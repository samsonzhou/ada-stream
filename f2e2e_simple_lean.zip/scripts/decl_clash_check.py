#!/usr/bin/env python3
"""Declaration-clash check for f2e2e (gate G1, static part).

Usage:
  decl_clash_check.py --root <tree> [--lib F2e2e]   check the tree (exit 0 iff both rules hold)
  decl_clash_check.py --self-test                  run the checker on synthetic trees under /tmp (exit 0 iff every
                                                   verdict is the expected one)

Two modules that declare the same constant cannot be imported together ("environment already contains ..."), so a
clash is only seen when some module, at the latest the final program assembly, imports both. Likewise two DSL
library functions with the same global index would collide in the assembled program table. Rules:
  D1  No two <lib> modules declare the same fully qualified, non-private name.
  D2  Every declaration in the namespace `<lib>.Idx` is a one-line `abbrev NAME : ℕ := NUMERAL` (the convention of
      F2e2e/Cost/Index.lean), and distinct names have distinct values.

Declarations are found textually, after comments and string literals are stripped (stripper of
scripts/scan_forbidden.py). Recognized: `def`, `abbrev`, `theorem`, `lemma`, `structure`, `inductive`, `class`,
`instance NAME`, `opaque`, `axiom`, with modifiers and attributes. The full name is the enclosing `namespace`s plus
the declared (possibly dotted) name; `_root_.` resets it. `section`/`mutual` blocks are tracked so that `end` pops
the right scope. `private` declarations are skipped, because their names are module-local. Not seen: generated
names (structure fields and constructors, anonymous instances, `alias`); Lean reports those clashes when it imports.
"""
import argparse
import collections
import pathlib
import re
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from scan_forbidden import strip_comments_and_strings  # noqa: E402

DECL = re.compile(r"^\s*(?:@\[[^\]]*\]\s*)*((?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*"
                  r"(abbrev|def|theorem|lemma|structure|inductive|instance|class|opaque|axiom)\s+([^\s:(\[{]+)")
IDX_DECL = re.compile(r"^\s*(?:@\[[^\]]*\]\s*)*abbrev\s+\S+\s*:\s*ℕ\s*:=\s*(\d+)\s*$")


def declared_names(lines):
    """[(full name, line number)] of the non-private declarations of a comment- and string-stripped file."""
    stack, out = [], []
    for ln, line in enumerate(lines, 1):
        s = line.strip()
        m = re.match(r"^namespace\s+(\S+)", s)
        if m:
            stack.append(("ns", m.group(1)))
            continue
        if re.match(r"^(?:noncomputable\s+)?section\b", s) or re.match(r"^mutual\b", s):
            stack.append(("blk", ""))
            continue
        if re.match(r"^end\b", s):
            if stack:
                stack.pop()
            continue
        m = DECL.match(line)
        if not m:
            continue
        mods, kind, nm = m.groups()
        if mods and "private" in mods:
            continue
        if kind == "instance" and nm[0] in ":[(":
            continue
        ns = [x for k, x in stack if k == "ns"]
        out.append((nm[len("_root_."):] if nm.startswith("_root_.") else ".".join(ns + [nm]), ln))
    return out


def module_files(root: pathlib.Path, lib: str):
    files = sorted((root / lib).rglob("*.lean"))
    if (root / (lib + ".lean")).exists():
        files.append(root / (lib + ".lean"))
    return files


def check(root: pathlib.Path, lib: str, quiet: bool = False) -> list:
    where = collections.defaultdict(list)       # name -> [(module, line)]
    idx = collections.defaultdict(list)         # value -> [(name, module, line)]
    bad = []
    ndecl = 0
    for path in module_files(root, lib):
        mod = ".".join(path.relative_to(root).with_suffix("").parts)
        lines = strip_comments_and_strings(path.read_bytes().decode("utf-8", errors="replace")).splitlines()
        for name, ln in declared_names(lines):
            ndecl += 1
            where[name].append((mod, ln))
            if name.startswith(lib + ".Idx."):
                m = IDX_DECL.match(lines[ln - 1])
                if m:
                    idx[int(m.group(1))].append((name, mod, ln))
                else:
                    bad.append(f"D2 {name} ({mod}:{ln}) is not a one-line `abbrev NAME : ℕ := NUMERAL`: "
                               f"{lines[ln - 1].strip()[:100]}")
    for name, locs in sorted(where.items()):
        mods = sorted({m for m, _ in locs})
        if len(mods) > 1:
            bad.append(f"D1 {name} is declared in {len(mods)} modules: " +
                       ", ".join(f"{m}:{ln}" for m, ln in locs))
    for v, decls in sorted(idx.items()):
        names = sorted({n for n, _, _ in decls})
        if len(names) > 1:
            bad.append(f"D2 index {v} is used by {len(names)} names: " +
                       ", ".join(f"{n} ({m}:{ln})" for n, m, ln in decls))
    if not quiet:
        for b in bad:
            print(f"DECL_CLASH FAIL: {b}")
        nidx = sum(len(d) for d in idx.values())
        print(f"DECL_CLASH SUMMARY: modules={len(module_files(root, lib))} declarations={ndecl} "
              f"names={len(where)} idx_constants={nidx} violations={len(bad)}")
    return bad


def self_test() -> int:
    cases = [
        ("clean", {"A.lean": "namespace F2e2e.Idx\nabbrev f : ℕ := 1\nend F2e2e.Idx\n",
                   "B.lean": "namespace F2e2e\nnamespace Idx\nabbrev g : ℕ := 2\nend Idx\ndef f : ℕ := 0\nend F2e2e\n"},
         []),
        ("dup_name_two_namespace_forms",
         {"A.lean": "namespace F2e2e.Idx\nabbrev pow2 : ℕ := 152\nend F2e2e.Idx\n",
          "B.lean": "namespace F2e2e\nnamespace Idx\nabbrev pow2 : ℕ := 100\nend Idx\nend F2e2e\n"}, ["D1"]),
        ("dup_idx_value", {"A.lean": "namespace F2e2e.Idx\nabbrev f : ℕ := 7\nend F2e2e.Idx\n",
                           "B.lean": "namespace F2e2e.Idx\nabbrev g : ℕ := 7\nend F2e2e.Idx\n"}, ["D2"]),
        ("nonliteral_idx", {"A.lean": "namespace F2e2e.Idx\nabbrev f : ℕ := 3\nabbrev g : ℕ := f + 1\nend F2e2e.Idx\n"},
         ["D2"]),
        ("private_and_comments_ok",
         {"A.lean": "namespace F2e2e\nprivate theorem h : True := trivial\n-- theorem k : True := trivial\nend F2e2e\n",
          "B.lean": "namespace F2e2e\nprivate theorem h : True := trivial\n/- def k : ℕ := 0 -/\ndef k : ℕ := 0\nend F2e2e\n"},
         []),
        ("sections_and_mutual_keep_namespace",
         {"A.lean": "namespace F2e2e.Foo\nsection s\nend s\nmutual\ndef a : ℕ := 0\nend\ntheorem t : True := trivial\n"
                    "end F2e2e.Foo\n",
          "B.lean": "namespace F2e2e.Bar\nsection\nend\ntheorem t : True := trivial\nend F2e2e.Bar\n"
                    "theorem F2e2e.Foo.t : True := trivial\n"}, ["D1"]),
        ("root_reset", {"A.lean": "namespace F2e2e\ntheorem _root_.foo : True := trivial\nend F2e2e\n",
                        "B.lean": "theorem foo : True := trivial\n"}, ["D1"]),
    ]
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="f2e2e_declclash_selftest_"))
    wrong = 0
    try:
        for name, files, want in cases:
            root = tmp / name
            for rel, content in files.items():
                p = root / "F2e2e" / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
            got = sorted({b.split()[0] for b in check(root, "F2e2e", quiet=True)})
            ok = got == sorted(want)
            wrong += 0 if ok else 1
            print(f"DECL_CLASH SELFTEST {'OK' if ok else 'WRONG'}: {name}: expected {sorted(want) or 'pass'}, "
                  f"got {got or 'pass'}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"DECL_CLASH SELFTEST SUMMARY: cases={len(cases)} wrong={wrong}")
    return 1 if wrong else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--lib", default="F2e2e")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        return self_test()
    if not a.root:
        ap.error("--root is required (or --self-test)")
    return 1 if check(pathlib.Path(a.root).resolve(), a.lib) else 0


if __name__ == "__main__":
    sys.exit(main())
