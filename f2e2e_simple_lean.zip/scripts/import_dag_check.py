#!/usr/bin/env python3
"""Import-DAG non-circularity check for f2e2e (gate G1, static part; adapted from cut2).

Usage:
  import_dag_check.py --root <tree> [--lib F2e2e]  check the tree (exit 0 iff every rule holds)
  import_dag_check.py --self-test                  run the checker on synthetic trees under /tmp (exit 0 iff every
                                                   verdict is the expected one)

Imports are parsed from the module headers (the leading `import` lines; `public`/`private`/`meta` prefixes and
`import all` are accepted). Only modules of the library <lib> are followed. Comments and string literals are
stripped before every search (with the same stripper as scripts/scan_forbidden.py), so a mention of the headline in a
docstring does not count.

Rules:
  R1  For every module M under <lib>/Lib/ (the spec-independent external-input libraries), the import closure of M
      (M itself and every <lib> module it imports, transitively) contains none of the following:
        * <lib>.Headline, or a module under <lib>.A, <lib>.B, <lib>.C, <lib>.AEff, <lib>.AEffU, <lib>.BSpace or
          <lib>.Comparator;
        * a module whose source mentions a headline (`theorem_A`, `theorem_B`, `theorem_C`, `theorem_main`,
          `Theorem_A`, `Theorem_B`, `Theorem_C`, their `_statistical` forms, and the Spec v3 names `theorem_A_eff`,
          `theorem_B_space`, `theorem_B_joint`, `theorem_main_full` (each also with `_2e128`), `Theorem_A_eff`,
          `Theorem_B_space`, `Theorem_B_joint` (each also with `_with`), `Theorem_main_full[_2e128]`), except
          <lib>.Spec (it defines the Props).
      Purpose: the external inputs are proved independently of the paper's development and of the headlines.
  R2  No <lib> module declares a constant whose last name component is a headline name: `theorem_A`, `theorem_B`,
      `theorem_C`, `theorem_main`, `theorem_A_statistical`, `theorem_B_statistical`, and (Spec v3) `theorem_A_eff`,
      `theorem_B_space`, `theorem_B_joint`, `theorem_main_full`, `theorem_B_space_2e128`, `theorem_B_joint_2e128`,
      `theorem_main_full_2e128` (`theorem`, `lemma`, `def`, `abbrev`, `instance`, `opaque` or `axiom`), except
      <lib>.Headline and the modules under <lib>.Comparator. (Names with a further suffix, e.g. `…_proof`, are
      not headline names.)
  R3  Every imported <lib> module exists in the tree, and the <lib> import graph is acyclic.
"""
import argparse
import pathlib
import re
import sys
import tempfile

sys.dont_write_bytecode = True  # do not leave scripts/__pycache__ behind
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from scan_forbidden import strip_comments_and_strings  # noqa: E402

# Headline names (Spec v2.2c and v3). The trailing \b makes a further suffix (e.g. `theorem_A_eff_proof`) a
# non-headline name.
HEADLINE_LOWER = (r"theorem_[ABC](?:_statistical)?|theorem_main(?:_full(?:_2e128)?)?|theorem_A_eff"
                  r"|theorem_B_(?:space|joint)(?:_2e128)?")
HEADLINE_UPPER = r"Theorem_[ABC](?:_statistical)?|Theorem_main_full(?:_2e128)?|Theorem_A_eff|Theorem_B_(?:space|joint)(?:_with)?"
MENTION = re.compile(r"\b(?:" + HEADLINE_LOWER + "|" + HEADLINE_UPPER + r")\b")
DECL = re.compile(r"\b(?:theorem|lemma|def|abbrev|instance|opaque|axiom)\s+(?:[\w.'«»]+\.)?(?:"
                  + HEADLINE_LOWER + r")\b")
IMPORT_LINE = re.compile(r"^(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(?:all\s+)?([\w.'«»]+)\s*$")


def module_name(root: pathlib.Path, path: pathlib.Path) -> str:
    return ".".join(path.relative_to(root).with_suffix("").parts)


def parse_header(stripped: str) -> list:
    """The modules imported by the header of a (comment- and string-stripped) Lean file."""
    imports = []
    for line in stripped.splitlines():
        s = line.strip()
        if not s:
            continue
        if s in ("prelude", "module"):
            continue
        m = IMPORT_LINE.match(s)
        if m:
            imports.append(m.group(1))
            continue
        break  # the first non-import token ends the header
    return imports


def load_tree(root: pathlib.Path, lib: str) -> dict:
    """module name -> {imports, mentions, decls (line numbers of `theorem_1_1` declarations)}."""
    mods = {}
    for path in sorted((root / lib).rglob("*.lean")):
        text = strip_comments_and_strings(path.read_bytes().decode("utf-8", errors="replace"))
        lines = text.splitlines()
        mods[module_name(root, path)] = {
            "imports": parse_header(text),
            "mentions": bool(MENTION.search(text)),
            "decls": [i + 1 for i, l in enumerate(lines) if DECL.search(l)],
        }
    top = root / (lib + ".lean")
    if top.exists():
        text = strip_comments_and_strings(top.read_bytes().decode("utf-8", errors="replace"))
        lines = text.splitlines()
        mods[lib] = {"imports": parse_header(text), "mentions": bool(MENTION.search(text)),
                     "decls": [i + 1 for i, l in enumerate(lines) if DECL.search(l)]}
    return mods


def in_lib(m: str, lib: str) -> bool:
    return m == lib or m.startswith(lib + ".")


def under(m: str, prefix: str) -> bool:
    return m == prefix or m.startswith(prefix + ".")


def closure(mods: dict, start: str, lib: str):
    """Breadth-first closure of `start` over <lib> imports: (set of reached modules incl. start, parent map)."""
    parent = {start: None}
    queue = [start]
    head = 0
    while head < len(queue):
        m = queue[head]
        head += 1
        for d in mods.get(m, {}).get("imports", []):
            if in_lib(d, lib) and d not in parent:
                parent[d] = m
                queue.append(d)
    return set(parent), parent


def path_to(parent: dict, m: str) -> str:
    p = []
    while m is not None:
        p.append(m)
        m = parent[m]
    return " -> ".join(reversed(p))


def find_cycle(mods: dict, lib: str):
    """Some import cycle among <lib> modules (as a list of modules), or None."""
    color = {}
    stack = []

    def dfs(m):
        color[m] = 1
        stack.append(m)
        for d in mods.get(m, {}).get("imports", []):
            if not in_lib(d, lib) or d not in mods:
                continue
            if color.get(d) == 1:
                return stack[stack.index(d):] + [d]
            if color.get(d) is None:
                c = dfs(d)
                if c:
                    return c
        stack.pop()
        color[m] = 2
        return None

    for m in sorted(mods):
        if color.get(m) is None:
            c = dfs(m)
            if c:
                return c
    return None


def check(root: pathlib.Path, lib: str, quiet: bool = False) -> list:
    """Run R1-R3 on the tree and print the findings. Returns the list of violated rule tags, one per violation."""
    out = (lambda *a: None) if quiet else print
    mods = load_tree(root, lib)
    bad = []
    # R3: dangling imports and cycles.
    for m in sorted(mods):
        for d in mods[m]["imports"]:
            if in_lib(d, lib) and d not in mods:
                out(f"DAG FAIL [R3]: {m} imports {d}, which is not in the tree")
                bad.append("R3")
    cyc = find_cycle(mods, lib)
    if cyc:
        out(f"DAG FAIL [R3]: import cycle {' -> '.join(cyc)}")
        bad.append("R3")
    # R1: closures of the Lib modules.
    headline, spec, libdir = f"{lib}.Headline", f"{lib}.Spec", f"{lib}.Lib"
    paper = [f"{lib}.A", f"{lib}.B", f"{lib}.C", f"{lib}.AEff", f"{lib}.AEffU", f"{lib}.BSpace",
             f"{lib}.Comparator"]
    coarse_mods = [m for m in sorted(mods) if under(m, libdir)]
    for m in coarse_mods:
        reach, parent = closure(mods, m, lib)
        reasons = []
        for d in sorted(reach):
            why = []
            if d == headline:
                why.append("is the headline module")
            for pp in paper:
                if under(d, pp):
                    why.append(f"is under {pp}")
            if d != spec and d in mods and mods[d]["mentions"]:
                why.append("mentions a headline")
            if why:
                reasons.append(f"{d} ({', '.join(why)}; path: {path_to(parent, d)})")
        status = "OK" if not reasons else "FAIL"
        out(f"DAG: {m}: closure={len(reach)} {lib} modules (incl. itself) {status}")
        for r in reasons:
            out(f"DAG FAIL [R1]: closure of {m} contains {r}")
            bad.append("R1")
    # R2: declarations named like a headline theorem.
    allowed = lambda m: m == headline or under(m, f"{lib}.Comparator")  # noqa: E731
    for m in sorted(mods):
        if mods[m]["decls"] and not allowed(m):
            out(f"DAG FAIL [R2]: {m} declares a headline theorem (line(s) {mods[m]['decls']}); only {headline} and "
                f"{lib}.Comparator.* may")
            bad.append("R2")
    mentioning = sorted(m for m in mods if mods[m]["mentions"])
    out(f"DAG SUMMARY: modules={len(mods)} lib={len(coarse_mods)} "
        f"mentioning_headlines={len(mentioning)} violations={len(bad)}")
    return bad


def self_test() -> int:
    """Synthetic trees under /tmp with known verdicts (the exact set of violated rules). Returns the number of
    wrong verdicts."""
    spec = "def Theorem_A : Prop := True\ndef Theorem_B : Prop := True\ndef Theorem_C : Prop := True\n"
    headline = "import F2e2e.Spec\n\ntheorem theorem_A : Theorem_A := trivial\n"
    cases = [
        ("A: a Lib module imports the headline", {"R1"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/Headline.lean": headline,
            "F2e2e/Lib/Fake.lean": "import F2e2e.Headline\n\ndef x : Nat := 0\n"}),
        ("B: a Lib module imports a Part B module (transitively)", {"R1"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/B/Algo.lean": "def algo : Nat := 1\n",
            "F2e2e/Util.lean": "import F2e2e.B.Algo\n",
            "F2e2e/Lib/Fake.lean": "import Mathlib\nimport F2e2e.Util\n"}),
        ("C: a Lib module imports a module that states Theorem_C", {"R1"}, {
            "F2e2e/Spec.lean": spec,
            "F2e2e/Util.lean": "import F2e2e.Spec\n\ntheorem useIt (h : Theorem_C) : True := trivial\n",
            "F2e2e/Lib/Fake.lean": "import F2e2e.Util\n"}),
        ("D2: a non-headline module declares theorem_B_statistical (Spec v2 name)", {"R2"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/Other.lean": "theorem F2e2e.theorem_B_statistical : True := trivial\n"}),
        ("D: a non-headline module declares theorem_B", {"R2"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/Other.lean": "theorem F2e2e.theorem_B : True := trivial\n"}),
        ("D3: a non-headline module declares theorem_main_full_2e128 (Spec v3 name)", {"R2"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/Other.lean": "theorem F2e2e.theorem_main_full_2e128 : True := trivial\n"}),
        ("D4: a non-headline module declares theorem_B_space (Spec v3 name)", {"R2"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/BSpace/X.lean": "theorem F2e2e.BSpace.theorem_B_space : True := trivial\n"}),
        ("D5: `_proof`-suffixed names are not headline names", set(), {
            "F2e2e/Spec.lean": spec,
            "F2e2e/AEff/Final.lean": "theorem F2e2e.AEff.theorem_A_eff_proof : True := trivial\n"}),
        ("B2: a Lib module imports an AEff module (Spec v3 proof dir)", {"R1"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/AEff/Ram.lean": "def ram : Nat := 1\n",
            "F2e2e/Lib/Fake.lean": "import F2e2e.AEff.Ram\n"}),
        ("B3: a Lib module imports an AEffU module (Spec v3.1 uniform A_eff dir)", {"R1"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/AEffU/RamU.lean": "def ramU : Nat := 1\n",
            "F2e2e/Lib/Fake.lean": "import F2e2e.AEffU.RamU\n"}),
        ("C2: a Lib module imports a module that mentions BSpace.Theorem_B_space_with", {"R1"}, {
            "F2e2e/Spec.lean": spec,
            "F2e2e/Util.lean": "import F2e2e.Spec\n\ntheorem useIt (h : BSpace.Theorem_B_space_with 128) : True := trivial\n",
            "F2e2e/Lib/Fake.lean": "import F2e2e.Util\n"}),
        ("E: a dangling import", {"R3"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/Lib/Fake.lean": "import F2e2e.Missing\n"}),
        ("F: an import cycle", {"R3"}, {
            "F2e2e/Spec.lean": spec, "F2e2e/P.lean": "import F2e2e.Q\n", "F2e2e/Q.lean": "import F2e2e.P\n"}),
        ("G: clean tree (mentions only in comments and strings; Headline imports Lib)", set(), {
            "F2e2e/Spec.lean": spec, "F2e2e/Headline.lean": "import F2e2e.Lib.Fake\n" + headline,
            "F2e2e/Util.lean": "import F2e2e.Spec\n\n/-! Used for `Theorem_A`. -/\n",
            "F2e2e/Lib/Fake.lean": ("-- leads to theorem_A\nimport F2e2e.Spec\nimport F2e2e.Util\n\n"
                                      "/-- not `theorem theorem_A` -/\ndef s : String := \"theorem_A\"\n")}),
    ]
    wrong = 0
    with tempfile.TemporaryDirectory(prefix="f2e2e_dag_selftest.", dir="/tmp") as tmp:
        for i, (name, expected, files) in enumerate(cases):
            root = pathlib.Path(tmp) / f"case{i}"
            for rel, content in files.items():
                p = root / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content)
            got = set(check(root, "F2e2e", quiet=True))
            verdict = "PASS" if got == expected else "WRONG"
            if got != expected:
                wrong += 1
            show = lambda s: "OK" if not s else "FAIL " + ",".join(sorted(s))  # noqa: E731
            print(f"DAG SELF-TEST {verdict}: case {name}: checker says {show(got)}, expected {show(expected)}")
    print(f"DAG SELF-TEST SUMMARY: cases={len(cases)} wrong={wrong}")
    return wrong


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--lib", default="F2e2e")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        return 1 if self_test() else 0
    if not a.root:
        ap.error("--root is required (or --self-test)")
    return 1 if check(pathlib.Path(a.root).resolve(), a.lib) else 0


if __name__ == "__main__":
    sys.exit(main())
