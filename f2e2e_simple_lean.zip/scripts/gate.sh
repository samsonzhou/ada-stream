#!/usr/bin/env bash
# f2e2e trust gate G1 (adapted from cut2's scripts/gate.sh): static scan, Spec pin/lock, elaborated gate. LEAD TOOL.
#
#   scripts/gate.sh [REV]           Full gate on commit REV (default HEAD). The static part runs on the files of REV,
#                                   extracted read-only with `git archive` (the scanned tree is exactly the built one).
#                                   The elaborated part builds F2e2e.GateCheck and F2e2e.GateTest at REV with
#                                   scripts/integ_build.sh (woodruffd6, ~/f2e2e_integ; never the workers' tree) and
#                                   re-runs GateCheck there to print its F2E2E_GATE report.
#   scripts/gate.sh --static [REV]  Static part only, on the files of commit REV (no build).
#   scripts/gate.sh --worktree      Static part only, on the main working tree (pre-commit check; no build).
#   scripts/gate.sh --dev [...]     Development mode (first argument): sorry/admit tokens are reported, not failures.
#                                   Never a closing gate; the closing gate is the plain form.
#
# Static part:
#   (1) F2e2e/Gate.lean and F2e2e/GateTest.lean have the pinned SHA256 values below (Gate.lean contains elab/Lean.Elab,
#       GateTest.lean deliberate negative controls; both whitelisted by SHA, not by name).
#   (2) scripts/scan_forbidden.py over every .lean file under F2e2e/ (comments and strings stripped; Spec.lean gets the
#       extra Spec rules). F2e2e/Scratch/ is not part of the library build and is excluded from commits.
#   (3) Import-DAG (scripts/import_dag_check.py, self-test first): R1 Lib modules independent of A/B/C/Headline and of
#       the headlines; R2 only F2e2e.Headline / F2e2e.Comparator.* declare theorem_A/B/C/main; R3 no dangling imports,
#       no cycles.
#   (3b) Declaration clashes (scripts/decl_clash_check.py, self-test first).
#   (4) Spec: F2e2e/Spec.lean = PINNED_SPEC_SHA (the audited/frozen version); once locked, also LOCKED_SPEC_SHA and a
#       verifying SPEC_LOCK.sha256.
# Elaborated part: the build of F2e2e.GateCheck fails iff some checked cone contains sorryAx, a native or non-standard
# axiom, or an implemented_by/extern/unsafe project constant; the build of F2e2e.GateTest fails iff a gate regression
# test fails. Every part runs even if an earlier one fails; summary at the end. Exit 0 iff all parts pass.
set -uo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)
H=woodruffd6.c.googlers.com

# Pinned SHA256 values of the gate files (copied from cut2 with the renaming Cut2 -> F2e2e, cut2 -> f2e2e,
# CUT2_GATE -> F2E2E_GATE; GateTest's positive controls point at F2e2e.Lib.DP.Defs). Update ONLY by the lead.
PINNED_GATE_SHA="42b4368e70ec603617a4c2ee5d3f4323f1dba47f93a3e3a9449c93a859ad2d51"
PINNED_GATETEST_SHA="34d045dc02c31eb491873d5e52d1dddb654a9edde0c6a7d3499a5751a32b1b59"
# Spec v3.1.2 (docs cross-reference for e2e_simple.pdf: comment/docstring-only patch of v3.1 lock d36e360b and v3.1.1
# 7d40afe2; scripts/strip_check.py IDENTICAL, stripped sha256 79c6cc1cbd8304adb52dd654db1facafa60aa1890e9af7b9bd1eaeebcde2263d).
PINNED_SPEC_SHA="0bda75467c74b470966a37c00c6f3fa0c0c31437b67078e9c83ca5ac6def35f0"
LOCKED_SPEC_SHA="0bda75467c74b470966a37c00c6f3fa0c0c31437b67078e9c83ca5ac6def35f0"

MODE=commit
BUILD=1
DEV=0
if [ "${1:-}" = "--dev" ]; then DEV=1; shift; fi
case "${1:-}" in
  --worktree) MODE=worktree; BUILD=0; shift ;;
  --static) BUILD=0; shift ;;
esac
SCAN_DEV=""
[ "$DEV" = 1 ] && SCAN_DEV="--allow-sorry" && echo "GATE: DEVELOPMENT MODE (sorry/admit tokens tolerated in the static scan; the elaborated gate still covers every module whose closure is sorry-free; NOT a closing gate)"
REV=${1:-HEAD}

if [ "$MODE" = worktree ]; then
  TREE="$ROOT"
  echo "GATE: mode=worktree tree=$TREE (static part only)"
else
  if ! COMMIT=$(git rev-parse --verify --quiet "$REV^{commit}"); then
    echo "GATE FAIL: unknown revision $REV"
    exit 2
  fi
  TREE=$(mktemp -d /tmp/f2e2e_gate.XXXXXX)
  trap 'rm -rf "$TREE"' EXIT
  PATHS=(F2e2e)
  if git cat-file -e "$COMMIT:SPEC_LOCK.sha256" 2>/dev/null; then PATHS+=(SPEC_LOCK.sha256); fi
  git archive "$COMMIT" -- "${PATHS[@]}" | tar -x -C "$TREE"
  echo "GATE: mode=commit commit=$COMMIT ($REV)$([ "$BUILD" = 1 ] || echo ' (static part only)')"
fi

FAILS=()

# (1) Pinned gate files.
for entry in "F2e2e/Gate.lean:$PINNED_GATE_SHA" "F2e2e/GateTest.lean:$PINNED_GATETEST_SHA"; do
  f=${entry%%:*}; pinned=${entry#*:}
  if [ ! -f "$TREE/$f" ]; then echo "GATE FAIL: $f is missing"; FAILS+=("pin:$f"); continue; fi
  sha=$(sha256sum "$TREE/$f" | cut -d' ' -f1)
  if [ "$sha" = "$pinned" ]; then echo "GATE: $f sha256 $sha (pinned) OK"
  else echo "GATE FAIL: $f sha256 $sha != pinned $pinned"; FAILS+=("pin:$f"); fi
done

# (2) Static scan (Scratch excluded: it is never imported and never committed).
SCAN_TREE="$TREE"
if [ "$MODE" = worktree ] && [ -d "$ROOT/F2e2e/Scratch" ]; then
  SCAN_TREE=$(mktemp -d /tmp/f2e2e_scan.XXXXXX)
  rsync -a --exclude=Scratch "$ROOT/F2e2e" "$SCAN_TREE/"
fi
if python3 "$ROOT/scripts/scan_forbidden.py" --root "$SCAN_TREE" --lib F2e2e --spec F2e2e/Spec.lean $SCAN_DEV \
    --whitelist-sha256 "$PINNED_GATE_SHA" "$PINNED_GATETEST_SHA" > /tmp/f2e2e_scan.$$ 2>&1; then
  echo "GATE: static scan OK"; grep -E "^SCAN (DEV|SUMMARY)" /tmp/f2e2e_scan.$$ | cut -c1-600
else
  grep -v "^SKIP" /tmp/f2e2e_scan.$$ | head -40; echo "GATE FAIL: static scan"; FAILS+=("scan")
fi
rm -f /tmp/f2e2e_scan.$$
[ "$SCAN_TREE" != "$TREE" ] && rm -rf "$SCAN_TREE"

# (3) Import DAG.
if python3 "$ROOT/scripts/import_dag_check.py" --self-test > /dev/null; then echo "GATE: import-DAG checker self-test OK"
else echo "GATE FAIL: import-DAG checker self-test"; FAILS+=("dag_selftest"); fi
if python3 "$ROOT/scripts/import_dag_check.py" --root "$TREE" --lib F2e2e > /tmp/f2e2e_dag.$$ 2>&1; then
  echo "GATE: import-DAG OK"; tail -1 /tmp/f2e2e_dag.$$
else grep "FAIL" /tmp/f2e2e_dag.$$ | head -20; echo "GATE FAIL: import-DAG"; FAILS+=("dag"); fi
rm -f /tmp/f2e2e_dag.$$

# (3b) Declaration clashes.
if python3 "$ROOT/scripts/decl_clash_check.py" --self-test > /dev/null 2>&1; then echo "GATE: declaration-clash checker self-test OK"
else echo "GATE FAIL: declaration-clash checker self-test"; FAILS+=("clash_selftest"); fi
if python3 "$ROOT/scripts/decl_clash_check.py" --root "$TREE" --lib F2e2e > /tmp/f2e2e_clash.$$ 2>&1; then
  echo "GATE: declaration clashes OK"
else grep -v "^OK" /tmp/f2e2e_clash.$$ | head -20; echo "GATE FAIL: declaration clashes"; FAILS+=("clash"); fi
rm -f /tmp/f2e2e_clash.$$

# (4) Spec pin / lock.
spec_sha=$(sha256sum "$TREE/F2e2e/Spec.lean" | cut -d' ' -f1)
if [ "$spec_sha" = "$PINNED_SPEC_SHA" ]; then echo "GATE: F2e2e/Spec.lean sha256 $spec_sha = PINNED_SPEC_SHA OK"
else echo "GATE FAIL: F2e2e/Spec.lean sha256 $spec_sha != PINNED_SPEC_SHA $PINNED_SPEC_SHA"; FAILS+=("spec_pin"); fi
if [ -n "$LOCKED_SPEC_SHA" ]; then
  if [ "$spec_sha" = "$LOCKED_SPEC_SHA" ] && [ -f "$TREE/SPEC_LOCK.sha256" ] \
      && grep -q "^$LOCKED_SPEC_SHA  F2e2e/Spec.lean$" "$TREE/SPEC_LOCK.sha256" \
      && (cd "$TREE" && sha256sum -c SPEC_LOCK.sha256 > /dev/null); then
    echo "GATE: LOCKED_SPEC_SHA and SPEC_LOCK.sha256 OK"
  else echo "GATE FAIL: Spec lock (LOCKED_SPEC_SHA / SPEC_LOCK.sha256)"; FAILS+=("spec_lock"); fi
else
  echo "GATE NOTE: Spec not locked yet (statement audit pending); pinned to the audited v1"
fi

# (5) Elaborated gate on woodruffd6.
if [ "$BUILD" = 1 ]; then
  LOG="/tmp/f2e2e_gate_build_${COMMIT:0:12}.log"
  REPORT="/tmp/f2e2e_gate_report_${COMMIT:0:12}.txt"
  if ! git cat-file -e "$COMMIT:F2e2e/GateCheck.lean" 2>/dev/null; then
    echo "GATE FAIL: F2e2e/GateCheck.lean is not in commit $COMMIT (run scripts/gen_gatecheck.py --write and commit)"
    FAILS+=("gatecheck_missing")
  else
    echo "GATE: building F2e2e.GateCheck F2e2e.GateTest at ${COMMIT:0:12} on $H (log: $LOG)"
    if "$ROOT/scripts/integ_build.sh" "$COMMIT" F2e2e.GateCheck F2e2e.GateTest > "$LOG" 2>&1; then
      echo "GATE: integration build of F2e2e.GateCheck F2e2e.GateTest OK"
    else
      echo "GATE FAIL: integration build (see $LOG)"; grep -E "error:|✖" "$LOG" | head -20; FAILS+=("build")
    fi
    ssh -o BatchMode=yes "$H" "cd ~/f2e2e_integ && systemd-run --user --scope --quiet --slice=f2e2e.slice -p MemoryMax=16G ~/f2e2e_slots.py 1 nice -n 10 env PATH=\$HOME/.elan/bin:/usr/bin:/bin lake env lean F2e2e/GateCheck.lean" > "$REPORT" 2>&1
    echo "GATE: GateCheck report ($REPORT):"
    grep -E "F2E2E_GATE: (OK|FAIL|ERROR|WARN)|depends on axioms|does not depend" "$REPORT" | cut -c1-400
    if ! grep -q "F2E2E_GATE: OK" "$REPORT" || grep -qE "F2E2E_GATE: FAIL|: error:" "$REPORT"; then
      echo "GATE FAIL: GateCheck report"; FAILS+=("report")
    fi
  fi
fi

if [ ${#FAILS[@]} -eq 0 ]; then
  if [ "$BUILD" = 1 ]; then echo "GATE OK"; else echo "GATE (static) OK"; fi
  exit 0
else
  echo "GATE FAIL: ${FAILS[*]}"
  exit 1
fi
