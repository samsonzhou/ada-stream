#!/usr/bin/env python3
"""Independent comment-strip check for two Lean files: removes line comments (`-- ...`), block comments (`/- ... -/`,
nested; includes doc comments `/-- -/` and module docs `/-! -/`), keeping string and char literals intact, then
normalizes whitespace runs (each maximal run of whitespace -> one space) and compares.

usage: strip_check.py A.lean B.lean   (prints IDENTICAL or DIFFERENT, with sha256 of both stripped texts)
"""
import hashlib
import re
import sys


def strip(src):
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith('--', i):
            j = src.find('\n', i)
            i = n if j < 0 else j          # keep the newline
            continue
        if src.startswith('/-', i):
            depth, i = 1, i + 2
            while i < n and depth:
                if src.startswith('/-', i):
                    depth, i = depth + 1, i + 2
                elif src.startswith('-/', i):
                    depth, i = depth - 1, i + 2
                else:
                    i += 1
            if depth:
                raise ValueError('unterminated block comment')
            out.append(' ')
            continue
        if c == '"':                         # string literal (with escapes)
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == '\\' else 1
            out.append(src[i:j + 1])
            i = j + 1
            continue
        if c == "'" and i + 2 < n and (src[i + 2] == "'" or (src[i + 1] == '\\' and "'" in src[i + 2:i + 8])):
            j = src.index("'", i + 2 if src[i + 1] != '\\' else i + 3)   # char literal like 'a' or '\n'
            out.append(src[i:j + 1])
            i = j + 1
            continue
        out.append(c)
        i += 1
    return re.sub(r'\s+', ' ', ''.join(out)).strip()


def main():
    a, b = (open(p, encoding='utf-8').read() for p in sys.argv[1:3])
    sa, sb = strip(a), strip(b)
    ha, hb = (hashlib.sha256(x.encode()).hexdigest() for x in (sa, sb))
    print(f'stripped sha256: {sys.argv[1]} {ha} ({len(sa)} chars); {sys.argv[2]} {hb} ({len(sb)} chars)')
    if sa == sb:
        print('IDENTICAL (comment-stripped, whitespace-normalized)')
        return 0
    k = next(i for i in range(min(len(sa), len(sb)) + 1) if i == min(len(sa), len(sb)) or sa[i] != sb[i])
    print(f'DIFFERENT at stripped offset {k}:\n  A: ...{sa[max(0, k - 80):k + 80]!r}\n  B: ...{sb[max(0, k - 80):k + 80]!r}')
    return 1


if __name__ == '__main__':
    sys.exit(main())
