# f2e2e: certification record (Spec v3.1 lock, v3.1.1 docs revision, and v3.1.2 `e2e_simple.pdf` cross-reference)

**Status: Spec v3.1 CERTIFIED** (integrator, 2026-10-25 17:08Z): statement audit FAITHFUL WITH MINOR ISSUES, both red teams
ACCEPT WITH FINDINGS, all closing checks green.

This package carries the v3.1.2 docs cross-reference for `e2e_simple.pdf` (`e2e_simple.tex`).

## The lock

- **main at the v3.1 lock:** `de676dccc6db9732e2f0439c9d5cd5570cd262f8` (tree `1d53ec7232fa07d3ab819f84bbdc00380b39c1fd`).
  It was fast-forwarded on 2026-10-25 at 16:56Z, on the integrator's sign-off, from `65d08ce6fb8adb3f831ed937d31017b5e15b2618`. The commit hash and tree are identical to the closed candidate.
- **Spec v3.1:** `F2e2e/Spec.lean`, sha256 `d36e360b80ae72627a493f9a65b159f67159ec2fd6ee441688a18db4bc27153a`.
  - Its v2.2c prefix is byte-identical to the v2.2c lock (sha256 `c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f`).
  - Relative to the audited text `2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e`, the only code change is fix F1 (`alg2Retained` / `alg2RetainedOf`); everything else in the delta is documentation.
- **Spec v3.1.1 (prior docs revision):** `F2e2e/Spec.lean`, sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`.
  - Comment/docstring-only patch of `d36e360b` applying statement audit replacements S1–S3 and red team B's D1/D2.
- **Spec v3.1.2 (this `e2e_simple.pdf` docs cross-reference):** `F2e2e/Spec.lean`, sha256 `0bda75467c74b470966a37c00c6f3fa0c0c31437b67078e9c83ca5ac6def35f0`.
  - Comment/docstring-only cross-reference patch of `7d40afe2` mapping Theorems 1.1–1.3, Algorithms 1–5, Section 7, and Appendix A of `e2e_simple.pdf` (`e2e_simple.tex`) to `F2e2e/Spec.lean` and `F2e2e/Headline.lean`.
  - Verified `IDENTICAL (comment-stripped, whitespace-normalized)` against `d36e360b` and `7d40afe2` via `scripts/strip_check.py` (stripped whitespace-normalized sha256 `79c6cc1cbd8304adb52dd654db1facafa60aa1890e9af7b9bd1eaeebcde2263d`; unnormalized comment-stripped sha256 `2ba118d2ced8551ebaea0c868f8eb63ea495eabf334fb04867d383a110a3638d`).

## Statement audit (an independent multi-stage statement audit)

The sanitized record is `notes/spec_v31/audit/F2E2E_V31_STATEMENT_AUDIT_SANITIZED.md`
(sha256 `2b36d87ba03426d59fc4cfce7c51db22a12dbb084216efc7c225eb18ab87b99a`); it is also appended verbatim to `F2E2E_SPEC_AUDIT.md`. Final verdict, verbatim:

```
Verdict: FAITHFUL WITH MINOR ISSUES
Per-headline: (A_eff) FAITHFUL; (B_space) FAITHFUL WITH MINOR ISSUES; (B_joint) FAITHFUL WITH MINOR ISSUES; (main_full) FAITHFUL WITH MINOR ISSUES
Staged target: main_full_2e128 HONESTLY LABELLED
Covers: SpecV31.lean, sha256 2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e (audited); SpecV31_d36e360b.lean, sha256 d36e360b80ae72627a493f9a65b159f67159ec2fd6ee441688a18db4bc27153a (delta: code (F1) verified in-stage; comment MINORs: 3, to be fixed in docs patch v3.1.1)
```

## Red teams (on the kit `comparator/kits/de676dccc6db`, SHA256SUMS sha256 `f8fd1a59aee3be327c6040e0ae095ff6036b83b09a59701d157cbc7cd383b244`)

- **Red team A:** "Verdict: ACCEPT WITH FINDINGS" (LOW/INFO only; no BLOCKER/HIGH/MEDIUM; no Spec-text findings).
  VERDICT.md sha256 `4820592c6d82bda5483ecf27d6d1c39f83e693b4296443b9a1c8b4f5e3ab3486`; FINDINGS.md sha256
  `668f3011c2677e933d114a4645cc32741549d3993328312a8bbf404c489d61d7`; TRACE_MANIFEST.tsv sha256
  `7114c5c561da7ba383f10f3b780d3a2cd98d01e191b407bb0e48c975db697e78`. Known, non-blocking: A-L1 (LOW; the comparator
  tool's version ceiling is v4.33.0 while the project uses Lean 4.33.1) and INFO items A-I1, A-I2, A-I5, A-I6, A-I7, A-I9.
- **Red team B:** "Verdict: ACCEPT WITH FINDINGS" (no CRITICAL, no MAJOR). VERDICT.md sha256
  `deb593c630fa26aecdedb2464bb9ee15746ca4254e1f4c3ef9e49935adcd0825`; FINDINGS.md sha256
  `e8d5cde07c6ae5ee8679a2ac42430fc4a99c542e276c106e79d56fda00a329f1`; TRACE_MANIFEST.tsv sha256
  `80007f54a53dba45d132fc8f5bd5bee0162dbcaa41cf39df71402a97f9183c6c`. Its documentation findings D1/D2 are applied in
  this docs revision.

## Headlines (`F2e2e/Headline.lean`)

Every headline depends only on the axioms `[propext, Classical.choice, Quot.sound]` (gate and CI GateCheck output):
- `theorem_A_statistical`
- `theorem_B_statistical`
- `theorem_C`
- `theorem_main`
- `theorem_A_eff`
- `theorem_B_space_2e128`
- `theorem_B_joint_2e128`
- `theorem_main_full_2e128`
- `theorem_B_space`
- `theorem_B_joint`
- `theorem_main_full`

`theorem_main_full : Theorem_main_full` is Main Theorem (A), (B) and (C) in full, with the paper's constants.

## Kernel and closing evidence for the lock commit `de676dc`

These paths are in the lead's campaign directory and are not part of the repository.

| check | verdict | evidence |
|---|---|---|
| gate (`scripts/gate.sh`) | GATE OK | `evidence/de676dc/gate/gate_de676dc.log` |
| CI: compile + leanchecker on every module | ALL_PASS 654/654 | `tools/borg/ci/de676dccc6db.md` |
| fresh replay: from-scratch build + `leanchecker --fresh F2e2e.Headline` | PASSED | `evidence/de676dc/fresh/` |
| comparator: Lean kernel + nanoda | ACCEPTED; negative controls REJECTED | `evidence/de676dc/kit/README.md` |
| con-leche 0d2f467b | ACCEPTED 84,399/84,399; negative controls REJECTED | `evidence/de676dc/kit/README.md` |
| summary | | `evidence/de676dc/README.md` |

The v3.1.1 docs revision is closed in the same way: strip-check, gate, CI, fresh replay, and a docs-revision kit through Lean + nanoda + con-leche. The evidence is under `evidence/<docs-rev>/`.
