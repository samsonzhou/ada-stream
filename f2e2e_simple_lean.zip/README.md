# Lean 4 Formalization (`F2e2e`) for `e2e_simple.pdf`

This archive contains the complete, mechanically verified Lean 4 (`leanprover/lean4:v4.33.1`, Mathlib `v4.33.0`) formalization for:

> *Adaptive Data Analysis with $\alpha^{-2}\operatorname{polylog}$ Overhead, Interval Validation, and Adversarially Robust Turnstile $F_2$ Estimation in $\varepsilon^{-2}\operatorname{polylog}$ Bits* (`e2e_simple.pdf` / `e2e_simple.tex`).

The project comprises **654 Lean modules** (`84,399` exported kernel declarations) culminating in `F2e2e.theorem_main_full : F2e2e.Theorem_main_full` in `F2e2e/Headline.lean`. Every headline theorem depends solely on Lean's three standard axioms (`propext`, `Classical.choice`, `Quot.sound`), with zero `sorry`, `sorryAx`, custom `axiom`, `native_decide`, `@[implemented_by]`, `@[extern]`, or `unsafe` declarations in the proof cone.

## Mapping Between `e2e_simple.pdf` and Lean Declarations

| `e2e_simple.pdf` Reference | Specification (`F2e2e/Spec.lean`) | Proof Source & Headline Wrapper (`F2e2e/Headline.lean`) |
|---|---|---|
| **Theorem 1.1** (`thm:ada`, statistical & sample bound; Section 4, Algorithm 1, Def. A.1, Lemma A.2) | `Theorem_A_statistical` (`adaCascade`, `adaSampleSize`, `ADAPublicGuarantee`) | `F2e2e.A.theorem_A_statistical_proof` (`F2e2e/A/Final.lean`) $\to$ `F2e2e.theorem_A_statistical` |
| **Theorem 1.1** (`thm:ada`, uniform `RatLits` real-RAM runtime & workspace; Section 7.1) | `Theorem_A_eff` (`AEff.RamProgram.RunsWithin`, `ADAOutputStreamed`) | `F2e2e.AEff.theorem_A_eff_proof` (`F2e2e/AEff/Final.lean`) $\to$ `F2e2e.theorem_A_eff` |
| **Theorem 1.2** (`thm:val-ada`, statistical, internal caps & bounded sampler; Section 5, Algorithm 2, Def. A.3, Lemma A.4) | `Theorem_B_statistical` (`alg2Mech`, `VGuaranteeWithInternalCaps`) | `F2e2e.B.theorem_B_statistical_proof` (`F2e2e/B/Final.lean`) $\to$ `F2e2e.theorem_B_statistical` |
| **Theorem 1.2** (`thm:val-ada`, `2^30 N (b_U + chi^2)`-bit space & joint single-witness `c_0`; Section 7.1, Lemma A.4) | `Theorem_B_space`, `Theorem_B_joint` (`RunsWithinBitsO`, `ReproducesFor 30`, `alg2RetainedOf`) | `F2e2e.BSpace.theorem_B_space_proof`, `theorem_B_joint_proof` (`F2e2e/BSpace/O2AssembleFinal.lean`) $\to$ `F2e2e.theorem_B_space`, `theorem_B_joint` |
| **Theorem 1.3** (`thm:f2`, robust turnstile `F_2` accuracy & `2^512 eps^{-2} Lambda^{15}`-bit space; Section 6, Algorithms 3–5, Defs. A.5–A.6, Lemma A.7) | `Theorem_C` (`StreamExec`, `RunsWithinBits`, `StreamAccurate`, `spaceBoundC`) | `F2e2e.C.Closure.theLawBound` (`F2e2e/C/Final.lean`) + `F2e2e.C.Impl.Asm.theorem_C_of_lawBound` (`F2e2e/C/Impl/Assemble.lean`) $\to$ `F2e2e.theorem_C` |
| **Full Conjunction** (Section 7, Table 2) | `Theorem_main_full` | `F2e2e.theorem_main_full` (`F2e2e/Headline.lean`) |

Single-pass no-replay and fixed-birth tree invariants on the constructed streaming algorithm are proved in `F2e2e/C/Alg/StrictModel.lean`. Locked streaming parameters and precision ceilings are in `F2e2e/C/ParamsDefs.lean` and `F2e2e/C/SpaceParams.lean` (see Appendix A, Tables 3–4 of `e2e_simple.pdf`).

## Specification Lock (`F2e2e/Spec.lean`)

- **Literal SHA-256 (`SPEC_LOCK.sha256`):** `0bda75467c74b470966a37c00c6f3fa0c0c31437b67078e9c83ca5ac6def35f0`
- **Comment-stripped, whitespace-normalized SHA-256 (`scripts/strip_check.py`):** `79c6cc1cbd8304adb52dd654db1facafa60aa1890e9af7b9bd1eaeebcde2263d` (identical to locked Spec v3.1 `d36e360b` and v3.1.1 `7d40afe2`).

## Reproducible Verification Commands

1. **Static Trust Gate** (verifies SHA-256 pins of `Spec.lean`, `Gate.lean`, and `GateTest.lean`, scans all 654 modules for forbidden tokens, checks import-DAG isolation and zero declaration clashes):
   ```bash
   bash scripts/gate.sh --worktree
   ```
2. **Type-check `F2e2e/Spec.lean` directly** (once Mathlib is fetched/built via `lake exe cache get` or `lake build`):
   ```bash
   LEAN_NUM_THREADS=2 lake env lean -DautoImplicit=false -DrelaxedAutoImplicit=false F2e2e/Spec.lean
   ```
3. **Full Build, Elaborated Axiom Gate, and Fresh Kernel Replay**:
   ```bash
   lake build F2e2e.Headline F2e2e.GateCheck F2e2e.GateTest
   lake env lean F2e2e/GateCheck.lean
   lake env leanchecker --fresh F2e2e.Headline
   ```
4. **Comment-Stripped Equivalence Check** (comparing any two revisions of `Spec.lean`):
   ```bash
   python3 scripts/strip_check.py path/to/ref/Spec.lean F2e2e/Spec.lean
   ```
