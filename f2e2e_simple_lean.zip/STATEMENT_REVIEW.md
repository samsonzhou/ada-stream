# f2e2e — STATEMENT_REVIEW.md (Spec v3.1.2 cross-reference for `e2e_simple.pdf`; locked Spec v3.1/v3.1.1 text preserved below)

## Cross-reference to `e2e_simple.pdf` (`e2e_simple.tex`)

- **Specification (`F2e2e/Spec.lean`):** literal SHA-256 `0bda75467c74b470966a37c00c6f3fa0c0c31437b67078e9c83ca5ac6def35f0`, comment-stripped whitespace-normalized SHA-256 `79c6cc1cbd8304adb52dd654db1facafa60aa1890e9af7b9bd1eaeebcde2263d` (`scripts/strip_check.py`: IDENTICAL to Spec v3.1 `d36e360b` and v3.1.1 `7d40afe2`).
- **Theorem 1.1 (`thm:ada`, Section 4, Algorithm 1 `alg:cascade`, Definition A.1 `def:cas-params`, Lemma A.2 `lem:cas-sample-bound`, Corollary 4.7 `cor:cas-absorbed`):** `Theorem_A_statistical` + `Theorem_A_eff` (proved by `F2e2e.theorem_A_statistical` and `F2e2e.theorem_A_eff`).
- **Theorem 1.2 (`thm:val-ada`, Section 5, Algorithm 2 `alg:val-ada`, Definition A.3 `def:val-params`, Lemma A.4 `lem:val-sample-bits`):** `Theorem_B_statistical` + `Theorem_B_space` + `Theorem_B_joint` (proved by `F2e2e.theorem_B_statistical`, `F2e2e.theorem_B_space`, and `F2e2e.theorem_B_joint`).
- **Theorem 1.3 (`thm:f2`, Section 6, Algorithms 3–5 `alg:zero-fp`, `alg:norm-bank`, `alg:time-tree`, Definitions A.5–A.6 `def:f2-params`, `def:f2-grids`, Lemma A.7 `lem:f2-bits`):** `Theorem_C` (proved by `F2e2e.theorem_C`, with strict single-pass/fixed-birth invariants in `F2e2e/C/Alg/StrictModel.lean`).
- **Full conjunction (Section 7 `sec:lean`, Table 2 `tab:lean-map`):** `Theorem_main_full` (proved by `F2e2e.theorem_main_full` in `F2e2e/Headline.lean`).

---

Original v3.1/v3.1.1 review header (`e2e.pdf` / `e2e_rev2.pdf`):
Source: the package `~/ada5_rf2_e2e_final/` (2026-10-24).
- `e2e.pdf`, md5 `158a3f8f4d65231e9492ed2a910226b3`.
- LaTeX `e2e_source.tgz`, md5 `3ccb54d5b9dd262f151a677810124162`, extracted to `source/`.

Every statement below is taken from the LaTeX: `e2e.tex` (Main Theorem), `parts/partI.tex`, `parts/partII.tex`, `parts/partIII.tex`.

Lean (v3.1.1): **`F2e2e/Spec.lean` = `notes/spec_v31/SpecV31.lean`, sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523` (3787 lines), sha-pinned**
(`SPEC_LOCK.sha256` and the gate pins; audit record `F2E2E_SPEC_AUDIT.md`; main carries this commit only after the
integrator's sign-off on a FAITHFUL verdict of the v3.1 statement audit). Its first 2344 lines (142,145 bytes) are the v2.2c file,
byte for byte; the v3.1 additions (§6–§8) follow and are reviewed in "Spec v3.1.1 additions" at the end of this file.
The rest of this section describes the v2.2c prefix: `notes/spec_v2_2_draft/SpecV2_2c.lean`, sha256
`c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f` (2344 lines), locked 2026-10-25 as v2.2c.
- v2.2c is v2.2b (`a34af531…`, which passed the mechanical check) with one comment line changed at the integrator's
  sign-off (10:07:54Z). In the footer, the label of rounds 1–2 lost the audit tool's name (now "audit rounds 1–2"): no tool names in shareable files.
- The code tokens are identical to v2.1, v2.2 and v2.2b. Summaries: v1→v2 in `spec_v2/V1_TO_V2.md`, v2→v2.1 in
`notes/spec_v2_1_draft/V2_TO_V2_1.md`, v2.1→v2.2 in `notes/spec_v2_2_draft/V2_1_TO_V2_2.md`.
- Generators, both by exact-once replacements with `--check` reproducing the file byte for byte:
  - `notes/spec_v2_1_draft/make_v2_1.py` applies the v2.1 edits to the frozen v2 file.
  - `notes/spec_v2_2_draft/make_v2_2.py` applies F-dR to the frozen v2.1 file.
- v2.1 (sha256 `9aeafbeb…`, frozen, the focused-check record) stays at `notes/spec_v2_1_draft/SpecV2_1.lean`.
- v2.1 → v2.2 changes only the `regBits` docstring (F-dR, verbatim from the check's "Exact Lean fixes") and puts the one-line `regBits` definition on two lines. The code tokens are identical to v2.1: 12446 tokens, comments stripped.
- v2.2b = v2.2 (`ae054eb6…`) with only the title and footer labels updated, at the integrator's request, so the locked bytes do not say "not audited; not locked". No sha appears in the new labels, and the code tokens are again identical. The generator is `notes/spec_v2_2_draft/make_v2_2b.py` (exact-once replacements; `--check` IDENTICAL).
- It imports only Mathlib and uses plain definitions.
- The v2.2c headlines are `F2e2e.Theorem_A_statistical`, `F2e2e.Theorem_B_statistical` and `F2e2e.Theorem_C`, each a
  `def … : Prop`. v3.1 adds `Theorem_A_eff`, `Theorem_B_space`, `Theorem_B_joint`, `Theorem_main_full` and
  `Theorem_main_full_2e128` ("Spec v3.1.1 additions"). `F2e2e/Headline.lean` proves `theorem_A_eff`, `theorem_B_space`,
  `theorem_B_joint`, `theorem_main_full` (the paper's `2^30`) and the `2^128` forms `theorem_B_space_2e128`,
  `theorem_B_joint_2e128`, `theorem_main_full_2e128` (closing evidence: `evidence/<candidate rev>/`, produced on this
  exact commit; see the kit README).
- `F2e2e/Headline.lean` proves each headline and their conjunction: `theorem_A_statistical`, `theorem_B_statistical`,
  `theorem_C`, `theorem_main`. Each depends only on `propext`, `Classical.choice`, `Quot.sound`. This was checked by the
  closing gate, by leanchecker on every module and by `leanchecker --fresh F2e2e.Headline`, all at commit 7802a6a
  (`FINAL_REPORT.md`, `evidence/7802a6a/`).
- Spec v2 (sha256 `cc04b02b…`, the round-2 audit record) stays unchanged at `spec_v2/Spec.lean`. Spec v1 (sha256
  `6a5254ff…`, commit 06ddff3, the round-1 audit record) is archived at `attic/Spec_v1_6a5254ff.lean` (lock commit 58fed18).
- The v2 → v2.1 code delta, with comments stripped, is +101/−3 lines:
  - the 95-line §3.2 block (14 definitions);
  - one changed conjunct of `RunsWithinBits`;
  - the examples: the satisfiability example's bound goes from 64 to 150 under the new charge, and there is one new
    example.
  The (A) and (B) code is byte-identical to v2, as are the bodies of `StreamExec`, `spaceBoundC` and `Theorem_C`.

> Internal / need-to-know. Nothing from this file or the
> paper goes to external tools.

## Scope of the v2.2c headlines (read first; the claims and non-claims are those of v2; v3.1's additional headlines are in "Spec v3.1.1 additions")

> [!IMPORTANT]
> **What v2.2 claims.** These are v2's claims. v2.1 only extended (C)'s space charge, and v2.2 only corrects one docstring.
> - **(A) `Theorem_A_statistical`.** The specific mechanism of Definition I.1.8 is pinned in the Spec: the cascade,
>   the locked allocation of Definition I.1.6, and the coin law. Its complete public output (each answer together
>   with the auxiliary public records τ_aux, partI.tex L45–52) is shown to analysts, who may adapt to it. The
>   mechanism answers `k` adaptive statistical queries with `P[max_i |a_i − μ_i| ≤ α] ≥ 1 − β`. Its locked sample
>   size satisfies the paper's explicit formula, the intermediate explicit bound and the `O(·)` bound.
> - **(B) `Theorem_B_statistical`.** Algorithm 2 is pinned in the Spec: allocation, internal state, and bounded
>   fair-bit samplers. Its sample count satisfies the paper's explicit and `O(·)` bounds. With probability
>   `≥ 1 − ξ_req`, Algorithm 2 never exhausts an internal correction cap (no cap/abort event) **and** every covered
>   response is correct. Both are in ONE event under ONE `ξ_req`.
> - **(C) `Theorem_C`.** This is e2e Main Theorem (C) as stated at e2e.tex L160–164: "There is a finite-precision
>   single-pass streaming algorithm that, against any computationally unbounded adaptive adversary in the integer
>   turnstile model with ‖x^{(t)}‖_∞ ≤ U, outputs F̂_t ≥ 0 after every update t ≤ m such that P[∀ t ≤ m :
>   F₂(x^{(t)})/(1+ε) ≤ F̂_t ≤ (1+ε)F₂(x^{(t)})] ≥ 1 − β, using at most 2^512 ε⁻² Λ^15 = ε⁻² polylog(n, m, U, 1/ε,
>   1/β) bits of space on every execution, counting all samples, seeds, counters, learner states, scale tags, caches,
>   noise samplers, public parameters, and arithmetic workspace; all randomness consists of fresh independent fair
>   bits." Space is measured in **certified bits** on a small-step machine (§C.3.1). At every step, the charge is the sum
>   of three terms:
>   - the explicit prefix-free binary encodings of the configurations before and after the step;
>   - the live storage of an explicitly specified bit-level algorithm for the step's arithmetic primitive;
>   - explicitly charged finite-control temporaries.
>   The last two terms are new in v2.1.
>
> **What the v2.2c headline Props do NOT claim (explicit non-claims, as in v2).** These remain true of
> `Theorem_A_statistical` / `Theorem_B_statistical`. Spec v3.1 claims the (A) and (B) clauses below through additional
> headlines (see the pointers and "Spec v3.1.1 additions").
> - (A): "The mechanism runs in O(kn) arithmetic operations and O(n) working space in the real-arithmetic (oracle)
>   model of Proposition I:prop:runtime" (e2e.tex L150; partI.tex L34). Spec v3.1 claims it as the
>   separate headline `Theorem_A_eff` (§6; "Spec v3.1.1 additions"). Also not restated: the `k`-independent absorbed additive form (Corollary
>   I:cor:absorbed_sample_complexity), which follows analytically from the explicit bound.
> - (B): "if records use b_𝒰 bits, at most 2^30 N(b_𝒰 + χ²) bits plus the working space of its evaluation oracle"
>   (e2e.tex L155; partII.tex L966–970). Spec v3.1 claims it as `Theorem_B_space` (the paper's
>   `2^30`), plus `Theorem_B_joint`; the `2^128` forms are stated too (§7–§8; "Spec v3.1.1 additions").
> - (C): Theorem R:thm:main (partII.tex L22) is stronger than e2e (C). It adds "obeying the strict streaming model
>   constraints of Definition R:def:streaming-model", namely rules 2–3 at partII.tex L41–42: no full buffering or
>   replay; persistence of descendant learners/banks across ancestor corrections via rescaling; no in-place resets;
>   data-independent bank births along a fixed binary interval tree; retirement before replacement. **These rules are
>   NOT a headline claim in v2 or v2.1.** They are non-headline construction lemmas about the constructed
>   algorithm; §F gives their proof status. The single-pass and fresh-bit parts are built into the execution model
>   (§C.3).

## Changes v1 → v2 (round-1 findings → v2 fix)

| # | round-1 finding | v2 fix |
|---|---|---|
| M1 | (A) has no O(kn)/O(n) conclusion | Explicit non-claim (scope box); headline renamed `Theorem_A_statistical`; v3 draft `AEff.lean`, now Spec v3.1 §6 `Theorem_A_eff`. |
| M2 | (B) has no finite-bit implementation and no 2^30·N(b_𝒰+χ²) bound | Explicit non-claim (scope box); headline renamed `Theorem_B_statistical`; v3 draft `BSpace.lean`, now Spec v3.1 §7 `Theorem_B_space`. |
| M3 | (A)/(B) are unrestricted existentials with selected sample counts | (A) pins Def I.1.8's cascade with the locked allocation (`n` = the paper's formula exactly) and its coin law; (B) pins Algorithm 2 with its allocation `N = Σ n_j` and its internal state (§A.3, §B.3). |
| M4 | (A)'s analyst sees answers only | The analyst sees each round's full public record (answer + τ_aux); the record contents are fixed by the pinned cascade (§A.3). |
| M5 | (B)'s success event omits cap non-exhaustion | (B)'s failure event = (some covered response wrong) ∪ (Algorithm 2's execution exhausts an internal correction cap / aborts), under one `ξ_req`; the cap event is derived from the pinned execution, not a ghost function (§B.3). |
| M6 | `valSize` tree units are not bits | (C) now measures bits: `confBits` = length of an explicit prefix-free encoding of the whole machine configuration (control, environments, continuation stack) of a small-step machine for the same DSL; `StreamExec` uses `RunsWithinBits`: for every step of every run, the footprint (bits of the configuration before the step plus bits of the configuration after it) is at most `S` (§C.3.1). In v2.1 the bound covers the footprint plus the step's arithmetic workspace `stepWork` plus its control temporaries `ctrlWork` (U-C row below). The proof bridges the big-step DSL to this machine inside `spaceBoundC`. |
| M7 | strict-model rules 2–3 missing | Integrator decision R4-0: the (C) headline is e2e Main Theorem (C) (L160), which does not reference Def R:def:streaming-model. R:thm:main's stronger clause is an explicit non-claim (scope box). Rules 2–3 are proved as non-headline lemmas (§F). Round-2 question V6 asks whether this is faithful to Main Theorem (C) as stated. |
| m1 | (A)'s answers are unrestricted reals | The pinned mechanism's answers are `clip01` values; the public answer type is documented as `[0,1]`-valued (§A.3). |
| m2 | `VCovered` "halts" comment | Replaced by the round-1 F1 text (totalized coverage contract, not an operational halting assertion). |
| m3 | `Real.log x = 0` for x ≤ 1 (false) | §0 uses the round-1 F2 logarithm text. |
| m4 | `Fin n → X` nonempty iff X nonempty needs n > 0 | §0 uses the round-1 F2 empty-product text. |
| m5 | p ≤ 5 ln(1/a_req) false (a_req = 99/1000 gives p = 12) | §B uses p ≤ 6 ln(1/a_req), with the F2 justification (Lean: `valP_le_six_mul_log`). |
| m6 | "deterministic algorithms are never accurate" false (n = 1) | §C.3.9 uses the round-1 F2 text. |
| m7 | "only definitions and the three headlines" inaccurate | The module docstring now says definitions, three headline propositions, and proved sanity examples, plus the scope statement. |
| N1–N3 | notes | N1: outer-measure convention kept. N2: sample sum unchanged (v1 verbatim; the parse is correct, round 1 refuted R1). N3: determinism lemmas are proved in the project (§F), not in the Spec. |

## Changes v2 → v2.1 (round-2 findings → v2.1 fix)

Audit round 2 (on v2 `cc04b02b…`) found (A) and (B) FAITHFUL WITH MINOR and (C) UNDETERMINED on U-C ("potentially MAJOR").
It accepted V6 (the R4-0 scope).

| # | round-2 finding | v2.1 fix |
|---|---|---|
| U-C | (C): `step` performs arbitrary-precision arithmetic atomically, and `RunsWithinBits` charged only the two endpoint configurations, so the binary workspace was justified only "up to a constant" (e.g. `2^63 · 2^63` has footprint 530 bits). Required implication: "Every relevant machine transition has a uniform implementation with the same result and coin consumption, whose complete live binary storage is bounded by the charged before-plus-after footprint, or by another explicitly accounted quantity already inside spaceBoundC." | v2.1 takes the second branch, with every term explicit in the Spec (§C.3.1). The new Spec §3.2 defines `opWork op a b` as the maximum of `regBits` over the trace of `arithRun op a b`. This is an explicitly specified bit-level algorithm for each primitive: ripple-carry adder; sign-magnitude add/sub; shift-and-add multiplication; restoring division with the `Int.ediv`/`Int.emod` fix-up; comparison by the adder's carry; equality scan. `stepWork` charges `opWork` at every arithmetic step. `ctrlWork` charges every step 64 bits plus four position registers of `⌈log₂(footprint + workspace + 2)⌉` bits. The `RunsWithinBits` conjunct is now `confBits c + confBits c' + stepWork c + ctrlWork c c' ≤ S`. Non-headline lemmas (§F.4): `arithRun` returns `evalBin`'s result and takes no tape, so it reads no coins; `opWork ≤ 8(\|enc a\| + \|enc b\|) + 64`; every step's charge is `≤ 50·(bitsFactor·S + bitsConst) + 392`, inside `spaceBoundC`. |
| dA | (A) review text: the sample sum was described as parenthesized; it is not | N2 row corrected (review text only; Spec unchanged). |
| dB | (B) B14: "`T_j` never decreases" is false across an abort | Fixed in the Spec docstrings of `alg2Interval`, `alg2Numerical`, `Alg2Outcome` and `alg2PeakCorrections` (code unchanged) and in the B14 row. On non-aborting requests, end-of-round counts equal within-request peaks. An abort can return the pre-request counts; the sticky abort flag makes that round an internal failure. |
| dC1 | (C): the Spec said rules 2–3 are "stated and proved" outside the Spec | The Spec header and the `Theorem_C` docstring now say only "Separate non-headline lemmas about the constructed algorithm are listed in STATEMENT_REVIEW v2 §F". The Spec makes no completion claim. |
| dC2 | (C) M6 row: it must say "per-step footprint (before + after) ≤ S" | The M6 row, §C.2 and §C.3 now describe the per-step charge: the footprint, plus v2.1's workspace and control terms. |
| N3 | Lattice-draw example: "reads true, false" are Bernoulli outcomes, not tape bits | Docstring: Bernoulli outcomes `true, false` from the raw tape bits `false, true`, then the outcome `false` from the raw bit `true`. The example itself is unchanged. |

## Changes v2.1 → v2.2 (focused (C) check → v2.2 fix)

The focused (C) check of the audit (on v2.1 `9aeafbeb…`) found (C) FAITHFUL WITH MINOR ISSUES.
- U-C is resolved; the check reproduced the 2^63·2^63 step charged 530 + 400 + 104 = 1034 bits.
- The algorithms are correct, consume no coins, and introduce no new loophole.

| # | finding | v2.2 fix |
|---|---|---|
| dR | (C) documentation: the `regBits` docstring called the register-file encoding self-delimiting. It is not self-delimiting standalone: `[]` ↦ `0` is a prefix of `[[]]` ↦ `00`. The individual registers are self-delimiting, and the register count comes from the control phase, which `ctrlWork` charges. | The `regBits` docstring is replaced by F-dR verbatim; the definition is unchanged. The §C.3.1 prose is qualified with the check's replacement text. |

## 0. Conventions common to all three

| Convention | Choice | Junk-value risk | Status |
|---|---|---|---|
| Logarithms | `Real.log` (natural) where the paper writes `ln` (Part I) or `log` in an O-bound (base change is a constant); `Real.logb 2` for `log₂` (`Λ`, `χ`) | Real.log is the ordinary natural logarithm on positive arguments. Real.log 0 = 0, and for negative nonzero x it equals Real.log \|x\|. In particular, it is negative on (0,1), not zero. Every explicit logarithm argument used by the headline parameter formulas is greater than one on the stated ranges (§A.4, §B.6, §C.3.9). | OK |
| Dyadic rounding | `dyadicExp x = Nat.clog 2 ⌈x⁻¹⌉₊ = ⌈log₂ x⁻¹⌉` (verbatim cut2), `dyadicDown x = 2^{-dyadicExp x} ∈ (x/2, x]` for `0 < x < 1` | none on `(0,1)` | OK |
| Ceilings | `⌈·⌉₊` (`Nat.ceil`) only on positive reals | `⌈x⌉₊ = 0` for `x ≤ 0` never happens on the hypotheses | OK |
| ℕ subtraction | `adaL α - 1` (`L ≥ 5`); `r - 1` in `adaNmax` and `adaEtaTilde` (used for `r ≥ 3`); `st.M r - 1` (`M_r ≥ 1` always); `p - 1` in `valP` (`p ≥ 2` in the set); `r - 1` in the `adaEps` exponent (real subtraction after cast) | truncation impossible on the used ranges | OK |
| Division | `x / 0 = 0` in Lean: every denominator is `> 0` on the hypotheses | none | OK |
| `rpow` | `α ^ ((r-1)/(L-1))` with a real exponent only for base `α > 0` | none | OK |
| Universes | all quantified types (`X`, the coin spaces `ΩA`/`Ω`, `U`) live in `Type` (universe 0), not in an arbitrary `Type u`. The paper allows arbitrary probability spaces | conventional fixed-universe formalization (round 1: NOTE R12; red team B: F-m3). It is a convention, not a weakening of any concrete instance: every space the paper uses is a `Type` | OK (convention) |
| Empty types | For N = 0, Fin N → X is a singleton, even when X is empty. For N > 0 it is nonempty exactly when X is nonempty. An admissible probability distribution forces X to be nonempty. The zero-length product probability measure has total mass one. | none | OK |
| Probability | (A) Mathlib `Measure.pi` + `Measure.prod`, with the pinned coin law (a product of the paper's Beta/Laplace laws); (B), (C) finite sums over samples/fair coins, weighted by an arbitrary probability measure on the adversary's/controller's coins | the measure of a non-measurable set is the outer measure, so "≤ β" is the strong form (round 1: N1, conservative) | OK |
| Randomized adversaries | an arbitrary probability space `Ω : Type` of private coins, independent of everything else (product / sum form), measurable in the coins for each fixed history | mirrors the paper (§I.1(ii); Def R:def:streaming-model rule 1; partII.tex L1032) | OK |

## A. Main Theorem (A) — `Theorem_A_statistical`

### A.1 The paper (e2e Main Theorem (A) = Theorem I.1.1, `I:thm:main`, partI.tex L8–35)
For every `k ≥ 1`, `α ∈ (0, 1/16)` and `β ∈ (0, 1/2)`, the mechanism of Definition I.1.8 with the locked parameters of Definition I.1.6 works as follows.
- It answers `k` adaptively chosen statistical queries `q_i : X → [0,1]` on any probability distribution `D` over any measurable domain `X`.
- It works against any adaptive analyst, possibly randomized and computationally unbounded, that sees the public transcript (answers and auxiliary records, L45–52).
- It guarantees `P[max_i |a_i − μ_i| ≤ α] ≥ 1 − β`.
- It uses `n = n₁ + ∑_{r=2}^{L-1} n_r + n_L` samples (eq. `I:eq:main_thm_explicit_n`), with `n ≤` the explicit bound `I:eq:main_explicit_bound` and `n = O(…)` as in e2e.tex L147. For `β ≥ α⁵` the leading term improves.
The computational clause ("O(kn) arithmetic operations and O(n) working space") is not claimed by
`Theorem_A_statistical` (scope box); Spec v3.1 claims it as `Theorem_A_eff` ("Spec v3.1.1 additions" §6).

### A.2 Side by side (paper line ↔ Lean definition)
| paper (line) | Lean (candidate) | note |
|---|---|---|
| Thm I.1.1 (L8–35), e2e (A) (L146–150) | `Theorem_A_statistical` | `∃ C>0 ∀ k≥1, α∈(0,1/16), β∈(0,1/2)`: `IsProbabilityMeasure (adaCoinLaw k α β) ∧ (adaCascade k α β).JointlyMeasurable ∧ adaSampleSize ≤ adaExplicitBound ∧ adaSampleSize ≤ C·adaAsymp ∧ ADAPublicGuarantee …`; scope: no `O(kn)`/`O(n)` clause |
| model (L40–54); `h_{<i}` (L45–47); `τ_aux,i` (L52) | `ADAPublicMechanism`, `ADAPublicAnalyst` | round `i` output `(a_i, τ_aux,i) : Set.Icc 0 1 × (ADAField → ℝ)` from the query values on the sample and the coins; analyst sees all previous outputs (previous queries are reconstructible from its coins) |
| items recorded in `h` (L316, L326, L335–339, L355–361, L366–370, L373–388) | `ADAField` | `active`, `c1` (`c_i^{(1)}`), `b r` (`b_i^{(r)}`), `uPrev r` (`u_prev(r)` on triggers), `released r`, `v r`, `c r` (`v_i^{(r)}`, `c_i^{(r)}`: trigger or retroactive release), `s` (`s^{(1)}_{t₁}` / `s_{i,r*}`), `delta m` (`δ_{m,i}`), `haltAfter` |
| `q_i : X → [0,1]` measurable, joint measurability (L47) | `ADAPublicAnalyst.Valid`, `.JointlyMeasurable` | product σ-algebra on the history (Borel on `[0,1]` and on each record field) |
| (audit N1) | `ADAPublicMechanism.JointlyMeasurable` | headline conjunct |
| accuracy event, `μ_i = E_D q_i` (L49–50, L63–64) | `adaPublicOutputs`, `adaPublicFails`, `ADAPublicGuarantee` | F1 code with the record type; outer measure; product `D^n ⊗ (P_M ⊗ P_A)` |
| (P2) `R₁ = α/32`, `η₁ = α/16` (L207) | `adaR1`, `adaEta1` | identical bodies to `F2e2e/A/Params.lean` |
| (P2) `p₁` (L218–223) | `adaP1` | branch test `α^5 ≤ β` as `adaChi1` |
| (P4) `τ_{(u,r)}` (L236–239) | `adaTau α u r` | argument order `(u, r)` as in A-ARCH |
| (P5) `w_m`, `η_m`, `η̃_{r*}`, `η̃_L = 0` (L245–249) | `adaW`, `adaEta`, `adaEtaTilde` | |
| partition into `S_1..S_L` (L116, L303) | `adaBlock`, `adaOffset`, `adaQAt` | consecutive blocks, `S_1` first; `adaOffset (L+1) = adaSampleSize` |
| `Lap(b)` density `e^{-|z|/b}/(2b)` (L297) | `laplaceLaw` | `volume.withDensity`; same body as the project's `F2e2e.laplace` |
| `ξ_i = R₁(2B_i−1)`, `B_i ∼ Beta(p₁,p₁)` (L224, L322) | `adaStage1Law` | `(ProbabilityTheory.betaMeasure p₁ p₁).map (v ↦ R₁(2v−1))` |
| noise draws `ρ^{(r)}` (L311, L360, L388), `ν_i^{(r)}` (L331), `ζ_i^{(r)}` (L336, L366) | `ADANoiseIndex`, `adaNoiseLaw`, `adaCoinLaw`, `noiseXi/Nu/Zeta/Rho` | index `Fin k ⊕ (Fin k × Fin (L+1)) ⊕ (Fin k × Fin (L+1)) ⊕ (Fin (L+1) × Fin (k+1))` = A-ARCH's `NoiseIdx.equivSum` target (same order and ranges); `Measure.pi` |
| `K₂(S_r)` (L117–119), `KL(P‖Unif)` (L120–123) | `capSimplex2`, `klUnif` | `0 ln 0 = 0` via `Real.log 0 = 0` |
| `P*(G) = argmin_{K₂}{⟨P,−G⟩ + η⁻¹KL}` (L134–137) | `entropicObjective`, `entropicArgmin` | literal argmin (ε-choice); Stage 1: `η₁` on `G^{(1)}` (L358); validators: `η = 1` on `L^{(m)}` (L385) |
| clip, sign (L297) | `clip01` (subtype-valued), `sign1` (`sign 0 = +1`) | |
| State Initialization (L305–313) | `ADAState`, `ADAState.init` | `halt, t1, N, M (=1), pay (G^{(1)} / L^{(m)}), P (= Unif)`; `t_m` omitted (index only) |
| halted round (L316) | `adaRound` | `a_i = 0`, record ≡ 0 (incl. `δ = 0`, `active = 0`), no data access, state unchanged |
| `θ_i^{(r)}` (L317–320) | `θ` in `adaActiveRound` | start-of-round weights, all `r ≤ L` |
| Step 1 (L322–326) | `c1` in `adaActiveRound` | |
| Step 2: test (L331–334), pass (L335), trigger + release (L336–340), `u_final`, `a_i` (L342–345) | `adaFires`, `adaChain`, `trig`, `uFinal`, `answer` | chain state = (origin, clipped proposal) before testing stage `r` |
| Step 3 Case 0 (L350), A (L352–362), B (L364–389) | `caseA/caseB`, `released`, `s`, `δ`, `haltAfter`, `pay'`, `upd`, `P'`, `st'`, `record` in `adaActiveRound` | resets: `M_2` (A3), `M_s, 2≤s≤r*` (B3); HALT iff the incremented counter reaches its cap |
| Def. I.1.8 as a whole | `adaStateBefore`, `adaCascade` | replay of rounds `0..i` = online execution |

### A.3 Modeling choices and junk-value risks
| # | choice / risk | assessment |
|---|---|---|
| A1 | rounds numbered `0..k−1` (paper `1..k`) | cosmetic |
| A2 | noises pre-drawn in a finite table instead of "fresh when needed" | same joint law: every entry is used by at most one paper draw and which entry is read is determined by the past (`ζ_i^{(r)}`: trigger release or (B1), never both; `ρ^{(r)}_e`: episode `e = M_r − 1`) |
| A3 | out-of-range noise reads return `0` | unreachable for rounds `i < k` (episode index `M_r − 1 ≤ i < k+1`, stages `≤ L`); rounds `≥ k` are never evaluated by the failure event |
| A4 | `adaQAt` returns `0` if `adaOffset r + ℓ ≥ n` | unreachable for `1 ≤ r ≤ L` (`adaOffset (L+1) = adaSampleSize`; project lemma `A.adaOffset_add_lt`) |
| A5 | `entropicArgmin` = ε-choice | equals the unique minimizer for block size `≥ 1` and `η > 0` (Lemma I.1.4(1); project: `Opt.kkt_water_filling`, `eq_waterFill_of_isMinOn`); arbitrary only if no minimizer (`n = 0`), never used |
| A6 | `ξ_i` used raw (no clamp to `(−R₁,R₁)`) | literal (L322); `|ξ_i| < R₁` almost surely; A-ARCH switches to this form |
| A7 | `laplaceLaw b` is the zero measure for `b ≤ 0`; `Measure.map` is `0` for a non-AE-measurable map | not on the range (`b_SVT > 0`; the map is continuous); in any case the conjunct `IsProbabilityMeasure (adaCoinLaw k α β)` excludes a degenerate coin law |
| A8 | `ADAPublicGuarantee` has no `[IsProbabilityMeasure PM]` binder | the Spec cannot declare instances; probability of the coin law is the first headline conjunct instead |
| A9 | record encoding: bits as reals `0/1`, `u_prev(r)` as a real, unpublished items `0`; derived flags `active`, `haltAfter` | injective on what the paper publishes, and Borel-decodable, so the class of jointly measurable analysts is not reduced; not published: `v_i^{(1)}`, noises, `θ`, weights, counters (counters are derivable anyway) |
| A10 | `P^{(r)}` stored in the state, initialized to `Unif` (L307–309) and recomputed only for updated levels | literal; equals A-ARCH's `waterFill` of the payoff by uniqueness |
| A11 | public interface types written inline (`Set.Icc (0:ℝ) 1 × (ADAField → ℝ)`), coin space via a `def` alias of a sum type with `Measure.pi (ι := …)` | needed to get Mathlib's measurable-space/`Fintype` instances without declaring instances or `abbrev` |
| A12 | `M_r − 1` in `ℕ` | safe: `M_r ≥ 1` always |
| A13 | answers in `Set.Icc 0 1` | `clip01 x = ⟨min 1 (max 0 x), …⟩` (L297 literally) |

### A.4 Parameters (Definition I.1.6) — unchanged from v1
These are transcribed one-to-one and were checked in round 1 ("correct formulas, branches, and constants; no active ceiling/log junk"). They are `adaL`, `adaGamma`, `adaU0`, `adaL1`, `adaChi1`, `adaN1`, `adaEps`, `adaEpsL`, `adaRanc`, `adaDeltaVal`, `adaLval`, `adaT1max`, `adaNmax`, `adaMmax`, `adaBsvt`, `adaNr`, `adaNL`, `adaSampleSize`, `adaExplicitBound` and `adaAsymp`.
Log arguments, all `> 1` on the range:
- `1/α > 16`;
- `20480/(αβ)`;
- `4/δ_val`, `64LkM_{2,max}/δ_val`, `6k/δ_val` (`δ_val < 5·10⁻²⁴`);
- in `adaAsymp`: `1/(αβ) > 32`, `ln(1/α) > 2.77`, `k ln(1/α)/(αβ) > 88`, `ln(1/α)/(αβ) > 88`.
v2 adds `adaR1`, `adaEta1`, `adaP1`, `adaTau`, `adaW`, `adaEta`, `adaEtaTilde`, `adaBlock` and `adaOffset` (§A.2), all of which have positive denominators on the range.

### A.5 Not claimed
- The efficiency clause (scope box), by `Theorem_A_statistical`; Spec v3.1 claims it as `Theorem_A_eff`.
- The `k`-independent absorbed form (a corollary, not in e2e (A)).
- The barrier theorem I.1.10 (a side result).

## B. Main Theorem (B) — `Theorem_B_statistical`

### B.1 The paper (e2e Main Theorem (B) = Theorem `R:thm:validation_ada`, partII.tex §3, L633–1060)
Setting:
- a finite domain `𝒰` with unknown distribution `𝒟`;
- `a_req ∈ (0, 1/10)` and `ξ_req ∈ (0, 1/2)`;
- caps `M, J, R ∈ ℕ`.
Algorithm 2 interacts with an adaptive controller. The controller submits functions `f_t : 𝒰 → [0,1]`, accessed only through their values on the samples, each with an interval request or a numerical request.
With probability `≥ 1 − ξ_req` (L951–959):
- it never exhausts an internal correction cap;
- every interval response up to and including a terminal `(J+1)`-st rejection satisfies the three certificate implications;
- every numerical answer is within `a_req`.
It uses `N = ∑_j n_j ≤ 2^64[…]` and `N = O[…]` samples. The bit-space clause is not claimed by
`Theorem_B_statistical` (scope box); Spec v3.1 claims it as `Theorem_B_space` and `Theorem_B_joint` ("Spec v3.1.1 additions" §7–§8).

### B.2 Side by side (paper line ↔ Lean definition)
| paper (line) | Lean (candidate) | note |
|---|---|---|
| Thm 3.6 `R:thm:validation_ada` (L951–970), e2e (B) (L151–159) | `Theorem_B_statistical` | `∃ C>0 ∀ M J R aReq ξReq`: `N ≤ valNExplicit ∧ N ≤ C·valNAsymp ∧ ∃ c, VGuaranteeWithInternalCaps … (alg2Mech … c) (alg2Aborted … c) (alg2PeakCorrections … c)`, `N = (alg2Params …).N`; scope: no bit-space clause |
| dyadic `a`, `ξ_A` (L669); `p` (L671); `τ, h` (L673); `T_j^max` (L673); `Q` (L685); `χ` (L686) | v1: `dyadicDown`, `valP`, `valTau`, `valH`, `valTmax`, `valQ`, `valChi` | verbatim v1 §2.1 |
| `κ = τ/4` (L673) | `valKappa` | |
| out-of-range `T_j^max = 0` (L675) | `valTcap` | used for `C_j` and the algorithm's caps |
| `C_0, C_j, C_p` (L682–684) | `valC` | `T_{−1}^max = 0` handled by `if 2 ≤ j` |
| `ξ_j`, `δ` (L686) | `valXiJ`, `valDelta` | |
| `d_j` (L689) | `valD` | |
| `n_j` (L690–692), `N = ∑ n_j` (L647) | `valNBlock`, `Alg2Params.N` | same formula as B-NUM's `alg2NBlock` |
| `h_A` (L693–696) | `valMaxN`, `valHABound`, `valHAExp`, `alg2Params.hA = (1/2)^{q_A}` | largest power of two `≤` the bound |
| `b_int, b_out, b_num` (L697–700) | `alg2Params.bInt/bOut/bNum` (ℚ) | `h = τ/64 = a/(512p)`, `a = (1/2)^e` as rationals |
| lattice law, `ϱ = b/(b+h_A)` (L703–706) | `Alg2Params.rho` (ℚ) | lowest terms = `Rat.num/den` |
| `ζ`, `B_0`, `K_s`, `r_s` (L708–711) | `valZeta`, `alg2Params.B0`, `Alg2Params.Ks`, `Alg2Params.rs` | paper form `⌈log₂ ·⌉` (B-ARCH: `Nat.clog 2 ⌈·⌉`, equal; bridged) |
| sampler step 1 (L713) | `readBits`, `bernoulliCoin` | `⌈log₂ D⌉ = Nat.clog 2 D` bits, MSB first, `r` trials, fallback `false` |
| steps 2–3 (L714–715) | `successCount`, `latticeSample`, `Alg2Params.draw` | `G₁` then `G₂`, each capped at `K_s`; index `G₁ − G₂` |
| `W_j`, `R_j`, `w_j` (L740–742) | `capSimplex8`, `quadReg`, `learnerObjective`, `learnerWeights` | literal argmax (ε-choice) |
| `μ_j`, anchor `μ_p` (L742, L746) | `alg2Mu` | weights recomputed from `G_j` on demand |
| conventions (L750): rounding, endpoint clipping, persistent thresholds, test scales, sampler | `roundGridQ`, `alg2Evals`, endpoints in `alg2Interval`, `Alg2State.thrInt/thrOut`, `4 b` draws | `round_h(z) = h⌊z/h+1/2⌋` (partII L155) |
| state (line [1], L755) | `Alg2State` | `G, T, thrInt, thrOut, rej, nInt, nNum, halted, aborted` |
| `PrepareRoot` (L757–765) | `alg2EdgeTest`, `alg2ReopenEdges`, `alg2DrawThresholds`, `alg2Correct`, `alg2ScanPass`, `alg2PrepareRoot`, `Alg2Status` | cache bits reset per request; phases persist across requests |
| `Interval` (L767–771) | `alg2Interval`, `alg2Reject` | |
| `Numerical` (L773–775) | `alg2Numerical` | |
| initialization (L750) | `alg2Init` | |
| run | `alg2Request`, `alg2Exec`, `Alg2Outcome` | one tape `List.ofFn ω` threaded through init and rounds |
| the mechanism of Thm 3.6 | `alg2Mech`, `alg2Aborted`, `alg2PeakCorrections` | projections of one `alg2Exec` |
| protocol (L651–664) | v1 `VResponse` … `VFails` | verbatim; `VCovered` docstring = F1 text |
| "never internally exhausts a correction cap" (L952; Lemma 3.5(v), L892–896: `T_j < T_j^max`) | `vRoundViews`, `VInternalFails` | F2: reaching the cap counts |
| joint success probability (L951–959) | `VGuaranteeWithInternalCaps` | F2: union, one `ξ_req` |

### B.3 Modeling choices and junk-value risks
| # | choice / risk | assessment |
|---|---|---|
| B1 | over-cap requests and requests after halting: dummy `ACCEPT` / `num 0`, no sample access, no bits, no state change | audit Q8: acceptable ("refuse and continue"); identical to B-ARCH |
| B2 | `CAP_ABORT` (L762) is output by the paper; the Spec returns the dummy and sets `aborted` (sticky), halting in the state before the aborting request (request counted) | the paper does not specify the post-halt state (aligned with ArchCore); the round is an internal failure via `aborted`, so the response is irrelevant |
| B3 | `TERMINAL_REJECT`: the certificate `HIGH`/`LOW` itself; terminal iff `J ≤ rej` | the flag is recoverable by counting (v1, audit-accepted) |
| B4 | the tape length `c` is existential; running out of bits = internal abort | a short tape only hurts the prover (abort ⇒ failure); for `c ≥` the worst-case bit count (B-ARCH: `adaCoins`, depth bound proved) the exhaustion branches are unreachable |
| B5 | `PrepareRoot` pass budget `1 + ∑_j T_j^max`; exhaustion reported as `capAbort` | unreachable (each pass but the last applies a correction with `T_j < T_j^max`) |
| B6 | draw order: init `ϑ̂_int,0..p−1` then `ϑ̂_out`; edge test `ν₊` then `ν₋` (both always drawn); reopened thresholds in increasing edge order; outer `ν_H` then `ν_L`; one `2b_out` redraw after a non-terminal rejection; one `b_num` draw | identical to B-ARCH (paper does not fix an order; the law is order-independent) |
| B7 | priorities: edge positive branch first (L762); outer `HIGH` first | outer priority unstated in the paper; L990 presupposes it; identical to B-ARCH |
| B8 | crossing iff value `≥` threshold | "test … against" (L760, L769); accept iff `max < τ + ϑ̂` (L917) |
| B9 | query values rounded without clipping to `[0,1]` | literal (L750); valid controllers are `[0,1]`-valued (B-ARCH clips first; equal on valid views) |
| B10 | endpoints `round_{h_A}(max (−1) (min 2 x))`; numerical answer `max 0 (min 1 (round_{h_A}(μ_0 + Z)))` in ℚ | L750, L775; `max lo (min hi x)` form = ArchCore's `clipQ` |
| B11 | `learnerWeights` = ε-choice | unique maximizer for `n_j ≥ 1` (project: `capWeightsQ_spec`, `eq_learnerWeights_of_isMax`) |
| B12 | `h_A`, `b`'s, `ϱ` in ℚ | needed for "`ϱ = A/D_ϱ` in lowest terms"; `(P.rho b).num > 0` for `b > 0` |
| B13 | `alg2Evals` returns `0` beyond `N` | unreachable (`offset p + n_p = N`) |
| B14 | `peakCorrections` = `T_j` at the end of the round | `T_j` never decreases except across an abort: the abort branches restore the pre-request counters (round-2 mB). The guarantee is unaffected, because `aborted = true` is itself an internal failure, and before any abort `T_j` is monotone. Corrections only happen in processed (= covered) rounds. |
| B15 | `alg2Exec` replays rounds `0..t` from the views | online equivalence (round `j` uses only views `0..j` and the tape prefix it reads) |
| B16 | no mechanism measurability conjunct | outer-measure convention (audit N1: acceptable) |

Further (protocol, unchanged from v1; round 1: correct):
- **Coverage** (`VCovered`, F1 text): the first `M` interval / first `R` numerical requests are covered, up to and including the terminal `(J+1)`-st rejection on covered interval requests. Over-cap requests are uncovered, and rejections on them do not count. "Refuse and continue" was accepted in round 1 (R8).
- **Correctness** (`VCorrect`): the three certificate implications; numerical answers lie in `[0,1]` and within `a_req`. A wrong-kind response is incorrect.
- **Non-vacuity**: with `N = 0` and `M ≥ 1` no mechanism succeeds.
- **Validation depth**: for the dyadically rounded accuracy a = 2^(-e), e ≥ 4, the candidate p = 2e+4 satisfies the defining inequality because 2^e ≥ 2e+4. Since e < log₂(1/a_req)+1, ln 2 > 2/3 and ln(1/a_req) > ln 10 > 2, this gives p < 6 ln(1/a_req). (Lean: B-NUM `valP_le_six_mul_log`.) This makes the asymptotic conjunct provable with one universal `C` (B-NUM: `C = 2^84`).

### B.6 Junk check
- `valP a = sInf {p | 2 ≤ p ∧ 1 ≤ 4^{p−1}(a/(8p))²}` is nonempty for every `a > 0` (`p ≥ 12` for `a ≤ 1/16`).
- `τ, h > 0`; `χ` is `⌈log₂(·)⌉₊` of an argument `> 2^40`; `1/aReq > 10`; `(M+J+R+2)/(aReq ξReq) > 40`; `T_j^max` is only used for `j < p` (`valTcap` = 0 beyond).
- `h_A`, the `b`'s and `ϱ` are positive rationals.
- Out-of-range reads are unreachable (`alg2Evals` beyond `N`, B13).

## C. Main Theorem (C) — `Theorem_C`

### C.1 The paper
e2e Main Theorem (C) (e2e.tex L160) is quoted in the scope box. It points to Theorem R:thm:main (partII.tex L22, proved in Part III), which states the same guarantee and space bound, "obeying the strict streaming model constraints of Definition R:def:streaming-model". The v2 headline is the e2e statement; rules 2–3 are an explicit non-claim (scope box, §F). Common content: for all integers `n, m, U ≥ 1` and reals `ε, β ∈ (0, 1/10)`, with `Λ = log₂[2^100 (n+2)(m+2)(U+2)/(εβ)] > 100`, there is an explicit finite-precision single-pass streaming algorithm that works against any computationally unbounded adaptive adversary in the integer turnstile model (`x^{(0)} = 0`, `x^{(t)} = x^{(t−1)} + Δ_t e_{i_t}`, `‖x^{(t)}‖_∞ ≤ U` for `1 ≤ t ≤ m`). It outputs `F̂_t ≥ 0` after every update, achieves `P[∀t: F₂/(1+ε) ≤ F̂_t ≤ (1+ε)F₂] ≥ 1 − β`, and uses at most `2^512 ε⁻² Λ^15` bits on every execution. All randomness consists of fresh independent fair bits.

### C.2 Side by side
| Paper | Lean |
|---|---|
| explicit algorithm | `∃ alg : StreamAlgorithm` **before** all parameters (uniform; C.3.2) |
| `n, m, U ≥ 1`, `ε, β ∈ (0,1/10)` | `1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1/10 → 0 < β → β < 1/10 →` |
| public parameters; Def 1.5 dyadic normalization | the programs see `encStreamParams (n, m, U, ⌈log₂ ε⁻¹⌉, ⌈log₂ β⁻¹⌉)` |
| memory at every instant ≤ `2^512 ε⁻² Λ^15` **bits**, every execution | conjunct 1: for every deterministic adversary and all tapes, `StreamExec … (spaceBoundC n m U ε β) …`. At every step `c → c'` of every machine run (initialization and each round), `confBits c + confBits c' + stepWork c + ctrlWork c c' ≤ S`: the configurations before and after the step, the arithmetic workspace and the control temporaries (§C.3.1). |
| `P[∀t ≤ m: F₂/(1+ε) ≤ F̂_t ≤ (1+ε)F₂] ≥ 1 − β` | conjunct 2: `∑_tapes P{ω : ¬∃ exec, StreamExec … ∧ StreamAccurate …} ≤ β · 2^{#tape bits}` |
| adversary `𝓐_t(τ_adv, F̂_1..F̂_{t−1})` | `adv : Ω → StreamAdversary n`, `∀ h, Measurable (fun ω => adv ω h)` |
| stream, box promise, `F₂` | `streamVec`, `BoxUpTo`, `F2` (Lean round `t = 0..m−1` is paper update `t+1`) |
| `Λ`, bound | `masterLambda` (`Real.logb 2`), `spaceBoundC = 2^512 · ε⁻¹^2 · Λ^15` with the real `ε, β` |

### C.3 Modeling notes
1. **Cost model: certified bits (round-1 M6 fix).** The program language (§3 of the Spec: `Val`, `Expr`, `evalBin`, `evalUn`) is the v1/cut2 first-order language with the fresh-bit primitive `Expr.coin`, unchanged.
   - **Machine.** Programs now run on a small-step CEK-style machine `step`/`stepN`. A configuration consists of:
     - the control: evaluate the expression at a code position in an environment, or return a value;
     - a continuation stack of frames, each frame recording its node's code position and exactly the data needed later (a saved environment or value);
     - the unread tape.
     The machine mirrors the big-step evaluator rule by rule. It gets stuck exactly where `eval` fails (type error, division by zero, missing variable, malformed loop result, exhausted tape).
   - **Bits.** `confBits prog c` is the length of `encodeConf prog c`, an explicit prefix-free binary encoding of the control and the stack:
     - integers use the self-delimiting `bitEncodeVal` (round-1 check-3 F-C1 encoding);
     - lists are self-delimiting;
     - code positions use `⌈log₂(|prog|+1)⌉` bits for the function plus 3 bits per path step;
     - frames carry a 4-bit tag.
     Environments saved in several frames are counted each time (no sharing), which over-counts. The program text is not memory: it is fixed before all parameters (C.3.2), and positions into it are charged. The random tape is not memory: the paper's bits are "drawn when used; no future random tape is stored".
   - **Run predicate (v2.1).** `RunsWithinBits prog input tape out S` says two things:
     - the machine halts with `out`;
     - every step `c → c'` satisfies `confBits c + confBits c' + stepWork c + ctrlWork c c' ≤ S`.
     The footprint `confBits c + confBits c'` holds the operands and the result of the step's primitive. Every reached configuration is covered, including the initial one (which holds the input) and the final one (which holds the output).
     v2 charged the footprint only, a hardening from spec checker C (F2). Round 2 found that this covers the arithmetic workspace only "up to a constant" (U-C). v2.1 adds two terms: the arithmetic workspace (`stepWork`, matching the paper's register-level accounting of arithmetic, partIII.tex L1243) and the control temporaries (`ctrlWork`).
   - **Arithmetic workspace (`stepWork`, Spec §3.2).** A step that applies `add`, `sub`, `mul`, `div`, `mod`, `lt` or `eq` to two integers is charged `opWork op a b`. This is the maximum of `regBits` over the trace of the bit-level algorithm `arithRun op a b`, which is defined in the Spec:
     - ripple-carry adder `addTrace`;
     - sign-magnitude addition/subtraction `addSM`;
     - shift-and-add multiplication `mulTrace`;
     - restoring long division `divTrace`, with the `Int.ediv`/`Int.emod` sign fix-up `divSM`;
     - comparison by the adder's final carry;
     - equality scan `eqTrace`.

     Each state of a trace lists the algorithm's complete live registers: signs, operand magnitudes, partial results, carries and flags, plus the live registers of a calling computation. `regBits` charges `2|r| + 1` bits per register plus 1.

     Each register is self-delimiting under the charged encoding. The number and roles of registers are determined by the arithmetic control phase, which is covered by `ctrlWork`; alternatively, the register count is at most ten and can be held in the constant control allowance. `regBits` is not claimed to be the length of a standalone self-delimiting encoding of arbitrary register-file lists. Trace histories are semantic instrumentation, not retained implementation memory. (v2.2, dR)

     No loop counter is stored. The fuel is `max |x| |y| + δ`, with `δ ∈ {0,1}` fixed by the caller (the loop runs until both operand registers are empty), or the recursion consumes a register.

     Between consecutive states, the algorithm does one of three things: it moves a constant number of bits at register ends; it drops or trims registers; or it moves or copies registers at a sub-computation boundary. So its storage never exceeds the larger of two consecutive states, except for constant-size temporaries, which `ctrlWork` charges. The listing of the states, and of the transitions between them, is the modeling claim. It can be checked by inspecting the 95-line block.

     All other steps are charged no workspace: variable reads, literals, `nil`, `coin`, frame pushes/pops, the `ite`/`letE`/`call`/`loop` frames, `cons` (relinking) and `head`/`tail`/`isNil` (cutting). Each of these only moves, copies or cuts data held in one of the two configurations. Ill-typed operands and division by zero give stuck steps, which are never charged.
   - **Control temporaries (`ctrlWork`).** Every step is charged `64 + 4·⌈log₂(confBits c + confBits c' + stepWork c + 2)⌉` bits:
     - four position registers, each able to address any position in the two configurations and the workspace: a read cursor, a write cursor, a nesting-depth counter, and an index or length counter;
     - 64 bits of constant-size temporaries: flags, a bit in transit, register delimiters.
   - **Why this meets the round-2 implication.** v2.1 takes its second branch, "another explicitly accounted quantity already inside spaceBoundC":
     1. Every arithmetic transition has a uniform implementation, `arithRun`, defined in the Spec: one algorithm per primitive, independent of all parameters.
     2. It has the same result: `arithRun_correct` (non-headline, §F.4). It has the same coin consumption: `arithRun` takes no tape argument, so it reads no random bits, exactly like `evalBin`. The machine's `step` still uses `evalBin`, so its semantics are unchanged.
     3. Its complete live storage is at most the footprint plus `opWork` plus `ctrlWork`. `RunsWithinBits` charges all three at that very step, and `StreamExec` bounds them by `spaceBoundC` (conjunct 1 of `Theorem_C`).
     4. So the printed bound `2^512 ε⁻² Λ^15` is proved directly for the complete charge, with no "up to a constant". §F.4 (iii) gives the explicit constants used in the proof.

     The non-arithmetic transitions fall under the first branch: their storage is the footprint plus `ctrlWork`.
   - **Proof obligation.** The proof bridges the big-step tree-space calculus to this machine:
     - `RunsOn S` implies that every configuration has at most `K(prog)·S + c(prog)` bits. Here `K(prog) = (D+1)(⌈log₂(|prog|+1)⌉ + 3D + 11)`, where `D` is the maximal body height.
     - In v2.1, each step's charge is then at most `50·(K(prog)·S + c(prog)) + 392`. This follows from `stepWork ≤ 8·confBits c + 64` and `ctrlWork ≤ 4·(footprint + stepWork) + 72` (§F.4).
     - The whole overhead is proved inside `spaceBoundC`. The paper's own accounting leaves ≈ 2^169 slack (spec checker C estimates ≈ 2^183), and the factor 50 is below 2^6.
   - The encoding is prefix-free on every configuration of a halting run. `fixedBits` truncation occurs only at positions that make the next step stuck.
2. **Uniformity** (unchanged from v1; round 1: ACCEPTABLE). There is one algorithm for all parameters, receiving only the encoded parameters. This is stronger than the literal "Fix n, m, U, ε, β. There exists …", and the paper's algorithm satisfies it.
3. **Memory.** The algorithm's entire memory between rounds is the state `Val`. Each round runs `updProg` on `[params, state, i, Δ]` and produces `[state', estimate]`. Every configuration of each run is charged, including input, temporaries, environments and the continuation stack. So the per-step charge `≤ S` (the configurations, the workspace and the control temporaries) bounds the memory "at every point during rounds 1..m". The initialization run is also bounded (stronger than the paper; round 1: ACCEPTABLE).
4. **Randomness** (unchanged; round 1: ACCEPTABLE).
   - Each program run gets its own fresh tape of `tapeLen P` uniform bits. Bits are consumed sequentially, one per `coin` step; unread bits are not charged.
   - Reading past the end makes the run stuck, which conjunct 1 forbids on every execution, so `tapeLen` is unobservable.
5. **Adversary** (unchanged). Deterministic strategies map the list of previous estimates to the next update. Randomized adversaries use any coin probability space, with per-history measurability, and are independent of the tapes.
6. **Box promise** (unchanged). Both conjuncts are required up to the first violation (`BoxUpTo`).
7. **Estimates** (unchanged). Output `[a, d]` with `a ≥ 0`, `d > 0`; anything else fails to parse.
8. **Relational execution.** `StreamExec` asserts the existence of states/estimates produced by the runs. The machine is deterministic, and `BoxUpTo t` depends only on `outs 0..t−1`, so these are unique up to the first violation. The project proves this (C-TOP `streamExec_unique`; §F).
9. **Junk check.** `Λ`'s argument is `> 2^100 · 27 · 100`, so `Λ > 100`. Also `ε⁻¹ > 10`, `dyadicExp ≥ 4` on `(0,1/10)`, and `Fin n` is nonempty. A zero-length random tape permits deterministic algorithms. Such an algorithm can be accurate on some parameter families; for example, when n = 1, maintaining the scalar coordinate gives exact F2. This does not establish a deterministic solution to the complete universal headline with its space bound. Deterministic algorithms are not intrinsically inaccurate.

### C.4 Not claimed
- No update-time bound (none is claimed by the paper).
- R:thm:main's strict-model rules 2–3 (scope box). These are proved as non-headline lemmas (§F).
- Rules 1 and 4 of Def R:def:streaming-model ARE modeled by `Theorem_C`:
  - rule 1 (adversary information, independent coins) by `StreamAdversary` and clause 2;
  - rule 4 (complete bit accounting) by `confBits` / `RunsWithinBits` and clause 1.

## D. Non-vacuity checks in the Spec (18 proved `example`s in the v2.2c prefix, by `rfl` / `decide`; v2.1 adds one; v3.1 adds 22 `example`s and 23 proved `theorem`s, see "Spec v3.1.1 additions")
- **v1 cost-model examples:** `x ↦ x+1` maps 2 to 3 (cost 8, peak 11); `x ↦ x+coin` reads one bit; `coin` on the empty tape fails; a `RunsOn` witness; estimate parsing (`[3,2]` ↦ 3/2; zero denominator fails).
- **Machine (C1):**
  - `x ↦ x+1` halts with 3 after 5 steps;
  - `x ↦ x+coin` consumes one bit;
  - `bitEncodeVal 3` has 7 bits;
  - the start configuration has 13 bits;
  - `RunsWithinBits … 150` holds, so the predicate is satisfiable:
    - the footprints are 45, 57, 55, 51, 30;
    - only the last step is arithmetic (`2 + 1`, workspace 19);
    - `ctrlWork` is 88 at every step;
    - the charges are 133, 145, 143, 139, 137;
  - `opWork add 2 1 = 19`: the adder's four states, with the two signs, have 19, 17, 17, 19 bits (v2.1);
  - `coin` on the empty tape is stuck.
- **Sampler (§2.4):**
  - MSB-first `readBits`;
  - Bernoulli-1/2 and rejected Bernoulli-1/3 coins;
  - one lattice draw with `ϱ = 1/2`, `K = 2`;
  - reading past the tape fails.

## E. Audit history
- v0/v1 pre-audit (lead-commissioned read-only checkers): (A) faithful; (B) MINOR, fixed; (C) faithful with doc fixes.
- Audit round 1 (run by a8ff0e4e) on v1 `6a5254ff…`: **NOT FAITHFUL** on (A), (B) and (C), with 7 MAJOR (M1–M7) and 7 MINOR (m1–m7) findings. Report: internal (not part of this record).
- Integrator decisions (07:27Z and 07:31Z): the v2 common core (M3/M4/M5 + docstrings); (C) with R3 (certified bits); R4-0 (rules 2–3 non-headline); A_eff/B_space as additive v3 drafts only (superseded at 12:50Z: the user requires a
  full end-to-end proof, so both became v3 headlines).
- Internal pre-review of the v2 candidate (lead-commissioned read-only checkers, 07:52–08:03Z):
  - (A) FAITHFUL, 4 doc fixes;
  - (B) FAITHFUL, 2 doc fixes;
  - (C) FAITHFUL, one WEAKER-MINOR point (workspace of atomic steps), resolved by the footprint form of `RunsWithinBits`, plus doc fixes.
  All fixes are applied in sha256 `cc04b02b…`.
- Proof-side alignment: A-ARCH and B-ARCH compared the pinned mechanisms line by line with the project's mechanism code. Control flow, draw order and sampler bits are identical; the representation differences are bridged in the proof (coin-level map for the Stage-1 Beta noise; grid-index encoding `k ↦ h_A·k`; argmin/argmax = water-filling by uniqueness).
- Audit round 2 (check 1, check 2, consolidation) on v2 `cc04b02b…`:
  - (A) and (B) FAITHFUL WITH MINOR;
  - (C) UNDETERMINED on U-C;
  - V6 accepted.
  Reports: internal (not part of this record).
- v2.1 (this file) fixes U-C by explicit accounting (Spec §3.2), and also dA, dB, dC1, dC2 and N3.
  - The consolidation's other options were not taken. (i) Proving that the footprint alone suffices was not attempted: the footprint bounds the workspace only up to a constant factor. (ii) A fully charged binary-transition model would need a verified compiler from the DSL to a binary machine (estimated 30–50K lines).
  - Lead checks: the code-only diff (+101/−3), `lean1` EXIT 0, and the spec-rule scan. The only directives are `import Mathlib` and `open MeasureTheory`, as in v2.
  - The non-headline lemmas of §F.4 are proved.
  - Internal read-only check of the delta by spec checker C (on `519a5632…`): **FAITHFUL**, with no WRONG, STRONGER or WEAKER findings.
    - It checked the implication point by point; every transition (none uncovered); the junk values (ill-typed operands, division by zero and `cons` are stuck or uncharged exactly where `evalBin` fails); the fuel claim at all 8 call sites; that the trace states are complete; and the operand order of `stepWork` against `step`.
    - Its trivial docstring fixes were applied in `9aeafbeb…` (code byte-identical to `519a5632…`): "v2 or v2.1" in the non-claim, the §F references, the footer, "§3.1 and §3.2 are new", and the lemma names `arithRun_correct`/`opWork_le` in §3.1/§3.2. It also corrected a pre-existing v2 inaccuracy in `alg2Interval`'s docstring: when `alg2Reject`'s new threshold draw fails, the response is the rejection certificate (rejection counted), not the dummy `ACCEPT`.
- Focused (C) check of v2.1 (`9aeafbeb…`; within the approved audit budget): (C) **FAITHFUL WITH MINOR ISSUES**.
  - U-C is resolved; the check reproduced the 2^63·2^63 step charged 530 + 400 + 104 = 1034 bits.
  - The arithmetic algorithms are verified correct, consume no coins, and introduce no new loophole or vacuity.
  - One documentation fix, dR, applied in v2.2 (`ae054eb6…`): F-dR verbatim. Code tokens are identical to v2.1.
  - v2.2b (`a34af531…`) also updates the title and footer labels only (integrator, 10:03Z).
  - Report: internal (not part of this record).

- Spec v3: internal read-only checkers A (§6), B (§7) and C (coverage), ≈13:30Z, on the candidate before
  the parametrization: all FAITHFUL WITH MINOR; fixes applied (docstrings; `ReproducesFor`; `Theorem_B_joint`).
  Then one Spec parametrized by the bit budget's constant (≈13:40Z); candidate `9dd5490e…` sent to the statement
  audit. Its check 2 raised three MAJORs: F-A (§6: one fixed program, rational literals, public input), F-B1 (§7:
  off-sample evaluation) and F-B2 (§7: history-free state). All three are fixed in v3.1 (user decision, 14:42Z),
  candidate `2f4f3c09…`. v3.1 statement audit on `2f4f3c09…`; main carries this commit only after the
  integrator's sign-off on a FAITHFUL verdict. Candidate cut 2026-10-25T17:06Z, sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`, a delta from `2f4f3c09…`
  confined to the appended part: the code fix F1 (retained state `alg2Retained`, v3.1 audit check 2) and
  documentation minors (red-team phase-1 m1, m2, m4; two §6 documentation minors).

## F. Additional properties (non-headline; proved in the project; listed for the auditors)
1. **Strict-model rules 2–3 for the constructed (C) algorithm.**
   - File: `F2e2e/C/Alg/StrictModel.lean`. All statements are proved (0 sorry of its own; 17fc0802, 09:37Z); (a3) is stated on `RoundReach` with an abstract ADA encoding bounded by `hada`.
   - The lemmas are stated on the controller code `roundCode` of the algorithm's AlgM presentation, for every sequence of primitive calls along every path of oracle responses. So they cover every execution of the mathematical algorithm `theAlg` (`algStep_eq_interp`), which the DSL implementation provably simulates (`Impl`).
   - (a) Rule 2, L41, "processed online in a single forward pass and are never altered, buffered in full, or replayed":
     - `roundCode_single_pass`: at most one fingerprint step and at most one physical row update per round, both with the round's own update.
     - `RowOp.apply_seed`: rows keep their seeds. Every row operation is a linear rounded update, or a homogeneous rescale by a grid scalar, or the client reset (see (d)).
     - `strict_no_full_buffer`: memory between updates is at most `stateSizeBound P`, independent of the round and of the update values.
   - (b) Rule 3, L42, "persist across the correction via homogeneous scalar rescaling without ever being restarted, re-allocated, reset in-place":
     - `roundCode_no_alloc_after_update`: after the fingerprint step, no bank birth, retirement or reset happens.
     - `rejectDepthCode_calls`: a correction at depth d makes exactly the PRIMARY release, the scaleY / scaleXY rescalings by one grid scalar in [1/2, 3/2], and the DIFF release.
     - `rejectTailCode_descendants`: every descendant learner changes only by `Learner.rescale`.
   - (c) L42, "allocated exclusively at predetermined, data-independent physical time boundaries along a fixed binary interval tree … where the outgoing vector is identically zero":
     - `roundCode_births`: the births of round t are a prefix of a list that is a function of (P, t) only, and precede the update.
     - `newBank_zero`: every row of a newborn bank has X = Y = 0.
   - (d) L42, "expired nodes are retired before replacements are initialized": `roundCode_retire_first`.
     - `roundCode_resetY`: resets happen only at client births (Def 5.1(4) L438; Alg 4 L475), never in a correction. That is a new lifetime after retirement, not an in-place reset of a live learner.
2. **Bridge from the big-step DSL to the bit machine.** `runsWithinBits_of_runsOn : RunsOn prog input tape out S → (every configuration ≤ bitsFactor prog · S + bitsConst prog bits)`, with `bitsFactor prog = (D+1)(⌈log₂(|prog|+1)⌉ + 3D + 11)`. This is proved, 0 sorry, in `F2e2e/Cost/MachineBridge.lean`. The footprint corollary `runsWithinBitsFP_of_runsOn` (factor 2) is also proved there. The v2.1 charge (footprint + `stepWork` + `ctrlWork`) is covered by §F.4 (iii).
3. **Determinism** (round 1: N3):
   - fuel monotonicity / determinism / tape-frame lemmas for `eval` (`F2e2e/Cost/Facts.lean`, proved);
   - uniqueness of `StreamExec` executions up to the first violation (`F2e2e/C/Top/Sanity.lean`, `streamExec_unique`, proved).
4. **Arithmetic workspace of v2.1 (U-C).** All proved, 0 sorry; `#print axioms` ⊆ {propext, Classical.choice, Quot.sound}.
   - Files: `F2e2e/Cost/{ArithDefs, ArithCore, ArithOps, ArithDiv, ArithBounds, ArithWork, MachineWork}.lean`, ≈ 1720 lines.
   - `ArithDefs.lean` is the v2.1 §3.2 block byte for byte (block sha256 `7a531f03…`, re-copied 09:37Z), in the namespace `F2e2e.Machine` until the lock. v2.2 changes only that block's `regBits` docstring (dR); the code is identical.
   - Statement list: `notes/spec_v2_1_draft/ArithWork.md`.
   - (i) Same result: `arithRun_correct (hop : op ≠ cons) (a b) (hdiv : op = div ∨ op = mod → b ≠ 0) : some (arithRun op a b).1 = (evalBin op (Val.int a) (Val.int b)).map Prod.fst`. It is assembled from the per-operation lemmas `arithRun_add/sub/mul/lt/eq/div/mod`.
   - No coins: `arithRun : BinOp → ℤ → ℤ → Val × List (List (List Bool))` has no tape argument (by definition).
   - (ii) Workspace:
     - `regBits_le_opWork`: every state of the run is charged;
     - `opWork_le : opWork op va vb ≤ 8·(|bitEncodeVal va| + |bitEncodeVal vb|) + 64`.
     Per operation, with `la`, `lb` the magnitudes' bit lengths: add/sub ≤ 6(la+lb)+17; mul ≤ 8(la+lb)+18; div/mod ≤ 12(la+lb)+27; lt ≤ 4(la+lb)+13; eq ≤ 2(la+lb)+12.
   - (iii) Bridge:
     - `stepWork_le : stepWork prog c ≤ 8·confBits prog c + 64`;
     - `ctrlWork_le : ctrlWork prog c c' ≤ 4·(confBits c + confBits c' + stepWork c) + 72`;
     - `runsWithinBitsW_of_runsOn : RunsOn prog input tape out S → RunsWithinBitsW prog input tape out (50·(bitsFactor prog · S + bitsConst prog) + 392)`. Until the lock, `RunsWithinBitsW` is the v2.1 `RunsWithinBits` verbatim;
     - `RunsWithinBitsW.mono`.
   - The (C) proof combines (iii) with C-SPACE's space chain (`F2e2e/C/SpaceChain.lean`), whose slack (≈ 2^167 against the ≈ 2^109 needed) absorbs the factor 50.


---

# Spec v3.1.1 additions (locked 2026-10-25T17:06Z, sha 7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523)

> Lock note: the paths `notes/spec_v31/…` below are those of the Spec source. `F2e2e/Spec.lean` is a
> byte-identical copy of `notes/spec_v31/SpecV31.lean` (sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`). The "Checks of the assembled
> files" at the end are the checks of the source; the closing evidence (`evidence/<candidate rev>/`, produced on
> this exact commit; see the kit README) supersedes them.

## STATEMENT_REVIEW — Spec v3 section (§6 A_eff, §7 B_space, §8 Theorem_B_joint and Theorem_main_full)

Spec v3.1 candidate: `notes/spec_v31/SpecV31.lean` (3787 lines, sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`; FA on, B1 on, B2 on, F1 on, DOCS311 on). It is one file, in which the constant
of (B)'s bit budget is a parameter (§7.5).
* It is the locked `F2e2e/Spec.lean` v2.2c (sha256 `c28be50e…`), as a byte-identical prefix, followed by the fragments
  `notes/spec_v31/parts/{S0_V3Header,S6_AEff,S7_BSpace,S8_Main}.lean`, assembled by `notes/spec_v31/make_v31.py`.
* v3.1 = v3 (candidate `9dd5490e…`) plus the statement-audit fixes F-A (§6), F-B1 and F-B2 (§7, §8). Each is behind
  a flag and is described in `notes/spec_v31/V3_TO_V31.md`.
* This file reviews only the appended sections; the v2.2c parts are reviewed in `STATEMENT_REVIEW.md`.
* §6 is by b5a655d4 (included verbatim below); §7, §8 and the assembly are by 1c1a75fe.

Plain-math reading of the v3 claim: `Theorem_main_full := Theorem_A_statistical ∧ Theorem_A_eff ∧
Theorem_B_statistical ∧ Theorem_B_space ∧ Theorem_B_joint ∧ Theorem_C`, with the paper's constants.
* `Theorem_A_eff` and `Theorem_B_space` are exactly the clauses that v2.2c lists as non-claims (e2e.tex L150 for
  (A), L155 for (B)).
* `Theorem_B_joint` states both (B) claims for the same tape lengths (§8).
* A second stated target, `Theorem_main_full_2e128`, is the same with the bit budget's constant `2^128` instead of
  `2^30` (§7.5, §8.3).

The v2.2c docstrings that say "does NOT claim" remain true of `Theorem_A_statistical` / `Theorem_B_statistical`
themselves. The v3 header (S0) says this explicitly.

---

<!-- §6: verbatim from notes/spec_v3/parts/STATEMENT_REVIEW_v3_S6.md (b5a655d4) -->

## §6 A_eff — statement review (plain math), Spec v3.1

Spec v3.1, §6 (`notes/spec_v31/parts/S6_AEff.lean`, appended after the locked v2.2c prefix).
Headline: `F2e2e.Theorem_A_eff`. Everything else in §6 is in the sub-namespace `F2e2e.AEff`.
Author: b5a655d4. The v3 draft (`notes/spec_v3_draft/AEff.lean`, `AEFF_DESIGN.md`) builds on c186bcb5's notes.
v3.1 applies fix F-A (uniform program, public input, rational constants); the change log is `V3_TO_V31_S6.md`.

### 6.0 What the paper claims

* e2e.tex L150, statement of (A): the mechanism runs in `O(kn)` arithmetic operations and `O(n)` working space in
  the real-arithmetic (oracle) model of Proposition I:prop:runtime.
* partI.tex L34, end of Theorem I.1.1: the same claim, phrased as `O(kn)` total arithmetic operations and `O(n)`
  working space.
* partI.tex L499–503, Proposition I.1.12, defines the model:
  * `O(1)`-time oracle evaluation of `q_i(x)` at the sample points;
  * `O(1)`-time sampling from the uniform, Laplace and Beta distributions;
  * unit-cost real arithmetic and elementary functions, with no finite-bit-complexity claim.

  Under this model it claims `O(kn)` total time, with at most `O(n)` operations per round, and `O(n)` working
  space. The space count excludes the streamed public transcript and the analyst's representations of the queries.
* partI.tex L505–507, the proof:
  * the means cost `O(n_r)` per stage, and each stage is evaluated at most once per round;
  * plus the water-filling projections of the updated levels, each in `O(n_r)` (Lemma I:lem:kkt_sensitivity(1)):
    one (on `S_1`) in Case A, at most two (on `S_{r*−1}` and `S_{r*}`) in Case B. The formal cascade
    (`adaActiveRound`) recomputes exactly the levels `{1}` in Case A and `{r*−1, r*} ∩ {2, …, L−1}` in Case B;
  * the mechanism stores the subsamples, one weight vector and one payoff vector per level, and `O(L)` scalars.

The docstrings of §6 quote all four passages verbatim (LaTeX source). The paper's mechanism is one algorithm,
parametrized by `(k, α, β)`; the formal statement now has the same shape (§6.2 item 9).

### 6.1 The headline in plain math

There are a constant `C ∈ ℕ` and **one** real-RAM program `P` whose constants are all rational (`P.RatLits`),
both chosen before any parameter, with the following property. Take any `k ≥ 1`, `α ∈ (0, 1/16)` and
`β ∈ (0, 1/2)` (the ranges of `Theorem_A_statistical`), and write `L = adaL α` and `n = adaSampleSize k α β`. For
every sequence of query values on the sample, `qv : ℕ → (Fin n → ℝ)`, and every realization
`ω : ADANoiseIndex k L → ℝ` of the locked cascade's coin table, the run of `P` on the public input
`adaInput k α β` (§6.2 item 10) satisfies:

* an initialization phase runs (without oracles) from the memory holding the input, emits nothing, and uses at
  most `C·n` unit operations;
* then rounds `i = 0, …, k−1` run, each with round `i`'s oracles (§6.2), each with at most `C·n` unit operations;
* in every round `i < k` the output stream equals the public output `(a_i, τ_aux,i)` of the locked cascade
  `adaCascade k α β` on the query values of rounds `0..i` and the coins `ω`, in the fixed streaming format (§6.2);
* the workspace of the whole run, input cells read included, is at most `C·n`.

The total number of operations is then at most `(k+1)·C·n ≤ 2C·kn`. This is the proved lemma
`AEff.RamProgram.RunsWithin.total_ops_le`.

`Theorem_main_full` (§8) conjoins `Theorem_A_statistical ∧ Theorem_A_eff`. Both are about the same mechanism,
`adaCascade k α β`, with the same coin table `ω` (law `adaCoinLaw k α β`).

### 6.2 The model, item by item (each item is a modelling choice)

1. **Real RAM.**
   * The memory is `ℕ → ℝ`, with exact reals. A run on the input `x₀, …, x_{m−1}` starts with `M[j] = x_j` for
     `j < m` and `M[j] = 0` otherwise (`RamConf.ofInput`).
   * Expressions: constants, indirect reads `M[a]`, `+ − × ÷`, `exp`, `log`, the query oracle and the noise
     oracle. The syntax admits real constants (`lit : ℝ → RamExp`); the headline admits only programs whose
     constants are all rational (`RamProgram.RatLits`).
   * Conditions: `< ≤ =` and `¬ ∧ ∨`.
   * Statements: `nop`, `M[a] := e`, `emit e`, sequencing, `if`, `while`, and calls of numbered parameterless
     procedures (global memory, recursion allowed).
2. **Semantics.**
   * A big-step relation `RamExec procs O s σ σ'`, proved deterministic (`RamExec.det`).
   * A run that hits a non-natural address or oracle index is stuck: it has no derivation, so `RunsWithin` fails.
3. **Cost.**
   * Sequencing itself is free.
   * Every other executed statement costs `1` plus the number of nodes of the expressions and conditions it
     evaluates: `nop`, an assignment, an output, the test of a conditional or of one loop iteration, a call. So
     `seq nop nop` costs `2`, and a call costs `1`.
   * All of these are unit operations, which upper-bounds the paper's "arithmetic operations".
4. **Workspace.**
   * `top` is `1 +` the largest address ever read or written. This is a watermark, which is stronger than
     counting live cells. It starts at `0`; an input cell counts once it is read, like any other cell.
   * `peak` is the largest call depth; it charges the implicit return stack.
   * The workspace is `top + peak`. The output stream and the oracles are not counted, which is exactly the
     paper's exclusion.
5. **Phases.**
   * The control restarts at the top of `P.round` in every round.
   * Only the memory (and the watermarks) persist between phases.
   * The output stream and the per-phase counter reset every round.
   * `init` runs once, before the first round, without oracles, from the input memory.
6. **Query oracle of round `i`.** It returns `qv i ℓ` for `ℓ < n` and `0` otherwise. One call costs `O(1)`. The
   program cannot see other rounds' queries. The sample points stay inside the oracle, which is the paper's
   "oracle evaluation of `q_i(x)` at any sample point".
7. **Noise oracle of round `i`.** Four families:
   * family 0 gives `ξ_i`, family 1 gives `ν_i^{(a)}`, family 2 gives `ζ_i^{(a)}`;
   * family 3 gives `ρ^{(a)}_b` for `b ≤ i`;
   * everything else returns `0`.

   One call is one `O(1)` "sample": the coin table `ω` is drawn from `adaCoinLaw`, a product of the scaled Beta
   law of `ξ_i` and Laplace laws (Prop I.1.12 also allows uniform sampling, which the cascade does not use).
   * The program cannot read the per-round noise (`ξ`, `ν`, `ζ`) of any other round.
   * Family 3 contains what round `i` of the cascade reads, since `M_a − 1 ≤ i`. It also exposes the threshold
     noise of episodes `b ≤ i` that may not have started, and every entry may be read again (replay).
   * **The relevant-table cache argument: the table oracle is equivalent to fresh sampling up to constants.**
     * The *relevant table* consists of the per-round noises `ξ_j, ν_j^{(a)}, ζ_j^{(a)}` (round `j`'s oracle shows
       only round `j`'s, `2L + 3` entries) and the thresholds `ρ^{(a)}_b` of the episodes that can occur:
       `b < M_{a,max}` for `2 ≤ a ≤ L` and `b = 0` for `a ≤ 1`. The episode counter `M_a` never exceeds
       `M_{a,max}` because of the caps `T_{1,max}`, `N_{r*,max}` that set `HALT`, so the cascade reads only relevant
       entries.
     * There are at most `(L + 1)·M_{2,max} ≤ 29 L⁵/α² + (L + 1)(L + 2)` relevant thresholds. Meanwhile
       `n ≥ n_L ≥ 10⁸ L⁵/α²`, from `M_{L,max} ≥ 20 L³` and `ln(1/δ_val) ≥ 3L`. So the relevant table has `O(n)`
       entries.
     * **Replay.** A program of the fresh-sampling model of Prop I.1.12 simulates the oracle on the relevant
       table: it draws each entry from its law at its first read and caches it. The per-round entries are
       dropped at the end of the round. This costs `O(1)` time per read and `O(n)` cells, and it gives the same
       joint law. So re-reading changes the bounds by at most a constant factor.
     * **Exposure.** A solution of the headline is correct, within its bounds, for every table `ω`. Answering its
       reads outside the relevant table by `0` is exactly its run on the table `ω'` that agrees with `ω` on the
       relevant table and is `0` elsewhere. The cascade has the same outputs on `ω'`. So the program with these
       reads answered by `0` is again a solution, with an `O(1)` test per read against the `O(L)` caps.
     * Together: a solution of the headline yields a fresh-sampling program with the same outputs, `O(kn)` time
       and `O(n)` workspace, which is the claim of Prop I.1.12. (That the conformance relation pins every output
       does not by itself justify replay; this argument does.)
8. **Output format.**
   * Per round, the program streams `a_i` followed by the `6L − 3` fields of `τ_aux,i` that can be nonzero:
     `active`, `c1`, then per stage `r = 2..L` the fields `b, uPrev, released, v, c`, then `s`, then
     `delta m` for `m = 2..L−1`, then `haltAfter`.
   * `ADAOutputStreamed` also requires every other field of `τ_aux,i` to be `0`.
   * The relation is lossless (`ADAOutputStreamed.unique`).
   * The cascade's own outputs satisfy it (`adaCascade_streamed`, using `adaCascade_supported`).
9. **Uniformity (fix F-A).**
   * `∃ C, ∃ P` come before `∀ k α β`. One fixed program serves all parameters: a uniform algorithm, as the
     paper's mechanism is.
   * **Rational constants only.** A fixed real constant could encode advice, e.g. in its digits, data that no
     algorithm computes; the real RAM can read such digits by doubling and comparing. A fixed rational constant
     is a finite piece of the program text.
   * The program text has constant size. So no size bound is stated (`RamProgram.size` is defined but not
     constrained), and the uncharged temporaries of a single expression evaluation are `O(1)`.
   * The parameters reach the program only through its public input (item 10), which the Spec defines. The
     program cannot choose it.
10. **The public input `adaInput k α β`.** It mirrors (C), whose algorithm receives `mkStreamParams`.
    * **Content.** These are exactly the locked parameters that the cascade reads (§1.1, §1.3):
      * the header: `k, α, β, n, L, α/2, γ = adaGamma α, η = adaEta α, η₁ = adaEta1 α, T_{1,max} = adaT1max α`;
      * per stage `r = 0, …, L+1`, the record: `n_r = adaBlock`, the block offset `adaOffset`,
        `N_{r,max} = adaNmax α r` and `η̃_r = adaEtaTilde α r`.
    * The thresholds `τ(u,r)` are computed from `α/2` and `γ`, and the caps `2/n_r` and initial weights `1/n_r`
      from `n_r`. The noise-law parameters are not needed, since the noise comes from the oracle.
    * **Layout** (presentation convention; the zeros carry no information): cells `0…9` hold the header and cells
      `10…63` are `0`. Cell `64 + 16r + j` holds field `j` of stage `r`'s record for `j < 4` and is `0` for
      `4 ≤ j < 16`. The length is `64 + 16(L+2) = 16L + 96 = O(L)`.
    * The padding gives the program's own variables fixed addresses that do not depend on `L`.
    * The address map is proved: `adaInput_mem_header`, `adaInput_mem_record`, `adaInput_mem_free`.
    * **Not a loophole.** Every entry is a Spec-defined function of `(k, α, β)`. That includes the records of
      stages `0` and `L+1`, which take the values of these Spec functions there. In principle, the RAM could
      compute every entry from `(k, α, β)` in `O(L log n)` operations: `⌈x⌉` greedily in `O(log x)` comparisons,
      powers and roots by `exp`/`log`. The input is supplied for simplicity, as in (C).
11. **Strength relative to the paper.**
    * The conformance holds for every `ω`, which is stronger than almost surely.
    * The query values are arbitrary reals, not only `[0, 1]`.
    * The per-round bound is worst case.
    * Adaptivity is covered by the open-loop quantification over `qv`: round `i`'s computation sees only round
      `i`'s oracle and the memory.

### 6.3 Junk values and loophole review

* **Total `÷` and `log`.** Lean has `x/0 = 0` and `log x = log|x|`. A guarded version costs `O(1)` more, so
  totality adds no power.
* **`ramNat`.** An address must be a real that is exactly a natural number; otherwise the run is stuck, so it can
  only hurt the program. Every address used raises `top`, which is counted.
* **No floor, mod or bit operations.** This is the honest BSS-style real RAM; the integer RAM with floor is known
  to be unrealistically strong.
  * The real RAM can still extract the binary digits of a constant by doubling and comparing, at `O(1)` per digit.
  * Since v3.1 this is not an advice channel. `P` is fixed before all parameters and its constants are rational,
    so they hold finitely much data, the same for every `(k, α, β)`.
* **Packing several reals into one cell does not help.**
  * The outputs must equal the exact real-valued cascade outputs for all real query values.
  * Computations with `+ − × ÷ exp log` and finitely many branches are piecewise analytic, so no injective
    encoding of two arbitrary reals into one exists.
  * So the workspace counts real numbers, as the paper's `O(n)` working memory does: it stores `O(n)` reals, one
    weight vector and one payoff vector per level plus `O(L)` scalars. §6 claims only this upper bound; it
    asserts no `Θ(n)` lower bound.
* **Hidden state.** The control restarts every round. The output stream is write-only. `ops`, `top` and `depth`
  are not readable.
* **Precomputation.**
  * `P` is fixed before `qv` and `ω`, and before `(k, α, β)`.
  * The input is Spec-defined and contains only locked parameters.
* **Junk values inside the locked cascade.**
  * `entropicArgmin` is a choice. It equals the unique minimizer because blocks have `n_r ≥ 1` and the step sizes
    are positive; the project's `Opt.eq_waterFill_of_isMinOn` covers this. So it is the computable water-filling
    vector.
  * The out-of-range defaults (`adaQAt`'s `0`, the noise reads off the table) are never used for `i < k`.
* **Not vacuous.**
  * The semantics and `RunsWithin` are satisfiable. The examples in §6.3 of the Spec show this: three runs, one of
    them a program that reads its input, plus a proof that this program satisfies `RatLits`.
  * Every round's specification is met by exactly one stream, the cascade's own.
  * The intended program (AEFF_DESIGN.md §7, made uniform as AEffU) has the following parts:
    * means in `O(n)`;
    * the AboveThreshold chain in `O(L)`;
    * the exact water-filling projections of the updated levels, one in Case A and at most two in Case B, each
      in `O(n_r)`, by median-of-medians selection and an exact normalization;
    * `O(n)` cells.
* **Not trivially true.** The stream must equal the exact cascade output for every real input. That includes:
  * the exact means;
  * the exact chain decisions;
  * the exact entropic projections, which need `exp`.

### 6.4 Alternatives considered (rejected)

* **A program per parameter triple with text size `≤ C·L` (v3).** Rejected by the audit (fix F-A): its real
  literals could carry parameter-dependent advice.
* **Typing the literals as `ℚ` (`lit : ℚ → RamExp`).** Same content as `RatLits`.
  * It would invalidate every evaluation lemma of the A_eff toolkit (about 15K lines). The predicate leaves the
    toolkit valid.
  * Kept as the alternative fragment `parts/S6_AEff_litQ.lean`, which also compiles.
* **A packed input at `0, 1, 2, …`.** It occupies an `L`-dependent prefix of the memory, so every variable of a
  fixed program would sit at a runtime-computed address. The padded layout has the same content.
* **An input holding only `(k, α, β)`.** The RAM would compute the other parameters itself (item 10). Same
  content, much more proof work.
* **Reuse the locked small-step machine (§3) for (A).** Its values are integers and lists. The paper's (A) claim
  is about a real-arithmetic model ("we make no finite-bit-complexity claim"), so a real RAM is needed. (B)'s
  bit-space clause, by contrast, reuses the locked machine in §7.
* **Total-only `O(kn)`.** Weaker than Proposition I.1.12, and the total follows here as a proved corollary.
* **Fresh sampling oracle instead of the coin table.** It would decouple (A_eff) from the coin space of
  `Theorem_A_statistical`. With the table, both headlines are about the same mechanism with the same coins.
* **Selection or sorting as a primitive.** Weakens the model; the `O(n_r)` water-filling must be programmed.
* **A small-step or fuel semantics.** The big-step relation is the textbook form; with determinism proved it
  pins the run uniquely.

### 6.5 What §6 does not claim

* Any finite-bit complexity, as the paper says.
* The analyst's cost.
* Drawing the sample: the sample points live inside the query oracle. Adding `n` cells to store them would not
  change the bound.
* Re-reading noise: the noise oracle may be asked again for a variable already read, at `O(1)` per call.
  Compared with fresh sampling this saves at most the cache of the relevant table, `O(n)` cells (§6.2 item 7),
  so it does not change the bounds.
* An explicit bound on the program size: the program is fixed, so its size is a constant.
* Universes: all quantified types live in `Type`, as in v2.2c.
* The `k`-independent absorbed sample form: it is not part of the computational clause.

---

## §7 B_space — statement review (plain math)

Spec v3, §7 (`notes/spec_v3/parts/S7_BSpace.lean`). Headline: `F2e2e.Theorem_B_space`. Everything else is in the
sub-namespace `F2e2e.BSpace`. Built on the design and draft of b5a655d4 (`notes/spec_v3_draft/BSpace.lean`,
`BSPACE_DESIGN.md`). Changed for v3:
* it reuses the locked machine instead of a copy;
* it uses the locked per-step charge;
* it refers to the locked Algorithm 2 instead of a copy;
* it bounds the tape length from below instead of adding a coin sentinel;
* the bit budget `bSpaceBound e` is parametrized by its exponent `e`; the headline uses the paper's `e = 30`
  (§7.5);
* the reproduction property for one tape length is the definition `BSpace.ReproducesFor` (the former body of the
  headline, unchanged; an `Iff.rfl` example in the Spec checks the unfolded form), so that §8's `Theorem_B_joint`
  can reuse it.

Changed for v3.1 (statement audit; `V3_TO_V31.md`):
* **F-B1, off-sample evaluation**: the round oracle is ANY oracle consistent with the sample (`BSpace.OracleFor`);
  see item 3 of §7.2.
* **F-B2, history-free state**: between requests, the implementation's memory is `enc` of Algorithm 2's current state
  (`BSpace.VImplRun`, `BSpace.alg2StateAt`); see item 13 of §7.2.

### 7.0 What the paper claims

* e2e.tex L155 (statement of (B)): "… if records use `b_𝒰` bits, at most `2^{30}N(b_𝒰 + χ²)` bits plus the working
  space of its evaluation oracle; its randomness consists of fresh independent fair bits drawn by bounded samplers."
* partII.tex L966–970 (Theorem R:thm:validation_ada): "If records use `b_𝒰` bits, the mechanism uses at most
  `2^{30}N(b_𝒰 + χ²)` bits, plus the working space of its evaluation oracle. It stores only current evaluations, not
  old queries."
* The Spec docstring quotes both passages verbatim (LaTeX source).

### 7.1 The headline in plain math

There is ONE implementation, a pair of programs `(initProg, roundProg)` of the locked DSL (`Expr`), with the
following property. Take any caps `M, J, R ∈ ℕ` and any `a_req ∈ (0, 1/10)`, `ξ_req ∈ (0, 1/2)` (the ranges of
`Theorem_B_statistical`). Then there is a tape-length bound `c_B ∈ ℕ`, depending only on these public parameters,
such that the following holds. Take any tape length `c ≥ c_B`, any finite domain `𝒰`, any `b_𝒰` with an injective
record code `code : 𝒰 → [0, 2^{b_𝒰})`, any sample `s ∈ 𝒰^N` (`N = (alg2Params M J R a_req ξ_req).N = ∑_j n_j`), any
fair-bit block `ω ∈ {0,1}^c`, and any sequence of valid requests `(f_t, kind_t, l_t, u_t)_{t∈ℕ}` (`f_t : 𝒰 → [0,1]`,
and `l_t ≤ u_t` for interval requests). Then there are states `state_t` and tape remainders `tape_t` such that:

1. `initProg` on `[params, [code(X_0), …, code(X_{N−1})]]` halts with `state_0`, starting from the tape `ω` and
   leaving `tape_0`. Here `params = [M, J, R, ⌈log₂ a_req⁻¹⌉, ⌈log₂ ξ_req⁻¹⌉]`, and the oracle answers `0`.
2. For every round `t ∈ ℕ`, `roundProg` on `[params, state_t, kind_t]`, with ANY oracle consistent with the sample for
   request `t` (§7.2 item 3), halts with `[state_{t+1}, respV_t]`, starting from `tape_t` and leaving `tape_{t+1}`.
   (The oracles are quantified universally, after the requests; the states may depend on them.)
3. Every step of every one of these runs is charged at most `2^30 · N · (b_𝒰 + χ²)` bits (`bSpaceBound 30 N b_𝒰 χ`),
   with `χ = valChi M J R (dyadicDown a_req) (dyadicDown ξ_req)`. The charge of a step is the footprint (`confBits`
   of the configurations before and after it), plus the arithmetic workspace `stepWork`, plus the control
   temporaries `ctrlWork`, exactly as in (C). The Spec states the clause for every exponent `e`
   (`BSpace.Theorem_B_space_with e`); the headline is `e = 30`. See §7.5.
4. `respV_t` parses to `alg2Mech M J R a_req ξ_req c t (views of rounds 0..t) ω`, the response of the pinned
   Algorithm 2 of §2 on the same views and the same fair bits.
5. > **History-freeness after F1.** For each sample there is an encoding `enc : Alg2State → Val`, chosen before coins, requests, and consistent oracles. Every actual boundary state satisfies  
   > `states t = enc (alg2RetainedOf M J R aReq ξReq c t (viewsBefore s reqs t) ω)`.  
   > The reference is the raw `alg2StateOf` fold projected by `alg2Retained`. It retains scores only for `j < p` and `i < n_j`, together with persistent correction counts, thresholds, request/rejection counters, and flags. Unused score coordinates are zeroed; unused `T` and `thrInt` coordinates are already zero on reachable states. The sample may be retained because `enc` is chosen after it. The encoding is not a runtime oracle, and every actual machine value remains charged.

**Joint reading with `Theorem_B_statistical`.** `Theorem_B_statistical` gives SOME tape length `c₀` for which
`alg2Mech … c₀` is accurate and never exhausts an internal cap (one `ξ_req`). That guarantee persists for every
`c ≥ c₀`.

Argument (a short project lemma). Fix everything except the tape, and let `ω'` be a tape of length `c` with prefix
`ω` of length `c₀`.
* An execution that tries to read PAST the end of the shorter tape sets the sticky abort flag. That is an internal
  failure if the execution has a covered round. If it has none, every request is over-cap and the execution on the
  longer tape has the same requests and dummy responses, so it fails on neither tape.
* Any other execution reads only bits of `ω`, so it is unchanged on `ω'`, response for response.

Hence failure on `ω'` implies failure on `ω`, and the failure probability over `{0,1}^c` is at most that over
`{0,1}^{c₀}`. Taking `c ≥ max(c₀, c_B)` gives one tape length for which the paper's mechanism is accurate and
implementable within the bit budget. §8's `Theorem_B_joint` states this directly in the Spec, for all long enough
tapes, so the link between the two tape lengths does not rest on this argument alone.

### 7.2 The model, item by item (each item is a modelling choice; alternatives in §7.4)

1. **Machine.** The locked small-step machine of §3.1 (`step`, `confBits`, `stepWork`, `ctrlWork`), with exactly one
   change, in `BSpace.stepO`:
   * at the return of the argument value to a `call oracleIdx a` node (reserved index `oracleIdx = 1000`, above the
     DSL index map 0–899, whose range 900–999 is reserved for glue), the argument must be `[sel, r, q]` (three
     integers), and the next configuration returns the integer `orc sel r q`;
   * any other argument is stuck.

   `stepNO` and `RunsWithinBitsO` are verbatim copies of `stepN` and `RunsWithinBits` with `stepO`. `RunsWithinBitsO`
   also exposes the unread tape `rest`, so the tape can be threaded into the next run. `coin` behaves as on the
   locked machine; in particular, it is stuck on the empty tape.
2. **The oracle is one step** and its internal working space is in no configuration. This is the paper's "plus the
   working space of its evaluation oracle". Its argument (in the configuration before) and its answer (after) are
   charged.
3. **The evaluation oracle of a request: any oracle consistent with the sample** (`OracleFor code s req orc`,
   F-B1). The precision `q` is chosen by the program (`q < 0` is read as `0`), and the oracle must satisfy:
   * `sel = 0` at the code of a sample record `s ℓ`: `⌊2^q f(s ℓ)⌋`;
   * `sel = 1, 2`: `⌊2^q clip_{[−1,2]}(l)⌋`, `⌊2^q clip_{[−1,2]}(u)⌋`;
   * everything else (`sel = 0` at any other integer, any other `sel`) is unconstrained.

   `ReproducesFor` quantifies over ALL such oracles (per round, after the requests), so the answers off the sample
   are adversarial. This is the paper's "accessed only through their values on the samples" (e2e.tex L151).
   * **No weaker than a stuck semantics for off-sample calls.** The answer of a call enters the next configuration and
     is charged. An implementation that ever makes an unconstrained call therefore fails against the consistent oracle
     that answers with an integer of more than `S` bits, while one that makes none sees only sample values.
   * **The honest oracle qualifies.** `reqOracle code req` (the v3 oracle: `f` at the record with code `r`, `0` if
     none) is consistent with the sample for injective `code` (a proved example).

   The grid rounding `h_A⌊z/h_A + 1/2⌋` of §2 is recovered by the program from one answer at precision `q_A + 1`.
   This is a proved `example` in §7.1 of the Spec.
4. **Records.** The sample is handed to `initProg` as the record codes `code(X_ℓ)`, and the oracle takes a record
   value, not a sample index. So an implementation must keep the sample (in some form) to evaluate the queries on it.
   That is the storage the paper's `N·b_𝒰` term pays for. The statement holds for every `b_𝒰` and every injective
   `code` into `b_𝒰`-bit integers.
5. **Public parameters.** `[M, J, R, ⌈log₂ a_req⁻¹⌉, ⌈log₂ ξ_req⁻¹⌉]`, the same normalization as `alg2Params`
   (`dyadicDown`). The programs compute all other parameters of Definition R:def:sec3_ada_params themselves, inside
   the budget.
6. **Fair bits.** One tape `List.ofFn ω` is threaded through the initialization and all rounds. It is read only by
   `coin`, never rewound, and unread bits are not charged. This matches the tape threading of `alg2Exec` in §2.
7. **Tape length: `∃ c_B, ∀ c ≥ c_B`** (lead's argument, agreed by the integrator; to be checked by the statement
   audit). The quantifier comes right after the public parameters and their hypotheses, before `𝒰`, `b_𝒰`, `code`,
   the sample, the coins and the requests.
   * The paper's mechanism draws fresh fair bits without limit; the finite tape is a formalization artifact.
   * For `c ≥` the worst-case consumption, `alg2Mech … c` is exactly the paper's mechanism (it never reaches the end
     of its tape, where it would abort).
   * Requiring an implementation to replicate the abort on short tapes would be stronger than the paper.
   * A proof of the headline implies bounded consumption: `coin` on the empty tape is stuck, and a stuck run yields no
     responses. Every run must halt for every `c ≥ c_B`, so the implementation never needs more than `c_B` bits in
     total over all rounds.
8. **Requests.** Request sequences rather than controllers. The statement holds for every valid sequence, which
   implies the controller form: for any adaptive controller and any value of its coins, the realized requests form
   such a sequence, and by induction on rounds the responses agree. Validity is `VController.Valid`'s condition,
   per request.
9. **All rounds `t ∈ ℕ`.** This covers over-cap requests and requests after halting (dummy responses with no data,
   no bits and no state change in §2). An implementation must keep saturated counters so that its state stays
   bounded.
10. **Responses.** `[0]`/`[1]`/`[2]` = ACCEPT/HIGH/LOW, and `[3, a, d]` (`d > 0`) = the numerical answer `a/d`;
    anything else fails to parse.
11. **Uniformity.** `∃ impl` precedes all parameters, and the constant is explicit in `bSpaceBound` (no `∃ C`).
12. **The budget** is `bSpaceBound e N b_𝒰 χ = 2^e · N · (b_𝒰 + χ²)` (real-valued), with `N`, `χ` the locked §2
    definitions. Its docstring: "the bit budget `2^e · N · (b_𝒰 + χ²)`; the paper's constant (`R:eq:sec3_bits`) is
    `e = 30`". The chain is:
    * `ReproducesFor e` and `Theorem_B_space_for e` carry the exponent;
    * `Theorem_B_space_with e` instantiates them with the pinned Algorithm 2;
    * `Theorem_B_space := Theorem_B_space_with 30` is the paper's clause, with its constant verbatim.
13. **History-freeness** (F-B2; partII.tex L970: "It stores only current evaluations, not old queries").
    * `VImplRun` is the execution with the between-request states `states` explicit: `states t` is the
      implementation's entire memory before request `t`, the only value passed from run to run.
    * `VImplExec := ∃ states, VImplRun …`.
    * > **History-freeness after F1.** For each sample there is an encoding `enc : Alg2State → Val`, chosen before coins, requests, and consistent oracles. Every actual boundary state satisfies  
      > `states t = enc (alg2RetainedOf M J R aReq ξReq c t (viewsBefore s reqs t) ω)`.  
      > The reference is the raw `alg2StateOf` fold projected by `alg2Retained`. It retains scores only for `j < p` and `i < n_j`, together with persistent correction counts, thresholds, request/rejection counters, and flags. Unused score coordinates are zeroed; unused `T` and `thrInt` coordinates are already zero on reachable states. The sample may be retained because `enc` is chosen after it. The encoding is not a runtime oracle, and every actual machine value remains charged.
    * One convention is pinned. After a halt (terminal rejection, `CAP_ABORT`), `Alg2State` is the Spec's convention
      (the paper leaves it open), and the equality pins the implementation's memory to `enc` of its retained part. A
      variant that requires the equality only while `halted = false` is a one-line change, if wanted.
    * **Retained state (fix F1; v3.1 audit, check 2).** `alg2Correct` updates `G_j` at every `i : ℕ`. The coordinates
      `i ≥ n_j` are never read (`alg2Mu` and `learnerWeights` read only `i < n_j`), but they accumulate evaluations at
      other blocks' sample points. An `enc` that read them could keep old-query information that the paper's
      mechanism does not retain. So the reference state of `Theorem_B_space_with` / `Theorem_B_joint_with` is
      `alg2RetainedOf = alg2Retained ∘ alg2StateOf`. It zeroes `G j i` outside `j < p ∧ i < n_j` and keeps every other
      field. `T` and `thrInt` need no restriction: they are updated only at edges `j < p` (`alg2Correct`; `alg2Init`
      draws for `List.range p`; `alg2ReopenEdges j ⊆ [0, p)`), so their other coordinates are `0` in every reachable
      state. `ReproducesFor` and `Theorem_B_space_for` are unchanged (generic in `stateOf`). The proof side confirmed
      that its state map reads `G` only in that range.

### 7.3 Junk values and loophole review

* **`c_B` cannot depend on** the domain, the record code, the sample, the views, the coins or the requests: it is
  chosen right after the public parameters. A huge `c_B` is harmless, because `c_B` is a tape length and unread bits
  are not charged. `c` is not an input of the implementation, which sees the tape only bit by bit through `coin`.
  The quantification over all `c ≥ c_B` leaves no room to exploit a particular length.
* **Exhaustion**: on the locked machine, `coin` on the empty tape is stuck. A stuck run yields no responses, so the
  headline forces the implementation never to exhaust a tape of length `≥ c_B`. The reference `alg2Mech … c` may
  abort on exhaustion only if `c` is below its worst-case consumption. A proof must then still match its responses,
  so the proof side will pick `c_B ≥` the reference's worst-case consumption (B-ARCH's bound).
* **`b_𝒰` too small** for `|𝒰|`: then no injective `code` exists, and the statement is empty for that `b_𝒰`. This is
  correct, since records cannot use fewer bits. If `b_𝒰 = 0`, then `|𝒰| ≤ 1`, and the budget is `2^e·N·χ²`.
* **Malformed oracle argument**: the step is stuck, so there is no run (as for type errors). `q < 0` is read as `0`.
* **Codes that are not records**, and evaluations at non-sample records: unconstrained, i.e. adversarial (F-B1;
  §7.2 item 3). Such a call can neither inform the responses nor stay within the budget against every consistent
  oracle. The oracle is stateless, so it cannot serve as memory either.
* **Program-chosen precision**: a large `q` gives a large answer, but that answer sits in the configuration after
  the step and is charged.
* **`reqOracle`** uses `Classical.choose` for the record with the given code; it is unique by injectivity.
  `truncIdx` is a real floor.
* **Reserved index**: a program may store a function at index 1000, but under `stepO`, `call 1000 a` never runs it.
  A `loop 1000 a` would still run it as a loop body; that is ordinary machine behaviour, charged as usual. (Agreed
  by the lead; W4 uses 900–999 for glue.)
* **Relational execution**: `VImplExec` asserts the existence of states and tape remainders. The machine is
  deterministic, so they are unique given the inputs.
* **Not trivially satisfiable**: the responses are pinned to `alg2Mech`, which is not constant, and the budget must
  contain the records, since the initial configuration holds them (`≥ N` bits).
* **Not vacuous**:
  * the oracle machine coincides with the locked machine on oracle-free programs (example: `x ↦ x+1`);
  * `coin` on the empty tape is stuck, as on the locked machine;
  * an oracle call returns `orc sel r q` (example: `0 + 5 + 3 = 8` in 15 steps);
  * the run predicate is satisfiable with the oracle step charged (example: within 300 bits, largest charge 270);
  * the stuck malformed call and four parse cases are checked by examples;
  * an `Iff.rfl` example shows that the factored headline (`ReproducesFor`) is definitionally the unfolded one.
  * the honest oracle `reqOracle code req` satisfies `OracleFor` (injective `code`), so the quantification over
    consistent oracles is not vacuous;
  * `alg2StateAt P 0 _ ω` is `alg2Init`'s state; `alg2StateAt P (t+1) views ω` has the abort flag and correction counts
    that `alg2Exec P t views ω` reports (`rfl`: the same fold); `VImplExec ↔ ∃ states, VImplRun` (`Iff.rfl`);
  * `(alg2Retained P st).G 0 (P.n 0) = 0`: the first coordinate past block `0`'s points is zeroed (fix F1);
  * Feasibility of the constant: §7.5.
* **Not claimed**: no time bound (the paper's clause has none); the oracle's working space (excluded by the paper).
  "It stores only current evaluations, not old queries" IS claimed in v3.1 (F-B2, §7.2 item 13).

### 7.4 Alternatives considered

* **A separate machine copy with an `Expr.oracle` constructor and a new frame** (the draft). Rejected: there would be
  two machines, and neither the (C) DSL code (W4 = Algorithm 2 routines) nor the machine lemmas would transfer
  without a translation bridge. The reserved-index call keeps `Expr`, `Frame`, `confBits` and the per-step charge
  untouched.
* **A coin sentinel (`-1` on the empty tape) with `∀ c`** (the first v3 draft). Rejected:
  * it is stronger than the paper, because the implementation would have to replicate the abort on short tapes;
  * it changes the locked `coin` semantics;
  * `∃ c_B, ∀ c ≥ c_B` keeps the locked semantics and is what the paper's unlimited fresh bits mean.
* **`∀ c ≥ alg2CoinBound`, a Spec-defined worst-case bit count.** This needs a new audited definition and pins one
  particular bound; the existential `c_B` (placed before all data) is simpler and no weaker in substance.
* **A program-relative oracle index** (`prog.length`). It avoids a reserved constant, but DSL code would need the
  final program length at compile time.
* **The draft's per-configuration bound** (`confBits c ≤ S` at every configuration). Replaced by the locked per-step
  charge (footprint + `stepWork` + `ctrlWork`), so the arithmetic-workspace accounting of (C) applies to (B) too.
* **An index oracle** (`f_t(X_ℓ)` for a sample index `ℓ`). Rejected: the records would never need to be stored, and
  the paper's `N·b_𝒰` term would be unexplained.
* **An oracle that returns §2's grid index at the interface-fixed `h_A`.** Simpler, but the interface would then
  depend on the parameters and on §2's rounding convention.
* **Endpoints in the round input** (`⌊2^q clip(l)⌋` for a fixed `q`). The oracle form keeps the interface uniform.
* **Controllers instead of request sequences.** Equivalent (§7.2 item 8); sequences are simpler.

### 7.5 The constant (integrator decision, 13:40Z)

The Spec states the clause for every `e`. `Theorem_B_space` and `Theorem_main_full` use the paper's `e = 30`.
`Theorem_main_full_2e128` exists so that a proof with `e = 128` can be certified first, and the paper's version added
later without changing the locked Spec.

* **One file.** The earlier two-variant scheme (a separate `SpecV3_O1.lean` with `2^128`) is retired.
  * `bSpaceBound e`, `ReproducesFor e`, `Theorem_B_space_for e`, `Theorem_B_space_with e` and
    `Theorem_B_joint_with e` carry the exponent.
  * The headlines `Theorem_B_space`, `Theorem_B_joint` and `Theorem_main_full` fix `e = 30`.
  * `Theorem_main_full_2e128` uses `e = 128` in its two (B) space conjuncts. Its docstring says it is a
    constant-factor weaker form, a stated target for staged certification, claimed only by a proof in
    `F2e2e/Headline.lean`.
* **Proved in the Spec:** `Theorem_main_full → Theorem_main_full_2e128`. The run predicates are monotone in the
  budget, and `2^30 ≤ 2^128`. Together with the two `Iff.rfl` checks of the conjunctions, this fits in about 50 lines.
* **Spike facts (W4).**
  * The measured peak on the existing programs is `≈ N·(90 q_A + 190) + 16.5K` bits `≲ 2^5.6 · N(b_𝒰 + χ²)`, so
    `e = 30` is true with margin and is being proved (O2b).
  * Earlier proof-side estimates: reusing the existing ADA module proves `≈ 2^75 · N · adaZ`; a crude chain gives
    `≲ 2^92`. Both are within `e = 128`.

---

## §8 Theorem_B_joint, Theorem_main_full, Theorem_main_full_2e128

### 8.1 `Theorem_B_joint` (new; internal checkers B (MINOR 2) and C (B1))

In plain math: there is ONE implementation such that, for all caps `M, J, R`, all `a_req ∈ (0, 1/10)` and
`ξ_req ∈ (0, 1/2)`, there is a tape length `c₀` (depending only on these public parameters) such that, for every
tape length `c ≥ c₀`, both of the following hold:
* `VGuaranteeWithInternalCaps M J R a_req ξ_req (alg2Mech … c) (alg2Aborted … c) (alg2PeakCorrections … c)`, the
  statistical guarantee of `Theorem_B_statistical` for this `c`;
* `BSpace.ReproducesFor e … impl M J R a_req ξ_req c`, the reproduction within the bit budget of
  `Theorem_B_space_with e` for this `c`.

This is `BSpace.Theorem_B_joint_with e`; the headline is `Theorem_B_joint := BSpace.Theorem_B_joint_with 30`.

**Why.** `Theorem_B_statistical` has `∃ c` and `Theorem_B_space` has `∀ c ≥ c_B`. Their conjunction alone speaks
about the same mechanism only through the monotonicity argument of §7.1, which is not in the Spec. `Theorem_B_joint`
states, in the Spec, that one tape length serves both claims: Main Theorem (B) is ONE mechanism that is accurate AND
implementable within the budget.

**Provability.** Take `c₀ := max(c_stat, c_B)`.
* `c_stat` is the worst-case coin count of B-ARCH (`adaCoins`, its depth bound). For `c ≥ c_stat` the reference
  never tries to read past the end of its tape, and the statistical proof applies to every such `c`; alternatively
  use the monotonicity of §7.1.
* `c_B` is the implementation's tape bound from `Theorem_B_space`.

The lead is confirming with B-ARCH. If they cannot provide this, item 4(b)/(c) is dropped and `ReproducesFor` stays.

### 8.2 `Theorem_main_full`

`def Theorem_main_full : Prop := Theorem_A_statistical ∧ Theorem_A_eff ∧ Theorem_B_statistical ∧ Theorem_B_space ∧
Theorem_B_joint ∧ Theorem_C` (sanity: `Iff.rfl` with the six-fold conjunction). This is the paper's Main Theorem in
full, with `2^30`. The docstring explains the pairing and lists both targets:
* (A) = statistical + efficiency;
* (B) = statistical + space (`2^30 · N · (b_𝒰 + χ²)`) + joint;
* (C) as locked.

Strict-model rules 2–3 remain outside the headline, as in v2.2c.

### 8.3 `Theorem_main_full_2e128`

`def Theorem_main_full_2e128 : Prop := Theorem_A_statistical ∧ Theorem_A_eff ∧ Theorem_B_statistical ∧
BSpace.Theorem_B_space_with 128 ∧ BSpace.Theorem_B_joint_with 128 ∧ Theorem_C` (sanity: `Iff.rfl`). Its docstring:
"the same with the bit budget's constant `2^128` instead of the paper's `2^30` (a constant-factor weaker form of
(B)'s bit clause; STATEMENT_REVIEW §7.5). It is a stated target for staged certification; like every Prop of this file
it is claimed only by a proof in `F2e2e/Headline.lean`." The Spec proves `Theorem_main_full → Theorem_main_full_2e128`
(an `example`).

### Checks of the assembled files

* `python3 notes/spec_v31/make_v31.py --check` compares SpecV31.lean and the three docs. It asserts the locked prefix
  sha256 `c28be50e…` and the byte-identical prefix, and fails if one of the four forbidden tool names appears
  anywhere.
* `python3 notes/spec_v31/make_v31.py --selftest-v3`: with all flags off, the assembly is byte-identical to the v3
  candidate `notes/spec_v3/SpecV3.lean` (`9dd5490e…`).
* `scripts/lean1.sh notes/spec_v31/SpecV31.lean`: EXIT 0. The variants B1-only and B2-only also compile (scratch).
* The Spec-rule scan (`scan_forbidden.py --spec`, including the Spec extras): 0 violations.
* Clashes with the proof-side copies `F2e2e/{AEff,BSpace}/SpecDefs.lean`: as for v3 (both deleted at the lock).
