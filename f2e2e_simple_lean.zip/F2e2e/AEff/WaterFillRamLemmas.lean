import F2e2e.AEff.WaterFillRamProg

/-!
# A_eff, item W4: evaluation and assignment lemmas for the water-filling procedure

Owner: A-ARCH (a99d156c). Exact evaluation of the expression shapes used by `wfBody` (`cellE`, `ind1`, `ind2`)
in the bounded form `EvalLE` of `F2e2e/AEff/RamCore.lean`, and the corresponding assignment rules
(`wp_setC`, `wp_setInd1`, `wp_setInd2`) with their resource conjuncts.
-/

namespace F2e2e.AEff.WFRam

open F2e2e.AEff F2e2e.AEff.Select

variable {procs : List RamStmt} {O : RamOracle}

/-! ## Expressions -/

theorem evalLE_cellE (m : ℕ → ℝ) {a w : ℕ} (h : a + 1 ≤ w) : EvalLE O m (cellE a) (m a) w :=
  EvalLE.rd_nat (EvalLE.lit m (a : ℝ) w) h

theorem evalLE_natLit (m : ℕ → ℝ) (a w : ℕ) : EvalLE O m (.lit (a : ℝ)) (a : ℝ) w := EvalLE.lit m _ w

/-- `M[base + M[i]]` with `M[i] = j`. -/
theorem evalLE_ind1 {m : ℕ → ℝ} {base i j w : ℕ} (hi : m i = (j : ℝ)) (hiw : i + 1 ≤ w)
    (hw : base + j + 1 ≤ w) : EvalLE O m (ind1 base i) (m (base + j)) w := by
  have h1 : EvalLE O m (.add (.lit (base : ℝ)) (cellE i)) ((base + j : ℕ) : ℝ) w := by
    have := EvalLE.add (EvalLE.lit (O := O) m (base : ℝ) w) (evalLE_cellE (O := O) m hiw)
    rw [hi, ← Nat.cast_add] at this
    exact this
  exact EvalLE.rd_nat h1 hw

/-- `M[M[b] + M[i]]` with `M[b] = g`, `M[i] = j`. -/
theorem evalLE_ind2 {m : ℕ → ℝ} {b i g j w : ℕ} (hb : m b = (g : ℝ)) (hi : m i = (j : ℝ))
    (hbw : b + 1 ≤ w) (hiw : i + 1 ≤ w) (hw : g + j + 1 ≤ w) : EvalLE O m (ind2 b i) (m (g + j)) w := by
  have h1 : EvalLE O m (.add (cellE b) (cellE i)) ((g + j : ℕ) : ℝ) w := by
    have := EvalLE.add (evalLE_cellE (O := O) m hbw) (evalLE_cellE (O := O) m hiw)
    rw [hb, hi, ← Nat.cast_add] at this
    exact this
  exact EvalLE.rd_nat h1 hw

/-- The address `base + M[i]` with `M[i] = j`. -/
theorem evalLE_addr1 {m : ℕ → ℝ} {base i j w : ℕ} (hi : m i = (j : ℝ)) (hiw : i + 1 ≤ w) :
    EvalLE O m (.add (.lit (base : ℝ)) (cellE i)) ((base + j : ℕ) : ℝ) w := by
  have := EvalLE.add (EvalLE.lit (O := O) m (base : ℝ) w) (evalLE_cellE (O := O) m hiw)
  rw [hi, ← Nat.cast_add] at this
  exact this

/-- The address `M[b] + M[i]` with `M[b] = g`, `M[i] = j`. -/
theorem evalLE_addr2 {m : ℕ → ℝ} {b i g j w : ℕ} (hb : m b = (g : ℝ)) (hi : m i = (j : ℝ))
    (hbw : b + 1 ≤ w) (hiw : i + 1 ≤ w) :
    EvalLE O m (.add (cellE b) (cellE i)) ((g + j : ℕ) : ℝ) w := by
  have := EvalLE.add (evalLE_cellE (O := O) m hbw) (evalLE_cellE (O := O) m hiw)
  rw [hb, hi, ← Nat.cast_add] at this
  exact this

/-! ## Assignments -/

/-- `M[a] := e`. -/
theorem wp_setC {a : ℕ} {e : RamExp} {Q : RamConf → Prop} {σ : RamConf} {v : ℝ} {w : ℕ}
    (he : EvalLE O σ.mem e v w) (haw : a + 1 ≤ w)
    (h : ∀ σ', σ'.mem = Function.update σ.mem a v → σ'.out = σ.out →
      ResWithin σ σ' (e.size + 2) w 0 → Q σ') :
    WP procs O (setC a e) Q σ := by
  refine wp_assign_res (EvalLE.lit σ.mem (a : ℝ) w) he haw fun σ' hm hout hres => h σ' hm hout ?_
  refine hres.mono (le_of_eq ?_) le_rfl le_rfl
  simp [RamExp.size]
  omega

/-- `M[base + M[i]] := e` with `M[i] = j`. -/
theorem wp_setInd1 {base i j : ℕ} {e : RamExp} {Q : RamConf → Prop} {σ : RamConf} {v : ℝ} {w : ℕ}
    (hi : σ.mem i = (j : ℝ)) (hiw : i + 1 ≤ w) (hw : base + j + 1 ≤ w) (he : EvalLE O σ.mem e v w)
    (h : ∀ σ', σ'.mem = Function.update σ.mem (base + j) v → σ'.out = σ.out →
      ResWithin σ σ' (e.size + 5) w 0 → Q σ') :
    WP procs O (setInd1 base i e) Q σ := by
  refine wp_assign_res (evalLE_addr1 hi hiw) he hw fun σ' hm hout hres => h σ' hm hout ?_
  refine hres.mono (le_of_eq ?_) le_rfl le_rfl
  simp [RamExp.size, cellE]
  omega

/-- `M[M[b] + M[i]] := e` with `M[b] = g`, `M[i] = j`. -/
theorem wp_setInd2 {b i g j : ℕ} {e : RamExp} {Q : RamConf → Prop} {σ : RamConf} {v : ℝ} {w : ℕ}
    (hb : σ.mem b = (g : ℝ)) (hi : σ.mem i = (j : ℝ)) (hbw : b + 1 ≤ w) (hiw : i + 1 ≤ w)
    (hw : g + j + 1 ≤ w) (he : EvalLE O σ.mem e v w)
    (h : ∀ σ', σ'.mem = Function.update σ.mem (g + j) v → σ'.out = σ.out →
      ResWithin σ σ' (e.size + 6) w 0 → Q σ') :
    WP procs O (setInd2 b i e) Q σ := by
  refine wp_assign_res (evalLE_addr2 hb hi hbw hiw) he hw fun σ' hm hout hres => h σ' hm hout ?_
  refine hres.mono (le_of_eq ?_) le_rfl le_rfl
  simp [RamExp.size, cellE]
  omega

end F2e2e.AEff.WFRam
