import F2e2e.AEff.RUpdEval

/-!
# A_eff, piece R-upd: phase 2, the weights by water-filling (FIXED STATEMENTS; owner: C-ALG)

The three lemmas below are fixed-statement sub-pieces of R-upd (handover candidates):
* `wp_wfCall`: one call of the water-filling procedure `2` (A-ARCH's frozen contract `WFRam.wf_call_spec`) on the
  block whose index is the value of `rE`, after setting `M[rG], M[rP], M[rN], M[rEta]`;
* `wp_wfA`: Case A, water-filling of block `1` with `η₁`;
* `wp_wfB`: every validator block `2 ≤ j < L` with `caseB ∧ (j + 1 = u ∨ j = u)`: water-filling with `η = 1`.
All are stated over variables (cell values, offsets `off`, block sizes `nb`).

Proofs (C-BANK, file owner since 13:43Z by agreement with C-ALG; `wp_wfB` by e26ae4ae): the four assignments of
`wfCall` write the cells `32 … 35` (water-filling scratch) and read only the round temporaries/scratch below `32`
(through `rE`, `ηE`) and the parameter tables; the call is `wf_call_spec` with procedure indices `0, 1, 2` of
`adaProcs L n` (by `rfl`), the payoff block at `aPay L n + o` and the output block at `aP L + o`.
-/

namespace F2e2e.AEff.RUpd

open F2e2e.AEff F2e2e.AEff.WFRam F2e2e.AEff.Select

variable {O : RamOracle}

/-- `M[t + rE]`, for an index expression `rE` that reads only cells below `32`. -/
theorem evalLE_tabIdx {m m₀ : ℕ → ℝ} {t r W : ℕ} {rE : RamExp} {v : ℝ}
    (hrE : ∀ m' : ℕ → ℝ, (∀ x, x < 32 → m' x = m₀ x) → EvalLE O m' rE (r : ℝ) 32)
    (hm : ∀ x, x < 32 → m x = m₀ x) (hv : m (t + r) = v) (hW : t + r + 1 ≤ W) (h32 : 32 ≤ W) :
    EvalLE O m (.rd (.add (.lit (t : ℝ)) rE)) v W := by
  have h1 := EvalLE.add (EvalLE.lit (O := O) m (t : ℝ) W) ((hrE m hm).mono h32)
  rw [← Nat.cast_add] at h1
  have h2 := EvalLE.rd_nat h1 hW
  rwa [hv] at h2

/-- **One water-filling call.** The expressions `rE` (block index `r`) and `ηE` (step `η`) read only cells below
`32` (watermark `≤ 32`), so their values survive the writes to `M[rG] … M[rEta]` (cells `32 … 35`). -/
theorem wp_wfCall {L n : ℕ} {rE ηE : RamExp} {r o nb : ℕ} {η : ℝ} {σ : RamConf}
    (hrE : ∀ m : ℕ → ℝ, (∀ x, x < 32 → m x = σ.mem x) → EvalLE O m rE (r : ℝ) 32)
    (hηE : ∀ m : ℕ → ℝ, (∀ x, x < 32 → m x = σ.mem x) → EvalLE O m ηE η 32)
    (hr : r < L + 2) (hO : σ.mem (tOff L + r) = (o : ℝ)) (hN : σ.mem (tBlock L + r) = (nb : ℝ))
    (hnb : 1 ≤ nb) (hblk : o + nb ≤ n) :
    WP (adaProcs L n) O (wfCall L n rE ηE) (fun σ' =>
      (∀ ℓ : Fin nb, σ'.mem (aP L + o + ℓ) = Opt.waterFill nb η (fun ℓ' => σ.mem (aPay L n + o + ℓ')) ℓ) ∧
      (∀ x, x < sBase L n → ¬ (aP L + o ≤ x ∧ x < aP L + o + nb) → ¬ WFScratch L n x →
        σ'.mem x = σ.mem x) ∧
      σ'.out = σ.out ∧
      ResWithin σ σ' (wfOpsA * nb + wfOpsB + rE.size * 3 + ηE.size + 30)
        (sBase L n + selTopA * nb + selTopB) (nb + selPeakC + 1)) σ := by
  have hS : 64 ≤ sBase L n := by unfold sBase arrBase; omega
  have hWoff : tOff L + r + 1 ≤ sBase L n := by unfold tOff tabBase sBase arrBase; omega
  have hWblk : tBlock L + r + 1 ≤ sBase L n := by unfold tBlock tabBase sBase arrBase; omega
  have eG : rG = 32 := rfl
  have eP : rP = 33 := rfl
  have eN : rN = 34 := rfl
  have eE : rEta = 35 := rfl
  have hoffG : tOff L + r ≠ rG := by rw [eG]; unfold tOff tabBase; omega
  have hblkG : tBlock L + r ≠ rG := by rw [eG]; unfold tBlock tabBase; omega
  have hblkP : tBlock L + r ≠ rP := by rw [eP]; unfold tBlock tabBase; omega
  unfold wfCall setCell
  -- `M[rG] := aPay + off_r`
  apply wp_seq
  refine wp_assign_res (EvalLE.lit σ.mem (rG : ℝ) (sBase L n))
    (EvalLE.add (EvalLE.lit σ.mem (aPay L n : ℝ) (sBase L n))
      (evalLE_tabIdx hrE (fun _ _ => rfl) hO hWoff (by omega)))
    (by rw [eG]; omega) fun σ1 hm1 hout1 hres1 => ?_
  have hb1 : ∀ x, x < 32 → σ1.mem x = σ.mem x := fun x hx => by
    rw [hm1, Function.update_of_ne (by rw [eG]; omega)]
  -- `M[rP] := aP + off_r`
  apply wp_seq
  refine wp_assign_res (EvalLE.lit σ1.mem (rP : ℝ) (sBase L n))
    (EvalLE.add (EvalLE.lit σ1.mem (aP L : ℝ) (sBase L n))
      (evalLE_tabIdx hrE hb1
        ((by rw [hm1, Function.update_of_ne hoffG] : σ1.mem (tOff L + r) = σ.mem (tOff L + r)).trans hO)
        hWoff (by omega)))
    (by rw [eP]; omega) fun σ2 hm2 hout2 hres2 => ?_
  have hb2 : ∀ x, x < 32 → σ2.mem x = σ.mem x := fun x hx => by
    rw [hm2, Function.update_of_ne (by rw [eP]; omega), hb1 x hx]
  -- `M[rN] := n_r`
  apply wp_seq
  refine wp_assign_res (EvalLE.lit σ2.mem (rN : ℝ) (sBase L n))
    (evalLE_tabIdx hrE hb2
      ((by rw [hm2, Function.update_of_ne hblkP, hm1, Function.update_of_ne hblkG] :
        σ2.mem (tBlock L + r) = σ.mem (tBlock L + r)).trans hN) hWblk (by omega))
    (by rw [eN]; omega) fun σ3 hm3 hout3 hres3 => ?_
  have hb3 : ∀ x, x < 32 → σ3.mem x = σ.mem x := fun x hx => by
    rw [hm3, Function.update_of_ne (by rw [eN]; omega), hb2 x hx]
  -- `M[rEta] := η`
  apply wp_seq
  refine wp_assign_res (EvalLE.lit σ3.mem (rEta : ℝ) (sBase L n)) ((hηE σ3.mem hb3).mono (by omega))
    (by rw [eE]; omega) fun σ4 hm4 hout4 hres4 => ?_
  -- the configuration before the call
  have h4G : σ4.mem rG = ((aPay L n + o : ℕ) : ℝ) := by
    rw [hm4, Function.update_of_ne (by rw [eG, eE]; omega), hm3, Function.update_of_ne (by rw [eG, eN]; omega),
      hm2, Function.update_of_ne (by rw [eG, eP]; omega), hm1, Function.update_self, Nat.cast_add]
  have h4P : σ4.mem rP = ((aP L + o : ℕ) : ℝ) := by
    rw [hm4, Function.update_of_ne (by rw [eP, eE]; omega), hm3, Function.update_of_ne (by rw [eP, eN]; omega),
      hm2, Function.update_self, Nat.cast_add]
  have h4N : σ4.mem rN = (nb : ℝ) := by
    rw [hm4, Function.update_of_ne (by rw [eN, eE]; omega), hm3, Function.update_self]
  have h4E : σ4.mem rEta = η := by
    rw [hm4, Function.update_self]
  have h4x : ∀ x, ¬ (32 ≤ x ∧ x < 36) → σ4.mem x = σ.mem x := fun x hx => by
    rw [hm4, Function.update_of_ne (by rw [eE]; omega), hm3, Function.update_of_ne (by rw [eN]; omega),
      hm2, Function.update_of_ne (by rw [eP]; omega), hm1, Function.update_of_ne (by rw [eG]; omega)]
  have h4o : σ4.out = σ.out := by rw [hout4, hout3, hout2, hout1]
  -- the call (procedure `2` of `adaProcs L n`)
  obtain ⟨σ', hex, hval, hfr, hout, hdep, hops, htop, hpeak⟩ :=
    wf_call_spec L n 0 1 2 (procs := adaProcs L n) O rfl rfl rfl (σ := σ4) (gB := aPay L n + o)
      (pB := aP L + o) (fun ℓ' => σ.mem (aPay L n + o + ℓ')) hnb (by omega) h4G h4P h4N h4E
      (fun ℓ => h4x _ (by unfold aPay arrBase; omega))
      (by unfold aPay arrBase; omega) (by unfold aPay aWf1 arrBase; omega)
      (by unfold aP arrBase; omega) (by unfold aP aWf1 arrBase; omega)
      (Or.inr (by unfold aP aPay; omega))
  refine WP.intro hex ⟨hval, fun x hx1 hx2 hx3 => ?_, hout.trans h4o, ?_⟩
  · rw [hfr x hx1 hx2 hx3]
    exact h4x x fun h => hx3 (Or.inl ⟨h.1, by omega⟩)
  · have hcall : ResWithin σ4 σ' (wfOpsA * nb + wfOpsB) (sBase L n + selTopA * nb + selTopB)
        (nb + selPeakC + 1) := by
      refine ⟨hdep, by omega, htop, le_trans hpeak (le_of_eq ?_)⟩
      rw [show σ4.depth + nb + selPeakC + 1 = σ4.depth + (nb + selPeakC + 1) by omega]
    refine ((((hres1.trans hres2).trans hres3).trans hres4).trans hcall).mono ?_ ?_ ?_
    · simp only [RamExp.size]
      omega
    · simp only [max_le_iff]
      omega
    · simp only [max_le_iff]
      omega

/-- **Phase 2a** (Case A): water-filling of block `1` (offset `o₁`, size `n₁`) with `η₁`. -/
theorem wp_wfA {L n o₁ n₁ : ℕ} {cA : Bool} {η₁ : ℝ} {σ : RamConf}
    (hA : σ.mem aCaseA = if cA = true then 1 else 0) (hE : σ.mem aEta1 = η₁)
    (hO : σ.mem (tOff L + 1) = (o₁ : ℝ)) (hN : σ.mem (tBlock L + 1) = (n₁ : ℝ))
    (hn₁ : 1 ≤ n₁) (hblk : o₁ + n₁ ≤ n) :
    WP (adaProcs L n) O (wfA L n) (fun σ' =>
      (∀ ℓ : Fin n₁, σ'.mem (aP L + o₁ + ℓ) =
        if cA = true then Opt.waterFill n₁ η₁ (fun ℓ' => σ.mem (aPay L n + o₁ + ℓ')) ℓ
        else σ.mem (aP L + o₁ + ℓ)) ∧
      (∀ x, x < sBase L n → ¬ (aP L + o₁ ≤ x ∧ x < aP L + o₁ + n₁) → ¬ WFScratch L n x →
        σ'.mem x = σ.mem x) ∧
      σ'.out = σ.out ∧
      ResWithin σ σ' (wfOpsA * n₁ + wfOpsB + 50) (sBase L n + selTopA * n₁ + selTopB)
        (n₁ + selPeakC + 1)) σ := by
  have hS : 64 ≤ sBase L n := by unfold sBase arrBase; omega
  have hc := CondLE.eq (evalLE_cell (O := O) hA (show aCaseA + 1 ≤ sBase L n by unfold aCaseA; omega))
    (EvalLE.lit (O := O) σ.mem 1 (sBase L n))
  unfold wfA
  cases cA with
  | true =>
    rw [decide_eq_true (by rw [if_pos rfl])] at hc
    obtain ⟨t, ht, hce⟩ := hc
    refine wp_ite_true hce ((wp_wfCall (r := 1) (o := o₁) (nb := n₁) (η := η₁) (rE := .lit 1)
      (ηE := cell aEta1) (σ := σ.charge ((RamCond.eq (cell aCaseA) (.lit 1)).size + 1) t)
      (fun m _ => by rw [Nat.cast_one]; exact EvalLE.lit m 1 32)
      (fun m hm => evalLE_cell (by rw [hm aEta1 (by unfold aEta1; omega)]; exact hE) (by unfold aEta1; omega))
      (by omega) hO hN hn₁ hblk).mono fun σ' hσ' => ?_)
    obtain ⟨h1, h2, h3, h4⟩ := hσ'
    refine ⟨fun ℓ => by rw [if_pos rfl]; exact h1 ℓ, h2, h3, ?_⟩
    refine ((ResWithin.charge σ _ t).trans h4).mono ?_ (max_le (by omega) le_rfl) (max_le (Nat.zero_le _) le_rfl)
    simp only [RamCond.size, RamExp.size, cell]
    omega
  | false =>
    rw [decide_eq_false (by rw [if_neg Bool.false_ne_true]; norm_num)] at hc
    obtain ⟨t, ht, hce⟩ := hc
    refine wp_ite_false hce (wp_nop ⟨fun ℓ => (if_neg Bool.false_ne_true).symm, fun x _ _ _ => rfl, rfl, ?_⟩)
    refine ((ResWithin.charge σ _ t).trans (ResWithin.charge _ 1 0)).mono ?_ ?_ ?_
    · simp only [RamCond.size, RamExp.size, cell]
      omega
    · exact max_le (by omega) (Nat.zero_le _)
    · exact max_le (Nat.zero_le _) (Nat.zero_le _)

/-- The invariant of the loop of `wfB` after the blocks `2 … j - 1`. -/
def wfBInv (L n u : ℕ) (cB : Bool) (off nb : ℕ → ℕ) (σ : RamConf) (j : ℕ) (τ : RamConf) : Prop :=
  τ.out = σ.out ∧
    (∀ x, x < sBase L n → ¬ IsTmp x → ¬ WFScratch L n x → ¬ (aP L + off 2 ≤ x ∧ x < aP L + off j) →
      τ.mem x = σ.mem x) ∧
    (∀ j', 2 ≤ j' → j' < j → ∀ ℓ : Fin (nb j'), τ.mem (aP L + off j' + ℓ) =
      if cB = true ∧ (j' + 1 = u ∨ j' = u) then
        Opt.waterFill (nb j') 1 (fun ℓ' => σ.mem (aPay L n + off j' + ℓ')) ℓ
      else σ.mem (aP L + off j' + ℓ))

/-- **Phase 2b**: water-filling with `η = 1` of every validator block `2 ≤ j < L` with
`caseB ∧ (j + 1 = u ∨ j = u)`. -/
theorem wp_wfB {L n u : ℕ} {cB : Bool} {off nb : ℕ → ℕ} {σ : RamConf}
    (hL : 2 ≤ L) (hoff : ∀ j, off (j + 1) = off j + nb j) (hoffL : off L ≤ n)
    (hmL : σ.mem aL = (L : ℝ)) (hB : σ.mem aCaseB = if cB = true then 1 else 0)
    (hU : σ.mem aUFinal = (u : ℝ))
    (hmO : ∀ j, 2 ≤ j → j < L → σ.mem (tOff L + j) = (off j : ℝ))
    (hmN : ∀ j, 2 ≤ j → j < L → σ.mem (tBlock L + j) = (nb j : ℝ))
    (hnb : ∀ j, 2 ≤ j → j < L → 1 ≤ nb j) :
    WP (adaProcs L n) O (wfB L n) (fun σ' =>
      (∀ j, 2 ≤ j → j < L → ∀ ℓ : Fin (nb j), σ'.mem (aP L + off j + ℓ) =
        if cB = true ∧ (j + 1 = u ∨ j = u) then
          Opt.waterFill (nb j) 1 (fun ℓ' => σ.mem (aPay L n + off j + ℓ')) ℓ
        else σ.mem (aP L + off j + ℓ)) ∧
      (∀ x, x < sBase L n → ¬ IsTmp x → ¬ WFScratch L n x → ¬ (aP L + off 2 ≤ x ∧ x < aP L + off L) →
        σ'.mem x = σ.mem x) ∧
      σ'.out = σ.out ∧
      ResWithin σ σ' (∑ j ∈ Finset.Ico 2 L, (wfOpsA * nb j + wfOpsB + 100) + 20)
        (sBase L n + selTopA * n + selTopB) (n + selPeakC + 1)) σ := by
  -- layout facts
  have hP : aP L = 64 + 16 * (L + 2) := rfl
  have hPay : aPay L n = 64 + 16 * (L + 2) + n := rfl
  have hWf : aWf1 L n = 64 + 16 * (L + 2) + 2 * n := rfl
  have hSB : sBase L n = 64 + 16 * (L + 2) + 4 * n := rfl
  have hB0 : tBlock L = 64 + 0 * (L + 2) := rfl
  have hO1 : tOff L = 64 + 1 * (L + 2) := rfl
  have hcR : cR = 26 := rfl
  have h2 : aL = 2 := rfl
  have hcB : aCaseB = 24 := rfl
  have hcU : aUFinal = 20 := rfl
  -- offsets are monotone
  have hmono : ∀ a b, a ≤ b → off a ≤ off b := by
    intro a b hab
    induction b, hab using Nat.le_induction with
    | base => exact le_rfl
    | succ b _ ih => rw [hoff b]; omega
  have hoffLn : ∀ j, j ≤ L → off j ≤ n := fun j hj => (hmono j L hj).trans hoffL
  -- the cells read by the loop are kept by the invariant
  have hkeep : ∀ j τ, wfBInv L n u cB off nb σ j τ → ∀ x, x < 32 → ¬ IsTmp x → τ.mem x = σ.mem x := by
    rintro j τ ⟨-, hf, -⟩ x hx hT
    exact hf x (by rw [hSB]; omega) hT (by unfold WFScratch; rw [hWf]; omega) (fun h => by omega)
  have hkeepT : ∀ j τ, wfBInv L n u cB off nb σ j τ → ∀ x, 64 ≤ x → x < aP L → τ.mem x = σ.mem x := by
    rintro j τ ⟨-, hf, -⟩ x hx1 hx2
    exact hf x (by rw [hSB]; rw [hP] at hx2; omega) (by unfold IsTmp; omega)
      (by unfold WFScratch; rw [hWf]; rw [hP] at hx2; omega) (fun h => by omega)
  -- the per-iteration cost bound
  let B : ℕ → ℕ := fun j => wfOpsA * nb j + wfOpsB + 56
  have key := wp_forRange_sum (procs := adaProcs L n) (O := O) (i := cR) (lo := .lit 2) (hi := cell aL)
    (body := .ite (.and (.eq (cell aCaseB) (.lit 1))
        (.or (.eq (.add (cell cR) (.lit 1)) (cell aUFinal)) (.eq (cell cR) (cell aUFinal))))
      (wfCall L n (cell cR) (.lit 1)) .nop)
    (a := 2) (N := L) hL (wfBInv L n u cB off nb σ) B (sBase L n + selTopA * n + selTopB)
    (n + selPeakC + 1) (σ := σ) ?hI ?hlo ?hhi ?hbody ?h0
  · refine key.mono fun σ' ⟨⟨h1, h2', h3⟩, _, hres⟩ => ⟨h3, h2', h1, hres.mono ?_ ?_ le_rfl⟩
    · -- the cost
      have hsz : (cell aL).size = 2 := rfl
      have hlo : (RamExp.lit 2).size = 1 := rfl
      rw [hsz, hlo]
      have e : ∀ j ∈ Finset.Ico 2 L, B j + 2 + 10 ≤ wfOpsA * nb j + wfOpsB + 100 := by
        intro j _
        show wfOpsA * nb j + wfOpsB + 56 + 2 + 10 ≤ wfOpsA * nb j + wfOpsB + 100
        omega
      have := Finset.sum_le_sum e
      omega
    · exact max_le le_rfl (by rw [hcR, hSB]; omega)
  case hI =>
    rintro j τ τ' ⟨h1, h2', h3⟩ ho _ _ hm
    refine ⟨ho.trans h1, fun x hx hT hW hR => ?_, fun j' hj2 hj' ℓ => ?_⟩
    · rw [hm x (fun h => hT (by rw [h, hcR]; unfold IsTmp; omega))]
      exact h2' x hx hT hW hR
    · rw [hm _ (by rw [hcR, hP]; omega)]
      exact h3 j' hj2 hj' ℓ
  case hlo =>
    have h := EvalLE.lit (O := O) σ.mem (2 : ℝ) (sBase L n + selTopA * n + selTopB)
    rwa [show ((2 : ℕ) : ℝ) = (2 : ℝ) by norm_num]
  case hhi =>
    intro j _ _ τ hτ _
    exact evalLE_cell ((hkeep j τ hτ aL (by rw [h2]; omega) (by rw [h2]; unfold IsTmp; omega)).trans hmL)
      (by rw [h2, hSB]; omega)
  case hbody =>
    intro j hj2 hjL τ hτ hτj
    have hvB : τ.mem aCaseB = if cB = true then 1 else 0 :=
      (hkeep j τ hτ aCaseB (by rw [hcB]; omega) (by rw [hcB]; unfold IsTmp; omega)).trans hB
    have hvU : τ.mem aUFinal = (u : ℝ) :=
      (hkeep j τ hτ aUFinal (by rw [hcU]; omega) (by rw [hcU]; unfold IsTmp; omega)).trans hU
    have hvO : τ.mem (tOff L + j) = (off j : ℝ) :=
      (hkeepT j τ hτ _ (by rw [hO1]; omega) (by rw [hO1, hP]; omega)).trans (hmO j hj2 hjL)
    have hvN : τ.mem (tBlock L + j) = (nb j : ℝ) :=
      (hkeepT j τ hτ _ (by rw [hB0]; omega) (by rw [hB0, hP]; omega)).trans (hmN j hj2 hjL)
    have hoffj : off j + nb j ≤ n := by rw [← hoff j]; exact hoffLn (j + 1) (by omega)
    have hnbn : nb j ≤ n := by omega
    have hoff2j : off 2 ≤ off j := hmono 2 j hj2
    have hoffjL : off (j + 1) ≤ off L := hmono (j + 1) L (by omega)
    have hoffj1 := hoff j
    obtain ⟨hτo, hτf, hτP⟩ := hτ
    -- the condition
    have hc := CondLE.and (O := O) (w := 64)
      (CondLE.eq (evalLE_cell hvB (by rw [hcB]; omega)) (EvalLE.lit τ.mem 1 64))
      (CondLE.or (CondLE.eq (EvalLE.add (evalLE_cell hτj (by rw [hcR]; omega)) (EvalLE.lit τ.mem 1 64))
          (evalLE_cell hvU (by rw [hcU]; omega)))
        (CondLE.eq (evalLE_cell hτj (by rw [hcR]; omega)) (evalLE_cell hvU (by rw [hcU]; omega))))
    have hcs : (RamCond.and (.eq (cell aCaseB) (.lit 1))
        (.or (.eq (.add (cell cR) (.lit 1)) (cell aUFinal)) (.eq (cell cR) (cell aUFinal)))).size = 18 := rfl
    by_cases hcond : cB = true ∧ (j + 1 = u ∨ j = u)
    · -- the block is recomputed
      have hb : (decide ((if cB = true then (1 : ℝ) else 0) = 1) &&
          (decide ((j : ℝ) + 1 = (u : ℝ)) || decide ((j : ℝ) = (u : ℝ)))) = true := by
        obtain ⟨hcB1, hju⟩ := hcond
        rw [if_pos hcB1]
        simp only [Bool.and_eq_true, Bool.or_eq_true, decide_eq_true_eq]
        refine ⟨trivial, ?_⟩
        rcases hju with h | h
        · left; exact_mod_cast h
        · right; exact_mod_cast h
      rw [hb] at hc
      obtain ⟨t, ht, hce⟩ := hc
      refine wp_ite_true hce ?_
      refine (wp_wfCall (r := j) (o := off j) (nb := nb j) (η := 1) (rE := cell cR) (ηE := .lit 1)
        (σ := τ.charge _ t)
        (fun m hm => evalLE_cell ((hm cR (by rw [hcR]; omega)).trans hτj) (by rw [hcR]; omega))
        (fun m _ => EvalLE.lit m 1 32) (by omega) hvO hvN (hnb j hj2 hjL) hoffj).mono
        fun τ' ⟨g1, g2, g3, g4⟩ => ⟨⟨g3.trans hτo, fun x hx hT hW hR => ?_, fun j' hj2' hj' ℓ => ?_⟩, ?_, ?_⟩
      · rw [g2 x hx (fun h => hR ⟨by omega, by omega⟩) hW]
        exact hτf x hx hT hW (fun h => hR ⟨h.1, by omega⟩)
      · have hℓ := ℓ.isLt
        rcases Nat.lt_or_ge j' j with hlt | hge
        · have e1 := hoff j'
          have e2 := hmono (j' + 1) j (by omega)
          have e3 := hmono j' L (by omega)
          rw [g2 _ (by rw [hSB, hP]; omega) (fun h => by omega)
            (by unfold WFScratch; rw [hWf, hP]; omega)]
          exact hτP j' hj2' hlt ℓ
        · obtain rfl : j' = j := by omega
          rw [if_pos hcond, g1 ℓ]
          congr 1
          funext ℓ'
          have hℓ' := ℓ'.isLt
          exact hτf _ (by rw [hSB, hPay]; omega) (by unfold IsTmp; rw [hPay]; omega)
            (by unfold WFScratch; rw [hWf, hPay]; omega) (fun h => by rw [hPay] at h; rw [hP] at h; omega)
      · rw [g2 cR (by rw [hcR, hSB]; omega) (fun h => by rw [hcR, hP] at h; omega)
          (by unfold WFScratch; rw [hcR]; omega)]
        exact hτj
      · refine ((ResWithin.charge τ _ t).trans g4).mono ?_ (max_le ?_ ?_) (max_le (Nat.zero_le _) ?_)
        · rw [hcs]
          show 18 + 1 + (wfOpsA * nb j + wfOpsB + 2 * 3 + 1 + 30) ≤ wfOpsA * nb j + wfOpsB + 56
          omega
        · rw [hSB]; omega
        · have := Nat.mul_le_mul_left selTopA hnbn
          omega
        · omega
    · -- the block is kept
      have hb : (decide ((if cB = true then (1 : ℝ) else 0) = 1) &&
          (decide ((j : ℝ) + 1 = (u : ℝ)) || decide ((j : ℝ) = (u : ℝ)))) = false := by
        rw [Bool.eq_false_iff]
        intro h
        simp only [Bool.and_eq_true, Bool.or_eq_true, decide_eq_true_eq] at h
        obtain ⟨h1, h2⟩ := h
        apply hcond
        refine ⟨?_, ?_⟩
        · by_contra hc'
          rw [if_neg hc'] at h1
          norm_num at h1
        · rcases h2 with h | h
          · left; exact_mod_cast h
          · right; exact_mod_cast h
      rw [hb] at hc
      obtain ⟨t, ht, hce⟩ := hc
      refine wp_ite_false hce (wp_nop ⟨⟨hτo, fun x hx hT hW hR => hτf x hx hT hW (fun h => hR ⟨h.1, by omega⟩),
        fun j' hj2' hj' ℓ => ?_⟩, hτj, ?_⟩)
      · have hℓ := ℓ.isLt
        rcases Nat.lt_or_ge j' j with hlt | hge
        · exact hτP j' hj2' hlt ℓ
        · obtain rfl : j' = j := by omega
          rw [if_neg hcond]
          exact hτf _ (by rw [hSB, hP]; omega) (by unfold IsTmp; rw [hP]; omega)
            (by unfold WFScratch; rw [hWf, hP]; omega) (fun h => by omega)
      · refine ((ResWithin.charge τ _ t).trans (ResWithin.charge _ 1 0)).mono ?_ (max_le ?_ ?_) (by simp)
        · rw [hcs]
          show 18 + 1 + 1 ≤ wfOpsA * nb j + wfOpsB + 56
          omega
        · rw [hSB]; omega
        · exact Nat.zero_le _
  case h0 =>
    refine ⟨rfl, fun x _ _ _ _ => rfl, fun j' hj2 hj' => absurd hj' (by omega)⟩

end F2e2e.AEff.RUpd
