import F2e2e.AEff.WaterFillCost
import F2e2e.AEff.SelectCorrect

/-!
# A_eff, item W: the water-filling algorithm with median-of-medians selection

Owner: A-ARCH (a99d156c). The abstract selector of `F2e2e/AEff/WaterFillAlg.lean` and
`F2e2e/AEff/WaterFillCost.lean` instantiated with C-TREE's selection (`F2e2e/AEff/SelectDefs.lean`,
`SelectCorrect.lean`): the median-of-medians `momSelect` and the sorting specification `sortSelect` are both
medians at the rank `⌊|l|/2⌋` (`selMedian_momSelect`, `selMedian_sortSelect`), so
`wfAlg n (momSelect) η G = Opt.waterFill n η G` (`wfAlg_momSelect_eq_waterFill`) and its operation count is
`O(n)` for every linear selection cost (`wfCost_momSelect_le`).
-/

namespace F2e2e.AEff.WF

open F2e2e.AEff.Select

/-- The sorting specification is a median selector. -/
theorem selMedian_sortSelect : SelMedian (fun k l => sortSelect k l) := by
  intro l hl
  have hk : l.length / 2 < l.length := Nat.div_lt_self (List.length_pos_of_ne_nil hl) (by norm_num)
  obtain ⟨h1, h2⟩ := sortSelect_rank hk
  exact ⟨sortSelect_mem hk, h1, h2⟩

/-- The median-of-medians selection is a median selector. -/
theorem selMedian_momSelect : SelMedian (fun k l => momSelect k l) := by
  intro l hl
  have hk : l.length / 2 < l.length := Nat.div_lt_self (List.length_pos_of_ne_nil hl) (by norm_num)
  obtain ⟨h1, h2⟩ := momSelect_rank hk
  exact ⟨momSelect_mem hk, h1, h2⟩

/-- **The algorithm with median-of-medians selection computes the water-filling projection.** -/
theorem wfAlg_momSelect_eq_waterFill {n : ℕ} (hn : 0 < n) (η : ℝ) (G : Fin n → ℝ) :
    wfAlg n (fun k l => momSelect k l) η G = Opt.waterFill n η G :=
  wfAlg_eq_waterFill hn (fun l hl => (selMedian_momSelect l hl).1) η G

/-- **The algorithm with median-of-medians selection runs in `O(n)` operations** (functional cost model, for
every linear bound `selCost s ≤ cS s + cS` on the cost of one selection). -/
theorem wfCost_momSelect_le {n : ℕ} (hn : 0 < n) {selCost : ℕ → ℕ} {cS : ℕ}
    (hc : ∀ s, selCost s ≤ cS * s + cS) (a b : ℕ) (η : ℝ) (G : Fin n → ℝ) :
    wfCost n (fun k l => momSelect k l) selCost a b η G ≤ (4 * a + 3 * cS + 3 * b) * n :=
  wfCost_le hn selMedian_momSelect hc a b η G

end F2e2e.AEff.WF
