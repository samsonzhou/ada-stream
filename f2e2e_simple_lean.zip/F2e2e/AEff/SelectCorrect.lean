import Mathlib
import F2e2e.AEff.SelectDefs

/-!
# A_eff, item S: correctness of the median-of-medians selection

For `k < l.length`, `momSelect k l` is the `k`-th smallest element of `l`: it belongs to `l` and
`#{x ∈ l | x < momSelect k l} ≤ k < #{x ∈ l | x ≤ momSelect k l}` (`momSelect_spec`); these rank facts
determine the element (`eq_of_rank`), so `momSelect k l = sortSelect k l` (`momSelect_eq_sortSelect`).

Also: the structure of `chunks5` (concatenation, nonempty groups of length `≤ 5`, at most one short group,
`⌈m/5⌉` groups) and the rank facts of `median5` in its group, used by the cost analysis
(`F2e2e/AEff/SelectCount.lean`).
-/

namespace F2e2e.AEff.Select

open List

variable {α : Type*}

/-! ## The groups -/

theorem chunks5_flatten (l : List α) : (chunks5 l).flatten = l := by
  induction l using chunks5.induct with
  | case1 => rfl
  | case2 a => rfl
  | case3 a b => rfl
  | case4 a b c => rfl
  | case5 a b c d => rfl
  | case6 a b c d e l ih => simp [chunks5, ih]

theorem ne_nil_of_mem_chunks5 {l g : List α} (hg : g ∈ chunks5 l) : g ≠ [] := by
  induction l using chunks5.induct with
  | case1 => simp [chunks5] at hg
  | case2 a => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case3 a b => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case4 a b c => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case5 a b c d => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case6 a b c d e l ih =>
    simp only [chunks5, mem_cons] at hg
    rcases hg with rfl | hg
    · simp
    · exact ih hg

theorem length_le_five_of_mem_chunks5 {l g : List α} (hg : g ∈ chunks5 l) : g.length ≤ 5 := by
  induction l using chunks5.induct with
  | case1 => simp [chunks5] at hg
  | case2 a => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case3 a b => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case4 a b c => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case5 a b c d => simp only [chunks5, mem_singleton] at hg; subst hg; simp
  | case6 a b c d e l ih =>
    simp only [chunks5, mem_cons] at hg
    rcases hg with rfl | hg
    · simp
    · exact ih hg

/-- `chunks5` has exactly `⌈m/5⌉` groups. -/
theorem length_chunks5 (l : List α) : (chunks5 l).length = (l.length + 4) / 5 := by
  induction l using chunks5.induct with
  | case1 => simp [chunks5]
  | case2 a => simp [chunks5]
  | case3 a b => simp [chunks5]
  | case4 a b c => simp [chunks5]
  | case5 a b c d => simp [chunks5]
  | case6 a b c d e l ih =>
    simp only [chunks5, length_cons, ih]
    omega

/-- At most one group is short (has fewer than `5` elements). -/
theorem length_filter_short_chunks5_le (l : List α) :
    ((chunks5 l).filter (fun g => decide (g.length < 5))).length ≤ 1 := by
  induction l using chunks5.induct with
  | case1 => simp [chunks5]
  | case2 a => simp [chunks5]
  | case3 a b => simp [chunks5]
  | case4 a b c => simp [chunks5]
  | case5 a b c d => simp [chunks5]
  | case6 a b c d e l ih =>
    simp only [chunks5]
    rw [filter_cons_of_neg (by simp)]
    exact ih

theorem chunks5_ne_nil {l : List α} (hl : l ≠ []) : chunks5 l ≠ [] := by
  intro h
  apply hl
  rw [← chunks5_flatten l, h, flatten_nil]

/-- Count splitting: `#{x ∈ l | q x} = #{x ∈ l | q x ∧ r x} + #{x ∈ l | q x ∧ ¬ r x}`. -/
theorem length_filter_split (l : List α) (q r : α → Bool) :
    (l.filter q).length = (l.filter (fun x => r x && q x)).length +
      (l.filter (fun x => !r x && q x)).length := by
  rw [length_eq_length_filter_add (l := l.filter q) r, filter_filter, filter_filter]

/-- Monotonicity of filtered lengths. -/
theorem length_filter_mono {l : List α} {q r : α → Bool} (h : ∀ x ∈ l, q x = true → r x = true) :
    (l.filter q).length ≤ (l.filter r).length := by
  rw [← countP_eq_length_filter, ← countP_eq_length_filter]
  exact countP_mono_left h

section Order

variable [LinearOrder α]

/-! ## Rank facts in a sorted list -/

/-- In a sorted list `s`, the element `s[k]` has at most `k` strictly smaller elements and more than `k`
elements `≤` it. -/
theorem rank_getElem_of_pairwise {s : List α} (hs : s.Pairwise (· ≤ ·)) {k : ℕ} (hk : k < s.length) :
    (s.filter (· < s[k])).length ≤ k ∧ k < (s.filter (· ≤ s[k])).length := by
  obtain ⟨x, hx⟩ : ∃ x, s[k] = x := ⟨_, rfl⟩
  have hsplit : s = s.take k ++ x :: s.drop (k + 1) := by
    rw [← hx, ← drop_eq_getElem_cons hk, take_append_drop]
  rw [hx]
  have hp := hs
  rw [hsplit, pairwise_append] at hp
  obtain ⟨-, hp2, hp3⟩ := hp
  have hle : ∀ a ∈ s.take k, a ≤ x := fun a ha => hp3 a ha x mem_cons_self
  have hge : ∀ b ∈ s.drop (k + 1), x ≤ b := (pairwise_cons.1 hp2).1
  have htk : (s.take k).length = k := by rw [length_take]; omega
  constructor
  · have h1 : (s.drop (k + 1)).filter (· < x) = [] :=
      filter_eq_nil_iff.2 (fun b hb => by simpa using hge b hb)
    rw [hsplit, filter_append, filter_cons_of_neg (by simp), h1, append_nil]
    exact (length_filter_le _ _).trans htk.le
  · have h2 : (s.take k).filter (· ≤ x) = s.take k :=
      filter_eq_self.2 (fun a ha => by simpa using hle a ha)
    rw [hsplit, filter_append, filter_cons_of_pos (by simp), h2, length_append, length_cons, htk]
    omega

/-- Filtered lengths are invariant under sorting. -/
theorem length_filter_insertionSort (q : α → Bool) (l : List α) :
    ((l.insertionSort (· ≤ ·)).filter q).length = (l.filter q).length :=
  ((perm_insertionSort _ l).filter q).length_eq

/-- The elements `≤ p` are those not `> p`. -/
theorem length_filter_le_eq (l : List α) (p : α) :
    (l.filter (· ≤ p)).length = l.length - (l.filter (p < ·)).length := by
  have h := length_eq_length_filter_add (l := l) (fun x => decide (x ≤ p))
  have e : l.filter (fun x => !decide (x ≤ p)) = l.filter (p < ·) :=
    filter_congr (fun x _ => by rw [← decide_not]; exact decide_eq_decide.mpr not_le)
  rw [e] at h
  omega

/-- The rank facts determine the element. -/
theorem eq_of_rank {l : List α} {k : ℕ} {a b : α}
    (hra : (l.filter (· < a)).length ≤ k ∧ k < (l.filter (· ≤ a)).length)
    (hrb : (l.filter (· < b)).length ≤ k ∧ k < (l.filter (· ≤ b)).length) : a = b := by
  rcases lt_trichotomy a b with hab | hab | hab
  · exfalso
    have : (l.filter (· ≤ a)).length ≤ (l.filter (· < b)).length :=
      length_filter_mono (fun x _ hx => by simp at hx ⊢; exact lt_of_le_of_lt hx hab)
    omega
  · exact hab
  · exfalso
    have : (l.filter (· ≤ b)).length ≤ (l.filter (· < a)).length :=
      length_filter_mono (fun x _ hx => by simp at hx ⊢; exact lt_of_le_of_lt hx hab)
    omega

variable [Inhabited α]

theorem sortSelect_eq_getElem {k : ℕ} {l : List α} (hk : k < l.length) :
    sortSelect k l = (l.insertionSort (· ≤ ·))[k]'(by rw [length_insertionSort]; exact hk) := by
  unfold sortSelect
  exact getD_eq_getElem _ _ _

theorem sortSelect_mem {k : ℕ} {l : List α} (hk : k < l.length) : sortSelect k l ∈ l := by
  rw [sortSelect_eq_getElem hk]
  exact (perm_insertionSort _ l).subset (getElem_mem _)

theorem sortSelect_rank {k : ℕ} {l : List α} (hk : k < l.length) :
    (l.filter (· < sortSelect k l)).length ≤ k ∧ k < (l.filter (· ≤ sortSelect k l)).length := by
  have hs : (l.insertionSort (· ≤ ·)).Pairwise (· ≤ ·) := pairwise_insertionSort _ l
  have hk' : k < (l.insertionSort (· ≤ ·)).length := by rw [length_insertionSort]; exact hk
  have h := rank_getElem_of_pairwise hs hk'
  rw [length_filter_insertionSort, length_filter_insertionSort] at h
  rw [sortSelect_eq_getElem hk]
  exact h

/-! ## The group medians -/

theorem median5_eq_sortSelect (g : List α) : median5 g = sortSelect (g.length / 2) g := rfl

theorem median5_mem {g : List α} (hg : g ≠ []) : median5 g ∈ g := by
  rw [median5_eq_sortSelect]
  apply sortSelect_mem
  have : 0 < g.length := length_pos_iff.2 hg
  omega

/-- The median of a nonempty group has at most `⌊|g|/2⌋` strictly smaller elements and more than
`⌊|g|/2⌋` elements `≤` it in the group. -/
theorem median5_rank {g : List α} (hg : g ≠ []) :
    (g.filter (· < median5 g)).length ≤ g.length / 2 ∧
      g.length / 2 < (g.filter (· ≤ median5 g)).length := by
  rw [median5_eq_sortSelect]
  apply sortSelect_rank
  have : 0 < g.length := length_pos_iff.2 hg
  omega

theorem mem_of_mem_medians {l : List α} {p : α} (hp : p ∈ (chunks5 l).map median5) : p ∈ l := by
  obtain ⟨g, hg, rfl⟩ := mem_map.1 hp
  rw [← chunks5_flatten l]
  exact mem_flatten.2 ⟨g, hg, median5_mem (ne_nil_of_mem_chunks5 hg)⟩

/-! ## Correctness of `momSelect` -/

/-- The pivot of a long list belongs to the list. -/
theorem pivot_mem {l : List α} (hl : momBase ≤ l.length)
    (ih : ∀ (k : ℕ) (l' : List α), l'.length < l.length → k < l'.length → momSelect k l' ∈ l') :
    momSelect (((chunks5 l).map median5).length / 2) ((chunks5 l).map median5) ∈ l := by
  have hne : l ≠ [] := by
    intro h; rw [h] at hl; unfold momBase at hl; simp at hl
  have hmlen : ((chunks5 l).map median5).length < l.length := by
    have := length_chunks5_le l
    rw [length_map]; unfold momBase at hl; omega
  have hmpos : 0 < ((chunks5 l).map median5).length := by
    rw [length_map]; exact length_pos_iff.2 (chunks5_ne_nil hne)
  exact mem_of_mem_medians (ih _ _ hmlen (by omega))

/-- The partition step of `momSelect` with the pivot `p` (the body of `momSelect` for long lists). -/
def momStep (k : ℕ) (l : List α) (p : α) : α :=
  if k < (l.filter (· < p)).length then
    if _hlo : (l.filter (· < p)).length < l.length then momSelect k (l.filter (· < p)) else p
  else if k < l.length - (l.filter (p < ·)).length then p
  else if _hhi : (l.filter (p < ·)).length < l.length then
    momSelect (k - (l.length - (l.filter (p < ·)).length)) (l.filter (p < ·))
  else p

/-- The unfolding of `momSelect` for long lists: the partition step with the median-of-medians pivot. -/
theorem momSelect_eq_momStep {k : ℕ} {l : List α} (hb : ¬ l.length < momBase) :
    momSelect k l =
      momStep k l (momSelect (((chunks5 l).map median5).length / 2) ((chunks5 l).map median5)) := by
  rw [momSelect, dif_neg hb]
  rfl

/-- The partition step is correct for every pivot `p ∈ l`, given correctness on shorter lists. -/
theorem momStep_spec {k : ℕ} {l : List α} (hk : k < l.length) {p : α} (hmem : p ∈ l)
    (ih : ∀ (k' : ℕ) (l' : List α), l'.length < l.length → k' < l'.length →
      momSelect k' l' ∈ l' ∧ (l'.filter (· < momSelect k' l')).length ≤ k' ∧
        k' < (l'.filter (· ≤ momSelect k' l')).length) :
    momStep k l p ∈ l ∧ (l.filter (· < momStep k l p)).length ≤ k ∧
      k < (l.filter (· ≤ momStep k l p)).length := by
  unfold momStep
  have hlo : (l.filter (· < p)).length < l.length :=
    length_filter_lt_length_iff_exists.2 ⟨p, hmem, by simp⟩
  have hhi : (l.filter (p < ·)).length < l.length :=
    length_filter_lt_length_iff_exists.2 ⟨p, hmem, by simp⟩
  have hle := length_filter_le_eq l p
  by_cases hk1 : k < (l.filter (· < p)).length
  · rw [if_pos hk1, dif_pos hlo]
    obtain ⟨hr, hr1, hr2⟩ := ih k (l.filter (· < p)) hlo hk1
    generalize momSelect k (l.filter (· < p)) = r at hr hr1 hr2 ⊢
    have hrp : r < p := by simpa using (mem_filter.1 hr).2
    have e1 : (l.filter (· < p)).filter (· < r) = l.filter (· < r) := by
      rw [filter_filter]
      exact filter_congr (fun x _ => by
        rw [← Bool.decide_and]
        exact decide_eq_decide.mpr ⟨fun h => h.1, fun h => ⟨h, lt_trans h hrp⟩⟩)
    have e2 : (l.filter (· < p)).filter (· ≤ r) = l.filter (· ≤ r) := by
      rw [filter_filter]
      exact filter_congr (fun x _ => by
        rw [← Bool.decide_and]
        exact decide_eq_decide.mpr ⟨fun h => h.1, fun h => ⟨h, lt_of_le_of_lt h hrp⟩⟩)
    rw [e1] at hr1
    rw [e2] at hr2
    exact ⟨(mem_filter.1 hr).1, hr1, hr2⟩
  rw [if_neg hk1]
  by_cases hk2 : k < l.length - (l.filter (p < ·)).length
  · rw [if_pos hk2]
    refine ⟨hmem, by omega, ?_⟩
    rw [hle]
    exact hk2
  rw [if_neg hk2, dif_pos hhi]
  have hk' : k - (l.length - (l.filter (p < ·)).length) < (l.filter (p < ·)).length := by omega
  obtain ⟨hr, hr1, hr2⟩ := ih _ (l.filter (p < ·)) hhi hk'
  generalize momSelect (k - (l.length - (l.filter (p < ·)).length)) (l.filter (p < ·)) = r at hr hr1 hr2 ⊢
  have hpr : p < r := by simpa using (mem_filter.1 hr).2
  have s1 := length_filter_split l (· < r) (· ≤ p)
  have s2 := length_filter_split l (· ≤ r) (· ≤ p)
  have e1 : l.filter (fun x => decide (x ≤ p) && decide (x < r)) = l.filter (· ≤ p) :=
    filter_congr (fun x _ => by
      rw [← Bool.decide_and]
      exact decide_eq_decide.mpr ⟨fun h => h.1, fun h => ⟨h, lt_of_le_of_lt h hpr⟩⟩)
  have e2 : l.filter (fun x => !decide (x ≤ p) && decide (x < r)) =
      (l.filter (p < ·)).filter (· < r) := by
    rw [filter_filter]
    exact filter_congr (fun x _ => by
      rw [← decide_not, ← Bool.decide_and, ← Bool.decide_and]
      exact decide_eq_decide.mpr ⟨fun h => ⟨h.2, not_le.1 h.1⟩, fun h => ⟨not_le.2 h.2, h.1⟩⟩)
  have e3 : l.filter (fun x => decide (x ≤ p) && decide (x ≤ r)) = l.filter (· ≤ p) :=
    filter_congr (fun x _ => by
      rw [← Bool.decide_and]
      exact decide_eq_decide.mpr ⟨fun h => h.1, fun h => ⟨h, (lt_of_le_of_lt h hpr).le⟩⟩)
  have e4 : l.filter (fun x => !decide (x ≤ p) && decide (x ≤ r)) =
      (l.filter (p < ·)).filter (· ≤ r) := by
    rw [filter_filter]
    exact filter_congr (fun x _ => by
      rw [← decide_not, ← Bool.decide_and, ← Bool.decide_and]
      exact decide_eq_decide.mpr ⟨fun h => ⟨h.2, not_le.1 h.1⟩, fun h => ⟨not_le.2 h.2, h.1⟩⟩)
  rw [e1, e2] at s1
  rw [e3, e4] at s2
  refine ⟨(mem_filter.1 hr).1, ?_, ?_⟩
  · rw [s1]; omega
  · rw [s2]; omega

/-- **Correctness of the median-of-medians selection**: for `k < l.length`, `momSelect k l ∈ l` and it
has at most `k` strictly smaller and more than `k` smaller-or-equal elements in `l`. -/
theorem momSelect_spec : ∀ (n : ℕ) (l : List α), l.length = n → ∀ k, k < l.length →
    momSelect k l ∈ l ∧ (l.filter (· < momSelect k l)).length ≤ k ∧
      k < (l.filter (· ≤ momSelect k l)).length := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro l hn k hk
  have ih' : ∀ (k' : ℕ) (l' : List α), l'.length < l.length → k' < l'.length →
      momSelect k' l' ∈ l' ∧ (l'.filter (· < momSelect k' l')).length ≤ k' ∧
        k' < (l'.filter (· ≤ momSelect k' l')).length :=
    fun k' l' hl' hk' => ih l'.length (by omega) l' rfl k' hk'
  by_cases hb : l.length < momBase
  · rw [momSelect, dif_pos hb]
    exact ⟨sortSelect_mem hk, sortSelect_rank hk⟩
  rw [momSelect_eq_momStep hb]
  exact momStep_spec hk (pivot_mem (not_lt.1 hb) (fun k' l' hl' hk' => (ih' k' l' hl' hk').1)) ih'

theorem momSelect_mem {k : ℕ} {l : List α} (hk : k < l.length) : momSelect k l ∈ l :=
  (momSelect_spec l.length l rfl k hk).1

theorem momSelect_rank {k : ℕ} {l : List α} (hk : k < l.length) :
    (l.filter (· < momSelect k l)).length ≤ k ∧ k < (l.filter (· ≤ momSelect k l)).length :=
  (momSelect_spec l.length l rfl k hk).2

/-- **`momSelect` is the `k`-th smallest element** (the element of index `k` of the sorted list). -/
theorem momSelect_eq_sortSelect {k : ℕ} {l : List α} (hk : k < l.length) :
    momSelect k l = sortSelect k l :=
  eq_of_rank (momSelect_rank hk) (sortSelect_rank hk)

end Order

end F2e2e.AEff.Select
