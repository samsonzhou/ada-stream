import F2e2e.AEff.RamCore
import F2e2e.AEff.Contracts

/-!
# R-θ / R-emit / R-halt (C-BANK): straight-line sequences and the emission calculus

Helpers shared by the C-BANK fragments of the cascade program (`RTheta.lean`, `REmit.lean`, `RHalt.lean`):

* `stmtSeq l`: the statements of `l` in order, then `nop` (the unrolled stage code, approved by C-CLOSE,
  13:15Z); `size_stmtSeq_le`;
* `Emits procs O s m vs c W`: run from any configuration with memory `m`, the statement `s` streams exactly
  the values `vs`, leaves the memory unchanged, costs at most `c` operations, keeps the watermark at most
  `max top W`, and makes no calls; its rules for `nop`, `emit`, `seq`, `ite`, and `stmtSeq` over a mapped or
  replicated list;
* `fragRes_of_resWithin_le`: from `RamCore`'s `ResWithin` to the contracts' `FragRes` (`Contracts.lean`, §2).

Only `RamCore` and `Contracts` are imported.
-/

namespace F2e2e.AEff

/-- `s₁; s₂; …; s_k; nop`: a straight-line sequence of statements (unrolled stage code). -/
def stmtSeq : List RamStmt → RamStmt
  | [] => .nop
  | s :: ss => .seq s (stmtSeq ss)

theorem stmtSeq_nil : stmtSeq [] = .nop := rfl

theorem stmtSeq_cons (s : RamStmt) (ss : List RamStmt) : stmtSeq (s :: ss) = .seq s (stmtSeq ss) := rfl

/-- The text of a sequence of statements of size at most `C` each. -/
theorem size_stmtSeq_le (C : ℕ) : ∀ (l : List RamStmt), (∀ s ∈ l, s.size ≤ C) →
    (stmtSeq l).size ≤ (C + 1) * l.length + 1
  | [], _ => by simp only [stmtSeq, RamStmt.size, List.length_nil, Nat.mul_zero, Nat.zero_add, le_refl]
  | s :: ss, h => by
    have h1 := h s (List.mem_cons.mpr (Or.inl rfl))
    have h2 := size_stmtSeq_le C ss fun t ht => h t (List.mem_cons.mpr (Or.inr ht))
    simp only [stmtSeq, RamStmt.size, List.length_cons]
    rw [Nat.mul_succ]
    omega

variable {procs : List RamStmt} {O : RamOracle}

/-! ## The emission calculus -/

/-- `s`, run from any configuration with memory `m`, terminates, streams exactly `vs`, leaves the memory
unchanged, costs at most `c` operations, keeps the watermark at most `max top W`, and makes no calls. -/
def Emits (procs : List RamStmt) (O : RamOracle) (s : RamStmt) (m : ℕ → ℝ) (vs : List ℝ) (c W : ℕ) :
    Prop :=
  ∀ σ : RamConf, σ.mem = m →
    WP procs O s (fun σ' => σ'.mem = σ.mem ∧ σ'.out = σ.out ++ vs ∧ ResWithin σ σ' c W 0) σ

theorem Emits.mono {s : RamStmt} {m : ℕ → ℝ} {vs : List ℝ} {c c' W W' : ℕ}
    (h : Emits procs O s m vs c W) (hc : c ≤ c') (hW : W ≤ W') : Emits procs O s m vs c' W' :=
  fun σ hσ => (h σ hσ).mono fun _ hq => ⟨hq.1, hq.2.1, hq.2.2.mono hc hW le_rfl⟩

theorem Emits.congr_out {s : RamStmt} {m : ℕ → ℝ} {vs vs' : List ℝ} {c W : ℕ}
    (h : Emits procs O s m vs c W) (hv : vs = vs') : Emits procs O s m vs' c W := by
  rw [← hv]
  exact h

theorem emits_nop (m : ℕ → ℝ) (W : ℕ) : Emits procs O .nop m [] 1 W := fun σ _ =>
  wp_nop ⟨rfl, by rw [List.append_nil]; rfl, (ResWithin.charge σ 1 0).mono le_rfl (Nat.zero_le W) le_rfl⟩

theorem emits_emit {e : RamExp} {m : ℕ → ℝ} {v : ℝ} {W : ℕ} (he : EvalLE O m e v W) :
    Emits procs O (.emit e) m [v] (e.size + 1) W := fun σ hσ => by
  rw [← hσ] at he
  exact wp_emit_res he fun _ h1 h2 h3 => ⟨h1, h2, h3⟩

theorem emits_seq {s₁ s₂ : RamStmt} {m : ℕ → ℝ} {vs ws : List ℝ} {c₁ c₂ W : ℕ}
    (h₁ : Emits procs O s₁ m vs c₁ W) (h₂ : Emits procs O s₂ m ws c₂ W) :
    Emits procs O (.seq s₁ s₂) m (vs ++ ws) (c₁ + c₂) W := fun σ hσ => by
  apply wp_seq
  refine (h₁ σ hσ).mono fun τ hτ => ?_
  obtain ⟨hm, ho, hr⟩ := hτ
  refine (h₂ τ (hm.trans hσ)).mono fun σ' hσ' => ?_
  obtain ⟨hm', ho', hr'⟩ := hσ'
  refine ⟨hm'.trans hm, ?_, ?_⟩
  · rw [ho', ho, List.append_assoc]
  · exact (hr.trans hr').mono le_rfl (max_le le_rfl le_rfl) (max_le le_rfl le_rfl)

theorem emits_ite {c : RamCond} {s₁ s₂ : RamStmt} {m : ℕ → ℝ} {vs : List ℝ} {b : Bool} {C W : ℕ}
    (hc : CondLE O m c b W) (h : Emits procs O (if b then s₁ else s₂) m vs C W) :
    Emits procs O (.ite c s₁ s₂) m vs (c.size + 1 + C) W := fun σ hσ => by
  obtain ⟨t, ht, hce⟩ := hc
  rw [← hσ] at hce
  refine wp_ite hce ((h (σ.charge (c.size + 1) t) hσ).mono fun σ' hσ' => ?_)
  obtain ⟨hm, ho, hr⟩ := hσ'
  exact ⟨hm, ho, ((ResWithin.charge σ _ t).trans hr).mono le_rfl (max_le ht le_rfl) (max_le le_rfl le_rfl)⟩

/-- A sequence over a list: each element streams its block, at most `C` operations each. -/
theorem emits_stmtSeq_map {ι : Type} (f : ι → RamStmt) (g : ι → List ℝ) {m : ℕ → ℝ} {C W : ℕ} :
    ∀ (l : List ι), (∀ x ∈ l, Emits procs O (f x) m (g x) C W) →
      Emits procs O (stmtSeq (l.map f)) m (l.flatMap g) (C * l.length + 1) W
  | [], _ => by
    rw [List.map_nil, List.flatMap_nil, List.length_nil, Nat.mul_zero, Nat.zero_add]
    exact emits_nop m W
  | x :: l, h => by
    have h1 := h x (List.mem_cons.mpr (Or.inl rfl))
    have h2 := emits_stmtSeq_map f g l fun y hy => h y (List.mem_cons.mpr (Or.inr hy))
    rw [List.map_cons, stmtSeq_cons, List.flatMap_cons]
    refine (emits_seq h1 h2).mono ?_ le_rfl
    rw [List.length_cons, Nat.mul_succ]
    omega

/-- A sequence over a list, one value per element. -/
theorem emits_stmtSeq_map_single {ι : Type} (f : ι → RamStmt) (g : ι → ℝ) {m : ℕ → ℝ} {C W : ℕ}
    (l : List ι) (h : ∀ x ∈ l, Emits procs O (f x) m [g x] C W) :
    Emits procs O (stmtSeq (l.map f)) m (l.map g) (C * l.length + 1) W := by
  have h' := emits_stmtSeq_map f (fun x => [g x]) l h
  rw [← List.map_eq_flatMap] at h'
  exact h'

/-- `N` copies of a statement streaming one value. -/
theorem emits_stmtSeq_replicate {s : RamStmt} {m : ℕ → ℝ} {v : ℝ} {C W : ℕ}
    (h : Emits procs O s m [v] C W) :
    ∀ N : ℕ, Emits procs O (stmtSeq (List.replicate N s)) m (List.replicate N v) (C * N + 1) W
  | 0 => by
    rw [List.replicate_zero, List.replicate_zero, Nat.mul_zero, Nat.zero_add]
    exact emits_nop m W
  | N + 1 => by
    rw [List.replicate_succ, List.replicate_succ, stmtSeq_cons]
    refine ((emits_seq h (emits_stmtSeq_replicate h N)).congr_out List.singleton_append).mono ?_ le_rfl
    rw [Nat.mul_succ]
    omega

/-! ## Direct reads -/

/-- The expression `M[a]` (a direct read of the cell `a`). -/
def emRd (a : ℕ) : RamExp := .rd (.lit (a : ℝ))

theorem size_emRd (a : ℕ) : (emRd a).size = 2 := rfl

theorem evalLE_emRd (m : ℕ → ℝ) (a W : ℕ) (h : a + 1 ≤ W) : EvalLE O m (emRd a) (m a) W :=
  EvalLE.rd_nat (EvalLE.lit m (a : ℝ) W) h

/-! ## From `ResWithin` to the contracts' `FragRes` -/

theorem fragRes_of_resWithin_le {c L n C W d : ℕ} {σ σ' : RamConf} (h : ResWithin σ σ' C W d)
    (hC : C ≤ c * (n + L + 1)) (hW : W ≤ sBase L n + c * (n + L + 1)) (hd : d ≤ c * (n + L + 1)) :
    FragRes c L n σ σ' := by
  unfold FragRes
  exact ⟨h.depth, le_trans h.ops (Nat.add_le_add_left hC _), le_trans h.top (max_le_max le_rfl hW),
    le_trans h.peak (max_le_max le_rfl (Nat.add_le_add_left hd _))⟩

end F2e2e.AEff
