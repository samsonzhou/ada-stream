import F2e2e.AEff.RUpdCodeBase

/-!
# A_eff, piece R-upd: evaluation and stability helpers (owner: C-ALG)

(Independent of the selection / water-filling modules; `F2e2e/AEff/RUpdEval.lean` re-exports it together with
the full code.)

Evaluation of the R-upd expressions (`cell`, `tabAt`, natural sums) with bounded watermarks, and their
loop-stable forms for C-ORC's map loops (`StableExp`).
-/

namespace F2e2e.AEff.RUpd

open F2e2e.AEff

variable {O : RamOracle}

theorem evalLE_cell {m : ℕ → ℝ} {a w : ℕ} {v : ℝ} (hm : m a = v) (hw : a + 1 ≤ w) :
    EvalLE O m (cell a) v w := by
  have h := EvalLE.rd_nat (EvalLE.lit (O := O) m (a : ℝ) w) hw
  rwa [hm] at h

theorem evalLE_add_nat {m : ℕ → ℝ} {a b : RamExp} {x y w : ℕ} (ha : EvalLE O m a (x : ℝ) w)
    (hb : EvalLE O m b (y : ℝ) w) : EvalLE O m (.add a b) ((x + y : ℕ) : ℝ) w := by
  have h := EvalLE.add ha hb
  rwa [← Nat.cast_add] at h

theorem evalLE_tabAt {m : ℕ → ℝ} {t i r w : ℕ} {v : ℝ} (hi : m i = (r : ℝ)) (ht : m (t + r) = v)
    (hwi : i + 1 ≤ w) (hwt : t + r + 1 ≤ w) : EvalLE O m (tabAt t i) v w := by
  have h1 : EvalLE O m (.add (.lit (t : ℝ)) (cell i)) ((t + r : ℕ) : ℝ) w :=
    evalLE_add_nat (EvalLE.lit m (t : ℝ) w) (evalLE_cell hi hwi)
  have h := EvalLE.rd_nat h1 hwt
  rwa [ht] at h

theorem stableExp_cell {P : ℕ → Prop} {σ₀ : RamConf} {c W : ℕ} {v : ℝ} (hP : ¬ P c) (hW : c + 1 ≤ W)
    (hv : σ₀.mem c = v) : StableExp O P σ₀ (cell c) v W :=
  StableExp.of_eq (stableExp_rd_lit hP hW) hv

theorem stableExp_tabAt {P : ℕ → Prop} {σ₀ : RamConf} {t i r W : ℕ} {v : ℝ} (hPi : ¬ P i)
    (hPt : ¬ P (t + r)) (hi : σ₀.mem i = (r : ℝ)) (ht : σ₀.mem (t + r) = v) (hWi : i + 1 ≤ W)
    (hWt : t + r + 1 ≤ W) : StableExp O P σ₀ (tabAt t i) v W := by
  have h1 : StableExp O P σ₀ (.add (.lit (t : ℝ)) (cell i)) ((t + r : ℕ) : ℝ) W :=
    StableExp.of_eq (StableExp.add (stableExp_lit O P σ₀ (t : ℝ) W) (stableExp_rd_lit hPi hWi))
      (by rw [hi, Nat.cast_add])
  exact StableExp.of_eq (StableExp.rd_nat h1 hPt hWt) ht

/-- The round temporaries are below `32`; every table cell and array cell is at least `64`. -/
theorem tabBase_ge (L j : ℕ) : 64 ≤ tabBase L j := by unfold tabBase; omega

theorem aPay_ge (L n : ℕ) : 64 + 16 * (L + 2) ≤ aPay L n := by unfold aPay arrBase; omega

theorem tab_lt_aPay {L n j r : ℕ} (hj : j < 16) (hr : r < L + 2) : tabBase L j + r < aPay L n := by
  unfold tabBase aPay arrBase
  have : j * (L + 2) + (L + 2) ≤ 16 * (L + 2) := by
    have := Nat.mul_le_mul_right (L + 2) (show j + 1 ≤ 16 by omega)
    linarith
  omega

end F2e2e.AEff.RUpd
