import Mathlib
import F2e2e.Spec

/-!
# U1: the value of a register and the bit-level arithmetic (generic part)

`regVal r`: the natural number of the register `r` (least significant bit first). Basic facts:
`regVal_append`, `regVal_lt`, `regVal_bits` (`Nat.bits` is a register of `n`), `regVal_map_not`
(complement), `regVal_take`, `regVal_replicate_false`; the full-adder identity `fullAdd_toNat`; the
sign-magnitude decoding `smVal` and `smVal_bits`.
-/

namespace F2e2e.Machine

/-! ## The value of a register -/

/-- The value of a register (least significant bit first). -/
def regVal : List Bool → ℕ
  | [] => 0
  | b :: r => b.toNat + 2 * regVal r

@[simp] theorem regVal_nil : regVal [] = 0 := rfl

@[simp] theorem regVal_cons (b : Bool) (r : List Bool) : regVal (b :: r) = b.toNat + 2 * regVal r := rfl

theorem regVal_append (r s : List Bool) : regVal (r ++ s) = regVal r + 2 ^ r.length * regVal s := by
  induction r with
  | nil => simp
  | cons b r ih =>
    simp only [List.cons_append, regVal_cons, ih, List.length_cons, pow_succ]
    ring

theorem regVal_lt (r : List Bool) : regVal r < 2 ^ r.length := by
  induction r with
  | nil => simp
  | cons b r ih =>
    simp only [regVal_cons, List.length_cons, pow_succ]
    have : b.toNat ≤ 1 := Bool.toNat_le b
    omega

@[simp] theorem regVal_replicate_false (n : ℕ) : regVal (List.replicate n false) = 0 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [List.replicate_succ, ih]

theorem regVal_singleton (b : Bool) : regVal [b] = b.toNat := by simp

/-- `Nat.bits n` is a register of value `n`. -/
theorem regVal_bits (n : ℕ) : regVal (Nat.bits n) = n := by
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · simp [Nat.zero_bits]
    · rcases Nat.even_or_odd n with ⟨m, hm⟩ | ⟨m, hm⟩
      · have hm0 : m ≠ 0 := by omega
        have e : n = 2 * m := by omega
        rw [e, Nat.bit0_bits m hm0, regVal_cons, ih m (by omega)]
        simp
      · rw [hm, Nat.bit1_bits m, regVal_cons, ih m (by omega)]
        simp
        ring

theorem length_bits (n : ℕ) : (Nat.bits n).length = Nat.size n := Nat.size_eq_bits_len n

/-- The complement: `regVal (¬r) + regVal r + 1 = 2^|r|`. -/
theorem regVal_map_not (r : List Bool) : regVal (r.map not) + regVal r + 1 = 2 ^ r.length := by
  induction r with
  | nil => simp
  | cons b r ih =>
    simp only [List.map_cons, regVal_cons, List.length_cons, pow_succ]
    cases b <;> simp <;> omega

/-- Zero extension does not change the value. -/
theorem regVal_append_replicate_false (r : List Bool) (n : ℕ) :
    regVal (r ++ List.replicate n false) = regVal r := by
  rw [regVal_append, regVal_replicate_false, mul_zero, add_zero]

theorem regVal_take (r : List Bool) (n : ℕ) : regVal (r.take n) = regVal r % 2 ^ n := by
  have h := regVal_append (r.take n) (r.drop n)
  rw [List.take_append_drop] at h
  rcases le_or_gt n r.length with hn | hn
  · have hl : (r.take n).length = n := List.length_take_of_le hn
    rw [hl] at h
    have hlt := regVal_lt (r.take n)
    rw [hl] at hlt
    rw [h, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hlt]
  · rw [List.take_of_length_le hn.le]
    have hlt := regVal_lt r
    exact (Nat.mod_eq_of_lt (lt_of_lt_of_le hlt (Nat.pow_le_pow_right (by norm_num) hn.le))).symm

/-- A register is zero iff it has no `1` bit. -/
theorem regVal_eq_zero_iff (r : List Bool) : regVal r = 0 ↔ r.any id = false := by
  induction r with
  | nil => simp
  | cons b r ih =>
    cases b <;> simp [ih]

/-! ## The full adder -/

/-- The full-adder identity: `sum + 2·carry = a + b + c`. -/
theorem fullAdd_toNat (a b c : Bool) :
    ((a ^^ b) ^^ c).toNat + 2 * ((a && b) || (c && (a ^^ b))).toNat = a.toNat + b.toNat + c.toNat := by
  cases a <;> cases b <;> cases c <;> rfl

/-! ## Sign-magnitude decoding -/

/-- The integer of a sign bit and a magnitude register. -/
def smVal (s : Bool) (x : List Bool) : ℤ := if s then -(regVal x : ℤ) else (regVal x : ℤ)

/-- The sign bit and the magnitude register of an integer decode to it. -/
theorem smVal_bits (z : ℤ) : smVal (decide (z < 0)) (Nat.bits z.natAbs) = z := by
  unfold smVal
  rw [regVal_bits]
  by_cases hz : z < 0
  · rw [if_pos (by simpa using hz)]
    omega
  · rw [if_neg (by simpa using hz)]
    omega

/-! ## The Spec's `bitsNat` and `trimBits` -/

theorem bitsNat_eq_regVal (m : List Bool) : bitsNat m = regVal m := by
  induction m with
  | nil => rfl
  | cons b m ih =>
    show 2 * bitsNat m + (if b then 1 else 0) = b.toNat + 2 * regVal m
    rw [ih]
    cases b
    · simp
    · simp; ring

theorem regVal_take_succ (x : List Bool) (n : ℕ) :
    regVal (x.take (n + 1)) = (x.headD false).toNat + 2 * regVal (x.tail.take n) := by
  cases x with
  | nil => simp
  | cons a x => simp

theorem regVal_take_lt (x : List Bool) (n : ℕ) : regVal (x.take n) < 2 ^ n :=
  lt_of_lt_of_le (regVal_lt _)
    (Nat.pow_le_pow_right (by norm_num) (by rw [List.length_take]; exact min_le_left _ _))

theorem regVal_take_of_le {x : List Bool} {n : ℕ} (h : x.length ≤ n) : regVal (x.take n) = regVal x := by
  rw [List.take_of_length_le h]

/-- `trimBits` drops high zero bits: `m = trimBits m ++ zeros`. -/
theorem trimBits_spec (m : List Bool) :
    ∃ k, m = trimBits m ++ List.replicate k false := by
  unfold trimBits
  refine ⟨(m.reverse.takeWhile (fun b => !b)).length, ?_⟩
  have h1 : m.reverse = m.reverse.takeWhile (fun b => !b) ++ m.reverse.dropWhile (fun b => !b) :=
    (List.takeWhile_append_dropWhile).symm
  have h2 : m.reverse.takeWhile (fun b => !b) =
      List.replicate (m.reverse.takeWhile (fun b => !b)).length false := by
    apply List.eq_replicate_iff.mpr
    refine ⟨rfl, fun b hb => ?_⟩
    have := List.mem_takeWhile_imp hb
    simpa using this
  conv_lhs => rw [← List.reverse_reverse m, h1, h2]
  simp [List.reverse_append, List.reverse_replicate]

theorem regVal_trimBits (m : List Bool) : regVal (trimBits m) = regVal m := by
  obtain ⟨k, hk⟩ := trimBits_spec m
  conv_rhs => rw [hk]
  rw [regVal_append_replicate_false]

theorem length_trimBits_le (m : List Bool) : (trimBits m).length ≤ m.length := by
  obtain ⟨k, hk⟩ := trimBits_spec m
  have := congrArg List.length hk
  simp at this
  omega

/-! ## The ripple-carry adder `addTrace` -/

/-- The adder without complement: `|sum| = |acc| + n` and
`sum + 2^(|acc|+n)·carry = acc + 2^|acc|·(x mod 2^n + y mod 2^n + k)`. -/
theorem addTrace_false_spec (n : ℕ) : ∀ (x y : List Bool) (k : Bool) (acc : List Bool),
    (addTrace false n x y k acc).1.length = acc.length + n ∧
    regVal (addTrace false n x y k acc).1 + 2 ^ (acc.length + n) * (addTrace false n x y k acc).2.1.toNat =
      regVal acc + 2 ^ acc.length * (regVal (x.take n) + regVal (y.take n) + k.toNat) := by
  induction n with
  | zero => intro x y k acc; simp [addTrace]
  | succ n ih =>
    intro x y k acc
    simp only [addTrace]
    set a := x.headD false with ha
    set b := xor false (y.headD false) with hb
    obtain ⟨h1, h2⟩ := ih x.tail y.tail ((a && b) || (k && xor a b)) (acc ++ [xor (xor a b) k])
    refine ⟨by rw [h1]; simp; ring, ?_⟩
    have hfa := fullAdd_toNat a b k
    have hb' : b = y.headD false := by rw [hb]; simp
    rw [List.length_append, List.length_singleton, regVal_append, regVal_singleton] at h2
    rw [regVal_take_succ x n, regVal_take_succ y n, ← ha, ← hb']
    have e1 : acc.length + 1 + n = acc.length + (n + 1) := by ring
    rw [e1] at h2
    rw [h2]
    have e2 : (2 : ℕ) ^ (acc.length + 1) = 2 ^ acc.length * 2 := by rw [pow_succ]
    rw [e2]
    have e3 : xor (xor a b) k = ((a ^^ b) ^^ k) := rfl
    have e4 : ((a && b) || (k && xor a b)) = ((a && b) || (k && (a ^^ b))) := rfl
    rw [e3, e4]
    generalize ((a ^^ b) ^^ k).toNat = sb at hfa ⊢
    generalize ((a && b) || (k && (a ^^ b))).toNat = cc at hfa ⊢
    generalize (2 : ℕ) ^ acc.length = P
    nlinarith [hfa]

/-- The adder with complement: `|sum| = |acc| + n` and
`sum + 2^(|acc|+n)·carry + 2^|acc|·(y mod 2^n) = acc + 2^|acc|·(x mod 2^n + (2^n − 1) + k)`. -/
theorem addTrace_true_spec (n : ℕ) : ∀ (x y : List Bool) (k : Bool) (acc : List Bool),
    (addTrace true n x y k acc).1.length = acc.length + n ∧
    regVal (addTrace true n x y k acc).1 + 2 ^ (acc.length + n) * (addTrace true n x y k acc).2.1.toNat +
        2 ^ acc.length * regVal (y.take n) + 2 ^ acc.length =
      regVal acc + 2 ^ acc.length * (regVal (x.take n) + 2 ^ n + k.toNat) := by
  induction n with
  | zero => intro x y k acc; simp [addTrace]; ring
  | succ n ih =>
    intro x y k acc
    simp only [addTrace]
    set a := x.headD false with ha
    set b := xor true (y.headD false) with hb
    obtain ⟨h1, h2⟩ := ih x.tail y.tail ((a && b) || (k && xor a b)) (acc ++ [xor (xor a b) k])
    refine ⟨by rw [h1]; simp; ring, ?_⟩
    have hfa := fullAdd_toNat a b k
    have hb' : b.toNat + (y.headD false).toNat = 1 := by
      rw [hb]; cases y.headD false <;> rfl
    rw [List.length_append, List.length_singleton, regVal_append, regVal_singleton] at h2
    rw [regVal_take_succ x n, regVal_take_succ y n, ← ha]
    have e1 : acc.length + 1 + n = acc.length + (n + 1) := by ring
    rw [e1] at h2
    have e2 : (2 : ℕ) ^ (acc.length + 1) = 2 ^ acc.length * 2 := by rw [pow_succ]
    have e5 : (2 : ℕ) ^ (n + 1) = 2 ^ n * 2 := by rw [pow_succ]
    rw [e2] at h2
    rw [e5]
    have e3 : xor (xor a b) k = ((a ^^ b) ^^ k) := rfl
    have e4 : ((a && b) || (k && xor a b)) = ((a && b) || (k && (a ^^ b))) := rfl
    rw [e3, e4] at h2
    generalize ((a ^^ b) ^^ k).toNat = sb at hfa h2
    generalize ((a && b) || (k && (a ^^ b))).toNat = cc at hfa h2
    generalize (2 : ℕ) ^ acc.length = P at h2 ⊢
    generalize (y.headD false).toNat = yb at hb' ⊢
    nlinarith [hfa, hb', h2]

/-- Addition of magnitudes: with `n ≥ max |x| |y| + 1` positions, carry-in `0` and an empty sum, the sum
bits are `x + y` and the final carry is `0`. -/
theorem addTrace_add {x y : List Bool} {n : ℕ} (hx : x.length < n) (hy : y.length < n) :
    regVal (addTrace false n x y false []).1 = regVal x + regVal y ∧
      (addTrace false n x y false []).2.1 = false := by
  obtain ⟨-, h2⟩ := addTrace_false_spec n x y false []
  simp only [List.length_nil, zero_add, pow_zero, regVal_nil, one_mul, Bool.toNat_false,
    add_zero] at h2
  rw [regVal_take_of_le hx.le, regVal_take_of_le hy.le] at h2
  have hxl := regVal_lt x
  have hyl := regVal_lt y
  have hx2 : 2 ^ x.length ≤ 2 ^ (n - 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hy2 : 2 ^ y.length ≤ 2 ^ (n - 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hn : 2 ^ n = 2 * 2 ^ (n - 1) := by
    rw [← pow_succ']; congr 1; omega
  cases hc : (addTrace false n x y false []).2.1
  · rw [hc] at h2; simp at h2; exact ⟨h2, rfl⟩
  · rw [hc] at h2; simp at h2; omega

/-- Subtraction and comparison of magnitudes: with `n ≥ max |x| |y|` positions, complement and carry-in
`1`, the final carry is `1` iff `x ≥ y`, and then the sum bits are `x − y`. -/
theorem addTrace_sub {x y : List Bool} {n : ℕ} (hx : x.length ≤ n) (hy : y.length ≤ n) :
    (addTrace true n x y true []).2.1 = decide (regVal y ≤ regVal x) ∧
      (regVal y ≤ regVal x → regVal (addTrace true n x y true []).1 = regVal x - regVal y) := by
  obtain ⟨h1, h2⟩ := addTrace_true_spec n x y true []
  simp only [List.length_nil, zero_add, pow_zero, regVal_nil, one_mul, Bool.toNat_true] at h1 h2
  rw [regVal_take_of_le hx, regVal_take_of_le hy] at h2
  have hs := regVal_lt (addTrace true n x y true []).1
  rw [h1] at hs
  have hxl : regVal x < 2 ^ n := lt_of_lt_of_le (regVal_lt x) (Nat.pow_le_pow_right (by norm_num) hx)
  have hyl : regVal y < 2 ^ n := lt_of_lt_of_le (regVal_lt y) (Nat.pow_le_pow_right (by norm_num) hy)
  cases hc : (addTrace true n x y true []).2.1
  · rw [hc] at h2
    simp at h2
    refine ⟨by simp; omega, fun hle => by omega⟩
  · rw [hc] at h2
    simp at h2
    refine ⟨by simp; omega, fun _ => by omega⟩

/-! ## Maxima of traces -/

theorem le_foldr_max {l : List ℕ} {x : ℕ} (hx : x ∈ l) : x ≤ l.foldr max 0 := by
  induction l with
  | nil => simp at hx
  | cons y l ih =>
    simp only [List.foldr_cons]
    rcases List.mem_cons.mp hx with rfl | hx
    · exact le_max_left _ _
    · exact le_trans (ih hx) (le_max_right _ _)

theorem foldr_max_le {l : List ℕ} {B : ℕ} (h : ∀ x ∈ l, x ≤ B) : l.foldr max 0 ≤ B := by
  induction l with
  | nil => simp
  | cons y l ih =>
    simp only [List.foldr_cons]
    exact max_le (h y (by simp)) (ih fun x hx => h x (by simp [hx]))

end F2e2e.Machine
