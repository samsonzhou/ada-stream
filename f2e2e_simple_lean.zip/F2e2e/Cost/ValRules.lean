import F2e2e.Cost.Generic
import F2e2e.Cost.Arith.Basic

/-!
# Forward rules for `EvalsVal` derivations (package L)

Convenience rules for building `EvalsVal` derivations of straight-line code, each with the
value-bound premise of the produced value in the form `valSize result ≤ M`:
`ite_true`, `ite_false`, `head`, `tail`, `isNil_nil`, `isNil_cons`, `cons`, `add`, `sub`, `mul`,
`div`, `mod`, `lt`, `eq`, `triple` (`Arith.eTriple`), `var0`, `var1`, `var2`, `var3`, and `lit'`
(literals in the form `valSize (Val.int z) ≤ M`).

For straight-line code (no `call`/`loop`) use symbolic evaluation instead: `EvalsVal.of_eval` /
`EvalsVal.of_evalT` (compute `eval` with the `eval_succ_*` simp lemmas and bound only the peak; no
cost bound), or convert a cut2-style `EvalsLe` spec with `EvalsLe.toVal`.
-/

namespace F2e2e.Cost

namespace EvalsVal

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem var0 {v : Val} {rest : List Val} : EvalsVal prog M (v :: rest) [] (.inl (Expr.var 0)) v :=
  EvalsVal.var rfl

theorem var1 {v w : Val} {rest : List Val} :
    EvalsVal prog M (w :: v :: rest) [] (.inl (Expr.var 1)) v :=
  EvalsVal.var rfl

theorem var2 {v w u : Val} {rest : List Val} :
    EvalsVal prog M (u :: w :: v :: rest) [] (.inl (Expr.var 2)) v :=
  EvalsVal.var rfl

theorem var3 {v w u t : Val} {rest : List Val} :
    EvalsVal prog M (t :: u :: w :: v :: rest) [] (.inl (Expr.var 3)) v :=
  EvalsVal.var rfl

theorem ite_true {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env bc (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsVal prog M env bv (.inl t) v) :
    EvalsVal prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite hc (by rw [if_pos hz]; exact ht)

theorem ite_false {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env bc (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsVal prog M env bv (.inl f) v) :
    EvalsVal prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem head {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env ba (.inl a) (Val.list (x :: l))) (hM : valSize x ≤ M) :
    EvalsVal prog M env ba (.inl (Expr.un UnOp.head a)) x :=
  EvalsVal.un (c := 1) ha rfl hM

theorem tail {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env ba (.inl a) (Val.list (x :: l))) (hM : valSize (Val.list l) ≤ M) :
    EvalsVal prog M env ba (.inl (Expr.un UnOp.tail a)) (Val.list l) :=
  EvalsVal.un (c := 1) ha rfl hM

theorem isNil_nil {a : Expr} {ba : List Bool}
    (ha : EvalsVal prog M env ba (.inl a) (Val.list [])) (hM : 2 ≤ M) :
    EvalsVal prog M env ba (.inl (Expr.un UnOp.isNil a)) (Val.int 1) :=
  EvalsVal.un (c := 1) ha rfl (by simpa using hM)

theorem isNil_cons {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env ba (.inl a) (Val.list (x :: l))) (hM : 1 ≤ M) :
    EvalsVal prog M env ba (.inl (Expr.un UnOp.isNil a)) (Val.int 0) :=
  EvalsVal.un (c := 1) ha rfl (by simpa using hM)

theorem lit' {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.lit z)) (Val.int z) :=
  EvalsVal.lit hM

theorem cons {a b : Expr} {ba bb : List Bool} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env ba (.inl a) x) (hb : EvalsVal prog M env bb (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.cons a b)) (Val.list (x :: l)) :=
  EvalsVal.bin (c := 1) ha hb (by cases x <;> rfl) hM

theorem add {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.add a b)) (Val.int (x + y)) :=
  EvalsVal.bin ha hb rfl hM

theorem sub {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x - y)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.sub a b)) (Val.int (x - y)) :=
  EvalsVal.bin ha hb rfl hM

theorem mul {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x * y)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.mul a b)) (Val.int (x * y)) :=
  EvalsVal.bin ha hb rfl hM

theorem div {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.div a b)) (Val.int (x / y)) :=
  EvalsVal.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem mod {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x % y)) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.mod a b)) (Val.int (x % y)) :=
  EvalsVal.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem lt {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.lt a b))
      (Val.int (if x < y then 1 else 0)) :=
  EvalsVal.bin ha hb rfl (by split_ifs <;> simp <;> omega)

theorem eq {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsVal prog M env ba (.inl a) (Val.int x))
    (hb : EvalsVal prog M env bb (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin BinOp.eq a b))
      (Val.int (if x = y then 1 else 0)) :=
  EvalsVal.bin ha hb rfl (by split_ifs <;> simp <;> omega)

/-- `Arith.eTriple a b c` builds `[x, y, z]`. -/
theorem triple {a b c : Expr} {ba bb bc : List Bool} {x y z : Val}
    (ha : EvalsVal prog M env ba (.inl a) x) (hb : EvalsVal prog M env bb (.inl b) y)
    (hc : EvalsVal prog M env bc (.inl c) z) (hM : valSize (Val.list [x, y, z]) ≤ M) :
    EvalsVal prog M env (ba ++ (bb ++ bc)) (.inl (Arith.eTriple a b c)) (Val.list [x, y, z]) := by
  have h0 : valSize (Val.list []) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h1 : valSize (Val.list [z]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h2 : valSize (Val.list [y, z]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hz := cons hc (EvalsVal.nil h0) h1
  rw [List.append_nil] at hz
  exact cons ha (cons hb hz h2) hM

/-- **Symbolic evaluation for `EvalsVal`.** Compute `eval` on the tape `bits` with an explicit fuel
(e.g. by `simp` with the `eval_succ_*` lemmas) and bound the resulting peak by `base + M`; no
cost bound is needed. Typically used with `base = 0` for straight-line code. -/
theorem of_evalT {base : ℕ} {bits : List Bool} {e : Expr} {v : Val} (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env bits e = some (v, c, p, []) ∧ p ≤ base + M) :
    EvalsVal prog M env bits (.inl e) v := by
  obtain ⟨c, p, h, hp⟩ := h
  exact (EvalsToT.toVal ⟨fuel, h⟩).mono_M (by omega)

/-- **Symbolic evaluation for deterministic `EvalsVal`** (empty tape, see `of_evalT`). -/
theorem of_eval {base : ℕ} {e : Expr} {v : Val} (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env [] e = some (v, c, p, []) ∧ p ≤ base + M) :
    EvalsVal prog M env [] (.inl e) v :=
  of_evalT fuel h

end EvalsVal

end F2e2e.Cost
