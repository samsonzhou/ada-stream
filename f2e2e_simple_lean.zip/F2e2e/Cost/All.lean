import F2e2e.Cost.Facts
import F2e2e.Cost.Enc
import F2e2e.Cost.Calculus
import F2e2e.Cost.Space
import F2e2e.Cost.Index
import F2e2e.Cost.Assembly
import F2e2e.Cost.Lib.Util
import F2e2e.Cost.Lib.Length
import F2e2e.Cost.Lib.RevAppend
import F2e2e.Cost.Lib.Sum
import F2e2e.Cost.Lib.Get
import F2e2e.Cost.Lib.Set
import F2e2e.Cost.Lib.TakeDrop
import F2e2e.Cost.Lib.ZipWithAdd
import F2e2e.Cost.Lib.LinComb
import F2e2e.Cost.Lib.Replicate
import F2e2e.Cost.Lib.Count
import F2e2e.Cost.Lib.Table
import F2e2e.Cost.Lib.Map
import F2e2e.Cost.Lib.Fold
import F2e2e.Cost.Lib.Eq
import F2e2e.Cost.Lib.Coins
import F2e2e.Cost.Arith.Basic
import F2e2e.Cost.Arith.AExp
import F2e2e.Cost.Arith.AExpSpec
import F2e2e.Cost.Arith.AExpBound
import F2e2e.Cost.Arith.Median
import F2e2e.Cost.Arith.Helpers
import F2e2e.Cost.Arith.LowerMed
import F2e2e.Cost.Generic
import F2e2e.Cost.ValRules
import F2e2e.Cost.BitProgBridge
import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.MapB
import F2e2e.Cost.Lib.MapIdx
import F2e2e.Cost.Lib.GetOpt
import F2e2e.Cost.Examples

/-!
# The f2e2e DSL cost library (aggregator and user guide)

Imports every module of `F2e2e/Cost/` (except 17fc0802's `Machine*`).

## Layers
* Semantics of the Spec's cost model with fresh bits (`Facts`): fuel monotonicity, determinism,
  tape frame lemmas. Encodings (`Enc`).
* cut2's cost calculus with consumed bits (`Calculus`: `EvalsLeT`/`EvalsLe`, loop rules, `RunsOn`
  bridges), space-only judgments (`Space`), program assembly (`Assembly`: `mkProg`, lookups by
  `rfl`), the ported cut2 list and arithmetic libraries (`Lib/*`, `Arith/*`), fresh-bit routines
  (`Lib/Coins`).
* Package L (time-free, value-bound style): `EvalsVal prog M env bits t v` (`Generic`) — exact
  consumed bits, every produced value `≤ M`, no cost or peak bookkeeping; forward rules and
  symbolic evaluation `EvalsVal.of_eval` (`ValRules`); bit programs (`BitProgBridge`:
  `Implements prog M env e enc p`); combinators `foldB` (`Lib/BitFold`), `mapB`/`replicateB`
  (`Lib/MapB`), `mapIdxB` + `modifyAt`/`setAt`/`mapFrom` (`Lib/MapIdx`), `getOpt` (`Lib/GetOpt`);
  helpers `natSqrt`, `clampZ`, `roundMantZ`, `floorSqrtND`, `ceilSqrtND` (`Arith/Helpers`),
  `lowerMedZ` (`Arith/LowerMed`).

## Recipe (package L)
1. Straight-line code: `apply EvalsVal.of_eval (base := 0) 20`, `simp only` with the `eval_succ_*`
   lemmas, `refine ⟨_, _, rfl, ?_⟩`, bound the peak by `M` (`omega`). Calls and loops: forward
   rules (`EvalsVal.call`, `.letE`, `.loop`, `EvalsVal.loop_of_measure`, `foldB_impl`, …).
2. Library routines with cut2-style specs (`X_spec : EvalsLe prog base … (base + S_X)`): use
   `(X_spec … 0).toVal` (value bound `S_X`) and `.mono_M`.
3. Randomized routines: state `Implements prog M env e enc p` for the reference bit program `p`
   (C-ALG's `BitProg`); compose with `Implements.coin`, `.of_det`, `.letE` (bind), `.call`.
4. Entry point: prove the rank certificate `rankOKB prog r K = true` by `decide` (see
   `Examples.rankOK_readBitsTestProg`) and conclude with `Implements.eval_entry` (a run
   `p.run tape = some (a, rest)` gives the DSL run on `tape` leaving `rest`, peak
   `≤ ((r 0 + 1)(K + 3) + 1) M`) or `EvalsVal.runsOn`.
-/
