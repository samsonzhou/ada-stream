import F2e2e.Cost.Lib.Coins
import F2e2e.Cost.BitProgBridge

/-!
# End-to-end sanity checks of package L (not imported by other modules)

On the coin-using test program `readBitsTestProg` (entry `readBits`, `F2e2e/Cost/Lib/Coins.lean`):
1. the rank certificate is checked by `decide` (`rankOKB … = true`);
2. the exact-bits spec `readBits_spec` (cut2-style `EvalsLeT`) converts to `EvalsVal` (`toVal`);
3. the generic space theorem gives `RunsOn` on every tape `bs ++ rest`, with the explicit peak
   bound `((r 0 + 1)(K + 3) + 1) M`.
-/

namespace F2e2e.Cost

namespace Examples

/-- Ranks for `readBitsTestProg`: the entry (index `0`) has rank `1`, every other body `0`. -/
def rTest (j : ℕ) : ℕ := if j = 0 then 1 else 0

/-- The rank certificate of the test program, checked by `decide`. -/
theorem rankOK_readBitsTestProg : rankOKB readBitsTestProg rTest 12 = true := by decide

/-- The GST on the test program: on input `|bs|` and any tape `bs ++ rest`, the program outputs
the bits `bs` within space `((1 + 1)(12 + 3) + 1) · M` for `M = S_readBits |bs|`. -/
theorem readBitsTestProg_runsOn (bs rest : List Bool) :
    RunsOn readBitsTestProg (encN bs.length) (bs ++ rest) (encBits bs)
      ((((rTest 0 + 1) * (12 + 3) + 1) * S_readBits bs.length : ℕ) : ℝ) := by
  have hspec := readBits_spec (prog := readBitsTestProg) (mkProg_get_of_lookup rfl (by norm_num))
    (mkProg_get_of_lookup rfl (by norm_num)) bs 0
  have hval : EvalsVal readBitsTestProg (S_readBits bs.length) [encN bs.length] bs
      (.inl body_readBits) (encBits bs) := hspec.toVal
  have hin : valSize (encN bs.length) ≤ S_readBits bs.length := by
    rw [valSize_encN]
    simp only [S_readBits]
    omega
  exact EvalsVal.runsOn (RankOK.of_rankOKB rankOK_readBitsTestProg) (mkProg_zero _ _) hval hin
    le_rfl rest

end Examples

end F2e2e.Cost
