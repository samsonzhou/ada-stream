import Mathlib
import F2e2e.Cost.ArithCore

/-!
# U1: the size of the states of the bit-level algorithms (lemma (ii), part 1)

`regBits rs = 2·(total register length) + (number of registers) + 1` (`regBits_eq`). For the adder
(`addTrace`), the sign-magnitude addition (`addSM`), the shift-and-add multiplication (`mulTrace`), the
comparison and the equality scan (`eqTrace`): every state of the trace has an explicit number of registers
and total register length, linear in the operand lengths. (Division: `F2e2e/Cost/ArithDiv.lean`.)
-/

namespace F2e2e.Machine

/-- The total length of the registers of a state. -/
def totLen (s : List (List Bool)) : ℕ := (s.map List.length).sum

theorem regBits_eq (s : List (List Bool)) : regBits s = 2 * totLen s + s.length + 1 := by
  unfold regBits totLen
  induction s with
  | nil => simp
  | cons r s ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons] at ih ⊢
    omega

theorem totLen_append (s e : List (List Bool)) : totLen (s ++ e) = totLen s + totLen e := by
  simp [totLen]

theorem totLen_cons (r : List Bool) (s : List (List Bool)) : totLen (r :: s) = r.length + totLen s := by
  simp [totLen]

@[simp] theorem totLen_nil : totLen [] = 0 := rfl

/-- A bound on the states of a trace extended by the live registers `e`. -/
theorem states_map_append {t : List (List (List Bool))} {e : List (List Bool)} {k T : ℕ}
    (h : ∀ s ∈ t, s.length ≤ k ∧ totLen s ≤ T) :
    ∀ s ∈ t.map (· ++ e), s.length ≤ k + e.length ∧ totLen s ≤ T + totLen e := by
  intro s hs
  obtain ⟨s', hs', rfl⟩ := List.mem_map.mp hs
  obtain ⟨h1, h2⟩ := h s' hs'
  simp only [List.length_append, totLen_append]
  omega

/-- From the shape bound to the size bound. -/
theorem regBits_le_of {s : List (List Bool)} {k T : ℕ} (h : s.length ≤ k ∧ totLen s ≤ T) :
    regBits s ≤ 2 * T + k + 1 := by
  rw [regBits_eq]
  omega

/-! ## The adder -/

theorem addTrace_states (inv : Bool) (n : ℕ) : ∀ (x y : List Bool) (k : Bool) (acc : List Bool),
    ∀ s ∈ (addTrace inv n x y k acc).2.2,
      s.length ≤ 4 ∧ totLen s ≤ x.length + y.length + acc.length + n + 1 := by
  induction n with
  | zero =>
    intro x y k acc s hs
    simp only [addTrace, List.mem_singleton] at hs
    subst hs
    simp [totLen]
    omega
  | succ n ih =>
    intro x y k acc s hs
    simp only [addTrace, List.mem_cons] at hs
    rcases hs with rfl | hs
    · simp [totLen]; omega
    · obtain ⟨h1, h2⟩ := ih _ _ _ _ s hs
      refine ⟨h1, ?_⟩
      have hx : x.tail.length ≤ x.length := by simp
      have hy : y.tail.length ≤ y.length := by simp
      simp only [List.length_append, List.length_singleton] at h2
      omega

/-- The sum bits of the adder have length `|acc| + n`. -/
theorem addTrace_length (inv : Bool) (n : ℕ) (x y : List Bool) (k : Bool) (acc : List Bool) :
    (addTrace inv n x y k acc).1.length = acc.length + n := by
  cases inv
  · exact (addTrace_false_spec n x y k acc).1
  · exact (addTrace_true_spec n x y k acc).1

/-! ## Sign-magnitude addition -/

theorem addSM_states (sa sb : Bool) (x y : List Bool) :
    ∀ s ∈ (addSM sa sb x y).2, s.length ≤ 8 ∧ totLen s ≤ 3 * (x.length + y.length) + 4 := by
  intro s hs
  unfold addSM at hs
  dsimp only at hs
  by_cases he : sa = sb
  · rw [if_pos he] at hs
    obtain ⟨h1, h2⟩ := states_map_append (e := [[sa], [sb]])
      (addTrace_states false (max x.length y.length + 1) x y false []) s hs
    simp [totLen] at h1 h2 ⊢
    omega
  · rw [if_neg he] at hs
    split at hs
    · obtain ⟨h1, h2⟩ := states_map_append (e := [x, y, [sa], [sb]])
        (addTrace_states true (max x.length y.length) x y true []) s hs
      simp [totLen] at h1 h2 ⊢
      omega
    · rcases List.mem_append.mp hs with hs | hs
      · obtain ⟨h1, h2⟩ := states_map_append (e := [x, y, [sa], [sb]])
          (addTrace_states true (max x.length y.length) x y true []) s hs
        simp [totLen] at h1 h2 ⊢
        omega
      · obtain ⟨h1, h2⟩ := states_map_append (e := [[sa], [sb]])
          (addTrace_states true (max x.length y.length) y x true []) s hs
        simp [totLen] at h1 h2 ⊢
        omega

/-! ## Multiplication -/

theorem mulTrace_states (x : List Bool) : ∀ (y p lo : List Bool), p.length ≤ x.length →
    ∀ s ∈ (mulTrace x y p lo).2, s.length ≤ 7 ∧ totLen s ≤ 4 * x.length + y.length + lo.length + 2 := by
  intro y
  induction y with
  | nil =>
    intro p lo hp s hs
    simp only [mulTrace, List.mem_singleton] at hs
    subst hs
    simp [totLen]
    omega
  | cons b y ih =>
    intro p lo hp s hs
    simp only [mulTrace, List.mem_append, List.mem_cons] at hs
    -- the length of the new high part
    have hmax : max p.length x.length = x.length := max_eq_right hp
    have hs1 : (if b then addTrace false (max p.length x.length + 1) p x false []
        else (p, false, [])).1.length ≤ x.length + 1 := by
      cases b
      · simp only [Bool.false_eq_true, if_false]
        omega
      · simp only [if_true]
        rw [addTrace_length, hmax, List.length_nil]
        omega
    have hp' : (trimBits (if b then addTrace false (max p.length x.length + 1) p x false []
        else (p, false, [])).1).tail.length ≤ x.length := by
      have := length_trimBits_le (if b then addTrace false (max p.length x.length + 1) p x false []
        else (p, false, [])).1
      simp only [List.length_tail]
      omega
    rcases hs with (rfl | hs) | hs
    · simp [totLen]; omega
    · -- a state of the addition
      cases b
      · simp at hs
      · simp only [if_true] at hs
        obtain ⟨h1, h2⟩ := states_map_append (e := [x, y, lo])
          (addTrace_states false (max p.length x.length + 1) p x false []) s hs
        rw [hmax] at h2
        simp [totLen] at h1 h2 ⊢
        omega
    · obtain ⟨h1, h2⟩ := ih _ _ hp' s hs
      refine ⟨h1, ?_⟩
      simp only [List.length_append, List.length_singleton] at h2
      simp only [List.length_cons]
      omega

/-! ## Equality scan -/

theorem eqTrace_states : ∀ (n : ℕ) (x y : List Bool) (e : Bool),
    ∀ s ∈ (eqTrace n x y e).2, s.length ≤ 3 ∧ totLen s ≤ x.length + y.length + 1
  | 0, x, y, e => by
    intro s hs
    simp only [eqTrace, List.mem_singleton] at hs
    subst hs
    simp [totLen]
    omega
  | n + 1, x, y, e => by
    intro s hs
    simp only [eqTrace, List.mem_cons] at hs
    rcases hs with rfl | hs
    · simp [totLen]
      omega
    · obtain ⟨h1, h2⟩ := eqTrace_states n x.tail y.tail _ s hs
      refine ⟨h1, ?_⟩
      have hx : x.tail.length ≤ x.length := by simp
      have hy : y.tail.length ≤ y.length := by simp
      omega

/-! ## Restoring division -/

/-- Along `divTrace`, `max(|r|, |y|) + |ds|` does not increase; every state has at most `8` registers of
total length `≤ 5·(max(|r|,|y|) + |ds|) + |q| + |ds| + 5`; the quotient has `|q| + |ds|` bits and the
remainder at most `max(|r|,|y|) + |ds|`. -/
theorem divTrace_states (y : List Bool) : ∀ (ds r q : List Bool),
    (∀ s ∈ (divTrace y ds r q).2.2, s.length ≤ 8 ∧
      totLen s ≤ 5 * (max r.length y.length + ds.length) + q.length + ds.length + 5) ∧
    (divTrace y ds r q).1.length = q.length + ds.length ∧
    (divTrace y ds r q).2.1.length ≤ max r.length y.length + ds.length := by
  intro ds
  induction ds with
  | nil =>
    intro r q
    simp only [divTrace, List.mem_singleton]
    refine ⟨fun s hs => ?_, by simp, by simp⟩
    subst hs
    simp [totLen]
    omega
  | cons d ds ih =>
    intro r q
    simp only [divTrace, List.length_cons]
    have hts := addTrace_states true (max (r.length + 1) y.length) (d :: r) y true []
    have htl := addTrace_length true (max (r.length + 1) y.length) (d :: r) y true []
    generalize addTrace true (max (r.length + 1) y.length) (d :: r) y true [] = t at hts htl ⊢
    simp only [List.length_cons, List.length_nil, zero_add] at hts htl
    have hr'l : (if t.2.1 = true then trimBits t.1 else trimBits (d :: r)).length ≤
        max (r.length + 1) y.length := by
      split
      · have := length_trimBits_le t.1
        omega
      · have := length_trimBits_le (d :: r)
        simp only [List.length_cons] at this
        omega
    generalize (if t.2.1 = true then trimBits t.1 else trimBits (d :: r)) = r' at hr'l ⊢
    obtain ⟨ih1, ih2, ih3⟩ := ih r' (q ++ [t.2.1])
    simp only [List.length_append, List.length_singleton] at ih1 ih2 ih3
    refine ⟨fun s hs => ?_, ?_, ?_⟩
    · simp only [List.mem_append, List.mem_cons] at hs
      rcases hs with (rfl | hs) | hs
      · simp [totLen]
        omega
      · obtain ⟨h1, h2⟩ := states_map_append (e := [y, ds, d :: r, q]) hts s hs
        simp [totLen] at h1 h2 ⊢
        omega
      · obtain ⟨h1, h2⟩ := ih1 s hs
        exact ⟨h1, by omega⟩
    · rw [ih2]
      omega
    · omega

/-- Every state of the sign-magnitude division has at most `10` registers of total length
`≤ 6·(|x| + |y|) + 8`. -/
theorem divSM_states (sa sb : Bool) (x y : List Bool) :
    ∀ s ∈ (divSM sa sb x y).2.2, s.length ≤ 10 ∧ totLen s ≤ 6 * (x.length + y.length) + 8 := by
  obtain ⟨hd1, hd2, hd3⟩ := divTrace_states y x.reverse [] []
  simp only [List.length_nil, List.length_reverse, zero_add] at hd1 hd2 hd3
  have hq : (trimBits (divTrace y x.reverse [] []).1.reverse).length ≤ x.length := by
    have := length_trimBits_le (divTrace y x.reverse [] []).1.reverse
    simp only [List.length_reverse] at this
    omega
  have hm : max 0 y.length = y.length := by simp
  rw [hm] at hd1 hd3
  intro s hs
  unfold divSM at hs
  dsimp only at hs
  split at hs
  · simp only [List.mem_append] at hs
    rcases hs with (hs | hs) | hs
    · obtain ⟨h1, h2⟩ := states_map_append (e := [[sa], [sb]]) hd1 s hs
      simp [totLen] at h1 h2 ⊢
      omega
    · obtain ⟨h1, h2⟩ := states_map_append
        (e := [y, (divTrace y x.reverse [] []).2.1, [sa], [sb]])
        (addTrace_states false ((trimBits (divTrace y x.reverse [] []).1.reverse).length + 1)
          (trimBits (divTrace y x.reverse [] []).1.reverse) [] true []) s hs
      simp [totLen] at h1 h2 ⊢
      omega
    · have hq1 : (trimBits (addTrace false ((trimBits (divTrace y x.reverse [] []).1.reverse).length + 1)
          (trimBits (divTrace y x.reverse [] []).1.reverse) [] true []).1).length ≤ x.length + 1 := by
        have := length_trimBits_le (addTrace false ((trimBits (divTrace y x.reverse [] []).1.reverse).length + 1)
          (trimBits (divTrace y x.reverse [] []).1.reverse) [] true []).1
        rw [addTrace_length] at this
        simp only [List.length_nil, zero_add] at this
        omega
      obtain ⟨h1, h2⟩ := states_map_append
        (e := [trimBits (addTrace false ((trimBits (divTrace y x.reverse [] []).1.reverse).length + 1)
          (trimBits (divTrace y x.reverse [] []).1.reverse) [] true []).1, [sa], [sb]])
        (addTrace_states true y.length y (divTrace y x.reverse [] []).2.1 true []) s hs
      simp [totLen] at h1 h2 ⊢
      omega
  · obtain ⟨h1, h2⟩ := states_map_append (e := [[sa], [sb]]) hd1 s hs
    simp [totLen] at h1 h2 ⊢
    omega

end F2e2e.Machine
