import Mathlib
import F2e2e.Cost.ArithOps
import F2e2e.Cost.ArithBounds
import F2e2e.Cost.ArithDiv

/-!
# U1: the arithmetic workspace — lemmas (i) and (ii) for the Spec v2.1 block

For the bit-level algorithms `arithRun` of Spec v2.1 (§3.2 of `F2e2e/Spec.lean`):

* every algorithm is a pure function of its operands (no tape argument: it consumes no coins), and its
  trace lists its full live storage at every step (registers, self-delimitingly encoded by `regBits`);
* (i) `arithRun_correct`: its result is `evalBin`'s;
* (ii) `regBits_le_opWork`: every state of its run has encoded size at most `opWork op a b` (`opWork` is the
  maximum over the trace), and `opWork_le`: `opWork op a b ≤ arithC·(|bitEncodeVal a| + |bitEncodeVal b|) +
  arithC'` with the explicit constants `arithC`, `arithC'`.

Division and remainder: `F2e2e/Cost/ArithDiv.lean` (c186bcb5).
-/

namespace F2e2e.Machine

/-! ## (i) correctness -/

/-- **(i)** The bit-level algorithm of every integer primitive computes `evalBin`'s result (whenever
`evalBin` succeeds: for `div`, `mod` the divisor is nonzero). -/
theorem arithRun_correct {op : BinOp} (hop : op ≠ BinOp.cons) (a b : ℤ)
    (hdiv : op = BinOp.div ∨ op = BinOp.mod → b ≠ 0) :
    some (arithRun op a b).1 = (evalBin op (Val.int a) (Val.int b)).map Prod.fst := by
  cases op with
  | add => rw [arithRun_add]; rfl
  | sub => rw [arithRun_sub]; rfl
  | mul => rw [arithRun_mul]; rfl
  | div =>
    have hb := hdiv (Or.inl rfl)
    rw [arithRun_div a b hb]
    simp [evalBin, hb]
  | mod =>
    have hb := hdiv (Or.inr rfl)
    rw [arithRun_mod a b hb]
    simp [evalBin, hb]
  | lt => rw [arithRun_lt]; rfl
  | eq => rw [arithRun_eq]; rfl
  | cons => exact absurd rfl hop

/-! ## (ii) part 1: every state is charged -/

/-- Every state of the run of the algorithm of `op` on `a, b` has encoded size at most `opWork op a b`. -/
theorem regBits_le_opWork {op : BinOp} (hop : op ≠ BinOp.cons) (a b : ℤ) :
    ∀ s ∈ (arithRun op a b).2, regBits s ≤ opWork op (Val.int a) (Val.int b) := by
  intro s hs
  have h : opWork op (Val.int a) (Val.int b) = ((arithRun op a b).2.map regBits).foldr max 0 := by
    cases op <;> rfl
  rw [h]
  exact le_foldr_max (List.mem_map.mpr ⟨s, hs, rfl⟩)

/-! ## The size of the operand encodings -/

theorem length_bitEncodeVal_int (z : ℤ) :
    (bitEncodeVal (Val.int z)).length = 2 * (Nat.bits z.natAbs).length + 3 := by
  simp [bitEncodeVal, bitLen, length_bits]
  omega

/-! ## (ii) part 2: the explicit linear bound -/

/-- The multiplicative constant of the workspace bound. -/
def arithC : ℕ := 8

/-- The additive constant of the workspace bound. -/
def arithC' : ℕ := 64

theorem opWork_le_of {op : BinOp} (hop : op ≠ BinOp.cons) {a b : ℤ} {B : ℕ}
    (h : ∀ s ∈ (arithRun op a b).2, regBits s ≤ B) : opWork op (Val.int a) (Val.int b) ≤ B := by
  have e : opWork op (Val.int a) (Val.int b) = ((arithRun op a b).2.map regBits).foldr max 0 := by
    cases op <;> rfl
  rw [e]
  apply foldr_max_le
  intro x hx
  obtain ⟨s, hs, rfl⟩ := List.mem_map.mp hx
  exact h s hs

section Ops

variable (a b : ℤ)


theorem arithRun_add_states : ∀ s ∈ (arithRun BinOp.add a b).2, regBits s ≤ 6 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 17 := by
  intro s hs
  have := regBits_le_of (addSM_states _ _ _ _ s hs)
  omega

theorem arithRun_sub_states : ∀ s ∈ (arithRun BinOp.sub a b).2, regBits s ≤ 6 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 17 := by
  intro s hs
  have := regBits_le_of (addSM_states _ _ _ _ s hs)
  omega

theorem arithRun_mul_states : ∀ s ∈ (arithRun BinOp.mul a b).2, regBits s ≤ 8 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 18 := by
  intro s hs
  have h := states_map_append (e := [[decide (a < 0)], [decide (b < 0)]])
    (mulTrace_states (Nat.bits a.natAbs) (Nat.bits b.natAbs) [] [] (by simp)) s hs
  have := regBits_le_of h
  simp [totLen] at this
  omega

theorem arithRun_lt_states : ∀ s ∈ (arithRun BinOp.lt a b).2,
    regBits s ≤ 4 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 13 := by
  intro s hs
  simp only [arithRun] at hs
  split at hs
  · obtain ⟨h1, h2⟩ := states_map_append (e := [[decide (a < 0)], [decide (b < 0)]])
      (addTrace_states true (max (Nat.bits a.natAbs).length (Nat.bits b.natAbs).length) _ _ true [])
      s hs
    have he1 : ([[decide (a < 0)], [decide (b < 0)]] : List (List Bool)).length = 2 := rfl
    have he2 : totLen ([[decide (a < 0)], [decide (b < 0)]] : List (List Bool)) = 2 := rfl
    rw [he1] at h1
    rw [he2, List.length_nil] at h2
    have hl1 : (if decide (a < 0) = true then Nat.bits b.natAbs else Nat.bits a.natAbs).length +
        (if decide (a < 0) = true then Nat.bits a.natAbs else Nat.bits b.natAbs).length =
          (Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length := by
      split <;> omega
    have hm : max (Nat.bits a.natAbs).length (Nat.bits b.natAbs).length ≤
        (Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length := max_le (by omega) (by omega)
    rw [regBits_eq]
    omega
  · simp only [List.mem_singleton] at hs
    subst hs
    rw [regBits_eq]
    simp [totLen]
    omega

theorem arithRun_eq_states : ∀ s ∈ (arithRun BinOp.eq a b).2, regBits s ≤ 2 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 12 := by
  intro s hs
  have h := states_map_append (e := [[decide (a < 0)], [decide (b < 0)]])
    (eqTrace_states (max (Nat.bits a.natAbs).length (Nat.bits b.natAbs).length) (Nat.bits a.natAbs) (Nat.bits b.natAbs) true) s hs
  have := regBits_le_of h
  simp [totLen] at this
  omega

theorem arithRun_div_states : ∀ s ∈ (arithRun BinOp.div a b).2,
    regBits s ≤ 12 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 27 := by
  intro s hs
  have := regBits_le_of (divSM_states _ _ _ _ s hs)
  omega

theorem arithRun_mod_states : ∀ s ∈ (arithRun BinOp.mod a b).2,
    regBits s ≤ 12 * ((Nat.bits a.natAbs).length + (Nat.bits b.natAbs).length) + 27 := by
  intro s hs
  have := regBits_le_of (divSM_states _ _ _ _ s hs)
  omega

end Ops

/-- **The explicit linear bound** (U1 (ii)): the workspace of a primitive is at most
`arithC·(|bitEncodeVal a| + |bitEncodeVal b|) + arithC'` (`arithC = 8`, `arithC' = 64`). -/
theorem opWork_le (op : BinOp) (va vb : Val) :
    opWork op va vb ≤ arithC * ((bitEncodeVal va).length + (bitEncodeVal vb).length) + arithC' := by
  cases va with
  | list l => cases op <;> simp [opWork]
  | int a =>
    cases vb with
    | list l => cases op <;> simp [opWork]
    | int b =>
      rw [length_bitEncodeVal_int, length_bitEncodeVal_int]
      unfold arithC arithC'
      cases op with
      | add =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_add_states a b s hs) (by omega))
      | sub =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_sub_states a b s hs) (by omega))
      | mul =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_mul_states a b s hs) (by omega))
      | div =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_div_states a b s hs) (by omega))
      | mod =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_mod_states a b s hs) (by omega))
      | lt =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_lt_states a b s hs) (by omega))
      | eq =>
        exact opWork_le_of (by intro h; cases h)
          (fun s hs => le_trans (arithRun_eq_states a b s hs) (by omega))
      | cons => simp [opWork]

end F2e2e.Machine
