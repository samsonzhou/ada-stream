import F2e2e.Cost.Facts

/-!
# Standard encodings of data as DSL values (port of cut2's `Cost/Enc.lean`)

* `encN n = Val.int n` (natural numbers), `encZ z = Val.int z` (integers), `encB b` (`1`/`0`);
* `encL f l = Val.list (l.map f)` (lists), `encPair a b = Val.list [a, b]` (pairs; tuples are
  lists `Val.list [a, b, c, …]`);
* `encT f t = encL (encL f) t` (2D tables: lists of rows);
* `encBits bs = encL encB bs` (bit lists, e.g. fresh bits read from the tape).

The Spec's `encInts` is `encL encZ` (`encInts_eq_encL`, by `rfl`). The value returned by
`Expr.coin` on the bit `b` is `encB b` (`coinVal_eq_encB`, by `rfl`).

Size lemmas: `valSize_encN`, `valSize_encZ`, `valSize_encB`, `valSize_encL`, `valSize_encPair`,
`valSize_encT`, `valSize_encBits_le`, and the bounds `valSize_encL_le` (uniform element bound),
`valSize_encL_ge`, `valSize_encInts_le`, `valSize_lt_of_mem`, `listSize_le_of_mem`.
-/

namespace F2e2e.Cost

/-- Natural numbers are encoded as (nonnegative) integers. -/
def encN (n : ℕ) : Val := Val.int (n : ℤ)

/-- Integers. -/
def encZ (z : ℤ) : Val := Val.int z

/-- Booleans as `1` (true) / `0` (false). -/
def encB (b : Bool) : Val := Val.int (if b then 1 else 0)

/-- Lists, elementwise. -/
def encL {α : Type*} (f : α → Val) (l : List α) : Val := Val.list (l.map f)

/-- Pairs as two-element lists. -/
def encPair (a b : Val) : Val := Val.list [a, b]

/-- Two-dimensional tables as lists of rows. -/
def encT {α : Type*} (f : α → Val) (t : List (List α)) : Val := encL (encL f) t

/-- Bit lists as lists of `1`/`0`. -/
def encBits (bs : List Bool) : Val := encL encB bs

theorem encInts_eq_encL (l : List ℤ) : encInts l = encL encZ l := rfl

/-- The value produced by `Expr.coin` on the bit `b` is `encB b`. -/
theorem coinVal_eq_encB (b : Bool) : Val.int (if b = true then 1 else 0) = encB b := rfl

@[simp] theorem encL_nil {α : Type*} (f : α → Val) : encL f [] = Val.list [] := rfl

@[simp] theorem encL_cons {α : Type*} (f : α → Val) (a : α) (l : List α) :
    encL f (a :: l) = Val.list (f a :: l.map f) := rfl

theorem encB_true : encB true = Val.int 1 := rfl

theorem encB_false : encB false = Val.int 0 := rfl

/-! ### Bit lengths -/

theorem bitLen_le_size_of_le {k n : ℕ} (h : k ≤ n) : bitLen (k : ℤ) ≤ Nat.size n := by
  rw [bitLen_natCast]
  exact Nat.size_le_size h

theorem bitLen_mono_nat {k n : ℕ} (h : k ≤ n) : bitLen (k : ℤ) ≤ bitLen (n : ℤ) := by
  rw [bitLen_natCast, bitLen_natCast]
  exact Nat.size_le_size h

theorem size_le_self (n : ℕ) : Nat.size n ≤ n := by
  rw [Nat.size_le]
  exact Nat.lt_two_pow_self

theorem bitLen_natCast_le (n : ℕ) : bitLen (n : ℤ) ≤ n := by
  rw [bitLen_natCast]
  exact size_le_self n

/-! ### Sizes of encodings -/

theorem valSize_encN (n : ℕ) : valSize (encN n) = Nat.size n + 1 := by
  simp [encN, bitLen_natCast]

theorem valSize_encZ (z : ℤ) : valSize (encZ z) = bitLen z + 1 := by
  simp [encZ]

theorem valSize_encB (b : Bool) : valSize (encB b) = if b then 2 else 1 := by
  cases b <;> simp [encB]

theorem valSize_encB_le (b : Bool) : valSize (encB b) ≤ 2 := by
  cases b <;> simp [encB]

theorem listSize_map {α : Type*} (f : α → Val) (l : List α) :
    listSize (l.map f) = (l.map (fun a => valSize (f a) + 1)).sum := by
  induction l with
  | nil => simp
  | cons a l ih => simp [ih]

theorem valSize_encL {α : Type*} (f : α → Val) (l : List α) :
    valSize (encL f l) = 1 + (l.map (fun a => valSize (f a) + 1)).sum := by
  simp [encL, listSize_map]

theorem valSize_encPair (a b : Val) : valSize (encPair a b) = valSize a + valSize b + 3 := by
  simp [encPair]; omega

theorem valSize_encT {α : Type*} (f : α → Val) (t : List (List α)) :
    valSize (encT f t) = 1 + (t.map (fun r => valSize (encL f r) + 1)).sum := by
  simp [encT, valSize_encL]

theorem listSize_le_of_forall_le (l : List Val) (B : ℕ) (h : ∀ v ∈ l, valSize v ≤ B) :
    listSize l ≤ l.length * (B + 1) := by
  induction l with
  | nil => simp
  | cons v l ih =>
    have hv := h v List.mem_cons_self
    have hl := ih (fun w hw => h w (List.mem_cons_of_mem v hw))
    simp only [listSize_cons, List.length_cons]
    nlinarith

theorem valSize_encL_le {α : Type*} (f : α → Val) (l : List α) (B : ℕ)
    (h : ∀ a ∈ l, valSize (f a) ≤ B) : valSize (encL f l) ≤ 1 + l.length * (B + 1) := by
  have := listSize_le_of_forall_le (l.map f) B (by
    intro v hv
    obtain ⟨a, ha, rfl⟩ := List.mem_map.mp hv
    exact h a ha)
  simp only [encL, valSize_list, List.length_map] at this ⊢
  omega

theorem valSize_encL_ge {α : Type*} (f : α → Val) (l : List α) :
    1 + 2 * l.length ≤ valSize (encL f l) := by
  have := length_le_listSize (l.map f)
  simp only [encL, valSize_list, List.length_map] at this ⊢
  omega

theorem valSize_encInts_le (l : List ℤ) (B : ℕ) (h : ∀ z ∈ l, bitLen z ≤ B) :
    valSize (encInts l) ≤ 1 + l.length * (B + 2) := by
  rw [encInts_eq_encL]
  exact valSize_encL_le encZ l (B + 1) (fun z hz => by
    have := h z hz
    simp [encZ]; omega)

/-- A bit list of length `k` has size at most `1 + 3k`. -/
theorem valSize_encBits_le (bs : List Bool) : valSize (encBits bs) ≤ 1 + 3 * bs.length := by
  have := valSize_encL_le encB bs 2 (fun b _ => valSize_encB_le b)
  simp only [encBits]
  omega

theorem valSize_lt_of_mem {v : Val} {l : List Val} (h : v ∈ l) :
    valSize v < valSize (Val.list l) := by
  induction l with
  | nil => simp at h
  | cons w l ih =>
    simp only [valSize_list, listSize_cons] at ih ⊢
    rcases List.mem_cons.mp h with rfl | h
    · omega
    · have := ih h; omega

theorem listSize_le_of_mem {v : Val} {l : List Val} (h : v ∈ l) :
    valSize v + 1 ≤ listSize l := by
  have := valSize_lt_of_mem h
  simp only [valSize_list] at this
  induction l with
  | nil => simp at h
  | cons w l ih =>
    simp only [listSize_cons]
    rcases List.mem_cons.mp h with rfl | h
    · omega
    · have := ih h (by
        have h2 := valSize_lt_of_mem h
        simp only [valSize_list] at h2
        omega)
      omega

end F2e2e.Cost
