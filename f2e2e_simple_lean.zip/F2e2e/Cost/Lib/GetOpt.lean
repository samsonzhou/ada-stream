import F2e2e.Cost.Lib.MapIdx

/-!
# Optional lookup `l[n]?` (package L, combinator 3; Idx 31–32)

* `encOpt enc : Option α → Val` : `none ↦ []`, `some a ↦ [enc a]`.
* `getOpt` (index `Idx.getOpt`, loop `Idx.getOptStep`): `[l, n] ↦ encOpt id (l[n]?)` for a list
  `l : List Val`; with an encoded list `encL enc xs` this is `encOpt enc (xs[n]?)`
  (`getOpt_val_encL`).

Loop state `[rest, k]`: stop with `[]` if `rest = []`, with `[head rest]` if `k = 0`, otherwise
continue with `[tail rest, k - 1]`. Specs are `EvalsVal` judgments proved by symbolic evaluation.
Also: `Implements.call` (a call of a function implementing `p` implements `p`).
-/

namespace F2e2e.Cost

open F2e2e.Discrete

namespace Idx

/-- `getOpt : [l, n] ↦ l[n]?` (as `[]` / `[x]`). -/
abbrev getOpt : ℕ := 31
/-- Loop body of `getOpt`. -/
abbrev getOptStep : ℕ := 32

end Idx

/-- Encoding of an option: `none ↦ []`, `some a ↦ [enc a]`. -/
def encOpt {α : Type*} (enc : α → Val) : Option α → Val
  | none => Val.list []
  | some a => Val.list [enc a]

/-- Calling a function whose body implements `p` (argument evaluated without fresh bits). -/
theorem Implements.call {prog : List Expr} {M : ℕ} {env : List Val} {α : Type} {i : ℕ}
    {argE body : Expr} {va : Val} {enc : α → Val} {p : BitProg α}
    (harg : EvalsVal prog M env [] (.inl argE) va) (hbody : prog[i]? = some body)
    (h : Implements prog M [va] body enc p) : Implements prog M env (Expr.call i argE) enc p :=
  fun bits a hp => EvalsVal.call harg hbody (h bits a hp)

/-- Loop body of `getOpt`. Environment `[acc]`, `acc = [rest, k]`. -/
def body_getOptStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- rest ; [rest, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) Expr.nil)                                            -- [0, []]
      (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))         -- k ; [k, rest, acc]
        (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
          (ePair (Expr.lit 0) (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 1)) Expr.nil))
          (ePair (Expr.lit 1) (ePair (Expr.un UnOp.tail (Expr.var 1))
            (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1)))))))

/-- `getOpt : [l, n] ↦ l[n]?`. Environment `[[l, n]]`. -/
def body_getOpt : Expr := Expr.loop Idx.getOptStep (Expr.var 0)

section Steps

variable (prog : List Expr) {M : ℕ}

theorem getOptStep_nil (k : ℤ) (hM : 2 * valSize (Val.list [Val.list [], Val.int k]) + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.list [], Val.int k]] [] (.inl body_getOptStep)
      (Val.list [Val.int 0, Val.list []]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_getOptStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hM ⊢
  omega

theorem getOptStep_hit (x : Val) (R : List Val)
    (hM : 3 * valSize (Val.list [Val.list (x :: R), Val.int 0]) + 2 * valSize x + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.list (x :: R), Val.int 0]] [] (.inl body_getOptStep)
      (Val.list [Val.int 0, Val.list [x]]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_getOptStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, not_true_eq_false, if_true, if_false]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hM ⊢
  omega

theorem getOptStep_skip (x : Val) (R : List Val) (k : ℤ) (hk : k ≠ 0)
    (hM : 3 * valSize (Val.list [Val.list (x :: R), Val.int k]) + 2 * bitLen (k - 1) + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.list (x :: R), Val.int k]] [] (.inl body_getOptStep)
      (Val.list [Val.int 1, Val.list [Val.list R, Val.int (k - 1)]]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_getOptStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hM ⊢
  omega

end Steps

/-- Encoding of the `getOpt` loop state `(rest, k)`. -/
def encGO (s : List Val × ℕ) : Val := Val.list [Val.list s.1, Val.int (s.2 : ℤ)]

/-- **Spec of `getOpt`.** -/
theorem getOpt_val {prog : List Expr} (h : prog[Idx.getOptStep]? = some body_getOptStep)
    (l : List Val) (n : ℕ) {M : ℕ}
    (hM : 5 * valSize (Val.list l) + 6 * Nat.size n + 40 ≤ M) :
    EvalsVal prog M [Val.list [Val.list l, Val.int (n : ℤ)]] [] (.inl body_getOpt)
      (encOpt id (l[n]?)) := by
  have hl : valSize (Val.list l) = 1 + listSize l := valSize_list l
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) h encGO (fun _ => [])
    (fun s : List Val × ℕ => s.1 <:+ l ∧ s.1[s.2]? = l[n]? ∧ s.2 ≤ n)
    (· = encOpt id (l[n]?)) (fun s => s.1.length) (by
      rintro ⟨r, k⟩ ⟨hsuf, hget, hk⟩
      simp only at hsuf hget hk
      have hR : listSize r ≤ listSize l := listSize_le_of_suffix hsuf
      have hB : bitLen (k : ℤ) ≤ Nat.size n := bitLen_le_size_of_le hk
      cases r with
      | nil =>
        left
        refine ⟨Val.list [], getOptStep_nil prog (k : ℤ) ?_, ?_⟩
        · simp only [valSize_list, valSize_int, listSize_cons, listSize_nil] at hR ⊢
          omega
        · rw [← hget]; rfl
      | cons x R =>
        have hx : valSize x + 1 + listSize R ≤ listSize l := by
          simpa only [listSize_cons] using hR
        cases k with
        | zero =>
          left
          refine ⟨Val.list [x], getOptStep_hit prog x R ?_, ?_⟩
          · simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]
            omega
          · rw [← hget]; rfl
        | succ k =>
          right
          have hB1 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ Nat.size n := by
            have : (((k + 1 : ℕ) : ℤ) - 1) = ((k : ℕ) : ℤ) := by push_cast; ring
            rw [this]; exact bitLen_le_size_of_le (by omega)
          refine ⟨1, (R, k), [], one_ne_zero, rfl, ?_, ⟨?_, ?_, ?_⟩, ?_⟩
          · have henc : encGO (R, k) = Val.list [Val.list R, Val.int (((k + 1 : ℕ) : ℤ) - 1)] := by
              simp [encGO]
            rw [henc]
            exact getOptStep_skip prog x R ((k + 1 : ℕ) : ℤ) (by omega) (by
              simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
              omega)
          · exact (List.suffix_cons x R).trans hsuf
          · simpa using hget
          · omega
          · simp)
    (l, n) ⟨List.suffix_refl l, rfl, le_rfl⟩
  obtain ⟨out, rfl, hloop⟩ := key
  exact EvalsVal.loop EvalsVal.var0 hloop

/-- `getOpt` on an encoded list. -/
theorem getOpt_val_encL {α : Type*} {prog : List Expr}
    (h : prog[Idx.getOptStep]? = some body_getOptStep) (enc : α → Val) (xs : List α) (n : ℕ)
    {M : ℕ} (hM : 5 * valSize (encL enc xs) + 6 * Nat.size n + 40 ≤ M) :
    EvalsVal prog M [Val.list [encL enc xs, Val.int (n : ℤ)]] [] (.inl body_getOpt)
      (encOpt enc (xs[n]?)) := by
  have := getOpt_val h (xs.map enc) n hM
  rw [List.getElem?_map] at this
  cases hx : xs[n]? with
  | none => rw [hx] at this; exact this
  | some a => rw [hx] at this; exact this

end F2e2e.Cost
