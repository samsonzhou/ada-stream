import F2e2e.Cost.Lib.RevAppend

/-!
# Generic `map` over a list (T1) — port of cut2 `Cost/Lib/Map.lean`

`body_mapStep iF` is the loop body of a `map` whose element function is the program function
`iF` (environment `[x] ↦ f x`); it is parametric in `iF`, so every mapped function gets its own
step index `iStep` (allocated by the user in its own range) with `prog[iStep]? = some
(body_mapStep iF)`.

* `body_mapStep iF`: accumulator `[R, r]` (reversed results, remaining list):
  `[R, []] ↦ [0, R]`, `[R, x :: r] ↦ [1, [f x :: R, r]]` (`f x` by `call iF x`).
* `body_map iStep`: `l ↦ l.map f`, as `loop iStep [[], l]` followed by the `revAppend` loop.

Spec (`map_spec`), typed: input `encL enc l`, output `encL encB (l.map f)`, from a spec of the
element function `∀ a ∈ l, ∀ b, EvalsLe prog b [enc a] bodyF (encB (f a)) (Cf a) (b + Sf a)` and
uniform bounds `Cf a ≤ Cmax`, `Sf a ≤ Smax`, `valSize (encB (f a)) ≤ Vmax` on `l`.
-/

namespace F2e2e.Cost
/-- Loop body of a `map` with element function `iF`. Environment `[acc]`, `acc = [R, r]`. -/
def body_mapStep (iF : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))            -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))                  -- [0, R]
      (ePair (Expr.lit 1)                                                    -- [1, [f x :: R, tail r]]
        (ePair
          (Expr.bin BinOp.cons (Expr.call iF (Expr.un UnOp.head (Expr.var 0)))
            (Expr.un UnOp.head (Expr.var 1)))
          (Expr.un UnOp.tail (Expr.var 0)))))

/-- `map` whose loop body `body_mapStep iF` is stored at `iStep`: `l ↦ l.map f`. -/
def body_map (iStep : ℕ) : Expr :=
  Expr.letE (Expr.loop iStep (ePair Expr.nil (Expr.var 0)))
    (Expr.loop Idx.revAppendStep (ePair (Expr.var 0) Expr.nil))

/-! ### The loop body -/

theorem mapStep_nil (prog : List Expr) (iF : ℕ) (base : ℕ) (R : List Val) :
    EvalsLe prog base [Val.list [Val.list R, Val.list []]] (body_mapStep iF)
      (Val.list [Val.int 0, Val.list R]) 19
      (base + 4 * valSize (Val.list [Val.list R, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_mapStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem mapStep_cons {prog : List Expr} {iF : ℕ} {bodyF : Expr} (hF : prog[iF]? = some bodyF)
    (base : ℕ) (R : List Val) (x : Val) (r : List Val) {y : Val} {Cx Sx : ℕ}
    (hx : ∀ b, EvalsLe prog b [x] bodyF y Cx (b + Sx)) :
    EvalsLe prog base [Val.list [Val.list R, Val.list (x :: r)]] (body_mapStep iF)
      (Val.list [Val.int 1, Val.list [Val.list (y :: R), Val.list r]]) (Cx + 34)
      (base + 4 * valSize (Val.list [Val.list R, Val.list (x :: r)]) + 2 * valSize y + Sx +
        20) := by
  have h := EvalsLe.letE (prog := prog) (base := base)
    (env := [Val.list [Val.list R, Val.list (x :: r)]])
    (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))
    (EvalsLe.ite_false (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))
      (EvalsLe.isNil_cons (EvalsLe.var (i := 0) rfl)) rfl
      (EvalsLe.pair (EvalsLe.lit 1)
        (EvalsLe.pair
          (EvalsLe.cons (EvalsLe.call (EvalsLe.head (EvalsLe.var (i := 0) rfl)) hF (hx _))
            (EvalsLe.head (EvalsLe.var (i := 1) rfl)))
          (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))))
  refine h.mono ?_ ?_
  · simp only [bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

/-! ### The loop -/

/-- Encoding of the `map` loop state `(R, r)` (values). -/
def encMapState (s : List Val × List Val) : Val := Val.list [Val.list s.1, Val.list s.2]

theorem map_loop {α β : Type*} {prog : List Expr} {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapStep iF)) (hF : prog[iF]? = some bodyF)
    (enc : α → Val) (encB : β → Val) (f : α → β) (Cf Sf : α → ℕ) (l : List α)
    (hspec : ∀ a ∈ l, ∀ b, EvalsLe prog b [enc a] bodyF (encB (f a)) (Cf a) (b + Sf a))
    (Cmax Smax Vmax : ℕ) (hC : ∀ a ∈ l, Cf a ≤ Cmax) (hS : ∀ a ∈ l, Sf a ≤ Smax)
    (hV : ∀ a ∈ l, valSize (encB (f a)) ≤ Vmax) (base : ℕ) :
    ∀ t : List β × List α, (∃ p, p ++ t.2 = l ∧ t.1 = (p.map f).reverse) →
      ∃ out, out = Val.list (((l.map f).reverse).map encB) ∧
        LoopLe prog base iStep (encMapState (t.1.map encB, t.2.map enc)) out
          ((t.2.length + 1) * (Cmax + 34 + 1))
          (base + 5 * (valSize (encL enc l) + l.length * (Vmax + 1) + 5) + 2 * Vmax + Smax +
            20) := by
  have key := LoopLe.of_measure (base := base)
    (S := base + 5 * (valSize (encL enc l) + l.length * (Vmax + 1) + 5) + 2 * Vmax + Smax + 20)
    hstep (fun t : List β × List α => encMapState (t.1.map encB, t.2.map enc))
    (fun t => ∃ p, p ++ t.2 = l ∧ t.1 = (p.map f).reverse)
    (· = Val.list (((l.map f).reverse).map encB)) (fun t => t.2.length) (Cmax + 34) ?_
  · exact key
  rintro ⟨R, r⟩ ⟨p, hp, hR⟩
  simp only at hp hR
  subst hR
  -- size of the state
  have hRs : listSize (((p.map f).reverse).map encB) ≤ p.length * (Vmax + 1) := by
    refine le_trans (listSize_le_of_forall_le _ Vmax ?_) (by simp)
    intro v hv
    simp only [List.mem_map, List.mem_reverse] at hv
    obtain ⟨b, ⟨a, ha, rfl⟩, rfl⟩ := hv
    exact hV a (hp ▸ List.mem_append_left r ha)
  have hrs : listSize (r.map enc) ≤ listSize (l.map enc) :=
    listSize_le_of_suffix ((hp ▸ List.suffix_append p r).map enc)
  have hpl : p.length ≤ l.length := by rw [← hp]; simp
  have hmul := Nat.mul_le_mul_right (Vmax + 1) hpl
  cases r with
  | nil =>
    left
    refine ⟨Val.list (((p.map f).reverse).map encB), ?_, ?_⟩
    · refine (mapStep_nil prog iF _ _).mono (by omega) ?_
      simp only [encMapState, encL, valSize_list, listSize_cons, listSize_nil,
        List.map_nil] at hrs ⊢
      omega
    · rw [← hp, List.append_nil]
  | cons a r =>
    right
    have ha : a ∈ l := hp ▸ List.mem_append_right p List.mem_cons_self
    have hCa := hC a ha
    have hSa := hS a ha
    have hVa := hV a ha
    refine ⟨1, (f a :: (p.map f).reverse, r), one_ne_zero, ?_, ⟨p ++ [a], by rw [← hp]; simp,
      by simp⟩, by simp⟩
    refine (mapStep_cons hF _ _ (enc a) (r.map enc) (hspec a ha)).mono (by omega) ?_
    simp only [encMapState, encL, valSize_list, listSize_cons, listSize_nil, List.map_cons]
      at hrs hRs ⊢
    omega

/-! ### The spec -/

/-- Cost bound of `map`. -/
def C_map (len Cmax : ℕ) : ℕ := (len + 1) * (Cmax + 35) + (len + 1) * 34 + 20

/-- Space bound of `map` (on top of the base). -/
def S_map {α : Type*} (enc : α → Val) (l : List α) (Smax Vmax : ℕ) : ℕ :=
  6 * (valSize (encL enc l) + l.length * (Vmax + 1) + 5) + 2 * Vmax + Smax + 40

/-- **Spec of `map`.** -/
theorem map_spec {α β : Type*} {prog : List Expr} {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapStep iF)) (hF : prog[iF]? = some bodyF)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (enc : α → Val) (encB : β → Val) (f : α → β) (Cf Sf : α → ℕ) (l : List α)
    (hspec : ∀ a ∈ l, ∀ b, EvalsLe prog b [enc a] bodyF (encB (f a)) (Cf a) (b + Sf a))
    (Cmax Smax Vmax : ℕ) (hC : ∀ a ∈ l, Cf a ≤ Cmax) (hS : ∀ a ∈ l, Sf a ≤ Smax)
    (hV : ∀ a ∈ l, valSize (encB (f a)) ≤ Vmax) (base : ℕ) :
    EvalsLe prog base [encL enc l] (body_map iStep) (encL encB (l.map f))
      (C_map l.length Cmax) (base + S_map enc l Smax Vmax) := by
  obtain ⟨out, rfl, hloop⟩ := map_loop hstep hF enc encB f Cf Sf l hspec Cmax Smax Vmax hC hS hV
    base ([], l) ⟨[], by simp, by simp⟩
  set Rv := ((l.map f).reverse).map encB with hRv
  have hinit : EvalsLe prog base [encL enc l] (ePair Expr.nil (Expr.var 0))
      (encMapState (([] : List β).map encB, l.map enc)) 7
      (base + 2 * valSize (encL enc l) + 7) := by
    refine (EvalsLe.pair EvalsLe.nil (EvalsLe.var (i := 0) rfl)).mono (le_refl _) ?_
    simp only [encL, valSize_list, listSize_nil, max_le_iff]
    omega
  have hA := EvalsLe.loop hinit hloop
  have hinit2 : EvalsLe prog (base + valSize (Val.list Rv)) [Val.list Rv, encL enc l]
      (ePair (Expr.var 0) Expr.nil) (encRA (Rv, [])) 7
      (base + valSize (Val.list Rv) + 2 * valSize (Val.list Rv) + 7) := by
    refine (EvalsLe.pair (EvalsLe.var (i := 0) rfl) EvalsLe.nil).mono (le_refl _) ?_
    simp only [valSize_list, listSize_nil, max_le_iff]
    omega
  have hB := EvalsLe.loop hinit2 (revAppend_loop hra (base + valSize (Val.list Rv)) (Rv, []))
  have hAll := EvalsLe.letE hA hB
  have e : Val.list (Rv.reverseAux []) = encL encB (l.map f) := by
    simp [hRv, encL, List.reverseAux_eq, List.map_reverse]
  rw [e] at hAll
  have hRs : listSize Rv ≤ l.length * (Vmax + 1) := by
    refine le_trans (listSize_le_of_forall_le _ Vmax ?_) (by simp [hRv])
    intro v hv
    simp only [hRv, List.mem_map, List.mem_reverse] at hv
    obtain ⟨b, ⟨a, ha, rfl⟩, rfl⟩ := hv
    exact hV a ha
  have hRl : Rv.length = l.length := by simp [hRv]
  refine hAll.mono ?_ ?_
  · simp only [C_map, hRl]
    nlinarith
  · simp only [S_map, max_le_iff, valSize_encRA, valSize_list, listSize_nil] at hRs ⊢
    omega

end F2e2e.Cost