import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.RevAppend

/-!
# Mapping a randomized function over a list, results in draw order (package L, combinator 2)

Reference functions (C-ALG's `sampleBlocks`, `sampleList` are instances):
* `mapB f l` : `[] ↦ pure []`, `x :: xs ↦ do b ← f x; bs ← mapB f xs; pure (b :: bs)`;
* `replicateB p k` : `0 ↦ pure []`, `k + 1 ↦ do a ← p; l ← replicateB p k; pure (a :: l)`;
  `replicateB_eq_mapB : replicateB p k = mapB (fun _ => p) (List.replicate k u)`.

DSL routine (generic in the element function index `iF`; the loop body `body_mapBStep iF` is
stored at an index `iStep` allocated by the user):
* loop accumulator `[rest, accRev, extra]`; the element function gets `[x, extra]` and returns the
  encoded result, which is consed onto `accRev`;
* `body_mapB iStep` : input `[l, extra]` ↦ `reverse` (library `Idx.reverse`) of the final `accRev`,
  i.e. the results in draw order.

Spec `mapB_impl` (`Implements` form): if the element routine implements every `f x` (`x ∈ l`), all
results have size `≤ VB`, and `M` dominates the loop values and the reverse (see `mapB_M`), then
`body_mapB iStep` implements `mapB f l` with the encoding `encL encB`.
-/

namespace F2e2e.Cost

open F2e2e.Discrete

/-! ## Reference functions -/

section Ref

variable {α β : Type}

/-- Map a randomized function over a list, collecting the results in order. -/
def mapB (f : α → BitProg β) : List α → BitProg (List β)
  | [] => BitProg.pure []
  | x :: xs => (f x).bind (fun b => (mapB f xs).bind (fun bs => BitProg.pure (b :: bs)))

/-- `k` independent draws of `p`, in draw order. -/
def replicateB (p : BitProg β) : ℕ → BitProg (List β)
  | 0 => BitProg.pure []
  | k + 1 => p.bind (fun a => (replicateB p k).bind (fun l => BitProg.pure (a :: l)))

theorem replicateB_eq_mapB {γ : Type} (p : BitProg β) (u : γ) :
    ∀ k, replicateB p k = mapB (fun _ => p) (List.replicate k u)
  | 0 => rfl
  | k + 1 => by
    simp only [replicateB, List.replicate_succ, mapB]
    rw [replicateB_eq_mapB p u k]

/-- Exact runs of `mapB f (x :: xs)`. -/
theorem mapB_cons_run_exact {f : α → BitProg β} {x : α} {xs : List α} {bits : List Bool}
    {bs : List β} (h : (mapB f (x :: xs)).run bits = some (bs, [])) :
    ∃ b₁ b₂ b bs', bits = b₁ ++ b₂ ∧ (f x).run b₁ = some (b, []) ∧
      (mapB f xs).run b₂ = some (bs', []) ∧ bs = b :: bs' := by
  simp only [mapB] at h
  obtain ⟨b₁, b₂, b, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨b₂₁, b₂₂, bs', rfl, h21, h22⟩ := bitProg_run_bind_exact.mp h2
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h22
  exact ⟨b₁, b₂₁, b, bs', by simp, h1, h21, rfl⟩

end Ref

/-! ## The DSL routine -/

/-- Loop body of `mapB` with element function `iF`. Environment `[acc]`,
`acc = [rest, accRev, extra]`: `[[], a, e] ↦ [0, a]`, `[x :: r, a, e] ↦ [1, [r, iF [x, e] :: a, e]]`. -/
def body_mapBStep (iF : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                -- rest; env [rest, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))     -- [0, accRev]
      (ePair (Expr.lit 1)
        (Arith.eTriple (Expr.un UnOp.tail (Expr.var 0))
          (Expr.bin BinOp.cons
            (Expr.call iF (ePair (Expr.un UnOp.head (Expr.var 0))
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `mapB` with the loop body stored at `iStep`: input `[l, extra]` ↦ the results in draw order. -/
def body_mapB (iStep : ℕ) : Expr :=
  Expr.call Idx.reverse
    (Expr.loop iStep (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))

section Body

variable {prog : List Expr} {M : ℕ}

theorem mapBStep_nil_val (iF : ℕ) (av extra : Val)
    (hM : valSize (Val.list [Val.list [], av, extra]) + 6 ≤ M) :
    EvalsVal prog M [Val.list [Val.list [], av, extra]] [] (.inl (body_mapBStep iF))
      (Val.list [Val.int 0, av]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h1 : EvalsVal prog M [Val.list [Val.list [], av, extra]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (Val.list []) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_list, listSize_nil]; omega)
  have hc : EvalsVal prog M [Val.list [], Val.list [Val.list [], av, extra]] []
      (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 1) :=
    EvalsVal.isNil_nil EvalsVal.var0 (by omega)
  have ht : EvalsVal prog M [Val.list [], Val.list [Val.list [], av, extra]] []
      (.inl (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))))
      (Val.list [Val.int 0, av]) := by
    have := EvalsVal.pair (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.list [], Val.list [Val.list [], av, extra]]) (z := 0) (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var1
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  have := EvalsVal.letE h1 (EvalsVal.ite_true (f := ePair (Expr.lit 1)
        (Arith.eTriple (Expr.un UnOp.tail (Expr.var 0))
          (Expr.bin BinOp.cons
            (Expr.call iF (ePair (Expr.un UnOp.head (Expr.var 0))
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
    hc one_ne_zero ht)
  simpa [body_mapBStep] using this

theorem mapBStep_cons_val {iF : ℕ} {bodyF : Expr} (hF : prog[iF]? = some bodyF)
    {x extra bv : Val} {R A : List Val} {b1 : List Bool}
    (hcall : EvalsVal prog M [Val.list [x, extra]] b1 (.inl bodyF) bv)
    (hM : valSize (Val.list [Val.list (x :: R), Val.list A, extra]) + valSize bv + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.list (x :: R), Val.list A, extra]] b1
      (.inl (body_mapBStep iF)) (Val.list [Val.int 1, Val.list [Val.list R, Val.list (bv :: A),
        extra]]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h1 : EvalsVal prog M [Val.list [Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (Val.list (x :: R)) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsVal prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    EvalsVal.isNil_cons EvalsVal.var0 (by omega)
  have hex : EvalsVal prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A, extra]]
      [] (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) extra :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hA : EvalsVal prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))) (Val.list A) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list]; omega)
  have hargs : EvalsVal prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A, extra]]
      [] (.inl (ePair (Expr.un UnOp.head (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [x, extra]) := by
    have := EvalsVal.pair (EvalsVal.head EvalsVal.var0 (by omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hcall' := EvalsVal.call hargs hF hcall
  have hcons := EvalsVal.cons hcall' hA
    (by simp only [valSize_list, listSize_cons]; omega)
  have htr := EvalsVal.triple (EvalsVal.tail EvalsVal.var0
    (by simp only [valSize_list]; omega)) hcons hex
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have hf := EvalsVal.pair (EvalsVal.lit' (z := 1) (by simp; omega)) htr
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
  have := EvalsVal.letE h1 (EvalsVal.ite_false
    (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))) hc rfl hf)
  simpa [body_mapBStep] using this

end Body

/-! ## The loop and the spec -/

section Spec

variable {prog : List Expr} {M : ℕ} {α β : Type}

/-- Size of the reversed encodings of a list of results bounded by `VB`. -/
theorem valSize_rev_map_le (encB : β → Val) (done : List β) (VB : ℕ)
    (h : ∀ b ∈ done, valSize (encB b) ≤ VB) :
    valSize (Val.list (done.map encB).reverse) ≤ 1 + done.length * (VB + 1) := by
  have := listSize_le_of_forall_le ((done.map encB).reverse) VB (by
    intro v hv
    rw [List.mem_reverse] at hv
    obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hv
    exact h b hb)
  simp only [List.length_reverse, List.length_map] at this
  simp only [valSize_list]
  omega

/-- The value bound required by `mapB_impl`. -/
def mapB_M {α : Type} (encA : α → Val) (l : List α) (extra : Val) (VB : ℕ) : ℕ :=
  valSize (encL encA l) + 5 * (1 + l.length * (VB + 1)) + VB + valSize extra + 60

theorem mapB_loop {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encB : β → Val) (extra : Val)
    (f : α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ x, x ∈ l → Implements prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hVb : ∀ x, x ∈ l → ∀ bits b, (f x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapB_M encA l extra VB ≤ M) :
    ∀ r : List α, r <:+ l → ∀ done : List β, done.length + r.length = l.length →
      (∀ b ∈ done, valSize (encB b) ≤ VB) → ∀ bits bs, (mapB f r).run bits = some (bs, []) →
      EvalsVal prog M [] bits
        (.inr (iStep, Val.list [encL encA r, Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro _ done hlen hdone bits bs h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hA := valSize_rev_map_le encB done VB hdone
    have hL := valSize_encL_ge encA l
    simp only [List.length_nil, Nat.add_zero] at hlen
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil, List.append_nil]
    refine mapBStep_nil_val iF _ extra ?_
    simp only [mapB_M, valSize_list, listSize_cons, listSize_nil] at hM hA ⊢
    rw [hlen] at hA
    nlinarith
  | cons x r ih =>
    intro hsuf done hlen hdone bits bs h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapB_cons_run_exact h
    have hb := hVb x hx b₁ b h1
    have hcall := hFi x hx b₁ b h1
    have hdone' : ∀ c ∈ done ++ [b], valSize (encB c) ≤ VB := by
      intro c hc
      rcases List.mem_append.mp hc with hc | hc
      · exact hdone c hc
      · rw [List.mem_singleton.mp hc]; exact hb
    have hlen' : (done ++ [b]).length + r.length = l.length := by
      simp only [List.length_append, List.length_cons, List.length_nil] at hlen ⊢
      omega
    have hrest := ih hsuf' (done ++ [b]) hlen' hdone' b₂ bs' h2
    have hA := valSize_rev_map_le encB done VB hdone
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hdl : done.length ≤ l.length := by simp only [List.length_cons] at hlen; omega
    have hbody := mapBStep_cons_val (R := r.map encA) (A := (done.map encB).reverse) hF hcall
      (by
        simp only [mapB_M, encL, valSize_list, listSize_cons, listSize_nil, List.map_cons]
          at hM hR hA ⊢
        have : done.length * (VB + 1) ≤ l.length * (VB + 1) := Nat.mul_le_mul_right _ hdl
        omega)
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    rw [hval]
    rw [hacc] at hbody
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- Exact runs of `mapB f l` have `|l|` results, each produced by an element run. -/
theorem mapB_run_results {f : α → BitProg β} (encB : β → Val) {VB : ℕ} :
    ∀ (l : List α) (bits : List Bool) (bs : List β),
      (∀ x, x ∈ l → ∀ bits b, (f x).run bits = some (b, []) → valSize (encB b) ≤ VB) →
      (mapB f l).run bits = some (bs, []) →
        bs.length = l.length ∧ ∀ b ∈ bs, valSize (encB b) ≤ VB
  | [], bits, bs, _, h => by
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    exact ⟨rfl, by simp⟩
  | x :: xs, bits, bs, hVb, h => by
    obtain ⟨c₁, c₂, c, cs, rfl, hc1, hc2, rfl⟩ := mapB_cons_run_exact h
    obtain ⟨hlen, hcs⟩ := mapB_run_results encB xs c₂ cs
      (fun y hy => hVb y (List.mem_cons_of_mem x hy)) hc2
    refine ⟨by simp [hlen], fun b hb => ?_⟩
    rcases List.mem_cons.mp hb with rfl | hb'
    · exact hVb x List.mem_cons_self c₁ b hc1
    · exact hcs b hb'

/-- **Spec of `mapB`** (`Implements` form): the results in draw order. -/
theorem mapB_impl {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (f : α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ x, x ∈ l → Implements prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hVb : ∀ x, x ∈ l → ∀ bits b, (f x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapB_M encA l extra VB ≤ M) :
    Implements prog M [Val.list [encL encA l, extra]] (body_mapB iStep) (encL encB) (mapB f l) := by
  intro bits bs h
  have hloop := mapB_loop hstep hF encA encB extra f l VB hFi hVb hM l (List.suffix_refl l) []
    (by simp) (by simp) bits bs h
  simp only [List.map_nil, List.reverse_nil, List.nil_append] at hloop
  have hL := valSize_encL_ge encA l
  -- the initial accumulator `[l, [], extra]`
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [encL encA l, Val.list [], extra]) := by
    simp only [mapB_M] at hM
    have := EvalsVal.triple (EvalsVal.head (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (by omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hl := EvalsVal.loop hinit hloop
  -- the final reverse (library routine, via the reverse bridge)
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  obtain ⟨hlen, hBs⟩ := mapB_run_results encB l bits bs hVb h
  have hsz := valSize_rev_map_le encB bs VB hBs
  have hcall := EvalsVal.call hl hrev (hrs.mono_M (by
    simp only [S_reverse, mapB_M] at hM ⊢
    rw [hlen] at hsz
    omega))
  simpa [encL, body_mapB] using hcall

end Spec

end F2e2e.Cost
