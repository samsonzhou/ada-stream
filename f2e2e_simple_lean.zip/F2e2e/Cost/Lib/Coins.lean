import F2e2e.Cost.Lib.RevAppend
import F2e2e.Cost.Assembly

/-!
# Fresh-bit routines (Idx 90–99)

Reference functions and DSL routines (inputs/outputs as in cut2's `notes/DSL_CONVENTION.md`):

| routine | index | input | output | consumes |
|---|---|---|---|---|
| `readBits` | `Idx.readBits` (loop `Idx.readBitsStep`, reverse by `Idx.revAppendStep`) | `encN k` | `encBits bs` | the `k` bits `bs` |
| `readNat` | `Idx.readNat` (loop `Idx.readNatStep`) | `encN k` | `encN (natOfBits bs)` | the `k` bits `bs` |

`natOfBits bs` is the big-endian value of `bs` (`natOfBits_lt : natOfBits bs < 2 ^ bs.length`,
`natOfBits_append_singleton`).

Specs are stated for an arbitrary bit list `bs` with the input `encN bs.length`: for every tape
starting with `bs` the routine consumes exactly `bs` (by `EvalsLeT.eval_append`), so on a tape of
length at least `k` it consumes the first `k` bits (`tape.take k`).

Loops: `readBits` iterates `[k, r] ↦ [k - 1, coin :: r]` from `[k, []]` and reverses the result;
`readNat` iterates `[k, a] ↦ [k - 1, 2a + coin]` from `[k, 0]`. Both stop at `k = 0`. The loop
rules are `LoopLeT.of_measure` with the state `(d, rest)` (bits read so far, bits still to read)
and the consumed bits `bitsOf (d, rest) = rest`.
-/

namespace F2e2e.Cost

namespace Idx

/-- `readBits : k ↦ the next k fresh bits`. -/
abbrev readBits : ℕ := 90
/-- Loop body of `readBits`. -/
abbrev readBitsStep : ℕ := 91
/-- `readNat : k ↦ the big-endian value of the next k fresh bits`. -/
abbrev readNat : ℕ := 92
/-- Loop body of `readNat`. -/
abbrev readNatStep : ℕ := 93

end Idx

/-! ## Reference function -/

/-- The value of a bit `b` (`1` or `0`). -/
def bitVal (b : Bool) : ℕ := if b then 1 else 0

/-- The big-endian value of a bit list. -/
def natOfBits (bs : List Bool) : ℕ := bs.foldl (fun a b => 2 * a + bitVal b) 0

@[simp] theorem natOfBits_nil : natOfBits [] = 0 := rfl

theorem natOfBits_append_singleton (d : List Bool) (b : Bool) :
    natOfBits (d ++ [b]) = 2 * natOfBits d + bitVal b := by
  simp [natOfBits, List.foldl_append]

theorem bitVal_le_one (b : Bool) : bitVal b ≤ 1 := by
  cases b <;> simp [bitVal]

theorem natOfBits_lt (bs : List Bool) : natOfBits bs < 2 ^ bs.length := by
  induction bs using List.reverseRecOn with
  | nil => simp
  | append_singleton d b ih =>
    rw [natOfBits_append_singleton, List.length_append, List.length_singleton, pow_succ]
    have := bitVal_le_one b
    omega

theorem bitLen_natOfBits_le (bs : List Bool) : bitLen (natOfBits bs : ℤ) ≤ bs.length := by
  rw [bitLen_natCast, Nat.size_le]
  exact natOfBits_lt bs

/-! ## `readBits` -/

/-- Loop body of `readBits`. Environment `[acc]`, `acc = [k, r]`: `[0, r] ↦ [0, r]` (stop),
`[k, r] ↦ [1, [k - 1, coin :: r]]` (reads one fresh bit). -/
def body_readBitsStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                            -- k   env [k, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))     -- r   env [r, k, acc]
      (Expr.ite (Expr.bin BinOp.eq (Expr.var 1) (Expr.lit 0))
        (ePair (Expr.lit 0) (Expr.var 0))
        (ePair (Expr.lit 1)
          (ePair (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
            (Expr.bin BinOp.cons Expr.coin (Expr.var 0))))))

/-- `readBits : k ↦ the next k fresh bits` (in order). Environment `[encN k]`. -/
def body_readBits : Expr :=
  Expr.loop Idx.revAppendStep
    (ePair (Expr.loop Idx.readBitsStep (ePair (Expr.var 0) Expr.nil)) Expr.nil)

/-- Cost bound of one iteration of `readBits` (`k` = number of bits). -/
def C_rbStep (k : ℕ) : ℕ := 2 * Nat.size k + 50

/-- Space bound of the `readBits` loop (on top of the base). -/
def S_rbLoop (k : ℕ) : ℕ := 15 * k + 7 * Nat.size k + 70

/-- Cost bound of `readBits`. -/
def C_readBits (k : ℕ) : ℕ := (k + 1) * (C_rbStep k + 1) + (k + 1) * 34 + 20

/-- Space bound of `readBits` (on top of the base). -/
def S_readBits (k : ℕ) : ℕ := 30 * k + 10 * Nat.size k + 120

theorem readBitsStep_zero (prog : List Expr) (base : ℕ) (r : List Val) :
    EvalsLeT prog base [Val.list [Val.int 0, Val.list r]] [] body_readBitsStep
      (Val.list [Val.int 0, Val.list r]) 30
      (base + 4 * valSize (Val.list [Val.int 0, Val.list r]) + 20) := by
  apply EvalsLeT.of_eval 20
  simp only [body_readBitsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, if_true,
    one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem readBitsStep_succ (prog : List Expr) (base : ℕ) (k : ℤ) (hk : k ≠ 0) (r : List Val)
    (b : Bool) :
    EvalsLeT prog base [Val.list [Val.int k, Val.list r]] [b] body_readBitsStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.list (encB b :: r)]])
      (40 + 2 * bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list r]) + 2 * bitLen (k - 1) + 40) := by
  have hb := valSize_encB_le b
  apply EvalsLeT.of_eval 20
  simp only [body_readBitsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, eval_succ_coin, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ,
    List.head?_cons, List.tail_cons, ne_eq, hk, if_false, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-- Encoding of the `readBits` loop state `(d, rest)` (bits read so far, reversed; bits still to
read). -/
def encRB (s : List Bool × List Bool) : Val :=
  Val.list [Val.int (s.2.length : ℤ), Val.list (s.1.map encB)]

theorem listSize_map_encB_le (d : List Bool) : listSize (d.map encB) ≤ 3 * d.length := by
  have := listSize_le_of_forall_le (d.map encB) 2 (fun v hv => by
    obtain ⟨b, -, rfl⟩ := List.mem_map.mp hv
    exact valSize_encB_le b)
  simp only [List.length_map] at this
  omega

theorem valSize_encRB (s : List Bool × List Bool) :
    valSize (encRB s) = bitLen (s.2.length : ℤ) + listSize (s.1.map encB) + 5 := by
  simp only [encRB, valSize_list, valSize_int, listSize_cons, listSize_nil]
  omega

/-- The `readBits` loop from the state `(d, rest)`: consumes `rest` and returns the reversed list
of all bits `bs = d.reverse ++ rest`. -/
theorem readBits_loop {prog : List Expr} (h : prog[Idx.readBitsStep]? = some body_readBitsStep)
    (bs : List Bool) (base : ℕ) :
    ∀ s : List Bool × List Bool, s.1.reverse ++ s.2 = bs →
      ∃ out, out = Val.list (bs.reverse.map encB) ∧
        LoopLeT prog base Idx.readBitsStep (encRB s) s.2 out
          ((s.2.length + 1) * (C_rbStep bs.length + 1)) (base + S_rbLoop bs.length) := by
  refine LoopLeT.of_measure h encRB (fun s => s.2) _ _ (fun s => s.2.length)
    (C_rbStep bs.length) ?_
  rintro ⟨d, rest⟩ hinv
  simp only at hinv
  have hlen : d.length + rest.length = bs.length := by
    rw [← hinv, List.length_append, List.length_reverse]
  have hd := listSize_map_encB_le d
  cases rest with
  | nil =>
    left
    refine ⟨Val.list (d.map encB), ?_, ?_⟩
    · refine (readBitsStep_zero prog _ (d.map encB)).mono (by simp only [C_rbStep]; omega) ?_
      simp only [encRB, S_rbLoop, List.length_nil, Nat.cast_zero, valSize_int, valSize_list,
        listSize_cons, listSize_nil, bitLen_zero]
      omega
    · simp only [List.append_nil] at hinv
      rw [← hinv, List.reverse_reverse]
  | cons b rest' =>
    right
    have hk : ((b :: rest').length : ℤ) ≠ 0 := by simp only [List.length_cons]; omega
    have hB : bitLen ((b :: rest').length : ℤ) ≤ Nat.size bs.length :=
      bitLen_le_size_of_le (by omega)
    have hB1 : bitLen (((b :: rest').length : ℤ) - 1) ≤ Nat.size bs.length := by
      have : (((b :: rest').length : ℤ) - 1) = ((rest'.length : ℕ) : ℤ) := by
        simp only [List.length_cons]; push_cast; ring
      rw [this]
      exact bitLen_le_size_of_le (by simp only [List.length_cons] at hlen; omega)
    have henc : encRB (b :: d, rest') =
        Val.list [Val.int (((b :: rest').length : ℤ) - 1), Val.list (encB b :: d.map encB)] := by
      simp only [encRB, List.map_cons, List.length_cons]
      push_cast
      ring_nf
    refine ⟨1, (b :: d, rest'), [b], one_ne_zero, rfl, ?_, ?_, ?_⟩
    · rw [henc]
      refine (readBitsStep_succ prog _ _ hk (d.map encB) b).mono
        (by simp only [C_rbStep]; omega) ?_
      simp only [encRB, S_rbLoop, valSize_int, valSize_list, listSize_cons, listSize_nil]
      simp only [List.length_cons] at hlen
      omega
    · simp only [List.reverse_cons, List.append_assoc, List.singleton_append]
      exact hinv
    · simp

/-- **Spec of `readBits`.** On the input `|bs|`, `readBits` consumes exactly the fresh bits `bs`
and returns them (in order). -/
theorem readBits_spec {prog : List Expr} (h1 : prog[Idx.readBitsStep]? = some body_readBitsStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep) (bs : List Bool) (base : ℕ) :
    EvalsLeT prog base [encN bs.length] bs body_readBits (encBits bs) (C_readBits bs.length)
      (base + S_readBits bs.length) := by
  obtain ⟨out, rfl, hloop⟩ := readBits_loop h1 bs base ([], bs) (by simp)
  have hsz : valSize (encN bs.length) = Nat.size bs.length + 1 := valSize_encN _
  -- the initial accumulator `[k, []]`
  have hinit : EvalsLeT prog base [encN bs.length] [] (ePair (Expr.var 0) Expr.nil)
      (encRB ([], bs)) 7 (base + 2 * valSize (encN bs.length) + 7) := by
    have := EvalsLeT.pair (prog := prog) (base := base) (env := [encN bs.length])
      (EvalsLeT.var (i := 0) (v := encN bs.length) rfl) EvalsLeT.nil
    refine (this.cast_bits (by simp)).mono (by simp) ?_
    simp only [valSize_list, listSize_nil, max_le_iff]
    omega
  have h1' := EvalsLeT.loop hinit hloop
  -- reverse the result
  have hr := (revAppend_loop h2 base (bs.reverse.map encB, [])).toT
  have hpair := EvalsLeT.pair h1' (EvalsLeT.nil (base := base + valSize
    (Val.list (bs.reverse.map encB))) (prog := prog) (env := [encN bs.length]))
  have hall := EvalsLeT.loop hpair hr
  have hval : Val.list ((bs.reverse.map encB).reverseAux []) = encBits bs := by
    rw [List.reverseAux_eq, List.append_nil, ← List.map_reverse, List.reverse_reverse]
    rfl
  rw [hval] at hall
  have hlist := listSize_map_encB_le bs.reverse
  rw [List.length_reverse] at hlist
  refine (hall.cast_bits (by simp)).mono ?_ ?_
  · simp only [C_readBits, List.length_map, List.length_reverse]
    omega
  · simp only [encRA, S_readBits, S_rbLoop, max_le_iff, valSize_list, listSize_cons,
      listSize_nil, hsz]
    have := bitLen_le_size_of_le (le_refl bs.length)
    omega

/-- **Spec of `call Idx.readBits`** (for callers): the argument's bits, then `bs`. -/
theorem readBits_call {prog : List Expr} (h0 : prog[Idx.readBits]? = some body_readBits)
    (h1 : prog[Idx.readBitsStep]? = some body_readBitsStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep) {base : ℕ} {env : List Val}
    {a : Expr} {ba bs : List Bool} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (encN bs.length) Ca Sa) :
    EvalsLeT prog base env (ba ++ bs) (Expr.call Idx.readBits a) (encBits bs)
      (1 + Ca + C_readBits bs.length)
      (max Sa (base + valSize (encN bs.length) + S_readBits bs.length)) :=
  EvalsLeT.call ha h0 (readBits_spec h1 h2 bs _)

/-! ## `readNat` -/

/-- Loop body of `readNat`. Environment `[acc]`, `acc = [k, a]`: `[0, a] ↦ [0, a]` (stop),
`[k, a] ↦ [1, [k - 1, a + a + coin]]` (reads one fresh bit). -/
def body_readNatStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                            -- k   env [k, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))     -- a   env [a, k, acc]
      (Expr.ite (Expr.bin BinOp.eq (Expr.var 1) (Expr.lit 0))
        (ePair (Expr.lit 0) (Expr.var 0))
        (ePair (Expr.lit 1)
          (ePair (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
            (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.var 0) (Expr.var 0)) Expr.coin)))))

/-- `readNat : k ↦ natOfBits (next k fresh bits)`. Environment `[encN k]`. -/
def body_readNat : Expr := Expr.loop Idx.readNatStep (ePair (Expr.var 0) (Expr.lit 0))

/-- Cost bound of one iteration of `readNat` (`k` = number of bits). -/
def C_rnStep (k : ℕ) : ℕ := 6 * k + 4 * Nat.size k + 70

/-- Cost bound of `readNat`. -/
def C_readNat (k : ℕ) : ℕ := (k + 1) * (C_rnStep k + 1) + 10

/-- Space bound of `readNat` (on top of the base). -/
def S_readNat (k : ℕ) : ℕ := 15 * k + 15 * Nat.size k + 100

theorem readNatStep_zero (prog : List Expr) (base : ℕ) (a : ℤ) :
    EvalsLeT prog base [Val.list [Val.int 0, Val.int a]] [] body_readNatStep
      (Val.list [Val.int 0, Val.int a]) 30
      (base + 4 * valSize (Val.list [Val.int 0, Val.int a]) + 20) := by
  apply EvalsLeT.of_eval 20
  simp only [body_readNatStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, if_true,
    one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem readNatStep_succ (prog : List Expr) (base : ℕ) (k a : ℤ) (hk : k ≠ 0) (b : Bool) :
    EvalsLeT prog base [Val.list [Val.int k, Val.int a]] [b] body_readNatStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.int (a + a + (bitVal b : ℤ))]])
      (60 + 2 * bitLen k + 3 * bitLen a + 2 * bitLen (a + a))
      (base + 4 * valSize (Val.list [Val.int k, Val.int a]) + 2 * bitLen (k - 1) +
        2 * bitLen (a + a) + 2 * bitLen (a + a + (bitVal b : ℤ)) + 40) := by
  cases b with
  | false =>
    apply EvalsLeT.of_eval 20
    simp only [body_readNatStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
      eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, eval_succ_coin, evalBin,
      evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, List.head?_cons, List.tail_cons, encB, ne_eq, hk, if_false,
      not_true_eq_false, bitVal, Bool.false_eq_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one, Nat.cast_zero, add_zero] <;> omega
  | true =>
    apply EvalsLeT.of_eval 20
    simp only [body_readNatStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
      eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, eval_succ_coin, evalBin,
      evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, List.head?_cons, List.tail_cons, encB, ne_eq, hk, if_false,
      not_true_eq_false, bitVal, if_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one, Nat.cast_one] <;> omega

/-- Encoding of the `readNat` loop state `(d, rest)` (bits read so far; bits still to read). -/
def encRN (s : List Bool × List Bool) : Val :=
  Val.list [Val.int (s.2.length : ℤ), Val.int (natOfBits s.1 : ℤ)]

/-- The `readNat` loop from the state `(d, rest)`: consumes `rest` and returns the value of all
bits `bs = d ++ rest`. -/
theorem readNat_loop {prog : List Expr} (h : prog[Idx.readNatStep]? = some body_readNatStep)
    (bs : List Bool) (base : ℕ) :
    ∀ s : List Bool × List Bool, s.1 ++ s.2 = bs →
      ∃ out, out = encN (natOfBits bs) ∧
        LoopLeT prog base Idx.readNatStep (encRN s) s.2 out
          ((s.2.length + 1) * (C_rnStep bs.length + 1)) (base + S_readNat bs.length) := by
  refine LoopLeT.of_measure h encRN (fun s => s.2) _ _ (fun s => s.2.length)
    (C_rnStep bs.length) ?_
  rintro ⟨d, rest⟩ hinv
  simp only at hinv
  have hlen : d.length + rest.length = bs.length := by
    rw [← hinv, List.length_append]
  have hA : bitLen (natOfBits d : ℤ) ≤ bs.length := by
    have := bitLen_natOfBits_le d
    omega
  cases rest with
  | nil =>
    left
    refine ⟨Val.int (natOfBits d : ℤ), ?_, ?_⟩
    · refine (readNatStep_zero prog _ (natOfBits d : ℤ)).mono
        (by simp only [C_rnStep]; omega) ?_
      simp only [encRN, S_readNat, List.length_nil, Nat.cast_zero, valSize_int, valSize_list,
        listSize_cons, listSize_nil, bitLen_zero]
      omega
    · simp only [List.append_nil] at hinv
      rw [hinv]
      rfl
  | cons b rest' =>
    right
    have hk : ((b :: rest').length : ℤ) ≠ 0 := by simp only [List.length_cons]; omega
    have hB : bitLen ((b :: rest').length : ℤ) ≤ Nat.size bs.length :=
      bitLen_le_size_of_le (by omega)
    have hB1 : bitLen (((b :: rest').length : ℤ) - 1) ≤ Nat.size bs.length := by
      have : (((b :: rest').length : ℤ) - 1) = ((rest'.length : ℕ) : ℤ) := by
        simp only [List.length_cons]; push_cast; ring
      rw [this]
      exact bitLen_le_size_of_le (by simp only [List.length_cons] at hlen; omega)
    have hval : (natOfBits d : ℤ) + (natOfBits d : ℤ) + (bitVal b : ℤ) =
        ((natOfBits (d ++ [b]) : ℕ) : ℤ) := by
      rw [natOfBits_append_singleton]; push_cast; ring
    have hlen' : (d ++ [b]).length ≤ bs.length := by
      simp only [List.length_append, List.length_singleton]
      simp only [List.length_cons] at hlen
      omega
    have hA1 : bitLen ((natOfBits d : ℤ) + (natOfBits d : ℤ) + (bitVal b : ℤ)) ≤ bs.length := by
      rw [hval]
      exact (bitLen_natOfBits_le _).trans hlen'
    have hA2 : bitLen ((natOfBits d : ℤ) + (natOfBits d : ℤ)) ≤ bs.length := by
      have h2 : ((natOfBits d : ℤ) + (natOfBits d : ℤ)) = ((2 * natOfBits d : ℕ) : ℤ) := by
        push_cast; ring
      rw [h2, bitLen_natCast, Nat.size_le]
      have := natOfBits_lt d
      have h3 : 2 ^ d.length * 2 ≤ 2 ^ bs.length := by
        rw [← pow_succ]
        exact Nat.pow_le_pow_right (by norm_num) (by simpa using hlen')
      omega
    have henc : encRN (d ++ [b], rest') =
        Val.list [Val.int (((b :: rest').length : ℤ) - 1),
          Val.int ((natOfBits d : ℤ) + (natOfBits d : ℤ) + (bitVal b : ℤ))] := by
      rw [hval]
      simp only [encRN, List.length_cons]
      push_cast
      ring_nf
    refine ⟨1, (d ++ [b], rest'), [b], one_ne_zero, rfl, ?_, ?_, ?_⟩
    · rw [henc]
      refine (readNatStep_succ prog _ _ _ hk b).mono (by simp only [C_rnStep]; omega) ?_
      simp only [encRN, S_readNat, valSize_int, valSize_list, listSize_cons, listSize_nil]
      have := size_le_self bs.length
      omega
    · simp only [List.append_assoc, List.singleton_append]
      exact hinv
    · simp

/-- **Spec of `readNat`.** On the input `|bs|`, `readNat` consumes exactly the fresh bits `bs` and
returns their big-endian value `natOfBits bs < 2 ^ |bs|`. -/
theorem readNat_spec {prog : List Expr} (h : prog[Idx.readNatStep]? = some body_readNatStep)
    (bs : List Bool) (base : ℕ) :
    EvalsLeT prog base [encN bs.length] bs body_readNat (encN (natOfBits bs))
      (C_readNat bs.length) (base + S_readNat bs.length) := by
  obtain ⟨out, rfl, hloop⟩ := readNat_loop h bs base ([], bs) (by simp)
  have hsz : valSize (encN bs.length) = Nat.size bs.length + 1 := valSize_encN _
  have hinit : EvalsLeT prog base [encN bs.length] [] (ePair (Expr.var 0) (Expr.lit 0))
      (encRN ([], bs)) 8 (base + 2 * valSize (encN bs.length) + 9) := by
    have := EvalsLeT.pair (prog := prog) (base := base) (env := [encN bs.length])
      (EvalsLeT.var (i := 0) (v := encN bs.length) rfl) (EvalsLeT.lit 0)
    refine (this.cast_bits (by simp)).mono (by simp) ?_
    simp only [valSize_int, bitLen_zero, max_le_iff]
    omega
  refine (EvalsLeT.loop hinit hloop).mono ?_ ?_
  · simp only [C_readNat]
    omega
  · simp only [S_readNat, max_le_iff]
    omega

/-- **Spec of `call Idx.readNat`** (for callers): the argument's bits, then `bs`. -/
theorem readNat_call {prog : List Expr} (h0 : prog[Idx.readNat]? = some body_readNat)
    (h1 : prog[Idx.readNatStep]? = some body_readNatStep) {base : ℕ} {env : List Val}
    {a : Expr} {ba bs : List Bool} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (encN bs.length) Ca Sa) :
    EvalsLeT prog base env (ba ++ bs) (Expr.call Idx.readNat a) (encN (natOfBits bs))
      (1 + Ca + C_readNat bs.length)
      (max Sa (base + valSize (encN bs.length) + S_readNat bs.length)) :=
  EvalsLeT.call ha h0 (readNat_spec h1 bs _)

/-! ## Sanity checks (non-vacuity) -/

/-- A test program with entry `readBits`. -/
def readBitsTestProg : List Expr :=
  mkProg body_readBits
    [(Idx.readBitsStep, body_readBitsStep), (Idx.revAppendStep, body_revAppendStep)]

/-- Concretely: on the input `2` and the tape `[true, false, true]`, the test program returns the
bits `[true, false]` and leaves `[true]`. -/
example : (eval readBitsTestProg 40 (valSize (encN 2)) [encN 2] [true, false, true]
    body_readBits).map (fun r => (r.1, r.2.2.2)) = some (encBits [true, false], [true]) := by
  rfl

/-- Via the spec and the `RunsOn` bridge: the test program on the input `2` and any tape starting
with `[true, false]` outputs `[true, false]`, within the spec's space bound. -/
example (rest : List Bool) :
    RunsOn readBitsTestProg (encN 2) ([true, false] ++ rest) (encBits [true, false])
      ((valSize (encN 2) + S_readBits 2 : ℕ) : ℝ) :=
  RunsOn_of_EvalsLeT (mkProg_zero _ _)
    (readBits_spec (prog := readBitsTestProg) (mkProg_get_of_lookup rfl (by norm_num))
      (mkProg_get_of_lookup rfl (by norm_num)) [true, false] (valSize (encN 2)))
    (le_refl _) rest

end F2e2e.Cost
