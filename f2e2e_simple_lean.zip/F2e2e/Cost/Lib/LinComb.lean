import F2e2e.Cost.Lib.ZipWithAdd

/-!
# List library: linear combination `α·a + β·b` (T1) — port of cut2 `Cost/Lib/LinComb.lean`

Reference function: `List.zipWith (fun x y => α * x + β * y) a b`. Input
`Val.list [encInts a, encInts b, Val.int α, Val.int β]`, output
`encInts (List.zipWith (fun x y => α * x + β * y) a b)`.

* `body_linCombStep` (index `Idx.linCombStep`): accumulator `[R, A, B, α, β]` (reversed results
  so far, remaining lists, coefficients): stops with `R` when `A = []` or `B = []`, else
  continues with `[(α x + β y) :: R, A', B', α, β]`.
* `body_linComb` (index `Idx.linComb`): `let R := loop Idx.linCombStep (nil :: input)`, then
  reverse `R` with the `revAppend` loop.

Spec (`linComb_spec`) for entries and coefficients of bit length `≤ K`:
`C_linComb a K = (a.length + 1) * (81 + 4K + 2(K+1)²) + (a.length + 1) * 34 + 15`,
`S_linComb a b K = 6 * V_lc a b K + 12K + 70`, with
`V_lc a b K = valSize (encInts a) + valSize (encInts b) + a.length * (2K + 3) + 2K + 10`.
-/

namespace F2e2e.Cost
namespace Idx
/-- `linComb : [a, b, α, β] ↦ zipWith (fun x y => α * x + β * y) a b`. -/
abbrev linComb : ℕ := 21
/-- Loop body of `linComb`. -/
abbrev linCombStep : ℕ := 22
end Idx

/-- Loop body of `linComb`. Environment `[acc]` with `acc = [R, A, B, α, β]`. -/
def body_linCombStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))                  -- A ; [A, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))
      -- B ; env [B, A, acc]
      (Expr.ite (Expr.un UnOp.isNil (Expr.var 1))
        (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 2)))                     -- [0, R]
        (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
          (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 2)))                   -- [0, R]
          (Expr.letE
            (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))
            -- [α, β] ; env [ab, B, A, acc]
            (ePair (Expr.lit 1)
              (Expr.bin BinOp.cons
                (Expr.bin BinOp.cons
                  (Expr.bin BinOp.add
                    (Expr.bin BinOp.mul (Expr.un UnOp.head (Expr.var 0))
                      (Expr.un UnOp.head (Expr.var 2)))
                    (Expr.bin BinOp.mul (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))
                      (Expr.un UnOp.head (Expr.var 1))))
                  (Expr.un UnOp.head (Expr.var 3)))                               -- (αx+βy) :: R
                (Expr.bin BinOp.cons (Expr.un UnOp.tail (Expr.var 2))
                  (Expr.bin BinOp.cons (Expr.un UnOp.tail (Expr.var 1)) (Expr.var 0)))))))))

/-- `linComb : [a, b, α, β] ↦ zipWith (fun x y => α * x + β * y) a b`. -/
def body_linComb : Expr :=
  Expr.letE (Expr.loop Idx.linCombStep (Expr.bin BinOp.cons Expr.nil (Expr.var 0)))
    (Expr.loop Idx.revAppendStep (ePair (Expr.var 0) Expr.nil))

theorem bitLen_lin_le {α x β y : ℤ} {K : ℕ} (ha : bitLen α ≤ K) (hx : bitLen x ≤ K)
    (hb : bitLen β ≤ K) (hy : bitLen y ≤ K) : bitLen (α * x + β * y) ≤ 2 * K + 1 := by
  have h1 := bitLen_add_le (α * x) (β * y)
  have h2 := bitLen_mul_le α x
  have h3 := bitLen_mul_le β y
  have h4 : max (bitLen (α * x)) (bitLen (β * y)) ≤ 2 * K := max_le (by omega) (by omega)
  omega

/-! ### The loop body -/

theorem lcStep_nilA (prog : List Expr) (base : ℕ) (R B : List Val) (α β : ℤ) :
    EvalsLe prog base [Val.list [Val.list R, Val.list [], Val.list B, Val.int α, Val.int β]]
      body_linCombStep (Val.list [Val.int 0, Val.list R]) 80
      (base + 4 * valSize (Val.list [Val.list R, Val.list [], Val.list B, Val.int α,
        Val.int β]) + 40) := by
  apply EvalsLe.of_eval 30
  simp only [body_linCombStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem lcStep_nilB (prog : List Expr) (base : ℕ) (R : List Val) (x : Val) (A : List Val)
    (α β : ℤ) :
    EvalsLe prog base
      [Val.list [Val.list R, Val.list (x :: A), Val.list [], Val.int α, Val.int β]]
      body_linCombStep (Val.list [Val.int 0, Val.list R]) 80
      (base + 4 * valSize (Val.list [Val.list R, Val.list (x :: A), Val.list [], Val.int α,
        Val.int β]) + 40) := by
  apply EvalsLe.of_eval 30
  simp only [body_linCombStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem lcStep_cons (prog : List Expr) (base : ℕ) (R : List Val) (x y : ℤ) (A B : List Val)
    (α β : ℤ) :
    EvalsLe prog base
      [Val.list [Val.list R, Val.list (Val.int x :: A), Val.list (Val.int y :: B), Val.int α,
        Val.int β]]
      body_linCombStep
      (Val.list [Val.int 1, Val.list [Val.list (Val.int (α * x + β * y) :: R), Val.list A,
        Val.list B, Val.int α, Val.int β]])
      (80 + bitLen (α * x) + bitLen (β * y) + (bitLen α + 1) * (bitLen x + 1) +
        (bitLen β + 1) * (bitLen y + 1))
      (base + 4 * valSize (Val.list [Val.list R, Val.list (Val.int x :: A),
          Val.list (Val.int y :: B), Val.int α, Val.int β]) +
        2 * bitLen (α * x + β * y) + 2 * bitLen (α * x) + 2 * bitLen (β * y) + 40) := by
  apply EvalsLe.of_eval 30
  simp only [body_linCombStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

/-! ### The loop -/

/-- Encoding of the `linComb` loop state `(R, A, B)` for fixed coefficients. -/
def encLC (α β : ℤ) (t : List ℤ × List ℤ × List ℤ) : Val :=
  Val.list [encInts t.1, encInts t.2.1, encInts t.2.2, Val.int α, Val.int β]

/-- Space measure of a `linComb` input. -/
def V_lc (a b : List ℤ) (K : ℕ) : ℕ :=
  valSize (encInts a) + valSize (encInts b) + a.length * (2 * K + 3) + 2 * K + 10

theorem bitLen_zipWith_lin_le (α β : ℤ) (K : ℕ) (ha : bitLen α ≤ K) (hb : bitLen β ≤ K) :
    ∀ (pa pb : List ℤ), (∀ x ∈ pa, bitLen x ≤ K) → (∀ y ∈ pb, bitLen y ≤ K) →
      ∀ z ∈ List.zipWith (fun x y => α * x + β * y) pa pb, bitLen z ≤ 2 * K + 1
  | [], _, _, _, z, hz => by simp at hz
  | _ :: _, [], _, _, z, hz => by simp at hz
  | x :: pa, y :: pb, hx, hy, z, hz => by
    simp only [List.zipWith_cons_cons, List.mem_cons] at hz
    rcases hz with rfl | hz
    · exact bitLen_lin_le ha (hx x List.mem_cons_self) hb (hy y List.mem_cons_self)
    · exact bitLen_zipWith_lin_le α β K ha hb pa pb
        (fun x' h => hx x' (List.mem_cons_of_mem x h))
        (fun y' h => hy y' (List.mem_cons_of_mem y h)) z hz

theorem valSize_zipWith_lin_rev_le (α β : ℤ) (K : ℕ) (ha : bitLen α ≤ K) (hb : bitLen β ≤ K)
    (pa pb : List ℤ) (hx : ∀ x ∈ pa, bitLen x ≤ K) (hy : ∀ y ∈ pb, bitLen y ≤ K) :
    valSize (encInts (List.zipWith (fun x y => α * x + β * y) pa pb).reverse) ≤
      1 + pa.length * (2 * K + 3) := by
  refine le_trans (valSize_encInts_le _ (2 * K + 1) (fun z hz =>
    bitLen_zipWith_lin_le α β K ha hb pa pb hx hy z (List.mem_reverse.mp hz))) ?_
  rw [show 2 * K + 1 + 2 = 2 * K + 3 by omega]
  have : (List.zipWith (fun x y => α * x + β * y) pa pb).reverse.length ≤ pa.length := by
    simp only [List.length_reverse, List.length_zipWith]
    exact min_le_left _ _
  have := Nat.mul_le_mul_right (2 * K + 3) this
  omega

theorem linComb_loop {prog : List Expr}
    (h : prog[Idx.linCombStep]? = some body_linCombStep) (a b : List ℤ) (α β : ℤ) (K : ℕ)
    (ha : ∀ x ∈ a, bitLen x ≤ K) (hb : ∀ y ∈ b, bitLen y ≤ K) (hα : bitLen α ≤ K)
    (hβ : bitLen β ≤ K) (base : ℕ) :
    ∀ t : List ℤ × List ℤ × List ℤ,
      (∃ pa pb, pa ++ t.2.1 = a ∧ pb ++ t.2.2 = b ∧ pa.length = pb.length ∧
        t.1 = (List.zipWith (fun x y => α * x + β * y) pa pb).reverse) →
      ∃ out, out = encInts (List.zipWith (fun x y => α * x + β * y) a b).reverse ∧
        LoopLe prog base Idx.linCombStep (encLC α β t) out
          ((t.2.1.length + 1) * (80 + 4 * K + 2 * ((K + 1) * (K + 1)) + 1))
          (base + 5 * V_lc a b K + 12 * K + 50) := by
  refine LoopLe.of_measure h (encLC α β) _ _ (fun t => t.2.1.length)
    (80 + 4 * K + 2 * ((K + 1) * (K + 1))) ?_
  rintro ⟨R, A, B⟩ ⟨pa, pb, hpa, hpb, hlen, hR⟩
  simp only at hpa hpb hR
  subst hR
  have hpaK : ∀ x ∈ pa, bitLen x ≤ K := fun x hx => ha x (hpa ▸ List.mem_append_left A hx)
  have hpbK : ∀ y ∈ pb, bitLen y ≤ K := fun y hy => hb y (hpb ▸ List.mem_append_left B hy)
  have hRs := valSize_zipWith_lin_rev_le α β K hα hβ pa pb hpaK hpbK
  have hAs : valSize (encInts A) ≤ valSize (encInts a) :=
    valSize_encInts_le_of_suffix (hpa ▸ List.suffix_append pa A)
  have hBs : valSize (encInts B) ≤ valSize (encInts b) :=
    valSize_encInts_le_of_suffix (hpb ▸ List.suffix_append pb B)
  have hpal : pa.length ≤ a.length := by rw [← hpa]; simp
  have hmul := Nat.mul_le_mul_right (2 * K + 3) hpal
  cases A with
  | nil =>
    left
    refine ⟨encInts (List.zipWith (fun x y => α * x + β * y) pa pb).reverse, ?_, ?_⟩
    · refine (lcStep_nilA prog _ _ (B.map Val.int) α β).mono (by omega) ?_
      simp only [encLC, encInts, V_lc, valSize_list, listSize_cons, listSize_nil, valSize_int,
        List.map_nil] at hRs hAs hBs ⊢
      omega
    · rw [← hpa, ← hpb, List.append_nil, zipWith_append_right_of_length _ pa pb B hlen]
  | cons x A =>
    cases B with
    | nil =>
      left
      refine ⟨encInts (List.zipWith (fun x y => α * x + β * y) pa pb).reverse, ?_, ?_⟩
      · refine (lcStep_nilB prog _ _ (Val.int x) (A.map Val.int) α β).mono (by omega) ?_
        simp only [encLC, encInts, V_lc, valSize_list, listSize_cons, listSize_nil,
          valSize_int, List.map_nil, List.map_cons] at hRs hAs hBs ⊢
        omega
      · rw [← hpa, ← hpb, List.append_nil, zipWith_append_left_of_length _ pa (x :: A) pb hlen]
    | cons y B =>
      right
      have hxK : bitLen x ≤ K := ha x (hpa ▸ List.mem_append_right pa List.mem_cons_self)
      have hyK : bitLen y ≤ K := hb y (hpb ▸ List.mem_append_right pb List.mem_cons_self)
      have hax : bitLen (α * x) ≤ 2 * K := le_trans (bitLen_mul_le α x) (by omega)
      have hby : bitLen (β * y) ≤ 2 * K := le_trans (bitLen_mul_le β y) (by omega)
      have hlin : bitLen (α * x + β * y) ≤ 2 * K + 1 := bitLen_lin_le hα hxK hβ hyK
      have hp1 : (bitLen α + 1) * (bitLen x + 1) ≤ (K + 1) * (K + 1) :=
        Nat.mul_le_mul (by omega) (by omega)
      have hp2 : (bitLen β + 1) * (bitLen y + 1) ≤ (K + 1) * (K + 1) :=
        Nat.mul_le_mul (by omega) (by omega)
      refine ⟨1, ((α * x + β * y) :: (List.zipWith (fun x y => α * x + β * y) pa pb).reverse,
        A, B), one_ne_zero, ?_, ⟨pa ++ [x], pb ++ [y], ?_, ?_, ?_, ?_⟩, by simp⟩
      · refine (lcStep_cons prog _ ((List.zipWith (fun x y => α * x + β * y) pa
          pb).reverse.map Val.int) x y (A.map Val.int) (B.map Val.int) α β).mono (by omega) ?_
        simp only [encLC, encInts, V_lc, valSize_list, listSize_cons, listSize_nil,
          valSize_int, List.map_cons] at hRs hAs hBs ⊢
        omega
      · simpa using hpa
      · simpa using hpb
      · simp [hlen]
      · rw [List.zipWith_append hlen]
        simp

/-! ### The spec -/

/-- Cost bound of `linComb` (entries and coefficients of bit length `≤ K`). -/
def C_linComb (a : List ℤ) (K : ℕ) : ℕ :=
  (a.length + 1) * (81 + 4 * K + 2 * ((K + 1) * (K + 1))) + (a.length + 1) * 34 + 15

/-- Space bound of `linComb` (on top of the base). -/
def S_linComb (a b : List ℤ) (K : ℕ) : ℕ := 6 * V_lc a b K + 12 * K + 70

/-- **Spec of `linComb`.** -/
theorem linComb_spec {prog : List Expr}
    (h1 : prog[Idx.linCombStep]? = some body_linCombStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (a b : List ℤ) (α β : ℤ) (K : ℕ) (ha : ∀ x ∈ a, bitLen x ≤ K) (hb : ∀ y ∈ b, bitLen y ≤ K)
    (hα : bitLen α ≤ K) (hβ : bitLen β ≤ K) (base : ℕ) :
    EvalsLe prog base [Val.list [encInts a, encInts b, Val.int α, Val.int β]] body_linComb
      (encInts (List.zipWith (fun x y => α * x + β * y) a b)) (C_linComb a K)
      (base + S_linComb a b K) := by
  set Rf := (List.zipWith (fun x y => α * x + β * y) a b).reverse with hRf
  obtain ⟨out, hout, hloop⟩ := linComb_loop h1 a b α β K ha hb hα hβ base ([], a, b)
    ⟨[], [], by simp, by simp, rfl, by simp⟩
  subst hout
  have hinit : EvalsLe prog base [Val.list [encInts a, encInts b, Val.int α, Val.int β]]
      (Expr.bin BinOp.cons Expr.nil (Expr.var 0)) (encLC α β ([], a, b)) 4
      (base + 2 * valSize (Val.list [encInts a, encInts b, Val.int α, Val.int β]) + 3) := by
    refine (EvalsLe.cons EvalsLe.nil (EvalsLe.var (i := 0) rfl)).mono (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have hA := EvalsLe.loop hinit hloop
  have hinit2 : EvalsLe prog (base + valSize (encInts Rf))
      [encInts Rf, Val.list [encInts a, encInts b, Val.int α, Val.int β]]
      (ePair (Expr.var 0) Expr.nil) (encRA (Rf.map Val.int, [])) 7
      (base + valSize (encInts Rf) + 2 * valSize (encInts Rf) + 7) := by
    refine (EvalsLe.pair (EvalsLe.var (i := 0) rfl) EvalsLe.nil).mono (le_refl _) ?_
    simp only [encInts, valSize_list, listSize_nil, max_le_iff]
    omega
  have hB := EvalsLe.loop hinit2
    (revAppend_loop h2 (base + valSize (encInts Rf)) (Rf.map Val.int, []))
  have hAll := EvalsLe.letE hA hB
  have e : Val.list ((Rf.map Val.int).reverseAux []) =
      encInts (List.zipWith (fun x y => α * x + β * y) a b) := by
    simp [hRf, encInts, List.reverseAux_eq, List.map_reverse]
  rw [e] at hAll
  have hRs : valSize (encInts Rf) ≤ 1 + a.length * (2 * K + 3) :=
    valSize_zipWith_lin_rev_le α β K hα hβ a b ha hb
  have hRl : (Rf.map Val.int).length ≤ a.length := by
    simp only [hRf, List.length_map, List.length_reverse, List.length_zipWith]
    exact min_le_left _ _
  have hRl' := Nat.mul_le_mul_right 34 (Nat.succ_le_succ hRl)
  have hc : (a.length + 1) * (80 + 4 * K + 2 * ((K + 1) * (K + 1)) + 1) =
      (a.length + 1) * (81 + 4 * K + 2 * ((K + 1) * (K + 1))) := by ring
  refine hAll.mono ?_ ?_
  · simp only [C_linComb, hc, Nat.succ_eq_add_one] at hRl' ⊢
    omega
  · simp only [S_linComb, V_lc, max_le_iff, valSize_encRA, encInts, valSize_list,
      listSize_cons, listSize_nil, valSize_int] at hRs ⊢
    omega

end F2e2e.Cost