import F2e2e.Cost.ValRules
import F2e2e.Cost.BitProgBridge

/-!
# State-threading folds over lists, with randomized steps (package L, combinator 1)

Reference functions (C-ALG's loops `birthLoop`, `step3Loop`, `step4Loop` are instances):
* `foldB f l s` : `[] ↦ pure s`, `x :: xs ↦ do s' ← f x s; foldB f xs s'` (`f : α → σ → BitProg σ`);
* `foldBE stop f l s` : the same with an early exit (`pure s` as soon as `stop s`); it equals
  `foldB` with the step `fun x s => if stop s then pure s else f x s` (`foldBE_eq_foldB`);
* `foldP g l s`, `foldPE stop g l s` : the deterministic versions (`foldB_pure`, `foldPE_eq_foldP`).

DSL routine (generic in the step function index `iF`; the loop body `body_foldBStep iF` is stored
at an index `iStep` allocated by the user):
* accumulator `[s, rest, extra]` (`extra` = any fixed value, e.g. encoded parameters, passed to
  every step); the step function gets `[x, s, extra]` and returns the new state;
* `body_foldB iStep` : input `[s, l, extra]` ↦ final state.

Specs (`Implements` form, `F2e2e/Cost/BitProgBridge.lean`):
* `foldB_impl` : if the step routine implements every `f x s` (for `x ∈ l` and states satisfying
  an invariant `P` preserved by the steps), states satisfying `P` have size `≤ VS`, and
  `M ≥ 2 VS + |encL encA l| + |extra| + 20`, then `body_foldB iStep` implements `foldB f l s`;
* `foldP_val` : the deterministic version (`EvalsVal` with no fresh bits).
-/

namespace F2e2e.Cost

open F2e2e.Discrete

/-! ## Reference functions -/

section Ref

variable {α σ : Type}

/-- Left fold of a list with a randomized step (element first). -/
def foldB (f : α → σ → BitProg σ) : List α → σ → BitProg σ
  | [], s => BitProg.pure s
  | x :: xs, s => (f x s).bind (foldB f xs)

/-- Left fold with a randomized step and an early exit as soon as `stop s` holds. -/
def foldBE (stop : σ → Bool) (f : α → σ → BitProg σ) : List α → σ → BitProg σ
  | [], s => BitProg.pure s
  | x :: xs, s => if stop s then BitProg.pure s else (f x s).bind (foldBE stop f xs)

/-- Deterministic left fold (element first). -/
def foldP (g : α → σ → σ) : List α → σ → σ
  | [], s => s
  | x :: xs, s => foldP g xs (g x s)

/-- Deterministic left fold with an early exit as soon as `stop s` holds. -/
def foldPE (stop : σ → Bool) (g : α → σ → σ) : List α → σ → σ
  | [], s => s
  | x :: xs, s => if stop s then s else foldPE stop g xs (g x s)

@[simp] theorem foldB_nil (f : α → σ → BitProg σ) (s : σ) : foldB f [] s = BitProg.pure s := rfl

theorem foldB_cons (f : α → σ → BitProg σ) (x : α) (xs : List α) (s : σ) :
    foldB f (x :: xs) s = (f x s).bind (foldB f xs) := rfl

/-- With a step that fixes stopped states, a stopped state is final. -/
theorem foldB_of_stop (stop : σ → Bool) (f : α → σ → BitProg σ) :
    ∀ (l : List α) (s : σ), stop s = true →
      foldB (fun x s => if stop s then BitProg.pure s else f x s) l s = BitProg.pure s
  | [], _, _ => rfl
  | x :: xs, s, hs => by
    rw [foldB_cons]
    simp only [hs, if_true, BitProg.bind_pure']
    exact foldB_of_stop stop f xs s hs

theorem foldBE_eq_foldB (stop : σ → Bool) (f : α → σ → BitProg σ) :
    ∀ (l : List α) (s : σ),
      foldBE stop f l s = foldB (fun x s => if stop s then BitProg.pure s else f x s) l s
  | [], _ => rfl
  | x :: xs, s => by
    by_cases hs : stop s = true
    · simp only [foldBE, hs, if_true]
      exact (foldB_of_stop stop f (x :: xs) s hs).symm
    · simp only [foldBE, hs, if_false, foldB_cons, Bool.false_eq_true]
      congr 1
      funext s'
      exact foldBE_eq_foldB stop f xs s'

/-- The deterministic fold is the fold with pure steps. -/
theorem foldB_pure (g : α → σ → σ) :
    ∀ (l : List α) (s : σ), foldB (fun x s => BitProg.pure (g x s)) l s = BitProg.pure (foldP g l s)
  | [], _ => rfl
  | x :: xs, s => by
    rw [foldB_cons, BitProg.bind_pure']
    exact foldB_pure g xs (g x s)

theorem foldPE_eq_foldP (stop : σ → Bool) (g : α → σ → σ) :
    ∀ (l : List α) (s : σ), foldPE stop g l s = foldP (fun x s => if stop s then s else g x s) l s
  | [], _ => rfl
  | x :: xs, s => by
    by_cases hs : stop s = true
    · simp only [foldPE, hs, if_true]
      have key : ∀ (l : List α), foldP (fun x s => if stop s then s else g x s) l s = s := by
        intro l
        induction l with
        | nil => rfl
        | cons y ys ih => simp only [foldP, hs, if_true]; exact ih
      exact (key (x :: xs)).symm
    · simp only [foldPE, hs, if_false, foldP, Bool.false_eq_true]
      exact foldPE_eq_foldP stop g xs (g x s)

end Ref

/-! ## The DSL routine -/

/-- Loop body of `foldB` with step function `iF`. Environment `[acc]`, `acc = [s, rest, extra]`:
`[s, [], e] ↦ [0, s]`, `[s, x :: r, e] ↦ [1, [iF [x, s, e], r, e]]`. -/
def body_foldBStep (iF : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))            -- rest; env [rest, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))                  -- [0, s]
      (ePair (Expr.lit 1)
        (Arith.eTriple
          (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
            (Expr.un UnOp.head (Expr.var 1))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
          (Expr.un UnOp.tail (Expr.var 0))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `foldB` with the loop body stored at `iStep`: input `[s, l, extra]` ↦ final state. -/
def body_foldB (iStep : ℕ) : Expr := Expr.loop iStep (Expr.var 0)

section Body

variable {prog : List Expr} {M : ℕ}

theorem foldBStep_nil_val (iF : ℕ) (sv extra : Val)
    (hM : valSize (Val.list [sv, Val.list [], extra]) + 6 ≤ M) :
    EvalsVal prog M [Val.list [sv, Val.list [], extra]] [] (.inl (body_foldBStep iF))
      (Val.list [Val.int 0, sv]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h1 : EvalsVal prog M [Val.list [sv, Val.list [], extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))) (Val.list []) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var0
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_nil]; omega)
  have hc : EvalsVal prog M [Val.list [], Val.list [sv, Val.list [], extra]] []
      (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 1) :=
    EvalsVal.isNil_nil EvalsVal.var0 (by omega)
  have ht : EvalsVal prog M [Val.list [], Val.list [sv, Val.list [], extra]] []
      (.inl (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))) (Val.list [Val.int 0, sv]) := by
    have := EvalsVal.pair (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.list [], Val.list [sv, Val.list [], extra]]) (z := 0) (by simp; omega))
      (EvalsVal.head EvalsVal.var1 (by omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  have := EvalsVal.letE h1 (EvalsVal.ite_true (t := ePair (Expr.lit 0) (Expr.un UnOp.head
    (Expr.var 1))) (f := ePair (Expr.lit 1) (Arith.eTriple
          (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
            (Expr.un UnOp.head (Expr.var 1))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
          (Expr.un UnOp.tail (Expr.var 0))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
    hc one_ne_zero ht)
  simpa [body_foldBStep] using this

theorem foldBStep_cons_val {iF : ℕ} {bodyF : Expr} (hF : prog[iF]? = some bodyF)
    {sv x extra sv' : Val} {R : List Val} {b1 : List Bool}
    (hcall : EvalsVal prog M [Val.list [x, sv, extra]] b1 (.inl bodyF) sv')
    (hM : valSize (Val.list [sv, Val.list (x :: R), extra]) + valSize sv' + 10 ≤ M) :
    EvalsVal prog M [Val.list [sv, Val.list (x :: R), extra]] b1 (.inl (body_foldBStep iF))
      (Val.list [Val.int 1, Val.list [sv', Val.list R, extra]]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  -- environment after the binding of `rest`
  have h1 : EvalsVal prog M [Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))) (Val.list (x :: R)) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var0
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsVal prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    EvalsVal.isNil_cons EvalsVal.var0 (by omega)
  -- `extra` from the accumulator
  have hex : EvalsVal prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) extra :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hargs : EvalsVal prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) (Expr.un UnOp.head (Expr.var 1))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [x, sv, extra]) := by
    have := EvalsVal.triple (EvalsVal.head EvalsVal.var0 (by omega))
      (EvalsVal.head EvalsVal.var1 (by omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hcall' := EvalsVal.call hargs hF hcall
  have htr : EvalsVal prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] b1
      (.inl (Arith.eTriple
        (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
          (Expr.un UnOp.head (Expr.var 1))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
        (Expr.un UnOp.tail (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [sv', Val.list R, extra]) := by
    have := EvalsVal.triple hcall' (EvalsVal.tail EvalsVal.var0
      (by simp only [valSize_list]; omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hf : EvalsVal prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] b1
      (.inl (ePair (Expr.lit 1) (Arith.eTriple
        (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
          (Expr.un UnOp.head (Expr.var 1))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
        (Expr.un UnOp.tail (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))))
      (Val.list [Val.int 1, Val.list [sv', Val.list R, extra]]) := by
    have := EvalsVal.pair (EvalsVal.lit' (z := 1) (by simp; omega)) htr
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
    simpa using this
  have := EvalsVal.letE h1 (EvalsVal.ite_false
    (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1))) hc rfl hf)
  simpa [body_foldBStep] using this

end Body

/-! ## The loop and the specs -/

section Spec

variable {prog : List Expr} {M : ℕ} {α σ : Type}

theorem foldB_loop {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_foldBStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encS : σ → Val) (extra : Val)
    (f : α → σ → BitProg σ) (P : σ → Prop) (l : List α) (VS : ℕ)
    (hP : ∀ x s bits s', x ∈ l → P s → (f x s).run bits = some (s', []) → P s')
    (hFi : ∀ x s, x ∈ l → P s → Implements prog M [Val.list [encA x, encS s, extra]] bodyF encS
      (f x s))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) :
    ∀ r : List α, r <:+ l → ∀ s, P s → ∀ bits s', (foldB f r s).run bits = some (s', []) →
      EvalsVal prog M [] bits (.inr (iStep, Val.list [encS s, encL encA r, extra])) (encS s') := by
  intro r
  induction r with
  | nil =>
    intro _ s hs bits s' h
    obtain ⟨hb1, hb2⟩ := bitProg_run_pure_exact.mp h
    subst hb1
    rw [hb2]
    have hVs := hV s hs
    have hL := valSize_encL_ge encA l
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil]
    exact foldBStep_nil_val iF (encS s) extra
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  | cons x r ih =>
    intro hsuf s hs bits s' h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    rw [foldB_cons] at h
    obtain ⟨b₁, b₂, s'', rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    have hs'' := hP x s b₁ s'' hx hs h1
    have hcall := hFi x s hx hs b₁ s'' h1
    have hrest := ih hsuf' s'' hs'' b₂ s' h2
    have hVs := hV s hs
    have hVs'' := hV s'' hs''
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hbody := foldBStep_cons_val (R := r.map encA) hF hcall
      (by simp only [encL, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hR hM ⊢
          omega)
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- **Spec of `foldB`** (`Implements` form). -/
theorem foldB_impl {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_foldBStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encS : σ → Val) (extra : Val)
    (f : α → σ → BitProg σ) (P : σ → Prop) (l : List α) (VS : ℕ)
    (hP : ∀ x s bits s', x ∈ l → P s → (f x s).run bits = some (s', []) → P s')
    (hFi : ∀ x s, x ∈ l → P s → Implements prog M [Val.list [encA x, encS s, extra]] bodyF encS
      (f x s))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : P s) :
    Implements prog M [Val.list [encS s, encL encA l, extra]] (body_foldB iStep) encS
      (foldB f l s) := by
  intro bits s' h
  exact EvalsVal.loop EvalsVal.var0
    (foldB_loop hstep hF encA encS extra f P l VS hP hFi hV hM l (List.suffix_refl l) s hs bits s' h)

/-- **Spec of the deterministic fold** (`foldP`): no fresh bits. -/
theorem foldP_val {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_foldBStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encS : σ → Val) (extra : Val)
    (g : α → σ → σ) (P : σ → Prop) (l : List α) (VS : ℕ)
    (hP : ∀ x s, x ∈ l → P s → P (g x s))
    (hG : ∀ x s, x ∈ l → P s →
      EvalsVal prog M [Val.list [encA x, encS s, extra]] [] (.inl bodyF) (encS (g x s)))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : P s) :
    EvalsVal prog M [Val.list [encS s, encL encA l, extra]] [] (.inl (body_foldB iStep))
      (encS (foldP g l s)) := by
  have himpl := foldB_impl hstep hF encA encS extra (fun x s => BitProg.pure (g x s)) P l VS
    (fun x s bits s' hx hs h => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
      exact hP x s hx hs)
    (fun x s hx hs => Implements.of_det (hG x s hx hs)) hV hM s hs
  exact himpl [] (foldP g l s) (by rw [foldB_pure]; rfl)

end Spec

end F2e2e.Cost
