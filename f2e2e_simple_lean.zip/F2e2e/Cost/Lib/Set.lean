import F2e2e.Cost.Lib.RevAppend

/-!
# List library: `set` (update the `n`-th entry) (T1) — port of cut2 `Cost/Lib/Set.lean`

Reference function: `List.set l n x`. Input `Val.list [Val.list l, Val.int n, x]` (`n : ℕ`),
output `Val.list (l.set n x)`.

* `body_setStep` (index `Idx.setStep`): accumulator `[k, r, P]` (remaining index, remaining
  list, reversed prefix): `[k, [], P] ↦ [0, [P, []]]`, `[0, y :: r, P] ↦ [0, [P, y :: r]]`,
  `[k, y :: r, P] ↦ [1, [k - 1, r, y :: P]]` for `k ≠ 0`.
* `body_set` (index `Idx.set`): run the loop from `[n, l, []]` to get `[P, r]`; then
  `revAppend P r'` with `r' = []` if `r = []` and `r' = x :: tail r` otherwise.

Needs `prog[Idx.setStep]? = some body_setStep` and
`prog[Idx.revAppendStep]? = some body_revAppendStep`.
-/

namespace F2e2e.Cost
/-- Loop body of `set`. Environment `[acc]` with `acc = [k, r, P]`. -/
def body_setStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))              -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0)                                                     -- [0, [P, r]]
        (ePair (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))
          (Expr.var 0)))
      (Expr.letE (Expr.un UnOp.head (Expr.var 1))                             -- k ; env [k, r, acc]
        (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
          (ePair (Expr.lit 0)                                                 -- [0, [P, r]]
            (ePair (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))
              (Expr.var 1)))
          (ePair (Expr.lit 1)                                                 -- [1, [k-1, tail r, head r :: P]]
            (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
              (ePair (Expr.un UnOp.tail (Expr.var 1))
                (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 1))
                  (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2)))))))))))

/-- Second argument of the final `revAppend`: `[]` if `r = []`, else `x :: tail r`.
Environment `[pr, input]` with `pr = [P, r]` and `input = [l, n, x]`. -/
def setFix : Expr :=
  Expr.ite (Expr.un UnOp.isNil (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))))
    (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))
    (Expr.bin BinOp.cons
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))
      (Expr.un UnOp.tail (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))

/-- `set : [l, n, x] ↦ l.set n x`. -/
def body_set : Expr :=
  Expr.letE
    (Expr.loop Idx.setStep
      (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))
        (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
          (Expr.bin BinOp.cons Expr.nil Expr.nil))))
    (Expr.loop Idx.revAppendStep (ePair (Expr.un UnOp.head (Expr.var 0)) setFix))

/-! ### The loop body -/

theorem setStep_nil (prog : List Expr) (base : ℕ) (k : ℤ) (P : List Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list [], Val.list P]] body_setStep
      (Val.list [Val.int 0, Val.list [Val.list P, Val.list []]]) 29
      (base + 4 * valSize (Val.list [Val.int k, Val.list [], Val.list P]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_setStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem setStep_zero (prog : List Expr) (base : ℕ) (y : Val) (r P : List Val) :
    EvalsLe prog base [Val.list [Val.int 0, Val.list (y :: r), Val.list P]] body_setStep
      (Val.list [Val.int 0, Val.list [Val.list P, Val.list (y :: r)]]) 38
      (base + 4 * valSize (Val.list [Val.int 0, Val.list (y :: r), Val.list P]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_setStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem setStep_succ (prog : List Expr) (base : ℕ) (k : ℤ) (hk : k ≠ 0) (y : Val)
    (r P : List Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list (y :: r), Val.list P]] body_setStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.list r, Val.list (y :: P)]])
      (54 + 2 * bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list (y :: r), Val.list P]) +
        2 * bitLen (k - 1) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_setStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop -/

/-- Encoding of the `set` loop state `(k, r, P)`. -/
def encSetState (s : ℕ × List Val × List Val) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.list s.2.1, Val.list s.2.2]

/-- Peak bound of the `set` loop (on top of the base). -/
def S_setLoop (l : List Val) (n : ℕ) : ℕ := 5 * valSize (Val.list l) + 7 * Nat.size n + 50

theorem set_loop {prog : List Expr} (h : prog[Idx.setStep]? = some body_setStep)
    (l : List Val) (n : ℕ) (base : ℕ) :
    ∀ s : ℕ × List Val × List Val, (s.2.2.reverse ++ s.2.1 = l ∧ s.2.2.length + s.1 = n) →
      ∃ out, (∃ P r, out = Val.list [Val.list P, Val.list r] ∧ P.reverse ++ r = l ∧
          P.length ≤ n ∧ (r = [] ∨ P.length = n)) ∧
        LoopLe prog base Idx.setStep (encSetState s) out
          ((s.2.1.length + 1) * (54 + 2 * Nat.size n + 1)) (base + S_setLoop l n) := by
  refine LoopLe.of_measure h encSetState _ _ (fun s => s.2.1.length) (54 + 2 * Nat.size n) ?_
  rintro ⟨k, r, P⟩ ⟨hPr, hlen⟩
  simp only at hPr hlen
  have hk : k ≤ n := by omega
  have hB : bitLen (k : ℤ) ≤ Nat.size n := bitLen_le_size_of_le hk
  have hsz : listSize P + listSize r = listSize l := by
    rw [← hPr, listSize_append, listSize_reverse]
  cases r with
  | nil =>
    left
    refine ⟨Val.list [Val.list P, Val.list []], ?_, ⟨P, [], rfl, hPr, by omega, Or.inl rfl⟩⟩
    refine (setStep_nil prog _ k P).mono (by omega) ?_
    simp only [encSetState, S_setLoop, valSize_int, valSize_list, listSize_cons,
      listSize_nil] at hsz ⊢
    omega
  | cons y r =>
    cases k with
    | zero =>
      left
      refine ⟨Val.list [Val.list P, Val.list (y :: r)], ?_,
        ⟨P, y :: r, rfl, hPr, by omega, Or.inr (by omega)⟩⟩
      refine (setStep_zero prog _ y r P).mono (by omega) ?_
      simp only [encSetState, S_setLoop, valSize_int, valSize_list, listSize_cons,
        listSize_nil, Nat.cast_zero, bitLen_zero] at hsz ⊢
      omega
    | succ k =>
      right
      have hk1 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
      have hB1 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ Nat.size n := by
        have := bitLen_le_size_of_le (show k ≤ n by omega)
        simpa using this
      have henc : encSetState (k, r, y :: P) =
          Val.list [Val.int (((k + 1 : ℕ) : ℤ) - 1), Val.list r, Val.list (y :: P)] := by
        simp [encSetState]
      refine ⟨1, (k, r, y :: P), one_ne_zero, ?_, ⟨?_, ?_⟩, ?_⟩
      · rw [henc]
        refine (setStep_succ prog _ _ hk1 y r P).mono (by omega) ?_
        simp only [encSetState, S_setLoop, valSize_int, valSize_list, listSize_cons,
          listSize_nil] at hsz ⊢
        omega
      · simp only [List.reverse_cons, List.append_assoc, List.singleton_append]
        exact hPr
      · simp only [List.length_cons]; omega
      · simp

/-! ### The final `revAppend` -/

theorem setFix_nil (prog : List Expr) (base : ℕ) (P : List Val) (inp : Val) :
    EvalsLe prog base [Val.list [Val.list P, Val.list []], inp]
      (ePair (Expr.un UnOp.head (Expr.var 0)) setFix) (encRA (P, [])) 30
      (base + 4 * valSize (Val.list [Val.list P, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [setFix, encRA, ePair, eval_succ_var, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_one]) <;> omega

theorem setFix_cons (prog : List Expr) (base : ℕ) (P : List Val) (y : Val) (r l : List Val)
    (m : ℤ) (x : Val) :
    EvalsLe prog base [Val.list [Val.list P, Val.list (y :: r)], Val.list [Val.list l, Val.int m, x]]
      (ePair (Expr.un UnOp.head (Expr.var 0)) setFix) (encRA (P, x :: r)) 40
      (base + 4 * valSize (Val.list [Val.list P, Val.list (y :: r)]) +
        2 * valSize (Val.list [Val.list l, Val.int m, x]) + 2 * valSize x + 20) := by
  apply EvalsLe.of_eval 20
  simp only [setFix, encRA, ePair, eval_succ_var, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false,
    if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero]) <;> omega

/-! ### The spec -/

/-- Cost bound of `set`. -/
def C_set (l : List Val) (n : ℕ) : ℕ :=
  (l.length + 1) * (55 + 2 * Nat.size n) + (l.length + 1) * 34 + 60

/-- Space bound of `set` (on top of the base). -/
def S_set (l : List Val) (n : ℕ) (x : Val) : ℕ :=
  10 * valSize (Val.list l) + 7 * Nat.size n + 10 * valSize x + 100

/-- **Spec of `set`.** -/
theorem set_spec {prog : List Expr} (h1 : prog[Idx.setStep]? = some body_setStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep) (l : List Val) (n : ℕ) (x : Val)
    (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ), x]] body_set (Val.list (l.set n x))
      (C_set l n) (base + S_set l n x) := by
  have hn : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
  -- the main loop
  obtain ⟨out, ⟨P, r, rfl, hPr, hPn, hcase⟩, hloop⟩ :=
    set_loop h1 l n base (n, l, []) ⟨by simp, by simp⟩
  have hinit : EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ), x]]
      (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))
        (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
          (Expr.bin BinOp.cons Expr.nil Expr.nil)))
      (encSetState (n, l, [])) 16
      (base + 3 * valSize (Val.list [Val.list l, Val.int (n : ℤ), x]) + 20) := by
    refine (EvalsLe.cons (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))
      (EvalsLe.cons (EvalsLe.head (EvalsLe.var (i := 0) rfl))
        (EvalsLe.cons EvalsLe.nil EvalsLe.nil))).mono (le_refl _) ?_
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have hA := EvalsLe.loop hinit hloop
  have hsz : listSize P + listSize r = listSize l := by
    rw [← hPr, listSize_append, listSize_reverse]
  have hPl : P.length ≤ l.length := by rw [← hPr]; simp
  have hPl' := Nat.mul_le_mul_right 34 (Nat.succ_le_succ hPl)
  have hc : (l.length + 1) * (54 + 2 * Nat.size n + 1) = (l.length + 1) * (55 + 2 * Nat.size n) := by
    ring
  cases r with
  | nil =>
    have hB := EvalsLe.loop (setFix_nil prog _ P (Val.list [Val.list l, Val.int (n : ℤ), x]))
      (revAppend_loop h2 (base + valSize (Val.list [Val.list P, Val.list []])) (P, []))
    have hAll := EvalsLe.letE hA hB
    have e : Val.list (P.reverseAux []) = Val.list (l.set n x) := by
      rw [List.reverseAux_eq, List.append_nil]
      rw [List.append_nil] at hPr
      rw [hPr, List.set_eq_of_length_le]
      rw [← hPr, List.length_reverse]
      exact hPn
    rw [e] at hAll
    refine hAll.mono ?_ ?_
    · simp only [C_set, hc, Nat.succ_eq_add_one] at hPl' ⊢
      omega
    · simp only [S_set, S_setLoop, max_le_iff, valSize_encRA, valSize_int, valSize_list,
        listSize_cons, listSize_nil, hn] at hsz ⊢
      omega
  | cons y r =>
    have hPn' : P.length = n := by
      rcases hcase with h | h
      · exact absurd h (List.cons_ne_nil y r)
      · exact h
    have hB := EvalsLe.loop (setFix_cons prog _ P y r l (n : ℤ) x)
      (revAppend_loop h2 (base + valSize (Val.list [Val.list P, Val.list (y :: r)])) (P, x :: r))
    have hAll := EvalsLe.letE hA hB
    have e : Val.list (P.reverseAux (x :: r)) = Val.list (l.set n x) := by
      rw [List.reverseAux_eq, ← hPr, List.set_append_right _ _ (by simp [hPn'])]
      simp [hPn']
    rw [e] at hAll
    refine hAll.mono ?_ ?_
    · simp only [C_set, hc, Nat.succ_eq_add_one] at hPl' ⊢
      omega
    · simp only [S_set, S_setLoop, max_le_iff, valSize_encRA, valSize_int, valSize_list,
        listSize_cons, listSize_nil, hn] at hsz ⊢
      omega

end F2e2e.Cost