import F2e2e.Cost.Lib.Util

/-!
# List library: equality and membership for integer lists (T1) — port of cut2 `Cost/Lib/Eq.lean`

* `body_eqInts` (index `Idx.eqInts`): `[encInts a, encInts b] ↦ Val.int (if a = b then 1 else 0)`;
  loop body `body_eqIntsStep` (index `Idx.eqIntsStep`) on the accumulator `[A, B]`.
* `body_memInts` (index `Idx.memInts`): `[encInts l, Val.int z] ↦ Val.int (if z ∈ l then 1 else 0)`;
  loop body `body_memIntsStep` (index `Idx.memIntsStep`) on the accumulator `[r, z]`.
-/

namespace F2e2e.Cost
namespace Idx
/-- `eqInts : [a, b] ↦ (a = b)`. -/
abbrev eqInts : ℕ := 27
/-- Loop body of `eqInts`. -/
abbrev eqIntsStep : ℕ := 28
/-- `memInts : [l, z] ↦ (z ∈ l)`. -/
abbrev memInts : ℕ := 29
/-- Loop body of `memInts`. -/
abbrev memIntsStep : ℕ := 30
end Idx

/-! ### `eqInts` -/

/-- Loop body of `eqInts`. Environment `[acc]` with `acc = [A, B]`. -/
def body_eqIntsStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- A ; env [A, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))           -- B ; env [B, A, acc]
      (Expr.ite (Expr.un UnOp.isNil (Expr.var 1))
        (ePair (Expr.lit 0) (Expr.un UnOp.isNil (Expr.var 0)))                -- [0, B = []]
        (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
          (ePair (Expr.lit 0) (Expr.lit 0))                                   -- [0, 0]
          (Expr.ite (Expr.bin BinOp.eq (Expr.un UnOp.head (Expr.var 1))
              (Expr.un UnOp.head (Expr.var 0)))
            (ePair (Expr.lit 1)
              (ePair (Expr.un UnOp.tail (Expr.var 1)) (Expr.un UnOp.tail (Expr.var 0))))
            (ePair (Expr.lit 0) (Expr.lit 0))))))

/-- `eqInts : [a, b] ↦ (a = b)`; the input is the initial accumulator. -/
def body_eqInts : Expr := Expr.loop Idx.eqIntsStep (Expr.var 0)

theorem eqIntsStep_nil_nil (prog : List Expr) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list [], Val.list []]] body_eqIntsStep
      (Val.list [Val.int 0, Val.int 1]) 60
      (base + 4 * valSize (Val.list [Val.list [], Val.list []]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_eqIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem eqIntsStep_nil_cons (prog : List Expr) (base : ℕ) (y : Val) (B : List Val) :
    EvalsLe prog base [Val.list [Val.list [], Val.list (y :: B)]] body_eqIntsStep
      (Val.list [Val.int 0, Val.int 0]) 60
      (base + 4 * valSize (Val.list [Val.list [], Val.list (y :: B)]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_eqIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem eqIntsStep_cons_nil (prog : List Expr) (base : ℕ) (x : Val) (A : List Val) :
    EvalsLe prog base [Val.list [Val.list (x :: A), Val.list []]] body_eqIntsStep
      (Val.list [Val.int 0, Val.int 0]) 60
      (base + 4 * valSize (Val.list [Val.list (x :: A), Val.list []]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_eqIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem eqIntsStep_eq (prog : List Expr) (base : ℕ) (x : ℤ) (A B : List Val) :
    EvalsLe prog base [Val.list [Val.list (Val.int x :: A), Val.list (Val.int x :: B)]]
      body_eqIntsStep (Val.list [Val.int 1, Val.list [Val.list A, Val.list B]])
      (60 + 2 * bitLen x)
      (base + 4 * valSize (Val.list [Val.list (Val.int x :: A), Val.list (Val.int x :: B)]) +
        30) := by
  apply EvalsLe.of_eval 20
  simp only [body_eqIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem eqIntsStep_ne (prog : List Expr) (base : ℕ) (x y : ℤ) (hxy : x ≠ y) (A B : List Val) :
    EvalsLe prog base [Val.list [Val.list (Val.int x :: A), Val.list (Val.int y :: B)]]
      body_eqIntsStep (Val.list [Val.int 0, Val.int 0]) (60 + bitLen x + bitLen y)
      (base + 4 * valSize (Val.list [Val.list (Val.int x :: A), Val.list (Val.int y :: B)]) +
        30) := by
  apply EvalsLe.of_eval 20
  simp only [body_eqIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hxy,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero]) <;> omega

/-- Encoding of the `eqInts` loop state. -/
def encEqState (t : List ℤ × List ℤ) : Val := Val.list [encInts t.1, encInts t.2]

/-- Cost bound of `eqInts` (entries of bit length `≤ B`). -/
def C_eqInts (a : List ℤ) (B : ℕ) : ℕ := (a.length + 1) * (61 + 2 * B) + 2

/-- Space bound of `eqInts` (on top of the base). -/
def S_eqInts (a b : List ℤ) : ℕ := 5 * valSize (Val.list [encInts a, encInts b]) + 30

theorem eqInts_loop {prog : List Expr} (h : prog[Idx.eqIntsStep]? = some body_eqIntsStep)
    (a b : List ℤ) (B : ℕ) (ha : ∀ z ∈ a, bitLen z ≤ B) (hb : ∀ z ∈ b, bitLen z ≤ B)
    (base : ℕ) :
    ∀ t : List ℤ × List ℤ, (∃ p, p ++ t.1 = a ∧ p ++ t.2 = b) →
      ∃ out, out = Val.int (if a = b then 1 else 0) ∧
        LoopLe prog base Idx.eqIntsStep (encEqState t) out
          ((t.1.length + 1) * (60 + 2 * B + 1)) (base + S_eqInts a b) := by
  refine LoopLe.of_measure h encEqState _ _ (fun t => t.1.length) (60 + 2 * B) ?_
  rintro ⟨A, B'⟩ ⟨p, hpa, hpb⟩
  simp only at hpa hpb
  have hAs : valSize (encInts A) ≤ valSize (encInts a) :=
    valSize_encInts_le_of_suffix (hpa ▸ List.suffix_append p A)
  have hBs : valSize (encInts B') ≤ valSize (encInts b) :=
    valSize_encInts_le_of_suffix (hpb ▸ List.suffix_append p B')
  have hab : (a = b) ↔ (A = B') := by
    rw [← hpa, ← hpb]
    exact List.append_right_inj p
  cases A with
  | nil =>
    cases B' with
    | nil =>
      left
      refine ⟨Val.int 1, ?_, ?_⟩
      · refine (eqIntsStep_nil_nil prog _).mono (by omega) ?_
        simp only [encEqState, encInts, S_eqInts, valSize_list, listSize_cons, listSize_nil,
          List.map_nil] at hAs hBs ⊢
        omega
      · simp [hab.mpr rfl]
    | cons y B' =>
      left
      refine ⟨Val.int 0, ?_, ?_⟩
      · refine (eqIntsStep_nil_cons prog _ (Val.int y) (B'.map Val.int)).mono (by omega) ?_
        simp only [encEqState, encInts, S_eqInts, valSize_list, listSize_cons, listSize_nil,
          List.map_nil, List.map_cons] at hAs hBs ⊢
        omega
      · have : a ≠ b := fun e => List.cons_ne_nil y B' (hab.mp e).symm
        simp [this]
  | cons x A =>
    cases B' with
    | nil =>
      left
      refine ⟨Val.int 0, ?_, ?_⟩
      · refine (eqIntsStep_cons_nil prog _ (Val.int x) (A.map Val.int)).mono (by omega) ?_
        simp only [encEqState, encInts, S_eqInts, valSize_list, listSize_cons, listSize_nil,
          List.map_nil, List.map_cons] at hAs hBs ⊢
        omega
      · have : a ≠ b := fun e => List.cons_ne_nil x A (hab.mp e)
        simp [this]
    | cons y B' =>
      have hxB : bitLen x ≤ B := ha x (hpa ▸ List.mem_append_right p List.mem_cons_self)
      have hyB : bitLen y ≤ B := hb y (hpb ▸ List.mem_append_right p List.mem_cons_self)
      by_cases hxy : x = y
      · subst hxy
        right
        refine ⟨1, (A, B'), one_ne_zero, ?_, ⟨p ++ [x], by rw [← hpa]; simp,
          by rw [← hpb]; simp⟩, by simp⟩
        refine (eqIntsStep_eq prog _ x (A.map Val.int) (B'.map Val.int)).mono (by omega) ?_
        simp only [encEqState, encInts, S_eqInts, valSize_list, listSize_cons, listSize_nil,
          List.map_cons] at hAs hBs ⊢
        omega
      · left
        refine ⟨Val.int 0, ?_, ?_⟩
        · refine (eqIntsStep_ne prog _ x y hxy (A.map Val.int) (B'.map Val.int)).mono
            (by omega) ?_
          simp only [encEqState, encInts, S_eqInts, valSize_list, listSize_cons, listSize_nil,
            List.map_cons] at hAs hBs ⊢
          omega
        · have : a ≠ b := fun e => hxy (List.cons.inj (hab.mp e)).1
          simp [this]

/-- **Spec of `eqInts`** (entries of bit length `≤ B`). -/
theorem eqInts_spec {prog : List Expr} (h : prog[Idx.eqIntsStep]? = some body_eqIntsStep)
    (a b : List ℤ) (B : ℕ) (ha : ∀ z ∈ a, bitLen z ≤ B) (hb : ∀ z ∈ b, bitLen z ≤ B)
    (base : ℕ) :
    EvalsLe prog base [Val.list [encInts a, encInts b]] body_eqInts
      (Val.int (if a = b then 1 else 0)) (C_eqInts a B) (base + S_eqInts a b) := by
  obtain ⟨out, rfl, hloop⟩ := eqInts_loop h a b B ha hb base (a, b) ⟨[], by simp, by simp⟩
  have hinit : EvalsLe prog base [Val.list [encInts a, encInts b]] (Expr.var 0)
      (encEqState (a, b)) 1 (base + valSize (Val.list [encInts a, encInts b])) :=
    EvalsLe.var rfl
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_eqInts]
    nlinarith
  · simp only [S_eqInts, max_le_iff]
    omega

/-! ### `memInts` -/

/-- Loop body of `memInts`. Environment `[acc]` with `acc = [r, z]`. -/
def body_memIntsStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.lit 0))                                       -- [0, 0]
      (Expr.ite (Expr.bin BinOp.eq (Expr.un UnOp.head (Expr.var 0))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
        (ePair (Expr.lit 0) (Expr.lit 1))                                     -- [0, 1]
        (ePair (Expr.lit 1)                                                   -- [1, [tail r, z]]
          (ePair (Expr.un UnOp.tail (Expr.var 0))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `memInts : [l, z] ↦ (z ∈ l)`; the input is the initial accumulator. -/
def body_memInts : Expr := Expr.loop Idx.memIntsStep (Expr.var 0)

theorem memIntsStep_nil (prog : List Expr) (base : ℕ) (z : ℤ) :
    EvalsLe prog base [Val.list [Val.list [], Val.int z]] body_memIntsStep
      (Val.list [Val.int 0, Val.int 0]) 50
      (base + 4 * valSize (Val.list [Val.list [], Val.int z]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_memIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem memIntsStep_eq (prog : List Expr) (base : ℕ) (z : ℤ) (r : List Val) :
    EvalsLe prog base [Val.list [Val.list (Val.int z :: r), Val.int z]] body_memIntsStep
      (Val.list [Val.int 0, Val.int 1]) (50 + 2 * bitLen z)
      (base + 4 * valSize (Val.list [Val.list (Val.int z :: r), Val.int z]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_memIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem memIntsStep_ne (prog : List Expr) (base : ℕ) (x z : ℤ) (hxz : x ≠ z) (r : List Val) :
    EvalsLe prog base [Val.list [Val.list (Val.int x :: r), Val.int z]] body_memIntsStep
      (Val.list [Val.int 1, Val.list [Val.list r, Val.int z]]) (50 + bitLen x + bitLen z)
      (base + 4 * valSize (Val.list [Val.list (Val.int x :: r), Val.int z]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_memIntsStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    hxz, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

/-- Encoding of the `memInts` loop state. -/
def encMemState (z : ℤ) (r : List ℤ) : Val := Val.list [encInts r, Val.int z]

/-- Cost bound of `memInts` (entries and `z` of bit length `≤ B`). -/
def C_memInts (l : List ℤ) (B : ℕ) : ℕ := (l.length + 1) * (51 + 2 * B) + 2

/-- Space bound of `memInts` (on top of the base). -/
def S_memInts (l : List ℤ) (z : ℤ) : ℕ := 5 * valSize (Val.list [encInts l, Val.int z]) + 30

theorem memInts_loop {prog : List Expr} (h : prog[Idx.memIntsStep]? = some body_memIntsStep)
    (l : List ℤ) (z : ℤ) (B : ℕ) (hl : ∀ x ∈ l, bitLen x ≤ B) (hz : bitLen z ≤ B) (base : ℕ) :
    ∀ r : List ℤ, (∃ p, p ++ r = l ∧ z ∉ p) →
      ∃ out, out = Val.int (if z ∈ l then 1 else 0) ∧
        LoopLe prog base Idx.memIntsStep (encMemState z r) out
          ((r.length + 1) * (50 + 2 * B + 1)) (base + S_memInts l z) := by
  refine LoopLe.of_measure h (encMemState z) _ _ (fun r => r.length) (50 + 2 * B) ?_
  rintro r ⟨p, hp, hzp⟩
  have hrs : valSize (encInts r) ≤ valSize (encInts l) :=
    valSize_encInts_le_of_suffix (hp ▸ List.suffix_append p r)
  cases r with
  | nil =>
    left
    refine ⟨Val.int 0, ?_, ?_⟩
    · refine (memIntsStep_nil prog _ z).mono (by omega) ?_
      simp only [encMemState, encInts, S_memInts, valSize_int, valSize_list, listSize_cons,
        listSize_nil, List.map_nil] at hrs ⊢
      omega
    · rw [List.append_nil] at hp
      subst hp
      simp [hzp]
  | cons x r =>
    have hxB : bitLen x ≤ B := hl x (hp ▸ List.mem_append_right p List.mem_cons_self)
    by_cases hxz : x = z
    · subst hxz
      left
      refine ⟨Val.int 1, ?_, ?_⟩
      · refine (memIntsStep_eq prog _ x (r.map Val.int)).mono (by omega) ?_
        simp only [encMemState, encInts, S_memInts, valSize_int, valSize_list, listSize_cons,
          listSize_nil, List.map_cons] at hrs ⊢
        omega
      · have : x ∈ l := hp ▸ List.mem_append_right p List.mem_cons_self
        simp [this]
    · right
      refine ⟨1, r, one_ne_zero, ?_, ⟨p ++ [x], by rw [← hp]; simp, ?_⟩, by simp⟩
      · refine (memIntsStep_ne prog _ x z hxz (r.map Val.int)).mono (by omega) ?_
        simp only [encMemState, encInts, S_memInts, valSize_int, valSize_list, listSize_cons,
          listSize_nil, List.map_cons] at hrs ⊢
        omega
      · simp only [List.mem_append, List.mem_singleton, not_or]
        exact ⟨hzp, fun e => hxz e.symm⟩

/-- **Spec of `memInts`** (entries and `z` of bit length `≤ B`). -/
theorem memInts_spec {prog : List Expr} (h : prog[Idx.memIntsStep]? = some body_memIntsStep)
    (l : List ℤ) (z : ℤ) (B : ℕ) (hl : ∀ x ∈ l, bitLen x ≤ B) (hz : bitLen z ≤ B) (base : ℕ) :
    EvalsLe prog base [Val.list [encInts l, Val.int z]] body_memInts
      (Val.int (if z ∈ l then 1 else 0)) (C_memInts l B) (base + S_memInts l z) := by
  obtain ⟨out, rfl, hloop⟩ := memInts_loop h l z B hl hz base l ⟨[], by simp, by simp⟩
  have hinit : EvalsLe prog base [Val.list [encInts l, Val.int z]] (Expr.var 0)
      (encMemState z l) 1 (base + valSize (Val.list [encInts l, Val.int z])) := EvalsLe.var rfl
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_memInts]
    nlinarith
  · simp only [S_memInts, max_le_iff]
    omega

end F2e2e.Cost