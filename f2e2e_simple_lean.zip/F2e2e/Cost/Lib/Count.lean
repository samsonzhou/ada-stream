import F2e2e.Cost.Lib.Util

/-!
# List library: `countNZ` (number of nonzero entries) (T1) — port of cut2 `Cost/Lib/Count.lean`

Reference function: `l.countP (fun z => z ≠ 0)` for `l : List ℤ`. Input `encInts l`, output
`Val.int (l.countP (fun z => z ≠ 0))`.

* `body_countNZStep` (index `Idx.countNZStep`): accumulator `[c, r]`; `[c, []] ↦ [0, c]`,
  `[c, x :: r] ↦ [1, [c + (x ≠ 0 ? 1 : 0), r]]`.
* `body_countNZ` (index `Idx.countNZ`): `loop Idx.countNZStep [0, l]`.

Spec (`countNZ_spec`), entries of bit length `≤ B`:
`C_countNZ l B = (l.length + 1) * (44 + B + Nat.size l.length) + 8`,
`S_countNZ l = 5 * valSize (encInts l) + 7 * Nat.size l.length + 45`.
-/

namespace F2e2e.Cost
namespace Idx
/-- `countNZ : l ↦ #{i | l[i] ≠ 0}`. -/
abbrev countNZ : ℕ := 23
/-- Loop body of `countNZ`. -/
abbrev countNZStep : ℕ := 24
end Idx

/-- Loop body of `countNZ`. Environment `[acc]` with `acc = [c, r]`. -/
def body_countNZStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))          -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))                -- [0, c]
      (Expr.ite (Expr.bin BinOp.eq (Expr.un UnOp.head (Expr.var 0)) (Expr.lit 0))
        (ePair (Expr.lit 1)                                                 -- [1, [c, tail r]]
          (ePair (Expr.un UnOp.head (Expr.var 1)) (Expr.un UnOp.tail (Expr.var 0))))
        (ePair (Expr.lit 1)                                                 -- [1, [c + 1, tail r]]
          (ePair (Expr.bin BinOp.add (Expr.un UnOp.head (Expr.var 1)) (Expr.lit 1))
            (Expr.un UnOp.tail (Expr.var 0))))))

/-- `countNZ : l ↦ #{nonzero entries}`. -/
def body_countNZ : Expr := Expr.loop Idx.countNZStep (ePair (Expr.lit 0) (Expr.var 0))

/-! ### The loop body -/

theorem countNZStep_nil (prog : List Expr) (base : ℕ) (c : ℤ) :
    EvalsLe prog base [Val.list [Val.int c, Val.list []]] body_countNZStep
      (Val.list [Val.int 0, Val.int c]) 40
      (base + 4 * valSize (Val.list [Val.int c, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_countNZStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem countNZStep_zero (prog : List Expr) (base : ℕ) (c : ℤ) (R : List Val) :
    EvalsLe prog base [Val.list [Val.int c, Val.list (Val.int 0 :: R)]] body_countNZStep
      (Val.list [Val.int 1, Val.list [Val.int c, Val.list R]]) 40
      (base + 4 * valSize (Val.list [Val.int c, Val.list (Val.int 0 :: R)]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_countNZStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem countNZStep_ne (prog : List Expr) (base : ℕ) (c x : ℤ) (hx : x ≠ 0) (R : List Val) :
    EvalsLe prog base [Val.list [Val.int c, Val.list (Val.int x :: R)]] body_countNZStep
      (Val.list [Val.int 1, Val.list [Val.int (c + 1), Val.list R]]) (44 + bitLen x + bitLen c)
      (base + 4 * valSize (Val.list [Val.int c, Val.list (Val.int x :: R)]) +
        2 * bitLen (c + 1) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_countNZStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    hx, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

/-! ### The loop -/

/-- Encoding of the `countNZ` loop state `(c, r)`. -/
def encCntState (t : ℕ × List ℤ) : Val := Val.list [Val.int (t.1 : ℤ), encInts t.2]

/-- Cost bound of `countNZ` (entries of bit length `≤ B`). -/
def C_countNZ (l : List ℤ) (B : ℕ) : ℕ := (l.length + 1) * (45 + B + Nat.size l.length) + 8

/-- Space bound of `countNZ` (on top of the base). -/
def S_countNZ (l : List ℤ) : ℕ := 5 * valSize (encInts l) + 7 * Nat.size l.length + 45

theorem countNZ_loop {prog : List Expr} (h : prog[Idx.countNZStep]? = some body_countNZStep)
    (l : List ℤ) (B : ℕ) (hB : ∀ z ∈ l, bitLen z ≤ B) (base : ℕ) :
    ∀ t : ℕ × List ℤ, (∃ p, p ++ t.2 = l ∧ t.1 = p.countP (fun z => z ≠ 0)) →
      ∃ out, out = Val.int (l.countP (fun z => z ≠ 0) : ℤ) ∧
        LoopLe prog base Idx.countNZStep (encCntState t) out
          ((t.2.length + 1) * (44 + B + Nat.size l.length + 1)) (base + S_countNZ l) := by
  refine LoopLe.of_measure h encCntState _ _ (fun t => t.2.length)
    (44 + B + Nat.size l.length) ?_
  rintro ⟨c, r⟩ ⟨p, hp, hc⟩
  simp only at hp hc
  have hcl : c ≤ l.length := by
    rw [hc, ← hp, List.length_append]
    have := List.countP_le_length (p := fun z => decide (z ≠ 0)) (l := p)
    omega
  have hbc : bitLen (c : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le hcl
  have hR : valSize (encInts r) ≤ valSize (encInts l) :=
    valSize_encInts_le_of_suffix (hp ▸ List.suffix_append p r)
  cases r with
  | nil =>
    left
    refine ⟨Val.int c, ?_, ?_⟩
    · refine (countNZStep_nil prog _ c).mono (by omega) ?_
      simp only [encCntState, encInts, S_countNZ, valSize_int, valSize_list, listSize_cons,
        listSize_nil, List.map_nil] at hR ⊢
      omega
    · rw [hc, ← hp, List.append_nil]
  | cons x r =>
    right
    have hxB : bitLen x ≤ B := hB x (hp ▸ List.mem_append_right p List.mem_cons_self)
    have hp' : (p ++ [x]) ++ r = l := by rw [← hp]; simp
    by_cases hx : x = 0
    · subst hx
      refine ⟨1, (c, r), one_ne_zero, ?_, ⟨p ++ [0], hp', by simp [hc]⟩, by simp⟩
      refine (countNZStep_zero prog _ c (r.map Val.int)).mono (by omega) ?_
      simp only [encCntState, encInts, S_countNZ, valSize_int, valSize_list, listSize_cons,
        listSize_nil, List.map_cons] at hR ⊢
      omega
    · have hc1 : c + 1 ≤ l.length := by
        have h1 := List.countP_le_length (p := fun z => decide (z ≠ 0)) (l := p)
        have h2 : l.length = p.length + 1 + r.length := by
          rw [← hp]
          simp only [List.length_append, List.length_cons]
          omega
        omega
      have hbc1 : bitLen ((c : ℤ) + 1) ≤ Nat.size l.length := by
        have := bitLen_le_size_of_le hc1
        push_cast at this
        exact this
      have henc : encCntState (c + 1, r) = Val.list [Val.int ((c : ℤ) + 1), encInts r] := by
        simp [encCntState]
      refine ⟨1, (c + 1, r), one_ne_zero, ?_, ⟨p ++ [x], hp', by simp [hc, hx]⟩, by simp⟩
      rw [henc]
      refine (countNZStep_ne prog _ c x hx (r.map Val.int)).mono (by omega) ?_
      simp only [encCntState, encInts, S_countNZ, valSize_int, valSize_list, listSize_cons,
        listSize_nil, List.map_cons] at hR ⊢
      omega

/-! ### The spec -/

/-- **Spec of `countNZ`** (entries of bit length `≤ B`). -/
theorem countNZ_spec {prog : List Expr} (h : prog[Idx.countNZStep]? = some body_countNZStep)
    (l : List ℤ) (B : ℕ) (hB : ∀ z ∈ l, bitLen z ≤ B) (base : ℕ) :
    EvalsLe prog base [encInts l] body_countNZ (Val.int (l.countP (fun z => z ≠ 0) : ℤ))
      (C_countNZ l B) (base + S_countNZ l) := by
  obtain ⟨out, rfl, hloop⟩ := countNZ_loop h l B hB base (0, l) ⟨[], by simp, by simp⟩
  have hinit : EvalsLe prog base [encInts l] (ePair (Expr.lit 0) (Expr.var 0))
      (encCntState (0, l)) 7 (base + 2 * valSize (encInts l) + 7) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [encInts l])
      (EvalsLe.lit 0) (EvalsLe.var (i := 0) (v := encInts l) rfl)
    refine this.mono (by simp) ?_
    simp only [valSize_int, bitLen_zero, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_countNZ]
    nlinarith
  · simp only [S_countNZ, max_le_iff]
    omega

end F2e2e.Cost