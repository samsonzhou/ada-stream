import F2e2e.Cost.Lib.Util

/-!
# List library: `sum` of an integer list (T1) — port of cut2 `Cost/Lib/Sum.lean`

Reference function: `List.sum : List ℤ → ℤ`. Input `encInts l`, output `Val.int l.sum`.

* `body_sumStep` (index `Idx.sumStep`): accumulator `[s, r]` (partial sum, remaining list);
  `[s, []] ↦ [0, s]`, `[s, x :: r] ↦ [1, [s + x, r]]`.
* `body_sum` (index `Idx.sum`): `loop Idx.sumStep [0, l]`.

Spec (`sum_spec`), for entries of absolute value `< 2 ^ B`:
`C_sum l B = (l.length + 1) * (34 + 2 * B + Nat.size l.length) + 8`,
`S_sum l B = 5 * valSize (encInts l) + 7 * (B + Nat.size l.length) + 45`.
Partial sums have bit length `≤ B + Nat.size l.length` (`bitLen_sum_le`).
-/

namespace F2e2e.Cost
/-- Loop body of `sum`. Environment `[acc]` with `acc = [s, r]`. -/
def body_sumStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))       -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))            -- [0, s]
      (ePair (Expr.lit 1)                                              -- [1, [s + head r, tail r]]
        (ePair (Expr.bin BinOp.add (Expr.un UnOp.head (Expr.var 1))
            (Expr.un UnOp.head (Expr.var 0)))
          (Expr.un UnOp.tail (Expr.var 0)))))

/-- `sum : l ↦ l.sum`. Environment `[encInts l]`. -/
def body_sum : Expr := Expr.loop Idx.sumStep (ePair (Expr.lit 0) (Expr.var 0))

/-- Cost bound of `sum` (entries of absolute value `< 2 ^ B`). -/
def C_sum (l : List ℤ) (B : ℕ) : ℕ := (l.length + 1) * (34 + 2 * B + Nat.size l.length) + 8

/-- Space bound of `sum` (on top of the base). -/
def S_sum (l : List ℤ) (B : ℕ) : ℕ := 5 * valSize (encInts l) + 7 * (B + Nat.size l.length) + 45

/-! ### The loop body -/

theorem sumStep_nil (prog : List Expr) (base : ℕ) (s : ℤ) :
    EvalsLe prog base [Val.list [Val.int s, Val.list []]] body_sumStep
      (Val.list [Val.int 0, Val.int s]) 19
      (base + 4 * valSize (Val.list [Val.int s, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_sumStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem sumStep_cons (prog : List Expr) (base : ℕ) (s x : ℤ) (R : List Val) :
    EvalsLe prog base [Val.list [Val.int s, Val.list (Val.int x :: R)]] body_sumStep
      (Val.list [Val.int 1, Val.list [Val.int (s + x), Val.list R]]) (33 + bitLen s + bitLen x)
      (base + 4 * valSize (Val.list [Val.int s, Val.list (Val.int x :: R)]) +
        2 * bitLen (s + x) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_sumStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false,
    if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop -/

/-- Encoding of the `sum` loop state `(s, r)`. -/
def encSumState (t : ℤ × List ℤ) : Val := Val.list [Val.int t.1, encInts t.2]

theorem valSize_encSumState (t : ℤ × List ℤ) :
    valSize (encSumState t) = bitLen t.1 + valSize (encInts t.2) + 4 := by
  simp only [encSumState, valSize_list, listSize_cons, listSize_nil, valSize_int]
  omega

theorem sum_loop {prog : List Expr} (h : prog[Idx.sumStep]? = some body_sumStep)
    (l : List ℤ) (B : ℕ) (hB : ∀ z ∈ l, |z| < 2 ^ B) (base : ℕ) :
    ∀ t : ℤ × List ℤ, (∃ p, p ++ t.2 = l ∧ t.1 = p.sum) →
      ∃ out, out = Val.int l.sum ∧
        LoopLe prog base Idx.sumStep (encSumState t) out
          ((t.2.length + 1) * (33 + (B + Nat.size l.length) + B + 1)) (base + S_sum l B) := by
  refine LoopLe.of_measure h encSumState _ _ (fun t => t.2.length)
    (33 + (B + Nat.size l.length) + B) ?_
  rintro ⟨s, r⟩ ⟨p, hp, hs⟩
  simp only at hp hs
  subst hs
  have hpl : p.length ≤ l.length := by rw [← hp]; simp
  have hpB : ∀ z ∈ p, |z| < 2 ^ B := fun z hz => hB z (hp ▸ List.mem_append_left r hz)
  have hbs : bitLen p.sum ≤ B + Nat.size l.length := bitLen_sum_le p B _ hpl hpB
  have hR : valSize (encInts r) ≤ valSize (encInts l) :=
    valSize_encInts_le_of_suffix (hp ▸ List.suffix_append p r)
  cases r with
  | nil =>
    left
    refine ⟨Val.int p.sum, ?_, ?_⟩
    · refine (sumStep_nil prog _ p.sum).mono (by omega) ?_
      have e : valSize (Val.list [Val.int p.sum, Val.list []]) = bitLen p.sum + 5 := by
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega
      simp only [valSize_encSumState, S_sum, e]
      have : valSize (encInts []) = 1 := rfl
      omega
    · simp only [List.append_nil] at hp
      rw [hp]
  | cons x r =>
    right
    have hx : |x| < 2 ^ B := hB x (hp ▸ List.mem_append_right p List.mem_cons_self)
    have hbx : bitLen x ≤ B := bitLen_le_of_abs_lt hx
    have hp' : (p ++ [x]) ++ r = l := by rw [← hp]; simp
    have hbsx : bitLen (p.sum + x) ≤ B + Nat.size l.length := by
      have := bitLen_sum_le (p ++ [x]) B l.length (by rw [← hp']; simp)
        (fun z hz => hB z (hp' ▸ List.mem_append_left r hz))
      simpa using this
    refine ⟨1, (p.sum + x, r), one_ne_zero, ?_, ⟨p ++ [x], hp', by simp⟩, by simp⟩
    refine (sumStep_cons prog _ p.sum x (r.map Val.int)).mono (by omega) ?_
    have e := valSize_encInts_cons x r
    have e2 : valSize (Val.list [Val.int p.sum, Val.list (Val.int x :: r.map Val.int)]) =
        bitLen p.sum + valSize (encInts (x :: r)) + 4 := valSize_encSumState (p.sum, x :: r)
    simp only [valSize_encSumState, S_sum, e2]
    omega

/-! ### The spec -/

/-- **Spec of `sum`** (entries of absolute value `< 2 ^ B`). -/
theorem sum_spec {prog : List Expr} (h : prog[Idx.sumStep]? = some body_sumStep)
    (l : List ℤ) (B : ℕ) (hB : ∀ z ∈ l, |z| < 2 ^ B) (base : ℕ) :
    EvalsLe prog base [encInts l] body_sum (Val.int l.sum) (C_sum l B) (base + S_sum l B) := by
  obtain ⟨out, rfl, hloop⟩ := sum_loop h l B hB base (0, l) ⟨[], by simp, by simp⟩
  have hinit : EvalsLe prog base [encInts l] (ePair (Expr.lit 0) (Expr.var 0))
      (encSumState (0, l)) 7 (base + 2 * valSize (encInts l) + 7) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [encInts l])
      (EvalsLe.lit 0) (EvalsLe.var (i := 0) (v := encInts l) rfl)
    refine this.mono (by simp) ?_
    simp only [valSize_int, bitLen_zero, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_sum]
    nlinarith
  · simp only [S_sum, max_le_iff]
    omega

/-- **Spec of `call Idx.sum`** (for callers). -/
theorem sum_call {prog : List Expr} (h1 : prog[Idx.sum]? = some body_sum)
    (h2 : prog[Idx.sumStep]? = some body_sumStep) {base : ℕ} {env : List Val} {a : Expr}
    {l : List ℤ} (B : ℕ) (hB : ∀ z ∈ l, |z| < 2 ^ B) {Ca Sa : ℕ}
    (ha : EvalsLe prog base env a (encInts l) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.sum a) (Val.int l.sum) (1 + Ca + C_sum l B)
      (max Sa (base + valSize (encInts l) + S_sum l B)) :=
  EvalsLe.call ha h1 (sum_spec h2 l B hB _)

end F2e2e.Cost