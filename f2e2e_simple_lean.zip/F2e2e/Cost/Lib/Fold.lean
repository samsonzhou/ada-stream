import F2e2e.Cost.Lib.Util

/-!
# Generic `foldl` over a list (T1) — port of cut2 `Cost/Lib/Fold.lean`

`body_foldStep iG` is the loop body of a left fold whose step function is the program function
`iG` (environment `[[c, x]] ↦ g c x`); every fold gets its own step index `iStep` (allocated by
the user in its own range) with `prog[iStep]? = some (body_foldStep iG)`.

* `body_foldStep iG`: accumulator `[c, r]`: `[c, []] ↦ [0, c]`, `[c, x :: r] ↦ [1, [g c x, r]]`.
* `body_fold iStep`: input `[init, l]` (it is the initial accumulator) ↦ `l.foldl g init`.

Spec (`fold_spec`), typed with an invariant `P` on accumulators (`P init`, preserved by `g` on
the elements of `l`) and uniform bounds: every step costs `≤ Cg`, has extra space `≤ Sg`, and
accumulators satisfying `P` have size `≤ Vacc`.
-/

namespace F2e2e.Cost
/-- Loop body of a `foldl` with step function `iG`. Environment `[st]`, `st = [c, r]`. -/
def body_foldStep (iG : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))            -- r ; env [r, st]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))                  -- [0, c]
      (ePair (Expr.lit 1)                                                    -- [1, [g c x, tail r]]
        (ePair
          (Expr.call iG (ePair (Expr.un UnOp.head (Expr.var 1))
            (Expr.un UnOp.head (Expr.var 0))))
          (Expr.un UnOp.tail (Expr.var 0)))))

/-- `foldl` whose loop body `body_foldStep iG` is stored at `iStep`: `[init, l] ↦ l.foldl g init`. -/
def body_fold (iStep : ℕ) : Expr := Expr.loop iStep (Expr.var 0)

/-! ### The loop body -/

theorem foldStep_nil (prog : List Expr) (iG : ℕ) (base : ℕ) (cv : Val) :
    EvalsLe prog base [Val.list [cv, Val.list []]] (body_foldStep iG)
      (Val.list [Val.int 0, cv]) 19 (base + 4 * valSize (Val.list [cv, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_foldStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem foldStep_cons {prog : List Expr} {iG : ℕ} {bodyG : Expr} (hG : prog[iG]? = some bodyG)
    (base : ℕ) (cv x : Val) (R : List Val) {y : Val} {Cx Sx : ℕ}
    (hx : ∀ b, EvalsLe prog b [Val.list [cv, x]] bodyG y Cx (b + Sx)) :
    EvalsLe prog base [Val.list [cv, Val.list (x :: R)]] (body_foldStep iG)
      (Val.list [Val.int 1, Val.list [y, Val.list R]]) (Cx + 40)
      (base + 6 * valSize (Val.list [cv, Val.list (x :: R)]) + 2 * valSize y + Sx + 30) := by
  have h := EvalsLe.letE (prog := prog) (base := base)
    (env := [Val.list [cv, Val.list (x :: R)]])
    (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))
    (EvalsLe.ite_false (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))
      (EvalsLe.isNil_cons (EvalsLe.var (i := 0) rfl)) rfl
      (EvalsLe.pair (EvalsLe.lit 1)
        (EvalsLe.pair
          (EvalsLe.call (EvalsLe.pair (EvalsLe.head (EvalsLe.var (i := 1) rfl))
            (EvalsLe.head (EvalsLe.var (i := 0) rfl))) hG (hx _))
          (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))))
  refine h.mono ?_ ?_
  · simp only [bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

/-! ### The loop -/

/-- Space bound of the `foldl` loop (on top of the base). -/
def S_fold {α : Type*} (encA : α → Val) (l : List α) (Sg Vacc : ℕ) : ℕ :=
  7 * (Vacc + valSize (encL encA l) + 3) + 2 * Vacc + Sg + 30

/-- Cost bound of `foldl`. -/
def C_fold (len Cg : ℕ) : ℕ := (len + 1) * (Cg + 41) + 2

theorem fold_loop {α γ : Type*} {prog : List Expr} {iG iStep : ℕ} {bodyG : Expr}
    (hstep : prog[iStep]? = some (body_foldStep iG)) (hG : prog[iG]? = some bodyG)
    (encA : α → Val) (encC : γ → Val) (g : γ → α → γ) (P : γ → Prop) (l : List α) (init : γ)
    (hPg : ∀ c a, P c → a ∈ l → P (g c a)) (Cg Sg Vacc : ℕ)
    (hspec : ∀ c a, P c → a ∈ l → ∀ b,
      EvalsLe prog b [Val.list [encC c, encA a]] bodyG (encC (g c a)) Cg (b + Sg))
    (hV : ∀ c, P c → valSize (encC c) ≤ Vacc) (base : ℕ) :
    ∀ t : γ × List α, ((∃ p, p ++ t.2 = l ∧ t.1 = p.foldl g init) ∧ P t.1) →
      ∃ out, out = encC (l.foldl g init) ∧
        LoopLe prog base iStep (Val.list [encC t.1, encL encA t.2]) out
          ((t.2.length + 1) * (Cg + 40 + 1)) (base + S_fold encA l Sg Vacc) := by
  refine LoopLe.of_measure hstep (fun t : γ × List α => Val.list [encC t.1, encL encA t.2])
    _ _ (fun t => t.2.length) (Cg + 40) ?_
  rintro ⟨c, r⟩ ⟨⟨p, hp, hc⟩, hPc⟩
  simp only at hp hc hPc
  have hVc := hV c hPc
  have hrs : listSize (r.map encA) ≤ listSize (l.map encA) :=
    listSize_le_of_suffix ((hp ▸ List.suffix_append p r).map encA)
  cases r with
  | nil =>
    left
    refine ⟨encC c, ?_, ?_⟩
    · refine (foldStep_nil prog iG _ (encC c)).mono (by omega) ?_
      simp only [encL, S_fold, valSize_list, listSize_cons, listSize_nil, List.map_nil] at hrs ⊢
      omega
    · rw [hc, ← hp, List.append_nil]
  | cons a r =>
    right
    have ha : a ∈ l := hp ▸ List.mem_append_right p List.mem_cons_self
    have hVg := hV (g c a) (hPg c a hPc ha)
    refine ⟨1, (g c a, r), one_ne_zero, ?_, ⟨⟨p ++ [a], by rw [← hp]; simp, by simp [hc]⟩,
      hPg c a hPc ha⟩, by simp⟩
    refine (foldStep_cons hG _ (encC c) (encA a) (r.map encA)
      (hspec c a hPc ha)).mono (by omega) ?_
    simp only [encL, S_fold, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hrs ⊢
    omega

/-! ### The spec -/

/-- **Spec of `foldl`.** -/
theorem fold_spec {α γ : Type*} {prog : List Expr} {iG iStep : ℕ} {bodyG : Expr}
    (hstep : prog[iStep]? = some (body_foldStep iG)) (hG : prog[iG]? = some bodyG)
    (encA : α → Val) (encC : γ → Val) (g : γ → α → γ) (P : γ → Prop) (l : List α) (init : γ)
    (hP0 : P init) (hPg : ∀ c a, P c → a ∈ l → P (g c a)) (Cg Sg Vacc : ℕ)
    (hspec : ∀ c a, P c → a ∈ l → ∀ b,
      EvalsLe prog b [Val.list [encC c, encA a]] bodyG (encC (g c a)) Cg (b + Sg))
    (hV : ∀ c, P c → valSize (encC c) ≤ Vacc) (base : ℕ) :
    EvalsLe prog base [Val.list [encC init, encL encA l]] (body_fold iStep)
      (encC (l.foldl g init)) (C_fold l.length Cg) (base + S_fold encA l Sg Vacc) := by
  obtain ⟨out, rfl, hloop⟩ := fold_loop hstep hG encA encC g P l init hPg Cg Sg Vacc hspec hV
    base (init, l) ⟨⟨[], by simp, by simp⟩, hP0⟩
  have hinit : EvalsLe prog base [Val.list [encC init, encL encA l]] (Expr.var 0)
      (Val.list [encC init, encL encA l]) 1
      (base + valSize (Val.list [encC init, encL encA l])) := EvalsLe.var rfl
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_fold]
    nlinarith
  · have := hV init hP0
    simp only [S_fold, max_le_iff, valSize_list, listSize_cons, listSize_nil, encL] at this ⊢
    omega

end F2e2e.Cost