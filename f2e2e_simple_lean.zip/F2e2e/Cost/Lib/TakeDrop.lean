import F2e2e.Cost.Lib.Set

/-!
# List library: `take`, `drop` (T1) — port of cut2 `Cost/Lib/TakeDrop.lean`

Both reuse the splitting loop of `set` (`body_setStep`, index `Idx.setStep`), which turns
`[n, l, []]` into `[P, r]` with `P.reverse ++ r = l` and `|P| = min n |l|`.

* `body_take` (index `Idx.take`): `[l, n] ↦ l.take n` (reverses `P` with the `revAppend` loop);
  needs `Idx.setStep` and `Idx.revAppendStep`.
* `body_drop` (index `Idx.drop`): `[l, n] ↦ l.drop n`; needs `Idx.setStep`.

Corollaries for integer lists: `take_spec_ints`, `drop_spec_ints` (`encInts`).
-/

namespace F2e2e.Cost
namespace Idx
/-- `take : [l, n] ↦ l.take n`. -/
abbrev take : ℕ := 19
/-- `drop : [l, n] ↦ l.drop n`. -/
abbrev drop : ℕ := 20
end Idx

/-- Initial accumulator `[n, l, []]` of the splitting loop, from an input `[l, n, …]`. -/
def splitInit : Expr :=
  Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))
    (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
      (Expr.bin BinOp.cons Expr.nil Expr.nil))

/-- `take : [l, n] ↦ l.take n`. -/
def body_take : Expr :=
  Expr.letE (Expr.loop Idx.setStep splitInit)
    (Expr.loop Idx.revAppendStep (ePair (Expr.un UnOp.head (Expr.var 0)) Expr.nil))

/-- `drop : [l, n] ↦ l.drop n`. -/
def body_drop : Expr :=
  Expr.letE (Expr.loop Idx.setStep splitInit) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))

theorem splitInit_spec (prog : List Expr) (base : ℕ) (l : List Val) (n : ℕ) (rest : List Val) :
    EvalsLe prog base [Val.list (Val.list l :: Val.int (n : ℤ) :: rest)] splitInit
      (encSetState (n, l, [])) 16
      (base + 3 * valSize (Val.list (Val.list l :: Val.int (n : ℤ) :: rest)) + 20) := by
  refine (EvalsLe.cons (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))
    (EvalsLe.cons (EvalsLe.head (EvalsLe.var (i := 0) rfl))
      (EvalsLe.cons EvalsLe.nil EvalsLe.nil))).mono (le_refl _) ?_
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
  omega

/-- The result of the splitting loop determines `take` and `drop`. -/
theorem take_drop_of_split {l P r : List Val} {n : ℕ} (hPr : P.reverse ++ r = l)
    (hPn : P.length ≤ n) (hcase : r = [] ∨ P.length = n) :
    l.take n = P.reverse ∧ l.drop n = r := by
  rcases hcase with rfl | hP
  · rw [List.append_nil] at hPr
    subst hPr
    exact ⟨List.take_of_length_le (by simp; omega), List.drop_of_length_le (by simp; omega)⟩
  · subst hPr
    have : P.reverse.length = n := by simp [hP]
    constructor
    · rw [List.take_append_of_le_length (by omega), List.take_of_length_le (by omega)]
    · rw [List.drop_append_of_le_length (by omega), List.drop_of_length_le (by omega),
        List.nil_append]

/-- Cost bound of `take`. -/
def C_take (l : List Val) (n : ℕ) : ℕ :=
  (l.length + 1) * (55 + 2 * Nat.size n) + (l.length + 1) * 34 + 40

/-- Space bound of `take` (on top of the base). -/
def S_take (l : List Val) (n : ℕ) : ℕ := 10 * valSize (Val.list l) + 7 * Nat.size n + 90

/-- **Spec of `take`.** -/
theorem take_spec {prog : List Expr} (h1 : prog[Idx.setStep]? = some body_setStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep) (l : List Val) (n : ℕ)
    (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ)]] body_take (Val.list (l.take n))
      (C_take l n) (base + S_take l n) := by
  have hn : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
  obtain ⟨out, ⟨P, r, rfl, hPr, hPn, hcase⟩, hloop⟩ :=
    set_loop h1 l n base (n, l, []) ⟨by simp, by simp⟩
  have hA := EvalsLe.loop (splitInit_spec prog base l n []) hloop
  have hinit2 : EvalsLe prog (base + valSize (Val.list [Val.list P, Val.list r]))
      [Val.list [Val.list P, Val.list r], Val.list [Val.list l, Val.int (n : ℤ)]]
      (ePair (Expr.un UnOp.head (Expr.var 0)) Expr.nil) (encRA (P, [])) 9
      (base + valSize (Val.list [Val.list P, Val.list r]) +
        3 * valSize (Val.list [Val.list P, Val.list r]) + 7) := by
    refine (EvalsLe.pair (EvalsLe.head (EvalsLe.var (i := 0) rfl)) EvalsLe.nil).mono
      (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have hB := EvalsLe.loop hinit2
    (revAppend_loop h2 (base + valSize (Val.list [Val.list P, Val.list r])) (P, []))
  have hAll := EvalsLe.letE hA hB
  have e : Val.list (P.reverseAux []) = Val.list (l.take n) := by
    rw [List.reverseAux_eq, List.append_nil, (take_drop_of_split hPr hPn hcase).1]
  rw [e] at hAll
  have hsz : listSize P + listSize r = listSize l := by
    rw [← hPr, listSize_append, listSize_reverse]
  have hPl : P.length ≤ l.length := by rw [← hPr]; simp
  have hPl' := Nat.mul_le_mul_right 34 (Nat.succ_le_succ hPl)
  have hc : (l.length + 1) * (54 + 2 * Nat.size n + 1) =
      (l.length + 1) * (55 + 2 * Nat.size n) := by ring
  refine hAll.mono ?_ ?_
  · simp only [C_take, hc, Nat.succ_eq_add_one] at hPl' ⊢
    omega
  · simp only [S_take, S_setLoop, max_le_iff, valSize_encRA, valSize_int, valSize_list,
      listSize_cons, listSize_nil, hn] at hsz ⊢
    omega

/-- Cost bound of `drop`. -/
def C_drop (l : List Val) (n : ℕ) : ℕ := (l.length + 1) * (55 + 2 * Nat.size n) + 30

/-- Space bound of `drop` (on top of the base). -/
def S_drop (l : List Val) (n : ℕ) : ℕ := 7 * valSize (Val.list l) + 7 * Nat.size n + 80

/-- **Spec of `drop`.** -/
theorem drop_spec {prog : List Expr} (h1 : prog[Idx.setStep]? = some body_setStep)
    (l : List Val) (n : ℕ) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ)]] body_drop (Val.list (l.drop n))
      (C_drop l n) (base + S_drop l n) := by
  have hn : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
  obtain ⟨out, ⟨P, r, rfl, hPr, hPn, hcase⟩, hloop⟩ :=
    set_loop h1 l n base (n, l, []) ⟨by simp, by simp⟩
  have hA := EvalsLe.loop (splitInit_spec prog base l n []) hloop
  have hB : EvalsLe prog (base + valSize (Val.list [Val.list P, Val.list r]))
      [Val.list [Val.list P, Val.list r], Val.list [Val.list l, Val.int (n : ℤ)]]
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))) (Val.list r) 5
      (base + valSize (Val.list [Val.list P, Val.list r]) +
        3 * valSize (Val.list [Val.list P, Val.list r])) := by
    refine (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl))).mono (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have hAll := EvalsLe.letE hA hB
  have hsz : listSize P + listSize r = listSize l := by
    rw [← hPr, listSize_append, listSize_reverse]
  rw [← (take_drop_of_split hPr hPn hcase).2] at hAll hsz
  have hc : (l.length + 1) * (54 + 2 * Nat.size n + 1) =
      (l.length + 1) * (55 + 2 * Nat.size n) := by ring
  refine hAll.mono ?_ ?_
  · simp only [C_drop, hc]
    omega
  · simp only [S_drop, S_setLoop, max_le_iff, valSize_int, valSize_list, listSize_cons,
      listSize_nil, hn] at hsz ⊢
    omega

/-! ### Integer-list corollaries -/

theorem take_spec_ints {prog : List Expr} (h1 : prog[Idx.setStep]? = some body_setStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep) (l : List ℤ) (n : ℕ)
    (base : ℕ) :
    EvalsLe prog base [Val.list [encInts l, Val.int (n : ℤ)]] body_take (encInts (l.take n))
      (C_take (l.map Val.int) n) (base + S_take (l.map Val.int) n) := by
  have := take_spec h1 h2 (l.map Val.int) n base
  rw [← List.map_take] at this
  exact this

theorem drop_spec_ints {prog : List Expr} (h1 : prog[Idx.setStep]? = some body_setStep)
    (l : List ℤ) (n : ℕ) (base : ℕ) :
    EvalsLe prog base [Val.list [encInts l, Val.int (n : ℤ)]] body_drop (encInts (l.drop n))
      (C_drop (l.map Val.int) n) (base + S_drop (l.map Val.int) n) := by
  have := drop_spec h1 (l.map Val.int) n base
  rw [← List.map_drop] at this
  exact this

end F2e2e.Cost