import F2e2e.Cost.Enc
import F2e2e.Cost.Index
import F2e2e.Cost.Calculus

/-!
# Small DSL helpers shared by the library (port of cut2's `Cost/Lib/Util.lean`)

* `ePair a b`: the expression building the two-element list `[a, b]`, with its rules
  `EvalsLe.pair` (cost `Ca + Cb + 5`) and `EvalsLeT.pair` (consuming the bits of `a` then `b`).
* `level` / `levelT`: one `letE` level of a long chain, with a *global* peak bound `base + S` and a
  size budget for the bindings made so far (from cut2's `AssemblyInit.lean`).
* Size helpers: `listSize_le_of_suffix`, `valSize_encInts_le_of_suffix`, `valSize_encInts_cons`,
  `abs_sum_le_length_mul`, `bitLen_sum_le`.
-/

namespace F2e2e.Cost

/-- The expression building the two-element list `[a, b]`. -/
def ePair (a b : Expr) : Expr := Expr.bin BinOp.cons a (Expr.bin BinOp.cons b Expr.nil)

theorem EvalsLe.pair {prog : List Expr} {base : ℕ} {env : List Val} {a b : Expr} {x y : Val}
    {Ca Sa Cb Sb : ℕ} (ha : EvalsLe prog base env a x Ca Sa)
    (hb : EvalsLe prog (base + valSize x) env b y Cb Sb) :
    EvalsLe prog base env (ePair a b) (Val.list [x, y]) (Ca + Cb + 5)
      (max (max Sa Sb) (base + 2 * valSize x + 2 * valSize y + 5)) := by
  have h := EvalsLe.cons ha (EvalsLe.cons hb EvalsLe.nil)
  refine h.mono (by omega) ?_
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem EvalsLeT.pair {prog : List Expr} {base : ℕ} {env : List Val} {a b : Expr}
    {ba bb : List Bool} {x y : Val} {Ca Sa Cb Sb : ℕ} (ha : EvalsLeT prog base env ba a x Ca Sa)
    (hb : EvalsLeT prog (base + valSize x) env bb b y Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (ePair a b) (Val.list [x, y]) (Ca + Cb + 5)
      (max (max Sa Sb) (base + 2 * valSize x + 2 * valSize y + 5)) := by
  have h := EvalsLeT.cons ha (EvalsLeT.cons hb EvalsLeT.nil)
  rw [List.append_nil] at h
  refine h.mono (by omega) ?_
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-! ### Long `letE` chains -/

/-- One `letE` level of a chain: global peak bound `base + S`, size budget `X` for the bindings
made so far (next budget `X' ≥ X + V`), the new binding of size `≤ V`. -/
theorem level {prog : List Expr} {base X X' V S : ℕ} {E : List Val} {a b : Expr} {va vb : Val}
    {Ca Cb : ℕ} (hva : valSize va ≤ V) (hX : X + V ≤ X')
    (ha : ∀ b', b' ≤ base + X → EvalsLe prog b' E a va Ca (base + S))
    (hb : ∀ b', b' ≤ base + X' → EvalsLe prog b' (va :: E) b vb Cb (base + S)) :
    ∀ b', b' ≤ base + X → EvalsLe prog b' E (Expr.letE a b) vb (1 + Ca + Cb) (base + S) := by
  intro b' hb'
  exact (EvalsLe.letE (ha b' hb') (hb (b' + valSize va) (by omega))).mono (le_refl _)
    (by simp)

/-- One `letE` level of a chain consuming fresh bits (`levelT`): as `level`, the binding consuming
`ba` and the rest `bb`. -/
theorem levelT {prog : List Expr} {base X X' V S : ℕ} {E : List Val} {a b : Expr} {va vb : Val}
    {ba bb : List Bool} {Ca Cb : ℕ} (hva : valSize va ≤ V) (hX : X + V ≤ X')
    (ha : ∀ b', b' ≤ base + X → EvalsLeT prog b' E ba a va Ca (base + S))
    (hb : ∀ b', b' ≤ base + X' → EvalsLeT prog b' (va :: E) bb b vb Cb (base + S)) :
    ∀ b', b' ≤ base + X →
      EvalsLeT prog b' E (ba ++ bb) (Expr.letE a b) vb (1 + Ca + Cb) (base + S) := by
  intro b' hb'
  exact (EvalsLeT.letE (ha b' hb') (hb (b' + valSize va) (by omega))).mono (le_refl _)
    (by simp)

/-! ### Shared size helpers -/

theorem listSize_le_of_suffix {r l : List Val} (h : r <:+ l) : listSize r ≤ listSize l := by
  obtain ⟨p, rfl⟩ := h
  rw [listSize_append]
  omega

theorem valSize_encInts_le_of_suffix {r l : List ℤ} (h : r <:+ l) :
    valSize (encInts r) ≤ valSize (encInts l) := by
  have := listSize_le_of_suffix (h.map Val.int)
  simp only [encInts, valSize_list]
  omega

theorem valSize_encInts_cons (x : ℤ) (r : List ℤ) :
    valSize (encInts (x :: r)) = bitLen x + 2 + valSize (encInts r) := by
  simp only [encInts, List.map_cons, valSize_list, listSize_cons, valSize_int]
  omega

/-- `|∑ p| ≤ |p| · M` when every entry has absolute value at most `M`. -/
theorem abs_sum_le_length_mul (p : List ℤ) (M : ℤ) (h : ∀ z ∈ p, |z| ≤ M) :
    |p.sum| ≤ p.length * M := by
  induction p with
  | nil => simp
  | cons z p ih =>
    simp only [List.sum_cons, List.length_cons]
    have h1 := h z List.mem_cons_self
    have h2 := ih (fun w hw => h w (List.mem_cons_of_mem z hw))
    have h3 := abs_add_le z p.sum
    push_cast
    linarith

/-- Bit length of a sum of at most `n` integers of absolute value `< 2 ^ B`. -/
theorem bitLen_sum_le (p : List ℤ) (B n : ℕ) (hlen : p.length ≤ n)
    (h : ∀ z ∈ p, |z| < 2 ^ B) : bitLen p.sum ≤ B + Nat.size n := by
  apply bitLen_le_of_abs_lt
  have h1 := abs_sum_le_length_mul p (2 ^ B) (fun z hz => (h z hz).le)
  have h2 : (p.length : ℤ) ≤ n := by exact_mod_cast hlen
  have h3 : (n : ℤ) < 2 ^ Nat.size n := by exact_mod_cast Nat.lt_size_self n
  have h4 : (0 : ℤ) < 2 ^ B := by positivity
  calc |p.sum| ≤ p.length * 2 ^ B := h1
    _ ≤ n * 2 ^ B := by gcongr
    _ < 2 ^ Nat.size n * 2 ^ B := by gcongr
    _ = 2 ^ (B + Nat.size n) := by rw [pow_add, mul_comm]

end F2e2e.Cost
