import F2e2e.Cost.Lib.Util

/-!
# Worked example: `length` (T1) — port of cut2 `Cost/Lib/Length.lean`

Reference function: `List.length`. DSL implementation: a `loop` over the accumulator `[k, r]`
(count so far, remaining list), started from `[0, l]`:
* `body_lengthStep` (index `Idx.lengthStep`): `[k, []] ↦ [0, k]` (stop), `[k, x :: r] ↦ [1, [k+1, r]]`;
* `body_length` (index `Idx.length`): `loop Idx.lengthStep [0, l]`.

Spec (`length_spec`): for every program containing `body_lengthStep` at `Idx.lengthStep`,
`EvalsLe prog base [Val.list l] body_length (encN l.length) (C_length l) (base + S_length l)`, with
`C_length l = (l.length + 1) * (Nat.size l.length + 36) + 8` and
`S_length l = 5 * valSize (Val.list l) + 7 * Nat.size l.length + 45`.

Proof pattern: the step is a straight-line body, evaluated symbolically (`EvalsLe.of_eval` +
`simp only` with the `eval_succ_*` lemmas) in the two cases `r = []`, `r = x :: r'`; the loop is
handled by `LoopLe.of_measure` with the invariant `k + r.length = l.length ∧ r <:+ l`
and the measure `r.length`.
-/

namespace F2e2e.Cost
/-- Loop body of `length`. Environment `[acc]` with `acc = [k, r]`. -/
def body_lengthStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                      -- k        env [k, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))) -- r     env [r, k, acc]
      (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
        (ePair (Expr.lit 0) (Expr.var 1))                           -- [0, k]
        (ePair (Expr.lit 1)                                         -- [1, [k + 1, tail r]]
          (ePair (Expr.bin BinOp.add (Expr.var 1) (Expr.lit 1)) (Expr.un UnOp.tail (Expr.var 0))))))

/-- `length`: `l ↦ l.length`. Environment `[l]`. -/
def body_length : Expr := Expr.loop Idx.lengthStep (ePair (Expr.lit 0) (Expr.var 0))

/-- Cost bound of `length`. -/
def C_length (l : List Val) : ℕ := (l.length + 1) * (Nat.size l.length + 36) + 8

/-- Space bound of `length` (on top of the base). -/
def S_length (l : List Val) : ℕ := 5 * valSize (Val.list l) + 7 * Nat.size l.length + 45

/-! ### The loop body (symbolic evaluation) -/

theorem lengthStep_nil (prog : List Expr) (base : ℕ) (k : ℤ) :
    EvalsLe prog base [Val.list [Val.int k, Val.list []]] body_lengthStep
      (Val.list [Val.int 0, Val.int k]) 21
      (base + 4 * valSize (Val.list [Val.int k, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_lengthStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem lengthStep_cons (prog : List Expr) (base : ℕ) (k : ℤ) (x : Val) (r : List Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list (x :: r)]] body_lengthStep
      (Val.list [Val.int 1, Val.list [Val.int (k + 1), Val.list r]]) (35 + bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list (x :: r)]) + 2 * bitLen (k + 1) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_lengthStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false,
    if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop (invariant + measure) -/

/-- Encoding of the loop state `(k, r)` of `length`. -/
def encLenState (s : ℕ × List Val) : Val := Val.list [Val.int (s.1 : ℤ), Val.list s.2]

theorem length_loop {prog : List Expr} (h : prog[Idx.lengthStep]? = some body_lengthStep)
    (l : List Val) (base : ℕ) :
    ∀ s : ℕ × List Val, (s.1 + s.2.length = l.length ∧ s.2 <:+ l) →
      ∃ out, out = encN l.length ∧
        LoopLe prog base Idx.lengthStep (encLenState s) out
          ((s.2.length + 1) * (35 + Nat.size l.length + 1)) (base + S_length l) := by
  refine LoopLe.of_measure h encLenState _ _ (fun s => s.2.length) (35 + Nat.size l.length) ?_
  rintro ⟨k, r⟩ ⟨hlen, hsuf⟩
  simp only at hlen
  have hk : k ≤ l.length := by omega
  have hB : bitLen (k : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le hk
  have hR : listSize r ≤ listSize l := listSize_le_of_suffix hsuf
  cases r with
  | nil =>
    left
    refine ⟨Val.int k, ?_, ?_⟩
    · refine (lengthStep_nil prog _ k).mono (by omega) ?_
      simp only [encLenState, S_length, valSize_int, valSize_list, listSize_cons,
        listSize_nil] at hR ⊢
      omega
    · simp only [List.length_nil, Nat.add_zero] at hlen
      simp [encN, hlen]
  | cons x r' =>
    right
    simp only [List.length_cons] at hlen
    have hk1 : k + 1 ≤ l.length := by omega
    have hB1 : bitLen ((k : ℤ) + 1) ≤ Nat.size l.length := by
      have := bitLen_le_size_of_le hk1
      push_cast at this
      exact this
    have henc : encLenState (k + 1, r') = Val.list [Val.int ((k : ℤ) + 1), Val.list r'] := by
      simp [encLenState]
    refine ⟨1, (k + 1, r'), one_ne_zero, ?_, ⟨?_, ?_⟩, ?_⟩
    · rw [henc]
      refine (lengthStep_cons prog _ k x r').mono (by omega) ?_
      simp only [encLenState, S_length, valSize_int, valSize_list, listSize_cons,
        listSize_nil] at hR ⊢
      omega
    · simp only at hlen ⊢
      omega
    · exact (List.suffix_cons x r').trans hsuf
    · simp

/-! ### The spec -/

/-- **Spec of `length`.** -/
theorem length_spec {prog : List Expr} (h : prog[Idx.lengthStep]? = some body_lengthStep)
    (l : List Val) (base : ℕ) :
    EvalsLe prog base [Val.list l] body_length (encN l.length) (C_length l)
      (base + S_length l) := by
  obtain ⟨out, rfl, hloop⟩ := length_loop h l base (0, l) ⟨by simp, List.suffix_refl l⟩
  have hinit : EvalsLe prog base [Val.list l] (ePair (Expr.lit 0) (Expr.var 0))
      (encLenState (0, l)) 7 (base + 2 * valSize (Val.list l) + 7) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [Val.list l])
      (EvalsLe.lit 0) (EvalsLe.var (i := 0) (v := Val.list l) rfl)
    refine this.mono (by simp) ?_
    simp only [valSize_int, valSize_list, bitLen_zero, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_length]
    nlinarith
  · simp only [S_length, max_le_iff]
    omega

/-- **Spec of `call Idx.length`** (for callers). -/
theorem length_call {prog : List Expr} (h1 : prog[Idx.length]? = some body_length)
    (h2 : prog[Idx.lengthStep]? = some body_lengthStep) {base : ℕ} {env : List Val} {a : Expr}
    {l : List Val} {Ca Sa : ℕ} (ha : EvalsLe prog base env a (Val.list l) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.length a) (encN l.length) (1 + Ca + C_length l)
      (max Sa (base + valSize (Val.list l) + S_length l)) :=
  EvalsLe.call ha h1 (length_spec h2 l _)

end F2e2e.Cost