import F2e2e.Cost.Lib.Util

/-!
# List library: `get` (indexing with default `0`) (T1) — port of cut2 `Cost/Lib/Get.lean`

Reference function: `l.getD n (Val.int 0)`. Input `Val.list [Val.list l, Val.int n]` with
`n : ℕ`; output `l.getD n (Val.int 0)`.

* `body_getStep` (index `Idx.getStep`): accumulator `[k, r]`; `[k, []] ↦ [0, 0]`,
  `[0, x :: r] ↦ [0, x]`, `[k, x :: r] ↦ [1, [k - 1, r]]` for `k ≠ 0`.
* `body_get` (index `Idx.get`): `loop Idx.getStep [n, l]`.

Spec (`get_spec`): `C_get l n = (l.length + 1) * (41 + 2 * Nat.size n) + 15`,
`S_get l n = 5 * valSize (Val.list l) + 7 * Nat.size n + 50`.
-/

namespace F2e2e.Cost
/-- Loop body of `get`. Environment `[acc]` with `acc = [k, r]`. -/
def body_getStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))          -- r ; env [r, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.lit 0))                                     -- [0, 0]
      (Expr.letE (Expr.un UnOp.head (Expr.var 1))                           -- k ; env [k, r, acc]
        (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
          (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))             -- [0, head r]
          (ePair (Expr.lit 1)                                               -- [1, [k - 1, tail r]]
            (ePair (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
              (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `get : [l, n] ↦ l.getD n 0`. -/
def body_get : Expr :=
  Expr.loop Idx.getStep
    (ePair (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))) (Expr.un UnOp.head (Expr.var 0)))

/-- Cost bound of `get`. -/
def C_get (l : List Val) (n : ℕ) : ℕ := (l.length + 1) * (41 + 2 * Nat.size n) + 15

/-- Space bound of `get` (on top of the base). -/
def S_get (l : List Val) (n : ℕ) : ℕ := 5 * valSize (Val.list l) + 7 * Nat.size n + 50

/-! ### The loop body -/

theorem getStep_nil (prog : List Expr) (base : ℕ) (k : ℤ) :
    EvalsLe prog base [Val.list [Val.int k, Val.list []]] body_getStep
      (Val.list [Val.int 0, Val.int 0]) 17
      (base + 4 * valSize (Val.list [Val.int k, Val.list []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_getStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, ne_eq, one_ne_zero,
    not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem getStep_zero (prog : List Expr) (base : ℕ) (x : Val) (r : List Val) :
    EvalsLe prog base [Val.list [Val.int 0, Val.list (x :: r)]] body_getStep
      (Val.list [Val.int 0, x]) 28
      (base + 4 * valSize (Val.list [Val.int 0, Val.list (x :: r)]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_getStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, one_ne_zero,
    not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem getStep_succ (prog : List Expr) (base : ℕ) (k : ℤ) (hk : k ≠ 0) (x : Val)
    (r : List Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list (x :: r)]] body_getStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.list r]]) (40 + 2 * bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list (x :: r)]) + 2 * bitLen (k - 1) +
        20) := by
  apply EvalsLe.of_eval 20
  simp only [body_getStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop -/

/-- Encoding of the `get` loop state `(k, r)`. -/
def encGetState (s : ℕ × List Val) : Val := Val.list [Val.int (s.1 : ℤ), Val.list s.2]

theorem get_loop {prog : List Expr} (h : prog[Idx.getStep]? = some body_getStep)
    (l : List Val) (n : ℕ) (base : ℕ) :
    ∀ s : ℕ × List Val, (s.2.getD s.1 (Val.int 0) = l.getD n (Val.int 0) ∧ s.2 <:+ l ∧ s.1 ≤ n) →
      ∃ out, out = l.getD n (Val.int 0) ∧
        LoopLe prog base Idx.getStep (encGetState s) out
          ((s.2.length + 1) * (40 + 2 * Nat.size n + 1)) (base + S_get l n) := by
  refine LoopLe.of_measure h encGetState _ _ (fun s => s.2.length) (40 + 2 * Nat.size n) ?_
  rintro ⟨k, r⟩ ⟨hget, hsuf, hk⟩
  simp only at hget hsuf hk
  have hB : bitLen (k : ℤ) ≤ Nat.size n := bitLen_le_size_of_le hk
  have hR : listSize r ≤ listSize l := listSize_le_of_suffix hsuf
  cases r with
  | nil =>
    left
    refine ⟨Val.int 0, ?_, ?_⟩
    · refine (getStep_nil prog _ k).mono (by omega) ?_
      simp only [encGetState, S_get, valSize_int, valSize_list, listSize_cons,
        listSize_nil] at hR ⊢
      omega
    · rw [← hget]; rfl
  | cons x r =>
    cases k with
    | zero =>
      left
      refine ⟨x, ?_, ?_⟩
      · refine (getStep_zero prog _ x r).mono (by omega) ?_
        simp only [encGetState, S_get, valSize_int, valSize_list, listSize_cons,
          listSize_nil, Nat.cast_zero, bitLen_zero] at hR ⊢
        omega
      · rw [← hget]; rfl
    | succ k =>
      right
      have hk1 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
      have hB1 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ Nat.size n := by
        have := bitLen_le_size_of_le (show k ≤ n by omega)
        simpa using this
      have henc : encGetState (k, r) =
          Val.list [Val.int (((k + 1 : ℕ) : ℤ) - 1), Val.list r] := by
        simp [encGetState]
      refine ⟨1, (k, r), one_ne_zero, ?_, ⟨?_, ?_, ?_⟩, ?_⟩
      · rw [henc]
        refine (getStep_succ prog _ _ hk1 x r).mono (by omega) ?_
        simp only [encGetState, S_get, valSize_int, valSize_list, listSize_cons,
          listSize_nil] at hR ⊢
        omega
      · simpa using hget
      · exact (List.suffix_cons x r).trans hsuf
      · simp only; omega
      · simp

/-! ### The spec -/

/-- **Spec of `get`.** -/
theorem get_spec {prog : List Expr} (h : prog[Idx.getStep]? = some body_getStep)
    (l : List Val) (n : ℕ) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ)]] body_get (l.getD n (Val.int 0))
      (C_get l n) (base + S_get l n) := by
  obtain ⟨out, rfl, hloop⟩ := get_loop h l n base (n, l) ⟨rfl, List.suffix_refl l, le_refl n⟩
  have hinit : EvalsLe prog base [Val.list [Val.list l, Val.int (n : ℤ)]]
      (ePair (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))) (Expr.un UnOp.head (Expr.var 0)))
      (encGetState (n, l)) 13
      (base + 4 * valSize (Val.list [Val.list l, Val.int (n : ℤ)]) + 10) := by
    refine (EvalsLe.pair (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))
      (EvalsLe.head (EvalsLe.var (i := 0) rfl))).mono (le_refl _) ?_
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_get]
    nlinarith
  · have : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
    simp only [S_get, max_le_iff, valSize_int, valSize_list, listSize_cons, listSize_nil, this]
    omega

end F2e2e.Cost