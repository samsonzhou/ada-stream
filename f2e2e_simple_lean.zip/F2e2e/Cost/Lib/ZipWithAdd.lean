import F2e2e.Cost.Lib.RevAppend

/-!
# List library: `zipWithAdd` (T1) — port of cut2 `Cost/Lib/ZipWithAdd.lean`

Reference function: `List.zipWith (fun x y => x + d * y) a b` (the sketch update
`state + Δ · column` of the Spec). Input `Val.list [encInts a, encInts b, Val.int d]`, output
`encInts (List.zipWith (fun x y => x + d * y) a b)`.

* `body_zipWithAddStep` (index `Idx.zipWithAddStep`): accumulator `[R, A, B, d]` (reversed
  results so far, remaining lists, factor): stops with `R` when `A = []` or `B = []`, else
  continues with `[(x + d*y) :: R, A', B', d]`.
* `body_zipWithAdd` (index `Idx.zipWithAdd`): `let R := loop Idx.zipWithAddStep (nil :: input)`,
  then reverse `R` with the `revAppend` loop.

Spec (`zipWithAdd_spec`) for entries and `d` of bit length `≤ K`:
`C_zipWithAdd a K = (a.length + 1) * (72 + 3K + (K+1)²) + (a.length + 1) * 34 + 15`,
`S_zipWithAdd a b K = 6 * V_zwa a b K + 8K + 60`, with
`V_zwa a b K = valSize (encInts a) + valSize (encInts b) + a.length * (2K + 3) + K + 7`.
-/

namespace F2e2e.Cost
/-- Loop body of `zipWithAdd`. Environment `[acc]` with `acc = [R, A, B, d]`. -/
def body_zipWithAddStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))                  -- A ; [A, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))
      -- B ; env [B, A, acc]
      (Expr.ite (Expr.un UnOp.isNil (Expr.var 1))
        (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 2)))                     -- [0, R]
        (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
          (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 2)))                   -- [0, R]
          (Expr.letE
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail
              (Expr.un UnOp.tail (Expr.var 2)))))                                 -- d ; [d, B, A, acc]
            (ePair (Expr.lit 1)
              (Expr.bin BinOp.cons
                (Expr.bin BinOp.cons
                  (Expr.bin BinOp.add (Expr.un UnOp.head (Expr.var 2))
                    (Expr.bin BinOp.mul (Expr.var 0) (Expr.un UnOp.head (Expr.var 1))))
                  (Expr.un UnOp.head (Expr.var 3)))                               -- (x + d*y) :: R
                (Expr.bin BinOp.cons (Expr.un UnOp.tail (Expr.var 2))
                  (Expr.bin BinOp.cons (Expr.un UnOp.tail (Expr.var 1))
                    (Expr.bin BinOp.cons (Expr.var 0) Expr.nil)))))))))

/-- `zipWithAdd : [a, b, d] ↦ zipWith (fun x y => x + d * y) a b`. -/
def body_zipWithAdd : Expr :=
  Expr.letE (Expr.loop Idx.zipWithAddStep (Expr.bin BinOp.cons Expr.nil (Expr.var 0)))
    (Expr.loop Idx.revAppendStep (ePair (Expr.var 0) Expr.nil))

/-! ### Bit lengths of products -/

theorem bitLen_mul_le (a b : ℤ) : bitLen (a * b) ≤ bitLen a + bitLen b := by
  unfold bitLen
  rw [Nat.size_le, Int.natAbs_mul, pow_add]
  exact Nat.mul_lt_mul'' (Nat.lt_size_self _) (Nat.lt_size_self _)

theorem bitLen_add_mul_le {x d y : ℤ} {K : ℕ} (hx : bitLen x ≤ K) (hd : bitLen d ≤ K)
    (hy : bitLen y ≤ K) : bitLen (x + d * y) ≤ 2 * K + 1 := by
  have h1 := bitLen_add_le x (d * y)
  have h2 := bitLen_mul_le d y
  have h3 : max (bitLen x) (bitLen (d * y)) ≤ 2 * K := max_le (by omega) (by omega)
  omega

/-! ### The loop body -/

theorem zwaStep_nilA (prog : List Expr) (base : ℕ) (R B : List Val) (d : ℤ) :
    EvalsLe prog base [Val.list [Val.list R, Val.list [], Val.list B, Val.int d]]
      body_zipWithAddStep (Val.list [Val.int 0, Val.list R]) 71
      (base + 4 * valSize (Val.list [Val.list R, Val.list [], Val.list B, Val.int d]) + 30) := by
  apply EvalsLe.of_eval 30
  simp only [body_zipWithAddStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem zwaStep_nilB (prog : List Expr) (base : ℕ) (R : List Val) (x : Val) (A : List Val)
    (d : ℤ) :
    EvalsLe prog base [Val.list [Val.list R, Val.list (x :: A), Val.list [], Val.int d]]
      body_zipWithAddStep (Val.list [Val.int 0, Val.list R]) 71
      (base + 4 * valSize (Val.list [Val.list R, Val.list (x :: A), Val.list [], Val.int d]) +
        30) := by
  apply EvalsLe.of_eval 30
  simp only [body_zipWithAddStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem zwaStep_cons (prog : List Expr) (base : ℕ) (R : List Val) (x y : ℤ) (A B : List Val)
    (d : ℤ) :
    EvalsLe prog base
      [Val.list [Val.list R, Val.list (Val.int x :: A), Val.list (Val.int y :: B), Val.int d]]
      body_zipWithAddStep
      (Val.list [Val.int 1,
        Val.list [Val.list (Val.int (x + d * y) :: R), Val.list A, Val.list B, Val.int d]])
      (71 + bitLen x + bitLen (d * y) + (bitLen d + 1) * (bitLen y + 1))
      (base + 4 * valSize (Val.list [Val.list R, Val.list (Val.int x :: A),
          Val.list (Val.int y :: B), Val.int d]) +
        2 * bitLen (x + d * y) + 2 * bitLen (d * y) + 30) := by
  apply EvalsLe.of_eval 30
  simp only [body_zipWithAddStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop -/

/-- Encoding of the `zipWithAdd` loop state `(R, A, B)` for a fixed factor `d`. -/
def encZwa (d : ℤ) (t : List ℤ × List ℤ × List ℤ) : Val :=
  Val.list [encInts t.1, encInts t.2.1, encInts t.2.2, Val.int d]

theorem valSize_encZwa (d : ℤ) (t : List ℤ × List ℤ × List ℤ) :
    valSize (encZwa d t) = valSize (encInts t.1) + valSize (encInts t.2.1) +
      valSize (encInts t.2.2) + bitLen d + 6 := by
  simp only [encZwa, valSize_list, listSize_cons, listSize_nil, valSize_int]
  omega

/-- Space measure of a `zipWithAdd` input (accumulated results have bit length `≤ 2K + 1`). -/
def V_zwa (a b : List ℤ) (K : ℕ) : ℕ :=
  valSize (encInts a) + valSize (encInts b) + a.length * (2 * K + 3) + K + 7

theorem bitLen_zipWith_le (d : ℤ) (K : ℕ) (hd : bitLen d ≤ K) :
    ∀ (pa pb : List ℤ), (∀ x ∈ pa, bitLen x ≤ K) → (∀ y ∈ pb, bitLen y ≤ K) →
      ∀ z ∈ List.zipWith (fun x y => x + d * y) pa pb, bitLen z ≤ 2 * K + 1
  | [], _, _, _, z, hz => by simp at hz
  | _ :: _, [], _, _, z, hz => by simp at hz
  | x :: pa, y :: pb, hx, hy, z, hz => by
    simp only [List.zipWith_cons_cons, List.mem_cons] at hz
    rcases hz with rfl | hz
    · exact bitLen_add_mul_le (hx x List.mem_cons_self) hd (hy y List.mem_cons_self)
    · exact bitLen_zipWith_le d K hd pa pb (fun x' h => hx x' (List.mem_cons_of_mem x h))
        (fun y' h => hy y' (List.mem_cons_of_mem y h)) z hz

theorem valSize_zipWith_rev_le (d : ℤ) (K : ℕ) (hd : bitLen d ≤ K) (pa pb : List ℤ)
    (hx : ∀ x ∈ pa, bitLen x ≤ K) (hy : ∀ y ∈ pb, bitLen y ≤ K) :
    valSize (encInts (List.zipWith (fun x y => x + d * y) pa pb).reverse) ≤
      1 + pa.length * (2 * K + 3) := by
  refine le_trans (valSize_encInts_le _ (2 * K + 1) (fun z hz =>
    bitLen_zipWith_le d K hd pa pb hx hy z (List.mem_reverse.mp hz))) ?_
  rw [show 2 * K + 1 + 2 = 2 * K + 3 by omega]
  have : (List.zipWith (fun x y => x + d * y) pa pb).reverse.length ≤ pa.length := by
    simp only [List.length_reverse, List.length_zipWith]
    exact min_le_left _ _
  have := Nat.mul_le_mul_right (2 * K + 3) this
  omega

theorem zipWith_append_right_of_length {α β γ : Type*} (f : α → β → γ) (l₁ : List α)
    (l₂ l₂' : List β) (h : l₁.length = l₂.length) :
    List.zipWith f l₁ (l₂ ++ l₂') = List.zipWith f l₁ l₂ := by
  have := List.zipWith_append (f := f) (l₁' := []) (l₂' := l₂') h
  simpa using this

theorem zipWith_append_left_of_length {α β γ : Type*} (f : α → β → γ) (l₁ l₁' : List α)
    (l₂ : List β) (h : l₁.length = l₂.length) :
    List.zipWith f (l₁ ++ l₁') l₂ = List.zipWith f l₁ l₂ := by
  have := List.zipWith_append (f := f) (l₁' := l₁') (l₂' := []) h
  simpa using this

theorem zipWithAdd_loop {prog : List Expr}
    (h : prog[Idx.zipWithAddStep]? = some body_zipWithAddStep) (a b : List ℤ) (d : ℤ) (K : ℕ)
    (ha : ∀ x ∈ a, bitLen x ≤ K) (hb : ∀ y ∈ b, bitLen y ≤ K) (hd : bitLen d ≤ K) (base : ℕ) :
    ∀ t : List ℤ × List ℤ × List ℤ,
      (∃ pa pb, pa ++ t.2.1 = a ∧ pb ++ t.2.2 = b ∧ pa.length = pb.length ∧
        t.1 = (List.zipWith (fun x y => x + d * y) pa pb).reverse) →
      ∃ out, out = encInts (List.zipWith (fun x y => x + d * y) a b).reverse ∧
        LoopLe prog base Idx.zipWithAddStep (encZwa d t) out
          ((t.2.1.length + 1) * (71 + 3 * K + (K + 1) * (K + 1) + 1))
          (base + 5 * V_zwa a b K + 8 * K + 40) := by
  refine LoopLe.of_measure h (encZwa d) _ _ (fun t => t.2.1.length)
    (71 + 3 * K + (K + 1) * (K + 1)) ?_
  rintro ⟨R, A, B⟩ ⟨pa, pb, hpa, hpb, hlen, hR⟩
  simp only at hpa hpb hR
  subst hR
  have hpaK : ∀ x ∈ pa, bitLen x ≤ K := fun x hx => ha x (hpa ▸ List.mem_append_left A hx)
  have hpbK : ∀ y ∈ pb, bitLen y ≤ K := fun y hy => hb y (hpb ▸ List.mem_append_left B hy)
  have hRs := valSize_zipWith_rev_le d K hd pa pb hpaK hpbK
  have hAs : valSize (encInts A) ≤ valSize (encInts a) :=
    valSize_encInts_le_of_suffix (hpa ▸ List.suffix_append pa A)
  have hBs : valSize (encInts B) ≤ valSize (encInts b) :=
    valSize_encInts_le_of_suffix (hpb ▸ List.suffix_append pb B)
  have hpal : pa.length ≤ a.length := by rw [← hpa]; simp
  have hmul := Nat.mul_le_mul_right (2 * K + 3) hpal
  cases A with
  | nil =>
    left
    refine ⟨encInts (List.zipWith (fun x y => x + d * y) pa pb).reverse, ?_, ?_⟩
    · refine (zwaStep_nilA prog _ _ (B.map Val.int) d).mono (by omega) ?_
      simp only [encZwa, encInts, V_zwa, valSize_list, listSize_cons, listSize_nil, valSize_int,
        List.map_nil] at hRs hAs hBs ⊢
      omega
    · rw [← hpa, ← hpb, List.append_nil, zipWith_append_right_of_length _ pa pb B hlen]
  | cons x A =>
    cases B with
    | nil =>
      left
      refine ⟨encInts (List.zipWith (fun x y => x + d * y) pa pb).reverse, ?_, ?_⟩
      · refine (zwaStep_nilB prog _ _ (Val.int x) (A.map Val.int) d).mono (by omega) ?_
        simp only [encZwa, encInts, V_zwa, valSize_list, listSize_cons, listSize_nil,
          valSize_int, List.map_nil, List.map_cons] at hRs hAs hBs ⊢
        omega
      · rw [← hpa, ← hpb, List.append_nil, zipWith_append_left_of_length _ pa (x :: A) pb hlen]
    | cons y B =>
      right
      have hxK : bitLen x ≤ K := ha x (hpa ▸ List.mem_append_right pa List.mem_cons_self)
      have hyK : bitLen y ≤ K := hb y (hpb ▸ List.mem_append_right pb List.mem_cons_self)
      have hdy : bitLen (d * y) ≤ 2 * K := le_trans (bitLen_mul_le d y) (by omega)
      have hxdy : bitLen (x + d * y) ≤ 2 * K + 1 := bitLen_add_mul_le hxK hd hyK
      have hprod : (bitLen d + 1) * (bitLen y + 1) ≤ (K + 1) * (K + 1) :=
        Nat.mul_le_mul (by omega) (by omega)
      refine ⟨1, ((x + d * y) :: (List.zipWith (fun x y => x + d * y) pa pb).reverse, A, B),
        one_ne_zero, ?_, ⟨pa ++ [x], pb ++ [y], ?_, ?_, ?_, ?_⟩, by simp⟩
      · refine (zwaStep_cons prog _ ((List.zipWith (fun x y => x + d * y) pa pb).reverse.map
          Val.int) x y (A.map Val.int) (B.map Val.int) d).mono (by omega) ?_
        simp only [encZwa, encInts, V_zwa, valSize_list, listSize_cons, listSize_nil,
          valSize_int, List.map_cons] at hRs hAs hBs ⊢
        omega
      · simpa using hpa
      · simpa using hpb
      · simp [hlen]
      · rw [List.zipWith_append hlen]
        simp

/-! ### The spec -/

/-- Cost bound of `zipWithAdd` (entries of `a`, `b` and the factor have bit length `≤ K`). -/
def C_zipWithAdd (a : List ℤ) (K : ℕ) : ℕ :=
  (a.length + 1) * (72 + 3 * K + (K + 1) * (K + 1)) + (a.length + 1) * 34 + 15

/-- Space bound of `zipWithAdd` (on top of the base). -/
def S_zipWithAdd (a b : List ℤ) (K : ℕ) : ℕ := 6 * V_zwa a b K + 8 * K + 60

/-- **Spec of `zipWithAdd`.** -/
theorem zipWithAdd_spec {prog : List Expr}
    (h1 : prog[Idx.zipWithAddStep]? = some body_zipWithAddStep)
    (h2 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (a b : List ℤ) (d : ℤ) (K : ℕ) (ha : ∀ x ∈ a, bitLen x ≤ K) (hb : ∀ y ∈ b, bitLen y ≤ K)
    (hd : bitLen d ≤ K) (base : ℕ) :
    EvalsLe prog base [Val.list [encInts a, encInts b, Val.int d]] body_zipWithAdd
      (encInts (List.zipWith (fun x y => x + d * y) a b)) (C_zipWithAdd a K)
      (base + S_zipWithAdd a b K) := by
  set Rf := (List.zipWith (fun x y => x + d * y) a b).reverse with hRf
  -- the main loop
  obtain ⟨out, hout, hloop⟩ := zipWithAdd_loop h1 a b d K ha hb hd base ([], a, b)
    ⟨[], [], by simp, by simp, rfl, by simp⟩
  subst hout
  have hinit : EvalsLe prog base [Val.list [encInts a, encInts b, Val.int d]]
      (Expr.bin BinOp.cons Expr.nil (Expr.var 0)) (encZwa d ([], a, b)) 4
      (base + 2 * valSize (Val.list [encInts a, encInts b, Val.int d]) + 3) := by
    refine (EvalsLe.cons EvalsLe.nil (EvalsLe.var (i := 0) rfl)).mono (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have hA := EvalsLe.loop hinit hloop
  -- the final reverse
  have hinit2 : EvalsLe prog (base + valSize (encInts Rf))
      [encInts Rf, Val.list [encInts a, encInts b, Val.int d]]
      (ePair (Expr.var 0) Expr.nil) (encRA (Rf.map Val.int, [])) 7
      (base + valSize (encInts Rf) + 2 * valSize (encInts Rf) + 7) := by
    refine (EvalsLe.pair (EvalsLe.var (i := 0) rfl) EvalsLe.nil).mono (le_refl _) ?_
    simp only [encInts, valSize_list, listSize_nil, max_le_iff]
    omega
  have hB := EvalsLe.loop hinit2 (revAppend_loop h2 (base + valSize (encInts Rf)) (Rf.map Val.int, []))
  have hAll := EvalsLe.letE hA hB
  have e : Val.list ((Rf.map Val.int).reverseAux []) =
      encInts (List.zipWith (fun x y => x + d * y) a b) := by
    simp [hRf, encInts, List.reverseAux_eq, List.map_reverse]
  rw [e] at hAll
  -- bounds
  have hRs : valSize (encInts Rf) ≤ 1 + a.length * (2 * K + 3) :=
    valSize_zipWith_rev_le d K hd a b ha hb
  have hRl : (Rf.map Val.int).length ≤ a.length := by
    simp only [hRf, List.length_map, List.length_reverse, List.length_zipWith]
    exact min_le_left _ _
  have hRl' := Nat.mul_le_mul_right 34 (Nat.succ_le_succ hRl)
  have hc : (a.length + 1) * (71 + 3 * K + (K + 1) * (K + 1) + 1) =
      (a.length + 1) * (72 + 3 * K + (K + 1) * (K + 1)) := by ring
  refine hAll.mono ?_ ?_
  · simp only [C_zipWithAdd, hc, Nat.succ_eq_add_one] at hRl' ⊢
    omega
  · simp only [S_zipWithAdd, V_zwa, max_le_iff, valSize_encRA, encInts, valSize_list,
      listSize_cons, listSize_nil, valSize_int] at hRs ⊢
    omega

end F2e2e.Cost