import F2e2e.Cost.Lib.Get
import F2e2e.Cost.Lib.Set

/-!
# Two-dimensional tables: `get2`, `set2` (T1) — port of cut2 `Cost/Lib/Table.lean`

Tables are lists of rows (`encT f t = Val.list (t.map (encL f))`). Both functions are
compositions of `get`/`set` through `Expr.call` (examples of the `call` rule):

* `body_get2` (index `Idx.get2`): `[T, i, j] ↦ (row i of T).getD j 0`, for `T = Val.list rows`
  with `rows.getD i 0 = Val.list r`; needs `Idx.get`, `Idx.getStep`.
* `body_set2` (index `Idx.set2`): `[T, i, j, x] ↦ T.set i (Val.list (r.set j x))`; needs
  `Idx.get`, `Idx.getStep`, `Idx.set`, `Idx.setStep`, `Idx.revAppendStep`.
-/

namespace F2e2e.Cost
namespace Idx
/-- `get2 : [T, i, j] ↦ T[i][j]`. -/
abbrev get2 : ℕ := 25
/-- `set2 : [T, i, j, x] ↦ T[i][j] := x`. -/
abbrev set2 : ℕ := 26
end Idx

/-- `get2 : [T, i, j] ↦ T[i][j]` (via two calls of `get`). -/
def body_get2 : Expr :=
  Expr.call Idx.get
    (ePair
      (Expr.call Idx.get (ePair (Expr.un UnOp.head (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 0)))))

/-- Cost bound of `get2`. -/
def C_get2 (rows r : List Val) (i j : ℕ) : ℕ := C_get rows i + C_get r j + 30

/-- Space bound of `get2` (on top of the base). -/
def S_get2 (rows r : List Val) (i j : ℕ) : ℕ :=
  4 * valSize (Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ)]) +
    3 * valSize (Val.list r) + S_get rows i + S_get r j + 20

/-- **Spec of `get2`.** -/
theorem get2_spec {prog : List Expr} (hg : prog[Idx.get]? = some body_get)
    (hs : prog[Idx.getStep]? = some body_getStep) (rows r : List Val) (i j : ℕ)
    (hrow : rows.getD i (Val.int 0) = Val.list r) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ)]] body_get2
      (r.getD j (Val.int 0)) (C_get2 rows r i j) (base + S_get2 rows r i j) := by
  have h1 := EvalsLe.pair (EvalsLe.head (EvalsLe.var (prog := prog) (i := 0)
      (env := [Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ)]]) (base := base) rfl))
    (EvalsLe.head (EvalsLe.tail (EvalsLe.var (prog := prog) (i := 0) rfl)))
  have h2 := EvalsLe.call h1 hg (get_spec hs rows i _)
  rw [hrow] at h2
  have h3 := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.var (prog := prog) (i := 0)
    (env := [Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ)]])
    (base := base + valSize (Val.list r)) rfl)))
  have h4 := EvalsLe.pair h2 h3
  have h5 := EvalsLe.call h4 hg (get_spec hs r j _)
  refine h5.mono ?_ ?_
  · simp only [C_get2]
    omega
  · simp only [S_get2, max_le_iff, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega

/-- `set2 : [T, i, j, x] ↦ T.set i ((T[i]).set j x)`. -/
def body_set2 : Expr :=
  Expr.letE
    (Expr.call Idx.get (ePair (Expr.un UnOp.head (Expr.var 0))
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))                  -- row ; [row, inp]
    (Expr.call Idx.set
      (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 1))                   -- T
        (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))   -- i
          (Expr.bin BinOp.cons
            (Expr.call Idx.set
              (Expr.bin BinOp.cons (Expr.var 0)                               -- row
                (Expr.bin BinOp.cons
                  (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))  -- j
                  (Expr.bin BinOp.cons
                    (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail
                      (Expr.un UnOp.tail (Expr.var 1)))))                     -- x
                    Expr.nil))))
            Expr.nil))))

/-- Cost bound of `set2`. -/
def C_set2 (rows r : List Val) (i j : ℕ) : ℕ := C_get rows i + C_set r j + C_set rows i + 80

/-- Space bound of `set2` (on top of the base). -/
def S_set2 (rows r : List Val) (i j : ℕ) (x : Val) : ℕ :=
  6 * valSize (Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]) +
    6 * valSize (Val.list r) + 3 * valSize (Val.list (r.set j x)) + S_get rows i + S_set r j x +
    S_set rows i (Val.list (r.set j x)) + 40

/-- **Spec of `set2`.** -/
theorem set2_spec {prog : List Expr} (hg : prog[Idx.get]? = some body_get)
    (hgs : prog[Idx.getStep]? = some body_getStep) (hst : prog[Idx.set]? = some body_set)
    (hss : prog[Idx.setStep]? = some body_setStep)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (rows r : List Val) (i j : ℕ) (x : Val) (hrow : rows.getD i (Val.int 0) = Val.list r)
    (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]] body_set2
      (Val.list (rows.set i (Val.list (r.set j x)))) (C_set2 rows r i j)
      (base + S_set2 rows r i j x) := by
  -- the row
  have h1 := EvalsLe.pair (EvalsLe.head (EvalsLe.var (prog := prog) (i := 0)
      (env := [Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
      (base := base) rfl))
    (EvalsLe.head (EvalsLe.tail (EvalsLe.var (prog := prog) (i := 0) rfl)))
  have hrowE := EvalsLe.call h1 hg (get_spec hgs rows i _)
  rw [hrow] at hrowE
  -- the new row `r.set j x`, built in the environment `[row, inp]`
  have hT := EvalsLe.head (EvalsLe.var (prog := prog) (i := 1)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r)) rfl)
  have hI := EvalsLe.head (EvalsLe.tail (EvalsLe.var (prog := prog) (i := 1)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows)) rfl))
  have hR := EvalsLe.var (prog := prog) (i := 0)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows) + valSize (Val.int (i : ℤ)))
    rfl
  have hJ := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.var (prog := prog) (i := 1)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows) + valSize (Val.int (i : ℤ)) +
      valSize (Val.list r)) rfl)))
  have hX := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail
    (EvalsLe.var (prog := prog) (i := 1)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows) + valSize (Val.int (i : ℤ)) +
      valSize (Val.list r) + valSize (Val.int (j : ℤ))) rfl))))
  have hN := EvalsLe.nil (prog := prog)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows) + valSize (Val.int (i : ℤ)) +
      valSize (Val.list r) + valSize (Val.int (j : ℤ)) + valSize x)
  have hArg := EvalsLe.cons hR (EvalsLe.cons hJ (EvalsLe.cons hX hN))
  have hNew := EvalsLe.call hArg hst (set_spec hss hra r j x _)
  have hN2 := EvalsLe.nil (prog := prog)
    (env := [Val.list r, Val.list [Val.list rows, Val.int (i : ℤ), Val.int (j : ℤ), x]])
    (base := base + valSize (Val.list r) + valSize (Val.list rows) + valSize (Val.int (i : ℤ)) +
      valSize (Val.list (r.set j x)))
  have hArg2 := EvalsLe.cons hT (EvalsLe.cons hI (EvalsLe.cons hNew hN2))
  have hOut := EvalsLe.call hArg2 hst (set_spec hss hra rows i (Val.list (r.set j x)) _)
  have hAll := EvalsLe.letE hrowE hOut
  refine hAll.mono ?_ ?_
  · simp only [C_set2]
    omega
  · simp only [S_set2, max_le_iff, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega

end F2e2e.Cost