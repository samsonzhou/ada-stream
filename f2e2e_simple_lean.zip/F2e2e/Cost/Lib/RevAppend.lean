import F2e2e.Cost.Lib.Util

/-!
# List library: `revAppend`, `reverse`, `append` (T1) — port of cut2 `Cost/Lib/RevAppend.lean`

Reference functions: `List.reverseAux a b = a.reverse ++ b`, `List.reverse`, `List.append`.

* `body_revAppendStep` (index `Idx.revAppendStep`): accumulator `[A, B]`;
  `[[], B] ↦ [0, B]`, `[x :: A, B] ↦ [1, [A, x :: B]]`.
* `body_revAppend` (index `Idx.revAppend`): input `[a, b]` ↦ `a.reverse ++ b`
  (`loop Idx.revAppendStep (var 0)`).
* `body_reverse` (index `Idx.reverse`): `l ↦ l.reverse` (`loop` from `[l, []]`).
* `body_append` (index `Idx.append`): input `[a, b]` ↦ `a ++ b` (two `revAppend` loops).

All three only need `prog[Idx.revAppendStep]? = some body_revAppendStep`. Every iteration costs
at most `33` (pointer operations only), so the costs are linear in the length; peaks are linear
in the input size (the accumulator keeps a constant size).
-/

namespace F2e2e.Cost
/-- Loop body of `revAppend`. Environment `[acc]` with `acc = [A, B]`. -/
def body_revAppendStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- A ; env [A, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))  -- [0, B]
      (ePair (Expr.lit 1)                                                     -- [1, [tail A, head A :: B]]
        (ePair (Expr.un UnOp.tail (Expr.var 0))
          (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `revAppend : [a, b] ↦ a.reverse ++ b`. -/
def body_revAppend : Expr := Expr.loop Idx.revAppendStep (Expr.var 0)

/-- `reverse : l ↦ l.reverse`. -/
def body_reverse : Expr := Expr.loop Idx.revAppendStep (ePair (Expr.var 0) Expr.nil)

/-- `append : [a, b] ↦ a ++ b`. -/
def body_append : Expr :=
  Expr.letE (Expr.loop Idx.revAppendStep (ePair (Expr.un UnOp.head (Expr.var 0)) Expr.nil))
    (Expr.loop Idx.revAppendStep
      (ePair (Expr.var 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))))

/-! ### Size helpers -/

theorem listSize_reverse (l : List Val) : listSize l.reverse = listSize l := by
  induction l with
  | nil => rfl
  | cons x l ih => simp [listSize_append, ih]; omega

theorem listSize_reverseAux (a b : List Val) :
    listSize (a.reverseAux b) = listSize a + listSize b := by
  rw [List.reverseAux_eq, listSize_append, listSize_reverse]

/-! ### The loop body -/

theorem revAppendStep_nil (prog : List Expr) (base : ℕ) (B : List Val) :
    EvalsLe prog base [Val.list [Val.list [], Val.list B]] body_revAppendStep
      (Val.list [Val.int 0, Val.list B]) 33
      (base + 4 * valSize (Val.list [Val.list [], Val.list B]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_revAppendStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem revAppendStep_cons (prog : List Expr) (base : ℕ) (x : Val) (A B : List Val) :
    EvalsLe prog base [Val.list [Val.list (x :: A), Val.list B]] body_revAppendStep
      (Val.list [Val.int 1, Val.list [Val.list A, Val.list (x :: B)]]) 33
      (base + 4 * valSize (Val.list [Val.list (x :: A), Val.list B]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_revAppendStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-! ### The loop -/

/-- Encoding of the `revAppend` loop state `(A, B)`. -/
def encRA (s : List Val × List Val) : Val := Val.list [Val.list s.1, Val.list s.2]

theorem valSize_encRA (s : List Val × List Val) :
    valSize (encRA s) = listSize s.1 + listSize s.2 + 5 := by
  simp [encRA]; omega

/-- The `revAppend` loop from any state `(A, B)`: returns `A.reverse ++ B`. -/
theorem revAppend_loop {prog : List Expr} (h : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (base : ℕ) (s : List Val × List Val) :
    LoopLe prog base Idx.revAppendStep (encRA s) (Val.list (s.1.reverseAux s.2))
      ((s.1.length + 1) * 34) (base + 5 * valSize (encRA s) + 20) := by
  have key := LoopLe.of_measure (base := base) (S := base + 5 * valSize (encRA s) + 20) h encRA
    (fun t => t.1.reverseAux t.2 = s.1.reverseAux s.2 ∧
      listSize t.1 + listSize t.2 = listSize s.1 + listSize s.2)
    (· = Val.list (s.1.reverseAux s.2)) (fun t => t.1.length) 33 ?_ s ⟨rfl, rfl⟩
  · obtain ⟨out, rfl, hl⟩ := key
    exact hl
  rintro ⟨A, B⟩ ⟨hinv, hsize⟩
  simp only at hinv hsize
  cases A with
  | nil =>
    left
    refine ⟨Val.list B, ?_, ?_⟩
    · refine (revAppendStep_nil prog _ B).mono (le_refl _) ?_
      simp only [encRA, valSize_list, listSize_cons, listSize_nil] at hsize ⊢
      omega
    · simp only [List.reverseAux_nil] at hinv
      rw [hinv]
  | cons x A =>
    right
    refine ⟨1, (A, x :: B), one_ne_zero, ?_, ⟨?_, ?_⟩, ?_⟩
    · refine (revAppendStep_cons prog _ x A B).mono (le_refl _) ?_
      simp only [encRA, valSize_list, listSize_cons, listSize_nil] at hsize ⊢
      omega
    · simpa only [List.reverseAux_cons] using hinv
    · simp only [listSize_cons] at hsize ⊢
      omega
    · simp

/-! ### Specs -/

/-- Cost bound of `revAppend` (`a` = first component). -/
def C_revAppend (a : List Val) : ℕ := (a.length + 1) * 34 + 2

/-- **Spec of `revAppend`.** -/
theorem revAppend_spec {prog : List Expr}
    (h : prog[Idx.revAppendStep]? = some body_revAppendStep) (a b : List Val) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list a, Val.list b]] body_revAppend
      (Val.list (a.reverseAux b)) (C_revAppend a)
      (base + 5 * valSize (Val.list [Val.list a, Val.list b]) + 20) := by
  have hl := revAppend_loop h base (a, b)
  have hinit : EvalsLe prog base [Val.list [Val.list a, Val.list b]] (Expr.var 0) (encRA (a, b)) 1
      (base + valSize (encRA (a, b))) := EvalsLe.var rfl
  refine (EvalsLe.loop hinit hl).mono ?_ ?_
  · simp only [C_revAppend]; omega
  · simp only [max_le_iff, encRA]
    omega

/-- Cost bound of `reverse`. -/
def C_reverse (l : List Val) : ℕ := (l.length + 1) * 34 + 8

/-- Space bound of `reverse` (on top of the base). -/
def S_reverse (l : List Val) : ℕ := 5 * valSize (Val.list l) + 40

/-- **Spec of `reverse`.** -/
theorem reverse_spec {prog : List Expr}
    (h : prog[Idx.revAppendStep]? = some body_revAppendStep) (l : List Val) (base : ℕ) :
    EvalsLe prog base [Val.list l] body_reverse (Val.list l.reverse) (C_reverse l)
      (base + S_reverse l) := by
  have hl := revAppend_loop h base (l, [])
  have hinit : EvalsLe prog base [Val.list l] (ePair (Expr.var 0) Expr.nil) (encRA (l, [])) 7
      (base + 2 * valSize (Val.list l) + 7) := by
    refine (EvalsLe.pair (EvalsLe.var (i := 0) (v := Val.list l) rfl) EvalsLe.nil).mono
      (le_refl _) ?_
    simp only [valSize_list, listSize_nil, max_le_iff]
    omega
  have := (EvalsLe.loop hinit hl).mono (C' := C_reverse l) (S' := base + S_reverse l) ?_ ?_
  · rw [List.reverseAux_eq, List.append_nil] at this
    exact this
  · simp only [C_reverse]; omega
  · simp only [max_le_iff, valSize_encRA, S_reverse, valSize_list, listSize_nil]
    omega

/-- Cost bound of `append` (`a` = first component). -/
def C_append (a : List Val) : ℕ := 2 * ((a.length + 1) * 34) + 23

/-- Space bound of `append` (on top of the base), in terms of the input `[a, b]`. -/
def S_append (a b : List Val) : ℕ := 6 * valSize (Val.list [Val.list a, Val.list b]) + 25

/-- **Spec of `append`.** -/
theorem append_spec {prog : List Expr}
    (h : prog[Idx.revAppendStep]? = some body_revAppendStep) (a b : List Val) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.list a, Val.list b]] body_append (Val.list (a ++ b))
      (C_append a) (base + S_append a b) := by
  -- first loop: reverse `a`
  have hinit1 : EvalsLe prog base [Val.list [Val.list a, Val.list b]]
      (ePair (Expr.un UnOp.head (Expr.var 0)) Expr.nil) (encRA (a, [])) 9
      (base + 3 * valSize (Val.list [Val.list a, Val.list b]) + 7) := by
    refine (EvalsLe.pair (EvalsLe.head (EvalsLe.var (i := 0) rfl)) EvalsLe.nil).mono
      (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have h1 := EvalsLe.loop hinit1 (revAppend_loop h base (a, []))
  rw [List.reverseAux_eq, List.append_nil] at h1
  -- second loop: `revAppend a.reverse b`
  have hinit2 : EvalsLe prog (base + valSize (Val.list a.reverse))
      [Val.list a.reverse, Val.list [Val.list a, Val.list b]]
      (ePair (Expr.var 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
      (encRA (a.reverse, b)) 11
      (base + valSize (Val.list a.reverse) + 3 * valSize (Val.list [Val.list a, Val.list b]) +
        2 * valSize (Val.list a.reverse) + 7) := by
    refine (EvalsLe.pair (EvalsLe.var (i := 0) rfl)
      (EvalsLe.head (EvalsLe.tail (EvalsLe.var (i := 1) rfl)))).mono (le_refl _) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  have h2 := EvalsLe.loop hinit2
    (revAppend_loop h (base + valSize (Val.list a.reverse)) (a.reverse, b))
  have h3 := EvalsLe.letE h1 h2
  rw [List.reverseAux_eq, List.reverse_reverse] at h3
  refine h3.mono ?_ ?_
  · simp only [C_append, List.length_reverse]; omega
  · have hr := listSize_reverse a
    simp only [max_le_iff, valSize_encRA, S_append, valSize_list, listSize_cons, listSize_nil,
      hr]
    omega

end F2e2e.Cost