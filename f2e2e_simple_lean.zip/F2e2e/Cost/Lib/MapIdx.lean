import F2e2e.Cost.Lib.MapB

/-!
# Mapping with the index (randomized or deterministic) and list updates (package L, combinator 3)

Reference functions:
* `mapIdxB f l = mapIdxBFrom f 0 l` with `f : ℕ → α → BitProg β` (index first):
  `mapIdxBFrom f i [] = pure []`, `mapIdxBFrom f i (x :: xs) = do b ← f i x;
  bs ← mapIdxBFrom f (i + 1) xs; pure (b :: bs)`;
* deterministic `mapIdxFrom g i l` (`mapIdxB_pure`);
* the list updates of C-ALG (`F2e2e/C/Alg/Arith.lean`), as local copies with the same equations
  (`modifyAtL`, `setAtL`, `mapFromL`), are deterministic indexed maps:
  `modifyAtL_eq : modifyAtL f k l = mapIdxFrom (fun i a => if i = k then f a else a) 0 l`,
  `setAtL_eq`, `mapFromL_eq` (`if k ≤ i then f a else a`). So each update is `mapIdx` with an
  element routine doing the index test (e.g. `ite (eq (var i) k) (call f …) (var x)`).

DSL routine (generic in the element function index `iF`; the loop body `body_mapIdxStep iF` is
stored at an index `iStep` allocated by the user):
* loop accumulator `[i, rest, accRev, extra]`; the element function gets `[i, x, extra]`;
* `body_mapIdx iStep` : input `[l, extra]` ↦ the results in order (library `reverse`, Idx 5,
  with `revAppendStep`, Idx 4).

Specs: `mapIdxB_impl` (`Implements` form, results `≤ VB`, `M ≥ mapIdx_M encA l extra VB`) and
`mapIdx_val` (deterministic, `EvalsVal` with no fresh bits).
-/

namespace F2e2e.Cost

open F2e2e.Discrete

/-! ## Reference functions -/

section Ref

variable {α β : Type}

/-- Randomized map with the index, starting at index `i`. -/
def mapIdxBFrom (f : ℕ → α → BitProg β) : ℕ → List α → BitProg (List β)
  | _, [] => BitProg.pure []
  | i, x :: xs =>
      (f i x).bind (fun b => (mapIdxBFrom f (i + 1) xs).bind (fun bs => BitProg.pure (b :: bs)))

/-- Randomized map with the index (from `0`). -/
def mapIdxB (f : ℕ → α → BitProg β) (l : List α) : BitProg (List β) := mapIdxBFrom f 0 l

/-- Deterministic map with the index, starting at index `i`. -/
def mapIdxFrom (g : ℕ → α → β) : ℕ → List α → List β
  | _, [] => []
  | i, x :: xs => g i x :: mapIdxFrom g (i + 1) xs

theorem mapIdxB_pure (g : ℕ → α → β) :
    ∀ (i : ℕ) (l : List α),
      mapIdxBFrom (fun i a => BitProg.pure (g i a)) i l = BitProg.pure (mapIdxFrom g i l)
  | _, [] => rfl
  | i, x :: xs => by
    simp only [mapIdxBFrom, BitProg.bind_pure', mapIdxFrom]
    rw [mapIdxB_pure g (i + 1) xs]
    rfl

theorem length_mapIdxFrom (g : ℕ → α → β) : ∀ (i : ℕ) (l : List α), (mapIdxFrom g i l).length = l.length
  | _, [] => rfl
  | i, x :: xs => by simp [mapIdxFrom, length_mapIdxFrom g (i + 1) xs]

/-- Local copy of C-ALG's `modifyAt`: apply `f` to the entry of index `k`. -/
def modifyAtL (f : α → α) : ℕ → List α → List α
  | _, [] => []
  | 0, a :: l => f a :: l
  | k + 1, a :: l => a :: modifyAtL f k l

/-- Local copy of C-ALG's `setAt`: replace the entry of index `k` by `b`. -/
def setAtL (b : α) : ℕ → List α → List α
  | _, [] => []
  | 0, _ :: l => b :: l
  | k + 1, a :: l => a :: setAtL b k l

/-- Local copy of C-ALG's `mapFrom`: apply `f` to every entry of index `≥ k`. -/
def mapFromL (f : α → α) : ℕ → List α → List α
  | _, [] => []
  | 0, a :: l => f a :: mapFromL f 0 l
  | k + 1, a :: l => a :: mapFromL f k l

/-- An indexed map that fixes every entry of index `≥ j` is the identity from index `j`. -/
theorem mapIdxFrom_id (g : ℕ → α → α) :
    ∀ (j : ℕ) (l : List α), (∀ i a, j ≤ i → g i a = a) → mapIdxFrom g j l = l
  | _, [], _ => rfl
  | j, x :: xs, h => by
    simp only [mapIdxFrom, h j x le_rfl]
    rw [mapIdxFrom_id g (j + 1) xs (fun i a hi => h i a (by omega))]

theorem modifyAtL_eq_from (f : α → α) :
    ∀ (k j : ℕ) (l : List α),
      mapIdxFrom (fun i a => if i = j + k then f a else a) j l = modifyAtL f k l
  | k, _, [] => by cases k <;> rfl
  | 0, j, x :: xs => by
    simp only [mapIdxFrom, Nat.add_zero, if_true, modifyAtL]
    rw [mapIdxFrom_id _ (j + 1) xs (fun i a hi => by simp only [show i ≠ j by omega, if_false])]
  | k + 1, j, x :: xs => by
    simp only [mapIdxFrom, show j ≠ j + (k + 1) by omega, if_false, modifyAtL]
    rw [← modifyAtL_eq_from f k (j + 1) xs]
    congr 2
    funext i a
    simp only [show j + (k + 1) = j + 1 + k by omega]

theorem modifyAtL_eq (f : α → α) (k : ℕ) (l : List α) :
    modifyAtL f k l = mapIdxFrom (fun i a => if i = k then f a else a) 0 l := by
  rw [← modifyAtL_eq_from f k 0 l]
  simp

theorem setAtL_eq_modifyAtL (b : α) :
    ∀ (k : ℕ) (l : List α), setAtL b k l = modifyAtL (fun _ => b) k l
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [setAtL, modifyAtL, setAtL_eq_modifyAtL b k l]

theorem setAtL_eq (b : α) (k : ℕ) (l : List α) :
    setAtL b k l = mapIdxFrom (fun i a => if i = k then b else a) 0 l := by
  rw [setAtL_eq_modifyAtL, modifyAtL_eq]

/-- Indexed maps from index `j` only depend on the function at indices `≥ j`. -/
theorem mapIdxFrom_congr {γ : Type} {g g' : ℕ → α → γ} :
    ∀ (j : ℕ) (l : List α), (∀ i a, j ≤ i → g i a = g' i a) → mapIdxFrom g j l = mapIdxFrom g' j l
  | _, [], _ => rfl
  | j, x :: xs, h => by
    simp only [mapIdxFrom, h j x le_rfl]
    rw [mapIdxFrom_congr (j + 1) xs (fun i a hi => h i a (by omega))]

theorem mapFromL_eq_from (f : α → α) :
    ∀ (k j : ℕ) (l : List α),
      mapIdxFrom (fun i a => if j + k ≤ i then f a else a) j l = mapFromL f k l
  | _, _, [] => rfl
  | 0, j, x :: xs => by
    simp only [mapIdxFrom, Nat.add_zero, le_refl, if_true, mapFromL]
    rw [← mapFromL_eq_from f 0 (j + 1) xs]
    congr 1
    exact mapIdxFrom_congr (j + 1) xs (fun i a hi => by
      simp only [Nat.add_zero, show j ≤ i by omega, show j + 1 ≤ i from hi, if_true])
  | k + 1, j, x :: xs => by
    simp only [mapIdxFrom, show ¬ (j + (k + 1) ≤ j) by omega, if_false, mapFromL]
    rw [← mapFromL_eq_from f k (j + 1) xs]
    congr 2
    funext i a
    simp only [show j + (k + 1) = j + 1 + k by omega]

theorem mapFromL_eq (f : α → α) (k : ℕ) (l : List α) :
    mapFromL f k l = mapIdxFrom (fun i a => if k ≤ i then f a else a) 0 l := by
  rw [← mapFromL_eq_from f k 0 l]
  simp

end Ref

/-! ## The DSL routine -/

/-- The expression building the four-element list `[a, b, c, d]`. -/
def eQuad (a b c d : Expr) : Expr :=
  Expr.bin BinOp.cons a (Expr.bin BinOp.cons b (Expr.bin BinOp.cons c
    (Expr.bin BinOp.cons d Expr.nil)))

theorem EvalsVal.quad {prog : List Expr} {M : ℕ} {env : List Val} {a b c d : Expr}
    {ba bb bc bd : List Bool} {x y z w : Val}
    (ha : EvalsVal prog M env ba (.inl a) x) (hb : EvalsVal prog M env bb (.inl b) y)
    (hc : EvalsVal prog M env bc (.inl c) z) (hd : EvalsVal prog M env bd (.inl d) w)
    (hM : valSize (Val.list [x, y, z, w]) ≤ M) :
    EvalsVal prog M env (ba ++ (bb ++ (bc ++ bd))) (.inl (eQuad a b c d))
      (Val.list [x, y, z, w]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h0 := EvalsVal.nil (prog := prog) (M := M) (env := env)
    (by simp only [valSize_list, listSize_nil]; omega)
  have h1 := EvalsVal.cons hd h0 (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  rw [List.append_nil] at h1
  have h2 := EvalsVal.cons hc h1 (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have h3 := EvalsVal.cons hb h2 (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  exact EvalsVal.cons ha h3 (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)

/-- `head (tail (tail (tail e)))`: the fourth entry. -/
def eFourth (e : Expr) : Expr :=
  Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.un UnOp.tail e)))

/-- Loop body of `mapIdx` with element function `iF`. Environment `[acc]`,
`acc = [i, rest, accRev, extra]`: `[i, [], a, e] ↦ [0, a]`,
`[i, x :: r, a, e] ↦ [1, [i + 1, r, iF [i, x, e] :: a, e]]`. -/
def body_mapIdxStep (iF : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))      -- rest ; env [rest, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))
      (ePair (Expr.lit 1)
        (eQuad (Expr.bin BinOp.add (Expr.un UnOp.head (Expr.var 1)) (Expr.lit 1))
          (Expr.un UnOp.tail (Expr.var 0))
          (Expr.bin BinOp.cons
            (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 1))
              (Expr.un UnOp.head (Expr.var 0)) (eFourth (Expr.var 1))))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))
          (eFourth (Expr.var 1)))))

/-- `mapIdx` with the loop body stored at `iStep`: input `[l, extra]` ↦ results in order. -/
def body_mapIdx (iStep : ℕ) : Expr :=
  Expr.call Idx.reverse
    (Expr.loop iStep (eQuad (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)) Expr.nil
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))

section Body

variable {prog : List Expr} {M : ℕ}

theorem mapIdxStep_nil_val (iF : ℕ) (i : ℤ) (av extra : Val)
    (hM : 2 * valSize (Val.list [Val.int i, Val.list [], av, extra]) + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.int i, Val.list [], av, extra]] [] (.inl (body_mapIdxStep iF))
      (Val.list [Val.int 0, av]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_mapIdxStep, ePair, eQuad, eFourth, Arith.eTriple, eval_succ_var, eval_succ_lit,
    eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hM ⊢
  omega

theorem mapIdxStep_cons_val {iF : ℕ} {bodyF : Expr} (hF : prog[iF]? = some bodyF) {i : ℤ}
    {x extra bv : Val} {R A : List Val} {b1 : List Bool}
    (hcall : EvalsVal prog M [Val.list [Val.int i, x, extra]] b1 (.inl bodyF) bv)
    (hM : valSize (Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]) + valSize bv +
      bitLen (i + 1) + 12 ≤ M) :
    EvalsVal prog M [Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]] b1
      (.inl (body_mapIdxStep iF))
      (Val.list [Val.int 1, Val.list [Val.int (i + 1), Val.list R, Val.list (bv :: A), extra]]) := by
  simp only [valSize_list, valSize_int, listSize_cons, listSize_nil] at hM
  have hacc : ∀ {E : List Val}, EvalsVal prog M (Val.list (x :: R) ::
      Val.list [Val.int i, Val.list (x :: R), Val.list A, extra] :: E) [] (.inl (Expr.var 1))
      (Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]) := EvalsVal.var1
  have h1 : EvalsVal prog M [Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))) (Val.list (x :: R)) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var0
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsVal prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    EvalsVal.isNil_cons EvalsVal.var0 (by omega)
  have hi : EvalsVal prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.head (Expr.var 1))) (Val.int i) :=
    EvalsVal.head hacc (by simp only [valSize_int]; omega)
  have hex : EvalsVal prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (eFourth (Expr.var 1))) extra :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail (EvalsVal.tail hacc
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hA : EvalsVal prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail
      (Expr.var 1))))) (Val.list A) :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail hacc
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list]; omega)
  have hargs := EvalsVal.triple hi (EvalsVal.head EvalsVal.var0 (by omega)) hex
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  have hcall' := EvalsVal.call hargs hF hcall
  have hcons := EvalsVal.cons hcall' hA (by simp only [valSize_list, listSize_cons]; omega)
  have hi1 := EvalsVal.add hi (EvalsVal.lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega))
    (by simp only [valSize_int]; omega)
  have hq := EvalsVal.quad hi1 (EvalsVal.tail EvalsVal.var0 (by simp only [valSize_list]; omega))
    hcons hex (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  have hf := EvalsVal.pair (EvalsVal.lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega))
    hq (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
  have := EvalsVal.letE h1 (EvalsVal.ite_false (t := ePair (Expr.lit 0)
    (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) hc rfl hf)
  simpa [body_mapIdxStep] using this

end Body

/-! ## The loop and the specs -/

section Spec

variable {prog : List Expr} {M : ℕ} {α β : Type}

/-- Exact runs of `mapIdxBFrom f i (x :: xs)`. -/
theorem mapIdxBFrom_cons_run_exact {f : ℕ → α → BitProg β} {i : ℕ} {x : α} {xs : List α}
    {bits : List Bool} {bs : List β} (h : (mapIdxBFrom f i (x :: xs)).run bits = some (bs, [])) :
    ∃ b₁ b₂ b bs', bits = b₁ ++ b₂ ∧ (f i x).run b₁ = some (b, []) ∧
      (mapIdxBFrom f (i + 1) xs).run b₂ = some (bs', []) ∧ bs = b :: bs' := by
  simp only [mapIdxBFrom] at h
  obtain ⟨b₁, b₂, b, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨b₂₁, b₂₂, bs', rfl, h21, h22⟩ := bitProg_run_bind_exact.mp h2
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h22
  exact ⟨b₁, b₂₁, b, bs', by simp, h1, h21, rfl⟩

/-- Exact runs of `mapIdxBFrom f i l` have `|l|` results, each produced by an element run. -/
theorem mapIdxBFrom_run_results {f : ℕ → α → BitProg β} (encB : β → Val) {VB : ℕ} :
    ∀ (l : List α) (i : ℕ) (bits : List Bool) (bs : List β),
      (∀ j x, x ∈ l → ∀ bits b, (f j x).run bits = some (b, []) → valSize (encB b) ≤ VB) →
      (mapIdxBFrom f i l).run bits = some (bs, []) →
        bs.length = l.length ∧ ∀ b ∈ bs, valSize (encB b) ≤ VB
  | [], _, bits, bs, _, h => by
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    exact ⟨rfl, by simp⟩
  | x :: xs, i, bits, bs, hVb, h => by
    obtain ⟨c₁, c₂, c, cs, rfl, hc1, hc2, rfl⟩ := mapIdxBFrom_cons_run_exact h
    obtain ⟨hlen, hcs⟩ := mapIdxBFrom_run_results encB xs (i + 1) c₂ cs
      (fun j y hy => hVb j y (List.mem_cons_of_mem x hy)) hc2
    refine ⟨by simp [hlen], fun b hb => ?_⟩
    rcases List.mem_cons.mp hb with rfl | hb'
    · exact hVb i x List.mem_cons_self c₁ b hc1
    · exact hcs b hb'

/-- The value bound required by `mapIdxB_impl`. -/
def mapIdx_M {α : Type} (encA : α → Val) (l : List α) (extra : Val) (VB : ℕ) : ℕ :=
  2 * valSize (encL encA l) + 5 * (1 + l.length * (VB + 1)) + VB + 2 * valSize extra +
    2 * Nat.size l.length + 100

theorem mapIdx_loop {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapIdxStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encB : β → Val) (extra : Val)
    (f : ℕ → α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ i x, x ∈ l → i < l.length →
      Implements prog M [Val.list [Val.int (i : ℤ), encA x, extra]] bodyF encB (f i x))
    (hVb : ∀ i x, x ∈ l → ∀ bits b, (f i x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    ∀ r : List α, r <:+ l → ∀ done : List β, done.length + r.length = l.length →
      (∀ b ∈ done, valSize (encB b) ≤ VB) → ∀ bits bs,
      (mapIdxBFrom f done.length r).run bits = some (bs, []) →
      EvalsVal prog M [] bits
        (.inr (iStep, Val.list [Val.int (done.length : ℤ), encL encA r,
          Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro _ done hlen hdone bits bs h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hA := valSize_rev_map_le encB done VB hdone
    simp only [List.length_nil, Nat.add_zero] at hlen
    have hi : bitLen (done.length : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le (by omega)
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil, List.append_nil]
    refine mapIdxStep_nil_val iF _ _ extra ?_
    simp only [mapIdx_M, valSize_list, valSize_int, listSize_cons, listSize_nil] at hM hA ⊢
    rw [hlen] at hA
    omega
  | cons x r ih =>
    intro hsuf done hlen hdone bits bs h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapIdxBFrom_cons_run_exact h
    have hdl : done.length < l.length := by simp only [List.length_cons] at hlen; omega
    have hb := hVb done.length x hx b₁ b h1
    have hcall := hFi done.length x hx hdl b₁ b h1
    have hdone' : ∀ c ∈ done ++ [b], valSize (encB c) ≤ VB := by
      intro c hc
      rcases List.mem_append.mp hc with hc | hc
      · exact hdone c hc
      · rw [List.mem_singleton.mp hc]; exact hb
    have hlen' : (done ++ [b]).length + r.length = l.length := by
      simp only [List.length_append, List.length_cons, List.length_nil] at hlen ⊢
      omega
    have h2' : (mapIdxBFrom f (done ++ [b]).length r).run b₂ = some (bs', []) := by
      simpa using h2
    have hrest := ih hsuf' (done ++ [b]) hlen' hdone' b₂ bs' h2'
    have hA := valSize_rev_map_le encB done VB hdone
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hi1 : bitLen ((done.length : ℤ) + 1) ≤ Nat.size l.length := by
      have := bitLen_le_size_of_le (show done.length + 1 ≤ l.length by omega)
      push_cast at this
      exact this
    have hi0 : bitLen (done.length : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le hdl.le
    have hbody := mapIdxStep_cons_val (R := r.map encA) (A := (done.map encB).reverse) hF hcall
      (by
        simp only [mapIdx_M, encL, valSize_list, valSize_int, listSize_cons, listSize_nil,
          List.map_cons] at hM hR hA ⊢
        have : done.length * (VB + 1) ≤ l.length * (VB + 1) := Nat.mul_le_mul_right _ hdl.le
        omega)
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    have hidx : Val.int ((done.length : ℤ) + 1) = Val.int (((done ++ [b]).length : ℕ) : ℤ) := by
      simp
    rw [hval]
    rw [hacc, hidx] at hbody
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- **Spec of `mapIdxB`** (`Implements` form): the results in order. -/
theorem mapIdxB_impl {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapIdxStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (f : ℕ → α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ i x, x ∈ l → i < l.length →
      Implements prog M [Val.list [Val.int (i : ℤ), encA x, extra]] bodyF encB (f i x))
    (hVb : ∀ i x, x ∈ l → ∀ bits b, (f i x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    Implements prog M [Val.list [encL encA l, extra]] (body_mapIdx iStep) (encL encB)
      (mapIdxB f l) := by
  intro bits bs h
  have hloop := mapIdx_loop hstep hF encA encB extra f l VB hFi hVb hM l (List.suffix_refl l) []
    (by simp) (by simp) bits bs (by simpa [mapIdxB] using h)
  simp only [List.map_nil, List.reverse_nil, List.nil_append, List.length_nil,
    Nat.cast_zero] at hloop
  have hL := valSize_encL_ge encA l
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (eQuad (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [Val.int 0, encL encA l, Val.list [], extra]) := by
    simp only [mapIdx_M] at hM
    have := EvalsVal.quad (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) (z := 0) (by simp; omega))
      (EvalsVal.head EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  have hl := EvalsVal.loop hinit hloop
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  obtain ⟨hlen, hBs⟩ := mapIdxBFrom_run_results encB l 0 bits bs hVb (by simpa [mapIdxB] using h)
  have hsz := valSize_rev_map_le encB bs VB hBs
  have hcall := EvalsVal.call hl hrev (hrs.mono_M (by
    simp only [S_reverse, mapIdx_M] at hM ⊢
    rw [hlen] at hsz
    omega))
  simpa [encL, body_mapIdx] using hcall

/-- **Spec of the deterministic indexed map** (`mapIdxFrom g 0 l`; with `modifyAtL_eq`,
`setAtL_eq`, `mapFromL_eq` this covers `modifyAt`, `setAt`, `mapFrom`). -/
theorem mapIdx_val {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapIdxStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (g : ℕ → α → β) (l : List α) (VB : ℕ)
    (hG : ∀ i x, x ∈ l → i < l.length →
      EvalsVal prog M [Val.list [Val.int (i : ℤ), encA x, extra]] [] (.inl bodyF) (encB (g i x)))
    (hVg : ∀ i x, x ∈ l → valSize (encB (g i x)) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    EvalsVal prog M [Val.list [encL encA l, extra]] [] (.inl (body_mapIdx iStep))
      (encL encB (mapIdxFrom g 0 l)) := by
  have himpl := mapIdxB_impl hstep hF hrev hra encA encB extra
    (fun i a => BitProg.pure (g i a)) l VB
    (fun i x hx hi => Implements.of_det (hG i x hx hi))
    (fun i x hx bits b h => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
      exact hVg i x hx) hM
  exact himpl [] (mapIdxFrom g 0 l) (by rw [mapIdxB, mapIdxB_pure]; rfl)

end Spec

end F2e2e.Cost
