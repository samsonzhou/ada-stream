import F2e2e.Cost.Lib.Util

/-!
# List library: `replicate` and `range` (T1) — port of cut2 `Cost/Lib/Replicate.lean`

* `body_replicate` (index `Idx.replicate`): input `[Val.int n, x]` (`n : ℕ`) ↦
  `Val.list (List.replicate n x)`; loop body `body_replicateStep` (index `Idx.replicateStep`) on
  the accumulator `[k, R, x]`: `[0, R, x] ↦ [0, R]`, `[k, R, x] ↦ [1, [k - 1, x :: R, x]]`.
* `body_range` (index `Idx.range`): input `Val.int n` (`n : ℕ`) ↦ `encInts (List.range n)`
  (as integers `0, …, n-1`); loop body `body_rangeStep` (index `Idx.rangeStep`) on the
  accumulator `[k, R]`: `[0, R] ↦ [0, R]`, `[k, R] ↦ [1, [k - 1, (k - 1) :: R]]`.
-/

namespace F2e2e.Cost
namespace Idx
/-- `replicate : [n, x] ↦ replicate n x`. -/
abbrev replicate : ℕ := 15
/-- Loop body of `replicate`. -/
abbrev replicateStep : ℕ := 16
/-- `range : n ↦ [0, …, n-1]`. -/
abbrev range : ℕ := 17
/-- Loop body of `range`. -/
abbrev rangeStep : ℕ := 18
end Idx

/-! ### `replicate` -/

/-- Loop body of `replicate`. Environment `[acc]` with `acc = [k, R, x]`. -/
def body_replicateStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- k ; env [k, acc]
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))  -- [0, R]
      (ePair (Expr.lit 1)                                                     -- [1, [k-1, x :: R, x]]
        (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
          (ePair
            (Expr.bin BinOp.cons
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))))

/-- `replicate : [n, x] ↦ replicate n x`. Starts the loop from `[n, [], x]`. -/
def body_replicate : Expr :=
  Expr.loop Idx.replicateStep
    (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
      (Expr.bin BinOp.cons Expr.nil (Expr.un UnOp.tail (Expr.var 0))))

theorem replicateStep_zero (prog : List Expr) (base : ℕ) (R : List Val) (x : Val) :
    EvalsLe prog base [Val.list [Val.int 0, Val.list R, x]] body_replicateStep
      (Val.list [Val.int 0, Val.list R]) 20
      (base + 4 * valSize (Val.list [Val.int 0, Val.list R, x]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_replicateStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, ne_eq, if_true, one_ne_zero,
    not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem replicateStep_succ (prog : List Expr) (base : ℕ) (k : ℤ) (hk : k ≠ 0) (R : List Val)
    (x : Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list R, x]] body_replicateStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.list (x :: R), x]])
      (50 + 2 * bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list R, x]) + 2 * bitLen (k - 1) +
        4 * valSize x + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_replicateStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, ne_eq, hk, if_false,
    not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

/-- Encoding of the `replicate` loop state `(k, m)` (`m` copies of `x` accumulated). -/
def encRepState (x : Val) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.list (List.replicate s.2 x), x]

theorem listSize_replicate (m : ℕ) (x : Val) :
    listSize (List.replicate m x) = m * (valSize x + 1) := by
  induction m with
  | zero => simp
  | succ m ih => simp only [List.replicate_succ, listSize_cons, ih]; ring

/-- Cost bound of `replicate`. -/
def C_replicate (n : ℕ) : ℕ := (n + 1) * (51 + 2 * Nat.size n) + 12

/-- Space bound of `replicate` (on top of the base). -/
def S_replicate (n : ℕ) (x : Val) : ℕ :=
  5 * (n * (valSize x + 1)) + 7 * Nat.size n + 9 * valSize x + 60

theorem replicate_loop {prog : List Expr} (h : prog[Idx.replicateStep]? = some body_replicateStep)
    (n : ℕ) (x : Val) (base : ℕ) :
    ∀ s : ℕ × ℕ, s.1 + s.2 = n →
      ∃ out, out = Val.list (List.replicate n x) ∧
        LoopLe prog base Idx.replicateStep (encRepState x s) out
          ((s.1 + 1) * (50 + 2 * Nat.size n + 1)) (base + S_replicate n x) := by
  refine LoopLe.of_measure h (encRepState x) _ _ (fun s => s.1) (50 + 2 * Nat.size n) ?_
  rintro ⟨k, m⟩ hkm
  simp only at hkm
  have hB : bitLen (k : ℤ) ≤ Nat.size n := bitLen_le_size_of_le (by omega)
  have hm : m * (valSize x + 1) ≤ n * (valSize x + 1) := Nat.mul_le_mul_right _ (by omega)
  cases k with
  | zero =>
    left
    refine ⟨Val.list (List.replicate m x), ?_, by simp only [Nat.zero_add] at hkm; rw [hkm]⟩
    refine (replicateStep_zero prog _ _ x).mono (by omega) ?_
    simp only [encRepState, S_replicate, valSize_int, valSize_list, listSize_cons, listSize_nil,
      listSize_replicate, Nat.cast_zero, bitLen_zero]
    omega
  | succ k =>
    right
    have hk1 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
    have hB1 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ Nat.size n := by
      have := bitLen_le_size_of_le (show k ≤ n by omega)
      simpa using this
    have hm1 : (m + 1) * (valSize x + 1) ≤ n * (valSize x + 1) :=
      Nat.mul_le_mul_right _ (by omega)
    have henc : encRepState x (k, m + 1) =
        Val.list [Val.int (((k + 1 : ℕ) : ℤ) - 1), Val.list (x :: List.replicate m x), x] := by
      simp [encRepState, List.replicate_succ]
    refine ⟨1, (k, m + 1), one_ne_zero, ?_, by simp only at hkm ⊢; omega, by simp⟩
    rw [henc]
    refine (replicateStep_succ prog _ _ hk1 _ x).mono (by omega) ?_
    simp only [encRepState, S_replicate, valSize_int, valSize_list, listSize_cons, listSize_nil,
      listSize_replicate] at hm1 ⊢
    nlinarith

/-- **Spec of `replicate`.** -/
theorem replicate_spec {prog : List Expr}
    (h : prog[Idx.replicateStep]? = some body_replicateStep) (n : ℕ) (x : Val) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.int (n : ℤ), x]] body_replicate
      (Val.list (List.replicate n x)) (C_replicate n) (base + S_replicate n x) := by
  obtain ⟨out, rfl, hloop⟩ := replicate_loop h n x base (n, 0) (by simp)
  have hinit : EvalsLe prog base [Val.list [Val.int (n : ℤ), x]]
      (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0))
        (Expr.bin BinOp.cons Expr.nil (Expr.un UnOp.tail (Expr.var 0))))
      (encRepState x (n, 0)) 11
      (base + 3 * valSize (Val.list [Val.int (n : ℤ), x]) + 10) := by
    refine (EvalsLe.cons (EvalsLe.head (EvalsLe.var (i := 0) rfl))
      (EvalsLe.cons EvalsLe.nil (EvalsLe.tail (EvalsLe.var (i := 0) rfl)))).mono (le_refl _) ?_
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_replicate]
    nlinarith
  · have : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
    simp only [S_replicate, max_le_iff, valSize_int, valSize_list, listSize_cons, listSize_nil,
      this]
    omega

/-! ### `range` -/

/-- Loop body of `range`. Environment `[acc]` with `acc = [k, R]`. -/
def body_rangeStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                  -- k ; env [k, acc]
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))  -- [0, R]
      (Expr.letE (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))               -- k-1 ; [k-1, k, acc]
        (ePair (Expr.lit 1)                                                   -- [1, [k-1, (k-1) :: R]]
          (ePair (Expr.var 0)
            (Expr.bin BinOp.cons (Expr.var 0)
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2))))))))

/-- `range : n ↦ [0, …, n-1]`. Starts the loop from `[n, []]`. -/
def body_range : Expr := Expr.loop Idx.rangeStep (ePair (Expr.var 0) Expr.nil)

theorem rangeStep_zero (prog : List Expr) (base : ℕ) (R : List Val) :
    EvalsLe prog base [Val.list [Val.int 0, Val.list R]] body_rangeStep
      (Val.list [Val.int 0, Val.list R]) 20
      (base + 4 * valSize (Val.list [Val.int 0, Val.list R]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_rangeStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, ne_eq, if_true, one_ne_zero,
    not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

theorem rangeStep_succ (prog : List Expr) (base : ℕ) (k : ℤ) (hk : k ≠ 0) (R : List Val) :
    EvalsLe prog base [Val.list [Val.int k, Val.list R]] body_rangeStep
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.list (Val.int (k - 1) :: R)]])
      (45 + 2 * bitLen k)
      (base + 4 * valSize (Val.list [Val.int k, Val.list R]) + 6 * bitLen (k - 1) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_rangeStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    hk, if_false, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    (try simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one]) <;> omega

/-- Encoding of the `range` loop state `k` (the list `[k, …, n-1]` has been built). -/
def encRangeState (n k : ℕ) : Val :=
  Val.list [Val.int (k : ℤ), encInts ((List.range' k (n - k)).map (fun i : ℕ => (i : ℤ)))]

theorem valSize_encInts_range'_le (n k : ℕ) :
    valSize (encInts ((List.range' k (n - k)).map (fun i : ℕ => (i : ℤ)))) ≤
      1 + n * (Nat.size n + 2) := by
  refine le_trans (valSize_encInts_le _ (Nat.size n) ?_) ?_
  · intro z hz
    simp only [List.mem_map, List.mem_range'] at hz
    obtain ⟨i, ⟨j, hj, rfl⟩, rfl⟩ := hz
    exact bitLen_le_size_of_le (by omega)
  · simp only [List.length_map, List.length_range']
    have := Nat.mul_le_mul_right (Nat.size n + 2) (show n - k ≤ n by omega)
    omega

/-- Cost bound of `range`. -/
def C_range (n : ℕ) : ℕ := (n + 1) * (46 + 2 * Nat.size n) + 9

/-- Space bound of `range` (on top of the base). -/
def S_range (n : ℕ) : ℕ := 5 * (n * (Nat.size n + 2)) + 11 * Nat.size n + 60

theorem range_loop {prog : List Expr} (h : prog[Idx.rangeStep]? = some body_rangeStep)
    (n : ℕ) (base : ℕ) :
    ∀ k : ℕ, k ≤ n →
      ∃ out, out = encInts ((List.range n).map (fun i : ℕ => (i : ℤ))) ∧
        LoopLe prog base Idx.rangeStep (encRangeState n k) out
          ((k + 1) * (45 + 2 * Nat.size n + 1)) (base + S_range n) := by
  refine LoopLe.of_measure h (encRangeState n) _ _ (fun k => k) (45 + 2 * Nat.size n) ?_
  intro k hk
  have hB : bitLen (k : ℤ) ≤ Nat.size n := bitLen_le_size_of_le hk
  have hR := valSize_encInts_range'_le n k
  cases k with
  | zero =>
    left
    refine ⟨encInts ((List.range' 0 (n - 0)).map (fun i : ℕ => (i : ℤ))), ?_, ?_⟩
    · refine (rangeStep_zero prog _ _).mono (by omega) ?_
      simp only [encRangeState, encInts, S_range, valSize_int, valSize_list, listSize_cons,
        listSize_nil, Nat.cast_zero, bitLen_zero] at hR ⊢
      omega
    · simp [List.range_eq_range']
  | succ k =>
    right
    have hk1 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
    have hB1 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ Nat.size n := by
      have := bitLen_le_size_of_le (show k ≤ n by omega)
      simpa using this
    have henc : encRangeState n k =
        Val.list [Val.int (((k + 1 : ℕ) : ℤ) - 1),
          Val.list (Val.int (((k + 1 : ℕ) : ℤ) - 1) ::
            ((List.range' (k + 1) (n - (k + 1))).map (fun i : ℕ => (i : ℤ))).map Val.int)] := by
      have e : n - k = (n - (k + 1)) + 1 := by omega
      simp [encRangeState, encInts, e, List.range'_succ]
    refine ⟨1, k, one_ne_zero, ?_, by omega, by simp⟩
    rw [henc]
    refine (rangeStep_succ prog _ _ hk1 _).mono (by omega) ?_
    simp only [encRangeState, encInts, S_range, valSize_int, valSize_list, listSize_cons,
      listSize_nil] at hR ⊢
    omega

/-- **Spec of `range`.** -/
theorem range_spec {prog : List Expr} (h : prog[Idx.rangeStep]? = some body_rangeStep)
    (n : ℕ) (base : ℕ) :
    EvalsLe prog base [Val.int (n : ℤ)] body_range
      (encInts ((List.range n).map (fun i : ℕ => (i : ℤ)))) (C_range n) (base + S_range n) := by
  obtain ⟨out, rfl, hloop⟩ := range_loop h n base n (le_refl n)
  have hinit : EvalsLe prog base [Val.int (n : ℤ)] (ePair (Expr.var 0) Expr.nil)
      (encRangeState n n) 7 (base + 2 * valSize (Val.int (n : ℤ)) + 9) := by
    have e : encRangeState n n = Val.list [Val.int (n : ℤ), Val.list []] := by
      simp [encRangeState, encInts]
    rw [e]
    refine (EvalsLe.pair (EvalsLe.var (i := 0) rfl) EvalsLe.nil).mono (le_refl _) ?_
    simp only [valSize_list, listSize_nil, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_range]
    nlinarith
  · have : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
    simp only [S_range, max_le_iff, valSize_int, this]
    omega

end F2e2e.Cost