import F2e2e.Spec

/-!
# Facts about the cost model of `F2e2e/Spec.lean` §3 (port of cut2's `SpecFacts.lean`, with tapes)

* One-step inversion lemmas `eval_*_iff` / `eval_*_eq` (one per constructor, at fuel `n + 1`) and
  `loopRun_succ_iff`: a successful evaluation decomposes into successful evaluations of the
  sub-expressions (and of the remaining loop iterations) at fuel `n`, each on the tape left by the
  previous one, with the exact cost/peak formula of the Spec.
* **Fuel monotonicity** (`eval_fuel_mono`, `loopRun_fuel_mono`) and **determinism** (`eval_det`,
  `loopRun_det`): more fuel never changes a successful result, so two successful runs on the same
  tape agree (value, cost, peak and leftover tape).
* **Base shift** (`eval_base_shift`): peaks shift with the base; values, costs and leftover tapes do
  not depend on it.
* Peak and cost bounds (`eval_peak_ge`, `eval_cost_pos`).
* **Tape frame lemmas.** A run consumes a prefix of its tape and depends only on that prefix:
  - `eval_tape_frame`: if a run on `tape` leaves `t'`, then `tape = pre ++ t'` and for every `r` the
    run on `pre ++ r` is identical and leaves `r`;
  - `eval_tape_suffix`: the leftover is a suffix of the input tape;
  - `eval_tape_append`: a run on `pre ++ t` leaving `t` gives a run on `pre ++ r` leaving `r`;
    `eval_tape_append_nil`: a run on `pre` leaving `[]` gives a run on `pre ++ r` leaving `r`;
  - `eval_tape_indep`: a run that consumes nothing runs identically on every tape;
    `eval_tape_nil`: a run on the empty tape consumes nothing;
  - `eval_tape_prefix`: a run on `l ++ r` that reads at most `|l|` bits leaves `l₂ ++ r` with `l₂` a
    suffix of `l`, and is unchanged (leaving `l₂ ++ r'`) when `r` is replaced by any `r'`;
  - `eval_tape_drop`: the leftover is `tape.drop k` for the number `k` of consumed bits.
  The same lemmas for `loopRun`.
* `RunsOn` facts: output uniqueness, monotonicity in the space bound, tape frame.
* Size lemmas (`valSize_int`, `valSize_list`, `listSize_*`, `bitLen_*`, `valSize_encInts`).

Proof plan: as in cut2, each property of `eval` is proved simultaneously with the corresponding
property of `loopRun` by induction on the fuel, using the inversion lemmas in every case. The tape
frame property is proved in the combined form `tape_aux` (a run on `tape` leaving `t'` determines the
consumed part `pre` with `tape = pre ++ t'` such that the run on `pre ++ s` leaves `s`, for every
`s`); in the composite cases the consumed part is the concatenation of those of the sub-runs.
-/

namespace F2e2e.Cost

/-! ### One-step inversion lemmas -/

section Inversion
variable (prog : List Expr)

theorem eval_zero_eq (base : ℕ) (env : List Val) (tape : List Bool) (e : Expr) :
    eval prog 0 base env tape e = none := by
  simp [eval]

theorem loopRun_zero_eq (base i : ℕ) (v : Val) (tape : List Bool) :
    loopRun prog 0 base i v tape = none := by
  simp [loopRun]

theorem eval_var_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.var i) = some r ↔
      ∃ v, env[i]? = some v ∧ r = (v, 1, base + valSize v, tape) := by
  simp only [eval]
  cases env[i]? <;> simp [eq_comm]

theorem eval_lit_eq (n base : ℕ) (env : List Val) (tape : List Bool) (z : ℤ) :
    eval prog (n+1) base env tape (Expr.lit z) =
      some (Val.int z, 1 + bitLen z, base + valSize (Val.int z), tape) := by
  simp only [eval]

theorem eval_nil_eq (n base : ℕ) (env : List Val) (tape : List Bool) :
    eval prog (n+1) base env tape Expr.nil =
      some (Val.list [], 1, base + valSize (Val.list []), tape) := by
  simp only [eval]

theorem eval_coin_cons (n base : ℕ) (env : List Val) (b : Bool) (rest : List Bool) :
    eval prog (n+1) base env (b :: rest) Expr.coin =
      some (Val.int (if b = true then 1 else 0), 1,
        base + valSize (Val.int (if b = true then 1 else 0)), rest) := by
  simp only [eval]

theorem eval_coin_nil (n base : ℕ) (env : List Val) :
    eval prog (n+1) base env [] Expr.coin = none := by
  simp only [eval]

theorem eval_coin_iff {n base : ℕ} {env : List Val} {tape : List Bool}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape Expr.coin = some r ↔
      ∃ b rest, tape = b :: rest ∧
        r = (Val.int (if b = true then 1 else 0), 1,
          base + valSize (Val.int (if b = true then 1 else 0)), rest) := by
  cases tape with
  | nil => simp [eval_coin_nil]
  | cons b rest =>
    rw [eval_coin_cons]
    constructor
    · intro h
      exact ⟨b, rest, rfl, (Option.some.inj h).symm⟩
    · rintro ⟨b', rest', h, rfl⟩
      cases h
      rfl

theorem eval_bin_iff {n base : ℕ} {env : List Val} {tape : List Bool} {op : BinOp} {a b : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.bin op a b) = some r ↔
      ∃ va ca pa ta vb cb pb tb v c, eval prog n base env tape a = some (va, ca, pa, ta) ∧
        eval prog n (base + valSize va) env ta b = some (vb, cb, pb, tb) ∧
        evalBin op va vb = some (v, c) ∧
        r = (v, 1 + ca + cb + c, max (max pa pb) (base + valSize va + valSize vb + valSize v),
          tb) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i vb cb pb tb hb
        split at h
        · simp at h
        · rename_i v c hv
          exact ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩
    simp only [ha, hb, hv]

theorem eval_un_iff {n base : ℕ} {env : List Val} {tape : List Bool} {op : UnOp} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.un op a) = some r ↔
      ∃ va ca pa ta v c, eval prog n base env tape a = some (va, ca, pa, ta) ∧
        evalUn op va = some (v, c) ∧
        r = (v, 1 + ca + c, max pa (base + valSize va + valSize v), ta) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i v c hv
        exact ⟨va, ca, pa, ta, v, c, ha, hv, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩
    simp only [ha, hv]

theorem eval_ite_iff {n base : ℕ} {env : List Val} {tape : List Bool} {c t f : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.ite c t f) = some r ↔
      ∃ z cc pc tc v cv pv tv, eval prog n base env tape c = some (Val.int z, cc, pc, tc) ∧
        eval prog n base env tc (if z ≠ 0 then t else f) = some (v, cv, pv, tv) ∧
        r = (v, 1 + cc + cv, max pc pv, tv) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · rename_i z cc pc tc hc
      split at h
      · simp at h
      · rename_i v cv pv tv hv
        exact ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, (Option.some.inj h).symm⟩
    · simp at h
  · rintro ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩
    simp only [hc, hv]

theorem eval_letE_iff {n base : ℕ} {env : List Val} {tape : List Bool} {a b : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.letE a b) = some r ↔
      ∃ va ca pa ta vb cb pb tb, eval prog n base env tape a = some (va, ca, pa, ta) ∧
        eval prog n (base + valSize va) (va :: env) ta b = some (vb, cb, pb, tb) ∧
        r = (vb, 1 + ca + cb, max pa pb, tb) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i vb cb pb tb hb
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩
    simp only [ha, hb]

theorem eval_call_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.call i a) = some r ↔
      ∃ va ca pa ta body vb cb pb tb, eval prog n base env tape a = some (va, ca, pa, ta) ∧
        prog[i]? = some body ∧
        eval prog n (base + valSize va) [va] ta body = some (vb, cb, pb, tb) ∧
        r = (vb, 1 + ca + cb, max pa pb, tb) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i body hbody
        split at h
        · simp at h
        · rename_i vb cb pb tb hb
          exact ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩
    simp only [ha, hbody, hb]

theorem eval_loop_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    eval prog (n+1) base env tape (Expr.loop i a) = some r ↔
      ∃ va ca pa ta w cw pw tw, eval prog n base env tape a = some (va, ca, pa, ta) ∧
        loopRun prog n base i va ta = some (w, cw, pw, tw) ∧
        r = (w, 1 + ca + cw, max pa pw, tw) := by
  simp only [eval]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i w cw pw tw hw
        exact ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hw, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hw, rfl⟩
    simp only [ha, hw]

theorem loopRun_succ_iff {n base i : ℕ} {v : Val} {tape : List Bool}
    {r : Val × ℕ × ℕ × List Bool} :
    loopRun prog (n+1) base i v tape = some r ↔
      ∃ body flag v' cb pb tb, prog[i]? = some body ∧
        eval prog n (base + valSize v) [v] tape body =
          some (Val.list [Val.int flag, v'], cb, pb, tb) ∧
        ((flag = 0 ∧ r = (v', 1 + cb, pb, tb)) ∨
          (flag ≠ 0 ∧ ∃ w cw pw tw, loopRun prog n base i v' tb = some (w, cw, pw, tw) ∧
            r = (w, 1 + cb + cw, max pb pw, tw))) := by
  simp only [loopRun]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i body hbody
      split at h
      · rename_i flag v' cb pb tb hb
        by_cases hflag : flag = 0
        · rw [if_pos hflag] at h
          exact ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inl ⟨hflag, (Option.some.inj h).symm⟩⟩
        · rw [if_neg hflag] at h
          split at h
          · simp at h
          · rename_i w cw pw tw hw
            exact ⟨body, flag, v', cb, pb, tb, hbody, hb,
              Or.inr ⟨hflag, w, cw, pw, tw, hw, (Option.some.inj h).symm⟩⟩
      · simp at h
  · rintro ⟨body, flag, v', cb, pb, tb, hbody, hb, ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩⟩
    · simp only [hbody, hb]
      rw [if_pos hflag]
    · simp only [hbody, hb]
      rw [if_neg hflag]
      simp only [hw]

end Inversion

/-! ### Fuel monotonicity and determinism (simultaneously for `eval` and `loopRun`) -/

theorem fuel_mono_aux (prog : List Expr) (n : ℕ) :
    (∀ m, n ≤ m → ∀ base env tape e r, eval prog n base env tape e = some r →
      eval prog m base env tape e = some r) ∧
    (∀ m, n ≤ m → ∀ base i v tape r, loopRun prog n base i v tape = some r →
      loopRun prog m base i v tape = some r) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ _ _ h => by simp [eval] at h,
      fun _ _ _ _ _ _ _ h => by simp [loopRun] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro m' hm base env tape e r hr
      obtain ⟨m, rfl⟩ : ∃ m, m' = m + 1 := ⟨m' - 1, by omega⟩
      have hnm : n ≤ m := by omega
      cases e with
      | var i => rw [eval_var_iff] at hr ⊢; exact hr
      | lit z => rw [eval_lit_eq] at hr ⊢; exact hr
      | nil => rw [eval_nil_eq] at hr ⊢; exact hr
      | coin => rw [eval_coin_iff] at hr ⊢; exact hr
      | bin op a b =>
        rw [eval_bin_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ihe m hnm _ _ _ _ _ ha,
          ihe m hnm _ _ _ _ _ hb, hv, rfl⟩
      | un op a =>
        rw [eval_un_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, v, c, ihe m hnm _ _ _ _ _ ha, hv, rfl⟩
      | ite c t f =>
        rw [eval_ite_iff] at hr ⊢
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := hr
        exact ⟨z, cc, pc, tc, v, cv, pv, tv, ihe m hnm _ _ _ _ _ hc, ihe m hnm _ _ _ _ _ hv, rfl⟩
      | letE a b =>
        rw [eval_letE_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, ihe m hnm _ _ _ _ _ ha, ihe m hnm _ _ _ _ _ hb, rfl⟩
      | call i a =>
        rw [eval_call_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ihe m hnm _ _ _ _ _ ha, hbody,
          ihe m hnm _ _ _ _ _ hb, rfl⟩
      | loop i a =>
        rw [eval_loop_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, w, cw, pw, tw, ihe m hnm _ _ _ _ _ ha, ihl m hnm _ _ _ _ _ hl, rfl⟩
    · intro m' hm base i v tape r hr
      obtain ⟨m, rfl⟩ : ∃ m, m' = m + 1 := ⟨m' - 1, by omega⟩
      have hnm : n ≤ m := by omega
      rw [loopRun_succ_iff] at hr ⊢
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := hr
      refine ⟨body, flag, v', cb, pb, tb, hbody, ihe m hnm _ _ _ _ _ hb, ?_⟩
      rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
      · exact Or.inl ⟨hflag, rfl⟩
      · exact Or.inr ⟨hflag, w, cw, pw, tw, ihl m hnm _ _ _ _ _ hw, rfl⟩

/-- **Fuel monotonicity.** More fuel never changes a successful result. -/
theorem eval_fuel_mono (prog : List Expr) {fuel fuel' : ℕ} (h : fuel ≤ fuel') (base : ℕ)
    (env : List Val) (tape : List Bool) (e : Expr) (r : Val × ℕ × ℕ × List Bool)
    (hr : eval prog fuel base env tape e = some r) :
    eval prog fuel' base env tape e = some r :=
  (fuel_mono_aux prog fuel).1 fuel' h base env tape e r hr

/-- Fuel monotonicity of loop iterations. -/
theorem loopRun_fuel_mono (prog : List Expr) {fuel fuel' : ℕ} (h : fuel ≤ fuel') (base i : ℕ)
    (v : Val) (tape : List Bool) (r : Val × ℕ × ℕ × List Bool)
    (hr : loopRun prog fuel base i v tape = some r) :
    loopRun prog fuel' base i v tape = some r :=
  (fuel_mono_aux prog fuel).2 fuel' h base i v tape r hr

/-- **Determinism.** Two successful runs on the same tape (with any fuels) agree: same value,
cost, peak and leftover tape. -/
theorem eval_det (prog : List Expr) {f₁ f₂ : ℕ} (base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) {r₁ r₂ : Val × ℕ × ℕ × List Bool} (h₁ : eval prog f₁ base env tape e = some r₁)
    (h₂ : eval prog f₂ base env tape e = some r₂) : r₁ = r₂ := by
  have e₁ := eval_fuel_mono prog (le_max_left f₁ f₂) base env tape e r₁ h₁
  have e₂ := eval_fuel_mono prog (le_max_right f₁ f₂) base env tape e r₂ h₂
  rw [e₁] at e₂
  exact Option.some.inj e₂

/-- Determinism of loop iterations. -/
theorem loopRun_det (prog : List Expr) {f₁ f₂ : ℕ} (base i : ℕ) (v : Val) (tape : List Bool)
    {r₁ r₂ : Val × ℕ × ℕ × List Bool} (h₁ : loopRun prog f₁ base i v tape = some r₁)
    (h₂ : loopRun prog f₂ base i v tape = some r₂) : r₁ = r₂ := by
  have e₁ := loopRun_fuel_mono prog (le_max_left f₁ f₂) base i v tape r₁ h₁
  have e₂ := loopRun_fuel_mono prog (le_max_right f₁ f₂) base i v tape r₂ h₂
  rw [e₁] at e₂
  exact Option.some.inj e₂

/-! ### Base shift (simultaneously for `eval` and `loopRun`) -/

/-- Helper: an equation `x = y.map f` of options from the two "success" implications. -/
theorem option_eq_map_of {α β : Type} {x : Option α} {y : Option β} {f : β → α}
    (h1 : ∀ r, y = some r → x = some (f r)) (h2 : ∀ r', x = some r' → ∃ r, y = some r) :
    x = y.map f := by
  cases hy : y with
  | none =>
    cases hx : x with
    | none => rfl
    | some r' =>
      obtain ⟨r, hr⟩ := h2 r' hx
      rw [hy] at hr
      exact absurd hr (by simp)
  | some r => simp [h1 r hy]

/-- Helper: the shift of a successful result. -/
theorem shift_some {o o' : Option (Val × ℕ × ℕ × List Bool)} {d : ℕ}
    (h : o' = o.map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) {v : Val} {c p : ℕ}
    {t : List Bool} (ho : o = some (v, c, p, t)) : o' = some (v, c, p + d, t) := by
  rw [h, ho]
  rfl

/-- Helper: un-shifting a successful result. -/
theorem shift_some_inv {o o' : Option (Val × ℕ × ℕ × List Bool)} {d : ℕ}
    (h : o' = o.map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) {v : Val} {c p' : ℕ}
    {t : List Bool} (ho' : o' = some (v, c, p', t)) : ∃ p, o = some (v, c, p, t) := by
  rw [h] at ho'
  obtain ⟨⟨v₀, c₀, p₀, t₀⟩, h₀, h₁⟩ := Option.map_eq_some_iff.mp ho'
  simp only [Prod.mk.injEq] at h₁
  obtain ⟨rfl, rfl, -, rfl⟩ := h₁
  exact ⟨p₀, h₀⟩

theorem base_shift_aux (prog : List Expr) (d n : ℕ) :
    (∀ base env tape e, eval prog n (base + d) env tape e =
      (eval prog n base env tape e).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) ∧
    (∀ base i v tape, loopRun prog n (base + d) i v tape =
      (loopRun prog n base i v tape).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) := by
  induction n with
  | zero => exact ⟨fun _ _ _ _ => by simp [eval], fun _ _ _ _ => by simp [loopRun]⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e
      apply option_eq_map_of
      · intro r hr
        cases e with
        | var i =>
          obtain ⟨v, hv, rfl⟩ := (eval_var_iff prog).mp hr
          exact (eval_var_iff prog).mpr ⟨v, hv, by
            simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
        | lit z =>
          rw [eval_lit_eq] at hr ⊢
          rw [← Option.some.inj hr]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | nil =>
          rw [eval_nil_eq] at hr ⊢
          rw [← Option.some.inj hr]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | coin =>
          obtain ⟨b, rest, rfl, rfl⟩ := (eval_coin_iff prog).mp hr
          rw [eval_coin_cons]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | bin op a b =>
          obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ :=
            (eval_bin_iff prog).mp hr
          refine (eval_bin_iff prog).mpr ⟨va, ca, pa + d, ta, vb, cb, pb + d, tb, v, c,
            shift_some (ihe _ _ _ _) ha, ?_, hv, ?_⟩
          · rw [Nat.add_right_comm]; exact shift_some (ihe _ _ _ _) hb
          · simp only [Prod.mk.injEq, true_and, and_true]; omega
        | un op a =>
          obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := (eval_un_iff prog).mp hr
          refine (eval_un_iff prog).mpr ⟨va, ca, pa + d, ta, v, c,
            shift_some (ihe _ _ _ _) ha, hv, ?_⟩
          simp only [Prod.mk.injEq, true_and, and_true]; omega
        | ite c t f =>
          obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := (eval_ite_iff prog).mp hr
          exact (eval_ite_iff prog).mpr ⟨z, cc, pc + d, tc, v, cv, pv + d, tv,
            shift_some (ihe _ _ _ _) hc, shift_some (ihe _ _ _ _) hv,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
        | letE a b =>
          obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := (eval_letE_iff prog).mp hr
          refine (eval_letE_iff prog).mpr ⟨va, ca, pa + d, ta, vb, cb, pb + d, tb,
            shift_some (ihe _ _ _ _) ha, ?_,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
          rw [Nat.add_right_comm]; exact shift_some (ihe _ _ _ _) hb
        | call i a =>
          obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩ :=
            (eval_call_iff prog).mp hr
          refine (eval_call_iff prog).mpr
            ⟨va, ca, pa + d, ta, body, vb, cb, pb + d, tb, shift_some (ihe _ _ _ _) ha, hbody, ?_,
              by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
          rw [Nat.add_right_comm]; exact shift_some (ihe _ _ _ _) hb
        | loop i a =>
          obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := (eval_loop_iff prog).mp hr
          exact (eval_loop_iff prog).mpr ⟨va, ca, pa + d, ta, w, cw, pw + d, tw,
            shift_some (ihe _ _ _ _) ha, shift_some (ihl _ _ _ _) hl,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
      · intro r' hr'
        cases e with
        | var i =>
          obtain ⟨v, hv, rfl⟩ := (eval_var_iff prog).mp hr'
          exact ⟨_, (eval_var_iff prog).mpr ⟨v, hv, rfl⟩⟩
        | lit z => exact ⟨_, eval_lit_eq prog n base env tape z⟩
        | nil => exact ⟨_, eval_nil_eq prog n base env tape⟩
        | coin =>
          obtain ⟨b, rest, rfl, rfl⟩ := (eval_coin_iff prog).mp hr'
          exact ⟨_, eval_coin_cons prog n base env b rest⟩
        | bin op a b =>
          obtain ⟨va, ca, pa', ta, vb, cb, pb', tb, v, c, ha, hb, hv, rfl⟩ :=
            (eval_bin_iff prog).mp hr'
          obtain ⟨pa, ha⟩ := shift_some_inv (ihe _ _ _ _) ha
          rw [Nat.add_right_comm] at hb
          obtain ⟨pb, hb⟩ := shift_some_inv (ihe _ _ _ _) hb
          exact ⟨_, (eval_bin_iff prog).mpr ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩⟩
        | un op a =>
          obtain ⟨va, ca, pa', ta, v, c, ha, hv, rfl⟩ := (eval_un_iff prog).mp hr'
          obtain ⟨pa, ha⟩ := shift_some_inv (ihe _ _ _ _) ha
          exact ⟨_, (eval_un_iff prog).mpr ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩⟩
        | ite c t f =>
          obtain ⟨z, cc, pc', tc, v, cv, pv', tv, hc, hv, rfl⟩ := (eval_ite_iff prog).mp hr'
          obtain ⟨pc, hc⟩ := shift_some_inv (ihe _ _ _ _) hc
          obtain ⟨pv, hv⟩ := shift_some_inv (ihe _ _ _ _) hv
          exact ⟨_, (eval_ite_iff prog).mpr ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩⟩
        | letE a b =>
          obtain ⟨va, ca, pa', ta, vb, cb, pb', tb, ha, hb, rfl⟩ := (eval_letE_iff prog).mp hr'
          obtain ⟨pa, ha⟩ := shift_some_inv (ihe _ _ _ _) ha
          rw [Nat.add_right_comm] at hb
          obtain ⟨pb, hb⟩ := shift_some_inv (ihe _ _ _ _) hb
          exact ⟨_, (eval_letE_iff prog).mpr ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩⟩
        | call i a =>
          obtain ⟨va, ca, pa', ta, body, vb, cb, pb', tb, ha, hbody, hb, rfl⟩ :=
            (eval_call_iff prog).mp hr'
          obtain ⟨pa, ha⟩ := shift_some_inv (ihe _ _ _ _) ha
          rw [Nat.add_right_comm] at hb
          obtain ⟨pb, hb⟩ := shift_some_inv (ihe _ _ _ _) hb
          exact ⟨_, (eval_call_iff prog).mpr
            ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩⟩
        | loop i a =>
          obtain ⟨va, ca, pa', ta, w, cw, pw', tw, ha, hl, rfl⟩ := (eval_loop_iff prog).mp hr'
          obtain ⟨pa, ha⟩ := shift_some_inv (ihe _ _ _ _) ha
          obtain ⟨pw, hl⟩ := shift_some_inv (ihl _ _ _ _) hl
          exact ⟨_, (eval_loop_iff prog).mpr ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩⟩
    · intro base i v tape
      apply option_eq_map_of
      · intro r hr
        obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := (loopRun_succ_iff prog).mp hr
        have hb' : eval prog n (base + d + valSize v) [v] tape body =
            some (Val.list [Val.int flag, v'], cb, pb + d, tb) := by
          rw [Nat.add_right_comm]; exact shift_some (ihe _ _ _ _) hb
        rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
        · exact (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb + d, tb, hbody, hb',
            Or.inl ⟨hflag, rfl⟩⟩
        · exact (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb + d, tb, hbody, hb',
            Or.inr ⟨hflag, w, cw, pw + d, tw, shift_some (ihl _ _ _ _) hw,
              by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩⟩
      · intro r' hr'
        obtain ⟨body, flag, v', cb, pb', tb, hbody, hb, hrest⟩ := (loopRun_succ_iff prog).mp hr'
        rw [Nat.add_right_comm] at hb
        obtain ⟨pb, hb⟩ := shift_some_inv (ihe _ _ _ _) hb
        rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw', tw, hw, rfl⟩
        · exact ⟨_, (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inl ⟨hflag, rfl⟩⟩⟩
        · obtain ⟨pw, hw⟩ := shift_some_inv (ihl _ _ _ _) hw
          exact ⟨_, (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inr ⟨hflag, w, cw, pw, tw, hw, rfl⟩⟩⟩

/-- **Base shift.** Peaks shift with the base; values, costs and leftover tapes do not depend on
it. -/
theorem eval_base_shift (prog : List Expr) (fuel base d : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) :
    eval prog fuel (base + d) env tape e =
      (eval prog fuel base env tape e).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2)) :=
  (base_shift_aux prog d fuel).1 base env tape e

/-- Base shift for loop iterations. -/
theorem loopRun_base_shift (prog : List Expr) (fuel base d i : ℕ) (v : Val) (tape : List Bool) :
    loopRun prog fuel (base + d) i v tape =
      (loopRun prog fuel base i v tape).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2)) :=
  (base_shift_aux prog d fuel).2 base i v tape

/-! ### Peak and cost bounds -/

/-- Helper: size of a loop-body result `[flag, v']`. -/
theorem valSize_flag_pair (flag : ℤ) (v' : Val) :
    valSize (Val.list [Val.int flag, v']) = bitLen flag + valSize v' + 4 := by
  simp only [valSize, listSize]
  omega

theorem peak_ge_aux (prog : List Expr) (n : ℕ) :
    (∀ base env tape e r, eval prog n base env tape e = some r →
      base + valSize r.1 ≤ r.2.2.1) ∧
    (∀ base i v tape r, loopRun prog n base i v tape = some r →
      base + valSize v ≤ r.2.2.1 ∧ base + valSize r.1 ≤ r.2.2.1) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ h => by simp [eval] at h, fun _ _ _ _ _ h => by simp [loopRun] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e r hr
      cases e with
      | var i =>
        obtain ⟨v, -, rfl⟩ := (eval_var_iff prog).mp hr
        exact le_refl _
      | lit z =>
        rw [eval_lit_eq] at hr
        rw [← Option.some.inj hr]
      | nil =>
        rw [eval_nil_eq] at hr
        rw [← Option.some.inj hr]
      | coin =>
        obtain ⟨b, rest, -, rfl⟩ := (eval_coin_iff prog).mp hr
        exact le_refl _
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, -, -, -, rfl⟩ := (eval_bin_iff prog).mp hr
        exact le_max_of_le_right (by dsimp only; omega)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v, c, -, -, rfl⟩ := (eval_un_iff prog).mp hr
        exact le_max_of_le_right (by dsimp only; omega)
      | ite c t f =>
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, -, hv, rfl⟩ := (eval_ite_iff prog).mp hr
        exact le_max_of_le_right (ihe _ _ _ _ _ hv)
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, -, hb, rfl⟩ := (eval_letE_iff prog).mp hr
        have := ihe _ _ _ _ _ hb
        exact le_max_of_le_right (by simp only at this ⊢; omega)
      | call i a =>
        obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, -, -, hb, rfl⟩ := (eval_call_iff prog).mp hr
        have := ihe _ _ _ _ _ hb
        exact le_max_of_le_right (by simp only at this ⊢; omega)
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, -, hl, rfl⟩ := (eval_loop_iff prog).mp hr
        exact le_max_of_le_right (ihl _ _ _ _ _ hl).2
    · intro base i v tape r hr
      obtain ⟨body, flag, v', cb, pb, tb, -, hb, hrest⟩ := (loopRun_succ_iff prog).mp hr
      have hpb := ihe _ _ _ _ _ hb
      simp only [valSize_flag_pair] at hpb
      rcases hrest with ⟨-, rfl⟩ | ⟨-, w, cw, pw, tw, hw, rfl⟩
      · constructor <;> (dsimp only; omega)
      · have := (ihl _ _ _ _ _ hw).2
        constructor
        · exact le_max_of_le_left (by omega)
        · exact le_max_of_le_right this

/-- The peak is at least the base plus the size of the produced value. -/
theorem eval_peak_ge (prog : List Expr) (fuel base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) (r : Val × ℕ × ℕ × List Bool) (hr : eval prog fuel base env tape e = some r) :
    base + valSize r.1 ≤ r.2.2.1 :=
  (peak_ge_aux prog fuel).1 base env tape e r hr

/-- The initial accumulator and the result of loop iterations are both live at some point. -/
theorem loopRun_peak_ge (prog : List Expr) (fuel base i : ℕ) (v : Val) (tape : List Bool)
    (r : Val × ℕ × ℕ × List Bool) (hr : loopRun prog fuel base i v tape = some r) :
    base + valSize v ≤ r.2.2.1 ∧ base + valSize r.1 ≤ r.2.2.1 :=
  (peak_ge_aux prog fuel).2 base i v tape r hr

/-- Every evaluation step costs at least one unit. -/
theorem eval_cost_pos (prog : List Expr) (fuel base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) (r : Val × ℕ × ℕ × List Bool) (hr : eval prog fuel base env tape e = some r) :
    1 ≤ r.2.1 := by
  cases fuel with
  | zero => simp [eval] at hr
  | succ n =>
    cases e with
    | var i =>
      obtain ⟨v, -, rfl⟩ := (eval_var_iff prog).mp hr
      exact le_refl _
    | lit z =>
      rw [eval_lit_eq] at hr
      rw [← Option.some.inj hr]
      dsimp only; omega
    | nil =>
      rw [eval_nil_eq] at hr
      rw [← Option.some.inj hr]
    | coin =>
      obtain ⟨b, rest, -, rfl⟩ := (eval_coin_iff prog).mp hr
      exact le_refl _
    | bin op a b =>
      obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, -, -, -, rfl⟩ := (eval_bin_iff prog).mp hr
      dsimp only; omega
    | un op a =>
      obtain ⟨va, ca, pa, ta, v, c, -, -, rfl⟩ := (eval_un_iff prog).mp hr
      dsimp only; omega
    | ite c t f =>
      obtain ⟨z, cc, pc, tc, v, cv, pv, tv, -, -, rfl⟩ := (eval_ite_iff prog).mp hr
      dsimp only; omega
    | letE a b =>
      obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, -, -, rfl⟩ := (eval_letE_iff prog).mp hr
      dsimp only; omega
    | call i a =>
      obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, -, -, -, rfl⟩ := (eval_call_iff prog).mp hr
      dsimp only; omega
    | loop i a =>
      obtain ⟨va, ca, pa, ta, w, cw, pw, tw, -, -, rfl⟩ := (eval_loop_iff prog).mp hr
      dsimp only; omega

/-- Every loop iteration costs at least one unit. -/
theorem loopRun_cost_pos (prog : List Expr) (fuel base i : ℕ) (v : Val) (tape : List Bool)
    (r : Val × ℕ × ℕ × List Bool) (hr : loopRun prog fuel base i v tape = some r) :
    1 ≤ r.2.1 := by
  cases fuel with
  | zero => simp [loopRun] at hr
  | succ n =>
    obtain ⟨body, flag, v', cb, pb, tb, -, -, ⟨-, rfl⟩ | ⟨-, w, cw, pw, tw, -, rfl⟩⟩ :=
      (loopRun_succ_iff prog).mp hr
    · dsimp only; omega
    · dsimp only; omega

/-! ### Tape frame lemmas (simultaneously for `eval` and `loopRun`) -/

theorem tape_aux (prog : List Expr) (n : ℕ) :
    (∀ base env tape e r, eval prog n base env tape e = some r →
      ∃ pre, tape = pre ++ r.2.2.2 ∧
        ∀ s, eval prog n base env (pre ++ s) e = some (r.1, r.2.1, r.2.2.1, s)) ∧
    (∀ base i v tape r, loopRun prog n base i v tape = some r →
      ∃ pre, tape = pre ++ r.2.2.2 ∧
        ∀ s, loopRun prog n base i v (pre ++ s) = some (r.1, r.2.1, r.2.2.1, s)) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ h => by simp [eval] at h, fun _ _ _ _ _ h => by simp [loopRun] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e r hr
      cases e with
      | var i =>
        obtain ⟨v, hv, rfl⟩ := (eval_var_iff prog).mp hr
        exact ⟨[], rfl, fun s => (eval_var_iff prog).mpr ⟨v, hv, rfl⟩⟩
      | lit z =>
        rw [eval_lit_eq] at hr
        cases hr
        exact ⟨[], rfl, fun s => eval_lit_eq prog n base env s z⟩
      | nil =>
        rw [eval_nil_eq] at hr
        cases hr
        exact ⟨[], rfl, fun s => eval_nil_eq prog n base env s⟩
      | coin =>
        obtain ⟨b, rest, rfl, rfl⟩ := (eval_coin_iff prog).mp hr
        exact ⟨[b], rfl, fun s => eval_coin_cons prog n base env b s⟩
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ :=
          (eval_bin_iff prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hqa hqb hfa hfb ⊢
        refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
          (eval_bin_iff prog).mpr ⟨va, ca, pa, qb ++ s, vb, cb, pb, s, v, c, ?_, hfb s, hv, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (qb ++ s)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := (eval_un_iff prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        dsimp only at hqa hfa ⊢
        exact ⟨qa, hqa, fun s => (eval_un_iff prog).mpr ⟨va, ca, pa, s, v, c, hfa s, hv, rfl⟩⟩
      | ite c t f =>
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := (eval_ite_iff prog).mp hr
        obtain ⟨qc, hqc, hfc⟩ := ihe _ _ _ _ _ hc
        obtain ⟨qv, hqv, hfv⟩ := ihe _ _ _ _ _ hv
        dsimp only at hqc hqv hfc hfv ⊢
        refine ⟨qc ++ qv, by rw [hqc, hqv, List.append_assoc], fun s =>
          (eval_ite_iff prog).mpr ⟨z, cc, pc, qv ++ s, v, cv, pv, s, ?_, hfv s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfc (qv ++ s)
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := (eval_letE_iff prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hqa hqb hfa hfb ⊢
        refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
          (eval_letE_iff prog).mpr ⟨va, ca, pa, qb ++ s, vb, cb, pb, s, ?_, hfb s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (qb ++ s)
      | call i a =>
        obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩ :=
          (eval_call_iff prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hqa hqb hfa hfb ⊢
        refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
          (eval_call_iff prog).mpr ⟨va, ca, pa, qb ++ s, body, vb, cb, pb, s, ?_, hbody, hfb s,
            rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (qb ++ s)
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := (eval_loop_iff prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨ql, hql, hfl⟩ := ihl _ _ _ _ _ hl
        dsimp only at hqa hql hfa hfl ⊢
        refine ⟨qa ++ ql, by rw [hqa, hql, List.append_assoc], fun s =>
          (eval_loop_iff prog).mpr ⟨va, ca, pa, ql ++ s, w, cw, pw, s, ?_, hfl s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (ql ++ s)
    · intro base i v tape r hr
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := (loopRun_succ_iff prog).mp hr
      obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
      dsimp only at hqb hfb
      rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
      · exact ⟨qb, hqb, fun s => (loopRun_succ_iff prog).mpr
          ⟨body, flag, v', cb, pb, s, hbody, hfb s, Or.inl ⟨hflag, rfl⟩⟩⟩
      · obtain ⟨qw, hqw, hfw⟩ := ihl _ _ _ _ _ hw
        dsimp only at hqw hfw ⊢
        refine ⟨qb ++ qw, by rw [hqb, hqw, List.append_assoc], fun s =>
          (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb, qw ++ s, hbody, ?_,
            Or.inr ⟨hflag, w, cw, pw, s, hfw s, rfl⟩⟩⟩
        rw [List.append_assoc]
        exact hfb (qw ++ s)

section TapeFrame
variable (prog : List Expr) {fuel base : ℕ} {env : List Val} {e : Expr} {v : Val} {c p : ℕ}

/-- **Tape frame.** A run on `tape` leaving `t'` consumed a prefix `pre` (`tape = pre ++ t'`), and
for every `r` the run on `pre ++ r` is identical and leaves `r`. -/
theorem eval_tape_frame {tape t' : List Bool}
    (h : eval prog fuel base env tape e = some (v, c, p, t')) :
    ∃ pre, tape = pre ++ t' ∧ ∀ r, eval prog fuel base env (pre ++ r) e = some (v, c, p, r) :=
  (tape_aux prog fuel).1 base env tape e _ h

/-- The leftover tape is a suffix of the input tape. -/
theorem eval_tape_suffix {tape t' : List Bool}
    (h : eval prog fuel base env tape e = some (v, c, p, t')) : t' <:+ tape := by
  obtain ⟨pre, htape, -⟩ := eval_tape_frame prog h
  exact ⟨pre, htape.symm⟩

/-- A run on `pre ++ t` leaving `t` gives, for every `r`, the same run on `pre ++ r`, leaving `r`. -/
theorem eval_tape_append {pre t : List Bool}
    (h : eval prog fuel base env (pre ++ t) e = some (v, c, p, t)) (r : List Bool) :
    eval prog fuel base env (pre ++ r) e = some (v, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := eval_tape_frame prog h
  rw [List.append_cancel_right htape]
  exact hf r

/-- A run on `pre` leaving the empty tape gives, for every `r`, the same run on `pre ++ r`,
leaving `r`. -/
theorem eval_tape_append_nil {pre : List Bool}
    (h : eval prog fuel base env pre e = some (v, c, p, [])) (r : List Bool) :
    eval prog fuel base env (pre ++ r) e = some (v, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := eval_tape_frame prog h
  rw [List.append_nil] at htape
  rw [htape]
  exact hf r

/-- A run that consumes nothing runs identically on every tape (leaving it untouched). -/
theorem eval_tape_indep {t : List Bool} (h : eval prog fuel base env t e = some (v, c, p, t))
    (r : List Bool) : eval prog fuel base env r e = some (v, c, p, r) :=
  eval_tape_append prog (pre := []) h r

/-- A run on the empty tape consumes nothing, hence runs identically on every tape. -/
theorem eval_tape_nil {t' : List Bool} (h : eval prog fuel base env [] e = some (v, c, p, t')) :
    t' = [] ∧ ∀ r, eval prog fuel base env r e = some (v, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := eval_tape_frame prog h
  have h1 : pre = [] ∧ t' = [] := List.append_eq_nil_iff.mp htape.symm
  obtain ⟨rfl, rfl⟩ := h1
  exact ⟨rfl, hf⟩

/-- **Bounded reading.** A run on `l ++ r` that reads at most `|l|` bits (its leftover is at least
as long as `r`) leaves `l₂ ++ r` for a suffix `l₂` of `l`, and is unchanged (leaving `l₂ ++ r'`)
when `r` is replaced by any `r'`. -/
theorem eval_tape_prefix {l r t' : List Bool}
    (h : eval prog fuel base env (l ++ r) e = some (v, c, p, t')) (hlen : r.length ≤ t'.length) :
    ∃ l₂, l₂ <:+ l ∧ t' = l₂ ++ r ∧
      ∀ r', eval prog fuel base env (l ++ r') e = some (v, c, p, l₂ ++ r') := by
  obtain ⟨pre, htape, hf⟩ := eval_tape_frame prog h
  rcases List.append_eq_append_iff.mp htape with ⟨a', hpre, hr⟩ | ⟨c', hl, ht'⟩
  · -- `pre = l ++ a'`, `r = a' ++ t'`: then `a' = []`
    have ha : a' = [] := by
      have := congrArg List.length hr
      simp only [List.length_append] at this
      exact List.eq_nil_of_length_eq_zero (by omega)
    subst ha
    simp only [List.append_nil, List.nil_append] at hpre hr
    subst hpre hr
    exact ⟨[], List.nil_suffix, rfl, fun r' => hf r'⟩
  · -- `l = pre ++ c'`, `t' = c' ++ r`
    refine ⟨c', ⟨pre, hl.symm⟩, ht', fun r' => ?_⟩
    rw [hl, List.append_assoc]
    exact hf (c' ++ r')

/-- The leftover tape is `tape.drop k` for the number `k = |tape| - |t'|` of consumed bits, and
the consumed bits are `tape.take k`. -/
theorem eval_tape_drop {tape t' : List Bool}
    (h : eval prog fuel base env tape e = some (v, c, p, t')) :
    t' = tape.drop (tape.length - t'.length) ∧
      ∀ r, eval prog fuel base env (tape.take (tape.length - t'.length) ++ r) e =
        some (v, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := eval_tape_frame prog h
  have hk : tape.length - t'.length = pre.length := by
    rw [htape, List.length_append]; omega
  rw [hk]
  refine ⟨?_, ?_⟩
  · rw [htape, List.drop_left]
  · rw [htape, List.take_left]
    exact hf

end TapeFrame

section LoopTapeFrame
variable (prog : List Expr) {fuel base i : ℕ} {v w : Val} {c p : ℕ}

/-- **Tape frame for loop iterations.** -/
theorem loopRun_tape_frame {tape t' : List Bool}
    (h : loopRun prog fuel base i v tape = some (w, c, p, t')) :
    ∃ pre, tape = pre ++ t' ∧ ∀ r, loopRun prog fuel base i v (pre ++ r) = some (w, c, p, r) :=
  (tape_aux prog fuel).2 base i v tape _ h

theorem loopRun_tape_suffix {tape t' : List Bool}
    (h : loopRun prog fuel base i v tape = some (w, c, p, t')) : t' <:+ tape := by
  obtain ⟨pre, htape, -⟩ := loopRun_tape_frame prog h
  exact ⟨pre, htape.symm⟩

theorem loopRun_tape_append {pre t : List Bool}
    (h : loopRun prog fuel base i v (pre ++ t) = some (w, c, p, t)) (r : List Bool) :
    loopRun prog fuel base i v (pre ++ r) = some (w, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := loopRun_tape_frame prog h
  rw [List.append_cancel_right htape]
  exact hf r

theorem loopRun_tape_append_nil {pre : List Bool}
    (h : loopRun prog fuel base i v pre = some (w, c, p, [])) (r : List Bool) :
    loopRun prog fuel base i v (pre ++ r) = some (w, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := loopRun_tape_frame prog h
  rw [List.append_nil] at htape
  rw [htape]
  exact hf r

theorem loopRun_tape_indep {t : List Bool}
    (h : loopRun prog fuel base i v t = some (w, c, p, t)) (r : List Bool) :
    loopRun prog fuel base i v r = some (w, c, p, r) :=
  loopRun_tape_append prog (pre := []) h r

theorem loopRun_tape_nil {t' : List Bool}
    (h : loopRun prog fuel base i v [] = some (w, c, p, t')) :
    t' = [] ∧ ∀ r, loopRun prog fuel base i v r = some (w, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := loopRun_tape_frame prog h
  have h1 : pre = [] ∧ t' = [] := List.append_eq_nil_iff.mp htape.symm
  obtain ⟨rfl, rfl⟩ := h1
  exact ⟨rfl, hf⟩

end LoopTapeFrame

/-! ### `RunsOn` -/

/-- `RunsOn` determines its output (for a fixed tape). -/
theorem runsOn_out_unique {prog : List Expr} {input : Val} {tape : List Bool} {o₁ o₂ : Val}
    {S₁ S₂ : ℝ} (h₁ : RunsOn prog input tape o₁ S₁) (h₂ : RunsOn prog input tape o₂ S₂) :
    o₁ = o₂ := by
  obtain ⟨body₁, f₁, c₁, p₁, r₁, hb₁, he₁, -⟩ := h₁
  obtain ⟨body₂, f₂, c₂, p₂, r₂, hb₂, he₂, -⟩ := h₂
  rw [hb₁] at hb₂
  cases Option.some.inj hb₂
  have := eval_det prog _ _ _ _ he₁ he₂
  simp only [Prod.mk.injEq] at this
  exact this.1

/-- `RunsOn` is monotone in the space bound. -/
theorem runsOn_mono {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S S' : ℝ}
    (hS : S ≤ S') (h : RunsOn prog input tape out S) : RunsOn prog input tape out S' := by
  obtain ⟨body, fuel, cost, peak, rest, hb, he, hp⟩ := h
  exact ⟨body, fuel, cost, peak, rest, hb, he, hp.trans hS⟩

/-- **Tape frame for `RunsOn`.** A run consumes a prefix `pre` of its tape, and runs identically
on every tape extending `pre`. -/
theorem runsOn_tape_frame {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S : ℝ}
    (h : RunsOn prog input tape out S) :
    ∃ pre, pre <+: tape ∧ ∀ r, RunsOn prog input (pre ++ r) out S := by
  obtain ⟨body, fuel, cost, peak, rest, hb, he, hp⟩ := h
  obtain ⟨pre, htape, hf⟩ := eval_tape_frame prog he
  exact ⟨pre, ⟨rest, htape.symm⟩, fun r => ⟨body, fuel, cost, peak, r, hb, hf r, hp⟩⟩

/-! ### Size lemmas -/

@[simp] theorem valSize_int (z : ℤ) : valSize (Val.int z) = bitLen z + 1 := by
  simp [valSize]

@[simp] theorem valSize_list (l : List Val) : valSize (Val.list l) = 1 + listSize l := by
  simp [valSize]

@[simp] theorem listSize_nil : listSize [] = 0 := by
  simp [listSize]

@[simp] theorem listSize_cons (v : Val) (l : List Val) :
    listSize (v :: l) = valSize v + 1 + listSize l := by
  simp [listSize]

theorem valSize_pos (v : Val) : 1 ≤ valSize v := by
  cases v <;> simp

theorem listSize_append (l₁ l₂ : List Val) :
    listSize (l₁ ++ l₂) = listSize l₁ + listSize l₂ := by
  induction l₁ with
  | nil => simp
  | cons v l ih => simp [ih]; omega

theorem length_le_listSize (l : List Val) : 2 * l.length ≤ listSize l := by
  induction l with
  | nil => simp
  | cons v l ih => have := valSize_pos v; simp; omega

@[simp] theorem bitLen_zero : bitLen 0 = 0 := rfl

@[simp] theorem bitLen_one : bitLen 1 = 1 := rfl

@[simp] theorem bitLen_neg (z : ℤ) : bitLen (-z) = bitLen z := by
  simp [bitLen]

theorem bitLen_natCast (n : ℕ) : bitLen (n : ℤ) = Nat.size n := by
  simp [bitLen]

theorem bitLen_le_bitLen_of_natAbs_le {a b : ℤ} (h : a.natAbs ≤ b.natAbs) :
    bitLen a ≤ bitLen b :=
  Nat.size_le_size h

theorem bitLen_add_le (a b : ℤ) : bitLen (a + b) ≤ max (bitLen a) (bitLen b) + 1 := by
  unfold bitLen
  rw [Nat.size_le]
  have ha := Nat.lt_size_self a.natAbs
  have hb := Nat.lt_size_self b.natAbs
  have hab : (a + b).natAbs ≤ a.natAbs + b.natAbs := Int.natAbs_add_le a b
  have h1 : 2 ^ Nat.size a.natAbs ≤ 2 ^ max (Nat.size a.natAbs) (Nat.size b.natAbs) :=
    Nat.pow_le_pow_right (by norm_num) (le_max_left _ _)
  have h2 : 2 ^ Nat.size b.natAbs ≤ 2 ^ max (Nat.size a.natAbs) (Nat.size b.natAbs) :=
    Nat.pow_le_pow_right (by norm_num) (le_max_right _ _)
  rw [pow_succ]
  omega

theorem bitLen_le_of_abs_lt {z : ℤ} {k : ℕ} (h : |z| < 2 ^ k) : bitLen z ≤ k := by
  unfold bitLen
  rw [Nat.size_le]
  have h' : ((z.natAbs : ℕ) : ℤ) < ((2 ^ k : ℕ) : ℤ) := by
    rw [Int.natCast_natAbs]
    exact_mod_cast h
  exact_mod_cast h'

/-- Helper: size of the cells of an encoded integer list. -/
theorem listSize_map_int (l : List ℤ) :
    listSize (l.map Val.int) = (l.map (fun z => bitLen z + 2)).sum := by
  induction l with
  | nil => simp
  | cons z l ih =>
    simp only [List.map_cons, listSize, valSize, List.sum_cons, ih]

/-- Size of an encoded integer list. -/
theorem valSize_encInts (l : List ℤ) :
    valSize (encInts l) = 1 + (l.map (fun z => bitLen z + 2)).sum := by
  simp only [encInts, valSize, listSize_map_int]

end F2e2e.Cost
