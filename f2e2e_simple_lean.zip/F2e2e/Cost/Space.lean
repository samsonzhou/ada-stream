import F2e2e.Cost.Calculus

/-!
# Space-only judgments (no time bookkeeping)

Theorem (C) bounds only space (`RunsOn` has no time clause), so new DSL code may skip the time
bounds of `EvalsLeT`/`EvalsLe`. This file provides the space-only judgments

* `EvalsSpT prog base env bits e v S := ∃ C, EvalsLeT prog base env bits e v C S` (consuming exactly the
  fresh bits `bits`), `EvalsSp prog base env e v S := ∃ C, EvalsLe prog base env e v C S`
  (deterministic);
* `LoopSpT` / `LoopSp` for loop iterations;

with one rule per constructor (`EvalsSpT.var`, …, `EvalsSpT.coin`, …), the primitive rules for the
deterministic judgment (`EvalsSp.add`, …), the loop rules `LoopSpT.of_measure` / `LoopSp.of_measure`
(termination by a decreasing measure, uniform peak bound; no cost potential), the conversions
`EvalsLeT.toSp`, `EvalsLe.toSp`, `EvalsSp.toT`, and the `RunsOn` bridges `RunsOn_of_EvalsSpT`,
`RunsOn_of_EvalsSp`. Every timed spec of the library converts with `.toSp`.
-/

namespace F2e2e.Cost

/-- `e` evaluates to `v` within peak live space `S` (some time), consuming exactly the fresh bits
`bits`. -/
def EvalsSpT (prog : List Expr) (base : ℕ) (env : List Val) (bits : List Bool) (e : Expr) (v : Val)
    (S : ℕ) : Prop :=
  ∃ C, EvalsLeT prog base env bits e v C S

/-- Deterministic: `e` evaluates to `v` within peak live space `S`, consuming no fresh bits. -/
def EvalsSp (prog : List Expr) (base : ℕ) (env : List Val) (e : Expr) (v : Val) (S : ℕ) : Prop :=
  ∃ C, EvalsLe prog base env e v C S

/-- Loop iterations within peak space `S`, consuming exactly the fresh bits `bits`. -/
def LoopSpT (prog : List Expr) (base i : ℕ) (v : Val) (bits : List Bool) (w : Val) (S : ℕ) :
    Prop :=
  ∃ C, LoopLeT prog base i v bits w C S

/-- Deterministic loop iterations within peak space `S`. -/
def LoopSp (prog : List Expr) (base i : ℕ) (v w : Val) (S : ℕ) : Prop :=
  ∃ C, LoopLe prog base i v w C S

theorem EvalsLeT.toSp {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} {C S : ℕ} (h : EvalsLeT prog base env bits e v C S) :
    EvalsSpT prog base env bits e v S :=
  ⟨C, h⟩

theorem EvalsLe.toSp {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {C S : ℕ} (h : EvalsLe prog base env e v C S) : EvalsSp prog base env e v S :=
  ⟨C, h⟩

theorem EvalsSp.toT {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSp prog base env e v S) : EvalsSpT prog base env [] e v S :=
  h

theorem EvalsSpT.toDet {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSpT prog base env [] e v S) : EvalsSp prog base env e v S :=
  h

theorem LoopLeT.toSp {prog : List Expr} {base i : ℕ} {v w : Val} {bits : List Bool} {C S : ℕ}
    (h : LoopLeT prog base i v bits w C S) : LoopSpT prog base i v bits w S :=
  ⟨C, h⟩

theorem LoopLe.toSp {prog : List Expr} {base i : ℕ} {v w : Val} {C S : ℕ}
    (h : LoopLe prog base i v w C S) : LoopSp prog base i v w S :=
  ⟨C, h⟩

/-! ### `EvalsSpT` -/

namespace EvalsSpT

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem mono {bits : List Bool} {e : Expr} {v : Val} {S S' : ℕ}
    (h : EvalsSpT prog base env bits e v S) (hS : S ≤ S') : EvalsSpT prog base env bits e v S' := by
  obtain ⟨C, h⟩ := h
  exact ⟨C, h.mono (le_refl _) hS⟩

theorem cast_bits {bits bits' : List Bool} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSpT prog base env bits e v S) (hb : bits = bits') : EvalsSpT prog base env bits' e v S :=
  hb ▸ h

theorem peak_ge {bits : List Bool} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSpT prog base env bits e v S) : base + valSize v ≤ S := by
  obtain ⟨C, h⟩ := h
  exact h.peak_ge

theorem base_shift {bits : List Bool} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSpT prog base env bits e v S) (d : ℕ) : EvalsSpT prog (base + d) env bits e v (S + d) := by
  obtain ⟨C, h⟩ := h
  exact ⟨C, h.base_shift d⟩

theorem val_unique {bits : List Bool} {e : Expr} {v v' : Val} {S S' : ℕ}
    (h : EvalsSpT prog base env bits e v S) (h' : EvalsSpT prog base env bits e v' S') : v = v' := by
  obtain ⟨C, h⟩ := h
  obtain ⟨C', h'⟩ := h'
  exact h.val_unique h'

/-- **Tape frame.** Within the space bound, the evaluation runs on every tape extending the
consumed bits. -/
theorem eval_append {bits : List Bool} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSpT prog base env bits e v S) :
    ∃ fuel c p, p ≤ S ∧ ∀ r, eval prog fuel base env (bits ++ r) e = some (v, c, p, r) := by
  obtain ⟨C, h⟩ := h
  obtain ⟨fuel, c, p, -, hp, hf⟩ := h.eval_append
  exact ⟨fuel, c, p, hp, hf⟩

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsSpT prog base env [] (Expr.var i) v (base + valSize v) :=
  (EvalsLeT.var h).toSp

theorem lit (z : ℤ) :
    EvalsSpT prog base env [] (Expr.lit z) (Val.int z) (base + valSize (Val.int z)) :=
  (EvalsLeT.lit z).toSp

theorem nil : EvalsSpT prog base env [] Expr.nil (Val.list []) (base + valSize (Val.list [])) :=
  EvalsLeT.nil.toSp

/-- `coin` consumes one fresh bit `b` and returns `encB b`. -/
theorem coin (b : Bool) : EvalsSpT prog base env [b] Expr.coin (encB b) (base + valSize (encB b)) :=
  (EvalsLeT.coin b).toSp

theorem bin {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {Sa Sb c : ℕ}
    (ha : EvalsSpT prog base env ba a va Sa) (hb : EvalsSpT prog (base + valSize va) env bb b vb Sb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsSpT prog base env (ba ++ bb) (Expr.bin op a b) v
      (max (max Sa Sb) (base + valSize va + valSize vb + valSize v)) := by
  obtain ⟨Ca, ha⟩ := ha
  obtain ⟨Cb, hb⟩ := hb
  exact (EvalsLeT.bin ha hb hop).toSp

theorem un {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {Sa c : ℕ}
    (ha : EvalsSpT prog base env ba a va Sa) (hop : evalUn op va = some (v, c)) :
    EvalsSpT prog base env ba (Expr.un op a) v (max Sa (base + valSize va + valSize v)) := by
  obtain ⟨Ca, ha⟩ := ha
  exact (EvalsLeT.un ha hop).toSp

theorem ite {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSpT prog base env bc c (Val.int z) Sc)
    (hv : EvalsSpT prog base env bv (if z ≠ 0 then t else f) v Sv) :
    EvalsSpT prog base env (bc ++ bv) (Expr.ite c t f) v (max Sc Sv) := by
  obtain ⟨Cc, hc⟩ := hc
  obtain ⟨Cv, hv⟩ := hv
  exact (EvalsLeT.ite hc hv).toSp

theorem ite_true {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSpT prog base env bc c (Val.int z) Sc) (hz : z ≠ 0)
    (ht : EvalsSpT prog base env bv t v Sv) :
    EvalsSpT prog base env (bc ++ bv) (Expr.ite c t f) v (max Sc Sv) :=
  ite hc (by rw [if_pos hz]; exact ht)

theorem ite_false {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSpT prog base env bc c (Val.int z) Sc) (hz : z = 0)
    (hf : EvalsSpT prog base env bv f v Sv) :
    EvalsSpT prog base env (bc ++ bv) (Expr.ite c t f) v (max Sc Sv) :=
  ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem letE {a b : Expr} {ba bb : List Bool} {va vb : Val} {Sa Sb : ℕ}
    (ha : EvalsSpT prog base env ba a va Sa)
    (hb : EvalsSpT prog (base + valSize va) (va :: env) bb b vb Sb) :
    EvalsSpT prog base env (ba ++ bb) (Expr.letE a b) vb (max Sa Sb) := by
  obtain ⟨Ca, ha⟩ := ha
  obtain ⟨Cb, hb⟩ := hb
  exact (EvalsLeT.letE ha hb).toSp

theorem call {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val} {Sa Sb : ℕ}
    (ha : EvalsSpT prog base env ba a va Sa) (hbody : prog[i]? = some body)
    (hb : EvalsSpT prog (base + valSize va) [va] bb body vb Sb) :
    EvalsSpT prog base env (ba ++ bb) (Expr.call i a) vb (max Sa Sb) := by
  obtain ⟨Ca, ha⟩ := ha
  obtain ⟨Cb, hb⟩ := hb
  exact (EvalsLeT.call ha hbody hb).toSp

theorem loop {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val} {Sa Sl : ℕ}
    (ha : EvalsSpT prog base env ba a va Sa) (hl : LoopSpT prog base i va bl w Sl) :
    EvalsSpT prog base env (ba ++ bl) (Expr.loop i a) w (max Sa Sl) := by
  obtain ⟨Ca, ha⟩ := ha
  obtain ⟨Cl, hl⟩ := hl
  exact (EvalsLeT.loop ha hl).toSp

end EvalsSpT

/-! ### `EvalsSp` (deterministic) -/

namespace EvalsSp

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem mono {e : Expr} {v : Val} {S S' : ℕ} (h : EvalsSp prog base env e v S) (hS : S ≤ S') :
    EvalsSp prog base env e v S' :=
  EvalsSpT.mono h hS

theorem peak_ge {e : Expr} {v : Val} {S : ℕ} (h : EvalsSp prog base env e v S) :
    base + valSize v ≤ S :=
  EvalsSpT.peak_ge h

theorem base_shift {e : Expr} {v : Val} {S : ℕ} (h : EvalsSp prog base env e v S) (d : ℕ) :
    EvalsSp prog (base + d) env e v (S + d) :=
  EvalsSpT.base_shift h d

theorem val_unique {e : Expr} {v v' : Val} {S S' : ℕ} (h : EvalsSp prog base env e v S)
    (h' : EvalsSp prog base env e v' S') : v = v' :=
  EvalsSpT.val_unique h h'

/-- A deterministic evaluation runs within the space bound on every tape, leaving it untouched. -/
theorem eval_tape {e : Expr} {v : Val} {S : ℕ} (h : EvalsSp prog base env e v S) :
    ∃ fuel c p, p ≤ S ∧ ∀ tape, eval prog fuel base env tape e = some (v, c, p, tape) :=
  EvalsSpT.eval_append h

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsSp prog base env (Expr.var i) v (base + valSize v) :=
  (EvalsLe.var h).toSp

theorem lit (z : ℤ) : EvalsSp prog base env (Expr.lit z) (Val.int z) (base + valSize (Val.int z)) :=
  (EvalsLe.lit z).toSp

theorem nil : EvalsSp prog base env Expr.nil (Val.list []) (base + valSize (Val.list [])) :=
  EvalsLe.nil.toSp

theorem bin {op : BinOp} {a b : Expr} {va vb v : Val} {Sa Sb c : ℕ}
    (ha : EvalsSp prog base env a va Sa) (hb : EvalsSp prog (base + valSize va) env b vb Sb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsSp prog base env (Expr.bin op a b) v
      (max (max Sa Sb) (base + valSize va + valSize vb + valSize v)) :=
  EvalsSpT.bin ha hb hop

theorem un {op : UnOp} {a : Expr} {va v : Val} {Sa c : ℕ}
    (ha : EvalsSp prog base env a va Sa) (hop : evalUn op va = some (v, c)) :
    EvalsSp prog base env (Expr.un op a) v (max Sa (base + valSize va + valSize v)) :=
  EvalsSpT.un ha hop

theorem ite {c t f : Expr} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSp prog base env c (Val.int z) Sc)
    (hv : EvalsSp prog base env (if z ≠ 0 then t else f) v Sv) :
    EvalsSp prog base env (Expr.ite c t f) v (max Sc Sv) :=
  EvalsSpT.ite hc hv

theorem ite_true {c t f : Expr} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSp prog base env c (Val.int z) Sc) (hz : z ≠ 0) (ht : EvalsSp prog base env t v Sv) :
    EvalsSp prog base env (Expr.ite c t f) v (max Sc Sv) :=
  EvalsSpT.ite_true hc hz ht

theorem ite_false {c t f : Expr} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSp prog base env c (Val.int z) Sc) (hz : z = 0) (hf : EvalsSp prog base env f v Sv) :
    EvalsSp prog base env (Expr.ite c t f) v (max Sc Sv) :=
  EvalsSpT.ite_false hc hz hf

theorem letE {a b : Expr} {va vb : Val} {Sa Sb : ℕ}
    (ha : EvalsSp prog base env a va Sa) (hb : EvalsSp prog (base + valSize va) (va :: env) b vb Sb) :
    EvalsSp prog base env (Expr.letE a b) vb (max Sa Sb) :=
  EvalsSpT.letE ha hb

theorem call {i : ℕ} {a body : Expr} {va vb : Val} {Sa Sb : ℕ}
    (ha : EvalsSp prog base env a va Sa) (hbody : prog[i]? = some body)
    (hb : EvalsSp prog (base + valSize va) [va] body vb Sb) :
    EvalsSp prog base env (Expr.call i a) vb (max Sa Sb) :=
  EvalsSpT.call ha hbody hb

theorem loop {i : ℕ} {a : Expr} {va w : Val} {Sa Sl : ℕ}
    (ha : EvalsSp prog base env a va Sa) (hl : LoopSp prog base i va w Sl) :
    EvalsSp prog base env (Expr.loop i a) w (max Sa Sl) :=
  EvalsSpT.loop ha hl

/-! #### Primitive operations -/

theorem add {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.add a b) (Val.int (x + y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x + y)))) :=
  bin ha hb rfl

theorem sub {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.sub a b) (Val.int (x - y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x - y)))) :=
  bin ha hb rfl

theorem mul {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.mul a b) (Val.int (x * y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x * y)))) :=
  bin ha hb rfl

theorem div {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) (hy : y ≠ 0) :
    EvalsSp prog base env (Expr.bin BinOp.div a b) (Val.int (x / y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x / y)))) :=
  bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy])

theorem mod {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) (hy : y ≠ 0) :
    EvalsSp prog base env (Expr.bin BinOp.mod a b) (Val.int (x % y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x % y)))) :=
  bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy])

theorem lt {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.lt a b) (Val.int (if x < y then 1 else 0))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x < y then 1 else 0)))) :=
  bin ha hb rfl

theorem eq {a b : Expr} {x y : ℤ} {Sa Sb : ℕ} (ha : EvalsSp prog base env a (Val.int x) Sa)
    (hb : EvalsSp prog (base + valSize (Val.int x)) env b (Val.int y) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.eq a b) (Val.int (if x = y then 1 else 0))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x = y then 1 else 0)))) :=
  bin ha hb rfl

theorem cons {a b : Expr} {x : Val} {l : List Val} {Sa Sb : ℕ} (ha : EvalsSp prog base env a x Sa)
    (hb : EvalsSp prog (base + valSize x) env b (Val.list l) Sb) :
    EvalsSp prog base env (Expr.bin BinOp.cons a b) (Val.list (x :: l))
      (max (max Sa Sb) (base + valSize x + valSize (Val.list l) + valSize (Val.list (x :: l)))) :=
  bin ha hb (by cases x <;> rfl)

theorem head {a : Expr} {x : Val} {l : List Val} {Sa : ℕ}
    (ha : EvalsSp prog base env a (Val.list (x :: l)) Sa) :
    EvalsSp prog base env (Expr.un UnOp.head a) x
      (max Sa (base + valSize (Val.list (x :: l)) + valSize x)) :=
  un ha rfl

theorem tail {a : Expr} {x : Val} {l : List Val} {Sa : ℕ}
    (ha : EvalsSp prog base env a (Val.list (x :: l)) Sa) :
    EvalsSp prog base env (Expr.un UnOp.tail a) (Val.list l)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.list l))) :=
  un ha rfl

theorem isNil_nil {a : Expr} {Sa : ℕ} (ha : EvalsSp prog base env a (Val.list []) Sa) :
    EvalsSp prog base env (Expr.un UnOp.isNil a) (Val.int 1)
      (max Sa (base + valSize (Val.list []) + valSize (Val.int 1))) :=
  un ha rfl

theorem isNil_cons {a : Expr} {x : Val} {l : List Val} {Sa : ℕ}
    (ha : EvalsSp prog base env a (Val.list (x :: l)) Sa) :
    EvalsSp prog base env (Expr.un UnOp.isNil a) (Val.int 0)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.int 0))) :=
  un ha rfl

end EvalsSp

/-! ### Loops -/

namespace LoopSpT

variable {prog : List Expr} {base i : ℕ}

theorem mono {v w : Val} {bits : List Bool} {S S' : ℕ} (h : LoopSpT prog base i v bits w S)
    (hS : S ≤ S') : LoopSpT prog base i v bits w S' := by
  obtain ⟨C, h⟩ := h
  exact ⟨C, h.mono (le_refl _) hS⟩

theorem cast_bits {v w : Val} {bits bits' : List Bool} {S : ℕ}
    (h : LoopSpT prog base i v bits w S) (hb : bits = bits') : LoopSpT prog base i v bits' w S :=
  hb ▸ h

theorem stop {body : Expr} {v v' : Val} {bits : List Bool} {Sb : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsSpT prog (base + valSize v) [v] bits body (Val.list [Val.int 0, v']) Sb) :
    LoopSpT prog base i v bits v' Sb := by
  obtain ⟨Cb, hb⟩ := hb
  exact (LoopLeT.stop hbody hb).toSp

theorem cont {body : Expr} {flag : ℤ} {v v' w : Val} {bb bw : List Bool} {Sb Sw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsSpT prog (base + valSize v) [v] bb body (Val.list [Val.int flag, v']) Sb)
    (hflag : flag ≠ 0) (hrest : LoopSpT prog base i v' bw w Sw) :
    LoopSpT prog base i v (bb ++ bw) w (max Sb Sw) := by
  obtain ⟨Cb, hb⟩ := hb
  obtain ⟨Cw, hw⟩ := hrest
  exact (LoopLeT.cont hbody hb hflag hw).toSp

/-- **Loop rule (measure, with fresh bits; space only).** Every iteration from a state `s`
satisfying `Inv` stays within peak `S` and either stops with an output satisfying `Post`,
consuming `bitsOf s`, or consumes a prefix `bs` with `bitsOf s = bs ++ bitsOf s'` and continues
to a state `s'` satisfying `Inv` with a smaller measure. Then the loop from `s` consumes
`bitsOf s` and returns an output satisfying `Post` within peak `S`. -/
theorem of_measure {σ : Type*} {body : Expr} {S : ℕ} (hbody : prog[i]? = some body)
    (enc : σ → Val) (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsSpT prog (base + valSize (enc s)) [enc s] (bitsOf s) body
          (Val.list [Val.int 0, out]) S ∧ Post out) ∨
      (∃ flag s' bs, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsSpT prog (base + valSize (enc s)) [enc s] bs body
            (Val.list [Val.int flag, enc s']) S ∧ Inv s' ∧ μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ LoopSpT prog base i (enc s) (bitsOf s) out S := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', bs, hflag, hbits, hb, hs', hlt⟩
    · exact ⟨out, hpost, stop hbody hb⟩
    · obtain ⟨out, hpost, hrest⟩ := ih (μ s') (by omega) s' rfl hs'
      rw [hbits]
      exact ⟨out, hpost, (cont hbody hb hflag hrest).mono (by simp)⟩

end LoopSpT

namespace LoopSp

variable {prog : List Expr} {base i : ℕ}

theorem mono {v w : Val} {S S' : ℕ} (h : LoopSp prog base i v w S) (hS : S ≤ S') :
    LoopSp prog base i v w S' :=
  LoopSpT.mono h hS

theorem stop {body : Expr} {v v' : Val} {Sb : ℕ} (hbody : prog[i]? = some body)
    (hb : EvalsSp prog (base + valSize v) [v] body (Val.list [Val.int 0, v']) Sb) :
    LoopSp prog base i v v' Sb :=
  LoopSpT.stop hbody hb

theorem cont {body : Expr} {flag : ℤ} {v v' w : Val} {Sb Sw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsSp prog (base + valSize v) [v] body (Val.list [Val.int flag, v']) Sb)
    (hflag : flag ≠ 0) (hrest : LoopSp prog base i v' w Sw) :
    LoopSp prog base i v w (max Sb Sw) :=
  LoopSpT.cont hbody hb hflag hrest

/-- **Loop rule (measure; space only, deterministic).** -/
theorem of_measure {σ : Type*} {body : Expr} {S : ℕ} (hbody : prog[i]? = some body)
    (enc : σ → Val) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsSp prog (base + valSize (enc s)) [enc s] body (Val.list [Val.int 0, out]) S ∧
          Post out) ∨
      (∃ flag s', flag ≠ 0 ∧ EvalsSp prog (base + valSize (enc s)) [enc s] body
          (Val.list [Val.int flag, enc s']) S ∧ Inv s' ∧ μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ LoopSp prog base i (enc s) out S :=
  LoopSpT.of_measure hbody enc (fun _ => []) Inv Post μ (fun s hs => by
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', hflag, hb, hs', hμ⟩
    · exact Or.inl ⟨out, hb, hpost⟩
    · exact Or.inr ⟨flag, s', [], hflag, rfl, hb, hs', hμ⟩)

end LoopSp

/-! ### `RunsOn` bridges -/

theorem RunsOn_of_EvalsSpT {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input out : Val} {bits : List Bool} {S : ℕ}
    (h : EvalsSpT prog (valSize input) [input] bits body out S) {Sbound : ℝ} (hS : (S : ℝ) ≤ Sbound)
    (rest : List Bool) : RunsOn prog input (bits ++ rest) out Sbound := by
  obtain ⟨C, h⟩ := h
  exact RunsOn_of_EvalsLeT h0 h hS rest

theorem RunsOn_of_EvalsSp {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input out : Val} {S : ℕ} (h : EvalsSp prog (valSize input) [input] body out S) {Sbound : ℝ}
    (hS : (S : ℝ) ≤ Sbound) (tape : List Bool) : RunsOn prog input tape out Sbound :=
  RunsOn_of_EvalsSpT h0 h hS tape

end F2e2e.Cost
