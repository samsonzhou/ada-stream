import F2e2e.Cost.MachineRun
import F2e2e.Cost.MachineBits

/-!
# Simulation of the big-step semantics by the machine, with the bit-space invariant

`sim prog n`: if Spec v1's `eval prog n base env tape e = some (v, c, pk, tape')` and `e` sits at the
code position `q`, then the machine goes from `⟨eval q env, K, tape⟩` to `⟨ret v, K, tape'⟩` (for every
stack `K`), and every configuration of that run has the form `⟨ctrl, F ++ K, _⟩` with
`|ctrl| + framesBits F ≤ simBound prog (height e) env (pk - base)`, where
`simBound prog h env δ = (h + 1)·(|bitEncodeVals env| + frameC prog) + bitsFactor prog · δ`.
The same for `loopRun` (iterations under a `loopIter` frame), proved simultaneously by induction on
the fuel, using the inversion lemmas of `F2e2e.Cost.Facts`.

Bookkeeping of the bound: a frame pushed by the current activation costs at most one copy of the
environment plus `frameC` (absorbed by the height factor, since the child has smaller height); a
saved left operand `va` costs at most `frameC + 3·valSize va` (absorbed by `bitsFactor·valSize va`,
because the right operand runs with base `base + valSize va`); a new activation (call or loop body
on `[v]`, or a `letE` extension of the environment) costs at most `(progDepth + 1)·(frameC + 5)·
valSize v = bitsFactor · valSize v`, paid by the big-step charge of `v`.
-/

namespace F2e2e.Machine

open F2e2e.Cost

variable {prog : List Expr}

/-! ## The invariant -/

/-- The configuration has stack `F ++ K`, and its control and the frames `F` take at most `B` bits. -/
def Within (prog : List Expr) (K : List Frame) (B : ℕ) (d : Conf) : Prop :=
  ∃ F, d.stack = F ++ K ∧ (encodeCtrl prog d.ctrl).length + framesBits prog F ≤ B

theorem Within.mono {K : List Frame} {B B' : ℕ} {d : Conf} (h : Within prog K B d) (hB : B ≤ B') :
    Within prog K B' d := by
  obtain ⟨F, hs, hb⟩ := h
  exact ⟨F, hs, hb.trans hB⟩

theorem Within.push {K : List Frame} {f : Frame} {B : ℕ} {d : Conf} (h : Within prog (f :: K) B d) :
    Within prog K (B + frameBits prog f) d := by
  obtain ⟨F, hs, hb⟩ := h
  refine ⟨F ++ [f], by rw [hs]; simp, ?_⟩
  rw [framesBits_append, framesBits_singleton]
  omega

theorem Within.top {K : List Frame} {B : ℕ} {c : Ctrl} {t : List Bool}
    (h : (encodeCtrl prog c).length ≤ B) : Within prog K B ⟨c, K, t⟩ :=
  ⟨[], by simp, by simpa [framesBits_nil] using h⟩

theorem RunAll.push {K : List Frame} {f : Frame} {B B' : ℕ} {c c' : Conf}
    (h : RunAll prog (Within prog (f :: K) B) c c') (hB : B + frameBits prog f ≤ B') :
    RunAll prog (Within prog K B') c c' :=
  h.mono fun _ hd => hd.push.mono hB

theorem RunAll.weaken {K : List Frame} {B B' : ℕ} {c c' : Conf}
    (h : RunAll prog (Within prog K B) c c') (hB : B ≤ B') :
    RunAll prog (Within prog K B') c c' :=
  h.mono fun _ hd => hd.mono hB

/-- The bound for simulating an expression of height `h` in `env` whose big-step peak exceeds its
base by `δ`. -/
def simBound (prog : List Expr) (h : ℕ) (env : List Val) (δ : ℕ) : ℕ :=
  (h + 1) * ((bitEncodeVals env).length + frameC prog) + bitsFactor prog * δ

/-! ## Arithmetic of the bound -/

theorem five_le_frameC (prog : List Expr) : 5 ≤ frameC prog := by
  unfold frameC; omega

theorem bitsFactor_ge (prog : List Expr) : (progDepth prog + 1) * (frameC prog + 5) ≤ bitsFactor prog :=
  le_rfl

theorem five_le_bitsFactor (prog : List Expr) : 5 ≤ bitsFactor prog := by
  unfold bitsFactor
  calc 5 ≤ frameC prog + 5 := by omega
    _ = 1 * (frameC prog + 5) := (one_mul _).symm
    _ ≤ (progDepth prog + 1) * (frameC prog + 5) := Nat.mul_le_mul_right _ (by omega)

theorem simBound_mono {h h' δ δ' : ℕ} (env : List Val) (hh : h ≤ h') (hδ : δ ≤ δ') :
    simBound prog h env δ ≤ simBound prog h' env δ' := by
  unfold simBound
  have h1 : (h + 1) * ((bitEncodeVals env).length + frameC prog) ≤
      (h' + 1) * ((bitEncodeVals env).length + frameC prog) :=
    Nat.mul_le_mul_right _ (by omega)
  have h2 := Nat.mul_le_mul_left (bitsFactor prog) hδ
  omega

/-- A frame of the current activation holding (at most) one copy of the environment. -/
theorem simBound_push_env {h ha δ δa : ℕ} (env : List Val) (hh : ha + 1 ≤ h) (hδ : δa ≤ δ)
    {fb : ℕ} (hfb : fb ≤ (bitEncodeVals env).length + frameC prog) :
    simBound prog ha env δa + fb ≤ simBound prog h env δ := by
  unfold simBound
  have h1 : (ha + 1) * ((bitEncodeVals env).length + frameC prog) +
      ((bitEncodeVals env).length + frameC prog) ≤
      (h + 1) * ((bitEncodeVals env).length + frameC prog) := by
    rw [← Nat.succ_mul]
    exact Nat.mul_le_mul_right _ (by omega)
  have h2 := Nat.mul_le_mul_left (bitsFactor prog) hδ
  omega

/-- A frame of the current activation holding a value `va` charged in the base of the child. -/
theorem simBound_push_val {h hb δ δb s : ℕ} (env : List Val) (hh : hb + 1 ≤ h) (hδ : δb + s ≤ δ)
    {fb : ℕ} (hfb : fb ≤ frameC prog + 3 * s) :
    simBound prog hb env δb + fb ≤ simBound prog h env δ := by
  unfold simBound
  have h1 : (hb + 1) * ((bitEncodeVals env).length + frameC prog) +
      ((bitEncodeVals env).length + frameC prog) ≤
      (h + 1) * ((bitEncodeVals env).length + frameC prog) := by
    rw [← Nat.succ_mul]
    exact Nat.mul_le_mul_right _ (by omega)
  have h2 : bitsFactor prog * δb + bitsFactor prog * s ≤ bitsFactor prog * δ := by
    rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ hδ
  have h3 : 3 * s ≤ bitsFactor prog * s := Nat.mul_le_mul_right s (by
    have := five_le_bitsFactor prog; omega)
  omega

/-- A new activation on `[v]` (call or loop body): its whole bound is paid by `bitsFactor · valSize v`. -/
theorem simBound_body {hb δb : ℕ} {v : Val} (hD : hb ≤ progDepth prog) :
    simBound prog hb [v] δb ≤ bitsFactor prog * (δb + valSize v) := by
  unfold simBound
  rw [bitEncodeVals_singleton_length]
  have hv := bitEncodeVal_length_le v
  have hpos := valSize_pos v
  set s := valSize v
  set D := progDepth prog
  set fc := frameC prog
  have h1 : (hb + 1) * ((bitEncodeVal v).length + 2 + fc) ≤ (D + 1) * (3 * s + 2 + fc) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h2 : (D + 1) * (3 * s + 2 + fc) ≤ (D + 1) * ((fc + 5) * s) := by
    apply Nat.mul_le_mul_left
    have : fc * 1 ≤ fc * s := Nat.mul_le_mul_left fc hpos
    nlinarith
  have h3 : (D + 1) * ((fc + 5) * s) = bitsFactor prog * s := by
    unfold bitsFactor; ring
  have h4 : bitsFactor prog * (δb + s) = bitsFactor prog * δb + bitsFactor prog * s := by ring
  rw [h4]
  omega

/-- A `letE` extension of the environment by `va`, charged in the base of the body. -/
theorem simBound_letE {h hb δ δb : ℕ} {va : Val} (env : List Val) (hh : hb + 1 ≤ h)
    (hD : hb ≤ progDepth prog) (hδ : δb + valSize va ≤ δ) :
    simBound prog hb (va :: env) δb ≤ simBound prog h env δ := by
  unfold simBound
  rw [bitEncodeVals_cons_length]
  have hv := bitEncodeVal_length_le va
  have hpos := valSize_pos va
  set s := valSize va
  set D := progDepth prog
  set fc := frameC prog
  set E := (bitEncodeVals env).length
  have h1 : (hb + 1) * ((bitEncodeVal va).length + E + 1 + fc) ≤
      (hb + 1) * (E + fc) + (D + 1) * (3 * s + 1) := by
    have h' : (hb + 1) * (3 * s + 1) ≤ (D + 1) * (3 * s + 1) := Nat.mul_le_mul_right _ (by omega)
    calc (hb + 1) * ((bitEncodeVal va).length + E + 1 + fc)
        ≤ (hb + 1) * ((E + fc) + (3 * s + 1)) := Nat.mul_le_mul_left _ (by omega)
      _ = (hb + 1) * (E + fc) + (hb + 1) * (3 * s + 1) := Nat.mul_add _ _ _
      _ ≤ (hb + 1) * (E + fc) + (D + 1) * (3 * s + 1) := Nat.add_le_add_left h' _
  have h2 : (D + 1) * (3 * s + 1) ≤ bitsFactor prog * s := by
    unfold bitsFactor
    have : (D + 1) * (3 * s + 1) ≤ (D + 1) * ((fc + 5) * s) := by
      apply Nat.mul_le_mul_left
      nlinarith
    calc (D + 1) * (3 * s + 1) ≤ (D + 1) * ((fc + 5) * s) := this
      _ = (D + 1) * (fc + 5) * s := by ring
  have h3 : (hb + 1) * (E + fc) ≤ h * (E + fc) := Nat.mul_le_mul_right _ hh
  have h4 : bitsFactor prog * δb + bitsFactor prog * s ≤ bitsFactor prog * δ := by
    rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ hδ
  have h5 : (h + 1) * (E + fc) = h * (E + fc) + (E + fc) := Nat.succ_mul _ _
  omega

/-- The first configuration of a simulation. -/
theorem start_within {q : CodePos} {e : Expr} (hq : exprAt prog q = some e) (env : List Val)
    (K : List Frame) (tape : List Bool) (h δ : ℕ) :
    Within prog K (simBound prog h env δ) ⟨Ctrl.eval q env, K, tape⟩ := by
  apply Within.top
  rw [encodeCtrl_eval_length]
  have hp := encodePos_le hq
  unfold simBound frameC
  have h1 : (bitEncodeVals env).length + (posBits prog + 5) ≤
      (h + 1) * ((bitEncodeVals env).length + (posBits prog + 5)) :=
    Nat.le_mul_of_pos_left _ (by omega)
  omega

/-- The last configuration of a simulation. -/
theorem ret_within {v : Val} {δ : ℕ} (hv : valSize v ≤ δ) (K : List Frame) (tape : List Bool)
    (h : ℕ) (env : List Val) :
    Within prog K (simBound prog h env δ) ⟨Ctrl.ret v, K, tape⟩ := by
  apply Within.top
  rw [encodeCtrl_ret_length]
  have h1 := bitEncodeVal_length_le v
  have h2 := valSize_pos v
  have h3 := five_le_bitsFactor prog
  have h4 : 4 * valSize v ≤ bitsFactor prog * δ := Nat.mul_le_mul (by omega) hv
  unfold simBound
  omega

end F2e2e.Machine
