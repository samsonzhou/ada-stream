import Mathlib
import F2e2e.Cost.ArithCore

/-!
# U1: correctness of the bit-level algorithms of `+`, `−`, `*`, `<`, `=` (lemma (i), part 1)

For the arithmetic block of Spec v2.1 (§3.2 of `F2e2e/Spec.lean`): `addSM` (sign-magnitude addition, also
used for subtraction), `mulTrace` (shift-and-add), `eqTrace` (equality scan) and the comparison of
`arithRun` compute exactly the value of `evalBin`. (Division and remainder: `F2e2e/Cost/ArithDiv.lean`.)
-/

namespace F2e2e.Machine

/-! ## Helpers -/

theorem regVal_eq_headD_tail (t : List Bool) : regVal t = (t.headD false).toNat + 2 * regVal t.tail := by
  cases t with
  | nil => simp
  | cons a t => simp

/-- The decoding used by `arithRun`. -/
theorem arith_sm_eq (s : Bool) (m : List Bool) :
    (if s then -(bitsNat m : ℤ) else (bitsNat m : ℤ)) = smVal s m := by
  unfold smVal
  rw [bitsNat_eq_regVal]

/-! ## Addition and subtraction (sign-magnitude) -/

/-- `addSM` computes the sum of the decoded operands. -/
theorem addSM_val (sa sb : Bool) (x y : List Bool) :
    smVal (addSM sa sb x y).1.1 (addSM sa sb x y).1.2 = smVal sa x + smVal sb y := by
  unfold addSM
  by_cases hs : sa = sb
  · rw [if_pos hs]
    obtain ⟨h1, -⟩ := addTrace_add (x := x) (y := y) (n := max x.length y.length + 1)
      (by omega) (by omega)
    simp only
    rw [smVal, smVal, smVal, regVal_trimBits, h1, ← hs]
    cases sa
    · simp
    · simp; ring
  · rw [if_neg hs]
    have hsb : sb = !sa := by cases sa <;> cases sb <;> simp_all
    obtain ⟨hc, hd⟩ := addTrace_sub (x := x) (y := y) (n := max x.length y.length)
      (le_max_left _ _) (le_max_right _ _)
    by_cases hle : regVal y ≤ regVal x
    · have hc' : (addTrace true (max x.length y.length) x y true []).2.1 = true := by
        rw [hc]; simpa using hle
      simp only [hc', if_true]
      rw [smVal, smVal, smVal, regVal_trimBits, hd hle, hsb]
      cases sa <;> simp <;> omega
    · have hc' : (addTrace true (max x.length y.length) x y true []).2.1 = false := by
        rw [hc]; simpa using hle
      simp only [hc', Bool.false_eq_true, if_false]
      obtain ⟨-, hd2⟩ := addTrace_sub (x := y) (y := x) (n := max x.length y.length)
        (le_max_right _ _) (le_max_left _ _)
      rw [smVal, smVal, smVal, regVal_trimBits, hd2 (by omega), hsb]
      cases sa <;> simp <;> omega

/-! ## Multiplication (shift and add) -/

/-- The invariant of `mulTrace`: the result is `lo + 2^|lo|·(p + x·y)`. -/
theorem mulTrace_val (x : List Bool) : ∀ (y p lo : List Bool),
    regVal (mulTrace x y p lo).1 = regVal lo + 2 ^ lo.length * (regVal p + regVal x * regVal y) := by
  intro y
  induction y with
  | nil => intro p lo; simp [mulTrace, regVal_append]
  | cons b y ih =>
    intro p lo
    simp only [mulTrace]
    rw [ih]
    have hs : regVal (if b then addTrace false (max p.length x.length + 1) p x false []
        else (p, false, [])).1 = regVal p + b.toNat * regVal x := by
      cases b
      · simp
      · simp only [if_true, Bool.toNat_true, one_mul]
        exact (addTrace_add (by omega) (by omega)).1
    set t := trimBits (if b then addTrace false (max p.length x.length + 1) p x false []
        else (p, false, [])).1 with ht
    have htv : regVal t = regVal p + b.toNat * regVal x := by rw [ht, regVal_trimBits, hs]
    rw [regVal_eq_headD_tail t] at htv
    rw [regVal_append, regVal_singleton, List.length_append, List.length_singleton, regVal_cons,
      pow_succ]
    generalize (2 : ℕ) ^ lo.length = P
    nlinarith [htv]

/-- The product of magnitudes. -/
theorem mulTrace_mag (x y : List Bool) :
    regVal (trimBits (mulTrace x y [] []).1) = regVal x * regVal y := by
  rw [regVal_trimBits, mulTrace_val]
  simp

/-! ## Equality scan -/

theorem eqTrace_val : ∀ (n : ℕ) (x y : List Bool) (e : Bool),
    (eqTrace n x y e).1 = (e && decide (regVal (x.take n) = regVal (y.take n)))
  | 0, x, y, e => by simp [eqTrace]
  | n + 1, x, y, e => by
    simp only [eqTrace]
    rw [eqTrace_val n x.tail y.tail, regVal_take_succ x n, regVal_take_succ y n]
    generalize x.headD false = xh
    generalize y.headD false = yh
    generalize regVal (x.tail.take n) = X
    generalize regVal (y.tail.take n) = Y
    rw [Bool.eq_iff_iff]
    simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
    constructor
    · rintro ⟨⟨he, hxy⟩, hXY⟩
      exact ⟨he, by rw [hxy, hXY]⟩
    · rintro ⟨he, h⟩
      have hx := Bool.toNat_le xh
      have hy := Bool.toNat_le yh
      have h1 : xh.toNat = yh.toNat := by omega
      refine ⟨⟨he, ?_⟩, by omega⟩
      cases xh <;> cases yh <;> simp at h1 ⊢

/-! ## The integer primitives -/

section Ints

variable (a b : ℤ)

theorem arithRun_add : (arithRun BinOp.add a b).1 = Val.int (a + b) := by
  simp only [arithRun]
  rw [arith_sm_eq, addSM_val, smVal_bits, smVal_bits]

theorem smVal_neg_sign (b : ℤ) : smVal (decide (0 < b)) (Nat.bits b.natAbs) = -b := by
  unfold smVal
  rw [regVal_bits]
  by_cases hb : 0 < b
  · rw [if_pos (by simpa using hb)]; omega
  · rw [if_neg (by simpa using hb)]; omega

theorem arithRun_sub : (arithRun BinOp.sub a b).1 = Val.int (a - b) := by
  simp only [arithRun]
  rw [arith_sm_eq, addSM_val, smVal_bits, smVal_neg_sign]
  ring_nf

theorem arithRun_mul : (arithRun BinOp.mul a b).1 = Val.int (a * b) := by
  simp only [arithRun]
  rw [arith_sm_eq]
  congr 1
  unfold smVal
  rw [mulTrace_mag, regVal_bits, regVal_bits, Nat.cast_mul, Int.natCast_natAbs, Int.natCast_natAbs]
  by_cases ha : a < 0
  · by_cases hb : b < 0
    · simp [ha, hb, abs_of_neg ha, abs_of_neg hb]
    · simp [ha, hb, abs_of_neg ha, abs_of_nonneg (not_lt.mp hb)]
  · by_cases hb : b < 0
    · simp [ha, hb, abs_of_nonneg (not_lt.mp ha), abs_of_neg hb]
    · simp [ha, hb, abs_of_nonneg (not_lt.mp ha), abs_of_nonneg (not_lt.mp hb)]

theorem cmp_carry (x y : List Bool) :
    (addTrace true (max x.length y.length) x y true []).2.1 = decide (regVal y ≤ regVal x) :=
  (addTrace_sub (le_max_left _ _) (le_max_right _ _)).1

theorem cmp_carry' (x y : List Bool) :
    (addTrace true (max x.length y.length) y x true []).2.1 = decide (regVal x ≤ regVal y) :=
  (addTrace_sub (le_max_right _ _) (le_max_left _ _)).1

theorem arithRun_lt : (arithRun BinOp.lt a b).1 = Val.int (if a < b then 1 else 0) := by
  simp only [arithRun]
  by_cases ha : a < 0
  · by_cases hb : b < 0
    · have hs : decide (a < 0) = decide (b < 0) := by simp [ha, hb]
      rw [if_pos hs]
      simp only [ha, decide_true, if_true]
      rw [cmp_carry', regVal_bits, regVal_bits]
      congr 1
      by_cases h : a.natAbs ≤ b.natAbs
      · rw [if_pos (by simpa using h), if_neg (by omega)]
      · rw [if_neg (by simpa using h), if_pos (by omega)]
    · have hs : ¬ decide (a < 0) = decide (b < 0) := by simp [ha, hb]
      rw [if_neg hs]
      simp only [ha, decide_true, if_true]
      rw [if_pos (by omega)]
  · by_cases hb : b < 0
    · have hs : ¬ decide (a < 0) = decide (b < 0) := by simp [ha, hb]
      rw [if_neg hs]
      simp only [ha, decide_false, Bool.false_eq_true, if_false]
      rw [if_neg (by omega)]
    · have hs : decide (a < 0) = decide (b < 0) := by simp [ha, hb]
      rw [if_pos hs]
      simp only [ha, decide_false, Bool.false_eq_true, if_false]
      rw [cmp_carry, regVal_bits, regVal_bits]
      congr 1
      by_cases h : b.natAbs ≤ a.natAbs
      · rw [if_pos (by simpa using h), if_neg (by omega)]
      · rw [if_neg (by simpa using h), if_pos (by omega)]

theorem arithRun_eq : (arithRun BinOp.eq a b).1 = Val.int (if a = b then 1 else 0) := by
  simp only [arithRun]
  rw [eqTrace_val, regVal_take_of_le (le_max_left _ _), regVal_take_of_le (le_max_right _ _),
    regVal_bits, regVal_bits]
  congr 1
  by_cases h : a = b
  · subst h
    rw [if_pos ⟨rfl, by simp⟩, if_pos rfl]
  · rw [if_neg h]
    rw [if_neg]
    rintro ⟨hs, hn⟩
    apply h
    simp only [Bool.true_and, decide_eq_true_eq] at hn
    by_cases ha : a < 0 <;> by_cases hb : b < 0 <;> simp [ha, hb] at hs <;> omega

end Ints

end F2e2e.Machine
