import F2e2e.Spec
import F2e2e.Cost.Facts

/-!
# Sizes of machine configurations

* Bit lengths of the value encodings: `bitEncodeVal_length_le : |bitEncodeVal v| ≤ 3·valSize v`,
  `bitEncodeVals_length_le : |bitEncodeVals l| ≤ 3·listSize l + 1`, exact forms for integers,
  lists, singletons.
* Code positions: `encodePos_length = fnWidth + 3·|path| + 1`; expression `height`, `progDepth`,
  `exprAt_bound : |path| + height e ≤ progDepth` for a valid position; child positions.
* Frames and stacks: `frameBits`, `framesBits`, `encodeStack_append_length`, `confBits_eq`.
* The constants of the bridge: `posBits`, `frameC`, `bitsFactor`, `bitsConst`.
-/

namespace F2e2e.Machine

/-! ## Value encodings -/

theorem bits_length (n : ℕ) : (Nat.bits n).length = Nat.size n :=
  Nat.size_eq_bits_len n

theorem bitEncodeVal_int_length (z : ℤ) :
    (bitEncodeVal (Val.int z)).length = 2 * bitLen z + 3 := by
  simp only [bitEncodeVal, List.length_append, List.length_cons, List.length_nil,
    List.length_replicate, bits_length]
  unfold bitLen
  omega

theorem bitEncodeVal_list_length (xs : List Val) :
    (bitEncodeVal (Val.list xs)).length = (bitEncodeVals xs).length + 1 := by
  simp [bitEncodeVal]

theorem bitEncodeVals_nil_length : (bitEncodeVals []).length = 1 := by
  simp [bitEncodeVals]

theorem bitEncodeVals_cons_length (x : Val) (xs : List Val) :
    (bitEncodeVals (x :: xs)).length = (bitEncodeVal x).length + (bitEncodeVals xs).length + 1 := by
  simp only [bitEncodeVals, List.length_cons, List.length_append]

theorem bitEncodeVals_singleton_length (x : Val) :
    (bitEncodeVals [x]).length = (bitEncodeVal x).length + 2 := by
  rw [bitEncodeVals_cons_length, bitEncodeVals_nil_length]

mutual
theorem bitEncodeVal_length_le : ∀ v : Val, (bitEncodeVal v).length ≤ 3 * valSize v
  | Val.int z => by
      rw [bitEncodeVal_int_length]
      simp only [valSize]
      omega
  | Val.list xs => by
      have := bitEncodeVals_length_le xs
      rw [bitEncodeVal_list_length]
      simp only [valSize]
      omega
theorem bitEncodeVals_length_le : ∀ l : List Val, (bitEncodeVals l).length ≤ 3 * listSize l + 1
  | [] => by simp [bitEncodeVals, listSize]
  | x :: xs => by
      have h1 := bitEncodeVal_length_le x
      have h2 := bitEncodeVals_length_le xs
      rw [bitEncodeVals_cons_length]
      simp only [listSize]
      omega
end

/-! ## Code positions and heights -/

theorem fixedBits_length (w n : ℕ) : (fixedBits w n).length = w := by
  simp [fixedBits]

theorem encodePos_length (prog : List Expr) (p : CodePos) :
    (encodePos prog p).length = fnWidth prog + 3 * p.path.length + 1 := by
  have h : ∀ l : List ℕ,
      (l.flatMap (fun j => [true, j.testBit 0, j.testBit 1])).length = 3 * l.length := by
    intro l
    induction l with
    | nil => simp
    | cons j l ih =>
      simp only [List.flatMap_cons, List.length_append, List.length_cons, List.length_nil, ih]
      ring
  simp only [encodePos, List.length_append, fixedBits_length, h, List.length_cons,
    List.length_nil]

/-- Height of an expression tree (leaves have height `0`). -/
def height : Expr → ℕ
  | Expr.bin _ a b => max (height a) (height b) + 1
  | Expr.un _ a => height a + 1
  | Expr.ite c t f => max (max (height c) (height t)) (height f) + 1
  | Expr.letE a b => max (height a) (height b) + 1
  | Expr.call _ a => height a + 1
  | Expr.loop _ a => height a + 1
  | _ => 0

theorem height_child {e e' : Expr} {j : ℕ} (h : Expr.child e j = some e') :
    height e' + 1 ≤ height e := by
  cases e with
  | bin op a b =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
    | 1, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | un op a =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | ite c t f =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
    | 1, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
    | 2, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | letE a b =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
    | 1, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | call i a =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | loop i a =>
    match j, h with
    | 0, h => simp only [Expr.child, Option.some.injEq] at h; subst h; simp [height]
  | var _ => simp [Expr.child] at h
  | lit _ => simp [Expr.child] at h
  | nil => simp [Expr.child] at h
  | coin => simp [Expr.child] at h

theorem exprAtPath_append (e : Expr) (path : List ℕ) (j : ℕ) :
    Expr.atPath e (path ++ [j]) = (Expr.atPath e path).bind (fun e' => Expr.child e' j) := by
  induction path generalizing e with
  | nil =>
    show (match Expr.child e j with | some e' => Expr.atPath e' [] | none => none) = Expr.child e j
    cases Expr.child e j <;> rfl
  | cons k path ih =>
    simp only [List.cons_append, Expr.atPath]
    cases Expr.child e k with
    | none => rfl
    | some e₁ => exact ih e₁

theorem height_atPath {e e' : Expr} {path : List ℕ} (h : Expr.atPath e path = some e') :
    path.length + height e' ≤ height e := by
  induction path generalizing e with
  | nil =>
    simp only [Expr.atPath, Option.some.injEq] at h
    subst h; simp
  | cons j path ih =>
    simp only [Expr.atPath] at h
    cases hc : Expr.child e j with
    | none => rw [hc] at h; simp at h
    | some e₁ =>
      rw [hc] at h
      have h1 := ih h
      have h2 := height_child hc
      simp only [List.length_cons]
      omega

/-- The maximal height of a function body. -/
def progDepth (prog : List Expr) : ℕ := (prog.map height).foldr max 0

theorem height_le_progDepth {prog : List Expr} {i : ℕ} {body : Expr} (h : prog[i]? = some body) :
    height body ≤ progDepth prog := by
  induction prog generalizing i with
  | nil => simp at h
  | cons b rest ih =>
    simp only [progDepth, List.map_cons, List.foldr_cons] at *
    cases i with
    | zero =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at h
      subst h; exact le_max_left _ _
    | succ i =>
      simp only [List.getElem?_cons_succ] at h
      exact (ih h).trans (le_max_right _ _)

theorem exprAt_bound {prog : List Expr} {p : CodePos} {e : Expr} (h : exprAt prog p = some e) :
    p.path.length + height e ≤ progDepth prog := by
  unfold exprAt at h
  cases hb : prog[p.fn]? with
  | none => rw [hb] at h; simp at h
  | some body =>
    rw [hb] at h
    exact (height_atPath h).trans (height_le_progDepth hb)

theorem exprAt_child {prog : List Expr} {p : CodePos} {e e' : Expr} {j : ℕ}
    (h : exprAt prog p = some e) (hc : Expr.child e j = some e') :
    exprAt prog (p.child j) = some e' := by
  unfold exprAt at h ⊢
  simp only [CodePos.child]
  cases hb : prog[p.fn]? with
  | none => rw [hb] at h; simp at h
  | some body =>
    rw [hb] at h
    simp only [exprAtPath_append, h, Option.bind_some, hc]

theorem exprAt_root {prog : List Expr} {i : ℕ} {body : Expr} (h : prog[i]? = some body) :
    exprAt prog ⟨i, []⟩ = some body := by
  simp [exprAt, h, Expr.atPath]

/-! ## Constants of the bridge -/

/-- Bits of any valid code position: `fnWidth + 3·progDepth + 1`. -/
def posBits (prog : List Expr) : ℕ := fnWidth prog + 3 * progDepth prog + 1

/-- Overhead of one frame (stack bit, tag, position) and of the control tag with a position. -/
def frameC (prog : List Expr) : ℕ := posBits prog + 5

/-- The factor `K(prog)` of the bridge: `(progDepth + 1)·(frameC + 5)`. -/
def bitsFactor (prog : List Expr) : ℕ := (progDepth prog + 1) * (frameC prog + 5)

/-- The additive constant `K'(prog)` of the bridge. -/
def bitsConst (prog : List Expr) : ℕ := (progDepth prog + 1) * (frameC prog + 2) + 1

theorem encodePos_le {prog : List Expr} {p : CodePos} {e : Expr} (h : exprAt prog p = some e) :
    (encodePos prog p).length + 3 * height e ≤ posBits prog := by
  have := exprAt_bound h
  rw [encodePos_length]
  unfold posBits
  omega

/-! ## Frames and stacks -/

/-- Bits of one frame on the stack (its stack bit included). -/
def frameBits (prog : List Expr) (f : Frame) : ℕ := (encodeFrame prog f).length + 1

/-- Bits of a list of frames on the stack. -/
def framesBits (prog : List Expr) (F : List Frame) : ℕ := (F.map (frameBits prog)).sum

theorem framesBits_nil (prog : List Expr) : framesBits prog [] = 0 := rfl

theorem framesBits_append (prog : List Expr) (F G : List Frame) :
    framesBits prog (F ++ G) = framesBits prog F + framesBits prog G := by
  simp [framesBits]

theorem framesBits_singleton (prog : List Expr) (f : Frame) :
    framesBits prog [f] = frameBits prog f := by
  simp [framesBits]

theorem encodeStack_append_length (prog : List Expr) (F K : List Frame) :
    (encodeStack prog (F ++ K)).length = framesBits prog F + (encodeStack prog K).length := by
  induction F with
  | nil => simp [framesBits]
  | cons f F ih =>
    simp only [List.cons_append, encodeStack, List.length_cons, List.length_append, ih,
      framesBits, List.map_cons, List.sum_cons, frameBits]
    omega

theorem confBits_eq (prog : List Expr) (c : Conf) :
    confBits prog c = (encodeCtrl prog c.ctrl).length + (encodeStack prog c.stack).length := by
  simp [confBits, encodeConf]

theorem encodeStack_nil_length (prog : List Expr) : (encodeStack prog []).length = 1 := rfl

theorem fixedBits4_length (n : ℕ) : (fixedBits 4 n).length = 4 := fixedBits_length 4 n

theorem frameBits_binL (prog : List Expr) (p : CodePos) (env : List Val) :
    frameBits prog (Frame.binL p env) =
      (encodePos prog p).length + (bitEncodeVals env).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_binR (prog : List Expr) (p : CodePos) (v : Val) :
    frameBits prog (Frame.binR p v) = (encodePos prog p).length + (bitEncodeVal v).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_un (prog : List Expr) (p : CodePos) :
    frameBits prog (Frame.un p) = (encodePos prog p).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_ite (prog : List Expr) (p : CodePos) (env : List Val) :
    frameBits prog (Frame.ite p env) =
      (encodePos prog p).length + (bitEncodeVals env).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_letE (prog : List Expr) (p : CodePos) (env : List Val) :
    frameBits prog (Frame.letE p env) =
      (encodePos prog p).length + (bitEncodeVals env).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_callArg (prog : List Expr) (p : CodePos) :
    frameBits prog (Frame.callArg p) = (encodePos prog p).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_loopInit (prog : List Expr) (p : CodePos) :
    frameBits prog (Frame.loopInit p) = (encodePos prog p).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem frameBits_loopIter (prog : List Expr) (p : CodePos) :
    frameBits prog (Frame.loopIter p) = (encodePos prog p).length + 5 := by
  simp only [frameBits, encodeFrame, List.length_append, fixedBits4_length]; omega

theorem encodeCtrl_eval_length (prog : List Expr) (p : CodePos) (env : List Val) :
    (encodeCtrl prog (Ctrl.eval p env)).length =
      (encodePos prog p).length + (bitEncodeVals env).length + 1 := by
  simp only [encodeCtrl, List.length_cons, List.length_append]

theorem encodeCtrl_ret_length (prog : List Expr) (v : Val) :
    (encodeCtrl prog (Ctrl.ret v)).length = (bitEncodeVal v).length + 1 := by
  simp only [encodeCtrl, List.length_cons]

end F2e2e.Machine
