import F2e2e.Cost.Arith.AExpSpec

/-!
# Bound propagation for `AExp` (owner de4dddbc) — port of cut2 `Cost/Arith/AExpBound.lean`

To discharge the bit-length side conditions of `AExp.Good`, bounds are propagated syntactically:
`AExp.bnd T envB e = (vb, sw)` with `e.val env ≤ vb` and `size (e.val env) ≤ sw`, from bounds
`envB` of the environment and a bound transformer `T j` for every called function `j`;
`AExp.mw T envB e` is the largest size bound over all subterms. `AExp.good_of_struct`: structural
conditions (`AExp.Struct`) plus `mw ≤ K` give `Good`. `chainGood_of_struct` lifts this to chains.
-/

namespace F2e2e.Cost.Arith
/-- Bound transformer of called functions: `(value bound, size bound)` of the argument to those of
the result. -/
abbrev BndT : Type := ℕ → ℕ × ℕ → ℕ × ℕ

/-- `T` is sound for the function `f` at index `j`. -/
def TSound (T : BndT) (j : ℕ) (f : ℕ → ℕ) : Prop :=
  ∀ x vb sw : ℕ, x ≤ vb → Nat.size x ≤ sw → f x ≤ (T j (vb, sw)).1 ∧ Nat.size (f x) ≤ (T j (vb, sw)).2

theorem size_mul_le' (a b : ℕ) : Nat.size (a * b) ≤ Nat.size a + Nat.size b := by
  rw [Nat.size_le, pow_add]
  exact Nat.mul_lt_mul_of_lt_of_le (Nat.lt_size_self a) (Nat.lt_size_self b).le
    (Nat.two_pow_pos _)

theorem size_add_le' (a b : ℕ) : Nat.size (a + b) ≤ Max.max (Nat.size a) (Nat.size b) + 1 := by
  rw [Nat.size_le, pow_succ]
  have ha := Nat.lt_size_self a
  have hb := Nat.lt_size_self b
  have h1 : 2 ^ Nat.size a ≤ 2 ^ Max.max (Nat.size a) (Nat.size b) :=
    Nat.pow_le_pow_right (by norm_num) (le_max_left _ _)
  have h2 : 2 ^ Nat.size b ≤ 2 ^ Max.max (Nat.size a) (Nat.size b) :=
    Nat.pow_le_pow_right (by norm_num) (le_max_right _ _)
  omega

namespace AExp

/-- Value bound and size bound. -/
def bnd (T : BndT) (envB : List (ℕ × ℕ)) : AExp → ℕ × ℕ
  | var i => envB.getD i (0, 0)
  | lit k => (k, Nat.size k)
  | add a b => ((a.bnd T envB).1 + (b.bnd T envB).1,
      Max.max (a.bnd T envB).2 (b.bnd T envB).2 + 1)
  | mul a b => ((a.bnd T envB).1 * (b.bnd T envB).1, (a.bnd T envB).2 + (b.bnd T envB).2)
  | tsub a _ => a.bnd T envB
  | div a _ => a.bnd T envB
  | max a b => (Max.max (a.bnd T envB).1 (b.bnd T envB).1,
      Max.max (a.bnd T envB).2 (b.bnd T envB).2)
  | call j _ a => T j (a.bnd T envB)

/-- Largest size bound over all subterms. -/
def mw (T : BndT) (envB : List (ℕ × ℕ)) : AExp → ℕ
  | var i => (envB.getD i (0, 0)).2
  | lit k => Nat.size k
  | add a b => Max.max (Max.max (a.mw T envB) (b.mw T envB))
      (Max.max (a.bnd T envB).2 (b.bnd T envB).2 + 1)
  | mul a b => Max.max (Max.max (a.mw T envB) (b.mw T envB))
      ((a.bnd T envB).2 + (b.bnd T envB).2)
  | tsub a b => Max.max (a.mw T envB) (b.mw T envB)
  | div a b => Max.max (a.mw T envB) (b.mw T envB)
  | max a b => Max.max (a.mw T envB) (b.mw T envB)
  | call j _ a => Max.max (a.mw T envB) (T j (a.bnd T envB)).2

/-- Structural side conditions. -/
def Struct (prog : List Expr) (K Cc Sc : ℕ) (T : BndT) (env : List ℕ) : AExp → Prop
  | var i => i < env.length
  | lit _ => True
  | add a b => a.Struct prog K Cc Sc T env ∧ b.Struct prog K Cc Sc T env
  | mul a b => a.Struct prog K Cc Sc T env ∧ b.Struct prog K Cc Sc T env
  | tsub a b => a.Struct prog K Cc Sc T env ∧ b.Struct prog K Cc Sc T env
  | div a b => a.Struct prog K Cc Sc T env ∧ b.Struct prog K Cc Sc T env ∧ b.val env ≠ 0
  | max a b => a.Struct prog K Cc Sc T env ∧ b.Struct prog K Cc Sc T env
  | call j f a => a.Struct prog K Cc Sc T env ∧ CallOK prog j f K Cc Sc ∧ TSound T j f

/-- The environment satisfies its bounds. -/
def EnvOK (env : List ℕ) (envB : List (ℕ × ℕ)) : Prop :=
  ∀ i < env.length, env.getD i 0 ≤ (envB.getD i (0, 0)).1 ∧
    Nat.size (env.getD i 0) ≤ (envB.getD i (0, 0)).2

variable {prog : List Expr} {K Cc Sc : ℕ} {T : BndT}

theorem bnd_sound {env : List ℕ} {envB : List (ℕ × ℕ)} (henv : EnvOK env envB) :
    ∀ e : AExp, e.Struct prog K Cc Sc T env →
      e.val env ≤ (e.bnd T envB).1 ∧ Nat.size (e.val env) ≤ (e.bnd T envB).2
  | var i, h => henv i h
  | lit k, _ => ⟨le_refl _, le_refl _⟩
  | add a b, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      obtain ⟨hb1, hb2⟩ := bnd_sound henv b h.2
      simp only [val, bnd]
      refine ⟨Nat.add_le_add ha1 hb1, (size_add_le' _ _).trans ?_⟩
      have := max_le_max ha2 hb2
      omega
  | mul a b, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      obtain ⟨hb1, hb2⟩ := bnd_sound henv b h.2
      simp only [val, bnd]
      exact ⟨Nat.mul_le_mul ha1 hb1, (size_mul_le' _ _).trans (Nat.add_le_add ha2 hb2)⟩
  | tsub a b, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      simp only [val, bnd]
      exact ⟨(Nat.sub_le _ _).trans ha1, (Nat.size_le_size (Nat.sub_le _ _)).trans ha2⟩
  | div a b, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      simp only [val, bnd]
      exact ⟨(Nat.div_le_self _ _).trans ha1, (Nat.size_le_size (Nat.div_le_self _ _)).trans ha2⟩
  | max a b, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      obtain ⟨hb1, hb2⟩ := bnd_sound henv b h.2
      simp only [val, bnd]
      refine ⟨max_le_max ha1 hb1, ?_⟩
      rcases le_total (a.val env) (b.val env) with hab | hab
      · rw [max_eq_right hab]; exact hb2.trans (le_max_right _ _)
      · rw [max_eq_left hab]; exact ha2.trans (le_max_left _ _)
  | call j f a, h => by
      obtain ⟨ha1, ha2⟩ := bnd_sound henv a h.1
      simp only [val, bnd]
      exact h.2.2 _ _ _ ha1 ha2

theorem good_of_struct {env : List ℕ} {envB : List (ℕ × ℕ)} (henv : EnvOK env envB) :
    ∀ e : AExp, e.Struct prog K Cc Sc T env → e.mw T envB ≤ K → e.Good prog K Cc Sc env
  | var i, h, hK => ⟨h, (henv i h).2.trans hK⟩
  | lit k, _, hK => hK
  | add a b, h, hK => by
      simp only [mw, max_le_iff] at hK
      have hs := (bnd_sound henv (add a b) h).2
      simp only [bnd] at hs
      exact ⟨good_of_struct henv a h.1 hK.1.1, good_of_struct henv b h.2 hK.1.2,
        hs.trans hK.2⟩
  | mul a b, h, hK => by
      simp only [mw, max_le_iff] at hK
      have hs := (bnd_sound henv (mul a b) h).2
      simp only [bnd] at hs
      exact ⟨good_of_struct henv a h.1 hK.1.1, good_of_struct henv b h.2 hK.1.2,
        hs.trans hK.2⟩
  | tsub a b, h, hK => by
      simp only [mw, max_le_iff] at hK
      exact ⟨good_of_struct henv a h.1 hK.1, good_of_struct henv b h.2 hK.2⟩
  | div a b, h, hK => by
      simp only [mw, max_le_iff] at hK
      exact ⟨good_of_struct henv a h.1 hK.1, good_of_struct henv b h.2.1 hK.2, h.2.2⟩
  | max a b, h, hK => by
      simp only [mw, max_le_iff] at hK
      exact ⟨good_of_struct henv a h.1 hK.1, good_of_struct henv b h.2 hK.2⟩
  | call j f a, h, hK => by
      simp only [mw, max_le_iff] at hK
      have hs := (bnd_sound henv (call j f a) h).2
      simp only [bnd] at hs
      exact ⟨good_of_struct henv a h.1 hK.1, h.2.1, hs.trans hK.2⟩

theorem envOK_cons {env : List ℕ} {envB : List (ℕ × ℕ)} (henv : EnvOK env envB) (e : AExp)
    (h : e.Struct prog K Cc Sc T env) :
    EnvOK (e.val env :: env) (e.bnd T envB :: envB) := by
  intro i hi
  cases i with
  | zero => simpa using bnd_sound henv e h
  | succ i =>
    simp only [List.length_cons] at hi
    simpa using henv i (by omega)

end AExp

/-- Structural conditions and size budget along a chain. -/
def ChainStruct (prog : List Expr) (K Cc Sc : ℕ) (T : BndT) :
    List AExp → List ℕ → List (ℕ × ℕ) → Prop
  | [], _, _ => True
  | e :: es, env, envB => e.Struct prog K Cc Sc T env ∧ e.mw T envB ≤ K ∧
      ChainStruct prog K Cc Sc T es (e.val env :: env) (e.bnd T envB :: envB)

/-- Bounds of the environment after a chain. -/
def chainEnvB (T : BndT) : List AExp → List (ℕ × ℕ) → List (ℕ × ℕ)
  | [], envB => envB
  | e :: es, envB => chainEnvB T es (e.bnd T envB :: envB)

theorem chainGood_of_struct {prog : List Expr} {K Cc Sc : ℕ} {T : BndT} :
    ∀ (es : List AExp) (env : List ℕ) (envB : List (ℕ × ℕ)), AExp.EnvOK env envB →
      ChainStruct prog K Cc Sc T es env envB →
      ChainGood prog K Cc Sc es env ∧ AExp.EnvOK (chainEnv es env) (chainEnvB T es envB)
  | [], env, envB, henv, _ => ⟨trivial, henv⟩
  | e :: es, env, envB, henv, ⟨hs, hK, hrest⟩ => by
    obtain ⟨h1, h2⟩ := chainGood_of_struct es (e.val env :: env) (e.bnd T envB :: envB)
      (AExp.envOK_cons henv e hs) hrest
    exact ⟨⟨AExp.good_of_struct henv e hs hK, h1⟩, h2⟩

end F2e2e.Cost.Arith