import F2e2e.Cost.Arith.Basic
import F2e2e.Cost.Lib.RevAppend

/-!
# ARITH (Idx 100–149): integer median by insertion sort (owner de4dddbc) — port of cut2 `Cost/Arith/Median.lean`

Reference: `medZ l = (l.mergeSort (· ≤ ·)).getD (l.length / 2) 0`, the integer version of
the real median `medianR` (cut2's `Cut2.Fine.median`, same definition); bridge
`median_map_cast : medianR (l.map (↑)) = ↑(medZ l)`
(all lengths; the decoder uses odd `R`).

DSL routines:
* `insertZ` (index `Idx.insertZ`, loop `Idx.insertZStep`): `[x, s] ↦ s.orderedInsert (· ≤ ·) x`;
  loop state `[x, rp, sfx]` (reversed prefix, suffix), continue while `head sfx < x`; on stopping,
  `revAppend` (the list library's loop `Idx.revAppendStep`) rebuilds `rp.reverse ++ x :: sfx`.
* `isortZ` (index `Idx.isortZ`, loop `Idx.isortZStep`): `l ↦ isortRef l` (left fold of `insertZ`).
* `medZ` (index `Idx.medZ`, loop `Idx.medWalkStep`): sorts, then walks `[slow, fast]` (one and two
  steps) to the element of index `⌊len/2⌋` (`0` for the empty list).

Status: proved. Internal specs: `Arith.insertZ_spec`, `Arith.isortZ_aux` (tighter space),
`Arith.walk_loop`.
-/

namespace F2e2e.Cost
namespace Idx

/-- `insertZ : [x, s] ↦ s.orderedInsert (· ≤ ·) x`. -/
abbrev insertZ : ℕ := 112
/-- Loop body of `insertZ`. -/
abbrev insertZStep : ℕ := 113
/-- `isortZ : l ↦ isortRef l`. -/
abbrev isortZ : ℕ := 114
/-- Loop body of `isortZ`. -/
abbrev isortZStep : ℕ := 115
/-- `medZ : l ↦ medZ l`. -/
abbrev medZ : ℕ := 116
/-- Loop body of the walk of `medZ`. -/
abbrev medWalkStep : ℕ := 117

end Idx

open Arith

/-! ## Reference functions -/

/-- Integer median: the entry of index `⌊len/2⌋` of the sorted list (`0` for `[]`). -/
def medZ (l : List ℤ) : ℤ := (l.mergeSort (fun a b => decide (a ≤ b))).getD (l.length / 2) 0

/-- Insertion sort as computed by the DSL routine (left fold of `orderedInsert`). -/
def isortRef (l : List ℤ) : List ℤ := l.foldl (fun s x => s.orderedInsert (· ≤ ·) x) []

namespace Arith

theorem sorted_mergeSort_le' {α : Type*} [LinearOrder α] (l : List α) :
    (l.mergeSort (fun a b => decide (a ≤ b))).Pairwise (· ≤ ·) := by
  have h := List.pairwise_mergeSort (le := fun a b : α => decide (a ≤ b))
    (fun a b c hab hbc => by
      simp only [decide_eq_true_eq] at hab hbc ⊢
      exact le_trans hab hbc)
    (fun a b => by rcases le_total a b with hab | hab <;> simp [hab]) l
  exact h.imp (fun hxy => by simpa using hxy)

/-- Sorting commutes with monotone maps. -/
theorem mergeSort_map_mono' {α β : Type*} [LinearOrder α] [LinearOrder β] (f : α → β)
    (hf : Monotone f) (l : List α) :
    (l.map f).mergeSort (fun a b => decide (a ≤ b)) =
      (l.mergeSort (fun a b => decide (a ≤ b))).map f := by
  have h1 := sorted_mergeSort_le' (l.map f)
  have h2 : ((l.mergeSort (fun a b => decide (a ≤ b))).map f).Pairwise (· ≤ ·) :=
    List.Pairwise.map f (fun a b h => hf h) (sorted_mergeSort_le' l)
  have hperm : List.Perm ((l.map f).mergeSort (fun a b => decide (a ≤ b)))
      ((l.mergeSort (fun a b => decide (a ≤ b))).map f) :=
    (List.mergeSort_perm _ _).trans ((List.mergeSort_perm l _).map f).symm
  exact hperm.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba) h1 h2

theorem isortAux_perm : ∀ (l s : List ℤ),
    (l.foldl (fun s x => s.orderedInsert (· ≤ ·) x) s).Perm (s ++ l)
  | [], s => by simp
  | x :: l, s => by
    simp only [List.foldl_cons]
    refine (isortAux_perm l (s.orderedInsert (· ≤ ·) x)).trans ?_
    have h1 : (s.orderedInsert (· ≤ ·) x ++ l).Perm ((x :: s) ++ l) :=
      (List.perm_orderedInsert _ x s).append_right l
    refine h1.trans ?_
    simpa using (List.perm_middle (a := x) (l₁ := s) (l₂ := l)).symm

theorem isortAux_sorted : ∀ (l s : List ℤ), s.Pairwise (· ≤ ·) →
    (l.foldl (fun s x => s.orderedInsert (· ≤ ·) x) s).Pairwise (· ≤ ·)
  | [], _, h => h
  | x :: l, s, h => isortAux_sorted l _ (h.orderedInsert x s)

end Arith

open Arith

/-- Real median: the entry of index `⌊len/2⌋` of the sorted list (`0` for `[]`); the definition
of cut2's `Cut2.Fine.median`. -/
noncomputable def medianR (l : List ℝ) : ℝ :=
  (l.mergeSort (fun a b => decide (a ≤ b))).getD (l.length / 2) 0

/-- **Bridge** to the real-valued median. -/
theorem median_map_cast (l : List ℤ) :
    medianR (l.map (fun z : ℤ => (z : ℝ))) = (medZ l : ℝ) := by
  unfold medianR medZ
  rw [mergeSort_map_mono' (fun z : ℤ => (z : ℝ)) (fun a b h => Int.cast_le.mpr h) l,
    List.length_map]
  conv_lhs => rw [← Int.cast_zero]
  exact List.getD_map _ _ _

/-- The DSL's sorting agrees with `mergeSort`. -/
theorem isortRef_eq_mergeSort (l : List ℤ) :
    isortRef l = l.mergeSort (fun a b => decide (a ≤ b)) := by
  have hp : (isortRef l).Perm (l.mergeSort (fun a b => decide (a ≤ b))) :=
    (isortAux_perm l []).trans (List.mergeSort_perm l _).symm
  exact hp.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba)
    (isortAux_sorted l [] List.Pairwise.nil) (sorted_mergeSort_le' l)

/-! ## Bodies -/

/-- `if e = [] then 0 else head e` (the expression `e` is evaluated once). -/
def eHeadOr0 (e : Expr) : Expr :=
  Expr.letE e (Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)))

/-- The stopping result `[0, rp.reverse ++ x :: sfx]` of `insertZ` (environment `[sfx, rp, x, acc]`). -/
def eInsertDone : Expr :=
  ePair (Expr.lit 0)
    (Expr.loop Idx.revAppendStep
      (ePair (Expr.var 1) (Expr.bin BinOp.cons (Expr.var 2) (Expr.var 0))))

/-- Loop body of `insertZ`. Environment `[acc]`, `acc = [x, rp, sfx]`. -/
def body_insertZStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                         -- x
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))                  -- rp
      (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))  -- sfx
        (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
          eInsertDone
          (Expr.ite (Expr.bin BinOp.lt (Expr.un UnOp.head (Expr.var 0)) (Expr.var 2))
            (ePair (Expr.lit 1)
              (eTriple (Expr.var 2)
                (Expr.bin BinOp.cons (Expr.un UnOp.head (Expr.var 0)) (Expr.var 1))
                (Expr.un UnOp.tail (Expr.var 0))))
            eInsertDone))))

/-- `insertZ : [x, s] ↦ s.orderedInsert (· ≤ ·) x`. Environment `[[encZ x, encInts s]]`. -/
def body_insertZ : Expr :=
  Expr.loop Idx.insertZStep
    (eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))))

/-- Loop body of `isortZ`. Environment `[acc]`, `acc = [s, r]`. -/
def body_isortZStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))                     -- r
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1)))
      (ePair (Expr.lit 1)
        (ePair
          (Expr.call Idx.insertZ
            (ePair (Expr.un UnOp.head (Expr.var 0)) (Expr.un UnOp.head (Expr.var 1))))
          (Expr.un UnOp.tail (Expr.var 0)))))

/-- `isortZ : l ↦ isortRef l`. Environment `[encInts l]`. -/
def body_isortZ : Expr := Expr.loop Idx.isortZStep (ePair Expr.nil (Expr.var 0))

/-- Loop body of the median walk. Environment `[acc]`, `acc = [slow, fast]`. -/
def body_medWalkStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))                     -- fast
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (ePair (Expr.lit 0) (eHeadOr0 (Expr.un UnOp.head (Expr.var 1))))
      (Expr.ite (Expr.un UnOp.isNil (Expr.un UnOp.tail (Expr.var 0)))
        (ePair (Expr.lit 0) (eHeadOr0 (Expr.un UnOp.head (Expr.var 1))))
        (ePair (Expr.lit 1)
          (ePair (Expr.un UnOp.tail (Expr.un UnOp.head (Expr.var 1)))
            (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 0)))))))

/-- `medZ : l ↦ medZ l`. Environment `[encInts l]`. -/
def body_medZ : Expr :=
  Expr.letE (Expr.call Idx.isortZ (Expr.var 0))
    (Expr.loop Idx.medWalkStep (ePair (Expr.var 0) (Expr.var 0)))

/-! ## Bounds and specs -/

/-- Cost bound of `isortZ`/`medZ` (`len` entries of bit length `≤ K`). -/
def C_medZ (len K : ℕ) : ℕ := 1000 * (len + 1) ^ 2 * (K + 1) + 1000

/-- Space bound of `isortZ`/`medZ` (on top of the base). -/
def S_medZ (len K : ℕ) : ℕ := 100 * (len + 1) * (K + 3) + 1000

/-! ## Proofs

* `insertZ`: the loop state `(rp, sfx)` satisfies `rp.reverseAux (sfx.orderedInsert x) = target`;
  each continuing iteration costs `O(K)`, the stopping one `O(|rp| + K)` (the `revAppend`), so the
  potential rule `LoopLe.of_inv` gives cost `O(|s| (K + 1))`.
* `isortZ`: state `(s, r)` with `r.foldl ins s = isortRef l` and `s ++ r ~ l`; uniform per-iteration
  bound (`LoopLe.of_measure`), cost `O(len² (K + 1))`.
* median walk: state `j` (`slow = t.drop j`, `fast = t.drop (2 j)`), stops at `j = ⌊len/2⌋`.
-/

namespace Arith

/-! ### Size helpers -/

theorem encInts_reverseAux_cons (a b : List ℤ) (x : ℤ) :
    Val.list ((a.map Val.int).reverseAux (Val.int x :: b.map Val.int)) =
      encInts (a.reverseAux (x :: b)) := by
  simp only [encInts, List.reverseAux_eq, List.map_append, List.map_reverse, List.map_cons]

theorem valSize_encInts_perm {a b : List ℤ} (h : a.Perm b) :
    valSize (encInts a) = valSize (encInts b) := by
  simp only [encInts, valSize_list, listSize_map]
  rw [(h.map _).sum_eq]

theorem valSize_encInts_append (a b : List ℤ) :
    valSize (encInts (a ++ b)) + 1 = valSize (encInts a) + valSize (encInts b) := by
  simp only [encInts, List.map_append, valSize_list, listSize_append]
  omega

theorem valSize_encInts_nil : valSize (encInts ([] : List ℤ)) = 1 := rfl

/-! ### `insertZ` -/

/-- Encoding of the `insertZ` loop state `(rp, sfx)` (reversed prefix, suffix) for the inserted
value `x`. -/
def encIns (x : ℤ) (st : List ℤ × List ℤ) : Val :=
  Val.list [Val.int x, encInts st.1, encInts st.2]

theorem valSize_encIns (x : ℤ) (a c : List ℤ) :
    valSize (encIns x (a, c)) = bitLen x + 5 + valSize (encInts a) + valSize (encInts c) := by
  simp only [encIns, valSize_list, listSize_cons, listSize_nil, valSize_int]
  omega

theorem insStep_cont (prog : List Expr) (base : ℕ) (x h : ℤ) (rp t : List ℤ) (hlt : h < x) :
    EvalsLe prog base [encIns x (rp, h :: t)] body_insertZStep
      (Val.list [Val.int 1, encIns x (h :: rp, t)]) (100 + bitLen h + bitLen x)
      (base + 5 * valSize (encIns x (rp, h :: t)) + 50) := by
  apply EvalsLe.of_eval 30
  simp only [body_insertZStep, encIns, encInts, List.map_cons, ePair, eTriple, eval_succ_var,
    eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hlt, if_true, one_ne_zero, not_false_eq_true,
    not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem eInsertDone_spec {prog : List Expr}
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (x : ℤ) (rp sfx : List ℤ) (acc : Val) :
    EvalsLe prog b [encInts sfx, encInts rp, Val.int x, acc] eInsertDone
      (Val.list [Val.int 0, encInts (rp.reverseAux (x :: sfx))])
      ((rp.length + 1) * 34 + 30)
      (b + 7 * (valSize (encInts rp) + valSize (encInts sfx) + bitLen x) + 60) := by
  have hinit := EvalsLe.pair (prog := prog) (base := b + valSize (Val.int 0))
    (env := [encInts sfx, encInts rp, Val.int x, acc])
    (EvalsLe.var (i := 1) (v := encInts rp) rfl)
    (EvalsLe.cons (EvalsLe.var (i := 2) (v := Val.int x) rfl)
      (EvalsLe.var (i := 0) (v := Val.list (sfx.map Val.int)) rfl))
  have hloop := revAppend_loop h6 (b + valSize (Val.int 0))
    (rp.map Val.int, Val.int x :: sfx.map Val.int)
  have hl := EvalsLe.loop (i := Idx.revAppendStep) hinit hloop
  have h := EvalsLe.pair (EvalsLe.lit (prog := prog) (base := b)
    (env := [encInts sfx, encInts rp, Val.int x, acc]) 0) hl
  have h' : EvalsLe prog b [encInts sfx, encInts rp, Val.int x, acc] eInsertDone
      (Val.list [Val.int 0,
        Val.list ((rp.map Val.int).reverseAux (Val.int x :: sfx.map Val.int))])
      ((rp.length + 1) * 34 + 30)
      (b + 7 * (valSize (encInts rp) + valSize (encInts sfx) + bitLen x) + 60) := by
    refine h.mono ?_ ?_
    · simp only [List.length_map, bitLen_zero]
      omega
    · simp only [encRA, encInts, valSize_list, valSize_int, listSize_cons, listSize_nil,
        listSize_reverseAux, max_le_iff, bitLen_zero]
      omega
  rw [encInts_reverseAux_cons] at h'
  exact h'

theorem insStep_nil {prog : List Expr} (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (x : ℤ) (rp : List ℤ) :
    EvalsLe prog b [encIns x (rp, [])] body_insertZStep
      (Val.list [Val.int 0, encInts (rp.reverseAux [x])])
      ((rp.length + 1) * 34 + 60) (b + 10 * valSize (encIns x (rp, [])) + 80) := by
  have hx1 := EvalsLe.head (prog := prog) (base := b) (env := [encIns x (rp, [])])
    (EvalsLe.var (i := 0) (v := Val.list [Val.int x, encInts rp, encInts []]) rfl)
  have hx2 := EvalsLe.head (prog := prog) (base := b + valSize (Val.int x))
    (env := [Val.int x, encIns x (rp, [])])
    (EvalsLe.tail (EvalsLe.var (i := 1) (v := Val.list [Val.int x, encInts rp, encInts []]) rfl))
  have hx3 := EvalsLe.head (prog := prog)
    (base := b + valSize (Val.int x) + valSize (encInts rp))
    (env := [encInts rp, Val.int x, encIns x (rp, [])])
    (EvalsLe.tail (EvalsLe.tail
      (EvalsLe.var (i := 2) (v := Val.list [Val.int x, encInts rp, encInts []]) rfl)))
  have hd := eInsertDone_spec h6
    (b + valSize (Val.int x) + valSize (encInts rp) + valSize (encInts [])) x rp []
    (encIns x (rp, []))
  have hc := EvalsLe.isNil_nil (prog := prog)
    (base := b + valSize (Val.int x) + valSize (encInts rp) + valSize (encInts []))
    (env := [encInts [], encInts rp, Val.int x, encIns x (rp, [])])
    (EvalsLe.var (i := 0) (v := Val.list []) rfl)
  refine (EvalsLe.letE hx1 (EvalsLe.letE hx2 (EvalsLe.letE hx3
    (EvalsLe.ite_true hc one_ne_zero hd)))).mono ?_ ?_
  · omega
  · simp only [valSize_encIns, valSize_encInts_nil, valSize_list, valSize_int, listSize_cons,
      listSize_nil, max_le_iff, bitLen_one]
    omega

theorem insStep_ge {prog : List Expr} (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (x h : ℤ) (rp t : List ℤ) (hge : ¬ h < x) :
    EvalsLe prog b [encIns x (rp, h :: t)] body_insertZStep
      (Val.list [Val.int 0, encInts (rp.reverseAux (x :: h :: t))])
      ((rp.length + 1) * 34 + 60 + bitLen h + bitLen x)
      (b + 10 * valSize (encIns x (rp, h :: t)) + 80) := by
  have hx1 := EvalsLe.head (prog := prog) (base := b) (env := [encIns x (rp, h :: t)])
    (EvalsLe.var (i := 0) (v := Val.list [Val.int x, encInts rp, encInts (h :: t)]) rfl)
  have hx2 := EvalsLe.head (prog := prog) (base := b + valSize (Val.int x))
    (env := [Val.int x, encIns x (rp, h :: t)])
    (EvalsLe.tail
      (EvalsLe.var (i := 1) (v := Val.list [Val.int x, encInts rp, encInts (h :: t)]) rfl))
  have hx3 := EvalsLe.head (prog := prog)
    (base := b + valSize (Val.int x) + valSize (encInts rp))
    (env := [encInts rp, Val.int x, encIns x (rp, h :: t)])
    (EvalsLe.tail (EvalsLe.tail
      (EvalsLe.var (i := 2) (v := Val.list [Val.int x, encInts rp, encInts (h :: t)]) rfl)))
  have hd := eInsertDone_spec h6
    (b + valSize (Val.int x) + valSize (encInts rp) + valSize (encInts (h :: t))) x rp (h :: t)
    (encIns x (rp, h :: t))
  have hc := EvalsLe.isNil_cons (prog := prog)
    (base := b + valSize (Val.int x) + valSize (encInts rp) + valSize (encInts (h :: t)))
    (env := [encInts (h :: t), encInts rp, Val.int x, encIns x (rp, h :: t)])
    (EvalsLe.var (i := 0) (v := Val.list (Val.int h :: t.map Val.int)) rfl)
  have hlt := EvalsLe.lt (prog := prog)
    (base := b + valSize (Val.int x) + valSize (encInts rp) + valSize (encInts (h :: t)))
    (env := [encInts (h :: t), encInts rp, Val.int x, encIns x (rp, h :: t)])
    (EvalsLe.head (EvalsLe.var (i := 0) (v := Val.list (Val.int h :: t.map Val.int)) rfl))
    (EvalsLe.var (i := 2) (v := Val.int x) rfl)
  refine (EvalsLe.letE hx1 (EvalsLe.letE hx2 (EvalsLe.letE hx3
    (EvalsLe.ite_false hc rfl (EvalsLe.ite_false hlt (if_neg hge) hd))))).mono ?_ ?_
  · omega
  · simp only [valSize_encIns, encInts, List.map_cons, valSize_list, valSize_int, listSize_cons,
      listSize_nil, max_le_iff, bitLen_zero, hge, if_false]
    omega

/-- The `insertZ` loop from `([], s)`. -/
theorem insertZ_loop {prog : List Expr} (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (x : ℤ) (s : List ℤ) (K : ℕ) (hx : bitLen x ≤ K) (hK : ∀ z ∈ s, bitLen z ≤ K) :
    LoopLe prog b Idx.insertZStep (encIns x ([], s)) (encInts (s.orderedInsert (· ≤ ·) x))
      (s.length * (2 * K + 101) + (s.length + 1) * 34 + 2 * K + 61)
      (b + 11 * (valSize (encInts s) + K + 6) + 100) := by
  have key := LoopLe.of_inv (prog := prog) (base := b) (i := Idx.insertZStep)
    (S := b + 11 * (valSize (encInts s) + K + 6) + 100) h4 (encIns x)
    (fun st : List ℤ × List ℤ =>
      st.1.reverseAux (st.2.orderedInsert (· ≤ ·) x) = s.orderedInsert (· ≤ ·) x ∧
      st.1.length + st.2.length = s.length ∧
      valSize (encInts st.1) + valSize (encInts st.2) = valSize (encInts s) + 1 ∧
      (∀ z ∈ st.2, bitLen z ≤ K))
    (fun out => out = encInts (s.orderedInsert (· ≤ ·) x))
    (fun st => st.2.length * (2 * K + 101) + (s.length + 1) * 34 + 2 * K + 61) ?_ ([], s)
    ⟨rfl, by simp, by simp only [valSize_encInts_nil]; omega, hK⟩
  · obtain ⟨out, rfl, hl⟩ := key
    exact hl
  rintro ⟨rp, sfx⟩ ⟨hinv, hlen, hsz, hbd⟩
  simp only at hinv hlen hsz hbd
  cases sfx with
  | nil =>
    left
    refine ⟨_, _, (insStep_nil h6 _ x rp).mono (le_refl _) ?_, ?_, ?_⟩
    · simp only [valSize_encIns]
      omega
    · simp only [List.orderedInsert_nil] at hinv
      simp only [hinv]
    · simp only [List.length_nil] at hlen ⊢
      omega
  | cons h t =>
    have hh : bitLen h ≤ K := hbd h List.mem_cons_self
    by_cases hlt : h < x
    · right
      refine ⟨1, (h :: rp, t), _, one_ne_zero,
        (insStep_cont prog _ x h rp t hlt).mono (le_refl _) ?_, ⟨?_, ?_, ?_, ?_⟩, ?_⟩
      · simp only [valSize_encIns]
        omega
      · rw [List.orderedInsert_of_not_le (· ≤ ·) t (not_le.mpr hlt)] at hinv
        exact hinv
      · simp only [List.length_cons] at hlen ⊢
        omega
      · simp only [valSize_encInts_cons] at hsz ⊢
        omega
      · exact fun z hz => hbd z (List.mem_cons_of_mem h hz)
      · simp only [List.length_cons, Nat.add_one_mul]
        omega
    · left
      refine ⟨_, _, (insStep_ge h6 _ x h rp t hlt).mono (le_refl _) ?_, ?_, ?_⟩
      · simp only [valSize_encIns]
        omega
      · rw [List.orderedInsert_cons_of_le (· ≤ ·) t (not_lt.mp hlt)] at hinv
        simp only [hinv]
      · simp only [List.length_cons] at hlen ⊢
        simp only [Nat.add_one_mul]
        omega

/-- Cost bound of `insertZ` into a list of length `n` (entries of bit length `≤ K`). -/
def C_ins (n K : ℕ) : ℕ := n * (2 * K + 101) + (n + 1) * 34 + 2 * K + 100

theorem C_ins_mono {n m : ℕ} (h : n ≤ m) (K : ℕ) : C_ins n K ≤ C_ins m K := by
  unfold C_ins
  have := Nat.mul_le_mul_right (2 * K + 101) h
  omega

/-- **Spec of `insertZ`.** -/
theorem insertZ_spec {prog : List Expr} (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (x : ℤ) (s : List ℤ) (K : ℕ) (hx : bitLen x ≤ K) (hK : ∀ z ∈ s, bitLen z ≤ K) (base : ℕ) :
    EvalsLe prog base [Val.list [Val.int x, encInts s]] body_insertZ
      (encInts (s.orderedInsert (· ≤ ·) x)) (C_ins s.length K)
      (base + 11 * (valSize (encInts s) + K + 6) + 100) := by
  have hl := insertZ_loop h4 h6 base x s K hx hK
  have hinit := EvalsLe.cons (prog := prog) (base := base)
    (env := [Val.list [Val.int x, encInts s]])
    (EvalsLe.head (EvalsLe.var (i := 0) (v := Val.list [Val.int x, encInts s]) rfl))
    (EvalsLe.cons EvalsLe.nil (EvalsLe.cons (EvalsLe.head (EvalsLe.tail
      (EvalsLe.var (i := 0) (v := Val.list [Val.int x, encInts s]) rfl))) EvalsLe.nil))
  refine (EvalsLe.loop hinit hl).mono ?_ ?_
  · simp only [C_ins]
    omega
  · simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, max_le_iff]
    omega

/-! ### `isortZ` -/

theorem isStep_stop (prog : List Expr) (base : ℕ) (s : List ℤ) :
    EvalsLe prog base [Val.list [encInts s, encInts []]] body_isortZStep
      (Val.list [Val.int 0, encInts s]) 30
      (base + 4 * valSize (Val.list [encInts s, encInts []]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_isortZStep, encInts, List.map_nil, ePair, eval_succ_var, eval_succ_lit,
    eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    one_ne_zero, not_false_eq_true, if_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem isStep_cont {prog : List Expr} (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (s : List ℤ) (h : ℤ) (t : List ℤ) (K : ℕ) (hh : bitLen h ≤ K)
    (hK : ∀ z ∈ s, bitLen z ≤ K) :
    EvalsLe prog b [Val.list [encInts s, encInts (h :: t)]] body_isortZStep
      (Val.list [Val.int 1, Val.list [encInts (s.orderedInsert (· ≤ ·) h), encInts t]])
      (C_ins s.length K + 40)
      (b + 15 * (valSize (Val.list [encInts s, encInts (h :: t)]) + K + 6) + 150) := by
  have hx1 := EvalsLe.head (prog := prog) (base := b)
    (env := [Val.list [encInts s, encInts (h :: t)]])
    (EvalsLe.tail (EvalsLe.var (i := 0) (v := Val.list [encInts s, encInts (h :: t)]) rfl))
  have hc := EvalsLe.isNil_cons (prog := prog) (base := b + valSize (encInts (h :: t)))
    (env := [encInts (h :: t), Val.list [encInts s, encInts (h :: t)]])
    (EvalsLe.var (i := 0) (v := Val.list (Val.int h :: t.map Val.int)) rfl)
  have harg := EvalsLe.pair (prog := prog)
    (base := b + valSize (encInts (h :: t)) + valSize (Val.int 1))
    (env := [encInts (h :: t), Val.list [encInts s, encInts (h :: t)]])
    (EvalsLe.head (EvalsLe.var (i := 0) (v := Val.list (Val.int h :: t.map Val.int)) rfl))
    (EvalsLe.head (EvalsLe.var (i := 1) (v := Val.list [encInts s, encInts (h :: t)]) rfl))
  have hcall := EvalsLe.call harg h3 (insertZ_spec h4 h6 h s K hh hK _)
  have htl := EvalsLe.tail (prog := prog)
    (base := b + valSize (encInts (h :: t)) + valSize (Val.int 1) +
      valSize (encInts (s.orderedInsert (· ≤ ·) h)))
    (env := [encInts (h :: t), Val.list [encInts s, encInts (h :: t)]])
    (EvalsLe.var (i := 0) (v := Val.list (Val.int h :: t.map Val.int)) rfl)
  have hbr := EvalsLe.pair (EvalsLe.lit (prog := prog) (base := b + valSize (encInts (h :: t)))
    (env := [encInts (h :: t), Val.list [encInts s, encInts (h :: t)]]) 1)
    (EvalsLe.pair hcall htl)
  refine (EvalsLe.letE hx1 (EvalsLe.ite_false hc rfl hbr)).mono ?_ ?_
  · simp only [bitLen_one]
    omega
  · have hp : valSize (encInts (s.orderedInsert (· ≤ ·) h)) = valSize (encInts (h :: s)) :=
      valSize_encInts_perm (List.perm_orderedInsert _ h s)
    simp only [hp, valSize_encInts_cons, valSize_list, valSize_int, listSize_cons, listSize_nil,
      max_le_iff, bitLen_one, bitLen_zero]
    simp only [encInts, valSize_list]
    omega

/-- The `isortZ` loop from `([], l)`. -/
theorem isortZ_loop {prog : List Expr} (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (b : ℕ) (l : List ℤ) (K : ℕ) (hK : ∀ z ∈ l, bitLen z ≤ K) :
    LoopLe prog b Idx.isortZStep (Val.list [encInts [], encInts l]) (encInts (isortRef l))
      ((l.length + 1) * (C_ins l.length K + 40 + 1))
      (b + 16 * (valSize (encInts l) + K + 10) + 200) := by
  have key := LoopLe.of_measure (prog := prog) (base := b) (i := Idx.isortZStep)
    (S := b + 16 * (valSize (encInts l) + K + 10) + 200) h2
    (fun st : List ℤ × List ℤ => Val.list [encInts st.1, encInts st.2])
    (fun st => st.2.foldl (fun s x => s.orderedInsert (· ≤ ·) x) st.1 = isortRef l ∧
      (st.1 ++ st.2).Perm l)
    (fun out => out = encInts (isortRef l)) (fun st => st.2.length) (C_ins l.length K + 40) ?_
    ([], l) ⟨rfl, by simp⟩
  · obtain ⟨out, rfl, hl⟩ := key
    exact hl
  rintro ⟨s, r⟩ ⟨hinv, hperm⟩
  simp only at hinv hperm
  have hsz : valSize (encInts s) + valSize (encInts r) = valSize (encInts l) + 1 := by
    rw [← valSize_encInts_append, valSize_encInts_perm hperm]
  have hmem : ∀ z, z ∈ s ∨ z ∈ r → bitLen z ≤ K := fun z hz =>
    hK z (hperm.subset (List.mem_append.mpr hz))
  have hslen : s.length ≤ l.length := by
    have := hperm.length_eq
    simp only [List.length_append] at this
    omega
  cases r with
  | nil =>
    left
    refine ⟨encInts s, (isStep_stop prog _ s).mono ?_ ?_, ?_⟩
    · omega
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only [List.foldl_nil] at hinv
      simp only [hinv]
  | cons h t =>
    right
    refine ⟨1, (s.orderedInsert (· ≤ ·) h, t), one_ne_zero,
      (isStep_cont h3 h4 h6 _ s h t K (hmem h (Or.inr List.mem_cons_self))
        (fun z hz => hmem z (Or.inl hz))).mono ?_ ?_, ⟨?_, ?_⟩, ?_⟩
    · have := C_ins_mono hslen K
      omega
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · exact hinv
    · exact ((List.perm_orderedInsert _ h s).append_right t).trans
        (List.perm_middle.symm.trans hperm)
    · simp

theorem isort_cost_le (n K : ℕ) : (n + 1) * (C_ins n K + 40 + 1) + 10 ≤ C_medZ n K := by
  have h0 : C_ins n K + 40 + 1 ≤ (n + 1) * (2 * K + 276) := by
    unfold C_ins
    nlinarith
  have h1 : (n + 1) * (C_ins n K + 40 + 1) ≤ (n + 1) ^ 2 * (2 * K + 276) := by
    calc (n + 1) * (C_ins n K + 40 + 1) ≤ (n + 1) * ((n + 1) * (2 * K + 276)) :=
          Nat.mul_le_mul_left _ h0
      _ = (n + 1) ^ 2 * (2 * K + 276) := by ring
  have h2 : (n + 1) ^ 2 * (2 * K + 276) ≤ (n + 1) ^ 2 * (1000 * (K + 1)) :=
    Nat.mul_le_mul_left _ (by omega)
  have h3 : 1000 * (n + 1) ^ 2 * (K + 1) = (n + 1) ^ 2 * (1000 * (K + 1)) := by ring
  unfold C_medZ
  omega

theorem le_C_medZ (n K : ℕ) : 51 * (n + 1) + 20 ≤ C_medZ n K := by
  have h1 : n + 1 ≤ (n + 1) ^ 2 := by nlinarith
  have h2 : (n + 1) ^ 2 ≤ (n + 1) ^ 2 * (K + 1) := Nat.le_mul_of_pos_right _ (Nat.succ_pos K)
  have h3 : 1000 * (n + 1) ^ 2 * (K + 1) = 1000 * ((n + 1) ^ 2 * (K + 1)) := by ring
  unfold C_medZ
  omega

theorem S_medZ_ge (n K V : ℕ) (hV : V ≤ 1 + n * (K + 2)) :
    17 * V + 16 * K + 400 ≤ S_medZ n K := by
  have h1 : 100 * (n + 1) * (K + 3) = 100 * (n * K) + 300 * n + 100 * K + 300 := by ring
  have h2 : n * (K + 2) = n * K + 2 * n := by ring
  unfold S_medZ
  omega

/-- Internal spec of `isortZ` (tighter space bound, used by `medZ`). -/
theorem isortZ_aux {prog : List Expr} (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (l : List ℤ) (K : ℕ) (hK : ∀ z ∈ l, bitLen z ≤ K) (base : ℕ) :
    EvalsLe prog base [encInts l] body_isortZ (encInts (isortRef l))
      ((l.length + 1) * (C_ins l.length K + 40 + 1) + 10)
      (base + 16 * (valSize (encInts l) + K + 10) + 200) := by
  have hl := isortZ_loop h2 h3 h4 h6 base l K hK
  have hinit := EvalsLe.pair (prog := prog) (base := base) (env := [encInts l])
    EvalsLe.nil (EvalsLe.var (i := 0) (v := encInts l) rfl)
  refine (EvalsLe.loop hinit hl).mono ?_ ?_
  · omega
  · simp only [max_le_iff, valSize_list, listSize_nil]
    omega

/-! ### The median walk -/

/-- Encoding of the walk state `j`: `[t.drop j, t.drop (2 j)]`. -/
def encW (t : List ℤ) (j : ℕ) : Val := Val.list [encInts (t.drop j), encInts (t.drop (2 * j))]

theorem walkStep_cont (prog : List Expr) (base : ℕ) (c : ℤ) (sl : List ℤ) (a d : ℤ)
    (fr : List ℤ) :
    EvalsLe prog base [Val.list [encInts (c :: sl), encInts (a :: d :: fr)]] body_medWalkStep
      (Val.list [Val.int 1, Val.list [encInts sl, encInts fr]]) 50
      (base + 4 * valSize (Val.list [encInts (c :: sl), encInts (a :: d :: fr)]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_medWalkStep, eHeadOr0, encInts, List.map_cons, ePair, eval_succ_var,
    eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, not_true_eq_false, if_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem walkStep_stop0 (prog : List Expr) (base : ℕ) (sl : List ℤ) :
    EvalsLe prog base [Val.list [encInts sl, encInts []]] body_medWalkStep
      (Val.list [Val.int 0, Val.int (sl.headD 0)]) 50
      (base + 4 * valSize (Val.list [encInts sl, encInts []]) + 30) := by
  cases sl with
  | nil =>
    apply EvalsLe.of_eval 20
    simp only [body_medWalkStep, eHeadOr0, encInts, List.map_nil, List.headD_nil,
      ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
      one_ne_zero, not_false_eq_true, if_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega
  | cons c sl =>
    apply EvalsLe.of_eval 20
    simp only [body_medWalkStep, eHeadOr0, encInts, List.map_cons, List.map_nil, List.headD_cons,
      ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false, if_false,
      one_ne_zero, not_false_eq_true, if_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega

theorem walkStep_stop1 (prog : List Expr) (base : ℕ) (sl : List ℤ) (a : ℤ) :
    EvalsLe prog base [Val.list [encInts sl, encInts [a]]] body_medWalkStep
      (Val.list [Val.int 0, Val.int (sl.headD 0)]) 50
      (base + 4 * valSize (Val.list [encInts sl, encInts [a]]) + 30) := by
  cases sl with
  | nil =>
    apply EvalsLe.of_eval 20
    simp only [body_medWalkStep, eHeadOr0, encInts, List.map_cons, List.map_nil, List.headD_nil,
      ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false, if_false,
      one_ne_zero, not_false_eq_true, if_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega
  | cons c sl =>
    apply EvalsLe.of_eval 20
    simp only [body_medWalkStep, eHeadOr0, encInts, List.map_cons, List.map_nil, List.headD_cons,
      ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false, if_false,
      one_ne_zero, not_false_eq_true, if_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega

theorem headD_drop (t : List ℤ) (j : ℕ) : (t.drop j).headD 0 = t.getD j 0 := by
  rcases lt_or_ge j t.length with hj | hj
  · rw [List.drop_eq_getElem_cons hj, List.headD_cons, List.getD_eq_getElem _ _ hj]
  · rw [List.drop_eq_nil_of_le hj, List.headD_nil, List.getD_eq_default _ _ hj]

/-- The walk from state `j` (`2 j ≤ len`) returns the entry of index `⌊len/2⌋` (`0` if none). -/
theorem walk_loop {prog : List Expr} (h5 : prog[Idx.medWalkStep]? = some body_medWalkStep)
    (b : ℕ) (t : List ℤ) :
    ∀ j : ℕ, 2 * j ≤ t.length → ∃ out, out = Val.int (t.getD (t.length / 2) 0) ∧
      LoopLe prog b Idx.medWalkStep (encW t j) out ((t.length - 2 * j + 1) * (50 + 1))
        (b + 10 * valSize (encInts t) + 50) := by
  refine LoopLe.of_measure h5 (encW t) (fun j => 2 * j ≤ t.length)
    (fun out => out = Val.int (t.getD (t.length / 2) 0)) (fun j => t.length - 2 * j) 50 ?_
  intro j hj
  have hj' : 2 * j ≤ t.length := hj
  clear hj
  have hs1 : valSize (encInts (t.drop j)) ≤ valSize (encInts t) :=
    valSize_encInts_le_of_suffix (List.drop_suffix _ _)
  have hs2 : valSize (encInts (t.drop (2 * j))) ≤ valSize (encInts t) :=
    valSize_encInts_le_of_suffix (List.drop_suffix _ _)
  rcases hfr : t.drop (2 * j) with _ | ⟨a, _ | ⟨d, fr⟩⟩
  · -- `fast = []`: `len = 2 j`
    left
    have hj2 : t.length ≤ 2 * j := List.drop_eq_nil_iff.mp hfr
    have hW : encW t j = Val.list [encInts (t.drop j), encInts []] := by
      simp only [encW, hfr]
    refine ⟨Val.int ((t.drop j).headD 0), ?_, ?_⟩
    · rw [hW]
      refine (walkStep_stop0 prog _ (t.drop j)).mono (le_refl _) ?_
      simp only [valSize_list, valSize_encInts_nil, listSize_cons, listSize_nil]
      omega
    · show Val.int ((t.drop j).headD 0) = Val.int (t.getD (t.length / 2) 0)
      rw [headD_drop]
      have : t.length / 2 = j := by omega
      rw [this]
  · -- `fast = [a]`: `len = 2 j + 1`
    left
    have hlen : t.length = 2 * j + 1 := by
      have := congrArg List.length hfr
      simp only [List.length_drop, List.length_cons, List.length_nil] at this
      omega
    have hW : encW t j = Val.list [encInts (t.drop j), encInts [a]] := by
      simp only [encW, hfr]
    rw [hfr] at hs2
    refine ⟨Val.int ((t.drop j).headD 0), ?_, ?_⟩
    · rw [hW]
      refine (walkStep_stop1 prog _ (t.drop j) a).mono (le_refl _) ?_
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · show Val.int ((t.drop j).headD 0) = Val.int (t.getD (t.length / 2) 0)
      rw [headD_drop]
      have : t.length / 2 = j := by omega
      rw [this]
  · -- `fast = a :: d :: fr`: continue
    right
    have hlen : 2 * j + 2 ≤ t.length := by
      have := congrArg List.length hfr
      simp only [List.length_drop, List.length_cons] at this
      omega
    have hjl : j < t.length := by omega
    have hsl : t.drop j = t[j] :: t.drop (j + 1) := List.drop_eq_getElem_cons hjl
    have hfr2 : t.drop (2 * (j + 1)) = fr := by
      have e1 : t.drop (2 * (j + 1)) = (t.drop (2 * j)).drop 2 := by
        rw [List.drop_drop, show 2 * j + 2 = 2 * (j + 1) by ring]
      rw [e1, hfr]
      rfl
    have hW : encW t j = Val.list [encInts (t[j] :: t.drop (j + 1)), encInts (a :: d :: fr)] := by
      simp only [encW, hfr, hsl]
    have hW' : encW t (j + 1) = Val.list [encInts (t.drop (j + 1)), encInts fr] := by
      simp only [encW, hfr2]
    rw [hfr] at hs2
    rw [hsl] at hs1
    refine ⟨1, j + 1, one_ne_zero, ?_, ?_, ?_⟩
    · rw [hW, hW']
      refine (walkStep_cont prog _ t[j] (t.drop (j + 1)) a d fr).mono (le_refl _) ?_
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · show 2 * (j + 1) ≤ t.length
      omega
    · show t.length - 2 * (j + 1) < t.length - 2 * j
      omega

end Arith

open Arith

/-- **Spec of `isortZ`.** -/
theorem isortZ_spec {prog : List Expr} (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (l : List ℤ) (K : ℕ) (hK : ∀ z ∈ l, bitLen z ≤ K) (base : ℕ) :
    EvalsLe prog base [encInts l] body_isortZ (encInts (isortRef l)) (C_medZ l.length K)
      (base + S_medZ l.length K) := by
  have hV := valSize_encInts_le l K hK
  have hS := S_medZ_ge l.length K _ hV
  refine (isortZ_aux h2 h3 h4 h6 l K hK base).mono (isort_cost_le l.length K) ?_
  omega

/-- **Spec of `medZ`.** -/
theorem medZ_spec {prog : List Expr} (h1 : prog[Idx.isortZ]? = some body_isortZ)
    (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h5 : prog[Idx.medWalkStep]? = some body_medWalkStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (l : List ℤ) (K : ℕ) (hK : ∀ z ∈ l, bitLen z ≤ K) (base : ℕ) :
    EvalsLe prog base [encInts l] body_medZ (encZ (medZ l)) (2 * C_medZ l.length K)
      (base + S_medZ l.length K) := by
  have hperm : (isortRef l).Perm l := by
    have h := isortAux_perm l []
    rw [List.nil_append] at h
    exact h
  have hVt : valSize (encInts (isortRef l)) = valSize (encInts l) := valSize_encInts_perm hperm
  have hlen : (isortRef l).length = l.length := hperm.length_eq
  have hcall := EvalsLe.call (EvalsLe.var (prog := prog) (base := base) (env := [encInts l])
    (i := 0) (v := encInts l) rfl) h1
    (isortZ_aux h2 h3 h4 h6 l K hK (base + valSize (encInts l)))
  obtain ⟨out, hout, hl⟩ := walk_loop h5 (base + valSize (encInts (isortRef l))) (isortRef l) 0
    (by omega)
  have hmed : out = encZ (medZ l) := by
    rw [hout, hlen, isortRef_eq_mergeSort]
    rfl
  rw [hmed] at hl
  have hinit := EvalsLe.pair (prog := prog) (base := base + valSize (encInts (isortRef l)))
    (env := [encInts (isortRef l), encInts l])
    (EvalsLe.var (i := 0) (v := encInts (isortRef l)) rfl)
    (EvalsLe.var (i := 0) (v := encInts (isortRef l)) rfl)
  have hloop := EvalsLe.loop hinit hl
  have hV := valSize_encInts_le l K hK
  have hS := S_medZ_ge l.length K _ hV
  have hc1 := isort_cost_le l.length K
  have hc2 := le_C_medZ l.length K
  refine (EvalsLe.letE hcall hloop).mono ?_ ?_
  · rw [hlen]
    omega
  · simp only [max_le_iff]
    omega

/-- **Spec of `call Idx.medZ`** (for callers). -/
theorem medZ_call {prog : List Expr} (h0 : prog[Idx.medZ]? = some body_medZ)
    (h1 : prog[Idx.isortZ]? = some body_isortZ)
    (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h5 : prog[Idx.medWalkStep]? = some body_medWalkStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    {base : ℕ} {env : List Val} {a : Expr} {l : List ℤ} {K Ca Sa : ℕ}
    (hK : ∀ z ∈ l, bitLen z ≤ K) (ha : EvalsLe prog base env a (encInts l) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.medZ a) (encZ (medZ l)) (1 + Ca + 2 * C_medZ l.length K)
      (max Sa (base + valSize (encInts l) + S_medZ l.length K)) :=
  EvalsLe.call ha h0 (medZ_spec h1 h2 h3 h4 h5 h6 l K hK _)

end F2e2e.Cost