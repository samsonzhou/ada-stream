import F2e2e.Cost.Arith.AExp

/-!
# Correctness and cost of compiled `AExp` code (owner de4dddbc) — port of cut2 `Cost/Arith/AExpSpec.lean`

* `CallOK prog j f K Cc Sc`: function `j` of `prog` computes `f : ℕ → ℕ` (input `encN x`, output
  `encN (f x)`) within cost `Cc` and extra space `Sc` whenever `size x ≤ K` and `size (f x) ≤ K`.
* `AExp.Good prog K Cc Sc env e`: variables in range, every intermediate value of bit length `≤ K`,
  nonzero divisors, all calls `CallOK`.
* `AExp.spec`: under `Good`, `e.toExpr pre.length` evaluates in `pre ++ env.map encN ++ rest` to
  `encN (e.val env)` within `e.cost K Cc` and `base + e.space K Sc`.
* `letChain_spec`: the same for a chain of let-bound expressions followed by a body.
* `mkVarList_spec`: the list of variables.
-/

namespace F2e2e.Cost.Arith
/-- Function `j` of `prog` computes `f` within uniform bounds on arguments/results of size `≤ K`. -/
def CallOK (prog : List Expr) (j : ℕ) (f : ℕ → ℕ) (K Cc Sc : ℕ) : Prop :=
  ∃ body, prog[j]? = some body ∧ ∀ x base : ℕ, Nat.size x ≤ K → Nat.size (f x) ≤ K →
    EvalsLe prog base [encN x] body (encN (f x)) Cc (base + Sc)

namespace AExp

/-- Side conditions for evaluating `e` in the numeric environment `env` within bit budget `K`. -/
def Good (prog : List Expr) (K Cc Sc : ℕ) (env : List ℕ) : AExp → Prop
  | var i => i < env.length ∧ Nat.size (env.getD i 0) ≤ K
  | lit k => Nat.size k ≤ K
  | add a b => a.Good prog K Cc Sc env ∧ b.Good prog K Cc Sc env ∧
      Nat.size (a.val env + b.val env) ≤ K
  | mul a b => a.Good prog K Cc Sc env ∧ b.Good prog K Cc Sc env ∧
      Nat.size (a.val env * b.val env) ≤ K
  | tsub a b => a.Good prog K Cc Sc env ∧ b.Good prog K Cc Sc env
  | div a b => a.Good prog K Cc Sc env ∧ b.Good prog K Cc Sc env ∧ b.val env ≠ 0
  | max a b => a.Good prog K Cc Sc env ∧ b.Good prog K Cc Sc env
  | call j f a => a.Good prog K Cc Sc env ∧ CallOK prog j f K Cc Sc ∧
      Nat.size (f (a.val env)) ≤ K

/-- Cost bound of compiled code (bit budget `K`, call cost `Cc`). -/
def cost (K Cc : ℕ) : AExp → ℕ
  | var _ => 1
  | lit _ => K + 1
  | add a b => a.cost K Cc + b.cost K Cc + 2 * K + 2
  | mul a b => a.cost K Cc + b.cost K Cc + (K + 1) * (K + 1) + 2
  | tsub a b => a.cost K Cc + b.cost K Cc + 4 * K + 11
  | div a b => a.cost K Cc + b.cost K Cc + (K + 1) * (K + 1) + 2
  | max a b => a.cost K Cc + b.cost K Cc + 2 * K + 9
  | call _ _ a => a.cost K Cc + Cc + 1

/-- Space bound (above the base) of compiled code (bit budget `K`, call space `Sc`). -/
def space (K Sc : ℕ) : AExp → ℕ
  | var _ => K + 1
  | lit _ => K + 1
  | add a b => Max.max (a.space K Sc) (K + 1 + b.space K Sc) + 3 * K + 3
  | mul a b => Max.max (a.space K Sc) (K + 1 + b.space K Sc) + 3 * K + 3
  | tsub a b => Max.max (a.space K Sc) (K + 1 + b.space K Sc) + 5 * K + 10
  | div a b => Max.max (a.space K Sc) (K + 1 + b.space K Sc) + 3 * K + 3
  | max a b => Max.max (a.space K Sc) (K + 1 + b.space K Sc) + 5 * K + 10
  | call _ _ a => Max.max (a.space K Sc) (K + 1 + Sc)

variable {prog : List Expr} {K Cc Sc : ℕ}

theorem space_ge : ∀ e : AExp, K + 1 ≤ e.space K Sc
  | var _ => le_refl _
  | lit _ => le_refl _
  | add _ _ => by simp only [space]; omega
  | mul _ _ => by simp only [space]; omega
  | tsub _ _ => by simp only [space]; omega
  | div _ _ => by simp only [space]; omega
  | max _ _ => by simp only [space]; omega
  | call _ _ _ => by simp only [space]; omega

theorem size_val_le {env : List ℕ} : ∀ e : AExp, e.Good prog K Cc Sc env →
    Nat.size (e.val env) ≤ K
  | var _, h => h.2
  | lit _, h => h
  | add _ _, h => h.2.2
  | mul _ _, h => h.2.2
  | tsub a _, h => (Nat.size_le_size (Nat.sub_le _ _)).trans (size_val_le a h.1)
  | div a _, h => (Nat.size_le_size (Nat.div_le_self _ _)).trans (size_val_le a h.1)
  | max a b, h => by
      simp only [val]
      rcases le_total (a.val env) (b.val env) with hab | hab
      · rw [max_eq_right hab]; exact size_val_le b h.2
      · rw [max_eq_left hab]; exact size_val_le a h.1
  | call _ _ _, h => h.2.2

theorem bitLen_val_le {env : List ℕ} (e : AExp) (h : e.Good prog K Cc Sc env) :
    bitLen ((e.val env : ℕ) : ℤ) ≤ K := by
  rw [bitLen_natCast]; exact size_val_le e h

theorem valSize_encN_val_le {env : List ℕ} (e : AExp) (h : e.Good prog K Cc Sc env) :
    valSize (encN (e.val env)) ≤ K + 1 := by
  rw [valSize_encN]; have := size_val_le e h; omega

/-- **Correctness and cost of compiled `AExp` code.** -/
theorem spec (envN : List ℕ) (rest : List Val) :
    ∀ (e : AExp) (pre : List Val) (base : ℕ), e.Good prog K Cc Sc envN →
      EvalsLe prog base (pre ++ (envN.map encN ++ rest)) (e.toExpr pre.length)
        (encN (e.val envN)) (e.cost K Cc) (base + e.space K Sc) := by
  intro e
  induction e with
  | var i =>
    intro pre base h
    obtain ⟨hi, hs⟩ := h
    have hget : (pre ++ (envN.map encN ++ rest))[i + pre.length]? =
        some (encN (envN.getD i 0)) := by
      rw [List.getElem?_append_right (by omega), Nat.add_sub_cancel,
        List.getElem?_append_left (by simp; omega), List.getElem?_map]
      simp [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hi]
    refine (EvalsLe.var hget).mono (by simp [cost]) ?_
    simp only [space, valSize_encN]
    omega
  | lit k =>
    intro pre base h
    have hk : Nat.size k ≤ K := h
    have := EvalsLe.lit (prog := prog) (base := base) (env := pre ++ (envN.map encN ++ rest))
      (k : ℤ)
    refine this.mono ?_ ?_
    · simp only [cost, bitLen_natCast]; omega
    · simp only [space, valSize_int, bitLen_natCast]; omega
  | add a b iha ihb =>
    intro pre base h
    obtain ⟨ga, gb, hs⟩ := h
    have ha := iha pre base ga
    have hb := ihb pre (base + valSize (encN (a.val envN))) gb
    have h := EvalsLe.add ha hb
    have hv : encN ((add a b).val envN) =
        Val.int ((a.val envN : ℤ) + (b.val envN : ℤ)) := by simp [encN, val]
    rw [hv]
    have h1 := bitLen_val_le a ga
    have h2 := bitLen_val_le b gb
    have h3 : bitLen (((a.val envN : ℤ) + (b.val envN : ℤ))) ≤ K := by
      have : ((a.val envN : ℤ) + (b.val envN : ℤ)) = ((a.val envN + b.val envN : ℕ) : ℤ) := by
        push_cast; ring
      rw [this, bitLen_natCast]; exact hs
    refine h.mono ?_ ?_
    · simp only [cost]; omega
    · simp only [space, valSize_int, encN, max_le_iff] at h1 h2 h3 ⊢
      omega
  | mul a b iha ihb =>
    intro pre base h
    obtain ⟨ga, gb, hs⟩ := h
    have ha := iha pre base ga
    have hb := ihb pre (base + valSize (encN (a.val envN))) gb
    have h := EvalsLe.mul ha hb
    have hv : encN ((mul a b).val envN) =
        Val.int ((a.val envN : ℤ) * (b.val envN : ℤ)) := by simp [encN, val]
    rw [hv]
    have h1 := bitLen_val_le a ga
    have h2 := bitLen_val_le b gb
    have h3 : bitLen (((a.val envN : ℤ) * (b.val envN : ℤ))) ≤ K := by
      have : ((a.val envN : ℤ) * (b.val envN : ℤ)) = ((a.val envN * b.val envN : ℕ) : ℤ) := by
        push_cast; ring
      rw [this, bitLen_natCast]; exact hs
    refine h.mono ?_ ?_
    · simp only [cost]
      have : (bitLen (a.val envN : ℤ) + 1) * (bitLen (b.val envN : ℤ) + 1) ≤ (K + 1) * (K + 1) :=
        Nat.mul_le_mul (by omega) (by omega)
      omega
    · simp only [space, valSize_int, encN, max_le_iff] at h1 h2 h3 ⊢
      omega
  | div a b iha ihb =>
    intro pre base h
    obtain ⟨ga, gb, hne⟩ := h
    have ha := iha pre base ga
    have hb := ihb pre (base + valSize (encN (a.val envN))) gb
    have hne' : ((b.val envN : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hne
    have h := EvalsLe.div ha hb hne'
    have hv : encN ((div a b).val envN) =
        Val.int ((a.val envN : ℤ) / (b.val envN : ℤ)) := by simp [encN, val]
    rw [hv]
    have h1 := bitLen_val_le a ga
    have h2 := bitLen_val_le b gb
    have h3 : bitLen (((a.val envN : ℤ) / (b.val envN : ℤ))) ≤ K := by
      have : ((a.val envN : ℤ) / (b.val envN : ℤ)) = ((a.val envN / b.val envN : ℕ) : ℤ) := by
        push_cast; rfl
      rw [this, bitLen_natCast]
      exact (Nat.size_le_size (Nat.div_le_self _ _)).trans (size_val_le a ga)
    refine h.mono ?_ ?_
    · simp only [cost]
      have : (bitLen (a.val envN : ℤ) + 1) * (bitLen (b.val envN : ℤ) + 1) ≤ (K + 1) * (K + 1) :=
        Nat.mul_le_mul (by omega) (by omega)
      omega
    · simp only [space, valSize_int, encN, max_le_iff] at h1 h2 h3 ⊢
      omega
  | tsub a b iha ihb =>
    intro pre base h
    obtain ⟨ga, gb⟩ := h
    simp only [toExpr]
    have ha := iha pre base ga
    have hb := ihb (encN (a.val envN) :: pre) (base + valSize (encN (a.val envN))) gb
    simp only [List.length_cons, List.cons_append] at hb
    have h1 := bitLen_val_le a ga
    have h2 := bitLen_val_le b gb
    set x := a.val envN with hx
    set y := b.val envN with hy
    have hite : EvalsLe prog (base + valSize (encN x) + valSize (encN y))
        (encN y :: encN x :: (pre ++ (envN.map encN ++ rest)))
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.lit 0)
          (Expr.bin BinOp.sub (Expr.var 1) (Expr.var 0)))
        (encN (x - y)) (4 * K + 9)
        (base + valSize (encN x) + valSize (encN y) + 3 * K + 6) := by
      have hlt := EvalsLe.lt (prog := prog) (base := base + valSize (encN x) + valSize (encN y))
        (env := encN y :: encN x :: (pre ++ (envN.map encN ++ rest)))
        (EvalsLe.var (i := 1) (v := Val.int (x : ℤ)) rfl)
        (EvalsLe.var (i := 0) (v := Val.int (y : ℤ)) rfl)
      by_cases hxy : x < y
      · have hz : (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≠ 0 := by
          rw [if_pos (by exact_mod_cast hxy)]; norm_num
        have hv : encN (x - y) = Val.int 0 := by
          simp [encN, Nat.sub_eq_zero_of_le hxy.le]
        rw [hv]
        refine (EvalsLe.ite_true hlt hz (EvalsLe.lit 0)).mono ?_ ?_
        · simp only [bitLen_zero]; omega
        · simp only [encN, valSize_int, max_le_iff, bitLen_zero] at h1 h2 ⊢
          have : bitLen (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≤ 1 := by
            split_ifs <;> simp
          omega
      · have hz : (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) = 0 := by
          rw [if_neg (by exact_mod_cast hxy)]
        have hle : y ≤ x := not_lt.mp hxy
        have hv : encN (x - y) = Val.int ((x : ℤ) - (y : ℤ)) := by
          simp [encN, Nat.cast_sub hle]
        rw [hv]
        have hsub := EvalsLe.sub (prog := prog)
          (base := base + valSize (encN x) + valSize (encN y))
          (env := encN y :: encN x :: (pre ++ (envN.map encN ++ rest)))
          (EvalsLe.var (i := 1) (v := Val.int (x : ℤ)) rfl)
          (EvalsLe.var (i := 0) (v := Val.int (y : ℤ)) rfl)
        have h3 : bitLen ((x : ℤ) - (y : ℤ)) ≤ K := by
          rw [← Nat.cast_sub hle, bitLen_natCast]
          exact (Nat.size_le_size (Nat.sub_le _ _)).trans (size_val_le a ga)
        refine (EvalsLe.ite_false hlt hz hsub).mono ?_ ?_
        · omega
        · simp only [encN, valSize_int, max_le_iff] at h1 h2 h3 ⊢
          have : bitLen (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≤ 1 := by
            split_ifs <;> simp
          omega
    have hv : encN ((tsub a b).val envN) = encN (x - y) := rfl
    rw [hv]
    refine (EvalsLe.letE ha (EvalsLe.letE hb hite)).mono ?_ ?_
    · simp only [cost]; omega
    · have hsb := space_ge (K := K) (Sc := Sc) b
      simp only [space, encN, valSize_int, max_le_iff] at h1 h2 ⊢
      omega
  | max a b iha ihb =>
    intro pre base h
    obtain ⟨ga, gb⟩ := h
    simp only [toExpr]
    have ha := iha pre base ga
    have hb := ihb (encN (a.val envN) :: pre) (base + valSize (encN (a.val envN))) gb
    simp only [List.length_cons, List.cons_append] at hb
    have h1 := bitLen_val_le a ga
    have h2 := bitLen_val_le b gb
    set x := a.val envN with hx
    set y := b.val envN with hy
    have hite : EvalsLe prog (base + valSize (encN x) + valSize (encN y))
        (encN y :: encN x :: (pre ++ (envN.map encN ++ rest)))
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 0) (Expr.var 1))
        (encN (Max.max x y)) (2 * K + 7)
        (base + valSize (encN x) + valSize (encN y) + 3 * K + 6) := by
      have hlt := EvalsLe.lt (prog := prog) (base := base + valSize (encN x) + valSize (encN y))
        (env := encN y :: encN x :: (pre ++ (envN.map encN ++ rest)))
        (EvalsLe.var (i := 1) (v := Val.int (x : ℤ)) rfl)
        (EvalsLe.var (i := 0) (v := Val.int (y : ℤ)) rfl)
      by_cases hxy : x < y
      · have hz : (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≠ 0 := by
          rw [if_pos (by exact_mod_cast hxy)]; norm_num
        rw [max_eq_right hxy.le]
        refine (EvalsLe.ite_true hlt hz (EvalsLe.var (i := 0) (v := encN y) rfl)).mono ?_ ?_
        · omega
        · simp only [encN, valSize_int, max_le_iff] at h1 h2 ⊢
          have : bitLen (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≤ 1 := by
            split_ifs <;> simp
          omega
      · have hz : (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) = 0 := by
          rw [if_neg (by exact_mod_cast hxy)]
        rw [max_eq_left (not_lt.mp hxy)]
        refine (EvalsLe.ite_false hlt hz (EvalsLe.var (i := 1) (v := encN x) rfl)).mono ?_ ?_
        · omega
        · simp only [encN, valSize_int, max_le_iff] at h1 h2 ⊢
          have : bitLen (if (x : ℤ) < (y : ℤ) then (1 : ℤ) else 0) ≤ 1 := by
            split_ifs <;> simp
          omega
    have hv : encN ((max a b).val envN) = encN (Max.max x y) := rfl
    rw [hv]
    refine (EvalsLe.letE ha (EvalsLe.letE hb hite)).mono ?_ ?_
    · simp only [cost]; omega
    · have hsb := space_ge (K := K) (Sc := Sc) b
      simp only [space, encN, valSize_int, max_le_iff] at h1 h2 ⊢
      omega
  | call j f a iha =>
    intro pre base h
    obtain ⟨ga, ⟨body, hbody, hcall⟩, hs⟩ := h
    simp only [toExpr]
    have ha := iha pre base ga
    have hsa := size_val_le a ga
    have hc := hcall (a.val envN) (base + valSize (encN (a.val envN))) hsa hs
    refine (EvalsLe.call ha hbody hc).mono ?_ ?_
    · simp only [cost]; omega
    · have := valSize_encN_val_le a ga
      simp only [space, max_le_iff]
      omega

end AExp

/-! ### Chains of let-bound expressions -/

/-- Side conditions of a chain. -/
def ChainGood (prog : List Expr) (K Cc Sc : ℕ) : List AExp → List ℕ → Prop
  | [], _ => True
  | e :: es, env => e.Good prog K Cc Sc env ∧ ChainGood prog K Cc Sc es (e.val env :: env)

/-- Cost of a chain (without the body). -/
def chainCost (K Cc : ℕ) : List AExp → ℕ
  | [] => 0
  | e :: es => 1 + e.cost K Cc + chainCost K Cc es

/-- Space of a chain (above the base, without the body's own space). -/
def chainSpace (K Sc : ℕ) : List AExp → ℕ
  | [] => 0
  | e :: es => Max.max (e.space K Sc) (K + 1 + chainSpace K Sc es)

theorem letChain_spec {prog : List Expr} {K Cc Sc : ℕ} (rest : List Val) (body : Expr) (v : Val)
    (Cb Sb : ℕ) :
    ∀ (es : List AExp) (envN : List ℕ) (base : ℕ), ChainGood prog K Cc Sc es envN →
      (∀ b : ℕ, EvalsLe prog b ((chainEnv es envN).map encN ++ rest) body v Cb (b + Sb)) →
      EvalsLe prog base (envN.map encN ++ rest) (letChain es body) v (chainCost K Cc es + Cb)
        (base + chainSpace K Sc es + Sb)
  | [], envN, base, _, hb => by
    simpa [letChain, chainCost, chainSpace, chainEnv] using hb base
  | e :: es, envN, base, ⟨ge, ges⟩, hb => by
    have he := AExp.spec envN rest e [] base ge
    simp only [List.nil_append, List.length_nil] at he
    have hrest := letChain_spec rest body v Cb Sb es (e.val envN :: envN)
      (base + valSize (encN (e.val envN))) ges (by simpa [chainEnv] using hb)
    simp only [List.map_cons, List.cons_append] at hrest
    have hvs := AExp.valSize_encN_val_le e ge
    refine (EvalsLe.letE he hrest).mono ?_ ?_
    · simp only [chainCost]; omega
    · simp only [chainSpace, max_le_iff]; omega

/-! ### Lists of variables -/

theorem mkVarList_spec {prog : List Expr} (env : List Val) (base : ℕ) :
    ∀ (is : List ℕ) (vs : List Val), is.map (fun i => env[i]?) = vs.map some →
      EvalsLe prog base env (mkVarList is) (Val.list vs) (3 * is.length + 1)
        (base + 2 * valSize (Val.list vs))
  | [], vs, h => by
    have hvs : vs = [] := by
      cases vs with
      | nil => rfl
      | cons v vs => simp at h
    subst hvs
    refine (EvalsLe.nil (prog := prog) (base := base) (env := env)).mono (by simp) ?_
    simp
  | i :: is, vs, h => by
    cases vs with
    | nil => simp at h
    | cons v vs =>
      simp only [List.map_cons, List.cons.injEq] at h
      obtain ⟨hi, his⟩ := h
      have hrest := mkVarList_spec (prog := prog) env (base + valSize v) is vs his
      have h := EvalsLe.cons (EvalsLe.var (prog := prog) (base := base) hi) hrest
      refine h.mono (by simp only [List.length_cons]; omega) ?_
      simp only [valSize_list, listSize_cons, max_le_iff]
      omega

end F2e2e.Cost.Arith