import F2e2e.Cost.Lib.Util

/-!
# ARITH (Idx 100–149): integer utilities (owner de4dddbc) — port of cut2 `Cost/Arith/Basic.lean`

Reference functions and DSL routines (inputs/outputs as in `notes/DSL_CONVENTION.md`):

| routine | index | input | output |
|---|---|---|---|
| `pow2` | `Idx.pow2` (loop `Idx.pow2Step`) | `encN k` | `encN (2 ^ k)` |
| `clog2` | `Idx.clog2` (loop `Idx.clog2Step`) | `encN m` | `encN (Nat.clog 2 m)` |
| `natSize` | `Idx.natSize` (loop `Idx.natSizeStep`) | `encN m` | `encN (Nat.size m)` |
| `testBitN` | `Idx.testBitN` (calls `pow2`) | `[encN m, encN i]` | `encB (m.testBit i)` |
| `lowBitsN` | `Idx.lowBitsN` (calls `pow2`) | `[encN m, encN b]` | `encN (m % 2 ^ b)` |
| `shiftRN` | `Idx.shiftRN` (calls `pow2`) | `[encN m, encN b]` | `encN (m / 2 ^ b)` |
| `minZ` | `Idx.minZ` | `[encZ a, encZ b]` | `encZ (min a b)` |
| `maxZ` | `Idx.maxZ` | `[encZ a, encZ b]` | `encZ (max a b)` |

Loops: `pow2` iterates `[k, p] ↦ [k - 1, 2p]` from `[k, 1]`; `clog2` iterates `[k, p, m]` from
`[0, 1, m]` while `p < m` (stops with the least `k` with `m ≤ 2^k`); `natSize` iterates while `p ≤ m`
(stops with the least `k` with `m < 2^k`).

Status: contracts published (bodies, bounds, statements); proofs in progress.
-/

namespace F2e2e.Cost
namespace Idx

/-! ### ARITH indices (100–149) -/

/-- `pow2 : k ↦ 2^k`. -/
abbrev pow2 : ℕ := 100
/-- Loop body of `pow2`. -/
abbrev pow2Step : ℕ := 101
/-- `clog2 : m ↦ Nat.clog 2 m`. -/
abbrev clog2 : ℕ := 102
/-- Loop body of `clog2`. -/
abbrev clog2Step : ℕ := 103
/-- `natSize : m ↦ Nat.size m`. -/
abbrev natSize : ℕ := 104
/-- Loop body of `natSize`. -/
abbrev natSizeStep : ℕ := 105
/-- `testBitN : [m, i] ↦ m.testBit i`. -/
abbrev testBitN : ℕ := 106
/-- `lowBitsN : [m, b] ↦ m % 2^b`. -/
abbrev lowBitsN : ℕ := 107
/-- `shiftRN : [m, b] ↦ m / 2^b`. -/
abbrev shiftRN : ℕ := 108
/-- `minZ : [a, b] ↦ min a b`. -/
abbrev minZ : ℕ := 109
/-- `maxZ : [a, b] ↦ max a b`. -/
abbrev maxZ : ℕ := 110

end Idx

namespace Arith

/-- The expression building the three-element list `[a, b, c]`. -/
def eTriple (a b c : Expr) : Expr :=
  Expr.bin BinOp.cons a (Expr.bin BinOp.cons b (Expr.bin BinOp.cons c Expr.nil))

theorem bitLen_two : bitLen 2 = 2 := rfl

end Arith

open Arith

/-! ## `pow2` -/

/-- Loop body of `pow2`. Environment `[acc]`, `acc = [k, p]`: `[0, p] ↦ [0, p]` (stop),
`[k, p] ↦ [1, [k - 1, p + p]]`. -/
def body_pow2Step : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                            -- k   env [k, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))     -- p   env [p, k, acc]
      (Expr.ite (Expr.bin BinOp.eq (Expr.var 1) (Expr.lit 0))
        (ePair (Expr.lit 0) (Expr.var 0))
        (ePair (Expr.lit 1)
          (ePair (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
            (Expr.bin BinOp.add (Expr.var 0) (Expr.var 0))))))

/-- `pow2 : k ↦ 2^k`. Environment `[encN k]`. -/
def body_pow2 : Expr := Expr.loop Idx.pow2Step (ePair (Expr.var 0) (Expr.lit 1))

/-- Cost bound of `pow2`. -/
def C_pow2 (k : ℕ) : ℕ := (k + 1) * (2 * k + 2 * Nat.size k + 50) + 20

/-- Space bound of `pow2` (on top of the base). -/
def S_pow2 (k : ℕ) : ℕ := 10 * (k + Nat.size k) + 100

theorem pow2Step_zero (prog : List Expr) (base : ℕ) (p : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int p]] body_pow2Step
      (Val.list [Val.int 0, Val.int p]) 30
      (base + 4 * valSize (Val.list [Val.int 0, Val.int p]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_pow2Step, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, if_true,
    one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem pow2Step_succ (prog : List Expr) (base : ℕ) (k p : ℤ) (hk : k ≠ 0) :
    EvalsLe prog base [Val.list [Val.int k, Val.int p]] body_pow2Step
      (Val.list [Val.int 1, Val.list [Val.int (k - 1), Val.int (p + p)]])
      (40 + 2 * bitLen k + 2 * bitLen p)
      (base + 4 * valSize (Val.list [Val.int k, Val.int p]) + 2 * bitLen (k - 1) +
        2 * bitLen (p + p) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_pow2Step, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin,
    eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk, if_false,
    not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

/-- Encoding of the `pow2` loop state `(k', p)`. -/
def encP2 (s : ℕ × ℕ) : Val := Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ)]

theorem pow2_loop {prog : List Expr} (h : prog[Idx.pow2Step]? = some body_pow2Step)
    (k base : ℕ) :
    ∀ s : ℕ × ℕ, (s.1 ≤ k ∧ s.2 * 2 ^ s.1 = 2 ^ k) →
      ∃ out, out = encN (2 ^ k) ∧
        LoopLe prog base Idx.pow2Step (encP2 s) out
          ((s.1 + 1) * (2 * k + 2 * Nat.size k + 45 + 1)) (base + S_pow2 k) := by
  refine LoopLe.of_measure h encP2 _ _ (fun s => s.1) (2 * k + 2 * Nat.size k + 45) ?_
  rintro ⟨j, p⟩ ⟨hj, hp⟩
  simp only at hj hp
  have hpk : p ≤ 2 ^ k := by
    rw [← hp]
    exact Nat.le_mul_of_pos_right p (Nat.two_pow_pos j)
  have hBp : bitLen (p : ℤ) ≤ k + 1 := by
    rw [bitLen_natCast]
    calc Nat.size p ≤ Nat.size (2 ^ k) := Nat.size_le_size hpk
      _ = k + 1 := Nat.size_pow
  have hBj : bitLen (j : ℤ) ≤ Nat.size k := bitLen_le_size_of_le hj
  cases j with
  | zero =>
    left
    refine ⟨Val.int (p : ℤ), ?_, ?_⟩
    · refine (pow2Step_zero prog _ p).mono (by omega) ?_
      simp only [encP2, S_pow2, valSize_int, valSize_list, listSize_cons, listSize_nil,
        Nat.cast_zero, bitLen_zero] at hBp ⊢
      omega
    · simp only [pow_zero, mul_one] at hp
      simp [encN, hp]
  | succ j =>
    right
    have hk1 : ((j + 1 : ℕ) : ℤ) ≠ 0 := by omega
    have hp2 : 2 * p ≤ 2 ^ k := by
      rw [← hp, pow_succ]
      nlinarith [Nat.two_pow_pos j]
    have hBp2 : bitLen ((p : ℤ) + (p : ℤ)) ≤ k + 1 := by
      have : ((p : ℤ) + (p : ℤ)) = ((2 * p : ℕ) : ℤ) := by push_cast; ring
      rw [this, bitLen_natCast]
      calc Nat.size (2 * p) ≤ Nat.size (2 ^ k) := Nat.size_le_size hp2
        _ = k + 1 := Nat.size_pow
    have hBj1 : bitLen (((j + 1 : ℕ) : ℤ) - 1) ≤ Nat.size k := by
      have := bitLen_le_size_of_le (show j ≤ k by omega)
      simpa using this
    have henc : encP2 (j, 2 * p) =
        Val.list [Val.int (((j + 1 : ℕ) : ℤ) - 1), Val.int ((p : ℤ) + (p : ℤ))] := by
      simp only [encP2]
      push_cast
      ring_nf
    refine ⟨1, (j, 2 * p), one_ne_zero, ?_, ⟨?_, ?_⟩, ?_⟩
    · rw [henc]
      refine (pow2Step_succ prog _ _ _ hk1).mono (by dsimp only; omega) ?_
      simp only [encP2, S_pow2, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only
      omega
    · simp only
      rw [← hp, pow_succ]
      ring
    · simp

/-- **Spec of `pow2`.** -/
theorem pow2_spec {prog : List Expr} (h : prog[Idx.pow2Step]? = some body_pow2Step)
    (k base : ℕ) :
    EvalsLe prog base [encN k] body_pow2 (encN (2 ^ k)) (C_pow2 k) (base + S_pow2 k) := by
  obtain ⟨out, rfl, hloop⟩ := pow2_loop h k base (k, 1) ⟨le_refl k, by ring⟩
  have hinit : EvalsLe prog base [encN k] (ePair (Expr.var 0) (Expr.lit 1))
      (encP2 (k, 1)) 8 (base + 2 * valSize (encN k) + 9) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [encN k])
      (EvalsLe.var (i := 0) (v := encN k) rfl) (EvalsLe.lit 1)
    refine this.mono (by simp) ?_
    simp only [encN, valSize_int, bitLen_one, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_pow2]
    nlinarith
  · have hk : valSize (encN k) = Nat.size k + 1 := valSize_encN k
    have hs : Nat.size k ≤ k := size_le_self k
    simp only [S_pow2, max_le_iff, hk]
    omega

/-- **Spec of `call Idx.pow2`** (for callers). -/
theorem pow2_call {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) {base : ℕ} {env : List Val} {a : Expr}
    {k Ca Sa : ℕ} (ha : EvalsLe prog base env a (encN k) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.pow2 a) (encN (2 ^ k)) (1 + Ca + C_pow2 k)
      (max Sa (base + valSize (encN k) + S_pow2 k)) :=
  EvalsLe.call ha h1 (pow2_spec h2 k _)

/-! ## `clog2` -/

/-- Loop body of `clog2`. Environment `[acc]`, `acc = [k, p, m]`: if `p < m` continue with
`[k + 1, p + p, m]`, otherwise stop with `k`. -/
def body_clog2Step : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                       -- k
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))                -- p
      (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))  -- m
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0))
          (ePair (Expr.lit 1)
            (eTriple (Expr.bin BinOp.add (Expr.var 2) (Expr.lit 1))
              (Expr.bin BinOp.add (Expr.var 1) (Expr.var 1)) (Expr.var 0)))
          (ePair (Expr.lit 0) (Expr.var 2)))))

/-- `clog2 : m ↦ Nat.clog 2 m`. Environment `[encN m]`. -/
def body_clog2 : Expr := Expr.loop Idx.clog2Step (eTriple (Expr.lit 0) (Expr.lit 1) (Expr.var 0))

/-- Cost bound of `clog2`. -/
def C_clog2 (m : ℕ) : ℕ := (Nat.size m + 2) * (6 * Nat.size m + 80) + 20

/-- Space bound of `clog2` (on top of the base). -/
def S_clog2 (m : ℕ) : ℕ := 20 * Nat.size m + 150

theorem clog2Step_stop (prog : List Expr) (base : ℕ) (k p m : ℤ) (h : ¬ p < m) :
    EvalsLe prog base [Val.list [Val.int k, Val.int p, Val.int m]] body_clog2Step
      (Val.list [Val.int 0, Val.int k]) (50 + bitLen p + bitLen m)
      (base + 4 * valSize (Val.list [Val.int k, Val.int p, Val.int m]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_clog2Step, ePair, eTriple, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    h, if_false, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero] <;> omega

theorem clog2Step_cont (prog : List Expr) (base : ℕ) (k p m : ℤ) (h : p < m) :
    EvalsLe prog base [Val.list [Val.int k, Val.int p, Val.int m]] body_clog2Step
      (Val.list [Val.int 1, Val.list [Val.int (k + 1), Val.int (p + p), Val.int m]])
      (60 + bitLen k + 3 * bitLen p + bitLen m)
      (base + 4 * valSize (Val.list [Val.int k, Val.int p, Val.int m]) + 2 * bitLen (k + 1) +
        2 * bitLen (p + p) + 40) := by
  apply EvalsLe.of_eval 20
  simp only [body_clog2Step, ePair, eTriple, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    h, if_true, one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_one] <;> omega

/-- Encoding of the `clog2`/`natSize` loop state `(k, p)` (for the fixed argument `m`). -/
def encCL (m : ℕ) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int (m : ℤ)]

theorem clog2_le_size (m : ℕ) : Nat.clog 2 m ≤ Nat.size m :=
  Nat.clog_le_of_le_pow (Nat.lt_size_self m).le

theorem clog2_loop {prog : List Expr} (h : prog[Idx.clog2Step]? = some body_clog2Step)
    (m base : ℕ) :
    ∀ s : ℕ × ℕ, (s.2 = 2 ^ s.1 ∧ s.1 ≤ Nat.clog 2 m) →
      ∃ out, out = encN (Nat.clog 2 m) ∧
        LoopLe prog base Idx.clog2Step (encCL m s) out
          ((Nat.clog 2 m - s.1 + 1) * (5 * Nat.size m + 63 + 1)) (base + S_clog2 m) := by
  refine LoopLe.of_measure h (encCL m) _ _ (fun s => Nat.clog 2 m - s.1)
    (5 * Nat.size m + 63) ?_
  rintro ⟨k, p⟩ ⟨hp, hk⟩
  simp only at hp hk
  subst hp
  have hcl := clog2_le_size m
  have hBk : bitLen (k : ℤ) ≤ Nat.size m := by
    rw [bitLen_natCast]
    exact (Nat.size_le_size (hk.trans hcl)).trans (size_le_self _)
  have hBp : bitLen ((2 ^ k : ℕ) : ℤ) = k + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hBm : bitLen (m : ℤ) = Nat.size m := bitLen_natCast m
  by_cases hlt : 2 ^ k < m
  · right
    have hk1 : k < Nat.clog 2 m := (Nat.lt_clog_iff_pow_lt (by norm_num)).mpr hlt
    have hltZ : ((2 ^ k : ℕ) : ℤ) < (m : ℤ) := by exact_mod_cast hlt
    have hBk1 : bitLen ((k : ℤ) + 1) ≤ Nat.size m + 1 := by
      have : ((k : ℤ) + 1) = ((k + 1 : ℕ) : ℤ) := by push_cast; ring
      rw [this, bitLen_natCast]
      exact (size_le_self _).trans (by omega)
    have hBp2 : bitLen (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)) = k + 2 := by
      have : (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)) = ((2 ^ (k + 1) : ℕ) : ℤ) := by
        push_cast; ring
      rw [this, bitLen_natCast, Nat.size_pow]
    have henc : encCL m (k + 1, 2 ^ (k + 1)) =
        Val.list [Val.int ((k : ℤ) + 1), Val.int (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)),
          Val.int (m : ℤ)] := by
      simp only [encCL]
      push_cast
      ring_nf
    refine ⟨1, (k + 1, 2 ^ (k + 1)), one_ne_zero, ?_, ⟨rfl, ?_⟩, ?_⟩
    · rw [henc]
      refine (clog2Step_cont prog _ _ _ _ hltZ).mono (by dsimp only; omega) ?_
      simp only [encCL, S_clog2, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only
      omega
    · simp only
      omega
  · left
    have hle : Nat.clog 2 m ≤ k := Nat.clog_le_of_le_pow (not_lt.mp hlt)
    have hnltZ : ¬ ((2 ^ k : ℕ) : ℤ) < (m : ℤ) := by exact_mod_cast hlt
    refine ⟨Val.int (k : ℤ), ?_, ?_⟩
    · refine (clog2Step_stop prog _ _ _ _ hnltZ).mono (by omega) ?_
      simp only [encCL, S_clog2, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    · have : k = Nat.clog 2 m := le_antisymm hk hle
      simp [encN, this]

/-- **Spec of `clog2`.** -/
theorem clog2_spec {prog : List Expr} (h : prog[Idx.clog2Step]? = some body_clog2Step)
    (m base : ℕ) :
    EvalsLe prog base [encN m] body_clog2 (encN (Nat.clog 2 m)) (C_clog2 m) (base + S_clog2 m) := by
  obtain ⟨out, rfl, hloop⟩ := clog2_loop h m base (0, 1) ⟨by simp, Nat.zero_le _⟩
  have hinit : EvalsLe prog base [encN m] (eTriple (Expr.lit 0) (Expr.lit 1) (Expr.var 0))
      (encCL m (0, 1)) 12 (base + 3 * valSize (encN m) + 20) := by
    have h0 := EvalsLe.cons (prog := prog) (base := base) (env := [encN m]) (EvalsLe.lit 0)
      (EvalsLe.cons (EvalsLe.lit 1) (EvalsLe.cons (EvalsLe.var (i := 0) (v := encN m) rfl)
        EvalsLe.nil))
    refine h0.mono (by simp) ?_
    simp only [encN, valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, max_le_iff]
    omega
  have hcl := clog2_le_size m
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_clog2]
    have : Nat.clog 2 m - 0 + 1 ≤ Nat.size m + 1 := by omega
    nlinarith
  · have hk : valSize (encN m) = Nat.size m + 1 := valSize_encN m
    simp only [S_clog2, max_le_iff, hk]
    omega

/-- **Spec of `call Idx.clog2`** (for callers). -/
theorem clog2_call {prog : List Expr} (h1 : prog[Idx.clog2]? = some body_clog2)
    (h2 : prog[Idx.clog2Step]? = some body_clog2Step) {base : ℕ} {env : List Val} {a : Expr}
    {m Ca Sa : ℕ} (ha : EvalsLe prog base env a (encN m) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.clog2 a) (encN (Nat.clog 2 m)) (1 + Ca + C_clog2 m)
      (max Sa (base + valSize (encN m) + S_clog2 m)) :=
  EvalsLe.call ha h1 (clog2_spec h2 m _)

/-! ## `natSize` -/

/-- Loop body of `natSize`. Environment `[acc]`, `acc = [k, p, m]`: if `m < p` stop with `k`,
otherwise continue with `[k + 1, p + p, m]`. -/
def body_natSizeStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                       -- k
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))                -- p
      (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))  -- m
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 0) (Expr.var 1))
          (ePair (Expr.lit 0) (Expr.var 2))
          (ePair (Expr.lit 1)
            (eTriple (Expr.bin BinOp.add (Expr.var 2) (Expr.lit 1))
              (Expr.bin BinOp.add (Expr.var 1) (Expr.var 1)) (Expr.var 0))))))

/-- `natSize : m ↦ Nat.size m`. Environment `[encN m]`. -/
def body_natSize : Expr :=
  Expr.loop Idx.natSizeStep (eTriple (Expr.lit 0) (Expr.lit 1) (Expr.var 0))

/-- Cost bound of `natSize`. -/
def C_natSize (m : ℕ) : ℕ := (Nat.size m + 2) * (6 * Nat.size m + 80) + 20

/-- Space bound of `natSize` (on top of the base). -/
def S_natSize (m : ℕ) : ℕ := 20 * Nat.size m + 150

theorem natSizeStep_stop (prog : List Expr) (base : ℕ) (k p m : ℤ) (h : m < p) :
    EvalsLe prog base [Val.list [Val.int k, Val.int p, Val.int m]] body_natSizeStep
      (Val.list [Val.int 0, Val.int k]) (50 + bitLen p + bitLen m)
      (base + 4 * valSize (Val.list [Val.int k, Val.int p, Val.int m]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_natSizeStep, ePair, eTriple, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    h, if_true, one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one] <;> omega

theorem natSizeStep_cont (prog : List Expr) (base : ℕ) (k p m : ℤ) (h : ¬ m < p) :
    EvalsLe prog base [Val.list [Val.int k, Val.int p, Val.int m]] body_natSizeStep
      (Val.list [Val.int 1, Val.list [Val.int (k + 1), Val.int (p + p), Val.int m]])
      (60 + bitLen k + 3 * bitLen p + bitLen m)
      (base + 4 * valSize (Val.list [Val.int k, Val.int p, Val.int m]) + 2 * bitLen (k + 1) +
        2 * bitLen (p + p) + 40) := by
  apply EvalsLe.of_eval 20
  simp only [body_natSizeStep, ePair, eTriple, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq,
    h, if_false, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero, bitLen_one] <;> omega

theorem natSize_loop {prog : List Expr} (h : prog[Idx.natSizeStep]? = some body_natSizeStep)
    (m base : ℕ) :
    ∀ s : ℕ × ℕ, (s.2 = 2 ^ s.1 ∧ s.1 ≤ Nat.size m) →
      ∃ out, out = encN (Nat.size m) ∧
        LoopLe prog base Idx.natSizeStep (encCL m s) out
          ((Nat.size m - s.1 + 1) * (5 * Nat.size m + 63 + 1)) (base + S_natSize m) := by
  refine LoopLe.of_measure h (encCL m) _ _ (fun s => Nat.size m - s.1)
    (5 * Nat.size m + 63) ?_
  rintro ⟨k, p⟩ ⟨hp, hk⟩
  simp only at hp hk
  subst hp
  have hBk : bitLen (k : ℤ) ≤ Nat.size m := by
    rw [bitLen_natCast]
    exact (Nat.size_le_size hk).trans (size_le_self _)
  have hBp : bitLen ((2 ^ k : ℕ) : ℤ) = k + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hBm : bitLen (m : ℤ) = Nat.size m := bitLen_natCast m
  by_cases hlt : m < 2 ^ k
  · left
    have hle : Nat.size m ≤ k := Nat.size_le.mpr hlt
    have hltZ : (m : ℤ) < ((2 ^ k : ℕ) : ℤ) := by exact_mod_cast hlt
    refine ⟨Val.int (k : ℤ), ?_, ?_⟩
    · refine (natSizeStep_stop prog _ _ _ _ hltZ).mono (by omega) ?_
      simp only [encCL, S_natSize, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    · have : k = Nat.size m := le_antisymm hk hle
      simp [encN, this]
  · right
    have hk1 : k < Nat.size m := Nat.lt_size.mpr (not_lt.mp hlt)
    have hnltZ : ¬ (m : ℤ) < ((2 ^ k : ℕ) : ℤ) := by exact_mod_cast hlt
    have hBk1 : bitLen ((k : ℤ) + 1) ≤ Nat.size m + 1 := by
      have : ((k : ℤ) + 1) = ((k + 1 : ℕ) : ℤ) := by push_cast; ring
      rw [this, bitLen_natCast]
      exact (size_le_self _).trans (by omega)
    have hBp2 : bitLen (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)) = k + 2 := by
      have : (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)) = ((2 ^ (k + 1) : ℕ) : ℤ) := by
        push_cast; ring
      rw [this, bitLen_natCast, Nat.size_pow]
    have henc : encCL m (k + 1, 2 ^ (k + 1)) =
        Val.list [Val.int ((k : ℤ) + 1), Val.int (((2 ^ k : ℕ) : ℤ) + ((2 ^ k : ℕ) : ℤ)),
          Val.int (m : ℤ)] := by
      simp only [encCL]
      push_cast
      ring_nf
    refine ⟨1, (k + 1, 2 ^ (k + 1)), one_ne_zero, ?_, ⟨rfl, ?_⟩, ?_⟩
    · rw [henc]
      refine (natSizeStep_cont prog _ _ _ _ hnltZ).mono (by dsimp only; omega) ?_
      simp only [encCL, S_natSize, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only
      omega
    · simp only
      omega

/-- **Spec of `natSize`.** -/
theorem natSize_spec {prog : List Expr} (h : prog[Idx.natSizeStep]? = some body_natSizeStep)
    (m base : ℕ) :
    EvalsLe prog base [encN m] body_natSize (encN (Nat.size m)) (C_natSize m)
      (base + S_natSize m) := by
  obtain ⟨out, rfl, hloop⟩ := natSize_loop h m base (0, 1) ⟨by simp, Nat.zero_le _⟩
  have hinit : EvalsLe prog base [encN m] (eTriple (Expr.lit 0) (Expr.lit 1) (Expr.var 0))
      (encCL m (0, 1)) 12 (base + 3 * valSize (encN m) + 20) := by
    have h0 := EvalsLe.cons (prog := prog) (base := base) (env := [encN m]) (EvalsLe.lit 0)
      (EvalsLe.cons (EvalsLe.lit 1) (EvalsLe.cons (EvalsLe.var (i := 0) (v := encN m) rfl)
        EvalsLe.nil))
    refine h0.mono (by simp) ?_
    simp only [encN, valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, max_le_iff]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_natSize]
    have : Nat.size m - 0 + 1 ≤ Nat.size m + 1 := by omega
    nlinarith
  · have hk : valSize (encN m) = Nat.size m + 1 := valSize_encN m
    simp only [S_natSize, max_le_iff, hk]
    omega

/-- **Spec of `call Idx.natSize`** (for callers). -/
theorem natSize_call {prog : List Expr} (h1 : prog[Idx.natSize]? = some body_natSize)
    (h2 : prog[Idx.natSizeStep]? = some body_natSizeStep) {base : ℕ} {env : List Val} {a : Expr}
    {m Ca Sa : ℕ} (ha : EvalsLe prog base env a (encN m) Ca Sa) :
    EvalsLe prog base env (Expr.call Idx.natSize a) (encN (Nat.size m)) (1 + Ca + C_natSize m)
      (max Sa (base + valSize (encN m) + S_natSize m)) :=
  EvalsLe.call ha h1 (natSize_spec h2 m _)

/-! ## Bit extraction: `testBitN`, `lowBitsN`, `shiftRN` -/

/-- `testBitN : [m, i] ↦ (m / 2^i) % 2`. Environment `[[encN m, encN i]]`. -/
def body_testBitN : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                     -- m
    (Expr.letE (Expr.call Idx.pow2 (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))  -- 2^i
      (Expr.bin BinOp.mod (Expr.bin BinOp.div (Expr.var 1) (Expr.var 0)) (Expr.lit 2)))

/-- `lowBitsN : [m, b] ↦ m % 2^b`. Environment `[[encN m, encN b]]`. -/
def body_lowBitsN : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))
    (Expr.letE (Expr.call Idx.pow2 (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
      (Expr.bin BinOp.mod (Expr.var 1) (Expr.var 0)))

/-- `shiftRN : [m, b] ↦ m / 2^b`. Environment `[[encN m, encN b]]`. -/
def body_shiftRN : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))
    (Expr.letE (Expr.call Idx.pow2 (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
      (Expr.bin BinOp.div (Expr.var 1) (Expr.var 0)))

/-- Cost bound of `testBitN`, `lowBitsN`, `shiftRN`. -/
def C_bits (m i : ℕ) : ℕ := C_pow2 i + (Nat.size m + 1) * (i + 2) + 4 * Nat.size m + 100

/-- Space bound of `testBitN`, `lowBitsN`, `shiftRN` (on top of the base). -/
def S_bits (m i : ℕ) : ℕ := S_pow2 i + 10 * (Nat.size m + i) + 200

/-- The common prefix of the bit routines: bind `m`, then `2^i` (by a call of `pow2`). -/
theorem bitsPrefix {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) (m i base : ℕ) {body : Expr} {v : Val}
    {Cb Sb : ℕ}
    (hb : EvalsLe prog (base + valSize (encN m) + valSize (encN (2 ^ i)))
      [encN (2 ^ i), encN m, Val.list [encN m, encN i]] body v Cb Sb) :
    EvalsLe prog base [Val.list [encN m, encN i]]
      (Expr.letE (Expr.un UnOp.head (Expr.var 0))
        (Expr.letE (Expr.call Idx.pow2 (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
          body))
      v (Cb + C_pow2 i + 20)
      (max Sb (base + 4 * valSize (Val.list [encN m, encN i]) + S_pow2 i + 10)) := by
  have hm := EvalsLe.head (prog := prog) (base := base) (env := [Val.list [encN m, encN i]])
    (EvalsLe.var (i := 0) (v := Val.list [encN m, encN i]) rfl)
  have ha := EvalsLe.head (prog := prog) (base := base + valSize (encN m))
    (env := [encN m, Val.list [encN m, encN i]])
    (EvalsLe.tail (EvalsLe.var (i := 1) (v := Val.list [encN m, encN i]) rfl))
  have hp := pow2_call h1 h2 ha
  refine (EvalsLe.letE hm (EvalsLe.letE hp hb)).mono ?_ ?_
  · omega
  · simp only [max_le_iff, valSize_list, listSize_cons, listSize_nil]
    omega

theorem bitLen_div_pow2 (m i : ℕ) : bitLen ((m : ℤ) / ((2 ^ i : ℕ) : ℤ)) ≤ Nat.size m := by
  have : ((m : ℤ) / ((2 ^ i : ℕ) : ℤ)) = ((m / 2 ^ i : ℕ) : ℤ) := by push_cast; rfl
  rw [this, bitLen_natCast]
  exact Nat.size_le_size (Nat.div_le_self _ _)

theorem bitLen_mod_pow2 (m i : ℕ) : bitLen ((m : ℤ) % ((2 ^ i : ℕ) : ℤ)) ≤ Nat.size m := by
  have : ((m : ℤ) % ((2 ^ i : ℕ) : ℤ)) = ((m % 2 ^ i : ℕ) : ℤ) := by push_cast; rfl
  rw [this, bitLen_natCast]
  exact Nat.size_le_size (Nat.mod_le _ _)

/-- **Spec of `testBitN`.** -/
theorem testBitN_spec {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) (m i base : ℕ) :
    EvalsLe prog base [Val.list [encN m, encN i]] body_testBitN (encB (m.testBit i))
      (C_bits m i) (base + S_bits m i) := by
  have hy : ((2 ^ i : ℕ) : ℤ) ≠ 0 := by positivity
  have hdiv := EvalsLe.div (prog := prog) (base := base + valSize (encN m) + valSize (encN (2 ^ i)))
    (env := [encN (2 ^ i), encN m, Val.list [encN m, encN i]])
    (EvalsLe.var (i := 1) (v := Val.int (m : ℤ)) rfl)
    (EvalsLe.var (i := 0) (v := Val.int ((2 ^ i : ℕ) : ℤ)) rfl) hy
  have hmod := EvalsLe.mod hdiv (EvalsLe.lit 2) two_ne_zero
  have hval : Val.int ((m : ℤ) / ((2 ^ i : ℕ) : ℤ) % 2) = encB (m.testBit i) := by
    have e1 : ((m : ℤ) / ((2 ^ i : ℕ) : ℤ) % 2) = ((m / 2 ^ i % 2 : ℕ) : ℤ) := by
      push_cast; rfl
    rw [e1, encB, Nat.testBit_eq_decide_div_mod_eq]
    rcases Nat.mod_two_eq_zero_or_one (m / 2 ^ i) with h | h <;> simp [h]
  rw [hval] at hmod
  have hB1 := bitLen_div_pow2 m i
  have hB2 : bitLen (((m / 2 ^ i % 2 : ℕ) : ℤ)) ≤ 1 := by
    rw [bitLen_natCast]
    exact Nat.size_le.mpr (by have := Nat.mod_lt (m / 2 ^ i) (by norm_num : 2 > 0); omega)
  have hBp : bitLen ((2 ^ i : ℕ) : ℤ) = i + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hBm : bitLen (m : ℤ) = Nat.size m := bitLen_natCast m
  refine (bitsPrefix h1 h2 m i base hmod).mono ?_ ?_
  · simp only [C_bits, bitLen_two, hBp, hBm]
    nlinarith
  · have hvs : valSize (encB (m.testBit i)) ≤ 2 := valSize_encB_le _
    simp only [S_bits, max_le_iff, encN, valSize_int, valSize_list, listSize_cons, listSize_nil,
      bitLen_two, hBp, hBm]
    have hsi : Nat.size i ≤ i := size_le_self i
    have : bitLen (i : ℤ) = Nat.size i := bitLen_natCast i
    refine ⟨⟨⟨?_, ?_⟩, ?_⟩, ?_⟩ <;> omega

/-- **Spec of `lowBitsN`.** -/
theorem lowBitsN_spec {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) (m b base : ℕ) :
    EvalsLe prog base [Val.list [encN m, encN b]] body_lowBitsN (encN (m % 2 ^ b))
      (C_bits m b) (base + S_bits m b) := by
  have hy : ((2 ^ b : ℕ) : ℤ) ≠ 0 := by positivity
  have hmod := EvalsLe.mod (prog := prog) (base := base + valSize (encN m) + valSize (encN (2 ^ b)))
    (env := [encN (2 ^ b), encN m, Val.list [encN m, encN b]])
    (EvalsLe.var (i := 1) (v := Val.int (m : ℤ)) rfl)
    (EvalsLe.var (i := 0) (v := Val.int ((2 ^ b : ℕ) : ℤ)) rfl) hy
  have hval : Val.int ((m : ℤ) % ((2 ^ b : ℕ) : ℤ)) = encN (m % 2 ^ b) := by
    simp only [encN]
    push_cast
    rfl
  rw [hval] at hmod
  have hB1 := bitLen_mod_pow2 m b
  have hBp : bitLen ((2 ^ b : ℕ) : ℤ) = b + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hBm : bitLen (m : ℤ) = Nat.size m := bitLen_natCast m
  have hBr : bitLen ((m % 2 ^ b : ℕ) : ℤ) ≤ Nat.size m := by
    rw [bitLen_natCast]; exact Nat.size_le_size (Nat.mod_le _ _)
  refine (bitsPrefix h1 h2 m b base hmod).mono ?_ ?_
  · simp only [C_bits]
    nlinarith
  · simp only [S_bits, max_le_iff, encN, valSize_int, valSize_list, listSize_cons, listSize_nil,
      hBp, hBm]
    have hsi : Nat.size b ≤ b := size_le_self b
    have : bitLen (b : ℤ) = Nat.size b := bitLen_natCast b
    refine ⟨⟨⟨?_, ?_⟩, ?_⟩, ?_⟩ <;> omega

/-- **Spec of `shiftRN`.** -/
theorem shiftRN_spec {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) (m b base : ℕ) :
    EvalsLe prog base [Val.list [encN m, encN b]] body_shiftRN (encN (m / 2 ^ b))
      (C_bits m b) (base + S_bits m b) := by
  have hy : ((2 ^ b : ℕ) : ℤ) ≠ 0 := by positivity
  have hdiv := EvalsLe.div (prog := prog) (base := base + valSize (encN m) + valSize (encN (2 ^ b)))
    (env := [encN (2 ^ b), encN m, Val.list [encN m, encN b]])
    (EvalsLe.var (i := 1) (v := Val.int (m : ℤ)) rfl)
    (EvalsLe.var (i := 0) (v := Val.int ((2 ^ b : ℕ) : ℤ)) rfl) hy
  have hval : Val.int ((m : ℤ) / ((2 ^ b : ℕ) : ℤ)) = encN (m / 2 ^ b) := by
    simp only [encN]
    push_cast
    rfl
  rw [hval] at hdiv
  have hBp : bitLen ((2 ^ b : ℕ) : ℤ) = b + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hBm : bitLen (m : ℤ) = Nat.size m := bitLen_natCast m
  have hBr : bitLen ((m / 2 ^ b : ℕ) : ℤ) ≤ Nat.size m := by
    rw [bitLen_natCast]; exact Nat.size_le_size (Nat.div_le_self _ _)
  refine (bitsPrefix h1 h2 m b base hdiv).mono ?_ ?_
  · simp only [C_bits]
    nlinarith
  · simp only [S_bits, max_le_iff, encN, valSize_int, valSize_list, listSize_cons, listSize_nil,
      hBp, hBm]
    have hsi : Nat.size b ≤ b := size_le_self b
    have : bitLen (b : ℤ) = Nat.size b := bitLen_natCast b
    refine ⟨⟨⟨?_, ?_⟩, ?_⟩, ?_⟩ <;> omega

/-! ## `minZ`, `maxZ` -/

/-- `minZ : [a, b] ↦ if a < b then a else b`. Environment `[[encZ a, encZ b]]`. -/
def body_minZ : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                     -- a
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))              -- b
      (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 1) (Expr.var 0)))

/-- `maxZ : [a, b] ↦ if a < b then b else a`. Environment `[[encZ a, encZ b]]`. -/
def body_maxZ : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))
      (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 0) (Expr.var 1)))

/-- Cost bound of `minZ`/`maxZ`. -/
def C_minmax (a b : ℤ) : ℕ := 2 * (bitLen a + bitLen b) + 40

/-- Space bound of `minZ`/`maxZ` (on top of the base). -/
def S_minmax (a b : ℤ) : ℕ := 6 * (bitLen a + bitLen b) + 60

/-- **Spec of `minZ`.** -/
theorem minZ_spec (prog : List Expr) (a b : ℤ) (base : ℕ) :
    EvalsLe prog base [Val.list [encZ a, encZ b]] body_minZ (encZ (min a b)) (C_minmax a b)
      (base + S_minmax a b) := by
  by_cases h : a < b
  · rw [min_eq_left h.le]
    apply EvalsLe.of_eval 20
    simp only [body_minZ, encZ, eval_succ_var, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, h, if_true, one_ne_zero,
      not_false_eq_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [C_minmax, S_minmax, valSize_int, valSize_list, listSize_cons, listSize_nil,
        max_le_iff, bitLen_one] <;> omega
  · rw [min_eq_right (not_lt.mp h)]
    apply EvalsLe.of_eval 20
    simp only [body_minZ, encZ, eval_succ_var, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, h, if_false, not_true_eq_false]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [C_minmax, S_minmax, valSize_int, valSize_list, listSize_cons, listSize_nil,
        max_le_iff, bitLen_zero] <;> omega

/-- **Spec of `maxZ`.** -/
theorem maxZ_spec (prog : List Expr) (a b : ℤ) (base : ℕ) :
    EvalsLe prog base [Val.list [encZ a, encZ b]] body_maxZ (encZ (max a b)) (C_minmax a b)
      (base + S_minmax a b) := by
  by_cases h : a < b
  · rw [max_eq_right h.le]
    apply EvalsLe.of_eval 20
    simp only [body_maxZ, encZ, eval_succ_var, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, h, if_true, one_ne_zero,
      not_false_eq_true]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [C_minmax, S_minmax, valSize_int, valSize_list, listSize_cons, listSize_nil,
        max_le_iff, bitLen_one] <;> omega
  · rw [max_eq_left (not_lt.mp h)]
    apply EvalsLe.of_eval 20
    simp only [body_maxZ, encZ, eval_succ_var, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, h, if_false, not_true_eq_false]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [C_minmax, S_minmax, valSize_int, valSize_list, listSize_cons, listSize_nil,
        max_le_iff, bitLen_zero] <;> omega

end F2e2e.Cost