import F2e2e.Cost.Arith.Median
import F2e2e.Cost.Lib.Get
import F2e2e.Cost.Lib.Length
import F2e2e.Cost.ValRules

/-!
# Lower median of an integer list (package L; Idx 122)

Reference (integer form of C-ALG's `lowerMedian`, partIII.tex L217):
`lowerMedZ l = (l.insertionSort (· ≤ ·)).getD ((l.length - 1) / 2) 0`.

* `isortRef_eq_insertionSort` : the DSL's insertion sort (cut2's `isortRef`, a left fold of
  `orderedInsert`) is `List.insertionSort`;
* `insertionSort_map_mono`, `lowerMed_map` : for a monotone `f : ℤ → β` with `f 0 = 0` (e.g. grid
  values `z ↦ z / 2^e`), the lower median of `l.map f` (in C-ALG's form) is `f (lowerMedZ l)`;
* DSL routine `body_lowerMedZ` (index `Idx.lowerMedZ`): `encInts l ↦ Val.int (lowerMedZ l)`, by the
  ported cut2 routines `isortZ` (Idx 114/115 with `insertZ` 112/113 and `revAppendStep` 4),
  `length` (1/2) and `get` (9/10); spec `lowerMedZ_val` (`EvalsVal`, `M ≥ S_medZ |l| K` for entries
  of bit length `≤ K`).
-/

namespace F2e2e.Cost

namespace Idx

/-- `lowerMedZ : l ↦ lowerMedZ l`. -/
abbrev lowerMedZ : ℕ := 122

end Idx

/-- Lower median of an integer list: the entry of index `⌊(len − 1)/2⌋` of the sorted list (`0` for
`[]`). -/
def lowerMedZ (l : List ℤ) : ℤ := (l.insertionSort (· ≤ ·)).getD ((l.length - 1) / 2) 0

theorem isortRef_eq_insertionSort (l : List ℤ) : isortRef l = l.insertionSort (· ≤ ·) := by
  have hp : (isortRef l).Perm (l.insertionSort (· ≤ ·)) := by
    have h := Arith.isortAux_perm l []
    rw [List.nil_append] at h
    exact h.trans (List.perm_insertionSort _ l).symm
  exact hp.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba)
    (Arith.isortAux_sorted l [] List.Pairwise.nil) (List.pairwise_insertionSort _ l)

/-- Insertion sort commutes with monotone maps. -/
theorem insertionSort_map_mono {β : Type*} [LinearOrder β] (f : ℤ → β) (hf : Monotone f)
    (l : List ℤ) : (l.map f).insertionSort (· ≤ ·) = (l.insertionSort (· ≤ ·)).map f := by
  have h1 := List.pairwise_insertionSort (fun a b : β => a ≤ b) (l.map f)
  have h2 : ((l.insertionSort (· ≤ ·)).map f).Pairwise (· ≤ ·) :=
    List.Pairwise.map f (fun a b h => hf h) (List.pairwise_insertionSort _ l)
  have hperm : ((l.map f).insertionSort (· ≤ ·)).Perm ((l.insertionSort (· ≤ ·)).map f) :=
    (List.perm_insertionSort _ _).trans ((List.perm_insertionSort _ l).map f).symm
  exact hperm.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba) h1 h2

/-- **Bridge** to C-ALG's lower median of the images under a monotone map with `f 0 = 0`. -/
theorem lowerMed_map {β : Type*} [LinearOrder β] [Zero β] (f : ℤ → β) (hf : Monotone f)
    (hf0 : f 0 = 0) (l : List ℤ) :
    ((l.map f).insertionSort (· ≤ ·)).getD (((l.map f).length - 1) / 2) 0 = f (lowerMedZ l) := by
  rw [insertionSort_map_mono f hf, List.length_map, lowerMedZ]
  conv_lhs => rw [← hf0]
  exact List.getD_map _ _ _

/-- `lowerMedZ : l ↦ lowerMedZ l`. Environment `[encInts l]`. -/
def body_lowerMedZ : Expr :=
  Expr.letE (Expr.call Idx.isortZ (Expr.var 0))                       -- t ; env [t, l]
    (Expr.letE (Expr.call Idx.length (Expr.var 0))                    -- n ; env [n, t, l]
      (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
        (Expr.lit 0)
        (Expr.call Idx.get (ePair (Expr.var 1)
          (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1)) (Expr.lit 2))))))

/-- **Spec of `lowerMedZ`.** -/
theorem lowerMedZ_val {prog : List Expr} (h1 : prog[Idx.isortZ]? = some body_isortZ)
    (h2 : prog[Idx.isortZStep]? = some body_isortZStep)
    (h3 : prog[Idx.insertZ]? = some body_insertZ)
    (h4 : prog[Idx.insertZStep]? = some body_insertZStep)
    (h6 : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (hl1 : prog[Idx.length]? = some body_length) (hl2 : prog[Idx.lengthStep]? = some body_lengthStep)
    (hg1 : prog[Idx.get]? = some body_get) (hg2 : prog[Idx.getStep]? = some body_getStep)
    (l : List ℤ) (K : ℕ) (hK : ∀ z ∈ l, bitLen z ≤ K) {M : ℕ} (hM : S_medZ l.length K ≤ M) :
    EvalsVal prog M [encInts l] [] (.inl body_lowerMedZ) (Val.int (lowerMedZ l)) := by
  set t := isortRef l with ht
  have hperm : t.Perm l := by
    have h := Arith.isortAux_perm l []
    rw [List.nil_append] at h
    exact h
  have hlen : t.length = l.length := hperm.length_eq
  have hVt : valSize (encInts t) = valSize (encInts l) := Arith.valSize_encInts_perm hperm
  have hV := valSize_encInts_le l K hK
  have hS := Arith.S_medZ_ge l.length K _ hV
  have hsz : Nat.size l.length ≤ l.length := size_le_self _
  have hSm : 100 * (l.length + 1) * (K + 3) + 1000 ≤ M := by simpa [S_medZ] using hM
  have hlk : 5 * valSize (encInts l) + 7 * l.length + 60 ≤ 100 * (l.length + 1) * (K + 3) + 1000 := by
    nlinarith
  -- `t := isortZ l`
  have hsort := (isortZ_spec h2 h3 h4 h6 l K hK 0).toVal.mono_M hM
  have hc1 : EvalsVal prog M [encInts l] [] (.inl (Expr.call Idx.isortZ (Expr.var 0)))
      (encInts t) := by
    have := EvalsVal.call (EvalsVal.var0 (rest := [])) h1 hsort
    simpa using this
  -- `n := length t`
  have hlenS := (length_spec hl2 (t.map Val.int) 0).toVal.mono_M (M' := M) (by
    simp only [S_length, List.length_map, hlen]
    have : valSize (Val.list (t.map Val.int)) = valSize (encInts t) := rfl
    omega)
  have hc2 : EvalsVal prog M [encInts t, encInts l] [] (.inl (Expr.call Idx.length (Expr.var 0)))
      (encN l.length) := by
    have := EvalsVal.call (EvalsVal.var0 (v := encInts t) (rest := [encInts l])) hl1 hlenS
    simpa [hlen] using this
  have hn : valSize (encN l.length) ≤ M := by
    rw [valSize_encN]; omega
  by_cases hl0 : l = []
  · -- empty list: the result is `0`
    subst hl0
    have hcond : EvalsVal prog M [encN 0, encInts t, encInts []] []
        (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 1) := by
      have := EvalsVal.eq (EvalsVal.var0 (v := encN 0) (rest := [encInts t, encInts []]))
        (EvalsVal.lit' (prog := prog) (M := M) (z := 0) (by simp; omega)) (by omega)
      simpa [encN] using this
    have hite := EvalsVal.ite_true (f := Expr.call Idx.get (ePair (Expr.var 1)
          (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1)) (Expr.lit 2))))
      hcond one_ne_zero (EvalsVal.lit' (prog := prog) (M := M) (z := 0) (by simp; omega))
    have := EvalsVal.letE hc1 (EvalsVal.letE hc2 (by simpa using hite))
    have hres : lowerMedZ [] = 0 := rfl
    rw [hres]
    simpa [body_lowerMedZ] using this
  · have hpos : 0 < l.length := List.length_pos_iff.mpr hl0
    have hcond : EvalsVal prog M [encN l.length, encInts t, encInts l] []
        (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 0) := by
      have := EvalsVal.eq (EvalsVal.var0 (v := encN l.length) (rest := [encInts t, encInts l]))
        (EvalsVal.lit' (prog := prog) (M := M) (z := 0) (by simp; omega)) (by omega)
      simpa [encN, hl0] using this
    -- the index `(n - 1) / 2`
    set k := (l.length - 1) / 2 with hk
    have hkz : ((l.length : ℤ) - 1) / 2 = (k : ℤ) := by omega
    have hkl : k ≤ l.length := by omega
    have hBk : bitLen (k : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le hkl
    have hBn1 : bitLen ((l.length : ℤ) - 1) ≤ Nat.size l.length := by
      have : ((l.length : ℤ) - 1) = ((l.length - 1 : ℕ) : ℤ) := by omega
      rw [this]; exact bitLen_le_size_of_le (by omega)
    have hidx : EvalsVal prog M [encN l.length, encInts t, encInts l] []
        (.inl (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1)) (Expr.lit 2)))
        (Val.int (k : ℤ)) := by
      have hsub := EvalsVal.sub (EvalsVal.var0 (v := encN l.length) (rest := [encInts t, encInts l]))
        (EvalsVal.lit' (prog := prog) (M := M) (z := 1) (by simp; omega))
        (by simp only [valSize_int]; omega)
      have hdiv := EvalsVal.div hsub (EvalsVal.lit' (prog := prog) (M := M) (z := 2)
        (by simp only [valSize_int, show bitLen 2 = 2 from rfl]; omega)) two_ne_zero
        (by rw [hkz]; simp only [valSize_int]; omega)
      rw [hkz] at hdiv
      simpa [encN] using hdiv
    have harg : EvalsVal prog M [encN l.length, encInts t, encInts l] []
        (.inl (ePair (Expr.var 1) (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
          (Expr.lit 2)))) (Val.list [Val.list (t.map Val.int), Val.int (k : ℤ)]) := by
      have := EvalsVal.pair (EvalsVal.var1 (v := encInts t) (w := encN l.length)
        (rest := [encInts l])) hidx (by
          simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
          have : valSize (encInts t) = 1 + listSize (t.map Val.int) := rfl
          omega)
      simpa [encInts] using this
    have hgetS := (get_spec hg2 (t.map Val.int) k 0).toVal.mono_M (M' := M) (by
      simp only [S_get]
      have : valSize (Val.list (t.map Val.int)) = valSize (encInts t) := rfl
      have := Nat.size_le_size hkl
      omega)
    have hget := EvalsVal.call harg hg1 hgetS
    have hval : (t.map Val.int).getD k (Val.int 0) = Val.int (lowerMedZ l) := by
      rw [lowerMedZ, ← isortRef_eq_insertionSort, ← ht, ← hk]
      exact List.getD_map _ _ _
    rw [hval] at hget
    have hite := EvalsVal.ite_false (t := Expr.lit 0) hcond rfl hget
    have := EvalsVal.letE hc1 (EvalsVal.letE hc2 hite)
    simpa [body_lowerMedZ] using this

end F2e2e.Cost
