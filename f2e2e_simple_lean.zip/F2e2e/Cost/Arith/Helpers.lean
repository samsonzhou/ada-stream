import F2e2e.Cost.ValRules

/-!
# Arithmetic helpers for C/Impl (package L, combinator 4; Idx 118–129)

Reference functions (integer forms of C-ALG's `Arith.lean` helpers, with bridges to the rational
forms):

| routine | index | input | output |
|---|---|---|---|
| `natSqrt` | `Idx.natSqrt` (loop `Idx.natSqrtStep`) | `encN N` | `encN (Nat.sqrt N)` |
| `roundMantZ` | `Idx.roundMantZ` (calls ARITH `pow2`) | `[q, num, den]` | `Val.int (roundMantZ q num den)` |
| `clampZ` | `Idx.clampZ` | `[lo, hi, z]` | `Val.int (max lo (min hi z))` |

* `roundMantZ q num den = (2·num·2^q + den) / (2·den)`; `roundMantZ_eq : 0 < den →
  roundMantZ q num den = ⌊(num / den : ℚ) * 2 ^ q + 1 / 2⌋` (C-ALG's `roundMant q (num / den)`);
* `floorDivZ_eq : 0 < den → num / den = ⌊(num / den : ℚ)⌋`,
  `ceilDivZ_eq : 0 < den → -((-num) / den) = ⌈(num / den : ℚ)⌉` (C-ALG's `floorSqrtQ`/`ceilSqrtQ`
  on `(num, den)` are `natSqrt` of these; the division is the primitive `div`).

All specs are `EvalsVal` judgments (no fresh bits; value bound `M`, see each statement). The loop
of `natSqrt` is a naive search (time is free in Theorem (C)): from `k = 0`, continue while
`(k + 1)² ≤ N`. Straight-line steps are verified by symbolic evaluation (`EvalsVal.of_eval`).
-/

namespace F2e2e.Cost

namespace Idx

/-- `natSqrt : N ↦ Nat.sqrt N`. -/
abbrev natSqrt : ℕ := 118
/-- Loop body of `natSqrt`. -/
abbrev natSqrtStep : ℕ := 119
/-- `roundMantZ : [q, num, den] ↦ (2 num 2^q + den) / (2 den)`. -/
abbrev roundMantZ : ℕ := 120
/-- `clampZ : [lo, hi, z] ↦ max lo (min hi z)`. -/
abbrev clampZ : ℕ := 121

end Idx

/-! ## Reference functions and bridges -/

/-- Integer form of C-ALG's `roundMant q (num / den)`. -/
def roundMantZ (q : ℕ) (num den : ℤ) : ℤ := (2 * num * 2 ^ q + den) / (2 * den)

theorem floor_div_intCast (num den : ℤ) (hden : 0 < den) :
    ⌊((num : ℚ) / (den : ℚ))⌋ = num / den := by
  obtain ⟨d, rfl⟩ : ∃ d : ℕ, den = (d : ℤ) := ⟨den.toNat, (Int.toNat_of_nonneg hden.le).symm⟩
  have := Rat.floor_intCast_div_natCast num d
  simpa using this

theorem floorDivZ_eq (num den : ℤ) (hden : 0 < den) :
    num / den = ⌊((num : ℚ) / (den : ℚ))⌋ :=
  (floor_div_intCast num den hden).symm

theorem ceilDivZ_eq (num den : ℤ) (hden : 0 < den) :
    -((-num) / den) = ⌈((num : ℚ) / (den : ℚ))⌉ := by
  have h1 : ⌈((num : ℚ) / (den : ℚ))⌉ = -⌊-((num : ℚ) / (den : ℚ))⌋ := by
    rw [Int.floor_neg, neg_neg]
  have h2 : -((num : ℚ) / (den : ℚ)) = (((-num : ℤ) : ℚ)) / (den : ℚ) := by
    push_cast; ring
  rw [h1, h2, floor_div_intCast _ _ hden]

theorem roundMantZ_eq (q : ℕ) (num den : ℤ) (hden : 0 < den) :
    roundMantZ q num den = ⌊((num : ℚ) / (den : ℚ)) * 2 ^ q + 1 / 2⌋ := by
  have hd : (den : ℚ) ≠ 0 := by positivity
  have : ((num : ℚ) / (den : ℚ)) * 2 ^ q + 1 / 2 =
      (((2 * num * 2 ^ q + den : ℤ) : ℚ)) / (((2 * den : ℤ) : ℚ)) := by
    push_cast
    field_simp
    try ring
  rw [this, floor_div_intCast _ _ (by omega), roundMantZ]

/-! ## `natSqrt` -/

/-- Loop body of `natSqrt`. Environment `[acc]`, `acc = [k, N]`: stop with `k` if
`N < (k + 1)²`, otherwise continue with `[k + 1, N]`. -/
def body_natSqrtStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                               -- k ; env [k, acc]
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))        -- N ; env [N, k, acc]
      (Expr.letE (Expr.bin BinOp.add (Expr.var 1) (Expr.lit 1))            -- k1 ; env [k1, N, k, acc]
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1)
            (Expr.bin BinOp.mul (Expr.var 0) (Expr.var 0)))
          (ePair (Expr.lit 0) (Expr.var 2))
          (ePair (Expr.lit 1) (ePair (Expr.var 0) (Expr.var 1))))))

/-- `natSqrt : N ↦ Nat.sqrt N`. Environment `[encN N]`. -/
def body_natSqrt : Expr := Expr.loop Idx.natSqrtStep (ePair (Expr.lit 0) (Expr.var 0))

theorem natSqrtStep_stop (prog : List Expr) {M : ℕ} (k N : ℤ) (h : N < (k + 1) * (k + 1))
    (hM : 5 * (bitLen k + bitLen N + bitLen (k + 1) + bitLen ((k + 1) * (k + 1))) + 80 ≤ M) :
    EvalsVal prog M [Val.list [Val.int k, Val.int N]] [] (.inl body_natSqrtStep)
      (Val.list [Val.int 0, Val.int k]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_natSqrtStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, h,
    if_true, ne_eq, one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

theorem natSqrtStep_cont (prog : List Expr) {M : ℕ} (k N : ℤ) (h : ¬ N < (k + 1) * (k + 1))
    (hM : 5 * (bitLen k + bitLen N + bitLen (k + 1) + bitLen ((k + 1) * (k + 1))) + 80 ≤ M) :
    EvalsVal prog M [Val.list [Val.int k, Val.int N]] [] (.inl body_natSqrtStep)
      (Val.list [Val.int 1, Val.list [Val.int (k + 1), Val.int N]]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_natSqrtStep, ePair, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, eval_succ_ite, eval_succ_letE, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, h,
    if_false, ne_eq, not_true_eq_false]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

/-- Encoding of the `natSqrt` loop state `k` (for the fixed argument `N`). -/
def encNS (N : ℕ) (k : ℕ) : Val := Val.list [Val.int (k : ℤ), Val.int (N : ℤ)]

theorem three_mul_add_one_lt (N : ℕ) : 3 * N + 1 < 2 ^ (Nat.size N + 2) := by
  have h := Nat.lt_size_self N
  rw [pow_add]
  omega

theorem natSqrt_loop {prog : List Expr} (h : prog[Idx.natSqrtStep]? = some body_natSqrtStep)
    (N : ℕ) {M : ℕ} (hM : 25 * Nat.size N + 100 ≤ M) :
    ∀ k : ℕ, k * k ≤ N →
      ∃ out, out = encN (Nat.sqrt N) ∧
        EvalsVal prog M [] ((fun _ => []) k) (.inr (Idx.natSqrtStep, encNS N k)) out := by
  refine EvalsVal.loop_of_measure h (encNS N) (fun _ => []) (fun k => k * k ≤ N)
    (· = encN (Nat.sqrt N)) (fun k => N + 1 - k) ?_
  intro k hk
  have hkN : k ≤ N := le_trans (Nat.le_mul_self k) hk
  -- bit lengths of the values of the step
  have hB1 : bitLen (k : ℤ) ≤ Nat.size N := bitLen_le_size_of_le hkN
  have hB2 : bitLen (N : ℤ) ≤ Nat.size N := bitLen_le_size_of_le le_rfl
  have hB3 : bitLen ((k : ℤ) + 1) ≤ Nat.size N + 2 := by
    apply bitLen_le_of_abs_lt
    have := three_mul_add_one_lt N
    rw [abs_of_nonneg (by positivity)]
    exact_mod_cast (show k + 1 < 2 ^ (Nat.size N + 2) by omega)
  have hB4 : bitLen (((k : ℤ) + 1) * ((k : ℤ) + 1)) ≤ Nat.size N + 2 := by
    apply bitLen_le_of_abs_lt
    have := three_mul_add_one_lt N
    rw [abs_of_nonneg (by positivity)]
    have hsq : (k + 1) * (k + 1) ≤ 3 * N + 1 := by nlinarith
    exact_mod_cast (show (k + 1) * (k + 1) < 2 ^ (Nat.size N + 2) by omega)
  have hMs : 5 * (bitLen (k : ℤ) + bitLen (N : ℤ) + bitLen ((k : ℤ) + 1) +
      bitLen (((k : ℤ) + 1) * ((k : ℤ) + 1))) + 80 ≤ M := by omega
  by_cases hlt : N < (k + 1) * (k + 1)
  · left
    refine ⟨Val.int (k : ℤ), ?_, ?_⟩
    · exact natSqrtStep_stop prog (k : ℤ) (N : ℤ) (by exact_mod_cast hlt) hMs
    · have : k = Nat.sqrt N := Nat.eq_sqrt.mpr ⟨hk, hlt⟩
      rw [← this]
      rfl
  · right
    refine ⟨1, k + 1, [], one_ne_zero, rfl, ?_, ?_, ?_⟩
    · have henc : encNS N (k + 1) = Val.list [Val.int ((k : ℤ) + 1), Val.int (N : ℤ)] := by
        simp [encNS]
      rw [henc]
      exact natSqrtStep_cont prog (k : ℤ) (N : ℤ) (by exact_mod_cast hlt) hMs
    · omega
    · omega

/-- **Spec of `natSqrt`.** -/
theorem natSqrt_val {prog : List Expr} (h : prog[Idx.natSqrtStep]? = some body_natSqrtStep)
    (N : ℕ) {M : ℕ} (hM : 25 * Nat.size N + 100 ≤ M) :
    EvalsVal prog M [encN N] [] (.inl body_natSqrt) (encN (Nat.sqrt N)) := by
  obtain ⟨out, rfl, hloop⟩ := natSqrt_loop h N hM 0 (by simp)
  have hinit : EvalsVal prog M [encN N] [] (.inl (ePair (Expr.lit 0) (Expr.var 0)))
      (encNS N 0) := by
    have hs : valSize (encN N) = Nat.size N + 1 := valSize_encN N
    have := EvalsVal.pair (EvalsVal.lit' (prog := prog) (M := M) (env := [encN N]) (z := 0)
      (by simp; omega)) EvalsVal.var0
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa [encNS, encN] using this
  exact EvalsVal.loop hinit hloop

/-- **Spec of `call Idx.natSqrt`.** -/
theorem natSqrt_call {prog : List Expr} (h0 : prog[Idx.natSqrt]? = some body_natSqrt)
    (h : prog[Idx.natSqrtStep]? = some body_natSqrtStep) {M : ℕ} {env : List Val} {a : Expr}
    {ba : List Bool} {N : ℕ} (ha : EvalsVal prog M env ba (.inl a) (encN N))
    (hM : 25 * Nat.size N + 100 ≤ M) :
    EvalsVal prog M env (ba ++ []) (.inl (Expr.call Idx.natSqrt a)) (encN (Nat.sqrt N)) :=
  EvalsVal.call ha h0 (natSqrt_val h N hM)

/-! ## `clampZ` -/

/-- `clampZ : [lo, hi, z] ↦ max lo (min hi z)`. Environment `[[lo, hi, z]]`. -/
def body_clampZ : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                 -- lo
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))          -- hi
      (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2))))  -- z
        (Expr.letE (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 1)
            (Expr.var 0))                                                     -- m = min hi z
          (Expr.ite (Expr.bin BinOp.lt (Expr.var 0) (Expr.var 3)) (Expr.var 3) (Expr.var 0)))))

/-- **Spec of `clampZ`.** -/
theorem clampZ_val (prog : List Expr) {M : ℕ} (lo hi z : ℤ)
    (hM : 8 * (bitLen lo + bitLen hi + bitLen z) + 60 ≤ M) :
    EvalsVal prog M [Val.list [Val.int lo, Val.int hi, Val.int z]] [] (.inl body_clampZ)
      (Val.int (max lo (min hi z))) := by
  have hmin : bitLen (min hi z) ≤ bitLen hi + bitLen z := by
    rcases le_total hi z with h | h
    · rw [min_eq_left h]; omega
    · rw [min_eq_right h]; omega
  by_cases h1 : hi < z
  · have hm : min hi z = hi := min_eq_left h1.le
    by_cases h2 : hi < lo
    · have hr : max lo (min hi z) = lo := by rw [hm]; exact max_eq_left h2.le
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_clampZ, eval_succ_var, eval_succ_bin, eval_succ_un, eval_succ_ite,
        eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, h2, if_true, ne_eq, one_ne_zero,
        not_false_eq_true]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
        bitLen_one]
      omega
    · have hr : max lo (min hi z) = hi := by rw [hm]; exact max_eq_right (not_lt.mp h2)
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_clampZ, eval_succ_var, eval_succ_bin, eval_succ_un, eval_succ_ite,
        eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, h2, if_true, if_false, ne_eq,
        one_ne_zero, not_false_eq_true, not_true_eq_false]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one]
      omega
  · have hm : min hi z = z := min_eq_right (not_lt.mp h1)
    by_cases h2 : z < lo
    · have hr : max lo (min hi z) = lo := by rw [hm]; exact max_eq_left h2.le
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_clampZ, eval_succ_var, eval_succ_bin, eval_succ_un, eval_succ_ite,
        eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, h2, if_true, if_false, ne_eq,
        one_ne_zero, not_false_eq_true, not_true_eq_false]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one]
      omega
    · have hr : max lo (min hi z) = z := by rw [hm]; exact max_eq_right (not_lt.mp h2)
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_clampZ, eval_succ_var, eval_succ_bin, eval_succ_un, eval_succ_ite,
        eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, h2, if_false, ne_eq,
        not_true_eq_false]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero]
      omega

/-! ## `roundMantZ` -/

theorem bitLen_ediv_le (a b : ℤ) : bitLen (a / b) ≤ bitLen a := by
  apply bitLen_le_bitLen_of_natAbs_le
  have h := Int.abs_ediv_le_abs a b
  rw [Int.abs_eq_natAbs, Int.abs_eq_natAbs] at h
  exact_mod_cast h

theorem bitLen_two_eq : bitLen 2 = 2 := rfl

/-- Bit length of a product (as `bitLen_mul_le` of `Lib/ZipWithAdd`, not imported here). -/
theorem bitLen_mul_le' (a b : ℤ) : bitLen (a * b) ≤ bitLen a + bitLen b := by
  unfold bitLen
  rw [Nat.size_le, Int.natAbs_mul, pow_add]
  exact Nat.mul_lt_mul'' (Nat.lt_size_self _) (Nat.lt_size_self _)

/-- The arithmetic tail of `roundMantZ` (after `p = 2^q` is bound). Environment
`[p, [q, num, den]]`. -/
def body_roundMantZTail : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))                         -- num
    (Expr.letE (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 2)))) -- den
      (Expr.bin BinOp.div
        (Expr.bin BinOp.add
          (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 2) (Expr.var 1)) (Expr.var 2))
          (Expr.var 0))
        (Expr.bin BinOp.mul (Expr.lit 2) (Expr.var 0))))

/-- `roundMantZ : [q, num, den] ↦ (2 num 2^q + den) / (2 den)`. Environment `[[q, num, den]]`;
calls ARITH `pow2`. -/
def body_roundMantZ : Expr :=
  Expr.letE (Expr.call Idx.pow2 (Expr.un UnOp.head (Expr.var 0))) body_roundMantZTail

theorem roundMantZTail_val (prog : List Expr) {M : ℕ} (q : ℕ) (p num den : ℤ) (hden : den ≠ 0)
    (hM : 12 * (bitLen p + bitLen num + bitLen den + bitLen (q : ℤ) + 5) + 60 ≤ M) :
    EvalsVal prog M [Val.int p, Val.list [Val.int (q : ℤ), Val.int num, Val.int den]] []
      (.inl body_roundMantZTail) (Val.int ((2 * num * p + den) / (2 * den))) := by
  have h2 : 2 * den ≠ 0 := by omega
  have e1 : bitLen (2 * num) ≤ 2 + bitLen num := by
    have := bitLen_mul_le' 2 num; rw [bitLen_two_eq] at this; exact this
  have e2 : bitLen (2 * num * p) ≤ 2 + bitLen num + bitLen p := by
    have := bitLen_mul_le' (2 * num) p; omega
  have e3 : bitLen (2 * num * p + den) ≤ 3 + bitLen num + bitLen p + bitLen den := by
    have := bitLen_add_le (2 * num * p) den
    have := max_le_iff.mpr ⟨show bitLen (2 * num * p) ≤ 2 + bitLen num + bitLen p + bitLen den by
      omega, show bitLen den ≤ 2 + bitLen num + bitLen p + bitLen den by omega⟩
    omega
  have e4 : bitLen (2 * den) ≤ 2 + bitLen den := by
    have := bitLen_mul_le' 2 den; rw [bitLen_two_eq] at this; exact this
  have e5 : bitLen ((2 * num * p + den) / (2 * den)) ≤ 3 + bitLen num + bitLen p + bitLen den :=
    (bitLen_ediv_le _ _).trans e3
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_roundMantZTail, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, h2, if_false]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_two_eq]
  omega

/-- **Spec of `roundMantZ`** (C-ALG's `roundMant q (num / den)` by `roundMantZ_eq`). -/
theorem roundMantZ_val {prog : List Expr} (h1 : prog[Idx.pow2]? = some body_pow2)
    (h2 : prog[Idx.pow2Step]? = some body_pow2Step) (q : ℕ) (num den : ℤ) (hden : 0 < den)
    {M : ℕ} (hM : S_pow2 q + 12 * (q + bitLen num + bitLen den + Nat.size q + 6) + 60 ≤ M) :
    EvalsVal prog M [Val.list [Val.int (q : ℤ), Val.int num, Val.int den]] []
      (.inl body_roundMantZ) (Val.int (roundMantZ q num den)) := by
  have hq : bitLen (q : ℤ) = Nat.size q := bitLen_natCast q
  have hp : bitLen (((2 ^ q : ℕ) : ℤ)) = q + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have harg : EvalsVal prog M [Val.list [Val.int (q : ℤ), Val.int num, Val.int den]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (encN q) :=
    EvalsVal.head EvalsVal.var0 (by simp only [encN, valSize_int]; omega)
  have hpow := (pow2_spec h2 q 0).toVal.mono_M (M' := M) (by simp only [S_pow2] at hM ⊢; omega)
  have hcall := EvalsVal.call harg h1 hpow
  have htail := roundMantZTail_val prog (M := M) q ((2 ^ q : ℕ) : ℤ) num den (by omega)
    (by rw [hp, hq]; simp only [S_pow2] at hM; omega)
  have := EvalsVal.letE hcall htail
  have hv : (2 * num * ((2 ^ q : ℕ) : ℤ) + den) / (2 * den) = roundMantZ q num den := by
    simp [roundMantZ]
  rw [hv] at this
  simpa [body_roundMantZ, encN] using this

/-! ## `floorSqrtND`, `ceilSqrtND` (C-ALG's `floorSqrtQ`, `ceilSqrtQ` on `num / den`) -/

namespace Idx

/-- `floorSqrtND : [num, den] ↦ Nat.sqrt ⌊num / den⌋`. -/
abbrev floorSqrtND : ℕ := 123
/-- `ceilSqrtND : [num, den] ↦ ⌈√(num / den)⌉`. -/
abbrev ceilSqrtND : ℕ := 124

end Idx

/-- `⌊√(num/den)⌋` in integer form (C-ALG's `floorSqrtQ (num / den)`, by `floorDivZ_eq`). -/
def floorSqrtND (num den : ℤ) : ℕ := Nat.sqrt (num / den).toNat

/-- `⌈√(num/den)⌉` in integer form (C-ALG's `ceilSqrtQ (num / den)`, by `ceilDivZ_eq`). -/
def ceilSqrtND (num den : ℤ) : ℕ :=
  let N := (-((-num) / den)).toNat
  let k := Nat.sqrt N
  if k * k = N then k else k + 1

/-- `floorSqrtND : [num, den] ↦ Nat.sqrt (num / den)`. Environment `[[num, den]]`. -/
def body_floorSqrtND : Expr :=
  Expr.call Idx.natSqrt (Expr.bin BinOp.div (Expr.un UnOp.head (Expr.var 0))
    (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))))

/-- **Spec of `floorSqrtND`** (`0 ≤ num`, `0 < den`). -/
theorem floorSqrtND_val {prog : List Expr} (h0 : prog[Idx.natSqrt]? = some body_natSqrt)
    (h : prog[Idx.natSqrtStep]? = some body_natSqrtStep) (num den : ℤ) (hnum : 0 ≤ num)
    (hden : 0 < den) {M : ℕ} (hM : 25 * (bitLen num + 1) + 4 * bitLen den + 120 ≤ M) :
    EvalsVal prog M [Val.list [Val.int num, Val.int den]] [] (.inl body_floorSqrtND)
      (encN (floorSqrtND num den)) := by
  have hq : 0 ≤ num / den := Int.ediv_nonneg hnum hden.le
  have hN : ((num / den).toNat : ℤ) = num / den := Int.toNat_of_nonneg hq
  have hB : bitLen (num / den) ≤ bitLen num := bitLen_ediv_le num den
  have hBN : Nat.size (num / den).toNat ≤ bitLen num := by
    have := bitLen_natCast (num / den).toNat
    rw [hN] at this
    omega
  have hdiv : EvalsVal prog M [Val.list [Val.int num, Val.int den]] []
      (.inl (Expr.bin BinOp.div (Expr.un UnOp.head (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))))) (encN (num / den).toNat) := by
    have := EvalsVal.div (EvalsVal.head (prog := prog) (M := M)
        (env := [Val.list [Val.int num, Val.int den]]) EvalsVal.var0
        (by simp only [valSize_int]; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (by simp only [valSize_int]; omega)) (by omega)
      (by simp only [valSize_int]; omega)
    simpa [encN, hN] using this
  have := EvalsVal.call hdiv h0 (natSqrt_val h _ (by omega))
  simpa [body_floorSqrtND, floorSqrtND] using this

/-- `ceilSqrtND : [num, den] ↦ ⌈√(num/den)⌉`. Environment `[[num, den]]`. -/
def body_ceilSqrtND : Expr :=
  Expr.letE (Expr.bin BinOp.sub (Expr.lit 0)
      (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))          -- N ; env [N, inp]
    (Expr.letE (Expr.call Idx.natSqrt (Expr.var 0))                     -- k ; env [k, N, inp]
      (Expr.ite (Expr.bin BinOp.eq (Expr.bin BinOp.mul (Expr.var 0) (Expr.var 0)) (Expr.var 1))
        (Expr.var 0) (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1))))

/-- The tail of `ceilSqrtND` after `N` and `k = Nat.sqrt N` are bound. -/
def eCeilSqrtTail : Expr :=
  Expr.ite (Expr.bin BinOp.eq (Expr.bin BinOp.mul (Expr.var 0) (Expr.var 0)) (Expr.var 1))
    (Expr.var 0) (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1))

theorem ceilSqrtTail_val (prog : List Expr) {M : ℕ} (k Nn : ℕ) (inp : Val)
    (hM : 6 * (bitLen (k : ℤ) + bitLen ((k : ℤ) * (k : ℤ)) + bitLen (Nn : ℤ) +
      bitLen ((k : ℤ) + 1)) + 2 * valSize inp + 40 ≤ M) :
    EvalsVal prog M [encN k, encN Nn, inp] [] (.inl eCeilSqrtTail)
      (encN (if k * k = Nn then k else k + 1)) := by
  apply EvalsVal.of_eval (base := 0) 20
  by_cases hkk : k * k = Nn
  · have hkkz : ((k : ℤ) * (k : ℤ) = (Nn : ℤ)) := by exact_mod_cast hkk
    simp only [eCeilSqrtTail, eval_succ_var, eval_succ_bin, eval_succ_ite,
      evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, encN, hkkz, hkk, if_true, ne_eq, one_ne_zero, not_false_eq_true]
    refine ⟨_, _, rfl, ?_⟩
    simp only [valSize_int, max_le_iff, bitLen_one]
    omega
  · have hkkz : ¬ ((k : ℤ) * (k : ℤ) = (Nn : ℤ)) := by exact_mod_cast hkk
    simp only [eCeilSqrtTail, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_ite,
      evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, encN, hkkz, hkk, if_false, ne_eq, not_true_eq_false,
      Nat.cast_add, Nat.cast_one]
    refine ⟨_, _, rfl, ?_⟩
    simp only [valSize_int, max_le_iff, bitLen_one, bitLen_zero]
    omega

/-- The computation of `N = ⌈num/den⌉ = -((-num)/den)` in `ceilSqrtND`. -/
def eCeilND : Expr :=
  Expr.bin BinOp.sub (Expr.lit 0)
    (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)))
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0))))

theorem ceilND_val (prog : List Expr) {M : ℕ} (num den : ℤ) (hden : den ≠ 0)
    (hM : 6 * (bitLen num + bitLen den + bitLen ((-num) / den)) + 60 ≤ M) :
    EvalsVal prog M [Val.list [Val.int num, Val.int den]] [] (.inl eCeilND)
      (Val.int (-((-num) / den))) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [eCeilND, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un, evalBin, evalUn,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, hden, if_false, zero_sub]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_neg]
  omega

theorem body_ceilSqrtND_eq :
    body_ceilSqrtND = Expr.letE eCeilND (Expr.letE (Expr.call Idx.natSqrt (Expr.var 0))
      eCeilSqrtTail) := rfl

/-- **Spec of `ceilSqrtND`** (`0 ≤ num`, `0 < den`). -/
theorem ceilSqrtND_val {prog : List Expr} (h0 : prog[Idx.natSqrt]? = some body_natSqrt)
    (h : prog[Idx.natSqrtStep]? = some body_natSqrtStep) (num den : ℤ) (hnum : 0 ≤ num)
    (hden : 0 < den) {M : ℕ} (hM : 30 * (bitLen num + 2) + 6 * bitLen den + 200 ≤ M) :
    EvalsVal prog M [Val.list [Val.int num, Val.int den]] [] (.inl body_ceilSqrtND)
      (encN (ceilSqrtND num den)) := by
  have hq0 : (-num) / den ≤ 0 := Int.ediv_nonpos_of_nonpos_of_neg (by omega) hden
  have hNle : -((-num) / den) ≤ num := by
    have h2 := Int.lt_ediv_add_one_mul_self (-num) hden
    by_contra hcon
    have h3 : (-num) / den + 1 ≤ -num := by omega
    have h4 : ((-num) / den + 1) * den ≤ (-num) * den :=
      Int.mul_le_mul_of_nonneg_right h3 hden.le
    have h5 : (-num) * den ≤ -num := by nlinarith
    omega
  obtain ⟨Nn, hNn⟩ : ∃ Nn : ℕ, (Nn : ℤ) = -((-num) / den) :=
    ⟨(-((-num) / den)).toNat, Int.toNat_of_nonneg (by omega)⟩
  have hNnum : Nn ≤ num.toNat := by omega
  have hBnum : bitLen ((num.toNat : ℕ) : ℤ) = bitLen num := by
    rw [Int.toNat_of_nonneg hnum]
  have hBN : bitLen (Nn : ℤ) ≤ bitLen num := by
    have := bitLen_mono_nat hNnum; omega
  have hsN : Nat.size Nn ≤ bitLen num := by rw [← bitLen_natCast]; exact hBN
  have hBq : bitLen ((-num) / den) ≤ bitLen num := by
    have := bitLen_ediv_le (-num) den; rw [bitLen_neg] at this; exact this
  -- `N`
  have hNv := ceilND_val prog (M := M) num den (by omega) (by omega)
  rw [← hNn] at hNv
  -- `k = Nat.sqrt N`
  have hks := EvalsVal.call (EvalsVal.var0 (prog := prog) (M := M) (v := encN Nn)
    (rest := [Val.list [Val.int num, Val.int den]])) h0 (natSqrt_val (M := M) h Nn (by omega))
  rw [List.append_nil] at hks
  obtain ⟨k, hk⟩ : ∃ k, k = Nat.sqrt Nn := ⟨_, rfl⟩
  rw [← hk] at hks
  have hkN : k ≤ Nn := hk ▸ Nat.sqrt_le_self Nn
  have hk2 : k * k ≤ Nn := hk ▸ Nat.sqrt_le Nn
  have hBk : bitLen (k : ℤ) ≤ bitLen num := by have := bitLen_mono_nat hkN; omega
  have hBkk : bitLen ((k : ℤ) * (k : ℤ)) ≤ bitLen num := by
    have := bitLen_mono_nat hk2
    push_cast at this
    omega
  have hBk1 : bitLen ((k : ℤ) + 1) ≤ bitLen num + 2 := by
    have := bitLen_add_le (k : ℤ) 1
    rw [bitLen_one] at this
    have : max (bitLen (k : ℤ)) 1 ≤ bitLen num + 1 := max_le (by omega) (by omega)
    omega
  have htail := ceilSqrtTail_val prog (M := M) k Nn (Val.list [Val.int num, Val.int den]) (by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega)
  have := EvalsVal.letE hNv (EvalsVal.letE hks htail)
  have hres : ceilSqrtND num den = if k * k = Nn then k else k + 1 := by
    have hNt : (-((-num) / den)).toNat = Nn := by omega
    simp only [ceilSqrtND, hNt, ← hk]
  rw [hres, body_ceilSqrtND_eq]
  simpa using this

end F2e2e.Cost
