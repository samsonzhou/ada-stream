import F2e2e.Cost.Arith.Basic

/-!
# ARITH: straight-line arithmetic over ℕ, compiled to DSL code (owner de4dddbc) — port of cut2 `Cost/Arith/AExp.lean`

`AExp` is a tiny language of natural-number expressions (variables = de Bruijn indices into the
DSL environment, literals, `+`, `*`, truncated `-`, `/`, `max`, and calls of library functions
`ℕ → ℕ`). `AExp.toExpr off e` compiles `e` to a DSL expression evaluated under `off` extra
let-bound variables; `letChain [e₀, …, e_m] body` evaluates the `e_j` in sequence, pushing each
value on the environment. Used by PARAMS (`F2e2e/Cost/Arith/Params.lean`) and available to other
areas for parameter arithmetic.

Correctness and cost theorems: `F2e2e/Cost/Arith/AExpSpec.lean` (in progress).
-/

namespace F2e2e.Cost.Arith
/-- Arithmetic expressions over `ℕ`. `call j f a` calls the library function of index `j`, whose
semantics is `f`. -/
inductive AExp : Type where
  | var : ℕ → AExp
  | lit : ℕ → AExp
  | add : AExp → AExp → AExp
  | mul : AExp → AExp → AExp
  | tsub : AExp → AExp → AExp
  | div : AExp → AExp → AExp
  | max : AExp → AExp → AExp
  | call : ℕ → (ℕ → ℕ) → AExp → AExp

namespace AExp

/-- Semantics in a numeric environment (`var i` reads `env.getD i 0`). -/
def val (env : List ℕ) : AExp → ℕ
  | var i => env.getD i 0
  | lit k => k
  | add a b => a.val env + b.val env
  | mul a b => a.val env * b.val env
  | tsub a b => a.val env - b.val env
  | div a b => a.val env / b.val env
  | max a b => Max.max (a.val env) (b.val env)
  | call _ f a => f (a.val env)

/-- Compilation under `off` extra let-bound variables. -/
def toExpr : ℕ → AExp → Expr
  | off, var i => Expr.var (i + off)
  | _, lit k => Expr.lit (k : ℤ)
  | off, add a b => Expr.bin BinOp.add (a.toExpr off) (b.toExpr off)
  | off, mul a b => Expr.bin BinOp.mul (a.toExpr off) (b.toExpr off)
  | off, tsub a b =>
      Expr.letE (a.toExpr off) (Expr.letE (b.toExpr (off + 1))
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.lit 0)
          (Expr.bin BinOp.sub (Expr.var 1) (Expr.var 0))))
  | off, div a b => Expr.bin BinOp.div (a.toExpr off) (b.toExpr off)
  | off, max a b =>
      Expr.letE (a.toExpr off) (Expr.letE (b.toExpr (off + 1))
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 0) (Expr.var 1)))
  | off, call j _ a => Expr.call j (a.toExpr off)

end AExp

/-- `letChain [e₀, e₁, …] body = letE e₀ (letE e₁ (… body))`: each `e_j` sees the values of
`e_{j-1}, …, e₀` as variables `0, …, j-1`, followed by the original environment. -/
def letChain : List AExp → Expr → Expr
  | [], body => body
  | e :: es, body => Expr.letE (e.toExpr 0) (letChain es body)

/-- Numeric environment after a chain: each value is pushed in turn. -/
def chainEnv : List AExp → List ℕ → List ℕ
  | [], env => env
  | e :: es, env => chainEnv es (e.val env :: env)

/-- The list expression `[var i₀, var i₁, …]`. -/
def mkVarList : List ℕ → Expr
  | [] => Expr.nil
  | i :: is => Expr.bin BinOp.cons (Expr.var i) (mkVarList is)

/-- Variable number `i` (counted in push order) when `j` values have been pushed. -/
def pv (j i : ℕ) : AExp := AExp.var (j - 1 - i)

end F2e2e.Cost.Arith