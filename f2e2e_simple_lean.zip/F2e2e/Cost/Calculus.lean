import F2e2e.Cost.Enc

/-!
# A cost calculus for the f2e2e DSL (port of cut2's `Cost/Calculus.lean`, with fresh bits)

## Judgments
* `EvalsToT prog base env bits e v c p`: for some fuel, `e` evaluates (in environment `env`, with
  `base` units of other live data) to `v` at time cost exactly `c` with peak live space exactly `p`,
  **consuming exactly the fresh bits `bits`**: run on the tape `bits` it leaves the empty tape. By
  the tape frame lemma it then runs identically on every tape `bits ++ r`, leaving `r`
  (`EvalsToT.eval_append`); conversely every successful run on any tape arises this way
  (`EvalsToT.of_eval_tape`). Coin-free code consumes `[]`; `Expr.coin` consumes `[b]` and returns
  `encB b`; composite expressions consume the concatenation of the bits of their parts (left to
  right).
* `EvalsLeT prog base env bits e v C S`: the same within time `C` and peak space `S`.
* `EvalsTo` / `EvalsLe` (cut2's judgments, same argument order): the **deterministic** case
  `bits = []`; such an evaluation runs identically on every tape and leaves it untouched
  (`EvalsTo.eval_tape`). Conversions: `EvalsLe.toT`, `EvalsLeT.toDet` (definitional).
* `LoopToT prog base i v bits w c p` / `LoopLeT` and the deterministic `LoopTo` / `LoopLe`: the same
  for the iterations of `loop i` started from the accumulator `v`.

## Contents
* basic facts: determinism (`det`, `det_append`, `val_unique`), `peak_ge`, `cost_pos`, base shift,
  monotonicity, `cast_bits`;
* one rule per constructor with the exact cost/peak formula of `F2e2e.eval` (`EvalsToT.*`,
  `EvalsTo.*`), and the same rules for `EvalsLeT`/`EvalsLe` (bounds of the sub-evaluations replace
  their exact costs/peaks), including `coin`;
* specialised rules for every primitive (`add`, `sub`, `mul`, `div`, `mod`, `lt`, `eq`, `cons`,
  `head`, `tail`, `isNil`), for `EvalsLeT` and `EvalsLe`;
* loop rules: single steps (`stop`, `cont`), invariant/potential (`of_inv`), measure
  (`of_measure`), explicit trajectories (`of_seq`, `of_seq_sup`), for `LoopLeT` (with the consumed
  bits as a function of the loop state) and `LoopLe`;
* `RunsOn_of_EvalsLeT` / `RunsOn_of_EvalsLe`: connection with the Spec's entry point `RunsOn`;
* symbolic evaluation lemmas `eval_succ_*` and `EvalsLeT.of_eval` / `EvalsLe.of_eval`.

Proof plan: every rule is obtained from the one-step inversion lemmas of `F2e2e/Cost/Facts.lean`
after lifting all sub-evaluations to a common fuel with `eval_fuel_mono`, and placing each
sub-evaluation on the tape left by its predecessor with the tape frame lemma
`eval_tape_append_nil`.
-/

namespace F2e2e.Cost

/-! ### Judgments -/

/-- For some fuel, `e` evaluates to `v` at time cost exactly `c` with peak exactly `p`, consuming
exactly the fresh bits `bits` (run on the tape `bits`, it leaves the empty tape). -/
def EvalsToT (prog : List Expr) (base : ℕ) (env : List Val) (bits : List Bool) (e : Expr)
    (v : Val) (c p : ℕ) : Prop :=
  ∃ fuel, eval prog fuel base env bits e = some (v, c, p, [])

/-- `e` evaluates to `v` within time `C` and peak live space `S`, consuming exactly the fresh bits
`bits`. -/
def EvalsLeT (prog : List Expr) (base : ℕ) (env : List Val) (bits : List Bool) (e : Expr)
    (v : Val) (C S : ℕ) : Prop :=
  ∃ c p, EvalsToT prog base env bits e v c p ∧ c ≤ C ∧ p ≤ S

/-- Deterministic exact evaluation: consumes no fresh bits (so it runs identically on every tape,
`EvalsTo.eval_tape`). -/
def EvalsTo (prog : List Expr) (base : ℕ) (env : List Val) (e : Expr) (v : Val) (c p : ℕ) :
    Prop :=
  EvalsToT prog base env [] e v c p

/-- Deterministic bounded evaluation (cut2's `EvalsLe`): `e` evaluates to `v` within time `C` and
peak live space `S`, consuming no fresh bits. -/
def EvalsLe (prog : List Expr) (base : ℕ) (env : List Val) (e : Expr) (v : Val) (C S : ℕ) :
    Prop :=
  ∃ c p, EvalsTo prog base env e v c p ∧ c ≤ C ∧ p ≤ S

theorem EvalsTo.toT {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {c p : ℕ} (h : EvalsTo prog base env e v c p) : EvalsToT prog base env [] e v c p := h

theorem EvalsToT.toDet {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {c p : ℕ} (h : EvalsToT prog base env [] e v c p) : EvalsTo prog base env e v c p := h

theorem EvalsLe.toT {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {C S : ℕ} (h : EvalsLe prog base env e v C S) : EvalsLeT prog base env [] e v C S := h

theorem EvalsLeT.toDet {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {C S : ℕ} (h : EvalsLeT prog base env [] e v C S) : EvalsLe prog base env e v C S := h

/-! ### Basic facts about `EvalsToT` -/

namespace EvalsToT

variable {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
  {c p : ℕ}

theorem of_eval {fuel : ℕ} (h : eval prog fuel base env bits e = some (v, c, p, [])) :
    EvalsToT prog base env bits e v c p :=
  ⟨fuel, h⟩

/-- **Tape frame.** The evaluation runs identically on every tape extending the consumed bits. -/
theorem eval_append (h : EvalsToT prog base env bits e v c p) :
    ∃ fuel, ∀ r, eval prog fuel base env (bits ++ r) e = some (v, c, p, r) := by
  obtain ⟨fuel, h⟩ := h
  exact ⟨fuel, eval_tape_append_nil prog h⟩

/-- A successful evaluation succeeds with every larger fuel, on every tape extending the consumed
bits. -/
theorem eval_of_le (h : EvalsToT prog base env bits e v c p) :
    ∃ N, ∀ m, N ≤ m → ∀ r, eval prog m base env (bits ++ r) e = some (v, c, p, r) := by
  obtain ⟨N, hN⟩ := h.eval_append
  exact ⟨N, fun m hm r => eval_fuel_mono prog hm base env _ e _ (hN r)⟩

theorem of_eval_append {fuel : ℕ} {r : List Bool}
    (h : eval prog fuel base env (bits ++ r) e = some (v, c, p, r)) :
    EvalsToT prog base env bits e v c p := by
  refine ⟨fuel, ?_⟩
  have := eval_tape_append prog h []
  rwa [List.append_nil] at this

/-- Every successful run (on any tape) is an `EvalsToT` judgment for its consumed bits. -/
theorem of_eval_tape {fuel : ℕ} {tape t' : List Bool}
    (h : eval prog fuel base env tape e = some (v, c, p, t')) :
    ∃ bits, tape = bits ++ t' ∧ EvalsToT prog base env bits e v c p := by
  obtain ⟨pre, htape, hf⟩ := eval_tape_frame prog h
  refine ⟨pre, htape, fuel, ?_⟩
  have := hf []
  rwa [List.append_nil] at this

theorem cast_bits {bits' : List Bool} (h : EvalsToT prog base env bits e v c p)
    (hb : bits = bits') : EvalsToT prog base env bits' e v c p :=
  hb ▸ h

theorem det {v' : Val} {c' p' : ℕ} (h₁ : EvalsToT prog base env bits e v c p)
    (h₂ : EvalsToT prog base env bits e v' c' p') : v = v' ∧ c = c' ∧ p = p' := by
  obtain ⟨f₁, h₁⟩ := h₁
  obtain ⟨f₂, h₂⟩ := h₂
  have := eval_det prog base env bits e h₁ h₂
  simp only [Prod.mk.injEq] at this
  exact ⟨this.1, this.2.1, this.2.2.1⟩

/-- **Determinism across consumed bits.** Two evaluations whose consumed bits are both prefixes of
a common tape consumed the same bits and agree. -/
theorem det_append {bits' : List Bool} {v' : Val} {c' p' : ℕ} {r r' : List Bool}
    (h₁ : EvalsToT prog base env bits e v c p) (h₂ : EvalsToT prog base env bits' e v' c' p')
    (ht : bits ++ r = bits' ++ r') : bits = bits' ∧ v = v' ∧ c = c' ∧ p = p' := by
  obtain ⟨f₁, h₁⟩ := h₁.eval_append
  obtain ⟨f₂, h₂⟩ := h₂.eval_append
  have e₁ := h₁ r
  have e₂ := h₂ r'
  rw [← ht] at e₂
  have := eval_det prog base env _ e e₁ e₂
  simp only [Prod.mk.injEq] at this
  obtain ⟨hv, hc, hp, hr⟩ := this
  subst hr
  exact ⟨List.append_cancel_right ht, hv, hc, hp⟩

theorem peak_ge (h : EvalsToT prog base env bits e v c p) : base + valSize v ≤ p := by
  obtain ⟨f, h⟩ := h
  exact eval_peak_ge prog f base env bits e _ h

theorem base_le_peak (h : EvalsToT prog base env bits e v c p) : base ≤ p := by
  have := h.peak_ge
  omega

theorem cost_pos (h : EvalsToT prog base env bits e v c p) : 1 ≤ c := by
  obtain ⟨f, h⟩ := h
  exact eval_cost_pos prog f base env bits e _ h

theorem base_shift (h : EvalsToT prog base env bits e v c p) (d : ℕ) :
    EvalsToT prog (base + d) env bits e v c (p + d) := by
  obtain ⟨f, h⟩ := h
  refine ⟨f, ?_⟩
  rw [eval_base_shift, h]
  rfl

theorem base_unshift {d : ℕ} (h : EvalsToT prog (base + d) env bits e v c p) :
    ∃ p₀, p = p₀ + d ∧ EvalsToT prog base env bits e v c p₀ := by
  obtain ⟨f, h⟩ := h
  rw [eval_base_shift] at h
  obtain ⟨⟨v₀, c₀, p₀, t₀⟩, h₀, h₁⟩ := Option.map_eq_some_iff.mp h
  simp only [Prod.mk.injEq] at h₁
  obtain ⟨rfl, rfl, rfl, rfl⟩ := h₁
  exact ⟨p₀, rfl, f, h₀⟩

end EvalsToT

/-! ### Constructor rules for `EvalsToT` (exact cost and peak) -/

namespace EvalsToT

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsToT prog base env [] (Expr.var i) v 1 (base + valSize v) :=
  ⟨1, (eval_var_iff prog).mpr ⟨v, h, rfl⟩⟩

theorem lit (z : ℤ) :
    EvalsToT prog base env [] (Expr.lit z) (Val.int z) (1 + bitLen z)
      (base + valSize (Val.int z)) :=
  ⟨1, eval_lit_eq prog 0 base env [] z⟩

theorem nil :
    EvalsToT prog base env [] Expr.nil (Val.list []) 1 (base + valSize (Val.list [])) :=
  ⟨1, eval_nil_eq prog 0 base env []⟩

/-- `coin` consumes one fresh bit `b` and returns `encB b` (`1` or `0`). -/
theorem coin (b : Bool) :
    EvalsToT prog base env [b] Expr.coin (encB b) 1 (base + valSize (encB b)) :=
  ⟨1, eval_coin_cons prog 0 base env b []⟩

theorem bin {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {ca pa cb pb c : ℕ}
    (ha : EvalsToT prog base env ba a va ca pa)
    (hb : EvalsToT prog (base + valSize va) env bb b vb cb pb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsToT prog base env (ba ++ bb) (Expr.bin op a b) v (1 + ca + cb + c)
      (max (max pa pb) (base + valSize va + valSize vb + valSize v)) := by
  obtain ⟨fa, ha⟩ := ha.eval_append
  obtain ⟨fb, hb⟩ := hb
  exact ⟨max fa fb + 1, (eval_bin_iff prog).mpr ⟨va, ca, pa, bb, vb, cb, pb, [], v, c,
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (ha bb),
    eval_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hb, hop, rfl⟩⟩

theorem un {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {ca pa c : ℕ}
    (ha : EvalsToT prog base env ba a va ca pa) (hop : evalUn op va = some (v, c)) :
    EvalsToT prog base env ba (Expr.un op a) v (1 + ca + c)
      (max pa (base + valSize va + valSize v)) := by
  obtain ⟨fa, ha⟩ := ha
  exact ⟨fa + 1, (eval_un_iff prog).mpr ⟨va, ca, pa, [], v, c, ha, hop, rfl⟩⟩

theorem ite {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsToT prog base env bc c (Val.int z) cc pc)
    (hv : EvalsToT prog base env bv (if z ≠ 0 then t else f) v cv pv) :
    EvalsToT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + cc + cv) (max pc pv) := by
  obtain ⟨fc, hc⟩ := hc.eval_append
  obtain ⟨fv, hv⟩ := hv
  exact ⟨max fc fv + 1, (eval_ite_iff prog).mpr ⟨z, cc, pc, bv, v, cv, pv, [],
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (hc bv),
    eval_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hv, rfl⟩⟩

theorem ite_true {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsToT prog base env bc c (Val.int z) cc pc) (hz : z ≠ 0)
    (ht : EvalsToT prog base env bv t v cv pv) :
    EvalsToT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + cc + cv) (max pc pv) :=
  ite hc (by rw [if_pos hz]; exact ht)

theorem ite_false {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsToT prog base env bc c (Val.int z) cc pc) (hz : z = 0)
    (hf : EvalsToT prog base env bv f v cv pv) :
    EvalsToT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + cc + cv) (max pc pv) :=
  ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem letE {a b : Expr} {ba bb : List Bool} {va vb : Val} {ca pa cb pb : ℕ}
    (ha : EvalsToT prog base env ba a va ca pa)
    (hb : EvalsToT prog (base + valSize va) (va :: env) bb b vb cb pb) :
    EvalsToT prog base env (ba ++ bb) (Expr.letE a b) vb (1 + ca + cb) (max pa pb) := by
  obtain ⟨fa, ha⟩ := ha.eval_append
  obtain ⟨fb, hb⟩ := hb
  exact ⟨max fa fb + 1, (eval_letE_iff prog).mpr ⟨va, ca, pa, bb, vb, cb, pb, [],
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (ha bb),
    eval_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hb, rfl⟩⟩

theorem call {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val} {ca pa cb pb : ℕ}
    (ha : EvalsToT prog base env ba a va ca pa) (hbody : prog[i]? = some body)
    (hb : EvalsToT prog (base + valSize va) [va] bb body vb cb pb) :
    EvalsToT prog base env (ba ++ bb) (Expr.call i a) vb (1 + ca + cb) (max pa pb) := by
  obtain ⟨fa, ha⟩ := ha.eval_append
  obtain ⟨fb, hb⟩ := hb
  exact ⟨max fa fb + 1, (eval_call_iff prog).mpr ⟨va, ca, pa, bb, body, vb, cb, pb, [],
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (ha bb), hbody,
    eval_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hb, rfl⟩⟩

end EvalsToT

/-! ### Constructor rules for `EvalsTo` (deterministic, exact cost and peak) -/

namespace EvalsTo

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem of_eval {fuel : ℕ} {tape : List Bool} {e : Expr} {v : Val} {c p : ℕ}
    (h : eval prog fuel base env tape e = some (v, c, p, tape)) : EvalsTo prog base env e v c p :=
  ⟨fuel, eval_tape_indep prog h []⟩

/-- A deterministic evaluation runs identically on every tape, leaving it untouched. -/
theorem eval_tape {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) :
    ∃ fuel, ∀ tape, eval prog fuel base env tape e = some (v, c, p, tape) :=
  EvalsToT.eval_append h

/-- A successful evaluation succeeds with every larger fuel, on every tape. -/
theorem eval_of_le {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) :
    ∃ N, ∀ m, N ≤ m → ∀ tape, eval prog m base env tape e = some (v, c, p, tape) :=
  EvalsToT.eval_of_le h

theorem det {e : Expr} {v v' : Val} {c p c' p' : ℕ} (h₁ : EvalsTo prog base env e v c p)
    (h₂ : EvalsTo prog base env e v' c' p') : v = v' ∧ c = c' ∧ p = p' :=
  EvalsToT.det h₁ h₂

theorem peak_ge {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) :
    base + valSize v ≤ p :=
  EvalsToT.peak_ge h

theorem base_le_peak {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) :
    base ≤ p :=
  EvalsToT.base_le_peak h

theorem cost_pos {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) : 1 ≤ c :=
  EvalsToT.cost_pos h

theorem base_shift {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) (d : ℕ) :
    EvalsTo prog (base + d) env e v c (p + d) :=
  EvalsToT.base_shift h d

theorem base_unshift {e : Expr} {v : Val} {c p d : ℕ} (h : EvalsTo prog (base + d) env e v c p) :
    ∃ p₀, p = p₀ + d ∧ EvalsTo prog base env e v c p₀ :=
  EvalsToT.base_unshift h

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsTo prog base env (Expr.var i) v 1 (base + valSize v) :=
  EvalsToT.var h

theorem lit (z : ℤ) :
    EvalsTo prog base env (Expr.lit z) (Val.int z) (1 + bitLen z) (base + valSize (Val.int z)) :=
  EvalsToT.lit z

theorem nil : EvalsTo prog base env Expr.nil (Val.list []) 1 (base + valSize (Val.list [])) :=
  EvalsToT.nil

theorem bin {op : BinOp} {a b : Expr} {va vb v : Val} {ca pa cb pb c : ℕ}
    (ha : EvalsTo prog base env a va ca pa) (hb : EvalsTo prog (base + valSize va) env b vb cb pb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsTo prog base env (Expr.bin op a b) v (1 + ca + cb + c)
      (max (max pa pb) (base + valSize va + valSize vb + valSize v)) :=
  EvalsToT.bin ha hb hop

theorem un {op : UnOp} {a : Expr} {va v : Val} {ca pa c : ℕ}
    (ha : EvalsTo prog base env a va ca pa) (hop : evalUn op va = some (v, c)) :
    EvalsTo prog base env (Expr.un op a) v (1 + ca + c) (max pa (base + valSize va + valSize v)) :=
  EvalsToT.un ha hop

theorem ite {c t f : Expr} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsTo prog base env c (Val.int z) cc pc)
    (hv : EvalsTo prog base env (if z ≠ 0 then t else f) v cv pv) :
    EvalsTo prog base env (Expr.ite c t f) v (1 + cc + cv) (max pc pv) :=
  EvalsToT.ite hc hv

theorem ite_true {c t f : Expr} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsTo prog base env c (Val.int z) cc pc) (hz : z ≠ 0)
    (ht : EvalsTo prog base env t v cv pv) :
    EvalsTo prog base env (Expr.ite c t f) v (1 + cc + cv) (max pc pv) :=
  EvalsToT.ite_true hc hz ht

theorem ite_false {c t f : Expr} {z : ℤ} {v : Val} {cc pc cv pv : ℕ}
    (hc : EvalsTo prog base env c (Val.int z) cc pc) (hz : z = 0)
    (hf : EvalsTo prog base env f v cv pv) :
    EvalsTo prog base env (Expr.ite c t f) v (1 + cc + cv) (max pc pv) :=
  EvalsToT.ite_false hc hz hf

theorem letE {a b : Expr} {va vb : Val} {ca pa cb pb : ℕ}
    (ha : EvalsTo prog base env a va ca pa)
    (hb : EvalsTo prog (base + valSize va) (va :: env) b vb cb pb) :
    EvalsTo prog base env (Expr.letE a b) vb (1 + ca + cb) (max pa pb) :=
  EvalsToT.letE ha hb

theorem call {i : ℕ} {a body : Expr} {va vb : Val} {ca pa cb pb : ℕ}
    (ha : EvalsTo prog base env a va ca pa) (hbody : prog[i]? = some body)
    (hb : EvalsTo prog (base + valSize va) [va] body vb cb pb) :
    EvalsTo prog base env (Expr.call i a) vb (1 + ca + cb) (max pa pb) :=
  EvalsToT.call ha hbody hb

theorem toLe {e : Expr} {v : Val} {c p : ℕ} (h : EvalsTo prog base env e v c p) :
    EvalsLe prog base env e v c p :=
  ⟨c, p, h, le_refl _, le_refl _⟩

end EvalsTo

theorem EvalsToT.toLe {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} {c p : ℕ} (h : EvalsToT prog base env bits e v c p) :
    EvalsLeT prog base env bits e v c p :=
  ⟨c, p, h, le_refl _, le_refl _⟩

/-! ### Basic facts about `EvalsLeT` -/

namespace EvalsLeT

variable {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
  {C S : ℕ}

theorem mono {C' S' : ℕ} (h : EvalsLeT prog base env bits e v C S) (hC : C ≤ C') (hS : S ≤ S') :
    EvalsLeT prog base env bits e v C' S' := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  exact ⟨c, p, h, hc.trans hC, hp.trans hS⟩

theorem cast_bits {bits' : List Bool} (h : EvalsLeT prog base env bits e v C S)
    (hb : bits = bits') : EvalsLeT prog base env bits' e v C S :=
  hb ▸ h

theorem peak_ge (h : EvalsLeT prog base env bits e v C S) : base + valSize v ≤ S := by
  obtain ⟨c, p, h, -, hp⟩ := h
  exact h.peak_ge.trans hp

theorem cost_pos (h : EvalsLeT prog base env bits e v C S) : 1 ≤ C := by
  obtain ⟨c, p, h, hc, -⟩ := h
  exact h.cost_pos.trans hc

theorem base_shift (h : EvalsLeT prog base env bits e v C S) (d : ℕ) :
    EvalsLeT prog (base + d) env bits e v C (S + d) := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  exact ⟨c, p + d, h.base_shift d, hc, by omega⟩

/-- A spec proved at base `0` holds at every base, with the peak shifted. -/
theorem of_base_zero (h : EvalsLeT prog 0 env bits e v C S) (base : ℕ) :
    EvalsLeT prog base env bits e v C (base + S) := by
  have := h.base_shift base
  rw [Nat.zero_add, Nat.add_comm] at this
  exact this

theorem base_unshift {d : ℕ} (h : EvalsLeT prog (base + d) env bits e v C (S + d)) :
    EvalsLeT prog base env bits e v C S := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  obtain ⟨p₀, rfl, h₀⟩ := h.base_unshift
  exact ⟨c, p₀, h₀, hc, by omega⟩

/-- Values are determined: two evaluations consuming the same bits agree. -/
theorem val_unique {v' : Val} {C' S' : ℕ} (h : EvalsLeT prog base env bits e v C S)
    (h' : EvalsLeT prog base env bits e v' C' S') : v = v' := by
  obtain ⟨c, p, h, -, -⟩ := h
  obtain ⟨c', p', h', -, -⟩ := h'
  exact (h.det h').1

/-- Two evaluations whose consumed bits are prefixes of a common tape consumed the same bits and
return the same value. -/
theorem val_unique_append {bits' : List Bool} {v' : Val} {C' S' : ℕ} {r r' : List Bool}
    (h : EvalsLeT prog base env bits e v C S) (h' : EvalsLeT prog base env bits' e v' C' S')
    (ht : bits ++ r = bits' ++ r') : bits = bits' ∧ v = v' := by
  obtain ⟨c, p, h, -, -⟩ := h
  obtain ⟨c', p', h', -, -⟩ := h'
  obtain ⟨hb, hv, -, -⟩ := h.det_append h' ht
  exact ⟨hb, hv⟩

/-- Symbolic evaluation: to prove a bound, compute `eval` on the tape `bits` with an explicit
fuel (e.g. by `simp`). -/
theorem of_eval (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env bits e = some (v, c, p, []) ∧ c ≤ C ∧ p ≤ S) :
    EvalsLeT prog base env bits e v C S := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  exact ⟨c, p, ⟨fuel, h⟩, hc, hp⟩

/-- **Tape frame.** Within the bounds, the evaluation runs on every tape extending the consumed
bits. -/
theorem eval_append (h : EvalsLeT prog base env bits e v C S) :
    ∃ fuel c p, c ≤ C ∧ p ≤ S ∧ ∀ r, eval prog fuel base env (bits ++ r) e = some (v, c, p, r) := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  obtain ⟨fuel, hf⟩ := h.eval_append
  exact ⟨fuel, c, p, hc, hp, hf⟩

end EvalsLeT

/-! ### Constructor rules for `EvalsLeT` -/

namespace EvalsLeT

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsLeT prog base env [] (Expr.var i) v 1 (base + valSize v) :=
  (EvalsToT.var h).toLe

theorem lit (z : ℤ) :
    EvalsLeT prog base env [] (Expr.lit z) (Val.int z) (1 + bitLen z)
      (base + valSize (Val.int z)) :=
  (EvalsToT.lit z).toLe

theorem nil :
    EvalsLeT prog base env [] Expr.nil (Val.list []) 1 (base + valSize (Val.list [])) :=
  EvalsToT.nil.toLe

/-- `coin` consumes one fresh bit `b` and returns `encB b` (`1` or `0`). -/
theorem coin (b : Bool) :
    EvalsLeT prog base env [b] Expr.coin (encB b) 1 (base + valSize (encB b)) :=
  (EvalsToT.coin b).toLe

theorem bin {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {Ca Sa Cb Sb c : ℕ}
    (ha : EvalsLeT prog base env ba a va Ca Sa)
    (hb : EvalsLeT prog (base + valSize va) env bb b vb Cb Sb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin op a b) v (1 + Ca + Cb + c)
      (max (max Sa Sb) (base + valSize va + valSize vb + valSize v)) := by
  obtain ⟨ca, pa, ha, hca, hpa⟩ := ha
  obtain ⟨cb, pb, hb, hcb, hpb⟩ := hb
  exact ⟨_, _, EvalsToT.bin ha hb hop, by omega,
    max_le_max (max_le_max hpa hpb) (le_refl _)⟩

theorem un {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {Ca Sa c : ℕ}
    (ha : EvalsLeT prog base env ba a va Ca Sa) (hop : evalUn op va = some (v, c)) :
    EvalsLeT prog base env ba (Expr.un op a) v (1 + Ca + c)
      (max Sa (base + valSize va + valSize v)) := by
  obtain ⟨ca, pa, ha, hca, hpa⟩ := ha
  exact ⟨_, _, EvalsToT.un ha hop, by omega, max_le_max hpa (le_refl _)⟩

theorem ite {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLeT prog base env bc c (Val.int z) Cc Sc)
    (hv : EvalsLeT prog base env bv (if z ≠ 0 then t else f) v Cv Sv) :
    EvalsLeT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) := by
  obtain ⟨cc, pc, hc, hcc, hpc⟩ := hc
  obtain ⟨cv, pv, hv, hcv, hpv⟩ := hv
  exact ⟨_, _, EvalsToT.ite hc hv, by omega, max_le_max hpc hpv⟩

theorem ite_true {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLeT prog base env bc c (Val.int z) Cc Sc) (hz : z ≠ 0)
    (ht : EvalsLeT prog base env bv t v Cv Sv) :
    EvalsLeT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) :=
  ite hc (by rw [if_pos hz]; exact ht)

theorem ite_false {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLeT prog base env bc c (Val.int z) Cc Sc) (hz : z = 0)
    (hf : EvalsLeT prog base env bv f v Cv Sv) :
    EvalsLeT prog base env (bc ++ bv) (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) :=
  ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem letE {a b : Expr} {ba bb : List Bool} {va vb : Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a va Ca Sa)
    (hb : EvalsLeT prog (base + valSize va) (va :: env) bb b vb Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.letE a b) vb (1 + Ca + Cb) (max Sa Sb) := by
  obtain ⟨ca, pa, ha, hca, hpa⟩ := ha
  obtain ⟨cb, pb, hb, hcb, hpb⟩ := hb
  exact ⟨_, _, EvalsToT.letE ha hb, by omega, max_le_max hpa hpb⟩

theorem call {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a va Ca Sa) (hbody : prog[i]? = some body)
    (hb : EvalsLeT prog (base + valSize va) [va] bb body vb Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.call i a) vb (1 + Ca + Cb) (max Sa Sb) := by
  obtain ⟨ca, pa, ha, hca, hpa⟩ := ha
  obtain ⟨cb, pb, hb, hcb, hpb⟩ := hb
  exact ⟨_, _, EvalsToT.call ha hbody hb, by omega, max_le_max hpa hpb⟩

/-! #### Primitive operations -/

theorem add {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.add a b) (Val.int (x + y))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x + y)))) :=
  bin ha hb rfl

theorem sub {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.sub a b) (Val.int (x - y))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x - y)))) :=
  bin ha hb rfl

theorem mul {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.mul a b) (Val.int (x * y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x * y)))) :=
  bin ha hb rfl

theorem div {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) (hy : y ≠ 0) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.div a b) (Val.int (x / y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x / y)))) :=
  bin ha hb (by simp [evalBin, hy])

theorem mod {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) (hy : y ≠ 0) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.mod a b) (Val.int (x % y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x % y)))) :=
  bin ha hb (by simp [evalBin, hy])

theorem lt {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.lt a b) (Val.int (if x < y then 1 else 0))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x < y then 1 else 0)))) :=
  bin ha hb rfl

theorem eq {a b : Expr} {ba bb : List Bool} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.int x) Ca Sa)
    (hb : EvalsLeT prog (base + valSize (Val.int x)) env bb b (Val.int y) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.eq a b) (Val.int (if x = y then 1 else 0))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x = y then 1 else 0)))) :=
  bin ha hb rfl

theorem cons {a b : Expr} {ba bb : List Bool} {x : Val} {l : List Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLeT prog base env ba a x Ca Sa)
    (hb : EvalsLeT prog (base + valSize x) env bb b (Val.list l) Cb Sb) :
    EvalsLeT prog base env (ba ++ bb) (Expr.bin BinOp.cons a b) (Val.list (x :: l))
      (1 + Ca + Cb + 1)
      (max (max Sa Sb) (base + valSize x + valSize (Val.list l) + valSize (Val.list (x :: l)))) :=
  bin ha hb (by cases x <;> rfl)

theorem head {a : Expr} {ba : List Bool} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.list (x :: l)) Ca Sa) :
    EvalsLeT prog base env ba (Expr.un UnOp.head a) x (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize x)) :=
  un ha rfl

theorem tail {a : Expr} {ba : List Bool} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.list (x :: l)) Ca Sa) :
    EvalsLeT prog base env ba (Expr.un UnOp.tail a) (Val.list l) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.list l))) :=
  un ha rfl

theorem isNil_nil {a : Expr} {ba : List Bool} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.list []) Ca Sa) :
    EvalsLeT prog base env ba (Expr.un UnOp.isNil a) (Val.int 1) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list []) + valSize (Val.int 1))) :=
  un ha rfl

theorem isNil_cons {a : Expr} {ba : List Bool} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLeT prog base env ba a (Val.list (x :: l)) Ca Sa) :
    EvalsLeT prog base env ba (Expr.un UnOp.isNil a) (Val.int 0) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.int 0))) :=
  un ha rfl

end EvalsLeT

/-! ### Basic facts about `EvalsLe` (deterministic) -/

namespace EvalsLe

variable {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val} {C S : ℕ}

theorem mono {C' S' : ℕ} (h : EvalsLe prog base env e v C S) (hC : C ≤ C') (hS : S ≤ S') :
    EvalsLe prog base env e v C' S' :=
  EvalsLeT.mono h hC hS

theorem peak_ge (h : EvalsLe prog base env e v C S) : base + valSize v ≤ S :=
  EvalsLeT.peak_ge h

theorem cost_pos (h : EvalsLe prog base env e v C S) : 1 ≤ C :=
  EvalsLeT.cost_pos h

theorem base_shift (h : EvalsLe prog base env e v C S) (d : ℕ) :
    EvalsLe prog (base + d) env e v C (S + d) :=
  EvalsLeT.base_shift h d

/-- A spec proved at base `0` holds at every base, with the peak shifted. -/
theorem of_base_zero (h : EvalsLe prog 0 env e v C S) (base : ℕ) :
    EvalsLe prog base env e v C (base + S) :=
  EvalsLeT.of_base_zero h base

theorem base_unshift {d : ℕ} (h : EvalsLe prog (base + d) env e v C (S + d)) :
    EvalsLe prog base env e v C S :=
  EvalsLeT.base_unshift h

/-- Values are determined: two evaluations of the same expression agree. -/
theorem val_unique {v' : Val} {C' S' : ℕ} (h : EvalsLe prog base env e v C S)
    (h' : EvalsLe prog base env e v' C' S') : v = v' :=
  EvalsLeT.val_unique h h'

/-- Symbolic evaluation: to prove a bound, compute `eval` on the empty tape with an explicit fuel
(e.g. by `simp`). -/
theorem of_eval (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env [] e = some (v, c, p, []) ∧ c ≤ C ∧ p ≤ S) :
    EvalsLe prog base env e v C S :=
  EvalsLeT.of_eval fuel h

/-- A deterministic evaluation runs within the bounds on every tape, leaving it untouched. -/
theorem eval_tape (h : EvalsLe prog base env e v C S) :
    ∃ fuel c p, c ≤ C ∧ p ≤ S ∧ ∀ tape, eval prog fuel base env tape e = some (v, c, p, tape) :=
  EvalsLeT.eval_append h

end EvalsLe

/-! ### Constructor rules for `EvalsLe` (deterministic; cut2's rules verbatim) -/

namespace EvalsLe

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsLe prog base env (Expr.var i) v 1 (base + valSize v) :=
  (EvalsTo.var h).toLe

theorem lit (z : ℤ) :
    EvalsLe prog base env (Expr.lit z) (Val.int z) (1 + bitLen z) (base + valSize (Val.int z)) :=
  (EvalsTo.lit z).toLe

theorem nil : EvalsLe prog base env Expr.nil (Val.list []) 1 (base + valSize (Val.list [])) :=
  EvalsTo.nil.toLe

theorem bin {op : BinOp} {a b : Expr} {va vb v : Val} {Ca Sa Cb Sb c : ℕ}
    (ha : EvalsLe prog base env a va Ca Sa) (hb : EvalsLe prog (base + valSize va) env b vb Cb Sb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsLe prog base env (Expr.bin op a b) v (1 + Ca + Cb + c)
      (max (max Sa Sb) (base + valSize va + valSize vb + valSize v)) :=
  EvalsLeT.bin ha hb hop

theorem un {op : UnOp} {a : Expr} {va v : Val} {Ca Sa c : ℕ}
    (ha : EvalsLe prog base env a va Ca Sa) (hop : evalUn op va = some (v, c)) :
    EvalsLe prog base env (Expr.un op a) v (1 + Ca + c) (max Sa (base + valSize va + valSize v)) :=
  EvalsLeT.un ha hop

theorem ite {c t f : Expr} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLe prog base env c (Val.int z) Cc Sc)
    (hv : EvalsLe prog base env (if z ≠ 0 then t else f) v Cv Sv) :
    EvalsLe prog base env (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) :=
  EvalsLeT.ite hc hv

theorem ite_true {c t f : Expr} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLe prog base env c (Val.int z) Cc Sc) (hz : z ≠ 0)
    (ht : EvalsLe prog base env t v Cv Sv) :
    EvalsLe prog base env (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) :=
  EvalsLeT.ite_true hc hz ht

theorem ite_false {c t f : Expr} {z : ℤ} {v : Val} {Cc Sc Cv Sv : ℕ}
    (hc : EvalsLe prog base env c (Val.int z) Cc Sc) (hz : z = 0)
    (hf : EvalsLe prog base env f v Cv Sv) :
    EvalsLe prog base env (Expr.ite c t f) v (1 + Cc + Cv) (max Sc Sv) :=
  EvalsLeT.ite_false hc hz hf

theorem letE {a b : Expr} {va vb : Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a va Ca Sa)
    (hb : EvalsLe prog (base + valSize va) (va :: env) b vb Cb Sb) :
    EvalsLe prog base env (Expr.letE a b) vb (1 + Ca + Cb) (max Sa Sb) :=
  EvalsLeT.letE ha hb

theorem call {i : ℕ} {a body : Expr} {va vb : Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a va Ca Sa) (hbody : prog[i]? = some body)
    (hb : EvalsLe prog (base + valSize va) [va] body vb Cb Sb) :
    EvalsLe prog base env (Expr.call i a) vb (1 + Ca + Cb) (max Sa Sb) :=
  EvalsLeT.call ha hbody hb

/-! #### Primitive operations -/

theorem add {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.add a b) (Val.int (x + y))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x + y)))) :=
  bin ha hb rfl

theorem sub {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.sub a b) (Val.int (x - y))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x - y)))) :=
  bin ha hb rfl

theorem mul {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.mul a b) (Val.int (x * y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x * y)))) :=
  bin ha hb rfl

theorem div {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) (hy : y ≠ 0) :
    EvalsLe prog base env (Expr.bin BinOp.div a b) (Val.int (x / y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x / y)))) :=
  bin ha hb (by simp [evalBin, hy])

theorem mod {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) (hy : y ≠ 0) :
    EvalsLe prog base env (Expr.bin BinOp.mod a b) (Val.int (x % y))
      (1 + Ca + Cb + (1 + (bitLen x + 1) * (bitLen y + 1)))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (x % y)))) :=
  bin ha hb (by simp [evalBin, hy])

theorem lt {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.lt a b) (Val.int (if x < y then 1 else 0))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x < y then 1 else 0)))) :=
  bin ha hb rfl

theorem eq {a b : Expr} {x y : ℤ} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a (Val.int x) Ca Sa)
    (hb : EvalsLe prog (base + valSize (Val.int x)) env b (Val.int y) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.eq a b) (Val.int (if x = y then 1 else 0))
      (1 + Ca + Cb + (1 + bitLen x + bitLen y))
      (max (max Sa Sb) (base + valSize (Val.int x) + valSize (Val.int y) +
        valSize (Val.int (if x = y then 1 else 0)))) :=
  bin ha hb rfl

theorem cons {a b : Expr} {x : Val} {l : List Val} {Ca Sa Cb Sb : ℕ}
    (ha : EvalsLe prog base env a x Ca Sa)
    (hb : EvalsLe prog (base + valSize x) env b (Val.list l) Cb Sb) :
    EvalsLe prog base env (Expr.bin BinOp.cons a b) (Val.list (x :: l)) (1 + Ca + Cb + 1)
      (max (max Sa Sb) (base + valSize x + valSize (Val.list l) + valSize (Val.list (x :: l)))) :=
  bin ha hb (by cases x <;> rfl)

theorem head {a : Expr} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLe prog base env a (Val.list (x :: l)) Ca Sa) :
    EvalsLe prog base env (Expr.un UnOp.head a) x (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize x)) :=
  un ha rfl

theorem tail {a : Expr} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLe prog base env a (Val.list (x :: l)) Ca Sa) :
    EvalsLe prog base env (Expr.un UnOp.tail a) (Val.list l) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.list l))) :=
  un ha rfl

theorem isNil_nil {a : Expr} {Ca Sa : ℕ}
    (ha : EvalsLe prog base env a (Val.list []) Ca Sa) :
    EvalsLe prog base env (Expr.un UnOp.isNil a) (Val.int 1) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list []) + valSize (Val.int 1))) :=
  un ha rfl

theorem isNil_cons {a : Expr} {x : Val} {l : List Val} {Ca Sa : ℕ}
    (ha : EvalsLe prog base env a (Val.list (x :: l)) Ca Sa) :
    EvalsLe prog base env (Expr.un UnOp.isNil a) (Val.int 0) (1 + Ca + 1)
      (max Sa (base + valSize (Val.list (x :: l)) + valSize (Val.int 0))) :=
  un ha rfl

end EvalsLe

/-! ### Loops

`loop i a` evaluates `a` to the initial accumulator and then runs `loopRun`: every iteration runs
the body of function `i` with environment `[v]` at base `base + valSize v` (on the tape left by the
previous iteration) and costs one unit plus the body; a result `[0, v']` stops with `v'`, a result
`[flag, v']` with `flag ≠ 0` continues from `v'`; the peak is the maximum over the iterations. -/

/-- For some fuel, the iterations of `loop i` from the accumulator `v` (in a context of live size
`base`) return `w` at cost exactly `c` and peak exactly `p`, consuming exactly the fresh bits
`bits`. -/
def LoopToT (prog : List Expr) (base i : ℕ) (v : Val) (bits : List Bool) (w : Val) (c p : ℕ) :
    Prop :=
  ∃ fuel, loopRun prog fuel base i v bits = some (w, c, p, [])

/-- The iterations of `loop i` from `v` return `w` within time `C` and peak space `S`, consuming
exactly the fresh bits `bits`. -/
def LoopLeT (prog : List Expr) (base i : ℕ) (v : Val) (bits : List Bool) (w : Val) (C S : ℕ) :
    Prop :=
  ∃ c p, LoopToT prog base i v bits w c p ∧ c ≤ C ∧ p ≤ S

/-- Deterministic loop iterations (no fresh bits consumed). -/
def LoopTo (prog : List Expr) (base i : ℕ) (v w : Val) (c p : ℕ) : Prop :=
  LoopToT prog base i v [] w c p

/-- Deterministic loop iterations within time `C` and peak space `S` (cut2's `LoopLe`). -/
def LoopLe (prog : List Expr) (base i : ℕ) (v w : Val) (C S : ℕ) : Prop :=
  ∃ c p, LoopTo prog base i v w c p ∧ c ≤ C ∧ p ≤ S

theorem LoopLe.toT {prog : List Expr} {base i : ℕ} {v w : Val} {C S : ℕ}
    (h : LoopLe prog base i v w C S) : LoopLeT prog base i v [] w C S := h

theorem LoopLeT.toDet {prog : List Expr} {base i : ℕ} {v w : Val} {C S : ℕ}
    (h : LoopLeT prog base i v [] w C S) : LoopLe prog base i v w C S := h

namespace LoopToT

variable {prog : List Expr} {base i : ℕ} {v w : Val} {bits : List Bool} {c p : ℕ}

theorem eval_append (h : LoopToT prog base i v bits w c p) :
    ∃ fuel, ∀ r, loopRun prog fuel base i v (bits ++ r) = some (w, c, p, r) := by
  obtain ⟨fuel, h⟩ := h
  exact ⟨fuel, loopRun_tape_append_nil prog h⟩

theorem cast_bits {bits' : List Bool} (h : LoopToT prog base i v bits w c p)
    (hb : bits = bits') : LoopToT prog base i v bits' w c p :=
  hb ▸ h

theorem det {w' : Val} {c' p' : ℕ} (h₁ : LoopToT prog base i v bits w c p)
    (h₂ : LoopToT prog base i v bits w' c' p') : w = w' ∧ c = c' ∧ p = p' := by
  obtain ⟨f₁, h₁⟩ := h₁
  obtain ⟨f₂, h₂⟩ := h₂
  have := loopRun_det prog base i v bits h₁ h₂
  simp only [Prod.mk.injEq] at this
  exact ⟨this.1, this.2.1, this.2.2.1⟩

/-- The initial accumulator and the result are both live at some point. -/
theorem peak_ge (h : LoopToT prog base i v bits w c p) :
    base + valSize v ≤ p ∧ base + valSize w ≤ p := by
  obtain ⟨f, h⟩ := h
  exact loopRun_peak_ge prog f base i v bits _ h

theorem cost_pos (h : LoopToT prog base i v bits w c p) : 1 ≤ c := by
  obtain ⟨f, h⟩ := h
  exact loopRun_cost_pos prog f base i v bits _ h

theorem base_shift (h : LoopToT prog base i v bits w c p) (d : ℕ) :
    LoopToT prog (base + d) i v bits w c (p + d) := by
  obtain ⟨f, h⟩ := h
  refine ⟨f, ?_⟩
  rw [loopRun_base_shift, h]
  rfl

/-- The stopping iteration: the body returns `[0, v']`. -/
theorem stop {body : Expr} {v' : Val} {cb pb : ℕ} (hbody : prog[i]? = some body)
    (hb : EvalsToT prog (base + valSize v) [v] bits body (Val.list [Val.int 0, v']) cb pb) :
    LoopToT prog base i v bits v' (1 + cb) pb := by
  obtain ⟨fb, hb⟩ := hb
  exact ⟨fb + 1, (loopRun_succ_iff prog).mpr
    ⟨body, 0, v', cb, pb, [], hbody, hb, Or.inl ⟨rfl, rfl⟩⟩⟩

/-- A continuing iteration: the body returns `[flag, v']` with `flag ≠ 0`. -/
theorem cont {body : Expr} {flag : ℤ} {v' : Val} {bb bw : List Bool} {cb pb cw pw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsToT prog (base + valSize v) [v] bb body (Val.list [Val.int flag, v']) cb pb)
    (hflag : flag ≠ 0) (hrest : LoopToT prog base i v' bw w cw pw) :
    LoopToT prog base i v (bb ++ bw) w (1 + cb + cw) (max pb pw) := by
  obtain ⟨fb, hb⟩ := hb.eval_append
  obtain ⟨fw, hw⟩ := hrest
  exact ⟨max fb fw + 1, (loopRun_succ_iff prog).mpr ⟨body, flag, v', cb, pb, bw, hbody,
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (hb bw),
    Or.inr ⟨hflag, w, cw, pw, [], loopRun_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hw, rfl⟩⟩⟩

theorem toLe (h : LoopToT prog base i v bits w c p) : LoopLeT prog base i v bits w c p :=
  ⟨c, p, h, le_refl _, le_refl _⟩

end LoopToT

theorem EvalsToT.loop {prog : List Expr} {base : ℕ} {env : List Val} {i : ℕ} {a : Expr}
    {ba bl : List Bool} {va w : Val} {ca pa cw pw : ℕ} (ha : EvalsToT prog base env ba a va ca pa)
    (hl : LoopToT prog base i va bl w cw pw) :
    EvalsToT prog base env (ba ++ bl) (Expr.loop i a) w (1 + ca + cw) (max pa pw) := by
  obtain ⟨fa, ha⟩ := ha.eval_append
  obtain ⟨fl, hl⟩ := hl
  exact ⟨max fa fl + 1, (eval_loop_iff prog).mpr ⟨va, ca, pa, bl, w, cw, pw, [],
    eval_fuel_mono prog (le_max_left _ _) _ _ _ _ _ (ha bl),
    loopRun_fuel_mono prog (le_max_right _ _) _ _ _ _ _ hl, rfl⟩⟩

namespace LoopTo

variable {prog : List Expr} {base i : ℕ} {v w : Val} {c p : ℕ}

theorem det {w' : Val} {c' p' : ℕ} (h₁ : LoopTo prog base i v w c p)
    (h₂ : LoopTo prog base i v w' c' p') : w = w' ∧ c = c' ∧ p = p' :=
  LoopToT.det h₁ h₂

theorem peak_ge (h : LoopTo prog base i v w c p) :
    base + valSize v ≤ p ∧ base + valSize w ≤ p :=
  LoopToT.peak_ge h

theorem cost_pos (h : LoopTo prog base i v w c p) : 1 ≤ c :=
  LoopToT.cost_pos h

theorem base_shift (h : LoopTo prog base i v w c p) (d : ℕ) :
    LoopTo prog (base + d) i v w c (p + d) :=
  LoopToT.base_shift h d

theorem stop {body : Expr} {v' : Val} {cb pb : ℕ} (hbody : prog[i]? = some body)
    (hb : EvalsTo prog (base + valSize v) [v] body (Val.list [Val.int 0, v']) cb pb) :
    LoopTo prog base i v v' (1 + cb) pb :=
  LoopToT.stop hbody hb

theorem cont {body : Expr} {flag : ℤ} {v' : Val} {cb pb cw pw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsTo prog (base + valSize v) [v] body (Val.list [Val.int flag, v']) cb pb)
    (hflag : flag ≠ 0) (hrest : LoopTo prog base i v' w cw pw) :
    LoopTo prog base i v w (1 + cb + cw) (max pb pw) :=
  LoopToT.cont hbody hb hflag hrest

theorem toLe (h : LoopTo prog base i v w c p) : LoopLe prog base i v w c p :=
  ⟨c, p, h, le_refl _, le_refl _⟩

end LoopTo

theorem EvalsTo.loop {prog : List Expr} {base : ℕ} {env : List Val} {i : ℕ} {a : Expr}
    {va w : Val} {ca pa cw pw : ℕ} (ha : EvalsTo prog base env a va ca pa)
    (hl : LoopTo prog base i va w cw pw) :
    EvalsTo prog base env (Expr.loop i a) w (1 + ca + cw) (max pa pw) :=
  EvalsToT.loop ha hl

namespace LoopLeT

variable {prog : List Expr} {base i : ℕ} {v w : Val} {bits : List Bool} {C S : ℕ}

theorem mono {C' S' : ℕ} (h : LoopLeT prog base i v bits w C S) (hC : C ≤ C') (hS : S ≤ S') :
    LoopLeT prog base i v bits w C' S' := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  exact ⟨c, p, h, hc.trans hC, hp.trans hS⟩

theorem cast_bits {bits' : List Bool} (h : LoopLeT prog base i v bits w C S)
    (hb : bits = bits') : LoopLeT prog base i v bits' w C S :=
  hb ▸ h

theorem peak_ge (h : LoopLeT prog base i v bits w C S) :
    base + valSize v ≤ S ∧ base + valSize w ≤ S := by
  obtain ⟨c, p, h, -, hp⟩ := h
  exact ⟨h.peak_ge.1.trans hp, h.peak_ge.2.trans hp⟩

theorem base_shift (h : LoopLeT prog base i v bits w C S) (d : ℕ) :
    LoopLeT prog (base + d) i v bits w C (S + d) := by
  obtain ⟨c, p, h, hc, hp⟩ := h
  exact ⟨c, p + d, h.base_shift d, hc, by omega⟩

theorem stop {body : Expr} {v' : Val} {Cb Sb : ℕ} (hbody : prog[i]? = some body)
    (hb : EvalsLeT prog (base + valSize v) [v] bits body (Val.list [Val.int 0, v']) Cb Sb) :
    LoopLeT prog base i v bits v' (1 + Cb) Sb := by
  obtain ⟨cb, pb, hb, hcb, hpb⟩ := hb
  exact ⟨_, _, LoopToT.stop hbody hb, by omega, hpb⟩

theorem cont {body : Expr} {flag : ℤ} {v' : Val} {bb bw : List Bool} {Cb Sb Cw Sw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsLeT prog (base + valSize v) [v] bb body (Val.list [Val.int flag, v']) Cb Sb)
    (hflag : flag ≠ 0) (hrest : LoopLeT prog base i v' bw w Cw Sw) :
    LoopLeT prog base i v (bb ++ bw) w (1 + Cb + Cw) (max Sb Sw) := by
  obtain ⟨cb, pb, hb, hcb, hpb⟩ := hb
  obtain ⟨cw, pw, hw, hcw, hpw⟩ := hrest
  exact ⟨_, _, LoopToT.cont hbody hb hflag hw, by omega, max_le_max hpb hpw⟩

/-- **Loop rule (invariant + potential, with fresh bits).** `Inv` is an invariant of the
accumulator states (encoded by `enc`), `bitsOf s` the fresh bits the remaining iterations consume
from state `s`, and `Φ` a potential bounding the remaining cost: every iteration from a state `s`
satisfying `Inv` stays within peak `S` and either stops with an output satisfying `Post`, consuming
`bitsOf s` (within cost `Φ s - 1`), or consumes a prefix `bs` with `bitsOf s = bs ++ bitsOf s'` and
continues to a state `s'` satisfying `Inv`, paying at most `Φ s - Φ s' - 1`. Then the loop from `s`
consumes `bitsOf s` and returns an output satisfying `Post` within time `Φ s` and peak `S`. -/
theorem of_inv {σ : Type*} {body : Expr} (hbody : prog[i]? = some body) (enc : σ → Val)
    (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (Φ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out Cb, EvalsLeT prog (base + valSize (enc s)) [enc s] (bitsOf s) body
          (Val.list [Val.int 0, out]) Cb S ∧ Post out ∧ 1 + Cb ≤ Φ s) ∨
      (∃ flag s' bs Cb, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsLeT prog (base + valSize (enc s)) [enc s] bs body
            (Val.list [Val.int flag, enc s']) Cb S ∧ Inv s' ∧ 1 + Cb + Φ s' ≤ Φ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ LoopLeT prog base i (enc s) (bitsOf s) out (Φ s) S := by
  intro s
  induction hΦ : Φ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs
    rcases hstep s hs with ⟨out, Cb, hb, hpost, hC⟩ |
        ⟨flag, s', bs, Cb, hflag, hbits, hb, hs', hC⟩
    · exact ⟨out, hpost, (stop hbody hb).mono (by omega) (le_refl _)⟩
    · obtain ⟨out, hpost, hrest⟩ := ih (Φ s') (by omega) s' rfl hs'
      rw [hbits]
      exact ⟨out, hpost, (cont hbody hb hflag hrest).mono (by omega) (by simp)⟩

/-- **Loop rule (measure, uniform per-iteration bound, with fresh bits).** If every iteration
costs at most `c`, stays within peak `S`, and continuing iterations decrease the measure `μ`, the
loop costs at most `(μ s + 1) * (c + 1)`. -/
theorem of_measure {σ : Type*} {body : Expr} (hbody : prog[i]? = some body) (enc : σ → Val)
    (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ) (c : ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsLeT prog (base + valSize (enc s)) [enc s] (bitsOf s) body
          (Val.list [Val.int 0, out]) c S ∧ Post out) ∨
      (∃ flag s' bs, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsLeT prog (base + valSize (enc s)) [enc s] bs body
            (Val.list [Val.int flag, enc s']) c S ∧ Inv s' ∧ μ s' < μ s)) :
    ∀ s, Inv s →
      ∃ out, Post out ∧ LoopLeT prog base i (enc s) (bitsOf s) out ((μ s + 1) * (c + 1)) S := by
  refine of_inv hbody enc bitsOf Inv Post (fun s => (μ s + 1) * (c + 1)) ?_
  intro s hs
  rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', bs, hflag, hbits, hb, hs', hμ⟩
  · refine Or.inl ⟨out, c, hb, hpost, ?_⟩
    nlinarith
  · refine Or.inr ⟨flag, s', bs, c, hflag, hbits, hb, hs', ?_⟩
    have : (μ s' + 1) * (c + 1) + (c + 1) ≤ (μ s + 1) * (c + 1) := by
      have : μ s' + 1 + 1 ≤ μ s + 1 := by omega
      nlinarith
    omega

/-- **Loop rule (explicit trajectory, with fresh bits).** The accumulators `acc 0, …, acc N`,
where iteration `k` consumes the bits `bs k`, with flags `flag k ≠ 0` for `k < N` and a final
result `[0, out]`: the loop consumes `bs 0 ++ ⋯ ++ bs N`, and the total cost is the sum of the
per-iteration costs plus one per iteration. -/
theorem of_seq {body : Expr} (hbody : prog[i]? = some body) (N : ℕ) (acc : ℕ → Val)
    (bs : ℕ → List Bool) (flag : ℕ → ℤ) (out : Val) (c : ℕ → ℕ)
    (hcont : ∀ k < N, flag k ≠ 0 ∧ EvalsLeT prog (base + valSize (acc k)) [acc k] (bs k) body
      (Val.list [Val.int (flag k), acc (k + 1)]) (c k) S)
    (hstop : EvalsLeT prog (base + valSize (acc N)) [acc N] (bs N) body
      (Val.list [Val.int 0, out]) (c N) S) :
    LoopLeT prog base i (acc 0) ((List.range (N + 1)).flatMap bs) out
      (∑ k ∈ Finset.range (N + 1), (c k + 1)) S := by
  induction N generalizing acc bs flag c with
  | zero =>
    simp only [zero_add, Finset.range_one, Finset.sum_singleton, List.range_one,
      List.flatMap_cons, List.flatMap_nil, List.append_nil]
    exact (stop hbody hstop).mono (by omega) (le_refl _)
  | succ N ih =>
    have h0 := hcont 0 (Nat.succ_pos N)
    have hrest := ih (fun k => acc (k + 1)) (fun k => bs (k + 1)) (fun k => flag (k + 1))
      (fun k => c (k + 1)) (fun k hk => hcont (k + 1) (by omega)) hstop
    rw [Finset.sum_range_succ']
    have hb : (List.range (N + 1 + 1)).flatMap bs =
        bs 0 ++ (List.range (N + 1)).flatMap (fun k => bs (k + 1)) := by
      rw [List.range_succ_eq_map, List.flatMap_cons, List.flatMap_map]
    rw [hb]
    exact (cont hbody h0.2 h0.1 hrest).mono (by omega) (by simp)

/-- **Loop rule (explicit trajectory, per-iteration peaks, with fresh bits).** As `of_seq`, with
the peak of iteration `k` bounded by `base + s k`; the loop's peak is at most
`base + max_k s k`. -/
theorem of_seq_sup {body : Expr} (hbody : prog[i]? = some body) (N : ℕ) (acc : ℕ → Val)
    (bs : ℕ → List Bool) (flag : ℕ → ℤ) (out : Val) (c s : ℕ → ℕ)
    (hcont : ∀ k < N, flag k ≠ 0 ∧ EvalsLeT prog (base + valSize (acc k)) [acc k] (bs k) body
      (Val.list [Val.int (flag k), acc (k + 1)]) (c k) (base + s k))
    (hstop : EvalsLeT prog (base + valSize (acc N)) [acc N] (bs N) body
      (Val.list [Val.int 0, out]) (c N) (base + s N)) :
    LoopLeT prog base i (acc 0) ((List.range (N + 1)).flatMap bs) out
      (∑ k ∈ Finset.range (N + 1), (c k + 1)) (base + (Finset.range (N + 1)).sup s) := by
  have hle : ∀ k ≤ N, s k ≤ (Finset.range (N + 1)).sup s := fun k hk =>
    Finset.le_sup (f := s) (Finset.mem_range.mpr (by omega))
  refine of_seq hbody N acc bs flag out c (fun k hk => ⟨(hcont k hk).1, ?_⟩) ?_
  · exact (hcont k hk).2.mono (le_refl _) (by have := hle k (by omega); omega)
  · exact hstop.mono (le_refl _) (by have := hle N (le_refl _); omega)

end LoopLeT

theorem EvalsLeT.loop {prog : List Expr} {base : ℕ} {env : List Val} {i : ℕ} {a : Expr}
    {ba bl : List Bool} {va w : Val} {Ca Sa Cl Sl : ℕ} (ha : EvalsLeT prog base env ba a va Ca Sa)
    (hl : LoopLeT prog base i va bl w Cl Sl) :
    EvalsLeT prog base env (ba ++ bl) (Expr.loop i a) w (1 + Ca + Cl) (max Sa Sl) := by
  obtain ⟨ca, pa, ha, hca, hpa⟩ := ha
  obtain ⟨cl, pl, hl, hcl, hpl⟩ := hl
  exact ⟨_, _, EvalsToT.loop ha hl, by omega, max_le_max hpa hpl⟩

namespace LoopLe

variable {prog : List Expr} {base i : ℕ} {v w : Val} {C S : ℕ}

theorem mono {C' S' : ℕ} (h : LoopLe prog base i v w C S) (hC : C ≤ C') (hS : S ≤ S') :
    LoopLe prog base i v w C' S' :=
  LoopLeT.mono h hC hS

theorem peak_ge (h : LoopLe prog base i v w C S) :
    base + valSize v ≤ S ∧ base + valSize w ≤ S :=
  LoopLeT.peak_ge h

theorem base_shift (h : LoopLe prog base i v w C S) (d : ℕ) :
    LoopLe prog (base + d) i v w C (S + d) :=
  LoopLeT.base_shift h d

theorem stop {body : Expr} {v' : Val} {Cb Sb : ℕ} (hbody : prog[i]? = some body)
    (hb : EvalsLe prog (base + valSize v) [v] body (Val.list [Val.int 0, v']) Cb Sb) :
    LoopLe prog base i v v' (1 + Cb) Sb :=
  LoopLeT.stop hbody hb

theorem cont {body : Expr} {flag : ℤ} {v' : Val} {Cb Sb Cw Sw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsLe prog (base + valSize v) [v] body (Val.list [Val.int flag, v']) Cb Sb)
    (hflag : flag ≠ 0) (hrest : LoopLe prog base i v' w Cw Sw) :
    LoopLe prog base i v w (1 + Cb + Cw) (max Sb Sw) :=
  LoopLeT.cont hbody hb hflag hrest

/-- **Loop rule (invariant + potential).** `Inv` is an invariant of the accumulator states
(encoded by `enc`), `Φ` a potential bounding the remaining cost: every iteration from a state
`s` satisfying `Inv` stays within peak `S` and either stops with an output satisfying `Post`
(within cost `Φ s - 1`) or continues to a state `s'` satisfying `Inv`, paying at most
`Φ s - Φ s' - 1`. Then the loop from `s` returns some output satisfying `Post` within time `Φ s`
and peak `S`. -/
theorem of_inv {σ : Type*} {body : Expr} (hbody : prog[i]? = some body) (enc : σ → Val)
    (Inv : σ → Prop) (Post : Val → Prop) (Φ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out Cb, EvalsLe prog (base + valSize (enc s)) [enc s] body
          (Val.list [Val.int 0, out]) Cb S ∧ Post out ∧ 1 + Cb ≤ Φ s) ∨
      (∃ flag s' Cb, flag ≠ 0 ∧ EvalsLe prog (base + valSize (enc s)) [enc s] body
          (Val.list [Val.int flag, enc s']) Cb S ∧ Inv s' ∧ 1 + Cb + Φ s' ≤ Φ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ LoopLe prog base i (enc s) out (Φ s) S :=
  LoopLeT.of_inv hbody enc (fun _ => []) Inv Post Φ (fun s hs => by
    rcases hstep s hs with ⟨out, Cb, hb, hpost, hC⟩ | ⟨flag, s', Cb, hflag, hb, hs', hC⟩
    · exact Or.inl ⟨out, Cb, hb, hpost, hC⟩
    · exact Or.inr ⟨flag, s', [], Cb, hflag, rfl, hb, hs', hC⟩)

/-- **Loop rule (measure, uniform per-iteration bound).** If every iteration costs at most `c`,
stays within peak `S`, and continuing iterations decrease the measure `μ`, the loop costs at
most `(μ s + 1) * (c + 1)`. -/
theorem of_measure {σ : Type*} {body : Expr} (hbody : prog[i]? = some body) (enc : σ → Val)
    (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ) (c : ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsLe prog (base + valSize (enc s)) [enc s] body
          (Val.list [Val.int 0, out]) c S ∧ Post out) ∨
      (∃ flag s', flag ≠ 0 ∧ EvalsLe prog (base + valSize (enc s)) [enc s] body
          (Val.list [Val.int flag, enc s']) c S ∧ Inv s' ∧ μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ LoopLe prog base i (enc s) out ((μ s + 1) * (c + 1)) S :=
  LoopLeT.of_measure hbody enc (fun _ => []) Inv Post μ c (fun s hs => by
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', hflag, hb, hs', hμ⟩
    · exact Or.inl ⟨out, hb, hpost⟩
    · exact Or.inr ⟨flag, s', [], hflag, rfl, hb, hs', hμ⟩)

/-- **Loop rule (explicit trajectory).** The accumulators `acc 0, …, acc N` with flags
`flag k ≠ 0` for `k < N` and a final result `[0, out]`: the total cost is the sum of the
per-iteration costs plus one per iteration. -/
theorem of_seq {body : Expr} (hbody : prog[i]? = some body) (N : ℕ) (acc : ℕ → Val)
    (flag : ℕ → ℤ) (out : Val) (c : ℕ → ℕ)
    (hcont : ∀ k < N, flag k ≠ 0 ∧ EvalsLe prog (base + valSize (acc k)) [acc k] body
      (Val.list [Val.int (flag k), acc (k + 1)]) (c k) S)
    (hstop : EvalsLe prog (base + valSize (acc N)) [acc N] body (Val.list [Val.int 0, out])
      (c N) S) :
    LoopLe prog base i (acc 0) out (∑ k ∈ Finset.range (N + 1), (c k + 1)) S := by
  have h := LoopLeT.of_seq hbody N acc (fun _ => []) flag out c hcont hstop
  refine LoopLeT.cast_bits h ?_
  simp

/-- **Loop rule (explicit trajectory, per-iteration peaks).** As `of_seq`, with the peak of
iteration `k` bounded by `base + s k`; the loop's peak is at most `base + max_k s k`. -/
theorem of_seq_sup {body : Expr} (hbody : prog[i]? = some body) (N : ℕ) (acc : ℕ → Val)
    (flag : ℕ → ℤ) (out : Val) (c s : ℕ → ℕ)
    (hcont : ∀ k < N, flag k ≠ 0 ∧ EvalsLe prog (base + valSize (acc k)) [acc k] body
      (Val.list [Val.int (flag k), acc (k + 1)]) (c k) (base + s k))
    (hstop : EvalsLe prog (base + valSize (acc N)) [acc N] body (Val.list [Val.int 0, out])
      (c N) (base + s N)) :
    LoopLe prog base i (acc 0) out (∑ k ∈ Finset.range (N + 1), (c k + 1))
      (base + (Finset.range (N + 1)).sup s) := by
  have h := LoopLeT.of_seq_sup hbody N acc (fun _ => []) flag out c s hcont hstop
  refine LoopLeT.cast_bits h ?_
  simp

end LoopLe

theorem EvalsLe.loop {prog : List Expr} {base : ℕ} {env : List Val} {i : ℕ} {a : Expr}
    {va w : Val} {Ca Sa Cl Sl : ℕ} (ha : EvalsLe prog base env a va Ca Sa)
    (hl : LoopLe prog base i va w Cl Sl) :
    EvalsLe prog base env (Expr.loop i a) w (1 + Ca + Cl) (max Sa Sl) :=
  EvalsLeT.loop ha hl

/-! ### Connection with the Spec's entry point `RunsOn` -/

/-- A bounded evaluation of the entry body consuming the fresh bits `bits` gives `RunsOn` on every
tape extending `bits`. -/
theorem RunsOn_of_EvalsLeT {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input out : Val} {bits : List Bool} {C S : ℕ}
    (h : EvalsLeT prog (valSize input) [input] bits body out C S) {Sp : ℝ} (hS : (S : ℝ) ≤ Sp)
    (rest : List Bool) : RunsOn prog input (bits ++ rest) out Sp := by
  obtain ⟨fuel, c, p, -, hp, hf⟩ := h.eval_append
  exact ⟨body, fuel, c, p, rest, h0, hf rest, le_trans (by exact_mod_cast hp) hS⟩

/-- A deterministic bounded evaluation of the entry body gives `RunsOn` on every tape. -/
theorem RunsOn_of_EvalsLe {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input out : Val} {C S : ℕ} (h : EvalsLe prog (valSize input) [input] body out C S)
    {Sp : ℝ} (hS : (S : ℝ) ≤ Sp) (tape : List Bool) : RunsOn prog input tape out Sp :=
  RunsOn_of_EvalsLeT h0 h hS tape

/-- Conversely, `RunsOn` comes from an exact evaluation consuming a prefix of the tape. -/
theorem EvalsToT_of_RunsOn {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input out : Val} {tape : List Bool} {Sp : ℝ} (h : RunsOn prog input tape out Sp) :
    ∃ bits rest c p, tape = bits ++ rest ∧
      EvalsToT prog (valSize input) [input] bits body out c p ∧ (p : ℝ) ≤ Sp := by
  obtain ⟨body', fuel, c, p, rest, h0', h, hp⟩ := h
  rw [h0] at h0'
  cases Option.some.inj h0'
  obtain ⟨bits, htape, hb⟩ := EvalsToT.of_eval_tape h
  exact ⟨bits, rest, c, p, htape, hb, hp⟩

/-! ### Symbolic evaluation

`simp only [eval]` unfolds `eval` with *all* constructor branches when the fuel is a numeral
(exponential blow-up). Use instead the lemmas `eval_succ_*` below (one constructor each, written
with `Option.bind`), e.g. for a loop- and call-free deterministic body:
```
apply EvalsLe.of_eval 20
simp [body, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
  eval_succ_ite, eval_succ_letE, evalBin, evalUn]
```
For code reading fresh bits use `EvalsLeT.of_eval` on the explicit bit list and `eval_succ_coin`
(with `List.head?_cons`, `List.tail_cons`).
-/

section Symb
variable (prog : List Expr) (n base : ℕ) (env : List Val) (tape : List Bool)

theorem eval_succ_var (i : ℕ) : eval prog (n+1) base env tape (Expr.var i) =
    (env[i]?).map (fun v => (v, 1, base + valSize v, tape)) := by
  simp only [eval]; cases env[i]? <;> rfl

theorem eval_succ_lit (z : ℤ) : eval prog (n+1) base env tape (Expr.lit z) =
    some (Val.int z, 1 + bitLen z, base + valSize (Val.int z), tape) :=
  eval_lit_eq prog n base env tape z

theorem eval_succ_nil : eval prog (n+1) base env tape Expr.nil =
    some (Val.list [], 1, base + valSize (Val.list []), tape) :=
  eval_nil_eq prog n base env tape

theorem eval_succ_coin : eval prog (n+1) base env tape Expr.coin =
    tape.head?.map (fun b => (encB b, 1, base + valSize (encB b), tape.tail)) := by
  cases tape with
  | nil => exact eval_coin_nil prog n base env
  | cons b rest => exact eval_coin_cons prog n base env b rest

theorem eval_succ_bin (op : BinOp) (a b : Expr) : eval prog (n+1) base env tape (Expr.bin op a b) =
    (eval prog n base env tape a).bind (fun ra =>
      (eval prog n (base + valSize ra.1) env ra.2.2.2 b).bind (fun rb =>
        (evalBin op ra.1 rb.1).map (fun r => (r.1, 1 + ra.2.1 + rb.2.1 + r.2,
          max (max ra.2.2.1 rb.2.2.1) (base + valSize ra.1 + valSize rb.1 + valSize r.1),
          rb.2.2.2)))) := by
  simp only [eval]
  rcases eval prog n base env tape a with _ | ⟨va, ca, pa, ta⟩
  · rfl
  · simp only [Option.bind_some]
    rcases eval prog n (base + valSize va) env ta b with _ | ⟨vb, cb, pb, tb⟩
    · rfl
    · simp only [Option.bind_some]
      rcases evalBin op va vb with _ | ⟨v, c⟩ <;> rfl

theorem eval_succ_un (op : UnOp) (a : Expr) : eval prog (n+1) base env tape (Expr.un op a) =
    (eval prog n base env tape a).bind (fun ra =>
      (evalUn op ra.1).map (fun r => (r.1, 1 + ra.2.1 + r.2,
        max ra.2.2.1 (base + valSize ra.1 + valSize r.1), ra.2.2.2))) := by
  simp only [eval]
  rcases eval prog n base env tape a with _ | ⟨va, ca, pa, ta⟩
  · rfl
  · simp only [Option.bind_some]
    rcases evalUn op va with _ | ⟨v, c⟩ <;> rfl

theorem eval_succ_ite (c t f : Expr) : eval prog (n+1) base env tape (Expr.ite c t f) =
    (eval prog n base env tape c).bind (fun rc =>
      match rc.1 with
      | Val.int z => (eval prog n base env rc.2.2.2 (if z ≠ 0 then t else f)).map (fun rv =>
          (rv.1, 1 + rc.2.1 + rv.2.1, max rc.2.2.1 rv.2.2.1, rv.2.2.2))
      | Val.list _ => none) := by
  simp only [eval]
  rcases eval prog n base env tape c with _ | ⟨_ | l, cc, pc, tc⟩
  · rfl
  · simp only [Option.bind_some]
    rename_i z
    rcases eval prog n base env tc (if z ≠ 0 then t else f) with _ | ⟨v, cv, pv, tv⟩ <;> rfl
  · rfl

theorem eval_succ_letE (a b : Expr) : eval prog (n+1) base env tape (Expr.letE a b) =
    (eval prog n base env tape a).bind (fun ra =>
      (eval prog n (base + valSize ra.1) (ra.1 :: env) ra.2.2.2 b).map (fun rb =>
        (rb.1, 1 + ra.2.1 + rb.2.1, max ra.2.2.1 rb.2.2.1, rb.2.2.2))) := by
  simp only [eval]
  rcases eval prog n base env tape a with _ | ⟨va, ca, pa, ta⟩
  · rfl
  · simp only [Option.bind_some]
    rcases eval prog n (base + valSize va) (va :: env) ta b with _ | ⟨vb, cb, pb, tb⟩ <;> rfl

theorem eval_succ_call (i : ℕ) (a : Expr) : eval prog (n+1) base env tape (Expr.call i a) =
    (eval prog n base env tape a).bind (fun ra =>
      (prog[i]?).bind (fun body =>
        (eval prog n (base + valSize ra.1) [ra.1] ra.2.2.2 body).map (fun rb =>
          (rb.1, 1 + ra.2.1 + rb.2.1, max ra.2.2.1 rb.2.2.1, rb.2.2.2)))) := by
  simp only [eval]
  rcases eval prog n base env tape a with _ | ⟨va, ca, pa, ta⟩
  · rfl
  · simp only [Option.bind_some]
    rcases prog[i]? with _ | body
    · rfl
    · simp only [Option.bind_some]
      rcases eval prog n (base + valSize va) [va] ta body with _ | ⟨vb, cb, pb, tb⟩ <;> rfl

theorem eval_succ_loop (i : ℕ) (a : Expr) : eval prog (n+1) base env tape (Expr.loop i a) =
    (eval prog n base env tape a).bind (fun ra =>
      (loopRun prog n base i ra.1 ra.2.2.2).map (fun rw =>
        (rw.1, 1 + ra.2.1 + rw.2.1, max ra.2.2.1 rw.2.2.1, rw.2.2.2))) := by
  simp only [eval]
  rcases eval prog n base env tape a with _ | ⟨va, ca, pa, ta⟩
  · rfl
  · simp only [Option.bind_some]
    rcases loopRun prog n base i va ta with _ | ⟨w, cw, pw, tw⟩ <;> rfl

end Symb

end F2e2e.Cost
