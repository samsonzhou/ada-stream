import F2e2e.Cost.Space
import F2e2e.Cost.Lib.Util

/-!
# The value judgment `EvalsVal` and the generic space theorem (package L)

Design: `notes/C_IMPL_DESIGN.md` §1 (C-TOP 95aff426 with DSL-CALC 795856c2).

## The value judgment
`EvalsVal prog M env bits t v` (an inductive big-step judgment, no fuel, cost or peak): the target
`t` — an expression `e` (`.inl e`, evaluated in the environment `env`) or the iterations of
`loop i` from the accumulator `acc` (`.inr (i, acc)`, environment `[]`) — evaluates to `v`,
consuming **exactly** the fresh bits `bits` (concatenated left to right, as in `EvalsToT`), and
every value produced by a literal, `nil`, `coin` or a primitive operation has size `≤ M`. All other
produced values (variable reads, results of `ite`/`letE`/`call`/`loop`, loop accumulators, loop
body results) are then automatically `≤ M` when the environment is (`GProp`).

## The generic space theorem (GST)
A *rank certificate* `RankOK prog r K`: every body of `prog` has depth `≤ K` and calls/loops only
functions of strictly smaller rank `r` (decidable: `RankOK.of_rankOKB` with the Boolean checker
`rankOKB`, to be discharged by `decide`/`rfl` on the assembled program). Then
(`EvalsVal.toSpT`): an `EvalsVal` evaluation of `e` whose environment values are `≤ M` and whose
callees have rank `< ρ` runs within peak `base + (exprDepth e + 2 + ρ (K + 3)) M`; at the entry
point (`EvalsVal.eval_entry`, `EvalsVal.runsOn`): peak `≤ ((r 0 + 1)(K + 3) + 1) M` when the input
has size `≤ M`.

Proof (`gst_aux`): induction on the derivation. The live data beyond the base at any time are the
pending intermediate results of the current body (at most its depth), the current produced value
(one slot) and, for a `call`/`loop`, the argument/accumulator plus the callee's own slots; along an
acyclic chain of calls the ranks decrease, so a body of rank `ρ'` uses at most
`(ρ' + 1)(K + 3)` slots of size `≤ M` (`stop`/`cont`: `valSize v + (K + 2 + r i (K + 3)) M ≤
(r i + 1)(K + 3) M`).

## Bridges
* `EvalsVal.sound`: every `EvalsVal` evaluation is a semantic one (`EvalsToT`, any base), so values
  are unique (`EvalsVal.val_unique`).
* Reverse bridge (`toVal_aux`): a semantic run with peak `p` at base `base` is an `EvalsVal`
  evaluation with `M = p - base` (every value produced at a sub-base `≥ base` is live together
  with it). Hence `EvalsLe.toVal`, `EvalsLeT.toVal`, `EvalsSpT.toVal`, `LoopLeT.toVal`, …: a spec
  with peak `≤ base + S` gives `EvalsVal` with `M = S`, so all cut2-style library specs plug in.
* `EvalsVal.loop_of_measure`: the uniform value-bound loop rule (decreasing measure, consumed bits
  given by a function of the loop state).
-/

namespace F2e2e.Cost

/-! ## Syntactic measures and the rank certificate -/

/-- Depth of an expression (leaves have depth `1`). -/
def exprDepth : Expr → ℕ
  | Expr.var _ => 1
  | Expr.lit _ => 1
  | Expr.nil => 1
  | Expr.coin => 1
  | Expr.bin _ a b => 1 + max (exprDepth a) (exprDepth b)
  | Expr.un _ a => 1 + exprDepth a
  | Expr.ite c t f => 1 + max (exprDepth c) (max (exprDepth t) (exprDepth f))
  | Expr.letE a b => 1 + max (exprDepth a) (exprDepth b)
  | Expr.call _ a => 1 + exprDepth a
  | Expr.loop _ a => 1 + exprDepth a

theorem one_le_exprDepth (e : Expr) : 1 ≤ exprDepth e := by
  cases e <;> simp only [exprDepth] <;> omega

/-- Every function called or looped by `e` has rank `< ρ`. -/
def CalleesLt (r : ℕ → ℕ) (ρ : ℕ) : Expr → Prop
  | Expr.var _ => True
  | Expr.lit _ => True
  | Expr.nil => True
  | Expr.coin => True
  | Expr.bin _ a b => CalleesLt r ρ a ∧ CalleesLt r ρ b
  | Expr.un _ a => CalleesLt r ρ a
  | Expr.ite c t f => CalleesLt r ρ c ∧ CalleesLt r ρ t ∧ CalleesLt r ρ f
  | Expr.letE a b => CalleesLt r ρ a ∧ CalleesLt r ρ b
  | Expr.call j a => r j < ρ ∧ CalleesLt r ρ a
  | Expr.loop j a => r j < ρ ∧ CalleesLt r ρ a

/-- Boolean version of `CalleesLt`. -/
def calleesLtB (r : ℕ → ℕ) (ρ : ℕ) : Expr → Bool
  | Expr.var _ => true
  | Expr.lit _ => true
  | Expr.nil => true
  | Expr.coin => true
  | Expr.bin _ a b => calleesLtB r ρ a && calleesLtB r ρ b
  | Expr.un _ a => calleesLtB r ρ a
  | Expr.ite c t f => calleesLtB r ρ c && (calleesLtB r ρ t && calleesLtB r ρ f)
  | Expr.letE a b => calleesLtB r ρ a && calleesLtB r ρ b
  | Expr.call j a => decide (r j < ρ) && calleesLtB r ρ a
  | Expr.loop j a => decide (r j < ρ) && calleesLtB r ρ a

theorem calleesLtB_iff (r : ℕ → ℕ) (ρ : ℕ) (e : Expr) :
    calleesLtB r ρ e = true ↔ CalleesLt r ρ e := by
  induction e with
  | var => simp [calleesLtB, CalleesLt]
  | lit => simp [calleesLtB, CalleesLt]
  | nil => simp [calleesLtB, CalleesLt]
  | coin => simp [calleesLtB, CalleesLt]
  | bin op a b iha ihb => simp [calleesLtB, CalleesLt, iha, ihb]
  | un op a iha => simp [calleesLtB, CalleesLt, iha]
  | ite c t f ihc iht ihf => simp [calleesLtB, CalleesLt, ihc, iht, ihf]
  | letE a b iha ihb => simp [calleesLtB, CalleesLt, iha, ihb]
  | call j a iha => simp [calleesLtB, CalleesLt, iha]
  | loop j a iha => simp [calleesLtB, CalleesLt, iha]

/-- **Rank certificate.** Every body of `prog` has depth `≤ K` and calls/loops only functions of
strictly smaller rank. -/
def RankOK (prog : List Expr) (r : ℕ → ℕ) (K : ℕ) : Prop :=
  ∀ j body, prog[j]? = some body → exprDepth body ≤ K ∧ CalleesLt r (r j) body

/-- Boolean checker of the rank certificate for the bodies `l` starting at index `j₀`. -/
def rankOKFrom (r : ℕ → ℕ) (K : ℕ) : ℕ → List Expr → Bool
  | _, [] => true
  | j, b :: bs => (decide (exprDepth b ≤ K) && calleesLtB r (r j) b) && rankOKFrom r K (j + 1) bs

/-- Boolean checker of the rank certificate (prove `rankOKB prog r K = true` by `decide`/`rfl`). -/
def rankOKB (prog : List Expr) (r : ℕ → ℕ) (K : ℕ) : Bool := rankOKFrom r K 0 prog

theorem rankOKFrom_sound {r : ℕ → ℕ} {K : ℕ} :
    ∀ (j₀ : ℕ) (l : List Expr), rankOKFrom r K j₀ l = true →
      ∀ j body, l[j]? = some body → exprDepth body ≤ K ∧ CalleesLt r (r (j₀ + j)) body
  | _, [], _, j, body, h => by simp at h
  | j₀, b :: bs, hl, j, body, h => by
    simp only [rankOKFrom, Bool.and_eq_true, decide_eq_true_eq] at hl
    obtain ⟨⟨hd, hc⟩, hrest⟩ := hl
    cases j with
    | zero =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at h
      subst h
      exact ⟨hd, by simpa using (calleesLtB_iff r (r j₀) b).mp hc⟩
    | succ j =>
      simp only [List.getElem?_cons_succ] at h
      have := rankOKFrom_sound (j₀ + 1) bs hrest j body h
      rwa [show j₀ + 1 + j = j₀ + (j + 1) by omega] at this

theorem RankOK.of_rankOKB {prog : List Expr} {r : ℕ → ℕ} {K : ℕ} (h : rankOKB prog r K = true) :
    RankOK prog r K := by
  intro j body hj
  have := rankOKFrom_sound 0 prog h j body hj
  simpa using this

/-! ## The value judgment -/

/-- **The value judgment** (see the module docstring). Targets: `.inl e` (an expression, in the
environment `env`) or `.inr (i, acc)` (the iterations of `loop i` from the accumulator `acc`,
environment `[]`). -/
inductive EvalsVal (prog : List Expr) (M : ℕ) :
    List Val → List Bool → Expr ⊕ (ℕ × Val) → Val → Prop
  | var {env : List Val} {i : ℕ} {v : Val} (h : env[i]? = some v) :
      EvalsVal prog M env [] (.inl (Expr.var i)) v
  | lit {env : List Val} {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
      EvalsVal prog M env [] (.inl (Expr.lit z)) (Val.int z)
  | nil {env : List Val} (hM : valSize (Val.list []) ≤ M) :
      EvalsVal prog M env [] (.inl Expr.nil) (Val.list [])
  | coin {env : List Val} (b : Bool) (hM : valSize (encB b) ≤ M) :
      EvalsVal prog M env [b] (.inl Expr.coin) (encB b)
  | bin {env : List Val} {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {c : ℕ}
      (ha : EvalsVal prog M env ba (.inl a) va) (hb : EvalsVal prog M env bb (.inl b) vb)
      (hop : evalBin op va vb = some (v, c)) (hM : valSize v ≤ M) :
      EvalsVal prog M env (ba ++ bb) (.inl (Expr.bin op a b)) v
  | un {env : List Val} {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {c : ℕ}
      (ha : EvalsVal prog M env ba (.inl a) va) (hop : evalUn op va = some (v, c))
      (hM : valSize v ≤ M) :
      EvalsVal prog M env ba (.inl (Expr.un op a)) v
  | ite {env : List Val} {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
      (hc : EvalsVal prog M env bc (.inl c) (Val.int z))
      (hv : EvalsVal prog M env bv (.inl (if z ≠ 0 then t else f)) v) :
      EvalsVal prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v
  | letE {env : List Val} {a b : Expr} {ba bb : List Bool} {va vb : Val}
      (ha : EvalsVal prog M env ba (.inl a) va)
      (hb : EvalsVal prog M (va :: env) bb (.inl b) vb) :
      EvalsVal prog M env (ba ++ bb) (.inl (Expr.letE a b)) vb
  | call {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
      (ha : EvalsVal prog M env ba (.inl a) va) (hbody : prog[i]? = some body)
      (hb : EvalsVal prog M [va] bb (.inl body) vb) :
      EvalsVal prog M env (ba ++ bb) (.inl (Expr.call i a)) vb
  | loop {env : List Val} {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val}
      (ha : EvalsVal prog M env ba (.inl a) va) (hl : EvalsVal prog M [] bl (.inr (i, va)) w) :
      EvalsVal prog M env (ba ++ bl) (.inl (Expr.loop i a)) w
  | stop {i : ℕ} {v : Val} {body : Expr} {bb : List Bool} {v' : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsVal prog M [v] bb (.inl body) (Val.list [Val.int 0, v'])) :
      EvalsVal prog M [] bb (.inr (i, v)) v'
  | cont {i : ℕ} {v : Val} {body : Expr} {bb bw : List Bool} {flag : ℤ} {v' w : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsVal prog M [v] bb (.inl body) (Val.list [Val.int flag, v']))
      (hflag : flag ≠ 0) (hrest : EvalsVal prog M [] bw (.inr (i, v')) w) :
      EvalsVal prog M [] (bb ++ bw) (.inr (i, v)) w

namespace EvalsVal

variable {prog : List Expr} {M : ℕ}

/-- Monotonicity in the value bound. -/
theorem mono_M {M' : ℕ} {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsVal prog M env bits t v) (hM : M ≤ M') : EvalsVal prog M' env bits t v := by
  induction h with
  | var hv => exact EvalsVal.var hv
  | lit h => exact EvalsVal.lit (h.trans hM)
  | nil h => exact EvalsVal.nil (h.trans hM)
  | coin b h => exact EvalsVal.coin b (h.trans hM)
  | bin _ _ hop h iha ihb => exact EvalsVal.bin iha ihb hop (h.trans hM)
  | un _ hop h iha => exact EvalsVal.un iha hop (h.trans hM)
  | ite _ _ ihc ihv => exact EvalsVal.ite ihc ihv
  | letE _ _ iha ihb => exact EvalsVal.letE iha ihb
  | call _ hbody _ iha ihb => exact EvalsVal.call iha hbody ihb
  | loop _ _ iha ihl => exact EvalsVal.loop iha ihl
  | stop hbody _ ihb => exact EvalsVal.stop hbody ihb
  | cont hbody _ hflag _ ihb ihr => exact EvalsVal.cont hbody ihb hflag ihr

theorem cast_bits {env : List Val} {bits bits' : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsVal prog M env bits t v) (hb : bits = bits') : EvalsVal prog M env bits' t v :=
  hb ▸ h

/-- `ePair a b` builds `[x, y]`. -/
theorem pair {env : List Val} {a b : Expr} {ba bb : List Bool} {x y : Val}
    (ha : EvalsVal prog M env ba (.inl a) x) (hb : EvalsVal prog M env bb (.inl b) y)
    (hM : valSize (Val.list [x, y]) ≤ M) :
    EvalsVal prog M env (ba ++ bb) (.inl (ePair a b)) (Val.list [x, y]) := by
  have h1 : valSize (Val.list [y]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h0 : valSize (Val.list []) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hin := EvalsVal.bin (op := BinOp.cons) (c := 1) hb (EvalsVal.nil h0)
    (by cases y <;> rfl) h1
  rw [List.append_nil] at hin
  exact EvalsVal.bin (c := 1) ha hin (by cases x <;> rfl) hM

/-- **Loop rule (measure, with fresh bits).** Every iteration from a state `s` satisfying `Inv`
either stops with an output satisfying `Post`, consuming `bitsOf s`, or consumes a prefix `bs`
with `bitsOf s = bs ++ bitsOf s'` and continues to a state `s'` satisfying `Inv` with a smaller
measure. -/
theorem loop_of_measure {σ : Type*} {i : ℕ} {body : Expr} (hbody : prog[i]? = some body)
    (enc : σ → Val) (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsVal prog M [enc s] (bitsOf s) (.inl body) (Val.list [Val.int 0, out]) ∧
          Post out) ∨
      (∃ flag s' bs, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsVal prog M [enc s] bs (.inl body) (Val.list [Val.int flag, enc s']) ∧ Inv s' ∧
          μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ EvalsVal prog M [] (bitsOf s) (.inr (i, enc s)) out := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', bs, hflag, hbits, hb, hs', hlt⟩
    · exact ⟨out, hpost, EvalsVal.stop hbody hb⟩
    · obtain ⟨out, hpost, hrest⟩ := ih (μ s') (by omega) s' rfl hs'
      rw [hbits]
      exact ⟨out, hpost, EvalsVal.cont hbody hb hflag hrest⟩

end EvalsVal

/-! ## Soundness: `EvalsVal` evaluations are semantic evaluations -/

/-- The statement proved by induction for soundness. -/
def SoundProp (prog : List Expr) (env : List Val) (bits : List Bool) :
    Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => ∀ base, ∃ c p, EvalsToT prog base env bits e v c p
  | .inr (i, acc), w => ∀ base, ∃ c p, LoopToT prog base i acc bits w c p

theorem EvalsVal.sound_aux {prog : List Expr} {M : ℕ} {env : List Val} {bits : List Bool}
    {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsVal prog M env bits t v) :
    SoundProp prog env bits t v := by
  induction h with
  | var hv => exact fun base => ⟨_, _, EvalsToT.var hv⟩
  | lit _ => exact fun base => ⟨_, _, EvalsToT.lit _⟩
  | nil _ => exact fun base => ⟨_, _, EvalsToT.nil⟩
  | coin b _ => exact fun base => ⟨_, _, EvalsToT.coin b⟩
  | @bin env op a b ba bb va vb v c ha hb hop hM iha ihb =>
    intro base
    obtain ⟨_, _, h1⟩ := iha base
    obtain ⟨_, _, h2⟩ := ihb (base + valSize va)
    exact ⟨_, _, EvalsToT.bin h1 h2 hop⟩
  | un ha hop hM iha =>
    intro base
    obtain ⟨_, _, h1⟩ := iha base
    exact ⟨_, _, EvalsToT.un h1 hop⟩
  | ite hc hv ihc ihv =>
    intro base
    obtain ⟨_, _, h1⟩ := ihc base
    obtain ⟨_, _, h2⟩ := ihv base
    exact ⟨_, _, EvalsToT.ite h1 h2⟩
  | @letE env a b ba bb va vb ha hb iha ihb =>
    intro base
    obtain ⟨_, _, h1⟩ := iha base
    obtain ⟨_, _, h2⟩ := ihb (base + valSize va)
    exact ⟨_, _, EvalsToT.letE h1 h2⟩
  | @call env i a body ba bb va vb ha hbody hb iha ihb =>
    intro base
    obtain ⟨_, _, h1⟩ := iha base
    obtain ⟨_, _, h2⟩ := ihb (base + valSize va)
    exact ⟨_, _, EvalsToT.call h1 hbody h2⟩
  | loop ha hl iha ihl =>
    intro base
    obtain ⟨_, _, h1⟩ := iha base
    obtain ⟨_, _, h2⟩ := ihl base
    exact ⟨_, _, EvalsToT.loop h1 h2⟩
  | @stop i v body bb v' hbody hb ihb =>
    intro base
    obtain ⟨_, _, h1⟩ := ihb (base + valSize v)
    exact ⟨_, _, LoopToT.stop hbody h1⟩
  | @cont i v body bb bw flag v' w hbody hb hflag hrest ihb ihr =>
    intro base
    obtain ⟨_, _, h1⟩ := ihb (base + valSize v)
    obtain ⟨_, _, h2⟩ := ihr base
    exact ⟨_, _, LoopToT.cont hbody h1 hflag h2⟩

/-- **Soundness.** An `EvalsVal` evaluation is a semantic evaluation (at every base). -/
theorem EvalsVal.sound {prog : List Expr} {M : ℕ} {env : List Val} {bits : List Bool} {e : Expr}
    {v : Val} (h : EvalsVal prog M env bits (.inl e) v) (base : ℕ) :
    ∃ c p, EvalsToT prog base env bits e v c p :=
  EvalsVal.sound_aux h base

/-- Values of `EvalsVal` evaluations are unique. -/
theorem EvalsVal.val_unique {prog : List Expr} {M M' : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v v' : Val} (h : EvalsVal prog M env bits (.inl e) v)
    (h' : EvalsVal prog M' env bits (.inl e) v') : v = v' := by
  obtain ⟨c, p, h1⟩ := h.sound 0
  obtain ⟨c', p', h2⟩ := h'.sound 0
  exact (h1.det h2).1

/-! ## The generic space theorem -/

namespace GST

theorem le_mul {x M n : ℕ} (hx : x ≤ M) (hn : 1 ≤ n) : x ≤ n * M :=
  hx.trans (by simpa using Nat.mul_le_mul_right M hn)

theorem add_le_mul {x M n n' : ℕ} (hx : x ≤ M) (h : n + 1 ≤ n') : x + n * M ≤ n' * M :=
  calc x + n * M ≤ M + n * M := Nat.add_le_add_right hx _
    _ = (n + 1) * M := by ring
    _ ≤ n' * M := Nat.mul_le_mul_right M h

theorem two_le_mul {x y M n : ℕ} (hx : x ≤ M) (hy : y ≤ M) (hn : 2 ≤ n) : x + y ≤ n * M :=
  calc x + y ≤ 2 * M := by omega
    _ ≤ n * M := Nat.mul_le_mul_right M hn

theorem three_le_mul {x y z M n : ℕ} (hx : x ≤ M) (hy : y ≤ M) (hz : z ≤ M) (hn : 3 ≤ n) :
    x + y + z ≤ n * M :=
  calc x + y + z ≤ 3 * M := by omega
    _ ≤ n * M := Nat.mul_le_mul_right M hn

end GST

/-- The statement proved by induction on `EvalsVal` (GST): produced values are `≤ M`, and the
evaluation runs within the generic peak bound. -/
def GProp (prog : List Expr) (r : ℕ → ℕ) (K M : ℕ) (env : List Val) (bits : List Bool) :
    Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ w ∈ env, valSize w ≤ M) → valSize v ≤ M ∧
      ∀ base ρ, CalleesLt r ρ e →
        EvalsSpT prog base env bits e v (base + (exprDepth e + 2 + ρ * (K + 3)) * M)
  | .inr (i, acc), w => valSize acc ≤ M → valSize w ≤ M ∧
      ∀ base, LoopSpT prog base i acc bits w (base + (r i + 1) * (K + 3) * M)

open GST in
theorem gst_aux {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ} (hR : RankOK prog r K)
    {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsVal prog M env bits t v) : GProp prog r K M env bits t v := by
  induction h with
  | @var env i v hv =>
    simp only [GProp]
    intro henv
    have hv' : valSize v ≤ M := henv v (List.mem_of_getElem? hv)
    refine ⟨hv', fun base ρ _ => (EvalsSpT.var hv).mono ?_⟩
    have := le_mul hv' (n := exprDepth (Expr.var i) + 2 + ρ * (K + 3)) (by omega)
    omega
  | @lit env z hM =>
    simp only [GProp]
    intro _
    refine ⟨hM, fun base ρ _ => (EvalsSpT.lit z).mono ?_⟩
    have := le_mul hM (n := exprDepth (Expr.lit z) + 2 + ρ * (K + 3)) (by omega)
    omega
  | @nil env hM =>
    simp only [GProp]
    intro _
    refine ⟨hM, fun base ρ _ => EvalsSpT.nil.mono ?_⟩
    have := le_mul hM (n := exprDepth Expr.nil + 2 + ρ * (K + 3)) (by omega)
    omega
  | @coin env b hM =>
    simp only [GProp]
    intro _
    refine ⟨hM, fun base ρ _ => (EvalsSpT.coin b).mono ?_⟩
    have := le_mul hM (n := exprDepth Expr.coin + 2 + ρ * (K + 3)) (by omega)
    omega
  | @bin env op a b ba bb va vb v c ha hb hop hM iha ihb =>
    simp only [GProp] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb henv
    refine ⟨hM, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.1
    have h2 := hb' (base + valSize va) ρ hc.2
    refine (EvalsSpT.bin h1 h2 hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth b + 2 + ρ * (K + 3))
      (n' := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3)) hva (by omega)
    have e3 := three_le_mul (n := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3))
      hva hvb hM (by omega)
    exact max_le (max_le (by omega) (by omega)) (by omega)
  | @un env op a ba va v c ha hop hM iha =>
    simp only [GProp] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc
    refine (EvalsSpT.un h1 hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := two_le_mul (n := 1 + exprDepth a + 2 + ρ * (K + 3)) hva hM (by omega)
    exact max_le (by omega) (by omega)
  | @ite env c t f bc bv z v hc hv ihc ihv =>
    simp only [GProp] at ihc ihv ⊢
    intro henv
    obtain ⟨-, hc'⟩ := ihc henv
    obtain ⟨hvv, hv'⟩ := ihv henv
    refine ⟨hvv, fun base ρ hcl => ?_⟩
    simp only [CalleesLt] at hcl
    obtain ⟨hcc, hct, hcf⟩ := hcl
    have hbr : exprDepth (if z ≠ 0 then t else f) ≤ max (exprDepth t) (exprDepth f) ∧
        CalleesLt r ρ (if z ≠ 0 then t else f) := by
      split_ifs
      · exact ⟨le_max_left _ _, hct⟩
      · exact ⟨le_max_right _ _, hcf⟩
    have h1 := hc' base ρ hcc
    have h2 := hv' base ρ hbr.2
    refine (EvalsSpT.ite h1 h2).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth c + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 + ρ * (K + 3) by omega)
    have e2 := Nat.mul_le_mul_right M (show exprDepth (if z ≠ 0 then t else f) + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 + ρ * (K + 3) by omega)
    exact max_le (by omega) (by omega)
  | @letE env a b ba bb va vb ha hb iha ihb =>
    simp only [GProp] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    have henv' : ∀ w ∈ va :: env, valSize w ≤ M := by
      intro w hw
      rcases List.mem_cons.mp hw with rfl | hw
      · exact hva
      · exact henv w hw
    obtain ⟨hvb, hb'⟩ := ihb henv'
    refine ⟨hvb, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.1
    have h2 := hb' (base + valSize va) ρ hc.2
    refine (EvalsSpT.letE h1 h2).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth b + 2 + ρ * (K + 3))
      (n' := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3)) hva (by omega)
    exact max_le (by omega) (by omega)
  | @call env i a body ba bb va vb ha hbody hb iha ihb =>
    simp only [GProp] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb (by simpa using hva)
    refine ⟨hvb, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    obtain ⟨hdep, hcb⟩ := hR i body hbody
    have h1 := ha' base ρ hc.2
    have h2 := hb' (base + valSize va) (r i) hcb
    refine (EvalsSpT.call h1 hbody h2).mono ?_
    simp only [exprDepth]
    have hX : (r i + 1) * (K + 3) ≤ ρ * (K + 3) := Nat.mul_le_mul_right _ hc.1
    have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
      (n' := 1 + exprDepth a + 2 + ρ * (K + 3)) hva (by omega)
    exact max_le (by omega) (by omega)
  | @loop env i a ba bl va w ha hl iha ihl =>
    simp only [GProp] at iha ihl ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hw, hl'⟩ := ihl hva
    refine ⟨hw, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.2
    have h2 := hl' base
    refine (EvalsSpT.loop h1 h2).mono ?_
    simp only [exprDepth]
    have hX : (r i + 1) * (K + 3) ≤ ρ * (K + 3) := Nat.mul_le_mul_right _ hc.1
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := Nat.mul_le_mul_right M (show (r i + 1) * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    exact max_le (by omega) (by omega)
  | @stop i v body bb v' hbody hb ihb =>
    simp only [GProp] at ihb ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    refine ⟨?_, fun base => ?_⟩
    · rw [valSize_flag_pair] at hpair
      omega
    · obtain ⟨hdep, hcb⟩ := hR i body hbody
      have h1 := hb' (base + valSize v) (r i) hcb
      refine (LoopSpT.stop hbody h1).mono ?_
      have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
      have e1 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
        (n' := (r i + 1) * (K + 3)) hv (by omega)
      omega
  | @cont i v body bb bw flag v' w hbody hb hflag hrest ihb ihr =>
    simp only [GProp] at ihb ihr ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    have hv' : valSize v' ≤ M := by
      rw [valSize_flag_pair] at hpair
      omega
    obtain ⟨hw, hr'⟩ := ihr hv'
    refine ⟨hw, fun base => ?_⟩
    obtain ⟨hdep, hcb⟩ := hR i body hbody
    have h1 := hb' (base + valSize v) (r i) hcb
    refine (LoopSpT.cont hbody h1 hflag (hr' base)).mono ?_
    have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
    have e1 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
      (n' := (r i + 1) * (K + 3)) hv (by omega)
    exact max_le (by omega) le_rfl

/-- **Generic space theorem.** For a program with a rank certificate, an `EvalsVal` evaluation of
`e` (callees of rank `< ρ`) in an environment of values `≤ M` runs within peak
`base + (exprDepth e + 2 + ρ (K + 3)) M`, consuming exactly `bits`. -/
theorem EvalsVal.toSpT {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ} (hR : RankOK prog r K)
    {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) {ρ : ℕ}
    (hc : CalleesLt r ρ e) (base : ℕ) :
    EvalsSpT prog base env bits e v (base + (exprDepth e + 2 + ρ * (K + 3)) * M) :=
  (gst_aux hR h henv).2 base ρ hc

/-- Produced values are `≤ M` (for environments of values `≤ M`). -/
theorem EvalsVal.val_le {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ} (hR : RankOK prog r K)
    {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) :
    valSize v ≤ M :=
  (gst_aux hR h henv).1

/-- **GST at the entry point**: the entry body (function `0`) evaluated on an input of size
`≤ M`, consuming exactly `bits`, runs on every tape `bits ++ rest`, leaving `rest`, with peak
`≤ ((r 0 + 1)(K + 3) + 1) M`. -/
theorem EvalsVal.eval_entry {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ} (hR : RankOK prog r K)
    {body : Expr} (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool}
    (h : EvalsVal prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) :
    ∃ fuel c p, p ≤ ((r 0 + 1) * (K + 3) + 1) * M ∧
      ∀ rest, eval prog fuel (valSize input) [input] (bits ++ rest) body =
        some (out, c, p, rest) := by
  obtain ⟨hdep, hcb⟩ := hR 0 body h0
  have hS := h.toSpT hR (by simpa using hin) hcb (valSize input)
  obtain ⟨fuel, c, p, hp, hf⟩ := hS.eval_append
  refine ⟨fuel, c, p, ?_, hf⟩
  have hri : (r 0 + 1) * (K + 3) = r 0 * (K + 3) + (K + 3) := by ring
  have e1 := GST.add_le_mul (n := exprDepth body + 2 + r 0 * (K + 3))
    (n' := (r 0 + 1) * (K + 3) + 1) hin (by omega)
  omega

/-- **GST + `RunsOn`.** -/
theorem EvalsVal.runsOn {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ} (hR : RankOK prog r K)
    {body : Expr} (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool}
    (h : EvalsVal prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) {Sb : ℝ}
    (hS : ((((r 0 + 1) * (K + 3) + 1) * M : ℕ) : ℝ) ≤ Sb) (rest : List Bool) :
    RunsOn prog input (bits ++ rest) out Sb := by
  obtain ⟨fuel, c, p, hp, hf⟩ := h.eval_entry hR h0 hin
  exact ⟨body, fuel, c, p, rest, h0, hf rest, le_trans (by exact_mod_cast hp) hS⟩

/-! ## Reverse bridge: semantic runs are `EvalsVal` evaluations -/

theorem toVal_aux (prog : List Expr) (n : ℕ) :
    (∀ base env tape e r, eval prog n base env tape e = some r →
      ∃ bits, tape = bits ++ r.2.2.2 ∧ EvalsVal prog (r.2.2.1 - base) env bits (.inl e) r.1) ∧
    (∀ base i acc tape r, loopRun prog n base i acc tape = some r →
      ∃ bits, tape = bits ++ r.2.2.2 ∧
        EvalsVal prog (r.2.2.1 - base) [] bits (.inr (i, acc)) r.1) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ h => by simp [eval] at h, fun _ _ _ _ _ h => by simp [loopRun] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e r hr
      cases e with
      | var i =>
        obtain ⟨v, hv, rfl⟩ := (eval_var_iff prog).mp hr
        exact ⟨[], rfl, EvalsVal.var hv⟩
      | lit z =>
        rw [eval_lit_eq] at hr
        cases hr
        exact ⟨[], rfl, EvalsVal.lit (by dsimp only; omega)⟩
      | nil =>
        rw [eval_nil_eq] at hr
        cases hr
        exact ⟨[], rfl, EvalsVal.nil (by dsimp only; omega)⟩
      | coin =>
        obtain ⟨b, rest, rfl, rfl⟩ := (eval_coin_iff prog).mp hr
        refine ⟨[b], rfl, ?_⟩
        rw [coinVal_eq_encB]
        exact EvalsVal.coin b (by dsimp only; omega)
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ :=
          (eval_bin_iff prog).mp hr
        obtain ⟨ba, hta, hVa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨bb, htb, hVb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hta htb hVa hVb ⊢
        refine ⟨ba ++ bb, by rw [hta, htb, List.append_assoc], ?_⟩
        exact EvalsVal.bin (hVa.mono_M (by omega)) (hVb.mono_M (by omega)) hv (by omega)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := (eval_un_iff prog).mp hr
        obtain ⟨ba, hta, hVa⟩ := ihe _ _ _ _ _ ha
        dsimp only at hta hVa ⊢
        exact ⟨ba, hta, EvalsVal.un (hVa.mono_M (by omega)) hv (by omega)⟩
      | ite c t f =>
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := (eval_ite_iff prog).mp hr
        obtain ⟨bc, htc, hVc⟩ := ihe _ _ _ _ _ hc
        obtain ⟨bv, htv, hVv⟩ := ihe _ _ _ _ _ hv
        dsimp only at htc htv hVc hVv ⊢
        refine ⟨bc ++ bv, by rw [htc, htv, List.append_assoc], ?_⟩
        exact EvalsVal.ite (hVc.mono_M (by omega)) (hVv.mono_M (by omega))
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := (eval_letE_iff prog).mp hr
        obtain ⟨ba, hta, hVa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨bb, htb, hVb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hta htb hVa hVb ⊢
        refine ⟨ba ++ bb, by rw [hta, htb, List.append_assoc], ?_⟩
        exact EvalsVal.letE (hVa.mono_M (by omega)) (hVb.mono_M (by omega))
      | call i a =>
        obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩ :=
          (eval_call_iff prog).mp hr
        obtain ⟨ba, hta, hVa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨bb, htb, hVb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hta htb hVa hVb ⊢
        refine ⟨ba ++ bb, by rw [hta, htb, List.append_assoc], ?_⟩
        exact EvalsVal.call (hVa.mono_M (by omega)) hbody (hVb.mono_M (by omega))
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := (eval_loop_iff prog).mp hr
        obtain ⟨ba, hta, hVa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨bl, htl, hVl⟩ := ihl _ _ _ _ _ hl
        dsimp only at hta htl hVa hVl ⊢
        refine ⟨ba ++ bl, by rw [hta, htl, List.append_assoc], ?_⟩
        exact EvalsVal.loop (hVa.mono_M (by omega)) (hVl.mono_M (by omega))
    · intro base i acc tape r hr
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := (loopRun_succ_iff prog).mp hr
      obtain ⟨bb, htb, hVb⟩ := ihe _ _ _ _ _ hb
      dsimp only at htb hVb
      rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
      · subst hflag
        dsimp only
        exact ⟨bb, htb, EvalsVal.stop hbody (hVb.mono_M (by omega))⟩
      · obtain ⟨bw, htw, hVw⟩ := ihl _ _ _ _ _ hw
        dsimp only at htw hVw ⊢
        refine ⟨bb ++ bw, by rw [htb, htw, List.append_assoc], ?_⟩
        exact EvalsVal.cont hbody (hVb.mono_M (by omega)) hflag (hVw.mono_M (by omega))

/-- An exact evaluation with peak `p` at base `base` is an `EvalsVal` evaluation with
`M = p - base`. -/
theorem EvalsToT.toVal {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} {c p : ℕ} (h : EvalsToT prog base env bits e v c p) :
    EvalsVal prog (p - base) env bits (.inl e) v := by
  obtain ⟨fuel, h⟩ := h
  obtain ⟨bits', hb, hV⟩ := (toVal_aux prog fuel).1 base env bits e _ h
  dsimp only at hb hV
  rw [List.append_nil] at hb
  subst hb
  exact hV

/-- **Reverse bridge.** A spec with peak `≤ base + S` gives an `EvalsVal` evaluation with
`M = S`. -/
theorem EvalsLeT.toVal {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} {C S : ℕ} (h : EvalsLeT prog base env bits e v C (base + S)) :
    EvalsVal prog S env bits (.inl e) v := by
  obtain ⟨c, p, h, -, hp⟩ := h
  exact h.toVal.mono_M (by omega)

theorem EvalsLe.toVal {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {C S : ℕ} (h : EvalsLe prog base env e v C (base + S)) :
    EvalsVal prog S env [] (.inl e) v :=
  EvalsLeT.toVal h

theorem EvalsSpT.toVal {prog : List Expr} {base : ℕ} {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} {S : ℕ} (h : EvalsSpT prog base env bits e v (base + S)) :
    EvalsVal prog S env bits (.inl e) v := by
  obtain ⟨C, h⟩ := h
  exact EvalsLeT.toVal h

theorem EvalsSp.toVal {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {S : ℕ} (h : EvalsSp prog base env e v (base + S)) : EvalsVal prog S env [] (.inl e) v :=
  EvalsSpT.toVal h

theorem LoopToT.toVal {prog : List Expr} {base i : ℕ} {acc w : Val} {bits : List Bool}
    {c p : ℕ} (h : LoopToT prog base i acc bits w c p) :
    EvalsVal prog (p - base) [] bits (.inr (i, acc)) w := by
  obtain ⟨fuel, h⟩ := h
  obtain ⟨bits', hb, hV⟩ := (toVal_aux prog fuel).2 base i acc bits _ h
  dsimp only at hb hV
  rw [List.append_nil] at hb
  subst hb
  exact hV

theorem LoopLeT.toVal {prog : List Expr} {base i : ℕ} {acc w : Val} {bits : List Bool}
    {C S : ℕ} (h : LoopLeT prog base i acc bits w C (base + S)) :
    EvalsVal prog S [] bits (.inr (i, acc)) w := by
  obtain ⟨c, p, h, -, hp⟩ := h
  exact h.toVal.mono_M (by omega)

theorem LoopLe.toVal {prog : List Expr} {base i : ℕ} {acc w : Val} {C S : ℕ}
    (h : LoopLe prog base i acc w C (base + S)) : EvalsVal prog S [] [] (.inr (i, acc)) w :=
  LoopLeT.toVal h

end F2e2e.Cost
