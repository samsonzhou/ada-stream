import F2e2e.Cost.MachineSimMain

/-!
# The bridge from the big-step space to the machine's bit space

`runsWithinBitsCfg_of_runsOn`: if `RunsOn prog input tape out S` (big-step evaluation of `prog` on
`input` with the tape `tape` returns `out` with peak at most `S` tree units), then
`RunsWithinBitsCfg prog input tape out (bitsFactor prog · S + bitsConst prog)`: the small-step machine
halts with the same output and the same unread tape, and every configuration of the run has at most
`bitsFactor prog · S + bitsConst prog` bits, where (`bitsFactor_eq`, `bitsConst_eq`)

* `bitsFactor prog = (progDepth prog + 1) · (⌈log₂(|prog| + 1)⌉ + 3 · progDepth prog + 11)`,
* `bitsConst prog = (progDepth prog + 1) · (⌈log₂(|prog| + 1)⌉ + 3 · progDepth prog + 8) + 1`,

and `progDepth prog` is the maximal height of a function body.

Footprint form (the `RunsWithinBits` of the Spec v2 candidate, local copy `RunsWithinBitsFP`):
`runsWithinBitsFP_of_runsOn` gives the footprint bound `2 · (bitsFactor prog · S + bitsConst prog)`
(`RunsWithinBitsCfg.toFP`: both ends of every step are configurations of the run).

The Spec's run predicate `F2e2e.RunsWithinBits` is the footprint form under Spec v2 (`RunsWithinBitsFP` has
its body) and the footprint plus arithmetic workspace plus finite-control temporaries under Spec v2.1
(`RunsWithinBitsW`, `runsWithinBitsW_of_runsOn` in `MachineWork`).
-/

namespace F2e2e.Machine

open F2e2e.Cost

theorem bitsFactor_eq (prog : List Expr) :
    bitsFactor prog =
      (progDepth prog + 1) * (Nat.clog 2 (prog.length + 1) + 3 * progDepth prog + 11) := by
  unfold bitsFactor frameC posBits fnWidth; ring

theorem bitsConst_eq (prog : List Expr) :
    bitsConst prog =
      (progDepth prog + 1) * (Nat.clog 2 (prog.length + 1) + 3 * progDepth prog + 8) + 1 := by
  unfold bitsConst frameC posBits fnWidth; ring

/-- Bounding `progDepth` by the heights of the bodies. -/
theorem progDepth_le {prog : List Expr} {D : ℕ} (h : ∀ body ∈ prog, height body ≤ D) :
    progDepth prog ≤ D := by
  induction prog with
  | nil => simp [progDepth]
  | cons b rest ih =>
    simp only [progDepth, List.map_cons, List.foldr_cons] at *
    exact max_le (h b (by simp)) (ih fun body hb => h body (by simp [hb]))

/-- Upper bound for the factor from a depth bound `D` and a width `w` with `|prog| + 1 ≤ 2^w`. -/
theorem bitsFactor_le {prog : List Expr} {D w : ℕ} (hD : progDepth prog ≤ D)
    (hw : prog.length + 1 ≤ 2 ^ w) : bitsFactor prog ≤ (D + 1) * (w + 3 * D + 11) := by
  rw [bitsFactor_eq]
  have hc : Nat.clog 2 (prog.length + 1) ≤ w := Nat.clog_le_of_le_pow hw
  exact Nat.mul_le_mul (by omega) (by omega)

/-- Upper bound for the additive constant from a depth bound and a width. -/
theorem bitsConst_le {prog : List Expr} {D w : ℕ} (hD : progDepth prog ≤ D)
    (hw : prog.length + 1 ≤ 2 ^ w) : bitsConst prog ≤ (D + 1) * (w + 3 * D + 8) + 1 := by
  rw [bitsConst_eq]
  have hc : Nat.clog 2 (prog.length + 1) ≤ w := Nat.clog_le_of_le_pow hw
  have := Nat.mul_le_mul (show progDepth prog + 1 ≤ D + 1 by omega)
    (show Nat.clog 2 (prog.length + 1) + 3 * progDepth prog + 8 ≤ w + 3 * D + 8 by omega)
  omega

/-- Machine execution within `S` bits, per configuration: the machine halts with `out` and every
configuration of the run has at most `S` bits (the run predicate of the first Spec v2 C1 draft; internal,
formerly the local `RunsWithinBits` of `Cost/MachineDefs.lean`). -/
def RunsWithinBitsCfg (prog : List Expr) (input : Val) (tape : List Bool) (out : Val) (S : ℝ) :
    Prop :=
  ∃ (n : ℕ) (rest : List Bool),
    stepN prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩ ∧
    ∀ k ≤ n, ∀ c : Conf, stepN prog k (initConf input tape) = some c → (confBits prog c : ℝ) ≤ S

/-- Monotonicity of `RunsWithinBitsCfg` in the bound. -/
theorem RunsWithinBitsCfg.mono {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S S' : ℝ} (h : RunsWithinBitsCfg prog input tape out S) (hS : S ≤ S') :
    RunsWithinBitsCfg prog input tape out S' := by
  obtain ⟨n, rest, hn, hall⟩ := h
  exact ⟨n, rest, hn, fun k hk c hc => (hall k hk c hc).trans hS⟩

/-- Every configuration met while simulating a top-level run fits in `bitsFactor · peak + bitsConst`
bits. -/
theorem simBound_top {prog : List Expr} {body : Expr} {input : Val} {peak : ℕ}
    (hD : height body ≤ progDepth prog) (hpk : valSize input ≤ peak) :
    simBound prog (height body) [input] (peak - valSize input) + 1 ≤
      bitsFactor prog * peak + bitsConst prog := by
  unfold simBound bitsConst
  rw [bitEncodeVals_singleton_length]
  have hv := bitEncodeVal_length_le input
  set s := valSize input
  set D := progDepth prog
  set fc := frameC prog
  have h1 : (height body + 1) * ((bitEncodeVal input).length + 2 + fc) ≤
      (D + 1) * (fc + 2) + (D + 1) * (3 * s) := by
    calc (height body + 1) * ((bitEncodeVal input).length + 2 + fc)
        ≤ (D + 1) * ((fc + 2) + 3 * s) := Nat.mul_le_mul (by omega) (by omega)
      _ = (D + 1) * (fc + 2) + (D + 1) * (3 * s) := Nat.mul_add _ _ _
  have h2 : (D + 1) * (3 * s) ≤ bitsFactor prog * s := by
    unfold bitsFactor
    calc (D + 1) * (3 * s) ≤ (D + 1) * ((fc + 5) * s) :=
          Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (by omega))
      _ = (D + 1) * (fc + 5) * s := by ring
  have h3 : bitsFactor prog * s + bitsFactor prog * (peak - s) = bitsFactor prog * peak := by
    rw [← Nat.mul_add]; congr 1; omega
  omega

/-- **The bridge, per-configuration form**: a big-step run within `S` tree units gives a machine run
with the same output and unread tape within `bitsFactor prog · S + bitsConst prog` bits per configuration.
(The footprint form is `runsWithinBitsFP_of_runsOn` below; the Spec v2.1 form is `runsWithinBitsW_of_runsOn`
in `MachineWork`.) -/
theorem runsWithinBitsCfg_of_runsOn {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S : ℝ} (h : RunsOn prog input tape out S) :
    RunsWithinBitsCfg prog input tape out (bitsFactor prog * S + bitsConst prog) := by
  obtain ⟨body, fuel, cost, peak, rest, hbody, heval, hpeak⟩ := h
  have hroot : exprAt prog ⟨0, []⟩ = some body := exprAt_root hbody
  obtain ⟨n, hn, hall⟩ :=
    (sim prog fuel).1 (valSize input) [input] tape body out cost peak rest ⟨0, []⟩ [] heval hroot
  refine ⟨n, rest, hn, fun k hk d hd => ?_⟩
  obtain ⟨F, hs, hb⟩ := hall k hk d hd
  have hconf : confBits prog d = (encodeCtrl prog d.ctrl).length + framesBits prog F + 1 := by
    rw [confBits_eq, hs, encodeStack_append_length, encodeStack_nil_length]
    omega
  have hpk : valSize input + valSize out ≤ peak := eval_peak_ge prog fuel _ _ _ _ _ heval
  have htop := simBound_top (prog := prog) (input := input) (height_le_progDepth hbody)
    (show valSize input ≤ peak by omega)
  have hnat : confBits prog d ≤ bitsFactor prog * peak + bitsConst prog := by omega
  calc (confBits prog d : ℝ) ≤ ((bitsFactor prog * peak + bitsConst prog : ℕ) : ℝ) := by
        exact_mod_cast hnat
    _ = (bitsFactor prog : ℝ) * (peak : ℝ) + bitsConst prog := by push_cast; ring
    _ ≤ bitsFactor prog * S + bitsConst prog := by
        gcongr

/-! ## The footprint form (Spec v2 candidate; statement check C, F2) -/

/-- The footprint form of `RunsWithinBits`, verbatim the `RunsWithinBits` of the Spec v2 candidate
(`spec_v2/Spec.lean`, sha256 `cc04b02b…`): the machine halts with `out`, and the footprint of every step,
i.e. the bits of the configuration before the step plus the bits of the configuration after it, is at
most `S`. (Verbatim the body of Spec v2's `RunsWithinBits`. Under Spec v2.1, whose `RunsWithinBits` also
charges `stepWork` and `ctrlWork`, an internal notion, used by `C/SpaceChain`.) -/
def RunsWithinBitsFP (prog : List Expr) (input : Val) (tape : List Bool) (out : Val) (S : ℝ) :
    Prop :=
  ∃ (n : ℕ) (rest : List Bool),
    stepN prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩ ∧
    ∀ k < n, ∀ c c' : Conf, stepN prog k (initConf input tape) = some c → step prog c = some c' →
      ((confBits prog c + confBits prog c' : ℕ) : ℝ) ≤ S

/-- A per-configuration bound `S` gives the footprint bound `2S` (both ends of every step are
configurations of the run). -/
theorem RunsWithinBitsCfg.toFP {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S : ℝ}
    (h : RunsWithinBitsCfg prog input tape out S) : RunsWithinBitsFP prog input tape out (2 * S) := by
  obtain ⟨n, rest, hn, hall⟩ := h
  refine ⟨n, rest, hn, fun k hk c c' hc hc' => ?_⟩
  have hc2 : stepN prog (k + 1) (initConf input tape) = some c' := by
    rw [stepN_add, hc]
    exact stepN_one hc'
  have h1 := hall k hk.le c hc
  have h2 := hall (k + 1) hk c' hc2
  push_cast
  linarith

/-- Monotonicity of `RunsWithinBitsFP` in the bound. -/
theorem RunsWithinBitsFP.mono {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S S' : ℝ} (h : RunsWithinBitsFP prog input tape out S) (hS : S ≤ S') :
    RunsWithinBitsFP prog input tape out S' := by
  obtain ⟨n, rest, hn, hall⟩ := h
  exact ⟨n, rest, hn, fun k hk c c' hc hc' => (hall k hk c c' hc hc').trans hS⟩

/-- **The bridge, footprint form** (Spec v2 C1 obligation for the candidate's `RunsWithinBits`): a
big-step run within `S` tree units gives a machine run with the same output and unread tape in which
every step has footprint at most `2 · (bitsFactor prog · S + bitsConst prog)` bits. -/
theorem runsWithinBitsFP_of_runsOn {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S : ℝ} (h : RunsOn prog input tape out S) :
    RunsWithinBitsFP prog input tape out (2 * (bitsFactor prog * S + bitsConst prog)) :=
  (runsWithinBitsCfg_of_runsOn h).toFP

end F2e2e.Machine
