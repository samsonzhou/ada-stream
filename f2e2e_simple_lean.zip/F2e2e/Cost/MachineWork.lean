import F2e2e.Cost.MachineBridge
import F2e2e.Cost.ArithWork

/-!
# U1 (iii): the bridge to the Spec v2.1 run predicate (footprint + arithmetic workspace)

`RunsWithinBitsW` is the Spec v2.1 `RunsWithinBits` itself (an `abbrev` under its pre-lock name;
`runsWithinBitsW_iff` restates its body): every step's footprint (the
configuration before plus the configuration after) plus the arithmetic workspace `stepWork` of the step
(`opWork` of an arithmetic `binR` step, `unWork = 0` of a unary step, `0` otherwise) plus the
finite-control temporaries `ctrlWork` is at most `S`.

* `binR_operands_le`: the operands of a `binR` step are inside the configuration before the step;
* `stepWork_le`: `stepWork prog c ≤ arithC · confBits prog c + arithC'`;
* `ctrlWork_le`: `ctrlWork prog c c' ≤ 4·(confBits prog c + confBits prog c' + stepWork prog c) + 72`;
* `runsWithinBitsW_of_runsOn`: a big-step run within `S` tree units gives a machine run with the same
  output and unread tape whose every step is charged at most
  `(bridgeWC + 2)·(bitsFactor prog · S + bitsConst prog) + bridgeWC'` bits
  (`bridgeWC = 5·arithC + 8 = 48`, `bridgeWC' = 5·arithC' + 72 = 392`).
-/

namespace F2e2e.Machine

/-- Spec v2.1's run predicate `F2e2e.RunsWithinBits`, under its pre-lock name: the machine halts with
`out`, and for every step the footprint plus the step's arithmetic workspace plus its finite-control
temporaries is at most `S`. -/
abbrev RunsWithinBitsW (prog : List Expr) (input : Val) (tape : List Bool) (out : Val) (S : ℝ) :
    Prop :=
  F2e2e.RunsWithinBits prog input tape out S

/-- The body of Spec v2.1's `RunsWithinBits` (verbatim the pre-lock local definition). -/
theorem runsWithinBitsW_iff {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S : ℝ} :
    RunsWithinBitsW prog input tape out S ↔
      ∃ (n : ℕ) (rest : List Bool),
        stepN prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩ ∧
        ∀ k < n, ∀ c c' : Conf, stepN prog k (initConf input tape) = some c → step prog c = some c' →
          ((confBits prog c + confBits prog c' + stepWork prog c + ctrlWork prog c c' : ℕ) : ℝ) ≤ S :=
  Iff.rfl

/-- Monotonicity of `RunsWithinBitsW` in the bound. -/
theorem RunsWithinBitsW.mono {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S S' : ℝ} (h : RunsWithinBitsW prog input tape out S) (hS : S ≤ S') :
    RunsWithinBitsW prog input tape out S' := by
  obtain ⟨n, rest, hn, hall⟩ := h
  exact ⟨n, rest, hn, fun k hk c c' hc hc' => (hall k hk c c' hc hc').trans hS⟩

/-- The operands of a `binR` step are inside the configuration before the step. -/
theorem binR_operands_le (prog : List Expr) (v va : Val) (p : CodePos) (K : List Frame)
    (t : List Bool) :
    (bitEncodeVal va).length + (bitEncodeVal v).length ≤
      confBits prog ⟨Ctrl.ret v, Frame.binR p va :: K, t⟩ := by
  simp only [confBits, encodeConf, encodeCtrl, encodeStack, encodeFrame, List.length_append,
    List.length_cons]
  omega

/-- The workspace charged to a step is at most `arithC · confBits + arithC'`. -/
theorem stepWork_le (prog : List Expr) (c : Conf) :
    stepWork prog c ≤ arithC * confBits prog c + arithC' := by
  obtain ⟨ctrl, stack, t⟩ := c
  cases ctrl with
  | eval p env => simp [stepWork]
  | ret v =>
    cases stack with
    | nil => simp [stepWork]
    | cons f K =>
      cases f with
      | binR p va =>
        simp only [stepWork]
        split
        · rename_i op _ _ _
          exact le_trans (opWork_le op va v) (by
            have := binR_operands_le prog v va p K t
            gcongr)
        · omega
      | un p =>
        simp only [stepWork]
        split
        · rename_i op _ _
          cases op <;> simp [unWork]
        · omega
      | binL p env => simp [stepWork]
      | ite p env => simp [stepWork]
      | letE p env => simp [stepWork]
      | callArg p => simp [stepWork]
      | loopInit p => simp [stepWork]
      | loopIter p => simp [stepWork]

/-- `⌈log₂ n⌉ ≤ n`. -/
theorem clog_two_le_self' (n : ℕ) : Nat.clog 2 n ≤ n :=
  Nat.clog_le_of_le_pow Nat.lt_two_pow_self.le

/-- The finite-control temporaries of a step: `ctrlWork ≤ 4·(footprint + workspace) + 72`. -/
theorem ctrlWork_le (prog : List Expr) (c c' : Conf) :
    ctrlWork prog c c' ≤ 4 * (confBits prog c + confBits prog c' + stepWork prog c) + 72 := by
  unfold ctrlWork
  have := clog_two_le_self' (confBits prog c + confBits prog c' + stepWork prog c + 2)
  omega

/-- The multiplicative constant of the Spec v2.1 bridge: the footprint, the workspace (`arithC`) and the
finite-control temporaries (`4·(footprint + workspace)`) give `5·(2 + arithC) = bridgeWC + 2`. -/
def bridgeWC : ℕ := 5 * arithC + 8

/-- The additive constant of the Spec v2.1 bridge: `5·arithC' + 72`. -/
def bridgeWC' : ℕ := 5 * arithC' + 72

theorem bridgeWC_eq : bridgeWC = 48 := rfl

theorem bridgeWC'_eq : bridgeWC' = 392 := rfl

/-- **The bridge, Spec v2.1 form** (U1 (iii)): a big-step run within `S` tree units gives a machine run
with the same output and unread tape in which every step's footprint plus arithmetic workspace plus
finite-control temporaries is at most `(bridgeWC + 2)·(bitsFactor prog · S + bitsConst prog) + bridgeWC'`. -/
theorem runsWithinBitsW_of_runsOn {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {S : ℝ} (h : RunsOn prog input tape out S) :
    RunsWithinBitsW prog input tape out
      ((((bridgeWC : ℕ) : ℝ) + 2) * ((bitsFactor prog : ℝ) * S + (bitsConst prog : ℝ)) +
        ((bridgeWC' : ℕ) : ℝ)) := by
  obtain ⟨n, rest, hn, hall⟩ := runsWithinBitsCfg_of_runsOn h
  refine ⟨n, rest, hn, fun k hk c c' hc hc' => ?_⟩
  have hc2 : stepN prog (k + 1) (initConf input tape) = some c' := by
    rw [stepN_add, hc]
    exact stepN_one hc'
  have h1 := hall k hk.le c hc
  have h2 := hall (k + 1) hk c' hc2
  have h3 : (stepWork prog c : ℝ) ≤ (arithC : ℝ) * (confBits prog c : ℝ) + (arithC' : ℝ) := by
    exact_mod_cast stepWork_le prog c
  have h5 : (ctrlWork prog c c' : ℝ) ≤
      4 * ((confBits prog c : ℝ) + (confBits prog c' : ℝ) + (stepWork prog c : ℝ)) + 72 := by
    exact_mod_cast ctrlWork_le prog c c'
  have hC : (0 : ℝ) ≤ (arithC : ℝ) := Nat.cast_nonneg _
  have h4 := mul_le_mul_of_nonneg_left h1 hC
  unfold bridgeWC bridgeWC'
  push_cast
  linarith

end F2e2e.Machine
