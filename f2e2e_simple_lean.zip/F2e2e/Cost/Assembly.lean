import F2e2e.Cost.Calculus

/-!
# Program assembly (port of cut2's `Cost/Assembly.lean`, with `RunsOn`)

* `mkProg main tbl`: the program (list of function bodies) with `main` at index `0` and, at every
  index `0 < i ≤ tblMax tbl`, the first `b` with `(i, b) ∈ tbl` (filler `Expr.nil` elsewhere).
  Every area exports a table `xTable : List (ℕ × Expr)` of `(Idx.X, body_X)` entries; the final
  programs are `mkProg initMain (tbl₁ ++ tbl₂ ++ …)` etc.
* `mkProg_zero`: `(mkProg main tbl)[0]? = some main`.
* `mkProg_get_of_lookup`: `tbl.lookup i = some b → 0 < i → (mkProg main tbl)[i]? = some b`.
  **Recommended for discharging the `prog[Idx.X]? = some body_X` hypotheses**: the premise
  `tbl.lookup Idx.X = some body_X` is proved by `rfl` (the kernel only compares the natural-number
  keys with `Nat.beq` until the first match; the bodies are never unfolded), and needs no `Nodup`.
* `mkProg_get`: the `Nodup`/membership form.
* `runsOn_mkProg` (deterministic entry body, every tape) and `runsOn_mkProg_T` (entry body
  consuming the fresh bits `bits`, every tape extending `bits`): the `RunsOn` bridges for an entry
  point `main`.
* `RunsOn_of_EvalsLeT_take` / `runsOn_mkProg_take`: an entry body that consumes exactly `k` bits
  (for every `bs` of length `k`, output `out bs`) runs on every concrete tape of length `≥ k`, with
  output `out (tape.take k)`.
-/

namespace F2e2e.Cost

/-- Largest key of a table (`0` for the empty table). -/
def tblMax (tbl : List (ℕ × Expr)) : ℕ := (tbl.map Prod.fst).foldr max 0

/-- The program with `main` at index `0` and the first `b` with `(i, b) ∈ tbl` at every index
`0 < i ≤ tblMax tbl` (filler `Expr.nil` at the other indices). -/
def mkProg (main : Expr) (tbl : List (ℕ × Expr)) : List Expr :=
  main :: (List.range (tblMax tbl)).map (fun j => (tbl.lookup (j + 1)).getD Expr.nil)

theorem mkProg_zero (main : Expr) (tbl : List (ℕ × Expr)) : (mkProg main tbl)[0]? = some main :=
  rfl

theorem le_tblMax {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr} (h : (i, b) ∈ tbl) :
    i ≤ tblMax tbl := by
  induction tbl with
  | nil => simp at h
  | cons p tbl ih =>
    simp only [tblMax, List.map_cons, List.foldr_cons] at ih ⊢
    rcases List.mem_cons.mp h with rfl | h
    · exact le_max_left _ _
    · exact le_trans (ih h) (le_max_right _ _)

/-- **Table lookup.** If the first entry of key `i > 0` in `tbl` is `b`, then the program has
`b` at index `i`. The premise is typically proved by `rfl`. -/
theorem mkProg_get_of_lookup {main : Expr} {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr}
    (h : tbl.lookup i = some b) (hi : 0 < i) : (mkProg main tbl)[i]? = some b := by
  obtain ⟨l₁, l₂, htbl, -⟩ := List.lookup_eq_some_iff.mp h
  have hmem : (i, b) ∈ tbl := by rw [htbl]; simp
  have hle := le_tblMax hmem
  obtain ⟨j, rfl⟩ : ∃ j, i = j + 1 := ⟨i - 1, by omega⟩
  simp only [mkProg, List.getElem?_cons_succ, List.getElem?_map,
    List.getElem?_range (show j < tblMax tbl by omega), Option.map_some, h, Option.getD_some]

theorem lookup_of_mem_of_nodup {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr}
    (hnd : (tbl.map Prod.fst).Nodup) (h : (i, b) ∈ tbl) : tbl.lookup i = some b := by
  induction tbl with
  | nil => simp at h
  | cons p tbl ih =>
    obtain ⟨k, c⟩ := p
    simp only [List.map_cons, List.nodup_cons] at hnd
    rcases List.mem_cons.mp h with h1 | h1
    · simp only [Prod.mk.injEq] at h1
      obtain ⟨rfl, rfl⟩ := h1
      simp
    · have hik : i ≠ k := by
        intro e
        subst e
        exact hnd.1 (List.mem_map_of_mem (f := Prod.fst) h1)
      rw [List.lookup_cons, beq_false_of_ne hik]
      exact ih hnd.2 h1

/-- **Table lookup (`Nodup` form).** -/
theorem mkProg_get {main : Expr} {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr}
    (hnd : (tbl.map Prod.fst).Nodup) (h : (i, b) ∈ tbl) (hi : 0 < i) :
    (mkProg main tbl)[i]? = some b :=
  mkProg_get_of_lookup (lookup_of_mem_of_nodup hnd h) hi

theorem length_mkProg (main : Expr) (tbl : List (ℕ × Expr)) :
    (mkProg main tbl).length = tblMax tbl + 1 := by
  simp [mkProg]

/-- **`RunsOn` bridge** for programs built by `mkProg` whose entry body is deterministic: the
program runs on every tape. -/
theorem runsOn_mkProg {main : Expr} {tbl : List (ℕ × Expr)} {input out : Val} {C S : ℕ}
    (h : EvalsLe (mkProg main tbl) (valSize input) [input] main out C S) {Sp : ℝ}
    (hS : (S : ℝ) ≤ Sp) (tape : List Bool) : RunsOn (mkProg main tbl) input tape out Sp :=
  RunsOn_of_EvalsLe (mkProg_zero main tbl) h hS tape

/-- **`RunsOn` bridge** for programs built by `mkProg` whose entry body consumes the fresh bits
`bits`: the program runs on every tape extending `bits`. -/
theorem runsOn_mkProg_T {main : Expr} {tbl : List (ℕ × Expr)} {input out : Val}
    {bits : List Bool} {C S : ℕ}
    (h : EvalsLeT (mkProg main tbl) (valSize input) [input] bits main out C S) {Sp : ℝ}
    (hS : (S : ℝ) ≤ Sp) (rest : List Bool) :
    RunsOn (mkProg main tbl) input (bits ++ rest) out Sp :=
  RunsOn_of_EvalsLeT (mkProg_zero main tbl) h hS rest

/-- **`RunsOn` on a concrete tape.** If, for every bit list `bs` of length `k`, the entry body
consumes exactly `bs` and outputs `out bs` within space `S`, then on every tape of length at least
`k` the program outputs `out (tape.take k)`. -/
theorem RunsOn_of_EvalsLeT_take {prog : List Expr} {body : Expr} (h0 : prog[0]? = some body)
    {input : Val} {k : ℕ} {out : List Bool → Val} {C S : ℕ}
    (h : ∀ bs : List Bool, bs.length = k →
      EvalsLeT prog (valSize input) [input] bs body (out bs) C S)
    {Sp : ℝ} (hS : (S : ℝ) ≤ Sp) (tape : List Bool) (hk : k ≤ tape.length) :
    RunsOn prog input tape (out (tape.take k)) Sp := by
  have := RunsOn_of_EvalsLeT h0 (h (tape.take k) (List.length_take_of_le hk)) hS (tape.drop k)
  rwa [List.take_append_drop] at this

/-- `RunsOn_of_EvalsLeT_take` for programs built by `mkProg`. -/
theorem runsOn_mkProg_take {main : Expr} {tbl : List (ℕ × Expr)} {input : Val} {k : ℕ}
    {out : List Bool → Val} {C S : ℕ}
    (h : ∀ bs : List Bool, bs.length = k →
      EvalsLeT (mkProg main tbl) (valSize input) [input] bs main (out bs) C S)
    {Sp : ℝ} (hS : (S : ℝ) ≤ Sp) (tape : List Bool) (hk : k ≤ tape.length) :
    RunsOn (mkProg main tbl) input tape (out (tape.take k)) Sp :=
  RunsOn_of_EvalsLeT_take (mkProg_zero main tbl) h hS tape hk

/-! ### Sanity check: a two-entry table -/

example : (mkProg Expr.nil [(3, Expr.lit 7), (1, Expr.lit 5)])[3]? = some (Expr.lit 7) :=
  mkProg_get_of_lookup rfl (by norm_num)

example : (mkProg Expr.nil [(3, Expr.lit 7), (1, Expr.lit 5)])[1]? = some (Expr.lit 5) :=
  mkProg_get_of_lookup rfl (by norm_num)

end F2e2e.Cost
