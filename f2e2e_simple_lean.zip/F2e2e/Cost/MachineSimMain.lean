import F2e2e.Cost.MachineSim

/-!
# The simulation theorem and the bridge `RunsOn ⇒ RunsWithinBitsCfg`

* One-step lemmas `step_eval_*`, `step_ret_*` for each rule of the machine.
* `sim prog n`: simulation of `eval`/`loopRun` at fuel `n` with the invariant of `MachineSim`.
* `runsWithinBitsCfg_of_runsOn` (`MachineBridge`): if `RunsOn prog input tape out S`, then the machine run of
  `prog` on `input` and `tape` halts with `out` (and the same unread tape), and every configuration
  has at most `bitsFactor prog · S + bitsConst prog` bits, with
  `bitsFactor prog = (progDepth prog + 1)·(⌈log₂(|prog|+1)⌉ + 3·progDepth prog + 11)` and
  `bitsConst prog = (progDepth prog + 1)·(⌈log₂(|prog|+1)⌉ + 3·progDepth prog + 8) + 1`.
-/

namespace F2e2e.Machine

open F2e2e.Cost

variable {prog : List Expr}

/-! ## One-step lemmas -/

section Steps

variable {q p : CodePos} {env : List Val} {K : List Frame} {t : List Bool}

theorem step_eval_var {i : ℕ} {v : Val} (hq : exprAt prog q = some (Expr.var i))
    (hv : env[i]? = some v) : step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.ret v, K, t⟩ := by
  simp [step, hq, hv]

theorem step_eval_lit {z : ℤ} (hq : exprAt prog q = some (Expr.lit z)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.ret (Val.int z), K, t⟩ := by
  simp [step, hq]

theorem step_eval_nil (hq : exprAt prog q = some Expr.nil) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.ret (Val.list []), K, t⟩ := by
  simp [step, hq]

theorem step_eval_coin {b : Bool} {rest : List Bool} (hq : exprAt prog q = some Expr.coin) :
    step prog ⟨Ctrl.eval q env, K, b :: rest⟩ =
      some ⟨Ctrl.ret (Val.int (if b = true then 1 else 0)), K, rest⟩ := by
  simp [step, hq]

theorem step_eval_bin {op : BinOp} {a b : Expr} (hq : exprAt prog q = some (Expr.bin op a b)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.binL q env :: K, t⟩ := by
  simp [step, hq]

theorem step_eval_un {op : UnOp} {a : Expr} (hq : exprAt prog q = some (Expr.un op a)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.un q :: K, t⟩ := by
  simp [step, hq]

theorem step_eval_ite {c a b : Expr} (hq : exprAt prog q = some (Expr.ite c a b)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.ite q env :: K, t⟩ := by
  simp [step, hq]

theorem step_eval_letE {a b : Expr} (hq : exprAt prog q = some (Expr.letE a b)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.letE q env :: K, t⟩ := by
  simp [step, hq]

theorem step_eval_call {i : ℕ} {a : Expr} (hq : exprAt prog q = some (Expr.call i a)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.callArg q :: K, t⟩ := by
  simp [step, hq]

theorem step_eval_loop {i : ℕ} {a : Expr} (hq : exprAt prog q = some (Expr.loop i a)) :
    step prog ⟨Ctrl.eval q env, K, t⟩ = some ⟨Ctrl.eval (q.child 0) env, Frame.loopInit q :: K, t⟩ := by
  simp [step, hq]

theorem step_ret_binL {v : Val} :
    step prog ⟨Ctrl.ret v, Frame.binL p env :: K, t⟩ =
      some ⟨Ctrl.eval (p.child 1) env, Frame.binR p v :: K, t⟩ := rfl

theorem step_ret_binR {op : BinOp} {a b : Expr} {va v w : Val} {c : ℕ}
    (hp : exprAt prog p = some (Expr.bin op a b)) (h : evalBin op va v = some (w, c)) :
    step prog ⟨Ctrl.ret v, Frame.binR p va :: K, t⟩ = some ⟨Ctrl.ret w, K, t⟩ := by
  simp [step, hp, h]

theorem step_ret_un {op : UnOp} {a : Expr} {v w : Val} {c : ℕ}
    (hp : exprAt prog p = some (Expr.un op a)) (h : evalUn op v = some (w, c)) :
    step prog ⟨Ctrl.ret v, Frame.un p :: K, t⟩ = some ⟨Ctrl.ret w, K, t⟩ := by
  simp [step, hp, h]

theorem step_ret_ite {z : ℤ} :
    step prog ⟨Ctrl.ret (Val.int z), Frame.ite p env :: K, t⟩ =
      some ⟨Ctrl.eval (p.child (if z ≠ 0 then 1 else 2)) env, K, t⟩ := rfl

theorem step_ret_letE {v : Val} :
    step prog ⟨Ctrl.ret v, Frame.letE p env :: K, t⟩ =
      some ⟨Ctrl.eval (p.child 1) (v :: env), K, t⟩ := rfl

theorem step_ret_callArg {i : ℕ} {a : Expr} {v : Val} (hp : exprAt prog p = some (Expr.call i a)) :
    step prog ⟨Ctrl.ret v, Frame.callArg p :: K, t⟩ = some ⟨Ctrl.eval ⟨i, []⟩ [v], K, t⟩ := by
  simp [step, hp]

theorem step_ret_loopInit {i : ℕ} {a : Expr} {v : Val} (hp : exprAt prog p = some (Expr.loop i a)) :
    step prog ⟨Ctrl.ret v, Frame.loopInit p :: K, t⟩ =
      some ⟨Ctrl.eval ⟨i, []⟩ [v], Frame.loopIter p :: K, t⟩ := by
  simp [step, hp]

theorem step_ret_loopIter_stop {i : ℕ} {a : Expr} {v' : Val}
    (hp : exprAt prog p = some (Expr.loop i a)) :
    step prog ⟨Ctrl.ret (Val.list [Val.int 0, v']), Frame.loopIter p :: K, t⟩ =
      some ⟨Ctrl.ret v', K, t⟩ := by
  simp [step, hp]

theorem step_ret_loopIter_cont {i : ℕ} {a : Expr} {flag : ℤ} {v' : Val}
    (hp : exprAt prog p = some (Expr.loop i a)) (hf : flag ≠ 0) :
    step prog ⟨Ctrl.ret (Val.list [Val.int flag, v']), Frame.loopIter p :: K, t⟩ =
      some ⟨Ctrl.eval ⟨i, []⟩ [v'], Frame.loopIter p :: K, t⟩ := by
  simp [step, hp, hf]

end Steps

/-! ## The simulation theorem -/

/-- Simulation of `eval` (first component) and `loopRun` (second component) at fuel `n`. -/
theorem sim (prog : List Expr) : ∀ n : ℕ,
    (∀ (base : ℕ) (env : List Val) (tape : List Bool) (e : Expr) (v : Val) (c pk : ℕ)
        (tape' : List Bool) (q : CodePos) (K : List Frame),
        eval prog n base env tape e = some (v, c, pk, tape') → exprAt prog q = some e →
        RunAll prog (Within prog K (simBound prog (height e) env (pk - base)))
          ⟨Ctrl.eval q env, K, tape⟩ ⟨Ctrl.ret v, K, tape'⟩) ∧
    (∀ (base i : ℕ) (v : Val) (tape : List Bool) (w : Val) (cw pw : ℕ) (tw : List Bool)
        (q : CodePos) (a : Expr) (K : List Frame),
        loopRun prog n base i v tape = some (w, cw, pw, tw) →
        exprAt prog q = some (Expr.loop i a) →
        RunAll prog (Within prog K (frameC prog + bitsFactor prog * (pw - base)))
          ⟨Ctrl.eval ⟨i, []⟩ [v], Frame.loopIter q :: K, tape⟩ ⟨Ctrl.ret w, K, tw⟩)
  | 0 => ⟨fun _ _ _ _ _ _ _ _ _ _ he _ => by simp [eval_zero_eq] at he,
          fun _ _ _ _ _ _ _ _ _ _ _ hl _ => by simp [loopRun_zero_eq] at hl⟩
  | n + 1 => by
    obtain ⟨ihE, ihL⟩ := sim prog n
    constructor
    · intro base env tape e v c pk tape' q K he hq
      cases e with
      | var i =>
        obtain ⟨v', hv', hr⟩ := (eval_var_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        exact RunAll.single (step_eval_var hq hv') (start_within hq env K tape _ _)
          (ret_within (by omega) K tape _ env)
      | lit z =>
        rw [eval_lit_eq] at he
        simp only [Option.some.injEq, Prod.mk.injEq] at he
        obtain ⟨rfl, -, rfl, h4⟩ := he
        subst tape'
        exact RunAll.single (step_eval_lit hq) (start_within hq env K tape _ _)
          (ret_within (by omega) K tape _ env)
      | nil =>
        rw [eval_nil_eq] at he
        simp only [Option.some.injEq, Prod.mk.injEq] at he
        obtain ⟨rfl, -, rfl, h4⟩ := he
        subst tape'
        exact RunAll.single (step_eval_nil hq) (start_within hq env K tape _ _)
          (ret_within (by omega) K tape _ env)
      | coin =>
        obtain ⟨b, rest, rfl, hr⟩ := (eval_coin_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨rfl, -, rfl, h4⟩ := hr
        subst tape'
        exact RunAll.single (step_eval_coin hq) (start_within hq env K _ _ _)
          (ret_within (by omega) K rest _ env)
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v', c', ha, hb, hv, hr⟩ := (eval_bin_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hqb : exprAt prog (q.child 1) = some b := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.bin op a b) := height_child (j := 0) rfl
        have hhb : height b + 1 ≤ height (Expr.bin op a b) := height_child (j := 1) rfl
        have hpa : base + valSize va ≤ pa := eval_peak_ge prog n base env tape a _ ha
        have hpb : base + valSize va + valSize vb ≤ pb :=
          eval_peak_ge prog n (base + valSize va) env ta b _ hb
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max (max pa pb) (base + valSize va + valSize vb + valSize v') :=
          (le_max_left _ _).trans (le_max_left _ _)
        have hm2 : pb ≤ max (max pa pb) (base + valSize va + valSize vb + valSize v') :=
          (le_max_right _ _).trans (le_max_left _ _)
        have hm3 : base + valSize va + valSize vb + valSize v' ≤
            max (max pa pb) (base + valSize va + valSize vb + valSize v') := le_max_right _ _
        have IHa := RunAll.push (ihE base env tape a va ca pa ta (q.child 0)
          (Frame.binL q env :: K) ha hqa)
          (B' := simBound prog (height (Expr.bin op a b)) env
            (max (max pa pb) (base + valSize va + valSize vb + valSize v') - base)) (by
            rw [frameBits_binL]
            exact simBound_push_env env hha (by omega) (by unfold frameC; omega))
        have IHb := RunAll.push (ihE (base + valSize va) env ta b vb cb pb tb (q.child 1)
          (Frame.binR q va :: K) hb hqb)
          (B' := simBound prog (height (Expr.bin op a b)) env
            (max (max pa pb) (base + valSize va + valSize vb + valSize v') - base)) (by
            rw [frameBits_binR]
            have := bitEncodeVal_length_le va
            exact simBound_push_val (s := valSize va) env hhb (by omega)
              (by unfold frameC; omega))
        exact (((RunAll.cons_step (step_eval_bin hq) (start_within hq env K tape _ _) IHa).snoc_step
          step_ret_binL IHb.first).trans IHb).snoc_step (step_ret_binR hq hv)
          (ret_within (by omega) K tb _ env)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v', c', ha, hv, hr⟩ := (eval_un_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.un op a) := height_child (j := 0) rfl
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa (base + valSize va + valSize v') := le_max_left _ _
        have hm2 : base + valSize va + valSize v' ≤ max pa (base + valSize va + valSize v') :=
          le_max_right _ _
        have IHa := RunAll.push (ihE base env tape a va ca pa ta (q.child 0) (Frame.un q :: K) ha hqa)
          (B' := simBound prog (height (Expr.un op a)) env
            (max pa (base + valSize va + valSize v') - base)) (by
            rw [frameBits_un]
            exact simBound_push_env env hha (by omega) (by unfold frameC; omega))
        exact (RunAll.cons_step (step_eval_un hq) (start_within hq env K tape _ _) IHa).snoc_step
          (step_ret_un hq hv) (ret_within (by omega) K ta _ env)
      | ite cnd tb fb =>
        obtain ⟨z, cc, pc, tc, v', cv, pv, tv, hc, hbr, hr⟩ := (eval_ite_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqc : exprAt prog (q.child 0) = some cnd := exprAt_child hq rfl
        have hqbr : exprAt prog (q.child (if z ≠ 0 then 1 else 2)) =
            some (if z ≠ 0 then tb else fb) := by
          split_ifs
          · exact exprAt_child hq rfl
          · exact exprAt_child hq rfl
        have hhc : height cnd + 1 ≤ height (Expr.ite cnd tb fb) := height_child (j := 0) rfl
        have hhbr : height (if z ≠ 0 then tb else fb) + 1 ≤ height (Expr.ite cnd tb fb) := by
          split_ifs
          · exact height_child (j := 1) rfl
          · exact height_child (j := 2) rfl
        have hpos := encodePos_le hq
        have IHc := RunAll.push (ihE base env tape cnd (Val.int z) cc pc tc (q.child 0)
          (Frame.ite q env :: K) hc hqc)
          (B' := simBound prog (height (Expr.ite cnd tb fb)) env (max pc pv - base)) (by
            rw [frameBits_ite]
            exact simBound_push_env env hhc (by omega) (by unfold frameC; omega))
        have IHbr := RunAll.weaken (ihE base env tc _ v' cv pv tv _ K hbr hqbr)
          (B' := simBound prog (height (Expr.ite cnd tb fb)) env (max pc pv - base))
          (simBound_mono env (by omega) (by omega))
        exact ((RunAll.cons_step (step_eval_ite hq) (start_within hq env K tape _ _) IHc).snoc_step
          step_ret_ite IHbr.first).trans IHbr
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, hr⟩ := (eval_letE_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hqb : exprAt prog (q.child 1) = some b := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.letE a b) := height_child (j := 0) rfl
        have hhb : height b + 1 ≤ height (Expr.letE a b) := height_child (j := 1) rfl
        have hDb : height b ≤ progDepth prog := by have := exprAt_bound hqb; omega
        have hpb : base + valSize va + valSize vb ≤ pb :=
          eval_peak_ge prog n (base + valSize va) (va :: env) ta b _ hb
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa pb := le_max_left _ _
        have hm2 : pb ≤ max pa pb := le_max_right _ _
        have IHa := RunAll.push (ihE base env tape a va ca pa ta (q.child 0)
          (Frame.letE q env :: K) ha hqa)
          (B' := simBound prog (height (Expr.letE a b)) env (max pa pb - base)) (by
            rw [frameBits_letE]
            exact simBound_push_env env hha (by omega) (by unfold frameC; omega))
        have IHb := RunAll.weaken (ihE (base + valSize va) (va :: env) ta b vb cb pb tb (q.child 1)
          K hb hqb)
          (B' := simBound prog (height (Expr.letE a b)) env (max pa pb - base))
          (simBound_letE env hhb hDb (by omega))
        exact ((RunAll.cons_step (step_eval_letE hq) (start_within hq env K tape _ _) IHa).snoc_step
          step_ret_letE IHb.first).trans IHb
      | call i a =>
        obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, hr⟩ :=
          (eval_call_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hroot : exprAt prog ⟨i, []⟩ = some body := exprAt_root hbody
        have hha : height a + 1 ≤ height (Expr.call i a) := height_child (j := 0) rfl
        have hDbody : height body ≤ progDepth prog := height_le_progDepth hbody
        have hpb : base + valSize va + valSize vb ≤ pb :=
          eval_peak_ge prog n (base + valSize va) [va] ta body _ hb
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa pb := le_max_left _ _
        have hm2 : pb ≤ max pa pb := le_max_right _ _
        have IHa := RunAll.push (ihE base env tape a va ca pa ta (q.child 0)
          (Frame.callArg q :: K) ha hqa)
          (B' := simBound prog (height (Expr.call i a)) env (max pa pb - base)) (by
            rw [frameBits_callArg]
            exact simBound_push_env env hha (by omega) (by unfold frameC; omega))
        have IHb := RunAll.weaken (ihE (base + valSize va) [va] ta body vb cb pb tb ⟨i, []⟩ K hb hroot)
          (B' := simBound prog (height (Expr.call i a)) env (max pa pb - base)) (by
            refine (simBound_body hDbody).trans ?_
            have h1 : bitsFactor prog * (pb - (base + valSize va) + valSize va) ≤
                bitsFactor prog * (max pa pb - base) := Nat.mul_le_mul_left _ (by omega)
            unfold simBound
            omega)
        exact ((RunAll.cons_step (step_eval_call hq) (start_within hq env K tape _ _) IHa).snoc_step
          (step_ret_callArg hq) IHb.first).trans IHb
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, hr⟩ := (eval_loop_iff prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.loop i a) := height_child (j := 0) rfl
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa pw := le_max_left _ _
        have hm2 : pw ≤ max pa pw := le_max_right _ _
        have IHa := RunAll.push (ihE base env tape a va ca pa ta (q.child 0)
          (Frame.loopInit q :: K) ha hqa)
          (B' := simBound prog (height (Expr.loop i a)) env (max pa pw - base)) (by
            rw [frameBits_loopInit]
            exact simBound_push_env env hha (by omega) (by unfold frameC; omega))
        have IHl := RunAll.weaken (ihL base i va ta w cw pw tw q a K hl hq)
          (B' := simBound prog (height (Expr.loop i a)) env (max pa pw - base)) (by
            have h1 : bitsFactor prog * (pw - base) ≤ bitsFactor prog * (max pa pw - base) :=
              Nat.mul_le_mul_left _ (by omega)
            have h2 : frameC prog ≤ (height (Expr.loop i a) + 1) *
                ((bitEncodeVals env).length + frameC prog) :=
              (Nat.le_add_left _ _).trans (Nat.le_mul_of_pos_left _ (by omega))
            unfold simBound
            omega)
        exact ((RunAll.cons_step (step_eval_loop hq) (start_within hq env K tape _ _) IHa).snoc_step
          (step_ret_loopInit hq) IHl.first).trans IHl
    · intro base i v tape w cw pw tw q a K hl hq
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hcase⟩ := (loopRun_succ_iff prog).1 hl
      have hroot : exprAt prog ⟨i, []⟩ = some body := exprAt_root hbody
      have hDbody : height body ≤ progDepth prog := height_le_progDepth hbody
      have hpb : base + valSize v + valSize (Val.list [Val.int flag, v']) ≤ pb :=
        eval_peak_ge prog n (base + valSize v) [v] tape body _ hb
      have hpair : valSize v' + 3 ≤ valSize (Val.list [Val.int flag, v']) := by
        simp only [valSize, listSize]; omega
      have hpos := encodePos_le hq
      -- the body runs under the `loopIter` frame
      have IHb := RunAll.push (ihE (base + valSize v) [v] tape body _ cb pb tb ⟨i, []⟩
        (Frame.loopIter q :: K) hb hroot)
        (B' := frameC prog + bitsFactor prog * (pb - base)) (by
          refine (Nat.add_le_add_right (simBound_body hDbody) _).trans ?_
          rw [frameBits_loopIter]
          have h1 : bitsFactor prog * (pb - (base + valSize v) + valSize v) ≤
              bitsFactor prog * (pb - base) := Nat.mul_le_mul_left _ (by omega)
          unfold frameC
          omega)
      rcases hcase with ⟨rfl, hr⟩ | ⟨hflag, w', cw', pw', tw', hl', hr⟩
      · simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, h3, h4⟩ := hr
        subst w pw tw
        refine IHb.snoc_step (step_ret_loopIter_stop hq) (Within.top ?_)
        rw [encodeCtrl_ret_length]
        have h1 := bitEncodeVal_length_le v'
        have h2 := valSize_pos v'
        have h3 := five_le_bitsFactor prog
        have h4 : 4 * valSize v' ≤ bitsFactor prog * (pb - base) :=
          Nat.mul_le_mul (by omega) (by omega)
        omega
      · simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst w tw
        have IHl := RunAll.weaken (ihL base i v' tb w' cw' pw' tw' q a K hl' hq)
          (B' := frameC prog + bitsFactor prog * (max pb pw' - base)) (by
            have := Nat.mul_le_mul_left (bitsFactor prog)
              (show pw' - base ≤ max pb pw' - base by omega)
            omega)
        have IHb' := RunAll.weaken IHb
          (B' := frameC prog + bitsFactor prog * (max pb pw' - base)) (by
            have := Nat.mul_le_mul_left (bitsFactor prog)
              (show pb - base ≤ max pb pw' - base by omega)
            omega)
        exact (IHb'.snoc_step (step_ret_loopIter_cont hq hflag) IHl.first).trans IHl

end F2e2e.Machine
