import F2e2e.Spec

/-!
# Runs of the small-step machine

The machine (`Conf`, `step`, `stepN`, `initConf`, `confBits`, ...) is the one of Spec v2.1 (`F2e2e/Spec.lean`).

* `stepN_add`: `m + n` steps are `m` steps then `n` steps.
* `RunAll prog P c c'`: the machine goes from `c` to `c'` and every configuration of the run (both
  ends included) satisfies `P`; composition (`trans`, `cons_step`, `snoc_step`), `single`, `mono`,
  `first`, `last`.
-/

namespace F2e2e.Machine

variable {prog : List Expr}

theorem stepN_zero (c : Conf) : stepN prog 0 c = some c := rfl

theorem stepN_add (m n : ℕ) (c : Conf) :
    stepN prog (m + n) c = (stepN prog m c).bind (stepN prog n) := by
  induction m generalizing c with
  | zero => simp [stepN]
  | succ m ih =>
    rw [show m + 1 + n = (m + n) + 1 by omega]
    simp only [stepN]
    cases step prog c with
    | none => rfl
    | some c' => exact ih c'

theorem stepN_one {c c' : Conf} (h : step prog c = some c') : stepN prog 1 c = some c' := by
  simp [stepN, h]

/-- The machine goes from `c` to `c'`, and every configuration of the run (both ends included)
satisfies `P`. -/
def RunAll (prog : List Expr) (P : Conf → Prop) (c c' : Conf) : Prop :=
  ∃ n, stepN prog n c = some c' ∧ ∀ k ≤ n, ∀ d, stepN prog k c = some d → P d

namespace RunAll

variable {P Q : Conf → Prop} {c c' c'' : Conf}

theorem refl (h : P c) : RunAll prog P c c :=
  ⟨0, rfl, fun k hk d hd => by
    obtain rfl : k = 0 := by omega
    simp only [stepN, Option.some.injEq] at hd
    exact hd ▸ h⟩

theorem first (h : RunAll prog P c c') : P c := by
  obtain ⟨n, _, hall⟩ := h
  exact hall 0 (Nat.zero_le _) c rfl

theorem last (h : RunAll prog P c c') : P c' := by
  obtain ⟨n, hn, hall⟩ := h
  exact hall n le_rfl c' hn

theorem steps (h : RunAll prog P c c') : ∃ n, stepN prog n c = some c' := by
  obtain ⟨n, hn, _⟩ := h
  exact ⟨n, hn⟩

theorem trans (h₁ : RunAll prog P c c') (h₂ : RunAll prog P c' c'') : RunAll prog P c c'' := by
  obtain ⟨n₁, hn₁, hall₁⟩ := h₁
  obtain ⟨n₂, hn₂, hall₂⟩ := h₂
  refine ⟨n₁ + n₂, by rw [stepN_add, hn₁]; exact hn₂, fun k hk d hd => ?_⟩
  by_cases hk1 : k ≤ n₁
  · exact hall₁ k hk1 d hd
  · obtain ⟨j, rfl⟩ : ∃ j, k = n₁ + j := ⟨k - n₁, by omega⟩
    rw [stepN_add, hn₁] at hd
    exact hall₂ j (by omega) d hd

theorem single (hs : step prog c = some c') (hc : P c) (hc' : P c') : RunAll prog P c c' :=
  ⟨1, stepN_one hs, fun k hk d hd => by
    interval_cases k
    · simp only [stepN, Option.some.injEq] at hd
      exact hd ▸ hc
    · rw [stepN_one hs, Option.some.injEq] at hd
      exact hd ▸ hc'⟩

theorem cons_step (hs : step prog c = some c') (hc : P c) (h : RunAll prog P c' c'') :
    RunAll prog P c c'' :=
  (single hs hc h.first).trans h

theorem snoc_step (h : RunAll prog P c c') (hs : step prog c' = some c'') (hc'' : P c'') :
    RunAll prog P c c'' :=
  h.trans (single hs h.last hc'')

theorem mono (h : RunAll prog P c c') (hPQ : ∀ d, P d → Q d) : RunAll prog Q c c' := by
  obtain ⟨n, hn, hall⟩ := h
  exact ⟨n, hn, fun k hk d hd => hPQ d (hall k hk d hd)⟩

end RunAll

end F2e2e.Machine
