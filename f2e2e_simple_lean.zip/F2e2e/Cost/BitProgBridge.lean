import F2e2e.Cost.Generic
import F2e2e.Lib.Discrete.BitProg

/-!
# Bridge between bit programs (`F2e2e.Discrete.BitProg`) and DSL code (package L)

C-ALG writes every randomized step as a `BitProg` (free monad over "read one fresh bit"; `run`
consumes bits from the head of the tape and returns the unread rest). A DSL target *implements* a
bit program when it consumes exactly the bits the program reads and returns the encoded output:

`Implements prog M env e enc p := ∀ bits a, p.run bits = some (a, []) → EvalsVal prog M env bits (.inl e) (enc a)`.

Exact-bits facts about `BitProg.run` (`bitProg_run_prefix` (the prefix lemma),
`bitProg_run_split`, `bitProg_run_exact_append`, `bitProg_run_bind_exact`,
`bitProg_run_readBit_exact`, `bitProg_run_pure_exact`, `bitProg_run_map_exact`) make
`Implements` compositional:
* `Implements.coin` : `Expr.coin` implements `readBit` (encoding `encB`);
* `Implements.of_det` : a deterministic evaluation implements `pure a`;
* `Implements.letE` : `letE ea eb` implements `p.bind f` when `ea` implements `p` and `eb`
  (with the encoded output of `p` pushed on the environment) implements every `f a`;
* `Implements.mono_M`, `Implements.congr`;
* `Implements.eval_entry` / `Implements.runsOn`: with a rank certificate (GST), a run
  `p.run tape = some (a, rest)` of the entry program on any tape gives a DSL run on `tape` leaving
  exactly `rest`, output `enc a`, peak `≤ ((r 0 + 1)(K + 3) + 1) M`.
-/

namespace F2e2e.Cost

open F2e2e.Discrete

/-! ## Exact-bits facts about `BitProg.run` -/

section BitProgFacts

variable {α β : Type}

/-- **Prefix lemma.** A run on `pre ++ r` leaving `r` is a run on `pre` leaving `[]`. -/
theorem bitProg_run_prefix {p : BitProg α} {pre r : List Bool} {a : α}
    (h : p.run (pre ++ r) = some (a, r)) : p.run pre = some (a, []) := by
  induction p generalizing pre with
  | pure a' =>
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨rfl, h2⟩ := h
    have : pre = [] := by
      have := congrArg List.length h2
      simp only [List.length_append] at this
      exact List.eq_nil_of_length_eq_zero (by omega)
    subst this
    rfl
  | bit k ih =>
    cases pre with
    | nil =>
      exfalso
      cases r with
      | nil => simp at h
      | cons b r' =>
        simp only [List.nil_append, BitProg.run_bit_cons] at h
        obtain ⟨pre', hpre', -⟩ := BitProg.run_eq_some_suffix h
        have := congrArg List.length hpre'
        simp only [List.length_append, List.length_cons] at this
        omega
    | cons b pre' =>
      simp only [List.cons_append, BitProg.run_bit_cons] at h ⊢
      exact ih b h

/-- A run on any tape splits it into the exactly consumed bits and the unread rest. -/
theorem bitProg_run_split {p : BitProg α} {tape rest : List Bool} {a : α}
    (h : p.run tape = some (a, rest)) : ∃ bits, tape = bits ++ rest ∧ p.run bits = some (a, []) := by
  obtain ⟨pre, hpre, -⟩ := BitProg.run_eq_some_suffix h
  subst hpre
  exact ⟨pre, rfl, bitProg_run_prefix h⟩

/-- A run consuming exactly `bits` runs on every tape `bits ++ rest`, leaving `rest`. -/
theorem bitProg_run_exact_append {p : BitProg α} {bits : List Bool} {a : α}
    (h : p.run bits = some (a, [])) (rest : List Bool) : p.run (bits ++ rest) = some (a, rest) := by
  have := BitProg.run_append h rest
  simpa using this

/-- Exact runs of `p.bind f` split into exact runs of `p` and of `f a`. -/
theorem bitProg_run_bind_exact {p : BitProg α} {f : α → BitProg β} {bits : List Bool} {c : β} :
    (p.bind f).run bits = some (c, []) ↔
      ∃ b₁ b₂ a, bits = b₁ ++ b₂ ∧ p.run b₁ = some (a, []) ∧ (f a).run b₂ = some (c, []) := by
  constructor
  · intro h
    rw [BitProg.run_bind] at h
    obtain ⟨⟨a, r⟩, h1, h2⟩ := Option.bind_eq_some_iff.mp h
    obtain ⟨b₁, hb, h1'⟩ := bitProg_run_split h1
    exact ⟨b₁, r, a, hb, h1', h2⟩
  · rintro ⟨b₁, b₂, a, rfl, h1, h2⟩
    rw [BitProg.run_bind, bitProg_run_exact_append h1 b₂]
    exact h2

theorem bitProg_run_readBit_exact {bits : List Bool} {b : Bool} :
    BitProg.readBit.run bits = some (b, []) ↔ bits = [b] := by
  constructor
  · intro h
    cases bits with
    | nil => simp [BitProg.readBit] at h
    | cons b' t =>
      simp only [BitProg.readBit, BitProg.run_bit_cons, BitProg.run_pure, Option.some.injEq,
        Prod.mk.injEq] at h
      obtain ⟨rfl, rfl⟩ := h
      rfl
  · rintro rfl
    rfl

theorem bitProg_run_pure_exact {bits : List Bool} {a a' : α} :
    (BitProg.pure a).run bits = some (a', []) ↔ bits = [] ∧ a' = a := by
  simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq]
  constructor
  · rintro ⟨rfl, rfl⟩
    exact ⟨rfl, rfl⟩
  · rintro ⟨rfl, rfl⟩
    exact ⟨rfl, rfl⟩

theorem bitProg_run_map_exact {p : BitProg α} {f : α → β} {bits : List Bool} {c : β} :
    (p.map f).run bits = some (c, []) ↔ ∃ a, p.run bits = some (a, []) ∧ c = f a := by
  rw [BitProg.run_map]
  constructor
  · intro h
    obtain ⟨⟨a, r⟩, h1, h2⟩ := Option.map_eq_some_iff.mp h
    simp only [Prod.mk.injEq] at h2
    obtain ⟨rfl, rfl⟩ := h2
    exact ⟨a, h1, rfl⟩
  · rintro ⟨a, h1, rfl⟩
    rw [h1]
    rfl

/-- The Monad instance's `bind` is `BitProg.bind`. -/
theorem bitProg_bind_eq (p : BitProg α) (f : α → BitProg β) : (p >>= f) = p.bind f := rfl

/-- The Monad instance's `pure` is `BitProg.pure`. -/
theorem bitProg_pure_eq (a : α) : (Pure.pure a : BitProg α) = BitProg.pure a := rfl

end BitProgFacts

/-! ## `Implements` -/

/-- The DSL expression `e` (in the environment `env`) implements the bit program `p` with the
encoding `enc`: whenever `p` reads exactly `bits` and returns `a`, the evaluation of `e` consumes
exactly `bits` and returns `enc a` (all primitive results `≤ M`). -/
def Implements {α : Type} (prog : List Expr) (M : ℕ) (env : List Val) (e : Expr) (enc : α → Val)
    (p : BitProg α) : Prop :=
  ∀ bits a, p.run bits = some (a, []) → EvalsVal prog M env bits (.inl e) (enc a)

namespace Implements

variable {prog : List Expr} {M : ℕ} {env : List Val} {α β : Type}

theorem mono_M {M' : ℕ} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : Implements prog M env e enc p) (hM : M ≤ M') : Implements prog M' env e enc p :=
  fun bits a hp => (h bits a hp).mono_M hM

/-- `Expr.coin` implements `readBit` with the encoding `encB` (values `1`/`0`, size `≤ 2`). -/
theorem coin (hM : 2 ≤ M) : Implements prog M env Expr.coin encB BitProg.readBit := by
  intro bits b hp
  rw [bitProg_run_readBit_exact.mp hp]
  exact EvalsVal.coin b ((valSize_encB_le b).trans hM)

/-- A deterministic evaluation implements `pure a`. -/
theorem of_det {e : Expr} {enc : α → Val} {a : α}
    (h : EvalsVal prog M env [] (.inl e) (enc a)) : Implements prog M env e enc (BitProg.pure a) := by
  intro bits a' hp
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp hp
  exact h

/-- **Sequential composition.** `letE ea eb` implements `p.bind f` when `ea` implements `p` and
`eb`, with the encoded output of `p` pushed on the environment, implements every `f a`. -/
theorem letE {ea eb : Expr} {encA : α → Val} {encC : β → Val} {p : BitProg α}
    {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ a, Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf a b₂ c h2)

/-- Rewriting the implemented program or the encoding. -/
theorem congr {e : Expr} {enc enc' : α → Val} {p p' : BitProg α}
    (h : Implements prog M env e enc p) (hp : p = p') (henc : ∀ a, enc a = enc' a) :
    Implements prog M env e enc' p' := by
  subst hp
  intro bits a hr
  rw [← henc a]
  exact h bits a hr

/-- **Entry point (GST).** If the entry body implements `p` on the input `input` (of size
`≤ M`) and the program has a rank certificate, then every run `p.run tape = some (a, rest)` gives
a DSL run on `tape` leaving exactly `rest`, with output `enc a` and peak
`≤ ((r 0 + 1)(K + 3) + 1) M`. -/
theorem eval_entry {r : ℕ → ℕ} {K : ℕ} (hR : RankOK prog r K) {body : Expr}
    (h0 : prog[0]? = some body) {input : Val} {enc : α → Val} {p : BitProg α}
    (h : Implements prog M [input] body enc p) (hin : valSize input ≤ M) {tape rest : List Bool}
    {a : α} (hrun : p.run tape = some (a, rest)) :
    ∃ fuel c pk, pk ≤ ((r 0 + 1) * (K + 3) + 1) * M ∧
      eval prog fuel (valSize input) [input] tape body = some (enc a, c, pk, rest) := by
  obtain ⟨bits, rfl, hb⟩ := bitProg_run_split hrun
  obtain ⟨fuel, c, pk, hpk, hf⟩ := (h bits a hb).eval_entry hR h0 hin
  exact ⟨fuel, c, pk, hpk, hf rest⟩

/-- **Entry point (GST), `RunsOn` form.** -/
theorem runsOn {r : ℕ → ℕ} {K : ℕ} (hR : RankOK prog r K) {body : Expr}
    (h0 : prog[0]? = some body) {input : Val} {enc : α → Val} {p : BitProg α}
    (h : Implements prog M [input] body enc p) (hin : valSize input ≤ M) {tape rest : List Bool}
    {a : α} (hrun : p.run tape = some (a, rest)) {Sb : ℝ}
    (hS : ((((r 0 + 1) * (K + 3) + 1) * M : ℕ) : ℝ) ≤ Sb) :
    RunsOn prog input tape (enc a) Sb := by
  obtain ⟨fuel, c, pk, hpk, hf⟩ := h.eval_entry hR h0 hin hrun
  exact ⟨body, fuel, c, pk, rest, h0, hf, le_trans (by exact_mod_cast hpk) hS⟩

end Implements

end F2e2e.Cost
