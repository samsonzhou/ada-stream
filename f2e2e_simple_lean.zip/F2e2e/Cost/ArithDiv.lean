import F2e2e.Cost.ArithCore

/-!
# U1: restoring long division and the Euclidean sign fix-up

Owner: c186bcb5 (split with 17fc0802, who owns `ArithCore`/`ArithWork`). Lemmas about the
division algorithms of the Spec v2.1 block (§3.2 of `F2e2e/Spec.lean`): `divTrace` (restoring long
division, most significant dividend bit first, trimmed remainder, quotient bits appended) and `divSM`
(sign-magnitude division with `Int.ediv`/`Int.emod` signs), as decoded by `arithRun`.

* (D1) `divTrace_mag`: on the magnitudes, the quotient register (reversed) and the remainder register
  are `x / y` and `x % y` (`0 < y`); loop invariant `divTrace_spec`.
* (D2) `arithRun_div`, `arithRun_mod`: `arithRun` computes `a / b` and `a % b` (`b ≠ 0`), the semantics
  of `evalBin`'s `div` and `mod`; core `divSM_spec`.
* Auxiliary: `divTrace_len` (register lengths along `divTrace`, and the remainder register stays trimmed),
  `addTrace_trace`, `addTrace_inc`. The (D3) state bounds `divTrace_states`/`divSM_states` are in
  `ArithBounds` (17fc0802).
-/

namespace F2e2e.Machine

/-! ## Trimmed registers -/

/-- A trimmed register of value `< 2^k` has at most `k` bits. -/
theorem trimBits_length_le_of_lt {m : List Bool} {k : ℕ} (h : regVal (trimBits m) < 2 ^ k) :
    (trimBits m).length ≤ k := by
  by_cases hD : m.reverse.dropWhile (fun b => !b) = []
  · have : trimBits m = [] := by unfold trimBits; rw [hD]; rfl
    rw [this]; exact Nat.zero_le _
  · obtain ⟨c, D', hcD⟩ := List.exists_cons_of_ne_nil hD
    have h1 := List.head?_dropWhile_not (fun b => !b) m.reverse
    rw [hcD] at h1
    have hc : c = true := by simpa using h1
    subst hc
    have ht : trimBits m = D'.reverse ++ [true] := by
      unfold trimBits; rw [hcD, List.reverse_cons]
    rw [ht] at h ⊢
    rw [regVal_append, regVal_singleton, List.length_reverse] at h
    simp only [Bool.toNat_true, mul_one] at h
    rw [List.length_append, List.length_reverse, List.length_singleton]
    have h2 : 2 ^ D'.length < 2 ^ k := by omega
    have := (Nat.pow_lt_pow_iff_right (by norm_num : (1 : ℕ) < 2)).mp h2
    omega

theorem trimBits_nil : trimBits [] = [] := rfl

/-- A trimmed register is empty iff its value is `0`. -/
theorem trimBits_eq_nil_iff (m : List Bool) : trimBits m = [] ↔ regVal m = 0 := by
  constructor
  · intro h
    rw [← regVal_trimBits, h]; rfl
  · intro h
    have h0 := trimBits_length_le_of_lt (k := 0) (m := m) (by rw [regVal_trimBits, h]; norm_num)
    exact List.eq_nil_of_length_eq_zero (by omega)

/-! ## The trace of the adder -/

/-- Every state of the adder's trace has four registers, each of length at most
`max (max |x| |y|) (|acc| + n) + 1`. -/
theorem addTrace_trace (inv : Bool) : ∀ (n : ℕ) (x y : List Bool) (k : Bool) (acc : List Bool),
    ∀ s ∈ (addTrace inv n x y k acc).2.2, s.length = 4 ∧
      ∀ reg ∈ s, reg.length ≤ max (max x.length y.length) (acc.length + n) + 1 := by
  intro n
  induction n with
  | zero =>
    intro x y k acc s hs
    simp only [addTrace, List.mem_singleton] at hs
    subst hs
    refine ⟨rfl, fun reg hreg => ?_⟩
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hreg
    rcases hreg with rfl | rfl | rfl | rfl <;> simp <;> omega
  | succ n ih =>
    intro x y k acc s hs
    simp only [addTrace, List.mem_cons] at hs
    rcases hs with rfl | hs
    · refine ⟨rfl, fun reg hreg => ?_⟩
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hreg
      rcases hreg with rfl | rfl | rfl | rfl <;> simp <;> omega
    · obtain ⟨h1, h2⟩ := ih _ _ _ _ s hs
      refine ⟨h1, fun reg hreg => ?_⟩
      have := h2 reg hreg
      simp only [List.length_tail, List.length_append, List.length_singleton] at this
      omega

/-! ## The loop of `divTrace` -/

theorem divTrace_nil (y r q : List Bool) : divTrace y [] r q = (q, r, [[y, [], r, q]]) := rfl

theorem divTrace_cons_fst (y : List Bool) (d : Bool) (ds r q : List Bool) :
    (divTrace y (d :: ds) r q).1 =
      (divTrace y ds
        (if (addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1 then
          trimBits (addTrace true (max (d :: r).length y.length) (d :: r) y true []).1
        else trimBits (d :: r))
        (q ++ [(addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1])).1 := rfl

theorem divTrace_cons_snd (y : List Bool) (d : Bool) (ds r q : List Bool) :
    (divTrace y (d :: ds) r q).2.1 =
      (divTrace y ds
        (if (addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1 then
          trimBits (addTrace true (max (d :: r).length y.length) (d :: r) y true []).1
        else trimBits (d :: r))
        (q ++ [(addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1])).2.1 := rfl

theorem divTrace_cons_trace (y : List Bool) (d : Bool) (ds r q : List Bool) :
    (divTrace y (d :: ds) r q).2.2 =
      ([y, d :: ds, r, q] ::
          (addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.2.map
            (· ++ [y, ds, d :: r, q])) ++
        (divTrace y ds
          (if (addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1 then
            trimBits (addTrace true (max (d :: r).length y.length) (d :: r) y true []).1
          else trimBits (d :: r))
          (q ++ [(addTrace true (max (d :: r).length y.length) (d :: r) y true []).2.1])).2.2 := rfl

theorem regVal_reverse_cons (b : Bool) (bs : List Bool) :
    regVal (b :: bs).reverse = regVal bs.reverse + 2 ^ bs.length * b.toNat := by
  rw [List.reverse_cons, regVal_append, regVal_singleton, List.length_reverse]

theorem regVal_reverse_append_singleton (q : List Bool) (b : Bool) :
    regVal (q ++ [b]).reverse = b.toNat + 2 * regVal q.reverse := by
  rw [List.reverse_append, List.reverse_singleton, List.singleton_append, regVal_cons]

/-- **Loop invariant of the restoring division** (values): processing the dividend bits `ds` (most
significant first) from the remainder `r < y` and the quotient bits `q` (most significant first) gives
`Q y + R = (q y + r) 2^|ds| + ds` with `R < y`. -/
theorem divTrace_spec (y : List Bool) :
    ∀ (ds r q : List Bool), regVal r < regVal y →
      regVal (divTrace y ds r q).1.reverse * regVal y + regVal (divTrace y ds r q).2.1 =
          (regVal q.reverse * regVal y + regVal r) * 2 ^ ds.length + regVal ds.reverse ∧
        regVal (divTrace y ds r q).2.1 < regVal y := by
  intro ds
  induction ds with
  | nil =>
    intro r q hlt
    rw [divTrace_nil]
    refine ⟨?_, hlt⟩
    simp
  | cons d ds ih =>
    intro r q hlt
    set n := max (d :: r).length y.length with hn
    set t := addTrace true n (d :: r) y true [] with ht
    obtain ⟨hge, hdiff⟩ := addTrace_sub (x := d :: r) (y := y) (n := n) (le_max_left _ _)
      (le_max_right _ _)
    rw [← ht] at hge hdiff
    have hX : regVal (d :: r) = d.toNat + 2 * regVal r := regVal_cons d r
    have hd : d.toNat ≤ 1 := Bool.toNat_le d
    set rn := (if t.2.1 then trimBits t.1 else trimBits (d :: r)) with hrn
    have hrnval : regVal rn + t.2.1.toNat * regVal y = regVal (d :: r) := by
      rw [hrn]
      by_cases hg : t.2.1 = true
      · have hle : regVal y ≤ regVal (d :: r) := by
          rw [hg] at hge; exact of_decide_eq_true hge.symm
        rw [if_pos hg, regVal_trimBits, hdiff hle, hg]
        simp only [Bool.toNat_true, one_mul]
        omega
      · have hg' : t.2.1 = false := by simpa using hg
        rw [if_neg hg, regVal_trimBits, hg']
        simp
    have hrnlt : regVal rn < regVal y := by
      by_cases hg : t.2.1 = true
      · have := hrnval; rw [hg] at this; simp only [Bool.toNat_true, one_mul] at this; omega
      · have hg' : t.2.1 = false := by simpa using hg
        have hlt' : ¬ (regVal y ≤ regVal (d :: r)) := by
          rw [hg'] at hge; exact of_decide_eq_false hge.symm
        have := hrnval; rw [hg'] at this
        simp only [Bool.toNat_false, zero_mul, add_zero] at this
        omega
    obtain ⟨h1, h2⟩ := ih rn (q ++ [t.2.1]) hrnlt
    rw [divTrace_cons_fst, divTrace_cons_snd]
    refine ⟨?_, h2⟩
    rw [h1, regVal_reverse_append_singleton, regVal_reverse_cons, List.length_cons, pow_succ]
    have e : (t.2.1.toNat + 2 * regVal q.reverse) * regVal y + regVal rn =
        2 * (regVal q.reverse * regVal y + regVal r) + d.toNat := by
      have := hrnval; rw [hX] at this; nlinarith
    rw [e]; ring

/-- **Lengths along `divTrace`**: the quotient grows by one bit per dividend bit, the remainder stays
within `|y| + |q|` bits, every state has at most `8` registers of length `≤ |y| + |q| + |ds| + 1`, and a
trimmed remainder stays trimmed. -/
theorem divTrace_len (y : List Bool) :
    ∀ (ds r q : List Bool), r.length ≤ y.length + q.length →
      (divTrace y ds r q).1.length = q.length + ds.length ∧
        (divTrace y ds r q).2.1.length ≤ y.length + q.length + ds.length ∧
        (∀ s ∈ (divTrace y ds r q).2.2, s.length ≤ 8 ∧
          ∀ reg ∈ s, reg.length ≤ y.length + q.length + ds.length + 1) ∧
        ((∃ m, r = trimBits m) → ∃ m, (divTrace y ds r q).2.1 = trimBits m) := by
  intro ds
  induction ds with
  | nil =>
    intro r q hr
    rw [divTrace_nil]
    refine ⟨by simp, by simpa using hr, fun s hs => ?_, fun h => h⟩
    simp only [List.mem_singleton] at hs
    subst hs
    refine ⟨by simp, fun reg hreg => ?_⟩
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hreg
    rcases hreg with rfl | rfl | rfl | rfl <;> simp <;> omega
  | cons d ds ih =>
    intro r q hr
    rw [divTrace_cons_fst, divTrace_cons_snd, divTrace_cons_trace]
    set n := max (d :: r).length y.length with hn
    set t := addTrace true n (d :: r) y true [] with ht
    set rn := (if t.2.1 then trimBits t.1 else trimBits (d :: r)) with hrn
    have htlen : t.1.length = n := by
      have := (addTrace_true_spec n (d :: r) y true []).1
      rw [← ht] at this; simpa using this
    have hrnlen : rn.length ≤ y.length + (q ++ [t.2.1]).length := by
      rw [hrn, List.length_append, List.length_singleton]
      split_ifs
      · have := length_trimBits_le t.1
        rw [htlen, hn] at this
        simp only [List.length_cons] at this
        omega
      · have := length_trimBits_le (d :: r)
        simp only [List.length_cons] at this
        omega
    obtain ⟨h1, h2, h3, h4⟩ := ih rn (q ++ [t.2.1]) hrnlen
    simp only [List.length_append, List.length_singleton] at h1 h2 h3
    have hn' : n ≤ y.length + q.length + 1 := by
      rw [hn]; simp only [List.length_cons]; omega
    have htrim : ∃ m, rn = trimBits m := by
      by_cases hg : t.2.1 = true
      · exact ⟨t.1, by rw [hrn, if_pos hg]⟩
      · exact ⟨d :: r, by rw [hrn, if_neg hg]⟩
    refine ⟨by rw [h1, List.length_cons]; omega, by rw [List.length_cons]; omega, fun s hs => ?_,
      fun _ => h4 htrim⟩
    simp only [List.cons_append, List.mem_cons, List.mem_append, List.mem_map] at hs
    rcases hs with rfl | ⟨s', hs', rfl⟩ | hs
    · refine ⟨by simp, fun reg hreg => ?_⟩
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hreg
      rcases hreg with rfl | rfl | rfl | rfl <;> simp <;> omega
    · obtain ⟨hs1, hs2⟩ := addTrace_trace true n (d :: r) y true [] s' hs'
      refine ⟨by simp [hs1], fun reg hreg => ?_⟩
      rw [List.mem_append] at hreg
      rcases hreg with hreg | hreg
      · have h5 := hs2 reg hreg
        have hmx : max (max (d :: r).length y.length) (([] : List Bool).length + n) = n := by
          rw [hn]; simp
        rw [hmx] at h5
        rw [List.length_cons]
        omega
      · simp only [List.mem_cons, List.not_mem_nil, or_false] at hreg
        rcases hreg with rfl | rfl | rfl | rfl <;> simp <;> omega
    · obtain ⟨hs1, hs2⟩ := h3 s hs
      refine ⟨hs1, fun reg hreg => ?_⟩
      have := hs2 reg hreg
      rw [List.length_cons]; omega

/-! ## (D1) The magnitudes -/

/-- **(D1)** Restoring division of the magnitudes: the quotient bits (most significant first, so
reversed) and the remainder are `x / y` and `x % y`. -/
theorem divTrace_mag (x y : List Bool) (hy : 0 < regVal y) :
    regVal (divTrace y x.reverse [] []).1.reverse = regVal x / regVal y ∧
      regVal (divTrace y x.reverse [] []).2.1 = regVal x % regVal y := by
  obtain ⟨h1, h2⟩ := divTrace_spec y x.reverse [] [] (by simpa using hy)
  simp only [List.reverse_nil, regVal_nil, zero_mul, add_zero, zero_add,
    List.reverse_reverse] at h1
  have key : regVal x / regVal y = regVal (divTrace y x.reverse [] []).1.reverse ∧
      regVal x % regVal y = regVal (divTrace y x.reverse [] []).2.1 :=
    (Nat.div_mod_unique hy).2 ⟨by rw [← h1]; ring, h2⟩
  exact ⟨key.1.symm, key.2.symm⟩

/-! ## (D2) Signed division -/

/-- The increment of `divSM`: `q + 1` by the adder with carry-in `1`. -/
theorem addTrace_inc (q : List Bool) :
    regVal (addTrace false (q.length + 1) q [] true []).1 = regVal q + 1 := by
  obtain ⟨hl, h2⟩ := addTrace_false_spec (q.length + 1) q [] true []
  simp only [List.length_nil, zero_add, pow_zero, regVal_nil, one_mul, Bool.toNat_true,
    List.take_nil] at hl h2
  rw [regVal_take_of_le (by omega)] at h2
  have hs := regVal_lt (addTrace false (q.length + 1) q [] true []).1
  rw [hl] at hs
  have hq := regVal_lt q
  have hp : 2 ^ (q.length + 1) = 2 * 2 ^ q.length := by rw [pow_succ]; ring
  cases hc : (addTrace false (q.length + 1) q [] true []).2.1
  · rw [hc] at h2; simp at h2; omega
  · rw [hc] at h2; simp at h2; omega

/-- **(D2), core**: for `b ≠ 0`, `divSM` on the signs and magnitudes of `a`, `b` returns the
quotient `a / b` and the remainder `a % b` (Lean's `Int` division, as `evalBin`). -/
theorem divSM_spec (a b : ℤ) (hb : b ≠ 0) :
    smVal (divSM (decide (a < 0)) (decide (b < 0)) (Nat.bits a.natAbs) (Nat.bits b.natAbs)).1.1
        (divSM (decide (a < 0)) (decide (b < 0)) (Nat.bits a.natAbs) (Nat.bits b.natAbs)).1.2 =
      a / b ∧
    smVal (divSM (decide (a < 0)) (decide (b < 0)) (Nat.bits a.natAbs) (Nat.bits b.natAbs)).2.1.1
        (divSM (decide (a < 0)) (decide (b < 0)) (Nat.bits a.natAbs) (Nat.bits b.natAbs)).2.1.2 =
      a % b := by
  set A := a.natAbs with hAdef
  set B := b.natAbs with hBdef
  have hB : 0 < B := Int.natAbs_pos.mpr hb
  have hyB : 0 < regVal (Nat.bits B) := by rw [regVal_bits]; exact hB
  set qr := divTrace (Nat.bits B) (Nat.bits A).reverse [] [] with hqr
  obtain ⟨hq0, hr0⟩ := divTrace_mag (Nat.bits A) (Nat.bits B) hyB
  rw [← hqr, regVal_bits, regVal_bits] at hq0 hr0
  obtain ⟨-, -, -, htrim⟩ := divTrace_len (Nat.bits B) (Nat.bits A).reverse [] [] (by simp)
  obtain ⟨m0, hm0⟩ := htrim ⟨[], rfl⟩
  rw [← hqr] at hm0
  have hRlt : A % B < B := Nat.mod_lt _ hB
  have hAeq : (A : ℤ) = (B : ℤ) * ((A / B : ℕ) : ℤ) + ((A % B : ℕ) : ℤ) := by
    have := Nat.div_add_mod A B
    exact_mod_cast this.symm
  have habs : |b| = (B : ℤ) := Int.abs_eq_natAbs b
  have haneg : a < 0 → a = -(A : ℤ) := fun h => by
    have := Int.ofNat_natAbs_of_nonpos h.le; rw [← hAdef] at this; linarith
  have hapos : ¬ a < 0 → a = (A : ℤ) := fun h => by
    have := Int.natAbs_of_nonneg (not_lt.mp h); rw [← hAdef] at this; linarith
  have hbneg : b < 0 → b = -(B : ℤ) := fun h => by
    have := Int.ofNat_natAbs_of_nonpos h.le; rw [← hBdef] at this; linarith
  have hbpos : ¬ b < 0 → b = (B : ℤ) := fun h => by
    have := Int.natAbs_of_nonneg (not_lt.mp h); rw [← hBdef] at this; linarith
  -- the remainder register is empty iff the remainder is `0`
  have hnil : qr.2.1 = [] ↔ A % B = 0 := by
    rw [hm0, trimBits_eq_nil_iff, ← regVal_trimBits, ← hm0, hr0]
  -- the remainder register is short
  have hrlen : qr.2.1.length ≤ (Nat.bits B).length := by
    rw [hm0]
    apply trimBits_length_le_of_lt
    rw [← hm0, hr0]
    have hBlt : B < 2 ^ (Nat.bits B).length := by
      have := regVal_lt (Nat.bits B); rwa [regVal_bits] at this
    exact lt_trans hRlt hBlt
  have htq : regVal (trimBits qr.1.reverse) = A / B := by rw [regVal_trimBits, hq0]
  unfold divSM
  rw [← hqr]
  by_cases hfix : decide (a < 0) = true ∧ qr.2.1 ≠ []
  · rw [if_pos hfix]
    have ha0 : a < 0 := of_decide_eq_true hfix.1
    have hR0 : A % B ≠ 0 := fun h0 => hfix.2 (hnil.2 h0)
    simp only [smVal, Bool.false_eq_true, if_false]
    rw [regVal_trimBits, addTrace_inc, htq, regVal_trimBits]
    obtain ⟨-, hdiff⟩ := addTrace_sub (x := Nat.bits B) (y := qr.2.1) (n := (Nat.bits B).length)
      le_rfl hrlen
    rw [hdiff (by rw [hr0, regVal_bits]; exact hRlt.le), hr0, regVal_bits]
    have hRpos : 0 < A % B := Nat.pos_of_ne_zero hR0
    refine And.imp Eq.symm Eq.symm ((Int.ediv_emod_unique'' hb).2 ⟨?_, ?_, ?_⟩)
    · by_cases hbn : b < 0
      · simp only [ha0, hbn, decide_true, Bool.true_xor, Bool.not_true, Bool.false_eq_true,
          if_false]
        rw [haneg ha0, hbneg hbn]
        push_cast [Nat.cast_sub hRlt.le] at hAeq ⊢
        linear_combination hAeq
      · simp only [ha0, hbn, decide_true, decide_false, Bool.true_xor, Bool.not_false, if_true]
        rw [haneg ha0, hbpos hbn]
        push_cast [Nat.cast_sub hRlt.le] at hAeq ⊢
        linear_combination hAeq
    · push_cast [Nat.cast_sub hRlt.le]; omega
    · rw [habs]; push_cast [Nat.cast_sub hRlt.le]; omega
  · rw [if_neg hfix]
    simp only [smVal, Bool.false_eq_true, if_false]
    rw [htq, hr0]
    have hcase : ¬ a < 0 ∨ A % B = 0 := by
      by_cases ha0 : a < 0
      · right
        by_contra h0
        exact hfix ⟨decide_eq_true ha0, fun hn => h0 (hnil.1 hn)⟩
      · left; exact ha0
    refine And.imp Eq.symm Eq.symm ((Int.ediv_emod_unique'' hb).2
      ⟨?_, Int.natCast_nonneg _, ?_⟩)
    · by_cases ha0 : a < 0
      · have hR0 : A % B = 0 := hcase.resolve_left (not_not.mpr ha0)
        rw [hR0] at hAeq ⊢
        push_cast at hAeq ⊢
        by_cases hbn : b < 0
        · simp only [ha0, hbn, decide_true, Bool.true_xor, Bool.not_true, Bool.false_eq_true,
            if_false]
          rw [haneg ha0, hbneg hbn]
          linear_combination hAeq
        · simp only [ha0, hbn, decide_true, decide_false, Bool.true_xor, Bool.not_false,
            if_true]
          rw [haneg ha0, hbpos hbn]
          linear_combination hAeq
      · by_cases hbn : b < 0
        · simp only [ha0, hbn, decide_true, decide_false, Bool.false_xor, if_true]
          rw [hapos ha0, hbneg hbn]
          linear_combination -hAeq
        · simp only [ha0, hbn, decide_false, Bool.false_xor, Bool.false_eq_true, if_false]
          rw [hapos ha0, hbpos hbn]
          linear_combination -hAeq
    · rw [habs]; exact_mod_cast hRlt

/-- **(D2)** `arithRun` computes `evalBin`'s `div`. -/
theorem arithRun_div (a b : ℤ) (hb : b ≠ 0) : (arithRun BinOp.div a b).1 = Val.int (a / b) := by
  have h := (divSM_spec a b hb).1
  simp only [smVal] at h
  simp only [arithRun, bitsNat_eq_regVal]
  rw [← h]

/-- **(D2)** `arithRun` computes `evalBin`'s `mod`. -/
theorem arithRun_mod (a b : ℤ) (hb : b ≠ 0) : (arithRun BinOp.mod a b).1 = Val.int (a % b) := by
  have h := (divSM_spec a b hb).2
  simp only [smVal] at h
  simp only [arithRun, bitsNat_eq_regVal]
  rw [← h]

end F2e2e.Machine
