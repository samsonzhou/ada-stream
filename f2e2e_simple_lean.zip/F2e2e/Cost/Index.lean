import Mathlib

/-!
# Global function indices of the f2e2e DSL library (program-assembly convention; from cut2)

A program is a list of function bodies `prog : List Expr`; `Expr.call i a` and `Expr.loop i a`
refer to functions by their index `i`. Every library function `X` has a fixed global index
constant `Idx.X : ℕ` and a body `body_X : Expr` (defined in the file of its area); its spec is
stated for *every* program `prog` with `prog[Idx.Y]? = some body_Y` for `X` and its (transitive)
callees, so that library files are independent. The final programs (`initProg`, `updProg` of the
streaming algorithm of Theorem (C)) are assembled once from a single lookup table
(`F2e2e/Cost/Assembly.lean`, `mkProg`), and these hypotheses are then discharged by `rfl`.

## Reserved ranges (one owner per range; add constants for your area in your own files)

| range     | area (owner)                                                        |
|-----------|---------------------------------------------------------------------|
| 0         | entry point of a program (`initMain`, `updMain`)                    |
| 1–89      | list basics and combinators (`F2e2e/Cost/Lib/*`, DSL-CALC)           |
| 90–99     | fresh-bit routines (`F2e2e/Cost/Lib/Coins.lean`, DSL-CALC)           |
| 100–149   | arithmetic, sorting / median, helpers (`F2e2e/Cost/Arith/*`, DSL-CALC) |
| 150–249   | W2: hash / GF(2^w) / fingerprint (port of cut2's HASH DSL)          |
| 250–399   | W6: tree controller, entry points (C-TOP)                           |
| 400–449   | W1: parameters                                                      |
| 450–549   | W2 overflow (spare)                                                 |
| 550–599   | W3: samplers, new banks                                             |
| 600–749   | W4: ADA                                                             |
| 750–899   | W5: bank operations                                                 |
| 900–999   | spare                                                               |

(Global map fixed with C-TOP in `F2e2e/C/Impl/W6Contracts.lean`. Generic combinators — `foldB`,
`mapB`, `mapIdx`, cut2's `map`/`fold` — take their step/element function indices as parameters;
each use allocates its own indices in the user's range.)

Inside a range, indices are allocated by the owner of the range; constants are `abbrev`s in the
namespace `F2e2e.Cost.Idx` (e.g. `F2e2e.Cost.Idx.length`), so that `prog[Idx.length]?` reduces by
`rfl`. This file defines the indices 1–14 of the list/integer basics; later allocations are
defined next to their bodies (same namespace):

| idx | constant | file | idx | constant | file |
|---|---|---|---|---|---|
| 1 | `length` | `Lib/Length` | 2 | `lengthStep` | `Lib/Length` |
| 3 | `revAppend` | `Lib/RevAppend` | 4 | `revAppendStep` | `Lib/RevAppend` |
| 5 | `reverse` | `Lib/RevAppend` | 6 | `append` | `Lib/RevAppend` |
| 7 | `sum` | `Lib/Sum` | 8 | `sumStep` | `Lib/Sum` |
| 9 | `get` | `Lib/Get` | 10 | `getStep` | `Lib/Get` |
| 11 | `set` | `Lib/Set` | 12 | `setStep` | `Lib/Set` |
| 13 | `zipWithAdd` | `Lib/ZipWithAdd` | 14 | `zipWithAddStep` | `Lib/ZipWithAdd` |
| 15 | `replicate` | `Lib/Replicate` | 16 | `replicateStep` | `Lib/Replicate` |
| 17 | `range` | `Lib/Replicate` | 18 | `rangeStep` | `Lib/Replicate` |
| 19 | `take` | `Lib/TakeDrop` | 20 | `drop` | `Lib/TakeDrop` |
| 21 | `linComb` | `Lib/LinComb` | 22 | `linCombStep` | `Lib/LinComb` |
| 23 | `countNZ` | `Lib/Count` | 24 | `countNZStep` | `Lib/Count` |
| 25 | `get2` | `Lib/Table` | 26 | `set2` | `Lib/Table` |
| 27 | `eqInts` | `Lib/Eq` | 28 | `eqIntsStep` | `Lib/Eq` |
| 29 | `memInts` | `Lib/Eq` | 30 | `memIntsStep` | `Lib/Eq` |
| 31 | `getOpt` | `Lib/GetOpt` | 32 | `getOptStep` | `Lib/GetOpt` |
| 90 | `readBits` | `Lib/Coins` | 91 | `readBitsStep` | `Lib/Coins` |
| 92 | `readNat` | `Lib/Coins` | 93 | `readNatStep` | `Lib/Coins` |
| 100–110 | `pow2` … `maxZ` | `Arith/Basic` | 112–117 | `insertZ` … `medWalkStep` | `Arith/Median` |
| 118 | `natSqrt` | `Arith/Helpers` | 119 | `natSqrtStep` | `Arith/Helpers` |
| 120 | `roundMantZ` | `Arith/Helpers` | 121 | `clampZ` | `Arith/Helpers` |
| 122 | `lowerMedZ` | `Arith/LowerMed` | 123 | `floorSqrtND` | `Arith/Helpers` |
| 124 | `ceilSqrtND` | `Arith/Helpers` | | | |

(`take`/`drop` reuse `setStep`; `reverse`/`append` reuse `revAppendStep`. The generic
combinators `map`/`fold` of `Lib/Map`, `Lib/Fold` use indices chosen by the caller.)
-/

namespace F2e2e.Cost.Idx

/-! ### List / integer basics (1–99) -/

/-- `length : list ↦ int`. -/
abbrev length : ℕ := 1
/-- Loop body of `length`. -/
abbrev lengthStep : ℕ := 2
/-- `revAppend : [a, b] ↦ reverse a ++ b`. -/
abbrev revAppend : ℕ := 3
/-- Loop body of `revAppend`. -/
abbrev revAppendStep : ℕ := 4
/-- `reverse : l ↦ reverse l`. -/
abbrev reverse : ℕ := 5
/-- `append : [a, b] ↦ a ++ b`. -/
abbrev append : ℕ := 6
/-- `sum : list of ints ↦ int`. -/
abbrev sum : ℕ := 7
/-- Loop body of `sum`. -/
abbrev sumStep : ℕ := 8
/-- `get : [l, n] ↦ l[n]` (default `0`). -/
abbrev get : ℕ := 9
/-- Loop body of `get`. -/
abbrev getStep : ℕ := 10
/-- `set : [l, n, x] ↦ l.set n x`. -/
abbrev set : ℕ := 11
/-- Loop body of `set`. -/
abbrev setStep : ℕ := 12
/-- `zipWithAdd : [a, b, d] ↦ zipWith (fun x y => x + d * y) a b`. -/
abbrev zipWithAdd : ℕ := 13
/-- Loop body of `zipWithAdd`. -/
abbrev zipWithAddStep : ℕ := 14

end F2e2e.Cost.Idx
