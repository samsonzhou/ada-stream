import F2e2e.B.ArchCore
import F2e2e.Lib.Opt.QuadraticRational

/-!
# Correctness of the computable exact learner weights `capWeightsQ`

Owner: LIB-OPT-QUAD. Paper (Part II, `parts/partII.tex`): Lemma `R:lem:sec3_kkt_sensitivity` (i) and (iii)
(L782-807, proofs L812, L838), Definition `R:def:sec3_capped_learners` (L737-748).

`F2e2e.B.capWeightsQ c g` (in `F2e2e/B/ArchCore.lean`) computes, for integer scores `g` and a rational step
`c` (the mechanism uses `c = κ h_A/4` and `g = 4G/h_A`, so `c g_i = κ G_i`), the water level `ν = wfLevel s`
of the shifted scores `s_i = 1 + c g_i` as the first candidate (breakpoints `s_i`, `s_i - 8` and the interpolated
levels `b + (Φ(b) - n)/k_b`) with `Φ(ν) = ∑_i clip_{[0,8]}(s_i - ν) = n`, and returns
`clip_{[0,8]}(s_i - ν)/n`.

Main results:
* `exists_wfCand`: some candidate always solves `Φ(ν) = n` (the largest breakpoint `b*` with `Φ(b*) ≥ n`; `Φ` is
  affine with slope `-k_{b*}` up to the next breakpoint, `wfMass_affine`);
* `wfMass_wfLevel`: `Φ(wfLevel s) = n` for nonempty `s`;
* `capWeightsQ_length`, `capWeightsQ_getD`;
* `capWeightsQ_spec`: `capWeightsQ c g` is exactly the learner weights
  `F2e2e.Opt.Quad.learnerWeights n 8 c g` (the unique maximizer of `κ⟨G, w⟩ - R(w)` over the `8/n`-capped simplex);
* `capWeightsQ_den`: every weight `x` satisfies `0 ≤ x ≤ 8/n` and `x.den ∣ k · n · c.den` for some
  `k ∈ [1, n]` (the active-set size, Lemma (iii)), hence `x.den ≤ n² · c.den` (no denominator growth across
  updates: the bound depends on the current scores only);
* `capWeightsQ_bits`: `x.den ≤ n² · c.den` and `|x.num| ≤ 8 · n · c.den` (bit-size per weight).
-/

namespace F2e2e.B

open F2e2e.Opt.Quad


open F2e2e.Opt.Quad

lemma clipQ_sub_anti (x : ℚ) {ν ν' : ℚ} (h : ν ≤ ν') : clipQ 0 8 (x - ν') ≤ clipQ 0 8 (x - ν) :=
  max_le_max le_rfl (min_le_min le_rfl (by linarith))

lemma wfMass_nil (ν : ℚ) : wfMass [] ν = 0 := by simp [wfMass]

lemma wfMass_cons (x : ℚ) (t : List ℚ) (ν : ℚ) :
    wfMass (x :: t) ν = clipQ 0 8 (x - ν) + wfMass t ν := by
  simp [wfMass]

lemma wfSlope_nil (b : ℚ) : wfSlope [] b = 0 := by simp [wfSlope]

lemma wfSlope_cons (x : ℚ) (t : List ℚ) (b : ℚ) :
    wfSlope (x :: t) b = (if x - 8 ≤ b ∧ b < x then 1 else 0) + wfSlope t b := by
  unfold wfSlope
  rw [List.filter_cons]
  by_cases h : x - 8 ≤ b ∧ b < x
  · rw [if_pos (decide_eq_true h), if_pos h, List.length_cons]
    omega
  · rw [if_neg (by rw [decide_eq_false h]; exact Bool.false_ne_true), if_neg h, zero_add]

/-- `Φ` is non-increasing. -/
lemma wfMass_antitone (s : List ℚ) {ν ν' : ℚ} (h : ν ≤ ν') : wfMass s ν' ≤ wfMass s ν := by
  induction s with
  | nil => simp [wfMass_nil]
  | cons x t ih =>
    rw [wfMass_cons, wfMass_cons]
    linarith [clipQ_sub_anti x h]

lemma wfMass_eq_of_forall (s : List ℚ) (ν a : ℚ) (h : ∀ x ∈ s, clipQ 0 8 (x - ν) = a) :
    wfMass s ν = s.length * a := by
  induction s with
  | nil => simp [wfMass_nil]
  | cons x t ih =>
    rw [wfMass_cons, h x (by simp), ih fun y hy => h y (by simp [hy])]
    push_cast [List.length_cons]
    ring

/-- One coordinate of `Φ` is affine between consecutive breakpoints. -/
lemma clipQ_affine {x b ν : ℚ} (hbν : b ≤ ν) (h1 : ¬(b < x ∧ x < ν)) (h2 : ¬(b < x - 8 ∧ x - 8 < ν)) :
    clipQ 0 8 (x - ν) = clipQ 0 8 (x - b) - (if x - 8 ≤ b ∧ b < x then ν - b else 0) := by
  unfold clipQ
  by_cases hx : x ≤ b
  · have hP : ¬(x - 8 ≤ b ∧ b < x) := fun h => absurd h.2 (not_lt.2 hx)
    rw [if_neg hP, sub_zero, min_eq_right (by linarith : x - ν ≤ 8),
      min_eq_right (by linarith : x - b ≤ 8), max_eq_left (by linarith : x - ν ≤ 0),
      max_eq_left (by linarith : x - b ≤ 0)]
  · have hx' : b < x := not_le.1 hx
    by_cases h8 : x - 8 ≤ b
    · rw [if_pos ⟨h8, hx'⟩]
      have hxν : ν ≤ x := by
        by_contra hc
        exact h1 ⟨hx', not_le.1 hc⟩
      rw [min_eq_right (by linarith : x - ν ≤ 8), min_eq_right (by linarith : x - b ≤ 8),
        max_eq_right (by linarith : 0 ≤ x - ν), max_eq_right (by linarith : 0 ≤ x - b)]
      ring
    · have h8' : b < x - 8 := not_le.1 h8
      have hP : ¬(x - 8 ≤ b ∧ b < x) := fun h => absurd h.1 h8
      rw [if_neg hP, sub_zero]
      have hν8 : ν ≤ x - 8 := by
        by_contra hc
        exact h2 ⟨h8', not_le.1 hc⟩
      rw [min_eq_left (by linarith : 8 ≤ x - ν), min_eq_left (by linarith : 8 ≤ x - b)]

/-- `Φ` is affine with slope `-k_b` on `[b, ν]` when no breakpoint lies strictly between `b` and `ν`. -/
lemma wfMass_affine (s : List ℚ) {b ν : ℚ} (hbν : b ≤ ν)
    (h : ∀ x ∈ s, ¬(b < x ∧ x < ν) ∧ ¬(b < x - 8 ∧ x - 8 < ν)) :
    wfMass s ν = wfMass s b - (wfSlope s b : ℚ) * (ν - b) := by
  induction s with
  | nil => simp [wfMass_nil, wfSlope_nil]
  | cons x t ih =>
    have hx := h x (by simp)
    have ht := ih fun y hy => h y (by simp [hy])
    rw [wfMass_cons, wfMass_cons, wfSlope_cons, clipQ_affine hbν hx.1 hx.2, ht]
    split_ifs <;> push_cast <;> ring

lemma wf_exists_min_mem (s : List ℚ) (hs : s ≠ []) : ∃ m ∈ s, ∀ x ∈ s, m ≤ x := by
  obtain ⟨a, ha⟩ := List.exists_mem_of_ne_nil s hs
  obtain ⟨m, hm, hmin⟩ := Finset.exists_min_image s.toFinset id ⟨a, List.mem_toFinset.2 ha⟩
  exact ⟨m, List.mem_toFinset.1 hm, fun x hx => hmin x (List.mem_toFinset.2 hx)⟩

lemma wf_exists_max_mem (s : List ℚ) (hs : s ≠ []) : ∃ M ∈ s, ∀ x ∈ s, x ≤ M := by
  obtain ⟨a, ha⟩ := List.exists_mem_of_ne_nil s hs
  obtain ⟨M, hM, hmax⟩ := Finset.exists_max_image s.toFinset id ⟨a, List.mem_toFinset.2 ha⟩
  exact ⟨M, List.mem_toFinset.1 hM, fun x hx => hmax x (List.mem_toFinset.2 hx)⟩

/-- **Completeness of the candidate list**: some candidate level solves `Φ(ν) = n`. -/
theorem exists_wfCand (s : List ℚ) (hs : s ≠ []) : ∃ ν ∈ wfCands s, wfMass s ν = s.length := by
  obtain ⟨m, hm, hmin⟩ := wf_exists_min_mem s hs
  obtain ⟨M, hM, hmax⟩ := wf_exists_max_mem s hs
  have hlen : (0 : ℚ) < s.length := by exact_mod_cast List.length_pos_iff.2 hs
  have hb0mem : m - 8 ∈ wfBreaks s := List.mem_append_right _ (List.mem_map.2 ⟨m, hm, rfl⟩)
  have hb0 : wfMass s (m - 8) = s.length * 8 := wfMass_eq_of_forall s _ 8 fun x hx => by
    unfold clipQ
    rw [min_eq_left (by linarith [hmin x hx]), max_eq_right (by norm_num)]
  have hb1mem : M ∈ wfBreaks s := List.mem_append_left _ hM
  have hb1 : wfMass s M = s.length * 0 := wfMass_eq_of_forall s _ 0 fun x hx => by
    unfold clipQ
    rw [min_eq_right (by linarith [hmax x hx]), max_eq_left (by linarith [hmax x hx])]
  -- `b*`: the largest breakpoint with `Φ(b*) ≥ n`
  obtain ⟨bs, hbs_mem, hbs_max⟩ := Finset.exists_max_image
    ((wfBreaks s).toFinset.filter fun b => (s.length : ℚ) ≤ wfMass s b) id
    ⟨m - 8, Finset.mem_filter.2 ⟨List.mem_toFinset.2 hb0mem, by rw [hb0]; linarith⟩⟩
  rw [Finset.mem_filter, List.mem_toFinset] at hbs_mem
  obtain ⟨hbs_B, hbs_ge⟩ := hbs_mem
  have hbs_max' : ∀ b ∈ wfBreaks s, (s.length : ℚ) ≤ wfMass s b → b ≤ bs := fun b hb hge =>
    hbs_max b (Finset.mem_filter.2 ⟨List.mem_toFinset.2 hb, hge⟩)
  rcases eq_or_lt_of_le hbs_ge with heq | hgt
  · exact ⟨bs, List.mem_append_left _ hbs_B, heq.symm⟩
  · have hM_gt : bs < M := by
      by_contra hc
      have := wfMass_antitone s (not_lt.1 hc)
      rw [hb1] at this
      linarith
    -- `b'`: the next breakpoint
    obtain ⟨b', hb'_mem, hb'_min⟩ := Finset.exists_min_image
      ((wfBreaks s).toFinset.filter fun b => bs < b) id
      ⟨M, Finset.mem_filter.2 ⟨List.mem_toFinset.2 hb1mem, hM_gt⟩⟩
    rw [Finset.mem_filter, List.mem_toFinset] at hb'_mem
    obtain ⟨hb'_B, hb'_gt⟩ := hb'_mem
    have hb'_min' : ∀ β ∈ wfBreaks s, bs < β → b' ≤ β := fun β hβ hlt =>
      hb'_min β (Finset.mem_filter.2 ⟨List.mem_toFinset.2 hβ, hlt⟩)
    have hb'_lt : wfMass s b' < s.length := by
      by_contra hc
      have := hbs_max' b' hb'_B (not_lt.1 hc)
      linarith
    have hgap : ∀ ν, ν ≤ b' → ∀ x ∈ s, ¬(bs < x ∧ x < ν) ∧ ¬(bs < x - 8 ∧ x - 8 < ν) := by
      intro ν hν x hx
      refine ⟨fun h => ?_, fun h => ?_⟩
      · have := hb'_min' x (List.mem_append_left _ hx) h.1
        linarith [h.2]
      · have := hb'_min' (x - 8) (List.mem_append_right _ (List.mem_map.2 ⟨x, hx, rfl⟩)) h.1
        linarith [h.2]
    have haff' := wfMass_affine s hb'_gt.le (hgap b' le_rfl)
    have hkpos : (0 : ℚ) < wfSlope s bs := by
      rcases Nat.eq_zero_or_pos (wfSlope s bs) with hk0 | hk0
      · rw [hk0, Nat.cast_zero, zero_mul, sub_zero] at haff'
        linarith
      · exact_mod_cast hk0
    have hk_ne : wfSlope s bs ≠ 0 := by
      intro h0
      rw [h0, Nat.cast_zero] at hkpos
      exact lt_irrefl _ hkpos
    have hkne' : (wfSlope s bs : ℚ) ≠ 0 := hkpos.ne'
    obtain ⟨νc, hνc⟩ : ∃ ν : ℚ, ν = bs + (wfMass s bs - s.length) / wfSlope s bs := ⟨_, rfl⟩
    have hq : 0 ≤ (wfMass s bs - s.length) / wfSlope s bs := div_nonneg (by linarith) hkpos.le
    have hq' : (wfMass s bs - s.length) / wfSlope s bs ≤ b' - bs := by
      rw [div_le_iff₀ hkpos]
      linarith
    have hνc_ge : bs ≤ νc := by rw [hνc]; linarith
    have hνc_le : νc ≤ b' := by rw [hνc]; linarith
    have haffc := wfMass_affine s hνc_ge (hgap νc hνc_le)
    refine ⟨νc, List.mem_append_right _ (List.mem_filterMap.2 ⟨bs, hbs_B, ?_⟩), ?_⟩
    · show (if wfSlope s bs = 0 then none else
        some (bs + (wfMass s bs - s.length) / wfSlope s bs)) = some νc
      rw [if_neg hk_ne, hνc]
    · rw [haffc, hνc]
      have hcancel : (wfSlope s bs : ℚ) * ((wfMass s bs - s.length) / wfSlope s bs) =
          wfMass s bs - s.length := by
        field_simp
      rw [show bs + (wfMass s bs - s.length) / wfSlope s bs - bs =
        (wfMass s bs - s.length) / wfSlope s bs by ring, hcancel]
      ring

/-- The water level found by `wfLevel` is valid: `Φ(wfLevel s) = n` for nonempty `s`. -/
theorem wfMass_wfLevel (s : List ℚ) (hs : s ≠ []) : wfMass s (wfLevel s) = s.length := by
  obtain ⟨ν₀, hmem, hν₀⟩ := exists_wfCand s hs
  unfold wfLevel
  cases h : (wfCands s).find? (fun ν => decide (wfMass s ν = s.length)) with
  | none =>
    exfalso
    have := List.find?_eq_none.1 h ν₀ hmem
    simp [hν₀] at this
  | some ν =>
    have := List.find?_some h
    simpa using this

theorem capWeightsQ_length (c : ℚ) (g : List ℤ) : (capWeightsQ c g).length = g.length := by
  simp [capWeightsQ]

lemma capWeightsQ_getD (c : ℚ) (g : List ℤ) (i : ℕ) (hi : i < g.length) :
    (capWeightsQ c g).getD i 0 =
      clipQ 0 8 (1 + c * g[i] - wfLevel (g.map fun gi : ℤ => 1 + c * gi)) / g.length := by
  simp only [capWeightsQ, List.length_map]
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_map, List.getElem?_eq_getElem hi]
  rfl

/-- **`capWeightsQ` computes the learner weights exactly** (Lemma `R:lem:sec3_kkt_sensitivity` (i)). -/
theorem capWeightsQ_spec (c : ℚ) (g : List ℤ) (hg : g ≠ []) :
    (fun i : Fin g.length => (((capWeightsQ c g).getD i 0 : ℚ) : ℝ)) =
      F2e2e.Opt.Quad.learnerWeights g.length 8 (c : ℝ) (fun i => ((g.get i : ℤ) : ℝ)) := by
  have hn : 0 < g.length := List.length_pos_iff.2 hg
  have hnQ : (g.length : ℚ) ≠ 0 := by exact_mod_cast hn.ne'
  have hsne : (g.map fun gi : ℤ => 1 + c * gi) ≠ [] := by simpa using hg
  obtain ⟨ν, hν⟩ : ∃ ν, ν = wfLevel (g.map fun gi : ℤ => 1 + c * gi) := ⟨_, rfl⟩
  have hmass : wfMass (g.map fun gi : ℤ => 1 + c * gi) ν = g.length := by
    rw [hν, wfMass_wfLevel _ hsne, List.length_map]
  have hpt : ∀ i : Fin g.length, (((capWeightsQ c g).getD i 0 : ℚ) : ℝ) =
      waterfill g.length 8 (shiftedScores (c : ℝ) (fun i => ((g.get i : ℤ) : ℝ))) (ν : ℝ) i := by
    intro i
    rw [capWeightsQ_getD c g i i.2, ← hν]
    simp only [waterfill, shiftedScores, clip, clipQ, List.get_eq_getElem]
    push_cast
    rfl
  have hsumQ : ∑ i : Fin g.length, clipQ 0 8 (1 + c * g[(i : ℕ)] - ν) = g.length := by
    rw [← hmass, wfMass, List.map_map]
    exact Fin.sum_univ_fun_getElem g (fun gi : ℤ => clipQ 0 8 (1 + c * gi - ν))
  have hsum : ∑ i, waterfill g.length 8 (shiftedScores (c : ℝ) (fun i => ((g.get i : ℤ) : ℝ)))
      (ν : ℝ) i = 1 := by
    have hQ : ∑ i : Fin g.length, (capWeightsQ c g).getD i 0 = 1 := by
      rw [Finset.sum_congr rfl fun (i : Fin g.length) _ => capWeightsQ_getD c g i i.2, ← hν,
        ← Finset.sum_div, hsumQ,
        div_self hnQ]
    have hR : ∑ i : Fin g.length, (((capWeightsQ c g).getD i 0 : ℚ) : ℝ) = 1 := by
      rw [← Rat.cast_sum, hQ, Rat.cast_one]
    rw [← hR]
    exact Finset.sum_congr rfl fun i _ => (hpt i).symm
  rw [funext hpt]
  exact waterfill_eq_learnerWeights hn (by norm_num) _ _ hsum

/-- `x.den ∣ m` for `x = z/m`. -/
lemma ratDen_dvd_of_eq_div {x : ℚ} {z : ℤ} {m : ℕ} (hx : x = (z : ℚ) / (m : ℚ)) : x.den ∣ m := by
  have h := Rat.den_dvd z (m : ℤ)
  rw [Rat.divInt_eq_div, Int.cast_natCast, ← hx] at h
  exact Int.natCast_dvd_natCast.1 h

/-- **Rational denominators of the exact weights** (Lemma `R:lem:sec3_kkt_sensitivity` (iii), for the
space accounting): for nonempty integer scores `g` there is `k ∈ [1, n]` (the active-set size `k_act`, or `1`
if no coordinate is active) such that every weight `x ∈ capWeightsQ c g` satisfies `0 ≤ x ≤ 8/n`,
`x.den ∣ k · n · c.den` and hence `x.den ≤ n² · c.den` (`n = g.length`); the bound depends on the current
scores only (no growth across updates). -/
theorem capWeightsQ_den (c : ℚ) (g : List ℤ) (hg : g ≠ []) :
    ∃ k : ℕ, 1 ≤ k ∧ k ≤ g.length ∧ ∀ x ∈ capWeightsQ c g,
      0 ≤ x ∧ x ≤ 8 / g.length ∧ x.den ∣ k * g.length * c.den ∧ x.den ≤ g.length ^ 2 * c.den := by
  have hn : 0 < g.length := List.length_pos_iff.2 hg
  have hD : 0 < c.den := c.den_pos
  set G : Fin g.length → ℝ := fun i => ((g.get i : ℤ) : ℝ) with hGdef
  have hG : ∀ i, ∃ z : ℤ, (c : ℝ) * G i = z / c.den := by
    intro i
    refine ⟨c.num * g.get i, ?_⟩
    rw [hGdef, Rat.cast_def]
    push_cast
    ring
  have hspec := capWeightsQ_spec c g hg
  obtain ⟨h1, h2⟩ := kkt_rational_denominators hn (c : ℝ) G hD hG rfl rfl rfl
  -- every weight is the cast of a learner weight
  have hx_of : ∀ x ∈ capWeightsQ c g, ∃ i : Fin g.length,
      (x : ℝ) = Opt.Quad.learnerWeights g.length 8 (c : ℝ) G i := by
    intro x hx
    obtain ⟨j, hj, rfl⟩ := List.mem_iff_getElem.1 hx
    have hj' : j < g.length := by rwa [capWeightsQ_length] at hj
    refine ⟨⟨j, hj'⟩, ?_⟩
    have := congrFun hspec ⟨j, hj'⟩
    simp only [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hj, Option.getD_some] at this
    exact this
  have hmem := learnerWeights_mem hn (by norm_num : (1 : ℝ) ≤ 8) (c : ℝ) G
  have hbounds : ∀ x ∈ capWeightsQ c g, 0 ≤ x ∧ x ≤ 8 / g.length := by
    intro x hx
    obtain ⟨i, hi⟩ := hx_of x hx
    have hb := hmem.1 i
    rw [← hi] at hb
    refine ⟨by exact_mod_cast hb.1, ?_⟩
    have : ((8 / g.length : ℚ) : ℝ) = 8 / g.length := by push_cast; ring
    exact_mod_cast (this ▸ hb.2 : (x : ℝ) ≤ ((8 / g.length : ℚ) : ℝ))
  rcases Finset.eq_empty_or_nonempty (activeSet g.length 8 (Opt.Quad.learnerWeights g.length 8 (c : ℝ) G))
    with hAe | hAne
  · obtain ⟨-, -, hcoord⟩ := h1 hAe
    refine ⟨1, le_rfl, hn, fun x hx => ⟨(hbounds x hx).1, (hbounds x hx).2, ?_, ?_⟩⟩
    · obtain ⟨i, hi⟩ := hx_of x hx
      obtain ⟨z, -, -, hz⟩ := (hcoord i).2
      have hxq : x = (z : ℚ) / (g.length : ℚ) := by
        apply Rat.cast_injective (α := ℝ)
        rw [hi, hz]
        push_cast
        ring
      exact (ratDen_dvd_of_eq_div hxq).trans ⟨c.den, by ring⟩
    · obtain ⟨i, hi⟩ := hx_of x hx
      obtain ⟨z, -, -, hz⟩ := (hcoord i).2
      have hxq : x = (z : ℚ) / (g.length : ℚ) := by
        apply Rat.cast_injective (α := ℝ)
        rw [hi, hz]
        push_cast
        ring
      have hdvd := ratDen_dvd_of_eq_div hxq
      calc x.den ≤ g.length := Nat.le_of_dvd hn hdvd
        _ ≤ g.length ^ 2 * c.den := by nlinarith
  · obtain ⟨hk1, hkn, -, -, -, hcoord, hkle⟩ := h2 hAne
    obtain ⟨k, hk⟩ : ∃ k, k = (activeSet g.length 8 (Opt.Quad.learnerWeights g.length 8 (c : ℝ) G)).card :=
      ⟨_, rfl⟩
    rw [← hk] at hk1 hkn hcoord hkle
    have hpos : 0 < k * g.length * c.den := Nat.mul_pos (Nat.mul_pos hk1 hn) hD
    have hden : ∀ x ∈ capWeightsQ c g, x.den ∣ k * g.length * c.den := by
      intro x hx
      obtain ⟨i, hi⟩ := hx_of x hx
      obtain ⟨z, -, -, hz⟩ := hcoord i
      have hxq : x = (z : ℚ) / ((k * g.length * c.den : ℕ) : ℚ) := by
        apply Rat.cast_injective (α := ℝ)
        rw [hi, hz]
        push_cast
        ring
      exact ratDen_dvd_of_eq_div hxq
    exact ⟨k, hk1, hkn, fun x hx => ⟨(hbounds x hx).1, (hbounds x hx).2, hden x hx,
      (Nat.le_of_dvd hpos (hden x hx)).trans hkle⟩⟩

/-- Bit-size bounds for the exact weights (space accounting, Lemma `R:lem:sec3_kkt_sensitivity` (iii)):
every `x ∈ capWeightsQ c g` has `x.den ≤ n² · c.den` and `|x.num| ≤ 8 · n · c.den` (`n = g.length`). -/
theorem capWeightsQ_bits (c : ℚ) (g : List ℤ) (hg : g ≠ []) :
    ∀ x ∈ capWeightsQ c g, x.den ≤ g.length ^ 2 * c.den ∧ x.num.natAbs ≤ 8 * g.length * c.den := by
  obtain ⟨k, hk1, hkn, h⟩ := capWeightsQ_den c g hg
  intro x hx
  obtain ⟨hx0, hx8, hdvd, hden⟩ := h x hx
  have hn : 0 < g.length := List.length_pos_iff.2 hg
  have hnQ : (0 : ℚ) < g.length := by exact_mod_cast hn
  have hpos : 0 < k * g.length * c.den := Nat.mul_pos (Nat.mul_pos hk1 hn) c.den_pos
  have hdenle : x.den ≤ k * g.length * c.den := Nat.le_of_dvd hpos hdvd
  refine ⟨hden, ?_⟩
  have hnum0 : 0 ≤ x.num := Rat.num_nonneg.2 hx0
  have hnumQ : (x.num : ℚ) = x * x.den := (Rat.mul_den_eq_num x).symm
  have hd : (x.den : ℚ) ≤ (k : ℚ) * g.length * c.den := by exact_mod_cast hdenle
  have hkQ : (k : ℚ) ≤ g.length := by exact_mod_cast hkn
  have hD : (0 : ℚ) ≤ c.den := Nat.cast_nonneg _
  have h1 : (x.num : ℚ) ≤ 8 / g.length * ((k : ℚ) * g.length * c.den) := by
    rw [hnumQ]
    calc x * x.den ≤ 8 / g.length * x.den := mul_le_mul_of_nonneg_right hx8 (Nat.cast_nonneg _)
      _ ≤ 8 / g.length * ((k : ℚ) * g.length * c.den) :=
          mul_le_mul_of_nonneg_left hd (by positivity)
  have h2 : 8 / (g.length : ℚ) * ((k : ℚ) * g.length * c.den) = 8 * k * c.den := by
    field_simp
  have h3 : (8 * k * c.den : ℚ) ≤ 8 * g.length * c.den := by
    have := mul_le_mul_of_nonneg_right hkQ hD
    nlinarith
  have h4 : ((x.num.natAbs : ℤ) : ℚ) = (x.num : ℚ) := by
    rw [Int.natAbs_of_nonneg hnum0]
  have h5 : ((x.num.natAbs : ℕ) : ℚ) ≤ ((8 * g.length * c.den : ℕ) : ℚ) := by
    rw [← Int.cast_natCast (R := ℚ) x.num.natAbs, h4]
    push_cast
    linarith
  exact_mod_cast h5

end F2e2e.B
