import F2e2e.B.SpecV2BridgeCorr
import F2e2e.B.Mechanism

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 3a: simulation of the internal machinery

Each lemma: if the core's bit execution of a component succeeds on the tape `τ` with result `x` and
rest `rest`, then the Spec's tape-passing component on `τ` returns the corresponding result with the
same rest of the tape, and the states stay in correspondence (`StCorr`).
-/

namespace F2e2e.B.V2

open F2e2e.Discrete

/-! ## Edge tests (lines [5]–[7]) -/

theorem edgeTest_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) {mu2 : ℕ → ℝ} {mus : List ℚ}
    (hmu : ∀ i ≤ P.p, mu2 i = ((mus.getD i 0 : ℚ) : ℝ)) {j : ℕ} (hj : j < P.p) {τ : List Bool}
    {r : Option Bool} {rest : List Bool}
    (h : ((edgeTest P st mus j).toBits (adaDraw P)).run τ = some (r, rest)) :
    F2e2e.alg2EdgeTest P2 st2 mu2 j τ =
      some (r.map (fun q => if q then (1 : ℤ) else -1), rest) := by
  unfold edgeTest at h
  obtain ⟨kp, τ1, h1, h2⟩ := run_drawNoise_bind_some h
  obtain ⟨km, τ2, h3, h4⟩ := run_drawNoise_bind_some h2
  obtain ⟨hr, hrest⟩ := run_toBits_ret_some h4
  subst hr hrest
  have c1 : (P2.tau + (P2.hA : ℝ) * (st2.thrInt j : ℝ) ≤
        mu2 (j + 1) - mu2 j + (P2.hA : ℝ) * (kp : ℝ)) ↔
      (P.tau + P.hA * (st.thrInt.getD j 0 : ℚ) ≤
        mus.getD (j + 1) 0 - mus.getD j 0 + P.hA * (kp : ℚ)) := by
    rw [hP.htau, hP.hhA, hst.thr, hmu (j + 1) hj, hmu j hj.le]
    norm_cast
  have c2 : (P2.tau + (P2.hA : ℝ) * (st2.thrInt j : ℝ) ≤
        mu2 j - mu2 (j + 1) + (P2.hA : ℝ) * (km : ℝ)) ↔
      (P.tau + P.hA * (st.thrInt.getD j 0 : ℚ) ≤
        -(mus.getD (j + 1) 0 - mus.getD j 0) + P.hA * (km : ℚ)) := by
    rw [hP.htau, hP.hhA, hst.thr, hmu (j + 1) hj, hmu j hj.le, neg_sub]
    norm_cast
  unfold F2e2e.alg2EdgeTest
  rw [hP.dIntTest, h1]
  dsimp only
  rw [hP.dIntTest, h3]
  dsimp only
  by_cases d1 : P.tau + P.hA * (st.thrInt.getD j 0 : ℚ) ≤
      mus.getD (j + 1) 0 - mus.getD j 0 + P.hA * (kp : ℚ)
  · rw [if_pos (c1.mpr d1), if_pos d1]; rfl
  · rw [if_neg (fun h => d1 (c1.mp h)), if_neg d1]
    by_cases d2 : P.tau + P.hA * (st.thrInt.getD j 0 : ℚ) ≤
        -(mus.getD (j + 1) 0 - mus.getD j 0) + P.hA * (km : ℚ)
    · rw [if_pos (c2.mpr d2), if_pos d2]; rfl
    · rw [if_neg (fun h => d2 (c2.mp h)), if_neg d2]; rfl

/-! ## Threshold draws -/

theorem redraw_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) :
    ∀ (es : List ℕ) (thr : List ℤ) (thr2 : ℕ → ℤ), (∀ e, thr2 e = thr.getD e 0) →
      (∀ e ∈ es, e < thr.length) → ∀ {τ : List Bool} {thr' : List ℤ} {rest : List Bool},
      ((redrawThresholds P es thr).toBits (adaDraw P)).run τ = some (thr', rest) →
      ∃ thr2', F2e2e.alg2DrawThresholds P2 es thr2 τ = some (thr2', rest) ∧
        (∀ e, thr2' e = thr'.getD e 0) ∧ thr'.length = thr.length
  | [], thr, thr2, hthr, _, τ, thr', rest, h => by
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    subst h1 h2
    exact ⟨thr2, rfl, hthr, rfl⟩
  | e :: es, thr, thr2, hthr, hes, τ, thr', rest, h => by
    obtain ⟨k, τ1, h1, h2⟩ := run_drawNoise_bind_some h
    have he : e < thr.length := hes e List.mem_cons_self
    obtain ⟨thr2', h3, h4, h5⟩ := redraw_sim hP es (thr.set e k) (Function.update thr2 e k)
      (fun e' => by rw [getD_set_of_lt thr e' k 0 he, Function.update_apply, hthr])
      (fun e' he' => by rw [List.length_set]; exact hes e' (List.mem_cons_of_mem _ he')) h2
    refine ⟨thr2', ?_, h4, by rw [h5, List.length_set]⟩
    unfold F2e2e.alg2DrawThresholds
    rw [hP.dIntThr, h1]
    exact h3

theorem drawList_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) :
    ∀ (n m : ℕ) (thr2 : ℕ → ℤ) {τ : List Bool} {ks : List ℤ} {rest : List Bool},
      ((drawList NoiseKind.intThr n).toBits (adaDraw P)).run τ = some (ks, rest) →
      ∃ thr2', F2e2e.alg2DrawThresholds P2 (List.range' m n) thr2 τ = some (thr2', rest) ∧
        (∀ e, thr2' e = if m ≤ e ∧ e < m + n then ks.getD (e - m) 0 else thr2 e) ∧
        ks.length = n
  | 0, m, thr2, τ, ks, rest, h => by
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    subst h1 h2
    refine ⟨thr2, rfl, fun e => ?_, rfl⟩
    rw [if_neg (by omega)]
  | n + 1, m, thr2, τ, ks, rest, h => by
    have e0 : drawList NoiseKind.intThr (n + 1) =
        (drawNoise NoiseKind.intThr).bind fun z => (drawList NoiseKind.intThr n).map (z :: ·) := rfl
    rw [e0] at h
    obtain ⟨k, τ1, h1, h2⟩ := run_drawNoise_bind_some h
    obtain ⟨ks0, h3, hks⟩ := run_toBits_map_some h2
    subst hks
    obtain ⟨thr2', h4, h5, h6⟩ := drawList_sim hP n (m + 1) (Function.update thr2 m k) h3
    refine ⟨thr2', ?_, fun e => ?_, by rw [List.length_cons, h6]⟩
    · rw [List.range'_succ]
      unfold F2e2e.alg2DrawThresholds
      rw [hP.dIntThr, h1]
      exact h4
    · rw [h5 e, Function.update_apply]
      by_cases hem : e = m
      · subst hem
        rw [if_neg (by omega), if_pos rfl, if_pos (by omega), Nat.sub_self, List.getD_cons_zero]
      · by_cases hr : m + 1 ≤ e ∧ e < m + 1 + n
        · rw [if_pos hr, if_pos (by omega)]
          obtain ⟨d, hd⟩ : ∃ d, e - m = d + 1 := ⟨e - m - 1, by omega⟩
          rw [hd, List.getD_cons_succ, show e - (m + 1) = d by omega]
        · rw [if_neg hr, if_neg hem, if_neg (by omega)]

/-! ## Corrections (lines [8]–[9]) -/

theorem addScaled_length (g : List ℤ) (c : ℤ) (v : List ℕ) : (addScaled g c v).length = g.length := by
  unfold addScaled; exact List.length_mapIdx

theorem addScaled_getD (g : List ℤ) (c : ℤ) (v : List ℕ) {i : ℕ} (hi : i < g.length) :
    (addScaled g c v).getD i 0 = g.getD i 0 + c * (v.getD i 0 : ℤ) := by
  unfold addScaled
  simp only [List.getD_eq_getElem?_getD, List.getElem?_mapIdx, List.getElem?_eq_getElem hi,
    Option.map_some, Option.getD_some]

theorem reopenEdges_lt (P : AdaParams) {j : ℕ} (hj : j < P.p) : ∀ e ∈ reopenEdges P j, e < P.p := by
  intro e he
  unfold reopenEdges at he
  split_ifs at he <;> simp at he <;> omega

theorem alg2ReopenEdges_eq {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) (j : ℕ) :
    F2e2e.alg2ReopenEdges P2 j = reopenEdges P j := by
  unfold F2e2e.alg2ReopenEdges reopenEdges; rw [hP.hp]

/-- `getD` after the (one or two) block updates of a correction. -/
theorem getD_set2 {α : Type} (l : List (List α)) {p j : ℕ} (hl : l.length = p) (hj : j < p)
    (a b : List α) (j' : ℕ) :
    (if j + 1 < p then (l.set j a).set (j + 1) b else l.set j a).getD j' [] =
      if j' = j then a else if j' = j + 1 ∧ j + 1 < p then b else l.getD j' [] := by
  by_cases hj1 : j + 1 < p
  · rw [if_pos hj1, getD_set_of_lt _ _ _ _ (by rw [List.length_set]; omega),
      getD_set_of_lt _ _ _ _ (by omega)]
    by_cases h1 : j' = j + 1
    · rw [if_pos h1, if_neg (by omega), if_pos ⟨h1, hj1⟩]
    · rw [if_neg h1]
      by_cases h2 : j' = j
      · rw [if_pos h2, if_pos h2]
      · rw [if_neg h2, if_neg h2, if_neg (fun h => h1 h.1)]
  · rw [if_neg hj1, getD_set_of_lt _ _ _ _ (by omega)]
    by_cases h2 : j' = j
    · rw [if_pos h2, if_pos h2]
    · rw [if_neg h2, if_neg h2, if_neg (fun h => hj1 h.2)]

theorem length_set2 {α : Type} (l : List (List α)) (p j : ℕ) (a b : List α) :
    (if j + 1 < p then (l.set j a).set (j + 1) b else l.set j a).length = l.length := by
  split_ifs <;> simp

theorem correct_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) {j : ℕ} (hj : j < P.p) (q : Bool)
    {τ : List Bool} {st' : AdaState} {rest : List Bool}
    (h : ((applyCorrection P st vals j q).toBits (adaDraw P)).run τ = some (st', rest)) :
    ∃ st2', F2e2e.alg2Correct P2 st2 fv j (if q then 1 else -1) τ = some (st2', rest) ∧
      StCorr P st2' st' := by
  unfold applyCorrection at h
  obtain ⟨thr', τ1, h1, h2⟩ := run_toBits_bind_some h
  obtain ⟨hst', hrest⟩ := run_toBits_ret_some h2
  subst hst' hrest
  obtain ⟨thr2', h3, h4, h5⟩ := redraw_sim hP (reopenEdges P j) st.thrInt st2.thrInt hst.thr
    (fun e he => by rw [hst.thrlen]; exact reopenEdges_lt P hj e he) h1
  unfold F2e2e.alg2Correct
  rw [alg2ReopenEdges_eq hP, h3]
  refine ⟨_, rfl, ?_⟩
  -- abbreviations
  have hvj : blockVals P vals j = vals.getD j [] := blockVals_eq hv hj.le
  have hvj1 : j + 1 < P.p → blockVals P vals (j + 1) = vals.getD (j + 1) [] :=
    fun h => blockVals_eq hv h.le
  have hg1 : ((st.scores.set j (addScaled (st.scores.getD j []) (4 * if q then 1 else -1)
      (blockVals P vals j))).getD (j + 1) []) = st.scores.getD (j + 1) [] := by
    rw [getD_set_of_lt _ _ _ _ (by rw [hst.slen]; exact hj), if_neg (by omega)]
  have hoff : ∀ j' ≤ P.p + 1, P2.offset j' = (P.blockSizes.take j').sum := fun j' h =>
    hP.offset_eq h
  constructor
  · -- slen
    dsimp only
    rw [length_set2, hst.slen]
  · -- wlen
    dsimp only
    rw [length_set2, hst.wlen]
  · -- blen
    intro j' hj'
    dsimp only
    rw [getD_set2 _ hst.slen hj]
    by_cases h1 : j' = j
    · rw [if_pos h1, addScaled_length, hst.blen j hj, h1]
    · rw [if_neg h1]
      by_cases h2 : j' = j + 1 ∧ j + 1 < P.p
      · rw [if_pos h2, addScaled_length, hg1, h2.1, hst.blen _ h2.2]
      · rw [if_neg h2]
        exact hst.blen j' hj'
  · -- weights
    intro j' hj'
    dsimp only
    rw [getD_set2 _ hst.wlen hj, getD_set2 _ hst.slen hj]
    by_cases h1 : j' = j
    · rw [if_pos h1, if_pos h1]
    · rw [if_neg h1, if_neg h1]
      by_cases h2 : j' = j + 1 ∧ j + 1 < P.p
      · rw [if_pos h2, if_pos h2]
      · rw [if_neg h2, if_neg h2]
        exact hst.w j' hj'
  · -- Tlen
    dsimp only
    rw [List.length_set, hst.Tlen]
  · -- thrlen
    dsimp only
    rw [h5, hst.thrlen]
  · -- G
    intro j' hj' i hi
    dsimp only
    rw [getD_set2 _ hst.slen hj, hP.hp]
    by_cases h1 : j' = j
    · rw [if_pos h1]
      rw [h1] at hi ⊢
      have hupd : (if j + 1 < P.p then
            Function.update (Function.update st2.G j fun i =>
              st2.G j i + ((if q = true then 1 else -1 : ℤ) : ℝ) * fv (P2.offset j + i)) (j + 1)
              (fun i => (Function.update st2.G j fun i =>
                st2.G j i + ((if q = true then 1 else -1 : ℤ) : ℝ) * fv (P2.offset j + i)) (j + 1) i -
                  ((if q = true then 1 else -1 : ℤ) : ℝ) / 4 * fv (P2.offset (j + 1) + i))
          else Function.update st2.G j fun i =>
            st2.G j i + ((if q = true then 1 else -1 : ℤ) : ℝ) * fv (P2.offset j + i)) j i =
          st2.G j i + ((if q = true then 1 else -1 : ℤ) : ℝ) * fv (P2.offset j + i) := by
        by_cases hj1 : j + 1 < P.p
        · rw [if_pos hj1, Function.update_of_ne (by omega), Function.update_self]
        · rw [if_neg hj1, Function.update_self]
      rw [hupd, addScaled_getD _ _ _ (by rw [hst.blen j hj]; exact hi), hst.G j hj i hi,
        hoff j (by omega), hv.eq j hj.le i hi, hvj]
      push_cast
      ring
    · rw [if_neg h1]
      by_cases h2 : j' = j + 1 ∧ j + 1 < P.p
      · rw [if_pos h2]
        obtain ⟨h2a, h2b⟩ := h2
        rw [h2a] at hi ⊢
        rw [if_pos h2b, Function.update_self, Function.update_of_ne (by omega),
          addScaled_getD _ _ _ (by rw [hg1, hst.blen _ h2b]; exact hi), hg1,
          hst.G _ h2b i hi, hoff (j + 1) (by omega), hv.eq (j + 1) h2b.le i hi, hvj1 h2b]
        push_cast
        ring
      · rw [if_neg h2]
        have hne : j' ≠ j := h1
        by_cases hj1 : j + 1 < P.p
        · rw [if_pos hj1, Function.update_of_ne (fun h => h2 ⟨h, hj1⟩), Function.update_of_ne hne]
          exact hst.G j' hj' i hi
        · rw [if_neg hj1, Function.update_of_ne hne]
          exact hst.G j' hj' i hi
  · -- T
    intro j'
    dsimp only
    rw [Function.update_apply, getD_set_of_lt _ _ _ _ (by rw [hst.Tlen]; exact hj)]
    split_ifs with h1
    · subst h1; rw [hst.T]
    · exact hst.T j'
  · exact h4
  · exact hst.thrOut
  · exact hst.rej
  · exact hst.nInt
  · exact hst.nNum
  · exact hst.halted
  · exact hst.aborted

/-! ## Scan passes and `PrepareRoot` (lines [2]–[10]) -/

/-- The Spec's status of a pass outcome. -/
def passStatus : PassOut → F2e2e.Alg2Status
  | PassOut.done => F2e2e.Alg2Status.done
  | PassOut.corrected => F2e2e.Alg2Status.corrected
  | PassOut.abort => F2e2e.Alg2Status.capAbort

theorem scan_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) {mu2 : ℕ → ℝ} {mus : List ℚ}
    (hmu : ∀ i ≤ P.p, mu2 i = ((mus.getD i 0 : ℚ) : ℝ)) :
    ∀ (es : List ℕ), (∀ e ∈ es, e < P.p) → ∀ (st2 : F2e2e.Alg2State) (st : AdaState)
      (cache2 : ℕ → Bool) (cache : List Bool), StCorr P st2 st →
      (∀ e, cache2 e = cache.getD e false) → cache.length = P.p →
      ∀ {τ : List Bool} {o : PassOut} {st' : AdaState} {cache' : List Bool} {rest : List Bool},
      ((scanPass P vals mus es st cache).toBits (adaDraw P)).run τ =
        some ((o, st', cache'), rest) →
      ∃ st2' cache2', F2e2e.alg2ScanPass P2 fv mu2 es st2 cache2 τ =
          (passStatus o, st2', cache2', rest) ∧
        StCorr P st2' st' ∧ (∀ e, cache2' e = cache'.getD e false) ∧ cache'.length = P.p
  | [], _, st2, st, cache2, cache, hst, hc, hcl, τ, o, st', cache', rest, h => by
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    simp only [Prod.mk.injEq] at h1
    obtain ⟨rfl, rfl, rfl⟩ := h1
    subst h2
    exact ⟨st2, cache2, rfl, hst, hc, hcl⟩
  | j :: es, hes, st2, st, cache2, cache, hst, hc, hcl, τ, o, st', cache', rest, h => by
    have hj : j < P.p := hes j List.mem_cons_self
    have hes' : ∀ e ∈ es, e < P.p := fun e he => hes e (List.mem_cons_of_mem _ he)
    unfold scanPass at h
    unfold F2e2e.alg2ScanPass
    by_cases hcj : cache.getD j false = true
    · rw [if_pos hcj] at h
      rw [if_pos (by rw [hc]; exact hcj)]
      exact scan_sim hP hv hmu es hes' st2 st cache2 cache hst hc hcl h
    · rw [if_neg hcj] at h
      rw [if_neg (by rw [hc]; exact hcj)]
      obtain ⟨r, τ1, h1, h2⟩ := run_toBits_bind_some h
      rcases r with _ | q
      · have e : F2e2e.alg2EdgeTest P2 st2 mu2 j τ = some (none, τ1) :=
          edgeTest_sim hP hst hmu hj h1
        rw [e]
        exact scan_sim hP hv hmu es hes' st2 st (Function.update cache2 j true) (cache.set j true)
          hst (fun e => by
            rw [Function.update_apply, getD_set_of_lt _ _ _ _ (by rw [hcl]; exact hj), hc])
          (by rw [List.length_set, hcl]) h2
      · have e : F2e2e.alg2EdgeTest P2 st2 mu2 j τ =
            some (some (if q then 1 else -1), τ1) := edgeTest_sim hP hst hmu hj h1
        rw [e]
        dsimp only at h2 ⊢
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hT] at h2
          rw [if_pos (by rw [hP.hTmax, hst.T]; exact hT)]
          obtain ⟨h3, h4⟩ := run_toBits_ret_some h2
          simp only [Prod.mk.injEq] at h3
          obtain ⟨rfl, rfl, rfl⟩ := h3
          subst h4
          exact ⟨st2, cache2, rfl, hst, hc, hcl⟩
        · rw [if_neg hT] at h2
          rw [if_neg (by rw [hP.hTmax, hst.T]; exact hT)]
          obtain ⟨st'', τ2, h3, h4⟩ := run_toBits_bind_some h2
          obtain ⟨h5, h6⟩ := run_toBits_ret_some h4
          simp only [Prod.mk.injEq] at h5
          obtain ⟨rfl, rfl, rfl⟩ := h5
          subst h6
          obtain ⟨st2'', h7, h8⟩ := correct_sim hP hst hv hj q h3
          rw [h7]
          refine ⟨st2'', _, rfl, h8, fun e => ?_, by rw [length_foldl_set_false, hcl]⟩
          rw [getD_foldl_set_false, alg2ReopenEdges_eq hP, hc]

theorem prep_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) :
    ∀ (fuel : ℕ) (st2 : F2e2e.Alg2State) (st : AdaState) (cache2 : ℕ → Bool)
      (cache : List Bool), StCorr P st2 st → (∀ e, cache2 e = cache.getD e false) →
      cache.length = P.p → ∀ {τ : List Bool} {r : Option AdaState} {rest : List Bool},
      ((prepareRoot P vals fuel st cache).toBits (adaDraw P)).run τ = some (r, rest) →
      (∀ st', r = some st' → ∃ st2', F2e2e.alg2PrepareRoot P2 fv fuel st2 cache2 τ =
          (F2e2e.Alg2Status.done, st2', rest) ∧ StCorr P st2' st') ∧
      (r = none → ∃ st2', F2e2e.alg2PrepareRoot P2 fv fuel st2 cache2 τ =
          (F2e2e.Alg2Status.capAbort, st2', rest))
  | 0, st2, st, cache2, cache, hst, hc, hcl, τ, r, rest, h => by
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    subst h1 h2
    exact ⟨fun st' h => (by cases h), fun _ => ⟨st2, rfl⟩⟩
  | fuel + 1, st2, st, cache2, cache, hst, hc, hcl, τ, r, rest, h => by
    unfold prepareRoot at h
    obtain ⟨⟨o, st1, cache1⟩, τ1, h1, h2⟩ := run_toBits_bind_some h
    have hmu : ∀ i ≤ P.p, F2e2e.alg2Mu P2 st2 fv i = (((adaMus P st vals).getD i 0 : ℚ) : ℝ) :=
      fun i hi => alg2Mu_eq hP hst hv hi
    obtain ⟨st2', cache2', h3, h4, h5, h6⟩ := scan_sim hP hv hmu (List.range P.p)
      (fun e he => List.mem_range.mp he) st2 st cache2 cache hst hc hcl h1
    unfold F2e2e.alg2PrepareRoot
    rw [hP.hp, h3]
    cases o with
    | done =>
      obtain ⟨h7, h8⟩ := run_toBits_ret_some h2
      subst h7 h8
      exact ⟨fun st' h => (by cases h; exact ⟨st2', rfl, h4⟩), fun h => (by cases h)⟩
    | corrected =>
      exact prep_sim hP hv fuel st2' st1 cache2' cache1 h4 h5 h6 h2
    | abort =>
      obtain ⟨h7, h8⟩ := run_toBits_ret_some h2
      subst h7 h8
      exact ⟨fun st' h => (by cases h), fun _ => ⟨st2', rfl⟩⟩

/-! ## Outer rejections, `Interval`, `Numerical`, initialization -/

/-- The Spec's response of an interval certificate. -/
def certRespV2 : AdaCert → F2e2e.VResponse
  | AdaCert.accept => F2e2e.VResponse.accept
  | AdaCert.high => F2e2e.VResponse.high
  | AdaCert.low => F2e2e.VResponse.low
  | AdaCert.termHigh => F2e2e.VResponse.high
  | AdaCert.termLow => F2e2e.VResponse.low
  | AdaCert.abort => F2e2e.VResponse.accept

/-- The Spec's response of a numerical output. -/
def numRespV2 : AdaNum → F2e2e.VResponse
  | AdaNum.val q => F2e2e.VResponse.num q
  | AdaNum.abort => F2e2e.VResponse.num 0

theorem StCorr.upd {P : AdaParams} {st2 : F2e2e.Alg2State} {st : AdaState}
    (hst : StCorr P st2 st) {rej2 nInt2 nNum2 rej nInt nNum : ℕ}
    {halted2 aborted2 halted aborted : Bool} {thrOut2 thrOut : ℤ}
    (h1 : rej2 = rej) (h2 : nInt2 = nInt) (h3 : nNum2 = nNum) (h4 : halted2 = halted)
    (h5 : aborted2 = aborted) (h6 : thrOut2 = thrOut) :
    StCorr P
      { st2 with
        rej := rej2, nInt := nInt2, nNum := nNum2, halted := halted2, aborted := aborted2,
        thrOut := thrOut2 }
      { st with
        rej := rej, nInt := nInt, nNum := nNum, halted := halted, capAborted := aborted,
        thrOut := thrOut } :=
  { slen := hst.slen, wlen := hst.wlen, blen := hst.blen, w := hst.w, Tlen := hst.Tlen,
    thrlen := hst.thrlen, G := hst.G, T := hst.T, thr := hst.thr, thrOut := h6, rej := h1,
    nInt := h2, nNum := h3, halted := h4, aborted := h5 }

theorem reject_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) (high : Bool)
    {τ : List Bool} {c : AdaCert} {st' : AdaState} {rest : List Bool}
    (h : ((outerReject P st high).toBits (adaDraw P)).run τ = some ((c, st'), rest)) :
    ∃ st2', F2e2e.alg2Reject P2 st2
        (if high then F2e2e.VResponse.high else F2e2e.VResponse.low) τ =
      (certRespV2 c, st2', rest) ∧ StCorr P st2' st' := by
  unfold outerReject at h
  unfold F2e2e.alg2Reject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ] at h
    rw [if_pos (by rw [hP.hJ, hst.rej]; omega)]
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    simp only [Prod.mk.injEq] at h1
    obtain ⟨rfl, rfl⟩ := h1
    subst h2
    refine ⟨{ st2 with rej := st2.rej + 1, halted := true }, ?_,
      hst.upd (by rw [hst.rej]) hst.nInt hst.nNum rfl hst.aborted hst.thrOut⟩
    cases high <;> rfl
  · rw [if_neg hJ] at h
    rw [if_neg (by rw [hP.hJ, hst.rej]; omega)]
    obtain ⟨k, τ1, h1, h2⟩ := run_drawNoise_bind_some h
    obtain ⟨h3, h4⟩ := run_toBits_ret_some h2
    simp only [Prod.mk.injEq] at h3
    obtain ⟨rfl, rfl⟩ := h3
    subst h4
    rw [hP.dOutThr, h1]
    refine ⟨{ st2 with rej := st2.rej + 1, thrOut := k }, ?_,
      hst.upd (by rw [hst.rej]) hst.nInt hst.nNum hst.halted hst.aborted rfl⟩
    cases high <;> rfl

/-- The core's re-rounded grid endpoint is the Spec's rounded clipped endpoint. -/
theorem endpoint_eq (P : AdaParams) (x : ℝ) :
    P.hA * (roundIdxQ P.hA (clipQ (-1) 2 (P.hA * (endIdx P x : ℚ))) : ℚ) =
      F2e2e.roundGridQ P.hA (max (-1) (min 2 x)) := by
  have hc1 : (-1 : ℝ) ≤ max (-1) (min 2 x) := le_max_left _ _
  have hc2 : max (-1) (min 2 x) ≤ (2 : ℝ) := max_le (by norm_num) (min_le_left _ _)
  have hA0 : (0 : ℚ) < P.hA := by unfold AdaParams.hA; positivity
  have hA0' : (0 : ℝ) < (P.hA : ℝ) := by exact_mod_cast hA0
  have h2 : (2 : ℚ) ^ P.qA * P.hA = 1 := by unfold AdaParams.hA; rw [← mul_pow]; norm_num
  have h2' : (2 : ℝ) ^ P.qA * (P.hA : ℝ) = 1 := by exact_mod_cast h2
  have hkdef : endIdx P x = ⌊max (-1) (min 2 x) / (P.hA : ℝ) + 1 / 2⌋ := rfl
  have hkl : -(2 : ℤ) ^ P.qA ≤ endIdx P x := by
    rw [hkdef, Int.le_floor]
    push_cast
    have : -(2 : ℝ) ^ P.qA ≤ max (-1) (min 2 x) / (P.hA : ℝ) := by
      rw [le_div_iff₀ hA0']
      nlinarith
    linarith
  have hku : endIdx P x ≤ 2 * (2 : ℤ) ^ P.qA := by
    rw [hkdef, Int.floor_le_iff]
    push_cast
    have : max (-1) (min 2 x) / (P.hA : ℝ) ≤ 2 * (2 : ℝ) ^ P.qA := by
      rw [div_le_iff₀ hA0']
      nlinarith
    linarith
  have hkl' : -(2 : ℚ) ^ P.qA ≤ (endIdx P x : ℚ) := by exact_mod_cast hkl
  have hku' : (endIdx P x : ℚ) ≤ 2 * (2 : ℚ) ^ P.qA := by exact_mod_cast hku
  have hg1 : (-1 : ℚ) ≤ P.hA * (endIdx P x : ℚ) := by nlinarith
  have hg2 : P.hA * (endIdx P x : ℚ) ≤ 2 := by nlinarith
  have hclip : clipQ (-1) 2 (P.hA * (endIdx P x : ℚ)) = P.hA * (endIdx P x : ℚ) := by
    unfold clipQ; rw [min_eq_right hg2, max_eq_right hg1]
  have hround : roundIdxQ P.hA (P.hA * (endIdx P x : ℚ)) = endIdx P x := by
    unfold roundIdxQ
    rw [mul_div_cancel_left₀ _ hA0.ne', Int.floor_intCast_add]
    norm_num
  rw [hclip, hround]
  rfl

theorem numOut_eq (P : AdaParams) (μ : ℚ) (k : ℤ) :
    clipQ 0 1 (P.hA * (roundIdxQ P.hA (μ + P.hA * (k : ℚ)) : ℚ)) =
      max 0 (min 1 (F2e2e.roundGridQ P.hA ((μ : ℝ) + (P.hA : ℝ) * (k : ℝ)))) := by
  have hfl : ⌊(μ + P.hA * (k : ℚ)) / P.hA + 1 / 2⌋ =
      ⌊((μ : ℝ) + (P.hA : ℝ) * (k : ℝ)) / (P.hA : ℝ) + 1 / 2⌋ := by
    rw [← Rat.floor_cast (α := ℝ)]
    push_cast
    rfl
  unfold clipQ roundIdxQ F2e2e.roundGridQ
  rw [hfl]

theorem cache_init_corr (P : AdaParams) :
    ∀ e, (fun _ : ℕ => false) e = (List.replicate P.p false).getD e false := by
  intro e
  by_cases he : e < P.p
  · rw [List.getD_replicate _ he]
  · rw [List.getD_eq_getElem?_getD, List.getElem?_eq_none (by simp; omega)]; rfl

theorem interval_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) (l u : ℝ) {τ : List Bool} {c : AdaCert}
    {st' : AdaState} {rest : List Bool}
    (h : ((adaIntervalD P st vals (P.hA * (endIdx P l : ℚ)) (P.hA * (endIdx P u : ℚ))).toBits
      (adaDraw P)).run τ = some ((c, st'), rest)) :
    ∃ st2', F2e2e.alg2Interval P2 st2 fv l u τ = (certRespV2 c, st2', rest) ∧
      StCorr P st2' st' := by
  unfold adaIntervalD at h
  unfold F2e2e.alg2Interval
  have hcond : (st2.halted = true ∨ P2.M ≤ st2.nInt) ↔ (st.halted = true ∨ P.M ≤ st.nInt) := by
    rw [hst.halted, hP.hM, hst.nInt]
  by_cases hc : st.halted = true ∨ P.M ≤ st.nInt
  · rw [if_pos hc] at h
    rw [if_pos (hcond.mpr hc)]
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    simp only [Prod.mk.injEq] at h1
    obtain ⟨rfl, rfl⟩ := h1
    subst h2
    exact ⟨st2, rfl, hst⟩
  · rw [if_neg hc] at h
    rw [if_neg (fun h' => hc (hcond.mp h'))]
    obtain ⟨r, τ1, h1, h2⟩ := run_toBits_bind_some h
    have hst1 : StCorr P { st2 with nInt := st2.nInt + 1 } { st with nInt := st.nInt + 1 } :=
      hst.upd hst.rej (by rw [hst.nInt]) hst.nNum hst.halted hst.aborted hst.thrOut
    obtain ⟨hsome, hnone⟩ := prep_sim hP hv P.fuel _ _ _ _ hst1 (cache_init_corr P)
      List.length_replicate h1
    rw [hP.fuel_eq]
    rcases r with _ | stm
    · obtain ⟨st2m, h3⟩ := hnone rfl
      rw [h3]
      obtain ⟨h4, h5⟩ := run_toBits_ret_some h2
      simp only [Prod.mk.injEq] at h4
      obtain ⟨rfl, rfl⟩ := h4
      subst h5
      exact ⟨{ st2 with nInt := st2.nInt + 1, halted := true, aborted := true }, rfl,
        hst.upd hst.rej (by rw [hst.nInt]) hst.nNum rfl rfl hst.thrOut⟩
    · obtain ⟨st2m, h3, hstm⟩ := hsome stm rfl
      rw [h3]
      dsimp only at h2 ⊢
      obtain ⟨kH, τ2, h4, h5⟩ := run_drawNoise_bind_some h2
      obtain ⟨kL, τ3, h6, h7⟩ := run_drawNoise_bind_some h5
      rw [hP.dOutTest, h4]
      dsimp only
      rw [hP.dOutTest, h6]
      dsimp only
      have hmu0 := alg2Mu_eq hP hstm hv (Nat.zero_le _)
      have c1 : (P2.a / 2 + (P2.hA : ℝ) * (st2m.thrOut : ℝ) ≤
            F2e2e.alg2Mu P2 st2m fv 0 - (F2e2e.roundGridQ P2.hA (max (-1) (min 2 u)) : ℝ) +
              (P2.hA : ℝ) * (kH : ℝ)) ↔
          (P.a / 2 + P.hA * (stm.thrOut : ℚ) ≤ (adaMus P stm vals).getD 0 0 -
            P.hA * (roundIdxQ P.hA (clipQ (-1) 2 (P.hA * (endIdx P u : ℚ))) : ℚ) +
              P.hA * (kH : ℚ)) := by
        rw [hP.ha, hP.hhA, hstm.thrOut, hmu0, ← endpoint_eq P u]
        norm_cast
      have c2 : (P2.a / 2 + (P2.hA : ℝ) * (st2m.thrOut : ℝ) ≤
            (F2e2e.roundGridQ P2.hA (max (-1) (min 2 l)) : ℝ) - F2e2e.alg2Mu P2 st2m fv 0 +
              (P2.hA : ℝ) * (kL : ℝ)) ↔
          (P.a / 2 + P.hA * (stm.thrOut : ℚ) ≤
            P.hA * (roundIdxQ P.hA (clipQ (-1) 2 (P.hA * (endIdx P l : ℚ))) : ℚ) -
              (adaMus P stm vals).getD 0 0 + P.hA * (kL : ℚ)) := by
        rw [hP.ha, hP.hhA, hstm.thrOut, hmu0, ← endpoint_eq P l]
        norm_cast
      by_cases d1 : P.a / 2 + P.hA * (stm.thrOut : ℚ) ≤ (adaMus P stm vals).getD 0 0 -
          P.hA * (roundIdxQ P.hA (clipQ (-1) 2 (P.hA * (endIdx P u : ℚ))) : ℚ) + P.hA * (kH : ℚ)
      · rw [if_pos d1] at h7
        rw [if_pos (c1.mpr d1)]
        exact reject_sim hP hstm true h7
      · rw [if_neg d1] at h7
        rw [if_neg (fun h' => d1 (c1.mp h'))]
        by_cases d2 : P.a / 2 + P.hA * (stm.thrOut : ℚ) ≤
            P.hA * (roundIdxQ P.hA (clipQ (-1) 2 (P.hA * (endIdx P l : ℚ))) : ℚ) -
              (adaMus P stm vals).getD 0 0 + P.hA * (kL : ℚ)
        · rw [if_pos d2] at h7
          rw [if_pos (c2.mpr d2)]
          exact reject_sim hP hstm false h7
        · rw [if_neg d2] at h7
          rw [if_neg (fun h' => d2 (c2.mp h'))]
          obtain ⟨h8, h9⟩ := run_toBits_ret_some h7
          simp only [Prod.mk.injEq] at h8
          obtain ⟨rfl, rfl⟩ := h8
          subst h9
          exact ⟨st2m, rfl, hstm⟩

theorem numerical_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) {τ : List Bool} {x : AdaNum}
    {st' : AdaState} {rest : List Bool}
    (h : ((adaNumericalD P st vals).toBits (adaDraw P)).run τ = some ((x, st'), rest)) :
    ∃ st2', F2e2e.alg2Numerical P2 st2 fv τ = (numRespV2 x, st2', rest) ∧
      StCorr P st2' st' := by
  unfold adaNumericalD at h
  unfold F2e2e.alg2Numerical
  have hcond : (st2.halted = true ∨ P2.R ≤ st2.nNum) ↔ (st.halted = true ∨ P.R ≤ st.nNum) := by
    rw [hst.halted, hP.hR, hst.nNum]
  by_cases hc : st.halted = true ∨ P.R ≤ st.nNum
  · rw [if_pos hc] at h
    rw [if_pos (hcond.mpr hc)]
    obtain ⟨h1, h2⟩ := run_toBits_ret_some h
    simp only [Prod.mk.injEq] at h1
    obtain ⟨rfl, rfl⟩ := h1
    subst h2
    exact ⟨st2, rfl, hst⟩
  · rw [if_neg hc] at h
    rw [if_neg (fun h' => hc (hcond.mp h'))]
    obtain ⟨r, τ1, h1, h2⟩ := run_toBits_bind_some h
    have hst1 : StCorr P { st2 with nNum := st2.nNum + 1 } { st with nNum := st.nNum + 1 } :=
      hst.upd hst.rej hst.nInt (by rw [hst.nNum]) hst.halted hst.aborted hst.thrOut
    obtain ⟨hsome, hnone⟩ := prep_sim hP hv P.fuel _ _ _ _ hst1 (cache_init_corr P)
      List.length_replicate h1
    rw [hP.fuel_eq]
    rcases r with _ | stm
    · obtain ⟨st2m, h3⟩ := hnone rfl
      rw [h3]
      obtain ⟨h4, h5⟩ := run_toBits_ret_some h2
      simp only [Prod.mk.injEq] at h4
      obtain ⟨rfl, rfl⟩ := h4
      subst h5
      exact ⟨{ st2 with nNum := st2.nNum + 1, halted := true, aborted := true }, rfl,
        hst.upd hst.rej hst.nInt (by rw [hst.nNum]) rfl rfl hst.thrOut⟩
    · obtain ⟨st2m, h3, hstm⟩ := hsome stm rfl
      rw [h3]
      dsimp only at h2 ⊢
      obtain ⟨k, τ2, h4, h5⟩ := run_drawNoise_bind_some h2
      rw [hP.dNum, h4]
      dsimp only
      obtain ⟨h6, h7⟩ := run_toBits_ret_some h5
      simp only [Prod.mk.injEq] at h6
      obtain ⟨rfl, rfl⟩ := h6
      subst h7
      refine ⟨st2m, ?_, hstm⟩
      rw [alg2Mu_eq hP hstm hv (Nat.zero_le _), hP.hhA, ← numOut_eq]
      rfl

theorem getD_map_take {α : Type} (l : List ℕ) (f : ℕ → List α) {p j : ℕ} (hj : j < p)
    (hl : p ≤ l.length) : ((l.take p).map f).getD j [] = f (l.getD j 0) := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_take_of_lt hj,
    List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by omega)]
  rfl

theorem init_sim {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) {τ : List Bool}
    {st : AdaState} {rest : List Bool}
    (h : ((adaInitD P).toBits (adaDraw P)).run τ = some (st, rest)) :
    StCorr P (F2e2e.alg2Init P2 τ).1 st ∧ (F2e2e.alg2Init P2 τ).2 = rest := by
  unfold adaInitD at h
  obtain ⟨ks, τ1, h1, h2⟩ := run_toBits_bind_some h
  obtain ⟨k, τ2, h3, h4⟩ := run_drawNoise_bind_some h2
  obtain ⟨h5, h6⟩ := run_toBits_ret_some h4
  subst h5
  obtain ⟨thr2, h7, h8, h9⟩ := drawList_sim hP P.p 0 (fun _ => 0) h1
  have hinit : F2e2e.alg2Init P2 τ =
      ((⟨fun _ _ => 0, fun _ => 0, thr2, k, 0, 0, 0, false, false⟩ : F2e2e.Alg2State), τ2) := by
    unfold F2e2e.alg2Init
    rw [hP.hp, List.range_eq_range', h7]
    simp only [hP.dOutThr, h3]
  rw [hinit]
  have hpl : P.p ≤ P.blockSizes.length := by rw [hP.hblen]; omega
  refine ⟨?_, h6.symm⟩
  constructor
  · simp only [adaInitState, List.length_map, List.length_take, hP.hblen]; omega
  · simp only [adaInitState, List.length_map, List.length_take, hP.hblen]; omega
  · intro j hj
    simp only [adaInitState]
    rw [getD_map_take _ _ hj hpl]
    rw [List.length_replicate]
  · intro j hj
    simp only [adaInitState]
    rw [getD_map_take _ _ hj hpl, getD_map_take _ _ hj hpl]
  · simp [adaInitState]
  · simp only [adaInitState]; exact h9
  · intro j hj i hi
    simp only [adaInitState]
    rw [getD_map_take _ _ hj hpl]
    rw [List.getD_replicate _ hi]
    simp
  · intro j
    simp only [adaInitState]
    by_cases hj : j < P.p
    · rw [List.getD_replicate _ hj]
    · rw [List.getD_eq_getElem?_getD, List.getElem?_eq_none (by simp; omega)]; rfl
  · intro e
    simp only [adaInitState]
    rw [h8 e]
    by_cases he : e < P.p
    · rw [if_pos ⟨Nat.zero_le _, by omega⟩, Nat.sub_zero]
    · rw [if_neg (by omega), List.getD_eq_getElem?_getD, List.getElem?_eq_none (by omega)]; rfl
  · rfl
  · rfl
  · rfl
  · rfl
  · rfl
  · rfl

end F2e2e.B.V2
