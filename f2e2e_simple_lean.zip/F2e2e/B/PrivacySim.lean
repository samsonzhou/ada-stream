import F2e2e.B.PrivacyDefs

/-!
# Lockstep simulation of programs with draws; inlining with the final oracle states

* `DrawRel R d d'`: the programs `d`, `d'` make the same draws (same parameters, same order, for every
  outcome) and return `R`-related values; then their interpretations agree after mapping related
  outcomes to equal values (`DrawRel.interp_map`), for **every** interpretation of the draws.
* `inlineSt`: `inlineAll` returning also the final oracle states; `inlineSt_bind`, `inlineAll_eq_map`.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete

/-! ## Lockstep relation -/

/-- `d` and `d'` make the same draws and return `R`-related values. -/
inductive DrawRel {P β α γ : Type} (R : α → γ → Prop) : DrawProg P β α → DrawProg P β γ → Prop where
  | ret {a : α} {c : γ} : R a c → DrawRel R (.ret a) (.ret c)
  | draw {p : P} {k : β → DrawProg P β α} {k' : β → DrawProg P β γ} :
      (∀ y, DrawRel R (k y) (k' y)) → DrawRel R (.draw p k) (.draw p k')

namespace DrawRel

variable {P β α γ α' γ' δ : Type}

theorem mono {R R' : α → γ → Prop} {d : DrawProg P β α} {d' : DrawProg P β γ} (h : DrawRel R d d')
    (hRR : ∀ a c, R a c → R' a c) : DrawRel R' d d' := by
  induction h with
  | ret hac => exact DrawRel.ret (hRR _ _ hac)
  | draw _ ih => exact DrawRel.draw fun y => ih y

theorem bind {R : α → γ → Prop} {R' : α' → γ' → Prop} {d : DrawProg P β α} {d' : DrawProg P β γ}
    (h : DrawRel R d d') {f : α → DrawProg P β α'} {g : γ → DrawProg P β γ'}
    (hfg : ∀ a c, R a c → DrawRel R' (f a) (g c)) : DrawRel R' (d.bind f) (d'.bind g) := by
  induction h with
  | ret hac => exact hfg _ _ hac
  | draw _ ih => exact DrawRel.draw fun y => ih y

theorem interp_map {R : α → γ → Prop} {d : DrawProg P β α} {d' : DrawProg P β γ}
    (h : DrawRel R d d') (L : P → PMF β) {F : α → δ} {G : γ → δ}
    (hFG : ∀ a c, R a c → F a = G c) :
    (DrawProg.interp L d).map F = (DrawProg.interp L d').map G := by
  induction h with
  | ret hac => simp only [DrawProg.interp_ret, PMF.pure_map, hFG _ _ hac]
  | draw _ ih =>
    rw [DrawProg.interp_draw, DrawProg.interp_draw, PMF.map_bind, PMF.map_bind]
    congr 1; funext y; exact ih y

end DrawRel

/-- Associativity of `DrawProg.bind`. -/
theorem drawProg_bind_assoc {P β α γ δ : Type} (d : DrawProg P β α) (f : α → DrawProg P β γ)
    (g : γ → DrawProg P β δ) : (d.bind f).bind g = d.bind fun a => (f a).bind g := by
  induction d with
  | ret a => rfl
  | draw p k ih => simp only [DrawProg.bind_draw]; congr 1; funext b; exact ih b

/-! ## Inlining with the final oracle states -/

section InlineSt

variable {S I X P α γ : Type} [DecidableEq S]

/-- `inlineAll`, returning also the final oracle states. -/
def inlineSt (sp : S → StreamSpec I X P) (x : S → X) :
    OProg S P ℤ (SQuery I) SResp α → (S → Option ℤ) → DrawProg P ℤ (α × (S → Option ℤ))
  | .ret a, σ => .ret (a, σ)
  | .draw p k, σ => .draw p fun y => inlineSt sp x (k y) σ
  | .call s q k, σ => ((sp s).step (x s) (σ s) q).bind fun r =>
      inlineSt sp x (k r.1) (Function.update σ s r.2)

theorem inlineSt_bind (sp : S → StreamSpec I X P) (x : S → X)
    (f : α → OProg S P ℤ (SQuery I) SResp γ) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      inlineSt sp x (E.bind f) σ = (inlineSt sp x E σ).bind fun r => inlineSt sp x (f r.1) r.2
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [OProg.bind, inlineSt, DrawProg.bind_draw]
      congr 1; funext y; exact inlineSt_bind sp x f (k y) σ
  | .call s q k, σ => by
      simp only [OProg.bind, inlineSt]
      rw [drawProg_bind_assoc]
      congr 1; funext r; exact inlineSt_bind sp x f (k r.1) _

/-- `inlineAll` and `inlineSt` make the same draws and return the same outputs. -/
theorem inlineAll_rel_inlineSt (sp : S → StreamSpec I X P) (x : S → X) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      DrawRel (fun a r => a = r.1) (inlineAll sp x E σ) (inlineSt sp x E σ)
  | .ret a, σ => DrawRel.ret rfl
  | .draw p k, σ => DrawRel.draw fun y => inlineAll_rel_inlineSt sp x (k y) σ
  | .call s q k, σ => by
      simp only [inlineAll, inlineSt]
      have hrefl : ∀ d : DrawProg P ℤ (SResp × Option ℤ), DrawRel (fun a b => a = b) d d := by
        intro d
        induction d with
        | ret a => exact DrawRel.ret rfl
        | draw p k ih => exact DrawRel.draw ih
      exact (hrefl _).bind fun a c hac => by
        subst hac; exact inlineAll_rel_inlineSt sp x (k a.1) _

theorem interp_inlineAll_eq (sp : S → StreamSpec I X P) (x : S → X) (L : P → PMF ℤ)
    (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ) :
    DrawProg.interp L (inlineAll sp x E σ) = (DrawProg.interp L (inlineSt sp x E σ)).map Prod.fst := by
  have h := (inlineAll_rel_inlineSt sp x E σ).interp_map L (F := id) (G := Prod.fst)
    (fun a r har => har)
  rwa [PMF.map_id] at h

end InlineSt

end F2e2e.B.Priv
