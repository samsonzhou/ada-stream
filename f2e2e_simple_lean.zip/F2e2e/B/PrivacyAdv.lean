import F2e2e.B.PrivacyDefs
import F2e2e.Lib.DP.Advanced

/-!
# Privacy (P2)–(P4): indistinguishability of discrete laws; advanced composition for `DrawProg`

* `PIndist` API: `mono`, `refl`, `trans` (hybrid chaining), `map` (post-processing), `bind_right`
  (mixture over a common law), `of_ratioLE` (pure DP), `of_one_le`, `tv_transfer` ((P4),
  `partII.tex` L1026–1030), `indist` (bridge to `F2e2e.DP.Indist`).
* `kov_pmf`: the Kairouz–Oh–Viswanath decomposition of a pointwise `e^ρ`-close pair of PMFs.
* `interp_eq_sum_bits`: if every draw law is the mixture `w A + (1-w) B`, then the output law of a
  program with at most `C` draws is the `w`-weighted mixture over bit strings `b : Fin C → Bool` of the
  bit-selected interpretations `interpBits A B prog b`.
* `drawProg_advComp_tail`, `drawProg_advComp`: advanced composition for adaptive programs with draws
  (as `F2e2e.DP.indist_advCompK_tail`, now for PMFs and `DrawProg`).
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.DP.Adv ENNReal

/-! ## Indistinguishability of discrete laws: API -/

section PIndistAPI

variable {α γ : Type*} {p q r : PMF α} {ε ε' ε₁ ε₂ δ δ' δ₁ δ₂ : ℝ}

theorem PIndist.mono (h : PIndist p q ε δ) (hε : ε ≤ ε') (hδ : δ ≤ δ') : PIndist p q ε' δ' := by
  intro E
  calc p.toOuterMeasure E ≤ ENNReal.ofReal (Real.exp ε) * q.toOuterMeasure E + ENNReal.ofReal δ :=
        h E
    _ ≤ ENNReal.ofReal (Real.exp ε') * q.toOuterMeasure E + ENNReal.ofReal δ' := by gcongr

/-- Every law is `(ε, δ)`-indistinguishable from itself for `ε ≥ 0`. -/
theorem PIndist.refl (p : PMF α) (hε : 0 ≤ ε) (δ : ℝ) : PIndist p p ε δ := by
  intro E
  calc p.toOuterMeasure E = 1 * p.toOuterMeasure E := (one_mul _).symm
    _ ≤ ENNReal.ofReal (Real.exp ε) * p.toOuterMeasure E := by
        gcongr
        rw [← ENNReal.ofReal_one]
        exact ENNReal.ofReal_le_ofReal (Real.one_le_exp hε)
    _ ≤ _ := le_self_add

/-- Events of a PMF have probability at most one. -/
theorem pmf_toOuterMeasure_le_one (p : PMF α) (E : Set α) : p.toOuterMeasure E ≤ 1 := by
  rw [PMF.toOuterMeasure_apply]
  exact (ENNReal.tsum_le_tsum fun a => Set.indicator_le_self E p a).trans p.tsum_coe.le

/-- Any two laws are `(ε, δ)`-indistinguishable for `δ ≥ 1`. -/
theorem PIndist.of_one_le (p q : PMF α) (hδ : 1 ≤ δ) : PIndist p q ε δ := by
  intro E
  calc p.toOuterMeasure E ≤ 1 := pmf_toOuterMeasure_le_one p E
    _ ≤ ENNReal.ofReal δ := by rw [← ENNReal.ofReal_one]; exact ENNReal.ofReal_le_ofReal hδ
    _ ≤ _ := le_add_self

/-- Hybrid chaining: `(ε₁, δ₁)` then `(ε₂, δ₂)` gives `(ε₁ + ε₂, δ₁ + e^{ε₁} δ₂)`. -/
theorem PIndist.trans (h₁ : PIndist p q ε₁ δ₁) (h₂ : PIndist q r ε₂ δ₂) (hδ₁ : 0 ≤ δ₁)
    (hδ₂ : 0 ≤ δ₂) : PIndist p r (ε₁ + ε₂) (δ₁ + Real.exp ε₁ * δ₂) := by
  intro E
  have hd : ENNReal.ofReal (δ₁ + Real.exp ε₁ * δ₂) =
      ENNReal.ofReal δ₁ + ENNReal.ofReal (Real.exp ε₁) * ENNReal.ofReal δ₂ := by
    rw [ENNReal.ofReal_add hδ₁ (mul_nonneg (Real.exp_pos _).le hδ₂),
      ENNReal.ofReal_mul (Real.exp_pos _).le]
  have he : ENNReal.ofReal (Real.exp (ε₁ + ε₂)) =
      ENNReal.ofReal (Real.exp ε₁) * ENNReal.ofReal (Real.exp ε₂) := by
    rw [Real.exp_add, ENNReal.ofReal_mul (Real.exp_pos _).le]
  calc p.toOuterMeasure E
      ≤ ENNReal.ofReal (Real.exp ε₁) * q.toOuterMeasure E + ENNReal.ofReal δ₁ := h₁ E
    _ ≤ ENNReal.ofReal (Real.exp ε₁) *
          (ENNReal.ofReal (Real.exp ε₂) * r.toOuterMeasure E + ENNReal.ofReal δ₂) +
          ENNReal.ofReal δ₁ := by gcongr; exact h₂ E
    _ = ENNReal.ofReal (Real.exp (ε₁ + ε₂)) * r.toOuterMeasure E +
          ENNReal.ofReal (δ₁ + Real.exp ε₁ * δ₂) := by rw [hd, he]; ring

/-- Post-processing. -/
theorem PIndist.map (h : PIndist p q ε δ) (f : α → γ) : PIndist (p.map f) (q.map f) ε δ := by
  intro E
  rw [PMF.toOuterMeasure_map_apply, PMF.toOuterMeasure_map_apply]
  exact h _

/-- Injective relabelling can be undone. -/
theorem PIndist.of_map_injective {f : α → γ} (hf : Function.Injective f)
    (h : PIndist (p.map f) (q.map f) ε δ) : PIndist p q ε δ := by
  intro E
  have := h (f '' E)
  rwa [PMF.toOuterMeasure_map_apply, PMF.toOuterMeasure_map_apply,
    Set.preimage_image_eq E hf] at this

/-- Mixture over a common law (independent randomness or data outside the selected block). -/
theorem PIndist.bind_right (μ : PMF γ) {f g : γ → PMF α} (h : ∀ c, PIndist (f c) (g c) ε δ) :
    PIndist (μ.bind f) (μ.bind g) ε δ := by
  intro E
  rw [PMF.toOuterMeasure_bind_apply, PMF.toOuterMeasure_bind_apply]
  calc ∑' c, μ c * (f c).toOuterMeasure E
      ≤ ∑' c, μ c * (ENNReal.ofReal (Real.exp ε) * (g c).toOuterMeasure E + ENNReal.ofReal δ) :=
        ENNReal.tsum_le_tsum fun c => by gcongr; exact h c E
    _ = ENNReal.ofReal (Real.exp ε) * ∑' c, μ c * (g c).toOuterMeasure E + ENNReal.ofReal δ := by
        simp_rw [mul_add]
        rw [ENNReal.tsum_add, ENNReal.tsum_mul_right, μ.tsum_coe, one_mul, ← ENNReal.tsum_mul_left]
        congr 1
        exact tsum_congr fun c => by ring

/-- Pure DP of discrete laws (pointwise ratio `e^ε`) gives `(ε, 0)`. -/
theorem PIndist.of_ratioLE (h : RatioLE p q (ENNReal.ofReal (Real.exp ε))) :
    PIndist p q ε 0 := by
  intro E
  rw [ENNReal.ofReal_zero, add_zero]
  exact h.toOuterMeasure_le E

/-- (P4) TV transfer (`partII.tex` L1026–1030): if the ideal laws `p', q'` are `(ε, δ)`-close and the
actual laws are within TV `η` of them, the actual laws are `(ε, δ + (1 + e^ε) η)`-close. -/
theorem PIndist.tv_transfer {p p' q q' : PMF α} {η : ℝ} (hδ : 0 ≤ δ) (hη : 0 ≤ η)
    (hp : tv p p' ≤ ENNReal.ofReal η) (hq : tv q' q ≤ ENNReal.ofReal η) (h : PIndist p' q' ε δ) :
    PIndist p q ε (δ + (1 + Real.exp ε) * η) := by
  intro E
  have h1 := toOuterMeasure_le_add_tv p p' E
  have h2 := toOuterMeasure_le_add_tv q' q E
  have h3 := h E
  have hsplit : ENNReal.ofReal (δ + (1 + Real.exp ε) * η) =
      ENNReal.ofReal δ + ENNReal.ofReal η + ENNReal.ofReal (Real.exp ε) * ENNReal.ofReal η := by
    have he := (Real.exp_pos ε).le
    rw [ENNReal.ofReal_add hδ (by positivity), add_mul, one_mul,
      ENNReal.ofReal_add hη (by positivity), ENNReal.ofReal_mul he]
    ring
  calc p.toOuterMeasure E ≤ p'.toOuterMeasure E + ENNReal.ofReal η := h1.trans (by gcongr)
    _ ≤ (ENNReal.ofReal (Real.exp ε) * q'.toOuterMeasure E + ENNReal.ofReal δ) +
          ENNReal.ofReal η := by gcongr
    _ ≤ (ENNReal.ofReal (Real.exp ε) * (q.toOuterMeasure E + ENNReal.ofReal η) +
          ENNReal.ofReal δ) + ENNReal.ofReal η := by
        gcongr; exact h2.trans (by gcongr)
    _ = ENNReal.ofReal (Real.exp ε) * q.toOuterMeasure E +
          ENNReal.ofReal (δ + (1 + Real.exp ε) * η) := by
        rw [hsplit]; ring

/-- Bridge to the fixed interface `F2e2e.DP.Indist` (any measurable space on the outcomes). -/
theorem PIndist.indist [MeasurableSpace α] (h : PIndist p q ε δ) :
    DP.Indist p.toMeasure q.toMeasure ε δ := by
  intro E hE
  rw [p.toMeasure_apply_eq_toOuterMeasure_apply hE, q.toMeasure_apply_eq_toOuterMeasure_apply hE]
  exact h E

end PIndistAPI

/-! ## The KOV decomposition of a pointwise `e^ρ`-close pair of PMFs -/

/-- **KOV decomposition** (PMF form): if `p ≤ e^ρ q` and `q ≤ e^ρ p` pointwise (`ρ > 0`), then
`p = a A + (1-a) B` and `q = (1-a) A + a B` pointwise for PMFs `A, B`, `a = kovA ρ = e^ρ/(e^ρ+1)`. -/
theorem kov_pmf {β : Type*} (p q : PMF β) {ρ : ℝ} (hρ : 0 < ρ)
    (h₁ : RatioLE p q (ENNReal.ofReal (Real.exp ρ))) (h₂ : RatioLE q p (ENNReal.ofReal (Real.exp ρ))) :
    ∃ A B : PMF β, (∀ b, p b = ENNReal.ofReal (kovA ρ) * A b + ENNReal.ofReal (1 - kovA ρ) * B b) ∧
      (∀ b, q b = ENNReal.ofReal (1 - kovA ρ) * A b + ENNReal.ofReal (kovA ρ) * B b) := by
  set r := Real.exp (-ρ) with hr_def
  have hr0 : 0 ≤ r := (Real.exp_pos _).le
  have hr1 : r < 1 := Real.exp_lt_one_iff.2 (by linarith)
  have h1r : 0 < 1 - r := by linarith
  -- domination `r q ≤ p` and `r p ≤ q`
  have hdom : ∀ (u v : PMF β), RatioLE v u (ENNReal.ofReal (Real.exp ρ)) →
      ∀ b, ENNReal.ofReal r * v b ≤ u b := by
    intro u v h b
    calc ENNReal.ofReal r * v b ≤ ENNReal.ofReal r * (ENNReal.ofReal (Real.exp ρ) * u b) := by
          gcongr; exact h b
      _ = u b := by
          rw [← mul_assoc, ← ENNReal.ofReal_mul hr0, hr_def, ← Real.exp_add, neg_add_cancel,
            Real.exp_zero, ENNReal.ofReal_one, one_mul]
  -- the components are probability mass functions
  have hpmf : ∀ (u v : PMF β), (∀ b, ENNReal.ofReal r * v b ≤ u b) →
      HasSum (fun b => (ENNReal.ofReal (1 - r))⁻¹ * (u b - ENNReal.ofReal r * v b)) 1 := by
    intro u v huv
    have hsum : ∑' b, (u b - ENNReal.ofReal r * v b) = ENNReal.ofReal (1 - r) := by
      have hadd : ∑' b, (u b - ENNReal.ofReal r * v b) + ∑' b, ENNReal.ofReal r * v b = 1 := by
        rw [← ENNReal.tsum_add]
        simp_rw [tsub_add_cancel_of_le (huv _)]
        exact u.tsum_coe
      rw [ENNReal.tsum_mul_left, v.tsum_coe, mul_one] at hadd
      rw [ENNReal.ofReal_sub _ hr0, ENNReal.ofReal_one]
      exact ENNReal.eq_sub_of_add_eq ENNReal.ofReal_ne_top hadd
    have : ∑' b, (ENNReal.ofReal (1 - r))⁻¹ * (u b - ENNReal.ofReal r * v b) = 1 := by
      rw [ENNReal.tsum_mul_left, hsum]
      exact ENNReal.inv_mul_cancel (ENNReal.ofReal_pos.2 h1r).ne' ENNReal.ofReal_ne_top
    exact this ▸ ENNReal.summable.hasSum
  have hqp := hdom p q h₂
  have hpq := hdom q p h₁
  refine ⟨⟨_, hpmf p q hqp⟩, ⟨_, hpmf q p hpq⟩, fun b => ?_, fun b => ?_⟩
  · have ha : kovA ρ * (1 + r) = 1 := by
      unfold kovA; rw [hr_def, Real.exp_neg]; field_simp
    exact kov_identity (PMF.apply_ne_top p b) (PMF.apply_ne_top q b) hr0 hr1 (hqp b) (hpq b) ha
  · have ha : kovA ρ * (1 + r) = 1 := by
      unfold kovA; rw [hr_def, Real.exp_neg]; field_simp
    show q b = ENNReal.ofReal (1 - kovA ρ) * ((ENNReal.ofReal (1 - r))⁻¹ * (p b - ENNReal.ofReal r * q b)) +
      ENNReal.ofReal (kovA ρ) * ((ENNReal.ofReal (1 - r))⁻¹ * (q b - ENNReal.ofReal r * p b))
    rw [add_comm]
    exact kov_identity (PMF.apply_ne_top q b) (PMF.apply_ne_top p b) hr0 hr1 (hpq b) (hqp b) ha

/-! ## Bit-string decomposition of the interpretation of a program -/

section Bits

variable {P β α : Type}

/-- Interpretation in which the `i`-th draw along the path uses `A` (bit `true`) or `B` (bit `false`)
according to the `i`-th bit (`A` once the bits run out). -/
noncomputable def interpBits (A B : P → PMF β) : DrawProg P β α → List Bool → PMF α
  | .ret a, _ => PMF.pure a
  | .draw p k, [] => (A p).bind fun y => interpBits A B (k y) []
  | .draw p k, b :: bs => (cond b (A p) (B p)).bind fun y => interpBits A B (k y) bs

lemma bitWeight_cons (w : ℝ) {C : ℕ} (b : Fin C → Bool) (β : Bool) :
    bitWeight w (Fin.cons β b : Fin (C + 1) → Bool) = (if β then w else 1 - w) * bitWeight w b := by
  simp only [bitWeight, Fin.prod_univ_succ, Fin.cons_zero, Fin.cons_succ]

/-- **Bit-string decomposition**: if every draw law is the mixture `w A + (1-w) B`, then the output
law of a program with at most `C` draws is the `w`-weighted mixture of the bit-selected
interpretations. -/
theorem interp_eq_sum_bits (L A B : P → PMF β) {w : ℝ} (hw0 : 0 ≤ w) (hw1 : w ≤ 1)
    (hL : ∀ p y, L p y = ENNReal.ofReal w * A p y + ENNReal.ofReal (1 - w) * B p y) :
    ∀ (prog : DrawProg P β α) {C : ℕ}, prog.DrawsLE C → ∀ o,
      DrawProg.interp L prog o =
        ∑ b : Fin C → Bool, ENNReal.ofReal (bitWeight w b) * interpBits A B prog (List.ofFn b) o := by
  intro prog
  induction prog with
  | ret a =>
    intro C _ o
    simp only [DrawProg.interp_ret, interpBits]
    rw [← Finset.sum_mul, ← ENNReal.ofReal_sum_of_nonneg (fun b _ => bitWeight_nonneg hw0 hw1 b),
      sum_bitWeight, ENNReal.ofReal_one, one_mul]
  | draw p k ih =>
    intro C hC o
    cases C with
    | zero => exact absurd hC (by simp [DrawProg.DrawsLE])
    | succ C =>
      have hk : ∀ y, (k y).DrawsLE C := hC
      have hcons : ∀ (β' : Bool) (x : Fin C → Bool),
          bitWeight w ((Fin.consEquiv fun _ => Bool) (β', x)) =
            (if β' then w else 1 - w) * bitWeight w x := by
        intro β' x
        simp only [bitWeight, Fin.prod_univ_succ, Fin.consEquiv_apply, Fin.cons_zero, Fin.cons_succ]
      rw [DrawProg.interp_draw, PMF.bind_apply]
      simp_rw [ih _ (hk _) o]
      rw [← (Fin.consEquiv (fun _ : Fin (C + 1) => Bool)).sum_comp, Fintype.sum_prod_type,
        Fintype.sum_bool]
      simp only [hcons, Fin.consEquiv_apply, List.ofFn_succ, Fin.cons_zero, Fin.cons_succ,
        interpBits, cond_true, cond_false, if_true, Bool.false_eq_true, if_false, PMF.bind_apply]
      simp_rw [ENNReal.ofReal_mul hw0, ENNReal.ofReal_mul (sub_nonneg.2 hw1), hL, add_mul,
        Finset.mul_sum, ENNReal.tsum_add]
      rw [← Finset.sum_add_distrib, Summable.tsum_finsetSum (fun _ _ => ENNReal.summable),
        Summable.tsum_finsetSum (fun _ _ => ENNReal.summable), ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun b _ => ?_
      rw [← ENNReal.tsum_mul_left, ← ENNReal.tsum_mul_left]
      congr 1
      · exact tsum_congr fun y => by ring
      · exact tsum_congr fun y => by ring

/-- Events: the bit-string decomposition of the output law, evaluated on an event. -/
theorem toOuterMeasure_eq_sum_bits {C : ℕ} (p : PMF α) (R : (Fin C → Bool) → PMF α) (c : (Fin C → Bool) → ℝ≥0∞)
    (hd : ∀ o, p o = ∑ b, c b * R b o) (E : Set α) :
    p.toOuterMeasure E = ∑ b, c b * (R b).toOuterMeasure E := by
  classical
  simp only [PMF.toOuterMeasure_apply, Set.indicator_apply]
  calc ∑' o, (if o ∈ E then p o else 0) = ∑' o, ∑ b, c b * (if o ∈ E then R b o else 0) := by
        refine tsum_congr fun o => ?_
        by_cases ho : o ∈ E
        · simp [ho, hd o]
        · simp [ho]
    _ = ∑ b, c b * ∑' o, (if o ∈ E then R b o else 0) := by
        rw [Summable.tsum_finsetSum (fun _ _ => ENNReal.summable)]
        exact Finset.sum_congr rfl fun b _ => ENNReal.tsum_mul_left

end Bits

/-! ## Advanced composition for programs with draws -/

/-- Degenerate cases: for `ρ = 0` or `C = 0` the two output laws coincide. -/
theorem interp_eq_of_degenerate {P β α : Type} (L L' : P → PMF β) {ρ : ℝ}
    (h₁ : ∀ p, RatioLE (L p) (L' p) (ENNReal.ofReal (Real.exp ρ)))
    (h₂ : ∀ p, RatioLE (L' p) (L p) (ENNReal.ofReal (Real.exp ρ)))
    {prog : DrawProg P β α} {C : ℕ} (hC : prog.DrawsLE C) (hdeg : ρ = 0 ∨ C = 0) :
    DrawProg.interp L prog = DrawProg.interp L' prog := by
  rcases hdeg with h | h
  · subst h
    have hLL : L = L' := funext fun p => PMF.ext fun y =>
      le_antisymm (by simpa using h₁ p y) (by simpa using h₂ p y)
    rw [hLL]
  · subst h
    cases prog with
    | ret a => rfl
    | draw p k => exact absurd hC (by simp [DrawProg.DrawsLE])

/-- **Advanced composition for adaptive programs** (tail form): if the two laws of every draw are
pointwise within the factor `e^ρ` of each other (both directions) and the program makes at most `C`
draws on every path, then the two output laws are
`(t + C ρ (e^ρ − 1)/(e^ρ + 1), exp(−t²/(2Cρ²)))`-indistinguishable for every `t ≥ 0`. -/
theorem drawProg_advComp_tail {P β α : Type} (L L' : P → PMF β) {ρ : ℝ} (hρ : 0 ≤ ρ)
    (h₁ : ∀ p, RatioLE (L p) (L' p) (ENNReal.ofReal (Real.exp ρ)))
    (h₂ : ∀ p, RatioLE (L' p) (L p) (ENNReal.ofReal (Real.exp ρ)))
    {prog : DrawProg P β α} {C : ℕ} (hC : prog.DrawsLE C) {t : ℝ} (ht : 0 ≤ t) :
    PIndist (DrawProg.interp L prog) (DrawProg.interp L' prog)
      (t + C * ρ * ((Real.exp ρ - 1) / (Real.exp ρ + 1))) (Real.exp (-t ^ 2 / (2 * C * ρ ^ 2))) := by
  have hε' : 0 ≤ t + C * ρ * ((Real.exp ρ - 1) / (Real.exp ρ + 1)) := by
    have : 0 ≤ Real.exp ρ - 1 := by linarith [Real.one_le_exp hρ]
    positivity
  by_cases hdeg : ρ = 0 ∨ C = 0
  · rw [interp_eq_of_degenerate L L' h₁ h₂ hC hdeg]
    exact PIndist.refl _ hε' _
  obtain ⟨hρ0, hC0⟩ := not_or.1 hdeg
  have hρpos : 0 < ρ := lt_of_le_of_ne hρ (Ne.symm hρ0)
  have hCpos : 0 < C := Nat.pos_of_ne_zero hC0
  have ha0 : 0 ≤ kovA ρ := (kovA_pos ρ).le
  have ha1 : kovA ρ ≤ 1 := (kovA_lt_one ρ).le
  choose A B hA hB using fun p => kov_pmf (L p) (L' p) hρpos (h₁ p) (h₂ p)
  have hdL := interp_eq_sum_bits L A B ha0 ha1 hA prog hC
  have h1a : (1 : ℝ) - (1 - kovA ρ) = kovA ρ := by ring
  have hB' : ∀ p y, L' p y = ENNReal.ofReal (1 - kovA ρ) * A p y +
      ENNReal.ofReal (1 - (1 - kovA ρ)) * B p y := fun p y => by rw [h1a]; exact hB p y
  have hdL' := interp_eq_sum_bits L' A B (w := 1 - kovA ρ) (by linarith) (by linarith) hB' prog hC
  intro E
  rw [toOuterMeasure_eq_sum_bits _ _ _ hdL E, toOuterMeasure_eq_sum_bits _ _ _ hdL' E,
    ← two_kovA_sub_one]
  set R : (Fin C → Bool) → ℝ≥0∞ := fun b =>
    (interpBits A B prog (List.ofFn b)).toOuterMeasure E with hR
  have hR1 : ∀ b, R b ≤ 1 := fun b => pmf_toOuterMeasure_le_one _ E
  have hterm : ∀ b : Fin C → Bool,
      ENNReal.ofReal (bitWeight (kovA ρ) b) * R b ≤
        ENNReal.ofReal (Real.exp (t + C * ρ * (2 * kovA ρ - 1))) *
            (ENNReal.ofReal (bitWeight (1 - kovA ρ) b) * R b) +
          ENNReal.ofReal (if t + C * ρ * (2 * kovA ρ - 1) < ρ * bitSign b
            then bitWeight (kovA ρ) b else 0) := by
    intro b
    split_ifs with hb
    · calc ENNReal.ofReal (bitWeight (kovA ρ) b) * R b
          ≤ ENNReal.ofReal (bitWeight (kovA ρ) b) * 1 := by gcongr; exact hR1 b
        _ = ENNReal.ofReal (bitWeight (kovA ρ) b) := mul_one _
        _ ≤ _ := le_add_self
    · replace hb := not_lt.1 hb
      calc ENNReal.ofReal (bitWeight (kovA ρ) b) * R b
          ≤ ENNReal.ofReal (Real.exp (t + C * ρ * (2 * kovA ρ - 1)) * bitWeight (1 - kovA ρ) b) *
              R b := by
            gcongr
            rw [bitWeight_eq_exp_mul]
            exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.2 hb)
              (bitWeight_nonneg (by linarith) (by linarith) b)
        _ = ENNReal.ofReal (Real.exp (t + C * ρ * (2 * kovA ρ - 1))) *
              (ENNReal.ofReal (bitWeight (1 - kovA ρ) b) * R b) := by
            rw [ENNReal.ofReal_mul (Real.exp_pos _).le, mul_assoc]
        _ ≤ _ := le_self_add
  calc ∑ b, ENNReal.ofReal (bitWeight (kovA ρ) b) * R b
      ≤ ∑ b, (ENNReal.ofReal (Real.exp (t + C * ρ * (2 * kovA ρ - 1))) *
            (ENNReal.ofReal (bitWeight (1 - kovA ρ) b) * R b) +
          ENNReal.ofReal (if t + C * ρ * (2 * kovA ρ - 1) < ρ * bitSign b
            then bitWeight (kovA ρ) b else 0)) := Finset.sum_le_sum fun b _ => hterm b
    _ = ENNReal.ofReal (Real.exp (t + C * ρ * (2 * kovA ρ - 1))) *
            ∑ b, ENNReal.ofReal (bitWeight (1 - kovA ρ) b) * R b +
          ENNReal.ofReal (∑ b : Fin C → Bool, if t + C * ρ * (2 * kovA ρ - 1) < ρ * bitSign b
            then bitWeight (kovA ρ) b else 0) := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum, ENNReal.ofReal_sum_of_nonneg]
        intro b _
        split_ifs
        · exact bitWeight_nonneg ha0 ha1 b
        · exact le_rfl
    _ ≤ _ := by
        gcongr
        exact bit_tail hρpos hCpos ht

/-- **Advanced composition for adaptive programs**, Part II form (paper ext. 21, L1016–1019):
`(2Cρ² + ρ√(2Cχ), e^{-χ})`. -/
theorem drawProg_advComp {P β α : Type} (L L' : P → PMF β) {ρ : ℝ} (hρ : 0 ≤ ρ)
    (h₁ : ∀ p, RatioLE (L p) (L' p) (ENNReal.ofReal (Real.exp ρ)))
    (h₂ : ∀ p, RatioLE (L' p) (L p) (ENNReal.ofReal (Real.exp ρ)))
    {prog : DrawProg P β α} {C : ℕ} (hC : prog.DrawsLE C) (χ : ℝ) :
    PIndist (DrawProg.interp L prog) (DrawProg.interp L' prog)
      (2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ)) (Real.exp (-χ)) := by
  have hε' : 0 ≤ 2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ) := by positivity
  by_cases hdeg : ρ = 0 ∨ C = 0
  · rw [interp_eq_of_degenerate L L' h₁ h₂ hC hdeg]
    exact PIndist.refl _ hε' _
  obtain ⟨hρ0, hC0⟩ := not_or.1 hdeg
  have hρpos : 0 < ρ := lt_of_le_of_ne hρ (Ne.symm hρ0)
  have hCpos : (0 : ℝ) < C := Nat.cast_pos.2 (Nat.pos_of_ne_zero hC0)
  rcases lt_or_ge χ 0 with hχ | hχ
  · exact PIndist.of_one_le _ _ (by rw [← Real.exp_zero]; exact Real.exp_le_exp.2 (by linarith))
  set t := ρ * Real.sqrt (2 * C * χ) with ht_def
  have ht : 0 ≤ t := mul_nonneg hρ (Real.sqrt_nonneg _)
  refine (drawProg_advComp_tail L L' hρ h₁ h₂ hC ht).mono ?_ (le_of_eq ?_)
  · have h1 : (C : ℝ) * ρ * ((Real.exp ρ - 1) / (Real.exp ρ + 1)) ≤ C * ρ * ρ :=
      mul_le_mul_of_nonneg_left (tanh_half_le hρ) (by positivity)
    nlinarith
  · have ht2 : t ^ 2 = 2 * C * χ * ρ ^ 2 := by
      rw [ht_def, mul_pow, Real.sq_sqrt (by positivity)]; ring
    rw [ht2]
    congr 1
    field_simp

end F2e2e.B.Priv
