import F2e2e.Spec

/-!
# Part II, Definition `R:def:sec3_ada_params` (Capped-Simplex Validation ADA Parameter Schedule)

`parts/partII.tex` L666–717 (Definition 3.1, the lattice law L703–706 and the bounded sampler
L708–716). This file is the **paper form**: every parameter is a real (or natural) number defined
from the requested accuracy `aReq`, the requested failure probability `ξReq` and the caps `M, J, R`,
literally as in the LaTeX, reusing the Spec's definitions `valP`, `valTau`, `valH`, `valTmax`,
`valQ`, `valChi` verbatim. (The computable integer form used by the mechanism is
`F2e2e.B.AdaParams` in `F2e2e/B/ArchParams.lean`, with bridge lemmas to this file.)

| paper (L) | Lean |
|---|---|
| `a = 2^{-⌈log₂(1/a_req)⌉}`, `ξ_A = 2^{-⌈log₂(1/ξ_req)⌉}` (L668–670) | `alg2A`, `alg2XiA` |
| least `p ≥ 2` with `4^{p-1}(a/(8p))² ≥ 1` (L671) | `alg2P` (= `valP a`) |
| `τ = a/(8p)`, `h = τ/64`, `κ = τ/4`, `T_j^max = ⌈6/(4^j τ²)⌉` (L672–675) | `alg2Tau`, `alg2H`, `alg2Kappa`, `alg2Tmax` |
| out-of-range `T_j^max = 0` (L675) | `alg2Tmax` (`j ≥ p`), `alg2TmaxZ` (`j < 0`) |
| `Δ_root = p(τ + 2h) + 1.5h` (L677) | `alg2DeltaRoot` |
| `C_0, C_j, C_p, Q, ξ_j, δ, χ` (L680–688) | `alg2C`, `alg2Q`, `alg2XiJ`, `alg2Delta`, `alg2Chi` |
| `d_j`, `ϑ_j = 1/d_j`, `λ_j = 4^j`, `θ_j` (L689) | `alg2D`, `alg2Vartheta`, `alg2Lambda`, `alg2Theta` |
| `n_j = ⌈2^20 χ d_j ⌈√(C_j χ)⌉/h + 2^12 χ/h²⌉` (L690–692) | `alg2NBlock` |
| `N = ∑_{j=0}^p n_j` (L647) | `alg2N` |
| largest dyadic `h_A ≤ min{h/(2^20(p+1)χ), 1/(2^20 max_j n_j)}` (L693–696) | `alg2HAExp`, `alg2HA` |
| `b_int = h/(128χ)`, `b_out = a/(512χ)`, `b_num = a/(64χ)` (L697–700) | `alg2BInt`, `alg2BOut`, `alg2BNum` |
| `ϱ = b/(b + h_A)` (L705) | `alg2Rho` |
| `ζ = δ/(1000Q)`, `B_0`, `K_s`, `r_s` (L708–711) | `alg2Zeta`, `alg2B0`, `alg2Ks`, `alg2Rs` |

"Largest dyadic" is read as the largest power of two `2^{-q}`, `q ∈ ℕ` (paper map II.3.1, item 8);
it is `dyadicDown` of the minimum (`dyadicDown x` is the largest `2^{-q} ≤ x` for `0 < x ≤ 1`).
All logarithms in Definition 3.1 are `log₂` (`Real.logb 2`).
-/

namespace F2e2e.B

/-! ## Dyadic inputs (`R:eq:sec3_dyadic_inputs`, L668–671) -/

/-- The dyadic accuracy `a = 2^{-⌈log₂(1/a_req)⌉}`. -/
noncomputable def alg2A (aReq : ℝ) : ℝ := dyadicDown aReq

/-- The dyadic failure probability `ξ_A = 2^{-⌈log₂(1/ξ_req)⌉}`. -/
noncomputable def alg2XiA (ξReq : ℝ) : ℝ := dyadicDown ξReq

/-! ## Levels, margins and correction caps (`R:eq:sec3_tau_p_def`, L671–675) -/

/-- The number of learned levels: the least `p ≥ 2` with `4^{p-1}(a/(8p))² ≥ 1` (Spec `valP`). -/
noncomputable def alg2P (aReq : ℝ) : ℕ := valP (alg2A aReq)

/-- `τ = a/(8p)` (Spec `valTau`). -/
noncomputable def alg2Tau (aReq : ℝ) : ℝ := valTau (alg2A aReq)

/-- The comparator accuracy `h = τ/64` (Spec `valH`). -/
noncomputable def alg2H (aReq : ℝ) : ℝ := valH (alg2A aReq)

/-- The learner step size `κ = τ/4`. -/
noncomputable def alg2Kappa (aReq : ℝ) : ℝ := alg2Tau aReq / 4

/-- The correction cap of edge `j`: `T_j^max = ⌈6/(4^j τ²)⌉` for `0 ≤ j < p` (Spec `valTmax`),
and `0` out of range (L675: "Out-of-range `T_j^max`'s are zero"). -/
noncomputable def alg2Tmax (aReq : ℝ) (j : ℕ) : ℕ :=
  if j < alg2P aReq then valTmax (alg2A aReq) j else 0

/-- `T_j^max` for an integer index `j`, zero for `j < 0` and for `j ≥ p` (L675). -/
noncomputable def alg2TmaxZ (aReq : ℝ) (j : ℤ) : ℕ :=
  if 0 ≤ j then alg2Tmax aReq j.toNat else 0

/-! ## Internal error budget (`R:eq:sec3_internal_error_budget`, L676–678) -/

/-- `Δ_root = p(τ + 2h) + 1.5h`. -/
noncomputable def alg2DeltaRoot (aReq : ℝ) : ℝ :=
  (alg2P aReq : ℝ) * (alg2Tau aReq + 2 * alg2H aReq) + 3 / 2 * alg2H aReq

/-! ## Phase counts, draw budget, failure split, χ (`R:eq:sec3_C_Q_chi`, L680–688) -/

/-- The phase-count budgets `C_0 = T_0^max + T_1^max + J + R + 2`,
`C_j = T_{j-2}^max + 2T_{j-1}^max + 2T_j^max + T_{j+1}^max + 2` (`1 ≤ j < p`),
`C_p = T_{p-2}^max + T_{p-1}^max + 1` (and `0` for `j > p`, unused). -/
noncomputable def alg2C (J R : ℕ) (aReq : ℝ) (j : ℕ) : ℕ :=
  if j = 0 then alg2Tmax aReq 0 + alg2Tmax aReq 1 + J + R + 2
  else if j < alg2P aReq then
    alg2TmaxZ aReq ((j : ℤ) - 2) + 2 * alg2TmaxZ aReq ((j : ℤ) - 1) + 2 * alg2Tmax aReq j +
      alg2Tmax aReq (j + 1) + 2
  else if j = alg2P aReq then
    alg2TmaxZ aReq ((j : ℤ) - 2) + alg2TmaxZ aReq ((j : ℤ) - 1) + 1
  else 0

/-- The scalar-draw budget `Q = 100(p+1)(M + R + J + 2 + ∑_{j<p} T_j^max)` (Spec `valQ`). -/
noncomputable def alg2Q (M J R : ℕ) (aReq : ℝ) : ℕ := valQ M J R (alg2A aReq)

/-- The per-block failure budget `ξ_j = ξ_A/(8(p+1))` (the same for every block `j`). -/
noncomputable def alg2XiJ (aReq ξReq : ℝ) : ℝ := alg2XiA ξReq / (8 * ((alg2P aReq : ℝ) + 1))

/-- The block-DP delta `δ = h ξ_j / 24`. -/
noncomputable def alg2Delta (aReq ξReq : ℝ) : ℝ := alg2H aReq * alg2XiJ aReq ξReq / 24

/-- `χ = ⌈log₂(2^40 (p+1) Q/(h ξ_A))⌉` (Spec `valChi`). -/
noncomputable def alg2Chi (M J R : ℕ) (aReq ξReq : ℝ) : ℕ :=
  valChi M J R (alg2A aReq) (alg2XiA ξReq)

/-! ## Block privacy parameters (L689) -/

/-- `d_j = ⌈√(p 4^j)⌉` for `j < p` and `d_p = ⌈4/h⌉` (also returned for `j > p`, unused). -/
noncomputable def alg2D (aReq : ℝ) (j : ℕ) : ℕ :=
  if j < alg2P aReq then ⌈Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j)⌉₊ else ⌈4 / alg2H aReq⌉₊

/-- The privacy parameter of block `S_j`: `ϑ_j = 1/d_j`. -/
noncomputable def alg2Vartheta (aReq : ℝ) (j : ℕ) : ℝ := 1 / (alg2D aReq j : ℝ)

/-- The potential weights `λ_j = 4^j`. -/
noncomputable def alg2Lambda (j : ℕ) : ℝ := 4 ^ j

/-- `θ_j = (p λ_j)^{-1/2}` for `j < p` and `θ_p = h/(2√2)` (also returned for `j > p`, unused). -/
noncomputable def alg2Theta (aReq : ℝ) (j : ℕ) : ℝ :=
  if j < alg2P aReq then 1 / Real.sqrt ((alg2P aReq : ℝ) * alg2Lambda j)
  else alg2H aReq / (2 * Real.sqrt 2)

/-! ## Block sizes and the sample size (`R:eq:sec3_nj_formula`, L690–692; L647) -/

/-- `n_j = ⌈2^20 χ d_j ⌈√(C_j χ)⌉ / h + 2^12 χ / h²⌉`. -/
noncomputable def alg2NBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) : ℕ :=
  ⌈(2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) / alg2H aReq +
      (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2⌉₊

/-- The sample size `N = ∑_{j=0}^p n_j`. -/
noncomputable def alg2N (M J R : ℕ) (aReq ξReq : ℝ) : ℕ :=
  ∑ j ∈ Finset.range (alg2P aReq + 1), alg2NBlock M J R aReq ξReq j

/-- `max_{0 ≤ j ≤ p} n_j`. -/
noncomputable def alg2MaxN (M J R : ℕ) (aReq ξReq : ℝ) : ℕ :=
  (Finset.range (alg2P aReq + 1)).sup (alg2NBlock M J R aReq ξReq)

/-! ## The lattice `h_A ℤ` (`R:eq:sec3_hA_def`, L693–696) -/

/-- The bound `min{h/(2^20 (p+1) χ), 1/(2^20 max_j n_j)}` that `h_A` must not exceed. -/
noncomputable def alg2HABound (M J R : ℕ) (aReq ξReq : ℝ) : ℝ :=
  min (alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ)))
    (1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)))

/-- The exponent `q_A` of `h_A = 2^{-q_A}`: the least `q` with `2^{-q} ≤ alg2HABound`. -/
noncomputable def alg2HAExp (M J R : ℕ) (aReq ξReq : ℝ) : ℕ := dyadicExp (alg2HABound M J R aReq ξReq)

/-- The lattice step `h_A`: the largest power of two `2^{-q}` (`q ∈ ℕ`) below `alg2HABound`. -/
noncomputable def alg2HA (M J R : ℕ) (aReq ξReq : ℝ) : ℝ := (1 / 2 : ℝ) ^ alg2HAExp M J R aReq ξReq

theorem alg2HA_eq_dyadicDown (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HA M J R aReq ξReq = dyadicDown (alg2HABound M J R aReq ξReq) := rfl

/-! ## Noise scales (`R:eq:sec3_noise_scales`, L697–700)

Internal edge thresholds have scale `2 b_int` and internal directed tests `4 b_int`; the outer
threshold has scale `2 b_out` and outer directed tests `4 b_out`; numerical releases have scale
`b_num` (L750, L775). -/

/-- `b_int = h/(128 χ)`. -/
noncomputable def alg2BInt (M J R : ℕ) (aReq ξReq : ℝ) : ℝ :=
  alg2H aReq / (128 * (alg2Chi M J R aReq ξReq : ℝ))

/-- `b_out = a/(512 χ)`. -/
noncomputable def alg2BOut (M J R : ℕ) (aReq ξReq : ℝ) : ℝ :=
  alg2A aReq / (512 * (alg2Chi M J R aReq ξReq : ℝ))

/-- `b_num = a/(64 χ)`. -/
noncomputable def alg2BNum (M J R : ℕ) (aReq ξReq : ℝ) : ℝ :=
  alg2A aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ))

/-! ## The ideal lattice law and the bounded sampler (L703–716) -/

/-- The geometric ratio `ϱ = b/(b + h_A)` of the ideal lattice law of scale `b` on `h_A ℤ`
(`R:eq:sec3_lattice_law`: `P[Z = k h_A] = (1-ϱ)/(1+ϱ) ϱ^{|k|}`). -/
noncomputable def alg2Rho (hA b : ℝ) : ℝ := b / (b + hA)

/-- The per-draw coupling budget `ζ = δ/(1000 Q)`. -/
noncomputable def alg2Zeta (M J R : ℕ) (aReq ξReq : ℝ) : ℝ :=
  alg2Delta aReq ξReq / (1000 * (alg2Q M J R aReq : ℝ))

/-- `B_0 = ⌈log₂(16/ζ)⌉`. -/
noncomputable def alg2B0 (M J R : ℕ) (aReq ξReq : ℝ) : ℕ :=
  ⌈Real.logb 2 (16 / alg2Zeta M J R aReq ξReq)⌉₊

/-- The count truncation `K_s = ⌈((b + h_A)/h_A) B_0⌉` of a draw of scale `b`. -/
noncomputable def alg2Ks (hA : ℝ) (B0 : ℕ) (b : ℝ) : ℕ := ⌈(b + hA) / hA * (B0 : ℝ)⌉₊

/-- The trial cap `r_s = ⌈log₂(32(K_s + 1)/ζ)⌉` of the capped uniform-integer sampler. -/
noncomputable def alg2Rs (ζ : ℝ) (Ks : ℕ) : ℕ := ⌈Real.logb 2 (32 * ((Ks : ℝ) + 1) / ζ)⌉₊

end F2e2e.B
