import F2e2e.B.PrivacyAdv

/-!
# Privacy (P2) + (P3) for one stream against an arbitrary interactive skeleton

Paper: `parts/partII.tex` L986–1002 (one-phase privacy: the injective noise shift), L1008–1019 (one
hybrid step: the other streams and the controller form an interactive analyst; advanced composition over
the `≤ C` phases of the selected stream).

A skeleton with a single stream oracle (`Env1`) is run by `run1`. We cut the run at the stream's phase
starts (`reopen`/`release` calls): `runSeg` runs until the next phase start, `segLaw` is one segment
from a phase start. The segments' outcomes contain everything the skeleton does in between (including
all draws of the other streams), so
* the initial segment (before the first phase start) does not depend on the data (`runSeg_closed`);
* each further segment law is pointwise `e^ρ`-close for neighbouring data (`segLaw_ratioLE`: shift the
  phase's threshold by `d` lattice steps and the crossing test's noise by `2d`, as in L990; the
  environment's draws factor out);
* the run is the interpretation of a segment-level program with at most `C` draws (`run1_map_some`),
  so `drawProg_advComp` applies (`stream_indist`).
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete ENNReal

/-- `bind` only depends on the continuation on the support. -/
theorem pmf_bind_congr {α β : Type*} (p : PMF α) {f g : α → PMF β}
    (h : ∀ a ∈ p.support, f a = g a) : p.bind f = p.bind g := by
  ext b
  rw [PMF.bind_apply, PMF.bind_apply]
  refine tsum_congr fun a => ?_
  by_cases ha : p a = 0
  · simp [ha]
  · rw [h a ((PMF.mem_support_iff p a).2 ha)]

/-! ## Single-stream skeletons and their segments -/

/-- Skeletons with a single stream oracle. -/
abbrev Env1 (I P α : Type) : Type := OProg Unit P ℤ (SQuery I) SResp α

/-- A phase-start node: the phase-starting query and the continuation of the skeleton. -/
abbrev Node1 (I P α : Type) : Type := SQuery I × (SResp → Env1 I P α)

section Segments

variable {I X P α : Type} (L : P → PMF ℤ) (sp : StreamSpec I X P)

/-- The law of the run of a single-stream skeleton (the stream reading `x`, from the state `σ`). -/
noncomputable def run1 (x : X) : Env1 I P α → Option ℤ → PMF α
  | .ret a, _ => PMF.pure a
  | .draw p k, σ => (L p).bind fun y => run1 x (k y) σ
  | .call _ q k, σ => (DrawProg.interp L (sp.step x σ q)).bind fun r => run1 x (k r.1) r.2

/-- Run until the next phase start (exclusive) or the end. -/
noncomputable def runSeg (x : X) : Env1 I P α → Option ℤ → PMF (Node1 I P α ⊕ α)
  | .ret a, _ => PMF.pure (Sum.inr a)
  | .draw p k, σ => (L p).bind fun y => runSeg x (k y) σ
  | .call _ q k, σ =>
      if q.isStart = true then PMF.pure (Sum.inl (q, k))
      else (DrawProg.interp L (sp.step x σ q)).bind fun r => runSeg x (k r.1) r.2

/-- One segment, from a phase start to the next phase start (exclusive) or the end. -/
noncomputable def segLaw (x : X) (nd : Node1 I P α) : PMF (Node1 I P α ⊕ α) :=
  (DrawProg.interp L (sp.step x none nd.1)).bind fun r => runSeg L sp x (nd.2 r.1) r.2

/-- The rest of the run from a phase start. -/
noncomputable def run1Node (x : X) (nd : Node1 I P α) : PMF α :=
  (DrawProg.interp L (sp.step x none nd.1)).bind fun r => run1 L sp x (nd.2 r.1) r.2

/-- The continuation of the run after a segment. -/
noncomputable def contRun (x : X) : Node1 I P α ⊕ α → PMF α
  | Sum.inl nd => run1Node L sp x nd
  | Sum.inr a => PMF.pure a

/-- The segment-level program: at most `n` segments. -/
def segDP : ℕ → Node1 I P α → DrawProg (Node1 I P α) (Node1 I P α ⊕ α) (Option α)
  | 0, _ => .ret none
  | n + 1, nd => .draw nd fun s => match s with
      | Sum.inl nd' => segDP n nd'
      | Sum.inr a => .ret (some a)

theorem segDP_drawsLE : ∀ (n : ℕ) (nd : Node1 I P α), (segDP n nd).DrawsLE n
  | 0, _ => trivial
  | n + 1, nd => fun s => by
      cases s with
      | inl nd' => exact segDP_drawsLE n nd'
      | inr a => trivial

/-- A phase start ignores the previous state. -/
theorem step_start (x : X) (σ : Option ℤ) {q : SQuery I} (hq : q.isStart = true) :
    sp.step x σ q = sp.step x none q := by
  cases q with
  | test i => simp [SQuery.isStart] at hq
  | reopen => cases σ <;> rfl
  | release i => cases σ <;> rfl

/-- The run is the initial segment followed by the rest of the run. -/
theorem run1_eq_bind (x : X) :
    ∀ (E : Env1 I P α) (σ : Option ℤ), run1 L sp x E σ = (runSeg L sp x E σ).bind (contRun L sp x)
  | .ret a, σ => by simp only [run1, runSeg, PMF.pure_bind, contRun]
  | .draw p k, σ => by
      simp only [run1, runSeg, PMF.bind_bind]
      congr 1; funext y; exact run1_eq_bind x (k y) σ
  | .call _ q k, σ => by
      by_cases hq : q.isStart = true
      · simp only [run1, runSeg, hq, if_true, PMF.pure_bind, contRun, run1Node]
        rw [step_start sp x σ hq]
      · simp only [run1, runSeg, hq, Bool.false_eq_true, if_false, PMF.bind_bind]
        congr 1; funext r; exact run1_eq_bind x (k r.1) r.2

/-- Before the first phase start the stream is closed: the initial segment does not depend on the
data. -/
theorem runSeg_closed (x x' : X) :
    ∀ E : Env1 I P α, runSeg L sp x E none = runSeg L sp x' E none
  | .ret a => rfl
  | .draw p k => by
      simp only [runSeg]; congr 1; funext y; exact runSeg_closed x x' (k y)
  | .call _ q k => by
      cases q with
      | test i =>
        simp only [runSeg, SQuery.isStart, Bool.false_eq_true, if_false, StreamSpec.step,
          DrawProg.interp_ret, PMF.pure_bind]
        exact runSeg_closed x x' (k SResp.closed)
      | reopen => rfl
      | release i => rfl

/-- Budget of the nodes reached by a segment. -/
theorem runSeg_support (x : X) :
    ∀ (E : Env1 I P α) (σ : Option ℤ) (n : ℕ), E.StartsLE () n →
      ∀ nd, Sum.inl nd ∈ (runSeg L sp x E σ).support → 0 < n ∧ ∀ r, (nd.2 r).StartsLE () (n - 1)
  | .ret a, σ, n, _, nd, hnd => by
      simp [runSeg, PMF.support_pure] at hnd
  | .draw p k, σ, n, hE, nd, hnd => by
      simp only [runSeg, PMF.mem_support_bind_iff] at hnd
      obtain ⟨y, _, hy⟩ := hnd
      exact runSeg_support x (k y) σ n (hE y) nd hy
  | .call _ q k, σ, n, hE, nd, hnd => by
      by_cases hq : q.isStart = true
      · simp only [runSeg, hq, if_true, PMF.support_pure, Set.mem_singleton_iff,
          Sum.inl.injEq] at hnd
        subst hnd
        simp only [OProg.StartsLE, true_and, hq, if_true] at hE
        exact hE
      · simp only [runSeg, hq, Bool.false_eq_true, if_false, PMF.mem_support_bind_iff] at hnd
        obtain ⟨r, _, hr⟩ := hnd
        simp only [OProg.StartsLE, true_and, hq, Bool.false_eq_true, if_false] at hE
        exact runSeg_support x (k r.1) r.2 n (hE r.1) nd hr

/-- The segment-level program computes the rest of the run (when the budget suffices). -/
theorem interp_segDP (x : X) :
    ∀ (n : ℕ) (nd : Node1 I P α), (∀ r, (nd.2 r).StartsLE () n) →
      DrawProg.interp (segLaw L sp x) (segDP (n + 1) nd) = (run1Node L sp x nd).map some := by
  intro n
  induction n with
  | zero =>
    intro nd hnd
    rw [segDP, DrawProg.interp_draw, run1Node, PMF.map_bind]
    simp_rw [run1_eq_bind L sp x, PMF.map_bind]
    rw [segLaw, PMF.bind_bind]
    refine pmf_bind_congr _ fun r _ => pmf_bind_congr _ fun s hs => ?_
    cases s with
    | inl nd' => exact absurd (runSeg_support L sp x _ _ 0 (hnd r.1) nd' hs).1 (lt_irrefl 0)
    | inr a => simp [contRun, PMF.pure_map]
  | succ m ih =>
    intro nd hnd
    rw [segDP, DrawProg.interp_draw, run1Node, PMF.map_bind]
    simp_rw [run1_eq_bind L sp x, PMF.map_bind]
    rw [segLaw, PMF.bind_bind]
    refine pmf_bind_congr _ fun r _ => pmf_bind_congr _ fun s hs => ?_
    cases s with
    | inl nd' =>
      have h := (runSeg_support L sp x _ _ (m + 1) (hnd r.1) nd' hs).2
      simp only [Nat.add_sub_cancel] at h
      exact ih nd' h
    | inr a => simp [contRun, PMF.pure_map]

/-- **Segmentation**: the run (relabelled by `some`) is the data-independent initial segment followed by
the segment-level program with at most `C` segments. -/
theorem run1_map_some (x : X) (E : Env1 I P α) {C : ℕ} (hC : E.StartsLE () C) :
    (run1 L sp x E none).map some = (runSeg L sp x E none).bind fun s => match s with
      | Sum.inl nd => DrawProg.interp (segLaw L sp x) (segDP C nd)
      | Sum.inr a => PMF.pure (some a) := by
  rw [run1_eq_bind L sp x, PMF.map_bind]
  refine pmf_bind_congr _ fun s hs => ?_
  cases s with
  | inl nd =>
    obtain ⟨hC0, hnd⟩ := runSeg_support L sp x E none C hC nd hs
    obtain ⟨m, rfl⟩ : ∃ m, C = m + 1 := ⟨C - 1, by omega⟩
    simp only [Nat.add_sub_cancel] at hnd
    exact (interp_segDP L sp x m nd hnd).symm
  | inr a => simp [contRun, PMF.pure_map]

end Segments

end F2e2e.B.Priv
