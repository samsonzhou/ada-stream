import F2e2e.Spec
import F2e2e.Lib.Discrete.Sampler

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 1: the bounded lattice sampler

The Spec's bounded sampler (`F2e2e.readBits`, `bernoulliCoin`, `successCount`, `latticeSample`,
tape-passing `Option` functions, §2.4) is LIB-DISCRETE's `latticeSampler` (a `BitProg`) run on the
tape.
-/

namespace F2e2e.B.V2

open F2e2e.Discrete

theorem readBits_eq : ∀ (acc k : ℕ) (t : List Bool),
    F2e2e.readBits acc k t = (Discrete.bitsNat acc k).run t
  | _, 0, _ => rfl
  | _, _ + 1, [] => rfl
  | acc, k + 1, b :: t => by
    show F2e2e.readBits (2 * acc + (if b = true then 1 else 0)) k t =
      (Discrete.bitsNat (2 * acc + if b then 1 else 0) k).run t
    exact readBits_eq _ _ _

theorem bernoulliCoin_eq (A D : ℕ) : ∀ (r : ℕ) (t : List Bool),
    F2e2e.bernoulliCoin A D r t = (ratCoin A D r).run t
  | 0, _ => rfl
  | r + 1, t => by
    have e1 : F2e2e.bernoulliCoin A D (r + 1) t =
        match F2e2e.readBits 0 (Nat.clog 2 D) t with
        | none => none
        | some (x, rest) =>
            if x < D then some (decide (x < A), rest) else F2e2e.bernoulliCoin A D r rest := rfl
    rw [e1, readBits_eq, run_ratCoin,
      show rejectUniform D (Nat.clog 2 D) (r + 1) = (Discrete.bitsNat 0 (Nat.clog 2 D)).bind (fun x =>
        if x < D then BitProg.pure (some x) else rejectUniform D (Nat.clog 2 D) r) from rfl,
      BitProg.run_bind]
    cases h : (Discrete.bitsNat 0 (Nat.clog 2 D)).run t with
    | none => rfl
    | some p =>
      obtain ⟨x, rest⟩ := p
      by_cases hx : x < D
      · simp only [hx, if_true, Option.bind_some, BitProg.run_pure, Option.map_some,
          Option.elim]
      · simp only [hx, if_false, Option.bind_some]
        rw [bernoulliCoin_eq A D r rest, run_ratCoin]

theorem successCount_eq (A D r : ℕ) : ∀ (K : ℕ) (t : List Bool),
    F2e2e.successCount A D r K t = ((countSucc K).toBits (fun _ => ratCoin A D r)).run t
  | 0, _ => rfl
  | K + 1, t => by
    have e1 : F2e2e.successCount A D r (K + 1) t =
        match F2e2e.bernoulliCoin A D r t with
        | none => none
        | some (false, rest) => some (0, rest)
        | some (true, rest) =>
            match F2e2e.successCount A D r K rest with
            | none => none
            | some (g, rest') => some (g + 1, rest') := rfl
    rw [e1, bernoulliCoin_eq,
      show countSucc (K + 1) = DrawProg.draw () (fun b =>
        if b then (countSucc K).map (· + 1) else DrawProg.ret 0) from rfl,
      DrawProg.toBits_draw, BitProg.run_bind]
    cases h : (ratCoin A D r).run t with
    | none => rfl
    | some p =>
      obtain ⟨b, rest⟩ := p
      cases b
      · rfl
      · simp only [Option.bind_some, if_true]
        rw [DrawProg.toBits_map, BitProg.run_map, ← successCount_eq A D r K rest]
        cases h2 : F2e2e.successCount A D r K rest with
        | none => rfl
        | some q => rfl

/-- **The Spec's bounded sampler is LIB-DISCRETE's `latticeSampler`.** -/
theorem latticeSample_eq (A D r K : ℕ) (t : List Bool) :
    F2e2e.latticeSample A D r K t = (latticeSampler A D r K).run t := by
  unfold F2e2e.latticeSample latticeSampler latticeProg
  rw [DrawProg.toBits_bind, BitProg.run_bind, ← successCount_eq]
  cases h : F2e2e.successCount A D r K t with
  | none => rfl
  | some p =>
    obtain ⟨g₁, rest₁⟩ := p
    simp only [Option.bind_some]
    rw [DrawProg.toBits_map, BitProg.run_map, ← successCount_eq]
    cases h2 : F2e2e.successCount A D r K rest₁ with
    | none => rfl
    | some q => rfl

end F2e2e.B.V2
