import F2e2e.B.PrivacyRefineDefs

/-!
# Refinement: B-ARCH's core = the data-oblivious skeleton with stream oracles (in law)

Split along the code structure of `F2e2e/B/ArchCore.lean` / `F2e2e/B/ArchOnline.lean`; every lemma is
a lockstep simulation `DrawRel` (same draws, same order, related outputs) between a core function and
the inlined skeleton function (`inlineSt (coreSpec P) (fun _ => s) …`), under the refinement relation
(`Rel0`: counters and replicated scores; `RelT`: thresholds = oracle states).

* `edgeTest_rel` (lines [5]–[7]), `redrawThresholds_rel`, `applyCorrection_rel` (lines [8]–[9]),
  `scanPass_rel`, `prepareRoot_rel` (lines [2]–[10]), `outerReject_rel`, `adaIntervalD_rel`
  (lines [11]–[15]), `adaNumericalD_rel` (lines [16]–[18]), `coreStepD_rel`, `coreLoopD_rel`,
  `adaInitD_rel`;
* `coreRunD_refine`: `interp L (coreRunD P ctrl s T) = interp L (inlineAll (coreSpec P) … (skRunD P ctrl T) …)`
  for every interpretation `L` of the draws.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

variable {U : Type} (P : AdaParams) (s : Fin P.N → U)

/-! ## Per-call lemmas -/

theorem edgeTest_rel (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (f : U → ℕ) {j : ℕ}
    (hj : j < P.p) (h0 : Rel0 P s st sk) (hT : RelT P st σ) :
    DrawRel (EdgeR σ j) (edgeTest P st (adaMus P st (valsOf P s f)) j)
      (inlineSt (coreSpec P) (fun _ => s) (skEdgeTest sk.hist f j) σ) := by
  have hσ : σ (Strm.edge j) = some (st.thrInt.getD j 0) := hT.2.1 j hj
  have hmu := recMus_eq P s h0 f 0 0
  simp only [skEdgeTest, inlineSt, hσ, StreamSpec.step, coreSpec, edgeTest, drawNoise,
    DrawProg.bind_draw, DrawProg.bind_ret, hmu]
  refine DrawRel.draw fun kp => DrawRel.draw fun km => DrawRel.ret ?_
  have hupd : Function.update σ (Strm.edge j) (some (st.thrInt.getD j 0)) = σ := by
    rw [← hσ, Function.update_eq_self]
  split_ifs with h1 h2
  · exact Or.inr ⟨true, rfl, rfl, rfl⟩
  · exact Or.inr ⟨false, rfl, rfl, rfl⟩
  · exact Or.inl ⟨rfl, rfl, hupd⟩

theorem redrawThresholds_rel :
    ∀ (es : List ℕ) (thr : List ℤ) (σ : Strm → Option ℤ),
      DrawRel (RedrawR σ thr es) (redrawThresholds P es thr)
        (inlineSt (coreSpec P) (fun _ => s) (skRedraw (U := U) es) σ)
  | [], thr, σ => DrawRel.ret ⟨rfl, fun e he => absurd he (List.not_mem_nil),
      fun e _ => ⟨rfl, rfl⟩, rfl, rfl⟩
  | e :: es, thr, σ => by
      simp only [redrawThresholds, skRedraw, inlineSt, drawNoise, StreamSpec.step, coreSpec,
        DrawProg.bind_draw, DrawProg.bind_ret]
      refine DrawRel.draw fun k => ?_
      refine (redrawThresholds_rel es (thr.set e k)
        (Function.update σ (Strm.edge e) (some k))).mono ?_
      rintro thr' ⟨u, σ'⟩ ⟨hlen, hin, hout, houter, hnum⟩
      simp only [List.length_set] at hlen hin
      refine ⟨hlen, fun e' he' hlt => ?_, fun e' he' => ?_, ?_, ?_⟩
      · by_cases hes : e' ∈ es
        · exact hin e' hes hlt
        · have he'e : e' = e := by
            rcases List.mem_cons.1 he' with h | h
            · exact h
            · exact absurd h hes
          subst he'e
          rw [(hout e' hes).1, (hout e' hes).2, Function.update_self, getD_set_self' hlt]
      · have hne : e' ≠ e := fun h => he' (h ▸ List.mem_cons_self)
        have hes : e' ∉ es := fun h => he' (List.mem_cons_of_mem e h)
        rw [(hout e' hes).1, (hout e' hes).2, getD_set_ne' (Ne.symm hne),
          Function.update_of_ne (by simpa using hne)]
        exact ⟨rfl, rfl⟩
      · rw [houter, Function.update_of_ne (by simp)]
      · rw [hnum, Function.update_of_ne (by simp)]

theorem applyCorrection_rel (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (f : U → ℕ)
    {j : ℕ} (_hj : j < P.p) (q : Bool) (h0 : Rel0 P s st sk) (hT : RelTx P st σ j) :
    DrawRel (fun st' o => Rel0 P s st' o.1 ∧ RelT P st' o.2)
      (applyCorrection P st (valsOf P s f) j q)
      (inlineSt (coreSpec P) (fun _ => s) (skApplyCorrection P sk f j q) σ) := by
  rw [applyCorrection_eq, skApplyCorrection, inlineSt_bind]
  refine (redrawThresholds_rel P s (reopenEdges P j) st.thrInt σ).bind ?_
  rintro thr' ⟨u, σ'⟩ ⟨hlen, hin, hout, houter, _⟩
  have hin' : ∀ e ∈ reopenEdges P j, e < st.thrInt.length →
      σ' (Strm.edge e) = some (thr'.getD e 0) := hin
  have hout' : ∀ e, e ∉ reopenEdges P j →
      σ' (Strm.edge e) = σ (Strm.edge e) ∧ thr'.getD e 0 = st.thrInt.getD e 0 := hout
  have houter' : σ' Strm.outer = σ Strm.outer := houter
  simp only [inlineSt]
  refine DrawRel.ret ⟨?_, ?_⟩
  · obtain ⟨hT0, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
    have hc := corrScores_congr P hsc hw (valsOf P s f) j q
    refine ⟨by simp [hT0], hrej, hnInt, hnNum, hhalt, hcap, ?_, ?_⟩
    · show (corrScores P st (valsOf P s f) j q).scores = (replay P s (sk.hist ++ [(j, q, f)])).scores
      rw [replay_append]; exact hc.1
    · show (corrScores P st (valsOf P s f) j q).weights = (replay P s (sk.hist ++ [(j, q, f)])).weights
      rw [replay_append]; exact hc.2
  · obtain ⟨hlen0, hedge, hout0⟩ := hT
    refine ⟨by simpa [hlen0] using hlen, fun e he => ?_, ?_⟩
    · show σ' (Strm.edge e) = some (thr'.getD e 0)
      by_cases hre : e ∈ reopenEdges P j
      · exact hin' e hre (by rw [hlen0]; exact he)
      · have hne : e ≠ j := fun h => hre (h ▸ mem_reopenEdges_self P j)
        rw [(hout' e hre).1, (hout' e hre).2]
        exact hedge e he hne
    · show σ' Strm.outer = some st.thrOut
      rw [houter']; exact hout0

theorem scanPass_rel (f : U → ℕ) (st : AdaState) (sk : SkState U) (h0 : Rel0 P s st sk) :
    ∀ (es : List ℕ), (∀ j ∈ es, j < P.p) → ∀ (σ : Strm → Option ℤ) (cache : List Bool),
      RelT P st σ →
      DrawRel (ScanR P s)
        (scanPass P (valsOf P s f) (adaMus P st (valsOf P s f)) es st cache)
        (inlineSt (coreSpec P) (fun _ => s) (skScanPass P f es sk cache) σ) := by
  intro es
  induction es with
  | nil =>
    intro _ σ cache hT
    exact DrawRel.ret ⟨rfl, rfl, h0, fun _ => hT⟩
  | cons j es ih =>
    intro hes σ cache hT
    have hj : j < P.p := hes j List.mem_cons_self
    have hes' : ∀ j ∈ es, j < P.p := fun j' hj' => hes j' (List.mem_cons_of_mem _ hj')
    simp only [scanPass, skScanPass]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc, if_pos hc]
      exact ih hes' σ cache hT
    · rw [if_neg hc, if_neg hc, inlineSt_bind]
      refine (edgeTest_rel P s st sk σ f hj h0 hT).bind ?_
      rintro r ⟨resp, σ'⟩ (⟨rfl, h1, h2⟩ | ⟨q, rfl, h1, h2⟩)
      · have h1' : resp = SResp.accept := h1
        have h2' : σ' = σ := h2
        subst h1' h2'
        exact ih hes' _ (cache.set j true) hT
      · have h1' : resp = SResp.cross q := h1
        have h2' : σ' = Function.update σ (Strm.edge j) none := h2
        subst h1' h2'
        dsimp only
        by_cases hcap : P.Tmax.getD j 0 ≤ sk.T.getD j 0
        · have hcap' : P.Tmax.getD j 0 ≤ st.T.getD j 0 := by rw [h0.1]; exact hcap
          rw [if_pos hcap', if_pos hcap]
          exact DrawRel.ret ⟨rfl, rfl, h0, fun h => (h rfl).elim⟩
        · have hcap' : ¬ P.Tmax.getD j 0 ≤ st.T.getD j 0 := by rw [h0.1]; exact hcap
          rw [if_neg hcap', if_neg hcap, inlineSt_bind]
          refine (applyCorrection_rel P s st sk (Function.update σ (Strm.edge j) none) f hj q h0
            ⟨hT.1, fun e he hne => ?_, ?_⟩).bind ?_
          · rw [Function.update_of_ne (by simpa using hne)]; exact hT.2.1 e he
          · rw [Function.update_of_ne (by simp)]; exact hT.2.2
          · rintro st' ⟨sk', σ3⟩ ⟨h0', hT'⟩
            exact DrawRel.ret ⟨rfl, rfl, h0', fun _ => hT'⟩

theorem prepareRoot_rel (f : U → ℕ) :
    ∀ (fuel : ℕ) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (cache : List Bool),
      Rel0 P s st sk → RelT P st σ →
      DrawRel (PrepR P s) (prepareRoot P (valsOf P s f) fuel st cache)
        (inlineSt (coreSpec P) (fun _ => s) (skPrepareRoot P f fuel sk cache) σ)
  | 0, st, sk, σ, cache, _, _ => by
      simp only [prepareRoot, skPrepareRoot, inlineSt]
      exact DrawRel.ret (Or.inl ⟨rfl, rfl⟩)
  | fuel + 1, st, sk, σ, cache, h0, hT => by
      simp only [prepareRoot, skPrepareRoot]
      rw [inlineSt_bind]
      refine (scanPass_rel P s f st sk h0 (List.range P.p) (fun j hj => List.mem_range.1 hj) σ cache
        hT).bind ?_
      rintro ⟨out, st', cache'⟩ ⟨⟨out', sk', cache''⟩, σ'⟩ ⟨h1, h2, h0', hT'⟩
      have h2' : cache' = cache'' := h2
      subst h2'
      cases out
      · have e : out' = PassOut.done := h1.symm
        subst e
        dsimp only
        exact DrawRel.ret (Or.inr ⟨st', sk', rfl, rfl, h0', hT' (by simp)⟩)
      · have e : out' = PassOut.corrected := h1.symm
        subst e
        dsimp only
        exact prepareRoot_rel f fuel st' sk' σ' _ h0' (hT' (by simp))
      · have e : out' = PassOut.abort := h1.symm
        subst e
        dsimp only
        exact DrawRel.ret (Or.inl ⟨rfl, rfl⟩)

theorem outerReject_rel (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (high : Bool)
    (h0 : Rel0 P s st sk) (hlen : st.thrInt.length = P.p)
    (hedge : ∀ e < P.p, σ (Strm.edge e) = some (st.thrInt.getD e 0)) :
    DrawRel (CallR P s) (outerReject P st high)
      (inlineSt (coreSpec P) (fun _ => s) (skOuterReject P sk high) σ) := by
  obtain ⟨hT0, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
  unfold outerReject skOuterReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · have hJ' : P.J + 1 ≤ sk.rej + 1 := by omega
    rw [if_pos hJ, if_pos hJ']
    refine DrawRel.ret ⟨rfl, ⟨hT0, by simp [hrej], hnInt, hnNum, rfl, hcap, hsc, hw⟩, fun h => ?_⟩
    simp at h
  · have hJ' : ¬ P.J + 1 ≤ sk.rej + 1 := by omega
    rw [if_neg hJ, if_neg hJ']
    simp only [inlineSt, drawNoise, StreamSpec.step, coreSpec, DrawProg.bind_draw,
      DrawProg.bind_ret]
    refine DrawRel.draw fun k => DrawRel.ret ⟨rfl, ⟨hT0, by simp [hrej], hnInt, hnNum, hhalt, hcap,
      hsc, hw⟩, fun _ => ⟨hlen, fun e he => ?_, ?_⟩⟩
    · show Function.update σ Strm.outer (some k) (Strm.edge e) = some (st.thrInt.getD e 0)
      rw [Function.update_of_ne (by simp)]; exact hedge e he
    · simp

theorem adaIntervalD_rel (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (f : U → ℕ)
    (l u : ℚ) (h : Rel P s st sk σ) :
    DrawRel (CallR P s) (adaIntervalD P st (valsOf P s f) l u)
      (inlineSt (coreSpec P) (fun _ => s) (skIntervalD P sk f l u) σ) := by
  obtain ⟨h0, hT⟩ := h
  obtain ⟨hT0, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
  unfold adaIntervalD skIntervalD
  by_cases hc : st.halted = true ∨ P.M ≤ st.nInt
  · have hc' : sk.halted = true ∨ P.M ≤ sk.nInt := by rwa [← hhalt, ← hnInt]
    rw [if_pos hc, if_pos hc']
    exact DrawRel.ret ⟨rfl, ⟨hT0, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩, hT⟩
  · have hc' : ¬ (sk.halted = true ∨ P.M ≤ sk.nInt) := by rwa [← hhalt, ← hnInt]
    rw [if_neg hc, if_neg hc', inlineSt_bind]
    have hnh : st.halted = false := by simpa using (not_or.1 hc).1
    have hT' := hT hnh
    refine (prepareRoot_rel P s f P.fuel { st with nInt := st.nInt + 1 }
      { sk with nInt := sk.nInt + 1 } σ (List.replicate P.p false)
      ⟨hT0, hrej, by simp [hnInt], hnNum, hhalt, hcap, hsc, hw⟩ hT').bind ?_
    rintro r ⟨o, σ'⟩ (⟨rfl, ho⟩ | ⟨st2, sk2, rfl, ho, h0', hT2⟩)
    · have ho' : o = none := ho
      subst ho'
      dsimp only
      exact DrawRel.ret ⟨rfl, ⟨hT0, hrej, by simp [hnInt], hnNum, rfl, rfl, hsc, hw⟩,
        fun h => by simp at h⟩
    · have ho' : o = some sk2 := ho
      subst ho'
      have hσo : σ' Strm.outer = some st2.thrOut := hT2.2.2
      have hmu := recMus_eq P s h0' f (P.hA * (roundIdxQ P.hA (clipQ (-1) 2 l) : ℚ))
        (P.hA * (roundIdxQ P.hA (clipQ (-1) 2 u) : ℚ))
      have hedge : ∀ e < P.p,
          Function.update σ' Strm.outer none (Strm.edge e) = some (st2.thrInt.getD e 0) :=
        fun e he => by rw [Function.update_of_ne (by simp)]; exact hT2.2.1 e he
      have hupd : Function.update σ' Strm.outer (some st2.thrOut) = σ' := by
        rw [← hσo, Function.update_eq_self]
      dsimp only
      simp only [inlineSt, hσo, StreamSpec.step, coreSpec, drawNoise, DrawProg.bind_draw,
        DrawProg.bind_ret, hmu]
      refine DrawRel.draw fun kH => DrawRel.draw fun kL => ?_
      split_ifs with h1 h2
      · exact outerReject_rel P s st2 sk2 (Function.update σ' Strm.outer none) true h0' hT2.1 hedge
      · exact outerReject_rel P s st2 sk2 (Function.update σ' Strm.outer none) false h0' hT2.1 hedge
      · refine DrawRel.ret ⟨rfl, h0', fun _ => ?_⟩
        show RelT P st2 (Function.update σ' Strm.outer (some st2.thrOut))
        rw [hupd]; exact hT2

end F2e2e.B.Priv
