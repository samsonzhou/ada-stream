import F2e2e.B.PrivacyRefineAux

/-!
# Refinement: one round, the online loop, and the whole run

`coreStepD_rel`, `coreLoopD_rel`, `coreRunD_refine` (see `F2e2e/B/PrivacyRefine.lean`).
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

variable {U : Type} (P : AdaParams) (s : Fin P.N → U)

theorem coreStepD_rel (req : CoreReq U) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ)
    (h : Rel P s st sk σ) :
    DrawRel (CallR P s) (coreStepD P s req st)
      (inlineSt (coreSpec P) (fun _ => s) (skStepD P req sk) σ) := by
  unfold coreStepD skStepD
  by_cases hi : req.isInterval = true
  · rw [if_pos hi, if_pos hi, DrawProg.map, OProg.map, inlineSt_bind]
    refine (adaIntervalD_rel P s st sk σ req.f req.l req.u h).bind ?_
    rintro r o ⟨h1, h2⟩
    exact DrawRel.ret ⟨congrArg Sum.inl h1, h2⟩
  · rw [if_neg hi, if_neg hi, DrawProg.map, OProg.map, inlineSt_bind]
    refine (adaNumericalD_rel P s st sk σ req.f h).bind ?_
    rintro r o ⟨h1, h2⟩
    exact DrawRel.ret ⟨congrArg Sum.inr h1, h2⟩

theorem coreLoopD_rel (ctrl : CoreCtrl U) :
    ∀ (T : ℕ) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (hist : List CoreOut),
      Rel P s st sk σ →
      DrawRel (fun r o => r = o.1) (coreLoopD P ctrl s T st hist)
        (inlineSt (coreSpec P) (fun _ => s) (skLoopD P ctrl T sk hist) σ)
  | 0, st, sk, σ, hist, _ => by
      simp only [coreLoopD, skLoopD, inlineSt]
      exact DrawRel.ret rfl
  | T + 1, st, sk, σ, hist, h => by
      simp only [coreLoopD, skLoopD]
      rw [inlineSt_bind]
      refine (coreStepD_rel P s (ctrl hist) st sk σ h).bind ?_
      intro r o hro
      obtain ⟨h1, h2⟩ := hro
      rw [h1]
      exact coreLoopD_rel ctrl T r.2 o.1.2 o.2 (hist ++ [o.1.1]) h2

/-! ## The refinement -/

/-- The core's online execution and the skeleton run with the stream oracles make the same draws
and return the same outputs. -/
theorem coreRunD_rel (ctrl : CoreCtrl U) (T : ℕ) :
    DrawRel (fun r o => r = o.1) (coreRunD P ctrl s T)
      (inlineSt (coreSpec P) (fun _ => s) (skRunD P ctrl T) (fun _ => none)) := by
  rw [coreRunD, skRunD, inlineSt_bind]
  refine (adaInitD_rel P s).bind ?_
  intro st o h
  exact coreLoopD_rel P s ctrl T st o.1 o.2 [] h

/-- **Refinement**: the online execution of B-ARCH's core and the data-oblivious skeleton with stream
oracles have the same law, for every interpretation `L` of the noise draws (ideal lattice laws or
otherwise). -/
theorem coreRunD_refine (ctrl : CoreCtrl U) (T : ℕ) (L : NoiseKind → PMF ℤ) :
    DrawProg.interp L (coreRunD P ctrl s T) =
      DrawProg.interp L (inlineAll (coreSpec P) (fun _ => s) (skRunD P ctrl T) (fun _ => none)) := by
  have h := (coreRunD_rel P s ctrl T).interp_map L (F := id) (G := Prod.fst)
    (fun a r har => har)
  rw [PMF.map_id] at h
  rw [h, interp_inlineAll_eq]

end F2e2e.B.Priv
