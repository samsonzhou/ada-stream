import F2e2e.Spec
import F2e2e.B.ArchMeas

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 5d: measurability of the union event

* `measurableSet_vCovered2`, `measurableSet_roundViews2`, `measurableSet_vInternalFails2`: generic
  (any mechanism whose responses, abort flags and correction counts are measurable in the views);
* `alg2Exec_congr`, `measurableSet_alg2Exec`: the Spec's `alg2Exec` reads the views only through their
  rounded data (`roundData`: the rounded query values `round_{h_A}(f(X_m))`, the request type, the
  rounded clipped endpoints), a measurable map into a countable type; hence every property of its
  outcome is a measurable set of views.

The generic measurability lemmas are those of `F2e2e/B/ArchMeas.lean` (`measurableSet_vFails`,
`measurable_viewsOf`, …), used directly.
-/

namespace F2e2e.B.V2

open MeasureTheory F2e2e.B

/-! ## Coverage and internal failures -/

theorem vCovered_iff2 {U : Type} {N c : ℕ} (mech : F2e2e.VMechanism N c)
    (ctrl : F2e2e.VController U) (M J R : ℕ) (s : Fin N → U) (ω : Fin c → Bool) (t : ℕ) :
    F2e2e.VCovered mech ctrl M J R s ω t ↔ ∃ h : Fin (t + 1) → F2e2e.VResponse,
      F2e2e.vResponses mech ctrl s ω (t + 1) = h ∧
      covPred M J R t (fun j => (reqOf ctrl t h j).2.1) (fun j => (respOf t h j).isReject) := by
  constructor
  · intro hcov
    refine ⟨_, rfl, ?_⟩
    rw [vCovered_eq_covPred] at hcov
    refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mp hcov
    · rw [vRequest_eq_reqOf mech ctrl s ω rfl hj]
    · rw [vResponse_eq_respOf mech ctrl s ω rfl hj.le]
  · rintro ⟨h, hω, hcov⟩
    rw [vCovered_eq_covPred]
    refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mpr hcov
    · rw [vRequest_eq_reqOf mech ctrl s ω hω hj]
    · rw [vResponse_eq_respOf mech ctrl s ω hω hj.le]

section Main

variable {U : Type} {N c : ℕ} (mech : F2e2e.VMechanism N c) {Ω : Type} [MeasurableSpace Ω]
  (ctrl : Ω → F2e2e.VController U)
  (hctrl : ∀ (t : ℕ) (h : Fin t → F2e2e.VResponse), Measurable (fun ω => ctrl ω t h))
  (hmeas : ∀ (t : ℕ) (ω' : Fin c → Bool) (r : F2e2e.VResponse),
    MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | mech t views ω' = r})

include hctrl hmeas in
theorem measurableSet_vCovered2 (M J R : ℕ) (s : Fin N → U) (ω' : Fin c → Bool) (t : ℕ) :
    MeasurableSet {ω | F2e2e.VCovered mech (ctrl ω) M J R s ω' t} := by
  have hset : {ω | F2e2e.VCovered mech (ctrl ω) M J R s ω' t} =
      ⋃ h : Fin (t + 1) → F2e2e.VResponse,
        {ω | F2e2e.vResponses mech (ctrl ω) s ω' (t + 1) = h} ∩
          {ω | covPred M J R t (fun j => (reqOf (ctrl ω) t h j).2.1)
            (fun j => (respOf t h j).isReject)} := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Set.mem_inter_iff]
    rw [vCovered_iff2]
  rw [hset]
  refine MeasurableSet.iUnion fun h => ?_
  refine (measurableSet_vResponses_eq mech ctrl hctrl s ω' (fun t r => hmeas t ω' r) (t + 1)
    h).inter ?_
  let pat : Ω → (Fin (t + 1) → Bool) := fun ω j => (reqOf (ctrl ω) t h j).2.1
  have hpat : Measurable pat :=
    measurable_pi_lambda _ fun j => (measurable_reqOf ctrl hctrl t h j).snd.fst
  have hset2 : {ω | covPred M J R t (fun j => (reqOf (ctrl ω) t h j).2.1)
        (fun j => (respOf t h j).isReject)} =
      pat ⁻¹' {v | covPred M J R t (fun j => if hj : j < t + 1 then v ⟨j, hj⟩ else false)
        (fun j => (respOf t h j).isReject)} := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_preimage]
    exact covPred_congr (fun j hj => by simp [pat, show j < t + 1 by omega]) (fun _ _ => rfl)
  rw [hset2]
  exact hpat (Set.to_countable _).measurableSet

include hctrl hmeas in
/-- A measurable property of the views of rounds `0..t` is a measurable event of the controller's
coins. -/
theorem measurableSet_roundViews2 (s : Fin N → U) (ω' : Fin c → Bool) (t : ℕ)
    (Q : (Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ) → Prop) (hQ : MeasurableSet {views | Q views}) :
    MeasurableSet {ω | Q (F2e2e.vRoundViews mech (ctrl ω) s ω' t)} := by
  have hset : {ω | Q (F2e2e.vRoundViews mech (ctrl ω) s ω' t)} =
      ⋃ h : Fin t → F2e2e.VResponse,
        {ω | F2e2e.vResponses mech (ctrl ω) s ω' t = h} ∩
          (fun ω => viewsOf (ctrl ω) s t h) ⁻¹' {views | Q views} := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Set.mem_inter_iff, Set.mem_preimage]
    constructor
    · intro hq; exact ⟨_, rfl, hq⟩
    · rintro ⟨h, hh, hq⟩
      rw [← hh] at hq
      exact hq
  rw [hset]
  exact MeasurableSet.iUnion fun h =>
    (measurableSet_vResponses_eq mech ctrl hctrl s ω' (fun t r => hmeas t ω' r) t h).inter
      (measurable_viewsOf ctrl hctrl s t h hQ)

include hctrl hmeas in
theorem measurableSet_vInternalFails2
    (aborted : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → Bool)
    (peak : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → ℕ → ℕ)
    (M J R : ℕ) (aReq : ℝ)
    (hA : ∀ (t : ℕ) (ω' : Fin c → Bool),
      MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | aborted t views ω' = true})
    (hPk : ∀ (t : ℕ) (ω' : Fin c → Bool) (j n : ℕ),
      MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | n ≤ peak t views ω' j})
    (s : Fin N → U) (ω' : Fin c → Bool) :
    MeasurableSet {ω | F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω'} := by
  have hset : {ω | F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω'} =
      ⋃ t : ℕ, {ω | F2e2e.VCovered mech (ctrl ω) M J R s ω' t} ∩
        ({ω | aborted t (F2e2e.vRoundViews mech (ctrl ω) s ω' t) ω' = true} ∪
          ⋃ j : Fin (F2e2e.valP (F2e2e.dyadicDown aReq)),
            {ω | F2e2e.valTmax (F2e2e.dyadicDown aReq) j.val ≤
              peak t (F2e2e.vRoundViews mech (ctrl ω) s ω' t) ω' j.val}) := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Set.mem_inter_iff, Set.mem_union]
    exact Iff.rfl
  rw [hset]
  refine MeasurableSet.iUnion fun t =>
    (measurableSet_vCovered2 mech ctrl hctrl hmeas M J R s ω' t).inter ?_
  refine (measurableSet_roundViews2 mech ctrl hctrl hmeas s ω' t _ (hA t ω')).union
    (MeasurableSet.iUnion fun j => ?_)
  exact measurableSet_roundViews2 mech ctrl hctrl hmeas s ω' t _ (hPk t ω' j.val _)

end Main

/-! ## `alg2Exec` reads only the rounded data of the views -/

/-- The rounded data of the views read by the Spec's Algorithm 2: rounded query values, request
type, rounded clipped endpoints. -/
noncomputable def roundData (P2 : F2e2e.Alg2Params) {t : ℕ}
    (views : Fin (t + 1) → (Fin P2.N → ℝ) × Bool × ℝ × ℝ) :
    Fin (t + 1) → (Fin P2.N → ℚ) × Bool × ℚ × ℚ :=
  fun j => ((fun m => F2e2e.roundGridQ P2.hA ((views j).1 m)), (views j).2.1,
    F2e2e.roundGridQ P2.hA (max (-1) (min 2 (views j).2.2.1)),
    F2e2e.roundGridQ P2.hA (max (-1) (min 2 (views j).2.2.2)))

theorem alg2Request_congr (P2 : F2e2e.Alg2Params) (st : F2e2e.Alg2State) (tape : List Bool)
    (v v' : (Fin P2.N → ℝ) × Bool × ℝ × ℝ)
    (h1 : ∀ m, F2e2e.roundGridQ P2.hA (v.1 m) = F2e2e.roundGridQ P2.hA (v'.1 m))
    (h2 : v.2.1 = v'.2.1)
    (h3 : F2e2e.roundGridQ P2.hA (max (-1) (min 2 v.2.2.1)) =
      F2e2e.roundGridQ P2.hA (max (-1) (min 2 v'.2.2.1)))
    (h4 : F2e2e.roundGridQ P2.hA (max (-1) (min 2 v.2.2.2)) =
      F2e2e.roundGridQ P2.hA (max (-1) (min 2 v'.2.2.2))) :
    F2e2e.alg2Request P2 st v tape = F2e2e.alg2Request P2 st v' tape := by
  have hev : F2e2e.alg2Evals P2 v.1 = F2e2e.alg2Evals P2 v'.1 := by
    funext m
    unfold F2e2e.alg2Evals
    split_ifs with hm
    · rw [h1]
    · rfl
  unfold F2e2e.alg2Request
  rw [h2, hev]
  by_cases hI : v'.2.1 = true
  · rw [if_pos hI, if_pos hI]
    unfold F2e2e.alg2Interval
    rw [h3, h4]
  · rw [if_neg hI, if_neg hI]

theorem foldl_ofFn_congr {α β : Type} (f : β → α → β) :
    ∀ (n : ℕ) (a b : Fin n → α), (∀ i acc, f acc (a i) = f acc (b i)) →
      ∀ init, (List.ofFn a).foldl f init = (List.ofFn b).foldl f init
  | 0, _, _, _, _ => rfl
  | n + 1, a, b, h, init => by
    rw [List.ofFn_succ, List.ofFn_succ, List.foldl_cons, List.foldl_cons, h 0 init]
    exact foldl_ofFn_congr f n _ _ (fun i acc => h i.succ acc) _

theorem alg2Exec_congr (P2 : F2e2e.Alg2Params) {c t : ℕ} (ω : Fin c → Bool)
    (views views' : Fin (t + 1) → (Fin P2.N → ℝ) × Bool × ℝ × ℝ)
    (h : roundData P2 views = roundData P2 views') :
    F2e2e.alg2Exec P2 t views ω = F2e2e.alg2Exec P2 t views' ω := by
  have hstep : ∀ (i : Fin (t + 1)) (acc : F2e2e.VResponse × F2e2e.Alg2State × List Bool),
      F2e2e.alg2Request P2 acc.2.1 (views i) acc.2.2 =
        F2e2e.alg2Request P2 acc.2.1 (views' i) acc.2.2 := by
    intro i acc
    have hi := congrFun h i
    simp only [roundData, Prod.mk.injEq] at hi
    obtain ⟨h1, h2, h3, h4⟩ := hi
    exact alg2Request_congr P2 _ _ _ _ (fun m => congrFun h1 m) h2 h3 h4
  have e := foldl_ofFn_congr (fun acc v => F2e2e.alg2Request P2 acc.2.1 v acc.2.2) (t + 1)
    views views' hstep
  unfold F2e2e.alg2Exec
  rw [e]

theorem measurable_roundGridQ (h : ℚ) : Measurable (F2e2e.roundGridQ h) := by
  unfold F2e2e.roundGridQ
  have hf : Measurable fun z : ℝ => ⌊z / (h : ℝ) + 1 / 2⌋ :=
    Int.measurable_floor.comp ((measurable_id.div_const _).add_const _)
  exact (measurable_of_countable (fun k : ℤ => h * (k : ℚ))).comp hf

theorem measurable_roundData (P2 : F2e2e.Alg2Params) (t : ℕ) :
    Measurable (roundData P2 (t := t)) := by
  refine measurable_pi_lambda _ fun j => ?_
  have hv : Measurable fun views : Fin (t + 1) → (Fin P2.N → ℝ) × Bool × ℝ × ℝ => views j :=
    measurable_pi_apply j
  refine Measurable.prodMk ?_ (Measurable.prodMk hv.snd.fst (Measurable.prodMk ?_ ?_))
  · exact measurable_pi_lambda _ fun m =>
      (measurable_roundGridQ _).comp ((measurable_pi_apply m).comp hv.fst)
  · exact (measurable_roundGridQ _).comp (measurable_const.max (measurable_const.min hv.snd.snd.fst))
  · exact (measurable_roundGridQ _).comp (measurable_const.max (measurable_const.min hv.snd.snd.snd))

/-- Every property of the outcome of `alg2Exec` is a measurable set of views. -/
theorem measurableSet_alg2Exec (P2 : F2e2e.Alg2Params) {c : ℕ} (t : ℕ) (ω : Fin c → Bool)
    (Q : F2e2e.Alg2Outcome → Prop) :
    MeasurableSet {views : Fin (t + 1) → (Fin P2.N → ℝ) × Bool × ℝ × ℝ |
      Q (F2e2e.alg2Exec P2 t views ω)} := by
  have hset : {views : Fin (t + 1) → (Fin P2.N → ℝ) × Bool × ℝ × ℝ |
      Q (F2e2e.alg2Exec P2 t views ω)} =
      roundData P2 ⁻¹' (roundData P2 '' {views | Q (F2e2e.alg2Exec P2 t views ω)}) := by
    ext views
    simp only [Set.mem_ofPred_eq, Set.mem_preimage, Set.mem_image]
    constructor
    · intro hq; exact ⟨views, hq, rfl⟩
    · rintro ⟨w, hw, he⟩
      rw [← alg2Exec_congr P2 ω w views he]
      exact hw
  rw [hset]
  exact measurable_roundData P2 t (Set.to_countable _).measurableSet

end F2e2e.B.V2
