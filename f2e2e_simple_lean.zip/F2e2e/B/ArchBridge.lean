import F2e2e.B.ArchCount
import F2e2e.B.ArchMeas

/-!
# Bridge: the Spec-level guarantee of `adaAlg2Mech` from the core-level guarantee

* `outResp`, `quantReq`, `specToCore`: a Spec-level controller (real views, Spec responses) induces a
  core-level controller that sees the Spec responses of the core outputs and quantizes its requests
  exactly as `mechOf` does (`specToCore_valid`: it is valid);
* `vResponses_mechOf_eq` (replay = online): the Spec interaction of `mechOf P` on the coins `ω` is
  the online core execution of the induced controller on the bit list `List.ofFn ω` (`mechOf`
  replays rounds `0, …, t` on the same coins: `adaStepQ_eq`, `replay_eq_online`);
* `vCorrect_of_coreCorrect`: core-level correctness at `a_req − h_A` for the quantized request gives
  Spec-level correctness at `a_req` (query and endpoint rounding cost at most `h_A/2` each; clipping
  the endpoints to `[−1, 2]` is sound since `𝒟f ∈ [0, 1]`);
* `vFails_imp_coreFails`, `vDetFailMass_le_of_core` (sum over the coin tapes:
  `BitProg.sum_tapes_eq`), `alg2_guarantee_det_of_core`: `CoreGuaranteeDet ⇒ VGuaranteeDet` for
  `adaAlg2Mech`.
-/

namespace F2e2e.B

open F2e2e.Discrete

/-! ## Generic helpers -/

namespace Bridge

/-- Functoriality of `DrawProg.map`. -/
theorem drawProg_map_map {Pm β α γ δ : Type} (prog : DrawProg Pm β α) (f : α → γ) (g : γ → δ) :
    (prog.map f).map g = prog.map (g ∘ f) := by
  unfold DrawProg.map
  rw [DrawProg.bind_assoc]
  rfl

/-- The last round of `coreLoopSD` (unrolled from the end). -/
theorem coreLoopSD_succ' {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (n : ℕ) (st : AdaState) (hist : List CoreOut),
      coreLoopSD P ctrl s (n + 1) st hist =
        (coreLoopSD P ctrl s n st hist).bind fun r =>
          (coreStepD P s (ctrl r.1) r.2).map fun x => (r.1 ++ [x.1], x.2)
  | 0, st, hist => rfl
  | n + 1, st, hist => by
    rw [show coreLoopSD P ctrl s (n + 1 + 1) st hist = (coreStepD P s (ctrl hist) st).bind
        fun r => coreLoopSD P ctrl s (n + 1) r.2 (hist ++ [r.1]) from rfl,
      show coreLoopSD P ctrl s (n + 1) st hist = (coreStepD P s (ctrl hist) st).bind
        fun r => coreLoopSD P ctrl s n r.2 (hist ++ [r.1]) from rfl,
      DrawProg.bind_assoc]
    congr 1
    funext r
    exact coreLoopSD_succ' P ctrl s n r.2 (hist ++ [r.1])

/-- A draw budget of `p.map f` is one of `p`. -/
theorem drawsLE_of_map {Pm β α γ : Type} {p : DrawProg Pm β α} {f : α → γ} {n : ℕ}
    (h : (p.map f).DrawsLE n) : p.DrawsLE n := by
  induction p generalizing n with
  | ret a => cases n <;> trivial
  | draw q k ih =>
    cases n with
    | zero => exact h.elim
    | succ n => exact fun b => ih b (h b)

/-- The online execution with its final state reads at most `adaCoins P` fair bits. -/
theorem coreRunS_depth_le {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : (coreRunS P ctrl s T).depth ≤ adaCoins P := by
  have hD : (coreRunSD P ctrl s T).DrawsLE (P.p + 1 + (P.M + P.R) * callDraws P) := by
    have := coreRunD_drawsLE P ctrl s T
    rw [coreRunD_eq_map] at this
    exact drawsLE_of_map this
  refine (DrawProg.depth_toBits_le (adaDraw P) (adaDraw_depth_le P) hD).trans (le_of_eq ?_)
  unfold adaCoins adaInitBits adaCallBits callDraws
  ring

/-- Congruence of a Spec-level controller in the length and the history. -/
theorem ctrl_congr {U : Type} (ctrl : VController U) {n m : ℕ} (hnm : n = m)
    (f : Fin n → VResponse) (g : Fin m → VResponse) (hfg : ∀ i : Fin n, f i = g (Fin.cast hnm i)) :
    ctrl n f = ctrl m g := by
  subst hnm
  congr 1
  funext i
  exact hfg i

/-- `h_A > 0`. -/
theorem hA_real_pos (P : AdaParams) : (0 : ℝ) < (P.hA : ℝ) := by
  unfold AdaParams.hA; push_cast; positivity

/-- Population means of uniformly close functions are close. -/
theorem abs_popMean_sub_le {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x)
    (hD1 : ∑ x, D x = 1) (f g : U → ℝ) {ε : ℝ} (h : ∀ x, |f x - g x| ≤ ε) :
    |popMean D f - popMean D g| ≤ ε := by
  unfold popMean
  rw [← Finset.sum_sub_distrib]
  calc |∑ x, (D x * f x - D x * g x)| ≤ ∑ x, |D x * f x - D x * g x| :=
        Finset.abs_sum_le_sum_abs _ _
    _ = ∑ x, D x * |f x - g x| := by
        refine Finset.sum_congr rfl fun x _ => ?_
        rw [← mul_sub, abs_mul, abs_of_nonneg (hD0 x)]
    _ ≤ ∑ x, D x * ε := Finset.sum_le_sum fun x _ => mul_le_mul_of_nonneg_left (h x) (hD0 x)
    _ = ε := by rw [← Finset.sum_mul, hD1, one_mul]

/-- The population mean of a nonnegative function is nonnegative. -/
theorem popMean_nonneg {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (f : U → ℝ)
    (hf : ∀ x, 0 ≤ f x) : 0 ≤ popMean D f :=
  Finset.sum_nonneg fun x _ => mul_nonneg (hD0 x) (hf x)

/-- The population mean of a function bounded by `1` is at most `1`. -/
theorem popMean_le_one {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x)
    (hD1 : ∑ x, D x = 1) (f : U → ℝ) (hf : ∀ x, f x ≤ 1) : popMean D f ≤ 1 := by
  unfold popMean
  calc ∑ x, D x * f x ≤ ∑ x, D x * 1 := Finset.sum_le_sum fun x _ =>
        mul_le_mul_of_nonneg_left (hf x) (hD0 x)
    _ = 1 := by simp [hD1]

/-- A run of the execution with final state gives a run of the execution. -/
theorem coreRun_run_of_S {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T : ℕ)
    (τ : List Bool) {o : List CoreOut} {st : AdaState} {rest : List Bool}
    (h : (coreRunS P ctrl s T).run τ = some ((o, st), rest)) :
    (coreRun P ctrl s T).run τ = some (o, rest) := by
  rw [coreRun_eq_map, BitProg.run_map, h]
  rfl

/-- Finitely many failing pairs `(s, ω)`: a uniform horizon. -/
theorem exists_horizon {U : Type} [Fintype U] {N c : ℕ} (mech : VMechanism N c) (D : U → ℝ)
    (M J R : ℕ) (aReq : ℝ) (ctrl : VController U) :
    ∃ T : ℕ, ∀ (s : Fin N → U) (ω : Fin c → Bool), VFails mech D M J R aReq ctrl s ω →
      ∃ t < T, VCovered mech ctrl M J R s ω t ∧
        ¬ VCorrect D aReq (vRequest mech ctrl s ω t) (vResponse mech ctrl s ω t) := by
  classical
  let w : (Fin N → U) × (Fin c → Bool) → ℕ := fun p =>
    if h : VFails mech D M J R aReq ctrl p.1 p.2 then h.choose else 0
  refine ⟨Finset.univ.sup w + 1, fun s ω hf => ⟨hf.choose, ?_, hf.choose_spec⟩⟩
  have hle : w (s, ω) ≤ Finset.univ.sup w := Finset.le_sup (Finset.mem_univ (s, ω))
  have hw : w (s, ω) = hf.choose := dif_pos hf
  omega

end Bridge

open Bridge

/-! ## Bridge to the Spec-level mechanism -/

/-- The Spec response of a core output. -/
def outResp : CoreOut → VResponse
  | Sum.inl c => certResp c
  | Sum.inr x => numResp x

/-- The Spec-level view of round `hist.length` when the previous core outputs are `hist`. -/
def specView {U : Type} {N : ℕ} (ctrl : VController U) (s : Fin N → U) (hist : List CoreOut) :
    VView N :=
  ((fun ℓ => (ctrl hist.length (fun i => outResp (hist.getD i.val (Sum.inl AdaCert.abort)))).1 (s ℓ)),
    (ctrl hist.length (fun i => outResp (hist.getD i.val (Sum.inl AdaCert.abort)))).2)

/-- The core request of a Spec request (as `mechOf` quantizes: grid indices of the clipped values,
grid points of the clipped endpoints). -/
noncomputable def quantReq {U : Type} (P : AdaParams) (r : (U → ℝ) × Bool × ℝ × ℝ) : CoreReq U where
  f := fun x => valIdx P (r.1 x)
  isInterval := r.2.1
  l := P.hA * (endIdx P r.2.2.1 : ℚ)
  u := P.hA * (endIdx P r.2.2.2 : ℚ)

/-- The core-level controller induced by a Spec-level controller: it sees the Spec responses of the
outputs and quantizes the request exactly as `mechOf` does. -/
noncomputable def specToCore {U : Type} (P : AdaParams) (ctrl : VController U) : CoreCtrl U :=
  fun hist => quantReq P (ctrl hist.length (fun i => outResp (hist.getD i.val (Sum.inl AdaCert.abort))))

/-- One round of the replay = one online round, with the Spec responses of the outputs. -/
theorem adaStepQ_eq {U : Type} (P : AdaParams) (ctrl : VController U) (s : Fin P.N → U)
    (st : AdaState) (hist : List CoreOut) :
    adaStepQ P st (quantView P (specView ctrl s hist)) =
      (coreStepD P s (specToCore P ctrl hist) st).map fun r => (outResp r.1, r.2) := by
  unfold adaStepQ coreStepD
  by_cases hI : (ctrl hist.length (fun i => outResp (hist.getD i.val (Sum.inl AdaCert.abort)))).2.1 = true
  · rw [if_pos (show (quantView P (specView ctrl s hist)).2.1 = true from hI),
      if_pos (show (specToCore P ctrl hist).isInterval = true from hI), drawProg_map_map]
    rfl
  · rw [if_neg (show ¬ (quantView P (specView ctrl s hist)).2.1 = true from hI),
      if_neg (show ¬ (specToCore P ctrl hist).isInterval = true from hI), drawProg_map_map]
    rfl

/-- The replay of the views of an online execution reproduces its Spec responses. -/
theorem replay_eq_online {U : Type} (P : AdaParams) (ctrl : VController U) (s : Fin P.N → U) :
    ∀ (n : ℕ) (st : AdaState) (hist : List CoreOut) (τ : List Bool) (o : List CoreOut)
      (st' : AdaState) (rest : List Bool),
      ((coreLoopSD P (specToCore P ctrl) s n st hist).toBits (adaDraw P)).run τ =
          some ((o, st'), rest) →
      ∃ o' : List CoreOut, o = hist ++ o' ∧ o'.length = n ∧
        ((adaRunQ P st (List.ofFn fun j : Fin n =>
            quantView P (specView ctrl s (hist ++ o'.take j)))).toBits (adaDraw P)).run τ =
          some (o'.map outResp, rest)
  | 0, st, hist, τ, o, st', rest, h => by
    simp only [coreLoopSD, DrawProg.toBits_ret, BitProg.run_pure, Option.some.injEq,
      Prod.mk.injEq] at h
    obtain ⟨⟨rfl, rfl⟩, rfl⟩ := h
    refine ⟨[], by simp, rfl, ?_⟩
    rfl
  | n + 1, st, hist, τ, o, st', rest, h => by
    simp only [coreLoopSD] at h
    rw [DrawProg.toBits_bind, BitProg.run_bind, Option.bind_eq_some_iff] at h
    obtain ⟨⟨r1, τ1⟩, hr1, hloop⟩ := h
    obtain ⟨o'', ho, hlen, hrep⟩ := replay_eq_online P ctrl s n r1.2 (hist ++ [r1.1]) τ1 o st' rest
      hloop
    refine ⟨r1.1 :: o'', by rw [ho]; simp, by simp [hlen], ?_⟩
    rw [List.ofFn_succ]
    simp only [Fin.val_zero, List.take_zero, List.append_nil, Fin.val_succ]
    unfold adaRunQ
    rw [adaStepQ_eq, DrawProg.toBits_bind, BitProg.run_bind, DrawProg.toBits_map, BitProg.run_map,
      hr1]
    simp only [Option.map_some, Option.bind_some]
    rw [DrawProg.toBits_map, BitProg.run_map]
    have hviews : (List.ofFn fun i : Fin n =>
        quantView P (specView ctrl s (hist ++ List.take (i + 1) (r1.1 :: o'')))) =
        List.ofFn fun j : Fin n => quantView P (specView ctrl s (hist ++ [r1.1] ++ o''.take j)) := by
      congr 1
      funext j
      simp
    rw [hviews, hrep]
    simp

/-- **Replay = online**: the Spec interaction of `mechOf P` with a controller on the coins `ω` gives
the Spec responses of the online core execution of the induced controller on `List.ofFn ω`. -/
theorem vResponses_mechOf_eq {U : Type} (P : AdaParams) (ctrl : VController U) (s : Fin P.N → U)
    (ω : Fin (adaCoins P) → Bool) (t : ℕ) :
    ∃ (o : List CoreOut) (st : AdaState) (rest : List Bool),
      (coreRunS P (specToCore P ctrl) s t).run (List.ofFn ω) = some ((o, st), rest) ∧
      o.length = t ∧
      ∀ i : Fin t, vResponses (mechOf P) ctrl s ω t i = outResp (o.getD i (Sum.inl AdaCert.abort)) := by
  set τ := List.ofFn ω with hτ
  have hlen : (adaCoins P) ≤ τ.length := by rw [hτ, List.length_ofFn]
  -- every online run succeeds
  have hsome : ∀ T, ((coreRunS P (specToCore P ctrl) s T).run τ).isSome := fun T =>
    BitProg.run_isSome _ _ ((coreRunS_depth_le P _ s T).trans hlen)
  -- the initialization
  have hsplit : ∀ T, (coreRunS P (specToCore P ctrl) s T).run τ =
      ((adaInitD P).toBits (adaDraw P) |>.run τ).bind fun r =>
        ((coreLoopSD P (specToCore P ctrl) s T r.1 []).toBits (adaDraw P)).run r.2 := by
    intro T
    unfold coreRunS coreRunSD
    rw [DrawProg.toBits_bind, BitProg.run_bind]
  obtain ⟨⟨st0, τ0⟩, hinit⟩ : ∃ r, ((adaInitD P).toBits (adaDraw P)).run τ = some r := by
    have h0 := hsome 0
    rw [hsplit] at h0
    cases hr : ((adaInitD P).toBits (adaDraw P)).run τ with
    | none => rw [hr] at h0; simp at h0
    | some r => exact ⟨r, rfl⟩
  have hloopSome : ∀ T, (((coreLoopSD P (specToCore P ctrl) s T st0 []).toBits (adaDraw P)).run
      τ0).isSome := by
    intro T
    have := hsome T
    rwa [hsplit, hinit, Option.bind_some] at this
  -- the claim on the loops from `(st0, τ0)`
  have claim : ∀ t : ℕ, ∃ (o : List CoreOut) (st : AdaState) (rest : List Bool),
      ((coreLoopSD P (specToCore P ctrl) s t st0 []).toBits (adaDraw P)).run τ0 =
        some ((o, st), rest) ∧ o.length = t ∧
      ∀ i : Fin t, vResponses (mechOf P) ctrl s ω t i = outResp (o.getD i (Sum.inl AdaCert.abort)) := by
    intro t
    induction t with
    | zero => exact ⟨[], st0, τ0, rfl, rfl, fun i => i.elim0⟩
    | succ t ih =>
      obtain ⟨o, st, rest, hrun, holen, hresp⟩ := ih
      have hS := hloopSome (t + 1)
      rw [coreLoopSD_succ', DrawProg.toBits_bind, BitProg.run_bind, hrun, Option.bind_some,
        DrawProg.toBits_map, BitProg.run_map] at hS
      obtain ⟨⟨⟨x, st'⟩, rest'⟩, hstep⟩ : ∃ r, ((coreStepD P s (specToCore P ctrl o) st).toBits
          (adaDraw P)).run rest = some r := by
        cases hr : ((coreStepD P s (specToCore P ctrl o) st).toBits (adaDraw P)).run rest with
        | none => rw [hr] at hS; simp at hS
        | some r => exact ⟨r, rfl⟩
      have hrun' : ((coreLoopSD P (specToCore P ctrl) s (t + 1) st0 []).toBits (adaDraw P)).run τ0 =
          some ((o ++ [x], st'), rest') := by
        rw [coreLoopSD_succ', DrawProg.toBits_bind, BitProg.run_bind, hrun, Option.bind_some,
          DrawProg.toBits_map, BitProg.run_map, hstep]
        rfl
      refine ⟨o ++ [x], st', rest', hrun', by simp [holen], fun i => ?_⟩
      rw [vResponses_succ]
      refine Fin.lastCases ?_ (fun i' => ?_) i
      · -- the last response: the replay of the views of rounds `0..t`
        rw [Fin.snoc_last]
        have hviews : (fun j : Fin (t + 1) =>
            quantView P (viewsOf ctrl s t (vResponses (mechOf P) ctrl s ω t) j)) =
            fun j : Fin (t + 1) => quantView P (specView ctrl s ([] ++ (o ++ [x]).take j)) := by
          funext j
          congr 1
          have hj : j.val ≤ o.length := by rw [holen]; exact Nat.lt_succ_iff.mp j.isLt
          have htake : (o ++ [x]).take j.val = o.take j.val := List.take_append_of_le_length hj
          rw [List.nil_append, htake]
          have hc : ctrl j.val (fun l : Fin j.val => vResponses (mechOf P) ctrl s ω t
              (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) =
              ctrl (o.take j.val).length (fun i => outResp ((o.take j.val).getD i.val
                (Sum.inl AdaCert.abort))) := by
            refine ctrl_congr ctrl (by simp [List.length_take, hj]) _ _ fun l => ?_
            rw [hresp]
            congr 1
            simp only [Fin.val_castLE, Fin.val_cast]
            rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take_of_lt l.isLt]
          unfold viewsOf specView
          rw [hc]
        obtain ⟨o', ho', ho'len, hrep⟩ := replay_eq_online P ctrl s (t + 1) st0 [] τ0 (o ++ [x]) st'
          rest' hrun'
        rw [List.nil_append] at ho'
        subst ho'
        show mechQ P t (fun j => quantView P (viewsOf ctrl s t (vResponses (mechOf P) ctrl s ω t) j)) ω =
          outResp ((o ++ [x]).getD (Fin.last t).val (Sum.inl AdaCert.abort))
        unfold mechQ adaProgQ
        rw [DrawProg.toBits_bind, BitProg.run_bind, ← hτ, hinit, Option.bind_some, hviews, hrep]
        simp [holen]
      · -- earlier responses
        rw [Fin.snoc_castSucc, hresp]
        congr 1
        simp only [Fin.val_castSucc]
        rw [List.getD_append _ _ _ _ (by rw [holen]; exact i'.isLt)]
  obtain ⟨o, st, rest, hrun, holen, hresp⟩ := claim t
  exact ⟨o, st, rest, by rw [hsplit, hinit, Option.bind_some, hrun], holen, hresp⟩

/-! ## Rounding: core-level correctness at `a_req − h_A` gives Spec-level correctness at `a_req` -/

/-- The grid value of a query value in `[0, 1]` is its lattice rounding. -/
theorem valIdx_cast (P : AdaParams) {x : ℝ} (h0 : 0 ≤ x) (h1 : x ≤ 1) :
    (P.hA : ℝ) * (valIdx P x : ℝ) = roundLat (P.hA : ℝ) x := by
  have hx : max 0 (min 1 x) = x := by rw [min_eq_right h1, max_eq_right h0]
  have hnn : 0 ≤ roundIdx (P.hA : ℝ) x := by
    unfold roundIdx
    apply Int.floor_nonneg.mpr
    have := hA_real_pos P
    positivity
  unfold valIdx
  rw [hx, roundLat_eq]
  congr 1
  exact_mod_cast Int.toNat_of_nonneg hnn

/-- The grid point of an endpoint is the lattice rounding of the clipped endpoint. -/
theorem endIdx_cast (P : AdaParams) (x : ℝ) :
    (((P.hA * (endIdx P x : ℚ) : ℚ)) : ℝ) = roundLat (P.hA : ℝ) (max (-1) (min 2 x)) := by
  push_cast
  rfl

/-- Endpoint rounding error: at most `h_A/2` from the clipped endpoint. -/
theorem abs_endIdx_sub_le (P : AdaParams) (x : ℝ) :
    |(((P.hA * (endIdx P x : ℚ) : ℚ)) : ℝ) - max (-1) (min 2 x)| ≤ (P.hA : ℝ) / 2 := by
  rw [endIdx_cast]; exact abs_roundLat_sub_le (hA_real_pos P) _

/-- **Rounding.** Core-level correctness at `a_req − h_A` for the quantized request (grid-valued
query `h_A·valIdx`, grid endpoints) gives Spec-level correctness at `a_req` for the original request:
the query rounding moves the mean by at most `h_A/2`, the endpoint rounding by at most `h_A/2`, and
clipping the endpoints to `[−1, 2]` only matters when the claim is trivial (`𝒟f ∈ [0, 1]`). -/
theorem vCorrect_of_coreCorrect {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) {aReq : ℝ} (ha1 : aReq < 1)
    (r : (U → ℝ) × Bool × ℝ × ℝ) (hr : ∀ x, 0 ≤ r.1 x ∧ r.1 x ≤ 1) (out : CoreOut)
    (h : coreCorrect D P.hA (aReq - P.hA) (quantReq P r) out) : VCorrect D aReq r (outResp out) := by
  have hA0 := hA_real_pos P
  set μ := popMean D r.1 with hμdef
  set μh := popMean D (fun x => (P.hA : ℝ) * (valIdx P (r.1 x) : ℝ)) with hμhdef
  have hclose : |μh - μ| ≤ (P.hA : ℝ) / 2 := by
    refine abs_popMean_sub_le D hD0 hD1 _ _ fun x => ?_
    rw [valIdx_cast P (hr x).1 (hr x).2]
    exact abs_roundLat_sub_le hA0 _
  have hμ0 : 0 ≤ μ := popMean_nonneg D hD0 _ fun x => (hr x).1
  have hμ1 : μ ≤ 1 := popMean_le_one D hD0 hD1 _ fun x => (hr x).2
  have hl := abs_endIdx_sub_le P r.2.2.1
  have hu := abs_endIdx_sub_le P r.2.2.2
  rcases abs_le.mp hclose with ⟨hc1, hc2⟩
  rcases abs_le.mp hl with ⟨hl1, hl2⟩
  rcases abs_le.mp hu with ⟨hu1, hu2⟩
  have hcl1 : -1 ≤ max (-1) (min 2 r.2.2.1) := le_max_left _ _
  have hcu1 : -1 ≤ max (-1) (min 2 r.2.2.2) := le_max_left _ _
  have hcl2 : max (-1) (min 2 r.2.2.1) ≤ 2 := max_le (by norm_num) (min_le_left _ _)
  have hcu2 : max (-1) (min 2 r.2.2.2) ≤ 2 := max_le (by norm_num) (min_le_left _ _)
  -- clip facts
  have clip_ge : ∀ y : ℝ, y ≤ 2 → y ≤ max (-1) (min 2 y) := fun y hy => by
    rw [min_eq_right hy]; exact le_max_right _ _
  have clip_le : ∀ y : ℝ, -1 ≤ y → max (-1) (min 2 y) ≤ y := fun y hy =>
    max_le hy (min_le_right _ _)
  have clip_hi : ∀ y : ℝ, 2 < y → max (-1) (min 2 y) = 2 := fun y hy => by
    rw [min_eq_left hy.le]; norm_num
  have clip_lo : ∀ y : ℝ, y < -1 → max (-1) (min 2 y) = -1 := fun y hy => by
    rw [max_eq_left]; exact (min_le_right _ _).trans hy.le
  unfold coreCorrect at h
  unfold VCorrect
  by_cases hI : r.2.1 = true
  · rw [if_pos (show (quantReq P r).isInterval = true from hI)] at h
    rw [if_pos hI]
    simp only [quantReq] at h
    rcases out with c | x
    · cases c with
      | accept =>
        obtain ⟨h1, h2⟩ := h
        simp only [outResp, certResp]
        constructor
        · by_cases hl2' : r.2.2.1 ≤ 2
          · have := clip_ge _ hl2'; linarith
          · have := clip_hi _ (lt_of_not_ge hl2'); linarith
        · by_cases hu1' : -1 ≤ r.2.2.2
          · have := clip_le _ hu1'; linarith
          · have := clip_lo _ (lt_of_not_ge hu1'); linarith
      | high =>
        simp only [outResp, certResp]
        by_cases hu2' : r.2.2.2 ≤ 2
        · have := clip_ge _ hu2'; linarith
        · have := clip_hi _ (lt_of_not_ge hu2'); linarith
      | termHigh =>
        simp only [outResp, certResp]
        by_cases hu2' : r.2.2.2 ≤ 2
        · have := clip_ge _ hu2'; linarith
        · have := clip_hi _ (lt_of_not_ge hu2'); linarith
      | low =>
        simp only [outResp, certResp]
        by_cases hl1' : -1 ≤ r.2.2.1
        · have := clip_le _ hl1'; linarith
        · have := clip_lo _ (lt_of_not_ge hl1'); linarith
      | termLow =>
        simp only [outResp, certResp]
        by_cases hl1' : -1 ≤ r.2.2.1
        · have := clip_le _ hl1'; linarith
        · have := clip_lo _ (lt_of_not_ge hl1'); linarith
      | abort => exact h.elim
    · exact h.elim
  · rw [if_neg (show ¬ (quantReq P r).isInterval = true from hI)] at h
    rw [if_neg hI]
    simp only [quantReq] at h
    rcases out with c | x
    · exact h.elim
    · cases x with
      | val q =>
        obtain ⟨h0, h1, h2⟩ := h
        simp only [outResp, numResp]
        refine ⟨h0, h1, ?_⟩
        calc |(q : ℝ) - μ| ≤ |(q : ℝ) - μh| + |μh - μ| := abs_sub_le _ _ _
          _ ≤ (aReq - P.hA) + P.hA / 2 := add_le_add h2 hclose
          _ ≤ aReq := by linarith
      | abort => exact h.elim

/-! ## Validity of the induced controller -/

/-- Rejections are preserved by `outResp`. -/
theorem outResp_isReject (out : CoreOut) : (outResp out).isReject = coreIsReject out := by
  rcases out with c | x
  · cases c <;> rfl
  · cases x <;> rfl

/-- Grid indices of query values are at most `2^{qA}` (values at most `1`). -/
theorem valIdx_le (P : AdaParams) (x : ℝ) : valIdx P x ≤ 2 ^ P.qA := by
  have hA0 := hA_real_pos P
  have hy1 : max 0 (min 1 x) ≤ 1 := max_le zero_le_one (min_le_left _ _)
  have h2 : (2 : ℝ) ^ P.qA * (P.hA : ℝ) = 1 := by
    unfold AdaParams.hA; push_cast; rw [← mul_pow]; norm_num
  have hdiv : max 0 (min 1 x) / (P.hA : ℝ) ≤ 2 ^ P.qA := by
    rw [div_le_iff₀ hA0]; linarith
  unfold valIdx roundIdx
  rw [Int.toNat_le, Int.floor_le_iff]
  push_cast
  linarith

/-- The endpoint quantization is monotone. -/
theorem endIdx_mono (P : AdaParams) {x y : ℝ} (h : x ≤ y) : endIdx P x ≤ endIdx P y := by
  unfold endIdx
  exact roundIdx_mono (hA_real_pos P) (max_le_max le_rfl (min_le_min le_rfl h))

/-- The induced core-level controller is valid. -/
theorem specToCore_valid {U : Type} (P : AdaParams) (ctrl : VController U) (h : ctrl.Valid) :
    (specToCore P ctrl).Valid P := by
  intro hist
  refine ⟨fun x => valIdx_le P _, fun hI => ?_⟩
  have hlu := (h hist.length (fun i => outResp (hist.getD i.val (Sum.inl AdaCert.abort)))).2 hI
  have hA0 : (0 : ℚ) ≤ P.hA := by unfold AdaParams.hA; positivity
  have hmono := endIdx_mono P hlu
  show P.hA * (endIdx P _ : ℚ) ≤ P.hA * (endIdx P _ : ℚ)
  exact mul_le_mul_of_nonneg_left (by exact_mod_cast hmono) hA0

/-! ## Spec-level failure ⇒ core-level failure -/

/-- Within the horizon of the online run, the induced controller's requests are the quantized
Spec requests. -/
theorem coreReqAt_specToCore {U : Type} (P : AdaParams) (ctrl : VController U) (s : Fin P.N → U)
    (ω : Fin (adaCoins P) → Bool) {T : ℕ} {o : List CoreOut} (holen : o.length = T)
    (hresp : ∀ i : Fin T,
      vResponses (mechOf P) ctrl s ω T i = outResp (o.getD i (Sum.inl AdaCert.abort)))
    {j : ℕ} (hj : j ≤ T) :
    coreReqAt (specToCore P ctrl) o j = quantReq P (vRequest (mechOf P) ctrl s ω j) := by
  unfold coreReqAt specToCore vRequest
  congr 1
  symm
  refine ctrl_congr ctrl (by simp [List.length_take, holen, hj]) _ _ fun i => ?_
  rw [vResponses_prefix (mechOf P) ctrl s ω T j hj i, hresp]
  congr 1
  simp only [Fin.val_castLE, Fin.val_cast]
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take_of_lt i.isLt]

/-- Within the horizon of the online run, the Spec responses are the `outResp` of the core
outputs. -/
theorem vResponse_eq_outResp {U : Type} (P : AdaParams) (ctrl : VController U) (s : Fin P.N → U)
    (ω : Fin (adaCoins P) → Bool) {T : ℕ} {o : List CoreOut}
    (hresp : ∀ i : Fin T,
      vResponses (mechOf P) ctrl s ω T i = outResp (o.getD i (Sum.inl AdaCert.abort)))
    {j : ℕ} (hj : j < T) :
    vResponse (mechOf P) ctrl s ω j = outResp (coreOutAt o j) := by
  unfold vResponse coreOutAt
  rw [vResponses_prefix (mechOf P) ctrl s ω T (j + 1) hj (Fin.last j), hresp]
  rfl

/-- A covered incorrect Spec response (at `a_req`) within the horizon `T` of the online core run is a
covered incorrect core output (at `a_req − h_A`). -/
theorem vFails_imp_coreFails {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) {aReq : ℝ} (ha1 : aReq < 1)
    (ctrl : VController U) (hvalid : ctrl.Valid) (s : Fin P.N → U) (ω : Fin (adaCoins P) → Bool)
    {t T : ℕ} (htT : t < T)
    (hcov : VCovered (mechOf P) ctrl P.M P.J P.R s ω t)
    (hinc : ¬ VCorrect D aReq (vRequest (mechOf P) ctrl s ω t) (vResponse (mechOf P) ctrl s ω t))
    {o : List CoreOut} (holen : o.length = T)
    (hresp : ∀ i : Fin T,
      vResponses (mechOf P) ctrl s ω T i = outResp (o.getD i (Sum.inl AdaCert.abort))) :
    coreFails P D (aReq - P.hA) (specToCore P ctrl) o := by
  refine ⟨t, by rw [holen]; exact htT, ?_, fun hc => hinc ?_⟩
  · show covPred P.M P.J P.R t (fun j => (coreReqAt (specToCore P ctrl) o j).isInterval)
      (fun j => coreIsReject (coreOutAt o j))
    rw [vCovered_eq_covPred] at hcov
    refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mp hcov
    · rw [coreReqAt_specToCore P ctrl s ω holen hresp (by omega)]
      rfl
    · rw [vResponse_eq_outResp P ctrl s ω hresp (by omega), outResp_isReject]
  · rw [coreReqAt_specToCore P ctrl s ω holen hresp htT.le] at hc
    rw [vResponse_eq_outResp P ctrl s ω hresp htT]
    exact vCorrect_of_coreCorrect P D hD0 hD1 ha1 (vRequest (mechOf P) ctrl s ω t)
      (hvalid t (vResponses (mechOf P) ctrl s ω t)).1 _ hc

/-! ## The Spec-level failure mass from the core-level guarantee -/

/-- The Spec-level failure mass of `mechOf P` against a deterministic valid controller is at most
`2^c` times any bound on the core-level failure probability (at accuracy `a_req − h_A`) of the
induced controller, uniform in the horizon. -/
theorem vDetFailMass_le_of_core {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) {aReq : ℝ} (ha1 : aReq < 1)
    (ctrl : VController U) (hvalid : ctrl.Valid) (B : ENNReal)
    (hcore : ∀ T : ℕ, ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRun P (specToCore P ctrl) s T).law.toOuterMeasure
          {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o} ≤ B) :
    vDetFailMass (mechOf P) D P.M P.J P.R aReq ctrl ≤ B * 2 ^ adaCoins P := by
  classical
  obtain ⟨T, hT⟩ := exists_horizon (mechOf P) D P.M P.J P.R aReq ctrl
  have hpt : ∀ (s : Fin P.N → U) (ω : Fin (adaCoins P) → Bool),
      (if VFails (mechOf P) D P.M P.J P.R aReq ctrl s ω then (1 : ENNReal) else 0) ≤
        ((coreRun P (specToCore P ctrl) s T).run (List.ofFn ω)).elim 0
          (fun r => {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o}.indicator 1 r.1) := by
    intro s ω
    split_ifs with hf
    · obtain ⟨t, htT, hcov, hinc⟩ := hT s ω hf
      obtain ⟨o, st, rest, hrun, holen, hresp⟩ := vResponses_mechOf_eq P ctrl s ω T
      rw [coreRun_run_of_S P (specToCore P ctrl) s T _ hrun]
      have hfail : o ∈ {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o} :=
        vFails_imp_coreFails P D hD0 hD1 ha1 ctrl hvalid s ω htT hcov hinc holen hresp
      simp [Set.indicator_of_mem hfail]
    · exact zero_le
  have hsum : ∀ s : Fin P.N → U, ∑ ω : Fin (adaCoins P) → Bool,
      (if VFails (mechOf P) D P.M P.J P.R aReq ctrl s ω then (1 : ENNReal) else 0) ≤
        2 ^ adaCoins P * (coreRun P (specToCore P ctrl) s T).law.toOuterMeasure
          {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o} := by
    intro s
    refine (Finset.sum_le_sum fun ω _ => hpt s ω).trans (le_of_eq ?_)
    rw [BitProg.sum_tapes_eq _ (coreRun_depth_le P (specToCore P ctrl) s T)
      ({o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o}.indicator 1),
      PMF.toOuterMeasure_apply]
    congr 1
    refine tsum_congr fun o => ?_
    by_cases ho : o ∈ {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o}
    · simp [Set.indicator_of_mem ho]
    · simp [Set.indicator_of_notMem ho]
  calc vDetFailMass (mechOf P) D P.M P.J P.R aReq ctrl
      = ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) * ∑ ω : Fin (adaCoins P) → Bool,
          (if VFails (mechOf P) D P.M P.J P.R aReq ctrl s ω then (1 : ENNReal) else 0) := by
        unfold vDetFailMass
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [Finset.mul_sum]
    _ ≤ ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (2 ^ adaCoins P * (coreRun P (specToCore P ctrl) s T).law.toOuterMeasure
            {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o}) :=
        Finset.sum_le_sum fun s _ => mul_le_mul' le_rfl (hsum s)
    _ = 2 ^ adaCoins P * ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRun P (specToCore P ctrl) s T).law.toOuterMeasure
            {o | coreFails P D (aReq - (P.hA : ℝ)) (specToCore P ctrl) o} := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun s _ => ?_
        ring
    _ ≤ 2 ^ adaCoins P * B := mul_le_mul' le_rfl (hcore T)
    _ = B * 2 ^ adaCoins P := mul_comm _ _

/-- The Spec-level guarantee for deterministic controllers follows from the core-level one (query and
endpoint rounding cost at most `h_A`; clipping the endpoints is sound). -/
theorem alg2_guarantee_det_of_core (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq)
    (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (hdet : CoreGuaranteeDet M J R aReq ξReq) :
    VGuaranteeDet M J R aReq ξReq (adaAlg2Mech M J R aReq ξReq) := by
  intro U _ D hD0 hD1 ctrl hvalid
  exact vDetFailMass_le_of_core (adaAlg2Params M J R aReq ξReq) D hD0 hD1 (by linarith) ctrl hvalid _
    fun T => hdet U D hD0 hD1 _ (specToCore_valid _ ctrl hvalid) T

end F2e2e.B
