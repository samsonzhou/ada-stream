import F2e2e.B.AccuracyBlocks
import F2e2e.B.AccuracyDraw
import F2e2e.B.ArchCoreSpec
import F2e2e.Lib.Opt.QuadraticPotential

/-!
# Theorem `R:thm:validation_ada` (P5): objects of the good-event analysis

Paper: `parts/partII.tex` L1034–1046 ("Transfer and accuracy"), with Lemma
`R:lem:sec3_potential_contraction` (L844–946) and Algorithm 2 (L752–777, `F2e2e/B/ArchCore.lean`).

The deterministic part of (P5) follows the core `adaIntervalD` / `adaNumericalD` along every path of noise
draws on which every draw is *good* (`NoiseGood`: `|h_A k| ≤ rad κ` for a draw of kind `κ`), relative to
fixed comparators `u_j` (Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` (i): `CompAdmissible`) that are
accurate on the current query (`CompCond`, `R:eq:sec3_good_comparator_cond`). The state invariant `AccInv`
carries
* the exact learner weights (`capWeightsQ`, = `Opt.Quad.learnerWeights` by `capWeightsQ_spec`),
* goodness of the persistent thresholds (drawn earlier),
* the potential budget `P + (25/128) τ² ∑_j 4^j T_j ≤ 1` (Lemma 3.5 (i), (iii)–(v)), which gives
  `T_j < T_j^max` (no `CAP_ABORT`),
* no `CAP_ABORT` so far, halting only by the terminal `(J+1)`-st rejection.
The outcome predicates `CertSound`, `NumSound` are the certificate/answer bounds relative to the population value
`c = 𝒟 f̂` of the (grid-valued) query and the core's rounded clipped endpoints; `IntervalBook`, `NumericalBook`
record the counter updates (refused requests: `abort`, no state change; processed requests: never `abort`).
-/

namespace F2e2e.B

open F2e2e.Discrete F2e2e.Opt.Quad

noncomputable section

/-! ## Good noise -/

/-- A draw of kind `κ` with lattice index `k` is good for the noise radii `rad`: `|h_A k| ≤ rad κ`. -/
def NoiseGood (P : AdaParams) (rad : NoiseKind → ℚ) (κ : NoiseKind) (k : ℤ) : Prop :=
  |P.hA * (k : ℚ)| ≤ rad κ

/-- Adequate noise radii (L1036, in the combined forms used by Lemma 3.5 (iii) and by the outer and numerical
certificates): internal threshold + test `≤ 2h`, outer threshold + test `≤ a/4`, numerical `≤ a/4`. -/
structure RadOK (P : AdaParams) (rad : NoiseKind → ℚ) : Prop where
  int : rad NoiseKind.intThr + rad NoiseKind.intTest ≤ 2 * (P.tau / 64)
  out : rad NoiseKind.outThr + rad NoiseKind.outTest ≤ P.a / 4
  num : rad NoiseKind.num ≤ P.a / 4

/-! ## Real-valued views of blocks, scores and comparators -/

/-- The values of the (grid-valued) query on block `j`: `x_j(i) = h_A v_{j,i} = f̂(X_{j,i}) ∈ [0, 1]`. -/
def blockX (P : AdaParams) (vals : List (List ℕ)) (j : ℕ) : Fin (blockN P j) → ℝ :=
  fun i => ((P.hA * ((blockVals P vals j).getD i 0 : ℚ) : ℚ) : ℝ)

/-- The real scores `G_j = (h_A/4) g_j` of the learned block `j` (the core stores `g_j = 4 G_j/h_A`). -/
def blockG (P : AdaParams) (st : AdaState) (j : ℕ) : Fin (blockN P j) → ℝ :=
  fun i => ((P.hA / 4 * ((st.scores.getD j []).getD i 0 : ℚ) : ℚ) : ℝ)

/-- The comparator radii `θ_j = (p 4^j)^{-1/2}` (`j < p`) and `θ_p = h/(2√2)` (L689). -/
def accTheta (P : AdaParams) (j : ℕ) : ℝ :=
  if j < P.p then (Real.sqrt (P.p * 4 ^ j))⁻¹ else ((P.tau : ℝ) / 64) / (2 * Real.sqrt 2)

/-- Admissible comparators (Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` (i) with `ϑ_j ≤ θ_j`):
`u_j ∈ W_j` for the learned blocks and `R_j(u_j) ≤ θ_j²` for every block `j ≤ p`. -/
structure CompAdmissible (P : AdaParams) (u : (j : ℕ) → Fin (blockN P j) → ℝ) : Prop where
  mem : ∀ j < P.p, u j ∈ cappedSimplex (blockN P j) 8
  reg : ∀ j ≤ P.p, Opt.Quad.quadReg (blockN P j) (u j) ≤ accTheta P j ^ 2

/-- The comparator condition (`R:eq:sec3_good_comparator_cond`, second part) for one query, whose values on
the blocks are `vals` and whose population value is `c`: `|⟨u_j, f̂(S_j)⟩ - c| ≤ h` for every block `j ≤ p`. -/
def CompCond (P : AdaParams) (u : (j : ℕ) → Fin (blockN P j) → ℝ) (vals : List (List ℕ)) (c : ℝ) :
    Prop :=
  ∀ j ≤ P.p, |∑ i, u j i * blockX P vals j i - c| ≤ (P.tau : ℝ) / 64

/-- The block values have the block sizes. -/
def ValsOK (P : AdaParams) (vals : List (List ℕ)) : Prop :=
  ∀ j ≤ P.p, (vals.getD j []).length = blockN P j

/-! ## Parameter facts used by the deterministic analysis -/

/-- The facts about the parameters used by the deterministic good-event analysis (proved for
`adaAlg2Params` in `F2e2e/B/AccuracyTail.lean`). -/
structure AccParamsOK (P : AdaParams) : Prop where
  two_le_p : 2 ≤ P.p
  sizes_len : P.blockSizes.length = P.p + 1
  n_pos : ∀ j ≤ P.p, 0 < blockN P j
  Tmax_len : P.Tmax.length = P.p
  Tmax_eq : ∀ j < P.p, P.Tmax.getD j 0 = ⌈(6 : ℚ) / (4 ^ j * P.tau ^ 2)⌉₊
  tau_pos : 0 < P.tau
  kappa_eq : P.kappa = P.tau / 4
  a_pos : 0 < P.a
  a_le : P.a ≤ 1 / 10

/-! ## The state invariant -/

/-- The joint weighted potential `P = ∑_{j<p} 4^j Ψ_j(G_j)` of the state relative to the comparators `u`
(`R:eq:sec3_P_def`), with `κ = τ/4`, cap `8/n_j`. -/
def statePotential (P : AdaParams) (u : (j : ℕ) → Fin (blockN P j) → ℝ) (st : AdaState) : ℝ :=
  jointPotential P.p (blockN P) 8 (P.kappa : ℝ) u (blockG P st)

/-- The weighted correction count `∑_{j<p} 4^j T_j`. -/
def weightedT (P : AdaParams) (st : AdaState) : ℝ :=
  ∑ j ∈ Finset.range P.p, (4 : ℝ) ^ j * (st.T.getD j 0 : ℝ)

/-- **The good-event invariant** of the state relative to the comparators `u` and the noise radii `rad`. -/
structure AccInv (P : AdaParams) (rad : NoiseKind → ℚ) (u : (j : ℕ) → Fin (blockN P j) → ℝ)
    (st : AdaState) : Prop where
  scores_len : st.scores.length = P.p
  score_len : ∀ j < P.p, (st.scores.getD j []).length = blockN P j
  weights_len : st.weights.length = P.p
  weights_eq : ∀ j < P.p, st.weights.getD j [] = capWeightsQ (scoreScale P) (st.scores.getD j [])
  T_len : st.T.length = P.p
  thr_len : st.thrInt.length = P.p
  thrInt_good : ∀ j < P.p, NoiseGood P rad NoiseKind.intThr (st.thrInt.getD j 0)
  thrOut_good : NoiseGood P rad NoiseKind.outThr st.thrOut
  potential : statePotential P u st + 25 / 128 * (P.tau : ℝ) ^ 2 * weightedT P st ≤ 1
  halted_rej : st.halted = true → st.rej = P.J + 1
  rej_le : st.halted = false → st.rej ≤ P.J
  not_capAborted : st.capAborted = false

/-! ## Outcomes of one call -/

/-- The internal root error budget `Δ_root = p(τ + 2h) + 1.5h` (`R:eq:sec3_internal_error_budget`). -/
def rootErr (P : AdaParams) : ℚ := P.p * (P.tau + 2 * (P.tau / 64)) + 3 / 2 * (P.tau / 64)

/-- The core's rounded clipped endpoint `h_A round_{h_A}(clip_{[-1,2]} x)` (L750). -/
def endQ (P : AdaParams) (x : ℚ) : ℚ := P.hA * (roundIdxQ P.hA (clipQ (-1) 2 x) : ℚ)

/-- A rejection certificate. -/
def AdaCert.isRej : AdaCert → Bool
  | AdaCert.high => true
  | AdaCert.low => true
  | AdaCert.termHigh => true
  | AdaCert.termLow => true
  | _ => false

/-- A terminal rejection certificate. -/
def AdaCert.isTerm : AdaCert → Bool
  | AdaCert.termHigh => true
  | AdaCert.termLow => true
  | _ => false

/-- Soundness of an interval certificate for a query with population value `c`, relative to the core's
rounded clipped endpoints (L1042: outer acceptance permits at most `3a/4` beyond either endpoint, a rejection
has signed excess at least `a/4`, the root error is `Δ_root`). -/
def CertSound (P : AdaParams) (c : ℝ) (l u : ℚ) : AdaCert → Prop
  | AdaCert.accept => ((endQ P l - 3 / 4 * P.a - rootErr P : ℚ) : ℝ) ≤ c ∧
      c ≤ ((endQ P u + 3 / 4 * P.a + rootErr P : ℚ) : ℝ)
  | AdaCert.high => ((endQ P u + P.a / 4 - rootErr P : ℚ) : ℝ) ≤ c
  | AdaCert.termHigh => ((endQ P u + P.a / 4 - rootErr P : ℚ) : ℝ) ≤ c
  | AdaCert.low => c ≤ ((endQ P l - P.a / 4 + rootErr P : ℚ) : ℝ)
  | AdaCert.termLow => c ≤ ((endQ P l - P.a / 4 + rootErr P : ℚ) : ℝ)
  | AdaCert.abort => True

/-- Soundness of a numerical answer for a query with population value `c` (L1044:
error `≤ Δ_root + a/4 + h_A/2`). -/
def NumSound (P : AdaParams) (c : ℝ) : AdaNum → Prop
  | AdaNum.val q => 0 ≤ q ∧ q ≤ 1 ∧ |(q : ℝ) - c| ≤ ((rootErr P + P.a / 4 + P.hA / 2 : ℚ) : ℝ)
  | AdaNum.abort => True

/-- Bookkeeping of an interval call: a refused request (halted, or cap `M` reached) returns `abort` with no
state change; a processed request never returns `abort` (no `CAP_ABORT`), increments `nInt`, increments
`rej` exactly on rejections, halts exactly on the terminal rejection, which is the rejection made when `J`
rejections have already been returned. -/
def IntervalBook (P : AdaParams) (st : AdaState) (r : AdaCert × AdaState) : Prop :=
  ((st.halted = true ∨ P.M ≤ st.nInt) → r = (AdaCert.abort, st)) ∧
  (¬(st.halted = true ∨ P.M ≤ st.nInt) →
    r.1 ≠ AdaCert.abort ∧ r.2.nInt = st.nInt + 1 ∧ r.2.nNum = st.nNum ∧
      r.2.rej = st.rej + (if r.1.isRej then 1 else 0) ∧ r.2.halted = r.1.isTerm ∧
      (r.1.isTerm = true ↔ (r.1.isRej = true ∧ P.J ≤ st.rej)))

/-- Bookkeeping of a numerical call: refused (halted, or cap `R` reached) ⇒ `abort`, no state change;
processed ⇒ a genuine answer, `nNum` incremented, the other counters and the halting flag unchanged. -/
def NumericalBook (P : AdaParams) (st : AdaState) (r : AdaNum × AdaState) : Prop :=
  ((st.halted = true ∨ P.R ≤ st.nNum) → r = (AdaNum.abort, st)) ∧
  (¬(st.halted = true ∨ P.R ≤ st.nNum) →
    r.1 ≠ AdaNum.abort ∧ r.2.nNum = st.nNum + 1 ∧ r.2.nInt = st.nInt ∧ r.2.rej = st.rej ∧
      r.2.halted = st.halted)

/-! ## Candidate rounds, comparator accuracy, margins -/

/-- Round `t` of the execution with outputs `o` is among the first `M` interval requests (resp. the first `R`
numerical requests): the requests the core may process. -/
def CoreCandidate {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (t : ℕ) : Prop :=
  if (coreReqAt ctrl o t).isInterval = true then
    ((Finset.range (t + 1)).filter fun i => (coreReqAt ctrl o i).isInterval = true).card ≤ P.M
  else ((Finset.range (t + 1)).filter fun i => (coreReqAt ctrl o i).isInterval = false).card ≤ P.R

/-- The population value `𝒟 f̂` of the grid-valued query `f̂ = h_A f` of a request. -/
noncomputable def reqMean {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (req : CoreReq U) : ℝ :=
  popMean D fun x => (P.hA : ℝ) * req.f x

/-- The comparators `u` are accurate (`R:eq:sec3_good_comparator_cond`) on every candidate query of the
execution with outputs `o` on the sample `s`. -/
def CompOK {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (u : (j : ℕ) → Fin (blockN P j) → ℝ) (o : List CoreOut) : Prop :=
  ∀ t < o.length, CoreCandidate P ctrl o t →
    CompCond P u (coreVals P s (coreReqAt ctrl o t)) (reqMean P D (coreReqAt ctrl o t))

/-- The accuracy margins at accuracy `α` (L1042–1046): acceptance `3a/4 + Δ_root + h_A/2 ≤ α`, numerical
`Δ_root + a/4 + h_A/2 ≤ α`, rejection excess `Δ_root + h_A/2 ≤ a/4`, and `3a/4 + Δ_root + h_A/2 < 1` (clipping
soundness). -/
structure AccMargins (P : AdaParams) (α : ℝ) : Prop where
  accept : ((3 / 4 * P.a + rootErr P + P.hA / 2 : ℚ) : ℝ) ≤ α
  num : ((rootErr P + P.a / 4 + P.hA / 2 : ℚ) : ℝ) ≤ α
  rej : rootErr P + P.hA / 2 ≤ P.a / 4
  small : 3 / 4 * P.a + rootErr P + P.hA / 2 < 1

end

end F2e2e.B
