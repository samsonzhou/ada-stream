import F2e2e.B.PrivacySens
import F2e2e.B.PrivacyNum
import F2e2e.B.PrivacyCount

/-!
# One-phase privacy (P2) of the stream oracles of Algorithm 2

Paper: `parts/partII.tex` L986–1002 (one-phase privacy: the injective noise shift), L1004–1008 (the
streams touching block `j` and their analytical replicas), L978–984 (phase counts).

For the block `j` the streams touching it are `streamsOf j`: the internal edges `j − 1` and `j`, and
for `j = 0` the edge `0`, the outer validator and the numerical releases (the gaps of edge `e` read
`μ_e, μ_{e+1}`; the outer validator and the numerical releases read `μ_0`). Each of them is
`PhaseDP` for single-record replacements in block `j` (`BlockAdj`) with the per-phase parameter
`dShift P j · h_A / b` of its noise scale `b` (`phaseDP_edge`, `phaseDP_outer`, `phaseDP_num`): the
replacement moves `μ_j` by at most `8/n_j ≤ h_A dShift P j` (`recMus_getD_sens`) and leaves the other
predictions unchanged (`recMus_getD_withBlock`). The other streams do not read block `j`
(`hinv_core`).

Remark (paper flag): the paper bounds the per-phase cost by `e^{2Δ'/b}`; the exact cost of a phase is
`e^{Δ'/b}` (threshold shift `Δ'` at scale `2b`, test shift `2Δ'` at scale `4b`). The KOV-based
composition (`F2e2e/B/PrivacyPhase.lean`) does not need the paper's restriction `ρ ≲ 1.25`.
-/

namespace F2e2e.B.Priv

open F2e2e.B F2e2e.Discrete

variable {U : Type} (P : AdaParams)

/-- Two contents of block `j` differing in at most one coordinate (single-record replacement). -/
def BlockAdj (j : ℕ) (y y' : Fin (blockN P j) → U) : Prop :=
  ∃ i₀ : Fin (blockN P j), ∀ i, i ≠ i₀ → y i = y' i

/-- The streams reading block `j`. -/
def streamsOf (j : ℕ) : Finset Strm :=
  if j = 0 then {Strm.edge 0, Strm.outer, Strm.num} else {Strm.edge (j - 1), Strm.edge j}

theorem streamsOf_card_le (j : ℕ) : (streamsOf j).card ≤ 3 := by
  unfold streamsOf
  split_ifs
  · exact Finset.card_le_three
  · exact Finset.card_le_two.trans (by norm_num)

theorem mem_streamsOf {j : ℕ} {s : Strm} (hs : s ∈ streamsOf j) :
    (∃ e, (e + 1 = j ∨ e = j) ∧ s = Strm.edge e) ∨ (j = 0 ∧ (s = Strm.outer ∨ s = Strm.num)) := by
  unfold streamsOf at hs
  split_ifs at hs with hj0
  · subst hj0
    simp only [Finset.mem_insert, Finset.mem_singleton] at hs
    rcases hs with rfl | rfl | rfl
    · exact Or.inl ⟨0, Or.inr rfl, rfl⟩
    · exact Or.inr ⟨rfl, Or.inl rfl⟩
    · exact Or.inr ⟨rfl, Or.inr rfl⟩
  · simp only [Finset.mem_insert, Finset.mem_singleton] at hs
    rcases hs with rfl | rfl
    · exact Or.inl ⟨j - 1, Or.inl (by omega), rfl⟩
    · exact Or.inl ⟨j, Or.inr rfl, rfl⟩

/-! ## Monotonicity of `PhaseDP` -/

theorem phaseDP_mono {I X Pp : Type} {L : Pp → PMF ℤ} {Adj : X → X → Prop}
    {sp : StreamSpec I X Pp} {ρ ρ' : ℝ} (h : sp.PhaseDP L Adj ρ) (hρ : ρ ≤ ρ') :
    sp.PhaseDP L Adj ρ' := by
  obtain ⟨hh, d, dR, cT, cQ, cR, h1, h2, h3, h4, h5, h6, h7⟩ := h
  have he : ENNReal.ofReal (Real.exp ρ) ≤ ENNReal.ofReal (Real.exp ρ') :=
    ENNReal.ofReal_le_ofReal (Real.exp_le_exp.2 hρ)
  exact ⟨hh, d, dR, cT, cQ, cR, h1, h2, h3, h4, h5, h6.trans he, h7.trans he⟩

/-! ## Lattice shift costs of the ideal laws -/

/-- Shifting a lattice noise of scale `b` by at most `d` lattice steps costs `e^{d h_A/b}`. -/
theorem idealLaw_shift {κ : NoiseKind} (hb : 0 < P.scale κ) (hh : 0 < P.hA) (d : ℕ) (t m : ℤ)
    (hm : m.natAbs ≤ d) :
    idealLaw P κ t ≤
      ENNReal.ofReal (Real.exp (d * (P.hA : ℝ) / (P.scale κ : ℝ))) * idealLaw P κ (t + m) := by
  have hbR : (0 : ℝ) < (P.scale κ : ℝ) := by exact_mod_cast hb
  have hhR : (0 : ℝ) < (P.hA : ℝ) := by exact_mod_cast hh
  have h0 := latticeRho_pos hbR hhR
  have h1 := latticeRho_lt_one hbR hhR
  unfold idealLaw
  refine (latticeLaw_le_shift h0 h1 t m).trans ?_
  have hle : (latticeRho (P.scale κ : ℝ) (P.hA : ℝ))⁻¹ ^ m.natAbs ≤
      Real.exp (d * (P.hA : ℝ) / (P.scale κ : ℝ)) := by
    refine (inv_latticeRho_pow_le_exp hbR hhR _).trans (Real.exp_le_exp.2 ?_)
    have hmd : (m.natAbs : ℝ) ≤ d := by exact_mod_cast hm
    have hq : 0 ≤ (P.hA : ℝ) / (P.scale κ : ℝ) := by positivity
    rw [mul_div_assoc, mul_div_assoc]
    exact mul_le_mul_of_nonneg_right hmd hq
  exact mul_le_mul_of_nonneg_right (ENNReal.ofReal_le_ofReal hle) zero_le

/-- A shift of at most `0` lattice steps is free. -/
theorem law_shift_zero (L : PMF ℤ) (t m : ℤ) (hm : m.natAbs ≤ 0) : L t ≤ 1 * L (t + m) := by
  have : m = 0 := by omega
  subst this
  simp

theorem one_le_ofReal_exp {ρ : ℝ} (hρ : 0 ≤ ρ) : (1 : ENNReal) ≤ ENNReal.ofReal (Real.exp ρ) :=
  ENNReal.one_le_ofReal.2 (Real.one_le_exp hρ)

/-- `cT cQ`: a threshold shift `d` at scale `2b` and a test shift `2d` at scale `4b` cost `e^{d h/b}`. -/
theorem ofReal_exp_mul_ofReal_exp (d : ℕ) {h b : ℝ} (hb : 0 < b) :
    ENNReal.ofReal (Real.exp (d * h / (2 * b))) * ENNReal.ofReal (Real.exp (((2 * d : ℕ) : ℝ) * h / (4 * b))) =
      ENNReal.ofReal (Real.exp (d * h / b)) := by
  rw [← ENNReal.ofReal_mul (Real.exp_pos _).le, ← Real.exp_add]
  congr 2
  push_cast
  field_simp
  ring

/-! ## Sensitivity facts -/

theorem le_hA_mul_dShift (hh : 0 < P.hA) (j : ℕ) : 8 / (blockN P j : ℚ) ≤ P.hA * dShift P j := by
  have h1 : (8 / (blockN P j : ℚ)) / P.hA ≤ dShift P j := Nat.le_ceil _
  rw [div_le_iff₀ hh] at h1
  linarith

theorem mu_sens_withBlock (D : Fin P.N → U) {j : ℕ} {y y' : Fin (blockN P j) → U}
    (hyy : BlockAdj P j y y') (i : CInfo U) :
    |(recMus P (withBlock P D j y) i).getD j 0 - (recMus P (withBlock P D j y') i).getD j 0| ≤
      8 / (blockN P j : ℚ) := by
  obtain ⟨i₀, hi₀⟩ := hyy
  exact recMus_getD_sens P (blockNeighbor_withBlock P D i₀ hi₀) i

theorem abs_gap_left {a b a' b' c : ℚ} (hab : a = a') (hb : |b - b'| ≤ c) :
    |(a - b) - (a' - b')| ≤ c ∧ |-(a - b) - -(a' - b')| ≤ c := by
  subst hab
  constructor
  · rw [show (a - b) - (a - b') = -(b - b') by ring, abs_neg]; exact hb
  · rw [show -(a - b) - -(a - b') = b - b' by ring]; exact hb

theorem abs_gap_right {a b a' b' c : ℚ} (hb : b = b') (ha : |a - a'| ≤ c) :
    |(a - b) - (a' - b')| ≤ c ∧ |-(a - b) - -(a' - b')| ≤ c := by
  subst hb
  constructor
  · rw [show (a - b) - (a' - b) = a - a' by ring]; exact ha
  · rw [show -(a - b) - -(a' - b) = -(a - a') by ring, abs_neg]; exact ha

theorem abs_gap_outer {a a' u l c : ℚ} (h : |a - a'| ≤ c) :
    |(a - u) - (a' - u)| ≤ c ∧ |(l - a) - (l - a')| ≤ c := by
  constructor
  · rw [show (a - u) - (a' - u) = a - a' by ring]; exact h
  · rw [show (l - a) - (l - a') = -(a - a') by ring, abs_neg]; exact h

/-- Rounding to the lattice moves by at most `m` steps when the argument moves by at most `h m`. -/
theorem roundIdxQ_sub_le {h a b : ℚ} (hh : 0 < h) {m : ℕ} (hab : |a - b| ≤ h * m) :
    |roundIdxQ h a - roundIdxQ h b| ≤ m := by
  unfold roundIdxQ
  have hab' := abs_le.1 hab
  have h1 : a / h + 1 / 2 ≤ (b / h + 1 / 2) + (m : ℚ) := by
    have : a / h - b / h ≤ m := by
      rw [← sub_div, div_le_iff₀ hh]; linarith
    linarith
  have h2 : b / h + 1 / 2 ≤ (a / h + 1 / 2) + (m : ℚ) := by
    have : b / h - a / h ≤ m := by
      rw [← sub_div, div_le_iff₀ hh]; linarith
    linarith
  have f1 := Int.floor_mono h1
  have f2 := Int.floor_mono h2
  rw [Int.floor_add_natCast] at f1 f2
  rw [abs_le]
  constructor <;> linarith

/-! ## One-phase privacy of the three kinds of streams -/

/-- **(P2) for an internal edge** `e ∈ {j − 1, j}` touching block `j`. -/
theorem phaseDP_edge (hh : 0 < P.hA) (hb : 0 < P.bInt) {j e : ℕ} (he : e + 1 = j ∨ e = j)
    (D : Fin P.N → U) :
    ((coreSpec P (Strm.edge e)).restrict (fun y => withBlock P D j y)).PhaseDP (idealLaw P)
      (BlockAdj P j) ((dShift P j : ℝ) * (P.hA : ℝ) / (P.bInt : ℝ)) := by
  have hbR : (0 : ℝ) < (P.bInt : ℝ) := by exact_mod_cast hb
  have hsT : ((P.scale NoiseKind.intThr : ℚ) : ℝ) = 2 * (P.bInt : ℝ) := by
    simp [AdaParams.scale]
  have hsQ : ((P.scale NoiseKind.intTest : ℚ) : ℝ) = 4 * (P.bInt : ℝ) := by
    simp [AdaParams.scale]
  refine ⟨hh, dShift P j, 0,
    ENNReal.ofReal (Real.exp ((dShift P j : ℝ) * (P.hA : ℝ) / ((P.scale NoiseKind.intThr : ℚ) : ℝ))),
    ENNReal.ofReal (Real.exp (((2 * dShift P j : ℕ) : ℝ) * (P.hA : ℝ) /
      ((P.scale NoiseKind.intTest : ℚ) : ℝ))), 1, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i y y' hyy
    have hsens := (mu_sens_withBlock P D hyy i).trans (le_hA_mul_dShift P hh j)
    show |(((recMus P (withBlock P D j y) i).getD (e + 1) 0 - (recMus P (withBlock P D j y) i).getD e 0,
        -((recMus P (withBlock P D j y) i).getD (e + 1) 0 - (recMus P (withBlock P D j y) i).getD e 0)) :
          ℚ × ℚ).1 -
        (((recMus P (withBlock P D j y') i).getD (e + 1) 0 - (recMus P (withBlock P D j y') i).getD e 0,
        -((recMus P (withBlock P D j y') i).getD (e + 1) 0 -
          (recMus P (withBlock P D j y') i).getD e 0)) : ℚ × ℚ).1| ≤ P.hA * (dShift P j : ℚ) ∧
      |(((recMus P (withBlock P D j y) i).getD (e + 1) 0 - (recMus P (withBlock P D j y) i).getD e 0,
        -((recMus P (withBlock P D j y) i).getD (e + 1) 0 - (recMus P (withBlock P D j y) i).getD e 0)) :
          ℚ × ℚ).2 -
        (((recMus P (withBlock P D j y') i).getD (e + 1) 0 - (recMus P (withBlock P D j y') i).getD e 0,
        -((recMus P (withBlock P D j y') i).getD (e + 1) 0 -
          (recMus P (withBlock P D j y') i).getD e 0)) : ℚ × ℚ).2| ≤ P.hA * (dShift P j : ℚ)
    simp only
    rcases he with he | he
    · subst he
      exact abs_gap_right (recMus_getD_withBlock P D (by omega) y y' i) hsens
    · subst he
      exact abs_gap_left (recMus_getD_withBlock P D (by omega) y y' i) hsens
  · intro i y y' _
    show |(0 : ℤ) - 0| ≤ ((0 : ℕ) : ℤ)
    simp
  · intro t m hm
    exact idealLaw_shift P (κ := NoiseKind.intThr) (by show (0 : ℚ) < 2 * P.bInt; positivity) hh
      _ t m hm
  · intro t m hm
    exact idealLaw_shift P (κ := NoiseKind.intTest) (by show (0 : ℚ) < 4 * P.bInt; positivity) hh
      _ t m hm
  · intro t m hm
    exact law_shift_zero _ t m hm
  · rw [hsT, hsQ, ofReal_exp_mul_ofReal_exp _ hbR]
  · exact one_le_ofReal_exp (by positivity)

/-- **(P2) for the outer validator** (block `0`). -/
theorem phaseDP_outer (hh : 0 < P.hA) (hb : 0 < P.bOut) (D : Fin P.N → U) :
    ((coreSpec P Strm.outer).restrict (fun y => withBlock P D 0 y)).PhaseDP (idealLaw P)
      (BlockAdj P 0) ((dShift P 0 : ℝ) * (P.hA : ℝ) / (P.bOut : ℝ)) := by
  have hbR : (0 : ℝ) < (P.bOut : ℝ) := by exact_mod_cast hb
  have hsT : ((P.scale NoiseKind.outThr : ℚ) : ℝ) = 2 * (P.bOut : ℝ) := by
    simp [AdaParams.scale]
  have hsQ : ((P.scale NoiseKind.outTest : ℚ) : ℝ) = 4 * (P.bOut : ℝ) := by
    simp [AdaParams.scale]
  refine ⟨hh, dShift P 0, 0,
    ENNReal.ofReal (Real.exp ((dShift P 0 : ℝ) * (P.hA : ℝ) / ((P.scale NoiseKind.outThr : ℚ) : ℝ))),
    ENNReal.ofReal (Real.exp (((2 * dShift P 0 : ℕ) : ℝ) * (P.hA : ℝ) /
      ((P.scale NoiseKind.outTest : ℚ) : ℝ))), 1, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i y y' hyy
    have hsens := (mu_sens_withBlock P D hyy i).trans (le_hA_mul_dShift P hh 0)
    exact abs_gap_outer hsens
  · intro i y y' _
    show |(0 : ℤ) - 0| ≤ ((0 : ℕ) : ℤ)
    simp
  · intro t m hm
    exact idealLaw_shift P (κ := NoiseKind.outThr) (by show (0 : ℚ) < 2 * P.bOut; positivity) hh
      _ t m hm
  · intro t m hm
    exact idealLaw_shift P (κ := NoiseKind.outTest) (by show (0 : ℚ) < 4 * P.bOut; positivity) hh
      _ t m hm
  · intro t m hm
    exact law_shift_zero _ t m hm
  · rw [hsT, hsQ, ofReal_exp_mul_ofReal_exp _ hbR]
  · exact one_le_ofReal_exp (by positivity)

/-- **(P2) for the numerical releases** (block `0`): the rounded center moves by at most
`dShift P 0` lattice steps. -/
theorem phaseDP_num (hh : 0 < P.hA) (hb : 0 < P.bNum) (D : Fin P.N → U) :
    ((coreSpec P Strm.num).restrict (fun y => withBlock P D 0 y)).PhaseDP (idealLaw P)
      (BlockAdj P 0) ((dShift P 0 : ℝ) * (P.hA : ℝ) / (P.bNum : ℝ)) := by
  have hbR : (0 : ℝ) < (P.bNum : ℝ) := by exact_mod_cast hb
  have hsR : ((P.scale NoiseKind.num : ℚ) : ℝ) = (P.bNum : ℝ) := by
    simp [AdaParams.scale]
  refine ⟨hh, 0, dShift P 0, 1, 1,
    ENNReal.ofReal (Real.exp ((dShift P 0 : ℝ) * (P.hA : ℝ) / ((P.scale NoiseKind.num : ℚ) : ℝ))),
    ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i y y' _
    show |(0 : ℚ) - 0| ≤ P.hA * ((0 : ℕ) : ℚ) ∧ |(0 : ℚ) - 0| ≤ P.hA * ((0 : ℕ) : ℚ)
    simp
  · intro i y y' hyy
    have hsens := (mu_sens_withBlock P D hyy i).trans (le_hA_mul_dShift P hh 0)
    exact roundIdxQ_sub_le hh hsens
  · intro t m hm
    exact law_shift_zero _ t m hm
  · intro t m hm
    exact law_shift_zero _ t m (by omega)
  · intro t m hm
    exact idealLaw_shift P (κ := NoiseKind.num) (by show (0 : ℚ) < P.bNum; exact hb) hh _ t m hm
  · rw [one_mul]
    exact one_le_ofReal_exp (by positivity)
  · rw [hsR]

/-! ## The other streams do not read block `j` -/

theorem hinv_core (j : ℕ) (D : Fin P.N → U) :
    ∀ s ∉ streamsOf j, ∀ (i : CInfo U) (y y' : Fin (blockN P j) → U),
      (coreSpec P s).gap i (withBlock P D j y) = (coreSpec P s).gap i (withBlock P D j y') ∧
        (coreSpec P s).center i (withBlock P D j y) = (coreSpec P s).center i (withBlock P D j y') := by
  intro s hs i y y'
  cases s with
  | edge e =>
    have hne : j ≠ e ∧ j ≠ e + 1 := by
      unfold streamsOf at hs
      split_ifs at hs with hj0
      · subst hj0
        simp only [Finset.mem_insert, Finset.mem_singleton, Strm.edge.injEq, reduceCtorEq,
          or_false] at hs
        exact ⟨fun h => hs (h ▸ rfl), by omega⟩
      · simp only [Finset.mem_insert, Finset.mem_singleton, Strm.edge.injEq, not_or] at hs
        exact ⟨fun h => hs.2 h.symm, by omega⟩
    simp only [coreSpec, recMus_getD_withBlock P D hne.1 y y' i,
      recMus_getD_withBlock P D hne.2 y y' i, and_self]
  | outer =>
    have hj0 : j ≠ 0 := by
      intro h
      apply hs
      simp [streamsOf, h]
    simp only [coreSpec, recMus_getD_withBlock P D hj0 y y' i, and_self]
  | num =>
    have hj0 : j ≠ 0 := by
      intro h
      apply hs
      simp [streamsOf, h]
    simp only [coreSpec, recMus_getD_withBlock P D hj0 y y' i, and_self]

/-! ## The instance -/

section Instance

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- Every stream touching block `j` is `ρ_j`-DP per phase. -/
theorem phaseDP_streamsOf (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p)
    (D : Fin (adaAlg2Params M J R aReq ξReq).N → U) :
    ∀ s ∈ streamsOf j, ((coreSpec (adaAlg2Params M J R aReq ξReq) s).restrict
      (fun y => withBlock (adaAlg2Params M J R aReq ξReq) D j y)).PhaseDP
      (idealLaw (adaAlg2Params M J R aReq ξReq)) (BlockAdj (adaAlg2Params M J R aReq ξReq) j)
      (privRho M J R aReq ξReq j) := by
  obtain ⟨hhA, hbI, hbO, hbN, -, -⟩ := priv_pos M J R ha0 ha1 hξ0 hξ1
  intro s hs
  rcases mem_streamsOf hs with ⟨e, he, rfl⟩ | ⟨rfl, rfl | rfl⟩
  · exact phaseDP_mono (phaseDP_edge _ hhA hbI he D) (priv_edge_cost M J R ha0 ha1 hξ0 hξ1 hj)
  · exact phaseDP_mono (phaseDP_outer _ hhA hbO D) (priv_outer_cost M J R ha0 ha1 hξ0 hξ1)
  · exact phaseDP_mono (phaseDP_num _ hhA hbN D) (priv_num_cost M J R ha0 ha1 hξ0 hξ1)

/-- Every stream touching block `j` has at most `C_j` phases. -/
theorem startsLE_streamsOf (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) (ctrl : CoreCtrl U)
    (T : ℕ) :
    ∀ s ∈ streamsOf j,
      (skRunD (adaAlg2Params M J R aReq ξReq) ctrl T).StartsLE s (adaC J R (dyadicExp aReq) j) := by
  intro s hs
  rcases mem_streamsOf hs with ⟨e, he, rfl⟩ | ⟨rfl, rfl | rfl⟩
  · exact (skRunD_startsLE_edge _ ctrl T e).mono (priv_edge_count M J R ha0 ha1 hξ0 hξ1 hj he)
  · exact (skRunD_startsLE_outer _ ctrl T).mono (priv_outer_count J R aReq)
  · exact (skRunD_startsLE_num _ ctrl T).mono (priv_num_count J R aReq)

end Instance

end F2e2e.B.Priv
