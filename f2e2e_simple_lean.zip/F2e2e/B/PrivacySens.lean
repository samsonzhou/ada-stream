import F2e2e.B.PrivacyLocal
import F2e2e.Lib.Opt.QuadraticSensitivity

/-!
# Replacement sensitivity of the replica predictions

Paper: `parts/partII.tex` L794–802 (Lemma `R:lem:sec3_kkt_sensitivity` (ii): for neighbouring blocks
`S_j, S'_j` and the same public queries/coefficients, `|μ_j(f; S_j) − μ_j(f; S'_j)| ≤ 8/n_j`; anchor
`≤ 1/n_p`), used by the one-phase privacy (P2), L986–990.

`recMus_getD_sens`: changing one record of block `j` of the sample moves the prediction `μ_j` of the
replica reconstruction (same protected-command history, same query) by at most `8/n_j`.
-/

namespace F2e2e.B.Priv

open F2e2e.B F2e2e.Discrete

variable {U : Type} (P : AdaParams)

/-! ## List helpers -/

theorem addScaled_getD_eq_ite (g : List ℤ) (c : ℤ) (v : List ℕ) (i : ℕ) :
    (addScaled g c v).getD i 0 = if i < g.length then g.getD i 0 + c * (v.getD i 0 : ℤ) else 0 := by
  unfold addScaled
  by_cases hi : i < g.length
  · rw [if_pos hi]
    simp [List.getD_eq_getElem?_getD, hi]
  · rw [if_neg hi]
    have hi' : g.length ≤ i := Nat.not_lt.mp hi
    simp [List.getD_eq_getElem?_getD, List.getElem?_mapIdx, List.getElem?_eq_none hi']

/-- Two score lists of length `n` that agree off the coordinate `i₀`. -/
def AgreeOff (n i₀ : ℕ) (g g' : List ℤ) : Prop :=
  g.length = n ∧ g'.length = n ∧ ∀ i, i ≠ i₀ → g.getD i 0 = g'.getD i 0

theorem agreeOff_addScaled {n i₀ : ℕ} {g g' : List ℤ} (h : AgreeOff n i₀ g g') (c : ℤ)
    {v v' : List ℕ} (hv : ∀ i, i ≠ i₀ → v.getD i 0 = v'.getD i 0) :
    AgreeOff n i₀ (addScaled g c v) (addScaled g' c v') := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨by rw [length_addScaled, h1], by rw [length_addScaled, h2], fun i hi => ?_⟩
  rw [addScaled_getD_eq_ite, addScaled_getD_eq_ite, h1, h2, h3 i hi, hv i hi]

theorem agreeOff_blockUpd {n i₀ : ℕ} {g g' : List ℤ} (h : AgreeOff n i₀ g g') (k j : ℕ) (q : Bool)
    {v v' : List ℕ} (hv : ∀ i, i ≠ i₀ → v.getD i 0 = v'.getD i 0) :
    AgreeOff n i₀ (blockUpd P k j q g v) (blockUpd P k j q g' v') := by
  unfold blockUpd
  split_ifs <;> first | exact h | exact agreeOff_addScaled h _ hv

theorem agreeOff_foldl {n i₀ k : ℕ} (s s' : Fin P.N → U)
    (hv : ∀ f : U → ℕ, ∀ i, i ≠ i₀ →
      (blockVals P (valsOf P s f) k).getD i 0 = (blockVals P (valsOf P s' f) k).getD i 0) :
    ∀ (hist : List (ℕ × Bool × (U → ℕ))) (g g' : List ℤ), AgreeOff n i₀ g g' →
      AgreeOff n i₀
        (hist.foldl (fun g c => blockUpd P k c.1 c.2.1 g (blockVals P (valsOf P s c.2.2) k)) g)
        (hist.foldl (fun g c => blockUpd P k c.1 c.2.1 g (blockVals P (valsOf P s' c.2.2) k)) g') := by
  intro hist
  induction hist with
  | nil => intro g g' h; exact h
  | cons c hist ih =>
    intro g g' h
    simp only [List.foldl_cons]
    exact ih _ _ (agreeOff_blockUpd P h _ _ _ (hv c.2.2))

theorem init_scores_getD {j : ℕ} (hj : j < P.p) :
    (adaInitState P [] 0).scores.getD j [] = List.replicate (blockN P j) 0 := by
  show ((P.blockSizes.take P.p).map fun nj => List.replicate nj (0 : ℤ)).getD j [] =
    List.replicate (P.blockSizes.getD j 0) 0
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_take_of_lt hj,
    List.getD_eq_getElem?_getD]
  cases P.blockSizes[j]? with
  | none => rfl
  | some nj => rfl

theorem blockVals_getD (s : Fin P.N → U) (f : U → ℕ) (k i : ℕ) :
    (blockVals P (valsOf P s f) k).getD i 0 =
      if h : i < blockN P k then min (f (sampleBlock P s k ⟨i, h⟩)) (2 ^ P.qA) else 0 := by
  rw [blockVals_valsOf, List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  split_ifs <;> rfl

/-! ## Predictions as sums -/

theorem predLearned_ofFn (hA : ℚ) (w : List ℚ) {n : ℕ} (hw : w.length = n) (V : Fin n → ℕ) :
    predLearned hA w (List.ofFn V) = hA * ∑ l : Fin n, w.getD l 0 * (V l : ℚ) := by
  unfold predLearned
  congr 1
  rw [← List.sum_ofFn]
  congr 1
  apply List.ext_getElem
  · simp [hw]
  · intro l h1 h2
    simp only [List.getElem_zipWith, List.getElem_ofFn]
    rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by simp at h1; omega)]
    rfl

theorem predAnchor_ofFn (hA : ℚ) {n : ℕ} (V : Fin n → ℕ) :
    predAnchor hA n (List.ofFn V) = hA * ((∑ l : Fin n, (V l : ℚ)) / n) := by
  unfold predAnchor
  have e0 : ((List.ofFn V).map fun x => (x : ℚ)) = (List.ofFn V).map (Nat.cast : ℕ → ℚ) := by
    simp [List.map_eq_flatMap]
  rw [e0, List.map_ofFn, List.sum_ofFn]
  rfl

theorem capWeightsQ_spec' (c : ℚ) (g : List ℤ) {n : ℕ} (hgn : g.length = n) (hg : g ≠ []) :
    (fun l : Fin n => (((capWeightsQ c g).getD l 0 : ℚ) : ℝ)) =
      F2e2e.Opt.Quad.learnerWeights n 8 (c : ℝ) (fun l : Fin n => ((g.getD l 0 : ℤ) : ℝ)) := by
  subst hgn
  rw [capWeightsQ_spec c g hg]
  congr 1
  funext l
  rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem l.isLt]
  rfl

/-! ## The two sensitivity cores -/

theorem predLearned_sens_aux {n : ℕ} (c hA : ℚ) (B : ℕ) (hA0 : 0 ≤ hA) (hAB : hA * B ≤ 1)
    {g g' : List ℤ} (hg : g.length = n) (hg' : g'.length = n) (i₀ : Fin n)
    (hgg : ∀ l : Fin n, l ≠ i₀ → g.getD l 0 = g'.getD l 0)
    (V V' : Fin n → ℕ) (hV : ∀ l, V l ≤ B) (hV' : ∀ l, V' l ≤ B)
    (hVV : ∀ l, l ≠ i₀ → V l = V' l) :
    |predLearned hA (capWeightsQ c g) (List.ofFn V) -
        predLearned hA (capWeightsQ c g') (List.ofFn V')| ≤ 8 / (n : ℚ) := by
  have hn : 0 < n := Nat.lt_of_le_of_lt (Nat.zero_le _) i₀.isLt
  have hgne : g ≠ [] := by
    rintro rfl
    simp at hg
    omega
  have hgne' : g' ≠ [] := by
    rintro rfl
    simp at hg'
    omega
  rw [predLearned_ofFn hA _ (by rw [capWeightsQ_length, hg]) V,
    predLearned_ofFn hA _ (by rw [capWeightsQ_length, hg']) V']
  have hW := capWeightsQ_spec' c g hg hgne
  have hW' := capWeightsQ_spec' c g' hg' hgne'
  have hA0' : (0 : ℝ) ≤ hA := by exact_mod_cast hA0
  have hAB' : (hA : ℝ) * (B : ℝ) ≤ 1 := by exact_mod_cast hAB
  have hxr : ∀ W : Fin n → ℕ, (∀ l, W l ≤ B) →
      ∀ l, 0 ≤ (hA : ℝ) * ((W l : ℕ) : ℝ) ∧ (hA : ℝ) * ((W l : ℕ) : ℝ) ≤ 1 := by
    intro W hW l
    have h1 : ((W l : ℕ) : ℝ) ≤ (B : ℝ) := by exact_mod_cast hW l
    refine ⟨by positivity, ?_⟩
    calc (hA : ℝ) * ((W l : ℕ) : ℝ) ≤ (hA : ℝ) * (B : ℝ) := mul_le_mul_of_nonneg_left h1 hA0'
      _ ≤ 1 := hAB'
  have hGG : ∀ l : Fin n, l ≠ i₀ →
      (fun l : Fin n => ((g.getD l 0 : ℤ) : ℝ)) l = (fun l : Fin n => ((g'.getD l 0 : ℤ) : ℝ)) l :=
    fun l hl => by simp only [hgg l hl]
  have hxx : ∀ l : Fin n, l ≠ i₀ →
      (fun l : Fin n => (hA : ℝ) * ((V l : ℕ) : ℝ)) l =
        (fun l : Fin n => (hA : ℝ) * ((V' l : ℕ) : ℝ)) l :=
    fun l hl => by simp only [hVV l hl]
  have key := F2e2e.Opt.Quad.learnerWeights_query_replace hn (C := 8) (by norm_num) (c : ℝ) i₀ hGG
    (hxr V hV) (hxr V' hV') hxx
  rw [← hW, ← hW'] at key
  have hcast : (((hA * ∑ l : Fin n, (capWeightsQ c g).getD l 0 * (V l : ℚ) -
      hA * ∑ l : Fin n, (capWeightsQ c g').getD l 0 * (V' l : ℚ) : ℚ)) : ℝ) =
      ∑ l : Fin n, (((capWeightsQ c g).getD l 0 : ℚ) : ℝ) * ((hA : ℝ) * ((V l : ℕ) : ℝ)) -
        ∑ l : Fin n, (((capWeightsQ c g').getD l 0 : ℚ) : ℝ) * ((hA : ℝ) * ((V' l : ℕ) : ℝ)) := by
    push_cast
    rw [Finset.mul_sum, Finset.mul_sum]
    congr 1 <;> refine Finset.sum_congr rfl fun l _ => ?_ <;> ring
  have key' : |(((hA * ∑ l : Fin n, (capWeightsQ c g).getD l 0 * (V l : ℚ) -
      hA * ∑ l : Fin n, (capWeightsQ c g').getD l 0 * (V' l : ℚ) : ℚ)) : ℝ)| ≤ 8 / (n : ℝ) := by
    rw [hcast]
    exact key
  have h8 : ((8 / (n : ℚ) : ℚ) : ℝ) = 8 / (n : ℝ) := by push_cast; ring
  rw [← h8, ← Rat.cast_abs] at key'
  exact Rat.cast_le.mp key'

theorem predAnchor_sens_aux {n : ℕ} (hA : ℚ) (B : ℕ) (hA0 : 0 ≤ hA) (hAB : hA * B ≤ 1)
    (i₀ : Fin n) (V V' : Fin n → ℕ) (hV : ∀ l, V l ≤ B) (hV' : ∀ l, V' l ≤ B)
    (hVV : ∀ l, l ≠ i₀ → V l = V' l) :
    |predAnchor hA n (List.ofFn V) - predAnchor hA n (List.ofFn V')| ≤ 8 / (n : ℚ) := by
  have hn : 0 < n := Nat.lt_of_le_of_lt (Nat.zero_le _) i₀.isLt
  have hnQ : (0 : ℚ) < n := by exact_mod_cast hn
  rw [predAnchor_ofFn, predAnchor_ofFn]
  have hsum : ∑ l : Fin n, (V l : ℚ) - ∑ l : Fin n, (V' l : ℚ) = (V i₀ : ℚ) - (V' i₀ : ℚ) := by
    rw [← Finset.sum_sub_distrib]
    rw [Finset.sum_eq_single i₀ (fun l _ hl => by rw [hVV l hl, sub_self])
      (fun h => absurd (Finset.mem_univ i₀) h)]
  have hdiff : |(V i₀ : ℚ) - (V' i₀ : ℚ)| ≤ B := by
    have h1 : (V i₀ : ℚ) ≤ B := by exact_mod_cast hV i₀
    have h2 : (V' i₀ : ℚ) ≤ B := by exact_mod_cast hV' i₀
    have h3 : (0 : ℚ) ≤ V i₀ := by positivity
    have h4 : (0 : ℚ) ≤ V' i₀ := by positivity
    rw [abs_le]
    constructor <;> linarith
  have heq : hA * ((∑ l : Fin n, (V l : ℚ)) / n) - hA * ((∑ l : Fin n, (V' l : ℚ)) / n) =
      hA * ((V i₀ : ℚ) - (V' i₀ : ℚ)) / n := by
    rw [← hsum]
    field_simp
  rw [heq, abs_div, abs_mul, abs_of_nonneg hA0, abs_of_pos hnQ]
  rw [div_le_div_iff_of_pos_right hnQ]
  calc hA * |(V i₀ : ℚ) - (V' i₀ : ℚ)| ≤ hA * B := mul_le_mul_of_nonneg_left hdiff hA0
    _ ≤ 1 := hAB
    _ ≤ 8 := by norm_num

/-! ## The bridge -/

theorem hA_mul_two_pow_le : P.hA * ((2 ^ P.qA : ℕ) : ℚ) ≤ 1 := by
  unfold AdaParams.hA
  push_cast
  rw [← mul_pow]
  norm_num

theorem hA_nonneg : 0 ≤ P.hA := by
  unfold AdaParams.hA
  positivity

/-- **Replacement sensitivity of the replica predictions** (Lemma `R:lem:sec3_kkt_sensitivity` (ii),
`partII.tex` L794–802): changing one record of block `j` moves `μ_j` by at most `8/n_j` (learned
blocks `j < p`: the block-`j` scores of `replay` agree off the replaced coordinate, `capWeightsQ_spec`
+ `learnerWeights_query_replace`; anchor `j = p`: `≤ 1/n_p`; `j > p`: `μ_j = 0`). -/
theorem recMus_getD_sens {s s' : Fin P.N → U} {j : ℕ} (h : BlockNeighbor P j s s') (i : CInfo U) :
    |(recMus P s i).getD j 0 - (recMus P s' i).getD j 0| ≤ 8 / (blockN P j : ℚ) := by
  obtain ⟨i₀, hoff⟩ := sampleBlock_offOne_of_blockNeighbor P h
  have hVV : ∀ l : Fin (blockN P j), l ≠ i₀ →
      min (i.f (sampleBlock P s j l)) (2 ^ P.qA) = min (i.f (sampleBlock P s' j l)) (2 ^ P.qA) :=
    fun l hl => by rw [hoff l hl]
  rw [recMus_getD, recMus_getD, blockVals_valsOf, blockVals_valsOf]
  by_cases hj : j < P.p
  · rw [if_pos hj, if_pos hj]
    have hv : ∀ f : U → ℕ, ∀ l, l ≠ (i₀ : ℕ) →
        (blockVals P (valsOf P s f) j).getD l 0 = (blockVals P (valsOf P s' f) j).getD l 0 := by
      intro f l hl
      rw [blockVals_getD, blockVals_getD]
      split_ifs with hlt
      · rw [hoff ⟨l, hlt⟩ (fun he => hl (congrArg Fin.val he))]
      · rfl
    have hag : AgreeOff (blockN P j) i₀ ((replay P s i.hist).scores.getD j [])
        ((replay P s' i.hist).scores.getD j []) := by
      rw [replay_scores_getD, replay_scores_getD]
      refine agreeOff_foldl P s s' hv i.hist _ _ ?_
      rw [init_scores_getD P hj]
      exact ⟨List.length_replicate, List.length_replicate, fun _ _ => rfl⟩
    exact predLearned_sens_aux (scoreScale P) P.hA (2 ^ P.qA) (hA_nonneg P) (hA_mul_two_pow_le P)
      hag.1 hag.2.1 i₀ (fun l hl => hag.2.2 l (fun he => hl (Fin.ext he))) _ _
      (fun l => min_le_right _ _) (fun l => min_le_right _ _) hVV
  · rw [if_neg hj, if_neg hj]
    by_cases hjp : j = P.p
    · rw [if_pos hjp, if_pos hjp]
      exact predAnchor_sens_aux P.hA (2 ^ P.qA) (hA_nonneg P) (hA_mul_two_pow_le P) i₀ _ _
        (fun l => min_le_right _ _) (fun l => min_le_right _ _) hVV
    · rw [if_neg hjp, if_neg hjp, sub_self, abs_zero]
      positivity


end F2e2e.B.Priv
