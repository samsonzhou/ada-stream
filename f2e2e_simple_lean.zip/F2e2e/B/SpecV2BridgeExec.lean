import F2e2e.B.SpecV2BridgeSim
import F2e2e.B.ArchBridge

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 4: the execution

The Spec's `alg2Exec` replays the views of rounds `0, …, t` from the initialization, all reading the
tape `List.ofFn ω`. Against the online core execution `coreRunS` of the induced core controller
(`specToCoreV2`, the same construction as `ArchBridge`'s `specToCore`):

* `step_sim`: one request (`alg2Request` ↔ `coreStepD` on the quantized request);
* `fold_sim`: the replay fold ↔ the online loop;
* `v2_online` (replay = online): the interaction of `alg2Exec`'s responses with a valid
  controller gives the `outRespV2` of the online core outputs, and the abort flag and correction counts
  of `alg2Exec` at round `t` are the `capAborted` flag and the counts `T_j` of the core state after
  `t + 1` online rounds.
-/

namespace F2e2e.B.V2

open F2e2e.Discrete F2e2e.B.Bridge

/-- The Spec's response of a core output. -/
def outRespV2 : CoreOut → F2e2e.VResponse
  | Sum.inl c => certRespV2 c
  | Sum.inr x => numRespV2 x

/-- A sample transported along `N = N'`. -/
def castSample {U : Type} {N N' : ℕ} (hN : N = N') (s2 : Fin N → U) : Fin N' → U :=
  fun ℓ => s2 (Fin.cast hN.symm ℓ)

/-- The core-level controller induced by a controller of the Spec (quantized requests). -/
noncomputable def specToCoreV2 {U : Type} (P : AdaParams) (ctrl : F2e2e.VController U) :
    CoreCtrl U :=
  fun hist =>
    quantReq P (ctrl hist.length (fun i => outRespV2 (hist.getD i.val (Sum.inl AdaCert.abort))))

/-- The Spec's view of the request issued after the core outputs `hist`. -/
def specViewV2 {U : Type} {N : ℕ} (ctrl : F2e2e.VController U) (s2 : Fin N → U)
    (hist : List CoreOut) : F2e2e.VView N :=
  ((fun ℓ => (ctrl hist.length (fun i => outRespV2 (hist.getD i.val (Sum.inl AdaCert.abort)))).1
      (s2 ℓ)),
    (ctrl hist.length (fun i => outRespV2 (hist.getD i.val (Sum.inl AdaCert.abort)))).2)

/-- The Spec's mechanism for a parameter record `P2` and `c` coins (`F2e2e.alg2Mech M J R a ξ c` is
`mech2 (F2e2e.alg2Params M J R a ξ) c` by definition). -/
noncomputable def mech2 (P2 : F2e2e.Alg2Params) (c : ℕ) : F2e2e.VMechanism P2.N c :=
  fun t views ω => (F2e2e.alg2Exec P2 t views ω).response

theorem roundGridQ_eq (P : AdaParams) {x : ℝ} (h0 : 0 ≤ x) (h1 : x ≤ 1) :
    ((F2e2e.roundGridQ P.hA x : ℚ) : ℝ) = (P.hA : ℝ) * (valIdx P x : ℝ) := by
  rw [valIdx_cast P h0 h1, roundLat_eq]
  unfold F2e2e.roundGridQ roundIdx
  push_cast
  rfl

theorem valsCorr_of {U : Type} {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    (hN : P2.N = P.N) (r : (U → ℝ) × Bool × ℝ × ℝ) (hr : ∀ x, 0 ≤ r.1 x ∧ r.1 x ≤ 1)
    (s2 : Fin P2.N → U) :
    ValsCorr P (F2e2e.alg2Evals P2 (fun ℓ => r.1 (s2 ℓ)))
      (coreVals P (castSample hN s2) (quantReq P r)) := by
  have hlen : P.blockSizes.sum ≤
      (List.ofFn fun ℓ => (quantReq P r).f (castSample hN s2 ℓ)).length := by
    rw [List.length_ofFn]; exact le_refl _
  refine ⟨fun j _ => length_splitBlocks_getD _ _ j hlen, fun j _ x hx => ?_, fun j hj i hi => ?_⟩
  · unfold coreVals at hx
    rw [splitBlocks_getD] at hx
    have hx' := List.mem_of_mem_drop (List.mem_of_mem_take hx)
    rw [List.mem_ofFn] at hx'
    obtain ⟨ℓ, rfl⟩ := hx'
    exact valIdx_le P _
  · have hm : (P.blockSizes.take j).sum + i < P.N := by
      have := sum_take_add_getD_le P.blockSizes j
      unfold AdaParams.N; omega
    have hm2 : (P.blockSizes.take j).sum + i < P2.N := by rw [hN]; exact hm
    unfold coreVals
    rw [splitBlocks_getD, List.getD_eq_getElem?_getD, List.getElem?_take_of_lt hi,
      List.getElem?_drop, List.getElem?_ofFn, dif_pos hm]
    simp only [Option.getD_some]
    unfold F2e2e.alg2Evals
    rw [dif_pos hm2, hP.hhA, roundGridQ_eq P (hr _).1 (hr _).2]
    rfl

/-- **One request.** -/
theorem step_sim {U : Type} {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    (hN : P2.N = P.N) {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st)
    (r : (U → ℝ) × Bool × ℝ × ℝ) (hr : ∀ x, 0 ≤ r.1 x ∧ r.1 x ≤ 1) (s2 : Fin P2.N → U)
    {τ : List Bool} {out : CoreOut} {st' : AdaState} {rest : List Bool}
    (h : ((coreStepD P (castSample hN s2) (quantReq P r) st).toBits (adaDraw P)).run τ =
      some ((out, st'), rest)) :
    ∃ st2', F2e2e.alg2Request P2 st2 ((fun ℓ => r.1 (s2 ℓ)), r.2) τ =
      (outRespV2 out, st2', rest) ∧ StCorr P st2' st' := by
  have hv := valsCorr_of hP hN r hr s2
  unfold coreStepD at h
  unfold F2e2e.alg2Request
  by_cases hI : r.2.1 = true
  · rw [if_pos (show (quantReq P r).isInterval = true from hI)] at h
    rw [if_pos (show (((fun ℓ => r.1 (s2 ℓ)), r.2) : F2e2e.VView P2.N).2.1 = true from hI)]
    obtain ⟨a, h1, h2⟩ := run_toBits_map_some h
    simp only [Prod.mk.injEq] at h2
    obtain ⟨rfl, rfl⟩ := h2
    obtain ⟨st2', h3, h4⟩ := interval_sim hP hst hv r.2.2.1 r.2.2.2 h1
    exact ⟨st2', h3, h4⟩
  · rw [if_neg (show ¬ (quantReq P r).isInterval = true from hI)] at h
    rw [if_neg (show ¬ (((fun ℓ => r.1 (s2 ℓ)), r.2) : F2e2e.VView P2.N).2.1 = true from hI)]
    obtain ⟨a, h1, h2⟩ := run_toBits_map_some h
    simp only [Prod.mk.injEq] at h2
    obtain ⟨rfl, rfl⟩ := h2
    obtain ⟨st2', h3, h4⟩ := numerical_sim hP hst hv h1
    exact ⟨st2', h3, h4⟩

/-- **The replay fold of the Spec is the online loop.** -/
theorem fold_sim {U : Type} {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    (hN : P2.N = P.N) (ctrl2 : F2e2e.VController U) (hvalid : ctrl2.Valid)
    (s2 : Fin P2.N → U) :
    ∀ (n : ℕ) (st2 : F2e2e.Alg2State) (st : AdaState) (hist : List CoreOut)
      (acc : F2e2e.VResponse) (τ : List Bool) (o : List CoreOut) (st' : AdaState)
      (rest : List Bool), StCorr P st2 st →
      ((coreLoopSD P (specToCoreV2 P ctrl2) (castSample hN s2) n st hist).toBits (adaDraw P)).run
          τ = some ((o, st'), rest) →
      ∃ (o' : List CoreOut) (st2' : F2e2e.Alg2State), o = hist ++ o' ∧ o'.length = n ∧
        StCorr P st2' st' ∧
        (List.ofFn fun j : Fin n => specViewV2 ctrl2 s2 (hist ++ o'.take j)).foldl
            (fun acc v => F2e2e.alg2Request P2 acc.2.1 v acc.2.2) (acc, st2, τ) =
          ((o'.map outRespV2).getLastD acc, st2', rest)
  | 0, st2, st, hist, acc, τ, o, st', rest, hst, h => by
    simp only [coreLoopSD, DrawProg.toBits_ret, BitProg.run_pure, Option.some.injEq,
      Prod.mk.injEq] at h
    obtain ⟨⟨rfl, rfl⟩, rfl⟩ := h
    exact ⟨[], st2, by simp, rfl, hst, rfl⟩
  | n + 1, st2, st, hist, acc, τ, o, st', rest, hst, h => by
    simp only [coreLoopSD] at h
    obtain ⟨⟨out, st1⟩, τ1, h1, h2⟩ := run_toBits_bind_some h
    have hr := hvalid hist.length (fun i => outRespV2 (hist.getD i.val (Sum.inl AdaCert.abort)))
    obtain ⟨st2a, h3, h4⟩ := step_sim hP hN hst _ hr.1 s2 h1
    obtain ⟨o'', st2', h5, h6, h7, h8⟩ := fold_sim hP hN ctrl2 hvalid s2 n st2a st1 (hist ++ [out])
      (outRespV2 out) τ1 o st' rest h4 h2
    refine ⟨out :: o'', st2', by rw [h5]; simp, by simp [h6], h7, ?_⟩
    rw [List.ofFn_succ, List.foldl_cons]
    simp only [Fin.val_zero, List.take_zero, List.append_nil, Fin.val_succ]
    have hviews : (List.ofFn fun i : Fin n =>
        specViewV2 ctrl2 s2 (hist ++ List.take (i + 1) (out :: o''))) =
        List.ofFn fun j : Fin n => specViewV2 ctrl2 s2 (hist ++ [out] ++ o''.take j) := by
      congr 1; funext j; simp
    rw [hviews]
    have hstep : F2e2e.alg2Request P2 (acc, st2, τ).2.1 (specViewV2 ctrl2 s2 hist)
        (acc, st2, τ).2.2 = (outRespV2 out, st2a, τ1) := h3
    rw [hstep, h8, List.map_cons, List.getLastD_cons]

theorem v2Responses_succ {U : Type} {N c : ℕ} (mech : F2e2e.VMechanism N c)
    (ctrl : F2e2e.VController U) (s : Fin N → U) (ω : Fin c → Bool) (t : ℕ) :
    F2e2e.vResponses mech ctrl s ω (t + 1) =
      Fin.snoc (F2e2e.vResponses mech ctrl s ω t)
        (mech t (F2e2e.vRoundViews mech ctrl s ω t) ω) := rfl

theorem v2ctrl_congr {U : Type} (ctrl : F2e2e.VController U) {n m : ℕ} (hnm : n = m)
    (f : Fin n → F2e2e.VResponse) (g : Fin m → F2e2e.VResponse)
    (hfg : ∀ i : Fin n, f i = g (Fin.cast hnm i)) : ctrl n f = ctrl m g := by
  subst hnm; congr 1; funext i; exact hfg i

/-- **Replay = online for the Spec's Algorithm 2.** For a valid controller and `c ≥ adaCoins P` coins,
the interaction with `mech2 P2 c` (= `F2e2e.alg2Mech`) on the coins `ω` gives the
`outRespV2` of the online core outputs of the induced controller on `List.ofFn ω`; and the abort flag
and correction counts reported by `alg2Exec` at round `t'` are the `capAborted` flag and the counts of
the core state after `t' + 1` online rounds. -/
theorem v2_online {U : Type} {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    (hN : P2.N = P.N) {c : ℕ} (hc : adaCoins P ≤ c) (ctrl2 : F2e2e.VController U)
    (hvalid : ctrl2.Valid) (s2 : Fin P2.N → U) (ω : Fin c → Bool) (t : ℕ) :
    ∃ (o : List CoreOut) (st : AdaState) (rest : List Bool),
      (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) t).run (List.ofFn ω) =
        some ((o, st), rest) ∧ o.length = t ∧
      (∀ i : Fin t, F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω t i =
        outRespV2 (o.getD i (Sum.inl AdaCert.abort))) ∧
      (∀ t', t = t' + 1 →
        (F2e2e.alg2Exec P2 t' (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t') ω).aborted =
          st.capAborted ∧
        ∀ j, (F2e2e.alg2Exec P2 t' (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t')
          ω).corrections j = st.T.getD j 0) := by
  set τ := List.ofFn ω with hτ
  have hlen : adaCoins P ≤ τ.length := by rw [hτ, List.length_ofFn]; exact hc
  have hsome : ∀ T, ((coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).run τ).isSome :=
    fun T => BitProg.run_isSome _ _ ((coreRunS_depth_le P _ _ T).trans hlen)
  have hsplit : ∀ T, (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).run τ =
      ((adaInitD P).toBits (adaDraw P) |>.run τ).bind fun r =>
        ((coreLoopSD P (specToCoreV2 P ctrl2) (castSample hN s2) T r.1 []).toBits
          (adaDraw P)).run r.2 := by
    intro T
    unfold coreRunS coreRunSD
    rw [DrawProg.toBits_bind, BitProg.run_bind]
  obtain ⟨⟨st0, τ0⟩, hinit⟩ : ∃ r, ((adaInitD P).toBits (adaDraw P)).run τ = some r := by
    have h0 := hsome 0
    rw [hsplit] at h0
    cases hr : ((adaInitD P).toBits (adaDraw P)).run τ with
    | none => rw [hr] at h0; simp at h0
    | some r => exact ⟨r, rfl⟩
  obtain ⟨hst0, hτ0⟩ := init_sim hP hinit
  have hloopSome : ∀ T, (((coreLoopSD P (specToCoreV2 P ctrl2) (castSample hN s2) T st0 []).toBits
      (adaDraw P)).run τ0).isSome := by
    intro T
    have := hsome T
    rwa [hsplit, hinit, Option.bind_some] at this
  have claim : ∀ t : ℕ, ∃ (o : List CoreOut) (st : AdaState) (rest : List Bool),
      ((coreLoopSD P (specToCoreV2 P ctrl2) (castSample hN s2) t st0 []).toBits (adaDraw P)).run
          τ0 = some ((o, st), rest) ∧ o.length = t ∧
      (∀ i : Fin t, F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω t i =
        outRespV2 (o.getD i (Sum.inl AdaCert.abort))) ∧
      (∀ t', t = t' + 1 →
        (F2e2e.alg2Exec P2 t' (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t') ω).aborted =
          st.capAborted ∧
        ∀ j, (F2e2e.alg2Exec P2 t' (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t')
          ω).corrections j = st.T.getD j 0) := by
    intro t
    induction t with
    | zero => exact ⟨[], st0, τ0, rfl, rfl, fun i => i.elim0, fun t' h => by omega⟩
    | succ t ih =>
      obtain ⟨o, st, rest, hrun, holen, hresp, -⟩ := ih
      have hS := hloopSome (t + 1)
      rw [coreLoopSD_succ', DrawProg.toBits_bind, BitProg.run_bind, hrun, Option.bind_some,
        DrawProg.toBits_map, BitProg.run_map] at hS
      obtain ⟨⟨⟨x, st'⟩, rest'⟩, hstep⟩ : ∃ r, ((coreStepD P (castSample hN s2)
          (specToCoreV2 P ctrl2 o) st).toBits (adaDraw P)).run rest = some r := by
        cases hr : ((coreStepD P (castSample hN s2) (specToCoreV2 P ctrl2 o) st).toBits
            (adaDraw P)).run rest with
        | none => rw [hr] at hS; simp at hS
        | some r => exact ⟨r, rfl⟩
      have hrun' : ((coreLoopSD P (specToCoreV2 P ctrl2) (castSample hN s2) (t + 1) st0 []).toBits
          (adaDraw P)).run τ0 = some ((o ++ [x], st'), rest') := by
        rw [coreLoopSD_succ', DrawProg.toBits_bind, BitProg.run_bind, hrun, Option.bind_some,
          DrawProg.toBits_map, BitProg.run_map, hstep]
        rfl
      -- the views of rounds `0..t`
      have hviews : F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t =
          fun j : Fin (t + 1) => specViewV2 ctrl2 s2 ([] ++ (o ++ [x]).take j) := by
        funext j
        have hj : j.val ≤ o.length := by rw [holen]; exact Nat.lt_succ_iff.mp j.isLt
        have htake : (o ++ [x]).take j.val = o.take j.val := List.take_append_of_le_length hj
        rw [List.nil_append, htake]
        have hc' : ctrl2 j.val (fun l : Fin j.val => F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω t
            (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) =
            ctrl2 (o.take j.val).length (fun i => outRespV2 ((o.take j.val).getD i.val
              (Sum.inl AdaCert.abort))) := by
          refine v2ctrl_congr ctrl2 (by simp [List.length_take, hj]) _ _ fun l => ?_
          rw [hresp]
          congr 1
          simp only [Fin.val_castLE, Fin.val_cast]
          rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD,
            List.getElem?_take_of_lt l.isLt]
        unfold F2e2e.vRoundViews specViewV2
        rw [hc']
      obtain ⟨o', st2', ho', ho'len, hst2', hfold⟩ := fold_sim hP hN ctrl2 hvalid s2 (t + 1)
        (F2e2e.alg2Init P2 τ).1 st0 [] F2e2e.VResponse.accept τ0 (o ++ [x]) st' rest' hst0
        hrun'
      rw [List.nil_append] at ho'
      subst ho'
      have hexec : F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t) ω =
          { response := ((o ++ [x]).map outRespV2).getLastD F2e2e.VResponse.accept,
            aborted := st2'.aborted, corrections := st2'.T } := by
        unfold F2e2e.alg2Exec
        rw [← hτ, hviews]
        dsimp only
        rw [hτ0, hfold]
      refine ⟨o ++ [x], st', rest', hrun', by simp [holen], fun i => ?_, fun t' ht' => ?_⟩
      · rw [v2Responses_succ]
        refine Fin.lastCases ?_ (fun i' => ?_) i
        · rw [Fin.snoc_last]
          show (F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 c) ctrl2 s2 ω t) ω).response =
            outRespV2 ((o ++ [x]).getD (Fin.last t).val (Sum.inl AdaCert.abort))
          rw [hexec]
          simp [holen]
        · rw [Fin.snoc_castSucc, hresp]
          congr 1
          simp only [Fin.val_castSucc]
          rw [List.getD_append _ _ _ _ (by rw [holen]; exact i'.isLt)]
      · have htt : t' = t := by omega
        subst htt
        rw [hexec]
        exact ⟨hst2'.aborted, hst2'.T⟩
  obtain ⟨o, st, rest, hrun, holen, hresp, hstate⟩ := claim t
  exact ⟨o, st, rest, by rw [hsplit, hinit, Option.bind_some, hrun], holen, hresp, hstate⟩

end F2e2e.B.V2
