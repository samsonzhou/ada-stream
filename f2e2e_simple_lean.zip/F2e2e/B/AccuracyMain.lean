import F2e2e.B.AccuracyComp
import F2e2e.B.AccuracyLoop

/-!
# Theorem `R:thm:validation_ada` (P5): assembly — the core-level guarantee

Paper: `parts/partII.tex` L1034–1046: the comparator event fails with probability `≤ ξ_A/8` (Transfer), the
noise-bounded event with probability `≤ ξ_A/100` (tails + sampler coupling), and on their intersection every
covered response is correct and no internal correction cap is exhausted; the total failure probability is
`≤ ξ_A/8 + ξ_A/100 ≤ ξ_A ≤ ξ_req`.

`accuracy_core_guarantee_detS_of_dp` proves B-ARCH's target `CoreGuaranteeDetS` (`F2e2e/B/ArchOnline.lean`:
covered failure at accuracy `a_req − h_A`, or `CAP_ABORT`/a reached correction cap in the final state) from
* `CoreBlockDP` (per-block DP of the online execution, (P2)–(P4), `F2e2e/B/Privacy*`), and
* the draw count of (P1): every online execution makes at most `Q` draws (`CoreDrawsLE`).

Proof: for each sample `s`, the failure set is contained in `{r | ¬ CompOK (comparators of (s, r.1))} ∪
{r | ¬ goodQ r}`, where `goodQ r` is the good-path conclusion of `coreRunSD_goodPaths`
(`∀ u admissible, CompOK u → ¬ coreFails ∧ ¬ internalFails`); the first set has total mass `≤ ξ_A/8`
(`comp_fail_le`, through `coreRun = coreRunS.map Prod.fst`), the second `≤ Q (2e^{−8χ} + ζ) ≤ ξ_A/100` for
every `s` (`DrawProg.toBits_bad_le`, `adaDraw_bad_le`, `noise_budget_alg2`).
-/

namespace F2e2e.B

open F2e2e.Discrete MeasureTheory

/-- The draw count of (P1) at the core level: every online execution of a valid controller makes at most `Q`
noise draws (`partII.tex` L984). -/
def CoreDrawsLE (M J R : ℕ) (aReq ξReq : ℝ) : Prop :=
  ∀ (U : Type) [Fintype U] (ctrl : CoreCtrl U), ctrl.Valid (adaAlg2Params M J R aReq ξReq) →
    ∀ (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) (T : ℕ),
      (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T).DrawsLE (accQ M J R aReq)

/-- A bound on the draws of a mapped program bounds the draws of the program. -/
theorem drawsLE_of_map {Pm β α γ : Type} {f : α → γ} :
    ∀ {prog : DrawProg Pm β α} {n : ℕ}, (prog.map f).DrawsLE n → prog.DrawsLE n
  | DrawProg.ret _, _, _ => trivial
  | DrawProg.draw _ _, 0, h => h
  | DrawProg.draw _ k, _ + 1, h => fun b => drawsLE_of_map (prog := k b) (h b)

/-- The sample weights `D^N(s)` sum to one. -/
theorem sum_ofReal_prod {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1)
    (N : ℕ) : ∑ s : Fin N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) = 1 := by
  classical
  rw [← ENNReal.ofReal_sum_of_nonneg fun s _ => Finset.prod_nonneg fun ℓ _ => hD0 _]
  rw [← Fintype.prod_sum (fun (_ : Fin N) (x : U) => D x)]
  simp [hD1]

/-- **Theorem `R:thm:validation_ada`, core level, with its internal-cap clause, from the privacy pillars**
(P5): per-block DP and the draw count give `CoreGuaranteeDetS` (accuracy `a_req − h_A`, failure `ξ_req`,
covered `CAP_ABORT` and internal cap exhaustion counted as failures). -/
theorem accuracy_core_guarantee_detS_of_dp (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq)
    (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (hdp : CoreBlockDP M J R aReq ξReq)
    (hdraws : CoreDrawsLE M J R aReq ξReq) : CoreGuaranteeDetS M J R aReq ξReq := by
  intro U _ D hD0 hD1 ctrl hctrl T
  have hP := accParamsOK_alg2 M J R ha0 ha1 hξ0 hξ1
  have hrad := radOK_alg2 M J R ha0 ha1 hξ0 hξ1
  have hα := accMargins_alg2 M J R ha0 ha1 hξ0 hξ1
  set P := adaAlg2Params M J R aReq ξReq with hPdef
  set ε : ENNReal := ENNReal.ofReal (2 * Real.exp (-(8 * (accChi M J R aReq ξReq : ℝ))) +
    (P.zeta : ℝ)) with hε
  -- per-sample decomposition of the failure event
  have hsplit : ∀ s : Fin P.N → U,
      (coreRunS P ctrl s T).law.toOuterMeasure
          {r | coreFails P D (aReq - (P.hA : ℝ)) ctrl r.1 ∨ internalFails P r.2} ≤
        (coreRun P ctrl s T).law.toOuterMeasure
          {o | ¬ CompOK P D ctrl s (fun j => blockComparator P D ctrl T aReq s j o) o} +
        (accQ M J R aReq : ENNReal) * ε := by
    intro s
    set A : Set (List CoreOut) :=
      {o | ¬ CompOK P D ctrl s (fun j => blockComparator P D ctrl T aReq s j o) o} with hA
    set B : Set (List CoreOut × AdaState) := {r | ¬ (∀ u, CompAdmissible P u →
      CompOK P D ctrl s u r.1 → ¬ coreFails P D (aReq - (P.hA : ℝ)) ctrl r.1 ∧
        ¬ internalFails P r.2)} with hB
    have hsub : {r : List CoreOut × AdaState |
        coreFails P D (aReq - (P.hA : ℝ)) ctrl r.1 ∨ internalFails P r.2} ⊆ Prod.fst ⁻¹' A ∪ B := by
      intro r hr
      by_contra hcon
      simp only [Set.mem_union, Set.mem_preimage, hA, hB, Set.mem_ofPred_eq, not_or, not_not] at hcon
      obtain ⟨hok, hgood⟩ := hcon
      have h := hgood _ (blockComparators_admissible M J R ha0 ha1 hξ0 hξ1 hdp D hD0 hD1 ctrl hctrl T
        s r.1) hok
      rcases hr with h' | h'
      · exact h.1 h'
      · exact h.2 h'
    have hAeq : (coreRunS P ctrl s T).law.toOuterMeasure (Prod.fst ⁻¹' A) =
        (coreRun P ctrl s T).law.toOuterMeasure A := by
      rw [coreRun_eq_map, BitProg.law_map, PMF.toOuterMeasure_map_apply]
    have hBle : (coreRunS P ctrl s T).law.toOuterMeasure B ≤ (accQ M J R aReq : ENNReal) * ε := by
      have hG := coreRunSD_goodPaths (rad := accRad P (accChi M J R aReq ξReq)) hP hrad D hD0 hD1 ctrl
        hctrl s T hα
      have hn : (coreRunSD P ctrl s T).DrawsLE (accQ M J R aReq) := by
        have h := hdraws U ctrl hctrl s T
        rw [coreRunD_eq_map] at h
        exact drawsLE_of_map h
      exact DrawProg.toBits_bad_le (adaDraw P)
        (fun κ => adaDraw_bad_le M J R ha0 ha1 hξ0 hξ1 κ) hG hn
    calc (coreRunS P ctrl s T).law.toOuterMeasure
          {r | coreFails P D (aReq - (P.hA : ℝ)) ctrl r.1 ∨ internalFails P r.2}
        ≤ (coreRunS P ctrl s T).law.toOuterMeasure (Prod.fst ⁻¹' A ∪ B) :=
          (coreRunS P ctrl s T).law.toOuterMeasure.mono hsub
      _ ≤ (coreRunS P ctrl s T).law.toOuterMeasure (Prod.fst ⁻¹' A) +
          (coreRunS P ctrl s T).law.toOuterMeasure B := measure_union_le _ _
      _ ≤ _ := by rw [hAeq]; exact add_le_add le_rfl hBle
  -- sum over samples
  have hcomp := comp_fail_le M J R ha0 ha1 hξ0 hξ1 hdp D hD0 hD1 ctrl hctrl T
  have hnoise := noise_budget_alg2 M J R ha0 ha1 hξ0 hξ1
  have hξA0 : 0 ≤ accXiA ξReq := by
    unfold accXiA
    rw [adaXiA_cast]
    exact (alg2XiA_pos ξReq).le
  have hξA1 : accXiA ξReq ≤ ξReq := by
    unfold accXiA
    rw [adaXiA_cast]
    exact dyadicDown_le hξ0
  calc ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRunS P ctrl s T).law.toOuterMeasure
          {r | coreFails P D (aReq - (P.hA : ℝ)) ctrl r.1 ∨ internalFails P r.2}
      ≤ ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          ((coreRun P ctrl s T).law.toOuterMeasure
            {o | ¬ CompOK P D ctrl s (fun j => blockComparator P D ctrl T aReq s j o) o} +
          (accQ M J R aReq : ENNReal) * ε) :=
        Finset.sum_le_sum fun s _ => mul_le_mul' le_rfl (hsplit s)
    _ = ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRun P ctrl s T).law.toOuterMeasure
            {o | ¬ CompOK P D ctrl s (fun j => blockComparator P D ctrl T aReq s j o) o} +
        (∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ))) * ((accQ M J R aReq : ENNReal) * ε) := by
        rw [Finset.sum_mul, ← Finset.sum_add_distrib]
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [mul_add]
    _ ≤ ENNReal.ofReal (accXiA ξReq / 8) + 1 * ENNReal.ofReal (accXiA ξReq / 100) := by
        rw [sum_ofReal_prod D hD0 hD1]
        exact add_le_add hcomp (mul_le_mul' le_rfl hnoise)
    _ = ENNReal.ofReal (accXiA ξReq / 8 + accXiA ξReq / 100) := by
        rw [one_mul, ENNReal.ofReal_add (by positivity) (by positivity)]
    _ ≤ ENNReal.ofReal ξReq := ENNReal.ofReal_le_ofReal (by linarith)

end F2e2e.B
