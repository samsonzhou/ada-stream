import F2e2e.B.PrivacyStream

/-!
# Privacy (P2): one phase of a stream is pure `ρ`-DP, with the environment interleaved

Paper: `parts/partII.tex` L986–1002 (one-phase privacy). For a fixed phase transcript, shift the
threshold noise up by `Δ' = h d` and leave the noises of accepted tests unchanged; at the terminal
test shift the crossing branch's noise up by `2Δ'`; for a `LOW` (negative) crossing the positive branch
stays below the shifted threshold, so the priority rule is preserved. Here the shift is applied inside a
whole **segment** of the run (from a phase start to the next one), in which the skeleton's own draws
(the other streams, the controller) are interleaved with the stream's tests: those draws have the same
laws on both data sets and factor out. A release segment costs the shift of one release noise by up to
`dR` lattice steps (`R:eq:sec3_lattice_dp_tail`).

* `runSeg_open_le`: within an open phase, `runSeg x E (some t) ≤ cQ · runSeg x' E (some (t + d))`
  pointwise (one crossing-noise shift `cQ` at most);
* `segLaw_le`: every segment law is pointwise within `max (cT cQ) (max cR 1)`;
* `stream_indist`: (P2) + (P3) per hybrid step, via the segmentation of `PrivacyStream` and
  `drawProg_advComp`. (The KOV route bounds the mean privacy loss by `ρ tanh(ρ/2) ≤ ρ²/2`, so the
  paper's `ρ(e^ρ − 1) ≤ 2ρ²`, which needs `ρ ≲ 1.25`, is not used: any `ρ ≥ 0` works.)
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete ENNReal

section TsumHelpers

/-- Splitting a sum along an `if`. -/
theorem tsum_ite_split (μ : PMF ℤ) (A : ℤ → Prop) [DecidablePred A] (U V : ℝ≥0∞) :
    ∑' n, μ n * (if A n then U else V) =
      ∑' n, μ n * (if A n then U else 0) + ∑' n, μ n * (if A n then 0 else V) := by
  rw [← ENNReal.tsum_add]
  refine tsum_congr fun n => ?_
  split_ifs <;> simp

/-- The crossing shift: if `A n ⇒ B (n + m)` and `μ n ≤ c μ (n + m)`, the mass of `A` is at most `c`
times the mass of `B`. -/
theorem tsum_shift_le (μ : PMF ℤ) {c : ℝ≥0∞} {m : ℤ} (hμ : ∀ n, μ n ≤ c * μ (n + m))
    (A B : ℤ → Prop) [DecidablePred A] [DecidablePred B] (hAB : ∀ n, A n → B (n + m)) (V : ℝ≥0∞) :
    ∑' n, μ n * (if A n then V else 0) ≤ c * ∑' n, μ n * (if B n then V else 0) := by
  calc ∑' n, μ n * (if A n then V else 0)
      ≤ ∑' n, c * (μ (n + m) * (if B (n + m) then V else 0)) := ENNReal.tsum_le_tsum fun n => by
        by_cases hA : A n
        · rw [if_pos hA, if_pos (hAB n hA), ← mul_assoc]
          gcongr
          exact hμ n
        · rw [if_neg hA, mul_zero]
          exact zero_le
    _ = c * ∑' n, μ (n + m) * (if B (n + m) then V else 0) := ENNReal.tsum_mul_left
    _ = c * ∑' n, μ n * (if B n then V else 0) := by
        congr 1
        exact (Equiv.addRight m).tsum_eq (fun n => μ n * (if B n then V else 0))

/-- Acceptance is monotone: if `¬A n ⇒ ¬B n` and `U ≤ V`, the accepted mass under `A` is at most that
under `B`. -/
theorem tsum_accept_le (μ : PMF ℤ) (A B : ℤ → Prop) [DecidablePred A] [DecidablePred B]
    (hAB : ∀ n, ¬A n → ¬B n) {U V : ℝ≥0∞} (hUV : U ≤ V) :
    ∑' n, μ n * (if A n then 0 else U) ≤ ∑' n, μ n * (if B n then 0 else V) :=
  ENNReal.tsum_le_tsum fun n => by
    by_cases hA : A n
    · rw [if_pos hA, mul_zero]; exact zero_le
    · rw [if_neg hA, if_neg (hAB n hA)]; gcongr

theorem tsum_ite_zero_mul (μ : PMF ℤ) (A : ℤ → Prop) [DecidablePred A] (c V : ℝ≥0∞) :
    ∑' n, μ n * (if A n then 0 else c * V) = c * ∑' n, μ n * (if A n then 0 else V) := by
  rw [← ENNReal.tsum_mul_left]
  refine tsum_congr fun n => ?_
  split_ifs <;> ring

theorem tsum_pmf_mul_const (μ : PMF ℤ) (V : ℝ≥0∞) : ∑' n, μ n * V = V := by
  rw [ENNReal.tsum_mul_right, μ.tsum_coe, one_mul]

end TsumHelpers

section Phase

variable {I X P α : Type} (L : P → PMF ℤ) (sp : StreamSpec I X P)

/-- The outcome of a test with threshold index `t` and test noise indices `np, nm`. -/
def testRes (x : X) (i : I) (t np nm : ℤ) : SResp × Option ℤ :=
  if sp.c + sp.h * t ≤ (sp.gap i x).1 + sp.h * np then (SResp.cross true, none)
  else if sp.c + sp.h * t ≤ (sp.gap i x).2 + sp.h * nm then (SResp.cross false, none)
  else (SResp.accept, some t)

theorem step_test (x : X) (t : ℤ) (i : I) :
    sp.step x (some t) (SQuery.test i) =
      .draw sp.pQ fun np => .draw sp.pQ fun nm => .ret (testRes sp x i t np nm) := rfl

theorem runSeg_test (x : X) (t : ℤ) (i : I) (k : SResp → Env1 I P α) (o : Node1 I P α ⊕ α) :
    runSeg L sp x (.call () (.test i) k) (some t) o =
      ∑' np, L sp.pQ np * ∑' nm, L sp.pQ nm *
        runSeg L sp x (k (testRes sp x i t np nm).1) (testRes sp x i t np nm).2 o := by
  simp only [runSeg, SQuery.isStart, Bool.false_eq_true, if_false, step_test,
    DrawProg.interp_draw, DrawProg.interp_ret, PMF.bind_bind, PMF.pure_bind, PMF.bind_apply]

/-- The three branches of a test. -/
theorem runSeg_testRes (x : X) (t : ℤ) (i : I) (k : SResp → Env1 I P α) (o : Node1 I P α ⊕ α)
    (np nm : ℤ) :
    runSeg L sp x (k (testRes sp x i t np nm).1) (testRes sp x i t np nm).2 o =
      if sp.c + sp.h * t ≤ (sp.gap i x).1 + sp.h * np then runSeg L sp x (k (SResp.cross true)) none o
      else if sp.c + sp.h * t ≤ (sp.gap i x).2 + sp.h * nm then
        runSeg L sp x (k (SResp.cross false)) none o
      else runSeg L sp x (k SResp.accept) (some t) o := by
  unfold testRes
  split_ifs <;> rfl

variable {x x' : X} {d dR : ℕ} {cT cQ cR : ℝ≥0∞}

/-- **Within an open phase** (threshold index `t` under `x`, `t + d` under `x'`): the run until the next
phase start is pointwise within the factor `cQ` (one crossing-noise shift by `2d`). -/
theorem runSeg_open_le
    (hg : ∀ i, |(sp.gap i x).1 - (sp.gap i x').1| ≤ sp.h * d ∧
      |(sp.gap i x).2 - (sp.gap i x').2| ≤ sp.h * d)
    (hQ : ∀ t m : ℤ, m.natAbs ≤ 2 * d → L sp.pQ t ≤ cQ * L sp.pQ (t + m)) (hcQ : 1 ≤ cQ) :
    ∀ (E : Env1 I P α) (t : ℤ) (o : Node1 I P α ⊕ α),
      runSeg L sp x E (some t) o ≤ cQ * runSeg L sp x' E (some (t + d)) o
  | .ret a, t, o => by
      simp only [runSeg]
      calc PMF.pure (Sum.inr a) o = 1 * PMF.pure (Sum.inr a) o := (one_mul _).symm
        _ ≤ cQ * PMF.pure (Sum.inr a) o := by gcongr
  | .draw p k, t, o => by
      simp only [runSeg, PMF.bind_apply]
      rw [← ENNReal.tsum_mul_left]
      refine ENNReal.tsum_le_tsum fun y => ?_
      rw [mul_left_comm]
      gcongr
      exact runSeg_open_le hg hQ hcQ (k y) t o
  | .call _ q k, t, o => by
      cases q with
      | reopen =>
        simp only [runSeg, SQuery.isStart, if_true]
        calc PMF.pure (Sum.inl (SQuery.reopen, k)) o
            = 1 * PMF.pure (Sum.inl (SQuery.reopen, k)) o := (one_mul _).symm
          _ ≤ cQ * PMF.pure (Sum.inl (SQuery.reopen, k)) o := by gcongr
      | release i =>
        simp only [runSeg, SQuery.isStart, if_true]
        calc PMF.pure (Sum.inl (SQuery.release i, k)) o
            = 1 * PMF.pure (Sum.inl (SQuery.release i, k)) o := (one_mul _).symm
          _ ≤ cQ * PMF.pure (Sum.inl (SQuery.release i, k)) o := by gcongr
      | test i =>
        rw [runSeg_test, runSeg_test]
        simp_rw [runSeg_testRes]
        set μ := L sp.pQ
        set Vp := runSeg L sp x (k (SResp.cross true)) none o with hVp
        set Vm := runSeg L sp x (k (SResp.cross false)) none o with hVm
        have hVp' : runSeg L sp x' (k (SResp.cross true)) none o = Vp := by
          rw [hVp, runSeg_closed L sp x x']
        have hVm' : runSeg L sp x' (k (SResp.cross false)) none o = Vm := by
          rw [hVm, runSeg_closed L sp x x']
        rw [hVp', hVm']
        set Va := runSeg L sp x (k SResp.accept) (some t) o
        set Va' := runSeg L sp x' (k SResp.accept) (some (t + d)) o
        have hVa : Va ≤ cQ * Va' := runSeg_open_le hg hQ hcQ (k SResp.accept) t o
        obtain ⟨hg1, hg2⟩ := hg i
        rw [abs_le] at hg1 hg2
        -- the inner sums
        have inner : ∀ (y : X) (s : ℤ) (Vacc : ℝ≥0∞) (np : ℤ),
            ∑' nm, μ nm * (if sp.c + sp.h * s ≤ (sp.gap i y).1 + sp.h * np then Vp
              else if sp.c + sp.h * s ≤ (sp.gap i y).2 + sp.h * nm then Vm else Vacc) =
            if sp.c + sp.h * s ≤ (sp.gap i y).1 + sp.h * np then Vp
            else ∑' nm, μ nm * (if sp.c + sp.h * s ≤ (sp.gap i y).2 + sp.h * nm then Vm
              else Vacc) := by
          intro y s Vacc np
          split_ifs
          · exact tsum_pmf_mul_const μ Vp
          · rfl
        simp_rw [inner]
        -- the inner (negative branch / accept) part
        set In := ∑' nm, μ nm * (if sp.c + sp.h * t ≤ (sp.gap i x).2 + sp.h * nm then Vm else Va)
        set In' := ∑' nm, μ nm *
          (if sp.c + sp.h * ((t + d : ℤ) : ℚ) ≤ (sp.gap i x').2 + sp.h * nm then Vm else Va')
        have hIn : In ≤ cQ * In' := by
          simp only [In, In']
          rw [tsum_ite_split μ _ Vm Va, tsum_ite_split μ _ Vm Va', mul_add]
          gcongr
          · exact tsum_shift_le μ (m := 2 * d) (fun n => hQ n _ (by omega)) _ _
              (fun n hn => by push_cast at hn ⊢; nlinarith) Vm
          · rw [← tsum_ite_zero_mul]
            refine tsum_accept_le μ _ _ (fun n hn => ?_) hVa
            push_cast at hn ⊢; rw [not_le] at hn ⊢; nlinarith
        rw [tsum_ite_split μ _ Vp In, tsum_ite_split μ _ Vp In', mul_add]
        gcongr
        · exact tsum_shift_le μ (m := 2 * d) (fun n => hQ n _ (by omega)) _ _
            (fun n hn => by push_cast at hn ⊢; nlinarith) Vp
        · rw [← tsum_ite_zero_mul]
          refine tsum_accept_le μ _ _ (fun n hn => ?_) hIn
          push_cast at hn ⊢; rw [not_le] at hn ⊢; nlinarith

theorem segLaw_reopen (x : X) (k : SResp → Env1 I P α) (o : Node1 I P α ⊕ α) :
    segLaw L sp x (SQuery.reopen, k) o =
      ∑' t, L sp.pT t * runSeg L sp x (k SResp.opened) (some t) o := by
  simp only [segLaw, StreamSpec.step, DrawProg.interp_draw, DrawProg.interp_ret, PMF.bind_bind,
    PMF.pure_bind, PMF.bind_apply]

theorem segLaw_release (x : X) (i : I) (k : SResp → Env1 I P α) (o : Node1 I P α ⊕ α) :
    segLaw L sp x (SQuery.release i, k) o =
      ∑' n, L sp.pR n * runSeg L sp x (k (SResp.value (sp.center i x + n))) none o := by
  simp only [segLaw, StreamSpec.step, DrawProg.interp_draw, DrawProg.interp_ret, PMF.bind_bind,
    PMF.pure_bind, PMF.bind_apply]

theorem segLaw_test (x : X) (i : I) (k : SResp → Env1 I P α) :
    segLaw L sp x (SQuery.test i, k) = runSeg L sp x (k SResp.closed) none := by
  simp only [segLaw, StreamSpec.step, DrawProg.interp_ret, PMF.pure_bind]

/-- **One phase is pure DP** (P2): every segment law is pointwise within `max (cT cQ) (max cR 1)` of the
segment law on the neighbouring data (reopen: threshold shift `cT` and one crossing shift `cQ`;
release: release-noise shift `cR`; a test of a closed stream: no data access). -/
theorem segLaw_le
    (hg : ∀ i, |(sp.gap i x).1 - (sp.gap i x').1| ≤ sp.h * d ∧
      |(sp.gap i x).2 - (sp.gap i x').2| ≤ sp.h * d)
    (hc : ∀ i, |sp.center i x - sp.center i x'| ≤ dR)
    (hT : ∀ t m : ℤ, m.natAbs ≤ d → L sp.pT t ≤ cT * L sp.pT (t + m))
    (hQ : ∀ t m : ℤ, m.natAbs ≤ 2 * d → L sp.pQ t ≤ cQ * L sp.pQ (t + m))
    (hR : ∀ t m : ℤ, m.natAbs ≤ dR → L sp.pR t ≤ cR * L sp.pR (t + m)) (hcQ : 1 ≤ cQ)
    (nd : Node1 I P α) (o : Node1 I P α ⊕ α) :
    segLaw L sp x nd o ≤ max (cT * cQ) (max cR 1) * segLaw L sp x' nd o := by
  obtain ⟨q, k⟩ := nd
  cases q with
  | reopen =>
    rw [segLaw_reopen, segLaw_reopen]
    calc ∑' t, L sp.pT t * runSeg L sp x (k SResp.opened) (some t) o
        ≤ ∑' t, (cT * L sp.pT (t + d)) *
            (cQ * runSeg L sp x' (k SResp.opened) (some (t + d)) o) :=
          ENNReal.tsum_le_tsum fun t => by
            gcongr
            · exact hT t d (by simp)
            · exact runSeg_open_le L sp hg hQ hcQ _ t o
      _ = cT * cQ * ∑' t, L sp.pT (t + d) * runSeg L sp x' (k SResp.opened) (some (t + d)) o := by
          rw [← ENNReal.tsum_mul_left]; exact tsum_congr fun t => by ring
      _ = cT * cQ * ∑' t, L sp.pT t * runSeg L sp x' (k SResp.opened) (some t) o := by
          congr 1
          exact (Equiv.addRight (d : ℤ)).tsum_eq
            (fun t => L sp.pT t * runSeg L sp x' (k SResp.opened) (some t) o)
      _ ≤ max (cT * cQ) (max cR 1) *
            ∑' t, L sp.pT t * runSeg L sp x' (k SResp.opened) (some t) o := by
          gcongr; exact le_max_left _ _
  | release i =>
    rw [segLaw_release, segLaw_release]
    set m := sp.center i x - sp.center i x' with hm
    have hmd : m.natAbs ≤ dR := by
      have h := hc i
      rw [← hm, Int.abs_eq_natAbs] at h
      exact_mod_cast h
    calc ∑' n, L sp.pR n * runSeg L sp x (k (SResp.value (sp.center i x + n))) none o
        ≤ ∑' n, (cR * L sp.pR (n + m)) *
            runSeg L sp x' (k (SResp.value (sp.center i x' + (n + m)))) none o :=
          ENNReal.tsum_le_tsum fun n => by
            rw [show sp.center i x' + (n + m) = sp.center i x + n by rw [hm]; ring,
              runSeg_closed L sp x' x]
            gcongr
            exact hR n m hmd
      _ = cR * ∑' n, L sp.pR (n + m) *
            runSeg L sp x' (k (SResp.value (sp.center i x' + (n + m)))) none o := by
          rw [← ENNReal.tsum_mul_left]; exact tsum_congr fun n => by ring
      _ = cR * ∑' n, L sp.pR n * runSeg L sp x' (k (SResp.value (sp.center i x' + n))) none o := by
          congr 1
          exact (Equiv.addRight m).tsum_eq
            (fun n => L sp.pR n * runSeg L sp x' (k (SResp.value (sp.center i x' + n))) none o)
      _ ≤ max (cT * cQ) (max cR 1) *
            ∑' n, L sp.pR n * runSeg L sp x' (k (SResp.value (sp.center i x' + n))) none o := by
          gcongr; exact le_max_of_le_right (le_max_left _ _)
  | test i =>
    rw [segLaw_test, segLaw_test, runSeg_closed L sp x x']
    calc runSeg L sp x' (k SResp.closed) none o = 1 * runSeg L sp x' (k SResp.closed) none o :=
          (one_mul _).symm
      _ ≤ max (cT * cQ) (max cR 1) * runSeg L sp x' (k SResp.closed) none o := by
          gcongr; exact le_max_of_le_right (le_max_right _ _)

end Phase

/-- A shift bound with shift `0` forces the factor to be at least `1`. -/
theorem one_le_of_self_le (μ : PMF ℤ) {c : ℝ≥0∞} (h : ∀ t, μ t ≤ c * μ t) : 1 ≤ c := by
  obtain ⟨t, ht⟩ := μ.support_nonempty
  have h0 : μ t ≠ 0 := (PMF.mem_support_iff μ t).1 ht
  exact (ENNReal.mul_le_mul_iff_left h0 (PMF.apply_ne_top μ t)).1 (by simpa using h t)

section StreamIndist

variable {I X P α : Type} (L : P → PMF ℤ) (sp : StreamSpec I X P)

/-- The ideal law of a single-stream skeleton is `run1`. -/
theorem interp_inlineAll_unit (x : X) :
    ∀ (E : Env1 I P α) (σ : Option ℤ),
      DrawProg.interp L (inlineAll (fun _ : Unit => sp) (fun _ => x) E (fun _ => σ)) = run1 L sp x E σ
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [inlineAll, DrawProg.interp_draw, run1]
      congr 1; funext y; exact interp_inlineAll_unit x (k y) σ
  | .call u q k, σ => by
      simp only [inlineAll, run1]
      rw [DrawProg.interp_bind]
      congr 1; funext r
      have hupd : Function.update (fun _ : Unit => σ) u r.2 = fun _ => r.2 :=
        funext fun v => by cases v; cases u; simp
      rw [hupd]
      exact interp_inlineAll_unit x (k r.1) r.2

/-- **One stream** ((P2) + (P3) per hybrid step, `partII.tex` L986–1019): if every phase of the stream
oracle `sp` satisfies the shift conditions `PhaseDP` with cost `ρ`, then for any skeleton `E` (the
controller, the other streams and all their randomness) with at most `C` phase starts of the stream on
every path, the ideal laws on `Adj`-related data are `(2Cρ² + ρ√(2Cχ), e^{-χ})`-indistinguishable. -/
theorem stream_indist {Adj : X → X → Prop} {ρ : ℝ} (hρ : 0 ≤ ρ) (hsp : sp.PhaseDP L Adj ρ)
    (E : OProg Unit P ℤ (SQuery I) SResp α) {C : ℕ} (hC : E.StartsLE () C) {x x' : X}
    (hxx : Adj x x') (χ : ℝ) :
    PIndist (DrawProg.interp L (inlineAll (fun _ => sp) (fun _ => x) E (fun _ => none)))
      (DrawProg.interp L (inlineAll (fun _ => sp) (fun _ => x') E (fun _ => none)))
      (2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ)) (Real.exp (-χ)) := by
  obtain ⟨_, d, dR, cT, cQ, cR, hgap, hcen, hT, hQ, hR, hTQ, hRρ⟩ := hsp
  have hcQ : 1 ≤ cQ := one_le_of_self_le (L sp.pQ) fun t => by simpa using hQ t 0 (by simp)
  have hg : ∀ i, |(sp.gap i x).1 - (sp.gap i x').1| ≤ sp.h * d ∧
      |(sp.gap i x).2 - (sp.gap i x').2| ≤ sp.h * d := fun i => hgap i x x' hxx
  have hg' : ∀ i, |(sp.gap i x').1 - (sp.gap i x).1| ≤ sp.h * d ∧
      |(sp.gap i x').2 - (sp.gap i x).2| ≤ sp.h * d := fun i => by
    rw [abs_sub_comm, abs_sub_comm (sp.gap i x').2]; exact hg i
  have hc : ∀ i, |sp.center i x - sp.center i x'| ≤ dR := fun i => hcen i x x' hxx
  have hc' : ∀ i, |sp.center i x' - sp.center i x| ≤ dR := fun i => by
    rw [abs_sub_comm]; exact hc i
  have hmax : max (cT * cQ) (max cR 1) ≤ ENNReal.ofReal (Real.exp ρ) :=
    max_le hTQ (max_le hRρ (ENNReal.one_le_ofReal.2 (Real.one_le_exp hρ)))
  have hr₁ : ∀ nd : Node1 I P α,
      RatioLE (segLaw L sp x nd) (segLaw L sp x' nd) (ENNReal.ofReal (Real.exp ρ)) :=
    fun nd o => (segLaw_le L sp hg hc hT hQ hR hcQ nd o).trans (by gcongr)
  have hr₂ : ∀ nd : Node1 I P α,
      RatioLE (segLaw L sp x' nd) (segLaw L sp x nd) (ENNReal.ofReal (Real.exp ρ)) :=
    fun nd o => (segLaw_le L sp hg' hc' hT hQ hR hcQ nd o).trans (by gcongr)
  rw [interp_inlineAll_unit L sp x E none, interp_inlineAll_unit L sp x' E none]
  apply PIndist.of_map_injective (Option.some_injective α)
  rw [run1_map_some L sp x E hC, run1_map_some L sp x' E hC, runSeg_closed L sp x x' E]
  apply PIndist.bind_right
  intro s
  cases s with
  | inl nd =>
    exact drawProg_advComp (segLaw L sp x) (segLaw L sp x') hρ hr₁ hr₂ (segDP_drawsLE C nd) χ
  | inr a => exact PIndist.refl _ (by positivity) _

end StreamIndist

end F2e2e.B.Priv
