import F2e2e.B.PrivacyRefineDefs

/-!
# Refinement helpers for `adaInitD_rel` and `adaNumericalD_rel`

Proved here against `F2e2e/B/PrivacyRefineDefs.lean` only (no dependency on the per-call lemmas of
`F2e2e/B/PrivacyRefine.lean`, which may import this file); the contract lemmas `adaInitD_rel`,
`adaNumericalD_rel`, `outerReject_rel`, `adaIntervalD_rel` follow by instantiation (the `_of_prep`
versions take the refinement of `PrepareRoot`, `prepareRoot_rel`, as a hypothesis).

* `DrawRel.map_left'`: mapping the output of the left program of a lockstep pair.
* `drawList_skRedraw_rel`: `drawList intThr n` (the core's initial thresholds) and the skeleton's
  reopening of the edges `a, a+1, …, a+n-1` (`skRedraw (List.range' a n)`) make the same draws; the
  `e`-th drawn index is the oracle state of edge `a + e`, the other oracle states are unchanged.
* `adaInitD_rel'`: the initialization (`adaInitD` vs `skInitD`).
* `hA_mul_roundIdxQ_add`: the rounding shift `h ⌊(μ + h k)/h + 1/2⌋ = h (⌊μ/h + 1/2⌋ + k)`
  (`partII.tex` L994–997; trivially true for `h = 0`).
* `adaNumericalD_rel_of_prep`: `Numerical` (lines [16]–[18]), given the `PrepareRoot` refinement.
* `outerReject_rel'`: an outer rejection (line [15]) (the statement of `outerReject_rel`).
* `adaIntervalD_rel_of_prep`: `Interval` (lines [11]–[15]), given the `PrepareRoot` refinement.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

/-- Mapping the output of the left program of a lockstep pair. -/
theorem DrawRel.map_left' {Pp β α α' γ : Type} {R : α → γ → Prop} {R' : α' → γ → Prop}
    {d : DrawProg Pp β α} {d' : DrawProg Pp β γ} (h : DrawRel R d d') (f : α → α')
    (hf : ∀ a c, R a c → R' (f a) c) : DrawRel R' (d.map f) d' := by
  induction h with
  | ret hac => exact DrawRel.ret (hf _ _ hac)
  | draw _ ih => exact DrawRel.draw fun y => ih y

/-- The rounding shift of the numerical release (`partII.tex` L994–997):
`h · round_idx(μ + h k) = h · (round_idx(μ) + k)` for `k ∈ ℤ` (for `h = 0` both sides vanish). -/
theorem hA_mul_roundIdxQ_add (h μ : ℚ) (k : ℤ) :
    h * (roundIdxQ h (μ + h * (k : ℚ)) : ℚ) = h * ((roundIdxQ h μ + k : ℤ) : ℚ) := by
  rcases eq_or_ne h 0 with rfl | hh
  · simp
  · congr 2
    unfold roundIdxQ
    have e : (μ + h * (k : ℚ)) / h + 1 / 2 = (μ / h + 1 / 2) + (k : ℚ) := by
      rw [add_div, mul_div_cancel_left₀ _ hh]; ring
    rw [e, Int.floor_add_intCast]

variable {U : Type} (P : AdaParams) (s : Fin P.N → U)

/-- The core's initial internal thresholds (`drawList intThr n`) and the skeleton's reopening of the
edges `a, …, a + n - 1` make the same draws; afterwards the oracle state of edge `a + e` is the `e`-th
drawn index, and every other oracle state is unchanged. -/
theorem drawList_skRedraw_rel (n : ℕ) : ∀ (a : ℕ) (σ : Strm → Option ℤ),
    DrawRel (fun (thr : List ℤ) (o : Unit × (Strm → Option ℤ)) =>
        thr.length = n ∧ (∀ e < n, o.2 (Strm.edge (a + e)) = some (thr.getD e 0)) ∧
        (∀ x, (∀ e < n, x ≠ Strm.edge (a + e)) → o.2 x = σ x))
      (drawList NoiseKind.intThr n)
      (inlineSt (coreSpec P) (fun _ => s) (skRedraw (U := U) (List.range' a n)) σ) := by
  induction n with
  | zero =>
    intro a σ
    simp only [drawList, List.range'_zero, skRedraw, inlineSt]
    exact DrawRel.ret ⟨rfl, fun e he => absurd he (Nat.not_lt_zero e), fun x _ => rfl⟩
  | succ n ih =>
    intro a σ
    simp only [drawList, List.range'_succ, skRedraw, inlineSt, drawNoise, StreamSpec.step, coreSpec,
      DrawProg.bind_draw, DrawProg.bind_ret]
    refine DrawRel.draw fun t => ?_
    refine (ih (a + 1) (Function.update σ (Strm.edge a) (some t))).map_left' (t :: ·) ?_
    rintro thr o ⟨hlen, hin, hout⟩
    refine ⟨by simp [hlen], fun e he => ?_, fun x hx => ?_⟩
    · cases e with
      | zero =>
        have hne : ∀ e' < n, Strm.edge a ≠ Strm.edge (a + 1 + e') := fun e' _ hh => by
          injection hh with hh; omega
        rw [Nat.add_zero, hout _ hne, Function.update_self]
        rfl
      | succ e =>
        have h1 := hin e (by omega)
        rw [show a + (e + 1) = a + 1 + e by omega, h1]
        rfl
    · have hx' : ∀ e' < n, x ≠ Strm.edge (a + 1 + e') := fun e' he' => by
        have h2 := hx (e' + 1) (by omega)
        rwa [show a + (e' + 1) = a + 1 + e' by omega] at h2
      have hx0 : x ≠ Strm.edge a := by simpa using hx 0 (by omega)
      rw [hout x hx', Function.update_of_ne hx0]

/-- The initialization: `adaInitD` and `skInitD` make the same draws (the `p` internal thresholds,
then the outer threshold) and end in related states (`Rel`). -/
theorem adaInitD_rel' :
    DrawRel (fun st o => Rel P s st o.1 o.2) (adaInitD P)
      (inlineSt (coreSpec P) (fun _ => s) (skInitD (U := U) P) (fun _ => none)) := by
  rw [adaInitD, skInitD, inlineSt_bind, List.range_eq_range']
  refine (drawList_skRedraw_rel P s P.p 0 (fun _ => none)).bind ?_
  rintro thr ⟨u, σ'⟩ ⟨hlen, hin, -⟩
  simp only [inlineSt, drawNoise, StreamSpec.step, coreSpec, DrawProg.bind_draw,
    DrawProg.bind_ret]
  refine DrawRel.draw fun ko => DrawRel.ret ?_
  refine ⟨⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩, fun _ => ⟨hlen, fun e he => ?_, ?_⟩⟩
  · show Function.update σ' Strm.outer (some ko) (Strm.edge e) = some (thr.getD e 0)
    rw [Function.update_of_ne (by simp)]
    have h1 := hin e he
    rw [Nat.zero_add] at h1
    exact h1
  · show Function.update σ' Strm.outer (some ko) Strm.outer = some ko
    rw [Function.update_self]

/-- `Numerical(f)` (lines [16]–[18]): the core and the skeleton make the same draws and return equal
responses with related states, given the refinement of `PrepareRoot`. -/
theorem adaNumericalD_rel_of_prep (f : U → ℕ)
    (hprep : ∀ (fuel : ℕ) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ)
      (cache : List Bool), Rel0 P s st sk → RelT P st σ →
      DrawRel (PrepR P s) (prepareRoot P (valsOf P s f) fuel st cache)
        (inlineSt (coreSpec P) (fun _ => s) (skPrepareRoot P f fuel sk cache) σ))
    (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (h : Rel P s st sk σ) :
    DrawRel (CallR P s) (adaNumericalD P st (valsOf P s f))
      (inlineSt (coreSpec P) (fun _ => s) (skNumericalD P sk f) σ) := by
  obtain ⟨h0, hT⟩ := h
  obtain ⟨hTT, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
  unfold adaNumericalD skNumericalD
  by_cases hc : st.halted = true ∨ P.R ≤ st.nNum
  · have hc' : sk.halted = true ∨ P.R ≤ sk.nNum := by rw [← hhalt, ← hnNum]; exact hc
    rw [if_pos hc, if_pos hc']
    exact DrawRel.ret ⟨rfl, ⟨hTT, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩, hT⟩
  · have hc' : ¬(sk.halted = true ∨ P.R ≤ sk.nNum) := by rw [← hhalt, ← hnNum]; exact hc
    rw [if_neg hc, if_neg hc', inlineSt_bind]
    have hhf : st.halted = false := by
      cases hh : st.halted
      · rfl
      · exact absurd (Or.inl hh) hc
    refine (hprep P.fuel { st with nNum := st.nNum + 1 } { sk with nNum := sk.nNum + 1 } σ
      (List.replicate P.p false)
      ⟨hTT, hrej, hnInt, congrArg (· + 1) hnNum, hhalt, hcap, hsc, hw⟩ (hT hhf)).bind ?_
    rintro r ⟨o1, σ'⟩ hPR
    rcases hPR with ⟨hr, ho⟩ | ⟨st2, sk2, hr, ho, h02, hT2⟩
    · subst hr
      simp only at ho
      subst ho
      simp only [inlineSt]
      exact DrawRel.ret ⟨rfl, ⟨hTT, hrej, hnInt, congrArg (· + 1) hnNum, rfl, rfl, hsc, hw⟩,
        fun hh => by simp at hh⟩
    · subst hr
      simp only at ho
      subst ho
      simp only [inlineSt, drawNoise, StreamSpec.step, coreSpec, DrawProg.bind_draw,
        DrawProg.bind_ret]
      refine DrawRel.draw fun k => DrawRel.ret ⟨?_, h02, fun _ => ?_⟩
      · show AdaNum.val _ = AdaNum.val _
        rw [recMus_eq P s h02 f 0 0, hA_mul_roundIdxQ_add]
      · obtain ⟨hl, he, ho'⟩ := hT2
        refine ⟨hl, fun e he' => ?_, ?_⟩
        · show Function.update σ' Strm.num none (Strm.edge e) = some (st2.thrInt.getD e 0)
          rw [Function.update_of_ne (by simp)]
          exact he e he'
        · show Function.update σ' Strm.num none Strm.outer = some st2.thrOut
          rw [Function.update_of_ne (by simp)]
          exact ho'

/-- An outer rejection (line [15]): same draws, equal certificates, related states. -/
theorem outerReject_rel' (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (high : Bool)
    (h0 : Rel0 P s st sk) (hlen : st.thrInt.length = P.p)
    (hedge : ∀ e < P.p, σ (Strm.edge e) = some (st.thrInt.getD e 0)) :
    DrawRel (CallR P s) (outerReject P st high)
      (inlineSt (coreSpec P) (fun _ => s) (skOuterReject P sk high) σ) := by
  obtain ⟨hTT, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
  unfold outerReject skOuterReject
  by_cases hc : P.J + 1 ≤ st.rej + 1
  · have hc' : P.J + 1 ≤ sk.rej + 1 := by rw [← hrej]; exact hc
    rw [if_pos hc, if_pos hc']
    simp only [inlineSt]
    exact DrawRel.ret ⟨rfl, ⟨hTT, congrArg (· + 1) hrej, hnInt, hnNum, rfl, hcap, hsc, hw⟩,
      fun hh => by simp at hh⟩
  · have hc' : ¬(P.J + 1 ≤ sk.rej + 1) := by rw [← hrej]; exact hc
    rw [if_neg hc, if_neg hc']
    simp only [inlineSt, drawNoise, StreamSpec.step, coreSpec, DrawProg.bind_draw,
      DrawProg.bind_ret]
    refine DrawRel.draw fun k => DrawRel.ret
      ⟨rfl, ⟨hTT, congrArg (· + 1) hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩,
        fun _ => ⟨hlen, fun e he => ?_, ?_⟩⟩
    · show Function.update σ Strm.outer (some k) (Strm.edge e) = some (st.thrInt.getD e 0)
      rw [Function.update_of_ne (by simp)]
      exact hedge e he
    · show Function.update σ Strm.outer (some k) Strm.outer = some k
      rw [Function.update_self]

/-- `Interval(f, [l, u])` (lines [11]–[15]): same draws, equal certificates, related states, given
the refinement of `PrepareRoot`. -/
theorem adaIntervalD_rel_of_prep (f : U → ℕ)
    (hprep : ∀ (fuel : ℕ) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ)
      (cache : List Bool), Rel0 P s st sk → RelT P st σ →
      DrawRel (PrepR P s) (prepareRoot P (valsOf P s f) fuel st cache)
        (inlineSt (coreSpec P) (fun _ => s) (skPrepareRoot P f fuel sk cache) σ))
    (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (l u : ℚ) (h : Rel P s st sk σ) :
    DrawRel (CallR P s) (adaIntervalD P st (valsOf P s f) l u)
      (inlineSt (coreSpec P) (fun _ => s) (skIntervalD P sk f l u) σ) := by
  obtain ⟨h0, hT⟩ := h
  obtain ⟨hTT, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩ := h0
  unfold adaIntervalD skIntervalD
  by_cases hc : st.halted = true ∨ P.M ≤ st.nInt
  · have hc' : sk.halted = true ∨ P.M ≤ sk.nInt := by rw [← hhalt, ← hnInt]; exact hc
    rw [if_pos hc, if_pos hc']
    exact DrawRel.ret ⟨rfl, ⟨hTT, hrej, hnInt, hnNum, hhalt, hcap, hsc, hw⟩, hT⟩
  · have hc' : ¬(sk.halted = true ∨ P.M ≤ sk.nInt) := by rw [← hhalt, ← hnInt]; exact hc
    rw [if_neg hc, if_neg hc', inlineSt_bind]
    have hhf : st.halted = false := by
      cases hh : st.halted
      · rfl
      · exact absurd (Or.inl hh) hc
    refine (hprep P.fuel { st with nInt := st.nInt + 1 } { sk with nInt := sk.nInt + 1 } σ
      (List.replicate P.p false)
      ⟨hTT, hrej, congrArg (· + 1) hnInt, hnNum, hhalt, hcap, hsc, hw⟩ (hT hhf)).bind ?_
    rintro r ⟨o1, σ'⟩ hPR
    rcases hPR with ⟨hr, ho⟩ | ⟨st2, sk2, hr, ho, h02, hT2⟩
    · subst hr
      simp only at ho
      subst ho
      simp only [inlineSt]
      exact DrawRel.ret ⟨rfl, ⟨hTT, hrej, congrArg (· + 1) hnInt, hnNum, rfl, rfl, hsc, hw⟩,
        fun hh => by simp at hh⟩
    · subst hr
      simp only at ho
      subst ho
      obtain ⟨hl, he, ho'⟩ := hT2
      have hout : σ' Strm.outer = some st2.thrOut := ho'
      have hedge : ∀ e < P.p, σ' (Strm.edge e) = some (st2.thrInt.getD e 0) := he
      simp only [inlineSt, hout, drawNoise, StreamSpec.step, coreSpec, DrawProg.bind_draw,
        DrawProg.bind_ret]
      simp only [recMus_eq P s h02 f]
      refine DrawRel.draw fun kH => DrawRel.draw fun kL => ?_
      have hedge' : ∀ (v : Option ℤ), ∀ e < P.p,
          Function.update σ' Strm.outer v (Strm.edge e) = some (st2.thrInt.getD e 0) :=
        fun v e he' => by rw [Function.update_of_ne (by simp)]; exact hedge e he'
      split_ifs with h1 h2
      · exact outerReject_rel' P s st2 sk2 _ true h02 hl (hedge' none)
      · exact outerReject_rel' P s st2 sk2 _ false h02 hl (hedge' none)
      · refine DrawRel.ret ⟨rfl, h02, fun _ => ⟨hl, hedge' (some st2.thrOut), ?_⟩⟩
        show Function.update σ' Strm.outer (some st2.thrOut) Strm.outer = some st2.thrOut
        rw [Function.update_self]

end F2e2e.B.Priv
