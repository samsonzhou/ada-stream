import F2e2e.B.NumericsAsymp
import F2e2e.B.Params

/-!
# Part II numerics (B-NUM), part 4: the sample size `N = ∑_j n_j` of Algorithm 2

Theorem `R:thm:validation_ada` (`parts/partII.tex` L958–961 and proof "Samples and memory" L1048–1052):
`N ≤ 2^64[(p^{7/2}/a² + p^{3/2}√K/a)χ^{3/2} + p³χ/a²]` (eq. `R:eq:sec3_N_explicit`, `K = J+R+1`),
"the constant `2^64` dominates the ceilings and the bounds 190, 31, 10 above", and the `O`-form
(eq. `R:eq:sec3_total_N_validation`). The parameters are B-ARCH's `alg2*` (`F2e2e/B/Params.lean`).

Per-block bounds (with `P = p`, `X = χ`, `v_j = 4^{-j}τ^{-2}`, `1/τ = 8p/a`, `1/h = 512p/a`):
* `d_j ≤ 2·2^j√p` (`j < p`), `d_p ≤ 5/h`;
* `C_0 ≤ 10τ^{-2} + K`, `C_j ≤ 157.5 v_j + 8 < 190 v_j` (`1 ≤ j < p`), `C_p ≤ 31`
  (Theorem `R:thm:validation_ada`, proof, "Counts", L978–982);
* `n_0 ≤ 2^36 p^{5/2}χ^{3/2}/a² + 2^31 p^{3/2}√K χ^{3/2}/a + 2^30 p²χ/a² + 1`,
  `n_j ≤ 2^38 p^{5/2}χ^{3/2}/a² + 2^30 p²χ/a² + 1` (`1 ≤ j < p`),
  `n_p ≤ 2^44 p²χ^{3/2}/a² + 2^30 p²χ/a² + 1`;
* `alg2_N_le_two_pow_45`: `N ≤ 2^45[…]`; **`alg2_N_le_explicit`**: `N ≤ valNExplicit`;
  **`alg2_N_le_asymp`**: `N ≤ 2^84 · valNAsymp` (existential form with `C = 2^84`).
-/

namespace F2e2e.B

/-! ### Basic facts for the `alg2*` parameters -/

theorem alg2A_pos (aReq : ℝ) : 0 < alg2A aReq := dyadicDown_pos aReq

theorem alg2A_le_one (aReq : ℝ) : alg2A aReq ≤ 1 := dyadicDown_le_one aReq

theorem alg2A_le {aReq : ℝ} (ha0 : 0 < aReq) : alg2A aReq ≤ aReq := dyadicDown_le ha0

theorem alg2A_le_sixteenth {aReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) :
    alg2A aReq ≤ 1 / 16 :=
  dyadicDown_le_sixteenth ha0 (by linarith)

theorem alg2XiA_pos (ξReq : ℝ) : 0 < alg2XiA ξReq := dyadicDown_pos ξReq

theorem alg2XiA_le_one (ξReq : ℝ) : alg2XiA ξReq ≤ 1 := dyadicDown_le_one ξReq

theorem two_le_alg2P (aReq : ℝ) : 2 ≤ alg2P aReq := two_le_valP (alg2A_pos aReq)

theorem two_le_alg2P_real (aReq : ℝ) : (2 : ℝ) ≤ alg2P aReq := two_le_valP_real (alg2A_pos aReq)

theorem alg2Tau_pos (aReq : ℝ) : 0 < alg2Tau aReq := valTau_pos (alg2A_pos aReq)

theorem alg2H_pos (aReq : ℝ) : 0 < alg2H aReq := valH_pos (alg2A_pos aReq)

theorem alg2H_le_one (aReq : ℝ) : alg2H aReq ≤ 1 :=
  valH_le_one (alg2A_pos aReq) (alg2A_le_one aReq)

/-- `1/h = 512p/a`. -/
theorem one_div_alg2H (aReq : ℝ) : 1 / alg2H aReq = 512 * (alg2P aReq : ℝ) / alg2A aReq :=
  one_div_valH _

/-- `1/τ² = 64p²/a²`. -/
theorem one_div_alg2Tau_sq (aReq : ℝ) :
    1 / alg2Tau aReq ^ 2 = 64 * (alg2P aReq : ℝ) ^ 2 / alg2A aReq ^ 2 :=
  one_div_valTau_sq _

theorem one_le_alg2Chi (M J R : ℕ) (aReq ξReq : ℝ) : 1 ≤ alg2Chi M J R aReq ξReq :=
  one_le_valChi M J R (alg2A_pos aReq) (alg2A_le_one aReq) (alg2XiA_pos ξReq)
    (alg2XiA_le_one ξReq)

/-! ### `T_j^max` with out-of-range zeros -/

theorem alg2Tmax_of_lt {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    alg2Tmax aReq j = valTmax (alg2A aReq) j := by
  unfold alg2Tmax
  rw [if_pos hj]

theorem alg2Tmax_of_ge {aReq : ℝ} {j : ℕ} (hj : alg2P aReq ≤ j) : alg2Tmax aReq j = 0 := by
  unfold alg2Tmax
  rw [if_neg (by omega)]

/-- `T_j^max ≤ 6/(4^jτ²) + 1` for every `j` (out-of-range values are `0`). -/
theorem alg2Tmax_le (aReq : ℝ) (j : ℕ) :
    (alg2Tmax aReq j : ℝ) ≤ 6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) + 1 := by
  unfold alg2Tmax
  split_ifs
  · exact valTmax_le _ _
  · simp only [Nat.cast_zero]
    positivity

theorem alg2TmaxZ_of_neg {aReq : ℝ} {z : ℤ} (hz : z < 0) : alg2TmaxZ aReq z = 0 := by
  unfold alg2TmaxZ
  rw [if_neg (by omega)]

theorem alg2TmaxZ_natCast (aReq : ℝ) (j : ℕ) : alg2TmaxZ aReq (j : ℤ) = alg2Tmax aReq j := by
  unfold alg2TmaxZ
  rw [if_pos (by positivity)]
  simp

theorem alg2TmaxZ_sub {aReq : ℝ} {j k : ℕ} (hkj : k ≤ j) :
    alg2TmaxZ aReq ((j : ℤ) - k) = alg2Tmax aReq (j - k) := by
  rw [show ((j : ℤ) - k) = ((j - k : ℕ) : ℤ) by push_cast [Nat.cast_sub hkj]; ring]
  exact alg2TmaxZ_natCast aReq (j - k)

theorem alg2TmaxZ_sub_two {aReq : ℝ} {j : ℕ} (hj : 2 ≤ j) :
    alg2TmaxZ aReq ((j : ℤ) - 2) = alg2Tmax aReq (j - 2) := by
  have e : ((j : ℤ) - 2) = ((j - 2 : ℕ) : ℤ) := by omega
  rw [e]
  exact alg2TmaxZ_natCast aReq (j - 2)

theorem alg2TmaxZ_sub_one {aReq : ℝ} {j : ℕ} (hj : 1 ≤ j) :
    alg2TmaxZ aReq ((j : ℤ) - 1) = alg2Tmax aReq (j - 1) := by
  have e : ((j : ℤ) - 1) = ((j - 1 : ℕ) : ℤ) := by omega
  rw [e]
  exact alg2TmaxZ_natCast aReq (j - 1)

/-- `6/(4^{j-k}τ²) = 4^k · 6/(4^jτ²)` for `k ≤ j`. -/
theorem six_div_four_pow_sub {τ : ℝ} (hτ : 0 < τ) {j k : ℕ} (hkj : k ≤ j) :
    6 / ((4 : ℝ) ^ (j - k) * τ ^ 2) = 4 ^ k * (6 / ((4 : ℝ) ^ j * τ ^ 2)) := by
  have e : (4 : ℝ) ^ j = 4 ^ (j - k) * 4 ^ k := by
    rw [← pow_add]
    congr 1
    omega
  rw [e]
  field_simp

/-! ### The phase budgets `C_j` (`R:eq:sec3_C_Q_chi`; proof of Theorem `R:thm:validation_ada`, "Counts") -/

theorem alg2C_zero_eq (J R : ℕ) (aReq : ℝ) :
    alg2C J R aReq 0 = valTmax (alg2A aReq) 0 + valTmax (alg2A aReq) 1 + J + R + 2 := by
  have hp := two_le_alg2P aReq
  unfold alg2C
  rw [if_pos rfl, alg2Tmax_of_lt (by omega), alg2Tmax_of_lt (by omega)]

theorem alg2C_mid_eq (J R : ℕ) {aReq : ℝ} {j : ℕ} (hj1 : 1 ≤ j) (hjp : j < alg2P aReq) :
    alg2C J R aReq j = alg2TmaxZ aReq ((j : ℤ) - 2) + 2 * alg2TmaxZ aReq ((j : ℤ) - 1) +
      2 * alg2Tmax aReq j + alg2Tmax aReq (j + 1) + 2 := by
  unfold alg2C
  rw [if_neg (by omega), if_pos hjp]

theorem alg2C_p_eq (J R : ℕ) (aReq : ℝ) :
    alg2C J R aReq (alg2P aReq) =
      valTmax (alg2A aReq) (alg2P aReq - 2) + valTmax (alg2A aReq) (alg2P aReq - 1) + 1 := by
  have hp := two_le_alg2P aReq
  unfold alg2C
  rw [if_neg (by omega), if_neg (lt_irrefl _), if_pos rfl,
    alg2TmaxZ_sub_two (by omega), alg2TmaxZ_sub_one (by omega),
    alg2Tmax_of_lt (by omega), alg2Tmax_of_lt (by omega)]

/-- `C_0 ≤ 7.5τ^{-2} + K + 3` with `K = J+R+1`. -/
theorem alg2C_zero_le (J R : ℕ) (aReq : ℝ) :
    (alg2C J R aReq 0 : ℝ) ≤ 15 / 2 / alg2Tau aReq ^ 2 + ((J : ℝ) + R + 1) + 3 := by
  rw [alg2C_zero_eq]
  have h0 := valTmax_le (alg2A aReq) 0
  have h1 := valTmax_le (alg2A aReq) 1
  have hτ := alg2Tau_pos aReq
  have e0 : 6 / ((4 : ℝ) ^ 0 * valTau (alg2A aReq) ^ 2) = 6 / alg2Tau aReq ^ 2 := by
    simp [alg2Tau]
  have e1 : 6 / ((4 : ℝ) ^ 1 * valTau (alg2A aReq) ^ 2) = 3 / 2 / alg2Tau aReq ^ 2 := by
    unfold alg2Tau
    field_simp
    ring
  rw [e0] at h0
  rw [e1] at h1
  push_cast
  have e2 : 15 / 2 / alg2Tau aReq ^ 2 = 6 / alg2Tau aReq ^ 2 + 3 / 2 / alg2Tau aReq ^ 2 := by ring
  linarith

/-- `C_0 ≤ 10τ^{-2} + K` (proof of Theorem `R:thm:validation_ada`, L982). -/
theorem alg2C_zero_le_ten (J R : ℕ) (aReq : ℝ) :
    (alg2C J R aReq 0 : ℝ) ≤ 10 / alg2Tau aReq ^ 2 + ((J : ℝ) + R + 1) := by
  have h := alg2C_zero_le J R aReq
  have hτ := alg2Tau_pos aReq
  have hτle : alg2Tau aReq ≤ 1 / 16 := by
    have h1 := valTau_le (alg2A_pos aReq)
    have h2 := alg2A_le_one aReq
    unfold alg2Tau
    linarith
  have h3 : (3 : ℝ) ≤ 5 / 2 / alg2Tau aReq ^ 2 := by
    rw [le_div_iff₀ (by positivity)]
    nlinarith
  have e : 10 / alg2Tau aReq ^ 2 = 15 / 2 / alg2Tau aReq ^ 2 + 5 / 2 / alg2Tau aReq ^ 2 := by ring
  linarith

/-- `C_j ≤ 157.5 v_j + 8` for `1 ≤ j < p`, `v_j = 4^{-j}τ^{-2}` (L978–980). -/
theorem alg2C_mid_le (J R : ℕ) {aReq : ℝ} {j : ℕ} (hj1 : 1 ≤ j) (hjp : j < alg2P aReq) :
    (alg2C J R aReq j : ℝ) ≤ 315 / 2 * (6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) / 6) + 8 := by
  rw [alg2C_mid_eq J R hj1 hjp]
  have hτ := alg2Tau_pos aReq
  set w := 6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) with hw
  have hw0 : 0 ≤ w := by positivity
  -- `T_{j-2}`
  have h1 : (alg2TmaxZ aReq ((j : ℤ) - 2) : ℝ) ≤ 16 * w + 1 := by
    rcases Nat.lt_or_ge j 2 with hj2 | hj2
    · rw [alg2TmaxZ_of_neg (by omega)]
      simp only [Nat.cast_zero]
      linarith
    · rw [alg2TmaxZ_sub_two hj2]
      have := alg2Tmax_le aReq (j - 2)
      rw [six_div_four_pow_sub hτ hj2] at this
      norm_num at this
      linarith
  -- `T_{j-1}`
  have h2 : (alg2TmaxZ aReq ((j : ℤ) - 1) : ℝ) ≤ 4 * w + 1 := by
    rw [alg2TmaxZ_sub_one hj1]
    have := alg2Tmax_le aReq (j - 1)
    rw [six_div_four_pow_sub hτ hj1] at this
    norm_num at this
    linarith
  -- `T_j`
  have h3 : (alg2Tmax aReq j : ℝ) ≤ w + 1 := alg2Tmax_le aReq j
  -- `T_{j+1}`
  have h4 : (alg2Tmax aReq (j + 1) : ℝ) ≤ w / 4 + 1 := by
    have := alg2Tmax_le aReq (j + 1)
    have e : 6 / ((4 : ℝ) ^ (j + 1) * alg2Tau aReq ^ 2) = w / 4 := by
      rw [hw, pow_succ]
      field_simp
    linarith
  push_cast
  linarith

/-- `C_j < 190 v_j` for `1 ≤ j < p` (L980), using `v_j > 1/4`. -/
theorem alg2C_mid_lt (J R : ℕ) {aReq : ℝ} {j : ℕ} (hj1 : 1 ≤ j) (hjp : j < alg2P aReq) :
    (alg2C J R aReq j : ℝ) < 190 * (1 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2)) := by
  have h := alg2C_mid_le J R hj1 hjp
  have hv := quarter_lt_inv_four_pow_valTau_sq (alg2A_pos aReq)
    (by linarith [alg2A_le_one aReq]) hjp
  have e : 6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) / 6 = 1 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) := by
    ring
  rw [e] at h
  change 1 / 4 < 1 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) at hv
  linarith

/-- `C_p ≤ 31` (L982). -/
theorem alg2C_p_le (J R : ℕ) (aReq : ℝ) : alg2C J R aReq (alg2P aReq) ≤ 31 := by
  rw [alg2C_p_eq]
  have h1 := valTmax_pred_pred_le (alg2A_pos aReq)
  have h2 := valTmax_pred_le (alg2A_pos aReq)
  change valTmax (alg2A aReq) (alg2P aReq - 2) ≤ 24 at h1
  change valTmax (alg2A aReq) (alg2P aReq - 1) ≤ 6 at h2
  omega

theorem one_le_alg2C (J R : ℕ) (aReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) : 1 ≤ alg2C J R aReq j := by
  rcases Nat.eq_zero_or_pos j with h0 | hpos
  · subst h0
    rw [alg2C_zero_eq]
    omega
  · rcases Nat.lt_or_ge j (alg2P aReq) with hlt | hge
    · rw [alg2C_mid_eq J R hpos hlt]
      omega
    · have hj' : j = alg2P aReq := le_antisymm hj hge
      subst hj'
      rw [alg2C_p_eq]
      omega

/-! ### `d_j` and `ϑ_j ≤ θ_j` (L689) -/

theorem alg2D_of_lt {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    alg2D aReq j = ⌈Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j)⌉₊ := by
  unfold alg2D
  rw [if_pos hj]

theorem alg2D_of_ge {aReq : ℝ} {j : ℕ} (hj : alg2P aReq ≤ j) :
    alg2D aReq j = ⌈4 / alg2H aReq⌉₊ := by
  unfold alg2D
  rw [if_neg (by omega)]

/-- `√(p 4^j) = 2^j √p`. -/
theorem sqrt_mul_four_pow (P : ℝ) (j : ℕ) : Real.sqrt (P * 4 ^ j) = 2 ^ j * Real.sqrt P := by
  rw [Real.sqrt_mul' _ (by positivity),
    show (4 : ℝ) ^ j = ((2 : ℝ) ^ j) ^ 2 by rw [← pow_mul, mul_comm, pow_mul]; norm_num,
    Real.sqrt_sq (by positivity)]
  ring

theorem one_le_sqrt_alg2P (aReq : ℝ) : 1 ≤ Real.sqrt (alg2P aReq : ℝ) := by
  rw [Real.one_le_sqrt]
  linarith [two_le_alg2P_real aReq]

/-- `d_j ≤ 2·2^j√p` for `j < p`. -/
theorem alg2D_le_of_lt {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    (alg2D aReq j : ℝ) ≤ 2 * 2 ^ j * Real.sqrt (alg2P aReq) := by
  rw [alg2D_of_lt hj, sqrt_mul_four_pow]
  have h1 := Nat.ceil_lt_add_one (by positivity : (0 : ℝ) ≤ 2 ^ j * Real.sqrt (alg2P aReq))
  have hs := one_le_sqrt_alg2P aReq
  have h2j : (1 : ℝ) ≤ 2 ^ j := one_le_pow₀ (by norm_num)
  nlinarith

/-- `d_p ≤ 5/h` (and the same for `j > p`). -/
theorem alg2D_le_of_ge {aReq : ℝ} {j : ℕ} (hj : alg2P aReq ≤ j) :
    (alg2D aReq j : ℝ) ≤ 5 / alg2H aReq := by
  rw [alg2D_of_ge hj]
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have h1 := Nat.ceil_lt_add_one (by positivity : (0 : ℝ) ≤ 4 / alg2H aReq)
  have h2 : (1 : ℝ) ≤ 1 / alg2H aReq := by rw [le_div_iff₀ hh]; linarith
  have e : 5 / alg2H aReq = 4 / alg2H aReq + 1 / alg2H aReq := by ring
  linarith

/-- `1 ≤ d_j`. -/
theorem one_le_alg2D (aReq : ℝ) (j : ℕ) : 1 ≤ alg2D aReq j := by
  unfold alg2D
  split_ifs
  · apply Nat.one_le_iff_ne_zero.mpr
    apply (Nat.ceil_pos.mpr _).ne'
    apply Real.sqrt_pos.mpr
    have := two_le_alg2P_real aReq
    positivity
  · apply Nat.one_le_iff_ne_zero.mpr
    apply (Nat.ceil_pos.mpr _).ne'
    have := alg2H_pos aReq
    positivity

/-- `ϑ_j ≤ θ_j` for every `0 ≤ j ≤ p` (L689; for `j > p` both use the anchor formulas). -/
theorem alg2Vartheta_le_alg2Theta (aReq : ℝ) (j : ℕ) : alg2Vartheta aReq j ≤ alg2Theta aReq j := by
  unfold alg2Vartheta alg2Theta
  split_ifs with hj
  · rw [alg2D_of_lt hj]
    unfold alg2Lambda
    have hpos : 0 < Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j) := by
      apply Real.sqrt_pos.mpr
      have := two_le_alg2P_real aReq
      positivity
    exact one_div_le_one_div_of_le hpos (Nat.le_ceil _)
  · rw [alg2D_of_ge (not_lt.mp hj)]
    have hh := alg2H_pos aReq
    have h4 : 4 / alg2H aReq ≤ (⌈4 / alg2H aReq⌉₊ : ℝ) := Nat.le_ceil _
    have hpos : 0 < 4 / alg2H aReq := by positivity
    have h1 : 1 / (⌈4 / alg2H aReq⌉₊ : ℝ) ≤ alg2H aReq / 4 := by
      calc 1 / (⌈4 / alg2H aReq⌉₊ : ℝ) ≤ 1 / (4 / alg2H aReq) := one_div_le_one_div_of_le hpos h4
        _ = alg2H aReq / 4 := by rw [one_div_div]
    have hs2 : Real.sqrt 2 ≤ 2 := by
      rw [Real.sqrt_le_left (by norm_num)]
      norm_num
    have hs0 : 0 < Real.sqrt 2 := by positivity
    have h2 : alg2H aReq / 4 ≤ alg2H aReq / (2 * Real.sqrt 2) := by
      apply div_le_div_of_nonneg_left hh.le (by positivity)
      linarith
    linarith

/-! ### `Δ_root < a/4` (`R:eq:sec3_internal_error_budget`, L676–678) -/

/-- `Δ_root = pτ(1 + 2/64 + 1.5/(64p))`. -/
theorem alg2DeltaRoot_eq (aReq : ℝ) :
    alg2DeltaRoot aReq =
      (alg2P aReq : ℝ) * alg2Tau aReq * (1 + 2 / 64 + 3 / 2 / (64 * (alg2P aReq : ℝ))) := by
  have hp : (0 : ℝ) < alg2P aReq := by linarith [two_le_alg2P_real aReq]
  unfold alg2DeltaRoot
  rw [alg2H, valH_eq_valTau_div]
  change (alg2P aReq : ℝ) * (alg2Tau aReq + 2 * (alg2Tau aReq / 64)) + 3 / 2 * (alg2Tau aReq / 64) =
    (alg2P aReq : ℝ) * alg2Tau aReq * (1 + 2 / 64 + 3 / 2 / (64 * (alg2P aReq : ℝ)))
  field_simp

/-- `Δ_root ≤ (66.75/64) pτ = (66.75/512) a`. -/
theorem alg2DeltaRoot_le (aReq : ℝ) : alg2DeltaRoot aReq ≤ 267 / 2048 * alg2A aReq := by
  rw [alg2DeltaRoot_eq]
  have hp := two_le_alg2P_real aReq
  have hpτ := valP_mul_valTau (alg2A_pos aReq)
  change (alg2P aReq : ℝ) * alg2Tau aReq = alg2A aReq / 8 at hpτ
  have hb : 3 / 2 / (64 * (alg2P aReq : ℝ)) ≤ 3 / 256 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    nlinarith
  have hpos : 0 ≤ (alg2P aReq : ℝ) * alg2Tau aReq := by
    have := alg2Tau_pos aReq
    positivity
  calc (alg2P aReq : ℝ) * alg2Tau aReq * (1 + 2 / 64 + 3 / 2 / (64 * (alg2P aReq : ℝ)))
      ≤ (alg2P aReq : ℝ) * alg2Tau aReq * (1 + 2 / 64 + 3 / 256) := by gcongr
    _ = 267 / 2048 * alg2A aReq := by rw [hpτ]; ring

/-- `Δ_root < 0.131 a`. -/
theorem alg2DeltaRoot_lt (aReq : ℝ) : alg2DeltaRoot aReq < 131 / 1000 * alg2A aReq := by
  have h := alg2DeltaRoot_le aReq
  have ha := alg2A_pos aReq
  linarith

/-- `Δ_root < a/4`. -/
theorem alg2DeltaRoot_lt_quarter (aReq : ℝ) : alg2DeltaRoot aReq < alg2A aReq / 4 := by
  have h := alg2DeltaRoot_lt aReq
  have ha := alg2A_pos aReq
  linarith

/-! ### Block sizes -/

/-- Pure-real bound for one block: `⌈2^20 X D ⌈√(CX)⌉/h + 2^12 X/h²⌉ ≤ 2^21 X D √(CX)/h + 2^12 X/h² + 1`. -/
theorem nblock_le {X D Cc h : ℝ} (hX : 1 ≤ X) (hC : 1 ≤ Cc) (hD : 0 ≤ D) (hh : 0 < h) :
    ((⌈(2 : ℝ) ^ 20 * X * D * (⌈Real.sqrt (Cc * X)⌉₊ : ℝ) / h + (2 : ℝ) ^ 12 * X / h ^ 2⌉₊ : ℕ) :
        ℝ) ≤
      2 ^ 21 * X * D * Real.sqrt (Cc * X) / h + 2 ^ 12 * X / h ^ 2 + 1 := by
  have hs1 : 1 ≤ Real.sqrt (Cc * X) := by
    rw [Real.one_le_sqrt]
    nlinarith
  have hc : (⌈Real.sqrt (Cc * X)⌉₊ : ℝ) ≤ 2 * Real.sqrt (Cc * X) := by
    have := Nat.ceil_lt_add_one (Real.sqrt_nonneg (Cc * X))
    linarith
  have hX0 : 0 ≤ X := by linarith
  have hin : 0 ≤ (2 : ℝ) ^ 20 * X * D * (⌈Real.sqrt (Cc * X)⌉₊ : ℝ) / h + (2 : ℝ) ^ 12 * X / h ^ 2 := by
    positivity
  have h1 := Nat.ceil_lt_add_one hin
  have h2 : (2 : ℝ) ^ 20 * X * D * (⌈Real.sqrt (Cc * X)⌉₊ : ℝ) / h ≤
      2 ^ 21 * X * D * Real.sqrt (Cc * X) / h := by
    apply div_le_div_of_nonneg_right _ hh.le
    have : 0 ≤ (2 : ℝ) ^ 20 * X * D := by positivity
    calc (2 : ℝ) ^ 20 * X * D * (⌈Real.sqrt (Cc * X)⌉₊ : ℝ)
        ≤ 2 ^ 20 * X * D * (2 * Real.sqrt (Cc * X)) := by gcongr
      _ = 2 ^ 21 * X * D * Real.sqrt (Cc * X) := by ring
  linarith

theorem alg2NBlock_le_raw (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    (alg2NBlock M J R aReq ξReq j : ℝ) ≤
      2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
          Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq +
        2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 + 1 := by
  have hX : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by exact_mod_cast one_le_alg2Chi M J R aReq ξReq
  have hC : (1 : ℝ) ≤ alg2C J R aReq j := by exact_mod_cast one_le_alg2C J R aReq hj
  unfold alg2NBlock
  exact nblock_le hX hC (Nat.cast_nonneg _) (alg2H_pos aReq)

/-- The second term of every block: `2^12 χ/h² = 2^30 p²χ/a²`. -/
theorem second_term_eq (aReq : ℝ) (X : ℝ) :
    2 ^ 12 * X / alg2H aReq ^ 2 = 2 ^ 30 * ((alg2P aReq : ℝ) ^ 2 * X / alg2A aReq ^ 2) := by
  have h := one_div_alg2H aReq
  have hh := alg2H_pos aReq
  have ha := alg2A_pos aReq
  have e : 2 ^ 12 * X / alg2H aReq ^ 2 = 2 ^ 12 * X * (1 / alg2H aReq) ^ 2 := by
    field_simp
  rw [e, h]
  field_simp
  ring

/-- `1/(4^jτ²) = 64p²/((2^j)² a²)`. -/
theorem inv_four_pow_alg2Tau_sq (aReq : ℝ) (j : ℕ) :
    1 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) =
      64 * (alg2P aReq : ℝ) ^ 2 / (((2 : ℝ) ^ j) ^ 2 * alg2A aReq ^ 2) := by
  have hp : (0 : ℝ) < alg2P aReq := by linarith [two_le_alg2P_real aReq]
  have ha := alg2A_pos aReq
  have e4 : ((2 : ℝ) ^ j) ^ 2 = 4 ^ j := by
    rw [← pow_mul, mul_comm, pow_mul]
    norm_num
  rw [e4]
  show 1 / ((4 : ℝ) ^ j * (alg2A aReq / (8 * (alg2P aReq : ℝ))) ^ 2) =
    64 * (alg2P aReq : ℝ) ^ 2 / ((4 : ℝ) ^ j * alg2A aReq ^ 2)
  field_simp
  ring

/-- Pure-real middle-block bound (`w = 2^j`, `hinv = 1/h`). -/
theorem mid_block_real {P X a D Cc w hinv : ℝ} (hP : 1 ≤ P) (hX : 1 ≤ X) (ha : 0 < a) (hw : 0 < w)
    (hD : D ≤ 2 * w * Real.sqrt P)
    (hC : Cc ≤ 190 * (64 * P ^ 2 / (w ^ 2 * a ^ 2))) (hhinv : hinv = 512 * P / a) :
    2 ^ 21 * X * D * Real.sqrt (Cc * X) * hinv ≤
      2 ^ 38 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) := by
  have hX0 : 0 ≤ X := by linarith
  have hP0 : 0 ≤ P := by linarith
  have hsX := Real.sq_sqrt hX0
  have hS : Real.sqrt (Cc * X) ≤ 112 * Real.sqrt X * P / (w * a) := by
    rw [Real.sqrt_le_left (by positivity)]
    have e1 : (112 * Real.sqrt X * P / (w * a)) ^ 2 = X * (12544 * P ^ 2 / (w ^ 2 * a ^ 2)) := by
      rw [div_pow, mul_pow, mul_pow, mul_pow, hsX]
      ring
    rw [e1]
    have h2 : 190 * (64 * P ^ 2 / (w ^ 2 * a ^ 2)) ≤ 12544 * P ^ 2 / (w ^ 2 * a ^ 2) := by
      rw [← mul_div_assoc, ← mul_assoc]
      apply div_le_div_of_nonneg_right _ (by positivity)
      nlinarith
    calc Cc * X = X * Cc := by ring
      _ ≤ X * (12544 * P ^ 2 / (w ^ 2 * a ^ 2)) := by gcongr; linarith
  rw [hhinv]
  calc 2 ^ 21 * X * D * Real.sqrt (Cc * X) * (512 * P / a)
      ≤ 2 ^ 21 * X * (2 * w * Real.sqrt P) * (112 * Real.sqrt X * P / (w * a)) * (512 * P / a) := by
        gcongr
    _ = 2 ^ 21 * 114688 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) := by
        field_simp
        ring
    _ ≤ 2 ^ 38 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) := by
        have : 0 ≤ P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2 := by positivity
        nlinarith

/-- Pure-real root-block bound (`hinv = 1/h`, `K = J+R+1`). -/
theorem root_block_real {P X a D Cc K hinv : ℝ} (hP : 1 ≤ P) (hX : 1 ≤ X) (ha : 0 < a) (hK : 0 ≤ K)
    (hD : D ≤ 2 * Real.sqrt P)
    (hC : Cc ≤ 640 * P ^ 2 / a ^ 2 + K) (hhinv : hinv = 512 * P / a) :
    2 ^ 21 * X * D * Real.sqrt (Cc * X) * hinv ≤
      2 ^ 36 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) +
        2 ^ 31 * (P * Real.sqrt P * Real.sqrt K * (X * Real.sqrt X) / a) := by
  have hX0 : 0 ≤ X := by linarith
  have hP0 : 0 ≤ P := by linarith
  have hsX := Real.sq_sqrt hX0
  have hsK := Real.sq_sqrt hK
  have hS : Real.sqrt (Cc * X) ≤ Real.sqrt X * (26 * P / a + Real.sqrt K) := by
    rw [Real.sqrt_le_left (by positivity)]
    have e1 : (Real.sqrt X * (26 * P / a + Real.sqrt K)) ^ 2 =
        X * (676 * P ^ 2 / a ^ 2 + 52 * P / a * Real.sqrt K + K) := by
      rw [mul_pow, hsX, add_sq, hsK]
      ring
    rw [e1]
    have h3 : 0 ≤ 52 * P / a * Real.sqrt K := by positivity
    have h4 : 640 * P ^ 2 / a ^ 2 ≤ 676 * P ^ 2 / a ^ 2 := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      nlinarith
    have hC' : Cc ≤ 676 * P ^ 2 / a ^ 2 + 52 * P / a * Real.sqrt K + K := by linarith
    calc Cc * X = X * Cc := by ring
      _ ≤ X * (676 * P ^ 2 / a ^ 2 + 52 * P / a * Real.sqrt K + K) := by gcongr
  rw [hhinv]
  calc 2 ^ 21 * X * D * Real.sqrt (Cc * X) * (512 * P / a)
      ≤ 2 ^ 21 * X * (2 * Real.sqrt P) * (Real.sqrt X * (26 * P / a + Real.sqrt K)) *
          (512 * P / a) := by gcongr
    _ = 2 ^ 31 * 26 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) +
        2 ^ 31 * (P * Real.sqrt P * Real.sqrt K * (X * Real.sqrt X) / a) := by
        field_simp
        ring
    _ ≤ 2 ^ 36 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) +
        2 ^ 31 * (P * Real.sqrt P * Real.sqrt K * (X * Real.sqrt X) / a) := by
        have : 0 ≤ P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2 := by positivity
        nlinarith

/-- Pure-real anchor-block bound (`hinv = 1/h`). -/
theorem anchor_block_real {P X a D Cc hinv : ℝ} (hX : 1 ≤ X) (ha : 0 < a) (hP0 : 0 ≤ P)
    (hD : D ≤ 5 * hinv) (hC : Cc ≤ 31) (hhinv : hinv = 512 * P / a) :
    2 ^ 21 * X * D * Real.sqrt (Cc * X) * hinv ≤ 2 ^ 44 * (P ^ 2 * (X * Real.sqrt X) / a ^ 2) := by
  have hX0 : 0 ≤ X := by linarith
  have hsX := Real.sq_sqrt hX0
  have hS : Real.sqrt (Cc * X) ≤ 6 * Real.sqrt X := by
    rw [Real.sqrt_le_left (by positivity), mul_pow, hsX]
    nlinarith
  have hinv0 : 0 ≤ hinv := by rw [hhinv]; positivity
  calc 2 ^ 21 * X * D * Real.sqrt (Cc * X) * hinv
      ≤ 2 ^ 21 * X * (5 * hinv) * (6 * Real.sqrt X) * hinv := by gcongr
    _ = 2 ^ 21 * 30 * (X * Real.sqrt X) * hinv ^ 2 := by ring
    _ = 2 ^ 21 * 7864320 * (P ^ 2 * (X * Real.sqrt X) / a ^ 2) := by
        rw [hhinv]
        field_simp
        ring
    _ ≤ 2 ^ 44 * (P ^ 2 * (X * Real.sqrt X) / a ^ 2) := by
        have : 0 ≤ P ^ 2 * (X * Real.sqrt X) / a ^ 2 := by positivity
        nlinarith

/-- Middle blocks `1 ≤ j < p`: `n_j ≤ 2^38 p^{5/2}χ^{3/2}/a² + 2^30 p²χ/a² + 1`. -/
theorem alg2NBlock_mid_le (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj1 : 1 ≤ j) (hjp : j < alg2P aReq) :
    (alg2NBlock M J R aReq ξReq j : ℝ) ≤
      2 ^ 38 * ((alg2P aReq : ℝ) ^ 2 * Real.sqrt (alg2P aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq)) / alg2A aReq ^ 2) +
        2 ^ 30 * ((alg2P aReq : ℝ) ^ 2 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2) + 1 := by
  have h := alg2NBlock_le_raw M J R aReq ξReq hjp.le
  rw [second_term_eq] at h
  have hX1 : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by
    exact_mod_cast one_le_alg2Chi M J R aReq ξReq
  have hP1 : (1 : ℝ) ≤ alg2P aReq := by linarith [two_le_alg2P_real aReq]
  have hC := alg2C_mid_lt J R (aReq := aReq) hj1 hjp
  rw [inv_four_pow_alg2Tau_sq] at hC
  have hfirst := mid_block_real (X := (alg2Chi M J R aReq ξReq : ℝ)) hP1 hX1 (alg2A_pos aReq)
    (by positivity : (0 : ℝ) < 2 ^ j) (alg2D_le_of_lt hjp) hC.le (one_div_alg2H aReq)
  have e : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
      Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq =
      2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
      Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq) := by
    ring
  rw [e] at h
  linarith

/-- Root block `j = 0`: `n_0 ≤ 2^36 p^{5/2}χ^{3/2}/a² + 2^31 p^{3/2}√K χ^{3/2}/a + 2^30 p²χ/a² + 1`. -/
theorem alg2NBlock_zero_le (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2NBlock M J R aReq ξReq 0 : ℝ) ≤
      2 ^ 36 * ((alg2P aReq : ℝ) ^ 2 * Real.sqrt (alg2P aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq)) / alg2A aReq ^ 2) +
        2 ^ 31 * ((alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq)) / alg2A aReq) +
        2 ^ 30 * ((alg2P aReq : ℝ) ^ 2 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2) + 1 := by
  have hp0 : 0 < alg2P aReq := by have := two_le_alg2P aReq; omega
  have h := alg2NBlock_le_raw M J R aReq ξReq (Nat.zero_le _)
  rw [second_term_eq] at h
  have hX1 : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by
    exact_mod_cast one_le_alg2Chi M J R aReq ξReq
  have hP1 : (1 : ℝ) ≤ alg2P aReq := by linarith [two_le_alg2P_real aReq]
  have hD := alg2D_le_of_lt hp0
  simp only [pow_zero, mul_one] at hD
  have hC := alg2C_zero_le_ten J R aReq
  have e10 : 10 / alg2Tau aReq ^ 2 = 640 * (alg2P aReq : ℝ) ^ 2 / alg2A aReq ^ 2 := by
    rw [show 10 / alg2Tau aReq ^ 2 = 10 * (1 / alg2Tau aReq ^ 2) by ring, one_div_alg2Tau_sq]
    ring
  rw [e10] at hC
  have hfirst := root_block_real (X := (alg2Chi M J R aReq ξReq : ℝ)) hP1 hX1 (alg2A_pos aReq)
    (by positivity : (0 : ℝ) ≤ (J : ℝ) + R + 1) hD hC (one_div_alg2H aReq)
  have e : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq 0 : ℝ) *
      Real.sqrt ((alg2C J R aReq 0 : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq =
      2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq 0 : ℝ) *
      Real.sqrt ((alg2C J R aReq 0 : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq) := by
    ring
  rw [e] at h
  linarith

/-- Anchor block `j = p`: `n_p ≤ 2^44 p²χ^{3/2}/a² + 2^30 p²χ/a² + 1`. -/
theorem alg2NBlock_p_le (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2NBlock M J R aReq ξReq (alg2P aReq) : ℝ) ≤
      2 ^ 44 * ((alg2P aReq : ℝ) ^ 2 *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq)) / alg2A aReq ^ 2) +
        2 ^ 30 * ((alg2P aReq : ℝ) ^ 2 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2) + 1 := by
  have h := alg2NBlock_le_raw M J R aReq ξReq (le_refl _)
  rw [second_term_eq] at h
  have hX1 : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by
    exact_mod_cast one_le_alg2Chi M J R aReq ξReq
  have hD := alg2D_le_of_ge (le_refl (alg2P aReq))
  have hD' : (alg2D aReq (alg2P aReq) : ℝ) ≤ 5 * (1 / alg2H aReq) := by
    calc (alg2D aReq (alg2P aReq) : ℝ) ≤ 5 / alg2H aReq := hD
      _ = 5 * (1 / alg2H aReq) := by ring
  have hC : (alg2C J R aReq (alg2P aReq) : ℝ) ≤ 31 := by exact_mod_cast alg2C_p_le J R aReq
  have hfirst := anchor_block_real (X := (alg2Chi M J R aReq ξReq : ℝ)) hX1 (alg2A_pos aReq)
    (Nat.cast_nonneg _) hD' hC (one_div_alg2H aReq)
  have e : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq (alg2P aReq) : ℝ) *
      Real.sqrt ((alg2C J R aReq (alg2P aReq) : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq =
      2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq (alg2P aReq) : ℝ) *
      Real.sqrt ((alg2C J R aReq (alg2P aReq) : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) *
        (1 / alg2H aReq) := by
    ring
  rw [e] at h
  linarith

/-! ### The total `N ≤ 2^45[…] ≤ valNExplicit` -/

/-- `N = n_0 + ∑_{1 ≤ j < p} n_j + n_p`. -/
theorem alg2N_split (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2N M J R aReq ξReq : ℝ) = (alg2NBlock M J R aReq ξReq 0 : ℝ) +
      ∑ i ∈ Finset.range (alg2P aReq - 1), (alg2NBlock M J R aReq ξReq (i + 1) : ℝ) +
      (alg2NBlock M J R aReq ξReq (alg2P aReq) : ℝ) := by
  have hp := two_le_alg2P aReq
  unfold alg2N
  push_cast
  rw [Finset.sum_range_succ]
  have e : alg2P aReq = (alg2P aReq - 1) + 1 := by omega
  conv_lhs => rw [e, Finset.sum_range_succ', ← e]
  ring

/-- Pure-real assembly of the block bounds into `2^45[…]`. -/
theorem sum_blocks_real {P X a K n0 S np : ℝ} (hP : 2 ≤ P) (hX : 1 ≤ X) (ha : 0 < a)
    (ha1 : a ≤ 1)
    (h0 : n0 ≤ 2 ^ 36 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) +
        2 ^ 31 * (P * Real.sqrt P * Real.sqrt K * (X * Real.sqrt X) / a) +
        2 ^ 30 * (P ^ 2 * X / a ^ 2) + 1)
    (hS : S ≤ (P - 1) * (2 ^ 38 * (P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2) +
        2 ^ 30 * (P ^ 2 * X / a ^ 2) + 1))
    (hp : np ≤ 2 ^ 44 * (P ^ 2 * (X * Real.sqrt X) / a ^ 2) + 2 ^ 30 * (P ^ 2 * X / a ^ 2) + 1) :
    n0 + S + np ≤ 2 ^ 45 * (((P ^ 3 * Real.sqrt P / a ^ 2 + P * Real.sqrt P * Real.sqrt K / a) *
        (X * Real.sqrt X)) + P ^ 3 * X / a ^ 2) := by
  have hsP : 1 ≤ Real.sqrt P := by rw [Real.one_le_sqrt]; linarith
  have hsX : 1 ≤ Real.sqrt X := by rw [Real.one_le_sqrt]; linarith
  have hP0 : 0 ≤ P := by linarith
  have hX0 : 0 ≤ X := by linarith
  -- abbreviations as plain equalities
  obtain ⟨q1, hq1⟩ : ∃ q1, q1 = P ^ 2 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2 := ⟨_, rfl⟩
  obtain ⟨q2, hq2⟩ : ∃ q2, q2 = P ^ 2 * (X * Real.sqrt X) / a ^ 2 := ⟨_, rfl⟩
  obtain ⟨q3, hq3⟩ : ∃ q3, q3 = P ^ 2 * X / a ^ 2 := ⟨_, rfl⟩
  obtain ⟨m1, hm1⟩ : ∃ m1, m1 = P ^ 3 * Real.sqrt P * (X * Real.sqrt X) / a ^ 2 := ⟨_, rfl⟩
  obtain ⟨m2, hm2⟩ : ∃ m2, m2 = P * Real.sqrt P * Real.sqrt K * (X * Real.sqrt X) / a := ⟨_, rfl⟩
  obtain ⟨m3, hm3⟩ : ∃ m3, m3 = P ^ 3 * X / a ^ 2 := ⟨_, rfl⟩
  rw [← hq1, ← hm2, ← hq3] at h0
  rw [← hq1, ← hq3] at hS
  rw [← hq2, ← hq3] at hp
  have efin : ((P ^ 3 * Real.sqrt P / a ^ 2 + P * Real.sqrt P * Real.sqrt K / a) *
      (X * Real.sqrt X)) + P ^ 3 * X / a ^ 2 = m1 + m2 + m3 := by
    rw [hm1, hm2, hm3]
    ring
  rw [efin]
  have hq1m : P * q1 = m1 := by rw [hq1, hm1]; ring
  have hq3m : P * q3 = m3 := by rw [hq3, hm3]; ring
  have hq1_0 : 0 ≤ q1 := by rw [hq1]; positivity
  have hq2_0 : 0 ≤ q2 := by rw [hq2]; positivity
  have hq3_0 : 0 ≤ q3 := by rw [hq3]; positivity
  have hm2_0 : 0 ≤ m2 := by rw [hm2]; positivity
  have hq2q1 : q2 ≤ q1 := by
    rw [hq2, hq1]
    apply div_le_div_of_nonneg_right _ (by positivity)
    have : 0 ≤ P ^ 2 * (X * Real.sqrt X) := by positivity
    nlinarith
  have hq1m1 : q1 ≤ m1 := by rw [← hq1m]; nlinarith
  have hq3m3 : q3 ≤ m3 := by rw [← hq3m]; nlinarith
  have hPm3 : P + 2 ≤ m3 := by
    rw [hm3]
    have h1 : P ^ 3 ≤ P ^ 3 * X / a ^ 2 := by
      rw [le_div_iff₀ (by positivity)]
      have : a ^ 2 ≤ 1 := by nlinarith
      have : 0 ≤ P ^ 3 := by positivity
      nlinarith
    have h2 : P + 2 ≤ P ^ 3 := by nlinarith
    linarith
  have e : (2 ^ 36 * q1 + 2 ^ 31 * m2 + 2 ^ 30 * q3 + 1) +
      (P - 1) * (2 ^ 38 * q1 + 2 ^ 30 * q3 + 1) + (2 ^ 44 * q2 + 2 ^ 30 * q3 + 1) =
      2 ^ 36 * q1 - 2 ^ 38 * q1 + 2 ^ 38 * (P * q1) + 2 ^ 44 * q2 + 2 ^ 31 * m2 +
        2 ^ 30 * (P * q3) + 2 ^ 30 * q3 + (P + 1) := by ring
  have hstep : (2 ^ 36 * q1 + 2 ^ 31 * m2 + 2 ^ 30 * q3 + 1) +
      (P - 1) * (2 ^ 38 * q1 + 2 ^ 30 * q3 + 1) + (2 ^ 44 * q2 + 2 ^ 30 * q3 + 1) ≤
      2 ^ 45 * (m1 + m2 + m3) := by
    rw [e, hq1m, hq3m]
    nlinarith
  linarith

/-- **The paper-checker form** `N ≤ 2^45[(p^{7/2}/a² + p^{3/2}√K/a)χ^{3/2} + p³χ/a²]`. -/
theorem alg2_N_le_two_pow_45 (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2N M J R aReq ξReq : ℝ) ≤
      2 ^ 45 * ((((alg2P aReq : ℝ) ^ 3 * Real.sqrt (alg2P aReq) / alg2A aReq ^ 2 +
          (alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) / alg2A aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq))) +
        (alg2P aReq : ℝ) ^ 3 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2) := by
  rw [alg2N_split]
  have h0 := alg2NBlock_zero_le M J R aReq ξReq
  have hpe := alg2NBlock_p_le M J R aReq ξReq
  have hp := two_le_alg2P aReq
  have hmid : ∀ i ∈ Finset.range (alg2P aReq - 1), (alg2NBlock M J R aReq ξReq (i + 1) : ℝ) ≤
      2 ^ 38 * ((alg2P aReq : ℝ) ^ 2 * Real.sqrt (alg2P aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq)) / alg2A aReq ^ 2) +
        2 ^ 30 * ((alg2P aReq : ℝ) ^ 2 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2) + 1 := by
    intro i hi
    rw [Finset.mem_range] at hi
    exact alg2NBlock_mid_le M J R aReq ξReq (by omega) (by omega)
  have hsum := Finset.sum_le_sum hmid
  rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hsum
  have hcast : ((alg2P aReq - 1 : ℕ) : ℝ) = (alg2P aReq : ℝ) - 1 := by
    rw [Nat.cast_sub (by omega)]
    simp
  rw [hcast] at hsum
  have hX1 : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by
    exact_mod_cast one_le_alg2Chi M J R aReq ξReq
  exact sum_blocks_real (two_le_alg2P_real aReq) hX1 (alg2A_pos aReq) (alg2A_le_one aReq)
    h0 hsum hpe

/-- **Contract** (`R:eq:sec3_N_explicit`): `N ≤ valNExplicit` (the Spec's `2^64[…]`). (The bound
holds for all `aReq, ξReq`; the hypotheses of Theorem B are kept in the agreed contract form.) -/
theorem alg2_N_le_explicit (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (alg2N M J R aReq ξReq : ℝ) ≤ valNExplicit M J R aReq ξReq := by
  have _hyp : 0 < aReq ∧ aReq < 1 / 10 ∧ 0 < ξReq ∧ ξReq < 1 / 2 := ⟨ha0, ha1, hξ0, hξ1⟩
  have h := alg2_N_le_two_pow_45 M J R aReq ξReq
  have hB : 0 ≤ (((alg2P aReq : ℝ) ^ 3 * Real.sqrt (alg2P aReq) / alg2A aReq ^ 2 +
          (alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) / alg2A aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq))) +
        (alg2P aReq : ℝ) ^ 3 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2 := by
    have := alg2A_pos aReq
    positivity
  unfold valNExplicit
  change (alg2N M J R aReq ξReq : ℝ) ≤ 2 ^ 64 *
    ((((alg2P aReq : ℝ) ^ 3 * Real.sqrt (alg2P aReq) / alg2A aReq ^ 2 +
          (alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) / alg2A aReq) *
          ((alg2Chi M J R aReq ξReq : ℝ) * Real.sqrt (alg2Chi M J R aReq ξReq))) +
        (alg2P aReq : ℝ) ^ 3 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2)
  nlinarith

/-- **Contract** (`R:eq:sec3_total_N_validation`): `N ≤ C · valNAsymp` for one universal `C`
(here `C = 2^84`). -/
theorem alg2_N_le_asymp :
    ∃ C : ℝ, 0 < C ∧ ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq →
      ξReq < 1 / 2 → (alg2N M J R aReq ξReq : ℝ) ≤ C * valNAsymp M J R aReq ξReq :=
  ⟨2 ^ 84, by positivity, fun M J R _ _ ha0 ha1 hξ0 hξ1 =>
    (alg2_N_le_explicit M J R ha0 ha1 hξ0 hξ1).trans (valNExplicit_le_asymp M J R ha0 ha1 hξ0 hξ1)⟩

end F2e2e.B
