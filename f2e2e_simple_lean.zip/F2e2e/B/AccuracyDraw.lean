import F2e2e.Lib.Discrete.DrawProg

/-!
# Good paths of programs with adaptive draws, and the bad-output probability

Paper: Part II, Theorem `R:thm:validation_ada`, proof, "Transfer and accuracy" (`parts/partII.tex`
L1036–1046): the noise-bounded event "no draw exceeds its radius" and the deterministic analysis "on this
event, …".

For a program `prog : DrawProg P β α` with adaptive draws, a per-draw predicate `good : P → β → Prop`
(a draw with parameter `p` and outcome `b` is *good*) and an output predicate `Q : α → Prop`:

* `GoodPaths good Q prog`: along every path on which every draw is good, the output satisfies `Q`
  (a deterministic statement, proved by following the program);
* `interp_bad_le`: if every draw is bad with probability at most `ε` (under the draw laws `L p`) and the
  program makes at most `n` draws on every path, then `P[¬ Q (output)] ≤ n ε`;
* `toBits_bad_le`, `sum_tapes_bad_le`: the same for the bit implementation, as a law and as a sum over the
  uniform finite tapes of the specification.
-/

namespace F2e2e.Discrete.DrawProg

open ENNReal

universe u

variable {P β α γ : Type u}

/-- Along every path of `prog` on which every draw outcome `b` with parameter `p` satisfies `good p b`, the
output satisfies `Q`. -/
def GoodPaths (good : P → β → Prop) (Q : α → Prop) : DrawProg P β α → Prop
  | ret a => Q a
  | draw p k => ∀ b, good p b → GoodPaths good Q (k b)

variable {good : P → β → Prop} {Q Q' : α → Prop}

@[simp] theorem goodPaths_ret (a : α) : GoodPaths good Q (ret a) ↔ Q a := Iff.rfl

@[simp] theorem goodPaths_draw (p : P) (k : β → DrawProg P β α) :
    GoodPaths good Q (draw p k) ↔ ∀ b, good p b → GoodPaths good Q (k b) := Iff.rfl

theorem GoodPaths.mono {prog : DrawProg P β α} (h : GoodPaths good Q prog) (hQ : ∀ a, Q a → Q' a) :
    GoodPaths good Q' prog := by
  induction prog with
  | ret a => exact hQ a h
  | draw p k ih => exact fun b hb => ih b (h b hb)

theorem GoodPaths.bind {prog : DrawProg P β α} {f : α → DrawProg P β γ} {R : γ → Prop}
    (h : GoodPaths good Q prog) (hf : ∀ a, Q a → GoodPaths good R (f a)) :
    GoodPaths good R (prog.bind f) := by
  induction prog with
  | ret a => exact hf a h
  | draw p k ih => exact fun b hb => ih b (h b hb)

theorem GoodPaths.map {prog : DrawProg P β α} {f : α → γ} {R : γ → Prop}
    (h : GoodPaths good Q prog) (hf : ∀ a, Q a → R (f a)) : GoodPaths good R (prog.map f) :=
  h.bind fun a ha => hf a ha

theorem GoodPaths.and {prog : DrawProg P β α} (h₁ : GoodPaths good Q prog)
    (h₂ : GoodPaths good Q' prog) : GoodPaths good (fun a => Q a ∧ Q' a) prog := by
  induction prog with
  | ret a => exact ⟨h₁, h₂⟩
  | draw p k ih => exact fun b hb => ih b (h₁ b hb) (h₂ b hb)

/-- Universally quantified output predicates (e.g. over all admissible comparators). -/
theorem goodPaths_forall {ι : Sort*} {prog : DrawProg P β α} {Qi : ι → α → Prop}
    (h : ∀ i, GoodPaths good (Qi i) prog) : GoodPaths good (fun a => ∀ i, Qi i a) prog := by
  induction prog with
  | ret a => exact fun i => h i
  | draw p k ih => exact fun b hb => ih b fun i => h i b hb

/-- The outer measure of a PMF is at most `1`. -/
theorem pmf_toOuterMeasure_le_one {α : Type*} (p : PMF α) (s : Set α) : p.toOuterMeasure s ≤ 1 := by
  rw [PMF.toOuterMeasure_apply]
  exact (ENNReal.tsum_le_tsum fun x => Set.indicator_le_self s p x).trans (le_of_eq p.tsum_coe)

/-- **Bad-output probability.** If every draw is bad with probability at most `ε` and `prog` makes at most
`n` draws on every path, then the output violates `Q` with probability at most `n ε`. -/
theorem interp_bad_le (L : P → PMF β) {ε : ℝ≥0∞}
    (hL : ∀ p, (L p).toOuterMeasure {b | ¬ good p b} ≤ ε) {prog : DrawProg P β α} {n : ℕ}
    (hG : GoodPaths good Q prog) (hn : prog.DrawsLE n) :
    (interp L prog).toOuterMeasure {a | ¬ Q a} ≤ n * ε := by
  classical
  induction prog generalizing n with
  | ret a =>
    rw [interp_ret, PMF.toOuterMeasure_pure_apply, if_neg (fun h => h hG)]
    exact zero_le
  | draw p k ih =>
    cases n with
    | zero => simp [DrawsLE] at hn
    | succ m =>
      rw [interp_draw, PMF.toOuterMeasure_bind_apply]
      have hpt : ∀ b, L p b * (interp L (k b)).toOuterMeasure {a | ¬ Q a} ≤
          L p b * (m * ε) + {b | ¬ good p b}.indicator (L p) b := by
        intro b
        by_cases hb : good p b
        · rw [Set.indicator_of_notMem (by simpa using hb), add_zero]
          exact mul_le_mul' le_rfl (ih b (hG b hb) (hn b))
        · rw [Set.indicator_of_mem (by simpa using hb)]
          calc L p b * (interp L (k b)).toOuterMeasure {a | ¬ Q a} ≤ L p b * 1 :=
                mul_le_mul' le_rfl (pmf_toOuterMeasure_le_one _ _)
            _ = L p b := mul_one _
            _ ≤ L p b * (m * ε) + L p b := le_add_self
      calc ∑' b, L p b * (interp L (k b)).toOuterMeasure {a | ¬ Q a}
          ≤ ∑' b, (L p b * (m * ε) + {b | ¬ good p b}.indicator (L p) b) :=
            ENNReal.tsum_le_tsum hpt
        _ = (∑' b, L p b) * (m * ε) + (L p).toOuterMeasure {b | ¬ good p b} := by
            rw [ENNReal.tsum_add, ENNReal.tsum_mul_right, PMF.toOuterMeasure_apply]
        _ ≤ 1 * (m * ε) + ε := by rw [PMF.tsum_coe]; exact add_le_add le_rfl (hL p)
        _ = ((m + 1 : ℕ) : ℝ≥0∞) * ε := by push_cast; ring

/-- **Bad-output probability, bit implementation.** -/
theorem toBits_bad_le (s : P → BitProg β) {ε : ℝ≥0∞}
    (hs : ∀ p, (s p).law.toOuterMeasure {b | ¬ good p b} ≤ ε) {prog : DrawProg P β α} {n : ℕ}
    (hG : GoodPaths good Q prog) (hn : prog.DrawsLE n) :
    (toBits s prog).law.toOuterMeasure {a | ¬ Q a} ≤ n * ε := by
  rw [law_toBits]
  exact interp_bad_le _ hs hG hn

open Classical in
/-- **Bad-output probability on the uniform tapes of the specification**: the number of tapes
`ω : Fin c → Bool` (with `c` at least the number of bits read) on which the run violates `Q` is at most
`2^c n ε`. -/
theorem sum_tapes_bad_le (s : P → BitProg β) {ε : ℝ≥0∞}
    (hs : ∀ p, (s p).law.toOuterMeasure {b | ¬ good p b} ≤ ε) {prog : DrawProg P β α} {n c : ℕ}
    (hG : GoodPaths good Q prog) (hn : prog.DrawsLE n) (hc : (toBits s prog).depth ≤ c) :
    ∑ ω : Fin c → Bool, ((toBits s prog).run (List.ofFn ω)).elim 0
        (fun r => if Q r.1 then 0 else 1) ≤ 2 ^ c * (n * ε) := by
  refine (BitProg.sum_tapes_eq (toBits s prog) hc
    (fun a => if Q a then (0 : ℝ≥0∞) else 1)).trans_le ?_
  refine mul_le_mul' le_rfl ?_
  calc ∑' a, (toBits s prog).law a * (if Q a then 0 else 1)
      = (toBits s prog).law.toOuterMeasure {a | ¬ Q a} := by
        rw [PMF.toOuterMeasure_apply]
        refine tsum_congr fun a => ?_
        by_cases ha : Q a
        · simp [ha]
        · simp [ha]
    _ ≤ n * ε := toBits_bad_le s hs hG hn

end F2e2e.Discrete.DrawProg
