import F2e2e.B.PrivacyRefineDefs
import F2e2e.B.AccuracyBlocks
import F2e2e.B.ArchCoreSpec

/-!
# Block locality of the replica predictions

Paper: `parts/partII.tex` L1004–1008 (each stream reconstructs its scores from its own copy of the
selected block and the common protected-command history), L794–802 (Lemma
`R:lem:sec3_kkt_sensitivity`).

The replica reconstruction `replay P s hist` (`F2e2e/B/PrivacyRefineDefs.lean`) of the scores and
weights, and the predictions `recMus P s i = [μ_0, …, μ_p]` computed from it:

* `blockOff_succ`, `not_inBlock_of_ne`, `sampleBlock_withBlock_ne`: the blocks are disjoint;
* `blockUpd`, `corrScores_scores_getD`, `replay_scores_getD`: the block-`k` scores after the
  corrections `hist` only depend on the block-`k` values of the corrected queries;
* `replay_weights`: the weights are `capWeightsQ (scoreScale P)` of the scores;
* `recMus_getD`: `μ_k` from the block-`k` scores and values;
* `blockVals_valsOf`: the block-`k` values read block `k` of the sample;
* `recMus_getD_congr`: **block locality**: `μ_k` only depends on block `k` of the sample.
-/

namespace F2e2e.B.Priv

open F2e2e.B F2e2e.Discrete

variable {U : Type} (P : AdaParams)

/-! ## Blocks are disjoint -/

theorem blockOff_succ (j : ℕ) : blockOff P (j + 1) = blockOff P j + blockN P j := by
  unfold blockOff blockN
  by_cases h : j < P.blockSizes.length
  · rw [List.sum_take_succ _ _ h, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem h]
    rfl
  · rw [List.take_of_length_le (by omega), List.take_of_length_le (by omega),
      List.getD_eq_getElem?_getD, List.getElem?_eq_none (by omega)]
    simp

theorem blockOff_mono {j k : ℕ} (h : j ≤ k) : blockOff P j ≤ blockOff P k := by
  induction k, h using Nat.le_induction with
  | base => exact le_rfl
  | succ k _ ih => rw [blockOff_succ]; omega

theorem not_inBlock_of_ne {j k ℓ : ℕ} (hjk : j ≠ k) (hk : InBlock P k ℓ) : ¬ InBlock P j ℓ := by
  rintro ⟨hj1, hj2⟩
  obtain ⟨hk1, hk2⟩ := hk
  rcases Nat.lt_or_gt_of_ne hjk with h | h
  · have := blockOff_mono P (Nat.succ_le_of_lt h)
    rw [blockOff_succ] at this
    omega
  · have := blockOff_mono P (Nat.succ_le_of_lt h)
    rw [blockOff_succ] at this
    omega

theorem sampleBlock_withBlock_ne (s : Fin P.N → U) {j k : ℕ} (hjk : j ≠ k)
    (y : Fin (blockN P j) → U) : sampleBlock P (withBlock P s j y) k = sampleBlock P s k := by
  funext i
  simp only [sampleBlock, withBlock]
  rw [dif_neg (not_inBlock_of_ne P hjk ⟨Nat.le_add_right _ _, Nat.add_lt_add_left i.isLt _⟩)]

/-- Block neighbours agree on every other block. -/
theorem sampleBlock_eq_of_blockNeighbor {s s' : Fin P.N → U} {j k : ℕ} (h : BlockNeighbor P j s s')
    (hjk : j ≠ k) : sampleBlock P s k = sampleBlock P s' k := by
  obtain ⟨ℓ, hℓ, hne⟩ := h
  funext i
  apply hne
  intro he
  have hin : InBlock P k (blockOff P k + i) := ⟨Nat.le_add_right _ _, Nat.add_lt_add_left i.isLt _⟩
  have hv : blockOff P k + (i : ℕ) = (ℓ : ℕ) := congrArg Fin.val he
  rw [hv] at hin
  exact not_inBlock_of_ne P hjk hin hℓ

/-- Block neighbours differ in at most one coordinate of block `j`. -/
theorem sampleBlock_offOne_of_blockNeighbor {s s' : Fin P.N → U} {j : ℕ}
    (h : BlockNeighbor P j s s') :
    ∃ i₀ : Fin (blockN P j), ∀ i, i ≠ i₀ → sampleBlock P s j i = sampleBlock P s' j i := by
  obtain ⟨ℓ, hℓ, hne⟩ := h
  refine ⟨⟨ℓ - blockOff P j, by unfold InBlock at hℓ; omega⟩, fun i hi => hne _ fun he => hi ?_⟩
  ext
  have := congrArg Fin.val he
  simp only at this ⊢
  omega

/-- Replacing block `j` by two blocks differing in one coordinate gives block neighbours. -/
theorem blockNeighbor_withBlock (s : Fin P.N → U) {j : ℕ} {y y' : Fin (blockN P j) → U}
    (i₀ : Fin (blockN P j)) (h : ∀ i, i ≠ i₀ → y i = y' i) :
    BlockNeighbor P j (withBlock P s j y) (withBlock P s j y') := by
  refine ⟨⟨blockOff P j + i₀, blockOff_add_lt P j i₀⟩,
    ⟨Nat.le_add_right _ _, Nat.add_lt_add_left i₀.isLt _⟩, fun ℓ' hℓ' => ?_⟩
  simp only [withBlock]
  split_ifs with hb
  · apply h
    intro he
    apply hℓ'
    ext
    have := congrArg Fin.val he
    simp only at this ⊢
    omega
  · rfl

/-! ## Lists -/

theorem addScaled_nil (c : ℤ) (v : List ℕ) : addScaled [] c v = [] := by
  simp [addScaled]

theorem length_addScaled (g : List ℤ) (c : ℤ) (v : List ℕ) : (addScaled g c v).length = g.length := by
  simp [addScaled]

theorem getD_set_addScaled (l : List (List ℤ)) (i k : ℕ) (c : ℤ) (v : List ℕ) :
    (l.set i (addScaled (l.getD i []) c v)).getD k [] =
      if k = i then addScaled (l.getD k []) c v else l.getD k [] := by
  by_cases hki : k = i
  · subst hki
    rw [if_pos rfl]
    by_cases hlt : k < l.length
    · rw [List.getD_eq_getElem?_getD, List.getElem?_set_self hlt]
      rfl
    · rw [List.set_eq_of_length_le (by omega)]
      have h0 : l.getD k [] = [] := by
        rw [List.getD_eq_getElem?_getD, List.getElem?_eq_none (by omega)]
        rfl
      rw [h0, addScaled_nil]
  · rw [if_neg hki, List.getD_eq_getElem?_getD, List.getElem?_set_ne (Ne.symm hki),
      ← List.getD_eq_getElem?_getD]

theorem capWeightsQ_nil (c : ℚ) : capWeightsQ c [] = [] := by
  simp [capWeightsQ]

theorem getD_map_capWeightsQ (c : ℚ) (l : List (List ℤ)) (k : ℕ) :
    (l.map (capWeightsQ c)).getD k [] = capWeightsQ c (l.getD k []) := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getD_eq_getElem?_getD]
  cases l[k]? with
  | none => exact (capWeightsQ_nil c).symm
  | some g => rfl

/-! ## The block-`k` scores of the replica reconstruction -/

/-- The block-`k` scores after a correction on edge `j` with sign `q`, from the block-`k` scores `g`
and the block-`k` values `v` of the corrected query (`g_j += 4 q v_j`, `g_{j+1} −= q v_{j+1}`). -/
def blockUpd (k j : ℕ) (q : Bool) (g : List ℤ) (v : List ℕ) : List ℤ :=
  if k = j then addScaled g (4 * (if q then 1 else -1)) v
  else if k = j + 1 ∧ j + 1 < P.p then addScaled g (-(if q then 1 else -1)) v
  else g

theorem corrScores_scores_getD (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) (k : ℕ) :
    (corrScores P st vals j q).scores.getD k [] =
      blockUpd P k j q (st.scores.getD k []) (blockVals P vals k) := by
  have hg1 : ∀ k', (st.scores.set j (addScaled (st.scores.getD j []) (4 * (if q then 1 else -1))
      (blockVals P vals j))).getD k' [] =
      if k' = j then addScaled (st.scores.getD k' []) (4 * (if q then 1 else -1)) (blockVals P vals k')
      else st.scores.getD k' [] := by
    intro k'
    rw [getD_set_addScaled]
    by_cases h : k' = j
    · subst h
      rfl
    · rw [if_neg h, if_neg h]
  show List.getD (α := List ℤ) (if j + 1 < P.p then _ else _) k [] = _
  unfold blockUpd
  by_cases hp : j + 1 < P.p
  · rw [if_pos hp, getD_set_addScaled]
    simp only [hg1]
    by_cases hkj : k = j
    · subst hkj
      simp
    · by_cases hk1 : k = j + 1
      · subst hk1
        simp [hp]
      · simp [hkj, hk1]
  · rw [if_neg hp]
    simp only [hg1]
    by_cases hkj : k = j
    · subst hkj
      simp
    · simp [hkj, hp]

theorem corrScores_weights (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool)
    (hw : st.weights = st.scores.map (capWeightsQ (scoreScale P))) :
    (corrScores P st vals j q).weights =
      (corrScores P st vals j q).scores.map (capWeightsQ (scoreScale P)) := by
  simp only [corrScores]
  rw [hw]
  split_ifs <;> simp only [List.map_set]

theorem replay_weights (s : Fin P.N → U) (hist : List (ℕ × Bool × (U → ℕ))) :
    (replay P s hist).weights = (replay P s hist).scores.map (capWeightsQ (scoreScale P)) := by
  unfold replay
  have h0 : (adaInitState P [] 0).weights =
      (adaInitState P [] 0).scores.map (capWeightsQ (scoreScale P)) := by
    simp only [adaInitState, List.map_map]
    rfl
  generalize adaInitState P [] 0 = st0 at h0
  induction hist generalizing st0 with
  | nil => exact h0
  | cons c hist ih =>
    simp only [List.foldl_cons]
    exact ih _ (corrScores_weights P _ _ _ _ h0)

theorem replay_scores_getD (s : Fin P.N → U) (hist : List (ℕ × Bool × (U → ℕ))) (k : ℕ) :
    (replay P s hist).scores.getD k [] =
      hist.foldl (fun g c => blockUpd P k c.1 c.2.1 g (blockVals P (valsOf P s c.2.2) k))
        ((adaInitState P [] 0).scores.getD k []) := by
  unfold replay
  generalize adaInitState P [] 0 = st0
  induction hist generalizing st0 with
  | nil => rfl
  | cons c hist ih =>
    simp only [List.foldl_cons]
    rw [ih, corrScores_scores_getD]

/-- The weights of block `k` of the replica reconstruction. -/
theorem replay_weights_getD (s : Fin P.N → U) (hist : List (ℕ × Bool × (U → ℕ))) (k : ℕ) :
    (replay P s hist).weights.getD k [] =
      capWeightsQ (scoreScale P) ((replay P s hist).scores.getD k []) := by
  rw [replay_weights, getD_map_capWeightsQ]

/-- `μ_k` of the replica reconstruction. -/
theorem recMus_getD (s : Fin P.N → U) (i : CInfo U) (k : ℕ) :
    (recMus P s i).getD k 0 =
      if k < P.p then
        predLearned P.hA (capWeightsQ (scoreScale P) ((replay P s i.hist).scores.getD k []))
          (blockVals P (valsOf P s i.f) k)
      else if k = P.p then predAnchor P.hA (P.blockSizes.getD k 0) (blockVals P (valsOf P s i.f) k)
      else 0 := by
  unfold recMus adaMus
  rw [List.getD_eq_getElem?_getD, List.getElem?_map]
  by_cases hk : k < P.p + 1
  · rw [List.getElem?_range hk]
    simp only [Option.map_some, Option.getD_some]
    rw [replay_weights_getD]
    by_cases hkp : k < P.p
    · rw [if_pos hkp, if_pos hkp]
    · rw [if_neg hkp, if_neg hkp, if_pos (by omega)]
  · rw [List.getElem?_eq_none (by rw [List.length_range]; omega : (List.range (P.p + 1)).length ≤ k)]
    simp only [Option.map_none, Option.getD_none]
    rw [if_neg (by omega), if_neg (by omega)]

/-! ## Block values -/

/-- The block-`k` values of a query read block `k` of the sample (clipped grid indices). -/
theorem blockVals_valsOf (s : Fin P.N → U) (f : U → ℕ) (k : ℕ) :
    blockVals P (valsOf P s f) k =
      List.ofFn (fun i : Fin (blockN P k) => min (f (sampleBlock P s k i)) (2 ^ P.qA)) := by
  unfold blockVals
  rw [show valsOf P s f = coreVals P s ⟨f, true, 0, 0⟩ from rfl, coreVals_getD, List.map_ofFn]
  rfl

theorem blockVals_valsOf_congr {s s' : Fin P.N → U} {k : ℕ}
    (h : sampleBlock P s k = sampleBlock P s' k) (f : U → ℕ) :
    blockVals P (valsOf P s f) k = blockVals P (valsOf P s' f) k := by
  rw [blockVals_valsOf, blockVals_valsOf, h]

/-- **Block locality**: `μ_k` of the replica reconstruction only depends on block `k` of the
sample. -/
theorem recMus_getD_congr {s s' : Fin P.N → U} {k : ℕ} (h : sampleBlock P s k = sampleBlock P s' k)
    (i : CInfo U) : (recMus P s i).getD k 0 = (recMus P s' i).getD k 0 := by
  simp only [recMus_getD, replay_scores_getD, blockVals_valsOf_congr P h]

/-- Block locality for a replaced block: `μ_k`, `k ≠ j`, does not see block `j`. -/
theorem recMus_getD_withBlock (s : Fin P.N → U) {j k : ℕ} (hjk : j ≠ k)
    (y y' : Fin (blockN P j) → U) (i : CInfo U) :
    (recMus P (withBlock P s j y) i).getD k 0 = (recMus P (withBlock P s j y') i).getD k 0 :=
  recMus_getD_congr P (by rw [sampleBlock_withBlock_ne P s hjk, sampleBlock_withBlock_ne P s hjk])
    i

end F2e2e.B.Priv
