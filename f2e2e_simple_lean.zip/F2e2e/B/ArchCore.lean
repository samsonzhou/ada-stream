import F2e2e.B.ArchParams
import F2e2e.Lib.Discrete.Sampler

/-!
# Algorithm `R:alg:sec3_validation_ada` (Algorithm 2): the computable core state machine

`parts/partII.tex` L737–777 (Definition `R:def:sec3_capped_learners`, the implementation conventions
of L750, Algorithm 2), with the bounded lattice sampler of L708–717.

The mechanism is written **once**, as a program with adaptive lattice-noise draws
(`NoiseProg = DrawProg NoiseKind ℤ`, LIB-DISCRETE): a draw with parameter `κ` (the kind of noise, of
scale `P.scale κ`) returns a lattice index `k ∈ ℤ`, the noise being `h_A k`. Two interpretations:
* the **actual** mechanism replaces each draw by the bounded sampler of L708–716 reading fresh fair
  bits (`DrawProg.toBits (adaDraw P)`, a `BitProg`; this is what runs);
* the **ideal** mechanism replaces each draw of kind `κ` by the exact lattice law
  `latticeLaw (b/(b + h_A))`, `b = P.scale κ` (`DrawProg.interp`), used by the privacy analysis; the
  coupling (P4) is `DrawProg.tv_toBits_le`.

Everything is exact integer/rational arithmetic on grid indices (L750: "Query evaluations are rounded
to `h_A`, and interval endpoints are monotonically clipped to `[−1, 2]` and rounded to the same grid"):
* a query is given block by block by its grid indices `vals[j][i] = f̂(X_{j,i})/h_A ∈ [0, 2^{qA}]`
  (clipped to that range inside);
* learned scores are integers `g_{j,i} = 4 G_{j,i}/h_A` (`G ∈ (h_A/4)ℤ`), the exact weights
  `w_j = argmax_{W_j}{κ⟨G_j, w⟩ − R_j(w)}` are rationals computed by exact water-filling
  (`capWeightsQ`, Lemma `R:lem:sec3_kkt_sensitivity` (i), (iii));
* thresholds and test noises are lattice indices.

Request caps (refuse and continue, `STATEMENT_REVIEW.md` B.3.2) are enforced inside the core: an
interval request beyond the first `M`, a numerical request beyond the first `R`, or any request after
halting returns `abort` with no data access, no draws and no state change.

Semantics of the scan (lines [4]–[10]): a `PrepareRoot` call performs at most `fuel = 1 + ∑_j T_j^max`
scan passes; a pass visits the edges `0, …, p−1` in order, skips cached edges, tests uncached ones;
an acceptance caches the edge; a crossing applies the correction (or `CAP_ABORT` if
`T_j = T_j^max`), reopens the internal phases incident to the updated blocks, invalidates their cache
bits and restarts the scan ("restart the scan at zero"); a pass without crossing finishes.
-/

namespace F2e2e.B

open F2e2e.Discrete

/-! ## Exact rational helpers -/

/-- `clip_{[lo,hi]}(x) = max lo (min hi x)`. -/
def clipQ (lo hi x : ℚ) : ℚ := max lo (min hi x)

/-- The grid index of `round_h(z) = h ⌊z/h + 1/2⌋` (`R:def:dyadic-normalization`; ties toward `+∞`). -/
def roundIdxQ (h z : ℚ) : ℤ := ⌊z / h + 1 / 2⌋

/-! ## Learner weights: exact water-filling on the `8/n`-capped simplex

Lemma `R:lem:sec3_kkt_sensitivity` (i): `w_i = clip_{[0,8]}(s_i − ν)/n` with `s_i = 1 + κ G_i` and
the water level `ν` solving `Φ(ν) := ∑_i clip_{[0,8]}(s_i − ν) = n`. `Φ` is continuous,
non-increasing and piecewise linear with breakpoints `{s_i} ∪ {s_i − 8}`. The candidate levels are
the breakpoints `b` and, for each breakpoint with `k_b = #{i : s_i − 8 ≤ b < s_i} ≠ 0`, the
interpolated level `b + (Φ(b) − n)/k_b`; `wfLevel` returns the first candidate with `Φ(ν) = n`
(exact rational check). Some candidate always passes (the largest breakpoint `b*` with `Φ(b*) ≥ n`:
`Φ` is affine with slope `−k_{b*}` up to the next breakpoint), so `capWeightsQ` equals the learner
weights (`capWeightsQ_spec` in `F2e2e/B/ArchCoreSpec.lean`, owned by LIB-OPT-QUAD). O(n²) exact
operations, first-order loops over lists. -/

/-- `Φ(ν) = ∑_i clip_{[0,8]}(s_i − ν)`. -/
def wfMass (s : List ℚ) (ν : ℚ) : ℚ := (s.map fun x => clipQ 0 8 (x - ν)).sum

/-- The breakpoints `{s_i} ∪ {s_i − 8}` of `Φ`. -/
def wfBreaks (s : List ℚ) : List ℚ := s ++ s.map (· - 8)

/-- The slope count `k_b = #{i : s_i − 8 ≤ b < s_i}` of `Φ` just right of `b`. -/
def wfSlope (s : List ℚ) (b : ℚ) : ℕ := (s.filter fun x => decide (x - 8 ≤ b ∧ b < x)).length

/-- The candidate water levels: the breakpoints, then the interpolated levels
`b + (Φ(b) − n)/k_b` (`k_b ≠ 0`), `n = s.length`. -/
def wfCands (s : List ℚ) : List ℚ :=
  wfBreaks s ++ (wfBreaks s).filterMap fun b =>
    if wfSlope s b = 0 then none else some (b + (wfMass s b - s.length) / wfSlope s b)

/-- The exact water level: the first candidate `ν` with `Φ(ν) = n`, `n = s.length` (`0` if none,
which does not happen for nonempty `s`). -/
def wfLevel (s : List ℚ) : ℚ := ((wfCands s).find? fun ν => decide (wfMass s ν = s.length)).getD 0

/-- The exact learner weights `w_j(G_j) = argmax_{w ∈ W_j}{κ⟨G_j, w⟩ − R_j(w)}` for integer scores
`g` with `κ G = c g`: `w_i = clip_{[0,8]}(1 + c g_i − ν)/n`. -/
def capWeightsQ (c : ℚ) (g : List ℤ) : List ℚ :=
  let s := g.map fun gi : ℤ => 1 + c * (gi : ℚ)
  let ν := wfLevel s
  s.map fun x => clipQ 0 8 (x - ν) / s.length

/-! ## State and outputs -/

/-- The state of Algorithm 2 (line [1]) plus its counters. -/
structure AdaState where
  /-- integer scores `g_{j,i} = 4 G_{j,i}/h_A` of the learned blocks `j < p` -/
  scores : List (List ℤ)
  /-- the exact weights `w_j = capWeightsQ (κ h_A/4) g_j` of the learned blocks `j < p` -/
  weights : List (List ℚ)
  /-- corrections `T_j` applied on edge `j < p` -/
  T : List ℕ
  /-- lattice indices of the persistent thresholds `ϑ̂_int,j` of the open internal phases -/
  thrInt : List ℤ
  /-- lattice index of the persistent threshold `ϑ̂_out` of the open outer phase -/
  thrOut : ℤ
  /-- rejections returned so far -/
  rej : ℕ
  /-- interval requests processed (at most `M`) -/
  nInt : ℕ
  /-- numerical requests processed (at most `R`) -/
  nNum : ℕ
  /-- halted (terminal `(J+1)`-st rejection or `CAP_ABORT`) -/
  halted : Bool
  /-- an internal correction cap was exhausted (`CAP_ABORT`, line [7]) -/
  capAborted : Bool

/-- Certificates returned by the interval interface (lines [11]–[15]). -/
inductive AdaCert where
  | accept : AdaCert
  | high : AdaCert
  | low : AdaCert
  /-- the `(J+1)`-st rejection: `HIGH` with `TERMINAL_REJECT` -/
  | termHigh : AdaCert
  /-- the `(J+1)`-st rejection: `LOW` with `TERMINAL_REJECT` -/
  | termLow : AdaCert
  /-- `CAP_ABORT`, an exceeded request cap, or a call after halting -/
  | abort : AdaCert
  deriving DecidableEq, Repr

/-- Outputs of the numerical interface (lines [16]–[18]). -/
inductive AdaNum where
  /-- the protected value `μ̂ ∈ [0, 1] ∩ h_A ℤ` -/
  | val : ℚ → AdaNum
  /-- `CAP_ABORT`, an exceeded request cap, or a call after halting -/
  | abort : AdaNum
  deriving DecidableEq, Repr

/-! ## Programs with lattice-noise draws -/

/-- Programs of the core: adaptive draws with parameter the noise kind `κ : NoiseKind` (of scale
`P.scale κ`), outcome the lattice index `k : ℤ` (the noise is `h_A k`). -/
abbrev NoiseProg := DrawProg NoiseKind ℤ

/-- One fresh lattice noise of kind `κ`. -/
def drawNoise (κ : NoiseKind) : NoiseProg ℤ := DrawProg.draw κ DrawProg.ret

/-- `n` fresh lattice noises of kind `κ`. -/
def drawList (κ : NoiseKind) : ℕ → NoiseProg (List ℤ)
  | 0 => DrawProg.ret []
  | n + 1 => (drawNoise κ).bind fun z => (drawList κ n).map (z :: ·)

/-! ## Predictions -/

/-- Block `j`'s grid indices, clipped to `[0, 2^{qA}]` (i.e. `f̂ ∈ [0, 1]`). -/
def blockVals (P : AdaParams) (vals : List (List ℕ)) (j : ℕ) : List ℕ :=
  (vals.getD j []).map fun x => min x (2 ^ P.qA)

/-- A learned block's prediction `μ_j = ⟨w_j, f̂(S_j)⟩ = h_A ∑_i w_{j,i} v_{j,i}`. -/
def predLearned (hA : ℚ) (w : List ℚ) (v : List ℕ) : ℚ :=
  hA * (List.zipWith (fun (wi : ℚ) (vi : ℕ) => wi * (vi : ℚ)) w v).sum

/-- The anchor's prediction `μ_p = (1/n_p) ∑_i f̂(X_{p,i}) = h_A (∑_i v_{p,i})/n_p`. -/
def predAnchor (hA : ℚ) (np : ℕ) (v : List ℕ) : ℚ := hA * ((v.map fun x => (x : ℚ)).sum / np)

/-- The current predictions `[μ_0, …, μ_p]` (line [3]). -/
def adaMus (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) : List ℚ :=
  (List.range (P.p + 1)).map fun j =>
    if j < P.p then predLearned P.hA (st.weights.getD j []) (blockVals P vals j)
    else predAnchor P.hA (P.blockSizes.getD j 0) (blockVals P vals j)

/-! ## `PrepareRoot` (lines [2]–[10]) -/

/-- The internal test of edge `j` (lines [5]–[7]) with fresh directed noises `ν₊, ν₋` of scale
`4 b_int`: `none` = accepted (both `μ_{j+1} − μ_j + ν₊` and `μ_j − μ_{j+1} + ν₋` are below
`τ + ϑ̂_int,j`); otherwise the crossing sign, the positive branch having priority
(`some true` = `q = +1`, `some false` = `q = −1`). -/
def edgeTest (P : AdaParams) (st : AdaState) (mus : List ℚ) (j : ℕ) : NoiseProg (Option Bool) :=
  (drawNoise NoiseKind.intTest).bind fun kp =>
  (drawNoise NoiseKind.intTest).bind fun km =>
    let gap := mus.getD (j + 1) 0 - mus.getD j 0
    let thr := P.tau + P.hA * (st.thrInt.getD j 0 : ℚ)
    DrawProg.ret
      (if thr ≤ gap + P.hA * (kp : ℚ) then some true
       else if thr ≤ -gap + P.hA * (km : ℚ) then some false
       else none)

/-- `g ← g + c v` coordinatewise (the length of `g` is preserved). -/
def addScaled (g : List ℤ) (c : ℤ) (v : List ℕ) : List ℤ :=
  g.mapIdx fun i gi => gi + c * (v.getD i 0 : ℤ)

/-- The internal phases reopened by a correction on edge `j` (line [9]): the edges incident to the
updated blocks `j` and (unless it is the anchor) `j + 1`, i.e. `{j−1, j, j+1} ∩ [0, p−1]`. -/
def reopenEdges (P : AdaParams) (j : ℕ) : List ℕ :=
  (if 1 ≤ j then [j - 1] else []) ++ [j] ++ (if j + 1 < P.p then [j + 1] else [])

/-- Fresh persistent thresholds `ϑ̂_int,e` (scale `2 b_int`) for the edges `es`, in order. -/
def redrawThresholds (P : AdaParams) : List ℕ → List ℤ → NoiseProg (List ℤ)
  | [], thr => DrawProg.ret thr
  | e :: es, thr => (drawNoise NoiseKind.intThr).bind fun k => redrawThresholds P es (thr.set e k)

/-- The factor `κ h_A/4` with `κ G = (κ h_A/4) g` for the integer scores `g = 4G/h_A`. -/
def scoreScale (P : AdaParams) : ℚ := P.kappa * P.hA / 4

/-- A correction on edge `j` with sign `q` (lines [8]–[9]): `G_j ← G_j + q f̂(S_j)` and
`G_{j+1} ← G_{j+1} − (q/4) f̂(S_{j+1})` (omitted at the anchor `j + 1 = p`), i.e.
`g_j += 4 q v_j`, `g_{j+1} −= q v_{j+1}`; the modified weights are recomputed exactly, `T_j` is
incremented, and every internal phase incident to an updated block is closed and reopened with a
fresh threshold. -/
def applyCorrection (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    NoiseProg AdaState :=
  let qz : ℤ := if q then 1 else -1
  let gj := addScaled (st.scores.getD j []) (4 * qz) (blockVals P vals j)
  let g1 := st.scores.set j gj
  let w1 := st.weights.set j (capWeightsQ (scoreScale P) gj)
  let gj1 := addScaled (g1.getD (j + 1) []) (-qz) (blockVals P vals (j + 1))
  let g2 := if j + 1 < P.p then g1.set (j + 1) gj1 else g1
  let w2 := if j + 1 < P.p then w1.set (j + 1) (capWeightsQ (scoreScale P) gj1) else w1
  (redrawThresholds P (reopenEdges P j) st.thrInt).bind fun thr =>
    DrawProg.ret
      { st with scores := g2, weights := w2, T := st.T.set j (st.T.getD j 0 + 1), thrInt := thr }

/-- Outcome of one scan pass. -/
inductive PassOut where
  /-- every edge accepted: `PrepareRoot` finishes -/
  | done : PassOut
  /-- a correction was applied: restart the scan at edge zero -/
  | corrected : PassOut
  /-- `CAP_ABORT` -/
  | abort : PassOut
  deriving DecidableEq

/-- One scan pass over the edges `es` (in increasing order) with the predictions `mus` of the
current state; the cache bits mark accepted edges. -/
def scanPass (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    List ℕ → AdaState → List Bool → NoiseProg (PassOut × AdaState × List Bool)
  | [], st, cache => DrawProg.ret (PassOut.done, st, cache)
  | j :: es, st, cache =>
    if cache.getD j false = true then scanPass P vals mus es st cache
    else (edgeTest P st mus j).bind fun r =>
      match r with
      | none => scanPass P vals mus es st (cache.set j true)
      | some q =>
        if P.Tmax.getD j 0 ≤ st.T.getD j 0 then DrawProg.ret (PassOut.abort, st, cache)
        else (applyCorrection P st vals j q).bind fun st' =>
          DrawProg.ret
            (PassOut.corrected, st', (reopenEdges P j).foldl (fun c e => c.set e false) cache)

/-- `PrepareRoot(f)` with at most `fuel` scan passes, starting from the cache bits `cache`; `none` is
`CAP_ABORT` (or an exhausted pass budget, impossible for `fuel = 1 + ∑_j T_j^max`; it is also
recorded as `CAP_ABORT`). -/
def prepareRoot (P : AdaParams) (vals : List (List ℕ)) :
    ℕ → AdaState → List Bool → NoiseProg (Option AdaState)
  | 0, _, _ => DrawProg.ret none
  | fuel + 1, st, cache =>
    (scanPass P vals (adaMus P st vals) (List.range P.p) st cache).bind fun r =>
      match r.1 with
      | PassOut.done => DrawProg.ret (some r.2.1)
      | PassOut.corrected => prepareRoot P vals fuel r.2.1 r.2.2
      | PassOut.abort => DrawProg.ret none

/-! ## `Interval` (lines [11]–[15]) and `Numerical` (lines [16]–[18]) -/

/-- An outer rejection (line [15]): the `(J+1)`-st rejection is terminal and halts; otherwise a new
outer phase is opened with a fresh threshold (scale `2 b_out`). -/
def outerReject (P : AdaParams) (st : AdaState) (high : Bool) : NoiseProg (AdaCert × AdaState) :=
  if P.J + 1 ≤ st.rej + 1 then
    DrawProg.ret (if high then AdaCert.termHigh else AdaCert.termLow,
      { st with rej := st.rej + 1, halted := true })
  else (drawNoise NoiseKind.outThr).bind fun k =>
    DrawProg.ret (if high then AdaCert.high else AdaCert.low,
      { st with rej := st.rej + 1, thrOut := k })

/-- `Interval(f, [l, u])` (lines [11]–[15]), noise-draw form: enforce the cap `M` (and halting), run
`PrepareRoot`, then test `μ_0 − ũ` (HIGH branch, priority) and `l̃ − μ_0` (LOW branch) with fresh
directed noises of scale `4 b_out` against `a/2 + ϑ̂_out`, where `l̃, ũ` are the endpoints clipped
to `[−1, 2]` and rounded to `h_A ℤ`. -/
def adaIntervalD (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    NoiseProg (AdaCert × AdaState) :=
  if st.halted = true ∨ P.M ≤ st.nInt then DrawProg.ret (AdaCert.abort, st)
  else
    (prepareRoot P vals P.fuel { st with nInt := st.nInt + 1 } (List.replicate P.p false)).bind
      fun r =>
      match r with
      | none =>
        DrawProg.ret (AdaCert.abort,
          { st with nInt := st.nInt + 1, halted := true, capAborted := true })
      | some st2 =>
        let μ0 := (adaMus P st2 vals).getD 0 0
        let lt := P.hA * (roundIdxQ P.hA (clipQ (-1) 2 l) : ℚ)
        let ut := P.hA * (roundIdxQ P.hA (clipQ (-1) 2 u) : ℚ)
        let thr := P.a / 2 + P.hA * (st2.thrOut : ℚ)
        (drawNoise NoiseKind.outTest).bind fun kH =>
        (drawNoise NoiseKind.outTest).bind fun kL =>
          if thr ≤ μ0 - ut + P.hA * (kH : ℚ) then outerReject P st2 true
          else if thr ≤ lt - μ0 + P.hA * (kL : ℚ) then outerReject P st2 false
          else DrawProg.ret (AdaCert.accept, st2)

/-- `Numerical(f)` (lines [16]–[18]), noise-draw form: enforce the cap `R` (and halting), run
`PrepareRoot`, draw `Z = h_A k` of scale `b_num` and return `clip_{[0,1]} round_{h_A}(μ_0 + Z)`. -/
def adaNumericalD (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    NoiseProg (AdaNum × AdaState) :=
  if st.halted = true ∨ P.R ≤ st.nNum then DrawProg.ret (AdaNum.abort, st)
  else
    (prepareRoot P vals P.fuel { st with nNum := st.nNum + 1 } (List.replicate P.p false)).bind
      fun r =>
      match r with
      | none =>
        DrawProg.ret (AdaNum.abort,
          { st with nNum := st.nNum + 1, halted := true, capAborted := true })
      | some st2 =>
        let μ0 := (adaMus P st2 vals).getD 0 0
        (drawNoise NoiseKind.num).bind fun k =>
          DrawProg.ret
            (AdaNum.val (clipQ 0 1 (P.hA * (roundIdxQ P.hA (μ0 + P.hA * (k : ℚ)) : ℚ))), st2)

/-! ## Initialization -/

/-- The initial state: zero scores, uniform weights (`capWeightsQ` of zero scores), no corrections,
the given initial thresholds, no requests, not halted. -/
def adaInitState (P : AdaParams) (thr : List ℤ) (ko : ℤ) : AdaState where
  scores := (P.blockSizes.take P.p).map fun nj => List.replicate nj 0
  weights := (P.blockSizes.take P.p).map fun nj => capWeightsQ (scoreScale P) (List.replicate nj 0)
  T := List.replicate P.p 0
  thrInt := thr
  thrOut := ko
  rej := 0
  nInt := 0
  nNum := 0
  halted := false
  capAborted := false

/-- Initialization, noise-draw form: the initial internal thresholds (`p` draws of scale `2 b_int`)
and the initial outer threshold (scale `2 b_out`). -/
def adaInitD (P : AdaParams) : NoiseProg AdaState :=
  (drawList NoiseKind.intThr P.p).bind fun thr =>
  (drawNoise NoiseKind.outThr).bind fun ko => DrawProg.ret (adaInitState P thr ko)

/-! ## The actual mechanism: fresh fair bits via the bounded lattice sampler -/

/-- The bounded lattice sampler (L708–716) for a draw of kind `κ`, of scale `b = P.scale κ`:
`ϱ = b/(b + h_A) = A/D_ϱ` in lowest terms, at most `r_s` rejection trials per coin, counts capped at
`K_s`. -/
def adaDraw (P : AdaParams) (κ : NoiseKind) : BitProg ℤ :=
  latticeSampler (P.rho (P.scale κ)).num.toNat (P.rho (P.scale κ)).den (P.rs (P.scale κ))
    (P.Ks (P.scale κ))

/-- A fresh mechanism instance (scores zero, uniform weights, initial thresholds drawn with the
bounded lattice sampler). -/
def adaInit (P : AdaParams) : BitProg AdaState := (adaInitD P).toBits (adaDraw P)

/-- `Interval(f, [l, u])` on the grid indices `vals[j][i] = f̂(X_{j,i})/h_A` of the blocks
`S_0, …, S_p`, reading fresh fair bits. -/
def adaInterval (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    BitProg (AdaCert × AdaState) :=
  (adaIntervalD P st vals l u).toBits (adaDraw P)

/-- `Numerical(f)` on the grid indices of the blocks, reading fresh fair bits. -/
def adaNumerical (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    BitProg (AdaNum × AdaState) :=
  (adaNumericalD P st vals).toBits (adaDraw P)

/-- Worst-case number of fresh bits read by `adaInit`: `p + 1` draws. -/
def adaInitBits (P : AdaParams) : ℕ := (P.p + 1) * P.maxDrawBits

/-- Worst-case number of fresh bits read by one `adaInterval` or `adaNumerical` call, uniformly over
all states and inputs: at most `fuel` passes of at most `p` tests (two draws each) and one correction
(at most three threshold draws), then at most three outer/numerical draws. -/
def adaCallBits (P : AdaParams) : ℕ := (P.fuel * (2 * P.p + 3) + 3) * P.maxDrawBits

/-! ## Draw counts and fresh-bit bounds (P1 of Theorem 3.6, per call)

Every call makes at most `fuel · (2p + 3) + 3` draws: at most `fuel` scan passes, each with at most
`p` edge tests (two draws) and at most one correction (at most three threshold redraws), then at most
three outer/numerical draws; initialization makes `p + 1` draws. Each draw reads at most
`maxDrawBits` fresh bits (`Discrete.depth_latticeSampler_le`). -/

theorem drawsLE_ret {α : Type} (a : α) (n : ℕ) : (DrawProg.ret a : NoiseProg α).DrawsLE n := by
  cases n <;> trivial

theorem drawNoise_drawsLE (κ : NoiseKind) : (drawNoise κ).DrawsLE 1 := by
  intro b; trivial

theorem drawList_drawsLE (κ : NoiseKind) : ∀ n, (drawList κ n).DrawsLE n
  | 0 => trivial
  | n + 1 => by
    have h := (drawNoise_drawsLE κ).bind (fun z => (drawList_drawsLE κ n).map (z :: ·))
    exact h.mono (by omega)

theorem edgeTest_drawsLE (P : AdaParams) (st : AdaState) (mus : List ℚ) (j : ℕ) :
    (edgeTest P st mus j).DrawsLE 2 :=
  (drawNoise_drawsLE _).bind fun _ => (drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0

theorem redrawThresholds_drawsLE (P : AdaParams) :
    ∀ (es : List ℕ) (thr : List ℤ), (redrawThresholds P es thr).DrawsLE es.length
  | [], _ => trivial
  | e :: es, thr => by
    have h := (drawNoise_drawsLE NoiseKind.intThr).bind
      (fun k => redrawThresholds_drawsLE P es (thr.set e k))
    exact h.mono (by simp only [List.length_cons]; omega)

theorem reopenEdges_length_le (P : AdaParams) (j : ℕ) : (reopenEdges P j).length ≤ 3 := by
  unfold reopenEdges
  split_ifs <;> simp

theorem applyCorrection_drawsLE (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ)
    (q : Bool) : (applyCorrection P st vals j q).DrawsLE 3 := by
  unfold applyCorrection
  exact ((redrawThresholds_drawsLE P (reopenEdges P j) st.thrInt).bind
    fun _ => drawsLE_ret _ 0).mono (by have := reopenEdges_length_le P j; omega)

theorem scanPass_drawsLE (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool),
      (scanPass P vals mus es st cache).DrawsLE (2 * es.length + 3)
  | [], _, _ => trivial
  | j :: es, st, cache => by
    unfold scanPass
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact (scanPass_drawsLE P vals mus es st cache).mono (by simp only [List.length_cons]; omega)
    · rw [if_neg hc]
      refine ((edgeTest_drawsLE P st mus j).bind (n := 2 * es.length + 3) fun r => ?_).mono
        (by simp only [List.length_cons]; omega)
      rcases r with _ | q
      · exact scanPass_drawsLE P vals mus es st _
      · dsimp only
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hT]; exact drawsLE_ret _ _
        · rw [if_neg hT]
          exact ((applyCorrection_drawsLE P st vals j q).bind fun _ => drawsLE_ret _ 0).mono
            (by omega)

theorem prepareRoot_drawsLE (P : AdaParams) (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool),
      (prepareRoot P vals fuel st cache).DrawsLE (fuel * (2 * P.p + 3))
  | 0, _, _ => trivial
  | fuel + 1, st, cache => by
    unfold prepareRoot
    have hs := scanPass_drawsLE P vals (adaMus P st vals) (List.range P.p) st cache
    rw [List.length_range] at hs
    refine (hs.bind (n := fuel * (2 * P.p + 3)) fun r => ?_).mono (by ring_nf; omega)
    rcases r with ⟨o, st', cache'⟩
    cases o
    · exact drawsLE_ret _ _
    · exact prepareRoot_drawsLE P vals fuel st' cache'
    · exact drawsLE_ret _ _

theorem outerReject_drawsLE (P : AdaParams) (st : AdaState) (high : Bool) :
    (outerReject P st high).DrawsLE 1 := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]; exact drawsLE_ret _ _
  · rw [if_neg hJ]; exact (drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0

theorem adaIntervalD_drawsLE (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    (adaIntervalD P st vals l u).DrawsLE (P.fuel * (2 * P.p + 3) + 3) := by
  unfold adaIntervalD
  split_ifs
  · exact drawsLE_ret _ _
  · refine (prepareRoot_drawsLE P vals P.fuel _ _).bind (n := 3) fun r => ?_
    rcases r with _ | st2
    · exact drawsLE_ret _ _
    · dsimp only
      refine ((drawNoise_drawsLE _).bind (n := 2) fun kH =>
        ((drawNoise_drawsLE _).bind (n := 1) fun kL => ?_)).mono (by omega)
      split_ifs
      · exact outerReject_drawsLE P st2 true
      · exact outerReject_drawsLE P st2 false
      · exact drawsLE_ret _ _

theorem adaNumericalD_drawsLE (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    (adaNumericalD P st vals).DrawsLE (P.fuel * (2 * P.p + 3) + 3) := by
  unfold adaNumericalD
  split_ifs
  · exact drawsLE_ret _ _
  · refine (prepareRoot_drawsLE P vals P.fuel _ _).bind (n := 3) fun r => ?_
    rcases r with _ | st2
    · exact drawsLE_ret _ _
    · dsimp only
      exact ((drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0).mono (by omega)

theorem adaInitD_drawsLE (P : AdaParams) : (adaInitD P).DrawsLE (P.p + 1) := by
  unfold adaInitD
  exact (drawList_drawsLE _ P.p).bind fun _ => (drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0

theorem adaDraw_depth_le (P : AdaParams) (κ : NoiseKind) : (adaDraw P κ).depth ≤ P.maxDrawBits := by
  have h2 : (adaDraw P κ).depth ≤ P.drawBits (P.scale κ) :=
    depth_latticeSampler_le (P.rho (P.scale κ)).num.toNat (P.rho (P.scale κ)).den
      (P.rs (P.scale κ)) (P.Ks (P.scale κ))
  refine h2.trans ?_
  unfold AdaParams.maxDrawBits
  cases κ <;> omega

theorem adaInit_depth_le (P : AdaParams) : (adaInit P).depth ≤ adaInitBits P :=
  DrawProg.depth_toBits_le (adaDraw P) (adaDraw_depth_le P) (adaInitD_drawsLE P)

theorem adaInterval_depth_le (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    (adaInterval P st vals l u).depth ≤ adaCallBits P :=
  DrawProg.depth_toBits_le (adaDraw P) (adaDraw_depth_le P) (adaIntervalD_drawsLE P st vals l u)

theorem adaNumerical_depth_le (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    (adaNumerical P st vals).depth ≤ adaCallBits P :=
  DrawProg.depth_toBits_le (adaDraw P) (adaDraw_depth_le P) (adaNumericalD_drawsLE P st vals)

end F2e2e.B
