import F2e2e.B.PrivacyRefineDefs

/-!
# Phase-start counts of the skeleton of Algorithm 2 ((P1) of the privacy analysis)

Paper: `parts/partII.tex` L986–1008 (the per-stream phase counts `C_j`), Algorithm 2 (L752–777).

A phase of a stream starts at each `reopen` or `release` call (`SQuery.isStart`). We bound the
number of phase starts of every stream of `skRunD P ctrl T` on every path:
* `skRunD_startsLE_edge`: edge `e` is reopened once at initialization and once per correction on an
  edge `j ∈ {e-1, e, e+1}`; the corrections on `j` are capped by `T_j^max` (`P.Tmax.getD j 0`);
* `skRunD_startsLE_outer`: the outer phase is opened once at initialization and once per
  non-terminal rejection (at most `J`);
* `skRunD_startsLE_num`: one release per numerical request passing the cap check (at most `R`).

Technique: the budgeted predicate `OProg.StartsPost s Q E n` (on every path, at most `n` starts of
`s`, and the returned value satisfies `Q` for the remaining budget), with a bind rule; the budgets are
`callB P s sk` (remaining correction budget of the neighbouring edges for an edge stream, `J - rej`
for the outer stream, `R - nNum` for the numerical stream; `0` once halted).
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

/-! ## A budgeted phase-start predicate -/

/-- `E.StartsPost s Q n`: on every path of `E`, the stream `s` starts at most `n` phases, and the
returned value `a` satisfies `Q a m`, where `m` is `n` minus the number of starts on the path. -/
def OProg.StartsPost {S Pp β I R α : Type} [DecidableEq S] (s : S) (Q : α → ℕ → Prop) :
    OProg S Pp β (SQuery I) R α → ℕ → Prop
  | .ret a, n => Q a n
  | .draw _ k, n => ∀ y, OProg.StartsPost s Q (k y) n
  | .call s' q k, n =>
      if s' = s ∧ q.isStart = true then 0 < n ∧ ∀ r, OProg.StartsPost s Q (k r) (n - 1)
      else ∀ r, OProg.StartsPost s Q (k r) n

section Generic

variable {S Pp β I R α γ : Type} [DecidableEq S] {s : S}

theorem OProg.startsLE_mono_aux (s : S) :
    ∀ (E : OProg S Pp β (SQuery I) R α) (m n : ℕ), E.StartsLE s m → m ≤ n → E.StartsLE s n := by
  intro E
  induction E with
  | ret a => intro m n _ _; trivial
  | draw p k ih =>
    intro m n h hmn
    simp only [OProg.StartsLE] at h ⊢
    exact fun y => ih y m n (h y) hmn
  | call s' q k ih =>
    intro m n h hmn
    simp only [OProg.StartsLE] at h ⊢
    split_ifs at h ⊢ with hc
    · exact ⟨lt_of_lt_of_le h.1 hmn, fun r => ih r (m - 1) (n - 1) (h.2 r) (Nat.sub_le_sub_right hmn 1)⟩
    · exact fun r => ih r m n (h r) hmn

/-- Monotonicity of the phase-start bound. -/
theorem OProg.StartsLE.mono {S Pp β I R α : Type} [DecidableEq S] {s : S}
    {E : OProg S Pp β (SQuery I) R α} {m n : ℕ} (h : E.StartsLE s m) (hmn : m ≤ n) :
    E.StartsLE s n :=
  OProg.startsLE_mono_aux s E m n h hmn

/-- Bind rule for the budgeted predicate. -/
theorem OProg.StartsPost.bind' {Q : α → ℕ → Prop} {Q' : γ → ℕ → Prop}
    {f : α → OProg S Pp β (SQuery I) R γ} (hf : ∀ a m, Q a m → (f a).StartsPost s Q' m) :
    ∀ (E : OProg S Pp β (SQuery I) R α) (n : ℕ), E.StartsPost s Q n →
      (E.bind f).StartsPost s Q' n := by
  intro E
  induction E with
  | ret a => intro n h; exact hf a n h
  | draw p k ih =>
    intro n h
    simp only [OProg.bind, OProg.StartsPost] at h ⊢
    exact fun y => ih y n (h y)
  | call s' q k ih =>
    intro n h
    simp only [OProg.bind, OProg.StartsPost] at h ⊢
    split_ifs at h ⊢ with hc
    · exact ⟨h.1, fun r => ih r (n - 1) (h.2 r)⟩
    · exact fun r => ih r n (h r)

/-- Weakening the postcondition. -/
theorem OProg.StartsPost.mono_post {Q Q' : α → ℕ → Prop} (hQ : ∀ a m, Q a m → Q' a m) :
    ∀ (E : OProg S Pp β (SQuery I) R α) (n : ℕ), E.StartsPost s Q n → E.StartsPost s Q' n := by
  intro E
  induction E with
  | ret a => intro n h; exact hQ a n h
  | draw p k ih =>
    intro n h
    simp only [OProg.StartsPost] at h ⊢
    exact fun y => ih y n (h y)
  | call s' q k ih =>
    intro n h
    simp only [OProg.StartsPost] at h ⊢
    split_ifs at h ⊢ with hc
    · exact ⟨h.1, fun r => ih r (n - 1) (h.2 r)⟩
    · exact fun r => ih r n (h r)

/-- The budgeted predicate implies the plain phase-start bound. -/
theorem OProg.StartsPost.startsLE {Q : α → ℕ → Prop} :
    ∀ (E : OProg S Pp β (SQuery I) R α) (n : ℕ), E.StartsPost s Q n → E.StartsLE s n := by
  intro E
  induction E with
  | ret a => intro n _; trivial
  | draw p k ih =>
    intro n h
    simp only [OProg.StartsPost, OProg.StartsLE] at h ⊢
    exact fun y => ih y n (h y)
  | call s' q k ih =>
    intro n h
    simp only [OProg.StartsPost, OProg.StartsLE] at h ⊢
    split_ifs at h ⊢ with hc
    · exact ⟨h.1, fun r => ih r (n - 1) (h.2 r)⟩
    · exact fun r => ih r n (h r)

theorem OProg.startsPost_ret {Q : α → ℕ → Prop} {a : α} {n : ℕ} :
    (OProg.ret a : OProg S Pp β (SQuery I) R α).StartsPost s Q n ↔ Q a n := Iff.rfl

theorem OProg.startsPost_call {Q : α → ℕ → Prop} {s' : S} {q : SQuery I}
    {k : R → OProg S Pp β (SQuery I) R α} {n : ℕ} :
    (OProg.call s' q k).StartsPost s Q n ↔
      if s' = s ∧ q.isStart = true then 0 < n ∧ ∀ r, (k r).StartsPost s Q (n - 1)
      else ∀ r, (k r).StartsPost s Q n := Iff.rfl

omit [DecidableEq S] in
/-- A test query never starts a phase. -/
theorem not_start_test (s' s₀ : S) (i : I) : ¬(s' = s₀ ∧ (SQuery.test i).isStart = true) :=
  fun h => Bool.false_ne_true h.2

end Generic

/-! ## Budgets -/

variable {U : Type} (P : AdaParams)

/-- The remaining correction budget of the edges whose corrections reopen edge `e`
(`j ∈ {e-1, e, e+1}`), at the correction counters `T`. -/
def edgeBudget (e : ℕ) (T : List ℕ) : ℕ :=
  (if 1 ≤ e then P.Tmax.getD (e - 1) 0 - T.getD (e - 1) 0 else 0) +
    (P.Tmax.getD e 0 - T.getD e 0) + (P.Tmax.getD (e + 1) 0 - T.getD (e + 1) 0)

/-- The budget of stream `s` consumed inside `PrepareRoot` (corrections reopen edges only). -/
def prepB (s : Strm) (T : List ℕ) : ℕ :=
  match s with
  | .edge e => edgeBudget P e T
  | .outer => 0
  | .num => 0

/-- The budget of stream `s` reserved for the interfaces (outer reopenings, numerical releases). -/
def extraB (s : Strm) (sk : SkState U) : ℕ :=
  match s with
  | .edge _ => 0
  | .outer => P.J - sk.rej
  | .num => P.R - sk.nNum

/-- The total remaining budget of stream `s` at the skeleton state `sk` (`0` once halted). -/
def callB (s : Strm) (sk : SkState U) : ℕ :=
  if sk.halted = true then 0 else prepB P s sk.T + extraB P s sk

/-- The number of reopenings of stream `s` by `skRedraw es`. -/
def redrawCount (s : Strm) : List ℕ → ℕ
  | [] => 0
  | e :: es => (if Strm.edge e = s then 1 else 0) + redrawCount s es

theorem redrawCount_append (s : Strm) (l₁ l₂ : List ℕ) :
    redrawCount s (l₁ ++ l₂) = redrawCount s l₁ + redrawCount s l₂ := by
  induction l₁ with
  | nil => simp [redrawCount]
  | cons e es ih => simp only [List.cons_append, redrawCount, ih]; omega

theorem redrawCount_outer (es : List ℕ) : redrawCount Strm.outer es = 0 := by
  induction es with
  | nil => rfl
  | cons e es ih => simp [redrawCount, ih]

theorem redrawCount_num (es : List ℕ) : redrawCount Strm.num es = 0 := by
  induction es with
  | nil => rfl
  | cons e es ih => simp [redrawCount, ih]

theorem redrawCount_range' (e : ℕ) :
    ∀ (n a : ℕ), redrawCount (Strm.edge e) (List.range' a n) ≤ 1 ∧
      (e < a → redrawCount (Strm.edge e) (List.range' a n) = 0) := by
  intro n
  induction n with
  | zero => intro a; simp [redrawCount]
  | succ n ih =>
    intro a
    obtain ⟨h1, h2⟩ := ih (a + 1)
    simp only [List.range'_succ, redrawCount, Strm.edge.injEq]
    by_cases hae : a = e
    · subst hae
      rw [if_pos rfl, h2 (Nat.lt_succ_self a)]
      exact ⟨le_rfl, fun h => absurd h (lt_irrefl a)⟩
    · rw [if_neg hae]
      exact ⟨by omega, fun h => by rw [h2 (by omega)]⟩

/-- The count of reopenings of edge `e` by a correction on edge `j`, bounded by the indicator that
`j` is a neighbour of `e`. -/
theorem redrawCount_reopen_le (e j : ℕ) :
    redrawCount (Strm.edge e) (reopenEdges P j) ≤
      (if e = j then 1 else 0) + (if e + 1 = j then 1 else 0) +
        (if 1 ≤ e ∧ e - 1 = j then 1 else 0) := by
  unfold reopenEdges
  split_ifs <;> simp only [redrawCount, Strm.edge.injEq, List.cons_append,
    List.nil_append] <;> split_ifs <;> omega

theorem getD_set_self_nat {l : List ℕ} {i a : ℕ} (h : i < l.length) : (l.set i a).getD i 0 = a := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set_self h]; rfl

theorem getD_set_ne_nat {l : List ℕ} {i j a : ℕ} (h : i ≠ j) :
    (l.set i a).getD j 0 = l.getD j 0 := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set_ne h, ← List.getD_eq_getElem?_getD]

theorem getD_replicate_zero (n i : ℕ) : (List.replicate n 0).getD i 0 = 0 := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_replicate]
  split_ifs <;> rfl

/-- A correction on edge `j` (allowed: `T_j < T_j^max`) consumes at least as much budget of stream
`s` as it makes reopenings of `s`. -/
theorem prepB_set_add_redrawCount (s : Strm) {T : List ℕ} {j : ℕ} (hT : T.length = P.p)
    (hj : j < P.p) (hlt : T.getD j 0 < P.Tmax.getD j 0) :
    prepB P s (T.set j (T.getD j 0 + 1)) + redrawCount s (reopenEdges P j) ≤ prepB P s T := by
  cases s with
  | outer => simp [prepB, redrawCount_outer]
  | num => simp [prepB, redrawCount_num]
  | edge e =>
    have hlen : j < T.length := by omega
    have hrem : ∀ i, P.Tmax.getD i 0 - (T.set j (T.getD j 0 + 1)).getD i 0 +
        (if i = j then 1 else 0) = P.Tmax.getD i 0 - T.getD i 0 := by
      intro i
      by_cases hij : i = j
      · subst hij
        rw [getD_set_self_nat hlen, if_pos rfl]
        omega
      · rw [getD_set_ne_nat (Ne.symm hij), if_neg hij, Nat.add_zero]
    have h1 := hrem (e - 1)
    have h2 := hrem e
    have h3 := hrem (e + 1)
    have hc := redrawCount_reopen_le P e j
    simp only [prepB, edgeBudget]
    split_ifs at h1 h2 h3 hc ⊢ <;> omega

/-! ## Per-call budget lemmas (any stream `s`) -/

theorem skRedraw_startsPost (s : Strm) :
    ∀ (es : List ℕ) (c n : ℕ), redrawCount s es + c ≤ n →
      (skRedraw (U := U) es).StartsPost s (fun _ m => c ≤ m) n := by
  intro es
  induction es with
  | nil =>
    intro c n h
    exact OProg.startsPost_ret.2 (by simpa [redrawCount] using h)
  | cons e es ih =>
    intro c n h
    show (OProg.call (Strm.edge e) SQuery.reopen fun _ => skRedraw es).StartsPost s _ n
    rw [OProg.startsPost_call]
    by_cases hs : Strm.edge e = s
    · rw [if_pos ⟨hs, rfl⟩]
      have hc : redrawCount s (e :: es) = 1 + redrawCount s es := by
        simp [redrawCount, hs]
      exact ⟨by omega, fun _ => ih c (n - 1) (by omega)⟩
    · rw [if_neg (fun h' => hs h'.1)]
      have hc : redrawCount s (e :: es) = redrawCount s es := by
        simp [redrawCount, hs]
      exact fun _ => ih c n (by omega)

theorem skApplyCorrection_startsPost (s : Strm) (sk : SkState U) (f : U → ℕ) {j : ℕ} (q : Bool)
    (hT : sk.T.length = P.p) (hj : j < P.p) (hlt : ¬P.Tmax.getD j 0 ≤ sk.T.getD j 0)
    (c n : ℕ) (hn : prepB P s sk.T + c ≤ n) :
    (skApplyCorrection P sk f j q).StartsPost s (fun sk' m => sk'.T.length = P.p ∧
      sk'.rej = sk.rej ∧ sk'.nNum = sk.nNum ∧ sk'.halted = sk.halted ∧
      prepB P s sk'.T + c ≤ m) n := by
  unfold skApplyCorrection
  have key := prepB_set_add_redrawCount P s hT hj (by omega)
  refine OProg.StartsPost.bind' ?_ _ n
    (skRedraw_startsPost s (reopenEdges P j) (prepB P s (sk.T.set j (sk.T.getD j 0 + 1)) + c) n
      (by omega))
  intro _ m hm
  refine OProg.startsPost_ret.2 ⟨?_, rfl, rfl, rfl, hm⟩
  show (sk.T.set j (sk.T.getD j 0 + 1)).length = P.p
  rw [List.length_set, hT]

theorem skScanPass_startsPost (s : Strm) (f : U → ℕ) :
    ∀ (es : List ℕ), (∀ j ∈ es, j < P.p) → ∀ (sk : SkState U) (cache : List Bool) (c n : ℕ),
      sk.T.length = P.p → prepB P s sk.T + c ≤ n →
      (skScanPass P f es sk cache).StartsPost s (fun r m => r.2.1.T.length = P.p ∧
        r.2.1.rej = sk.rej ∧ r.2.1.nNum = sk.nNum ∧ r.2.1.halted = sk.halted ∧
        prepB P s r.2.1.T + c ≤ m) n := by
  intro es
  induction es with
  | nil =>
    intro _ sk cache c n hT hn
    exact OProg.startsPost_ret.2 ⟨hT, rfl, rfl, rfl, hn⟩
  | cons j es ih =>
    intro hes sk cache c n hT hn
    have hj : j < P.p := hes j List.mem_cons_self
    have hes' : ∀ j' ∈ es, j' < P.p := fun j' h => hes j' (List.mem_cons_of_mem j h)
    rw [skScanPass]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact ih hes' sk cache c n hT hn
    · rw [if_neg hc]
      refine OProg.StartsPost.bind' (Q := fun _ m => n ≤ m) ?_ _ n ?_
      · intro r m hm
        cases r with
        | cross q =>
          show OProg.StartsPost s _ (if P.Tmax.getD j 0 ≤ sk.T.getD j 0 then
            OProg.ret (PassOut.abort, sk, cache) else
            (skApplyCorrection P sk f j q).bind fun sk' => OProg.ret
              (PassOut.corrected, sk', (reopenEdges P j).foldl (fun c e => c.set e false) cache)) m
          by_cases hcap : P.Tmax.getD j 0 ≤ sk.T.getD j 0
          · rw [if_pos hcap]
            exact OProg.startsPost_ret.2 ⟨hT, rfl, rfl, rfl, (show prepB P s sk.T + c ≤ m by omega)⟩
          · rw [if_neg hcap]
            refine OProg.StartsPost.bind' ?_ _ m
              (skApplyCorrection_startsPost P s sk f q hT hj hcap c m (by omega))
            intro sk' m' hsk'
            exact OProg.startsPost_ret.2 hsk'
        | accept => exact ih hes' sk _ c m hT (by omega)
        | closed => exact ih hes' sk _ c m hT (by omega)
        | opened => exact ih hes' sk _ c m hT (by omega)
        | value z => exact ih hes' sk _ c m hT (by omega)
      · show (OProg.call (Strm.edge j) (SQuery.test ⟨sk.hist, f, 0, 0⟩) OProg.ret).StartsPost s _ n
        rw [OProg.startsPost_call, if_neg (not_start_test _ _ _)]
        intro _
        exact OProg.startsPost_ret.2 le_rfl

theorem skPrepareRoot_startsPost (s : Strm) (f : U → ℕ) :
    ∀ (fuel : ℕ) (sk : SkState U) (cache : List Bool) (c n : ℕ),
      sk.T.length = P.p → prepB P s sk.T + c ≤ n →
      (skPrepareRoot P f fuel sk cache).StartsPost s (fun o m => ∀ sk2, o = some sk2 →
        sk2.T.length = P.p ∧ sk2.rej = sk.rej ∧ sk2.nNum = sk.nNum ∧ sk2.halted = sk.halted ∧
        prepB P s sk2.T + c ≤ m) n := by
  intro fuel
  induction fuel with
  | zero =>
    intro sk cache c n _ _
    refine OProg.startsPost_ret.2 ?_
    intro sk2 h
    cases h
  | succ fuel ih =>
    intro sk cache c n hT hn
    rw [skPrepareRoot]
    refine OProg.StartsPost.bind' ?_ _ n (skScanPass_startsPost P s f (List.range P.p)
      (fun j hj => List.mem_range.1 hj) sk cache c n hT hn)
    rintro ⟨out, sk', cache'⟩ m ⟨hT', hrej, hnum, hhalt, hm⟩
    cases out with
    | done =>
      refine OProg.startsPost_ret.2 ?_
      intro sk2 h
      cases h
      exact ⟨hT', hrej, hnum, hhalt, hm⟩
    | corrected =>
      refine OProg.StartsPost.mono_post ?_ _ m (ih sk' cache' c m hT' hm)
      intro o m' ho sk2 h2
      obtain ⟨a1, a2, a3, a4, a5⟩ := ho sk2 h2
      exact ⟨a1, a2.trans hrej, a3.trans hnum, a4.trans hhalt, a5⟩
    | abort =>
      refine OProg.startsPost_ret.2 ?_
      intro sk2 h
      cases h

theorem callB_halted (s : Strm) {sk : SkState U} (h : sk.halted = true) : callB P s sk = 0 := by
  simp [callB, h]

theorem callB_of_not_halted (s : Strm) {sk : SkState U} (h : sk.halted = false) :
    callB P s sk = prepB P s sk.T + extraB P s sk := by
  simp [callB, h]

theorem skOuterReject_startsPost (s : Strm) (sk : SkState U) (high : Bool) (n : ℕ)
    (hT : sk.T.length = P.p) (hh : sk.halted = false) (hn : callB P s sk ≤ n) :
    (skOuterReject P sk high).StartsPost s
      (fun r m => r.2.T.length = P.p ∧ callB P s r.2 ≤ m) n := by
  rw [skOuterReject]
  by_cases hJ : P.J + 1 ≤ sk.rej + 1
  · rw [if_pos hJ]
    exact OProg.startsPost_ret.2 ⟨hT, by rw [callB_halted P s rfl]; exact Nat.zero_le n⟩
  · rw [if_neg hJ]
    have hrej : sk.rej < P.J := by omega
    rw [OProg.startsPost_call, callB_of_not_halted P s hh] at *
    have hh' : ({ sk with rej := sk.rej + 1 } : SkState U).halted = false := hh
    cases s with
    | outer =>
      rw [if_pos ⟨rfl, rfl⟩]
      simp only [prepB, extraB] at hn
      refine ⟨by omega, fun _ => OProg.startsPost_ret.2 ⟨hT, ?_⟩⟩
      rw [callB_of_not_halted P _ hh']
      simp only [prepB, extraB]
      omega
    | edge e =>
      rw [if_neg (fun h => by cases h.1)]
      intro _
      refine OProg.startsPost_ret.2 ⟨hT, ?_⟩
      rw [callB_of_not_halted P _ hh']
      simpa [prepB, extraB] using hn
    | num =>
      rw [if_neg (fun h => by cases h.1)]
      intro _
      refine OProg.startsPost_ret.2 ⟨hT, ?_⟩
      rw [callB_of_not_halted P _ hh']
      simpa [prepB, extraB] using hn

theorem skIntervalD_startsPost (s : Strm) (sk : SkState U) (f : U → ℕ) (l u : ℚ) (n : ℕ)
    (hT : sk.T.length = P.p) (hn : callB P s sk ≤ n) :
    (skIntervalD P sk f l u).StartsPost s
      (fun r m => r.2.T.length = P.p ∧ callB P s r.2 ≤ m) n := by
  rw [skIntervalD]
  by_cases hc : sk.halted = true ∨ P.M ≤ sk.nInt
  · rw [if_pos hc]
    exact OProg.startsPost_ret.2 ⟨hT, hn⟩
  · rw [if_neg hc]
    have hh : sk.halted = false := by
      cases h : sk.halted
      · rfl
      · exact absurd (Or.inl h) hc
    have hn' : prepB P s sk.T + extraB P s sk ≤ n := by
      rw [← callB_of_not_halted P s hh]; exact hn
    refine OProg.StartsPost.bind' ?_ _ n (skPrepareRoot_startsPost P s f P.fuel
      { sk with nInt := sk.nInt + 1 } (List.replicate P.p false) (extraB P s sk) n hT hn')
    intro r m hr
    cases r with
    | none =>
      exact OProg.startsPost_ret.2 ⟨hT, by rw [callB_halted P s rfl]; exact Nat.zero_le m⟩
    | some sk2 =>
      obtain ⟨hT2, hrej2, hnum2, hhalt2, hm⟩ := hr sk2 rfl
      have hh2 : sk2.halted = false := hhalt2.trans hh
      have hext : extraB P s sk2 = extraB P s sk := by
        cases s
        · rfl
        · show P.J - sk2.rej = P.J - sk.rej
          rw [hrej2]
        · show P.R - sk2.nNum = P.R - sk.nNum
          rw [hnum2]
      have hcb : callB P s sk2 ≤ m := by
        rw [callB_of_not_halted P s hh2, hext]
        exact hm
      show (OProg.call Strm.outer (SQuery.test _) _).StartsPost s _ m
      rw [OProg.startsPost_call, if_neg (not_start_test _ _ _)]
      intro resp
      cases resp with
      | cross b =>
        cases b with
        | true => exact skOuterReject_startsPost P s sk2 true m hT2 hh2 hcb
        | false => exact skOuterReject_startsPost P s sk2 false m hT2 hh2 hcb
      | accept => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
      | closed => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
      | opened => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
      | value z => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩

theorem skNumericalD_startsPost (s : Strm) (sk : SkState U) (f : U → ℕ) (n : ℕ)
    (hT : sk.T.length = P.p) (hn : callB P s sk ≤ n) :
    (skNumericalD P sk f).StartsPost s
      (fun r m => r.2.T.length = P.p ∧ callB P s r.2 ≤ m) n := by
  rw [skNumericalD]
  by_cases hc : sk.halted = true ∨ P.R ≤ sk.nNum
  · rw [if_pos hc]
    exact OProg.startsPost_ret.2 ⟨hT, hn⟩
  · rw [if_neg hc]
    have hh : sk.halted = false := by
      cases h : sk.halted
      · rfl
      · exact absurd (Or.inl h) hc
    have hR : sk.nNum < P.R := by
      by_contra h
      exact hc (Or.inr (by omega))
    have hn' : prepB P s sk.T + extraB P s sk ≤ n := by
      rw [← callB_of_not_halted P s hh]; exact hn
    refine OProg.StartsPost.bind' ?_ _ n (skPrepareRoot_startsPost P s f P.fuel
      { sk with nNum := sk.nNum + 1 } (List.replicate P.p false) (extraB P s sk) n hT hn')
    intro r m hr
    cases r with
    | none =>
      exact OProg.startsPost_ret.2 ⟨hT, by rw [callB_halted P s rfl]; exact Nat.zero_le m⟩
    | some sk2 =>
      obtain ⟨hT2, hrej2, hnum2, hhalt2, hm⟩ := hr sk2 rfl
      have hh2 : sk2.halted = false := hhalt2.trans hh
      have hnum2' : sk2.nNum = sk.nNum + 1 := hnum2
      have hrej2' : sk2.rej = sk.rej := hrej2
      show (OProg.call Strm.num (SQuery.release _) _).StartsPost s _ m
      rw [OProg.startsPost_call]
      cases s with
      | num =>
        rw [if_pos ⟨rfl, rfl⟩]
        have hm' : P.R - sk.nNum ≤ m := by simpa [prepB, extraB] using hm
        have hcb : callB P Strm.num sk2 ≤ m - 1 := by
          rw [callB_of_not_halted P _ hh2]
          simp only [prepB, extraB, hnum2']
          omega
        refine ⟨by omega, fun resp => ?_⟩
        cases resp with
        | value v => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | accept => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | cross b => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | closed => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | opened => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
      | edge e =>
        rw [if_neg (fun h => by cases h.1)]
        have hcb : callB P (Strm.edge e) sk2 ≤ m := by
          rw [callB_of_not_halted P _ hh2]
          simpa [prepB, extraB] using hm
        intro resp
        cases resp with
        | value v => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | accept => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | cross b => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | closed => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | opened => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
      | outer =>
        rw [if_neg (fun h => by cases h.1)]
        have hcb : callB P Strm.outer sk2 ≤ m := by
          rw [callB_of_not_halted P _ hh2]
          simpa [prepB, extraB, hrej2'] using hm
        intro resp
        cases resp with
        | value v => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | accept => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | cross b => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | closed => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩
        | opened => exact OProg.startsPost_ret.2 ⟨hT2, hcb⟩

theorem skStepD_startsPost (s : Strm) (req : CoreReq U) (sk : SkState U) (n : ℕ)
    (hT : sk.T.length = P.p) (hn : callB P s sk ≤ n) :
    (skStepD P req sk).StartsPost s (fun r m => r.2.T.length = P.p ∧ callB P s r.2 ≤ m) n := by
  rw [skStepD]
  by_cases hi : req.isInterval = true
  · rw [if_pos hi, OProg.map]
    refine OProg.StartsPost.bind' ?_ _ n (skIntervalD_startsPost P s sk req.f req.l req.u n hT hn)
    intro r m hr
    exact OProg.startsPost_ret.2 hr
  · rw [if_neg hi, OProg.map]
    refine OProg.StartsPost.bind' ?_ _ n (skNumericalD_startsPost P s sk req.f n hT hn)
    intro r m hr
    exact OProg.startsPost_ret.2 hr

theorem skLoopD_startsPost (s : Strm) (ctrl : CoreCtrl U) :
    ∀ (T : ℕ) (sk : SkState U) (hist : List CoreOut) (n : ℕ),
      sk.T.length = P.p → callB P s sk ≤ n →
      (skLoopD P ctrl T sk hist).StartsPost s (fun _ _ => True) n := by
  intro T
  induction T with
  | zero =>
    intro sk hist n _ _
    exact OProg.startsPost_ret.2 trivial
  | succ T ih =>
    intro sk hist n hT hn
    rw [skLoopD]
    refine OProg.StartsPost.bind' ?_ _ n (skStepD_startsPost P s (ctrl hist) sk n hT hn)
    intro r m hr
    exact ih r.2 (hist ++ [r.1]) m hr.1 hr.2

theorem skInit_T_length : (skInit (U := U) P).T.length = P.p := by
  simp [skInit]

theorem skRunD_startsPost (s : Strm) (ctrl : CoreCtrl U) (T : ℕ) :
    (skRunD P ctrl T).StartsPost s (fun _ _ => True)
      (redrawCount s (List.range P.p) +
        ((if s = Strm.outer then 1 else 0) + callB P s (skInit (U := U) P))) := by
  have hinit : (skInitD (U := U) P).StartsPost s
      (fun sk m => sk.T.length = P.p ∧ callB P s sk ≤ m)
      (redrawCount s (List.range P.p) +
        ((if s = Strm.outer then 1 else 0) + callB P s (skInit (U := U) P))) := by
    rw [skInitD]
    refine OProg.StartsPost.bind' ?_ _ _ (skRedraw_startsPost s (List.range P.p) _ _ le_rfl)
    intro _ m hm
    show (OProg.call Strm.outer SQuery.reopen fun _ => OProg.ret (skInit P)).StartsPost s _ m
    rw [OProg.startsPost_call]
    by_cases hs : s = Strm.outer
    · subst hs
      rw [if_pos ⟨rfl, rfl⟩]
      rw [if_pos rfl] at hm
      exact ⟨by omega, fun _ => OProg.startsPost_ret.2 ⟨skInit_T_length P, by omega⟩⟩
    · rw [if_neg (fun h => hs h.1.symm)]
      rw [if_neg hs, Nat.zero_add] at hm
      exact fun _ => OProg.startsPost_ret.2 ⟨skInit_T_length P, hm⟩
  rw [skRunD]
  exact OProg.StartsPost.bind' (fun sk m hsk => skLoopD_startsPost P s ctrl T sk [] m hsk.1 hsk.2)
    _ _ hinit

/-! ## The phase-start counts -/

theorem edgeBudget_init (e : ℕ) :
    edgeBudget P e (List.replicate P.p 0) =
      (if 1 ≤ e then P.Tmax.getD (e - 1) 0 else 0) + P.Tmax.getD e 0 + P.Tmax.getD (e + 1) 0 := by
  simp only [edgeBudget, getD_replicate_zero, Nat.sub_zero]

theorem callB_skInit (s : Strm) :
    callB P s (skInit (U := U) P) = prepB P s (List.replicate P.p 0) + extraB P s (skInit (U := U) P) :=
  callB_of_not_halted P s rfl

/-- Edge `e` starts at most `1 + T_{e-1}^max + T_e^max + T_{e+1}^max` phases. -/
theorem skRunD_startsLE_edge (ctrl : CoreCtrl U) (T e : ℕ) :
    (skRunD P ctrl T).StartsLE (Strm.edge e)
      (1 + (if 1 ≤ e then P.Tmax.getD (e - 1) 0 else 0) + P.Tmax.getD e 0 +
        P.Tmax.getD (e + 1) 0) := by
  refine (OProg.StartsPost.startsLE _ _ (skRunD_startsPost P (Strm.edge e) ctrl T)).mono ?_
  have h1 := (redrawCount_range' e P.p 0).1
  rw [← List.range_eq_range'] at h1
  rw [callB_skInit, if_neg (fun h => by cases h)]
  have h2 : prepB P (Strm.edge e) (List.replicate P.p 0) =
      (if 1 ≤ e then P.Tmax.getD (e - 1) 0 else 0) + P.Tmax.getD e 0 + P.Tmax.getD (e + 1) 0 :=
    edgeBudget_init P e
  have h3 : extraB P (Strm.edge e) (skInit (U := U) P) = 0 := rfl
  rw [h2, h3]
  omega

/-- The outer validator starts at most `J + 1` phases. -/
theorem skRunD_startsLE_outer (ctrl : CoreCtrl U) (T : ℕ) :
    (skRunD P ctrl T).StartsLE Strm.outer (P.J + 1) := by
  refine (OProg.StartsPost.startsLE _ _ (skRunD_startsPost P Strm.outer ctrl T)).mono ?_
  rw [callB_skInit, redrawCount_outer, if_pos rfl]
  have h2 : prepB P Strm.outer (List.replicate P.p 0) = 0 := rfl
  have h3 : extraB P Strm.outer (skInit (U := U) P) = P.J := by
    show P.J - 0 = P.J
    rfl
  rw [h2, h3]
  omega

/-- The numerical stream starts at most `R` phases. -/
theorem skRunD_startsLE_num (ctrl : CoreCtrl U) (T : ℕ) :
    (skRunD P ctrl T).StartsLE Strm.num P.R := by
  refine (OProg.StartsPost.startsLE _ _ (skRunD_startsPost P Strm.num ctrl T)).mono ?_
  rw [callB_skInit, redrawCount_num, if_neg (fun h => by cases h)]
  have h2 : prepB P Strm.num (List.replicate P.p 0) = 0 := rfl
  have h3 : extraB P Strm.num (skInit (U := U) P) = P.R := by
    show P.R - 0 = P.R
    rfl
  rw [h2, h3]
  omega

end F2e2e.B.Priv
