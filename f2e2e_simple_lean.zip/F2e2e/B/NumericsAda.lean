import F2e2e.B.ArchParamsBridge

/-!
# Part II numerics (B-NUM), part 7: size bounds for the computable parameters `adaParams`

Interface for Part III (Lemma `R:lem:bit-length-accounting`, `R:eq:Jstar-Nbank-bounds`, partIII
L1225–1237, which substitutes `p, χ ≤ 2^12 ℒ` into eq. `R:eq:sec3_N_explicit`): bounds on B-ARCH's
computable `adaP`, `adaChi`, `adaBlockSizes` (`F2e2e/B/ArchParams.lean`) as functions of
`(eA, eXi, M, J, R)`, where `a = 2^{-eA}`, `ξ_A = 2^{-eXi}`.

* `adaBlockSizes_length`: `(adaBlockSizes …).length = p + 1`;
* `adaP_le_of_four_le` (`p ≤ 2eA + 4`), `adaP_le_two_pow` (`p ≤ 2^{eA}`), `twelve_le_adaP`;
* `adaChi_le_of_four_le`: `χ ≤ 68 + 8eA + eXi + ⌈log₂(M+J+R+2)⌉`;
* `adaN_le_explicit`: `N ≤ 2^45[(p^{7/2}4^{eA} + p^{3/2}√K 2^{eA})χ^{3/2} + p³χ4^{eA}]`;
* `adaN_le_of_bounds`: if `p, χ ≤ 2^12 L`, `2^{eA} ≤ 2^21 E L`, `K ≤ 2^13 E² L³` then
  `N ≤ 2^199 E² L^7`.
-/

namespace F2e2e.B

/-- `dyadicExp (2^{-e}) = e`. -/
theorem dyadicExp_half_pow (e : ℕ) : dyadicExp ((1 / 2 : ℝ) ^ e) = e := by
  unfold dyadicExp
  rw [one_div_pow, one_div, inv_inv]
  have h : ((2 ^ e : ℕ) : ℝ) = (2 : ℝ) ^ e := by push_cast; rfl
  rw [← h, Nat.ceil_natCast, Nat.clog_pow 2 e (by norm_num)]

/-- `dyadicDown (2^{-e}) = 2^{-e}`. -/
theorem dyadicDown_half_pow (e : ℕ) : dyadicDown ((1 / 2 : ℝ) ^ e) = (1 / 2 : ℝ) ^ e := by
  unfold dyadicDown
  rw [dyadicExp_half_pow]

theorem half_pow_lt_tenth {e : ℕ} (h : 4 ≤ e) : (1 / 2 : ℝ) ^ e < 1 / 10 := by
  calc (1 / 2 : ℝ) ^ e ≤ (1 / 2) ^ 4 := pow_le_pow_of_le_one (by norm_num) (by norm_num) h
    _ < 1 / 10 := by norm_num

theorem half_pow_lt_half {e : ℕ} (h : 2 ≤ e) : (1 / 2 : ℝ) ^ e < 1 / 2 := by
  calc (1 / 2 : ℝ) ^ e ≤ (1 / 2) ^ 2 := pow_le_pow_of_le_one (by norm_num) (by norm_num) h
    _ < 1 / 2 := by norm_num

/-- `(adaBlockSizes …).length = p + 1`. -/
theorem adaBlockSizes_length (M J R eA eXi : ℕ) :
    (adaBlockSizes M J R eA eXi).length = adaP eA + 1 := by
  unfold adaBlockSizes
  rw [List.length_map, List.length_range]

/-- `adaP eA = alg2P (2^{-eA})`. -/
theorem adaP_eq_alg2P_half_pow (eA : ℕ) : adaP eA = alg2P ((1 / 2 : ℝ) ^ eA) := by
  have h := adaP_eq ((1 / 2 : ℝ) ^ eA)
  rwa [dyadicExp_half_pow] at h

/-- `p ≤ 2eA + 4` for `eA ≥ 4`. -/
theorem adaP_le_of_four_le {eA : ℕ} (h : 4 ≤ eA) : adaP eA ≤ 2 * eA + 4 := by
  apply Nat.find_min' (exists_adaP eA)
  refine ⟨by omega, ?_⟩
  have e : 2 * eA + 4 - 1 = eA + (eA + 3) := by omega
  rw [e, pow_add 2 eA (eA + 3)]
  exact Nat.mul_le_mul_right (2 ^ (eA + 3)) (two_mul_add_four_le_two_pow h)

/-- `p ≤ 2^{eA}` for `eA ≥ 4`. -/
theorem adaP_le_two_pow {eA : ℕ} (h : 4 ≤ eA) : adaP eA ≤ 2 ^ eA :=
  (adaP_le_of_four_le h).trans (two_mul_add_four_le_two_pow h)

/-- `p ≥ 12` for `eA ≥ 4`. -/
theorem twelve_le_adaP {eA : ℕ} (h : 4 ≤ eA) : 12 ≤ adaP eA := by
  rw [adaP_eq_alg2P_half_pow]
  apply twelve_le_valP (alg2A_pos _)
  show dyadicDown ((1 / 2 : ℝ) ^ eA) ≤ 1 / 16
  rw [dyadicDown_half_pow]
  calc (1 / 2 : ℝ) ^ eA ≤ (1 / 2) ^ 4 := pow_le_pow_of_le_one (by norm_num) (by norm_num) h
    _ = 1 / 16 := by norm_num

/-- `χ ≤ 68 + 8eA + eXi + ⌈log₂(M+J+R+2)⌉` for `eA ≥ 4`. -/
theorem adaChi_le_of_four_le (M J R : ℕ) {eA : ℕ} (eXi : ℕ) (h : 4 ≤ eA) :
    adaChi M J R eA eXi ≤ 68 + 8 * eA + eXi + Nat.clog 2 (M + J + R + 2) := by
  set aReq := (1 / 2 : ℝ) ^ eA with haReq
  have hk : dyadicExp aReq = eA := dyadicExp_half_pow eA
  have hpA : adaP eA = alg2P aReq := adaP_eq_alg2P_half_pow eA
  have hQ : adaQ M J R eA = alg2Q M J R aReq := by
    have := adaQ_eq M J R aReq
    rwa [hk] at this
  have ha : alg2A aReq = (1 / 2 : ℝ) ^ eA := dyadicDown_half_pow eA
  have hapos := alg2A_pos aReq
  have hp2 := two_le_alg2P_real aReq
  have hpe : (alg2P aReq : ℝ) ≤ 2 ^ eA := by
    rw [← hpA]
    exact_mod_cast adaP_le_two_pow h
  -- the real bound `p(p+1)Q ≤ 2^{7eA+19} S`
  have hQle := valQ_le M J R (alg2A_pos aReq)
  change (alg2Q M J R aReq : ℝ) ≤ 100 * ((alg2P aReq : ℝ) + 1) *
    ((M : ℝ) + J + R + 2 + 8 / alg2Tau aReq ^ 2 + alg2P aReq) at hQle
  have hτ : 8 / alg2Tau aReq ^ 2 = 512 * (alg2P aReq : ℝ) ^ 2 * 4 ^ eA := by
    have h1 := one_div_alg2Tau_sq aReq
    rw [ha] at h1
    have e4 : ((1 / 2 : ℝ) ^ eA) ^ 2 = ((4 : ℝ) ^ eA)⁻¹ := by
      rw [← pow_mul, one_div_pow, mul_comm, pow_mul]
      norm_num
    rw [e4] at h1
    calc 8 / alg2Tau aReq ^ 2 = 8 * (1 / alg2Tau aReq ^ 2) := by ring
      _ = 8 * (64 * (alg2P aReq : ℝ) ^ 2 / ((4 : ℝ) ^ eA)⁻¹) := by rw [h1]
      _ = 512 * (alg2P aReq : ℝ) ^ 2 * 4 ^ eA := by field_simp; ring
  rw [hτ] at hQle
  set P := (alg2P aReq : ℝ) with hP
  set S := (M : ℝ) + J + R + 2 with hS
  set T := (2 : ℝ) ^ eA with hT
  have hT16 : (16 : ℝ) ≤ T := by
    rw [hT]
    calc (16 : ℝ) = 2 ^ 4 := by norm_num
      _ ≤ 2 ^ eA := pow_le_pow_right₀ (by norm_num) h
  have hS2 : (2 : ℝ) ≤ S := by
    have : (0 : ℝ) ≤ (M : ℝ) + J + R := by positivity
    rw [hS]
    linarith
  have h4T : (4 : ℝ) ^ eA = T ^ 2 := by
    rw [hT, ← pow_mul, mul_comm, pow_mul]
    norm_num
  rw [h4T] at hQle
  have hinner : S + 512 * P ^ 2 * T ^ 2 + P ≤ 1024 * S * T ^ 4 := by
    have hP2T : P ^ 2 ≤ T ^ 2 := pow_le_pow_left₀ (by linarith) hpe 2
    have hT2 : 1 ≤ T ^ 2 := by nlinarith
    have hT4 : T ^ 2 ≤ T ^ 4 := by nlinarith
    have h1 : 512 * P ^ 2 * T ^ 2 ≤ 512 * T ^ 4 := by nlinarith
    have h2 : P ≤ T ^ 4 := by nlinarith
    have h3 : S ≤ S * T ^ 4 := by nlinarith
    nlinarith
  have hQ' : (alg2Q M J R aReq : ℝ) ≤ 100 * (2 * T) * (1024 * S * T ^ 4) := by
    have hp1 : P + 1 ≤ 2 * T := by linarith
    have h0 : 0 ≤ S + 512 * P ^ 2 * T ^ 2 + P := by positivity
    calc (alg2Q M J R aReq : ℝ) ≤ 100 * (P + 1) * (S + 512 * P ^ 2 * T ^ 2 + P) := hQle
      _ ≤ 100 * (2 * T) * (1024 * S * T ^ 4) := by gcongr
  have hprod : P * (P + 1) * (alg2Q M J R aReq : ℝ) ≤ 2 ^ 19 * T ^ 7 * S := by
    have hp1 : P + 1 ≤ 2 * T := by linarith
    have hQ0 : (0 : ℝ) ≤ alg2Q M J R aReq := Nat.cast_nonneg _
    calc P * (P + 1) * (alg2Q M J R aReq : ℝ) ≤ T * (2 * T) * (100 * (2 * T) * (1024 * S * T ^ 4)) := by
          gcongr
      _ = 409600 * T ^ 7 * S := by ring
      _ ≤ 2 ^ 19 * T ^ 7 * S := by
          have : 0 ≤ T ^ 7 * S := by positivity
          nlinarith
  -- cast back to `ℕ`
  have hnat : adaP eA * (adaP eA + 1) * adaQ M J R eA ≤ 2 ^ (7 * eA + 19) * (M + J + R + 2) := by
    rw [hpA, hQ]
    have e7 : ((2 ^ (7 * eA + 19) * (M + J + R + 2) : ℕ) : ℝ) = 2 ^ 19 * T ^ 7 * S := by
      have h7 : (2 : ℝ) ^ (7 * eA + 19) = 2 ^ 19 * ((2 : ℝ) ^ eA) ^ 7 := by
        rw [pow_add, pow_mul']
        ring
      push_cast
      rw [h7, hT, hS]
    have : ((alg2P aReq * (alg2P aReq + 1) * alg2Q M J R aReq : ℕ) : ℝ) ≤
        ((2 ^ (7 * eA + 19) * (M + J + R + 2) : ℕ) : ℝ) := by
      rw [e7]
      push_cast
      exact hprod
    exact_mod_cast this
  unfold adaChi
  have hclog := Nat.clog_mono_right 2 hnat
  rw [clog_two_pow_mul _ _ (by omega)] at hclog
  omega

/-- Computable form of the explicit sample bound (eq. `R:eq:sec3_N_explicit` with constant `2^45`,
`a = 2^{-eA}`): `N ≤ 2^45[(p^{7/2}4^{eA} + p^{3/2}√K 2^{eA})χ^{3/2} + p³χ4^{eA}]`. -/
theorem adaN_le_explicit (M J R : ℕ) {eA eXi : ℕ} (hA : 4 ≤ eA) (hXi : 2 ≤ eXi) :
    ((adaBlockSizes M J R eA eXi).sum : ℝ) ≤
      2 ^ 45 * ((((adaP eA : ℝ) ^ 3 * Real.sqrt (adaP eA) * 4 ^ eA +
          (adaP eA : ℝ) * Real.sqrt (adaP eA) * Real.sqrt ((J : ℝ) + R + 1) * 2 ^ eA) *
          ((adaChi M J R eA eXi : ℝ) * Real.sqrt (adaChi M J R eA eXi))) +
        (adaP eA : ℝ) ^ 3 * (adaChi M J R eA eXi : ℝ) * 4 ^ eA) := by
  set aReq := (1 / 2 : ℝ) ^ eA with haReq
  set ξReq := (1 / 2 : ℝ) ^ eXi with hξReq
  have hkA : dyadicExp aReq = eA := dyadicExp_half_pow eA
  have hkX : dyadicExp ξReq = eXi := dyadicExp_half_pow eXi
  have ha0 : 0 < aReq := by positivity
  have ha1 : aReq < 1 / 10 := half_pow_lt_tenth hA
  have hξ0 : 0 < ξReq := by positivity
  have hξ1 : ξReq < 1 / 2 := half_pow_lt_half hXi
  have hN := adaParams_N_eq M J R ha0 ha1 hξ0 hξ1
  rw [hkA, hkX] at hN
  have hsum : (adaBlockSizes M J R eA eXi).sum = alg2N M J R aReq ξReq := hN
  have hp : adaP eA = alg2P aReq := by
    have := adaP_eq aReq
    rwa [hkA] at this
  have hχ : adaChi M J R eA eXi = alg2Chi M J R aReq ξReq := by
    have := adaChi_eq M J R ha0 ha1 hξ0 hξ1
    rwa [hkA, hkX] at this
  have ha : alg2A aReq = (1 / 2 : ℝ) ^ eA := dyadicDown_half_pow eA
  have h2 : 1 / alg2A aReq ^ 2 = (4 : ℝ) ^ eA := by
    rw [ha, ← pow_mul, one_div_pow, mul_comm, pow_mul, one_div_one_div]
    norm_num
  have h1 : 1 / alg2A aReq = (2 : ℝ) ^ eA := by
    rw [ha, one_div_pow, one_div_one_div]
  have hmain := alg2_N_le_two_pow_45 M J R aReq ξReq
  rw [hsum, hp, hχ]
  have e1 : (alg2P aReq : ℝ) ^ 3 * Real.sqrt (alg2P aReq) / alg2A aReq ^ 2 =
      (alg2P aReq : ℝ) ^ 3 * Real.sqrt (alg2P aReq) * 4 ^ eA := by
    rw [← h2]
    ring
  have e2 : (alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) / alg2A aReq =
      (alg2P aReq : ℝ) * Real.sqrt (alg2P aReq) * Real.sqrt ((J : ℝ) + R + 1) * 2 ^ eA := by
    rw [← h1]
    ring
  have e3 : (alg2P aReq : ℝ) ^ 3 * (alg2Chi M J R aReq ξReq : ℝ) / alg2A aReq ^ 2 =
      (alg2P aReq : ℝ) ^ 3 * (alg2Chi M J R aReq ξReq : ℝ) * 4 ^ eA := by
    rw [← h2]
    ring
  rw [e1, e2, e3] at hmain
  exact hmain

/-- Pure-real substitution behind `adaN_le_of_bounds`. -/
theorem adaN_subst_real {P X A K L E : ℝ} (hP1 : 1 ≤ P) (hX1 : 1 ≤ X) (hA0 : 0 ≤ A) (hK0 : 0 ≤ K)
    (hL : 1 ≤ L) (hE : 1 ≤ E) (hP : P ≤ 2 ^ 12 * L) (hX : X ≤ 2 ^ 12 * L) (hA : A ≤ 2 ^ 21 * E * L)
    (hK : K ≤ 2 ^ 13 * E ^ 2 * L ^ 3) :
    2 ^ 45 * (((P ^ 3 * Real.sqrt P * A ^ 2 + P * Real.sqrt P * Real.sqrt K * A) *
        (X * Real.sqrt X)) + P ^ 3 * X * A ^ 2) ≤ 2 ^ 199 * E ^ 2 * L ^ 7 := by
  have hL0 : 0 ≤ L := by linarith
  have hP0 : 0 ≤ P := by linarith
  have hX0 : 0 ≤ X := by linarith
  set s := Real.sqrt L with hs
  have hs0 : 0 ≤ s := Real.sqrt_nonneg L
  have hss : s ^ 2 = L := Real.sq_sqrt hL0
  have hs1 : 1 ≤ s := by rw [hs, Real.one_le_sqrt]; exact hL
  have hsL : s ≤ L := by nlinarith
  -- square-root bounds
  have hsP : Real.sqrt P ≤ 2 ^ 6 * s := by
    rw [Real.sqrt_le_left (by positivity), mul_pow, hss]
    norm_num
    linarith
  have hsX : Real.sqrt X ≤ 2 ^ 6 * s := by
    rw [Real.sqrt_le_left (by positivity), mul_pow, hss]
    norm_num
    linarith
  have hsK : Real.sqrt K ≤ 2 ^ 7 * E * L * s := by
    rw [Real.sqrt_le_left (by positivity)]
    have e : (2 ^ 7 * E * L * s) ^ 2 = 2 ^ 14 * E ^ 2 * L ^ 3 := by
      rw [mul_pow, hss]
      ring
    rw [e]
    have : (0 : ℝ) ≤ E ^ 2 * L ^ 3 := by positivity
    nlinarith
  have hsP0 : 0 ≤ Real.sqrt P := Real.sqrt_nonneg _
  have hsX0 : 0 ≤ Real.sqrt X := Real.sqrt_nonneg _
  have hsK0 : 0 ≤ Real.sqrt K := Real.sqrt_nonneg _
  have hE0 : 0 ≤ E := by linarith
  -- term 1
  have t1 : P ^ 3 * Real.sqrt P * A ^ 2 * (X * Real.sqrt X) ≤
      (2 ^ 12 * L) ^ 3 * (2 ^ 6 * s) * (2 ^ 21 * E * L) ^ 2 * ((2 ^ 12 * L) * (2 ^ 6 * s)) := by
    gcongr
  have t1' : (2 ^ 12 * L) ^ 3 * (2 ^ 6 * s) * (2 ^ 21 * E * L) ^ 2 * ((2 ^ 12 * L) * (2 ^ 6 * s)) =
      2 ^ 102 * E ^ 2 * L ^ 7 := by
    have : (2 ^ 12 * L) ^ 3 * (2 ^ 6 * s) * (2 ^ 21 * E * L) ^ 2 * ((2 ^ 12 * L) * (2 ^ 6 * s)) =
        2 ^ 102 * E ^ 2 * L ^ 6 * s ^ 2 := by ring
    rw [this, hss]
    ring
  -- term 2
  have t2 : P * Real.sqrt P * Real.sqrt K * A * (X * Real.sqrt X) ≤
      (2 ^ 12 * L) * (2 ^ 6 * s) * (2 ^ 7 * E * L * s) * (2 ^ 21 * E * L) *
        ((2 ^ 12 * L) * (2 ^ 6 * s)) := by
    gcongr
  have t2' : (2 ^ 12 * L) * (2 ^ 6 * s) * (2 ^ 7 * E * L * s) * (2 ^ 21 * E * L) *
      ((2 ^ 12 * L) * (2 ^ 6 * s)) ≤ 2 ^ 64 * E ^ 2 * L ^ 7 := by
    have e : (2 ^ 12 * L) * (2 ^ 6 * s) * (2 ^ 7 * E * L * s) * (2 ^ 21 * E * L) *
        ((2 ^ 12 * L) * (2 ^ 6 * s)) = 2 ^ 64 * E ^ 2 * L ^ 5 * s := by
      have : (2 ^ 12 * L) * (2 ^ 6 * s) * (2 ^ 7 * E * L * s) * (2 ^ 21 * E * L) *
          ((2 ^ 12 * L) * (2 ^ 6 * s)) = 2 ^ 64 * E ^ 2 * L ^ 4 * s ^ 2 * s := by ring
      rw [this, hss]
      ring
    rw [e]
    have hL5 : 0 ≤ 2 ^ 64 * E ^ 2 * L ^ 5 := by positivity
    have hLL : L ^ 5 * s ≤ L ^ 7 := by
      have : s ≤ L ^ 2 := by nlinarith
      calc L ^ 5 * s ≤ L ^ 5 * L ^ 2 := by gcongr
        _ = L ^ 7 := by ring
    nlinarith
  -- term 3
  have t3 : P ^ 3 * X * A ^ 2 ≤ (2 ^ 12 * L) ^ 3 * (2 ^ 12 * L) * (2 ^ 21 * E * L) ^ 2 := by
    gcongr
  have t3' : (2 ^ 12 * L) ^ 3 * (2 ^ 12 * L) * (2 ^ 21 * E * L) ^ 2 ≤ 2 ^ 90 * E ^ 2 * L ^ 7 := by
    have e : (2 ^ 12 * L) ^ 3 * (2 ^ 12 * L) * (2 ^ 21 * E * L) ^ 2 = 2 ^ 90 * E ^ 2 * L ^ 6 := by
      ring
    rw [e]
    have : L ^ 6 ≤ L ^ 7 := pow_le_pow_right₀ hL (by norm_num)
    have h0 : 0 ≤ 2 ^ 90 * E ^ 2 := by positivity
    nlinarith
  have hsum : ((P ^ 3 * Real.sqrt P * A ^ 2 + P * Real.sqrt P * Real.sqrt K * A) *
      (X * Real.sqrt X)) + P ^ 3 * X * A ^ 2 ≤ 2 ^ 103 * E ^ 2 * L ^ 7 := by
    have e : ((P ^ 3 * Real.sqrt P * A ^ 2 + P * Real.sqrt P * Real.sqrt K * A) *
        (X * Real.sqrt X)) + P ^ 3 * X * A ^ 2 =
        P ^ 3 * Real.sqrt P * A ^ 2 * (X * Real.sqrt X) +
          P * Real.sqrt P * Real.sqrt K * A * (X * Real.sqrt X) + P ^ 3 * X * A ^ 2 := by ring
    rw [e]
    have hEL : 0 ≤ E ^ 2 * L ^ 7 := by positivity
    nlinarith
  have hEL : 0 ≤ E ^ 2 * L ^ 7 := by positivity
  nlinarith

/-- **Size bound for Part III**: if `p, χ ≤ 2^12 L`, `2^{eA} ≤ 2^21 E L` and `J+R+1 ≤ 2^13 E² L³` (with
`L, E ≥ 1`), then the computable sample size is `N ≤ 2^199 E² L^7`. -/
theorem adaN_le_of_bounds (M J R : ℕ) {eA eXi : ℕ} (hA : 4 ≤ eA) (hXi : 2 ≤ eXi) {L E : ℝ}
    (hL : 1 ≤ L) (hE : 1 ≤ E) (hP : (adaP eA : ℝ) ≤ 2 ^ 12 * L)
    (hX : (adaChi M J R eA eXi : ℝ) ≤ 2 ^ 12 * L) (hAb : (2 : ℝ) ^ eA ≤ 2 ^ 21 * E * L)
    (hK : (J : ℝ) + R + 1 ≤ 2 ^ 13 * E ^ 2 * L ^ 3) :
    ((adaBlockSizes M J R eA eXi).sum : ℝ) ≤ 2 ^ 199 * E ^ 2 * L ^ 7 := by
  have h := adaN_le_explicit M J R hA hXi
  have hP1 : (1 : ℝ) ≤ adaP eA := by
    have := twelve_le_adaP hA
    have : (12 : ℝ) ≤ adaP eA := by exact_mod_cast this
    linarith
  have hX1 : (1 : ℝ) ≤ adaChi M J R eA eXi := by
    have : 1 ≤ adaChi M J R eA eXi := by unfold adaChi; omega
    exact_mod_cast this
  have e4 : (4 : ℝ) ^ eA = ((2 : ℝ) ^ eA) ^ 2 := by
    rw [← pow_mul, mul_comm, pow_mul]
    norm_num
  rw [e4] at h
  exact h.trans (adaN_subst_real hP1 hX1 (by positivity) (by positivity) hL hE hP hX hAb hK)

end F2e2e.B
