import F2e2e.B.PrivacyNum
import F2e2e.B.PrivacyAdv
import F2e2e.B.ArchCount

/-!
# Theorem `R:thm:validation_ada`, privacy pillar (P4): from the ideal lattice laws to the samplers

Paper: `parts/partII.tex` L1026–1030 ("(P4) … Lemma `R:lem:sec3_sampler` gives TV at most `ζ` per draw;
the first-disagreement coupling over at most `Q` draws gives TV at most `Qζ = δ/1000` between the actual
and the ideal executions; hence the actual mechanism is `(ϑ_j, δ/16 + (1 + e^{ϑ_j/4}) δ/1000)` and therefore
`(ϑ_j, δ)`-DP in block `j`").

* `adaDraw_tv_lt`: one bounded-sampler draw of kind `κ` is within TV `ζ` of its ideal lattice law
  (`tv_latticeSampler_lt`, Lemma `R:lem:sec3_sampler`);
* `core_tv_ideal`: the online execution with the bounded samplers is within TV `Qζ = δ/1000` of its
  interpretation by the ideal laws (`DrawProg.tv_toBits_le`, B-ARCH's `coreRunD_drawsLE_Q`);
* `block_dp_of_ideal`: per-block `(ϑ_j/4, δ/16)`-indistinguishability of the ideal laws gives
  `CoreBlockDP` (`PIndist.tv_transfer`, `priv_final`).
-/

namespace F2e2e.B.Priv

open F2e2e.B F2e2e.Discrete

/-- **Lemma `R:lem:sec3_sampler`** for one draw of the core: the bounded lattice sampler of kind `κ` is
within TV `ζ` of the ideal lattice law. -/
theorem adaDraw_tv_lt {P : AdaParams} (κ : NoiseKind) (hb : 0 < P.scale κ) (hA0 : 0 < P.hA)
    (hζ : 0 < P.zeta) (hB0 : P.B0 = Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊) :
    tv (adaDraw P κ).law (idealLaw P κ) < ENNReal.ofReal (P.zeta : ℝ) := by
  set b := P.scale κ with hbdef
  have hbR : (0 : ℝ) < (b : ℝ) := by exact_mod_cast hb
  have hAR : (0 : ℝ) < (P.hA : ℝ) := by exact_mod_cast hA0
  have hζR : (0 : ℝ) < (P.zeta : ℝ) := by exact_mod_cast hζ
  have hρpos : 0 < P.rho b := by unfold AdaParams.rho; positivity
  have hρ : (((P.rho b).num.toNat : ℕ) : ℝ) / ((P.rho b).den : ℝ) = latticeRho (b : ℝ) (P.hA : ℝ) := by
    have hnum : 0 ≤ (P.rho b).num := Rat.num_nonneg.mpr hρpos.le
    have h1 : (((P.rho b).num.toNat : ℕ) : ℝ) = (((P.rho b).num : ℤ) : ℝ) := by
      rw [← Int.cast_natCast, Int.toNat_of_nonneg hnum]
    rw [h1, ← Rat.cast_def]
    unfold AdaParams.rho latticeRho
    push_cast
    ring
  have hB : 16 / (P.zeta : ℝ) ≤ 2 ^ P.B0 := by
    rw [hB0]
    have h1 : ((16 : ℚ) / P.zeta : ℚ) ≤ (⌈(16 : ℚ) / P.zeta⌉₊ : ℚ) := Nat.le_ceil _
    have h2 : ⌈(16 : ℚ) / P.zeta⌉₊ ≤ 2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ :=
      Nat.le_pow_clog (by norm_num) _
    have h3 : (((16 : ℚ) / P.zeta : ℚ) : ℝ) ≤ ((2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ : ℕ) : ℝ) := by
      have h4 : ((16 : ℚ) / P.zeta : ℚ) ≤ ((2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ : ℕ) : ℚ) :=
        h1.trans (by exact_mod_cast h2)
      exact_mod_cast h4
    push_cast at h3
    exact h3
  have hK : ((b : ℝ) + P.hA) / P.hA * (P.B0 : ℝ) ≤ (P.Ks b : ℝ) := by
    have h1 : ((b + P.hA) / P.hA * P.B0 : ℚ) ≤ (P.Ks b : ℚ) := Nat.le_ceil _
    have h2 : (((b + P.hA) / P.hA * P.B0 : ℚ) : ℝ) ≤ ((P.Ks b : ℚ) : ℝ) := by exact_mod_cast h1
    push_cast at h2
    exact h2
  have hr : 32 * ((P.Ks b : ℝ) + 1) / P.zeta ≤ 2 ^ P.rs b := by
    have h1 : (32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) ≤ (⌈32 * ((P.Ks b : ℚ) + 1) / P.zeta⌉₊ : ℚ) :=
      Nat.le_ceil _
    have h2 : ⌈32 * ((P.Ks b : ℚ) + 1) / P.zeta⌉₊ ≤ 2 ^ P.rs b := Nat.le_pow_clog (by norm_num) _
    have h3 : ((32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) : ℝ) ≤ ((2 ^ P.rs b : ℕ) : ℝ) := by
      have h4 : (32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) ≤ ((2 ^ P.rs b : ℕ) : ℚ) :=
        h1.trans (Nat.cast_le.mpr h2)
      exact_mod_cast h4
    push_cast at h3
    exact h3
  exact tv_latticeSampler_lt hbR hAR hζR hρ hB hK hr

section Instance

variable (M J R : ℕ) {aReq ξReq : ℝ}

theorem priv_scale_pos (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (κ : NoiseKind) : 0 < (adaAlg2Params M J R aReq ξReq).scale κ := by
  obtain ⟨-, hI, hO, hN, -, -⟩ := priv_pos M J R ha0 ha1 hξ0 hξ1
  cases κ
  · show 0 < 2 * (adaAlg2Params M J R aReq ξReq).bInt
    positivity
  · show 0 < 4 * (adaAlg2Params M J R aReq ξReq).bInt
    positivity
  · show 0 < 2 * (adaAlg2Params M J R aReq ξReq).bOut
    positivity
  · show 0 < 4 * (adaAlg2Params M J R aReq ξReq).bOut
    positivity
  · exact hN

/-- **(P4) coupling** (`partII.tex` L1026–1028): the online execution with the bounded samplers is within
TV `Qζ = δ/1000` of its interpretation by the ideal lattice laws. -/
theorem core_tv_ideal (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {U : Type} (ctrl : CoreCtrl U) (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) (T : ℕ) :
    tv (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law
        (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
          (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T)) ≤
      ENNReal.ofReal (accDelta aReq ξReq / 1000) := by
  obtain ⟨hA0, -, -, -, hζ, -⟩ := priv_pos M J R ha0 ha1 hξ0 hξ1
  rw [coreRun_eq_toBits]
  calc tv ((coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T).toBits
          (adaDraw (adaAlg2Params M J R aReq ξReq))).law
        (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
          (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T))
      ≤ (adaQ M J R (dyadicExp aReq) : ENNReal) *
          ENNReal.ofReal ((adaAlg2Params M J R aReq ξReq).zeta : ℝ) :=
        DrawProg.tv_toBits_le (adaDraw _) (idealLaw _)
          (fun κ => (adaDraw_tv_lt κ (priv_scale_pos M J R ha0 ha1 hξ0 hξ1 κ) hA0 hζ rfl).le)
          (coreRunD_drawsLE_Q M J R aReq ξReq ctrl s T)
    _ = ENNReal.ofReal ((adaQ M J R (dyadicExp aReq) : ℝ) * ((adaAlg2Params M J R aReq ξReq).zeta : ℝ)) := by
        rw [ENNReal.ofReal_mul (Nat.cast_nonneg _), ENNReal.ofReal_natCast]
    _ = ENNReal.ofReal (accDelta aReq ξReq / 1000) := by
        rw [priv_Qzeta M J R ha0 ha1 hξ0 hξ1]

/-- **(P4) transfer** (`partII.tex` L1026–1030): per-block `(ϑ_j/4, δ/16)`-indistinguishability of the
online execution under the ideal lattice laws gives the per-block DP of the actual core (`CoreBlockDP`). -/
theorem block_dp_of_ideal (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (hideal : ∀ (U : Type) (ctrl : CoreCtrl U) (T j : ℕ), j ≤ (adaAlg2Params M J R aReq ξReq).p →
      ∀ s s' : Fin (adaAlg2Params M J R aReq ξReq).N → U, BlockNeighbor (adaAlg2Params M J R aReq ξReq) j s s' →
        PIndist (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
            (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T))
          (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
            (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s' T))
          (accVartheta aReq j / 4) (accDelta aReq ξReq / 16)) :
    CoreBlockDP M J R aReq ξReq := by
  intro U _ ctrl _ T j hj s s' hss E
  have hid := hideal U ctrl T j hj s s' hss
  have hδ := (priv_pos M J R ha0 ha1 hξ0 hξ1).2.2.2.2.2
  have hϑ := (priv_vartheta_mem aReq j).1
  have h := PIndist.tv_transfer (by positivity) (by positivity)
    (core_tv_ideal M J R ha0 ha1 hξ0 hξ1 ctrl s T)
    (by rw [tv_comm]; exact core_tv_ideal M J R ha0 ha1 hξ0 hξ1 ctrl s' T) hid
  exact (h.mono (by linarith) (priv_final ha0 ha1 hξ0 hξ1 j)) E

end Instance

end F2e2e.B.Priv
