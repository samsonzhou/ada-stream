import F2e2e.B.ArchParams
import F2e2e.B.NumericsCert

/-!
# Bridges: the computable parameters `adaParams` = the paper form of Definition `R:def:sec3_ada_params`

For requested accuracy `aReq ∈ (0, 1/10)` and failure probability `ξReq ∈ (0, 1/2)`, the exact
`ℕ`/`ℚ` parameters `adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R` of `F2e2e/B/ArchParams.lean`
(used by the mechanism) coincide with the real paper-form parameters `alg2*` of
`F2e2e/B/Params.lean` (`parts/partII.tex` L666–716). The headline uses `adaParams_N_eq` (the
mechanism's sample size is the paper's `N = ∑_{j=0}^p n_j`, bounded by B-NUM's
`alg2_N_le_explicit`/`alg2_N_le_asymp`); the analysis uses the others.

Owner: B-NUM (statements by B-ARCH; do not change them without telling B-ARCH).

Helper lemmas (B-NUM): `natCeil_ratCast` (`⌈(q:ℝ)⌉₊ = ⌈q⌉₊`), `list_sum_map_range`,
`list_foldl_max_map_range`, `ceil_logb_eq_clog` (`⌈log₂ y⌉₊ = clog₂ ⌈y⌉₊`), `ceil_logb_natCast`,
`clog_two_pow_mul` (`clog₂(2^m x) = m + clog₂ x`), `ceilSqrt_eq` (`ceilSqrt m = ⌈√m⌉₊`),
`ada_cond_iff`, `one_div_alg2H_eq_adaHInv`, `adaTmaxZ_eq`, `adaMaxN_eq`, `inv_min_of_pos`,
`alg2Zeta_pos` (`one_le_alg2NBlock`, `one_le_alg2MaxN` come from `F2e2e.B.NumericsCert`).
-/

namespace F2e2e.B

/-! ### General helpers -/

/-- `⌈(q : ℝ)⌉₊ = ⌈q⌉₊` for `q : ℚ`. -/
theorem natCeil_ratCast (q : ℚ) : ⌈(q : ℝ)⌉₊ = ⌈q⌉₊ := by
  apply le_antisymm
  · apply Nat.ceil_le.mpr
    have h := Nat.le_ceil q
    exact_mod_cast h
  · apply Nat.ceil_le.mpr
    have h := Nat.le_ceil (q : ℝ)
    exact_mod_cast h

/-- `((List.range n).map f).sum = ∑_{i<n} f i`. -/
theorem list_sum_map_range (n : ℕ) (f : ℕ → ℕ) :
    ((List.range n).map f).sum = ∑ i ∈ Finset.range n, f i := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [List.range_succ, List.map_append, List.sum_append, ih, Finset.sum_range_succ]
    simp

/-- `((List.range n).map f).foldl max 0 = sup_{i<n} f i`. -/
theorem list_foldl_max_map_range (n : ℕ) (f : ℕ → ℕ) :
    ((List.range n).map f).foldl max 0 = (Finset.range n).sup f := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [List.range_succ, List.map_append, List.foldl_append, ih, Finset.range_add_one,
      Finset.sup_insert]
    simp only [List.map_cons, List.map_nil, List.foldl_cons, List.foldl_nil]
    rw [max_comm]

/-- `⌈log₂ y⌉₊ = clog₂ ⌈y⌉₊` for `y > 0`. -/
theorem ceil_logb_eq_clog (y : ℝ) (hy : 0 < y) : ⌈Real.logb 2 y⌉₊ = Nat.clog 2 ⌈y⌉₊ := by
  have h := dyadicExp_eq_ceil_logb (x := y⁻¹) (inv_pos.mpr hy)
  rw [inv_inv] at h
  unfold dyadicExp at h
  rw [inv_inv] at h
  exact h.symm

/-- `⌈log₂ n⌉₊ = clog₂ n` for a natural `n ≥ 1`. -/
theorem ceil_logb_natCast (n : ℕ) (hn : 1 ≤ n) : ⌈Real.logb 2 (n : ℝ)⌉₊ = Nat.clog 2 n := by
  rw [ceil_logb_eq_clog _ (by exact_mod_cast hn), Nat.ceil_natCast]

/-- `clog₂(2^m x) = m + clog₂ x` for `x ≥ 1`. -/
theorem clog_two_pow_mul (m x : ℕ) (hx : 1 ≤ x) : Nat.clog 2 (2 ^ m * x) = m + Nat.clog 2 x := by
  apply le_antisymm
  · apply Nat.clog_le_of_le_pow
    rw [pow_add]
    exact Nat.mul_le_mul_left _ (Nat.le_pow_clog (by norm_num) x)
  · rcases Nat.eq_zero_or_pos (Nat.clog 2 x) with h0 | hpos
    · rw [h0, add_zero]
      have h1 : 2 ^ m ≤ 2 ^ m * x := Nat.le_mul_of_pos_right _ hx
      calc m = Nat.clog 2 (2 ^ m) := (Nat.clog_pow 2 m (by norm_num)).symm
        _ ≤ Nat.clog 2 (2 ^ m * x) := Nat.clog_mono_right 2 h1
    · have hx1 : 1 < x := by
        by_contra hc
        have := Nat.clog_of_right_le_one (not_lt.mp hc) 2
        omega
      have hlt := Nat.pow_pred_clog_lt_self (by norm_num : 1 < 2) hx1
      rw [Nat.pred_eq_sub_one] at hlt
      have h3 : m + (Nat.clog 2 x - 1) < Nat.clog 2 (2 ^ m * x) := by
        rw [Nat.lt_clog_iff_pow_lt (by norm_num), pow_add]
        exact (Nat.mul_lt_mul_left (by positivity)).mpr hlt
      omega

/-- `ceilSqrt m = ⌈√m⌉₊`. -/
theorem ceilSqrt_eq (m : ℕ) : ceilSqrt m = ⌈Real.sqrt (m : ℝ)⌉₊ := by
  unfold ceilSqrt
  split_ifs with h
  · have hs : Real.sqrt (m : ℝ) = (Nat.sqrt m : ℝ) := by
      rw [Real.sqrt_eq_iff_mul_self_eq (Nat.cast_nonneg _) (Nat.cast_nonneg _)]
      exact_mod_cast h.symm
    rw [hs, Nat.ceil_natCast]
  · have hle : Nat.sqrt m * Nat.sqrt m ≤ m := Nat.sqrt_le m
    have hlt : Nat.sqrt m * Nat.sqrt m < m := lt_of_le_of_ne hle h
    symm
    rw [Nat.ceil_eq_iff (by omega)]
    constructor
    · rw [Nat.add_sub_cancel, Real.lt_sqrt (Nat.cast_nonneg _)]
      have : ((Nat.sqrt m * Nat.sqrt m : ℕ) : ℝ) < (m : ℝ) := by exact_mod_cast hlt
      push_cast at this
      nlinarith
    · push_cast
      exact Real.real_sqrt_le_nat_sqrt_succ

/-- `(min x y)⁻¹ = max x⁻¹ y⁻¹` for `x, y > 0`. -/
theorem inv_min_of_pos {x y : ℝ} (hx : 0 < x) (hy : 0 < y) : (min x y)⁻¹ = max x⁻¹ y⁻¹ := by
  rcases le_total x y with h | h
  · rw [min_eq_left h, max_eq_left (inv_anti₀ hx h)]
  · rw [min_eq_right h, max_eq_right (inv_anti₀ hy h)]

/-! ### `p` -/

/-- At `a = 2^{-k}` the defining condition `1 ≤ 4^{p-1}(a/(8p))²` of `valP` is `p·2^{k+3} ≤ 2^{p-1}`. -/
theorem ada_cond_iff (k p : ℕ) (hp : 1 ≤ p) :
    1 ≤ (4 : ℝ) ^ (p - 1) * ((1 / 2 : ℝ) ^ k / (8 * (p : ℝ))) ^ 2 ↔
      p * 2 ^ (k + 3) ≤ 2 ^ (p - 1) := by
  rw [valPCond_iff (by positivity) hp]
  have h2k : (0 : ℝ) < 2 ^ k := by positivity
  have e : (2 : ℝ) ^ (p - 1) * (1 / 2) ^ k = 2 ^ (p - 1) / 2 ^ k := by
    rw [one_div, inv_pow, div_eq_mul_inv]
  rw [e, le_div_iff₀ h2k]
  have e2 : ((p * 2 ^ (k + 3) : ℕ) : ℝ) = 8 * (p : ℝ) * 2 ^ k := by
    push_cast
    ring
  constructor
  · intro h
    have : ((p * 2 ^ (k + 3) : ℕ) : ℝ) ≤ ((2 ^ (p - 1) : ℕ) : ℝ) := by
      rw [e2]
      push_cast
      linarith
    exact_mod_cast this
  · intro h
    have : ((p * 2 ^ (k + 3) : ℕ) : ℝ) ≤ ((2 ^ (p - 1) : ℕ) : ℝ) := by exact_mod_cast h
    rw [e2] at this
    push_cast at this
    linarith

theorem adaP_eq (aReq : ℝ) : adaP (dyadicExp aReq) = alg2P aReq := by
  have hapos := alg2A_pos aReq
  apply le_antisymm
  · apply Nat.find_min'
    have hm := valP_mem hapos
    have hp2 : 2 ≤ alg2P aReq := hm.1
    refine ⟨hp2, ?_⟩
    exact (ada_cond_iff (dyadicExp aReq) (alg2P aReq) (by omega)).mp hm.2
  · show sInf (valPSet (alg2A aReq)) ≤ adaP (dyadicExp aReq)
    apply Nat.sInf_le
    have hs := Nat.find_spec (exists_adaP (dyadicExp aReq))
    have hp2 : 2 ≤ adaP (dyadicExp aReq) := hs.1
    refine ⟨hp2, ?_⟩
    exact (ada_cond_iff (dyadicExp aReq) (adaP (dyadicExp aReq)) (by omega)).mpr hs.2

/-! ### `τ`, `h`, `κ`, `T_j^max`, `C_j`, `Q` -/

theorem adaTau_cast (aReq : ℝ) : ((adaTauQ (dyadicExp aReq) : ℚ) : ℝ) = alg2Tau aReq := by
  unfold adaTauQ
  push_cast
  rw [adaA_cast, adaP_eq]
  rfl

theorem adaH_cast (aReq : ℝ) : ((adaH (dyadicExp aReq) : ℚ) : ℝ) = alg2H aReq := by
  unfold adaH
  push_cast
  rw [adaTau_cast]
  rfl

theorem adaKappa_cast (aReq : ℝ) : ((adaKappa (dyadicExp aReq) : ℚ) : ℝ) = alg2Kappa aReq := by
  unfold adaKappa alg2Kappa
  push_cast
  rw [adaTau_cast]

theorem adaTmax_eq (aReq : ℝ) (j : ℕ) : adaTmax (dyadicExp aReq) j = alg2Tmax aReq j := by
  unfold adaTmax alg2Tmax
  rw [adaP_eq]
  split_ifs with hj
  · rw [← natCeil_ratCast]
    push_cast
    rw [adaTau_cast]
    rfl
  · rfl

theorem adaTmaxZ_eq (aReq : ℝ) (z : ℤ) : adaTmaxZ (dyadicExp aReq) z = alg2TmaxZ aReq z := by
  unfold adaTmaxZ alg2TmaxZ
  rw [adaTmax_eq]

theorem adaC_eq (J R : ℕ) (aReq : ℝ) (j : ℕ) : adaC J R (dyadicExp aReq) j = alg2C J R aReq j := by
  unfold adaC alg2C
  simp only [adaTmax_eq, adaTmaxZ_eq, adaP_eq]

theorem adaQ_eq (M J R : ℕ) (aReq : ℝ) : adaQ M J R (dyadicExp aReq) = alg2Q M J R aReq := by
  unfold adaQ adaTmaxList
  rw [list_sum_map_range, adaP_eq]
  show 100 * (alg2P aReq + 1) *
      (M + R + J + 2 + ∑ i ∈ Finset.range (alg2P aReq), adaTmax (dyadicExp aReq) i) =
    100 * (alg2P aReq + 1) *
      (M + R + J + 2 + ∑ j ∈ Finset.range (alg2P aReq), valTmax (alg2A aReq) j)
  congr 2
  apply Finset.sum_congr rfl
  intro j hj
  rw [adaTmax_eq, alg2Tmax_of_lt (Finset.mem_range.mp hj)]

/-! ### `χ` -/

theorem adaChi_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) = alg2Chi M J R aReq ξReq := by
  have _hyp : 0 < aReq ∧ aReq < 1 / 10 ∧ 0 < ξReq ∧ ξReq < 1 / 2 := ⟨ha0, ha1, hξ0, hξ1⟩
  unfold adaChi
  rw [adaP_eq, adaQ_eq]
  have hp0 : 0 < alg2P aReq := by have := two_le_alg2P aReq; omega
  have hQ0 : 0 < alg2Q M J R aReq := valQ_pos M J R (alg2A_pos aReq)
  have hx : 1 ≤ alg2P aReq * (alg2P aReq + 1) * alg2Q M J R aReq :=
    Nat.mul_pos (Nat.mul_pos hp0 (Nat.succ_pos _)) hQ0
  have hp : (0 : ℝ) < alg2P aReq := by exact_mod_cast hp0
  have key : 2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) /
      (alg2H aReq * alg2XiA ξReq) =
      ((2 ^ (49 + dyadicExp aReq + dyadicExp ξReq) *
        (alg2P aReq * (alg2P aReq + 1) * alg2Q M J R aReq) : ℕ) : ℝ) := by
    have hH : alg2H aReq = (1 / 2 : ℝ) ^ dyadicExp aReq / (512 * (alg2P aReq : ℝ)) :=
      valH_eq _
    have hXi : alg2XiA ξReq = (1 / 2 : ℝ) ^ dyadicExp ξReq := rfl
    rw [hH, hXi, one_div_pow, one_div_pow]
    push_cast
    rw [pow_add, pow_add]
    field_simp
    ring
  show _ = ⌈Real.logb 2 (2 ^ 40 * ((alg2P aReq : ℝ) + 1) *
    (alg2Q M J R aReq : ℝ) / (alg2H aReq * alg2XiA ξReq))⌉₊
  rw [key, ceil_logb_natCast _ (Nat.one_le_iff_ne_zero.mpr (by positivity)),
    clog_two_pow_mul _ _ hx]

/-! ### `d_j`, `1/h`, block sizes, `N` -/

/-- `1/h = adaHInv = 512 p 2^{eA}`. -/
theorem one_div_alg2H_eq_adaHInv (aReq : ℝ) :
    1 / alg2H aReq = (adaHInv (dyadicExp aReq) : ℝ) := by
  unfold adaHInv
  rw [adaP_eq, one_div_alg2H]
  push_cast
  have ha : alg2A aReq = (1 / 2 : ℝ) ^ dyadicExp aReq := rfl
  rw [ha, one_div_pow]
  field_simp

theorem adaD_eq (aReq : ℝ) (j : ℕ) : adaD (dyadicExp aReq) j = alg2D aReq j := by
  unfold adaD alg2D
  rw [adaP_eq]
  split_ifs with hj
  · rw [ceilSqrt_eq]
    push_cast
    rfl
  · have hh := alg2H_pos aReq
    have e : 4 / alg2H aReq = ((2 ^ (dyadicExp aReq + 11) * alg2P aReq : ℕ) : ℝ) := by
      have h1 := one_div_alg2H_eq_adaHInv aReq
      unfold adaHInv at h1
      rw [adaP_eq] at h1
      have e1 : 4 / alg2H aReq = 4 * (1 / alg2H aReq) := by ring
      rw [e1, h1]
      push_cast
      rw [pow_add]
      ring
    rw [e, Nat.ceil_natCast]

theorem adaNBlock_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (j : ℕ) :
    adaNBlock M J R (dyadicExp aReq) (dyadicExp ξReq) j = alg2NBlock M J R aReq ξReq j := by
  unfold adaNBlock alg2NBlock
  rw [adaChi_eq M J R ha0 ha1 hξ0 hξ1, adaD_eq, adaC_eq, ceilSqrt_eq]
  have hH := one_div_alg2H_eq_adaHInv aReq
  have hh := alg2H_pos aReq
  have e : (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) /
          alg2H aReq +
      (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 =
      ((2 ^ 20 * alg2Chi M J R aReq ξReq * alg2D aReq j *
          ⌈Real.sqrt (((alg2C J R aReq j * alg2Chi M J R aReq ξReq : ℕ) : ℝ))⌉₊ *
          adaHInv (dyadicExp aReq) +
        2 ^ 12 * alg2Chi M J R aReq ξReq * adaHInv (dyadicExp aReq) ^ 2 : ℕ) : ℝ) := by
    push_cast
    rw [← hH]
    field_simp
    ring
  rw [e, Nat.ceil_natCast]

/-- The sample size of the computable instance is the paper's `N = ∑_{j=0}^p n_j`. -/
theorem adaParams_N_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).N = alg2N M J R aReq ξReq := by
  show (adaBlockSizes M J R (dyadicExp aReq) (dyadicExp ξReq)).sum = alg2N M J R aReq ξReq
  unfold adaBlockSizes alg2N
  rw [list_sum_map_range, adaP_eq]
  apply Finset.sum_congr rfl
  intro j _
  exact adaNBlock_eq M J R ha0 ha1 hξ0 hξ1 j

/-! ### `h_A` -/

theorem adaMaxN_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaMaxN M J R (dyadicExp aReq) (dyadicExp ξReq) = alg2MaxN M J R aReq ξReq := by
  unfold adaMaxN adaBlockSizes alg2MaxN
  rw [list_foldl_max_map_range, adaP_eq]
  apply Finset.sup_congr rfl
  intro j _
  exact adaNBlock_eq M J R ha0 ha1 hξ0 hξ1 j

theorem adaQA_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaQA M J R (dyadicExp aReq) (dyadicExp ξReq) = alg2HAExp M J R aReq ξReq := by
  unfold adaQA
  rw [show alg2HAExp M J R aReq ξReq = Nat.clog 2 ⌈(alg2HABound M J R aReq ξReq)⁻¹⌉₊ from rfl]
  rw [adaP_eq, adaChi_eq M J R ha0 ha1 hξ0 hξ1, adaMaxN_eq M J R ha0 ha1 hξ0 hξ1]
  have hp0 : 0 < alg2P aReq := by have := two_le_alg2P aReq; omega
  have hχ := one_le_alg2Chi M J R aReq ξReq
  have hmax := one_le_alg2MaxN M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hx : 1 ≤ alg2P aReq * (alg2P aReq + 1) * alg2Chi M J R aReq ξReq :=
    Nat.mul_pos (Nat.mul_pos hp0 (Nat.succ_pos _)) hχ
  have hp : (0 : ℝ) < alg2P aReq := by exact_mod_cast hp0
  have hχr : (0 : ℝ) < alg2Chi M J R aReq ξReq := by exact_mod_cast hχ
  have hmr : (0 : ℝ) < alg2MaxN M J R aReq ξReq := by exact_mod_cast hmax
  have hA : (alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
      (alg2Chi M J R aReq ξReq : ℝ)))⁻¹ =
      ((2 ^ (29 + dyadicExp aReq) * (alg2P aReq * (alg2P aReq + 1) * alg2Chi M J R aReq ξReq) :
        ℕ) : ℝ) := by
    have h1 := one_div_alg2H_eq_adaHInv aReq
    unfold adaHInv at h1
    rw [adaP_eq] at h1
    rw [inv_div]
    have e1 : (2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq =
        (2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) *
          (1 / alg2H aReq) := by ring
    rw [e1, h1]
    push_cast
    rw [pow_add]
    ring
  have hB : (1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)))⁻¹ =
      ((2 ^ 20 * alg2MaxN M J R aReq ξReq : ℕ) : ℝ) := by
    rw [one_div, inv_inv]
    push_cast
    ring
  have hpos1 : 0 < alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
      (alg2Chi M J R aReq ξReq : ℝ)) := by positivity
  have hpos2 : 0 < 1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)) := by positivity
  show _ = Nat.clog 2 ⌈(min (alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
      (alg2Chi M J R aReq ξReq : ℝ))) (1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ))))⁻¹⌉₊
  rw [inv_min_of_pos hpos1 hpos2, hA, hB, ← Nat.cast_max, Nat.ceil_natCast,
    Monotone.map_max (Nat.clog_monotone 2), clog_two_pow_mul _ _ hx,
    clog_two_pow_mul _ _ hmax]

theorem adaParams_hA_cast (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).hA : ℚ) : ℝ) = alg2HA M J R aReq ξReq := by
  show (((1 / 2 : ℚ) ^ adaQA M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) : ℝ) =
    (1 / 2 : ℝ) ^ alg2HAExp M J R aReq ξReq
  rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1]
  push_cast
  rfl

/-! ### Noise scales and sampler parameters -/

theorem adaParams_bInt_cast (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).bInt : ℚ) : ℝ) =
      alg2BInt M J R aReq ξReq := by
  show ((adaH (dyadicExp aReq) / (128 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)) : ℚ) : ℝ) =
    alg2H aReq / (128 * (alg2Chi M J R aReq ξReq : ℝ))
  push_cast
  rw [adaH_cast, adaChi_eq M J R ha0 ha1 hξ0 hξ1]

theorem adaParams_bOut_cast (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).bOut : ℚ) : ℝ) =
      alg2BOut M J R aReq ξReq := by
  show ((adaA (dyadicExp aReq) / (512 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)) : ℚ) : ℝ) =
    alg2A aReq / (512 * (alg2Chi M J R aReq ξReq : ℝ))
  push_cast
  rw [adaA_cast, adaChi_eq M J R ha0 ha1 hξ0 hξ1]

theorem adaParams_bNum_cast (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).bNum : ℚ) : ℝ) =
      alg2BNum M J R aReq ξReq := by
  show ((adaA (dyadicExp aReq) / (64 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)) : ℚ) : ℝ) =
    alg2A aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ))
  push_cast
  rw [adaA_cast, adaChi_eq M J R ha0 ha1 hξ0 hξ1]

theorem adaParams_zeta_cast (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).zeta : ℚ) : ℝ) =
      alg2Zeta M J R aReq ξReq := by
  have _hyp : 0 < aReq ∧ aReq < 1 / 10 ∧ 0 < ξReq ∧ ξReq < 1 / 2 := ⟨ha0, ha1, hξ0, hξ1⟩
  show ((adaZeta M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq
  unfold adaZeta adaDelta adaXiJ alg2Zeta alg2Delta alg2XiJ
  push_cast
  rw [adaH_cast, adaXiA_cast, adaP_eq, adaQ_eq]

theorem alg2Zeta_pos (M J R : ℕ) (aReq ξReq : ℝ) : 0 < alg2Zeta M J R aReq ξReq := by
  have hh := alg2H_pos aReq
  have hξ := alg2XiA_pos ξReq
  have hQ : (0 : ℝ) < alg2Q M J R aReq := by exact_mod_cast valQ_pos M J R (alg2A_pos aReq)
  unfold alg2Zeta alg2Delta alg2XiJ
  positivity

theorem adaParams_B0_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).B0 = alg2B0 M J R aReq ξReq := by
  have hz := adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1
  change ((adaZeta M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq at hz
  show Nat.clog 2 ⌈(16 : ℚ) / adaZeta M J R (dyadicExp aReq) (dyadicExp ξReq)⌉₊ =
    ⌈Real.logb 2 (16 / alg2Zeta M J R aReq ξReq)⌉₊
  have hpos := alg2Zeta_pos M J R aReq ξReq
  rw [ceil_logb_eq_clog _ (by positivity), ← hz,
    show (16 : ℝ) / ((adaZeta M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) : ℝ) =
      (((16 : ℚ) / adaZeta M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) : ℝ) by push_cast; ring,
    natCeil_ratCast]

end F2e2e.B
