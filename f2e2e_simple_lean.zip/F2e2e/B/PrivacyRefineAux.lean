import F2e2e.B.PrivacyRefine
import F2e2e.B.PrivacyRefineInit

/-!
# Refinement, auxiliary per-call lemmas: `adaNumericalD_rel`, `adaInitD_rel`

(Lines [16]–[18] and the initialization of Algorithm 2; see `F2e2e/B/PrivacyRefine.lean`.) The
proofs are in `F2e2e/B/PrivacyRefineInit.lean` (`adaNumericalD_rel_of_prep`, `adaInitD_rel'`).
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

variable {U : Type} (P : AdaParams) (s : Fin P.N → U)

theorem adaNumericalD_rel (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) (f : U → ℕ)
    (h : Rel P s st sk σ) :
    DrawRel (CallR P s) (adaNumericalD P st (valsOf P s f))
      (inlineSt (coreSpec P) (fun _ => s) (skNumericalD P sk f) σ) :=
  adaNumericalD_rel_of_prep P s f (prepareRoot_rel P s f) st sk σ h

theorem adaInitD_rel :
    DrawRel (fun st o => Rel P s st o.1 o.2) (adaInitD P)
      (inlineSt (coreSpec P) (fun _ => s) (skInitD (U := U) P) (fun _ => none)) :=
  adaInitD_rel' P s

end F2e2e.B.Priv
