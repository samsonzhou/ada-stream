import F2e2e.Spec

/-!
# Measurability of the Spec's validation interaction in the controller's coins

Generic facts about `F2e2e.vResponses`, `VCovered`, `VCorrect`, `VFails` (`F2e2e/Spec.lean` §2.2), used
to pass from deterministic to randomized controllers (`vGuarantee_of_det`, `F2e2e/B/Final.lean`):

* `VResponse` is countable;
* `vResponses_succ`, `vResponses_prefix`: the interaction transcript is built round by round and is
  prefix-consistent (STATEMENT_REVIEW §D: "prefix-consistency of the interaction transcripts");
* `measurableSet_vResponses_eq`: if the mechanism's responses are measurable in the views and the
  controller is measurable in its coins for each fixed history (the Spec's hypothesis), then each
  fibre `{ω | vResponses … (ctrl ω) … t = h}` is measurable;
* `covPred` (the coverage condition as a function of the request types and rejection flags),
  `measurableSet_vCorrect`, `vFails_iff` (the failure event through a fixed response history), and
  `measurableSet_vFails`: the failure event is measurable in the controller's coins.
-/

namespace F2e2e.B

open MeasureTheory

/-- Responses are countable. -/
def vRespCode : VResponse → ℚ ⊕ Fin 3
  | VResponse.accept => Sum.inr 0
  | VResponse.high => Sum.inr 1
  | VResponse.low => Sum.inr 2
  | VResponse.num q => Sum.inl q

theorem vRespCode_injective : Function.Injective vRespCode := by
  intro a b h
  cases a <;> cases b <;> simp_all [vRespCode]

instance : Countable VResponse := vRespCode_injective.countable

section Interaction

variable {U : Type} {N c : ℕ} (mech : VMechanism N c)

/-- The views of rounds `0..t` when the first `t` responses are `h`. -/
def viewsOf (ctrl : VController U) (s : Fin N → U) (t : ℕ) (h : Fin t → VResponse) :
    Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ :=
  fun j => ((fun ℓ => (ctrl j.val (fun l : Fin j.val =>
      h (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l))).1 (s ℓ)),
    (ctrl j.val (fun l : Fin j.val => h (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l))).2)

theorem vResponses_succ (ctrl : VController U) (s : Fin N → U) (ω : Fin c → Bool) (t : ℕ) :
    vResponses mech ctrl s ω (t + 1) =
      Fin.snoc (vResponses mech ctrl s ω t)
        (mech t (viewsOf ctrl s t (vResponses mech ctrl s ω t)) ω) := rfl

/-- Prefix consistency of the interaction. -/
theorem vResponses_prefix (ctrl : VController U) (s : Fin N → U) (ω : Fin c → Bool) :
    ∀ (k j : ℕ) (hjk : j ≤ k) (i : Fin j),
      vResponses mech ctrl s ω j i = vResponses mech ctrl s ω k (Fin.castLE hjk i) := by
  intro k
  induction k with
  | zero =>
    intro j hj i
    have : j = 0 := by omega
    subst this
    exact i.elim0
  | succ k ih =>
    intro j hj i
    rcases Nat.lt_or_ge j (k + 1) with hlt | hge
    · rw [ih j (by omega) i, vResponses_succ]
      have : (Fin.castLE hj i) = Fin.castSucc (Fin.castLE (by omega) i) := by
        ext; simp
      rw [this, Fin.snoc_castSucc]
    · have : j = k + 1 := by omega
      subst this
      rfl

end Interaction

section Meas

variable {U : Type} {N c : ℕ} (mech : VMechanism N c) {Ω : Type} [MeasurableSpace Ω]
  (ctrl : Ω → VController U)
  (hctrl : ∀ (t : ℕ) (h : Fin t → VResponse), Measurable (fun ω => ctrl ω t h))
  (s : Fin N → U) (ω' : Fin c → Bool)

include hctrl in
theorem measurable_viewsOf (t : ℕ) (h : Fin t → VResponse) :
    Measurable (fun ω => viewsOf (ctrl ω) s t h) := by
  refine measurable_pi_lambda _ fun j => ?_
  refine Measurable.prodMk ?_ (hctrl _ _).snd
  exact measurable_pi_lambda _ fun ℓ => (measurable_pi_apply (s ℓ)).comp (hctrl _ _).fst

include hctrl in
theorem measurableSet_vResponses_eq
    (hmeas : ∀ (t : ℕ) (r : VResponse),
      MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | mech t views ω' = r}) :
    ∀ (t : ℕ) (h : Fin t → VResponse),
      MeasurableSet {ω | vResponses mech (ctrl ω) s ω' t = h} := by
  intro t
  induction t with
  | zero =>
    intro h
    have : {ω | vResponses mech (ctrl ω) s ω' 0 = h} = Set.univ := by
      ext ω; simp only [Set.mem_ofPred_eq, Set.mem_univ, iff_true]
      funext i; exact i.elim0
    rw [this]; exact MeasurableSet.univ
  | succ t ih =>
    intro h
    have hset : {ω | vResponses mech (ctrl ω) s ω' (t + 1) = h} =
        {ω | vResponses mech (ctrl ω) s ω' t = Fin.init h} ∩
          (fun ω => viewsOf (ctrl ω) s t (Fin.init h)) ⁻¹'
            {views | mech t views ω' = h (Fin.last t)} := by
      ext ω
      simp only [Set.mem_ofPred_eq, Set.mem_inter_iff, Set.mem_preimage, vResponses_succ]
      constructor
      · intro hω
        have h1 : vResponses mech (ctrl ω) s ω' t = Fin.init h := by
          rw [← hω, Fin.init_snoc]
        refine ⟨h1, ?_⟩
        rw [← h1, ← hω, Fin.snoc_last]
      · rintro ⟨h1, h2⟩
        rw [h1, h2, Fin.snoc_init_self]
    rw [hset]
    exact (ih _).inter (measurable_viewsOf ctrl hctrl s t _ (hmeas t _))

end Meas

/-! ## Coverage and correctness as measurable conditions -/

/-- The coverage condition of round `t` from the request types `isInt j` and rejection flags
`rej j` of the rounds (`VCovered` is this with the interaction's values). -/
def covPred (M J R t : ℕ) (isInt rej : ℕ → Bool) : Prop :=
  ((Finset.range t).filter (fun j => isInt j = true ∧
      ((Finset.range (j + 1)).filter (fun i => isInt i = true)).card ≤ M ∧ rej j = true)).card ≤ J ∧
  (isInt t = true → ((Finset.range (t + 1)).filter (fun j => isInt j = true)).card ≤ M) ∧
  (isInt t = false → ((Finset.range (t + 1)).filter (fun j => isInt j = false)).card ≤ R)

theorem vCovered_eq_covPred {U : Type} {N c : ℕ} (mech : VMechanism N c) (ctrl : VController U)
    (M J R : ℕ) (s : Fin N → U) (ω : Fin c → Bool) (t : ℕ) :
    VCovered mech ctrl M J R s ω t =
      covPred M J R t (fun j => (vRequest mech ctrl s ω j).2.1)
        (fun j => (vResponse mech ctrl s ω j).isReject) := rfl

theorem covPred_congr {M J R t : ℕ} {isInt rej isInt' rej' : ℕ → Bool}
    (h1 : ∀ j ≤ t, isInt j = isInt' j) (h2 : ∀ j < t, rej j = rej' j) :
    covPred M J R t isInt rej ↔ covPred M J R t isInt' rej' := by
  unfold covPred
  have e1 : (Finset.range t).filter (fun j => isInt j = true ∧
      ((Finset.range (j + 1)).filter (fun i => isInt i = true)).card ≤ M ∧ rej j = true) =
      (Finset.range t).filter (fun j => isInt' j = true ∧
      ((Finset.range (j + 1)).filter (fun i => isInt' i = true)).card ≤ M ∧ rej' j = true) := by
    refine Finset.filter_congr fun j hj => ?_
    rw [Finset.mem_range] at hj
    have e : (Finset.range (j + 1)).filter (fun i => isInt i = true) =
        (Finset.range (j + 1)).filter (fun i => isInt' i = true) :=
      Finset.filter_congr fun i hi => by
        rw [Finset.mem_range] at hi; rw [h1 i (by omega)]
    rw [e, h1 j (by omega), h2 j hj]
  have e2 : (Finset.range (t + 1)).filter (fun j => isInt j = true) =
      (Finset.range (t + 1)).filter (fun j => isInt' j = true) :=
    Finset.filter_congr fun i hi => by rw [Finset.mem_range] at hi; rw [h1 i (by omega)]
  have e3 : (Finset.range (t + 1)).filter (fun j => isInt j = false) =
      (Finset.range (t + 1)).filter (fun j => isInt' j = false) :=
    Finset.filter_congr fun i hi => by rw [Finset.mem_range] at hi; rw [h1 i (by omega)]
  rw [e1, e2, e3, h1 t le_rfl]

theorem measurableSet_setOf_ite {α : Type} [MeasurableSpace α] {p : α → Prop} [DecidablePred p]
    {q r : α → Prop} (hp : MeasurableSet {x | p x}) (hq : MeasurableSet {x | q x})
    (hr : MeasurableSet {x | r x}) : MeasurableSet {x | if p x then q x else r x} := by
  have : {x | if p x then q x else r x} = ({x | p x} ∩ {x | q x}) ∪ ({x | p x}ᶜ ∩ {x | r x}) := by
    ext x; by_cases h : p x <;> simp [h]
  rw [this]; exact (hp.inter hq).union (hp.compl.inter hr)

theorem measurable_popMean {U : Type} [Fintype U] (D : U → ℝ) :
    Measurable (fun req : (U → ℝ) × Bool × ℝ × ℝ => popMean D req.1) := by
  unfold popMean
  exact (continuous_finsetSum _ fun x _ =>
    continuous_const.mul ((continuous_apply x).comp continuous_fst)).measurable

theorem measurableSet_vCorrect {U : Type} [Fintype U] (D : U → ℝ) (a : ℝ) (resp : VResponse) :
    MeasurableSet {req : (U → ℝ) × Bool × ℝ × ℝ | VCorrect D a req resp} := by
  have hpm := measurable_popMean D
  have hl : Measurable fun req : (U → ℝ) × Bool × ℝ × ℝ => req.2.2.1 := measurable_snd.snd.fst
  have hu : Measurable fun req : (U → ℝ) × Bool × ℝ × ℝ => req.2.2.2 := measurable_snd.snd.snd
  have hb : MeasurableSet {req : (U → ℝ) × Bool × ℝ × ℝ | req.2.1 = true} :=
    measurable_snd.fst (measurableSet_singleton true)
  unfold VCorrect
  cases resp with
  | accept =>
    exact measurableSet_setOf_ite hb
      ((measurableSet_le (hl.sub_const a) hpm).inter (measurableSet_le hpm (hu.add_const a)))
      MeasurableSet.empty
  | high =>
    exact measurableSet_setOf_ite hb (measurableSet_le (hu.sub_const a) hpm) MeasurableSet.empty
  | low =>
    exact measurableSet_setOf_ite hb (measurableSet_le hpm (hl.add_const a)) MeasurableSet.empty
  | num q =>
    refine measurableSet_setOf_ite hb MeasurableSet.empty ?_
    refine (MeasurableSet.const _).inter ((MeasurableSet.const _).inter ?_)
    exact measurableSet_le (measurable_const.sub hpm).abs measurable_const

/-! ## The failure event in terms of a fixed response history -/

section Fixed

variable {U : Type} {N c : ℕ} (mech : VMechanism N c)

/-- The request of round `j ≤ t` when the first `t + 1` responses are `h`. -/
def reqOf (ctrl : VController U) (t : ℕ) (h : Fin (t + 1) → VResponse) (j : ℕ) :
    (U → ℝ) × Bool × ℝ × ℝ :=
  if hj : j ≤ t then ctrl j (fun i : Fin j => h (Fin.castLE (by omega) i))
  else ctrl j (fun _ => VResponse.accept)

/-- The response of round `j ≤ t` in the history `h`. -/
def respOf (t : ℕ) (h : Fin (t + 1) → VResponse) (j : ℕ) : VResponse :=
  if hj : j < t + 1 then h ⟨j, hj⟩ else VResponse.accept

theorem vRequest_eq_reqOf (ctrl : VController U) (s : Fin N → U) (ω : Fin c → Bool) {t : ℕ}
    {h : Fin (t + 1) → VResponse} (hω : vResponses mech ctrl s ω (t + 1) = h) {j : ℕ}
    (hj : j ≤ t) : vRequest mech ctrl s ω j = reqOf ctrl t h j := by
  unfold vRequest reqOf
  rw [dif_pos hj]
  congr 1
  funext i
  rw [vResponses_prefix mech ctrl s ω (t + 1) j (by omega) i, hω]

theorem vResponse_eq_respOf (ctrl : VController U) (s : Fin N → U) (ω : Fin c → Bool) {t : ℕ}
    {h : Fin (t + 1) → VResponse} (hω : vResponses mech ctrl s ω (t + 1) = h) {j : ℕ}
    (hj : j ≤ t) : vResponse mech ctrl s ω j = respOf t h j := by
  unfold vResponse respOf
  rw [dif_pos (by omega), vResponses_prefix mech ctrl s ω (t + 1) (j + 1) (by omega) (Fin.last j),
    hω]
  rfl

theorem vFails_iff [Fintype U] (ctrl : VController U) (D : U → ℝ) (M J R : ℕ) (aReq : ℝ)
    (s : Fin N → U) (ω : Fin c → Bool) :
    VFails mech D M J R aReq ctrl s ω ↔ ∃ t : ℕ, ∃ h : Fin (t + 1) → VResponse,
      vResponses mech ctrl s ω (t + 1) = h ∧
      covPred M J R t (fun j => (reqOf ctrl t h j).2.1) (fun j => (respOf t h j).isReject) ∧
      ¬ VCorrect D aReq (reqOf ctrl t h t) (respOf t h t) := by
  constructor
  · rintro ⟨t, hcov, hcor⟩
    refine ⟨t, _, rfl, ?_, ?_⟩
    · rw [vCovered_eq_covPred] at hcov
      refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mp hcov
      · rw [vRequest_eq_reqOf mech ctrl s ω rfl hj]
      · rw [vResponse_eq_respOf mech ctrl s ω rfl hj.le]
    · rwa [← vRequest_eq_reqOf mech ctrl s ω rfl le_rfl, ← vResponse_eq_respOf mech ctrl s ω rfl le_rfl]
  · rintro ⟨t, h, hω, hcov, hcor⟩
    refine ⟨t, ?_, ?_⟩
    · rw [vCovered_eq_covPred]
      refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mpr hcov
      · rw [vRequest_eq_reqOf mech ctrl s ω hω hj]
      · rw [vResponse_eq_respOf mech ctrl s ω hω hj.le]
    · rwa [vRequest_eq_reqOf mech ctrl s ω hω le_rfl, vResponse_eq_respOf mech ctrl s ω hω le_rfl]

end Fixed

section Main

variable {U : Type} {N c : ℕ} (mech : VMechanism N c) {Ω : Type} [MeasurableSpace Ω]
  (ctrl : Ω → VController U)
  (hctrl : ∀ (t : ℕ) (h : Fin t → VResponse), Measurable (fun ω => ctrl ω t h))

include hctrl in
theorem measurable_reqOf (t : ℕ) (h : Fin (t + 1) → VResponse) (j : ℕ) :
    Measurable (fun ω => reqOf (ctrl ω) t h j) := by
  unfold reqOf
  by_cases hj : j ≤ t
  · simp only [dif_pos hj]; exact hctrl _ _
  · simp only [dif_neg hj]; exact hctrl _ _

include hctrl in
theorem measurableSet_vFails [Fintype U] (D : U → ℝ) (M J R : ℕ) (aReq : ℝ)
    (hmeas : ∀ (t : ℕ) (ω' : Fin c → Bool) (r : VResponse),
      MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | mech t views ω' = r})
    (s : Fin N → U) (ω' : Fin c → Bool) :
    MeasurableSet {ω | VFails mech D M J R aReq (ctrl ω) s ω'} := by
  have hset : {ω | VFails mech D M J R aReq (ctrl ω) s ω'} =
      ⋃ t : ℕ, ⋃ h : Fin (t + 1) → VResponse,
        {ω | vResponses mech (ctrl ω) s ω' (t + 1) = h} ∩
          ({ω | covPred M J R t (fun j => (reqOf (ctrl ω) t h j).2.1)
              (fun j => (respOf t h j).isReject)} ∩
            {ω | ¬ VCorrect D aReq (reqOf (ctrl ω) t h t) (respOf t h t)}) := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Set.mem_inter_iff]
    rw [vFails_iff]
  rw [hset]
  refine MeasurableSet.iUnion fun t => MeasurableSet.iUnion fun h => ?_
  refine (measurableSet_vResponses_eq mech ctrl hctrl s ω' (fun t r => hmeas t ω' r) (t + 1) h).inter
    ((?_ : MeasurableSet _).inter ?_)
  · -- coverage depends on the Bool pattern of request types
    let pat : Ω → (Fin (t + 1) → Bool) := fun ω j => (reqOf (ctrl ω) t h j).2.1
    have hpat : Measurable pat :=
      measurable_pi_lambda _ fun j => (measurable_reqOf ctrl hctrl t h j).snd.fst
    have hset2 : {ω | covPred M J R t (fun j => (reqOf (ctrl ω) t h j).2.1)
          (fun j => (respOf t h j).isReject)} =
        pat ⁻¹' {v | covPred M J R t (fun j => if hj : j < t + 1 then v ⟨j, hj⟩ else false)
          (fun j => (respOf t h j).isReject)} := by
      ext ω
      simp only [Set.mem_ofPred_eq, Set.mem_preimage]
      exact covPred_congr (fun j hj => by simp [pat, show j < t + 1 by omega]) (fun _ _ => rfl)
    rw [hset2]
    exact hpat (Set.to_countable _).measurableSet
  · exact (measurable_reqOf ctrl hctrl t h t) (measurableSet_vCorrect D aReq _).compl

end Main

end F2e2e.B
