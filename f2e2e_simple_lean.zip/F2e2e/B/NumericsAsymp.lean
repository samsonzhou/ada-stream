import F2e2e.B.NumericsP

/-!
# Part II numerics (B-NUM), part 3: the asymptotic form `valNExplicit ≤ C · valNAsymp`

Theorem `R:thm:validation_ada` (`parts/partII.tex` L958–965) states
`N ≤ 2^64[(p^{7/2}/a² + p^{3/2}√K/a)χ^{3/2} + p³χ/a²]` (eq. `R:eq:sec3_N_explicit`) and "Consequently"
`N = O[(√(J+R+1)/a_req + a_req^{-2}) log³(1/a_req) log²((M+J+R+2)/(a_req ξ_req))]`
(eq. `R:eq:sec3_total_N_validation`); the proof (L1052) says "Since `p = O(log(1/a))` and `p = O(χ)`, (…) follows".

Here (Spec only), for `0 < a_req < 1/10`, `0 < ξ_req < 1/2`, with `a = dyadicDown a_req`,
`ξ_A = dyadicDown ξ_req`, `L = (M+J+R+2)/(a_req ξ_req)`:
* `valP_le_one_div_dyadicDown`: `p ≤ 1/a`; `valP_le_six_mul_log`: `p ≤ 6 ln(1/a_req)`;
* `chiArg_dyadic_le`: `2^40(p+1)Q/(hξ_A) ≤ 2^62 L^8`;
* `valChi_le_logb`: `χ ≤ 63 + 8 log₂ L`; `valChi_le_log`: `χ ≤ 31 ln L`;
* `valNExplicit_le_asymp`: `valNExplicit ≤ 2^84 · valNAsymp` (one universal constant);
* `exists_valNExplicit_le_asymp`: the existential form used for `Theorem_B`.

(The paper's checker sketch "`p ≤ 5 ln(1/a_req)`" fails near `a_req = 1/10`: there `p = 12 > 5 ln 10`;
`6 ln(1/a_req)` is used instead.)
-/

namespace F2e2e.B

/-- `L = (M+J+R+2)/(a_req ξ_req)`, the argument of the second logarithm in `valNAsymp`. -/
noncomputable def valL (M J R : ℕ) (aReq ξReq : ℝ) : ℝ := ((M : ℝ) + J + R + 2) / (aReq * ξReq)

/-- `4/a_req < L` (as `M+J+R+2 ≥ 2` and `ξ_req < 1/2`). -/
theorem four_div_lt_valL (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) : 4 / aReq < valL M J R aReq ξReq := by
  unfold valL
  have hS : (2 : ℝ) ≤ (M : ℝ) + J + R + 2 := by
    have : (0 : ℝ) ≤ (M : ℝ) + J + R := by positivity
    linarith
  rw [div_lt_div_iff₀ ha0 (by positivity)]
  nlinarith

theorem forty_lt_valL (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) : 40 < valL M J R aReq ξReq := by
  have h := four_div_lt_valL M J R ha0 hξ0 hξ1
  have h2 : (40 : ℝ) < 4 / aReq := by
    rw [lt_div_iff₀ ha0]
    linarith
  linarith

/-- `1/a_req < L`. -/
theorem one_div_lt_valL (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) : 1 / aReq < valL M J R aReq ξReq := by
  have h := four_div_lt_valL M J R ha0 hξ0 hξ1
  have h2 : 1 / aReq ≤ 4 / aReq := by
    apply div_le_div_of_nonneg_right (by norm_num) ha0.le
  linarith

/-! ### `p` for the dyadic accuracy -/

/-- `p ≤ 1/a` for the dyadic `a = dyadicDown x`, `0 < x < 1/8`. -/
theorem valP_le_one_div_dyadicDown {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 8) :
    (valP (dyadicDown x) : ℝ) ≤ 1 / dyadicDown x := by
  have ha := dyadicDown_pos x
  have ha16 := dyadicDown_le_sixteenth hx0 hx1
  have h := valP_le_two_pow_dyadicExp ha ha16
  rw [dyadicExp_dyadicDown] at h
  rw [one_div_dyadicDown]
  exact_mod_cast h

/-- `p ≤ 2⌈log₂(1/x)⌉ + 4` for the dyadic `a = dyadicDown x`, `0 < x < 1/8`. -/
theorem valP_dyadicDown_le {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 8) :
    valP (dyadicDown x) ≤ 2 * dyadicExp x + 4 := by
  have h := valP_le_two_mul_dyadicExp_add_four (dyadicDown_pos x) (dyadicDown_le_sixteenth hx0 hx1)
  rwa [dyadicExp_dyadicDown] at h

/-- `p ≤ 6 ln(1/a_req)` for `0 < a_req < 1/8` (the paper's `p = O(log(1/a))`). -/
theorem valP_le_six_mul_log {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 8) :
    (valP (dyadicDown x) : ℝ) ≤ 6 * Real.log (1 / x) := by
  have h := valP_dyadicDown_le hx0 hx1
  have hk4 := four_le_dyadicExp hx0 hx1
  have hk : (4 : ℝ) ≤ dyadicExp x := by exact_mod_cast hk4
  have hl := dyadicExp_sub_one_mul_log_two_lt hx0 (by linarith)
  have hln2 := Real.log_two_gt_d9
  have hp : (valP (dyadicDown x) : ℝ) ≤ 2 * dyadicExp x + 4 := by exact_mod_cast h
  have hprod : 0 ≤ ((dyadicExp x : ℝ) - 1) * (Real.log 2 - 0.6931471803) :=
    mul_nonneg (by linarith) (by linarith)
  rw [one_div]
  nlinarith

/-! ### `χ` for the dyadic parameters -/

/-- Pure-real core of `chiArg_dyadic_le`. Here `u = 1/a`, `z = 1/ξ_A`, `w = 1/a_req`, `y = 1/ξ_req`,
`S = M+J+R+2`, `L = S w y`. -/
theorem chiArg_core {P u S Q z w y L : ℝ} (hP1 : 1 ≤ P) (hPu : P ≤ u) (hS : 1 ≤ S) (hQ0 : 0 ≤ Q)
    (hQ : Q ≤ 100 * (P + 1) * (S + 512 * P ^ 2 * u ^ 2 + P)) (hz : 0 ≤ z) (hu : u ≤ 2 * w)
    (hzy : z ≤ 2 * y) (hwL : 4 * w ≤ L) (hL : L = S * w * y) :
    2 ^ 40 * (P + 1) * Q * (512 * P * u) * z ≤ 2 ^ 62 * L ^ 8 := by
  have hu1 : 1 ≤ u := hP1.trans hPu
  have hw : 0 ≤ w := by linarith
  have hy : 0 ≤ y := by linarith
  have hu4 : 1 ≤ u ^ 4 := one_le_pow₀ hu1
  have hPu2 : P ^ 2 * u ^ 2 ≤ u ^ 4 := by
    have h1 : P ^ 2 ≤ u ^ 2 := pow_le_pow_left₀ (by linarith) hPu 2
    have h2 : u ^ 4 = u ^ 2 * u ^ 2 := by ring
    rw [h2]
    have : 0 ≤ u ^ 2 := by positivity
    nlinarith
  have hPu4 : P ≤ u ^ 4 := by
    have : u ≤ u ^ 4 := by
      calc u = u ^ 1 := by ring
        _ ≤ u ^ 4 := pow_le_pow_right₀ hu1 (by norm_num)
    linarith
  have hin : S + 512 * P ^ 2 * u ^ 2 + P ≤ 514 * S * u ^ 4 := by
    have h1 : S ≤ S * u ^ 4 := by nlinarith
    have h2 : u ^ 4 ≤ S * u ^ 4 := by nlinarith
    nlinarith
  have hQ' : Q ≤ 102800 * S * u ^ 5 := by
    have h2 : P + 1 ≤ 2 * u := by linarith
    have h3 : 0 ≤ S + 512 * P ^ 2 * u ^ 2 + P := by positivity
    calc Q ≤ 100 * (P + 1) * (S + 512 * P ^ 2 * u ^ 2 + P) := hQ
      _ ≤ 100 * (2 * u) * (514 * S * u ^ 4) := by gcongr
      _ = 102800 * S * u ^ 5 := by ring
  have hP0 : 0 ≤ P := by linarith
  have hu0 : 0 ≤ u := by linarith
  have hS0 : 0 ≤ S := by linarith
  have hL0 : 0 ≤ L := by rw [hL]; positivity
  calc 2 ^ 40 * (P + 1) * Q * (512 * P * u) * z
      ≤ 2 ^ 40 * (2 * u) * (102800 * S * u ^ 5) * (512 * u * u) * (2 * y) := by
        gcongr
        linarith
    _ = 2 ^ 40 * 210534400 * (S * u ^ 8 * y) := by ring
    _ ≤ 2 ^ 40 * 2 ^ 28 * (S * (2 * w) ^ 8 * y) := by
        gcongr
        · norm_num
    _ = 2 ^ 76 * (S * w * y) * w ^ 7 := by ring
    _ ≤ 2 ^ 76 * L * (L / 4) ^ 7 := by
        rw [← hL]
        gcongr
        linarith
    _ = 2 ^ 62 * L ^ 8 := by ring

/-- `2^40(p+1)Q/(hξ_A) ≤ 2^62 L^8` for the dyadic parameters of Theorem B. -/
theorem chiArg_dyadic_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    chiArg M J R (dyadicDown aReq) (dyadicDown ξReq) ≤ 2 ^ 62 * valL M J R aReq ξReq ^ 8 := by
  set a := dyadicDown aReq with ha_def
  set ξA := dyadicDown ξReq with hξA_def
  have ha : 0 < a := dyadicDown_pos aReq
  have hξA : 0 < ξA := dyadicDown_pos ξReq
  have hP1 : (1 : ℝ) ≤ valP a := by
    have := two_le_valP_real ha
    linarith
  have hPu : (valP a : ℝ) ≤ 1 / a := valP_le_one_div_dyadicDown ha0 (by linarith)
  have hS : (1 : ℝ) ≤ (M : ℝ) + J + R + 2 := by
    have : (0 : ℝ) ≤ (M : ℝ) + J + R := by positivity
    linarith
  have hQ0 : (0 : ℝ) ≤ valQ M J R a := by positivity
  have hQ := valQ_le M J R ha
  have hτ : 8 / valTau a ^ 2 = 512 * (valP a : ℝ) ^ 2 * (1 / a) ^ 2 := by
    have h := one_div_valTau_sq a
    calc 8 / valTau a ^ 2 = 8 * (1 / valTau a ^ 2) := by ring
      _ = 8 * (64 * (valP a : ℝ) ^ 2 / a ^ 2) := by rw [h]
      _ = 512 * (valP a : ℝ) ^ 2 * (1 / a) ^ 2 := by ring
  rw [hτ] at hQ
  have hQ' : (valQ M J R a : ℝ) ≤ 100 * ((valP a : ℝ) + 1) *
      (((M : ℝ) + J + R + 2) + 512 * (valP a : ℝ) ^ 2 * (1 / a) ^ 2 + valP a) := by
    linarith
  have hu : 1 / a ≤ 2 * (1 / aReq) := by
    have := one_div_dyadicDown_lt ha0 (by linarith : aReq < 1)
    rw [← ha_def] at this
    have e : 2 / aReq = 2 * (1 / aReq) := by ring
    linarith
  have hzy : 1 / ξA ≤ 2 * (1 / ξReq) := by
    have := one_div_dyadicDown_lt hξ0 (by linarith : ξReq < 1)
    rw [← hξA_def] at this
    have e : 2 / ξReq = 2 * (1 / ξReq) := by ring
    linarith
  have hwL : 4 * (1 / aReq) ≤ valL M J R aReq ξReq := by
    have := four_div_lt_valL M J R ha0 hξ0 hξ1
    have e : 4 * (1 / aReq) = 4 / aReq := by ring
    linarith
  have hL : valL M J R aReq ξReq = ((M : ℝ) + J + R + 2) * (1 / aReq) * (1 / ξReq) := by
    unfold valL
    field_simp
  have hcore := chiArg_core hP1 hPu hS hQ0 hQ' (by positivity) hu hzy hwL hL
  have e : chiArg M J R a ξA =
      2 ^ 40 * ((valP a : ℝ) + 1) * (valQ M J R a : ℝ) * (512 * (valP a : ℝ) * (1 / a)) *
        (1 / ξA) := by
    have h1 : 1 / valH a = 512 * (valP a : ℝ) / a := one_div_valH a
    have hh := valH_pos ha
    unfold chiArg
    rw [show 512 * (valP a : ℝ) * (1 / a) = 1 / valH a by rw [h1]; ring]
    field_simp
  rw [e]
  exact hcore

/-- `χ ≤ 63 + 8 log₂ L` for the dyadic parameters of Theorem B. -/
theorem valChi_le_logb (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (valChi M J R (dyadicDown aReq) (dyadicDown ξReq) : ℝ) ≤
      63 + 8 * Real.logb 2 (valL M J R aReq ξReq) := by
  have ha := dyadicDown_pos aReq
  have hξA := dyadicDown_pos ξReq
  have hL40 := forty_lt_valL M J R ha0 ha1 hξ0 hξ1
  have hLpos : 0 < valL M J R aReq ξReq := by linarith
  have h1 : (1 : ℝ) ≤ chiArg M J R (dyadicDown aReq) (dyadicDown ξReq) := by
    have := two_pow_sixty_lt_chiArg M J R ha (dyadicDown_le_one aReq) hξA (dyadicDown_le_one ξReq)
    have h60 : (1 : ℝ) ≤ 2 ^ 60 := one_le_pow₀ (by norm_num)
    linarith
  have hlt := valChi_lt_logb_add_one M J R h1
  have hle := chiArg_dyadic_le M J R ha0 ha1 hξ0 hξ1
  have hpos := chiArg_pos M J R ha hξA
  have hlog : Real.logb 2 (chiArg M J R (dyadicDown aReq) (dyadicDown ξReq)) ≤
      Real.logb 2 (2 ^ 62 * valL M J R aReq ξReq ^ 8) :=
    Real.logb_le_logb_of_le (by norm_num) hpos hle
  have e : Real.logb 2 (2 ^ 62 * valL M J R aReq ξReq ^ 8) =
      62 + 8 * Real.logb 2 (valL M J R aReq ξReq) := by
    rw [Real.logb_mul (by positivity) (by positivity), Real.logb_pow, Real.logb_pow,
      Real.logb_self_eq_one (by norm_num)]
    push_cast
    ring
  linarith

/-- `χ ≤ 31 ln L` for the dyadic parameters of Theorem B (the paper's `χ = O(log((M+J+R+2)/(aξ)))`). -/
theorem valChi_le_log (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (valChi M J R (dyadicDown aReq) (dyadicDown ξReq) : ℝ) ≤
      31 * Real.log (valL M J R aReq ξReq) := by
  have h := valChi_le_logb M J R ha0 ha1 hξ0 hξ1
  have hL40 := forty_lt_valL M J R ha0 ha1 hξ0 hξ1
  have hln2 := Real.log_two_gt_d9
  have hln2' : Real.log 2 < 1 := by
    have := Real.log_two_lt_d9
    linarith
  -- `ln L ≥ ln 32 = 5 ln 2`
  have hL32 : 5 * Real.log 2 ≤ Real.log (valL M J R aReq ξReq) := by
    have : Real.log ((2 : ℝ) ^ 5) ≤ Real.log (valL M J R aReq ξReq) :=
      Real.log_le_log (by norm_num) (by linarith)
    rwa [Real.log_pow] at this
  have hlogb : Real.logb 2 (valL M J R aReq ξReq) = Real.log (valL M J R aReq ξReq) / Real.log 2 :=
    rfl
  rw [hlogb] at h
  have hl2pos : 0 < Real.log 2 := by linarith
  -- `63 + 8 ln L/ln 2 ≤ 31 ln L`, i.e. `63 ln 2 + 8 ln L ≤ 31 ln 2 ln L`
  have key : 63 * Real.log 2 + 8 * Real.log (valL M J R aReq ξReq) ≤
      31 * Real.log 2 * Real.log (valL M J R aReq ξReq) := by
    nlinarith
  have e : 63 + 8 * (Real.log (valL M J R aReq ξReq) / Real.log 2) =
      (63 * Real.log 2 + 8 * Real.log (valL M J R aReq ξReq)) / Real.log 2 := by
    field_simp
  have h2 : (63 * Real.log 2 + 8 * Real.log (valL M J R aReq ξReq)) / Real.log 2 ≤
      31 * Real.log (valL M J R aReq ξReq) := by
    rw [div_le_iff₀ hl2pos]
    linarith
  linarith

/-! ### `valNExplicit ≤ 2^84 · valNAsymp` -/

/-- Pure-real core of `valNExplicit_le_asymp`: `P = p`, `X = χ`, `a` dyadic, `A = a_req`,
`ℓa = ln(1/a_req)`, `ℓL = ln L`, `K = J+R+1`. -/
theorem valNExplicit_asymp_core {P X a A ℓa ℓL K : ℝ} (hP1 : 1 ≤ P) (hX1 : 1 ≤ X) (ha : 0 < a) (hA : 0 < A)
    (haA : 1 / a ≤ 2 / A) (hPa : P ≤ 6 * ℓa) (hPL : P ≤ 6 * ℓL) (hXL : X ≤ 31 * ℓL)
    (hℓa : 1 ≤ ℓa) (hℓL : 1 ≤ ℓL) :
    2 ^ 64 * ((P ^ 3 * Real.sqrt P / a ^ 2 + P * Real.sqrt P * Real.sqrt K / a) *
        (X * Real.sqrt X) + P ^ 3 * X / a ^ 2) ≤
      2 ^ 84 * ((Real.sqrt K / A + 1 / A ^ 2) * ℓa ^ 3 * ℓL ^ 2) := by
  have hP0 : 0 ≤ P := by linarith
  have hX0 : 0 ≤ X := by linarith
  set s := Real.sqrt P * Real.sqrt X with hs_def
  have hs0 : 0 ≤ s := by positivity
  have hsP : Real.sqrt P ^ 2 = P := Real.sq_sqrt hP0
  have hsX : Real.sqrt X ^ 2 = X := Real.sq_sqrt hX0
  have hs : s ≤ 37 / 2 * ℓL := by
    have h2 : 2 * s ≤ P + X := by
      have := sq_nonneg (Real.sqrt P - Real.sqrt X)
      nlinarith
    linarith
  set i := 1 / a with hi_def
  have hi0 : 0 ≤ i := by positivity
  have hi2 : i ^ 2 ≤ 4 * (1 / A ^ 2) := by
    have : i ^ 2 ≤ (2 / A) ^ 2 := pow_le_pow_left₀ hi0 haA 2
    calc i ^ 2 ≤ (2 / A) ^ 2 := this
      _ = 4 * (1 / A ^ 2) := by ring
  have hsK : 0 ≤ Real.sqrt K := Real.sqrt_nonneg K
  have hℓa0 : 0 ≤ ℓa := by linarith
  have hℓL0 : 0 ≤ ℓL := by linarith
  have hP3 : P ^ 3 ≤ 216 * ℓa ^ 3 := by
    have := pow_le_pow_left₀ hP0 hPa 3
    calc P ^ 3 ≤ (6 * ℓa) ^ 3 := this
      _ = 216 * ℓa ^ 3 := by ring
  -- rewrite the left side
  have e : (P ^ 3 * Real.sqrt P / a ^ 2 + P * Real.sqrt P * Real.sqrt K / a) * (X * Real.sqrt X) +
      P ^ 3 * X / a ^ 2 =
      P ^ 3 * X * s * i ^ 2 + P * X * s * Real.sqrt K * i + P ^ 3 * X * i ^ 2 := by
    rw [hs_def, hi_def]
    field_simp
  rw [e]
  have hA2 : 0 ≤ 1 / A ^ 2 := by positivity
  have hA1 : 0 ≤ Real.sqrt K / A := by positivity
  have t1 : P ^ 3 * X * s * i ^ 2 ≤
      (216 * ℓa ^ 3) * (31 * ℓL) * (37 / 2 * ℓL) * (4 * (1 / A ^ 2)) := by
    gcongr
  have t2 : P * X * s * Real.sqrt K * i ≤
      (6 * ℓa) * (31 * ℓL) * (37 / 2 * ℓL) * Real.sqrt K * (2 / A) := by
    gcongr
  have t3 : P ^ 3 * X * i ^ 2 ≤ (216 * ℓa ^ 3) * (31 * ℓL) * (4 * (1 / A ^ 2)) := by
    gcongr
  have hℓa3 : ℓa ≤ ℓa ^ 3 := by
    calc ℓa = ℓa ^ 1 := by ring
      _ ≤ ℓa ^ 3 := pow_le_pow_right₀ hℓa (by norm_num)
  have hℓL2 : ℓL ≤ ℓL ^ 2 := by
    calc ℓL = ℓL ^ 1 := by ring
      _ ≤ ℓL ^ 2 := pow_le_pow_right₀ hℓL (by norm_num)
  have m1 : (216 * ℓa ^ 3) * (31 * ℓL) * (37 / 2 * ℓL) * (4 * (1 / A ^ 2)) =
      495504 * (ℓa ^ 3 * ℓL ^ 2 * (1 / A ^ 2)) := by ring
  have m2 : (6 * ℓa) * (31 * ℓL) * (37 / 2 * ℓL) * Real.sqrt K * (2 / A) =
      6882 * (ℓa * ℓL ^ 2 * (Real.sqrt K / A)) := by ring
  have m3 : (216 * ℓa ^ 3) * (31 * ℓL) * (4 * (1 / A ^ 2)) =
      26784 * (ℓa ^ 3 * ℓL * (1 / A ^ 2)) := by ring
  have b2 : ℓa * ℓL ^ 2 * (Real.sqrt K / A) ≤ ℓa ^ 3 * ℓL ^ 2 * (Real.sqrt K / A) := by
    gcongr
  have b3 : ℓa ^ 3 * ℓL * (1 / A ^ 2) ≤ ℓa ^ 3 * ℓL ^ 2 * (1 / A ^ 2) := by
    gcongr
  have hm1 : 0 ≤ ℓa ^ 3 * ℓL ^ 2 * (1 / A ^ 2) := by positivity
  have hm2 : 0 ≤ ℓa ^ 3 * ℓL ^ 2 * (Real.sqrt K / A) := by positivity
  have efin : 2 ^ 84 * ((Real.sqrt K / A + 1 / A ^ 2) * ℓa ^ 3 * ℓL ^ 2) =
      2 ^ 64 * (2 ^ 20 * (ℓa ^ 3 * ℓL ^ 2 * (Real.sqrt K / A)) +
        2 ^ 20 * (ℓa ^ 3 * ℓL ^ 2 * (1 / A ^ 2))) := by ring
  rw [efin]
  have hsum : P ^ 3 * X * s * i ^ 2 + P * X * s * Real.sqrt K * i + P ^ 3 * X * i ^ 2 ≤
      2 ^ 20 * (ℓa ^ 3 * ℓL ^ 2 * (Real.sqrt K / A)) +
        2 ^ 20 * (ℓa ^ 3 * ℓL ^ 2 * (1 / A ^ 2)) := by
    rw [m1] at t1
    rw [m2] at t2
    rw [m3] at t3
    nlinarith
  have h64 : (0 : ℝ) < 2 ^ 64 := by positivity
  exact mul_le_mul_of_nonneg_left hsum h64.le

/-- **`valNExplicit ≤ 2^84 · valNAsymp`** under the hypotheses of Theorem B
(eq. `R:eq:sec3_N_explicit` ⇒ eq. `R:eq:sec3_total_N_validation`, with the explicit constant `2^84`). -/
theorem valNExplicit_le_asymp (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    valNExplicit M J R aReq ξReq ≤ 2 ^ 84 * valNAsymp M J R aReq ξReq := by
  have ha := dyadicDown_pos aReq
  have hξA := dyadicDown_pos ξReq
  have ha16 := dyadicDown_le_sixteenth ha0 (by linarith)
  have hP1 : (1 : ℝ) ≤ valP (dyadicDown aReq) := by
    have := two_le_valP_real ha
    linarith
  have hX1 : (1 : ℝ) ≤ valChi M J R (dyadicDown aReq) (dyadicDown ξReq) := by
    exact_mod_cast one_le_valChi M J R ha (dyadicDown_le_one aReq) hξA (dyadicDown_le_one ξReq)
  have haA : 1 / dyadicDown aReq ≤ 2 / aReq := (one_div_dyadicDown_lt ha0 (by linarith)).le
  have hPa := valP_le_six_mul_log ha0 (by linarith)
  have hL40 := forty_lt_valL M J R ha0 ha1 hξ0 hξ1
  have hwL := one_div_lt_valL M J R ha0 hξ0 hξ1
  have hlogle : Real.log (1 / aReq) ≤ Real.log (valL M J R aReq ξReq) :=
    Real.log_le_log (by positivity) hwL.le
  have hPL : (valP (dyadicDown aReq) : ℝ) ≤ 6 * Real.log (valL M J R aReq ξReq) := by linarith
  have hXL := valChi_le_log M J R ha0 ha1 hξ0 hξ1
  have hln2 := Real.log_two_gt_d9
  have hℓa : 1 ≤ Real.log (1 / aReq) := by
    -- `1/a_req > 10 > e`
    have h10 : (10 : ℝ) < 1 / aReq := by
      rw [lt_div_iff₀ ha0]
      linarith
    have he : Real.exp 1 < 10 := by
      have := Real.exp_one_lt_d9
      linarith
    have : Real.log (Real.exp 1) < Real.log (1 / aReq) :=
      Real.log_lt_log (Real.exp_pos 1) (by linarith)
    rw [Real.log_exp] at this
    linarith
  have hℓL : 1 ≤ Real.log (valL M J R aReq ξReq) := by linarith
  have h := valNExplicit_asymp_core (K := (J : ℝ) + R + 1) hP1 hX1 ha ha0 haA hPa hPL hXL hℓa hℓL
  unfold valNExplicit valNAsymp
  unfold valL at h
  exact h

/-- Existential form (a universal constant `C = 2^84`). -/
theorem exists_valNExplicit_le_asymp :
    ∃ C : ℝ, 0 < C ∧ ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq →
      ξReq < 1 / 2 → valNExplicit M J R aReq ξReq ≤ C * valNAsymp M J R aReq ξReq :=
  ⟨2 ^ 84, by positivity, fun M J R _ _ ha0 ha1 hξ0 hξ1 => valNExplicit_le_asymp M J R ha0 ha1 hξ0 hξ1⟩

end F2e2e.B
