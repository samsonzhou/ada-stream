import F2e2e.B.AccuracyMain
import F2e2e.B.PrivacyCore
import F2e2e.B.ArchCount

/-!
# Theorem `R:thm:validation_ada`, core level: the final wiring

Paper: `parts/partII.tex` L980–1046 (proof of Theorem `R:thm:validation_ada`): (P1) the draw count
(`coreRunD_drawsLE_Q`, `F2e2e/B/ArchCount.lean`), (P2)–(P4) the per-block privacy of the core
(`core_block_dp`, `F2e2e/B/PrivacyCore.lean`) and (P5) transfer and accuracy
(`accuracy_core_guarantee_detS_of_dp`, `F2e2e/B/AccuracyMain.lean`).

* `accuracy_core_guarantee_detS`: B-ARCH's `CoreGuaranteeDetS` (covered failure at accuracy `a_req − h_A`,
  `CAP_ABORT`, or a reached correction cap, with probability at most `ξ_req`);
* `accuracy_core_guarantee_det`: B-ARCH's `CoreGuaranteeDet` (via `coreGuaranteeDet_of_S`).
-/

namespace F2e2e.B

/-- **Theorem `R:thm:validation_ada`, core level, with the internal-cap clause.** -/
theorem accuracy_core_guarantee_detS (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) : CoreGuaranteeDetS M J R aReq ξReq :=
  accuracy_core_guarantee_detS_of_dp M J R ha0 ha1 hξ0 hξ1 (core_block_dp M J R ha0 ha1 hξ0 hξ1)
    (fun _ _ ctrl _ s T => coreRunD_drawsLE_Q M J R aReq ξReq ctrl s T)

/-- **Theorem `R:thm:validation_ada`, core level.** -/
theorem accuracy_core_guarantee_det (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) : CoreGuaranteeDet M J R aReq ξReq :=
  coreGuaranteeDet_of_S (accuracy_core_guarantee_detS M J R ha0 ha1 hξ0 hξ1)

end F2e2e.B
