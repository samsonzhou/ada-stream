import F2e2e.Spec
import F2e2e.B.ArchParamsBridge

/-!
# Spec bridge (B-NUM), part 2: the parameters of Algorithm 2

The Spec's paper-form parameter record `F2e2e.alg2Params M J R aReq ξReq` (Definition
`R:def:sec3_ada_params`, `parts/partII.tex` L666–717: reals and rationals, ceilings, `log₂`)
agrees field by field with B-ARCH's computable record `F2e2e.B.adaParams eA eXi M J R` at
`eA = dyadicExp aReq`, `eXi = dyadicExp ξReq` (the Spec uses `a = dyadicDown aReq`,
`ξ_A = dyadicDown ξReq`, L669).

Notation in the docstrings: `P := F2e2e.alg2Params M J R aReq ξReq` and
`A := adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R`.

## Contents
* §1 `v2_valC`, `v2_valNBlock`, `v2_valMaxN`, `v2_valHAExp`, …: the Spec's §2.2 helpers equal
  the paper form `F2e2e/B/Params.lean` (`alg2C`, `alg2NBlock`, …); the only non-definitional
  step is `valC = alg2C` (natural vs integer index of `T_{j-2}^max`, using `p ≥ 2`).
* §2 the field lemmas requested by B-ARCH (names `v2par_*`): `M J R p n Tmax a tau kappa hA bInt
  bOut bNum draw N`, the Spec-constant forms `v2par_valP`, `v2par_valTmax`, and the auxiliary
  `v2par_zeta`, `v2par_B0`, `v2par_rho`, `v2par_Ks`, `v2par_rs`.
* §3 the size conjuncts of `Theorem_B_statistical`: `v2par_N_eq_alg2N`, `v2par_N_le_explicit`,
  `v2par_N_le_asymp`, `v2par_size_conjuncts`.

(Moved at the Spec lock from `F2e2e/Scratch/AV2/BParamsV2.lean`, where it bridged the namespaced
draft `F2e2eV2`; the v1 ↔ v2 identities of its §1 became self-equalities and were dropped.)
-/

namespace F2e2e.B.V2

/-! ## 1. The Spec's §2.2 helpers ↔ the paper form `F2e2e/B/Params.lean` -/

/-- `T_j^max` with the out-of-range convention. -/
theorem v2_valTcap (aReq : ℝ) (j : ℕ) :
    F2e2e.valTcap (F2e2e.dyadicDown aReq) j = alg2Tmax aReq j := rfl

/-- `p ≥ 2` for the dyadic accuracy (it is positive for every `aReq`). -/
theorem two_le_alg2P (aReq : ℝ) : 2 ≤ alg2P aReq := two_le_valP (dyadicDown_pos aReq)

/-- The phase budgets `C_j`: the Spec writes `T_{j-2}^max` with a natural index guarded by `2 ≤ j`,
the paper form with an integer index (`alg2TmaxZ`); they agree because `p ≥ 2`. -/
theorem v2_valC (J R : ℕ) (aReq : ℝ) (j : ℕ) :
    F2e2e.valC J R (F2e2e.dyadicDown aReq) j = alg2C J R aReq j := by
  have hp : 2 ≤ alg2P aReq := two_le_alg2P aReq
  have hZ2 : alg2TmaxZ aReq ((j : ℤ) - 2) = if 2 ≤ j then alg2Tmax aReq (j - 2) else 0 := by
    unfold alg2TmaxZ
    by_cases h : 2 ≤ j
    · rw [if_pos (by omega), if_pos h]
      congr 1
      omega
    · rw [if_neg (by omega), if_neg h]
  have hZ1 : 1 ≤ j → alg2TmaxZ aReq ((j : ℤ) - 1) = alg2Tmax aReq (j - 1) := by
    intro h
    unfold alg2TmaxZ
    rw [if_pos (by omega)]
    congr 1
    omega
  show (if j = 0 then alg2Tmax aReq 0 + alg2Tmax aReq 1 + J + R + 2
      else if j < alg2P aReq then
        (if 2 ≤ j then alg2Tmax aReq (j - 2) else 0) + 2 * alg2Tmax aReq (j - 1) +
          2 * alg2Tmax aReq j + alg2Tmax aReq (j + 1) + 2
      else if j = alg2P aReq then alg2Tmax aReq (j - 2) + alg2Tmax aReq (j - 1) + 1
      else 0) = alg2C J R aReq j
  unfold alg2C
  by_cases h0 : j = 0
  · rw [if_pos h0, if_pos h0]
  · rw [if_neg h0, if_neg h0, hZ2, hZ1 (by omega)]
    by_cases hlt : j < alg2P aReq
    · rw [if_pos hlt, if_pos hlt]
    · rw [if_neg hlt, if_neg hlt]
      by_cases heq : j = alg2P aReq
      · rw [if_pos heq, if_pos heq, if_pos (by omega)]
      · rw [if_neg heq, if_neg heq]

/-- The block sizes `n_j` (every `j`). -/
theorem v2_valNBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    F2e2e.valNBlock M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) j =
      alg2NBlock M J R aReq ξReq j := by
  unfold F2e2e.valNBlock
  rw [v2_valC]
  rfl

/-- `max_j n_j`. -/
theorem v2_valMaxN (M J R : ℕ) (aReq ξReq : ℝ) :
    F2e2e.valMaxN M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
      alg2MaxN M J R aReq ξReq := by
  unfold F2e2e.valMaxN
  have h : F2e2e.valNBlock M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
      alg2NBlock M J R aReq ξReq := funext (v2_valNBlock M J R aReq ξReq)
  rw [h]
  rfl

/-- The lattice exponent `q_A`. -/
theorem v2_valHAExp (M J R : ℕ) (aReq ξReq : ℝ) :
    F2e2e.valHAExp M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
      alg2HAExp M J R aReq ξReq := by
  unfold F2e2e.valHAExp F2e2e.valHABound
  rw [v2_valMaxN]
  rfl

/-- The sampler budget `ζ`. -/
theorem v2_valZeta (M J R : ℕ) (aReq ξReq : ℝ) :
    F2e2e.valZeta M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
      alg2Zeta M J R aReq ξReq := rfl

/-! ## 2. The field lemmas -/

/-- `((range m).map f).getD j 0 = f j` for `j < m`. -/
theorem getD_map_range (f : ℕ → ℕ) {m j : ℕ} (hj : j < m) :
    ((List.range m).map f).getD j 0 = f j := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_range hj]

/-- The list of correction caps, read with default `0`, is `adaTmax` (which is `0` for `j ≥ p`). -/
theorem getD_adaTmaxList (eA j : ℕ) : (adaTmaxList eA).getD j 0 = adaTmax eA j := by
  by_cases hj : j < adaP eA
  · exact getD_map_range _ hj
  · rw [List.getD_eq_default _ _ (by simp [adaTmaxList]; omega)]
    simp [adaTmax, hj]

/-- `P.M = A.M`. -/
theorem v2par_M (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).M =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).M := rfl

/-- `P.J = A.J`. -/
theorem v2par_J (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).J =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).J := rfl

/-- `P.R = A.R`. -/
theorem v2par_R (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).R =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).R := rfl

/-- `P.p = A.p`. -/
theorem v2par_p (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).p =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p :=
  (adaP_eq aReq).symm

/-- The Spec constant `p` (as used by `VInternalFails`) is `A.p`. -/
theorem v2par_valP (M J R : ℕ) (aReq ξReq : ℝ) :
    F2e2e.valP (F2e2e.dyadicDown aReq) =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p :=
  (adaP_eq aReq).symm

/-- `P.n j = A.blockSizes.getD j 0` for `j ≤ p` (the Spec's `n` is a total function; out of range it is not
`0`). -/
theorem v2par_n (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (j : ℕ)
    (hj : j ≤ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p) :
    (F2e2e.alg2Params M J R aReq ξReq).n j =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).blockSizes.getD j 0 := by
  have hj' : j < adaP (dyadicExp aReq) + 1 := Nat.lt_succ_of_le hj
  show F2e2e.valNBlock M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) j =
    ((List.range (adaP (dyadicExp aReq) + 1)).map
      (adaNBlock M J R (dyadicExp aReq) (dyadicExp ξReq))).getD j 0
  rw [getD_map_range _ hj', v2_valNBlock, adaNBlock_eq M J R ha0 ha1 hξ0 hξ1]

/-- `P.Tmax j = A.Tmax.getD j 0` for every `j`. -/
theorem v2par_Tmax (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    (F2e2e.alg2Params M J R aReq ξReq).Tmax j =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).Tmax.getD j 0 := by
  show alg2Tmax aReq j = (adaTmaxList (dyadicExp aReq)).getD j 0
  rw [getD_adaTmaxList, adaTmax_eq]

/-- The Spec constant `T_j^max` (as used by `VInternalFails`) is `A.Tmax.getD j 0` for `j < p`. -/
theorem v2par_valTmax (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ)
    (hj : j < (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p) :
    F2e2e.valTmax (F2e2e.dyadicDown aReq) j =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).Tmax.getD j 0 := by
  have hlt : j < alg2P aReq := by
    rw [← adaP_eq]
    exact hj
  have h : alg2Tmax aReq j = valTmax (alg2A aReq) j := if_pos hlt
  rw [← v2par_Tmax M J R aReq ξReq j]
  exact h.symm

/-- `P.a = A.a`. -/
theorem v2par_a (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).a =
      ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).a : ℝ) :=
  (adaA_cast aReq).symm

/-- `P.tau = A.tau`. -/
theorem v2par_tau (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).tau =
      ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).tau : ℝ) :=
  (adaTau_cast aReq).symm

/-- `P.kappa = A.kappa`. -/
theorem v2par_kappa (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).kappa =
      ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).kappa : ℝ) :=
  (adaKappa_cast aReq).symm

/-- `P.hA = A.hA` (exact rationals). -/
theorem v2par_hA (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).hA =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).hA := by
  show (1 / 2 : ℚ) ^ F2e2e.valHAExp M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
    (1 / 2 : ℚ) ^ adaQA M J R (dyadicExp aReq) (dyadicExp ξReq)
  rw [v2_valHAExp, adaQA_eq M J R ha0 ha1 hξ0 hξ1]

/-- `P.bInt = A.bInt` (exact rationals). -/
theorem v2par_bInt (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).bInt =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).bInt := by
  show (1 / 2 : ℚ) ^ dyadicExp aReq / (8 * (valP (dyadicDown aReq) : ℚ)) / 64 /
      (128 * (valChi M J R (dyadicDown aReq) (dyadicDown ξReq) : ℚ)) =
    (1 / 2 : ℚ) ^ dyadicExp aReq / (8 * (adaP (dyadicExp aReq) : ℚ)) / 64 /
      (128 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ))
  rw [adaChi_eq M J R ha0 ha1 hξ0 hξ1, adaP_eq]
  rfl

/-- `P.bOut = A.bOut` (exact rationals). -/
theorem v2par_bOut (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).bOut =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).bOut := by
  show (1 / 2 : ℚ) ^ dyadicExp aReq / (512 * (valChi M J R (dyadicDown aReq) (dyadicDown ξReq) : ℚ)) =
    (1 / 2 : ℚ) ^ dyadicExp aReq / (512 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ))
  rw [adaChi_eq M J R ha0 ha1 hξ0 hξ1]
  rfl

/-- `P.bNum = A.bNum` (exact rationals). -/
theorem v2par_bNum (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).bNum =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).bNum := by
  show (1 / 2 : ℚ) ^ dyadicExp aReq / (64 * (valChi M J R (dyadicDown aReq) (dyadicDown ξReq) : ℚ)) =
    (1 / 2 : ℚ) ^ dyadicExp aReq / (64 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ))
  rw [adaChi_eq M J R ha0 ha1 hξ0 hξ1]
  rfl

/-- `P.zeta = A.zeta`. -/
theorem v2par_zeta (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).zeta =
      ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).zeta : ℝ) :=
  (adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1).symm

/-- `P.B0 = A.B0`. -/
theorem v2par_B0 (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).B0 =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).B0 :=
  (adaParams_B0_eq M J R ha0 ha1 hξ0 hξ1).symm

/-- `P.rho b = A.rho b`. -/
theorem v2par_rho (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (b : ℚ) :
    (F2e2e.alg2Params M J R aReq ξReq).rho b =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).rho b := by
  show b / (b + (F2e2e.alg2Params M J R aReq ξReq).hA) =
    b / (b + (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).hA)
  rw [v2par_hA M J R ha0 ha1 hξ0 hξ1]

/-- `P.Ks b = A.Ks b`. -/
theorem v2par_Ks (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (b : ℚ) :
    (F2e2e.alg2Params M J R aReq ξReq).Ks b =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).Ks b := by
  show ⌈((b : ℝ) + ((F2e2e.alg2Params M J R aReq ξReq).hA : ℝ)) /
      ((F2e2e.alg2Params M J R aReq ξReq).hA : ℝ) *
      ((F2e2e.alg2Params M J R aReq ξReq).B0 : ℝ)⌉₊ =
    ⌈(b + (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).hA) /
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).hA *
      ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).B0 : ℚ)⌉₊
  rw [v2par_hA M J R ha0 ha1 hξ0 hξ1, v2par_B0 M J R ha0 ha1 hξ0 hξ1, ← natCeil_ratCast]
  push_cast
  rfl

/-- `P.rs b = A.rs b`. -/
theorem v2par_rs (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (b : ℚ) :
    (F2e2e.alg2Params M J R aReq ξReq).rs b =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).rs b := by
  set A := adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R with hA
  have hz : (0 : ℚ) < A.zeta := by
    have h1 : ((A.zeta : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq :=
      adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1
    have h2 := alg2Zeta_pos M J R aReq ξReq
    rw [← h1] at h2
    exact_mod_cast h2
  have hpos : (0 : ℚ) < 32 * ((A.Ks b : ℚ) + 1) / A.zeta := by positivity
  show ⌈Real.logb 2 (32 * (((F2e2e.alg2Params M J R aReq ξReq).Ks b : ℝ) + 1) /
      (F2e2e.alg2Params M J R aReq ξReq).zeta)⌉₊ =
    Nat.clog 2 ⌈32 * ((A.Ks b : ℚ) + 1) / A.zeta⌉₊
  rw [v2par_Ks M J R ha0 ha1 hξ0 hξ1, v2par_zeta M J R ha0 ha1 hξ0 hξ1]
  have hcast : (32 * ((A.Ks b : ℝ) + 1) / (A.zeta : ℝ)) =
      ((32 * ((A.Ks b : ℚ) + 1) / A.zeta : ℚ) : ℝ) := by
    push_cast
    ring
  rw [hcast, ceil_logb_eq_clog _ (by exact_mod_cast hpos), natCeil_ratCast]

/-- `P.draw b t` is the bounded sampler with `A`'s `ϱ`, `r_s`, `K_s`. -/
theorem v2par_draw (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (b : ℚ) (t : List Bool) :
    (F2e2e.alg2Params M J R aReq ξReq).draw b t =
      F2e2e.latticeSample
        ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).rho b).num.toNat
        ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).rho b).den
        ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).rs b)
        ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).Ks b) t := by
  show F2e2e.latticeSample ((F2e2e.alg2Params M J R aReq ξReq).rho b).num.toNat
      ((F2e2e.alg2Params M J R aReq ξReq).rho b).den ((F2e2e.alg2Params M J R aReq ξReq).rs b)
      ((F2e2e.alg2Params M J R aReq ξReq).Ks b) t = _
  rw [v2par_rho M J R ha0 ha1 hξ0 hξ1, v2par_rs M J R ha0 ha1 hξ0 hξ1,
    v2par_Ks M J R ha0 ha1 hξ0 hξ1]

/-! ## 3. The sample size and the size conjuncts of `Theorem_B_statistical` -/

/-- `P.N` is the paper-form sample size `alg2N` (no hypotheses needed). -/
theorem v2par_N_eq_alg2N (M J R : ℕ) (aReq ξReq : ℝ) :
    (F2e2e.alg2Params M J R aReq ξReq).N = alg2N M J R aReq ξReq := by
  show ∑ j ∈ Finset.range (F2e2e.valP (F2e2e.dyadicDown aReq) + 1),
      F2e2e.valNBlock M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) j =
    ∑ j ∈ Finset.range (alg2P aReq + 1), alg2NBlock M J R aReq ξReq j
  exact Finset.sum_congr rfl fun j _ => v2_valNBlock M J R aReq ξReq j

/-- `P.N = A.N`. -/
theorem v2par_N (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).N =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N := by
  rw [v2par_N_eq_alg2N]
  exact (adaParams_N_eq M J R ha0 ha1 hξ0 hξ1).symm

/-- The explicit size conjunct of `Theorem_B_statistical`. -/
theorem v2par_N_le_explicit (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) ≤ F2e2e.valNExplicit M J R aReq ξReq := by
  rw [v2par_N_eq_alg2N]
  exact alg2_N_le_explicit M J R ha0 ha1 hξ0 hξ1

/-- The asymptotic size conjunct of `Theorem_B_statistical` (with `C = 2^84`). -/
theorem v2par_N_le_asymp :
    ∃ C : ℝ, 0 < C ∧ ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq →
      ξReq < 1 / 2 →
        ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) ≤ C * F2e2e.valNAsymp M J R aReq ξReq := by
  obtain ⟨C, hC, h⟩ := alg2_N_le_asymp
  exact ⟨C, hC, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 => by
    rw [v2par_N_eq_alg2N]
    exact h M J R aReq ξReq ha0 ha1 hξ0 hξ1⟩

/-- Both size conjuncts of `Theorem_B_statistical`, in its quantifier shape. -/
theorem v2par_size_conjuncts :
    ∃ C : ℝ, 0 < C ∧ ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq →
      ξReq < 1 / 2 →
        ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) ≤ F2e2e.valNExplicit M J R aReq ξReq ∧
          ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) ≤
            C * F2e2e.valNAsymp M J R aReq ξReq := by
  obtain ⟨C, hC, h⟩ := v2par_N_le_asymp
  exact ⟨C, hC, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 =>
    ⟨v2par_N_le_explicit M J R ha0 ha1 hξ0 hξ1, h M J R aReq ξReq ha0 ha1 hξ0 hξ1⟩⟩

end F2e2e.B.V2
