import F2e2e.B.AccuracyLemmas

/-!
# Theorem `R:thm:validation_ada` (P5): the good-event analysis of one call of the core

Paper: `parts/partII.tex` L1038–1046 ("On this event, Lemma 3.5 excludes internal cap exhaustion. An unchanged
scan gives `|μ₀ − 𝒟f| ≤ p(τ + 2h) + 1.5h < 0.131a`. Outer acceptance permits at most `3a/4` beyond either
rounded endpoint … A rejection has signed empirical excess at least `a/4` … Numerical error is below
`0.131a + a/4 + 2h_A`"), Lemma `R:lem:sec3_potential_contraction` (iii)–(v), Algorithm 2 lines [2]–[18].

Deterministic statements on the noise-draw programs of `F2e2e/B/ArchCore.lean`, along every path on which all
draws are good (`DrawProg.GoodPaths (NoiseGood P rad)`), relative to admissible comparators `u` that are
accurate on the current query:

* `accInv_init`: initialization establishes `AccInv` (Lemma 3.5 (i): `P₀ ≤ 1`);
* `accInv_T_lt_Tmax`: `AccInv` gives `T_j < T_j^max` (Lemma 3.5 (v)): the correction caps are never reached;
* `interval_goodPaths`: `Interval` preserves `AccInv`, never returns `CAP_ABORT` on a processed request, and its
  certificate is sound (`CertSound`); counters as in `IntervalBook`;
* `numerical_goodPaths`: the same for `Numerical` (`NumSound`, `NumericalBook`).

Internal steps (stated here, used by the two call theorems): `scanPass_goodPaths` (one scan pass: acceptance
certificates for cached edges are preserved, a crossing applies a correction that keeps the potential budget,
never `CAP_ABORT`), `prepareRoot_goodPaths` (the pass budget `fuel = 1 + ∑ T_j^max` suffices; at the end all
edges are certified, `|μ_{j+1} − μ_j| ≤ τ + 2h`), `root_error_le` (telescoping + anchor accuracy:
`|μ₀ − c| ≤ Δ_root`).
-/

namespace F2e2e.B

open F2e2e.Discrete F2e2e.Opt.Quad DrawProg

variable {P : AdaParams} {rad : NoiseKind → ℚ} {u : (j : ℕ) → Fin (blockN P j) → ℝ}

/-! ## A correction -/

/-- **A correction on the good event** (Lemma `R:lem:sec3_potential_contraction` (iii)–(iv)): if edge `j`
crossed with sign `q` (`q Δμ ≥ τ − 2h`), the corrected state keeps the invariant (the joint potential drops
by at least `(25/128) 4^j τ²` while `∑ 4^k T_k` grows by `4^j`), the predictions off `{j, j+1}` are
unchanged, `T_j` is incremented and the counters are unchanged. -/
theorem applyCorrection_goodPaths (hP : AccParamsOK P) (hu : CompAdmissible P u)
    {vals : List (List ℕ)} (hvals : ValsOK P vals) {c : ℝ} (hc : CompCond P u vals c)
    {st : AdaState} (hst : AccInv P rad u st) {j : ℕ} (hj : j < P.p) (q : Bool)
    (hrej : (P.tau : ℝ) - 2 * ((P.tau : ℝ) / 64) ≤
      (if q then (1 : ℝ) else -1) * (musR P st vals (j + 1) - musR P st vals j)) :
    (applyCorrection P st vals j q).GoodPaths (NoiseGood P rad)
      (fun st' => AccInv P rad u st' ∧
        (∀ k, k ≠ j → k ≠ j + 1 → musR P st' vals k = musR P st vals k) ∧
        st'.nInt = st.nInt ∧ st'.nNum = st.nNum ∧ st'.rej = st.rej ∧ st'.halted = st.halted ∧
        st'.thrOut = st.thrOut ∧ st'.T = st.T.set j (st.T.getD j 0 + 1)) := by
  rw [applyCorrection_eq]
  refine (redrawThresholds_goodPaths P rad P.p (reopenEdges P j) st.thrInt hst.thrInt_good).bind ?_
  intro thr hthr
  simp only [goodPaths_ret]
  have hjs : j < st.scores.length := by rw [hst.scores_len]; exact hj
  have hjw : j < st.weights.length := by rw [hst.weights_len]; exact hj
  have hT' : (corrState P st vals j q thr).T = st.T.set j (st.T.getD j 0 + 1) := rfl
  have hqR : (if q then (1 : ℝ) else -1) = 1 ∨ (if q then (1 : ℝ) else -1) = -1 := by
    cases q <;> simp
  have hτ0 : (0 : ℝ) ≤ P.tau := by exact_mod_cast hP.tau_pos.le
  have hκ : (P.kappa : ℝ) = (P.tau : ℝ) / 4 := by rw [hP.kappa_eq]; push_cast; ring
  have hn : ∀ k < P.p, 0 < blockN P k := fun k hk => hP.n_pos k hk.le
  have hmuj := musR_learned P st vals hj (hn j hj) (hst.weights_eq j hj) (hst.score_len j hj)
    (hvals j hj.le)
  -- the potential drop
  have hdrop : statePotential P u (corrState P st vals j q thr) - statePotential P u st ≤
      -(25 / 128) * 4 ^ j * (P.tau : ℝ) ^ 2 := by
    by_cases hj1 : j + 1 < P.p
    · have hmuj1 := musR_learned P st vals hj1 (hn _ hj1) (hst.weights_eq _ hj1)
        (hst.score_len _ hj1) (hvals _ hj1.le)
      rw [hmuj, hmuj1] at hrej
      exact (jointPotential_interior_drop hn (by norm_num : (1 : ℝ) ≤ 8) hτ0 hκ rfl u (blockG P st)
        (blockG P (corrState P st vals j q thr)) hj1 (blockX P vals j) (blockX P vals (j + 1))
        (blockX_mem P vals j) (blockX_mem P vals (j + 1)) hqR (hc j hj.le) (hc (j + 1) hj1.le) hrej
        (blockG_corrState_self P st vals j q thr hjs (hst.score_len j hj))
        (blockG_corrState_succ P st vals j q thr hj1 (by rw [hst.scores_len]; exact hj1)
          (hst.score_len _ hj1))
        (fun k hk hk1 => blockG_corrState_other P st vals j q thr hk hk1)).2
    · have hjp : j + 1 = P.p := by omega
      have hmup := musR_anchor P st vals (hvals P.p le_rfl)
      rw [hjp, hmup, hmuj] at hrej
      have hθp : accTheta P P.p = ((P.tau : ℝ) / 64) / (2 * Real.sqrt 2) := by
        unfold accTheta
        rw [if_neg (lt_irrefl _)]
      obtain ⟨-, -, h2, h3⟩ := jointPotential_anchor_drop_of_comparator hn (by norm_num : (1 : ℝ) ≤ 8)
        (by exact_mod_cast hP.tau_pos) hκ rfl hθp u (blockG P st)
        (blockG P (corrState P st vals j q thr)) hjp (blockX P vals j) (blockX_mem P vals j)
        (u P.p) (blockX P vals P.p) (blockX_mem P vals P.p) (hu.reg P.p le_rfl) (hc P.p le_rfl) hqR
        (hc j hj.le) hrej (blockG_corrState_self P st vals j q thr hjs (hst.score_len j hj))
        (fun k hk => by
          by_cases hk1 : k = j + 1
          · rw [hk1]
            exact blockG_corrState_anchor P st vals j q thr hj1
          · exact blockG_corrState_other P st vals j q thr hk hk1)
      unfold statePotential
      linarith
  have hW : weightedT P (corrState P st vals j q thr) = weightedT P st + 4 ^ j :=
    weightedT_set P hj hst.T_len hT'
  have hpot : statePotential P u (corrState P st vals j q thr) +
      25 / 128 * (P.tau : ℝ) ^ 2 * weightedT P (corrState P st vals j q thr) ≤ 1 := by
    have h1 := hst.potential
    rw [hW]
    have h2 : 25 / 128 * (P.tau : ℝ) ^ 2 * (weightedT P st + 4 ^ j) =
        25 / 128 * (P.tau : ℝ) ^ 2 * weightedT P st + 25 / 128 * 4 ^ j * (P.tau : ℝ) ^ 2 := by ring
    rw [h2]
    linarith
  have hinv : AccInv P rad u (corrState P st vals j q thr) :=
    { scores_len := by rw [corrState_scores_length]; exact hst.scores_len
      score_len := by
        intro k hk
        by_cases hkj : k = j
        · rw [hkj, corrState_scores_self P st vals j q thr hjs, addScaled_length]
          exact hst.score_len j hj
        · by_cases hkj1 : k = j + 1
          · rw [hkj1] at hk ⊢
            rw [corrState_scores_succ P st vals j q thr hk (by rw [hst.scores_len]; exact hk),
              addScaled_length]
            exact hst.score_len _ hk
          · rw [corrState_scores_other P st vals j q thr hkj hkj1]
            exact hst.score_len k hk
      weights_len := by rw [corrState_weights_length]; exact hst.weights_len
      weights_eq := by
        intro k hk
        by_cases hkj : k = j
        · rw [hkj, corrState_weights_self P st vals j q thr hjw,
            corrState_scores_self P st vals j q thr hjs]
        · by_cases hkj1 : k = j + 1
          · rw [hkj1] at hk ⊢
            rw [corrState_weights_succ P st vals j q thr hk (by rw [hst.weights_len]; exact hk),
              corrState_scores_succ P st vals j q thr hk (by rw [hst.scores_len]; exact hk)]
          · rw [corrState_weights_other P st vals j q thr hkj hkj1,
              corrState_scores_other P st vals j q thr hkj hkj1]
            exact hst.weights_eq k hk
      T_len := by rw [hT', List.length_set]; exact hst.T_len
      thr_len := by
        show thr.length = P.p
        rw [hthr.1]
        exact hst.thr_len
      thrInt_good := hthr.2
      thrOut_good := hst.thrOut_good
      potential := hpot
      halted_rej := hst.halted_rej
      rej_le := hst.rej_le
      not_capAborted := hst.not_capAborted }
  exact ⟨hinv, fun k hk hk1 => musR_eq_of_weights P vals (corrState_weights_other P st vals j q thr hk hk1),
    rfl, rfl, rfl, rfl, rfl, rfl⟩

/-! ## One scan pass and `PrepareRoot` -/

/-- **One scan pass** (lines [5]–[9]) on the good event: never `CAP_ABORT`; `done` certifies every edge
(and keeps the cache); `corrected` applies one correction (some `T_j` incremented by one) keeping the
invariant and the cache certificates. -/
theorem scanPass_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad) (hu : CompAdmissible P u)
    {vals : List (List ℕ)} (hvals : ValsOK P vals) {c : ℝ} (hc : CompCond P u vals c)
    (es : List ℕ) (hes : ∀ e ∈ es, e < P.p) {st : AdaState} (hst : AccInv P rad u st)
    {cache : List Bool} (hcache : CacheOK P st vals cache) :
    (scanPass P vals (adaMus P st vals) es st cache).GoodPaths (NoiseGood P rad)
      (fun r => r.1 ≠ PassOut.abort ∧ AccInv P rad u r.2.1 ∧ CacheOK P r.2.1 vals r.2.2 ∧
        r.2.1.nInt = st.nInt ∧ r.2.1.nNum = st.nNum ∧ r.2.1.rej = st.rej ∧
        r.2.1.halted = st.halted ∧ r.2.1.thrOut = st.thrOut ∧
        (r.1 = PassOut.done → r.2.1 = st ∧ (∀ e ∈ es, r.2.2.getD e false = true) ∧
          ∀ e, cache.getD e false = true → r.2.2.getD e false = true) ∧
        (r.1 = PassOut.corrected →
          ∃ j0 < P.p, r.2.1.T = st.T.set j0 (st.T.getD j0 0 + 1))) := by
  induction es generalizing cache with
  | nil =>
    simp only [scanPass]
    exact (goodPaths_ret _).2 ⟨by simp, hst, hcache, rfl, rfl, rfl, rfl, rfl,
      fun _ => ⟨rfl, by simp, fun e h => h⟩, fun h => by simp at h⟩
  | cons j es ih =>
    have hj : j < P.p := hes j List.mem_cons_self
    have hes' : ∀ e ∈ es, e < P.p := fun e he => hes e (List.mem_cons_of_mem _ he)
    simp only [scanPass]
    by_cases hcj : cache.getD j false = true
    · rw [if_pos hcj]
      refine (ih hes' hcache).mono ?_
      rintro r ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10⟩
      refine ⟨h1, h2, h3, h4, h5, h6, h7, h8, fun hd => ?_, h10⟩
      obtain ⟨hd1, hd2, hd3⟩ := h9 hd
      refine ⟨hd1, fun e he => ?_, hd3⟩
      rcases List.mem_cons.1 he with rfl | he'
      · exact hd3 _ hcj
      · exact hd2 e he'
    · rw [if_neg hcj]
      refine (edgeTest_goodPaths hrad st (adaMus P st vals) j (hst.thrInt_good j hj)).bind ?_
      intro r hr
      cases r with
      | none =>
        have hcert : EdgeCert P st vals j := by
          have h := hr
          simp only [EdgeOutOK] at h
          unfold EdgeCert musR
          rw [← Rat.cast_sub]
          exact h
        have hcache' : CacheOK P st vals (cache.set j true) := by
          refine ⟨by rw [List.length_set]; exact hcache.1, fun k hk hck => ?_⟩
          rw [getD_set_eq] at hck
          by_cases hkj : j = k
          · rw [← hkj]
            exact hcert
          · rw [if_neg (fun h => hkj h.1)] at hck
            exact hcache.2 k hk hck
        refine (ih hes' hcache').mono ?_
        rintro r ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10⟩
        refine ⟨h1, h2, h3, h4, h5, h6, h7, h8, fun hd => ?_, h10⟩
        obtain ⟨hd1, hd2, hd3⟩ := h9 hd
        refine ⟨hd1, fun e he => ?_, fun e hce => hd3 e ?_⟩
        · rcases List.mem_cons.1 he with rfl | he'
          · exact hd3 _ (getD_set_self_of_lt (by rw [hcache.1]; exact hj) _ _)
          · exact hd2 e he'
        · rw [getD_set_eq]
          split_ifs
          · rfl
          · exact hce
      | some q =>
        dsimp only
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · exact absurd hT (not_le.2 (accInv_T_lt_Tmax hP hu hst j hj))
        · rw [if_neg hT]
          have hrej : (P.tau : ℝ) - 2 * ((P.tau : ℝ) / 64) ≤
              (if q then (1 : ℝ) else -1) * (musR P st vals (j + 1) - musR P st vals j) := by
            have h := hr
            simp only [EdgeOutOK] at h
            unfold musR
            rw [← Rat.cast_sub]
            exact h
          refine (applyCorrection_goodPaths hP hu hvals hc hst hj q hrej).bind ?_
          rintro st' ⟨hinv, hmus, h4, h5, h6, h7, h8, hT'⟩
          simp only [goodPaths_ret]
          refine ⟨by simp, hinv, ?_, h4, h5, h6, h7, h8, fun h => by simp at h,
            fun _ => ⟨j, hj, hT'⟩⟩
          refine ⟨by rw [foldl_set_false_length]; exact hcache.1, fun e he hce => ?_⟩
          obtain ⟨hne, hce'⟩ := foldl_set_false_getD _ _ _ hce
          obtain ⟨h1, h2, h3⟩ := not_mem_reopenEdges he hne
          have hold := hcache.2 e he hce'
          unfold EdgeCert at hold ⊢
          rw [hmus e h1 h2, hmus (e + 1) h3 (by omega)]
          exact hold

/-- **`PrepareRoot`** (lines [2]–[10]) on the good event: with a pass budget exceeding the remaining correction
budget, it returns a state (never `CAP_ABORT`, never out of passes) satisfying the invariant, with every edge
certified, and the counters other than `T` unchanged. -/
theorem prepareRoot_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad) (hu : CompAdmissible P u)
    {vals : List (List ℕ)} (hvals : ValsOK P vals) {c : ℝ} (hc : CompCond P u vals c)
    (fuel : ℕ) {st : AdaState} (hst : AccInv P rad u st) {cache : List Bool}
    (hcache : CacheOK P st vals cache)
    (hfuel : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0) < fuel) :
    (prepareRoot P vals fuel st cache).GoodPaths (NoiseGood P rad)
      (fun r => ∃ st2, r = some st2 ∧ AccInv P rad u st2 ∧ (∀ j < P.p, EdgeCert P st2 vals j) ∧
        st2.nInt = st.nInt ∧ st2.nNum = st.nNum ∧ st2.rej = st.rej ∧ st2.halted = st.halted ∧
        st2.thrOut = st.thrOut) := by
  induction fuel generalizing st cache with
  | zero => exact absurd hfuel (Nat.not_lt_zero _)
  | succ fuel ih =>
    simp only [prepareRoot]
    refine (scanPass_goodPaths hP hrad hu hvals hc (List.range P.p)
      (fun e he => List.mem_range.1 he) hst hcache).bind ?_
    rintro ⟨o, st', cache'⟩ ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10⟩
    cases o with
    | done =>
      obtain ⟨-, hd2, -⟩ := h9 rfl
      simp only [goodPaths_ret]
      exact ⟨st', rfl, h2, fun j hj => h3.2 j hj (hd2 j (List.mem_range.2 hj)), h4, h5, h6, h7, h8⟩
    | corrected =>
      obtain ⟨j0, hj0, hT⟩ := h10 rfl
      have hlt := accInv_T_lt_Tmax hP hu hst j0 hj0
      have hfuel' : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st'.T.getD j 0) < fuel := by
        have := sum_sub_set_succ P.Tmax st.T hj0 (by rw [hst.T_len]; exact hj0) hlt
        simp only at hT
        rw [hT]
        omega
      refine (ih h2 h3 hfuel').mono ?_
      rintro r ⟨st2, hr, hi, hcert, e4, e5, e6, e7, e8⟩
      exact ⟨st2, hr, hi, hcert, e4.trans h4, e5.trans h5, e6.trans h6, e7.trans h7, e8.trans h8⟩
    | abort => exact absurd rfl h1

/-- **Root accuracy** (`R:eq:sec3_internal_error_budget`; L1040): if every edge is certified and the anchor
comparator is accurate, `|μ₀ − c| ≤ p(τ + 2h) + 1.5h`. -/
theorem root_error_le (hP : AccParamsOK P) (hu : CompAdmissible P u) {vals : List (List ℕ)}
    (hvals : ValsOK P vals) {c : ℝ} (hc : CompCond P u vals c) {st : AdaState}
    (hcert : ∀ j < P.p, EdgeCert P st vals j) :
    |musR P st vals 0 - c| ≤ ((rootErr P : ℚ) : ℝ) := by
  have hτ : (0 : ℝ) ≤ P.tau := by exact_mod_cast hP.tau_pos.le
  have hθp : accTheta P P.p = ((P.tau : ℝ) / 64) / (2 * Real.sqrt 2) := by
    unfold accTheta
    rw [if_neg (lt_irrefl _)]
  have hanchor : |musR P st vals P.p - c| ≤ 3 / 2 * ((P.tau : ℝ) / 64) := by
    rw [musR_anchor P st vals (hvals P.p le_rfl)]
    exact (anchor_accuracy (blockX_mem P vals P.p) (by positivity) hθp (hu.reg P.p le_rfl)
      (hc P.p le_rfl)).2.2.2.2
  have htel : musR P st vals 0 - musR P st vals P.p =
      ∑ j ∈ Finset.range P.p, (musR P st vals j - musR P st vals (j + 1)) :=
    (Finset.sum_range_sub' _ _).symm
  have hsum : |∑ j ∈ Finset.range P.p, (musR P st vals j - musR P st vals (j + 1))| ≤
      P.p * ((P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)) := by
    calc _ ≤ ∑ j ∈ Finset.range P.p, |musR P st vals j - musR P st vals (j + 1)| :=
          Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ j ∈ Finset.range P.p, ((P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)) :=
          Finset.sum_le_sum fun j hj => by
            rw [abs_sub_comm]
            exact hcert j (Finset.mem_range.1 hj)
      _ = P.p * ((P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)) := by
          rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have e : musR P st vals 0 - c = (musR P st vals 0 - musR P st vals P.p) + (musR P st vals P.p - c) := by
    ring
  rw [e, htel]
  unfold rootErr
  push_cast
  calc _ ≤ |∑ j ∈ Finset.range P.p, (musR P st vals j - musR P st vals (j + 1))| +
        |musR P st vals P.p - c| := abs_add_le _ _
    _ ≤ _ := by linarith

/-! ## The three entry points -/

theorem getD_map_take {α : Type*} (l : List ℕ) (f : ℕ → α) {p k : ℕ} (hk : k < p) (hl : k < l.length)
    (d : α) : ((l.take p).map f).getD k d = f (l.getD k 0) := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_take_of_lt hk,
    List.getElem?_eq_getElem hl, List.getD_eq_getElem l 0 hl]
  rfl

/-- **Initialization** (Lemma 3.5 (i), L905): the initial state satisfies the invariant (`P₀ ≤ 1`, no
corrections, good initial thresholds), with all counters zero. -/
theorem accInv_init (hP : AccParamsOK P) (hu : CompAdmissible P u) :
    (adaInitD P).GoodPaths (NoiseGood P rad)
      (fun st => AccInv P rad u st ∧ st.rej = 0 ∧ st.nInt = 0 ∧ st.nNum = 0 ∧ st.halted = false) := by
  unfold adaInitD
  refine (drawList_goodPaths P rad NoiseKind.intThr P.p).bind ?_
  rintro thr ⟨hlen, hgood⟩
  simp only [drawNoise, bind_draw, bind_ret, goodPaths_draw, goodPaths_ret]
  intro ko hko
  refine ⟨?_, rfl, rfl, rfl, rfl⟩
  have hlenS : ∀ k < P.p, k < P.blockSizes.length := fun k hk => by rw [hP.sizes_len]; omega
  have htake : (P.blockSizes.take P.p).length = P.p := by simp [hP.sizes_len]
  have hscores : ∀ k < P.p, (adaInitState P thr ko).scores.getD k [] = List.replicate (blockN P k) 0 :=
    fun k hk => getD_map_take P.blockSizes _ hk (hlenS k hk) []
  have hweights : ∀ k < P.p, (adaInitState P thr ko).weights.getD k [] =
      capWeightsQ (scoreScale P) (List.replicate (blockN P k) 0) :=
    fun k hk => getD_map_take P.blockSizes _ hk (hlenS k hk) []
  have hG0 : blockG P (adaInitState P thr ko) = fun _ => 0 := by
    funext j
    funext i
    simp only [blockG, adaInitState, Pi.zero_apply]
    rw [List.getD_eq_getElem?_getD (l := List.map _ _), List.getElem?_map]
    cases (P.blockSizes.take P.p)[j]? with
    | none => simp
    | some nj => simp [List.getD_eq_getElem?_getD]
  have hW0 : weightedT P (adaInitState P thr ko) = 0 := by
    unfold weightedT
    refine Finset.sum_eq_zero fun k _ => ?_
    simp [adaInitState, List.getD_eq_getElem?_getD]
  have hθ : ∀ j < P.p, accTheta P j = (Real.sqrt (P.p * 4 ^ j))⁻¹ := fun j hj => by
    unfold accTheta
    rw [if_pos hj]
  obtain ⟨-, -, hle, hone⟩ := jointPotential_zero_le_one (by have := hP.two_le_p; omega)
    (fun k hk => hP.n_pos k hk.le) (by norm_num : (1 : ℝ) ≤ 8) (P.kappa : ℝ) u hθ
    (fun j hj => hu.reg j hj.le)
  exact
    { scores_len := by simp [adaInitState, hP.sizes_len]
      score_len := fun k hk => by rw [hscores k hk]; simp
      weights_len := by simp [adaInitState, hP.sizes_len]
      weights_eq := fun k hk => by rw [hscores k hk, hweights k hk]
      T_len := by simp [adaInitState]
      thr_len := hlen
      thrInt_good := hgood
      thrOut_good := hko
      potential := by
        unfold statePotential
        rw [hG0, hW0]
        linarith
      halted_rej := by simp [adaInitState]
      rej_le := fun _ => by simp [adaInitState]
      not_capAborted := rfl }

/-! ### Outer certificates (L1042) -/

theorem cert_high (hrad : RadOK P rad) {μ0 ut : ℚ} {thrO kH : ℤ} {c : ℝ}
    (hroot : |(μ0 : ℝ) - c| ≤ ((rootErr P : ℚ) : ℝ)) (hthr : NoiseGood P rad NoiseKind.outThr thrO)
    (hk : NoiseGood P rad NoiseKind.outTest kH)
    (hH : P.a / 2 + P.hA * (thrO : ℚ) ≤ μ0 - ut + P.hA * (kH : ℚ)) :
    ((ut + P.a / 4 - rootErr P : ℚ) : ℝ) ≤ c := by
  unfold NoiseGood at hthr hk
  have h1 := hrad.out
  have h2 := neg_abs_le (P.hA * (thrO : ℚ))
  have h3 := le_abs_self (P.hA * (kH : ℚ))
  have hq : ut + P.a / 4 ≤ μ0 := by linarith
  have hq' : ((ut + P.a / 4 : ℚ) : ℝ) ≤ (μ0 : ℝ) := by exact_mod_cast hq
  have hr := (abs_le.1 hroot).2
  push_cast at hq' ⊢
  linarith

theorem cert_low (hrad : RadOK P rad) {μ0 lt : ℚ} {thrO kL : ℤ} {c : ℝ}
    (hroot : |(μ0 : ℝ) - c| ≤ ((rootErr P : ℚ) : ℝ)) (hthr : NoiseGood P rad NoiseKind.outThr thrO)
    (hk : NoiseGood P rad NoiseKind.outTest kL)
    (hL : P.a / 2 + P.hA * (thrO : ℚ) ≤ lt - μ0 + P.hA * (kL : ℚ)) :
    c ≤ ((lt - P.a / 4 + rootErr P : ℚ) : ℝ) := by
  unfold NoiseGood at hthr hk
  have h1 := hrad.out
  have h2 := neg_abs_le (P.hA * (thrO : ℚ))
  have h3 := le_abs_self (P.hA * (kL : ℚ))
  have hq : μ0 ≤ lt - P.a / 4 := by linarith
  have hq' : (μ0 : ℝ) ≤ ((lt - P.a / 4 : ℚ) : ℝ) := by exact_mod_cast hq
  have hr := (abs_le.1 hroot).1
  push_cast at hq' ⊢
  linarith

theorem cert_accept (hrad : RadOK P rad) {μ0 lt ut : ℚ} {thrO kH kL : ℤ} {c : ℝ}
    (hroot : |(μ0 : ℝ) - c| ≤ ((rootErr P : ℚ) : ℝ)) (hthr : NoiseGood P rad NoiseKind.outThr thrO)
    (hkH : NoiseGood P rad NoiseKind.outTest kH) (hkL : NoiseGood P rad NoiseKind.outTest kL)
    (hH : ¬ P.a / 2 + P.hA * (thrO : ℚ) ≤ μ0 - ut + P.hA * (kH : ℚ))
    (hL : ¬ P.a / 2 + P.hA * (thrO : ℚ) ≤ lt - μ0 + P.hA * (kL : ℚ)) :
    ((lt - 3 / 4 * P.a - rootErr P : ℚ) : ℝ) ≤ c ∧ c ≤ ((ut + 3 / 4 * P.a + rootErr P : ℚ) : ℝ) := by
  unfold NoiseGood at hthr hkH hkL
  have h1 := hrad.out
  have h2 := le_abs_self (P.hA * (thrO : ℚ))
  have h3 := neg_abs_le (P.hA * (kH : ℚ))
  have h4 := neg_abs_le (P.hA * (kL : ℚ))
  push Not at hH hL
  have hqU : μ0 ≤ ut + 3 / 4 * P.a := by linarith
  have hqL : lt - 3 / 4 * P.a ≤ μ0 := by linarith
  have hqU' : (μ0 : ℝ) ≤ ((ut + 3 / 4 * P.a : ℚ) : ℝ) := by exact_mod_cast hqU
  have hqL' : ((lt - 3 / 4 * P.a : ℚ) : ℝ) ≤ (μ0 : ℝ) := by exact_mod_cast hqL
  have hr := abs_le.1 hroot
  push_cast at hqU' hqL' ⊢
  constructor <;> linarith

/-- **`Interval` on the good event** (L1038–1042): the invariant is preserved, a processed request never
returns `abort` (in particular never `CAP_ABORT`), and the certificate is sound. The comparator condition is
needed only for processed requests. -/
theorem interval_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad) (hu : CompAdmissible P u)
    {st : AdaState} (hst : AccInv P rad u st) {vals : List (List ℕ)} (hvals : ValsOK P vals) {c : ℝ}
    (hc : ¬(st.halted = true ∨ P.M ≤ st.nInt) → CompCond P u vals c) (l u' : ℚ) :
    (adaIntervalD P st vals l u').GoodPaths (NoiseGood P rad)
      (fun r => AccInv P rad u r.2 ∧ CertSound P c l u' r.1 ∧ IntervalBook P st r) := by
  unfold adaIntervalD
  split_ifs with hrf
  · simp only [goodPaths_ret]
    exact ⟨hst, trivial, fun _ => rfl, fun h => absurd hrf h⟩
  · have hc' := hc hrf
    have hhalt : st.halted = false := by
      have := (not_or.1 hrf).1
      simpa using this
    have hst1 : AccInv P rad u { st with nInt := st.nInt + 1 } :=
      hst.of_eq rfl rfl rfl rfl hst.thrOut_good hst.halted_rej hst.rej_le hst.not_capAborted
    have hfuel : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0) < P.fuel := by
      unfold AdaParams.fuel
      rw [list_sum_eq_range P.Tmax hP.Tmax_len]
      have : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0) ≤
          ∑ j ∈ Finset.range P.p, P.Tmax.getD j 0 :=
        Finset.sum_le_sum fun j _ => Nat.sub_le _ _
      omega
    have hcache0 : CacheOK P { st with nInt := st.nInt + 1 } vals (List.replicate P.p false) :=
      ⟨by simp, fun k hk h => by simp at h⟩
    refine (prepareRoot_goodPaths hP hrad hu hvals hc' P.fuel hst1 hcache0 hfuel).bind ?_
    rintro r ⟨st2, rfl, hinv, hcert, e1, e2, e3, e4, e5⟩
    simp only at e1 e2 e3 e4 e5
    have hroot := root_error_le hP hu hvals hc' hcert
    have hh2 : st2.halted = false := e4.trans hhalt
    simp only [drawNoise, bind_draw, bind_ret, goodPaths_draw]
    intro kH hkH kL hkL
    split_ifs with hH hL
    · -- HIGH
      have hcs := cert_high hrad hroot hinv.thrOut_good hkH hH
      unfold outerReject
      by_cases hJ : P.J + 1 ≤ st2.rej + 1
      · rw [if_pos hJ, if_pos rfl]
        simp only [goodPaths_ret]
        have hrej : st2.rej = P.J := le_antisymm (hinv.rej_le hh2) (by omega)
        refine ⟨hinv.of_eq rfl rfl rfl rfl hinv.thrOut_good (fun _ => by simp [hrej])
          (fun h => absurd h (by simp)) hinv.not_capAborted, hcs, fun h => absurd h hrf,
          fun _ => ⟨by simp, e1, e2, by simp [AdaCert.isRej, e3], rfl, ?_⟩⟩
        simp only [AdaCert.isTerm, AdaCert.isRej, true_iff, true_and]
        omega
      · rw [if_neg hJ, if_pos rfl]
        simp only [drawNoise, bind_draw, bind_ret, goodPaths_draw, goodPaths_ret]
        intro k hk
        refine ⟨hinv.of_eq rfl rfl rfl rfl hk (fun h => absurd h (by simp [hh2]))
          (fun _ => by simp only; omega) hinv.not_capAborted, hcs, fun h => absurd h hrf,
          fun _ => ⟨by simp, e1, e2, by simp [AdaCert.isRej, e3], by simp [hh2, AdaCert.isTerm], ?_⟩⟩
        simp only [AdaCert.isTerm, AdaCert.isRej, true_and, Bool.false_eq_true, false_iff]
        omega
    · -- LOW
      have hcs := cert_low hrad hroot hinv.thrOut_good hkL hL
      unfold outerReject
      by_cases hJ : P.J + 1 ≤ st2.rej + 1
      · rw [if_pos hJ, if_neg Bool.false_ne_true]
        simp only [goodPaths_ret]
        have hrej : st2.rej = P.J := le_antisymm (hinv.rej_le hh2) (by omega)
        refine ⟨hinv.of_eq rfl rfl rfl rfl hinv.thrOut_good (fun _ => by simp [hrej])
          (fun h => absurd h (by simp)) hinv.not_capAborted, hcs, fun h => absurd h hrf,
          fun _ => ⟨by simp, e1, e2, by simp [AdaCert.isRej, e3], rfl, ?_⟩⟩
        simp only [AdaCert.isTerm, AdaCert.isRej, true_iff, true_and]
        omega
      · rw [if_neg hJ, if_neg Bool.false_ne_true]
        simp only [drawNoise, bind_draw, bind_ret, goodPaths_draw, goodPaths_ret]
        intro k hk
        refine ⟨hinv.of_eq rfl rfl rfl rfl hk (fun h => absurd h (by simp [hh2]))
          (fun _ => by simp only; omega) hinv.not_capAborted, hcs, fun h => absurd h hrf,
          fun _ => ⟨by simp, e1, e2, by simp [AdaCert.isRej, e3], by simp [hh2, AdaCert.isTerm], ?_⟩⟩
        simp only [AdaCert.isTerm, AdaCert.isRej, true_and, Bool.false_eq_true, false_iff]
        omega
    · -- ACCEPT
      simp only [goodPaths_ret]
      exact ⟨hinv, cert_accept hrad hroot hinv.thrOut_good hkH hkL hH hL, fun h => absurd h hrf,
        fun _ => ⟨by simp, e1, e2, by simp [AdaCert.isRej, e3], by simp [hh2, AdaCert.isTerm],
          by simp [AdaCert.isTerm, AdaCert.isRej]⟩⟩

/-- **`Numerical` on the good event** (L1042–1044): the invariant is preserved, a processed request returns a
genuine answer with error at most `Δ_root + a/4 + h_A/2` (for a population value `c ∈ [0, 1]`). -/
theorem numerical_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad) (hu : CompAdmissible P u)
    {st : AdaState} (hst : AccInv P rad u st) {vals : List (List ℕ)} (hvals : ValsOK P vals) {c : ℝ}
    (hc : ¬(st.halted = true ∨ P.R ≤ st.nNum) → CompCond P u vals c) (hc01 : 0 ≤ c ∧ c ≤ 1) :
    (adaNumericalD P st vals).GoodPaths (NoiseGood P rad)
      (fun r => AccInv P rad u r.2 ∧ NumSound P c r.1 ∧ NumericalBook P st r) := by
  unfold adaNumericalD
  split_ifs with hrf
  · simp only [goodPaths_ret]
    exact ⟨hst, trivial, fun _ => rfl, fun h => absurd hrf h⟩
  · have hc' := hc hrf
    have hst1 : AccInv P rad u { st with nNum := st.nNum + 1 } :=
      hst.of_eq rfl rfl rfl rfl hst.thrOut_good hst.halted_rej hst.rej_le hst.not_capAborted
    have hfuel : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0) < P.fuel := by
      unfold AdaParams.fuel
      rw [list_sum_eq_range P.Tmax hP.Tmax_len]
      have : ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0) ≤
          ∑ j ∈ Finset.range P.p, P.Tmax.getD j 0 :=
        Finset.sum_le_sum fun j _ => Nat.sub_le _ _
      omega
    have hcache0 : CacheOK P { st with nNum := st.nNum + 1 } vals (List.replicate P.p false) :=
      ⟨by simp, fun k hk h => by simp at h⟩
    refine (prepareRoot_goodPaths hP hrad hu hvals hc' P.fuel hst1 hcache0 hfuel).bind ?_
    rintro r ⟨st2, rfl, hinv, hcert, e1, e2, e3, e4, e5⟩
    simp only at e1 e2 e3 e4 e5
    have hroot := root_error_le hP hu hvals hc' hcert
    simp only [drawNoise, bind_draw, bind_ret, goodPaths_draw, goodPaths_ret]
    intro k hk
    refine ⟨hinv, ?_, fun h => absurd h hrf, fun _ => ⟨by simp, e2, e1, e3, e4⟩⟩
    -- the numerical answer
    unfold NoiseGood at hk
    have hA0 := hA_pos P
    set μ0 := (adaMus P st2 vals).getD 0 0 with hμ0
    set x := P.hA * (roundIdxQ P.hA (μ0 + P.hA * (k : ℚ)) : ℚ) with hx
    have hround := round_err hA0 (μ0 + P.hA * (k : ℚ))
    have hnum := hrad.num
    refine ⟨le_max_left _ _, max_le (by norm_num) (min_le_left _ _), ?_⟩
    have hxq : |x - μ0| ≤ P.hA / 2 + P.a / 4 := by
      have e : x - μ0 = (x - (μ0 + P.hA * (k : ℚ))) + P.hA * (k : ℚ) := by ring
      rw [e]
      calc |(x - (μ0 + P.hA * (k : ℚ))) + P.hA * (k : ℚ)| ≤
            |x - (μ0 + P.hA * (k : ℚ))| + |P.hA * (k : ℚ)| := abs_add_le _ _
        _ ≤ P.hA / 2 + P.a / 4 := by linarith
    have hxr : |(x : ℝ) - (μ0 : ℝ)| ≤ ((P.hA / 2 + P.a / 4 : ℚ) : ℝ) := by
      rw [← Rat.cast_sub, ← Rat.cast_abs]
      exact_mod_cast hxq
    have hroot' : |(μ0 : ℝ) - c| ≤ ((rootErr P : ℚ) : ℝ) := hroot
    calc |((clipQ 0 1 x : ℚ) : ℝ) - c| ≤ |(x : ℝ) - c| := abs_clipQ01_sub_le x hc01
      _ = |((x : ℝ) - μ0) + ((μ0 : ℝ) - c)| := by ring_nf
      _ ≤ |(x : ℝ) - μ0| + |(μ0 : ℝ) - c| := abs_add_le _ _
      _ ≤ ((rootErr P + P.a / 4 + P.hA / 2 : ℚ) : ℝ) := by
          push_cast at hxr hroot' ⊢
          linarith

end F2e2e.B
