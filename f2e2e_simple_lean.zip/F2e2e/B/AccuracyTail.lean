import F2e2e.B.AccuracyDefs
import F2e2e.B.ArchParamsBridge

/-!
# Theorem `R:thm:validation_ada` (P5): parameter facts, noise radii and noise tails

Paper: `parts/partII.tex` L1036 ("From `R:eq:sec3_hA_def`–`R:eq:sec3_noise_scales` and
`R:eq:sec3_lattice_dp_tail`, the ideal internal noises exceed `h`, outer noises exceed `a/8`, or numerical noises
exceed `a/4`, with total probability below `ξ_A/100`; for example, all these tails are bounded by `2e^{−8χ}`.
Adding the sampler coupling error retains this bound with harmless slack."), Lemma `R:lem:sec3_sampler`,
Definition `R:def:sec3_ada_params`; numeric certificates `notes/PAPER_MAP_II_b.md` §II.3.6 (tails, accuracy).

* `accRad P χ κ = 16 χ · scale κ`: internal radii `≤ h/2`, outer `≤ a/8`, numerical `= a/4` (`radOK_alg2`);
* `adaDraw_bad_le`: a bounded-sampler draw exceeds its radius with probability `≤ 2e^{−8χ} + ζ`
  (`P[|Z| ≥ 16χb] ≤ 2e^{−16χb/(b+h_A)}`, `h_A ≤ b`, plus the sampler's TV `< ζ`);
* `noise_budget_alg2`: at most `Q` draws on every execution (the count of (P1)) give total probability
  `≤ Q(2e^{−8χ} + ζ) ≤ ξ_A/100`;
* `accParamsOK_alg2`, `accMargins_alg2`: the facts and margins used by the deterministic analysis for the
  parameters of Definition `R:def:sec3_ada_params` at accuracy `a_req − h_A`.
-/

namespace F2e2e.B

open F2e2e.Discrete

/-- `χ` of Definition `R:def:sec3_ada_params` for `a_req`, `ξ_req` and caps `M, J, R`. -/
noncomputable def accChi (M J R : ℕ) (aReq ξReq : ℝ) : ℕ :=
  adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)

/-- `ξ_A` of Definition `R:def:sec3_ada_params`. -/
noncomputable def accXiA (ξReq : ℝ) : ℝ := (adaXiA (dyadicExp ξReq) : ℝ)

/-- `Q = 100 (p+1)(M + R + J + 2 + ∑_{j<p} T_j^max)`, the bound of (P1) on the number of draws. -/
noncomputable def accQ (M J R : ℕ) (aReq : ℝ) : ℕ := adaQ M J R (dyadicExp aReq)

/-- The noise radii `16 χ b` of the draws of scale `b` (L1036): internal threshold `h/4`, internal test `h/2`,
outer threshold `a/16`, outer test `a/8`, numerical `a/4`. -/
def accRad (P : AdaParams) (χ : ℕ) (κ : NoiseKind) : ℚ := 16 * χ * P.scale κ

section Alg2

variable (M J R : ℕ) {aReq ξReq : ℝ}

theorem alg2_hA_pos : 0 < (adaAlg2Params M J R aReq ξReq).hA := by
  show (0 : ℚ) < (1 / 2 : ℚ) ^ (adaAlg2Params M J R aReq ξReq).qA
  positivity

theorem accTail_two_le_adaP (eA : ℕ) : 2 ≤ adaP eA := (Nat.find_spec (exists_adaP eA)).1

theorem accTail_adaChi_pos (M J R eA eXi : ℕ) : 0 < adaChi M J R eA eXi := by
  unfold adaChi; omega

theorem accTail_adaBlockSizes_getD (M J R eA eXi : ℕ) {j : ℕ} (hj : j ≤ adaP eA) :
    (adaBlockSizes M J R eA eXi).getD j 0 = adaNBlock M J R eA eXi j := by
  unfold adaBlockSizes
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range (by omega)]
  rfl

theorem accTail_adaTmaxList_getD (eA : ℕ) {j : ℕ} (hj : j < adaP eA) :
    (adaTmaxList eA).getD j 0 = adaTmax eA j := by
  unfold adaTmaxList
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj]
  rfl

theorem accParamsOK_alg2 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    AccParamsOK (adaAlg2Params M J R aReq ξReq) := by
  have _hyp := hξ0
  have _hyp' := hξ1
  have hp2 := accTail_two_le_adaP (dyadicExp aReq)
  have hpQ : (0 : ℚ) < adaP (dyadicExp aReq) := by exact_mod_cast (show 0 < adaP (dyadicExp aReq) by omega)
  refine
    { two_le_p := hp2
      sizes_len := by
        show (adaBlockSizes M J R (dyadicExp aReq) (dyadicExp ξReq)).length = adaP (dyadicExp aReq) + 1
        simp [adaBlockSizes]
      n_pos := fun j hj => ?_
      Tmax_len := by
        show (adaTmaxList (dyadicExp aReq)).length = adaP (dyadicExp aReq)
        simp [adaTmaxList]
      Tmax_eq := fun j hj => ?_
      tau_pos := by
        show (0 : ℚ) < adaA (dyadicExp aReq) / (8 * adaP (dyadicExp aReq))
        unfold adaA
        positivity
      kappa_eq := rfl
      a_pos := by
        show (0 : ℚ) < adaA (dyadicExp aReq)
        unfold adaA
        positivity
      a_le := ?_ }
  · show 0 < (adaBlockSizes M J R (dyadicExp aReq) (dyadicExp ξReq)).getD j 0
    rw [accTail_adaBlockSizes_getD M J R _ _ hj]
    unfold adaNBlock
    have hχ := accTail_adaChi_pos M J R (dyadicExp aReq) (dyadicExp ξReq)
    have hh : 0 < adaHInv (dyadicExp aReq) :=
      Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (pow_pos (by norm_num) _)
    have h2 : 0 < 2 ^ 12 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) * adaHInv (dyadicExp aReq) ^ 2 :=
      Nat.mul_pos (Nat.mul_pos (by norm_num) hχ) (pow_pos hh 2)
    exact Nat.lt_of_lt_of_le h2 (Nat.le_add_left _ _)
  · show (adaTmaxList (dyadicExp aReq)).getD j 0 = _
    rw [accTail_adaTmaxList_getD _ hj]
    unfold adaTmax
    rw [if_pos (show j < adaP (dyadicExp aReq) from hj)]
    rfl
  · show adaA (dyadicExp aReq) ≤ 1 / 10
    have h1 : ((adaA (dyadicExp aReq) : ℚ) : ℝ) ≤ aReq := by
      rw [adaA_cast]
      exact alg2A_le ha0
    have h2 : ((adaA (dyadicExp aReq) : ℚ) : ℝ) ≤ ((1 / 10 : ℚ) : ℝ) := by
      push_cast
      linarith
    exact_mod_cast h2

theorem radOK_alg2 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    RadOK (adaAlg2Params M J R aReq ξReq) (accRad (adaAlg2Params M J R aReq ξReq) (accChi M J R aReq ξReq)) := by
  have _hyp := ha0
  have _hyp' := ha1
  have _hyp'' := hξ0
  have _hyp''' := hξ1
  have hχ : (0 : ℚ) < adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) := by
    exact_mod_cast accTail_adaChi_pos M J R (dyadicExp aReq) (dyadicExp ξReq)
  have hp2 := accTail_two_le_adaP (dyadicExp aReq)
  have hpQ : (0 : ℚ) < adaP (dyadicExp aReq) := by exact_mod_cast (show 0 < adaP (dyadicExp aReq) by omega)
  have hτ : (0 : ℚ) < adaTauQ (dyadicExp aReq) := by
    unfold adaTauQ adaA
    positivity
  have ha : (0 : ℚ) < adaA (dyadicExp aReq) := by unfold adaA; positivity
  refine ⟨?_, ?_, ?_⟩
  · show 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (2 * (adaH (dyadicExp aReq) / (128 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) +
      16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (4 * (adaH (dyadicExp aReq) / (128 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) ≤
      2 * (adaTauQ (dyadicExp aReq) / 64)
    have e : 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (2 * (adaH (dyadicExp aReq) / (128 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) +
      16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (4 * (adaH (dyadicExp aReq) / (128 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) =
        3 / 4 * adaH (dyadicExp aReq) := by
      field_simp
      ring
    rw [e]
    unfold adaH
    linarith
  · show 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (2 * (adaA (dyadicExp aReq) / (512 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) +
      16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (4 * (adaA (dyadicExp aReq) / (512 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) ≤
      adaA (dyadicExp aReq) / 4
    have e : 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (2 * (adaA (dyadicExp aReq) / (512 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) +
      16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (4 * (adaA (dyadicExp aReq) / (512 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)))) =
        3 / 16 * adaA (dyadicExp aReq) := by
      field_simp
      ring
    rw [e]
    linarith
  · show 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (adaA (dyadicExp aReq) / (64 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq))) ≤
      adaA (dyadicExp aReq) / 4
    have e : 16 * (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℚ) *
        (adaA (dyadicExp aReq) / (64 * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq))) =
        adaA (dyadicExp aReq) / 4 := by
      field_simp
      ring
    rw [e]

/-- `Δ_root` of the computable parameters is the paper's `alg2DeltaRoot`. -/
theorem accTail_rootErr_cast (aReq ξReq : ℝ) :
    ((rootErr (adaAlg2Params M J R aReq ξReq) : ℚ) : ℝ) = alg2DeltaRoot aReq := by
  unfold rootErr alg2DeltaRoot
  have hp : ((adaAlg2Params M J R aReq ξReq).p : ℝ) = alg2P aReq := by
    exact_mod_cast adaP_eq aReq
  have ht : (((adaAlg2Params M J R aReq ξReq).tau : ℚ) : ℝ) = alg2Tau aReq := adaTau_cast aReq
  push_cast
  rw [hp, ht, alg2H_eq_tau]

/-- The accuracy margins at `a_req − h_A` (L1042–1046: `0.131a + 3a/4 + h_A < a ≤ a_req` etc.). -/
theorem accMargins_alg2 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    AccMargins (adaAlg2Params M J R aReq ξReq) (aReq - ((adaAlg2Params M J R aReq ξReq).hA : ℝ)) := by
  have hA : (((adaAlg2Params M J R aReq ξReq).hA : ℚ) : ℝ) = alg2HA M J R aReq ξReq :=
    adaParams_hA_cast M J R ha0 ha1 hξ0 hξ1
  have ha : (((adaAlg2Params M J R aReq ξReq).a : ℚ) : ℝ) = alg2A aReq := adaA_cast aReq
  have hr := accTail_rootErr_cast M J R aReq ξReq
  have h1 := alg2DeltaRoot_lt aReq
  have h2 := alg2HA_le_a M J R aReq ξReq
  have h3 := alg2A_le ha0
  have h4 := alg2A_pos aReq
  have h5 := alg2HA_pos M J R aReq ξReq
  have h6 := alg2A_le_one aReq
  refine ⟨?_, ?_, ?_, ?_⟩
  · push_cast
    rw [ha, hr, hA]
    linarith
  · push_cast
    rw [ha, hr, hA]
    linarith
  · have h : ((rootErr (adaAlg2Params M J R aReq ξReq) + (adaAlg2Params M J R aReq ξReq).hA / 2 : ℚ) : ℝ) ≤
        (((adaAlg2Params M J R aReq ξReq).a / 4 : ℚ) : ℝ) := by
      push_cast
      rw [ha, hr, hA]
      linarith
    exact_mod_cast h
  · have h : ((3 / 4 * (adaAlg2Params M J R aReq ξReq).a + rootErr (adaAlg2Params M J R aReq ξReq) +
        (adaAlg2Params M J R aReq ξReq).hA / 2 : ℚ) : ℝ) < ((1 : ℚ) : ℝ) := by
      push_cast
      rw [ha, hr, hA]
      linarith
    exact_mod_cast h

/-- A sharper form of B-NUM's `tail_total_lt`: `Q · 2e^{-8χ} ≤ 2 ξ_A/2^40`. -/
theorem accTail_tail_total_le (aReq ξReq : ℝ) :
    (alg2Q M J R aReq : ℝ) * (2 * Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ)))) ≤
      2 * (alg2XiA ξReq / 2 ^ 40) := by
  have hexp := exp_neg_natCast_le (alg2Chi M J R aReq ξReq)
  have hinv := inv_two_pow_valChi_le M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change ((2 : ℝ) ^ alg2Chi M J R aReq ξReq)⁻¹ ≤
    alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    at hinv
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have hξ := alg2XiA_pos ξReq
  have hξ1 := alg2XiA_le_one ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hQ := alg2Q_pos_real M J R aReq
  set y := alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    with hy
  have hy0 : 0 < y := by rw [hy]; positivity
  have hQy : (alg2Q M J R aReq : ℝ) * y ≤ alg2XiA ξReq / 2 ^ 40 := by
    rw [hy, mul_div_assoc', div_le_div_iff₀ (by positivity) (by norm_num)]
    have h1 : alg2H aReq * alg2XiA ξReq ≤ alg2XiA ξReq := by nlinarith
    calc (alg2Q M J R aReq : ℝ) * (alg2H aReq * alg2XiA ξReq) * 2 ^ 40
        ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 := by gcongr
      _ ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 * ((alg2P aReq : ℝ) + 1) := by
          have : 0 ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 := by positivity
          nlinarith
      _ = alg2XiA ξReq * (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) := by ring
  have hy1 : y ≤ 1 := by
    have : (alg2Q M J R aReq : ℝ) * y ≤ 1 := by
      have : alg2XiA ξReq / 2 ^ 40 ≤ 1 := by
        rw [div_le_one (by norm_num)]
        linarith
      linarith
    have hQ1 : (1 : ℝ) ≤ alg2Q M J R aReq := by
      have := six_hundred_le_valQ M J R (alg2A_pos aReq)
      have : (600 : ℝ) ≤ alg2Q M J R aReq := by exact_mod_cast this
      linarith
    nlinarith
  have he1 : Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ≤ y := hexp.trans hinv
  have he8 : Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))) =
      Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ^ 8 := by
    rw [← Real.exp_nat_mul]
    ring_nf
  have he8' : Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))) ≤ y := by
    rw [he8]
    calc Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ^ 8 ≤ y ^ 8 :=
          pow_le_pow_left₀ (Real.exp_pos _).le he1 8
      _ ≤ y ^ 1 := pow_le_pow_of_le_one hy0.le hy1 (by norm_num)
      _ = y := pow_one y
  calc (alg2Q M J R aReq : ℝ) * (2 * Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))))
      ≤ (alg2Q M J R aReq : ℝ) * (2 * y) := by gcongr
    _ = 2 * ((alg2Q M J R aReq : ℝ) * y) := by ring
    _ ≤ 2 * (alg2XiA ξReq / 2 ^ 40) := by linarith

/-- **Noise budget** (L1036): `Q (2e^{−8χ} + ζ) ≤ ξ_A/100`. -/
theorem noise_budget_alg2 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ((accQ M J R aReq : ℕ) : ENNReal) *
        ENNReal.ofReal (2 * Real.exp (-(8 * (accChi M J R aReq ξReq : ℝ))) +
          ((adaAlg2Params M J R aReq ξReq).zeta : ℝ)) ≤
      ENNReal.ofReal (accXiA ξReq / 100) := by
  have hQ : ((accQ M J R aReq : ℕ) : ℝ) = (alg2Q M J R aReq : ℝ) := by
    unfold accQ
    exact_mod_cast adaQ_eq M J R aReq
  have hχ : ((accChi M J R aReq ξReq : ℕ) : ℝ) = (alg2Chi M J R aReq ξReq : ℝ) := by
    unfold accChi
    exact_mod_cast adaChi_eq M J R ha0 ha1 hξ0 hξ1
  have hz : (((adaAlg2Params M J R aReq ξReq).zeta : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq :=
    adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1
  have hxi : accXiA ξReq = alg2XiA ξReq := adaXiA_cast ξReq
  rw [← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
  apply ENNReal.ofReal_le_ofReal
  rw [hQ, hχ, hz, hxi, mul_add, alg2Q_mul_alg2Zeta]
  have h1 := accTail_tail_total_le M J R aReq ξReq
  have hξ := alg2XiA_pos ξReq
  have h2 : alg2Delta aReq ξReq ≤ alg2XiA ξReq / 192 := by
    unfold alg2Delta alg2XiJ
    have hh := alg2H_pos aReq
    have hh1 := alg2H_le_one aReq
    have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
    have hX : alg2XiA ξReq / (8 * ((alg2P aReq : ℝ) + 1)) ≤ alg2XiA ξReq / 8 :=
      div_le_div_of_nonneg_left hξ.le (by norm_num) (by linarith)
    have hX0 : 0 ≤ alg2XiA ξReq / (8 * ((alg2P aReq : ℝ) + 1)) := by positivity
    have : alg2H aReq * (alg2XiA ξReq / (8 * ((alg2P aReq : ℝ) + 1))) ≤ alg2XiA ξReq / 8 := by
      nlinarith
    linarith
  linarith

/-- **Noise tail of one draw, generic form.** -/
theorem accTail_adaDraw_bad_le_of {P : AdaParams} (κ : NoiseKind) (χ : ℕ)
    (hb : 0 < P.scale κ) (hA0 : 0 < P.hA) (hζ : 0 < P.zeta) (hAb : P.hA ≤ P.scale κ)
    (hB0 : P.B0 = Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊) :
    (adaDraw P κ).law.toOuterMeasure {k | ¬ NoiseGood P (accRad P χ) κ k} ≤
      ENNReal.ofReal (2 * Real.exp (-(8 * (χ : ℝ))) + (P.zeta : ℝ)) := by
  set b := P.scale κ with hbdef
  have hbR : (0 : ℝ) < (b : ℝ) := by exact_mod_cast hb
  have hAR : (0 : ℝ) < (P.hA : ℝ) := by exact_mod_cast hA0
  have hζR : (0 : ℝ) < (P.zeta : ℝ) := by exact_mod_cast hζ
  have hρpos : 0 < P.rho b := by unfold AdaParams.rho; positivity
  have hρ : (((P.rho b).num.toNat : ℕ) : ℝ) / ((P.rho b).den : ℝ) = latticeRho (b : ℝ) (P.hA : ℝ) := by
    have hnum : 0 ≤ (P.rho b).num := Rat.num_nonneg.mpr hρpos.le
    have h1 : (((P.rho b).num.toNat : ℕ) : ℝ) = (((P.rho b).num : ℤ) : ℝ) := by
      rw [← Int.cast_natCast, Int.toNat_of_nonneg hnum]
    rw [h1, ← Rat.cast_def]
    unfold AdaParams.rho latticeRho
    push_cast
    ring
  have hB : 16 / (P.zeta : ℝ) ≤ 2 ^ P.B0 := by
    rw [hB0]
    have h1 : ((16 : ℚ) / P.zeta : ℚ) ≤ (⌈(16 : ℚ) / P.zeta⌉₊ : ℚ) := Nat.le_ceil _
    have h2 : ⌈(16 : ℚ) / P.zeta⌉₊ ≤ 2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ :=
      Nat.le_pow_clog (by norm_num) _
    have h3 : (((16 : ℚ) / P.zeta : ℚ) : ℝ) ≤ ((2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ : ℕ) : ℝ) := by
      have h4 : ((16 : ℚ) / P.zeta : ℚ) ≤ ((2 ^ Nat.clog 2 ⌈(16 : ℚ) / P.zeta⌉₊ : ℕ) : ℚ) :=
        h1.trans (by exact_mod_cast h2)
      exact_mod_cast h4
    push_cast at h3
    exact h3
  have hK : ((b : ℝ) + P.hA) / P.hA * (P.B0 : ℝ) ≤ (P.Ks b : ℝ) := by
    have h1 : ((b + P.hA) / P.hA * P.B0 : ℚ) ≤ (P.Ks b : ℚ) := Nat.le_ceil _
    have h2 : (((b + P.hA) / P.hA * P.B0 : ℚ) : ℝ) ≤ ((P.Ks b : ℚ) : ℝ) := by exact_mod_cast h1
    push_cast at h2
    exact h2
  have hr : 32 * ((P.Ks b : ℝ) + 1) / P.zeta ≤ 2 ^ P.rs b := by
    have h1 : (32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) ≤ (⌈32 * ((P.Ks b : ℚ) + 1) / P.zeta⌉₊ : ℚ) :=
      Nat.le_ceil _
    have h2 : ⌈32 * ((P.Ks b : ℚ) + 1) / P.zeta⌉₊ ≤ 2 ^ P.rs b := Nat.le_pow_clog (by norm_num) _
    have h3 : ((32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) : ℝ) ≤ ((2 ^ P.rs b : ℕ) : ℝ) := by
      have h4 : (32 * ((P.Ks b : ℚ) + 1) / P.zeta : ℚ) ≤ ((2 ^ P.rs b : ℕ) : ℚ) :=
        h1.trans (Nat.cast_le.mpr h2)
      exact_mod_cast h4
    push_cast at h3
    exact h3
  have htv := tv_latticeSampler_lt hbR hAR hζR hρ hB hK hr
  have hsub : {k | ¬ NoiseGood P (accRad P χ) κ k} ⊆
      {k : ℤ | ((16 * χ * b : ℚ) : ℝ) ≤ |(P.hA : ℝ) * (k : ℝ)|} := by
    intro k hk
    simp only [Set.mem_ofPred_eq, NoiseGood, accRad, not_le] at hk ⊢
    have h5 : ((16 * χ * b : ℚ) : ℝ) < ((|P.hA * (k : ℚ)| : ℚ) : ℝ) := by exact_mod_cast hk
    push_cast at h5 ⊢
    exact h5.le
  have htail := latticeLaw_tail_le hbR hAR (u := ((16 * χ * b : ℚ) : ℝ)) (by push_cast; positivity)
  have hexp : 2 * Real.exp (-((16 * χ * b : ℚ) : ℝ) / ((b : ℝ) + P.hA)) ≤
      2 * Real.exp (-(8 * (χ : ℝ))) := by
    have hχ0 : (0 : ℝ) ≤ χ := Nat.cast_nonneg _
    have hAbR : (P.hA : ℝ) ≤ b := by exact_mod_cast hAb
    have h1 : -((16 * χ * b : ℚ) : ℝ) / ((b : ℝ) + P.hA) ≤ -(8 * (χ : ℝ)) := by
      push_cast
      rw [div_le_iff₀ (by positivity)]
      nlinarith
    have := Real.exp_le_exp.mpr h1
    linarith
  calc (adaDraw P κ).law.toOuterMeasure {k | ¬ NoiseGood P (accRad P χ) κ k}
      ≤ (latticeLaw (latticeRho b P.hA)).toOuterMeasure {k | ¬ NoiseGood P (accRad P χ) κ k} +
          tv (adaDraw P κ).law (latticeLaw (latticeRho b P.hA)) :=
        toOuterMeasure_le_add_tv _ _ _
    _ ≤ ENNReal.ofReal (2 * Real.exp (-(8 * (χ : ℝ)))) + ENNReal.ofReal (P.zeta : ℝ) := by
        refine add_le_add ?_ htv.le
        exact (MeasureTheory.measure_mono hsub).trans (htail.trans (ENNReal.ofReal_le_ofReal hexp))
    _ = ENNReal.ofReal (2 * Real.exp (-(8 * (χ : ℝ))) + (P.zeta : ℝ)) :=
        (ENNReal.ofReal_add (by positivity) hζR.le).symm

/-- Every noise scale of the instance is at least `h/(64χ) ≥ h_A`. -/
theorem accTail_hA_le_scale (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (κ : NoiseKind) :
    0 < (adaAlg2Params M J R aReq ξReq).scale κ ∧
      (adaAlg2Params M J R aReq ξReq).hA ≤ (adaAlg2Params M J R aReq ξReq).scale κ := by
  have hAr : (((adaAlg2Params M J R aReq ξReq).hA : ℚ) : ℝ) = alg2HA M J R aReq ξReq :=
    adaParams_hA_cast M J R ha0 ha1 hξ0 hξ1
  have hbI : (((adaAlg2Params M J R aReq ξReq).bInt : ℚ) : ℝ) = alg2BInt M J R aReq ξReq :=
    adaParams_bInt_cast M J R ha0 ha1 hξ0 hξ1
  have hbO : (((adaAlg2Params M J R aReq ξReq).bOut : ℚ) : ℝ) = alg2BOut M J R aReq ξReq :=
    adaParams_bOut_cast M J R ha0 ha1 hξ0 hξ1
  have hbN : (((adaAlg2Params M J R aReq ξReq).bNum : ℚ) : ℝ) = alg2BNum M J R aReq ξReq :=
    adaParams_bNum_cast M J R ha0 ha1 hξ0 hξ1
  have hχ1 := one_le_alg2Chi_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hha : alg2H aReq ≤ alg2A aReq / 1024 := valH_le (alg2A_pos aReq)
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hHA := alg2HA_le_first M J R aReq ξReq
  have hχ0 : (0 : ℝ) < (alg2Chi M J R aReq ξReq : ℝ) := by linarith
  have hχne : (alg2Chi M J R aReq ξReq : ℝ) ≠ 0 := hχ0.ne'
  have hX0 : 0 < alg2H aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ)) := by positivity
  have hAX : alg2HA M J R aReq ξReq ≤ alg2H aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ)) :=
    hHA.trans (div_le_div_of_nonneg_left hh.le (by positivity) (by nlinarith))
  have hscale : alg2H aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ)) ≤
      (((adaAlg2Params M J R aReq ξReq).scale κ : ℚ) : ℝ) := by
    rw [div_le_iff₀ (by positivity)]
    cases κ
    · show alg2H aReq ≤ ((2 * (adaAlg2Params M J R aReq ξReq).bInt : ℚ) : ℝ) * (64 * (alg2Chi M J R aReq ξReq : ℝ))
      push_cast
      rw [hbI]
      unfold alg2BInt
      have e : 2 * (alg2H aReq / (128 * (alg2Chi M J R aReq ξReq : ℝ))) * (64 * (alg2Chi M J R aReq ξReq : ℝ)) =
          alg2H aReq := by
        field_simp
        ring
      linarith
    · show alg2H aReq ≤ ((4 * (adaAlg2Params M J R aReq ξReq).bInt : ℚ) : ℝ) * (64 * (alg2Chi M J R aReq ξReq : ℝ))
      push_cast
      rw [hbI]
      unfold alg2BInt
      have e : 4 * (alg2H aReq / (128 * (alg2Chi M J R aReq ξReq : ℝ))) * (64 * (alg2Chi M J R aReq ξReq : ℝ)) =
          2 * alg2H aReq := by
        field_simp
        ring
      linarith
    · show alg2H aReq ≤ ((2 * (adaAlg2Params M J R aReq ξReq).bOut : ℚ) : ℝ) * (64 * (alg2Chi M J R aReq ξReq : ℝ))
      push_cast
      rw [hbO]
      unfold alg2BOut
      have e : 2 * (alg2A aReq / (512 * (alg2Chi M J R aReq ξReq : ℝ))) * (64 * (alg2Chi M J R aReq ξReq : ℝ)) =
          alg2A aReq / 4 := by
        field_simp
        ring
      linarith
    · show alg2H aReq ≤ ((4 * (adaAlg2Params M J R aReq ξReq).bOut : ℚ) : ℝ) * (64 * (alg2Chi M J R aReq ξReq : ℝ))
      push_cast
      rw [hbO]
      unfold alg2BOut
      have e : 4 * (alg2A aReq / (512 * (alg2Chi M J R aReq ξReq : ℝ))) * (64 * (alg2Chi M J R aReq ξReq : ℝ)) =
          alg2A aReq / 2 := by
        field_simp
        ring
      linarith
    · show alg2H aReq ≤ (((adaAlg2Params M J R aReq ξReq).bNum : ℚ) : ℝ) * (64 * (alg2Chi M J R aReq ξReq : ℝ))
      rw [hbN]
      unfold alg2BNum
      have e : alg2A aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ)) * (64 * (alg2Chi M J R aReq ξReq : ℝ)) =
          alg2A aReq := by
        field_simp
      linarith
  refine ⟨?_, ?_⟩
  · have : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).scale κ : ℚ) : ℝ) := hX0.trans_le hscale
    exact_mod_cast this
  · have : (((adaAlg2Params M J R aReq ξReq).hA : ℚ) : ℝ) ≤ (((adaAlg2Params M J R aReq ξReq).scale κ : ℚ) : ℝ) := by
      rw [hAr]
      exact hAX.trans hscale
    exact_mod_cast this

/-- **Noise tail of one draw** (Lemma `R:lem:sec3_sampler`, L1036): a bounded-sampler draw of any kind exceeds
its radius `16 χ b` with probability at most `2e^{−8χ} + ζ`. -/
theorem adaDraw_bad_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (κ : NoiseKind) :
    (adaDraw (adaAlg2Params M J R aReq ξReq) κ).law.toOuterMeasure
        {k | ¬ NoiseGood (adaAlg2Params M J R aReq ξReq)
          (accRad (adaAlg2Params M J R aReq ξReq) (accChi M J R aReq ξReq)) κ k} ≤
      ENNReal.ofReal (2 * Real.exp (-(8 * (accChi M J R aReq ξReq : ℝ))) +
        ((adaAlg2Params M J R aReq ξReq).zeta : ℝ)) := by
  obtain ⟨hb, hAb⟩ := accTail_hA_le_scale M J R ha0 ha1 hξ0 hξ1 κ
  have hζ : 0 < (adaAlg2Params M J R aReq ξReq).zeta := by
    have hz : (((adaAlg2Params M J R aReq ξReq).zeta : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq :=
      adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1
    have h1 : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).zeta : ℚ) : ℝ) := by
      rw [hz]
      exact alg2Zeta_pos M J R aReq ξReq
    exact_mod_cast h1
  exact accTail_adaDraw_bad_le_of κ (accChi M J R aReq ξReq) hb (alg2_hA_pos M J R) hζ hAb rfl

end Alg2

end F2e2e.B
