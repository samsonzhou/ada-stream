import F2e2e.B.ArchOnline

/-!
# Draw counts of the online execution (P1 of the proof of Theorem `R:thm:validation_ada`)

* Generic: `AllOut prog Q` (every output of a noise-draw program satisfies `Q`) and
  `DrawsBudget prog B Φ` (on every path, the number of draws plus `Φ` of the output is at most `B`),
  which compose along `bind` with state-dependent budgets.
* Frame facts: the internal operations of `PrepareRoot` never touch the request counters.
* `coreStepD_budget`, `coreRunD_drawsLE`: an online execution of any length makes at most
  `p + 1 + (M + R) · (fuel (2p + 3) + 3)` draws (only the at most `M + R` processed requests draw),
  hence `coreRun_depth_le`: it reads at most `adaCoins P` fresh bits.
-/

namespace F2e2e.B

open F2e2e.Discrete

/-! ## Generic path predicates for noise-draw programs -/

section Generic

variable {Pm β α γ : Type}

/-- Every output of `prog` satisfies `Q`. -/
def AllOut : DrawProg Pm β α → (α → Prop) → Prop
  | DrawProg.ret a, Q => Q a
  | DrawProg.draw _ k, Q => ∀ b, AllOut (k b) Q

theorem allOut_ret {a : α} {Q : α → Prop} (h : Q a) : AllOut (DrawProg.ret a : DrawProg Pm β α) Q :=
  h

theorem AllOut.mono {prog : DrawProg Pm β α} {Q R : α → Prop} (h : AllOut prog Q)
    (hQR : ∀ a, Q a → R a) : AllOut prog R := by
  induction prog with
  | ret a => exact hQR a h
  | draw p k ih => exact fun b => ih b (h b)

theorem AllOut.bind {prog : DrawProg Pm β α} {f : α → DrawProg Pm β γ} {Q : α → Prop}
    {R : γ → Prop} (h : AllOut prog Q) (hf : ∀ a, Q a → AllOut (f a) R) :
    AllOut (prog.bind f) R := by
  induction prog with
  | ret a => exact hf a h
  | draw p k ih => exact fun b => ih b (h b)

/-- On every path, the number of draws plus `Φ` of the output is at most `B`. -/
def DrawsBudget : DrawProg Pm β α → ℕ → (α → ℕ) → Prop
  | DrawProg.ret a, B, Φ => Φ a ≤ B
  | DrawProg.draw _ _, 0, _ => False
  | DrawProg.draw _ k, B + 1, Φ => ∀ b, DrawsBudget (k b) B Φ

theorem DrawsBudget.mono {prog : DrawProg Pm β α} {B B' : ℕ} {Φ : α → ℕ}
    (h : DrawsBudget prog B Φ) (hB : B ≤ B') : DrawsBudget prog B' Φ := by
  induction prog generalizing B B' with
  | ret a => exact le_trans h hB
  | draw p k ih =>
    cases B with
    | zero => exact h.elim
    | succ B =>
      cases B' with
      | zero => omega
      | succ B' => exact fun b => ih b (h b) (by omega)

theorem DrawsBudget.bind {prog : DrawProg Pm β α} {f : α → DrawProg Pm β γ} {B : ℕ}
    {Φ : α → ℕ} {Ψ : γ → ℕ} (h : DrawsBudget prog B Φ) (hf : ∀ a, DrawsBudget (f a) (Φ a) Ψ) :
    DrawsBudget (prog.bind f) B Ψ := by
  induction prog generalizing B with
  | ret a => exact (hf a).mono h
  | draw p k ih =>
    cases B with
    | zero => exact h.elim
    | succ B => exact fun b => ih b (h b)

theorem DrawsBudget.drawsLE {prog : DrawProg Pm β α} {B : ℕ} {Φ : α → ℕ}
    (h : DrawsBudget prog B Φ) : prog.DrawsLE B := by
  induction prog generalizing B with
  | ret a => cases B <;> trivial
  | draw p k ih =>
    cases B with
    | zero => exact h.elim
    | succ B => exact fun b => ih b (h b)

/-- A program with no outputs satisfying `Q` cannot have all its outputs in `Q` (draw outcomes
range over a nonempty type). -/
theorem allOut_false [Nonempty β] {q : DrawProg Pm β α} {Q : α → Prop} (hQ : ∀ a, ¬ Q a)
    (h : AllOut q Q) : False := by
  induction q with
  | ret a => exact hQ a h
  | draw p k ih => exact ih (Classical.arbitrary β) (h _)

/-- A program with at most `m` draws whose outputs all satisfy `Φ a + m ≤ B` has budget `B`. -/
theorem drawsBudget_of [Nonempty β] {prog : DrawProg Pm β α} {m B : ℕ} {Φ : α → ℕ}
    (h1 : prog.DrawsLE m) (h2 : AllOut prog fun a => Φ a + m ≤ B) : DrawsBudget prog B Φ := by
  induction prog generalizing m B with
  | ret a => exact le_trans (Nat.le_add_right _ _) h2
  | draw p k ih =>
    cases m with
    | zero => exact h1.elim
    | succ m =>
      cases B with
      | zero => exact allOut_false (fun a ha => by omega) h2
      | succ B => exact fun b => ih b (h1 b) ((h2 b).mono fun a ha => by omega)

theorem allOut_true (prog : DrawProg Pm β α) : AllOut prog fun _ => True := by
  induction prog with
  | ret a => trivial
  | draw p k ih => exact fun b => ih b

theorem DrawsBudget.map {prog : DrawProg Pm β α} {B : ℕ} {f : α → γ} {Φ : γ → ℕ}
    (h : DrawsBudget prog B (Φ ∘ f)) : DrawsBudget (prog.map f) B Φ :=
  h.bind fun _ => le_refl _

/-- `bind` with a continuation budget needed only on the outputs satisfying an invariant. -/
theorem DrawsBudget.bind_of_allOut {prog : DrawProg Pm β α} {f : α → DrawProg Pm β γ} {B : ℕ}
    {Φ : α → ℕ} {Ψ : γ → ℕ} {Q : α → Prop} (h : DrawsBudget prog B Φ) (hQ : AllOut prog Q)
    (hf : ∀ a, Q a → DrawsBudget (f a) (Φ a) Ψ) : DrawsBudget (prog.bind f) B Ψ := by
  induction prog generalizing B with
  | ret a => exact (hf a hQ).mono h
  | draw p k ih =>
    cases B with
    | zero => exact h.elim
    | succ B => exact fun b => ih b (h b) (hQ b)

theorem AllOut.and {prog : DrawProg Pm β α} {Q R : α → Prop} (hQ : AllOut prog Q)
    (hR : AllOut prog R) : AllOut prog fun a => Q a ∧ R a := by
  induction prog with
  | ret a => exact ⟨hQ, hR⟩
  | draw p k ih => exact fun b => ih b (hQ b) (hR b)

end Generic

/-! ## Frame facts for the core -/

/-- The fields of the state that the internal operations of `PrepareRoot` never change. -/
def CountersEq (st st' : AdaState) : Prop :=
  st'.nInt = st.nInt ∧ st'.nNum = st.nNum ∧ st'.rej = st.rej ∧ st'.halted = st.halted ∧
    st'.capAborted = st.capAborted ∧ st'.thrOut = st.thrOut

theorem CountersEq.refl (st : AdaState) : CountersEq st st := ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

theorem CountersEq.trans {st st' st'' : AdaState} (h : CountersEq st st')
    (h' : CountersEq st' st'') : CountersEq st st'' :=
  ⟨h'.1.trans h.1, h'.2.1.trans h.2.1, h'.2.2.1.trans h.2.2.1, h'.2.2.2.1.trans h.2.2.2.1,
    h'.2.2.2.2.1.trans h.2.2.2.2.1, h'.2.2.2.2.2.trans h.2.2.2.2.2⟩

theorem applyCorrection_allOut (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ)
    (q : Bool) : AllOut (applyCorrection P st vals j q) fun st' =>
      CountersEq st st' ∧ st'.T = st.T.set j (st.T.getD j 0 + 1) := by
  unfold applyCorrection
  exact (allOut_true _).bind fun _ _ => ⟨CountersEq.refl _, rfl⟩

theorem scanPass_allOut (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool),
      AllOut (scanPass P vals mus es st cache) fun r => CountersEq st r.2.1
  | [], st, _ => CountersEq.refl st
  | j :: es, st, cache => by
    unfold scanPass
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]; exact scanPass_allOut P vals mus es st cache
    · rw [if_neg hc]
      refine (allOut_true _).bind fun r _ => ?_
      rcases r with _ | q
      · exact scanPass_allOut P vals mus es st _
      · dsimp only
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hT]; exact CountersEq.refl st
        · rw [if_neg hT]
          exact (applyCorrection_allOut P st vals j q).bind fun st' h' => h'.1

theorem prepareRoot_allOut (P : AdaParams) (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool),
      AllOut (prepareRoot P vals fuel st cache) fun o => ∀ st2, o = some st2 → CountersEq st st2
  | 0, _, _ => fun _ h => by cases h
  | fuel + 1, st, cache => by
    unfold prepareRoot
    refine (scanPass_allOut P vals (adaMus P st vals) (List.range P.p) st cache).bind
      fun r hr => ?_
    rcases r with ⟨o, st', cache'⟩
    cases o
    · intro st2 h; cases h; exact hr
    · exact (prepareRoot_allOut P vals fuel st' cache').mono fun o ho st2 h2 =>
        hr.trans (ho st2 h2)
    · intro st2 h; cases h

theorem outerReject_allOut (P : AdaParams) (st : AdaState) (high : Bool) :
    AllOut (outerReject P st high) fun r => r.2.nInt = st.nInt ∧ r.2.nNum = st.nNum := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]; exact ⟨rfl, rfl⟩
  · rw [if_neg hJ]; exact (allOut_true _).bind fun _ _ => ⟨rfl, rfl⟩

/-! ## The request potential and the per-call budget -/

/-- The number of requests the core may still process: `0` once halted, else
`(M − nInt) + (R − nNum)`. -/
def reqPot (P : AdaParams) (st : AdaState) : ℕ :=
  if st.halted = true then 0 else (P.M - st.nInt) + (P.R - st.nNum)

/-- Draws of one processed call: `fuel (2p + 3) + 3`. -/
def callDraws (P : AdaParams) : ℕ := P.fuel * (2 * P.p + 3) + 3

theorem adaIntervalD_budget (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    DrawsBudget (adaIntervalD P st vals l u) (callDraws P * reqPot P st)
      fun r => callDraws P * reqPot P r.2 := by
  have hD := adaIntervalD_drawsLE P st vals l u
  unfold adaIntervalD at hD ⊢
  by_cases hc : st.halted = true ∨ P.M ≤ st.nInt
  · rw [if_pos hc]; exact le_refl _
  · rw [if_neg hc] at hD ⊢
    have hh : ¬ st.halted = true := fun h => hc (Or.inl h)
    have hm : ¬ P.M ≤ st.nInt := fun h => hc (Or.inr h)
    have hpot : reqPot P st = (P.M - st.nInt) + (P.R - st.nNum) := by
      unfold reqPot; rw [if_neg hh]
    refine drawsBudget_of hD ?_
    -- every output: one more interval request processed, or halted
    have key : AllOut ((prepareRoot P vals P.fuel { st with nInt := st.nInt + 1 }
        (List.replicate P.p false)).bind fun r =>
        match r with
        | none => DrawProg.ret (AdaCert.abort,
            { st with nInt := st.nInt + 1, halted := true, capAborted := true })
        | some st2 =>
          let μ0 := (adaMus P st2 vals).getD 0 0
          let lt := P.hA * (roundIdxQ P.hA (clipQ (-1) 2 l) : ℚ)
          let ut := P.hA * (roundIdxQ P.hA (clipQ (-1) 2 u) : ℚ)
          let thr := P.a / 2 + P.hA * (st2.thrOut : ℚ)
          (drawNoise NoiseKind.outTest).bind fun kH =>
          (drawNoise NoiseKind.outTest).bind fun kL =>
            if thr ≤ μ0 - ut + P.hA * (kH : ℚ) then outerReject P st2 true
            else if thr ≤ lt - μ0 + P.hA * (kL : ℚ) then outerReject P st2 false
            else DrawProg.ret (AdaCert.accept, st2))
        fun r => r.2.halted = true ∨ (r.2.nInt = st.nInt + 1 ∧ r.2.nNum = st.nNum) := by
      refine (prepareRoot_allOut P vals P.fuel _ _).bind fun r hr => ?_
      rcases r with _ | st2
      · exact Or.inl rfl
      · have h2 := hr st2 rfl
        dsimp only
        refine (allOut_true _).bind fun _ _ => (allOut_true _).bind fun _ _ => ?_
        split_ifs
        · exact (outerReject_allOut P st2 true).mono fun r hr' =>
            Or.inr ⟨hr'.1.trans h2.1, hr'.2.trans h2.2.1⟩
        · exact (outerReject_allOut P st2 false).mono fun r hr' =>
            Or.inr ⟨hr'.1.trans h2.1, hr'.2.trans h2.2.1⟩
        · exact Or.inr ⟨h2.1, h2.2.1⟩
    refine key.mono fun r hr => ?_
    have hle : reqPot P r.2 + 1 ≤ reqPot P st := by
      rw [hpot]
      unfold reqPot
      rcases hr with hh | ⟨h1, h2⟩
      · rw [if_pos hh]; omega
      · split_ifs <;> omega
    calc callDraws P * reqPot P r.2 + (P.fuel * (2 * P.p + 3) + 3)
        = callDraws P * (reqPot P r.2 + 1) := by unfold callDraws; ring
      _ ≤ callDraws P * reqPot P st := Nat.mul_le_mul_left _ hle

theorem adaNumericalD_budget (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    DrawsBudget (adaNumericalD P st vals) (callDraws P * reqPot P st)
      fun r => callDraws P * reqPot P r.2 := by
  have hD := adaNumericalD_drawsLE P st vals
  unfold adaNumericalD at hD ⊢
  by_cases hc : st.halted = true ∨ P.R ≤ st.nNum
  · rw [if_pos hc]; exact le_refl _
  · rw [if_neg hc] at hD ⊢
    have hh : ¬ st.halted = true := fun h => hc (Or.inl h)
    have hm : ¬ P.R ≤ st.nNum := fun h => hc (Or.inr h)
    have hpot : reqPot P st = (P.M - st.nInt) + (P.R - st.nNum) := by
      unfold reqPot; rw [if_neg hh]
    refine drawsBudget_of hD ?_
    have key : AllOut ((prepareRoot P vals P.fuel { st with nNum := st.nNum + 1 }
        (List.replicate P.p false)).bind fun r =>
        match r with
        | none => DrawProg.ret (AdaNum.abort,
            { st with nNum := st.nNum + 1, halted := true, capAborted := true })
        | some st2 =>
          let μ0 := (adaMus P st2 vals).getD 0 0
          (drawNoise NoiseKind.num).bind fun k =>
            DrawProg.ret
              (AdaNum.val (clipQ 0 1 (P.hA * (roundIdxQ P.hA (μ0 + P.hA * (k : ℚ)) : ℚ))), st2))
        fun r => r.2.halted = true ∨ (r.2.nInt = st.nInt ∧ r.2.nNum = st.nNum + 1) := by
      refine (prepareRoot_allOut P vals P.fuel _ _).bind fun r hr => ?_
      rcases r with _ | st2
      · exact Or.inl rfl
      · have h2 := hr st2 rfl
        exact (allOut_true _).bind fun _ _ => Or.inr ⟨h2.1, h2.2.1⟩
    refine key.mono fun r hr => ?_
    have hle : reqPot P r.2 + 1 ≤ reqPot P st := by
      rw [hpot]
      unfold reqPot
      rcases hr with hh' | ⟨h1, h2⟩
      · rw [if_pos hh']; omega
      · split_ifs <;> omega
    calc callDraws P * reqPot P r.2 + (P.fuel * (2 * P.p + 3) + 3)
        = callDraws P * (reqPot P r.2 + 1) := by unfold callDraws; ring
      _ ≤ callDraws P * reqPot P st := Nat.mul_le_mul_left _ hle

theorem coreStepD_budget {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U)
    (st : AdaState) : DrawsBudget (coreStepD P s req st) (callDraws P * reqPot P st)
      fun r => callDraws P * reqPot P r.2 := by
  unfold coreStepD
  split_ifs
  · exact DrawsBudget.map (f := fun r : AdaCert × AdaState => ((Sum.inl r.1 : CoreOut), r.2))
      (Φ := fun r : CoreOut × AdaState => callDraws P * reqPot P r.2)
      (adaIntervalD_budget P st _ _ _)
  · exact DrawsBudget.map (f := fun r : AdaNum × AdaState => ((Sum.inr r.1 : CoreOut), r.2))
      (Φ := fun r : CoreOut × AdaState => callDraws P * reqPot P r.2)
      (adaNumericalD_budget P st _)

theorem coreLoopD_budget {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut),
      DrawsBudget (coreLoopD P ctrl s T st hist) (callDraws P * reqPot P st) fun _ => 0
  | 0, _, _ => Nat.zero_le _
  | T + 1, st, hist => by
    unfold coreLoopD
    exact (coreStepD_budget P s (ctrl hist) st).bind fun r =>
      coreLoopD_budget P ctrl s T r.2 (hist ++ [r.1])

theorem adaInitD_allOut (P : AdaParams) :
    AllOut (adaInitD P) fun st => reqPot P st = P.M + P.R := by
  unfold adaInitD
  refine (allOut_true _).bind fun _ _ => (allOut_true _).bind fun _ _ => ?_
  show reqPot P (adaInitState P _ _) = P.M + P.R
  simp [reqPot, adaInitState]

/-- **P1 (fresh bits)**: an online execution of any length makes at most
`p + 1 + (M + R) (fuel (2p + 3) + 3)` noise draws. -/
theorem coreRunD_drawsLE {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : (coreRunD P ctrl s T).DrawsLE (P.p + 1 + (P.M + P.R) * callDraws P) := by
  unfold coreRunD
  refine DrawsBudget.drawsLE (Φ := fun _ => 0) ?_
  refine DrawsBudget.bind (Φ := fun st => callDraws P * reqPot P st) ?_
    fun st => coreLoopD_budget P ctrl s T st []
  refine drawsBudget_of (adaInitD_drawsLE P) ((adaInitD_allOut P).mono fun st hst => ?_)
  rw [hst, Nat.mul_comm]
  omega

/-- Every online execution reads at most `adaCoins P` fresh bits (only the at most `M + R` processed
requests draw noise). -/
theorem coreRun_depth_le {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : (coreRun P ctrl s T).depth ≤ adaCoins P := by
  rw [coreRun_eq_toBits]
  refine (DrawProg.depth_toBits_le (adaDraw P) (adaDraw_depth_le P) (coreRunD_drawsLE P ctrl s T)).trans
    (le_of_eq ?_)
  unfold adaCoins adaInitBits adaCallBits callDraws
  ring

theorem adaQA_ge_left (M J R eA eXi : ℕ) :
    29 + eA + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaChi M J R eA eXi) ≤ adaQA M J R eA eXi :=
  le_max_left _ _

theorem adaQA_ge_right (M J R eA eXi : ℕ) :
    20 + Nat.clog 2 (adaMaxN M J R eA eXi) ≤ adaQA M J R eA eXi :=
  le_max_right _ _

/-! ## The global draw count: fewer than `Q` draws on every execution (P1)

Paper (proof of Theorem 3.6, "Counts", L984): "Each external request initially tests at most `p`
edges. Each applied correction invalidates at most three acceptances and opens at most three
thresholds. Adding directed query noises, outer tests, numerical releases, initial thresholds, and
terminal tests gives fewer than `Q` scalar draws on every capped execution." Inside `PrepareRoot`
the potential `2·#uncached edges + 9·∑_j (T_j^max − T_j)` pays for every test (an acceptance caches
an edge: −2; a correction costs at most 2 + 3 draws, invalidates at most two other cache bits: +4,
and uses one unit of slack: −9); across requests the potential
`(2p+2)(M − nInt) + (2p+1)(R − nNum) + 9·slack + (J + 1 − rej) + 2` (zero once halted) pays for the
`2p` initial uncached edges, the outer tests, the outer threshold redraw, the numerical draw and the
aborting test. -/

theorem list_getD_set_ne {α : Type} (l : List α) {i j : ℕ} (h : i ≠ j) (a d : α) :
    (l.set i a).getD j d = l.getD j d := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_set_ne h]

theorem list_getD_set_self {α : Type} (l : List α) {i : ℕ} (hi : i < l.length) (a d : α) :
    (l.set i a).getD i d = a := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set_self hi]
  rfl

/-- The uncached edges `j < p`. -/
def uncachedSet (P : AdaParams) (cache : List Bool) : Finset ℕ :=
  (Finset.range P.p).filter fun j => cache.getD j false = false

/-- The remaining corrections `∑_{j<p} (T_j^max − T_j)`. -/
def slackT (P : AdaParams) (st : AdaState) : ℕ :=
  ∑ j ∈ Finset.range P.p, (P.Tmax.getD j 0 - st.T.getD j 0)

/-- The scan potential `2·#uncached + 9·slack`. -/
def scanPot (P : AdaParams) (st : AdaState) (cache : List Bool) : ℕ :=
  2 * (uncachedSet P cache).card + 9 * slackT P st

theorem uncachedSet_set_true (P : AdaParams) (cache : List Bool) {j : ℕ} (hjp : j < P.p)
    (hjl : j < cache.length) (hc : cache.getD j false = false) :
    (uncachedSet P (cache.set j true)).card + 1 = (uncachedSet P cache).card := by
  have hset : uncachedSet P (cache.set j true) = (uncachedSet P cache).erase j := by
    ext i
    simp only [uncachedSet, Finset.mem_filter, Finset.mem_range, Finset.mem_erase]
    by_cases hij : i = j
    · subst hij
      rw [list_getD_set_self cache hjl]
      simp
    · rw [list_getD_set_ne cache (Ne.symm hij)]
      tauto
  have hmem : j ∈ uncachedSet P cache := by
    simp only [uncachedSet, Finset.mem_filter, Finset.mem_range]; exact ⟨hjp, hc⟩
  rw [hset, Finset.card_erase_of_mem hmem]
  have := Finset.card_pos.mpr ⟨j, hmem⟩
  omega

theorem getD_foldl_set_false (es : List ℕ) :
    ∀ (cache : List Bool) (i : ℕ),
      (es.foldl (fun c e => c.set e false) cache).getD i false = false →
        i ∈ es ∨ cache.getD i false = false := by
  induction es with
  | nil => intro cache i h; exact Or.inr h
  | cons e es ih =>
    intro cache i h
    rcases ih (cache.set e false) i h with h1 | h1
    · exact Or.inl (List.mem_cons_of_mem e h1)
    · by_cases hie : i = e
      · exact Or.inl (hie ▸ List.mem_cons_self)
      · rw [list_getD_set_ne cache (Ne.symm hie)] at h1
        exact Or.inr h1

theorem length_foldl_set (es : List ℕ) :
    ∀ (cache : List Bool), (es.foldl (fun c e => c.set e false) cache).length = cache.length := by
  induction es with
  | nil => intro cache; rfl
  | cons e es ih => intro cache; simp only [List.foldl_cons]; rw [ih, List.length_set]

theorem uncachedSet_invalidate (P : AdaParams) (cache : List Bool) {j : ℕ}
    (hc : cache.getD j false = false) :
    (uncachedSet P ((reopenEdges P j).foldl (fun c e => c.set e false) cache)).card ≤
      (uncachedSet P cache).card + 2 := by
  have hsub : uncachedSet P ((reopenEdges P j).foldl (fun c e => c.set e false) cache) ⊆
      uncachedSet P cache ∪ (reopenEdges P j).toFinset.erase j := by
    intro i hi
    simp only [uncachedSet, Finset.mem_filter, Finset.mem_range] at hi
    rcases getD_foldl_set_false _ cache i hi.2 with h1 | h1
    · by_cases hij : i = j
      · subst hij
        exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hi.1, hc⟩)
      · exact Finset.mem_union_right _ (Finset.mem_erase.mpr ⟨hij, List.mem_toFinset.mpr h1⟩)
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hi.1, h1⟩)
  have hj : j ∈ (reopenEdges P j).toFinset := by simp [reopenEdges]
  have hcard : ((reopenEdges P j).toFinset.erase j).card ≤ 2 := by
    rw [Finset.card_erase_of_mem hj]
    have := List.toFinset_card_le (reopenEdges P j)
    have := reopenEdges_length_le P j
    omega
  calc _ ≤ (uncachedSet P cache ∪ (reopenEdges P j).toFinset.erase j).card := Finset.card_le_card hsub
    _ ≤ (uncachedSet P cache).card + ((reopenEdges P j).toFinset.erase j).card :=
        Finset.card_union_le _ _
    _ ≤ (uncachedSet P cache).card + 2 := by omega

theorem slackT_incr (P : AdaParams) (st st' : AdaState) {j : ℕ} (hjp : j < P.p)
    (hjl : j < st.T.length) (hlt : st.T.getD j 0 < P.Tmax.getD j 0)
    (hT : st'.T = st.T.set j (st.T.getD j 0 + 1)) : slackT P st' + 1 = slackT P st := by
  unfold slackT
  have hj : j ∈ Finset.range P.p := Finset.mem_range.mpr hjp
  rw [← Finset.add_sum_erase _ _ hj, ← Finset.add_sum_erase _ _ hj]
  have hrest : ∑ x ∈ (Finset.range P.p).erase j, (P.Tmax.getD x 0 - st'.T.getD x 0) =
      ∑ x ∈ (Finset.range P.p).erase j, (P.Tmax.getD x 0 - st.T.getD x 0) := by
    refine Finset.sum_congr rfl fun x hx => ?_
    rw [hT, list_getD_set_ne _ (Ne.symm (Finset.ne_of_mem_erase hx))]
  rw [hrest, hT, list_getD_set_self _ hjl]
  omega

theorem scanPass_allOut_len (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool), cache.length = P.p → st.T.length = P.p →
      AllOut (scanPass P vals mus es st cache) fun r => r.2.2.length = P.p ∧ r.2.1.T.length = P.p
  | [], _, _, hc, hT => ⟨hc, hT⟩
  | j :: es, st, cache, hc, hT => by
    unfold scanPass
    by_cases hcj : cache.getD j false = true
    · rw [if_pos hcj]; exact scanPass_allOut_len P vals mus es st cache hc hT
    · rw [if_neg hcj]
      refine (allOut_true _).bind fun r _ => ?_
      rcases r with _ | q
      · exact scanPass_allOut_len P vals mus es st _ (by rw [List.length_set, hc]) hT
      · dsimp only
        by_cases hTj : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hTj]; exact ⟨hc, hT⟩
        · rw [if_neg hTj]
          exact (applyCorrection_allOut P st vals j q).bind fun st' h' =>
            ⟨by rw [length_foldl_set, hc], by rw [h'.2, List.length_set, hT]⟩

theorem scanPass_budgetQ (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) (C : ℕ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool), (∀ e ∈ es, e < P.p) →
      cache.length = P.p → st.T.length = P.p →
      DrawsBudget (scanPass P vals mus es st cache) (C + scanPot P st cache + 2)
        fun r => C + (if r.1 = PassOut.abort then 0 else scanPot P r.2.1 r.2.2 + 2)
  | [], st, cache, _, _, _ => by
    show C + (if PassOut.done = PassOut.abort then 0 else scanPot P st cache + 2) ≤
      C + scanPot P st cache + 2
    simp only [reduceCtorEq, if_false]
    omega
  | j :: es, st, cache, hes, hc, hT => by
    have hjp : j < P.p := hes j List.mem_cons_self
    have hes' : ∀ e ∈ es, e < P.p := fun e he => hes e (List.mem_cons_of_mem j he)
    unfold scanPass
    by_cases hcj : cache.getD j false = true
    · rw [if_pos hcj]; exact scanPass_budgetQ P vals mus C es st cache hes' hc hT
    · rw [if_neg hcj]
      have hcj' : cache.getD j false = false := by simpa using hcj
      have hE : DrawsBudget (edgeTest P st mus j) (C + scanPot P st cache + 2)
          (fun _ => C + scanPot P st cache) :=
        drawsBudget_of (edgeTest_drawsLE P st mus j) ((allOut_true _).mono fun _ _ => le_refl _)
      refine hE.bind fun r => ?_
      rcases r with _ | q
      · have h1 := uncachedSet_set_true P cache hjp (by omega) hcj'
        refine (scanPass_budgetQ P vals mus C es st (cache.set j true) hes'
          (by rw [List.length_set, hc]) hT).mono (le_of_eq ?_)
        unfold scanPot; omega
      · dsimp only
        by_cases hTj : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hTj]
          show C + (if PassOut.abort = PassOut.abort then 0 else _) ≤ C + scanPot P st cache
          simp
        · rw [if_neg hTj]
          refine drawsBudget_of ((applyCorrection_drawsLE P st vals j q).bind
            fun _ => drawsLE_ret _ 0) ?_
          refine (applyCorrection_allOut P st vals j q).bind fun st' h' => ?_
          show C + (if PassOut.corrected = PassOut.abort then 0 else
              scanPot P st' ((reopenEdges P j).foldl (fun c e => c.set e false) cache) + 2) +
              (3 + 0) ≤ C + scanPot P st cache
          have hs := slackT_incr P st st' hjp (by omega) (by omega) h'.2
          have hu := uncachedSet_invalidate P cache hcj'
          simp only [reduceCtorEq, if_false]
          unfold scanPot
          omega

theorem prepareRoot_budgetQ (P : AdaParams) (vals : List (List ℕ)) (C : ℕ) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool), cache.length = P.p → st.T.length = P.p →
      DrawsBudget (prepareRoot P vals fuel st cache) (C + scanPot P st cache + 2)
        fun o => match o with
          | none => C
          | some st2 => C + 9 * slackT P st2 + 2
  | 0, _, _, _, _ => by show C ≤ _; omega
  | fuel + 1, st, cache, hc, hT => by
    unfold prepareRoot
    have hS := scanPass_budgetQ P vals (adaMus P st vals) C (List.range P.p) st cache
      (fun e he => List.mem_range.mp he) hc hT
    have hL := scanPass_allOut_len P vals (adaMus P st vals) (List.range P.p) st cache hc hT
    refine hS.bind_of_allOut hL fun r hr => ?_
    rcases r with ⟨o, st', cache'⟩
    cases o
    · show C + 9 * slackT P st' + 2 ≤
        C + (if PassOut.done = PassOut.abort then 0 else scanPot P st' cache' + 2)
      simp only [reduceCtorEq, if_false]
      unfold scanPot; omega
    · refine (prepareRoot_budgetQ P vals C fuel st' cache' hr.1 hr.2).mono (le_of_eq ?_)
      show C + scanPot P st' cache' + 2 =
        C + (if PassOut.corrected = PassOut.abort then 0 else scanPot P st' cache' + 2)
      simp only [reduceCtorEq, if_false]
      omega
    · show C ≤ C + (if PassOut.abort = PassOut.abort then 0 else scanPot P st' cache' + 2)
      simp

theorem prepareRoot_allOut_len (P : AdaParams) (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool), cache.length = P.p → st.T.length = P.p →
      AllOut (prepareRoot P vals fuel st cache) fun o => ∀ st2, o = some st2 → st2.T.length = P.p
  | 0, _, _, _, _ => fun _ h => by cases h
  | fuel + 1, st, cache, hc, hT => by
    unfold prepareRoot
    refine (scanPass_allOut_len P vals (adaMus P st vals) (List.range P.p) st cache hc hT).bind
      fun r hr => ?_
    rcases r with ⟨o, st', cache'⟩
    cases o
    · intro st2 h; cases h; exact hr.2
    · exact prepareRoot_allOut_len P vals fuel st' cache' hr.1 hr.2
    · intro st2 h; cases h

/-- The request-level potential: `0` once halted, else
`(2p+2)(M − nInt) + (2p+1)(R − nNum) + 9·slack + (J + 1 − rej) + 2`. -/
def gPot (P : AdaParams) (st : AdaState) : ℕ :=
  if st.halted = true then 0
  else (2 * P.p + 2) * (P.M - st.nInt) + (2 * P.p + 1) * (P.R - st.nNum) + 9 * slackT P st +
    (P.J + 1 - st.rej) + 2

theorem gPot_of_not_halted (P : AdaParams) (st : AdaState) (hh : st.halted = false) :
    gPot P st = (2 * P.p + 2) * (P.M - st.nInt) + (2 * P.p + 1) * (P.R - st.nNum) +
      9 * slackT P st + (P.J + 1 - st.rej) + 2 := by
  simp [gPot, hh]

theorem gPot_of_halted (P : AdaParams) (st : AdaState) (hh : st.halted = true) : gPot P st = 0 := by
  simp [gPot, hh]

theorem slackT_congr (P : AdaParams) {st st' : AdaState} (h : st'.T = st.T) :
    slackT P st' = slackT P st := by
  unfold slackT; rw [h]

theorem uncachedSet_replicate (P : AdaParams) :
    (uncachedSet P (List.replicate P.p false)).card = P.p := by
  have : uncachedSet P (List.replicate P.p false) = Finset.range P.p := by
    ext i
    simp only [uncachedSet, Finset.mem_filter, Finset.mem_range, and_iff_left_iff_imp]
    intro hi
    rw [List.getD_eq_getElem?_getD, List.getElem?_replicate]
    simp [hi]
  rw [this, Finset.card_range]

theorem outerReject_budgetQ (P : AdaParams) (st : AdaState) (high : Bool)
    (hh : st.halted = false) :
    DrawsBudget (outerReject P st high) (gPot P st) fun r => gPot P r.2 := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]
    show gPot P { st with rej := st.rej + 1, halted := true } ≤ gPot P st
    rw [gPot_of_halted P _ rfl]
    exact Nat.zero_le _
  · rw [if_neg hJ]
    refine drawsBudget_of ((drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0)
      ((allOut_true _).bind fun k _ => ?_)
    show gPot P { st with rej := st.rej + 1, thrOut := k } + (1 + 0) ≤ gPot P st
    rw [gPot_of_not_halted P { st with rej := st.rej + 1, thrOut := k } hh,
      gPot_of_not_halted P st hh,
      slackT_congr P (st := st) (st' := { st with rej := st.rej + 1, thrOut := k }) rfl]
    dsimp only
    omega

theorem adaIntervalD_budgetQ (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ)
    (hT : st.T.length = P.p) :
    DrawsBudget (adaIntervalD P st vals l u) (gPot P st) fun r => gPot P r.2 := by
  unfold adaIntervalD
  by_cases hc : st.halted = true ∨ P.M ≤ st.nInt
  · rw [if_pos hc]; exact le_refl _
  · rw [if_neg hc]
    have hh : st.halted = false := by
      cases h : st.halted
      · rfl
      · exact absurd (Or.inl h) hc
    have hm : st.nInt < P.M := by
      by_contra h; exact hc (Or.inr (by omega))
    have hgP : gPot P st = ((2 * P.p + 2) * (P.M - (st.nInt + 1)) + (2 * P.p + 1) * (P.R - st.nNum) +
        (P.J + 1 - st.rej) + 2) + scanPot P { st with nInt := st.nInt + 1 }
          (List.replicate P.p false) + 2 := by
      have hM : P.M - st.nInt = (P.M - (st.nInt + 1)) + 1 := by omega
      rw [gPot_of_not_halted P st hh, scanPot, uncachedSet_replicate,
        slackT_congr P (st := st) (st' := { st with nInt := st.nInt + 1 }) rfl, hM]
      ring
    rw [hgP]
    refine (prepareRoot_budgetQ P vals _ P.fuel { st with nInt := st.nInt + 1 }
      (List.replicate P.p false) (by simp) hT).bind_of_allOut
      (prepareRoot_allOut P vals P.fuel _ _) fun o ho => ?_
    rcases o with _ | st2
    · show gPot P { st with nInt := st.nInt + 1, halted := true, capAborted := true } ≤ _
      rw [gPot_of_halted P _ rfl]
      exact Nat.zero_le _
    · have h2 := ho st2 rfl
      have hh2 : st2.halted = false := h2.2.2.2.1.trans hh
      have hg2 : gPot P st2 = (2 * P.p + 2) * (P.M - (st.nInt + 1)) +
          (2 * P.p + 1) * (P.R - st.nNum) + (P.J + 1 - st.rej) + 9 * slackT P st2 + 2 := by
        rw [gPot_of_not_halted P st2 hh2, h2.1, h2.2.1, h2.2.2.1]
        dsimp only
        ring
      dsimp only
      refine DrawsBudget.mono (B := gPot P st2 + 2) ?_ (by rw [hg2]; omega)
      refine (drawsBudget_of (B := gPot P st2 + 2) (Φ := fun _ => gPot P st2 + 1)
        (drawNoise_drawsLE _) ((allOut_true _).mono fun _ _ => le_refl _)).bind fun kH => ?_
      refine (drawsBudget_of (B := gPot P st2 + 1) (Φ := fun _ => gPot P st2)
        (drawNoise_drawsLE _) ((allOut_true _).mono fun _ _ => le_refl _)).bind fun kL => ?_
      split_ifs
      · exact outerReject_budgetQ P st2 true hh2
      · exact outerReject_budgetQ P st2 false hh2
      · exact le_refl _

theorem adaNumericalD_budgetQ (P : AdaParams) (st : AdaState) (vals : List (List ℕ))
    (hT : st.T.length = P.p) :
    DrawsBudget (adaNumericalD P st vals) (gPot P st) fun r => gPot P r.2 := by
  unfold adaNumericalD
  by_cases hc : st.halted = true ∨ P.R ≤ st.nNum
  · rw [if_pos hc]; exact le_refl _
  · rw [if_neg hc]
    have hh : st.halted = false := by
      cases h : st.halted
      · rfl
      · exact absurd (Or.inl h) hc
    have hm : st.nNum < P.R := by
      by_contra h; exact hc (Or.inr (by omega))
    have hgP : gPot P st = ((2 * P.p + 2) * (P.M - st.nInt) + (2 * P.p + 1) * (P.R - (st.nNum + 1)) +
        (P.J + 1 - st.rej) + 1) + scanPot P { st with nNum := st.nNum + 1 }
          (List.replicate P.p false) + 2 := by
      have hR : P.R - st.nNum = (P.R - (st.nNum + 1)) + 1 := by omega
      rw [gPot_of_not_halted P st hh, scanPot, uncachedSet_replicate,
        slackT_congr P (st := st) (st' := { st with nNum := st.nNum + 1 }) rfl, hR]
      ring
    rw [hgP]
    refine (prepareRoot_budgetQ P vals _ P.fuel { st with nNum := st.nNum + 1 }
      (List.replicate P.p false) (by simp) hT).bind_of_allOut
      (prepareRoot_allOut P vals P.fuel _ _) fun o ho => ?_
    rcases o with _ | st2
    · show gPot P { st with nNum := st.nNum + 1, halted := true, capAborted := true } ≤ _
      rw [gPot_of_halted P _ rfl]
      exact Nat.zero_le _
    · have h2 := ho st2 rfl
      have hh2 : st2.halted = false := h2.2.2.2.1.trans hh
      have hg2 : gPot P st2 = (2 * P.p + 2) * (P.M - st.nInt) +
          (2 * P.p + 1) * (P.R - (st.nNum + 1)) + (P.J + 1 - st.rej) + 9 * slackT P st2 + 2 := by
        rw [gPot_of_not_halted P st2 hh2, h2.1, h2.2.1, h2.2.2.1]
        dsimp only
        ring
      dsimp only
      refine drawsBudget_of ((drawNoise_drawsLE _).bind fun _ => drawsLE_ret _ 0)
        ((allOut_true _).bind fun k _ => ?_)
      show gPot P st2 + (1 + 0) ≤ _
      rw [hg2]
      omega

theorem outerReject_allOut_T (P : AdaParams) (st : AdaState) (high : Bool) :
    AllOut (outerReject P st high) fun r => r.2.T = st.T := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]; exact rfl
  · rw [if_neg hJ]; exact (allOut_true _).bind fun _ _ => rfl

theorem adaIntervalD_allOut_len (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ)
    (hT : st.T.length = P.p) : AllOut (adaIntervalD P st vals l u) fun r => r.2.T.length = P.p := by
  unfold adaIntervalD
  split_ifs
  · exact hT
  · refine (prepareRoot_allOut_len P vals P.fuel { st with nInt := st.nInt + 1 }
      (List.replicate P.p false) (by simp) hT).bind fun o ho => ?_
    rcases o with _ | st2
    · exact hT
    · have h2 := ho st2 rfl
      dsimp only
      refine (allOut_true _).bind fun _ _ => (allOut_true _).bind fun _ _ => ?_
      split_ifs
      · exact (outerReject_allOut_T P st2 true).mono fun r hr => hr ▸ h2
      · exact (outerReject_allOut_T P st2 false).mono fun r hr => hr ▸ h2
      · exact h2

theorem adaNumericalD_allOut_len (P : AdaParams) (st : AdaState) (vals : List (List ℕ))
    (hT : st.T.length = P.p) : AllOut (adaNumericalD P st vals) fun r => r.2.T.length = P.p := by
  unfold adaNumericalD
  split_ifs
  · exact hT
  · refine (prepareRoot_allOut_len P vals P.fuel { st with nNum := st.nNum + 1 }
      (List.replicate P.p false) (by simp) hT).bind fun o ho => ?_
    rcases o with _ | st2
    · exact hT
    · exact (allOut_true _).bind fun _ _ => ho st2 rfl

theorem coreStepD_allOut_len {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U)
    (st : AdaState) (hT : st.T.length = P.p) :
    AllOut (coreStepD P s req st) fun r => r.2.T.length = P.p := by
  unfold coreStepD DrawProg.map
  split_ifs
  · exact (adaIntervalD_allOut_len P st _ _ _ hT).bind fun r hr => hr
  · exact (adaNumericalD_allOut_len P st _ hT).bind fun r hr => hr

theorem coreStepD_budgetQ {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U)
    (st : AdaState) (hT : st.T.length = P.p) :
    DrawsBudget (coreStepD P s req st) (gPot P st) fun r => gPot P r.2 := by
  unfold coreStepD
  split_ifs
  · exact DrawsBudget.map (f := fun r : AdaCert × AdaState => ((Sum.inl r.1 : CoreOut), r.2))
      (Φ := fun r : CoreOut × AdaState => gPot P r.2) (adaIntervalD_budgetQ P st _ _ _ hT)
  · exact DrawsBudget.map (f := fun r : AdaNum × AdaState => ((Sum.inr r.1 : CoreOut), r.2))
      (Φ := fun r : CoreOut × AdaState => gPot P r.2) (adaNumericalD_budgetQ P st _ hT)

theorem coreLoopD_budgetQ {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut), st.T.length = P.p →
      DrawsBudget (coreLoopD P ctrl s T st hist) (gPot P st) fun _ => 0
  | 0, _, _, _ => Nat.zero_le _
  | T + 1, st, hist, hT => by
    unfold coreLoopD
    exact (coreStepD_budgetQ P s (ctrl hist) st hT).bind_of_allOut
      (coreStepD_allOut_len P s (ctrl hist) st hT) fun r hr =>
        coreLoopD_budgetQ P ctrl s T r.2 (hist ++ [r.1]) hr

/-- The potential of the initial state:
`(2p+2) M + (2p+1) R + 9 ∑_{j<p} T_j^max + J + 3`. -/
def gPotInit (P : AdaParams) : ℕ :=
  (2 * P.p + 2) * P.M + (2 * P.p + 1) * P.R + 9 * ∑ j ∈ Finset.range P.p, P.Tmax.getD j 0 + P.J + 3

theorem adaInitD_allOut_Q (P : AdaParams) :
    AllOut (adaInitD P) fun st => st.T.length = P.p ∧ gPot P st = gPotInit P := by
  unfold adaInitD
  refine (allOut_true _).bind fun thr _ => (allOut_true _).bind fun ko _ => ?_
  show (adaInitState P thr ko).T.length = P.p ∧ gPot P (adaInitState P thr ko) = gPotInit P
  refine ⟨by simp [adaInitState], ?_⟩
  rw [gPot_of_not_halted P _ rfl]
  have hs : slackT P (adaInitState P thr ko) = ∑ j ∈ Finset.range P.p, P.Tmax.getD j 0 := by
    unfold slackT
    refine Finset.sum_congr rfl fun j hj => ?_
    have hj' : j < P.p := Finset.mem_range.mp hj
    have : (adaInitState P thr ko).T.getD j 0 = 0 := by
      show (List.replicate P.p 0).getD j 0 = 0
      rw [List.getD_eq_getElem?_getD, List.getElem?_replicate]
      simp [hj']
    rw [this, Nat.sub_zero]
  rw [hs]
  simp only [adaInitState, gPotInit, Nat.sub_zero]
  ring

/-- **P1 (global count)**: every online execution makes at most `p + 1 + gPotInit P` draws. -/
theorem coreRunD_drawsLE_gPot {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : (coreRunD P ctrl s T).DrawsLE (P.p + 1 + gPotInit P) := by
  unfold coreRunD
  refine DrawsBudget.drawsLE (Φ := fun _ => 0) ?_
  refine DrawsBudget.bind_of_allOut (Φ := fun st => gPot P st) ?_ (adaInitD_allOut_Q P)
    fun st hst => (coreLoopD_budgetQ P ctrl s T st [] hst.1)
  refine drawsBudget_of (adaInitD_drawsLE P) ((adaInitD_allOut_Q P).mono fun st hst => ?_)
  rw [hst.2]
  omega

theorem sum_map_range_eq (n : ℕ) (f : ℕ → ℕ) :
    ((List.range n).map f).sum = ∑ i ∈ Finset.range n, f i := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [List.range_succ, List.map_append, List.sum_append, ih, Finset.sum_range_succ]
    simp

theorem sum_adaTmaxList (eA : ℕ) :
    ∑ j ∈ Finset.range (adaP eA), (adaTmaxList eA).getD j 0 = (adaTmaxList eA).sum := by
  unfold adaTmaxList
  rw [sum_map_range_eq]
  refine Finset.sum_congr rfl fun j hj => ?_
  have hj' : j < adaP eA := Finset.mem_range.mp hj
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj']
  rfl

/-- The global count bound is below the paper's `Q = 100(p+1)(M + R + J + 2 + ∑_{j<p} T_j^max)`. -/
theorem drawBound_le_adaQ (eA eXi M J R : ℕ) :
    (adaParams eA eXi M J R).p + 1 + gPotInit (adaParams eA eXi M J R) ≤ adaQ M J R eA := by
  have hsum : ∑ j ∈ Finset.range (adaParams eA eXi M J R).p,
      (adaParams eA eXi M J R).Tmax.getD j 0 = (adaTmaxList eA).sum := sum_adaTmaxList eA
  unfold gPotInit adaQ
  rw [hsum]
  show adaP eA + 1 + ((2 * adaP eA + 2) * M + (2 * adaP eA + 1) * R + 9 * (adaTmaxList eA).sum +
      J + 3) ≤ 100 * (adaP eA + 1) * (M + R + J + 2 + (adaTmaxList eA).sum)
  nlinarith [Nat.zero_le (adaP eA * M), Nat.zero_le (adaP eA * R), Nat.zero_le (adaP eA * J),
    Nat.zero_le (adaP eA * (adaTmaxList eA).sum), Nat.zero_le M, Nat.zero_le R, Nat.zero_le J,
    Nat.zero_le (adaTmaxList eA).sum, Nat.zero_le (adaP eA)]

/-- **P1 (fewer than `Q` draws on every execution)**, the form used by the coupling (P4) and the
noise tails (P5): every online execution of the mechanism of Theorem `R:thm:validation_ada` makes
at most `Q = adaQ M J R (dyadicExp aReq)` noise draws. -/
theorem coreRunD_drawsLE_Q (M J R : ℕ) (aReq ξReq : ℝ) {U : Type} (ctrl : CoreCtrl U)
    (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) (T : ℕ) :
    (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T).DrawsLE (adaQ M J R (dyadicExp aReq)) :=
  (coreRunD_drawsLE_gPot _ ctrl s T).mono (drawBound_le_adaQ _ _ M J R)

end F2e2e.B
