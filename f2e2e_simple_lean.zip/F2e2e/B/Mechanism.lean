import F2e2e.B.ArchCore

/-!
# Algorithm `R:alg:sec3_validation_ada` as a Spec-level validation mechanism

The Spec's interface (`F2e2e.VMechanism N c`): in round `t` the mechanism answers from the views
of the requests of rounds `0, …, t` (values `f_j(X_ℓ)` on the `N` samples and `(isInterval, l, u)`)
and a block of `c` fair coins. Algorithm 2 (`F2e2e/B/ArchCore.lean`) is turned into such a mechanism
by
1. **quantization** (`partII.tex` L750): every query value is clipped to `[0, 1]` and rounded to the
   grid `h_A ℤ` (grid index `valIdx ∈ [0, 2^{qA}]`), every endpoint is clipped to `[−1, 2]` and rounded
   to `h_A ℤ` (grid index `endIdx`); for a valid controller (values in `[0,1]`) the clip of values is
   the identity;
2. **replay**: the core (`adaInitD`, then one `adaIntervalD`/`adaNumericalD` call per round, the sample
   split into the blocks `S_0, …, S_p` of sizes `n_0, …, n_p`) is run on the quantized views of rounds
   `0, …, t`, every noise draw being the bounded lattice sampler reading the next fresh bits of the
   coin block (`DrawProg.toBits (adaDraw P)`, `BitProg.run`); the round-`t` response is the last one.
   The responses of earlier rounds are recomputed identically, so this is the online execution.
3. **responses**: `ACCEPT/HIGH/LOW` (terminal rejections are `HIGH`/`LOW`), numerical answers
   `μ̂ ∈ [0, 1] ∩ h_A ℤ`; a request the core refuses (`abort`: beyond the first `M` interval or `R`
   numerical requests — "refuse and continue", `STATEMENT_REVIEW.md` B.3.2 — or after halting) gets the
   fixed dummy `ACCEPT` / `num 0`, with no data access, no fair bits and no state change.

The coin budget `adaCoins P = adaInitBits P + (M + R) · adaCallBits P` covers every execution: only
the at most `M + R` processed requests draw noise, each within `adaCallBits P` bits.

The instance of Theorem `R:thm:validation_ada` is `adaAlg2Mech M J R aReq ξReq`, with the parameters
`adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R` (Definition `R:def:sec3_ada_params`).
-/

namespace F2e2e.B

open F2e2e.Discrete

/-! ## Quantized views -/

/-- A quantized request: the grid indices of the query values on the `N` samples, the request type
(`true` = interval), and the grid indices of the clipped endpoints `l, u`. -/
abbrev QView (N : ℕ) : Type := (Fin N → ℕ) × Bool × ℤ × ℤ

/-- Split a list into consecutive blocks of the given sizes. -/
def splitBlocks : List ℕ → List ℕ → List (List ℕ)
  | [], _ => []
  | n :: ns, v => v.take n :: splitBlocks ns (v.drop n)

/-- Block `j` of `splitBlocks sizes v` is the segment of `v` of length `sizes[j]` after the first
`sizes[0] + ⋯ + sizes[j-1]` entries (empty for `j ≥ sizes.length`). -/
theorem splitBlocks_getD (sizes v : List ℕ) (j : ℕ) :
    (splitBlocks sizes v).getD j [] = (v.drop (sizes.take j).sum).take (sizes.getD j 0) := by
  induction sizes generalizing v j with
  | nil => simp [splitBlocks]
  | cons n ns ih =>
    cases j with
    | zero => simp [splitBlocks]
    | succ j =>
      simp only [splitBlocks, List.getD_cons_succ, ih, List.take_succ_cons, List.sum_cons,
        List.drop_drop]

theorem sum_take_add_getD_le (sizes : List ℕ) (j : ℕ) :
    (sizes.take j).sum + sizes.getD j 0 ≤ sizes.sum := by
  induction sizes generalizing j with
  | nil => simp
  | cons n ns ih =>
    cases j with
    | zero => simp
    | succ j =>
      simp only [List.take_succ_cons, List.sum_cons, List.getD_cons_succ]
      have := ih j
      omega

/-- If `v` has at least `∑ sizes` entries, block `j` has exactly `sizes[j]` entries. -/
theorem length_splitBlocks_getD (sizes v : List ℕ) (j : ℕ) (h : sizes.sum ≤ v.length) :
    ((splitBlocks sizes v).getD j []).length = sizes.getD j 0 := by
  rw [splitBlocks_getD, List.length_take, List.length_drop]
  have := sum_take_add_getD_le sizes j
  omega

/-- The block-structured grid indices `vals[j][i] = f̂(X_{j,i})/h_A` of a quantized request. -/
def qVals (P : AdaParams) (v : QView P.N) : List (List ℕ) := splitBlocks P.blockSizes (List.ofFn v.1)

/-- Spec response of an interval certificate (terminal rejections are `HIGH`/`LOW`; a refused or
halted request gets the dummy `ACCEPT`). -/
def certResp : AdaCert → VResponse
  | AdaCert.accept => VResponse.accept
  | AdaCert.high => VResponse.high
  | AdaCert.low => VResponse.low
  | AdaCert.termHigh => VResponse.high
  | AdaCert.termLow => VResponse.low
  | AdaCert.abort => VResponse.accept

/-- Spec response of a numerical output (a refused or halted request gets the dummy `num 0`). -/
def numResp : AdaNum → VResponse
  | AdaNum.val q => VResponse.num q
  | AdaNum.abort => VResponse.num 0

/-- One round of the core on a quantized request. The endpoints are passed as the grid points
`h_A l̂`, `h_A û` (the core's clip-and-round is the identity on them). -/
def adaStepQ (P : AdaParams) (st : AdaState) (v : QView P.N) : NoiseProg (VResponse × AdaState) :=
  if v.2.1 = true then
    (adaIntervalD P st (qVals P v) (P.hA * (v.2.2.1 : ℚ)) (P.hA * (v.2.2.2 : ℚ))).map
      fun r => (certResp r.1, r.2)
  else (adaNumericalD P st (qVals P v)).map fun r => (numResp r.1, r.2)

/-- The responses to a list of quantized requests, starting from the state `st`. -/
def adaRunQ (P : AdaParams) : AdaState → List (QView P.N) → NoiseProg (List VResponse)
  | _, [] => DrawProg.ret []
  | st, v :: vs => (adaStepQ P st v).bind fun r => (adaRunQ P r.2 vs).map (r.1 :: ·)

/-- The whole execution on the quantized requests `vs`: initialization, then one round per request. -/
def adaProgQ (P : AdaParams) (vs : List (QView P.N)) : NoiseProg (List VResponse) :=
  (adaInitD P).bind fun st => adaRunQ P st vs

/-- The fair-coin budget: initialization plus `M + R` processed requests. -/
def adaCoins (P : AdaParams) : ℕ := adaInitBits P + (P.M + P.R) * adaCallBits P

/-- The mechanism on quantized views (computable): replay rounds `0, …, t` on the coin block and
return the round-`t` response. -/
def mechQ (P : AdaParams) (t : ℕ) (views : Fin (t + 1) → QView P.N)
    (ω : Fin (adaCoins P) → Bool) : VResponse :=
  match ((adaProgQ P (List.ofFn views)).toBits (adaDraw P)).run (List.ofFn ω) with
  | some (rs, _) => rs.getLastD VResponse.accept
  | none => VResponse.accept

/-! ## Quantization of real views (L750) -/

/-- Grid index of a query value: `round_{h_A}(clip_{[0,1]} x)/h_A ∈ [0, 2^{qA}]`. -/
noncomputable def valIdx (P : AdaParams) (x : ℝ) : ℕ :=
  (roundIdx (P.hA : ℝ) (max 0 (min 1 x))).toNat

/-- Grid index of an interval endpoint: `round_{h_A}(clip_{[−1,2]} x)/h_A`. -/
noncomputable def endIdx (P : AdaParams) (x : ℝ) : ℤ := roundIdx (P.hA : ℝ) (max (-1) (min 2 x))

/-- The quantized request of a view. -/
noncomputable def quantView (P : AdaParams) (v : VView P.N) : QView P.N :=
  (fun ℓ => valIdx P (v.1 ℓ), v.2.1, endIdx P v.2.2.1, endIdx P v.2.2.2)

/-- Algorithm 2 with parameters `P` as a Spec-level validation mechanism. -/
noncomputable def mechOf (P : AdaParams) : VMechanism P.N (adaCoins P) :=
  fun t views ω => mechQ P t (fun i => quantView P (views i)) ω

/-! ## The instance of Theorem `R:thm:validation_ada` -/

/-- The parameters of Definition `R:def:sec3_ada_params` for `a_req`, `ξ_req` and caps `M, J, R`:
`a = 2^{-⌈log₂(1/a_req)⌉}`, `ξ_A = 2^{-⌈log₂(1/ξ_req)⌉}`. -/
noncomputable def adaAlg2Params (M J R : ℕ) (aReq ξReq : ℝ) : AdaParams :=
  adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R

/-- The mechanism of Theorem `R:thm:validation_ada`: Algorithm 2 with the parameters of
Definition `R:def:sec3_ada_params`, `N = ∑_{j=0}^p n_j` samples and `adaCoins` fair coins. -/
noncomputable def adaAlg2Mech (M J R : ℕ) (aReq ξReq : ℝ) :
    VMechanism (adaAlg2Params M J R aReq ξReq).N (adaCoins (adaAlg2Params M J R aReq ξReq)) :=
  mechOf (adaAlg2Params M J R aReq ξReq)

/-! ## Measurability in the views

The mechanism factors through the quantization, a measurable map into a countable type; hence each
response is a measurable function of the views (this makes the Spec's failure events measurable for
controllers that are measurable in their coins, `vGuarantee_of_det` in `F2e2e/B/Final.lean`). -/

theorem measurable_valIdx (P : AdaParams) : Measurable (valIdx P) := by
  have h : Measurable fun x : ℝ => max 0 (min 1 x) / (P.hA : ℝ) + 1 / 2 := by fun_prop
  exact (measurable_of_countable Int.toNat).comp h.floor

theorem measurable_endIdx (P : AdaParams) : Measurable (endIdx P) := by
  have h : Measurable fun x : ℝ => max (-1) (min 2 x) / (P.hA : ℝ) + 1 / 2 := by fun_prop
  exact h.floor

theorem measurable_quantView (P : AdaParams) :
    Measurable (fun v : (Fin P.N → ℝ) × Bool × ℝ × ℝ => quantView P v) := by
  unfold quantView
  refine Measurable.prodMk ?_ (Measurable.prodMk measurable_snd.fst
    (Measurable.prodMk ((measurable_endIdx P).comp measurable_snd.snd.fst)
      ((measurable_endIdx P).comp measurable_snd.snd.snd)))
  exact measurable_pi_lambda _ fun ℓ =>
    (measurable_valIdx P).comp ((measurable_pi_apply ℓ).comp measurable_fst)

/-- Each response of `mechOf P` is a measurable function of the (real) views. -/
theorem mechOf_measurableSet (P : AdaParams) (t : ℕ) (ω : Fin (adaCoins P) → Bool) (r : VResponse) :
    MeasurableSet {views : Fin (t + 1) → (Fin P.N → ℝ) × Bool × ℝ × ℝ | mechOf P t views ω = r} := by
  have hq : Measurable (fun views : Fin (t + 1) → (Fin P.N → ℝ) × Bool × ℝ × ℝ =>
      fun i => quantView P (views i)) :=
    measurable_pi_lambda _ fun i => (measurable_quantView P).comp (measurable_pi_apply i)
  have hS : MeasurableSet {qs : Fin (t + 1) → QView P.N | mechQ P t qs ω = r} :=
    (Set.to_countable _).measurableSet
  exact hq hS

end F2e2e.B
