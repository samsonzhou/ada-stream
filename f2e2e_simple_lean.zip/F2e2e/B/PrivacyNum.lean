import F2e2e.B.AccuracyBlocks
import F2e2e.B.ArchParamsBridge
import F2e2e.B.NumericsCert

/-!
# Theorem `R:thm:validation_ada`, privacy pillars (P2)–(P4): numerics

Paper: `parts/partII.tex` L986–1032 (Definition `R:def:sec3_ada_params` for the parameters).

The numerical facts about the parameters of the instance `adaAlg2Params M J R aReq ξReq`
(`= adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R`) used by the per-block privacy proof
`F2e2e/B/PrivacyCore.lean`:

* (P2) per-phase costs: the lattice shift `dShift P j = ⌈(8/n_j)/h_A⌉` covering the replacement
  sensitivity `8/n_j` of the predictions (Lemma `R:lem:sec3_kkt_sensitivity` (ii)) costs
  `e^{d h_A/b}` with `b = b_int` (internal edges: threshold shift `d` at scale `2b`, test shift `2d`
  at scale `4b`), `b = b_out` (outer validator), `b = b_num` (numerical release); each is
  `≤ ρ_j = 1/(64 d_j ⌈√(C_j χ)⌉)` (L998–1002: `2Δ'_j/b_int ≤ 2304χ/(n_j h) ≤ ρ_j`; for the outer and
  numerical streams of block `0` the paper does not spell out the check; it uses `h ≤ a` and
  `9216·64, 576·64 ≤ 2^20`);
* (P3) `ε₁ = 2 C_j ρ_j² + ρ_j √(2 C_j χ) ≤ ϑ_j/12` and `e^{-χ}(1 + e^{ϑ_j/12} + e^{ϑ_j/6}) ≤ δ/16`
  (L1020–1024);
* (P4) `Q ζ = δ/1000` and `δ/16 + (1 + e^{ϑ_j/4}) δ/1000 ≤ δ` (L1026–1030);
* (P1) phase counts: every stream touching block `j` has at most `C_j` phases (L978–984).

The proofs transport B-NUM's certificates (`F2e2e/B/NumericsCert.lean`, stated for the paper-form
parameters `alg2*`) through B-ARCH's bridges (`F2e2e/B/ArchParamsBridge.lean`).
-/

namespace F2e2e.B.Priv

open F2e2e.B

/-- The ideal lattice laws of the noise draws: a draw of kind `κ` has the two-sided geometric law on
`ℤ` with ratio `ϱ = b/(b + h_A)`, `b = P.scale κ` (`partII.tex` L700–716); the noise is `h_A k`. -/
noncomputable def idealLaw (P : AdaParams) (κ : NoiseKind) : PMF ℤ :=
  F2e2e.Discrete.latticeLaw (F2e2e.Discrete.latticeRho (P.scale κ : ℝ) (P.hA : ℝ))

/-- The lattice shift `⌈(8/n_j)/h_A⌉` covering the replacement sensitivity `8/n_j` of the
predictions of block `j` (`Δ'_j = h_A ⌈(8/n_j)/h_A⌉`, `partII.tex` L988). -/
def dShift (P : AdaParams) (j : ℕ) : ℕ := ⌈(8 / (blockN P j : ℚ)) / P.hA⌉₊

/-- The per-phase privacy parameter `ρ_j = 1/(64 d_j ⌈√(C_j χ)⌉)` of block `j` (`partII.tex` L998). -/
noncomputable def privRho (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) : ℝ :=
  1 / (64 * (adaD (dyadicExp aReq) j : ℝ) *
    (ceilSqrt (adaC J R (dyadicExp aReq) j * adaChi M J R (dyadicExp aReq) (dyadicExp ξReq)) : ℝ))

theorem privRho_nonneg (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) : 0 ≤ privRho M J R aReq ξReq j := by
  unfold privRho
  positivity

/-! ## Bridges to the paper-form parameters -/

theorem priv_accDelta_eq (aReq ξReq : ℝ) : accDelta aReq ξReq = alg2Delta aReq ξReq := by
  unfold accDelta adaDelta adaXiJ alg2Delta alg2XiJ
  push_cast
  rw [adaH_cast, adaXiA_cast, adaP_eq]

theorem priv_accVartheta_eq (aReq : ℝ) (j : ℕ) : accVartheta aReq j = alg2Vartheta aReq j := by
  unfold accVartheta alg2Vartheta
  rw [adaD_eq]

theorem tmaxList_getD (eA k : ℕ) : (adaTmaxList eA).getD k 0 = adaTmax eA k := by
  unfold adaTmaxList
  rw [List.getD_eq_getElem?_getD, List.getElem?_map]
  by_cases hk : k < adaP eA
  · rw [List.getElem?_range hk]
    rfl
  · rw [List.getElem?_eq_none (by simp; omega)]
    simp [adaTmax, hk]

theorem tmaxZ_sub (eA j m : ℕ) :
    adaTmaxZ eA ((j : ℤ) - m) = if m ≤ j then adaTmax eA (j - m) else 0 := by
  unfold adaTmaxZ
  by_cases h : m ≤ j
  · rw [if_pos (by omega), if_pos h, ← Nat.cast_sub h, Int.toNat_natCast]
  · rw [if_neg (by omega), if_neg h]

theorem tmaxZ_sub_two (eA j : ℕ) :
    adaTmaxZ eA ((j : ℤ) - 2) = if 2 ≤ j then adaTmax eA (j - 2) else 0 := by
  rw [show ((j : ℤ) - 2) = ((j : ℤ) - ((2 : ℕ) : ℤ)) by norm_num]
  exact tmaxZ_sub eA j 2

theorem tmaxZ_sub_one (eA j : ℕ) :
    adaTmaxZ eA ((j : ℤ) - 1) = if 1 ≤ j then adaTmax eA (j - 1) else 0 := by
  rw [show ((j : ℤ) - 1) = ((j : ℤ) - ((1 : ℕ) : ℤ)) by norm_num]
  exact tmaxZ_sub eA j 1

section Instance

variable (M J R : ℕ) {aReq ξReq : ℝ}

theorem priv_hA_cast (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaAlg2Params M J R aReq ξReq).hA : ℚ) : ℝ) = alg2HA M J R aReq ξReq :=
  adaParams_hA_cast M J R ha0 ha1 hξ0 hξ1

theorem priv_bInt_cast (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaAlg2Params M J R aReq ξReq).bInt : ℚ) : ℝ) = alg2BInt M J R aReq ξReq :=
  adaParams_bInt_cast M J R ha0 ha1 hξ0 hξ1

theorem priv_bOut_cast (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaAlg2Params M J R aReq ξReq).bOut : ℚ) : ℝ) = alg2BOut M J R aReq ξReq :=
  adaParams_bOut_cast M J R ha0 ha1 hξ0 hξ1

theorem priv_bNum_cast (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaAlg2Params M J R aReq ξReq).bNum : ℚ) : ℝ) = alg2BNum M J R aReq ξReq :=
  adaParams_bNum_cast M J R ha0 ha1 hξ0 hξ1

theorem priv_zeta_cast (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (((adaAlg2Params M J R aReq ξReq).zeta : ℚ) : ℝ) = alg2Zeta M J R aReq ξReq :=
  adaParams_zeta_cast M J R ha0 ha1 hξ0 hξ1

theorem priv_p_eq : (adaAlg2Params M J R aReq ξReq).p = alg2P aReq := adaP_eq aReq

theorem priv_blockN_eq (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    blockN (adaAlg2Params M J R aReq ξReq) j = alg2NBlock M J R aReq ξReq j := by
  show (adaBlockSizes M J R (dyadicExp aReq) (dyadicExp ξReq)).getD j 0 = _
  have hj' : j < adaP (dyadicExp aReq) + 1 := Nat.lt_succ_of_le hj
  unfold adaBlockSizes
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj']
  exact adaNBlock_eq M J R ha0 ha1 hξ0 hξ1 j

theorem priv_dShift_eq (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    (dShift (adaAlg2Params M J R aReq ξReq) j : ℝ) =
      (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) := by
  unfold dShift
  rw [← natCeil_ratCast]
  push_cast
  rw [priv_hA_cast M J R ha0 ha1 hξ0 hξ1, priv_blockN_eq M J R ha0 ha1 hξ0 hξ1 hj]

theorem priv_privRho_eq (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (j : ℕ) : privRho M J R aReq ξReq j = numRho M J R aReq ξReq j := by
  unfold privRho numRho
  rw [adaD_eq, adaC_eq, adaChi_eq M J R ha0 ha1 hξ0 hξ1, ceilSqrt_eq]
  push_cast
  rfl

/-! ## (P2) per-phase costs -/

/-- Internal edges touching block `j`: `d h_A/b_int ≤ ρ_j`. -/
theorem priv_edge_cost (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    (dShift (adaAlg2Params M J R aReq ξReq) j : ℝ) * ((adaAlg2Params M J R aReq ξReq).hA : ℝ) /
        ((adaAlg2Params M J R aReq ξReq).bInt : ℝ) ≤ privRho M J R aReq ξReq j := by
  have hj' : j ≤ alg2P aReq := by rw [← priv_p_eq M J R (ξReq := ξReq)]; exact hj
  rw [priv_dShift_eq M J R ha0 ha1 hξ0 hξ1 hj, priv_hA_cast M J R ha0 ha1 hξ0 hξ1,
    priv_bInt_cast M J R ha0 ha1 hξ0 hξ1, priv_privRho_eq M J R ha0 ha1 hξ0 hξ1]
  have hA := alg2HA_pos M J R aReq ξReq
  have hb : 0 < alg2BInt M J R aReq ξReq := by
    have := alg2H_pos aReq
    have := alg2Chi_pos_real M J R aReq ξReq
    unfold alg2BInt
    positivity
  have hΔ0 : 0 ≤ alg2HA M J R aReq ξReq *
      (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) := by positivity
  have h2 := two_mul_div_bInt_le_numRho M J R aReq ξReq hj' hΔ0 (deltaPrime_le M J R aReq ξReq hj')
  calc (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) *
        alg2HA M J R aReq ξReq / alg2BInt M J R aReq ξReq
      = alg2HA M J R aReq ξReq *
          (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) /
          alg2BInt M J R aReq ξReq := by ring
    _ ≤ 2 * (alg2HA M J R aReq ξReq *
          (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ)) /
          alg2BInt M J R aReq ξReq := by
        rw [div_le_div_iff_of_pos_right hb]
        linarith
    _ ≤ _ := h2

/-- The outer validator (block `0`): `d h_A/b_out ≤ ρ_0`. -/
theorem priv_outer_cost (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (dShift (adaAlg2Params M J R aReq ξReq) 0 : ℝ) * ((adaAlg2Params M J R aReq ξReq).hA : ℝ) /
        ((adaAlg2Params M J R aReq ξReq).bOut : ℝ) ≤ privRho M J R aReq ξReq 0 := by
  have hj : 0 ≤ (adaAlg2Params M J R aReq ξReq).p := Nat.zero_le _
  rw [priv_dShift_eq M J R ha0 ha1 hξ0 hξ1 hj, priv_hA_cast M J R ha0 ha1 hξ0 hξ1,
    priv_bOut_cast M J R ha0 ha1 hξ0 hξ1, priv_privRho_eq M J R ha0 ha1 hξ0 hξ1]
  have hA := alg2HA_pos M J R aReq ξReq
  have hb : 0 < alg2BOut M J R aReq ξReq := by
    have := alg2A_pos aReq
    have := alg2Chi_pos_real M J R aReq ξReq
    unfold alg2BOut
    positivity
  have hΔ0 : 0 ≤ alg2HA M J R aReq ξReq *
      (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) := by positivity
  have h2 := two_mul_div_bOut_le_numRho M J R aReq ξReq hΔ0
    (deltaPrime_le M J R aReq ξReq (Nat.zero_le _))
  calc (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) *
        alg2HA M J R aReq ξReq / alg2BOut M J R aReq ξReq
      = alg2HA M J R aReq ξReq *
          (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) /
          alg2BOut M J R aReq ξReq := by ring
    _ ≤ 2 * (alg2HA M J R aReq ξReq *
          (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ)) /
          alg2BOut M J R aReq ξReq := by
        rw [div_le_div_iff_of_pos_right hb]
        linarith
    _ ≤ _ := h2

/-- The numerical releases (block `0`): `d h_A/b_num ≤ ρ_0`. -/
theorem priv_num_cost (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (dShift (adaAlg2Params M J R aReq ξReq) 0 : ℝ) * ((adaAlg2Params M J R aReq ξReq).hA : ℝ) /
        ((adaAlg2Params M J R aReq ξReq).bNum : ℝ) ≤ privRho M J R aReq ξReq 0 := by
  have hj : 0 ≤ (adaAlg2Params M J R aReq ξReq).p := Nat.zero_le _
  rw [priv_dShift_eq M J R ha0 ha1 hξ0 hξ1 hj, priv_hA_cast M J R ha0 ha1 hξ0 hξ1,
    priv_bNum_cast M J R ha0 ha1 hξ0 hξ1, priv_privRho_eq M J R ha0 ha1 hξ0 hξ1]
  have hA := alg2HA_pos M J R aReq ξReq
  have hΔ0 : 0 ≤ alg2HA M J R aReq ξReq *
      (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) := by positivity
  have h2 := div_bNum_le_numRho M J R aReq ξReq hΔ0 (deltaPrime_le M J R aReq ξReq (Nat.zero_le _))
  calc (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) *
        alg2HA M J R aReq ξReq / alg2BNum M J R aReq ξReq
      = alg2HA M J R aReq ξReq *
          (⌈8 / (alg2NBlock M J R aReq ξReq 0 : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) /
          alg2BNum M J R aReq ξReq := by ring
    _ ≤ _ := h2

/-! ## (P3) composition numerics -/

/-- `ε₁ = 2 C_j ρ_j² + ρ_j √(2 C_j χ) ≤ ϑ_j/12` (L1020–1022). -/
theorem priv_eps (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    2 * (adaC J R (dyadicExp aReq) j : ℝ) * privRho M J R aReq ξReq j ^ 2 +
        privRho M J R aReq ξReq j * Real.sqrt (2 * (adaC J R (dyadicExp aReq) j : ℝ) *
          (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)) ≤
      accVartheta aReq j / 12 := by
  have hj' : j ≤ alg2P aReq := by rw [← priv_p_eq M J R (ξReq := ξReq)]; exact hj
  rw [priv_privRho_eq M J R ha0 ha1 hξ0 hξ1, adaC_eq, adaChi_eq M J R ha0 ha1 hξ0 hξ1,
    priv_accVartheta_eq]
  exact (advComp_budget_lt M J R aReq ξReq hj').le

/-- `e^{-χ} · 3 e^{1/6} ≤ δ/16` (L1022–1024: `e^{-χ}(1 + e^{ϑ_j/12} + e^{ϑ_j/6}) ≤ δ/16`). -/
theorem priv_tail (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    Real.exp (-(adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)) * (3 * Real.exp (1 / 6)) ≤
      accDelta aReq ξReq / 16 := by
  rw [adaChi_eq M J R ha0 ha1 hξ0 hξ1, priv_accDelta_eq]
  have e1 := exp_le_one_add_add_sq (x := 1 / 6) (by norm_num) (by norm_num)
  have hsum : 3 * Real.exp (1 / 6) ≤ 4 := by nlinarith
  have hexp := exp_neg_natCast_le (alg2Chi M J R aReq ξReq)
  have hinv := inv_two_pow_valChi_le M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change ((2 : ℝ) ^ alg2Chi M J R aReq ξReq)⁻¹ ≤
    alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    at hinv
  have hh := alg2H_pos aReq
  have hξ := alg2XiA_pos ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hQ : (600 : ℝ) ≤ alg2Q M J R aReq := by
    exact_mod_cast six_hundred_le_valQ M J R (alg2A_pos aReq)
  have hδ : alg2Delta aReq ξReq / 16 =
      alg2H aReq * alg2XiA ξReq / (3072 * ((alg2P aReq : ℝ) + 1)) := by
    unfold alg2Delta alg2XiJ
    field_simp
    ring
  rw [hδ]
  have hy : alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) *
      4 ≤ alg2H aReq * alg2XiA ξReq / (3072 * ((alg2P aReq : ℝ) + 1)) := by
    rw [div_mul_eq_mul_div, div_le_div_iff₀ (by positivity) (by positivity)]
    have hhx : 0 < alg2H aReq * alg2XiA ξReq := by positivity
    have : (4 : ℝ) * (3072 * ((alg2P aReq : ℝ) + 1)) ≤
        2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) := by nlinarith
    nlinarith
  calc Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) * (3 * Real.exp (1 / 6))
      ≤ alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) * 4 :=
        mul_le_mul (hexp.trans hinv) hsum (by positivity) (by positivity)
    _ ≤ _ := hy

/-- `0 < ϑ_j ≤ 1`. -/
theorem priv_vartheta_mem (aReq : ℝ) (j : ℕ) : 0 < accVartheta aReq j ∧ accVartheta aReq j ≤ 1 := by
  rw [priv_accVartheta_eq]
  exact ⟨alg2Vartheta_pos aReq j, alg2Vartheta_le_one aReq j⟩

/-! ## (P4) coupling numerics -/

/-- `Q ζ = δ/1000`. -/
theorem priv_Qzeta (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaQ M J R (dyadicExp aReq) : ℝ) * ((adaAlg2Params M J R aReq ξReq).zeta : ℝ) =
      accDelta aReq ξReq / 1000 := by
  rw [adaQ_eq, priv_zeta_cast M J R ha0 ha1 hξ0 hξ1, priv_accDelta_eq]
  exact alg2Q_mul_alg2Zeta M J R aReq ξReq

/-- `δ/16 + (1 + e^{ϑ_j/4}) δ/1000 ≤ δ` (L1028–1030). -/
theorem priv_final (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (j : ℕ) :
    accDelta aReq ξReq / 16 + (1 + Real.exp (accVartheta aReq j / 4)) * (accDelta aReq ξReq / 1000) ≤
      accDelta aReq ξReq := by
  have _hyp : 0 < aReq ∧ aReq < 1 / 10 ∧ 0 < ξReq ∧ ξReq < 1 / 2 := ⟨ha0, ha1, hξ0, hξ1⟩
  rw [priv_accDelta_eq, priv_accVartheta_eq]
  have h := coupling_delta_le aReq ξReq j
  have e : (1 + Real.exp (alg2Vartheta aReq j / 4)) * (alg2Delta aReq ξReq / 1000) =
      (1 + Real.exp (alg2Vartheta aReq j / 4)) * alg2Delta aReq ξReq / 1000 := by ring
  rw [e]
  exact h

/-! ## Positivity -/

theorem priv_pos (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    0 < (adaAlg2Params M J R aReq ξReq).hA ∧ 0 < (adaAlg2Params M J R aReq ξReq).bInt ∧
      0 < (adaAlg2Params M J R aReq ξReq).bOut ∧ 0 < (adaAlg2Params M J R aReq ξReq).bNum ∧
      0 < (adaAlg2Params M J R aReq ξReq).zeta ∧ 0 < accDelta aReq ξReq := by
  have hh := alg2H_pos aReq
  have ha := alg2A_pos aReq
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · unfold AdaParams.hA
    positivity
  · have h : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).bInt : ℚ) : ℝ) := by
      rw [priv_bInt_cast M J R ha0 ha1 hξ0 hξ1]
      unfold alg2BInt
      positivity
    exact_mod_cast h
  · have h : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).bOut : ℚ) : ℝ) := by
      rw [priv_bOut_cast M J R ha0 ha1 hξ0 hξ1]
      unfold alg2BOut
      positivity
    exact_mod_cast h
  · have h : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).bNum : ℚ) : ℝ) := by
      rw [priv_bNum_cast M J R ha0 ha1 hξ0 hξ1]
      unfold alg2BNum
      positivity
    exact_mod_cast h
  · have h : (0 : ℝ) < (((adaAlg2Params M J R aReq ξReq).zeta : ℚ) : ℝ) := by
      rw [priv_zeta_cast M J R ha0 ha1 hξ0 hξ1]
      exact alg2Zeta_pos M J R aReq ξReq
    exact_mod_cast h
  · rw [priv_accDelta_eq]
    exact alg2Delta_pos aReq ξReq

/-! ## (P1) phase counts against `C_j` -/

/-- An internal edge `e ∈ {j−1, j}` touching block `j` has at most
`1 + T_{e−1} + T_e + T_{e+1} ≤ C_j` phases. -/
theorem priv_edge_count (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {j e : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) (he : e + 1 = j ∨ e = j) :
    1 + (if 1 ≤ e then (adaAlg2Params M J R aReq ξReq).Tmax.getD (e - 1) 0 else 0) +
        (adaAlg2Params M J R aReq ξReq).Tmax.getD e 0 +
        (adaAlg2Params M J R aReq ξReq).Tmax.getD (e + 1) 0 ≤
      adaC J R (dyadicExp aReq) j := by
  have _hyp : 0 < aReq ∧ aReq < 1 / 10 ∧ 0 < ξReq ∧ ξReq < 1 / 2 := ⟨ha0, ha1, hξ0, hξ1⟩
  have hT : ∀ k, (adaAlg2Params M J R aReq ξReq).Tmax.getD k 0 = adaTmax (dyadicExp aReq) k :=
    fun k => tmaxList_getD _ k
  simp only [hT]
  have hj' : j ≤ adaP (dyadicExp aReq) := hj
  have h0 : ∀ k, adaP (dyadicExp aReq) ≤ k → adaTmax (dyadicExp aReq) k = 0 := fun k hk => by
    unfold adaTmax
    rw [if_neg (by omega)]
  unfold adaC
  rw [tmaxZ_sub_two, tmaxZ_sub_one]
  by_cases hj0 : j = 0
  · subst hj0
    rcases he with he | he
    · omega
    · subst he
      simp
      omega
  · rw [if_neg hj0]
    by_cases hjp : j < adaP (dyadicExp aReq)
    · rw [if_pos hjp]
      rcases he with he | he
      · subst he
        by_cases h1 : 1 ≤ e
        · rw [if_pos h1, if_pos (by omega : 2 ≤ e + 1), if_pos (by omega : 1 ≤ e + 1),
            show e + 1 - 2 = e - 1 by omega, show e + 1 - 1 = e by omega]
          omega
        · rw [if_neg h1, if_neg (by omega : ¬ 2 ≤ e + 1), if_pos (by omega : 1 ≤ e + 1),
            show e + 1 - 1 = e by omega]
          omega
      · subst he
        rw [if_pos (by omega : 1 ≤ e)]
        split_ifs <;> omega
    · have hjeq : j = adaP (dyadicExp aReq) := by omega
      rw [if_neg hjp, if_pos hjeq]
      rcases he with he | he
      · have hTp : adaTmax (dyadicExp aReq) (e + 1) = 0 := h0 _ (by omega)
        rw [hTp]
        subst he
        by_cases h1 : 1 ≤ e
        · rw [if_pos h1, if_pos (by omega : 2 ≤ e + 1), if_pos (by omega : 1 ≤ e + 1),
            show e + 1 - 2 = e - 1 by omega, show e + 1 - 1 = e by omega]
          omega
        · rw [if_neg h1, if_neg (by omega : ¬ 2 ≤ e + 1), if_pos (by omega : 1 ≤ e + 1),
            show e + 1 - 1 = e by omega]
          omega
      · subst e
        have hT1 : adaTmax (dyadicExp aReq) j = 0 := h0 _ (by omega)
        have hT2 : adaTmax (dyadicExp aReq) (j + 1) = 0 := h0 _ (by omega)
        rw [hT1, hT2, if_pos (by omega : 1 ≤ j)]
        split_ifs <;> omega

/-- The outer validator has at most `J + 1 ≤ C_0` phases. -/
theorem priv_outer_count (aReq : ℝ) : J + 1 ≤ adaC J R (dyadicExp aReq) 0 := by
  unfold adaC
  rw [if_pos rfl]
  omega

/-- The numerical stream has at most `R ≤ C_0` phases. -/
theorem priv_num_count (aReq : ℝ) : R ≤ adaC J R (dyadicExp aReq) 0 := by
  unfold adaC
  rw [if_pos rfl]
  omega

end Instance

end F2e2e.B.Priv
