import F2e2e.B.ArchOnline

/-!
# Theorem `R:thm:validation_ada` (P5): blocks of the sample and the per-block privacy interface

Paper: `parts/partII.tex` L647–650 (`R:eq:sec3_sample_blocks`: the sample is split into the independent
blocks `S_0, …, S_p` of sizes `n_0, …, n_p`), L1034 (Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` is
applied block by block, with the `(ϑ_j, δ)`-DP of the transcript as a function of `S_j`).

The core (`F2e2e/B/ArchOnline.lean`, `coreVals`) splits the sample `s : Fin N → U` into consecutive blocks:
block `j` consists of the indices `blockOff P j ≤ ℓ < blockOff P j + blockN P j`.

* `blockOff`, `blockN`, `InBlock`, `BlockNeighbor` (the samples differ in exactly one record, which lies in
  block `j`), `withBlock` (replace block `j`), `sampleBlock` (read block `j`);
* `CoreBlockDP`: the per-block privacy statement of (P2)–(P4) (L986–1030) at the core level, the input of
  (P5) from `F2e2e/B/Privacy*.lean`: for every deterministic valid controller and horizon, changing one
  record of block `j` moves the law of the online output history by at most `(ϑ_j, δ)` with
  `ϑ_j = 1/d_j`, `δ = h ξ_j/24` (Definition `R:def:sec3_ada_params`).
-/

namespace F2e2e.B

open F2e2e.Discrete

/-! ## Blocks -/

/-- The size `n_j` of block `j` (`0` out of range). -/
def blockN (P : AdaParams) (j : ℕ) : ℕ := P.blockSizes.getD j 0

/-- The offset `n_0 + ⋯ + n_{j-1}` of block `j` in the sample. -/
def blockOff (P : AdaParams) (j : ℕ) : ℕ := (P.blockSizes.take j).sum

/-- The sample index `ℓ` lies in block `j`. -/
abbrev InBlock (P : AdaParams) (j : ℕ) (ℓ : ℕ) : Prop := blockOff P j ≤ ℓ ∧ ℓ < blockOff P j + blockN P j

theorem blockOff_add_blockN_le (P : AdaParams) (j : ℕ) : blockOff P j + blockN P j ≤ P.N :=
  sum_take_add_getD_le P.blockSizes j

theorem blockOff_add_lt (P : AdaParams) (j : ℕ) (i : Fin (blockN P j)) : blockOff P j + i < P.N :=
  lt_of_lt_of_le (Nat.add_lt_add_left i.isLt _) (blockOff_add_blockN_le P j)

/-- Block `j` of the sample: `S_j = (X_{j,1}, …, X_{j,n_j})`. -/
def sampleBlock {U : Type} (P : AdaParams) (s : Fin P.N → U) (j : ℕ) : Fin (blockN P j) → U :=
  fun i => s ⟨blockOff P j + i, blockOff_add_lt P j i⟩

/-- The sample with block `j` replaced by `x`. -/
def withBlock {U : Type} (P : AdaParams) (s : Fin P.N → U) (j : ℕ) (x : Fin (blockN P j) → U) :
    Fin P.N → U :=
  fun ℓ => if h : InBlock P j ℓ then x ⟨ℓ - blockOff P j, by unfold InBlock at h; omega⟩ else s ℓ

/-- Two samples differ in at most one record, and that record lies in block `j` (single-record replacement
in `S_j`, `R:def:replacement_dp`). -/
def BlockNeighbor {U : Type} (P : AdaParams) (j : ℕ) (s s' : Fin P.N → U) : Prop :=
  ∃ ℓ : Fin P.N, InBlock P j ℓ ∧ ∀ ℓ' : Fin P.N, ℓ' ≠ ℓ → s ℓ' = s' ℓ'

/-! ## The per-block privacy interface (input from (P2)–(P4)) -/

/-- The privacy parameter `ϑ_j = 1/d_j` of block `j` (`d_j = ⌈√(p 4^j)⌉` for `j < p`, `d_p = ⌈4/h⌉`). -/
noncomputable def accVartheta (aReq : ℝ) (j : ℕ) : ℝ := 1 / (adaD (dyadicExp aReq) j : ℝ)

/-- The privacy slack `δ = h ξ_j/24`. -/
noncomputable def accDelta (aReq ξReq : ℝ) : ℝ := (adaDelta (dyadicExp aReq) (dyadicExp ξReq) : ℝ)

/-- **Per-block differential privacy of the online execution** ((P2)–(P4), `partII.tex` L986–1030, at the
core level): for every finite domain, deterministic valid controller, horizon `T` and block `j ≤ p`,
changing one record of block `j` moves the law of the output history of the online execution by at most
`(ϑ_j, δ)`: `Pr_s[E] ≤ e^{ϑ_j} Pr_{s'}[E] + δ` for every set `E` of output histories. -/
def CoreBlockDP (M J R : ℕ) (aReq ξReq : ℝ) : Prop :=
  ∀ (U : Type) [Fintype U] (ctrl : CoreCtrl U), ctrl.Valid (adaAlg2Params M J R aReq ξReq) →
    ∀ (T j : ℕ), j ≤ (adaAlg2Params M J R aReq ξReq).p →
      ∀ s s' : Fin (adaAlg2Params M J R aReq ξReq).N → U, BlockNeighbor (adaAlg2Params M J R aReq ξReq) j s s' →
        ∀ E : Set (List CoreOut),
          (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure E ≤
            ENNReal.ofReal (Real.exp (accVartheta aReq j)) *
                (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s' T).law.toOuterMeasure E +
              ENNReal.ofReal (accDelta aReq ξReq)

/-! ## Basic facts -/

theorem sampleBlock_withBlock {U : Type} (P : AdaParams) (s : Fin P.N → U) (j : ℕ)
    (x : Fin (blockN P j) → U) : sampleBlock P (withBlock P s j x) j = x := by
  funext i
  simp only [sampleBlock, withBlock]
  rw [dif_pos ⟨Nat.le_add_right _ _, Nat.add_lt_add_left i.isLt _⟩]
  congr 1
  ext
  simp

theorem withBlock_withBlock {U : Type} (P : AdaParams) (s : Fin P.N → U) (j : ℕ)
    (x x' : Fin (blockN P j) → U) : withBlock P (withBlock P s j x) j x' = withBlock P s j x' := by
  funext ℓ
  simp only [withBlock]
  split_ifs <;> rfl

theorem withBlock_sampleBlock {U : Type} (P : AdaParams) (s : Fin P.N → U) (j : ℕ) :
    withBlock P s j (sampleBlock P s j) = s := by
  funext ℓ
  simp only [withBlock, sampleBlock]
  split_ifs with h
  · congr 1
    ext
    simp only
    omega
  · rfl

/-- Replacing one coordinate of the block gives block neighbours. -/
theorem blockNeighbor_withBlock_update {U : Type} [DecidableEq U] (P : AdaParams) (s : Fin P.N → U)
    (j : ℕ) (x : Fin (blockN P j) → U) (i : Fin (blockN P j)) (a b : U) :
    BlockNeighbor P j (withBlock P s j (Function.update x i a))
      (withBlock P s j (Function.update x i b)) := by
  refine ⟨⟨blockOff P j + i, blockOff_add_lt P j i⟩, ⟨Nat.le_add_right _ _, Nat.add_lt_add_left i.isLt _⟩,
    fun ℓ' hℓ' => ?_⟩
  simp only [withBlock]
  split_ifs with h
  · have hne : (⟨ℓ' - blockOff P j, by omega⟩ : Fin (blockN P j)) ≠ i := by
      intro he
      apply hℓ'
      ext
      have := congrArg Fin.val he
      simp only at this ⊢
      omega
    rw [Function.update_of_ne hne, Function.update_of_ne hne]
  · rfl

/-- The block values used by the core: `coreVals` reads block `j` of the sample. -/
theorem coreVals_getD {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) (j : ℕ) :
    (coreVals P s req).getD j [] =
      List.ofFn (fun i : Fin (blockN P j) => req.f (sampleBlock P s j i)) := by
  have hle := blockOff_add_blockN_le P j
  rw [coreVals, splitBlocks_getD]
  apply List.ext_getElem
  · simp only [List.length_take, List.length_drop, List.length_ofFn]
    change min (blockN P j) (P.N - blockOff P j) = blockN P j
    omega
  · intro n h1 h2
    simp only [List.getElem_take, List.getElem_drop, List.getElem_ofFn, sampleBlock]
    rfl

/-- The in-block indices as `Fin (blockN P j)`. -/
def blockEquiv (P : AdaParams) (j : ℕ) : Fin (blockN P j) ≃ {ℓ : Fin P.N // InBlock P j ℓ} where
  toFun i := ⟨⟨blockOff P j + i, blockOff_add_lt P j i⟩, Nat.le_add_right _ _, Nat.add_lt_add_left i.isLt _⟩
  invFun ℓ := ⟨ℓ.1 - blockOff P j, by have := ℓ.2; unfold InBlock at this; omega⟩
  left_inv i := by ext; simp
  right_inv ℓ := by
    ext
    have := ℓ.2
    unfold InBlock at this
    simp only
    omega

theorem prod_inBlock (P : AdaParams) (j : ℕ) (g : Fin P.N → ℝ) :
    ∏ ℓ : {ℓ : Fin P.N // InBlock P j ℓ}, g ℓ =
      ∏ i : Fin (blockN P j), g ⟨blockOff P j + i, blockOff_add_lt P j i⟩ := by
  rw [← (blockEquiv P j).prod_comp]
  rfl

theorem prod_withBlock_mul {U : Type} (P : AdaParams) (D : U → ℝ) (s : Fin P.N → U) (j : ℕ)
    (x : Fin (blockN P j) → U) :
    (∏ ℓ, D (withBlock P s j x ℓ)) * ∏ i, D (sampleBlock P s j i) =
      (∏ ℓ, D (s ℓ)) * ∏ i, D (x i) := by
  classical
  rw [← Fintype.prod_subtype_mul_prod_subtype (fun ℓ : Fin P.N => InBlock P j ℓ)
      (fun ℓ => D (withBlock P s j x ℓ)),
    ← Fintype.prod_subtype_mul_prod_subtype (fun ℓ : Fin P.N => InBlock P j ℓ) (fun ℓ => D (s ℓ))]
  rw [prod_inBlock P j (fun ℓ => D (withBlock P s j x ℓ)),
    prod_inBlock P j (fun ℓ => D (s ℓ))]
  have h1 : ∀ i : Fin (blockN P j),
      withBlock P s j x ⟨blockOff P j + i, blockOff_add_lt P j i⟩ = x i := by
    intro i
    have := congrFun (sampleBlock_withBlock P s j x) i
    simpa [sampleBlock] using this
  have h2 : ∀ ℓ : {ℓ : Fin P.N // ¬ InBlock P j ℓ}, withBlock P s j x ℓ = s ℓ := by
    intro ℓ
    simp only [withBlock, dif_neg ℓ.2]
  simp only [h1, h2, sampleBlock]
  ring

/-- **Resampling a block** (`R:eq:sec3_sample_blocks`: the blocks are independent): for `s ∼ D^N` and an
independent `x ∼ D^{n_j}`, `withBlock s j x ∼ D^N`. -/
theorem sum_resample_block {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x)
    (hD1 : ∑ x, D x = 1) (j : ℕ) (G : (Fin P.N → U) → ENNReal) :
    ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) * G s =
      ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        ∑ x : Fin (blockN P j) → U, ENNReal.ofReal (∏ i, D (x i)) * G (withBlock P s j x) := by
  -- the involution `(s, x) ↦ (withBlock s j x, sampleBlock s j)` preserves the weight
  let Φ : (Fin P.N → U) × (Fin (blockN P j) → U) ≃ (Fin P.N → U) × (Fin (blockN P j) → U) :=
    { toFun := fun p => (withBlock P p.1 j p.2, sampleBlock P p.1 j)
      invFun := fun p => (withBlock P p.1 j p.2, sampleBlock P p.1 j)
      left_inv := fun p => by
        simp only [withBlock_withBlock, sampleBlock_withBlock, withBlock_sampleBlock]
      right_inv := fun p => by
        simp only [withBlock_withBlock, sampleBlock_withBlock, withBlock_sampleBlock] }
  have hw : ∀ p : (Fin P.N → U) × (Fin (blockN P j) → U),
      ENNReal.ofReal (∏ ℓ, D ((Φ p).1 ℓ)) * ENNReal.ofReal (∏ i, D ((Φ p).2 i)) =
        ENNReal.ofReal (∏ ℓ, D (p.1 ℓ)) * ENNReal.ofReal (∏ i, D (p.2 i)) := by
    intro p
    have hn : ∀ (n : ℕ) (y : Fin n → U), 0 ≤ ∏ i, D (y i) :=
      fun n y => Finset.prod_nonneg fun i _ => hD0 _
    rw [← ENNReal.ofReal_mul (hn _ _), ← ENNReal.ofReal_mul (hn _ _)]
    exact congrArg ENNReal.ofReal (prod_withBlock_mul P D p.1 j p.2)
  have hsum1 : ∑ x : Fin (blockN P j) → U, ENNReal.ofReal (∏ i, D (x i)) = 1 := by
    rw [← ENNReal.ofReal_sum_of_nonneg (fun x _ => Finset.prod_nonneg fun i _ => hD0 _),
      ← Fintype.sum_pow, hD1, one_pow, ENNReal.ofReal_one]
  calc ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) * G s
      = ∑ p : (Fin P.N → U) × (Fin (blockN P j) → U),
          ENNReal.ofReal (∏ ℓ, D (p.1 ℓ)) * ENNReal.ofReal (∏ i, D (p.2 i)) * G p.1 := by
        rw [Fintype.sum_prod_type]
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [show (∑ x : Fin (blockN P j) → U, ENNReal.ofReal (∏ ℓ, D ((s, x).1 ℓ)) *
            ENNReal.ofReal (∏ i, D ((s, x).2 i)) * G (s, x).1) =
            ENNReal.ofReal (∏ ℓ, D (s ℓ)) * G s *
              ∑ x : Fin (blockN P j) → U, ENNReal.ofReal (∏ i, D (x i)) by
          rw [Finset.mul_sum]
          exact Finset.sum_congr rfl fun x _ => by ring, hsum1, mul_one]
    _ = ∑ p : (Fin P.N → U) × (Fin (blockN P j) → U),
          ENNReal.ofReal (∏ ℓ, D ((Φ p).1 ℓ)) * ENNReal.ofReal (∏ i, D ((Φ p).2 i)) * G (Φ p).1 :=
        (Fintype.sum_equiv Φ _ _ fun p => rfl).symm
    _ = ∑ p : (Fin P.N → U) × (Fin (blockN P j) → U),
          ENNReal.ofReal (∏ ℓ, D (p.1 ℓ)) * ENNReal.ofReal (∏ i, D (p.2 i)) *
            G (withBlock P p.1 j p.2) := by
        refine Finset.sum_congr rfl fun p _ => ?_
        rw [hw p]
        rfl
    _ = ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          ∑ x : Fin (blockN P j) → U, ENNReal.ofReal (∏ i, D (x i)) * G (withBlock P s j x) := by
        rw [Fintype.sum_prod_type]
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun x _ => ?_
        ring

end F2e2e.B
