import F2e2e.B.Mechanism

/-!
# The core of Algorithm 2 run online against a controller: the core-level guarantee

Part III runs the core (`adaInit`, `adaInterval`, `adaNumerical`) directly inside its norm banks
(partIII.tex L205), with grid-valued queries and with composite controllers ("query selection uses
only permitted outputs and independent auxiliary randomness", partIII.tex L353; L121, L393;
partII.tex L1032). This file states the guarantee of Theorem `R:thm:validation_ada` at this level:

* `CoreReq`, `CoreCtrl` (a deterministic controller: the next request from the previous outputs,
  oldest first), `CoreCtrl.Valid`;
* the online execution `coreRun P ctrl s T : BitProg (List CoreOut)` (initialization, then `T`
  rounds; the sample `s` is split into the blocks `S_0, …, S_p`: the first `n_0` points form `S_0`,
  the next `n_1` form `S_1`, …) and its noise-draw form `coreRunD`;
* `coreCovered`, `coreCorrect`, `coreFails` (as the Spec's `VCovered`, `VCorrect`, `VFails`, for the
  grid-valued query `f̂ = h_A f` and the original endpoints; `abort` on a covered round — e.g.
  `CAP_ABORT` — is a failure);
* `CoreGuaranteeDet` (deterministic controllers, at accuracy `a_req − h_A`: the slack `h_A` pays
  for the query and endpoint rounding of the Spec-level mechanism), the primary analysis statement,
  proved from the skeleton of Theorem 3.6's proof (`F2e2e/B/Accuracy*.lean`; assembled in
  `F2e2e/B/Final.lean` as `core_guarantee_det`);
* `core_guarantee_of_det` (controllers with independent auxiliary randomness on any probability
  space, accuracy `a_req`; Part III uses `F2e2e.B.core_guarantee` of `Final.lean`);
* the Spec-level guarantee for deterministic controllers (`vDetFailMass`, `VGuaranteeDet`, with an
  independent countable auxiliary parameter `VGuaranteeDet.aux`); the bridge to it (`specToCore`,
  `vResponses_mechOf_eq`, `alg2_guarantee_det_of_core`) is in `F2e2e/B/ArchBridge.lean`, the draw
  counts (`coreRunD_drawsLE`, `coreRun_depth_le`) in `F2e2e/B/ArchCount.lean`.
-/

namespace F2e2e.B

open F2e2e.Discrete MeasureTheory

/-! ## Core-level requests, controllers and the online execution -/

/-- A core-level request on the domain `U`: the grid indices `f x` of a grid-valued query
`f̂ = h_A f`, the request type (`true` = interval) and the endpoints `l, u`. -/
structure CoreReq (U : Type) where
  /-- grid indices of the query values (`f̂(x) = h_A f(x) ∈ [0, 1]` for `f x ≤ 2^{qA}`) -/
  f : U → ℕ
  /-- `true` for an interval request, `false` for a numerical request -/
  isInterval : Bool
  /-- lower endpoint -/
  l : ℚ
  /-- upper endpoint -/
  u : ℚ

/-- Outputs of the core: interval certificates and numerical outputs. -/
abbrev CoreOut : Type := AdaCert ⊕ AdaNum

/-- A deterministic core-level controller: the next request from the previous outputs (oldest
first). -/
def CoreCtrl (U : Type) : Type := List CoreOut → CoreReq U

/-- Validity: grid indices at most `2^{qA}` (values in `[0, 1]`) and `l ≤ u` for interval requests. -/
def CoreCtrl.Valid {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) : Prop :=
  ∀ h : List CoreOut, (∀ x, (ctrl h).f x ≤ 2 ^ P.qA) ∧
    ((ctrl h).isInterval = true → (ctrl h).l ≤ (ctrl h).u)

/-- The block-structured grid indices `vals[j][i] = f(X_{j,i})` of a request on the sample `s`. -/
def coreVals {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) : List (List ℕ) :=
  splitBlocks P.blockSizes (List.ofFn fun ℓ => req.f (s ℓ))

/-- One online round, noise-draw form. -/
def coreStepD {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) (st : AdaState) :
    NoiseProg (CoreOut × AdaState) :=
  if req.isInterval = true then
    (adaIntervalD P st (coreVals P s req) req.l req.u).map fun r => (Sum.inl r.1, r.2)
  else (adaNumericalD P st (coreVals P s req)).map fun r => (Sum.inr r.1, r.2)

/-- `T` online rounds from the state `st` after the outputs `hist`, noise-draw form; returns the
whole output history. -/
def coreLoopD {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ℕ → AdaState → List CoreOut → NoiseProg (List CoreOut)
  | 0, _, hist => DrawProg.ret hist
  | T + 1, st, hist =>
    (coreStepD P s (ctrl hist) st).bind fun r => coreLoopD P ctrl s T r.2 (hist ++ [r.1])

/-- The online execution for `T` rounds, noise-draw form. -/
def coreRunD {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T : ℕ) :
    NoiseProg (List CoreOut) :=
  (adaInitD P).bind fun st => coreLoopD P ctrl s T st []

/-- One online round (fresh fair bits). -/
def coreStep {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) (st : AdaState) :
    BitProg (CoreOut × AdaState) :=
  if req.isInterval = true then
    (adaInterval P st (coreVals P s req) req.l req.u).map fun r => (Sum.inl r.1, r.2)
  else (adaNumerical P st (coreVals P s req)).map fun r => (Sum.inr r.1, r.2)

/-- `T` online rounds from the state `st` after the outputs `hist` (fresh fair bits). -/
def coreLoop {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ℕ → AdaState → List CoreOut → BitProg (List CoreOut)
  | 0, _, hist => BitProg.pure hist
  | T + 1, st, hist =>
    (coreStep P s (ctrl hist) st).bind fun r => coreLoop P ctrl s T r.2 (hist ++ [r.1])

/-- The online execution for `T` rounds: `adaInit`, then `T` rounds of `adaInterval`/`adaNumerical`
(fresh fair bits; this is how Part III runs the core). -/
def coreRun {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T : ℕ) :
    BitProg (List CoreOut) :=
  (adaInit P).bind fun st => coreLoop P ctrl s T st []

/-- Associativity of `BitProg.bind`. -/
theorem bitProg_bind_assoc {α β γ : Type} (p : BitProg α) (f : α → BitProg β)
    (g : β → BitProg γ) : (p.bind f).bind g = p.bind fun a => (f a).bind g := by
  induction p with
  | pure a => rfl
  | bit k ih =>
    simp only [BitProg.bind_bit]
    congr 1
    funext b
    exact ih b

/-- `toBits` is a monad morphism: it commutes with `bind`. -/
theorem drawProg_toBits_bind {Pm β α γ : Type} (smp : Pm → BitProg β) (prog : DrawProg Pm β α)
    (f : α → DrawProg Pm β γ) :
    (prog.bind f).toBits smp = (prog.toBits smp).bind fun a => (f a).toBits smp := by
  induction prog with
  | ret a => rfl
  | draw p k ih =>
    simp only [DrawProg.bind_draw, DrawProg.toBits_draw]
    rw [bitProg_bind_assoc]
    congr 1
    funext b
    exact ih b

theorem drawProg_toBits_map {Pm β α γ : Type} (smp : Pm → BitProg β) (prog : DrawProg Pm β α)
    (f : α → γ) : (prog.map f).toBits smp = (prog.toBits smp).map f := by
  unfold DrawProg.map BitProg.map
  rw [drawProg_toBits_bind]
  rfl

theorem coreStep_eq_toBits {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U)
    (st : AdaState) : coreStep P s req st = (coreStepD P s req st).toBits (adaDraw P) := by
  unfold coreStep coreStepD adaInterval adaNumerical
  split_ifs <;> rw [drawProg_toBits_map]

theorem coreLoop_eq_toBits {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut),
      coreLoop P ctrl s T st hist = (coreLoopD P ctrl s T st hist).toBits (adaDraw P)
  | 0, _, _ => rfl
  | T + 1, st, hist => by
    simp only [coreLoop, coreLoopD]
    rw [drawProg_toBits_bind, coreStep_eq_toBits]
    congr 1
    funext r
    exact coreLoop_eq_toBits P ctrl s T r.2 (hist ++ [r.1])

/-- The bit execution is the noise-draw execution with every draw run by the bounded sampler. -/
theorem coreRun_eq_toBits {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : coreRun P ctrl s T = (coreRunD P ctrl s T).toBits (adaDraw P) := by
  unfold coreRun coreRunD adaInit
  rw [drawProg_toBits_bind]
  congr 1
  funext st
  exact coreLoop_eq_toBits P ctrl s T st []

/-! ## The online execution with its final state -/

/-- `T` online rounds from the state `st` after the outputs `hist`, noise-draw form, returning the
whole output history and the final state. -/
def coreLoopSD {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ℕ → AdaState → List CoreOut → NoiseProg (List CoreOut × AdaState)
  | 0, st, hist => DrawProg.ret (hist, st)
  | T + 1, st, hist =>
    (coreStepD P s (ctrl hist) st).bind fun r => coreLoopSD P ctrl s T r.2 (hist ++ [r.1])

/-- The online execution for `T` rounds with its final state, noise-draw form. -/
def coreRunSD {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T : ℕ) :
    NoiseProg (List CoreOut × AdaState) :=
  (adaInitD P).bind fun st => coreLoopSD P ctrl s T st []

/-- The online execution for `T` rounds with its final state (fresh fair bits). -/
def coreRunS {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T : ℕ) :
    BitProg (List CoreOut × AdaState) :=
  (coreRunSD P ctrl s T).toBits (adaDraw P)

theorem coreLoopD_eq_map {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut),
      coreLoopD P ctrl s T st hist = (coreLoopSD P ctrl s T st hist).map Prod.fst
  | 0, _, _ => rfl
  | T + 1, st, hist => by
    simp only [coreLoopD, coreLoopSD, DrawProg.map]
    rw [DrawProg.bind_assoc]
    congr 1
    funext r
    rw [coreLoopD_eq_map P ctrl s T r.2 (hist ++ [r.1])]
    rfl

theorem coreRunD_eq_map {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : coreRunD P ctrl s T = (coreRunSD P ctrl s T).map Prod.fst := by
  unfold coreRunD coreRunSD
  simp only [DrawProg.map]
  rw [DrawProg.bind_assoc]
  congr 1
  funext st
  rw [coreLoopD_eq_map]
  rfl

theorem coreRun_eq_map {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (T : ℕ) : coreRun P ctrl s T = (coreRunS P ctrl s T).map Prod.fst := by
  rw [coreRun_eq_toBits, coreRunD_eq_map, coreRunS, drawProg_toBits_map]

/-- Internal failure of a state (Theorem `R:thm:validation_ada`, L952: "It never internally exhausts
a correction cap on this event"; Lemma `R:lem:sec3_potential_contraction` (v): `T_j < T_j^max`):
`CAP_ABORT` occurred, or some edge `j < p` has reached its correction cap. -/
def internalFails (P : AdaParams) (st : AdaState) : Prop :=
  st.capAborted = true ∨ ∃ j < P.p, P.Tmax.getD j 0 ≤ st.T.getD j 0

/-! ## Coverage, correctness, failure -/

/-- A rejection certificate (`HIGH`/`LOW`, terminal or not). -/
def coreIsReject : CoreOut → Bool
  | Sum.inl AdaCert.high => true
  | Sum.inl AdaCert.low => true
  | Sum.inl AdaCert.termHigh => true
  | Sum.inl AdaCert.termLow => true
  | _ => false

/-- The request of round `t` in the execution with outputs `o`. -/
def coreReqAt {U : Type} (ctrl : CoreCtrl U) (o : List CoreOut) (t : ℕ) : CoreReq U :=
  ctrl (o.take t)

/-- The output of round `t`. -/
def coreOutAt (o : List CoreOut) (t : ℕ) : CoreOut := o.getD t (Sum.inl AdaCert.abort)

/-- Round `t` is covered (as the Spec's `VCovered`): it is among the first `M` interval requests
(resp. the first `R` numerical requests), and at most `J` rejections were returned before it on
interval requests among the first `M`. -/
def coreCovered {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (t : ℕ) : Prop :=
  ((Finset.range t).filter (fun j =>
      (coreReqAt ctrl o j).isInterval = true ∧
        ((Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl o i).isInterval = true)).card ≤
          P.M ∧
        coreIsReject (coreOutAt o j) = true)).card ≤ P.J ∧
  ((coreReqAt ctrl o t).isInterval = true →
      ((Finset.range (t + 1)).filter (fun j => (coreReqAt ctrl o j).isInterval = true)).card ≤
        P.M) ∧
  ((coreReqAt ctrl o t).isInterval = false →
      ((Finset.range (t + 1)).filter (fun j => (coreReqAt ctrl o j).isInterval = false)).card ≤
        P.R)

/-- Correctness of an output for a request at accuracy `α` (as the Spec's `VCorrect`, for the
grid-valued query `f̂ = h_A f` and the original endpoints): `ACCEPT ⇒ 𝒟f̂ ∈ [l − α, u + α]`,
`HIGH ⇒ 𝒟f̂ ≥ u − α`, `LOW ⇒ 𝒟f̂ ≤ l + α` (terminal or not), numerical `μ̂ ∈ [0, 1]` with
`|μ̂ − 𝒟f̂| ≤ α`; `abort` and outputs of the wrong kind are incorrect. -/
def coreCorrect {U : Type} [Fintype U] (D : U → ℝ) (hA : ℚ) (α : ℝ) (req : CoreReq U)
    (out : CoreOut) : Prop :=
  if req.isInterval = true then
    match out with
    | Sum.inl AdaCert.accept =>
        (req.l : ℝ) - α ≤ popMean D (fun x => (hA : ℝ) * req.f x) ∧
          popMean D (fun x => (hA : ℝ) * req.f x) ≤ (req.u : ℝ) + α
    | Sum.inl AdaCert.high => (req.u : ℝ) - α ≤ popMean D (fun x => (hA : ℝ) * req.f x)
    | Sum.inl AdaCert.termHigh => (req.u : ℝ) - α ≤ popMean D (fun x => (hA : ℝ) * req.f x)
    | Sum.inl AdaCert.low => popMean D (fun x => (hA : ℝ) * req.f x) ≤ (req.l : ℝ) + α
    | Sum.inl AdaCert.termLow => popMean D (fun x => (hA : ℝ) * req.f x) ≤ (req.l : ℝ) + α
    | _ => False
  else
    match out with
    | Sum.inr (AdaNum.val q) =>
        0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ 1 ∧ |(q : ℝ) - popMean D (fun x => (hA : ℝ) * req.f x)| ≤ α
    | _ => False

/-- Failure at accuracy `α`: some covered round of the execution has an incorrect output. -/
def coreFails {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (α : ℝ) (ctrl : CoreCtrl U)
    (o : List CoreOut) : Prop :=
  ∃ t < o.length, coreCovered P ctrl o t ∧ ¬ coreCorrect D P.hA α (coreReqAt ctrl o t) (coreOutAt o t)

theorem coreCorrect_mono {U : Type} [Fintype U] (D : U → ℝ) (hA : ℚ) {α β : ℝ} (hαβ : α ≤ β)
    (req : CoreReq U) (out : CoreOut) (h : coreCorrect D hA α req out) :
    coreCorrect D hA β req out := by
  unfold coreCorrect at *
  split_ifs at * with hI
  · rcases out with c | x
    · cases c <;> simp only at h ⊢ <;>
        first | exact h.elim | (constructor <;> linarith [h.1, h.2]) | linarith
    · exact h.elim
  · rcases out with c | x
    · exact h.elim
    · cases x with
      | val q => exact ⟨h.1, h.2.1, h.2.2.trans hαβ⟩
      | abort => exact h.elim

theorem coreFails_mono {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) {α β : ℝ} (hαβ : α ≤ β)
    (ctrl : CoreCtrl U) (o : List CoreOut) (h : coreFails P D β ctrl o) : coreFails P D α ctrl o := by
  obtain ⟨t, ht, hcov, hinc⟩ := h
  exact ⟨t, ht, hcov, fun hc => hinc (coreCorrect_mono D P.hA hαβ _ _ hc)⟩

/-! ## The core-level guarantee -/

/-- **Theorem `R:thm:validation_ada`, core level, deterministic controllers** (the primary analysis
statement, proved in `F2e2e/B/Accuracy*.lean` from the skeleton of Theorem 3.6's proof): for every
finite domain, distribution, deterministic valid controller and horizon `T`, the online execution of
Algorithm 2 with the parameters of Definition `R:def:sec3_ada_params` fails at accuracy `a_req − h_A`
(some covered output incorrect, `CAP_ABORT` included) with probability at most `ξ_req` over the
sample and the fair bits. -/
def CoreGuaranteeDet (M J R : ℕ) (aReq ξReq : ℝ) : Prop :=
  ∀ (U : Type) [Fintype U] (D : U → ℝ), (∀ x, 0 ≤ D x) → ∑ x, D x = 1 →
    ∀ ctrl : CoreCtrl U, ctrl.Valid (adaAlg2Params M J R aReq ξReq) → ∀ T : ℕ,
      ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure
          {o | coreFails (adaAlg2Params M J R aReq ξReq) D
            (aReq - ((adaAlg2Params M J R aReq ξReq).hA : ℝ)) ctrl o} ≤ ENNReal.ofReal ξReq

/-- **Theorem `R:thm:validation_ada` with its internal-cap clause, core level, deterministic
controllers** (strengthens `CoreGuaranteeDet`; the form needed for Spec v2's
`VGuaranteeWithInternalCaps`): with probability at most `ξ_req`, some covered output is incorrect at
accuracy `a_req − h_A`, or the final state has `CAP_ABORT` or a reached correction cap (corrections only
happen during processed, hence covered, requests). -/
def CoreGuaranteeDetS (M J R : ℕ) (aReq ξReq : ℝ) : Prop :=
  ∀ (U : Type) [Fintype U] (D : U → ℝ), (∀ x, 0 ≤ D x) → ∑ x, D x = 1 →
    ∀ ctrl : CoreCtrl U, ctrl.Valid (adaAlg2Params M J R aReq ξReq) → ∀ T : ℕ,
      ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRunS (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure
          {r | coreFails (adaAlg2Params M J R aReq ξReq) D
            (aReq - ((adaAlg2Params M J R aReq ξReq).hA : ℝ)) ctrl r.1 ∨
            internalFails (adaAlg2Params M J R aReq ξReq) r.2} ≤ ENNReal.ofReal ξReq

theorem coreGuaranteeDet_of_S {M J R : ℕ} {aReq ξReq : ℝ} (h : CoreGuaranteeDetS M J R aReq ξReq) :
    CoreGuaranteeDet M J R aReq ξReq := by
  intro U _ D hD0 hD1 ctrl hctrl T
  refine le_trans (Finset.sum_le_sum fun s _ => ?_) (h U D hD0 hD1 ctrl hctrl T)
  refine mul_le_mul' le_rfl ?_
  rw [coreRun_eq_map, BitProg.law_map, PMF.toOuterMeasure_map_apply]
  exact OuterMeasure.mono _ fun r hr => Or.inl hr

/-- Finite sums commute below the lower Lebesgue integral (superadditivity of `∫⁻`; no
measurability needed). -/
theorem sum_lintegral_le_lintegral_sum {Ω ι : Type} [MeasurableSpace Ω] (μ : Measure Ω)
    (S : Finset ι) (F : ι → Ω → ENNReal) :
    ∑ i ∈ S, ∫⁻ ω, F i ω ∂μ ≤ ∫⁻ ω, ∑ i ∈ S, F i ω ∂μ := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | insert a S ha ih =>
    rw [Finset.sum_insert ha]
    calc ∫⁻ ω, F a ω ∂μ + ∑ i ∈ S, ∫⁻ ω, F i ω ∂μ
        ≤ ∫⁻ ω, F a ω ∂μ + ∫⁻ ω, ∑ i ∈ S, F i ω ∂μ := add_le_add le_rfl ih
      _ ≤ ∫⁻ ω, (F a ω + ∑ i ∈ S, F i ω) ∂μ := le_lintegral_add _ _
      _ = ∫⁻ ω, ∑ i ∈ insert a S, F i ω ∂μ := by
        congr 1; funext ω; rw [Finset.sum_insert ha]

/-- **Theorem `R:thm:validation_ada`, core level, controllers with independent auxiliary
randomness** (Part III's composite controllers: adversary coins × other components' bits, any
probability space; no measurability is needed since the bound holds for every coin outcome): the
online execution fails at accuracy `a_req` with probability at most `ξ_req`. -/
theorem core_guarantee_of_det {M J R : ℕ} {aReq ξReq : ℝ} (hdet : CoreGuaranteeDet M J R aReq ξReq)
    {U : Type} [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (Ω : Type) [MeasurableSpace Ω] (Pω : Measure Ω)
    [IsProbabilityMeasure Pω] (ctrl : Ω → CoreCtrl U)
    (hctrl : ∀ ω, (ctrl ω).Valid (adaAlg2Params M J R aReq ξReq)) (T : ℕ) :
    ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
      ∫⁻ ω, (coreRun (adaAlg2Params M J R aReq ξReq) (ctrl ω) s T).law.toOuterMeasure
        {o | coreFails (adaAlg2Params M J R aReq ξReq) D aReq (ctrl ω) o} ∂Pω ≤
      ENNReal.ofReal ξReq := by
  set P := adaAlg2Params M J R aReq ξReq
  have hA0 : (0 : ℝ) ≤ (P.hA : ℝ) := by
    show (0 : ℝ) ≤ (((1 / 2 : ℚ) ^ P.qA : ℚ) : ℝ)
    positivity
  -- pointwise (in the coins) bound from the deterministic guarantee
  have hpt : ∀ ω, ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
      (coreRun P (ctrl ω) s T).law.toOuterMeasure {o | coreFails P D aReq (ctrl ω) o} ≤
      ENNReal.ofReal ξReq := by
    intro ω
    refine le_trans (Finset.sum_le_sum fun s _ => ?_) (hdet U D hD0 hD1 (ctrl ω) (hctrl ω) T)
    refine mul_le_mul' le_rfl (OuterMeasure.mono _ fun o ho => ?_)
    exact coreFails_mono P D (by linarith) (ctrl ω) o ho
  calc ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        ∫⁻ ω, (coreRun P (ctrl ω) s T).law.toOuterMeasure {o | coreFails P D aReq (ctrl ω) o} ∂Pω
      = ∑ s : Fin P.N → U, ∫⁻ ω, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRun P (ctrl ω) s T).law.toOuterMeasure {o | coreFails P D aReq (ctrl ω) o} ∂Pω := by
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
    _ ≤ ∫⁻ ω, ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRun P (ctrl ω) s T).law.toOuterMeasure {o | coreFails P D aReq (ctrl ω) o} ∂Pω :=
        sum_lintegral_le_lintegral_sum Pω _ _
    _ ≤ ∫⁻ _ω, ENNReal.ofReal ξReq ∂Pω := lintegral_mono hpt
    _ = ENNReal.ofReal ξReq := by simp

/-! ## Spec-level guarantee for deterministic controllers -/

open Classical in
/-- The failure mass of a deterministic controller: `∑_s D^N(s) · #{ω | some covered response is
incorrect}`, i.e. `2^c` times the failure probability over `s ~ D^N` and the `c` fair coins. -/
noncomputable def vDetFailMass {U : Type} [Fintype U] {N c : ℕ} (mech : VMechanism N c)
    (D : U → ℝ) (M J R : ℕ) (aReq : ℝ) (ctrl : VController U) : ENNReal :=
  ∑ s : Fin N → U, ∑ ω : Fin c → Bool,
    ENNReal.ofReal (∏ ℓ, D (s ℓ)) * (if VFails mech D M J R aReq ctrl s ω then 1 else 0)

/-- The guarantee of Theorem `R:thm:validation_ada` for deterministic controllers: for every finite
domain, distribution and deterministic valid controller, the failure probability is at most
`ξReq`. -/
def VGuaranteeDet (M J R : ℕ) (aReq ξReq : ℝ) {N c : ℕ} (mech : VMechanism N c) : Prop :=
  ∀ (U : Type) [Fintype U] (D : U → ℝ), (∀ x, 0 ≤ D x) → ∑ x, D x = 1 →
    ∀ ctrl : VController U, ctrl.Valid →
      vDetFailMass mech D M J R aReq ctrl ≤ ENNReal.ofReal ξReq * 2 ^ c

/-- **Independent auxiliary parameter** (partII.tex L1032): a controller that is deterministic given
an auxiliary parameter `a ~ μA`, independent of the sample and of the mechanism's coins, fails with
probability at most `ξReq`. -/
theorem VGuaranteeDet.aux {M J R : ℕ} {aReq ξReq : ℝ} {N c : ℕ} {mech : VMechanism N c}
    (h : VGuaranteeDet M J R aReq ξReq mech) (U : Type) [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) {A : Type} (μA : PMF A) (ctrl : A → VController U)
    (hctrl : ∀ a, (ctrl a).Valid) :
    ∑' a, μA a * vDetFailMass mech D M J R aReq (ctrl a) ≤ ENNReal.ofReal ξReq * 2 ^ c := by
  calc ∑' a, μA a * vDetFailMass mech D M J R aReq (ctrl a)
      ≤ ∑' a, μA a * (ENNReal.ofReal ξReq * 2 ^ c) :=
        ENNReal.tsum_le_tsum fun a => mul_le_mul' le_rfl (h U D hD0 hD1 (ctrl a) (hctrl a))
    _ = ENNReal.ofReal ξReq * 2 ^ c := by rw [ENNReal.tsum_mul_right, PMF.tsum_coe, one_mul]

end F2e2e.B
