import F2e2e.B.PrivacyStreams
import F2e2e.B.PrivacyTV
import F2e2e.B.PrivacyRefineMain
import F2e2e.B.PrivacyHybrid

/-!
# Theorem `R:thm:validation_ada`, privacy pillars (P2)–(P4): the per-block DP of the core

Paper: `parts/partII.tex` L986–1032.

`core_block_dp`: for every block `j ≤ p`, changing one record of block `j` moves the law of the
online output history of B-ARCH's core (`coreRun`, fresh fair bits through the bounded lattice
samplers) by at most `(ϑ_j, δ)` (`CoreBlockDP`, `F2e2e/B/AccuracyBlocks.lean`).

Proof:
1. Refinement (`coreRunD_refine`, `F2e2e/B/PrivacyRefineMain.lean`): under the ideal lattice laws the
   core's law is that of the data-oblivious skeleton `skRunD` with the stream oracles `coreSpec`.
2. (P2)+(P3) (`block_indist`, `F2e2e/B/PrivacyHybrid.lean`): the streams touching block `j`
   (`streamsOf j`: edges `j−1, j`; for `j = 0` the edge `0`, the outer validator and the numerical
   releases) are pure `ρ_j`-DP per phase (`phaseDP_streamsOf`, `F2e2e/B/PrivacyStreams.lean`:
   replacement sensitivity `8/n_j` of the predictions, lattice shift costs), with at most `C_j` phases
   each (`startsLE_streamsOf`); the other streams do not read block `j` (`hinv_core`). Hence the
   ideal laws are `(3 ε₁, e^{-χ}(1 + e^{ε₁} + e^{2ε₁}))`-, so `(ϑ_j/4, δ/16)`-indistinguishable
   (`core_block_ideal`; numerics `priv_eps`, `priv_tail` in `F2e2e/B/PrivacyNum.lean`).
3. (P4) (`block_dp_of_ideal`, `F2e2e/B/PrivacyTV.lean`): the bounded samplers are within TV `ζ` of
   the ideal laws per draw, at most `Q` draws, `Qζ = δ/1000`, so the actual laws are
   `(ϑ_j, δ)`-indistinguishable.
-/

namespace F2e2e.B.Priv

open F2e2e.B F2e2e.Discrete

/-- Block neighbours: the second sample is the first with block `j` replaced by its own block `j`. -/
theorem withBlock_sampleBlock_of_blockNeighbor {U : Type} (P : AdaParams) {s s' : Fin P.N → U}
    {j : ℕ} (h : BlockNeighbor P j s s') : withBlock P s j (sampleBlock P s' j) = s' := by
  obtain ⟨ℓ₀, hℓ₀, hne⟩ := h
  funext ℓ
  simp only [withBlock, sampleBlock]
  split_ifs with hb
  · congr 1
    ext
    simp only
    unfold InBlock at hb
    omega
  · apply hne
    intro he
    rw [he] at hb
    exact hb hℓ₀

/-- **(P2)+(P3) for the ideal laws**: changing one record of block `j` moves the ideal law of the
online execution by at most `(ϑ_j/4, δ/16)` (`partII.tex` L1004–1024). -/
theorem core_block_ideal (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} (ctrl : CoreCtrl U) (T j : ℕ)
    (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) (s s' : Fin (adaAlg2Params M J R aReq ξReq).N → U)
    (hss : BlockNeighbor (adaAlg2Params M J R aReq ξReq) j s s') :
    PIndist (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
        (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s T))
      (DrawProg.interp (idealLaw (adaAlg2Params M J R aReq ξReq))
        (coreRunD (adaAlg2Params M J R aReq ξReq) ctrl s' T))
      (accVartheta aReq j / 4) (accDelta aReq ξReq / 16) := by
  rw [coreRunD_refine _ s ctrl T, coreRunD_refine _ s' ctrl T]
  obtain ⟨i₀, hi₀⟩ := sampleBlock_offOne_of_blockNeighbor _ hss
  have hadj : BlockAdj (adaAlg2Params M J R aReq ξReq) j (sampleBlock _ s j) (sampleBlock _ s' j) :=
    ⟨i₀, hi₀⟩
  have key := block_indist (idealLaw (adaAlg2Params M J R aReq ξReq))
    (coreSpec (adaAlg2Params M J R aReq ξReq)) (fun D y => withBlock (adaAlg2Params M J R aReq ξReq) D j y)
    (streamsOf j) s (hinv_core _ j s) (privRho_nonneg M J R aReq ξReq j)
    (phaseDP_streamsOf M J R ha0 ha1 hξ0 hξ1 hj s) (skRunD (adaAlg2Params M J R aReq ξReq) ctrl T)
    (startsLE_streamsOf M J R ha0 ha1 hξ0 hξ1 hj ctrl T) hadj
    (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)
  simp only [withBlock_sampleBlock, withBlock_sampleBlock_of_blockNeighbor _ hss] at key
  set ε₁ := 2 * (adaC J R (dyadicExp aReq) j : ℝ) * privRho M J R aReq ξReq j ^ 2 +
    privRho M J R aReq ξReq j * Real.sqrt (2 * (adaC J R (dyadicExp aReq) j : ℝ) *
      (adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)) with hε₁
  have h1 : ε₁ ≤ accVartheta aReq j / 12 := priv_eps M J R ha0 ha1 hξ0 hξ1 hj
  have h0 : 0 ≤ ε₁ :=
    add_nonneg (by positivity) (mul_nonneg (privRho_nonneg M J R aReq ξReq j) (Real.sqrt_nonneg _))
  have hϑ := (priv_vartheta_mem aReq j).2
  have hc : ((streamsOf j).card : ℝ) ≤ 3 := by exact_mod_cast streamsOf_card_le j
  refine key.mono ?_ ?_
  · calc ((streamsOf j).card : ℝ) * ε₁ ≤ 3 * ε₁ := mul_le_mul_of_nonneg_right hc h0
      _ ≤ 3 * (accVartheta aReq j / 12) := by linarith
      _ = accVartheta aReq j / 4 := by ring
  · have hsum : ∑ i ∈ Finset.range (streamsOf j).card, Real.exp (i * ε₁) ≤
        3 * Real.exp (1 / 6) := by
      calc ∑ i ∈ Finset.range (streamsOf j).card, Real.exp (i * ε₁)
          ≤ ∑ _i ∈ Finset.range (streamsOf j).card, Real.exp (1 / 6) := by
            apply Finset.sum_le_sum
            intro i hi
            apply Real.exp_le_exp.2
            have hi2 : i ≤ 2 := by
              have := Finset.mem_range.1 hi
              have := streamsOf_card_le j
              omega
            have hi2' : (i : ℝ) ≤ 2 := by exact_mod_cast hi2
            have hi0 : (0 : ℝ) ≤ i := Nat.cast_nonneg i
            nlinarith
        _ = (streamsOf j).card * Real.exp (1 / 6) := by
            rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
        _ ≤ 3 * Real.exp (1 / 6) := mul_le_mul_of_nonneg_right hc (Real.exp_pos _).le
    calc Real.exp (-(adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)) *
          ∑ i ∈ Finset.range (streamsOf j).card, Real.exp (i * ε₁)
        ≤ Real.exp (-(adaChi M J R (dyadicExp aReq) (dyadicExp ξReq) : ℝ)) *
          (3 * Real.exp (1 / 6)) := mul_le_mul_of_nonneg_left hsum (Real.exp_pos _).le
      _ ≤ accDelta aReq ξReq / 16 := priv_tail M J R ha0 ha1 hξ0 hξ1

end F2e2e.B.Priv

namespace F2e2e.B

open F2e2e.Discrete

/-- **Per-block DP of the core** ((P2)–(P4), `partII.tex` L986–1032). -/
theorem core_block_dp (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) : CoreBlockDP M J R aReq ξReq :=
  Priv.block_dp_of_ideal M J R ha0 ha1 hξ0 hξ1 fun _ ctrl T j hj s s' h =>
    Priv.core_block_ideal M J R ha0 ha1 hξ0 hξ1 ctrl T j hj s s' h

end F2e2e.B
