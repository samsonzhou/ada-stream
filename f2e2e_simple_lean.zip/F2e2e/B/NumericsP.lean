import F2e2e.B.NumericsDyadic

/-!
# Part II numerics (B-NUM), part 2: `p`, `τ`, `h`, `T_j^max`, `Q`, `χ` of Definition `R:def:sec3_ada_params`

Source: `parts/partII.tex` L671–688 (Definition `R:def:sec3_ada_params`):
"Choose the least `p ≥ 2` such that `4^{p-1}(a/(8p))² ≥ 1`, and set `τ := a/(8p)`, `h := τ/64`,
`T_j^max := ⌈6/(4^j τ²)⌉`, so that, by minimality of `p`, `1 ≤ 4^{p-1}τ² < 4`";
`Q = 100(p+1)(M+R+J+2+∑_{j<p} T_j^max)`, `χ = ⌈log₂(2^40(p+1)Q/(h ξ_A))⌉`.
Spec names: `valP`, `valTau`, `valH`, `valTmax`, `valQ`, `valChi`.

Everything here is stated for a general accuracy `a` (usually `0 < a ≤ 1/16`, which holds for the dyadic
`a = dyadicDown a_req` when `a_req < 1/10`, see `dyadicDown_le_sixteenth`).

Main results (namespace `F2e2e.B`):
* `valP_mem`, `two_le_valP`, `valP_cond` (`8p ≤ 2^{p-1} a`), `cond_fails_of_lt_valP` (minimality);
* `twelve_le_valP` (`a ≤ 1/16`), `three_le_valP` (`a < 8`);
* `one_le_four_pow_valTau_sq`, `four_pow_valTau_sq_lt_four`: `1 ≤ 4^{p-1}τ² < 4`;
* `two_pow_valP_lt`: `2^p < 32 p / a` (minimality); `valP_le_two_mul_dyadicExp_add_four`,
  `valP_le_two_pow_dyadicExp`: `p ≤ 2⌈log₂(1/a)⌉ + 4 ≤ 2^{⌈log₂(1/a)⌉}`;
* `valTau_eq`, `valH_eq`, `one_div_valTau`, `one_div_valH`, positivity and size facts;
* `le_valTmax`, `valTmax_lt`, `one_le_valTmax`, `valTmax_le_six_mul_four_pow` (`T_j ≤ 6·4^{p-1-j}`),
  `valTmax_pred_le` (`T_{p-1} ≤ 6`), `valTmax_pred_pred_le` (`T_{p-2} ≤ 24`),
  `quarter_lt_inv_four_pow_valTau_sq` (`v = 4^{-j}τ^{-2} > 1/4` for `j < p`),
  `sum_valTmax_le` (`∑_{j<p} T_j ≤ 8τ^{-2} + p`);
* `valQ_cast`, `six_hundred_le_valQ`, `valQ_le`;
* `chiArg` (the argument of `log₂` in `χ`), `chiArg_le_two_pow_valChi`, `valChi_lt_logb_add_one`,
  `two_pow_sixty_lt_chiArg`, `sixty_lt_valChi`, `forty_lt_valChi`, `valP_lt_valChi`,
  `inv_two_pow_valChi_le`.
-/

namespace F2e2e.B

/-! ### `p` -/

/-- The defining set of `valP a`. -/
def valPSet (a : ℝ) : Set ℕ :=
  {p : ℕ | 2 ≤ p ∧ 1 ≤ (4 : ℝ) ^ (p - 1) * (a / (8 * (p : ℝ))) ^ 2}

theorem valP_eq_sInf (a : ℝ) : valP a = sInf (valPSet a) := rfl

/-- `4^{p-1}(a/(8p))² = (2^{p-1} a/(8p))²`. -/
theorem valPCond_eq_sq (a : ℝ) (p : ℕ) :
    (4 : ℝ) ^ (p - 1) * (a / (8 * (p : ℝ))) ^ 2 = (2 ^ (p - 1) * a / (8 * (p : ℝ))) ^ 2 := by
  have h4 : (4 : ℝ) ^ (p - 1) = ((2 : ℝ) ^ (p - 1)) ^ 2 := by
    rw [← pow_mul, mul_comm, pow_mul]
    norm_num
  rw [h4]
  ring

/-- The defining condition `1 ≤ 4^{p-1}(a/(8p))²` is `8p ≤ 2^{p-1} a` (for `a ≥ 0`, `p ≥ 1`). -/
theorem valPCond_iff {a : ℝ} (ha : 0 ≤ a) {p : ℕ} (hp : 1 ≤ p) :
    1 ≤ (4 : ℝ) ^ (p - 1) * (a / (8 * (p : ℝ))) ^ 2 ↔ 8 * (p : ℝ) ≤ 2 ^ (p - 1) * a := by
  rw [valPCond_eq_sq]
  have hp1 : (1 : ℝ) ≤ p := by exact_mod_cast hp
  have hp' : (0 : ℝ) < 8 * p := by positivity
  have hy : 0 ≤ 2 ^ (p - 1) * a / (8 * (p : ℝ)) := by positivity
  rw [← one_le_div hp']
  constructor
  · intro h
    by_contra hc
    have hc' := not_le.mp hc
    nlinarith
  · intro h
    nlinarith

/-- `2k + 4 ≤ 2^k` for `k ≥ 4`. -/
theorem two_mul_add_four_le_two_pow {k : ℕ} (hk : 4 ≤ k) : 2 * k + 4 ≤ 2 ^ k := by
  induction k, hk using Nat.le_induction with
  | base => norm_num
  | succ n hn ih =>
    have h2 : 2 ≤ 2 ^ n :=
      calc 2 = 2 ^ 1 := by norm_num
        _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) (by omega)
    rw [pow_succ]
    omega

/-- A sufficient condition for membership: if `2^{-k} ≤ a`, `p ≥ max(2, k+1)` and `8p ≤ 2^{p-1-k}`. -/
theorem mem_valPSet_of_two_pow {a : ℝ} (ha : 0 < a) {k p : ℕ} (hk : ((2 : ℝ) ^ k)⁻¹ ≤ a)
    (hp2 : 2 ≤ p) (hpk : k + 1 ≤ p) (h : 8 * p ≤ 2 ^ (p - 1 - k)) : p ∈ valPSet a := by
  refine ⟨hp2, (valPCond_iff ha.le (by omega)).mpr ?_⟩
  have h1 : (8 * p : ℝ) ≤ 2 ^ (p - 1 - k) := by exact_mod_cast h
  have h2 : (2 : ℝ) ^ (p - 1) = 2 ^ (p - 1 - k) * 2 ^ k := by
    rw [← pow_add]
    congr 1
    omega
  have h3 : (2 : ℝ) ^ (p - 1 - k) = 2 ^ (p - 1) * ((2 : ℝ) ^ k)⁻¹ := by
    rw [h2, mul_assoc, mul_inv_cancel₀ (by positivity), mul_one]
  calc 8 * (p : ℝ) ≤ 2 ^ (p - 1 - k) := h1
    _ = 2 ^ (p - 1) * ((2 : ℝ) ^ k)⁻¹ := h3
    _ ≤ 2 ^ (p - 1) * a := by gcongr

theorem two_pow_dyadicExp_inv_le {a : ℝ} (ha : 0 < a) : ((2 : ℝ) ^ dyadicExp a)⁻¹ ≤ a := by
  rw [← dyadicDown_eq]
  exact dyadicDown_le ha

/-- The defining set of `p` is nonempty for `a > 0` (witness `2⌈log₂(1/a)⌉ + 8`). -/
theorem valPSet_nonempty {a : ℝ} (ha : 0 < a) : (valPSet a).Nonempty := by
  refine ⟨2 * dyadicExp a + 8, mem_valPSet_of_two_pow ha (two_pow_dyadicExp_inv_le ha)
    (by omega) (by omega) ?_⟩
  have e : 2 * dyadicExp a + 8 - 1 - dyadicExp a = dyadicExp a + 7 := by omega
  rw [e, pow_add]
  have := Nat.lt_two_pow_self (n := dyadicExp a)
  generalize 2 ^ dyadicExp a = t at *
  omega

theorem valP_mem {a : ℝ} (ha : 0 < a) : valP a ∈ valPSet a := Nat.sInf_mem (valPSet_nonempty ha)

theorem two_le_valP {a : ℝ} (ha : 0 < a) : 2 ≤ valP a := (valP_mem ha).1

theorem valP_pos {a : ℝ} (ha : 0 < a) : 0 < valP a := by
  have := two_le_valP ha
  omega

theorem two_le_valP_real {a : ℝ} (ha : 0 < a) : (2 : ℝ) ≤ valP a := by
  exact_mod_cast two_le_valP ha

theorem valP_le_of_mem {a : ℝ} {q : ℕ} (hq : q ∈ valPSet a) : valP a ≤ q := Nat.sInf_le hq

/-- `8p ≤ 2^{p-1} a`, i.e. `4^{p-1}(a/(8p))² ≥ 1`. -/
theorem valP_cond {a : ℝ} (ha : 0 < a) : 8 * (valP a : ℝ) ≤ 2 ^ (valP a - 1) * a :=
  (valPCond_iff ha.le (by have := two_le_valP ha; omega)).mp (valP_mem ha).2

/-- Minimality of `p`: every `2 ≤ q < p` fails the condition, `2^{q-1} a < 8q`. -/
theorem cond_fails_of_lt_valP {a : ℝ} (ha : 0 < a) {q : ℕ} (hq2 : 2 ≤ q) (hq : q < valP a) :
    2 ^ (q - 1) * a < 8 * (q : ℝ) := by
  have hn := Nat.notMem_of_lt_sInf hq
  have hc : ¬ (1 ≤ (4 : ℝ) ^ (q - 1) * (a / (8 * (q : ℝ))) ^ 2) := fun h => hn ⟨hq2, h⟩
  rw [valPCond_iff ha.le (by omega)] at hc
  exact not_le.mp hc

/-- `p ≥ 3` for `a < 8` (`p = 2` would need `a ≥ 8`). -/
theorem three_le_valP {a : ℝ} (ha : 0 < a) (ha8 : a < 8) : 3 ≤ valP a := by
  by_contra hcon
  have hp2 := two_le_valP ha
  have hc := valP_cond ha
  have hp : valP a = 2 := by omega
  rw [hp] at hc
  norm_num at hc
  linarith

/-- `p ≥ 12` for `a ≤ 1/16` (for `a = 1/16` one gets exactly `p = 12`). -/
theorem twelve_le_valP {a : ℝ} (ha : 0 < a) (ha16 : a ≤ 1 / 16) : 12 ≤ valP a := by
  by_contra hcon
  have hp2 := two_le_valP ha
  have hc := valP_cond ha
  obtain ⟨p, hp⟩ : ∃ p, valP a = p := ⟨_, rfl⟩
  rw [hp] at hc hp2 hcon
  have h2 : (2 : ℝ) ^ (p - 1) * a ≤ 2 ^ (p - 1) * (1 / 16) := by gcongr
  have hp11 : p ≤ 11 := by omega
  interval_cases p <;> norm_num at hc h2 <;> linarith

/-- Minimality in the form `2^{p-2} a < 8(p-1)` (for `a < 8`, so that `p - 1 ≥ 2`). -/
theorem two_pow_valP_sub_two_lt {a : ℝ} (ha : 0 < a) (ha8 : a < 8) :
    2 ^ (valP a - 2) * a < 8 * ((valP a : ℝ) - 1) := by
  have hp3 := three_le_valP ha ha8
  have h := cond_fails_of_lt_valP ha (q := valP a - 1) (by omega) (by omega)
  have e1 : valP a - 1 - 1 = valP a - 2 := by omega
  have e2 : ((valP a - 1 : ℕ) : ℝ) = (valP a : ℝ) - 1 := by
    rw [Nat.cast_sub (by omega)]
    simp
  rw [e1, e2] at h
  exact h

/-- `2^p a < 32 p` (minimality of `p`, for `a < 8`). -/
theorem two_pow_valP_mul_lt {a : ℝ} (ha : 0 < a) (ha8 : a < 8) :
    2 ^ valP a * a < 32 * (valP a : ℝ) := by
  have hp3 := three_le_valP ha ha8
  have h := two_pow_valP_sub_two_lt ha ha8
  have e : (2 : ℝ) ^ valP a = 4 * 2 ^ (valP a - 2) := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, ← pow_add]
    congr 1
    omega
  rw [e]
  nlinarith

/-- `2^p < 32 p / a`. -/
theorem two_pow_valP_lt {a : ℝ} (ha : 0 < a) (ha8 : a < 8) :
    (2 : ℝ) ^ valP a < 32 * (valP a : ℝ) / a := by
  rw [lt_div_iff₀ ha]
  exact two_pow_valP_mul_lt ha ha8

/-- `p ≤ 2⌈log₂(1/a)⌉ + 4` for `0 < a ≤ 1/16`. -/
theorem valP_le_two_mul_dyadicExp_add_four {a : ℝ} (ha : 0 < a) (ha16 : a ≤ 1 / 16) :
    valP a ≤ 2 * dyadicExp a + 4 := by
  have hk := four_le_dyadicExp ha (by linarith)
  apply valP_le_of_mem
  refine mem_valPSet_of_two_pow ha (two_pow_dyadicExp_inv_le ha) (by omega) (by omega) ?_
  have e : 2 * dyadicExp a + 4 - 1 - dyadicExp a = dyadicExp a + 3 := by omega
  rw [e, pow_add]
  have := two_mul_add_four_le_two_pow hk
  generalize 2 ^ dyadicExp a = t at *
  omega

/-- `p ≤ 2^{⌈log₂(1/a)⌉}` for `0 < a ≤ 1/16`. -/
theorem valP_le_two_pow_dyadicExp {a : ℝ} (ha : 0 < a) (ha16 : a ≤ 1 / 16) :
    valP a ≤ 2 ^ dyadicExp a :=
  (valP_le_two_mul_dyadicExp_add_four ha ha16).trans
    (two_mul_add_four_le_two_pow (four_le_dyadicExp ha (by linarith)))

/-! ### `τ` and `h` -/

theorem valTau_eq (a : ℝ) : valTau a = a / (8 * (valP a : ℝ)) := rfl

theorem valH_eq (a : ℝ) : valH a = a / (512 * (valP a : ℝ)) := by
  unfold valH valTau
  rw [div_div, mul_comm (8 * (valP a : ℝ)) 64, ← mul_assoc]
  norm_num

theorem valTau_pos {a : ℝ} (ha : 0 < a) : 0 < valTau a := by
  have := valP_pos ha
  unfold valTau
  positivity

theorem valH_pos {a : ℝ} (ha : 0 < a) : 0 < valH a := by
  unfold valH
  have := valTau_pos ha
  positivity

/-- `1/τ = 8p/a`. -/
theorem one_div_valTau (a : ℝ) : 1 / valTau a = 8 * (valP a : ℝ) / a := by
  unfold valTau
  rw [one_div_div]

/-- `1/h = 512p/a`. -/
theorem one_div_valH (a : ℝ) : 1 / valH a = 512 * (valP a : ℝ) / a := by
  rw [valH_eq, one_div_div]

/-- `1/τ² = 64p²/a²`. -/
theorem one_div_valTau_sq (a : ℝ) : 1 / valTau a ^ 2 = 64 * (valP a : ℝ) ^ 2 / a ^ 2 := by
  rw [one_div, ← inv_pow, ← one_div, one_div_valTau a]
  ring

/-- `p τ = a/8`. -/
theorem valP_mul_valTau {a : ℝ} (ha : 0 < a) : (valP a : ℝ) * valTau a = a / 8 := by
  have := valP_pos ha
  have hp : (0 : ℝ) < valP a := by exact_mod_cast this
  unfold valTau
  field_simp

/-- `h = τ/64`. -/
theorem valH_eq_valTau_div (a : ℝ) : valH a = valTau a / 64 := rfl

theorem valTau_le {a : ℝ} (ha : 0 < a) : valTau a ≤ a / 16 := by
  have hp := two_le_valP_real ha
  unfold valTau
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith

theorem valH_le {a : ℝ} (ha : 0 < a) : valH a ≤ a / 1024 := by
  have := valTau_le ha
  unfold valH
  linarith

theorem valH_lt_valTau {a : ℝ} (ha : 0 < a) : valH a < valTau a := by
  have := valTau_pos ha
  unfold valH
  linarith

theorem valH_le_one {a : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) : valH a ≤ 1 := by
  have := valH_le ha
  linarith

/-! ### The minimality window `1 ≤ 4^{p-1}τ² < 4` -/

/-- `1 ≤ 4^{p-1}τ²`. -/
theorem one_le_four_pow_valTau_sq {a : ℝ} (ha : 0 < a) :
    1 ≤ (4 : ℝ) ^ (valP a - 1) * valTau a ^ 2 :=
  (valP_mem ha).2

/-- `4^{p-1}τ² < 4` (minimality of `p`; needs `a < 8`). -/
theorem four_pow_valTau_sq_lt_four {a : ℝ} (ha : 0 < a) (ha8 : a < 8) :
    (4 : ℝ) ^ (valP a - 1) * valTau a ^ 2 < 4 := by
  have hp3 := three_le_valP ha ha8
  have hp : (3 : ℝ) ≤ valP a := by exact_mod_cast hp3
  have h := two_pow_valP_sub_two_lt ha ha8
  rw [valTau_eq, valPCond_eq_sq]
  have e : (2 : ℝ) ^ (valP a - 1) = 2 * 2 ^ (valP a - 2) := by
    rw [← pow_succ']
    congr 1
    omega
  have hy0 : 0 ≤ 2 ^ (valP a - 1) * a / (8 * (valP a : ℝ)) := by positivity
  have hy2 : 2 ^ (valP a - 1) * a / (8 * (valP a : ℝ)) < 2 := by
    rw [div_lt_iff₀ (by positivity), e]
    nlinarith
  nlinarith

/-- `4^j τ² < 4` for `j < p`. -/
theorem four_pow_valTau_sq_lt_four_of_lt {a : ℝ} (ha : 0 < a) (ha8 : a < 8) {j : ℕ}
    (hj : j < valP a) : (4 : ℝ) ^ j * valTau a ^ 2 < 4 := by
  have h := four_pow_valTau_sq_lt_four ha ha8
  have hle : (4 : ℝ) ^ j ≤ 4 ^ (valP a - 1) := pow_le_pow_right₀ (by norm_num) (by omega)
  have hτ : 0 < valTau a ^ 2 := by have := valTau_pos ha; positivity
  calc (4 : ℝ) ^ j * valTau a ^ 2 ≤ 4 ^ (valP a - 1) * valTau a ^ 2 := by gcongr
    _ < 4 := h

/-- `v = 4^{-j}τ^{-2} > 1/4` for `j < p` (Theorem `R:thm:validation_ada`, proof, "Counts"). -/
theorem quarter_lt_inv_four_pow_valTau_sq {a : ℝ} (ha : 0 < a) (ha8 : a < 8) {j : ℕ}
    (hj : j < valP a) : 1 / 4 < 1 / ((4 : ℝ) ^ j * valTau a ^ 2) := by
  have h := four_pow_valTau_sq_lt_four_of_lt ha ha8 hj
  have hpos : 0 < (4 : ℝ) ^ j * valTau a ^ 2 := by have := valTau_pos ha; positivity
  exact one_div_lt_one_div_of_lt hpos h

/-! ### `T_j^max` -/

theorem valTmax_eq (a : ℝ) (j : ℕ) : valTmax a j = ⌈6 / ((4 : ℝ) ^ j * valTau a ^ 2)⌉₊ := rfl

theorem le_valTmax (a : ℝ) (j : ℕ) : 6 / ((4 : ℝ) ^ j * valTau a ^ 2) ≤ valTmax a j :=
  Nat.le_ceil _

/-- `T_j^max < 6/(4^jτ²) + 1`. -/
theorem valTmax_lt (a : ℝ) (j : ℕ) : (valTmax a j : ℝ) < 6 / ((4 : ℝ) ^ j * valTau a ^ 2) + 1 :=
  Nat.ceil_lt_add_one (by positivity)

theorem valTmax_le (a : ℝ) (j : ℕ) : (valTmax a j : ℝ) ≤ 6 / ((4 : ℝ) ^ j * valTau a ^ 2) + 1 :=
  (valTmax_lt a j).le

theorem one_le_valTmax {a : ℝ} (ha : 0 < a) (j : ℕ) : 1 ≤ valTmax a j := by
  have hpos : 0 < 6 / ((4 : ℝ) ^ j * valTau a ^ 2) := by have := valTau_pos ha; positivity
  exact Nat.one_le_iff_ne_zero.mpr (Nat.ceil_pos.mpr hpos).ne'

/-- `T_j^max ≤ 6·4^{p-1-j}` for `j < p`. -/
theorem valTmax_le_six_mul_four_pow {a : ℝ} (ha : 0 < a) {j : ℕ} (hj : j < valP a) :
    valTmax a j ≤ 6 * 4 ^ (valP a - 1 - j) := by
  apply Nat.ceil_le.mpr
  have h1 := one_le_four_pow_valTau_sq ha
  have hpos : 0 < (4 : ℝ) ^ j * valTau a ^ 2 := by have := valTau_pos ha; positivity
  rw [div_le_iff₀ hpos]
  have e : (4 : ℝ) ^ (valP a - 1) = 4 ^ (valP a - 1 - j) * 4 ^ j := by
    rw [← pow_add]
    congr 1
    omega
  push_cast
  rw [e] at h1
  nlinarith

/-- `T_{p-1}^max ≤ 6`. -/
theorem valTmax_pred_le {a : ℝ} (ha : 0 < a) : valTmax a (valP a - 1) ≤ 6 := by
  have hp := two_le_valP ha
  have h := valTmax_le_six_mul_four_pow ha (j := valP a - 1) (by omega)
  have e : valP a - 1 - (valP a - 1) = 0 := by omega
  rw [e] at h
  simpa using h

/-- `T_{p-2}^max ≤ 24`. -/
theorem valTmax_pred_pred_le {a : ℝ} (ha : 0 < a) : valTmax a (valP a - 2) ≤ 24 := by
  have hp := two_le_valP ha
  have h := valTmax_le_six_mul_four_pow ha (j := valP a - 2) (by omega)
  have e : valP a - 1 - (valP a - 2) = 1 := by omega
  rw [e] at h
  simpa using h

/-- `∑_{j<n} 4^{-j} < 4/3`. -/
theorem sum_inv_four_pow_lt (n : ℕ) : ∑ j ∈ Finset.range n, ((1 : ℝ) / 4) ^ j < 4 / 3 := by
  rw [geom_sum_eq (by norm_num) n]
  have h : (0 : ℝ) < (1 / 4) ^ n := by positivity
  rw [div_lt_iff_of_neg (by norm_num)]
  linarith

/-- `∑_{j<p} T_j^max ≤ 8τ^{-2} + p` (used in the paper's `O`-form of `χ`). -/
theorem sum_valTmax_le {a : ℝ} (ha : 0 < a) :
    (∑ j ∈ Finset.range (valP a), (valTmax a j : ℝ)) ≤ 8 / valTau a ^ 2 + valP a := by
  have hτ : 0 < valTau a ^ 2 := by have := valTau_pos ha; positivity
  have h1 : ∀ j ∈ Finset.range (valP a),
      (valTmax a j : ℝ) ≤ 6 / valTau a ^ 2 * ((1 : ℝ) / 4) ^ j + 1 := by
    intro j _
    have := valTmax_le a j
    have e : 6 / ((4 : ℝ) ^ j * valTau a ^ 2) = 6 / valTau a ^ 2 * ((1 : ℝ) / 4) ^ j := by
      rw [div_pow, one_pow]
      field_simp
    linarith
  calc (∑ j ∈ Finset.range (valP a), (valTmax a j : ℝ))
      ≤ ∑ j ∈ Finset.range (valP a), (6 / valTau a ^ 2 * ((1 : ℝ) / 4) ^ j + 1) :=
        Finset.sum_le_sum h1
    _ = 6 / valTau a ^ 2 * ∑ j ∈ Finset.range (valP a), ((1 : ℝ) / 4) ^ j + valP a := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum]
        simp
    _ ≤ 6 / valTau a ^ 2 * (4 / 3) + valP a := by
        have := sum_inv_four_pow_lt (valP a)
        have h6 : 0 ≤ 6 / valTau a ^ 2 := by positivity
        nlinarith
    _ = 8 / valTau a ^ 2 + valP a := by ring

/-! ### `Q` -/

theorem valQ_cast (M J R : ℕ) (a : ℝ) :
    (valQ M J R a : ℝ) = 100 * ((valP a : ℝ) + 1) *
      ((M : ℝ) + R + J + 2 + ∑ j ∈ Finset.range (valP a), (valTmax a j : ℝ)) := by
  unfold valQ
  push_cast
  ring

/-- `Q ≥ 600`. -/
theorem six_hundred_le_valQ (M J R : ℕ) {a : ℝ} (ha : 0 < a) : 600 ≤ valQ M J R a := by
  have hp := two_le_valP ha
  unfold valQ
  have h1 : 300 ≤ 100 * (valP a + 1) := by omega
  have h2 : 2 ≤ M + R + J + 2 + ∑ j ∈ Finset.range (valP a), valTmax a j := by omega
  calc 600 = 300 * 2 := by norm_num
    _ ≤ 100 * (valP a + 1) * (M + R + J + 2 + ∑ j ∈ Finset.range (valP a), valTmax a j) :=
        Nat.mul_le_mul h1 h2

theorem valQ_pos (M J R : ℕ) {a : ℝ} (ha : 0 < a) : 0 < valQ M J R a := by
  have := six_hundred_le_valQ M J R ha
  omega

/-- `Q ≤ 100(p+1)(M+J+R+2+8τ^{-2}+p)`. -/
theorem valQ_le (M J R : ℕ) {a : ℝ} (ha : 0 < a) :
    (valQ M J R a : ℝ) ≤
      100 * ((valP a : ℝ) + 1) * ((M : ℝ) + J + R + 2 + 8 / valTau a ^ 2 + valP a) := by
  rw [valQ_cast]
  have h := sum_valTmax_le ha
  have hp : (0 : ℝ) ≤ 100 * ((valP a : ℝ) + 1) := by positivity
  have h2 : (M : ℝ) + R + J + 2 + ∑ j ∈ Finset.range (valP a), (valTmax a j : ℝ) ≤
      (M : ℝ) + J + R + 2 + 8 / valTau a ^ 2 + valP a := by linarith
  exact mul_le_mul_of_nonneg_left h2 hp

/-! ### `χ` -/

/-- The argument `2^40 (p+1) Q/(h ξ_A)` of `log₂` in `χ`. -/
noncomputable def chiArg (M J R : ℕ) (a ξA : ℝ) : ℝ :=
  2 ^ 40 * ((valP a : ℝ) + 1) * (valQ M J R a : ℝ) / (valH a * ξA)

theorem valChi_eq (M J R : ℕ) (a ξA : ℝ) :
    valChi M J R a ξA = ⌈Real.logb 2 (chiArg M J R a ξA)⌉₊ := rfl

theorem chiArg_pos (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (hξ : 0 < ξA) : 0 < chiArg M J R a ξA := by
  have := valQ_pos M J R ha
  have := valH_pos ha
  unfold chiArg
  positivity

/-- `2^40 · 1800 · (512p/a) ≤ 2^40 (p+1) Q/(h ξ_A)` for `0 < ξ_A ≤ 1`. -/
theorem chiArg_ge (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (hξ0 : 0 < ξA) (hξ1 : ξA ≤ 1) :
    2 ^ 40 * 1800 * (512 * (valP a : ℝ) / a) ≤ chiArg M J R a ξA := by
  have hp := two_le_valP_real ha
  have hQ : (600 : ℝ) ≤ valQ M J R a := by exact_mod_cast six_hundred_le_valQ M J R ha
  have hh := valH_pos ha
  have h1 : (1800 : ℝ) ≤ ((valP a : ℝ) + 1) * (valQ M J R a : ℝ) := by nlinarith
  have hinvh : 1 / valH a = 512 * (valP a : ℝ) / a := one_div_valH a
  have hξ' : 1 ≤ 1 / ξA := by rw [le_div_iff₀ hξ0]; linarith
  have e : chiArg M J R a ξA =
      2 ^ 40 * (((valP a : ℝ) + 1) * (valQ M J R a : ℝ)) * (1 / valH a) * (1 / ξA) := by
    unfold chiArg
    field_simp
  rw [e, hinvh]
  have hpa : 0 ≤ 512 * (valP a : ℝ) / a := by positivity
  calc 2 ^ 40 * 1800 * (512 * (valP a : ℝ) / a)
      = 2 ^ 40 * 1800 * (512 * (valP a : ℝ) / a) * 1 := by ring
    _ ≤ 2 ^ 40 * (((valP a : ℝ) + 1) * (valQ M J R a : ℝ)) * (512 * (valP a : ℝ) / a) *
        (1 / ξA) := by gcongr

/-- `2^60 < 2^40 (p+1) Q/(h ξ_A)` for `0 < a ≤ 1`, `0 < ξ_A ≤ 1`. -/
theorem two_pow_sixty_lt_chiArg (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hξ0 : 0 < ξA)
    (hξ1 : ξA ≤ 1) : (2 : ℝ) ^ 60 < chiArg M J R a ξA := by
  have h := chiArg_ge M J R ha hξ0 hξ1
  have hp := two_le_valP_real ha
  have h2 : (1024 : ℝ) ≤ 512 * (valP a : ℝ) / a := by
    rw [le_div_iff₀ ha]
    nlinarith
  have h3 : (2 : ℝ) ^ 60 < 2 ^ 40 * 1800 * 1024 := by norm_num
  have h4 : (2 : ℝ) ^ 40 * 1800 * 1024 ≤ 2 ^ 40 * 1800 * (512 * (valP a : ℝ) / a) := by
    gcongr
  linarith

/-- `arg ≤ 2^χ`. -/
theorem chiArg_le_two_pow_valChi (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (hξ : 0 < ξA) :
    chiArg M J R a ξA ≤ 2 ^ valChi M J R a ξA := by
  have hpos := chiArg_pos M J R ha hξ
  have h : Real.logb 2 (chiArg M J R a ξA) ≤ valChi M J R a ξA := Nat.le_ceil _
  rw [Real.logb_le_iff_le_rpow (by norm_num) hpos, Real.rpow_natCast] at h
  exact h

/-- `2^{-χ} ≤ h ξ_A/(2^40 (p+1) Q)`. -/
theorem inv_two_pow_valChi_le (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (hξ : 0 < ξA) :
    ((2 : ℝ) ^ valChi M J R a ξA)⁻¹ ≤
      valH a * ξA / (2 ^ 40 * ((valP a : ℝ) + 1) * (valQ M J R a : ℝ)) := by
  have h := chiArg_le_two_pow_valChi M J R ha hξ
  have hpos := chiArg_pos M J R ha hξ
  have e : valH a * ξA / (2 ^ 40 * ((valP a : ℝ) + 1) * (valQ M J R a : ℝ)) =
      (chiArg M J R a ξA)⁻¹ := by
    unfold chiArg
    rw [inv_div]
  rw [e]
  exact inv_anti₀ hpos h

/-- `χ < log₂ arg + 1` (when `arg ≥ 1`). -/
theorem valChi_lt_logb_add_one (M J R : ℕ) {a ξA : ℝ} (h1 : 1 ≤ chiArg M J R a ξA) :
    (valChi M J R a ξA : ℝ) < Real.logb 2 (chiArg M J R a ξA) + 1 :=
  Nat.ceil_lt_add_one (Real.logb_nonneg (by norm_num) h1)

/-- `χ > 60` (in particular `χ > 40`) for `0 < a ≤ 1`, `0 < ξ_A ≤ 1`. -/
theorem sixty_lt_valChi (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hξ0 : 0 < ξA)
    (hξ1 : ξA ≤ 1) : 60 < valChi M J R a ξA := by
  have h := two_pow_sixty_lt_chiArg M J R ha ha1 hξ0 hξ1
  have h2 := chiArg_le_two_pow_valChi M J R ha hξ0
  have h3 : (2 : ℝ) ^ 60 < 2 ^ valChi M J R a ξA := lt_of_lt_of_le h h2
  exact (pow_lt_pow_iff_right₀ (by norm_num : (1 : ℝ) < 2)).mp h3

theorem forty_lt_valChi (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hξ0 : 0 < ξA)
    (hξ1 : ξA ≤ 1) : 40 < valChi M J R a ξA := by
  have := sixty_lt_valChi M J R ha ha1 hξ0 hξ1
  omega

theorem one_le_valChi (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hξ0 : 0 < ξA)
    (hξ1 : ξA ≤ 1) : 1 ≤ valChi M J R a ξA := by
  have := sixty_lt_valChi M J R ha ha1 hξ0 hξ1
  omega

/-- `p < χ` for `0 < a ≤ 1`, `0 < ξ_A ≤ 1` (the paper's "`p = O(χ)`"): `2^p < 32p/a < arg ≤ 2^χ`. -/
theorem valP_lt_valChi (M J R : ℕ) {a ξA : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hξ0 : 0 < ξA)
    (hξ1 : ξA ≤ 1) : valP a < valChi M J R a ξA := by
  have h1 := two_pow_valP_lt ha (by linarith)
  have h2 := chiArg_ge M J R ha hξ0 hξ1
  have h3 := chiArg_le_two_pow_valChi M J R ha hξ0
  have hp := two_le_valP_real ha
  have h4 : 32 * (valP a : ℝ) / a ≤ 2 ^ 40 * 1800 * (512 * (valP a : ℝ) / a) := by
    rw [mul_div_assoc, mul_div_assoc]
    have : 0 ≤ (valP a : ℝ) / a := by positivity
    nlinarith
  have h5 : (2 : ℝ) ^ valP a < 2 ^ valChi M J R a ξA := by linarith
  exact (pow_lt_pow_iff_right₀ (by norm_num : (1 : ℝ) < 2)).mp h5

end F2e2e.B
