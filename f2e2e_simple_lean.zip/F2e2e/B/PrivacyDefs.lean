import F2e2e.Lib.Discrete.DrawProg
import F2e2e.Lib.Discrete.Lattice

/-!
# Theorem `R:thm:validation_ada`, privacy pillars (P2)–(P4): definitions

Paper: `parts/partII.tex` L986–1032 (one-phase privacy (P2), concurrent composition (P3), sampler
coupling (P4)); `notes/PAPER_MAP_II_b.md` §II.3.6, external inputs 10–22.

## The model
The interaction of Algorithm 2 with a fixed deterministic controller is written as a **data-oblivious
skeleton** `E : OProg S P ℤ (SQuery I) SResp α`: a program that makes draws (randomness of the
mechanism, interpreted by the ideal lattice laws `L : P → PMF ℤ` or by the bounded samplers) and calls
**stream oracles** `s : S` (the internal edge streams, the outer validation stream, the numerical
stream). Every access to the sample happens inside an oracle, through the oracle's
`StreamSpec` (`gap`, `center`: functions of the information `i : I` sent with the query — the current
query `f`, the protected command history, … — and of the data). A stream oracle is a persistent
two-sided priority AboveThreshold mechanism with lattice noise (`partII.tex` L750, L760–764,
L769–771) that can also make one-shot lattice releases (L775):
* state `Option ℤ`: the lattice index `t` of the persistent threshold of the open phase, or closed;
* `reopen`: draw a fresh threshold index `t ~ L pT` (a new phase);
* `test i`: if open with threshold `t`, draw `np, nm ~ L pQ`; with `(g₊, g₋) = gap i x`:
  cross with sign `+` iff `c + h t ≤ g₊ + h np` (the positive branch has priority), else cross with
  sign `−` iff `c + h t ≤ g₋ + h nm`, else accept; a crossing closes the phase; if closed, answer
  `closed` (no draw, no data access);
* `release i`: draw `n ~ L pR` and return the lattice index `center i x + n` (a phase of its own; the
  rounding shift `round_h(μ + h n) = round_h(μ) + h n` of L994–997 turns the numerical release into
  this form).
`inlineAll sp x E σ` runs `E` with stream `s` reading the data `x s`: the ideal law of the mechanism
is `DrawProg.interp L (inlineAll sp (fun _ => D) E (fun _ => none))`.

Phases: a phase of stream `s` starts at each `reopen` or `release` call (`SQuery.isStart`);
`E.StartsLE s C` bounds their number on every path (the counts `C_j` of (P1)).

`PIndist p q ε δ` is `(ε, δ)`-indistinguishability of discrete laws for **all** events.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete

/-! ## Oracle programs -/

/-- Programs with draws (law parameter `p : P`, outcome in `β`) and oracle calls (oracle `s : S`,
query `Q`, response `R`): the free monad over the two effects. -/
inductive OProg (S P β Q R α : Type) : Type where
  /-- return a value -/
  | ret : α → OProg S P β Q R α
  /-- draw an outcome from the law with parameter `p` and continue -/
  | draw : P → (β → OProg S P β Q R α) → OProg S P β Q R α
  /-- call the oracle `s` with query `q` and continue with its response -/
  | call : S → Q → (R → OProg S P β Q R α) → OProg S P β Q R α

namespace OProg

variable {S P β Q R α γ : Type}

/-- Sequential composition. -/
def bind : OProg S P β Q R α → (α → OProg S P β Q R γ) → OProg S P β Q R γ
  | ret a, f => f a
  | draw p k, f => draw p fun b => bind (k b) f
  | call s q k, f => call s q fun r => bind (k r) f

/-- A program with draws only, as an oracle program. -/
def ofDraw : DrawProg P β α → OProg S P β Q R α
  | .ret a => ret a
  | .draw p k => draw p fun b => ofDraw (k b)

end OProg

/-! ## Stream oracles -/

/-- Queries to a stream oracle (with information of type `I`). -/
inductive SQuery (I : Type) : Type where
  /-- a directed two-sided AboveThreshold test; the oracle computes the gaps from `i` and its data -/
  | test : I → SQuery I
  /-- close the current phase (if any) and open a new one: draw a fresh persistent threshold -/
  | reopen : SQuery I
  /-- a one-shot lattice release; the oracle computes the center from `i` and its data -/
  | release : I → SQuery I

/-- The phase-starting queries (`reopen`, `release`). -/
def SQuery.isStart {I : Type} : SQuery I → Bool
  | .test _ => false
  | .reopen => true
  | .release _ => true

/-- Responses of a stream oracle. -/
inductive SResp : Type where
  /-- both directed tests stayed below the threshold; the phase stays open -/
  | accept : SResp
  /-- a crossing with sign `pos` (`true` = positive branch); the phase closes -/
  | cross : Bool → SResp
  /-- a test while no phase is open -/
  | closed : SResp
  /-- acknowledgment of a `reopen` -/
  | opened : SResp
  /-- the released lattice index -/
  | value : ℤ → SResp

/-- The parameters of one stream oracle reading data of type `X`: law parameters (noise scales) of
the threshold, test and release noises, the lattice step `h`, the threshold offset `c`, and the
data-dependent directed gaps and release centers. -/
structure StreamSpec (I X P : Type) where
  /-- law parameter of the persistent threshold noise (scale `2b`) -/
  pT : P
  /-- law parameter of the directed test noises (scale `4b`) -/
  pQ : P
  /-- law parameter of the release noise -/
  pR : P
  /-- lattice step `h_A` -/
  h : ℚ
  /-- threshold offset (`τ` for an internal edge, `a/2` for the outer validator) -/
  c : ℚ
  /-- the directed gaps `(g₊, g₋)` of a test -/
  gap : I → X → ℚ × ℚ
  /-- the lattice index of the (rounded) center of a release -/
  center : I → X → ℤ

namespace StreamSpec

variable {I X Dt P : Type}

/-- One step of the stream oracle reading the data `x`, from the state `σ` (threshold index of the
open phase, or `none`), on the query `q`. -/
def step (sp : StreamSpec I X P) (x : X) : Option ℤ → SQuery I → DrawProg P ℤ (SResp × Option ℤ)
  | _, .reopen => .draw sp.pT fun t => .ret (.opened, some t)
  | _, .release i => .draw sp.pR fun n => .ret (.value (sp.center i x + n), none)
  | none, .test _ => .ret (.closed, none)
  | some t, .test i => .draw sp.pQ fun np => .draw sp.pQ fun nm =>
      .ret (if sp.c + sp.h * t ≤ (sp.gap i x).1 + sp.h * np then (.cross true, none)
        else if sp.c + sp.h * t ≤ (sp.gap i x).2 + sp.h * nm then (.cross false, none)
        else (.accept, some t))

/-- The same oracle reading data of type `X` through `f : X → Dt` (e.g. `f = upd D`: the selected
block replaced, the other blocks fixed to those of `D`). -/
def restrict (sp : StreamSpec I Dt P) (f : X → Dt) : StreamSpec I X P where
  pT := sp.pT
  pQ := sp.pQ
  pR := sp.pR
  h := sp.h
  c := sp.c
  gap i x := sp.gap i (f x)
  center i x := sp.center i (f x)

/-- **Per-phase shift conditions** making every phase of the oracle `ρ`-DP (in both directions) for
`Adj`-related data — the injective noise shift of (P2) (`partII.tex` L990): directed gaps move by at
most `h d`, release centers by at most `dR` lattice steps, and shifting the threshold noise by up to
`d`, a test noise by up to `2d`, a release noise by up to `dR` lattice steps costs the factors `cT`,
`cQ`, `cR`, with `cT cQ ≤ e^ρ` (a phase pays one threshold shift and at most one crossing) and
`cR ≤ e^ρ`. -/
def PhaseDP (L : P → PMF ℤ) (Adj : X → X → Prop) (sp : StreamSpec I X P) (ρ : ℝ) : Prop :=
  0 < sp.h ∧ ∃ (d dR : ℕ) (cT cQ cR : ENNReal),
    (∀ i x x', Adj x x' → |(sp.gap i x).1 - (sp.gap i x').1| ≤ sp.h * d ∧
      |(sp.gap i x).2 - (sp.gap i x').2| ≤ sp.h * d) ∧
    (∀ i x x', Adj x x' → |sp.center i x - sp.center i x'| ≤ dR) ∧
    (∀ t m : ℤ, m.natAbs ≤ d → L sp.pT t ≤ cT * L sp.pT (t + m)) ∧
    (∀ t m : ℤ, m.natAbs ≤ 2 * d → L sp.pQ t ≤ cQ * L sp.pQ (t + m)) ∧
    (∀ t m : ℤ, m.natAbs ≤ dR → L sp.pR t ≤ cR * L sp.pR (t + m)) ∧
    cT * cQ ≤ ENNReal.ofReal (Real.exp ρ) ∧ cR ≤ ENNReal.ofReal (Real.exp ρ)

end StreamSpec

/-! ## Running a skeleton with the stream oracles -/

section Inline

variable {S I X P α : Type} [DecidableEq S]

/-- Run the skeleton `E` with stream `s` reading the data `x s`, from the oracle states `σ`: every
call is replaced by the oracle's step; the result has draws only. -/
def inlineAll (sp : S → StreamSpec I X P) (x : S → X) :
    OProg S P ℤ (SQuery I) SResp α → (S → Option ℤ) → DrawProg P ℤ α
  | .ret a, _ => .ret a
  | .draw p k, σ => .draw p fun y => inlineAll sp x (k y) σ
  | .call s q k, σ => ((sp s).step (x s) (σ s) q).bind fun r =>
      inlineAll sp x (k r.1) (Function.update σ s r.2)

end Inline

/-- At most `n` phase starts (`reopen`/`release` calls) of stream `s` on every path. -/
def OProg.StartsLE {S P β I R α : Type} [DecidableEq S] (s : S) :
    OProg S P β (SQuery I) R α → ℕ → Prop
  | .ret _, _ => True
  | .draw _ k, n => ∀ y, OProg.StartsLE s (k y) n
  | .call s' q k, n =>
      if s' = s ∧ q.isStart = true then 0 < n ∧ ∀ r, OProg.StartsLE s (k r) (n - 1)
      else ∀ r, OProg.StartsLE s (k r) n

/-! ## Indistinguishability of discrete laws -/

/-- `(ε, δ)`-indistinguishability of the discrete laws `p`, `q` for all events:
`p(E) ≤ e^ε q(E) + δ`. -/
def PIndist {α : Type*} (p q : PMF α) (ε δ : ℝ) : Prop :=
  ∀ E : Set α, p.toOuterMeasure E ≤ ENNReal.ofReal (Real.exp ε) * q.toOuterMeasure E +
    ENNReal.ofReal δ

end F2e2e.B.Priv
