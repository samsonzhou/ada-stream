import F2e2e.B.AccuracyTail
import F2e2e.B.ArchCount
import F2e2e.B.Comparator.Main

/-!
# Theorem `R:thm:validation_ada` (P5): the comparator event ("Transfer")

Paper: `parts/partII.tex` L1034 ("The second term of `R:eq:sec3_nj_formula` dominates the sample condition of
Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` at privacy `ϑ_j` and failure `ξ_j`, with
`δ ≤ hξ_j/24`: indeed `e^{2ϑ_j} < 8`, and all required logarithms are at most `χ`. A union bound over blocks
gives the comparator event with failure at most `ξ_A/8`.").

Instance of `F2e2e.Comparator.posterior_comparator` for block `j ≤ p`, with the other blocks fixed:
* `r = n_j`, `X = S_j`; coins `Ω = Fin c → Bool` with uniform weights (`tapeW`), the fair bits of the online
  execution;
* transcript `blockTranscript`: the output history of the online execution on the sample with block `j`
  replaced by `x`, on the tape `ω` (type `Option (List CoreOut)`);
* queries `candQuery`: the `k = M + R` candidate queries `f̂ = h_A f` (first `M` interval requests, first `R`
  numerical requests) read off the transcript;
* `θ = ϑ_j = 1/d_j`, `ξ = ξ_j = ξ_A/(8(p+1))`, `δ = hξ_j/24`, `h = τ/64`; the DP hypothesis is `CoreBlockDP`
  (input from (P2)–(P4)), transported to the uniform tapes.

Results: `blockComparators_admissible` (part (i), with `ϑ_j ≤ θ_j`) and `comp_fail_le` (part (ii) for every block
and the union bound: the comparators fail on some candidate query with probability `≤ (p+1) ξ_j = ξ_A/8`).
-/

namespace F2e2e.B

open F2e2e.Discrete

/-- Uniform weights `2^{-c}` on the tapes `Fin c → Bool`. -/
noncomputable def tapeW (c : ℕ) : (Fin c → Bool) → ℝ := fun _ => ((1 : ℝ) / 2) ^ c

/-- The transcript of block `j` (Theorem II.2.9's mechanism `T`): the output history of the online execution
on the sample `s` with block `j` replaced by `x`, on the tape `ω`. -/
def blockTranscript {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) (T j : ℕ)
    (x : Fin (blockN P j) → U) (ω : Fin (adaCoins P) → Bool) : Option (List CoreOut) :=
  ((coreRun P ctrl (withBlock P s j x) T).run (List.ofFn ω)).map Prod.fst

/-- The round of the `i`-th candidate request of the output history `o`: the `i`-th interval request for
`i < M`, the `(i − M)`-th numerical request for `i ≥ M` (if it exists). -/
def candRound {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (i : ℕ) : Option ℕ :=
  if i < P.M then ((List.range o.length).filter fun t => (coreReqAt ctrl o t).isInterval)[i]?
  else ((List.range o.length).filter fun t => !(coreReqAt ctrl o t).isInterval)[i - P.M]?

/-- The candidate queries (Theorem II.2.9's `q`, `k = M + R`): the grid-valued query `f̂ = h_A f` of the
`i`-th candidate request (`0` if there is none). -/
noncomputable def candQuery {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) :
    Option (List CoreOut) → Fin (P.M + P.R) → U → ℝ
  | none, _ => fun _ => 0
  | some o, i =>
    match candRound P ctrl o i with
    | some t => fun x => (P.hA : ℝ) * (coreReqAt ctrl o t).f x
    | none => fun _ => 0

open Classical in
/-- The comparator `u_j` of block `j` for the realization (sample `s`, output history `o`)
(Definition `R:def:posterior_comparator`, `R:eq:u_i_def`). -/
noncomputable def blockComparator {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (ctrl : CoreCtrl U)
    (T : ℕ) (aReq : ℝ) (s : Fin P.N → U) (j : ℕ) (o : List CoreOut) : Fin (blockN P j) → ℝ :=
  Comparator.comparator D (tapeW (adaCoins P)) (blockTranscript P ctrl s T j) (accVartheta aReq j)
    (sampleBlock P s j) (some o)

/-! ## Helpers -/

theorem accComp_tapeW_nonneg (c : ℕ) (ω : Fin c → Bool) : 0 ≤ tapeW c ω := by
  unfold tapeW; positivity

theorem accComp_tapeW_sum (c : ℕ) : ∑ ω : Fin c → Bool, tapeW c ω = 1 := by
  unfold tapeW
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin,
    nsmul_eq_mul]
  push_cast
  rw [← mul_pow]
  norm_num

open Classical in
theorem accComp_coinProb_nonneg {c : ℕ} (A : (Fin c → Bool) → Prop) :
    0 ≤ Comparator.coinProb (tapeW c) A := by
  unfold Comparator.coinProb
  exact Finset.sum_nonneg fun ω _ => by split_ifs; exacts [accComp_tapeW_nonneg c ω, le_rfl]

open Classical in
/-- The uniform-tape probability of an event of the output equals its probability under the law. -/
theorem accComp_ofReal_coinProb {α : Type} (p : BitProg α) {c : ℕ} (hc : p.depth ≤ c)
    (E : Set (Option α)) :
    ENNReal.ofReal (Comparator.coinProb (tapeW c) (fun ω => (p.run (List.ofFn ω)).map Prod.fst ∈ E)) =
      p.law.toOuterMeasure {a | some a ∈ E} := by
  have hsum := BitProg.sum_tapes_eq p hc (fun a => if some a ∈ E then (1 : ENNReal) else 0)
  have hrun : ∀ ω : Fin c → Bool,
      (p.run (List.ofFn ω)).elim 0 (fun r => if some r.1 ∈ E then (1 : ENNReal) else 0) =
        if (p.run (List.ofFn ω)).map Prod.fst ∈ E then 1 else 0 := by
    intro ω
    obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp
      (BitProg.run_isSome p (List.ofFn ω) (by rw [List.length_ofFn]; exact hc))
    rw [hr]
    rfl
  have hR : ∑' a, p.law a * (if some a ∈ E then (1 : ENNReal) else 0) =
      p.law.toOuterMeasure {a | some a ∈ E} := by
    rw [PMF.toOuterMeasure_apply]
    congr 1
    funext a
    by_cases h : some a ∈ E
    · simp [h, Set.indicator]
    · simp [h, Set.indicator]
  unfold Comparator.coinProb tapeW
  rw [ENNReal.ofReal_sum_of_nonneg (fun ω _ => by split_ifs <;> positivity)]
  have hterm : ∀ ω : Fin c → Bool,
      ENNReal.ofReal (if (p.run (List.ofFn ω)).map Prod.fst ∈ E then ((1 : ℝ) / 2) ^ c else 0) =
        ENNReal.ofReal (((1 : ℝ) / 2) ^ c) *
          (if (p.run (List.ofFn ω)).map Prod.fst ∈ E then 1 else 0) := by
    intro ω
    split_ifs <;> simp
  simp_rw [hterm, ← Finset.mul_sum, ← hrun, hsum, ← hR]
  rw [← mul_assoc]
  have h2 : ENNReal.ofReal (((1 : ℝ) / 2) ^ c) * 2 ^ c = 1 := by
    rw [ENNReal.ofReal_pow (by norm_num), ← mul_pow]
    have : ENNReal.ofReal ((1 : ℝ) / 2) * 2 = 1 := by
      rw [ENNReal.ofReal_div_of_pos (by norm_num), ENNReal.ofReal_one, ENNReal.ofReal_ofNat]
      exact ENNReal.div_mul_cancel (by norm_num) (by norm_num)
    rw [this, one_pow]
  rw [h2, one_mul]

open Classical in
/-- **DP of the block transcript** on the uniform tapes, from the per-block DP of the online execution. -/
theorem accComp_finDP (M J R : ℕ) {aReq ξReq : ℝ} (hdp : CoreBlockDP M J R aReq ξReq) {U : Type}
    [Fintype U] (ctrl : CoreCtrl U) (hctrl : ctrl.Valid (adaAlg2Params M J R aReq ξReq)) (T : ℕ)
    (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p)
    (hδ0 : 0 ≤ accDelta aReq ξReq) :
    Comparator.FinDP (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
      (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j) (accVartheta aReq j)
      (accDelta aReq ξReq) := by
  intro i x a b E
  have hN := blockNeighbor_withBlock_update (adaAlg2Params M J R aReq ξReq) s j x i a b
  have h := hdp U ctrl hctrl T j hj _ _ hN {o | some o ∈ E}
  rw [← accComp_ofReal_coinProb _ (coreRun_depth_le _ _ _ _) E,
    ← accComp_ofReal_coinProb _ (coreRun_depth_le _ _ _ _) E,
    ← ENNReal.ofReal_mul (Real.exp_pos _).le,
    ← ENNReal.ofReal_add (mul_nonneg (Real.exp_pos _).le (accComp_coinProb_nonneg _)) hδ0] at h
  exact (ENNReal.ofReal_le_ofReal_iff
    (add_nonneg (mul_nonneg (Real.exp_pos _).le (accComp_coinProb_nonneg _)) hδ0)).1 h

/-- The `m`-th element of the indices `< n` satisfying `q` is `t`, when `q t` and `m = #{i < t | q i}`. -/
theorem accComp_filter_range_getElem? (q : ℕ → Bool) {n t : ℕ} (ht : t < n) (hq : q t = true) :
    ((List.range n).filter q)[((List.range t).filter q).length]? = some t := by
  obtain ⟨d, rfl⟩ : ∃ d, n = t + (d + 1) := ⟨n - t - 1, by omega⟩
  rw [List.range_add, List.filter_append, List.range_succ_eq_map, List.map_cons, List.filter_cons]
  simp only [Nat.add_zero, hq, if_true]
  rw [List.getElem?_append_right (le_refl _), Nat.sub_self]
  rfl

theorem accComp_card_filter_range (q : ℕ → Bool) (t : ℕ) :
    ((Finset.range t).filter fun i => q i = true).card = ((List.range t).filter q).length := by
  rw [Finset.card_def, Finset.filter_val, Finset.range_val, Multiset.range, Multiset.filter_coe,
    Multiset.coe_card]
  congr 1
  simp only [Bool.decide_eq_true]

/-- Every candidate round is the round of some candidate index. -/
theorem accComp_exists_candRound {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut)
    {t : ℕ} (ht : t < o.length) (hc : CoreCandidate P ctrl o t) :
    ∃ i : Fin (P.M + P.R), candRound P ctrl o i = some t := by
  unfold CoreCandidate at hc
  by_cases hI : (coreReqAt ctrl o t).isInterval = true
  · rw [if_pos hI] at hc
    set q : ℕ → Bool := fun i => (coreReqAt ctrl o i).isInterval with hqdef
    have hcard : ((Finset.range (t + 1)).filter fun i => q i = true).card =
        ((List.range t).filter q).length + 1 := by
      rw [accComp_card_filter_range q (t + 1), List.range_succ, List.filter_append]
      simp [q, hI]
    have hm : ((List.range t).filter q).length < P.M := by
      have : ((Finset.range (t + 1)).filter fun i => q i = true).card ≤ P.M := hc
      omega
    refine ⟨⟨((List.range t).filter q).length, by omega⟩, ?_⟩
    simp only [candRound, if_pos hm]
    exact accComp_filter_range_getElem? q ht hI
  · rw [if_neg hI] at hc
    have hI' : (coreReqAt ctrl o t).isInterval = false := by simpa using hI
    set q : ℕ → Bool := fun i => !(coreReqAt ctrl o i).isInterval with hqdef
    have hqt : q t = true := by simp [q, hI']
    have hcard : ((Finset.range (t + 1)).filter fun i => (coreReqAt ctrl o i).isInterval = false).card =
        ((List.range t).filter q).length + 1 := by
      have e : ((Finset.range (t + 1)).filter fun i => (coreReqAt ctrl o i).isInterval = false) =
          ((Finset.range (t + 1)).filter fun i => q i = true) := by
        ext i
        simp [q]
      rw [e, accComp_card_filter_range q (t + 1), List.range_succ, List.filter_append]
      simp [hqt]
    have hm : ((List.range t).filter q).length < P.R := by omega
    refine ⟨⟨P.M + ((List.range t).filter q).length, by omega⟩, ?_⟩
    simp only [candRound, if_neg (show ¬ (P.M + ((List.range t).filter q).length < P.M) by omega),
      Nat.add_sub_cancel_left]
    exact accComp_filter_range_getElem? q ht hqt

theorem accComp_hA_mul_two_pow (P : AdaParams) : (P.hA : ℝ) * 2 ^ P.qA = 1 := by
  rw [show (P.hA : ℝ) = ((1 / 2 : ℚ) ^ P.qA : ℚ) from rfl]
  push_cast
  rw [← mul_pow]
  norm_num

/-- The block values of a request read off the core: `x_j(i) = h_A f(X_{j,i})` for a valid controller. -/
theorem accComp_blockX_coreVals {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (hctrl : ctrl.Valid P)
    (s : Fin P.N → U) (hist : List CoreOut) (j : ℕ) (i : Fin (blockN P j)) :
    blockX P (coreVals P s (ctrl hist)) j i = (P.hA : ℝ) * ((ctrl hist).f (sampleBlock P s j i) : ℝ) := by
  unfold blockX blockVals
  rw [coreVals_getD]
  have hlen : i.val < (List.ofFn fun i : Fin (blockN P j) => (ctrl hist).f (sampleBlock P s j i)).length := by
    rw [List.length_ofFn]; exact i.isLt
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_eq_getElem hlen]
  simp only [Option.map_some, Option.getD_some, List.getElem_ofFn]
  rw [min_eq_left ((hctrl hist).1 _)]
  push_cast
  rfl

/-- The candidate queries take values in `[0, 1]`. -/
theorem accComp_candQuery_mem {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (hctrl : ctrl.Valid P)
    (t : Option (List CoreOut)) (i : Fin (P.M + P.R)) (a : U) :
    0 ≤ candQuery P ctrl t i a ∧ candQuery P ctrl t i a ≤ 1 := by
  have hA0 : (0 : ℝ) ≤ (P.hA : ℝ) := by
    rw [show (P.hA : ℝ) = ((1 / 2 : ℚ) ^ P.qA : ℚ) from rfl]
    positivity
  rcases t with _ | o
  · simp [candQuery]
  · simp only [candQuery]
    rcases candRound P ctrl o i with _ | t'
    · simp
    · simp only
      refine ⟨by positivity, ?_⟩
      have hf : ((coreReqAt ctrl o t').f a : ℝ) ≤ 2 ^ P.qA := by
        exact_mod_cast (hctrl (o.take t')).1 a
      calc (P.hA : ℝ) * ((coreReqAt ctrl o t').f a : ℝ) ≤ (P.hA : ℝ) * 2 ^ P.qA :=
            mul_le_mul_of_nonneg_left hf hA0
        _ = 1 := accComp_hA_mul_two_pow P

/-! ## The parameters of the comparator instance -/

theorem accComp_accDelta_eq (aReq ξReq : ℝ) : accDelta aReq ξReq = alg2Delta aReq ξReq := by
  unfold accDelta adaDelta adaXiJ alg2Delta alg2XiJ
  push_cast
  rw [adaH_cast, adaXiA_cast, adaP_eq]

theorem accComp_accVartheta_eq (aReq : ℝ) (j : ℕ) : accVartheta aReq j = alg2Vartheta aReq j := by
  unfold accVartheta alg2Vartheta
  rw [adaD_eq]

theorem accComp_h_eq (M J R : ℕ) (aReq ξReq : ℝ) :
    (((adaAlg2Params M J R aReq ξReq).tau : ℚ) : ℝ) / 64 = alg2H aReq := by
  rw [show (((adaAlg2Params M J R aReq ξReq).tau : ℚ) : ℝ) = alg2Tau aReq from adaTau_cast aReq]
  exact (alg2H_eq_tau aReq).symm

theorem accComp_blockN_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    (blockN (adaAlg2Params M J R aReq ξReq) j : ℝ) = alg2NBlock M J R aReq ξReq j := by
  have h : blockN (adaAlg2Params M J R aReq ξReq) j = alg2NBlock M J R aReq ξReq j := by
    show (adaBlockSizes M J R (dyadicExp aReq) (dyadicExp ξReq)).getD j 0 = _
    rw [accTail_adaBlockSizes_getD M J R _ _ hj, adaNBlock_eq M J R ha0 ha1 hξ0 hξ1 j]
  rw [h]

theorem accComp_accTheta_eq (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    accTheta (adaAlg2Params M J R aReq ξReq) j = alg2Theta aReq j := by
  have hp : (adaAlg2Params M J R aReq ξReq).p = alg2P aReq := adaP_eq aReq
  unfold accTheta alg2Theta alg2Lambda
  rw [hp, accComp_h_eq]
  split_ifs
  · exact (one_div _).symm
  · rfl

open Classical in
/-- **Theorem II.2.9 for block `j`** of the instance (the facts used below): the comparator is in `W_{n_j}` with
`R(u) ≤ ϑ_j²` for every realization, and it is `2h/3`-inaccurate on some candidate query with probability
`≤ ξ_j`. -/
theorem accComp_block (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (hdp : CoreBlockDP M J R aReq ξReq) {U : Type} [Fintype U]
    (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl : CoreCtrl U)
    (hctrl : ctrl.Valid (adaAlg2Params M J R aReq ξReq)) (T : ℕ)
    (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) {j : ℕ} (hj : j ≤ (adaAlg2Params M J R aReq ξReq).p) :
    (∀ (x : Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U) (t : Option (List CoreOut)),
      Comparator.comparator D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
          (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j) (accVartheta aReq j) x t ∈
        Comparator.cappedSimplexW (blockN (adaAlg2Params M J R aReq ξReq) j) ∧
      Comparator.Rreg (blockN (adaAlg2Params M J R aReq ξReq) j)
          (Comparator.comparator D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
            (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j) (accVartheta aReq j) x t) ≤
        accVartheta aReq j ^ 2) ∧
    Comparator.jProb D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
        (fun y ω => ∃ i : Fin ((adaAlg2Params M J R aReq ξReq).M + (adaAlg2Params M J R aReq ξReq).R),
          2 / 3 * alg2H aReq <
            |∑ l, Comparator.comparator D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
                (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j) (accVartheta aReq j) y
                (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j y ω) l *
              candQuery (adaAlg2Params M J R aReq ξReq) ctrl
                (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j y ω) i (y l) -
              popMean D (candQuery (adaAlg2Params M J R aReq ξReq) ctrl
                (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j y ω) i)|) ≤
      alg2XiJ aReq ξReq := by
  have hδ0 : 0 ≤ accDelta aReq ξReq := by
    rw [accComp_accDelta_eq]
    exact (alg2Delta_pos aReq ξReq).le
  have hT := accComp_finDP M J R hdp ctrl hctrl T s hj hδ0
  have hθ := accComp_accVartheta_eq aReq j
  have hk : (adaAlg2Params M J R aReq ξReq).M + (adaAlg2Params M J R aReq ξReq).R ≤ M + R := le_rfl
  have hr0 := transfer_condition M J R aReq ξReq j hk
  have hr : 72 * Real.exp (2 * accVartheta aReq j) * (alg2H aReq ^ 2)⁻¹ *
      Real.log (((((adaAlg2Params M J R aReq ξReq).M + (adaAlg2Params M J R aReq ξReq).R : ℕ) : ℝ) + 2) /
        alg2XiJ aReq ξReq) ≤ (blockN (adaAlg2Params M J R aReq ξReq) j : ℝ) := by
    rw [hθ, accComp_blockN_eq M J R ha0 ha1 hξ0 hξ1 hj, ← div_eq_mul_inv]
    exact hr0
  have hδ : accDelta aReq ξReq ≤ 1 / 24 * alg2H aReq * alg2XiJ aReq ξReq := by
    rw [accComp_accDelta_eq, alg2Delta_eq]
    apply le_of_eq
    ring
  have h := Comparator.posterior_comparator hD0 hD1 (accComp_tapeW_nonneg _) (accComp_tapeW_sum _) hT
    (candQuery (adaAlg2Params M J R aReq ξReq) ctrl) (accComp_candQuery_mem _ ctrl hctrl)
    (by rw [hθ]; exact alg2Vartheta_pos aReq j) (by rw [hθ]; exact alg2Vartheta_le_one aReq j)
    (alg2H_pos aReq) (alg2H_le_one aReq) (alg2XiJ_pos aReq ξReq) (alg2XiJ_lt_one aReq ξReq) hr hδ
  refine ⟨fun x t => ?_, h.2.1⟩
  obtain ⟨hmem, -, -, hR, h1, h2⟩ := h.1 x t
  exact ⟨hmem, hR.trans (h1.trans h2)⟩

theorem accComp_blockTranscript_withBlock {U : Type} (P : AdaParams) (ctrl : CoreCtrl U)
    (s : Fin P.N → U) (T j : ℕ) (x : Fin (blockN P j) → U) :
    blockTranscript P ctrl (withBlock P s j x) T j = blockTranscript P ctrl s T j := by
  funext x' ω
  unfold blockTranscript
  rw [withBlock_withBlock]

open Classical in
/-- `∑_x D^{n}(x) · Pr_ω[E x ω] = jProb D w E` (uniform tapes). -/
theorem accComp_sum_coinProb {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) {n c : ℕ}
    (E : (Fin n → U) → (Fin c → Bool) → Prop) :
    ∑ x : Fin n → U, ENNReal.ofReal (∏ i, D (x i)) * ENNReal.ofReal (Comparator.coinProb (tapeW c) (E x)) =
      ENNReal.ofReal (Comparator.jProb D (tapeW c) E) := by
  have hp : ∀ x : Fin n → U, 0 ≤ ∏ i, D (x i) := fun x => Finset.prod_nonneg fun i _ => hD0 _
  simp_rw [← ENNReal.ofReal_mul (hp _)]
  rw [← ENNReal.ofReal_sum_of_nonneg (fun x _ => mul_nonneg (hp x) (accComp_coinProb_nonneg _))]
  congr 1
  unfold Comparator.jProb Comparator.coinProb Comparator.prodMass
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun ω _ => ?_
  split_ifs <;> simp

section Alg2

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- **Theorem II.2.9 (i) for every block** (with `ϑ_j ≤ θ_j`): the block comparators are admissible for every
realization. -/
theorem blockComparators_admissible (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hdp : CoreBlockDP M J R aReq ξReq) {U : Type} [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl : CoreCtrl U)
    (hctrl : ctrl.Valid (adaAlg2Params M J R aReq ξReq)) (T : ℕ)
    (s : Fin (adaAlg2Params M J R aReq ξReq).N → U) (o : List CoreOut) :
    CompAdmissible (adaAlg2Params M J R aReq ξReq)
      (fun j => blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o) := by
  refine ⟨fun j hj => ?_, fun j hj => ?_⟩
  · exact ((accComp_block M J R ha0 ha1 hξ0 hξ1 hdp D hD0 hD1 ctrl hctrl T s hj.le).1
      (sampleBlock _ s j) (some o)).1
  · have hb := ((accComp_block M J R ha0 ha1 hξ0 hξ1 hdp D hD0 hD1 ctrl hctrl T s hj).1
      (sampleBlock _ s j) (some o)).2
    have hθ0 : 0 ≤ accVartheta aReq j := by
      rw [accComp_accVartheta_eq]
      exact (alg2Vartheta_pos aReq j).le
    have hθΘ : accVartheta aReq j ≤ accTheta (adaAlg2Params M J R aReq ξReq) j := by
      rw [accComp_accVartheta_eq, accComp_accTheta_eq]
      exact alg2Vartheta_le_alg2Theta aReq j
    exact hb.trans (pow_le_pow_left₀ hθ0 hθΘ 2)

/-- **The comparator event** (L1034): Theorem II.2.9 (ii) for every block `j ≤ p` and a union bound: the block
comparators are inaccurate on some candidate query with probability at most `(p+1) ξ_j = ξ_A/8`. -/
theorem comp_fail_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (hdp : CoreBlockDP M J R aReq ξReq) {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x)
    (hD1 : ∑ x, D x = 1) (ctrl : CoreCtrl U) (hctrl : ctrl.Valid (adaAlg2Params M J R aReq ξReq))
    (T : ℕ) :
    ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
      (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure
        {o | ¬ CompOK (adaAlg2Params M J R aReq ξReq) D ctrl s
          (fun j => blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o) o} ≤
      ENNReal.ofReal (accXiA ξReq / 8) := by
  classical
  have hh := accComp_h_eq M J R aReq ξReq
  -- the per-block bad events
  let Bad : ℕ → (Fin (adaAlg2Params M J R aReq ξReq).N → U) → Set (List CoreOut) := fun j s =>
    {o | ∃ t < o.length, CoreCandidate (adaAlg2Params M J R aReq ξReq) ctrl o t ∧
      alg2H aReq < |∑ i, blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o i *
          blockX (adaAlg2Params M J R aReq ξReq) (coreVals (adaAlg2Params M J R aReq ξReq) s (coreReqAt ctrl o t)) j i -
        reqMean (adaAlg2Params M J R aReq ξReq) D (coreReqAt ctrl o t)|}
  have hsub : ∀ s, {o | ¬ CompOK (adaAlg2Params M J R aReq ξReq) D ctrl s
      (fun j => blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o) o} ⊆
      ⋃ j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1), Bad j s := by
    intro s o ho
    simp only [Set.mem_ofPred_eq, CompOK] at ho
    push Not at ho
    obtain ⟨t, ht, hc, hcc⟩ := ho
    unfold CompCond at hcc
    push Not at hcc
    obtain ⟨j, hj, hjb⟩ := hcc
    rw [hh] at hjb
    exact Set.mem_biUnion (Finset.mem_range.2 (Nat.lt_succ_of_le hj)) ⟨t, ht, hc, hjb⟩
  have hstep : ∀ s, (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure
      {o | ¬ CompOK (adaAlg2Params M J R aReq ξReq) D ctrl s
        (fun j => blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o) o} ≤
      ∑ j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1),
        (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure (Bad j s) := fun s =>
    (MeasureTheory.measure_mono (hsub s)).trans (MeasureTheory.measure_biUnion_finset_le _ _)
  have hsumD : ∀ (n : ℕ), ∑ x : Fin n → U, ENNReal.ofReal (∏ i, D (x i)) = 1 := by
    intro n
    rw [← ENNReal.ofReal_sum_of_nonneg (fun x _ => Finset.prod_nonneg fun i _ => hD0 _),
      ← Fintype.sum_pow, hD1, one_pow, ENNReal.ofReal_one]
  -- one block
  have hblock : ∀ j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1),
      ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure (Bad j s) ≤
      ENNReal.ofReal (alg2XiJ aReq ξReq) := by
    intro j hj
    have hj' : j ≤ (adaAlg2Params M J R aReq ξReq).p := Nat.lt_succ_iff.mp (Finset.mem_range.mp hj)
    rw [sum_resample_block (adaAlg2Params M J R aReq ξReq) D hD0 hD1 j
      (fun s => (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure (Bad j s))]
    have hinner : ∀ s : Fin (adaAlg2Params M J R aReq ξReq).N → U,
        ∑ x : Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U, ENNReal.ofReal (∏ i, D (x i)) *
          (coreRun (adaAlg2Params M J R aReq ξReq) ctrl (withBlock (adaAlg2Params M J R aReq ξReq) s j x) T).law.toOuterMeasure
            (Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x)) ≤
        ENNReal.ofReal (alg2XiJ aReq ξReq) := by
      intro s
      obtain ⟨-, hbad⟩ := accComp_block M J R ha0 ha1 hξ0 hξ1 hdp D hD0 hD1 ctrl hctrl T s hj'
      let E : (Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U) →
          (Fin (adaCoins (adaAlg2Params M J R aReq ξReq)) → Bool) → Prop := fun x ω =>
        blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j x ω ∈
          {oo : Option (List CoreOut) | ∃ o, oo = some o ∧ o ∈ Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x)}
      have hlaw : ∀ x, (coreRun (adaAlg2Params M J R aReq ξReq) ctrl
          (withBlock (adaAlg2Params M J R aReq ξReq) s j x) T).law.toOuterMeasure
            (Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x)) =
          ENNReal.ofReal (Comparator.coinProb (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq))) (E x)) := by
        intro x
        show _ = ENNReal.ofReal (Comparator.coinProb _ (fun ω =>
          ((coreRun (adaAlg2Params M J R aReq ξReq) ctrl (withBlock (adaAlg2Params M J R aReq ξReq) s j x) T).run
            (List.ofFn ω)).map Prod.fst ∈
              {oo : Option (List CoreOut) | ∃ o, oo = some o ∧ o ∈ Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x)}))
        rw [accComp_ofReal_coinProb _ (coreRun_depth_le _ _ _ _)]
        congr 1
        ext o
        simp
      have hmono : Comparator.jProb D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq))) E ≤
          alg2XiJ aReq ξReq := by
        refine le_trans (Comparator.jProb_mono hD0 (accComp_tapeW_nonneg _) fun x ω hE => ?_) hbad
        obtain ⟨o, hTo, t, ht, hc, hlt⟩ := hE
        obtain ⟨i, hi⟩ := accComp_exists_candRound (adaAlg2Params M J R aReq ξReq) ctrl o ht hc
        refine ⟨i, ?_⟩
        rw [hTo]
        have hq : candQuery (adaAlg2Params M J R aReq ξReq) ctrl (some o) i =
            fun a => ((adaAlg2Params M J R aReq ξReq).hA : ℝ) * ((coreReqAt ctrl o t).f a : ℝ) := by
          simp only [candQuery, hi]
        have hcomp : blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq
            (withBlock (adaAlg2Params M J R aReq ξReq) s j x) j o =
            Comparator.comparator D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq)))
              (blockTranscript (adaAlg2Params M J R aReq ξReq) ctrl s T j) (accVartheta aReq j) x (some o) := by
          unfold blockComparator
          rw [accComp_blockTranscript_withBlock, sampleBlock_withBlock]
        have hX : ∀ l, blockX (adaAlg2Params M J R aReq ξReq)
            (coreVals (adaAlg2Params M J R aReq ξReq) (withBlock (adaAlg2Params M J R aReq ξReq) s j x)
              (coreReqAt ctrl o t)) j l =
            ((adaAlg2Params M J R aReq ξReq).hA : ℝ) * ((coreReqAt ctrl o t).f (x l) : ℝ) := by
          intro l
          rw [show coreReqAt ctrl o t = ctrl (o.take t) from rfl,
            accComp_blockX_coreVals (adaAlg2Params M J R aReq ξReq) ctrl hctrl, sampleBlock_withBlock]
        rw [hcomp] at hlt
        simp_rw [hX] at hlt
        rw [hq]
        have hh0 := alg2H_pos aReq
        unfold reqMean at hlt
        linarith
      calc ∑ x : Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U, ENNReal.ofReal (∏ i, D (x i)) *
            (coreRun (adaAlg2Params M J R aReq ξReq) ctrl (withBlock (adaAlg2Params M J R aReq ξReq) s j x) T).law.toOuterMeasure
              (Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x))
          = ∑ x : Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U, ENNReal.ofReal (∏ i, D (x i)) *
              ENNReal.ofReal (Comparator.coinProb (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq))) (E x)) :=
            Finset.sum_congr rfl fun x _ => by rw [hlaw x]
        _ = ENNReal.ofReal (Comparator.jProb D (tapeW (adaCoins (adaAlg2Params M J R aReq ξReq))) E) :=
            accComp_sum_coinProb D hD0 E
        _ ≤ ENNReal.ofReal (alg2XiJ aReq ξReq) := ENNReal.ofReal_le_ofReal hmono
    calc ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          ∑ x : Fin (blockN (adaAlg2Params M J R aReq ξReq) j) → U, ENNReal.ofReal (∏ i, D (x i)) *
            (coreRun (adaAlg2Params M J R aReq ξReq) ctrl (withBlock (adaAlg2Params M J R aReq ξReq) s j x) T).law.toOuterMeasure
              (Bad j (withBlock (adaAlg2Params M J R aReq ξReq) s j x))
        ≤ ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
            ENNReal.ofReal (alg2XiJ aReq ξReq) :=
          Finset.sum_le_sum fun s _ => mul_le_mul_right (hinner s) _
      _ = ENNReal.ofReal (alg2XiJ aReq ξReq) := by
          rw [← Finset.sum_mul, hsumD, one_mul]
  calc ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure
          {o | ¬ CompOK (adaAlg2Params M J R aReq ξReq) D ctrl s
            (fun j => blockComparator (adaAlg2Params M J R aReq ξReq) D ctrl T aReq s j o) o}
      ≤ ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          ∑ j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1),
            (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure (Bad j s) :=
        Finset.sum_le_sum fun s _ => mul_le_mul_right (hstep s) _
    _ = ∑ j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1),
          ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
            (coreRun (adaAlg2Params M J R aReq ξReq) ctrl s T).law.toOuterMeasure (Bad j s) := by
        simp_rw [Finset.mul_sum]
        exact Finset.sum_comm
    _ ≤ ∑ _j ∈ Finset.range ((adaAlg2Params M J R aReq ξReq).p + 1), ENNReal.ofReal (alg2XiJ aReq ξReq) :=
        Finset.sum_le_sum hblock
    _ = ENNReal.ofReal (accXiA ξReq / 8) := by
        rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, ← ENNReal.ofReal_natCast,
          ← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
        congr 1
        have hp : (((adaAlg2Params M J R aReq ξReq).p + 1 : ℕ) : ℝ) = (alg2P aReq : ℝ) + 1 := by
          push_cast
          rw [show ((adaAlg2Params M J R aReq ξReq).p : ℝ) = (alg2P aReq : ℝ) from by
            exact_mod_cast adaP_eq aReq]
        rw [hp, alg2P_add_one_mul_alg2XiJ, show accXiA ξReq = alg2XiA ξReq from adaXiA_cast ξReq]

end Alg2

end F2e2e.B
