import F2e2e.B.AccuracyDefs

/-!
# Theorem `R:thm:validation_ada` (P5): helper lemmas for the good-event analysis

* list bookkeeping for the core's state updates (`getD_set_eq`, `foldl_set_false_getD`, `addScaled_getD`);
* real-valued forms of the core's predictions: `musR_learned` (`μ_j = ⟨w_j(G_j), f̂(S_j)⟩` with
  `w_j = learnerWeights`, via `capWeightsQ_spec`) and `musR_anchor` (`μ_p = ⟨1/n_p, f̂(S_p)⟩`);
* the state after a correction (`corrState`) and its real scores (`blockG_corrState_*`:
  `G_j ← G_j + q f̂(S_j)`, `G_{j+1} ← G_{j+1} − (q/4) f̂(S_{j+1})`);
* good paths of the threshold redraws and of the edge test (`edgeTest_goodPaths`:
  Lemma `R:lem:sec3_potential_contraction` (iii), `R:eq:sec3_edge_accept_cert`, `R:eq:sec3_edge_reject_cert`).
-/

namespace F2e2e.B

open F2e2e.Discrete F2e2e.Opt.Quad DrawProg

/-! ## Lists -/

theorem getD_set_eq {α : Type*} (l : List α) (i j : ℕ) (a d : α) :
    (l.set i a).getD j d = if i = j ∧ i < l.length then a else l.getD j d := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_set]
  by_cases h : i = j
  · subst h
    by_cases hi : i < l.length
    · simp [hi]
    · simp [hi]
  · simp [h]

theorem getD_set_self_of_lt {α : Type*} {l : List α} {i : ℕ} (hi : i < l.length) (a d : α) :
    (l.set i a).getD i d = a := by
  rw [getD_set_eq]
  simp [hi]

theorem getD_set_of_ne {α : Type*} (l : List α) {i j : ℕ} (h : i ≠ j) (a d : α) :
    (l.set i a).getD j d = l.getD j d := by
  rw [getD_set_eq]
  simp [h]

theorem getD_set_self_default {α : Type*} (l : List α) (i : ℕ) (a : α) :
    (l.set i a).getD i a = a := by
  rw [getD_set_eq]
  split_ifs with h
  · rfl
  · exact List.getD_eq_default l a (by simp at h; omega)

theorem foldl_set_false_length (es : List ℕ) (c : List Bool) :
    (es.foldl (fun c e => c.set e false) c).length = c.length := by
  induction es generalizing c with
  | nil => rfl
  | cons e es ih =>
    simp only [List.foldl_cons]
    rw [ih, List.length_set]

theorem foldl_set_false_getD (es : List ℕ) (c : List Bool) (e : ℕ)
    (h : (es.foldl (fun c e => c.set e false) c).getD e false = true) :
    e ∉ es ∧ c.getD e false = true := by
  induction es generalizing c with
  | nil => exact ⟨by simp, h⟩
  | cons e' es ih =>
    simp only [List.foldl_cons] at h
    obtain ⟨h1, h2⟩ := ih (c.set e' false) h
    have hne : e' ≠ e := by
      rintro rfl
      rw [getD_set_self_default] at h2
      exact Bool.false_ne_true h2
    refine ⟨?_, ?_⟩
    · simp only [List.mem_cons, not_or]
      exact ⟨fun h => hne h.symm, h1⟩
    · rwa [getD_set_of_ne _ hne] at h2

theorem addScaled_length (g : List ℤ) (c : ℤ) (v : List ℕ) : (addScaled g c v).length = g.length := by
  simp [addScaled]

theorem addScaled_getD (g : List ℤ) (c : ℤ) (v : List ℕ) {i : ℕ} (hi : i < g.length) :
    (addScaled g c v).getD i 0 = g.getD i 0 + c * (v.getD i 0 : ℤ) := by
  rw [List.getD_eq_getElem (addScaled g c v) 0 (by rw [addScaled_length]; exact hi),
    List.getD_eq_getElem g 0 hi]
  simp [addScaled]

theorem sum_zipWith_mul_eq {n : ℕ} (w : List ℚ) (v : List ℕ) (hw : w.length = n)
    (hv : v.length = n) :
    (List.zipWith (fun (wi : ℚ) (vi : ℕ) => wi * (vi : ℚ)) w v).sum =
      ∑ i : Fin n, w.getD i 0 * (v.getD i 0 : ℚ) := by
  have e : List.zipWith (fun (wi : ℚ) (vi : ℕ) => wi * (vi : ℚ)) w v =
      List.ofFn (fun i : Fin n => w.getD i 0 * (v.getD i 0 : ℚ)) := by
    apply List.ext_getElem
    · simp [hw, hv]
    · intro i h1 h2
      have hi : i < n := by simpa using h2
      rw [List.getElem_zipWith, List.getElem_ofFn, List.getD_eq_getElem w 0 (by omega),
        List.getD_eq_getElem v 0 (by omega)]
  rw [e, List.sum_ofFn]

theorem sum_map_natCast_eq {n : ℕ} (v : List ℕ) (hv : v.length = n) :
    (v.map fun x => (x : ℚ)).sum = ∑ i : Fin n, (v.getD i 0 : ℚ) := by
  have e0 : (v.map fun x => (x : ℚ)) = v.map (Nat.cast : ℕ → ℚ) := by
    simp [List.map_eq_flatMap]
  rw [e0]
  have e : v.map (Nat.cast : ℕ → ℚ) = List.ofFn (fun i : Fin n => (v.getD i 0 : ℚ)) := by
    apply List.ext_getElem
    · simp [hv]
    · intro i h1 h2
      have hi : i < n := by simpa using h2
      rw [List.getElem_map, List.getElem_ofFn, List.getD_eq_getElem v 0 (by omega)]
  rw [e, List.sum_ofFn]

/-! ## Block values -/

theorem hA_pos (P : AdaParams) : 0 < P.hA := by
  unfold AdaParams.hA
  positivity

theorem hA_mul_two_pow (P : AdaParams) : P.hA * 2 ^ P.qA = 1 := by
  unfold AdaParams.hA
  rw [← mul_pow]
  norm_num

theorem blockVals_length (P : AdaParams) (vals : List (List ℕ)) (j : ℕ) :
    (blockVals P vals j).length = (vals.getD j []).length := by
  simp [blockVals]

theorem blockVals_getD_le (P : AdaParams) (vals : List (List ℕ)) (j i : ℕ) :
    (blockVals P vals j).getD i 0 ≤ 2 ^ P.qA := by
  rw [List.getD_eq_getElem?_getD, blockVals, List.getElem?_map]
  cases (vals.getD j [])[i]? with
  | none => simp
  | some x => simp

theorem blockX_mem (P : AdaParams) (vals : List (List ℕ)) (j : ℕ) (i : Fin (blockN P j)) :
    0 ≤ blockX P vals j i ∧ blockX P vals j i ≤ 1 := by
  have h1 : ((blockVals P vals j).getD i 0 : ℚ) ≤ 2 ^ P.qA := by
    exact_mod_cast blockVals_getD_le P vals j i
  have h0 := hA_pos P
  have hq : P.hA * ((blockVals P vals j).getD i 0 : ℚ) ≤ 1 := by
    calc P.hA * ((blockVals P vals j).getD i 0 : ℚ) ≤ P.hA * 2 ^ P.qA := by gcongr
      _ = 1 := hA_mul_two_pow P
  have hq0 : 0 ≤ P.hA * ((blockVals P vals j).getD i 0 : ℚ) := by positivity
  unfold blockX
  constructor
  · exact_mod_cast hq0
  · exact_mod_cast hq

/-! ## Predictions as reals -/

/-- The predictions `[μ_0, …, μ_p]` of the state as reals. -/
noncomputable def musR (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) : ℝ :=
  (((adaMus P st vals).getD j 0 : ℚ) : ℝ)

/-- Edge `j` is certified for the state: `|μ_{j+1} − μ_j| ≤ τ + 2h` (`R:eq:sec3_edge_accept_cert`). -/
def EdgeCert (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) : Prop :=
  |musR P st vals (j + 1) - musR P st vals j| ≤ (P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)

/-- Every cached edge is certified. -/
def CacheOK (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (cache : List Bool) : Prop :=
  cache.length = P.p ∧ ∀ j < P.p, cache.getD j false = true → EdgeCert P st vals j

theorem adaMus_getD (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) {j : ℕ} (hj : j ≤ P.p) :
    (adaMus P st vals).getD j 0 =
      if j < P.p then predLearned P.hA (st.weights.getD j []) (blockVals P vals j)
      else predAnchor P.hA (P.blockSizes.getD j 0) (blockVals P vals j) := by
  unfold adaMus
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range (by omega)]
  rfl

theorem learnerWeights_congr {n : ℕ} {C κ κ' : ℝ} {G G' : Fin n → ℝ}
    (h : ∀ i, κ * G i = κ' * G' i) : Opt.Quad.learnerWeights n C κ G = Opt.Quad.learnerWeights n C κ' G' := by
  have hs : shiftedScores κ G = shiftedScores κ' G' := funext fun i => by
    simp only [shiftedScores, h i]
  unfold Opt.Quad.learnerWeights waterLevel
  rw [hs]

theorem capWeightsQ_real {n : ℕ} (hn : 0 < n) (c : ℚ) (g : List ℤ) (hg : g.length = n) (i : Fin n) :
    (((capWeightsQ c g).getD i 0 : ℚ) : ℝ) =
      Opt.Quad.learnerWeights n 8 (c : ℝ) (fun i : Fin n => ((g.getD i 0 : ℤ) : ℝ)) i := by
  subst hg
  have h := congrFun (capWeightsQ_spec c g (List.ne_nil_of_length_pos hn)) i
  have hf : (fun i : Fin g.length => ((g.get i : ℤ) : ℝ)) =
      (fun i : Fin g.length => ((g.getD i 0 : ℤ) : ℝ)) := by
    funext k
    rw [List.getD_eq_getElem g 0 k.2, List.get_eq_getElem]
  rw [h, hf]

/-- The exact weights of a learned block are the learner weights of its real scores `G_j`. -/
theorem weights_real (P : AdaParams) (st : AdaState) {j : ℕ} (hn : 0 < blockN P j)
    (hw : st.weights.getD j [] = capWeightsQ (scoreScale P) (st.scores.getD j []))
    (hs : (st.scores.getD j []).length = blockN P j) (i : Fin (blockN P j)) :
    (((st.weights.getD j []).getD i 0 : ℚ) : ℝ) =
      Opt.Quad.learnerWeights (blockN P j) 8 (P.kappa : ℝ) (blockG P st j) i := by
  rw [hw, capWeightsQ_real hn _ _ hs]
  refine congrFun (learnerWeights_congr fun k => ?_) i
  simp only [blockG, scoreScale]
  push_cast
  ring

/-- **Learned prediction** `μ_j = ⟨w_j(G_j), f̂(S_j)⟩` (`R:eq:sec3_wj_muj_def`). -/
theorem musR_learned (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) {j : ℕ} (hj : j < P.p)
    (hn : 0 < blockN P j)
    (hw : st.weights.getD j [] = capWeightsQ (scoreScale P) (st.scores.getD j []))
    (hs : (st.scores.getD j []).length = blockN P j) (hv : (vals.getD j []).length = blockN P j) :
    musR P st vals j =
      ∑ i, Opt.Quad.learnerWeights (blockN P j) 8 (P.kappa : ℝ) (blockG P st j) i * blockX P vals j i := by
  unfold musR
  rw [adaMus_getD P st vals hj.le, if_pos hj, predLearned,
    sum_zipWith_mul_eq (n := blockN P j) _ _ (by rw [hw, capWeightsQ_length, hs])
      (by rw [blockVals_length, hv])]
  push_cast
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [← weights_real P st hn hw hs i]
  simp only [blockX]
  push_cast
  ring

/-- **Anchor prediction** `μ_p = ⟨1/n_p, f̂(S_p)⟩` (`R:eq:sec3_anchor_def`). -/
theorem musR_anchor (P : AdaParams) (st : AdaState) (vals : List (List ℕ))
    (hv : (vals.getD P.p []).length = blockN P P.p) :
    musR P st vals P.p = ∑ i, (1 / (blockN P P.p : ℝ)) * blockX P vals P.p i := by
  unfold musR
  rw [adaMus_getD P st vals le_rfl, if_neg (lt_irrefl _), predAnchor,
    sum_map_natCast_eq (n := blockN P P.p) _ (by rw [blockVals_length, hv])]
  have e : (blockN P P.p : ℝ) = ((P.blockSizes.getD P.p 0 : ℕ) : ℝ) := rfl
  simp only [blockX]
  push_cast
  rw [Finset.sum_div, Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [e]
  ring

/-! ## A correction -/

/-- The state after a correction on edge `j` with sign `q` and redrawn thresholds `thr` (line [8]). -/
def corrState (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool)
    (thr : List ℤ) : AdaState :=
  let qz : ℤ := if q then 1 else -1
  let gj := addScaled (st.scores.getD j []) (4 * qz) (blockVals P vals j)
  let g1 := st.scores.set j gj
  let w1 := st.weights.set j (capWeightsQ (scoreScale P) gj)
  let gj1 := addScaled (g1.getD (j + 1) []) (-qz) (blockVals P vals (j + 1))
  let g2 := if j + 1 < P.p then g1.set (j + 1) gj1 else g1
  let w2 := if j + 1 < P.p then w1.set (j + 1) (capWeightsQ (scoreScale P) gj1) else w1
  { st with scores := g2, weights := w2, T := st.T.set j (st.T.getD j 0 + 1), thrInt := thr }

theorem applyCorrection_eq (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    applyCorrection P st vals j q = (redrawThresholds P (reopenEdges P j) st.thrInt).bind
      fun thr => DrawProg.ret (corrState P st vals j q thr) := rfl

section corr

variable (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) (thr : List ℤ)

theorem corrState_scores_length : (corrState P st vals j q thr).scores.length = st.scores.length := by
  simp only [corrState]
  split_ifs <;> simp

theorem corrState_weights_length :
    (corrState P st vals j q thr).weights.length = st.weights.length := by
  simp only [corrState]
  split_ifs <;> simp

theorem corrState_scores_self (hj : j < st.scores.length) :
    (corrState P st vals j q thr).scores.getD j [] =
      addScaled (st.scores.getD j []) (4 * (if q then 1 else -1)) (blockVals P vals j) := by
  simp only [corrState]
  by_cases h : j + 1 < P.p
  · rw [if_pos h, getD_set_of_ne (i := j + 1) (j := j) _ (by omega), getD_set_self_of_lt hj]
  · rw [if_neg h, getD_set_self_of_lt hj]

theorem corrState_scores_succ (hj1 : j + 1 < P.p) (hlen : j + 1 < st.scores.length) :
    (corrState P st vals j q thr).scores.getD (j + 1) [] =
      addScaled (st.scores.getD (j + 1) []) (-(if q then 1 else -1)) (blockVals P vals (j + 1)) := by
  simp only [corrState]
  rw [if_pos hj1, getD_set_self_of_lt (by rw [List.length_set]; exact hlen),
    getD_set_of_ne (i := j) (j := j + 1) _ (by omega)]

theorem corrState_scores_other {k : ℕ} (hk : k ≠ j) (hk1 : k ≠ j + 1) :
    (corrState P st vals j q thr).scores.getD k [] = st.scores.getD k [] := by
  simp only [corrState]
  by_cases h : j + 1 < P.p
  · rw [if_pos h, getD_set_of_ne (i := j + 1) (j := k) _ (Ne.symm hk1),
      getD_set_of_ne (i := j) (j := k) _ (Ne.symm hk)]
  · rw [if_neg h, getD_set_of_ne (i := j) (j := k) _ (Ne.symm hk)]

theorem corrState_weights_self (hj : j < st.weights.length) :
    (corrState P st vals j q thr).weights.getD j [] =
      capWeightsQ (scoreScale P)
        (addScaled (st.scores.getD j []) (4 * (if q then 1 else -1)) (blockVals P vals j)) := by
  simp only [corrState]
  by_cases h : j + 1 < P.p
  · rw [if_pos h, getD_set_of_ne (i := j + 1) (j := j) _ (by omega), getD_set_self_of_lt hj]
  · rw [if_neg h, getD_set_self_of_lt hj]

theorem corrState_weights_succ (hj1 : j + 1 < P.p) (hlen : j + 1 < st.weights.length) :
    (corrState P st vals j q thr).weights.getD (j + 1) [] =
      capWeightsQ (scoreScale P)
        (addScaled (st.scores.getD (j + 1) []) (-(if q then 1 else -1)) (blockVals P vals (j + 1))) := by
  simp only [corrState]
  rw [if_pos hj1, getD_set_self_of_lt (by rw [List.length_set]; exact hlen),
    getD_set_of_ne (i := j) (j := j + 1) _ (by omega)]

theorem corrState_scores_anchor (hj1 : ¬ j + 1 < P.p) :
    (corrState P st vals j q thr).scores.getD (j + 1) [] = st.scores.getD (j + 1) [] := by
  simp only [corrState]
  rw [if_neg hj1, getD_set_of_ne (i := j) (j := j + 1) _ (by omega)]

theorem corrState_weights_other {k : ℕ} (hk : k ≠ j) (hk1 : k ≠ j + 1) :
    (corrState P st vals j q thr).weights.getD k [] = st.weights.getD k [] := by
  simp only [corrState]
  by_cases h : j + 1 < P.p
  · rw [if_pos h, getD_set_of_ne (i := j + 1) (j := k) _ (Ne.symm hk1),
      getD_set_of_ne (i := j) (j := k) _ (Ne.symm hk)]
  · rw [if_neg h, getD_set_of_ne (i := j) (j := k) _ (Ne.symm hk)]

/-- The real scores after a correction, updated block `j`: `G_j ← G_j + q f̂(S_j)`. -/
theorem blockG_corrState_self (hj : j < st.scores.length)
    (hs : (st.scores.getD j []).length = blockN P j) :
    blockG P (corrState P st vals j q thr) j =
      blockG P st j + (if q then (1 : ℝ) else -1) • blockX P vals j := by
  funext i
  have hi : (i : ℕ) < (st.scores.getD j []).length := by rw [hs]; exact i.2
  simp only [blockG, blockX, Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  rw [corrState_scores_self P st vals j q thr hj, addScaled_getD _ _ _ hi]
  split_ifs <;> push_cast <;> ring

/-- The real scores after a correction, coupled block `j + 1 < p`: `G_{j+1} ← G_{j+1} − (q/4) f̂(S_{j+1})`. -/
theorem blockG_corrState_succ (hj1 : j + 1 < P.p) (hlen : j + 1 < st.scores.length)
    (hs : (st.scores.getD (j + 1) []).length = blockN P (j + 1)) :
    blockG P (corrState P st vals j q thr) (j + 1) =
      blockG P st (j + 1) + (-((if q then (1 : ℝ) else -1) / 4)) • blockX P vals (j + 1) := by
  funext i
  have hi : (i : ℕ) < (st.scores.getD (j + 1) []).length := by rw [hs]; exact i.2
  simp only [blockG, blockX, Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  rw [corrState_scores_succ P st vals j q thr hj1 hlen, addScaled_getD _ _ _ hi]
  split_ifs <;> push_cast <;> ring

theorem blockG_corrState_other {k : ℕ} (hk : k ≠ j) (hk1 : k ≠ j + 1) :
    blockG P (corrState P st vals j q thr) k = blockG P st k := by
  funext i
  simp only [blockG]
  rw [corrState_scores_other P st vals j q thr hk hk1]

theorem blockG_corrState_anchor (hj1 : ¬ j + 1 < P.p) :
    blockG P (corrState P st vals j q thr) (j + 1) = blockG P st (j + 1) := by
  funext i
  simp only [blockG]
  rw [corrState_scores_anchor P st vals j q thr hj1]

end corr

/-- Predictions depend on the state only through the weights. -/
theorem musR_eq_of_weights (P : AdaParams) {st st' : AdaState} (vals : List (List ℕ)) {k : ℕ}
    (h : st'.weights.getD k [] = st.weights.getD k []) : musR P st' vals k = musR P st vals k := by
  unfold musR
  by_cases hk : k ≤ P.p
  · rw [adaMus_getD P st' vals hk, adaMus_getD P st vals hk, h]
  · rw [List.getD_eq_default (adaMus P st' vals) 0 (by simp [adaMus]; omega),
      List.getD_eq_default (adaMus P st vals) 0 (by simp [adaMus]; omega)]

theorem not_mem_reopenEdges {P : AdaParams} {j e : ℕ} (he : e < P.p) (h : e ∉ reopenEdges P j) :
    e ≠ j ∧ e ≠ j + 1 ∧ e + 1 ≠ j := by
  unfold reopenEdges at h
  refine ⟨?_, ?_, ?_⟩
  · rintro rfl
    apply h
    simp
  · rintro rfl
    apply h
    simp [he]
  · intro h'
    apply h
    have h1 : 1 ≤ j := by omega
    have h2 : e = j - 1 := by omega
    simp [h1, h2]

theorem reopenEdges_lt {P : AdaParams} {j : ℕ} (hj : j < P.p) : ∀ e ∈ reopenEdges P j, e < P.p := by
  intro e he
  unfold reopenEdges at he
  simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at he
  split_ifs at he with h1 h2 <;> simp at he <;> omega

/-- The weighted correction count after one more correction on edge `j < p`. -/
theorem weightedT_set (P : AdaParams) {st st' : AdaState} {j : ℕ} (hj : j < P.p) (hlen : st.T.length = P.p)
    (hT : st'.T = st.T.set j (st.T.getD j 0 + 1)) : weightedT P st' = weightedT P st + 4 ^ j := by
  unfold weightedT
  have hpt : ∀ k ∈ Finset.range P.p, (4 : ℝ) ^ k * (st'.T.getD k 0 : ℝ) =
      (4 : ℝ) ^ k * (st.T.getD k 0 : ℝ) + if j = k then (4 : ℝ) ^ k else 0 := by
    intro k _
    rw [hT, getD_set_eq]
    by_cases hk : j = k
    · subst hk
      rw [if_pos ⟨rfl, by omega⟩, if_pos rfl]
      push_cast
      ring
    · rw [if_neg (fun h => hk h.1), if_neg hk, add_zero]
  rw [Finset.sum_congr rfl hpt, Finset.sum_add_distrib, Finset.sum_ite_eq, if_pos (Finset.mem_range.2 hj)]

/-- The remaining correction budget drops by one after a correction below the cap. -/
theorem sum_sub_set_succ (Tmax T : List ℕ) {p j : ℕ} (hj : j < p) (hjT : j < T.length)
    (hlt : T.getD j 0 < Tmax.getD j 0) :
    ∑ k ∈ Finset.range p, (Tmax.getD k 0 - (T.set j (T.getD j 0 + 1)).getD k 0) + 1 =
      ∑ k ∈ Finset.range p, (Tmax.getD k 0 - T.getD k 0) := by
  rw [← Finset.add_sum_erase _ _ (Finset.mem_range.2 hj),
    ← Finset.add_sum_erase _ _ (Finset.mem_range.2 hj)]
  have hrest : ∑ k ∈ (Finset.range p).erase j, (Tmax.getD k 0 - (T.set j (T.getD j 0 + 1)).getD k 0) =
      ∑ k ∈ (Finset.range p).erase j, (Tmax.getD k 0 - T.getD k 0) := by
    refine Finset.sum_congr rfl fun k hk => ?_
    rw [getD_set_of_ne _ (Ne.symm (Finset.ne_of_mem_erase hk))]
  rw [hrest, getD_set_self_of_lt hjT]
  omega

/-- `l.sum = ∑_{k < n} l[k]` for a list of length `n`. -/
theorem list_sum_eq_range (l : List ℕ) {n : ℕ} (hl : l.length = n) :
    l.sum = ∑ k ∈ Finset.range n, l.getD k 0 := by
  subst hl
  rw [← Fin.sum_univ_getElem, Finset.sum_range]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [List.getD_eq_getElem l 0 i.2]

theorem drawList_goodPaths (P : AdaParams) (rad : NoiseKind → ℚ) (κ : NoiseKind) :
    ∀ n, (drawList κ n).GoodPaths (NoiseGood P rad)
      (fun l => l.length = n ∧ ∀ k < n, NoiseGood P rad κ (l.getD k 0))
  | 0 => ⟨rfl, fun k hk => absurd hk (Nat.not_lt_zero k)⟩
  | n + 1 => by
    simp only [drawList, drawNoise, bind_draw, bind_ret, goodPaths_draw]
    intro z hz
    refine (drawList_goodPaths P rad κ n).map fun l hl => ⟨by simp [hl.1], fun k hk => ?_⟩
    cases k with
    | zero => simpa using hz
    | succ k => simpa using hl.2 k (by omega)

/-- The invariant transfers to a state with the same learner data and good outer threshold. -/
theorem AccInv.of_eq {P : AdaParams} {rad : NoiseKind → ℚ} {u : (j : ℕ) → Fin (blockN P j) → ℝ}
    {st st' : AdaState} (h : AccInv P rad u st) (h1 : st'.scores = st.scores)
    (h2 : st'.weights = st.weights) (h3 : st'.T = st.T) (h4 : st'.thrInt = st.thrInt)
    (h5 : NoiseGood P rad NoiseKind.outThr st'.thrOut) (h6 : st'.halted = true → st'.rej = P.J + 1)
    (h7 : st'.halted = false → st'.rej ≤ P.J) (h8 : st'.capAborted = false) : AccInv P rad u st' := by
  have hG : blockG P st' = blockG P st := by
    funext j i
    simp only [blockG, h1]
  have hpot : statePotential P u st' = statePotential P u st := by
    simp only [statePotential, hG]
  have hW : weightedT P st' = weightedT P st := by
    simp only [weightedT, h3]
  exact
    { scores_len := by rw [h1]; exact h.scores_len
      score_len := by rw [h1]; exact h.score_len
      weights_len := by rw [h2]; exact h.weights_len
      weights_eq := by rw [h1, h2]; exact h.weights_eq
      T_len := by rw [h3]; exact h.T_len
      thr_len := by rw [h4]; exact h.thr_len
      thrInt_good := by rw [h4]; exact h.thrInt_good
      thrOut_good := h5
      potential := by rw [hpot, hW]; exact h.potential
      halted_rej := h6
      rej_le := h7
      not_capAborted := h8 }

/-- Rounding to the grid `h ℤ` moves by at most `h/2`. -/
theorem round_err {h : ℚ} (hh : 0 < h) (z : ℚ) : |h * (roundIdxQ h z : ℚ) - z| ≤ h / 2 := by
  unfold roundIdxQ
  have h1 := Int.floor_le (z / h + 1 / 2)
  have h2 := Int.lt_floor_add_one (z / h + 1 / 2)
  have e : h * (z / h) = z := by field_simp
  rw [abs_le]
  constructor
  · have : h * (z / h + 1 / 2 - 1) < h * (⌊z / h + 1 / 2⌋ : ℚ) := by
      apply mul_lt_mul_of_pos_left _ hh
      linarith
    nlinarith
  · have : h * (⌊z / h + 1 / 2⌋ : ℚ) ≤ h * (z / h + 1 / 2) := mul_le_mul_of_nonneg_left h1 hh.le
    nlinarith

/-- Clipping to `[0, 1]` does not move a point away from a value `c ∈ [0, 1]`. -/
theorem abs_clipQ01_sub_le (x : ℚ) {c : ℝ} (hc : 0 ≤ c ∧ c ≤ 1) :
    |((clipQ 0 1 x : ℚ) : ℝ) - c| ≤ |(x : ℝ) - c| := by
  unfold clipQ
  rcases le_total x 0 with hx | hx
  · have e : max (0 : ℚ) (min 1 x) = 0 := by
      rw [min_eq_right (by linarith), max_eq_left hx]
    rw [e]
    have hx' : (x : ℝ) ≤ 0 := by exact_mod_cast hx
    rw [abs_of_nonpos (by push_cast; linarith), abs_of_nonpos (by linarith)]
    push_cast
    linarith
  · rcases le_total x 1 with hx1 | hx1
    · have e : max (0 : ℚ) (min 1 x) = x := by
        rw [min_eq_right hx1, max_eq_right hx]
      rw [e]
    · have e : max (0 : ℚ) (min 1 x) = 1 := by
        rw [min_eq_left hx1, max_eq_right (by norm_num)]
      rw [e]
      have hx' : (1 : ℝ) ≤ x := by exact_mod_cast hx1
      rw [abs_of_nonneg (by push_cast; linarith), abs_of_nonneg (by linarith)]
      push_cast
      linarith

/-! ## Good paths of the threshold redraws and of the edge test -/

theorem redrawThresholds_goodPaths (P : AdaParams) (rad : NoiseKind → ℚ) (n : ℕ) :
    ∀ (es : List ℕ) (thr : List ℤ), (∀ k < n, NoiseGood P rad NoiseKind.intThr (thr.getD k 0)) →
      (redrawThresholds P es thr).GoodPaths (NoiseGood P rad)
        (fun thr' => thr'.length = thr.length ∧
          ∀ k < n, NoiseGood P rad NoiseKind.intThr (thr'.getD k 0))
  | [], thr, h => ⟨rfl, h⟩
  | e :: es, thr, h => by
    simp only [redrawThresholds, drawNoise, bind_draw, bind_ret, goodPaths_draw]
    intro z hz
    refine (redrawThresholds_goodPaths P rad n es (thr.set e z) ?_).mono ?_
    · intro m hm
      rw [getD_set_eq]
      split_ifs with h'
      · exact hz
      · exact h m hm
    · intro thr' h'
      exact ⟨by rw [h'.1, List.length_set], h'.2⟩

/-- The certified outcome of an edge test with gap `Δμ = μ_{j+1} − μ_j`: acceptance certifies
`|Δμ| ≤ τ + 2h`, a crossing with sign `q` certifies `q Δμ ≥ τ − 2h`. -/
def EdgeOutOK (P : AdaParams) (gap : ℝ) : Option Bool → Prop
  | none => |gap| ≤ (P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)
  | some q => (P.tau : ℝ) - 2 * ((P.tau : ℝ) / 64) ≤ (if q then (1 : ℝ) else -1) * gap

/-- **Lemma `R:lem:sec3_potential_contraction` (iii)** on the good event (`R:eq:sec3_edge_accept_cert`,
`R:eq:sec3_edge_reject_cert`): with a good persistent threshold and good directed noises, the edge
test's outcome is certified. -/
theorem edgeTest_goodPaths {P : AdaParams} {rad : NoiseKind → ℚ} (hrad : RadOK P rad) (st : AdaState)
    (mus : List ℚ) (j : ℕ) (hthr : NoiseGood P rad NoiseKind.intThr (st.thrInt.getD j 0)) :
    (edgeTest P st mus j).GoodPaths (NoiseGood P rad)
      (EdgeOutOK P (((mus.getD (j + 1) 0 - mus.getD j 0 : ℚ) : ℝ))) := by
  simp only [edgeTest, drawNoise, bind_draw, bind_ret, goodPaths_draw, goodPaths_ret]
  intro kp hkp km hkm
  unfold NoiseGood at hthr hkp hkm
  have hQ : |P.hA * (st.thrInt.getD j 0 : ℚ)| + max |P.hA * (kp : ℚ)| |P.hA * (km : ℚ)| ≤
      2 * (P.tau / 64) := by
    have h1 := hrad.int
    have h2 : max |P.hA * (kp : ℚ)| |P.hA * (km : ℚ)| ≤ rad NoiseKind.intTest := max_le hkp hkm
    linarith
  have hnoise : |((P.hA * (st.thrInt.getD j 0 : ℚ) : ℚ) : ℝ)| +
      max |((P.hA * (kp : ℚ) : ℚ) : ℝ)| |((P.hA * (km : ℚ) : ℚ) : ℝ)| ≤ 2 * ((P.tau : ℝ) / 64) := by
    have := (Rat.cast_le (K := ℝ)).2 hQ
    push_cast at this ⊢
    exact this
  split_ifs with h1 h2
  · show (P.tau : ℝ) - 2 * ((P.tau : ℝ) / 64) ≤ (if true then (1 : ℝ) else -1) * _
    rw [if_pos rfl]
    refine edge_reject_cert (ϑ := ((P.hA * (st.thrInt.getD j 0 : ℚ) : ℚ) : ℝ))
      (νp := ((P.hA * (kp : ℚ) : ℚ) : ℝ)) (νm := ((P.hA * (km : ℚ) : ℚ) : ℝ)) hnoise
      (Or.inl ⟨rfl, ?_⟩)
    have := (Rat.cast_le (K := ℝ)).2 h1
    push_cast at this ⊢
    linarith
  · show (P.tau : ℝ) - 2 * ((P.tau : ℝ) / 64) ≤ (if false then (1 : ℝ) else -1) * _
    rw [if_neg Bool.false_ne_true]
    refine edge_reject_cert (ϑ := ((P.hA * (st.thrInt.getD j 0 : ℚ) : ℚ) : ℝ))
      (νp := ((P.hA * (kp : ℚ) : ℚ) : ℝ)) (νm := ((P.hA * (km : ℚ) : ℚ) : ℝ)) hnoise
      (Or.inr ⟨rfl, ?_⟩)
    have := (Rat.cast_le (K := ℝ)).2 h2
    push_cast at this ⊢
    linarith
  · show |_| ≤ (P.tau : ℝ) + 2 * ((P.tau : ℝ) / 64)
    refine edge_accept_cert (ϑ := ((P.hA * (st.thrInt.getD j 0 : ℚ) : ℚ) : ℝ))
      (νp := ((P.hA * (kp : ℚ) : ℚ) : ℝ)) (νm := ((P.hA * (km : ℚ) : ℚ) : ℝ)) hnoise ?_
    have e1 := (Rat.cast_lt (K := ℝ)).2 (lt_of_not_ge h1)
    have e2 := (Rat.cast_lt (K := ℝ)).2 (lt_of_not_ge h2)
    push_cast at e1 e2 ⊢
    exact max_lt (by linarith) (by linarith)

/-! ## The correction caps (Lemma 3.5 (v)) -/

/-- **Lemma `R:lem:sec3_potential_contraction` (v)** on the invariant: `T_j ≤ 5.12 · 4^{-j} τ^{-2} < T_j^max`. -/
theorem accInv_T_lt_Tmax {P : AdaParams} {rad : NoiseKind → ℚ} {u : (j : ℕ) → Fin (blockN P j) → ℝ}
    (hP : AccParamsOK P) (hu : CompAdmissible P u) {st : AdaState}
    (hst : AccInv P rad u st) : ∀ j < P.p, st.T.getD j 0 < P.Tmax.getD j 0 := by
  intro j hj
  have hnn : 0 ≤ statePotential P u st :=
    jointPotential_nonneg (fun k hk => hP.n_pos k hk.le) (by norm_num) _ hu.mem _
  have hτ : (0 : ℝ) < P.tau := by exact_mod_cast hP.tau_pos
  have hsingle : (4 : ℝ) ^ j * (st.T.getD j 0 : ℝ) ≤ weightedT P st :=
    Finset.single_le_sum (f := fun k => (4 : ℝ) ^ k * (st.T.getD k 0 : ℝ))
      (fun k _ => by positivity) (Finset.mem_range.2 hj)
  have hpot := hst.potential
  have hτ2 : (0 : ℝ) < (P.tau : ℝ) ^ 2 := by positivity
  have h4 : (0 : ℝ) < 4 ^ j := by positivity
  have hb : 25 / 128 * (P.tau : ℝ) ^ 2 * ((4 : ℝ) ^ j * (st.T.getD j 0 : ℝ)) ≤ 1 := by
    have : 25 / 128 * (P.tau : ℝ) ^ 2 * ((4 : ℝ) ^ j * (st.T.getD j 0 : ℝ)) ≤
        25 / 128 * (P.tau : ℝ) ^ 2 * weightedT P st :=
      mul_le_mul_of_nonneg_left hsingle (by positivity)
    linarith
  have hR : (st.T.getD j 0 : ℝ) < 6 / ((4 : ℝ) ^ j * (P.tau : ℝ) ^ 2) := by
    rw [lt_div_iff₀ (by positivity)]
    nlinarith
  rw [hP.Tmax_eq j hj, Nat.lt_ceil]
  have : ((st.T.getD j 0 : ℚ) : ℝ) < (((6 : ℚ) / (4 ^ j * P.tau ^ 2) : ℚ) : ℝ) := by
    push_cast
    exact hR
  exact_mod_cast this

end F2e2e.B
