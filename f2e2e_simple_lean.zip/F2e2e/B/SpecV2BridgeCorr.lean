import F2e2e.B.SpecV2BridgeSampler
import F2e2e.B.ArchCoreSpec

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 2: correspondences

The simulation relation between the Spec's Algorithm 2 (`F2e2e.alg2*`: real-valued scores and
evaluations, `Function.update` states, tape-passing draws) and the core (`F2e2e.B` `ArchCore`: exact
grid indices, integer scores `g = 4G/h_A`, exact weights `capWeightsQ`, `DrawProg` draws):

* `ParCorr P2 P`: the parameter records agree (caps, `p`, block sizes, correction caps, `a`, `τ`, `κ`,
  `h_A`, and each of the five draws is the same bounded sampler);
* `ValsCorr P fv vals`: the Spec's rounded evaluations `fv m` (by global sample index) are `h_A` times
  the core's block-structured grid indices;
* `StCorr P st2 st`: the states agree (`G = (h_A/4) g` on the learned blocks, the weights of the core
  are `capWeightsQ` of its scores, the counters, thresholds and flags agree; `aborted = capAborted`);
* `v2LearnerWeights_eq`: the Spec's ε-choice argmax weights are the core's exact weights
  (`capWeightsQ_spec` + uniqueness of the maximizer, `Opt.Quad.eq_learnerWeights_of_isMax`);
* `alg2Mu_eq`: the predictions agree.
-/

namespace F2e2e.B.V2

open F2e2e.Discrete

/-! ## List helpers -/

theorem getD_set_of_lt {α : Type} (l : List α) {i : ℕ} (j : ℕ) (a d : α) (hi : i < l.length) :
    (l.set i a).getD j d = if j = i then a else l.getD j d := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set, List.getD_eq_getElem?_getD]
  by_cases hji : j = i
  · subst hji; simp [hi]
  · rw [if_neg (Ne.symm hji), if_neg hji]

theorem getD_set_false (l : List Bool) (e e' : ℕ) :
    (l.set e false).getD e' false = if e' = e then false else l.getD e' false := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set, List.getD_eq_getElem?_getD]
  by_cases he : e' = e
  · subst he
    rw [if_pos rfl, if_pos rfl]
    split_ifs with h
    · rfl
    · rfl
  · rw [if_neg (Ne.symm he), if_neg he]

theorem getD_foldl_set_false (es : List ℕ) (l : List Bool) (e' : ℕ) :
    (es.foldl (fun c e => c.set e false) l).getD e' false =
      if e' ∈ es then false else l.getD e' false := by
  induction es generalizing l with
  | nil => simp
  | cons e es ih =>
    rw [List.foldl_cons, ih, getD_set_false]
    by_cases h1 : e' ∈ es
    · simp [h1]
    · by_cases h2 : e' = e
      · simp [h2]
      · simp [h1, h2]

theorem length_foldl_set_false (es : List ℕ) (l : List Bool) :
    (es.foldl (fun c e => c.set e false) l).length = l.length := by
  induction es generalizing l with
  | nil => rfl
  | cons e es ih => rw [List.foldl_cons, ih, List.length_set]

theorem sum_range_getD (l : List ℕ) : ∀ j : ℕ,
    ∑ j' ∈ Finset.range j, l.getD j' 0 = (l.take j).sum := by
  induction l with
  | nil => intro j; simp
  | cons a l ih =>
    intro j
    cases j with
    | zero => simp
    | succ j =>
      rw [Finset.sum_range_succ', List.take_succ_cons, List.sum_cons]
      simp only [List.getD_cons_succ, List.getD_cons_zero]
      rw [ih j, add_comm]

theorem sum_zipWith_eq (w : List ℚ) (v : List ℕ) : ∀ (n : ℕ), w.length = n → v.length = n →
    (List.zipWith (fun (wi : ℚ) (vi : ℕ) => wi * (vi : ℚ)) w v).sum =
      ∑ i : Fin n, w.getD i 0 * (v.getD i 0 : ℚ) := by
  induction w generalizing v with
  | nil =>
    intro n hw hv
    subst hw; simp
  | cons a w ih =>
    intro n hw hv
    cases v with
    | nil => simp only [List.length_cons, List.length_nil] at hv hw; omega
    | cons b v =>
      cases n with
      | zero => simp at hw
      | succ n =>
        simp only [List.length_cons, Nat.add_right_cancel_iff] at hw hv
        rw [List.zipWith_cons_cons, List.sum_cons, ih v n hw hv, Fin.sum_univ_succ]
        simp

theorem sum_map_cast_eq (v : List ℕ) : ∀ (n : ℕ), v.length = n →
    (v.map fun x => (x : ℚ)).sum = ∑ i : Fin n, (v.getD i 0 : ℚ) := by
  induction v with
  | nil => intro n hv; subst hv; simp
  | cons b v ih =>
    intro n hv
    cases n with
    | zero => simp at hv
    | succ n =>
      simp only [List.length_cons, Nat.add_right_cancel_iff] at hv
      have e : ((b :: v).map fun x => (x : ℚ)).sum = (b : ℚ) + (v.map fun x => (x : ℚ)).sum := rfl
      rw [e, ih n hv, Fin.sum_univ_succ]
      simp

/-! ## Run extraction helpers -/

theorem run_bind_some {α β : Type} {p : BitProg α} {f : α → BitProg β} {τ : List Bool} {x : β}
    {rest : List Bool} (h : (p.bind f).run τ = some (x, rest)) :
    ∃ a τ1, p.run τ = some (a, τ1) ∧ (f a).run τ1 = some (x, rest) := by
  rw [BitProg.run_bind, Option.bind_eq_some_iff] at h
  obtain ⟨⟨a, τ1⟩, h1, h2⟩ := h
  exact ⟨a, τ1, h1, h2⟩

theorem run_toBits_bind_some {α γ : Type} {s : NoiseKind → BitProg ℤ} {prog : NoiseProg α}
    {f : α → NoiseProg γ} {τ : List Bool} {x : γ} {rest : List Bool}
    (h : ((prog.bind f).toBits s).run τ = some (x, rest)) :
    ∃ a τ1, (prog.toBits s).run τ = some (a, τ1) ∧ ((f a).toBits s).run τ1 = some (x, rest) := by
  rw [DrawProg.toBits_bind] at h
  exact run_bind_some h

theorem run_toBits_map_some {α γ : Type} {s : NoiseKind → BitProg ℤ} {prog : NoiseProg α}
    {g : α → γ} {τ : List Bool} {y : γ} {rest : List Bool}
    (h : ((prog.map g).toBits s).run τ = some (y, rest)) :
    ∃ a, (prog.toBits s).run τ = some (a, rest) ∧ y = g a := by
  rw [DrawProg.toBits_map, BitProg.run_map] at h
  cases h' : (prog.toBits s).run τ with
  | none => rw [h'] at h; cases h
  | some r =>
    rw [h'] at h
    simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at h
    exact ⟨r.1, by rw [← h.2], h.1.symm⟩

theorem run_toBits_ret_some {α : Type} {s : NoiseKind → BitProg ℤ} {a : α} {τ : List Bool} {x : α}
    {rest : List Bool} (h : ((DrawProg.ret a : NoiseProg α).toBits s).run τ = some (x, rest)) :
    x = a ∧ rest = τ := by
  simp only [DrawProg.toBits_ret, BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at h
  exact ⟨h.1.symm, h.2.symm⟩

theorem run_drawNoise_bind_some {α : Type} {s : NoiseKind → BitProg ℤ} {κ : NoiseKind}
    {f : ℤ → NoiseProg α} {τ : List Bool} {x : α} {rest : List Bool}
    (h : (((drawNoise κ).bind f).toBits s).run τ = some (x, rest)) :
    ∃ k τ1, (s κ).run τ = some (k, τ1) ∧ ((f k).toBits s).run τ1 = some (x, rest) := by
  have e : ((drawNoise κ).bind f).toBits s = (s κ).bind fun b => (f b).toBits s := rfl
  rw [e] at h
  exact run_bind_some h

/-! ## The correspondences -/

/-- The parameter records agree. -/
structure ParCorr (P2 : F2e2e.Alg2Params) (P : AdaParams) : Prop where
  hM : P2.M = P.M
  hJ : P2.J = P.J
  hR : P2.R = P.R
  hp : P2.p = P.p
  hblen : P.blockSizes.length = P.p + 1
  hn : ∀ j ≤ P.p, P2.n j = P.blockSizes.getD j 0
  hTlen : P.Tmax.length = P.p
  hTmax : ∀ j, P2.Tmax j = P.Tmax.getD j 0
  ha : P2.a = (P.a : ℝ)
  htau : P2.tau = (P.tau : ℝ)
  hkappa : P2.kappa = (P.kappa : ℝ)
  hhA : P2.hA = P.hA
  dIntThr : ∀ t, P2.draw (2 * P2.bInt) t = (adaDraw P NoiseKind.intThr).run t
  dIntTest : ∀ t, P2.draw (4 * P2.bInt) t = (adaDraw P NoiseKind.intTest).run t
  dOutThr : ∀ t, P2.draw (2 * P2.bOut) t = (adaDraw P NoiseKind.outThr).run t
  dOutTest : ∀ t, P2.draw (4 * P2.bOut) t = (adaDraw P NoiseKind.outTest).run t
  dNum : ∀ t, P2.draw P2.bNum t = (adaDraw P NoiseKind.num).run t

theorem ParCorr.offset_eq {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) {j : ℕ}
    (hj : j ≤ P.p + 1) : P2.offset j = (P.blockSizes.take j).sum := by
  unfold F2e2e.Alg2Params.offset
  rw [← sum_range_getD]
  exact Finset.sum_congr rfl fun j' hj' => hP.hn j' (by rw [Finset.mem_range] at hj'; omega)

theorem ParCorr.fuel_eq {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P) :
    P2.fuel = P.fuel := by
  unfold F2e2e.Alg2Params.fuel AdaParams.fuel
  congr 1
  rw [hP.hp, Finset.sum_congr rfl fun j _ => hP.hTmax j, sum_range_getD, ← hP.hTlen, List.take_length]

/-- The Spec's rounded evaluations are `h_A` times the core's block-structured grid indices. -/
structure ValsCorr (P : AdaParams) (fv : ℕ → ℝ) (vals : List (List ℕ)) : Prop where
  len : ∀ j ≤ P.p, (vals.getD j []).length = P.blockSizes.getD j 0
  le : ∀ j ≤ P.p, ∀ x ∈ vals.getD j [], x ≤ 2 ^ P.qA
  eq : ∀ j ≤ P.p, ∀ i < P.blockSizes.getD j 0,
    fv ((P.blockSizes.take j).sum + i) = (P.hA : ℝ) * ((vals.getD j []).getD i 0 : ℝ)

/-- The states agree. -/
structure StCorr (P : AdaParams) (st2 : F2e2e.Alg2State) (st : AdaState) : Prop where
  slen : st.scores.length = P.p
  wlen : st.weights.length = P.p
  blen : ∀ j < P.p, (st.scores.getD j []).length = P.blockSizes.getD j 0
  w : ∀ j < P.p, st.weights.getD j [] = capWeightsQ (scoreScale P) (st.scores.getD j [])
  Tlen : st.T.length = P.p
  thrlen : st.thrInt.length = P.p
  G : ∀ j < P.p, ∀ i < P.blockSizes.getD j 0,
    st2.G j i = (P.hA : ℝ) / 4 * ((st.scores.getD j []).getD i 0 : ℝ)
  T : ∀ j, st2.T j = st.T.getD j 0
  thr : ∀ j, st2.thrInt j = st.thrInt.getD j 0
  thrOut : st2.thrOut = st.thrOut
  rej : st2.rej = st.rej
  nInt : st2.nInt = st.nInt
  nNum : st2.nNum = st.nNum
  halted : st2.halted = st.halted
  aborted : st2.aborted = st.capAborted

/-! ## Learner weights and predictions -/

/-- The Spec's learner weights (ε-choice of a maximizer over `W_j`) are the core's exact weights. -/
theorem v2LearnerWeights_eq {n : ℕ} (κ : ℝ) (G : Fin n → ℝ) (c : ℚ) (g : List ℤ)
    (hg : g.length = n) (hcG : ∀ i : Fin n, κ * G i = (c : ℝ) * (g.getD i 0 : ℝ)) :
    F2e2e.learnerWeights n κ G = fun i : Fin n => (((capWeightsQ c g).getD (i : ℕ) 0 : ℚ) : ℝ) := by
  subst hg
  rcases Nat.eq_zero_or_pos g.length with h0 | hpos
  · funext i
    exact absurd i.isLt (by omega)
  have hne : g ≠ [] := List.ne_nil_of_length_pos hpos
  rw [capWeightsQ_spec c g hne]
  set G' : Fin g.length → ℝ := fun i => ((g.get i : ℤ) : ℝ) with hG'
  have hobj : ∀ u : Fin g.length → ℝ, F2e2e.learnerObjective g.length κ G u =
      F2e2e.Opt.Quad.quadObj g.length (c : ℝ) G' u := by
    intro u
    unfold F2e2e.learnerObjective F2e2e.Opt.Quad.quadObj F2e2e.quadReg F2e2e.Opt.Quad.quadReg
    congr 1
    rw [Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [← mul_assoc, hcG i, hG']
    simp only [List.get_eq_getElem]
    rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem i.isLt, Option.getD_some]
    ring
  have hset : F2e2e.capSimplex8 g.length = F2e2e.Opt.Quad.cappedSimplex g.length 8 := rfl
  have hmem := F2e2e.Opt.Quad.learnerWeights_mem hpos (by norm_num : (1 : ℝ) ≤ 8) (c : ℝ) G'
  have hmax := F2e2e.Opt.Quad.learnerWeights_isMax hpos (by norm_num : (1 : ℝ) ≤ 8) (c : ℝ) G'
  have hex : ∃ w : Fin g.length → ℝ, w ∈ F2e2e.capSimplex8 g.length ∧
      ∀ v ∈ F2e2e.capSimplex8 g.length, F2e2e.learnerObjective g.length κ G v ≤
        F2e2e.learnerObjective g.length κ G w := by
    refine ⟨F2e2e.Opt.Quad.learnerWeights g.length 8 (c : ℝ) G', by rw [hset]; exact hmem,
      fun v hv => ?_⟩
    rw [hobj, hobj]
    exact hmax v (by rw [← hset]; exact hv)
  have hspec := Classical.epsilon_spec hex
  unfold F2e2e.learnerWeights
  refine F2e2e.Opt.Quad.eq_learnerWeights_of_isMax hpos (by norm_num : (1 : ℝ) ≤ 8) (c : ℝ) G'
    (by rw [← hset]; exact hspec.1) fun u hu => ?_
  rw [← hobj, ← hobj]
  exact hspec.2 u (by rw [hset]; exact hu)

theorem adaMus_getD (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) {j : ℕ} (hj : j ≤ P.p) :
    (adaMus P st vals).getD j 0 =
      if j < P.p then predLearned P.hA (st.weights.getD j []) (blockVals P vals j)
      else predAnchor P.hA (P.blockSizes.getD j 0) (blockVals P vals j) := by
  unfold adaMus
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range (by omega)]
  rfl

theorem blockVals_eq {P : AdaParams} {fv : ℕ → ℝ} {vals : List (List ℕ)} (hv : ValsCorr P fv vals)
    {j : ℕ} (hj : j ≤ P.p) : blockVals P vals j = vals.getD j [] := by
  unfold blockVals
  conv_rhs => rw [← List.map_id (vals.getD j [])]
  exact List.map_congr_left fun x hx => min_eq_left (hv.le j hj x hx)

theorem predAnchor_eq (hA : ℚ) (np : ℕ) (v : List ℕ) (n : ℕ) (hv : v.length = n) :
    predAnchor hA np v = hA * ((∑ i : Fin n, (v.getD i 0 : ℚ)) / np) := by
  unfold predAnchor
  rw [sum_map_cast_eq v n hv]

/-- **The predictions agree.** -/
theorem alg2Mu_eq {P2 : F2e2e.Alg2Params} {P : AdaParams} (hP : ParCorr P2 P)
    {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr P st2 st) {fv : ℕ → ℝ}
    {vals : List (List ℕ)} (hv : ValsCorr P fv vals) {j : ℕ} (hj : j ≤ P.p) :
    F2e2e.alg2Mu P2 st2 fv j = (((adaMus P st vals).getD j 0 : ℚ) : ℝ) := by
  rw [adaMus_getD P st vals hj, blockVals_eq hv hj]
  unfold F2e2e.alg2Mu
  rw [hP.hp, hP.offset_eq (by omega), hP.hn j hj]
  have hvl := hv.len j hj
  by_cases hjp : j < P.p
  · rw [if_pos hjp, if_pos hjp]
    have hgl := hst.blen j hjp
    have hw : F2e2e.learnerWeights (P.blockSizes.getD j 0) P2.kappa (fun i' => st2.G j (i' : ℕ)) =
        fun i : Fin (P.blockSizes.getD j 0) =>
          (((capWeightsQ (scoreScale P) (st.scores.getD j [])).getD (i : ℕ) 0 : ℚ) : ℝ) := by
      refine v2LearnerWeights_eq _ _ _ _ hgl fun i => ?_
      rw [hst.G j hjp i i.isLt, hP.hkappa]
      unfold scoreScale
      push_cast
      ring
    rw [hw, hst.w j hjp]
    unfold predLearned
    rw [sum_zipWith_eq _ _ (P.blockSizes.getD j 0) (by rw [capWeightsQ_length, hgl]) hvl]
    push_cast
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [hv.eq j hj i i.isLt]
    ring
  · rw [if_neg hjp, if_neg hjp, predAnchor_eq _ _ _ _ hvl]
    push_cast
    rw [Finset.sum_congr rfl fun (i : Fin (P.blockSizes.getD j 0)) _ => hv.eq j hj i i.isLt,
      ← Finset.mul_sum]
    ring

end F2e2e.B.V2
