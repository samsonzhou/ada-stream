import F2e2e.B.Params

/-!
# Part II, Definition `R:def:sec3_ada_params`: the computable (exact integer/rational) form

The mechanism of Algorithm `R:alg:sec3_validation_ada` is a computable state machine
(`F2e2e/B/ArchCore.lean`); its parameters are computed here from the natural numbers
`(eA, eXi, M, J, R)`, where `a = 2^{-eA}` and `ξ_A = 2^{-eXi}` are the dyadic inputs of
`R:eq:sec3_dyadic_inputs` (`parts/partII.tex` L668–670), in exact `ℕ`/`ℚ` arithmetic.

Once `a = 2^{-eA}` and `ξ_A = 2^{-eXi}` are substituted, every ceiling of Definition 3.1 is an exact
integer operation:
* `p`: `4^{p-1}(a/(8p))² ≥ 1 ⟺ p · 2^{eA+3} ≤ 2^{p-1}` (`adaP`, by `Nat.find`);
* `1/h = 512 p 2^{eA}` is a natural number (`adaHInv`), so `n_j` and `d_p = 4/h` are naturals;
* `2^40 (p+1) Q/(h ξ_A) = 2^{49+eA+eXi} p (p+1) Q`, so `χ = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉`
  (`adaChi`);
* `⌈√m⌉` for natural `m` is `ceilSqrt m` (via `Nat.sqrt`);
* `h_A = 2^{-q_A}` with `q_A = max(29 + eA + ⌈log₂(p(p+1)χ)⌉, 20 + ⌈log₂ max_j n_j⌉)` (`adaQA`);
* `T_j^max = ⌈6/(4^j τ²)⌉`, `B_0 = ⌈log₂(16/ζ)⌉`, `K_s`, `r_s` are ceilings of rationals.

The bridge lemmas (`adaP_eq`, `adaChi_eq`, `adaNBlock_eq`, `adaParams_N_eq`, …, in
`F2e2e/B/ArchParamsBridge.lean`) identify these values with the paper form of `F2e2e/B/Params.lean`
at `eA = dyadicExp aReq`, `eXi = dyadicExp ξReq`.
-/

namespace F2e2e.B

/-! ## Exact integer helpers -/

/-- `⌈√m⌉` for a natural number `m`. -/
def ceilSqrt (m : ℕ) : ℕ := if Nat.sqrt m * Nat.sqrt m = m then Nat.sqrt m else Nat.sqrt m + 1

/-! ## The level count `p` -/

/-- Existence of a level count: `p = 2^{eA+3}` satisfies `p · 2^{eA+3} ≤ 2^{p-1}`. -/
theorem exists_adaP (eA : ℕ) : ∃ p : ℕ, 2 ≤ p ∧ p * 2 ^ (eA + 3) ≤ 2 ^ (p - 1) := by
  refine ⟨2 ^ (eA + 3), ?_, ?_⟩
  · calc 2 ≤ 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (eA + 3) := Nat.pow_le_pow_right (by norm_num) (by omega)
  · have hlt : eA < 2 ^ eA := Nat.lt_two_pow_self
    have h8 : 2 ^ (eA + 3) = 8 * 2 ^ eA := by rw [pow_add]; ring
    rw [← pow_add]
    apply Nat.pow_le_pow_right (by norm_num)
    omega

/-- The number of learned levels: the least `p ≥ 2` with `4^{p-1}(a/(8p))² ≥ 1`, i.e. with
`p · 2^{eA+3} ≤ 2^{p-1}` for `a = 2^{-eA}`. -/
def adaP (eA : ℕ) : ℕ := Nat.find (exists_adaP eA)

/-! ## Margins and caps -/

/-- `a = 2^{-eA}`. -/
def adaA (eA : ℕ) : ℚ := (1 / 2) ^ eA

/-- `ξ_A = 2^{-eXi}`. -/
def adaXiA (eXi : ℕ) : ℚ := (1 / 2) ^ eXi

/-- `τ = a/(8p)`. -/
def adaTauQ (eA : ℕ) : ℚ := adaA eA / (8 * adaP eA)

/-- `h = τ/64`. -/
def adaH (eA : ℕ) : ℚ := adaTauQ eA / 64

/-- `1/h = 512 p 2^{eA}` (a natural number). -/
def adaHInv (eA : ℕ) : ℕ := 512 * adaP eA * 2 ^ eA

/-- `κ = τ/4`. -/
def adaKappa (eA : ℕ) : ℚ := adaTauQ eA / 4

/-- `T_j^max = ⌈6/(4^j τ²)⌉` for `j < p`, and `0` out of range. -/
def adaTmax (eA : ℕ) (j : ℕ) : ℕ :=
  if j < adaP eA then ⌈(6 : ℚ) / (4 ^ j * adaTauQ eA ^ 2)⌉₊ else 0

/-- `T_j^max` for an integer index (zero for `j < 0`). -/
def adaTmaxZ (eA : ℕ) (j : ℤ) : ℕ := if 0 ≤ j then adaTmax eA j.toNat else 0

/-- The list `[T_0^max, …, T_{p-1}^max]`. -/
def adaTmaxList (eA : ℕ) : List ℕ := (List.range (adaP eA)).map (adaTmax eA)

/-- `C_0, C_j, C_p` of `R:eq:sec3_C_Q_chi` (and `0` for `j > p`). -/
def adaC (J R eA : ℕ) (j : ℕ) : ℕ :=
  if j = 0 then adaTmax eA 0 + adaTmax eA 1 + J + R + 2
  else if j < adaP eA then
    adaTmaxZ eA ((j : ℤ) - 2) + 2 * adaTmaxZ eA ((j : ℤ) - 1) + 2 * adaTmax eA j +
      adaTmax eA (j + 1) + 2
  else if j = adaP eA then adaTmaxZ eA ((j : ℤ) - 2) + adaTmaxZ eA ((j : ℤ) - 1) + 1
  else 0

/-- `Q = 100 (p+1)(M + R + J + 2 + ∑_{j<p} T_j^max)`. -/
def adaQ (M J R eA : ℕ) : ℕ := 100 * (adaP eA + 1) * (M + R + J + 2 + (adaTmaxList eA).sum)

/-- `χ = ⌈log₂(2^40 (p+1) Q/(h ξ_A))⌉ = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉`. -/
def adaChi (M J R eA eXi : ℕ) : ℕ :=
  49 + eA + eXi + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaQ M J R eA)

/-- `ξ_j = ξ_A/(8(p+1))`. -/
def adaXiJ (eA eXi : ℕ) : ℚ := adaXiA eXi / (8 * (adaP eA + 1))

/-- `δ = h ξ_j/24`. -/
def adaDelta (eA eXi : ℕ) : ℚ := adaH eA * adaXiJ eA eXi / 24

/-- `d_j = ⌈√(p 4^j)⌉` for `j < p`, `d_p = ⌈4/h⌉ = 2^{eA+11} p`. -/
def adaD (eA : ℕ) (j : ℕ) : ℕ :=
  if j < adaP eA then ceilSqrt (adaP eA * 4 ^ j) else 2 ^ (eA + 11) * adaP eA

/-- `n_j = ⌈2^20 χ d_j ⌈√(C_j χ)⌉/h + 2^12 χ/h²⌉`, an exact natural number since `1/h ∈ ℕ`. -/
def adaNBlock (M J R eA eXi : ℕ) (j : ℕ) : ℕ :=
  2 ^ 20 * adaChi M J R eA eXi * adaD eA j * ceilSqrt (adaC J R eA j * adaChi M J R eA eXi) *
      adaHInv eA +
    2 ^ 12 * adaChi M J R eA eXi * adaHInv eA ^ 2

/-- `[n_0, …, n_p]`. -/
def adaBlockSizes (M J R eA eXi : ℕ) : List ℕ :=
  (List.range (adaP eA + 1)).map (adaNBlock M J R eA eXi)

/-- `max_j n_j`. -/
def adaMaxN (M J R eA eXi : ℕ) : ℕ := (adaBlockSizes M J R eA eXi).foldl max 0

/-- `q_A` with `h_A = 2^{-q_A}` the largest power of two `≤ min{h/(2^20(p+1)χ), 1/(2^20 max_j n_j)}`. -/
def adaQA (M J R eA eXi : ℕ) : ℕ :=
  max (29 + eA + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaChi M J R eA eXi))
    (20 + Nat.clog 2 (adaMaxN M J R eA eXi))

/-- `ζ = δ/(1000 Q)`. -/
def adaZeta (M J R eA eXi : ℕ) : ℚ := adaDelta eA eXi / (1000 * adaQ M J R eA)

/-- `B_0 = ⌈log₂(16/ζ)⌉`. -/
def adaB0 (M J R eA eXi : ℕ) : ℕ := Nat.clog 2 ⌈(16 : ℚ) / adaZeta M J R eA eXi⌉₊

/-! ## The parameter record of one mechanism instance -/

/-- The five kinds of lattice-noise draws of Algorithm 2 (L750, L775): the persistent threshold of
an internal edge phase, a directed test noise of an internal edge, the persistent outer threshold,
an outer directed test noise, a numerical release noise. -/
inductive NoiseKind where
  | intThr : NoiseKind
  | intTest : NoiseKind
  | outThr : NoiseKind
  | outTest : NoiseKind
  | num : NoiseKind
  deriving DecidableEq, Repr

/-- The parameters read by the mechanism (Definition `R:def:sec3_ada_params`). -/
structure AdaParams where
  /-- interval-request cap `M` -/
  M : ℕ
  /-- nonterminal-rejection cap `J` -/
  J : ℕ
  /-- numerical-request cap `R` -/
  R : ℕ
  /-- number of learned levels `p` (blocks `0..p-1` learn, block `p` is the anchor) -/
  p : ℕ
  /-- block sizes `[n_0, …, n_p]` -/
  blockSizes : List ℕ
  /-- correction caps `[T_0^max, …, T_{p-1}^max]` -/
  Tmax : List ℕ
  /-- dyadic accuracy `a` -/
  a : ℚ
  /-- edge margin `τ = a/(8p)` -/
  tau : ℚ
  /-- learner step `κ = τ/4` -/
  kappa : ℚ
  /-- lattice exponent: `h_A = 2^{-qA}` -/
  qA : ℕ
  /-- internal noise scale `b_int` (thresholds `2 b_int`, directed tests `4 b_int`) -/
  bInt : ℚ
  /-- outer noise scale `b_out` (threshold `2 b_out`, directed tests `4 b_out`) -/
  bOut : ℚ
  /-- numerical noise scale `b_num` -/
  bNum : ℚ
  /-- per-draw coupling budget `ζ = δ/(1000 Q)` -/
  zeta : ℚ
  /-- `B_0 = ⌈log₂(16/ζ)⌉` -/
  B0 : ℕ

namespace AdaParams

/-- The lattice step `h_A = 2^{-qA}`. -/
def hA (P : AdaParams) : ℚ := (1 / 2) ^ P.qA

/-- The sample size `N = ∑_{j=0}^p n_j`. -/
def N (P : AdaParams) : ℕ := P.blockSizes.sum

/-- The pass budget of `PrepareRoot`: `1 + ∑_j T_j^max` scan passes. -/
def fuel (P : AdaParams) : ℕ := 1 + P.Tmax.sum

/-- The noise scale of each kind of draw (L750, L775): internal thresholds `2 b_int`, internal
directed tests `4 b_int`, outer threshold `2 b_out`, outer directed tests `4 b_out`, numerical
releases `b_num`. -/
def scale (P : AdaParams) : NoiseKind → ℚ
  | NoiseKind.intThr => 2 * P.bInt
  | NoiseKind.intTest => 4 * P.bInt
  | NoiseKind.outThr => 2 * P.bOut
  | NoiseKind.outTest => 4 * P.bOut
  | NoiseKind.num => P.bNum

/-- The geometric ratio `ϱ = b/(b + h_A)` of the ideal lattice law of scale `b`. -/
def rho (P : AdaParams) (b : ℚ) : ℚ := b / (b + P.hA)

/-- The count truncation `K_s = ⌈((b + h_A)/h_A) B_0⌉` of a draw of scale `b`. -/
def Ks (P : AdaParams) (b : ℚ) : ℕ := ⌈(b + P.hA) / P.hA * P.B0⌉₊

/-- The trial cap `r_s = ⌈log₂(32(K_s + 1)/ζ)⌉` of a draw of scale `b`. -/
def rs (P : AdaParams) (b : ℚ) : ℕ := Nat.clog 2 ⌈32 * ((P.Ks b : ℚ) + 1) / P.zeta⌉₊

/-- Worst-case fresh bits of one bounded-sampler draw of scale `b`: `2 K_s r_s ⌈log₂ D_ϱ⌉`. -/
def drawBits (P : AdaParams) (b : ℚ) : ℕ := 2 * P.Ks b * (P.rs b * Nat.clog 2 (P.rho b).den)

/-- Worst-case fresh bits of one draw of any of the five kinds used by the mechanism. -/
def maxDrawBits (P : AdaParams) : ℕ :=
  P.drawBits (P.scale NoiseKind.intThr) + P.drawBits (P.scale NoiseKind.intTest) +
    P.drawBits (P.scale NoiseKind.outThr) + P.drawBits (P.scale NoiseKind.outTest) +
    P.drawBits (P.scale NoiseKind.num)

end AdaParams

/-- The parameters of the mechanism for `a = 2^{-eA}`, `ξ_A = 2^{-eXi}` and caps `M, J, R`
(Definition `R:def:sec3_ada_params`, exact form). -/
def adaParams (eA eXi M J R : ℕ) : AdaParams where
  M := M
  J := J
  R := R
  p := adaP eA
  blockSizes := adaBlockSizes M J R eA eXi
  Tmax := adaTmaxList eA
  a := adaA eA
  tau := adaTauQ eA
  kappa := adaKappa eA
  qA := adaQA M J R eA eXi
  bInt := adaH eA / (128 * adaChi M J R eA eXi)
  bOut := adaA eA / (512 * adaChi M J R eA eXi)
  bNum := adaA eA / (64 * adaChi M J R eA eXi)
  zeta := adaZeta M J R eA eXi
  B0 := adaB0 M J R eA eXi

/-! ## Bridges to the paper form (`F2e2e/B/Params.lean`)

At `eA = dyadicExp aReq` and `eXi = dyadicExp ξReq`. The remaining bridge lemmas (`adaP_eq`,
`adaChi_eq`, `adaNBlock_eq`, `adaParams_N_eq`, …) are in `F2e2e/B/ArchParamsBridge.lean`. -/

theorem adaA_cast (aReq : ℝ) : ((adaA (dyadicExp aReq) : ℚ) : ℝ) = alg2A aReq := by
  simp [adaA, alg2A, dyadicDown]

theorem adaXiA_cast (ξReq : ℝ) : ((adaXiA (dyadicExp ξReq) : ℚ) : ℝ) = alg2XiA ξReq := by
  simp [adaXiA, alg2XiA, dyadicDown]

end F2e2e.B
