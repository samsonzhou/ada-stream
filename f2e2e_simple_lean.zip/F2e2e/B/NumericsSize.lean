import F2e2e.B.NumericsCert

/-!
# Part II numerics (B-NUM), part 6: block sizes, edge caps and bit sizes

* `eight_le_alg2NBlock`: `n_j ≥ 8` (hypothesis of Lemma `R:lem:sec3_kkt_sensitivity`; Definition 3.1
  numeric fact "`n_j ≥ 2^12χ/h² ≥ 8`").
* `numEdgeCap` (`C_{edge,r} = 1 + T_{r-1}^max + T_r^max + T_{r+1}^max`, proof of Theorem
  `R:thm:validation_ada`, "Counts", L974–977) and the identities `alg2C_zero_eq_edgeCap`
  (`C_0 = C_{edge,0} + (J+1) + R`), `alg2C_mid_eq_edgeCap` (`C_j = C_{edge,j-1} + C_{edge,j}`),
  `alg2C_p_eq_edgeCap` (`C_p = C_{edge,p-1}`): "summing the two edge counts gives exactly the `C_j` of
  Definition 3.1".
* Bit sizes (proof of Theorem `R:thm:validation_ada`, "Samples and memory", L1054: "`log n_j ≤ 16χ` and
  `log(1/h_A) ≤ 32χ`"): `alg2NBlock_le_two_pow` (`n_j ≤ 2^{8χ} ≤ 2^{16χ}`), `alg2HAExp_le`
  (`log₂(1/h_A) = q_A ≤ 9χ ≤ 32χ`), with the intermediate `one_div_alg2H_le` (`1/h ≤ 2^χ/2^50`),
  `alg2C_le_big` (`C_j ≤ 191·4^χ`), `alg2D_le_big` (`d_j ≤ 5·4^χ`).
-/

namespace F2e2e.B

/-- `n_j ≥ 8`. -/
theorem eight_le_alg2NBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) : 8 ≤ alg2NBlock M J R aReq ξReq j := by
  have h := second_term_le_alg2NBlock M J R aReq ξReq j
  have hχ := one_le_alg2Chi_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have h2 : (8 : ℝ) ≤ 2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 := by
    rw [le_div_iff₀ (by positivity)]
    have : alg2H aReq ^ 2 ≤ 1 := by nlinarith
    nlinarith
  exact_mod_cast h2.trans h

/-! ### Edge phase caps -/

/-- The phase cap of edge `r`: `C_{edge,r} = 1 + T_{r-1}^max + T_r^max + T_{r+1}^max` (out-of-range caps
are `0`). -/
noncomputable def numEdgeCap (aReq : ℝ) (r : ℕ) : ℕ :=
  1 + alg2TmaxZ aReq ((r : ℤ) - 1) + alg2Tmax aReq r + alg2Tmax aReq (r + 1)

/-- `C_0 = C_{edge,0} + (J+1) + R` (edge 0, the `≤ J+1` outer phases and the `R` numerical releases). -/
theorem alg2C_zero_eq_edgeCap (J R : ℕ) (aReq : ℝ) :
    alg2C J R aReq 0 = numEdgeCap aReq 0 + (J + 1) + R := by
  have hp := two_le_alg2P aReq
  rw [alg2C_zero_eq]
  unfold numEdgeCap
  simp only [Nat.cast_zero, zero_sub, Nat.zero_add]
  rw [alg2TmaxZ_of_neg (by norm_num), alg2Tmax_of_lt (by omega), alg2Tmax_of_lt (by omega)]
  omega

/-- `C_j = C_{edge,j-1} + C_{edge,j}` for `1 ≤ j < p`. -/
theorem alg2C_mid_eq_edgeCap (J R : ℕ) {aReq : ℝ} {j : ℕ} (hj1 : 1 ≤ j) (hjp : j < alg2P aReq) :
    alg2C J R aReq j = numEdgeCap aReq (j - 1) + numEdgeCap aReq j := by
  rw [alg2C_mid_eq J R hj1 hjp]
  unfold numEdgeCap
  have e1 : (((j - 1 : ℕ) : ℤ) - 1) = (j : ℤ) - 2 := by omega
  have e2 : j - 1 + 1 = j := by omega
  rw [e1, e2, alg2TmaxZ_sub_one hj1]
  omega

/-- `C_p = C_{edge,p-1}`. -/
theorem alg2C_p_eq_edgeCap (J R : ℕ) (aReq : ℝ) :
    alg2C J R aReq (alg2P aReq) = numEdgeCap aReq (alg2P aReq - 1) := by
  have hp := two_le_alg2P aReq
  rw [alg2C_p_eq]
  unfold numEdgeCap
  have e1 : (((alg2P aReq - 1 : ℕ) : ℤ) - 1) = (((alg2P aReq - 2 : ℕ) : ℤ)) := by omega
  have e2 : alg2P aReq - 1 + 1 = alg2P aReq := by omega
  rw [e1, e2, alg2TmaxZ_natCast, alg2Tmax_of_lt (by omega), alg2Tmax_of_lt (by omega),
    alg2Tmax_of_ge (le_refl _)]
  omega

/-! ### Bit sizes -/

/-- `chiArg ≥ 2^50/h` and hence `1/h ≤ 2^χ/2^50`. -/
theorem one_div_alg2H_le (M J R : ℕ) (aReq ξReq : ℝ) :
    1 / alg2H aReq ≤ (2 : ℝ) ^ alg2Chi M J R aReq ξReq / 2 ^ 50 := by
  have h1 := chiArg_ge M J R (alg2A_pos aReq) (alg2XiA_pos ξReq) (alg2XiA_le_one ξReq)
  have h2 := chiArg_le_two_pow_valChi M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change chiArg M J R (alg2A aReq) (alg2XiA ξReq) ≤ 2 ^ alg2Chi M J R aReq ξReq at h2
  have hih := one_div_alg2H aReq
  change 2 ^ 40 * 1800 * (512 * (alg2P aReq : ℝ) / alg2A aReq) ≤ chiArg M J R (alg2A aReq) (alg2XiA ξReq)
    at h1
  rw [← hih] at h1
  have hh := alg2H_pos aReq
  have hpos : 0 ≤ 1 / alg2H aReq := by positivity
  rw [le_div_iff₀ (by norm_num)]
  nlinarith

/-- `J + R + 1 ≤ Q ≤ arg ≤ 2^χ`. -/
theorem K_le_two_pow_chi (M J R : ℕ) (aReq ξReq : ℝ) :
    (J : ℝ) + R + 1 ≤ (2 : ℝ) ^ alg2Chi M J R aReq ξReq := by
  have h2 := chiArg_le_two_pow_valChi M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change chiArg M J R (alg2A aReq) (alg2XiA ξReq) ≤ 2 ^ alg2Chi M J R aReq ξReq at h2
  have hQ : (J : ℝ) + R + 1 ≤ alg2Q M J R aReq := by
    have hc := valQ_cast M J R (alg2A aReq)
    change (alg2Q M J R aReq : ℝ) = _ at hc
    have hs : (0 : ℝ) ≤ ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ) :=
      Finset.sum_nonneg (fun _ _ => Nat.cast_nonneg _)
    have hp' : (0 : ℝ) ≤ valP (alg2A aReq) := Nat.cast_nonneg _
    have hM : (0 : ℝ) ≤ M := Nat.cast_nonneg _
    rw [hc]
    nlinarith
  have hQarg : (alg2Q M J R aReq : ℝ) ≤ chiArg M J R (alg2A aReq) (alg2XiA ξReq) := by
    have hh := alg2H_pos aReq
    have hh1 := alg2H_le_one aReq
    have hξ := alg2XiA_pos ξReq
    have hξ1 := alg2XiA_le_one ξReq
    have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
    have hQ0 := alg2Q_pos_real M J R aReq
    unfold chiArg
    change (alg2Q M J R aReq : ℝ) ≤
      2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) / (alg2H aReq * alg2XiA ξReq)
    rw [le_div_iff₀ (by positivity)]
    have : alg2H aReq * alg2XiA ξReq ≤ 1 := by nlinarith
    nlinarith
  linarith

/-- `1/τ ≤ 1/h`. -/
theorem one_div_alg2Tau_le (aReq : ℝ) : 1 / alg2Tau aReq ≤ 1 / alg2H aReq := by
  have hτ := alg2Tau_pos aReq
  rw [alg2H_eq_tau]
  apply one_div_le_one_div_of_le (by positivity)
  linarith

/-- `C_j ≤ 190/h² + (J+R+1)` for `j ≤ p`. -/
theorem alg2C_le_inv_h_sq (J R : ℕ) (aReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    (alg2C J R aReq j : ℝ) ≤ 190 * (1 / alg2H aReq) ^ 2 + ((J : ℝ) + R + 1) := by
  have hτh := one_div_alg2Tau_le aReq
  have hτ := alg2Tau_pos aReq
  have hτ2 : 1 / alg2Tau aReq ^ 2 ≤ (1 / alg2H aReq) ^ 2 := by
    rw [← one_div_pow]
    exact pow_le_pow_left₀ (by positivity) hτh 2
  have hK : (0 : ℝ) ≤ (J : ℝ) + R + 1 := by positivity
  rcases Nat.eq_zero_or_pos j with h0 | hpos
  · subst h0
    have h := alg2C_zero_le_ten J R aReq
    have : 10 / alg2Tau aReq ^ 2 ≤ 190 * (1 / alg2H aReq) ^ 2 := by
      rw [show 10 / alg2Tau aReq ^ 2 = 10 * (1 / alg2Tau aReq ^ 2) by ring]
      nlinarith
    linarith
  · rcases Nat.lt_or_ge j (alg2P aReq) with hlt | hge
    · have h := alg2C_mid_lt J R hpos hlt
      have hv : 1 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) ≤ 1 / alg2Tau aReq ^ 2 := by
        apply one_div_le_one_div_of_le (by positivity)
        have : (1 : ℝ) ≤ 4 ^ j := one_le_pow₀ (by norm_num)
        nlinarith [sq_nonneg (alg2Tau aReq)]
      nlinarith
    · have hj' : j = alg2P aReq := le_antisymm hj hge
      subst hj'
      have h := alg2C_p_le J R aReq
      have h' : (alg2C J R aReq (alg2P aReq) : ℝ) ≤ 31 := by exact_mod_cast h
      have hh := alg2H_pos aReq
      have hh1 := alg2H_le_one aReq
      have : (1 : ℝ) ≤ 1 / alg2H aReq := by rw [le_div_iff₀ hh]; linarith
      nlinarith

/-- `d_j ≤ 5/h²` for `j ≤ p`. -/
theorem alg2D_le_inv_h_sq (aReq : ℝ) (j : ℕ) :
    (alg2D aReq j : ℝ) ≤ 5 * (1 / alg2H aReq) ^ 2 := by
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have hu1 : (1 : ℝ) ≤ 1 / alg2H aReq := by rw [le_div_iff₀ hh]; linarith
  have hih := one_div_alg2H aReq
  have ha := alg2A_pos aReq
  have ha1 := alg2A_le_one aReq
  have hp2 := two_le_alg2P_real aReq
  -- `p ≤ 1/h` and `2^p ≤ 1/h`
  have hpu : (alg2P aReq : ℝ) ≤ 1 / alg2H aReq := by
    rw [hih, le_div_iff₀ ha]
    nlinarith
  have h2p : (2 : ℝ) ^ alg2P aReq ≤ 1 / alg2H aReq := by
    have h := two_pow_valP_lt (alg2A_pos aReq) (by linarith)
    change (2 : ℝ) ^ alg2P aReq < 32 * (alg2P aReq : ℝ) / alg2A aReq at h
    have : 32 * (alg2P aReq : ℝ) / alg2A aReq ≤ 512 * (alg2P aReq : ℝ) / alg2A aReq := by
      apply div_le_div_of_nonneg_right _ ha.le
      linarith
    rw [hih]
    linarith
  rcases Nat.lt_or_ge j (alg2P aReq) with hlt | hge
  · have hD := alg2D_le_of_lt hlt
    have h2j : (2 : ℝ) ^ j ≤ 2 ^ alg2P aReq := pow_le_pow_right₀ (by norm_num) hlt.le
    have hsp : Real.sqrt (alg2P aReq) ≤ (alg2P aReq : ℝ) := by
      rw [Real.sqrt_le_left (by linarith)]
      nlinarith
    have h1 : (2 : ℝ) ^ j ≤ 1 / alg2H aReq := h2j.trans h2p
    have h2 : Real.sqrt (alg2P aReq) ≤ 1 / alg2H aReq := hsp.trans hpu
    have h3 : 2 * 2 ^ j * Real.sqrt (alg2P aReq) ≤ 2 * (1 / alg2H aReq) * (1 / alg2H aReq) := by
      gcongr
    nlinarith
  · have hD := alg2D_le_of_ge hge
    have : 5 / alg2H aReq = 5 * (1 / alg2H aReq) := by ring
    nlinarith

/-- `log₂ n_j ≤ 16χ`: `n_j ≤ 2^{16χ}` for `j ≤ p` (indeed `n_j ≤ 2^{8χ}`). -/
theorem alg2NBlock_le_two_pow (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    (alg2NBlock M J R aReq ξReq j : ℝ) ≤ (2 : ℝ) ^ (16 * alg2Chi M J R aReq ξReq) := by
  have hraw := alg2NBlock_le_raw M J R aReq ξReq hj
  set E := (2 : ℝ) ^ alg2Chi M J R aReq ξReq with hE
  have hχ := one_le_alg2Chi_real M J R aReq ξReq
  have hχ61 : 60 < alg2Chi M J R aReq ξReq :=
    sixty_lt_valChi M J R (alg2A_pos aReq) (alg2A_le_one aReq) (alg2XiA_pos ξReq)
      (alg2XiA_le_one ξReq)
  have hE60 : (2 : ℝ) ^ 60 ≤ E := pow_le_pow_right₀ (by norm_num) hχ61.le
  have hE1 : (1 : ℝ) ≤ E := le_trans (one_le_pow₀ (by norm_num)) hE60
  have hXE : (alg2Chi M J R aReq ξReq : ℝ) ≤ E := by
    have := Nat.lt_two_pow_self (n := alg2Chi M J R aReq ξReq)
    rw [hE]
    exact_mod_cast this.le
  have hu := one_div_alg2H_le M J R aReq ξReq
  rw [← hE] at hu
  have hh := alg2H_pos aReq
  have hu0 : 0 ≤ 1 / alg2H aReq := by positivity
  have huE : 1 / alg2H aReq ≤ E := by
    have : E / 2 ^ 50 ≤ E := by
      rw [div_le_iff₀ (by norm_num)]
      nlinarith
    linarith
  have hK := K_le_two_pow_chi M J R aReq ξReq
  rw [← hE] at hK
  have hC := alg2C_le_inv_h_sq J R aReq hj
  have hD := alg2D_le_inv_h_sq aReq j
  have hC1 : (1 : ℝ) ≤ alg2C J R aReq j := by exact_mod_cast one_le_alg2C J R aReq hj
  have hD0 : (0 : ℝ) ≤ alg2D aReq j := Nat.cast_nonneg _
  -- crude bounds in terms of `E`
  have hu2 : (1 / alg2H aReq) ^ 2 ≤ E ^ 2 := pow_le_pow_left₀ hu0 huE 2
  have hCE : (alg2C J R aReq j : ℝ) ≤ 191 * E ^ 2 := by nlinarith
  have hDE : (alg2D aReq j : ℝ) ≤ 5 * E ^ 2 := by nlinarith
  have hCX : (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) ≤ 191 * E ^ 3 := by
    have : (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) ≤ (191 * E ^ 2) * E :=
      mul_le_mul hCE hXE (by linarith) (by positivity)
    nlinarith
  have hsq : Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) ≤ 191 * E ^ 3 := by
    have h1 : 1 ≤ (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) := by nlinarith
    have h2 : Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) ≤
        (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) := by
      rw [Real.sqrt_le_left (by linarith)]
      nlinarith
    linarith
  have hfirst : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
      Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq ≤
      2 ^ 21 * 955 * E ^ 7 := by
    have e : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq =
        2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq) := by
      ring
    rw [e]
    calc 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
          Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq)
        ≤ 2 ^ 21 * E * (5 * E ^ 2) * (191 * E ^ 3) * E := by gcongr
      _ = 2 ^ 21 * 955 * E ^ 7 := by ring
  have hsecond : 2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 ≤ 2 ^ 12 * E ^ 3 := by
    have e : 2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 =
        2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) ^ 2 := by
      field_simp
    rw [e]
    calc 2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) ^ 2 ≤ 2 ^ 12 * E * E ^ 2 := by
          gcongr
      _ = 2 ^ 12 * E ^ 3 := by ring
  have hE7 : 2 ^ 21 * 955 * E ^ 7 + 2 ^ 12 * E ^ 3 + 1 ≤ E ^ 8 := by
    have h3 : 1 ≤ E ^ 3 := one_le_pow₀ hE1
    have h7 : E ^ 3 ≤ E ^ 7 := pow_le_pow_right₀ hE1 (by norm_num)
    have h8 : (2 : ℝ) ^ 33 * E ^ 7 ≤ E ^ 8 := by
      have : (2 : ℝ) ^ 33 ≤ E := le_trans (pow_le_pow_right₀ (by norm_num) (by norm_num)) hE60
      have h7pos : 0 ≤ E ^ 7 := by positivity
      calc (2 : ℝ) ^ 33 * E ^ 7 ≤ E * E ^ 7 := by gcongr
        _ = E ^ 8 := by ring
    nlinarith
  have hE8 : E ^ 8 ≤ (2 : ℝ) ^ (16 * alg2Chi M J R aReq ξReq) := by
    rw [hE, ← pow_mul]
    apply pow_le_pow_right₀ (by norm_num)
    omega
  linarith

/-- `log₂(1/h_A) ≤ 32χ`: `q_A ≤ 32χ` (indeed `≤ 9χ`). -/
theorem alg2HAExp_le (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HAExp M J R aReq ξReq ≤ 32 * alg2Chi M J R aReq ξReq := by
  set E := (2 : ℝ) ^ alg2Chi M J R aReq ξReq with hE
  have hχ := one_le_alg2Chi_real M J R aReq ξReq
  have hχ61 : 60 < alg2Chi M J R aReq ξReq :=
    sixty_lt_valChi M J R (alg2A_pos aReq) (alg2A_le_one aReq) (alg2XiA_pos ξReq)
      (alg2XiA_le_one ξReq)
  have hE60 : (2 : ℝ) ^ 60 ≤ E := pow_le_pow_right₀ (by norm_num) hχ61.le
  have hE1 : (1 : ℝ) ≤ E := le_trans (one_le_pow₀ (by norm_num)) hE60
  have hXE : (alg2Chi M J R aReq ξReq : ℝ) ≤ E := by
    have := Nat.lt_two_pow_self (n := alg2Chi M J R aReq ξReq)
    rw [hE]
    exact_mod_cast this.le
  have hu := one_div_alg2H_le M J R aReq ξReq
  rw [← hE] at hu
  have hh := alg2H_pos aReq
  have hu0 : 0 ≤ 1 / alg2H aReq := by positivity
  have huE : 1 / alg2H aReq ≤ E := by
    have : E / 2 ^ 50 ≤ E := by
      rw [div_le_iff₀ (by norm_num)]
      nlinarith
    linarith
  -- `max_j n_j ≤ E^8`
  have hmax : (alg2MaxN M J R aReq ξReq : ℝ) ≤ (2 : ℝ) ^ (16 * alg2Chi M J R aReq ξReq) := by
    obtain ⟨j, hjmem, hjeq⟩ := Finset.exists_mem_eq_sup (Finset.range (alg2P aReq + 1))
      ⟨0, Finset.mem_range.mpr (Nat.succ_pos _)⟩ (alg2NBlock M J R aReq ξReq)
    have hj : j ≤ alg2P aReq := Nat.lt_succ_iff.mp (Finset.mem_range.mp hjmem)
    unfold alg2MaxN
    rw [hjeq]
    exact alg2NBlock_le_two_pow M J R aReq ξReq hj
  have hp : (alg2P aReq : ℝ) + 1 ≤ 2 * (1 / alg2H aReq) := by
    have hih := one_div_alg2H aReq
    have ha := alg2A_pos aReq
    have ha1 := alg2A_le_one aReq
    have hp2 := two_le_alg2P_real aReq
    rw [hih, mul_div_assoc', le_div_iff₀ ha]
    nlinarith
  -- `1/bound ≤ 2^{32χ}`
  have hinv : (alg2HABound M J R aReq ξReq)⁻¹ ≤ (2 : ℝ) ^ (32 * alg2Chi M J R aReq ξReq) := by
    have hpos1 := alg2HABound_first_pos M J R aReq ξReq
    have hmax1 : (1 : ℝ) ≤ alg2MaxN M J R aReq ξReq := by
      exact_mod_cast one_le_alg2MaxN M J R aReq ξReq
    have hpos2 : 0 < 1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)) := by positivity
    unfold alg2HABound
    rcases le_total (alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
        (alg2Chi M J R aReq ξReq : ℝ))) (1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)))
      with hle | hle
    · rw [min_eq_left hle, inv_div]
      have e : (2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq =
          (2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) := by
        ring
      rw [e]
      have hb : (2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) *
          (1 / alg2H aReq) ≤ 2 ^ 20 * (2 * E) * E * E := by
        have hp0 : (0 : ℝ) ≤ (alg2P aReq : ℝ) + 1 := by positivity
        gcongr
        linarith
      have hE3 : (2 : ℝ) ^ 20 * (2 * E) * E * E ≤ E ^ 4 := by
        have : (2 : ℝ) ^ 21 ≤ E := le_trans (pow_le_pow_right₀ (by norm_num) (by norm_num)) hE60
        have h3 : 0 ≤ E ^ 3 := by positivity
        calc (2 : ℝ) ^ 20 * (2 * E) * E * E = 2 ^ 21 * E ^ 3 := by ring
          _ ≤ E * E ^ 3 := by gcongr
          _ = E ^ 4 := by ring
      have hE4 : E ^ 4 ≤ (2 : ℝ) ^ (32 * alg2Chi M J R aReq ξReq) := by
        rw [hE, ← pow_mul]
        apply pow_le_pow_right₀ (by norm_num)
        omega
      linarith
    · rw [min_eq_right hle, one_div, inv_inv]
      have hE16 : (2 : ℝ) ^ 20 * (2 : ℝ) ^ (16 * alg2Chi M J R aReq ξReq) ≤
          (2 : ℝ) ^ (32 * alg2Chi M J R aReq ξReq) := by
        rw [← pow_add]
        apply pow_le_pow_right₀ (by norm_num)
        omega
      have : (2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ) ≤
          (2 : ℝ) ^ 20 * (2 : ℝ) ^ (16 * alg2Chi M J R aReq ξReq) := by gcongr
      linarith
  -- `q_A = clog₂ ⌈1/bound⌉ ≤ 32χ`
  show Nat.clog 2 ⌈(alg2HABound M J R aReq ξReq)⁻¹⌉₊ ≤ 32 * alg2Chi M J R aReq ξReq
  apply Nat.clog_le_of_le_pow
  apply Nat.ceil_le.mpr
  have : ((2 ^ (32 * alg2Chi M J R aReq ξReq) : ℕ) : ℝ) = (2 : ℝ) ^ (32 * alg2Chi M J R aReq ξReq) := by
    push_cast
    rfl
  rw [this]
  exact hinv

end F2e2e.B
