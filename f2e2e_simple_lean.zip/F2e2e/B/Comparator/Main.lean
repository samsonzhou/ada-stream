import F2e2e.B.Comparator.Conc
import F2e2e.B.Comparator.BhatiaDavis
import F2e2e.Lib.DP.Defs

/-!
# Part II §2, Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` (L611–631)

The clipped sequential inverse-posterior comparator (the BNSSSU16-style transfer theorem consumed by
Section 3, proof of Theorem `R:thm:validation_ada`, "Transfer and accuracy", L1034).

Finite model (`F2e2e.B.Comparator.Defs`): `X ∼ D^r` on a finite `U` (any probability vector `D`, no
full-support assumption), a `(θ, δ)`-DP mechanism `T : (Fin r → U) → Ω → 𝒯` with finite coin space
`(Ω, w)` and arbitrary transcript type `𝒯`, a query-selection rule `q : 𝒯 → Fin k → U → ℝ` with
values in `[0, 1]`. The comparator `u = comparator D w T θ X (T X ω)` satisfies:

(i) for every realization: `u ∈ W_r`, `r uᵢ ∈ [e^{-2θ}, e^{2θ}] ⊂ [0, 8]` and
`R_r(u) ≤ ½ sinh²θ ≤ 0.691 θ² ≤ θ²` (`R:eq:L1_R_bound`);
(ii) with probability `≥ 1 - ξ`: `max_{t ≤ k} |∑ᵢ uᵢ f_t(Xᵢ) - D f_t| ≤ 2h/3 < h` (`R:eq:L1_acc_bound`),

provided `r ≥ 72 e^{2θ} h^{-2} log((k+2)/ξ)` and `δ ≤ hξ/24` (`R:eq:sec2_L1_scales`), `θ ∈ (0,1]`,
`h ∈ (0,1]`, `ξ ∈ (0,1)`.

Bridges: `finDP_iff_neighbor` (the DP condition with `F2e2e.DP.Neighbor`) and `finDP_of_isDP` (from
`F2e2e.DP.IsDP` for the finitely supported output laws `∑_ω w(ω) δ_{T x ω}`).
-/

namespace F2e2e.Comparator

open Finset Real MeasureTheory

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

/-! ### Bridges for the DP hypothesis -/

omit [Fintype U] in
/-- `FinDP` is DP with respect to `F2e2e.DP.Neighbor` (single-coordinate replacement). -/
theorem finDP_iff_neighbor (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ δ : ℝ) :
    FinDP w T θ δ ↔ ∀ S S' : Fin r → U, DP.Neighbor S S' → ∀ E : Set 𝒯,
      coinProb w (fun ω => T S ω ∈ E) ≤ Real.exp θ * coinProb w (fun ω => T S' ω ∈ E) + δ := by
  constructor
  · rintro hT S S' ⟨i, hi⟩ E
    have h1 : Function.update S i (S i) = S := Function.update_eq_self i S
    have h2 : Function.update S i (S' i) = S' := by
      funext j
      by_cases hj : j = i
      · subst hj; simp
      · rw [Function.update_of_ne hj]; exact hi j hj
    have := hT i S (S i) (S' i) E
    rwa [h1, h2] at this
  · intro h i x a b E
    refine h _ _ ⟨i, fun j hj => ?_⟩ E
    rw [Function.update_of_ne hj, Function.update_of_ne hj]

omit [Fintype U] in
/-- From the measure-theoretic `F2e2e.DP.IsDP` (with the lead's `Indist`) for the output laws
`∑_ω w(ω) δ_{T x ω}` on a transcript space with measurable singletons. -/
theorem finDP_of_isDP [MeasurableSpace 𝒯] [MeasurableSingletonClass 𝒯] {w : Ω → ℝ}
    (hw0 : ∀ ω, 0 ≤ w ω) {T : (Fin r → U) → Ω → 𝒯} {θ δ : ℝ} (hδ : 0 ≤ δ)
    (hT : DP.IsDP DP.Neighbor
      (fun x => ∑ ω, ENNReal.ofReal (w ω) • Measure.dirac (T x ω)) θ δ) :
    FinDP w T θ δ := by
  classical
  intro i x a b E
  set S := Function.update x i a
  set S' := Function.update x i b
  have hN : DP.Neighbor S S' := ⟨i, fun j hj => by
    simp only [S, S']; rw [Function.update_of_ne hj, Function.update_of_ne hj]⟩
  -- a measurable (finite) set with the same trace on the two (finite) supports
  let F : Finset 𝒯 := Finset.univ.image (T S) ∪ Finset.univ.image (T S')
  let E' : Set 𝒯 := E ∩ (F : Set 𝒯)
  have hE' : MeasurableSet E' := (F.finite_toSet.subset Set.inter_subset_right).measurableSet
  have hmem : ∀ z : Fin r → U, (z = S ∨ z = S') → ∀ ω, (T z ω ∈ E' ↔ T z ω ∈ E) := by
    intro z hz ω
    refine ⟨fun h => h.1, fun h => ⟨h, ?_⟩⟩
    rcases hz with rfl | rfl
    · exact Finset.mem_coe.2 (Finset.mem_union_left _ (Finset.mem_image_of_mem _ (Finset.mem_univ ω)))
    · exact Finset.mem_coe.2 (Finset.mem_union_right _ (Finset.mem_image_of_mem _ (Finset.mem_univ ω)))
  have hmeas : ∀ z : Fin r → U, (z = S ∨ z = S') →
      (∑ ω, ENNReal.ofReal (w ω) • Measure.dirac (T z ω)) E' =
        ENNReal.ofReal (coinProb w (fun ω => T z ω ∈ E)) := by
    intro z hz
    rw [Measure.coe_finsetSum, Finset.sum_apply]
    unfold coinProb
    rw [ENNReal.ofReal_sum_of_nonneg (fun ω _ => by split_ifs; exacts [hw0 ω, le_rfl])]
    refine Finset.sum_congr rfl fun ω _ => ?_
    rw [Measure.smul_apply, smul_eq_mul, Measure.dirac_apply]
    by_cases h : T z ω ∈ E
    · rw [Set.indicator_of_mem ((hmem z hz ω).2 h), if_pos h, Pi.one_apply, mul_one]
    · rw [Set.indicator_of_notMem (fun h' => h ((hmem z hz ω).1 h')), if_neg h, mul_zero,
        ENNReal.ofReal_zero]
  have h := hT S S' hN E' hE'
  simp only at h
  rw [hmeas S (Or.inl rfl), hmeas S' (Or.inr rfl)] at h
  have hc0 : 0 ≤ coinProb w (fun ω => T S' ω ∈ E) := by
    unfold coinProb
    exact Finset.sum_nonneg fun ω _ => by split_ifs; exacts [hw0 ω, le_rfl]
  rw [← ENNReal.ofReal_mul (Real.exp_pos θ).le, ← ENNReal.ofReal_add
    (mul_nonneg (Real.exp_pos θ).le hc0) hδ] at h
  exact (ENNReal.ofReal_le_ofReal_iff (add_nonneg (mul_nonneg (Real.exp_pos θ).le hc0) hδ)).1 h

/-! ### Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` -/

section Theorem29

variable {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ δ h ξ : ℝ} {k : ℕ}

/-- **Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator`** (clipped sequential inverse-posterior
comparator). (i) deterministic box and regularizer bounds for every realization `(x, t)`;
(ii) the bad event `∃ t ∈ [k], |∑ᵢ uᵢ f_t(Xᵢ) - D f_t| > 2h/3` has probability `≤ ξ` over
`X ∼ D^r` and the coins of `T`; and `2h/3 < h`. -/
theorem posterior_comparator (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hw1 : ∑ ω, w ω = 1) (hT : FinDP w T θ δ) (q : 𝒯 → Fin k → U → ℝ)
    (hq : ∀ t j a, 0 ≤ q t j a ∧ q t j a ≤ 1) (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (hh0 : 0 < h)
    (hh1 : h ≤ 1) (hξ0 : 0 < ξ) (hξ1 : ξ < 1)
    (hr : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r)
    (hδ : δ ≤ 1 / 24 * h * ξ) :
    -- (i) (`R:eq:L1_R_bound`)
    (∀ (x : Fin r → U) (t : 𝒯),
      comparator D w T θ x t ∈ cappedSimplexW r ∧
      (∀ i, Real.exp (-(2 * θ)) ≤ r * comparator D w T θ x t i ∧
        r * comparator D w T θ x t i ≤ Real.exp (2 * θ)) ∧
      (0 < Real.exp (-(2 * θ)) ∧ Real.exp (2 * θ) < 8) ∧
      Rreg r (comparator D w T θ x t) ≤ Real.sinh θ ^ 2 / 2 ∧
      Real.sinh θ ^ 2 / 2 ≤ 0.691 * θ ^ 2 ∧ 0.691 * θ ^ 2 ≤ θ ^ 2) ∧
    -- (ii) (`R:eq:L1_acc_bound`)
    (jProb D w (fun y ω => ∃ j : Fin k,
        2 / 3 * h < |∑ i, comparator D w T θ y (T y ω) i * q (T y ω) j (y i) -
          popMean D (q (T y ω) j)|) ≤ ξ ∧
      2 / 3 * h < h) := by
  have hy : 1 < ((k : ℝ) + 2) / ξ := by
    rw [lt_div_iff₀ hξ0]; linarith [(Nat.cast_nonneg k : (0 : ℝ) ≤ k)]
  have hrpos : 0 < r := by
    have h1 : 0 < 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) := by
      have := Real.log_pos hy
      positivity
    exact_mod_cast lt_of_lt_of_le h1 hr
  refine ⟨fun x t => ?_, ?_, by linarith⟩
  · -- (i): Lemma `R:lem:bhatia_davis_regularizer` for the clipped weights
    have hv : ∀ i, Real.exp (-θ) ≤ vReal D w T θ x t i ∧ vReal D w T θ x t i ≤ Real.exp θ :=
      fun i => clipInv_mem θ _ _ hθ0.le
    obtain ⟨⟨-, hratio, h8, hmem⟩, ⟨hR, hc2, hc3, hc4, hc5⟩⟩ :=
      bhatia_davis_regularizer hrpos θ hθ0 hθ1 (vReal D w T θ x t) hv
    have hcomp : comparator D w T θ x t = normW (vReal D w T θ x t) := rfl
    rw [hcomp]
    exact ⟨hmem, fun i => ⟨(hratio i).2.1, (hratio i).2.2⟩, h8, hR ▸ hc2.trans hc3, hc4, hc5⟩
  · -- (ii): Lemma `R:lem:concentration_and_normalization` (iii)
    obtain ⟨⟨hfail, -⟩, -, hiii⟩ :=
      concentration_and_normalization hD0 hD1 hw0 hw1 hT q hq hθ0 hθ1 hh0 hh1 hξ0 hξ1 hr hδ
    refine le_trans (jProb_mono hD0 hw0 fun y ω hbad hC => ?_) hfail
    obtain ⟨j, hj⟩ := hbad
    obtain ⟨h1, h2, -⟩ := hiii y (T y ω) hC j
    have : |uMean D w T θ y (T y ω) (q (T y ω) j) - popMean D (q (T y ω) j)| ≤ 2 / 3 * h :=
      h1.trans h2
    unfold uMean at this
    linarith

omit [DecidableEq U] in
theorem jProb_not {D : U → ℝ} {w : Ω → ℝ} (hD1 : ∑ a, D a = 1) (hw1 : ∑ ω, w ω = 1)
    (E : (Fin r → U) → Ω → Prop) : jProb D w (fun y ω => ¬ E y ω) = 1 - jProb D w E := by
  classical
  have htot : jProb D w E + jProb D w (fun y ω => ¬ E y ω) = 1 := by
    unfold jProb
    rw [← Finset.sum_add_distrib, ← sum_prodMass (r := r) hD1]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [← Finset.sum_add_distrib]
    conv_rhs => rw [← mul_one (prodMass D y), ← hw1, Finset.mul_sum]
    refine Finset.sum_congr rfl fun ω _ => ?_
    by_cases h : E y ω
    · rw [if_pos h, if_neg (not_not.2 h), add_zero]
    · rw [if_neg h, if_pos h, zero_add]
  linarith

/-- (ii) in good-event form: with probability `≥ 1 - ξ`, `∀ t ∈ [k], |⟨u, f_t(X)⟩ - D f_t| ≤ 2h/3`. -/
theorem posterior_comparator_good (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hw1 : ∑ ω, w ω = 1) (hT : FinDP w T θ δ) (q : 𝒯 → Fin k → U → ℝ)
    (hq : ∀ t j a, 0 ≤ q t j a ∧ q t j a ≤ 1) (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (hh0 : 0 < h)
    (hh1 : h ≤ 1) (hξ0 : 0 < ξ) (hξ1 : ξ < 1)
    (hr : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r)
    (hδ : δ ≤ 1 / 24 * h * ξ) :
    1 - ξ ≤ jProb D w (fun y ω => ∀ j : Fin k,
        |∑ i, comparator D w T θ y (T y ω) i * q (T y ω) j (y i) - popMean D (q (T y ω) j)| ≤
          2 / 3 * h) := by
  have hbad := (posterior_comparator hD0 hD1 hw0 hw1 hT q hq hθ0 hθ1 hh0 hh1 hξ0 hξ1 hr hδ).2.1
  have e : jProb D w (fun y ω => ∀ j : Fin k,
      |∑ i, comparator D w T θ y (T y ω) i * q (T y ω) j (y i) - popMean D (q (T y ω) j)| ≤
        2 / 3 * h) =
      jProb D w (fun y ω => ¬ ∃ j : Fin k,
        2 / 3 * h < |∑ i, comparator D w T θ y (T y ω) i * q (T y ω) j (y i) -
          popMean D (q (T y ω) j)|) := by
    refine jProb_congr D w fun y ω => ?_
    simp only [not_exists, not_lt]
  rw [e, jProb_not hD1 hw1]
  linarith

end Theorem29

end F2e2e.Comparator
