import F2e2e.B.Comparator.Defs

/-!
# Part II §2: finite-probability toolkit for the comparator (disintegration, independence)

Helpers for Lemmas `R:lem:prefix_marginal_dp`, `R:lem:uniform_l1_drift`,
`R:lem:concentration_and_normalization` in the finite model of `F2e2e.B.Comparator.Defs`.

* `condLaw`, `sum_disintegrate`: on a finite weighted space, conditioning on the class of an
  equivalence relation `R` ("a finite σ-algebra"): `E[ψ(ξ, α ξ)] = E[∑ₐ P(a | [ξ]) ψ(ξ, a)]` for `ψ`
  constant on classes. This is the finite form of the Bayes identity (`R:eq:sec2_joint_law_factor`) and
  of "`E[g(T, X_{≤i}) | T, X_{<i}] = ∑ₐ g(·, a) P_i(a | ·)`" (paper map E10, E11).
* `jExp_disintegrate`: the concrete instance with `R = (same transcript, same prefix x_{<i})`, whose
  conditional law is the sequential posterior `posterior D w T i`.
* Independence of the records under `D^r` (`R:eq:sec2_prior_independence`): `jProb_and_coord`,
  `jProb_total_coord`.
-/

namespace F2e2e.Comparator

open Finset Real

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

section Abstract

variable {Ξ : Type*} [Fintype Ξ]

open Classical in
/-- The mass `∑_{ξ' ∈ [ξ]} c ξ'` of the `R`-class of `ξ`. -/
noncomputable def classMass (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (ξ : Ξ) : ℝ :=
  ∑ ξ', if R ξ ξ' then c ξ' else 0

open Classical in
/-- The mass `∑_{ξ' ∈ [ξ], α ξ' = a} c ξ'`. -/
noncomputable def classJoint (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (ξ : Ξ) (a : U) : ℝ :=
  ∑ ξ', if R ξ ξ' ∧ α ξ' = a then c ξ' else 0

/-- The conditional law of `α : Ξ → U` given the `R`-class of `ξ` under the weights `c`
(`:= D` on null classes). -/
noncomputable def condLaw (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (D : U → ℝ) (ξ : Ξ) (a : U) :
    ℝ :=
  if classMass c R ξ = 0 then D a else classJoint c R α ξ a / classMass c R ξ

theorem classMass_nonneg (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (ξ : Ξ) :
    0 ≤ classMass c R ξ := by
  unfold classMass
  exact Finset.sum_nonneg fun ξ' _ => by split_ifs <;> simp [hc ξ']

omit [Fintype U] in
theorem classJoint_nonneg (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (ξ : Ξ)
    (a : U) : 0 ≤ classJoint c R α ξ a := by
  unfold classJoint
  exact Finset.sum_nonneg fun ξ' _ => by split_ifs <;> simp [hc ξ']

theorem le_classMass (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (hR : Equivalence R)
    (ξ : Ξ) : c ξ ≤ classMass c R ξ := by
  classical
  unfold classMass
  have h := Finset.single_le_sum (f := fun ξ' => if R ξ ξ' then c ξ' else 0)
    (fun ξ' _ => by split_ifs <;> simp [hc ξ']) (Finset.mem_univ ξ)
  simpa [hR.refl ξ] using h

theorem classMass_congr (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (hR : Equivalence R) {ξ ξ' : Ξ}
    (h : R ξ ξ') : classMass c R ξ = classMass c R ξ' := by
  unfold classMass
  refine Finset.sum_congr rfl fun ζ _ => ?_
  have hiff : R ξ ζ ↔ R ξ' ζ := ⟨fun h1 => hR.trans (hR.symm h) h1, fun h1 => hR.trans h h1⟩
  by_cases h1 : R ξ ζ
  · rw [if_pos h1, if_pos (hiff.1 h1)]
  · rw [if_neg h1, if_neg (fun h2 => h1 (hiff.2 h2))]

theorem sum_classJoint (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (ξ : Ξ) :
    ∑ a, classJoint c R α ξ a = classMass c R ξ := by
  unfold classJoint classMass
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ξ' _ => ?_
  by_cases hR : R ξ ξ'
  · rw [if_pos hR]
    rw [Finset.sum_eq_single (α ξ')]
    · rw [if_pos ⟨hR, rfl⟩]
    · intro b _ hb
      rw [if_neg]
      exact fun h => hb h.2.symm
    · intro h; exact absurd (Finset.mem_univ _) h
  · rw [if_neg hR]
    exact Finset.sum_eq_zero fun b _ => by rw [if_neg]; exact fun h => hR h.1

open Classical in
theorem sum_classJoint_mul (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (ψ : Ξ → U → ℝ)
    (hψ : ∀ ξ ξ' a, R ξ ξ' → ψ ξ a = ψ ξ' a) (ξ : Ξ) :
    ∑ a, classJoint c R α ξ a * ψ ξ a =
      ∑ ξ', if R ξ ξ' then c ξ' * ψ ξ' (α ξ') else 0 := by
  unfold classJoint
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ξ' _ => ?_
  by_cases hR : R ξ ξ'
  · rw [if_pos hR]
    rw [Finset.sum_eq_single (α ξ')]
    · rw [if_pos ⟨hR, rfl⟩, hψ ξ ξ' _ hR]
    · intro b _ hb
      rw [if_neg, zero_mul]
      exact fun h => hb h.2.symm
    · intro h; exact absurd (Finset.mem_univ _) h
  · rw [if_neg hR]
    exact Finset.sum_eq_zero fun b _ => by rw [if_neg, zero_mul]; exact fun h => hR h.1

omit [Fintype U] in
/-- The conditional law is a probability vector (when `D` is). -/
theorem condLaw_nonneg (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (α : Ξ → U)
    (D : U → ℝ) (hD0 : ∀ a, 0 ≤ D a) (ξ : Ξ) (a : U) : 0 ≤ condLaw c R α D ξ a := by
  unfold condLaw
  split_ifs with h
  · exact hD0 a
  · exact div_nonneg (classJoint_nonneg c hc R α ξ a) (classMass_nonneg c hc R ξ)

theorem condLaw_sum (c : Ξ → ℝ) (R : Ξ → Ξ → Prop) (α : Ξ → U) (D : U → ℝ)
    (hD1 : ∑ a, D a = 1) (ξ : Ξ) : ∑ a, condLaw c R α D ξ a = 1 := by
  unfold condLaw
  by_cases h : classMass c R ξ = 0
  · simp only [h, if_true]; exact hD1
  · simp only [h, if_false]
    rw [← Finset.sum_div, sum_classJoint]
    exact div_self h

omit [Fintype U] in
theorem mul_condLaw (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (hR : Equivalence R)
    (α : Ξ → U) (D : U → ℝ) (ξ : Ξ) (a : U) :
    c ξ * condLaw c R α D ξ a = c ξ / classMass c R ξ * classJoint c R α ξ a := by
  rcases (hc ξ).eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  · have hM : classMass c R ξ ≠ 0 := (lt_of_lt_of_le hpos (le_classMass c hc R hR ξ)).ne'
    unfold condLaw
    rw [if_neg hM]
    ring

/-- **Disintegration** (finite Bayes / tower property): for `ψ` constant on `R`-classes,
`∑ ξ, c ξ ψ(ξ, α ξ) = ∑ ξ, c ξ ∑ₐ P(a | [ξ]) ψ(ξ, a)`. -/
theorem sum_disintegrate (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (hR : Equivalence R)
    (α : Ξ → U) (D : U → ℝ) (ψ : Ξ → U → ℝ) (hψ : ∀ ξ ξ' a, R ξ ξ' → ψ ξ a = ψ ξ' a) :
    ∑ ξ, c ξ * ψ ξ (α ξ) = ∑ ξ, c ξ * ∑ a, condLaw c R α D ξ a * ψ ξ a := by
  classical
  have step1 : ∀ ξ, c ξ * ∑ a, condLaw c R α D ξ a * ψ ξ a =
      ∑ ξ', if R ξ ξ' then c ξ / classMass c R ξ * (c ξ' * ψ ξ' (α ξ')) else 0 := by
    intro ξ
    rw [Finset.mul_sum]
    have : ∀ a, c ξ * (condLaw c R α D ξ a * ψ ξ a) =
        c ξ / classMass c R ξ * (classJoint c R α ξ a * ψ ξ a) := by
      intro a
      rw [← mul_assoc, mul_condLaw c hc R hR α D ξ a]
      ring
    simp_rw [this]
    rw [← Finset.mul_sum, sum_classJoint_mul c R α ψ hψ ξ, Finset.mul_sum]
    refine Finset.sum_congr rfl fun ξ' _ => ?_
    split_ifs <;> simp
  simp_rw [step1]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ξ' _ => ?_
  -- the inner sum over the class of ξ'
  have hinner : ∀ ξ, (if R ξ ξ' then c ξ / classMass c R ξ * (c ξ' * ψ ξ' (α ξ')) else 0) =
      (if R ξ' ξ then c ξ else 0) * (c ξ' * ψ ξ' (α ξ') / classMass c R ξ') := by
    intro ξ
    by_cases h : R ξ ξ'
    · rw [if_pos h, if_pos (hR.symm h), classMass_congr c R hR h]
      ring
    · rw [if_neg h, if_neg (fun h' => h (hR.symm h')), zero_mul]
  simp_rw [hinner]
  rw [← Finset.sum_mul]
  change c ξ' * ψ ξ' (α ξ') = classMass c R ξ' * (c ξ' * ψ ξ' (α ξ') / classMass c R ξ')
  rcases (hc ξ').eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  · have hM : classMass c R ξ' ≠ 0 := (lt_of_lt_of_le hpos (le_classMass c hc R hR ξ')).ne'
    field_simp

end Abstract

/-! ### Basic facts on `prodMass`, `jProb`, `jExp` -/

omit [Fintype U] [DecidableEq U] in
theorem prodMass_nonneg {D : U → ℝ} (hD0 : ∀ a, 0 ≤ D a) (y : Fin r → U) : 0 ≤ prodMass D y :=
  Finset.prod_nonneg fun j _ => hD0 (y j)

omit [DecidableEq U] in
theorem sum_prodMass {D : U → ℝ} (hD1 : ∑ a, D a = 1) : ∑ y : Fin r → U, prodMass D y = 1 := by
  unfold prodMass
  rw [← Fintype.sum_pow, hD1, one_pow]

omit [DecidableEq U] in
theorem jProb_nonneg {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (E : (Fin r → U) → Ω → Prop) : 0 ≤ jProb D w E := by
  unfold jProb
  exact Finset.sum_nonneg fun y _ => Finset.sum_nonneg fun ω _ => by
    split_ifs
    · exact mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
    · exact le_refl 0

omit [DecidableEq U] in
theorem jProb_le_one {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1)
    (hw0 : ∀ ω, 0 ≤ w ω) (hw1 : ∑ ω, w ω = 1) (E : (Fin r → U) → Ω → Prop) : jProb D w E ≤ 1 := by
  classical
  unfold jProb
  calc (∑ y, ∑ ω, if E y ω then prodMass D y * w ω else 0)
      ≤ ∑ y : Fin r → U, ∑ ω, prodMass D y * w ω := by
        refine Finset.sum_le_sum fun y _ => Finset.sum_le_sum fun ω _ => ?_
        split_ifs
        · exact le_refl _
        · exact mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
    _ = 1 := by
        simp_rw [← Finset.mul_sum, hw1, mul_one]
        exact sum_prodMass hD1


/-! ### Independence of the records -/

/-- Moving the `i`-th coordinate between two fibers. -/
theorem sum_fiber_coord (i : Fin r) (a b : U) (H : (Fin r → U) → ℝ)
    (hH : ∀ y c, H (Function.update y i c) = H y) :
    ∑ y : Fin r → U, (if y i = b then H y else 0) = ∑ y : Fin r → U, (if y i = a then H y else 0) := by
  rw [← Finset.sum_filter, ← Finset.sum_filter]
  refine Finset.sum_nbij' (fun y => Function.update y i a) (fun y => Function.update y i b)
    ?_ ?_ ?_ ?_ ?_
  · intro y _; simp
  · intro y _; simp
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy
    rw [Function.update_idem, ← hy, Function.update_eq_self]
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy
    rw [Function.update_idem, ← hy, Function.update_eq_self]
  · intro y _; exact (hH y a).symm

omit [Fintype U] [DecidableEq U] in
theorem prodMass_split (D : U → ℝ) (i : Fin r) (y : Fin r → U) :
    prodMass D y = D (y i) * ∏ j ∈ univ.erase i, D (y j) :=
  (Finset.mul_prod_erase univ (fun j => D (y j)) (mem_univ i)).symm

/-- `∑_y [y_i = a] D^r(y) F(y) = D(a) ∑_y D^r(y) F(y^{(i ← a)})`. -/
theorem sum_prodMass_coord {D : U → ℝ} (hD1 : ∑ a, D a = 1) (i : Fin r) (a : U)
    (F : (Fin r → U) → ℝ) :
    ∑ y, (if y i = a then prodMass D y * F y else 0) =
      D a * ∑ y, prodMass D y * F (Function.update y i a) := by
  let H : (Fin r → U) → ℝ := fun y => (∏ j ∈ univ.erase i, D (y j)) * F (Function.update y i a)
  have hH : ∀ y c, H (Function.update y i c) = H y := by
    intro y c
    simp only [H, Function.update_idem]
    congr 1
    refine Finset.prod_congr rfl fun j hj => ?_
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hj)]
  have h1 : ∑ y, (if y i = a then prodMass D y * F y else 0) =
      D a * ∑ y, (if y i = a then H y else 0) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun y _ => ?_
    split_ifs with hy
    · have hy' : Function.update y i a = y := by rw [← hy]; exact Function.update_eq_self i y
      simp only [H, hy']
      rw [prodMass_split D i y, hy]
      ring
    · simp
  have h2 : ∑ y, prodMass D y * F (Function.update y i a) = ∑ y, D (y i) * H y := by
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [prodMass_split D i y]
    simp only [H]
    ring
  have h3 : ∑ y, D (y i) * H y = ∑ y, (if y i = a then H y else 0) := by
    have hfib : ∀ y : Fin r → U, D (y i) * H y = ∑ b, if y i = b then D b * H y else 0 := by
      intro y
      rw [Finset.sum_ite_eq]
      simp
    simp_rw [hfib]
    rw [Finset.sum_comm]
    have hb : ∀ b, ∑ y : Fin r → U, (if y i = b then D b * H y else 0) =
        D b * ∑ y : Fin r → U, (if y i = a then H y else 0) := by
      intro b
      rw [← sum_fiber_coord i a b H hH, Finset.mul_sum]
      refine Finset.sum_congr rfl fun y _ => ?_
      split_ifs <;> simp
    simp_rw [hb]
    rw [← Finset.sum_mul, hD1, one_mul]
  rw [h1, h2, h3]

/-- `Pr[E(X, ω) ∧ X_i = a] = D(a) · Pr[E(X^{(i ← a)}, ω)]`: the record `X_i` is independent of the other
records and of the coins (`R:eq:sec2_prior_independence`). -/
theorem jProb_and_coord {D : U → ℝ} (hD1 : ∑ a, D a = 1) (w : Ω → ℝ) (i : Fin r) (a : U)
    (E : (Fin r → U) → Ω → Prop) :
    jProb D w (fun y ω => E y ω ∧ y i = a) =
      D a * jProb D w (fun y ω => E (Function.update y i a) ω) := by
  classical
  have h := sum_prodMass_coord hD1 i a (fun y => ∑ ω, if E y ω then w ω else 0)
  calc jProb D w (fun y ω => E y ω ∧ y i = a)
      = ∑ y, (if y i = a then prodMass D y * ∑ ω, (if E y ω then w ω else 0) else 0) := by
        unfold jProb
        refine Finset.sum_congr rfl fun y _ => ?_
        by_cases hy : y i = a
        · rw [if_pos hy, Finset.mul_sum]
          refine Finset.sum_congr rfl fun ω _ => ?_
          by_cases hE : E y ω
          · rw [if_pos ⟨hE, hy⟩, if_pos hE]
          · rw [if_neg (fun h => hE h.1), if_neg hE, mul_zero]
        · rw [if_neg hy]
          exact Finset.sum_eq_zero fun ω _ => if_neg (fun h => hy h.2)
    _ = D a * ∑ y, prodMass D y * ∑ ω, (if E (Function.update y i a) ω then w ω else 0) := h
    _ = D a * jProb D w (fun y ω => E (Function.update y i a) ω) := by
        unfold jProb
        congr 1
        refine Finset.sum_congr rfl fun y _ => ?_
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun ω _ => ?_
        by_cases hE : E (Function.update y i a) ω
        · rw [if_pos hE, if_pos hE]
        · rw [if_neg hE, if_neg hE, mul_zero]

/-- Law of total probability over the record `X_i`. -/
theorem jProb_total_coord {D : U → ℝ} (hD1 : ∑ a, D a = 1) (w : Ω → ℝ) (i : Fin r)
    (E : (Fin r → U) → Ω → Prop) :
    jProb D w E = ∑ a, D a * jProb D w (fun y ω => E (Function.update y i a) ω) := by
  classical
  have : jProb D w E = ∑ a, jProb D w (fun y ω => E y ω ∧ y i = a) := by
    unfold jProb
    symm
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun ω _ => ?_
    by_cases hE : E y ω
    · rw [if_pos hE, Finset.sum_eq_single (y i)]
      · rw [if_pos ⟨hE, rfl⟩]
      · intro b _ hb; rw [if_neg]; exact fun h => hb h.2.symm
      · intro h; exact absurd (Finset.mem_univ _) h
    · rw [if_neg hE]
      exact Finset.sum_eq_zero fun b _ => if_neg (fun h => hE h.1)
  rw [this]
  exact Finset.sum_congr rfl fun a _ => jProb_and_coord hD1 w i a E

/-! ### Sequential posteriors are conditional laws -/

/-- The relation "same transcript and same prefix `x_{<n}`" on `(X, coins)`: the atoms of
`𝓕_n = σ(T, X_{<n})` (0-based: `X_{<n} = (X_0, …, X_{n-1})`). -/
def sameTP (T : (Fin r → U) → Ω → 𝒯) (n : ℕ) (ξ ξ' : (Fin r → U) × Ω) : Prop :=
  T ξ'.1 ξ'.2 = T ξ.1 ξ.2 ∧ PrefixAgree n ξ.1 ξ'.1

omit [Fintype U] [DecidableEq U] [Fintype Ω] in
theorem sameTP_equivalence (T : (Fin r → U) → Ω → 𝒯) (n : ℕ) : Equivalence (sameTP T n) := by
  refine ⟨fun ξ => ⟨rfl, fun _ _ => rfl⟩, fun {ξ ξ'} h => ⟨h.1.symm, fun j hj => (h.2 j hj).symm⟩,
    fun {ξ ξ' ξ''} h1 h2 => ⟨h2.1.trans h1.1, fun j hj => (h2.2 j hj).trans (h1.2 j hj)⟩⟩

omit [Fintype U] [DecidableEq U] in
theorem prefixAgree_trans {n : ℕ} {x y z : Fin r → U} (h1 : PrefixAgree n x y)
    (h2 : PrefixAgree n y z) : PrefixAgree n x z :=
  fun j hj => (h2 j hj).trans (h1 j hj)

omit [Fintype U] [DecidableEq U] in
theorem prefixAgree_symm {n : ℕ} {x y : Fin r → U} (h : PrefixAgree n x y) : PrefixAgree n y x :=
  fun j hj => (h j hj).symm

omit [DecidableEq U] in
theorem postMarg_nonneg {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯) (x : Fin r → U) :
    0 ≤ postMarg D w T i t x := jProb_nonneg hD0 hw0 _

omit [DecidableEq U] in
theorem postJoint_nonneg {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯) (x : Fin r → U) (a : U) :
    0 ≤ postJoint D w T i t x a := jProb_nonneg hD0 hw0 _

omit [DecidableEq U] in
theorem sum_postJoint (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯)
    (x : Fin r → U) : ∑ a, postJoint D w T i t x a = postMarg D w T i t x := by
  classical
  unfold postJoint postMarg jProb
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ω _ => ?_
  by_cases hE : T y ω = t ∧ PrefixAgree (↑i) x y
  · rw [if_pos hE, Finset.sum_eq_single (y i)]
    · rw [if_pos ⟨hE.1, hE.2, rfl⟩]
    · intro b _ hb; rw [if_neg]; exact fun h => hb h.2.2.symm
    · intro h; exact absurd (Finset.mem_univ _) h
  · rw [if_neg hE]
    refine Finset.sum_eq_zero fun a _ => ?_
    rw [if_neg]
    exact fun h => hE ⟨h.1, h.2.1⟩

omit [DecidableEq U] in
theorem posterior_nonneg {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯) (x : Fin r → U) (a : U) :
    0 ≤ posterior D w T i t x a := by
  unfold posterior
  split_ifs
  · exact hD0 a
  · exact div_nonneg (postJoint_nonneg hD0 hw0 T i t x a) (postMarg_nonneg hD0 hw0 T i t x)

omit [DecidableEq U] in
theorem posterior_sum {D : U → ℝ} {w : Ω → ℝ} (hD1 : ∑ a, D a = 1) (T : (Fin r → U) → Ω → 𝒯)
    (i : Fin r) (t : 𝒯) (x : Fin r → U) : ∑ a, posterior D w T i t x a = 1 := by
  unfold posterior
  by_cases h : postMarg D w T i t x = 0
  · simp only [h, if_true]; exact hD1
  · simp only [h, if_false]
    rw [← Finset.sum_div, sum_postJoint]
    exact div_self h

omit [DecidableEq U] in
/-- The posterior depends on `x` only through `x_{<i}`. -/
theorem posterior_prefixDep (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (a : U) :
    PrefixDep (i : ℕ) (fun t x => posterior D w T i t x a) := by
  intro t x y hxy
  have hiff : ∀ z, PrefixAgree (↑i) x z ↔ PrefixAgree (↑i) y z := fun z =>
    ⟨fun h => prefixAgree_trans (prefixAgree_symm hxy) h, fun h => prefixAgree_trans hxy h⟩
  have hM : postMarg D w T i t x = postMarg D w T i t y := by
    unfold postMarg
    simp_rw [hiff]
  have hJ : postJoint D w T i t x a = postJoint D w T i t y a := by
    unfold postJoint
    simp_rw [hiff]
  simp only [posterior, hM, hJ]

theorem condLaw_sameTP {D : U → ℝ} {w : Ω → ℝ} (T : (Fin r → U) → Ω → 𝒯) (i : Fin r)
    (y : Fin r → U) (ω : Ω) (a : U) :
    condLaw (fun ξ : (Fin r → U) × Ω => prodMass D ξ.1 * w ξ.2) (sameTP T i) (fun ξ => ξ.1 i) D
        (y, ω) a = posterior D w T i (T y ω) y a := by
  classical
  have hM : classMass (fun ξ : (Fin r → U) × Ω => prodMass D ξ.1 * w ξ.2) (sameTP T i) (y, ω) =
      postMarg D w T i (T y ω) y := by
    unfold classMass postMarg jProb
    rw [Fintype.sum_prod_type]
    refine Finset.sum_congr rfl fun y' _ => Finset.sum_congr rfl fun ω' _ => ?_
    by_cases h : T y' ω' = T y ω ∧ PrefixAgree (↑i) y y'
    · rw [if_pos (show sameTP T i (y, ω) (y', ω') from h), if_pos h]
    · rw [if_neg (show ¬ sameTP T i (y, ω) (y', ω') from h), if_neg h]
  have hJ : classJoint (fun ξ : (Fin r → U) × Ω => prodMass D ξ.1 * w ξ.2) (sameTP T i)
      (fun ξ => ξ.1 i) (y, ω) a = postJoint D w T i (T y ω) y a := by
    unfold classJoint postJoint jProb
    rw [Fintype.sum_prod_type]
    refine Finset.sum_congr rfl fun y' _ => Finset.sum_congr rfl fun ω' _ => ?_
    by_cases h : T y' ω' = T y ω ∧ PrefixAgree (↑i) y y' ∧ y' i = a
    · rw [if_pos (show sameTP T i (y, ω) (y', ω') ∧ (y', ω').1 i = a from
        ⟨⟨h.1, h.2.1⟩, h.2.2⟩), if_pos h]
    · rw [if_neg (show ¬ (sameTP T i (y, ω) (y', ω') ∧ (y', ω').1 i = a) from
        fun h' => h ⟨h'.1.1, h'.1.2, h'.2⟩), if_neg h]
  unfold condLaw posterior
  rw [hM, hJ]

/-- **Disintegration along `𝓕_i = σ(T, X_{<i})`** (paper map E10/E11): for `ψ(y, ω, a)` depending on
`(y, ω)` only through `(T y ω, y_{<i})`,
`E[ψ(X, ω, X_i)] = E[∑ₐ P_i(a | T, X_{<i}) ψ(X, ω, a)]`. -/
theorem jExp_disintegrate {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (ψ : (Fin r → U) → Ω → U → ℝ)
    (hψ : ∀ y ω y' ω' a, T y ω = T y' ω' → PrefixAgree i y y' → ψ y ω a = ψ y' ω' a) :
    jExp D w (fun y ω => ψ y ω (y i)) =
      jExp D w (fun y ω => ∑ a, posterior D w T i (T y ω) y a * ψ y ω a) := by
  have h := sum_disintegrate (fun ξ : (Fin r → U) × Ω => prodMass D ξ.1 * w ξ.2)
    (fun ξ => mul_nonneg (prodMass_nonneg hD0 ξ.1) (hw0 ξ.2)) (sameTP T i)
    (sameTP_equivalence T i) (fun ξ => ξ.1 i) D (fun ξ a => ψ ξ.1 ξ.2 a)
    (fun ξ ξ' a h => hψ ξ.1 ξ.2 ξ'.1 ξ'.2 a h.1.symm h.2)
  unfold jExp
  rw [← Fintype.sum_prod_type' (f := fun y ω => prodMass D y * w ω * ψ y ω (y i)),
    ← Fintype.sum_prod_type' (f := fun y ω => prodMass D y * w ω *
      ∑ a, posterior D w T i (T y ω) y a * ψ y ω a)]
  refine h.trans (Finset.sum_congr rfl fun ξ _ => ?_)
  congr 1
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [condLaw_sameTP T i ξ.1 ξ.2 a]

end F2e2e.Comparator
