import Mathlib
import F2e2e.Spec

/-!
# Part II §2: setting, replacement DP, sequential posteriors, clipped comparator (definitions)

Paper: `parts/partII.tex` §2: the setting (II.2.P0, L294–302), Definition `R:def:replacement_dp`
(L304–310) and Definition `R:def:posterior_comparator` (L314–344).

## Finite/discrete model (notes/PAPER_MAP_II_a.md, II.2.P0–II.2.2 and risk R3)

* `U` is a finite domain and `D : U → ℝ` a probability vector (`0 ≤ D`, `∑ D = 1`), exactly as in
  `F2e2e.VGuarantee`. **No full-support assumption**: the paper's WLOG restriction to `supp D`
  (L295) is handled directly (off-support values occur with probability `0`; the clipped weight
  `clipInv` is still in `[e^{-θ}, e^θ]` there, so all deterministic statements hold for every
  realization).
* The block `X = (X_1, …, X_r) ∼ D^r` (`R:eq:sec2_sample_block`) is `y : Fin r → U` with mass
  `prodMass D y = ∏ⱼ D (y j)`.
* The randomized mechanism (complete augmented transcript) is `T : (Fin r → U) → Ω → 𝒯`, where the
  finite coin space `Ω` carries a probability vector `w` (the internal coins of `T`, independent of
  `X`). The transcript type `𝒯` is arbitrary: all laws are finitely supported, so no measurability or
  finiteness of `𝒯` is needed (the paper allows countable or standard Borel `𝒯`, L305).
* Probabilities/expectations over the joint draw `(X, coins)` are finite weighted sums `jProb`, `jExp`.
* Sequential posteriors are ratios of finite sums: `P_i(a | t, x_{<i}) = Pr[T = t, X_{<i} = x_{<i},
  X_i = a] / Pr[T = t, X_{<i} = x_{<i}]`, and `:= D a` on the null set — the discrete form of the
  Radon–Nikodym definition (`R:eq:P_i_def`).
* Prefixes are not separate types: a function of `(t, x)` "depends on `x_{<i}` only" is expressed by
  `PrefixDep i`; `PrefixAgree i x y` says `y_{<i} = x_{<i}`.
-/

namespace F2e2e.Comparator

open Finset Real

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

/-! ### Finite probability over `(X, coins)` -/

/-- `D^r(y) = ∏ⱼ D(yⱼ)`, the mass of the block `y` under `X ∼ D^r`. -/
noncomputable def prodMass (D : U → ℝ) (y : Fin r → U) : ℝ := ∏ j, D (y j)

open Classical in
/-- Probability `Pr_ω[A(ω)]` of an event of the internal coins of the mechanism. -/
noncomputable def coinProb (w : Ω → ℝ) (A : Ω → Prop) : ℝ := ∑ ω, if A ω then w ω else 0

open Classical in
/-- Joint probability `Pr_{X ∼ D^r, ω ∼ w}[E(X, ω)]`. -/
noncomputable def jProb (D : U → ℝ) (w : Ω → ℝ) (E : (Fin r → U) → Ω → Prop) : ℝ :=
  ∑ y, ∑ ω, if E y ω then prodMass D y * w ω else 0

/-- Joint expectation `E_{X ∼ D^r, ω ∼ w}[G(X, ω)]`. -/
noncomputable def jExp (D : U → ℝ) (w : Ω → ℝ) (G : (Fin r → U) → Ω → ℝ) : ℝ :=
  ∑ y, ∑ ω, prodMass D y * w ω * G y ω

/-! ### Definition `R:def:replacement_dp` (L304–310) -/

/-- **Definition `R:def:replacement_dp`** (eq. `R:eq:dp_def`), finite-coin form: the mechanism `T` is
`(θ, δ)`-DP under single-record replacement if for every coordinate `i`, every dataset `x` (i.e. every
prefix `x_{<i}` and suffix `x_{>i}`), every pair of record values `a, b` and every event `E ⊆ 𝒯`,
`Pr_T[T(x_{<i}, a, x_{>i}) ∈ E] ≤ e^θ · Pr_T[T(x_{<i}, b, x_{>i}) ∈ E] + δ`,
where `Pr_T` integrates over the internal coins of `T` only. (The adaptive query-selection rule of
the definition is a map `q : 𝒯 → Fin k → U → ℝ` with values in `[0,1]`, an explicit argument of the
statements below; `f_0 ≡ 1` is `extQ`.) -/
def FinDP (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ δ : ℝ) : Prop :=
  ∀ (i : Fin r) (x : Fin r → U) (a b : U) (E : Set 𝒯),
    coinProb w (fun ω => T (Function.update x i a) ω ∈ E) ≤
      Real.exp θ * coinProb w (fun ω => T (Function.update x i b) ω ∈ E) + δ

/-! ### Prefixes -/

/-- `y` agrees with `x` on the coordinates `j < i`, i.e. `y_{<i} = x_{<i}`. -/
def PrefixAgree (i : ℕ) (x y : Fin r → U) : Prop := ∀ j : Fin r, (j : ℕ) < i → y j = x j

/-- `S t x` depends on `x` only through the prefix `x_{<i}` (e.g. an event `S ⊆ 𝒯 × U^{i-1}`). -/
def PrefixDep {β : Sort*} (i : ℕ) (S : 𝒯 → (Fin r → U) → β) : Prop :=
  ∀ t x y, PrefixAgree i x y → S t x = S t y

/-- `T(x_{<i}, a, z_{>i})`: the dataset with prefix `x_{<i}`, record `a` at `i` and suffix `z_{>i}`. -/
def splice (i : Fin r) (x : Fin r → U) (a : U) (z : Fin r → U) : Fin r → U :=
  fun j => if (j : ℕ) < i then x j else if j = i then a else z j

/-! ### Definition `R:def:posterior_comparator` (L314–344) -/

/-- `Pr[T = t, X_{<i} = x_{<i}, X_i = a]` (the joint law of `(M_i, X_i)`, `M_i = (T, X_{<i})`). -/
noncomputable def postJoint (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯)
    (x : Fin r → U) (a : U) : ℝ :=
  jProb D w (fun y ω => T y ω = t ∧ PrefixAgree i x y ∧ y i = a)

/-- `μ_i({(t, x_{<i})}) = Pr[T = t, X_{<i} = x_{<i}]` (the law `μ_i` of `M_i = (T, X_{<i})`). -/
noncomputable def postMarg (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯)
    (x : Fin r → U) : ℝ :=
  jProb D w (fun y ω => T y ω = t ∧ PrefixAgree i x y)

/-- **(`R:eq:P_i_def`)** The sequential posterior `P_i(a | t, x_{<i}) = D(a) (dQ_i(·|a)/dμ_i)(t, x_{<i})`,
i.e. `Pr[X_i = a | T = t, X_{<i} = x_{<i}]`; on the `μ_i`-null set it is `D` (L321). -/
noncomputable def posterior (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯)
    (x : Fin r → U) (a : U) : ℝ :=
  if postMarg D w T i t x = 0 then D a else postJoint D w T i t x a / postMarg D w T i t x

/-- **(`R:eq:a_i_def`)** The sequential posterior ratio `a_i(a) = P_i(a | t, x_{<i}) / D(a)`. -/
noncomputable def postRatio (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (t : 𝒯)
    (x : Fin r → U) (a : U) : ℝ :=
  posterior D w T i t x a / D a

/-- `clip_{[e^{-θ}, e^θ]}(1/a)` for the ratio `a = p/d`, with `1/0 = +∞` (L334): it is `e^θ` if
`p < e^{-θ} d` (including `p = 0 < d`), `d/p` in the window, `e^{-θ}` if `p > e^θ d`
(`clipInv_eq_cases`). Off the support (`d = 0`) the value is `e^{-θ}`, still in the window. -/
noncomputable def clipInv (θ d p : ℝ) : ℝ :=
  if p < Real.exp (-θ) * d then Real.exp θ else max (Real.exp (-θ)) (min (Real.exp θ) (d / p))

/-- **(`R:eq:v_i_def`)** The clipped inverse-posterior weight function `v_i(a | t, x_{<i})`. -/
noncomputable def clipWeight (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (i : Fin r)
    (t : 𝒯) (x : Fin r → U) (a : U) : ℝ :=
  clipInv θ (D a) (posterior D w T i t x a)

/-- The realized clipped weight `v_i = v_i(x_i | t, x_{<i})` on record `i` of the realization `(x, t)`. -/
noncomputable def vReal (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (x : Fin r → U)
    (t : 𝒯) (i : Fin r) : ℝ :=
  clipWeight D w T θ i t x (x i)

/-- **(`R:eq:u_i_def`)** The sample mean `v̄ = (1/r) ∑ᵢ vᵢ`. -/
noncomputable def vBar (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (x : Fin r → U)
    (t : 𝒯) : ℝ :=
  (∑ i, vReal D w T θ x t i) / r

/-- **(`R:eq:u_i_def`)** The normalized comparator `u_i = v_i / (r v̄) = v_i / ∑_ℓ v_ℓ`. -/
noncomputable def comparator (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ)
    (x : Fin r → U) (t : 𝒯) : Fin r → ℝ :=
  fun i => vReal D w T θ x t i / ∑ l, vReal D w T θ x t l

/-- **(`R:eq:W_r_def`)** The box-capped simplex `W_r = {u : u_i ≥ 0, ∑ u_i = 1, u_i ≤ 8/r}` (same body as
`F2e2e.Opt.Quad.cappedSimplex r 8` of the Section 3 learners). -/
def cappedSimplexW (r : ℕ) : Set (Fin r → ℝ) :=
  {u | (∀ i, 0 ≤ u i ∧ u i ≤ 8 / r) ∧ ∑ i, u i = 1}

/-- **(`R:eq:W_r_def`)** The quadratic regularizer `R_r(u) = (r/2) ∑ (u_i - 1/r)²` (same body as
`F2e2e.Opt.Quad.quadReg r`). -/
noncomputable def Rreg (r : ℕ) (u : Fin r → ℝ) : ℝ := (r : ℝ) / 2 * ∑ i, (u i - 1 / r) ^ 2

/-! ### Queries -/

/-- The queries `f_0 ≡ 1, f_1, …, f_k` selected by the transcript `t` (Definition `R:def:replacement_dp`:
`f_0` is the constant query). -/
def extQ {k : ℕ} (q : 𝒯 → Fin k → U → ℝ) (t : 𝒯) : Fin (k + 1) → U → ℝ :=
  Fin.cons (fun _ => 1) (q t)

/-- The unnormalized weighted mean `(1/r) ∑ᵢ vᵢ f(xᵢ)`. -/
noncomputable def vMean (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (x : Fin r → U)
    (t : 𝒯) (f : U → ℝ) : ℝ :=
  (∑ i, vReal D w T θ x t i * f (x i)) / r

/-- The comparator mean `⟨u, f(x)⟩ = ∑ᵢ uᵢ f(xᵢ)`. -/
noncomputable def uMean (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (x : Fin r → U)
    (t : 𝒯) (f : U → ℝ) : ℝ :=
  ∑ i, comparator D w T θ x t i * f (x i)

end F2e2e.Comparator
