import F2e2e.B.Comparator.Basic

/-!
# Part II §2, Lemma `R:lem:prefix_marginal_dp` (L351–395): prior-marginalized single-record DP

Finite model of `F2e2e.B.Comparator.Defs`. Events `S ⊆ 𝒯 × U^{i-1}` are predicates
`S : 𝒯 → (Fin r → U) → Prop` with `PrefixDep i S` (they see only the prefix `x_{<i}`).

* `QIker D w T i E x a` = `Q_i(E | x_{<i}, a) = Pr_{X_{>i} ∼ D^{r-i}, T}[T(x_{<i}, a, X_{>i}) ∈ E]`
  (`R:eq:sec2_Qi_kernel`);
* `QI D w T i S a` = `Q_i(S | a) = Pr_{(X_{<i}, X_{>i}), T}[(T(X_{<i}, a, X_{>i}), X_{<i}) ∈ S]`
  (`R:eq:Q_i_def`);
* `muI D w T S` = `μ_i(S) = Pr[(T(X), X_{<i}) ∈ S]`.

Part (i): `prefix_record_independence`, `cond_law_given_prefix_record`, `cond_law_given_record`,
`bayes_identity` (`R:eq:sec2_joint_law_factor`). Part (ii): `fixed_prefix_dp` (`R:eq:fixed_prefix_dp`),
`prefix_augmented_dp` (`R:eq:M_i_dp`), `dp_dir_1` (`R:eq:dp_dir_1`), `dp_dir_2` (`R:eq:dp_dir_2`).
-/

namespace F2e2e.Comparator

open Finset Real

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

/-- `Q_i(E | x_{<i}, a) = Pr_{X_{>i} ∼ D^{r-i}, T}[T(x_{<i}, a, X_{>i}) ∈ E]` (`R:eq:sec2_Qi_kernel`); the
coordinates `≤ i` of the dummy block `z` are integrated out with total mass `1`. -/
noncomputable def QIker (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r) (E : Set 𝒯)
    (x : Fin r → U) (a : U) : ℝ :=
  jProb D w (fun z ω => T (splice i x a z) ω ∈ E)

/-- `Q_i(S | a) = Pr_{(X_{<i}, X_{>i}), T}[(T(X_{<i}, a, X_{>i}), X_{<i}) ∈ S]` (`R:eq:Q_i_def`). -/
noncomputable def QI (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (i : Fin r)
    (S : 𝒯 → (Fin r → U) → Prop) (a : U) : ℝ :=
  jProb D w (fun y ω => S (T (Function.update y i a) ω) y)

/-- `μ_i(S) = Pr[(T(X), X_{<i}) ∈ S]`, the law of `M_i = (T, X_{<i})` (for `S` with `PrefixDep i S`). -/
noncomputable def muI (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯)
    (S : 𝒯 → (Fin r → U) → Prop) : ℝ :=
  jProb D w (fun y ω => S (T y ω) y)

/-! ### Helpers -/

omit [Fintype U] [DecidableEq U] in
theorem prefixAgree_update_iff (i : Fin r) (x y : Fin r → U) (a : U) :
    PrefixAgree (i : ℕ) x (Function.update y i a) ↔ PrefixAgree (i : ℕ) x y := by
  constructor
  · intro h j hj
    have h1 := h j hj
    rwa [Function.update_of_ne (ne_of_lt (show j < i from hj))] at h1
  · intro h j hj
    rw [Function.update_of_ne (ne_of_lt (show j < i from hj))]
    exact h j hj

omit [Fintype U] [DecidableEq U] in
theorem prefixAgree_update_self (i : Fin r) (y : Fin r → U) (a : U) :
    PrefixAgree (i : ℕ) (Function.update y i a) y := by
  intro j hj
  rw [Function.update_of_ne (ne_of_lt (show j < i from hj))]

omit [DecidableEq U] in
theorem jProb_eq_sum_coinProb (D : U → ℝ) (w : Ω → ℝ) (E : (Fin r → U) → Ω → Prop) :
    jProb D w E = ∑ y, prodMass D y * coinProb w (E y) := by
  classical
  unfold jProb coinProb
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun ω _ => ?_
  by_cases h : E y ω
  · rw [if_pos h, if_pos h]
  · rw [if_neg h, if_neg h, mul_zero]

omit [DecidableEq U] in
theorem jProb_congr (D : U → ℝ) (w : Ω → ℝ) {E E' : (Fin r → U) → Ω → Prop}
    (h : ∀ y ω, E y ω ↔ E' y ω) : jProb D w E = jProb D w E' := by
  have : E = E' := funext fun y => funext fun ω => propext (h y ω)
  rw [this]

omit [DecidableEq U] in
open Classical in
theorem jProb_eq_jExp (D : U → ℝ) (w : Ω → ℝ) (E : (Fin r → U) → Ω → Prop) :
    jProb D w E = jExp D w (fun y ω => if E y ω then 1 else 0) := by
  classical
  unfold jProb jExp
  refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun ω _ => ?_
  dsimp only
  by_cases h : E y ω
  · rw [if_pos h, if_pos h, mul_one]
  · rw [if_neg h, if_neg h, mul_zero]

omit [DecidableEq U] in
/-- The coin probability of an event not depending on the coins. -/
theorem coinProb_const (w : Ω → ℝ) (hw1 : ∑ ω, w ω = 1) (P : Prop) [Decidable P] :
    coinProb w (fun _ => P) = if P then 1 else 0 := by
  classical
  unfold coinProb
  by_cases h : P
  · simp only [h, if_true]; exact hw1
  · simp only [h, if_false, Finset.sum_const_zero]

omit [DecidableEq U] in
theorem coinProb_nonneg {w : Ω → ℝ} (hw0 : ∀ ω, 0 ≤ w ω) (A : Ω → Prop) : 0 ≤ coinProb w A := by
  classical
  unfold coinProb
  exact Finset.sum_nonneg fun ω _ => by split_ifs; exacts [hw0 ω, le_refl 0]

omit [DecidableEq U] in
/-- **Independence of disjoint blocks of records** (resampling): for any `S ⊆ [r]`,
`E_{y, z ∼ D^r}[G(y|_S ∪ z|_{Sᶜ})] = E_{y ∼ D^r}[G(y)]`. -/
theorem sum_prodMass_piecewise {D : U → ℝ} (hD1 : ∑ a, D a = 1) (S : Finset (Fin r))
    (G : (Fin r → U) → ℝ) :
    ∑ y, ∑ z, prodMass D y * prodMass D z * G (S.piecewise y z) = ∑ y, prodMass D y * G y := by
  classical
  let σ : (Fin r → U) × (Fin r → U) → (Fin r → U) × (Fin r → U) :=
    fun p => (S.piecewise p.1 p.2, S.piecewise p.2 p.1)
  have hσ : Function.Involutive σ := by
    intro p
    refine Prod.ext (funext fun j => ?_) (funext fun j => ?_) <;>
      by_cases hj : j ∈ S <;> simp [σ, Finset.piecewise, hj]
  have hmass : ∀ y z : Fin r → U, prodMass D (S.piecewise y z) * prodMass D (S.piecewise z y) =
      prodMass D y * prodMass D z := by
    intro y z
    unfold prodMass
    rw [← Finset.prod_mul_distrib, ← Finset.prod_mul_distrib]
    refine Finset.prod_congr rfl fun j _ => ?_
    by_cases hj : j ∈ S
    · simp [Finset.piecewise, hj]
    · simp [Finset.piecewise, hj, mul_comm]
  calc ∑ y, ∑ z, prodMass D y * prodMass D z * G (S.piecewise y z)
      = ∑ p : (Fin r → U) × (Fin r → U),
          prodMass D (σ p).1 * prodMass D (σ p).2 * G (σ p).1 := by
        rw [Fintype.sum_prod_type]
        refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun z _ => ?_
        simp only [σ]
        rw [hmass]
    _ = ∑ p : (Fin r → U) × (Fin r → U), prodMass D p.1 * prodMass D p.2 * G p.1 :=
        Equiv.sum_comp (hσ.toPerm σ) (fun p => prodMass D p.1 * prodMass D p.2 * G p.1)
    _ = ∑ y, prodMass D y * G y := by
        rw [Fintype.sum_prod_type]
        refine Finset.sum_congr rfl fun y _ => ?_
        dsimp only
        have : ∀ z : Fin r → U, prodMass D y * prodMass D z * G y =
            prodMass D y * G y * prodMass D z := fun z => by ring
        simp_rw [this]
        rw [← Finset.mul_sum, sum_prodMass hD1, mul_one]

omit [Fintype U] [DecidableEq U] in
theorem splice_self (i : Fin r) (x y : Fin r → U) (a : U) (hx : PrefixAgree (i : ℕ) x y)
    (ha : y i = a) : splice i x a y = y := by
  funext j
  unfold splice
  split_ifs with h1 h2
  · exact (hx j h1).symm
  · rw [h2, ha]
  · rfl

omit [Fintype U] [DecidableEq U] in
theorem update_splice (i : Fin r) (x z : Fin r → U) (a b : U) :
    Function.update (splice i x a z) i b = splice i x b z := by
  funext j
  by_cases hj : j = i
  · subst hj; simp [splice]
  · rw [Function.update_of_ne hj]
    unfold splice
    simp [hj]

section Lemma23

variable {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ δ : ℝ}

/-! ### Part (i) -/

/-- (i) `Pr[X_{<i} = x_{<i}, X_i = a] = Pr[X_{<i} = x_{<i}] · D(a)`, i.e.
`Pr[X_i = a | X_{<i} = x_{<i}] = D(a)` (`R:eq:sec2_prior_independence`). -/
theorem prefix_record_independence (hD1 : ∑ a, D a = 1) (i : Fin r) (x : Fin r → U) (a : U) :
    jProb D w (fun y _ => PrefixAgree i x y ∧ y i = a) =
      jProb D w (fun y _ => PrefixAgree i x y) * D a := by
  rw [jProb_and_coord hD1 w i a (fun y _ => PrefixAgree i x y), mul_comm]
  congr 1
  exact jProb_congr D w fun y _ => prefixAgree_update_iff i x y a

/-- (i) `Pr[T ∈ E, X_{<i} = x_{<i}, X_i = a] = Pr[X_{<i} = x_{<i}, X_i = a] · Q_i(E | x_{<i}, a)`, i.e.
`Pr[T(X) ∈ E | X_{<i} = x_{<i}, X_i = a] = Q_i(E | x_{<i}, a)`. -/
theorem cond_law_given_prefix_record (hD1 : ∑ a, D a = 1)
    (hw1 : ∑ ω, w ω = 1) (i : Fin r) (x : Fin r → U) (a : U) (E : Set 𝒯) :
    jProb D w (fun y ω => T y ω ∈ E ∧ PrefixAgree i x y ∧ y i = a) =
      jProb D w (fun y _ => PrefixAgree i x y ∧ y i = a) * QIker D w T i E x a := by
  classical
  let S : Finset (Fin r) := Finset.univ.filter (fun j : Fin r => (j : ℕ) ≤ i)
  let A : (Fin r → U) → Prop := fun y => PrefixAgree i x y ∧ y i = a
  let b : (Fin r → U) → ℝ := fun z => coinProb w (fun ω => T (splice i x a z) ω ∈ E)
  have hpwA : ∀ y z, A (S.piecewise y z) ↔ A y := by
    intro y z
    have h1 : ∀ j : Fin r, (j : ℕ) ≤ i → S.piecewise y z j = y j := fun j hj =>
      Finset.piecewise_eq_of_mem _ _ _ (Finset.mem_filter.2 ⟨Finset.mem_univ _, hj⟩)
    simp only [A]
    constructor
    · rintro ⟨hx, ha⟩
      refine ⟨fun j hj => ?_, ?_⟩
      · rw [← h1 j hj.le]; exact hx j hj
      · rw [← h1 i le_rfl]; exact ha
    · rintro ⟨hx, ha⟩
      refine ⟨fun j hj => ?_, ?_⟩
      · rw [h1 j hj.le]; exact hx j hj
      · rw [h1 i le_rfl]; exact ha
  have hpwb : ∀ y z, b (S.piecewise y z) = b z := by
    intro y z
    have : splice i x a (S.piecewise y z) = splice i x a z := by
      funext j
      unfold splice
      split_ifs with h1 h2
      · rfl
      · rfl
      · have hj : ¬ (j : ℕ) ≤ i := by
          intro hle
          rcases Nat.lt_or_eq_of_le hle with hlt | heq
          · exact h1 hlt
          · exact h2 (Fin.ext heq)
        exact Finset.piecewise_eq_of_notMem _ _ _ (fun h => hj (Finset.mem_filter.1 h).2)
    simp only [b, this]
  -- LHS as an expectation of `1_A · b`
  have hL : jProb D w (fun y ω => T y ω ∈ E ∧ PrefixAgree i x y ∧ y i = a) =
      ∑ y, prodMass D y * ((if A y then 1 else 0) * b y) := by
    rw [jProb_eq_sum_coinProb]
    refine Finset.sum_congr rfl fun y _ => ?_
    congr 1
    by_cases hA : A y
    · rw [if_pos hA, one_mul]
      simp only [b]
      rw [splice_self i x y a hA.1 hA.2]
      unfold coinProb
      refine Finset.sum_congr rfl fun ω _ => ?_
      by_cases hT : T y ω ∈ E
      · rw [if_pos ⟨hT, hA⟩, if_pos hT]
      · rw [if_neg (fun h => hT h.1), if_neg hT]
    · rw [if_neg hA, zero_mul]
      unfold coinProb
      exact Finset.sum_eq_zero fun ω _ => if_neg (fun h => hA h.2)
  have hA1 : jProb D w (fun y _ => PrefixAgree i x y ∧ y i = a) =
      ∑ y, prodMass D y * (if A y then 1 else 0) := by
    rw [jProb_eq_sum_coinProb]
    refine Finset.sum_congr rfl fun y _ => ?_
    congr 1
    exact coinProb_const w hw1 (A y)
  have hQ : QIker D w T i E x a = ∑ z, prodMass D z * b z := by
    unfold QIker
    rw [jProb_eq_sum_coinProb]
  rw [hL, hA1, hQ, ← sum_prodMass_piecewise hD1 S, Finset.sum_mul]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun z _ => ?_
  have hA' : (if A (S.piecewise y z) then (1 : ℝ) else 0) = if A y then 1 else 0 := by
    by_cases hA : A y
    · rw [if_pos hA, if_pos ((hpwA y z).2 hA)]
    · rw [if_neg hA, if_neg (fun h => hA ((hpwA y z).1 h))]
  rw [hA', hpwb]
  ring

/-- (i) `Pr[(T(X), X_{<i}) ∈ S, X_i = a] = D(a) · Q_i(S | a)`, i.e.
`Pr[(T(X), X_{<i}) ∈ S | X_i = a] = Q_i(S | a)`. -/
theorem cond_law_given_record (hD1 : ∑ a, D a = 1) (i : Fin r) (S : 𝒯 → (Fin r → U) → Prop)
    (hS : PrefixDep (i : ℕ) S) (a : U) :
    jProb D w (fun y ω => S (T y ω) y ∧ y i = a) = D a * QI D w T i S a := by
  rw [jProb_and_coord hD1 w i a (fun y ω => S (T y ω) y)]
  congr 1
  unfold QI
  refine jProb_congr D w fun y ω => ?_
  rw [hS _ _ _ (prefixAgree_update_self i y a)]

open Classical in
/-- (i) **Bayes identity** (`R:eq:sec2_joint_law_factor`):
`∫_S P_i(a | z) dμ_i(z) = Pr[(T(X), X_{<i}) ∈ S, X_i = a] = D(a) Q_i(S | a)`. -/
theorem bayes_identity (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω) (i : Fin r)
    (S : 𝒯 → (Fin r → U) → Prop) (hS : PrefixDep (i : ℕ) S) (a : U) :
    jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a else 0) =
        jProb D w (fun y ω => S (T y ω) y ∧ y i = a) ∧
      jProb D w (fun y ω => S (T y ω) y ∧ y i = a) = D a * QI D w T i S a := by
  refine ⟨?_, cond_law_given_record hD1 i S hS a⟩
  have h := jExp_disintegrate hD0 hw0 T i
    (fun y ω b => if S (T y ω) y ∧ b = a then (1 : ℝ) else 0)
    (fun y ω y' ω' b hT hP => by
      have : S (T y ω) y = S (T y' ω') y' := by rw [hT]; exact hS _ _ _ hP
      simp only [this])
  have e1 : jProb D w (fun y ω => S (T y ω) y ∧ y i = a) =
      jExp D w (fun y ω => if S (T y ω) y ∧ y i = a then (1 : ℝ) else 0) := by
    unfold jProb jExp
    refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun ω _ => ?_
    dsimp only
    by_cases hc : S (T y ω) y ∧ y i = a
    · rw [if_pos hc, if_pos hc, mul_one]
    · rw [if_neg hc, if_neg hc, mul_zero]
  calc jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a else 0)
      = jExp D w (fun y ω => ∑ b, posterior D w T i (T y ω) y b *
          (if S (T y ω) y ∧ b = a then (1 : ℝ) else 0)) := by
        unfold jExp
        refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun ω _ => ?_
        congr 1
        dsimp only
        by_cases hSy : S (T y ω) y
        · rw [if_pos hSy, Finset.sum_eq_single a]
          · rw [if_pos ⟨hSy, rfl⟩, mul_one]
          · intro b _ hb; rw [if_neg (fun h => hb h.2), mul_zero]
          · intro h; exact absurd (Finset.mem_univ _) h
        · rw [if_neg hSy]
          exact (Finset.sum_eq_zero fun b _ => by rw [if_neg (fun h => hSy h.1), mul_zero]).symm
    _ = jExp D w (fun y ω => if S (T y ω) y ∧ y i = a then (1 : ℝ) else 0) := h.symm
    _ = jProb D w (fun y ω => S (T y ω) y ∧ y i = a) := e1.symm

/-! ### Part (ii) -/

/-- (ii) **Fixed-prefix DP** (`R:eq:fixed_prefix_dp`): marginalizing the suffix `X_{>i} ∼ D^{r-i}`,
`Q_i(E | x_{<i}, a) ≤ e^θ Q_i(E | x_{<i}, b) + δ`. -/
theorem fixed_prefix_dp (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hT : FinDP w T θ δ) (i : Fin r)
    (x : Fin r → U) (a b : U) (E : Set 𝒯) :
    QIker D w T i E x a ≤ Real.exp θ * QIker D w T i E x b + δ := by
  unfold QIker
  rw [jProb_eq_sum_coinProb, jProb_eq_sum_coinProb]
  calc ∑ z, prodMass D z * coinProb w (fun ω => T (splice i x a z) ω ∈ E)
      ≤ ∑ z, prodMass D z * (Real.exp θ * coinProb w (fun ω => T (splice i x b z) ω ∈ E) + δ) := by
        refine Finset.sum_le_sum fun z _ => mul_le_mul_of_nonneg_left ?_ (prodMass_nonneg hD0 z)
        have h := hT i (splice i x a z) a b E
        rwa [update_splice, update_splice] at h
    _ = Real.exp θ * ∑ z, prodMass D z * coinProb w (fun ω => T (splice i x b z) ω ∈ E) +
          δ * ∑ z : Fin r → U, prodMass D z := by
        rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
        refine Finset.sum_congr rfl fun z _ => ?_
        ring
    _ = Real.exp θ * ∑ z, prodMass D z * coinProb w (fun ω => T (splice i x b z) ω ∈ E) + δ := by
        rw [sum_prodMass hD1, mul_one]

/-- (ii) **Prefix-augmented DP** (`R:eq:M_i_dp`): `M_i = (T, X_{<i})` is single-record `(θ, δ)`-DP in
`X_i`: `Q_i(S | a) ≤ e^θ Q_i(S | b) + δ`. -/
theorem prefix_augmented_dp (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hT : FinDP w T θ δ)
    (i : Fin r) (S : 𝒯 → (Fin r → U) → Prop) (a b : U) :
    QI D w T i S a ≤ Real.exp θ * QI D w T i S b + δ := by
  unfold QI
  rw [jProb_eq_sum_coinProb, jProb_eq_sum_coinProb]
  calc ∑ y, prodMass D y * coinProb w (fun ω => S (T (Function.update y i a) ω) y)
      ≤ ∑ y, prodMass D y *
          (Real.exp θ * coinProb w (fun ω => S (T (Function.update y i b) ω) y) + δ) := by
        refine Finset.sum_le_sum fun y _ => mul_le_mul_of_nonneg_left ?_ (prodMass_nonneg hD0 y)
        exact hT i y a b {t | S t y}
    _ = Real.exp θ * ∑ y, prodMass D y * coinProb w (fun ω => S (T (Function.update y i b) ω) y) +
          δ * ∑ y : Fin r → U, prodMass D y := by
        rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
        refine Finset.sum_congr rfl fun y _ => ?_
        ring
    _ = Real.exp θ * ∑ y, prodMass D y * coinProb w (fun ω => S (T (Function.update y i b) ω) y) +
          δ := by
        rw [sum_prodMass hD1, mul_one]

/-- The law of `M_i` is the `D`-mixture of the `Q_i(· | a)`:
`μ_i(S) = ∑ₐ D(a) Q_i(S | a)`. -/
theorem muI_eq_sum_QI (hD1 : ∑ a, D a = 1) (i : Fin r) (S : 𝒯 → (Fin r → U) → Prop)
    (hS : PrefixDep (i : ℕ) S) : muI D w T S = ∑ a, D a * QI D w T i S a := by
  unfold muI
  rw [jProb_total_coord hD1 w i (fun y ω => S (T y ω) y)]
  refine Finset.sum_congr rfl fun a _ => ?_
  congr 1
  unfold QI
  refine jProb_congr D w fun y ω => ?_
  rw [hS _ _ _ (prefixAgree_update_self i y a)]

/-- (ii) **Directed DP inequality 1** (`R:eq:dp_dir_1`): `Q_i(S | a) ≤ e^θ μ_i(S) + δ`. -/
theorem dp_dir_1 (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hT : FinDP w T θ δ) (i : Fin r)
    (S : 𝒯 → (Fin r → U) → Prop) (hS : PrefixDep (i : ℕ) S) (a : U) :
    QI D w T i S a ≤ Real.exp θ * muI D w T S + δ := by
  rw [muI_eq_sum_QI hD1 i S hS]
  calc QI D w T i S a = ∑ b, D b * QI D w T i S a := by rw [← Finset.sum_mul, hD1, one_mul]
    _ ≤ ∑ b, D b * (Real.exp θ * QI D w T i S b + δ) :=
        Finset.sum_le_sum fun b _ =>
          mul_le_mul_of_nonneg_left (prefix_augmented_dp hD0 hD1 hT i S a b) (hD0 b)
    _ = Real.exp θ * ∑ b, D b * QI D w T i S b + δ := by
        rw [Finset.mul_sum]
        have : ∑ b, D b * (Real.exp θ * QI D w T i S b + δ) =
            ∑ b, Real.exp θ * (D b * QI D w T i S b) + ∑ b, D b * δ := by
          rw [← Finset.sum_add_distrib]
          exact Finset.sum_congr rfl fun b _ => by ring
        rw [this, ← Finset.sum_mul, hD1, one_mul]

/-- (ii) **Directed DP inequality 2** (`R:eq:dp_dir_2`): `μ_i(S) ≤ e^θ Q_i(S | a) + δ`. -/
theorem dp_dir_2 (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hT : FinDP w T θ δ) (i : Fin r)
    (S : 𝒯 → (Fin r → U) → Prop) (hS : PrefixDep (i : ℕ) S) (a : U) :
    muI D w T S ≤ Real.exp θ * QI D w T i S a + δ := by
  rw [muI_eq_sum_QI hD1 i S hS]
  calc ∑ b, D b * QI D w T i S b ≤ ∑ b, D b * (Real.exp θ * QI D w T i S a + δ) :=
        Finset.sum_le_sum fun b _ =>
          mul_le_mul_of_nonneg_left (prefix_augmented_dp hD0 hD1 hT i S b a) (hD0 b)
    _ = Real.exp θ * QI D w T i S a + δ := by rw [← Finset.sum_mul, hD1, one_mul]

end Lemma23

end F2e2e.Comparator
