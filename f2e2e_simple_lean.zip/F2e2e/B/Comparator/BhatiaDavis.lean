import F2e2e.B.Comparator.Defs
import F2e2e.Lib.BhatiaDavis

/-!
# Part II §2, Lemma `R:lem:bhatia_davis_regularizer` (L552–606): deterministic box enclosure and
Bhatia–Davis regularizer bound

The lemma is proved in the library `F2e2e.Lib.BhatiaDavis` (LIB-OPT-QUAD, namespace
`F2e2e.BhatiaDavis`, with `F2e2e.Opt.Quad.cappedSimplex r 8` and `F2e2e.Opt.Quad.quadReg r`); this file
restates it in the notation of the comparator files (`cappedSimplexW`, `Rreg`, which are definitionally
the library's `W_r`, `R_r`: `cappedSimplexW_eq_quad`, `Rreg_eq_quadReg`).

For arbitrary numbers `v_1, …, v_r ∈ [e^{-θ}, e^θ]` (`θ ∈ (0,1]`), with `v̄ = (1/r) ∑ vᵢ` (`meanW`) and
`uᵢ = vᵢ/(r v̄) = vᵢ / ∑ v` (`normW`):

(i) `v̄ ∈ [e^{-θ}, e^θ]`, `r uᵢ = vᵢ/v̄ ∈ [e^{-2θ}, e^{2θ}] ⊂ [0, 8]` (`R:eq:r_u_i_enclosure`), `u ∈ W_r`;
(ii) (`R:eq:bhatia_davis_chain`)
`R_r(u) = (1/(2r v̄²)) ∑ (vᵢ - v̄)² ≤ (e^θ - v̄)(v̄ - e^{-θ})/(2v̄²) ≤ ½ sinh²θ ≤ 0.691 θ² ≤ θ²`,
the maximum over `v̄` being attained at `v̄ = sech θ` (`bhatia_davis_max_at_sech`).
-/

namespace F2e2e.Comparator

open Finset Real

variable {r : ℕ}

/-- `W_r` of the comparator files is the library's `8/r`-capped simplex. -/
theorem cappedSimplexW_eq_quad (r : ℕ) : cappedSimplexW r = F2e2e.Opt.Quad.cappedSimplex r 8 := rfl

/-- `R_r` of the comparator files is the library's quadratic regularizer. -/
theorem Rreg_eq_quadReg (r : ℕ) : Rreg r = F2e2e.Opt.Quad.quadReg r := rfl

/-- `v̄ = (1/r) ∑ᵢ vᵢ`. -/
noncomputable def meanW (v : Fin r → ℝ) : ℝ := (∑ i, v i) / r

/-- `uᵢ = vᵢ/(r v̄) = vᵢ / ∑_ℓ v_ℓ`. -/
noncomputable def normW (v : Fin r → ℝ) : Fin r → ℝ := fun i => v i / ∑ l, v l

theorem meanW_eq (v : Fin r → ℝ) : meanW v = 1 / r * ∑ i, v i := by
  unfold meanW; ring

theorem normW_eq (hr : 0 < r) (v : Fin r → ℝ) (i : Fin r) :
    normW v i = v i / (r * meanW v) := by
  have hr' : (r : ℝ) ≠ 0 := (Nat.cast_pos.2 hr).ne'
  unfold normW meanW
  congr 1
  field_simp

/-- **Bhatia–Davis inequality** (`R:eq:bhatia_davis_raw`): for `vᵢ ∈ [m, M]`,
`(1/r) ∑ (vᵢ - v̄)² ≤ (M - v̄)(v̄ - m)`. -/
theorem bhatia_davis_ineq (hr : 0 < r) (m M : ℝ) (v : Fin r → ℝ) (hv : ∀ i, m ≤ v i ∧ v i ≤ M) :
    (∑ i, (v i - meanW v) ^ 2) / r ≤ (M - meanW v) * (meanW v - m) := by
  have h := F2e2e.BhatiaDavis.empirical_bhatia_davis hr v hv (meanW_eq v)
  rw [div_eq_inv_mul, ← one_div]
  exact h

/-- `½ sinh²θ ≤ 0.691 θ²` on `[0, 1]` (via `sinh θ ≤ θ sinh 1` and `(e - e⁻¹)²/8 ≤ 0.691`). -/
theorem half_sinh_sq_le (θ : ℝ) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) :
    Real.sinh θ ^ 2 / 2 ≤ 0.691 * θ ^ 2 := by
  obtain ⟨h1, h2, -⟩ := F2e2e.BhatiaDavis.half_sinh_sq_le hθ0 hθ1
  linarith

/-- The maximum of `(e^θ - v̄)(v̄ - e^{-θ})/(2v̄²)` over `v̄ ∈ [e^{-θ}, e^θ]` is `½ sinh²θ`, attained at the
harmonic mean `v̄ = sech θ = 2/(e^θ + e^{-θ})`. -/
theorem bhatia_davis_max_at_sech (θ : ℝ) (hθ0 : 0 ≤ θ) :
    (Real.exp (-θ) ≤ 1 / Real.cosh θ ∧ 1 / Real.cosh θ ≤ Real.exp θ) ∧
      (Real.exp θ - 1 / Real.cosh θ) * (1 / Real.cosh θ - Real.exp (-θ)) /
          (2 * (1 / Real.cosh θ) ^ 2) = Real.sinh θ ^ 2 / 2 ∧
      ∀ vb : ℝ, 0 < vb →
        (Real.exp θ - vb) * (vb - Real.exp (-θ)) / (2 * vb ^ 2) ≤ Real.sinh θ ^ 2 / 2 := by
  obtain ⟨-, ⟨h1, h2⟩, h3⟩ := F2e2e.BhatiaDavis.bd_bound_max_at_sech hθ0
  rw [one_div]
  refine ⟨⟨h1, h2⟩, by rw [h3]; ring, fun vb hvb => ?_⟩
  have := F2e2e.BhatiaDavis.bd_bound_le θ hvb.ne'
  linarith

/-- **Lemma `R:lem:bhatia_davis_regularizer`.** -/
theorem bhatia_davis_regularizer (hr : 0 < r) (θ : ℝ) (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (v : Fin r → ℝ)
    (hv : ∀ i, Real.exp (-θ) ≤ v i ∧ v i ≤ Real.exp θ) :
    -- (i) (`R:eq:r_u_i_enclosure`)
    ((Real.exp (-θ) ≤ meanW v ∧ meanW v ≤ Real.exp θ) ∧
      (∀ i, r * normW v i = v i / meanW v ∧
        Real.exp (-(2 * θ)) ≤ r * normW v i ∧ r * normW v i ≤ Real.exp (2 * θ)) ∧
      (0 < Real.exp (-(2 * θ)) ∧ Real.exp (2 * θ) < 8) ∧ normW v ∈ cappedSimplexW r) ∧
    -- (ii) (`R:eq:bhatia_davis_chain`)
    (Rreg r (normW v) = 1 / (2 * r * meanW v ^ 2) * ∑ i, (v i - meanW v) ^ 2 ∧
      1 / (2 * r * meanW v ^ 2) * ∑ i, (v i - meanW v) ^ 2 ≤
        (Real.exp θ - meanW v) * (meanW v - Real.exp (-θ)) / (2 * meanW v ^ 2) ∧
      (Real.exp θ - meanW v) * (meanW v - Real.exp (-θ)) / (2 * meanW v ^ 2) ≤
        Real.sinh θ ^ 2 / 2 ∧
      Real.sinh θ ^ 2 / 2 ≤ 0.691 * θ ^ 2 ∧ 0.691 * θ ^ 2 ≤ θ ^ 2) := by
  obtain ⟨hvb, hratio, -, hmem, hR, hc2, hc3, hc4, hc5⟩ :=
    F2e2e.BhatiaDavis.bhatia_davis_regularizer hr hθ0 hθ1 v hv (meanW_eq v) (normW_eq hr v)
  have he8 : Real.exp (2 * θ) < 8 :=
    lt_of_le_of_lt (Real.exp_le_exp.2 (by linarith)) F2e2e.BhatiaDavis.exp_two_lt_eight
  refine ⟨⟨hvb, fun i => ?_, ⟨Real.exp_pos _, he8⟩, hmem⟩, ⟨hR, hc2, ?_, ?_, hc5⟩⟩
  · obtain ⟨h1, h2, h3⟩ := hratio i
    exact ⟨h1, h1 ▸ h2, h1 ▸ h3⟩
  · linarith
  · linarith

end F2e2e.Comparator
