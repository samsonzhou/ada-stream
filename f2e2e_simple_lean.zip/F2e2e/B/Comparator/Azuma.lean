import F2e2e.B.Comparator.Basic
import F2e2e.Lib.Prob.Finite

/-!
# Part II §2, Lemma `R:lem:azuma_hoeffding` (L472–481): Azuma–Hoeffding, finite filtration form

Finite probability space: a finite type `Ξ` with nonnegative weights `c`. A filtration
`𝓕_0 ⊆ 𝓕_1 ⊆ ⋯` of a finite space is a sequence of partitions, given here by equivalence relations
`R n` (the atoms of `𝓕_n`), each refining the previous one (`R (n+1) ξ ξ' → R n ξ ξ'`).
"`X` is `𝓕_n`-measurable" means `X` is constant on `R n`-classes; "`E[X | 𝓕_n] = 0`" means
`∑_{ξ ∈ [ξ₀]_n} c ξ X ξ = 0` for every atom; "almost surely" means "where `c ξ ≠ 0`".
Indices are 0-based: the paper's `D_i` (`i = 1..r`, `𝓕_i`-measurable, `E[D_i | 𝓕_{i-1}] = 0`) is our
`Dm (i-1)`.

* `hoeffding_lemma_fin`: Hoeffding's lemma for a finite weighted distribution (the paper's convexity /
  `ψ'' ≤ 1/4` step), from `F2e2e.Prob.sum_mul_exp_le_hoeffding` (LIB-PROB).
* `sum_eq_sum_condAvg`, `sum_mul_le_of_atoms`: the tower property for a finite partition.
* `atom_hoeffding`: the conditional Hoeffding bound on one atom of `𝓕_n`.
* `azuma_mgf_le`: the iterated conditional MGF bound
  `E[g · exp(s ∑_{n<r} D_n)] ≤ exp(s² ∑ L_n² / 8) · E[g]` for `𝓕_0`-measurable `g ≥ 0`.
* `azuma_hoeffding`: (`R:eq:azuma_bound`) conditionally on `𝓕_0` (i.e. weighted by any
  `𝓕_0`-measurable `g ≥ 0`, e.g. the indicator of an atom of `𝓕_0`):
  `Pr[|∑ D_n| ≥ λ | 𝓕_0] ≤ 2 exp(-2λ² / ∑ L_n²)`.
-/

namespace F2e2e.Comparator

open Finset Real

/-- **Hoeffding's lemma** (finite form): if `p` is a probability vector on a finite type, `Y` has
`p`-mean `0` and lies in `[lo, hi]` wherever `p ≠ 0`, then `∑ p e^{sY} ≤ exp(s²(hi - lo)²/8)`. -/
theorem hoeffding_lemma_fin {ι : Type*} [Fintype ι] (p : ι → ℝ) (hp0 : ∀ i, 0 ≤ p i)
    (hp1 : ∑ i, p i = 1) (Y : ι → ℝ) (lo hi : ℝ) (hY : ∀ i, p i ≠ 0 → lo ≤ Y i ∧ Y i ≤ hi)
    (hmean : ∑ i, p i * Y i = 0) (s : ℝ) :
    ∑ i, p i * Real.exp (s * Y i) ≤ Real.exp (s ^ 2 * (hi - lo) ^ 2 / 8) := by
  have hlohi : lo ≤ hi := by
    obtain ⟨i, hi'⟩ : ∃ i, p i ≠ 0 := by
      by_contra h
      simp only [not_exists, not_not] at h
      simp [h] at hp1
    exact (hY i hi').1.trans (hY i hi').2
  let f : ι → ℝ := fun i => max lo (min hi (Y i))
  have hf : ∀ i, p i ≠ 0 → f i = Y i := fun i h => by
    simp only [f]
    rw [min_eq_right (hY i h).2, max_eq_right (hY i h).1]
  have hpf : ∀ i, p i * f i = p i * Y i := fun i => by
    by_cases h : p i = 0
    · rw [h, zero_mul, zero_mul]
    · rw [hf i h]
  have hpe : ∀ i, p i * Real.exp (s * f i) = p i * Real.exp (s * Y i) := fun i => by
    by_cases h : p i = 0
    · rw [h, zero_mul, zero_mul]
    · rw [hf i h]
  have hmean' : ∑ i, p i * f i = 0 := by simp_rw [hpf]; exact hmean
  have h := F2e2e.Prob.sum_mul_exp_le_hoeffding p hp0 hp1 f (a := lo) (L := hi - lo)
    (fun i => le_max_left _ _)
    (fun i => by
      simp only [f]
      rw [add_sub_cancel]
      exact max_le hlohi (min_le_left _ _))
    hmean' s
  simp_rw [hpe] at h
  exact h

section Azuma

variable {Ξ : Type*} [Fintype Ξ]

open Classical in
/-- **Tower property on a finite partition**: `E[F] = E[E[F | R]]`, with
`E[F | R](ξ) = (∑_{ξ' ∈ [ξ]} c ξ' F ξ') / c([ξ])`. -/
theorem sum_eq_sum_condAvg (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (hR : Equivalence R)
    (F : Ξ → ℝ) :
    ∑ ξ, c ξ * F ξ =
      ∑ ξ, c ξ * ((∑ ξ', if R ξ ξ' then c ξ' * F ξ' else 0) / classMass c R ξ) := by
  symm
  calc ∑ ξ, c ξ * ((∑ ξ', if R ξ ξ' then c ξ' * F ξ' else 0) / classMass c R ξ)
      = ∑ ξ, ∑ ξ', (if R ξ ξ' then c ξ / classMass c R ξ * (c ξ' * F ξ') else 0) := by
        refine Finset.sum_congr rfl fun ξ _ => ?_
        rw [Finset.sum_div, Finset.mul_sum]
        refine Finset.sum_congr rfl fun ξ' _ => ?_
        split_ifs <;> ring
    _ = ∑ ξ', ∑ ξ, (if R ξ ξ' then c ξ / classMass c R ξ * (c ξ' * F ξ') else 0) :=
        Finset.sum_comm
    _ = ∑ ξ', c ξ' * F ξ' := by
        refine Finset.sum_congr rfl fun ξ' _ => ?_
        have hinner : ∀ ξ, (if R ξ ξ' then c ξ / classMass c R ξ * (c ξ' * F ξ') else 0) =
            (if R ξ' ξ then c ξ else 0) * (c ξ' * F ξ' / classMass c R ξ') := by
          intro ξ
          by_cases h : R ξ ξ'
          · rw [if_pos h, if_pos (hR.symm h), classMass_congr c R hR h]
            ring
          · rw [if_neg h, if_neg (fun h' => h (hR.symm h')), zero_mul]
        simp_rw [hinner]
        rw [← Finset.sum_mul]
        change classMass c R ξ' * (c ξ' * F ξ' / classMass c R ξ') = c ξ' * F ξ'
        rcases (hc ξ').eq_or_lt with h0 | hpos
        · rw [← h0]; simp
        · have hM : classMass c R ξ' ≠ 0 :=
            (lt_of_lt_of_le hpos (le_classMass c hc R hR ξ')).ne'
          field_simp

open Classical in
/-- If on every atom `∑_{[ξ₀]} c H ≤ K c([ξ₀])`, then `E[G H] ≤ K E[G]` for every `R`-measurable
`G ≥ 0`. -/
theorem sum_mul_le_of_atoms (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop) (hR : Equivalence R)
    (G H : Ξ → ℝ) (hG : ∀ ξ, 0 ≤ G ξ) (hGmeas : ∀ ξ ξ', R ξ ξ' → G ξ = G ξ') (K : ℝ)
    (hatom : ∀ ξ₀, (∑ ξ, if R ξ₀ ξ then c ξ * H ξ else 0) ≤ K * classMass c R ξ₀) :
    ∑ ξ, c ξ * (G ξ * H ξ) ≤ K * ∑ ξ, c ξ * G ξ := by
  rw [sum_eq_sum_condAvg c hc R hR (fun ξ => G ξ * H ξ), Finset.mul_sum]
  refine Finset.sum_le_sum fun ξ _ => ?_
  have hN : (∑ ξ', if R ξ ξ' then c ξ' * (G ξ' * H ξ') else 0) =
      G ξ * ∑ ξ', if R ξ ξ' then c ξ' * H ξ' else 0 := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ξ' _ => ?_
    by_cases h : R ξ ξ'
    · rw [if_pos h, if_pos h, hGmeas ξ ξ' h]; ring
    · rw [if_neg h, if_neg h, mul_zero]
  rw [hN]
  rcases (hc ξ).eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  · have hMpos := lt_of_lt_of_le hpos (le_classMass c hc R hR ξ)
    have h2 : (∑ ξ', if R ξ ξ' then c ξ' * H ξ' else 0) / classMass c R ξ ≤ K := by
      rw [div_le_iff₀ hMpos]; exact hatom ξ
    rw [mul_div_assoc]
    calc c ξ * (G ξ * ((∑ ξ', if R ξ ξ' then c ξ' * H ξ' else 0) / classMass c R ξ))
        ≤ c ξ * (G ξ * K) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left h2 (hG ξ)) (hc ξ)
      _ = K * (c ξ * G ξ) := by ring

open Classical in
/-- The conditional Hoeffding bound on one atom of `𝓕_n`:
`∑_{ξ ∈ [ξ₀]} c ξ e^{s D(ξ)} ≤ e^{s² L²/8} c([ξ₀])`. -/
theorem atom_hoeffding (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (R : Ξ → Ξ → Prop)
    (Dn An Bn : Ξ → ℝ) (Ln : ℝ) (hAmeas : ∀ ξ ξ', R ξ ξ' → An ξ = An ξ')
    (hBmeas : ∀ ξ ξ', R ξ ξ' → Bn ξ = Bn ξ')
    (hmart : ∀ ξ₀, ∑ ξ, (if R ξ₀ ξ then c ξ * Dn ξ else 0) = 0)
    (hAB : ∀ ξ, c ξ ≠ 0 → An ξ ≤ Dn ξ ∧ Dn ξ ≤ Bn ξ) (hL : ∀ ξ, Bn ξ - An ξ ≤ Ln) (s : ℝ)
    (ξ₀ : Ξ) :
    (∑ ξ, if R ξ₀ ξ then c ξ * Real.exp (s * Dn ξ) else 0) ≤
      Real.exp (s ^ 2 * Ln ^ 2 / 8) * classMass c R ξ₀ := by
  have hMnn := classMass_nonneg c hc R ξ₀
  have hsingle : ∀ ξ, R ξ₀ ξ → c ξ ≤ classMass c R ξ₀ := by
    intro ξ h
    have h1 := Finset.single_le_sum (f := fun ξ' => if R ξ₀ ξ' then c ξ' else 0)
      (fun ξ' _ => by split_ifs <;> simp [hc ξ']) (Finset.mem_univ ξ)
    simp only [if_pos h] at h1
    exact h1
  rcases hMnn.eq_or_lt with hM0 | hMpos
  · -- a null atom
    rw [← hM0, mul_zero]
    refine le_of_eq (Finset.sum_eq_zero fun ξ _ => ?_)
    split_ifs with h
    · have : c ξ = 0 := le_antisymm (hM0 ▸ hsingle ξ h) (hc ξ)
      rw [this, zero_mul]
    · rfl
  · set M := classMass c R ξ₀ with hMdef
    let p : Ξ → ℝ := fun ξ => (if R ξ₀ ξ then c ξ else 0) / M
    have hp0 : ∀ ξ, 0 ≤ p ξ := fun ξ =>
      div_nonneg (by split_ifs <;> simp [hc ξ]) hMpos.le
    have hp1 : ∑ ξ, p ξ = 1 := by
      simp only [p]
      rw [← Finset.sum_div]
      exact div_self hMpos.ne'
    have hmemR : ∀ ξ, p ξ ≠ 0 → R ξ₀ ξ ∧ c ξ ≠ 0 := by
      intro ξ hp
      by_cases h : R ξ₀ ξ
      · refine ⟨h, fun hc0 => hp ?_⟩
        simp only [p, if_pos h, hc0, zero_div]
      · exact absurd (by simp only [p, if_neg h, zero_div]) hp
    have hY : ∀ ξ, p ξ ≠ 0 → An ξ₀ ≤ Dn ξ ∧ Dn ξ ≤ Bn ξ₀ := by
      intro ξ hp
      obtain ⟨hR', hc'⟩ := hmemR ξ hp
      rw [hAmeas ξ₀ ξ hR', hBmeas ξ₀ ξ hR']
      exact hAB ξ hc'
    have hmean : ∑ ξ, p ξ * Dn ξ = 0 := by
      have : ∑ ξ, p ξ * Dn ξ = (∑ ξ, if R ξ₀ ξ then c ξ * Dn ξ else 0) / M := by
        rw [Finset.sum_div]
        refine Finset.sum_congr rfl fun ξ _ => ?_
        simp only [p]
        split_ifs <;> ring
      rw [this, hmart ξ₀, zero_div]
    have h := hoeffding_lemma_fin p hp0 hp1 Dn (An ξ₀) (Bn ξ₀) hY hmean s
    have hsum : ∑ ξ, p ξ * Real.exp (s * Dn ξ) =
        (∑ ξ, if R ξ₀ ξ then c ξ * Real.exp (s * Dn ξ) else 0) / M := by
      rw [Finset.sum_div]
      refine Finset.sum_congr rfl fun ξ _ => ?_
      simp only [p]
      split_ifs <;> ring
    rw [hsum, div_le_iff₀ hMpos] at h
    -- the atom has positive mass, so `A ≤ B` on it
    have hAB0 : An ξ₀ ≤ Bn ξ₀ := by
      obtain ⟨ξ₁, hξ₁⟩ : ∃ ξ₁, p ξ₁ ≠ 0 := by
        by_contra hcon
        simp only [not_exists, not_not] at hcon
        simp [hcon] at hp1
      exact (hY ξ₁ hξ₁).1.trans (hY ξ₁ hξ₁).2
    have hsq : (Bn ξ₀ - An ξ₀) ^ 2 ≤ Ln ^ 2 :=
      pow_le_pow_left₀ (sub_nonneg.2 hAB0) (hL ξ₀) 2
    calc (∑ ξ, if R ξ₀ ξ then c ξ * Real.exp (s * Dn ξ) else 0)
        ≤ Real.exp (s ^ 2 * (Bn ξ₀ - An ξ₀) ^ 2 / 8) * M := h
      _ ≤ Real.exp (s ^ 2 * Ln ^ 2 / 8) * M := by
          refine mul_le_mul_of_nonneg_right (Real.exp_le_exp.2 ?_) hMpos.le
          have := mul_le_mul_of_nonneg_left hsq (sq_nonneg s)
          linarith

open Classical in
/-- Iterated conditional MGF bound behind (`R:eq:azuma_bound`): for a martingale difference sequence
with `𝓕_n`-measurable ranges `[A_n, B_n]` of width `≤ L_n`, and an `𝓕_0`-measurable weight `g ≥ 0`,
`E[g · exp(s ∑_{n<r} D_n)] ≤ exp(s² ∑_{n<r} L_n² / 8) · E[g]`. -/
theorem azuma_mgf_le (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (r : ℕ) (R : ℕ → Ξ → Ξ → Prop)
    (hR : ∀ n, Equivalence (R n)) (hRmono : ∀ n ξ ξ', R (n + 1) ξ ξ' → R n ξ ξ')
    (Dm A B : ℕ → Ξ → ℝ) (L : ℕ → ℝ)
    (hDmeas : ∀ n ξ ξ', R (n + 1) ξ ξ' → Dm n ξ = Dm n ξ')
    (hAmeas : ∀ n ξ ξ', R n ξ ξ' → A n ξ = A n ξ') (hBmeas : ∀ n ξ ξ', R n ξ ξ' → B n ξ = B n ξ')
    (hmart : ∀ n ξ₀, ∑ ξ, (if R n ξ₀ ξ then c ξ * Dm n ξ else 0) = 0)
    (hAB : ∀ n ξ, c ξ ≠ 0 → A n ξ ≤ Dm n ξ ∧ Dm n ξ ≤ B n ξ) (hL : ∀ n ξ, B n ξ - A n ξ ≤ L n)
    (g : Ξ → ℝ) (hg : ∀ ξ, 0 ≤ g ξ) (hgmeas : ∀ ξ ξ', R 0 ξ ξ' → g ξ = g ξ') (s : ℝ) :
    ∑ ξ, c ξ * g ξ * Real.exp (s * ∑ n ∈ range r, Dm n ξ) ≤
      Real.exp (s ^ 2 * (∑ n ∈ range r, L n ^ 2) / 8) * ∑ ξ, c ξ * g ξ := by
  have hRle : ∀ m n, m ≤ n → ∀ ξ ξ', R n ξ ξ' → R m ξ ξ' := by
    intro m n hmn
    induction hmn with
    | refl => exact fun _ _ h => h
    | step _ ih => exact fun ξ ξ' h => ih ξ ξ' (hRmono _ ξ ξ' h)
  have hZmeas : ∀ n ξ ξ', R n ξ ξ' → ∑ k ∈ range n, Dm k ξ = ∑ k ∈ range n, Dm k ξ' := by
    intro n ξ ξ' h
    exact Finset.sum_congr rfl fun k hk =>
      hDmeas k ξ ξ' (hRle (k + 1) n (Finset.mem_range.1 hk) ξ ξ' h)
  induction r with
  | zero => simp
  | succ n ih =>
    have step := sum_mul_le_of_atoms c hc (R n) (hR n)
      (fun ξ => g ξ * Real.exp (s * ∑ k ∈ range n, Dm k ξ)) (fun ξ => Real.exp (s * Dm n ξ))
      (fun ξ => mul_nonneg (hg ξ) (Real.exp_pos _).le)
      (fun ξ ξ' h => by
        beta_reduce
        rw [hgmeas ξ ξ' (hRle 0 n (Nat.zero_le n) ξ ξ' h), hZmeas n ξ ξ' h])
      (Real.exp (s ^ 2 * L n ^ 2 / 8))
      (fun ξ₀ => atom_hoeffding c hc (R n) (Dm n) (A n) (B n) (L n) (hAmeas n) (hBmeas n)
        (hmart n) (hAB n) (hL n) s ξ₀)
    calc ∑ ξ, c ξ * g ξ * Real.exp (s * ∑ k ∈ range (n + 1), Dm k ξ)
        = ∑ ξ, c ξ * ((g ξ * Real.exp (s * ∑ k ∈ range n, Dm k ξ)) *
            Real.exp (s * Dm n ξ)) := by
          refine Finset.sum_congr rfl fun ξ _ => ?_
          rw [Finset.sum_range_succ, mul_add, Real.exp_add]
          ring
      _ ≤ Real.exp (s ^ 2 * L n ^ 2 / 8) *
            ∑ ξ, c ξ * (g ξ * Real.exp (s * ∑ k ∈ range n, Dm k ξ)) := step
      _ ≤ Real.exp (s ^ 2 * L n ^ 2 / 8) *
            (Real.exp (s ^ 2 * (∑ k ∈ range n, L k ^ 2) / 8) * ∑ ξ, c ξ * g ξ) := by
          refine mul_le_mul_of_nonneg_left ?_ (Real.exp_pos _).le
          have : ∑ ξ, c ξ * (g ξ * Real.exp (s * ∑ k ∈ range n, Dm k ξ)) =
              ∑ ξ, c ξ * g ξ * Real.exp (s * ∑ k ∈ range n, Dm k ξ) :=
            Finset.sum_congr rfl fun ξ _ => by ring
          rw [this]
          exact ih
      _ = Real.exp (s ^ 2 * (∑ k ∈ range (n + 1), L k ^ 2) / 8) * ∑ ξ, c ξ * g ξ := by
          rw [← mul_assoc, ← Real.exp_add, Finset.sum_range_succ]
          ring_nf

open Classical in
/-- **Lemma `R:lem:azuma_hoeffding`** (`R:eq:azuma_bound`), finite filtration form: for a martingale
difference sequence `D_0, …, D_{r-1}` (`D_n` `𝓕_{n+1}`-measurable, `E[D_n | 𝓕_n] = 0`) with
`A_n ≤ D_n ≤ B_n` a.s., `A_n, B_n` `𝓕_n`-measurable, `B_n - A_n ≤ L_n`, `L_n > 0`, and every
`λ > 0`, conditionally on `𝓕_0` (weight `g ≥ 0`, `𝓕_0`-measurable):
`E[g · 1{|∑_{n<r} D_n| ≥ λ}] ≤ 2 exp(-2λ² / ∑_{n<r} L_n²) · E[g]`. -/
theorem azuma_hoeffding (c : Ξ → ℝ) (hc : ∀ ξ, 0 ≤ c ξ) (r : ℕ) (R : ℕ → Ξ → Ξ → Prop)
    (hR : ∀ n, Equivalence (R n)) (hRmono : ∀ n ξ ξ', R (n + 1) ξ ξ' → R n ξ ξ')
    (Dm A B : ℕ → Ξ → ℝ) (L : ℕ → ℝ)
    (hDmeas : ∀ n ξ ξ', R (n + 1) ξ ξ' → Dm n ξ = Dm n ξ')
    (hAmeas : ∀ n ξ ξ', R n ξ ξ' → A n ξ = A n ξ') (hBmeas : ∀ n ξ ξ', R n ξ ξ' → B n ξ = B n ξ')
    (hmart : ∀ n ξ₀, ∑ ξ, (if R n ξ₀ ξ then c ξ * Dm n ξ else 0) = 0)
    (hAB : ∀ n ξ, c ξ ≠ 0 → A n ξ ≤ Dm n ξ ∧ Dm n ξ ≤ B n ξ) (hL : ∀ n ξ, B n ξ - A n ξ ≤ L n)
    (hLpos : ∀ n, 0 < L n) (g : Ξ → ℝ) (hg : ∀ ξ, 0 ≤ g ξ)
    (hgmeas : ∀ ξ ξ', R 0 ξ ξ' → g ξ = g ξ') (lam : ℝ) (hlam : 0 < lam) :
    ∑ ξ, (if lam ≤ |∑ n ∈ range r, Dm n ξ| then c ξ * g ξ else 0) ≤
      2 * Real.exp (-(2 * lam ^ 2 / ∑ n ∈ range r, L n ^ 2)) * ∑ ξ, c ξ * g ξ := by
  have hcg : ∀ ξ, 0 ≤ c ξ * g ξ := fun ξ => mul_nonneg (hc ξ) (hg ξ)
  have hsumcg : 0 ≤ ∑ ξ, c ξ * g ξ := Finset.sum_nonneg fun ξ _ => hcg ξ
  rcases Nat.eq_zero_or_pos r with hr0 | hrpos
  · subst hr0
    have : ∀ ξ, (if lam ≤ |∑ n ∈ range 0, Dm n ξ| then c ξ * g ξ else 0) = 0 := by
      intro ξ
      rw [if_neg]
      simp only [Finset.range_zero, Finset.sum_empty, abs_zero, not_le]
      exact hlam
    simp_rw [this]
    rw [Finset.sum_const_zero]
    positivity
  set V := ∑ n ∈ range r, L n ^ 2 with hVdef
  have hV : 0 < V :=
    Finset.sum_pos (fun n _ => pow_pos (hLpos n) 2) (Finset.nonempty_range_iff.2 hrpos.ne')
  set s := 4 * lam / V with hsdef
  have hs : 0 ≤ s := by positivity
  have hexp : -(s * lam) + s ^ 2 * V / 8 = -(2 * lam ^ 2 / V) := by
    rw [hsdef]
    field_simp
    ring
  -- one tail, for `σ = ±1`
  have tail : ∀ σ : ℝ, σ ^ 2 = 1 →
      ∑ ξ, (if lam ≤ σ * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0) ≤
        Real.exp (-(2 * lam ^ 2 / V)) * ∑ ξ, c ξ * g ξ := by
    intro σ hσ
    have hmgf := azuma_mgf_le c hc r R hR hRmono Dm A B L hDmeas hAmeas hBmeas hmart hAB hL g hg
      hgmeas (σ * s)
    have hσs : (σ * s) ^ 2 = s ^ 2 := by rw [mul_pow, hσ, one_mul]
    rw [hσs] at hmgf
    calc ∑ ξ, (if lam ≤ σ * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0)
        ≤ ∑ ξ, c ξ * g ξ * Real.exp (s * (σ * ∑ n ∈ range r, Dm n ξ - lam)) := by
          refine Finset.sum_le_sum fun ξ _ => ?_
          split_ifs with h
          · have : 1 ≤ Real.exp (s * (σ * ∑ n ∈ range r, Dm n ξ - lam)) :=
              Real.one_le_exp (mul_nonneg hs (by linarith))
            nlinarith [hcg ξ]
          · exact mul_nonneg (hcg ξ) (Real.exp_pos _).le
      _ = Real.exp (-(s * lam)) *
            ∑ ξ, c ξ * g ξ * Real.exp (σ * s * ∑ n ∈ range r, Dm n ξ) := by
          rw [Finset.mul_sum]
          refine Finset.sum_congr rfl fun ξ _ => ?_
          rw [show s * (σ * ∑ n ∈ range r, Dm n ξ - lam) =
              -(s * lam) + σ * s * ∑ n ∈ range r, Dm n ξ by ring, Real.exp_add]
          ring
      _ ≤ Real.exp (-(s * lam)) * (Real.exp (s ^ 2 * V / 8) * ∑ ξ, c ξ * g ξ) :=
          mul_le_mul_of_nonneg_left hmgf (Real.exp_pos _).le
      _ = Real.exp (-(2 * lam ^ 2 / V)) * ∑ ξ, c ξ * g ξ := by
          rw [← mul_assoc, ← Real.exp_add, hexp]
  have h1 := tail 1 (by norm_num)
  have h2 := tail (-1) (by norm_num)
  calc ∑ ξ, (if lam ≤ |∑ n ∈ range r, Dm n ξ| then c ξ * g ξ else 0)
      ≤ ∑ ξ, ((if lam ≤ 1 * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0) +
          (if lam ≤ -1 * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0)) := by
        refine Finset.sum_le_sum fun ξ _ => ?_
        by_cases h : lam ≤ |∑ n ∈ range r, Dm n ξ|
        · rw [if_pos h]
          rcases le_abs'.1 h with h' | h'
          · have hn : lam ≤ -1 * ∑ n ∈ range r, Dm n ξ := by linarith
            rw [if_pos hn]
            split_ifs <;> linarith [hcg ξ]
          · have hp : lam ≤ 1 * ∑ n ∈ range r, Dm n ξ := by linarith
            rw [if_pos hp]
            split_ifs <;> linarith [hcg ξ]
        · rw [if_neg h]
          split_ifs <;> linarith [hcg ξ]
    _ = ∑ ξ, (if lam ≤ 1 * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0) +
          ∑ ξ, (if lam ≤ -1 * ∑ n ∈ range r, Dm n ξ then c ξ * g ξ else 0) :=
        Finset.sum_add_distrib
    _ ≤ Real.exp (-(2 * lam ^ 2 / V)) * ∑ ξ, c ξ * g ξ +
          Real.exp (-(2 * lam ^ 2 / V)) * ∑ ξ, c ξ * g ξ := add_le_add h1 h2
    _ = 2 * Real.exp (-(2 * lam ^ 2 / V)) * ∑ ξ, c ξ * g ξ := by ring

end Azuma

end F2e2e.Comparator
