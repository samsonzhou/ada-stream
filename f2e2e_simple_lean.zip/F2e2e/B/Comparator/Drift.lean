import F2e2e.B.Comparator.Prefix

/-!
# Part II §2, Lemma `R:lem:uniform_l1_drift` (L400–467): uniform conditional `L₁` drift

* `condMeanV D w T θ i t x f` = `E[v_i f(X_i) | T = t, X_{<i} = x_{<i}] = ∑ₐ P_i(a) v_i(a) f(a)`;
* `condDrift D w T θ i t x` = `Δ_i(t, x_{<i}) = sup_{f : U → [0,1]} |E[v_i f(X_i) | t, x_{<i}] - D f|`
  (`R:eq:Delta_i_def`);
* `l1Drift D w T θ i t x` = `∑ₐ |v_i(a) P_i(a) - D(a)|`.

(i) `condDrift_le_l1Drift`, `l1Drift_eq_posParts` (`R:eq:Delta_i_pointwise`);
(ii) `expected_l1Drift_le`, `expected_condDrift_le` (`R:eq:Delta_i_expectation`).
-/

namespace F2e2e.Comparator

open Finset Real

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

/-- `E[v_i f(X_i) | T = t, X_{<i} = x_{<i}] = ∑ₐ P_i(a | t, x_{<i}) v_i(a | t, x_{<i}) f(a)`. -/
noncomputable def condMeanV (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (i : Fin r)
    (t : 𝒯) (x : Fin r → U) (f : U → ℝ) : ℝ :=
  ∑ a, posterior D w T i t x a * clipWeight D w T θ i t x a * f a

/-- (`R:eq:Delta_i_def`) The uniform conditional drift
`Δ_i(t, x_{<i}) = sup_{f : U → [0,1]} |E[v_i f(X_i) | T = t, X_{<i} = x_{<i}] - D f|`. -/
noncomputable def condDrift (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (i : Fin r)
    (t : 𝒯) (x : Fin r → U) : ℝ :=
  ⨆ f : {f : U → ℝ // ∀ a, 0 ≤ f a ∧ f a ≤ 1}, |condMeanV D w T θ i t x f.1 - popMean D f.1|

/-- The `L₁` density defect `∑ₐ |v_i(a) P_i(a) - D(a)|` between the clipped posterior measure and `D`. -/
noncomputable def l1Drift (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ) (i : Fin r)
    (t : 𝒯) (x : Fin r → U) : ℝ :=
  ∑ a, |clipWeight D w T θ i t x a * posterior D w T i t x a - D a|

/-! ### Linearity and monotonicity of `jExp` -/

omit [DecidableEq U] in
theorem jExp_add (D : U → ℝ) (w : Ω → ℝ) (f g : (Fin r → U) → Ω → ℝ) :
    jExp D w (fun y ω => f y ω + g y ω) = jExp D w f + jExp D w g := by
  unfold jExp
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun ω _ => by ring

omit [DecidableEq U] in
theorem jExp_sub (D : U → ℝ) (w : Ω → ℝ) (f g : (Fin r → U) → Ω → ℝ) :
    jExp D w (fun y ω => f y ω - g y ω) = jExp D w f - jExp D w g := by
  unfold jExp
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [← Finset.sum_sub_distrib]
  exact Finset.sum_congr rfl fun ω _ => by ring

omit [DecidableEq U] in
theorem jExp_const_mul (D : U → ℝ) (w : Ω → ℝ) (c : ℝ) (f : (Fin r → U) → Ω → ℝ) :
    jExp D w (fun y ω => c * f y ω) = c * jExp D w f := by
  unfold jExp
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun ω _ => by ring

omit [DecidableEq U] in
theorem jExp_sum {ι : Type*} (s : Finset ι) (D : U → ℝ) (w : Ω → ℝ)
    (f : ι → (Fin r → U) → Ω → ℝ) :
    jExp D w (fun y ω => ∑ a ∈ s, f a y ω) = ∑ a ∈ s, jExp D w (f a) := by
  unfold jExp
  symm
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ω _ => ?_
  rw [Finset.mul_sum]

omit [DecidableEq U] in
theorem jExp_mono {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    {f g : (Fin r → U) → Ω → ℝ} (h : ∀ y ω, f y ω ≤ g y ω) : jExp D w f ≤ jExp D w g := by
  unfold jExp
  exact Finset.sum_le_sum fun y _ => Finset.sum_le_sum fun ω _ =>
    mul_le_mul_of_nonneg_left (h y ω) (mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω))

omit [DecidableEq U] in
theorem jExp_congr (D : U → ℝ) (w : Ω → ℝ) {f g : (Fin r → U) → Ω → ℝ}
    (h : ∀ y ω, f y ω = g y ω) : jExp D w f = jExp D w g := by
  unfold jExp
  exact Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun ω _ => by rw [h y ω]

omit [DecidableEq U] in
theorem jExp_ite_const (D : U → ℝ) (w : Ω → ℝ) (E : (Fin r → U) → Ω → Prop)
    [∀ y ω, Decidable (E y ω)] (c : ℝ) :
    jExp D w (fun y ω => if E y ω then c else 0) = c * jProb D w E := by
  classical
  unfold jExp jProb
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun ω _ => ?_
  dsimp only
  by_cases h : E y ω
  · rw [if_pos h, if_pos h]; ring
  · rw [if_neg h, if_neg h]; ring

/-! ### The three-case identity for a single value -/

/-- The clipped inverse ratio lies in the window `[e^{-θ}, e^θ]`. -/
theorem clipInv_mem (θ d p : ℝ) (hθ : 0 ≤ θ) :
    Real.exp (-θ) ≤ clipInv θ d p ∧ clipInv θ d p ≤ Real.exp θ := by
  have he : Real.exp (-θ) ≤ Real.exp θ := Real.exp_le_exp.2 (by linarith)
  unfold clipInv
  split_ifs
  · exact ⟨he, le_rfl⟩
  · exact ⟨le_max_left _ _, max_le he (min_le_left _ _)⟩

/-- The clipped inverse ratio equals the paper's three-case formula (`R:eq:v_i_def`) for `d > 0`. -/
theorem clipInv_eq_cases (θ d p : ℝ) (hθ : 0 ≤ θ) (hd : 0 < d) :
    clipInv θ d p =
      if p < Real.exp (-θ) * d then Real.exp θ
      else if Real.exp θ * d < p then Real.exp (-θ) else d / p := by
  have hmul : Real.exp θ * Real.exp (-θ) = 1 := by rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
  unfold clipInv
  by_cases h1 : p < Real.exp (-θ) * d
  · rw [if_pos h1, if_pos h1]
  · rw [if_neg h1, if_neg h1]
    rw [not_lt] at h1
    have hp : 0 < p := lt_of_lt_of_le (mul_pos (Real.exp_pos _) hd) h1
    by_cases h2 : Real.exp θ * d < p
    · rw [if_pos h2]
      have h3 : d / p < Real.exp (-θ) := by
        rw [div_lt_iff₀ hp]
        calc d = Real.exp (-θ) * (Real.exp θ * d) := by
              rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
          _ < Real.exp (-θ) * p := mul_lt_mul_of_pos_left h2 (Real.exp_pos _)
      have he : Real.exp (-θ) ≤ Real.exp θ := Real.exp_le_exp.2 (by linarith)
      rw [min_eq_right (by linarith), max_eq_left h3.le]
    · rw [if_neg h2]
      rw [not_lt] at h2
      have h4 : d / p ≤ Real.exp θ := by
        rw [div_le_iff₀ hp]
        calc d = Real.exp θ * (Real.exp (-θ) * d) := by rw [← mul_assoc, hmul, one_mul]
          _ ≤ Real.exp θ * p := mul_le_mul_of_nonneg_left h1 (Real.exp_pos _).le
      have h5 : Real.exp (-θ) ≤ d / p := by
        rw [le_div_iff₀ hp]
        calc Real.exp (-θ) * p ≤ Real.exp (-θ) * (Real.exp θ * d) :=
              mul_le_mul_of_nonneg_left h2 (Real.exp_pos _).le
          _ = d := by rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
      rw [min_eq_right h4, max_eq_right h5]

/-- The three-case identity (proof of (`R:eq:Delta_i_pointwise`)) for one value `x`:
`|v(x) P(x) - D(x)| = [D(x) - e^θ P(x)]₊ + e^{-θ} [P(x) - e^θ D(x)]₊`. -/
theorem abs_clipInv_mul_sub (θ d p : ℝ) (hθ : 0 ≤ θ) (hd : 0 ≤ d) (hp : 0 ≤ p) :
    |clipInv θ d p * p - d| =
      max (d - Real.exp θ * p) 0 + Real.exp (-θ) * max (p - Real.exp θ * d) 0 := by
  have hmul : Real.exp θ * Real.exp (-θ) = 1 := by rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
  have he : Real.exp (-θ) ≤ Real.exp θ := Real.exp_le_exp.2 (by linarith)
  have hepos : 0 < Real.exp θ := Real.exp_pos θ
  have hempos : 0 < Real.exp (-θ) := Real.exp_pos _
  unfold clipInv
  by_cases h1 : p < Real.exp (-θ) * d
  · rw [if_pos h1]
    have h2 : Real.exp θ * p < d := by
      calc Real.exp θ * p < Real.exp θ * (Real.exp (-θ) * d) := mul_lt_mul_of_pos_left h1 hepos
        _ = d := by rw [← mul_assoc, hmul, one_mul]
    have h3 : p - Real.exp θ * d ≤ 0 := by
      have : Real.exp (-θ) * d ≤ Real.exp θ * d := mul_le_mul_of_nonneg_right he hd
      linarith
    rw [abs_of_neg (by linarith), max_eq_left (by linarith), max_eq_right h3]
    ring
  · rw [if_neg h1]
    rw [not_lt] at h1
    by_cases h4 : Real.exp θ * d < p
    · have hp' : 0 < p := lt_of_le_of_lt (mul_nonneg hepos.le hd) h4
      have h5 : d / p < Real.exp (-θ) := by
        rw [div_lt_iff₀ hp']
        calc d = Real.exp (-θ) * (Real.exp θ * d) := by
              rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
          _ < Real.exp (-θ) * p := mul_lt_mul_of_pos_left h4 hempos
      rw [min_eq_right (by linarith), max_eq_left h5.le]
      have h6 : d < Real.exp (-θ) * p := by
        calc d = Real.exp (-θ) * (Real.exp θ * d) := by
              rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
          _ < Real.exp (-θ) * p := mul_lt_mul_of_pos_left h4 hempos
      have h7 : d - Real.exp θ * p ≤ 0 := by
        have : Real.exp (-θ) * p ≤ Real.exp θ * p := mul_le_mul_of_nonneg_right he hp
        linarith
      rw [abs_of_pos (by linarith), max_eq_right h7, max_eq_left (by linarith)]
      have : Real.exp (-θ) * (Real.exp θ * d) = d := by
        rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
      linarith [this]
    · rw [not_lt] at h4
      rcases hp.eq_or_lt with hp0 | hp'
      · -- `p = 0`, hence `d = 0`
        have hd0 : d = 0 := by
          have : Real.exp (-θ) * d ≤ 0 := hp0 ▸ h1
          nlinarith
        subst hd0
        rw [← hp0]
        simp
      · have h8 : d / p ≤ Real.exp θ := by
          rw [div_le_iff₀ hp']
          calc d = Real.exp θ * (Real.exp (-θ) * d) := by rw [← mul_assoc, hmul, one_mul]
            _ ≤ Real.exp θ * p := mul_le_mul_of_nonneg_left h1 hepos.le
        have h9 : Real.exp (-θ) ≤ d / p := by
          rw [le_div_iff₀ hp']
          calc Real.exp (-θ) * p ≤ Real.exp (-θ) * (Real.exp θ * d) :=
                mul_le_mul_of_nonneg_left h4 hempos.le
            _ = d := by rw [← mul_assoc, mul_comm (Real.exp (-θ)), hmul, one_mul]
        rw [min_eq_right h8, max_eq_right h9, div_mul_cancel₀ d hp'.ne', sub_self, abs_zero]
        have h10 : d - Real.exp θ * p ≤ 0 := by
          have : d ≤ Real.exp θ * p := by
            calc d = Real.exp θ * (Real.exp (-θ) * d) := by rw [← mul_assoc, hmul, one_mul]
              _ ≤ Real.exp θ * p := mul_le_mul_of_nonneg_left h1 hepos.le
          linarith
        rw [max_eq_right h10, max_eq_right (by linarith)]
        ring

section Lemma24

variable {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ δ : ℝ}

/-- Any single query `f : U → [0,1]`: `|E[v_i f(X_i) | t, x_{<i}] - D f| ≤ ∑ₐ |v_i P_i - D|`. -/
theorem abs_condMeanV_sub_le (i : Fin r) (t : 𝒯) (x : Fin r → U) (f : U → ℝ)
    (hf : ∀ a, 0 ≤ f a ∧ f a ≤ 1) :
    |condMeanV D w T θ i t x f - popMean D f| ≤ l1Drift D w T θ i t x := by
  unfold condMeanV popMean l1Drift
  rw [← Finset.sum_sub_distrib]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun a _ => ?_)
  have e : posterior D w T i t x a * clipWeight D w T θ i t x a * f a - D a * f a =
      (clipWeight D w T θ i t x a * posterior D w T i t x a - D a) * f a := by ring
  rw [e, abs_mul]
  have hf1 : |f a| ≤ 1 := abs_le.2 ⟨by linarith [(hf a).1], (hf a).2⟩
  calc |clipWeight D w T θ i t x a * posterior D w T i t x a - D a| * |f a|
      ≤ |clipWeight D w T θ i t x a * posterior D w T i t x a - D a| * 1 :=
        mul_le_mul_of_nonneg_left hf1 (abs_nonneg _)
    _ = _ := mul_one _

theorem condDrift_bddAbove (i : Fin r) (t : 𝒯) (x : Fin r → U) :
    BddAbove (Set.range fun f : {f : U → ℝ // ∀ a, 0 ≤ f a ∧ f a ≤ 1} =>
      |condMeanV D w T θ i t x f.1 - popMean D f.1|) := by
  refine ⟨l1Drift D w T θ i t x, ?_⟩
  rintro _ ⟨f, rfl⟩
  exact abs_condMeanV_sub_le i t x f.1 f.2

/-- Every query `f : U → [0,1]` has drift at most `Δ_i`. -/
theorem abs_condMeanV_sub_le_condDrift (i : Fin r) (t : 𝒯) (x : Fin r → U) (f : U → ℝ)
    (hf : ∀ a, 0 ≤ f a ∧ f a ≤ 1) :
    |condMeanV D w T θ i t x f - popMean D f| ≤ condDrift D w T θ i t x :=
  le_ciSup (f := fun f : {f : U → ℝ // ∀ a, 0 ≤ f a ∧ f a ≤ 1} =>
    |condMeanV D w T θ i t x f.1 - popMean D f.1|) (condDrift_bddAbove i t x) ⟨f, hf⟩

/-- (i) `Δ_i ≥ 0` (take `f = 0`). -/
theorem condDrift_nonneg (i : Fin r) (t : 𝒯) (x : Fin r → U) : 0 ≤ condDrift D w T θ i t x :=
  (abs_nonneg _).trans (abs_condMeanV_sub_le_condDrift i t x (fun _ => 0)
    (fun _ => ⟨le_rfl, zero_le_one⟩))

/-- (i), first half of (`R:eq:Delta_i_pointwise`): `Δ_i(t, x_{<i}) ≤ ∑ₐ |v_i(a) P_i(a) - D(a)|`. -/
theorem condDrift_le_l1Drift (i : Fin r) (t : 𝒯) (x : Fin r → U) :
    condDrift D w T θ i t x ≤ l1Drift D w T θ i t x := by
  have : Nonempty {f : U → ℝ // ∀ a, 0 ≤ f a ∧ f a ≤ 1} :=
    ⟨⟨fun _ => 0, fun _ => ⟨le_rfl, zero_le_one⟩⟩⟩
  exact ciSup_le fun f => abs_condMeanV_sub_le i t x f.1 f.2

/-- (i), second half of (`R:eq:Delta_i_pointwise`) (the three-case identity):
`∑ₐ |v_i(a) P_i(a) - D(a)| = ∑ₐ [D(a) - e^θ P_i(a)]₊ + e^{-θ} ∑ₐ [P_i(a) - e^θ D(a)]₊`. -/
theorem l1Drift_eq_posParts (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω) (hθ : 0 ≤ θ) (i : Fin r)
    (t : 𝒯) (x : Fin r → U) :
    l1Drift D w T θ i t x =
      ∑ a, max (D a - Real.exp θ * posterior D w T i t x a) 0 +
        Real.exp (-θ) * ∑ a, max (posterior D w T i t x a - Real.exp θ * D a) 0 := by
  unfold l1Drift clipWeight
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun a _ =>
    abs_clipInv_mul_sub θ (D a) _ hθ (hD0 a) (posterior_nonneg hD0 hw0 T i t x a)

open Classical in
/-- Step (`R:eq:S_plus_bound`), for one record value `a` and the threshold event
`S_+(a) = {D(a) > e^θ P_i(a | ·)}` (or any prefix-dependent event `S`):
`E[1_S (D(a) - e^θ P_i(a))] = D(a) (μ_i(S) - e^θ Q_i(S | a)) ≤ D(a) δ`. -/
theorem expected_plus_le (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hT : FinDP w T θ δ) (i : Fin r) (a : U) (S : 𝒯 → (Fin r → U) → Prop)
    (hS : PrefixDep (i : ℕ) S) :
    jExp D w (fun y ω => if S (T y ω) y then D a - Real.exp θ * posterior D w T i (T y ω) y a
      else 0) ≤ D a * δ := by
  have e1 : jExp D w (fun y ω => if S (T y ω) y then D a - Real.exp θ *
      posterior D w T i (T y ω) y a else 0) =
      jExp D w (fun y ω => if S (T y ω) y then D a else 0) - Real.exp θ *
        jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a else 0) := by
    rw [← jExp_const_mul, ← jExp_sub]
    refine jExp_congr D w fun y ω => ?_
    by_cases h : S (T y ω) y
    · rw [if_pos h, if_pos h, if_pos h]
    · rw [if_neg h, if_neg h, if_neg h]; ring
  obtain ⟨hb1, hb2⟩ := bayes_identity hD0 hD1 hw0 i S hS a
  rw [e1, hb1, hb2, jExp_ite_const]
  have hdir := dp_dir_2 hD0 hD1 hT i S hS a
  have : jProb D w (fun y ω => S (T y ω) y) = muI D w T S := rfl
  rw [this]
  nlinarith [hD0 a, Real.exp_pos θ]

open Classical in
/-- Step (`R:eq:S_minus_bound`), for one record value `a` and a prefix-dependent event `S` (e.g.
`S_-(a) = {P_i(a | ·) > e^θ D(a)}`): `E[1_S (P_i(a) - e^θ D(a))] = D(a)(Q_i(S | a) - e^θ μ_i(S)) ≤ D(a) δ`. -/
theorem expected_minus_le (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hT : FinDP w T θ δ) (i : Fin r) (a : U) (S : 𝒯 → (Fin r → U) → Prop)
    (hS : PrefixDep (i : ℕ) S) :
    jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a - Real.exp θ * D a
      else 0) ≤ D a * δ := by
  have e1 : jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a -
      Real.exp θ * D a else 0) =
      jExp D w (fun y ω => if S (T y ω) y then posterior D w T i (T y ω) y a else 0) -
        Real.exp θ * jExp D w (fun y ω => if S (T y ω) y then D a else 0) := by
    rw [← jExp_const_mul, ← jExp_sub]
    refine jExp_congr D w fun y ω => ?_
    by_cases h : S (T y ω) y
    · rw [if_pos h, if_pos h, if_pos h]
    · rw [if_neg h, if_neg h, if_neg h]; ring
  obtain ⟨hb1, hb2⟩ := bayes_identity hD0 hD1 hw0 i S hS a
  rw [e1, hb1, hb2, jExp_ite_const]
  have hdir := dp_dir_1 hD0 hD1 hT i S hS a
  have : jProb D w (fun y ω => S (T y ω) y) = muI D w T S := rfl
  rw [this]
  nlinarith [hD0 a, Real.exp_pos θ]

/-- (ii) for the `L₁` defect: `E_{T, X_{<i}}[∑ₐ |v_i P_i - D|] ≤ (1 + e^{-θ}) δ`. -/
theorem expected_l1Drift_le (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hT : FinDP w T θ δ) (hθ : 0 ≤ θ) (i : Fin r) :
    jExp D w (fun y ω => l1Drift D w T θ i (T y ω) y) ≤ (1 + Real.exp (-θ)) * δ := by
  classical
  -- the threshold events `S_±(a)` (`R:eq:S_plus_def`, `R:eq:S_minus_def`)
  let Sp : U → 𝒯 → (Fin r → U) → Prop := fun a t x => Real.exp θ * posterior D w T i t x a < D a
  let Sm : U → 𝒯 → (Fin r → U) → Prop := fun a t x => Real.exp θ * D a < posterior D w T i t x a
  have hP : ∀ a t x y, PrefixAgree (i : ℕ) x y →
      posterior D w T i t x a = posterior D w T i t y a :=
    fun a t x y hxy => posterior_prefixDep D w T i a t x y hxy
  have hSp : ∀ a, PrefixDep (i : ℕ) (Sp a) := fun a t x y hxy => by
    simp only [Sp]; rw [hP a t x y hxy]
  have hSm : ∀ a, PrefixDep (i : ℕ) (Sm a) := fun a t x y hxy => by
    simp only [Sm]; rw [hP a t x y hxy]
  have hpt : ∀ y ω, l1Drift D w T θ i (T y ω) y =
      ∑ a, (if Sp a (T y ω) y then D a - Real.exp θ * posterior D w T i (T y ω) y a else 0) +
        Real.exp (-θ) * ∑ a, (if Sm a (T y ω) y then
          posterior D w T i (T y ω) y a - Real.exp θ * D a else 0) := by
    intro y ω
    rw [l1Drift_eq_posParts hD0 hw0 hθ]
    congr 1
    · refine Finset.sum_congr rfl fun a _ => ?_
      by_cases h : Sp a (T y ω) y
      · rw [if_pos h, max_eq_left (by simp only [Sp] at h; linarith)]
      · rw [if_neg h, max_eq_right (by simp only [Sp, not_lt] at h; linarith)]
    · congr 1
      refine Finset.sum_congr rfl fun a _ => ?_
      by_cases h : Sm a (T y ω) y
      · rw [if_pos h, max_eq_left (by simp only [Sm] at h; linarith)]
      · rw [if_neg h, max_eq_right (by simp only [Sm, not_lt] at h; linarith)]
  rw [jExp_congr D w hpt, jExp_add, jExp_const_mul, jExp_sum, jExp_sum]
  have h1 : ∑ a, jExp D w (fun y ω => if Sp a (T y ω) y then
      D a - Real.exp θ * posterior D w T i (T y ω) y a else 0) ≤ ∑ a, D a * δ :=
    Finset.sum_le_sum fun a _ => expected_plus_le hD0 hD1 hw0 hT i a (Sp a) (hSp a)
  have h2 : ∑ a, jExp D w (fun y ω => if Sm a (T y ω) y then
      posterior D w T i (T y ω) y a - Real.exp θ * D a else 0) ≤ ∑ a, D a * δ :=
    Finset.sum_le_sum fun a _ => expected_minus_le hD0 hD1 hw0 hT i a (Sm a) (hSm a)
  rw [← Finset.sum_mul, hD1, one_mul] at h1 h2
  have h3 := mul_le_mul_of_nonneg_left h2 (Real.exp_pos (-θ)).le
  linarith

/-- (ii) (`R:eq:Delta_i_expectation`): `E_{T, X_{<i}}[Δ_i(T, X_{<i})] ≤ (1 + e^{-θ}) δ ≤ 2δ`, uniformly
prior to query selection. -/
theorem expected_condDrift_le (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hT : FinDP w T θ δ) (hθ : 0 ≤ θ) (hδ : 0 ≤ δ) (i : Fin r) :
    jExp D w (fun y ω => condDrift D w T θ i (T y ω) y) ≤ (1 + Real.exp (-θ)) * δ ∧
      (1 + Real.exp (-θ)) * δ ≤ 2 * δ := by
  refine ⟨(jExp_mono hD0 hw0 fun y ω => condDrift_le_l1Drift i (T y ω) y).trans
    (expected_l1Drift_le hD0 hD1 hw0 hT hθ i), ?_⟩
  have : Real.exp (-θ) ≤ 1 := Real.exp_le_one_iff.2 (by linarith)
  nlinarith

end Lemma24

end F2e2e.Comparator
