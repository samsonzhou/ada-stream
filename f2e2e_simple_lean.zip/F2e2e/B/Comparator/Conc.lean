import F2e2e.B.Comparator.Drift
import F2e2e.B.Comparator.Azuma

/-!
# Part II §2, Lemma `R:lem:concentration_and_normalization` (L483–543) and Remark
`R:rem:sec2_log_k_plus_1` (L545–547)

Constants `C = 72`, `c = 1/24` (`R:eq:C_c_constants`); hypotheses (`R:eq:r_delta_scales`)
`r ≥ C e^{2θ} h^{-2} log((k+2)/ξ)` (natural logarithm) and `δ ≤ c h ξ`.

* `ConcEvent D w T θ q h x t`: the event (`R:eq:unnormalized_concentration`)
  `∀ t ∈ {0..k}, |(1/r) ∑ᵢ vᵢ f_t(Xᵢ) - D f_t| ≤ h/3` (with `f_0 ≡ 1`, `extQ`);
* `concentration_and_normalization`: parts (i), (ii) (`R:eq:division_free_identity`) and (iii)
  (`R:eq:normalized_concentration`);
* intermediate statements of the proof: `error_decomposition` (`R:eq:error_decomposition`),
  `abs_driftPart_le` (Step 1), `markov_drift_failure` (`R:eq:markov_drift_failure`),
  `azuma_one_query`, `azuma_union_failure` (`R:eq:azuma_union_failure`);
* `log_k_plus_one`, `sample_scale_of_k_plus_one` (Remark `R:rem:sec2_log_k_plus_1`, `C' = 144`).

Only the main route `L_i = e^θ` of the proof (L531) is formalized; the parenthetical alternative
"`L_i = 2e^θ` … matches `2·6² = 72`" is not used (it is false: notes/PAPER_MAP_II_a.md, erratum R7).
-/

namespace F2e2e.Comparator

open Finset Real

variable {U : Type} [Fintype U] [DecidableEq U] {Ω : Type*} [Fintype Ω] {𝒯 : Type*} {r : ℕ}

/-- The event (`R:eq:unnormalized_concentration`): for all `t ∈ {0, …, k}` (with `f_0 ≡ 1`),
`|(1/r) ∑ᵢ vᵢ f_t(xᵢ) - D f_t| ≤ h/3`. -/
def ConcEvent {k : ℕ} (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ)
    (q : 𝒯 → Fin k → U → ℝ) (h : ℝ) (x : Fin r → U) (t : 𝒯) : Prop :=
  ∀ j : Fin (k + 1), |vMean D w T θ x t (extQ q t j) - popMean D (extQ q t j)| ≤ h / 3

/-- The average uniform drift `Δ̄ = (1/r) ∑ᵢ Δᵢ(T, X_{<i})`. -/
noncomputable def avgDrift (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ)
    (x : Fin r → U) (t : 𝒯) : ℝ :=
  (∑ i, condDrift D w T θ i t x) / r

/-- The martingale part `M_t = (1/r) ∑ᵢ (vᵢ f(Xᵢ) - E[vᵢ f(Xᵢ) | T, X_{<i}])` of
(`R:eq:error_decomposition`), for the query `f` (a function of the transcript). -/
noncomputable def martPart (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ)
    (f : 𝒯 → U → ℝ) (x : Fin r → U) (t : 𝒯) : ℝ :=
  (∑ i, (vReal D w T θ x t i * f t (x i) - condMeanV D w T θ i t x (f t))) / r

/-- The drift part `B_t = (1/r) ∑ᵢ (E[vᵢ f(Xᵢ) | T, X_{<i}] - D f)` of (`R:eq:error_decomposition`). -/
noncomputable def driftPart (D : U → ℝ) (w : Ω → ℝ) (T : (Fin r → U) → Ω → 𝒯) (θ : ℝ)
    (f : 𝒯 → U → ℝ) (x : Fin r → U) (t : 𝒯) : ℝ :=
  (∑ i, (condMeanV D w T θ i t x (f t) - popMean D (f t))) / r

/-! ### Elementary facts -/

theorem clipInv_pos (θ d p : ℝ) : 0 < clipInv θ d p := by
  unfold clipInv
  split_ifs
  · exact Real.exp_pos θ
  · exact lt_of_lt_of_le (Real.exp_pos _) (le_max_left _ _)

omit [Fintype U] in
theorem extQ_mem {k : ℕ} (q : 𝒯 → Fin k → U → ℝ) (hq : ∀ t j a, 0 ≤ q t j a ∧ q t j a ≤ 1)
    (t : 𝒯) (j : Fin (k + 1)) (a : U) : 0 ≤ extQ q t j a ∧ extQ q t j a ≤ 1 := by
  refine Fin.cases ?_ (fun j => ?_) j
  · simp [extQ]
  · simp only [extQ, Fin.cons_succ]
    exact hq t j a

omit [Fintype U] in
theorem extQ_zero {k : ℕ} (q : 𝒯 → Fin k → U → ℝ) (t : 𝒯) : extQ q t 0 = fun _ => 1 := by
  simp [extQ]

omit [Fintype U] in
theorem extQ_succ {k : ℕ} (q : 𝒯 → Fin k → U → ℝ) (t : 𝒯) (j : Fin k) :
    extQ q t j.succ = q t j := by
  simp [extQ]

omit [DecidableEq U] in
theorem jProb_mono {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    {E E' : (Fin r → U) → Ω → Prop} (h : ∀ y ω, E y ω → E' y ω) : jProb D w E ≤ jProb D w E' := by
  classical
  unfold jProb
  refine Finset.sum_le_sum fun y _ => Finset.sum_le_sum fun ω _ => ?_
  by_cases hE : E y ω
  · rw [if_pos hE, if_pos (h y ω hE)]
  · rw [if_neg hE]
    split_ifs
    · exact mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
    · exact le_rfl

omit [DecidableEq U] in
theorem jProb_or_le {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (E E' : (Fin r → U) → Ω → Prop) :
    jProb D w (fun y ω => E y ω ∨ E' y ω) ≤ jProb D w E + jProb D w E' := by
  classical
  unfold jProb
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_le_sum fun y _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_le_sum fun ω _ => ?_
  have hm := mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
  by_cases h1 : E y ω
  · rw [if_pos (Or.inl h1), if_pos h1]
    split_ifs <;> linarith
  · by_cases h2 : E' y ω
    · rw [if_pos (Or.inr h2), if_neg h1, if_pos h2]; linarith
    · rw [if_neg (fun h => h.elim h1 h2), if_neg h1, if_neg h2]; linarith

omit [DecidableEq U] in
theorem jProb_exists_le {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    {ι : Type*} [Fintype ι] (E : ι → (Fin r → U) → Ω → Prop) :
    jProb D w (fun y ω => ∃ j, E j y ω) ≤ ∑ j, jProb D w (E j) := by
  classical
  unfold jProb
  have e : ∑ j, ∑ y, ∑ ω, (if E j y ω then prodMass D y * w ω else 0) =
      ∑ y, ∑ ω, ∑ j, (if E j y ω then prodMass D y * w ω else 0) := by
    rw [Finset.sum_comm]
    exact Finset.sum_congr rfl fun y _ => Finset.sum_comm
  rw [e]
  refine Finset.sum_le_sum fun y _ => Finset.sum_le_sum fun ω _ => ?_
  have hm := mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
  by_cases h : ∃ j, E j y ω
  · rw [if_pos h]
    obtain ⟨j, hj⟩ := h
    calc prodMass D y * w ω = (if E j y ω then prodMass D y * w ω else 0) := by rw [if_pos hj]
      _ ≤ ∑ j', (if E j' y ω then prodMass D y * w ω else 0) :=
        Finset.single_le_sum (f := fun j' => if E j' y ω then prodMass D y * w ω else 0)
          (fun j' _ => by split_ifs <;> linarith) (Finset.mem_univ j)
  · rw [if_neg h]
    exact Finset.sum_nonneg fun j' _ => by split_ifs <;> linarith

omit [DecidableEq U] in
/-- Markov's inequality for `jProb`. -/
theorem jProb_lt_le_jExp_div {D : U → ℝ} {w : Ω → ℝ} (hD0 : ∀ a, 0 ≤ D a) (hw0 : ∀ ω, 0 ≤ w ω)
    (X : (Fin r → U) → Ω → ℝ) (hX : ∀ y ω, 0 ≤ X y ω) {a : ℝ} (ha : 0 < a) :
    jProb D w (fun y ω => a < X y ω) ≤ jExp D w X / a := by
  classical
  rw [le_div_iff₀ ha]
  unfold jProb jExp
  rw [Finset.sum_mul]
  refine Finset.sum_le_sum fun y _ => ?_
  rw [Finset.sum_mul]
  refine Finset.sum_le_sum fun ω _ => ?_
  have hm := mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)
  split_ifs with h
  · nlinarith
  · nlinarith [hX y ω]

theorem posterior_congr {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {i : Fin r} {t : 𝒯}
    {x y : Fin r → U} (h : PrefixAgree (i : ℕ) x y) (a : U) :
    posterior D w T i t x a = posterior D w T i t y a :=
  posterior_prefixDep D w T i a t x y h

theorem clipWeight_congr {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ : ℝ} {i : Fin r}
    {t : 𝒯} {x y : Fin r → U} (h : PrefixAgree (i : ℕ) x y) (a : U) :
    clipWeight D w T θ i t x a = clipWeight D w T θ i t y a := by
  unfold clipWeight; rw [posterior_congr h]

theorem condMeanV_congr {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ : ℝ} {i : Fin r}
    {t : 𝒯} {x y : Fin r → U} (h : PrefixAgree (i : ℕ) x y) (f : U → ℝ) :
    condMeanV D w T θ i t x f = condMeanV D w T θ i t y f := by
  unfold condMeanV
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [posterior_congr h, clipWeight_congr h]

section Lemma26

variable {D : U → ℝ} {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} {θ δ h ξ : ℝ} {k : ℕ}

/-- (`R:eq:error_decomposition`) `(1/r) ∑ᵢ vᵢ f(Xᵢ) - D f = M_t + B_t`. -/
theorem error_decomposition (hr : 0 < r) (f : 𝒯 → U → ℝ) (x : Fin r → U) (t : 𝒯) :
    vMean D w T θ x t (f t) - popMean D (f t) =
      martPart D w T θ f x t + driftPart D w T θ f x t := by
  have hr' : (r : ℝ) ≠ 0 := (Nat.cast_pos.2 hr).ne'
  unfold vMean martPart driftPart
  rw [← add_div, ← Finset.sum_add_distrib]
  simp only [sub_add_sub_cancel]
  rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
    sub_div, mul_div_cancel_left₀ _ hr']

/-- Step 1: `|B_t| ≤ Δ̄` for every query `f` with values in `[0,1]` (selected by the transcript). -/
theorem abs_driftPart_le (f : 𝒯 → U → ℝ) (hf : ∀ t a, 0 ≤ f t a ∧ f t a ≤ 1) (x : Fin r → U)
    (t : 𝒯) : |driftPart D w T θ f x t| ≤ avgDrift D w T θ x t := by
  unfold driftPart avgDrift
  rw [abs_div, Nat.abs_cast]
  refine div_le_div_of_nonneg_right ?_ (Nat.cast_nonneg r)
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
  exact abs_condMeanV_sub_le_condDrift i t x (f t) (hf t)

theorem finDP_delta_nonneg {w : Ω → ℝ} {T : (Fin r → U) → Ω → 𝒯} (hT : FinDP w T θ δ)
    (i : Fin r) (x : Fin r → U) : 0 ≤ δ := by
  have h := hT i x (x i) (x i) ∅
  have h0 : ∀ y : Fin r → U, coinProb w (fun ω => T y ω ∈ (∅ : Set 𝒯)) = 0 := by
    intro y
    classical
    unfold coinProb
    exact Finset.sum_eq_zero fun ω _ => if_neg (Set.notMem_empty _)
  rw [h0, mul_zero, zero_add] at h
  exact h

/-- Step 1 (`R:eq:markov_drift_failure`): `Pr[Δ̄ > h/6] ≤ E[Δ̄]/(h/6) ≤ 12δ/h ≤ ξ/2`. -/
theorem markov_drift_failure (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hT : FinDP w T θ δ) (hθ : 0 ≤ θ) (hh0 : 0 < h) (hδ0 : 0 ≤ δ) (hδ : δ ≤ 1 / 24 * h * ξ) :
    jProb D w (fun y ω => h / 6 < avgDrift D w T θ y (T y ω)) ≤ 12 * δ / h ∧ 12 * δ / h ≤ ξ / 2 := by
  refine ⟨?_, ?_⟩
  · have hX : ∀ y ω, 0 ≤ avgDrift D w T θ y (T y ω) := fun y ω =>
      div_nonneg (Finset.sum_nonneg fun i _ => condDrift_nonneg i _ _) (Nat.cast_nonneg r)
    refine (jProb_lt_le_jExp_div hD0 hw0 _ hX (by positivity : (0 : ℝ) < h / 6)).trans ?_
    have hE : jExp D w (fun y ω => avgDrift D w T θ y (T y ω)) ≤ 2 * δ := by
      have e : jExp D w (fun y ω => avgDrift D w T θ y (T y ω)) =
          (r : ℝ)⁻¹ * ∑ i : Fin r, jExp D w (fun y ω => condDrift D w T θ i (T y ω) y) := by
        rw [← jExp_sum, ← jExp_const_mul]
        refine jExp_congr D w fun y ω => ?_
        unfold avgDrift
        rw [div_eq_inv_mul]
      rw [e]
      have hb : ∀ i : Fin r, jExp D w (fun y ω => condDrift D w T θ i (T y ω) y) ≤ 2 * δ :=
        fun i => (expected_condDrift_le hD0 hD1 hw0 hT hθ hδ0 i).1.trans
          (expected_condDrift_le hD0 hD1 hw0 hT hθ hδ0 i).2
      calc (r : ℝ)⁻¹ * ∑ i : Fin r, jExp D w (fun y ω => condDrift D w T θ i (T y ω) y)
          ≤ (r : ℝ)⁻¹ * ∑ i : Fin r, 2 * δ :=
            mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => hb i)
              (inv_nonneg.2 (Nat.cast_nonneg r))
        _ = (r : ℝ)⁻¹ * r * (2 * δ) := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]; ring
        _ ≤ 2 * δ := by
            rcases Nat.eq_zero_or_pos r with hr0 | hrpos
            · subst hr0; simp; linarith
            · rw [inv_mul_cancel₀ (Nat.cast_pos.2 hrpos).ne', one_mul]
    calc jExp D w (fun y ω => avgDrift D w T θ y (T y ω)) / (h / 6) ≤ 2 * δ / (h / 6) :=
          div_le_div_of_nonneg_right hE (by positivity)
      _ = 12 * δ / h := by field_simp; ring
  · rw [div_le_iff₀ hh0]
    nlinarith

/-- Step 2, one query (Azuma with `L_i = e^θ`, `λ = rh/6`):
`Pr[|M_t| > h/6] ≤ 2 exp(-r h² / (18 e^{2θ}))`. -/
theorem azuma_one_query (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hw1 : ∑ ω, w ω = 1) (hθ : 0 ≤ θ) (hh0 : 0 < h) (hr : 0 < r) (f : 𝒯 → U → ℝ)
    (hf : ∀ t a, 0 ≤ f t a ∧ f t a ≤ 1) :
    jProb D w (fun y ω => h / 6 < |martPart D w T θ f y (T y ω)|) ≤
      2 * Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)))) := by
  classical
  have hrR : (0 : ℝ) < r := Nat.cast_pos.2 hr
  let c : (Fin r → U) × Ω → ℝ := fun ξ => prodMass D ξ.1 * w ξ.2
  have hc : ∀ ξ, 0 ≤ c ξ := fun ξ => mul_nonneg (prodMass_nonneg hD0 ξ.1) (hw0 ξ.2)
  let CE : ℕ → (Fin r → U) × Ω → ℝ := fun n ξ =>
    if hn : n < r then condMeanV D w T θ ⟨n, hn⟩ (T ξ.1 ξ.2) ξ.1 (f (T ξ.1 ξ.2)) else 0
  let Yv : ℕ → (Fin r → U) × Ω → ℝ := fun n ξ =>
    if hn : n < r then vReal D w T θ ξ.1 (T ξ.1 ξ.2) ⟨n, hn⟩ * f (T ξ.1 ξ.2) (ξ.1 ⟨n, hn⟩)
    else 0
  let Dm : ℕ → (Fin r → U) × Ω → ℝ := fun n ξ => Yv n ξ - CE n ξ
  have hRmono : ∀ n ξ ξ', sameTP T (n + 1) ξ ξ' → sameTP T n ξ ξ' :=
    fun n ξ ξ' h => ⟨h.1, fun j hj => h.2 j (Nat.lt_succ_of_lt hj)⟩
  have hCEmeas : ∀ n ξ ξ', sameTP T n ξ ξ' → CE n ξ = CE n ξ' := by
    intro n ξ ξ' h
    simp only [CE]
    split_ifs with hn
    · rw [← h.1]
      exact condMeanV_congr (fun j hj => h.2 j hj) _
    · rfl
  have hDmeas : ∀ n ξ ξ', sameTP T (n + 1) ξ ξ' → Dm n ξ = Dm n ξ' := by
    intro n ξ ξ' h
    simp only [Dm]
    rw [hCEmeas n ξ ξ' (hRmono n ξ ξ' h)]
    congr 1
    simp only [Yv]
    split_ifs with hn
    · have hpre : PrefixAgree n ξ.1 ξ'.1 := fun j hj => h.2 j (Nat.lt_succ_of_lt hj)
      have hxn : ξ'.1 ⟨n, hn⟩ = ξ.1 ⟨n, hn⟩ := h.2 ⟨n, hn⟩ (Nat.lt_succ_self n)
      unfold vReal
      rw [← h.1, hxn, clipWeight_congr hpre]
    · rfl
  have hYmem : ∀ n ξ, 0 ≤ Yv n ξ ∧ Yv n ξ ≤ Real.exp θ := by
    intro n ξ
    simp only [Yv]
    split_ifs with hn
    · have hv := clipInv_mem θ (D (ξ.1 ⟨n, hn⟩))
        (posterior D w T ⟨n, hn⟩ (T ξ.1 ξ.2) ξ.1 (ξ.1 ⟨n, hn⟩)) hθ
      have hv0 : 0 ≤ vReal D w T θ ξ.1 (T ξ.1 ξ.2) ⟨n, hn⟩ :=
        (Real.exp_pos _).le.trans hv.1
      have hf' := hf (T ξ.1 ξ.2) (ξ.1 ⟨n, hn⟩)
      refine ⟨mul_nonneg hv0 hf'.1, ?_⟩
      calc vReal D w T θ ξ.1 (T ξ.1 ξ.2) ⟨n, hn⟩ * f (T ξ.1 ξ.2) (ξ.1 ⟨n, hn⟩)
          ≤ Real.exp θ * 1 := mul_le_mul hv.2 hf'.2 hf'.1 (Real.exp_pos θ).le
        _ = Real.exp θ := mul_one _
    · exact ⟨le_rfl, (Real.exp_pos θ).le⟩
  have hmart : ∀ n ξ₀, ∑ ξ, (if sameTP T n ξ₀ ξ then c ξ * Dm n ξ else 0) = 0 := by
    intro n ξ₀
    by_cases hn : n < r
    · let i : Fin r := ⟨n, hn⟩
      have hdis := jExp_disintegrate hD0 hw0 T i
        (fun y ω b => if sameTP T n ξ₀ (y, ω) then
          clipWeight D w T θ i (T y ω) y b * f (T y ω) b - condMeanV D w T θ i (T y ω) y (f (T y ω))
          else 0)
        (fun y ω y' ω' b hT hP => by
          have hiff : sameTP T n ξ₀ (y, ω) ↔ sameTP T n ξ₀ (y', ω') := by
            constructor
            · rintro ⟨h1, h2⟩
              exact ⟨hT.symm.trans h1, fun j hj => (hP j hj).trans (h2 j hj)⟩
            · rintro ⟨h1, h2⟩
              exact ⟨hT.trans h1, fun j hj => (hP j hj).symm.trans (h2 j hj)⟩
          by_cases hs : sameTP T n ξ₀ (y, ω)
          · rw [if_pos hs, if_pos (hiff.1 hs), hT, clipWeight_congr hP, condMeanV_congr hP]
          · rw [if_neg hs, if_neg (fun h' => hs (hiff.2 h'))])
      have hrhs : jExp D w (fun y ω => ∑ b, posterior D w T i (T y ω) y b *
          (if sameTP T n ξ₀ (y, ω) then
            clipWeight D w T θ i (T y ω) y b * f (T y ω) b -
              condMeanV D w T θ i (T y ω) y (f (T y ω)) else 0)) = 0 := by
        unfold jExp
        refine Finset.sum_eq_zero fun y _ => Finset.sum_eq_zero fun ω _ => ?_
        by_cases hs : sameTP T n ξ₀ (y, ω)
        · simp only [if_pos hs]
          have : ∑ b, posterior D w T i (T y ω) y b * (clipWeight D w T θ i (T y ω) y b *
              f (T y ω) b - condMeanV D w T θ i (T y ω) y (f (T y ω))) = 0 := by
            simp only [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul,
              posterior_sum hD1 T i (T y ω) y, one_mul]
            unfold condMeanV
            rw [sub_eq_zero]
            exact Finset.sum_congr rfl fun b _ => by ring
          rw [this, mul_zero]
        · simp only [if_neg hs, mul_zero, Finset.sum_const_zero]
      refine Eq.trans ?_ (hdis.trans hrhs)
      unfold jExp
      rw [Fintype.sum_prod_type]
      refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun ω _ => ?_
      beta_reduce
      by_cases hs : sameTP T n ξ₀ (y, ω)
      · rw [if_pos hs, if_pos hs]
        simp only [c, Dm, Yv, CE, dif_pos hn]
        rfl
      · rw [if_neg hs, if_neg hs, mul_zero]
    · refine Finset.sum_eq_zero fun ξ _ => ?_
      split_ifs
      · simp [Dm, Yv, CE, dif_neg hn]
      · rfl
  have hmain := azuma_hoeffding c hc r (fun n => sameTP T n) (fun n => sameTP_equivalence T n)
    hRmono Dm (fun n ξ => -CE n ξ) (fun n ξ => Real.exp θ - CE n ξ) (fun _ => Real.exp θ) hDmeas
    (fun n ξ ξ' h => by show -CE n ξ = -CE n ξ'; rw [hCEmeas n ξ ξ' h])
    (fun n ξ ξ' h => by show Real.exp θ - CE n ξ = Real.exp θ - CE n ξ'; rw [hCEmeas n ξ ξ' h])
    hmart
    (fun n ξ _ => ⟨by simp only [Dm]; linarith [(hYmem n ξ).1],
      by simp only [Dm]; linarith [(hYmem n ξ).2]⟩)
    (fun n ξ => by show Real.exp θ - CE n ξ - -CE n ξ ≤ Real.exp θ; linarith)
    (fun _ => Real.exp_pos θ) (fun _ => 1) (fun _ => zero_le_one) (fun _ _ _ => rfl)
    ((r : ℝ) * h / 6) (by positivity)
  have he2 : Real.exp θ ^ 2 = Real.exp (2 * θ) := by rw [sq, ← Real.exp_add, two_mul]
  have hV : ∑ n ∈ range r, Real.exp θ ^ 2 = r * Real.exp (2 * θ) := by
    rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, he2]
  have hsumc : ∑ ξ, c ξ * 1 = 1 := by
    simp only [mul_one, c]
    rw [Fintype.sum_prod_type]
    simp_rw [← Finset.mul_sum, hw1, mul_one]
    exact sum_prodMass hD1
  beta_reduce at hmain
  rw [hV, hsumc, mul_one] at hmain
  have hr' : (r : ℝ) ≠ 0 := hrR.ne'
  have hexp : 2 * ((r : ℝ) * h / 6) ^ 2 / (r * Real.exp (2 * θ)) =
      (r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)) := by
    field_simp
    ring
  rw [hexp] at hmain
  refine le_trans ?_ hmain
  -- the event `h/6 < |M|` is contained in `rh/6 ≤ |∑ D_n|`
  unfold jProb
  rw [Fintype.sum_prod_type]
  refine Finset.sum_le_sum fun y _ => Finset.sum_le_sum fun ω _ => ?_
  have hsum : ∑ n ∈ range r, Dm n (y, ω) =
      ∑ i : Fin r, (vReal D w T θ y (T y ω) i * f (T y ω) (y i) -
        condMeanV D w T θ i (T y ω) y (f (T y ω))) := by
    rw [← Fin.sum_univ_eq_sum_range (fun n => Dm n (y, ω)) r]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp only [Dm, Yv, CE, dif_pos i.isLt, Fin.eta]
  by_cases hE : h / 6 < |martPart D w T θ f y (T y ω)|
  · have hcond : (r : ℝ) * h / 6 ≤ |∑ n ∈ range r, Dm n (y, ω)| := by
      rw [hsum]
      unfold martPart at hE
      rw [abs_div, abs_of_pos hrR, lt_div_iff₀ hrR] at hE
      linarith
    rw [if_pos hE, if_pos hcond]
    simp [c]
  · rw [if_neg hE]
    split_ifs
    · exact mul_nonneg (mul_nonneg (prodMass_nonneg hD0 y) (hw0 ω)) zero_le_one
    · exact le_rfl

/-- The arithmetic of (`R:eq:azuma_union_failure`):
`2(k+1) exp(-r h²/(18 e^{2θ})) ≤ 2(k+1) ((k+2)/ξ)^{-4} ≤ ξ/2`. -/
theorem azuma_union_arith (k : ℕ) (r : ℕ) (hh0 : 0 < h) (hξ0 : 0 < ξ) (hξ1 : ξ < 1)
    (hr : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r) :
    ((k : ℝ) + 1) * (2 * Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ))))) ≤ ξ / 2 := by
  have hk : (0 : ℝ) ≤ k := Nat.cast_nonneg k
  have hy : 1 < ((k : ℝ) + 2) / ξ := by rw [lt_div_iff₀ hξ0]; linarith
  have hy0 : 0 < ((k : ℝ) + 2) / ξ := by positivity
  set Lg := Real.log (((k : ℝ) + 2) / ξ) with hLg
  have hL0 : 0 < Lg := Real.log_pos hy
  have he : 0 < Real.exp (2 * θ) := Real.exp_pos _
  -- `r h²/(18 e^{2θ}) ≥ 4 Lg`
  have hh' : h ≠ 0 := hh0.ne'
  have h4 : 4 * Lg ≤ (r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)) := by
    rw [le_div_iff₀ (by positivity)]
    have := mul_le_mul_of_nonneg_right hr (show (0 : ℝ) ≤ h ^ 2 by positivity)
    have e : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Lg * h ^ 2 = 4 * Lg * (18 * Real.exp (2 * θ)) := by
      field_simp
      ring
    linarith
  have hexp : Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)))) ≤ (ξ / ((k : ℝ) + 2)) ^ 4 := by
    calc Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)))) ≤ Real.exp (-(4 * Lg)) :=
          Real.exp_le_exp.2 (by linarith)
      _ = (ξ / ((k : ℝ) + 2)) ^ 4 := by
          rw [show -(4 * Lg) = ((4 : ℕ) : ℝ) * (-Lg) by push_cast; ring, Real.exp_nat_mul,
            Real.exp_neg, hLg, Real.exp_log hy0, inv_div]
  have hξ3 : ξ ^ 3 ≤ 1 := pow_le_one₀ hξ0.le hξ1.le
  have hk2 : (0 : ℝ) < (k : ℝ) + 2 := by linarith
  have hk2' : (k : ℝ) + 2 ≠ 0 := hk2.ne'
  have hk4 : 4 * ((k : ℝ) + 1) ≤ ((k : ℝ) + 2) ^ 4 := by
    have h1 : 4 * ((k : ℝ) + 1) ≤ ((k : ℝ) + 2) ^ 2 := by nlinarith [sq_nonneg (k : ℝ)]
    have h2 : (1 : ℝ) ≤ ((k : ℝ) + 2) ^ 2 := by nlinarith
    have h3 : ((k : ℝ) + 2) ^ 2 ≤ ((k : ℝ) + 2) ^ 4 := by
      have : ((k : ℝ) + 2) ^ 4 = ((k : ℝ) + 2) ^ 2 * ((k : ℝ) + 2) ^ 2 := by ring
      rw [this]
      nlinarith
    linarith
  calc ((k : ℝ) + 1) * (2 * Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)))))
      ≤ ((k : ℝ) + 1) * (2 * (ξ / ((k : ℝ) + 2)) ^ 4) := by gcongr
    _ = ξ * (2 * ((k : ℝ) + 1) * ξ ^ 3 / ((k : ℝ) + 2) ^ 4) := by field_simp
    _ ≤ ξ * (1 / 2) := by
        refine mul_le_mul_of_nonneg_left ?_ hξ0.le
        rw [div_le_iff₀ (by positivity)]
        nlinarith [mul_nonneg (show (0 : ℝ) ≤ (k : ℝ) + 1 by positivity) (sub_nonneg.2 hξ3)]
    _ = ξ / 2 := by ring

/-- Step 2 (`R:eq:azuma_union_failure`): union over the `k + 1` queries `f_0 ≡ 1, f_1, …, f_k`:
`Pr[max_t |M_t| > h/6] ≤ 2(k+1) exp(-r h²/(18 e^{2θ})) ≤ ξ/2`. -/
theorem azuma_union_failure (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1) (hw0 : ∀ ω, 0 ≤ w ω)
    (hw1 : ∑ ω, w ω = 1) (q : 𝒯 → Fin k → U → ℝ) (hq : ∀ t j a, 0 ≤ q t j a ∧ q t j a ≤ 1)
    (hθ : 0 ≤ θ) (hh0 : 0 < h) (hξ0 : 0 < ξ) (hξ1 : ξ < 1)
    (hr : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r) :
    jProb D w (fun y ω => ∃ j : Fin (k + 1),
        h / 6 < |martPart D w T θ (fun t => extQ q t j) y (T y ω)|) ≤ ξ / 2 := by
  have hy : 1 < ((k : ℝ) + 2) / ξ := by
    rw [lt_div_iff₀ hξ0]; linarith [(Nat.cast_nonneg k : (0 : ℝ) ≤ k)]
  have hrpos : 0 < r := by
    have h1 : 0 < 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) := by
      have := Real.log_pos hy
      positivity
    exact_mod_cast lt_of_lt_of_le h1 hr
  refine (jProb_exists_le hD0 hw0 _).trans ?_
  calc ∑ j : Fin (k + 1), jProb D w (fun y ω =>
        h / 6 < |martPart D w T θ (fun t => extQ q t j) y (T y ω)|)
      ≤ ∑ j : Fin (k + 1), 2 * Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ)))) :=
        Finset.sum_le_sum fun j _ => azuma_one_query hD0 hD1 hw0 hw1 hθ hh0 hrpos
          (fun t => extQ q t j) (fun t a => extQ_mem q hq t j a)
    _ = ((k : ℝ) + 1) * (2 * Real.exp (-((r : ℝ) * h ^ 2 / (18 * Real.exp (2 * θ))))) := by
        rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
        push_cast; ring
    _ ≤ ξ / 2 := azuma_union_arith k r hh0 hξ0 hξ1 hr

/-- The division-free identity (`R:eq:division_free_identity`) and `⟨u, f(X)⟩ ∈ [0,1]`
(deterministic). -/
theorem division_free_identity (y : Fin r → U) (t : 𝒯) (f : U → ℝ)
    (hf : ∀ a, 0 ≤ f a ∧ f a ≤ 1) :
    uMean D w T θ y t f - popMean D f =
        (vMean D w T θ y t f - popMean D f) + (1 - vBar D w T θ y t) * uMean D w T θ y t f ∧
      0 ≤ uMean D w T θ y t f ∧ uMean D w T θ y t f ≤ 1 := by
  rcases Nat.eq_zero_or_pos r with hr0 | hrpos
  · subst hr0
    simp [uMean, vMean, vBar]
  have hv : ∀ i, 0 < vReal D w T θ y t i := fun i => clipInv_pos _ _ _
  have hV : 0 < ∑ l, vReal D w T θ y t l :=
    Finset.sum_pos (fun i _ => hv i) (Finset.univ_nonempty_iff.2 ⟨⟨0, hrpos⟩⟩)
  have hrR : (0 : ℝ) < r := Nat.cast_pos.2 hrpos
  have hV' : ∑ l, vReal D w T θ y t l ≠ 0 := hV.ne'
  have hr' : (r : ℝ) ≠ 0 := hrR.ne'
  have hu : uMean D w T θ y t f =
      (∑ i, vReal D w T θ y t i * f (y i)) / ∑ l, vReal D w T θ y t l := by
    unfold uMean comparator
    rw [Finset.sum_div]
    refine Finset.sum_congr rfl fun i _ => ?_
    ring
  refine ⟨?_, ?_, ?_⟩
  · rw [hu]
    unfold vMean vBar
    field_simp
    ring
  · rw [hu]
    exact div_nonneg (Finset.sum_nonneg fun i _ => mul_nonneg (hv i).le (hf (y i)).1) hV.le
  · rw [hu, div_le_one hV]
    exact Finset.sum_le_sum fun i _ => by
      have := mul_le_mul_of_nonneg_left (hf (y i)).2 (hv i).le
      linarith

/-- **Lemma `R:lem:concentration_and_normalization`** (`C = 72`, `c = 1/24`).
(i) With probability `≥ 1 - ξ`, `ConcEvent` holds (all `t ∈ {0..k}`), and on it `|v̄ - 1| ≤ h/3`;
(ii) the division-free identity (`R:eq:division_free_identity`) holds deterministically, with
`⟨u, f(X)⟩ ∈ [0,1]`; (iii) on `ConcEvent`, for all `1 ≤ t ≤ k`,
`|⟨u, f_t(X)⟩ - D f_t| ≤ |(1/r)∑ vᵢ f_t(Xᵢ) - D f_t| + |1 - v̄| ≤ 2h/3 < h`
(`R:eq:normalized_concentration`). -/
theorem concentration_and_normalization (hD0 : ∀ a, 0 ≤ D a) (hD1 : ∑ a, D a = 1)
    (hw0 : ∀ ω, 0 ≤ w ω) (hw1 : ∑ ω, w ω = 1) (hT : FinDP w T θ δ) (q : 𝒯 → Fin k → U → ℝ)
    (hq : ∀ t j a, 0 ≤ q t j a ∧ q t j a ≤ 1) (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (hh0 : 0 < h)
    (hh1 : h ≤ 1) (hξ0 : 0 < ξ) (hξ1 : ξ < 1)
    (hr : 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r)
    (hδ : δ ≤ 1 / 24 * h * ξ) :
    -- (i)
    (jProb D w (fun y ω => ¬ ConcEvent D w T θ q h y (T y ω)) ≤ ξ ∧
      ∀ y t, ConcEvent D w T θ q h y t → |vBar D w T θ y t - 1| ≤ h / 3) ∧
    -- (ii)
    (∀ y t (f : U → ℝ), (∀ a, 0 ≤ f a ∧ f a ≤ 1) →
      uMean D w T θ y t f - popMean D f =
          (vMean D w T θ y t f - popMean D f) + (1 - vBar D w T θ y t) * uMean D w T θ y t f ∧
        0 ≤ uMean D w T θ y t f ∧ uMean D w T θ y t f ≤ 1) ∧
    -- (iii)
    (∀ y t, ConcEvent D w T θ q h y t → ∀ j : Fin k,
      |uMean D w T θ y t (q t j) - popMean D (q t j)| ≤
          |vMean D w T θ y t (q t j) - popMean D (q t j)| + |1 - vBar D w T θ y t| ∧
        |vMean D w T θ y t (q t j) - popMean D (q t j)| + |1 - vBar D w T θ y t| ≤ 2 / 3 * h ∧
        2 / 3 * h < h) := by
  have hy : 1 < ((k : ℝ) + 2) / ξ := by
    rw [lt_div_iff₀ hξ0]; linarith [(Nat.cast_nonneg k : (0 : ℝ) ≤ k)]
  have hrpos : 0 < r := by
    have h1 : 0 < 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) := by
      have := Real.log_pos hy
      positivity
    exact_mod_cast lt_of_lt_of_le h1 hr
  -- `δ ≥ 0` (DP with `E = ∅`)
  have hδ0 : 0 ≤ δ := by
    have hU : Nonempty U := by
      by_contra hne
      rw [not_nonempty_iff] at hne
      rw [Finset.univ_eq_empty_iff.2 hne, Finset.sum_empty] at hD1
      norm_num at hD1
    obtain ⟨a₀⟩ := hU
    exact finDP_delta_nonneg hT ⟨0, hrpos⟩ (fun _ => a₀)
  -- `v̄` is the weighted mean of `f_0 ≡ 1`, and `D f_0 = 1`
  have hbar : ∀ y t, vMean D w T θ y t (extQ q t 0) = vBar D w T θ y t := by
    intro y t
    rw [extQ_zero]
    simp [vMean, vBar]
  have hpop1 : ∀ t, popMean D (extQ q t 0) = 1 := by
    intro t
    rw [extQ_zero]
    simp [popMean, hD1]
  have hvbar : ∀ y t, ConcEvent D w T θ q h y t → |vBar D w T θ y t - 1| ≤ h / 3 := by
    intro y t hC
    have := hC 0
    rwa [hbar, hpop1] at this
  have hii := fun y t f hf => division_free_identity (D := D) (w := w) (T := T) (θ := θ) y t f hf
  refine ⟨⟨?_, hvbar⟩, hii, ?_⟩
  · -- (i): union of the drift event and the martingale events
    have hsub : ∀ y ω, ¬ ConcEvent D w T θ q h y (T y ω) →
        h / 6 < avgDrift D w T θ y (T y ω) ∨
          ∃ j : Fin (k + 1), h / 6 < |martPart D w T θ (fun t => extQ q t j) y (T y ω)| := by
      intro y ω hnot
      by_contra hcon
      simp only [not_or, not_exists, not_lt] at hcon
      apply hnot
      intro j
      rw [error_decomposition hrpos (fun t => extQ q t j)]
      have hB := abs_driftPart_le (D := D) (w := w) (T := T) (θ := θ) (fun t => extQ q t j)
        (fun t a => extQ_mem q hq t j a) y (T y ω)
      calc |martPart D w T θ (fun t => extQ q t j) y (T y ω) +
            driftPart D w T θ (fun t => extQ q t j) y (T y ω)|
          ≤ |martPart D w T θ (fun t => extQ q t j) y (T y ω)| +
            |driftPart D w T θ (fun t => extQ q t j) y (T y ω)| := abs_add_le _ _
        _ ≤ h / 6 + h / 6 := add_le_add (hcon.2 j) (hB.trans hcon.1)
        _ = h / 3 := by ring
    calc jProb D w (fun y ω => ¬ ConcEvent D w T θ q h y (T y ω))
        ≤ jProb D w (fun y ω => h / 6 < avgDrift D w T θ y (T y ω) ∨
            ∃ j : Fin (k + 1), h / 6 < |martPart D w T θ (fun t => extQ q t j) y (T y ω)|) :=
          jProb_mono hD0 hw0 hsub
      _ ≤ jProb D w (fun y ω => h / 6 < avgDrift D w T θ y (T y ω)) +
            jProb D w (fun y ω => ∃ j : Fin (k + 1),
              h / 6 < |martPart D w T θ (fun t => extQ q t j) y (T y ω)|) :=
          jProb_or_le hD0 hw0 _ _
      _ ≤ ξ / 2 + ξ / 2 := by
          refine add_le_add ?_ (azuma_union_failure hD0 hD1 hw0 hw1 q hq hθ0.le hh0 hξ0 hξ1 hr)
          obtain ⟨h1, h2⟩ := markov_drift_failure hD0 hD1 hw0 hT hθ0.le hh0 hδ0 hδ
          exact h1.trans h2
      _ = ξ := by ring
  · -- (iii)
    intro y t hC j
    obtain ⟨hid, hu0, hu1⟩ := hii y t (q t j) (hq t j)
    have hj := hC j.succ
    rw [extQ_succ] at hj
    have hb := hvbar y t hC
    refine ⟨?_, ?_, by linarith⟩
    · rw [hid]
      calc |(vMean D w T θ y t (q t j) - popMean D (q t j)) +
            (1 - vBar D w T θ y t) * uMean D w T θ y t (q t j)|
          ≤ |vMean D w T θ y t (q t j) - popMean D (q t j)| +
            |(1 - vBar D w T θ y t) * uMean D w T θ y t (q t j)| := abs_add_le _ _
        _ ≤ |vMean D w T θ y t (q t j) - popMean D (q t j)| + |1 - vBar D w T θ y t| := by
            have hu : |uMean D w T θ y t (q t j)| ≤ 1 := abs_le.2 ⟨by linarith, hu1⟩
            have hm : |(1 - vBar D w T θ y t) * uMean D w T θ y t (q t j)| ≤
                |1 - vBar D w T θ y t| := by
              rw [abs_mul]
              calc |1 - vBar D w T θ y t| * |uMean D w T θ y t (q t j)|
                  ≤ |1 - vBar D w T θ y t| * 1 := mul_le_mul_of_nonneg_left hu (abs_nonneg _)
                _ = |1 - vBar D w T θ y t| := mul_one _
            linarith
    · rw [abs_sub_comm] at hb
      linarith

end Lemma26

/-! ### Remark `R:rem:sec2_log_k_plus_1` -/

/-- `(k+2)/ξ ≤ ((k+1)/ξ)²` for `k ≥ 1`, `ξ ∈ (0,1)`, hence `log((k+2)/ξ) ≤ 2 log((k+1)/ξ)`. -/
theorem log_k_plus_one (k : ℕ) (hk : 1 ≤ k) (ξ : ℝ) (hξ0 : 0 < ξ) (hξ1 : ξ < 1) :
    ((k : ℝ) + 2) / ξ ≤ (((k : ℝ) + 1) / ξ) ^ 2 ∧
      Real.log (((k : ℝ) + 2) / ξ) ≤ 2 * Real.log (((k : ℝ) + 1) / ξ) := by
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have h1 : ((k : ℝ) + 2) / ξ ≤ (((k : ℝ) + 1) / ξ) ^ 2 := by
    rw [div_pow, div_le_div_iff₀ hξ0 (by positivity)]
    have h2 : (0 : ℝ) ≤ ((k : ℝ) + 1) ^ 2 - ((k : ℝ) + 2) * ξ := by nlinarith
    nlinarith [mul_nonneg hξ0.le h2]
  refine ⟨h1, ?_⟩
  have hpos : 0 < ((k : ℝ) + 2) / ξ := by positivity
  calc Real.log (((k : ℝ) + 2) / ξ) ≤ Real.log ((((k : ℝ) + 1) / ξ) ^ 2) :=
        Real.log_le_log hpos h1
    _ = 2 * Real.log (((k : ℝ) + 1) / ξ) := by
        rw [Real.log_pow]; push_cast; ring

/-- Remark `R:rem:sec2_log_k_plus_1`: `r ≥ 144 e^{2θ} h^{-2} log((k+1)/ξ)` implies
(`R:eq:r_delta_scales`) `r ≥ 72 e^{2θ} h^{-2} log((k+2)/ξ)` for `k ≥ 1`, `ξ ∈ (0,1)`. -/
theorem sample_scale_of_k_plus_one (k : ℕ) (hk : 1 ≤ k) (ξ θ h : ℝ) (r : ℕ) (hξ0 : 0 < ξ)
    (hξ1 : ξ < 1) (hr : 144 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 1) / ξ) ≤ r) :
    72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ) ≤ r := by
  have hl := (log_k_plus_one k hk ξ hξ0 hξ1).2
  have hc : 0 ≤ 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ := by positivity
  calc 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 2) / ξ)
      ≤ 72 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * (2 * Real.log (((k : ℝ) + 1) / ξ)) :=
        mul_le_mul_of_nonneg_left hl hc
    _ = 144 * Real.exp (2 * θ) * (h ^ 2)⁻¹ * Real.log (((k : ℝ) + 1) / ξ) := by ring
    _ ≤ r := hr

end F2e2e.Comparator
