import F2e2e.B.ArchOnline
import F2e2e.B.PrivacySim

/-!
# Algorithm 2 as a data-oblivious skeleton with stream oracles (for the privacy analysis)

Paper: `parts/partII.tex` L1004–1008 ("give each stream its own conceptual copy of the selected block
and reconstruct its scores from that copy and the common protected-command history").

The core of Algorithm 2 (`F2e2e/B/ArchCore.lean`, `F2e2e/B/ArchOnline.lean`, B-ARCH) is stored-state
code. Here it is rewritten as a skeleton `skRunD P ctrl T : CProg U (List CoreOut)` that never reads the
sample: every noise draw happens inside a stream oracle (`Strm`: the internal edges `edge e`, the outer
validator `outer`, the numerical releases `num`), and the oracles compute their gaps/centers from the
information `CInfo` (the protected command history of corrections, the current query, the rounded
endpoints) and the sample, through the replica reconstruction `replay` of the scores (`coreSpec`). The
refinement `coreRunD = skRunD` (in law) is in `F2e2e/B/PrivacyRefine.lean`.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete F2e2e.B

/-- The streams of Algorithm 2: the internal edges, the outer validator, the numerical releases. -/
inductive Strm where
  | edge : ℕ → Strm
  | outer : Strm
  | num : Strm
  deriving DecidableEq

/-- The information sent with a query: the protected command history (corrections `(edge, sign,
query)`), the current query, and the rounded clipped endpoints of an interval request. -/
structure CInfo (U : Type) where
  /-- the corrections applied so far, oldest first -/
  hist : List (ℕ × Bool × (U → ℕ))
  /-- the current query (grid indices) -/
  f : U → ℕ
  /-- rounded clipped lower endpoint `l̃` -/
  lt : ℚ
  /-- rounded clipped upper endpoint `ũ` -/
  ut : ℚ

variable {U : Type}

/-- The block-structured grid indices of a query on the sample (`coreVals`). -/
def valsOf (P : AdaParams) (s : Fin P.N → U) (f : U → ℕ) : List (List ℕ) :=
  splitBlocks P.blockSizes (List.ofFn fun ℓ => f (s ℓ))

theorem coreVals_eq_valsOf (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) :
    coreVals P s req = valsOf P s req.f := rfl

/-- The data-dependent part of a correction on edge `j` with sign `q` (scores and weights,
`applyCorrection` without the threshold redraws and the counter). -/
def corrScores (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    AdaState :=
  let qz : ℤ := if q then 1 else -1
  let gj := addScaled (st.scores.getD j []) (4 * qz) (blockVals P vals j)
  let g1 := st.scores.set j gj
  let w1 := st.weights.set j (capWeightsQ (scoreScale P) gj)
  let gj1 := addScaled (g1.getD (j + 1) []) (-qz) (blockVals P vals (j + 1))
  let g2 := if j + 1 < P.p then g1.set (j + 1) gj1 else g1
  let w2 := if j + 1 < P.p then w1.set (j + 1) (capWeightsQ (scoreScale P) gj1) else w1
  { st with scores := g2, weights := w2 }

/-- The replica reconstruction: the scores and weights after the corrections `hist`. -/
def replay (P : AdaParams) (s : Fin P.N → U) (hist : List (ℕ × Bool × (U → ℕ))) : AdaState :=
  hist.foldl (fun st c => corrScores P st (valsOf P s c.2.2) c.1 c.2.1) (adaInitState P [] 0)

/-- The predictions `[μ_0, …, μ_p]` of the replica reconstruction. -/
def recMus (P : AdaParams) (s : Fin P.N → U) (i : CInfo U) : List ℚ :=
  adaMus P (replay P s i.hist) (valsOf P s i.f)

/-- The stream oracles of Algorithm 2 reading the sample `s`. -/
def coreSpec (P : AdaParams) : Strm → StreamSpec (CInfo U) (Fin P.N → U) NoiseKind
  | .edge e =>
    { pT := .intThr, pQ := .intTest, pR := .num, h := P.hA, c := P.tau
      gap := fun i s => ((recMus P s i).getD (e + 1) 0 - (recMus P s i).getD e 0,
        -((recMus P s i).getD (e + 1) 0 - (recMus P s i).getD e 0))
      center := fun _ _ => 0 }
  | .outer =>
    { pT := .outThr, pQ := .outTest, pR := .num, h := P.hA, c := P.a / 2
      gap := fun i s => ((recMus P s i).getD 0 0 - i.ut, i.lt - (recMus P s i).getD 0 0)
      center := fun _ _ => 0 }
  | .num =>
    { pT := .intThr, pQ := .intTest, pR := .num, h := P.hA, c := 0
      gap := fun _ _ => (0, 0)
      center := fun i s => roundIdxQ P.hA ((recMus P s i).getD 0 0) }

/-! ## The skeleton -/

/-- The data-free part of the state of Algorithm 2. -/
structure SkState (U : Type) where
  /-- the protected command history -/
  hist : List (ℕ × Bool × (U → ℕ))
  /-- corrections per edge -/
  T : List ℕ
  /-- rejections -/
  rej : ℕ
  /-- interval requests processed -/
  nInt : ℕ
  /-- numerical requests processed -/
  nNum : ℕ
  /-- halted -/
  halted : Bool
  /-- `CAP_ABORT` -/
  capAborted : Bool

/-- Skeletons of Algorithm 2. -/
abbrev CProg (U α : Type) : Type := OProg Strm NoiseKind ℤ (SQuery (CInfo U)) SResp α

/-- Apply a function to the output. -/
def OProg.map {S P β Q R α γ : Type} (f : α → γ) (E : OProg S P β Q R α) : OProg S P β Q R γ :=
  E.bind fun a => .ret (f a)

/-- The internal test of edge `j` (lines [5]–[7]). -/
def skEdgeTest (hist : List (ℕ × Bool × (U → ℕ))) (f : U → ℕ) (j : ℕ) : CProg U SResp :=
  .call (.edge j) (.test ⟨hist, f, 0, 0⟩) .ret

/-- Reopen the internal phases of the edges `es`, in order (fresh thresholds). -/
def skRedraw : List ℕ → CProg U Unit
  | [] => .ret ()
  | e :: es => .call (.edge e) .reopen fun _ => skRedraw es

/-- A correction on edge `j` with sign `q` (lines [8]–[9]). -/
def skApplyCorrection (P : AdaParams) (sk : SkState U) (f : U → ℕ) (j : ℕ) (q : Bool) :
    CProg U (SkState U) :=
  (skRedraw (reopenEdges P j)).bind fun _ =>
    .ret { sk with hist := sk.hist ++ [(j, q, f)], T := sk.T.set j (sk.T.getD j 0 + 1) }

/-- One scan pass (as `scanPass`). -/
def skScanPass (P : AdaParams) (f : U → ℕ) :
    List ℕ → SkState U → List Bool → CProg U (PassOut × SkState U × List Bool)
  | [], sk, cache => .ret (PassOut.done, sk, cache)
  | j :: es, sk, cache =>
    if cache.getD j false = true then skScanPass P f es sk cache
    else (skEdgeTest sk.hist f j).bind fun r =>
      match r with
      | .cross q =>
        if P.Tmax.getD j 0 ≤ sk.T.getD j 0 then .ret (PassOut.abort, sk, cache)
        else (skApplyCorrection P sk f j q).bind fun sk' =>
          .ret (PassOut.corrected, sk', (reopenEdges P j).foldl (fun c e => c.set e false) cache)
      | _ => skScanPass P f es sk (cache.set j true)

/-- `PrepareRoot` (as `prepareRoot`). -/
def skPrepareRoot (P : AdaParams) (f : U → ℕ) :
    ℕ → SkState U → List Bool → CProg U (Option (SkState U))
  | 0, _, _ => .ret none
  | fuel + 1, sk, cache =>
    (skScanPass P f (List.range P.p) sk cache).bind fun r =>
      match r.1 with
      | PassOut.done => .ret (some r.2.1)
      | PassOut.corrected => skPrepareRoot P f fuel r.2.1 r.2.2
      | PassOut.abort => .ret none

/-- An outer rejection (as `outerReject`). -/
def skOuterReject (P : AdaParams) (sk : SkState U) (high : Bool) : CProg U (AdaCert × SkState U) :=
  if P.J + 1 ≤ sk.rej + 1 then
    .ret (if high then AdaCert.termHigh else AdaCert.termLow,
      { sk with rej := sk.rej + 1, halted := true })
  else .call .outer .reopen fun _ =>
    .ret (if high then AdaCert.high else AdaCert.low, { sk with rej := sk.rej + 1 })

/-- `Interval(f, [l, u])` (as `adaIntervalD`). -/
def skIntervalD (P : AdaParams) (sk : SkState U) (f : U → ℕ) (l u : ℚ) :
    CProg U (AdaCert × SkState U) :=
  if sk.halted = true ∨ P.M ≤ sk.nInt then .ret (AdaCert.abort, sk)
  else
    (skPrepareRoot P f P.fuel { sk with nInt := sk.nInt + 1 } (List.replicate P.p false)).bind
      fun r =>
      match r with
      | none => .ret (AdaCert.abort, { sk with nInt := sk.nInt + 1, halted := true, capAborted := true })
      | some sk2 =>
        .call .outer (.test ⟨sk2.hist, f, P.hA * (roundIdxQ P.hA (clipQ (-1) 2 l) : ℚ),
            P.hA * (roundIdxQ P.hA (clipQ (-1) 2 u) : ℚ)⟩) fun r =>
          match r with
          | .cross true => skOuterReject P sk2 true
          | .cross false => skOuterReject P sk2 false
          | _ => .ret (AdaCert.accept, sk2)

/-- `Numerical(f)` (as `adaNumericalD`). -/
def skNumericalD (P : AdaParams) (sk : SkState U) (f : U → ℕ) : CProg U (AdaNum × SkState U) :=
  if sk.halted = true ∨ P.R ≤ sk.nNum then .ret (AdaNum.abort, sk)
  else
    (skPrepareRoot P f P.fuel { sk with nNum := sk.nNum + 1 } (List.replicate P.p false)).bind
      fun r =>
      match r with
      | none => .ret (AdaNum.abort, { sk with nNum := sk.nNum + 1, halted := true, capAborted := true })
      | some sk2 => .call .num (.release ⟨sk2.hist, f, 0, 0⟩) fun r =>
          match r with
          | .value v => .ret (AdaNum.val (clipQ 0 1 (P.hA * (v : ℚ))), sk2)
          | _ => .ret (AdaNum.abort, sk2)

/-- One online round (as `coreStepD`). -/
def skStepD (P : AdaParams) (req : CoreReq U) (sk : SkState U) : CProg U (CoreOut × SkState U) :=
  if req.isInterval = true then
    (skIntervalD P sk req.f req.l req.u).map fun r => (Sum.inl r.1, r.2)
  else (skNumericalD P sk req.f).map fun r => (Sum.inr r.1, r.2)

/-- `T` online rounds (as `coreLoopD`). -/
def skLoopD (P : AdaParams) (ctrl : CoreCtrl U) :
    ℕ → SkState U → List CoreOut → CProg U (List CoreOut)
  | 0, _, hist => .ret hist
  | T + 1, sk, hist => (skStepD P (ctrl hist) sk).bind fun r => skLoopD P ctrl T r.2 (hist ++ [r.1])

/-- The initial data-free state. -/
def skInit (P : AdaParams) : SkState U where
  hist := []
  T := List.replicate P.p 0
  rej := 0
  nInt := 0
  nNum := 0
  halted := false
  capAborted := false

/-- Initialization (as `adaInitD`): open the internal phases `0, …, p−1`, then the outer phase. -/
def skInitD (P : AdaParams) : CProg U (SkState U) :=
  (skRedraw (List.range P.p)).bind fun _ => .call .outer .reopen fun _ => .ret (skInit P)

/-- The online execution (as `coreRunD`). -/
def skRunD (P : AdaParams) (ctrl : CoreCtrl U) (T : ℕ) : CProg U (List CoreOut) :=
  (skInitD P).bind fun sk => skLoopD P ctrl T sk []

/-! ## The refinement relation -/

/-- Counters agree and the stored scores/weights are the replica reconstruction. -/
def Rel0 (P : AdaParams) (s : Fin P.N → U) (st : AdaState) (sk : SkState U) : Prop :=
  st.T = sk.T ∧ st.rej = sk.rej ∧ st.nInt = sk.nInt ∧ st.nNum = sk.nNum ∧ st.halted = sk.halted ∧
    st.capAborted = sk.capAborted ∧ st.scores = (replay P s sk.hist).scores ∧
    st.weights = (replay P s sk.hist).weights

/-- The persistent thresholds of the open phases are the oracle states. -/
def RelT (P : AdaParams) (st : AdaState) (σ : Strm → Option ℤ) : Prop :=
  st.thrInt.length = P.p ∧ (∀ e < P.p, σ (Strm.edge e) = some (st.thrInt.getD e 0)) ∧
    σ Strm.outer = some st.thrOut

/-- The refinement relation: `Rel0`, and the thresholds while running. -/
def Rel (P : AdaParams) (s : Fin P.N → U) (st : AdaState) (sk : SkState U) (σ : Strm → Option ℤ) :
    Prop :=
  Rel0 P s st sk ∧ (st.halted = false → RelT P st σ)

section Rels

variable (P : AdaParams) (s : Fin P.N → U)

/-! ## Output relations -/

/-- Outputs of an edge test: accept with unchanged oracle states, or a crossing closing the phase. -/
def EdgeR (σ : Strm → Option ℤ) (j : ℕ) (r : Option Bool) (o : SResp × (Strm → Option ℤ)) : Prop :=
  (r = none ∧ o.1 = SResp.accept ∧ o.2 = σ) ∨
    (∃ q, r = some q ∧ o.1 = SResp.cross q ∧ o.2 = Function.update σ (Strm.edge j) none)

/-- Outputs of a threshold redraw over the edges `es` starting from `thr` and `σ`. -/
def RedrawR (σ : Strm → Option ℤ) (thr : List ℤ) (es : List ℕ) (thr' : List ℤ)
    (o : Unit × (Strm → Option ℤ)) : Prop :=
  thr'.length = thr.length ∧
    (∀ e ∈ es, e < thr.length → o.2 (Strm.edge e) = some (thr'.getD e 0)) ∧
    (∀ e, e ∉ es → o.2 (Strm.edge e) = σ (Strm.edge e) ∧ thr'.getD e 0 = thr.getD e 0) ∧
    o.2 Strm.outer = σ Strm.outer ∧ o.2 Strm.num = σ Strm.num

/-- `RelT` except possibly at edge `j` (just crossed, about to be reopened). -/
def RelTx (st : AdaState) (σ : Strm → Option ℤ) (j : ℕ) : Prop :=
  st.thrInt.length = P.p ∧ (∀ e < P.p, e ≠ j → σ (Strm.edge e) = some (st.thrInt.getD e 0)) ∧
    σ Strm.outer = some st.thrOut

/-- Outputs of a scan pass. -/
def ScanR (r : PassOut × AdaState × List Bool) (o : (PassOut × SkState U × List Bool) × (Strm → Option ℤ)) :
    Prop :=
  r.1 = o.1.1 ∧ r.2.2 = o.1.2.2 ∧ Rel0 P s r.2.1 o.1.2.1 ∧ (r.1 ≠ PassOut.abort → RelT P r.2.1 o.2)

/-- Outputs of `PrepareRoot`. -/
def PrepR (r : Option AdaState) (o : Option (SkState U) × (Strm → Option ℤ)) : Prop :=
  (r = none ∧ o.1 = none) ∨
    (∃ st2 sk2, r = some st2 ∧ o.1 = some sk2 ∧ Rel0 P s st2 sk2 ∧ RelT P st2 o.2)

/-- Outputs of a call: equal responses and related states. -/
def CallR {A : Type} (r : A × AdaState) (o : (A × SkState U) × (Strm → Option ℤ)) : Prop :=
  r.1 = o.1.1 ∧ Rel P s r.2 o.1.2 o.2

/-! ## Helper facts -/

theorem getD_set_self' {l : List ℤ} {i : ℕ} {a : ℤ} (h : i < l.length) : (l.set i a).getD i 0 = a := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set_self h]; rfl

theorem getD_set_ne' {l : List ℤ} {i j : ℕ} {a : ℤ} (h : i ≠ j) :
    (l.set i a).getD j 0 = l.getD j 0 := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_set_ne h, ← List.getD_eq_getElem?_getD]

omit s in
theorem adaMus_congr {st st' : AdaState} (h : st.weights = st'.weights) (vals : List (List ℕ)) :
    adaMus P st vals = adaMus P st' vals := by
  unfold adaMus; rw [h]

theorem recMus_eq {st : AdaState} {sk : SkState U} (h0 : Rel0 P s st sk) (f : U → ℕ) (lt ut : ℚ) :
    recMus P s ⟨sk.hist, f, lt, ut⟩ = adaMus P st (valsOf P s f) :=
  adaMus_congr P h0.2.2.2.2.2.2.2.symm _

omit s in
theorem corrScores_congr {st st' : AdaState} (h1 : st.scores = st'.scores)
    (h2 : st.weights = st'.weights) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    (corrScores P st vals j q).scores = (corrScores P st' vals j q).scores ∧
      (corrScores P st vals j q).weights = (corrScores P st' vals j q).weights := by
  constructor <;> simp only [corrScores, h1, h2]

theorem replay_append (hist : List (ℕ × Bool × (U → ℕ))) (c : ℕ × Bool × (U → ℕ)) :
    replay P s (hist ++ [c]) = corrScores P (replay P s hist) (valsOf P s c.2.2) c.1 c.2.1 := by
  simp only [replay, List.foldl_append, List.foldl_cons, List.foldl_nil]

omit s in
theorem applyCorrection_eq (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    applyCorrection P st vals j q =
      (redrawThresholds P (reopenEdges P j) st.thrInt).bind fun thr =>
        DrawProg.ret { corrScores P st vals j q with
          T := st.T.set j (st.T.getD j 0 + 1), thrInt := thr } := rfl

omit s in
theorem mem_reopenEdges_self (j : ℕ) : j ∈ reopenEdges P j := by
  simp [reopenEdges]

end Rels

end F2e2e.B.Priv
