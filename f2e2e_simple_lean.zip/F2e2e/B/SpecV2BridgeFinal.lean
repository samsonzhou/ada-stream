import F2e2e.B.SpecV2BridgeExec
import F2e2e.B.SpecV2BridgeMono
import F2e2e.B.SpecV2BridgeMeas
import F2e2e.B.SpecV2BridgeParams
import F2e2e.B.AccuracyFinal

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 5b: the guarantee of the Spec's Algorithm 2

* `parCorr_alg2`: the parameter correspondence for the Spec's parameters (from B-NUM's `v2par_*`,
  `F2e2e/B/SpecV2BridgeParams.lean`);
* `v2Fails_imp_coreFails`: a covered incorrect response of the Spec's mechanism is a covered
  incorrect core output; an internal failure at round `t` (abort flag, or a correction count
  reaching its cap, as reported by `alg2Exec`) is `internalFails` of the core state after `t + 1`
  rounds, hence of the final state (`coreRunS_internalFails_mono`);
* `v2DetFailMass_le`, `alg2V2_det`: the deterministic-controller form of
  `F2e2e.VGuaranteeWithInternalCaps` from B-ACC's `accuracy_core_guarantee_detS`
  (`CoreGuaranteeDetS`, union event bounded by one `ξ_req`);
* `vGuaranteeWithInternalCaps_of_det`: deterministic ⇒ randomized controllers, given measurability
  of the union event in the controller's coins; `alg2V2_meas`: that measurability
  (`F2e2e/B/SpecV2BridgeMeas.lean`);
* `alg2V2_guarantee`: `∃ c, VGuaranteeWithInternalCaps … (alg2Mech … c) (alg2Aborted … c)
  (alg2PeakCorrections … c)` with `c = adaCoins (adaAlg2Params …)`: the guarantee conjunct of
  `F2e2e.Theorem_B_statistical` (the headline `theorem_B_statistical_proof` is in
  `F2e2e/B/Final.lean`).

The interaction lemmas of the second section (`v2Responses_prefix`, `coreReqAt_specToCoreV2`,
`vResponse_eq_outRespV2`, …, and the identity `toV2`) are copies of the `ArchMeas`/`ArchBridge`
ones, kept from the draft of this file written against a namespaced copy of the Spec; merging them
is a post-lock refactor.
-/

namespace F2e2e.B.V2

open F2e2e.Discrete F2e2e.B.Bridge MeasureTheory

/-! ## The parameter correspondence for the Spec's parameters -/

theorem parCorr_alg2 (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ParCorr (F2e2e.alg2Params M J R aReq ξReq) (adaAlg2Params M J R aReq ξReq) := by
  have hdraw : ∀ (κ : NoiseKind) (b : ℚ), b = (adaAlg2Params M J R aReq ξReq).scale κ → ∀ t,
      (F2e2e.alg2Params M J R aReq ξReq).draw b t =
        (adaDraw (adaAlg2Params M J R aReq ξReq) κ).run t := by
    intro κ b hb t
    rw [v2par_draw M J R ha0 ha1 hξ0 hξ1 b t, latticeSample_eq, hb]
    rfl
  exact
    { hM := v2par_M M J R aReq ξReq
      hJ := v2par_J M J R aReq ξReq
      hR := v2par_R M J R aReq ξReq
      hp := v2par_p M J R aReq ξReq
      hblen := by simp [adaAlg2Params, adaParams, adaBlockSizes]
      hn := fun j hj => v2par_n M J R ha0 ha1 hξ0 hξ1 j hj
      hTlen := by simp [adaAlg2Params, adaParams, adaTmaxList]
      hTmax := fun j => v2par_Tmax M J R aReq ξReq j
      ha := v2par_a M J R aReq ξReq
      htau := v2par_tau M J R aReq ξReq
      hkappa := v2par_kappa M J R aReq ξReq
      hhA := v2par_hA M J R ha0 ha1 hξ0 hξ1
      dIntThr := hdraw NoiseKind.intThr _ (by rw [v2par_bInt M J R ha0 ha1 hξ0 hξ1]; rfl)
      dIntTest := hdraw NoiseKind.intTest _ (by rw [v2par_bInt M J R ha0 ha1 hξ0 hξ1]; rfl)
      dOutThr := hdraw NoiseKind.outThr _ (by rw [v2par_bOut M J R ha0 ha1 hξ0 hξ1]; rfl)
      dOutTest := hdraw NoiseKind.outTest _ (by rw [v2par_bOut M J R ha0 ha1 hξ0 hξ1]; rfl)
      dNum := hdraw NoiseKind.num _ (by rw [v2par_bNum M J R ha0 ha1 hξ0 hξ1]; rfl) }

/-! ## Copies of the interaction lemmas of `ArchMeas`/`ArchBridge` for the Spec's mechanism -/

/-- The identity on responses (from the draft, where it mapped the responses of two copies of the
Spec onto each other). -/
def toV2 : F2e2e.VResponse → F2e2e.VResponse
  | F2e2e.VResponse.accept => F2e2e.VResponse.accept
  | F2e2e.VResponse.high => F2e2e.VResponse.high
  | F2e2e.VResponse.low => F2e2e.VResponse.low
  | F2e2e.VResponse.num q => F2e2e.VResponse.num q

theorem outRespV2_eq (out : CoreOut) : outRespV2 out = toV2 (outResp out) := by
  rcases out with c | x
  · cases c <;> rfl
  · cases x <;> rfl

theorem vCorrectV2_iff {U : Type} [Fintype U] (D : U → ℝ) (a : ℝ) (r : (U → ℝ) × Bool × ℝ × ℝ)
    (resp : F2e2e.VResponse) :
    F2e2e.VCorrect D a r (toV2 resp) ↔ F2e2e.VCorrect D a r resp := by
  cases resp <;> exact Iff.rfl

theorem outRespV2_isReject (out : CoreOut) : (outRespV2 out).isReject = coreIsReject out := by
  rcases out with c | x
  · cases c <;> rfl
  · cases x <;> rfl

theorem v2Responses_prefix {U : Type} {N c : ℕ} (mech : F2e2e.VMechanism N c)
    (ctrl : F2e2e.VController U) (s : Fin N → U) (ω : Fin c → Bool) :
    ∀ (k j : ℕ) (hjk : j ≤ k) (i : Fin j),
      F2e2e.vResponses mech ctrl s ω j i = F2e2e.vResponses mech ctrl s ω k (Fin.castLE hjk i) := by
  intro k
  induction k with
  | zero =>
    intro j hj i
    have : j = 0 := by omega
    subst this
    exact i.elim0
  | succ k ih =>
    intro j hj i
    rcases Nat.lt_or_ge j (k + 1) with hlt | hge
    · rw [ih j (by omega) i, v2Responses_succ]
      have : (Fin.castLE hj i) = Fin.castSucc (Fin.castLE (by omega) i) := by
        ext; simp
      rw [this, Fin.snoc_castSucc]
    · have : j = k + 1 := by omega
      subst this
      rfl

theorem coreReqAt_specToCoreV2 {U : Type} {P2 : F2e2e.Alg2Params} (P : AdaParams) {c : ℕ}
    (ctrl2 : F2e2e.VController U) (s2 : Fin P2.N → U) (ω : Fin c → Bool) {T : ℕ}
    {o : List CoreOut} (holen : o.length = T)
    (hresp : ∀ i : Fin T, F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω T i =
      outRespV2 (o.getD i (Sum.inl AdaCert.abort)))
    {j : ℕ} (hj : j ≤ T) :
    coreReqAt (specToCoreV2 P ctrl2) o j =
      quantReq P (F2e2e.vRequest (mech2 P2 c) ctrl2 s2 ω j) := by
  unfold coreReqAt specToCoreV2 F2e2e.vRequest
  congr 1
  symm
  refine v2ctrl_congr ctrl2 (by simp [List.length_take, holen, hj]) _ _ fun i => ?_
  rw [v2Responses_prefix (mech2 P2 c) ctrl2 s2 ω T j hj i, hresp]
  congr 1
  simp only [Fin.val_castLE, Fin.val_cast]
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take_of_lt i.isLt]

theorem vResponse_eq_outRespV2 {U : Type} {P2 : F2e2e.Alg2Params} {c : ℕ}
    (ctrl2 : F2e2e.VController U) (s2 : Fin P2.N → U) (ω : Fin c → Bool) {T : ℕ}
    {o : List CoreOut}
    (hresp : ∀ i : Fin T, F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω T i =
      outRespV2 (o.getD i (Sum.inl AdaCert.abort)))
    {j : ℕ} (hj : j < T) :
    F2e2e.vResponse (mech2 P2 c) ctrl2 s2 ω j = outRespV2 (coreOutAt o j) := by
  unfold F2e2e.vResponse coreOutAt
  rw [v2Responses_prefix (mech2 P2 c) ctrl2 s2 ω T (j + 1) hj (Fin.last j), hresp]
  rfl

theorem specToCoreV2_valid {U : Type} (P : AdaParams) (ctrl : F2e2e.VController U)
    (h : ctrl.Valid) : (specToCoreV2 P ctrl).Valid P := by
  intro hist
  refine ⟨fun x => valIdx_le P _, fun hI => ?_⟩
  have hlu := (h hist.length (fun i => outRespV2 (hist.getD i.val (Sum.inl AdaCert.abort)))).2 hI
  have hA0 : (0 : ℚ) ≤ P.hA := by unfold AdaParams.hA; positivity
  have hmono := endIdx_mono P hlu
  show P.hA * (endIdx P _ : ℚ) ≤ P.hA * (endIdx P _ : ℚ)
  exact mul_le_mul_of_nonneg_left (by exact_mod_cast hmono) hA0

/-- A covered incorrect response of the Spec's mechanism within the horizon of the online run is a
covered incorrect core output (at `a_req − h_A`). -/
theorem v2Fails_imp_coreFails {U : Type} [Fintype U] (P2 : F2e2e.Alg2Params) (P : AdaParams)
    (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) {aReq : ℝ} (ha1 : aReq < 1) (c : ℕ)
    (ctrl2 : F2e2e.VController U) (hvalid : ctrl2.Valid) (s2 : Fin P2.N → U)
    (ω : Fin c → Bool) {t T : ℕ} (htT : t < T)
    (hcov : F2e2e.VCovered (mech2 P2 c) ctrl2 P.M P.J P.R s2 ω t)
    (hinc : ¬ F2e2e.VCorrect D aReq (F2e2e.vRequest (mech2 P2 c) ctrl2 s2 ω t)
      (F2e2e.vResponse (mech2 P2 c) ctrl2 s2 ω t))
    {o : List CoreOut} (holen : o.length = T)
    (hresp : ∀ i : Fin T, F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω T i =
      outRespV2 (o.getD i (Sum.inl AdaCert.abort))) :
    coreFails P D (aReq - P.hA) (specToCoreV2 P ctrl2) o := by
  refine ⟨t, by rw [holen]; exact htT, ?_, fun hc => hinc ?_⟩
  · show covPred P.M P.J P.R t (fun j => (coreReqAt (specToCoreV2 P ctrl2) o j).isInterval)
      (fun j => coreIsReject (coreOutAt o j))
    have hcov' : covPred P.M P.J P.R t (fun j => (F2e2e.vRequest (mech2 P2 c) ctrl2 s2 ω j).2.1)
        (fun j => (F2e2e.vResponse (mech2 P2 c) ctrl2 s2 ω j).isReject) := hcov
    refine (covPred_congr (fun j hj => ?_) (fun j hj => ?_)).mp hcov'
    · rw [coreReqAt_specToCoreV2 P ctrl2 s2 ω holen hresp (by omega)]
      rfl
    · rw [vResponse_eq_outRespV2 ctrl2 s2 ω hresp (by omega), outRespV2_isReject]
  · rw [coreReqAt_specToCoreV2 P ctrl2 s2 ω holen hresp htT.le] at hc
    rw [vResponse_eq_outRespV2 ctrl2 s2 ω hresp htT, outRespV2_eq, vCorrectV2_iff]
    exact vCorrect_of_coreCorrect P D hD0 hD1 ha1 (F2e2e.vRequest (mech2 P2 c) ctrl2 s2 ω t)
      (hvalid t (F2e2e.vResponses (mech2 P2 c) ctrl2 s2 ω t)).1 _ hc

/-! ## The deterministic-controller guarantee -/

theorem exists_horizon' {α : Type} [Fintype α] (E : α → ℕ → Prop) :
    ∃ T : ℕ, ∀ a, (∃ t, E a t) → ∃ t < T, E a t := by
  classical
  let w : α → ℕ := fun a => if h : ∃ t, E a t then h.choose else 0
  refine ⟨Finset.univ.sup w + 1, fun a hf => ⟨hf.choose, ?_, hf.choose_spec⟩⟩
  have hle : w a ≤ Finset.univ.sup w := Finset.le_sup (Finset.mem_univ a)
  have hw : w a = hf.choose := dif_pos hf
  omega

theorem sum_castSample {U : Type} [Fintype U] {N2 N : ℕ} (hN : N2 = N) (D : U → ℝ)
    (F : (Fin N → U) → ENNReal) :
    ∑ s2 : Fin N2 → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) * F (castSample hN s2) =
      ∑ s : Fin N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) * F s := by
  subst hN
  rfl

open Classical in
/-- The failure mass of a deterministic controller for the union event of
`F2e2e.VGuaranteeWithInternalCaps`: `∑_s D^N(s) · #{ω | VFails ∨ VInternalFails}`. -/
noncomputable def v2DetFailMass {U : Type} [Fintype U] {N c : ℕ} (mech : F2e2e.VMechanism N c)
    (aborted : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → Bool)
    (peak : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → ℕ → ℕ)
    (D : U → ℝ) (M J R : ℕ) (aReq : ℝ) (ctrl : F2e2e.VController U) : ENNReal :=
  ∑ s : Fin N → U, ∑ ω : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
    (if F2e2e.VFails mech D M J R aReq ctrl s ω ∨
        F2e2e.VInternalFails mech aborted peak ctrl M J R aReq s ω then 1 else 0)

/-- **The union event of the Spec's Algorithm 2 from the core-level guarantee with internal caps**,
for a general corresponding pair of parameter records. -/
theorem v2DetFailMass_le {U : Type} [Fintype U] {P2 : F2e2e.Alg2Params} {P : AdaParams}
    (hP : ParCorr P2 P) (hN : P2.N = P.N) {aReq : ℝ} (ha1 : aReq < 1)
    (hvp : F2e2e.valP (F2e2e.dyadicDown aReq) = P.p)
    (hvt : ∀ j < P.p, F2e2e.valTmax (F2e2e.dyadicDown aReq) j = P.Tmax.getD j 0)
    (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl2 : F2e2e.VController U)
    (hvalid : ctrl2.Valid) (B : ENNReal)
    (hcore : ∀ T : ℕ, ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure
          {r | coreFails P D (aReq - (P.hA : ℝ)) (specToCoreV2 P ctrl2) r.1 ∨
            internalFails P r.2} ≤ B) :
    v2DetFailMass (mech2 P2 (adaCoins P))
      (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
      (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) D P.M P.J P.R aReq ctrl2 ≤
      B * 2 ^ adaCoins P := by
  classical
  -- the per-round bad event of the union
  let E : (Fin P2.N → U) × (Fin (adaCoins P) → Bool) → ℕ → Prop := fun p t =>
    F2e2e.VCovered (mech2 P2 (adaCoins P)) ctrl2 P.M P.J P.R p.1 p.2 t ∧
      (¬ F2e2e.VCorrect D aReq (F2e2e.vRequest (mech2 P2 (adaCoins P)) ctrl2 p.1 p.2 t)
          (F2e2e.vResponse (mech2 P2 (adaCoins P)) ctrl2 p.1 p.2 t) ∨
        ((F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 (adaCoins P)) ctrl2 p.1 p.2 t)
            p.2).aborted = true ∨
          ∃ j : Fin (F2e2e.valP (F2e2e.dyadicDown aReq)),
            F2e2e.valTmax (F2e2e.dyadicDown aReq) j.val ≤
              (F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 (adaCoins P)) ctrl2 p.1 p.2 t)
                p.2).corrections j.val))
  obtain ⟨T, hT⟩ := exists_horizon' E
  set Ebad : Set (List CoreOut × AdaState) :=
    {r | coreFails P D (aReq - (P.hA : ℝ)) (specToCoreV2 P ctrl2) r.1 ∨ internalFails P r.2}
    with hEbad
  have hpt : ∀ (s2 : Fin P2.N → U) (ω : Fin (adaCoins P) → Bool),
      (if F2e2e.VFails (mech2 P2 (adaCoins P)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
          F2e2e.VInternalFails (mech2 P2 (adaCoins P))
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R aReq
            s2 ω then (1 : ENNReal) else 0) ≤
        ((coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).run (List.ofFn ω)).elim 0
          (fun r => Ebad.indicator 1 r.1) := by
    intro s2 ω
    split_ifs with hf
    · have hex : ∃ t, E (s2, ω) t := by
        rcases hf with ⟨t, hcov, hinc⟩ | ⟨t, hcov, hint⟩
        · exact ⟨t, hcov, Or.inl hinc⟩
        · exact ⟨t, hcov, Or.inr hint⟩
      obtain ⟨t, htT, hcov, hbad⟩ := hT (s2, ω) hex
      obtain ⟨o, st, rest, hrun, holen, hresp, -⟩ := v2_online hP hN le_rfl ctrl2 hvalid s2 ω T
      rw [hrun]
      have hmem : (o, st) ∈ Ebad := by
        rcases hbad with hinc | hint
        · exact Or.inl (v2Fails_imp_coreFails P2 P D hD0 hD1 ha1 _ ctrl2 hvalid s2 ω htT hcov hinc
            holen hresp)
        · right
          obtain ⟨o1, st1, rest1, hrun1, -, -, hstate⟩ :=
            v2_online hP hN le_rfl ctrl2 hvalid s2 ω (t + 1)
          obtain ⟨hab, hcor⟩ := hstate t rfl
          have hf1 : internalFails P st1 := by
            rcases hint with ha | ⟨j, hj⟩
            · left; rw [← hab]; exact ha
            · right
              have hjp : j.val < P.p := by rw [← hvp]; exact j.isLt
              refine ⟨j.val, hjp, ?_⟩
              rw [← hvt j.val hjp, ← hcor]; exact hj
          obtain ⟨b, hb⟩ : ∃ b, T = t + 1 + b := ⟨T - (t + 1), by omega⟩
          rw [hb] at hrun
          exact coreRunS_internalFails_mono P _ _ (t + 1) b _ hrun1 hrun hf1
      simp [Set.indicator_of_mem hmem]
    · exact zero_le
  have hsum : ∀ s2 : Fin P2.N → U, ∑ ω : Fin (adaCoins P) → Bool,
      (if F2e2e.VFails (mech2 P2 (adaCoins P)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
          F2e2e.VInternalFails (mech2 P2 (adaCoins P))
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R aReq
            s2 ω then (1 : ENNReal) else 0) ≤
        2 ^ adaCoins P *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad := by
    intro s2
    refine (Finset.sum_le_sum fun ω _ => hpt s2 ω).trans (le_of_eq ?_)
    rw [BitProg.sum_tapes_eq _ (coreRunS_depth_le P _ _ T) (Ebad.indicator 1),
      PMF.toOuterMeasure_apply]
    congr 1
    refine tsum_congr fun r => ?_
    by_cases hr : r ∈ Ebad
    · simp [Set.indicator_of_mem hr]
    · simp [Set.indicator_of_notMem hr]
  calc v2DetFailMass (mech2 P2 (adaCoins P))
        (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
        (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) D P.M P.J P.R aReq ctrl2
      = ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) * ∑ ω : Fin (adaCoins P) → Bool,
          (if F2e2e.VFails (mech2 P2 (adaCoins P)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
            F2e2e.VInternalFails (mech2 P2 (adaCoins P))
              (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
              (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R
              aReq s2 ω then (1 : ENNReal) else 0) := by
        unfold v2DetFailMass
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [Finset.mul_sum]
    _ ≤ ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) * (2 ^ adaCoins P *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad) :=
        Finset.sum_le_sum fun s2 _ => mul_le_mul' le_rfl (hsum s2)
    _ = 2 ^ adaCoins P * ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun s _ => ?_
        ring
    _ = 2 ^ adaCoins P * ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure Ebad := by
        rw [sum_castSample hN D
          (fun s => (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure Ebad)]
    _ ≤ 2 ^ adaCoins P * B := mul_le_mul' le_rfl (hcore T)
    _ = B * 2 ^ adaCoins P := mul_comm _ _

/-- **The Spec's Algorithm 2, deterministic controllers**: the union event (some covered response
incorrect, or an internal failure during a covered request) has probability at most `ξ_req`. -/
theorem alg2V2_det (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl2 : F2e2e.VController U)
    (hvalid : ctrl2.Valid) :
    v2DetFailMass (F2e2e.alg2Mech M J R aReq ξReq (adaCoins (adaAlg2Params M J R aReq ξReq)))
      (F2e2e.alg2Aborted M J R aReq ξReq (adaCoins (adaAlg2Params M J R aReq ξReq)))
      (F2e2e.alg2PeakCorrections M J R aReq ξReq (adaCoins (adaAlg2Params M J R aReq ξReq)))
      D M J R aReq ctrl2 ≤ ENNReal.ofReal ξReq * 2 ^ adaCoins (adaAlg2Params M J R aReq ξReq) :=
  v2DetFailMass_le (parCorr_alg2 M J R ha0 ha1 hξ0 hξ1) (v2par_N M J R ha0 ha1 hξ0 hξ1)
    (by linarith) (v2par_valP M J R aReq ξReq) (fun j hj => v2par_valTmax M J R aReq ξReq j hj)
    D hD0 hD1 ctrl2 hvalid _
    (fun T => accuracy_core_guarantee_detS M J R ha0 ha1 hξ0 hξ1 U D hD0 hD1 _
      (specToCoreV2_valid _ ctrl2 hvalid) T)

/-! ## Randomized controllers -/

/-- Deterministic ⇒ randomized controllers for `VGuaranteeWithInternalCaps`, given measurability of
the union event in the controller's coins. -/
theorem vGuaranteeWithInternalCaps_of_det {N c : ℕ} (mech : F2e2e.VMechanism N c)
    (aborted : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → Bool)
    (peak : (t : ℕ) → (Fin (t + 1) → F2e2e.VView N) → (Fin c → Bool) → ℕ → ℕ)
    (M J R : ℕ) (aReq ξReq : ℝ)
    (hmeas : ∀ (U : Type) [Fintype U] (D : U → ℝ) (Ω : Type) [MeasurableSpace Ω]
      (ctrl : Ω → F2e2e.VController U), (∀ ω, (ctrl ω).Valid) →
      (∀ (t : ℕ) (h : Fin t → F2e2e.VResponse), Measurable fun ω => ctrl ω t h) →
      ∀ (s : Fin N → U) (ω' : Fin c → Bool),
        MeasurableSet {ω | F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
          F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω'})
    (h : ∀ (U : Type) [Fintype U] (D : U → ℝ), (∀ x, 0 ≤ D x) → ∑ x, D x = 1 →
      ∀ ctrl : F2e2e.VController U, ctrl.Valid →
        v2DetFailMass mech aborted peak D M J R aReq ctrl ≤ ENNReal.ofReal ξReq * 2 ^ c) :
    F2e2e.VGuaranteeWithInternalCaps M J R aReq ξReq mech aborted peak := by
  classical
  intro U _ D hD0 hD1 Ω _ P _ ctrl hvalid hctrl
  have hE := hmeas U D Ω ctrl hvalid hctrl
  have hpt : ∀ (s : Fin N → U) (ω' : Fin c → Bool),
      P {ω | F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
          F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω'} =
        ∫⁻ ω, (if F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
          F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω' then 1 else 0) ∂P := by
    intro s ω'
    rw [← lintegral_indicator_one (hE s ω')]
    congr 1
    funext ω
    rw [Set.indicator_apply]
    exact if_congr Iff.rfl rfl rfl
  calc ∑ s : Fin N → U, ∑ ω' : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        P {ω | F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
          F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω'}
      = ∑ s : Fin N → U, ∑ ω' : Fin c → Bool, ∫⁻ ω, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
            F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω' then 1 else 0) ∂P := by
        refine Finset.sum_congr rfl fun s _ => Finset.sum_congr rfl fun ω' _ => ?_
        rw [hpt, lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
    _ ≤ ∑ s : Fin N → U, ∫⁻ ω, ∑ ω' : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
            F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω' then 1 else 0) ∂P :=
        Finset.sum_le_sum fun s _ => sum_lintegral_le_lintegral_sum P _ _
    _ ≤ ∫⁻ ω, ∑ s : Fin N → U, ∑ ω' : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if F2e2e.VFails mech D M J R aReq (ctrl ω) s ω' ∨
            F2e2e.VInternalFails mech aborted peak (ctrl ω) M J R aReq s ω' then 1 else 0) ∂P :=
        sum_lintegral_le_lintegral_sum P _ _
    _ = ∫⁻ ω, v2DetFailMass mech aborted peak D M J R aReq (ctrl ω) ∂P := by
        congr 1
    _ ≤ ∫⁻ _ω, ENNReal.ofReal ξReq * 2 ^ c ∂P :=
        lintegral_mono fun ω => h U D hD0 hD1 (ctrl ω) (hvalid ω)
    _ = ENNReal.ofReal ξReq * 2 ^ c := by simp

/-- **Measurability of the union event for the Spec's Algorithm 2** in the controller's coins:
`alg2Exec` reads the views only through their rounded data (`measurableSet_alg2Exec`), so its
responses, abort flags and correction counts are measurable in the views, and the generic
`measurableSet_vFails`, `measurableSet_vInternalFails2` apply. -/
theorem alg2V2_meas (M J R : ℕ) (aReq ξReq : ℝ) (c : ℕ) (U : Type) [Fintype U] (D : U → ℝ)
    (Ω : Type) [MeasurableSpace Ω] (ctrl : Ω → F2e2e.VController U)
    (hctrl : ∀ (t : ℕ) (h : Fin t → F2e2e.VResponse), Measurable fun ω => ctrl ω t h)
    (s : Fin (F2e2e.alg2Params M J R aReq ξReq).N → U) (ω' : Fin c → Bool) :
    MeasurableSet {ω | F2e2e.VFails (F2e2e.alg2Mech M J R aReq ξReq c) D M J R aReq
          (ctrl ω) s ω' ∨
        F2e2e.VInternalFails (F2e2e.alg2Mech M J R aReq ξReq c)
          (F2e2e.alg2Aborted M J R aReq ξReq c) (F2e2e.alg2PeakCorrections M J R aReq ξReq c)
          (ctrl ω) M J R aReq s ω'} := by
  have hmeas : ∀ (t : ℕ) (ω'' : Fin c → Bool) (r : F2e2e.VResponse),
      MeasurableSet {views : Fin (t + 1) → (Fin (F2e2e.alg2Params M J R aReq ξReq).N → ℝ) ×
        Bool × ℝ × ℝ | F2e2e.alg2Mech M J R aReq ξReq c t views ω'' = r} :=
    fun t ω'' r => measurableSet_alg2Exec _ t ω'' (fun o => o.response = r)
  have hA : ∀ (t : ℕ) (ω'' : Fin c → Bool),
      MeasurableSet {views : Fin (t + 1) → (Fin (F2e2e.alg2Params M J R aReq ξReq).N → ℝ) ×
        Bool × ℝ × ℝ | F2e2e.alg2Aborted M J R aReq ξReq c t views ω'' = true} :=
    fun t ω'' => measurableSet_alg2Exec _ t ω'' (fun o => o.aborted = true)
  have hPk : ∀ (t : ℕ) (ω'' : Fin c → Bool) (j n : ℕ),
      MeasurableSet {views : Fin (t + 1) → (Fin (F2e2e.alg2Params M J R aReq ξReq).N → ℝ) ×
        Bool × ℝ × ℝ | n ≤ F2e2e.alg2PeakCorrections M J R aReq ξReq c t views ω'' j} :=
    fun t ω'' j n => measurableSet_alg2Exec _ t ω'' (fun o => n ≤ o.corrections j)
  exact (measurableSet_vFails _ ctrl hctrl D M J R aReq hmeas s ω').union
    (measurableSet_vInternalFails2 _ ctrl hctrl hmeas _ _ M J R aReq hA hPk s ω')

/-- **Main Theorem (B), the guarantee conjunct** (`F2e2e.Theorem_B_statistical`, third conjunct):
Algorithm 2 with `c = adaCoins (adaAlg2Params …)` fair bits satisfies `VGuaranteeWithInternalCaps`. -/
theorem alg2V2_guarantee (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ∃ c : ℕ, F2e2e.VGuaranteeWithInternalCaps M J R aReq ξReq
      (F2e2e.alg2Mech M J R aReq ξReq c) (F2e2e.alg2Aborted M J R aReq ξReq c)
      (F2e2e.alg2PeakCorrections M J R aReq ξReq c) :=
  ⟨adaCoins (adaAlg2Params M J R aReq ξReq),
    vGuaranteeWithInternalCaps_of_det _ _ _ M J R aReq ξReq
      (fun U _ D Ω _ ctrl _ hctrl s ω' => alg2V2_meas M J R aReq ξReq _ U D Ω ctrl hctrl s ω')
      (fun _U _ D hD0 hD1 ctrl hvalid => alg2V2_det M J R ha0 ha1 hξ0 hξ1 D hD0 hD1 ctrl hvalid)⟩

end F2e2e.B.V2
