import F2e2e.B.ArchCount

/-!
# Algorithm 2 of the Spec and the core (B-ARCH), part 5a: the internal counters only grow

`CAP_ABORT` (`capAborted`) is sticky and the correction counts `T_j` never decrease along the online
execution (`coreLoopSD_mono`), so an internal failure at the end of some round persists to the end of
the execution (`internalFails_of_mono`). Spec-independent.
-/

namespace F2e2e.B

open F2e2e.Discrete

/-- The internal counters only grow from `st` to `st'`. -/
def StMono (st st' : AdaState) : Prop :=
  (st.capAborted = true → st'.capAborted = true) ∧ ∀ j, st.T.getD j 0 ≤ st'.T.getD j 0

theorem StMono.refl (st : AdaState) : StMono st st := ⟨id, fun _ => le_rfl⟩

theorem StMono.trans {a b c : AdaState} (h1 : StMono a b) (h2 : StMono b c) : StMono a c :=
  ⟨fun h => h2.1 (h1.1 h), fun j => (h1.2 j).trans (h2.2 j)⟩

theorem internalFails_of_mono {P : AdaParams} {st st' : AdaState} (h : internalFails P st)
    (hm : StMono st st') : internalFails P st' := by
  rcases h with h | ⟨j, hj, hT⟩
  · exact Or.inl (hm.1 h)
  · exact Or.inr ⟨j, hj, hT.trans (hm.2 j)⟩

theorem getD_set_succ_ge (l : List ℕ) (i j : ℕ) :
    l.getD j 0 ≤ (l.set i (l.getD i 0 + 1)).getD j 0 := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_set]
  by_cases hij : i = j
  · subst hij
    rw [if_pos rfl]
    by_cases hi : i < l.length
    · rw [if_pos hi, List.getElem?_eq_getElem hi]
      simp [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hi]
    · rw [if_neg hi, List.getElem?_eq_none (by omega)]
  · rw [if_neg hij]

theorem applyCorrection_mono (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ)
    (q : Bool) : AllOut (applyCorrection P st vals j q) fun st' => StMono st st' := by
  unfold applyCorrection
  exact (allOut_true _).bind fun _ _ => allOut_ret ⟨id, fun j' => getD_set_succ_ge st.T j j'⟩

theorem scanPass_mono (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool),
      AllOut (scanPass P vals mus es st cache) fun r => StMono st r.2.1
  | [], st, _ => allOut_ret (StMono.refl st)
  | j :: es, st, cache => by
    unfold scanPass
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]; exact scanPass_mono P vals mus es st cache
    · rw [if_neg hc]
      refine (allOut_true _).bind fun r _ => ?_
      rcases r with _ | q
      · exact scanPass_mono P vals mus es st _
      · dsimp only
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hT]; exact allOut_ret (StMono.refl st)
        · rw [if_neg hT]
          exact (applyCorrection_mono P st vals j q).bind fun st' h' => allOut_ret h'

theorem prepareRoot_mono (P : AdaParams) (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool),
      AllOut (prepareRoot P vals fuel st cache) fun o => ∀ st2, o = some st2 → StMono st st2
  | 0, _, _ => allOut_ret fun _ h => by cases h
  | fuel + 1, st, cache => by
    unfold prepareRoot
    refine (scanPass_mono P vals (adaMus P st vals) (List.range P.p) st cache).bind
      fun r hr => ?_
    rcases r with ⟨o, st', cache'⟩
    cases o
    · exact allOut_ret fun st2 h => by cases h; exact hr
    · exact (prepareRoot_mono P vals fuel st' cache').mono fun o ho st2 h2 => hr.trans (ho st2 h2)
    · exact allOut_ret fun _ h => by cases h

theorem outerReject_mono (P : AdaParams) (st : AdaState) (high : Bool) :
    AllOut (outerReject P st high) fun r => StMono st r.2 := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]; exact allOut_ret ⟨id, fun _ => le_rfl⟩
  · rw [if_neg hJ]; exact (allOut_true _).bind fun _ _ => allOut_ret ⟨id, fun _ => le_rfl⟩

theorem adaIntervalD_mono (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    AllOut (adaIntervalD P st vals l u) fun r => StMono st r.2 := by
  unfold adaIntervalD
  split_ifs
  · exact allOut_ret (StMono.refl st)
  · refine (prepareRoot_mono P vals P.fuel _ _).bind fun r hr => ?_
    rcases r with _ | st2
    · exact allOut_ret ⟨fun _ => rfl, fun _ => le_rfl⟩
    · have hm : StMono st st2 := hr st2 rfl
      dsimp only
      refine (allOut_true _).bind fun _ _ => (allOut_true _).bind fun _ _ => ?_
      split_ifs
      · exact (outerReject_mono P st2 true).mono fun _ hr' => hm.trans hr'
      · exact (outerReject_mono P st2 false).mono fun _ hr' => hm.trans hr'
      · exact allOut_ret hm

theorem adaNumericalD_mono (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    AllOut (adaNumericalD P st vals) fun r => StMono st r.2 := by
  unfold adaNumericalD
  split_ifs
  · exact allOut_ret (StMono.refl st)
  · refine (prepareRoot_mono P vals P.fuel _ _).bind fun r hr => ?_
    rcases r with _ | st2
    · exact allOut_ret ⟨fun _ => rfl, fun _ => le_rfl⟩
    · have hm : StMono st st2 := hr st2 rfl
      dsimp only
      exact (allOut_true _).bind fun _ _ => allOut_ret hm

theorem coreStepD_mono {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U)
    (st : AdaState) : AllOut (coreStepD P s req st) fun r => StMono st r.2 := by
  unfold coreStepD
  split_ifs
  · exact (adaIntervalD_mono P st _ _ _).bind fun _ hr => allOut_ret hr
  · exact (adaNumericalD_mono P st _).bind fun _ hr => allOut_ret hr

theorem coreLoopSD_mono {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (n : ℕ) (st : AdaState) (hist : List CoreOut),
      AllOut (coreLoopSD P ctrl s n st hist) fun r => StMono st r.2
  | 0, st, _ => allOut_ret (StMono.refl st)
  | n + 1, st, hist => (coreStepD_mono P s (ctrl hist) st).bind fun r hr =>
      (coreLoopSD_mono P ctrl s n r.2 (hist ++ [r.1])).mono fun _ hr' => hr.trans hr'

theorem coreLoopSD_add {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U) :
    ∀ (a b : ℕ) (st : AdaState) (hist : List CoreOut),
      coreLoopSD P ctrl s (a + b) st hist =
        (coreLoopSD P ctrl s a st hist).bind fun r => coreLoopSD P ctrl s b r.2 r.1
  | 0, b, st, hist => by rw [Nat.zero_add]; rfl
  | a + 1, b, st, hist => by
    rw [show a + 1 + b = (a + b) + 1 by omega]
    show (coreStepD P s (ctrl hist) st).bind (fun r => coreLoopSD P ctrl s (a + b) r.2 (hist ++ [r.1])) =
      ((coreStepD P s (ctrl hist) st).bind fun r => coreLoopSD P ctrl s a r.2 (hist ++ [r.1])).bind
        fun r => coreLoopSD P ctrl s b r.2 r.1
    rw [DrawProg.bind_assoc]
    congr 1
    funext r
    exact coreLoopSD_add P ctrl s a b r.2 (hist ++ [r.1])

/-- Every output of a noise-draw program on a successful bit run satisfies its `AllOut` property. -/
theorem allOut_run {α : Type} {prog : NoiseProg α} {Q : α → Prop} (h : AllOut prog Q)
    {s : NoiseKind → BitProg ℤ} {τ : List Bool} {x : α} {rest : List Bool}
    (hr : (prog.toBits s).run τ = some (x, rest)) : Q x := by
  induction prog generalizing τ with
  | ret a =>
    simp only [DrawProg.toBits_ret, BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hr
    rw [← hr.1]; exact h
  | draw κ k ih =>
    rw [DrawProg.toBits_draw, BitProg.run_bind, Option.bind_eq_some_iff] at hr
    obtain ⟨⟨b, τ1⟩, -, h2⟩ := hr
    exact ih b (h b) h2

/-- **Internal failures persist**: if the online run for `a` rounds ends in a state with an internal
failure, so does the run for `a + b` rounds (on the same tape). -/
theorem coreRunS_internalFails_mono {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (s : Fin P.N → U)
    (a b : ℕ) (τ : List Bool) {o1 o2 : List CoreOut} {st1 st2 : AdaState} {r1 r2 : List Bool}
    (h1 : (coreRunS P ctrl s a).run τ = some ((o1, st1), r1))
    (h2 : (coreRunS P ctrl s (a + b)).run τ = some ((o2, st2), r2)) (hf : internalFails P st1) :
    internalFails P st2 := by
  unfold coreRunS coreRunSD at h1 h2
  rw [DrawProg.toBits_bind, BitProg.run_bind] at h1 h2
  cases hinit : ((adaInitD P).toBits (adaDraw P)).run τ with
  | none => rw [hinit] at h1; cases h1
  | some r0 =>
    rw [hinit, Option.bind_some] at h1 h2
    rw [coreLoopSD_add, DrawProg.toBits_bind, BitProg.run_bind, h1, Option.bind_some] at h2
    exact internalFails_of_mono hf (allOut_run (coreLoopSD_mono P ctrl s b st1 o1) h2)

end F2e2e.B
