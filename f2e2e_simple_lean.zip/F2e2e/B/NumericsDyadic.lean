import F2e2e.Spec

/-!
# Part II numerics (B-NUM), part 1: the dyadic rounding `dyadicExp` / `dyadicDown`

Definition `R:def:sec3_ada_params`, eq. `R:eq:sec3_dyadic_inputs` (`parts/partII.tex` L668–671):
`a := 2^{-⌈log₂(1/a_req)⌉}`, `ξ_A := 2^{-⌈log₂(1/ξ_req)⌉}`; "Thus `a > a_req/2` and `ξ_A > ξ_req/2`".
In the Spec these are `dyadicDown aReq` and `dyadicDown ξReq`, where
`dyadicExp x = Nat.clog 2 ⌈x⁻¹⌉₊` and `dyadicDown x = (1/2)^{dyadicExp x}`.

Main results (namespace `F2e2e.B`):
* `inv_le_two_pow_dyadicExp`, `two_pow_pred_dyadicExp_lt`: `x⁻¹ ≤ 2^k` and (for `0 < x < 1`)
  `2^{k-1} < x⁻¹`, where `k = dyadicExp x`;
* `dyadicDown_le`, `half_lt_dyadicDown`: `dyadicDown x ∈ (x/2, x]` for `0 < x < 1`;
* `dyadicExp_eq_ceil_logb`, `dyadicDown_eq_zpow`: the paper's form `2^{-⌈log₂(1/x)⌉}`;
* `four_le_dyadicExp`, `dyadicDown_le_sixteenth`: `x < 1/8 ⇒ dyadicExp x ≥ 4`, `dyadicDown x ≤ 1/16`;
* `dyadicExp_dyadicDown`, `inv_dyadicDown`: `dyadicDown x` is exactly `2^{-k}`.
-/

namespace F2e2e.B

/-- `dyadicDown x = (2^{dyadicExp x})⁻¹`. -/
theorem dyadicDown_eq (x : ℝ) : dyadicDown x = ((2 : ℝ) ^ dyadicExp x)⁻¹ := by
  unfold dyadicDown
  rw [one_div, inv_pow]

theorem dyadicDown_pos (x : ℝ) : 0 < dyadicDown x := by
  unfold dyadicDown
  positivity

/-- `(dyadicDown x)⁻¹ = 2^{dyadicExp x}`. -/
theorem inv_dyadicDown (x : ℝ) : (dyadicDown x)⁻¹ = (2 : ℝ) ^ dyadicExp x := by
  rw [dyadicDown_eq, inv_inv]

theorem one_div_dyadicDown (x : ℝ) : 1 / dyadicDown x = (2 : ℝ) ^ dyadicExp x := by
  rw [one_div, inv_dyadicDown]

theorem dyadicDown_le_one (x : ℝ) : dyadicDown x ≤ 1 := by
  unfold dyadicDown
  exact pow_le_one₀ (by norm_num) (by norm_num)

/-- `x⁻¹ ≤ 2^{⌈log₂ x⁻¹⌉}` (copied from cut2 `ImplAux.inv_le_two_pow_dyadicExp`). -/
theorem inv_le_two_pow_dyadicExp (x : ℝ) : x⁻¹ ≤ (2 : ℝ) ^ dyadicExp x := by
  have h1 : x⁻¹ ≤ (⌈x⁻¹⌉₊ : ℝ) := Nat.le_ceil _
  have h2 : ⌈x⁻¹⌉₊ ≤ 2 ^ dyadicExp x := Nat.le_pow_clog (by norm_num) _
  have h3 : (⌈x⁻¹⌉₊ : ℝ) ≤ (2 : ℝ) ^ dyadicExp x := by exact_mod_cast h2
  linarith

/-- `dyadicDown x ≤ x` for `x > 0`. -/
theorem dyadicDown_le {x : ℝ} (hx : 0 < x) : dyadicDown x ≤ x := by
  rw [dyadicDown_eq]
  calc ((2 : ℝ) ^ dyadicExp x)⁻¹ ≤ (x⁻¹)⁻¹ :=
        inv_anti₀ (inv_pos.mpr hx) (inv_le_two_pow_dyadicExp x)
    _ = x := inv_inv x

theorem one_lt_ceil_inv {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) : 1 < ⌈x⁻¹⌉₊ := by
  have h4 : (1 : ℝ) < x⁻¹ := (one_lt_inv₀ hx0).mpr hx1
  exact Nat.lt_ceil.mpr (by exact_mod_cast h4)

theorem one_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) : 1 ≤ dyadicExp x :=
  Nat.clog_pos (by norm_num) (one_lt_ceil_inv hx0 hx1)

/-- Minimality of `⌈log₂ x⁻¹⌉`: `2^{k-1} < x⁻¹` for `0 < x < 1`. -/
theorem two_pow_pred_dyadicExp_lt {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    (2 : ℝ) ^ (dyadicExp x - 1) < x⁻¹ := by
  have h := Nat.pow_pred_clog_lt_self (by norm_num : 1 < 2) (one_lt_ceil_inv hx0 hx1)
  have h' : 2 ^ (dyadicExp x - 1) < ⌈x⁻¹⌉₊ := by
    simpa [dyadicExp, Nat.pred_eq_sub_one] using h
  have h'' : ((2 ^ (dyadicExp x - 1) : ℕ) : ℝ) < x⁻¹ := Nat.lt_ceil.mp h'
  exact_mod_cast h''

/-- `2^k < 2 x⁻¹` for `0 < x < 1`, where `k = dyadicExp x`. -/
theorem two_pow_dyadicExp_lt {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    (2 : ℝ) ^ dyadicExp x < 2 * x⁻¹ := by
  have hk := one_le_dyadicExp hx0 hx1
  have h := two_pow_pred_dyadicExp_lt hx0 hx1
  have hpow : (2 : ℝ) ^ dyadicExp x = 2 * 2 ^ (dyadicExp x - 1) := by
    rw [← pow_succ']
    congr 1
    omega
  rw [hpow]
  linarith

/-- `x/2 < dyadicDown x` for `0 < x < 1` (the paper's "`a > a_req/2`"). -/
theorem half_lt_dyadicDown {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) : x / 2 < dyadicDown x := by
  have h := two_pow_dyadicExp_lt hx0 hx1
  have hpos : (0 : ℝ) < 2 ^ dyadicExp x := by positivity
  rw [dyadicDown_eq, lt_inv_comm₀ (by positivity) hpos, inv_div]
  calc (2 : ℝ) ^ dyadicExp x < 2 * x⁻¹ := h
    _ = 2 / x := by rw [div_eq_mul_inv]

/-- `dyadicDown x ∈ (x/2, x]` for `0 < x < 1`. -/
theorem dyadicDown_mem_Ioc {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    dyadicDown x ∈ Set.Ioc (x / 2) x :=
  ⟨half_lt_dyadicDown hx0 hx1, dyadicDown_le hx0⟩

/-- `1/dyadicDown x < 2/x` for `0 < x < 1`. -/
theorem one_div_dyadicDown_lt {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    1 / dyadicDown x < 2 / x := by
  rw [one_div_dyadicDown, div_eq_mul_inv]
  exact two_pow_dyadicExp_lt hx0 hx1

theorem one_div_le_one_div_dyadicDown {x : ℝ} (hx0 : 0 < x) : 1 / x ≤ 1 / dyadicDown x :=
  one_div_le_one_div_of_le (dyadicDown_pos x) (dyadicDown_le hx0)

/-- `dyadicExp x = ⌈log₂ x⁻¹⌉₊` for `x > 0`. -/
theorem dyadicExp_eq_ceil_logb {x : ℝ} (hx0 : 0 < x) :
    dyadicExp x = ⌈Real.logb 2 x⁻¹⌉₊ := by
  apply le_antisymm
  · -- `k ≤ ⌈log₂ x⁻¹⌉₊`
    rcases Nat.eq_zero_or_pos (dyadicExp x) with hk | hk
    · rw [hk]
      exact Nat.zero_le _
    · have hx1 : x < 1 := by
        by_contra hcon
        have hle : x⁻¹ ≤ 1 := inv_le_one_of_one_le₀ (not_lt.mp hcon)
        have hc : ⌈x⁻¹⌉₊ ≤ 1 := Nat.ceil_le.mpr (by exact_mod_cast hle)
        have : dyadicExp x = 0 := Nat.clog_of_right_le_one hc 2
        omega
      have h := two_pow_pred_dyadicExp_lt hx0 hx1
      have hlog : ((dyadicExp x - 1 : ℕ) : ℝ) < Real.logb 2 x⁻¹ := by
        rw [Real.lt_logb_iff_rpow_lt (by norm_num) (inv_pos.mpr hx0), Real.rpow_natCast]
        exact h
      have := Nat.lt_ceil.mpr hlog
      omega
  · -- `⌈log₂ x⁻¹⌉₊ ≤ k`
    apply Nat.ceil_le.mpr
    rw [Real.logb_le_iff_le_rpow (by norm_num) (inv_pos.mpr hx0), Real.rpow_natCast]
    exact inv_le_two_pow_dyadicExp x

/-- The paper's form `dyadicDown x = 2^{-⌈log₂(1/x)⌉}` (eq. `R:eq:sec3_dyadic_inputs`) for `0 < x ≤ 1`. -/
theorem dyadicDown_eq_zpow {x : ℝ} (hx0 : 0 < x) (hx1 : x ≤ 1) :
    dyadicDown x = (2 : ℝ) ^ (-⌈Real.logb 2 (1 / x)⌉) := by
  have hnn : 0 ≤ Real.logb 2 (1 / x) := by
    apply Real.logb_nonneg (by norm_num)
    rw [one_div]
    exact one_le_inv₀ hx0 |>.mpr hx1
  rw [← Int.natCast_ceil_eq_ceil hnn, one_div, ← dyadicExp_eq_ceil_logb hx0, dyadicDown_eq,
    zpow_neg, zpow_natCast]

/-- `x < 1/8 ⇒ ⌈log₂ x⁻¹⌉ ≥ 4`. -/
theorem four_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 8) : 4 ≤ dyadicExp x := by
  have h8 : (8 : ℝ) < x⁻¹ := by
    rw [lt_inv_comm₀ (by norm_num) hx0]
    norm_num
    linarith
  have hm : 8 < ⌈x⁻¹⌉₊ := Nat.lt_ceil.mpr (by exact_mod_cast h8)
  unfold dyadicExp
  by_contra hcon
  have h5 : Nat.clog 2 ⌈x⁻¹⌉₊ ≤ 3 := by omega
  rw [Nat.clog_le_iff_le_pow (by norm_num)] at h5
  omega

/-- `x < 1/2 ⇒ ⌈log₂ x⁻¹⌉ ≥ 2`. -/
theorem two_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 2) : 2 ≤ dyadicExp x := by
  have h2 : (2 : ℝ) < x⁻¹ := by
    rw [lt_inv_comm₀ (by norm_num) hx0]
    norm_num
    linarith
  have hm : 2 < ⌈x⁻¹⌉₊ := Nat.lt_ceil.mpr (by exact_mod_cast h2)
  unfold dyadicExp
  by_contra hcon
  have h5 : Nat.clog 2 ⌈x⁻¹⌉₊ ≤ 1 := by omega
  rw [Nat.clog_le_iff_le_pow (by norm_num)] at h5
  omega

/-- `x < 1/8 ⇒ dyadicDown x ≤ 1/16` (so for `a_req < 1/10` the dyadic accuracy is `≤ 1/16`). -/
theorem dyadicDown_le_sixteenth {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 8) :
    dyadicDown x ≤ 1 / 16 := by
  have hk := four_le_dyadicExp hx0 hx1
  unfold dyadicDown
  calc (1 / 2 : ℝ) ^ dyadicExp x ≤ (1 / 2) ^ 4 :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) hk
    _ = 1 / 16 := by norm_num

/-- `x < 1/2 ⇒ dyadicDown x ≤ 1/4`. -/
theorem dyadicDown_le_quarter {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 2) :
    dyadicDown x ≤ 1 / 4 := by
  have hk := two_le_dyadicExp hx0 hx1
  unfold dyadicDown
  calc (1 / 2 : ℝ) ^ dyadicExp x ≤ (1 / 2) ^ 2 :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) hk
    _ = 1 / 4 := by norm_num

/-- `dyadicDown` is idempotent on exponents: `dyadicExp (dyadicDown x) = dyadicExp x`. -/
theorem dyadicExp_dyadicDown (x : ℝ) : dyadicExp (dyadicDown x) = dyadicExp x := by
  unfold dyadicExp
  rw [inv_dyadicDown]
  have : ⌈(2 : ℝ) ^ dyadicExp x⌉₊ = 2 ^ dyadicExp x := by
    have h : ((2 ^ dyadicExp x : ℕ) : ℝ) = (2 : ℝ) ^ dyadicExp x := by push_cast; rfl
    rw [← h, Nat.ceil_natCast]
  rw [this, Nat.clog_pow 2 _ (by norm_num)]
  rfl

theorem dyadicDown_dyadicDown (x : ℝ) : dyadicDown (dyadicDown x) = dyadicDown x := by
  show (1 / 2 : ℝ) ^ dyadicExp (dyadicDown x) = dyadicDown x
  rw [dyadicExp_dyadicDown]
  rfl

/-- `(dyadicExp x - 1) · ln 2 < ln x⁻¹` for `0 < x < 1`. -/
theorem dyadicExp_sub_one_mul_log_two_lt {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    ((dyadicExp x : ℝ) - 1) * Real.log 2 < Real.log x⁻¹ := by
  have hk := one_le_dyadicExp hx0 hx1
  have h := two_pow_pred_dyadicExp_lt hx0 hx1
  have hlog := Real.log_lt_log (by positivity) h
  rw [Real.log_pow] at hlog
  have hcast : ((dyadicExp x - 1 : ℕ) : ℝ) = (dyadicExp x : ℝ) - 1 := by
    rw [Nat.cast_sub hk]
    simp
  rw [hcast] at hlog
  exact hlog

end F2e2e.B
