import F2e2e.B.PrivacyPhase

/-!
# Privacy (P3): concurrent composition of the streams reading one block (replicas and hybrids)

Paper: `parts/partII.tex` L1004–1024. "Give each stream its own conceptual copy of the selected block
… For one hybrid step, fix complete independent tapes and assigned datasets of the other streams. They
form an interactive analyst for the selected stream. … Chaining at most three hybrids gives
`R:eq:sec3_hybrid_chain`."

* The replicated run gives stream `s` the data `d s` (`inlineAll sp d E σ` with an arbitrary family
  `d`); the real run is the special case `d = fun _ => D`.
* `inlineAll_regroup`: running all streams = running the selected stream `m` against the skeleton
  `inlineOthers sp d m E σ` in which all other streams (with their own randomness, their data and
  states) are inlined — this skeleton is the "interactive analyst" of the hybrid step (no tapes are
  fixed: the other streams' fresh draws stay inside the skeleton).
* `block_indist`: hybrids `c_F` (copy `x'` on `F ⊆ T`, `x` elsewhere), one stream changed at a time
  (`stream_indist`), chained with `PIndist.trans`.
-/

namespace F2e2e.B.Priv

open F2e2e.Discrete ENNReal

section Regroup

variable {S I Dt P α γ : Type} [DecidableEq S]

/-- The step of a stream oracle only depends on the data through its gaps and centers. -/
theorem StreamSpec.step_congr (sp : StreamSpec I Dt P) {y y' : Dt}
    (hg : ∀ i, sp.gap i y = sp.gap i y') (hc : ∀ i, sp.center i y = sp.center i y')
    (σ : Option ℤ) (q : SQuery I) : sp.step y σ q = sp.step y' σ q := by
  cases q <;> cases σ <;> simp only [StreamSpec.step, hg, hc]

/-- The restricted oracle takes the same steps as the original one on the embedded data. -/
theorem StreamSpec.step_restrict {X : Type} (sp : StreamSpec I Dt P) (f : X → Dt) (x : X)
    (σ : Option ℤ) (q : SQuery I) : (sp.restrict f).step x σ q = sp.step (f x) σ q := by
  cases q <;> cases σ <;> rfl

/-- Running a program without calls, then a skeleton. -/
theorem inlineAll_ofDraw_bind {X : Type} (sp : S → StreamSpec I X P) (d : S → X)
    (D : DrawProg P ℤ γ) (f : γ → OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ) :
    inlineAll sp d ((OProg.ofDraw D).bind f) σ = D.bind fun r => inlineAll sp d (f r) σ := by
  induction D with
  | ret a => rfl
  | draw p k ih =>
    simp only [OProg.ofDraw, OProg.bind, inlineAll, DrawProg.bind_draw]
    congr 1; funext b; exact ih b

/-- Congruence: equal steps give equal runs. -/
theorem inlineAll_congr {X X' : Type} (sp : S → StreamSpec I X P) (sp' : S → StreamSpec I X' P)
    (d : S → X) (d' : S → X') (h : ∀ s σ q, (sp s).step (d s) σ q = (sp' s).step (d' s) σ q) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      inlineAll sp d E σ = inlineAll sp' d' E σ
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [inlineAll]; congr 1; funext y; exact inlineAll_congr sp sp' d d' h (k y) σ
  | .call s q k, σ => by
      simp only [inlineAll]; rw [h s (σ s) q]
      congr 1; funext r; exact inlineAll_congr sp sp' d d' h (k r.1) _

/-- Inline every stream except `m` (stream `s` reading `d s`, from the states `σ`); the calls to `m`
become calls to the single oracle of the result. -/
def inlineOthers {X : Type} (sp : S → StreamSpec I X P) (d : S → X) (m : S) :
    OProg S P ℤ (SQuery I) SResp α → (S → Option ℤ) → OProg Unit P ℤ (SQuery I) SResp α
  | .ret a, _ => .ret a
  | .draw p k, σ => .draw p fun y => inlineOthers sp d m (k y) σ
  | .call s q k, σ =>
      if s = m then .call () q fun r => inlineOthers sp d m (k r) σ
      else (OProg.ofDraw ((sp s).step (d s) (σ s) q)).bind fun r =>
        inlineOthers sp d m (k r.1) (Function.update σ s r.2)

/-- `inlineOthers` does not read the state of the selected stream. -/
theorem inlineOthers_update_self {X : Type} (sp : S → StreamSpec I X P) (d : S → X) (m : S)
    (v : Option ℤ) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      inlineOthers sp d m E (Function.update σ m v) = inlineOthers sp d m E σ
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [inlineOthers]; congr 1; funext y
      exact inlineOthers_update_self sp d m v (k y) σ
  | .call s q k, σ => by
      by_cases hs : s = m
      · simp only [inlineOthers, hs, if_true]
        congr 1; funext r; exact inlineOthers_update_self sp d m v (k r) σ
      · simp only [inlineOthers, hs, if_false, Function.update_of_ne hs]
        congr 1; funext r
        rw [Function.update_comm (Ne.symm hs)]
        exact inlineOthers_update_self sp d m v (k r.1) _

/-- `inlineOthers` only reads the data of the other streams. -/
theorem inlineOthers_congr {X : Type} (sp : S → StreamSpec I X P) (d d' : S → X) (m : S)
    (h : ∀ s, s ≠ m → d s = d' s) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      inlineOthers sp d m E σ = inlineOthers sp d' m E σ
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [inlineOthers]; congr 1; funext y; exact inlineOthers_congr sp d d' m h (k y) σ
  | .call s q k, σ => by
      by_cases hs : s = m
      · simp only [inlineOthers, hs, if_true]
        congr 1; funext r; exact inlineOthers_congr sp d d' m h (k r) σ
      · simp only [inlineOthers, hs, if_false, h s hs]
        congr 1; funext r; exact inlineOthers_congr sp d d' m h (k r.1) _

/-- **Regrouping**: running all streams is running the selected stream `m` against the skeleton in
which the other streams are inlined. -/
theorem inlineAll_regroup {X : Type} (sp : S → StreamSpec I X P) (d : S → X) (m : S) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ),
      inlineAll sp d E σ =
        inlineAll (fun _ : Unit => sp m) (fun _ => d m) (inlineOthers sp d m E σ) (fun _ => σ m)
  | .ret a, σ => rfl
  | .draw p k, σ => by
      simp only [inlineAll, inlineOthers]; congr 1; funext y; exact inlineAll_regroup sp d m (k y) σ
  | .call s q k, σ => by
      by_cases hs : s = m
      · subst hs
        simp only [inlineAll, inlineOthers, if_true]
        congr 1; funext r
        rw [inlineAll_regroup sp d s (k r.1) (Function.update σ s r.2),
          inlineOthers_update_self, Function.update_self,
          show Function.update (fun _ : Unit => σ s) () r.2 = fun _ => r.2 from
            funext fun u => by cases u; simp]
      · simp only [inlineAll, inlineOthers, hs, if_false]
        rw [inlineAll_ofDraw_bind]
        congr 1; funext r
        rw [inlineAll_regroup sp d m (k r.1) (Function.update σ s r.2),
          Function.update_of_ne (Ne.symm hs)]

/-- Phase starts of a program without calls followed by a skeleton. -/
theorem startsLE_ofDraw_bind {β' R' : Type} (D : DrawProg P ℤ γ)
    (f : γ → OProg Unit P ℤ (SQuery I) R' β') {n : ℕ} (h : ∀ r, (f r).StartsLE () n) :
    ((OProg.ofDraw D).bind f).StartsLE () n := by
  induction D with
  | ret a => exact h a
  | draw p k ih => exact fun b => ih b

/-- The counts of the selected stream survive the inlining of the other streams. -/
theorem startsLE_inlineOthers {X : Type} (sp : S → StreamSpec I X P) (d : S → X) (m : S) :
    ∀ (E : OProg S P ℤ (SQuery I) SResp α) (σ : S → Option ℤ) (n : ℕ), E.StartsLE m n →
      (inlineOthers sp d m E σ).StartsLE () n
  | .ret a, σ, n, _ => trivial
  | .draw p k, σ, n, hE => fun y => startsLE_inlineOthers sp d m (k y) σ n (hE y)
  | .call s q k, σ, n, hE => by
      by_cases hs : s = m
      · subst hs
        simp only [inlineOthers, if_true]
        by_cases hq : q.isStart = true
        · simp only [OProg.StartsLE, hq, and_self, if_true] at hE ⊢
          exact ⟨hE.1, fun r => startsLE_inlineOthers sp d s (k r) σ (n - 1) (hE.2 r)⟩
        · simp only [OProg.StartsLE, hq, Bool.false_eq_true, and_false, if_false] at hE ⊢
          exact fun r => startsLE_inlineOthers sp d s (k r) σ n (hE r)
      · simp only [inlineOthers, hs, if_false]
        simp only [OProg.StartsLE, hs, false_and, if_false] at hE
        exact startsLE_ofDraw_bind _ _ fun r =>
          startsLE_inlineOthers sp d m (k r.1) _ n (hE r.1)

end Regroup

/-! ## Hybrid chaining -/

/-- `n`-step hybrid chaining with equal steps: `(n ε, δ Σ_{i<n} e^{i ε})`. -/
theorem PIndist.chain_step {α : Type*} {p q r : PMF α} {ε δ : ℝ} (hδ : 0 ≤ δ) (n : ℕ)
    (h₁ : PIndist p q (n * ε) (δ * ∑ i ∈ Finset.range n, Real.exp (i * ε)))
    (h₂ : PIndist q r ε δ) :
    PIndist p r ((n + 1 : ℕ) * ε) (δ * ∑ i ∈ Finset.range (n + 1), Real.exp (i * ε)) := by
  have hS : 0 ≤ δ * ∑ i ∈ Finset.range n, Real.exp (i * ε) :=
    mul_nonneg hδ (Finset.sum_nonneg fun i _ => (Real.exp_pos _).le)
  refine (h₁.trans h₂ hS hδ).mono (le_of_eq ?_) (le_of_eq ?_)
  · push_cast; ring
  · rw [Finset.sum_range_succ]; ring

/-! ## Concurrent composition -/

section Block

variable {S I Dt X P α : Type} [DecidableEq S]

/-- **Concurrent composition** ((P3), `partII.tex` L1004–1024). The streams `s ∈ T` read the selected
block (`upd D y`: the data `D` with the selected block replaced by `y`); the other streams do not
(`hinv`). If every phase of every stream in `T` is `ρ`-DP (`PhaseDP`) and each makes at most `C` phase
starts on every path, then the ideal laws on `Adj`-related blocks `x, x'` are
`(|T| ε₁, e^{-χ} Σ_{i<|T|} e^{i ε₁})`-indistinguishable, `ε₁ = 2Cρ² + ρ√(2Cχ)`. (With `|T| ≤ 3` this is
the hybrid chain `R:eq:sec3_hybrid_chain`.) -/
theorem block_indist (L : P → PMF ℤ)
    (sp : S → StreamSpec I Dt P) (upd : Dt → X → Dt) {Adj : X → X → Prop} (T : Finset S) (D : Dt)
    (hinv : ∀ s ∉ T, ∀ i y y', (sp s).gap i (upd D y) = (sp s).gap i (upd D y') ∧
      (sp s).center i (upd D y) = (sp s).center i (upd D y'))
    {ρ : ℝ} (hρ : 0 ≤ ρ) (hsp : ∀ s ∈ T, ((sp s).restrict (upd D)).PhaseDP L Adj ρ)
    (E : OProg S P ℤ (SQuery I) SResp α) {C : ℕ} (hC : ∀ s ∈ T, E.StartsLE s C) {x x' : X}
    (hxx : Adj x x') (χ : ℝ) :
    PIndist (DrawProg.interp L (inlineAll sp (fun _ => upd D x) E (fun _ => none)))
      (DrawProg.interp L (inlineAll sp (fun _ => upd D x') E (fun _ => none)))
      (T.card * (2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ)))
      (Real.exp (-χ) * ∑ i ∈ Finset.range T.card,
        Real.exp (i * (2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ)))) := by
  classical
  set ε₁ := 2 * C * ρ ^ 2 + ρ * Real.sqrt (2 * C * χ) with hε₁
  have hε₁0 : 0 ≤ ε₁ := by positivity
  -- the hybrid laws: copy `x'` on `F`, `x` elsewhere
  let H : Finset S → PMF α := fun F => DrawProg.interp L
    (inlineAll sp (fun s => upd D (if s ∈ F then x' else x)) E (fun _ => none))
  -- one hybrid step
  have hstep : ∀ (F : Finset S) (a : S), a ∉ F → a ∈ T →
      PIndist (H F) (H (insert a F)) ε₁ (Real.exp (-χ)) := by
    intro F a haF haT
    have hsame : ∀ s, s ≠ a → upd D (if s ∈ F then x' else x) =
        upd D (if s ∈ insert a F then x' else x) := by
      intro s hs
      simp only [Finset.mem_insert, hs, false_or]
    have hrw : ∀ G : Finset S, DrawProg.interp L
        (inlineAll sp (fun s => upd D (if s ∈ G then x' else x)) E (fun _ => none)) =
        DrawProg.interp L (inlineAll (fun _ : Unit => (sp a).restrict (upd D))
          (fun _ => if a ∈ G then x' else x)
          (inlineOthers sp (fun s => upd D (if s ∈ G then x' else x)) a E (fun _ => none))
          (fun _ => none)) := by
      intro G
      rw [inlineAll_regroup sp _ a]
      congr 1
      exact inlineAll_congr _ _ _ _
        (fun _ σ q => (StreamSpec.step_restrict (sp a) (upd D) _ σ q).symm) _ _
    show PIndist (DrawProg.interp L _) (DrawProg.interp L _) ε₁ (Real.exp (-χ))
    rw [hrw F, hrw (insert a F), inlineOthers_congr sp _ _ a hsame E,
      if_neg haF, if_pos (Finset.mem_insert_self a F)]
    exact stream_indist L ((sp a).restrict (upd D)) hρ (hsp a haT) _
      (startsLE_inlineOthers sp _ a E _ C (hC a haT)) hxx χ
  -- chain over the subsets of `T`
  have hchain : ∀ F : Finset S, F ⊆ T →
      PIndist (H ∅) (H F) (F.card * ε₁)
        (Real.exp (-χ) * ∑ i ∈ Finset.range F.card, Real.exp (i * ε₁)) := by
    intro F
    induction F using Finset.induction_on with
    | empty =>
      intro _
      simp only [Finset.card_empty, Nat.cast_zero, zero_mul, Finset.range_zero, Finset.sum_empty,
        mul_zero]
      exact PIndist.refl _ le_rfl 0
    | insert a F haF ih =>
      intro hFT
      have haT : a ∈ T := hFT (Finset.mem_insert_self a F)
      have hFT' : F ⊆ T := fun s hs => hFT (Finset.mem_insert_of_mem hs)
      rw [Finset.card_insert_of_notMem haF]
      exact PIndist.chain_step (Real.exp_pos _).le F.card (ih hFT') (hstep F a haF haT)
  have h0 : H ∅ = DrawProg.interp L (inlineAll sp (fun _ => upd D x) E (fun _ => none)) := by
    simp only [H, Finset.notMem_empty, if_false]
  have hT : H T = DrawProg.interp L (inlineAll sp (fun _ => upd D x') E (fun _ => none)) := by
    simp only [H]
    congr 1
    refine inlineAll_congr _ _ _ _ (fun s σ q => ?_) _ _
    by_cases hs : s ∈ T
    · simp only [hs, if_true]
    · simp only [hs, if_false]
      exact StreamSpec.step_congr _ (fun i => (hinv s hs i x x').1)
        (fun i => (hinv s hs i x x').2) σ q
  rw [← h0, ← hT]
  exact hchain T subset_rfl

end Block

end F2e2e.B.Priv
