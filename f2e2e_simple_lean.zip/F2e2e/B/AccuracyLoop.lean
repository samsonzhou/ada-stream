import F2e2e.B.AccuracyCall

/-!
# Theorem `R:thm:validation_ada` (P5): the good-event analysis of the online execution

Paper: `parts/partII.tex` L1038–1046 (on the good event: no internal cap exhaustion, every interval response —
including a terminal rejection — and every numerical answer is correct; clipping of the endpoints is sound).

For the online execution with final state `coreRunSD` (`F2e2e/B/ArchOnline.lean`) of a deterministic valid
controller, along every path of good noise draws: for **every** admissible comparator family `u` that is
accurate on every candidate query of the execution (`CompOK`), no covered round has an incorrect output
(`¬ coreFails`, which includes "no `CAP_ABORT` on a covered request") and the final state has no internal
failure (`¬ internalFails`: no `CAP_ABORT`, every `T_j < T_j^max`). Quantifying over all `u` inside the
good-path predicate lets the comparators of Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` depend on the
whole transcript.

* `certSound_coreCorrect`, `numSound_coreCorrect`: endpoint rounding and clipping soundness (L1046);
* `reqCount`, `rejUpTo`, `LoopInv`: the bookkeeping invariant relating the state's counters to the history;
* `coreLoopSD_goodPaths`, `coreRunSD_goodPaths`: the multi-round statement.
-/

namespace F2e2e.B

open F2e2e.Discrete F2e2e.Opt.Quad DrawProg

variable {P : AdaParams} {rad : NoiseKind → ℚ}

/-! ## Rounding and clipping soundness (L1046) -/

theorem endQ_le_of_ge (P : AdaParams) {x : ℚ} (hx : -1 ≤ x) :
    ((endQ P x : ℚ) : ℝ) ≤ (x : ℝ) + (P.hA : ℝ) / 2 := by
  have h1 := (abs_le.1 (round_err (hA_pos P) (clipQ (-1) 2 x))).2
  have h2 : clipQ (-1) 2 x ≤ x := by unfold clipQ; exact max_le hx (min_le_right _ _)
  have : endQ P x ≤ x + P.hA / 2 := by unfold endQ; linarith
  exact_mod_cast this

theorem endQ_ge_of_le (P : AdaParams) {x : ℚ} (hx : x ≤ 2) :
    (x : ℝ) - (P.hA : ℝ) / 2 ≤ ((endQ P x : ℚ) : ℝ) := by
  have h1 := (abs_le.1 (round_err (hA_pos P) (clipQ (-1) 2 x))).1
  have h2 : x ≤ clipQ (-1) 2 x := by unfold clipQ; rw [min_eq_right hx]; exact le_max_right _ _
  have : x - P.hA / 2 ≤ endQ P x := by unfold endQ; linarith
  exact_mod_cast this

theorem endQ_ge_two (P : AdaParams) {x : ℚ} (hx : 2 < x) :
    2 - (P.hA : ℝ) / 2 ≤ ((endQ P x : ℚ) : ℝ) := by
  have h1 := (abs_le.1 (round_err (hA_pos P) (clipQ (-1) 2 x))).1
  have h2 : clipQ (-1) 2 x = 2 := by unfold clipQ; rw [min_eq_left hx.le]; norm_num
  have : 2 - P.hA / 2 ≤ endQ P x := by unfold endQ; rw [h2] at h1 ⊢; linarith
  exact_mod_cast this

theorem endQ_le_neg_one (P : AdaParams) {x : ℚ} (hx : x < -1) :
    ((endQ P x : ℚ) : ℝ) ≤ -1 + (P.hA : ℝ) / 2 := by
  have h1 := (abs_le.1 (round_err (hA_pos P) (clipQ (-1) 2 x))).2
  have h2 : clipQ (-1) 2 x = -1 := by
    unfold clipQ
    rw [min_eq_right (by linarith)]
    exact max_eq_left hx.le
  have : endQ P x ≤ -1 + P.hA / 2 := by unfold endQ; rw [h2] at h1 ⊢; linarith
  exact_mod_cast this

/-- **Endpoint rounding and clipping soundness** (L1046): a sound non-abort certificate (relative to the rounded
clipped endpoints) is correct for the original endpoints at accuracy `α`, for a population value `c ∈ [0, 1]`;
a `HIGH` at the clipped upper endpoint `2` or a `LOW` at `-1` would contradict `c ∈ [0, 1]`. -/
theorem certSound_coreCorrect (hP : AccParamsOK P) {α : ℝ} (hα : AccMargins P α) {U : Type}
    [Fintype U] (D : U → ℝ) (req : CoreReq U) (hI : req.isInterval = true)
    (hc01 : 0 ≤ reqMean P D req ∧ reqMean P D req ≤ 1) {cert : AdaCert}
    (hcert : CertSound P (reqMean P D req) req.l req.u cert) (hab : cert ≠ AdaCert.abort) :
    coreCorrect D P.hA α req (Sum.inl cert) := by
  have hA0 : (0 : ℝ) < P.hA := by exact_mod_cast hA_pos P
  have ha0 : (0 : ℝ) < P.a := by exact_mod_cast hP.a_pos
  have hroot0 : (0 : ℝ) ≤ ((rootErr P : ℚ) : ℝ) := by
    have := hP.tau_pos
    have : (0 : ℚ) ≤ rootErr P := by unfold rootErr; positivity
    exact_mod_cast this
  have hacc : 3 / 4 * (P.a : ℝ) + ((rootErr P : ℚ) : ℝ) + (P.hA : ℝ) / 2 ≤ α := by
    have := hα.accept
    push_cast at this ⊢
    linarith
  have hrej : ((rootErr P : ℚ) : ℝ) + (P.hA : ℝ) / 2 ≤ (P.a : ℝ) / 4 := by
    have h := hα.rej
    have h' : ((rootErr P + P.hA / 2 : ℚ) : ℝ) ≤ ((P.a / 4 : ℚ) : ℝ) := by exact_mod_cast h
    push_cast at h'
    exact h'
  have hsmall : 3 / 4 * (P.a : ℝ) + ((rootErr P : ℚ) : ℝ) + (P.hA : ℝ) / 2 < 1 := by
    have h := hα.small
    have h' : ((3 / 4 * P.a + rootErr P + P.hA / 2 : ℚ) : ℝ) < ((1 : ℚ) : ℝ) := by exact_mod_cast h
    push_cast at h'
    exact h'
  have hα0 : 0 ≤ α := by linarith
  set c := reqMean P D req with hcdef
  have hc0 := hc01.1
  have hc1 := hc01.2
  unfold coreCorrect
  rw [if_pos hI]
  cases cert with
  | accept =>
    obtain ⟨h1, h2⟩ := hcert
    push_cast at h1 h2
    refine ⟨?_, ?_⟩
    · by_cases hl : req.l ≤ 2
      · have := endQ_ge_of_le P hl
        change (req.l : ℝ) - α ≤ c
        linarith
      · have := endQ_ge_two P (lt_of_not_ge hl)
        exfalso
        linarith
    · by_cases hu : -1 ≤ req.u
      · have := endQ_le_of_ge P hu
        change c ≤ (req.u : ℝ) + α
        linarith
      · have := endQ_le_neg_one P (lt_of_not_ge hu)
        exfalso
        linarith
  | high =>
    have h1 : ((endQ P req.u + P.a / 4 - rootErr P : ℚ) : ℝ) ≤ c := hcert
    push_cast at h1
    change (req.u : ℝ) - α ≤ c
    by_cases hu : req.u ≤ 2
    · have := endQ_ge_of_le P hu
      linarith
    · have := endQ_ge_two P (lt_of_not_ge hu)
      exfalso
      linarith
  | termHigh =>
    have h1 : ((endQ P req.u + P.a / 4 - rootErr P : ℚ) : ℝ) ≤ c := hcert
    push_cast at h1
    change (req.u : ℝ) - α ≤ c
    by_cases hu : req.u ≤ 2
    · have := endQ_ge_of_le P hu
      linarith
    · have := endQ_ge_two P (lt_of_not_ge hu)
      exfalso
      linarith
  | low =>
    have h1 : c ≤ ((endQ P req.l - P.a / 4 + rootErr P : ℚ) : ℝ) := hcert
    push_cast at h1
    change c ≤ (req.l : ℝ) + α
    by_cases hl : -1 ≤ req.l
    · have := endQ_le_of_ge P hl
      linarith
    · have := endQ_le_neg_one P (lt_of_not_ge hl)
      exfalso
      linarith
  | termLow =>
    have h1 : c ≤ ((endQ P req.l - P.a / 4 + rootErr P : ℚ) : ℝ) := hcert
    push_cast at h1
    change c ≤ (req.l : ℝ) + α
    by_cases hl : -1 ≤ req.l
    · have := endQ_le_of_ge P hl
      linarith
    · have := endQ_le_neg_one P (lt_of_not_ge hl)
      exfalso
      linarith
  | abort => exact absurd rfl hab

/-- Numerical soundness gives correctness (L1044). -/
theorem numSound_coreCorrect {α : ℝ} (hα : AccMargins P α) {U : Type} [Fintype U] (D : U → ℝ)
    (req : CoreReq U) (hI : req.isInterval = false) {out : AdaNum}
    (hout : NumSound P (reqMean P D req) out) (hab : out ≠ AdaNum.abort) :
    coreCorrect D P.hA α req (Sum.inr out) := by
  unfold coreCorrect
  rw [if_neg (by simp [hI])]
  cases out with
  | val q =>
    obtain ⟨h0, h1, h2⟩ := hout
    have hn := hα.num
    refine ⟨by exact_mod_cast h0, by exact_mod_cast h1, ?_⟩
    exact h2.trans hn
  | abort => exact absurd rfl hab

/-! ## Bookkeeping of the online execution -/

/-- Number of requests of type `b` (`true` = interval) among the first `n` rounds. -/
def reqCount {U : Type} (ctrl : CoreCtrl U) (o : List CoreOut) (b : Bool) (n : ℕ) : ℕ :=
  ((Finset.range n).filter fun i => (coreReqAt ctrl o i).isInterval = b).card

/-- Number of rejections among the first `n` rounds on interval requests among the first `M`. -/
def rejUpTo {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (n : ℕ) : ℕ :=
  ((Finset.range n).filter fun j => (coreReqAt ctrl o j).isInterval = true ∧
      ((Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl o i).isInterval = true)).card ≤ P.M ∧
      coreIsReject (coreOutAt o j) = true).card

theorem coreCovered_iff {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (t : ℕ) :
    coreCovered P ctrl o t ↔ rejUpTo P ctrl o t ≤ P.J ∧
      ((coreReqAt ctrl o t).isInterval = true → reqCount ctrl o true (t + 1) ≤ P.M) ∧
      ((coreReqAt ctrl o t).isInterval = false → reqCount ctrl o false (t + 1) ≤ P.R) := Iff.rfl

theorem coreCandidate_iff {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (t : ℕ) :
    CoreCandidate P ctrl o t ↔ if (coreReqAt ctrl o t).isInterval = true then
      reqCount ctrl o true (t + 1) ≤ P.M else reqCount ctrl o false (t + 1) ≤ P.R := Iff.rfl

theorem coreReqAt_append {U : Type} (ctrl : CoreCtrl U) (hist rest : List CoreOut) {t : ℕ}
    (ht : t ≤ hist.length) : coreReqAt ctrl (hist ++ rest) t = coreReqAt ctrl hist t := by
  unfold coreReqAt
  rw [List.take_append_of_le_length ht]

theorem coreReqAt_length {U : Type} (ctrl : CoreCtrl U) (hist : List CoreOut) :
    coreReqAt ctrl hist hist.length = ctrl hist := by
  unfold coreReqAt
  rw [List.take_length]

theorem coreOutAt_append (hist rest : List CoreOut) {t : ℕ} (ht : t < hist.length) :
    coreOutAt (hist ++ rest) t = coreOutAt hist t := by
  unfold coreOutAt
  exact List.getD_append _ _ _ _ ht

theorem coreOutAt_append_length (hist : List CoreOut) (x : CoreOut) (rest : List CoreOut) :
    coreOutAt (hist ++ x :: rest) hist.length = x := by
  unfold coreOutAt
  rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
  rfl

theorem reqCount_append {U : Type} (ctrl : CoreCtrl U) (hist rest : List CoreOut) (b : Bool) {n : ℕ}
    (hn : n ≤ hist.length + 1) : reqCount ctrl (hist ++ rest) b n = reqCount ctrl hist b n := by
  unfold reqCount
  congr 1
  apply Finset.filter_congr
  intro i hi
  rw [coreReqAt_append ctrl hist rest (by simp at hi; omega)]

theorem reqCount_succ {U : Type} (ctrl : CoreCtrl U) (o : List CoreOut) (b : Bool) (n : ℕ) :
    reqCount ctrl o b (n + 1) =
      reqCount ctrl o b n + if (coreReqAt ctrl o n).isInterval = b then 1 else 0 := by
  unfold reqCount
  rw [Finset.range_add_one, Finset.filter_insert]
  split_ifs with h
  · rw [Finset.card_insert_of_notMem (by simp)]
  · rw [add_zero]

theorem rejUpTo_append {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (hist rest : List CoreOut) {n : ℕ}
    (hn : n ≤ hist.length) : rejUpTo P ctrl (hist ++ rest) n = rejUpTo P ctrl hist n := by
  unfold rejUpTo
  congr 1
  apply Finset.filter_congr
  intro j hj
  have hj' : j < hist.length := by simp at hj; omega
  rw [coreReqAt_append ctrl hist rest hj'.le, coreOutAt_append hist rest hj']
  have : ((Finset.range (j + 1)).filter fun i => (coreReqAt ctrl (hist ++ rest) i).isInterval = true) =
      ((Finset.range (j + 1)).filter fun i => (coreReqAt ctrl hist i).isInterval = true) :=
    Finset.filter_congr fun i hi => by rw [coreReqAt_append ctrl hist rest (by simp at hi; omega)]
  rw [this]

theorem rejUpTo_succ {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (o : List CoreOut) (n : ℕ) :
    rejUpTo P ctrl o (n + 1) = rejUpTo P ctrl o n +
      if (coreReqAt ctrl o n).isInterval = true ∧ reqCount ctrl o true (n + 1) ≤ P.M ∧
        coreIsReject (coreOutAt o n) = true then 1 else 0 := by
  unfold rejUpTo
  rw [Finset.range_add_one, Finset.filter_insert]
  unfold reqCount
  split_ifs with h
  · rw [Finset.card_insert_of_notMem (by simp)]
  · rw [add_zero]

theorem coreCovered_append {U : Type} (P : AdaParams) (ctrl : CoreCtrl U) (hist rest : List CoreOut)
    {t : ℕ} (ht : t < hist.length) :
    coreCovered P ctrl (hist ++ rest) t ↔ coreCovered P ctrl hist t := by
  rw [coreCovered_iff, coreCovered_iff, rejUpTo_append P ctrl hist rest ht.le,
    reqCount_append ctrl hist rest true (by omega), reqCount_append ctrl hist rest false (by omega),
    coreReqAt_append ctrl hist rest ht.le]

theorem coreIsReject_inl (c : AdaCert) : coreIsReject (Sum.inl c) = c.isRej := by
  cases c <;> rfl

/-- The bookkeeping invariant of the online execution after the outputs `hist`, with state `st`. -/
structure LoopInv (P : AdaParams) (rad : NoiseKind → ℚ) (u : (j : ℕ) → Fin (blockN P j) → ℝ)
    {U : Type} [Fintype U] (D : U → ℝ) (α : ℝ) (ctrl : CoreCtrl U) (st : AdaState)
    (hist : List CoreOut) : Prop where
  inv : AccInv P rad u st
  live : st.halted = false → st.nInt = min P.M (reqCount ctrl hist true hist.length) ∧
    st.nNum = min P.R (reqCount ctrl hist false hist.length) ∧
    st.rej = rejUpTo P ctrl hist hist.length
  dead : st.halted = true → P.J + 1 ≤ rejUpTo P ctrl hist hist.length
  ok : ∀ t < hist.length, coreCovered P ctrl hist t →
    coreCorrect D P.hA α (coreReqAt ctrl hist t) (coreOutAt hist t)

theorem loopInv_snoc {u : (j : ℕ) → Fin (blockN P j) → ℝ} {U : Type} [Fintype U] {D : U → ℝ}
    {α : ℝ} {ctrl : CoreCtrl U} {st' : AdaState} {hist : List CoreOut} {x : CoreOut}
    (hinv : AccInv P rad u st')
    (hlive : st'.halted = false →
      st'.nInt = min P.M (reqCount ctrl (hist ++ [x]) true (hist.length + 1)) ∧
      st'.nNum = min P.R (reqCount ctrl (hist ++ [x]) false (hist.length + 1)) ∧
      st'.rej = rejUpTo P ctrl (hist ++ [x]) (hist.length + 1))
    (hdead : st'.halted = true → P.J + 1 ≤ rejUpTo P ctrl (hist ++ [x]) (hist.length + 1))
    (hok : ∀ t < hist.length + 1, coreCovered P ctrl (hist ++ [x]) t →
      coreCorrect D P.hA α (coreReqAt ctrl (hist ++ [x]) t) (coreOutAt (hist ++ [x]) t)) :
    LoopInv P rad u D α ctrl st' (hist ++ [x]) := by
  have hL : (hist ++ [x]).length = hist.length + 1 := by simp
  exact ⟨hinv, by rw [hL]; exact hlive, by rw [hL]; exact hdead, by rw [hL]; exact hok⟩

theorem goodPaths_true {good : NoiseKind → ℤ → Prop} {α : Type} (prog : NoiseProg α) :
    prog.GoodPaths good (fun _ => True) := by
  induction prog with
  | ret a => trivial
  | draw p k ih => exact fun b _ => ih b

/-- Every output of `T` further rounds extends the history by `T` outputs. -/
theorem coreLoopSD_prefix {good : NoiseKind → ℤ → Prop} (P : AdaParams) {U : Type} (ctrl : CoreCtrl U)
    (s : Fin P.N → U) : ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut),
      (coreLoopSD P ctrl s T st hist).GoodPaths good
        (fun r => ∃ rest, r.1 = hist ++ rest ∧ rest.length = T)
  | 0, st, hist => (goodPaths_ret _).2 ⟨[], by simp, rfl⟩
  | T + 1, st, hist => by
    simp only [coreLoopSD]
    refine (goodPaths_true _).bind fun a _ => (coreLoopSD_prefix P ctrl s T a.2 (hist ++ [a.1])).mono ?_
    rintro r ⟨rest, h1, h2⟩
    exact ⟨a.1 :: rest, by simp [h1], by simp [h2]⟩

theorem valsOK_coreVals {U : Type} (P : AdaParams) (s : Fin P.N → U) (req : CoreReq U) :
    ValsOK P (coreVals P s req) := by
  intro j _
  rw [coreVals_getD]
  simp

theorem reqMean_mem {U : Type} [Fintype U] (P : AdaParams) (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x)
    (hD1 : ∑ x, D x = 1) (req : CoreReq U) (hf : ∀ x, req.f x ≤ 2 ^ P.qA) :
    0 ≤ reqMean P D req ∧ reqMean P D req ≤ 1 := by
  unfold reqMean popMean
  have hA0 : (0 : ℝ) < P.hA := by exact_mod_cast hA_pos P
  have hA1 : (P.hA : ℝ) * (2 : ℝ) ^ P.qA = 1 := by exact_mod_cast hA_mul_two_pow P
  have h1 : ∀ x, (P.hA : ℝ) * req.f x ≤ 1 := by
    intro x
    have hx : (req.f x : ℝ) ≤ (2 : ℝ) ^ P.qA := by exact_mod_cast hf x
    calc (P.hA : ℝ) * req.f x ≤ P.hA * 2 ^ P.qA := mul_le_mul_of_nonneg_left hx hA0.le
      _ = 1 := hA1
  constructor
  · exact Finset.sum_nonneg fun x _ => mul_nonneg (hD0 x) (by positivity)
  · calc ∑ x, D x * ((P.hA : ℝ) * req.f x) ≤ ∑ x, D x * 1 :=
          Finset.sum_le_sum fun x _ => mul_le_mul_of_nonneg_left (h1 x) (hD0 x)
      _ = 1 := by simp [hD1]

/-! ## The online execution -/

/-- **(P5) on the good event, the online loop**: from a state satisfying the bookkeeping invariant, along
every path of good noise draws, if the comparators `u` are accurate on every candidate query of the final
output history then no covered round fails and the final state has no internal failure. -/
theorem coreLoopSD_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad)
    {u : (j : ℕ) → Fin (blockN P j) → ℝ} (hu : CompAdmissible P u)
    {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1)
    (ctrl : CoreCtrl U) (hctrl : ctrl.Valid P) (s : Fin P.N → U) {α : ℝ} (hα : AccMargins P α) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut), LoopInv P rad u D α ctrl st hist →
      (coreLoopSD P ctrl s T st hist).GoodPaths (NoiseGood P rad)
        (fun r => CompOK P D ctrl s u r.1 → ¬ coreFails P D α ctrl r.1 ∧ ¬ internalFails P r.2)
  | 0, st, hist, hinv => by
    simp only [coreLoopSD]
    refine (goodPaths_ret _).2 fun _ => ⟨?_, ?_⟩
    · rintro ⟨t, ht, hcov, hinc⟩
      exact hinc (hinv.ok t ht hcov)
    · rintro (h | ⟨j, hj, hle⟩)
      · rw [hinv.inv.not_capAborted] at h
        exact Bool.false_ne_true h
      · exact absurd hle (not_le.2 (accInv_T_lt_Tmax hP hu hinv.inv j hj))
  | T + 1, st, hist, hinv => by
    simp only [coreLoopSD]
    have hvals := valsOK_coreVals P s (ctrl hist)
    have hc01 := reqMean_mem P D hD0 hD1 (ctrl hist) (hctrl hist).1
    -- the new round `t = hist.length`, with history `hist ++ [x] ++ rest`
    have hreq : ∀ x rest, coreReqAt ctrl (hist ++ x :: rest) hist.length = ctrl hist := fun x rest => by
      rw [coreReqAt_append ctrl hist _ le_rfl, coreReqAt_length]
    have hcount : ∀ x rest b, reqCount ctrl (hist ++ x :: rest) b (hist.length + 1) =
        reqCount ctrl hist b hist.length + if (ctrl hist).isInterval = b then 1 else 0 := by
      intro x rest b
      rw [reqCount_append ctrl hist _ b le_rfl, reqCount_succ, coreReqAt_length]
    have hrejc : ∀ x rest, rejUpTo P ctrl (hist ++ x :: rest) (hist.length + 1) =
        rejUpTo P ctrl hist hist.length +
          if (ctrl hist).isInterval = true ∧ reqCount ctrl hist true hist.length +
            (if (ctrl hist).isInterval = true then 1 else 0) ≤ P.M ∧ coreIsReject x = true
          then 1 else 0 := by
      intro x rest
      rw [rejUpTo_succ, rejUpTo_append P ctrl hist _ le_rfl, hreq, hcount, coreOutAt_append_length]
    -- old rounds keep their coverage and correctness
    have hold : ∀ x : CoreOut, ∀ t < hist.length, coreCovered P ctrl (hist ++ [x]) t →
        coreCorrect D P.hA α (coreReqAt ctrl (hist ++ [x]) t) (coreOutAt (hist ++ [x]) t) := by
      intro x t ht hcov
      rw [coreCovered_append P ctrl hist [x] ht] at hcov
      rw [coreReqAt_append ctrl hist [x] ht.le, coreOutAt_append hist [x] ht]
      exact hinv.ok t ht hcov
    unfold coreStepD
    by_cases hI : (ctrl hist).isInterval = true
    · rw [if_pos hI]
      simp only [DrawProg.map, DrawProg.bind_assoc, Function.comp, bind_ret]
      by_cases hgood : ¬(st.halted = true ∨ P.M ≤ st.nInt) →
          CompCond P u (coreVals P s (ctrl hist)) (reqMean P D (ctrl hist))
      · refine (interval_goodPaths hP hrad hu hinv.inv hvals hgood (ctrl hist).l (ctrl hist).u).bind ?_
        rintro ⟨cert, st'⟩ ⟨hinv', hsound, hbook⟩
        refine coreLoopSD_goodPaths hP hrad hu D hD0 hD1 ctrl hctrl s hα T st' (hist ++ [Sum.inl cert]) ?_
        have hc1 := hcount (Sum.inl cert) [] true
        have hc2 := hcount (Sum.inl cert) [] false
        have hr1 := hrejc (Sum.inl cert) []
        rw [if_pos hI] at hc1 hr1
        rw [if_neg (by simp [hI])] at hc2
        rw [coreIsReject_inl] at hr1
        by_cases hrf : st.halted = true ∨ P.M ≤ st.nInt
        · -- refused: `abort`, no state change, not covered
          obtain ⟨hr, hst'⟩ := Prod.mk.inj (hbook.1 hrf)
          subst hr
          subst st'
          refine loopInv_snoc hinv' (fun hh => ?_) (fun hh => ?_) (fun t ht hcov => ?_)
          · obtain ⟨h1, h2, h3⟩ := hinv.live hh
            have hM : P.M ≤ reqCount ctrl hist true hist.length := by
              rcases hrf with h | h
              · rw [hh] at h; exact absurd h (by simp)
              · omega
            refine ⟨by rw [hc1]; omega, by rw [hc2]; omega, ?_⟩
            rw [hr1, if_neg (by simp [AdaCert.isRej]), add_zero]
            exact h3
          · rw [hr1]
            have := hinv.dead hh
            omega
          · rcases Nat.lt_succ_iff_lt_or_eq.1 ht with ht' | ht'
            · exact hold _ t ht' hcov
            · exfalso
              subst ht'
              rw [coreCovered_iff, hreq, rejUpTo_append P ctrl hist _ le_rfl, hc1] at hcov
              obtain ⟨hcj, hcm, -⟩ := hcov
              rcases hrf with h | h
              · have := hinv.dead h
                omega
              · have hh : st.halted = false := by
                  cases hst : st.halted
                  · rfl
                  · have := hinv.dead hst
                    omega
                obtain ⟨h1, -, -⟩ := hinv.live hh
                have := hcm hI
                omega
        · -- processed: a sound genuine certificate
          obtain ⟨hab, e1, e2, e3, e4, e5⟩ := hbook.2 hrf
          simp only at hab e1 e2 e3 e4 e5
          have hh : st.halted = false := by simpa using (not_or.1 hrf).1
          obtain ⟨h1, h2, h3⟩ := hinv.live hh
          have hlt : reqCount ctrl hist true hist.length < P.M := by
            have := (not_or.1 hrf).2
            omega
          refine loopInv_snoc hinv' (fun hh' => ?_) (fun hh' => ?_) (fun t ht hcov => ?_)
          · refine ⟨by rw [e1, hc1]; omega, by rw [e2, hc2]; omega, ?_⟩
            rw [e3, hr1, h3]
            by_cases hrj : cert.isRej = true
            · rw [if_pos hrj, if_pos ⟨hI, by omega, hrj⟩]
            · rw [if_neg hrj, if_neg (fun h => hrj h.2.2)]
          · rw [e4] at hh'
            obtain ⟨hrj, hJ⟩ := e5.1 hh'
            rw [hr1, if_pos ⟨hI, by omega, hrj⟩, ← h3]
            omega
          · rcases Nat.lt_succ_iff_lt_or_eq.1 ht with ht' | ht'
            · exact hold _ t ht' hcov
            · subst ht'
              rw [hreq, coreOutAt_append_length]
              exact certSound_coreCorrect hP hα D (ctrl hist) hI hc01 hsound hab
      · -- the comparators fail on this candidate query: the final history violates `CompOK`
        push Not at hgood
        obtain ⟨hrf, hbad⟩ := hgood
        refine (goodPaths_true _).bind fun a _ =>
          (coreLoopSD_prefix P ctrl s T a.2 (hist ++ [Sum.inl a.1])).mono ?_
        rintro r ⟨rest, hr, -⟩ hok
        exfalso
        have hh : st.halted = false := by simpa using hrf.1
        obtain ⟨h1, -, -⟩ := hinv.live hh
        have hlt : reqCount ctrl hist true hist.length < P.M := by
          have := hrf.2
          omega
        have hr' : r.1 = hist ++ Sum.inl a.1 :: rest := by rw [hr]; simp
        have hcand : CoreCandidate P ctrl r.1 hist.length := by
          rw [coreCandidate_iff, hr', hreq, if_pos hI, hcount, if_pos hI]
          omega
        have := hok hist.length (by rw [hr']; simp) hcand
        rw [hr', hreq] at this
        exact hbad this
    · have hN : (ctrl hist).isInterval = false := by simpa using hI
      rw [if_neg hI]
      simp only [DrawProg.map, DrawProg.bind_assoc, Function.comp, bind_ret]
      by_cases hgood : ¬(st.halted = true ∨ P.R ≤ st.nNum) →
          CompCond P u (coreVals P s (ctrl hist)) (reqMean P D (ctrl hist))
      · refine (numerical_goodPaths hP hrad hu hinv.inv hvals hgood hc01).bind ?_
        rintro ⟨out, st'⟩ ⟨hinv', hsound, hbook⟩
        refine coreLoopSD_goodPaths hP hrad hu D hD0 hD1 ctrl hctrl s hα T st' (hist ++ [Sum.inr out]) ?_
        have hc1 := hcount (Sum.inr out) [] true
        have hc2 := hcount (Sum.inr out) [] false
        have hr1 := hrejc (Sum.inr out) []
        rw [if_neg hI] at hc1
        rw [if_pos hN] at hc2
        rw [if_neg (fun h => hI h.1)] at hr1
        by_cases hrf : st.halted = true ∨ P.R ≤ st.nNum
        · obtain ⟨hr, hst'⟩ := Prod.mk.inj (hbook.1 hrf)
          subst hr
          subst st'
          refine loopInv_snoc hinv' (fun hh => ?_) (fun hh => ?_) (fun t ht hcov => ?_)
          · obtain ⟨h1, h2, h3⟩ := hinv.live hh
            have hR : P.R ≤ reqCount ctrl hist false hist.length := by
              rcases hrf with h | h
              · rw [hh] at h; exact absurd h (by simp)
              · omega
            refine ⟨by rw [hc1]; omega, by rw [hc2]; omega, ?_⟩
            rw [hr1, add_zero]
            exact h3
          · rw [hr1, add_zero]
            exact hinv.dead hh
          · rcases Nat.lt_succ_iff_lt_or_eq.1 ht with ht' | ht'
            · exact hold _ t ht' hcov
            · exfalso
              subst ht'
              rw [coreCovered_iff, hreq, rejUpTo_append P ctrl hist _ le_rfl, hc2] at hcov
              obtain ⟨hcj, -, hcr⟩ := hcov
              rcases hrf with h | h
              · have := hinv.dead h
                omega
              · have hh : st.halted = false := by
                  cases hst : st.halted
                  · rfl
                  · have := hinv.dead hst
                    omega
                obtain ⟨-, h2, -⟩ := hinv.live hh
                have := hcr hN
                omega
        · obtain ⟨hab, e1, e2, e3, e4⟩ := hbook.2 hrf
          simp only at hab e1 e2 e3 e4
          have hh : st.halted = false := by simpa using (not_or.1 hrf).1
          obtain ⟨h1, h2, h3⟩ := hinv.live hh
          have hlt : reqCount ctrl hist false hist.length < P.R := by
            have := (not_or.1 hrf).2
            omega
          refine loopInv_snoc hinv' (fun hh' => ?_) (fun hh' => ?_) (fun t ht hcov => ?_)
          · refine ⟨by rw [e2, hc1]; omega, by rw [e1, hc2]; omega, ?_⟩
            rw [e3, hr1, add_zero, h3]
          · rw [e4, hh] at hh'
            exact absurd hh' (by simp)
          · rcases Nat.lt_succ_iff_lt_or_eq.1 ht with ht' | ht'
            · exact hold _ t ht' hcov
            · subst ht'
              rw [hreq, coreOutAt_append_length]
              exact numSound_coreCorrect hα D (ctrl hist) hN hsound hab
      · push Not at hgood
        obtain ⟨hrf, hbad⟩ := hgood
        refine (goodPaths_true _).bind fun a _ =>
          (coreLoopSD_prefix P ctrl s T a.2 (hist ++ [Sum.inr a.1])).mono ?_
        rintro r ⟨rest, hr, -⟩ hok
        exfalso
        have hh : st.halted = false := by simpa using hrf.1
        obtain ⟨-, h2, -⟩ := hinv.live hh
        have hlt : reqCount ctrl hist false hist.length < P.R := by
          have := hrf.2
          omega
        have hr' : r.1 = hist ++ Sum.inr a.1 :: rest := by rw [hr]; simp
        have hcand : CoreCandidate P ctrl r.1 hist.length := by
          rw [coreCandidate_iff, hr', hreq, if_neg hI, hcount, if_pos hN]
          omega
        have := hok hist.length (by rw [hr']; simp) hcand
        rw [hr', hreq] at this
        exact hbad this

/-- **(P5) on the good event, online execution**: along every path of good noise draws, for every admissible
comparator family accurate on every candidate query, no covered round of the execution has an incorrect output
(in particular no covered request is answered by `CAP_ABORT`) and the final state has no internal failure (no
`CAP_ABORT`, no correction cap reached). -/
theorem coreRunSD_goodPaths (hP : AccParamsOK P) (hrad : RadOK P rad)
    {U : Type} [Fintype U] (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1)
    (ctrl : CoreCtrl U) (hctrl : ctrl.Valid P) (s : Fin P.N → U) (T : ℕ) {α : ℝ}
    (hα : AccMargins P α) :
    (coreRunSD P ctrl s T).GoodPaths (NoiseGood P rad)
      (fun r => ∀ u, CompAdmissible P u → CompOK P D ctrl s u r.1 →
        ¬ coreFails P D α ctrl r.1 ∧ ¬ internalFails P r.2) := by
  refine goodPaths_forall fun u => ?_
  by_cases hu : CompAdmissible P u
  · unfold coreRunSD
    refine (accInv_init (rad := rad) hP hu).bind ?_
    rintro st ⟨hinv, hrej, hnI, hnN, hhalt⟩
    refine (coreLoopSD_goodPaths hP hrad hu D hD0 hD1 ctrl hctrl s hα T st [] ?_).mono
      fun r h _ => h
    exact ⟨hinv, fun _ => ⟨by simp [hnI, reqCount], by simp [hnN, reqCount], by simp [hrej, rejUpTo]⟩,
      fun h => by rw [hhalt] at h; exact absurd h (by simp), fun t ht => absurd ht (by simp)⟩
  · exact (goodPaths_true _).mono fun r _ h => absurd h hu

end F2e2e.B
