import F2e2e.B.AccuracyFinal
import F2e2e.B.ArchBridge
import F2e2e.B.ArchMeas
import F2e2e.B.ArchParamsBridge
import F2e2e.B.NumericsN
import F2e2e.B.SpecV2BridgeFinal
import F2e2e.SpecV1Compat

/-!
# Main Theorem (B): `theorem_B_statistical_proof : Theorem_B_statistical`

Theorem `R:thm:validation_ada` (`parts/partII.tex` L951–971) for Algorithm 2 with the parameters of
Definition `R:def:sec3_ada_params`.

**Headline.** `theorem_B_statistical_proof : F2e2e.Theorem_B_statistical` is about the Spec's
Algorithm 2 (`alg2Mech`, `alg2Aborted`, `alg2PeakCorrections`, parameters `alg2Params`): the two
size conjuncts (B-NUM's `V2.v2par_size_conjuncts`, `F2e2e/B/SpecV2BridgeParams.lean`) and the
guarantee with internal caps (`V2.alg2V2_guarantee`, `F2e2e/B/SpecV2BridgeFinal.lean`: the Spec's
execution simulates the core of `F2e2e/B/ArchCore.lean`, whose guarantee with internal caps is
`accuracy_core_guarantee_detS`, `F2e2e/B/AccuracyFinal.lean`).

**Our mechanism.** The results about our implementation `adaAlg2Mech` of Algorithm 2
(`F2e2e/B/Mechanism.lean`) are kept; `VGuarantee` and `Theorem_B` are the v1 definitions
(`F2e2e/SpecV1Compat.lean`):

* `alg2_guarantee_det`: the guarantee for every **deterministic** valid controller
  (`VGuaranteeDet`, `F2e2e/B/ArchOnline.lean`), from the core-level guarantee `core_guarantee_det`
  (the primary analysis statement, proved from the skeleton of Theorem 3.6's proof,
  `F2e2e/B/Accuracy*.lean`, `F2e2e/B/Privacy*.lean`) by `alg2_guarantee_det_of_core`;
* `VGuaranteeDet.aux` (`ArchOnline`): the same with an independent auxiliary parameter; Part III uses
  the core-level `core_guarantee` for its composite controllers (partII.tex L1032; partIII.tex L121,
  L353, L393);
* `vGuarantee_of_det`: deterministic ⇒ randomized controllers (any coin probability space,
  measurable in the coins for each fixed history), for mechanisms whose responses are measurable in
  the views (`mechOf_measurableSet`);
* `alg2_guarantee : VGuarantee … (adaAlg2Mech …)`;
* sizes: `adaParams_N_eq` (B-NUM, `F2e2e/B/ArchParamsBridge.lean`: the mechanism's `N` is the paper's
  `∑_{j=0}^p n_j`) and B-NUM's `alg2_N_le_explicit`, `alg2_N_le_asymp` (`F2e2e/B/NumericsN.lean`);
* `theorem_B_proof : Theorem_B`: the v1 form of Main Theorem (B), with `adaAlg2Mech`.
-/

namespace F2e2e.B

open MeasureTheory

/-- **Deterministic ⇒ randomized controllers.** If every response of `mech` is a measurable function
of the views, then the guarantee for deterministic controllers implies `VGuarantee` (randomized
controllers on any coin probability space, measurable in the coins for each fixed history): the
failure set is then measurable in the controller's coins (responses are countable), and the bound
integrates. -/
theorem vGuarantee_of_det {N c : ℕ} (mech : VMechanism N c) (M J R : ℕ) (aReq ξReq : ℝ)
    (hmeas : ∀ (t : ℕ) (ω : Fin c → Bool) (r : VResponse),
      MeasurableSet {views : Fin (t + 1) → (Fin N → ℝ) × Bool × ℝ × ℝ | mech t views ω = r})
    (h : VGuaranteeDet M J R aReq ξReq mech) : VGuarantee M J R aReq ξReq mech := by
  classical
  intro U _ D hD0 hD1 Ω _ P _ ctrl hvalid hctrl
  have hE : ∀ (s : Fin N → U) (ω' : Fin c → Bool),
      MeasurableSet {ω | VFails mech D M J R aReq (ctrl ω) s ω'} := fun s ω' =>
    measurableSet_vFails mech ctrl hctrl D M J R aReq (fun t ω r => hmeas t ω r) s ω'
  have hpt : ∀ (s : Fin N → U) (ω' : Fin c → Bool), P {ω | VFails mech D M J R aReq (ctrl ω) s ω'} =
      ∫⁻ ω, (if VFails mech D M J R aReq (ctrl ω) s ω' then 1 else 0) ∂P := by
    intro s ω'
    rw [← lintegral_indicator_one (hE s ω')]
    congr 1
  calc ∑ s : Fin N → U, ∑ ω' : Fin c → Bool,
        ENNReal.ofReal (∏ ℓ, D (s ℓ)) * P {ω | VFails mech D M J R aReq (ctrl ω) s ω'}
      = ∑ s : Fin N → U, ∑ ω' : Fin c → Bool, ∫⁻ ω, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if VFails mech D M J R aReq (ctrl ω) s ω' then 1 else 0) ∂P := by
        refine Finset.sum_congr rfl fun s _ => Finset.sum_congr rfl fun ω' _ => ?_
        rw [hpt, lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
    _ ≤ ∑ s : Fin N → U, ∫⁻ ω, ∑ ω' : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if VFails mech D M J R aReq (ctrl ω) s ω' then 1 else 0) ∂P :=
        Finset.sum_le_sum fun s _ => sum_lintegral_le_lintegral_sum P _ _
    _ ≤ ∫⁻ ω, ∑ s : Fin N → U, ∑ ω' : Fin c → Bool, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (if VFails mech D M J R aReq (ctrl ω) s ω' then 1 else 0) ∂P :=
        sum_lintegral_le_lintegral_sum P _ _
    _ = ∫⁻ ω, vDetFailMass mech D M J R aReq (ctrl ω) ∂P := by
        congr 1
    _ ≤ ∫⁻ _ω, ENNReal.ofReal ξReq * 2 ^ c ∂P :=
        lintegral_mono fun ω => h U D hD0 hD1 (ctrl ω) (hvalid ω)
    _ = ENNReal.ofReal ξReq * 2 ^ c := by simp

/-! ## Theorem `R:thm:validation_ada` for Algorithm 2 -/

/-- **Theorem `R:thm:validation_ada`, core level, deterministic controllers** (`CoreGuaranteeDet`):
the primary analysis statement (P1–P5 of the proof of Theorem 3.6: `accuracy_core_guarantee_detS`,
`F2e2e/B/AccuracyFinal.lean`, which also bounds the internal-cap failures). -/
theorem core_guarantee_det (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) : CoreGuaranteeDet M J R aReq ξReq :=
  coreGuaranteeDet_of_S (accuracy_core_guarantee_detS M J R ha0 ha1 hξ0 hξ1)

/-- **Theorem `R:thm:validation_ada`, core level, controllers with independent auxiliary
randomness** (the form Part III applies to its composite controllers: adversary coins × the other
components' bits, any probability space, no measurability needed): the online execution of the core
fails at accuracy `a_req` with probability at most `ξ_req`. -/
theorem core_guarantee (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (Ω : Type) [MeasurableSpace Ω] (Pω : Measure Ω)
    [IsProbabilityMeasure Pω] (ctrl : Ω → CoreCtrl U)
    (hctrl : ∀ ω, (ctrl ω).Valid (adaAlg2Params M J R aReq ξReq)) (T : ℕ) :
    ∑ s : Fin (adaAlg2Params M J R aReq ξReq).N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
      ∫⁻ ω, (coreRun (adaAlg2Params M J R aReq ξReq) (ctrl ω) s T).law.toOuterMeasure
        {o | coreFails (adaAlg2Params M J R aReq ξReq) D aReq (ctrl ω) o} ∂Pω ≤
      ENNReal.ofReal ξReq :=
  core_guarantee_of_det (core_guarantee_det M J R ha0 ha1 hξ0 hξ1) D hD0 hD1 Ω Pω ctrl hctrl T

/-- **Theorem `R:thm:validation_ada`, deterministic controllers**: Algorithm 2 with the parameters of
Definition `R:def:sec3_ada_params` fails (some covered response incorrect) with probability at most
`ξ_req`. -/
theorem alg2_guarantee_det (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    VGuaranteeDet M J R aReq ξReq (adaAlg2Mech M J R aReq ξReq) :=
  alg2_guarantee_det_of_core M J R ha0 ha1 hξ0 hξ1 (core_guarantee_det M J R ha0 ha1 hξ0 hξ1)

/-- **Theorem `R:thm:validation_ada`** (randomized controllers, the Spec's `VGuarantee`). -/
theorem alg2_guarantee (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    VGuarantee M J R aReq ξReq (adaAlg2Mech M J R aReq ξReq) :=
  vGuarantee_of_det _ M J R aReq ξReq (fun t ω r => mechOf_measurableSet _ t ω r)
    (alg2_guarantee_det M J R ha0 ha1 hξ0 hξ1)

/-- The sample size of `adaAlg2Mech` is the paper's `N = ∑_{j=0}^p n_j`. -/
theorem alg2Params_N (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaAlg2Params M J R aReq ξReq).N = alg2N M J R aReq ξReq :=
  adaParams_N_eq M J R ha0 ha1 hξ0 hξ1

/-- **Main Theorem (B), v1 form** (`Theorem_B` of `F2e2e/SpecV1Compat.lean`), with our mechanism
`adaAlg2Mech`. -/
theorem theorem_B_proof : Theorem_B := by
  obtain ⟨C, hC, hasymp⟩ := alg2_N_le_asymp
  refine ⟨C, hC, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 => ?_⟩
  refine ⟨(adaAlg2Params M J R aReq ξReq).N, adaCoins (adaAlg2Params M J R aReq ξReq),
    adaAlg2Mech M J R aReq ξReq, ?_, ?_, alg2_guarantee M J R ha0 ha1 hξ0 hξ1⟩
  · rw [alg2Params_N M J R ha0 ha1 hξ0 hξ1]
    exact alg2_N_le_explicit M J R ha0 ha1 hξ0 hξ1
  · rw [alg2Params_N M J R ha0 ha1 hξ0 hξ1]
    exact hasymp M J R aReq ξReq ha0 ha1 hξ0 hξ1

/-! ## Main Theorem (B) of the Spec -/

/-- **Main Theorem (B)** (`F2e2e.Theorem_B_statistical`): for the Spec's Algorithm 2, the size
conjuncts (B-NUM, `V2.v2par_size_conjuncts`) and the guarantee with internal caps
(`V2.alg2V2_guarantee`). -/
theorem theorem_B_statistical_proof : F2e2e.Theorem_B_statistical := by
  obtain ⟨C, hC, h⟩ := V2.v2par_size_conjuncts
  exact ⟨C, hC, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 =>
    ⟨(h M J R aReq ξReq ha0 ha1 hξ0 hξ1).1, (h M J R aReq ξReq ha0 ha1 hξ0 hξ1).2,
      V2.alg2V2_guarantee M J R ha0 ha1 hξ0 hξ1⟩⟩

end F2e2e.B
