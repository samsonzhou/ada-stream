import F2e2e.B.NumericsN

/-!
# Part II numerics (B-NUM), part 5: the numeric certificates of Section 3

Certificates used by the proof of Theorem `R:thm:validation_ada` (`parts/partII.tex` L973–1054) and by
Lemmas `R:lem:sec3_sampler`, `R:lem:sec3_potential_contraction` (paper map II_b, §4), for B-ARCH's
paper-form parameters `alg2*` (`F2e2e/B/Params.lean`). All hold for every `aReq, ξReq` (the dyadic
`a`, `ξ_A` are in `(0, 1]`), so no hypotheses on `aReq, ξReq` are needed.

* `h_A` (`R:eq:sec3_hA_def`): `alg2HA_pos`, `alg2HA_le_bound`, `half_bound_lt_alg2HA`,
  `alg2HA_le_first`, `alg2HA_le_inv_nBlock` (`h_A ≤ 1/(2^20 n_j)`), `one_div_alg2HA`
  (`1/h_A = 2^{q_A}`), `alg2HA_mul_le_h` (`2^20 χ h_A ≤ h`), `alg2HA_le_a` (`h_A ≤ a/2^30`).
* One-phase privacy (P2, L986–1002): `deltaPrime_le` (`Δ'_j = h_A⌈(8/n_j)/h_A⌉ ≤ 9/n_j`),
  `le_deltaPrime`, `numRho` (`ρ_j`), `first_term_le_alg2NBlock`,
  `two_mul_div_bInt_le_numRho` (`2Δ'_j/b_int ≤ 2304χ/(n_j h) ≤ ρ_j`),
  `two_mul_div_bOut_le_numRho` (outer, `9216·64 ≤ 2^20`), `div_bNum_le_numRho` (numerical, `576·64 ≤ 2^20`).
* Composition (P3, P4): `rho_mul_exp_sub_one_le` (`ρ(e^ρ−1) ≤ 2ρ²`), `numRho_le_one`,
  `advComp_budget_lt` (`2C_jρ_j² + ρ_j√(2C_jχ) < ϑ_j/12`), `hybrid_delta_le`
  (`e^{-χ}(1+e^{ϑ_j/12}+e^{ϑ_j/6}) ≤ δ/16`), `alg2Q_mul_alg2Zeta` (`Qζ = δ/1000`),
  `coupling_delta_le` (`δ/16 + (1+e^{ϑ_j/4})δ/1000 ≤ δ`).
* Transfer (P5): `alg2Vartheta_pos`, `alg2Vartheta_le_one`, `alg2Vartheta_le_half`,
  `exp_two_mul_alg2Vartheta_lt_eight`, `alg2P_add_one_mul_alg2XiJ` (`(p+1)ξ_j = ξ_A/8`),
  `log_le_alg2Chi` (`ln((k+2)/ξ_j) ≤ χ` for `k ≤ M+R`), `transfer_condition`
  (`72 e^{2ϑ_j} h^{-2} ln((k+2)/ξ_j) ≤ n_j`).
* Noise tails (P5): `int_tail_ratio` (`h/(c b_int + h_A) ≥ 31χ`, `c ≤ 4`), `out_tail_ratio`,
  `num_tail_ratio` (`≥ 8χ`), `tail_total_lt` (`Q·2e^{-8χ} < ξ_A/100`).
* Accuracy (P5): `accept_budget`, `reject_budget`, `numerical_budget`, `failure_budget`.
* Lemma 3.5: `sum_four_pow_mul_alg2Theta_sq` (`∑_{j<p} 4^jθ_j² = 1`), `alg2Lambda_eq`,
  `interior_drop_identity`, `sqrt_two_mul_alg2Theta_p`, `anchor_drop_identity`, `anchor_drop_lt`,
  `lt_alg2Tmax_of_weighted`.
* Sampler (Lemma 3.2): `sampler_trunc_le` (`2ϱ^{K_s} ≤ ζ/8`), `sampler_coin_lt`
  (`2K_s 2^{-r_s} < ζ/16`).
* Counting (P1): `draws_lt_alg2Q`.
-/

namespace F2e2e.B

/-! ### Small analytic helpers -/

/-- `e^{-n} ≤ 2^{-n}`. -/
theorem exp_neg_natCast_le (n : ℕ) : Real.exp (-(n : ℝ)) ≤ ((2 : ℝ) ^ n)⁻¹ := by
  rw [Real.exp_neg]
  apply inv_anti₀ (by positivity)
  have h := Real.exp_one_gt_d9
  have h2 : (2 : ℝ) ≤ Real.exp 1 := by linarith
  calc (2 : ℝ) ^ n ≤ Real.exp 1 ^ n := pow_le_pow_left₀ (by norm_num) h2 n
    _ = Real.exp (n : ℝ) := by rw [← Real.exp_nat_mul, mul_one]

/-- `e^x ≤ 1 + x + x²` for `|x| ≤ 1`. -/
theorem exp_le_one_add_add_sq {x : ℝ} (h0 : -1 ≤ x) (h1 : x ≤ 1) :
    Real.exp x ≤ 1 + x + x ^ 2 := by
  have h := Real.abs_exp_sub_one_sub_id_le (x := x) (abs_le.mpr ⟨h0, h1⟩)
  have h2 := (abs_le.mp h).2
  linarith

/-! ### Blocks, `χ`, `ϑ_j` -/

/-- Every block is nonempty: `n_j ≥ 1`. -/
theorem one_le_alg2NBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    1 ≤ alg2NBlock M J R aReq ξReq j := by
  unfold alg2NBlock
  apply Nat.one_le_iff_ne_zero.mpr
  apply (Nat.ceil_pos.mpr _).ne'
  have hh := alg2H_pos aReq
  have hX : (0 : ℝ) < alg2Chi M J R aReq ξReq := by
    have := one_le_alg2Chi M J R aReq ξReq
    exact_mod_cast this
  have h2 : (0 : ℝ) < (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 := by
    positivity
  have h1 : (0 : ℝ) ≤ (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
      (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) /
        alg2H aReq := by positivity
  linarith

/-- `n_j ≤ max_j n_j` for `j ≤ p`. -/
theorem alg2NBlock_le_alg2MaxN (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    alg2NBlock M J R aReq ξReq j ≤ alg2MaxN M J R aReq ξReq :=
  Finset.le_sup (f := alg2NBlock M J R aReq ξReq) (Finset.mem_range.mpr (Nat.lt_succ_of_le hj))

/-- `max_j n_j ≥ 1`. -/
theorem one_le_alg2MaxN (M J R : ℕ) (aReq ξReq : ℝ) : 1 ≤ alg2MaxN M J R aReq ξReq :=
  le_trans (one_le_alg2NBlock M J R aReq ξReq 0) (alg2NBlock_le_alg2MaxN M J R aReq ξReq (Nat.zero_le _))

theorem alg2Chi_pos_real (M J R : ℕ) (aReq ξReq : ℝ) : (0 : ℝ) < alg2Chi M J R aReq ξReq := by
  have := one_le_alg2Chi M J R aReq ξReq
  exact_mod_cast this

theorem one_le_alg2Chi_real (M J R : ℕ) (aReq ξReq : ℝ) : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := by
  exact_mod_cast one_le_alg2Chi M J R aReq ξReq

theorem one_le_alg2D_real (aReq : ℝ) (j : ℕ) : (1 : ℝ) ≤ alg2D aReq j := by
  exact_mod_cast one_le_alg2D aReq j

theorem alg2Vartheta_pos (aReq : ℝ) (j : ℕ) : 0 < alg2Vartheta aReq j := by
  have := one_le_alg2D_real aReq j
  unfold alg2Vartheta
  positivity

theorem alg2Vartheta_le_one (aReq : ℝ) (j : ℕ) : alg2Vartheta aReq j ≤ 1 := by
  have := one_le_alg2D_real aReq j
  unfold alg2Vartheta
  rw [div_le_one (by linarith)]
  exact this

/-- `ϑ_j ≤ 1/2` for `j < p` (`d_j = ⌈√(p4^j)⌉ ≥ 2`). -/
theorem alg2Vartheta_le_half {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    alg2Vartheta aReq j ≤ 1 / 2 := by
  have hd : 2 ≤ alg2D aReq j := by
    rw [alg2D_of_lt hj]
    have h1 : (1 : ℝ) < Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j) := by
      rw [Real.lt_sqrt (by norm_num)]
      have hp := two_le_alg2P_real aReq
      have h4 : (1 : ℝ) ≤ 4 ^ j := one_le_pow₀ (by norm_num)
      nlinarith
    have h2 : 1 < ⌈Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j)⌉₊ :=
      Nat.lt_ceil.mpr (by rw [Nat.cast_one]; exact h1)
    omega
  have hd' : (2 : ℝ) ≤ alg2D aReq j := by exact_mod_cast hd
  unfold alg2Vartheta
  rw [div_le_div_iff₀ (by linarith) (by norm_num)]
  linarith

/-- `e^{2ϑ_j} < 8` (P5, L1034). -/
theorem exp_two_mul_alg2Vartheta_lt_eight (aReq : ℝ) (j : ℕ) :
    Real.exp (2 * alg2Vartheta aReq j) < 8 := by
  have h1 := alg2Vartheta_le_one aReq j
  have h2 : Real.exp (2 * alg2Vartheta aReq j) ≤ Real.exp 2 := Real.exp_le_exp.mpr (by linarith)
  have h3 : Real.exp 2 = Real.exp 1 ^ 2 := by rw [← Real.exp_nat_mul]; norm_num
  have h4 := Real.exp_one_lt_d9
  have h5 : Real.exp 1 ^ 2 < 8 := by nlinarith [Real.exp_pos 1]
  linarith

/-! ### `h_A` (`R:eq:sec3_hA_def`, L693–696) -/

theorem alg2HABound_first_pos (M J R : ℕ) (aReq ξReq : ℝ) :
    0 < alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ)) := by
  have hh := alg2H_pos aReq
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  positivity

theorem alg2HABound_pos (M J R : ℕ) (aReq ξReq : ℝ) : 0 < alg2HABound M J R aReq ξReq := by
  unfold alg2HABound
  have h2 : (0 : ℝ) < alg2MaxN M J R aReq ξReq := by
    have := one_le_alg2MaxN M J R aReq ξReq
    exact_mod_cast this
  exact lt_min (alg2HABound_first_pos M J R aReq ξReq) (by positivity)

theorem alg2HABound_le_first (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HABound M J R aReq ξReq ≤
      alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ)) :=
  min_le_left _ _

theorem alg2HABound_le_second (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HABound M J R aReq ξReq ≤ 1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)) :=
  min_le_right _ _

theorem alg2HABound_lt_one (M J R : ℕ) (aReq ξReq : ℝ) : alg2HABound M J R aReq ξReq < 1 := by
  refine lt_of_le_of_lt (alg2HABound_le_first M J R aReq ξReq) ?_
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have hχ := one_le_alg2Chi_real M J R aReq ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  rw [div_lt_one (by positivity)]
  nlinarith

theorem alg2HA_pos (M J R : ℕ) (aReq ξReq : ℝ) : 0 < alg2HA M J R aReq ξReq := by
  rw [alg2HA_eq_dyadicDown]
  exact dyadicDown_pos _

theorem alg2HA_le_bound (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HA M J R aReq ξReq ≤ alg2HABound M J R aReq ξReq := by
  rw [alg2HA_eq_dyadicDown]
  exact dyadicDown_le (alg2HABound_pos M J R aReq ξReq)

/-- `h_A` is the largest power of two below the bound: `bound/2 < h_A`. -/
theorem half_bound_lt_alg2HA (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HABound M J R aReq ξReq / 2 < alg2HA M J R aReq ξReq := by
  rw [alg2HA_eq_dyadicDown]
  exact half_lt_dyadicDown (alg2HABound_pos M J R aReq ξReq) (alg2HABound_lt_one M J R aReq ξReq)

/-- `h_A ≤ h/(2^20 (p+1) χ)`. -/
theorem alg2HA_le_first (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HA M J R aReq ξReq ≤
      alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ)) :=
  (alg2HA_le_bound M J R aReq ξReq).trans (alg2HABound_le_first M J R aReq ξReq)

/-- `h_A ≤ 1/(2^20 n_j)` for every block `j ≤ p`. -/
theorem alg2HA_le_inv_nBlock (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    alg2HA M J R aReq ξReq ≤ 1 / ((2 : ℝ) ^ 20 * (alg2NBlock M J R aReq ξReq j : ℝ)) := by
  refine (alg2HA_le_bound M J R aReq ξReq).trans
    ((alg2HABound_le_second M J R aReq ξReq).trans ?_)
  have hn : (1 : ℝ) ≤ alg2NBlock M J R aReq ξReq j := by
    exact_mod_cast one_le_alg2NBlock M J R aReq ξReq j
  have hle : (alg2NBlock M J R aReq ξReq j : ℝ) ≤ alg2MaxN M J R aReq ξReq := by
    exact_mod_cast alg2NBlock_le_alg2MaxN M J R aReq ξReq hj
  apply one_div_le_one_div_of_le (by positivity)
  gcongr

/-- `1/h_A = 2^{q_A}` (an integer). -/
theorem one_div_alg2HA (M J R : ℕ) (aReq ξReq : ℝ) :
    1 / alg2HA M J R aReq ξReq = (2 : ℝ) ^ alg2HAExp M J R aReq ξReq := by
  unfold alg2HA
  rw [one_div_pow, one_div_one_div]

/-- `2^20 χ h_A ≤ h`. -/
theorem alg2HA_mul_le_h (M J R : ℕ) (aReq ξReq : ℝ) :
    (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq ≤ alg2H aReq := by
  have h := alg2HA_le_first M J R aReq ξReq
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hA := alg2HA_pos M J R aReq ξReq
  rw [le_div_iff₀ (by positivity)] at h
  have e : alg2HA M J R aReq ξReq * ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
      (alg2Chi M J R aReq ξReq : ℝ)) = (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) *
        alg2HA M J R aReq ξReq + (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) *
        alg2HA M J R aReq ξReq * (alg2P aReq : ℝ) := by ring
  have h0 : 0 ≤ (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq *
      (alg2P aReq : ℝ) := by positivity
  linarith

/-- `h_A ≤ a/2^30`. -/
theorem alg2HA_le_a (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HA M J R aReq ξReq ≤ alg2A aReq / 2 ^ 30 := by
  have h := alg2HA_mul_le_h M J R aReq ξReq
  have hχ := one_le_alg2Chi_real M J R aReq ξReq
  have hA := alg2HA_pos M J R aReq ξReq
  have hha : alg2H aReq ≤ alg2A aReq / 1024 := valH_le (alg2A_pos aReq)
  have : (2 : ℝ) ^ 20 * alg2HA M J R aReq ξReq ≤ alg2H aReq := by nlinarith
  rw [le_div_iff₀ (by norm_num)]
  have e : (2 : ℝ) ^ 30 = 2 ^ 20 * 1024 := by norm_num
  rw [e]
  nlinarith

/-! ### One-phase privacy (proof of Theorem `R:thm:validation_ada`, P2, L986–1002) -/

/-- `Δ'_j = h_A⌈(8/n_j)/h_A⌉ ≤ 9/n_j` (L988). -/
theorem deltaPrime_le (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    alg2HA M J R aReq ξReq *
        (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) ≤
      9 / (alg2NBlock M J R aReq ξReq j : ℝ) := by
  have hn : (1 : ℝ) ≤ alg2NBlock M J R aReq ξReq j := by
    exact_mod_cast one_le_alg2NBlock M J R aReq ξReq j
  have hA := alg2HA_pos M J R aReq ξReq
  have hAn := alg2HA_le_inv_nBlock M J R aReq ξReq hj
  set hA' := alg2HA M J R aReq ξReq with hA'_def
  set n := (alg2NBlock M J R aReq ξReq j : ℝ) with hn_def
  have hc := Nat.ceil_lt_add_one (by positivity : (0 : ℝ) ≤ 8 / n / hA')
  have h1 : hA' * (⌈8 / n / hA'⌉₊ : ℝ) ≤ hA' * (8 / n / hA' + 1) := by
    apply mul_le_mul_of_nonneg_left hc.le hA.le
  have h2 : hA' * (8 / n / hA' + 1) = 8 / n + hA' := by
    field_simp
  have h3 : 1 / ((2 : ℝ) ^ 20 * n) ≤ 1 / n := by
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith
  have h4 : 8 / n + 1 / n = 9 / n := by ring
  linarith

/-- `8/n_j ≤ Δ'_j`. -/
theorem le_deltaPrime (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    8 / (alg2NBlock M J R aReq ξReq j : ℝ) ≤
      alg2HA M J R aReq ξReq *
        (⌈8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq⌉₊ : ℝ) := by
  have hA := alg2HA_pos M J R aReq ξReq
  have h := Nat.le_ceil (8 / (alg2NBlock M J R aReq ξReq j : ℝ) / alg2HA M J R aReq ξReq)
  rw [div_le_iff₀ hA] at h
  linarith

/-- The per-phase privacy `ρ_j = 1/(64 d_j ⌈√(C_jχ)⌉)` (`R:eq:sec3_rho_j`). -/
noncomputable def numRho (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) : ℝ :=
  1 / (64 * (alg2D aReq j : ℝ) *
    (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ))

/-- `⌈√(C_jχ)⌉ ≥ 1` and `(⌈√(C_jχ)⌉)² ≥ C_jχ` for `j ≤ p`. -/
theorem ceil_sqrt_facts (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    1 ≤ (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) ∧
      (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) ≤
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) ^ 2 := by
  have hC : (1 : ℝ) ≤ alg2C J R aReq j := by exact_mod_cast one_le_alg2C J R aReq hj
  have hX := one_le_alg2Chi_real M J R aReq ξReq
  have hCX : 1 ≤ (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ) := by nlinarith
  have hs1 : 1 ≤ Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) := by
    rw [Real.one_le_sqrt]
    exact hCX
  have hceil := Nat.le_ceil (Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)))
  refine ⟨hs1.trans hceil, ?_⟩
  have hsq := Real.sq_sqrt (show (0 : ℝ) ≤ (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)
    by positivity)
  calc (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)
      = Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) ^ 2 := hsq.symm
    _ ≤ _ := pow_le_pow_left₀ (Real.sqrt_nonneg _) hceil 2

theorem numRho_pos (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    0 < numRho M J R aReq ξReq j := by
  have hc := (ceil_sqrt_facts M J R aReq ξReq hj).1
  have hd := one_le_alg2D_real aReq j
  unfold numRho
  positivity

theorem numRho_le_one (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    numRho M J R aReq ξReq j ≤ 1 := by
  have hc := (ceil_sqrt_facts M J R aReq ξReq hj).1
  have hd := one_le_alg2D_real aReq j
  unfold numRho
  rw [div_le_one (by positivity)]
  nlinarith

/-- The first term of `n_j`: `2^20 χ d_j ⌈√(C_jχ)⌉/h ≤ n_j`. -/
theorem first_term_le_alg2NBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) / alg2H aReq ≤
      (alg2NBlock M J R aReq ξReq j : ℝ) := by
  have hh := alg2H_pos aReq
  have h2 : (0 : ℝ) ≤ (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 := by
    positivity
  unfold alg2NBlock
  have := Nat.le_ceil ((2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) / alg2H aReq +
      (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2)
  linarith

/-- The second term of `n_j`: `2^12 χ/h² ≤ n_j`. -/
theorem second_term_le_alg2NBlock (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 ≤
      (alg2NBlock M J R aReq ξReq j : ℝ) := by
  have hh := alg2H_pos aReq
  have h1 : (0 : ℝ) ≤ (2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
      (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) /
        alg2H aReq := by positivity
  unfold alg2NBlock
  have := Nat.le_ceil ((2 : ℝ) ^ 20 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
        (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ))⌉₊ : ℝ) / alg2H aReq +
      (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2)
  linarith

/-- Core of the privacy multipliers: if `K·64·9 ≤ 2^20` and `Δ ≤ 9/n_j`, then `KχΔ/h ≤ ρ_j`. -/
theorem mult_le_numRho (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) {K Δ : ℝ}
    (hK0 : 0 ≤ K) (hK : K * 64 * 9 ≤ 2 ^ 20) (hΔ0 : 0 ≤ Δ)
    (hΔ : Δ ≤ 9 / (alg2NBlock M J R aReq ξReq j : ℝ)) :
    K * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2H aReq ≤ numRho M J R aReq ξReq j := by
  have hfirst := first_term_le_alg2NBlock M J R aReq ξReq j
  have hc := (ceil_sqrt_facts M J R aReq ξReq hj).1
  have hd := one_le_alg2D_real aReq j
  have hX := one_le_alg2Chi_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hn : (1 : ℝ) ≤ alg2NBlock M J R aReq ξReq j := by
    exact_mod_cast one_le_alg2NBlock M J R aReq ξReq j
  set X := (alg2Chi M J R aReq ξReq : ℝ)
  set D := (alg2D aReq j : ℝ)
  set c := (⌈Real.sqrt ((alg2C J R aReq j : ℝ) * X)⌉₊ : ℝ)
  set n := (alg2NBlock M J R aReq ξReq j : ℝ)
  set h := alg2H aReq
  unfold numRho
  change K * X * Δ / h ≤ 1 / (64 * D * c)
  have hΔn : Δ * n ≤ 9 := by
    rw [le_div_iff₀ (by linarith)] at hΔ
    exact hΔ
  have hnh : 2 ^ 20 * X * D * c ≤ n * h := by
    rw [div_le_iff₀ hh] at hfirst
    exact hfirst
  rw [div_le_div_iff₀ hh (by positivity)]
  -- `K X Δ (64 D c) ≤ h`
  have step1 : K * X * Δ * (64 * D * c) = 64 * K * Δ * (X * D * c) := by ring
  have step2 : 64 * K * Δ * (X * D * c) ≤ 64 * K * Δ * (n * h / 2 ^ 20) := by
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    rw [le_div_iff₀ (by norm_num)]
    linarith
  have step3 : 64 * K * Δ * (n * h / 2 ^ 20) = 64 * K * (Δ * n) * h / 2 ^ 20 := by ring
  have step4 : 64 * K * (Δ * n) * h ≤ 64 * K * 9 * h := by
    apply mul_le_mul_of_nonneg_right _ hh.le
    apply mul_le_mul_of_nonneg_left hΔn (by positivity)
  have step5 : 64 * K * 9 * h ≤ 2 ^ 20 * h := by nlinarith
  rw [step1]
  calc 64 * K * Δ * (X * D * c) ≤ 64 * K * Δ * (n * h / 2 ^ 20) := step2
    _ = 64 * K * (Δ * n) * h / 2 ^ 20 := step3
    _ ≤ 2 ^ 20 * h / 2 ^ 20 := by
        apply div_le_div_of_nonneg_right _ (by norm_num)
        linarith
    _ = 1 * h := by ring

/-- Internal streams: `2Δ/b_int ≤ 2304χ/(n_j h) ≤ ρ_j` for any shift `0 ≤ Δ ≤ 9/n_j` (L1002). -/
theorem two_mul_div_bInt_le_numRho (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq)
    {Δ : ℝ} (hΔ0 : 0 ≤ Δ) (hΔ : Δ ≤ 9 / (alg2NBlock M J R aReq ξReq j : ℝ)) :
    2 * Δ / alg2BInt M J R aReq ξReq ≤ numRho M J R aReq ξReq j := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have e : 2 * Δ / alg2BInt M J R aReq ξReq = 256 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2H aReq := by
    unfold alg2BInt
    field_simp
    ring
  rw [e]
  exact mult_le_numRho M J R aReq ξReq hj (by norm_num) (by norm_num) hΔ0 hΔ

/-- The intermediate form `2Δ'_j/b_int ≤ 2304χ/(n_j h)`. -/
theorem two_mul_div_bInt_le (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) {Δ : ℝ}
    (hΔ : Δ ≤ 9 / (alg2NBlock M J R aReq ξReq j : ℝ)) :
    2 * Δ / alg2BInt M J R aReq ξReq ≤
      2304 * (alg2Chi M J R aReq ξReq : ℝ) / ((alg2NBlock M J R aReq ξReq j : ℝ) * alg2H aReq) := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hn : (1 : ℝ) ≤ alg2NBlock M J R aReq ξReq j := by
    exact_mod_cast one_le_alg2NBlock M J R aReq ξReq j
  have e : 2 * Δ / alg2BInt M J R aReq ξReq = 256 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2H aReq := by
    unfold alg2BInt
    field_simp
    ring
  rw [e]
  have e2 : 2304 * (alg2Chi M J R aReq ξReq : ℝ) / ((alg2NBlock M J R aReq ξReq j : ℝ) * alg2H aReq) =
      256 * (alg2Chi M J R aReq ξReq : ℝ) * (9 / (alg2NBlock M J R aReq ξReq j : ℝ)) / alg2H aReq := by
    field_simp
    ring
  rw [e2]
  apply div_le_div_of_nonneg_right _ hh.le
  apply mul_le_mul_of_nonneg_left hΔ (by positivity)

/-- Outer stream (block 0): `2Δ/b_out ≤ 9216χ/(n_0 a) ≤ ρ_0` (`9216·64 ≤ 2^20`, `h ≤ a`). -/
theorem two_mul_div_bOut_le_numRho (M J R : ℕ) (aReq ξReq : ℝ) {Δ : ℝ} (hΔ0 : 0 ≤ Δ)
    (hΔ : Δ ≤ 9 / (alg2NBlock M J R aReq ξReq 0 : ℝ)) :
    2 * Δ / alg2BOut M J R aReq ξReq ≤ numRho M J R aReq ξReq 0 := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have ha := alg2A_pos aReq
  have hha : alg2H aReq ≤ alg2A aReq := by
    have := valH_le (alg2A_pos aReq)
    change alg2H aReq ≤ alg2A aReq / 1024 at this
    linarith
  have e : 2 * Δ / alg2BOut M J R aReq ξReq = 1024 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2A aReq := by
    unfold alg2BOut
    field_simp
    ring
  rw [e]
  have h1 : 1024 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2A aReq ≤
      1024 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2H aReq :=
    div_le_div_of_nonneg_left (by positivity) hh hha
  exact h1.trans (mult_le_numRho M J R aReq ξReq (Nat.zero_le _) (by norm_num) (by norm_num) hΔ0 hΔ)

/-- Numerical releases (block 0): `Δ/b_num ≤ 576χ/(n_0 a) ≤ ρ_0` (`576·64 ≤ 2^20`). -/
theorem div_bNum_le_numRho (M J R : ℕ) (aReq ξReq : ℝ) {Δ : ℝ} (hΔ0 : 0 ≤ Δ)
    (hΔ : Δ ≤ 9 / (alg2NBlock M J R aReq ξReq 0 : ℝ)) :
    Δ / alg2BNum M J R aReq ξReq ≤ numRho M J R aReq ξReq 0 := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have ha := alg2A_pos aReq
  have hha : alg2H aReq ≤ alg2A aReq := by
    have := valH_le (alg2A_pos aReq)
    change alg2H aReq ≤ alg2A aReq / 1024 at this
    linarith
  have e : Δ / alg2BNum M J R aReq ξReq = 64 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2A aReq := by
    unfold alg2BNum
    field_simp
  rw [e]
  have h1 : 64 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2A aReq ≤
      64 * (alg2Chi M J R aReq ξReq : ℝ) * Δ / alg2H aReq :=
    div_le_div_of_nonneg_left (by positivity) hh hha
  exact h1.trans (mult_le_numRho M J R aReq ξReq (Nat.zero_le _) (by norm_num) (by norm_num) hΔ0 hΔ)

/-! ### Composition (P3, P4; L1004–1030) -/

/-- `ρ(e^ρ − 1) ≤ 2ρ²` for `0 ≤ ρ ≤ 1` (L1014). -/
theorem rho_mul_exp_sub_one_le {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ ≤ 1) :
    ρ * (Real.exp ρ - 1) ≤ 2 * ρ ^ 2 := by
  have h := exp_le_one_add_add_sq (x := ρ) (by linarith) h1
  have h2 : Real.exp ρ - 1 ≤ 2 * ρ := by nlinarith
  nlinarith

/-- `2C_jρ_j² + ρ_j√(2C_jχ) < ϑ_j/12` (L1018). -/
theorem advComp_budget_lt (M J R : ℕ) (aReq ξReq : ℝ) {j : ℕ} (hj : j ≤ alg2P aReq) :
    2 * (alg2C J R aReq j : ℝ) * numRho M J R aReq ξReq j ^ 2 +
        numRho M J R aReq ξReq j *
          Real.sqrt (2 * (alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) <
      alg2Vartheta aReq j / 12 := by
  obtain ⟨hc1, hcsq⟩ := ceil_sqrt_facts M J R aReq ξReq hj
  have hd := one_le_alg2D_real aReq j
  have hX := one_le_alg2Chi_real M J R aReq ξReq
  have hC : (1 : ℝ) ≤ alg2C J R aReq j := by exact_mod_cast one_le_alg2C J R aReq hj
  set X := (alg2Chi M J R aReq ξReq : ℝ)
  set D := (alg2D aReq j : ℝ)
  set C := (alg2C J R aReq j : ℝ)
  set c := (⌈Real.sqrt (C * X)⌉₊ : ℝ)
  unfold numRho alg2Vartheta
  change 2 * C * (1 / (64 * D * c)) ^ 2 + 1 / (64 * D * c) * Real.sqrt (2 * C * X) < 1 / D / 12
  -- `√(2CX) ≤ (3/2) c`
  have hs : Real.sqrt (2 * C * X) ≤ 3 / 2 * c := by
    rw [Real.sqrt_le_left (by positivity)]
    nlinarith
  have t1 : 2 * C * (1 / (64 * D * c)) ^ 2 ≤ 1 / (2048 * D) := by
    rw [div_pow, one_pow, ← mul_div_assoc, mul_one, div_le_div_iff₀ (by positivity) (by positivity)]
    -- `2C · 2048 D ≤ (64Dc)²`
    have h1 : C ≤ c ^ 2 := by nlinarith
    have hDD : D ≤ D ^ 2 := by nlinarith
    have h2 : D * C ≤ D ^ 2 * c ^ 2 := by
      calc D * C ≤ D * c ^ 2 := by gcongr
        _ ≤ D ^ 2 * c ^ 2 := by gcongr
    calc 2 * C * (2048 * D) = 4096 * (D * C) := by ring
      _ ≤ 4096 * (D ^ 2 * c ^ 2) := by linarith
      _ = 1 * (64 * D * c) ^ 2 := by ring
  have t2 : 1 / (64 * D * c) * Real.sqrt (2 * C * X) ≤ 3 / 2 / (64 * D) := by
    rw [one_div_mul_eq_div, div_le_div_iff₀ (by positivity) (by positivity)]
    nlinarith
  have t3 : 1 / (2048 * D) + 3 / 2 / (64 * D) < 1 / D / 12 := by
    rw [div_add_div _ _ (by positivity) (by positivity), div_div,
      div_lt_div_iff₀ (by positivity) (by positivity)]
    nlinarith
  linarith

/-- `e^{-χ}(1 + e^{ϑ_j/12} + e^{ϑ_j/6}) ≤ δ/16` (`R:eq:sec3_hybrid_chain`, L1022). -/
theorem hybrid_delta_le (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) :
    Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) *
        (1 + Real.exp (alg2Vartheta aReq j / 12) + Real.exp (alg2Vartheta aReq j / 6)) ≤
      alg2Delta aReq ξReq / 16 := by
  have hθ0 := (alg2Vartheta_pos aReq j).le
  have hθ1 := alg2Vartheta_le_one aReq j
  have e1 := exp_le_one_add_add_sq (x := alg2Vartheta aReq j / 12) (by linarith) (by linarith)
  have e2 := exp_le_one_add_add_sq (x := alg2Vartheta aReq j / 6) (by linarith) (by linarith)
  have hsum : 1 + Real.exp (alg2Vartheta aReq j / 12) + Real.exp (alg2Vartheta aReq j / 6) ≤
      33 / 10 := by nlinarith
  have hexp := exp_neg_natCast_le (alg2Chi M J R aReq ξReq)
  have hinv := inv_two_pow_valChi_le M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change ((2 : ℝ) ^ alg2Chi M J R aReq ξReq)⁻¹ ≤
    alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    at hinv
  have hh := alg2H_pos aReq
  have hξ := alg2XiA_pos ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hQ : (600 : ℝ) ≤ alg2Q M J R aReq := by
    exact_mod_cast six_hundred_le_valQ M J R (alg2A_pos aReq)
  have hpos : 0 ≤ 1 + Real.exp (alg2Vartheta aReq j / 12) + Real.exp (alg2Vartheta aReq j / 6) := by
    positivity
  have hδ : alg2Delta aReq ξReq / 16 =
      alg2H aReq * alg2XiA ξReq / (3072 * ((alg2P aReq : ℝ) + 1)) := by
    unfold alg2Delta alg2XiJ
    field_simp
    ring
  rw [hδ]
  have hy : alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) *
      (33 / 10) ≤ alg2H aReq * alg2XiA ξReq / (3072 * ((alg2P aReq : ℝ) + 1)) := by
    rw [div_mul_eq_mul_div, div_le_div_iff₀ (by positivity) (by positivity)]
    have hhx : 0 < alg2H aReq * alg2XiA ξReq := by positivity
    have : (33 / 10 : ℝ) * (3072 * ((alg2P aReq : ℝ) + 1)) ≤
        2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) := by nlinarith
    nlinarith
  calc Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) *
        (1 + Real.exp (alg2Vartheta aReq j / 12) + Real.exp (alg2Vartheta aReq j / 6))
      ≤ alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) *
          (33 / 10) := by
        apply mul_le_mul (hexp.trans hinv) hsum hpos (by positivity)
    _ ≤ _ := hy

theorem alg2Q_pos_real (M J R : ℕ) (aReq : ℝ) : (0 : ℝ) < alg2Q M J R aReq := by
  exact_mod_cast valQ_pos M J R (alg2A_pos aReq)

/-- `Qζ = δ/1000` (L1026). -/
theorem alg2Q_mul_alg2Zeta (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2Q M J R aReq : ℝ) * alg2Zeta M J R aReq ξReq = alg2Delta aReq ξReq / 1000 := by
  have hQ := alg2Q_pos_real M J R aReq
  unfold alg2Zeta
  field_simp

theorem alg2Delta_pos (aReq ξReq : ℝ) : 0 < alg2Delta aReq ξReq := by
  have hh := alg2H_pos aReq
  have hξ := alg2XiA_pos ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  unfold alg2Delta alg2XiJ
  positivity

/-- `δ/16 + (1 + e^{ϑ_j/4})δ/1000 ≤ δ` (L1028–1030). -/
theorem coupling_delta_le (aReq ξReq : ℝ) (j : ℕ) :
    alg2Delta aReq ξReq / 16 + (1 + Real.exp (alg2Vartheta aReq j / 4)) * alg2Delta aReq ξReq / 1000 ≤
      alg2Delta aReq ξReq := by
  have hθ0 := (alg2Vartheta_pos aReq j).le
  have hθ1 := alg2Vartheta_le_one aReq j
  have e1 := exp_le_one_add_add_sq (x := alg2Vartheta aReq j / 4) (by linarith) (by linarith)
  have hδ := alg2Delta_pos aReq ξReq
  have : Real.exp (alg2Vartheta aReq j / 4) ≤ 2 := by nlinarith
  nlinarith

/-! ### Transfer via Theorem `R:thm:L1_Posterior_Bhatia_Davis_Comparator` (P5, L1034) -/

theorem alg2XiJ_pos (aReq ξReq : ℝ) : 0 < alg2XiJ aReq ξReq := by
  have hξ := alg2XiA_pos ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  unfold alg2XiJ
  positivity

theorem alg2XiJ_lt_one (aReq ξReq : ℝ) : alg2XiJ aReq ξReq < 1 := by
  have hξ := alg2XiA_pos ξReq
  have hξ1 := alg2XiA_le_one ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  unfold alg2XiJ
  rw [div_lt_one (by positivity)]
  linarith

/-- `(p+1)ξ_j = ξ_A/8` (the union bound over the `p+1` blocks). -/
theorem alg2P_add_one_mul_alg2XiJ (aReq ξReq : ℝ) :
    ((alg2P aReq : ℝ) + 1) * alg2XiJ aReq ξReq = alg2XiA ξReq / 8 := by
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  unfold alg2XiJ
  field_simp

/-- `δ = hξ_j/24` (so `δ ≤ hξ_j/24`, the second condition of `R:eq:sec2_L1_scales`). -/
theorem alg2Delta_eq (aReq ξReq : ℝ) :
    alg2Delta aReq ξReq = alg2H aReq * alg2XiJ aReq ξReq / 24 := rfl

/-- `ln((k+2)/ξ_j) ≤ χ` for `k ≤ M + R` ("all required logarithms are at most `χ`", L1034). -/
theorem log_le_alg2Chi (M J R : ℕ) (aReq ξReq : ℝ) {k : ℕ} (hk : k ≤ M + R) :
    Real.log (((k : ℝ) + 2) / alg2XiJ aReq ξReq) ≤ alg2Chi M J R aReq ξReq := by
  have hξj := alg2XiJ_pos aReq ξReq
  have hξ := alg2XiA_pos ξReq
  have hξ1 := alg2XiA_le_one ξReq
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have harg := chiArg_le_two_pow_valChi M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change chiArg M J R (alg2A aReq) (alg2XiA ξReq) ≤ 2 ^ alg2Chi M J R aReq ξReq at harg
  -- `(k+2)/ξ_j ≤ arg`
  have hQ : ((M : ℝ) + R + 2) ≤ alg2Q M J R aReq := by
    have hc := valQ_cast M J R (alg2A aReq)
    change (alg2Q M J R aReq : ℝ) = _ at hc
    have hs : (0 : ℝ) ≤ ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ) :=
      Finset.sum_nonneg (fun _ _ => Nat.cast_nonneg _)
    have hp' : (0 : ℝ) ≤ valP (alg2A aReq) := Nat.cast_nonneg _
    rw [hc]
    have hJ : (0 : ℝ) ≤ J := Nat.cast_nonneg _
    nlinarith
  have hk' : (k : ℝ) ≤ (M : ℝ) + R := by exact_mod_cast hk
  have hle : ((k : ℝ) + 2) / alg2XiJ aReq ξReq ≤ chiArg M J R (alg2A aReq) (alg2XiA ξReq) := by
    unfold alg2XiJ chiArg
    change ((k : ℝ) + 2) / (alg2XiA ξReq / (8 * ((alg2P aReq : ℝ) + 1))) ≤
      2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) / (alg2H aReq * alg2XiA ξReq)
    rw [div_div_eq_mul_div, div_le_div_iff₀ hξ (by positivity)]
    have h1 : ((k : ℝ) + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * (alg2H aReq * alg2XiA ξReq) ≤
        ((M : ℝ) + R + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * alg2XiA ξReq := by
      have hk2 : ((k : ℝ) + 2) * alg2H aReq ≤ (M : ℝ) + R + 2 := by nlinarith
      calc ((k : ℝ) + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * (alg2H aReq * alg2XiA ξReq)
          = (((k : ℝ) + 2) * alg2H aReq) * (8 * ((alg2P aReq : ℝ) + 1) * alg2XiA ξReq) := by ring
        _ ≤ ((M : ℝ) + R + 2) * (8 * ((alg2P aReq : ℝ) + 1) * alg2XiA ξReq) :=
            mul_le_mul_of_nonneg_right hk2 (by positivity)
        _ = ((M : ℝ) + R + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * alg2XiA ξReq := by ring
    have h2 : ((M : ℝ) + R + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * alg2XiA ξReq ≤
        2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) * alg2XiA ξReq := by
      have hM8 : ((M : ℝ) + R + 2) * 8 ≤ 2 ^ 40 * (alg2Q M J R aReq : ℝ) := by nlinarith
      calc ((M : ℝ) + R + 2) * (8 * ((alg2P aReq : ℝ) + 1)) * alg2XiA ξReq
          = (((M : ℝ) + R + 2) * 8) * (((alg2P aReq : ℝ) + 1) * alg2XiA ξReq) := by ring
        _ ≤ (2 ^ 40 * (alg2Q M J R aReq : ℝ)) * (((alg2P aReq : ℝ) + 1) * alg2XiA ξReq) :=
            mul_le_mul_of_nonneg_right hM8 (by positivity)
        _ = 2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) * alg2XiA ξReq := by ring
    linarith
  have hpos : 0 < ((k : ℝ) + 2) / alg2XiJ aReq ξReq := by positivity
  calc Real.log (((k : ℝ) + 2) / alg2XiJ aReq ξReq)
      ≤ Real.log ((2 : ℝ) ^ alg2Chi M J R aReq ξReq) :=
        Real.log_le_log hpos (hle.trans harg)
    _ = alg2Chi M J R aReq ξReq * Real.log 2 := by rw [Real.log_pow]
    _ ≤ alg2Chi M J R aReq ξReq := by
        have := Real.log_two_lt_d9
        have hχ := alg2Chi_pos_real M J R aReq ξReq
        nlinarith

/-- **Transfer condition** (`R:eq:sec2_L1_scales` at `r = n_j`, `θ = ϑ_j`, `ξ = ξ_j`, `k ≤ M+R`):
`72 e^{2ϑ_j} h^{-2} ln((k+2)/ξ_j) ≤ n_j` (L1034: "the second term of `n_j` dominates"). -/
theorem transfer_condition (M J R : ℕ) (aReq ξReq : ℝ) (j : ℕ) {k : ℕ} (hk : k ≤ M + R) :
    72 * Real.exp (2 * alg2Vartheta aReq j) / alg2H aReq ^ 2 *
        Real.log (((k : ℝ) + 2) / alg2XiJ aReq ξReq) ≤
      (alg2NBlock M J R aReq ξReq j : ℝ) := by
  have h2 := second_term_le_alg2NBlock M J R aReq ξReq j
  have hlog := log_le_alg2Chi M J R aReq ξReq hk
  have hexp := exp_two_mul_alg2Vartheta_lt_eight aReq j
  have hh := alg2H_pos aReq
  have hξj := alg2XiJ_pos aReq ξReq
  have hξj1 := alg2XiJ_lt_one aReq ξReq
  have hlog0 : 0 ≤ Real.log (((k : ℝ) + 2) / alg2XiJ aReq ξReq) := by
    apply Real.log_nonneg
    rw [le_div_iff₀ hξj]
    have : (0 : ℝ) ≤ k := Nat.cast_nonneg _
    linarith
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  calc 72 * Real.exp (2 * alg2Vartheta aReq j) / alg2H aReq ^ 2 *
        Real.log (((k : ℝ) + 2) / alg2XiJ aReq ξReq)
      ≤ 72 * 8 / alg2H aReq ^ 2 * (alg2Chi M J R aReq ξReq : ℝ) := by
        apply mul_le_mul _ hlog hlog0 (by positivity)
        apply div_le_div_of_nonneg_right _ (by positivity)
        linarith
    _ ≤ (2 : ℝ) ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 := by
        rw [div_mul_eq_mul_div]
        apply div_le_div_of_nonneg_right _ (by positivity)
        nlinarith
    _ ≤ _ := h2

/-! ### Noise tails (P5, L1036) -/

/-- Internal noises (scale `c·b_int`, `c ∈ {2, 4}`): `h/(c b_int + h_A) ≥ 31χ`. -/
theorem int_tail_ratio (M J R : ℕ) (aReq ξReq : ℝ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 4) :
    31 * (alg2Chi M J R aReq ξReq : ℝ) ≤
      alg2H aReq / (c * alg2BInt M J R aReq ξReq + alg2HA M J R aReq ξReq) := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hA := alg2HA_pos M J R aReq ξReq
  have hAh := alg2HA_mul_le_h M J R aReq ξReq
  have hb : alg2BInt M J R aReq ξReq = alg2H aReq / (128 * (alg2Chi M J R aReq ξReq : ℝ)) := rfl
  have hb0 : 0 < alg2BInt M J R aReq ξReq := by rw [hb]; positivity
  rw [le_div_iff₀ (by positivity)]
  have e : 31 * (alg2Chi M J R aReq ξReq : ℝ) * (c * alg2BInt M J R aReq ξReq) = 31 * c * alg2H aReq / 128 := by
    rw [hb]
    field_simp
  have e2 : 31 * (alg2Chi M J R aReq ξReq : ℝ) * (c * alg2BInt M J R aReq ξReq + alg2HA M J R aReq ξReq) =
      31 * c * alg2H aReq / 128 + 31 * ((alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq) := by
    rw [mul_add, e]
    ring
  rw [e2]
  have h3 : (alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq ≤ alg2H aReq / 2 ^ 20 := by
    rw [le_div_iff₀ (by norm_num)]
    linarith
  have h4 : 31 * c * alg2H aReq / 128 ≤ 31 * 4 * alg2H aReq / 128 := by
    apply div_le_div_of_nonneg_right _ (by norm_num)
    nlinarith
  have h5 : 31 * 4 * alg2H aReq / 128 + 31 * (alg2H aReq / 2 ^ 20) ≤ alg2H aReq := by
    nlinarith
  linarith

/-- Outer noises (scale `c·b_out`, `c ≤ 4`): `(a/8)/(c b_out + h_A) ≥ 8χ`. -/
theorem out_tail_ratio (M J R : ℕ) (aReq ξReq : ℝ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 4) :
    8 * (alg2Chi M J R aReq ξReq : ℝ) ≤
      alg2A aReq / 8 / (c * alg2BOut M J R aReq ξReq + alg2HA M J R aReq ξReq) := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have ha := alg2A_pos aReq
  have hA := alg2HA_pos M J R aReq ξReq
  have hAh := alg2HA_mul_le_h M J R aReq ξReq
  have hha : alg2H aReq ≤ alg2A aReq / 1024 := valH_le (alg2A_pos aReq)
  have hb : alg2BOut M J R aReq ξReq = alg2A aReq / (512 * (alg2Chi M J R aReq ξReq : ℝ)) := rfl
  have hb0 : 0 < alg2BOut M J R aReq ξReq := by rw [hb]; positivity
  rw [le_div_iff₀ (by positivity)]
  have e2 : 8 * (alg2Chi M J R aReq ξReq : ℝ) * (c * alg2BOut M J R aReq ξReq + alg2HA M J R aReq ξReq) =
      c * alg2A aReq / 64 + 8 * ((alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq) := by
    rw [hb]
    field_simp
    ring
  rw [e2]
  have h3 : (alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq ≤ alg2A aReq / 2 ^ 30 := by
    rw [le_div_iff₀ (by norm_num)]
    nlinarith
  have h4 : c * alg2A aReq / 64 ≤ 4 * alg2A aReq / 64 := by
    apply div_le_div_of_nonneg_right _ (by norm_num)
    nlinarith
  nlinarith

/-- Numerical noises (scale `b_num`): `(a/4)/(b_num + h_A) ≥ 8χ`. -/
theorem num_tail_ratio (M J R : ℕ) (aReq ξReq : ℝ) :
    8 * (alg2Chi M J R aReq ξReq : ℝ) ≤
      alg2A aReq / 4 / (alg2BNum M J R aReq ξReq + alg2HA M J R aReq ξReq) := by
  have hχ := alg2Chi_pos_real M J R aReq ξReq
  have ha := alg2A_pos aReq
  have hA := alg2HA_pos M J R aReq ξReq
  have hAh := alg2HA_mul_le_h M J R aReq ξReq
  have hha : alg2H aReq ≤ alg2A aReq / 1024 := valH_le (alg2A_pos aReq)
  have hb : alg2BNum M J R aReq ξReq = alg2A aReq / (64 * (alg2Chi M J R aReq ξReq : ℝ)) := rfl
  have hb0 : 0 < alg2BNum M J R aReq ξReq := by rw [hb]; positivity
  rw [le_div_iff₀ (by positivity)]
  have e2 : 8 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2BNum M J R aReq ξReq + alg2HA M J R aReq ξReq) =
      alg2A aReq / 8 + 8 * ((alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq) := by
    rw [hb]
    field_simp
    ring
  rw [e2]
  have h3 : (alg2Chi M J R aReq ξReq : ℝ) * alg2HA M J R aReq ξReq ≤ alg2A aReq / 2 ^ 30 := by
    rw [le_div_iff₀ (by norm_num)]
    nlinarith
  nlinarith

/-- `Q · 2e^{-8χ} < ξ_A/100` (total ideal tail mass over the fewer than `Q` draws). -/
theorem tail_total_lt (M J R : ℕ) (aReq ξReq : ℝ) :
    (alg2Q M J R aReq : ℝ) * (2 * Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ)))) <
      alg2XiA ξReq / 100 := by
  have hexp := exp_neg_natCast_le (alg2Chi M J R aReq ξReq)
  have hinv := inv_two_pow_valChi_le M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  change ((2 : ℝ) ^ alg2Chi M J R aReq ξReq)⁻¹ ≤
    alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    at hinv
  have hh := alg2H_pos aReq
  have hh1 := alg2H_le_one aReq
  have hξ := alg2XiA_pos ξReq
  have hξ1 := alg2XiA_le_one ξReq
  have hp : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hQ := alg2Q_pos_real M J R aReq
  set y := alg2H aReq * alg2XiA ξReq / (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ))
    with hy
  have hy0 : 0 < y := by rw [hy]; positivity
  have hQy : (alg2Q M J R aReq : ℝ) * y ≤ alg2XiA ξReq / 2 ^ 40 := by
    rw [hy, mul_div_assoc', div_le_div_iff₀ (by positivity) (by norm_num)]
    have h1 : alg2H aReq * alg2XiA ξReq ≤ alg2XiA ξReq := by nlinarith
    calc (alg2Q M J R aReq : ℝ) * (alg2H aReq * alg2XiA ξReq) * 2 ^ 40
        ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 := by gcongr
      _ ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 * ((alg2P aReq : ℝ) + 1) := by
          have : 0 ≤ (alg2Q M J R aReq : ℝ) * alg2XiA ξReq * 2 ^ 40 := by positivity
          nlinarith
      _ = alg2XiA ξReq * (2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) := by ring
  have hy1 : y ≤ 1 := by
    have : (alg2Q M J R aReq : ℝ) * y ≤ 1 := by
      have : alg2XiA ξReq / 2 ^ 40 ≤ 1 := by
        rw [div_le_one (by norm_num)]
        linarith
      linarith
    have hQ1 : (1 : ℝ) ≤ alg2Q M J R aReq := by
      have := six_hundred_le_valQ M J R (alg2A_pos aReq)
      have : (600 : ℝ) ≤ alg2Q M J R aReq := by exact_mod_cast this
      linarith
    nlinarith
  have he1 : Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ≤ y := hexp.trans hinv
  have he8 : Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))) =
      Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ^ 8 := by
    rw [← Real.exp_nat_mul]
    ring_nf
  have he8' : Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))) ≤ y := by
    rw [he8]
    calc Real.exp (-(alg2Chi M J R aReq ξReq : ℝ)) ^ 8 ≤ y ^ 8 :=
          pow_le_pow_left₀ (Real.exp_pos _).le he1 8
      _ ≤ y ^ 1 := pow_le_pow_of_le_one hy0.le hy1 (by norm_num)
      _ = y := pow_one y
  calc (alg2Q M J R aReq : ℝ) * (2 * Real.exp (-(8 * (alg2Chi M J R aReq ξReq : ℝ))))
      ≤ (alg2Q M J R aReq : ℝ) * (2 * y) := by gcongr
    _ = 2 * ((alg2Q M J R aReq : ℝ) * y) := by ring
    _ ≤ 2 * (alg2XiA ξReq / 2 ^ 40) := by linarith
    _ < alg2XiA ξReq / 100 := by
        rw [mul_div_assoc', div_lt_div_iff₀ (by norm_num) (by norm_num)]
        nlinarith

/-! ### Accuracy on the good event (P5, L1038–1046) -/

/-- Acceptance: `0.131a + 3a/4 + h_A < a`. -/
theorem accept_budget (M J R : ℕ) (aReq ξReq : ℝ) :
    131 / 1000 * alg2A aReq + 3 / 4 * alg2A aReq + alg2HA M J R aReq ξReq < alg2A aReq := by
  have h := alg2HA_le_a M J R aReq ξReq
  have ha := alg2A_pos aReq
  linarith

/-- Rejection: the signed excess `a/2 − a/8 − a/8 = a/4` exceeds `0.131a + h_A`. -/
theorem reject_budget (M J R : ℕ) (aReq ξReq : ℝ) :
    131 / 1000 * alg2A aReq + alg2HA M J R aReq ξReq < alg2A aReq / 2 - alg2A aReq / 8 - alg2A aReq / 8 := by
  have h := alg2HA_le_a M J R aReq ξReq
  have ha := alg2A_pos aReq
  linarith

/-- Numerical answers: `0.131a + a/4 + 2h_A < a`. -/
theorem numerical_budget (M J R : ℕ) (aReq ξReq : ℝ) :
    131 / 1000 * alg2A aReq + alg2A aReq / 4 + 2 * alg2HA M J R aReq ξReq < alg2A aReq := by
  have h := alg2HA_le_a M J R aReq ξReq
  have ha := alg2A_pos aReq
  linarith

/-- Failure: `ξ_A/8 + ξ_A/100 ≤ ξ_A`. -/
theorem failure_budget (ξReq : ℝ) : alg2XiA ξReq / 8 + alg2XiA ξReq / 100 ≤ alg2XiA ξReq := by
  have := alg2XiA_pos ξReq
  linarith

/-! ### Lemma `R:lem:sec3_potential_contraction` numerics -/

theorem alg2H_eq_tau (aReq : ℝ) : alg2H aReq = alg2Tau aReq / 64 := rfl

theorem alg2Theta_of_lt {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    alg2Theta aReq j = 1 / Real.sqrt ((alg2P aReq : ℝ) * 4 ^ j) := by
  unfold alg2Theta alg2Lambda
  rw [if_pos hj]

theorem alg2Theta_of_ge {aReq : ℝ} {j : ℕ} (hj : alg2P aReq ≤ j) :
    alg2Theta aReq j = alg2H aReq / (2 * Real.sqrt 2) := by
  unfold alg2Theta
  rw [if_neg (by omega)]

/-- `4^j θ_j² = 1/p` for `j < p`. -/
theorem four_pow_mul_alg2Theta_sq {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    (4 : ℝ) ^ j * alg2Theta aReq j ^ 2 = 1 / (alg2P aReq : ℝ) := by
  rw [alg2Theta_of_lt hj, div_pow, one_pow,
    Real.sq_sqrt (by positivity : (0 : ℝ) ≤ (alg2P aReq : ℝ) * 4 ^ j)]
  have hp : (0 : ℝ) < alg2P aReq := by linarith [two_le_alg2P_real aReq]
  field_simp

/-- `∑_{j<p} 4^j θ_j² = 1` (`R:eq:sec3_P0_bound`). -/
theorem sum_four_pow_mul_alg2Theta_sq (aReq : ℝ) :
    ∑ j ∈ Finset.range (alg2P aReq), (4 : ℝ) ^ j * alg2Theta aReq j ^ 2 = 1 := by
  rw [Finset.sum_congr rfl (fun j hj => four_pow_mul_alg2Theta_sq (Finset.mem_range.mp hj)),
    Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have hp : (0 : ℝ) < alg2P aReq := by linarith [two_le_alg2P_real aReq]
  field_simp

/-- `λ_j = (pθ_j²)^{-1}` for `j < p`. -/
theorem alg2Lambda_eq {aReq : ℝ} {j : ℕ} (hj : j < alg2P aReq) :
    alg2Lambda j = 1 / ((alg2P aReq : ℝ) * alg2Theta aReq j ^ 2) := by
  have h := four_pow_mul_alg2Theta_sq hj
  have hp : (0 : ℝ) < alg2P aReq := by linarith [two_le_alg2P_real aReq]
  have hθ : alg2Theta aReq j ^ 2 = 1 / ((alg2P aReq : ℝ) * 4 ^ j) := by
    have h4 : (0 : ℝ) < 4 ^ j := by positivity
    field_simp at h ⊢
    linarith
  unfold alg2Lambda
  rw [hθ]
  field_simp

theorem alg2Lambda_succ (j : ℕ) : alg2Lambda (j + 1) = 4 * alg2Lambda j := by
  unfold alg2Lambda
  ring

/-- Interior drop: `−κ(τ − 4h) + (5/8)κ² = −(25/128)τ²` (`R:eq:sec3_interior_drop`). -/
theorem interior_drop_identity (aReq : ℝ) :
    -alg2Kappa aReq * (alg2Tau aReq - 4 * alg2H aReq) + 5 / 8 * alg2Kappa aReq ^ 2 =
      -(25 / 128) * alg2Tau aReq ^ 2 := by
  unfold alg2Kappa
  rw [alg2H_eq_tau]
  ring

/-- `√2 θ_p = h/2` (`R:eq:sec3_anchor_error_15h`). -/
theorem sqrt_two_mul_alg2Theta_p (aReq : ℝ) :
    Real.sqrt 2 * alg2Theta aReq (alg2P aReq) = alg2H aReq / 2 := by
  rw [alg2Theta_of_ge (le_refl _)]
  have hs : 0 < Real.sqrt 2 := by positivity
  field_simp

/-- Anchor drop: `−κ(τ − 4.5h) + κ²/2 = −(51.5/256)τ²` (`R:eq:sec3_anchor_drop`). -/
theorem anchor_drop_identity (aReq : ℝ) :
    -alg2Kappa aReq * (alg2Tau aReq - 9 / 2 * alg2H aReq) + alg2Kappa aReq ^ 2 / 2 =
      -(103 / 512) * alg2Tau aReq ^ 2 := by
  unfold alg2Kappa
  rw [alg2H_eq_tau]
  ring

/-- `−(51.5/256)τ² < −(25/128)τ²`. -/
theorem anchor_drop_lt (aReq : ℝ) : -(103 / 512) * alg2Tau aReq ^ 2 < -(25 / 128) * alg2Tau aReq ^ 2 := by
  have := alg2Tau_pos aReq
  nlinarith

/-- No cap exhaustion (`R:eq:sec3_total_weighted_Tj`): if `4^j T ≤ (128/25)τ^{-2}` then `T < T_j^max`. -/
theorem lt_alg2Tmax_of_weighted {aReq : ℝ} {j T : ℕ} (hj : j < alg2P aReq)
    (hT : (4 : ℝ) ^ j * T ≤ 128 / 25 / alg2Tau aReq ^ 2) : T < alg2Tmax aReq j := by
  rw [alg2Tmax_of_lt hj]
  have hτ := alg2Tau_pos aReq
  have h4 : (0 : ℝ) < 4 ^ j := by positivity
  have hle := le_valTmax (alg2A aReq) j
  change 6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) ≤ (valTmax (alg2A aReq) j : ℝ) at hle
  have hT' : (T : ℝ) ≤ 128 / 25 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) := by
    rw [le_div_iff₀ (by positivity)]
    rw [le_div_iff₀ (by positivity)] at hT
    nlinarith
  have hlt : 128 / 25 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) < 6 / ((4 : ℝ) ^ j * alg2Tau aReq ^ 2) := by
    apply div_lt_div_of_pos_right (by norm_num) (by positivity)
  have : (T : ℝ) < valTmax (alg2A aReq) j := by linarith
  exact_mod_cast this

/-! ### The bounded sampler (Lemma `R:lem:sec3_sampler`) -/

/-- Truncation: `2ϱ^{K_s} ≤ ζ/8` with `B_0 = ⌈log₂(16/ζ)⌉`, `K_s = ⌈((b+h_A)/h_A)B_0⌉`. -/
theorem sampler_trunc_le {hA b ζ : ℝ} (hA0 : 0 < hA) (hb : 0 < b) (hζ : 0 < ζ) :
    2 * alg2Rho hA b ^ alg2Ks hA ⌈Real.logb 2 (16 / ζ)⌉₊ b ≤ ζ / 8 := by
  set B0 := ⌈Real.logb 2 (16 / ζ)⌉₊ with hB0
  set K := alg2Ks hA B0 b with hK
  have hB : 16 / ζ ≤ (2 : ℝ) ^ B0 := by
    have h := Nat.le_ceil (Real.logb 2 (16 / ζ))
    rw [← hB0, Real.logb_le_iff_le_rpow (by norm_num) (by positivity), Real.rpow_natCast] at h
    exact h
  have hKge : (b + hA) / hA * (B0 : ℝ) ≤ K := Nat.le_ceil _
  set t := hA / (b + hA) with ht
  have ht0 : 0 < t := by rw [ht]; positivity
  have hrho : alg2Rho hA b = 1 - t := by
    unfold alg2Rho
    rw [ht]
    field_simp
    ring
  have hrho0 : 0 ≤ alg2Rho hA b := by unfold alg2Rho; positivity
  have h1 : alg2Rho hA b ≤ Real.exp (-t) := by
    rw [hrho]
    have := Real.add_one_le_exp (-t)
    linarith
  have h2 : alg2Rho hA b ^ K ≤ Real.exp (-t) ^ K := pow_le_pow_left₀ hrho0 h1 K
  have h3 : Real.exp (-t) ^ K = Real.exp (-(t * K)) := by
    rw [← Real.exp_nat_mul]
    ring_nf
  have htK : (B0 : ℝ) ≤ t * K := by
    have e : t * ((b + hA) / hA * (B0 : ℝ)) = B0 := by
      rw [ht]
      field_simp
    calc (B0 : ℝ) = t * ((b + hA) / hA * (B0 : ℝ)) := e.symm
      _ ≤ t * K := mul_le_mul_of_nonneg_left hKge ht0.le
  have h4 : Real.exp (-(t * K)) ≤ Real.exp (-(B0 : ℝ)) := Real.exp_le_exp.mpr (by linarith)
  have h5 := exp_neg_natCast_le B0
  have h6 : ((2 : ℝ) ^ B0)⁻¹ ≤ ζ / 16 := by
    rw [inv_le_comm₀ (by positivity) (by positivity), inv_div]
    exact hB
  have : alg2Rho hA b ^ K ≤ ζ / 16 := by
    calc alg2Rho hA b ^ K ≤ Real.exp (-t) ^ K := h2
      _ = Real.exp (-(t * K)) := h3
      _ ≤ Real.exp (-(B0 : ℝ)) := h4
      _ ≤ ((2 : ℝ) ^ B0)⁻¹ := h5
      _ ≤ ζ / 16 := h6
  linarith

/-- Coin failures: `2K_s 2^{-r_s} < ζ/16` with `r_s = ⌈log₂(32(K_s+1)/ζ)⌉`. -/
theorem sampler_coin_lt {ζ : ℝ} (hζ : 0 < ζ) (Ks : ℕ) :
    2 * (Ks : ℝ) * ((2 : ℝ) ^ alg2Rs ζ Ks)⁻¹ < ζ / 16 := by
  have hr : 32 * ((Ks : ℝ) + 1) / ζ ≤ (2 : ℝ) ^ alg2Rs ζ Ks := by
    have h := Nat.le_ceil (Real.logb 2 (32 * ((Ks : ℝ) + 1) / ζ))
    unfold alg2Rs
    rw [Real.logb_le_iff_le_rpow (by norm_num) (by positivity), Real.rpow_natCast] at h
    exact h
  have h2 : ((2 : ℝ) ^ alg2Rs ζ Ks)⁻¹ ≤ ζ / (32 * ((Ks : ℝ) + 1)) := by
    rw [inv_le_comm₀ (by positivity) (by positivity), inv_div]
    exact hr
  have hK : (0 : ℝ) ≤ Ks := Nat.cast_nonneg _
  calc 2 * (Ks : ℝ) * ((2 : ℝ) ^ alg2Rs ζ Ks)⁻¹ ≤ 2 * (Ks : ℝ) * (ζ / (32 * ((Ks : ℝ) + 1))) :=
        mul_le_mul_of_nonneg_left h2 (by positivity)
    _ < ζ / 16 := by
        rw [mul_div_assoc', div_lt_div_iff₀ (by positivity) (by norm_num)]
        nlinarith

/-! ### Counting (P1, L984) -/

/-- "Fewer than `Q` scalar draws": `(p+1) + 3T + J + 2(p(M+R) + 3T) + 2M + R < Q` whenever the number
`T` of corrections is at most `∑_{j<p} T_j^max`. -/
theorem draws_lt_alg2Q (M J R : ℕ) (aReq : ℝ) {T : ℕ}
    (hT : T ≤ ∑ j ∈ Finset.range (alg2P aReq), alg2Tmax aReq j) :
    (alg2P aReq + 1) + 3 * T + J + 2 * (alg2P aReq * (M + R) + 3 * T) + 2 * M + R <
      alg2Q M J R aReq := by
  have hsum : ∑ j ∈ Finset.range (alg2P aReq), alg2Tmax aReq j =
      ∑ j ∈ Finset.range (alg2P aReq), valTmax (alg2A aReq) j :=
    Finset.sum_congr rfl (fun j hj => alg2Tmax_of_lt (Finset.mem_range.mp hj))
  rw [hsum] at hT
  show _ < 100 * (alg2P aReq + 1) *
    (M + R + J + 2 + ∑ j ∈ Finset.range (alg2P aReq), valTmax (alg2A aReq) j)
  generalize ∑ j ∈ Finset.range (alg2P aReq), valTmax (alg2A aReq) j = S at hT ⊢
  generalize alg2P aReq = p
  nlinarith

end F2e2e.B
