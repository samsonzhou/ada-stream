import F2e2e.C.SpaceDefs
import F2e2e.C.SpaceSize
import F2e2e.C.SpaceSteps

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`), part 2: the stored state on every execution

`parts/partIII.tex` L1238–1262: "Each row stores `2s⌈log₂(D_*+1)⌉ = O(ℒ²)` seed bits; two
`O(ℒ³)`-bit fixed-point counters; … Live learners additionally store tags, caches, epoch and
correction counters … this is a worst-case bound: samplers have finite loop caps, scores have
deterministic correction caps, rows are silently saturated, protected scalars have explicit ranges,
and all failures enter an absorbing state."

For the exact memory of the Theorem (C) algorithm (`F2e2e/C/Alg/State.lean`: `Row`, `Bank`,
`Learner`, `State`):

* (a)+(b) the per-component bounds `RowOK`, `BankOK`, `LearnerOK`, `StateOK` and the invariant
  `StateInv` (`F2e2e/C/SpaceDefs.lean`);
* that `StateInv` holds after the initialization and is preserved by every round, on every path of
  fresh bits and for every update (`algInit_inv`, `algStep_inv`; no box promise is needed), given an
  invariant of the ADA module's state (`AdaInvariant`); the sub-steps of a round:
  `F2e2e/C/SpaceSteps.lean`;
* the bit length of every stored integer (at most `23ℒ³ ≤ 2^30 ℒ³`, the register claim of Lemma 6.3,
  L1180) and the tree size bound `stateSizeBound` of the canonical encoding `encState`
  (`StateOK.valSize_encState_le`): `F2e2e/C/SpaceSize.lean`.

This module re-exports all of them.
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete

/-! ## The invariant on every execution -/

/-- The initialization establishes the invariant, on every path of fresh bits. -/
theorem algInit_inv (P : StreamParams) {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK) :
    Always (algInit P) (StateInv P adaOK) :=
  Always.mono (fun _ h => ⟨h.mono (by norm_num), fun _ => h⟩) (algInit_ok hA)

/-- Every round preserves the invariant, on every path of fresh bits and for every update `(i, Δ)`
(partIII.tex L1259–1261: worst case on every execution). -/
theorem algStep_inv (P : StreamParams) {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {s : State} (hs : StateInv P adaOK s) (i : ℕ) (Δ : ℤ) :
    Always (algStep P s i Δ) (fun r => StateInv P adaOK r.1) :=
  hs.always_fst (fun h => roundStep_ok hA (by norm_num) h i Δ)
    (fun h => roundStep_ok hA le_rfl h i Δ) (Always.mono (fun _ h => h.1) (algStep_failed P s i Δ))

/-- Tape form of `algInit_inv`. -/
theorem initRun_inv (P : StreamParams) {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {tape : List Bool} {s : State} {rest : List Bool} (h : initRun P tape = some (s, rest)) :
    StateInv P adaOK s :=
  Always.of_run (algInit_inv P hA) h

/-- Tape form of `algStep_inv`. -/
theorem stepRun_inv (P : StreamParams) {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {s : State} (hs : StateInv P adaOK s) {i : ℕ} {Δ : ℤ} {tape : List Bool} {s' : State} {q : ℚ}
    {rest : List Bool} (h : stepRun P s i Δ tape = some ((s', q), rest)) :
    StateInv P adaOK s' :=
  Always.of_run (algStep_inv P hA hs i Δ) h

end F2e2e.C.Space
