import Mathlib
import F2e2e.C.ClosureFreeM
import F2e2e.C.NormBank.Defs
import F2e2e.C.Tree.Shadow

/-!
# Theorem 6.4: the statistical good events (definitions shared by C-CLOSE and C-PROB)

Sources: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1266–1318), its
information-flow paragraph (L1271–1277) and failure budget (eq. `R:eq:global-failure-budget`, L1283); Theorem
`R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step` (statistical part); Lemma `R:lem:coarse-ams`.

All events are predicates on the ghost data of the instrumented canonical run (`theAlgL`,
`F2e2e/C/ClosureFreeM.lean`) at the end of round `m`.

* `rowFun P hist ζ`: the hypothetical row of seed `ζ` after the bank's row operations `hist` (with rounding and
  saturation exactly as the algorithm; partIII.tex L1273: "fixing that history defines the rounded, saturated
  recurrence on every possible row seed"). Every stored row of a bank equals `rowFun` of its seed (an algebraic
  invariant of the closure).
* `bankShadowXY P hist`: the exact (unrounded, unsaturated) shadow vectors tracked by the primary and secondary
  counters (the recurrences of Lemma 6.1 (iv) with the same rounded coefficients, partIII.tex L997, L1083);
  `bankShadow P mode hist` the vector measured in mode `PRIMARY` (`v_X`) or `DIFF` (`v_X − v_Y`).
* `callReq P rec`: the request a bank call makes to the bank's ADA module, as a core-level request
  (`F2e2e.B.CoreReq`) on C-BANK's seed space `NormBank.Seed P`: the grid indices of the query values
  `f̂(ζ) = round_{h_A} min{Ẑ(ζ)²/(Lc), 1}` of the hypothetical rows, the type, and the endpoints
  `(1 ∓ θ)/L` (partIII.tex L210–219).
* `adaTranscript P lab g`: the requests and ADA outputs of bank `lab`, oldest first.
* **`AdaGood P lab g`**: B's core-level failure event (`F2e2e.B.coreFails`: some covered output incorrect at
  accuracy `a_num`, `CAP_ABORT` on a covered request included) does not occur on bank `lab`'s transcript
  (Theorem 3.6 applied to the bank, partIII.tex L1277; budget `β_B/2`).
* **`CoarseGood P lab k g`**: the exact coarse moment event of the `k`-th release of bank `lab` (the release that
  consumes its reserved group `k`): the lower median of the `g` means of `32` squared exact measurements
  `⟨b(ζ), w⟩²`, `w = (v, σ)` the target augmented shadow, lies in `[9/16‖w‖², 23/16‖w‖²]` (Lemma 4.2,
  partIII.tex L387; budget `β_B/(2R_max)` per group).
* **`BankGood P adv tapes`**: all of these for every label, on the instrumented canonical run.
The fingerprint event is C-FP's `FpFalseZero` (`F2e2e/C/Fingerprint*.lean`).

The probability bounds (C-PROB, `F2e2e/C/ClosureProb*.lean`): `card_not_bankGood_le` (proved there).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Hypothetical rows and bank shadows -/

/-- The hypothetical row of seed `ζ` after the row operations `hist` (oldest first), starting from zero
counters. -/
def rowFun (P : StreamParams) (hist : List RowOp) (ζ : Seed P) : Row :=
  hist.foldl (fun r op => op.apply P r) (rowOf ζ (0, 0))

/-- One exact shadow step `(v_X, v_Y) ↦ (v_X', v_Y')` of a row operation (real units: counters are mantissas on
`h_b`; guards `δ` mantissas on `h_g`; multipliers `c` mantissas on `h_step`; coordinates `i, g` are 1-based,
Lean index `i − 1`). -/
noncomputable def shadowStep (P : StreamParams) (v : Tree.Vec P × Tree.Vec P) : RowOp → Tree.Vec P × Tree.Vec P
  | RowOp.phys i Δ => (v.1 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1), v.2 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1))
  | RowOp.guardY g δ => (v.1, v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1))
  | RowOp.guardXY g δ =>
      (v.1 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1),
        v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1))
  | RowOp.scaleY c => (v.1, ((gridVal P.eHstep c : ℚ) : ℝ) • v.2)
  | RowOp.scaleXY c => (((gridVal P.eHstep c : ℚ) : ℝ) • v.1, ((gridVal P.eHstep c : ℚ) : ℝ) • v.2)
  | RowOp.resetY => (v.1, 0)

/-- The exact shadow vectors `(v_X, v_Y)` of a bank with row-operation history `hist`. -/
noncomputable def bankShadowXY (P : StreamParams) (hist : List RowOp) : Tree.Vec P × Tree.Vec P :=
  hist.foldl (shadowStep P) (0, 0)

/-- The shadow vector measured by a bank in mode `PRIMARY` (`v_X`) or `DIFF` (`v_X − v_Y`). -/
noncomputable def bankShadow (P : StreamParams) (mode : Mode) (hist : List RowOp) : Tree.Vec P :=
  match mode with
  | Mode.primary => (bankShadowXY P hist).1
  | Mode.diff => (bankShadowXY P hist).1 - (bankShadowXY P hist).2

/-! ## ADA requests and transcripts -/

/-- The core-level request a bank call makes to the bank's ADA module. -/
def callReq (P : StreamParams) (rec : CallRec) : CoreReq (Seed P) :=
  match rec.kind with
  | CallKind.validate _ θ =>
      ⟨fun ζ => queryIdx (bankAda P).qA P.L rec.scale (regZ P Mode.primary (rowFun P rec.hist ζ)), true,
        (1 - θ) / (P.L : ℚ), (1 + θ) / (P.L : ℚ)⟩
  | CallKind.release mode =>
      ⟨fun ζ => queryIdx (bankAda P).qA P.L rec.scale (regZ P mode (rowFun P rec.hist ζ)), false, 0, 0⟩

/-- The ADA transcript of bank `lab` (requests and outputs of the calls that reached its ADA module). -/
def adaTranscript (P : StreamParams) (lab : BankLabel) (g : Ghost) : List (CoreReq (Seed P) × CoreOut) :=
  g.calls.filterMap fun rec => if rec.lab = lab then rec.out.map fun o => (callReq P rec, o) else none

/-- A default request (only used beyond the end of a transcript). -/
def defaultReq (U : Type) : CoreReq U := ⟨fun _ => 0, false, 0, 0⟩

/-- The controller replaying a transcript: the request following a history of length `j` is the `j`-th
request of the transcript. -/
def ctrlOf {U : Type} (tr : List (CoreReq U × CoreOut)) : CoreCtrl U :=
  fun h => (tr.getD h.length (defaultReq U, Sum.inl AdaCert.abort)).1

/-- **The ADA event of bank `lab`** (partIII.tex L1277): no covered output of its ADA module is incorrect at
accuracy `a_num` (B's core-level `coreFails`, with the uniform distribution on seeds). -/
def AdaGood (P : StreamParams) (lab : BankLabel) (g : Ghost) : Prop :=
  ¬ coreFails (bankAda P) (unifD P) (P.aNum : ℝ) (ctrlOf (adaTranscript P lab g))
    ((adaTranscript P lab g).map Prod.snd)

/-! ## Coarse groups -/

/-- The seed of a stored row, as an element of the seed space (`seedCoeffs (seedOfRow P r) = r.seed` for the
rows the algorithm creates). -/
def seedOfRow (P : StreamParams) (r : Row) : Seed P :=
  fun k => ⟨r.seed.getD k 0 % 2 ^ Hash.seedDeg P.Dstar, Nat.mod_lt _ (by positivity)⟩

/-- The seeds of a coarse group (`g` subgroups of `32` rows). -/
def groupSeeds (P : StreamParams) (grp : List (List Row)) : Fin P.gCoarse → Fin 32 → Seed P :=
  fun j l => seedOfRow P ((grp.getD j.val []).getD l.val ⟨[], 0, 0⟩)

/-- The exact coarse moment event of one release record (`True` if it found no coarse group). -/
def CoarseOK (P : StreamParams) (rec : CallRec) : Prop :=
  match rec.kind, rec.bank.coarse with
  | CallKind.release mode, grp :: _ =>
      9 / 16 * ‖aug P P.sigma (bankShadow P mode rec.hist)‖ ^ 2 ≤
          FinProb.coarseEst (FinProb.rowVals (sgn P) (aug P P.sigma (bankShadow P mode rec.hist))
            (groupSeeds P grp)) ∧
        FinProb.coarseEst (FinProb.rowVals (sgn P) (aug P P.sigma (bankShadow P mode rec.hist))
            (groupSeeds P grp)) ≤ 23 / 16 * ‖aug P P.sigma (bankShadow P mode rec.hist)‖ ^ 2
  | _, _ => True

/-- The release records of bank `lab` that consumed a coarse group, oldest first (the `k`-th consumed the
bank's reserved group `k`). -/
def coarseRecs (lab : BankLabel) (g : Ghost) : List CallRec :=
  g.calls.filter fun rec =>
    decide (rec.lab = lab) && (match rec.kind with
      | CallKind.release _ => true
      | _ => false) && !rec.bank.coarse.isEmpty

/-- **The coarse event of group `k` of bank `lab`** (Lemma 4.2; partIII.tex L1275, L387). -/
def CoarseGood (P : StreamParams) (lab : BankLabel) (k : ℕ) (g : Ghost) : Prop :=
  ∀ rec ∈ (coarseRecs lab g)[k]?, CoarseOK P rec

/-! ## The statistical event of the banks -/

/-- **All bank events** on the instrumented canonical run of a deterministic adversary. -/
def BankGood (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) : Prop :=
  ∀ c, theAlgL.run P adv tapes P.m = some c → ∀ lab, AdaGood P lab c.1.2 ∧ ∀ k, CoarseGood P lab k c.1.2

/-! The probability bound for these events, `card_not_bankGood_le` (C-PROB's target, partIII.tex L1281–1285: at
most `2m(H+1)` bank labels, each failing (ADA module `β_B/2`, its `R_max` coarse groups `β_B/2`) on at most a
`β_B = β₀/(64m(H+1))` fraction of the tapes, so the bank events fail on at most `β₀/32` of the tapes), is proved in
`F2e2e/C/ClosureProb.lean`. -/

end F2e2e.C.Closure
