import Mathlib
import F2e2e.C.ClosureEvents
import F2e2e.C.Fingerprint
import F2e2e.C.ClosureProb
import F2e2e.C.ClosureMain

/-!
# Theorem 6.4 and the proof of Theorem 1.1 (accuracy part): `theLawBound : TheLawBound`

Sources: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1266–1318) and the proof
of Theorem `R:thm:main-f2` (L1320–1322); the failure budget eq. `R:eq:global-failure-budget` (L1283).

C-TOP's Part III target `F2e2e.C.Top.TheLawBound` (`F2e2e/C/Top/AlgInstance.lean`) is proved from
* the fingerprint count (Lemma `R:lem:zero-fingerprint`, owner C-FP): the tapes on which some nonzero round
  before the first box violation is misreported as a zero round are at most a `β₀/8` fraction
  (`F2e2e.C.card_fpFalseZero_le_beta0`, `F2e2e/C/Fingerprint.lean`);
* the bank count (Theorem 3.6 + Lemma 4.2 + the information flow, owner C-PROB): the tapes on which some
  bank's ADA event or coarse event fails are at most a `β₀/32` fraction (`card_not_bankGood_le`,
  `F2e2e/C/ClosureProb.lean`);
* the deterministic chronological closure (`accurate_of_good` = `accurate_main`, `F2e2e/C/ClosureMain.lean`, on
  the invariant of `F2e2e/C/ClosureJoint.lean` threaded through every round by `F2e2e/C/ClosureRound.lean`): on all
  remaining tapes the canonical run is `ε₀`-accurate up to the first box violation;
via `β₀/8 + β₀/32 = 5β₀/32 ≤ β₀` and C-TOP's `ncard_not_streamAccurate_eq`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-- **The deterministic chronological closure** (Theorem 6.4, partIII.tex L1287–1317): on every tape on
which the fingerprint is exact and every bank's statistical events hold, the canonical run reports
`(1 ± ε₀)`-accurate estimates up to the first violation of the box promise. -/
theorem accurate_of_good (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (hfp : ¬ FpFalseZero P adv tapes)
    (hbank : BankGood P adv tapes) :
    StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes) :=
  accurate_main hP adv tapes hfp hbank

/-- The failure budget (eq. `R:eq:global-failure-budget`, partIII.tex L1283) in counting form. -/
theorem card_bad_le (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) :
    (({tapes | ¬ StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes)} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      (1 / 2 : ℝ) ^ P.betaExp * 2 ^ ((P.m + 1) * tapeBits P) := by
  classical
  set N := (P.m + 1) * tapeBits P
  have hsub : ({tapes | ¬ StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes)} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)) ⊆
      {tapes | FpFalseZero P adv tapes} ∪ {tapes | ¬ BankGood P adv tapes} := by
    intro tapes ht
    by_contra hn
    simp only [Set.mem_union, Set.mem_ofPred_eq, not_or, not_not] at hn
    exact ht (accurate_of_good P hP adv tapes hn.1 hn.2)
  have h1 := card_fpFalseZero_le_beta0 P hP adv
  have h2 := card_not_bankGood_le P hP adv
  have hb : (P.beta0 : ℝ) = (1 / 2 : ℝ) ^ P.betaExp := by
    simp [StreamParams.beta0]
  have hpos : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ P.betaExp * 2 ^ N := by positivity
  calc (({tapes | ¬ StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes)} :
          Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ)
      ≤ (({tapes | FpFalseZero P adv tapes} ∪ {tapes | ¬ BankGood P adv tapes} :
          Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) := by
        exact_mod_cast Set.ncard_le_ncard hsub (Set.toFinite _)
    _ ≤ (({tapes | FpFalseZero P adv tapes} : Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) +
          (({tapes | ¬ BankGood P adv tapes} : Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) := by
        exact_mod_cast Set.ncard_union_le _ _
    _ ≤ (P.beta0 : ℝ) / 8 * 2 ^ N + (P.beta0 : ℝ) / 32 * 2 ^ N := add_le_add h1 h2
    _ = 5 / 32 * ((1 / 2 : ℝ) ^ P.betaExp * 2 ^ N) := by rw [hb]; ring
    _ ≤ (1 / 2 : ℝ) ^ P.betaExp * 2 ^ N := by linarith

/-- **C-TOP's Part III target** (Theorem 6.4 + the proof of Theorem 1.1, accuracy part). -/
theorem theLawBound : TheLawBound := by
  intro P hP adv
  have hcount := ncard_not_streamAccurate_eq (A := theAlg) adv (algInit P) (theStep P)
    (fun _ => rfl) (fun _ _ _ => rfl) (theAlg_init_depth P) (fun s u => theAlg_step_depth P s u)
    ((1 / 2 : ℝ) ^ P.epsExp)
  have hle := card_bad_le P hP adv
  set N := (P.m + 1) * tapeBits P with hN
  set c := ({tapes | ¬ StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes)} :
    Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard with hc
  set L := (interact (algInit P) (theStep P) adv P.m).law.toOuterMeasure
    (BadOutcome P adv ((1 / 2 : ℝ) ^ P.epsExp)) with hL
  have hcount' : (c : ENNReal) = 2 ^ N * L := hcount
  have h2N : (2 : ENNReal) ^ N ≠ 0 := pow_ne_zero _ two_ne_zero
  have h2Nt : (2 : ENNReal) ^ N ≠ ⊤ := ENNReal.pow_ne_top ENNReal.ofNat_ne_top
  have h2 : (2 : ENNReal) ^ N = ENNReal.ofReal ((2 : ℝ) ^ N) := by
    rw [ENNReal.ofReal_pow (by norm_num), ENNReal.ofReal_ofNat]
  have hcR : (c : ENNReal) ≤ ENNReal.ofReal ((1 / 2 : ℝ) ^ P.betaExp) * 2 ^ N := by
    rw [h2, ← ENNReal.ofReal_mul (by positivity), ← ENNReal.ofReal_natCast]
    exact ENNReal.ofReal_le_ofReal hle
  rw [hcount', mul_comm] at hcR
  exact (ENNReal.mul_le_mul_iff_left h2N h2Nt).mp hcR

end F2e2e.C.Closure
