import Mathlib
import F2e2e.C.ClosureWP

/-!
# Theorem 6.4: stored rows are hypothetical rows (an algebraic invariant)

Every row operation of the algorithm acts on a row only through its seed and counters
(`RowOp.apply`, partIII.tex L482, L491, L505–506), and every bank starts with zero counters. Hence at every
moment every stored row of a bank equals the hypothetical row `rowFun P hist ζ` of its seed `ζ` under the
bank's row-operation history `hist` (partIII.tex L1273: "fixing that history defines the rounded, saturated
recurrence on every possible row seed"). This identifies the query values the bank hands to its ADA module with
the values on the sample of the query function on *all* seeds (the population means of Theorem 3.6), and the
coarse estimates with functions of the group's seeds.

* `RowOK P hist r`: the seed of `r` is well formed and `r = rowFun P hist (seedOfRow P r)`;
* `RowsOK P o g`: every stored row of every bank satisfies `RowOK` for the bank's history, and the ghost lists
  are parallel to the bank list;
* `rowsOK_outcome`: preserved by every outcome of the instrumented interpreter.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-! ## Every-path predicates on bit programs -/

/-- `BitAlways p Q`: every output of `p`, on every path of fresh bits, satisfies `Q`. (An inductive predicate,
so that unification never tries to unfold it by evaluating the bit program.) -/
inductive BitAlways {α : Type} (Q : α → Prop) : BitProg α → Prop
  | pure (a : α) : Q a → BitAlways Q (BitProg.pure a)
  | bit (k : Bool → BitProg α) : (∀ b, BitAlways Q (k b)) → BitAlways Q (BitProg.bit k)

theorem BitAlways.of_run {α : Type} {Q : α → Prop} :
    ∀ {p : BitProg α}, BitAlways Q p → ∀ {t : List Bool} {a : α} {r : List Bool},
      p.run t = some (a, r) → Q a
  | _, BitAlways.pure a h, t, a', r, hr => by
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hr
    exact hr.1 ▸ h
  | _, BitAlways.bit k h, [], _, _, hr => by simp at hr
  | _, BitAlways.bit k h, b :: t, a', r, hr => by
    simp only [BitProg.run_bit_cons] at hr
    exact BitAlways.of_run (h b) hr

theorem BitAlways.bind' {α β : Type} {Q : α → Prop} {R : β → Prop} {f : α → BitProg β}
    (hf : ∀ a, Q a → BitAlways R (f a)) : ∀ {p : BitProg α}, BitAlways Q p → BitAlways R (p.bind f)
  | _, BitAlways.pure a h => hf a h
  | _, BitAlways.bit k h => BitAlways.bit _ fun b => BitAlways.bind' hf (h b)

theorem BitAlways.mono' {α : Type} {Q Q' : α → Prop} (hQ : ∀ a, Q a → Q' a) :
    ∀ {p : BitProg α}, BitAlways Q p → BitAlways Q' p
  | _, BitAlways.pure a h => BitAlways.pure a (hQ a h)
  | _, BitAlways.bit k h => BitAlways.bit k fun b => BitAlways.mono' hQ (h b)

theorem bitAlways_true {α : Type} : ∀ p : BitProg α, BitAlways (fun _ => True) p
  | BitProg.pure a => BitAlways.pure a trivial
  | BitProg.bit k => BitAlways.bit k fun b => bitAlways_true (k b)

theorem bitAlways_bitsNat (acc : ℕ) :
    ∀ k, BitAlways (fun x => acc * 2 ^ k ≤ x ∧ x < (acc + 1) * 2 ^ k) (Discrete.bitsNat acc k)
  | 0 => BitAlways.pure acc (by simp)
  | k + 1 => by
    refine BitAlways.bit _ fun b => ?_
    refine BitAlways.mono' (fun x hx => ?_) (bitAlways_bitsNat (2 * acc + if b then 1 else 0) k)
    obtain ⟨h1, h2⟩ := hx
    constructor
    · calc acc * 2 ^ (k + 1) = 2 * acc * 2 ^ k := by ring
        _ ≤ (2 * acc + if b then 1 else 0) * 2 ^ k := Nat.mul_le_mul_right _ (Nat.le_add_right _ _)
        _ ≤ x := h1
    · calc x < (2 * acc + (if b then 1 else 0) + 1) * 2 ^ k := h2
        _ ≤ (acc + 1) * 2 ^ (k + 1) := by
          rw [pow_succ]
          have : (if b then 1 else 0) ≤ 1 := by split_ifs <;> omega
          nlinarith

theorem bitAlways_uniformBits (k : ℕ) : BitAlways (fun x => x < 2 ^ k) (uniformBits k) :=
  BitAlways.mono' (fun x hx => by simpa using hx.2) (bitAlways_bitsNat 0 k)

theorem bitAlways_sampleList {α : Type} {Q : α → Prop} (p : BitProg α) (hp : BitAlways Q p) :
    ∀ k, BitAlways (fun l => l.length = k ∧ ∀ x ∈ l, Q x) (sampleList p k)
  | 0 => BitAlways.pure [] ⟨rfl, fun x hx => absurd hx List.not_mem_nil⟩
  | k + 1 => by
    rw [sampleList_succ]
    refine BitAlways.bind' (fun a ha => BitAlways.bind' (fun l hl => BitAlways.pure _ ?_)
      (bitAlways_sampleList p hp k)) hp
    refine ⟨by simp [hl.1], fun x hx => ?_⟩
    rcases List.mem_cons.mp hx with rfl | hx
    · exact ha
    · exact hl.2 x hx

/-! ## Fresh rows -/

/-- A seed list is well formed: `2s` entries below `2^w`. -/
def SeedWF (P : StreamParams) (l : List ℕ) : Prop := l.length = 2 * P.s ∧ ∀ x ∈ l, x < 2 ^ P.w

/-- A fresh row: a well-formed seed and zero counters. -/
def FreshRow (P : StreamParams) (r : Row) : Prop := SeedWF P r.seed ∧ r.X = 0 ∧ r.Y = 0

theorem bitAlways_sampleSeed (P : StreamParams) : BitAlways (SeedWF P) (sampleSeed P) :=
  bitAlways_sampleList (uniformBits P.w) (bitAlways_uniformBits P.w) (2 * P.s)

theorem newRow_eq (P : StreamParams) :
    newRow P = (sampleSeed P).bind fun z => BitProg.pure ⟨z, 0, 0⟩ := rfl

theorem bitAlways_newRow (P : StreamParams) : BitAlways (FreshRow P) (newRow P) := by
  rw [newRow_eq]
  exact BitAlways.bind' (fun z hz => BitAlways.pure _ ⟨hz, rfl, rfl⟩) (bitAlways_sampleSeed P)

theorem sampleBlocks_cons (P : StreamParams) (nj : ℕ) (rest : List ℕ) :
    sampleBlocks P (nj :: rest) = (sampleList (newRow P) nj).bind fun blk =>
      (sampleBlocks P rest).bind fun l => BitProg.pure (blk :: l) := rfl

theorem bitAlways_sampleBlocks (P : StreamParams) :
    ∀ l : List ℕ, BitAlways (fun blks => ∀ blk ∈ blks, ∀ r ∈ blk, FreshRow P r) (sampleBlocks P l)
  | [] => BitAlways.pure [] fun blk hblk => absurd hblk List.not_mem_nil
  | nj :: rest => by
    rw [sampleBlocks_cons]
    have hb := bitAlways_sampleList (newRow P) (bitAlways_newRow P) nj
    have hr := bitAlways_sampleBlocks P rest
    refine BitAlways.bind' (fun blk hblk => BitAlways.bind' (fun l hl => BitAlways.pure _ ?_) hr) hb
    intro b hb r hr
    rcases List.mem_cons.mp hb with rfl | hb
    · exact hblk.2 r hr
    · exact hl b hb r hr

/-- Every row of a fresh bank is fresh. -/
theorem bitAlways_newBank (P : StreamParams) :
    BitAlways (fun B => (∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧
      (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) (newBank P) := by
  have hnb : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
      (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind fun coarse =>
        (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl
  rw [hnb]
  have h1 := bitAlways_sampleBlocks P (bankAda P).blockSizes
  have h2 := bitAlways_sampleList _ (bitAlways_sampleList _ (bitAlways_sampleList _
    (bitAlways_newRow P) 32) P.gCoarse) P.Rmax
  have h3 := bitAlways_true (adaInit (bankAda P))
  refine BitAlways.bind' (fun ada hada => BitAlways.bind' (fun coarse hco =>
    BitAlways.bind' (fun st _ => BitAlways.pure _ ?_) h3) h2) h1
  exact ⟨hada, fun grp hgrp sub hsub r hr => ((hco.2 grp hgrp).2 sub hsub).2 r hr⟩

/-! ## Hypothetical rows -/

theorem rowOp_apply_seed (P : StreamParams) (op : RowOp) (r : Row) : (op.apply P r).seed = r.seed := by
  cases op <;> rfl

theorem rowFun_append (P : StreamParams) (hist : List RowOp) (op : RowOp) (ζ : Seed P) :
    rowFun P (hist ++ [op]) ζ = op.apply P (rowFun P hist ζ) := by
  unfold rowFun
  rw [List.foldl_append]
  rfl

theorem rowFun_nil (P : StreamParams) (ζ : Seed P) : rowFun P [] ζ = rowOf ζ (0, 0) := rfl

/-- The seed of a well-formed seed list round-trips. -/
theorem seedCoeffs_seedOfRow (P : StreamParams) (r : Row) (h : SeedWF P r.seed) :
    Hash.seedCoeffs (seedOfRow P r) = r.seed := by
  obtain ⟨hlen, hlt⟩ := h
  unfold Hash.seedCoeffs seedOfRow
  apply List.ext_getElem
  · simp [hlen]
  · intro k h1 h2
    simp only [List.getElem_ofFn]
    have hk : k < r.seed.length := h2
    rw [List.getD_eq_getElem _ _ hk]
    exact Nat.mod_eq_of_lt (hlt _ (List.getElem_mem hk))

/-- A row is the hypothetical row of its (well-formed) seed under `hist`. -/
def RowOK (P : StreamParams) (hist : List RowOp) (r : Row) : Prop :=
  SeedWF P r.seed ∧ r = rowFun P hist (seedOfRow P r)

theorem rowOK_fresh (P : StreamParams) {r : Row} (h : FreshRow P r) : RowOK P [] r := by
  refine ⟨h.1, ?_⟩
  rw [rowFun_nil]
  unfold rowOf
  rw [seedCoeffs_seedOfRow P r h.1]
  obtain ⟨-, hX, hY⟩ := h
  cases r
  simp_all

theorem rowOK_apply (P : StreamParams) {hist : List RowOp} {r : Row} (op : RowOp) (h : RowOK P hist r) :
    RowOK P (hist ++ [op]) (op.apply P r) := by
  obtain ⟨hwf, hr⟩ := h
  have hseed : seedOfRow P (op.apply P r) = seedOfRow P r := by
    funext k
    exact Fin.ext (by simp only [seedOfRow, rowOp_apply_seed])
  refine ⟨by rw [rowOp_apply_seed]; exact hwf, ?_⟩
  rw [hseed, rowFun_append, ← hr]

/-- All stored rows of a bank are hypothetical rows of its history. -/
def BankRowsOK (P : StreamParams) (hist : List RowOp) (B : Bank) : Prop :=
  (∀ blk ∈ B.ada, ∀ r ∈ blk, RowOK P hist r) ∧ (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P hist r)

theorem bankRowsOK_mapRows (P : StreamParams) {hist : List RowOp} {B : Bank} (op : RowOp)
    (h : BankRowsOK P hist B) : BankRowsOK P (hist ++ [op]) (Bank.mapRows (op.apply P) B) := by
  obtain ⟨h1, h2⟩ := h
  unfold Bank.mapRows
  refine ⟨fun blk hblk r hr => ?_, fun grp hgrp sub hsub r hr => ?_⟩
  · obtain ⟨blk0, hblk0, rfl⟩ := List.mem_map.mp hblk
    obtain ⟨r0, hr0, rfl⟩ := List.mem_map.mp hr
    exact rowOK_apply P op (h1 blk0 hblk0 r0 hr0)
  · obtain ⟨grp0, hgrp0, rfl⟩ := List.mem_map.mp hgrp
    obtain ⟨sub0, hsub0, rfl⟩ := List.mem_map.mp hsub
    obtain ⟨r0, hr0, rfl⟩ := List.mem_map.mp hr
    exact rowOK_apply P op (h2 grp0 hgrp0 sub0 hsub0 r0 hr0)

/-- The invariant: every bank's stored rows are hypothetical rows of its history; the ghost lists are
parallel to the bank list. -/
structure RowsOK (P : StreamParams) (o : OState) (g : Ghost) : Prop where
  len_hists : g.hists.length = o.banks.length
  len_labels : g.labels.length = o.banks.length
  rows : ∀ (idx : ℕ) (B : Bank), o.banks[idx]? = some B → BankRowsOK P (g.histAt idx) B

/-! ## List lemmas for `modifyAt`, `mapFrom`, `setAt` -/

theorem length_modifyAt {α : Type} (f : α → α) : ∀ (k : ℕ) (l : List α), (modifyAt f k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [modifyAt]
  | k + 1, _ :: l => by simp [modifyAt, length_modifyAt f k l]

theorem length_mapFrom {α : Type} (f : α → α) : ∀ (k : ℕ) (l : List α), (mapFrom f k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [mapFrom, length_mapFrom f 0 l]
  | k + 1, _ :: l => by simp [mapFrom, length_mapFrom f k l]

theorem length_setAt {α : Type} (b : α) : ∀ (k : ℕ) (l : List α), (setAt b k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [setAt]
  | k + 1, _ :: l => by simp [setAt, length_setAt b k l]

theorem getElem?_modifyAt {α : Type} (f : α → α) :
    ∀ (k j : ℕ) (l : List α), (modifyAt f k l)[j]? = if j = k then l[j]?.map f else l[j]?
  | _, _, [] => by simp [modifyAt]
  | 0, 0, a :: l => by simp [modifyAt]
  | 0, j + 1, a :: l => by simp [modifyAt]
  | k + 1, 0, a :: l => by simp [modifyAt]
  | k + 1, j + 1, a :: l => by
    simp only [modifyAt, List.getElem?_cons_succ, getElem?_modifyAt f k j l, Nat.add_right_cancel_iff]

theorem getElem?_mapFrom {α : Type} (f : α → α) :
    ∀ (k j : ℕ) (l : List α), (mapFrom f k l)[j]? = if k ≤ j then l[j]?.map f else l[j]?
  | _, _, [] => by simp [mapFrom]
  | 0, 0, a :: l => by simp [mapFrom]
  | 0, j + 1, a :: l => by
    simp only [mapFrom, List.getElem?_cons_succ, getElem?_mapFrom f 0 j l]
    simp
  | k + 1, 0, a :: l => by simp [mapFrom]
  | k + 1, j + 1, a :: l => by
    simp only [mapFrom, List.getElem?_cons_succ, getElem?_mapFrom f k j l, Nat.add_le_add_iff_right]

theorem getElem?_setAt {α : Type} (b : α) :
    ∀ (k j : ℕ) (l : List α), (setAt b k l)[j]? = if j = k ∧ j < l.length then some b else l[j]?
  | _, _, [] => by simp [setAt]
  | 0, 0, a :: l => by simp [setAt]
  | 0, j + 1, a :: l => by simp [setAt]
  | k + 1, 0, a :: l => by simp [setAt]
  | k + 1, j + 1, a :: l => by
    simp only [setAt, List.getElem?_cons_succ, getElem?_setAt b k j l, Nat.add_right_cancel_iff,
      List.length_cons, Nat.add_lt_add_iff_right]

/-! ## Preservation -/

theorem histAt_modifyAt (g : Ghost) (f : List RowOp → List RowOp) (idx j : ℕ) :
    ({ g with hists := modifyAt f idx g.hists } : Ghost).histAt j =
      if j = idx then (g.hists[j]?.map f).getD [] else g.histAt j := by
  unfold Ghost.histAt
  rw [List.getD_eq_getElem?_getD, getElem?_modifyAt]
  split_ifs <;> simp [List.getD_eq_getElem?_getD]

theorem histAt_mapFrom (g : Ghost) (f : List RowOp → List RowOp) (idx j : ℕ) :
    ({ g with hists := mapFrom f idx g.hists } : Ghost).histAt j =
      if idx ≤ j then (g.hists[j]?.map f).getD [] else g.histAt j := by
  unfold Ghost.histAt
  rw [List.getD_eq_getElem?_getD, getElem?_mapFrom]
  split_ifs <;> simp [List.getD_eq_getElem?_getD]

theorem bitAlways_validate (P : StreamParams) (B : Bank) (S θ : ℚ) :
    BitAlways (fun r => r.2.ada = B.ada ∧ r.2.coarse = B.coarse) (B.validate P S θ) := by
  unfold Bank.validate
  simp only [bp_bind_eq, bp_pure_eq]
  exact BitAlways.bind' (fun _ _ => BitAlways.pure _ ⟨rfl, rfl⟩) (bitAlways_true _)

theorem releaseLog_nil (P : StreamParams) (B : Bank) (mode : Mode) (h : B.coarse = []) :
    releaseLog P B mode = BitProg.pure ((none, B), none) := by
  unfold releaseLog; rw [h]

theorem releaseLog_cons (P : StreamParams) (B : Bank) (mode : Mode) {grp : List (List Row)}
    {rest : List (List (List Row))} (h : B.coarse = grp :: rest) :
    releaseLog P B mode =
      (adaNumerical (bankAda P) B.adaSt
          (adaVals P mode (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) B)).bind
        fun res =>
          match res.1 with
          | AdaNum.val μ =>
            BitProg.pure ((some (max 0 ((P.L : ℚ) *
                (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) * μ - P.omega)),
                { B with coarse := rest, adaSt := res.2 }),
              some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1))
          | AdaNum.abort =>
            BitProg.pure ((none, { B with coarse := rest, adaSt := res.2 }),
              some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1)) := by
  unfold releaseLog; rw [h]; rfl

theorem bitAlways_releaseLog (P : StreamParams) (B : Bank) (mode : Mode) :
    BitAlways (fun r => r.1.2.ada = B.ada ∧ r.1.2.coarse = B.coarse.tail) (releaseLog P B mode) := by
  cases h : B.coarse with
  | nil =>
    rw [releaseLog_nil P B mode h]
    exact BitAlways.pure _ ⟨rfl, by simp [h]⟩
  | cons grp rest =>
    rw [releaseLog_cons P B mode h]
    refine BitAlways.bind' (fun res _ => ?_) (bitAlways_true _)
    rcases res with ⟨out, st⟩
    cases out with
    | val μ => exact BitAlways.pure _ ⟨rfl, by simp⟩
    | abort => exact BitAlways.pure _ ⟨rfl, by simp⟩

theorem rowsOK_of_eq {P : StreamParams} {o o' : OState} {g g' : Ghost} (h : RowsOK P o g)
    (hb : o'.banks = o.banks) (hh : g'.hists = g.hists) (hl : g'.labels = g.labels) : RowsOK P o' g' where
  len_hists := by rw [hb, hh]; exact h.len_hists
  len_labels := by rw [hb, hl]; exact h.len_labels
  rows := by
    intro idx B hB
    rw [hb] at hB
    have : g'.histAt idx = g.histAt idx := by unfold Ghost.histAt; rw [hh]
    rw [this]
    exact h.rows idx B hB

theorem rowsOK_bankNew {P : StreamParams} {o : OState} {g : Ghost} (h : RowsOK P o g) (B : Bank)
    (hB : (∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧ (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r))
    (lab : BankLabel) :
    RowsOK P { o with banks := o.banks ++ [B] } { g with labels := g.labels ++ [lab], hists := g.hists ++ [[]] } where
  len_hists := by simp [h.len_hists]
  len_labels := by simp [h.len_labels]
  rows := by
    intro idx B' hB'
    simp only at hB'
    rcases Nat.lt_or_ge idx o.banks.length with hlt | hge
    · rw [List.getElem?_append_left hlt] at hB'
      have hh : ({ g with labels := g.labels ++ [lab], hists := g.hists ++ [[]] } : Ghost).histAt idx =
          g.histAt idx := by
        unfold Ghost.histAt
        simp only
        rw [List.getD_append _ _ _ _ (by rw [h.len_hists]; exact hlt)]
      rw [hh]
      exact h.rows idx B' hB'
    · rw [List.getElem?_append_right hge] at hB'
      have hidx : idx - o.banks.length = 0 := by
        by_contra hne
        have : [B][idx - o.banks.length]? = none := by
          rw [List.getElem?_eq_none_iff]; simp; omega
        rw [this] at hB'; simp at hB'
      rw [hidx] at hB'
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hB'
      subst hB'
      have hh : ({ g with labels := g.labels ++ [lab], hists := g.hists ++ [[]] } : Ghost).histAt idx = [] := by
        unfold Ghost.histAt
        simp only
        rw [List.getD_append_right _ _ _ _ (by rw [h.len_hists]; exact hge), h.len_hists, hidx]
        rfl
      rw [hh]
      exact ⟨fun blk hblk r hr => rowOK_fresh P (hB.1 blk hblk r hr),
        fun grp hgrp sub hsub r hr => rowOK_fresh P (hB.2 grp hgrp sub hsub r hr)⟩

theorem rowsOK_retain {P : StreamParams} {o : OState} {g : Ghost} (h : RowsOK P o g) (n : ℕ) :
    RowsOK P { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n } where
  len_hists := by simp [h.len_hists]
  len_labels := by simp [h.len_labels]
  rows := by
    intro idx B hB
    by_cases hlt : idx < n
    · rw [List.getElem?_take, if_pos hlt] at hB
      have hh : ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost).histAt idx =
          g.histAt idx := by
        unfold Ghost.histAt
        simp only [List.getD_eq_getElem?_getD, List.getElem?_take, if_pos hlt]
      rw [hh]
      exact h.rows idx B hB
    · rw [List.getElem?_take, if_neg hlt] at hB
      simp at hB

theorem rowsOK_bankOp {P : StreamParams} {o : OState} {g : Ghost} (h : RowsOK P o g) (idx : ℕ)
    (op : RowOp) :
    RowsOK P { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } where
  len_hists := by simp [length_modifyAt, h.len_hists]
  len_labels := by simp [length_modifyAt, h.len_labels]
  rows := by
    intro j B hB
    simp only [getElem?_modifyAt] at hB
    rw [histAt_modifyAt]
    split_ifs at hB ⊢ with hj
    · subst hj
      obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp hB
      have hlt : j < g.hists.length := by
        rw [h.len_hists]; exact (List.getElem?_eq_some_iff.mp hB0).1
      rw [List.getElem?_eq_getElem hlt, Option.map_some, Option.getD_some]
      have := h.rows j B0 hB0
      unfold Ghost.histAt at this
      rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hlt, Option.getD_some] at this
      exact bankRowsOK_mapRows P op this
    · exact h.rows j B hB

theorem rowsOK_bankOpFrom {P : StreamParams} {o : OState} {g : Ghost} (h : RowsOK P o g) (idx : ℕ)
    (op : RowOp) :
    RowsOK P { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists } where
  len_hists := by simp [length_mapFrom, h.len_hists]
  len_labels := by simp [length_mapFrom, h.len_labels]
  rows := by
    intro j B hB
    simp only [getElem?_mapFrom] at hB
    rw [histAt_mapFrom]
    split_ifs at hB ⊢ with hj
    · obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp hB
      have hlt : j < g.hists.length := by
        rw [h.len_hists]; exact (List.getElem?_eq_some_iff.mp hB0).1
      rw [List.getElem?_eq_getElem hlt, Option.map_some, Option.getD_some]
      have := h.rows j B0 hB0
      unfold Ghost.histAt at this
      rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hlt, Option.getD_some] at this
      exact bankRowsOK_mapRows P op this
    · exact h.rows j B hB

theorem rowsOK_setAt {P : StreamParams} {o : OState} {g g' : Ghost} (h : RowsOK P o g) (idx : ℕ)
    {B B' : Bank} (hB : o.banks[idx]? = some B) (hada : B'.ada = B.ada)
    (hco : ∀ grp ∈ B'.coarse, grp ∈ B.coarse) (hh : g'.hists = g.hists) (hl : g'.labels = g.labels) :
    RowsOK P { o with banks := setAt B' idx o.banks } g' where
  len_hists := by simp [length_setAt, hh, h.len_hists]
  len_labels := by simp [length_setAt, hl, h.len_labels]
  rows := by
    intro j B2 hB2
    have hhj : g'.histAt j = g.histAt j := by unfold Ghost.histAt; rw [hh]
    rw [hhj]
    simp only [getElem?_setAt] at hB2
    split_ifs at hB2 with hj
    · obtain ⟨rfl, -⟩ := hj
      simp only [Option.some.injEq] at hB2
      subst hB2
      obtain ⟨h1, h2⟩ := h.rows j B hB
      refine ⟨fun blk hblk r hr => h1 blk (hada ▸ hblk) r hr, fun grp hgrp sub hsub r hr => ?_⟩
      exact h2 grp (hco grp hgrp) sub hsub r hr
    · exact h.rows j B2 hB2

/-- **The stored rows stay hypothetical rows of their banks' histories**, along every outcome of the
instrumented interpreter. -/
theorem rowsOK_outcome (P : StreamParams) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost) (a : α) (o' : OState) (g' : Ghost),
      RowsOK P o g → Outcome P p o g a o' g' → RowsOK P o' g'
  | AlgM.pure _, o, g, a, o', g', h, hout => by
    obtain ⟨-, rfl, rfl⟩ := outcome_pure hout
    exact h
  | AlgM.fpInit k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    obtain ⟨b, mid, -, hrun⟩ := outcome_tag_bind _ _ _ hrun
    exact rowsOK_outcome P k _ _ a o' g' (by exact rowsOK_of_eq h rfl rfl rfl) ⟨mid, rest, hrun⟩
  | AlgM.fpStep i Δ k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    exact rowsOK_outcome P _ _ _ a o' g' (by exact rowsOK_of_eq h rfl rfl rfl) ⟨tape, rest, hrun⟩
  | AlgM.bankNew tr d k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    rw [merge_bind, merge_newBankT, BitProg.run_bind] at hrun
    obtain ⟨r, hr, hrun⟩ := Option.bind_eq_some_iff.mp hrun
    exact rowsOK_outcome P k _ _ a o' g'
      (rowsOK_bankNew h r.1 (BitAlways.of_run (bitAlways_newBank P) hr) (tr, d)) ⟨r.2, rest, hrun⟩
  | AlgM.bankRetain n k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    exact rowsOK_outcome P k _ _ a o' g' (by exact rowsOK_retain h n) ⟨tape, rest, hrun⟩
  | AlgM.bankOp idx op k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    exact rowsOK_outcome P k _ _ a o' g' (by exact rowsOK_bankOp h idx op) ⟨tape, rest, hrun⟩
  | AlgM.bankOpFrom idx op k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    exact rowsOK_outcome P k _ _ a o' g' (by exact rowsOK_bankOpFrom h idx op) ⟨tape, rest, hrun⟩
  | AlgM.bankValidate idx S θ k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    cases hB : o.banks[idx]? with
    | none =>
      rw [hB] at hrun
      exact rowsOK_outcome P _ _ _ a o' g' h ⟨tape, rest, hrun⟩
    | some B =>
      rw [hB] at hrun
      obtain ⟨b, mid, hb, hrun⟩ := outcome_tag_bind _ _ _ hrun
      have hb' := BitAlways.of_run (bitAlways_validate P B S θ) hb
      exact rowsOK_outcome P _ _ _ a o' g'
        (by exact rowsOK_setAt h idx hB hb'.1 (fun grp hg => hb'.2 ▸ hg) rfl rfl) ⟨mid, rest, hrun⟩
  | AlgM.bankRelease idx mode k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    cases hB : o.banks[idx]? with
    | none =>
      rw [hB] at hrun
      exact rowsOK_outcome P _ _ _ a o' g' h ⟨tape, rest, hrun⟩
    | some B =>
      rw [hB] at hrun
      obtain ⟨b, mid, hb, hrun⟩ := outcome_tag_bind _ _ _ hrun
      have hb' := BitAlways.of_run (bitAlways_releaseLog P B mode) hb
      exact rowsOK_outcome P _ _ _ a o' g'
        (by exact rowsOK_setAt h idx hB hb'.1 (fun grp hg => by
          rw [hb'.2] at hg; exact List.mem_of_mem_tail hg) rfl rfl) ⟨mid, rest, hrun⟩
  | AlgM.note ev k, o, g, a, o', g', h, ⟨tape, rest, hrun⟩ => by
    simp only [runL] at hrun
    exact rowsOK_outcome P k _ _ a o' g' (by exact rowsOK_of_eq h rfl rfl rfl) ⟨tape, rest, hrun⟩

end F2e2e.C.Closure
