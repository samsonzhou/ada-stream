import Mathlib
import F2e2e.C.ClosureRound
import F2e2e.C.Fingerprint

/-!
# Theorem 6.4: the chronological induction over the canonical run

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1287–1317): by induction over the
rounds, on the fingerprint event and the bank events, every round before the first violation of the box promise
keeps the invariant and reports an `ε₀`-accurate estimate.

The canonical run of the instrumented algorithm `theAlgL` (`F2e2e/C/ClosureFreeM.lean`) consists of outcomes of the
controller code (`initCode`, then `roundCode` per round); the final ghost data carry the bank events
(`BankGood`), every intermediate call log is a prefix of the final one, and the fingerprint event (C-FP's
`FpFalseZero`) makes the zero test of every round before the first box violation exact.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## The initialization -/

/-- The initialization data (`initCode` from `initO`, `Ghost.init`). -/
theorem wp_initCode (F : List CallRec) :
    WP P F initCode (fun c o g => InitState P c o g) initO Ghost.init := by
  show WP P F (AlgM.fpInit (AlgM.bankNew 0 0 (AlgM.pure ⟨0, false, [], 0⟩)))
    (fun c o g => InitState P c o g) initO Ghost.init
  refine wp_fpInit (fun r => ?_)
  refine wp_bankNew (bitAlways_newBank_all P) (fun B hB => ?_)
  refine wp_pure ?_
  show InitState P ⟨0, false, [], 0⟩ { { initO with fpSeed := r, fpVal := 0 } with banks := [] ++ [B] }
    { Ghost.init with labels := [] ++ [(0, 0)], hists := [] ++ [[]] }
  exact ⟨rfl, ⟨B, rfl, hB⟩, rfl, rfl, rfl, rfl⟩

/-! ## The canonical run as outcomes of the controller code -/

theorem theAlgL_run_zero_some (adv : StreamAdversary P.n) (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool)
    {c : (State × Ghost) × List ℚ} (h : theAlgL.run P adv tapes 0 = some c) :
    ∃ (a : CState) (o : OState) (g : Ghost), Outcome P initCode initO Ghost.init a o g ∧
      c = ((State.mk' a o, g), []) := by
  have h' : ((((runL P initCode initO Ghost.init).map fun r => (State.mk' r.1 r.2.1, r.2.2)).merge.run
      (tapeAt tapes 0)).map fun r => (r.1, ([] : List ℚ))) = some c := h
  rw [TBitProg.merge_map, BitProg.run_map] at h'
  obtain ⟨r, hr, rfl⟩ := Option.map_eq_some_iff.mp h'
  obtain ⟨x, hx, rfl⟩ := Option.map_eq_some_iff.mp hr
  exact ⟨x.1.1, x.1.2.1, x.1.2.2, ⟨tapeAt tapes 0, x.2, hx⟩, rfl⟩

theorem theAlgL_run_succ_some (adv : StreamAdversary P.n) (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool)
    {t : ℕ} {c' : (State × Ghost) × List ℚ} (h : theAlgL.run P adv tapes (t + 1) = some c') :
    ∃ c, theAlgL.run P adv tapes t = some c ∧ ∃ (a : CState × ℚ) (o : OState) (g : Ghost),
      Outcome P (roundCode P c.1.1.ctrl (adv c.2).1.val (adv c.2).2) c.1.1.orc c.1.2 a o g ∧
        c' = ((State.mk' a.1 o, g), c.2 ++ [a.2]) := by
  obtain ⟨c, hc, s', q, rest, hs, rfl⟩ := run_succ_some h
  refine ⟨c, hc, ?_⟩
  have hs' : (((runL P (roundCode P c.1.1.ctrl (adv c.2).1.val (adv c.2).2) c.1.1.orc c.1.2).map
      fun r => ((State.mk' r.1.1 r.2.1, r.2.2), r.1.2)).merge.run (tapeAt tapes (t + 1))) =
      some ((s', q), rest) := hs
  rw [TBitProg.merge_map, BitProg.run_map] at hs'
  obtain ⟨x, hx, hxe⟩ := Option.map_eq_some_iff.mp hs'
  have h1 : ((State.mk' x.1.1.1 x.1.2.1, x.1.2.2) : State × Ghost) = s' := congrArg (fun y => y.1.1) hxe
  have h2 : x.1.1.2 = q := congrArg (fun y => y.1.2) hxe
  refine ⟨x.1.1, x.1.2.1, x.1.2.2, ⟨tapeAt tapes (t + 1), x.2, hx⟩, ?_⟩
  subst h1 h2
  rfl

/-- The call logs of the canonical run only grow. -/
theorem calls_prefix_run (adv : StreamAdversary P.n) (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) :
    ∀ (k t : ℕ) (c c' : (State × Ghost) × List ℚ), theAlgL.run P adv tapes t = some c →
      theAlgL.run P adv tapes (t + k) = some c' → c.1.2.calls <+: c'.1.2.calls := by
  intro k
  induction k with
  | zero =>
    intro t c c' hc hc'
    rw [Nat.add_zero, hc] at hc'
    cases hc'
    exact List.prefix_refl _
  | succ k ih =>
    intro t c c' hc hc'
    rw [← Nat.add_assoc] at hc'
    obtain ⟨c1, hc1, a, o, g, hout, rfl⟩ := theAlgL_run_succ_some adv tapes hc'
    exact (ih t c c1 hc hc1).trans (outcome_calls_prefix P _ _ _ _ _ _ hout).1

/-! ## The induction -/

theorem seqVec_zero_eq {n : ℕ} (us : ℕ → Fin n × ℤ) : seqVec us 0 = updVec 0 (us 0).1 (us 0).2 := by
  funext i
  rw [seqVec_zero]
  unfold updVec
  by_cases h : (us 0).1 = i
  · subst h; simp
  · rw [if_neg h, Function.update_of_ne (Ne.symm h)]; rfl

theorem seqVec_succ_eq {n : ℕ} (us : ℕ → Fin n × ℤ) (t : ℕ) :
    seqVec us (t + 1) = updVec (seqVec us t) (us (t + 1)).1 (us (t + 1)).2 := by
  funext i
  rw [seqVec_succ]
  unfold updVec
  by_cases h : (us (t + 1)).1 = i
  · subst h; simp
  · rw [if_neg h, Function.update_of_ne (Ne.symm h)]; simp

theorem theAlg_run_of_L {adv : StreamAdversary P.n} {tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool} {t : ℕ}
    {c : (State × Ghost) × List ℚ} (hc : theAlgL.run P adv tapes t = some c) :
    theAlg.run P adv tapes t = some (c.1.1, c.2) := by
  rw [← run_theAlgL P adv tapes t, hc]
  rfl

/-- **One round of the canonical run** (round `t < m`, the box promise up to `t`): the invariant after the round
and the accuracy of its estimate, on the fingerprint event and the bank events of the final log. -/
theorem round_post (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (hfp : ¬ FpFalseZero P adv tapes)
    (gF : Ghost) (hgood : GoodLog P gF)
    (hpre : ∀ t ≤ P.m, ∀ c, theAlgL.run P adv tapes t = some c → c.1.2.calls <+: gF.calls) :
    ∀ t, t < P.m → BoxUpTo P.U adv (theAlg.outs P adv tapes) t → ∀ c, theAlgL.run P adv tapes (t + 1) = some c →
      RoundInv P (seqVec (advUpdate adv (theAlg.outs P adv tapes)) t) (t + 1) c.1.1 c.1.2 ∧
        EstOK ((1 / 2 : ℝ) ^ P.epsExp) (seqVec (advUpdate adv (theAlg.outs P adv tapes)) t) (c.2.getD t 0) := by
  intro t
  induction t with
  | zero =>
    intro htm hbox c hc
    obtain ⟨c0, hc0, a, o, g, hout, rfl⟩ := theAlgL_run_succ_some adv tapes hc
    obtain ⟨a0, o0, g0, hout0, rfl⟩ := theAlgL_run_zero_some adv tapes hc0
    have hinit : InitState P a0 o0 g0 := wp_initCode g0.calls a0 o0 g0 hout0 (List.prefix_refl _)
    have hrun0 := theAlg_run_of_L hc0
    have hus0 : advUpdate adv (theAlg.outs P adv tapes) 0 = adv [] := advUpdate_outs_of_run hrun0
    have hseq : seqVec (advUpdate adv (theAlg.outs P adv tapes)) 0 = updVec 0 (adv []).1 (adv []).2 := by
      rw [seqVec_zero_eq, hus0]
    have hf0 : (State.mk' a0 o0).failed = false := by rw [hinit.ctrl]; rfl
    have hfpt := fpZeroTest_iff_seqVec_eq_zero P adv tapes hfp htm hbox hrun0 hf0
    rw [hseq] at hfpt
    have hbox' : ∀ j, |updVec (0 : Fin P.n → ℤ) (adv []).1 (adv []).2 j| ≤ (P.U : ℤ) := by
      rw [← hseq]; exact hbox 0 le_rfl
    have hwp := wp_round_init hP gF rfl hgood (s := State.mk' a0 o0) (g := g0) hinit (adv []).1 (adv []).2
      hbox' hfpt
    obtain ⟨hR, -, hacc⟩ := hwp a o g hout (hpre 1 htm _ hc)
    rw [hseq]
    exact ⟨hR, by simpa using hacc⟩
  | succ t ih =>
    intro htm hbox c hc
    obtain ⟨ct, hct, a, o, g, hout, rfl⟩ := theAlgL_run_succ_some adv tapes hc
    have hR := (ih (by omega) (boxUpTo_mono hbox (Nat.le_succ t)) ct hct).1
    have hrun := theAlg_run_of_L hct
    have hust : advUpdate adv (theAlg.outs P adv tapes) (t + 1) = adv ct.2 := advUpdate_outs_of_run hrun
    have hseq : seqVec (advUpdate adv (theAlg.outs P adv tapes)) (t + 1) =
        updVec (seqVec (advUpdate adv (theAlg.outs P adv tapes)) t) (adv ct.2).1 (adv ct.2).2 := by
      rw [seqVec_succ_eq, hust]
    have hfpt := fpZeroTest_iff_seqVec_eq_zero P adv tapes hfp htm hbox hrun hR.joint.notFailed
    rw [hseq] at hfpt
    have hbox_x : ∀ j, |seqVec (advUpdate adv (theAlg.outs P adv tapes)) t j| ≤ (P.U : ℤ) :=
      hbox t (Nat.le_succ t)
    have hbox' : ∀ j, |updVec (seqVec (advUpdate adv (theAlg.outs P adv tapes)) t) (adv ct.2).1 (adv ct.2).2 j| ≤
        (P.U : ℤ) := by
      rw [← hseq]; exact hbox (t + 1) le_rfl
    have hwp := wp_round hP gF rfl hgood hR (by omega) (adv ct.2).1 (adv ct.2).2 hbox_x hbox' hfpt
    obtain ⟨hR', -, hacc⟩ := hwp a o g hout (hpre (t + 2) htm _ hc)
    have hlen : ct.2.length = t + 1 := run_length hct
    rw [hseq]
    refine ⟨hR', ?_⟩
    have : (ct.2 ++ [a.2]).getD (t + 1) 0 = a.2 := by
      rw [List.getD_append_right _ _ _ _ (by omega), hlen, Nat.sub_self]
      rfl
    rw [this]
    exact hacc

/-- **Every round before the first box violation is accurate** on the good events. -/
theorem accurate_main (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (hfp : ¬ FpFalseZero P adv tapes)
    (hbank : BankGood P adv tapes) :
    StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (theAlg.outs P adv tapes) := by
  have htot := run_isSome_of_depth (A := theAlgL) (P := P) adv (algInitL P).merge
    (fun sg u => (algStepL P sg u).merge) (fun _ => rfl) (fun _ _ _ => rfl) (theAlgL_init_depth P)
    (fun sg u => theAlgL_step_depth P sg u) tapes
  obtain ⟨cF, hcF⟩ := htot P.m le_rfl
  have hgood : GoodLog P cF.1.2 := hbank cF hcF
  have hpre : ∀ t ≤ P.m, ∀ c, theAlgL.run P adv tapes t = some c → c.1.2.calls <+: cF.1.2.calls := by
    intro t ht c hc
    exact calls_prefix_run adv tapes (P.m - t) t c cF hc (by rw [Nat.add_sub_cancel' ht]; exact hcF)
  intro t ht hbox
  obtain ⟨c, hc⟩ := htot (t + 1) ht
  have hpost := (round_post hP adv tapes hfp cF.1.2 hgood hpre t ht hbox c hc).2
  have hrun := theAlg_run_of_L hc
  have houts : theAlg.outs P adv tapes t = c.2.getD t 0 := outs_eq_of_run hrun t (Nat.lt_succ_self t)
  rw [houts]
  exact hpost

end F2e2e.C.Closure
