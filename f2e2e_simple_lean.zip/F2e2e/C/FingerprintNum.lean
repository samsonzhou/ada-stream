import F2e2e.C.ParamsDefs
import F2e2e.Lib.Discrete.Sampler

/-!
# Numerics and the seed law of the zero fingerprint

Paper: `parts/partII.tex` Algorithm `R:alg:zero-fingerprint` (L219) and Lemma
`R:lem:zero-fingerprint` (L234–237, proof L263, L267, L283–285); `notes/PAPER_MAP_II_a.md` §II.1.9,
numeric facts and E1, E6.

* `q_prime`, `Mq_le_q`: `q` is the least prime `≥ M_q = ⌈10 n m (U+1)/β₀⌉³`
  (`= (10 n m (U+1) 2^{betaExp})³`, eq. `R:eq:prime-q-bound`);
* `U_lt_q`: the box bound `U < q` (L277);
* `mn_div_q_le`: `m n/q ≤ β₀/1000` (L283);
* `half_pow_seedTrials_le`: `2^{-⌈log₂(1000/β₀)⌉} = 2^{-(betaExp+10)} ≤ β₀/1000` (L267);
* `fp_budget`: `m n/q + 2^{-(betaExp+10)} ≤ 2β₀/1000 ≤ β₀/8` (eq. `R:eq:fingerprint-collision-prob`);
* `law_seed_le`: the capped rejection sampler with fallback `0` (L219: `⌈log₂ q⌉` fresh bits per
  trial, accept if `< q`) has law at most uniform on `{0, …, q-1}` plus the failure mass
  `2^{-trials}` at `0` (the coupling of L267).
-/

namespace F2e2e.C.FP

open F2e2e F2e2e.Discrete
open scoped ENNReal

/-! ### The modulus -/

theorem q_spec (P : StreamParams) : P.Mq ≤ P.q ∧ P.q.Prime :=
  Nat.find_spec (StreamParams.exists_prime_ge P.Mq)

theorem q_prime (P : StreamParams) : P.q.Prime := (q_spec P).2

theorem Mq_le_q (P : StreamParams) : P.Mq ≤ P.q := (q_spec P).1

theorem q_pos (P : StreamParams) : 0 < P.q := (q_prime P).pos

/-- `1000 m n 2^{betaExp} ≤ M_q` (for `n, m ≥ 1`). -/
theorem mn_mul_le_Mq (P : StreamParams) (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) :
    1000 * (P.m * P.n) * 2 ^ P.betaExp ≤ P.Mq := by
  unfold StreamParams.Mq
  have h2 : 1 ≤ 2 ^ P.betaExp := Nat.one_le_two_pow
  set a := 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp with ha
  have hU : 1 ≤ P.U + 1 := Nat.le_add_left 1 P.U
  have hge : 10 * P.n * P.m * 2 ^ P.betaExp ≤ a := by
    rw [ha]
    calc 10 * P.n * P.m * 2 ^ P.betaExp = 10 * P.n * P.m * 1 * 2 ^ P.betaExp := by ring
      _ ≤ 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp := by gcongr
  have h1 : 1 ≤ 10 * P.n * P.m * 2 ^ P.betaExp := by
    have : 1 ≤ P.n * P.m := Nat.one_le_iff_ne_zero.mpr (by positivity)
    nlinarith
  calc 1000 * (P.m * P.n) * 2 ^ P.betaExp ≤ (10 * P.n * P.m * 2 ^ P.betaExp) ^ 3 := by
        have e : (10 * P.n * P.m * 2 ^ P.betaExp) ^ 3 =
            1000 * (P.m * P.n) * 2 ^ P.betaExp * ((P.n * P.m * 2 ^ P.betaExp) ^ 2) := by ring
        rw [e]
        have : 1 ≤ (P.n * P.m * 2 ^ P.betaExp) ^ 2 := Nat.one_le_pow _ _ (by positivity)
        calc 1000 * (P.m * P.n) * 2 ^ P.betaExp = 1000 * (P.m * P.n) * 2 ^ P.betaExp * 1 := by ring
          _ ≤ _ := Nat.mul_le_mul_left _ this
    _ ≤ a ^ 3 := Nat.pow_le_pow_left hge 3

/-- The box bound `U < q` (paper L277: `‖x‖_∞ ≤ U < q`). -/
theorem U_lt_q (P : StreamParams) (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) : P.U < P.q := by
  refine lt_of_lt_of_le ?_ (Mq_le_q P)
  unfold StreamParams.Mq
  have h2 : 1 ≤ 2 ^ P.betaExp := Nat.one_le_two_pow
  set a := 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp with ha
  have hge : P.U + 1 ≤ a := by
    rw [ha]
    have : 1 ≤ 10 * P.n * P.m := by nlinarith
    calc P.U + 1 = 1 * (P.U + 1) * 1 := by ring
      _ ≤ (10 * P.n * P.m) * (P.U + 1) * 2 ^ P.betaExp := by gcongr
  have : a ≤ a ^ 3 := by
    calc a = a ^ 1 := (pow_one a).symm
      _ ≤ a ^ 3 := Nat.pow_le_pow_right (by omega) (by norm_num)
  omega

/-! ### The failure budget -/

/-- `m n/q ≤ β₀/1000` (paper L283). -/
theorem mn_div_q_le (P : StreamParams) (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) :
    ((P.m * P.n : ℕ) : ℝ) / P.q ≤ (1 / 2 : ℝ) ^ P.betaExp / 1000 := by
  have hq : (0 : ℝ) < P.q := by exact_mod_cast q_pos P
  have hkey : (1000 * (P.m * P.n) * 2 ^ P.betaExp : ℝ) ≤ P.q := by
    have := le_trans (mn_mul_le_Mq P hn hm) (Mq_le_q P)
    exact_mod_cast this
  rw [div_le_div_iff₀ hq (by norm_num), one_div_pow, div_mul_eq_mul_div, le_div_iff₀ (by positivity)]
  push_cast
  linarith

/-- `2^{-(betaExp+10)} ≤ β₀/1000` (paper L267: `2^{-⌈log₂(1000/β₀)⌉} ≤ β₀/1000`). -/
theorem half_pow_seedTrials_le (P : StreamParams) :
    (1 / 2 : ℝ) ^ P.seedTrials ≤ (1 / 2 : ℝ) ^ P.betaExp / 1000 := by
  unfold StreamParams.seedTrials
  rw [pow_add]
  have h : (1 / 2 : ℝ) ^ 10 ≤ 1 / 1000 := by norm_num
  calc (1 / 2 : ℝ) ^ P.betaExp * (1 / 2) ^ 10 ≤ (1 / 2 : ℝ) ^ P.betaExp * (1 / 1000) :=
        mul_le_mul_of_nonneg_left h (by positivity)
    _ = (1 / 2 : ℝ) ^ P.betaExp / 1000 := by ring

/-- **The fingerprint failure budget** (eq. `R:eq:fingerprint-collision-prob`):
`m n/q + 2^{-(betaExp+10)} ≤ 2 β₀/1000`, and `2 β₀/1000 ≤ β₀/8`. -/
theorem fp_budget (P : StreamParams) (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) :
    ((P.m * P.n : ℕ) : ℝ) / P.q + (1 / 2 : ℝ) ^ P.seedTrials ≤
      2 * ((1 / 2 : ℝ) ^ P.betaExp / 1000) := by
  have h1 := mn_div_q_le P hn hm
  have h2 := half_pow_seedTrials_le P
  linarith

theorem two_div_thousand_le_eighth (b : ℕ) :
    2 * ((1 / 2 : ℝ) ^ b / 1000) ≤ (1 / 2 : ℝ) ^ b / 8 := by
  have : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ b := by positivity
  linarith

/-! ### The seed law -/

/-- **The law of the capped rejection sampler with fallback `0`** (Algorithm
`R:alg:zero-fingerprint`, L219; the coupling of L267): for `q ≥ 1`, every value has probability at
most `[r < q]/q + [r = 0] 2^{-trials}`. -/
theorem law_seed_le {q : ℕ} (hq : 1 ≤ q) (K : ℕ) (r : ℕ) :
    ((rejectUniform q (Nat.clog 2 q) K).map fun o => o.getD 0).law r ≤
      (if r < q then (q : ℝ≥0∞)⁻¹ else 0) + (if r = 0 then 2⁻¹ ^ K else 0) := by
  have hD : q ≤ 2 ^ Nat.clog 2 q := Nat.le_pow_clog (by norm_num) q
  set p := rejectUniform q (Nat.clog 2 q) K with hp
  have hsome : p.law (some r) ≤ if r < q then (q : ℝ≥0∞)⁻¹ else 0 := by
    by_cases hr : r < q
    · rw [if_pos hr, hp, law_rejectUniform_some hD K hr]
      exact ENNReal.div_le_of_le_mul (by
        rw [ENNReal.inv_mul_cancel (by exact_mod_cast (show q ≠ 0 by omega)) (by simp)]
        exact tsub_le_self)
    · rw [if_neg hr, hp, law_rejectUniform_some_of_le q _ K (not_lt.mp hr)]
  have hnone : p.law none ≤ 2⁻¹ ^ K := law_rejectUniform_none_le hq K
  rw [BitProg.law_map, PMF.map_apply]
  -- only the outcomes `some r` and `none` can map to `r`
  rw [tsum_eq_sum (s := {some r, none}) (fun o ho => by
    simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at ho
    cases o with
    | none => exact absurd rfl ho.2
    | some x =>
      have hx : r ≠ x := fun h => ho.1 (by rw [h])
      simp [Option.getD, hx])]
  rw [Finset.sum_pair (by simp)]
  by_cases hr0 : r = 0
  · subst hr0
    simp only [Option.getD_some, Option.getD_none, if_true]
    exact add_le_add hsome (by simpa using hnone)
  · simp only [Option.getD_some, Option.getD_none, if_true, hr0, if_false, add_zero]
    exact hsome

end F2e2e.C.FP
