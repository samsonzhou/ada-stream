import Mathlib
import F2e2e.C.Alg.Bank
import F2e2e.C.Alg.Fingerprint

/-!
# The streaming algorithm of Theorem C: one round (Algorithms 1 and 4) and initialization

Sources: `parts/partII.tex` Algorithm `R:alg:zero-fingerprint` (L216–231); `parts/partIII.tex`
Definition `R:def:binary-tree-architecture` (L429–443), Definition `R:def:total-behavior`
(L445–464) and Algorithm `R:alg:within-round-tree` (L466–517).

The round procedure `roundStep P s i Δ` processes the update `x_{i+1} ← x_{i+1} + Δ` (`i` is the
0-based coordinate handed over by the Spec; the paper's coordinates are 1-based) and returns the new
state and the estimate `F̂_t ≥ 0`:
* Step 1 (`step1`, L472–478): scheduled retirements and births (Definition 5.1);
* Step 2 (`step2`, L480–484): fingerprint, counters, terminal accumulator, zero-round bypass;
* Step 3 (`step3`, L486–493): top-down guards `d = 0, …, H−1`;
* Step 4 (`step4`, L495–513): terminal value, then bottom-up validation, single local correction,
  descendant rescaling and cache refresh `d = H−1, …, 0`.

Totality (Definition `R:def:total-behavior`): counters are saturated; tags are range-checked against
`[0, C_max]`; caches, candidates, returned geometric estimates and the terminal accumulator against
`[0, A_max]` (after computing and before storing); a rejection with `P ≤ 0` or `Q̂ ≤ 0` fails; step
coefficients are clamped; client, epoch, bank and ADA caps are enforced; every failure sets the
absorbing `failed` flag, and a failed algorithm reports `0` in that round and every later round
without reading bits or changing its memory (L456–457).

Decisions where the pseudocode leaves a choice (all irrelevant on the good event; recorded for the
red team):
* (a) every failed check (range, cap, positive-denominator rule, ADA `TERMINAL_REJECT` or
  `CAP_ABORT`, exhausted coarse groups) enters the failure state; the round in which it happens
  reports `0` (L456–457: "A bank's terminal rejection certificate is returned before the global
  failure state is entered … In the failure state, the algorithm reports zero thereafter");
* (b) the client cap `J_used < J_*` is checked before the correction (L502); the epoch cap
  `k_d ≤ K_epoch` (L440) fails if an epoch increment would exceed it;
* (c) "the birth prefix is deterministically known to be zero" (L477) ⇔ `d = 0` (the root has
  `a_0 = 0`, L437) or the parent `d − 1` is born in the same round;
* (d) the post-use `c²` updates of the terminal accumulator (L507) are kept, with their range check;
* (e) consumed coarse groups are dropped (the next reserved group is the head of the list);
* (f) the per-depth order of Step 1 is the box's line order: reset of the incoming secondary
  array (L475), allocation of the outgoing bank (L476), birth cache (L477).
-/

namespace F2e2e.C.Alg

open F2e2e.B

open F2e2e.Discrete

/-! ## The schedule (Definition 5.1 (1), partIII.tex L431) -/

/-- Depth `d < H` has the scheduled lifetimes `[1 + j 2^{H-1-d}, (j+1) 2^{H-1-d}]` (the fixed dyadic
intervals of `[1, 2^{H-1}]`); it is (re)born at the start of round `tr ≥ 1` iff
`2^{H-1-d} ∣ tr − 1`. -/
def bornAt (H d tr : ℕ) : Bool := (tr - 1) % 2 ^ (H - 1 - d) == 0

/-- The shallowest depth born at the start of round `tr`. Lifetimes are nested, so the depths born
at round `tr` are `firstBorn H tr, …, H − 1` (depth `H − 1` is born every round). -/
def firstBorn (H tr : ℕ) : ℕ := (List.range H).findIdx (fun d => bornAt H d tr)

/-! ## Step 1: scheduled retirements and births (partIII.tex L472–478) -/

/-- A freshly allocated learner (L474: `u = q = 0`, `Ĉ = 1`, `k = 0`, `j_epoch = J_used = 0`) with
the birth cache `cache` (mantissa on `h_P`). -/
def newLearner (P : StreamParams) (cache : ℤ) : Learner := ⟨2 ^ P.eHC, cache, 0, 0, 0⟩

/-- Step 1 for one newly born depth `d`, when `d₀` is the shallowest depth born this round:
* (L475) retain the incoming primary array of `𝓑_{d-1}` (bank index `d`) and reset its
  client-secondary array to zero;
* (L476) allocate the new outgoing bank `𝓑_d` (bank index `d + 1`) if `d ≤ H − 2`;
* (L477) the birth cache: `P = 0` if the birth prefix is deterministically known to be zero
  (decision (c): `d = 0` or `d > d₀`), otherwise `P = round_{h_P}(𝓑_{d-1}.ReleaseNumerical(PRIMARY))`
  (range-checked against `[0, A_max]`).
The learner record (L474) is appended last. -/
def birthDepth (P : StreamParams) (d0 d : ℕ) (s : State) : BitProg State := do
  let s1 : State := { s with banks := modifyAt (Bank.mapRows Row.resetY) d s.banks }
  let s2 ← (if d + 2 ≤ P.H then
      (do
        let B ← newBank P
        pure { s1 with banks := s1.banks ++ [B] })
    else pure s1)
  if d = 0 ∨ d0 < d then
    pure { s2 with learners := s2.learners ++ [newLearner P 0] }
  else
    match s2.banks[d]? with
    | none => pure s2.fail
    | some B => do
      let res ← B.release P Mode.primary
      -- the bank returned by the call is stored at once (the call happened)
      let s3 : State := { s2 with banks := setAt res.2 d s2.banks }
      match res.1 with
      | none => pure s3.fail
      | some N =>
        let cache := roundMant P.eHP N
        if inRangeA P (gridVal P.eHP cache) then
          pure { s3 with learners := s2.learners ++ [newLearner P cache] }
        else pure s3.fail

/-- The births of the depths in `ds` (shallowest first), stopping at a failure. -/
def birthLoop (P : StreamParams) (d0 : ℕ) : List ℕ → State → BitProg State
  | [], s => pure s
  | d :: ds, s =>
    if s.failed then pure s
    else do
      let s' ← birthDepth P d0 d s
      birthLoop P d0 ds s'

/-- Step 1 of round `t + 1` (L472–478): retire the expiring suffix of the live path (learners of
depth `≥ d₀` and the banks they own) before allocating replacements, allocate the new nonleaves
`d₀, …, H − 1` from shallowest to deepest, and initialize the new terminal accumulator to zero.
"Do this even on physical-zero rounds" (L477): Step 1 precedes the zero test. -/
def step1 (P : StreamParams) (s : State) : BitProg State := do
  let d0 := firstBorn P.H (s.t + 1)
  let s1 : State := { s with learners := s.learners.take d0, banks := s.banks.take (d0 + 1) }
  let s2 ← birthLoop P d0 (List.range' d0 (P.H - d0)) s1
  pure { s2 with leaf := 0 }

/-! ## Step 2: physical update and zero bypass (partIII.tex L480–484) -/

/-- Step 2 for the update `(i, Δ)` (0-based coordinate `i`, i.e. the paper's `i_t = i + 1`):
* (L481) the zero fingerprint (Algorithm 1 line 3);
* (L482) in every live bank add `Δ b_{i_t}` once to each primary and secondary array;
* (L483) set the terminal accumulator to `Δ²` (range-checked against `[0, A_max]`).
Returns the new state and whether `F_zero^{(t)} = 0` (L484: then report zero and omit Steps 3–4). -/
def step2 (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) : State × Bool :=
  let fp := fpUpdate P s.fpSeed s.fpVal (i + 1) Δ
  let banks := s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ))
  let leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2)
  let s' : State := { s with fpVal := fp, banks := banks }
  if inRangeA P (gridVal P.eHleaf leaf) then ({ s' with leaf := leaf }, fp == 0)
  else (s'.fail, fp == 0)

/-! ## Step 3: top-down guards (partIII.tex L486–493) -/

/-- The exponent `α = q_g − q_C − q_γ − 2` of `guardMant`. -/
def guardAlpha (P : StreamParams) : ℤ := (P.eHg : ℤ) - P.eHC - P.eGamma - 2

/-- Step 3 at depth `d` of round `tr` (L488–491):
`g = g(d,t) = n + H(t−1) + d + 1`, `δ̃_d = (γ/4)√(2^{-k_d} 𝒰_{d,0})`, `δ_d = 0` if
`Ĉ_d δ̃_d < 2h_g`, else `round_{h_g}(Ĉ_d δ̃_d)`; if `δ_d ≠ 0`, add `δ_d e_g` once to `Y_d` (bank
`𝓑_{d-1}`, index `d`) and once to both arrays of every strict nonleaf descendant (banks
`𝓑_d, …, 𝓑_{H-2}`, indices `d+1, …, H−1`), update `P_d ← round_{h_P}(P_d + δ_d²)` and add `δ_d²` to
the terminal accumulator (exact on `h_leaf`), both range-checked. -/
def step3Depth (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) : State :=
  match s.learners[d]? with
  | none => s.fail
  | some Ld =>
    let g := P.guardCoord d tr
    let δ := guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))
    if δ = 0 then s
    else
      let banks := modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d s.banks
      let banks := mapFrom (Bank.mapRows (Row.addGuardXY P g δ)) (d + 1) banks
      let δv : ℚ := gridVal P.eHg δ
      let cache := roundMant P.eHP (gridVal P.eHP Ld.cache + δv ^ 2)
      let leaf := roundMant P.eHleaf (gridVal P.eHleaf s.leaf + δv ^ 2)
      let s' : State := { s with banks := banks }
      if inRangeA P (gridVal P.eHP cache) && inRangeA P (gridVal P.eHleaf leaf) then
        { s' with learners := setAt { Ld with cache := cache } d s.learners, leaf := leaf }
      else s'.fail

/-- Step 3 for the depths in `ds` (in order), stopping at a failure. -/
def step3Loop (P : StreamParams) (tr : ℕ) : List ℕ → State → State
  | [], s => s
  | d :: ds, s => if s.failed then s else step3Loop P tr ds (step3Depth P tr s d)

/-- Step 3 of round `t + 1`: `d = 0, …, H − 1`. -/
def step3 (P : StreamParams) (s : State) : State := step3Loop P (s.t + 1) (List.range P.H) s

/-! ## Step 4: terminal and bottom-up evaluation (partIII.tex L495–513) -/

/-- The rescaling of a strict nonleaf descendant learner by `c = cInt h_step` (L506): its tag by `c`
(rounded on `h_C`) and its cache by `c²` (rounded on `h_P`). -/
def Learner.rescale (P : StreamParams) (cInt : ℤ) (L : Learner) : Learner :=
  { L with tag := scaleMant P.eHstep cInt L.tag,
           cache := scaleMant (2 * P.eHstep) (cInt ^ 2) L.cache }

/-- Increment the local counters after a correction (L509): `J_used += 1`, `j_epoch += 1`; after
`K_0 = ⌈128/η²⌉` corrections increment `k_d` and reset the intra-epoch counter. `none` if `k_d` would
exceed `K_epoch` (decision (b)). -/
def Learner.countCorrection (P : StreamParams) (L : Learner) : Option Learner :=
  if L.jEpoch + 1 = P.K0 then
    if L.epoch + 1 ≤ P.Kepoch then
      some { L with jUsed := L.jUsed + 1, jEpoch := 0, epoch := L.epoch + 1 }
    else none
  else some { L with jUsed := L.jUsed + 1, jEpoch := L.jEpoch + 1 }

/-- The tail of Step 4's rejection branch at depth `d` (L506–510), after `N₁` was obtained (bank
index `d` already updated) and the multiplier `c = cInt h_step` computed: rescale the strict nonleaf
descendants and the terminal accumulator, refresh `P_d` by `ReleaseNumerical(DIFF)`, count the
correction, and return `F = N₁`. -/
def rejectTail (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (s : State) :
    BitProg (State × ℚ) :=
  -- (L506) both arrays of every strict nonleaf descendant, its tag by `c` and its cache by `c²`
  let banks := mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks
  let learners := mapFrom (Learner.rescale P cInt) (d + 1) s.learners
  -- (L507) the terminal accumulator, exactly by `c²`
  let leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf)
  -- the rescaled tags, caches and accumulator are range-checked before they are stored (L453)
  if ((learners.drop (d + 1)).all (Learner.inRange P) && inRangeA P (gridVal P.eHleaf leaf)) then
    let s1 : State := { s with banks := banks, learners := learners, leaf := leaf }
    match s1.banks[d]? with
    | none => pure (s1.fail, 0)
    | some Bd => do
      -- (L508) refresh `P_d ← round_{h_P}(ReleaseNumerical(DIFF(X_d − Y_d)))`
      let r2 ← Bd.release P Mode.diff
      -- the bank returned by the call is stored at once (the call happened)
      let s2 : State := { s1 with banks := setAt r2.2 d s1.banks }
      match r2.1 with
      | none => pure (s2.fail, 0)
      | some N2 =>
        let cache := roundMant P.eHP N2
        -- (L509) the local counters and the epoch
        match Learner.countCorrection P { Ld with cache := cache } with
        | none => pure (s2.fail, 0)
        | some Ld' =>
          if inRangeA P (gridVal P.eHP cache) then
            -- (L510) `F = N₁(x_d)`, without reevaluating the child
            pure ({ s2 with learners := setAt Ld' d s1.learners }, N1)
          else pure (s2.fail, 0)
  else pure ({ s with banks := banks }.fail, 0)

/-- Step 4's rejection branch at depth `d` with protected sign `s` (`pos = true` iff `HIGH`,
`s = +1`, partIII.tex L800) and candidate child estimate `Q̂_d` (L501–510):
* (L502) enforce the client cap (`J_used < J_*`) and the positive-denominator rule (`P_d > 0`,
  `Q̂_d > 0`);
* (L503) obtain `N₁(x_d) = 𝓑_{d-1}.ReleaseNumerical(PRIMARY)` (range-checked: it is returned);
* (L504) `a_step = clamp_{[-1/2,1/2]} round_{h_step}(s (η/16) √(P_d/Q̂_d))`, `c = 1 + a_step`;
* (L505) multiply `Y_d` (bank `𝓑_{d-1}`, index `d`) once by `c`;
* (L506–510) `rejectTail`. -/
def rejectDepth (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State) :
    BitProg (State × ℚ) :=
  match s.learners[d]?, s.banks[d]? with
  | some Ld, some Bd =>
    if P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ Qhat ≤ 0 then pure (s.fail, 0)
    else do
      let r1 ← Bd.release P Mode.primary
      -- the bank returned by the call is stored at once (the call happened)
      let s1 : State := { s with banks := setAt r1.2 d s.banks }
      match r1.1 with
      | none => pure (s1.fail, 0)
      | some N1 =>
        if inRangeA P N1 then
          let cInt := stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat
          let banks := modifyAt (Bank.mapRows (Row.scaleY P cInt)) d s1.banks
          rejectTail P d Ld cInt N1 { s1 with banks := banks }
        else pure (s1.fail, 0)
  | _, _ => pure (s.fail, 0)

/-- Step 4 at depth `d` with the current returned value `F` (L498–511): `ℓ = H − d`, `Q̂_d = F`,
`S_d = P_d + Q̂_d` (range-checked: a candidate), `θ_ℓ = (8ℓ + 4)η`; call the incoming bank's
`ValidateInterval(x_d, S_d, θ_ℓ)`; on `ACCEPT` set `F = S_d` (L500); on `HIGH`/`LOW` run the
rejection branch; a terminal rejection or an abort enters the failure state (decision (a)). -/
def step4Depth (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) : BitProg (State × ℚ) :=
  match s.learners[d]?, s.banks[d]? with
  | some Ld, some Bd =>
    let Qhat := F
    let S := gridVal P.eHP Ld.cache + Qhat
    if inRangeA P S then do
      let θ : ℚ := (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta
      let res ← Bd.validate P S θ
      let s1 : State := { s with banks := setAt res.2 d s.banks }
      match res.1 with
      | AdaCert.accept => pure (s1, S)
      | AdaCert.high => rejectDepth P d true Qhat s1
      | AdaCert.low => rejectDepth P d false Qhat s1
      | _ => pure (s1.fail, 0)
    else pure (s.fail, 0)
  | _, _ => pure (s.fail, 0)

/-- Step 4 for the depths in `ds` (in order), threading the returned value, stopping at a
failure. -/
def step4Loop (P : StreamParams) : List ℕ → State → ℚ → BitProg (State × ℚ)
  | [], s, F => pure (s, F)
  | d :: ds, s, F =>
    if s.failed then pure (s, F)
    else do
      let r ← step4Depth P d s F
      step4Loop P ds r.1 r.2

/-- Step 4 (L495–513): `F` := the exact terminal accumulator (L496), then `d = H − 1, …, 0`; the
root's `F` is reported (L513). -/
def step4 (P : StreamParams) (s : State) : BitProg (State × ℚ) :=
  step4Loop P (List.range P.H).reverse s (gridVal P.eHleaf s.leaf)

/-! ## One round, initialization, and the algorithm -/

/-- Close a round: count it and report `F` (or `0` if the state has failed). -/
def finishRound (s : State) (F : ℚ) : State × ℚ :=
  ({ s with t := s.t + 1 }, if s.failed then 0 else F)

/-- One round (Algorithm 1 lines 2–9 with Algorithm 4's Steps 1–4) for the update
`x_{i+1} ← x_{i+1} + Δ`: returns the new state and the estimate `F̂_t`. A failed state reports `0`
and does nothing else. -/
def roundStep (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) : BitProg (State × ℚ) :=
  if s.failed then pure (finishRound s 0)
  else do
    let s1 ← step1 P s
    if s1.failed then pure (finishRound s1 0)
    else
      let r2 := step2 P i Δ s1
      if r2.1.failed || r2.2 then pure (finishRound r2.1 0)
      else
        let s3 := step3 P r2.1
        if s3.failed then pure (finishRound s3 0)
        else do
          let r4 ← step4 P s3
          pure (finishRound r4.1 r4.2)

/-- Initialization (Algorithm 1 line 1, partII.tex L219; Definition 5.1 (2), partIII.tex L432: the
root incoming bank `𝓑_{-1}` is initialized at time zero): sample the fingerprint seed, set
`F_zero = 0`, allocate `𝓑_{-1}`. No learner is live before round 1 (all depths are born at the
start of round 1). -/
def initState (P : StreamParams) : BitProg State := do
  let r ← fpSeedProg P
  let B ← newBank P
  pure ⟨0, false, r, 0, [], [B], 0⟩

/-- The streaming algorithm of Theorem C (mathematical form): initialization. -/
def algInit (P : StreamParams) : BitProg State := initState P

/-- The streaming algorithm of Theorem C (mathematical form): the program run on the update
`(i, Δ)` (0-based coordinate `i`), returning the new state and the estimate. -/
def algStep (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) : BitProg (State × ℚ) :=
  roundStep P s i Δ

/-- Run the initialization on a tape: the initial state and the unread rest of the tape (`none`
iff the tape is too short). -/
def initRun (P : StreamParams) (tape : List Bool) : Option (State × List Bool) :=
  (algInit P).run tape

/-- Run one round on a tape: the new state, the estimate, and the unread rest of the tape. -/
def stepRun (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) (tape : List Bool) :
    Option ((State × ℚ) × List Bool) :=
  (algStep P s i Δ).run tape

end F2e2e.C.Alg
