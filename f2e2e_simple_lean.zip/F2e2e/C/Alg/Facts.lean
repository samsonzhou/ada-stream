import Mathlib
import F2e2e.C.Alg.FactsAux
import F2e2e.C.Alg.Bits

/-!
# Facts about the Theorem C algorithm needed by the analysis

Statements about the concrete algorithm of `F2e2e/C/Alg/Round.lean` that Sections 1.5, 5 and 6 of
the paper use (per-step identities, exactness of the integer formulas, totality). All are proved
(helper lemmas in `F2e2e/C/Alg/FactsAux.lean`, which also contains `Always`, the schedule facts
`firstBorn_lt`, `firstBorn_one`, the per-step invariants `step1_frame`, `step1_shape`, `step2_*`,
`step3_pres`, `step4_out`, `roundStep_out`, and `guardOf`).

* `Always p Q`: every output of the bit program `p`, on every bit path, satisfies `Q`
  ("on every execution").
* Exactness of the integer formulas: `roundMant` is the paper's `round_h` (partII.tex L197);
  `guardMant` computes `δ_d` of Step 3 exactly (partIII.tex L488–489); `stepCoeffMant` computes
  `c = 1 + a_step` of Step 4 exactly (L504) and `c ∈ [1/2, 3/2]`; `scaleMant` is the rounded
  rescaling; `lowerMedian` lies in every interval containing a strict majority of the values (the
  form used by Lemma `R:lem:coarse-ams`, partIII.tex L81–85).
* Zero fingerprint (Lemma `R:lem:zero-fingerprint` (1)–(2), partII.tex L240–245): the homomorphic
  one-step recurrence; a fingerprint-zero round reports `0`.
* Lemma `R:lem:terminal-accumulator` (partIII.tex L519–525), algorithm side: when Step 4 starts, the
  terminal accumulator equals `Δ_t² + Σ_d δ_d²` exactly.
* Rescaling (Lemma `R:lem:homogeneous-child-rescaling`, partIII.tex L527–585, algorithm side): the
  rejection branch multiplies exactly the registers the lemma lists, on the prescribed grids.
* Totality (Definition `R:def:total-behavior`): every estimate lies in `[0, A_max]`; failure is
  absorbing and reports `0`; the schedule (Definition `R:def:binary-tree-architecture` (1)).
-/

namespace F2e2e.C.Alg

open F2e2e.B

open F2e2e.Discrete

/-! ## Exactness of the integer formulas -/

/-- `roundMant` is the paper's rounding `round_h(z) = h ⌊z/h + 1/2⌋` for `h = 2^{-q}`
(partII.tex L197). -/
theorem gridVal_roundMant (q : ℕ) (z : ℚ) :
    gridVal q (roundMant q z) = (1 / 2 : ℚ) ^ q * ⌊z / (1 / 2 : ℚ) ^ q + 1 / 2⌋ := by
  unfold gridVal roundMant
  have h : z / (1 / 2 : ℚ) ^ q = z * 2 ^ q := by
    rw [one_div, inv_pow, div_inv_eq_mul]
  rw [h, one_div, inv_pow]
  ring

/-- `|round_h(z) − z| ≤ h/2` (partII.tex L197). -/
theorem abs_gridVal_roundMant_sub_le (q : ℕ) (z : ℚ) :
    |gridVal q (roundMant q z) - z| ≤ (1 / 2 : ℚ) ^ q / 2 := by
  unfold gridVal roundMant
  have h1 := Int.floor_le (z * 2 ^ q + 1 / 2)
  have h2 := Int.lt_floor_add_one (z * 2 ^ q + 1 / 2)
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  have e : ((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) / 2 ^ q - z =
      (((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) - z * 2 ^ q) / 2 ^ q := by
    field_simp
  rw [e, abs_div, abs_of_pos hpos, div_le_iff₀ hpos]
  have e2 : (1 / 2 : ℚ) ^ q / 2 * 2 ^ q = 1 / 2 := by
    rw [one_div, inv_pow]; field_simp
  rw [e2, abs_le]
  constructor <;> linarith

/-- Rounded rescaling: `scaleMant qs cInt m` is the mantissa (on the grid `2^{-q}`, any `q`) of
`round_{2^{-q}}(c · m 2^{-q})` for the multiplier `c = cInt 2^{-qs}`. -/
theorem gridVal_scaleMant (q qs : ℕ) (cInt m : ℤ) :
    gridVal q (scaleMant qs cInt m) =
      (1 / 2 : ℚ) ^ q * ⌊gridVal qs cInt * gridVal q m / (1 / 2 : ℚ) ^ q + 1 / 2⌋ := by
  unfold gridVal scaleMant roundMant
  have h : (cInt : ℚ) / 2 ^ qs * ((m : ℚ) / 2 ^ q) / (1 / 2 : ℚ) ^ q =
      (cInt : ℚ) * m / 2 ^ qs * 2 ^ 0 := by
    rw [one_div, inv_pow]; field_simp
  rw [h, one_div, inv_pow]
  ring

/-- The Step-3 guard is computed exactly (partIII.tex L488–489): for `Cint ≥ 0` and
`y = Cint 2^α √(2^e) = Ĉ_d δ̃_d / h_g`, the guard mantissa is `0` if `y < 2` and `⌊y + 1/2⌋`
otherwise. -/
theorem guardMant_eq (Cint α e : ℤ) (hC : 0 ≤ Cint) :
    guardMant Cint α e =
      if (Cint : ℝ) * (2 : ℝ) ^ α * Real.sqrt ((2 : ℝ) ^ e) < 2 then 0
      else ⌊(Cint : ℝ) * (2 : ℝ) ^ α * Real.sqrt ((2 : ℝ) ^ e) + 1 / 2⌋ := by
  set y : ℝ := (Cint : ℝ) * (2 : ℝ) ^ α * Real.sqrt ((2 : ℝ) ^ e) with hy
  have hC' : (0 : ℝ) ≤ Cint := by exact_mod_cast hC
  have hy0 : 0 ≤ y := mul_nonneg (mul_nonneg hC' (by positivity)) (Real.sqrt_nonneg _)
  have hsq : y ^ 2 = (((Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e) : ℚ) : ℝ) := by
    have e1 : ((2 : ℝ) ^ α) ^ 2 = (2 : ℝ) ^ (2 * α) := by
      rw [← zpow_natCast, ← zpow_mul]; congr 1; push_cast; ring
    rw [hy]
    push_cast
    rw [mul_pow, mul_pow, Real.sq_sqrt (by positivity), e1, zpow_add₀ (by norm_num)]
    ring
  unfold guardMant
  simp only
  by_cases hlt : (Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e) < 4
  · have h4 : y ^ 2 < 4 := by
      rw [hsq]; exact_mod_cast hlt
    have hy2 : y < 2 := by nlinarith
    rw [if_pos hlt, if_pos hy2]
  · have h4 : 4 ≤ y ^ 2 := by
      rw [hsq]; exact_mod_cast (not_lt.mp hlt)
    have hy2 : ¬ y < 2 := by nlinarith
    rw [if_neg hlt, if_neg hy2]
    have hsq4 : (2 * y) ^ 2 = ((4 * ((Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e)) : ℚ) : ℝ) := by
      push_cast; rw [mul_pow, hsq]; push_cast; ring
    obtain ⟨h1, h2⟩ := floorSqrtQ_eq _ (2 * y) (by positivity) hsq4
    rw [floor_add_half_eq y _ h1 h2]

/-- The Step-4 multiplier is computed exactly (partIII.tex L504): for `P > 0`, `Q̂ > 0`, `qs ≥ 1`
and `w = (η/16) √(P/Q̂)` (`η = 2^{-qη}`), `c = 1 + clamp_{[-1/2,1/2]} round_{h_step}(s w)` with
`s = +1` iff `pos`. -/
theorem stepCoeffMant_eq (pos : Bool) (qη qs : ℕ) (Pval Qhat : ℚ) (hP : 0 < Pval) (hQ : 0 < Qhat)
    (hqs : 1 ≤ qs) :
    stepCoeffMant pos qη qs Pval Qhat =
      2 ^ qs + clampZ (-(2 ^ (qs - 1))) (2 ^ (qs - 1))
        ⌊(if pos then (1 : ℝ) else -1) * ((1 / 2 : ℝ) ^ qη / 16 * Real.sqrt ((Pval : ℝ) / Qhat)) *
            (2 : ℝ) ^ qs + 1 / 2⌋ := by
  have hk' : ((2 ^ qs / 2 : ℕ) : ℤ) = 2 ^ (qs - 1) := by
    have : (2 : ℕ) ^ qs = 2 * 2 ^ (qs - 1) := by rw [← pow_succ']; congr 1; omega
    rw [this, Nat.mul_div_cancel_left _ (by norm_num)]; push_cast; ring
  set w' : ℝ := (1 / 2 : ℝ) ^ qη / 16 * Real.sqrt ((Pval : ℝ) / Qhat) * (2 : ℝ) ^ qs with hw'
  have hPQ : (0 : ℝ) < (Pval : ℝ) / Qhat := by
    have : (0 : ℝ) < Pval := by exact_mod_cast hP
    have : (0 : ℝ) < Qhat := by exact_mod_cast hQ
    positivity
  have hw0 : 0 ≤ w' := by positivity
  have hM : (2 * w') ^ 2 =
      ((Pval / Qhat * (2 : ℚ) ^ (2 * (qs : ℤ) - 2 * (qη : ℤ) - 6) : ℚ) : ℝ) := by
    have e1 : (2 * (qs : ℤ) - 2 * (qη : ℤ) - 6) = ((2 * qs : ℕ) : ℤ) - ((2 * qη + 6 : ℕ) : ℤ) := by
      push_cast; ring
    rw [hw']
    push_cast
    rw [e1, zpow_sub₀ (by norm_num), zpow_natCast, zpow_natCast]
    rw [mul_pow, mul_pow, mul_pow, Real.sq_sqrt hPQ.le]
    simp only [one_div, inv_pow]
    field_simp
    ring
  unfold stepCoeffMant
  simp only [hk']
  congr 2
  cases pos
  · -- `s = −1`
    simp only [Bool.false_eq_true, if_false]
    obtain ⟨h1, h2⟩ := ceilSqrtQ_eq _ (2 * w') (by positivity) hM
    have := floor_neg_add_half_eq w' _ h1 h2
    rw [show (-1 : ℝ) * ((1 / 2 : ℝ) ^ qη / 16 * Real.sqrt ((Pval : ℝ) / Qhat)) * (2 : ℝ) ^ qs
        = -w' by rw [hw']; ring, this]
  · -- `s = +1`
    simp only [if_true]
    obtain ⟨h1, h2⟩ := floorSqrtQ_eq _ (2 * w') (by positivity) hM
    have := floor_add_half_eq w' _ h1 h2
    rw [show (1 : ℝ) * ((1 / 2 : ℝ) ^ qη / 16 * Real.sqrt ((Pval : ℝ) / Qhat)) * (2 : ℝ) ^ qs
        = w' by rw [hw']; ring, this]

/-- The multiplier always lies in `[1/2, 3/2]` (the clamp, Definition `R:def:total-behavior`,
partIII.tex L455), on every execution. -/
theorem stepCoeffMant_mem (pos : Bool) (qη qs : ℕ) (Pval Qhat : ℚ) (hqs : 1 ≤ qs) :
    2 ^ (qs - 1) ≤ stepCoeffMant pos qη qs Pval Qhat ∧
      stepCoeffMant pos qη qs Pval Qhat ≤ 3 * 2 ^ (qs - 1) := by
  have hk : (2 : ℤ) ^ qs = 2 * 2 ^ (qs - 1) := by
    rw [← pow_succ']; congr 1; omega
  have hk' : ((2 ^ qs / 2 : ℕ) : ℤ) = 2 ^ (qs - 1) := by
    have : (2 : ℕ) ^ qs = 2 * 2 ^ (qs - 1) := by rw [← pow_succ']; congr 1; omega
    rw [this, Nat.mul_div_cancel_left _ (by norm_num)]; push_cast; ring
  unfold stepCoeffMant clampZ
  simp only [hk']
  set a : ℤ := (if pos then _ else _)
  set k : ℤ := 2 ^ (qs - 1)
  rw [hk]
  constructor
  · have : -k ≤ max (-k) (min k a) := le_max_left _ _
    linarith
  · have : max (-k) (min k a) ≤ k := max_le (by
      have : (0 : ℤ) ≤ k := by positivity
      linarith) (min_le_left _ _)
    linarith

/-- The lower median lies in every interval containing a strict majority of the values (the form
used in Lemma `R:lem:coarse-ams`, partIII.tex L81–85). -/
theorem lowerMedian_mem_Icc (l : List ℚ) (A B : ℚ)
    (h : l.length < 2 * (l.filter (fun x => decide (A ≤ x ∧ x ≤ B))).length) :
    A ≤ lowerMedian l ∧ lowerMedian l ≤ B := by
  set p : ℚ → Bool := fun x => decide (A ≤ x ∧ x ≤ B) with hp
  set sl := l.insertionSort (· ≤ ·) with hsl
  have hperm : sl.Perm l := List.perm_insertionSort _ _
  have hsorted : sl.Pairwise (· ≤ ·) := List.pairwise_insertionSort _ _
  have hlen : sl.length = l.length := hperm.length_eq
  have hcount : (sl.filter p).length = (l.filter p).length := (hperm.filter p).length_eq
  have hcle : (l.filter p).length ≤ l.length := List.length_filter_le _ _
  set n := l.length with hn
  set k := (n - 1) / 2 with hk
  have hk' : k < sl.length := by omega
  have hmed : lowerMedian l = sl[k] := by
    show sl[k]?.getD 0 = sl[k]
    rw [List.getElem?_eq_getElem hk', Option.getD_some]
  have hle : ∀ i j (hi : i < sl.length) (hj : j < sl.length), i ≤ j → sl[i] ≤ sl[j] := by
    intro i j hi hj hij
    rcases Nat.lt_or_eq_of_le hij with hij | rfl
    · exact List.pairwise_iff_getElem.mp hsorted i j hi hj hij
    · exact le_rfl
  have hsplit : ∀ m, (sl.filter p).length =
      ((sl.take m).filter p).length + ((sl.drop m).filter p).length := by
    intro m
    rw [← List.length_append, ← List.filter_append, List.take_append_drop]
  rw [hmed]
  constructor
  · by_contra hA
    replace hA := lt_of_not_ge hA
    have htake : ((sl.take (k + 1)).filter p).length = 0 := by
      rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
      intro x hx
      obtain ⟨i, hi, hxi⟩ := List.getElem_of_mem hx
      rw [List.length_take] at hi
      have hi' : i < sl.length := by omega
      have hx' : x = sl[i] := by rw [← hxi, List.getElem_take]
      have : sl[i] ≤ sl[k] := hle i k hi' hk' (by omega)
      simp only [hp, decide_eq_true_eq, not_and, not_le]
      intro hAx
      exact absurd (lt_of_le_of_lt (hx' ▸ this) hA) (not_lt.mpr hAx)
    have hdrop : ((sl.drop (k + 1)).filter p).length ≤ n - (k + 1) := by
      calc _ ≤ (sl.drop (k + 1)).length := List.length_filter_le _ _
        _ = n - (k + 1) := by simp [hlen]
    have := hsplit (k + 1)
    omega
  · by_contra hB
    replace hB := lt_of_not_ge hB
    have hdrop : ((sl.drop k).filter p).length = 0 := by
      rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
      intro x hx
      obtain ⟨i, hi, hxi⟩ := List.getElem_of_mem hx
      rw [List.length_drop] at hi
      have hi' : k + i < sl.length := by omega
      have hx' : x = sl[k + i] := by rw [← hxi, List.getElem_drop]
      have : sl[k] ≤ sl[k + i] := hle k (k + i) hk' hi' (by omega)
      simp only [hp, decide_eq_true_eq, not_and, not_le]
      intro _
      exact lt_of_lt_of_le hB (hx' ▸ this)
    have htake : ((sl.take k).filter p).length ≤ k := by
      calc _ ≤ (sl.take k).length := List.length_filter_le _ _
        _ ≤ k := List.length_take_le _ _
    have := hsplit k
    omega

/-! ## The zero fingerprint (Lemma `R:lem:zero-fingerprint` (1)–(2)) -/

/-- The one-step homomorphic recurrence (partII.tex L259–262). -/
theorem fpUpdate_modEq (P : StreamParams) (hq : 0 < P.q) (seed val i : ℕ) (Δ : ℤ) :
    (fpUpdate P seed val i Δ : ℤ) ≡ (val : ℤ) + Δ * (seed : ℤ) ^ i [ZMOD (P.q : ℤ)] := by
  unfold fpUpdate
  have hq' : (0 : ℤ) < P.q := by exact_mod_cast hq
  set x : ℤ := (val : ℤ) + Δ % (P.q : ℤ) * ((seed ^ i % P.q : ℕ) : ℤ)
  have h1 : 0 ≤ x % (P.q : ℤ) := Int.emod_nonneg _ (ne_of_gt hq')
  rw [Int.toNat_of_nonneg h1]
  refine (Int.mod_modEq x _).trans ?_
  have hs : ((seed ^ i % P.q : ℕ) : ℤ) ≡ (seed : ℤ) ^ i [ZMOD (P.q : ℤ)] := by
    push_cast; exact Int.mod_modEq _ _
  exact Int.ModEq.add_left _ (Int.ModEq.mul (Int.mod_modEq _ _) hs)

theorem fpUpdate_lt (P : StreamParams) (hq : 0 < P.q) (seed val i : ℕ) (Δ : ℤ) :
    fpUpdate P seed val i Δ < P.q := by
  unfold fpUpdate
  have hq' : (0 : ℤ) < P.q := by exact_mod_cast hq
  set x : ℤ := (val : ℤ) + Δ % (P.q : ℤ) * ((seed ^ i % P.q : ℕ) : ℤ)
  have h1 : 0 ≤ x % (P.q : ℤ) := Int.emod_nonneg _ (ne_of_gt hq')
  have h2 : x % (P.q : ℤ) < P.q := Int.emod_lt_of_pos _ hq'
  omega

/-- The fingerprint invariant along an execution (eq. `R:eq:fingerprint-recurrence`): if `F_zero`
fingerprints `x` (coordinates `1, …, n`, i.e. 0-based `j ↦ r^{j+1}`), then after Step 2 for the
update `(i, Δ)` it fingerprints `x + Δ e_i`. -/
theorem step2_fpVal_modEq (P : StreamParams) (hq : 0 < P.q) (s : State) (i : Fin P.n) (Δ : ℤ)
    (x : Fin P.n → ℤ)
    (hx : (s.fpVal : ℤ) ≡ ∑ j, x j * (s.fpSeed : ℤ) ^ (j.val + 1) [ZMOD (P.q : ℤ)]) :
    ((step2 P i.val Δ s).1.fpVal : ℤ) ≡
      ∑ j, (x j + if j = i then Δ else 0) * ((step2 P i.val Δ s).1.fpSeed : ℤ) ^ (j.val + 1)
        [ZMOD (P.q : ℤ)] := by
  rw [step2_fpVal, step2_fpSeed]
  refine (fpUpdate_modEq P hq _ _ _ _).trans ?_
  have hsum : ∑ j, (x j + if j = i then Δ else 0) * (s.fpSeed : ℤ) ^ (j.val + 1) =
      ∑ j, x j * (s.fpSeed : ℤ) ^ (j.val + 1) + Δ * (s.fpSeed : ℤ) ^ (i.val + 1) := by
    simp only [add_mul, Finset.sum_add_distrib, ite_mul, zero_mul, Finset.sum_ite_eq',
      Finset.mem_univ, if_true]
  rw [hsum]
  exact Int.ModEq.add_right _ hx

/-- Exact completeness on zero rounds (Lemma `R:lem:zero-fingerprint` (2)) and the zero-round bypass
(partIII.tex L484): if the fingerprint is zero after the update (Step 1 does not touch the
fingerprint registers), the round reports `0`, on every execution. -/
theorem roundStep_zero_round (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ)
    (h : fpUpdate P s.fpSeed s.fpVal (i + 1) Δ = 0) :
    Always (roundStep P s i Δ) (fun r => r.2 = 0) := by
  unfold roundStep
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hf
  · exact always_pure (by rw [finishRound_snd]; split <;> rfl)
  · refine Always.bind (fun s1 hs1 => ?_) (step1_frame P s)
    have hz : (step2 P i Δ s1).2 = true := by
      rw [step2_snd, hs1.2.1, hs1.2.2.1, h]; rfl
    split_ifs with h1 h2 h3
    · exact always_pure (by rw [finishRound_snd]; split <;> rfl)
    · exact always_pure (by rw [finishRound_snd]; split <;> rfl)
    · exact absurd (by rw [hz]; simp) h2
    · exact absurd (by rw [hz]; simp) h2

/-! ## Totality and failure (Definition `R:def:total-behavior`) -/

/-- A failed state reports `0` and does nothing else (partIII.tex L457). -/
theorem roundStep_of_failed (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) (h : s.failed = true) :
    roundStep P s i Δ = BitProg.pure (finishRound s 0) := by
  simp [roundStep, h]

/-- Every estimate lies in `[0, A_max]`, on every execution (the range checks of partIII.tex L453;
the encoding `[a, d]` with `a ≥ 0`, `d > 0` of the Spec is therefore always possible). -/
theorem algStep_estimate_mem (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    Always (algStep P s i Δ) (fun r => 0 ≤ r.2 ∧ r.2 ≤ (P.Amax : ℚ)) :=
  Always.mono (fun _ h => ⟨h.2.2.2.2.1, h.2.2.2.2.2⟩) (roundStep_out P s i Δ)

/-- Failure is absorbing, and a failed round reports `0`. -/
theorem algStep_failed (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    Always (algStep P s i Δ)
      (fun r => (s.failed = true → r.1.failed = true) ∧ (r.1.failed = true → r.2 = 0)) :=
  Always.mono (fun _ h => ⟨h.2.2.1, h.2.2.2.1⟩) (roundStep_out P s i Δ)

/-- The round counter. -/
theorem algStep_t (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    Always (algStep P s i Δ) (fun r => r.1.t = s.t + 1) :=
  Always.mono (fun _ h => h.1) (roundStep_out P s i Δ)

/-- The fingerprint seed is fixed at initialization. -/
theorem algStep_fpSeed (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    Always (algStep P s i Δ) (fun r => r.1.fpSeed = s.fpSeed) :=
  Always.mono (fun _ h => h.2.1) (roundStep_out P s i Δ)

/-! ## The schedule (Definition `R:def:binary-tree-architecture` (1)) -/

/-- The depths born at round `tr` are exactly `firstBorn H tr, …, H − 1` (nested dyadic lifetimes);
see also `firstBorn_lt` (depth `H − 1` is born every round) and `firstBorn_one` (every depth is born
at round `1`) in `FactsAux.lean`. -/
theorem bornAt_iff_firstBorn_le (H tr d : ℕ) (hH : 1 ≤ H) :
    bornAt H d tr = true ↔ firstBorn H tr ≤ d := by
  have hlt := firstBorn_lt H tr hH
  constructor
  · intro h
    by_contra hcon
    replace hcon := lt_of_not_ge hcon
    have := List.not_of_lt_findIdx (p := fun d => bornAt H d tr) (xs := List.range H)
      (i := d) (by simpa [firstBorn] using hcon)
    simp [h] at this
  · intro h
    refine bornAt_mono h ?_
    have := List.findIdx_getElem (p := fun d => bornAt H d tr) (xs := List.range H)
      (w := by simpa [firstBorn] using hlt)
    simpa [firstBorn] using this

/-! ## Shape of the state (on every execution) -/

/-- The shape invariant: `H` live learners and `H` live banks after every completed non-failed
round. -/
def State.Shaped (P : StreamParams) (s : State) : Prop :=
  s.learners.length = P.H ∧ s.banks.length = P.H

theorem algStep_shaped (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) (hH : 1 ≤ P.H)
    (hs : s.t = 0 → s.banks.length = 1 ∧ s.learners = []) (hs' : 0 < s.t → s.Shaped P) :
    Always (algStep P s i Δ) (fun r => r.1.failed = false → r.1.Shaped P) := by
  have hd0 := firstBorn_lt P.H (s.t + 1) hH
  have hlen : firstBorn P.H (s.t + 1) ≤ s.learners.length ∧
      firstBorn P.H (s.t + 1) + 1 ≤ s.banks.length := by
    rcases Nat.eq_zero_or_pos s.t with h0 | h0
    · obtain ⟨hb, hl⟩ := hs h0
      rw [h0, firstBorn_one P.H hH, hb, hl]; simp
    · obtain ⟨hl, hb⟩ := hs' h0
      rw [hl, hb]; omega
  have nf : ∀ s' : State, s'.failed = true → (finishRound s' 0).1.failed = false →
      (finishRound s' 0).1.Shaped P := by
    intro s' h h'
    rw [finishRound_fst_failed, h] at h'; exact Bool.noConfusion h'
  unfold algStep roundStep
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hf
  · exact always_pure (nf s hf)
  · refine Always.bind (fun s1 hs1 => ?_) (step1_shape P s hlen.1 hlen.2)
    have hl2 := step2_lengths P i Δ s1
    have h2f := step2_failed P i Δ s1
    split_ifs with h1 h2 h3
    · exact always_pure (nf s1 h1)
    · refine always_pure (fun h => ?_)
      have hr2 : (step2 P i Δ s1).1.failed = false := h
      have hs1f : s1.failed = false := by
        cases hc : s1.failed
        · rfl
        · rw [h2f hc] at hr2; exact Bool.noConfusion hr2
      obtain ⟨a, b⟩ := hs1.2 hs1f
      exact ⟨hl2.1.trans a, hl2.2.trans b⟩
    · exact always_pure (nf _ h3)
    · refine Always.bind (fun r4 hr4 => always_pure (fun _ => ?_)) (step4_out P _)
      have h3' := step3_pres P (step2 P i Δ s1).1
      have hs1f : s1.failed = false := Bool.eq_false_iff.mpr h1
      obtain ⟨a, b⟩ := hs1.2 hs1f
      exact ⟨hr4.1.2.2.2.2.1.trans (h3'.2.2.2.2.1.trans (hl2.1.trans a)),
        hr4.1.2.2.2.2.2.trans (h3'.2.2.2.2.2.trans (hl2.2.trans b))⟩

/-! ## Lemma `R:lem:terminal-accumulator` (algorithm side) -/

/-- When Step 4 starts (after Steps 1–3 of a round that did not fail and is not a fingerprint-zero
round), the terminal accumulator equals `Δ_t² + Σ_{d<H} δ_d²` exactly (partIII.tex L483, L491,
L496; Lemma `R:lem:terminal-accumulator`). Exactness uses `2 q_g ≤ q_leaf` (`h_leaf = h_g² h_step^{2H}`,
eq. `R:eq:h-leaf`). -/
theorem step3_leaf_eq (P : StreamParams) (s1 : State) (i : ℕ) (Δ : ℤ)
    (h2 : (step2 P i Δ s1).1.failed = false) (h3 : (step3 P (step2 P i Δ s1).1).failed = false) :
    gridVal P.eHleaf (step3 P (step2 P i Δ s1).1).leaf =
      (Δ : ℚ) ^ 2 + ∑ d ∈ Finset.range P.H, gridVal P.eHg (guardOf P (step2 P i Δ s1).1 d) ^ 2 := by
  unfold step3 at h3 ⊢
  rw [step3Loop_leaf P _ _ _ h3, step2_leaf P i Δ s1 h2, list_range_map_sum]

/-! ## The rejection branch (algorithm side of Lemma `R:lem:homogeneous-child-rescaling`) -/

/-- In the rejection branch at depth `d` with multiplier `c = cInt h_step` (partIII.tex L505–507):
the secondary counters of bank `𝓑_{d-1}` are multiplied by `c`; both counters of the banks
`𝓑_d, …, 𝓑_{H-2}` by `c`; the tags of the strict descendants by `c` and their caches by `c²`; the
terminal accumulator by `c²`; all rounded on their grids (and saturated, for counters). This is the
definition of `rejectTail` and of the scaling in `rejectDepth`; stated here for the analysis. -/
theorem rejectTail_rescaled (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (s : State) :
    Always (rejectTail P d Ld cInt N1 s) (fun r => r.1.failed = false →
      (∀ d', d < d' → ∀ L, s.learners[d']? = some L →
        ∃ L', r.1.learners[d']? = some L' ∧ L' = Learner.rescale P cInt L) ∧
      gridVal P.eHleaf r.1.leaf =
        gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf))
      ∧ r.2 = N1) := by
  unfold rejectTail
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs
  · split
    · exact always_pure (fun h => (not_fail_false h).elim)
    · refine Always.bind_all (fun r2 => ?_) _
      split
      · exact always_pure (fun h => (not_fail_false h).elim)
      · split
        · exact always_pure (fun h => (not_fail_false h).elim)
        · split_ifs
          · refine always_pure (fun _ => ⟨fun d' hdd L hL => ⟨Learner.rescale P cInt L, ?_, rfl⟩,
              rfl, rfl⟩)
            show (setAt _ d (mapFrom (Learner.rescale P cInt) (d + 1) s.learners))[d']? = _
            rw [getElem?_setAt_ne _ _ _ _ (by omega), getElem?_mapFrom, if_pos (by omega), hL]
            rfl
          · exact always_pure (fun h => (not_fail_false h).elim)
  · exact always_pure (fun h => (not_fail_false h).elim)

end F2e2e.C.Alg
