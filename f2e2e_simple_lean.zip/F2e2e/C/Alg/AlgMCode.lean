import Mathlib
import F2e2e.C.Alg.AlgM
import F2e2e.C.Alg.Round
import F2e2e.C.Alg.Bits

/-!
# The controller code of the Theorem C algorithm (Algorithms 1 and 4 over oracle calls)

The round procedure of `F2e2e/C/Alg/Round.lean` (the source of truth, mirrored by the DSL), written
as a program of `AlgM` (primitive calls on the banks and the fingerprint, `F2e2e/C/Alg/AlgM.lean`)
acting on the controller state `CState` (round counter, failure flag, learners, terminal
accumulator). The primitives are issued in exactly the order of the direct code, so the
interpretation by `runO` reads the same fresh bits and produces the same memory and estimates:
`algInit_eq_interp`, `algStep_eq_interp`. Sources and decisions: see the header of `Round.lean`
(`parts/partIII.tex` L466–517, L429–464; `parts/partII.tex` L216–231).

Analysis events (`noteM`, no effect on the algorithm): `newRound` at the start of a non-failed
round (before Step 1); `birth d` when a newly born depth-`d` learner is allocated (Step 1; after all
bank calls of the birth; for a released birth cache the range check follows, and if it fails the
round fails at once);
`phys (i+1) Δ` right after Step 2's counter update (1-based coordinate); `guard d g δ` once per depth
entering Step 3 (`δ = 0` for an omitted guard; for `δ ≠ 0` after the two bank operations);
`accept d` when the Step-4 validation of depth `d` accepts; `correct d cInt` right after the rescaling
of the descendants' banks in a Step-4 correction (before the `DIFF` refresh).
-/

namespace F2e2e.C.Alg

open F2e2e.B
open F2e2e.Discrete

/-! ## The controller state -/

/-- The controller part of the memory. -/
structure CState where
  /-- the number of rounds processed -/
  t : ℕ
  /-- the absorbing failure flag -/
  failed : Bool
  /-- the live learners `𝓛_0, …, 𝓛_{H-1}` -/
  learners : List Learner
  /-- the terminal accumulator (mantissa on `h_leaf`) -/
  leaf : ℤ

/-- Enter the failure state. -/
def CState.fail (c : CState) : CState := { c with failed := true }

/-- The controller part of a state. -/
def State.ctrl (s : State) : CState := ⟨s.t, s.failed, s.learners, s.leaf⟩

/-- The oracle part of a state. -/
def State.orc (s : State) : OState := ⟨s.fpSeed, s.fpVal, s.banks⟩

/-- Assemble a state from its controller and oracle parts. -/
def State.mk' (c : CState) (o : OState) : State :=
  ⟨c.t, c.failed, o.fpSeed, o.fpVal, c.learners, o.banks, c.leaf⟩

@[simp] theorem State.mk'_ctrl_orc (s : State) : State.mk' s.ctrl s.orc = s := rfl

@[simp] theorem State.ctrl_mk' (c : CState) (o : OState) : (State.mk' c o).ctrl = c := rfl

@[simp] theorem State.orc_mk' (c : CState) (o : OState) : (State.mk' c o).orc = o := rfl

/-! ## Step 1: scheduled retirements and births (partIII.tex L472–478) -/

/-- Step 1 for one newly born depth `d` of round `tr`, when `d₀` is the shallowest depth born this
round (L475–477; decision (c) of `Round.lean` for the birth cache). -/
def birthCode (P : StreamParams) (tr d0 d : ℕ) (c : CState) : AlgM CState := do
  bankOpM d RowOp.resetY
  if d + 2 ≤ P.H then bankNewM tr d
  if d = 0 ∨ d0 < d then
    noteM (TreeEvent.birth d)
    pure { c with learners := c.learners ++ [newLearner P 0] }
  else do
    let o ← releaseM d Mode.primary
    match o with
    | none => pure c.fail
    | some N => do
      noteM (TreeEvent.birth d)
      let cache := roundMant P.eHP N
      pure (if inRangeA P (gridVal P.eHP cache) then
          { c with learners := c.learners ++ [newLearner P cache] }
        else c.fail)

/-- The births of the depths in `ds` (shallowest first), stopping at a failure. -/
def birthLoopCode (P : StreamParams) (tr d0 : ℕ) : List ℕ → CState → AlgM CState
  | [], c => pure c
  | d :: ds, c =>
    if c.failed then pure c
    else do
      let c' ← birthCode P tr d0 d c
      birthLoopCode P tr d0 ds c'

/-- Step 1 of round `t + 1`. -/
def step1Code (P : StreamParams) (c : CState) : AlgM CState := do
  let tr := c.t + 1
  let d0 := firstBorn P.H tr
  bankRetainM (d0 + 1)
  let c2 ← birthLoopCode P tr d0 (List.range' d0 (P.H - d0)) { c with learners := c.learners.take d0 }
  pure { c2 with leaf := 0 }

/-! ## Step 2: physical update and zero bypass (partIII.tex L480–484) -/

/-- Step 2 for the update `(i, Δ)` (0-based coordinate `i`); returns whether the fingerprint is
zero. -/
def step2Code (P : StreamParams) (i : ℕ) (Δ : ℤ) (c : CState) : AlgM (CState × Bool) := do
  let z ← fpStepM (i + 1) Δ
  bankOpFromM 0 (RowOp.phys (i + 1) Δ)
  noteM (TreeEvent.phys (i + 1) Δ)
  let leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2)
  pure (if inRangeA P (gridVal P.eHleaf leaf) then ({ c with leaf := leaf }, z) else (c.fail, z))

/-! ## Step 3: top-down guards (partIII.tex L486–493) -/

/-- Step 3 at depth `d` of round `tr`. -/
def step3DepthCode (P : StreamParams) (tr : ℕ) (c : CState) (d : ℕ) : AlgM CState :=
  match c.learners[d]? with
  | none => pure c.fail
  | some Ld =>
    let g := P.guardCoord d tr
    let δ := guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))
    if δ = 0 then do
      noteM (TreeEvent.guard d g 0)
      pure c
    else do
      bankOpM d (RowOp.guardY g δ)
      bankOpFromM (d + 1) (RowOp.guardXY g δ)
      noteM (TreeEvent.guard d g δ)
      let δv : ℚ := gridVal P.eHg δ
      let cache := roundMant P.eHP (gridVal P.eHP Ld.cache + δv ^ 2)
      let leaf := roundMant P.eHleaf (gridVal P.eHleaf c.leaf + δv ^ 2)
      pure (if inRangeA P (gridVal P.eHP cache) && inRangeA P (gridVal P.eHleaf leaf) then
          { c with learners := setAt { Ld with cache := cache } d c.learners, leaf := leaf }
        else c.fail)

/-- Step 3 for the depths in `ds`, stopping at a failure. -/
def step3LoopCode (P : StreamParams) (tr : ℕ) : List ℕ → CState → AlgM CState
  | [], c => pure c
  | d :: ds, c =>
    if c.failed then pure c
    else do
      let c' ← step3DepthCode P tr c d
      step3LoopCode P tr ds c'

/-- Step 3 of round `t + 1`: `d = 0, …, H − 1`. -/
def step3Code (P : StreamParams) (c : CState) : AlgM CState :=
  step3LoopCode P (c.t + 1) (List.range P.H) c

/-! ## Step 4: terminal and bottom-up evaluation (partIII.tex L495–513) -/

/-- The tail of the rejection branch (L506–510). -/
def rejectTailCode (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (c : CState) :
    AlgM (CState × ℚ) := do
  bankOpFromM (d + 1) (RowOp.scaleXY cInt)
  noteM (TreeEvent.correct d cInt)
  let learners := mapFrom (Learner.rescale P cInt) (d + 1) c.learners
  let leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf)
  if ((learners.drop (d + 1)).all (Learner.inRange P) && inRangeA P (gridVal P.eHleaf leaf)) then do
    let c1 : CState := { c with learners := learners, leaf := leaf }
    let o ← releaseM d Mode.diff
    match o with
    | none => pure (c1.fail, 0)
    | some N2 =>
      let cache := roundMant P.eHP N2
      pure (match Learner.countCorrection P { Ld with cache := cache } with
        | none => (c1.fail, 0)
        | some Ld' =>
          if inRangeA P (gridVal P.eHP cache) then
            ({ c1 with learners := setAt Ld' d c1.learners }, N1)
          else (c1.fail, 0))
  else pure (c.fail, 0)

/-- The rejection branch at depth `d` (L501–510). -/
def rejectDepthCode (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState) :
    AlgM (CState × ℚ) :=
  match c.learners[d]? with
  | none => pure (c.fail, 0)
  | some Ld =>
    if P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ Qhat ≤ 0 then pure (c.fail, 0)
    else do
      let o ← releaseM d Mode.primary
      match o with
      | none => pure (c.fail, 0)
      | some N1 =>
        if inRangeA P N1 then do
          let cInt := stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat
          bankOpM d (RowOp.scaleY cInt)
          rejectTailCode P d Ld cInt N1 c
        else pure (c.fail, 0)

/-- Step 4 at depth `d` with the current returned value `F` (L498–511). -/
def step4DepthCode (P : StreamParams) (d : ℕ) (c : CState) (F : ℚ) : AlgM (CState × ℚ) :=
  match c.learners[d]? with
  | none => pure (c.fail, 0)
  | some Ld =>
    let Qhat := F
    let S := gridVal P.eHP Ld.cache + Qhat
    if inRangeA P S then do
      let θ : ℚ := (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta
      let cert ← validateM d S θ
      match cert with
      | AdaCert.accept => do
        noteM (TreeEvent.accept d)
        pure (c, S)
      | AdaCert.high => rejectDepthCode P d true Qhat c
      | AdaCert.low => rejectDepthCode P d false Qhat c
      | _ => pure (c.fail, 0)
    else pure (c.fail, 0)

/-- Step 4 for the depths in `ds`, threading the returned value, stopping at a failure. -/
def step4LoopCode (P : StreamParams) : List ℕ → CState → ℚ → AlgM (CState × ℚ)
  | [], c, F => pure (c, F)
  | d :: ds, c, F =>
    if c.failed then pure (c, F)
    else do
      let r ← step4DepthCode P d c F
      step4LoopCode P ds r.1 r.2

/-- Step 4: `F` := the exact terminal accumulator, then `d = H − 1, …, 0`. -/
def step4Code (P : StreamParams) (c : CState) : AlgM (CState × ℚ) :=
  step4LoopCode P (List.range P.H).reverse c (gridVal P.eHleaf c.leaf)

/-! ## One round and initialization -/

/-- Close a round: count it and report `F` (or `0` if failed). -/
def finishC (c : CState) (F : ℚ) : CState × ℚ :=
  ({ c with t := c.t + 1 }, if c.failed then 0 else F)

/-- One round for the update `x_{i+1} ← x_{i+1} + Δ`. -/
def roundCode (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) : AlgM (CState × ℚ) :=
  if c.failed then pure (finishC c 0)
  else do
    noteM TreeEvent.newRound
    let c1 ← step1Code P c
    if c1.failed then pure (finishC c1 0)
    else do
      let r2 ← step2Code P i Δ c1
      if r2.1.failed || r2.2 then pure (finishC r2.1 0)
      else do
        let c3 ← step3Code P r2.1
        if c3.failed then pure (finishC c3 0)
        else do
          let r4 ← step4Code P c3
          pure (finishC r4.1 r4.2)

/-- Initialization: the fingerprint seed and the root bank `𝓑_{-1}` (`bankNew 0 0`). -/
def initCode : AlgM CState := do
  fpInitM
  bankNewM 0 0
  pure ⟨0, false, [], 0⟩

/-- The initial oracle state before `initCode`. -/
def initO : OState := ⟨0, 0, []⟩

/-- Initialization, as the interpretation of the controller code. -/
def algInitM (P : StreamParams) : BitProg State :=
  (runO P initCode initO).bind fun r => BitProg.pure (State.mk' r.1 r.2)

/-- One round, as the interpretation of the controller code. -/
def algStepM (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) : BitProg (State × ℚ) :=
  (runO P (roundCode P s.ctrl i Δ) s.orc).bind fun r => BitProg.pure (State.mk' r.1.1 r.2, r.1.2)

/-! ## The direct code is the interpretation of the controller code

Every piece of the round is proved separately, for a variable state: `runO` of the piece's code on
`(s.ctrl, s.orc)` is the direct piece mapped by `State.split` / `State.split2`. Conventions that
keep these proofs cheap: every `ite` is resolved by an explicit `by_cases` on both sides before any
`rfl` (an unresolved range check would be evaluated by `whnf`); a condition that `simp` may already
have rewritten definitionally is rewritten propositionally (`simp only [h, if_true]`), because the
`Decidable` instance of the `ite` keeps the old form. -/

/-! ### Helpers -/

/-- Split a state into its controller and oracle parts. -/
def State.split (s : State) : CState × OState := (s.ctrl, s.orc)

/-- Split a state-value pair into the controller part with the value, and the oracle part. -/
def State.split2 {β : Type} (r : State × β) : (CState × β) × OState := ((r.1.ctrl, r.2), r.1.orc)

/-! Projections of the two parts (`rfl`). -/

theorem State.ctrl_t (s : State) : s.ctrl.t = s.t := rfl
theorem State.ctrl_failed (s : State) : s.ctrl.failed = s.failed := rfl
theorem State.ctrl_learners (s : State) : s.ctrl.learners = s.learners := rfl
theorem State.ctrl_leaf (s : State) : s.ctrl.leaf = s.leaf := rfl
theorem State.orc_fpSeed (s : State) : s.orc.fpSeed = s.fpSeed := rfl
theorem State.orc_fpVal (s : State) : s.orc.fpVal = s.fpVal := rfl
theorem State.orc_banks (s : State) : s.orc.banks = s.banks := rfl

/-- `mapFrom f 0` is `List.map f` (Step 2 updates every bank). -/
theorem mapFrom_zero_eq_map {α : Type} (f : α → α) : ∀ l : List α, mapFrom f 0 l = l.map f
  | [] => rfl
  | a :: l => by simp [mapFrom, mapFrom_zero_eq_map f l]

/-- `BitProg.map` of a pure program. -/
theorem algEq_map_pure {α β : Type} (f : α → β) (a : α) :
    (BitProg.pure a).map f = BitProg.pure (f a) := rfl

/-- Binding after a `BitProg.map`. -/
theorem algEq_map_bind {α β γ : Type} (p : BitProg α) (f : α → β) (g : β → BitProg γ) :
    (p.map f).bind g = p.bind (fun a => g (f a)) := by
  unfold BitProg.map; rw [BitProg.bind_assoc]; rfl

/-- Congruence of `BitProg.bind` in the continuation. -/
theorem algEq_bind_congr {α β : Type} (p : BitProg α) {f g : α → BitProg β}
    (h : ∀ a, f a = g a) : p.bind f = p.bind g := by
  rw [funext h]

/-- The interpreter commutes with `if`. -/
theorem runO_ite (P : StreamParams) {α : Type} (c : Prop) [Decidable c] (a b : AlgM α)
    (o : OState) : runO P (if c then a else b) o = if c then runO P a o else runO P b o := by
  split_ifs <;> rfl

/-- `BitProg.map` commutes with `if`. -/
theorem algEq_map_ite {α β : Type} (f : α → β) (c : Prop) [Decidable c] (a b : BitProg α) :
    BitProg.map f (if c then a else b) = if c then BitProg.map f a else BitProg.map f b := by
  split_ifs <;> rfl

/-! ### Step 2 -/

set_option maxHeartbeats 300000 in
/-- Step 2: the code reads no bits and produces the direct result. -/
theorem runO_step2Code (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    runO P (step2Code P i Δ s.ctrl) s.orc = BitProg.pure (State.split2 (step2 P i Δ s)) := by
  unfold step2Code step2
  simp only [fpStepM, bankOpFromM, noteM, AlgM.bind_eq, AlgM.bind, AlgM.pure_eq, runO_fpStep,
    runO_bankOpFrom, runO_note, runO_pure, mapFrom_zero_eq_map]
  by_cases h : inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) = true
  · simp only [if_pos h]; rfl
  · simp only [if_neg h]; rfl

/-! ### Step 3 -/

set_option maxHeartbeats 300000 in
/-- Step 3 at one depth. -/
theorem runO_step3DepthCode (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) :
    runO P (step3DepthCode P tr s.ctrl d) s.orc = BitProg.pure (State.split (step3Depth P tr s d)) := by
  unfold step3DepthCode step3Depth
  simp only [State.ctrl_learners, State.ctrl_leaf]
  cases hL : s.learners[d]? with
  | none => rfl
  | some Ld =>
    by_cases hδ : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0
    · simp only [if_pos hδ, noteM, AlgM.bind_eq, AlgM.bind, AlgM.pure_eq, runO_note, runO_pure]
      rfl
    · simp only [if_neg hδ, bankOpM, bankOpFromM, noteM, AlgM.bind_eq, AlgM.bind,
        AlgM.pure_eq, runO_bankOp, runO_bankOpFrom, runO_note, runO_pure]
      by_cases hr : (inRangeA P (gridVal P.eHP (roundMant P.eHP (gridVal P.eHP Ld.cache +
          gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))) &&
          inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHleaf s.leaf +
          gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))))
          = true
      · simp only [hr, if_true]; rfl
      · simp only [hr, if_false, Bool.false_eq_true]; rfl

/-- Step 3 over a list of depths. -/
theorem runO_step3LoopCode (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State),
      runO P (step3LoopCode P tr ds s.ctrl) s.orc = BitProg.pure (State.split (step3Loop P tr ds s))
  | [], _ => rfl
  | d :: ds, s => by
    simp only [step3LoopCode, step3Loop]
    by_cases hf : s.failed = true
    · have hc : s.ctrl.failed = true := hf
      simp only [if_pos hf, if_pos hc, AlgM.pure_eq, runO_pure]
      rfl
    · have hc : ¬ s.ctrl.failed = true := hf
      simp only [if_neg hf, if_neg hc, AlgM.bind_eq, runO_bind, runO_step3DepthCode,
        BitProg.bind_pure']
      exact runO_step3LoopCode P tr ds (step3Depth P tr s d)

/-- Step 3. -/
theorem runO_step3Code (P : StreamParams) (s : State) :
    runO P (step3Code P s.ctrl) s.orc = BitProg.pure (State.split (step3 P s)) :=
  runO_step3LoopCode P (s.t + 1) (List.range P.H) s

/-! ### Step 1 -/

set_option maxHeartbeats 300000 in
/-- Step 1 for one newly born depth. -/
theorem runO_birthCode (P : StreamParams) (tr d0 d : ℕ) (s : State) :
    runO P (birthCode P tr d0 d s.ctrl) s.orc = (birthDepth P d0 d s).map State.split := by
  unfold birthCode birthDepth
  by_cases h1 : d + 2 ≤ P.H
  · by_cases h2 : d = 0 ∨ d0 < d
    · simp only [if_pos h1, if_pos h2, bankOpM, bankNewM, noteM, AlgM.bind_eq, AlgM.bind,
        AlgM.pure_eq, runO_bankOp, runO_bankNew, runO_note, runO_pure, bp_bind_eq, bp_pure_eq,
        BitProg.bind_assoc, BitProg.bind_pure', BitProg.map_bind, algEq_map_pure]
      exact algEq_bind_congr _ (fun B => rfl)
    · simp only [if_pos h1, if_neg h2, bankOpM, bankNewM, noteM, releaseM, AlgM.bind_eq, AlgM.bind,
        AlgM.pure_eq, runO_bankOp, runO_bankNew, runO_pure, runO_bankRelease, bp_bind_eq,
        bp_pure_eq, BitProg.bind_assoc, BitProg.bind_pure', BitProg.map_bind,
        RowOp.apply, State.orc_banks, State.ctrl_learners]
      refine algEq_bind_congr _ (fun B => ?_)
      rcases hX : (modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B])[d]? with _ | B'
      · rfl
      · simp only [BitProg.map_bind]
        refine algEq_bind_congr _ (fun r => ?_)
        rcases r with ⟨_ | N, B''⟩
        · rfl
        · simp only [runO_note, runO_pure]
          by_cases h3 : inRangeA P (gridVal P.eHP (roundMant P.eHP N)) = true
          · simp only [h3, if_true]; rfl
          · simp only [h3, if_false, Bool.false_eq_true]; rfl
  · by_cases h2 : d = 0 ∨ d0 < d
    · simp only [if_neg h1, if_pos h2, bankOpM, noteM, AlgM.bind_eq, AlgM.bind,
        AlgM.pure_eq, runO_bankOp, runO_note, runO_pure, bp_bind_eq, bp_pure_eq,
        BitProg.bind_pure', algEq_map_pure]
      rfl
    · simp only [if_neg h1, if_neg h2, bankOpM, noteM, releaseM, AlgM.bind_eq, AlgM.bind,
        AlgM.pure_eq, runO_bankOp, runO_pure, runO_bankRelease, bp_bind_eq,
        bp_pure_eq, BitProg.bind_pure', RowOp.apply, State.orc_banks,
        State.ctrl_learners]
      rcases hX : (modifyAt (Bank.mapRows Row.resetY) d s.banks)[d]? with _ | B'
      · rfl
      · simp only [BitProg.map_bind]
        refine algEq_bind_congr _ (fun r => ?_)
        rcases r with ⟨_ | N, B''⟩
        · rfl
        · simp only [runO_note, runO_pure]
          by_cases h3 : inRangeA P (gridVal P.eHP (roundMant P.eHP N)) = true
          · simp only [h3, if_true]; rfl
          · simp only [h3, if_false, Bool.false_eq_true]; rfl

/-- Step 1 births over a list of depths. -/
theorem runO_birthLoopCode (P : StreamParams) (tr d0 : ℕ) :
    ∀ (ds : List ℕ) (s : State),
      runO P (birthLoopCode P tr d0 ds s.ctrl) s.orc = (birthLoop P d0 ds s).map State.split
  | [], _ => rfl
  | d :: ds, s => by
    simp only [birthLoopCode, birthLoop]
    by_cases hf : s.failed = true
    · have hc : s.ctrl.failed = true := hf
      simp only [if_pos hf, if_pos hc, AlgM.pure_eq, runO_pure, bp_pure_eq, algEq_map_pure]
      rfl
    · have hc : ¬ s.ctrl.failed = true := hf
      simp only [if_neg hf, if_neg hc, AlgM.bind_eq, runO_bind, runO_birthCode, bp_bind_eq,
        algEq_map_bind, BitProg.map_bind]
      exact algEq_bind_congr _ (fun s' => runO_birthLoopCode P tr d0 ds s')

set_option maxHeartbeats 300000 in
/-- Step 1. -/
theorem runO_step1Code (P : StreamParams) (s : State) :
    runO P (step1Code P s.ctrl) s.orc = (step1 P s).map State.split := by
  have h := runO_birthLoopCode P (s.t + 1) (firstBorn P.H (s.t + 1))
    (List.range' (firstBorn P.H (s.t + 1)) (P.H - firstBorn P.H (s.t + 1)))
    { s with learners := s.learners.take (firstBorn P.H (s.t + 1)),
             banks := s.banks.take (firstBorn P.H (s.t + 1) + 1) }
  simp only [State.ctrl, State.orc] at h
  unfold step1Code step1
  simp only [bankRetainM, AlgM.bind_eq, AlgM.bind, AlgM.pure_eq, runO_bankRetain, runO_bind,
    runO_pure, bp_bind_eq, bp_pure_eq, BitProg.map_bind, algEq_map_pure, State.ctrl_t,
    State.ctrl_failed, State.ctrl_learners, State.ctrl_leaf, State.orc_fpSeed, State.orc_fpVal,
    State.orc_banks]
  rw [h, algEq_map_bind]
  exact algEq_bind_congr _ (fun a => rfl)

/-! ### Step 4 -/

set_option maxHeartbeats 300000 in
/-- The tail of a Step-4 correction. -/
theorem runO_rejectTailCode (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (s : State) :
    runO P (rejectTailCode P d Ld cInt N1 s.ctrl) s.orc =
      (rejectTail P d Ld cInt N1 s).map State.split2 := by
  unfold rejectTailCode rejectTail
  simp only [bankOpFromM, noteM, AlgM.bind_eq, AlgM.bind, AlgM.pure_eq, runO_bankOpFrom,
    runO_note, State.ctrl_learners, State.ctrl_leaf, State.ctrl_t, State.ctrl_failed,
    State.orc_banks, State.orc_fpSeed, State.orc_fpVal, RowOp.apply]
  by_cases hc : ((List.drop (d + 1) (mapFrom (Learner.rescale P cInt) (d + 1) s.learners)).all
      (Learner.inRange P) && inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf
        (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf)))) = true
  · simp only [hc, if_true, releaseM, AlgM.bind, runO_bankRelease]
    rcases hX : (mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks)[d]? with _ | Bd
    · simp only [runO_pure]; rfl
    · simp only [bp_bind_eq, bp_pure_eq, BitProg.map_bind]
      refine algEq_bind_congr _ (fun r => ?_)
      rcases r with ⟨_ | N2, B'⟩
      · simp only [runO_pure, algEq_map_pure]; rfl
      · simp only [runO_pure]
        cases hcc : Learner.countCorrection P { Ld with cache := roundMant P.eHP N2 } with
        | none => simp only [algEq_map_pure]; rfl
        | some Ld' =>
          by_cases hr : inRangeA P (gridVal P.eHP (roundMant P.eHP N2)) = true
          · simp only [hr, if_true, algEq_map_pure]; rfl
          · simp only [hr, if_false, Bool.false_eq_true, algEq_map_pure]; rfl
  · simp only [hc, if_false, Bool.false_eq_true, runO_pure, bp_pure_eq, algEq_map_pure]; rfl

set_option maxHeartbeats 300000 in
/-- A Step-4 correction. -/
theorem runO_rejectDepthCode (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State) :
    runO P (rejectDepthCode P d pos Qhat s.ctrl) s.orc =
      (rejectDepth P d pos Qhat s).map State.split2 := by
  unfold rejectDepthCode rejectDepth
  simp only [State.ctrl_learners]
  cases hL : s.learners[d]? with
  | none => rfl
  | some Ld =>
    cases hB : s.banks[d]? with
    | none =>
      by_cases hc : P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ Qhat ≤ 0
      · simp only [if_pos hc]; rfl
      · simp only [if_neg hc, releaseM, AlgM.bind_eq, AlgM.bind, runO_bankRelease,
          State.orc_banks, hB, runO_pure, AlgM.pure_eq]
        rfl
    | some Bd =>
      by_cases hc : P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ Qhat ≤ 0
      · simp only [if_pos hc]; rfl
      · simp only [if_neg hc, releaseM, AlgM.bind_eq, AlgM.bind, runO_bankRelease,
          State.orc_banks, hB, bp_bind_eq, bp_pure_eq, BitProg.map_bind]
        refine algEq_bind_congr _ (fun r => ?_)
        rcases r with ⟨_ | N1, B'⟩
        · simp only [runO_pure, AlgM.pure_eq, algEq_map_pure]; rfl
        · by_cases hN : inRangeA P N1 = true
          · simp only [if_pos hN, bankOpM, AlgM.bind, runO_bankOp]
            exact runO_rejectTailCode P d Ld _ N1
              { s with banks := (modifyAt (Bank.mapRows (Row.scaleY P
                  (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat)))
                  d (setAt B' d s.banks)) }
          · simp only [if_neg hN, runO_pure, AlgM.pure_eq, algEq_map_pure]; rfl

set_option maxHeartbeats 300000 in
/-- Step 4 at one depth. -/
theorem runO_step4DepthCode (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) :
    runO P (step4DepthCode P d s.ctrl F) s.orc = (step4Depth P d s F).map State.split2 := by
  unfold step4DepthCode step4Depth
  simp only [State.ctrl_learners]
  cases hL : s.learners[d]? with
  | none => rfl
  | some Ld =>
    cases hB : s.banks[d]? with
    | none =>
      by_cases hS : inRangeA P (gridVal P.eHP Ld.cache + F) = true
      · simp only [if_pos hS, validateM, AlgM.bind_eq, AlgM.bind, runO_bankValidate,
          State.orc_banks, hB, runO_pure, AlgM.pure_eq]
        rfl
      · simp only [if_neg hS]; rfl
    | some Bd =>
      by_cases hS : inRangeA P (gridVal P.eHP Ld.cache + F) = true
      · simp only [if_pos hS, validateM, AlgM.bind_eq, AlgM.bind, runO_bankValidate,
          State.orc_banks, hB, bp_bind_eq, bp_pure_eq, BitProg.map_bind]
        refine algEq_bind_congr _ (fun r => ?_)
        rcases r with ⟨cert, B'⟩
        cases cert with
        | accept =>
          simp only [noteM, AlgM.bind, runO_note, runO_pure, AlgM.pure_eq, algEq_map_pure]
          rfl
        | high => exact runO_rejectDepthCode P d true F { s with banks := setAt B' d s.banks }
        | low => exact runO_rejectDepthCode P d false F { s with banks := setAt B' d s.banks }
        | termHigh => simp only [runO_pure, AlgM.pure_eq, algEq_map_pure]; rfl
        | termLow => simp only [runO_pure, AlgM.pure_eq, algEq_map_pure]; rfl
        | abort => simp only [runO_pure, AlgM.pure_eq, algEq_map_pure]; rfl
      · simp only [if_neg hS]; rfl

/-- Step 4 over a list of depths. -/
theorem runO_step4LoopCode (P : StreamParams) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ),
      runO P (step4LoopCode P ds s.ctrl F) s.orc = (step4Loop P ds s F).map State.split2
  | [], _, _ => rfl
  | d :: ds, s, F => by
    simp only [step4LoopCode, step4Loop]
    by_cases hf : s.failed = true
    · have hc : s.ctrl.failed = true := hf
      simp only [if_pos hf, if_pos hc, AlgM.pure_eq, runO_pure, bp_pure_eq, algEq_map_pure]
      rfl
    · have hc : ¬ s.ctrl.failed = true := hf
      simp only [if_neg hf, if_neg hc, AlgM.bind_eq, runO_bind, runO_step4DepthCode, bp_bind_eq,
        algEq_map_bind, BitProg.map_bind]
      exact algEq_bind_congr _ (fun r => runO_step4LoopCode P ds r.1 r.2)

/-- Step 4. -/
theorem runO_step4Code (P : StreamParams) (s : State) :
    runO P (step4Code P s.ctrl) s.orc = (step4 P s).map State.split2 :=
  runO_step4LoopCode P (List.range P.H).reverse s (gridVal P.eHleaf s.leaf)

/-! ### One round -/

/-- Closing a round (failed or finished): the two sides agree, for every state. -/
theorem finish_split (s : State) (F : ℚ) :
    BitProg.pure (finishC s.ctrl F, s.orc) = (BitProg.pure (finishRound s F)).map State.split2 :=
  rfl

/-- A round with its four steps abstracted (due to c186bcb5): the controller code and the direct
code agree whenever the four steps do. Instantiated by `runO_roundCode`; since the steps are
variables here, no proof term ever exposes `step2 …`/`step3 …` to reduction. -/
theorem round_generic (P : StreamParams) (s : State) (A1 : AlgM CState) (p1 : BitProg State)
    (A2 : CState → AlgM (CState × Bool)) (f2 : State → State × Bool)
    (A3 : CState → AlgM CState) (f3 : State → State)
    (A4 : CState → AlgM (CState × ℚ)) (f4 : State → BitProg (State × ℚ))
    (e1 : runO P A1 s.orc = p1.map State.split)
    (e2 : ∀ s1 : State, runO P (A2 s1.ctrl) s1.orc = BitProg.pure (State.split2 (f2 s1)))
    (e3 : ∀ s1 : State, runO P (A3 s1.ctrl) s1.orc = BitProg.pure (State.split (f3 s1)))
    (e4 : ∀ s1 : State, runO P (A4 s1.ctrl) s1.orc = (f4 s1).map State.split2) :
    runO P (if s.ctrl.failed then pure (finishC s.ctrl 0)
      else do
        noteM TreeEvent.newRound
        let c1 ← A1
        if c1.failed then pure (finishC c1 0)
        else do
          let r2 ← A2 c1
          if r2.1.failed || r2.2 then pure (finishC r2.1 0)
          else do
            let c3 ← A3 r2.1
            if c3.failed then pure (finishC c3 0)
            else do
              let r4 ← A4 c3
              pure (finishC r4.1 r4.2)) s.orc =
    (if s.failed then pure (finishRound s 0)
      else do
        let s1 ← p1
        if s1.failed then pure (finishRound s1 0)
        else
          let r2 := f2 s1
          if r2.1.failed || r2.2 then pure (finishRound r2.1 0)
          else
            let s3 := f3 r2.1
            if s3.failed then pure (finishRound s3 0)
            else do
              let r4 ← f4 s3
              pure (finishRound r4.1 r4.2)).map State.split2 := by
  by_cases hf : s.failed = true
  · have hc : s.ctrl.failed = true := hf
    rw [if_pos hc, if_pos hf]
    exact finish_split s 0
  · have hc : ¬ s.ctrl.failed = true := hf
    rw [if_neg hc, if_neg hf]
    simp only [noteM, AlgM.bind_eq, AlgM.bind, runO_note, runO_bind, e1, algEq_map_bind,
      bp_bind_eq, BitProg.map_bind]
    refine algEq_bind_congr _ (fun s1 => ?_)
    have hs1 : (State.split s1).1 = s1.ctrl := rfl
    have hs2 : (State.split s1).2 = s1.orc := rfl
    rw [hs1, hs2]
    by_cases h1 : s1.failed = true
    · have h1c : s1.ctrl.failed = true := h1
      rw [if_pos h1c, if_pos h1]
      exact finish_split s1 0
    · have h1c : ¬ s1.ctrl.failed = true := h1
      rw [if_neg h1c, if_neg h1, runO_bind, e2 s1, BitProg.bind_pure']
      have hx1 : (State.split2 (f2 s1)).1.1 = (f2 s1).1.ctrl := rfl
      have hx2 : (State.split2 (f2 s1)).1.2 = (f2 s1).2 := rfl
      have hx3 : (State.split2 (f2 s1)).2 = (f2 s1).1.orc := rfl
      rw [hx1, hx2, hx3]
      by_cases h2 : ((f2 s1).1.failed || (f2 s1).2) = true
      · have h2c : ((f2 s1).1.ctrl.failed || (f2 s1).2) = true := h2
        rw [if_pos h2c, if_pos h2]
        exact finish_split (f2 s1).1 0
      · have h2c : ¬ ((f2 s1).1.ctrl.failed || (f2 s1).2) = true := h2
        rw [if_neg h2c, if_neg h2, runO_bind, e3 (f2 s1).1, BitProg.bind_pure']
        have hy1 : (State.split (f3 (f2 s1).1)).1 = (f3 (f2 s1).1).ctrl := rfl
        have hy2 : (State.split (f3 (f2 s1).1)).2 = (f3 (f2 s1).1).orc := rfl
        rw [hy1, hy2]
        by_cases h3 : (f3 (f2 s1).1).failed = true
        · have h3c : (f3 (f2 s1).1).ctrl.failed = true := h3
          rw [if_pos h3c, if_pos h3]
          exact finish_split (f3 (f2 s1).1) 0
        · have h3c : ¬ (f3 (f2 s1).1).ctrl.failed = true := h3
          rw [if_neg h3c, if_neg h3, runO_bind, e4 (f3 (f2 s1).1), algEq_map_bind,
            BitProg.map_bind]
          exact algEq_bind_congr _ (fun a => finish_split a.1 a.2)

/-- One round. -/
theorem runO_roundCode (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    runO P (roundCode P s.ctrl i Δ) s.orc = (roundStep P s i Δ).map State.split2 :=
  round_generic P s (step1Code P s.ctrl) (step1 P s) (step2Code P i Δ) (step2 P i Δ)
    (step3Code P) (step3 P) (step4Code P) (step4 P) (runO_step1Code P s) (runO_step2Code P i Δ)
    (runO_step3Code P) (runO_step4Code P)

/-- The initialization of `Round.lean` is the interpretation of `initCode` (same fresh bits, same
initial state). -/
theorem algInit_eq_interp (P : StreamParams) : algInit P = algInitM P := by
  unfold algInitM algInit initState initCode
  simp only [fpInitM, bankNewM, AlgM.bind_eq, AlgM.bind, AlgM.pure_eq, runO_fpInit, runO_bankNew,
    runO_pure, bp_bind_eq, bp_pure_eq, BitProg.bind_assoc, BitProg.bind_pure']
  rfl

/-- A round of `Round.lean` is the interpretation of `roundCode` (same fresh bits, same new state,
same estimate), from every state and for every update. -/
theorem algStep_eq_interp (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    algStep P s i Δ = algStepM P s i Δ := by
  unfold algStepM algStep
  rw [runO_roundCode, algEq_map_bind]
  exact (BitProg.bind_pure_right _).symm.trans (algEq_bind_congr _ (fun r => rfl))

end F2e2e.C.Alg
