import Mathlib
import F2e2e.C.Alg.Bank
import F2e2e.C.Alg.Fingerprint

/-!
# The Theorem C algorithm as controller code over oracle calls

The round procedure of Algorithms 1 and 4 (`parts/partII.tex` L216–231, `parts/partIII.tex`
L466–517) only touches the Norm Banks and the zero fingerprint through a few primitive operations.
`AlgM α` is the free monad over these primitives (non-dependent constructors, so it lives in `Type`):

* `fpInit` (Algorithm 1 line 1: sample `r_fp`, set `F_zero = 0`) and `fpStep i Δ` (line 3, for the
  1-based coordinate `i`; returns whether `F_zero = 0`);
* `bankNew tr d` (allocate a fresh bank at the end of the bank list: the root bank `𝓑_{-1}` is
  `bankNew 0 0` at initialization, the outgoing bank `𝓑_d` of a depth-`d` learner born at round
  `tr ≥ 1` is `bankNew tr d`; the arguments are labels for the analysis, not read by the
  implementation), `bankRetain n` (retire all banks of index `≥ n`);
* `bankOp idx op`, `bankOpFrom idx op` (apply the row operation `op` to every row of bank `idx`,
  resp. of every bank of index `≥ idx`);
* `bankValidate idx S θ` (`ValidateInterval`, returns the certificate) and `bankRelease idx mode`
  (`ReleaseNumerical`, returns `N` or `none` on an exhausted cap / abort);
* `note ev`: a no-op recording an analysis event (`TreeEvent`); never read by the algorithm.

The controller code (`F2e2e/C/Alg/AlgMCode.lean`) keeps the learners, the terminal accumulator, the
round counter and the failure flag (`CState`); the oracle state `OState` holds the fingerprint
registers and the banks. The real interpreter `runO` implements every primitive by the Norm Bank and
fingerprint procedures of `Bank.lean` / `Fingerprint.lean` (fresh bits as `BitProg`). A missing bank
index makes `bankValidate` return `abort`, `bankRelease` return `none`, and the row operations no-ops
(the controller then enters the failure state).
-/

namespace F2e2e.C.Alg

open F2e2e.B
open F2e2e.Discrete

/-! ## Row operations and analysis events -/

/-- The row operations of Algorithm 4 (each a function of the row's seed and counters only). -/
inductive RowOp where
  /-- Step 2 (L482): add `Δ b_i` (1-based coordinate `i`) to both counters. -/
  | phys (i : ℕ) (Δ : ℤ) : RowOp
  /-- Step 3 (L491): add the guard `δ e_g` (`δ` a mantissa on `h_g`) to the secondary counter. -/
  | guardY (g : ℕ) (δ : ℤ) : RowOp
  /-- Step 3 (L491): add the guard `δ e_g` to both counters. -/
  | guardXY (g : ℕ) (δ : ℤ) : RowOp
  /-- Step 4 (L505): multiply the secondary counter by `c = cInt h_step`. -/
  | scaleY (cInt : ℤ) : RowOp
  /-- Step 4 (L506): multiply both counters by `c = cInt h_step`. -/
  | scaleXY (cInt : ℤ) : RowOp
  /-- Step 1 (L475): reset the client-secondary counter. -/
  | resetY : RowOp

/-- The effect of a row operation on one row. -/
def RowOp.apply (P : StreamParams) : RowOp → Row → Row
  | RowOp.phys i Δ => Row.addPhys P i Δ
  | RowOp.guardY g δ => Row.addGuardY P g δ
  | RowOp.guardXY g δ => Row.addGuardXY P g δ
  | RowOp.scaleY c => Row.scaleY P c
  | RowOp.scaleXY c => Row.scaleXY P c
  | RowOp.resetY => Row.resetY

/-- Events of the analytical (shadow) semantics of Section 5, emitted where they happen. -/
inductive TreeEvent where
  /-- a round starts (not failed; before Step 1) -/
  | newRound : TreeEvent
  /-- a depth-`d` learner is born (after its record is allocated) -/
  | birth (d : ℕ) : TreeEvent
  /-- the physical update `x_i ← x_i + Δ` (1-based coordinate `i`) -/
  | phys (i : ℕ) (Δ : ℤ) : TreeEvent
  /-- the Step-3 guard `δ e_g` of depth `d` (`g = g(d,t)`, `δ` a mantissa on `h_g`; `δ = 0` for an
  omitted guard), once per depth entering Step 3 -/
  | guard (d g : ℕ) (δ : ℤ) : TreeEvent
  /-- the Step-4 validation of depth `d` returned `ACCEPT` -/
  | accept (d : ℕ) : TreeEvent
  /-- the Step-4 correction of depth `d` with multiplier `c = cInt h_step` -/
  | correct (d : ℕ) (cInt : ℤ) : TreeEvent

/-! ## The free monad of primitive calls -/

/-- Programs over the primitive oracle calls. -/
inductive AlgM (α : Type) : Type where
  | pure : α → AlgM α
  | fpInit : AlgM α → AlgM α
  | fpStep : ℕ → ℤ → (Bool → AlgM α) → AlgM α
  | bankNew : ℕ → ℕ → AlgM α → AlgM α
  | bankRetain : ℕ → AlgM α → AlgM α
  | bankOp : ℕ → RowOp → AlgM α → AlgM α
  | bankOpFrom : ℕ → RowOp → AlgM α → AlgM α
  | bankValidate : ℕ → ℚ → ℚ → (AdaCert → AlgM α) → AlgM α
  | bankRelease : ℕ → Mode → (Option ℚ → AlgM α) → AlgM α
  | note : TreeEvent → AlgM α → AlgM α

namespace AlgM

/-- Sequential composition. -/
def bind {α β : Type} : AlgM α → (α → AlgM β) → AlgM β
  | pure a, f => f a
  | fpInit k, f => fpInit (bind k f)
  | fpStep i Δ k, f => fpStep i Δ (fun b => bind (k b) f)
  | bankNew tr d k, f => bankNew tr d (bind k f)
  | bankRetain n k, f => bankRetain n (bind k f)
  | bankOp idx op k, f => bankOp idx op (bind k f)
  | bankOpFrom idx op k, f => bankOpFrom idx op (bind k f)
  | bankValidate idx S θ k, f => bankValidate idx S θ (fun c => bind (k c) f)
  | bankRelease idx mode k, f => bankRelease idx mode (fun o => bind (k o) f)
  | note ev k, f => note ev (bind k f)

instance : Monad AlgM where
  pure := pure
  bind := bind

@[simp] theorem bind_eq {α β : Type} (p : AlgM α) (f : α → AlgM β) : (p >>= f) = p.bind f := rfl

@[simp] theorem pure_eq {α : Type} (a : α) : (Pure.pure a : AlgM α) = AlgM.pure a := rfl

@[simp] theorem pure_bind {α β : Type} (a : α) (f : α → AlgM β) : (pure a).bind f = f a := rfl

@[simp] theorem bind_pure {α : Type} : ∀ p : AlgM α, p.bind pure = p
  | pure _ => rfl
  | fpInit k => by simp only [bind, bind_pure k]
  | fpStep i Δ k => by simp only [bind, bind_pure]
  | bankNew tr d k => by simp only [bind, bind_pure k]
  | bankRetain n k => by simp only [bind, bind_pure k]
  | bankOp idx op k => by simp only [bind, bind_pure k]
  | bankOpFrom idx op k => by simp only [bind, bind_pure k]
  | bankValidate idx S θ k => by simp only [bind, bind_pure]
  | bankRelease idx mode k => by simp only [bind, bind_pure]
  | note ev k => by simp only [bind, bind_pure k]

theorem bind_assoc {α β γ : Type} (f : α → AlgM β) (g : β → AlgM γ) :
    ∀ p : AlgM α, (p.bind f).bind g = p.bind (fun a => (f a).bind g)
  | pure _ => rfl
  | fpInit k => by simp only [bind, bind_assoc f g k]
  | fpStep i Δ k => by simp only [bind, bind_assoc f g]
  | bankNew tr d k => by simp only [bind, bind_assoc f g k]
  | bankRetain n k => by simp only [bind, bind_assoc f g k]
  | bankOp idx op k => by simp only [bind, bind_assoc f g k]
  | bankOpFrom idx op k => by simp only [bind, bind_assoc f g k]
  | bankValidate idx S θ k => by simp only [bind, bind_assoc f g]
  | bankRelease idx mode k => by simp only [bind, bind_assoc f g]
  | note ev k => by simp only [bind, bind_assoc f g k]

end AlgM

/-! ## Primitive actions -/

/-- Algorithm 1 line 1: sample the fingerprint seed and set `F_zero = 0`. -/
def fpInitM : AlgM Unit := AlgM.fpInit (AlgM.pure ())

/-- Algorithm 1 line 3 for the 1-based coordinate `i`; returns whether `F_zero^{(t)} = 0`. -/
def fpStepM (i : ℕ) (Δ : ℤ) : AlgM Bool := AlgM.fpStep i Δ AlgM.pure

/-- Allocate a fresh bank (labels `tr`, `d`). -/
def bankNewM (tr d : ℕ) : AlgM Unit := AlgM.bankNew tr d (AlgM.pure ())

/-- Retire all banks of index `≥ n`. -/
def bankRetainM (n : ℕ) : AlgM Unit := AlgM.bankRetain n (AlgM.pure ())

/-- Apply a row operation to every row of bank `idx`. -/
def bankOpM (idx : ℕ) (op : RowOp) : AlgM Unit := AlgM.bankOp idx op (AlgM.pure ())

/-- Apply a row operation to every row of every bank of index `≥ idx`. -/
def bankOpFromM (idx : ℕ) (op : RowOp) : AlgM Unit := AlgM.bankOpFrom idx op (AlgM.pure ())

/-- `ValidateInterval(S, θ)` on bank `idx`. -/
def validateM (idx : ℕ) (S θ : ℚ) : AlgM AdaCert := AlgM.bankValidate idx S θ AlgM.pure

/-- `ReleaseNumerical(mode)` on bank `idx`. -/
def releaseM (idx : ℕ) (mode : Mode) : AlgM (Option ℚ) := AlgM.bankRelease idx mode AlgM.pure

/-- Record an analysis event (no effect on the algorithm). -/
def noteM (ev : TreeEvent) : AlgM Unit := AlgM.note ev (AlgM.pure ())

/-! ## The oracle state and the real interpreter -/

/-- The oracle part of the memory: the fingerprint registers and the live banks
`𝓑_{-1}, …, 𝓑_{H-2}` (bank `𝓑_e` at index `e + 1`). -/
structure OState where
  /-- the secret fingerprint seed `r_fp ∈ 𝔽_q` -/
  fpSeed : ℕ
  /-- the fingerprint register `F_zero ∈ 𝔽_q` -/
  fpVal : ℕ
  /-- the live banks -/
  banks : List Bank

/-- The implementation of `bankNew tr d`: a fresh bank (the labels are not used). -/
def bankNewImpl (P : StreamParams) (_tr _d : ℕ) : BitProg Bank := newBank P

/-- The real interpreter: every primitive is implemented by the Norm Bank / fingerprint procedure
on fresh bits. -/
def runO (P : StreamParams) {α : Type} : AlgM α → OState → BitProg (α × OState)
  | AlgM.pure a, o => BitProg.pure (a, o)
  | AlgM.fpInit k, o =>
    (fpSeedProg P).bind fun r => runO P k { o with fpSeed := r, fpVal := 0 }
  | AlgM.fpStep i Δ k, o =>
    runO P (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0))
      { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
  | AlgM.bankNew tr d k, o =>
    (bankNewImpl P tr d).bind fun B => runO P k { o with banks := o.banks ++ [B] }
  | AlgM.bankRetain n k, o => runO P k { o with banks := o.banks.take n }
  | AlgM.bankOp idx op k, o =>
    runO P k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
  | AlgM.bankOpFrom idx op k, o =>
    runO P k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
  | AlgM.bankValidate idx S θ k, o =>
    match o.banks[idx]? with
    | none => runO P (k AdaCert.abort) o
    | some B =>
      (B.validate P S θ).bind fun r => runO P (k r.1) { o with banks := setAt r.2 idx o.banks }
  | AlgM.bankRelease idx mode k, o =>
    match o.banks[idx]? with
    | none => runO P (k none) o
    | some B =>
      (B.release P mode).bind fun r => runO P (k r.1) { o with banks := setAt r.2 idx o.banks }
  | AlgM.note _ k, o => runO P k o

section runO_eqns

variable (P : StreamParams) {α : Type}

@[simp] theorem runO_pure (a : α) (o : OState) : runO P (AlgM.pure a) o = BitProg.pure (a, o) :=
  rfl

@[simp] theorem runO_fpInit (k : AlgM α) (o : OState) :
    runO P (AlgM.fpInit k) o =
      (fpSeedProg P).bind fun r => runO P k { o with fpSeed := r, fpVal := 0 } := rfl

@[simp] theorem runO_fpStep (i : ℕ) (Δ : ℤ) (k : Bool → AlgM α) (o : OState) :
    runO P (AlgM.fpStep i Δ k) o =
      runO P (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0))
        { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ } := rfl

@[simp] theorem runO_bankNew (tr d : ℕ) (k : AlgM α) (o : OState) :
    runO P (AlgM.bankNew tr d k) o =
      (bankNewImpl P tr d).bind fun B => runO P k { o with banks := o.banks ++ [B] } := rfl

@[simp] theorem runO_bankRetain (n : ℕ) (k : AlgM α) (o : OState) :
    runO P (AlgM.bankRetain n k) o = runO P k { o with banks := o.banks.take n } := rfl

@[simp] theorem runO_bankOp (idx : ℕ) (op : RowOp) (k : AlgM α) (o : OState) :
    runO P (AlgM.bankOp idx op k) o =
      runO P k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks } := rfl

@[simp] theorem runO_bankOpFrom (idx : ℕ) (op : RowOp) (k : AlgM α) (o : OState) :
    runO P (AlgM.bankOpFrom idx op k) o =
      runO P k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks } := rfl

@[simp] theorem runO_bankValidate (idx : ℕ) (S θ : ℚ) (k : AdaCert → AlgM α) (o : OState) :
    runO P (AlgM.bankValidate idx S θ k) o =
      match o.banks[idx]? with
      | none => runO P (k AdaCert.abort) o
      | some B =>
        (B.validate P S θ).bind fun r => runO P (k r.1) { o with banks := setAt r.2 idx o.banks } := by
  rw [runO]

@[simp] theorem runO_bankRelease (idx : ℕ) (mode : Mode) (k : Option ℚ → AlgM α) (o : OState) :
    runO P (AlgM.bankRelease idx mode k) o =
      match o.banks[idx]? with
      | none => runO P (k none) o
      | some B =>
        (B.release P mode).bind fun r => runO P (k r.1) { o with banks := setAt r.2 idx o.banks } := by
  rw [runO]

@[simp] theorem runO_note (ev : TreeEvent) (k : AlgM α) (o : OState) :
    runO P (AlgM.note ev k) o = runO P k o := rfl

end runO_eqns

/-- Associativity of `BitProg.bind`. -/
theorem bp_bind_assoc {α β γ : Type} (f : α → BitProg β) (g : β → BitProg γ) :
    ∀ p : BitProg α, (p.bind f).bind g = p.bind (fun a => (f a).bind g)
  | BitProg.pure _ => rfl
  | BitProg.bit k => by
    show BitProg.bit (fun b => ((k b).bind f).bind g) = BitProg.bit (fun b => (k b).bind _)
    congr 1; funext b; exact bp_bind_assoc f g (k b)

/-- The interpreter commutes with sequential composition. -/
theorem runO_bind (P : StreamParams) {α β : Type} (f : α → AlgM β) :
    ∀ (p : AlgM α) (o : OState),
      runO P (p.bind f) o = (runO P p o).bind (fun r => runO P (f r.1) r.2)
  | AlgM.pure _, _ => rfl
  | AlgM.fpInit k, o => by
    simp only [AlgM.bind, runO_fpInit, bp_bind_assoc]
    congr 1; funext r; exact runO_bind P f k _
  | AlgM.fpStep i Δ k, o => by
    simp only [AlgM.bind, runO_fpStep]; exact runO_bind P f (k _) _
  | AlgM.bankNew tr d k, o => by
    simp only [AlgM.bind, runO_bankNew, bp_bind_assoc]
    congr 1; funext B; exact runO_bind P f k _
  | AlgM.bankRetain n k, o => by simp only [AlgM.bind, runO_bankRetain]; exact runO_bind P f k _
  | AlgM.bankOp idx op k, o => by simp only [AlgM.bind, runO_bankOp]; exact runO_bind P f k _
  | AlgM.bankOpFrom idx op k, o => by
    simp only [AlgM.bind, runO_bankOpFrom]; exact runO_bind P f k _
  | AlgM.bankValidate idx S θ k, o => by
    simp only [AlgM.bind, runO_bankValidate]
    split
    · exact runO_bind P f (k _) _
    · rw [bp_bind_assoc]; congr 1; funext r; exact runO_bind P f (k _) _
  | AlgM.bankRelease idx mode k, o => by
    simp only [AlgM.bind, runO_bankRelease]
    split
    · exact runO_bind P f (k _) _
    · rw [bp_bind_assoc]; congr 1; funext r; exact runO_bind P f (k _) _
  | AlgM.note ev k, o => by simp only [AlgM.bind, runO_note]; exact runO_bind P f k _

end F2e2e.C.Alg
