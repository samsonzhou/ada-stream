import Mathlib
import F2e2e.C.Alg.Bits

/-!
# Helper lemmas about the Theorem C algorithm (for `F2e2e/C/Alg/Facts.lean`)

* `Always p Q` (every output of the bit program `p`, on every path of fresh bits, satisfies `Q`)
  and its calculus;
* length / lookup lemmas for the list helpers `modifyAt`, `setAt`, `mapFrom`;
* integer square roots: `floorSqrtQ` and `ceilSqrtQ` compute `⌊√r⌋` and `⌈√r⌉`; rounding facts;
* the schedule: `firstBorn_lt`, `firstBorn_one`, nestedness of lifetimes;
* the preserved quantities of every sub-step of a round (`Pres`, `Out4`, `Frame1`, `Birth1`):
  round counter, fingerprint registers, numbers of live learners and banks, monotonicity of the
  failure flag, range of the returned values; `roundStep_out`;
* the terminal accumulator through Steps 2–3 (`step2_leaf`, `step3Loop_leaf`).
-/

namespace F2e2e.C.Alg

open F2e2e.B

open F2e2e.Discrete

/-! ## Every-path predicates on bit programs -/

/-- `Always p Q`: every output of `p`, on every path of fresh bits, satisfies `Q`. -/
def Always {α : Type} : BitProg α → (α → Prop) → Prop
  | BitProg.pure a, Q => Q a
  | BitProg.bit k, Q => ∀ b, Always (k b) Q

theorem Always.of_run {α : Type} {Q : α → Prop} :
    ∀ {p : BitProg α}, Always p Q → ∀ {t : List Bool} {a : α} {r : List Bool},
      p.run t = some (a, r) → Q a
  | BitProg.pure a, h, t, a', r, hr => by
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hr
    exact hr.1 ▸ h
  | BitProg.bit _, _, [], _, _, hr => by simp at hr
  | BitProg.bit k, h, b :: t, a', r, hr => by
    simp only [BitProg.run_bit_cons] at hr
    exact Always.of_run (h b) hr

theorem Always.mono {α : Type} {Q Q' : α → Prop} (hQ : ∀ a, Q a → Q' a) :
    ∀ {p : BitProg α}, Always p Q → Always p Q'
  | BitProg.pure a, h => hQ a h
  | BitProg.bit _k, h => fun b => Always.mono hQ (h b)

theorem Always.bind {α β : Type} {Q : α → Prop} {R : β → Prop} {f : α → BitProg β}
    (hf : ∀ a, Q a → Always (f a) R) : ∀ {p : BitProg α}, Always p Q → Always (p.bind f) R
  | BitProg.pure a, h => hf a h
  | BitProg.bit _k, h => fun b => Always.bind hf (h b)

theorem always_pure {α : Type} {Q : α → Prop} {a : α} (h : Q a) : Always (BitProg.pure a) Q := h

theorem Always.true' {α : Type} : ∀ (p : BitProg α), Always p (fun _ => True)
  | BitProg.pure _ => trivial
  | BitProg.bit k => fun b => Always.true' (k b)

theorem Always.bind_all {α β : Type} {R : β → Prop} {f : α → BitProg β}
    (hf : ∀ a, Always (f a) R) (p : BitProg α) : Always (p.bind f) R :=
  Always.bind (Q := fun _ => True) (fun a _ => hf a) (Always.true' p)

/-! ## Range checks and failure -/

theorem inRangeA_iff (P : StreamParams) (x : ℚ) :
    inRangeA P x = true ↔ 0 ≤ x ∧ x ≤ (P.Amax : ℚ) :=
  decide_eq_true_iff

theorem fail_failed (s : State) : s.fail.failed = true := rfl

theorem not_fail_false {s : State} (h : s.fail.failed = false) : False := by
  rw [fail_failed] at h; exact Bool.noConfusion h

/-! ## The list helpers -/

@[simp] theorem length_modifyAt {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (modifyAt f k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, _ :: l => by simp [modifyAt, length_modifyAt f k l]

@[simp] theorem length_setAt {α : Type} (b : α) :
    ∀ (k : ℕ) (l : List α), (setAt b k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, _ :: l => by simp [setAt, length_setAt b k l]

@[simp] theorem length_mapFrom {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (mapFrom f k l).length = l.length
  | _, [] => rfl
  | 0, _ :: l => by simp [mapFrom, length_mapFrom f 0 l]
  | k + 1, _ :: l => by simp [mapFrom, length_mapFrom f k l]

theorem getElem?_setAt_ne {α : Type} (b : α) :
    ∀ (k : ℕ) (l : List α) (j : ℕ), j ≠ k → (setAt b k l)[j]? = l[j]?
  | k, [], _, _ => by cases k <;> rfl
  | 0, _ :: _, 0, h => absurd rfl h
  | 0, _ :: _, _ + 1, _ => rfl
  | _ + 1, _ :: _, 0, _ => rfl
  | k + 1, _ :: l, j + 1, h => by
    simp only [setAt, List.getElem?_cons_succ]
    exact getElem?_setAt_ne b k l j (fun e => h (by rw [e]))

theorem getElem?_setAt_self {α : Type} (b : α) :
    ∀ (k : ℕ) (l : List α), k < l.length → (setAt b k l)[k]? = some b
  | _, [], h => absurd h (Nat.not_lt_zero _)
  | 0, _ :: _, _ => rfl
  | k + 1, _ :: l, h => by
    simp only [setAt, List.getElem?_cons_succ]
    exact getElem?_setAt_self b k l (by simpa using h)

theorem getElem?_mapFrom {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α) (j : ℕ), (mapFrom f k l)[j]? = if k ≤ j then (l[j]?).map f else l[j]?
  | _, [], j => by simp [mapFrom]
  | 0, a :: l, 0 => by simp [mapFrom]
  | 0, a :: l, j + 1 => by
    simp only [mapFrom, List.getElem?_cons_succ]
    rw [getElem?_mapFrom f 0 l j]; simp
  | k + 1, a :: l, 0 => by simp [mapFrom]
  | k + 1, a :: l, j + 1 => by
    simp only [mapFrom, List.getElem?_cons_succ]
    rw [getElem?_mapFrom f k l j]
    simp only [Nat.add_le_add_iff_right]

theorem list_range_map_sum {β : Type} [AddCommMonoid β] (f : ℕ → β) :
    ∀ n, ((List.range n).map f).sum = ∑ d ∈ Finset.range n, f d
  | 0 => by simp
  | n + 1 => by
    rw [List.range_succ, List.map_append, List.sum_append, list_range_map_sum f n,
      Finset.sum_range_succ]
    simp

/-! ## Integer square roots and rounding -/

/-- `floorSqrtQ` computes `⌊√r⌋`: for `x ≥ 0` with `x² = r`, `floorSqrtQ r = ⌊x⌋`. -/
theorem floorSqrtQ_eq (r : ℚ) (x : ℝ) (hx : 0 ≤ x) (hr : x ^ 2 = (r : ℝ)) :
    ((floorSqrtQ r : ℕ) : ℝ) ≤ x ∧ x < (floorSqrtQ r : ℝ) + 1 := by
  have hr0 : (0 : ℝ) ≤ r := by rw [← hr]; positivity
  have hr0' : (0 : ℚ) ≤ r := by exact_mod_cast hr0
  set N : ℕ := ⌊r⌋.toNat with hN
  have hfl : (0 : ℤ) ≤ ⌊r⌋ := Int.floor_nonneg.mpr hr0'
  have hNr : (N : ℝ) ≤ (r : ℝ) := by
    have h1 : ((⌊r⌋ : ℤ) : ℚ) ≤ r := Int.floor_le r
    have h2 : ((N : ℤ) : ℚ) = ((⌊r⌋ : ℤ) : ℚ) := by rw [hN, Int.toNat_of_nonneg hfl]
    have : (N : ℚ) ≤ r := by exact_mod_cast (h2 ▸ h1 : ((N : ℤ) : ℚ) ≤ r)
    exact_mod_cast this
  have hrN : (r : ℝ) < N + 1 := by
    have h1 : r < ((⌊r⌋ : ℤ) : ℚ) + 1 := Int.lt_floor_add_one r
    have h2 : ((N : ℤ) : ℚ) = ((⌊r⌋ : ℤ) : ℚ) := by rw [hN, Int.toNat_of_nonneg hfl]
    have : r < (N : ℚ) + 1 := by
      have := h2 ▸ h1
      exact_mod_cast this
    exact_mod_cast this
  set s := Nat.sqrt N with hs
  have hs1 : s ^ 2 ≤ N := Nat.sqrt_le' N
  have hs2 : N < (s + 1) ^ 2 := Nat.lt_succ_sqrt' N
  have hs1' : (s : ℝ) ^ 2 ≤ N := by exact_mod_cast hs1
  have hs2' : (N : ℝ) + 1 ≤ ((s : ℝ) + 1) ^ 2 := by exact_mod_cast hs2
  unfold floorSqrtQ
  rw [← hN, ← hs]
  constructor
  · have : (s : ℝ) ^ 2 ≤ x ^ 2 := by rw [hr]; linarith
    exact (pow_le_pow_iff_left₀ (by positivity) hx (by norm_num)).mp this
  · have : x ^ 2 < ((s : ℝ) + 1) ^ 2 := by rw [hr]; linarith
    exact (pow_lt_pow_iff_left₀ hx (by positivity) (by norm_num)).mp this


theorem floor_add_half_eq (y : ℝ) (s : ℕ) (h1 : (s : ℝ) ≤ 2 * y) (h2 : 2 * y < s + 1) :
    ⌊y + 1 / 2⌋ = (((s + 1) / 2 : ℕ) : ℤ) := by
  set m : ℕ := (s + 1) / 2 with hm
  rw [Int.floor_eq_iff, Int.cast_natCast]
  have hm1 : 2 * m ≤ s + 1 := Nat.mul_div_le (s + 1) 2
  have hm2 : s ≤ 2 * m := by omega
  have hm1' : (2 : ℝ) * (m : ℝ) ≤ s + 1 := by exact_mod_cast hm1
  have hm2' : (s : ℝ) ≤ 2 * (m : ℝ) := by exact_mod_cast hm2
  constructor <;> linarith

theorem ceilSqrtQ_eq (r : ℚ) (x : ℝ) (hx : 0 ≤ x) (hr : x ^ 2 = (r : ℝ)) :
    (ceilSqrtQ r : ℝ) - 1 < x ∧ x ≤ (ceilSqrtQ r : ℝ) := by
  have hr0 : (0 : ℝ) ≤ r := by rw [← hr]; positivity
  have hr0' : (0 : ℚ) ≤ r := by exact_mod_cast hr0
  set N : ℕ := ⌈r⌉.toNat with hN
  have hcl : (0 : ℤ) ≤ ⌈r⌉ := Int.ceil_nonneg hr0'
  have hNz : ((N : ℤ) : ℚ) = ((⌈r⌉ : ℤ) : ℚ) := by rw [hN, Int.toNat_of_nonneg hcl]
  have hrN : (r : ℝ) ≤ N := by
    have h1 : r ≤ ((⌈r⌉ : ℤ) : ℚ) := Int.le_ceil r
    have : r ≤ (N : ℚ) := by exact_mod_cast (hNz ▸ h1 : r ≤ ((N : ℤ) : ℚ))
    exact_mod_cast this
  have hNr : (N : ℝ) < r + 1 := by
    have h1 : ((⌈r⌉ : ℤ) : ℚ) < r + 1 := Int.ceil_lt_add_one r
    have : (N : ℚ) < r + 1 := by exact_mod_cast (hNz ▸ h1 : ((N : ℤ) : ℚ) < r + 1)
    exact_mod_cast this
  set k := Nat.sqrt N with hk
  have hk1 : k ^ 2 ≤ N := Nat.sqrt_le' N
  have hk2 : N < (k + 1) ^ 2 := Nat.lt_succ_sqrt' N
  unfold ceilSqrtQ
  simp only [← hN, ← hk]
  split_ifs with heq
  · -- `k² = N`
    have hkN : (k : ℝ) ^ 2 = N := by exact_mod_cast (show k ^ 2 = N by rw [sq]; exact heq)
    constructor
    · rcases Nat.eq_zero_or_pos k with h0 | hpos
      · rw [h0]; push_cast; linarith
      · have hk1r : (1 : ℝ) ≤ k := by exact_mod_cast hpos
        have : ((k : ℝ) - 1) ^ 2 < x ^ 2 := by nlinarith
        exact (pow_lt_pow_iff_left₀ (by linarith) hx (by norm_num)).mp this
    · have : x ^ 2 ≤ (k : ℝ) ^ 2 := by rw [hr, hkN]; exact hrN
      exact (pow_le_pow_iff_left₀ hx (by positivity) (by norm_num)).mp this
  · -- `k² < N`
    have hlt : k ^ 2 < N := lt_of_le_of_ne hk1 (by rw [sq]; exact heq)
    have hlt' : (k : ℝ) ^ 2 + 1 ≤ N := by exact_mod_cast hlt
    have hk2' : (N : ℝ) + 1 ≤ ((k : ℝ) + 1) ^ 2 := by exact_mod_cast hk2
    push_cast
    constructor
    · have : (k : ℝ) ^ 2 < x ^ 2 := by rw [hr]; linarith
      have := (pow_lt_pow_iff_left₀ (by positivity) hx (by norm_num)).mp this
      linarith
    · have : x ^ 2 ≤ ((k : ℝ) + 1) ^ 2 := by rw [hr]; linarith
      exact (pow_le_pow_iff_left₀ hx (by positivity) (by norm_num)).mp this


theorem floor_neg_add_half_eq (w : ℝ) (c : ℕ) (h1 : (c : ℝ) - 1 < 2 * w) (h2 : 2 * w ≤ c) :
    ⌊-w + 1 / 2⌋ = -(((c / 2 : ℕ)) : ℤ) := by
  set m : ℕ := c / 2 with hm
  rw [Int.floor_eq_iff]
  have hm1 : 2 * m ≤ c := Nat.mul_div_le c 2
  have hm2 : c ≤ 2 * m + 1 := by omega
  have hm1' : (2 : ℝ) * (m : ℝ) ≤ c := by exact_mod_cast hm1
  have hm2' : (c : ℝ) ≤ 2 * (m : ℝ) + 1 := by exact_mod_cast hm2
  push_cast
  constructor <;> linarith

theorem gridVal_roundMant_exact (q : ℕ) (z : ℚ) (k : ℤ) (h : z * 2 ^ q = k) :
    gridVal q (roundMant q z) = z := by
  unfold gridVal roundMant
  rw [h]
  have : ⌊(k : ℚ) + 1 / 2⌋ = k := by
    rw [Int.floor_eq_iff]; constructor <;> linarith
  rw [this, ← h]
  field_simp

/-! ## The schedule (Definition `R:def:binary-tree-architecture` (1)) -/

theorem H_pos (P : StreamParams) : 1 ≤ P.H := by
  unfold StreamParams.H; omega

theorem bornAt_last (H tr : ℕ) : bornAt H (H - 1) tr = true := by
  simp [bornAt, Nat.mod_one]

theorem firstBorn_lt (H tr : ℕ) (hH : 1 ≤ H) : firstBorn H tr < H := by
  unfold firstBorn
  have h : (List.range H).findIdx (fun d => bornAt H d tr) < (List.range H).length := by
    apply List.findIdx_lt_length_of_exists
    exact ⟨H - 1, List.mem_range.mpr (by omega), bornAt_last H tr⟩
  simpa using h

theorem bornAt_mono {H d d' tr : ℕ} (hdd : d ≤ d') (h : bornAt H d tr = true) :
    bornAt H d' tr = true := by
  simp only [bornAt, beq_iff_eq] at h ⊢
  rw [← Nat.dvd_iff_mod_eq_zero] at h ⊢
  exact Nat.dvd_trans (Nat.pow_dvd_pow 2 (by omega)) h

theorem firstBorn_one (H : ℕ) (hH : 1 ≤ H) : firstBorn H 1 = 0 := by
  obtain ⟨H', rfl⟩ : ∃ H', H = H' + 1 := ⟨H - 1, by omega⟩
  simp [firstBorn, List.range_succ_eq_map, List.findIdx_cons, bornAt]

/-! ## The Step-3 guard of a depth -/

/-- The Step-3 guard mantissa of depth `d` in a state (it depends only on the tag and the epoch,
which Step 3 does not modify). -/
def guardOf (P : StreamParams) (s : State) (d : ℕ) : ℤ :=
  match s.learners[d]? with
  | none => 0
  | some Ld => guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))

/-! ## Steps 3 and 4: preserved quantities -/

/-- Steps 3 and 4 (and all their sub-steps) keep the round counter, the fingerprint registers and
the numbers of live learners and banks, and never clear the failure flag. -/
def Pres (s s' : State) : Prop :=
  s'.t = s.t ∧ s'.fpSeed = s.fpSeed ∧ s'.fpVal = s.fpVal ∧ (s.failed = true → s'.failed = true) ∧
    s'.learners.length = s.learners.length ∧ s'.banks.length = s.banks.length

theorem Pres.refl (s : State) : Pres s s := ⟨rfl, rfl, rfl, id, rfl, rfl⟩

theorem Pres.trans {s1 s2 s3 : State} (h1 : Pres s1 s2) (h2 : Pres s2 s3) : Pres s1 s3 :=
  ⟨h2.1.trans h1.1, h2.2.1.trans h1.2.1, h2.2.2.1.trans h1.2.2.1,
    fun h => h2.2.2.2.1 (h1.2.2.2.1 h), h2.2.2.2.2.1.trans h1.2.2.2.2.1,
    h2.2.2.2.2.2.trans h1.2.2.2.2.2⟩

theorem Pres.fail {s s' : State} (h : Pres s s') : Pres s s'.fail :=
  ⟨h.1, h.2.1, h.2.2.1, fun _ => rfl, h.2.2.2.2.1, h.2.2.2.2.2⟩


theorem pres_update (s : State) (ls : List Learner) (bs : List Bank) (leaf : ℤ)
    (hl : ls.length = s.learners.length) (hb : bs.length = s.banks.length) :
    Pres s { s with learners := ls, banks := bs, leaf := leaf } :=
  ⟨rfl, rfl, rfl, id, hl, hb⟩

theorem step3Depth_pres (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) :
    Pres s (step3Depth P tr s d) := by
  unfold step3Depth
  split
  · exact Pres.fail (Pres.refl s)
  · dsimp only
    split_ifs
    · exact Pres.refl s
    · exact pres_update s _ _ _ (by simp) (by simp)
    · exact Pres.fail (pres_update s _ _ _ rfl (by simp))

theorem step3Loop_pres (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State), Pres s (step3Loop P tr ds s)
  | [], s => Pres.refl s
  | d :: ds, s => by
    simp only [step3Loop]
    split_ifs
    · exact Pres.refl s
    · exact Pres.trans (step3Depth_pres P tr s d) (step3Loop_pres P tr ds _)

theorem step3_pres (P : StreamParams) (s : State) : Pres s (step3 P s) :=
  step3Loop_pres P _ _ _


def Out4 (P : StreamParams) (s : State) (r : State × ℚ) : Prop :=
  Pres s r.1 ∧ (r.1.failed = false → 0 ≤ r.2 ∧ r.2 ≤ (P.Amax : ℚ))

theorem out4_fail {P : StreamParams} {s s' : State} (h : Pres s s') (F : ℚ) :
    Out4 P s (s'.fail, F) :=
  ⟨Pres.fail h, fun h' => (not_fail_false h').elim⟩

theorem rejectTail_out (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (s : State)
    (hN1 : 0 ≤ N1 ∧ N1 ≤ (P.Amax : ℚ)) : Always (rejectTail P d Ld cInt N1 s) (Out4 P s) := by
  unfold rejectTail
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs
  · split
    · exact always_pure (out4_fail (pres_update s _ _ _ (by simp) (by simp)) 0)
    · refine Always.bind_all (fun r2 => ?_) _
      split
      · exact always_pure (out4_fail (pres_update s _ _ _ (by simp) (by simp)) 0)
      · split
        · exact always_pure (out4_fail (pres_update s _ _ _ (by simp) (by simp)) 0)
        · split_ifs
          · exact always_pure ⟨pres_update s _ _ _ (by simp) (by simp), fun _ => hN1⟩
          · exact always_pure (out4_fail (pres_update s _ _ _ (by simp) (by simp)) 0)
  · exact always_pure (out4_fail (pres_update s _ _ _ (by simp) (by simp)) 0)

theorem rejectDepth_out (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State) :
    Always (rejectDepth P d pos Qhat s) (Out4 P s) := by
  unfold rejectDepth
  split
  · simp only [bp_bind_eq, bp_pure_eq]
    split_ifs
    · exact always_pure (out4_fail (Pres.refl s) 0)
    · refine Always.bind_all (fun r1 => ?_) _
      split
      · exact always_pure (out4_fail (pres_update s _ _ _ rfl (by simp)) 0)
      · rename_i N1 _
        split_ifs with hN
        · exact Always.mono (fun r h => ⟨Pres.trans (pres_update s _ _ _ rfl (by simp)) h.1, h.2⟩)
            (rejectTail_out P _ _ _ _ _ ((inRangeA_iff P N1).mp hN))
        · exact always_pure (out4_fail (pres_update s _ _ _ rfl (by simp)) 0)
  · exact always_pure (out4_fail (Pres.refl s) 0)

theorem step4Depth_out (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) :
    Always (step4Depth P d s F) (Out4 P s) := by
  unfold step4Depth
  split
  · simp only [bp_bind_eq, bp_pure_eq]
    split_ifs with hS
    · refine Always.bind_all (fun res => ?_) _
      have h1 : Pres s { s with banks := setAt res.2 d s.banks } :=
        pres_update s _ _ _ rfl (by simp)
      split
      · exact always_pure ⟨h1, fun _ => (inRangeA_iff P _).mp hS⟩
      · exact Always.mono (fun r h => ⟨Pres.trans h1 h.1, h.2⟩) (rejectDepth_out P _ _ _ _)
      · exact Always.mono (fun r h => ⟨Pres.trans h1 h.1, h.2⟩) (rejectDepth_out P _ _ _ _)
      · exact always_pure (out4_fail h1 0)
    · exact always_pure (out4_fail (Pres.refl s) 0)
  · exact always_pure (out4_fail (Pres.refl s) 0)

theorem step4Loop_out (P : StreamParams) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), (ds = [] → s.failed = false → 0 ≤ F ∧ F ≤ (P.Amax : ℚ)) →
      Always (step4Loop P ds s F) (Out4 P s)
  | [], s, F, hF => always_pure ⟨Pres.refl s, hF rfl⟩
  | d :: ds, s, F, _ => by
    simp only [step4Loop, bp_bind_eq]
    split_ifs with hs
    · exact always_pure ⟨Pres.refl s, fun h => by rw [hs] at h; exact Bool.noConfusion h⟩
    · refine Always.bind (fun r hr => ?_) (step4Depth_out P d s F)
      exact Always.mono (fun r' h => ⟨Pres.trans hr.1 h.1, h.2⟩)
        (step4Loop_out P ds r.1 r.2 (fun _ => hr.2))

theorem step4_out (P : StreamParams) (s : State) : Always (step4 P s) (Out4 P s) := by
  unfold step4
  apply step4Loop_out
  intro h
  have : (List.range P.H).reverse ≠ [] := by
    simp only [ne_eq, List.reverse_eq_nil_iff, List.range_eq_nil]
    have := H_pos P; omega
  exact absurd h this

/-! ## Step 1 -/

/-- Step 1 keeps the round counter and the fingerprint registers and never clears failure. -/
def Frame1 (s s' : State) : Prop :=
  s'.t = s.t ∧ s'.fpSeed = s.fpSeed ∧ s'.fpVal = s.fpVal ∧ (s.failed = true → s'.failed = true)

theorem Frame1.refl (s : State) : Frame1 s s := ⟨rfl, rfl, rfl, id⟩

theorem Frame1.trans {s1 s2 s3 : State} (h1 : Frame1 s1 s2) (h2 : Frame1 s2 s3) : Frame1 s1 s3 :=
  ⟨h2.1.trans h1.1, h2.2.1.trans h1.2.1, h2.2.2.1.trans h1.2.2.1,
    fun h => h2.2.2.2 (h1.2.2.2 h)⟩

theorem Frame1.fail {s s' : State} (h : Frame1 s s') : Frame1 s s'.fail :=
  ⟨h.1, h.2.1, h.2.2.1, fun _ => rfl⟩


def Birth1 (P : StreamParams) (d : ℕ) (s s' : State) : Prop :=
  Frame1 s s' ∧ (s'.failed = false → s'.learners.length = s.learners.length + 1 ∧
    s'.banks.length = s.banks.length + (if d + 2 ≤ P.H then 1 else 0))

theorem birthDepth_birth (P : StreamParams) (d0 d : ℕ) (s : State) :
    Always (birthDepth P d0 d s) (Birth1 P d s) := by
  unfold birthDepth
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (Q := fun s2 => Frame1 s s2 ∧ s2.learners.length = s.learners.length ∧
      s2.banks.length = s.banks.length + (if d + 2 ≤ P.H then 1 else 0)) (fun s2 hs2 => ?_) ?_
  · obtain ⟨hf, hl, hb⟩ := hs2
    split_ifs
    · exact always_pure ⟨Frame1.trans hf ⟨rfl, rfl, rfl, id⟩, fun _ => ⟨by simp [hl], hb⟩⟩
    · split
      · exact always_pure ⟨hf.fail, fun h => (not_fail_false h).elim⟩
      · refine Always.bind_all (fun res => ?_) _
        split
        · exact always_pure ⟨(Frame1.trans hf ⟨rfl, rfl, rfl, id⟩).fail,
            fun h => (not_fail_false h).elim⟩
        · split_ifs
          · exact always_pure ⟨Frame1.trans hf ⟨rfl, rfl, rfl, id⟩,
              fun _ => ⟨by simp [hl], by simp [hb]⟩⟩
          · exact always_pure ⟨(Frame1.trans hf ⟨rfl, rfl, rfl, id⟩).fail,
              fun h => (not_fail_false h).elim⟩
  · split_ifs with hd
    · exact Always.bind_all (fun B => always_pure ⟨⟨rfl, rfl, rfl, id⟩, by simp, by simp⟩) _
    · exact always_pure ⟨⟨rfl, rfl, rfl, id⟩, rfl, by simp⟩


theorem birthLoop_shape (P : StreamParams) (d0 : ℕ) :
    ∀ (k d : ℕ) (s : State), d + k = P.H → 1 ≤ k → s.learners.length = d →
      s.banks.length = d + 1 →
      Always (birthLoop P d0 (List.range' d k) s)
        (fun s' => Frame1 s s' ∧ (s'.failed = false → s'.learners.length = P.H ∧
          s'.banks.length = P.H))
  | 0, _, _, _, hk, _, _ => absurd hk (by norm_num)
  | k + 1, d, s, hdk, _, hl, hb => by
    simp only [List.range'_succ, birthLoop, bp_bind_eq]
    split_ifs with hs
    · exact always_pure ⟨Frame1.refl s, fun h => by rw [hs] at h; exact Bool.noConfusion h⟩
    · refine Always.bind (fun s' hs' => ?_) (birthDepth_birth P d0 d s)
      rcases Nat.eq_zero_or_pos k with hk0 | hk0
      · subst hk0
        simp only [List.range'_zero, birthLoop]
        refine always_pure ⟨hs'.1, fun h => ?_⟩
        obtain ⟨h1, h2⟩ := hs'.2 h
        have hd : ¬ (d + 2 ≤ P.H) := by omega
        rw [if_neg hd] at h2
        exact ⟨by omega, by omega⟩
      · by_cases hf : s'.failed = true
        · -- the loop stops at once
          have : birthLoop P d0 (List.range' (d + 1) k) s' = BitProg.pure s' := by
            cases k with
            | zero => omega
            | succ k => simp [List.range'_succ, birthLoop, hf]
          rw [this]
          exact always_pure ⟨hs'.1, fun h => by rw [hf] at h; exact Bool.noConfusion h⟩
        · obtain ⟨h1, h2⟩ := hs'.2 (Bool.eq_false_iff.mpr hf)
          have hd : d + 2 ≤ P.H := by omega
          rw [if_pos hd] at h2
          exact Always.mono (fun s'' h => ⟨Frame1.trans hs'.1 h.1, h.2⟩)
            (birthLoop_shape P d0 k (d + 1) s' (by omega) hk0 (by omega) (by omega))

theorem birthLoop_frame1 (P : StreamParams) (d0 : ℕ) :
    ∀ (ds : List ℕ) (s : State), Always (birthLoop P d0 ds s) (Frame1 s)
  | [], s => always_pure (Frame1.refl s)
  | d :: ds, s => by
    simp only [birthLoop, bp_bind_eq]
    split_ifs
    · exact always_pure (Frame1.refl s)
    · exact Always.bind (fun s' hs' => Always.mono (fun s'' h => Frame1.trans hs'.1 h)
        (birthLoop_frame1 P d0 ds s')) (birthDepth_birth P d0 d s)

theorem step1_frame (P : StreamParams) (s : State) : Always (step1 P s) (Frame1 s) := by
  unfold step1
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (fun s2 hs2 => always_pure ?_) (birthLoop_frame1 P _ _ _)
  exact Frame1.trans (Frame1.trans ⟨rfl, rfl, rfl, id⟩ hs2) ⟨rfl, rfl, rfl, id⟩

theorem step1_shape (P : StreamParams) (s : State)
    (hl : firstBorn P.H (s.t + 1) ≤ s.learners.length)
    (hb : firstBorn P.H (s.t + 1) + 1 ≤ s.banks.length) :
    Always (step1 P s) (fun s1 => Frame1 s s1 ∧ (s1.failed = false →
      s1.learners.length = P.H ∧ s1.banks.length = P.H)) := by
  have hd0 := firstBorn_lt P.H (s.t + 1) (H_pos P)
  unfold step1
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (fun s2 hs2 => always_pure
    ⟨Frame1.trans (Frame1.trans ⟨rfl, rfl, rfl, id⟩ hs2.1) ⟨rfl, rfl, rfl, id⟩, fun h => hs2.2 h⟩)
    (birthLoop_shape P _ (P.H - firstBorn P.H (s.t + 1)) (firstBorn P.H (s.t + 1)) _ (by omega)
      (by omega) (by simp only [List.length_take]; omega) (by simp only [List.length_take]; omega))

/-! ## Step 2 -/

theorem step2_t (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) : (step2 P i Δ s).1.t = s.t := by
  unfold step2; dsimp only; split_ifs <;> rfl

theorem step2_fpSeed (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).1.fpSeed = s.fpSeed := by
  unfold step2; dsimp only; split_ifs <;> rfl

theorem step2_fpVal (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).1.fpVal = fpUpdate P s.fpSeed s.fpVal (i + 1) Δ := by
  unfold step2; dsimp only; split_ifs <;> rfl

theorem step2_snd (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).2 = (fpUpdate P s.fpSeed s.fpVal (i + 1) Δ == 0) := by
  unfold step2; dsimp only; split_ifs <;> rfl

theorem step2_failed (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) (h : s.failed = true) :
    (step2 P i Δ s).1.failed = true := by
  unfold step2; dsimp only; split_ifs
  · exact h
  · rfl

theorem step2_lengths (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).1.learners.length = s.learners.length ∧
      (step2 P i Δ s).1.banks.length = s.banks.length := by
  unfold step2; dsimp only; split_ifs <;> simp [State.fail]

theorem step2_leaf (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State)
    (h : (step2 P i Δ s).1.failed = false) :
    gridVal P.eHleaf (step2 P i Δ s).1.leaf = (Δ : ℚ) ^ 2 := by
  revert h
  unfold step2
  dsimp only
  split_ifs
  · intro _
    exact gridVal_roundMant_exact _ _ (Δ ^ 2 * 2 ^ P.eHleaf) (by push_cast; ring)
  · intro h; exact (not_fail_false h).elim

/-! ## One round -/

theorem finishRound_snd (s : State) (F : ℚ) :
    (finishRound s F).2 = if s.failed then 0 else F := rfl

theorem finishRound_fst_failed (s : State) (F : ℚ) : (finishRound s F).1.failed = s.failed := rfl

theorem roundStep_out (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    Always (roundStep P s i Δ) (fun r => r.1.t = s.t + 1 ∧ r.1.fpSeed = s.fpSeed ∧
      (s.failed = true → r.1.failed = true) ∧ (r.1.failed = true → r.2 = 0) ∧
      0 ≤ r.2 ∧ r.2 ≤ (P.Amax : ℚ)) := by
  have hA : (0 : ℚ) ≤ P.Amax := by positivity
  have fin0 : ∀ s' : State, s'.t = s.t → s'.fpSeed = s.fpSeed →
      (s.failed = true → s'.failed = true) → (fun r : State × ℚ => r.1.t = s.t + 1 ∧
      r.1.fpSeed = s.fpSeed ∧ (s.failed = true → r.1.failed = true) ∧
      (r.1.failed = true → r.2 = 0) ∧ 0 ≤ r.2 ∧ r.2 ≤ (P.Amax : ℚ)) (finishRound s' 0) := by
    intro s' ht hs hf
    have h2 : (finishRound s' 0).2 = 0 := by rw [finishRound_snd]; split <;> rfl
    exact ⟨by show s'.t + 1 = s.t + 1; rw [ht], hs, hf, fun _ => h2, by rw [h2], by rw [h2]; exact hA⟩
  unfold roundStep
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hf
  · exact always_pure (fin0 s rfl rfl id)
  · refine Always.bind (fun s1 hs1 => ?_) (step1_frame P s)
    have h2t := step2_t P i Δ s1
    have h2s := step2_fpSeed P i Δ s1
    have h2f := step2_failed P i Δ s1
    split_ifs with h1 h2 h3
    · exact always_pure (fin0 s1 hs1.1 hs1.2.1 hs1.2.2.2)
    · exact always_pure (fin0 _ (h2t.trans hs1.1) (h2s.trans hs1.2.1)
        (fun h => h2f (hs1.2.2.2 h)))
    · have h3' := step3_pres P (step2 P i Δ s1).1
      exact always_pure (fin0 _ (h3'.1.trans (h2t.trans hs1.1)) (h3'.2.1.trans (h2s.trans hs1.2.1))
        (fun h => h3'.2.2.2.1 (h2f (hs1.2.2.2 h))))
    · refine Always.bind (fun r4 hr4 => ?_) (step4_out P _)
      have h3' := step3_pres P (step2 P i Δ s1).1
      have ht : r4.1.t = s.t := hr4.1.1.trans (h3'.1.trans (h2t.trans hs1.1))
      have hs : r4.1.fpSeed = s.fpSeed :=
        hr4.1.2.1.trans (h3'.2.1.trans (h2s.trans hs1.2.1))
      have hfm : s.failed = true → r4.1.failed = true :=
        fun h => hr4.1.2.2.2.1 (h3'.2.2.2.1 (h2f (hs1.2.2.2 h)))
      refine always_pure ⟨by show r4.1.t + 1 = s.t + 1; rw [ht], hs, hfm, fun h => ?_, ?_⟩
      · have h' : r4.1.failed = true := h
        rw [finishRound_snd, if_pos h']
      · by_cases hr : r4.1.failed = true
        · rw [finishRound_snd, if_pos hr]; exact ⟨le_rfl, hA⟩
        · rw [finishRound_snd, if_neg hr]
          exact hr4.2 (Bool.eq_false_iff.mpr hr)


/-! ## The terminal accumulator through Step 3 -/

theorem eHg_two_le_eHleaf (P : StreamParams) : 2 * P.eHg ≤ P.eHleaf := by
  unfold StreamParams.eHleaf; omega

theorem guardOf_step3Depth (P : StreamParams) (tr : ℕ) (s : State) (d d' : ℕ) :
    guardOf P (step3Depth P tr s d) d' = guardOf P s d' := by
  unfold step3Depth
  cases hLd : s.learners[d]? with
  | none => rfl
  | some Ld =>
    dsimp only
    split_ifs
    · rfl
    · unfold guardOf
      by_cases hdd : d' = d
      · subst hdd
        have hlt : d' < s.learners.length := (List.getElem?_eq_some_iff.mp hLd).1
        rw [getElem?_setAt_self _ _ _ hlt, hLd]
      · rw [getElem?_setAt_ne _ _ _ _ hdd]
    · rfl

theorem step3Depth_leaf (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ)
    (h : (step3Depth P tr s d).failed = false) :
    gridVal P.eHleaf (step3Depth P tr s d).leaf =
      gridVal P.eHleaf s.leaf + gridVal P.eHg (guardOf P s d) ^ 2 := by
  have hle := eHg_two_le_eHleaf P
  revert h
  unfold step3Depth guardOf
  cases hLd : s.learners[d]? with
  | none => intro h; exact (not_fail_false h).elim
  | some Ld =>
    dsimp only
    split_ifs with hδ hr
    · intro _; rw [hδ]; simp [gridVal]
    · intro _
      refine gridVal_roundMant_exact _ _
        (s.leaf + (guardMant Ld.tag (guardAlpha P) (↑(P.eU d) - ↑Ld.epoch)) ^ 2 *
          2 ^ (P.eHleaf - 2 * P.eHg)) ?_
      unfold gridVal
      have h2 : (2 : ℚ) ^ P.eHleaf = 2 ^ (P.eHleaf - 2 * P.eHg) * (2 ^ P.eHg) ^ 2 := by
        rw [← pow_mul, ← pow_add]; congr 1; omega
      rw [h2]; push_cast; field_simp
    · intro h; exact (not_fail_false h).elim

theorem step3Loop_leaf (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State), (step3Loop P tr ds s).failed = false →
      gridVal P.eHleaf (step3Loop P tr ds s).leaf =
        gridVal P.eHleaf s.leaf + (ds.map (fun d => gridVal P.eHg (guardOf P s d) ^ 2)).sum
  | [], s, _ => by simp [step3Loop]
  | d :: ds, s, h => by
    simp only [step3Loop] at h ⊢
    split_ifs with hs
    · rw [if_pos hs] at h; rw [hs] at h; exact Bool.noConfusion h
    · rw [if_neg hs] at h
      have hpres := step3Loop_pres P tr ds (step3Depth P tr s d)
      have h1 : (step3Depth P tr s d).failed = false := by
        cases hc : (step3Depth P tr s d).failed
        · rfl
        · rw [hpres.2.2.2.1 hc] at h; exact Bool.noConfusion h
      rw [step3Loop_leaf P tr ds _ h, step3Depth_leaf P tr s d h1]
      have hg : ∀ d', guardOf P (step3Depth P tr s d) d' = guardOf P s d' :=
        guardOf_step3Depth P tr s d
      simp only [hg, List.map_cons, List.sum_cons]
      ring

end F2e2e.C.Alg
