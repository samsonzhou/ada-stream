import Mathlib
import F2e2e.C.Alg.State
import F2e2e.Lib.Discrete.Sampler
import F2e2e.Lib.Hash.Defs

/-!
# The Streaming Regularized Norm Bank (Algorithm 3, `R:alg:regularized-norm-bank`)

Source: `parts/partIII.tex` Definition `R:def:regularized-norm-bank` (L164–193) and Algorithm
`R:alg:regularized-norm-bank` (L201–223); counters' saturation from Definition `R:def:total-behavior`
(L445–464).

* Rows (L207): a seed is `2s` uniformly random elements of `𝔽_{2^w} = 𝔽_2[x]/(irrPoly w)`,
  `w = ⌈log₂(D_*+1)⌉`, i.e. `2sw` fresh bits; the sign of coordinate `i ∈ [1, D_*]` is
  `b_i = (-1)^{lsb(Σ_k ζ_k α_i^k)}` with `α_i` the field element with binary code `i` (distinct and
  nonzero since `D_* < 2^w`), `lsb` = bit `0` (`F2e2e.Hash.signBit`).
* Counters (L208): `X(b)`, `Y(b)` exclude the regularizer coordinate; every row update is rounded to
  `h_b` and saturated to `[-Z_max, Z_max]`; the regularized evaluation adds `b_{D_*} σ` unscaled:
  `Ẑ(b) = X(b) + b_{D_*}σ` (`PRIMARY`) or `X(b) − Y(b) + b_{D_*}σ` (`DIFF`) (L184–191).
* `ValidateInterval(S, θ)` (L210–213) and `ReleaseNumerical(mode)` (L215–219).
* A new bank (L204–207): fresh seeds for the ADA blocks `S_0, …, S_p` and the `R_max` reserved coarse
  groups of `32g` rows, all counters zero, a fresh ADA module.
-/

namespace F2e2e.C.Alg

open F2e2e.B

open F2e2e.Discrete

/-! ## Signs of a row -/

/-- The irreducible polynomial of degree `w` defining `𝔽_{2^w}` (least degree-`w` pattern passing the
trial-division test, partIII.tex L1249). -/
def irrW (P : StreamParams) : ℕ := Hash.irrPoly P.w

/-- The sign `b_i ∈ {±1}` of the row at coordinate `i` (coordinates `1, …, D_*`; physical coordinates
`1..n`, guard coordinates `g(d,t)`, the regularizer coordinate `D_*`), Lemma `R:lem:2s-moment-bound`
eq. `R:eq:rademacher-seed-poly` (partIII.tex L13). -/
def rowSign (P : StreamParams) (r : Row) (i : ℕ) : ℤ :=
  if Hash.signBit P.w (irrW P) r.seed i then -1 else 1

/-! ## Counter maintenance (every update rounded to `h_b`, then saturated) -/

/-- Step 2 (partIII.tex L482): add `Δ b_i` once to the primary and the secondary counter (exact on
`h_b`, since `Δ ∈ ℤ`). -/
def Row.addPhys (P : StreamParams) (i : ℕ) (Δ : ℤ) (r : Row) : Row :=
  let v : ℤ := Δ * rowSign P r i * 2 ^ P.eHb
  { r with X := sat (zSat P) (r.X + v), Y := sat (zSat P) (r.Y + v) }

/-- The mantissa on `h_b` of `round_{h_b}(δ b_g)` for the guard `δ = δInt h_g` at coordinate `g`. -/
def guardIncr (P : StreamParams) (r : Row) (g : ℕ) (δInt : ℤ) : ℤ :=
  roundMant P.eHb (gridVal P.eHg (δInt * rowSign P r g))

/-- Step 3 (partIII.tex L491): add the guard `δ e_g` to the secondary counter only. -/
def Row.addGuardY (P : StreamParams) (g : ℕ) (δInt : ℤ) (r : Row) : Row :=
  { r with Y := sat (zSat P) (r.Y + guardIncr P r g δInt) }

/-- Step 3 (partIII.tex L491): add the guard `δ e_g` to both counters. -/
def Row.addGuardXY (P : StreamParams) (g : ℕ) (δInt : ℤ) (r : Row) : Row :=
  { r with X := sat (zSat P) (r.X + guardIncr P r g δInt),
           Y := sat (zSat P) (r.Y + guardIncr P r g δInt) }

/-- Step 4 (partIII.tex L505): multiply the secondary counter by `c = cInt h_step`, rounding to
`h_b`. -/
def Row.scaleY (P : StreamParams) (cInt : ℤ) (r : Row) : Row :=
  { r with Y := sat (zSat P) (scaleMant P.eHstep cInt r.Y) }

/-- Step 4 (partIII.tex L506): multiply both counters by `c = cInt h_step`, rounding to `h_b`. -/
def Row.scaleXY (P : StreamParams) (cInt : ℤ) (r : Row) : Row :=
  { r with X := sat (zSat P) (scaleMant P.eHstep cInt r.X),
           Y := sat (zSat P) (scaleMant P.eHstep cInt r.Y) }

/-- Step 1 (partIII.tex L475): reset the client-secondary counter to zero (the primary is
retained). -/
def Row.resetY (r : Row) : Row := { r with Y := 0 }

/-- Apply a row operation to every row of the bank (ADA rows and the remaining coarse rows; L221:
"maintaining its counters is allowed"). -/
def Bank.mapRows (f : Row → Row) (B : Bank) : Bank :=
  { B with ada := B.ada.map (fun blk => blk.map f),
           coarse := B.coarse.map (fun grp => grp.map (fun sub => sub.map f)) }

/-! ## Evaluation -/

/-- The regularized counter `Ẑ(b)` (partIII.tex L208; eqs. `R:eq:unscaled-regularizer-counter`,
`R:eq:difference-counter-def`, L186, L190): `X(b) + b_{D_*}σ` (`PRIMARY`) or
`X(b) − Y(b) + b_{D_*}σ` (`DIFF`), exactly. -/
def regZ (P : StreamParams) (mode : Mode) (r : Row) : ℚ :=
  let cnt : ℤ := match mode with
    | Mode.primary => r.X
    | Mode.diff => r.X - r.Y
  gridVal P.eHb cnt + (rowSign P r P.Dstar : ℚ) * P.sigma

/-- The rowwise query value as a grid index: `f̂(b)/h_A = round_{h_A}(min{Ẑ(b)²/(Lc), 1}) / h_A`,
an integer in `[0, 2^{qA}]` (partIII.tex L212, eq. `R:eq:unscaled-regularizer-counter`). -/
def queryIdx (qA L : ℕ) (c z : ℚ) : ℕ :=
  let ratio : ℚ := z ^ 2 / ((L : ℚ) * c)
  if 1 ≤ ratio then 2 ^ qA else (roundMant qA ratio).toNat

/-- The query values handed to the ADA module: for every block `S_j` and every row of it, the grid
index of `f̂(b)` in the given mode at the scale `c`. -/
def adaVals (P : StreamParams) (mode : Mode) (c : ℚ) (B : Bank) : List (List ℕ) :=
  B.ada.map (fun blk => blk.map (fun r => queryIdx (bankAda P).qA P.L c (regZ P mode r)))

/-- `ValidateInterval(v, S, θ)` (partIII.tex L210–213): `c = S + ω`, rowwise queries `f̂` in
`PRIMARY` mode, the ADA interval interface on `[(1−θ)/L, (1+θ)/L]`; returns the protected
certificate and the updated bank. (Section 5 validates primary vectors only, L498.) -/
def Bank.validate (P : StreamParams) (B : Bank) (S θ : ℚ) : BitProg (AdaCert × Bank) := do
  let c : ℚ := S + P.omega
  let res ← adaInterval (bankAda P) B.adaSt (adaVals P Mode.primary c B)
    ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ))
  pure (res.1, { B with adaSt := res.2 })

/-- The mean of the `32` squared regularized counters of one coarse subgroup (partIII.tex L217;
Lemma `R:lem:coarse-ams`, eq. `R:eq:coarse-ams-estimator`). -/
def subgroupMean (P : StreamParams) (mode : Mode) (sub : List Row) : ℚ :=
  (sub.map (fun r => regZ P mode r ^ 2)).sum / 32

/-- `ReleaseNumerical(mode)` (partIII.tex L215–219): enforce the numerical cap and consume the next
reserved coarse group; `c_raw` = lower median of its `g` subgroup means; `c = max(c_raw, ω/2)`;
query the ADA numerical interface on the corresponding `f̂`, receiving `μ̂`; return
`N = max(0, L c μ̂ − ω)`. Returns `none` if the cap is exhausted (no coarse group left) or the ADA
aborts (the caller then enters the failure state). -/
def Bank.release (P : StreamParams) (B : Bank) (mode : Mode) : BitProg (Option ℚ × Bank) :=
  match B.coarse with
  | [] => pure (none, B)
  | grp :: rest => do
    let c : ℚ := max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)
    let res ← adaNumerical (bankAda P) B.adaSt (adaVals P mode c B)
    let B' : Bank := { B with coarse := rest, adaSt := res.2 }
    match res.1 with
    | AdaNum.val μ => pure (some (max 0 ((P.L : ℚ) * c * μ - P.omega)), B')
    | AdaNum.abort => pure (none, B')

/-! ## Allocation of a new bank -/

/-- `k` independent draws of the bit program `p` (in order). -/
def sampleList {α : Type} (p : BitProg α) : ℕ → BitProg (List α)
  | 0 => pure []
  | k + 1 => do
    let a ← p
    let l ← sampleList p k
    pure (a :: l)

/-- A fresh row seed: `2s` uniform elements of `𝔽_{2^w}`, i.e. `2sw` fresh bits (partIII.tex L207). -/
def sampleSeed (P : StreamParams) : BitProg (List ℕ) := sampleList (uniformBits P.w) (2 * P.s)

/-- A fresh row with zero counters. -/
def newRow (P : StreamParams) : BitProg Row := do
  let z ← sampleSeed P
  pure ⟨z, 0, 0⟩

/-- Fresh rows for the ADA blocks of the given sizes. -/
def sampleBlocks (P : StreamParams) : List ℕ → BitProg (List (List Row))
  | [] => pure []
  | nj :: rest => do
    let blk ← sampleList (newRow P) nj
    let l ← sampleBlocks P rest
    pure (blk :: l)

/-- A fresh bank (partIII.tex L204–207, L476): the ADA blocks `S_0, …, S_p` (sizes `n_j` of the bank
ADA instance), `R_max` reserved coarse groups of `g` subgroups of `32` rows, all counters zero, and a
fresh ADA module. -/
def newBank (P : StreamParams) : BitProg Bank := do
  let ada ← sampleBlocks P (bankAda P).blockSizes
  let coarse ← sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax
  let st ← adaInit (bankAda P)
  pure ⟨ada, coarse, st⟩

end F2e2e.C.Alg
