import Mathlib
import F2e2e.C.Alg.State
import F2e2e.Lib.Discrete.Sampler

/-!
# The homomorphic zero fingerprint (Algorithm 1, `R:alg:zero-fingerprint`)

Source: `parts/partII.tex` Algorithm `R:alg:zero-fingerprint` (L216–231) and Lemma
`R:lem:zero-fingerprint` (L233–286).

* Initialization (L219): the least prime `q ≥ ⌈10 n m (U+1)/β₀⌉³` (`F2e2e.StreamParams.q`; since
  `β₀ = 2^{-betaExp}` the bound is the integer `(10 n m (U+1) 2^{betaExp})³ = P.Mq`), the secret seed
  `r_fp ∈ 𝔽_q` by capped uniform-integer rejection sampling with `⌈log₂(1000/β₀)⌉ = betaExp + 10`
  trials (`P.seedTrials`) and fallback seed zero, and `F_zero ← 0`.
* Update (L221): `F_zero ← (F_zero + (Δ_t mod q) · r_fp^{i_t}) mod q` for the 1-based coordinate
  `i_t ∈ [n]`.
-/

namespace F2e2e.C.Alg

open F2e2e.Discrete

/-- The fingerprint seed (partII.tex L219): up to `betaExp + 10` trials of `⌈log₂ q⌉` fresh bits,
the first value `< q`, or the fallback seed `0` if every trial fails. -/
def fpSeedProg (P : StreamParams) : BitProg ℕ := do
  let o ← rejectUniform P.q (Nat.clog 2 P.q) P.seedTrials
  pure (o.getD 0)

/-- The fingerprint update (partII.tex L221) for the 1-based coordinate `i` and increment `Δ`:
`(F_zero + (Δ mod q) · (r_fp^i mod q)) mod q`. (The DSL computes `r_fp^i mod q` by repeated squaring;
the value is the same.) -/
def fpUpdate (P : StreamParams) (seed val i : ℕ) (Δ : ℤ) : ℕ :=
  (((val : ℤ) + Δ % (P.q : ℤ) * ((seed ^ i % P.q : ℕ) : ℤ)) % (P.q : ℤ)).toNat

end F2e2e.C.Alg
