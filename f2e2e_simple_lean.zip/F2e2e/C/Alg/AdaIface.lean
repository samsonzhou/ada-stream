import Mathlib
import F2e2e.Lib.Discrete.BitProg
import F2e2e.B.ArchCore
import F2e2e.C.Params

/-!
# The ADA component of the Theorem C algorithm

The streaming algorithm of Theorem C runs one copy of the Capped-Simplex Validation ADA mechanism
(Algorithm `R:alg:sec3_validation_ada`, `parts/partII.tex` L752–777) inside every Regularized Norm
Bank (Algorithm `R:alg:regularized-norm-bank`, `parts/partIII.tex` L205: "the ADA module of
Theorem `R:thm:validation_ada` with requested accuracy `a_num`, failure probability `β_B/2`, and caps
`M = m`, `J = J_max`, `R = R_max`").

The mechanism is B-ARCH's computable core state machine (`F2e2e/B/ArchParams.lean`,
`F2e2e/B/ArchCore.lean`, namespace `F2e2e.B`), on integer grid indices, from which B's Spec-level
`VMechanism` is derived by rounding the real views to the grid `h_A` (`partII.tex` L750). The Theorem C
algorithm uses (with `open F2e2e.B`):
* `AdaParams` (fields `qA`, `h_A = 2^{-qA}`, and `blockSizes = [n_0, …, n_p]`), computed from naturals
  by `adaParams eA eXi M J R` (`a = 2^{-eA}`, `ξ_A = 2^{-eXi}`);
* `AdaState`, `adaInit`, `adaInterval`, `adaNumerical`, the certificates `AdaCert` and the numerical
  outputs `AdaNum`; query values are passed as grid indices `vals[j][i] = f̂(X_{j,i}) / h_A ∈ [0, 2^{qA}]`,
  block by block (blocks `S_0, …, S_p`); interval endpoints are clipped to `[-1, 2]` and rounded to
  `h_A` inside the core; the caps `M`, `R` are enforced inside the core (over-cap or halted ⇒ `abort`,
  no fresh bits);
* the uniform worst-case bit bounds `adaInitBits`, `adaCallBits` (`adaInit_depth_le`,
  `adaInterval_depth_le`, `adaNumerical_depth_le`).
-/

namespace F2e2e.C.Alg

open F2e2e.B

/-- The bank ADA instance of Algorithm `R:alg:regularized-norm-bank` (partIII.tex L205): requested
accuracy `a_num` (dyadic `a = 2^{-eBankA}`), failure probability `β_B/2` (dyadic
`ξ_A = 2^{-eBankXi}`), caps `M = m`, `J = J_max`, `R = R_max`. -/
def bankAda (P : StreamParams) : AdaParams :=
  adaParams P.eBankA P.eBankXi P.bankM P.bankJ P.bankR

end F2e2e.C.Alg
