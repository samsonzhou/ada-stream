import Mathlib
import F2e2e.C.Alg.Arith
import F2e2e.C.Alg.AdaIface

/-!
# The memory of the Theorem C algorithm

All memory kept between updates (`parts/partII.tex` L30, L43: "all `2s`-wise independent sign seeds,
linear sketch row counters, capped-simplex ADA learning states, cumulative scale tags, residual
energy caches, homomorphic zero-fingerprint registers, …"), as exact integers:

* `Row`: one sign row of a Norm Bank (Algorithm `R:alg:regularized-norm-bank`, partIII.tex
  L204–208): its seed `ζ ∈ 𝔽_{2^w}^{2s}` (`2s` field elements, constant coefficient first, each a
  `w`-bit pattern) and its primary / active-client secondary counters `X(b), Y(b)` (mantissas on the
  grid `h_b`; they exclude the regularizer coordinate, L208).
* `Bank`: the ADA sample blocks `S_0, …, S_p` (rows), the not yet consumed reserved coarse groups
  (each `g` subgroups of `32` rows, L206, L216), and the bank's ADA state.
* `Learner`: the stored registers of a live nonleaf learner `𝓛_d` (Definition
  `R:def:binary-tree-architecture`, partIII.tex L440): tag `Ĉ_d` (mantissa on `h_C`), cache `P_d`
  (mantissa on `h_P`), epoch `k_d`, intra-epoch counter `j_epoch` and lifetime counter `J_used`
  (L474, L509). The analytical vectors `a_d, q_d, u_d, r_d, y_d` and `C_d` are never stored (L437,
  L442).
* `State`: round counter, absorbing failure flag (Def. `R:def:total-behavior`, L454–457), the
  zero-fingerprint registers (Algorithm `R:alg:zero-fingerprint`, partII.tex L219–221), the live
  learners `𝓛_0, …, 𝓛_{H-1}` (index `d`), the live banks `𝓑_{-1}, 𝓑_0, …, 𝓑_{H-2}` (bank `𝓑_e` at
  index `e + 1`, so the incoming bank `𝓑_{d-1}` of depth `d` is at index `d`), and the exact
  terminal accumulator (mantissa on `h_leaf`, partIII.tex L442, L459–463).

Public parameters (`F2e2e.StreamParams` and the derived values of `F2e2e/C/Params*.lean`) are not
part of the state: they are recomputed from the parameters handed to every program run.
-/

namespace F2e2e.C.Alg

open F2e2e.B

/-- One sign row of a Norm Bank. -/
structure Row where
  /-- The seed `ζ = (ζ_0, …, ζ_{2s-1})`, constant coefficient first; each `ζ_k < 2^w`. -/
  seed : List ℕ
  /-- The primary counter `X(b)` (mantissa on the grid `h_b`). -/
  X : ℤ
  /-- The active-client secondary counter `Y(b)` (mantissa on the grid `h_b`). -/
  Y : ℤ

/-- Evaluation modes of a bank (partIII.tex L208): `PRIMARY` uses `X(b)`, residual `DIFF` uses
`X(b) − Y(b)`. -/
inductive Mode where
  | primary : Mode
  | diff : Mode
  deriving DecidableEq

/-- A Regularized Norm Bank (Algorithm `R:alg:regularized-norm-bank`). -/
structure Bank where
  /-- The ADA sample blocks `S_0, …, S_p` (sizes `n_0, …, n_p`). -/
  ada : List (List Row)
  /-- The reserved coarse groups not yet consumed, next group first; each group is a list of `g`
  subgroups of `32` rows. -/
  coarse : List (List (List Row))
  /-- The state of the bank's ADA module. -/
  adaSt : AdaState

/-- The stored registers of a live nonleaf learner `𝓛_d`. -/
structure Learner where
  /-- The strict-ancestor cumulative multiplier tag `Ĉ_d` (mantissa on `h_C`). -/
  tag : ℤ
  /-- The residual energy cache `P_d` (mantissa on `h_P`). -/
  cache : ℤ
  /-- The envelope epoch index `k_d ∈ {0, …, K_epoch}`. -/
  epoch : ℕ
  /-- The intra-epoch correction counter `j_epoch`. -/
  jEpoch : ℕ
  /-- The lifetime correction counter `J_used`. -/
  jUsed : ℕ

/-- The entire memory of the algorithm between updates. -/
structure State where
  /-- The number of rounds processed (the next round is round `t + 1` of the paper). -/
  t : ℕ
  /-- The absorbing failure flag (Def. `R:def:total-behavior`). -/
  failed : Bool
  /-- The secret fingerprint seed `r_fp ∈ 𝔽_q`. -/
  fpSeed : ℕ
  /-- The fingerprint register `F_zero ∈ 𝔽_q`. -/
  fpVal : ℕ
  /-- The live learners `𝓛_0, …, 𝓛_{H-1}` (index `d`). -/
  learners : List Learner
  /-- The live banks `𝓑_{-1}, …, 𝓑_{H-2}` (bank `𝓑_e` at index `e + 1`). -/
  banks : List Bank
  /-- The terminal accumulator (mantissa on `h_leaf`). -/
  leaf : ℤ

/-- Enter the absorbing failure state (Def. `R:def:total-behavior`, partIII.tex L454–457). -/
def State.fail (s : State) : State := { s with failed := true }

/-- The range `[0, A_max]` of caches, candidates, returned geometric estimates and the terminal
accumulator (Def. `R:def:total-behavior`, partIII.tex L453; checked before storing). -/
def inRangeA (P : StreamParams) (x : ℚ) : Bool := decide (0 ≤ x ∧ x ≤ (P.Amax : ℚ))

/-- The range `[0, C_max]` of stored tags (partIII.tex L452). -/
def inRangeC (P : StreamParams) (x : ℚ) : Bool := decide (0 ≤ x ∧ x ≤ (P.Cmax : ℚ))

/-- A learner's stored tag and cache are within their ranges. -/
def Learner.inRange (P : StreamParams) (L : Learner) : Bool :=
  inRangeC P (gridVal P.eHC L.tag) && inRangeA P (gridVal P.eHP L.cache)

/-- The saturation bound `Z_max` as a mantissa on the grid `h_b`. -/
def zSat (P : StreamParams) : ℤ := (P.Zmax : ℤ) * 2 ^ P.eHb

end F2e2e.C.Alg
