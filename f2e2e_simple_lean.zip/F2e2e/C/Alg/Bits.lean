import Mathlib
import F2e2e.C.Alg.Round

/-!
# Worst-case number of fresh bits read by the Theorem C algorithm

Every randomness source of the algorithm reads a bounded number of fresh bits on every path
(`BitProg.depth`), uniformly over all states and inputs:
* a fresh row seed: `2s` field elements of `w` bits (`rowBits`);
* a fresh bank: its `n_0 + ⋯ + n_p + R_max · 32g` rows and the ADA initialization (`newBankBits`);
* one ADA interval or numerical call (`adaCallBits`, B's uniform bound);
* the fingerprint seed: `betaExp + 10` trials of `⌈log₂ q⌉` bits (`fpSeedBits`).

Per round: Step 1 allocates at most `H` banks (one per reborn depth) and makes at most one numerical
release per reborn depth; Step 4 makes, per depth, one validation and at most two numerical releases.
Hence `depth (algStep P s i Δ) ≤ stepBits P` and `depth (algInit P) ≤ initBits P`, and a run on any tape
of length `≥ tapeBits P = max (initBits P) (stepBits P)` never fails (`BitProg.run_isSome`).
-/

namespace F2e2e.C.Alg

open F2e2e.B

open F2e2e.Discrete

/-! ## Bit budgets -/

/-- Fresh bits of one row seed: `2s` elements of `𝔽_{2^w}`. -/
def rowBits (P : StreamParams) : ℕ := 2 * P.s * P.w

/-- The number of rows of a bank: the ADA blocks and the `R_max` coarse groups of `g · 32` rows. -/
def bankRows (P : StreamParams) : ℕ := (bankAda P).blockSizes.sum + P.Rmax * (P.gCoarse * 32)

/-- Fresh bits of a new bank. -/
def newBankBits (P : StreamParams) : ℕ := bankRows P * rowBits P + adaInitBits (bankAda P)

/-- Fresh bits of one bank call (`ValidateInterval` or `ReleaseNumerical`). -/
def callBits (P : StreamParams) : ℕ := adaCallBits (bankAda P)

/-- Fresh bits of the fingerprint seed. -/
def fpSeedBits (P : StreamParams) : ℕ := P.seedTrials * Nat.clog 2 P.q

/-- Worst-case fresh bits of the initialization. -/
def initBits (P : StreamParams) : ℕ := fpSeedBits P + newBankBits P

/-- Worst-case fresh bits of one round. -/
def stepBits (P : StreamParams) : ℕ := P.H * (newBankBits P + callBits P) + P.H * (3 * callBits P)

/-- A tape length sufficient for the initialization and for every round. -/
def tapeBits (P : StreamParams) : ℕ := max (initBits P) (stepBits P)

/-! ## `do`-notation normal forms and depth lemmas -/

@[simp] theorem bp_bind_eq {α β : Type} (p : BitProg α) (f : α → BitProg β) :
    (p >>= f) = p.bind f := rfl

@[simp] theorem bp_pure_eq {α : Type} (a : α) : (pure a : BitProg α) = BitProg.pure a := rfl

@[simp] theorem bp_depth_pure {α : Type} (a : α) : (BitProg.pure a).depth = 0 := rfl

theorem bp_depth_bind_le {α β : Type} {p : BitProg α} {f : α → BitProg β} {m n k : ℕ}
    (hp : p.depth ≤ m) (hf : ∀ a, (f a).depth ≤ n) (hk : m + n ≤ k) : (p.bind f).depth ≤ k :=
  le_trans (BitProg.depth_bind_le p f hf) (le_trans (Nat.add_le_add_right hp n) hk)

theorem bp_depth_ite_le {α : Type} {c : Prop} [Decidable c] {p q : BitProg α} {n : ℕ}
    (hp : p.depth ≤ n) (hq : q.depth ≤ n) : (if c then p else q).depth ≤ n := by
  split_ifs <;> assumption

theorem bp_depth_bind_pure_le {α β : Type} {p : BitProg α} {g : α → β} {m : ℕ}
    (hp : p.depth ≤ m) : (p.bind fun a => BitProg.pure (g a)).depth ≤ m :=
  bp_depth_bind_le (n := 0) hp (fun _ => le_of_eq (bp_depth_pure _)) (by simp)

theorem depth_sampleList {α : Type} (p : BitProg α) {n : ℕ} (hp : p.depth ≤ n) :
    ∀ k, (sampleList p k).depth ≤ k * n
  | 0 => by simp [sampleList]
  | k + 1 => by
    simp only [sampleList, bp_bind_eq, bp_pure_eq]
    refine bp_depth_bind_le (n := k * n) hp (fun a => ?_) (le_of_eq (by ring))
    exact bp_depth_bind_pure_le (depth_sampleList p hp k)

theorem depth_newRow (P : StreamParams) : (newRow P).depth ≤ rowBits P := by
  simp only [newRow, bp_bind_eq, bp_pure_eq]
  refine bp_depth_bind_pure_le (le_trans
    (depth_sampleList _ (le_of_eq (depth_uniformBits P.w)) _) (le_of_eq ?_))
  simp [rowBits]

theorem depth_sampleBlocks (P : StreamParams) :
    ∀ l : List ℕ, (sampleBlocks P l).depth ≤ l.sum * rowBits P
  | [] => by simp [sampleBlocks]
  | nj :: rest => by
    simp only [sampleBlocks, bp_bind_eq, bp_pure_eq, List.sum_cons]
    refine bp_depth_bind_le (n := rest.sum * rowBits P)
      (depth_sampleList _ (depth_newRow P) nj) (fun _ => ?_) (le_of_eq (by ring))
    exact bp_depth_bind_pure_le (depth_sampleBlocks P rest)

theorem depth_newBank (P : StreamParams) : (newBank P).depth ≤ newBankBits P := by
  simp only [newBank, bp_bind_eq, bp_pure_eq]
  refine bp_depth_bind_le (depth_sampleBlocks P _) (fun _ => ?_)
    (n := P.Rmax * (P.gCoarse * (32 * rowBits P)) + adaInitBits (bankAda P)) ?_
  · refine bp_depth_bind_le (n := adaInitBits (bankAda P))
      (depth_sampleList _ (depth_sampleList _ (depth_sampleList _ (depth_newRow P) 32) _) _)
      (fun _ => ?_) le_rfl
    exact bp_depth_bind_pure_le (adaInit_depth_le _)
  · simp only [newBankBits, bankRows]; ring_nf; exact le_rfl

theorem depth_validate (P : StreamParams) (B : Bank) (S θ : ℚ) :
    (B.validate P S θ).depth ≤ callBits P := by
  simp only [Bank.validate, bp_bind_eq, bp_pure_eq]
  exact bp_depth_bind_pure_le (adaInterval_depth_le _ _ _ _ _)

theorem depth_release (P : StreamParams) (B : Bank) (mode : Mode) :
    (B.release P mode).depth ≤ callBits P := by
  unfold Bank.release
  split
  · simp
  · simp only [bp_bind_eq, bp_pure_eq]
    refine bp_depth_bind_le (n := 0) (adaNumerical_depth_le _ _ _) (fun res => ?_)
      (by simp [callBits])
    split <;> simp

theorem depth_fpSeedProg (P : StreamParams) : (fpSeedProg P).depth ≤ fpSeedBits P := by
  simp only [fpSeedProg, bp_bind_eq, bp_pure_eq]
  exact bp_depth_bind_pure_le (le_trans (depth_rejectUniform_le _ _ _) (by simp [fpSeedBits]))

/-! ## Step 1 -/

theorem depth_birthDepth (P : StreamParams) (d0 d : ℕ) (s : State) :
    (birthDepth P d0 d s).depth ≤ newBankBits P + callBits P := by
  simp only [birthDepth, bp_bind_eq, bp_pure_eq]
  refine bp_depth_bind_le (m := newBankBits P) ?_ (fun s2 => ?_) le_rfl
  · apply bp_depth_ite_le
    · exact bp_depth_bind_pure_le (depth_newBank P)
    · simp
  · split_ifs
    · simp
    · split
      · simp
      · refine bp_depth_bind_le (n := 0) (depth_release P _ _) (fun res => ?_) (by simp)
        split
        · simp
        · split_ifs <;> simp

theorem depth_birthLoop (P : StreamParams) (d0 : ℕ) :
    ∀ (ds : List ℕ) (s : State), (birthLoop P d0 ds s).depth ≤
      ds.length * (newBankBits P + callBits P)
  | [], s => by simp [birthLoop]
  | d :: ds, s => by
    simp only [birthLoop, bp_bind_eq]
    split_ifs
    · simp
    · refine bp_depth_bind_le (depth_birthDepth P d0 d s) (fun s' => depth_birthLoop P d0 ds s')
        (le_of_eq ?_)
      simp only [List.length_cons]; ring

theorem depth_step1 (P : StreamParams) (s : State) :
    (step1 P s).depth ≤ P.H * (newBankBits P + callBits P) := by
  simp only [step1, bp_bind_eq, bp_pure_eq]
  refine bp_depth_bind_pure_le (le_trans (depth_birthLoop P _ _ _) ?_)
  simp only [List.length_range']
  exact Nat.mul_le_mul_right _ (Nat.sub_le _ _)

/-! ## Step 4 -/

theorem depth_rejectTail (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (s : State) : (rejectTail P d Ld cInt N1 s).depth ≤ callBits P := by
  unfold rejectTail
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs
  · split
    · simp
    · refine bp_depth_bind_le (n := 0) (depth_release P _ _) (fun r2 => ?_) (by simp)
      split
      · simp
      · split
        · simp
        · split_ifs <;> simp
  · simp

theorem depth_rejectDepth (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State) :
    (rejectDepth P d pos Qhat s).depth ≤ 2 * callBits P := by
  unfold rejectDepth
  split
  · simp only [bp_bind_eq, bp_pure_eq]
    split_ifs
    · simp
    · refine bp_depth_bind_le (depth_release P _ _) (fun r1 => ?_) (n := callBits P) (by omega)
      split
      · simp
      · split_ifs
        · exact depth_rejectTail P _ _ _ _ _
        · simp
  · simp

theorem depth_step4Depth (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) :
    (step4Depth P d s F).depth ≤ 3 * callBits P := by
  unfold step4Depth
  split
  · simp only [bp_bind_eq, bp_pure_eq]
    split_ifs
    · refine bp_depth_bind_le (depth_validate P _ _ _) (fun res => ?_) (n := 2 * callBits P)
        (by omega)
      split
      · simp
      · exact depth_rejectDepth P _ _ _ _
      · exact depth_rejectDepth P _ _ _ _
      · simp
    · simp
  · simp

theorem depth_step4Loop (P : StreamParams) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), (step4Loop P ds s F).depth ≤ ds.length * (3 * callBits P)
  | [], s, F => by simp [step4Loop]
  | d :: ds, s, F => by
    simp only [step4Loop, bp_bind_eq]
    split_ifs
    · simp
    · refine bp_depth_bind_le (depth_step4Depth P d s F)
        (fun r => depth_step4Loop P ds r.1 r.2) (le_of_eq ?_)
      simp only [List.length_cons]; ring

theorem depth_step4 (P : StreamParams) (s : State) : (step4 P s).depth ≤ P.H * (3 * callBits P) := by
  unfold step4
  refine le_trans (depth_step4Loop P _ _ _) (le_of_eq ?_)
  simp

/-! ## One round and initialization -/

/-- Worst-case bits of one round, uniformly over all states and updates. -/
theorem depth_algStep_le (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    (algStep P s i Δ).depth ≤ stepBits P := by
  simp only [algStep, roundStep, bp_bind_eq, bp_pure_eq]
  split_ifs
  · simp
  · refine bp_depth_bind_le (depth_step1 P s) (fun s1 => ?_) (n := P.H * (3 * callBits P))
      (by simp [stepBits])
    split_ifs
    · simp
    · simp
    · simp
    · exact bp_depth_bind_pure_le (depth_step4 P _)

/-- Worst-case bits of the initialization. -/
theorem depth_algInit_le (P : StreamParams) : (algInit P).depth ≤ initBits P := by
  simp only [algInit, initState, bp_bind_eq, bp_pure_eq]
  refine bp_depth_bind_le (depth_fpSeedProg P) (fun _ => ?_) (n := newBankBits P) le_rfl
  exact bp_depth_bind_pure_le (depth_newBank P)

/-- The initialization never fails on a tape of length `≥ initBits P` (in particular `≥ tapeBits P`). -/
theorem initRun_isSome (P : StreamParams) (tape : List Bool) (h : initBits P ≤ tape.length) :
    (initRun P tape).isSome :=
  BitProg.run_isSome _ _ (le_trans (depth_algInit_le P) h)

/-- A round never fails on a tape of length `≥ stepBits P`, from every state and for every update. -/
theorem stepRun_isSome (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) (tape : List Bool)
    (h : stepBits P ≤ tape.length) : (stepRun P s i Δ tape).isSome :=
  BitProg.run_isSome _ _ (le_trans (depth_algStep_le P s i Δ) h)

end F2e2e.C.Alg
