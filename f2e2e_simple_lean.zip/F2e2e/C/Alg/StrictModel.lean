import Mathlib
import F2e2e.C.Alg.AlgMCode
import F2e2e.C.Alg.Facts
import F2e2e.C.SpaceState

/-!
# Rules 2–3 of the strict streaming model, as properties of the built algorithm (non-headline)

`parts/partII.tex` Definition `R:def:streaming-model` (L37–45), rules 2 and 3:

* Rule 2 (L41): "The physical stream updates `(i_t, Δ_t)` are processed online in a single forward pass
  and are never altered, buffered in full, or replayed. Virtual coordinate decompositions and scalar
  multiplications induced by ancestor learner corrections are realized purely computationally through
  maintained linear sketch row counters, virtual learner states, residual energy caches, and
  finite-precision scale tags on fixed dyadic grids."
* Rule 3 (L42): "Whenever an ancestor learner updates its internal iterate at round `t`, its active
  descendant learners and their associated outgoing linear measurement banks persist across the
  correction via homogeneous scalar rescaling without ever being restarted, re-allocated, reset
  in-place (`u_d ← 0`), or asked to measure an old unknown prefix vector with a freshly sampled matrix.
  Fresh independent measurement banks (Norm Banks) are allocated exclusively at predetermined,
  data-independent physical time boundaries along a fixed binary interval tree over `[1,m]`
  (determined before round `t`'s update arrives), where the outgoing vector is identically zero, and
  expired nodes are retired before replacements are initialized."

They are stated about the controller code `roundCode` of `F2e2e/C/Alg/AlgMCode.lean`, whose
interpretation by `runO` IS the algorithm (`algStep_eq_interp`): every bank and fingerprint access of a
round is one of its primitive calls. `CallSeq p l` says that `l` is the sequence of primitive calls
(with their arguments) that `p` makes along some path of oracle responses. Every statement below
quantifies over ALL oracle-response paths of `roundCode` (resp. of its sub-procedures), i.e. over all
answers the banks and the fingerprint may give; since the round procedure `algStep` of the
mathematical algorithm `theAlg` is the interpretation of `roundCode` by `runO` (`algStep_eq_interp`,
`F2e2e/C/Alg/AlgMCode.lean`), the statements cover every execution of `theAlg`, on every path of fresh
bits and for every update. (`rejectTailCode_descendants` and `newBank_zero` are stated directly on the
interpretation, with `Always`: on every path of fresh bits.) The memory bound (a3) is stated on the
reachable states of the algorithm itself (`RoundReach`).

Proof infrastructure: `StrictAux.CallSeqR` (call sequences with the returned value) and the
decomposition `StrictAux.callSeqR_bind` of the call sequences of `p >>= f`.
-/

namespace F2e2e.C.Alg

open F2e2e.B
open F2e2e.Discrete

/-! ## Call sequences of controller programs -/

/-- A primitive call with its arguments (the oracle's response is not recorded). -/
inductive Call where
  | fpInit : Call
  | fpStep (i : ℕ) (Δ : ℤ) : Call
  | bankNew (tr d : ℕ) : Call
  | bankRetain (n : ℕ) : Call
  | bankOp (idx : ℕ) (op : RowOp) : Call
  | bankOpFrom (idx : ℕ) (op : RowOp) : Call
  | validate (idx : ℕ) (S θ : ℚ) : Call
  | release (idx : ℕ) (mode : Mode) : Call
  | note (ev : TreeEvent) : Call

/-- `CallSeq p l`: `l` is the sequence of primitive calls made by `p` along some path of oracle
responses, until `p` returns. -/
inductive CallSeq {α : Type} : AlgM α → List Call → Prop where
  | pure (a : α) : CallSeq (AlgM.pure a) []
  | fpInit {k : AlgM α} {l : List Call} : CallSeq k l → CallSeq (AlgM.fpInit k) (Call.fpInit :: l)
  | fpStep {i : ℕ} {Δ : ℤ} {k : Bool → AlgM α} {l : List Call} (b : Bool) :
      CallSeq (k b) l → CallSeq (AlgM.fpStep i Δ k) (Call.fpStep i Δ :: l)
  | bankNew {tr d : ℕ} {k : AlgM α} {l : List Call} :
      CallSeq k l → CallSeq (AlgM.bankNew tr d k) (Call.bankNew tr d :: l)
  | bankRetain {n : ℕ} {k : AlgM α} {l : List Call} :
      CallSeq k l → CallSeq (AlgM.bankRetain n k) (Call.bankRetain n :: l)
  | bankOp {idx : ℕ} {op : RowOp} {k : AlgM α} {l : List Call} :
      CallSeq k l → CallSeq (AlgM.bankOp idx op k) (Call.bankOp idx op :: l)
  | bankOpFrom {idx : ℕ} {op : RowOp} {k : AlgM α} {l : List Call} :
      CallSeq k l → CallSeq (AlgM.bankOpFrom idx op k) (Call.bankOpFrom idx op :: l)
  | validate {idx : ℕ} {S θ : ℚ} {k : AdaCert → AlgM α} {l : List Call} (c : AdaCert) :
      CallSeq (k c) l → CallSeq (AlgM.bankValidate idx S θ k) (Call.validate idx S θ :: l)
  | release {idx : ℕ} {mode : Mode} {k : Option ℚ → AlgM α} {l : List Call} (o : Option ℚ) :
      CallSeq (k o) l → CallSeq (AlgM.bankRelease idx mode k) (Call.release idx mode :: l)
  | note {ev : TreeEvent} {k : AlgM α} {l : List Call} :
      CallSeq k l → CallSeq (AlgM.note ev k) (Call.note ev :: l)

/-- The fingerprint step (the first read of the round's update). -/
def Call.isFpStep : Call → Bool
  | Call.fpStep _ _ => true
  | _ => false

/-- A physical row update. -/
def Call.isPhys : Call → Bool
  | Call.bankOp _ (RowOp.phys _ _) => true
  | Call.bankOpFrom _ (RowOp.phys _ _) => true
  | _ => false

/-- A bank allocation. -/
def Call.isBankNew : Call → Bool
  | Call.bankNew _ _ => true
  | _ => false

/-- A bank retirement. -/
def Call.isRetain : Call → Bool
  | Call.bankRetain _ => true
  | _ => false

/-- A reset of client-secondary counters. -/
def Call.isResetY : Call → Bool
  | Call.bankOp _ RowOp.resetY => true
  | Call.bankOpFrom _ RowOp.resetY => true
  | _ => false

/-- An allocation, a retirement or a reset. -/
def Call.isAllocOrReset (c : Call) : Bool := c.isBankNew || c.isRetain || c.isResetY

/-! ## Proof infrastructure (namespace `StrictAux`)

`CallSeqR p a l` is `CallSeq p l` together with the value `a` returned at the end of the path; call
sequences of `p >>= f` split as a sequence of `p` followed by a sequence of `f a` (`callSeqR_bind`). -/

namespace StrictAux

/-- `CallSeqR p a l`: `l` is the sequence of primitive calls made by `p` along some path of oracle
responses, at the end of which `p` returns `a`. -/
inductive CallSeqR {α : Type} : AlgM α → α → List Call → Prop where
  | pure (a : α) : CallSeqR (AlgM.pure a) a []
  | fpInit {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.fpInit k) a (Call.fpInit :: l)
  | fpStep {i : ℕ} {Δ : ℤ} {k : Bool → AlgM α} {a : α} {l : List Call} (b : Bool) :
      CallSeqR (k b) a l → CallSeqR (AlgM.fpStep i Δ k) a (Call.fpStep i Δ :: l)
  | bankNew {tr d : ℕ} {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.bankNew tr d k) a (Call.bankNew tr d :: l)
  | bankRetain {n : ℕ} {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.bankRetain n k) a (Call.bankRetain n :: l)
  | bankOp {idx : ℕ} {op : RowOp} {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.bankOp idx op k) a (Call.bankOp idx op :: l)
  | bankOpFrom {idx : ℕ} {op : RowOp} {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.bankOpFrom idx op k) a (Call.bankOpFrom idx op :: l)
  | validate {idx : ℕ} {S θ : ℚ} {k : AdaCert → AlgM α} {a : α} {l : List Call} (c : AdaCert) :
      CallSeqR (k c) a l → CallSeqR (AlgM.bankValidate idx S θ k) a (Call.validate idx S θ :: l)
  | release {idx : ℕ} {mode : Mode} {k : Option ℚ → AlgM α} {a : α} {l : List Call} (o : Option ℚ) :
      CallSeqR (k o) a l → CallSeqR (AlgM.bankRelease idx mode k) a (Call.release idx mode :: l)
  | note {ev : TreeEvent} {k : AlgM α} {a : α} {l : List Call} :
      CallSeqR k a l → CallSeqR (AlgM.note ev k) a (Call.note ev :: l)

theorem callSeq_exists {α : Type} {p : AlgM α} {l : List Call} (h : CallSeq p l) :
    ∃ a, CallSeqR p a l := by
  induction h with
  | pure a => exact ⟨a, .pure a⟩
  | fpInit _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .fpInit h⟩
  | fpStep b _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .fpStep b h⟩
  | bankNew _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .bankNew h⟩
  | bankRetain _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .bankRetain h⟩
  | bankOp _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .bankOp h⟩
  | bankOpFrom _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .bankOpFrom h⟩
  | validate c _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .validate c h⟩
  | release o _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .release o h⟩
  | note _ ih => obtain ⟨a, h⟩ := ih; exact ⟨a, .note h⟩

theorem callSeqR_bind {α β : Type} (f : α → AlgM β) (p : AlgM α) :
    ∀ {b : β} {l : List Call}, CallSeqR (p.bind f) b l →
      ∃ a l₁ l₂, CallSeqR p a l₁ ∧ CallSeqR (f a) b l₂ ∧ l = l₁ ++ l₂ := by
  induction p with
  | pure a => intro b l h; exact ⟨a, [], l, .pure a, h, rfl⟩
  | fpInit k ih =>
    intro b l h
    change CallSeqR (AlgM.fpInit (k.bind f)) b l at h
    cases h with
    | fpInit h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .fpInit h1, h2, rfl⟩
  | fpStep i Δ k ih =>
    intro b l h
    change CallSeqR (AlgM.fpStep i Δ (fun x => (k x).bind f)) b l at h
    cases h with
    | fpStep x h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih x h'
      exact ⟨a, _, l₂, .fpStep x h1, h2, rfl⟩
  | bankNew tr d k ih =>
    intro b l h
    change CallSeqR (AlgM.bankNew tr d (k.bind f)) b l at h
    cases h with
    | bankNew h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .bankNew h1, h2, rfl⟩
  | bankRetain n k ih =>
    intro b l h
    change CallSeqR (AlgM.bankRetain n (k.bind f)) b l at h
    cases h with
    | bankRetain h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .bankRetain h1, h2, rfl⟩
  | bankOp idx op k ih =>
    intro b l h
    change CallSeqR (AlgM.bankOp idx op (k.bind f)) b l at h
    cases h with
    | bankOp h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .bankOp h1, h2, rfl⟩
  | bankOpFrom idx op k ih =>
    intro b l h
    change CallSeqR (AlgM.bankOpFrom idx op (k.bind f)) b l at h
    cases h with
    | bankOpFrom h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .bankOpFrom h1, h2, rfl⟩
  | bankValidate idx S θ k ih =>
    intro b l h
    change CallSeqR (AlgM.bankValidate idx S θ (fun x => (k x).bind f)) b l at h
    cases h with
    | validate x h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih x h'
      exact ⟨a, _, l₂, .validate x h1, h2, rfl⟩
  | bankRelease idx mode k ih =>
    intro b l h
    change CallSeqR (AlgM.bankRelease idx mode (fun x => (k x).bind f)) b l at h
    cases h with
    | release x h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih x h'
      exact ⟨a, _, l₂, .release x h1, h2, rfl⟩
  | note ev k ih =>
    intro b l h
    change CallSeqR (AlgM.note ev (k.bind f)) b l at h
    cases h with
    | note h' =>
      obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := ih h'
      exact ⟨a, _, l₂, .note h1, h2, rfl⟩

/-! ### Inversion -/

section Inv

variable {α : Type} {a b : α} {l : List Call}

theorem inv_pure : CallSeqR (AlgM.pure a) b l ↔ b = a ∧ l = [] := by
  constructor
  · intro h; cases h; exact ⟨rfl, rfl⟩
  · rintro ⟨rfl, rfl⟩; exact .pure _

theorem inv_fpStep {i : ℕ} {Δ : ℤ} {k : Bool → AlgM α} :
    CallSeqR (AlgM.fpStep i Δ k) a l ↔ ∃ x l', l = Call.fpStep i Δ :: l' ∧ CallSeqR (k x) a l' := by
  constructor
  · intro h; cases h with | fpStep x h => exact ⟨x, _, rfl, h⟩
  · rintro ⟨x, l', rfl, h⟩; exact .fpStep x h

theorem inv_bankNew {tr d : ℕ} {k : AlgM α} :
    CallSeqR (AlgM.bankNew tr d k) a l ↔ ∃ l', l = Call.bankNew tr d :: l' ∧ CallSeqR k a l' := by
  constructor
  · intro h; cases h with | bankNew h => exact ⟨_, rfl, h⟩
  · rintro ⟨l', rfl, h⟩; exact .bankNew h

theorem inv_bankRetain {n : ℕ} {k : AlgM α} :
    CallSeqR (AlgM.bankRetain n k) a l ↔ ∃ l', l = Call.bankRetain n :: l' ∧ CallSeqR k a l' := by
  constructor
  · intro h; cases h with | bankRetain h => exact ⟨_, rfl, h⟩
  · rintro ⟨l', rfl, h⟩; exact .bankRetain h

theorem inv_bankOp {idx : ℕ} {op : RowOp} {k : AlgM α} :
    CallSeqR (AlgM.bankOp idx op k) a l ↔ ∃ l', l = Call.bankOp idx op :: l' ∧ CallSeqR k a l' := by
  constructor
  · intro h; cases h with | bankOp h => exact ⟨_, rfl, h⟩
  · rintro ⟨l', rfl, h⟩; exact .bankOp h

theorem inv_bankOpFrom {idx : ℕ} {op : RowOp} {k : AlgM α} :
    CallSeqR (AlgM.bankOpFrom idx op k) a l ↔
      ∃ l', l = Call.bankOpFrom idx op :: l' ∧ CallSeqR k a l' := by
  constructor
  · intro h; cases h with | bankOpFrom h => exact ⟨_, rfl, h⟩
  · rintro ⟨l', rfl, h⟩; exact .bankOpFrom h

theorem inv_validate {idx : ℕ} {S θ : ℚ} {k : AdaCert → AlgM α} :
    CallSeqR (AlgM.bankValidate idx S θ k) a l ↔
      ∃ x l', l = Call.validate idx S θ :: l' ∧ CallSeqR (k x) a l' := by
  constructor
  · intro h; cases h with | validate x h => exact ⟨x, _, rfl, h⟩
  · rintro ⟨x, l', rfl, h⟩; exact .validate x h

theorem inv_release {idx : ℕ} {mode : Mode} {k : Option ℚ → AlgM α} :
    CallSeqR (AlgM.bankRelease idx mode k) a l ↔
      ∃ x l', l = Call.release idx mode :: l' ∧ CallSeqR (k x) a l' := by
  constructor
  · intro h; cases h with | release x h => exact ⟨x, _, rfl, h⟩
  · rintro ⟨x, l', rfl, h⟩; exact .release x h

theorem inv_note {ev : TreeEvent} {k : AlgM α} :
    CallSeqR (AlgM.note ev k) a l ↔ ∃ l', l = Call.note ev :: l' ∧ CallSeqR k a l' := by
  constructor
  · intro h; cases h with | note h => exact ⟨_, rfl, h⟩
  · rintro ⟨l', rfl, h⟩; exact .note h

end Inv

/-! ### Binds of the primitive actions (definitional) -/

section Prim

variable {β : Type}

theorem fpStepM_bind (i : ℕ) (Δ : ℤ) (f : Bool → AlgM β) : (fpStepM i Δ).bind f = AlgM.fpStep i Δ f :=
  rfl

theorem bankNewM_bind (tr d : ℕ) (f : Unit → AlgM β) :
    (bankNewM tr d).bind f = AlgM.bankNew tr d (f ()) := rfl

theorem bankRetainM_bind (n : ℕ) (f : Unit → AlgM β) :
    (bankRetainM n).bind f = AlgM.bankRetain n (f ()) := rfl

theorem bankOpM_bind (idx : ℕ) (op : RowOp) (f : Unit → AlgM β) :
    (bankOpM idx op).bind f = AlgM.bankOp idx op (f ()) := rfl

theorem bankOpFromM_bind (idx : ℕ) (op : RowOp) (f : Unit → AlgM β) :
    (bankOpFromM idx op).bind f = AlgM.bankOpFrom idx op (f ()) := rfl

theorem validateM_bind (idx : ℕ) (S θ : ℚ) (f : AdaCert → AlgM β) :
    (validateM idx S θ).bind f = AlgM.bankValidate idx S θ f := rfl

theorem releaseM_bind (idx : ℕ) (mode : Mode) (f : Option ℚ → AlgM β) :
    (releaseM idx mode).bind f = AlgM.bankRelease idx mode f := rfl

theorem noteM_bind (ev : TreeEvent) (f : Unit → AlgM β) : (noteM ev).bind f = AlgM.note ev (f ()) :=
  rfl

end Prim

/-! ### Every call of every path -/

/-- Every call made by `p`, on every path of oracle responses, satisfies `Q`. -/
def AllCalls {α : Type} (Q : Call → Prop) (p : AlgM α) : Prop :=
  ∀ a l, CallSeqR p a l → ∀ x ∈ l, Q x

section AllCallsLemmas

variable {α β : Type} {Q : Call → Prop}

theorem allCalls_pure (a : α) : AllCalls Q (AlgM.pure a) := by
  intro b l h x hx
  rw [inv_pure] at h
  rw [h.2] at hx
  simp at hx

theorem allCalls_bind {p : AlgM α} {f : α → AlgM β} (hp : AllCalls Q p) (hf : ∀ a, AllCalls Q (f a)) :
    AllCalls Q (p.bind f) := by
  intro b l h x hx
  obtain ⟨a, l₁, l₂, h1, h2, rfl⟩ := callSeqR_bind f p h
  rcases List.mem_append.mp hx with hx | hx
  · exact hp a l₁ h1 x hx
  · exact hf a b l₂ h2 x hx

theorem allCalls_ite {c : Prop} [Decidable c] {p q : AlgM α} (hp : c → AllCalls Q p)
    (hq : ¬c → AllCalls Q q) : AllCalls Q (if c then p else q) := by
  by_cases h : c
  · rw [if_pos h]; exact hp h
  · rw [if_neg h]; exact hq h

theorem allCalls_bankOp {idx : ℕ} {op : RowOp} {k : AlgM α} (hq : Q (Call.bankOp idx op))
    (hk : AllCalls Q k) : AllCalls Q (AlgM.bankOp idx op k) := by
  intro b l h x hx
  rw [inv_bankOp] at h
  obtain ⟨l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk b l' h' x hx

theorem allCalls_bankOpFrom {idx : ℕ} {op : RowOp} {k : AlgM α} (hq : Q (Call.bankOpFrom idx op))
    (hk : AllCalls Q k) : AllCalls Q (AlgM.bankOpFrom idx op k) := by
  intro b l h x hx
  rw [inv_bankOpFrom] at h
  obtain ⟨l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk b l' h' x hx

theorem allCalls_note {ev : TreeEvent} {k : AlgM α} (hq : Q (Call.note ev)) (hk : AllCalls Q k) :
    AllCalls Q (AlgM.note ev k) := by
  intro b l h x hx
  rw [inv_note] at h
  obtain ⟨l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk b l' h' x hx

theorem allCalls_validate {idx : ℕ} {S θ : ℚ} {k : AdaCert → AlgM α}
    (hq : Q (Call.validate idx S θ)) (hk : ∀ c, AllCalls Q (k c)) :
    AllCalls Q (AlgM.bankValidate idx S θ k) := by
  intro b l h x hx
  rw [inv_validate] at h
  obtain ⟨c, l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk c b l' h' x hx

theorem allCalls_release {idx : ℕ} {mode : Mode} {k : Option ℚ → AlgM α}
    (hq : Q (Call.release idx mode)) (hk : ∀ o, AllCalls Q (k o)) :
    AllCalls Q (AlgM.bankRelease idx mode k) := by
  intro b l h x hx
  rw [inv_release] at h
  obtain ⟨o, l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk o b l' h' x hx

end AllCallsLemmas

/-- The calls of Steps 3–4: no fingerprint step, no physical update, no allocation, retirement or
reset. -/
def Late (x : Call) : Prop := x.isFpStep = false ∧ x.isPhys = false ∧ x.isAllocOrReset = false

/-! ### Steps 2, 3, 4 -/

theorem step2_calls {P : StreamParams} {i : ℕ} {Δ : ℤ} {c : CState} {r : CState × Bool}
    {l : List Call} (h : CallSeqR (step2Code P i Δ c) r l) :
    l = [Call.fpStep (i + 1) Δ, Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ),
      Call.note (TreeEvent.phys (i + 1) Δ)] := by
  unfold step2Code at h
  simp only [AlgM.bind_eq, fpStepM_bind, bankOpFromM_bind, noteM_bind, AlgM.pure_eq] at h
  rw [inv_fpStep] at h
  obtain ⟨z, l1, rfl, h1⟩ := h
  rw [inv_bankOpFrom] at h1
  obtain ⟨l2, rfl, h2⟩ := h1
  rw [inv_note] at h2
  obtain ⟨l3, rfl, h3⟩ := h2
  rw [inv_pure] at h3
  rw [h3.2]

theorem step3Depth_late (P : StreamParams) (tr : ℕ) (c : CState) (d : ℕ) :
    AllCalls Late (step3DepthCode P tr c d) := by
  unfold step3DepthCode
  split
  · exact allCalls_pure _
  · simp only [AlgM.bind_eq, bankOpM_bind, bankOpFromM_bind, noteM_bind, AlgM.pure_eq]
    apply allCalls_ite
    · intro _
      exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)
    · intro _
      exact allCalls_bankOp ⟨rfl, rfl, rfl⟩
        (allCalls_bankOpFrom ⟨rfl, rfl, rfl⟩ (allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)))

theorem step3Loop_late (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (c : CState), AllCalls Late (step3LoopCode P tr ds c)
  | [], c => by
    simp only [step3LoopCode, AlgM.pure_eq]
    exact allCalls_pure _
  | d :: ds, c => by
    simp only [step3LoopCode, AlgM.bind_eq, AlgM.pure_eq]
    apply allCalls_ite
    · intro _; exact allCalls_pure _
    · intro _; exact allCalls_bind (step3Depth_late P tr c d) (fun c' => step3Loop_late P tr ds c')

theorem rejectTail_late (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (c : CState) :
    AllCalls Late (rejectTailCode P d Ld cInt N1 c) := by
  unfold rejectTailCode
  simp only [AlgM.bind_eq, bankOpFromM_bind, noteM_bind, releaseM_bind, AlgM.pure_eq]
  refine allCalls_bankOpFrom ⟨rfl, rfl, rfl⟩ (allCalls_note ⟨rfl, rfl, rfl⟩ ?_)
  apply allCalls_ite
  · intro _
    refine allCalls_release ⟨rfl, rfl, rfl⟩ (fun o => ?_)
    cases o <;> exact allCalls_pure _
  · intro _; exact allCalls_pure _

theorem rejectDepth_late (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState) :
    AllCalls Late (rejectDepthCode P d pos Qhat c) := by
  unfold rejectDepthCode
  split
  · exact allCalls_pure _
  · simp only [AlgM.bind_eq, bankOpM_bind, releaseM_bind, AlgM.pure_eq]
    apply allCalls_ite
    · intro _; exact allCalls_pure _
    · intro _
      refine allCalls_release ⟨rfl, rfl, rfl⟩ (fun o => ?_)
      cases o with
      | none => exact allCalls_pure _
      | some N1 =>
        apply allCalls_ite
        · intro _
          exact allCalls_bankOp ⟨rfl, rfl, rfl⟩ (rejectTail_late P d _ _ N1 c)
        · intro _; exact allCalls_pure _

theorem step4Depth_late (P : StreamParams) (d : ℕ) (c : CState) (F : ℚ) :
    AllCalls Late (step4DepthCode P d c F) := by
  unfold step4DepthCode
  split
  · exact allCalls_pure _
  · simp only [AlgM.bind_eq, validateM_bind, noteM_bind, AlgM.pure_eq]
    apply allCalls_ite
    · intro _
      refine allCalls_validate ⟨rfl, rfl, rfl⟩ (fun cert => ?_)
      cases cert with
      | accept => exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)
      | high => exact rejectDepth_late P d true _ c
      | low => exact rejectDepth_late P d false _ c
      | _ => exact allCalls_pure _
    · intro _; exact allCalls_pure _

theorem allCalls_bankNew {α : Type} {Q : Call → Prop} {tr d : ℕ} {k : AlgM α}
    (hq : Q (Call.bankNew tr d)) (hk : AllCalls Q k) : AllCalls Q (AlgM.bankNew tr d k) := by
  intro b l h x hx
  rw [inv_bankNew] at h
  obtain ⟨l', rfl, h'⟩ := h
  rcases List.mem_cons.mp hx with rfl | hx
  · exact hq
  · exact hk b l' h' x hx

theorem step4Loop_late (P : StreamParams) :
    ∀ (ds : List ℕ) (c : CState) (F : ℚ), AllCalls Late (step4LoopCode P ds c F)
  | [], c, F => by
    simp only [step4LoopCode, AlgM.pure_eq]
    exact allCalls_pure _
  | d :: ds, c, F => by
    simp only [step4LoopCode, AlgM.bind_eq, AlgM.pure_eq]
    apply allCalls_ite
    · intro _; exact allCalls_pure _
    · intro _
      exact allCalls_bind (step4Depth_late P d c F) (fun r => step4Loop_late P ds r.1 r.2)

/-! ### Step 1 -/

/-- The calls of Step 1 after the retirement: no fingerprint step, no physical update, no
retirement. -/
def Birthy (x : Call) : Prop := x.isFpStep = false ∧ x.isPhys = false ∧ x.isRetain = false

theorem birthCode_birthy (P : StreamParams) (tr d0 d : ℕ) (c : CState) :
    AllCalls Birthy (birthCode P tr d0 d c) := by
  unfold birthCode
  simp only [AlgM.bind_eq, bankOpM_bind, bankNewM_bind, noteM_bind, releaseM_bind, AlgM.pure_eq]
  refine allCalls_bankOp ⟨rfl, rfl, rfl⟩ ?_
  apply allCalls_ite
  · intro _
    refine allCalls_bankNew ⟨rfl, rfl, rfl⟩ ?_
    apply allCalls_ite
    · intro _; exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)
    · intro _
      refine allCalls_release ⟨rfl, rfl, rfl⟩ (fun o => ?_)
      cases o with
      | none => exact allCalls_pure _
      | some N => exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)
  · intro _
    apply allCalls_ite
    · intro _; exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)
    · intro _
      refine allCalls_release ⟨rfl, rfl, rfl⟩ (fun o => ?_)
      cases o with
      | none => exact allCalls_pure _
      | some N => exact allCalls_note ⟨rfl, rfl, rfl⟩ (allCalls_pure _)

theorem birthLoop_birthy (P : StreamParams) (tr d0 : ℕ) :
    ∀ (ds : List ℕ) (c : CState), AllCalls Birthy (birthLoopCode P tr d0 ds c)
  | [], c => by
    simp only [birthLoopCode, AlgM.pure_eq]
    exact allCalls_pure _
  | d :: ds, c => by
    simp only [birthLoopCode, AlgM.bind_eq, AlgM.pure_eq]
    apply allCalls_ite
    · intro _; exact allCalls_pure _
    · intro _
      exact allCalls_bind (birthCode_birthy P tr d0 d c) (fun c' => birthLoop_birthy P tr d0 ds c')

/-- The exact shape of the calls of one birth: the client reset, the allocation of the outgoing bank
(for `d + 2 ≤ H`), then a note and/or the release of the birth cache. -/
theorem birthCode_calls {P : StreamParams} {tr d0 d : ℕ} {c c' : CState} {l : List Call}
    (h : CallSeqR (birthCode P tr d0 d c) c' l) :
    ∃ lr, l = Call.bankOp d RowOp.resetY ::
        ((if d + 2 ≤ P.H then [Call.bankNew tr d] else []) ++ lr) ∧
      ∀ x ∈ lr, x = Call.note (TreeEvent.birth d) ∨ x = Call.release d Mode.primary := by
  unfold birthCode at h
  simp only [AlgM.bind_eq, bankOpM_bind, bankNewM_bind, noteM_bind, releaseM_bind,
    AlgM.pure_eq] at h
  rw [inv_bankOp] at h
  obtain ⟨l1, rfl, h1⟩ := h
  split at h1
  · rename_i hd
    rw [inv_bankNew] at h1
    obtain ⟨l2, rfl, h2⟩ := h1
    refine ⟨l2, by rw [if_pos hd]; rfl, ?_⟩
    split at h2
    · simp only [inv_note, inv_pure] at h2
      obtain ⟨l3, rfl, -, rfl⟩ := h2
      simp
    · rw [inv_release] at h2
      obtain ⟨o, l3, rfl, h3⟩ := h2
      cases o with
      | none =>
        simp only [inv_pure] at h3
        rw [h3.2]
        simp
      | some N =>
        simp only [inv_note, inv_pure] at h3
        obtain ⟨l4, rfl, -, rfl⟩ := h3
        simp
  · rename_i hd
    refine ⟨l1, by rw [if_neg hd]; rfl, ?_⟩
    split at h1
    · simp only [inv_note, inv_pure] at h1
      obtain ⟨l3, rfl, -, rfl⟩ := h1
      simp
    · rw [inv_release] at h1
      obtain ⟨o, l3, rfl, h3⟩ := h1
      cases o with
      | none =>
        simp only [inv_pure] at h3
        rw [h3.2]
        simp
      | some N =>
        simp only [inv_note, inv_pure] at h3
        obtain ⟨l4, rfl, -, rfl⟩ := h3
        simp

/-- The allocations and resets of the birth loop: a prefix of the scheduled ones, all of them unless
the loop ends in the failure state. -/
theorem birthLoop_filters (P : StreamParams) (tr d0 : ℕ) :
    ∀ (ds : List ℕ) (c c' : CState) (l : List Call), CallSeqR (birthLoopCode P tr d0 ds c) c' l →
      l.filter Call.isBankNew <+:
          (ds.filter (fun d => decide (d + 2 ≤ P.H))).map (fun d => Call.bankNew tr d) ∧
        l.filter Call.isResetY <+: ds.map (fun d => Call.bankOp d RowOp.resetY) ∧
        (c'.failed = false → l.filter Call.isBankNew =
          (ds.filter (fun d => decide (d + 2 ≤ P.H))).map (fun d => Call.bankNew tr d))
  | [], c, c', l, h => by
    simp only [birthLoopCode, AlgM.pure_eq, inv_pure] at h
    obtain ⟨-, rfl⟩ := h
    simp
  | d :: ds, c, c', l, h => by
    simp only [birthLoopCode, AlgM.bind_eq, AlgM.pure_eq] at h
    split at h
    · rename_i hc
      rw [inv_pure] at h
      obtain ⟨rfl, rfl⟩ := h
      refine ⟨by simp, by simp, fun hf => ?_⟩
      rw [hc] at hf
      exact absurd hf (by simp)
    · obtain ⟨c'', lb, lr, hb, hr, rfl⟩ := callSeqR_bind _ _ h
      obtain ⟨l0, rfl, hl0⟩ := birthCode_calls hb
      obtain ⟨ih1, ih2, ih3⟩ := birthLoop_filters P tr d0 ds c'' c' lr hr
      have hl0n : l0.filter Call.isBankNew = [] := by
        rw [List.filter_eq_nil_iff]
        intro x hx
        rcases hl0 x hx with rfl | rfl <;> simp [Call.isBankNew]
      have hl0r : l0.filter Call.isResetY = [] := by
        rw [List.filter_eq_nil_iff]
        intro x hx
        rcases hl0 x hx with rfl | rfl <;> simp [Call.isResetY]
      by_cases hd : d + 2 ≤ P.H
      · simp [hd, hl0n, hl0r, List.filter_cons, List.filter_append, Call.isBankNew, Call.isResetY]
        exact ⟨ih1, ih2, fun hf => ih3 hf⟩
      · simp [hd, hl0n, hl0r, List.filter_cons, List.filter_append, Call.isBankNew, Call.isResetY]
        exact ⟨ih1, ih2, fun hf => ih3 hf⟩

/-- The calls of Step 1: the retirement, then the birth loop. -/
theorem step1_calls {P : StreamParams} {c c1 : CState} {l : List Call}
    (h : CallSeqR (step1Code P c) c1 l) :
    ∃ c2 lb, CallSeqR (birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1))
        (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1)))
        { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }) c2 lb ∧
      l = Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ∧ c1.failed = c2.failed := by
  unfold step1Code at h
  simp only [AlgM.bind_eq, bankRetainM_bind, AlgM.pure_eq] at h
  rw [inv_bankRetain] at h
  obtain ⟨l', rfl, h'⟩ := h
  obtain ⟨c2, lb, l2, hb, h2, rfl⟩ := callSeqR_bind _ _ h'
  rw [inv_pure] at h2
  obtain ⟨rfl, rfl⟩ := h2
  exact ⟨c2, lb, hb, by simp, rfl⟩

/-! ### One round -/

/-- The calls of one round: nothing (failed state), or the note, Step 1, and possibly Step 2 (exactly
three calls) followed by calls of Steps 3–4. -/
theorem roundCode_split {P : StreamParams} {c : CState} {i : ℕ} {Δ : ℤ} {r : CState × ℚ}
    {l : List Call} (h : CallSeqR (roundCode P c i Δ) r l) :
    l = [] ∨ ∃ c1 l1 lrest, CallSeqR (step1Code P c) c1 l1 ∧
      l = Call.note TreeEvent.newRound :: (l1 ++ lrest) ∧
      (lrest = [] ∨ (c1.failed = false ∧ ∃ l34, (∀ x ∈ l34, Late x) ∧
        lrest = Call.fpStep (i + 1) Δ :: Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ) ::
          Call.note (TreeEvent.phys (i + 1) Δ) :: l34)) := by
  unfold roundCode at h
  split at h
  · simp only [AlgM.pure_eq, inv_pure] at h
    exact Or.inl h.2
  · right
    simp only [AlgM.bind_eq, noteM_bind, AlgM.pure_eq] at h
    rw [inv_note] at h
    obtain ⟨l', rfl, h'⟩ := h
    obtain ⟨c1, l1, lrest, h1, h2, rfl⟩ := callSeqR_bind _ _ h'
    refine ⟨c1, l1, lrest, h1, rfl, ?_⟩
    split at h2
    · rw [inv_pure] at h2
      exact Or.inl h2.2
    · rename_i hc1
      right
      refine ⟨by simpa using hc1, ?_⟩
      obtain ⟨r2, l2, l2', h21, h22, rfl⟩ := callSeqR_bind _ _ h2
      rw [step2_calls h21]
      split at h22
      · rw [inv_pure] at h22
        exact ⟨[], by simp, by rw [h22.2]; rfl⟩
      · obtain ⟨c3, l3, l3', h31, h32, rfl⟩ := callSeqR_bind _ _ h22
        have hl3 := step3Loop_late P _ _ _ _ _ h31
        split at h32
        · rw [inv_pure] at h32
          refine ⟨l3, hl3, ?_⟩
          rw [h32.2, List.append_nil]
          rfl
        · obtain ⟨r4, l4, l4', h41, h42, rfl⟩ := callSeqR_bind _ _ h32
          have hl4 := step4Loop_late P _ _ _ _ _ h41
          rw [inv_pure] at h42
          rw [h42.2, List.append_nil]
          refine ⟨l3 ++ l4, fun x hx => ?_, rfl⟩
          rcases List.mem_append.mp hx with hx | hx
          · exact hl3 x hx
          · exact hl4 x hx

/-! ### Positions -/

theorem idx_lt_of_split {l A B : List Call} (hl : l = A ++ B) {p q : Call → Bool}
    (hA : ∀ x ∈ A, q x = false) (hB : ∀ x ∈ B, p x = false) :
    ∀ j k (hj : j < l.length) (hk : k < l.length), p l[j] = true → q l[k] = true → j < k := by
  subst hl
  intro j k hj hk hp hq
  have hjA : j < A.length := by
    rcases Nat.lt_or_ge j A.length with hcon | hcon
    · exact hcon
    · rw [List.getElem_append_right hcon] at hp
      rw [hB _ (List.getElem_mem _)] at hp
      exact absurd hp Bool.false_ne_true
  have hkA : A.length ≤ k := by
    rcases Nat.lt_or_ge k A.length with hcon | hcon
    · rw [List.getElem_append_left hcon] at hq
      rw [hA _ (List.getElem_mem _)] at hq
      exact absurd hq Bool.false_ne_true
    · exact hcon
  omega

theorem after_of_split {l A B : List Call} (hl : l = A ++ B) {p q : Call → Bool}
    (hA : ∀ x ∈ A, p x = false) (hB : ∀ x ∈ B, q x = false) :
    ∀ j (hj : j < l.length), p l[j] = true → ∀ k (hk : k < l.length), j < k → q l[k] = false := by
  subst hl
  intro j hj hp k hk hjk
  have hjA : A.length ≤ j := by
    rcases Nat.lt_or_ge j A.length with hcon | hcon
    · rw [List.getElem_append_left hcon] at hp
      rw [hA _ (List.getElem_mem _)] at hp
      exact absurd hp Bool.false_ne_true
    · exact hcon
  rw [List.getElem_append_right (by omega : A.length ≤ k)]
  exact hB _ (List.getElem_mem _)

theorem forall_eq_of_filter_eq_singleton {l : List Call} {p : Call → Bool} {y : Call}
    (h : l.filter p = [y]) : ∀ x ∈ l, p x = true → x = y := by
  intro x hx hpx
  have : x ∈ l.filter p := List.mem_filter.mpr ⟨hx, hpx⟩
  rw [h] at this
  simpa using this

theorem not_of_filter_eq_nil {l : List Call} {p : Call → Bool} (h : l.filter p = []) :
    ∀ x ∈ l, p x = false := by
  intro x hx
  have := List.filter_eq_nil_iff.mp h x hx
  simpa using this

theorem late_parts {x : Call} (h : Late x) :
    x.isFpStep = false ∧ x.isPhys = false ∧ x.isBankNew = false ∧ x.isRetain = false ∧
      x.isResetY = false := by
  obtain ⟨h1, h2, h3⟩ := h
  rw [Call.isAllocOrReset, Bool.or_eq_false_iff, Bool.or_eq_false_iff] at h3
  exact ⟨h1, h2, h3.1.1, h3.1.2, h3.2⟩

theorem filter_nil_of_forall {l : List Call} {p : Call → Bool} (h : ∀ x ∈ l, p x = false) :
    l.filter p = [] :=
  List.filter_eq_nil_iff.mpr (fun x hx => by rw [h x hx]; exact Bool.false_ne_true)

/-- `firstBorn H tr ≤ H`. -/
theorem firstBorn_le (H tr : ℕ) : firstBorn H tr ≤ H := by
  unfold firstBorn
  have := List.findIdx_le_length (p := fun d => bornAt H d tr) (xs := List.range H)
  simpa using this

/-- The depths `≤ H − 2` among `a, …, a + n − 1` (when `a + n = H`). -/
theorem range'_filter (H : ℕ) : ∀ n a : ℕ, a + n = H →
    (List.range' a n).filter (fun d => decide (d + 2 ≤ H)) = List.range' a (n - 1)
  | 0, a, _ => by simp
  | n + 1, a, h => by
    rw [List.range'_succ, List.filter_cons]
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · have : ¬ (a + 2 ≤ H) := by omega
      simp [this]
    · have : a + 2 ≤ H := by omega
      rw [if_pos (by simpa using this), range'_filter H n (a + 1) (by omega)]
      obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
      simp [List.range'_succ]

theorem no_idx_of_forall {l : List Call} {p : Call → Bool} (h : ∀ x ∈ l, p x = false) (k : ℕ)
    (hk : k < l.length) : p l[k] = true → False := by
  intro hp
  rw [h _ (List.getElem_mem hk)] at hp
  exact Bool.false_ne_true hp

/-- The common analysis of the calls of a round for (c1), (d) and the client resets: the note, the
retirement, the birth loop `lb`, and the calls `lrest` of Steps 2–4, which contain no allocation,
retirement or reset, and contain a fingerprint step only if Step 1 did not fail. -/
theorem roundCode_split' {P : StreamParams} {c : CState} {i : ℕ} {Δ : ℤ} {l : List Call}
    (h : CallSeq (roundCode P c i Δ) l) :
    l = [] ∨ ∃ c2 lb lrest, CallSeqR (birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1))
        (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1)))
        { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }) c2 lb ∧
      l = Call.note TreeEvent.newRound ::
        (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ lrest) ∧
      (∀ x ∈ lrest, x.isBankNew = false ∧ x.isRetain = false ∧ x.isResetY = false) ∧
      ((∃ x ∈ lrest, x.isFpStep = true) → c2.failed = false) := by
  obtain ⟨r, hR⟩ := callSeq_exists h
  rcases roundCode_split hR with rfl | ⟨c1, l1, lrest, h1, rfl, hrest⟩
  · exact Or.inl rfl
  · right
    obtain ⟨c2, lb, hb, rfl, hc12⟩ := step1_calls h1
    refine ⟨c2, lb, lrest, hb, rfl, ?_, ?_⟩
    · rcases hrest with rfl | ⟨-, l34, h34, rfl⟩
      · simp
      · intro x hx
        simp only [List.mem_cons] at hx
        rcases hx with rfl | rfl | rfl | hx
        · exact ⟨rfl, rfl, rfl⟩
        · exact ⟨rfl, rfl, rfl⟩
        · exact ⟨rfl, rfl, rfl⟩
        · obtain ⟨-, -, h3, h4, h5⟩ := late_parts (h34 x hx)
          exact ⟨h3, h4, h5⟩
    · rcases hrest with rfl | ⟨hc1, l34, h34, rfl⟩
      · simp
      · intro _
        rw [← hc12]
        exact hc1

theorem early_isFpStep {P : StreamParams} {tr d0 : ℕ} {ds : List ℕ} {c c2 : CState} {lb : List Call}
    (hb : CallSeqR (birthLoopCode P tr d0 ds c) c2 lb) (n : ℕ) :
    ∀ x ∈ Call.note TreeEvent.newRound :: Call.bankRetain n :: lb, x.isFpStep = false := by
  intro x hx
  simp only [List.mem_cons] at hx
  rcases hx with rfl | rfl | hx
  · rfl
  · rfl
  · exact (birthLoop_birthy P tr d0 ds c _ lb hb x hx).1

/-! ### Fresh banks -/

theorem always_sampleList {α : Type} {Q : α → Prop} {p : BitProg α} (hp : Always p Q) :
    ∀ k, Always (sampleList p k) (fun l => ∀ x ∈ l, Q x)
  | 0 => always_pure (by simp)
  | k + 1 => by
    show Always (p.bind fun a => (sampleList p k).bind fun l => BitProg.pure (a :: l)) _
    exact Always.bind (fun a ha => Always.bind (fun l hl => always_pure (List.forall_mem_cons.mpr ⟨ha, hl⟩))
      (always_sampleList hp k)) hp

theorem always_newRow (P : StreamParams) : Always (newRow P) (fun r => r.X = 0 ∧ r.Y = 0) := by
  show Always ((sampleSeed P).bind fun z => BitProg.pure (⟨z, 0, 0⟩ : Row)) _
  exact Always.bind_all (fun _ => always_pure ⟨rfl, rfl⟩) _

theorem always_sampleBlocks (P : StreamParams) : ∀ ns : List ℕ,
    Always (sampleBlocks P ns) (fun blks => ∀ blk ∈ blks, ∀ r ∈ blk, r.X = 0 ∧ r.Y = 0)
  | [] => always_pure (by simp)
  | nj :: rest => by
    show Always ((sampleList (newRow P) nj).bind fun blk =>
      (sampleBlocks P rest).bind fun l => BitProg.pure (blk :: l)) _
    exact @Always.bind _ _ _ _ _ (fun blk hblk => @Always.bind _ _ _ _ _ (fun l hl =>
      always_pure (List.forall_mem_cons.mpr ⟨hblk, hl⟩)) _ (always_sampleBlocks P rest))
      _ (@always_sampleList _ _ _ (@always_newRow P) nj)

end StrictAux

open StrictAux

/-! ## (a) Single forward pass; the update is never altered, buffered or replayed (Rule 2) -/

/-- (a1) "processed online in a single forward pass and never altered … or replayed" (L41): a round
receives only its own update `(i, Δ)` (the controller state `CState` holds no update data), and on every
path the update is read exactly as given, at most once: at most one fingerprint step, which is
`fpStep (i+1) Δ`, and at most one physical row update, which is `bankOpFrom 0 (phys (i+1) Δ)` (the
update added once to every live bank, L482); they occur together. -/
theorem roundCode_single_pass (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) (l : List Call)
    (h : CallSeq (roundCode P c i Δ) l) :
    (l.filter Call.isFpStep).length ≤ 1 ∧
    (∀ x ∈ l, x.isFpStep = true → x = Call.fpStep (i + 1) Δ) ∧
    (l.filter Call.isPhys).length ≤ 1 ∧
    (∀ x ∈ l, x.isPhys = true → x = Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ)) ∧
    ((l.filter Call.isFpStep).length = (l.filter Call.isPhys).length) := by
  obtain ⟨r, hR⟩ := callSeq_exists h
  rcases roundCode_split hR with rfl | ⟨c1, l1, lrest, h1, rfl, hrest⟩
  · simp
  · obtain ⟨c2, lb, hb, rfl, -⟩ := step1_calls h1
    have hbB := birthLoop_birthy P _ _ _ _ _ _ hb
    have hF1 : lb.filter Call.isFpStep = [] := filter_nil_of_forall (fun x hx => (hbB x hx).1)
    have hP1 : lb.filter Call.isPhys = [] := filter_nil_of_forall (fun x hx => (hbB x hx).2.1)
    rcases hrest with rfl | ⟨-, l34, h34, rfl⟩
    · have hF : (Call.note TreeEvent.newRound ::
          (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ [])).filter Call.isFpStep = [] := by
        simp [hF1, Call.isFpStep]
      have hP : (Call.note TreeEvent.newRound ::
          (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ [])).filter Call.isPhys = [] := by
        simp [hP1, Call.isPhys]
      refine ⟨by rw [hF]; simp, fun x hx hfx => ?_, by rw [hP]; simp, fun x hx hpx => ?_,
        by rw [hF, hP]⟩
      · rw [not_of_filter_eq_nil hF x hx] at hfx; exact absurd hfx Bool.false_ne_true
      · rw [not_of_filter_eq_nil hP x hx] at hpx; exact absurd hpx Bool.false_ne_true
    · have h34F : l34.filter Call.isFpStep = [] :=
        filter_nil_of_forall (fun x hx => (late_parts (h34 x hx)).1)
      have h34P : l34.filter Call.isPhys = [] :=
        filter_nil_of_forall (fun x hx => (late_parts (h34 x hx)).2.1)
      have hF : (Call.note TreeEvent.newRound ::
          (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++
            Call.fpStep (i + 1) Δ :: Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ) ::
              Call.note (TreeEvent.phys (i + 1) Δ) :: l34)).filter Call.isFpStep =
            [Call.fpStep (i + 1) Δ] := by
        simp [List.filter_cons, List.filter_append, hF1, h34F, Call.isFpStep]
      have hP : (Call.note TreeEvent.newRound ::
          (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++
            Call.fpStep (i + 1) Δ :: Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ) ::
              Call.note (TreeEvent.phys (i + 1) Δ) :: l34)).filter Call.isPhys =
            [Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ)] := by
        simp [List.filter_cons, List.filter_append, hP1, h34P, Call.isPhys]
      exact ⟨by rw [hF]; simp, forall_eq_of_filter_eq_singleton hF, by rw [hP]; simp,
        forall_eq_of_filter_eq_singleton hP, by rw [hF, hP]; rfl⟩

/-- (a2) "realized purely computationally through maintained linear sketch row counters, virtual
learner states, residual energy caches, and finite-precision scale tags on fixed dyadic grids" (L41):
every row operation is a function of the row's counters and seed only, keeps the seed, and is either a
linear (rounded, saturated) update of the counters (`phys`, `guardY`, `guardXY`), a homogeneous
rescaling by a grid scalar (`scaleY`, `scaleXY`), or the client-secondary reset `resetY`. -/
theorem RowOp.apply_seed (P : StreamParams) (op : RowOp) (r : Row) : (op.apply P r).seed = r.seed := by
  cases op <;> rfl

/-! (a3) "never … buffered in full" (L41): the memory between updates is `State`; its only
update-dependent parts are the fingerprint register (`F_zero = Σ x_i r^i mod q`, Lemma
`R:lem:zero-fingerprint` (1); `step2_fpVal_modEq`) and the banks' row counters, which are maintained
only by the row operations of (a2). Its size is bounded independently of the round and of the update
values by C-SPACE's `StateOK.valSize_encState_le` / `algStep_inv` (`F2e2e/C/SpaceState.lean`), restated
for the reachable states as `strict_no_full_buffer`. -/

/-- The states of the algorithm reachable after its initialization and `t` rounds, for arbitrary updates
`(i, Δ)` and arbitrary fresh bits (no box promise is needed). -/
inductive RoundReach (P : StreamParams) : ℕ → State → Prop where
  | init {tape : List Bool} {s : State} {rest : List Bool} :
      initRun P tape = some (s, rest) → RoundReach P 0 s
  | step {t : ℕ} {s : State} {i : ℕ} {Δ : ℤ} {tape : List Bool} {s' : State} {q : ℚ}
      {rest : List Bool} :
      RoundReach P t s → stepRun P s i Δ tape = some ((s', q), rest) → RoundReach P (t + 1) s'

namespace StrictAux

theorem algInit_t (P : StreamParams) : Always (algInit P) (fun s => s.t = 0) := by
  show Always ((fpSeedProg P).bind fun r => (newBank P).bind fun B =>
    BitProg.pure (⟨0, false, r, 0, [], [B], 0⟩ : State)) _
  refine @Always.bind_all _ _ (fun s : State => s.t = 0) _ (fun r => ?_) _
  exact @Always.bind_all _ _ (fun s : State => s.t = 0) _ (fun B => always_pure rfl) _

/-- Every reachable state satisfies C-SPACE's invariant, and its round counter is the number of rounds. -/
theorem roundReach_inv (P : StreamParams) {adaOK : AdaState → Prop}
    (hA : Space.AdaInvariant P adaOK) {t : ℕ} {s : State} (hs : RoundReach P t s) :
    Space.StateInv P adaOK s ∧ s.t = t := by
  induction hs with
  | init h => exact ⟨Space.initRun_inv P hA h, Always.of_run (@algInit_t P) h⟩
  | step _ h ih =>
    refine ⟨Space.stepRun_inv P hA ih.1 h, ?_⟩
    have h2 := Always.of_run (@algStep_t P _ _ _) h
    simp only at h2
    rw [h2, ih.2]

end StrictAux

/-- (a3) "never … buffered in full" (L41): between updates, after any `t ≤ m` rounds with arbitrary
updates and fresh bits, the whole memory of the algorithm (the canonical encoding `encState` of
`F2e2e/C/SpaceDefs.lean`, for any encoding `adaEnc` of the ADA module's state of size at most `adaBound`
on its invariant `adaOK`) has tree size at most `stateSizeBound P adaBound`, a function of the parameters
only: it does not depend on `t` nor on the update values (C-SPACE's `StateOK.valSize_encState_le` and
`initRun_inv` / `stepRun_inv`, `F2e2e/C/SpaceState.lean`). -/
theorem strict_no_full_buffer (P : StreamParams) {adaOK : AdaState → Prop}
    (hA : Space.AdaInvariant P adaOK) {adaEnc : AdaState → Val} {adaBound : ℕ}
    (hada : ∀ st, adaOK st → valSize (adaEnc st) ≤ adaBound) {t : ℕ} {s : State}
    (hs : RoundReach P t s) (ht : t ≤ P.m) :
    valSize (Space.encState adaEnc s) ≤ Space.stateSizeBound P adaBound := by
  obtain ⟨hinv, hst⟩ := StrictAux.roundReach_inv P hA hs
  exact hinv.1.valSize_encState_le hada (by rw [hst]; exact ht)

/-! ## (b) Persistence across ancestor corrections (Rule 3) -/

/-- (b1) "without ever being restarted, re-allocated, reset in-place": after the round's update is
read (Steps 2–4, in particular in every Step-4 correction) no bank is allocated, retired, or reset:
every call after the fingerprint step is a validation, a release, a note, or a row operation among
`phys`, `guardY`, `guardXY`, `scaleY`, `scaleXY`. -/
theorem roundCode_no_alloc_after_update (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ)
    (l : List Call) (h : CallSeq (roundCode P c i Δ) l) (j : ℕ) (hj : j < l.length)
    (hfp : l[j].isFpStep = true) :
    ∀ k (hk : k < l.length), j < k → l[k].isAllocOrReset = false := by
  obtain ⟨r, hR⟩ := callSeq_exists h
  rcases roundCode_split hR with rfl | ⟨c1, l1, lrest, h1, rfl, hrest⟩
  · simp at hj
  · obtain ⟨c2, lb, hb, rfl, -⟩ := step1_calls h1
    have hbB := birthLoop_birthy P _ _ _ _ _ _ hb
    have hA : ∀ x ∈ Call.note TreeEvent.newRound ::
        Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb, x.isFpStep = false := by
      intro x hx
      simp only [List.mem_cons] at hx
      rcases hx with rfl | rfl | hx
      · rfl
      · rfl
      · exact (hbB x hx).1
    rcases hrest with rfl | ⟨-, l34, h34, rfl⟩
    · exact after_of_split (A := Call.note TreeEvent.newRound ::
        Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb) (B := []) (by simp) hA (by simp)
        j hj hfp
    · refine after_of_split (A := Call.note TreeEvent.newRound ::
        Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb)
        (B := Call.fpStep (i + 1) Δ :: Call.bankOpFrom 0 (RowOp.phys (i + 1) Δ) ::
          Call.note (TreeEvent.phys (i + 1) Δ) :: l34) (by simp) hA ?_ j hj hfp
      intro x hx
      simp only [List.mem_cons] at hx
      rcases hx with rfl | rfl | rfl | hx
      · rfl
      · rfl
      · rfl
      · exact (h34 x hx).2.2

/-- (b2) "persist across the correction via homogeneous scalar rescaling" (L42): a Step-4 correction
at depth `d` makes exactly the calls `release d PRIMARY` (for `N₁`), `bankOp d (scaleY cInt)` (the
corrected learner's outgoing measurement `Y_d`), `bankOpFrom (d+1) (scaleXY cInt)` (both arrays of the
banks of every strict nonleaf descendant), the note, and `release d DIFF`, with one grid scalar
`c = cInt h_step ∈ [1/2, 3/2]`; it stops earlier only by entering the failure state. -/
theorem rejectDepthCode_calls (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState)
    (l : List Call) (h : CallSeq (rejectDepthCode P d pos Qhat c) l) :
    l = [] ∨ l = [Call.release d Mode.primary] ∨
      ∃ cInt : ℤ, 2 ^ (P.eHstep - 1) ≤ cInt ∧ cInt ≤ 3 * 2 ^ (P.eHstep - 1) ∧
        (l = [Call.release d Mode.primary, Call.bankOp d (RowOp.scaleY cInt),
            Call.bankOpFrom (d + 1) (RowOp.scaleXY cInt), Call.note (TreeEvent.correct d cInt)] ∨
          l = [Call.release d Mode.primary, Call.bankOp d (RowOp.scaleY cInt),
            Call.bankOpFrom (d + 1) (RowOp.scaleXY cInt), Call.note (TreeEvent.correct d cInt),
            Call.release d Mode.diff]) := by
  obtain ⟨r, hR⟩ := callSeq_exists h
  unfold rejectDepthCode at hR
  split at hR
  · simp only [AlgM.pure_eq, inv_pure] at hR
    exact Or.inl hR.2
  · rename_i Ld _
    simp only [AlgM.bind_eq, bankOpM_bind, releaseM_bind, AlgM.pure_eq] at hR
    split at hR
    · simp only [inv_pure] at hR
      exact Or.inl hR.2
    · rw [inv_release] at hR
      obtain ⟨o, l1, rfl, h1⟩ := hR
      right
      cases o with
      | none =>
        simp only [inv_pure] at h1
        left
        rw [h1.2]
      | some N1 =>
        simp only at h1
        split at h1
        · rw [inv_bankOp] at h1
          obtain ⟨l2, rfl, h2⟩ := h1
          unfold rejectTailCode at h2
          simp only [AlgM.bind_eq, bankOpFromM_bind, noteM_bind, releaseM_bind, AlgM.pure_eq] at h2
          rw [inv_bankOpFrom] at h2
          obtain ⟨l3, rfl, h3⟩ := h2
          rw [inv_note] at h3
          obtain ⟨l4, rfl, h4⟩ := h3
          right
          have hq : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
          obtain ⟨hlo, hhi⟩ := stepCoeffMant_mem pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat hq
          refine ⟨_, hlo, hhi, ?_⟩
          split at h4
          · rw [inv_release] at h4
            obtain ⟨o2, l5, rfl, h5⟩ := h4
            right
            cases o2 with
            | none =>
              simp only [inv_pure] at h5
              rw [h5.2]
            | some N2 =>
              simp only [inv_pure] at h5
              rw [h5.2]
          · simp only [inv_pure] at h4
            left
            rw [h4.2]
        · simp only [inv_pure] at h1
          left
          rw [h1.2]

/-- (b3) The active descendant learners persist too: a correction at depth `d` changes the record of
every strict descendant `d' > d` only by the rescaling of its tag by `c` and its cache by `c²`
(`Learner.rescale`; its epoch and correction counters are kept), on every path that does not fail. -/
theorem rejectTailCode_descendants (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (c : CState) (o : OState) :
    Always (runO P (rejectTailCode P d Ld cInt N1 c) o) (fun res => res.1.1.failed = false →
      ∀ d', d < d' → res.1.1.learners[d']? = (c.learners[d']?).map (Learner.rescale P cInt)) := by
  unfold rejectTailCode
  simp only [AlgM.bind_eq, bankOpFromM_bind, noteM_bind, releaseM_bind, AlgM.pure_eq,
    runO_bankOpFrom, runO_note]
  split
  · rw [runO_bankRelease]
    split
    · simp only [runO_pure]
      exact always_pure (fun hf => by simp [CState.fail] at hf)
    · apply Always.bind_all
      rintro ⟨o2, B'⟩
      cases o2 with
      | none =>
        simp only [runO_pure]
        exact always_pure (fun hf => by simp [CState.fail] at hf)
      | some N2 =>
        simp only [runO_pure]
        apply always_pure
        split
        · intro hf; simp [CState.fail] at hf
        · split
          · intro _ d' hd'
            dsimp only
            rw [getElem?_setAt_ne _ _ _ _ (by omega), getElem?_mapFrom, if_pos (by omega)]
          · intro hf; simp [CState.fail] at hf
  · simp only [runO_pure]
    exact always_pure (fun hf => by simp [CState.fail] at hf)

/-! ## (c) Births at data-independent tree boundaries (Rule 3) -/

/-- The banks born at round `tr`: the outgoing banks `𝓑_d` of the depths `d = d₀, …, H − 2`, where
`d₀ = firstBorn H tr` is the shallowest depth whose dyadic lifetime starts at `tr` (Definition
`R:def:binary-tree-architecture` (1)–(2)). A function of `(P, tr)` only. -/
def bornBanks (P : StreamParams) (tr : ℕ) : List Call :=
  (List.range' (firstBorn P.H tr) (P.H - 1 - firstBorn P.H tr)).map (fun d => Call.bankNew tr d)

/-- (c1) "allocated exclusively at predetermined, data-independent physical time boundaries along a
fixed binary interval tree … (determined before round `t`'s update arrives)": the bank allocations of
round `t + 1` are a prefix of `bornBanks P (t+1)` (all of it unless the round fails in Step 1), and all
of them precede the round's fingerprint step (the first read of the update). -/
theorem roundCode_births (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) (l : List Call)
    (h : CallSeq (roundCode P c i Δ) l) :
    l.filter Call.isBankNew <+: bornBanks P (c.t + 1) ∧
    ((∃ x ∈ l, x.isFpStep = true) → l.filter Call.isBankNew = bornBanks P (c.t + 1)) ∧
    (∀ j k (hj : j < l.length) (hk : k < l.length), l[j].isBankNew = true → l[k].isFpStep = true →
      j < k) := by
  have hd0 := firstBorn_le P.H (c.t + 1)
  have hsched : ((List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1))).filter
      (fun d => decide (d + 2 ≤ P.H))).map (fun d => Call.bankNew (c.t + 1) d) =
        bornBanks P (c.t + 1) := by
    rw [range'_filter P.H _ _ (by omega)]
    unfold bornBanks
    congr 2
    omega
  rcases roundCode_split' h with rfl | ⟨c2, lb, lrest, hb, rfl, hrest, hfp⟩
  · exact ⟨by simp, fun ⟨x, hx, _⟩ => by simp at hx, fun j k hj => by simp at hj⟩
  · obtain ⟨hpre, -, heq⟩ := birthLoop_filters P _ _ _ _ _ _ hb
    have hA := early_isFpStep hb (firstBorn P.H (c.t + 1) + 1)
    have hF : (Call.note TreeEvent.newRound ::
        (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ lrest)).filter Call.isBankNew =
          lb.filter Call.isBankNew := by
      rw [List.cons_append, List.filter_cons, List.filter_cons, List.filter_append,
        filter_nil_of_forall (fun x hx => (hrest x hx).1)]
      simp [Call.isBankNew]
    refine ⟨by rw [hF, ← hsched]; exact hpre, fun ⟨x, hx, hfx⟩ => ?_, ?_⟩
    · rw [hF, ← hsched]
      apply heq
      apply hfp
      refine ⟨x, ?_, hfx⟩
      rw [← List.cons_append, List.mem_append] at hx
      rcases hx with hx | hx
      · rw [hA x hx] at hfx; exact absurd hfx Bool.false_ne_true
      · exact hx
    · exact idx_lt_of_split (A := Call.note TreeEvent.newRound ::
        Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb) (B := lrest) (by simp) hA
        (fun x hx => (hrest x hx).1)

/-- (c2) "where the outgoing vector is identically zero" (L42): a newborn bank has all counters zero
(its secondary array `Y` measures the outgoing vector `y_d = 0` of its newborn owner, and its primary
array `X` the input `x_{d+1} = y_d = 0` of its newborn first client). -/
theorem newBank_zero (P : StreamParams) :
    Always (newBank P) (fun B => (∀ blk ∈ B.ada, ∀ r ∈ blk, r.X = 0 ∧ r.Y = 0) ∧
      ∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, r.X = 0 ∧ r.Y = 0) := by
  show Always ((sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
    (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind fun coarse =>
      (adaInit (bankAda P)).bind fun st => BitProg.pure (⟨ada, coarse, st⟩ : Bank)) _
  exact @Always.bind _ _ _ _ _ (fun ada hada => @Always.bind _ _ _ _ _ (fun coarse hco =>
    @Always.bind_all _ _ _ _ (fun _ => always_pure ⟨hada, hco⟩) _) _
    (@always_sampleList _ _ _ (@always_sampleList _ _ _ (@always_sampleList _ _ _
      (@always_newRow P) 32) P.gCoarse) P.Rmax))
    _ (@always_sampleBlocks P _)

/-! ## (d) Retire before replace (Rule 3) -/

/-- (d) "expired nodes are retired before replacements are initialized" (L42): in each round the
retirement call (`bankRetain (d₀ + 1)`, with the learners truncated to `d₀` at the same point) occurs
at most once and precedes every bank allocation and every client reset of the round. -/
theorem roundCode_retire_first (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) (l : List Call)
    (h : CallSeq (roundCode P c i Δ) l) :
    (l.filter Call.isRetain).length ≤ 1 ∧
    (∀ x ∈ l, x.isRetain = true → x = Call.bankRetain (firstBorn P.H (c.t + 1) + 1)) ∧
    (∀ j k (hj : j < l.length) (hk : k < l.length), l[j].isRetain = true →
      (l[k].isBankNew || l[k].isResetY) = true → j < k) := by
  rcases roundCode_split' h with rfl | ⟨c2, lb, lrest, hb, rfl, hrest, -⟩
  · exact ⟨by simp, by simp, fun j k hj => by simp at hj⟩
  · have hbB := birthLoop_birthy P _ _ _ _ _ _ hb
    have hR : (Call.note TreeEvent.newRound ::
        (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ lrest)).filter Call.isRetain =
          [Call.bankRetain (firstBorn P.H (c.t + 1) + 1)] := by
      rw [List.cons_append, List.filter_cons, List.filter_cons, List.filter_append,
        filter_nil_of_forall (fun x hx => (hbB x hx).2.2),
        filter_nil_of_forall (fun x hx => (hrest x hx).2.1)]
      simp [Call.isRetain]
    refine ⟨by rw [hR]; simp, forall_eq_of_filter_eq_singleton hR, ?_⟩
    refine idx_lt_of_split (A := [Call.note TreeEvent.newRound,
      Call.bankRetain (firstBorn P.H (c.t + 1) + 1)]) (B := lb ++ lrest)
      (q := fun x => x.isBankNew || x.isResetY) (by simp) ?_ ?_
    · intro x hx
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl <;> rfl
    · intro x hx
      rcases List.mem_append.mp hx with hx | hx
      · exact (hbB x hx).2.2
      · exact (hrest x hx).2.1

/-! ## The client reset `resetY` is not an in-place reset of a live learner -/

/-- `resetY` realizes Definition `R:def:binary-tree-architecture` (4) "At a new client birth only its
secondary array is reset to zero" (partIII.tex L438; Algorithm 4 L475 "Retain the incoming primary
array and reset its new client-secondary array to zero"): the secondary array `Y` of `𝓑_{d−1}`
measures the outgoing vector `y_d = u_d + q_d` of the depth-`d` client, and a NEW client is born with
`u_d = q_d = 0`. It is issued only in Step 1, before the round's update is read, exactly once for each
depth `d` reborn at that round (data-independent), on its incoming bank (index `d`) — never in Steps
2–4, in particular never in a correction (b1). The forbidden "in-place reset (`u_d ← 0`)" of Rule 3
concerns a LIVE learner's iterate when an ancestor corrects; the reset depth-`d` learner here is a new
lifetime (the previous one expired and was retired first, (d)). -/
theorem roundCode_resetY (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) (l : List Call)
    (h : CallSeq (roundCode P c i Δ) l) :
    l.filter Call.isResetY <+:
      (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1))).map
        (fun d => Call.bankOp d RowOp.resetY) ∧
    (∀ j k (hj : j < l.length) (hk : k < l.length), l[j].isResetY = true → l[k].isFpStep = true →
      j < k) := by
  rcases roundCode_split' h with rfl | ⟨c2, lb, lrest, hb, rfl, hrest, -⟩
  · exact ⟨by simp, fun j k hj => by simp at hj⟩
  · obtain ⟨-, hpre, -⟩ := birthLoop_filters P _ _ _ _ _ _ hb
    have hA := early_isFpStep hb (firstBorn P.H (c.t + 1) + 1)
    have hF : (Call.note TreeEvent.newRound ::
        (Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb ++ lrest)).filter Call.isResetY =
          lb.filter Call.isResetY := by
      rw [List.cons_append, List.filter_cons, List.filter_cons, List.filter_append,
        filter_nil_of_forall (fun x hx => (hrest x hx).2.2)]
      simp [Call.isResetY]
    refine ⟨by rw [hF]; exact hpre, ?_⟩
    exact idx_lt_of_split (A := Call.note TreeEvent.newRound ::
      Call.bankRetain (firstBorn P.H (c.t + 1) + 1) :: lb) (B := lrest) (by simp) hA
      (fun x hx => (hrest x hx).2.2)

end F2e2e.C.Alg
