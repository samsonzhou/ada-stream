import Mathlib

/-!
# Exact integer/rational primitives of the Theorem C algorithm

All prescribed arithmetic of the streaming algorithm is exact rational or integer arithmetic, and
"rounded square roots are computed by integer comparisons of squares" (Definition
`R:def:dyadic-normalization`, `parts/partII.tex` L155). This file contains the primitives:

* `roundMant q z`: the mantissa of `round_h(z) = h ⌊z/h + 1/2⌋` on the dyadic grid `h = 2^{-q}`
  (Definition `R:def:dyadic-grids`, partII.tex L197: nearest multiple, half-way ties toward `+∞`);
* `gridVal q m = m 2^{-q}`;
* `sat`, `clampZ`: saturation of row counters (Def. `R:def:total-behavior`, partIII.tex L451) and the
  clamp of step coefficients (partIII.tex L455);
* `floorSqrtQ`, `ceilSqrtQ`: `⌊√r⌋`, `⌈√r⌉` of a nonnegative rational (integer square roots);
* `guardMant`: the Step-3 guard `δ_d = round_{h_g}(Ĉ_d δ̃_d)` with the `2h_g` omission rule
  (partIII.tex L488–489; partII.tex L189–193), computed by comparisons of squares;
* `stepCoeffMant`: the Step-4 multiplier `c = 1 + clamp_{[-1/2,1/2]} round_{h_step}(s (η/16) √(P/Q̂))`
  (partIII.tex L504), computed by comparisons of squares;
* `lowerMedian`: the lower median used by `ReleaseNumerical` (partIII.tex L217).

The exactness statements (that `guardMant` and `stepCoeffMant` equal the real-valued formulas of the
paper) are in `F2e2e/C/Alg/Facts.lean`.

Every definition is computable and first-order (to be mirrored by the cost-model DSL).
-/

namespace F2e2e.C.Alg

/-- The mantissa of `round_h(z) = h ⌊z/h + 1/2⌋` on the dyadic grid `h = 2^{-q}`: the integer
`⌊z 2^q + 1/2⌋` (partII.tex L197: nearest multiple, half-way ties toward `+∞`). -/
def roundMant (q : ℕ) (z : ℚ) : ℤ := ⌊z * 2 ^ q + 1 / 2⌋

/-- The value `m 2^{-q}` of the mantissa `m` on the dyadic grid `2^{-q}`. -/
def gridVal (q : ℕ) (m : ℤ) : ℚ := (m : ℚ) / 2 ^ q

/-- Rescaling a value stored on a dyadic grid by the multiplier `c = cInt 2^{-qs}` and rounding back
to the same grid: the new mantissa is `⌊c m + 1/2⌋` (for any grid `h`, `round_h(c · m h) =
h ⌊c m + 1/2⌋`). -/
def scaleMant (qs : ℕ) (cInt m : ℤ) : ℤ := roundMant 0 ((cInt : ℚ) * m / 2 ^ qs)

/-- Saturation of a counter mantissa to `[-Z, Z]` (Def. `R:def:total-behavior`, partIII.tex L451:
"Every row update is rounded to `h_b` and independently saturated to `[-Z_max, Z_max]`"). -/
def sat (Z : ℤ) (z : ℤ) : ℤ := max (-Z) (min Z z)

/-- Clamp to `[lo, hi]`. -/
def clampZ (lo hi z : ℤ) : ℤ := max lo (min hi z)

/-- `⌊√r⌋` for a rational `r ≥ 0` (`= Nat.sqrt ⌊r⌋`, since `k² ≤ r ↔ k² ≤ ⌊r⌋` for `k : ℕ`). -/
def floorSqrtQ (r : ℚ) : ℕ := Nat.sqrt ⌊r⌋.toNat

/-- `⌈√r⌉` for a rational `r ≥ 0`: the least `c : ℕ` with `r ≤ c²` (`r ≤ c² ↔ ⌈r⌉ ≤ c²`). -/
def ceilSqrtQ (r : ℚ) : ℕ :=
  let N := ⌈r⌉.toNat
  let k := Nat.sqrt N
  if k * k = N then k else k + 1

/-- The Step-3 guard mantissa on the grid `h_g` (Algorithm `R:alg:within-round-tree` lines
L488–489; committed amplitude, partII.tex L189–193):
`δ̃_d = (γ/4) √(2^{-k_d} 𝒰_{d,0})`, `δ_d = 0` if `Ĉ_d δ̃_d < 2 h_g`, else `δ_d = round_{h_g}(Ĉ_d δ̃_d)`.
With `Ĉ_d = Cint 2^{-q_C}`, `γ = 2^{-q_γ}`, `𝒰_{d,0} = 2^{u_d}`, `h_g = 2^{-q_g}`:
`y := Ĉ_d δ̃_d / h_g = Cint 2^α √(2^e)` with `α = q_g − q_C − q_γ − 2` and `e = u_d − k_d`,
so `y² = Cint² 2^{2α+e}` is rational. The guard is omitted iff `y < 2`, i.e. `y² < 4`; otherwise its
mantissa is `⌊y + 1/2⌋ = ⌊(⌊2y⌋ + 1)/2⌋` with `⌊2y⌋ = ⌊√(4y²)⌋`. (For `Cint ≥ 0`, as guaranteed
by the tag range check; see `Facts.lean` for the exactness statement.) -/
def guardMant (Cint α e : ℤ) : ℤ :=
  let y2 : ℚ := (Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e)
  if y2 < 4 then 0 else (((floorSqrtQ (4 * y2) + 1) / 2 : ℕ) : ℤ)

/-- The Step-4 multiplier mantissa on the grid `h_step = 2^{-qs}` (Algorithm
`R:alg:within-round-tree` line L504): `a_step = round_{h_step}(s (η/16) √(P/Q̂))`, clamped to
`[-1/2, 1/2]` (Def. `R:def:total-behavior`, L455), and `c = 1 + a_step`; `pos = true` iff `s = +1`
(`HIGH`, partIII.tex L800). With `w' := (η/16) √(P/Q̂) 2^{qs} ≥ 0` and
`M := 4 w'² = (P/Q̂) 2^{2qs − 2qη − 6}` (`η = 2^{-qη}`):
* `s = +1`: `⌊w' + 1/2⌋ = ⌊(⌊2w'⌋ + 1)/2⌋`, `⌊2w'⌋ = ⌊√M⌋`;
* `s = −1`: `⌊−w' + 1/2⌋ = −⌈w' − 1/2⌉ = −⌊⌈2w'⌉ / 2⌋`, `⌈2w'⌉ = ⌈√M⌉`.
The clamp bound `1/2` has mantissa `2^{qs}/2`. Requires `P > 0`, `Q̂ > 0` (positive-denominator
rule, checked by the caller). -/
def stepCoeffMant (pos : Bool) (qη qs : ℕ) (Pval Qhat : ℚ) : ℤ :=
  let M : ℚ := Pval / Qhat * (2 : ℚ) ^ (2 * (qs : ℤ) - 2 * (qη : ℤ) - 6)
  let a : ℤ := if pos then (((floorSqrtQ M + 1) / 2 : ℕ) : ℤ) else -((ceilSqrtQ M / 2 : ℕ) : ℤ)
  2 ^ qs + clampZ (-((2 ^ qs / 2 : ℕ) : ℤ)) ((2 ^ qs / 2 : ℕ) : ℤ) a

/-- The lower median of a list: the element of rank `⌊(g−1)/2⌋` (0-based) of the sorted list, i.e.
the `(g/2)`-th smallest for even `g` (Algorithm `R:alg:regularized-norm-bank` line L217:
"the lower median `c_raw` of its `g` means"). Sorting is insertion sort. -/
def lowerMedian (l : List ℚ) : ℚ := (l.insertionSort (· ≤ ·)).getD ((l.length - 1) / 2) 0

/-- Apply `f` to the entry at index `k` (no change if `k` is out of range). -/
def modifyAt {α : Type} (f : α → α) : ℕ → List α → List α
  | _, [] => []
  | 0, a :: l => f a :: l
  | k + 1, a :: l => a :: modifyAt f k l

/-- Replace the entry at index `k` by `b` (no change if `k` is out of range). -/
def setAt {α : Type} (b : α) : ℕ → List α → List α
  | _, [] => []
  | 0, _ :: l => b :: l
  | k + 1, a :: l => a :: setAt b k l

/-- Apply `f` to every entry of index `≥ k`. -/
def mapFrom {α : Type} (f : α → α) : ℕ → List α → List α
  | _, [] => []
  | 0, a :: l => f a :: mapFrom f 0 l
  | k + 1, a :: l => a :: mapFrom f k l

end F2e2e.C.Alg
