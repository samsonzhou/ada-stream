import Mathlib
import F2e2e.C.Tree.Inv

/-!
# Theorem 6.4: product-weighted sums over the ghost logs (drift witnesses)

Source: `parts/partIII.tex` Lemma `R:lem:sec6-precision` (i) (pathwise expansion `R:eq:pathwise-expansion-identity`,
L1047–1052, and its proof L1060–1066), (ii) (scale tags), (iv) (row counters), and Lemma
`R:lem:sec6-covariant-cache` (caches, exponent `2`); Theorem 5.11 (2a) (`R:eq:compound-product-factorization`): a
forward product of elementary multipliers affecting a counter, tag or cache of depth `≤ D` is a product over the
generating depths `j < D` of local interval products `P_{int,j}[a_j, t]` of their ghost logs.

Every rounded quantity of the closure (a row counter, a stored tag, a cache) has an error `e` with the one-step
recurrence `e⁺ = c e + ζ` (`c` the multiplier of an ancestor correction, `|ζ| ≤ h`). We keep the error in the
**exact** form `e = Σ_k w_k (∏_{j<D} P_{int,j}[a_{k,j}, t])^p` (`pws S D p L`, `L = [(a_k, w_k)]`): a correction of
depth `d < D` multiplies every term by `c^p` (after moving `a_{k,d}` to the current round, `pws_correct_lt`), a new
rounding error is a new term with empty window (`pws_snoc`), and the other events change nothing. The bound
`|pws| ≤ (Σ |w_k|) B̄^{Dp}` (`abs_pws_le`) is C-TREE's `prod_family_le` (Theorem 5.11 (2a)).
-/

namespace F2e2e.C.Closure

open F2e2e

variable {P : StreamParams}

/-- The window product `∏_{j<D} P_{int,j}[a_j, t]` of the ghost logs, `t` the current round. -/
noncomputable def winProd (S : Tree.TreeSt P) (D : ℕ) (a : ℕ → ℕ) : ℝ :=
  ∏ j ∈ Finset.range D, Tree.intervalProd (S.log j) (a j) S.t

/-- The product-weighted sum `Σ_{(a, w) ∈ L} w · (winProd S D a)^p`. -/
noncomputable def pws (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) : ℝ :=
  (L.map fun x => x.2 * winProd S D x.1 ^ p).sum

/-- Move the start round of depth `d` to (at most) the current round `t` (the correction of depth `d` in round
`t` enters every existing window). -/
def winShift (d t : ℕ) (L : List ((ℕ → ℕ) × ℝ)) : List ((ℕ → ℕ) × ℝ) :=
  L.map fun x => (Function.update x.1 d (min (x.1 d) t), x.2)

/-- The total weight `Σ |w_k|`. -/
noncomputable def pwsWeight (L : List ((ℕ → ℕ) × ℝ)) : ℝ := (L.map fun x => |x.2|).sum

/-- Two states with the same window products have the same weighted sums. -/
theorem pws_congr {S S' : Tree.TreeSt P} {D : ℕ} (h : ∀ a, winProd S' D a = winProd S D a) (p : ℕ)
    (L : List ((ℕ → ℕ) × ℝ)) : pws S' D p L = pws S D p L := by
  unfold pws
  congr 1
  apply List.map_congr_left
  intro x _
  rw [h x.1]

theorem pws_nil (S : Tree.TreeSt P) (D p : ℕ) : pws S D p [] = 0 := by
  simp [pws]

/-- A new term with an empty window (start round `t + 1`) contributes its weight. -/
theorem pws_snoc (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) (w : ℝ) :
    pws S D p (L ++ [(fun _ => S.t + 1, w)]) = pws S D p L + w := by
  have hw : winProd S D (fun _ => S.t + 1) = 1 := by
    unfold winProd
    apply Finset.prod_eq_one
    intro j _
    show Tree.intervalProd (S.log j) (S.t + 1) S.t = 1
    exact Tree.intervalProd_eq_one _ _ _ (fun e _ he => by omega)
  simp [pws, List.map_append, List.sum_append, hw]

theorem pwsWeight_snoc (L : List ((ℕ → ℕ) × ℝ)) (a : ℕ → ℕ) (w : ℝ) :
    pwsWeight (L ++ [(a, w)]) = pwsWeight L + |w| := by
  simp [pwsWeight, List.map_append, List.sum_append]

theorem pwsWeight_winShift (d t : ℕ) (L : List ((ℕ → ℕ) × ℝ)) : pwsWeight (winShift d t L) = pwsWeight L := by
  simp [pwsWeight, winShift, List.map_map, Function.comp_def]

theorem length_winShift (d t : ℕ) (L : List ((ℕ → ℕ) × ℝ)) : (winShift d t L).length = L.length := by
  simp [winShift]

/-- A new round: all log entries are of past rounds, so no window changes. -/
theorem pws_newRound (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ))
    (h : ∀ j < D, ∀ e ∈ S.log j, e.t ≤ S.t) :
    pws (S.step P .newRound) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_newRound_log, Tree.step_newRound_t]
  apply Finset.prod_congr rfl
  intro j hj
  exact Tree.intervalProd_of_le _ _ _ _ (Nat.le_succ _) (h j (Finset.mem_range.1 hj))

theorem pws_phys (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) (i : Fin P.n) (Δ : ℤ) :
    pws (S.step P (.phys i Δ)) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_phys_log, Tree.step_phys_t]

/-- A birth of a depth `d ≥ D` does not touch the logs of the depths `< D`. -/
theorem pws_birth (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) {d : ℕ} (hd : D ≤ d) :
    pws (S.step P (.birth d)) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_birth_t]
  apply Finset.prod_congr rfl
  intro j hj
  have hj' : j ≠ d := by have := Finset.mem_range.1 hj; omega
  rw [Tree.step_birth_log, Function.update_of_ne hj']

/-- A guard adds a pending record (multiplier `1`). -/
theorem pws_guard (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    pws (S.step P (.guard d g δ)) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_guard_t]
  apply Finset.prod_congr rfl
  intro j _
  rw [Tree.step_guard_log]
  by_cases hj : j = d
  · rw [hj, Function.update_self, Tree.intervalProd_cons]
    have : (Tree.Outcome.pending).mult = 1 := rfl
    simp [this]
  · rw [Function.update_of_ne hj]

/-- `ACCEPT` turns a pending record (multiplier `1`) into an accepted one (multiplier `1`). -/
theorem pws_accept (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) (d : ℕ)
    (hhead : ∀ e ∈ (S.log d).head?, e.out = .pending) :
    pws (S.step P (.accept d)) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_accept_t]
  apply Finset.prod_congr rfl
  intro j _
  apply Tree.intervalProd_congr
  rw [Tree.step_accept_log]
  by_cases hj : j = d
  · rw [hj, Function.update_self]
    rcases hl : S.log d with _ | ⟨e, l⟩
    · rfl
    · have he : e.out = .pending := hhead e (by rw [hl]; rfl)
      simp [Tree.TreeState.setHead, he, Tree.Outcome.mult]
  · rw [Function.update_of_ne hj]

/-- A correction of a depth `d ≥ D` does not touch the logs of the depths `< D`. -/
theorem pws_correct_ge (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) {d : ℕ} (hd : D ≤ d) (c : ℝ) :
    pws (S.step P (.correct d c)) D p L = pws S D p L := by
  apply pws_congr _ p L
  intro a
  unfold winProd
  simp only [Tree.step_correct_t]
  apply Finset.prod_congr rfl
  intro j hj
  have hj' : j ≠ d := by have := Finset.mem_range.1 hj; omega
  rw [Tree.log_correct_ne c hj']

/-- The window product after a correction of depth `d < D` (current record pending of the current round, older
records of past rounds), on the shifted window: multiplied by `c`. -/
theorem winProd_correct_lt (S : Tree.TreeSt P) {D d : ℕ} (hd : d < D) (c : ℝ)
    {e : Tree.LogEntry} {l : List Tree.LogEntry} (hlog : S.log d = e :: l) (het : e.t = S.t)
    (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < S.t) (a : ℕ → ℕ) :
    winProd (S.step P (.correct d c)) D (Function.update a d (min (a d) S.t)) = c * winProd S D a := by
  unfold winProd
  simp only [Tree.step_correct_t]
  apply Tree.prod_range_mul_at hd
  · rw [Function.update_self, Tree.log_correct_eq hlog c, Tree.intervalProd_correct_head e l hpend c,
      if_pos ⟨by rw [het]; exact min_le_right _ _, le_of_eq het⟩, hlog]
    congr 1
    rcases le_or_gt (a d) S.t with had | had
    · rw [min_eq_left had]
    · rw [min_eq_right had.le]
      have h1 : Tree.intervalProd (e :: l) S.t S.t = 1 := Tree.intervalProd_head_pending het hpend hl
      have h2 : Tree.intervalProd (e :: l) (a d) S.t = 1 :=
        Tree.intervalProd_eq_one _ _ _ (fun e' _ he' => by omega)
      rw [h1, h2]
  · intro i hi
    rw [Function.update_of_ne hi, Tree.log_correct_ne c hi]

/-- A correction of a depth `d < D` with multiplier `c`, whose current record is the pending record of the
current round (the older ones are of past rounds), multiplies every window product by `c` (after
`winShift d t`). -/
theorem pws_correct_lt (S : Tree.TreeSt P) (D p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) {d : ℕ} (hd : d < D) (c : ℝ)
    {e : Tree.LogEntry} {l : List Tree.LogEntry} (hlog : S.log d = e :: l) (het : e.t = S.t)
    (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < S.t) :
    pws (S.step P (.correct d c)) D p (winShift d S.t L) = c ^ p * pws S D p L := by
  unfold pws winShift
  rw [List.map_map, ← List.sum_map_mul_left]
  congr 1
  apply List.map_congr_left
  intro x _
  simp only [Function.comp_apply]
  rw [winProd_correct_lt S hd c hlog het hpend hl x.1, mul_pow]
  ring

/-- The window products are positive and at most `B̄^D` (for `D` live depths). -/
theorem winProd_pos_le {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (h : Tree.TreeInv P ph R S) {D : ℕ}
    (hD : D ≤ ph.live P.H) (a : ℕ → ℕ) : 0 < winProd S D a ∧ winProd S D a ≤ Tree.Bbar P ^ D :=
  Tree.prod_family_le h hD a (fun _ => S.t)

/-- **The bound** (Theorem 5.11 (2a), C-TREE's `prod_family_le`): under the tree invariant, for `D` live depths,
every window product is in `(0, B̄^D]`, hence `|pws| ≤ (Σ |w_k|) B̄^{Dp}`. -/
theorem abs_pws_le {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (h : Tree.TreeInv P ph R S) {D : ℕ}
    (hD : D ≤ ph.live P.H) (p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) :
    |pws S D p L| ≤ pwsWeight L * Tree.Bbar P ^ (D * p) := by
  induction L with
  | nil => simp [pws, pwsWeight]
  | cons x L ih =>
    have hx := winProd_pos_le h hD x.1
    have hpow : winProd S D x.1 ^ p ≤ Tree.Bbar P ^ (D * p) := by
      rw [pow_mul]
      exact pow_le_pow_left₀ hx.1.le hx.2 p
    have hpow0 : 0 ≤ winProd S D x.1 ^ p := pow_nonneg hx.1.le p
    have e1 : pws S D p (x :: L) = x.2 * winProd S D x.1 ^ p + pws S D p L := by
      simp [pws]
    have e2 : pwsWeight (x :: L) = |x.2| + pwsWeight L := by
      simp [pwsWeight]
    rw [e1, e2]
    calc |x.2 * winProd S D x.1 ^ p + pws S D p L|
        ≤ |x.2 * winProd S D x.1 ^ p| + |pws S D p L| := abs_add_le _ _
      _ = |x.2| * winProd S D x.1 ^ p + |pws S D p L| := by rw [abs_mul, abs_of_nonneg hpow0]
      _ ≤ |x.2| * Tree.Bbar P ^ (D * p) + pwsWeight L * Tree.Bbar P ^ (D * p) := by
          gcongr
      _ = (|x.2| + pwsWeight L) * Tree.Bbar P ^ (D * p) := by ring

/-- The total weight of a list with `≤ n` terms of weight `≤ hw` (`hw ≥ 0`). -/
theorem pwsWeight_le (L : List ((ℕ → ℕ) × ℝ)) {n : ℕ} {hw : ℝ} (hw0 : 0 ≤ hw) (hlen : L.length ≤ n)
    (hwt : ∀ x ∈ L, |x.2| ≤ hw) : pwsWeight L ≤ n * hw := by
  induction L generalizing n with
  | nil => simp [pwsWeight]; positivity
  | cons x L ih =>
    obtain ⟨n', rfl⟩ : ∃ n', n = n' + 1 := ⟨n - 1, by simp at hlen; omega⟩
    have h1 := ih (n := n') (by simp at hlen; omega) (fun y hy => hwt y (List.mem_cons_of_mem _ hy))
    have h2 := hwt x List.mem_cons_self
    have e2 : pwsWeight (x :: L) = |x.2| + pwsWeight L := by simp [pwsWeight]
    rw [e2]
    push_cast
    linarith

/-- A weighted sum with weights `≤ h` (`h ≥ 0`) and at most `n` terms: `|pws| ≤ n h G^p` for `D ≤ H + 1` live
depths. -/
theorem abs_pws_le_G {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (h : Tree.TreeInv P ph R S) {D : ℕ}
    (hD : D ≤ ph.live P.H) (hDH : D ≤ P.H + 1) (p : ℕ) (L : List ((ℕ → ℕ) × ℝ)) {n : ℕ} {hw : ℝ}
    (hw0 : 0 ≤ hw) (hlen : L.length ≤ n) (hwt : ∀ x ∈ L, |x.2| ≤ hw) :
    |pws S D p L| ≤ n * hw * (P.G : ℝ) ^ p := by
  have h1 := abs_pws_le h hD p L
  have h2 := pwsWeight_le L hw0 hlen hwt
  have hB1 := Tree.one_le_Bbar P
  have h3 : Tree.Bbar P ^ (D * p) ≤ (P.G : ℝ) ^ p := by
    rw [pow_mul]
    exact pow_le_pow_left₀ (pow_nonneg (by linarith) D) (Tree.Bbar_pow_le_G P hDH) p
  have hW0 : 0 ≤ pwsWeight L := by
    unfold pwsWeight
    exact List.sum_nonneg (fun y hy => by
      obtain ⟨x, _, rfl⟩ := List.mem_map.1 hy
      exact abs_nonneg _)
  have hBp0 : 0 ≤ Tree.Bbar P ^ (D * p) := pow_nonneg (by linarith) _
  calc |pws S D p L| ≤ pwsWeight L * Tree.Bbar P ^ (D * p) := h1
    _ ≤ (n * hw) * (P.G : ℝ) ^ p := mul_le_mul h2 h3 hBp0 (by positivity)
    _ = n * hw * (P.G : ℝ) ^ p := by ring

end F2e2e.C.Closure
