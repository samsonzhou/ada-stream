import Mathlib
import F2e2e.C.Alg.Bank
import F2e2e.Lib.Hash.Rademacher
import F2e2e.Lib.FinProb.AMS
import F2e2e.Lib.FinProb.Sandwich

/-!
# Regularized Norm Bank: definitions (Definition 4.5, Algorithm 3)

Source: `parts/partIII.tex` Definition `R:def:regularized-norm-bank` (L164–193) and Algorithm
`R:alg:regularized-norm-bank` (L201–223). The algorithm itself is C-ALG's (`F2e2e/C/Alg/Bank.lean`:
`Row`, `Bank`, `regZ`, `queryIdx`, `Bank.validate`, `Bank.release`, `newBank`); this file gives the
real-valued analysis objects of Definition 4.5 and links them to C-ALG's exact rational ones.

Conventions (agreed with C-CLOSE / C-TREE).
* Vectors live in `EuclideanSpace ℝ (Fin P.Dstar)`; Lean index `i` is the paper's coordinate `i + 1`,
  the regularizer coordinate `D_*` is `regIdx P = Fin.last` (index `D_* − 1`). Shadow vectors vanish on
  it, and the augmented vector is `v⁺ = aug P σ v = v + σ e_{D_*}` (so `‖v⁺‖² = ‖v‖² + σ²` when
  `v (regIdx P) = 0`, `norm_sq_aug`).
* Rows: a seed is `ζ : Seed P = Fin (2s) → Fin (2^w)` (`w = ⌈log₂(D_*+1)⌉`, Lemma
  `R:lem:2s-moment-bound`), its signs are `sgn P ζ : Fin D_* → ℝ` (LIB-HASH's `rademacher s D_*`);
  C-ALG stores the seed as the list `Hash.seedCoeffs ζ`, and `sgn P ζ i` is C-ALG's
  `rowSign P r (i + 1)` (`rowSign_seedCoeffs`).
* The law `𝒟` of one row is the uniform distribution `unifD P` on seeds; population means
  `popMean (unifD P) f` are uniform averages `E f` (`popMean_unifD`).
* Counter values of a row are reals `X ζ` (C-ALG mantissa times `h_b`, in the evaluation mode);
  the rowwise query is `f̂_c(ζ) = round_{h_A}(min{(X ζ + b_{D_*}(ζ) σ)²/(Lc), 1})` (`fhatQ`,
  partIII.tex L212), equal to C-ALG's `queryIdx`/`2^{qA}` (`queryIdx_regZ_eq_fhatQ`).
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb Finset

/-! ## Coordinates -/

/-- `D_* - 1 = n + T`: the number of physical and guard coordinates (partIII.tex L170). -/
def Dm (P : StreamParams) : ℕ := P.n + P.T

theorem Dstar_eq (P : StreamParams) : P.Dstar = Dm P + 1 := rfl

/-- The regularizer coordinate `D_*` of the paper (Lean index `D_* − 1`, partIII.tex L172). -/
def regIdx (P : StreamParams) : Fin P.Dstar := Fin.last (Dm P)

theorem regIdx_val (P : StreamParams) : (regIdx P : ℕ) = P.Dstar - 1 := by
  simp [regIdx, Dstar_eq]

/-! ## Rows and their signs -/

/-- Seeds of the bank's rows: `2s` elements of `𝔽_{2^w}`, `w = ⌈log₂(D_*+1)⌉` (Lemma
`R:lem:2s-moment-bound` with `D = D_*`; Algorithm `R:alg:regularized-norm-bank` L207). -/
abbrev Seed (P : StreamParams) : Type := Hash.RadSeed (Hash.seedDeg P.Dstar) P.s

/-- The signs `b(ζ) ∈ {±1}^{D_*}` of the row with seed `ζ` (eq. `R:eq:rademacher-seed-poly`). -/
noncomputable def sgn (P : StreamParams) (ζ : Seed P) (i : Fin P.Dstar) : ℝ :=
  Hash.rademacher P.s P.Dstar ζ i

/-- The field degree of the rows is C-ALG's `w`. -/
theorem seedDeg_Dstar (P : StreamParams) : Hash.seedDeg P.Dstar = P.w := rfl

/-- The law `𝒟` of one row: the uniform distribution on seeds. -/
noncomputable def unifD (P : StreamParams) (_ζ : Seed P) : ℝ := 1 / (Fintype.card (Seed P) : ℝ)

/-! ## Vectors, linear forms, scales (Definition 4.5 (1)–(3)) -/

/-- The augmented vector `v⁺ = v + σ e_{D_*}` (eq. `R:eq:Fprime-def`). -/
noncomputable def aug (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) :
    EuclideanSpace ℝ (Fin P.Dstar) :=
  v + σ • EuclideanSpace.single (regIdx P) (1 : ℝ)

/-- The exact linear form `Z_v(ζ) = ⟨b(ζ), v⁺⟩` of the row with seed `ζ` (eq. `R:eq:ideal-Z-and-f`);
for a shadow `v` it is `⟨b(ζ)_{1:D_*-1}, v⟩ + b_{D_*}(ζ) σ` (`Zlin_eq`). -/
noncomputable def Zlin (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar))
    (ζ : Seed P) : ℝ :=
  ∑ i, sgn P ζ i * aug P σ v i

/-- The ideal clipped query `f_{v,c}(ζ) = min{Z_v(ζ)²/(Lc), 1}` (eq. `R:eq:ideal-Z-and-f`). -/
noncomputable def fIdeal (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) (c : ℝ)
    (ζ : Seed P) : ℝ :=
  min (Zlin P σ v ζ ^ 2 / ((P.L : ℝ) * c)) 1

/-! ## Counters and rounded queries (Definition 4.5 (4), Algorithm 3 L208–L212) -/

/-- `round_{h_A}(u) = h_A ⌊u/h_A + 1/2⌋` for `h_A = 2^{-qA}` (Definition `R:def:dyadic-grids`,
partII.tex L197: nearest grid point, ties toward `+∞`). -/
noncomputable def roundH (qA : ℕ) (u : ℝ) : ℝ := (⌊u * 2 ^ qA + 1 / 2⌋ : ℝ) / 2 ^ qA

/-- The rowwise query of a bank whose (mode) counter values are `X`:
`f̂_c(ζ) = round_{h_A}(min{(X ζ + b_{D_*}(ζ) σ)²/(Lc), 1})` (partIII.tex L212,
eq. `R:eq:unscaled-regularizer-counter`; `σ = P.sigma`, the regularizer added unscaled). -/
noncomputable def fhatQ (P : StreamParams) (qA : ℕ) (X : Seed P → ℝ) (c : ℝ) (ζ : Seed P) : ℝ :=
  roundH qA (min ((X ζ + sgn P ζ (regIdx P) * (P.sigma : ℝ)) ^ 2 / ((P.L : ℝ) * c)) 1)

/-! ## Basic facts -/

/-! ### Parameter facts used throughout -/

theorem L_pos (P : StreamParams) : (0 : ℝ) < P.L := by
  have : 0 < P.L := by unfold StreamParams.L StreamParams.s; omega
  exact_mod_cast this

theorem L_eq (P : StreamParams) : (P.L : ℝ) = 16 * (P.s : ℝ) := by
  unfold StreamParams.L; push_cast; ring

/-- `L ≥ 64` (partIII.tex L167; in fact `L = 16(log₂(1/η) + 22) ≥ 352`). -/
theorem sixtyfour_le_L (P : StreamParams) : (64 : ℝ) ≤ P.L := by
  have : 64 ≤ P.L := by unfold StreamParams.L StreamParams.s; omega
  exact_mod_cast this

theorem s_eq (P : StreamParams) : (P.s : ℝ) = (P.eEta : ℝ) + 22 := by
  unfold StreamParams.s; push_cast; ring

theorem eta_eq (P : StreamParams) : (P.eta : ℝ) = (1 / 2 : ℝ) ^ P.eEta := by
  unfold StreamParams.eta; push_cast; ring

theorem eta_pos (P : StreamParams) : (0 : ℝ) < P.eta := by
  rw [eta_eq]; positivity

theorem eta_le_one (P : StreamParams) : (P.eta : ℝ) ≤ 1 := by
  rw [eta_eq]; exact pow_le_one₀ (by norm_num) (by norm_num)

theorem four_le_two_s (P : StreamParams) : 4 ≤ 2 * P.s := by
  unfold StreamParams.s; omega

theorem sigma_pos (P : StreamParams) : (0 : ℝ) < P.sigma := by
  unfold StreamParams.sigma; push_cast; positivity

theorem omega_eq (P : StreamParams) : (P.omega : ℝ) = (P.sigma : ℝ) ^ 2 := by
  unfold StreamParams.omega; push_cast; ring

theorem omega_pos (P : StreamParams) : (0 : ℝ) < P.omega := by
  rw [omega_eq]; exact pow_pos (sigma_pos P) 2

theorem aNum_eq (P : StreamParams) : (P.aNum : ℝ) = (P.eta : ℝ) / (2 ^ 14 * P.L) := by
  unfold StreamParams.aNum; push_cast; ring

theorem hb_pos (P : StreamParams) : (0 : ℝ) < P.hb := by
  unfold StreamParams.hb; push_cast; positivity


theorem sgn_eq_or (P : StreamParams) (ζ : Seed P) (i : Fin P.Dstar) :
    sgn P ζ i = 1 ∨ sgn P ζ i = -1 := by
  unfold sgn Hash.rademacher Hash.radSign
  exact bitSign_eq_or _

/-- The bank's rows are `2s`-wise independent signs (Lemma `R:lem:2s-moment-bound` (i)). -/
theorem sgn_isKWiseSigns (P : StreamParams) : IsKWiseSigns (2 * P.s) (sgn P) :=
  Hash.rademacher_isKWiseSigns (by unfold StreamParams.Dstar; omega)

theorem aug_apply (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) (i : Fin P.Dstar) :
    aug P σ v i = v i + if i = regIdx P then σ else 0 := by
  simp [aug]

/-- `Z_v(ζ) = ⟨b(ζ), v⟩ + b_{D_*}(ζ) σ`; for a shadow (`v_{D_*} = 0`) the first term is
`⟨b(ζ)_{1:D_*-1}, v⟩`. -/
theorem Zlin_eq (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) (ζ : Seed P) :
    Zlin P σ v ζ = ∑ i, sgn P ζ i * v i + sgn P ζ (regIdx P) * σ := by
  unfold Zlin
  simp only [aug_apply, mul_add, Finset.sum_add_distrib, mul_ite, mul_zero, Finset.sum_ite_eq',
    Finset.mem_univ, if_true]

/-- `‖v⁺‖² = ‖v‖² + σ²` for a shadow vector (`v_{D_*} = 0`). -/
theorem norm_sq_aug (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar))
    (hv : v (regIdx P) = 0) : ‖aug P σ v‖ ^ 2 = ‖v‖ ^ 2 + σ ^ 2 := by
  rw [EuclideanSpace.real_norm_sq_eq, EuclideanSpace.real_norm_sq_eq]
  have h : ∀ i, aug P σ v i ^ 2 = v i ^ 2 + if i = regIdx P then σ ^ 2 else 0 := by
    intro i
    rw [aug_apply]
    split_ifs with hi
    · subst hi; rw [hv]; ring
    · ring
  simp only [h, Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_univ, if_true]

/-- `‖w‖² = ∑ᵢ wᵢ²` (the form used by LIB-HASH-AMS). -/
theorem norm_sq_eq_sum (P : StreamParams) (w : EuclideanSpace ℝ (Fin P.Dstar)) :
    ‖w‖ ^ 2 = ∑ i, w i ^ 2 :=
  EuclideanSpace.real_norm_sq_eq w

/-- The exact row values of a coarse group (LIB-HASH's `rowVals`) are the linear forms `Z_v`. -/
theorem rowVals_aug (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) {g m : ℕ}
    (G : Fin g → Fin m → Seed P) (j : Fin g) (l : Fin m) :
    rowVals (sgn P) (aug P σ v) G j l = Zlin P σ v (G j l) := rfl

theorem unifD_nonneg (P : StreamParams) (ζ : Seed P) : 0 ≤ unifD P ζ := by
  unfold unifD; positivity

theorem sum_unifD (P : StreamParams) : ∑ ζ, unifD P ζ = 1 := by
  unfold unifD
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have h : (Fintype.card (Seed P) : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  field_simp

/-- Population means under the row law are uniform averages. -/
theorem popMean_unifD (P : StreamParams) (f : Seed P → ℝ) : popMean (unifD P) f = E f := by
  unfold popMean unifD
  rw [E_def, Finset.sum_div]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  ring

/-- The rounding error `|round_{h_A}(u) − u| ≤ h_A/2`. -/
theorem abs_roundH_sub_le (qA : ℕ) (u : ℝ) : |roundH qA u - u| ≤ (1 / 2 : ℝ) ^ qA / 2 := by
  unfold roundH
  have h1 := Int.floor_le (u * 2 ^ qA + 1 / 2)
  have h2 := Int.lt_floor_add_one (u * 2 ^ qA + 1 / 2)
  have hpos : (0 : ℝ) < 2 ^ qA := by positivity
  have e : (⌊u * 2 ^ qA + 1 / 2⌋ : ℝ) / 2 ^ qA - u =
      ((⌊u * 2 ^ qA + 1 / 2⌋ : ℝ) - u * 2 ^ qA) / 2 ^ qA := by
    field_simp
  rw [e, abs_div, abs_of_pos hpos, div_le_iff₀ hpos]
  have e2 : (1 / 2 : ℝ) ^ qA / 2 * 2 ^ qA = 1 / 2 := by
    rw [one_div, inv_pow]; field_simp
  rw [e2, abs_le]
  constructor <;> linarith

/-- The query values lie in `[0, 1]` (`round_{h_A}` maps `[0, 1]` into itself, `h_A` dyadic). -/
theorem fhatQ_mem_Icc (P : StreamParams) (qA : ℕ) (X : Seed P → ℝ) {c : ℝ} (hc : 0 ≤ c)
    (ζ : Seed P) : 0 ≤ fhatQ P qA X c ζ ∧ fhatQ P qA X c ζ ≤ 1 := by
  unfold fhatQ roundH
  set W := min ((X ζ + sgn P ζ (regIdx P) * (P.sigma : ℝ)) ^ 2 / ((P.L : ℝ) * c)) 1 with hWdef
  have hW0 : 0 ≤ W := le_min (div_nonneg (sq_nonneg _) (mul_nonneg (Nat.cast_nonneg _) hc))
    zero_le_one
  have hW1 : W ≤ 1 := min_le_right _ _
  have hpos : (0 : ℝ) < 2 ^ qA := by positivity
  constructor
  · apply div_nonneg _ hpos.le
    have : (0 : ℤ) ≤ ⌊W * 2 ^ qA + 1 / 2⌋ := Int.floor_nonneg.mpr (by positivity)
    exact_mod_cast this
  · rw [div_le_one hpos]
    have : ⌊W * 2 ^ qA + 1 / 2⌋ ≤ (2 ^ qA : ℤ) := by
      rw [Int.floor_le_iff]
      push_cast
      nlinarith
    exact_mod_cast this

/-! ## Link to C-ALG's exact rational evaluation -/

/-- The C-ALG row carrying the seed `ζ` and the counter mantissas `c = (X, Y)`. -/
def rowOf {P : StreamParams} (ζ : Seed P) (c : ℤ × ℤ) : Alg.Row := ⟨Hash.seedCoeffs ζ, c.1, c.2⟩

/-- The counter mantissa of a row in an evaluation mode: `X` (`PRIMARY`) or `X − Y` (`DIFF`)
(partIII.tex L208). -/
def modeCnt : Alg.Mode → ℤ × ℤ → ℤ
  | Alg.Mode.primary, c => c.1
  | Alg.Mode.diff, c => c.1 - c.2

/-- The real counter value `(mode counter) · h_b` of the rows whose mantissas are `ctr`. -/
noncomputable def cntVal (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) (ζ : Seed P) :
    ℝ :=
  (modeCnt mode (ctr ζ) : ℝ) * (P.hb : ℝ)

theorem rowOf_seed {P : StreamParams} (ζ : Seed P) (c : ℤ × ℤ) :
    (rowOf ζ c).seed = Hash.seedCoeffs ζ := by
  simp only [rowOf]

theorem rowOf_X {P : StreamParams} (ζ : Seed P) (c : ℤ × ℤ) : (rowOf ζ c).X = c.1 := by
  simp only [rowOf]

theorem rowOf_Y {P : StreamParams} (ζ : Seed P) (c : ℤ × ℤ) : (rowOf ζ c).Y = c.2 := by
  simp only [rowOf]

/-- C-ALG's sign of coordinate `i + 1` of a row is `sgn` at index `i`. -/
theorem rowSign_seedCoeffs (P : StreamParams) (ζ : Seed P) (c : ℤ × ℤ) (i : Fin P.Dstar) :
    ((Alg.rowSign P (rowOf ζ c) (i.val + 1) : ℤ) : ℝ) = sgn P ζ i := by
  simp only [Alg.rowSign, Alg.irrW, rowOf_seed, sgn, Hash.rademacher, Hash.radSign, Hash.radBit,
    Hash.radBitAt, Hash.radPoint, seedDeg_Dstar]
  split_ifs with h
  · rw [h]; simp [bitSign]
  · rw [Bool.not_eq_true] at h; rw [h]; simp [bitSign]

/-- C-ALG's regularized counter `regZ` (partIII.tex L208) is `X ζ + b_{D_*}(ζ) σ`. -/
theorem regZ_rowOf (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) (ζ : Seed P) :
    ((Alg.regZ P mode (rowOf ζ (ctr ζ)) : ℚ) : ℝ) =
      cntVal P mode ctr ζ + sgn P ζ (regIdx P) * (P.sigma : ℝ) := by
  have hs : ((Alg.rowSign P (rowOf ζ (ctr ζ)) P.Dstar : ℤ) : ℝ) = sgn P ζ (regIdx P) :=
    rowSign_seedCoeffs P ζ (ctr ζ) (regIdx P)
  have h2 : (2 : ℝ) ^ P.eHb ≠ 0 := by positivity
  cases mode <;>
  · simp only [Alg.regZ, Alg.gridVal, cntVal, modeCnt, rowOf_X, rowOf_Y, StreamParams.hb]
    push_cast
    rw [hs, one_div_pow, div_eq_mul_one_div]

/-- C-ALG's query grid index of a row, divided by `2^{qA}`, is the rowwise query `f̂_c`. -/
theorem queryIdx_regZ_eq_fhatQ (P : StreamParams) (qA : ℕ) (mode : Alg.Mode)
    (ctr : Seed P → ℤ × ℤ) {c : ℚ} (hc : 0 < c) (ζ : Seed P) :
    ((Alg.queryIdx qA P.L c (Alg.regZ P mode (rowOf ζ (ctr ζ))) : ℕ) : ℝ) / 2 ^ qA =
      fhatQ P qA (cntVal P mode ctr) (c : ℝ) ζ := by
  have hzr := regZ_rowOf P mode ctr ζ
  unfold fhatQ
  rw [← hzr]
  have hLq : (0 : ℚ) < P.L := by
    exact_mod_cast (show 0 < P.L by unfold StreamParams.L StreamParams.s; omega)
  have hρ0 : 0 ≤ Alg.regZ P mode (rowOf ζ (ctr ζ)) ^ 2 / ((P.L : ℚ) * c) := by positivity
  have hρr : ((Alg.regZ P mode (rowOf ζ (ctr ζ)) : ℚ) : ℝ) ^ 2 / ((P.L : ℝ) * (c : ℝ)) =
      ((Alg.regZ P mode (rowOf ζ (ctr ζ)) ^ 2 / ((P.L : ℚ) * c) : ℚ) : ℝ) := by
    push_cast; ring
  rw [hρr]
  simp only [Alg.queryIdx]
  generalize Alg.regZ P mode (rowOf ζ (ctr ζ)) ^ 2 / ((P.L : ℚ) * c) = ρ at hρ0 ⊢
  have hpos : (0 : ℝ) < 2 ^ qA := by positivity
  split_ifs with h1
  · have h1' : (1 : ℝ) ≤ (ρ : ℝ) := by exact_mod_cast h1
    rw [min_eq_right h1']
    unfold roundH
    have hf : ⌊(1 : ℝ) * 2 ^ qA + 1 / 2⌋ = ((2 ^ qA : ℕ) : ℤ) := by
      rw [Int.floor_eq_iff]; push_cast; constructor <;> linarith
    rw [hf]
    push_cast
    rfl
  · rw [not_le] at h1
    have h1' : (ρ : ℝ) < 1 := by exact_mod_cast h1
    rw [min_eq_left h1'.le]
    unfold roundH Alg.roundMant
    have hfl : 0 ≤ ⌊ρ * 2 ^ qA + 1 / 2⌋ := Int.floor_nonneg.mpr (by positivity)
    have hcast : (((⌊ρ * 2 ^ qA + 1 / 2⌋).toNat : ℕ) : ℝ) = ((⌊ρ * 2 ^ qA + 1 / 2⌋ : ℤ) : ℝ) := by
      rw [← Int.cast_natCast, Int.toNat_of_nonneg hfl]
    have hfl2 : ⌊(ρ : ℝ) * 2 ^ qA + 1 / 2⌋ = ⌊ρ * 2 ^ qA + 1 / 2⌋ := by
      rw [← Rat.floor_cast (α := ℝ)]
      push_cast
      rfl
    rw [hcast, hfl2]

/-- C-ALG's coarse scale (`Bank.release`, partIII.tex L217): for a coarse group whose rows carry the
seeds `G j l` and mantissas `ctr`, `c = max(lowerMedian of the g subgroup means of Ẑ², ω/2)` is the
real `max(coarseEst Ẑ, ω/2)`. -/
theorem release_scale_eq (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) {g : ℕ}
    (G : Fin g → Fin 32 → Seed P) :
    (((max (Alg.lowerMedian ((List.ofFn fun j => List.ofFn fun l => rowOf (G j l) (ctr (G j l))).map
        (Alg.subgroupMean P mode))) (P.omega / 2) : ℚ)) : ℝ) =
      max (coarseEst fun j l => cntVal P mode ctr (G j l) + sgn P (G j l) (regIdx P) * P.sigma)
        ((P.omega : ℝ) / 2) := by
  set y : Fin g → ℚ := fun j => (∑ l, Alg.regZ P mode (rowOf (G j l) (ctr (G j l))) ^ 2) / 32
    with hy
  have hlist : (List.ofFn fun j => List.ofFn fun l => rowOf (G j l) (ctr (G j l))).map
      (Alg.subgroupMean P mode) = List.ofFn y := by
    rw [List.map_ofFn]
    congr 1
  have hmed : Alg.lowerMedian (List.ofFn y) = FinProb.lowerMedian y := by
    unfold Alg.lowerMedian FinProb.lowerMedian FinProb.orderStat
    rw [List.length_ofFn]
    rfl
  have hcast : ((FinProb.lowerMedian y : ℚ) : ℝ) = FinProb.lowerMedian (fun j => (y j : ℝ)) := by
    rcases Nat.eq_zero_or_pos g with hg | hg
    · subst hg
      simp only [FinProb.lowerMedian, FinProb.orderStat]
      have h1 : (default : ℚ) = 0 := rfl
      have h2 : (default : ℝ) = 0 := rfl
      simp [h1, h2]
    · exact (lowerMedian_comp_of_monotone Rat.cast_mono y hg).symm
  have hy' : (fun j => (y j : ℝ)) = fun j =>
      groupMean (fun l => cntVal P mode ctr (G j l) + sgn P (G j l) (regIdx P) * P.sigma) := by
    funext j
    simp only [hy, groupMean]
    push_cast
    simp only [regZ_rowOf]
  rw [hlist, hmed, Rat.cast_max, hcast, hy']
  unfold coarseEst
  push_cast
  rfl

end F2e2e.C.NormBank
