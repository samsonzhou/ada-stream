import F2e2e.C.NormBank.Defs

/-!
# Lemma 4.8: uniform shadow-counter perturbation (primary and `2ξ`-difference counters)

Source: `parts/partIII.tex` Lemma `R:lem:shadow-counter-perturbation` (L275–310, proof L312–343).
Purely deterministic real inequalities for one row `b ∈ {±1}^{D_*}` (a sign vector `Fin D_* → ℝ`).

Notation (Definition 4.5): for a target `w` (a shadow vector, `w_{D_*} = 0` in applications; not needed
here) the exact linear form of the row is `Z_w(b) = ⟨b, w⁺⟩` (`Zrow`, `w⁺ = aug P σ w`), and a counter
value `z_t` (tracking `⟨b, w⟩`) is evaluated as `ẑ(b) = z_t + b_{D_*} σ` (`zrow`, the unscaled
regularizer). `σ = P.sigma`, `ω = σ² = P.omega`, `η = P.eta`, `L = P.L = 16s`, `a_num = η/(2^14 L)`.
The ADA's rounding of query values is a hypothesis `|f̂ − min{ẑ²/(Lc), 1}| ≤ h_A` (for C-ALG's
`queryIdx` with `h_A = 2^{-qA}` it is `abs_roundH_sub_le`).

* `abs_Zrow_le` (eq. `R:eq:Z-cauchy-schwarz-bound`): `|Z_w(b)| ≤ √D_* ‖w⁺‖`;
* (i) `primary_perturbation`: drift `≤ ξ` ⇒ `|ẑ − Z| ≤ ξ` and `|f̂ − f| ≤ |ẑ² − Z²|/(Lc) + h_A ≤
  (2√D_*Vξ + ξ²)/(Lω) + h_A ≤ η/(2^29 L) = 2^{-15} a_num` for every `c ≥ ω`
  (eq. `R:eq:primary-counter-perturbation`);
* (ii) `diff_perturbation`: drifts `≤ ξ` of the parent and client counters ⇒ difference-counter drift
  `≤ 2ξ` (eq. `R:eq:diff-counter-linear-drift`), the quadratic bound `η/(2^28 L) = 2^{-14} a_num`
  (eq. `R:eq:diff-counter-quadratic-perturbation`), `|f̂ − f| ≤ η/(2^28 L) + h_A ≤ η/(2^27 L)`
  (eq. `R:eq:diff-counter-total-perturbation`) for `c ≥ ω`, and `≤ η/(2^26 L)` for `c ≥ ω/2`;
  `two_xi_perturbation` is the same for a counter given directly with drift `≤ 2ξ`;
* (iii) `coarse_perturbation`: for coarse rows with drift `≤ 2ξ`, `|ẑ² − Z²| ≤ 4√D_*Vξ + 4ξ² ≤
  (η/2^28) ω ≤ 2^{-28} F' < F'/16` (eq. `R:eq:coarse-row-perturbation`), and the perturbed coarse
  median lies in `[F'/2, 3F'/2]` whenever the exact one lies in `[9F'/16, 23F'/16]`
  (eq. `R:eq:coarse-perturbed-enclosure`; lower medians, LIB-HASH-AMS's `coarseEst`).
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb Finset

/-- The exact linear form `Z_w(b) = ⟨b, w⁺⟩` of a sign vector `b` (eq. `R:eq:ideal-Z-and-f`). -/
noncomputable def Zrow (P : StreamParams) (b : Fin P.Dstar → ℝ) (σ : ℝ)
    (w : EuclideanSpace ℝ (Fin P.Dstar)) : ℝ :=
  ∑ i, b i * aug P σ w i

/-- The unscaled regularizer evaluation `ẑ(b) = z_t + b_{D_*} σ` of a counter value `z_t`
(eq. `R:eq:unscaled-regularizer-counter`). -/
def zrow (P : StreamParams) (b : Fin P.Dstar → ℝ) (σ zt : ℝ) : ℝ := zt + b (regIdx P) * σ

/-- The left side `2√D_* V ξ + ξ²` of the precision condition (eq. `R:eq:xi-precision-condition`). -/
noncomputable def precLhs (P : StreamParams) (V ξ : ℝ) : ℝ :=
  2 * Real.sqrt (P.Dstar : ℝ) * V * ξ + ξ ^ 2

theorem Zlin_eq_Zrow (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) (ζ : Seed P) :
    Zlin P σ v ζ = Zrow P (sgn P ζ) σ v := rfl

/-- `ẑ − Z = z_t − ⟨b, w⟩`: the unscaled regularizer terms cancel. -/
theorem zrow_sub_Zrow (P : StreamParams) (b : Fin P.Dstar → ℝ) (σ zt : ℝ)
    (w : EuclideanSpace ℝ (Fin P.Dstar)) :
    zrow P b σ zt - Zrow P b σ w = zt - ∑ i, b i * w i := by
  unfold zrow Zrow
  simp only [aug_apply, mul_add, Finset.sum_add_distrib, mul_ite, mul_zero, Finset.sum_ite_eq',
    Finset.mem_univ, if_true]
  ring

/-- Cauchy–Schwarz for a sign vector (eq. `R:eq:Z-cauchy-schwarz-bound`):
`|Z_w(b)| = |⟨b, w⁺⟩| ≤ ‖b‖₂ ‖w⁺‖₂ = √D_* ‖w⁺‖`. -/
theorem abs_Zrow_le (P : StreamParams) (b : Fin P.Dstar → ℝ) (hb : ∀ i, b i = 1 ∨ b i = -1)
    (σ : ℝ) (w : EuclideanSpace ℝ (Fin P.Dstar)) :
    |Zrow P b σ w| ≤ Real.sqrt (P.Dstar : ℝ) * ‖aug P σ w‖ := by
  unfold Zrow
  have hcs : (∑ i, b i * aug P σ w i) ^ 2 ≤ (∑ i, b i ^ 2) * ∑ i, aug P σ w i ^ 2 :=
    Finset.sum_mul_sq_le_sq_mul_sq _ _ _
  have hb2 : ∑ i, b i ^ 2 = (P.Dstar : ℝ) := by
    have h1 : ∀ i, b i ^ 2 = 1 := fun i => by rcases hb i with h | h <;> rw [h] <;> norm_num
    simp only [h1, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
  rw [hb2, ← norm_sq_eq_sum] at hcs
  rw [← Real.sqrt_sq_eq_abs]
  calc Real.sqrt ((∑ i, b i * aug P σ w i) ^ 2)
      ≤ Real.sqrt ((P.Dstar : ℝ) * ‖aug P σ w‖ ^ 2) := Real.sqrt_le_sqrt hcs
    _ = Real.sqrt (P.Dstar : ℝ) * ‖aug P σ w‖ := by
        rw [Real.sqrt_mul (Nat.cast_nonneg _), Real.sqrt_sq (norm_nonneg _)]

/-- `|min{x,1} − min{y,1}| ≤ |x − y|` (`min(·,1)` is 1-Lipschitz). -/
theorem abs_min_one_sub_min_one_le (x y : ℝ) : |min x 1 - min y 1| ≤ |x - y| := by
  have h := abs_min_sub_min_le_max x 1 y 1
  simpa using h

/-- `|ẑ² − Z²| = |2Zδ + δ²| ≤ 2|Z|ξ + ξ²` for `|ẑ − Z| = |δ| ≤ ξ`. -/
theorem abs_sq_sub_sq_le {zh Z ξ : ℝ} (h : |zh - Z| ≤ ξ) :
    |zh ^ 2 - Z ^ 2| ≤ 2 * |Z| * ξ + ξ ^ 2 := by
  have e : zh ^ 2 - Z ^ 2 = (zh - Z) * ((zh - Z) + 2 * Z) := by ring
  rw [e, abs_mul]
  have h0 : 0 ≤ |zh - Z| := abs_nonneg _
  have h1 : |(zh - Z) + 2 * Z| ≤ |zh - Z| + 2 * |Z| := by
    calc |(zh - Z) + 2 * Z| ≤ |zh - Z| + |2 * Z| := abs_add_le _ _
      _ = |zh - Z| + 2 * |Z| := by rw [abs_mul]; norm_num
  have hξ : 0 ≤ ξ := h0.trans h
  calc |zh - Z| * |(zh - Z) + 2 * Z| ≤ ξ * (ξ + 2 * |Z|) :=
        mul_le_mul h (h1.trans (by linarith)) (abs_nonneg _) hξ
    _ = 2 * |Z| * ξ + ξ ^ 2 := by ring

/-- `|f̂ − min{Z²/M, 1}| ≤ |ẑ² − Z²|/M + h_A` for `M > 0` and `|f̂ − min{ẑ²/M, 1}| ≤ h_A`. -/
theorem abs_fh_sub_le {fh zh Z M hA : ℝ} (hM : 0 < M)
    (hround : |fh - min (zh ^ 2 / M) 1| ≤ hA) :
    |fh - min (Z ^ 2 / M) 1| ≤ |zh ^ 2 - Z ^ 2| / M + hA := by
  have h1 := abs_min_one_sub_min_one_le (zh ^ 2 / M) (Z ^ 2 / M)
  rw [← sub_div, abs_div, abs_of_pos hM] at h1
  calc |fh - min (Z ^ 2 / M) 1|
      ≤ |fh - min (zh ^ 2 / M) 1| + |min (zh ^ 2 / M) 1 - min (Z ^ 2 / M) 1| := abs_sub_le _ _ _
    _ ≤ hA + |zh ^ 2 - Z ^ 2| / M := add_le_add hround h1
    _ = |zh ^ 2 - Z ^ 2| / M + hA := add_comm _ _

/-- `η/(2^k L) = (η/L) (1/2)^k`. -/
theorem eta_div (P : StreamParams) (k : ℕ) :
    (P.eta : ℝ) / (2 ^ k * P.L) = (P.eta : ℝ) / P.L * (1 / 2) ^ k := by
  rw [one_div_pow, div_mul_div_comm, mul_one, mul_comm (P.L : ℝ)]

/-- From the precision premise: `(2√D_*Vξ + ξ²)/(Lω) ≤ η/(2^30 L)`. -/
theorem prec_div_le (P : StreamParams) {V ξ : ℝ}
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30) :
    precLhs P V ξ / ((P.L : ℝ) * P.omega) ≤ (P.eta : ℝ) / (2 ^ 30 * P.L) := by
  have hL := L_pos P
  have hω := omega_pos P
  rw [div_le_div_iff₀ (mul_pos hL hω) (mul_pos (by norm_num) hL)]
  calc precLhs P V ξ * (2 ^ 30 * P.L) ≤ ((P.eta : ℝ) * P.omega / 2 ^ 30) * (2 ^ 30 * P.L) :=
        mul_le_mul_of_nonneg_right hprec (mul_pos (by norm_num) hL).le
    _ = (P.eta : ℝ) * ((P.L : ℝ) * P.omega) := by ring

/-- The `2ξ` core estimate: `|ẑ − Z| ≤ 2ξ`, `|Z| ≤ √D_* V` give
`|ẑ² − Z²| ≤ 2|Z|(2ξ) + (2ξ)² ≤ 4√D_*Vξ + 4ξ² ≤ ηω/2^28`. -/
theorem two_xi_sq_le (P : StreamParams) {V ξ zh Z : ℝ} (hV0 : 0 ≤ V) (hξ : 0 ≤ ξ)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hdz : |zh - Z| ≤ 2 * ξ) (hZ : |Z| ≤ Real.sqrt (P.Dstar : ℝ) * V) :
    |zh ^ 2 - Z ^ 2| ≤ 2 * |Z| * (2 * ξ) + (2 * ξ) ^ 2 ∧
      2 * |Z| * (2 * ξ) + (2 * ξ) ^ 2 ≤ 4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ∧
      4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 28 := by
  refine ⟨abs_sq_sub_sq_le hdz, by nlinarith, ?_⟩
  have h0 : 0 ≤ Real.sqrt (P.Dstar : ℝ) * V * ξ :=
    mul_nonneg (mul_nonneg (Real.sqrt_nonneg _) hV0) hξ
  unfold precLhs at hprec
  nlinarith

/-- **Lemma 4.8 (i)** (primary counter perturbation, drift `≤ ξ`, eq.
`R:eq:primary-counter-perturbation`): for a row `b` whose counter value `z_t` satisfies
`|z_t − ⟨b, v⟩| ≤ ξ`, the evaluation `ẑ = z_t + b_{D_*}σ` has `|ẑ − Z| ≤ ξ`, and uniformly over
`c ≥ ω`, `|f̂ − f| ≤ |ẑ² − Z²|/(Lc) + h_A ≤ (2√D_*Vξ + ξ²)/(Lω) + h_A ≤ η/(2^29 L) = 2^{-15} a_num`. -/
theorem primary_perturbation (P : StreamParams) (b : Fin P.Dstar → ℝ)
    (hb : ∀ i, b i = 1 ∨ b i = -1) (v : EuclideanSpace ℝ (Fin P.Dstar)) {V ξ hA c zt fh : ℝ}
    (hV : ‖aug P P.sigma v‖ ≤ V)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hhA : hA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) (hc : (P.omega : ℝ) ≤ c)
    (hdrift : |zt - ∑ i, b i * v i| ≤ ξ)
    (hround : |fh - min (zrow P b P.sigma zt ^ 2 / ((P.L : ℝ) * c)) 1| ≤ hA) :
    |zrow P b P.sigma zt - Zrow P b P.sigma v| ≤ ξ ∧
      |fh - min (Zrow P b P.sigma v ^ 2 / ((P.L : ℝ) * c)) 1| ≤
        |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma v ^ 2| / ((P.L : ℝ) * c) + hA ∧
      |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma v ^ 2| / ((P.L : ℝ) * c) + hA ≤
        precLhs P V ξ / ((P.L : ℝ) * P.omega) + hA ∧
      precLhs P V ξ / ((P.L : ℝ) * P.omega) + hA ≤ (P.eta : ℝ) / (2 ^ 29 * P.L) ∧
      (P.eta : ℝ) / (2 ^ 29 * P.L) = (1 / 2) ^ 15 * (P.aNum : ℝ) := by
  have hL := L_pos P
  have hω := omega_pos P
  have hM : 0 < (P.L : ℝ) * c := mul_pos hL (lt_of_lt_of_le hω hc)
  have hdz : |zrow P b P.sigma zt - Zrow P b P.sigma v| ≤ ξ := by rw [zrow_sub_Zrow]; exact hdrift
  have hξ : 0 ≤ ξ := (abs_nonneg _).trans hdz
  have hZ : |Zrow P b P.sigma v| ≤ Real.sqrt (P.Dstar : ℝ) * V :=
    (abs_Zrow_le P b hb _ v).trans (mul_le_mul_of_nonneg_left hV (Real.sqrt_nonneg _))
  have hsq : |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma v ^ 2| ≤ precLhs P V ξ := by
    unfold precLhs
    calc _ ≤ 2 * |Zrow P b P.sigma v| * ξ + ξ ^ 2 := abs_sq_sub_sq_le hdz
      _ ≤ 2 * (Real.sqrt (P.Dstar : ℝ) * V) * ξ + ξ ^ 2 := by
          nlinarith [mul_le_mul_of_nonneg_right hZ hξ]
      _ = _ := by ring
  have hpre0 : 0 ≤ precLhs P V ξ := (abs_nonneg _).trans hsq
  refine ⟨hdz, abs_fh_sub_le hM hround, ?_, ?_, ?_⟩
  · have hq : |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma v ^ 2| / ((P.L : ℝ) * c) ≤
        precLhs P V ξ / ((P.L : ℝ) * P.omega) :=
      (div_le_div_of_nonneg_right hsq hM.le).trans
        (div_le_div_of_nonneg_left hpre0 (mul_pos hL hω) (mul_le_mul_of_nonneg_left hc hL.le))
    linarith
  · have h1 := prec_div_le P hprec
    have h2 : (P.eta : ℝ) / (2 ^ 30 * P.L) + (P.eta : ℝ) / (2 ^ 32 * P.L) ≤
        (P.eta : ℝ) / (2 ^ 29 * P.L) := by
      rw [eta_div, eta_div, eta_div]
      have hx : 0 ≤ (P.eta : ℝ) / P.L := div_nonneg (eta_pos P).le hL.le
      have hn : (1 / 2 : ℝ) ^ 30 + (1 / 2) ^ 32 ≤ (1 / 2) ^ 29 := by norm_num
      calc (P.eta : ℝ) / P.L * (1 / 2) ^ 30 + (P.eta : ℝ) / P.L * (1 / 2) ^ 32
          = (P.eta : ℝ) / P.L * ((1 / 2) ^ 30 + (1 / 2) ^ 32) := by ring
        _ ≤ (P.eta : ℝ) / P.L * (1 / 2) ^ 29 := mul_le_mul_of_nonneg_left hn hx
    linarith
  · rw [aNum_eq, eta_div, eta_div]; ring

/-- **Lemma 4.8 (ii)** (difference counter `2ξ` perturbation for the residual cache refresh): if the
parent counter `z_x` and the (rescaled) client counter `z_y` have drifts `≤ ξ` with respect to `x` and
`y⁺`, and `‖(r⁺)⁺‖ = ‖(x − y⁺, σ)‖ ≤ V`, then the regularized difference counter
`ẑ_{r⁺} = (z_x − z_y) + b_{D_*}σ` has `|ẑ_{r⁺} − Z_{r⁺}| ≤ 2ξ` (eq. `R:eq:diff-counter-linear-drift`);
uniformly over `c ≥ ω`,
`|ẑ² − Z²|/(Lc) ≤ (2|Z|(2ξ) + (2ξ)²)/(Lω) ≤ (4√D_*Vξ + 4ξ²)/(Lω) ≤ η/(2^28 L) = 2^{-14} a_num`
(eq. `R:eq:diff-counter-quadratic-perturbation`) and
`|f̂ − f| ≤ η/(2^28 L) + h_A ≤ η/(2^27 L) = 2^{-13} a_num` (eq. `R:eq:diff-counter-total-perturbation`);
and `|f̂ − f| ≤ η/(2^26 L) = 2^{-12} a_num` for every `c ≥ ω/2`. -/
theorem diff_perturbation (P : StreamParams) (b : Fin P.Dstar → ℝ)
    (hb : ∀ i, b i = 1 ∨ b i = -1) (x y : EuclideanSpace ℝ (Fin P.Dstar)) {V ξ hA c zx zy fh : ℝ}
    (hV : ‖aug P P.sigma (x - y)‖ ≤ V)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hhA : hA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L))
    (hx : |zx - ∑ i, b i * x i| ≤ ξ) (hy : |zy - ∑ i, b i * y i| ≤ ξ)
    (hround : |fh - min (zrow P b P.sigma (zx - zy) ^ 2 / ((P.L : ℝ) * c)) 1| ≤ hA) :
    |zrow P b P.sigma (zx - zy) - Zrow P b P.sigma (x - y)| ≤ 2 * ξ ∧
      ((P.omega : ℝ) ≤ c →
        |zrow P b P.sigma (zx - zy) ^ 2 - Zrow P b P.sigma (x - y) ^ 2| / ((P.L : ℝ) * c) ≤
            (2 * |Zrow P b P.sigma (x - y)| * (2 * ξ) + (2 * ξ) ^ 2) / ((P.L : ℝ) * P.omega) ∧
          (2 * |Zrow P b P.sigma (x - y)| * (2 * ξ) + (2 * ξ) ^ 2) / ((P.L : ℝ) * P.omega) ≤
            (4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2) / ((P.L : ℝ) * P.omega) ∧
          (4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2) / ((P.L : ℝ) * P.omega) ≤
            (P.eta : ℝ) / (2 ^ 28 * P.L) ∧
          (P.eta : ℝ) / (2 ^ 28 * P.L) = (1 / 2) ^ 14 * (P.aNum : ℝ) ∧
          |fh - min (Zrow P b P.sigma (x - y) ^ 2 / ((P.L : ℝ) * c)) 1| ≤
            (P.eta : ℝ) / (2 ^ 28 * P.L) + hA ∧
          (P.eta : ℝ) / (2 ^ 28 * P.L) + hA ≤ (P.eta : ℝ) / (2 ^ 27 * P.L) ∧
          (P.eta : ℝ) / (2 ^ 27 * P.L) = (1 / 2) ^ 13 * (P.aNum : ℝ)) ∧
      ((P.omega : ℝ) / 2 ≤ c →
        |fh - min (Zrow P b P.sigma (x - y) ^ 2 / ((P.L : ℝ) * c)) 1| ≤
            (P.eta : ℝ) / (2 ^ 26 * P.L) ∧
          (P.eta : ℝ) / (2 ^ 26 * P.L) = (1 / 2) ^ 12 * (P.aNum : ℝ)) := by
  have hL := L_pos P
  have hω := omega_pos P
  have hη := eta_pos P
  have hLω : 0 < (P.L : ℝ) * P.omega := mul_pos hL hω
  have hlin : ∑ i, b i * (x - y) i = ∑ i, b i * x i - ∑ i, b i * y i := by
    simp only [PiLp.sub_apply, mul_sub, Finset.sum_sub_distrib]
  have hξ : 0 ≤ ξ := (abs_nonneg _).trans hx
  have hdz : |zrow P b P.sigma (zx - zy) - Zrow P b P.sigma (x - y)| ≤ 2 * ξ := by
    rw [zrow_sub_Zrow, hlin]
    calc |zx - zy - (∑ i, b i * x i - ∑ i, b i * y i)|
        = |(zx - ∑ i, b i * x i) + -(zy - ∑ i, b i * y i)| := by ring_nf
      _ ≤ |zx - ∑ i, b i * x i| + |-(zy - ∑ i, b i * y i)| := abs_add_le _ _
      _ = |zx - ∑ i, b i * x i| + |zy - ∑ i, b i * y i| := by rw [abs_neg]
      _ ≤ ξ + ξ := add_le_add hx hy
      _ = 2 * ξ := by ring
  have hV0 : 0 ≤ V := (norm_nonneg _).trans hV
  have hZ : |Zrow P b P.sigma (x - y)| ≤ Real.sqrt (P.Dstar : ℝ) * V :=
    (abs_Zrow_le P b hb _ (x - y)).trans (mul_le_mul_of_nonneg_left hV (Real.sqrt_nonneg _))
  obtain ⟨hsq, hsq2, h4⟩ := two_xi_sq_le P hV0 hξ hprec hdz hZ
  have hnum0 : 0 ≤ 2 * |Zrow P b P.sigma (x - y)| * (2 * ξ) + (2 * ξ) ^ 2 :=
    add_nonneg (mul_nonneg (mul_nonneg (by norm_num) (abs_nonneg _)) (by linarith))
      (sq_nonneg _)
  refine ⟨hdz, fun hc => ?_, fun hc => ?_⟩
  · have hM : 0 < (P.L : ℝ) * c := mul_pos hL (lt_of_lt_of_le hω hc)
    have q1 := (div_le_div_of_nonneg_right hsq hM.le).trans
      (div_le_div_of_nonneg_left hnum0 hLω (mul_le_mul_of_nonneg_left hc hL.le))
    have q2 := div_le_div_of_nonneg_right hsq2 hLω.le
    have q3 : (4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2) / ((P.L : ℝ) * P.omega) ≤
        (P.eta : ℝ) / (2 ^ 28 * P.L) := by
      rw [div_le_div_iff₀ hLω (mul_pos (by norm_num) hL)]
      calc (4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2) * (2 ^ 28 * P.L)
          ≤ ((P.eta : ℝ) * P.omega / 2 ^ 28) * (2 ^ 28 * P.L) :=
            mul_le_mul_of_nonneg_right h4 (mul_pos (by norm_num) hL).le
        _ = (P.eta : ℝ) * ((P.L : ℝ) * P.omega) := by ring
    have q6 : (P.eta : ℝ) / (2 ^ 28 * P.L) + hA ≤ (P.eta : ℝ) / (2 ^ 27 * P.L) := by
      have h2 : (P.eta : ℝ) / (2 ^ 28 * P.L) + (P.eta : ℝ) / (2 ^ 32 * P.L) ≤
          (P.eta : ℝ) / (2 ^ 27 * P.L) := by
        rw [eta_div, eta_div, eta_div]
        have hx' : 0 ≤ (P.eta : ℝ) / P.L := div_nonneg hη.le hL.le
        have hn : (1 / 2 : ℝ) ^ 28 + (1 / 2) ^ 32 ≤ (1 / 2) ^ 27 := by norm_num
        calc (P.eta : ℝ) / P.L * (1 / 2) ^ 28 + (P.eta : ℝ) / P.L * (1 / 2) ^ 32
            = (P.eta : ℝ) / P.L * ((1 / 2) ^ 28 + (1 / 2) ^ 32) := by ring
          _ ≤ (P.eta : ℝ) / P.L * (1 / 2) ^ 27 := mul_le_mul_of_nonneg_left hn hx'
      linarith
    refine ⟨q1, q2, q3, by rw [aNum_eq, eta_div, eta_div]; ring, ?_, q6,
      by rw [aNum_eq, eta_div, eta_div]; ring⟩
    exact (abs_fh_sub_le hM hround).trans (by linarith)
  · have hc' : 0 < c := lt_of_lt_of_le (by linarith) hc
    have hM : 0 < (P.L : ℝ) * c := mul_pos hL hc'
    have r1 : |zrow P b P.sigma (zx - zy) ^ 2 - Zrow P b P.sigma (x - y) ^ 2| / ((P.L : ℝ) * c) ≤
        (P.eta : ℝ) / (2 ^ 27 * P.L) := by
      rw [div_le_div_iff₀ hM (mul_pos (by norm_num) hL)]
      have hs : |zrow P b P.sigma (zx - zy) ^ 2 - Zrow P b P.sigma (x - y) ^ 2| ≤
          (P.eta : ℝ) * P.omega / 2 ^ 28 := (hsq.trans hsq2).trans h4
      calc |zrow P b P.sigma (zx - zy) ^ 2 - Zrow P b P.sigma (x - y) ^ 2| * (2 ^ 27 * P.L)
          ≤ ((P.eta : ℝ) * P.omega / 2 ^ 28) * (2 ^ 27 * P.L) :=
            mul_le_mul_of_nonneg_right hs (mul_pos (by norm_num) hL).le
        _ = (P.eta : ℝ) * ((P.L : ℝ) * ((P.omega : ℝ) / 2)) := by ring
        _ ≤ (P.eta : ℝ) * ((P.L : ℝ) * c) :=
            mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hc hL.le) hη.le
    have r2 : (P.eta : ℝ) / (2 ^ 27 * P.L) + (P.eta : ℝ) / (2 ^ 32 * P.L) ≤
        (P.eta : ℝ) / (2 ^ 26 * P.L) := by
      rw [eta_div, eta_div, eta_div]
      have hx' : 0 ≤ (P.eta : ℝ) / P.L := div_nonneg hη.le hL.le
      have hn : (1 / 2 : ℝ) ^ 27 + (1 / 2) ^ 32 ≤ (1 / 2) ^ 26 := by norm_num
      calc (P.eta : ℝ) / P.L * (1 / 2) ^ 27 + (P.eta : ℝ) / P.L * (1 / 2) ^ 32
          = (P.eta : ℝ) / P.L * ((1 / 2) ^ 27 + (1 / 2) ^ 32) := by ring
        _ ≤ (P.eta : ℝ) / P.L * (1 / 2) ^ 26 := mul_le_mul_of_nonneg_left hn hx'
    refine ⟨(abs_fh_sub_le hM hround).trans (by linarith), by rw [aNum_eq, eta_div, eta_div]; ring⟩

/-- The `2ξ` form of (ii) for a counter given directly with drift `≤ 2ξ` (both evaluation modes;
used for numerical releases, where `c ≥ ω/2`): `|f̂ − f| ≤ η/(2^26 L)`. -/
theorem two_xi_perturbation (P : StreamParams) (b : Fin P.Dstar → ℝ)
    (hb : ∀ i, b i = 1 ∨ b i = -1) (w : EuclideanSpace ℝ (Fin P.Dstar)) {V ξ hA c zt fh : ℝ}
    (hV : ‖aug P P.sigma w‖ ≤ V)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hhA : hA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) (hc : (P.omega : ℝ) / 2 ≤ c)
    (hdrift : |zt - ∑ i, b i * w i| ≤ 2 * ξ)
    (hround : |fh - min (zrow P b P.sigma zt ^ 2 / ((P.L : ℝ) * c)) 1| ≤ hA) :
    |fh - min (Zrow P b P.sigma w ^ 2 / ((P.L : ℝ) * c)) 1| ≤ (P.eta : ℝ) / (2 ^ 26 * P.L) := by
  have hL := L_pos P
  have hω := omega_pos P
  have hη := eta_pos P
  have hdz : |zrow P b P.sigma zt - Zrow P b P.sigma w| ≤ 2 * ξ := by
    rw [zrow_sub_Zrow]; exact hdrift
  have hξ : 0 ≤ ξ := by have := (abs_nonneg _).trans hdz; linarith
  have hV0 : 0 ≤ V := (norm_nonneg _).trans hV
  have hZ : |Zrow P b P.sigma w| ≤ Real.sqrt (P.Dstar : ℝ) * V :=
    (abs_Zrow_le P b hb _ w).trans (mul_le_mul_of_nonneg_left hV (Real.sqrt_nonneg _))
  obtain ⟨hsq, hsq2, h4⟩ := two_xi_sq_le P hV0 hξ hprec hdz hZ
  have hc' : 0 < c := lt_of_lt_of_le (by linarith) hc
  have hM : 0 < (P.L : ℝ) * c := mul_pos hL hc'
  have r1 : |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma w ^ 2| / ((P.L : ℝ) * c) ≤
      (P.eta : ℝ) / (2 ^ 27 * P.L) := by
    rw [div_le_div_iff₀ hM (mul_pos (by norm_num) hL)]
    have hs : |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma w ^ 2| ≤
        (P.eta : ℝ) * P.omega / 2 ^ 28 := (hsq.trans hsq2).trans h4
    calc |zrow P b P.sigma zt ^ 2 - Zrow P b P.sigma w ^ 2| * (2 ^ 27 * P.L)
        ≤ ((P.eta : ℝ) * P.omega / 2 ^ 28) * (2 ^ 27 * P.L) :=
          mul_le_mul_of_nonneg_right hs (mul_pos (by norm_num) hL).le
      _ = (P.eta : ℝ) * ((P.L : ℝ) * ((P.omega : ℝ) / 2)) := by ring
      _ ≤ (P.eta : ℝ) * ((P.L : ℝ) * c) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hc hL.le) hη.le
  have r2 : (P.eta : ℝ) / (2 ^ 27 * P.L) + (P.eta : ℝ) / (2 ^ 32 * P.L) ≤
      (P.eta : ℝ) / (2 ^ 26 * P.L) := by
    rw [eta_div, eta_div, eta_div]
    have hx' : 0 ≤ (P.eta : ℝ) / P.L := div_nonneg hη.le hL.le
    have hn : (1 / 2 : ℝ) ^ 27 + (1 / 2) ^ 32 ≤ (1 / 2) ^ 26 := by norm_num
    calc (P.eta : ℝ) / P.L * (1 / 2) ^ 27 + (P.eta : ℝ) / P.L * (1 / 2) ^ 32
        = (P.eta : ℝ) / P.L * ((1 / 2) ^ 27 + (1 / 2) ^ 32) := by ring
      _ ≤ (P.eta : ℝ) / P.L * (1 / 2) ^ 26 := mul_le_mul_of_nonneg_left hn hx'
  exact (abs_fh_sub_le hM hround).trans (by linarith)

/-! ### Order statistics are monotone and `1`-Lipschitz (for Lemma 4.8 (iii)) -/

/-- The lower median is monotone in the values. -/
theorem lowerMedian_mono {g : ℕ} {y y' : Fin g → ℝ} (h : ∀ j, y j ≤ y' j) :
    lowerMedian y ≤ lowerMedian y' := by
  classical
  rcases Nat.eq_zero_or_pos g with hg | hg
  · subst hg; exact le_refl _
  · by_contra hcon
    rw [not_le] at hcon
    have e1 := card_lt_lowerMedian_le y hg
    have e2 := lt_card_le_lowerMedian y' hg
    have hsub : univ.filter (fun j => y' j ≤ lowerMedian y') ⊆
        univ.filter (fun j => y j < lowerMedian y) := by
      intro j hj
      simp only [mem_filter, mem_univ, true_and] at hj ⊢
      exact lt_of_le_of_lt (h j) (lt_of_le_of_lt hj hcon)
    have := card_le_card hsub
    omega

/-- Translating all values translates the lower median. -/
theorem lowerMedian_add_const {g : ℕ} (y : Fin g → ℝ) (hg : 0 < g) (δ : ℝ) :
    lowerMedian (fun j => y j + δ) = lowerMedian y + δ :=
  lowerMedian_comp_of_monotone (f := fun x => x + δ) (fun _ _ hab => by simp only; linarith) y hg

/-- The lower median is `1`-Lipschitz in the sup norm. -/
theorem abs_lowerMedian_sub_le {g : ℕ} {y y' : Fin g → ℝ} {δ : ℝ} (hg : 0 < g)
    (h : ∀ j, |y' j - y j| ≤ δ) : |lowerMedian y' - lowerMedian y| ≤ δ := by
  rw [abs_le]
  constructor
  · have hm := lowerMedian_mono (y := fun j => y j + -δ) (y' := y')
      (fun j => by have := (abs_le.mp (h j)).1; linarith)
    rw [lowerMedian_add_const y hg] at hm
    linarith
  · have hm := lowerMedian_mono (y := y') (y' := fun j => y j + δ)
      (fun j => by have := (abs_le.mp (h j)).2; linarith)
    rw [lowerMedian_add_const y hg] at hm
    linarith

/-- **Lemma 4.8 (iii)** (coarse AMS perturbation on primary and difference counters): if every row of a
coarse group has counter drift `≤ 2ξ` with respect to the target `w`, then for every row
`|ẑ² − Z²| ≤ 4√D_*Vξ + 4ξ² ≤ (η/2^28) ω ≤ 2^{-28} F' < F'/16` (eq. `R:eq:coarse-row-perturbation`;
`F' = ‖w⁺‖²`, `ω ≤ F'` needs the shadow condition `w_{D_*} = 0`), and the coarse median computed from
the `ẑ²` lies in `[F'/2, 3F'/2]` whenever the exact coarse median lies in `[9F'/16, 23F'/16]`
(eq. `R:eq:coarse-perturbed-enclosure`). -/
theorem coarse_perturbation (P : StreamParams) (w : EuclideanSpace ℝ (Fin P.Dstar))
    (hw : w (regIdx P) = 0) {V ξ : ℝ} (hξ : 0 ≤ ξ) (hV : ‖aug P P.sigma w‖ ≤ V)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    {g : ℕ} (G : Fin g → Fin 32 → Seed P) (zt : Fin g → Fin 32 → ℝ)
    (hdrift : ∀ j l, |zt j l - ∑ i, sgn P (G j l) i * w i| ≤ 2 * ξ) :
    (∀ j l, |zrow P (sgn P (G j l)) P.sigma (zt j l) ^ 2 - Zlin P P.sigma w (G j l) ^ 2| ≤
        4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2) ∧
      4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ≤ (P.eta : ℝ) / 2 ^ 28 * P.omega ∧
      (P.eta : ℝ) / 2 ^ 28 * P.omega ≤ (1 / 2) ^ 28 * ‖aug P P.sigma w‖ ^ 2 ∧
      (1 / 2) ^ 28 * ‖aug P P.sigma w‖ ^ 2 < ‖aug P P.sigma w‖ ^ 2 / 16 ∧
      (9 / 16 * ‖aug P P.sigma w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) (aug P P.sigma w) G) ∧
          coarseEst (rowVals (sgn P) (aug P P.sigma w) G) ≤ 23 / 16 * ‖aug P P.sigma w‖ ^ 2 →
        1 / 2 * ‖aug P P.sigma w‖ ^ 2 ≤
            coarseEst (fun j l => zrow P (sgn P (G j l)) P.sigma (zt j l)) ∧
          coarseEst (fun j l => zrow P (sgn P (G j l)) P.sigma (zt j l)) ≤
            3 / 2 * ‖aug P P.sigma w‖ ^ 2) := by
  have hω := omega_pos P
  have hη1 := eta_le_one P
  have hV0 : 0 ≤ V := (norm_nonneg _).trans hV
  set F := ‖aug P P.sigma w‖ ^ 2 with hFdef
  have hFω : (P.omega : ℝ) ≤ F := by
    rw [hFdef, norm_sq_aug P _ w hw, omega_eq]
    nlinarith [sq_nonneg ‖w‖]
  have hFpos : 0 < F := lt_of_lt_of_le hω hFω
  have hrow : ∀ j l, |zrow P (sgn P (G j l)) P.sigma (zt j l) ^ 2 - Zlin P P.sigma w (G j l) ^ 2| ≤
      2 * |Zlin P P.sigma w (G j l)| * (2 * ξ) + (2 * ξ) ^ 2 ∧
      2 * |Zlin P P.sigma w (G j l)| * (2 * ξ) + (2 * ξ) ^ 2 ≤
        4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ∧
      4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 28 := by
    intro j l
    have hdz : |zrow P (sgn P (G j l)) P.sigma (zt j l) - Zlin P P.sigma w (G j l)| ≤ 2 * ξ := by
      rw [Zlin_eq_Zrow, zrow_sub_Zrow]; exact hdrift j l
    have hZ : |Zlin P P.sigma w (G j l)| ≤ Real.sqrt (P.Dstar : ℝ) * V :=
      (abs_Zrow_le P _ (sgn_eq_or P (G j l)) _ w).trans
        (mul_le_mul_of_nonneg_left hV (Real.sqrt_nonneg _))
    exact two_xi_sq_le P hV0 hξ hprec hdz hZ
  have h4 : 4 * Real.sqrt (P.Dstar : ℝ) * V * ξ + 4 * ξ ^ 2 ≤ (P.eta : ℝ) / 2 ^ 28 * P.omega := by
    have h0 : 0 ≤ Real.sqrt (P.Dstar : ℝ) * V * ξ :=
      mul_nonneg (mul_nonneg (Real.sqrt_nonneg _) hV0) hξ
    unfold precLhs at hprec
    have : (P.eta : ℝ) / 2 ^ 28 * P.omega = (P.eta : ℝ) * P.omega / 2 ^ 28 := by ring
    rw [this]
    nlinarith
  have h5 : (P.eta : ℝ) / 2 ^ 28 * P.omega ≤ (1 / 2) ^ 28 * F := by
    have : (P.eta : ℝ) / 2 ^ 28 * P.omega = (1 / 2) ^ 28 * ((P.eta : ℝ) * P.omega) := by ring
    rw [this]
    apply mul_le_mul_of_nonneg_left _ (by norm_num)
    calc (P.eta : ℝ) * P.omega ≤ 1 * P.omega := mul_le_mul_of_nonneg_right hη1 hω.le
      _ = P.omega := one_mul _
      _ ≤ F := hFω
  have h6 : (1 / 2 : ℝ) ^ 28 * F < F / 16 := by nlinarith
  refine ⟨fun j l => ((hrow j l).1.trans (hrow j l).2.1), h4, h5, h6, ?_⟩
  intro hmed
  rcases Nat.eq_zero_or_pos g with hg | hg
  · exfalso
    subst hg
    have h0 : coarseEst (rowVals (sgn P) (aug P P.sigma w) G) = 0 := by
      simp only [coarseEst, lowerMedian, orderStat]
      rfl
    rw [h0] at hmed
    linarith [hmed.1]
  · -- every perturbed group mean is within `F/16` of the exact one
    have hclose : ∀ j, |groupMean (fun l => zrow P (sgn P (G j l)) P.sigma (zt j l)) -
        groupMean (rowVals (sgn P) (aug P P.sigma w) G j)| ≤ F / 16 := by
      intro j
      unfold groupMean
      have h32 : (0 : ℝ) < (32 : ℕ) := by norm_num
      rw [← sub_div, ← Finset.sum_sub_distrib, abs_div, abs_of_pos h32, div_le_iff₀ h32]
      calc |∑ l, (zrow P (sgn P (G j l)) P.sigma (zt j l) ^ 2 -
            rowVals (sgn P) (aug P P.sigma w) G j l ^ 2)|
          ≤ ∑ l, |zrow P (sgn P (G j l)) P.sigma (zt j l) ^ 2 -
            rowVals (sgn P) (aug P P.sigma w) G j l ^ 2| := Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _l : Fin 32, F / 16 := by
            refine Finset.sum_le_sum fun l _ => ?_
            rw [rowVals_aug]
            have := (hrow j l).1.trans ((hrow j l).2.1.trans h4)
            linarith
        _ = F / 16 * ((32 : ℕ) : ℝ) := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_comm]
    have hlip := abs_lowerMedian_sub_le hg hclose
    unfold coarseEst at hmed ⊢
    rw [abs_le] at hlip
    constructor <;> linarith [hmed.1, hmed.2, hlip.1, hlip.2]

end F2e2e.C.NormBank
