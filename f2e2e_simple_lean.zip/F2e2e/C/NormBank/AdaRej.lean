import Mathlib
import F2e2e.C.ClosureRows

/-!
# The rejection counter of a bank's ADA module (helpers for `F2e2e/C/ClosureBank.lean`)

B's core (`F2e2e/B/ArchCore.lean`, Algorithm 2 of partII.tex) counts the rejections it returns in
`AdaState.rej`; the `(J+1)`-st rejection is terminal (line [15], `outerReject`). This file shows, on every path
of fresh bits:

* `adaIntervalD_rej`: an interval call increments `rej` exactly when it returns a rejection, and a terminal
  rejection needs `J ≤ rej` before the call;
* `adaNumericalD_rej`, `adaInitD_rej`: numerical calls keep `rej`, initialization sets it to `0`;
* the bank-level forms `bitAlways_validate_rej'`, `bitAlways_releaseLog_rej'`, `bitAlways_newBank_rej'`;
* `bitAlways_newBank_shape`: the reserved coarse groups of a fresh bank have `g` subgroups of `32` rows.

`DrawAlways` is the every-path predicate on draw programs (`F2e2e.Discrete.DrawProg`), the analogue of C-CLOSE's
`BitAlways`; `DrawAlways.toBits` transfers it through the bounded samplers.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-! ## Every-path predicates on draw programs -/

/-- `DrawAlways Q p`: every output of the draw program `p`, on every path of draws, satisfies `Q`. -/
inductive DrawAlways {Pm β α : Type} (Q : α → Prop) : DrawProg Pm β α → Prop
  | ret (a : α) : Q a → DrawAlways Q (DrawProg.ret a)
  | draw (p : Pm) (k : β → DrawProg Pm β α) :
      (∀ b, DrawAlways Q (k b)) → DrawAlways Q (DrawProg.draw p k)

theorem DrawAlways.bind' {Pm β α γ : Type} {Q : α → Prop} {R : γ → Prop} {f : α → DrawProg Pm β γ}
    (hf : ∀ a, Q a → DrawAlways R (f a)) :
    ∀ {p : DrawProg Pm β α}, DrawAlways Q p → DrawAlways R (p.bind f)
  | _, DrawAlways.ret a h => hf a h
  | _, DrawAlways.draw p k h => DrawAlways.draw p _ fun b => DrawAlways.bind' hf (h b)

theorem DrawAlways.mono' {Pm β α : Type} {Q Q' : α → Prop} (hQ : ∀ a, Q a → Q' a) :
    ∀ {p : DrawProg Pm β α}, DrawAlways Q p → DrawAlways Q' p
  | _, DrawAlways.ret a h => DrawAlways.ret a (hQ a h)
  | _, DrawAlways.draw p k h => DrawAlways.draw p k fun b => DrawAlways.mono' hQ (h b)

theorem drawAlways_true {Pm β α : Type} : ∀ p : DrawProg Pm β α, DrawAlways (fun _ => True) p
  | DrawProg.ret a => DrawAlways.ret a trivial
  | DrawProg.draw p k => DrawAlways.draw p k fun b => drawAlways_true (k b)

/-- Every-path predicates survive the bit implementation of the draws. -/
theorem DrawAlways.toBits {Pm β α : Type} {Q : α → Prop} {s : Pm → BitProg β} :
    ∀ {p : DrawProg Pm β α}, DrawAlways Q p → BitAlways Q (p.toBits s)
  | _, DrawAlways.ret a h => BitAlways.pure a h
  | _, DrawAlways.draw p k h => by
    show BitAlways Q ((s p).bind fun b => DrawProg.toBits s (k b))
    exact BitAlways.bind' (fun b _ => DrawAlways.toBits (h b)) (bitAlways_true (s p))

/-! ## The core's rejection counter -/

theorem applyCorrection_rej (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    DrawAlways (fun st' : AdaState => st'.rej = st.rej) (applyCorrection P st vals j q) := by
  unfold applyCorrection
  dsimp only
  refine DrawAlways.bind' (fun _ _ => ?_) (drawAlways_true _)
  exact DrawAlways.ret _ rfl

theorem scanPass_rej (P : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool),
      DrawAlways (fun r : PassOut × AdaState × List Bool => r.2.1.rej = st.rej)
        (scanPass P vals mus es st cache)
  | [], st, cache => DrawAlways.ret _ rfl
  | j :: es, st, cache => by
    unfold scanPass
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact scanPass_rej P vals mus es st cache
    · rw [if_neg hc]
      refine DrawAlways.bind' (fun r _ => ?_) (drawAlways_true _)
      rcases r with _ | q
      · exact scanPass_rej P vals mus es st _
      · dsimp only
        by_cases hT : P.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hT]
          exact DrawAlways.ret _ rfl
        · rw [if_neg hT]
          refine DrawAlways.bind' (fun st' hst' => ?_) (applyCorrection_rej P st vals j q)
          exact DrawAlways.ret _ hst'

theorem prepareRoot_rej (P : AdaParams) (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool),
      DrawAlways (fun r : Option AdaState => ∀ st2, r = some st2 → st2.rej = st.rej)
        (prepareRoot P vals fuel st cache)
  | 0, _, _ => DrawAlways.ret _ (fun _ h => by cases h)
  | fuel + 1, st, cache => by
    unfold prepareRoot
    refine DrawAlways.bind' (fun r hr => ?_)
      (scanPass_rej P vals (adaMus P st vals) (List.range P.p) st cache)
    rcases r with ⟨o, st', cache'⟩
    have hr' : st'.rej = st.rej := hr
    cases o
    · exact DrawAlways.ret _ (fun st2 h => by cases h; exact hr')
    · exact DrawAlways.mono' (fun r h st2 hs => (h st2 hs).trans hr')
        (prepareRoot_rej P vals fuel st' cache')
    · exact DrawAlways.ret _ (fun _ h => by cases h)

theorem outerReject_rej (P : AdaParams) (st : AdaState) (high : Bool) :
    DrawAlways (fun r : AdaCert × AdaState => r.2.rej = st.rej + 1 ∧ coreIsReject (Sum.inl r.1) = true ∧
      (r.1 = AdaCert.termHigh ∨ r.1 = AdaCert.termLow → P.J ≤ st.rej)) (outerReject P st high) := by
  unfold outerReject
  by_cases hJ : P.J + 1 ≤ st.rej + 1
  · rw [if_pos hJ]
    refine DrawAlways.ret _ ⟨rfl, ?_, fun _ => by omega⟩
    cases high <;> rfl
  · rw [if_neg hJ]
    refine DrawAlways.bind' (fun k _ => DrawAlways.ret _ ⟨rfl, ?_, ?_⟩) (drawAlways_true _)
    · cases high <;> rfl
    · cases high <;> simp

/-- **`Interval`**: `rej` grows by one exactly on a returned rejection; a terminal rejection needs `J ≤ rej`. -/
theorem adaIntervalD_rej (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    DrawAlways (fun r : AdaCert × AdaState =>
      r.2.rej = st.rej + (if coreIsReject (Sum.inl r.1) = true then 1 else 0) ∧
        (r.1 = AdaCert.termHigh ∨ r.1 = AdaCert.termLow → P.J ≤ st.rej)) (adaIntervalD P st vals l u) := by
  unfold adaIntervalD
  split_ifs with h
  · exact DrawAlways.ret _ ⟨by simp [coreIsReject], by simp⟩
  · refine DrawAlways.bind' (fun r hr => ?_)
      (prepareRoot_rej P vals P.fuel { st with nInt := st.nInt + 1 } _)
    rcases r with _ | st2
    · exact DrawAlways.ret _ ⟨by simp [coreIsReject], by simp⟩
    · have h2 : st2.rej = st.rej := hr st2 rfl
      dsimp only
      refine DrawAlways.bind' (fun kH _ => DrawAlways.bind' (fun kL _ => ?_) (drawAlways_true _))
        (drawAlways_true _)
      split_ifs
      · refine DrawAlways.mono' (fun r hr' => ⟨?_, fun ht => ?_⟩) (outerReject_rej P st2 true)
        · rw [if_pos hr'.2.1, hr'.1, h2]
        · rw [← h2]; exact hr'.2.2 ht
      · refine DrawAlways.mono' (fun r hr' => ⟨?_, fun ht => ?_⟩) (outerReject_rej P st2 false)
        · rw [if_pos hr'.2.1, hr'.1, h2]
        · rw [← h2]; exact hr'.2.2 ht
      · exact DrawAlways.ret _ ⟨by simp [coreIsReject, h2], by simp⟩

/-- **`Numerical`** keeps the rejection counter. -/
theorem adaNumericalD_rej (P : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    DrawAlways (fun r : AdaNum × AdaState => r.2.rej = st.rej) (adaNumericalD P st vals) := by
  unfold adaNumericalD
  split_ifs with h
  · exact DrawAlways.ret _ rfl
  · refine DrawAlways.bind' (fun r hr => ?_)
      (prepareRoot_rej P vals P.fuel { st with nNum := st.nNum + 1 } _)
    rcases r with _ | st2
    · exact DrawAlways.ret _ rfl
    · have h2 : st2.rej = st.rej := hr st2 rfl
      dsimp only
      refine DrawAlways.bind' (fun k _ => ?_) (drawAlways_true _)
      exact DrawAlways.ret _ h2

/-- The initial state has returned no rejection. -/
theorem adaInitD_rej (P : AdaParams) : DrawAlways (fun st : AdaState => st.rej = 0) (adaInitD P) := by
  unfold adaInitD
  refine DrawAlways.bind' (fun _ _ => ?_) (drawAlways_true _)
  refine DrawAlways.bind' (fun _ _ => ?_) (drawAlways_true _)
  exact DrawAlways.ret _ rfl

/-! ## Bank-level forms -/

theorem bitAlways_validate_rej' (P : StreamParams) (B : Bank) (S θ : ℚ) :
    BitAlways (fun r : AdaCert × Bank =>
      r.2.adaSt.rej = B.adaSt.rej + (if coreIsReject (Sum.inl r.1) = true then 1 else 0) ∧
        (r.1 = AdaCert.termHigh ∨ r.1 = AdaCert.termLow → (bankAda P).J ≤ B.adaSt.rej))
      (B.validate P S θ) := by
  unfold Bank.validate
  simp only [bp_bind_eq, bp_pure_eq]
  have hp : BitAlways (fun res : AdaCert × AdaState =>
      res.2.rej = B.adaSt.rej + (if coreIsReject (Sum.inl res.1) = true then 1 else 0) ∧
        (res.1 = AdaCert.termHigh ∨ res.1 = AdaCert.termLow → (bankAda P).J ≤ B.adaSt.rej))
      (adaInterval (bankAda P) B.adaSt (adaVals P Mode.primary (S + P.omega) B)
        ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ))) := by
    unfold adaInterval
    exact DrawAlways.toBits (adaIntervalD_rej _ _ _ _ _)
  refine BitAlways.bind' (fun res hres => ?_) hp
  exact BitAlways.pure _ hres

theorem bitAlways_releaseLog_rej' (P : StreamParams) (B : Bank) (mode : Mode) :
    BitAlways (fun r : (Option ℚ × Bank) × Option (ℚ × AdaNum) => r.1.2.adaSt.rej = B.adaSt.rej)
      (releaseLog P B mode) := by
  cases h : B.coarse with
  | nil =>
    rw [releaseLog_nil P B mode h]
    exact BitAlways.pure _ rfl
  | cons grp rest =>
    rw [releaseLog_cons P B mode h]
    have hp : BitAlways (fun res : AdaNum × AdaState => res.2.rej = B.adaSt.rej)
        (adaNumerical (bankAda P) B.adaSt
          (adaVals P mode (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) B)) := by
      unfold adaNumerical
      exact DrawAlways.toBits (adaNumericalD_rej _ _ _)
    refine BitAlways.bind' (fun res hres => ?_) hp
    rcases res with ⟨out, st⟩
    have hst : st.rej = B.adaSt.rej := hres
    cases out with
    | val μ => exact BitAlways.pure _ hst
    | abort => exact BitAlways.pure _ hst

theorem newBank_eq_bind (P : StreamParams) :
    newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
      (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind fun coarse =>
        (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl

theorem bitAlways_newBank_rej' (P : StreamParams) :
    BitAlways (fun B : Bank => B.adaSt.rej = 0) (newBank P) := by
  rw [newBank_eq_bind]
  have hp : BitAlways (fun st : AdaState => st.rej = 0) (adaInit (bankAda P)) := by
    unfold adaInit
    exact DrawAlways.toBits (adaInitD_rej _)
  refine BitAlways.bind' (fun ada _ => ?_) (bitAlways_true _)
  refine BitAlways.bind' (fun coarse _ => ?_) (bitAlways_true _)
  refine BitAlways.bind' (fun st hst => ?_) hp
  exact BitAlways.pure _ hst

/-! ## The shape of the reserved coarse groups -/

/-- The coarse groups of a bank have `g` subgroups of `32` rows (partIII.tex L206). -/
def CoarseShape (P : StreamParams) (B : Bank) : Prop :=
  ∀ grp ∈ B.coarse, grp.length = P.gCoarse ∧ ∀ sub ∈ grp, sub.length = 32

theorem bitAlways_newBank_shape (P : StreamParams) : BitAlways (CoarseShape P) (newBank P) := by
  rw [newBank_eq_bind]
  have h2 := bitAlways_sampleList _ (bitAlways_sampleList _ (bitAlways_sampleList _
    (bitAlways_true (newRow P)) 32) P.gCoarse) P.Rmax
  refine BitAlways.bind' (fun ada _ => BitAlways.bind' (fun coarse hco =>
    BitAlways.bind' (fun st _ => BitAlways.pure _ ?_) (bitAlways_true _)) h2) (bitAlways_true _)
  intro grp hgrp
  obtain ⟨hlen, hsub⟩ := hco.2 grp hgrp
  exact ⟨hlen, fun sub hs => (hsub sub hs).1⟩

end F2e2e.C.Closure
