import Mathlib
import F2e2e.C.ClosureJoint

/-!
# Helpers for the bank calls of a round (`F2e2e/C/ClosureGlue.lean`)

* `mem_setAt`, `labelAt_snoc`, `nRej_eq_zero_of_fresh`, `nNum_eq_zero_of_fresh` (list bookkeeping);
* `x_reg_zero`, `y_reg_zero`: the tree shadow's inputs vanish at the regularizer coordinate `D_*` (Lean index
  `D_* − 1`): the root input is physical (`x0_phys`) and every residual vanishes from the next guard coordinate on
  (`fresh`), which is at most `n + T` (partIII.tex L599: `g(d,t) ≤ n + mH < n + T = D_* − 1`);
* `sqrt_x_le_V`: `√(‖x_d‖² + ω) ≤ V` for every `d ≤ live` (Theorem 5.11 (2b) and the augmented bound);
* `coarseOK_of_good`: the coarse event of a logged release that consumed a group;
* `not_coreCorrect_abort_int`, `not_coreCorrect_abort_num`: an `abort` is never a correct output.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Lists -/

theorem mem_setAt {α : Type} {x b : α} {k : ℕ} {l : List α} (hb : b ∈ setAt x k l) : b ∈ l ∨ b = x := by
  obtain ⟨j, hj, hjb⟩ := List.getElem_of_mem hb
  have h := getElem?_setAt x k j l
  rw [List.getElem?_eq_getElem hj, hjb] at h
  split_ifs at h with hjk
  · simp only [Option.some.injEq] at h
    exact Or.inr h
  · exact Or.inl (List.mem_of_getElem? h.symm)

theorem labelAt_snoc (g : Ghost) (lab : BankLabel) (hs : List (List RowOp)) {idx : ℕ}
    (hidx : idx < g.labels.length) :
    ({ g with labels := g.labels ++ [lab], hists := hs } : Ghost).labelAt idx = g.labelAt idx := by
  unfold Ghost.labelAt
  exact List.getD_append _ _ _ _ hidx

theorem labelAt_snoc_last (g : Ghost) (lab : BankLabel) (hs : List (List RowOp)) :
    ({ g with labels := g.labels ++ [lab], hists := hs } : Ghost).labelAt g.labels.length = lab := by
  unfold Ghost.labelAt
  show (g.labels ++ [lab]).getD g.labels.length (0, 0) = lab
  rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
  rfl

theorem nRej_eq_zero_of_fresh {lab : BankLabel} {calls : List CallRec} (h : ∀ rec ∈ calls, rec.lab ≠ lab) :
    nRej lab calls = 0 := by
  unfold nRej
  rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
  intro rec hrec
  simp [h rec hrec]

theorem nNum_eq_zero_of_fresh {lab : BankLabel} {calls : List CallRec} (h : ∀ rec ∈ calls, rec.lab ≠ lab) :
    nNum lab calls = 0 := by
  unfold nNum
  rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
  intro rec hrec
  simp [h rec hrec]

/-! ## The regularizer coordinate of the tree shadow -/

variable {P : StreamParams}

theorem regIdx_val' (P : StreamParams) : (regIdx P : ℕ) = P.n + P.T := by
  simp [regIdx, Dm]

/-- The next guard coordinate is at most `D_*` (for the phases used by the algorithm). -/
theorem nextG_le_Dstar (ph : Tree.Phase) {t : ℕ} (ht1 : 1 ≤ t) (htm : t ≤ P.m)
    (hph : ∀ D, ph = Tree.Phase.guards D → D ≤ P.H) : ph.nextG P t ≤ P.n + P.T + 1 := by
  have hT := P.m_mul_H_add_one_lt_T
  have hHm : P.H * (t - 1) + P.H + 1 ≤ P.m * (P.H + 1) := by
    have h1 : P.H * (t - 1) ≤ P.H * (P.m - 1) := Nat.mul_le_mul_left _ (by omega)
    have h2 : P.H * (P.m - 1) + P.H = P.H * P.m := by
      rw [← Nat.mul_succ]; congr 1; omega
    have h3 : P.m * (P.H + 1) = P.H * P.m + P.m := by ring
    omega
  cases ph with
  | births D =>
    simp only [Tree.Phase.nextG, StreamParams.guardCoord]
    omega
  | guards D =>
    have hD := hph D rfl
    simp only [Tree.Phase.nextG, StreamParams.guardCoord]
    have : P.H * (t - 1) + D + 1 ≤ P.H * (t - 1) + P.H + 1 := by omega
    omega
  | evals D =>
    simp only [Tree.Phase.nextG, StreamParams.guardCoord]
    omega
  | idle =>
    simp only [Tree.Phase.nextG, StreamParams.guardCoord]
    omega

/-- The inputs `x_D` (`D ≤ live`) vanish at the regularizer coordinate. -/
theorem x_reg_zero {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (htree : Tree.TreeInv P ph R S)
    (hph : ∀ D, ph = Tree.Phase.guards D → D ≤ P.H) {D : ℕ} (hD : D ≤ ph.live P.H) :
    (S.x D) (regIdx P) = 0 := by
  have hng := nextG_le_Dstar ph htree.round_pos htree.round_le hph
  have hc : Tree.coordAt (S.x D) (P.n + P.T) = 0 := by
    apply Tree.coordAt_x_zero S (htree.x0_phys _ (by omega))
    intro i hi
    exact htree.fresh i (by omega) _ (by omega)
  have hlt : P.n + P.T < P.Dstar := by unfold StreamParams.Dstar; omega
  unfold Tree.coordAt at hc
  rw [dif_pos hlt] at hc
  have he : (regIdx P) = ⟨P.n + P.T, hlt⟩ := Fin.ext (regIdx_val' P)
  rw [he]
  exact hc

/-- The outgoing vectors `y_D = x_{D+1}` (`D < live`) vanish at the regularizer coordinate. -/
theorem y_reg_zero {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (htree : Tree.TreeInv P ph R S)
    (hph : ∀ D, ph = Tree.Phase.guards D → D ≤ P.H) {D : ℕ} (hD : D < ph.live P.H) :
    (S.y D) (regIdx P) = 0 :=
  x_reg_zero htree hph (D := D + 1) hD

/-- `√(‖x_d‖² + ω) ≤ V` for every `d ≤ live` (Theorem 5.11 (2b): `‖x_d‖ ≤ V_d ≤ V_H`, and the augmented bound). -/
theorem sqrt_x_le_V {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (htree : Tree.TreeInv P ph R S)
    (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) {d : ℕ} (hd : d ≤ ph.live P.H) :
    √(‖S.x d‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ) := by
  have hx := (Tree.vector_bounds_inv htree hbox).1 d hd
  have hdH : d ≤ P.H := hd.trans htree.live_le
  have hVd : (P.Vd d : ℝ) ≤ (P.Vd P.H : ℝ) := by exact_mod_cast P.Vd_mono hdH
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) ^ P.H := one_le_pow₀ (Tree.B_eq_and_gt P).2.le
  have hVH0 : (0 : ℝ) ≤ (P.Vd P.H : ℝ) := Nat.cast_nonneg _
  apply Tree.aug_le_V P (norm_nonneg _)
  nlinarith

/-! ## Coarse events and correctness -/

/-- The coarse event of a logged release of bank `lab` that consumed a coarse group. -/
theorem coarseOK_of_good {lab : BankLabel} {gF : Ghost} (hcgood : ∀ k, CoarseGood P lab k gF)
    {rec : CallRec} (hmem : rec ∈ gF.calls) (hlab : rec.lab = lab) {mode : Mode}
    (hrel : rec.kind = CallKind.release mode) (hco : rec.bank.coarse ≠ []) : CoarseOK P rec := by
  have hin : rec ∈ coarseRecs lab gF := by
    unfold coarseRecs
    rw [List.mem_filter]
    refine ⟨hmem, ?_⟩
    simp only [hlab, hrel, decide_true, Bool.true_and]
    cases h : rec.bank.coarse with
    | nil => exact absurd h hco
    | cons a l => rfl
  obtain ⟨k, hk⟩ := List.mem_iff_getElem?.mp hin
  exact hcgood k rec (by rw [hk]; rfl)

theorem not_coreCorrect_abort_int {U : Type} [Fintype U] {D : U → ℝ} {hA : ℚ} {α : ℝ} {req : CoreReq U}
    (h : req.isInterval = true) : ¬ coreCorrect D hA α req (Sum.inl AdaCert.abort) := by
  unfold coreCorrect
  rw [if_pos h]
  exact id

theorem not_coreCorrect_abort_num {U : Type} [Fintype U] {D : U → ℝ} {hA : ℚ} {α : ℝ} {req : CoreReq U}
    (h : req.isInterval = false) : ¬ coreCorrect D hA α req (Sum.inr AdaNum.abort) := by
  unfold coreCorrect
  rw [if_neg (by rw [h]; exact Bool.false_ne_true)]
  exact id

end F2e2e.C.Closure
