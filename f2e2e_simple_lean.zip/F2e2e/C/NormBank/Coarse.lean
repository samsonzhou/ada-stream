import F2e2e.C.NormBank.Defs
import F2e2e.C.Top.Interface

/-!
# The coarse moment event of one reserved coarse group (Lemma 4.2 inside Theorem 4.9)

Source: `parts/partIII.tex` Algorithm `R:alg:regularized-norm-bank` L206 (`R_max` coarse groups of
`32g` rows, `g = 32⌈log₂(4R_max/β_B)⌉`), Lemma `R:lem:coarse-ams` (L61–86) and the proof of
Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step` (L387: "A `32`-row mean of squared exact
measurements has variance at most `F'²/16`. Chebyshev gives failure probability at most
`16/49 < 1/3` for the interval `[9F'/16, 23F'/16]`. The independent-group bounded-range inequality
gives median failure at most `e^{−g/18} ≤ β_B/(2R_max)`").

For a **fixed** target `w` (the augmented shadow vector `v⁺` of the release that will consume the
group; its independence from the group at first use is the closure's information-flow argument,
partIII.tex L393, L1275), over the uniform seeds `z : Fin g → Fin 32 → Seed P` of the group:

* `coarse_bad_prob`: `P[exact coarse median ∉ [9‖w‖²/16, 23‖w‖²/16]] ≤ β_B/(2R_max)`;
* `coarse_bad_count`: the same as a count, `≤ β_B/(2R_max) · |Seed|^{32g}`;
* `exp_neg_gCoarse_le`: the numerics `e^{−g/18} ≤ β_B/(4R_max) ≤ β_B/(2R_max)` (`32 ≥ 18 ln 2`).

(The pure probability is LIB-HASH-AMS's `P_not_AMSGood_le` with the bank's `2s`-wise rows.)
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb Finset

/-- `e^{−g/18} ≤ β_B/(4 R_max)` for `g = 32⌈log₂(4R_max/β_B)⌉` (partIII.tex L387; `32 ≥ 18 ln 2`). -/
theorem exp_neg_gCoarse_le (P : StreamParams) (hP : Top.ParamsOK P) :
    Real.exp (-((P.gCoarse : ℝ) / 18)) ≤ (P.betaB : ℝ) / (4 * P.Rmax) := by
  set N := P.Rmax * P.m * (P.H + 1) with hNdef
  set K := P.betaExp + 8 + Nat.clog 2 N with hK
  have hg : (P.gCoarse : ℝ) = 32 * (K : ℝ) := by
    unfold StreamParams.gCoarse; rw [hK, hNdef]; push_cast; ring
  have hR : 1 ≤ P.Rmax := by unfold StreamParams.Rmax; omega
  have hm : 1 ≤ P.m := hP.one_le_m
  have hN1 : 1 ≤ N := by
    rw [hNdef]
    have h1 : 1 ≤ P.Rmax * P.m := by nlinarith
    nlinarith
  -- `e^{-32K/18} ≤ 2^{-K}` since `ln 2 < 32/18`
  have h1 : Real.exp (-((P.gCoarse : ℝ) / 18)) ≤ (1 / 2 : ℝ) ^ K := by
    have e1 : (1 / 2 : ℝ) ^ K = Real.exp ((K : ℝ) * Real.log (1 / 2)) := by
      rw [Real.exp_nat_mul, Real.exp_log (by norm_num)]
    rw [e1, hg]
    apply Real.exp_le_exp.mpr
    have hl : Real.log (1 / 2 : ℝ) = -Real.log 2 := by
      rw [one_div, Real.log_inv]
    rw [hl]
    have := Real.log_two_lt_d9
    have hK0 : (0 : ℝ) ≤ K := Nat.cast_nonneg _
    nlinarith
  -- `2^{-K} ≤ β_B/(4R_max)` since `2^{⌈log₂ N⌉} ≥ N`
  have hNle : (N : ℝ) ≤ 2 ^ Nat.clog 2 N := by exact_mod_cast Nat.le_pow_clog (by norm_num) N
  have hNpos : (0 : ℝ) < N := by exact_mod_cast hN1
  have hbB : (P.betaB : ℝ) / (4 * P.Rmax) = (1 / 2 : ℝ) ^ P.betaExp / (256 * N) := by
    unfold StreamParams.betaB StreamParams.beta0
    rw [hNdef]
    push_cast
    have hR0 : (P.Rmax : ℝ) ≠ 0 := by exact_mod_cast (show P.Rmax ≠ 0 by omega)
    have hm0 : (P.m : ℝ) ≠ 0 := by exact_mod_cast (show P.m ≠ 0 by omega)
    field_simp
    ring
  have h2 : (1 / 2 : ℝ) ^ K ≤ (P.betaB : ℝ) / (4 * P.Rmax) := by
    rw [hbB, hK, pow_add, pow_add]
    have h3 : (1 / 2 : ℝ) ^ Nat.clog 2 N ≤ 1 / N := by
      rw [one_div_pow, one_div_le_one_div (pow_pos (by norm_num) _) hNpos]
      exact hNle
    calc (1 / 2 : ℝ) ^ P.betaExp * (1 / 2) ^ 8 * (1 / 2) ^ Nat.clog 2 N
        ≤ (1 / 2 : ℝ) ^ P.betaExp * (1 / 2) ^ 8 * (1 / N) :=
          mul_le_mul_of_nonneg_left h3
            (mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg (by norm_num) _))
      _ = (1 / 2 : ℝ) ^ P.betaExp / (256 * N) := by field_simp; norm_num
  exact h1.trans h2

/-- The number of seed tuples of one coarse group. -/
theorem card_coarse_seeds (P : StreamParams) :
    Fintype.card (Fin P.gCoarse → Fin 32 → Seed P) = Fintype.card (Seed P) ^ (32 * P.gCoarse) := by
  rw [Fintype.card_fun, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin, ← pow_mul]

/-- The exact coarse median event fails with probability at most `β_B/(2R_max)` (uniform seeds of
one group, fixed target `w`). -/
theorem coarse_bad_prob (P : StreamParams) (hP : Top.ParamsOK P)
    (w : EuclideanSpace ℝ (Fin P.Dstar)) :
    FinProb.P (fun z : Fin P.gCoarse → Fin 32 → Seed P =>
        ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w z) ∧
          coarseEst (rowVals (sgn P) w z) ≤ 23 / 16 * ‖w‖ ^ 2)) ≤
      (P.betaB : ℝ) / (2 * P.Rmax) := by
  have hb := sgn_isKWiseSigns P
  have h1 : FinProb.P (fun z : Fin P.gCoarse → Fin 32 → Seed P =>
        ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w z) ∧
          coarseEst (rowVals (sgn P) w z) ≤ 23 / 16 * ‖w‖ ^ 2)) ≤
      FinProb.P (fun z : Fin P.gCoarse → Fin 32 → Seed P => ¬ AMSGood (sgn P) w z) := by
    apply P_mono
    intro z hz hgood
    apply hz
    have := hgood.coarseEst_mem
    rw [← norm_sq_eq_sum] at this
    exact this
  have h2 := P_not_AMSGood_le hb (four_le_two_s P) w (g := P.gCoarse) (le_refl 32)
  have h3 := exp_neg_gCoarse_le P hP
  have hbB0 : (0 : ℝ) ≤ P.betaB := by
    unfold StreamParams.betaB StreamParams.beta0
    push_cast
    exact div_nonneg (pow_nonneg (by norm_num) _) (mul_nonneg (mul_nonneg (by norm_num)
      (Nat.cast_nonneg _)) (by have := (Nat.cast_nonneg P.H : (0 : ℝ) ≤ P.H); linarith))
  have hR : (0 : ℝ) < P.Rmax := by
    exact_mod_cast (show 0 < P.Rmax by unfold StreamParams.Rmax; omega)
  have h4 : (P.betaB : ℝ) / (4 * P.Rmax) ≤ (P.betaB : ℝ) / (2 * P.Rmax) :=
    div_le_div_of_nonneg_left hbB0 (by linarith) (by linarith)
  linarith

/-- **Counting form** (as consumed by the closure): the number of seed tuples of one coarse group
whose exact coarse median lies outside `[9‖w‖²/16, 23‖w‖²/16]` is at most
`β_B/(2R_max) · |Seed|^{32g}`. -/
theorem coarse_bad_count (P : StreamParams) (hP : Top.ParamsOK P)
    (w : EuclideanSpace ℝ (Fin P.Dstar)) :
    ((univ.filter (fun z : Fin P.gCoarse → Fin 32 → Seed P =>
        ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w z) ∧
          coarseEst (rowVals (sgn P) w z) ≤ 23 / 16 * ‖w‖ ^ 2))).card : ℝ) ≤
      (P.betaB : ℝ) / (2 * P.Rmax) * (Fintype.card (Seed P) : ℝ) ^ (32 * P.gCoarse) := by
  classical
  have h := coarse_bad_prob P hP w
  rw [P_def, card_coarse_seeds,
    div_le_iff₀ (Nat.cast_pos.mpr (pow_pos Fintype.card_pos _))] at h
  push_cast at h
  exact h

/-- The per-bank failure budget (partIII.tex L393): `β_B/2` (ADA) plus `R_max` coarse events of
`β_B/(2R_max)` each is `β_B`. -/
theorem betaB_budget (P : StreamParams) :
    (P.betaB : ℝ) / 2 + P.Rmax * ((P.betaB : ℝ) / (2 * P.Rmax)) = P.betaB := by
  have hR : (P.Rmax : ℝ) ≠ 0 := by
    exact_mod_cast (show P.Rmax ≠ 0 by unfold StreamParams.Rmax; omega)
  field_simp
  ring

end F2e2e.C.NormBank
