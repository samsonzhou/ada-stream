import F2e2e.C.NormBank.Moments
import F2e2e.C.NormBank.Perturb
import F2e2e.C.Top.Interface

/-!
# Theorem 4.9: two-regime Regularized Norm Bank certificates (deterministic form)

Source: `parts/partIII.tex` Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step` (L348–368,
proof L370–405). The theorem says: except with probability `β_B`, every request to the bank satisfies
the certificates. Its proof (L393) splits into
* a **statistical event** — the bank ADA's capped event of Theorem `R:thm:validation_ada` (every covered
  response correct, probability `≥ 1 − β_B/2`) and, for every numerical release, the exact coarse
  moment event of the consumed coarse group for its target (`R_max` events of probability
  `≥ 1 − β_B/(2R_max)` each, `coarse_bad_count` in `F2e2e/C/NormBank/Coarse.lean`); the information
  flow (ADA with a composite controller, each unused coarse group independent of its target at first
  use, union bound) is done in the chronological closure (Theorem 6.4, C-CLOSE);
* a **deterministic step** for one request on that event — this file:

* `normBank_validate` (L377–L398): if the ADA's interval response to the rowwise query `f̂_c`
  (`c = S + ω`, band `[(1−θ)/L, (1+θ)/L]`) is correct at accuracy `a_num` (`VCorrect`, the row law
  `unifD P`), the counters have drift `≤ ξ` on **every** seed, `‖v⁺‖ ≤ V`, the precision premise
  `2√D_*Vξ + ξ² ≤ ηω/2^30` holds, `S ≥ 0` and `0 ≤ θ ≤ 2^{-16}`, then with `r = (‖v‖² + ω)/(S + ω)`:
  `ACCEPT ⇒ |r − 1| ≤ θ + η/4`, `HIGH ⇒ r − 1 ≥ θ − η/4`, `LOW ⇒ 1 − r ≥ θ − η/4`
  (eqs. `R:eq:cert-accept`, `R:eq:cert-high`, `R:eq:cert-low`; terminal rejections are `HIGH`/`LOW`
  responses). The two regimes are stitched at `r = 2`: for `r ≥ 2` the sandwich (Lemma 4.7 (i)) gives
  `E f ≥ 2/(L+6)`, above the band plus all errors, so `ACCEPT` and `LOW` force `r < 2`.
* `normBank_release` (L387–L404): if the exact coarse median of the consumed group lies in
  `[9F'/16, 23F'/16]`, the counters have drift `≤ 2ξ` on every seed (`ξ` for `PRIMARY`, `2ξ` for
  `DIFF`), `c = max(c_raw, ω/2)` with `c_raw` the lower median of the perturbed group means, and the
  ADA's numerical answer `μ̂` to `f̂_c` is correct at accuracy `a_num`, then `N = max(0, Lcμ̂ − ω)`
  satisfies `|N − ‖v‖²| ≤ 2^{-13}η‖v‖² + ω` (eq. `R:eq:cert-numerical`).

Both are stated for the bank's ADA grid `h_A = 2^{-qA}` under `h_A ≤ η/(2^32 L)` (`*_of_hA`), and for
C-ALG's bank instance `qA = (bankAda P).qA` (`bankAda_hA_le`). The general forms `validate_certificate`,
`release_certificate` take any query values within `h_A` of the clipped ones and any accuracy
`a ≤ a_val = η/(16L)` (interval) resp. `a ≤ a_num = η/(2^14 L)` (numerical).

Conventions: `σ = P.sigma`, `ω = P.omega = σ²`, `η = P.eta`, `L = P.L`, shadows `v` with
`v (regIdx P) = 0`, `v⁺ = aug P σ v` (`F2e2e/C/NormBank/Defs.lean`).
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb Finset

/-! ## Certificates -/

/-- Correctness of one ADA interval response for a query with population mean `μ`, band `[l, u]`
and accuracy `a` (Theorem `R:thm:validation_ada`, eqs. `R:eq:sec3_cert_accept`–`R:eq:sec3_cert_low`;
terminal rejections are `HIGH`/`LOW`). -/
def IntervalCorrect (resp : VResponse) (l u a μ : ℝ) : Prop :=
  (resp = VResponse.accept → l - a ≤ μ ∧ μ ≤ u + a) ∧
    (resp = VResponse.high → u - a ≤ μ) ∧
    (resp = VResponse.low → μ ≤ l + a)

/-- The interval certificates of Theorem 4.9 for the scale ratio `r` (eqs. `R:eq:cert-accept`,
`R:eq:cert-high`, `R:eq:cert-low`). -/
def ValCert (η θ r : ℝ) (resp : VResponse) : Prop :=
  (resp = VResponse.accept → |r - 1| ≤ θ + η / 4) ∧
    (resp = VResponse.high → θ - η / 4 ≤ r - 1) ∧
    (resp = VResponse.low → θ - η / 4 ≤ 1 - r)

/-- The numerical certificate of Theorem 4.9, `|N − ‖v‖²| ≤ 2^{-13} η ‖v‖² + ω`
(eq. `R:eq:cert-numerical`), with `F = ‖v‖²`. -/
def NumCert (η ω F N : ℝ) : Prop := |N - F| ≤ (1 / 2) ^ 13 * η * F + ω

/-- `|E f − E g| ≤ δ` from a pointwise bound. -/
theorem abs_E_sub_E_le {Ω : Type*} [Fintype Ω] [Nonempty Ω] {f g : Ω → ℝ} {δ : ℝ}
    (h : ∀ ω, |f ω - g ω| ≤ δ) : |E f - E g| ≤ δ := by
  rw [← E_sub, abs_le]
  constructor
  · calc -δ = E (fun _ : Ω => -δ) := (E_const _).symm
      _ ≤ E (fun ω => f ω - g ω) := E_mono fun ω => (abs_le.mp (h ω)).1
  · calc E (fun ω => f ω - g ω) ≤ E (fun _ : Ω => δ) := E_mono fun ω => (abs_le.mp (h ω)).2
      _ = δ := E_const _

/-- `|max(0, x) − y| ≤ |x − y|` for `y ≥ 0` (truncation at zero is nonexpansive). -/
theorem abs_max_zero_sub_le {x y : ℝ} (hy : 0 ≤ y) : |max 0 x - y| ≤ |x - y| := by
  rcases le_total 0 x with hx | hx
  · rw [max_eq_right hx]
  · rw [max_eq_left hx, zero_sub, abs_neg, abs_of_nonneg hy, abs_of_nonpos (by linarith)]
    linarith

/-- The Spec's `VCorrect` for an interval request is `IntervalCorrect` of the population mean. -/
theorem vCorrect_interval_iff {U : Type} [Fintype U] (D : U → ℝ) (a : ℝ) (f : U → ℝ) (l u : ℝ)
    (resp : VResponse) (hresp : ∀ q, resp ≠ VResponse.num q) :
    VCorrect D a (f, true, l, u) resp ↔ IntervalCorrect resp l u a (popMean D f) := by
  cases resp with
  | accept => simp [VCorrect, IntervalCorrect]
  | high => simp [VCorrect, IntervalCorrect]
  | low => simp [VCorrect, IntervalCorrect]
  | num q => exact absurd rfl (hresp q)

/-! ## Certificate algebra (real inequalities, partIII.tex L395–L404) -/

/-- **Certificate algebra** (partIII.tex L395–L398), scaled by `L`: `m = L·E f` (exact mean),
`m̂ = L·E f̂` (mean of the submitted query), `e = L a ≤ η/16`, with `|m̂ − m| ≤ η/2^29`,
`m ≤ r` (sandwich upper bound), `r ≥ 2 ⇒ m ≥ 9/5` (sandwich lower bound, `L ≥ 64`) and
`r ≤ 2 ⇒ r − m ≤ 2^{-16} η r` (tail). Slack: `1/16 + 2^{-29} + 2^{-15} < 1/4`. -/
theorem cert_algebra {η θ e r m mh : ℝ} (hη0 : 0 < η) (hη1 : η ≤ 1) (hθ0 : 0 ≤ θ)
    (hθ1 : θ ≤ 1 / 65536) (he : e ≤ η / 16) (hd1 : -(η / 2 ^ 29) ≤ mh - m)
    (hd2 : mh - m ≤ η / 2 ^ 29) (hmup : m ≤ r) (hmlow : 2 ≤ r → 9 / 5 ≤ m)
    (hmtail : r ≤ 2 → r - m ≤ η / 2 ^ 16 * r) :
    (1 - θ - e ≤ mh → mh ≤ 1 + θ + e → |r - 1| ≤ θ + η / 4) ∧
      (1 + θ - e ≤ mh → θ - η / 4 ≤ r - 1) ∧
      (mh ≤ 1 - θ + e → θ - η / 4 ≤ 1 - r) := by
  refine ⟨fun h1 h2 => ?_, fun h1 => ?_, fun h2 => ?_⟩
  · have hr2 : r < 2 := by
      by_contra hcon
      have := hmlow (not_lt.mp hcon)
      linarith
    have ht := hmtail hr2.le
    have hηr : η * r ≤ η * 2 := mul_le_mul_of_nonneg_left hr2.le hη0.le
    rw [abs_le]
    constructor <;> linarith
  · linarith
  · have hr2 : r < 2 := by
      by_contra hcon
      have := hmlow (not_lt.mp hcon)
      linarith
    have ht := hmtail hr2.le
    have hηr : η * r ≤ η * 2 := mul_le_mul_of_nonneg_left hr2.le hη0.le
    linarith

/-- The validation step in terms of the means (partIII.tex L377–L398): from the perturbation
`|μ̂ − μ| ≤ η/(2^29 L)` (Lemma 4.8 (i)), the sandwich and the tail (Lemma 4.7) for `r = F'/c`. -/
theorem validate_scaled {L η F c μ μh a θ : ℝ} (hL : 0 < L) (hL64 : 64 ≤ L) (hη : 0 < η)
    (hη1 : η ≤ 1) (hF : 0 < F) (hc : 0 < c) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16)
    (ha : a ≤ η / (16 * L)) (hpert : |μh - μ| ≤ η / (2 ^ 29 * L))
    (hlow : F / c / (L + 3 * (F / c)) ≤ μ) (hup : μ ≤ F / c / L)
    (htail : F ≤ 2 * c → F / c / L - μ ≤ η / 2 ^ 16 * (F / c / L)) :
    ((1 - θ) / L - a ≤ μh ∧ μh ≤ (1 + θ) / L + a → |F / c - 1| ≤ θ + η / 4) ∧
      ((1 + θ) / L - a ≤ μh → θ - η / 4 ≤ F / c - 1) ∧
      (μh ≤ (1 - θ) / L + a → θ - η / 4 ≤ 1 - F / c) := by
  obtain ⟨r, hr⟩ : ∃ r, r = F / c := ⟨_, rfl⟩
  rw [← hr] at hlow hup htail ⊢
  have hL0 : L ≠ 0 := hL.ne'
  have hr0 : 0 < r := hr ▸ div_pos hF hc
  have hFrc : F = r * c := by rw [hr]; field_simp
  have hmup : L * μ ≤ r := by
    have h := mul_le_mul_of_nonneg_left hup hL.le
    have e : L * (r / L) = r := by field_simp
    linarith
  have hmlow : 2 ≤ r → 9 / 5 ≤ L * μ := fun h2 => by
    have hq : 9 / 5 ≤ L * (r / (L + 3 * r)) := by
      rw [mul_div_assoc', le_div_iff₀ (by linarith)]
      nlinarith [mul_nonneg (sub_nonneg.mpr hL64) (by linarith : (0 : ℝ) ≤ 5 * r - 9)]
    exact hq.trans (mul_le_mul_of_nonneg_left hlow hL.le)
  have hmtail : r ≤ 2 → r - L * μ ≤ η / 2 ^ 16 * r := fun h2 => by
    have hall := htail (by rw [hFrc]; exact mul_le_mul_of_nonneg_right h2 hc.le)
    have h := mul_le_mul_of_nonneg_left hall hL.le
    have e1 : L * (r / L - μ) = r - L * μ := by field_simp
    have e2 : L * (η / 2 ^ 16 * (r / L)) = η / 2 ^ 16 * r := by field_simp
    linarith
  have hd : |L * μh - L * μ| ≤ η / 2 ^ 29 := by
    rw [← mul_sub, abs_mul, abs_of_pos hL]
    have h := mul_le_mul_of_nonneg_left hpert hL.le
    have e : L * (η / (2 ^ 29 * L)) = η / 2 ^ 29 := by field_simp
    linarith
  rw [abs_le] at hd
  have he : L * a ≤ η / 16 := by
    have h := mul_le_mul_of_nonneg_left ha hL.le
    have e : L * (η / (16 * L)) = η / 16 := by field_simp
    linarith
  have hθ1' : θ ≤ 1 / 65536 := by norm_num at hθ1 ⊢; linarith
  obtain ⟨hA1, hA2, hA3⟩ := cert_algebra hη hη1 hθ0 hθ1' he hd.1 hd.2 hmup hmlow hmtail
  have hup' : ∀ {t : ℝ}, μh ≤ t / L + a → L * μh ≤ t + L * a := fun {t} h => by
    have h' := mul_le_mul_of_nonneg_left h hL.le
    have e : L * (t / L + a) = t + L * a := by field_simp
    linarith
  have hlo' : ∀ {t : ℝ}, t / L - a ≤ μh → t - L * a ≤ L * μh := fun {t} h => by
    have h' := mul_le_mul_of_nonneg_left h hL.le
    have e : L * (t / L - a) = t - L * a := by field_simp
    linarith
  refine ⟨fun h => hA1 ?_ ?_, fun h => hA2 ?_, fun h => hA3 ?_⟩
  · have := hlo' h.1; linarith
  · have := hup' h.2; linarith
  · have := hlo' h; linarith
  · have := hup' h; linarith

/-- **Numerical algebra** (partIII.tex L400–L404): with `c ∈ (0, 3F'/2]`, `q = F'/(Lc)`,
`La ≤ η/2^14`, `|μ̂ − E f̂| ≤ a`, `|E f̂ − E f| ≤ η/(2^26 L)`, `E f ≤ q` and `q − E f ≤ 2^{-16} η q`:
`|max(0, Lcμ̂ − ω) − ‖v‖²| ≤ 2^{-13}η‖v‖² + ω` (`F' = ‖v‖² + ω`; the constant
`(3/2)(2^{-14} + 2^{-26}) + 2^{-16} = (14339/16384) 2^{-13} < 2^{-13}`). -/
theorem num_algebra {L η a c F q μ μf μx ω v2 : ℝ} (hL : 0 < L) (hη : 0 < η) (hη1 : η ≤ 1)
    (hω : 0 < ω) (hv2 : 0 ≤ v2) (hF : F = v2 + ω) (hc : 0 < c) (hc_hi : c ≤ 3 / 2 * F)
    (hq : q = F / c / L) (ha : L * a ≤ η / 2 ^ 14) (hμ : |μ - μf| ≤ a)
    (hpert : |μf - μx| ≤ η / (2 ^ 26 * L)) (hup : μx ≤ q) (hlo : q - μx ≤ η / 2 ^ 16 * q) :
    |max 0 (L * c * μ - ω) - v2| ≤ (1 / 2) ^ 13 * η * v2 + ω := by
  have hL0 : L ≠ 0 := hL.ne'
  have hc0 : c ≠ 0 := hc.ne'
  have hLc : 0 < L * c := mul_pos hL hc
  have hqLc : L * c * q = F := by rw [hq]; field_simp
  have habs : |μ - q| ≤ a + η / (2 ^ 26 * L) + η / 2 ^ 16 * q := by
    rw [abs_le] at hμ hpert ⊢
    constructor <;> linarith
  have hmain : |L * c * μ - F| ≤ c * (η / 2 ^ 14 + η / 2 ^ 26) + η / 2 ^ 16 * F := by
    have e1 : L * c * μ - F = L * c * (μ - q) := by rw [mul_sub, hqLc]
    rw [e1, abs_mul, abs_of_pos hLc]
    have h1 := mul_le_mul_of_nonneg_left habs hLc.le
    have e2 : L * c * (a + η / (2 ^ 26 * L) + η / 2 ^ 16 * q) =
        c * (L * a) + c * (η / 2 ^ 26) + η / 2 ^ 16 * (L * c * q) := by field_simp
    rw [hqLc] at e2
    have h3 : c * (L * a) ≤ c * (η / 2 ^ 14) := mul_le_mul_of_nonneg_left ha hc.le
    linarith
  have hk : 0 ≤ η / 2 ^ 14 + η / 2 ^ 26 :=
    add_nonneg (div_nonneg hη.le (by norm_num)) (div_nonneg hη.le (by norm_num))
  have h4 : c * (η / 2 ^ 14 + η / 2 ^ 26) ≤ 3 / 2 * F * (η / 2 ^ 14 + η / 2 ^ 26) :=
    mul_le_mul_of_nonneg_right hc_hi hk
  have hηF : 0 ≤ η * F := mul_nonneg hη.le (by rw [hF]; linarith)
  have h5 : |L * c * μ - F| ≤ (1 / 2) ^ 13 * η * F := by
    have : 3 / 2 * F * (η / 2 ^ 14 + η / 2 ^ 26) + η / 2 ^ 16 * F ≤ (1 / 2) ^ 13 * η * F := by
      have e : 3 / 2 * F * (η / 2 ^ 14 + η / 2 ^ 26) + η / 2 ^ 16 * F =
          (14339 / 16384) * ((1 / 2) ^ 13 * (η * F)) := by ring
      rw [e]
      have e' : (1 / 2 : ℝ) ^ 13 * η * F = (1 / 2) ^ 13 * (η * F) := by ring
      rw [e']
      have : 0 ≤ (1 / 2 : ℝ) ^ 13 * (η * F) := mul_nonneg (by norm_num) hηF
      linarith
    linarith
  have h6 : |max 0 (L * c * μ - ω) - v2| ≤ |L * c * μ - ω - v2| := abs_max_zero_sub_le hv2
  have e3 : L * c * μ - ω - v2 = L * c * μ - F := by rw [hF]; ring
  rw [e3] at h6
  have h7 : (1 / 2 : ℝ) ^ 13 * η * F = (1 / 2) ^ 13 * η * v2 + (1 / 2) ^ 13 * η * ω := by
    rw [hF]; ring
  have h8 : (1 / 2 : ℝ) ^ 13 * η * ω ≤ ω := by
    have : (1 / 2 : ℝ) ^ 13 * η ≤ 1 := by
      have : (1 / 2 : ℝ) ^ 13 * η ≤ (1 / 2) ^ 13 * 1 := mul_le_mul_of_nonneg_left hη1 (by norm_num)
      linarith
    nlinarith
  linarith

/-! ## General deterministic forms -/

/-- **Theorem 4.9, interval certificates** (deterministic step, partIII.tex L377–L398), general
form: query values `fh` within `h_A ≤ η/(2^32 L)` of `min{ẑ²/(Lc), 1}`, ADA accuracy
`a ≤ a_val = η/(16L)`. -/
theorem validate_certificate (P : StreamParams) {V ξ hA a S θ : ℝ}
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hhA : hA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) (ha : a ≤ (P.eta : ℝ) / (16 * P.L))
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ ξ)
    (hS : 0 ≤ S) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16)
    (fh : Seed P → ℝ)
    (hround : ∀ ζ, |fh ζ - min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 /
      ((P.L : ℝ) * (S + P.omega))) 1| ≤ hA)
    (resp : VResponse)
    (hresp : IntervalCorrect resp ((1 - θ) / P.L) ((1 + θ) / P.L) a (E fh)) :
    ValCert (P.eta : ℝ) θ ((‖v‖ ^ 2 + P.omega) / (S + P.omega)) resp := by
  have hω := omega_pos P
  have hc : (P.omega : ℝ) ≤ S + P.omega := by linarith
  have hcpos : (0 : ℝ) < S + P.omega := by linarith
  have hFeq : ‖aug P P.sigma v‖ ^ 2 = ‖v‖ ^ 2 + P.omega := by
    rw [norm_sq_aug P _ v hv, omega_eq]
  have hFpos : 0 < ‖aug P P.sigma v‖ ^ 2 := by
    rw [hFeq]; exact add_pos_of_nonneg_of_pos (sq_nonneg _) hω
  have hpert : |E fh - E (fIdeal P P.sigma v (S + P.omega))| ≤ (P.eta : ℝ) / (2 ^ 29 * P.L) := by
    refine abs_E_sub_E_le fun ζ => ?_
    obtain ⟨-, h2, h3, h4, -⟩ :=
      primary_perturbation P (sgn P ζ) (sgn_eq_or P ζ) v hV hprec hhA hc (hdrift ζ) (hround ζ)
    exact h2.trans (h3.trans h4)
  obtain ⟨hs1, hs2, hs3, hs4⟩ := moment_sandwich P P.sigma v hcpos
  have htail : ‖aug P P.sigma v‖ ^ 2 ≤ 2 * (S + P.omega) →
      ‖aug P P.sigma v‖ ^ 2 / (S + P.omega) / P.L - E (fIdeal P P.sigma v (S + P.omega)) ≤
        (P.eta : ℝ) / 2 ^ 16 * (‖aug P P.sigma v‖ ^ 2 / (S + P.omega) / P.L) := fun h2 => by
    have mt := moment_tail P P.sigma v hFpos hcpos h2
    exact mt.2.1.trans (mt.2.2.1.trans mt.2.2.2.1)
  obtain ⟨hA1, hA2, hA3⟩ := validate_scaled (L_pos P) (sixtyfour_le_L P) (eta_pos P)
    (eta_le_one P) hFpos hcpos hθ0 hθ1 ha hpert (hs1 ▸ hs2) (hs4 ▸ hs3) htail
  rw [← hFeq]
  obtain ⟨hacc, hhigh, hlowc⟩ := hresp
  exact ⟨fun h => hA1 (hacc h), fun h => hA2 (hhigh h), fun h => hA3 (hlowc h)⟩

/-- **Theorem 4.9, numerical certificate** (deterministic step, partIII.tex L387–L404), general form:
query values `fh` within `h_A ≤ η/(2^32 L)` of `min{ẑ²/(Lc), 1}`, ADA error `|μ − E fh| ≤ a` with
`a ≤ a_num = η/(2^14 L)`. -/
theorem release_certificate (P : StreamParams) {V ξ hA a c μ : ℝ}
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (hhA : hA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) (ha : a ≤ (P.eta : ℝ) / (2 ^ 14 * P.L))
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ 2 * ξ)
    {g : ℕ} (G : Fin g → Fin 32 → Seed P)
    (hmed : 9 / 16 * ‖aug P P.sigma v‖ ^ 2 ≤ coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ∧
      coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ≤ 23 / 16 * ‖aug P P.sigma v‖ ^ 2)
    (hcdef : c = max (coarseEst fun j l => zrow P (sgn P (G j l)) P.sigma (X (G j l)))
      ((P.omega : ℝ) / 2))
    (fh : Seed P → ℝ)
    (hround : ∀ ζ, |fh ζ - min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 / ((P.L : ℝ) * c)) 1| ≤ hA)
    (hμ : |μ - E fh| ≤ a) :
    NumCert (P.eta : ℝ) (P.omega : ℝ) (‖v‖ ^ 2) (max 0 ((P.L : ℝ) * c * μ - P.omega)) := by
  have hL := L_pos P
  have hω := omega_pos P
  have hFeq : ‖aug P P.sigma v‖ ^ 2 = ‖v‖ ^ 2 + P.omega := by
    rw [norm_sq_aug P _ v hv, omega_eq]
  have hFω : (P.omega : ℝ) ≤ ‖aug P P.sigma v‖ ^ 2 := by rw [hFeq]; linarith [sq_nonneg ‖v‖]
  have hFpos : 0 < ‖aug P P.sigma v‖ ^ 2 := lt_of_lt_of_le hω hFω
  have hξ : 0 ≤ ξ := by
    have := (abs_nonneg _).trans (hdrift (Classical.arbitrary (Seed P)))
    linarith
  have hco := (coarse_perturbation P v hv hξ hV hprec G (fun j l => X (G j l))
    (fun j l => hdrift (G j l))).2.2.2.2 hmed
  have hc_lo : ‖aug P P.sigma v‖ ^ 2 / 2 ≤ c := by
    rw [hcdef]; exact le_trans (by linarith [hco.1]) (le_max_left _ _)
  have hc_eq : c = coarseEst fun j l => zrow P (sgn P (G j l)) P.sigma (X (G j l)) := by
    rw [hcdef]; exact max_eq_left (by linarith [hco.1])
  have hc_hi : c ≤ 3 / 2 * ‖aug P P.sigma v‖ ^ 2 := by rw [hc_eq]; exact hco.2
  have hcpos : 0 < c := by linarith
  have hcω : (P.omega : ℝ) / 2 ≤ c := by linarith
  have hpert : |E fh - E (fIdeal P P.sigma v c)| ≤ (P.eta : ℝ) / (2 ^ 26 * P.L) :=
    abs_E_sub_E_le fun ζ =>
      two_xi_perturbation P (sgn P ζ) (sgn_eq_or P ζ) v hV hprec hhA hcω (hdrift ζ) (hround ζ)
  obtain ⟨-, -, hs3, hs4⟩ := moment_sandwich P P.sigma v hcpos
  have mt := moment_tail P P.sigma v hFpos hcpos (by linarith)
  have ha' : (P.L : ℝ) * a ≤ (P.eta : ℝ) / 2 ^ 14 := by
    have h := mul_le_mul_of_nonneg_left ha hL.le
    have e : (P.L : ℝ) * ((P.eta : ℝ) / (2 ^ 14 * P.L)) = (P.eta : ℝ) / 2 ^ 14 := by
      have hL0 : (P.L : ℝ) ≠ 0 := hL.ne'
      field_simp
    linarith
  exact num_algebra hL (eta_pos P) (eta_le_one P) hω (sq_nonneg _) hFeq hcpos hc_hi rfl ha' hμ
    hpert (hs4 ▸ hs3) (mt.2.1.trans (mt.2.2.1.trans mt.2.2.2.1))

/-! ## The forms consumed by the closure (Spec `VCorrect`, uniform row law, `a_num`) -/

/-- **Theorem 4.9, interval certificates**, for the ADA grid `h_A = 2^{-qA} ≤ η/(2^32 L)`: a correct
(`VCorrect`, row law `unifD P`, accuracy `a_num`) interval response to the rowwise query `f̂_c`,
`c = S + ω`, on the band `[(1−θ)/L, (1+θ)/L]` gives the certificates for
`r = (‖v‖² + ω)/(S + ω)`. -/
theorem normBank_validate_of_hA (P : StreamParams) (qA : ℕ)
    (hqA : (1 / 2 : ℝ) ^ qA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) {V ξ S θ : ℝ}
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ ξ)
    (hS : 0 ≤ S) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16) (resp : VResponse)
    (hada : VCorrect (unifD P) (P.aNum : ℝ)
      (fhatQ P qA X (S + P.omega), true, (1 - θ) / P.L, (1 + θ) / P.L) resp) :
    ValCert (P.eta : ℝ) θ ((‖v‖ ^ 2 + P.omega) / (S + P.omega)) resp := by
  have hL := L_pos P
  cases resp with
  | num q =>
    -- an interval request never gets a numerical answer under `VCorrect`
    exact absurd hada (by simp [VCorrect])
  | accept | high | low =>
    have hic := (vCorrect_interval_iff (unifD P) _ _ _ _ _ (fun q h => by cases h)).mp hada
    rw [popMean_unifD] at hic
    refine validate_certificate P hprec hqA (by
      rw [aNum_eq]
      exact div_le_div_of_nonneg_left (eta_pos P).le (mul_pos (by norm_num) hL) (by nlinarith))
      v hv hV X hdrift hS hθ0 hθ1 (fhatQ P qA X (S + P.omega)) (fun ζ => ?_) _ hic
    have h := abs_roundH_sub_le qA (min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 /
      ((P.L : ℝ) * (S + P.omega))) 1)
    have hq0 : (1 / 2 : ℝ) ^ qA / 2 ≤ (1 / 2 : ℝ) ^ qA := by
      have : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ qA := pow_nonneg (by norm_num) _
      linarith
    exact h.trans hq0

/-- **Theorem 4.9, numerical certificate**, for the ADA grid `h_A = 2^{-qA} ≤ η/(2^32 L)`: with the
exact coarse median event of the consumed group, drift `≤ 2ξ`, `c = max(c_raw, ω/2)` and a correct
(`VCorrect`, accuracy `a_num`) numerical answer `μ̂` to `f̂_c`, `N = max(0, Lcμ̂ − ω)` satisfies
`|N − ‖v‖²| ≤ 2^{-13}η‖v‖² + ω`. -/
theorem normBank_release_of_hA (P : StreamParams) (qA : ℕ)
    (hqA : (1 / 2 : ℝ) ^ qA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L)) {V ξ c l u : ℝ} (μ : ℚ)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ 2 * ξ)
    {g : ℕ} (G : Fin g → Fin 32 → Seed P)
    (hmed : 9 / 16 * ‖aug P P.sigma v‖ ^ 2 ≤ coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ∧
      coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ≤ 23 / 16 * ‖aug P P.sigma v‖ ^ 2)
    (hcdef : c = max (coarseEst fun j l => X (G j l) + sgn P (G j l) (regIdx P) * P.sigma)
      ((P.omega : ℝ) / 2))
    (hada : VCorrect (unifD P) (P.aNum : ℝ) (fhatQ P qA X c, false, l, u) (VResponse.num μ)) :
    NumCert (P.eta : ℝ) (P.omega : ℝ) (‖v‖ ^ 2) (max 0 ((P.L : ℝ) * c * μ - P.omega)) := by
  have hcor : |(μ : ℝ) - popMean (unifD P) (fhatQ P qA X c)| ≤ P.aNum := by
    simp only [VCorrect, Bool.false_eq_true, if_false] at hada
    exact hada.2.2
  rw [popMean_unifD] at hcor
  refine release_certificate P hprec hqA (le_of_eq (aNum_eq P)) v hv hV X hdrift G hmed hcdef
    (fhatQ P qA X c) (fun ζ => ?_) hcor
  have h := abs_roundH_sub_le qA (min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 / ((P.L : ℝ) * c)) 1)
  have hq0 : (1 / 2 : ℝ) ^ qA / 2 ≤ (1 / 2 : ℝ) ^ qA := by
    have : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ qA := pow_nonneg (by norm_num) _
    linarith
  exact h.trans hq0

/-- The bank ADA's grid satisfies `h_A ≤ η/(2^32 L)` (partIII.tex L280, L391; from
eq. `R:eq:sec3_hA_def` with `a ≤ a_num`: `h_A ≤ η/(2^43 p(p+1)χL)`). Needs C-ALG's `bankAda` to be
B-ARCH's `adaParams` (C-ALG's `AdaIface.lean` is still a placeholder). -/
theorem bankAda_hA_le (P : StreamParams) (_hP : Top.ParamsOK P) :
    (1 / 2 : ℝ) ^ (Alg.bankAda P).qA ≤ (P.eta : ℝ) / (2 ^ 32 * P.L) := by
  have hq : 29 + P.eBankA ≤ (Alg.bankAda P).qA := by
    show 29 + P.eBankA ≤ B.adaQA P.bankM P.bankJ P.bankR P.eBankA P.eBankXi
    unfold B.adaQA
    exact le_trans (by omega) (le_max_left _ _)
  have h1 : (1 / 2 : ℝ) ^ (Alg.bankAda P).qA ≤ (1 / 2 : ℝ) ^ (29 + P.eBankA) :=
    pow_le_pow_of_le_one (by norm_num) (by norm_num) hq
  have hs1 : (1 : ℝ) ≤ P.s := by
    have : 1 ≤ P.s := by unfold StreamParams.s; omega
    exact_mod_cast this
  have hspos : (0 : ℝ) < P.s := by linarith
  have hs : (P.s : ℝ) ≤ 2 ^ Nat.clog 2 P.s := by exact_mod_cast Nat.le_pow_clog (by norm_num) P.s
  have hclog : (1 / 2 : ℝ) ^ Nat.clog 2 P.s ≤ 1 / P.s := by
    rw [one_div_pow, one_div_le_one_div (pow_pos (by norm_num) _) hspos]
    exact hs
  have e : (1 / 2 : ℝ) ^ (29 + P.eBankA) =
      (P.eta : ℝ) * (1 / 2) ^ 47 * (1 / 2) ^ (Nat.clog 2 P.s) := by
    rw [eta_eq]; unfold StreamParams.eBankA; ring
  have hη := eta_pos P
  calc (1 / 2 : ℝ) ^ (Alg.bankAda P).qA ≤ (1 / 2 : ℝ) ^ (29 + P.eBankA) := h1
    _ = (P.eta : ℝ) * (1 / 2) ^ 47 * (1 / 2) ^ (Nat.clog 2 P.s) := e
    _ ≤ (P.eta : ℝ) * (1 / 2) ^ 47 * (1 / P.s) :=
        mul_le_mul_of_nonneg_left hclog (mul_nonneg hη.le (by norm_num))
    _ ≤ (P.eta : ℝ) * (1 / 2) ^ 36 * (1 / P.s) := by
        apply mul_le_mul_of_nonneg_right _ (div_nonneg zero_le_one hspos.le)
        apply mul_le_mul_of_nonneg_left _ hη.le
        norm_num
    _ = (P.eta : ℝ) / (2 ^ 32 * P.L) := by
        rw [L_eq]
        have hs0 : (P.s : ℝ) ≠ 0 := hspos.ne'
        field_simp
        ring

/-- **Theorem 4.9, interval certificates** for C-ALG's bank (`h_A` of `bankAda P`). -/
theorem normBank_validate (P : StreamParams) (hP : Top.ParamsOK P) {V ξ S θ : ℝ}
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ ξ)
    (hS : 0 ≤ S) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16) (resp : VResponse)
    (hada : VCorrect (unifD P) (P.aNum : ℝ)
      (fhatQ P (Alg.bankAda P).qA X (S + P.omega), true, (1 - θ) / P.L, (1 + θ) / P.L) resp) :
    ValCert (P.eta : ℝ) θ ((‖v‖ ^ 2 + P.omega) / (S + P.omega)) resp :=
  normBank_validate_of_hA P _ (bankAda_hA_le P hP) hprec v hv hV X hdrift hS hθ0 hθ1 resp hada

/-- **Theorem 4.9, numerical certificate** for C-ALG's bank (`h_A` of `bankAda P`). -/
theorem normBank_release (P : StreamParams) (hP : Top.ParamsOK P) {V ξ c l u : ℝ} (μ : ℚ)
    (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (X : Seed P → ℝ) (hdrift : ∀ ζ, |X ζ - ∑ i, sgn P ζ i * v i| ≤ 2 * ξ)
    {g : ℕ} (G : Fin g → Fin 32 → Seed P)
    (hmed : 9 / 16 * ‖aug P P.sigma v‖ ^ 2 ≤ coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ∧
      coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ≤ 23 / 16 * ‖aug P P.sigma v‖ ^ 2)
    (hcdef : c = max (coarseEst fun j l => X (G j l) + sgn P (G j l) (regIdx P) * P.sigma)
      ((P.omega : ℝ) / 2))
    (hada : VCorrect (unifD P) (P.aNum : ℝ) (fhatQ P (Alg.bankAda P).qA X c, false, l, u)
      (VResponse.num μ)) :
    NumCert (P.eta : ℝ) (P.omega : ℝ) (‖v‖ ^ 2) (max 0 ((P.L : ℝ) * c * μ - P.omega)) :=
  normBank_release_of_hA P _ (bankAda_hA_le P hP) μ hprec v hv hV X hdrift G hmed hcdef hada

end F2e2e.C.NormBank
