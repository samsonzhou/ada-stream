import F2e2e.C.NormBank.Cert
import F2e2e.B.ArchOnline

/-!
# Theorem 4.9 in the form of B's core-level guarantee

The bank's ADA module is B-ARCH's core state machine run online (`F2e2e.B.coreRun`), and the per-bank
ADA event of the closure comes from `F2e2e.B.core_guarantee` (`F2e2e/B/Final.lean`), whose correctness
predicate is `F2e2e.B.coreCorrect` for core-level requests (grid-index queries `f`, `f̂ = h_A f`, and
rational endpoints) and the core's own outputs (`AdaCert ⊕ AdaNum`). This file restates the
deterministic certificates of Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step`
(`F2e2e/C/NormBank/Cert.lean`) for exactly the requests C-ALG's bank submits:

* `validateReq P ctr S θ`: `ValidateInterval(S, θ)` (partIII.tex L210–213) of a bank whose rows carry
  the counter mantissas `ctr ζ` on every seed `ζ` — query `queryIdx qA L (S + ω) (regZ PRIMARY)`,
  band `[(1−θ)/L, (1+θ)/L]` (C-ALG's `Bank.validate`, `adaVals`);
* `releaseReq P mode ctr c` with `c = releaseScale P mode ctr G`: `ReleaseNumerical(mode)` (L215–219)
  consuming the coarse group with seeds `G` (C-ALG's `Bank.release`), whose output is
  `N = max(0, Lcμ̂ − ω)` (ℚ);
* `normBank_validate_core`, `normBank_release_core`: the certificates from `coreCorrect` at any accuracy
  `α ≤ a_num`.
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb

/-- The core-level request of `ValidateInterval(S, θ)` (partIII.tex L210–213) for a bank whose rows
carry the counter mantissas `ctr` (on every seed). -/
def validateReq (P : StreamParams) (ctr : Seed P → ℤ × ℤ) (S θ : ℚ) : B.CoreReq (Seed P) where
  f ζ := Alg.queryIdx (Alg.bankAda P).qA P.L (S + P.omega)
    (Alg.regZ P Alg.Mode.primary (rowOf ζ (ctr ζ)))
  isInterval := true
  l := (1 - θ) / P.L
  u := (1 + θ) / P.L

/-- The core-level request of `ReleaseNumerical(mode)` at the scale `c` (partIII.tex L218). -/
def releaseReq (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) (c : ℚ) :
    B.CoreReq (Seed P) where
  f ζ := Alg.queryIdx (Alg.bankAda P).qA P.L c (Alg.regZ P mode (rowOf ζ (ctr ζ)))
  isInterval := false
  l := 0
  u := 0

/-- C-ALG's scale `c = max(c_raw, ω/2)` of `ReleaseNumerical(mode)` for the consumed coarse group
whose rows carry the seeds `G j l` (partIII.tex L217; `Bank.release`). -/
def releaseScale (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) {g : ℕ}
    (G : Fin g → Fin 32 → Seed P) : ℚ :=
  max (Alg.lowerMedian ((List.ofFn fun j => List.ofFn fun l => rowOf (G j l) (ctr (G j l))).map
    (Alg.subgroupMean P mode))) (P.omega / 2)

/-- The interval certificates of Theorem 4.9 for a core output (terminal rejections included). -/
def ValCertCore (η θ r : ℝ) (out : B.CoreOut) : Prop :=
  (out = Sum.inl B.AdaCert.accept → |r - 1| ≤ θ + η / 4) ∧
    (out = Sum.inl B.AdaCert.high ∨ out = Sum.inl B.AdaCert.termHigh → θ - η / 4 ≤ r - 1) ∧
    (out = Sum.inl B.AdaCert.low ∨ out = Sum.inl B.AdaCert.termLow → θ - η / 4 ≤ 1 - r)

theorem omega_pos_q (P : StreamParams) : (0 : ℚ) < P.omega := by
  have h := omega_pos P
  exact_mod_cast h

/-- The grid-valued query of the bank's requests is `f̂ = fhatQ`. -/
theorem hA_mul_queryIdx (P : StreamParams) (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ) {c : ℚ}
    (hc : 0 < c) (ζ : Seed P) :
    (((Alg.bankAda P).hA : ℚ) : ℝ) *
        ((Alg.queryIdx (Alg.bankAda P).qA P.L c (Alg.regZ P mode (rowOf ζ (ctr ζ))) : ℕ) : ℝ) =
      fhatQ P (Alg.bankAda P).qA (cntVal P mode ctr) (c : ℝ) ζ := by
  rw [← queryIdx_regZ_eq_fhatQ P _ mode ctr hc ζ]
  simp only [B.AdaParams.hA, Rat.cast_pow, Rat.cast_div, Rat.cast_one, Rat.cast_ofNat]
  rw [one_div, inv_pow, mul_comm, div_eq_mul_inv]

/-- The rounding error of the bank's query values. -/
theorem abs_fhatQ_sub_le (P : StreamParams) (qA : ℕ) (X : Seed P → ℝ) (c : ℝ) (ζ : Seed P) :
    |fhatQ P qA X c ζ - min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 / ((P.L : ℝ) * c)) 1| ≤
      (1 / 2 : ℝ) ^ qA := by
  have h := abs_roundH_sub_le qA (min (zrow P (sgn P ζ) P.sigma (X ζ) ^ 2 / ((P.L : ℝ) * c)) 1)
  have hq0 : (1 / 2 : ℝ) ^ qA / 2 ≤ (1 / 2 : ℝ) ^ qA := by
    have : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ qA := pow_nonneg (by norm_num) _
    linarith
  exact h.trans hq0

theorem intervalCorrect_accept {l u a μ : ℝ} (h : l - a ≤ μ ∧ μ ≤ u + a) :
    IntervalCorrect VResponse.accept l u a μ := by
  unfold IntervalCorrect
  exact ⟨fun _ => h, (fun h' => by cases h'), (fun h' => by cases h')⟩

theorem intervalCorrect_high {l u a μ : ℝ} (h : u - a ≤ μ) :
    IntervalCorrect VResponse.high l u a μ := by
  unfold IntervalCorrect
  exact ⟨(fun h' => by cases h'), (fun _ => h), (fun h' => by cases h')⟩

theorem intervalCorrect_low {l u a μ : ℝ} (h : μ ≤ l + a) :
    IntervalCorrect VResponse.low l u a μ := by
  unfold IntervalCorrect
  exact ⟨(fun h' => by cases h'), (fun h' => by cases h'), (fun _ => h)⟩

/-- **Theorem 4.9, interval certificates, core-level form**: a correct (`coreCorrect` at accuracy
`α ≤ a_num`, row law `unifD P`) output of the bank's ADA to the request of `ValidateInterval(S, θ)`
gives the certificates for `r = (‖v‖² + ω)/(S + ω)`. -/
theorem normBank_validate_core (P : StreamParams) (hP : Top.ParamsOK P) {V ξ α : ℝ}
    (hα : α ≤ P.aNum) (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (ctr : Seed P → ℤ × ℤ)
    (hdrift : ∀ ζ, |cntVal P Alg.Mode.primary ctr ζ - ∑ i, sgn P ζ i * v i| ≤ ξ)
    {S θ : ℚ} (hS : 0 ≤ S) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16) (out : B.CoreOut)
    (hada : B.coreCorrect (unifD P) (Alg.bankAda P).hA α (validateReq P ctr S θ) out) :
    ValCertCore (P.eta : ℝ) θ ((‖v‖ ^ 2 + P.omega) / (S + P.omega)) out := by
  have hL := L_pos P
  have hc : (0 : ℚ) < S + P.omega := by have := omega_pos_q P; linarith
  have hpop : popMean (unifD P) (fun ζ => (((Alg.bankAda P).hA : ℚ) : ℝ) *
        ((Alg.queryIdx (Alg.bankAda P).qA P.L (S + P.omega)
          (Alg.regZ P Alg.Mode.primary (rowOf ζ (ctr ζ))) : ℕ) : ℝ)) =
      E (fhatQ P (Alg.bankAda P).qA (cntVal P Alg.Mode.primary ctr) ((S + P.omega : ℚ) : ℝ)) := by
    rw [← popMean_unifD]
    congr 1
    funext ζ
    exact hA_mul_queryIdx P Alg.Mode.primary ctr hc ζ
  have ha : α ≤ (P.eta : ℝ) / (16 * P.L) := by
    refine hα.trans ?_
    rw [aNum_eq]
    exact div_le_div_of_nonneg_left (eta_pos P).le (mul_pos (by norm_num) hL) (by nlinarith)
  have hS' : (0 : ℝ) ≤ S := by exact_mod_cast hS
  have hθ0' : (0 : ℝ) ≤ θ := by exact_mod_cast hθ0
  have hθ1' : (θ : ℝ) ≤ (1 / 2) ^ 16 := by
    have h := (Rat.cast_le (K := ℝ)).mpr hθ1
    push_cast at h
    exact h
  have hcast : ((S + P.omega : ℚ) : ℝ) = (S : ℝ) + P.omega := by push_cast; ring
  have hl : (((1 - θ) / P.L : ℚ) : ℝ) = (1 - θ) / P.L := by push_cast; ring
  have hu : (((1 + θ) / P.L : ℚ) : ℝ) = (1 + θ) / P.L := by push_cast; ring
  have key := fun resp hresp => validate_certificate P hprec (bankAda_hA_le P hP) ha v hv hV
    (cntVal P Alg.Mode.primary ctr) hdrift hS' hθ0' hθ1'
    (fhatQ P (Alg.bankAda P).qA (cntVal P Alg.Mode.primary ctr) ((S + P.omega : ℚ) : ℝ))
    (fun ζ => by rw [← hcast]; exact abs_fhatQ_sub_le P _ _ _ ζ) resp hresp
  simp only [B.coreCorrect, validateReq, if_true, hl, hu] at hada
  rw [hpop] at hada
  refine ⟨fun h => ?_, fun h => ?_, fun h => ?_⟩
  · subst h
    simp only at hada
    exact (key VResponse.accept (intervalCorrect_accept hada)).1 rfl
  · rcases h with h | h <;> subst h <;> simp only at hada <;>
      exact (key VResponse.high (intervalCorrect_high hada)).2.1 rfl
  · rcases h with h | h <;> subst h <;> simp only at hada <;>
      exact (key VResponse.low (intervalCorrect_low hada)).2.2 rfl

/-- **Theorem 4.9, numerical certificate, core-level form**: if the exact coarse median of the
consumed group (seeds `G`) lies in `[9F'/16, 23F'/16]`, the mode counters have drift `≤ 2ξ` on every
seed, and the bank's ADA answers the request of `ReleaseNumerical(mode)` at C-ALG's scale
`c = releaseScale P mode ctr G` with a correct (`coreCorrect`, `α ≤ a_num`) value `μ̂`, then the
release `N = max(0, Lcμ̂ − ω)` satisfies `|N − ‖v‖²| ≤ 2^{-13}η‖v‖² + ω`. -/
theorem normBank_release_core (P : StreamParams) (hP : Top.ParamsOK P) {V ξ α : ℝ}
    (hα : α ≤ P.aNum) (hprec : precLhs P V ξ ≤ (P.eta : ℝ) * P.omega / 2 ^ 30)
    (v : EuclideanSpace ℝ (Fin P.Dstar)) (hv : v (regIdx P) = 0) (hV : ‖aug P P.sigma v‖ ≤ V)
    (mode : Alg.Mode) (ctr : Seed P → ℤ × ℤ)
    (hdrift : ∀ ζ, |cntVal P mode ctr ζ - ∑ i, sgn P ζ i * v i| ≤ 2 * ξ)
    {g : ℕ} (G : Fin g → Fin 32 → Seed P)
    (hmed : 9 / 16 * ‖aug P P.sigma v‖ ^ 2 ≤ coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ∧
      coarseEst (rowVals (sgn P) (aug P P.sigma v) G) ≤ 23 / 16 * ‖aug P P.sigma v‖ ^ 2)
    (μ : ℚ)
    (hada : B.coreCorrect (unifD P) (Alg.bankAda P).hA α
      (releaseReq P mode ctr (releaseScale P mode ctr G)) (Sum.inr (B.AdaNum.val μ))) :
    NumCert (P.eta : ℝ) (P.omega : ℝ) (‖v‖ ^ 2)
      ((max 0 ((P.L : ℚ) * releaseScale P mode ctr G * μ - P.omega) : ℚ) : ℝ) := by
  have hc : (0 : ℚ) < releaseScale P mode ctr G := by
    unfold releaseScale
    have := omega_pos_q P
    exact lt_of_lt_of_le (by linarith) (le_max_right _ _)
  have hpop : popMean (unifD P) (fun ζ => (((Alg.bankAda P).hA : ℚ) : ℝ) *
        ((Alg.queryIdx (Alg.bankAda P).qA P.L (releaseScale P mode ctr G)
          (Alg.regZ P mode (rowOf ζ (ctr ζ))) : ℕ) : ℝ)) =
      E (fhatQ P (Alg.bankAda P).qA (cntVal P mode ctr) ((releaseScale P mode ctr G : ℚ) : ℝ)) := by
    rw [← popMean_unifD]
    congr 1
    funext ζ
    exact hA_mul_queryIdx P mode ctr hc ζ
  have hcdef : ((releaseScale P mode ctr G : ℚ) : ℝ) =
      max (coarseEst fun j l => zrow P (sgn P (G j l)) P.sigma (cntVal P mode ctr (G j l)))
        ((P.omega : ℝ) / 2) := release_scale_eq P mode ctr G
  simp only [B.coreCorrect, releaseReq, Bool.false_eq_true, if_false] at hada
  rw [hpop] at hada
  have hμ : |(μ : ℝ) - E (fhatQ P (Alg.bankAda P).qA (cntVal P mode ctr)
      ((releaseScale P mode ctr G : ℚ) : ℝ))| ≤ α := hada.2.2
  have h := release_certificate P hprec (bankAda_hA_le P hP) (hα.trans (le_of_eq (aNum_eq P))) v
    hv hV (cntVal P mode ctr) hdrift G hmed hcdef _ (fun ζ => abs_fhatQ_sub_le P _ _ _ ζ) hμ
  have hN : ((max 0 ((P.L : ℚ) * releaseScale P mode ctr G * μ - P.omega) : ℚ) : ℝ) =
      max 0 ((P.L : ℝ) * (releaseScale P mode ctr G : ℝ) * μ - P.omega) := by
    push_cast; ring_nf
  rw [hN]
  exact h

end F2e2e.C.NormBank
