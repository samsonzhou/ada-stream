import Mathlib
import F2e2e.C.ClosureEvents

/-!
# Transcripts of a bank's ADA module: coverage and correctness of one call

Helpers for `F2e2e/C/ClosureBank.lean` (`coreCorrect_of_adaGood`): pure list combinatorics on B's
core-level transcripts (`F2e2e.B.coreCovered`, `coreFails`; partII.tex, the coverage clause of Theorem
`R:thm:validation_ada`) and C-CLOSE's transcript of a bank (`adaTranscript`, `ctrlOf`).

* `callsTranscript P lab cs`: the transcript of bank `lab` in a call list (`adaTranscript_eq_calls`);
* `coreCovered_prefix`: coverage of a round only depends on the transcript up to that round;
* `coreCovered_last`: a round is covered if at most `J` rejections precede it and the interval (resp.
  numerical) requests up to it are at most `M` (resp. `R`);
* `coreCorrect_of_noFail`: if no covered round of the final transcript is incorrect, every covered round of
  a prefix is correct.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## The transcript of a call list -/

/-- The ADA transcript of bank `lab` in a call list (`adaTranscript P lab g = callsTranscript P lab g.calls`). -/
def callsTranscript (P : StreamParams) (lab : BankLabel) (cs : List CallRec) :
    List (CoreReq (Seed P) × CoreOut) :=
  cs.filterMap fun rec => if rec.lab = lab then rec.out.map fun o => (callReq P rec, o) else none

theorem adaTranscript_eq_calls (P : StreamParams) (lab : BankLabel) (g : Ghost) :
    adaTranscript P lab g = callsTranscript P lab g.calls := rfl

theorem callsTranscript_append (P : StreamParams) (lab : BankLabel) (cs cs' : List CallRec) :
    callsTranscript P lab (cs ++ cs') = callsTranscript P lab cs ++ callsTranscript P lab cs' := by
  unfold callsTranscript
  exact List.filterMap_append

theorem callsTranscript_singleton (P : StreamParams) {lab : BankLabel} {rec : CallRec} {out : CoreOut}
    (hlab : rec.lab = lab) (hout : rec.out = some out) :
    callsTranscript P lab [rec] = [(callReq P rec, out)] := by
  simp [callsTranscript, hlab, hout]

theorem callsTranscript_prefix (P : StreamParams) (lab : BankLabel) {cs cs' : List CallRec}
    (h : cs <+: cs') : callsTranscript P lab cs <+: callsTranscript P lab cs' := by
  obtain ⟨t, rfl⟩ := h
  rw [callsTranscript_append]
  exact List.prefix_append _ _

/-- Counting the entries of a `filterMap` with a property. -/
theorem length_filter_filterMap {α β : Type} (f : α → Option β) (q : β → Bool) (l : List α) :
    ((l.filterMap f).filter q).length = (l.filter fun a => (f a).any q).length := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    rw [List.filterMap_cons]
    cases h : f a with
    | none =>
      simp only [List.filter_cons, h, Option.any_none, Bool.false_eq_true, if_false]
      exact ih
    | some b =>
      simp only [List.filter_cons, h, Option.any_some]
      split_ifs <;> simp [ih]

/-! ## Transcript combinatorics (generic) -/

section Generic

variable {U : Type}

/-- The default transcript entry (as used by `ctrlOf` and `coreOutAt` beyond the end). -/
def trDefault (U : Type) : CoreReq U × CoreOut := (defaultReq U, Sum.inl AdaCert.abort)

theorem coreReqAt_ctrlOf (tr : List (CoreReq U × CoreOut)) {i : ℕ} (hi : i ≤ tr.length) :
    coreReqAt (ctrlOf tr) (tr.map Prod.snd) i = (tr.getD i (trDefault U)).1 := by
  unfold coreReqAt ctrlOf
  rw [List.length_take, List.length_map, min_eq_left hi]
  rfl

theorem coreOutAt_map (tr : List (CoreReq U × CoreOut)) (i : ℕ) :
    coreOutAt (tr.map Prod.snd) i = (tr.getD i (trDefault U)).2 := by
  unfold coreOutAt
  exact List.getD_map tr (trDefault U) Prod.snd

theorem getD_of_prefix {tr tr' : List (CoreReq U × CoreOut)} (h : tr <+: tr') {i : ℕ}
    (hi : i < tr.length) (d : CoreReq U × CoreOut) : tr'.getD i d = tr.getD i d := by
  obtain ⟨t, rfl⟩ := h
  exact List.getD_append _ _ _ _ hi

/-- Coverage of round `j` only depends on the requests of rounds `≤ j` and the outputs of rounds `< j`. -/
theorem coreCovered_congr (A : AdaParams) {ctrl ctrl' : CoreCtrl U} {o o' : List CoreOut} {j : ℕ}
    (hreq : ∀ i ≤ j, coreReqAt ctrl o i = coreReqAt ctrl' o' i)
    (hout : ∀ i < j, coreOutAt o i = coreOutAt o' i) :
    coreCovered A ctrl o j ↔ coreCovered A ctrl' o' j := by
  unfold coreCovered
  have h1 : (Finset.range j).filter (fun i => (coreReqAt ctrl o i).isInterval = true ∧
        ((Finset.range (i + 1)).filter (fun i' => (coreReqAt ctrl o i').isInterval = true)).card ≤
          A.M ∧ coreIsReject (coreOutAt o i) = true) =
      (Finset.range j).filter (fun i => (coreReqAt ctrl' o' i).isInterval = true ∧
        ((Finset.range (i + 1)).filter (fun i' => (coreReqAt ctrl' o' i').isInterval = true)).card ≤
          A.M ∧ coreIsReject (coreOutAt o' i) = true) := by
    apply Finset.filter_congr
    intro i hi
    have hi' : i < j := Finset.mem_range.mp hi
    have hin : (Finset.range (i + 1)).filter (fun i' => (coreReqAt ctrl o i').isInterval = true) =
        (Finset.range (i + 1)).filter (fun i' => (coreReqAt ctrl' o' i').isInterval = true) := by
      apply Finset.filter_congr
      intro i' hi''
      have := Finset.mem_range.mp hi''
      rw [hreq i' (by omega)]
    rw [hin, hreq i hi'.le, hout i hi']
  have h2 : (Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl o i).isInterval = true) =
      (Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl' o' i).isInterval = true) := by
    apply Finset.filter_congr
    intro i hi
    have := Finset.mem_range.mp hi
    rw [hreq i (by omega)]
  have h3 : (Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl o i).isInterval = false) =
      (Finset.range (j + 1)).filter (fun i => (coreReqAt ctrl' o' i).isInterval = false) := by
    apply Finset.filter_congr
    intro i hi
    have := Finset.mem_range.mp hi
    rw [hreq i (by omega)]
  rw [h1, h2, h3, hreq j le_rfl]

/-- Coverage of a round of a transcript is decided by any transcript extending it. -/
theorem coreCovered_prefix (A : AdaParams) {tr tr' : List (CoreReq U × CoreOut)} (h : tr <+: tr')
    {j : ℕ} (hj : j < tr.length) :
    coreCovered A (ctrlOf tr') (tr'.map Prod.snd) j ↔ coreCovered A (ctrlOf tr) (tr.map Prod.snd) j := by
  have hlen : tr.length ≤ tr'.length := h.length_le
  apply coreCovered_congr
  · intro i hi
    rw [coreReqAt_ctrlOf tr' (by omega), coreReqAt_ctrlOf tr (by omega), getD_of_prefix h (by omega)]
  · intro i hi
    rw [coreOutAt_map, coreOutAt_map, getD_of_prefix h (by omega)]

/-- Counting the indices of a list with a property. -/
theorem card_filter_range_getD {α : Type} (p : α → Bool) (d : α) (l : List α) :
    ((Finset.range l.length).filter (fun j => p (l.getD j d) = true)).card = (l.filter p).length := by
  induction l using List.reverseRecOn with
  | nil => simp
  | append_singleton l a ih =>
    rw [List.length_append, List.length_singleton, Finset.range_add_one, Finset.filter_insert]
    have hcongr : (Finset.range l.length).filter (fun j => p ((l ++ [a]).getD j d) = true) =
        (Finset.range l.length).filter (fun j => p (l.getD j d) = true) := by
      apply Finset.filter_congr
      intro j hj
      rw [List.getD_append _ _ _ _ (Finset.mem_range.mp hj)]
    have hlast : (l ++ [a]).getD l.length d = a := by
      rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
      rfl
    rw [hcongr, hlast, List.filter_append]
    by_cases hpa : p a = true
    · rw [if_pos hpa, Finset.card_insert_of_notMem (by simp), ih, List.length_append]
      simp [hpa]
    · rw [if_neg hpa, ih, List.length_append]
      simp [hpa]

/-- **Coverage of the last round from counts**: at most `J` rejections before it, and at most `M`
interval (resp. `R` numerical) requests up to it. -/
theorem coreCovered_last (A : AdaParams) (tr0 : List (CoreReq U × CoreOut)) (e : CoreReq U × CoreOut)
    (hJ : (tr0.filter fun x => coreIsReject x.2).length ≤ A.J)
    (hM : e.1.isInterval = true → (tr0.filter fun x => x.1.isInterval).length + 1 ≤ A.M)
    (hR : e.1.isInterval = false → (tr0.filter fun x => !x.1.isInterval).length + 1 ≤ A.R) :
    coreCovered A (ctrlOf (tr0 ++ [e])) ((tr0 ++ [e]).map Prod.snd) tr0.length := by
  have hlen : (tr0 ++ [e]).length = tr0.length + 1 := by simp
  have hreq : ∀ i ≤ tr0.length, coreReqAt (ctrlOf (tr0 ++ [e])) ((tr0 ++ [e]).map Prod.snd) i =
      ((tr0 ++ [e]).getD i (trDefault U)).1 := fun i hi => coreReqAt_ctrlOf _ (by omega)
  have hlast : (tr0 ++ [e]).getD tr0.length (trDefault U) = e := by
    rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
    rfl
  have hearly : ∀ i < tr0.length, (tr0 ++ [e]).getD i (trDefault U) = tr0.getD i (trDefault U) :=
    fun i hi => List.getD_append _ _ _ _ hi
  refine ⟨?_, ?_, ?_⟩
  · refine le_trans (Finset.card_le_card (t := (Finset.range tr0.length).filter
      (fun j => (fun x : CoreReq U × CoreOut => coreIsReject x.2) (tr0.getD j (trDefault U)) = true)) ?_) ?_
    · intro j hj
      simp only [Finset.mem_filter] at hj ⊢
      refine ⟨hj.1, ?_⟩
      have h3 := hj.2.2.2
      rw [coreOutAt_map, hearly j (Finset.mem_range.mp hj.1)] at h3
      exact h3
    · rw [card_filter_range_getD (fun x : CoreReq U × CoreOut => coreIsReject x.2)]
      exact hJ
  · intro hI
    rw [hreq _ le_rfl, hlast] at hI
    have hcount : (Finset.range (tr0.length + 1)).filter
        (fun j => (coreReqAt (ctrlOf (tr0 ++ [e])) ((tr0 ++ [e]).map Prod.snd) j).isInterval = true) =
        (Finset.range (tr0 ++ [e]).length).filter
          (fun j => (fun x : CoreReq U × CoreOut => x.1.isInterval) ((tr0 ++ [e]).getD j (trDefault U)) = true) := by
      rw [hlen]
      apply Finset.filter_congr
      intro j hj
      rw [hreq j (by have := Finset.mem_range.mp hj; omega)]
    rw [hcount, card_filter_range_getD (fun x : CoreReq U × CoreOut => x.1.isInterval),
      List.filter_append]
    have := hM hI
    simp [hI]
    omega
  · intro hI
    rw [hreq _ le_rfl, hlast] at hI
    have hcount : (Finset.range (tr0.length + 1)).filter
        (fun j => (coreReqAt (ctrlOf (tr0 ++ [e])) ((tr0 ++ [e]).map Prod.snd) j).isInterval = false) =
        (Finset.range (tr0 ++ [e]).length).filter
          (fun j => (fun x : CoreReq U × CoreOut => !x.1.isInterval) ((tr0 ++ [e]).getD j (trDefault U)) = true) := by
      rw [hlen]
      apply Finset.filter_congr
      intro j hj
      rw [hreq j (by have := Finset.mem_range.mp hj; omega)]
      simp
    rw [hcount, card_filter_range_getD (fun x : CoreReq U × CoreOut => !x.1.isInterval),
      List.filter_append]
    have := hR hI
    simp [hI]
    omega

/-- **Correctness of a covered round of a prefix** from the absence of failures on the final transcript. -/
theorem coreCorrect_of_noFail [Fintype U] (A : AdaParams) {D : U → ℝ} {α : ℝ}
    {trF : List (CoreReq U × CoreOut)} (hgood : ¬ coreFails A D α (ctrlOf trF) (trF.map Prod.snd))
    {tr0 : List (CoreReq U × CoreOut)} {e : CoreReq U × CoreOut} (hpre : tr0 ++ [e] <+: trF)
    (hcov : coreCovered A (ctrlOf (tr0 ++ [e])) ((tr0 ++ [e]).map Prod.snd) tr0.length) :
    coreCorrect D A.hA α e.1 e.2 := by
  by_contra hc
  apply hgood
  have hlen : (tr0 ++ [e]).length ≤ trF.length := hpre.length_le
  have hl : tr0.length < (tr0 ++ [e]).length := by simp
  have hlast : (tr0 ++ [e]).getD tr0.length (trDefault U) = e := by
    rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
    rfl
  refine ⟨tr0.length, by rw [List.length_map]; omega, (coreCovered_prefix A hpre hl).mpr hcov, ?_⟩
  rw [coreReqAt_ctrlOf trF (by omega), coreOutAt_map, getD_of_prefix hpre hl, hlast]
  exact hc

end Generic

end F2e2e.C.Closure
