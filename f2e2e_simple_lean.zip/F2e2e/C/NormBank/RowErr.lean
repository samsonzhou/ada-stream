import Mathlib
import F2e2e.C.ClosureRows
import F2e2e.C.NormBank.Core
import F2e2e.C.Precision

/-!
# Hypothetical rows of a bank: seeds, signs, rounding (helpers for `F2e2e/C/ClosureBank.lean`)

* `rowFun_seed`, `rowCtr`, `rowOf_rowCtr`: the hypothetical row of seed `ζ` carries the seed `ζ` and the counter
  mantissas `rowCtr P hist ζ` (so the bank's ADA queries are C-BANK's `validateReq`/`releaseReq` of these
  counters); `rowSign_rowFun`: its sign at the 1-based coordinate `i` is `sgn` at the Lean index `i − 1`;
* `bankShadowXY_append`: the exact shadows follow the history step by step;
* the rounding errors of the row operations (`abs_roundMant_sub_le`, `abs_guardIncr_sub_le`,
  `abs_scaleMant_sub_le`: at most `h_b/2`) and `counter_step`, the one-step error recurrence of a counter
  without saturation (Lemma 6.1 (i), (iv), partIII.tex L1055, L1083–1087);
* the request bridges `callReq_validate_eq`, `callReq_release_eq`, and the release scale of a coarse group of
  hypothetical rows (`releaseScale_eq_of_rows`);
* `precLhs_xi_le` (the Norm-Bank precision premise at `V`, `ξ`), `norm_aug_le_of_sqrt`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Seeds and signs of hypothetical rows -/

theorem foldl_apply_seed (P : StreamParams) :
    ∀ (hist : List RowOp) (r : Row), (hist.foldl (fun r op => op.apply P r) r).seed = r.seed
  | [], _ => rfl
  | op :: hist, r => by
    rw [List.foldl_cons, foldl_apply_seed P hist (op.apply P r), rowOp_apply_seed]

theorem rowFun_seed (P : StreamParams) (hist : List RowOp) (ζ : Seed P) :
    (rowFun P hist ζ).seed = Hash.seedCoeffs ζ := by
  unfold rowFun
  rw [foldl_apply_seed, rowOf_seed]

/-- The counter mantissas `(X, Y)` of the hypothetical row of seed `ζ` after the history `hist`. -/
def rowCtr (P : StreamParams) (hist : List RowOp) (ζ : Seed P) : ℤ × ℤ :=
  ((rowFun P hist ζ).X, (rowFun P hist ζ).Y)

theorem rowOf_rowCtr (P : StreamParams) (hist : List RowOp) (ζ : Seed P) :
    rowOf ζ (rowCtr P hist ζ) = rowFun P hist ζ := by
  have hs := rowFun_seed P hist ζ
  unfold rowCtr
  generalize rowFun P hist ζ = r at hs ⊢
  obtain ⟨seed, X, Y⟩ := r
  simp only at hs
  subst hs
  simp only [rowOf]

/-- The sign of the hypothetical row of seed `ζ` at the 1-based coordinate `i` is `sgn P ζ` at the Lean index
`i − 1`. -/
theorem rowSign_rowFun (P : StreamParams) (hist : List RowOp) (ζ : Seed P) {i : ℕ} (h1 : 1 ≤ i)
    (h2 : i ≤ P.Dstar) :
    ((rowSign P (rowFun P hist ζ) i : ℤ) : ℝ) = sgn P ζ ⟨i - 1, by omega⟩ := by
  rw [← rowOf_rowCtr P hist ζ]
  have h := rowSign_seedCoeffs P ζ (rowCtr P hist ζ) ⟨i - 1, by omega⟩
  have hi : i - 1 + 1 = i := by omega
  simp only [hi] at h
  exact h

theorem bankShadowXY_append (P : StreamParams) (hist : List RowOp) (op : RowOp) :
    bankShadowXY P (hist ++ [op]) = shadowStep P (bankShadowXY P hist) op := by
  unfold bankShadowXY
  rw [List.foldl_append]
  rfl

/-! ## Rounding and saturation -/

theorem sat_eq_of_abs_le {Z z : ℤ} (h : |z| ≤ Z) : sat Z z = z := by
  unfold sat
  rw [abs_le] at h
  rw [min_eq_right h.2, max_eq_right h.1]

theorem abs_roundMant_sub_le_q (q : ℕ) (z : ℚ) :
    |((roundMant q z : ℤ) : ℚ) - z * 2 ^ q| ≤ 1 / 2 := by
  unfold roundMant
  have h1 := Int.floor_le (z * 2 ^ q + 1 / 2)
  have h2 := Int.lt_floor_add_one (z * 2 ^ q + 1 / 2)
  rw [abs_le]
  constructor <;> linarith

/-- Nearest rounding to the grid `2^{-q}` (ties up) errs by at most half a grid step. -/
theorem abs_roundMant_sub_le (q : ℕ) (z : ℚ) :
    |((roundMant q z : ℤ) : ℝ) - (z : ℝ) * 2 ^ q| ≤ 1 / 2 := by
  have h := (Rat.cast_le (K := ℝ)).mpr (abs_roundMant_sub_le_q q z)
  push_cast at h
  exact h

theorem hb_mul_two_pow (P : StreamParams) : (P.hb : ℝ) * 2 ^ P.eHb = 1 := by
  unfold StreamParams.hb
  push_cast
  rw [← mul_pow]
  norm_num

/-- The real value of a guard increment is within `h_b/2` of `δ b_g` (Algorithm L491). -/
theorem abs_guardIncr_sub_le (P : StreamParams) (r : Row) (g : ℕ) (δ : ℤ) :
    |((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * ((rowSign P r g : ℤ) : ℝ)| ≤
      P.hb / 2 := by
  have h := abs_roundMant_sub_le P.eHb (gridVal P.eHg (δ * rowSign P r g))
  have hb0 : (0 : ℝ) < P.hb := hb_pos P
  have hgv : ((gridVal P.eHg (δ * rowSign P r g) : ℚ) : ℝ) =
      ((gridVal P.eHg δ : ℚ) : ℝ) * ((rowSign P r g : ℤ) : ℝ) := by
    unfold gridVal
    push_cast
    ring
  have e : ((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * ((rowSign P r g : ℤ) : ℝ) =
      (((roundMant P.eHb (gridVal P.eHg (δ * rowSign P r g)) : ℤ) : ℝ) -
        ((gridVal P.eHg (δ * rowSign P r g) : ℚ) : ℝ) * 2 ^ P.eHb) * P.hb := by
    rw [hgv]
    unfold guardIncr
    have := hb_mul_two_pow P
    linear_combination (((gridVal P.eHg δ : ℚ) : ℝ) * ((rowSign P r g : ℤ) : ℝ)) * this
  rw [e, abs_mul, abs_of_pos hb0]
  calc _ ≤ 1 / 2 * (P.hb : ℝ) := mul_le_mul_of_nonneg_right h hb0.le
    _ = P.hb / 2 := by ring

/-- The real value of a rescaled counter is within `h_b/2` of `c` times the old value (Algorithm L505). -/
theorem abs_scaleMant_sub_le (P : StreamParams) (c m : ℤ) :
    |((scaleMant P.eHstep c m : ℤ) : ℝ) * P.hb - ((gridVal P.eHstep c : ℚ) : ℝ) * ((m : ℝ) * P.hb)| ≤
      P.hb / 2 := by
  have h := abs_roundMant_sub_le 0 ((c : ℚ) * m / 2 ^ P.eHstep)
  have hb0 : (0 : ℝ) < P.hb := hb_pos P
  have e : ((scaleMant P.eHstep c m : ℤ) : ℝ) * P.hb - ((gridVal P.eHstep c : ℚ) : ℝ) * ((m : ℝ) * P.hb) =
      (((roundMant 0 ((c : ℚ) * m / 2 ^ P.eHstep) : ℤ) : ℝ) -
        (((c : ℚ) * m / 2 ^ P.eHstep : ℚ) : ℝ) * 2 ^ 0) * P.hb := by
    unfold scaleMant gridVal
    push_cast
    ring
  rw [e, abs_mul, abs_of_pos hb0]
  calc _ ≤ 1 / 2 * (P.hb : ℝ) := mul_le_mul_of_nonneg_right h hb0.le
    _ = P.hb / 2 := by ring

/-- **One counter update without saturation** (Lemma 6.1 (i), the one-step error recurrence
`e_{τ+1} = a_τ e_τ + ζ_τ`, partIII.tex L1055; no saturation, L1087): if the proposed mantissa `y` satisfies
`y h_b = a (x h_b) + d + z₀` and the exact measurement follows `m' = a m + d`, with `|z₀| ≤ h_b`, `|a| ≤ 2`
and `|m'| + 2|x h_b − m| + h_b ≤ Z_max`, then the saturated counter is `y` and its error follows
`e' = a e + z₀`. -/
theorem counter_step (P : StreamParams) {x y : ℤ} {m m' a d z0 : ℝ}
    (hy : (y : ℝ) * P.hb = a * ((x : ℝ) * P.hb) + d + z0) (hm : m' = a * m + d)
    (hz0 : |z0| ≤ P.hb) (ha : |a| ≤ 2)
    (hsat : |m'| + 2 * |(x : ℝ) * P.hb - m| + P.hb ≤ P.Zmax) :
    ((sat (zSat P) y : ℤ) : ℝ) * P.hb - m' = a * ((x : ℝ) * P.hb - m) + z0 := by
  have hb0 : (0 : ℝ) < P.hb := hb_pos P
  have he : (y : ℝ) * P.hb - m' = a * ((x : ℝ) * P.hb - m) + z0 := by rw [hy, hm]; ring
  have hyb : |(y : ℝ) * P.hb| ≤ P.Zmax := by
    have hsplit : (y : ℝ) * P.hb = m' + a * ((x : ℝ) * P.hb - m) + z0 := by linarith
    have e1 := abs_add_le (m' + a * ((x : ℝ) * P.hb - m)) z0
    have e2 := abs_add_le m' (a * ((x : ℝ) * P.hb - m))
    have h2 : |a * ((x : ℝ) * P.hb - m)| ≤ 2 * |(x : ℝ) * P.hb - m| := by
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_right ha (abs_nonneg _)
    rw [hsplit]
    linarith
  have hyZ : |y| ≤ zSat P := by
    have h3 : ((|y| : ℤ) : ℝ) ≤ (P.Zmax : ℝ) * 2 ^ P.eHb := by
      have h4 : |(y : ℝ)| * P.hb ≤ P.Zmax := by rwa [abs_mul, abs_of_pos hb0] at hyb
      have h2p : (0 : ℝ) < 2 ^ P.eHb := by positivity
      calc ((|y| : ℤ) : ℝ) = |(y : ℝ)| * P.hb * 2 ^ P.eHb := by
            rw [Int.cast_abs, mul_assoc, hb_mul_two_pow, mul_one]
        _ ≤ P.Zmax * 2 ^ P.eHb := mul_le_mul_of_nonneg_right h4 h2p.le
    unfold zSat
    exact_mod_cast h3
  rw [sat_eq_of_abs_le hyZ]
  exact he

/-! ## Requests and scales of logged calls -/

/-- The Norm-Bank precision premise `R:eq:bank-precision-premise` at `V` and `ξ = G(T+1)h_b`. -/
theorem precLhs_xi_le (P : StreamParams) :
    precLhs P (P.V : ℝ) (Precision.xi P) ≤ (P.eta : ℝ) * P.omega / 2 ^ 30 := by
  unfold precLhs
  exact Precision.bank_precision_premise P

/-- The tree's form `√(‖v‖² + ω) ≤ V` of the augmented bound `‖v⁺‖ ≤ V` (eq. `R:eq:augmented-V-bound`). -/
theorem norm_aug_le_of_sqrt (P : StreamParams) {v : EuclideanSpace ℝ (Fin P.Dstar)}
    (hv : v (regIdx P) = 0) {V : ℝ} (hV : √(‖v‖ ^ 2 + (P.omega : ℝ)) ≤ V) : ‖aug P P.sigma v‖ ≤ V := by
  rw [← Real.sqrt_sq (norm_nonneg (aug P P.sigma v)), norm_sq_aug P _ v hv, ← NormBank.omega_eq]
  exact hV

/-- The request of a logged `ValidateInterval(S, θ)` call is C-BANK's `validateReq` of the hypothetical
counters. -/
theorem callReq_validate_eq (P : StreamParams) (rec : CallRec) {S θ : ℚ}
    (hkind : rec.kind = CallKind.validate S θ) (hscale : rec.scale = S + P.omega) :
    callReq P rec = validateReq P (rowCtr P rec.hist) S θ := by
  unfold callReq validateReq
  rw [hkind]
  simp only [hscale, rowOf_rowCtr]

/-- The request of a logged `ReleaseNumerical(mode)` call is C-BANK's `releaseReq` of the hypothetical
counters at the logged scale. -/
theorem callReq_release_eq (P : StreamParams) (rec : CallRec) {mode : Mode}
    (hkind : rec.kind = CallKind.release mode) :
    callReq P rec = releaseReq P mode (rowCtr P rec.hist) rec.scale := by
  unfold callReq releaseReq
  rw [hkind]
  simp only [rowOf_rowCtr]

/-- A coarse group of hypothetical rows (`g` subgroups of `32`) is the group of hypothetical rows of its
seeds. -/
theorem ofFn_groupRows (P : StreamParams) (hist : List RowOp) (grp : List (List Row))
    (hlen : grp.length = P.gCoarse) (hsub : ∀ sub ∈ grp, sub.length = 32)
    (hrows : ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P hist r) :
    (List.ofFn fun j : Fin P.gCoarse => List.ofFn fun l : Fin 32 =>
      rowOf (groupSeeds P grp j l) (rowCtr P hist (groupSeeds P grp j l))) = grp := by
  apply List.ext_getElem
  · simp [hlen]
  · intro j h1 h2
    rw [List.getElem_ofFn]
    have hmem : grp[j] ∈ grp := List.getElem_mem h2
    apply List.ext_getElem
    · simp [hsub _ hmem]
    · intro l h3 h4
      rw [List.getElem_ofFn]
      have hr := hrows _ hmem _ (List.getElem_mem h4)
      have hG : ∀ (hj : j < P.gCoarse) (hl : l < 32),
          groupSeeds P grp ⟨j, hj⟩ ⟨l, hl⟩ = seedOfRow P grp[j][l] := by
        intro hj hl
        simp only [groupSeeds]
        rw [List.getD_eq_getElem _ _ h2, List.getD_eq_getElem _ _ h4]
      rw [hG, rowOf_rowCtr]
      exact hr.2.symm

/-- C-ALG's release scale on a coarse group of hypothetical rows is C-BANK's `releaseScale` of the group's
seeds. -/
theorem releaseScale_eq_of_rows (P : StreamParams) (mode : Mode) (hist : List RowOp)
    (grp : List (List Row)) (hlen : grp.length = P.gCoarse) (hsub : ∀ sub ∈ grp, sub.length = 32)
    (hrows : ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P hist r) :
    releaseScale P mode (rowCtr P hist) (groupSeeds P grp) =
      max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2) := by
  unfold releaseScale
  rw [ofFn_groupRows P hist grp hlen hsub hrows]

end F2e2e.C.Closure
