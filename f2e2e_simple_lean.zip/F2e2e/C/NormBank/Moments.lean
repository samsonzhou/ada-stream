import F2e2e.C.NormBank.Defs

/-!
# Lemma 4.7: global fourth-moment sandwich and high-scale `2s`-moment tail

Source: `parts/partIII.tex` Lemma `R:lem:two-regime-moments` (L228–240, proof L242–270), for the bank's
`2s`-wise independent rows (`s = log₂(1/η) + 22`, `L = 16s`), any vector `v`, regularizer `σ`
(`ω = σ²`), augmented vector `v⁺ = aug P σ v` with `F' = ‖v⁺‖²` (`= ‖v‖² + ω` for a shadow,
`norm_sq_aug`), scale `c > 0`, `r = F'/c`, `Z = ⟨b, v⁺⟩` and `f = min{Z²/(Lc), 1}`:

* (i) `moment_sandwich`: `r/(L+3r) = F'/(Lc+3F') ≤ E f ≤ F'/(Lc) = r/L` (eq.
  `R:eq:global-fourth-moment-sandwich`);
* (ii) `moment_tail`: if `c ≥ F'/2` (`r ≤ 2`),
  `0 ≤ r/L − E f ≤ (r/L)(2sr/L)^{s−1}·2s ≤ (r/L)·2s·4^{−(s−1)} ≤ (η/2^16)(r/L) < (η/2^13)(r/L)`
  (eq. `R:eq:high-scale-2s-tail`);
* `two_s_quarter_pow_le`: Part II eq. `R:eq:param-s-bound`, `2s·4^{−(s−1)} ≤ 2^{−16}η`.

The pure probability is LIB-HASH-AMS's (`F2e2e/Lib/FinProb/Sandwich.lean`); this file specializes it
to the bank's rows and parameters (`4^{-(s-1)}` is written `(1/4)^(s-1)`).
-/

namespace F2e2e.C.NormBank

open F2e2e.FinProb Finset

/-- `E f_{v,c}` is LIB-HASH-AMS's clipped mean for the vector `u = v⁺`. -/
theorem E_fIdeal_eq (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) (c : ℝ) :
    E (fIdeal P σ v c) =
      E (fun ζ : Seed P => min ((∑ i, sgn P ζ i * aug P σ v i) ^ 2 / ((P.L : ℝ) * c)) 1) := rfl

/-- **Lemma 4.7 (i)** (global fourth-moment Cauchy–Schwarz sandwich,
eq. `R:eq:global-fourth-moment-sandwich`): for every `c > 0`, with `F' = ‖v⁺‖²` and `r = F'/c`,
`r/(L+3r) = F'/(Lc+3F') ≤ E f_{v,c} ≤ F'/(Lc) = r/L`. -/
theorem moment_sandwich (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) {c : ℝ}
    (hc : 0 < c) :
    ‖aug P σ v‖ ^ 2 / c / ((P.L : ℝ) + 3 * (‖aug P σ v‖ ^ 2 / c)) =
        ‖aug P σ v‖ ^ 2 / ((P.L : ℝ) * c + 3 * ‖aug P σ v‖ ^ 2) ∧
      ‖aug P σ v‖ ^ 2 / ((P.L : ℝ) * c + 3 * ‖aug P σ v‖ ^ 2) ≤ E (fIdeal P σ v c) ∧
      E (fIdeal P σ v c) ≤ ‖aug P σ v‖ ^ 2 / ((P.L : ℝ) * c) ∧
      ‖aug P σ v‖ ^ 2 / ((P.L : ℝ) * c) = ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) := by
  have hb := sgn_isKWiseSigns P
  have hF : ‖aug P σ v‖ ^ 2 = ∑ i, (aug P σ v) i ^ 2 := norm_sq_eq_sum P _
  refine ⟨ratio_div_add _ hc, ?_, ?_, (ratio_div _ _ _).symm⟩
  · rw [E_fIdeal_eq, hF]
    exact hb.le_E_clip (four_le_two_s P) _ (L_pos P) hc
  · rw [E_fIdeal_eq, hF]
    exact hb.E_clip_le (by have := four_le_two_s P; omega) _ _ _

/-- Part II eq. `R:eq:param-s-bound` for the bank: `2s · 4^{-(s-1)} ≤ 2^{-16} η`. -/
theorem two_s_quarter_pow_le (P : StreamParams) :
    2 * (P.s : ℝ) * (1 / 4 : ℝ) ^ (P.s - 1) ≤ (P.eta : ℝ) / 2 ^ 16 := by
  have h := two_mul_quarter_pow_le P.eEta
  rw [s_eq, eta_eq, show P.s - 1 = P.eEta + 22 - 1 from rfl]
  calc 2 * ((P.eEta : ℝ) + 22) * (1 / 4 : ℝ) ^ (P.eEta + 22 - 1)
      ≤ (1 / 2 : ℝ) ^ 16 * (1 / 2 : ℝ) ^ P.eEta := h
    _ = (1 / 2 : ℝ) ^ P.eEta / 2 ^ 16 := by ring

/-- **Lemma 4.7 (ii)** (high-scale `2s`-moment clipping tail, eq. `R:eq:high-scale-2s-tail`): whenever
`c ≥ F'/2` (equivalently `r = F'/c ≤ 2`),
`0 ≤ r/L − E f ≤ (r/L)(2sr/L)^{s−1}·2s ≤ (r/L)·2s·4^{−(s−1)} ≤ (η/2^16)(r/L) < (η/2^13)(r/L)`.
(`F' > 0`, e.g. `σ ≠ 0` for a shadow, is used only for the last, strict, inequality.) -/
theorem moment_tail (P : StreamParams) (σ : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) {c : ℝ}
    (hF : 0 < ‖aug P σ v‖ ^ 2) (hc : 0 < c) (hr : ‖aug P σ v‖ ^ 2 ≤ 2 * c) :
    0 ≤ ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) - E (fIdeal P σ v c) ∧
      ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) - E (fIdeal P σ v c) ≤
        ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) *
            (2 * (P.s : ℝ) * (‖aug P σ v‖ ^ 2 / c) / (P.L : ℝ)) ^ (P.s - 1) * (2 * (P.s : ℝ)) ∧
      ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) *
            (2 * (P.s : ℝ) * (‖aug P σ v‖ ^ 2 / c) / (P.L : ℝ)) ^ (P.s - 1) * (2 * (P.s : ℝ)) ≤
        ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) * (2 * (P.s : ℝ)) * (1 / 4 : ℝ) ^ (P.s - 1) ∧
      ‖aug P σ v‖ ^ 2 / c / (P.L : ℝ) * (2 * (P.s : ℝ)) * (1 / 4 : ℝ) ^ (P.s - 1) ≤
        (P.eta : ℝ) / 2 ^ 16 * (‖aug P σ v‖ ^ 2 / c / (P.L : ℝ)) ∧
      (P.eta : ℝ) / 2 ^ 16 * (‖aug P σ v‖ ^ 2 / c / (P.L : ℝ)) <
        (P.eta : ℝ) / 2 ^ 13 * (‖aug P σ v‖ ^ 2 / c / (P.L : ℝ)) := by
  have hb := sgn_isKWiseSigns P
  have hs1 : 1 ≤ P.s := by unfold StreamParams.s; omega
  have hL := L_pos P
  set F := ‖aug P σ v‖ ^ 2 with hFdef
  have hFsum : F = ∑ i, (aug P σ v) i ^ 2 := norm_sq_eq_sum P _
  obtain ⟨t1, t2⟩ := hb.E_clip_tail hs1 le_rfl (aug P σ v) hL hc
  rw [← hFsum, ← E_fIdeal_eq] at t1 t2
  have e1 : F / c / (P.L : ℝ) = F / ((P.L : ℝ) * c) := ratio_div F c _
  have e2 : 2 * (P.s : ℝ) * (F / c) / (P.L : ℝ) = 2 * (P.s : ℝ) * F / ((P.L : ℝ) * c) := by
    field_simp
  have hs0 : (0 : ℝ) < P.s := by have : 0 < P.s := by omega
                                 exact_mod_cast this
  have hF0 : 0 ≤ F := le_of_lt hF
  have hq0 : 0 ≤ 2 * (P.s : ℝ) * (F / c) / (P.L : ℝ) :=
    div_nonneg (mul_nonneg (mul_nonneg (by norm_num) hs0.le) (div_nonneg hF0 hc.le)) hL.le
  have hq : 2 * (P.s : ℝ) * (F / c) / (P.L : ℝ) ≤ 1 / 4 := by
    have hr2 : F / c ≤ 2 := by rw [div_le_iff₀ hc]; linarith
    rw [div_le_iff₀ hL, L_eq]
    nlinarith
  have hpow := pow_le_pow_left₀ hq0 hq (P.s - 1)
  have hrL : 0 ≤ F / c / (P.L : ℝ) := div_nonneg (div_nonneg hF0 hc.le) hL.le
  have h2s : 0 ≤ 2 * (P.s : ℝ) := by linarith
  have hrLpos : 0 < F / c / (P.L : ℝ) := div_pos (div_pos hF hc) hL
  refine ⟨by rw [e1]; exact t1, by rw [e1, e2]; exact t2, ?_, ?_, ?_⟩
  · calc F / c / (P.L : ℝ) * (2 * (P.s : ℝ) * (F / c) / (P.L : ℝ)) ^ (P.s - 1) * (2 * (P.s : ℝ))
        ≤ F / c / (P.L : ℝ) * (1 / 4 : ℝ) ^ (P.s - 1) * (2 * (P.s : ℝ)) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hpow hrL) h2s
      _ = F / c / (P.L : ℝ) * (2 * (P.s : ℝ)) * (1 / 4 : ℝ) ^ (P.s - 1) := by ring
  · have h := two_s_quarter_pow_le P
    calc F / c / (P.L : ℝ) * (2 * (P.s : ℝ)) * (1 / 4 : ℝ) ^ (P.s - 1)
        = F / c / (P.L : ℝ) * (2 * (P.s : ℝ) * (1 / 4 : ℝ) ^ (P.s - 1)) := by ring
      _ ≤ F / c / (P.L : ℝ) * ((P.eta : ℝ) / 2 ^ 16) := mul_le_mul_of_nonneg_left h hrL
      _ = (P.eta : ℝ) / 2 ^ 16 * (F / c / (P.L : ℝ)) := by ring
  · have hη := eta_pos P
    have : (P.eta : ℝ) / 2 ^ 16 < (P.eta : ℝ) / 2 ^ 13 :=
      div_lt_div_of_pos_left hη (by norm_num) (by norm_num)
    exact mul_lt_mul_of_pos_right this hrLpos

end F2e2e.C.NormBank
