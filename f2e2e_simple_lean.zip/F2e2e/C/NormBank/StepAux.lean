import Mathlib
import F2e2e.C.ClosureInv

/-!
# Helpers for the bank part of the chronological closure (`F2e2e/C/ClosureBankStep.lean`)

* list lemmas for the histories (`getD_modifyAt_of_lt`, `getD_mapFrom_of_lt`, `getD_take_of_lt`);
* the exact shadows and counter errors after one row operation (`bankShadowXY_*`, `errX_resetY`, …);
* `abs_meas_le` (Cauchy–Schwarz for a sign row, eq. `R:eq:Z-cauchy-schwarz-bound`) and `nosat_of`, the
  no-saturation premise of `err_step` from the vector bound `√(‖v‖² + ω) ≤ V` and the drift `≤ ξ`
  (partIII.tex L1087: "the proposed rounded value is within `ξ` of a shadow measurement of magnitude at most
  `√D_* V`, strictly inside the totality ranges");
* the counter-error witnesses `CtrW` (`F2e2e/C/ClosureInv.lean`): `ctrW_zero`, `ctrW_congr`, `ctrW_step_same`,
  `ctrW_step_scale` (one new rounding error, after an operation with multiplier `1`, resp. `c`), and
  `ctrW_abs_le` (Lemma 6.1 (iv): drift `≤ G(T+1)h_b = ξ`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Lists of histories -/

theorem getD_modifyAt_of_lt {α : Type} (f : α → α) (k : ℕ) (l : List α) (d : α) {j : ℕ}
    (hj : j < l.length) :
    (modifyAt f k l).getD j d = if j = k then f (l.getD j d) else l.getD j d := by
  rw [List.getD_eq_getElem?_getD, getElem?_modifyAt, List.getD_eq_getElem _ _ hj,
    List.getElem?_eq_getElem hj]
  split_ifs <;> rfl

theorem getD_mapFrom_of_lt {α : Type} (f : α → α) (k : ℕ) (l : List α) (d : α) {j : ℕ}
    (hj : j < l.length) :
    (mapFrom f k l).getD j d = if k ≤ j then f (l.getD j d) else l.getD j d := by
  rw [List.getD_eq_getElem?_getD, getElem?_mapFrom, List.getD_eq_getElem _ _ hj,
    List.getElem?_eq_getElem hj]
  split_ifs <;> rfl

theorem getD_take_of_lt {α : Type} (l : List α) (n : ℕ) (d : α) {j : ℕ} (hj : j < n) :
    (l.take n).getD j d = l.getD j d := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take_of_lt hj]

variable {P : StreamParams}

/-! ## Shadows and errors after one row operation -/

theorem bankShadowXY_nil : bankShadowXY P [] = (0, 0) := rfl

theorem errX_nil (ζ : Seed P) : errX P [] ζ = 0 := by
  unfold errX
  rw [rowFun_nil, bankShadowXY_nil, rowOf_X, meas_zero]
  simp

theorem errY_nil (ζ : Seed P) : errY P [] ζ = 0 := by
  unfold errY
  rw [rowFun_nil, bankShadowXY_nil, rowOf_Y, meas_zero]
  simp

theorem bankShadowXY_resetY (hist : List RowOp) :
    bankShadowXY P (hist ++ [RowOp.resetY]) = ((bankShadowXY P hist).1, 0) := by
  rw [bankShadowXY_append]
  rfl

theorem errX_resetY (hist : List RowOp) (ζ : Seed P) :
    errX P (hist ++ [RowOp.resetY]) ζ = errX P hist ζ := by
  unfold errX
  rw [rowFun_append, bankShadowXY_append]
  rfl

theorem errY_resetY (hist : List RowOp) (ζ : Seed P) : errY P (hist ++ [RowOp.resetY]) ζ = 0 := by
  unfold errY
  rw [rowFun_append, bankShadowXY_append]
  show ((0 : ℤ) : ℝ) * P.hb - meas P ζ 0 = 0
  rw [meas_zero]
  simp

theorem bankShadowXY_phys (hist : List RowOp) (i : ℕ) (Δ : ℤ) :
    bankShadowXY P (hist ++ [RowOp.phys i Δ]) =
      ((bankShadowXY P hist).1 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1),
        (bankShadowXY P hist).2 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1)) := by
  rw [bankShadowXY_append]
  rfl

theorem bankShadowXY_guardY (hist : List RowOp) (g : ℕ) (δ : ℤ) :
    bankShadowXY P (hist ++ [RowOp.guardY g δ]) =
      ((bankShadowXY P hist).1,
        (bankShadowXY P hist).2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1)) := by
  rw [bankShadowXY_append]
  rfl

theorem bankShadowXY_guardXY (hist : List RowOp) (g : ℕ) (δ : ℤ) :
    bankShadowXY P (hist ++ [RowOp.guardXY g δ]) =
      ((bankShadowXY P hist).1 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1),
        (bankShadowXY P hist).2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1)) := by
  rw [bankShadowXY_append]
  rfl

theorem bankShadowXY_scaleY (hist : List RowOp) (c : ℤ) :
    bankShadowXY P (hist ++ [RowOp.scaleY c]) =
      ((bankShadowXY P hist).1, ((gridVal P.eHstep c : ℚ) : ℝ) • (bankShadowXY P hist).2) := by
  rw [bankShadowXY_append]
  rfl

theorem bankShadowXY_scaleXY (hist : List RowOp) (c : ℤ) :
    bankShadowXY P (hist ++ [RowOp.scaleXY c]) =
      (((gridVal P.eHstep c : ℚ) : ℝ) • (bankShadowXY P hist).1,
        ((gridVal P.eHstep c : ℚ) : ℝ) • (bankShadowXY P hist).2) := by
  rw [bankShadowXY_append]
  rfl

/-! ## No saturation -/

/-- Cauchy–Schwarz for a sign row (eq. `R:eq:Z-cauchy-schwarz-bound`): `|⟨b(ζ), v⟩| ≤ √D_* ‖v‖`. -/
theorem abs_meas_le (ζ : Seed P) (v : EuclideanSpace ℝ (Fin P.Dstar)) :
    |meas P ζ v| ≤ √(P.Dstar : ℝ) * ‖v‖ := by
  unfold meas
  have hcs : (∑ i, sgn P ζ i * v i) ^ 2 ≤ (∑ i, sgn P ζ i ^ 2) * ∑ i, v i ^ 2 :=
    Finset.sum_mul_sq_le_sq_mul_sq _ _ _
  have hb2 : ∑ i, sgn P ζ i ^ 2 = (P.Dstar : ℝ) := by
    have h1 : ∀ i, sgn P ζ i ^ 2 = 1 := fun i => by
      rcases sgn_eq_or P ζ i with h | h <;> rw [h] <;> norm_num
    simp only [h1, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
  rw [hb2, ← norm_sq_eq_sum] at hcs
  rw [← Real.sqrt_sq_eq_abs]
  calc √((∑ i, sgn P ζ i * v i) ^ 2) ≤ √((P.Dstar : ℝ) * ‖v‖ ^ 2) := Real.sqrt_le_sqrt hcs
    _ = √(P.Dstar : ℝ) * ‖v‖ := by rw [Real.sqrt_mul (Nat.cast_nonneg _), Real.sqrt_sq (norm_nonneg _)]

theorem hb_le_xi (P : StreamParams) : (P.hb : ℝ) ≤ Precision.xi P := by
  have hb0 : (0 : ℝ) < P.hb := hb_pos P
  have hG : (1 : ℝ) ≤ P.G := by exact_mod_cast P.G_pos
  have hT : (0 : ℝ) ≤ P.T := Nat.cast_nonneg _
  have h1 : (1 : ℝ) ≤ (P.G : ℝ) * ((P.T : ℝ) + 1) := by nlinarith
  unfold Precision.xi
  nlinarith

theorem xi_le_quarter (P : StreamParams) : Precision.xi P ≤ 1 / 4 := by
  refine (Precision.xi_le P).trans ?_
  have he : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have he0 : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
  have ho : (P.omega : ℝ) ≤ 1 := by exact_mod_cast P.omega_le_one
  have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
  have hD : (1 : ℝ) ≤ P.Dstar := by exact_mod_cast P.Dstar_pos
  have hV : (1 : ℝ) ≤ (P.V : ℝ) + 1 := by
    have : (0 : ℝ) ≤ P.V := Nat.cast_nonneg _
    linarith
  have hDV : (1 : ℝ) ≤ (P.Dstar : ℝ) * ((P.V : ℝ) + 1) := by nlinarith
  have hden : (4 : ℝ) ≤ 2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1) := by
    have h2 : (4 : ℝ) ≤ 2 ^ 40 := by norm_num
    have e : (2 : ℝ) ^ 40 * P.Dstar * ((P.V : ℝ) + 1) = 2 ^ 40 * ((P.Dstar : ℝ) * ((P.V : ℝ) + 1)) := by
      ring
    rw [e]
    nlinarith
  have hηω : (P.eta : ℝ) * P.omega ≤ 1 := by nlinarith
  rw [div_le_iff₀ (by linarith)]
  nlinarith

/-- **No saturation** (partIII.tex L1087): the new exact measurement of a bank counter has magnitude at most
`√D_* V`, the old drift is at most `ξ`, so `|meas| + 2|e| + h_b ≤ √D_* V + 1 < Z_max`. -/
theorem nosat_of (ζ : Seed P) {v : EuclideanSpace ℝ (Fin P.Dstar)}
    (hv : √(‖v‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ)) {e : ℝ} (he : |e| ≤ Precision.xi P) :
    |meas P ζ v| + 2 * |e| + (P.hb : ℝ) ≤ (P.Zmax : ℝ) := by
  have h1 := abs_meas_le ζ v
  have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
  have hnv : ‖v‖ ≤ (P.V : ℝ) := by
    have h := Real.sqrt_le_sqrt (show ‖v‖ ^ 2 ≤ ‖v‖ ^ 2 + (P.omega : ℝ) by linarith)
    rw [Real.sqrt_sq (norm_nonneg v)] at h
    linarith
  have h2 : √(P.Dstar : ℝ) * ‖v‖ ≤ √(P.Dstar : ℝ) * P.V :=
    mul_le_mul_of_nonneg_left hnv (Real.sqrt_nonneg _)
  have h3 := P.sqrt_Dstar_mul_V_add_one_lt_Zmax
  have h4 := hb_le_xi P
  have h5 := xi_le_quarter P
  linarith

/-! ## Counter-error witnesses -/

theorem ctrW_zero (S : Tree.TreeSt P) (D nev : ℕ) : CtrW P S D nev 0 :=
  ⟨[], by rw [pws_nil], by simp, by simp⟩

theorem ctrW_congr {S S' : Tree.TreeSt P} {D nev nev' : ℕ} {e : ℝ} (h : CtrW P S D nev e)
    (hpws : ∀ L, pws S' D 1 L = pws S D 1 L) (hn : nev ≤ nev') : CtrW P S' D nev' e := by
  obtain ⟨L, he, hlen, hw⟩ := h
  exact ⟨L, by rw [hpws]; exact he, hlen.trans hn, hw⟩

/-- One new rounding error after an operation with multiplier `1` (the windows are unchanged). -/
theorem ctrW_step_same {S S' : Tree.TreeSt P} {D nev : ℕ} {e e' z : ℝ} (h : CtrW P S D nev e)
    (hpws : ∀ L, pws S' D 1 L = pws S D 1 L) (he' : e' = 1 * e + z) (hz : |z| ≤ (P.hb : ℝ)) :
    CtrW P S' D (nev + 1) e' := by
  obtain ⟨L, he, hlen, hw⟩ := h
  refine ⟨L ++ [(fun _ => S'.t + 1, z)], ?_, by simp; omega, ?_⟩
  · rw [pws_snoc, hpws, ← he, he']
    ring
  · intro x hx
    rcases List.mem_append.mp hx with hx | hx
    · exact hw x hx
    · rw [List.mem_singleton] at hx
      subst hx
      exact hz

/-- One new rounding error after an operation with multiplier `c` (a correction of a depth `d < D`: every window
is shifted and multiplied by `c`). -/
theorem ctrW_step_scale {S S' : Tree.TreeSt P} {D nev d : ℕ} {c e e' z : ℝ} (h : CtrW P S D nev e)
    (hpws : ∀ L, pws S' D 1 (winShift d S.t L) = c ^ 1 * pws S D 1 L) (he' : e' = c * e + z)
    (hz : |z| ≤ (P.hb : ℝ)) : CtrW P S' D (nev + 1) e' := by
  obtain ⟨L, he, hlen, hw⟩ := h
  refine ⟨winShift d S.t L ++ [(fun _ => S'.t + 1, z)], ?_, ?_, ?_⟩
  · rw [pws_snoc, hpws, ← he, he']
    ring
  · rw [List.length_append, length_winShift, List.length_singleton]
    omega
  · intro x hx
    rcases List.mem_append.mp hx with hx | hx
    · unfold winShift at hx
      obtain ⟨y, hy, rfl⟩ := List.mem_map.mp hx
      exact hw y hy
    · rw [List.mem_singleton] at hx
      subst hx
      exact hz

/-- **Lemma 6.1 (iv)**: a counter error with a witness over `D ≤ live` depths and at most `T` rounding errors is at
most `G(T+1)h_b = ξ` (Theorem 5.11 (2a) bounds every window product by `G`). -/
theorem ctrW_abs_le {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} {D nev : ℕ} {e : ℝ}
    (htree : Tree.TreeInv P ph R S) (hD : D ≤ ph.live P.H) (hDH : D ≤ P.H + 1) (hnev : nev ≤ P.T)
    (h : CtrW P S D nev e) : |e| ≤ Precision.xi P := by
  obtain ⟨L, rfl, hlen, hw⟩ := h
  have hb0 : (0 : ℝ) ≤ P.hb := (hb_pos P).le
  have h1 := abs_pws_le_G htree hD hDH 1 L hb0 hlen hw
  have hG : (0 : ℝ) ≤ P.G := Nat.cast_nonneg _
  have hn : (nev : ℝ) ≤ (P.T : ℝ) + 1 := by
    have : (nev : ℝ) ≤ P.T := by exact_mod_cast hnev
    linarith
  calc |pws S D 1 L| ≤ nev * P.hb * (P.G : ℝ) ^ 1 := h1
    _ ≤ ((P.T : ℝ) + 1) * P.hb * (P.G : ℝ) ^ 1 := by
        apply mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hn hb0)
        rw [pow_one]
        exact hG
    _ = Precision.xi P := by
        unfold Precision.xi
        ring

end F2e2e.C.Closure
