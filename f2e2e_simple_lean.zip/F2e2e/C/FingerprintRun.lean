import F2e2e.C.Top.Run
import F2e2e.C.FingerprintCount
import F2e2e.C.FingerprintNum

/-!
# The zero-fingerprint failure count on the canonical run of a `MathStreamAlg`

Paper: `parts/partII.tex` Lemma `R:lem:zero-fingerprint` (3) (L246–249).

Glue between the abstract coupling (`F2e2e/C/FingerprintCoupling.lean`,
`F2e2e/C/FingerprintCount.lean`) and the canonical run `MathStreamAlg.run` of `F2e2e/C/Top/Run.lean`:
for an algorithm `A'` whose initialization is `seedProg.bind (fun r => restProg.map (mk r))` and
whose round is an abstract fingerprint round `A : FpRound P.n P.q A'.State` with the real zero test,

* `run_eq_bind_runZ`: the canonical run is the abstract real run from the initial state;
* `seqVec_eq_vecOf`: the Spec's stream vectors along the canonical run;
* `card_falseZeroRun_le`: the number of tape tuples on which some round `t < m` within the box
  promise, from a non-failed state, has `x^{(t+1)} ≠ 0` but the zero test reports zero is at most
  `2^{(m+1) tapeLen} (m n/q + p_f)`;

With the paper's parameters (`q` the least prime `≥ M_q`, the capped sampler with `betaExp + 10`
trials) this gives at most `(2 β₀/1000) 2^{(m+1) tapeLen}`, hence `≤ (β₀/8) 2^{(m+1) tapeLen}`, for
C-ALG's algorithm: `F2e2e.C.card_fpFalseZero_le_two`, `F2e2e.C.card_fpFalseZero_le`
(`F2e2e/C/Fingerprint.lean`, via the instance `F2e2e/C/FingerprintAlg.lean`).
-/

namespace F2e2e.C.FP

open F2e2e.C.Top F2e2e.Discrete Finset
open scoped ENNReal

section Run

variable {P : StreamParams} {A' : MathStreamAlg}

/-- The real zero test of the round with update `u` from the registers of `s`. -/
def fpBitOf (A : FpRound P.n P.q A'.State) (s : A'.State) (u : Fin P.n × ℤ) : Bool :=
  decide (fpNext P.q (A.seed s) (A.val s) u = 0)

/-- **The false-zero event** on the canonical run (generic form of `F2e2e.C.FpFalseZero`): some
round `t < m`, within the box promise after the rounds `0, …, t`, from a non-failed state, has
`x^{(t+1)} ≠ 0` but the zero test reports zero. -/
def FalseZeroRun (A : FpRound P.n P.q A'.State) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool) : Prop :=
  ∃ t < P.m, BoxUpTo P.U adv (A'.outs P adv tapes) t ∧ ∃ c, A'.run P adv tapes t = some c ∧
    A.failed c.1 = false ∧ seqVec (advUpdate adv (A'.outs P adv tapes)) t ≠ 0 ∧
      fpBitOf A c.1 (adv c.2) = true

theorem tapeAt_eq_tapeAtM {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) :
    tapeAt tapes = tapeAtM tapes := rfl

/-- The canonical run is the abstract real run from the initial state. -/
theorem run_eq_bind_runZ (A : FpRound P.n P.q A'.State) (adv : StreamAdversary P.n)
    (init : BitProg A'.State) (hi : ∀ tape, A'.init P tape = init.run tape)
    (hs : ∀ s u tape, A'.step P s u tape = (A.stepZ s u (fpBitOf A s u)).run tape)
    (tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool) :
    ∀ t, A'.run P adv tapes t =
      (init.run (tapeAt tapes 0)).bind fun c0 => runZ A adv (realZ A adv) (tapeAt tapes) c0.1 t
  | 0 => by
    rw [run_zero_eq, hi]
    cases init.run (tapeAt tapes 0) <;> rfl
  | t + 1 => by
    rw [run_succ_eq, run_eq_bind_runZ A adv init hi hs tapes t, Option.bind_assoc]
    congr 1
    funext c0
    simp only [runZ, hs]
    rfl

/-- `List.ofFn` of the first `s` values of a list. -/
theorem ofFn_getD_eq_take (l : List ℚ) {s : ℕ} (hs : s ≤ l.length) :
    List.ofFn (fun r : Fin s => l.getD r.val 0) = l.take s := by
  apply List.ext_getElem
  · simp [List.length_take, min_eq_left hs]
  · intro r h1 h2
    simp only [List.getElem_ofFn, List.getElem_take]
    rw [List.getD_eq_getElem]

/-- The Spec's stream vectors along the canonical run: after round `s ≤ t` it is the stream
vector of the first `s` outputs. -/
theorem seqVec_eq_vecOf {adv : StreamAdversary P.n}
    {tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool} {t : ℕ} {c : A'.State × List ℚ}
    (hc : A'.run P adv tapes t = some c) {s : ℕ} (hs : s ≤ t) :
    seqVec (advUpdate adv (A'.outs P adv tapes)) s = vecOf adv (c.2.take s) := by
  have hlen := run_length hc
  have hout := outs_eq_of_run hc
  funext i
  simp only [seqVec, vecOf, List.length_take, hlen, min_eq_left hs]
  refine Finset.sum_congr rfl fun s' hs' => ?_
  have hs'' : s' ≤ s := Nat.lt_succ_iff.mp (Finset.mem_range.mp hs')
  have hu : advUpdate adv (A'.outs P adv tapes) s' = adv ((c.2.take s).take s') := by
    unfold advUpdate
    congr 1
    rw [List.take_take, min_eq_left hs'']
    rw [← ofFn_getD_eq_take c.2 (by omega)]
    congr 1
    funext r
    exact hout r.val (by omega)
  rw [hu]

/-- The false-zero event on the canonical run is an abstract real false zero from the initial
state. -/
theorem falseZeroRun_imp (A : FpRound P.n P.q A'.State) (adv : StreamAdversary P.n)
    (init : BitProg A'.State) (hi : ∀ tape, A'.init P tape = init.run tape)
    (hs : ∀ s u tape, A'.step P s u tape = (A.stepZ s u (fpBitOf A s u)).run tape)
    {tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool} (h : FalseZeroRun A adv tapes) :
    ∃ c0, init.run (tapeAtM tapes 0) = some c0 ∧ BadFrom A adv P.U P.m (tapeAtM tapes) c0.1 := by
  obtain ⟨t, ht, hbox, c, hc, hf, hv, hz⟩ := h
  have hc' := hc
  rw [run_eq_bind_runZ A adv init hi hs tapes t] at hc'
  obtain ⟨c0, hc0, hrun⟩ := Option.bind_eq_some_iff.mp hc'
  have hlen := run_length hc
  refine ⟨c0, hc0, t, ht, c, hrun, hf, fun s hst j => ?_, ?_, hz⟩
  · rw [← seqVec_eq_vecOf hc hst]
    exact hbox s hst j
  · rw [← List.take_of_length_le (le_of_eq hlen), ← seqVec_eq_vecOf hc le_rfl]
    exact hv

open Classical in
/-- **The failure count** (Lemma `R:lem:zero-fingerprint` (3), generic form): at most
`2^{(m+1) tapeLen} (m n/q + p_f)` tape tuples have a false zero. -/
theorem card_falseZeroRun_le [Fact P.q.Prime] (A : FpRound P.n P.q A'.State)
    (adv : StreamAdversary P.n) (hU : P.U < P.q) {R : Type} (seedProg : BitProg ℕ)
    (restProg : BitProg R) (mk : ℕ → R → A'.State)
    (hi : ∀ tape, A'.init P tape = (seedProg.bind fun r => restProg.map (mk r)).run tape)
    (hs : ∀ s u tape, A'.step P s u tape = (A.stepZ s u (fpBitOf A s u)).run tape)
    (hseed : ∀ r Bk, A.seed (mk r Bk) = r) (hval : ∀ r Bk, A.val (mk r Bk) = 0)
    (herase : ∀ r Bk, A.erase (mk r Bk) = A.erase (mk 0 Bk))
    (hdepth : (seedProg.bind fun r => restProg.map (mk r)).depth ≤ A'.tapeLen P) {pf : ℝ≥0∞}
    (hlaw : ∀ r, seedProg.law r ≤
      (if r < P.q then (P.q : ℝ≥0∞)⁻¹ else 0) + (if r = 0 then pf else 0)) :
    (({tapes | FalseZeroRun A adv tapes} : Set (Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool)).ncard :
        ℝ≥0∞) ≤ 2 ^ ((P.m + 1) * A'.tapeLen P) * ((P.m * P.n : ℝ≥0∞) / P.q + pf) := by
  set init := seedProg.bind fun r => restProg.map (mk r) with hinit
  have hset : ({tapes | FalseZeroRun A adv tapes} :
      Set (Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool)) =
      ↑(Finset.univ.filter (fun tapes => FalseZeroRun A adv tapes)) := by
    ext tapes
    simp
  rw [hset, Set.ncard_coe_finset]
  have hcard : ((Finset.univ.filter (fun tapes => FalseZeroRun A adv tapes)).card : ℝ≥0∞) =
      ∑ tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool,
        (if FalseZeroRun A adv tapes then (1 : ℝ≥0∞) else 0) := by
    rw [Finset.sum_boole]
  rw [hcard]
  refine le_trans (Finset.sum_le_sum fun tapes _ => ?_)
    (sum_tapes_badFrom_le A adv P.U P.m (A'.tapeLen P) hU seedProg restProg mk hseed hval herase
      hdepth hlaw)
  by_cases hF : FalseZeroRun A adv tapes
  · rw [if_pos hF, if_pos (falseZeroRun_imp A adv init hi hs hF)]
  · rw [if_neg hF]
    positivity

end Run

end F2e2e.C.FP
