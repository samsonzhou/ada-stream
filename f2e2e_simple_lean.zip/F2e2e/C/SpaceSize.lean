import F2e2e.C.SpaceDefs
import F2e2e.Cost.Facts

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`): bit lengths of the stored integers and tree sizes

For the bounds `RowOK`, `LearnerOK`, `StateOK` and the encodings `encRow`, `encLearner`, `encBank`,
`encState` of `F2e2e/C/SpaceDefs.lean`:

* the bit length of every stored integer: at most `23ℒ³ ≤ 2^30 ℒ³` (the register claim of
  Lemma 6.3, partIII.tex L1180);
* the explicit tree size (`valSize`) bounds of the encoded rows, learners, banks and of the whole
  memory (`StateOK.valSize_encState_le`, the bound `stateSizeBound` before the final arithmetic of
  `F2e2e/C/SpaceBound.lean`).

Parameter bounds used: `F2e2e/C/SpaceParams.lean` (`eZmax_le`, `eHb_le`, `w_le`, `s_le`, `eCmax_le`,
`eHC_le`, `eAmax_le`, `eHP_le`, `eHleaf_le`, `Kepoch_le`, `Jstar_le`, `eEta_le`, `q_le`, `m_le`,
`hundred_le_calL`, `hundred_mul_sq_le_cube`, …).

Helper lemmas live in the namespace `F2e2e.C.Space.SizeAux` (never directly in `F2e2e.C.Space`, whose
users also open `F2e2e.Cost`).
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete

namespace SizeAux

/-! ## Helpers -/

theorem hundred_le_calL_cube (P : StreamParams) : 100 ≤ P.calL ^ 3 :=
  (hundred_le_calL P).trans (Nat.le_self_pow (by norm_num) _)

theorem hundred_calL_le_cube (P : StreamParams) : 100 * P.calL ≤ P.calL ^ 3 := by
  have h1 := hundred_mul_calL_le_sq P
  have h2 : P.calL ^ 2 ≤ P.calL ^ 3 :=
    Nat.pow_le_pow_right (by have := hundred_le_calL P; omega) (by norm_num)
  omega

/-- Bit length of a natural number below `2^k`. -/
theorem bitLen_nat_le_of_lt {n k : ℕ} (h : n < 2 ^ k) : bitLen (n : ℤ) ≤ k := by
  rw [F2e2e.Cost.bitLen_natCast]
  exact Nat.size_le.mpr h

/-- `bitLen n ≤ n`. -/
theorem bitLen_nat_le_self (n : ℕ) : bitLen (n : ℤ) ≤ n :=
  bitLen_nat_le_of_lt Nat.lt_two_pow_self

/-- Bit length of an integer with `|z| ≤ 2^k`. -/
theorem bitLen_le_of_abs_le {z : ℤ} {k : ℕ} (h : |z| ≤ 2 ^ k) : bitLen z ≤ k + 1 := by
  apply F2e2e.Cost.bitLen_le_of_abs_lt
  rw [pow_succ]
  have : (0 : ℤ) < 2 ^ k := by positivity
  linarith

/-- Bit length of an integer in `[0, 2^k]`. -/
theorem bitLen_le_of_nonneg_le {z : ℤ} {k : ℕ} (h0 : 0 ≤ z) (h : z ≤ 2 ^ k) : bitLen z ≤ k + 1 :=
  bitLen_le_of_abs_le (by rw [abs_of_nonneg h0]; exact h)

theorem zSat_eq (P : StreamParams) : zSat P = 2 ^ (P.eZmax + P.eHb) := by
  unfold zSat StreamParams.Zmax
  push_cast
  rw [pow_add]

/-- Counters: `|z| ≤ zSat = 2^{e_Zmax + e_hb}` gives `bitLen z ≤ e_Zmax + e_hb + 1 ≤ 23ℒ³`. -/
theorem bitLen_le_of_abs_le_zSat {P : StreamParams} {z : ℤ} (h : |z| ≤ zSat P) :
    bitLen z ≤ 23 * P.calL ^ 3 := by
  rw [zSat_eq] at h
  have h2 := bitLen_le_of_abs_le h
  have h3 := eZmax_le P
  have h4 := eHb_le P
  have h5 := hundred_le_calL_cube P
  omega

theorem listSize_map_le {α : Type*} (l : List α) (f : α → Val) (B : ℕ)
    (h : ∀ a ∈ l, valSize (f a) ≤ B) : listSize (l.map f) ≤ l.length * (B + 1) := by
  induction l with
  | nil => simp
  | cons a l ih =>
    have ha := h a (by simp)
    have hl := ih (fun b hb => h b (by simp [hb]))
    simp only [List.map_cons, F2e2e.Cost.listSize_cons, List.length_cons]
    have e : (l.length + 1) * (B + 1) = l.length * (B + 1) + (B + 1) := by ring
    omega

theorem valSize_list_map_le {α : Type*} (l : List α) (f : α → Val) (B : ℕ)
    (h : ∀ a ∈ l, valSize (f a) ≤ B) : valSize (Val.list (l.map f)) ≤ 1 + l.length * (B + 1) := by
  rw [F2e2e.Cost.valSize_list]
  have := listSize_map_le l f B h
  omega

theorem valSize_encInts_le (l : List ℤ) (B : ℕ) (h : ∀ z ∈ l, bitLen z ≤ B) :
    valSize (encInts l) ≤ 1 + l.length * (B + 2) := by
  have e : encInts l = Val.list (l.map Val.int) := rfl
  rw [e]
  calc valSize (Val.list (l.map Val.int)) ≤ 1 + l.length * (B + 1 + 1) :=
        valSize_list_map_le l Val.int (B + 1) (fun z hz => by
          rw [F2e2e.Cost.valSize_int]
          have := h z hz
          omega)
    _ = 1 + l.length * (B + 2) := by ring

/-! ## Fine bounds on the stored scalars -/

theorem bitLen_tag_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen L.tag ≤ P.eCmax + P.eHC + 3 := by
  have e : ((4 : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) = 2 ^ (P.eCmax + P.eHC + 2) := by
    unfold StreamParams.Cmax
    push_cast
    ring
  exact bitLen_le_of_nonneg_le h.tag_nonneg (h.tag_le.trans_eq e)

theorem bitLen_cache_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen L.cache ≤ P.eAmax + P.eHP + 3 := by
  have e : ((4 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) = 2 ^ (P.eAmax + P.eHP + 2) := by
    unfold StreamParams.Amax
    push_cast
    ring
  exact bitLen_le_of_nonneg_le h.cache_nonneg (h.cache_le.trans_eq e)

theorem bitLen_epoch_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen (L.epoch : ℤ) ≤ P.Kepoch :=
  (bitLen_nat_le_self L.epoch).trans h.epoch_le

theorem bitLen_jEpoch_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen (L.jEpoch : ℤ) ≤ 7 + 2 * P.eEta := by
  have hK : P.K0 = 2 ^ (7 + 2 * P.eEta) := rfl
  exact bitLen_nat_le_of_lt (hK ▸ h.jEpoch_lt)

theorem bitLen_jUsed_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen (L.jUsed : ℤ) ≤ 10 + 2 * P.eEta + 3 * P.calL := by
  apply bitLen_nat_le_of_lt
  have h3 : P.calL ^ 3 < 2 ^ (3 * P.calL) := by
    rw [pow_mul']
    exact Nat.pow_lt_pow_left Nat.lt_two_pow_self (by norm_num)
  calc L.jUsed ≤ P.Jstar := h.jUsed_le
    _ ≤ 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := Jstar_le P
    _ < 2 ^ 10 * 2 ^ (2 * P.eEta) * 2 ^ (3 * P.calL) := mul_lt_mul_of_pos_left h3 (by positivity)
    _ = 2 ^ (10 + 2 * P.eEta + 3 * P.calL) := by rw [pow_add, pow_add]

theorem bitLen_t_le {P : StreamParams} {s : State} (ht : s.t ≤ P.m) : bitLen (s.t : ℤ) ≤ P.calL + 1 := by
  apply bitLen_nat_le_of_lt
  calc s.t ≤ 2 ^ P.calL := ht.trans (m_le P)
    _ < 2 ^ (P.calL + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)

theorem bitLen_fpSeed_le {P : StreamParams} {adaOK : AdaState → Prop} {c : ℕ} {s : State}
    (h : StateOK P adaOK c s) : bitLen (s.fpSeed : ℤ) ≤ 3 * P.calL :=
  bitLen_nat_le_of_lt (lt_of_lt_of_le h.fpSeed_lt (q_le P))

theorem bitLen_fpVal_le {P : StreamParams} {adaOK : AdaState → Prop} {c : ℕ} {s : State}
    (h : StateOK P adaOK c s) : bitLen (s.fpVal : ℤ) ≤ 3 * P.calL :=
  bitLen_nat_le_of_lt (lt_of_lt_of_le h.fpVal_lt (q_le P))

theorem bitLen_leaf_le {P : StreamParams} {adaOK : AdaState → Prop} {s : State}
    (h : StateOK P adaOK 4 s) : bitLen s.leaf ≤ P.eAmax + P.eHleaf + 3 := by
  have e : ((4 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHleaf) = 2 ^ (P.eAmax + P.eHleaf + 2) := by
    unfold StreamParams.Amax
    push_cast
    ring
  exact bitLen_le_of_nonneg_le h.leaf_nonneg (h.leaf_le.trans_eq e)

/-! ## Sizes of the bank parts -/

theorem listSize_blocks_le (l : List (List Row)) (R : ℕ)
    (h : ∀ blk ∈ l, ∀ r ∈ blk, valSize (encRow r) ≤ R) :
    listSize (l.map fun blk => Val.list (blk.map encRow)) ≤
      2 * l.length + (l.map List.length).sum * (R + 1) := by
  induction l with
  | nil => simp
  | cons blk l ih =>
    have h1 : valSize (Val.list (blk.map encRow)) ≤ 1 + blk.length * (R + 1) :=
      valSize_list_map_le blk encRow R (h blk (by simp))
    have h2 := ih (fun b hb r hr => h b (by simp [hb]) r hr)
    simp only [List.map_cons, F2e2e.Cost.listSize_cons, List.length_cons, List.sum_cons]
    have e : (blk.length + (l.map List.length).sum) * (R + 1) =
        blk.length * (R + 1) + (l.map List.length).sum * (R + 1) := by ring
    omega

theorem valSize_group_le (grp : List (List Row)) (g R : ℕ) (hg : grp.length = g)
    (hsub : ∀ sub ∈ grp, sub.length = 32) (h : ∀ sub ∈ grp, ∀ r ∈ sub, valSize (encRow r) ≤ R) :
    valSize (Val.list (grp.map fun sub => Val.list (sub.map encRow))) ≤
      1 + 2 * g + 32 * g * (R + 1) := by
  have h1 : ∀ sub ∈ grp, valSize (Val.list (sub.map encRow)) ≤ 1 + 32 * (R + 1) := by
    intro sub hs
    have := valSize_list_map_le sub encRow R (h sub hs)
    rw [hsub sub hs] at this
    exact this
  have := valSize_list_map_le grp (fun sub => Val.list (sub.map encRow)) (1 + 32 * (R + 1)) h1
  rw [hg] at this
  calc _ ≤ 1 + g * (1 + 32 * (R + 1) + 1) := this
    _ = 1 + 2 * g + 32 * g * (R + 1) := by ring

theorem listSize_groups_le (l : List (List (List Row))) (g R : ℕ)
    (hshape : ∀ grp ∈ l, grp.length = g ∧ ∀ sub ∈ grp, sub.length = 32)
    (h : ∀ grp ∈ l, ∀ sub ∈ grp, ∀ r ∈ sub, valSize (encRow r) ≤ R) :
    listSize (l.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))) ≤
      l.length * (2 + 2 * g + 32 * g * (R + 1)) := by
  have := listSize_map_le l (fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow)))
    (1 + 2 * g + 32 * g * (R + 1)) (fun grp hgrp =>
      valSize_group_le grp g R (hshape grp hgrp).1 (hshape grp hgrp).2 (h grp hgrp))
  calc _ ≤ l.length * (1 + 2 * g + 32 * g * (R + 1) + 1) := this
    _ = l.length * (2 + 2 * g + 32 * g * (R + 1)) := by ring

/-- The bank size bound for an arbitrary row bound `R`. -/
theorem valSize_encBank_le_aux {P : StreamParams} {adaOK : AdaState → Prop}
    {adaEnc : AdaState → Val} {adaBound : ℕ} (hada : ∀ st, adaOK st → valSize (adaEnc st) ≤ adaBound)
    {B : Bank} (h : BankOK P adaOK B) (R : ℕ) (hrow : ∀ r : Row, RowOK P r → valSize (encRow r) ≤ R) :
    valSize (encBank adaEnc B) ≤
      ((bankAda P).blockSizes.sum + P.Rmax * (P.gCoarse * 32)) * (R + 1) +
        2 * (bankAda P).blockSizes.length + 4 * P.Rmax * (P.gCoarse + 1) + adaBound + 8 := by
  have hA := listSize_blocks_le B.ada R (fun blk hb r hr => hrow r (h.ada_rows blk hb r hr))
  have hC := listSize_groups_le B.coarse P.gCoarse R h.coarse_shape
    (fun grp hg sub hs r hr => hrow r (h.coarse_rows grp hg sub hs r hr))
  have hS := hada B.adaSt h.ada_ok
  have hlen : B.ada.length = (bankAda P).blockSizes.length := by
    rw [← h.ada_sizes, List.length_map]
  have hsum : (B.ada.map List.length).sum = (bankAda P).blockSizes.sum := by rw [h.ada_sizes]
  rw [hlen, hsum] at hA
  have hC' : B.coarse.length * (2 + 2 * P.gCoarse + 32 * P.gCoarse * (R + 1)) ≤
      P.Rmax * (2 + 2 * P.gCoarse + 32 * P.gCoarse * (R + 1)) :=
    Nat.mul_le_mul_right _ h.coarse_length_le
  unfold encBank
  simp only [F2e2e.Cost.valSize_list, F2e2e.Cost.listSize_cons, F2e2e.Cost.listSize_nil]
  nlinarith [hA, hC, hC', hS]

end SizeAux

/-! ## Bit lengths of the stored integers (the register claim of Lemma 6.3, L1180) -/

/-- Counters have at most `23ℒ³` bits (`|X| ≤ Z_max/h_b`, `log₂ Z_max ≤ 4ℒ³`, `log₂(1/h_b) ≤ 18ℒ³`). -/
theorem RowOK.bitLen_X_le {P : StreamParams} {r : Row} (h : RowOK P r) :
    bitLen r.X ≤ 23 * P.calL ^ 3 :=
  SizeAux.bitLen_le_of_abs_le_zSat h.abs_X_le

theorem RowOK.bitLen_Y_le {P : StreamParams} {r : Row} (h : RowOK P r) :
    bitLen r.Y ≤ 23 * P.calL ^ 3 :=
  SizeAux.bitLen_le_of_abs_le_zSat h.abs_Y_le

/-- Seed elements have at most `w ≤ 3ℒ + 1` bits. -/
theorem RowOK.bitLen_seed_le {P : StreamParams} {r : Row} (h : RowOK P r) {z : ℕ} (hz : z ∈ r.seed) :
    bitLen (z : ℤ) ≤ 3 * P.calL + 1 :=
  (SizeAux.bitLen_nat_le_of_lt (h.seed_lt z hz)).trans (w_le P)

/-- Every stored learner scalar has at most `8ℒ³` bits. -/
theorem LearnerOK.bitLen_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    bitLen L.tag ≤ 8 * P.calL ^ 3 ∧ bitLen L.cache ≤ 8 * P.calL ^ 3 ∧
      bitLen (L.epoch : ℤ) ≤ 8 * P.calL ^ 3 ∧ bitLen (L.jEpoch : ℤ) ≤ 8 * P.calL ^ 3 ∧
      bitLen (L.jUsed : ℤ) ≤ 8 * P.calL ^ 3 := by
  have t1 := SizeAux.bitLen_tag_le h
  have t2 := SizeAux.bitLen_cache_le h
  have t3 := SizeAux.bitLen_epoch_le h
  have t4 := SizeAux.bitLen_jEpoch_le h
  have t5 := SizeAux.bitLen_jUsed_le h
  have a1 := eCmax_le P
  have a2 := eHC_le P
  have a3 := eAmax_le P
  have a4 := eHP_le P
  have a5 := Kepoch_le P
  have a6 := eEta_le P
  have b1 := hundred_mul_sq_le_cube P
  have b2 := SizeAux.hundred_calL_le_cube P
  have b3 := SizeAux.hundred_le_calL_cube P
  refine ⟨by omega, by omega, by omega, by omega, by omega⟩

/-- The global registers have at most `8ℒ³` bits (the round counter for at most `m` rounds). -/
theorem StateOK.bitLen_le {P : StreamParams} {adaOK : AdaState → Prop} {s : State}
    (h : StateOK P adaOK 4 s) (ht : s.t ≤ P.m) :
    bitLen (s.t : ℤ) ≤ 8 * P.calL ^ 3 ∧ bitLen (s.fpSeed : ℤ) ≤ 8 * P.calL ^ 3 ∧
      bitLen (s.fpVal : ℤ) ≤ 8 * P.calL ^ 3 ∧ bitLen s.leaf ≤ 8 * P.calL ^ 3 := by
  have t1 := SizeAux.bitLen_t_le (s := s) ht
  have t2 := SizeAux.bitLen_fpSeed_le h
  have t3 := SizeAux.bitLen_fpVal_le h
  have t4 := SizeAux.bitLen_leaf_le h
  have a1 := eAmax_le P
  have a2 := eHleaf_le P
  have b1 := hundred_mul_sq_le_cube P
  have b2 := SizeAux.hundred_calL_le_cube P
  have b3 := SizeAux.hundred_le_calL_cube P
  refine ⟨by omega, by omega, by omega, by omega⟩

/-! ## Tree sizes of the encodings -/

/-- Tree size bound of one encoded row: `2^6 ℒ³`. -/
theorem RowOK.valSize_encRow_le {P : StreamParams} {r : Row} (h : RowOK P r) :
    valSize (encRow r) ≤ 2 ^ 6 * P.calL ^ 3 := by
  have hseed : valSize (encInts (r.seed.map fun z : ℕ => (z : ℤ))) ≤
      1 + (r.seed.map fun z : ℕ => (z : ℤ)).length * (3 * P.calL + 1 + 2) :=
    SizeAux.valSize_encInts_le _ _ (fun z hz => by
      obtain ⟨z', hz', rfl⟩ := List.mem_map.mp hz
      exact h.bitLen_seed_le hz')
  rw [List.length_map, h.seed_length] at hseed
  have hX := h.bitLen_X_le
  have hY := h.bitLen_Y_le
  have hs := s_le P
  have hprod : 2 * P.s * (3 * P.calL + 1 + 2) ≤ 18 * P.calL ^ 2 + 18 * P.calL := by
    have h1 : 2 * P.s * (3 * P.calL + 1 + 2) ≤ 2 * (3 * P.calL) * (3 * P.calL + 1 + 2) :=
      Nat.mul_le_mul_right _ (by omega)
    have h2 : 2 * (3 * P.calL) * (3 * P.calL + 1 + 2) = 18 * P.calL ^ 2 + 18 * P.calL := by ring
    omega
  have b1 := hundred_mul_sq_le_cube P
  have b2 := SizeAux.hundred_calL_le_cube P
  have b3 := SizeAux.hundred_le_calL_cube P
  unfold encRow
  simp only [F2e2e.Cost.valSize_list, F2e2e.Cost.listSize_cons, F2e2e.Cost.listSize_nil,
    F2e2e.Cost.valSize_int]
  rw [show (2 : ℕ) ^ 6 = 64 by norm_num]
  omega

/-- Tree size bound of one encoded learner: `2^6 ℒ³`. -/
theorem LearnerOK.valSize_encLearner_le {P : StreamParams} {L : Learner} (h : LearnerOK P 4 L) :
    valSize (encLearner L) ≤ 2 ^ 6 * P.calL ^ 3 := by
  obtain ⟨t1, t2, t3, t4, t5⟩ := h.bitLen_le
  have hv := SizeAux.valSize_encInts_le [L.tag, L.cache, (L.epoch : ℤ), (L.jEpoch : ℤ), (L.jUsed : ℤ)]
    (8 * P.calL ^ 3) (by
      intro z hz
      simp only [List.mem_cons, List.mem_nil_iff, or_false] at hz
      rcases hz with rfl | rfl | rfl | rfl | rfl <;> assumption)
  have hlen : [L.tag, L.cache, (L.epoch : ℤ), (L.jEpoch : ℤ), (L.jUsed : ℤ)].length = 5 := rfl
  rw [hlen] at hv
  have b3 := SizeAux.hundred_le_calL_cube P
  unfold encLearner
  rw [show (2 : ℕ) ^ 6 = 64 by norm_num]
  omega

theorem BankOK.valSize_encBank_le {P : StreamParams} {adaOK : AdaState → Prop}
    {adaEnc : AdaState → Val} {adaBound : ℕ} (hada : ∀ st, adaOK st → valSize (adaEnc st) ≤ adaBound)
    {B : Bank} (h : BankOK P adaOK B) :
    valSize (encBank adaEnc B) ≤ bankSizeBound P adaBound := by
  unfold bankSizeBound bankRows
  exact SizeAux.valSize_encBank_le_aux hada h (2 ^ 6 * P.calL ^ 3) (fun r hr => hr.valSize_encRow_le)

/-- **The memory on every execution** (Lemma 6.3, the bound before the final arithmetic): the
encoded memory of a state satisfying the invariant, after at most `m` rounds, has tree size at most
`stateSizeBound P adaBound`. -/
theorem StateOK.valSize_encState_le {P : StreamParams} {adaOK : AdaState → Prop}
    {adaEnc : AdaState → Val} {adaBound : ℕ} (hada : ∀ st, adaOK st → valSize (adaEnc st) ≤ adaBound)
    {s : State} (h : StateOK P adaOK 4 s) (ht : s.t ≤ P.m) :
    valSize (encState adaEnc s) ≤ stateSizeBound P adaBound := by
  have t1 := SizeAux.bitLen_t_le (s := s) ht
  have t2 := SizeAux.bitLen_fpSeed_le h
  have t3 := SizeAux.bitLen_fpVal_le h
  have t4 := SizeAux.bitLen_leaf_le h
  have tf : bitLen (if s.failed then (1 : ℤ) else 0) ≤ 1 := by
    split_ifs <;> simp
  have hL : listSize (s.learners.map encLearner) ≤ s.learners.length * (2 ^ 6 * P.calL ^ 3 + 1) :=
    SizeAux.listSize_map_le _ _ _ (fun L hL => (h.learners_ok L hL).valSize_encLearner_le)
  have hB : listSize (s.banks.map (encBank adaEnc)) ≤
      s.banks.length * (bankSizeBound P adaBound + 1) :=
    SizeAux.listSize_map_le _ _ _ (fun B hB => (h.banks_ok B hB).valSize_encBank_le hada)
  have hL' : s.learners.length * (2 ^ 6 * P.calL ^ 3 + 1) ≤ P.H * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul_right _ h.learners_length_le
  have hB' : s.banks.length * (bankSizeBound P adaBound + 1) ≤ P.H * (bankSizeBound P adaBound + 1) :=
    Nat.mul_le_mul_right _ h.banks_length_le
  have a1 := eAmax_le P
  have a2 := eHleaf_le P
  have b1 := hundred_mul_sq_le_cube P
  have b2 := SizeAux.hundred_calL_le_cube P
  have b3 := SizeAux.hundred_le_calL_cube P
  unfold encState stateSizeBound
  simp only [F2e2e.Cost.valSize_list, F2e2e.Cost.listSize_cons, F2e2e.Cost.listSize_nil,
    F2e2e.Cost.valSize_int]
  have e5 : (2 : ℕ) ^ 5 * P.calL ^ 3 = 32 * P.calL ^ 3 := by norm_num
  rw [e5]
  omega

end F2e2e.C.Space
