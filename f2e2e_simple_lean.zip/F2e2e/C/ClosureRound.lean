import Mathlib
import F2e2e.C.ClosureBlocks2
import F2e2e.C.ClosureStep4WP

/-!
# Theorem 6.4: one round of the algorithm

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof`, the chronological induction
(L1287–1317), and the proof of Theorem `R:thm:main-f2` (L1320–1322): on the good events, every round before the first
violation of the box promise reports `F̂ ∈ [(1 − 8(H+1)η)F₂, (1 + 8(H+1)η)F₂] ⊆ [F₂/(1+ε₀), (1+ε₀)F₂]`; a zero round
(fingerprint zero, Lemma `R:lem:zero-fingerprint`) reports `0 = F₂`.

* `roundTail`: the controller code of a round after Step 1 (`roundCode_eq`);
* `wp_roundTail`: from the end of Step 1 to the end of the round, with the accuracy of the estimate;
* `RoundInv`, `wp_round` (rounds `t + 1 ≥ 2`) and `wp_round_init` (round `1`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## The physical vector in the shadow space -/

/-- The stream vector after the update `x_{i} += Δ`. -/
def updVec {n : ℕ} (x : Fin n → ℤ) (i : Fin n) (Δ : ℤ) : Fin n → ℤ := Function.update x i (x i + Δ)

/-- The accuracy of an estimate `q` of `F₂(x)` at relative accuracy `ε` (as in the Spec's `StreamAccurate`). -/
def EstOK (ε : ℝ) {n : ℕ} (x : Fin n → ℤ) (q : ℚ) : Prop :=
  F2 x / (1 + ε) ≤ (q : ℝ) ∧ (q : ℝ) ≤ (1 + ε) * F2 x

theorem coordAt_embedPhys (x : Fin P.n → ℤ) (j : ℕ) :
    Tree.coordAt (embedPhys P x) j = if h : j < P.n then (x ⟨j, h⟩ : ℝ) else 0 := by
  unfold embedPhys
  rw [Tree.coordAt_sum]
  simp only [Tree.coordAt_smul, Tree.coordAt_unitVec, Tree.physIdx, mul_ite, mul_one, mul_zero]
  split_ifs with h
  · rw [Finset.sum_eq_single ⟨j, h⟩]
    · simp
    · intro b _ hb
      have : j ≠ b.val := fun hjb => hb (Fin.ext hjb.symm)
      simp [this]
    · simp
  · refine Finset.sum_eq_zero fun i _ => ?_
    have : j ≠ i.val := fun hji => h (hji ▸ i.isLt)
    simp [this]

theorem embedPhys_update (x : Fin P.n → ℤ) (i : Fin P.n) (Δ : ℤ) :
    embedPhys P (updVec x i Δ) = embedPhys P x + (Δ : ℝ) • Tree.unitVec (Tree.physIdx P i) := by
  unfold embedPhys updVec
  have hterm : ∀ j : Fin P.n, ((Function.update x i (x i + Δ) j : ℤ) : ℝ) • Tree.unitVec (Tree.physIdx P j) =
      (x j : ℝ) • Tree.unitVec (Tree.physIdx P j) +
        (if j = i then (Δ : ℝ) • Tree.unitVec (Tree.physIdx P i) else 0) := by
    intro j
    by_cases hj : j = i
    · subst hj
      simp [add_smul]
    · simp [hj]
  rw [Finset.sum_congr rfl (fun j _ => hterm j), Finset.sum_add_distrib, Finset.sum_ite_eq']
  simp

theorem norm_sq_embedPhys (x : Fin P.n → ℤ) : ‖embedPhys P x‖ ^ 2 = F2 x := by
  have hnD : P.n ≤ P.Dstar := by unfold StreamParams.Dstar; omega
  have e1 : ‖embedPhys P x‖ ^ 2 = ∑ j ∈ Finset.range P.Dstar, Tree.coordAt (embedPhys P x) j ^ 2 := by
    rw [EuclideanSpace.real_norm_sq_eq,
      ← Fin.sum_univ_eq_sum_range (fun j => Tree.coordAt (embedPhys P x) j ^ 2)]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [Tree.coordAt, i.isLt]
  rw [e1, ← Finset.sum_range_add_sum_Ico _ hnD]
  have e2 : ∑ j ∈ Finset.Ico P.n P.Dstar, Tree.coordAt (embedPhys P x) j ^ 2 = 0 := by
    refine Finset.sum_eq_zero fun j hj => ?_
    have : ¬ j < P.n := by have := (Finset.mem_Ico.mp hj).1; omega
    rw [coordAt_embedPhys, dif_neg this]
    ring
  rw [e2, add_zero, F2, ← Fin.sum_univ_eq_sum_range]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [coordAt_embedPhys, dif_pos i.isLt]

theorem norm_embedPhys_le_W (x : Fin P.n → ℤ) (hx : ∀ i, |x i| ≤ (P.U : ℤ)) : ‖embedPhys P x‖ ≤ (P.W : ℝ) := by
  have hsq : ‖embedPhys P x‖ ^ 2 ≤ (P.n : ℝ) * (P.U : ℝ) ^ 2 := by
    rw [norm_sq_embedPhys, F2]
    calc ∑ i, ((x i : ℤ) : ℝ) ^ 2 ≤ ∑ _i : Fin P.n, (P.U : ℝ) ^ 2 := by
          refine Finset.sum_le_sum fun i _ => ?_
          have hb : |((x i : ℤ) : ℝ)| ≤ (P.U : ℝ) := by exact_mod_cast hx i
          exact sq_le_sq' (abs_le.mp hb).1 (abs_le.mp hb).2
      _ = (P.n : ℝ) * (P.U : ℝ) ^ 2 := by simp
  have hle : ‖embedPhys P x‖ ≤ √(P.n : ℝ) * (P.U : ℝ) := by
    have h1 : √(‖embedPhys P x‖ ^ 2) ≤ √((P.n : ℝ) * (P.U : ℝ) ^ 2) := Real.sqrt_le_sqrt hsq
    rwa [Real.sqrt_sq (norm_nonneg _), Real.sqrt_mul (Nat.cast_nonneg _),
      Real.sqrt_sq (Nat.cast_nonneg _)] at h1
  exact hle.trans (StreamParams.sqrt_n_mul_U_lt_W P).le

theorem one_le_F2_of_ne_zero' {n : ℕ} {x : Fin n → ℤ} (hx : x ≠ 0) : 1 ≤ F2 x := by
  obtain ⟨i, hi⟩ : ∃ i, x i ≠ 0 := by
    by_contra h
    exact hx (funext fun j => by
      by_contra hj
      exact h ⟨j, hj⟩)
  have h1 : (1 : ℝ) ≤ ((x i : ℤ) : ℝ) ^ 2 := by
    have h2 : (1 : ℤ) ≤ |x i| := Int.one_le_abs hi
    have h3 : (1 : ℝ) ≤ |((x i : ℤ) : ℝ)| := by exact_mod_cast h2
    nlinarith [abs_nonneg ((x i : ℤ) : ℝ), sq_abs ((x i : ℤ) : ℝ)]
  calc (1 : ℝ) ≤ ((x i : ℤ) : ℝ) ^ 2 := h1
    _ ≤ F2 x := by
      unfold F2
      exact Finset.single_le_sum (f := fun j => ((x j : ℤ) : ℝ) ^ 2) (fun j _ => sq_nonneg _)
        (Finset.mem_univ i)

theorem one_le_norm_embedPhys (x : Fin P.n → ℤ) (hx : x ≠ 0) : 1 ≤ ‖embedPhys P x‖ := by
  have h1 : 1 ≤ ‖embedPhys P x‖ ^ 2 := by
    rw [norm_sq_embedPhys]
    exact one_le_F2_of_ne_zero' hx
  nlinarith [norm_nonneg (embedPhys P x)]

/-- `8(H+1)η ≤ ε₀/2` (eq. `R:eq:param-eta`). -/
theorem eight_H_eta_le_half_eps (P : StreamParams) :
    8 * ((P.H + 1 : ℕ) : ℝ) * (P.eta : ℝ) ≤ (P.eps0 : ℝ) / 2 := by
  have h := P.eta_le
  have hH : (1 : ℚ) ≤ (P.H : ℚ) + 1 := by have := P.H.cast_nonneg (α := ℚ); linarith
  have he0 : (0 : ℚ) ≤ P.eps0 := P.eps0_pos.le
  have key : 8 * ((P.H : ℚ) + 1) * P.eta ≤ P.eps0 / 2 := by
    calc 8 * ((P.H : ℚ) + 1) * P.eta ≤ 8 * ((P.H : ℚ) + 1) * (P.eps0 / (2 ^ 20 * ((P.H : ℚ) + 1) ^ 2)) := by
          gcongr
      _ = P.eps0 / (2 ^ 17 * ((P.H : ℚ) + 1)) := by field_simp; ring
      _ ≤ P.eps0 / 2 := by
          apply div_le_div_of_nonneg_left he0 (by norm_num)
          nlinarith
  have := (Rat.cast_le (K := ℝ)).mpr key
  push_cast at this ⊢
  linarith

/-- An estimate within `8(H+1)η` of `F₂` is `ε₀`-accurate. -/
theorem estOK_of_close (x : Fin P.n → ℤ) (q : ℚ)
    (h : |(q : ℝ) - F2 x| ≤ 8 * ((P.H + 1 : ℕ) : ℝ) * (P.eta : ℝ) * F2 x) :
    EstOK ((1 / 2 : ℝ) ^ P.epsExp) x q := by
  have hF : 0 ≤ F2 x := Finset.sum_nonneg fun i _ => sq_nonneg _
  have hε : ((P.eps0 : ℚ) : ℝ) = (1 / 2 : ℝ) ^ P.epsExp := by simp [StreamParams.eps0]
  have hk := eight_H_eta_le_half_eps P
  rw [hε] at hk
  set ε := (1 / 2 : ℝ) ^ P.epsExp
  have hε0 : 0 < ε := by positivity
  have hε1 : ε ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hclose : |(q : ℝ) - F2 x| ≤ ε / 2 * F2 x :=
    h.trans (mul_le_mul_of_nonneg_right hk hF)
  obtain ⟨h1, h2⟩ := abs_le.mp hclose
  constructor
  · rw [div_le_iff₀ (by linarith)]
    nlinarith
  · nlinarith

/-! ## Phase transitions without code -/

theorem jointInv_startStep4 {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.guards P.H) c o g) :
    JointInv P (.evals P.H) c o g ∧ leafVal P c = ‖(shadowOf P g).x P.H‖ ^ 2 := by
  obtain ⟨htp, hleaf⟩ := treePart_startStep4 h.tp
  exact ⟨⟨htp, bankPart_startStep4 h.bp, countPart_startStep4 h.cp, h.sp, h.notFailed,
    by simpa [phIdle] using h.time⟩, hleaf⟩

theorem jointInv_bypass {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.guards 0) c o g) :
    JointInv P .idle { c with t := c.t + 1 } o g :=
  ⟨(treePart_bypass h.tp).congr_c rfl rfl, bankPart_bypass h.bp,
    (countPart_bypass h.cp).congr rfl rfl rfl rfl, h.sp, h.notFailed, by simpa [phIdle] using h.time⟩

theorem jointInv_endRound {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.evals 0) c o g) :
    JointInv P .idle { c with t := c.t + 1 } o g :=
  ⟨(treePart_endRound h.tp).congr_c rfl rfl, bankPart_endRound h.bp, countPart_endRound h.cp rfl, h.sp,
    h.notFailed, by simpa [phIdle] using h.time⟩

/-! ## The code of a round after Step 1 -/

/-- The controller code of a round after Step 1 (as in `roundCode`). -/
def roundTail (P : StreamParams) (i : ℕ) (Δ : ℤ) (c1 : CState) : AlgM (CState × ℚ) :=
  if c1.failed then pure (finishC c1 0)
  else do
    let r2 ← step2Code P i Δ c1
    if r2.1.failed || r2.2 then pure (finishC r2.1 0)
    else do
      let c3 ← step3Code P r2.1
      if c3.failed then pure (finishC c3 0)
      else do
        let r4 ← step4Code P c3
        pure (finishC r4.1 r4.2)

theorem roundCode_eq (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) (hc : c.failed = false) :
    roundCode P c i Δ = ((noteM TreeEvent.newRound).bind fun _ => step1Code P c).bind (roundTail P i Δ) := by
  rw [AlgM.bind_assoc]
  unfold roundCode
  rw [hc]
  rfl

/-- **From the end of Step 1 to the end of the round**: the joint invariant at the end of the round, the round
counter, the new root input `x^{(t+1)}`, and the `ε₀`-accuracy of the estimate (a zero round on the fingerprint
event reports `0`; a nonzero round the Step-4 value). -/
theorem wp_roundTail (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F) (hgood : GoodLog P gF)
    {c1 : CState} {o1 : OState} {g1 : Ghost} (h : JointInv P (.births P.H) c1 o1 g1) (i : Fin P.n) (Δ : ℤ)
    {x : Fin P.n → ℤ} (hx : (shadowOf P g1).x0 = embedPhys P x)
    (hbox' : ∀ j, |updVec x i Δ j| ≤ (P.U : ℤ)) (ht : (shadowOf P g1).t ≤ P.m)
    (hfp : (fpUpdate P o1.fpSeed o1.fpVal (i.val + 1) Δ == 0) = true ↔ updVec x i Δ = 0) :
    WP P F (roundTail P i.val Δ c1)
      (fun r o' g' => JointInv P .idle r.1 o' g' ∧ r.1.t = c1.t + 1 ∧
        (shadowOf P g').x0 = embedPhys P (updVec x i Δ) ∧ o'.fpSeed = o1.fpSeed ∧
        EstOK ((1 / 2 : ℝ) ^ P.epsExp) (updVec x i Δ) r.2) o1 g1 := by
  have hW' : ‖embedPhys P (updVec x i Δ)‖ ≤ (P.W : ℝ) := norm_embedPhys_le_W _ hbox'
  have hbox1 : ‖((shadowOf P g1).step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ) := by
    rw [Tree.TreeState.step_phys_x0, hx, ← embedPhys_update]; exact hW'
  unfold roundTail
  simp only [h.notFailed, Bool.false_eq_true, if_false, AlgM.bind_eq, AlgM.pure_eq]
  apply wp_bind
  refine wp_mono (wp_step2 hP h i Δ hbox1 ht) ?_
  rintro ⟨c2, z⟩ o2 g2 ⟨h2, hz, hfp2, hS2, ht2⟩
  have hx2 : (shadowOf P g2).x0 = embedPhys P (updVec x i Δ) := by
    rw [hS2, Tree.TreeState.step_phys_x0, hx, embedPhys_update]
  have hT2 : (shadowOf P g2).t = (shadowOf P g1).t := by rw [hS2]; rfl
  have hc2 : c2.failed = false := h2.notFailed
  simp only [hc2, Bool.false_or]
  cases z with
  | true =>
    simp only [if_true]
    apply wp_pure
    have hzero : updVec x i Δ = 0 := hfp.mp (by simpa using hz.symm)
    refine ⟨jointInv_bypass h2, by simpa [finishC] using ht2, hx2, hfp2, ?_⟩
    simp only [finishC, hc2, Bool.false_eq_true, if_false]
    rw [hzero]
    simp [EstOK, F2]
  | false =>
    simp only [Bool.false_eq_true, if_false]
    have hnz : updVec x i Δ ≠ 0 := fun h0 => by
      have := hfp.mpr h0
      rw [← hz] at this
      simp at this
    apply wp_bind
    refine wp_mono (wp_step3 hP h2 (by rw [hx2]; exact hW') (by rw [hT2]; exact ht)) ?_
    rintro c3 o3 g3 ⟨h3, hfr3⟩
    simp only [h3.notFailed, Bool.false_eq_true, if_false]
    obtain ⟨h4, hleaf⟩ := jointInv_startStep4 h3
    have hx3 : (shadowOf P g3).x0 = embedPhys P (updVec x i Δ) := by rw [hfr3.2.1, hx2]
    apply wp_bind
    refine wp_mono (wp_step4Code hP gF hF hgood h4 (by rw [hx3]; exact hW')
      (by rw [hfr3.2.2.1, hT2]; exact ht) (by rw [hx3]; exact one_le_norm_embedPhys _ hnz) hleaf) ?_
    rintro ⟨c4, q⟩ o4 g4 ⟨h4', hfr4, hq0, hacc⟩
    apply wp_pure
    have hx4 : (shadowOf P g4).x0 = embedPhys P (updVec x i Δ) := by rw [hfr4.2.1, hx3]
    refine ⟨jointInv_endRound h4', ?_, hx4, ?_, ?_⟩
    · simp only [finishC]
      rw [hfr4.1, hfr3.1, ht2]
    · rw [hfr4.2.2.2.1, hfr3.2.2.2.1, hfp2]
    · have hc4 : c4.failed = false := h4'.notFailed
      simp only [finishC, hc4, Bool.false_eq_true, if_false]
      rw [hx4, norm_sq_embedPhys] at hacc
      exact estOK_of_close _ _ hacc

/-! ## Rounds -/

/-- The invariant after `t ≥ 1` completed rounds, for the stream vector `x = x^{(t)}`. -/
structure RoundInv (P : StreamParams) (x : Fin P.n → ℤ) (t : ℕ) (s : State) (g : Ghost) : Prop where
  joint : JointInv P .idle s.ctrl s.orc g
  t_eq : s.t = t
  x0 : (shadowOf P g).x0 = embedPhys P x

/-- **Round `t + 1`** (`2 ≤ t + 1 ≤ m`) on the good events: from the invariant after round `t` to the invariant
after round `t + 1`, with an `ε₀`-accurate estimate, when the box promise holds for `x^{(t)}` and `x^{(t+1)}` and
the fingerprint test of the round is exact. -/
theorem wp_round (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F) (hgood : GoodLog P gF)
    {s : State} {g : Ghost} {x : Fin P.n → ℤ} {t : ℕ} (hinv : RoundInv P x t s g) (htm : t < P.m)
    (i : Fin P.n) (Δ : ℤ) (hbox : ∀ j, |x j| ≤ (P.U : ℤ)) (hbox' : ∀ j, |updVec x i Δ j| ≤ (P.U : ℤ))
    (hfp : (fpUpdate P s.fpSeed s.fpVal (i.val + 1) Δ == 0) = true ↔ updVec x i Δ = 0) :
    WP P F (roundCode P s.ctrl i.val Δ)
      (fun r o' g' => RoundInv P (updVec x i Δ) (t + 1) (State.mk' r.1 o') g' ∧ o'.fpSeed = s.fpSeed ∧
        EstOK ((1 / 2 : ℝ) ^ P.epsExp) (updVec x i Δ) r.2) s.orc g := by
  have hc : s.ctrl.failed = false := hinv.joint.notFailed
  have hT : (shadowOf P g).t = t := by
    have := hinv.joint.time
    simp only [phIdle, if_true, add_zero] at this
    rw [this]
    exact hinv.t_eq
  rw [roundCode_eq P s.ctrl i.val Δ hc]
  apply wp_bind
  refine wp_mono (wp_step1 hP gF hF hgood hinv.joint (by rw [hinv.x0]; exact norm_embedPhys_le_W x hbox)
    (by rw [hT]; exact htm)) ?_
  rintro c1 o1 g1 ⟨h1, ht1, hx1, hS1, hfs, hfv⟩
  refine wp_mono (wp_roundTail hP gF hF hgood h1 i Δ (x := x) (by rw [hx1, hinv.x0]) hbox'
    (by rw [hS1, hT]; omega) (by rw [hfs, hfv]; exact hfp)) ?_
  rintro r o' g' ⟨hJ, hrt, hx', hfs', hacc⟩
  refine ⟨⟨hJ, ?_, hx'⟩, by rw [hfs', hfs]; rfl, hacc⟩
  show r.1.t = t + 1
  rw [hrt, ht1]
  show s.t + 1 = t + 1
  rw [hinv.t_eq]

/-- **Round `1`** from the initialization data (`x^{(0)} = 0`). -/
theorem wp_round_init (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {s : State} {g : Ghost} (hinit : InitState P s.ctrl s.orc g)
    (i : Fin P.n) (Δ : ℤ) (hbox' : ∀ j, |updVec (0 : Fin P.n → ℤ) i Δ j| ≤ (P.U : ℤ))
    (hfp : (fpUpdate P s.fpSeed s.fpVal (i.val + 1) Δ == 0) = true ↔ updVec (0 : Fin P.n → ℤ) i Δ = 0) :
    WP P F (roundCode P s.ctrl i.val Δ)
      (fun r o' g' => RoundInv P (updVec 0 i Δ) 1 (State.mk' r.1 o') g' ∧ o'.fpSeed = s.fpSeed ∧
        EstOK ((1 / 2 : ℝ) ^ P.epsExp) (updVec 0 i Δ) r.2) s.orc g := by
  have hc : s.ctrl.failed = false := by rw [hinit.ctrl]
  rw [roundCode_eq P s.ctrl i.val Δ hc]
  apply wp_bind
  refine wp_mono (wp_step1_init hP gF hF hgood hinit) ?_
  rintro c1 o1 g1 ⟨h1, ht1, hx1, hS1, hfs, hfv⟩
  have hx1' : (shadowOf P g1).x0 = embedPhys P (0 : Fin P.n → ℤ) := by
    rw [hx1]; unfold embedPhys; simp
  refine wp_mono (wp_roundTail hP gF hF hgood h1 i Δ hx1' hbox'
    (by rw [hS1]; exact hP.one_le_m) (by rw [hfs, hfv]; exact hfp)) ?_
  rintro r o' g' ⟨hJ, hrt, hx', hfs', hacc⟩
  refine ⟨⟨hJ, ?_, hx'⟩, by rw [hfs', hfs]; rfl, hacc⟩
  show r.1.t = 1
  rw [hrt, ht1]

end F2e2e.C.Closure
