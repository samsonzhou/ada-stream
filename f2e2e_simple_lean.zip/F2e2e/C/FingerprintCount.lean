import F2e2e.C.FingerprintCoupling

/-!
# Counting tapes: the zero-fingerprint failure probability

Paper: `parts/partII.tex` Lemma `R:lem:zero-fingerprint` (3), proof L267–285: the capped seed
sampler is uniform on `𝔽_q` up to a failure probability `p_f` (L267), the seed is independent of
all other randomness, at most `m n` seeds are bad for every fixed value of the other randomness
(`card_seeds_badFrom_le`), hence `P[false zero] ≤ m n/q + p_f`.

The probability model is the one of the specification of Theorem C: `m + 1` independent uniform
tapes of `B` bits, tape `0` for the initialization, tape `t + 1` for round `t`. The initialization
first samples the seed (`seedProg`) and then the rest of the state (`restProg`) on the remaining bits
of tape `0`; sequential composition of bit programs is a product of laws (`BitProg.law_bind`), which
is the independence of the seed (L238, "independently of all other internal randomness").

Main result: `sum_tapes_badFrom_le`.
-/

namespace F2e2e.C.FP

open F2e2e.Discrete Finset
open scoped ENNReal

/-! ### PMF expectations -/

theorem tsum_bind_mul {α β : Type} (p : PMF α) (f : α → PMF β) (g : β → ℝ≥0∞) :
    ∑' b, (p.bind f) b * g b = ∑' a, p a * ∑' b, f a b * g b := by
  simp only [PMF.bind_apply]
  calc ∑' b, (∑' a, p a * f a b) * g b = ∑' b, ∑' a, p a * f a b * g b := by
        congr 1; funext b; rw [ENNReal.tsum_mul_right]
    _ = ∑' a, ∑' b, p a * f a b * g b := ENNReal.tsum_comm
    _ = ∑' a, p a * ∑' b, f a b * g b := by
        congr 1; funext a; rw [← ENNReal.tsum_mul_left]; congr 1; funext b; ring

theorem tsum_pure_mul {β : Type} (b0 : β) (g : β → ℝ≥0∞) :
    ∑' b, (PMF.pure b0) b * g b = g b0 := by
  classical
  rw [tsum_eq_single b0]
  · simp
  · intro b hb
    simp [PMF.pure_apply, hb]

theorem tsum_map_mul {α β : Type} (p : PMF α) (h : α → β) (g : β → ℝ≥0∞) :
    ∑' b, (p.map h) b * g b = ∑' a, p a * g (h a) := by
  rw [← PMF.bind_pure_comp, tsum_bind_mul]
  congr 1
  funext a
  rw [Function.comp_apply, tsum_pure_mul]

/-! ### Tapes -/

/-- The tape of run `j` (`[]` beyond the last run `m`); the same as `F2e2e.C.Top.tapeAt`. -/
def tapeAtM {m B : ℕ} (tapes : Fin (m + 1) → Fin B → Bool) (j : ℕ) : List Bool :=
  if h : j < m + 1 then List.ofFn (tapes ⟨j, h⟩) else []

/-- The round tapes `1, …, m` given by `tail`. -/
def tailTape {m B : ℕ} (tail : Fin m → Fin B → Bool) (j : ℕ) : List Bool :=
  if h : j - 1 < m then List.ofFn (tail ⟨j - 1, h⟩) else []

theorem tapeAtM_cons_succ {m B : ℕ} (t0 : Fin B → Bool) (tail : Fin m → Fin B → Bool) (j : ℕ) :
    tapeAtM (Fin.cons t0 tail : Fin (m + 1) → Fin B → Bool) (j + 1) = tailTape tail (j + 1) := by
  unfold tapeAtM tailTape
  simp only [Nat.add_sub_cancel]
  by_cases hj : j < m
  · rw [dif_pos (by omega), dif_pos hj]
    exact congrArg List.ofFn (Fin.cons_succ (α := fun _ => Fin B → Bool) t0 tail ⟨j, hj⟩)
  · rw [dif_neg (by omega), dif_neg hj]

theorem tapeAtM_cons_zero {m B : ℕ} (t0 : Fin B → Bool) (tail : Fin m → Fin B → Bool) :
    tapeAtM (Fin.cons t0 tail : Fin (m + 1) → Fin B → Bool) 0 = List.ofFn t0 := by
  unfold tapeAtM
  rw [dif_pos (by omega)]
  exact congrArg List.ofFn (Fin.cons_zero (α := fun _ => Fin B → Bool) t0 tail)

theorem sum_tapes_cons {m B : ℕ} (F : (Fin (m + 1) → Fin B → Bool) → ℝ≥0∞) :
    ∑ tapes, F tapes = ∑ t0 : Fin B → Bool, ∑ tail : Fin m → Fin B → Bool, F (Fin.cons t0 tail) := by
  rw [← (Fin.consEquiv (fun _ : Fin (m + 1) => Fin B → Bool)).sum_comp, Fintype.sum_prod_type]
  rfl

variable {n q : ℕ} {S : Type}

/-- `runZ` reads only the round tapes `tp (t + 1)`. -/
theorem runZ_congr_tp (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (zf : S → List ℚ → Bool)
    {tp tp' : ℕ → List Bool} (h : ∀ j, tp (j + 1) = tp' (j + 1)) (s0 : S) :
    ∀ t, runZ A adv zf tp s0 t = runZ A adv zf tp' s0 t
  | 0 => rfl
  | t + 1 => by
    simp only [runZ]
    rw [runZ_congr_tp A adv zf h s0 t, h t]

theorem badFrom_congr_tp (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (U m : ℕ)
    {tp tp' : ℕ → List Bool} (h : ∀ j, tp (j + 1) = tp' (j + 1)) (s0 : S) :
    BadFrom A adv U m tp s0 ↔ BadFrom A adv U m tp' s0 := by
  unfold BadFrom
  simp only [runZ_congr_tp A adv _ h s0]

/-! ### The count -/

open Classical in
/-- **The failure count of the zero fingerprint** (paper: Lemma `R:lem:zero-fingerprint` (3),
`P ≤ m n/q + β₀/1000`): over the `2^{(m+1)B}` tape tuples, the number on which the initialization
succeeds and the run has a false zero within the box promise is at most
`2^{(m+1)B} (m n/q + p_f)`, where `p_f` bounds the probability that the seed sampler falls back to
the seed `0` (`hlaw`: the seed law is at most uniform on `{0, …, q-1}` plus `p_f` at `0`). -/
theorem sum_tapes_badFrom_le [Fact q.Prime] (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ)
    (U m B : ℕ) (hU : U < q) {R : Type} (seedProg : BitProg ℕ) (restProg : BitProg R)
    (mk : ℕ → R → S) (hseed : ∀ r Bk, A.seed (mk r Bk) = r) (hval : ∀ r Bk, A.val (mk r Bk) = 0)
    (herase : ∀ r Bk, A.erase (mk r Bk) = A.erase (mk 0 Bk))
    (hdepth : (seedProg.bind fun r => restProg.map (mk r)).depth ≤ B) {pf : ℝ≥0∞}
    (hlaw : ∀ r, seedProg.law r ≤ (if r < q then (q : ℝ≥0∞)⁻¹ else 0) + (if r = 0 then pf else 0)) :
    ∑ tapes : Fin (m + 1) → Fin B → Bool,
      (if ∃ c, (seedProg.bind fun r => restProg.map (mk r)).run (tapeAtM tapes 0) = some c ∧
          BadFrom A adv U m (tapeAtM tapes) c.1 then (1 : ℝ≥0∞) else 0) ≤
      2 ^ ((m + 1) * B) * ((m * n : ℝ≥0∞) / q + pf) := by
  set init := seedProg.bind fun r => restProg.map (mk r) with hinit
  have hq : 0 < q := (Fact.out : q.Prime).pos
  -- per fixed round tapes: expectation over the initial state
  have hinner : ∀ tail : Fin m → Fin B → Bool,
      ∑ t0 : Fin B → Bool,
        (if ∃ c, init.run (List.ofFn t0) = some c ∧ BadFrom A adv U m (tailTape tail) c.1
          then (1 : ℝ≥0∞) else 0) ≤ 2 ^ B * ((m * n : ℝ≥0∞) / q + pf) := by
    intro tail
    set g : S → ℝ≥0∞ := fun s0 => if BadFrom A adv U m (tailTape tail) s0 then 1 else 0 with hg
    have h1 : ∀ t0 : Fin B → Bool,
        (if ∃ c, init.run (List.ofFn t0) = some c ∧ BadFrom A adv U m (tailTape tail) c.1
          then (1 : ℝ≥0∞) else 0) = (init.run (List.ofFn t0)).elim 0 (fun c => g c.1) := by
      intro t0
      cases hr : init.run (List.ofFn t0) with
      | none => simp
      | some c =>
        simp only [Option.elim, hg]
        by_cases hb : BadFrom A adv U m (tailTape tail) c.1
        · rw [if_pos ⟨c, rfl, hb⟩, if_pos hb]
        · rw [if_neg, if_neg hb]
          rintro ⟨c', hc', hb'⟩
          cases hc'
          exact hb hb'
    simp only [h1]
    rw [BitProg.sum_tapes_eq init hdepth g]
    gcongr
    -- the expectation over `law init`
    rw [hinit, BitProg.law_bind, tsum_bind_mul]
    simp only [BitProg.law_map, tsum_map_mul]
    -- swap the seed and the rest of the state
    have hswap : ∑' r, seedProg.law r * ∑' Bk, restProg.law Bk * g (mk r Bk) =
        ∑' Bk, restProg.law Bk * ∑' r, seedProg.law r * g (mk r Bk) := by
      calc ∑' r, seedProg.law r * ∑' Bk, restProg.law Bk * g (mk r Bk)
          = ∑' r, ∑' Bk, seedProg.law r * (restProg.law Bk * g (mk r Bk)) := by
            congr 1; funext r; rw [ENNReal.tsum_mul_left]
        _ = ∑' Bk, ∑' r, seedProg.law r * (restProg.law Bk * g (mk r Bk)) := ENNReal.tsum_comm
        _ = ∑' Bk, restProg.law Bk * ∑' r, seedProg.law r * g (mk r Bk) := by
            congr 1; funext Bk; rw [← ENNReal.tsum_mul_left]; congr 1; funext r; ring
    rw [hswap]
    -- for every value of the rest of the state, the seed average is small
    have hseedavg : ∀ Bk, ∑' r, seedProg.law r * g (mk r Bk) ≤ (m * n : ℝ≥0∞) / q + pf := by
      intro Bk
      have hcount := card_seeds_badFrom_le A adv U m hU (tailTape tail) (fun r => mk r Bk)
        (fun r => hseed r Bk) (fun r => hval r Bk) (fun r => herase r Bk)
      calc ∑' r, seedProg.law r * g (mk r Bk)
          ≤ ∑' r, ((if r < q then (q : ℝ≥0∞)⁻¹ else 0) + (if r = 0 then pf else 0)) *
              g (mk r Bk) := ENNReal.tsum_le_tsum fun r => mul_le_mul_left (hlaw r) _
        _ = ∑' r, (if r < q then (q : ℝ≥0∞)⁻¹ else 0) * g (mk r Bk) +
              ∑' r, (if r = 0 then pf else 0) * g (mk r Bk) := by
            rw [← ENNReal.tsum_add]; congr 1; funext r; ring
        _ ≤ (m * n : ℝ≥0∞) / q + pf := by
            gcongr
            · rw [tsum_eq_sum (s := range q) (fun r hr => by
                simp only [Finset.mem_range] at hr; simp [hr])]
              calc ∑ r ∈ range q, (if r < q then (q : ℝ≥0∞)⁻¹ else 0) * g (mk r Bk)
                  = (q : ℝ≥0∞)⁻¹ * ∑ r ∈ range q, g (mk r Bk) := by
                    rw [Finset.mul_sum]
                    refine Finset.sum_congr rfl fun r hr => ?_
                    rw [if_pos (Finset.mem_range.mp hr)]
                _ = (q : ℝ≥0∞)⁻¹ *
                    (((range q).filter (fun r => BadFrom A adv U m (tailTape tail) (mk r Bk))).card :
                      ℝ≥0∞) := by
                    congr 1
                    simp only [hg]
                    rw [Finset.sum_boole]
                _ ≤ (q : ℝ≥0∞)⁻¹ * (m * n : ℝ≥0∞) := by
                    gcongr
                    exact_mod_cast hcount
                _ = (m * n : ℝ≥0∞) / q := by rw [ENNReal.div_eq_inv_mul]
            · rw [tsum_eq_single 0 (fun r hr => by simp [hr])]
              simp only [if_true]
              calc pf * g (mk 0 Bk) ≤ pf * 1 := by
                    gcongr
                    simp only [hg]
                    split_ifs <;> simp
                _ = pf := mul_one pf
    calc ∑' Bk, restProg.law Bk * ∑' r, seedProg.law r * g (mk r Bk)
        ≤ ∑' Bk, restProg.law Bk * ((m * n : ℝ≥0∞) / q + pf) :=
          ENNReal.tsum_le_tsum fun Bk => mul_le_mul_right (hseedavg Bk) _
      _ = (m * n : ℝ≥0∞) / q + pf := by
          rw [ENNReal.tsum_mul_right, PMF.tsum_coe, one_mul]
  -- the sum over all tape tuples
  rw [sum_tapes_cons, Finset.sum_comm]
  have hF : ∀ (t0 : Fin B → Bool) (tail : Fin m → Fin B → Bool),
      (if ∃ c, init.run (tapeAtM (Fin.cons t0 tail : Fin (m + 1) → Fin B → Bool) 0) = some c ∧
          BadFrom A adv U m (tapeAtM (Fin.cons t0 tail : Fin (m + 1) → Fin B → Bool)) c.1
        then (1 : ℝ≥0∞) else 0) =
      (if ∃ c, init.run (List.ofFn t0) = some c ∧ BadFrom A adv U m (tailTape tail) c.1
        then (1 : ℝ≥0∞) else 0) := by
    intro t0 tail
    rw [tapeAtM_cons_zero]
    congr 1
    apply propext
    simp only [badFrom_congr_tp A adv U m (tapeAtM_cons_succ t0 tail)]
  simp only [hF]
  calc ∑ tail : Fin m → Fin B → Bool, ∑ t0 : Fin B → Bool,
        (if ∃ c, init.run (List.ofFn t0) = some c ∧ BadFrom A adv U m (tailTape tail) c.1
          then (1 : ℝ≥0∞) else 0)
      ≤ ∑ _tail : Fin m → Fin B → Bool, 2 ^ B * ((m * n : ℝ≥0∞) / q + pf) :=
        Finset.sum_le_sum fun tail _ => hinner tail
    _ = 2 ^ ((m + 1) * B) * ((m * n : ℝ≥0∞) / q + pf) := by
        rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ← mul_assoc]
        congr 1
        rw [Fintype.card_fun, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin,
          Fintype.card_fin]
        push_cast
        rw [← pow_mul, ← pow_add]
        congr 1
        ring

end F2e2e.C.FP
