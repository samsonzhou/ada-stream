import Mathlib

/-!
# Part III §5.5: Lemma 5.10 (buffered two-level epoch energy invariant), maintainable form

Source: `parts/partIII.tex` Lemma `R:lem:epoch-envelope-invariant` (L862–894).

The paper proves, for the birth-normalized residual energy `Ẽ_d = ‖r_d/C_d‖² = E_d/C_d²` of a depth-`d`
learner in epoch `k` (envelope `𝒰_{d,k} = 2^{-k}𝒰_{d,0}`):
(a) `Ẽ_d ≤ 𝒰_{d,k}/2` at the start of epoch `k`; (b) `Ẽ_d ≤ 𝒰_{d,k}/2 + Tγ²𝒰_{d,k} ≤ (33/64)𝒰_{d,k} < 𝒰_{d,k}`
throughout epoch `k`; and after `K₀ = ⌈128/η²⌉` local contractions
`Ẽ_d ≤ (1 − η²/64)^{K₀}(𝒰_{d,k}/2) + Tγ²𝒰_{d,k} ≤ (e^{-2}/2 + 1/64)𝒰_{d,k} < 𝒰_{d,k}/4 = 𝒰_{d,k+1}/2`.

For the chronological induction of Theorem 6.4 we state it as a bound maintained by every event
(`EpochBound ρ γ U Ẽ j n`: `Ẽ ≤ ρ^j U/2 + n γ²U` after `j` contractions and `n` own guards since the start of
the epoch, `ρ = 1 − η²/64`):
* `EpochBound.birth` (base case (a) for `k = 0`, from Theorem 5.11 (2b) at birth: `‖x_d(t_birth)‖² ≤ V_d² ≤ 𝒰_{d,0}/2`);
* suffix updates and strict-ancestor rescalings leave `Ẽ` unchanged (Lemma 5.4 (iii)(a),(b));
* `EpochBound.guard`: an own guard adds `(δ/C)² ≤ γ²𝒰_{d,k}` (Lemma 5.4 (iii)(c), Lemma 5.7 (2));
* `EpochBound.contract`: a local correction multiplies by at most `ρ` (Lemma 5.4 (iii)(d), Theorem 5.9 (4));
* `EpochBound.ceiling`: (b);
* `EpochBound.transition`: the `K₀`-th contraction re-establishes (a) for epoch `k+1`.
-/

namespace F2e2e.C.Tree

/-- The maintained form of Lemma 5.10: during an epoch with envelope `U`, after `j` local contractions of
factor `ρ` and `n` own guard injections since the start of the epoch, `Ẽ ≤ ρ^j (U/2) + n γ² U`
(partIII.tex L885–888). -/
def EpochBound (ρ γ U Et : ℝ) (j n : ℕ) : Prop :=
  Et ≤ ρ ^ j * (U / 2) + n * (γ ^ 2 * U)

/-- `(1 − η²/64)^{K₀} ≤ exp(−(η²/64)K₀) ≤ e^{-2}` for `0 < η ≤ 1` and `K₀ ≥ 128/η²` (partIII.tex L889;
external input `(1−x)^n ≤ e^{−nx}` from `1 + y ≤ e^y`). -/
theorem contraction_pow_le_exp {η : ℝ} {K0 : ℕ} (hη : 0 < η) (hη1 : η ≤ 1) (hK0 : 128 / η ^ 2 ≤ K0) :
    (1 - η ^ 2 / 64) ^ K0 ≤ Real.exp (-2) := by
  have hx0 : 0 ≤ 1 - η ^ 2 / 64 := by nlinarith
  have hx1 : 1 - η ^ 2 / 64 ≤ Real.exp (-(η ^ 2 / 64)) := by
    have := Real.add_one_le_exp (-(η ^ 2 / 64)); linarith
  calc (1 - η ^ 2 / 64) ^ K0 ≤ Real.exp (-(η ^ 2 / 64)) ^ K0 := pow_le_pow_left₀ hx0 hx1 K0
    _ = Real.exp (K0 * (-(η ^ 2 / 64))) := (Real.exp_nat_mul _ _).symm
    _ ≤ Real.exp (-2) := by
        apply Real.exp_le_exp.2
        have hη2 : 0 < η ^ 2 := by positivity
        have : 128 ≤ (K0 : ℝ) * η ^ 2 := by
          rw [div_le_iff₀ hη2] at hK0; linarith
        nlinarith

/-- `e^{-2} < 0.1354` and `e^{-2}/2 + 1/64 < 0.084 < 1/4` (partIII.tex L889–891; from `e > 2.7182818283`). -/
theorem exp_neg_two_bounds :
    Real.exp (-2) < 0.1354 ∧ 1 / 2 * Real.exp (-2) + 1 / 64 < 0.084 ∧ (0.084 : ℝ) < 1 / 4 := by
  have he := Real.exp_one_gt_d9
  have h2 : Real.exp 2 = Real.exp 1 ^ 2 := by
    rw [← Real.exp_nat_mul]; norm_num
  have h3 : (7.389 : ℝ) < Real.exp 2 := by rw [h2]; nlinarith
  have h4 : Real.exp (-2) = (Real.exp 2)⁻¹ := Real.exp_neg 2
  have h5 : Real.exp (-2) < 0.1354 := by
    rw [h4, inv_lt_comm₀ (by positivity) (by norm_num)]
    calc (0.1354 : ℝ)⁻¹ < 7.389 := by norm_num
      _ < Real.exp 2 := h3
  refine ⟨h5, by linarith, by norm_num⟩

namespace EpochBound

/-- Lemma 5.10 (a) at the start of an epoch (`j = n = 0`), in particular at birth (partIII.tex L881–885:
`Ẽ_d(t_birth) = ‖x_d(t_birth)‖² ≤ V_d² ≤ 𝒰_{d,0}/2`). -/
theorem start {ρ γ U Et : ℝ} (h : Et ≤ U / 2) : EpochBound ρ γ U Et 0 0 := by
  unfold EpochBound; simp; linarith

/-- An event that leaves `Ẽ` unchanged (suffix update or strict-ancestor rescaling, Lemma 5.4 (iii)(a),(b)). -/
theorem of_eq {ρ γ U Et Et' : ℝ} {j n : ℕ} (h : EpochBound ρ γ U Et j n) (he : Et' = Et) :
    EpochBound ρ γ U Et' j n := by
  subst he; exact h

/-- An own guard injection increases `Ẽ` by `g = (δ/C)² ≤ γ²U` (Lemma 5.4 (iii)(c), Lemma 5.7 (2)). -/
theorem guard {ρ γ U Et g : ℝ} {j n : ℕ} (h : EpochBound ρ γ U Et j n) (hg : g ≤ γ ^ 2 * U) :
    EpochBound ρ γ U (Et + g) j (n + 1) := by
  unfold EpochBound at *; push_cast; linarith

/-- A local contraction `Ẽ⁺ ≤ ρẼ` with `0 ≤ ρ ≤ 1` (Lemma 5.4 (iii)(d) and Theorem 5.9 (4)). -/
theorem contract {ρ γ U Et Et' : ℝ} {j n : ℕ} (h : EpochBound ρ γ U Et j n) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1)
    (hU : 0 ≤ U) (hE' : Et' ≤ ρ * Et) : EpochBound ρ γ U Et' (j + 1) n := by
  unfold EpochBound at *
  have h1 : ρ * Et ≤ ρ * (ρ ^ j * (U / 2) + n * (γ ^ 2 * U)) := mul_le_mul_of_nonneg_left h hρ0
  have h2 : 0 ≤ (n : ℝ) * (γ ^ 2 * U) := by positivity
  have h3 : ρ * ((n : ℝ) * (γ ^ 2 * U)) ≤ (n : ℝ) * (γ ^ 2 * U) := by nlinarith
  rw [pow_succ]
  nlinarith

/-- Lemma 5.10 (b) (eq. `R:eq:buffered-epoch-ceiling`, partIII.tex L869–872, L885–888): with at most `T`
own guards in the epoch (at most one per round and `m < T` rounds) and `Tγ² ≤ 1/64`:
`Ẽ ≤ U/2 + Tγ²U ≤ (33/64)U < U`. -/
theorem ceiling {ρ γ U Et : ℝ} {j n T : ℕ} (h : EpochBound ρ γ U Et j n) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1)
    (hU : 0 < U) (hn : n ≤ T) (hT : (T : ℝ) * γ ^ 2 ≤ 1 / 64) :
    Et ≤ U / 2 + T * γ ^ 2 * U ∧ U / 2 + T * γ ^ 2 * U ≤ 33 / 64 * U ∧ 33 / 64 * U < U := by
  unfold EpochBound at h
  have h1 : ρ ^ j ≤ 1 := pow_le_one₀ hρ0 hρ1
  have h2 : ρ ^ j * (U / 2) ≤ U / 2 := by nlinarith
  have hn' : (n : ℝ) ≤ T := by exact_mod_cast hn
  have h3 : (n : ℝ) * (γ ^ 2 * U) ≤ T * γ ^ 2 * U := by
    have : 0 ≤ γ ^ 2 * U := by positivity
    nlinarith
  refine ⟨by linarith, ?_, by linarith⟩
  have : (T : ℝ) * γ ^ 2 * U ≤ 1 / 64 * U := by nlinarith
  linarith

/-- Lemma 5.10, epoch transition (eq. `R:eq:epoch-transition-contraction`, partIII.tex L873–876, L889–893):
after `K₀ ≥ 128/η²` contractions in the epoch,
`Ẽ ≤ (1 − η²/64)^{K₀}(U/2) + Tγ²U ≤ (e^{-2}/2 + 1/64)U < U/4 = (U/2)/2`; i.e. (a) holds for the next epoch,
whose envelope is `U/2`. -/
theorem transition {η γ U Et : ℝ} {K0 n T : ℕ} (h : EpochBound (1 - η ^ 2 / 64) γ U Et K0 n)
    (hη : 0 < η) (hη1 : η ≤ 1) (hK0 : 128 / η ^ 2 ≤ K0) (hU : 0 < U) (hn : n ≤ T)
    (hT : (T : ℝ) * γ ^ 2 ≤ 1 / 64) :
    Et ≤ (1 / 2 * Real.exp (-2) + 1 / 64) * U ∧ (1 / 2 * Real.exp (-2) + 1 / 64) * U < U / 4 ∧
      EpochBound (1 - η ^ 2 / 64) γ (U / 2) Et 0 0 := by
  unfold EpochBound at h
  have hp := contraction_pow_le_exp hη hη1 hK0
  have hb := exp_neg_two_bounds
  have hn' : (n : ℝ) ≤ T := by exact_mod_cast hn
  have h3 : (n : ℝ) * (γ ^ 2 * U) ≤ 1 / 64 * U := by
    have : 0 ≤ γ ^ 2 * U := by positivity
    nlinarith
  have h4 : (1 - η ^ 2 / 64) ^ K0 * (U / 2) ≤ Real.exp (-2) * (U / 2) := by
    apply mul_le_mul_of_nonneg_right hp; positivity
  have e1 : Et ≤ (1 / 2 * Real.exp (-2) + 1 / 64) * U := by nlinarith
  have e2 : (1 / 2 * Real.exp (-2) + 1 / 64) * U < U / 4 := by nlinarith
  refine ⟨e1, e2, ?_⟩
  unfold EpochBound; simp; linarith

end EpochBound

end F2e2e.C.Tree
