import Mathlib

/-!
# Part III §5.2: Lemma 5.4 (homogeneous child rescaling, birth-normalized residual invariance), algebraic form

Source: `parts/partIII.tex` Lemma `R:lem:homogeneous-child-rescaling` (L527–585).

A learner decomposes its input as `x = a + q = r + y` with `r = a − u`, `y = u + q`.
* (i) `rescale_single_step` (eq. `R:eq:single-step-child-rescaling`): under `u⁺ = u + a_step y` (with `a, q`
  fixed), `r⁺ = r − a_step y`, `y⁺ = (1 + a_step) y`, `r⁺ + y⁺ = r + y = x`; `rescale_guard_coord`
  (eq. `R:eq:guard-coord-residual-rescaling`): on a coordinate with `x_g = 0`, `r_g⁺ = (1 + a_step) r_g`.
* (ii) `cumulative_identity` (eq. `R:eq:cumulative-y-identity`); explanatory in the paper (used only in
  Remark 5.5), included for completeness.
* (iii) `normalized_scale` (eq. `R:eq:birth-normalized-prefix-invariance` and (b)),
  `normalized_energy_scale` ((b) for `Ẽ = ‖r/C‖² = E/C²`, eq. `R:eq:birth-normalized-energy-def`),
  `normalized_energy_suffix` ((a)), `normalized_energy_guard` ((c), fresh coordinate),
  `normalized_energy_contract` ((d), eq. `R:eq:normalized-energy-contraction`).
-/

namespace F2e2e.C.Tree

/-! ## (i) The single-step identity -/

/-- Lemma 5.4 (i) (eq. `R:eq:single-step-child-rescaling`, partIII.tex L533–536, L575): with `r = a − u`,
`y = u + q` and `u⁺ = u + a_step y` (`a, q` fixed): `r⁺ = a − u⁺ = r − a_step y`,
`y⁺ = u⁺ + q = (1 + a_step) y`, and `r⁺ + y⁺ = r + y`. -/
theorem rescale_single_step {M : Type*} [AddCommGroup M] [Module ℝ M] (a q u : M) (s : ℝ) :
    a - (u + s • (u + q)) = (a - u) - s • (u + q) ∧
      (u + s • (u + q)) + q = (1 + s) • (u + q) ∧
      (a - (u + s • (u + q))) + ((u + s • (u + q)) + q) = (a - u) + (u + q) := by
  refine ⟨by abel, ?_, by abel⟩
  rw [add_smul, one_smul]
  abel

/-- Lemma 5.4 (i) (eq. `R:eq:guard-coord-residual-rescaling`, partIII.tex L537–540): on a coordinate with
`x_g = r_g + y_g = 0`, `r_g⁺ = r_g − a_step y_g = (1 + a_step) r_g`. -/
theorem rescale_guard_coord {rg yg : ℝ} (s : ℝ) (hx : rg + yg = 0) : rg - s * yg = (1 + s) * rg := by
  have : yg = -rg := by linarith
  subst this
  ring

/-! ## (ii) The cumulative multiplier identity -/

/-- Lemma 5.4 (ii) (eqs. `R:eq:cumulative-y-recurrence`, `R:eq:cumulative-Pi-def`,
`R:eq:cumulative-y-identity`; partIII.tex L541–552, L577–582): if `y_0 = v_0` and
`y_{j+1} = c_{j+1}(y_j + d_j)` with `c_h ≠ 0`, then, with `Π_j = ∏_{h=1}^{j} c_h`,
`y_k = Π_k [v_0 + Σ_{j<k} d_j/Π_j]`. -/
theorem cumulative_identity {M : Type*} [AddCommGroup M] [Module ℝ M] (v0 : M) (c : ℕ → ℝ)
    (dv y : ℕ → M) (h0 : y 0 = v0) (hy : ∀ j, y (j + 1) = c (j + 1) • (y j + dv j))
    (hc : ∀ j, c (j + 1) ≠ 0) (k : ℕ) :
    y k = (∏ h ∈ Finset.range k, c (h + 1)) •
      (v0 + ∑ j ∈ Finset.range k, (∏ h ∈ Finset.range j, c (h + 1))⁻¹ • dv j) := by
  induction k with
  | zero => simp [h0]
  | succ k ih =>
    have hP : (∏ h ∈ Finset.range k, c (h + 1)) ≠ 0 :=
      Finset.prod_ne_zero_iff.mpr fun j _ => hc j
    rw [hy k, ih, Finset.prod_range_succ, Finset.sum_range_succ]
    set Pk := ∏ h ∈ Finset.range k, c (h + 1)
    set S := ∑ j ∈ Finset.range k, (∏ h ∈ Finset.range j, c (h + 1))⁻¹ • dv j
    have e1 : c (k + 1) * Pk * Pk⁻¹ = c (k + 1) := mul_inv_cancel_right₀ hP _
    simp only [smul_add, smul_smul, mul_comm Pk (c (k + 1)), e1]
    abel

/-- Lemma 5.4 (ii), norm form (eq. `R:eq:cumulative-y-identity`, second identity):
`‖y_k‖² = Π_k² ‖v_0 + Σ_{j<k} d_j/Π_j‖²`. -/
theorem cumulative_identity_norm {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] (v0 : E)
    (c : ℕ → ℝ) (dv y : ℕ → E) (h0 : y 0 = v0) (hy : ∀ j, y (j + 1) = c (j + 1) • (y j + dv j))
    (hc : ∀ j, c (j + 1) ≠ 0) (k : ℕ) :
    ‖y k‖ ^ 2 = (∏ h ∈ Finset.range k, c (h + 1)) ^ 2 *
      ‖v0 + ∑ j ∈ Finset.range k, (∏ h ∈ Finset.range j, c (h + 1))⁻¹ • dv j‖ ^ 2 := by
  rw [cumulative_identity v0 c dv y h0 hy hc k, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]

/-! ## (iii) Birth-normalized invariance -/

/-- Lemma 5.4 (iii), eq. `R:eq:birth-normalized-prefix-invariance` and (b) (partIII.tex L553–556, L564,
L584): a strict-ancestor rescaling multiplies `(a, u, C)` by `c ≠ 0` and leaves the birth-normalized prefix
`a/C` and the normalized residual `(a − u)/C` unchanged. -/
theorem normalized_scale {M : Type*} [AddCommGroup M] [Module ℝ M] (a u : M) (C c : ℝ) (hc : c ≠ 0) :
    (c * C)⁻¹ • (c • a) = C⁻¹ • a ∧ (c * C)⁻¹ • (c • a - c • u) = C⁻¹ • (a - u) := by
  have key : (c * C)⁻¹ * c = C⁻¹ := by
    rw [mul_inv, mul_comm c⁻¹ C⁻¹, mul_assoc, inv_mul_cancel₀ hc, mul_one]
  refine ⟨by rw [smul_smul, key], ?_⟩
  rw [← smul_sub, smul_smul, key]

/-- Lemma 5.4 (iii)(b) for the birth-normalized residual energy `Ẽ = ‖r‖²/C²`
(eq. `R:eq:birth-normalized-energy-def`): `‖c r‖²/(cC)² = ‖r‖²/C²` for `c ≠ 0`. -/
theorem normalized_energy_scale {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] (r : E)
    (C c : ℝ) (hc : c ≠ 0) : ‖c • r‖ ^ 2 / (c * C) ^ 2 = ‖r‖ ^ 2 / C ^ 2 := by
  rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs, mul_pow]
  exact mul_div_mul_left _ _ (pow_ne_zero 2 hc)

/-- Lemma 5.4 (iii)(a) (partIII.tex L563, L584): a suffix addition `q ↦ q + Δq` (physical update or ancestor
guard) adds `Δq` to both `x = a + q` and `y = u + q` and leaves `r = x − y = a − u` (and `a`, `u`, `C`, hence
`Ẽ`) unchanged. -/
theorem normalized_energy_suffix {M : Type*} [AddCommGroup M] (a q u dq : M) :
    (a + (q + dq)) - (u + (q + dq)) = (a + q) - (u + q) ∧ (a + q) - (u + q) = a - u ∧
      a + (q + dq) = (a + q) + dq ∧ u + (q + dq) = (u + q) + dq := by
  refine ⟨by abel, by abel, by abel, by abel⟩

/-- Lemma 5.4 (iii)(c) (partIII.tex L565, L584): injecting the own guard `+δ e_g` into `u` on a fresh
coordinate (`r_g = 0`) changes the residual to `r − δ e_g` and increases `Ẽ` by exactly `(δ/C)²`. -/
theorem normalized_energy_guard {ι : Type*} [Fintype ι] [DecidableEq ι] (r : EuclideanSpace ℝ ι) (g : ι)
    (δ C : ℝ) (hg : r g = 0) :
    ‖r - EuclideanSpace.single g δ‖ ^ 2 / C ^ 2 = ‖r‖ ^ 2 / C ^ 2 + (δ / C) ^ 2 := by
  have hsq : ∀ x : EuclideanSpace ℝ ι, ‖x‖ ^ 2 = ∑ i, x i ^ 2 := by
    intro x
    rw [EuclideanSpace.norm_eq, Real.sq_sqrt (Finset.sum_nonneg fun i _ => by positivity)]
    simp [Real.norm_eq_abs, sq_abs]
  have hpt : ∀ i, (r - EuclideanSpace.single g δ) i ^ 2 = r i ^ 2 + (if i = g then δ ^ 2 else 0) := by
    intro i
    by_cases hi : i = g
    · subst hi; simp [hg]
    · simp [hi]
  rw [hsq, hsq, Finset.sum_congr rfl (fun i _ => hpt i), Finset.sum_add_distrib,
    Finset.sum_ite_eq' Finset.univ g, if_pos (Finset.mem_univ g), add_div, div_pow]

/-- Lemma 5.4 (iii)(d) (eq. `R:eq:normalized-energy-contraction`, partIII.tex L566–569, L584): a local
correction with `E⁺ ≤ ρE` and `C` unchanged gives `Ẽ⁺ ≤ ρẼ`. -/
theorem normalized_energy_contract {Ep E C ρ : ℝ} (h : Ep ≤ ρ * E) : Ep / C ^ 2 ≤ ρ * (E / C ^ 2) := by
  rw [← mul_div_assoc]
  exact div_le_div_of_nonneg_right h (sq_nonneg C)

end F2e2e.C.Tree
