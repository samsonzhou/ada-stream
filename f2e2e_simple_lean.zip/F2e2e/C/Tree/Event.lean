import F2e2e.C.Params

/-!
# Part III §5: the tree-shadow events (interface file; imports only the parameters)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree` (L466–517), with the analytical (shadow)
semantics of its Steps 1–4 (Definition `R:def:binary-tree-architecture` (3), L433–437; Lemma
`R:lem:homogeneous-child-rescaling`, L527–585; Lemma `R:lem:guard-orthogonality`, L594–616).

The chronological induction of Theorem 6.4 (`F2e2e/C/Closure*`) runs the algorithm of `F2e2e/C/Alg` and, in
lockstep, the tree shadow of `F2e2e/C/Tree/Shadow.lean` driven by the events below, which carry the exact
data the algorithm actually chose (the shadows of Section 6 are defined "by applying the exact same dyadically
rounded step coefficients and guard amplitudes actually chosen", partIII.tex L997):

* `newRound`: the start of round `t + 1` (before Step 1);
* `birth d`: Step 1, the birth of depth `d` (the reborn depths `d₀, …, H − 1`, shallowest first; L472–478);
* `phys i Δ`: Step 2, the physical update `x_{i} ← x_{i} + Δ` (0-based coordinate `i`, paper coordinate
  `i + 1`; L480–483);
* `guard d g δ`: Step 3 at depth `d` (L487–491), the guard amplitude `δ = δ_d` actually injected (real value
  `mantissa · h_g`, possibly `0` when omitted) on the Lean index `g` of the guard coordinate `g(d,t)`;
  one such event per depth per round that enters Step 3 (also when `δ = 0`), so that every learner has one
  ghost record per evaluated round;
* `accept d`: Step 4 at depth `d`, `ACCEPT` (L499–500; no shadow change);
* `correct d c`: Step 4 at depth `d`, a rejection with multiplier `c = 1 + a_step` (L501–510).
-/

namespace F2e2e.C.Tree

open F2e2e

/-- The tree-shadow events of Algorithm `R:alg:within-round-tree` (see the module docstring), for `n`
physical coordinates and the ambient dimension `N = D_*`. (The dimensions are parameters rather than
`P.n`, `P.Dstar`: inductive types whose constructor fields mention `P.Dstar` hit the maximal recursion depth
when Lean generates their auxiliary constructions; use `TreeEv P`.) -/
inductive TreeEvent (n N : ℕ) where
  /-- start of the next round (before Step 1) -/
  | newRound : TreeEvent n N
  /-- Step 1: birth of depth `d` -/
  | birth (d : ℕ) : TreeEvent n N
  /-- Step 2: physical update `x_i ← x_i + Δ` (0-based `i`) -/
  | phys (i : Fin n) (Δ : ℤ) : TreeEvent n N
  /-- Step 3 at depth `d`: guard amplitude `δ` (possibly `0`) on the Lean index `g` of `g(d,t)` -/
  | guard (d : ℕ) (g : Fin N) (δ : ℝ) : TreeEvent n N
  /-- Step 4 at depth `d`: `ACCEPT` -/
  | accept (d : ℕ) : TreeEvent n N
  /-- Step 4 at depth `d`: rejection, correction with multiplier `c = 1 + a_step` -/
  | correct (d : ℕ) (c : ℝ) : TreeEvent n N

/-- The tree-shadow events for the parameters `P` (`n = P.n`, `N = D_* = P.Dstar`). -/
abbrev TreeEv (P : StreamParams) := TreeEvent P.n P.Dstar

end F2e2e.C.Tree
