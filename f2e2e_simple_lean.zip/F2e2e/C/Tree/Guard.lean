import Mathlib
import F2e2e.C.Tree.Basic

/-!
# Part III §5.3: Lemma 5.7 (active guard enclosure) and Lemma 5.8 (root-guard floor), local forms

Source: `parts/partIII.tex` Lemma `R:lem:active-guard-enclosure` (L618–645) and Lemma
`R:lem:step3-root-guard-floor` (L647–701).

These are the tree-free (pure real) cores; the parameters are symbolic. The instantiation with the committed
parameters of `F2e2e.C.Params` is in `F2e2e/C/Tree/ParamFacts.lean`, the shadow-vector part of Lemma 5.8 (iii)
(the root guard coordinate propagates unattenuated to every `x_d`, `1 ≤ d ≤ H`) in
`F2e2e/C/Tree/Shadow.lean`.

Lemma 5.7 is used at Step 3 of every round, for every depth, with the tag-precision hypothesis
`|Ĉ_d − C_d| ≤ e_C` supplied by Lemma 6.1 (ii) at that moment (chronological induction of Theorem 6.4).
-/

namespace F2e2e.C.Tree

/-! ## Lemma 5.7 -/

/-- Lemma 5.7 (1) (eq. `R:eq:physical-tag-error-bound`, partIII.tex L621–624, L634): if
`|Ĉ − C| ≤ e_C = h/(2^10 γ V)` and the envelope satisfies `√U ≤ 4V` (in the paper
`√𝒰_{d,k} ≤ √𝒰_{d,0} < 2V_d ≤ 2V_H < V`), then the physical tag error of the nominal guard
`δ̃ = (γ/4)√U` is at most `2^{-10} h`. -/
theorem tag_error_le {h Chat C γ U V : ℝ} (hh : 0 < h) (hγ : 0 < γ) (hV : 0 < V)
    (hUV : √U ≤ 4 * V) (htag : |Chat - C| ≤ h / (2 ^ 10 * γ * V)) :
    |Chat - C| * (γ / 4 * √U) ≤ h / 2 ^ 10 := by
  have hsU : 0 ≤ √U := Real.sqrt_nonneg U
  have h1 : γ / 4 * √U ≤ γ * V := by nlinarith
  have h2 : 0 ≤ γ / 4 * √U := by positivity
  calc |Chat - C| * (γ / 4 * √U) ≤ h / (2 ^ 10 * γ * V) * (γ * V) :=
        mul_le_mul htag h1 h2 (by positivity)
    _ = h / 2 ^ 10 := by field_simp

/-- Lemma 5.7 (2), ratio form (partIII.tex L636–643): if the guard is not omitted
(`z = Ĉ δ̃ ≥ 2h`) and the physical tag error is `≤ 2^{-10} h`, then `C > 0` and the rounded guard
`δ = round_h(z)` satisfies `(4/15) δ̃ ≤ δ/C ≤ (5/4) δ̃`. -/
theorem guard_ratio_enclosure {h Chat C δt : ℝ} (hh : 0 < h) (hδt : 0 < δt)
    (hz : 2 * h ≤ Chat * δt) (htag : |Chat - C| * δt ≤ h / 2 ^ 10) :
    0 < C ∧ 4 / 15 * δt ≤ roundGrid h (Chat * δt) / C ∧
      roundGrid h (Chat * δt) / C ≤ 5 / 4 * δt := by
  set z := Chat * δt with hzdef
  have hz0 : 0 < z := by linarith
  have herr : |z - C * δt| ≤ h / 2 ^ 10 := by
    have : z - C * δt = (Chat - C) * δt := by rw [hzdef]; ring
    rw [this, abs_mul, abs_of_pos hδt]; exact htag
  rw [abs_le] at herr
  have hCd_lo : z * (1 - 1 / 2 ^ 11) ≤ C * δt := by nlinarith
  have hCd_hi : C * δt ≤ z * (1 + 1 / 2 ^ 11) := by nlinarith
  have hCpos : 0 < C * δt := by nlinarith
  have hC : 0 < C := by
    by_contra hc
    have hc' : C ≤ 0 := not_lt.mp hc
    nlinarith
  obtain ⟨hr1, hr2⟩ := roundGrid_ratio hh hz
  refine ⟨hC, ?_, ?_⟩
  · rw [le_div_iff₀ hC]
    nlinarith
  · rw [div_le_iff₀ hC]
    nlinarith

/-- Lemma 5.7 (2) (eq. `R:eq:non-omitted-guard-enclosure`, partIII.tex L625–628, L644): for the
nominal guard `δ̃ = (γ/4)√U` of epoch envelope `U > 0`, if the guard is not omitted
(`Ĉ δ̃ ≥ 2h`) and the physical tag error is `≤ 2^{-10} h`, then
`(γ/16)√U < (γ/15)√U ≤ δ/C ≤ (5/16)γ√U < γ√U`, where `δ = guardAmp h Ĉ δ̃`. -/
theorem guard_enclosure {h Chat C γ U : ℝ} (hh : 0 < h) (hγ : 0 < γ) (hU : 0 < U)
    (hz : 2 * h ≤ Chat * (γ / 4 * √U)) (htag : |Chat - C| * (γ / 4 * √U) ≤ h / 2 ^ 10) :
    0 < C ∧ γ / 16 * √U < γ / 15 * √U ∧ γ / 15 * √U ≤ guardAmp h Chat (γ / 4 * √U) / C ∧
      guardAmp h Chat (γ / 4 * √U) / C ≤ 5 / 16 * γ * √U ∧ 5 / 16 * γ * √U < γ * √U := by
  have hsU : 0 < √U := Real.sqrt_pos.2 hU
  have hδt : 0 < γ / 4 * √U := by positivity
  obtain ⟨hC, h1, h2⟩ := guard_ratio_enclosure hh hδt hz htag
  have hg : guardAmp h Chat (γ / 4 * √U) = roundGrid h (Chat * (γ / 4 * √U)) := by
    unfold guardAmp; rw [if_neg (not_lt.2 hz)]
  rw [hg]
  refine ⟨hC, ?_, ?_, ?_, ?_⟩
  · have : γ * √U / 16 < γ * √U / 15 := by
      apply div_lt_div_of_pos_left (by positivity) (by norm_num) (by norm_num)
    linarith
  · linarith
  · linarith
  · nlinarith

/-- Lemma 5.7 (2), last sentence (partIII.tex L629): on every round (omitted or not),
`(δ/C)² ≤ γ² U`. -/
theorem guardAmp_div_sq_le {h Chat C γ U : ℝ} (hh : 0 < h) (hγ : 0 < γ) (hU : 0 < U)
    (htag : |Chat - C| * (γ / 4 * √U) ≤ h / 2 ^ 10) :
    (guardAmp h Chat (γ / 4 * √U) / C) ^ 2 ≤ γ ^ 2 * U := by
  by_cases hz : Chat * (γ / 4 * √U) < 2 * h
  · unfold guardAmp; rw [if_pos hz]; simp; positivity
  · obtain ⟨hC, -, h1, h2, -⟩ := guard_enclosure hh hγ hU (not_lt.1 hz) htag
    have hsU : 0 ≤ √U := Real.sqrt_nonneg U
    have h0 : 0 ≤ guardAmp h Chat (γ / 4 * √U) / C := by
      have : 0 ≤ γ / 15 * √U := by positivity
      linarith
    calc (guardAmp h Chat (γ / 4 * √U) / C) ^ 2 ≤ (5 / 16 * γ * √U) ^ 2 :=
          pow_le_pow_left₀ h0 h2 2
      _ = 25 / 256 * γ ^ 2 * (√U) ^ 2 := by ring
      _ = 25 / 256 * γ ^ 2 * U := by rw [Real.sq_sqrt hU.le]
      _ ≤ γ ^ 2 * U := by nlinarith [sq_nonneg γ]

/-! ## Lemma 5.8, scalar parts -/

/-- Lemma 5.8 (i), envelope floor as an invariant step (partIII.tex L654–657, L684–688): the root envelope
floor `𝒰_{0,k_0} ≥ η²/64` is preserved by a root correction at which `E_0 ≥ η²/32` (from Theorem 5.9 (3),
`E_0 ≥ (η²/32)‖x_0‖²`, and `‖x_0‖ ≥ 1`) and `E_0 ≤ 𝒰_{0,k_0}` (Lemma 5.10 (b) at the root, where
`C_0 = 1`), whether or not the epoch advances (`adv = true`: `𝒰_{0,k_0+1} = 𝒰_{0,k_0}/2`). -/
theorem root_envelope_step {η U E : ℝ} (adv : Bool) (hU : η ^ 2 / 64 ≤ U) (hE : η ^ 2 / 32 ≤ E)
    (hEU : E ≤ U) : η ^ 2 / 64 ≤ (if adv then U / 2 else U) := by
  cases adv
  · simpa using hU
  · simp only [if_true]; linarith

/-- Lemma 5.8 (i), initial envelope (partIII.tex L684): `𝒰_{0,0} ≥ 2W² ≥ 8 > η²/64`. -/
theorem root_envelope_init {η U : ℝ} (hη : |η| ≤ 1) (hU : 8 ≤ U) : η ^ 2 / 64 ≤ U := by
  have : η ^ 2 ≤ 1 := by
    rw [sq_le_one_iff_abs_le_one]; exact hη
  linarith

/-- Lemma 5.8 (ii), local form (eqs. `R:eq:root-nominal-guard-lower`, `R:eq:root-guard-delta-lower`,
partIII.tex L658–666, L690–698): at the root (`Ĉ_0 = C_0 = 1`), if the envelope satisfies
`U ≥ η²/512` and the guard grid satisfies `2h ≤ γη/(64√2)` (in the paper
`γη/(64√2) > 2^{H+33} h_{g,unrefined} = 2^{H+33} B^{2H} h_g ≫ 2h_g`), then the root guard is not
omitted and `δ_{g(0,t)} ≥ (γ/15)√U ≥ γη/(240√2)`. -/
theorem root_guard_lower {h γ η U : ℝ} (hh : 0 < h) (hγ : 0 < γ) (hη : 0 < η)
    (hU : η ^ 2 / 512 ≤ U) (hgrid : 2 * h ≤ γ * η / (64 * √2)) :
    2 * h ≤ 1 * (γ / 4 * √U) ∧ γ / 15 * √U ≤ guardAmp h 1 (γ / 4 * √U) ∧
      γ * η / (240 * √2) ≤ γ / 15 * √U := by
  have hs2 : 0 < √2 := by positivity
  have hs2sq : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hU0 : 0 < U := lt_of_lt_of_le (by positivity) hU
  have hlow : η / (16 * √2) ≤ √U := by
    have e : (η / (16 * √2)) ^ 2 = η ^ 2 / 512 := by
      rw [div_pow, mul_pow, hs2sq]; norm_num
    have : √((η / (16 * √2)) ^ 2) ≤ √U := Real.sqrt_le_sqrt (by rw [e]; exact hU)
    rwa [Real.sqrt_sq (by positivity)] at this
  have hz : 2 * h ≤ 1 * (γ / 4 * √U) := by
    have : γ * η / (64 * √2) = γ / 4 * (η / (16 * √2)) := by field_simp; ring
    rw [one_mul]
    calc 2 * h ≤ γ * η / (64 * √2) := hgrid
      _ = γ / 4 * (η / (16 * √2)) := this
      _ ≤ γ / 4 * √U := by gcongr
  have htag : |(1 : ℝ) - 1| * (γ / 4 * √U) ≤ h / 2 ^ 10 := by simp; positivity
  obtain ⟨-, -, h1, -, -⟩ := guard_enclosure hh hγ hU0 hz htag
  refine ⟨hz, by simpa using h1, ?_⟩
  have : γ * η / (240 * √2) = γ / 15 * (η / (16 * √2)) := by field_simp; ring
  rw [this]
  gcongr

/-- Lemma 5.8 (ii), the margin over `ν` (eq. `R:eq:root-guard-delta-lower`, partIII.tex L664, L696–698;
`2^{H+11.5}` written as `2^{H+11} √2`): if `γη = 2^{H+20} ν` then
`γη/(240√2) > 2^{H+11}√2 ν ≥ 2^{12} √2 ν > ν` (for `ν > 0`). -/
theorem root_guard_margin {γ η ν : ℝ} (H : ℕ) (hν : 0 < ν) (hγη : γ * η = 2 ^ (H + 20) * ν) :
    2 ^ (H + 11) * √2 * ν < γ * η / (240 * √2) ∧ ν < 2 ^ (H + 11) * √2 * ν := by
  have hs2 : 0 < √2 := by positivity
  have hs2sq : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
  have h2 : (2 : ℝ) ^ (H + 20) = 2 ^ (H + 11) * 512 := by
    rw [show H + 20 = (H + 11) + 9 by ring, pow_add]; norm_num
  have hp : (0 : ℝ) < 2 ^ (H + 11) := by positivity
  constructor
  · rw [hγη, lt_div_iff₀ (by positivity), h2]
    have : 2 ^ (H + 11) * √2 * ν * (240 * √2) = 2 ^ (H + 11) * ν * 480 := by
      calc 2 ^ (H + 11) * √2 * ν * (240 * √2) = 2 ^ (H + 11) * ν * 240 * (√2 * √2) := by ring
        _ = 2 ^ (H + 11) * ν * 480 := by rw [hs2sq]; ring
    rw [this]
    nlinarith
  · have h1 : (1 : ℝ) ≤ √2 := by
      rw [show (1 : ℝ) = √1 by simp]; exact Real.sqrt_le_sqrt (by norm_num)
    have h3 : (2 : ℝ) ≤ 2 ^ (H + 11) := by
      calc (2 : ℝ) = 2 ^ 1 := by norm_num
        _ ≤ 2 ^ (H + 11) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h4 : (2 : ℝ) ≤ 2 ^ (H + 11) * √2 := by nlinarith
    have h5 : 2 * ν ≤ 2 ^ (H + 11) * √2 * ν := by nlinarith
    linarith

end F2e2e.C.Tree
