import Mathlib

/-!
# Part III §5.5: Theorem 5.11 (first-correction guard, all-interval product bound `B`, lifetime cap `J_*`),
local forms

Source: `parts/partIII.tex` Theorem `R:thm:L4_First_Correction_Guard_And_Precision` (L896–988).

Tree-free statements (parameters symbolic; instantiation in `F2e2e/C/Tree/ParamFacts.lean`, tree-level use in
`F2e2e/C/Tree/Shadow.lean` and the chronological induction of Theorem 6.4):
* (1) `first_correction_nonomission` (eqs. `R:eq:sec5-scale-cancellation`, `R:eq:first-correction-non-omission`),
  `CoordOp`/`coord_track` (the guard coordinate `r_{d,g_*}/C_d` is multiplied only by local multipliers),
  `localProd_append_of_noLoc` (eq. `R:eq:Pint-tstar-reduction`), `product_trap`
  (eqs. `R:eq:Pint-energy-trap`, `R:eq:Pint-less-than-B`);
* (2a) `compound_product_le`, `pow_le_G` (eqs. `R:eq:compound-product-G`, `R:eq:Cd-upper-bound`);
* (2b) `vector_bounds`, `augmented_le` (eq. `R:eq:xd-Vd-bound` and the augmented family bound);
* (2c) `epoch_floor` (eq. `R:eq:epoch-halving-termination`), `lifetime_cap` (eq. `R:eq:Jstar-lifetime-cap`),
  `bank_caps` (`J ≤ 2J_* = J_max`, `R ≤ 4J_* + 2 = R_max`).
-/

namespace F2e2e.C.Tree

/-! ## (1) First-correction scale cancellation and the all-interval product bound -/

/-- Theorem 5.11 (1), scale cancellation and non-omission at the first correction `t_*` of an interval
(eqs. `R:eq:sec5-scale-cancellation`, `R:eq:first-correction-non-omission`; partIII.tex L907–914, L957–961).
At the Step-4 rejection of round `t_*`: `E = E_d(t_*) ≥ E_min = η²ν²/256` (Theorem 5.9 (3)) and
`Ẽ_d(t_*) = E/C² < 𝒰` (Lemma 5.10 (b)), where `C = C_d(t_*) > 0`, `Ĉ = Ĉ_d(t_*)` and `𝒰 = 𝒰_{d,k(t_*)}` are the
same as at Step 3 of round `t_*` (strict ancestors evaluate later). With
`h_{g,unrefined} = γην/2^20 = B^{2H} h_g` (`B ≥ 1`) and the physical tag error `≤ 2^{-10} h_g`
(Lemma 5.7 (1)): `C√𝒰 > √E ≥ ην/16`, `Cδ̃ > (γ/64)ην = 2^14 B^{2H} h_g` and
`Ĉδ̃ > 2^14 B^{2H} h_g − 2^{-10} h_g ≥ 2h_g` (`δ̃ = (γ/4)√𝒰`): the guard of `t_*` was not omitted. (The paper's
intermediate `> 2^14 h_g` needs `B^{2H} > 1 + 2^{-24}`, true for the committed `B ≥ 2^15`; it is not needed.) -/
theorem first_correction_nonomission {γ η ν hg B C Chat U E : ℝ} {H : ℕ} (hγ : 0 < γ) (hη : 0 < η)
    (hν : 0 < ν) (hhg : 0 < hg) (hB : 1 ≤ B) (hgrid : γ * η * ν / 2 ^ 20 = B ^ (2 * H) * hg)
    (hC : 0 < C) (hE : η ^ 2 * ν ^ 2 / 256 ≤ E) (hEt : E / C ^ 2 < U)
    (htag : |Chat - C| * (γ / 4 * √U) ≤ hg / 2 ^ 10) :
    η * ν / 16 < C * √U ∧ 2 ^ 14 * B ^ (2 * H) * hg < C * (γ / 4 * √U) ∧
      2 ^ 14 * B ^ (2 * H) * hg - hg / 2 ^ 10 < Chat * (γ / 4 * √U) ∧
      2 * hg ≤ Chat * (γ / 4 * √U) := by
  have hE0 : 0 ≤ E := le_trans (by positivity) hE
  have hC2 : 0 < C ^ 2 := by positivity
  have hEU : E < U * C ^ 2 := by rwa [div_lt_iff₀ hC2] at hEt
  have hU0 : 0 < U := by
    by_contra hU
    have : U ≤ 0 := not_lt.mp hU
    nlinarith
  have hsE : η * ν / 16 ≤ √E := by
    have h1 : (η * ν / 16) ^ 2 ≤ E := by nlinarith
    have := Real.sqrt_le_sqrt h1
    rwa [Real.sqrt_sq (by positivity)] at this
  have hsEU : √E < C * √U := by
    have h1 : √E < √(U * C ^ 2) := Real.sqrt_lt_sqrt hE0 hEU
    rwa [Real.sqrt_mul hU0.le, Real.sqrt_sq hC.le, mul_comm] at h1
  have h1 : η * ν / 16 < C * √U := lt_of_le_of_lt hsE hsEU
  have h2 : 2 ^ 14 * B ^ (2 * H) * hg < C * (γ / 4 * √U) := by
    have e : 2 ^ 14 * B ^ (2 * H) * hg = γ / 4 * (η * ν / 16) := by
      rw [mul_assoc, ← hgrid]; ring
    rw [e, show C * (γ / 4 * √U) = γ / 4 * (C * √U) by ring]
    exact mul_lt_mul_of_pos_left h1 (by positivity)
  have hsU : 0 ≤ γ / 4 * √U := by positivity
  have h3 : C * (γ / 4 * √U) - hg / 2 ^ 10 ≤ Chat * (γ / 4 * √U) := by
    have : -(|Chat - C| * (γ / 4 * √U)) ≤ (Chat - C) * (γ / 4 * √U) := by
      have := neg_abs_le (Chat - C)
      nlinarith
    nlinarith
  have hBH : 1 ≤ B ^ (2 * H) := one_le_pow₀ hB
  refine ⟨h1, h2, by linarith, ?_⟩
  have : 2 * hg ≤ 2 ^ 14 * B ^ (2 * H) * hg - hg / 2 ^ 10 := by nlinarith
  linarith

/-- The operations acting on the pair `(ρ, C)` = (the guard coordinate `r_{d,g_*}` of the residual, the exact
tag `C_d`) after the injection of the guard `g_* = g(d,t_*)` (Lemma 5.6 (2), eq.
`R:eq:guard-residual-evolution`; Lemma 5.4 (iii)(b)): a local correction multiplies `ρ` by `1 + a`, a
strict-ancestor rescaling multiplies both by `c`, all other events (physical updates, other guards, accepts)
leave both unchanged. -/
inductive CoordOp
  /-- a local correction of depth `d` with step `a` -/
  | loc (a : ℝ)
  /-- a strict-ancestor rescaling by `c` -/
  | anc (c : ℝ)
  /-- any other event -/
  | other

/-- The action of a `CoordOp` on `(ρ, C)`. -/
def CoordOp.act : CoordOp → ℝ × ℝ → ℝ × ℝ
  | .loc a, p => ((1 + a) * p.1, p.2)
  | .anc c, p => (c * p.1, c * p.2)
  | .other, p => p

/-- Run a list of `CoordOp`s (first element first). -/
def CoordOp.run (l : List CoordOp) (p : ℝ × ℝ) : ℝ × ℝ := l.foldl (fun q o => o.act q) p

/-- The local interval product `∏ (1 + a)` over the local corrections of an event list (eq.
`R:eq:Pint-definition`). -/
def localProd : List CoordOp → ℝ
  | [] => 1
  | .loc a :: l => (1 + a) * localProd l
  | .anc _ :: l => localProd l
  | .other :: l => localProd l

/-- Coordinate tracking (partIII.tex L965–968): `ρ_end/C_end = (ρ_0/C_0) ∏_{local}(1 + a)`, provided every
strict-ancestor multiplier is nonzero (indeed `c ∈ [1/2, 3/2]`). -/
theorem coord_track (l : List CoordOp) (p : ℝ × ℝ) (hanc : ∀ c, CoordOp.anc c ∈ l → c ≠ 0) :
    (CoordOp.run l p).1 / (CoordOp.run l p).2 = p.1 / p.2 * localProd l := by
  induction l generalizing p with
  | nil => simp [CoordOp.run, localProd]
  | cons o l ih =>
    have hrun : CoordOp.run (o :: l) p = CoordOp.run l (o.act p) := rfl
    rw [hrun, ih (o.act p) (fun c hc => hanc c (List.mem_cons_of_mem _ hc))]
    cases o with
    | loc a => simp only [CoordOp.act, localProd]; ring
    | anc c =>
      have hc : c ≠ 0 := hanc c (by simp)
      simp only [CoordOp.act, localProd]
      rw [mul_div_mul_left _ _ hc]
    | other => simp only [CoordOp.act, localProd]

/-- Eq. `R:eq:Pint-tstar-reduction` (partIII.tex L903–906, L955): the events before the first local correction
`t_*` of `[t_1, t_2]` contribute no factor, `P_int[t_1, t_2] = P_int[t_*, t_2]`. -/
theorem localProd_append_of_noLoc (l₁ l₂ : List CoordOp) (h : ∀ a, CoordOp.loc a ∉ l₁) :
    localProd (l₁ ++ l₂) = localProd l₂ := by
  induction l₁ with
  | nil => simp
  | cons o l ih =>
    have h' : ∀ a, CoordOp.loc a ∉ l := fun a ha => h a (List.mem_cons_of_mem _ ha)
    cases o with
    | loc a => exact absurd (by simp) (h a)
    | anc c => simp only [List.cons_append, localProd]; exact ih h'
    | other => simp only [List.cons_append, localProd]; exact ih h'

/-- Theorem 5.11 (1), the energy trap (eqs. `R:eq:Pint-energy-trap`, `R:eq:Pint-less-than-B`; partIII.tex
L915–922, L962–973). The normalized guard coordinate `ρ = r_{d,g_*}/C_d` has `ρ_0 = δ(t_*)/C(t_*) ≥
(γ/15)√𝒰_*` at the Step-3 injection of round `t_*` (Lemma 5.7 (2); `𝒰_* = 𝒰_{d,k(t_*)} > 0`), equals
`ρ_0 · P_int[t_*, t_2]` in absolute value at the end of round `t_2` (`coord_track`), and is bounded by the
normalized energy: `ρ² ≤ Ẽ_d(t_2) ≤ (33/64)𝒰_{d,k(t_2)} ≤ (33/64)𝒰_*` (Lemma 5.10 (b), envelopes
non-increasing). Hence `P_int ≤ 15√(33/64)/γ = 15√33/(8γ) < 10.78/γ < 16/γ = B`. -/
theorem product_trap {γ Us ρ0 ρ2 Pint : ℝ} (hγ : 0 < γ) (hUs : 0 < Us) (hP : 0 ≤ Pint)
    (h0 : γ / 15 * √Us ≤ ρ0) (h2 : |ρ2| = ρ0 * Pint) (hE : ρ2 ^ 2 ≤ 33 / 64 * Us) :
    Pint ≤ 15 * √33 / (8 * γ) ∧ 15 * √33 / (8 * γ) < 10.78 / γ ∧ 10.78 / γ < 16 / γ := by
  have hsU : 0 < √Us := Real.sqrt_pos.2 hUs
  have hsUsq : √Us ^ 2 = Us := Real.sq_sqrt hUs.le
  have h33 : √33 ^ 2 = 33 := Real.sq_sqrt (by norm_num)
  have hs33 : 0 < √33 := by positivity
  have hA : γ / 15 * √Us * Pint ≤ ρ0 * Pint := mul_le_mul_of_nonneg_right h0 hP
  have hA0 : 0 ≤ γ / 15 * √Us * Pint := by positivity
  have hB : (ρ0 * Pint) ^ 2 = ρ2 ^ 2 := by rw [← h2, sq_abs]
  have hC : (γ / 15 * √Us * Pint) ^ 2 ≤ 33 / 64 * Us :=
    calc (γ / 15 * √Us * Pint) ^ 2 ≤ (ρ0 * Pint) ^ 2 := pow_le_pow_left₀ hA0 hA 2
      _ = ρ2 ^ 2 := hB
      _ ≤ 33 / 64 * Us := hE
  have e1 : (γ / 15 * √Us * Pint) ^ 2 = (γ * Pint) ^ 2 * Us / 225 := by
    rw [show (γ / 15 * √Us * Pint) ^ 2 = (γ * Pint) ^ 2 * √Us ^ 2 / 225 by ring, hsUsq]
  have hD : (γ * Pint) ^ 2 ≤ (15 * √33 / 8) ^ 2 := by
    have e2 : (15 * √33 / 8) ^ 2 = 225 * 33 / 64 := by
      rw [show (15 * √33 / 8) ^ 2 = 225 * √33 ^ 2 / 64 by ring, h33]
    rw [e2]
    rw [e1] at hC
    have h4 : (γ * Pint) ^ 2 * Us ≤ 225 * 33 / 64 * Us := by linarith
    exact le_of_mul_le_mul_right h4 hUs
  have hE' : γ * Pint ≤ 15 * √33 / 8 :=
    (pow_le_pow_iff_left₀ (by positivity) (by positivity) two_ne_zero).1 hD
  have h1 : √33 < 5.7493 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  refine ⟨?_, ?_, ?_⟩
  · rw [le_div_iff₀ (by positivity)]; linarith
  · rw [div_lt_div_iff₀ (by positivity) hγ]; nlinarith
  · exact (div_lt_div_iff_of_pos_right hγ).2 (by norm_num)

/-! ## (2a) Compound products -/

/-- Theorem 5.11 (2a) (eqs. `R:eq:compound-product-factorization`, `R:eq:compound-product-G`,
`R:eq:Cd-upper-bound`; partIII.tex L925–932, L975–979): a forward interval product of elementary multipliers,
grouped by the generating depth `d' ∈ s` (at most `k` depths: `k = d` for primary arrays and tags of depth
`d`, `k = d + 1` for secondary arrays), is a product of single-learner interval products, each in `[0, B]`;
hence it is at most `B^k`. -/
theorem compound_product_le {ι : Type*} (s : Finset ι) (f : ι → ℝ) {B : ℝ} (hB : 1 ≤ B)
    (hf : ∀ i ∈ s, 0 ≤ f i ∧ f i ≤ B) {k : ℕ} (hs : s.card ≤ k) : ∏ i ∈ s, f i ≤ B ^ k := by
  calc ∏ i ∈ s, f i ≤ ∏ _i ∈ s, B :=
        Finset.prod_le_prod (fun i hi => (hf i hi).1) (fun i hi => (hf i hi).2)
    _ = B ^ s.card := Finset.prod_const B
    _ ≤ B ^ k := pow_le_pow_right₀ hB hs

/-- Theorem 5.11 (2a) (eq. `R:eq:compound-product-G`): `B^d ≤ B^{d+1} ≤ B^{H+1} < B^{H+2} = G` for `d ≤ H`,
`B > 1`. -/
theorem pow_le_G {B : ℝ} (hB : 1 < B) {d H : ℕ} (hd : d ≤ H) :
    B ^ d ≤ B ^ (d + 1) ∧ B ^ (d + 1) ≤ B ^ (H + 1) ∧ B ^ (H + 1) < B ^ (H + 2) :=
  ⟨pow_le_pow_right₀ hB.le (by omega), pow_le_pow_right₀ hB.le (by omega),
    pow_lt_pow_right₀ hB (by omega)⟩

/-! ## (2b) Vector bounds -/

/-- Theorem 5.11 (2b) (eqs. `R:eq:xd-Vd-bound`, `R:eq:sec5-Vd-inductive-step`; partIII.tex L933–939,
L981–985), induction on the depth: if `‖x_0‖ ≤ V_0`, `x_{d+1} = y_d = x_d − r_d`, `0 < C_d ≤ B^d`,
`Ẽ_d = ‖r_d‖²/C_d² ≤ 𝒰_{d,0}` (Lemma 5.10 (b) and `𝒰_{d,k} ≤ 𝒰_{d,0}`), `√𝒰_{d,0} ≤ 2V_d` and
`V_{d+1} = (1 + 2B^d)V_d`, then `‖x_d‖ ≤ V_d` (`d ≤ H`) and `‖r_d‖ ≤ 2B^dV_d` (`d < H`). -/
theorem vector_bounds {E : Type*} [NormedAddCommGroup E] {H : ℕ} (x r : ℕ → E) (C Vd U0 : ℕ → ℝ)
    {B : ℝ} (h0 : ‖x 0‖ ≤ Vd 0) (hx : ∀ d < H, x (d + 1) = x d - r d)
    (hC : ∀ d < H, 0 < C d ∧ C d ≤ B ^ d) (hEt : ∀ d < H, ‖r d‖ ^ 2 / C d ^ 2 ≤ U0 d)
    (hU : ∀ d < H, √(U0 d) ≤ 2 * Vd d) (hV : ∀ d < H, Vd (d + 1) = (1 + 2 * B ^ d) * Vd d) :
    (∀ d ≤ H, ‖x d‖ ≤ Vd d) ∧ (∀ d < H, ‖r d‖ ≤ 2 * B ^ d * Vd d) := by
  have hr : ∀ d < H, ‖r d‖ ≤ 2 * B ^ d * Vd d := by
    intro d hd
    obtain ⟨hC0, hCB⟩ := hC d hd
    have hC2 : 0 < C d ^ 2 := by positivity
    have h1 : ‖r d‖ ^ 2 ≤ U0 d * C d ^ 2 := by
      have := hEt d hd; rwa [div_le_iff₀ hC2] at this
    have hU0 : 0 ≤ U0 d := le_trans (div_nonneg (sq_nonneg _) (sq_nonneg _)) (hEt d hd)
    have h2 : ‖r d‖ ≤ √(U0 d) * C d := by
      have := Real.sqrt_le_sqrt h1
      rwa [Real.sqrt_sq (norm_nonneg _), Real.sqrt_mul hU0, Real.sqrt_sq hC0.le] at this
    have hsU := Real.sqrt_nonneg (U0 d)
    have hVd : 0 ≤ Vd d := by have := hU d hd; linarith
    calc ‖r d‖ ≤ √(U0 d) * C d := h2
      _ ≤ (2 * Vd d) * B ^ d := mul_le_mul (hU d hd) hCB hC0.le (by positivity)
      _ = 2 * B ^ d * Vd d := by ring
  refine ⟨?_, hr⟩
  intro d hd
  induction d with
  | zero => exact h0
  | succ d ih =>
    have hdH : d < H := by omega
    rw [hx d hdH, hV d hdH]
    calc ‖x d - r d‖ ≤ ‖x d‖ + ‖r d‖ := norm_sub_le _ _
      _ ≤ Vd d + 2 * B ^ d * Vd d := add_le_add (ih (by omega)) (hr d hdH)
      _ = (1 + 2 * B ^ d) * Vd d := by ring

/-- Theorem 5.11 (2b), augmented family (partIII.tex L940, L985; Lemma 6.1 (iii) L1081): every
`w ∈ {x_H} ∪ ⋃_{d<H}{x_d, y_d, y_d⁺, r_d, r_d⁺}` has `‖w‖ ≤ 6B^HV_H`, hence the augmented vector
`w⁺ = (w, σ)` satisfies `‖w⁺‖ = √(‖w‖² + σ²) ≤ ‖w‖ + σ ≤ 8B^{H+1}V_H + 2 = V` (for `B ≥ 1`, `0 ≤ σ ≤ 2`). -/
theorem augmented_le {w B VH σ : ℝ} {H : ℕ} (hB : 1 ≤ B) (hVH : 0 ≤ VH) (hσ : 0 ≤ σ) (hσ2 : σ ≤ 2)
    (hw : 0 ≤ w) (hwle : w ≤ 6 * B ^ H * VH) :
    √(w ^ 2 + σ ^ 2) ≤ w + σ ∧ w + σ ≤ 8 * B ^ (H + 1) * VH + 2 := by
  constructor
  · have h1 : w ^ 2 + σ ^ 2 ≤ (w + σ) ^ 2 := by nlinarith
    have := Real.sqrt_le_sqrt h1
    rwa [Real.sqrt_sq (by positivity)] at this
  · have hBH : B ^ H ≤ B ^ (H + 1) := pow_le_pow_right₀ hB (by omega)
    have hB0 : 0 ≤ B ^ H := le_trans zero_le_one (one_le_pow₀ hB)
    have : 6 * B ^ H * VH ≤ 8 * B ^ (H + 1) * VH := by nlinarith
    linarith

/-- Theorem 5.11 (2b): the family members are bounded by `6B^HV_H` (partIII.tex L985; Lemma 6.1 (iii) L1081),
from `‖x_d‖ ≤ V_d ≤ V_H`, `‖r_d‖ ≤ 2B^dV_d`, `y_d = x_d − r_d`, `y_d⁺ = c y_d` with `|c| ≤ 3/2`,
`r_d⁺ = x_d − y_d⁺`. -/
theorem family_le {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] {x r : E} {c B Vdd VH : ℝ}
    {d H : ℕ} (hdH : d ≤ H) (hB : 1 ≤ B) (hV : 0 ≤ Vdd) (hVH : Vdd ≤ VH) (hx : ‖x‖ ≤ Vdd)
    (hr : ‖r‖ ≤ 2 * B ^ d * Vdd) (hc : |c| ≤ 3 / 2) :
    ‖x‖ ≤ 6 * B ^ H * VH ∧ ‖r‖ ≤ 6 * B ^ H * VH ∧ ‖x - r‖ ≤ 6 * B ^ H * VH ∧
      ‖c • (x - r)‖ ≤ 6 * B ^ H * VH ∧ ‖x - c • (x - r)‖ ≤ 6 * B ^ H * VH := by
  have hBd : B ^ d ≤ B ^ H := pow_le_pow_right₀ hB hdH
  have hBH : 1 ≤ B ^ H := one_le_pow₀ hB
  have hBd0 : 0 ≤ B ^ d := le_trans zero_le_one (one_le_pow₀ hB)
  have hVH0 : 0 ≤ VH := le_trans hV hVH
  have h1 : ‖x‖ ≤ VH := le_trans hx hVH
  have h2 : ‖r‖ ≤ 2 * B ^ H * VH := by
    have : B ^ d * Vdd ≤ B ^ H * VH := mul_le_mul hBd hVH hV (le_trans zero_le_one hBH)
    linarith
  have h3 : ‖x - r‖ ≤ 3 * B ^ H * VH := by
    calc ‖x - r‖ ≤ ‖x‖ + ‖r‖ := norm_sub_le _ _
      _ ≤ VH + 2 * B ^ H * VH := add_le_add h1 h2
      _ ≤ 3 * B ^ H * VH := by nlinarith [mul_nonneg (sub_nonneg.2 hBH) hVH0]
  have h4 : ‖c • (x - r)‖ ≤ 9 / 2 * B ^ H * VH := by
    rw [norm_smul, Real.norm_eq_abs]
    calc |c| * ‖x - r‖ ≤ 3 / 2 * (3 * B ^ H * VH) := mul_le_mul hc h3 (norm_nonneg _) (by norm_num)
      _ = 9 / 2 * B ^ H * VH := by ring
  have h5 : ‖x - c • (x - r)‖ ≤ 11 / 2 * B ^ H * VH := by
    calc ‖x - c • (x - r)‖ ≤ ‖x‖ + ‖c • (x - r)‖ := norm_sub_le _ _
      _ ≤ VH + 9 / 2 * B ^ H * VH := add_le_add h1 h4
      _ ≤ 11 / 2 * B ^ H * VH := by nlinarith [mul_nonneg (sub_nonneg.2 hBH) hVH0]
  have hpos : 0 ≤ B ^ H * VH := mul_nonneg (le_trans zero_le_one hBH) hVH0
  have hVHle : VH ≤ B ^ H * VH := by nlinarith [mul_nonneg (sub_nonneg.2 hBH) hVH0]
  refine ⟨by linarith, by linarith, by linarith, by linarith, by linarith⟩

/-! ## (2c) Epoch cap and lifetime cap -/

/-- Theorem 5.11 (2c) (eq. `R:eq:epoch-halving-termination`; partIII.tex L941–944, L987): at a rejection,
`E_d ≥ E_min = η²ν²/256` (Theorem 5.9 (3)), `0 < C_d ≤ B^H` ((2a)) and
`E_d/C_d² < 𝒰_{d,k} = 2^{-k}𝒰_{d,0} ≤ 2^{-k}𝒰_*` (Lemma 5.10 (b)); hence `2^{-k}𝒰_* > η²ν²/(256B^{2H})`.
(With the committed powers of two this gives `k ≤ K_epoch − 13`, `ParamFacts.epoch_lt`.) -/
theorem epoch_floor {η ν B C E Us : ℝ} {H k : ℕ} (hB : 1 ≤ B) (hC0 : 0 < C) (hC : C ≤ B ^ H)
    (hE : η ^ 2 * ν ^ 2 / 256 ≤ E) (hEt : E / C ^ 2 < Us / 2 ^ k) :
    η ^ 2 * ν ^ 2 / (256 * B ^ (2 * H)) < Us / 2 ^ k := by
  have hB0 : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hBpos : 0 < B ^ (2 * H) := pow_pos hB0 _
  have hC2 : C ^ 2 ≤ B ^ (2 * H) :=
    calc C ^ 2 ≤ (B ^ H) ^ 2 := pow_le_pow_left₀ hC0.le hC 2
      _ = B ^ (2 * H) := by rw [← pow_mul, mul_comm]
  have hE0 : 0 ≤ E := le_trans (by positivity) hE
  have h1 : η ^ 2 * ν ^ 2 / (256 * B ^ (2 * H)) ≤ E / B ^ (2 * H) := by
    rw [show η ^ 2 * ν ^ 2 / (256 * B ^ (2 * H)) = (η ^ 2 * ν ^ 2 / 256) / B ^ (2 * H) by
      field_simp]
    exact div_le_div_of_nonneg_right hE hBpos.le
  have h2 : E / B ^ (2 * H) ≤ E / C ^ 2 := div_le_div_of_nonneg_left hE0 (by positivity) hC2
  linarith

/-- Theorem 5.11 (2c), lifetime cap (eq. `R:eq:Jstar-lifetime-cap`; partIII.tex L945–949, L987): with the
local counters `J_used = K₀k + j_epoch`, `j_epoch < K₀` (Algorithm `R:alg:within-round-tree` L509) and
`k + 13 ≤ K_epoch` at a rejection, the client cap `J_used < J_* = K₀(K_epoch + 1)` and the epoch cap
`k + 1 ≤ K_epoch` hold before the correction, and `J_used + 1 ≤ J_*` after it. -/
theorem lifetime_cap {K0 Kepoch k j J : ℕ} (hJ : J = K0 * k + j) (hj : j < K0) (hk : k + 13 ≤ Kepoch) :
    J < K0 * (Kepoch + 1) ∧ k + 1 ≤ Kepoch ∧ J + 1 ≤ K0 * (Kepoch + 1) := by
  subst hJ
  have h1 : K0 * (k + 1) ≤ K0 * (Kepoch + 1) := Nat.mul_le_mul_left _ (by omega)
  have h2 : K0 * (k + 1) = K0 * k + K0 := by ring
  refine ⟨by omega, by omega, by omega⟩

/-- Theorem 5.11 (2c), bank caps (partIII.tex L949; Theorem 6.4 L1303–1306): a bank serving at most two
sequential client lifetimes with `J₁, J₂ ≤ J_*` local rejections, each client with one initialization and two
numerical requests per rejection, has `J₁ + J₂ ≤ 2J_* = J_max` rejections and
`(2J₁ + 1) + (2J₂ + 1) ≤ 4J_* + 2 = R_max` numerical requests. -/
theorem bank_caps {Jstar J1 J2 : ℕ} (h1 : J1 ≤ Jstar) (h2 : J2 ≤ Jstar) :
    J1 + J2 ≤ 2 * Jstar ∧ (2 * J1 + 1) + (2 * J2 + 1) ≤ 4 * Jstar + 2 := by
  omega

end F2e2e.C.Tree
