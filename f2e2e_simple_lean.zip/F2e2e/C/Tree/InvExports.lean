import Mathlib
import F2e2e.C.Tree.InvDefs

/-!
# Part III §5: the facts exported by the tree invariant

Source: `parts/partIII.tex` Section 5 (L407–989). From `TreeInv` (`F2e2e/C/Tree/InvDefs.lean`) at any moment:
the all-interval product bound and `C_d ≤ B^d` (Theorem 5.11 (1), (2a)), the vector bounds (Theorem 5.11 (2b),
Lemma 6.1 (iii); the premise `‖v⁺‖ ≤ V` of Theorem 4.9), and during Step 4: the terminal accumulator
(Lemma 5.3), the norm floor (Lemma 5.8) and the returned accuracy (Theorem 5.9 (2)).
-/

namespace F2e2e.C.Tree

open F2e2e

/-! ## Coordinates, unit vectors and guard indices -/

section Coord

variable {N : ℕ}

/-- A coordinate is the inner product with the unit vector. -/
theorem coordAt_eq_inner {v : VecN N} {j : ℕ} (hj : j < N) :
    coordAt v j = inner ℝ v (unitAt N j) := by
  unfold coordAt unitAt
  rw [dif_pos hj, dif_pos hj, EuclideanSpace.inner_single_right]
  simp

theorem coordAt_add (u v : VecN N) (j : ℕ) : coordAt (u + v) j = coordAt u j + coordAt v j := by
  by_cases hj : j < N
  · simp only [coordAt_eq_inner hj, inner_add_left]
  · simp [coordAt, hj]

theorem coordAt_sub (u v : VecN N) (j : ℕ) : coordAt (u - v) j = coordAt u j - coordAt v j := by
  by_cases hj : j < N
  · simp only [coordAt_eq_inner hj, inner_sub_left]
  · simp [coordAt, hj]

theorem coordAt_smul (a : ℝ) (v : VecN N) (j : ℕ) : coordAt (a • v) j = a * coordAt v j := by
  by_cases hj : j < N
  · simp only [coordAt_eq_inner hj, real_inner_smul_left]
  · simp [coordAt, hj]

theorem coordAt_sum {ι : Type*} (s : Finset ι) (f : ι → VecN N) (j : ℕ) :
    coordAt (∑ i ∈ s, f i) j = ∑ i ∈ s, coordAt (f i) j := by
  by_cases hj : j < N
  · simp only [coordAt_eq_inner hj, sum_inner]
  · simp [coordAt, hj]

theorem coordAt_unitAt_ne {i j : ℕ} (hij : i ≠ j) : coordAt (unitAt N i) j = 0 := by
  unfold coordAt unitAt
  split_ifs with hj hi
  · simp [Fin.ext_iff, Ne.symm hij]
  · simp
  · rfl

theorem norm_unitAt {j : ℕ} (hj : j < N) : ‖unitAt N j‖ = 1 := by
  unfold unitAt
  rw [dif_pos hj]
  simp

end Coord

/-- Guard indices are not physical indices: `n ≤ g(d,t) − 1`. -/
theorem guardIdx_ge (P : StreamParams) (d t : ℕ) : P.n ≤ guardIdx P d t := by
  have := P.guardCoord_ge d t
  unfold guardIdx
  omega

/-- Guard indices of the rounds `1..m` and depths `< H` are in range. -/
theorem guardIdx_lt (P : StreamParams) {d t : ℕ} (hd : d < P.H) (ht : 1 ≤ t) (htm : t ≤ P.m) :
    guardIdx P d t < P.Dstar := by
  obtain ⟨h1, h2, h3, h4⟩ := guardCoord_range P hd ht htm
  unfold guardIdx
  omega

/-- The guard indices of one round are distinct for distinct depths `< H`. -/
theorem guardIdx_inj (P : StreamParams) {d d' t : ℕ} (hd : d < P.H) (hd' : d' < P.H) (ht : 1 ≤ t)
    (h : guardIdx P d t = guardIdx P d' t) : d = d' := by
  have h1 := P.guardCoord_ge d t
  have h2 := P.guardCoord_ge d' t
  unfold guardIdx at h
  exact (guardCoord_injective P hd hd' ht ht (by omega)).1

/-- Pythagoras for the terminal input: a vector supported on the physical indices plus guards on distinct
guard coordinates of one round. -/
theorem norm_sq_add_guards (P : StreamParams) {t : ℕ} (ht : 1 ≤ t) (htm : t ≤ P.m) (u : Vec P)
    (hu : ∀ j, P.n ≤ j → coordAt u j = 0) (a : ℕ → ℝ) {D : ℕ} (hD : D ≤ P.H) :
    ‖u + ∑ d ∈ Finset.range D, a d • unitAt P.Dstar (guardIdx P d t)‖ ^ 2 =
      ‖u‖ ^ 2 + ∑ d ∈ Finset.range D, a d ^ 2 := by
  induction D with
  | zero => simp
  | succ D ih =>
    have hDH : D < P.H := by omega
    have hgD := guardIdx_lt P hDH ht htm
    have hinner : inner ℝ (u + ∑ d ∈ Finset.range D, a d • unitAt P.Dstar (guardIdx P d t))
        (a D • unitAt P.Dstar (guardIdx P D t)) = 0 := by
      rw [real_inner_smul_right, ← coordAt_eq_inner hgD, coordAt_add, coordAt_sum,
        hu _ (guardIdx_ge P D t)]
      have hz : ∀ d ∈ Finset.range D,
          coordAt (a d • unitAt P.Dstar (guardIdx P d t)) (guardIdx P D t) = 0 := by
        intro d hd
        have hdD : d < D := Finset.mem_range.mp hd
        rw [coordAt_smul, coordAt_unitAt_ne, mul_zero]
        intro heq
        have := guardIdx_inj P (by omega) hDH ht heq
        omega
      rw [Finset.sum_eq_zero hz]
      ring
    rw [Finset.sum_range_succ, Finset.sum_range_succ, ← add_assoc u, norm_add_sq_real, ih (by omega),
      hinner, norm_smul, mul_pow, norm_unitAt hgD, Real.norm_eq_abs, sq_abs]
    ring

/-- A log whose rounds are strictly decreasing and lie in `[1, b]` has at most `b` entries. -/
theorem length_le_of_sorted (l : List LogEntry) : ∀ b : ℕ, l.Pairwise (fun e e' => e'.t < e.t) →
    (∀ e ∈ l, 1 ≤ e.t ∧ e.t ≤ b) → l.length ≤ b := by
  induction l with
  | nil => intro b _ _; simp
  | cons e l ih =>
    intro b hp hb
    rw [List.pairwise_cons] at hp
    have he := hb e (by simp)
    have hl : l.length ≤ b - 1 := ih (b - 1) hp.2 (fun e' he' => by
      have h1 := hb e' (by simp [he'])
      have h2 := hp.1 e' he'
      omega)
    simp only [List.length_cons]
    omega

/-- The interval product over the current round `[t, t]` when the head record (of round `t`) is pending and
the older records are from earlier rounds. -/
theorem intervalProd_head_pending {e : LogEntry} {l : List LogEntry} {t : ℕ} (he : e.t = t)
    (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < t) : intervalProd (e :: l) t t = 1 := by
  unfold intervalProd
  have hfl : l.filter (fun e' => decide (t ≤ e'.t ∧ e'.t ≤ t)) = [] := by
    rw [List.filter_eq_nil_iff]
    intro e' he'
    have := hl e' he'
    simp only [decide_eq_true_eq, not_and, not_le]
    omega
  rw [List.filter_cons_of_pos (by simp [he]), hfl]
  simp [hpend, Outcome.mult]

/-! ## The bound `15√33/(8γ)` -/

theorem gamma_le_one_real (P : StreamParams) : (P.gamma : ℝ) ≤ 1 := by
  have : P.gamma ≤ 1 := by
    unfold StreamParams.gamma
    exact pow_le_one₀ (by norm_num) (by norm_num)
  exact_mod_cast this

/-- `15√33/(8γ) < 16/γ = B`. -/
theorem Bbar_lt_B (P : StreamParams) : Bbar P < (P.B : ℝ) := by
  have hγ : (0 : ℝ) < (P.gamma : ℝ) := by exact_mod_cast P.gamma_pos
  have hs : √33 < 6 := by
    rw [Real.sqrt_lt' (by norm_num)]
    norm_num
  rw [(B_eq_and_gt P).1]
  unfold Bbar
  rw [div_lt_div_iff₀ (mul_pos (by norm_num) hγ) hγ]
  nlinarith

/-- `1 ≤ 15√33/(8γ)` (`γ ≤ 1`, `√33 ≥ 5`). -/
theorem one_le_Bbar (P : StreamParams) : 1 ≤ Bbar P := by
  have hγ : (0 : ℝ) < (P.gamma : ℝ) := by exact_mod_cast P.gamma_pos
  have hγ1 := gamma_le_one_real P
  have hs : (5 : ℝ) ≤ √33 := (Real.le_sqrt' (by norm_num)).mpr (by norm_num)
  unfold Bbar
  rw [le_div_iff₀ (mul_pos (by norm_num) hγ)]
  linarith

theorem Bbar_le_B (P : StreamParams) : Bbar P ≤ (P.B : ℝ) := (Bbar_lt_B P).le

/-- `Bbar^D ≤ B^D ≤ B^{H+2} = G` for `D ≤ H + 1`. -/
theorem Bbar_pow_le_G (P : StreamParams) {D : ℕ} (hD : D ≤ P.H + 1) : Bbar P ^ D ≤ (P.G : ℝ) := by
  have h1 := one_le_Bbar P
  have hB := (B_eq_and_gt P).2
  have hG : P.G = P.B ^ (P.H + 2) := rfl
  calc Bbar P ^ D ≤ (P.B : ℝ) ^ D := pow_le_pow_left₀ (by linarith) (Bbar_le_B P) D
    _ ≤ (P.B : ℝ) ^ (P.H + 2) := pow_le_pow_right₀ hB.le (by omega)
    _ = (P.G : ℝ) := by rw [hG]; push_cast; rfl

/-! ## Exports -/

section Exports

variable {P : StreamParams}

/-- Theorem 5.11 (1) (eq. `R:eq:Pint-less-than-B`): every local interval product of every live learner over any
interval of its lifetime so far lies in `(0, 15√33/(8γ)] ⊂ (0, B)`. -/
theorem prod_le_B {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) (t1 t2 : ℕ) :
    0 < intervalProd (S.log d) t1 t2 ∧ intervalProd (S.log d) t1 t2 ≤ Bbar P ∧ Bbar P < (P.B : ℝ) := by
  refine ⟨?_, h.prod_le d hd t1 t2, Bbar_lt_B P⟩
  unfold intervalProd
  apply List.prod_pos
  intro x hx
  obtain ⟨e, he, rfl⟩ := List.mem_map.mp hx
  have he' : e ∈ S.log d := (List.mem_filter.mp he).1
  have := (h.mult_mem d hd e he').1
  linarith

/-- Theorem 5.11 (2a), compound products (eq. `R:eq:compound-product-factorization`): the multipliers applied
to a counter/tag/cache trace, grouped by generating depth `j < D`, are local interval products of the ghost logs. -/
theorem prod_family_le {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {D : ℕ}
    (hD : D ≤ ph.live P.H) (a b : ℕ → ℕ) :
    0 < ∏ j ∈ Finset.range D, intervalProd (S.log j) (a j) (b j) ∧
      ∏ j ∈ Finset.range D, intervalProd (S.log j) (a j) (b j) ≤ Bbar P ^ D := by
  have hmem : ∀ j ∈ Finset.range D, j < ph.live P.H := fun j hj =>
    lt_of_lt_of_le (Finset.mem_range.mp hj) hD
  refine ⟨Finset.prod_pos fun j hj => (prod_le_B h (hmem j hj) (a j) (b j)).1, ?_⟩
  apply compound_product_le (Finset.range D) _ (one_le_Bbar P) _ (by simp)
  intro j hj
  obtain ⟨h0, h1, -⟩ := prod_le_B h (hmem j hj) (a j) (b j)
  exact ⟨h0.le, h1⟩

/-- Theorem 5.11 (2a) (eq. `R:eq:Cd-upper-bound`): `0 < C_d ≤ B^d`. -/
theorem C_le_B_pow {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) : 0 < S.C d ∧ S.C d ≤ (P.B : ℝ) ^ d := by
  refine ⟨h.C_pos d hd, ?_⟩
  rw [h.C_prod d hd]
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (B_eq_and_gt P).2.le
  apply compound_product_le (Finset.range d) _ hB1 _ (by simp)
  intro j hj
  have hjd : j < ph.live P.H := lt_trans (Finset.mem_range.mp hj) hd
  obtain ⟨h0, h1, h2⟩ := prod_le_B h hjd (S.tb d) S.t
  exact ⟨h0.le, h1.trans h2.le⟩

/-- The box promise gives `‖x_0‖ ≤ √n U < W` (Theorem 5.11 (2b) base case, eq. `R:eq:base-case-V0`). -/
theorem norm_x0_le_W {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S)
    (hbox : ∀ j : Fin P.Dstar, |S.x0 j| ≤ (P.U : ℝ)) : ‖S.x0‖ ≤ (P.W : ℝ) := by
  have hnD : P.n ≤ P.Dstar := by unfold StreamParams.Dstar; omega
  have hsq : ‖S.x0‖ ^ 2 ≤ (P.n : ℝ) * (P.U : ℝ) ^ 2 := by
    have e1 : ‖S.x0‖ ^ 2 = ∑ j ∈ Finset.range P.Dstar, coordAt S.x0 j ^ 2 := by
      rw [EuclideanSpace.real_norm_sq_eq, ← Fin.sum_univ_eq_sum_range (fun j => coordAt S.x0 j ^ 2)]
      refine Finset.sum_congr rfl fun i _ => ?_
      simp [coordAt, i.isLt]
    rw [e1, ← Finset.sum_range_add_sum_Ico _ hnD]
    have e2 : ∑ j ∈ Finset.Ico P.n P.Dstar, coordAt S.x0 j ^ 2 = 0 := by
      refine Finset.sum_eq_zero fun j hj => ?_
      rw [h.x0_phys j (Finset.mem_Ico.mp hj).1]
      ring
    rw [e2, add_zero]
    calc ∑ j ∈ Finset.range P.n, coordAt S.x0 j ^ 2 ≤ ∑ _j ∈ Finset.range P.n, (P.U : ℝ) ^ 2 := by
          refine Finset.sum_le_sum fun j hj => ?_
          have hj' : j < P.Dstar := lt_of_lt_of_le (Finset.mem_range.mp hj) hnD
          have hb : |coordAt S.x0 j| ≤ (P.U : ℝ) := by
            unfold coordAt
            rw [dif_pos hj']
            exact hbox ⟨j, hj'⟩
          exact sq_le_sq' (abs_le.mp hb).1 (abs_le.mp hb).2
      _ = (P.n : ℝ) * (P.U : ℝ) ^ 2 := by simp
  have hle : ‖S.x0‖ ≤ √(P.n : ℝ) * (P.U : ℝ) := by
    have h1 : √(‖S.x0‖ ^ 2) ≤ √((P.n : ℝ) * (P.U : ℝ) ^ 2) := Real.sqrt_le_sqrt hsq
    rwa [Real.sqrt_sq (norm_nonneg _), Real.sqrt_mul (Nat.cast_nonneg _),
      Real.sqrt_sq (Nat.cast_nonneg _)] at h1
  exact hle.trans (StreamParams.sqrt_n_mul_U_lt_W P).le

/-- Lemma 5.10 (b) with `𝒰_{d,k} ≤ 𝒰_{d,0}`: `Ẽ_d ≤ 𝒰_{d,0}` for every live depth. -/
theorem Et_le_Ud {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) : S.Et d ≤ (P.Ud d : ℝ) := by
  obtain ⟨ng, hng, hEB⟩ := h.epoch d hd
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hρ0 : (0 : ℝ) ≤ 1 - (P.eta : ℝ) ^ 2 / 64 := by nlinarith
  have hρ1 : 1 - (P.eta : ℝ) ^ 2 / 64 ≤ 1 := by nlinarith
  have hUd : (0 : ℝ) < (P.Ud d : ℝ) := by
    have : 0 < P.Ud d := by unfold StreamParams.Ud; positivity
    exact_mod_cast this
  have hU : 0 < env P d (R.k d) := by
    unfold env
    exact div_pos hUd (by positivity)
  have hlen : (S.log d).length ≤ P.T := by
    have h1 := length_le_of_sorted (S.log d) S.t (h.log_sorted d hd) (fun e he => by
      obtain ⟨a1, a2, -⟩ := h.log_t d hd e he
      obtain ⟨b1, -⟩ := h.tb_le d hd
      omega)
    have := h.round_le
    have := P.m_lt_T
    omega
  obtain ⟨hc1, hc2, hc3⟩ := hEB.ceiling hρ0 hρ1 hU (hng.trans hlen) (T_gamma_sq_le P).1
  have henv : env P d (R.k d) ≤ (P.Ud d : ℝ) := by
    unfold env
    exact div_le_self hUd.le (one_le_pow₀ (by norm_num))
  linarith

/-- `√(w² + ω) ≤ w + σ ≤ 8B^{H+1}V_H + 2 = V` for `0 ≤ w ≤ 6B^HV_H`. -/
theorem aug_le_V (P : StreamParams) {w : ℝ} (hw0 : 0 ≤ w)
    (hw : w ≤ 6 * (P.B : ℝ) ^ P.H * (P.Vd P.H : ℝ)) : √(w ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ) := by
  obtain ⟨hs0, hs1, hom, hV⟩ := sigma_V P
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (B_eq_and_gt P).2.le
  obtain ⟨h1, h2⟩ := augmented_le (H := P.H) hB1 (Nat.cast_nonneg _) hs0.le (by linarith) hw0 hw
  rw [hom, hV]
  exact h1.trans h2

/-- Theorem 5.11 (2b) (eq. `R:eq:xd-Vd-bound`) and the augmented family bound (Lemma 6.1 (iii)): with
`‖x_0‖ ≤ W`, `‖x_d‖ ≤ V_d` for `d ≤ live`, `‖r_d‖ ≤ 2B^dV_d` for `d < live`, and for every
`w ∈ {x_d, y_d, r_d, c y_d, x_d − c y_d}` (`d < live`, `|c| ≤ 3/2`; `y_d⁺ = c y_d`, `r_d⁺ = x_d − y_d⁺`) and
`w = x_H` (if all depths are live), `√(‖w‖² + ω) ≤ V` (premise of Theorem 4.9). -/
theorem vector_bounds_inv {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S)
    (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) :
    (∀ d ≤ ph.live P.H, ‖S.x d‖ ≤ (P.Vd d : ℝ)) ∧
      (∀ d < ph.live P.H, ‖S.r d‖ ≤ 2 * (P.B : ℝ) ^ d * (P.Vd d : ℝ)) ∧
      (∀ d < ph.live P.H, ∀ c : ℝ, |c| ≤ 3 / 2 →
        ∀ w ∈ ({S.x d, S.y d, S.r d, c • S.y d, S.x d - c • S.y d} : Set (Vec P)),
          √(‖w‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ)) ∧
      (ph.live P.H = P.H → √(‖S.x P.H‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ)) := by
  have hL := h.live_le
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (B_eq_and_gt P).2.le
  have h0 : ‖S.x 0‖ ≤ (P.Vd 0 : ℝ) := by
    have e : S.x 0 = S.x0 := by simp [TreeState.x]
    rw [e, StreamParams.Vd_zero]
    exact hbox
  have hx : ∀ d < ph.live P.H, S.x (d + 1) = S.x d - S.r d := fun d _ => TreeState.x_succ S d
  have hC : ∀ d < ph.live P.H, 0 < S.C d ∧ S.C d ≤ (P.B : ℝ) ^ d := fun d hd => C_le_B_pow h hd
  have hEt : ∀ d < ph.live P.H, ‖S.r d‖ ^ 2 / S.C d ^ 2 ≤ (P.Ud d : ℝ) := fun d hd => Et_le_Ud h hd
  have hU : ∀ d < ph.live P.H, √(P.Ud d : ℝ) ≤ 2 * (P.Vd d : ℝ) := fun d _ => (Vd_sq_le_half_Ud P d).2
  have hV : ∀ d < ph.live P.H, (P.Vd (d + 1) : ℝ) = (1 + 2 * (P.B : ℝ) ^ d) * (P.Vd d : ℝ) := by
    intro d _
    rw [StreamParams.Vd_succ]
    push_cast
    ring
  obtain ⟨hxV, hrV⟩ := vector_bounds (H := ph.live P.H) S.x S.r S.C (fun d => (P.Vd d : ℝ))
    (fun d => (P.Ud d : ℝ)) h0 hx hC hEt hU hV
  refine ⟨hxV, hrV, ?_, ?_⟩
  · intro d hd c hc w hw
    have hdH : d ≤ P.H := by omega
    have hVd0 : (0 : ℝ) ≤ (P.Vd d : ℝ) := Nat.cast_nonneg _
    have hVdH : (P.Vd d : ℝ) ≤ (P.Vd P.H : ℝ) := by exact_mod_cast P.Vd_mono hdH
    obtain ⟨f1, f2, f3, f4, f5⟩ := family_le hdH hB1 hVd0 hVdH (hxV d hd.le) (hrV d hd) hc
    have hy : S.y d = S.x d - S.r d := TreeState.x_succ S d
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hw
    rcases hw with rfl | rfl | rfl | rfl | rfl
    · exact aug_le_V P (norm_nonneg _) f1
    · rw [hy]; exact aug_le_V P (norm_nonneg _) f3
    · exact aug_le_V P (norm_nonneg _) f2
    · rw [hy]; exact aug_le_V P (norm_nonneg _) f4
    · rw [hy]; exact aug_le_V P (norm_nonneg _) f5
  · intro hLH
    have hxH := hxV P.H (by omega)
    have hVH0 : (0 : ℝ) ≤ (P.Vd P.H : ℝ) := Nat.cast_nonneg _
    have hBH : (1 : ℝ) ≤ (P.B : ℝ) ^ P.H := one_le_pow₀ hB1
    apply aug_le_V P (norm_nonneg _)
    nlinarith

/-- Lemma 5.3 (shadow form; L519–525): at the start of Step 4 the terminal input is
`x_H = Δ e_i + Σ_d δ_d e_{g(d,t)}` with orthogonal summands, so `‖x_H‖² = Δ² + Σ_{d<H} δ_d²`, which is the
exact terminal accumulator (`F2e2e.C.Alg.step3_leaf_eq`). -/
theorem leaf_norm_sq {R : Regs} {S : TreeSt P} (h : TreeInv P (.evals P.H) R S) :
    ‖S.x P.H‖ ^ 2 = ‖S.upd‖ ^ 2 + ∑ d ∈ Finset.range P.H, headδ (S.log d) ^ 2 := by
  obtain ⟨hupd, hx⟩ := h.leaf
  rw [hx rfl]
  exact norm_sq_add_guards P h.round_pos h.round_le S.upd hupd (fun d => headδ (S.log d)) le_rfl

/-- Lemma 5.8 (L647–701): on a nonzero round on the fingerprint event (`‖x_phys‖ ≥ 1`), with the root tag
`Ĉ_0 = C_0 = 1`, during Step 4 before the root is evaluated (the depths `< D` are not yet evaluated, `D ≥ 1`),
the inputs of the depths `d ≤ D` (in particular the depth `D − 1` being evaluated next) satisfy `‖x_d‖ ≥ ν`:
`‖x_0‖ = ‖x_phys‖ ≥ 1 > ν`, and for `1 ≤ d ≤ D` the root guard coordinate is unattenuated,
`‖x_d‖ ≥ |x_{d,g(0,t)}| = δ_{g(0,t)} ≥ γη/(240√2) > 2^{H+11}√2 ν` (eq. `R:eq:all-depths-norm-floor`). -/
theorem norm_floor {R : Regs} {S : TreeSt P} {D : ℕ} (h : TreeInv P (.evals D) R S) (hD : 0 < D)
    (hDH : D ≤ P.H) (hx0 : 1 ≤ ‖S.x0‖) (hroot : R.Chat 0 = 1) : ∀ d ≤ D, (P.nu : ℝ) ≤ ‖S.x d‖ := by
  have hν1 : (P.nu : ℝ) < 1 := by exact_mod_cast P.nu_lt_one
  have hν0 : (0 : ℝ) < (P.nu : ℝ) := by exact_mod_cast P.nu_pos
  intro d hd
  rcases Nat.eq_zero_or_pos d with rfl | hd0
  · have e : S.x 0 = S.x0 := by simp [TreeState.x]
    rw [e]
    linarith
  have hH : 0 < P.H := by omega
  have hlive : 0 < (Phase.evals D).live P.H := hH
  -- the root's record of the current round is pending
  obtain ⟨e, l', hlog, het, hpend_iff, hrest⟩ := h.log_phase 0 hlive
  have hpend : e.out = .pending := hpend_iff.mp hD
  have hmem : e ∈ S.log 0 := by rw [hlog]; simp
  obtain ⟨heC, heδ⟩ := h.pending 0 hlive e (by rw [hlog]; simp) hpend
  have hC0 : S.C 0 = 1 := by rw [h.C_prod 0 hlive]; simp
  have hprod : intervalProd (S.log 0) e.t S.t = 1 := by
    rw [hlog, het]
    exact intervalProd_head_pending het hpend (fun e' he' => (hrest e' he').1)
  have hcoord := h.coord 0 hlive e hmem
  rw [hprod, heC, hC0] at hcoord
  have hg : e.g = guardIdx P 0 S.t := by rw [(h.log_t 0 hlive e hmem).2.2, het]
  have hr0 : coordAt (S.r 0) (guardIdx P 0 S.t) = -e.δ := by
    rw [← hg]
    linarith
  -- the other (pending) depths `1 ≤ j < d` vanish on the root guard coordinate
  have hrj : ∀ j ∈ Finset.range d, j ≠ 0 → coordAt (S.r j) (guardIdx P 0 S.t) = 0 := by
    intro j hj hj0
    have hjd : j < d := Finset.mem_range.mp hj
    have hcf : ∀ j < D, ∀ i < P.H, i ≠ j → coordAt (S.r j) (guardIdx P i S.t) = 0 := h.cur_fresh
    exact hcf j (by omega) 0 hH (Ne.symm hj0)
  have hx0g : coordAt S.x0 (guardIdx P 0 S.t) = 0 := h.x0_phys _ (guardIdx_ge P 0 S.t)
  have hxd : coordAt (S.x d) (guardIdx P 0 S.t) = e.δ := by
    unfold TreeState.x
    rw [coordAt_sub, coordAt_sum, hx0g, ← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hd0),
      Finset.sum_eq_zero (fun j hj => hrj j (Finset.mem_of_mem_erase hj) (Finset.ne_of_mem_erase hj)),
      hr0]
    ring
  -- the root guard is far above `ν`
  have hδ : (P.nu : ℝ) < e.δ := by
    rw [heδ, hroot]
    have hU := h.root_env hlive
    have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
    have hγ0 : (0 : ℝ) < (P.gamma : ℝ) := by exact_mod_cast P.gamma_pos
    have hh0 : (0 : ℝ) < (P.hg : ℝ) := by exact_mod_cast P.hg_pos
    have hU' : (P.eta : ℝ) ^ 2 / 512 ≤ env P 0 (R.k 0) := by
      have : (0 : ℝ) ≤ (P.eta : ℝ) ^ 2 := sq_nonneg _
      linarith
    obtain ⟨-, h2, h3⟩ := root_guard_lower hh0 hγ0 hη0 hU' (root_guard_grid P)
    obtain ⟨m1, m2⟩ := root_guard_margin P.H hν0 (gamma_mul_eta P)
    unfold nomGuard
    linarith
  have habs := TreeState.abs_coordAt_le_norm (S.x d) (guardIdx P 0 S.t)
  rw [hxd] at habs
  have := le_abs_self e.δ
  linarith

/-- Theorem 5.9 (2), `ACCEPT` at depth `d` (height `ℓ = H − d`): the returned `S = P + Q̂` satisfies
`|S − ‖x_d‖²| ≤ 8(ℓ+1)η‖x_d‖²` (eq. `R:eq:height-ell-accuracy`). -/
theorem accept_accuracy {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) (hroot : R.Chat 0 = 1) {Pc Qhat : ℝ} (hP : 0 ≤ Pc) (hQ : 0 ≤ Qhat)
    (hcert : |(‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (Pc + Qhat + (P.omega : ℝ)) - 1| ≤
      (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) + (P.eta : ℝ) / 4) :
    |Pc + Qhat - ‖S.x d‖ ^ 2| ≤ 8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 := by
  have hfl := norm_floor h (Nat.succ_pos d) (by omega) hx0 hroot d (Nat.le_succ d)
  have hν0 : (0 : ℝ) ≤ (P.nu : ℝ) := by exact_mod_cast P.nu_pos.le
  have hX : (P.nu : ℝ) ^ 2 ≤ ‖S.x d‖ ^ 2 := pow_le_pow_left₀ hν0 hfl 2
  exact (step4_accept (step4Params_committed P) (Nat.sub_le P.H d) hX (add_nonneg hP hQ) hcert).2.2

/-- Theorem 5.9 (2), rejection at depth `d`: the returned `N₁(x_d)` with the numerical certificate
(eq. `R:eq:cert-numerical`) satisfies `|N₁ − ‖x_d‖²| ≤ 8(ℓ+1)η‖x_d‖²` (eq. `R:eq:post-rejection-N1-handoff`). -/
theorem reject_accuracy {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) (hroot : R.Chat 0 = 1) {N1 : ℝ}
    (hN : |N1 - ‖S.x d‖ ^ 2| ≤ (P.eta : ℝ) * ‖S.x d‖ ^ 2 / 2 ^ 13 + (P.omega : ℝ)) :
    |N1 - ‖S.x d‖ ^ 2| ≤ 8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 := by
  have hfl := norm_floor h (Nat.succ_pos d) (by omega) hx0 hroot d (Nat.le_succ d)
  have hν0 : (0 : ℝ) ≤ (P.nu : ℝ) := by exact_mod_cast P.nu_pos.le
  have hX : (P.nu : ℝ) ^ 2 ≤ ‖S.x d‖ ^ 2 := pow_le_pow_left₀ hν0 hfl 2
  exact (step4_reject_handoff (ℓ := P.H - d) (step4Params_committed P) hX hN).2

end Exports

end F2e2e.C.Tree
