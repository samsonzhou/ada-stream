import Mathlib
import F2e2e.C.Tree.Shadow
import F2e2e.C.Tree.Guard
import F2e2e.C.Tree.Step4
import F2e2e.C.Tree.Epoch
import F2e2e.C.Tree.Caps
import F2e2e.C.Tree.ParamFacts

/-!
# Part III §5: the tree part of the chronological invariant (definitions)

Source: `parts/partIII.tex` Section 5 (L407–989) and the chronological induction of Theorem
`R:thm:chronological-closure-and-main-proof` (L1287–1307).

The paper's Section 5 results depend on each other and on Section 6 across time (Lemma 5.7 ← Lemma 6.1 (ii)
← Theorem 5.11; Theorem 5.9 ← Lemma 6.2; Lemma 5.8 ← Theorem 5.9 (3), Lemma 5.10 (b) at earlier rounds;
Lemma 5.10 ← Theorem 5.11 (2b) at birth). Following Theorem 6.4, they are proved here as ONE invariant
`TreeInv P ph R S` of the tree shadow `S` (with its ghost log), indexed by the moment `ph` within the round and
the algorithm's stored learner registers `R`, preserved by every event (`treeInv_*`). The hypotheses of the step
lemmas are exactly the facts the paper imports at that moment from outside Section 5 (the bank certificates of
Theorem 4.9, the tag precision of Lemma 6.1 (ii), the cache invariant of Lemma 6.2, the fingerprint coupling
of Lemma 1.9, the box promise); the exports are what Sections 4 and 6 consume (product bounds, `C_d ≤ B^d`,
vector bounds, norm floor, returned accuracy, contraction, caps).

Items of `TreeInv` (paper reference):
* shape of the ghost logs and of the phase (`LogPhase`: which learners have been evaluated this round);
* `C_prod`: `C_d = ∏_{j<d} P_{int,j}[t_birth(d), t]` (eq. `R:eq:Cd-upper-bound`);
* `prod_le`: every local interval product is `≤ 15√33/(8γ)` (eq. `R:eq:Pint-less-than-B`);
* `coord`: the guard coordinate identity `r_{d,g(d,t')} C_d(t') = −δ(t') P_int[t', t] C_d` (L965–968);
* `nonomit`: the guard of every correction round was non-omitted, `δ/C ≥ (γ/15)√𝒰_{d,k}` (L957–964);
* `epoch`: the maintained epoch bound of Lemma 5.10 (`EpochBound`);
* `root_env`: `𝒰_{0,k_0} ≥ η²/64` (eq. `R:eq:root-envelope-floor`);
* `counters`: `J_used = K₀k + j_epoch`, `j_epoch < K₀`, `k + 12 ≤ K_epoch` (eqs. `R:eq:epoch-halving-termination`,
  `R:eq:Jstar-lifetime-cap`);
* `x0_phys`, `r_supp`, `fresh`: supports and freshness of the guard coordinates (Lemma 5.6);
* `pending`: the Step-3 data of the learners not yet evaluated in this round; `leaf`: the terminal input during
  Steps 1–3 (Lemma 5.3).
-/

namespace F2e2e.C.Tree

open F2e2e

/-- The stored learner registers the tree invariant refers to (read from the algorithm state,
`F2e2e.C.Alg.Learner`): the real value of the stored tag `Ĉ_d`, the epoch `k_d`, the intra-epoch counter
`j_epoch` and the lifetime counter `J_used` of depth `d`. -/
structure Regs where
  /-- the stored tag `Ĉ_d` (real value `mantissa · h_C`) -/
  Chat : ℕ → ℝ
  /-- the epoch index `k_d` -/
  k : ℕ → ℕ
  /-- the intra-epoch correction counter `j_epoch` -/
  jE : ℕ → ℕ
  /-- the lifetime correction counter `J_used` -/
  jU : ℕ → ℕ

/-- The epoch envelope `𝒰_{d,k} = 2^{-k} 𝒰_{d,0}` (Definition 5.1, partIII.tex L440). -/
noncomputable def env (P : StreamParams) (d k : ℕ) : ℝ := (P.Ud d : ℝ) / 2 ^ k

/-- The nominal guard `δ̃_{g,d} = (γ/4)√𝒰_{d,k}` (eq. `R:eq:committed-guard-amplitude`). -/
noncomputable def nomGuard (P : StreamParams) (d k : ℕ) : ℝ := (P.gamma : ℝ) / 4 * √(env P d k)

/-- The bound `15√33/(8γ)` of eq. `R:eq:Pint-less-than-B` (`< 16/γ = B`). -/
noncomputable def Bbar (P : StreamParams) : ℝ := 15 * √33 / (8 * (P.gamma : ℝ))

/-- The local interval product `P_int[t₁, t₂]` of a learner's ghost log (eq. `R:eq:Pint-definition`). -/
noncomputable def intervalProd (l : List LogEntry) (t1 t2 : ℕ) : ℝ :=
  ((l.filter (fun e => decide (t1 ≤ e.t ∧ e.t ≤ t2))).map (fun e => e.out.mult)).prod

/-- The guard amplitude of the most recent entry of a log (`0` if empty). -/
def headδ : List LogEntry → ℝ
  | [] => 0
  | e :: _ => e.δ

/-- The moment within a round (Algorithm `R:alg:within-round-tree`). -/
inductive Phase where
  /-- Step 1: the depths `< D` are live (the deeper ones are retired, or not yet born) -/
  | births (D : ℕ)
  /-- after Step 2, during Step 3: the guards of the depths `< D` have been injected -/
  | guards (D : ℕ)
  /-- Step 4: the depths `≥ D` have been evaluated -/
  | evals (D : ℕ)
  /-- the round is over (after Step 4, or after the zero-round bypass) -/
  | idle

/-- The number of live depths at a moment. -/
def Phase.live (H : ℕ) : Phase → ℕ
  | .births D => D
  | _ => H

/-- The paper coordinate of the next guard to be injected at round `t` (Lemma 5.6: guard coordinates increase
in the order of injection; `g(H,t) = g(0,t+1)`). -/
def Phase.nextG (P : StreamParams) (t : ℕ) : Phase → ℕ
  | .births _ => P.guardCoord 0 t
  | .guards D => P.guardCoord D t
  | .evals _ => P.guardCoord P.H t
  | .idle => P.guardCoord P.H t

/-- The shape of the ghost log of depth `d` at round `t`, by phase: which learners have a record of the current
round, and which records are still pending (Step 3 done, Step 4 not yet). -/
def LogPhase (ph : Phase) (t d : ℕ) (l : List LogEntry) : Prop :=
  match ph with
  | .births _ => ∀ e ∈ l, e.t < t ∧ e.out ≠ .pending
  | .guards D =>
      (d < D → ∃ e l', l = e :: l' ∧ e.t = t ∧ e.out = .pending ∧ ∀ e' ∈ l', e'.t < t ∧ e'.out ≠ .pending) ∧
        (D ≤ d → ∀ e ∈ l, e.t < t ∧ e.out ≠ .pending)
  | .evals D => ∃ e l', l = e :: l' ∧ e.t = t ∧ (d < D ↔ e.out = .pending) ∧
      ∀ e' ∈ l', e'.t < t ∧ e'.out ≠ .pending
  | .idle => ∀ e ∈ l, e.out ≠ .pending

/-- The terminal input during Steps 1–3 (for Lemma 5.3): after the births `x_H = 0`; after Step 2 and the
guards of the depths `< D`, `x_H = Δ e_i + Σ_{d<D} δ_d e_{g(d,t)}`. -/
def LeafPhase (P : StreamParams) (ph : Phase) (S : TreeSt P) : Prop :=
  match ph with
  | .births D => S.upd = 0 ∧ (D = P.H → S.x P.H = 0)
  | .guards D => (∀ j, P.n ≤ j → coordAt S.upd j = 0) ∧
      S.x P.H = S.upd + ∑ d ∈ Finset.range D, headδ (S.log d) • unitAt P.Dstar (guardIdx P d S.t)
  | .evals D => (∀ j, P.n ≤ j → coordAt S.upd j = 0) ∧ (D = P.H →
      S.x P.H = S.upd + ∑ d ∈ Finset.range P.H, headδ (S.log d) • unitAt P.Dstar (guardIdx P d S.t))
  | .idle => True

/-- The current round's guard coordinates in the learners not yet evaluated in this round (for Lemma 5.8 (iii):
the root guard coordinate is unattenuated in `x_d` until depth `d` is evaluated): during Step 3 every residual
`r_j` vanishes on the current guard coordinates `g(i,t)` of the other depths `i ≠ j` (they are fresh, or touched
only by depth `i`'s own guard); during Step 4 this persists for the depths `j < D` not yet evaluated. -/
def CurFresh (P : StreamParams) (ph : Phase) (S : TreeSt P) : Prop :=
  match ph with
  | .guards _ => ∀ j < P.H, ∀ i < P.H, i ≠ j → coordAt (S.r j) (guardIdx P i S.t) = 0
  | .evals D => ∀ j < D, ∀ i < P.H, i ≠ j → coordAt (S.r j) (guardIdx P i S.t) = 0
  | _ => True

/-- The tree part of the chronological invariant of Theorem 6.4 at the moment `ph` of round `S.t`, for the
stored learner registers `R` (see the module docstring). -/
structure TreeInv (P : StreamParams) (ph : Phase) (R : Regs) (S : TreeSt P) : Prop where
  /-- rounds `1 ≤ t ≤ m` -/
  round_pos : 1 ≤ S.t
  round_le : S.t ≤ P.m
  live_le : ph.live P.H ≤ P.H
  /-- the root input is the physical vector (Lemma 5.8 (i): root guards never enter `x_0`) -/
  x0_phys : ∀ j, P.n ≤ j → coordAt S.x0 j = 0
  /-- the residual `r_j` vanishes on the guard coordinates of the deeper depths (Lemma 5.6 (2), (3)) -/
  r_supp : ∀ j < ph.live P.H, ∀ i t' : ℕ, j < i → i < P.H → coordAt (S.r j) (guardIdx P i t') = 0
  /-- freshness: every residual vanishes from the next guard coordinate on (Lemma 5.6 (1)) -/
  fresh : ∀ j < ph.live P.H, ∀ l : ℕ, ph.nextG P S.t ≤ l + 1 → coordAt (S.r j) l = 0
  /-- birth rounds: `1 ≤ t_birth(d) ≤ t`, lifetimes nested (Definition 5.1 (1)) -/
  tb_le : ∀ d < ph.live P.H, 1 ≤ S.tb d ∧ S.tb d ≤ S.t
  tb_mono : ∀ j d, j < d → d < ph.live P.H → S.tb j ≤ S.tb d
  /-- the ghost log: one record per round of the lifetime, most recent first, on the right coordinate -/
  log_t : ∀ d < ph.live P.H, ∀ e ∈ S.log d, S.tb d ≤ e.t ∧ e.t ≤ S.t ∧ e.g = guardIdx P d e.t
  log_sorted : ∀ d < ph.live P.H, (S.log d).Pairwise (fun e e' => e'.t < e.t)
  log_phase : ∀ d < ph.live P.H, LogPhase ph S.t d (S.log d)
  /-- (T2) the exact tags: `C_d > 0` and `C_d = ∏_{j<d} P_{int,j}[t_birth(d), t]` (eq. `R:eq:Cd-upper-bound`) -/
  C_pos : ∀ d < ph.live P.H, 0 < S.C d
  C_prod : ∀ d < ph.live P.H, S.C d = ∏ j ∈ Finset.range d, intervalProd (S.log j) (S.tb d) S.t
  /-- local multipliers lie in `[1/2, 3/2]` (Theorem 5.9 (4)) -/
  mult_mem : ∀ d < ph.live P.H, ∀ e ∈ S.log d, 1 / 2 ≤ e.out.mult ∧ e.out.mult ≤ 3 / 2
  /-- (T1) all local interval products are `≤ 15√33/(8γ)` (eq. `R:eq:Pint-less-than-B`) -/
  prod_le : ∀ d < ph.live P.H, ∀ t1 t2 : ℕ, intervalProd (S.log d) t1 t2 ≤ Bbar P
  /-- (T3) the guard coordinate identity (Lemma 5.6 (2), Lemma 5.4 (iii)(b); partIII.tex L965–968) -/
  coord : ∀ d < ph.live P.H, ∀ e ∈ S.log d,
    coordAt (S.r d) e.g * e.C = -e.δ * intervalProd (S.log d) e.t S.t * S.C d
  entry_C_pos : ∀ d < ph.live P.H, ∀ e ∈ S.log d, 0 < e.C
  entry_δ_nonneg : ∀ d < ph.live P.H, ∀ e ∈ S.log d, 0 ≤ e.δ
  /-- (T7) non-omission of the guard of every correction round (eq. `R:eq:first-correction-non-omission`,
  Lemma 5.7 (2)), in the form monotone in the epoch -/
  nonomit : ∀ d < ph.live P.H, ∀ e ∈ S.log d, ∀ c : ℝ, e.out = .corrected c →
    (P.gamma : ℝ) / 15 * √(env P d (R.k d)) ≤ e.δ / e.C
  /-- (T5) the maintained epoch bound of Lemma 5.10, with `ng` own guards since the start of the epoch -/
  epoch : ∀ d < ph.live P.H, ∃ ng ≤ (S.log d).length,
    EpochBound (1 - (P.eta : ℝ) ^ 2 / 64) P.gamma (env P d (R.k d)) (S.Et d) (R.jE d) ng
  /-- (T6) the root envelope floor (eq. `R:eq:root-envelope-floor`) -/
  root_env : 0 < ph.live P.H → (P.eta : ℝ) ^ 2 / 64 ≤ env P 0 (R.k 0)
  /-- (T8) the local counters (Algorithm L509) and the epoch cap with margin -/
  counters : ∀ d < ph.live P.H,
    R.jU d = P.K0 * R.k d + R.jE d ∧ R.jE d < P.K0 ∧ R.k d + 12 ≤ P.Kepoch
  /-- the Step-3 data of a learner not yet evaluated in this round are still current: its exact tag, and its
  guard is `guardAmp h_g Ĉ_d δ̃_d` for the current registers -/
  pending : ∀ d < ph.live P.H, ∀ e ∈ (S.log d).head?, e.out = .pending →
    e.C = S.C d ∧ e.δ = guardAmp P.hg (R.Chat d) (nomGuard P d (R.k d))
  /-- the learners not yet evaluated in this round vanish on the other current guard coordinates (`CurFresh`) -/
  cur_fresh : CurFresh P ph S
  /-- the terminal input during Steps 1–3 (Lemma 5.3) -/
  leaf : LeafPhase P ph S

end F2e2e.C.Tree
