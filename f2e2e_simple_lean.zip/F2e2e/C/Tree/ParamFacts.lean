import Mathlib
import F2e2e.C.Tree.Step4

/-!
# Part III §5: the parameter facts used by Section 5, for the committed parameters

Source: `parts/partII.tex` Definitions `R:def:global-parameters` (L166–194) and `R:def:dyadic-grids`
(L196–207); `parts/partIII.tex` L758–769 ((P1)–(P3) of Theorem 5.9), L634 (Lemma 5.7), L684, L690–698
(Lemma 5.8), L881–889 (Lemma 5.10), L957–987 (Theorem 5.11).

The committed parameters are those of `F2e2e.C.Params` (exact rationals / naturals, cast to `ℝ` here):
`η = P.eta`, `γ = P.gamma`, `ν = P.nu`, `B = P.B`, `G = P.G`, `T = P.T`, `D_* = P.Dstar`, `V = P.V`,
`V_d = P.Vd d`, `𝒰_{d,0} = P.Ud d`, `𝒰_* = P.Ustar`, `σ = P.sigma`, `ω = P.omega`, `h_P = P.hP`,
`h_g = P.hg`, `e_C = P.eC`, `h_step = P.hstep`, `K₀ = P.K0`, `K_epoch = P.Kepoch`, `J_* = P.Jstar`.

All proofs cast the exact rational / natural facts of `F2e2e.C.ParamsFacts`, `F2e2e.C.ParamsGrids` and
`F2e2e.C.ParamsTree` (namespace `F2e2e.StreamParams`) to `ℝ`.
-/

namespace F2e2e.C.Tree

open F2e2e

/-- The additive cache drift of (H2) (eq. `R:eq:sec5-cache-invariant-premise`, partIII.tex L718):
`2ωG² + TG²D_*h_P`. -/
noncomputable def cacheDrift (P : StreamParams) : ℝ :=
  2 * (P.omega : ℝ) * (P.G : ℝ) ^ 2 + (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.Dstar : ℝ) * (P.hP : ℝ)

/-- (P1)–(P3) of Theorem 5.9 hold for the committed parameters (partIII.tex L758–769; numeric certificates
N11–N14 of the paper map). -/
theorem step4Params_committed (P : StreamParams) :
    Step4Params P.H (P.eta : ℝ) (P.omega : ℝ) (P.nu : ℝ) (cacheDrift P) := by
  have hP1 : 64 * ((P.H : ℚ) + 1) ^ 2 * P.eta ≤ 1 / 2 ^ 14 := by
    have h := P.sixtyfour_H_add_one_sq_mul_eta_le
    rwa [one_div_pow] at h
  have hP2 : 2 * P.omega * (P.G : ℚ) ^ 2 + P.T * (P.G : ℚ) ^ 2 * P.Dstar * P.hP ≤
      P.eta ^ 3 * P.nu ^ 2 / 2 ^ 39 :=
    P.two_omega_G_sq_add_lt.le
  have hP3 : 2 * P.omega ≤ P.eta * P.nu ^ 2 / 2 ^ 40 :=
    P.two_omega_le_two_omega_G_sq.trans P.two_omega_G_sq_lt.le
  have hom : (0 : ℝ) ≤ (P.omega : ℝ) := Rat.cast_nonneg.mpr P.omega_pos.le
  have hhP : (0 : ℝ) ≤ (P.hP : ℝ) := Rat.cast_nonneg.mpr P.hP_pos.le
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact_mod_cast P.eta_pos
  · exact_mod_cast P.omega_pos
  · exact_mod_cast P.nu_pos
  · have h := (Rat.cast_le (K := ℝ)).mpr hP1
    push_cast at h
    exact h
  · unfold cacheDrift
    exact add_nonneg (mul_nonneg (mul_nonneg (by norm_num) hom) (sq_nonneg _))
      (mul_nonneg (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (sq_nonneg _)) (Nat.cast_nonneg _)) hhP)
  · unfold cacheDrift
    exact_mod_cast hP2
  · exact_mod_cast hP3

/-- `h_step = 2^{-⌈log₂(2^20/η²)⌉} = η²/2^20` exactly (eq. `R:eq:grid-hstep-hADA`; `η` is a power of two). -/
theorem hstep_eq (P : StreamParams) : (P.hstep : ℝ) = (P.eta : ℝ) ^ 2 / 2 ^ 20 := by
  exact_mod_cast P.hstep_eq

/-- `ν = γη2^{-H-20}`, i.e. `γη = 2^{H+20} ν` (eq. `R:eq:param-nu-Emin`). -/
theorem gamma_mul_eta (P : StreamParams) :
    (P.gamma : ℝ) * (P.eta : ℝ) = 2 ^ (P.H + 20) * (P.nu : ℝ) := by
  exact_mod_cast P.gamma_mul_eta_eq

/-- `h_{g,unrefined} = γην/2^20 = B^{2H} h_g` (eq. `R:eq:grid-hg`, partII.tex L197–199). -/
theorem hgUnref_eq (P : StreamParams) :
    (P.gamma : ℝ) * (P.eta : ℝ) * (P.nu : ℝ) / 2 ^ 20 = (P.B : ℝ) ^ (2 * P.H) * (P.hg : ℝ) := by
  have h : P.gamma * P.eta * P.nu / 2 ^ 20 = (P.B : ℚ) ^ (2 * P.H) * P.hg := by
    rw [← StreamParams.hgUnref_eq P, ← P.hg_mul_B_pow, mul_comm]
  exact_mod_cast h

/-- `e_C = h_g/(2^10 γ V)` (eq. `R:eq:grid-eC-hC`), as reals. -/
theorem eC_eq (P : StreamParams) :
    (P.eC : ℝ) = (P.hg : ℝ) / (2 ^ 10 * (P.gamma : ℝ) * (P.V : ℝ)) := by
  have h : P.eC = P.hg / (2 ^ 10 * P.gamma * (P.V : ℚ)) := rfl
  rw [h]
  push_cast
  rfl

/-- `B = 16/γ` (eq. `R:eq:param-B`), and `B > 1`. -/
theorem B_eq_and_gt (P : StreamParams) : (P.B : ℝ) = 16 / (P.gamma : ℝ) ∧ 1 < (P.B : ℝ) := by
  refine ⟨?_, ?_⟩
  · exact_mod_cast P.B_eq_sixteen_div_gamma
  · exact_mod_cast P.one_lt_B

/-- `Tγ² ≤ 1/64` (eq. `R:eq:param-gamma`) and `m < T` (at most `m` guards per epoch). -/
theorem T_gamma_sq_le (P : StreamParams) : (P.T : ℝ) * (P.gamma : ℝ) ^ 2 ≤ 1 / 64 ∧ P.m < P.T := by
  refine ⟨?_, P.m_lt_T⟩
  have h := (Rat.cast_le (K := ℝ)).mpr P.T_mul_gamma_sq_le
  push_cast at h
  exact h

/-- `√𝒰_{d,0} < 2V_d` (from `𝒰_{d,0} < 4V_d²`). -/
theorem sqrt_Ud_lt_two_mul_Vd (P : StreamParams) (d : ℕ) : √(P.Ud d : ℝ) < 2 * (P.Vd d : ℝ) := by
  have hV : (0 : ℝ) < 2 * (P.Vd d : ℝ) := by
    have : (0 : ℝ) < (P.Vd d : ℝ) := Nat.cast_pos.mpr (P.Vd_pos d)
    linarith
  rw [Real.sqrt_lt' hV]
  have h : ((P.Ud d : ℕ) : ℝ) < 4 * ((P.Vd d : ℕ) : ℝ) ^ 2 := by exact_mod_cast P.Ud_lt_four_mul_Vd_sq d
  calc (P.Ud d : ℝ) < 4 * (P.Vd d : ℝ) ^ 2 := h
    _ = (2 * (P.Vd d : ℝ)) ^ 2 := by ring

/-- Lemma 5.7 premise (partIII.tex L634): for `d ≤ H` and every epoch `k`,
`√𝒰_{d,k} ≤ √𝒰_{d,0} < 2V_d ≤ 2V_H < V`, in particular `√𝒰_{d,k} ≤ 4V`. -/
theorem sqrt_U_le (P : StreamParams) {d : ℕ} (hd : d ≤ P.H) (k : ℕ) :
    √((P.Ud d : ℝ) / 2 ^ k) ≤ √(P.Ud d : ℝ) ∧ √(P.Ud d : ℝ) < 2 * (P.Vd d : ℝ) ∧
      2 * (P.Vd d : ℝ) ≤ 2 * (P.Vd P.H : ℝ) ∧ 2 * (P.Vd P.H : ℝ) < (P.V : ℝ) ∧
      √((P.Ud d : ℝ) / 2 ^ k) ≤ 4 * (P.V : ℝ) := by
  have h1 : √((P.Ud d : ℝ) / 2 ^ k) ≤ √(P.Ud d : ℝ) :=
    Real.sqrt_le_sqrt (div_le_self (Nat.cast_nonneg _) (one_le_pow₀ (by norm_num)))
  have h2 := sqrt_Ud_lt_two_mul_Vd P d
  have h3 : 2 * (P.Vd d : ℝ) ≤ 2 * (P.Vd P.H : ℝ) := by
    have : (P.Vd d : ℝ) ≤ (P.Vd P.H : ℝ) := by exact_mod_cast P.Vd_mono hd
    linarith
  have h4 : 2 * (P.Vd P.H : ℝ) < (P.V : ℝ) := by exact_mod_cast P.two_mul_Vd_lt_V le_rfl
  have hV : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  exact ⟨h1, h2, h3, h4, by linarith⟩

/-- Lemma 5.10 (a) at birth and Theorem 5.11 (2b): `V_d² ≤ 𝒰_{d,0}/2` and `√𝒰_{d,0} ≤ 2V_d`
(eq. `R:eq:param-Ud`: `𝒰_{d,0} ∈ [2V_d², 4V_d²)`). -/
theorem Vd_sq_le_half_Ud (P : StreamParams) (d : ℕ) :
    (P.Vd d : ℝ) ^ 2 ≤ (P.Ud d : ℝ) / 2 ∧ √(P.Ud d : ℝ) ≤ 2 * (P.Vd d : ℝ) := by
  refine ⟨?_, (sqrt_Ud_lt_two_mul_Vd P d).le⟩
  have h : 2 * ((P.Vd d : ℕ) : ℝ) ^ 2 ≤ ((P.Ud d : ℕ) : ℝ) := by
    exact_mod_cast P.two_mul_Vd_sq_le_Ud d
  linarith

/-- Lemma 5.8 (i) (partIII.tex L684): `𝒰_{0,0} ≥ 2V_0² = 2W² ≥ 8` (for `n, U ≥ 1`). -/
theorem eight_le_Ud_zero (P : StreamParams) (hn : 1 ≤ P.n) (hU : 1 ≤ P.U) : 8 ≤ (P.Ud 0 : ℝ) := by
  have hW : 2 ≤ P.W := by
    unfold StreamParams.W
    have := Nat.mul_pos hn hU
    omega
  have h1 : 2 * P.Vd 0 ^ 2 ≤ P.Ud 0 := P.two_mul_Vd_sq_le_Ud 0
  rw [StreamParams.Vd_zero] at h1
  have h4 : 4 ≤ P.W ^ 2 := by nlinarith
  have h8 : 8 ≤ P.Ud 0 := by omega
  exact_mod_cast h8

/-- Lemma 5.8 (ii) premise (partIII.tex L660, L694): `2h_g ≤ 2^{H+33} B^{2H} h_g = 2^{H+33} h_{g,unrefined} <
γη/(64√2)`. -/
theorem root_guard_grid (P : StreamParams) :
    2 * (P.hg : ℝ) ≤ (P.gamma : ℝ) * (P.eta : ℝ) / (64 * √2) := by
  have h34 : (2 : ℝ) ^ 34 * (P.hg : ℝ) ≤ 2 ^ (P.H + 33) * (P.hgUnref : ℝ) := by
    exact_mod_cast P.two_pow_34_mul_hg_le
  have hsq : ((2 : ℝ) ^ (P.H + 33) * (P.hgUnref : ℝ)) ^ 2 <
      ((P.gamma : ℝ) * (P.eta : ℝ) / 64) ^ 2 / 2 := by
    have h1 : ((2 : ℚ) ^ (P.H + 33) * P.hgUnref) ^ 2 < (P.gamma * P.eta / 64) ^ 2 / 2 := by
      rw [P.root_guard_sq]
      exact P.root_guard_gt_sq
    exact_mod_cast h1
  have hg0 : (0 : ℝ) ≤ (P.hg : ℝ) := Rat.cast_nonneg.mpr P.hg_pos.le
  have hge : (0 : ℝ) ≤ (P.gamma : ℝ) * (P.eta : ℝ) :=
    mul_nonneg (Rat.cast_nonneg.mpr P.gamma_pos.le) (Rat.cast_nonneg.mpr P.eta_pos.le)
  have hs2 : (0 : ℝ) < √2 := Real.sqrt_pos.mpr (by norm_num)
  have hlt : (2 : ℝ) ^ (P.H + 33) * (P.hgUnref : ℝ) < (P.gamma : ℝ) * (P.eta : ℝ) / (64 * √2) := by
    apply lt_of_pow_lt_pow_left₀ 2 (div_nonneg hge (by positivity))
    have hden : ((64 : ℝ) * √2) ^ 2 = 64 ^ 2 * 2 := by
      rw [mul_pow, Real.sq_sqrt (by norm_num)]
    rw [div_pow, hden]
    calc ((2 : ℝ) ^ (P.H + 33) * (P.hgUnref : ℝ)) ^ 2
        < ((P.gamma : ℝ) * (P.eta : ℝ) / 64) ^ 2 / 2 := hsq
      _ = ((P.gamma : ℝ) * (P.eta : ℝ)) ^ 2 / (64 ^ 2 * 2) := by ring
  have h2 : 2 * (P.hg : ℝ) ≤ 2 ^ 34 * (P.hg : ℝ) := by
    have : (2 : ℝ) ≤ 2 ^ 34 := by norm_num
    nlinarith
  linarith

/-- Theorem 5.9 (2) at the root (partIII.tex L731): `8(H+1)η ≤ 8(H+1)ε/(2^20(H+1)²) < ε/2` for the real `ε`
with `epsExp = ⌈log₂ ε⁻¹⌉` (`ε₀ ≤ ε`). -/
theorem root_eta_le (P : StreamParams) {ε : ℝ} (hε : 0 < ε) (hexp : P.epsExp = dyadicExp ε) :
    8 * ((P.H : ℝ) + 1) * (P.eta : ℝ) ≤ ε / 2 :=
  (StreamParams.eight_mul_H_add_one_mul_eta_lt_eps hexp hε).le

/-- `K₀ = ⌈128/η²⌉ = 128/η²` exactly (`η` is a power of two; Algorithm L509, partII.tex L188). -/
theorem K0_eq (P : StreamParams) : (P.K0 : ℝ) = 128 / (P.eta : ℝ) ^ 2 := by
  exact_mod_cast StreamParams.K0_eq P

/-- Theorem 5.11 (2c) with the committed powers of two (eq. `R:eq:epoch-halving-termination`, paper map N32):
if `2^{-k}𝒰_* > η²ν²/(256 B^{2H})` then `k < log₂(256𝒰_*B^{2H}/(η²ν²)) = K_epoch − 12`, i.e.
`k + 13 ≤ K_epoch`. -/
theorem epoch_lt (P : StreamParams) {k : ℕ}
    (h : (P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2 / (256 * (P.B : ℝ) ^ (2 * P.H)) < (P.Ustar : ℝ) / 2 ^ k) :
    k + 13 ≤ P.Kepoch := by
  have h' : P.eta ^ 2 * P.nu ^ 2 / (256 * (P.B : ℚ) ^ (2 * P.H)) < (P.Ustar : ℚ) / 2 ^ k := by
    have h2 : ((P.eta ^ 2 * P.nu ^ 2 / (256 * (P.B : ℚ) ^ (2 * P.H)) : ℚ) : ℝ) <
        (((P.Ustar : ℚ) / 2 ^ k : ℚ) : ℝ) := by
      push_cast
      exact h
    exact (Rat.cast_lt (K := ℝ)).mp h2
  have := StreamParams.add_twelve_lt_Kepoch_of h'
  omega

/-- `J_* = K₀(K_epoch + 1)` (eq. `R:eq:param-Kepoch-Jstar`) and `R_max = 4J_* + 2`, `J_max = 2J_*`. -/
theorem Jstar_eq (P : StreamParams) :
    P.Jstar = P.K0 * (P.Kepoch + 1) ∧ P.Jmax = 2 * P.Jstar ∧ P.Rmax = 4 * P.Jstar + 2 :=
  ⟨rfl, rfl, rfl⟩

/-- `0 < σ ≤ 1`, `ω = σ²`, `V = 8B^{H+1}V_H + 2` (augmented family bound of Theorem 5.11 (2b)). -/
theorem sigma_V (P : StreamParams) :
    0 < (P.sigma : ℝ) ∧ (P.sigma : ℝ) ≤ 1 ∧ (P.omega : ℝ) = (P.sigma : ℝ) ^ 2 ∧
      (P.V : ℝ) = 8 * (P.B : ℝ) ^ (P.H + 1) * (P.Vd P.H : ℝ) + 2 := by
  have hom : P.omega = P.sigma ^ 2 := rfl
  have hV : P.V = 8 * P.B ^ (P.H + 1) * P.Vd P.H + 2 := rfl
  refine ⟨?_, ?_, ?_, ?_⟩
  · exact_mod_cast P.sigma_pos
  · exact_mod_cast P.sigma_le_one
  · exact_mod_cast hom
  · exact_mod_cast hV

end F2e2e.C.Tree
