import Mathlib
import F2e2e.C.Tree.Basic

/-!
# Part III §5.4: Theorem 5.9 (Step-4 accuracy induction and non-circular two-step contraction), local form

Source: `parts/partIII.tex` Theorem `R:thm:step4-noncircular-contraction` (L703–857).

Tree-free statements on an arbitrary real inner product space `E` (instantiated with the shadow vectors of
`F2e2e/C/Tree/Shadow.lean`): for the learner evaluated at height `ℓ = H − d ∈ {1..H}` with residual `r = r_d`,
outgoing vector `y = y_d` and input `x = x_d = r + y`:

* (2) returned accuracy: on `ACCEPT` (`step4_accept`) and after a rejection (`step4_reject_handoff`,
  `F̂ = N₁(x)`), `|F̂ − ‖x‖²| ≤ 8(ℓ+1)η‖x‖²`; at the root `root_accuracy`;
* (1) the child input: `child_of_returned` (the height-`(ℓ−1)` returned accuracy is the height-`ℓ` child
  bound) and `child_of_leaf` (Lemma 5.3: the terminal value is exact);
* (3) Step A on rejection (`RejectSit.discrepancy`, `.sign_consistency`, `.ratio_enclosure`,
  `.energy_floor`);
* (4) Step B on rejection (`RejectSit.multiplicative`, `RejectSit.stepB`).

The hypotheses are the paper's: the norm floor `‖x‖ ≥ ν` (Lemma 5.8), the cache invariant (H2) with additive
drift `Dadd = 2ωG² + TG²D_*h_P` (Lemma 6.2 at the current moment), the bank certificate inequalities of
Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step` (eqs. `R:eq:cert-accept`, `R:eq:cert-high`,
`R:eq:cert-low`, `R:eq:cert-numerical`, partIII.tex L358–366) for the actual outcome, and the parameter
premises (P1)–(P3) of L758–769 (`Step4Params`; proved for the committed parameters in
`F2e2e/C/Tree/ParamFacts.lean`).
-/

namespace F2e2e.C.Tree

/-- The parameter premises of Theorem 5.9 (partIII.tex L758–769): (P1) eq. `R:eq:sec5-eta-H-small`,
(P2) eq. `R:eq:sec5-additive-drift-vs-Emin` for the additive cache drift `Dadd = 2ωG² + TG²D_*h_P`
(`η³ν²/2^39 = 2^{-19}(η/2^12)E_min`, `E_min = η²ν²/256`), (P3) eq. `R:eq:two-omega-absorbed-by-x`. -/
structure Step4Params (H : ℕ) (η ω ν Dadd : ℝ) : Prop where
  eta_pos : 0 < η
  omega_pos : 0 < ω
  nu_pos : 0 < ν
  /-- (P1): `(64ℓ² + 64ℓ + 16)η ≤ 64(H+1)²η ≤ 2^{-14}` (for all `ℓ ≤ H`). -/
  P1 : 64 * ((H : ℝ) + 1) ^ 2 * η ≤ 1 / 2 ^ 14
  Dadd_nonneg : 0 ≤ Dadd
  /-- (P2): `2ωG² + TG²D_*h_P ≤ η³ν²/2^39 = 2^{-19}(η/2^12)E_min`. -/
  P2 : Dadd ≤ η ^ 3 * ν ^ 2 / 2 ^ 39
  /-- (P3): `2ω ≤ 2^{-40}ην²`. -/
  P3 : 2 * ω ≤ η * ν ^ 2 / 2 ^ 40

/-- Derived parameter facts. -/
theorem Step4Params.eta_small {H : ℕ} {η ω ν Dadd : ℝ} (hp : Step4Params H η ω ν Dadd) :
    η ≤ 1 / 2 ^ 20 := by
  have h1 := hp.P1
  have hη := hp.eta_pos
  have hH : (64 : ℝ) ≤ 64 * ((H : ℝ) + 1) ^ 2 := by
    have : (1 : ℝ) ≤ ((H : ℝ) + 1) ^ 2 := by
      have : (1 : ℝ) ≤ (H : ℝ) + 1 := by have := Nat.cast_nonneg (α := ℝ) H; linarith
      nlinarith
    linarith
  nlinarith

/-- From (P1): `8(ℓ+1)η ≤ 2^{-17}` and `64(ℓ+1)²η ≤ 2^{-14}` for `ℓ ≤ H`. -/
theorem Step4Params.lin_small {H ℓ : ℕ} {η ω ν Dadd : ℝ} (hp : Step4Params H η ω ν Dadd) (hℓH : ℓ ≤ H) :
    8 * ((ℓ : ℝ) + 1) * η ≤ 1 / 2 ^ 17 ∧ 64 * ((ℓ : ℝ) + 1) ^ 2 * η ≤ 1 / 2 ^ 14 := by
  have h1 := hp.P1
  have hη := hp.eta_pos
  have hl : (ℓ : ℝ) + 1 ≤ (H : ℝ) + 1 := by exact_mod_cast Nat.add_le_add_right hℓH 1
  have hl0 : (1 : ℝ) ≤ (ℓ : ℝ) + 1 := by have := Nat.cast_nonneg (α := ℝ) ℓ; linarith
  have hsq : ((ℓ : ℝ) + 1) ^ 2 ≤ ((H : ℝ) + 1) ^ 2 := by nlinarith
  have h2 : 64 * ((ℓ : ℝ) + 1) ^ 2 * η ≤ 1 / 2 ^ 14 := by nlinarith
  refine ⟨?_, h2⟩
  have : 8 * ((ℓ : ℝ) + 1) ≤ 8 * ((ℓ : ℝ) + 1) ^ 2 := by nlinarith
  nlinarith

/-! ## Parts (1) and (2): returned accuracy -/

/-- Theorem 5.9 (2), `ACCEPT` branch (eqs. `R:eq:accept-r-minus-1`, `R:eq:S-plus-omega-upper`,
`R:eq:sec5-accept-final-bound`, partIII.tex L782–796): with `X = ‖x‖² ≥ ν²`, candidate `S ≥ 0` and the
certificate `|r − 1| ≤ θ_ℓ + η/4` for `r = (X + ω)/(S + ω)`, `θ_ℓ = (8ℓ+4)η`:
`S + ω ≤ (X + ω)/(1 − (8ℓ+5)η)` and `|S − X| ≤ 8(ℓ+1)η X`. -/
theorem step4_accept {H ℓ : ℕ} {η ω ν Dadd X S : ℝ} (hp : Step4Params H η ω ν Dadd) (hℓH : ℓ ≤ H)
    (hX : ν ^ 2 ≤ X) (hS : 0 ≤ S)
    (hcert : |(X + ω) / (S + ω) - 1| ≤ (8 * ℓ + 4) * η + η / 4) :
    S + ω ≤ (X + ω) / (1 - (8 * ℓ + 5) * η) ∧ S ≤ (X + ω) / (1 - (8 * ℓ + 5) * η) ∧
      |S - X| ≤ 8 * (ℓ + 1) * η * X := by
  have hη := hp.eta_pos
  have hω := hp.omega_pos
  have hηs := hp.eta_small
  obtain ⟨hlin, hsq⟩ := hp.lin_small hℓH
  have hl0 : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  have hX0 : 0 ≤ X := le_trans (sq_nonneg ν) hX
  have hu : 0 < S + ω := by linarith
  obtain ⟨a, ha⟩ : ∃ a : ℝ, a = (8 * ℓ + 4) * η + η / 4 := ⟨_, rfl⟩
  rw [← ha] at hcert
  have hlη : 0 ≤ (ℓ : ℝ) * η := mul_nonneg hl0 hη.le
  have ha0 : 0 ≤ a := by rw [ha]; linarith
  have ha5 : a ≤ (8 * ℓ + 5) * η := by rw [ha]; linarith
  have hb5 : (8 * ℓ + 5) * η ≤ 1 / 2 ^ 17 := by linarith
  have hpos : 0 < 1 - (8 * ℓ + 5) * η := by linarith
  have hapos : 0 < 1 - a := by linarith
  rw [abs_le] at hcert
  obtain ⟨hc1, hc2⟩ := hcert
  have e : (X + ω) / (S + ω) - 1 = (X - S) / (S + ω) := by field_simp; ring
  rw [e] at hc1 hc2
  have hc1' : -a * (S + ω) ≤ X - S := by
    have := (le_div_iff₀ hu).1 hc1; linarith
  have hc2' : X - S ≤ a * (S + ω) := by
    have := (div_le_iff₀ hu).1 hc2; linarith
  have hup : S + ω ≤ (X + ω) / (1 - a) := by
    rw [le_div_iff₀ hapos]; linarith
  have hup' : (X + ω) / (1 - a) ≤ (X + ω) / (1 - (8 * ℓ + 5) * η) :=
    div_le_div_of_nonneg_left (by linarith) hpos (by linarith)
  refine ⟨le_trans hup hup', by linarith, ?_⟩
  have h1 : |S - X| ≤ a * (S + ω) := by rw [abs_le]; constructor <;> linarith
  have h2 : a * (S + ω) ≤ a * ((X + ω) / (1 - a)) := mul_le_mul_of_nonneg_left hup ha0
  have h3 : a * ((X + ω) / (1 - a)) ≤ (a + 2 * a ^ 2) * (X + ω) := by
    have ha12 : a ≤ 1 / 2 := by linarith
    have key : a / (1 - a) ≤ a + 2 * a ^ 2 := by
      rw [div_le_iff₀ hapos]
      have e2 : (a + 2 * a ^ 2) * (1 - a) - a = a ^ 2 * (1 - 2 * a) := by ring
      have : 0 ≤ a ^ 2 * (1 - 2 * a) := mul_nonneg (sq_nonneg a) (by linarith)
      linarith
    have e3 : a * ((X + ω) / (1 - a)) = a / (1 - a) * (X + ω) := by ring
    rw [e3]
    exact mul_le_mul_of_nonneg_right key (by linarith)
  have hω' : ω ≤ η * X / 2 ^ 41 := by
    have := hp.P3
    have : η * ν ^ 2 ≤ η * X := mul_le_mul_of_nonneg_left hX hη.le
    linarith
  have h2a : 2 * a ^ 2 ≤ η / 2 ^ 13 := by
    have h8 : (8 * ℓ + 5) * η ≤ 8 * ((ℓ : ℝ) + 1) * η := by linarith
    have h0 : 0 ≤ (8 * ℓ + 5) * η := by linarith
    have h9 : a ^ 2 ≤ (8 * ((ℓ : ℝ) + 1) * η) ^ 2 :=
      pow_le_pow_left₀ ha0 (le_trans ha5 h8) 2
    have e9 : (8 * ((ℓ : ℝ) + 1) * η) ^ 2 = 64 * ((ℓ : ℝ) + 1) ^ 2 * η * η := by ring
    have h10 : 64 * ((ℓ : ℝ) + 1) ^ 2 * η * η ≤ 1 / 2 ^ 14 * η :=
      mul_le_mul_of_nonneg_right hsq hη.le
    linarith
  have ha1 : a + 2 * a ^ 2 ≤ 1 := by linarith
  have h4 : (a + 2 * a ^ 2) * (X + ω) ≤ (a + 2 * a ^ 2) * X + η * X / 2 ^ 41 := by
    have h6 : (a + 2 * a ^ 2) * ω ≤ 1 * (η * X / 2 ^ 41) :=
      mul_le_mul ha1 hω' hω.le (by norm_num)
    have e4 : (a + 2 * a ^ 2) * (X + ω) = (a + 2 * a ^ 2) * X + (a + 2 * a ^ 2) * ω := by ring
    linarith
  have h5 : (a + 2 * a ^ 2) * X + η * X / 2 ^ 41 ≤ 8 * (ℓ + 1) * η * X := by
    have hb : a + 2 * a ^ 2 ≤ (8 * ℓ + 4) * η + η / 4 + η / 2 ^ 13 := by rw [ha] at h2a ⊢; linarith
    have h7 : (a + 2 * a ^ 2) * X ≤ ((8 * ℓ + 4) * η + η / 4 + η / 2 ^ 13) * X :=
      mul_le_mul_of_nonneg_right hb hX0
    have hηX : 0 ≤ η * X := mul_nonneg hη.le hX0
    have e7 : 8 * ((ℓ : ℝ) + 1) * η * X -
        (((8 * ℓ + 4) * η + η / 4 + η / 2 ^ 13) * X + η * X / 2 ^ 41) =
        (15 / 4 - 1 / 2 ^ 13 - 1 / 2 ^ 41) * (η * X) := by ring
    have : 0 ≤ (15 / 4 - 1 / 2 ^ 13 - 1 / 2 ^ 41 : ℝ) * (η * X) :=
      mul_nonneg (by norm_num) hηX
    linarith
  linarith

/-- Theorem 5.9 (2), rejection branch (eq. `R:eq:post-rejection-N1-handoff`, partIII.tex L777–781):
the returned `N₁(x)` with the numerical certificate `|N − X| ≤ 2^{-13}ηX + ω` satisfies
`|N − X| < (2^{-13} + 2^{-41})ηX ≤ 8(ℓ+1)ηX`. -/
theorem step4_reject_handoff {H ℓ : ℕ} {η ω ν Dadd X N : ℝ} (hp : Step4Params H η ω ν Dadd)
    (hX : ν ^ 2 ≤ X) (hN : |N - X| ≤ η * X / 2 ^ 13 + ω) :
    |N - X| ≤ (1 / 2 ^ 13 + 1 / 2 ^ 41) * η * X ∧ |N - X| ≤ 8 * (ℓ + 1) * η * X := by
  have hη := hp.eta_pos
  have hX0 : 0 ≤ X := le_trans (sq_nonneg ν) hX
  have hω' : ω ≤ η * X / 2 ^ 41 := by
    have := hp.P3
    have : η * ν ^ 2 ≤ η * X := mul_le_mul_of_nonneg_left hX hη.le
    linarith
  have h1 : |N - X| ≤ (1 / 2 ^ 13 + 1 / 2 ^ 41) * η * X := by nlinarith
  refine ⟨h1, ?_⟩
  have hl0 : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  have : (1 / 2 ^ 13 + 1 / 2 ^ 41) * η * X ≤ 8 * (ℓ + 1) * η * X := by
    have hηX : 0 ≤ η * X := by positivity
    nlinarith
  linarith

/-- Theorem 5.9 (1), inductive step (partIII.tex L773): the child at height `ℓ − 1` returned
`F̂_{d+1}` with `|F̂_{d+1} − ‖x_{d+1}‖²| ≤ 8((ℓ−1)+1)η‖x_{d+1}‖²`, and `‖x_{d+1}‖² = Q_d`; hence the child
estimate `Q̂_d = F̂_{d+1}` satisfies `|Q̂ − Q| ≤ 8ℓηQ`. -/
theorem child_of_returned {ℓ : ℕ} {η Q Qhat : ℝ} (hℓ : 1 ≤ ℓ)
    (hret : |Qhat - Q| ≤ 8 * (((ℓ - 1 : ℕ) : ℝ) + 1) * η * Q) : |Qhat - Q| ≤ 8 * ℓ * η * Q := by
  have : (((ℓ - 1 : ℕ) : ℝ) + 1) = (ℓ : ℝ) := by
    rw [Nat.cast_sub hℓ]; push_cast; ring
  rwa [this] at hret

/-- Theorem 5.9 (1), base case (partIII.tex L773; Lemma 5.3): at height `ℓ = 1` the child is the exact
terminal accumulator, `Q̂ = Q`, so `|Q̂ − Q| = 0 ≤ 8ηQ`. -/
theorem child_of_leaf {η Q Qhat : ℝ} (hη : 0 ≤ η) (hQ : 0 ≤ Q) (hexact : Qhat = Q) :
    |Qhat - Q| ≤ 8 * ((1 : ℕ) : ℝ) * η * Q := by
  subst hexact; simp; positivity

/-- Theorem 5.9 (2) at the root (eq. `R:eq:root-F2-accuracy-step4`, partIII.tex L731–734): if
`|F̂ − F₂| ≤ 8(H+1)ηF₂` and `8(H+1)η ≤ ε/2` with `0 < ε ≤ 1`, then
`F₂/(1+ε) ≤ (1 − ε/2)F₂ ≤ F̂ ≤ (1 + ε/2)F₂ ≤ (1+ε)F₂`. -/
theorem root_accuracy {H : ℕ} {η ε F2 Fhat : ℝ} (hF2 : 0 ≤ F2) (hε : 0 < ε) (hε1 : ε ≤ 1)
    (hη : 8 * ((H : ℝ) + 1) * η ≤ ε / 2) (hacc : |Fhat - F2| ≤ 8 * ((H : ℝ) + 1) * η * F2) :
    F2 / (1 + ε) ≤ (1 - ε / 2) * F2 ∧ (1 - ε / 2) * F2 ≤ Fhat ∧ Fhat ≤ (1 + ε / 2) * F2 ∧
      (1 + ε / 2) * F2 ≤ (1 + ε) * F2 := by
  have h1 : |Fhat - F2| ≤ ε / 2 * F2 := le_trans hacc (mul_le_mul_of_nonneg_right hη hF2)
  rw [abs_le] at h1
  refine ⟨?_, by linarith, by linarith, by nlinarith⟩
  rw [div_le_iff₀ (by linarith)]
  nlinarith

/-! ## Parts (3) and (4): the rejection branch -/

/-- The situation of Theorem 5.9 (3)–(4) at a rejection at height `ℓ ∈ {1..H}` (partIII.tex L713–720,
L735, L800–803): residual `r = r_d`, outgoing vector `y = y_d` (input `x = r + y`), the norm floor
`ν ≤ ‖x‖` (Lemma 5.8), the cache `P ≥ 0` with the cache invariant (H2) (eq.
`R:eq:sec5-cache-invariant-premise`) `|P − E| ≤ (η/2^12)E + Dadd`, the child estimate `Q̂ ≥ 0` with
`|Q̂ − Q| ≤ 8ℓηQ` (part (1)), and the protected rejection certificate with sign `s` (`HIGH ↔ s = +1`,
`LOW ↔ s = −1`; eqs. `R:eq:cert-high`, `R:eq:cert-low`): `s(r_c − 1) ≥ θ_ℓ − η/4` with
`r_c = (‖x‖² + ω)/(S + ω)`, `S = P + Q̂`, `θ_ℓ = (8ℓ+4)η`. -/
structure RejectSit {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (H ℓ : ℕ) (η ω ν Dadd : ℝ) (r y : E) (P Qhat s : ℝ) : Prop where
  params : Step4Params H η ω ν Dadd
  one_le : 1 ≤ ℓ
  le_H : ℓ ≤ H
  floor : ν ≤ ‖r + y‖
  P_nonneg : 0 ≤ P
  Qhat_nonneg : 0 ≤ Qhat
  cache : |P - ‖r‖ ^ 2| ≤ η / 2 ^ 12 * ‖r‖ ^ 2 + Dadd
  child : |Qhat - ‖y‖ ^ 2| ≤ 8 * ℓ * η * ‖y‖ ^ 2
  sign : s = 1 ∨ s = -1
  cert : (8 * ℓ + 4) * η - η / 4 ≤ s * ((‖r + y‖ ^ 2 + ω) / (P + Qhat + ω) - 1)

namespace RejectSit

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] {H ℓ : ℕ} {η ω ν Dadd P Qhat s : ℝ}
  {r y : E}

/-- `s z ≥ -|z|` for `s = ±1`. -/
theorem sign_mul_ge {s z : ℝ} (hs : s = 1 ∨ s = -1) : -|z| ≤ s * z := by
  rcases hs with rfl | rfl
  · simp [neg_abs_le]
  · simp only [neg_mul, one_mul, neg_le_neg_iff]; exact le_abs_self z

/-- Step A, the proposal error without division by `E` (eq. `R:eq:S-minus-EplusQ-bound`). -/
theorem serr_bound {η Dadd P Qhat Er Q : ℝ} {ℓ : ℕ} (hη : 0 < η) (hℓ : 1 ≤ ℓ) (hE : 0 ≤ Er)
    (hQ : 0 ≤ Q) (hcache : |P - Er| ≤ η / 2 ^ 12 * Er + Dadd)
    (hchild : |Qhat - Q| ≤ 8 * ℓ * η * Q) (hD : Dadd ≤ η * (Er + Q) / 2 ^ 38) :
    |P + Qhat - (Er + Q)| ≤ (8 * ℓ + 1 / 2 ^ 11) * η * (Er + Q) := by
  have h1 : |P + Qhat - (Er + Q)| ≤ |P - Er| + |Qhat - Q| := by
    have : P + Qhat - (Er + Q) = (P - Er) + (Qhat - Q) := by ring
    rw [this]; exact abs_add_le _ _
  have hl : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  have hlEr : 0 ≤ (ℓ : ℝ) * (η * Er) := mul_nonneg hl (mul_nonneg hη.le hE)
  have hηQ : 0 ≤ η * Q := mul_nonneg hη.le hQ
  have hηT : 0 ≤ η * (Er + Q) := mul_nonneg hη.le (by linarith)
  have e : (8 * ℓ + 1 / 2 ^ 11) * η * (Er + Q) - (η / 2 ^ 12 * Er + η * (Er + Q) / 2 ^ 38 + 8 * ℓ * η * Q)
      = 8 * ((ℓ : ℝ) * (η * Er)) + (1 / 2 ^ 12) * (η * Q) + (1 / 2 ^ 12 - 1 / 2 ^ 38) * (η * (Er + Q)) := by
    ring
  have : 0 ≤ 8 * ((ℓ : ℝ) * (η * Er)) + (1 / 2 ^ 12) * (η * Q) +
      (1 / 2 ^ 12 - 1 / 2 ^ 38) * (η * (Er + Q)) := by positivity
  linarith

/-- Step A, the certificate rearranged (eq. `R:eq:rejection-raw-r-gap`): `s(X − S) ≥ c₀ S`. -/
theorem cert_bound {s X S ω c0 : ℝ} (hS : 0 ≤ S) (hω : 0 < ω) (hc0 : 0 ≤ c0)
    (hcert : c0 ≤ s * ((X + ω) / (S + ω) - 1)) : c0 * S ≤ s * (X - S) := by
  have hu : 0 < S + ω := by linarith
  have e : s * ((X + ω) / (S + ω) - 1) = s * (X - S) / (S + ω) := by field_simp; ring
  rw [e, le_div_iff₀ hu] at hcert
  have : c0 * S ≤ c0 * (S + ω) := mul_le_mul_of_nonneg_left (by linarith) hc0
  linarith

/-- Step A, the numerical core (eq. `R:eq:2s-ip-derivation`). -/
theorem stepA_numeric {η s ip X S T : ℝ} {ℓ : ℕ} (hη : 0 < η) (hℓ : 1 ≤ ℓ) (hT : 0 < T)
    (hsq : 64 * ((ℓ : ℝ) + 1) ^ 2 * η ≤ 1 / 2 ^ 14) (hsplit : 2 * s * ip = s * (X - S) + s * (S - T))
    (hcert : ((8 * ℓ + 4) * η - η / 4) * S ≤ s * (X - S)) (hsT : -|S - T| ≤ s * (S - T))
    (hSerr : |S - T| ≤ (8 * ℓ + 1 / 2 ^ 11) * η * T) :
    374 / 100 * η * T ≤ 2 * s * ip := by
  have hl : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  obtain ⟨A, hA⟩ : ∃ A : ℝ, A = (8 * ℓ + 4) * η - η / 4 := ⟨_, rfl⟩
  obtain ⟨Bc, hBc⟩ : ∃ Bc : ℝ, Bc = (8 * ℓ + 1 / 2 ^ 11) * η := ⟨_, rfl⟩
  rw [← hA] at hcert
  rw [← hBc] at hSerr
  have hlη : 0 ≤ (ℓ : ℝ) * η := mul_nonneg hl hη.le
  have hA0 : 0 ≤ A := by rw [hA]; linarith
  have hB0 : 0 ≤ Bc := by rw [hBc]; positivity
  have hSlow : T - Bc * T ≤ S := by have := (abs_le.1 hSerr).1; linarith
  have hAS : A * (T - Bc * T) ≤ A * S := mul_le_mul_of_nonneg_left hSlow hA0
  have hABc : A * Bc ≤ η / 2 ^ 14 := by
    have h1 : A ≤ 8 * ((ℓ : ℝ) + 1) * η := by rw [hA]; linarith
    have h2 : Bc ≤ 8 * ((ℓ : ℝ) + 1) * η := by rw [hBc]; linarith
    have h3 : A * Bc ≤ (8 * ((ℓ : ℝ) + 1) * η) * (8 * ((ℓ : ℝ) + 1) * η) :=
      mul_le_mul h1 h2 hB0 (by positivity)
    have h4 : (8 * ((ℓ : ℝ) + 1) * η) * (8 * ((ℓ : ℝ) + 1) * η) =
        (64 * ((ℓ : ℝ) + 1) ^ 2 * η) * η := by ring
    have h5 : (64 * ((ℓ : ℝ) + 1) ^ 2 * η) * η ≤ 1 / 2 ^ 14 * η :=
      mul_le_mul_of_nonneg_right hsq hη.le
    linarith
  have hABcT : (A * Bc) * T ≤ η / 2 ^ 14 * T := mul_le_mul_of_nonneg_right hABc hT.le
  have e1 : A * (T - Bc * T) = A * T - (A * Bc) * T := by ring
  have e2 : A - Bc = (15 / 4 - 1 / 2 ^ 11) * η := by rw [hA, hBc]; ring
  have e3 : (A - Bc) * T = A * T - Bc * T := by ring
  have hηT : 0 ≤ η * T := mul_nonneg hη.le hT.le
  have e4 : (15 / 4 - 1 / 2 ^ 11) * η * T - η / 2 ^ 14 * T - 374 / 100 * η * T =
      (15 / 4 - 1 / 2 ^ 11 - 1 / 2 ^ 14 - 374 / 100) * (η * T) := by ring
  have : 0 ≤ (15 / 4 - 1 / 2 ^ 11 - 1 / 2 ^ 14 - 374 / 100 : ℝ) * (η * T) :=
    mul_nonneg (by norm_num) hηT
  have e5 : (A - Bc) * T = (15 / 4 - 1 / 2 ^ 11) * η * T := by rw [e2]
  linarith

/-- The core of Step A: `2s⟨r,y⟩ ≥ 3.74 η (E+Q)`, together with the basic relations. -/
theorem core (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    ‖r + y‖ ^ 2 = ‖r‖ ^ 2 + 2 * inner ℝ r y + ‖y‖ ^ 2 ∧
      ν ^ 2 ≤ ‖r + y‖ ^ 2 ∧ ‖r + y‖ ^ 2 ≤ 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ∧
      |inner ℝ r y| ≤ ‖r‖ * ‖y‖ ∧ 0 < ‖r‖ ^ 2 + ‖y‖ ^ 2 ∧
      374 / 100 * η * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 2 * s * inner ℝ r y := by
  obtain ⟨hp, hℓ1, hℓH, hfloor, hP0, hQ0, hcache, hchild, hs, hcert⟩ := h
  have hη := hp.eta_pos
  have hω := hp.omega_pos
  have hν := hp.nu_pos
  have hηs := hp.eta_small
  obtain ⟨hlin, hsq⟩ := hp.lin_small hℓH
  have hX : ‖r + y‖ ^ 2 = ‖r‖ ^ 2 + 2 * inner ℝ r y + ‖y‖ ^ 2 := norm_add_sq_real r y
  have hcs : |inner ℝ r y| ≤ ‖r‖ * ‖y‖ := abs_real_inner_le_norm r y
  have hnr : 0 ≤ ‖r‖ := norm_nonneg r
  have hny : 0 ≤ ‖y‖ := norm_nonneg y
  have hfl : ν ^ 2 ≤ ‖r + y‖ ^ 2 := pow_le_pow_left₀ hν.le hfloor 2
  have hpar : ‖r + y‖ ^ 2 ≤ 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) := by
    have h1 := (abs_le.1 hcs).2
    have h2 : 0 ≤ (‖r‖ - ‖y‖) ^ 2 := sq_nonneg _
    have e : (‖r‖ - ‖y‖) ^ 2 = ‖r‖ ^ 2 - 2 * (‖r‖ * ‖y‖) + ‖y‖ ^ 2 := by ring
    linarith
  have hν2 : 0 < ν ^ 2 := by positivity
  have hT : 0 < ‖r‖ ^ 2 + ‖y‖ ^ 2 := by linarith
  have hD : Dadd ≤ η * (‖r‖ ^ 2 + ‖y‖ ^ 2) / 2 ^ 38 := by
    have h1 := hp.P2
    have h3 : η ^ 2 ≤ 1 := by
      have : η ≤ 1 := by linarith
      nlinarith
    have h2 : η ^ 3 * ν ^ 2 ≤ η * ν ^ 2 := by
      have e : η ^ 3 * ν ^ 2 = η ^ 2 * (η * ν ^ 2) := by ring
      rw [e]
      have : 0 ≤ η * ν ^ 2 := by positivity
      calc η ^ 2 * (η * ν ^ 2) ≤ 1 * (η * ν ^ 2) := mul_le_mul_of_nonneg_right h3 this
        _ = η * ν ^ 2 := one_mul _
    have h4 : η * ν ^ 2 ≤ η * (2 * (‖r‖ ^ 2 + ‖y‖ ^ 2)) :=
      mul_le_mul_of_nonneg_left (by linarith) hη.le
    linarith
  have hSerr := serr_bound hη hℓ1 (sq_nonneg ‖r‖) (sq_nonneg ‖y‖) hcache hchild hD
  have hS0 : 0 ≤ P + Qhat := by linarith
  have hl0 : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  have hc0 : 0 ≤ (8 * ℓ + 4) * η - η / 4 := by
    have : 0 ≤ (ℓ : ℝ) * η := mul_nonneg hl0 hη.le
    linarith
  have hc2 := cert_bound hS0 hω hc0 hcert
  have hsplit : 2 * s * inner ℝ r y =
      s * (‖r + y‖ ^ 2 - (P + Qhat)) + s * ((P + Qhat) - (‖r‖ ^ 2 + ‖y‖ ^ 2)) := by
    rw [hX]; ring
  have hsT := sign_mul_ge (z := (P + Qhat) - (‖r‖ ^ 2 + ‖y‖ ^ 2)) hs
  exact ⟨hX, hfl, hpar, hcs, hT, stepA_numeric hη hℓ1 hT hsq hsplit hc2 hsT hSerr⟩

/-- Basic positivity facts at a rejection: `s⟨r,y⟩ > 0`, `‖r‖, ‖y‖ > 0`, `2s⟨r,y⟩ ≥ η‖r‖‖y‖`. -/
theorem basics (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    0 < s * inner ℝ r y ∧ 0 < ‖r‖ ∧ 0 < ‖y‖ ∧ η * (‖r‖ * ‖y‖) ≤ 2 * s * inner ℝ r y ∧
      η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 2 * (‖r‖ * ‖y‖) := by
  obtain ⟨hX, hfl, hpar, hcs, hT, hmain⟩ := core h
  have hη := h.params.eta_pos
  have hs := h.sign
  have hnr : 0 ≤ ‖r‖ := norm_nonneg r
  have hny : 0 ≤ ‖y‖ := norm_nonneg y
  have hηT : 0 < η * (‖r‖ ^ 2 + ‖y‖ ^ 2) := mul_pos hη hT
  have hpos : 0 < 2 * s * inner ℝ r y := by nlinarith
  have hsip : 0 < s * inner ℝ r y := by linarith
  have hsle : s * inner ℝ r y ≤ ‖r‖ * ‖y‖ := by
    rcases hs with rfl | rfl
    · simpa using le_trans (le_abs_self _) hcs
    · simpa using le_trans (neg_le_abs _) hcs
  have hprod : 0 < ‖r‖ * ‖y‖ := lt_of_lt_of_le hsip hsle
  have hnr' : 0 < ‖r‖ := by
    rcases hnr.lt_or_eq with h1 | h1
    · exact h1
    · rw [← h1, zero_mul] at hprod; exact absurd hprod (lt_irrefl 0)
  have hny' : 0 < ‖y‖ := by
    rcases hny.lt_or_eq with h1 | h1
    · exact h1
    · rw [← h1, mul_zero] at hprod; exact absurd hprod (lt_irrefl 0)
  have hamgm : 2 * (‖r‖ * ‖y‖) ≤ ‖r‖ ^ 2 + ‖y‖ ^ 2 := by
    have := sq_nonneg (‖r‖ - ‖y‖)
    have e : (‖r‖ - ‖y‖) ^ 2 = ‖r‖ ^ 2 - 2 * (‖r‖ * ‖y‖) + ‖y‖ ^ 2 := by ring
    linarith
  have h1 : η * (‖r‖ * ‖y‖) ≤ η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) := by
    have := mul_le_mul_of_nonneg_left hamgm hη.le
    linarith
  have h2 : η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 2 * s * inner ℝ r y := by
    have : η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 374 / 100 * η * (‖r‖ ^ 2 + ‖y‖ ^ 2) := by
      have : 0 ≤ η * (‖r‖ ^ 2 + ‖y‖ ^ 2) := hηT.le
      nlinarith
    linarith
  exact ⟨hsip, hnr', hny', le_trans h1 h2, by linarith⟩

theorem sqrt_ratio_eq {u v : ℝ} (hu : 0 ≤ u) (hv : 0 < v) : √(u ^ 2 / v ^ 2) = u / v := by
  rw [show u ^ 2 / v ^ 2 = (u / v) ^ 2 by ring, Real.sqrt_sq (div_nonneg hu hv.le)]

/-- Step B, the ratio `√(P/Q̂)/√(E/Q) ∈ [1 − 2^{-14}, 1 + 2^{-14}]` (partIII.tex L838). -/
theorem sigma_ratio {Er Q P Qhat ρ σ : ℝ} (hE : 0 < Er) (hQ : 0 < Q) (_hP : 0 < P) (hQh : 0 < Qhat)
    (hPlo : (1 - 1 / 2 ^ 31) * Er ≤ P) (hPhi : P ≤ (1 + 1 / 2 ^ 31) * Er)
    (hQlo : (1 - 1 / 2 ^ 15) * Q ≤ Qhat) (hQhi : Qhat ≤ (1 + 1 / 2 ^ 15) * Q)
    (hρ0 : 0 ≤ ρ) (hρsq : ρ ^ 2 = Er / Q) (hσ0 : 0 ≤ σ) (hσsq : σ ^ 2 = P / Qhat) :
    (1 - 1 / 2 ^ 14) * ρ ≤ σ ∧ σ ≤ (1 + 1 / 2 ^ 14) * ρ := by
  have hEQ : 0 < Er * Q := mul_pos hE hQ
  have hσlo : ((1 - 1 / 2 ^ 14) * ρ) ^ 2 ≤ σ ^ 2 := by
    rw [hσsq, mul_pow, hρsq, ← mul_div_assoc, div_le_div_iff₀ hQ hQh]
    have k1 : ((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * (1 + 1 / 2 ^ 15) ≤ 1 - 1 / 2 ^ 31 := by norm_num
    have h1 : ((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * Er * Qhat ≤
        ((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * Er * ((1 + 1 / 2 ^ 15) * Q) :=
      mul_le_mul_of_nonneg_left hQhi (by positivity)
    have h2 : ((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * Er * ((1 + 1 / 2 ^ 15) * Q) =
        (((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * (1 + 1 / 2 ^ 15)) * (Er * Q) := by ring
    have h3 : (((1 : ℝ) - 1 / 2 ^ 14) ^ 2 * (1 + 1 / 2 ^ 15)) * (Er * Q) ≤
        (1 - 1 / 2 ^ 31) * (Er * Q) := mul_le_mul_of_nonneg_right k1 hEQ.le
    have h4 : (1 - 1 / 2 ^ 31) * Er * Q ≤ P * Q := mul_le_mul_of_nonneg_right hPlo hQ.le
    have h5 : (1 - 1 / 2 ^ 31) * (Er * Q) = (1 - 1 / 2 ^ 31) * Er * Q := by ring
    linarith
  have hσhi : σ ^ 2 ≤ ((1 + 1 / 2 ^ 14) * ρ) ^ 2 := by
    rw [hσsq, mul_pow, hρsq, ← mul_div_assoc, div_le_div_iff₀ hQh hQ]
    have k2 : (1 + 1 / 2 ^ 31 : ℝ) ≤ ((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * (1 - 1 / 2 ^ 15) := by norm_num
    have h1 : ((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * Er * ((1 - 1 / 2 ^ 15) * Q) ≤
        ((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * Er * Qhat :=
      mul_le_mul_of_nonneg_left hQlo (by positivity)
    have h2 : ((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * Er * ((1 - 1 / 2 ^ 15) * Q) =
        (((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * (1 - 1 / 2 ^ 15)) * (Er * Q) := by ring
    have h3 : (1 + 1 / 2 ^ 31) * (Er * Q) ≤
        (((1 : ℝ) + 1 / 2 ^ 14) ^ 2 * (1 - 1 / 2 ^ 15)) * (Er * Q) :=
      mul_le_mul_of_nonneg_right k2 hEQ.le
    have h4 : P * Q ≤ (1 + 1 / 2 ^ 31) * Er * Q := mul_le_mul_of_nonneg_right hPhi hQ.le
    have h5 : (1 + 1 / 2 ^ 31) * (Er * Q) = (1 + 1 / 2 ^ 31) * Er * Q := by ring
    linarith
  exact ⟨(pow_le_pow_iff_left₀ (by positivity) hσ0 two_ne_zero).1 hσlo,
    (pow_le_pow_iff_left₀ hσ0 (by positivity) two_ne_zero).1 hσhi⟩

/-- Step B, the effective step (eq. `R:eq:teff-tight-enclosure`, partIII.tex L840–848). -/
theorem teff_bounds {η ρ σ s hstep : ℝ} (hη : 0 < η) (hρ0 : 0 < ρ) (hρlo : η / 4 ≤ ρ)
    (hρhi : ρ ≤ 4 / η) (hσlo : (1 - 1 / 2 ^ 14) * ρ ≤ σ) (hσhi : σ ≤ (1 + 1 / 2 ^ 14) * ρ)
    (hs : s = 1 ∨ s = -1) (hh : 0 < hstep) (hhη : hstep ≤ η ^ 2 / 2 ^ 20) :
    ∃ t : ℝ, roundGrid hstep (s * (η / 16 * σ)) = s * t * ρ ∧ η / 32 ≤ t ∧ t ≤ η / 8 ∧
      -(1 / 2) ≤ roundGrid hstep (s * (η / 16 * σ)) ∧ roundGrid hstep (s * (η / 16 * σ)) ≤ 1 / 2 := by
  have hs2 : s * s = 1 := by rcases hs with rfl | rfl <;> norm_num
  have habs : |s| = 1 := by rcases hs with rfl | rfl <;> norm_num
  obtain ⟨z, hz⟩ : ∃ z : ℝ, z = s * (η / 16 * σ) := ⟨_, rfl⟩
  obtain ⟨a0, ha0⟩ : ∃ a0 : ℝ, a0 = roundGrid hstep z := ⟨_, rfl⟩
  rw [← hz, ← ha0]
  have hround := abs_roundGrid_sub_le hh z
  rw [← ha0] at hround
  have hsa0 : s * a0 = η / 16 * σ + s * (a0 - z) := by
    have e : s * a0 = s * z + s * (a0 - z) := by ring
    rw [e, hz, ← mul_assoc, hs2, one_mul]
  have hserr : |s * (a0 - z)| ≤ hstep / 2 := by rw [abs_mul, habs, one_mul]; exact hround
  have hserr' := abs_le.1 hserr
  have hm : hstep / 2 ≤ η / 16 * (1 / 2 - 1 / 2 ^ 14) * ρ := by
    have h1 : η / 16 * (1 / 2 - 1 / 2 ^ 14) * (η / 4) ≤ η / 16 * (1 / 2 - 1 / 2 ^ 14) * ρ :=
      mul_le_mul_of_nonneg_left hρlo (by positivity)
    have e : η / 16 * (1 / 2 - 1 / 2 ^ 14) * (η / 4) = (1 / 2 - 1 / 2 ^ 14) / 64 * η ^ 2 := by ring
    have h2 : η ^ 2 / 2 ^ 21 ≤ (1 / 2 - 1 / 2 ^ 14) / 64 * η ^ 2 := by
      have : 0 ≤ η ^ 2 := sq_nonneg η
      have e2 : (1 / 2 - 1 / 2 ^ 14) / 64 * η ^ 2 - η ^ 2 / 2 ^ 21 =
          ((1 / 2 - 1 / 2 ^ 14) / 64 - 1 / 2 ^ 21) * η ^ 2 := by ring
      have : 0 ≤ ((1 / 2 - 1 / 2 ^ 14) / 64 - 1 / 2 ^ 21 : ℝ) * η ^ 2 :=
        mul_nonneg (by norm_num) this
      linarith
    linarith
  obtain ⟨t, ht⟩ : ∃ t : ℝ, t = s * a0 / ρ := ⟨_, rfl⟩
  have htρ : t * ρ = s * a0 := by rw [ht]; field_simp
  have hat : a0 = s * t * ρ := by
    have e : s * t * ρ = s * (t * ρ) := by ring
    rw [e, htρ, ← mul_assoc, hs2, one_mul]
  have hσlo' : η / 16 * ((1 - 1 / 2 ^ 14) * ρ) ≤ η / 16 * σ :=
    mul_le_mul_of_nonneg_left hσlo (by positivity)
  have hσhi' : η / 16 * σ ≤ η / 16 * ((1 + 1 / 2 ^ 14) * ρ) :=
    mul_le_mul_of_nonneg_left hσhi (by positivity)
  have htlo : η / 32 ≤ t := by
    have h1 : η / 32 * ρ ≤ t * ρ := by
      rw [htρ, hsa0]
      have e : η / 16 * ((1 - 1 / 2 ^ 14) * ρ) - η / 16 * (1 / 2 - 1 / 2 ^ 14) * ρ = η / 32 * ρ := by
        ring
      linarith
    exact le_of_mul_le_mul_right h1 hρ0
  have hthi : t ≤ η / 8 := by
    have h1 : t * ρ ≤ η / 8 * ρ := by
      rw [htρ, hsa0]
      have hm2 : hstep / 2 ≤ η / 16 * (1 - 1 / 2 ^ 14) * ρ := by
        have : η / 16 * (1 / 2 - 1 / 2 ^ 14) * ρ ≤ η / 16 * (1 - 1 / 2 ^ 14) * ρ := by
          have : 0 ≤ η / 16 * ρ := by positivity
          nlinarith
        linarith
      have e : η / 16 * ((1 + 1 / 2 ^ 14) * ρ) + η / 16 * (1 - 1 / 2 ^ 14) * ρ = η / 8 * ρ := by ring
      linarith
    exact le_of_mul_le_mul_right h1 hρ0
  have ht0 : 0 ≤ t := le_trans (by positivity) htlo
  have htρle : t * ρ ≤ 1 / 2 := by
    have h1 : t * ρ ≤ η / 8 * ρ := mul_le_mul_of_nonneg_right hthi hρ0.le
    have h2 : η / 8 * ρ ≤ η / 8 * (4 / η) := mul_le_mul_of_nonneg_left hρhi (by positivity)
    have h3 : η / 8 * (4 / η) = 1 / 2 := by field_simp; ring
    linarith
  have htρ0 : 0 ≤ t * ρ := mul_nonneg ht0 hρ0.le
  refine ⟨t, hat, htlo, hthi, ?_, ?_⟩
  · rw [hat]; rcases hs with rfl | rfl
    · linarith
    · nlinarith
  · rw [hat]; rcases hs with rfl | rfl
    · nlinarith
    · nlinarith

/-- Step B, the contraction (eq. `R:eq:sec5-Eplus-contraction`, partIII.tex L850–856). -/
theorem contraction_core {η nr ny ip s t ρ a : ℝ} (hη : 0 < η) (_hnr : 0 < nr) (_hny : 0 < ny)
    (hs : s = 1 ∨ s = -1) (htlo : η / 32 ≤ t) (hthi : t ≤ η / 8) (hρy : ρ * ny = nr)
    (hρ0 : 0 < ρ) (ha : a = s * t * ρ) (hlow : η * (nr * ny) ≤ 2 * s * ip) :
    nr ^ 2 - 2 * a * ip + a ^ 2 * ny ^ 2 ≤ (1 - 3 * η ^ 2 / 128) * nr ^ 2 := by
  have hs2 : s * s = 1 := by rcases hs with rfl | rfl <;> norm_num
  have ht0 : 0 ≤ t := le_trans (by positivity) htlo
  have htρ0 : 0 ≤ t * ρ := mul_nonneg ht0 hρ0.le
  have h2a : t * η * nr ^ 2 ≤ 2 * a * ip := by
    have e1 : 2 * a * ip = (t * ρ) * (2 * s * ip) := by rw [ha]; ring
    have e2 : t * η * nr ^ 2 = (t * ρ) * (η * (nr * ny)) := by
      have : nr ^ 2 = ρ * ny * nr := by rw [hρy]; ring
      rw [this]; ring
    rw [e1, e2]
    exact mul_le_mul_of_nonneg_left hlow htρ0
  have ha2 : a ^ 2 * ny ^ 2 = t ^ 2 * nr ^ 2 := by
    rw [ha, ← hρy]
    have e : (s * t * ρ) ^ 2 * ny ^ 2 = (s * s) * t ^ 2 * (ρ * ny) ^ 2 := by ring
    rw [e, hs2, one_mul]
  have hq : 3 * η ^ 2 / 128 ≤ η * t - t ^ 2 := by
    have : 0 ≤ (t - η / 32) * (η / 8 - t) := mul_nonneg (by linarith) (by linarith)
    nlinarith
  have hE0 : 0 ≤ nr ^ 2 := sq_nonneg nr
  have h3 : (3 * η ^ 2 / 128) * nr ^ 2 ≤ (η * t - t ^ 2) * nr ^ 2 :=
    mul_le_mul_of_nonneg_right hq hE0
  rw [ha2]
  have e3 : (η * t - t ^ 2) * nr ^ 2 = t * η * nr ^ 2 - t ^ 2 * nr ^ 2 := by ring
  have e4 : (1 - 3 * η ^ 2 / 128) * nr ^ 2 = nr ^ 2 - (3 * η ^ 2 / 128) * nr ^ 2 := by ring
  linarith

/-- Theorem 5.9 (3), eq. `R:eq:sec5-rejection-discrepancy` (partIII.tex L737, L804–821), with
`E = ‖r‖²`, `Q = ‖y‖²`: `2s⟨r,y⟩ = s(‖x‖² − (E+Q)) ≥ 2.4η(E+Q) ≥ (η/2)(E+Q) ≥ η√(EQ) > 0`. -/
theorem discrepancy (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    2 * s * inner ℝ r y = s * (‖r + y‖ ^ 2 - (‖r‖ ^ 2 + ‖y‖ ^ 2)) ∧
      12 / 5 * η * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 2 * s * inner ℝ r y ∧
      η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ 12 / 5 * η * (‖r‖ ^ 2 + ‖y‖ ^ 2) ∧
      η * √(‖r‖ ^ 2 * ‖y‖ ^ 2) ≤ η / 2 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ∧
      0 < η * √(‖r‖ ^ 2 * ‖y‖ ^ 2) := by
  obtain ⟨hX, hfl, hpar, hcs, hT, hmain⟩ := core h
  obtain ⟨hsip, hnr, hny, hlow, hhalf⟩ := basics h
  have hη := h.params.eta_pos
  have hsq : √(‖r‖ ^ 2 * ‖y‖ ^ 2) = ‖r‖ * ‖y‖ := by
    rw [show ‖r‖ ^ 2 * ‖y‖ ^ 2 = (‖r‖ * ‖y‖) ^ 2 by ring, Real.sqrt_sq (by positivity)]
  have hηT : 0 ≤ η * (‖r‖ ^ 2 + ‖y‖ ^ 2) := by positivity
  rw [hsq]
  refine ⟨by rw [hX]; ring, by nlinarith, by nlinarith, ?_, by positivity⟩
  have hamgm : 2 * (‖r‖ * ‖y‖) ≤ ‖r‖ ^ 2 + ‖y‖ ^ 2 := by
    have := sq_nonneg (‖r‖ - ‖y‖)
    have e : (‖r‖ - ‖y‖) ^ 2 = ‖r‖ ^ 2 - 2 * (‖r‖ * ‖y‖) + ‖y‖ ^ 2 := by ring
    linarith
  have := mul_le_mul_of_nonneg_left hamgm hη.le
  linarith

/-- Theorem 5.9 (3), eq. `R:eq:sec5-sign-consistency` (partIII.tex L738, L821): `sgn⟨r,y⟩ = s`, i.e.
`s⟨r,y⟩ > 0`; in particular `r ≠ 0` and `y ≠ 0`. -/
theorem sign_consistency (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    0 < s * inner ℝ r y ∧ 0 < ‖r‖ ∧ 0 < ‖y‖ := by
  obtain ⟨hsip, hnr, hny, -, -⟩ := basics h
  exact ⟨hsip, hnr, hny⟩

/-- Theorem 5.9 (3), eq. `R:eq:sec5-ratio-enclosure` (partIII.tex L739, L821–825):
`√(E/Q) ∈ [η/4, 4/η]`. -/
theorem ratio_enclosure (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    η / 4 ≤ √(‖r‖ ^ 2 / ‖y‖ ^ 2) ∧ √(‖r‖ ^ 2 / ‖y‖ ^ 2) ≤ 4 / η := by
  obtain ⟨hsip, hnr, hny, hlow, hhalf⟩ := basics h
  have hη := h.params.eta_pos
  rw [sqrt_ratio_eq (norm_nonneg r) hny]
  -- η/2 (nr² + ny²) ≤ 2 nr ny
  constructor
  · rw [le_div_iff₀ hny]
    -- η/4 * ny ≤ nr
    have h1 : η / 2 * ‖y‖ ^ 2 ≤ 2 * (‖r‖ * ‖y‖) := by
      have : 0 ≤ η / 2 * ‖r‖ ^ 2 := by positivity
      linarith
    have h2 : (η / 4 * ‖y‖) * ‖y‖ ≤ ‖r‖ * ‖y‖ := by nlinarith
    exact le_of_mul_le_mul_right h2 hny
  · rw [div_le_div_iff₀ hny hη]
    have h1 : η / 2 * ‖r‖ ^ 2 ≤ 2 * (‖r‖ * ‖y‖) := by
      have : 0 ≤ η / 2 * ‖y‖ ^ 2 := by positivity
      linarith
    have h2 : (‖r‖ * η) * ‖r‖ ≤ (4 * ‖y‖) * ‖r‖ := by nlinarith
    exact le_of_mul_le_mul_right h2 hnr

/-- Theorem 5.9 (3), eq. `R:eq:sec5-rejection-energy-floor` (partIII.tex L740, L825–829):
`min(E,Q) ≥ (η²/16)(E+Q) ≥ (η²/32)‖x‖² > (η²/256)‖x‖² ≥ (η²/256)ν² = E_min`. -/
theorem energy_floor (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    η ^ 2 / 16 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ min (‖r‖ ^ 2) (‖y‖ ^ 2) ∧
      η ^ 2 / 32 * ‖r + y‖ ^ 2 ≤ η ^ 2 / 16 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ∧
      η ^ 2 / 256 * ‖r + y‖ ^ 2 < η ^ 2 / 32 * ‖r + y‖ ^ 2 ∧
      η ^ 2 / 256 * ν ^ 2 ≤ η ^ 2 / 256 * ‖r + y‖ ^ 2 := by
  obtain ⟨hX, hfl, hpar, hcs, hT, hmain⟩ := core h
  obtain ⟨hsip, hnr, hny, hlow, hhalf⟩ := basics h
  have hη := h.params.eta_pos
  have hν := h.params.nu_pos
  have hη2 : 0 < η ^ 2 := by positivity
  set T := ‖r‖ ^ 2 + ‖y‖ ^ 2 with hTdef
  -- (η/2 T)² ≤ (2 nr ny)² ⇒ η²/16 T² ≤ nr² ny²
  have hsq : (η / 2 * T) ^ 2 ≤ (2 * (‖r‖ * ‖y‖)) ^ 2 :=
    pow_le_pow_left₀ (by positivity) hhalf 2
  have hEQ : η ^ 2 / 16 * T * T ≤ ‖r‖ ^ 2 * ‖y‖ ^ 2 := by nlinarith
  have hE : η ^ 2 / 16 * T ≤ ‖r‖ ^ 2 := by
    have h1 : ‖r‖ ^ 2 * ‖y‖ ^ 2 ≤ ‖r‖ ^ 2 * T := by
      have : ‖y‖ ^ 2 ≤ T := by rw [hTdef]; nlinarith [sq_nonneg ‖r‖]
      exact mul_le_mul_of_nonneg_left this (by positivity)
    have h2 : (η ^ 2 / 16 * T) * T ≤ ‖r‖ ^ 2 * T := le_trans hEQ h1
    exact le_of_mul_le_mul_right h2 hT
  have hQ : η ^ 2 / 16 * T ≤ ‖y‖ ^ 2 := by
    have h1 : ‖r‖ ^ 2 * ‖y‖ ^ 2 ≤ T * ‖y‖ ^ 2 := by
      have : ‖r‖ ^ 2 ≤ T := by rw [hTdef]; nlinarith [sq_nonneg ‖y‖]
      exact mul_le_mul_of_nonneg_right this (by positivity)
    have h2 : (η ^ 2 / 16 * T) * T ≤ ‖y‖ ^ 2 * T := by nlinarith
    exact le_of_mul_le_mul_right h2 hT
  have hX0 : 0 < ‖r + y‖ ^ 2 := lt_of_lt_of_le (by positivity) hfl
  refine ⟨le_min hE hQ, ?_, ?_, ?_⟩
  · have := mul_le_mul_of_nonneg_left hpar hη2.le
    nlinarith
  · have : 0 < η ^ 2 * ‖r + y‖ ^ 2 := mul_pos hη2 hX0
    nlinarith
  · exact mul_le_mul_of_nonneg_left hfl (by positivity)

/-- Theorem 5.9 (4), eq. `R:eq:sec5-multiplicative-P-Qhat` (partIII.tex L742–745, L832–836):
`|P/E − 1| ≤ η/2^11`, `|Q̂/Q − 1| ≤ (8ℓ + 2^{-11})η < 2^{-15}`; in particular the positive-denominator
rule of Definition `R:def:total-behavior` (L454) is inactive: `P > 0` and `Q̂ > 0`. -/
theorem multiplicative (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) :
    |P / ‖r‖ ^ 2 - 1| ≤ η / 2 ^ 11 ∧ |Qhat / ‖y‖ ^ 2 - 1| ≤ (8 * ℓ + 1 / 2 ^ 11) * η ∧
      (8 * ℓ + 1 / 2 ^ 11) * η < 1 / 2 ^ 15 ∧ 0 < P ∧ 0 < Qhat := by
  obtain ⟨hE16, hX32, -, -⟩ := energy_floor h
  obtain ⟨hsip, hnr, hny, -, -⟩ := basics h
  obtain ⟨hX, hfl, hpar, hcs, hT, hmain⟩ := core h
  have hp := h.params
  have hη := hp.eta_pos
  have hν := hp.nu_pos
  obtain ⟨hlin, hsq⟩ := hp.lin_small h.le_H
  have hE0 : 0 < ‖r‖ ^ 2 := by positivity
  have hQ0 : 0 < ‖y‖ ^ 2 := by positivity
  have hl0 : (0 : ℝ) ≤ ℓ := Nat.cast_nonneg ℓ
  have hlη : 0 ≤ (ℓ : ℝ) * η := mul_nonneg hl0 hη.le
  have hEmin : η ^ 2 * ν ^ 2 / 32 ≤ ‖r‖ ^ 2 := by
    have h1 : η ^ 2 / 16 * (‖r‖ ^ 2 + ‖y‖ ^ 2) ≤ ‖r‖ ^ 2 := le_trans hE16 (min_le_left _ _)
    have h2 : η ^ 2 / 32 * ν ^ 2 ≤ η ^ 2 / 32 * ‖r + y‖ ^ 2 :=
      mul_le_mul_of_nonneg_left hfl (by positivity)
    have e : η ^ 2 * ν ^ 2 / 32 = η ^ 2 / 32 * ν ^ 2 := by ring
    linarith
  have hD : Dadd ≤ η * ‖r‖ ^ 2 / 2 ^ 31 := by
    have h1 := hp.P2
    have e : η ^ 3 * ν ^ 2 / 2 ^ 39 = η * (η ^ 2 * ν ^ 2 / 32) / 2 ^ 34 := by ring
    have h3 : η * (η ^ 2 * ν ^ 2 / 32) ≤ η * ‖r‖ ^ 2 := mul_le_mul_of_nonneg_left hEmin hη.le
    have h4 : 0 ≤ η * ‖r‖ ^ 2 := by positivity
    linarith
  have hPE : |P - ‖r‖ ^ 2| ≤ η / 2 ^ 11 * ‖r‖ ^ 2 := by
    have h1 := h.cache
    have h4 : 0 ≤ η * ‖r‖ ^ 2 := by positivity
    have e : η / 2 ^ 11 * ‖r‖ ^ 2 - (η / 2 ^ 12 * ‖r‖ ^ 2 + η * ‖r‖ ^ 2 / 2 ^ 31) =
        (1 / 2 ^ 12 - 1 / 2 ^ 31) * (η * ‖r‖ ^ 2) := by ring
    have : 0 ≤ (1 / 2 ^ 12 - 1 / 2 ^ 31 : ℝ) * (η * ‖r‖ ^ 2) := mul_nonneg (by norm_num) h4
    linarith
  have hQQ : |Qhat - ‖y‖ ^ 2| ≤ 8 * ℓ * η * ‖y‖ ^ 2 := h.child
  have hsmall : (8 * ℓ + 1 / 2 ^ 11) * η < 1 / 2 ^ 15 := by
    have : (8 * ℓ + 1 / 2 ^ 11) * η ≤ 8 * ((ℓ : ℝ) + 1) * η := by linarith
    have : (1 : ℝ) / 2 ^ 17 < 1 / 2 ^ 15 := by norm_num
    linarith
  refine ⟨?_, ?_, hsmall, ?_, ?_⟩
  · have e : P / ‖r‖ ^ 2 - 1 = (P - ‖r‖ ^ 2) / ‖r‖ ^ 2 := by field_simp
    rw [e, abs_div, abs_of_pos hE0, div_le_iff₀ hE0]; exact hPE
  · have e : Qhat / ‖y‖ ^ 2 - 1 = (Qhat - ‖y‖ ^ 2) / ‖y‖ ^ 2 := by field_simp
    rw [e, abs_div, abs_of_pos hQ0, div_le_iff₀ hQ0]
    have : 8 * ℓ * η * ‖y‖ ^ 2 ≤ (8 * ℓ + 1 / 2 ^ 11) * η * ‖y‖ ^ 2 := by
      have : 0 ≤ η * ‖y‖ ^ 2 := by positivity
      nlinarith
    linarith
  · have h1 := (abs_le.1 hPE).1
    have : η / 2 ^ 11 * ‖r‖ ^ 2 < ‖r‖ ^ 2 := by
      have : η / 2 ^ 11 < 1 := by have := hp.eta_small; linarith
      nlinarith
    linarith
  · have h1 := (abs_le.1 hQQ).1
    have : 8 * ℓ * η * ‖y‖ ^ 2 < ‖y‖ ^ 2 := by
      have : 8 * (ℓ : ℝ) * η < 1 := by linarith
      nlinarith
    linarith

/-- Theorem 5.9 (4), eqs. `R:eq:sec5-astep-properties` and `R:eq:sec5-Eplus-contraction` (partIII.tex
L746–753, L837–856): the step `a = clamp_{[-1/2,1/2]} round_{h_step}(s (η/16) √(P/Q̂))` (Algorithm
`R:alg:within-round-tree` L504; clamp of Definition `R:def:total-behavior` L455) on a grid
`0 < h_step ≤ η²/2^20` has an inactive clamp, `a = s t_eff √(E/Q)` with `t_eff ∈ [η/32, η/8]`,
`1 + a ∈ [1/2, 3/2]`, and the corrected residual `r⁺ = r − a y` (Lemma 5.4 (i)) satisfies
`E⁺ = E − 2a⟨r,y⟩ + a²Q ≤ (1 − 3η²/128) E ≤ (1 − η²/64) E`. -/
theorem stepB (h : RejectSit H ℓ η ω ν Dadd r y P Qhat s) {hstep a : ℝ} (hh : 0 < hstep)
    (hhη : hstep ≤ η ^ 2 / 2 ^ 20)
    (ha : a = max (-1 / 2) (min (1 / 2) (roundGrid hstep (s * (η / 16 * √(P / Qhat)))))) :
    a = roundGrid hstep (s * (η / 16 * √(P / Qhat))) ∧
      (∃ t : ℝ, a = s * t * √(‖r‖ ^ 2 / ‖y‖ ^ 2) ∧ η / 32 ≤ t ∧ t ≤ η / 8) ∧
      1 / 2 ≤ 1 + a ∧ 1 + a ≤ 3 / 2 ∧
      ‖r - a • y‖ ^ 2 = ‖r‖ ^ 2 - 2 * a * inner ℝ r y + a ^ 2 * ‖y‖ ^ 2 ∧
      ‖r - a • y‖ ^ 2 ≤ (1 - 3 * η ^ 2 / 128) * ‖r‖ ^ 2 ∧
      (1 - 3 * η ^ 2 / 128) * ‖r‖ ^ 2 ≤ (1 - η ^ 2 / 64) * ‖r‖ ^ 2 := by
  obtain ⟨hsip, hnr, hny, hlow, -⟩ := basics h
  obtain ⟨hρlo, hρhi⟩ := ratio_enclosure h
  obtain ⟨hPE, hQQ, hsmall, hP, hQ⟩ := multiplicative h
  have hp := h.params
  have hη := hp.eta_pos
  have hηs := hp.eta_small
  have hs := h.sign
  rw [sqrt_ratio_eq (norm_nonneg r) hny] at hρlo hρhi ⊢
  have hE0 : 0 < ‖r‖ ^ 2 := by positivity
  have hQ0 : 0 < ‖y‖ ^ 2 := by positivity
  have hρ0 : 0 < ‖r‖ / ‖y‖ := div_pos hnr hny
  have hρy : ‖r‖ / ‖y‖ * ‖y‖ = ‖r‖ := by field_simp
  have hρsq : (‖r‖ / ‖y‖) ^ 2 = ‖r‖ ^ 2 / ‖y‖ ^ 2 := by rw [div_pow]
  have hσ0 : 0 ≤ √(P / Qhat) := Real.sqrt_nonneg _
  have hσsq : √(P / Qhat) ^ 2 = P / Qhat := Real.sq_sqrt (div_nonneg hP.le hQ.le)
  have hx : η / 2 ^ 11 ≤ 1 / 2 ^ 31 := by linarith
  have hPE' : |P - ‖r‖ ^ 2| ≤ η / 2 ^ 11 * ‖r‖ ^ 2 := by
    have e : P / ‖r‖ ^ 2 - 1 = (P - ‖r‖ ^ 2) / ‖r‖ ^ 2 := by field_simp
    rw [e, abs_div, abs_of_pos hE0, div_le_iff₀ hE0] at hPE; exact hPE
  have hQQ' : |Qhat - ‖y‖ ^ 2| ≤ (8 * ℓ + 1 / 2 ^ 11) * η * ‖y‖ ^ 2 := by
    have e : Qhat / ‖y‖ ^ 2 - 1 = (Qhat - ‖y‖ ^ 2) / ‖y‖ ^ 2 := by field_simp
    rw [e, abs_div, abs_of_pos hQ0, div_le_iff₀ hQ0] at hQQ; exact hQQ
  have hPa := abs_le.1 hPE'
  have hQa := abs_le.1 hQQ'
  have hPb : η / 2 ^ 11 * ‖r‖ ^ 2 ≤ 1 / 2 ^ 31 * ‖r‖ ^ 2 := mul_le_mul_of_nonneg_right hx hE0.le
  have hQb : (8 * ℓ + 1 / 2 ^ 11) * η * ‖y‖ ^ 2 ≤ 1 / 2 ^ 15 * ‖y‖ ^ 2 :=
    mul_le_mul_of_nonneg_right hsmall.le hQ0.le
  obtain ⟨hσlo, hσhi⟩ := sigma_ratio hE0 hQ0 hP hQ (by linarith) (by linarith) (by linarith)
    (by linarith) hρ0.le hρsq hσ0 hσsq
  obtain ⟨t, hat, htlo, hthi, hlo2, hhi2⟩ :=
    teff_bounds hη hρ0 hρlo hρhi hσlo hσhi hs hh hhη
  have hclamp : a = roundGrid hstep (s * (η / 16 * √(P / Qhat))) := by
    rw [ha, min_eq_right hhi2, max_eq_right (by linarith)]
  rw [hclamp]
  have hexp : ‖r - roundGrid hstep (s * (η / 16 * √(P / Qhat))) • y‖ ^ 2 =
      ‖r‖ ^ 2 - 2 * roundGrid hstep (s * (η / 16 * √(P / Qhat))) * inner ℝ r y +
        roundGrid hstep (s * (η / 16 * √(P / Qhat))) ^ 2 * ‖y‖ ^ 2 := by
    rw [norm_sub_sq_real, real_inner_smul_right, norm_smul, mul_pow, Real.norm_eq_abs, sq_abs]
    ring
  have hcon := contraction_core hη hnr hny hs htlo hthi hρy hρ0 hat hlow
  refine ⟨rfl, ⟨t, hat, htlo, hthi⟩, by linarith, by linarith, hexp, by rw [hexp]; exact hcon, ?_⟩
  have : η ^ 2 / 64 * ‖r‖ ^ 2 ≤ 3 * η ^ 2 / 128 * ‖r‖ ^ 2 := by
    have h0 : 0 ≤ η ^ 2 * ‖r‖ ^ 2 := by positivity
    have e : 3 * η ^ 2 / 128 * ‖r‖ ^ 2 - η ^ 2 / 64 * ‖r‖ ^ 2 = 1 / 128 * (η ^ 2 * ‖r‖ ^ 2) := by
      ring
    linarith
  have e2 : (1 - η ^ 2 / 64) * ‖r‖ ^ 2 = ‖r‖ ^ 2 - η ^ 2 / 64 * ‖r‖ ^ 2 := by ring
  have e3 : (1 - 3 * η ^ 2 / 128) * ‖r‖ ^ 2 = ‖r‖ ^ 2 - 3 * η ^ 2 / 128 * ‖r‖ ^ 2 := by ring
  linarith

end RejectSit

end F2e2e.C.Tree
