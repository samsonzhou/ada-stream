import Mathlib
import F2e2e.C.Params

/-!
# Part III §5: basic tools (dyadic rounding, guard amplitudes, guard coordinates)

Source: `parts/partIII.tex` Section 5 (L407–989); `parts/partII.tex` Definitions
`R:def:dyadic-normalization` (L154–164) and `R:def:dyadic-grids` (L196–207).

* `roundGrid h z = h ⌊z/h + 1/2⌋`: nearest-multiple rounding to the grid `hℤ` with half-way ties toward
  `+∞` (partII.tex L155, L197); `|round_h(z) − z| ≤ h/2` (`abs_roundGrid_sub_le`) and, for `z ≥ 2h`,
  the ratio enclosure `4/5 ≤ round_h(z)/z ≤ 6/5` (eq. `R:eq:rounding-relative-2hg`, partIII.tex L636–639;
  `roundGrid_ratio`).
* `guardAmp h Ĉ δ̃`: the Step-3 physical guard of Algorithm `R:alg:within-round-tree` (L489) and of
  eq. `R:eq:committed-guard-amplitude` (partII.tex L190–193): `0` if `Ĉ δ̃ < 2h`, else `round_h(Ĉ δ̃)`.
* Lemma `R:lem:guard-orthogonality` (Lemma 5.6), arithmetic part (partIII.tex L594–599, L615): the guard
  coordinate `g(d,t) = n + H(t−1) + d + 1` (`F2e2e.StreamParams.guardCoord`) satisfies
  `n + 1 ≤ g(d,t) ≤ n + mH < n + T = D_* − 1` and `(d,t) ↦ g(d,t)` is injective on
  `{0..H−1} × {1..m}`; moreover it is strictly increasing in the lexicographic order of `(t, d)`
  (`guardCoord_lt_of_lex`), which is the form of freshness used by the shadow-model invariants.
  The shadow-vector claims (1)–(3) of Lemma 5.6 are proved in `F2e2e/C/Tree/Shadow.lean`.
-/

namespace F2e2e.C.Tree

open F2e2e

/-! ## Dyadic rounding -/

/-- `round_h(z) = h ⌊z/h + 1/2⌋`: rounding to the grid `hℤ`, half-way ties toward `+∞`
(partII.tex L155, L197). -/
noncomputable def roundGrid (h z : ℝ) : ℝ := h * ⌊z / h + 1 / 2⌋

/-- `|round_h(z) − z| ≤ h/2` (partII.tex L197). -/
theorem abs_roundGrid_sub_le {h : ℝ} (hh : 0 < h) (z : ℝ) : |roundGrid h z - z| ≤ h / 2 := by
  unfold roundGrid
  have h1 := Int.floor_le (z / h + 1 / 2)
  have h2 := Int.lt_floor_add_one (z / h + 1 / 2)
  have hz : h * (z / h) = z := by field_simp
  have e : h * (⌊z / h + 1 / 2⌋ : ℝ) - z = h * ((⌊z / h + 1 / 2⌋ : ℝ) - z / h) := by
    rw [mul_sub, hz]
  rw [e, abs_mul, abs_of_pos hh]
  have : |(⌊z / h + 1 / 2⌋ : ℝ) - z / h| ≤ 1 / 2 := by
    rw [abs_le]; constructor <;> linarith
  calc h * |(⌊z / h + 1 / 2⌋ : ℝ) - z / h| ≤ h * (1 / 2) := by gcongr
    _ = h / 2 := by ring

/-- The rounding ratio for `z ≥ 2h` (eq. `R:eq:rounding-relative-2hg`, partIII.tex L636–639):
`(4/5) z ≤ round_h(z) ≤ (6/5) z`. (For `z ∈ [2h, 2.5h)` the rounded value is `2h`; for `z ≥ 2.5h`,
`|round_h(z) − z| ≤ h/2 ≤ z/5`.) -/
theorem roundGrid_ratio {h z : ℝ} (hh : 0 < h) (hz : 2 * h ≤ z) :
    4 / 5 * z ≤ roundGrid h z ∧ roundGrid h z ≤ 6 / 5 * z := by
  rcases lt_or_ge z (5 / 2 * h) with hlt | hge
  · have hk : ⌊z / h + 1 / 2⌋ = 2 := by
      rw [Int.floor_eq_iff]
      have a1 : 2 ≤ z / h := by rw [le_div_iff₀ hh]; linarith
      have a2 : z / h < 5 / 2 := by rw [div_lt_iff₀ hh]; linarith
      push_cast
      constructor <;> linarith
    unfold roundGrid
    rw [hk]
    push_cast
    constructor <;> linarith
  · have := abs_roundGrid_sub_le hh z
    rw [abs_le] at this
    constructor <;> linarith

/-! ## The Step-3 physical guard -/

/-- The physical guard amplitude of Step 3 (Algorithm `R:alg:within-round-tree` L489;
eq. `R:eq:committed-guard-amplitude`, partII.tex L190–193): with tag `Ĉ` and nominal amplitude `δ̃`,
`δ = 0` if `Ĉ δ̃ < 2h`, and `δ = round_h(Ĉ δ̃)` otherwise. -/
noncomputable def guardAmp (h Chat δt : ℝ) : ℝ :=
  if Chat * δt < 2 * h then 0 else roundGrid h (Chat * δt)

/-- If `z ≥ 2h` then `⌊z/h + 1/2⌋ ≥ 2`. -/
theorem two_le_floor {h z : ℝ} (hh : 0 < h) (hz : 2 * h ≤ z) : (2 : ℤ) ≤ ⌊z / h + 1 / 2⌋ := by
  rw [Int.le_floor]
  have a1 : 2 ≤ z / h := by rw [le_div_iff₀ hh]; linarith
  push_cast
  linarith

/-- A non-omitted guard is at least `2h` (in particular positive). -/
theorem two_mul_le_guardAmp {h Chat δt : ℝ} (hh : 0 < h) (hz : 2 * h ≤ Chat * δt) :
    2 * h ≤ guardAmp h Chat δt := by
  unfold guardAmp
  rw [if_neg (not_lt.2 hz)]
  unfold roundGrid
  have hk := two_le_floor hh hz
  have hk' : (2 : ℝ) ≤ (⌊Chat * δt / h + 1 / 2⌋ : ℝ) := by exact_mod_cast hk
  nlinarith

/-- The guard amplitude is nonnegative. -/
theorem guardAmp_nonneg {h Chat δt : ℝ} (hh : 0 < h) : 0 ≤ guardAmp h Chat δt := by
  by_cases hz : Chat * δt < 2 * h
  · unfold guardAmp; rw [if_pos hz]
  · have := two_mul_le_guardAmp (Chat := Chat) (δt := δt) hh (not_lt.1 hz)
    linarith

/-! ## Lemma 5.6 (`R:lem:guard-orthogonality`): the guard coordinates -/

/-- Lemma 5.6, injectivity (partIII.tex L599, L615: Euclidean division of `g(d,t) − n − 1 = H(t−1) + d`
by `H` recovers `t − 1` and `d`). -/
theorem guardCoord_injective (P : StreamParams) {d d' t t' : ℕ} (hd : d < P.H) (hd' : d' < P.H)
    (ht : 1 ≤ t) (ht' : 1 ≤ t') (h : P.guardCoord d t = P.guardCoord d' t') : d = d' ∧ t = t' := by
  unfold StreamParams.guardCoord at h
  have hH : 0 < P.H := by omega
  have e : d + P.H * (t - 1) = d' + P.H * (t' - 1) := by omega
  have h1 : (d + P.H * (t - 1)) % P.H = d := by
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hd]
  have h2 : (d' + P.H * (t' - 1)) % P.H = d' := by
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hd']
  have hdd : d = d' := by rw [← h1, ← h2, e]
  subst hdd
  have e2 : P.H * (t - 1) = P.H * (t' - 1) := by omega
  have := Nat.eq_of_mul_eq_mul_left hH e2
  omega

/-- The guard coordinates are strictly increasing in the lexicographic order of `(t, d)`: the guard
of depth `d` at round `t` is injected before that of `(d', t')` iff `g(d,t) < g(d',t')`. -/
theorem guardCoord_lt_of_lex (P : StreamParams) {d d' t t' : ℕ} (hd : d < P.H) (ht : 1 ≤ t)
    (h : t < t' ∨ (t = t' ∧ d < d')) : P.guardCoord d t < P.guardCoord d' t' := by
  unfold StreamParams.guardCoord
  rcases h with h | ⟨rfl, h⟩
  · have : P.H * (t - 1) + P.H ≤ P.H * (t' - 1) := by
      have : P.H * (t - 1) + P.H = P.H * (t - 1 + 1) := by ring
      rw [this]
      exact Nat.mul_le_mul_left _ (by omega)
    omega
  · omega

/-- Lemma 5.6, range (partIII.tex L599): `n + 1 ≤ g(d,t) ≤ n + mH < n + T = D_* − 1` for
`d ∈ {0..H−1}`, `t ∈ {1..m}`. -/
theorem guardCoord_range (P : StreamParams) {d t : ℕ} (hd : d < P.H) (ht : 1 ≤ t) (htm : t ≤ P.m) :
    P.n + 1 ≤ P.guardCoord d t ∧ P.guardCoord d t ≤ P.n + P.m * P.H ∧
      P.n + P.m * P.H < P.n + P.T ∧ P.n + P.T = P.Dstar - 1 := by
  unfold StreamParams.guardCoord
  refine ⟨by omega, ?_, ?_, ?_⟩
  · have : P.H * (t - 1) + P.H ≤ P.m * P.H := by
      have : P.H * (t - 1) + P.H = P.H * (t - 1 + 1) := by ring
      rw [this, mul_comm P.m]
      exact Nat.mul_le_mul_left _ (by omega)
    omega
  · have : P.m * P.H < P.T := by
      unfold StreamParams.T
      have h1 : P.m * P.H < (P.m + 1) * (P.H + 1) := by nlinarith
      have h2 : (P.m + 1) * (P.H + 1) ≤ (P.m + 1) * (P.H + 1) ^ 3 := by
        apply Nat.mul_le_mul_left
        calc P.H + 1 = (P.H + 1) ^ 1 := by ring
          _ ≤ (P.H + 1) ^ 3 := Nat.pow_le_pow_right (by omega) (by norm_num)
      calc P.m * P.H < (P.m + 1) * (P.H + 1) ^ 3 := by omega
        _ ≤ 2 ^ 12 * (P.m + 1) * (P.H + 1) ^ 3 := by
          rw [mul_assoc]; exact Nat.le_mul_of_pos_left _ (by norm_num)
    omega
  · unfold StreamParams.Dstar; omega

/-- Physical coordinates (`1..n`) are never guard coordinates. -/
theorem lt_guardCoord (P : StreamParams) {i d t : ℕ} (hi : i ≤ P.n) : i < P.guardCoord d t := by
  unfold StreamParams.guardCoord; omega

end F2e2e.C.Tree
