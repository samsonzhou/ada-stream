import Mathlib
import F2e2e.C.Tree.InvExports
import F2e2e.C.Tree.InvLemmas
import F2e2e.C.Tree.Rescale
import F2e2e.C.Tree.CorrectAux

/-!
# Part III §5: the step lemmas of the tree invariant

Source: `parts/partIII.tex` Section 5 (L407–989) and Theorem `R:thm:chronological-closure-and-main-proof`
(L1287–1307). The invariant `TreeInv` and its ingredients are defined in `F2e2e/C/Tree/InvDefs.lean` (see the
docstring there); this file states and proves one preservation lemma per event of
`F2e2e/C/Tree/Event.lean` (`treeInv_*`). The facts exported to Sections 4 and 6 are in
`F2e2e/C/Tree/InvExports.lean`; the analytic ingredients of the correction step (Theorem 5.9 (3)–(4),
Theorem 5.11 (1), (2c)) are in `F2e2e/C/Tree/CorrectAux.lean`.
-/

namespace F2e2e.C.Tree

open F2e2e

/-! ## Helper lemmas -/

section Helpers

variable {P : StreamParams}

theorem guardCoord_mono_d (P : StreamParams) {d d' : ℕ} (h : d ≤ d') (t : ℕ) :
    P.guardCoord d t ≤ P.guardCoord d' t := by
  unfold StreamParams.guardCoord; omega

theorem guardCoord_zero_succ (P : StreamParams) {t : ℕ} (ht : 1 ≤ t) :
    P.guardCoord 0 (t + 1) = P.guardCoord P.H t := by
  unfold StreamParams.guardCoord
  have : P.H * (t + 1 - 1) = P.H * (t - 1) + P.H := by
    rw [show t + 1 - 1 = (t - 1) + 1 by omega, mul_add, mul_one]
  omega

theorem log_t_le {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) : ∀ e ∈ S.log d, e.t ≤ S.t := fun e he => (h.log_t d hd e he).2.1

/-- The log of the evaluated depth after an `accept`. -/
theorem log_accept_eq {S : TreeSt P} {d : ℕ} {e : LogEntry} {l' : List LogEntry} (hl : S.log d = e :: l') :
    (S.step P (.accept d)).log d = { e with out := .accepted } :: l' := by
  rw [step_accept_log, Function.update_self, hl]; rfl

theorem log_accept_ne {S : TreeSt P} {d d' : ℕ} (h : d' ≠ d) :
    (S.step P (.accept d)).log d' = S.log d' := by
  rw [step_accept_log, Function.update_of_ne h]

theorem guardIdx_add_one (P : StreamParams) (i t : ℕ) : guardIdx P i t + 1 = P.guardCoord i t := by
  unfold guardIdx StreamParams.guardCoord; omega

/-- Guard indices of different depths never coincide. -/
theorem guardIdx_ne_of_ne (P : StreamParams) {i d t t' : ℕ} (hi : i < P.H) (hd : d < P.H)
    (ht : 1 ≤ t) (hid : i ≠ d) : guardIdx P i t' ≠ guardIdx P d t := by
  intro h
  have h1 : P.guardCoord i (max t' 1) = P.guardCoord d t := by
    have e1 := guardIdx_add_one P i t'
    have e2 := guardIdx_add_one P d t
    have e3 : P.guardCoord i (max t' 1) = P.guardCoord i t' := by
      unfold StreamParams.guardCoord
      rcases Nat.eq_zero_or_pos t' with h0 | h0
      · subst h0; simp
      · rw [max_eq_left h0]
    omega
  exact hid (guardCoord_injective P hi hd (le_max_right _ _) ht h1).1

/-- Guard indices of one depth at different rounds never coincide. -/
theorem guardIdx_ne_of_lt (P : StreamParams) {d t t' : ℕ} (hd : d < P.H) (ht' : 1 ≤ t')
    (htt : t' < t) : guardIdx P d t' ≠ guardIdx P d t := by
  intro h
  have := guardCoord_lt_of_lex P hd ht' (Or.inl htt) (d' := d)
  have e1 := guardIdx_add_one P d t'
  have e2 := guardIdx_add_one P d t
  omega

theorem x_birth_le (S : TreeSt P) {d d' : ℕ} (h : d' ≤ d) : (S.step P (.birth d)).x d' = S.x d' := by
  unfold TreeState.x
  rw [step_birth_x0]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [step_birth_r, Function.update_of_ne]
  have := Finset.mem_range.1 hj; omega

theorem tree_K0_pos (P : StreamParams) : 0 < P.K0 := by unfold StreamParams.K0; positivity

theorem smul_unitVec_eq_single {N : ℕ} (g : Fin N) (δ : ℝ) :
    δ • unitVec g = EuclideanSpace.single g δ := by
  ext i
  simp only [unitVec, PiLp.smul_apply, PiLp.single_apply, smul_eq_mul]
  split_ifs <;> simp

theorem env_succ (P : StreamParams) (d k : ℕ) : env P d (k + 1) = env P d k / 2 := by
  unfold env; rw [pow_succ, div_div]

theorem env_anti (P : StreamParams) (d : ℕ) {k k' : ℕ} (hk : k ≤ k') : env P d k' ≤ env P d k := by
  unfold env
  exact div_le_div_of_nonneg_left (Nat.cast_nonneg _) (by positivity) (pow_le_pow_right₀ (by norm_num) hk)

theorem env_pos (P : StreamParams) (d k : ℕ) : 0 < env P d k := by
  unfold env
  have : 0 < P.Ud d := by unfold StreamParams.Ud; positivity
  exact div_pos (by exact_mod_cast this) (by positivity)

theorem rho_bounds (P : StreamParams) :
    (0 : ℝ) ≤ 1 - (P.eta : ℝ) ^ 2 / 64 ∧ 1 - (P.eta : ℝ) ^ 2 / 64 ≤ 1 := by
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  constructor <;> nlinarith

theorem log_length_le_T {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) : (S.log d).length ≤ P.T := by
  have h1 := length_le_of_sorted (S.log d) S.t (h.log_sorted d hd) (fun e he => by
    obtain ⟨a1, a2, -⟩ := h.log_t d hd e he
    obtain ⟨b1, -⟩ := h.tb_le d hd
    omega)
  have := h.round_le
  have := P.m_lt_T
  omega

/-- Lemma 5.10 (b): `Ẽ_d ≤ (33/64)𝒰_{d,k_d} < 𝒰_{d,k_d}` for every live depth. -/
theorem Et_le_env {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) :
    S.Et d ≤ 33 / 64 * env P d (R.k d) ∧ 33 / 64 * env P d (R.k d) < env P d (R.k d) := by
  obtain ⟨ng, hng, hEB⟩ := h.epoch d hd
  obtain ⟨hρ0, hρ1⟩ := rho_bounds P
  obtain ⟨hc1, hc2, hc3⟩ :=
    hEB.ceiling hρ0 hρ1 (env_pos P d _) (hng.trans (log_length_le_T h hd)) (T_gamma_sq_le P).1
  exact ⟨hc1.trans hc2, hc3⟩

theorem prod_range_mul_at {f g : ℕ → ℝ} {j d : ℕ} {c : ℝ} (hdj : d < j) (hd : f d = c * g d)
    (hf : ∀ i, i ≠ d → f i = g i) : ∏ i ∈ Finset.range j, f i = c * ∏ i ∈ Finset.range j, g i := by
  rw [← Finset.mul_prod_erase _ f (Finset.mem_range.2 hdj),
    ← Finset.mul_prod_erase _ g (Finset.mem_range.2 hdj), hd,
    Finset.prod_congr rfl (fun i hi => hf i (Finset.ne_of_mem_erase hi))]
  ring

theorem coordAt_x_zero (S : TreeSt P) {D l : ℕ} (h0 : coordAt S.x0 l = 0)
    (hr : ∀ i < D, coordAt (S.r i) l = 0) : coordAt (S.x D) l = 0 := by
  unfold TreeState.x
  rw [coordAt_sub, h0, coordAt_sum, Finset.sum_eq_zero (fun i hi => hr i (Finset.mem_range.1 hi))]
  simp

theorem log_correct_eq {S : TreeSt P} {d : ℕ} {e : LogEntry} {l' : List LogEntry}
    (hl : S.log d = e :: l') (c : ℝ) :
    (S.step P (.correct d c)).log d = { e with out := .corrected c } :: l' := by
  rw [step_correct_log, Function.update_self, hl]; rfl

theorem log_correct_ne {S : TreeSt P} {d d' : ℕ} (c : ℝ) (h : d' ≠ d) :
    (S.step P (.correct d c)).log d' = S.log d' := by
  rw [step_correct_log, Function.update_of_ne h]

theorem intervalProd_correct_head (e : LogEntry) (l : List LogEntry) (hp : e.out = .pending) (c : ℝ)
    (a b : ℕ) :
    intervalProd ({ e with out := .corrected c } :: l) a b =
      (if a ≤ e.t ∧ e.t ≤ b then c else 1) * intervalProd (e :: l) a b := by
  rw [intervalProd_cons, intervalProd_cons, hp]
  simp only [Outcome.mult]
  split_ifs <;> ring

/-- The guard coordinate identity of the corrected depth after its correction (Lemma 5.4 (i), Lemma 5.6 (2):
`x_d` vanishes on the own guard coordinates, so `y_{d,g} = −r_{d,g}` and `r_{d,g}⁺ = c r_{d,g}`, while the
current-round record's multiplier becomes `c`). -/
theorem correct_coord_d {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (c : ℝ) {e0 : LogEntry} {l' : List LogEntry} (hl : S.log d = e0 :: l')
    (hep : e0.out = .pending) (het : e0.t = S.t) :
    ∀ x ∈ (S.step P (.correct d c)).log d,
      coordAt ((S.step P (.correct d c)).r d) x.g * x.C =
        -x.δ * intervalProd ((S.step P (.correct d c)).log d) x.t S.t * S.C d := by
  intro x hx
  rw [log_correct_eq hl c] at hx ⊢
  obtain ⟨e, he, het', heg, heδ, heC⟩ :
      ∃ e ∈ S.log d, e.t = x.t ∧ e.g = x.g ∧ e.δ = x.δ ∧ e.C = x.C := by
    rcases List.mem_cons.1 hx with rfl | hx'
    · exact ⟨e0, by rw [hl]; exact List.mem_cons_self, rfl, rfl, rfl, rfl⟩
    · exact ⟨x, by rw [hl]; exact List.mem_cons_of_mem _ hx', rfl, rfl, rfl, rfl⟩
  have hlt := h.log_t d hd e he
  have hco := h.coord d hd e he
  have hxg : coordAt (S.x d) e.g = 0 := by
    rw [hlt.2.2]
    apply coordAt_x_zero S (h.x0_phys _ (guardIdx_ge P d e.t))
    intro i hi
    exact h.r_supp i (by show i < P.H; omega) d e.t hi hd
  have hyg : coordAt (S.y d) e.g = -coordAt (S.r d) e.g := by
    have : S.y d = S.x d - S.r d := TreeState.x_succ S d
    rw [this, coordAt_sub, hxg]; ring
  have hr' : coordAt ((S.step P (.correct d c)).r d) e.g = c * coordAt (S.r d) e.g := by
    rw [TreeState.step_correct_r, if_pos rfl, coordAt_sub, coordAt_smul, hyg]; ring
  have hip : intervalProd ({ e0 with out := .corrected c } :: l') e.t S.t =
      c * intervalProd (S.log d) e.t S.t := by
    rw [intervalProd_correct_head e0 l' hep c, hl, if_pos ⟨by rw [het]; exact hlt.2.1, le_of_eq het⟩]
  rw [← heg, ← heC, ← heδ, ← het', hr', hip]
  calc c * coordAt (S.r d) e.g * e.C = c * (coordAt (S.r d) e.g * e.C) := by ring
    _ = c * (-e.δ * intervalProd (S.log d) e.t S.t * S.C d) := by rw [hco]
    _ = -e.δ * (c * intervalProd (S.log d) e.t S.t) * S.C d := by ring

/-- The epoch bound of the corrected depth after its correction (Lemma 5.10: contraction, and the epoch
transition at the `K₀`-th correction). -/
theorem correct_epoch_d {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) {c : ℝ}
    (hcontr : ‖S.r d - (c - 1) • S.y d‖ ^ 2 ≤ (1 - (P.eta : ℝ) ^ 2 / 64) * S.E d)
    (hRd : (R.jE d + 1 = P.K0 ∧ R'.k d = R.k d + 1 ∧ R'.jE d = 0) ∨
        (R.jE d + 1 ≠ P.K0 ∧ R'.k d = R.k d ∧ R'.jE d = R.jE d + 1)) :
    ∃ ng ≤ ((S.step P (.correct d c)).log d).length,
      EpochBound (1 - (P.eta : ℝ) ^ 2 / 64) P.gamma (env P d (R'.k d))
        ((S.step P (.correct d c)).Et d) (R'.jE d) ng := by
  obtain ⟨ng, hng, hb⟩ := h.epoch d hd
  have hη0 : (0 : ℝ) < P.eta := by exact_mod_cast P.eta_pos
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  obtain ⟨hρ0, hρ1⟩ := rho_bounds P
  have hU := env_pos P d (R.k d)
  have hlen : ((S.step P (.correct d c)).log d).length = (S.log d).length := by
    rw [step_correct_log, Function.update_self]
    cases S.log d <;> rfl
  have hEt' : (S.step P (.correct d c)).Et d ≤ (1 - (P.eta : ℝ) ^ 2 / 64) * S.Et d := by
    unfold TreeState.Et TreeState.E
    rw [TreeState.step_correct_r, if_pos rfl, TreeState.step_correct_C, if_neg (lt_irrefl d)]
    exact normalized_energy_contract hcontr
  have hb' := EpochBound.contract hb hρ0 hρ1 hU.le hEt'
  rcases hRd with ⟨hK, hk', hj'⟩ | ⟨hK, hk', hj'⟩
  · rw [hK] at hb'
    have hlenT : ng ≤ P.T := hng.trans (log_length_le_T h hd)
    have hK0 : 128 / (P.eta : ℝ) ^ 2 ≤ (P.K0 : ℝ) := (K0_eq P).symm.le
    obtain ⟨-, -, hnew⟩ := EpochBound.transition hb' hη0 hη1 hK0 hU hlenT (T_gamma_sq_le P).1
    refine ⟨0, Nat.zero_le _, ?_⟩
    rw [hk', hj', env_succ]
    exact hnew
  · refine ⟨ng, by rw [hlen]; exact hng, ?_⟩
    rw [hk', hj']
    exact hb'

/-- The root envelope floor after a correction (Lemma 5.8 (i)). -/
theorem correct_root_env {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) (hEx : (P.eta : ℝ) ^ 2 / 32 * ‖S.x d‖ ^ 2 ≤ S.E d)
    (hRlt : ∀ j < d, R'.k j = R.k j) (hRd : R'.k d = R.k d + 1 ∨ R'.k d = R.k d) :
    (P.eta : ℝ) ^ 2 / 64 ≤ env P 0 (R'.k 0) := by
  have hH : 0 < Phase.live P.H (.evals (d + 1)) := by show 0 < P.H; omega
  have hroot := h.root_env hH
  rcases Nat.eq_zero_or_pos d with hd0 | hd0
  · subst hd0
    rcases hRd with hk | hk
    · rw [hk, env_succ]
      have hC0 : S.C 0 = 1 := by rw [h.C_prod 0 hH]; simp
      have hx : S.x 0 = S.x0 := by simp [TreeState.x]
      have hE1 : (P.eta : ℝ) ^ 2 / 32 ≤ S.E 0 := by
        rw [hx] at hEx
        have h1 : 1 ≤ ‖S.x0‖ ^ 2 := by nlinarith
        have h2 : (0 : ℝ) ≤ (P.eta : ℝ) ^ 2 / 32 := by positivity
        have h3 : (P.eta : ℝ) ^ 2 / 32 * 1 ≤ (P.eta : ℝ) ^ 2 / 32 * ‖S.x0‖ ^ 2 :=
          mul_le_mul_of_nonneg_left h1 h2
        linarith
      have hEU : S.E 0 ≤ env P 0 (R.k 0) := by
        obtain ⟨h1, h2⟩ := Et_le_env h hH
        unfold TreeState.Et at h1
        rw [hC0, one_pow, div_one] at h1
        linarith
      linarith
    · rw [hk]; exact hroot
  · rw [hRlt 0 hd0]; exact hroot

/-- The counters of the corrected depth after the update of L509. -/
theorem correct_counters_d {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hmargin : R.k d + 13 ≤ P.Kepoch)
    (hRd : R'.jU d = R.jU d + 1 ∧
      ((R.jE d + 1 = P.K0 ∧ R'.k d = R.k d + 1 ∧ R'.jE d = 0) ∨
        (R.jE d + 1 ≠ P.K0 ∧ R'.k d = R.k d ∧ R'.jE d = R.jE d + 1))) :
    R'.jU d = P.K0 * R'.k d + R'.jE d ∧ R'.jE d < P.K0 ∧ R'.k d + 12 ≤ P.Kepoch := by
  obtain ⟨hJ, hJE, hk⟩ := h.counters d hd
  obtain ⟨hU, ⟨hK, hk', hj'⟩ | ⟨hK, hk', hj'⟩⟩ := hRd
  · have hm : P.K0 * (R.k d + 1) = P.K0 * R.k d + P.K0 := Nat.mul_succ _ _
    rw [hU, hk', hj']
    exact ⟨by omega, tree_K0_pos P, by omega⟩
  · rw [hU, hk', hj']
    exact ⟨by omega, by omega, hk⟩

end Helpers

/-! ## Step lemmas (one per event) -/

section Steps

variable {P : StreamParams}

/-- Initialization: after the `newRound` of round `1` no learner is live yet. -/
theorem treeInv_init (hm : 1 ≤ P.m) (R : Regs) :
    TreeInv P (.births 0) R ((TreeState.init P.Dstar).step P .newRound) := by
  have hH := P.one_le_H
  exact
    { round_pos := le_refl _
      round_le := hm
      live_le := Nat.zero_le _
      x0_phys := fun j _ => coordAt_zero j
      r_supp := fun j hj => absurd hj (Nat.not_lt_zero _)
      fresh := fun j hj => absurd hj (Nat.not_lt_zero _)
      tb_le := fun j hj => absurd hj (Nat.not_lt_zero _)
      tb_mono := fun j d _ hd => absurd hd (Nat.not_lt_zero _)
      log_t := fun j hj => absurd hj (Nat.not_lt_zero _)
      log_sorted := fun j hj => absurd hj (Nat.not_lt_zero _)
      log_phase := fun j hj => absurd hj (Nat.not_lt_zero _)
      C_pos := fun j hj => absurd hj (Nat.not_lt_zero _)
      C_prod := fun j hj => absurd hj (Nat.not_lt_zero _)
      mult_mem := fun j hj => absurd hj (Nat.not_lt_zero _)
      prod_le := fun j hj => absurd hj (Nat.not_lt_zero _)
      coord := fun j hj => absurd hj (Nat.not_lt_zero _)
      entry_C_pos := fun j hj => absurd hj (Nat.not_lt_zero _)
      entry_δ_nonneg := fun j hj => absurd hj (Nat.not_lt_zero _)
      nonomit := fun j hj => absurd hj (Nat.not_lt_zero _)
      epoch := fun j hj => absurd hj (Nat.not_lt_zero _)
      root_env := fun h => absurd h (lt_irrefl 0)
      counters := fun j hj => absurd hj (Nat.not_lt_zero _)
      pending := fun j hj => absurd hj (Nat.not_lt_zero _)
      cur_fresh := trivial
      leaf := ⟨rfl, fun h => absurd h (by omega)⟩ }

/-- A new round (Step 1, L472–473): from the end of round `t < m`, after `newRound` and the retirement of the
expiring suffix `d ≥ d₀` (`d₀ < H`: depth `H − 1` is reborn every round), the invariant holds for the retained
depths `< d₀`, whose registers are unchanged. -/
theorem treeInv_newRound {R R' : Regs} {S : TreeSt P} (h : TreeInv P .idle R S) (ht : S.t < P.m)
    {d0 : ℕ} (hd0 : d0 < P.H)
    (hR : ∀ d < d0, R'.Chat d = R.Chat d ∧ R'.k d = R.k d ∧ R'.jE d = R.jE d ∧ R'.jU d = R.jU d) :
    TreeInv P (.births d0) R' (S.step P .newRound) := by
  have hlive : ∀ d, d < d0 → d < Phase.live P.H .idle := fun d hd => by
    show d < P.H; omega
  have hlt : ∀ d, d < d0 → ∀ e ∈ S.log d, e.t ≤ S.t := fun d hd => log_t_le h (hlive d hd)
  have ht1 := h.round_pos
  exact
    { round_pos := by simp
      round_le := by simp; omega
      live_le := hd0.le
      x0_phys := h.x0_phys
      r_supp := fun j hj => h.r_supp j (hlive j hj)
      fresh := fun j hj l hl => by
        apply h.fresh j (hlive j hj) l
        show P.guardCoord P.H S.t ≤ l + 1
        have := guardCoord_zero_succ P ht1
        simp only [Phase.nextG, step_newRound_t] at hl
        omega
      tb_le := fun d hd => by
        obtain ⟨h1, h2⟩ := h.tb_le d (hlive d hd); simp; omega
      tb_mono := fun j d hjd hd => h.tb_mono j d hjd (hlive d hd)
      log_t := fun d hd e he => by
        obtain ⟨h1, h2, h3⟩ := h.log_t d (hlive d hd) e he; simp; omega
      log_sorted := fun d hd => h.log_sorted d (hlive d hd)
      log_phase := fun d hd e he => by
        simp only [step_newRound_log, step_newRound_t] at he ⊢
        exact ⟨by have := hlt d hd e he; omega, h.log_phase d (hlive d hd) e he⟩
      C_pos := fun d hd => h.C_pos d (hlive d hd)
      C_prod := fun d hd => by
        simp only [step_newRound_C, step_newRound_log, step_newRound_tb, step_newRound_t]
        rw [h.C_prod d (hlive d hd)]
        apply Finset.prod_congr rfl
        intro j hj
        have hjd : j < d0 := lt_trans (Finset.mem_range.1 hj) hd
        exact (intervalProd_of_le _ _ _ _ (Nat.le_succ _) (hlt j hjd)).symm
      mult_mem := fun d hd => h.mult_mem d (hlive d hd)
      prod_le := fun d hd => h.prod_le d (hlive d hd)
      coord := fun d hd e he => by
        simp only [step_newRound_C, step_newRound_log, step_newRound_r, step_newRound_t] at he ⊢
        rw [h.coord d (hlive d hd) e he, intervalProd_of_le _ _ _ _ (Nat.le_succ _) (hlt d hd)]
      entry_C_pos := fun d hd => h.entry_C_pos d (hlive d hd)
      entry_δ_nonneg := fun d hd => h.entry_δ_nonneg d (hlive d hd)
      nonomit := fun d hd e he c hc => by
        rw [(hR d hd).2.1]; exact h.nonomit d (hlive d hd) e he c hc
      epoch := fun d hd => by
        rw [(hR d hd).2.1, (hR d hd).2.2.1]; exact h.epoch d (hlive d hd)
      root_env := fun h0 => by
        rw [(hR 0 h0).2.1]; exact h.root_env (by show 0 < P.H; omega)
      counters := fun d hd => by
        rw [(hR d hd).2.1, (hR d hd).2.2.1, (hR d hd).2.2.2]; exact h.counters d (hlive d hd)
      pending := fun d hd e he hp => by
        simp only [step_newRound_log] at he
        exact absurd hp (h.log_phase d (hlive d hd) e (List.mem_of_mem_head? he))
      cur_fresh := trivial
      leaf := ⟨rfl, fun hh => absurd hh (by omega)⟩ }

/-- Step 1, birth of depth `d` (L474–477): `r_d := x_d`, `C_d := 1`, empty log; the new learner's registers are
`Ĉ_d = 1`, `k_d = j_epoch = J_used = 0`. The box promise for the current physical vector (before this round's
update) gives `‖x_0‖ ≤ W`, hence `‖x_d‖ ≤ V_d` (Theorem 5.11 (2b)) and the epoch start bound
`Ẽ_d = ‖x_d‖² ≤ V_d² ≤ 𝒰_{d,0}/2` (Lemma 5.10 (a), L881–885). -/
theorem treeInv_birth {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.births d) R S) (hd : d < P.H)
    (hn : 1 ≤ P.n) (hU : 1 ≤ P.U) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hR : ∀ j < d, R'.Chat j = R.Chat j ∧ R'.k j = R.k j ∧ R'.jE j = R.jE j ∧ R'.jU j = R.jU j)
    (hRd : R'.Chat d = 1 ∧ R'.k d = 0 ∧ R'.jE d = 0 ∧ R'.jU d = 0) :
    TreeInv P (.births (d + 1)) R' (S.step P (.birth d)) := by
  have hlive : ∀ j, j < d → j < Phase.live P.H (.births d) := fun j hj => hj
  have hS' : ∀ j, j < d → (S.step P (.birth d)).r j = S.r j := fun j hj => by
    rw [step_birth_r, Function.update_of_ne (by omega)]
  have hC' : ∀ j, j < d → (S.step P (.birth d)).C j = S.C j := fun j hj => by
    rw [step_birth_C, Function.update_of_ne (by omega)]
  have htb' : ∀ j, j < d → (S.step P (.birth d)).tb j = S.tb j := fun j hj => by
    rw [step_birth_tb, Function.update_of_ne (by omega)]
  have hlog' : ∀ j, j < d → (S.step P (.birth d)).log j = S.log j := fun j hj => by
    rw [step_birth_log, Function.update_of_ne (by omega)]
  have hrd : (S.step P (.birth d)).r d = S.x d := by rw [step_birth_r, Function.update_self]
  have hCd : (S.step P (.birth d)).C d = 1 := by rw [step_birth_C, Function.update_self]
  have htbd : (S.step P (.birth d)).tb d = S.t := by rw [step_birth_tb, Function.update_self]
  have hlogd : (S.step P (.birth d)).log d = [] := by rw [step_birth_log, Function.update_self]
  have hlt1 : ∀ j, j < d + 1 → j < d ∨ j = d := fun j hj => by omega
  -- the new residual `x_d` vanishes on guard coordinates and from the next guard on
  have hxd_coord : ∀ l, P.n ≤ l → (∀ j < d, coordAt (S.r j) l = 0) → coordAt (S.x d) l = 0 := by
    intro l hl hr
    unfold TreeState.x
    rw [coordAt_sub, h.x0_phys l hl, coordAt_sum, Finset.sum_eq_zero (fun j hj => hr j (Finset.mem_range.1 hj))]
    simp
  have hxd_norm : ‖S.x d‖ ≤ (P.Vd d : ℝ) := (vector_bounds_inv h hbox).1 d (le_refl _)
  have hround := h.round_pos
  exact
    { round_pos := h.round_pos
      round_le := h.round_le
      live_le := hd
      x0_phys := h.x0_phys
      r_supp := fun j hj i t' hji hi => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hS' j hj']; exact h.r_supp j hj' i t' hji hi
        · rw [hrd]
          exact hxd_coord _ (guardIdx_ge P i t') (fun j' hj' => h.r_supp j' hj' i t' (by omega) hi)
      fresh := fun j hj l hl => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hS' j hj']; exact h.fresh j hj' l hl
        · rw [hrd]
          have hl' : P.n ≤ l := by
            simp only [Phase.nextG, step_birth_t] at hl
            unfold StreamParams.guardCoord at hl; omega
          exact hxd_coord l hl' (fun j' hj' => h.fresh j' hj' l hl)
      tb_le := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [htb' j hj']; exact h.tb_le j hj'
        · rw [htbd]; exact ⟨hround, le_refl _⟩
      tb_mono := fun j d' hjd hd' => by
        rcases hlt1 d' hd' with hd'' | rfl
        · rw [htb' j (by omega), htb' d' hd'']; exact h.tb_mono j d' hjd hd''
        · rw [htb' j hjd, htbd]; exact (h.tb_le j hjd).2
      log_t := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; rw [htb' j hj']; exact h.log_t j hj' e he
        · rw [hlogd] at he; simp at he
      log_sorted := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj']; exact h.log_sorted j hj'
        · rw [hlogd]; exact List.Pairwise.nil
      log_phase := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; exact h.log_phase j hj' e he
        · rw [hlogd] at he; simp at he
      C_pos := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hC' j hj']; exact h.C_pos j hj'
        · rw [hCd]; exact one_pos
      C_prod := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hC' j hj', h.C_prod j hj', htb' j hj']
          apply Finset.prod_congr rfl
          intro i hi
          rw [hlog' i (by have := Finset.mem_range.1 hi; omega)]
          rfl
        · rw [hCd, htbd]
          symm
          apply Finset.prod_eq_one
          intro i hi
          have hi' := Finset.mem_range.1 hi
          rw [hlog' i hi']
          apply intervalProd_eq_one
          intro e he
          have := (h.log_phase i hi' e he).1
          simp only [step_birth_t]; omega
      mult_mem := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; exact h.mult_mem j hj' e he
        · rw [hlogd] at he; simp at he
      prod_le := fun j hj t1 t2 => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj']; exact h.prod_le j hj' t1 t2
        · rw [hlogd, intervalProd_nil]; exact one_le_Bbar P
      coord := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he ⊢; rw [hS' j hj', hC' j hj']; exact h.coord j hj' e he
        · rw [hlogd] at he; simp at he
      entry_C_pos := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; exact h.entry_C_pos j hj' e he
        · rw [hlogd] at he; simp at he
      entry_δ_nonneg := fun j hj e he => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; exact h.entry_δ_nonneg j hj' e he
        · rw [hlogd] at he; simp at he
      nonomit := fun j hj e he c hc => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he; rw [(hR j hj').2.1]; exact h.nonomit j hj' e he c hc
        · rw [hlogd] at he; simp at he
      epoch := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [(hR j hj').2.1, (hR j hj').2.2.1, hlog' j hj']
          have he := h.epoch j hj'
          unfold TreeState.Et TreeState.E at he ⊢
          rw [hS' j hj', hC' j hj']; exact he
        · refine ⟨0, Nat.zero_le _, ?_⟩
          rw [hRd.2.1, hRd.2.2.1]
          apply EpochBound.start
          unfold TreeState.Et TreeState.E
          rw [hrd, hCd, one_pow, div_one]
          have h1 := pow_le_pow_left₀ (norm_nonneg _) hxd_norm 2
          have h2 := (Vd_sq_le_half_Ud P j).1
          unfold env; simp only [pow_zero, div_one]
          linarith
      root_env := fun h0 => by
        by_cases hd0 : d = 0
        · subst hd0
          rw [hRd.2.1]
          unfold env; simp only [pow_zero, div_one]
          apply root_envelope_init
          · rw [abs_of_pos (by exact_mod_cast P.eta_pos)]; exact_mod_cast P.eta_le_one
          · exact eight_le_Ud_zero P hn hU
        · rw [(hR 0 (by omega)).2.1]; exact h.root_env (by show 0 < d; omega)
      counters := fun j hj => by
        rcases hlt1 j hj with hj' | rfl
        · rw [(hR j hj').2.1, (hR j hj').2.2.1, (hR j hj').2.2.2]; exact h.counters j hj'
        · rw [hRd.2.1, hRd.2.2.1, hRd.2.2.2]
          refine ⟨by simp, tree_K0_pos P, ?_⟩
          unfold StreamParams.Kepoch; omega
      pending := fun j hj e he hp => by
        rcases hlt1 j hj with hj' | rfl
        · rw [hlog' j hj'] at he
          exact absurd hp (h.log_phase j hj' e (List.mem_of_mem_head? he)).2
        · rw [hlogd] at he; simp at he
      cur_fresh := trivial
      leaf := by
        refine ⟨h.leaf.1, fun hH => ?_⟩
        have e1 : (S.step P (.birth d)).x (d + 1) = (S.step P (.birth d)).x d - (S.step P (.birth d)).r d :=
          TreeState.x_succ _ d
        rw [← hH, e1, x_birth_le S (le_refl d), hrd, sub_self] }

/-- Step 2 (L480–483): the physical update. -/
theorem treeInv_phys {R : Regs} {S : TreeSt P} (h : TreeInv P (.births P.H) R S) (i : Fin P.n) (Δ : ℤ) :
    TreeInv P (.guards 0) R (S.step P (.phys i Δ)) := by
  have hcu : ∀ j, P.n ≤ j → coordAt ((Δ : ℝ) • unitVec (physIdx P i)) j = 0 := by
    intro j hj
    rw [coordAt_smul, coordAt_unitVec, if_neg]
    · simp
    · intro h'; simp [physIdx] at h'; have := i.isLt; omega
  exact
    { h with
      x0_phys := fun j hj => by
        rw [TreeState.step_phys_x0, coordAt_add, h.x0_phys j hj, hcu j hj, add_zero]
      log_phase := fun d hd => ⟨fun h' => absurd h' (Nat.not_lt_zero _), fun _ => h.log_phase d hd⟩
      cur_fresh := fun j hj i hi _ => by
        show coordAt (S.r j) (guardIdx P i S.t) = 0
        apply h.fresh j hj
        show P.guardCoord 0 S.t ≤ guardIdx P i S.t + 1
        unfold guardIdx StreamParams.guardCoord; omega
      leaf := by
        refine ⟨fun j hj => by rw [TreeState.step_phys_upd]; exact hcu j hj, ?_⟩
        simp only [Finset.range_zero, Finset.sum_empty, add_zero]
        rw [(TreeState.x_phys P S i Δ P.H).1, (h.leaf.2 rfl), zero_add, TreeState.step_phys_upd] }

/-- The zero-round bypass (L484: on `F_zero = 0` Steps 3 and 4 are omitted). -/
theorem treeInv_bypass {R : Regs} {S : TreeSt P} (h : TreeInv P (.guards 0) R S) :
    TreeInv P .idle R S :=
  { h with
    fresh := fun j hj l hl => h.fresh j hj l (le_trans (guardCoord_mono_d P (Nat.zero_le _) _) hl)
    log_phase := fun d hd e he => ((h.log_phase d hd).2 (Nat.zero_le d) e he).2
    cur_fresh := trivial
    leaf := trivial }

/-- Step 3 at depth `d` (L488–491; Lemma 5.6, Lemma 5.7, Lemma 5.4 (iii)(c)): the guard
`δ = guardAmp h_g Ĉ_d δ̃_d` (`δ̃_d = (γ/4)√𝒰_{d,k_d}`) on the coordinate `g(d,t)`, under the tag precision
`|Ĉ_d − C_d| ≤ e_C` (Lemma 6.1 (ii) at this moment). Also: `E_d` increases by exactly `δ²` (used by Lemma 6.2)
and `(δ/C_d)² ≤ γ²𝒰_{d,k_d}` (Lemma 5.7 (2)). -/
theorem treeInv_guard {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.guards d) R S) (hd : d < P.H)
    (g : Fin P.Dstar) (hg : g.val = guardIdx P d S.t) (δ : ℝ)
    (hδ : δ = guardAmp P.hg (R.Chat d) (nomGuard P d (R.k d))) (htag : |R.Chat d - S.C d| ≤ (P.eC : ℝ)) :
    TreeInv P (.guards (d + 1)) R (S.step P (.guard d g δ)) ∧
      (S.step P (.guard d g δ)).E d = S.E d + δ ^ 2 ∧
      (δ / S.C d) ^ 2 ≤ (P.gamma : ℝ) ^ 2 * env P d (R.k d) := by
  have ht1 := h.round_pos
  have hlive : d < Phase.live P.H (.guards d) := hd
  -- freshness of `g`
  have hfreshg : ∀ j < P.H, coordAt (S.r j) g.val = 0 := fun j hj => by
    apply h.fresh j hj
    show P.guardCoord d S.t ≤ g.val + 1
    rw [hg, guardIdx_add_one]
  have hrg : (S.r d) g = 0 := by
    have := hfreshg d hd; unfold coordAt at this; rw [dif_pos g.isLt] at this; exact this
  -- the new state
  set S' := S.step P (.guard d g δ) with hS'
  have hr' : ∀ j, S'.r j = if j = d then S.r d - δ • unitVec g else S.r j := fun j => by
    rw [hS', TreeState.step_guard_r]
    by_cases hj : j = d
    · subst hj; rw [Function.update_self, if_pos rfl]
    · rw [Function.update_of_ne hj, if_neg hj]
  have hrd : S'.r d = S.r d - δ • unitVec g := by rw [hr', if_pos rfl]
  have hrj : ∀ j, j ≠ d → S'.r j = S.r j := fun j hj => by rw [hr', if_neg hj]
  have hSt : S'.t = S.t := rfl
  have hSC : ∀ j, S'.C j = S.C j := fun j => rfl
  set e0 : LogEntry := ⟨S.t, g.val, δ, S.C d, .pending⟩ with he0
  have hlogd : S'.log d = e0 :: S.log d := by rw [hS', step_guard_log, Function.update_self]
  have hlogj : ∀ j, j ≠ d → S'.log j = S.log j := fun j hj => by
    rw [hS', step_guard_log, Function.update_of_ne hj]
  have hold : ∀ e ∈ S.log d, e.t < S.t ∧ e.out ≠ .pending := (h.log_phase d hlive).2 (le_refl d)
  -- interval products unchanged
  have hip : ∀ j a b, intervalProd (S'.log j) a b = intervalProd (S.log j) a b := fun j a b => by
    by_cases hj : j = d
    · subst hj; rw [hlogd, intervalProd_cons]
      have : e0.out.mult = 1 := rfl
      rw [this]; simp
    · rw [hlogj j hj]
  -- coordinates of the new residual
  have hcoord_d : ∀ l, coordAt (S'.r d) l = coordAt (S.r d) l - δ * (if l = g.val then 1 else 0) := by
    intro l; rw [hrd, coordAt_sub, coordAt_smul, coordAt_unitVec]
  -- the guard bound (Lemma 5.7)
  have hγ : (0 : ℝ) < P.gamma := by exact_mod_cast P.gamma_pos
  have hhg : (0 : ℝ) < P.hg := by exact_mod_cast P.hg_pos
  have hV : (0 : ℝ) < P.V := by exact_mod_cast (show 0 < P.V by have := P.one_le_V; omega)
  have hU : 0 < env P d (R.k d) := by
    unfold env; apply div_pos _ (by positivity)
    exact_mod_cast (show 0 < P.Ud d by unfold StreamParams.Ud; positivity)
  have hUV : √(env P d (R.k d)) ≤ 4 * (P.V : ℝ) := (sqrt_U_le P hd.le (R.k d)).2.2.2.2
  have htag' : |R.Chat d - S.C d| * ((P.gamma : ℝ) / 4 * √(env P d (R.k d))) ≤ (P.hg : ℝ) / 2 ^ 10 :=
    tag_error_le hhg hγ hV hUV (by rw [← eC_eq]; exact htag)
  have hbound : (δ / S.C d) ^ 2 ≤ (P.gamma : ℝ) ^ 2 * env P d (R.k d) := by
    rw [hδ]; exact guardAmp_div_sq_le hhg hγ hU htag'
  have hδ0 : 0 ≤ δ := by rw [hδ]; exact guardAmp_nonneg hhg
  -- energies
  have hE : S'.E d = S.E d + δ ^ 2 := by
    unfold TreeState.E
    rw [hrd, smul_unitVec_eq_single]
    have := normalized_energy_guard (S.r d) g δ 1 hrg
    simpa using this
  have hEt : S'.Et d = S.Et d + (δ / S.C d) ^ 2 := by
    unfold TreeState.Et TreeState.E
    rw [hrd, smul_unitVec_eq_single, step_guard_C]
    exact normalized_energy_guard (S.r d) g δ (S.C d) hrg
  refine ⟨?_, hE, hbound⟩
  exact
    { round_pos := h.round_pos
      round_le := h.round_le
      live_le := h.live_le
      x0_phys := h.x0_phys
      r_supp := fun j hj i t' hji hi => by
        by_cases hjd : j = d
        · subst hjd
          rw [hcoord_d, h.r_supp j hj i t' hji hi, if_neg]
          · ring
          · rw [hg]; exact guardIdx_ne_of_ne P hi hd ht1 (by omega)
        · rw [hrj j hjd]; exact h.r_supp j hj i t' hji hi
      fresh := fun j hj l hl => by
        have hl' : P.guardCoord d S.t ≤ l + 1 := by
          have := guardCoord_lt_of_lex P hd ht1 (Or.inr ⟨rfl, Nat.lt_succ_self d⟩) (d' := d + 1)
          simp only [Phase.nextG, hSt] at hl; omega
        by_cases hjd : j = d
        · subst hjd
          rw [hcoord_d, h.fresh j hj l hl', if_neg]
          · ring
          · rw [hg]; intro hlg
            have := guardIdx_add_one P j S.t
            have := guardCoord_lt_of_lex P hd ht1 (Or.inr ⟨rfl, Nat.lt_succ_self j⟩) (d' := j + 1)
            simp only [Phase.nextG, hSt] at hl; omega
        · rw [hrj j hjd]; exact h.fresh j hj l hl'
      tb_le := h.tb_le
      tb_mono := h.tb_mono
      log_t := fun j hj e he => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · exact ⟨(h.tb_le j hj).2, le_refl _, hg⟩
          · exact h.log_t j hj e he'
        · rw [hlogj j hjd] at he; exact h.log_t j hj e he
      log_sorted := fun j hj => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd]
          exact List.pairwise_cons.2 ⟨fun e he => (hold e he).1, h.log_sorted j hj⟩
        · rw [hlogj j hjd]; exact h.log_sorted j hj
      log_phase := fun j hj => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd]
          exact ⟨fun _ => ⟨e0, S.log j, rfl, rfl, rfl, hold⟩, fun h' => absurd h' (by omega)⟩
        · rw [hlogj j hjd]
          have hph := h.log_phase j hj
          rcases lt_or_gt_of_ne hjd with hlt | hgt
          · exact ⟨fun _ => hph.1 hlt, fun h' => absurd h' (by omega)⟩
          · exact ⟨fun h' => absurd h' (by omega), fun _ => hph.2 (by omega)⟩
      C_pos := h.C_pos
      C_prod := fun j hj => by
        simp only [hip]
        exact h.C_prod j hj
      mult_mem := fun j hj e he => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · show 1 / 2 ≤ (1 : ℝ) ∧ (1 : ℝ) ≤ 3 / 2; norm_num
          · exact h.mult_mem j hj e he'
        · rw [hlogj j hjd] at he; exact h.mult_mem j hj e he
      prod_le := fun j hj a b => by rw [hip]; exact h.prod_le j hj a b
      coord := fun j hj e he => by
        rw [hSt, hSC, hip]
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · simp only [he0]
            rw [hcoord_d, hfreshg j hj, if_pos rfl,
              intervalProd_eq_one _ _ _ (fun e' he' h' => by have := (hold e' he').1; omega)]
            ring
          · rw [hcoord_d, if_neg]
            · simp only [mul_zero, sub_zero]; exact h.coord j hj e he'
            · rw [hg, (h.log_t j hj e he').2.2]
              have hte := (hold e he').1
              have hte1 : 1 ≤ e.t := le_trans (h.tb_le j hj).1 (h.log_t j hj e he').1
              exact guardIdx_ne_of_lt P hd hte1 hte
        · rw [hlogj j hjd] at he; rw [hrj j hjd]; exact h.coord j hj e he
      entry_C_pos := fun j hj e he => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · exact h.C_pos j hj
          · exact h.entry_C_pos j hj e he'
        · rw [hlogj j hjd] at he; exact h.entry_C_pos j hj e he
      entry_δ_nonneg := fun j hj e he => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · exact hδ0
          · exact h.entry_δ_nonneg j hj e he'
        · rw [hlogj j hjd] at he; exact h.entry_δ_nonneg j hj e he
      nonomit := fun j hj e he c hc => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he
          rcases List.mem_cons.1 he with rfl | he'
          · simp [he0] at hc
          · exact h.nonomit j hj e he' c hc
        · rw [hlogj j hjd] at he; exact h.nonomit j hj e he c hc
      epoch := fun j hj => by
        by_cases hjd : j = d
        · subst hjd
          obtain ⟨ng, hng, hb⟩ := h.epoch j hj
          refine ⟨ng + 1, by rw [hlogd]; simp; omega, ?_⟩
          rw [hEt]
          exact EpochBound.guard hb hbound
        · obtain ⟨ng, hng, hb⟩ := h.epoch j hj
          refine ⟨ng, by rw [hlogj j hjd]; exact hng, ?_⟩
          have : S'.Et j = S.Et j := by
            unfold TreeState.Et TreeState.E; rw [hrj j hjd, step_guard_C]
          rw [this]; exact hb
      root_env := h.root_env
      counters := h.counters
      pending := fun j hj e he hp => by
        by_cases hjd : j = d
        · subst hjd; rw [hlogd] at he; simp at he; subst he
          exact ⟨rfl, hδ⟩
        · rw [hlogj j hjd] at he
          rw [hSC]; exact h.pending j hj e he hp
      cur_fresh := fun j hj i hi hij => by
        show coordAt (S'.r j) (guardIdx P i S.t) = 0
        by_cases hjd : j = d
        · subst hjd
          rw [hcoord_d, h.cur_fresh j hj i hi hij, if_neg]
          · ring
          · rw [hg]; exact guardIdx_ne_of_ne P hi hd ht1 hij
        · rw [hrj j hjd]; exact h.cur_fresh j hj i hi hij
      leaf := by
        refine ⟨h.leaf.1, ?_⟩
        have hx := TreeState.x_guard P S d g δ P.H
        rw [if_pos hd] at hx
        rw [show (S.step P (.guard d g δ)).x P.H = S'.x P.H from rfl] at hx
        rw [hx, h.leaf.2, Finset.sum_range_succ, hlogd]
        have hsum : ∑ x ∈ Finset.range d, headδ (S'.log x) • unitAt P.Dstar (guardIdx P x S'.t) =
            ∑ x ∈ Finset.range d, headδ (S.log x) • unitAt P.Dstar (guardIdx P x S.t) := by
          apply Finset.sum_congr rfl
          intro x hx'
          rw [hlogj x (by have := Finset.mem_range.1 hx'; omega)]; rfl
        rw [show S'.upd = S.upd from rfl, hsum, unitVec_eq_unitAt, hg]
        simp only [headδ, he0]
        abel }

/-- The end of Step 3 is the start of Step 4. -/
theorem treeInv_startStep4 {R : Regs} {S : TreeSt P} (h : TreeInv P (.guards P.H) R S) :
    TreeInv P (.evals P.H) R S :=
  { h with
    log_phase := fun d hd => by
      obtain ⟨e, l', hl, het, hep, hrest⟩ := (h.log_phase d hd).1 hd
      exact ⟨e, l', hl, het, ⟨fun _ => hep, fun _ => hd⟩, hrest⟩
    leaf := ⟨h.leaf.1, fun _ => h.leaf.2⟩ }

/-- Step 4 at depth `d`, `ACCEPT` (L499–500): no shadow change. -/
theorem treeInv_accept {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) : TreeInv P (.evals d) R (S.step P (.accept d)) := by
  obtain ⟨e, l', hl, het, hiff, hrest⟩ := h.log_phase d hd
  have hep : e.out = .pending := hiff.1 (Nat.lt_succ_self d)
  set e' : LogEntry := { e with out := .accepted } with he'
  have hlog : (S.step P (.accept d)).log d = e' :: l' := log_accept_eq hl
  -- interval products unchanged
  have hmap : ∀ d', ((S.step P (.accept d)).log d').map (fun x => (x.t, x.out.mult)) =
      (S.log d').map (fun x => (x.t, x.out.mult)) := by
    intro d'
    by_cases hdd : d' = d
    · subst hdd; rw [hlog, hl]; simp [he', Outcome.mult, hep]
    · rw [log_accept_ne hdd]
  have hip : ∀ d' a b, intervalProd ((S.step P (.accept d)).log d') a b = intervalProd (S.log d') a b :=
    fun d' a b => intervalProd_congr a b (hmap d')
  -- membership transfer
  have hmem : ∀ d' x, x ∈ (S.step P (.accept d)).log d' →
      (x ∈ S.log d') ∨ (d' = d ∧ x = e') := by
    intro d' x hx
    by_cases hdd : d' = d
    · subst hdd; rw [hlog] at hx
      rcases List.mem_cons.1 hx with rfl | hx'
      · exact Or.inr ⟨rfl, rfl⟩
      · exact Or.inl (by rw [hl]; exact List.mem_cons_of_mem _ hx')
    · rw [log_accept_ne hdd] at hx; exact Or.inl hx
  have he_mem : e ∈ S.log d := by rw [hl]; exact List.mem_cons_self
  exact
    { h with
      log_t := fun d' hd' x hx => by
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.log_t d' hd' x hx'
        · exact h.log_t d' hd' e he_mem
      log_sorted := fun d' hd' => by
        by_cases hdd : d' = d
        · subst hdd; rw [hlog]
          have hs := h.log_sorted d' hd'; rw [hl] at hs
          exact List.pairwise_cons.2 ⟨fun x hx => (List.pairwise_cons.1 hs).1 x hx,
            (List.pairwise_cons.1 hs).2⟩
        · rw [log_accept_ne hdd]; exact h.log_sorted d' hd'
      log_phase := fun d' hd' => by
        by_cases hdd : d' = d
        · subst hdd; rw [hlog]
          refine ⟨e', l', rfl, het, ⟨fun h' => absurd h' (lt_irrefl _), fun h' => ?_⟩, hrest⟩
          simp [he'] at h'
        · rw [log_accept_ne hdd]
          obtain ⟨e2, l2, hl2, het2, hiff2, hrest2⟩ := h.log_phase d' hd'
          refine ⟨e2, l2, hl2, het2, ⟨fun h' => hiff2.1 (by omega), fun h' => ?_⟩, hrest2⟩
          have := hiff2.2 h'; omega
      C_prod := fun d' hd' => by
        simp only [step_accept_C, step_accept_tb, step_accept_t, hip]; exact h.C_prod d' hd'
      mult_mem := fun d' hd' x hx => by
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.mult_mem d' hd' x hx'
        · rw [he']; simp only [Outcome.mult]; norm_num
      prod_le := fun d' hd' a b => by rw [hip]; exact h.prod_le d' hd' a b
      coord := fun d' hd' x hx => by
        simp only [step_accept_r, step_accept_C, step_accept_t]
        rw [hip]
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.coord d' hd' x hx'
        · exact h.coord d' hd' e he_mem
      entry_C_pos := fun d' hd' x hx => by
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.entry_C_pos d' hd' x hx'
        · exact h.entry_C_pos d' hd' e he_mem
      entry_δ_nonneg := fun d' hd' x hx => by
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.entry_δ_nonneg d' hd' x hx'
        · exact h.entry_δ_nonneg d' hd' e he_mem
      nonomit := fun d' hd' x hx c hc => by
        rcases hmem d' x hx with hx' | ⟨rfl, rfl⟩
        · exact h.nonomit d' hd' x hx' c hc
        · simp [he'] at hc
      epoch := fun d' hd' => by
        obtain ⟨ng, hng, hb⟩ := h.epoch d' hd'
        refine ⟨ng, ?_, hb⟩
        have := congrArg List.length (hmap d'); simp only [List.length_map] at this; omega
      pending := fun d' hd' x hx hp => by
        by_cases hdd : d' = d
        · subst hdd; rw [hlog] at hx; simp at hx; subst hx; simp [he'] at hp
        · rw [log_accept_ne hdd] at hx; exact h.pending d' hd' x hx hp
      cur_fresh := fun j hj i hi hij => h.cur_fresh j (by omega) i hi hij
      leaf := ⟨h.leaf.1, fun hh => absurd hh (by omega)⟩ }

/-- The bookkeeping half of `treeInv_correct`: the invariant after the correction of depth `d`, given the
Step-4 facts (Theorem 5.9 (3)-(4)), the epoch margin (Theorem 5.11 (2c)) and the non-omission of the current
guard (Theorem 5.11 (1)). -/
theorem treeInv_correct_inv {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) {c : ℝ} (hc1 : 1 / 2 ≤ c) (hc2 : c ≤ 3 / 2)
    (hEx : (P.eta : ℝ) ^ 2 / 32 * ‖S.x d‖ ^ 2 ≤ S.E d)
    (hcontr : ‖S.r d - (c - 1) • S.y d‖ ^ 2 ≤ (1 - (P.eta : ℝ) ^ 2 / 64) * S.E d)
    (hmargin : R.k d + 13 ≤ P.Kepoch)
    (hnon0 : ∀ e, (S.log d).head? = some e → (P.gamma : ℝ) / 15 * √(env P d (R.k d)) ≤ e.δ / e.C)
    (hRlt : ∀ j < d, R'.Chat j = R.Chat j ∧ R'.k j = R.k j ∧ R'.jE j = R.jE j ∧ R'.jU j = R.jU j)
    (hRd : R'.Chat d = R.Chat d ∧ R'.jU d = R.jU d + 1 ∧
      ((R.jE d + 1 = P.K0 ∧ R'.k d = R.k d + 1 ∧ R'.jE d = 0) ∨
        (R.jE d + 1 ≠ P.K0 ∧ R'.k d = R.k d ∧ R'.jE d = R.jE d + 1)))
    (hRgt : ∀ j, d < j → R'.k j = R.k j ∧ R'.jE j = R.jE j ∧ R'.jU j = R.jU j) :
    TreeInv P (.evals d) R' (S.step P (.correct d c)) := by
  -- the record of the current round
  obtain ⟨e0, l', hl, het, hiff, hrest⟩ := h.log_phase d hd
  have hep : e0.out = .pending := hiff.1 (Nat.lt_succ_self d)
  have hc0 : (0 : ℝ) < c := by linarith
  have hlog : (S.step P (.correct d c)).log d = { e0 with out := .corrected c } :: l' :=
    log_correct_eq hl c
  have he0mem : e0 ∈ S.log d := by rw [hl]; exact List.mem_cons_self
  have hmem : ∀ j x, x ∈ (S.step P (.correct d c)).log j →
      x ∈ S.log j ∨ (j = d ∧ x = { e0 with out := .corrected c }) := by
    intro j x hx
    by_cases hjd : j = d
    · rw [hjd, hlog] at hx
      rcases List.mem_cons.1 hx with hx' | hx'
      · exact Or.inr ⟨hjd, hx'⟩
      · exact Or.inl (by rw [hjd, hl]; exact List.mem_cons_of_mem _ hx')
    · rw [log_correct_ne c hjd] at hx; exact Or.inl hx
  -- interval products
  have hip_ne : ∀ i, i ≠ d → ∀ a b,
      intervalProd ((S.step P (.correct d c)).log i) a b = intervalProd (S.log i) a b :=
    fun i hi a b => by rw [log_correct_ne c hi]
  have hipd : ∀ a b, a ≤ S.t → S.t ≤ b →
      intervalProd ((S.step P (.correct d c)).log d) a b = c * intervalProd (S.log d) a b := by
    intro a b ha hb
    rw [hlog, intervalProd_correct_head e0 l' hep c, hl,
      if_pos ⟨by rw [het]; exact ha, by rw [het]; exact hb⟩]
  have hipd' : ∀ a b, b < S.t →
      intervalProd ((S.step P (.correct d c)).log d) a b = intervalProd (S.log d) a b := by
    intro a b hb
    rw [hlog, intervalProd_correct_head e0 l' hep c, hl, if_neg (by rw [het]; omega), one_mul]
  -- residuals and tags
  have hr_lt : ∀ j, j < d → (S.step P (.correct d c)).r j = S.r j := fun j hj => by
    rw [TreeState.step_correct_r, if_neg (by omega), if_neg (by omega)]
  have hr_gt : ∀ j, d < j → (S.step P (.correct d c)).r j = c • S.r j := fun j hj => by
    rw [TreeState.step_correct_r, if_neg (by omega), if_pos hj]
  have hC_le : ∀ j, j ≤ d → (S.step P (.correct d c)).C j = S.C j := fun j hj => by
    rw [TreeState.step_correct_C, if_neg (by omega)]
  have hC_gt : ∀ j, d < j → (S.step P (.correct d c)).C j = c * S.C j := fun j hj => by
    rw [TreeState.step_correct_C, if_pos hj]
  have hy0 : ∀ l, (∀ i ≤ d, coordAt (S.r i) l = 0) → coordAt S.x0 l = 0 → coordAt (S.y d) l = 0 :=
    fun l hr h0 => coordAt_x_zero S h0 (fun i hi => hr i (by omega))
  have hrd0 : ∀ l, coordAt (S.r d) l = 0 → coordAt (S.y d) l = 0 →
      coordAt ((S.step P (.correct d c)).r d) l = 0 := fun l h1 h2 => by
    rw [TreeState.step_correct_r, if_pos rfl, coordAt_sub, coordAt_smul, h1, h2]; ring
  -- registers
  have hk_le : R.k d ≤ R'.k d := by
    rcases hRd.2.2 with ⟨-, hk, -⟩ | ⟨-, hk, -⟩ <;> omega
  have hRk : ∀ j, j ≠ d → R'.k j = R.k j := fun j hj => by
    rcases lt_or_gt_of_ne hj with h1 | h1
    · exact (hRlt j h1).2.1
    · exact (hRgt j h1).1
  -- the new data of depth `d`
  have hle_t : ∀ x ∈ (S.step P (.correct d c)).log d, x.t ≤ S.t := fun x hx => by
    rcases hmem d x hx with hx' | ⟨-, rfl⟩
    · exact (h.log_t d hd x hx').2.1
    · exact (h.log_t d hd e0 he0mem).2.1
  have hmult' : ∀ x ∈ (S.step P (.correct d c)).log d, 1 / 2 ≤ x.out.mult ∧ x.out.mult ≤ 3 / 2 :=
    fun x hx => by
      rcases hmem d x hx with hx' | ⟨-, rfl⟩
      · exact h.mult_mem d hd x hx'
      · exact ⟨hc1, hc2⟩
  have hCe' : ∀ x ∈ (S.step P (.correct d c)).log d, 0 < x.C := fun x hx => by
    rcases hmem d x hx with hx' | ⟨-, rfl⟩
    · exact h.entry_C_pos d hd x hx'
    · exact h.entry_C_pos d hd e0 he0mem
  have hδ' : ∀ x ∈ (S.step P (.correct d c)).log d, 0 ≤ x.δ := fun x hx => by
    rcases hmem d x hx with hx' | ⟨-, rfl⟩
    · exact h.entry_δ_nonneg d hd x hx'
    · exact h.entry_δ_nonneg d hd e0 he0mem
  have hcoord' := correct_coord_d h hd c hl hep het
  have hepoch' := correct_epoch_d (R' := R') h hd hcontr hRd.2.2
  have hγ : (0 : ℝ) < P.gamma := by exact_mod_cast P.gamma_pos
  have hnon' : ∀ x ∈ (S.step P (.correct d c)).log d, ∀ c' : ℝ, x.out = .corrected c' →
      (P.gamma : ℝ) / 15 * √(env P d (R'.k d)) ≤ x.δ / x.C := by
    intro x hx c' hc'
    have hmono : (P.gamma : ℝ) / 15 * √(env P d (R'.k d)) ≤
        (P.gamma : ℝ) / 15 * √(env P d (R.k d)) :=
      mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt (env_anti P d hk_le)) (by positivity)
    rcases hmem d x hx with hx' | ⟨-, rfl⟩
    · exact hmono.trans (h.nonomit d hd x hx' c' hc')
    · exact hmono.trans (hnon0 e0 (by rw [hl]; rfl))
  have hceil' : ‖(S.step P (.correct d c)).r d‖ ^ 2 / S.C d ^ 2 ≤ 33 / 64 * env P d (R'.k d) := by
    obtain ⟨ng, hng, hb⟩ := hepoch'
    obtain ⟨hρ0, hρ1⟩ := rho_bounds P
    have hlen : ((S.step P (.correct d c)).log d).length = (S.log d).length := by
      rw [hlog, hl]; rfl
    have hlenT : ng ≤ P.T := hng.trans (by rw [hlen]; exact log_length_le_T h hd)
    obtain ⟨c1, c2, -⟩ := hb.ceiling hρ0 hρ1 (env_pos P d _) hlenT (T_gamma_sq_le P).1
    have c3 := c1.trans c2
    unfold TreeState.Et TreeState.E at c3
    rw [hC_le d le_rfl] at c3
    exact c3
  exact
    { round_pos := h.round_pos
      round_le := h.round_le
      live_le := h.live_le
      x0_phys := h.x0_phys
      r_supp := fun j hj i t' hji hi => by
        by_cases hjd : j = d
        · rw [hjd] at hji ⊢
          apply hrd0 _ (h.r_supp d hd i t' hji hi)
          exact hy0 _ (fun i' hi' => h.r_supp i' (by show i' < P.H; omega) i t' (by omega) hi)
            (h.x0_phys _ (guardIdx_ge P i t'))
        · rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [hr_lt j h1]; exact h.r_supp j hj i t' hji hi
          · rw [hr_gt j h1, coordAt_smul, h.r_supp j hj i t' hji hi, mul_zero]
      fresh := fun j hj l hl => by
        have hl' : Phase.nextG P S.t (.evals (d + 1)) ≤ l + 1 := hl
        have hn : P.n ≤ l := by
          simp only [Phase.nextG] at hl'; unfold StreamParams.guardCoord at hl'; omega
        by_cases hjd : j = d
        · rw [hjd]
          apply hrd0 _ (h.fresh d hd l hl')
          exact hy0 _ (fun i' hi' => h.fresh i' (by show i' < P.H; omega) l hl') (h.x0_phys l hn)
        · rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [hr_lt j h1]; exact h.fresh j hj l hl'
          · rw [hr_gt j h1, coordAt_smul, h.fresh j hj l hl', mul_zero]
      tb_le := h.tb_le
      tb_mono := h.tb_mono
      log_t := fun j hj x hx => by
        rcases hmem j x hx with hx' | ⟨hjd, rfl⟩
        · exact h.log_t j hj x hx'
        · rw [hjd]; exact h.log_t d hd e0 he0mem
      log_sorted := fun j hj => by
        by_cases hjd : j = d
        · rw [hjd, hlog]
          have hs := h.log_sorted d hd
          rw [hl] at hs
          exact List.pairwise_cons.2
            ⟨fun x hx => (List.pairwise_cons.1 hs).1 x hx, (List.pairwise_cons.1 hs).2⟩
        · rw [log_correct_ne c hjd]; exact h.log_sorted j hj
      log_phase := fun j hj => by
        by_cases hjd : j = d
        · rw [hjd, hlog]
          refine ⟨{ e0 with out := .corrected c }, l', rfl, het,
            ⟨fun h' => absurd h' (lt_irrefl _), fun h' => ?_⟩, hrest⟩
          simp at h'
        · rw [log_correct_ne c hjd]
          obtain ⟨e2, l2, hl2, het2, hiff2, hrest2⟩ := h.log_phase j hj
          refine ⟨e2, l2, hl2, het2, ⟨fun h' => hiff2.1 (by omega), fun h' => ?_⟩, hrest2⟩
          have := hiff2.2 h'; omega
      C_pos := fun j hj => by
        rw [TreeState.step_correct_C]
        split_ifs
        · exact mul_pos hc0 (h.C_pos j hj)
        · exact h.C_pos j hj
      C_prod := fun j hj => by
        have hp := h.C_prod j hj
        simp only [step_correct_tb, step_correct_t]
        by_cases hdj : d < j
        · rw [hC_gt j hdj, hp]
          symm
          exact prod_range_mul_at hdj (hipd _ _ (h.tb_le j hj).2 le_rfl)
            (fun i hi => hip_ne i hi _ _)
        · rw [hC_le j (by omega), hp]
          apply Finset.prod_congr rfl
          intro i hi
          rw [hip_ne i (by have := Finset.mem_range.1 hi; omega)]
      mult_mem := fun j hj x hx => by
        rcases hmem j x hx with hx' | ⟨-, rfl⟩
        · exact h.mult_mem j hj x hx'
        · exact ⟨hc1, hc2⟩
      prod_le := fun j hj t1 t2 => by
        by_cases hjd : j = d
        · rw [hjd]
          by_cases ht2 : t2 < S.t
          · rw [hipd' t1 t2 ht2]; exact h.prod_le d hd t1 t2
          · rw [intervalProd_of_le _ t1 t2 S.t (by omega) hle_t]
            exact prod_le_of_coord hγ (gamma_le_one_real P) (env_pos P d _) (h.C_pos d hd)
              (fun x hx => le_trans (by norm_num) (hmult' x hx).1) hCe' hδ' hle_t hcoord' hnon'
              hceil' t1
        · rw [hip_ne j hjd]; exact h.prod_le j hj t1 t2
      coord := fun j hj x hx => by
        simp only [step_correct_t]
        by_cases hjd : j = d
        · rw [hjd] at hx ⊢
          rw [hC_le d le_rfl]
          exact hcoord' x hx
        · rw [log_correct_ne c hjd] at hx
          rw [hip_ne j hjd]
          rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [hr_lt j h1, hC_le j h1.le]; exact h.coord j hj x hx
          · rw [hr_gt j h1, hC_gt j h1, coordAt_smul, mul_assoc, h.coord j hj x hx]; ring
      entry_C_pos := fun j hj x hx => by
        rcases hmem j x hx with hx' | ⟨-, rfl⟩
        · exact h.entry_C_pos j hj x hx'
        · exact h.entry_C_pos d hd e0 he0mem
      entry_δ_nonneg := fun j hj x hx => by
        rcases hmem j x hx with hx' | ⟨-, rfl⟩
        · exact h.entry_δ_nonneg j hj x hx'
        · exact h.entry_δ_nonneg d hd e0 he0mem
      nonomit := fun j hj x hx c' hc' => by
        by_cases hjd : j = d
        · rw [hjd] at hx ⊢; exact hnon' x hx c' hc'
        · rw [log_correct_ne c hjd] at hx; rw [hRk j hjd]; exact h.nonomit j hj x hx c' hc'
      epoch := fun j hj => by
        by_cases hjd : j = d
        · rw [hjd]; exact hepoch'
        · rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [log_correct_ne c hjd, (hRlt j h1).2.1, (hRlt j h1).2.2.1]
            have hEt : (S.step P (.correct d c)).Et j = S.Et j := by
              unfold TreeState.Et TreeState.E; rw [hr_lt j h1, hC_le j h1.le]
            rw [hEt]; exact h.epoch j hj
          · rw [log_correct_ne c hjd, (hRgt j h1).1, (hRgt j h1).2.1,
              TreeState.Et_correct_of_lt P S hc0.ne' h1]
            exact h.epoch j hj
      root_env := fun _ => correct_root_env h hd hx0 hEx (fun j hj => (hRlt j hj).2.1)
        (by rcases hRd.2.2 with ⟨-, hk, -⟩ | ⟨-, hk, -⟩
            · exact Or.inl hk
            · exact Or.inr hk)
      counters := fun j hj => by
        by_cases hjd : j = d
        · rw [hjd]; exact correct_counters_d h hd hmargin ⟨hRd.2.1, hRd.2.2⟩
        · rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [(hRlt j h1).2.1, (hRlt j h1).2.2.1, (hRlt j h1).2.2.2]; exact h.counters j hj
          · rw [(hRgt j h1).1, (hRgt j h1).2.1, (hRgt j h1).2.2]; exact h.counters j hj
      pending := fun j hj x hx hp => by
        by_cases hjd : j = d
        · rw [hjd, hlog] at hx
          simp at hx
          subst hx; simp at hp
        · rw [log_correct_ne c hjd] at hx
          rcases lt_or_gt_of_ne hjd with h1 | h1
          · rw [hC_le j h1.le, (hRlt j h1).1, (hRlt j h1).2.1]; exact h.pending j hj x hx hp
          · obtain ⟨e2, l2, hl2, het2, hiff2, hrest2⟩ := h.log_phase j hj
            rw [hl2] at hx; simp at hx; subst hx
            exact absurd (hiff2.2 hp) (by omega)
      cur_fresh := fun j hj i hi hij => by
        show coordAt ((S.step P (.correct d c)).r j) (guardIdx P i S.t) = 0
        rw [hr_lt j hj]; exact h.cur_fresh j (by omega) i hi hij
      leaf := ⟨h.leaf.1, fun hh => absurd hh (by omega)⟩ }

/-- Step 4 at depth `d` (height `ℓ = H − d`), rejection with protected sign `s` (L501–510; Theorem 5.9 (3)–(4),
Theorem 5.11 (1), (2c), Lemma 5.10, Lemma 5.8 (i)). Hypotheses at the moment of the rejection: the root tag
`Ĉ_0 = 1` and `‖x_phys‖ ≥ 1` (nonzero round on the fingerprint event; they give the norm floor `‖x_d‖ ≥ ν`,
`norm_floor`); the cache `P ≥ 0` with (H2) (Lemma 6.2); the child estimate `Q̂ ≥ 0` with
`|Q̂ − Q_d| ≤ 8ℓηQ_d` (Theorem 5.9 (1)); the certificate `HIGH`/`LOW` (eqs. `R:eq:cert-high`, `R:eq:cert-low`)
for `S = P + Q̂`; the tag precision (Lemma 6.1 (ii)); the multiplier
`c = 1 + clamp_{[-1/2,1/2]} round_{h_step}(s(η/16)√(P/Q̂))` (L504); the registers after the local counters'
update (L509): `J_used += 1`, `j_epoch += 1` or, at `j_epoch + 1 = K₀`, `k += 1` and `j_epoch := 0`; the
registers of the depths `< d` and the counters of the depths `> d` unchanged.
Conclusions: the invariant at the next moment, and the facts used by the algorithm's checks and by Section 6:
the positive-denominator rule is inactive (`P > 0`, `Q̂ > 0`), the client cap `J_used < J_*` and the epoch cap
hold, `c ∈ [1/2, 3/2]`, `E_d, Q_d ≥ E_min`, and `E_d⁺ ≤ (1 − η²/64)E_d`. -/
theorem treeInv_correct {R R' : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) (hroot : R.Chat 0 = 1)
    {Pc Qhat s c : ℝ} (hP : 0 ≤ Pc) (hQ : 0 ≤ Qhat)
    (hcache : |Pc - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + cacheDrift P)
    (hchild : |Qhat - S.Q d| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * S.Q d)
    (hs : s = 1 ∨ s = -1)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      s * ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (Pc + Qhat + (P.omega : ℝ)) - 1))
    (htag : |R.Chat d - S.C d| ≤ (P.eC : ℝ))
    (hc : c = 1 + max (-1 / 2) (min (1 / 2)
      (roundGrid (P.hstep : ℝ) (s * ((P.eta : ℝ) / 16 * √(Pc / Qhat))))))
    (hRlt : ∀ j < d, R'.Chat j = R.Chat j ∧ R'.k j = R.k j ∧ R'.jE j = R.jE j ∧ R'.jU j = R.jU j)
    (hRd : R'.Chat d = R.Chat d ∧ R'.jU d = R.jU d + 1 ∧
      ((R.jE d + 1 = P.K0 ∧ R'.k d = R.k d + 1 ∧ R'.jE d = 0) ∨
        (R.jE d + 1 ≠ P.K0 ∧ R'.k d = R.k d ∧ R'.jE d = R.jE d + 1)))
    (hRgt : ∀ j, d < j → R'.k j = R.k j ∧ R'.jE j = R.jE j ∧ R'.jU j = R.jU j) :
    TreeInv P (.evals d) R' (S.step P (.correct d c)) ∧
      0 < Pc ∧ 0 < Qhat ∧ R.jU d < P.Jstar ∧ (R.jE d + 1 = P.K0 → R.k d + 1 ≤ P.Kepoch) ∧
      1 / 2 ≤ c ∧ c ≤ 3 / 2 ∧
      (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.E d ∧ (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.Q d ∧
      (S.step P (.correct d c)).E d ≤ (1 - (P.eta : ℝ) ^ 2 / 64) * S.E d := by
  obtain ⟨hPc, hQh, hc1, hc2, hEx, hEmin, hQmin, hcontr⟩ :=
    correct_step4 h hd hx0 hroot hP hQ hcache hchild hs hcert hc
  have hmargin := correct_epoch_margin h hd hEmin
  obtain ⟨hJ, hJE, -⟩ := h.counters d hd
  obtain ⟨hcap1, hcap2, -⟩ := lifetime_cap hJ hJE hmargin
  have hnon0 : ∀ e, (S.log d).head? = some e →
      (P.gamma : ℝ) / 15 * √(env P d (R.k d)) ≤ e.δ / e.C :=
    fun e he => correct_head_nonomit h hd hEmin htag he
  refine ⟨treeInv_correct_inv h hd hx0 hc1 hc2 hEx hcontr hmargin hnon0 hRlt hRd hRgt, hPc, hQh, ?_,
    fun _ => hcap2, hc1, hc2, hEmin, hQmin, ?_⟩
  · rw [(Jstar_eq P).1]; exact hcap1
  · unfold TreeState.E; rw [TreeState.step_correct_r, if_pos rfl]; exact hcontr

/-- The end of Step 4 (L513). -/
theorem treeInv_endRound {R : Regs} {S : TreeSt P} (h : TreeInv P (.evals 0) R S) :
    TreeInv P .idle R S :=
  { h with
    log_phase := fun d hd e he => by
      obtain ⟨e0, l', hl, het, hiff, hrest⟩ := h.log_phase d hd
      rw [hl] at he
      rcases List.mem_cons.1 he with rfl | he'
      · intro hp; exact absurd (hiff.2 hp) (Nat.not_lt_zero _)
      · exact (hrest e he').2
    cur_fresh := trivial
    leaf := trivial }

end Steps

end F2e2e.C.Tree
