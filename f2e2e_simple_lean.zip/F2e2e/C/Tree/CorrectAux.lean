import Mathlib
import F2e2e.C.Tree.InvExports
import F2e2e.C.Tree.InvLemmas
import F2e2e.C.Tree.Rescale

/-!
# Part III §5: auxiliary facts for the Step-4 correction step lemma `treeInv_correct`

Source: `parts/partIII.tex` Theorem 5.9 (L703–860), Lemma 5.7 (L618–645), Theorem 5.11 (1), (2c) (L895–989).

These are the four ingredients of `treeInv_correct` (in `F2e2e/C/Tree/Inv.lean`) that are not bookkeeping:
* `correct_step4`: Theorem 5.9 (3), (4) at the rejection of depth `d` (the rejection situation `RejectSit` is
  built from the invariant: the norm floor `norm_floor`, the cache invariant (H2), the child estimate, the
  certificate);
* `correct_epoch_margin`: Theorem 5.11 (2c), `k_d + 13 ≤ K_epoch` at a rejection;
* `correct_head_nonomit`: Theorem 5.11 (1) + Lemma 5.7 (2), the pending guard of the rejecting depth was not
  omitted, `δ/C ≥ (γ/15)√𝒰_{d,k}` (eq. `R:eq:first-correction-non-omission`);
* `prod_le_of_coord`: Theorem 5.11 (1), the energy trap for one ghost log (eqs. `R:eq:Pint-tstar-reduction`,
  `R:eq:Pint-energy-trap`, `R:eq:Pint-less-than-B`).
-/

namespace F2e2e.C.Tree

open F2e2e

/-! ## Helpers -/

/-- Interval products of logs with nonnegative multipliers are nonnegative. -/
theorem correctAux_intervalProd_nonneg (l : List LogEntry) (t1 t2 : ℕ) (h : ∀ e ∈ l, 0 ≤ e.out.mult) :
    0 ≤ intervalProd l t1 t2 := by
  induction l with
  | nil => simp
  | cons e l ih =>
    rw [intervalProd_cons]
    apply mul_nonneg
    · split_ifs
      · exact h e (by simp)
      · exact zero_le_one
    · exact ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))

/-- Moving the left end of the interval over records with multiplier `1` does not change the product
(eq. `R:eq:Pint-tstar-reduction`). -/
theorem correctAux_intervalProd_shift (l : List LogEntry) {t1 ts : ℕ} (t : ℕ) (h1 : t1 ≤ ts)
    (h : ∀ e ∈ l, t1 ≤ e.t → e.t < ts → e.out.mult = 1) :
    intervalProd l t1 t = intervalProd l ts t := by
  induction l with
  | nil => rfl
  | cons e l ih =>
    rw [intervalProd_cons, intervalProd_cons, ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))]
    congr 1
    by_cases ha : t1 ≤ e.t ∧ e.t ≤ t
    · by_cases hb : ts ≤ e.t
      · rw [if_pos ha, if_pos ⟨hb, ha.2⟩]
      · rw [if_pos ha, if_neg (fun h' => hb h'.1), h e (by simp) ha.1 (by omega)]
    · rw [if_neg ha, if_neg (fun h' => ha ⟨by omega, h'.2⟩)]

/-- If every record of the interval has multiplier `1`, the product is `1`. -/
theorem correctAux_intervalProd_eq_one_of (l : List LogEntry) (t1 t : ℕ)
    (h : ∀ e ∈ l, t1 ≤ e.t → e.t ≤ t → e.out.mult = 1) : intervalProd l t1 t = 1 := by
  induction l with
  | nil => rfl
  | cons e l ih =>
    rw [intervalProd_cons, ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))]
    split_ifs with ha
    · rw [h e (by simp) ha.1 ha.2, one_mul]
    · rw [one_mul]

/-- The multiplier of an outcome that is not a correction is `1`. -/
theorem correctAux_mult_eq_one {o : Outcome} (h : ∀ c, o ≠ .corrected c) : o.mult = 1 := by
  cases o with
  | pending => rfl
  | accepted => rfl
  | corrected c => exact absurd rfl (h c)

section CorrectAux

variable {P : StreamParams}

/-- Lemma 5.10 (b) for a live depth: `Ẽ_d ≤ (33/64)𝒰_{d,k_d} < 𝒰_{d,k_d}`. -/
theorem correctAux_Et_lt_env {ph : Phase} {R : Regs} {S : TreeSt P} (h : TreeInv P ph R S) {d : ℕ}
    (hd : d < ph.live P.H) :
    0 < env P d (R.k d) ∧ S.Et d ≤ 33 / 64 * env P d (R.k d) ∧ S.Et d < env P d (R.k d) := by
  obtain ⟨ng, hng, hEB⟩ := h.epoch d hd
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hρ0 : (0 : ℝ) ≤ 1 - (P.eta : ℝ) ^ 2 / 64 := by nlinarith
  have hρ1 : 1 - (P.eta : ℝ) ^ 2 / 64 ≤ 1 := by nlinarith
  have hUd : (0 : ℝ) < (P.Ud d : ℝ) := by
    have : 0 < P.Ud d := by unfold StreamParams.Ud; positivity
    exact_mod_cast this
  have hU : 0 < env P d (R.k d) := by
    unfold env
    exact div_pos hUd (by positivity)
  have hlen : (S.log d).length ≤ P.T := by
    have h1 := length_le_of_sorted (S.log d) S.t (h.log_sorted d hd) (fun e he => by
      obtain ⟨a1, a2, -⟩ := h.log_t d hd e he
      obtain ⟨b1, -⟩ := h.tb_le d hd
      omega)
    have := h.round_le
    have := P.m_lt_T
    omega
  obtain ⟨hc1, hc2, hc3⟩ := hEB.ceiling hρ0 hρ1 hU (hng.trans hlen) (T_gamma_sq_le P).1
  exact ⟨hU, hc1.trans hc2, lt_of_le_of_lt (hc1.trans hc2) hc3⟩

/-- Theorem 5.9 (3), (4) at the Step-4 rejection of depth `d` (height `ℓ = H − d`), with the hypotheses of
`treeInv_correct`: the positive-denominator rule is inactive (`P > 0`, `Q̂ > 0`), the multiplier
`c = 1 + clamp(round(s(η/16)√(P/Q̂)))` lies in `[1/2, 3/2]`, the energy floors
`E_d ≥ (η²/32)‖x_d‖²` and `E_d, Q_d ≥ E_min = η²ν²/256`, and the contraction
`‖r_d − (c − 1) y_d‖² ≤ (1 − η²/64) E_d` (eqs. `R:eq:sec5-rejection-energy-floor`,
`R:eq:sec5-multiplicative-P-Qhat`, `R:eq:sec5-astep-properties`, `R:eq:sec5-Eplus-contraction`). -/
theorem correct_step4 {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) (hroot : R.Chat 0 = 1)
    {Pc Qhat s c : ℝ} (hP : 0 ≤ Pc) (hQ : 0 ≤ Qhat)
    (hcache : |Pc - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + cacheDrift P)
    (hchild : |Qhat - S.Q d| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * S.Q d)
    (hs : s = 1 ∨ s = -1)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      s * ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (Pc + Qhat + (P.omega : ℝ)) - 1))
    (hc : c = 1 + max (-1 / 2) (min (1 / 2)
      (roundGrid (P.hstep : ℝ) (s * ((P.eta : ℝ) / 16 * √(Pc / Qhat)))))) :
    0 < Pc ∧ 0 < Qhat ∧ 1 / 2 ≤ c ∧ c ≤ 3 / 2 ∧
      (P.eta : ℝ) ^ 2 / 32 * ‖S.x d‖ ^ 2 ≤ S.E d ∧
      (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.E d ∧
      (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.Q d ∧
      ‖S.r d - (c - 1) • S.y d‖ ^ 2 ≤ (1 - (P.eta : ℝ) ^ 2 / 64) * S.E d := by
  have hxd : S.r d + S.y d = S.x d := TreeState.r_add_y S d
  have hfl := norm_floor h (Nat.succ_pos d) (by omega) hx0 hroot d (Nat.le_succ d)
  have hsit : RejectSit P.H (P.H - d) (P.eta : ℝ) (P.omega : ℝ) (P.nu : ℝ) (cacheDrift P) (S.r d) (S.y d)
      Pc Qhat s :=
    { params := step4Params_committed P
      one_le := by omega
      le_H := Nat.sub_le _ _
      floor := by rw [hxd]; exact hfl
      P_nonneg := hP
      Qhat_nonneg := hQ
      cache := hcache
      child := hchild
      sign := hs
      cert := by rw [hxd]; exact hcert }
  obtain ⟨-, -, -, hP0, hQ0⟩ := hsit.multiplicative
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hhs := hstep_eq P
  have hh : (0 : ℝ) < (P.hstep : ℝ) := by rw [hhs]; positivity
  have ha : c - 1 = max (-1 / 2) (min (1 / 2)
      (roundGrid (P.hstep : ℝ) (s * ((P.eta : ℝ) / 16 * √(Pc / Qhat))))) := by
    rw [hc]; ring
  obtain ⟨-, -, hc1, hc2, -, hcon1, hcon2⟩ := hsit.stepB hh hhs.le ha
  obtain ⟨hmin, h32, h256, hν⟩ := hsit.energy_floor
  rw [hxd] at h32 h256 hν
  have hEle : min (‖S.r d‖ ^ 2) (‖S.y d‖ ^ 2) ≤ S.E d := min_le_left _ _
  have hQle : min (‖S.r d‖ ^ 2) (‖S.y d‖ ^ 2) ≤ S.Q d := min_le_right _ _
  refine ⟨hP0, hQ0, by linarith, by linarith, by linarith, by linarith, by linarith, ?_⟩
  exact hcon1.trans hcon2

/-- Theorem 5.11 (2c) (eq. `R:eq:epoch-halving-termination`, partIII.tex L941–944, L987): at a rejection of
depth `d` (`E_d ≥ E_min`), `C_d ≤ B^d ≤ B^H` and `Ẽ_d < 𝒰_{d,k} ≤ 2^{-k}𝒰_*` give
`2^{-k}𝒰_* > η²ν²/(256B^{2H})`, hence `k_d + 13 ≤ K_epoch` (`epoch_floor`, `ParamFacts.epoch_lt`). -/
theorem correct_epoch_margin {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hE : (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.E d) :
    R.k d + 13 ≤ P.Kepoch := by
  have hlive : d < (Phase.evals (d + 1)).live P.H := hd
  obtain ⟨hC0, hCB⟩ := C_le_B_pow h hlive
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (B_eq_and_gt P).2.le
  have hCH : S.C d ≤ (P.B : ℝ) ^ P.H := hCB.trans (pow_le_pow_right₀ hB1 hd.le)
  obtain ⟨-, -, hEt⟩ := correctAux_Et_lt_env h hlive
  have henv : env P d (R.k d) ≤ (P.Ustar : ℝ) / 2 ^ (R.k d) := by
    unfold env
    apply div_le_div_of_nonneg_right _ (by positivity)
    exact_mod_cast StreamParams.Ud_le_Ustar P hd
  have hE' : (P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2 / 256 ≤ S.E d := by
    have e : (P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2 / 256 = (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 := by ring
    rw [e]
    exact hE
  exact epoch_lt P (epoch_floor hB1 hC0 hCH hE' (lt_of_lt_of_le hEt henv))

/-- Theorem 5.11 (1) and Lemma 5.7 (2) (eqs. `R:eq:sec5-scale-cancellation`,
`R:eq:first-correction-non-omission`, `R:eq:non-omitted-guard-enclosure`; partIII.tex L907–914, L957–961):
at a rejection of depth `d` (`E_d ≥ E_min`), under the tag precision `|Ĉ_d − C_d| ≤ e_C`, the pending record
`e` of the current round (its guard is `guardAmp h_g Ĉ_d δ̃_d` and `e.C = C_d`, field `pending`) was not
omitted: `δ/C ≥ (γ/15)√𝒰_{d,k_d}` (`first_correction_nonomission`, `guard_enclosure`; `Ẽ_d < 𝒰_{d,k_d}` from
`EpochBound.ceiling`). -/
theorem correct_head_nonomit {R : Regs} {S : TreeSt P} {d : ℕ} (h : TreeInv P (.evals (d + 1)) R S)
    (hd : d < P.H) (hE : (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 ≤ S.E d)
    (htag : |R.Chat d - S.C d| ≤ (P.eC : ℝ)) {e : LogEntry} (he : (S.log d).head? = some e) :
    (P.gamma : ℝ) / 15 * √(env P d (R.k d)) ≤ e.δ / e.C := by
  have hlive : d < (Phase.evals (d + 1)).live P.H := hd
  obtain ⟨e', l', hlog, -, hpend_iff, -⟩ := h.log_phase d hlive
  have hpend : e'.out = .pending := hpend_iff.mp (Nat.lt_succ_self d)
  have hee : e' = e := by
    rw [hlog] at he
    simpa using he
  subst hee
  obtain ⟨heC, heδ⟩ := h.pending d hlive e' he hpend
  rw [heC, heδ]
  have hγ0 : (0 : ℝ) < (P.gamma : ℝ) := by exact_mod_cast P.gamma_pos
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hν0 : (0 : ℝ) < (P.nu : ℝ) := by exact_mod_cast P.nu_pos
  have hhg0 : (0 : ℝ) < (P.hg : ℝ) := by exact_mod_cast P.hg_pos
  have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (B_eq_and_gt P).2.le
  have hC0 := h.C_pos d hlive
  obtain ⟨hU, -, hEt⟩ := correctAux_Et_lt_env h hlive
  have hUV : √(env P d (R.k d)) ≤ 4 * (P.V : ℝ) := (sqrt_U_le P hd.le (R.k d)).2.2.2.2
  have hV : (0 : ℝ) < (P.V : ℝ) := by
    have : 0 < √(env P d (R.k d)) := Real.sqrt_pos.2 hU
    linarith
  have htag' := tag_error_le hhg0 hγ0 hV hUV (by rw [← eC_eq]; exact htag)
  have hE' : (P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2 / 256 ≤ S.E d := by
    have e : (P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2 / 256 = (P.eta : ℝ) ^ 2 / 256 * (P.nu : ℝ) ^ 2 := by ring
    rw [e]
    exact hE
  have hnon := first_correction_nonomission hγ0 hη0 hν0 hhg0 hB1 (hgUnref_eq P) hC0 hE' hEt htag'
  have henc := guard_enclosure hhg0 hγ0 hU hnon.2.2.2 htag'
  unfold nomGuard
  exact henc.2.2.1

end CorrectAux

/-- Theorem 5.11 (1) for one ghost log at the current round `t` (eqs. `R:eq:Pint-tstar-reduction`,
`R:eq:Pint-energy-trap`, `R:eq:Pint-less-than-B`; partIII.tex L903–922, L955–973). Let `l` be a ghost log
whose records are from rounds `≤ t`, with nonnegative multipliers, `e.C > 0`, `e.δ ≥ 0`, satisfying the guard
coordinate identity `r_{e.g} e.C = −e.δ P_int[e.t, t] C` for the residual `r` and tag `C > 0`, such that every
corrected record was not omitted (`e.δ/e.C ≥ (γ/15)√U`), and `‖r‖²/C² ≤ (33/64)U`. Then every interval product
ending at `t` is at most `15√33/(8γ)`: if `[t₁, t]` contains no correction the product is `1`; otherwise, at the
first correction `e_*` of the interval, `P_int[t₁, t] = P_int[e_*.t, t]` and `product_trap` applies to
`ρ₀ = e_*.δ/e_*.C`, `ρ₂ = r_{e_*.g}/C`. -/
theorem prod_le_of_coord {N : ℕ} {l : List LogEntry} {r : VecN N} {C U γ : ℝ} {t : ℕ}
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) (hU : 0 < U) (hC : 0 < C)
    (hmult : ∀ e ∈ l, 0 ≤ e.out.mult)
    (hCe : ∀ e ∈ l, 0 < e.C) (hδ : ∀ e ∈ l, 0 ≤ e.δ)
    (ht : ∀ e ∈ l, e.t ≤ t)
    (hcoord : ∀ e ∈ l, coordAt r e.g * e.C = -e.δ * intervalProd l e.t t * C)
    (hnon : ∀ e ∈ l, ∀ c : ℝ, e.out = .corrected c → γ / 15 * √U ≤ e.δ / e.C)
    (hE : ‖r‖ ^ 2 / C ^ 2 ≤ 33 / 64 * U) (t1 : ℕ) :
    intervalProd l t1 t ≤ 15 * √33 / (8 * γ) := by
  classical
  have _ht := ht
  have hB1 : (1 : ℝ) ≤ 15 * √33 / (8 * γ) := by
    rw [le_div_iff₀ (by positivity)]
    have h5 : (5 : ℝ) ≤ √33 := by
      rw [Real.le_sqrt (by norm_num) (by norm_num)]
      norm_num
    nlinarith
  by_cases hex : ∃ n, ∃ e ∈ l, (∃ c, e.out = .corrected c) ∧ t1 ≤ e.t ∧ e.t ≤ t ∧ e.t = n
  · obtain ⟨es, hes, ⟨cs, hcs⟩, h1s, h2s, hts⟩ := Nat.find_spec hex
    have hmin : ∀ e ∈ l, (∃ c, e.out = .corrected c) → t1 ≤ e.t → e.t ≤ t → Nat.find hex ≤ e.t :=
      fun e he hc h1 h2 => Nat.find_min' hex ⟨e, he, hc, h1, h2, rfl⟩
    have hshift : intervalProd l t1 t = intervalProd l es.t t := by
      rw [hts]
      refine correctAux_intervalProd_shift l t (by omega) fun e he h1 h2 => ?_
      refine correctAux_mult_eq_one fun c hc => ?_
      have := hmin e he ⟨c, hc⟩ h1 (by omega)
      omega
    rw [hshift]
    have hP0 : 0 ≤ intervalProd l es.t t := correctAux_intervalProd_nonneg l _ _ hmult
    have hCe0 := hCe es hes
    have hC' : C ≠ 0 := hC.ne'
    have hCe' : es.C ≠ 0 := hCe0.ne'
    have hρ0 : γ / 15 * √U ≤ es.δ / es.C := hnon es hes cs hcs
    have hco := hcoord es hes
    have hρ2 : coordAt r es.g / C = -(es.δ / es.C) * intervalProd l es.t t := by
      calc coordAt r es.g / C = (coordAt r es.g * es.C) / (C * es.C) := by
            rw [mul_div_mul_right _ _ hCe']
        _ = (-es.δ * intervalProd l es.t t * C) / (C * es.C) := by rw [hco]
        _ = -(es.δ / es.C) * intervalProd l es.t t := by
            field_simp
    have habs : |coordAt r es.g / C| = es.δ / es.C * intervalProd l es.t t := by
      rw [hρ2, abs_mul, abs_neg, abs_of_nonneg (div_nonneg (hδ es hes) hCe0.le), abs_of_nonneg hP0]
    have hEr : (coordAt r es.g / C) ^ 2 ≤ 33 / 64 * U := by
      have h1 := TreeState.abs_coordAt_le_norm r es.g
      have h2 : coordAt r es.g ^ 2 ≤ ‖r‖ ^ 2 := by
        rw [← sq_abs]
        exact pow_le_pow_left₀ (abs_nonneg _) h1 2
      rw [div_pow]
      exact (div_le_div_of_nonneg_right h2 (by positivity)).trans hE
    exact (product_trap hγ hU hP0 hρ0 habs hEr).1
  · rw [correctAux_intervalProd_eq_one_of l t1 t fun e he h1 h2 =>
      correctAux_mult_eq_one fun c hc => hex ⟨e.t, e, he, ⟨c, hc⟩, h1, h2, rfl⟩]
    exact hB1

end F2e2e.C.Tree
