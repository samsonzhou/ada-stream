import Mathlib
import F2e2e.C.Tree.InvExports

/-!
# Part III §5: helper lemmas for the tree invariant

Algebra of `coordAt` on shadow vectors, the effect of each event on the components of the tree state, and the
local interval products `intervalProd` of the ghost logs (eq. `R:eq:Pint-definition`).
-/

namespace F2e2e.C.Tree

open F2e2e

/-! ## `coordAt` -/

section Coord

variable {N : ℕ}

@[simp] theorem coordAt_zero (j : ℕ) : coordAt (0 : VecN N) j = 0 := by
  unfold coordAt; split_ifs <;> simp

theorem coordAt_neg (v : VecN N) (j : ℕ) : coordAt (-v) j = -coordAt v j := by
  unfold coordAt; split_ifs <;> simp

theorem coordAt_unitVec (g : Fin N) (j : ℕ) : coordAt (unitVec g) j = if j = g.val then 1 else 0 := by
  unfold coordAt unitVec
  split_ifs with h1 h2 h2
  · subst h2; simp
  · rw [PiLp.single_apply]
    rw [if_neg]; intro h; apply h2; rw [← h]
  · omega
  · rfl

theorem coordAt_unitAt (g j : ℕ) : coordAt (unitAt N g) j = if j = g ∧ g < N then 1 else 0 := by
  by_cases hg : g < N
  · have e : unitAt N g = unitVec (⟨g, hg⟩ : Fin N) := by
      unfold unitAt unitVec; rw [dif_pos hg]
    rw [e, coordAt_unitVec]
    simp [hg]
  · have e : unitAt N g = 0 := by unfold unitAt; rw [dif_neg hg]
    rw [e, coordAt_zero]
    simp [hg]

/-- Two vectors with the same coordinates are equal. -/
theorem vec_ext_coordAt {u v : VecN N} (h : ∀ j, coordAt u j = coordAt v j) : u = v := by
  ext i
  have := h i.val
  unfold coordAt at this
  rw [dif_pos i.isLt, dif_pos i.isLt] at this
  exact this

end Coord

/-! ## The events on the components of the state -/

section Events

variable (P : StreamParams) (S : TreeSt P)

@[simp] theorem step_newRound_t : (S.step P .newRound).t = S.t + 1 := rfl
@[simp] theorem step_newRound_x0 : (S.step P .newRound).x0 = S.x0 := rfl
@[simp] theorem step_newRound_upd : (S.step P .newRound).upd = 0 := rfl
@[simp] theorem step_newRound_r : (S.step P .newRound).r = S.r := rfl
@[simp] theorem step_newRound_C : (S.step P .newRound).C = S.C := rfl
@[simp] theorem step_newRound_tb : (S.step P .newRound).tb = S.tb := rfl
@[simp] theorem step_newRound_log : (S.step P .newRound).log = S.log := rfl

@[simp] theorem step_birth_t (d : ℕ) : (S.step P (.birth d)).t = S.t := rfl
@[simp] theorem step_birth_x0 (d : ℕ) : (S.step P (.birth d)).x0 = S.x0 := rfl
@[simp] theorem step_birth_upd (d : ℕ) : (S.step P (.birth d)).upd = S.upd := rfl
theorem step_birth_r (d : ℕ) : (S.step P (.birth d)).r = Function.update S.r d (S.x d) := rfl
theorem step_birth_C (d : ℕ) : (S.step P (.birth d)).C = Function.update S.C d 1 := rfl
theorem step_birth_tb (d : ℕ) : (S.step P (.birth d)).tb = Function.update S.tb d S.t := rfl
theorem step_birth_log (d : ℕ) : (S.step P (.birth d)).log = Function.update S.log d [] := rfl

@[simp] theorem step_phys_t (i : Fin P.n) (Δ : ℤ) : (S.step P (.phys i Δ)).t = S.t := rfl
@[simp] theorem step_phys_C (i : Fin P.n) (Δ : ℤ) : (S.step P (.phys i Δ)).C = S.C := rfl
@[simp] theorem step_phys_tb (i : Fin P.n) (Δ : ℤ) : (S.step P (.phys i Δ)).tb = S.tb := rfl
@[simp] theorem step_phys_log (i : Fin P.n) (Δ : ℤ) : (S.step P (.phys i Δ)).log = S.log := rfl

@[simp] theorem step_guard_t (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) : (S.step P (.guard d g δ)).t = S.t := rfl
@[simp] theorem step_guard_upd (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    (S.step P (.guard d g δ)).upd = S.upd := rfl
@[simp] theorem step_guard_C (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) : (S.step P (.guard d g δ)).C = S.C := rfl
@[simp] theorem step_guard_tb (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    (S.step P (.guard d g δ)).tb = S.tb := rfl
theorem step_guard_log (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    (S.step P (.guard d g δ)).log =
      Function.update S.log d (⟨S.t, g.val, δ, S.C d, .pending⟩ :: S.log d) := rfl

@[simp] theorem step_accept_t (d : ℕ) : (S.step P (.accept d)).t = S.t := rfl
@[simp] theorem step_accept_x0 (d : ℕ) : (S.step P (.accept d)).x0 = S.x0 := rfl
@[simp] theorem step_accept_upd (d : ℕ) : (S.step P (.accept d)).upd = S.upd := rfl
@[simp] theorem step_accept_r (d : ℕ) : (S.step P (.accept d)).r = S.r := rfl
@[simp] theorem step_accept_C (d : ℕ) : (S.step P (.accept d)).C = S.C := rfl
@[simp] theorem step_accept_tb (d : ℕ) : (S.step P (.accept d)).tb = S.tb := rfl
theorem step_accept_log (d : ℕ) : (S.step P (.accept d)).log =
    Function.update S.log d (TreeState.setHead (fun e => { e with out := .accepted }) (S.log d)) := rfl

@[simp] theorem step_correct_t (d : ℕ) (c : ℝ) : (S.step P (.correct d c)).t = S.t := rfl
@[simp] theorem step_correct_upd (d : ℕ) (c : ℝ) : (S.step P (.correct d c)).upd = S.upd := rfl
@[simp] theorem step_correct_tb (d : ℕ) (c : ℝ) : (S.step P (.correct d c)).tb = S.tb := rfl
theorem step_correct_log (d : ℕ) (c : ℝ) : (S.step P (.correct d c)).log =
    Function.update S.log d (TreeState.setHead (fun e => { e with out := .corrected c }) (S.log d)) := rfl

end Events

/-! ## Local interval products -/

section IntervalProd

@[simp] theorem intervalProd_nil (t1 t2 : ℕ) : intervalProd [] t1 t2 = 1 := rfl

theorem intervalProd_cons (e : LogEntry) (l : List LogEntry) (t1 t2 : ℕ) :
    intervalProd (e :: l) t1 t2 =
      (if t1 ≤ e.t ∧ e.t ≤ t2 then e.out.mult else 1) * intervalProd l t1 t2 := by
  unfold intervalProd
  by_cases h : t1 ≤ e.t ∧ e.t ≤ t2
  · rw [List.filter_cons_of_pos (by simpa using h), if_pos h]; simp
  · rw [List.filter_cons_of_neg (by simpa using h), if_neg h, one_mul]

/-- If no entry lies in `[t₁, t₂]`, the product is `1`. -/
theorem intervalProd_eq_one (l : List LogEntry) (t1 t2 : ℕ)
    (h : ∀ e ∈ l, ¬ (t1 ≤ e.t ∧ e.t ≤ t2)) : intervalProd l t1 t2 = 1 := by
  induction l with
  | nil => rfl
  | cons e l ih =>
    rw [intervalProd_cons, if_neg (h e (by simp)), one_mul]
    exact ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))

/-- Two logs with the same entries' rounds and multipliers have the same interval products. -/
theorem intervalProd_congr {l l' : List LogEntry} (t1 t2 : ℕ)
    (h : l.map (fun e => (e.t, e.out.mult)) = l'.map (fun e => (e.t, e.out.mult))) :
    intervalProd l t1 t2 = intervalProd l' t1 t2 := by
  induction l generalizing l' with
  | nil =>
    cases l' with
    | nil => rfl
    | cons e' l' => simp at h
  | cons e l ih =>
    cases l' with
    | nil => simp at h
    | cons e' l' =>
      simp only [List.map_cons, List.cons.injEq, Prod.mk.injEq] at h
      rw [intervalProd_cons, intervalProd_cons, h.1.1, h.1.2, ih h.2]

/-- Interval products of logs whose entries all have rounds `≤ t` do not see rounds beyond `t`. -/
theorem intervalProd_of_le (l : List LogEntry) (t1 t2 t : ℕ) (ht : t ≤ t2) (h : ∀ e ∈ l, e.t ≤ t) :
    intervalProd l t1 t2 = intervalProd l t1 t := by
  induction l with
  | nil => rfl
  | cons e l ih =>
    have he := h e (by simp)
    rw [intervalProd_cons, intervalProd_cons, ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))]
    congr 1
    by_cases h1 : t1 ≤ e.t
    · rw [if_pos ⟨h1, by omega⟩, if_pos ⟨h1, he⟩]
    · rw [if_neg (fun h' => h1 h'.1), if_neg (fun h' => h1 h'.1)]

/-- Positivity and the multiplier bounds give positive interval products. -/
theorem intervalProd_pos (l : List LogEntry) (t1 t2 : ℕ) (h : ∀ e ∈ l, 0 < e.out.mult) :
    0 < intervalProd l t1 t2 := by
  induction l with
  | nil => simp
  | cons e l ih =>
    rw [intervalProd_cons]
    apply mul_pos
    · split_ifs
      · exact h e (by simp)
      · exact one_pos
    · exact ih (fun e' he' => h e' (List.mem_cons_of_mem _ he'))

end IntervalProd

end F2e2e.C.Tree
