import Mathlib
import F2e2e.C.Tree.Event
import F2e2e.C.Tree.Basic

/-!
# Part III §5: the tree shadow (analytical vectors of Definition 5.1 (3)) and its events

Source: `parts/partIII.tex` Definition `R:def:binary-tree-architecture` (3) (L433–437), the analytical
semantics of Algorithm `R:alg:within-round-tree` (L466–517), Lemma `R:lem:homogeneous-child-rescaling`
(L527–585), Lemma `R:lem:guard-orthogonality` (L594–616), Lemma `R:lem:terminal-accumulator` (L519–525).

## Representation (residual form)

The paper's learner vectors `x_d = a_d + q_d = r_d + y_d`, `r_d = a_d − u_d`, `y_d = u_d + q_d = x_{d+1}` are
represented by the root input `x_0` (the physical stream vector, embedded in `ℝ^{D_*}`), the residuals
`r_d` (`d < H`) and the exact strict-ancestor tags `C_d`:
`x_d = x_0 − Σ_{j<d} r_j`, `y_d = x_{d+1} = x_d − r_d`, `E_d = ‖r_d‖²`, `Q_d = ‖y_d‖²`,
`Ẽ_d = E_d/C_d²` (eq. `R:eq:birth-normalized-energy-def`). The events act as the paper prescribes
(map item III.5.ALG "analytical semantics"):
* birth of `d`: `a_d := x_d`, `u_d = q_d = 0`, `C_d := 1`, i.e. `r_d := x_d`, `C_d := 1` (then `y_d = 0`);
* physical update: `q_d += Δ e_i` for all `d`, i.e. `x_0 += Δ e_i` (all `x_d`, `y_d` gain `Δe_i`, `r` unchanged);
* guard of depth `d`: `u_d += δ e_g`, `q_{d'} += δ e_g` (`d' > d`), i.e. `r_d −= δ e_g`;
* correction of depth `d` by `c = 1 + a`: `u_d += a y_d` and `(a,q,u,C)_{d'} ← c·(a,q,u,C)_{d'}` (`d' > d`),
  i.e. `r_d ← r_d − a y_d`, `r_{d'} ← c r_{d'}`, `C_{d'} ← c C_{d'}` (then `y_d ← c y_d`, `x_{d'} ← c x_{d'}`).

Correspondence with the algorithm's registers (Definition 5.1 (3), Algorithm L482, L491, L505–508): the primary
array of bank `𝓑_{d−1}` measures `x_d`, its secondary array `y_d`, its `DIFF` mode `r_d`; the cache `P_d` tracks
`E_d`; the tag `Ĉ_d` tracks `C_d`; the terminal accumulator holds `‖x_H‖²`.

## Ghost log

Every learner keeps, since its birth, one `LogEntry` per round that entered Step 3: the round `t`, the Lean index
`g` of its guard coordinate `g(d,t)`, the guard amplitude `δ`, the exact tag `C_d` at Step 3, and the Step-4
outcome (`pending`, `accepted`, or `corrected c`). The local interval products of Theorem 5.11 (1)
(eq. `R:eq:Pint-definition`) are `intervalProd (S.log d) t₁ t₂` (`F2e2e/C/Tree/Inv.lean`).

The state is parametrized by the ambient dimension `N` (`= D_*`; see the note in `Event.lean`), `TreeSt P` is
the instance for the parameters `P`.
-/

namespace F2e2e.C.Tree

open F2e2e

/-- `ℝ^N` (Euclidean). -/
abbrev VecN (N : ℕ) := EuclideanSpace ℝ (Fin N)

/-- The ambient space `ℝ^{D_*}` of the shadow vectors; Lean index `j` ↔ paper coordinate `j + 1`
(physical coordinates `0..n−1`, guard `g(d,t)` ↔ `n + H(t−1) + d`, regularizer ↔ `D_* − 1`). -/
abbrev Vec (P : StreamParams) := VecN P.Dstar

/-- The unit vector of the Lean index `j`. -/
noncomputable def unitVec {N : ℕ} (j : Fin N) : VecN N := EuclideanSpace.single j 1

/-- The unit vector of the Lean index `j` given as a natural number (`0` if `j ≥ N`). -/
noncomputable def unitAt (N j : ℕ) : VecN N :=
  if h : j < N then EuclideanSpace.single (⟨j, h⟩ : Fin N) 1 else 0

/-- The coordinate of Lean index `j` (a natural number) of a vector (`0` if `j ≥ N`). -/
noncomputable def coordAt {N : ℕ} (v : VecN N) (j : ℕ) : ℝ :=
  if h : j < N then v ⟨j, h⟩ else 0

theorem unitVec_eq_unitAt {N : ℕ} (j : Fin N) : unitVec j = unitAt N j.val := by
  simp [unitVec, unitAt, j.isLt]

/-- Lean index of the physical coordinate `i` (paper coordinate `i + 1`). -/
def physIdx (P : StreamParams) (i : Fin P.n) : Fin P.Dstar :=
  ⟨i.val, by have := i.isLt; unfold StreamParams.Dstar; omega⟩

/-- Lean index (a natural number) of the guard coordinate `g(d,t)`: `n + H(t−1) + d`
(paper coordinate `g(d,t) = n + H(t−1) + d + 1`, eq. `R:eq:guard-index-def`). -/
def guardIdx (P : StreamParams) (d t : ℕ) : ℕ := P.guardCoord d t - 1

/-- The Step-4 outcome of a learner in one round. -/
inductive Outcome where
  /-- Step 3 done, Step 4 not yet evaluated -/
  | pending : Outcome
  /-- `ACCEPT` -/
  | accepted : Outcome
  /-- rejection, local correction with multiplier `c = 1 + a_step` -/
  | corrected (c : ℝ) : Outcome

/-- The local multiplier of an outcome (`1` unless corrected). -/
def Outcome.mult : Outcome → ℝ
  | .corrected c => c
  | _ => 1

/-- One ghost record of a learner: one per round that entered Step 3. -/
structure LogEntry where
  /-- the round `t` -/
  t : ℕ
  /-- the Lean index of the guard coordinate `g(d,t)` -/
  g : ℕ
  /-- the guard amplitude `δ_d(t)` (possibly `0`) -/
  δ : ℝ
  /-- the exact tag `C_d(t)` at Step 3 of round `t` -/
  C : ℝ
  /-- the Step-4 outcome of round `t` -/
  out : Outcome

/-- The tree shadow together with its ghost data, in ambient dimension `N`. -/
structure TreeState (N : ℕ) where
  /-- the current round (`0` before round `1`) -/
  t : ℕ
  /-- the root input `x_0` (the physical stream vector, on the indices `0..n−1`) -/
  x0 : VecN N
  /-- the physical update of the current round (`Δ e_i`; `0` before Step 2) -/
  upd : VecN N
  /-- the residuals `r_d` (`d < H`) -/
  r : ℕ → VecN N
  /-- the exact strict-ancestor tags `C_d` -/
  C : ℕ → ℝ
  /-- the birth round of the current learner of depth `d` -/
  tb : ℕ → ℕ
  /-- the ghost log of the current learner of depth `d`, most recent round first -/
  log : ℕ → List LogEntry

/-- The tree state for the parameters `P` (`N = D_*`). -/
abbrev TreeSt (P : StreamParams) := TreeState P.Dstar

namespace TreeState

variable {N : ℕ}

/-- The input vector `x_d = x_0 − Σ_{j<d} r_j`. -/
noncomputable def x (S : TreeState N) (d : ℕ) : VecN N := S.x0 - ∑ j ∈ Finset.range d, S.r j

/-- The outgoing vector `y_d = x_{d+1}`. -/
noncomputable def y (S : TreeState N) (d : ℕ) : VecN N := S.x (d + 1)

/-- The residual energy `E_d = ‖r_d‖²`. -/
noncomputable def E (S : TreeState N) (d : ℕ) : ℝ := ‖S.r d‖ ^ 2

/-- The outgoing energy `Q_d = ‖y_d‖²`. -/
noncomputable def Q (S : TreeState N) (d : ℕ) : ℝ := ‖S.y d‖ ^ 2

/-- The birth-normalized residual energy `Ẽ_d = E_d/C_d²` (eq. `R:eq:birth-normalized-energy-def`). -/
noncomputable def Et (S : TreeState N) (d : ℕ) : ℝ := S.E d / S.C d ^ 2

/-- The initial tree state (before round `1`). -/
def init (N : ℕ) : TreeState N := ⟨0, 0, 0, fun _ => 0, fun _ => 1, fun _ => 0, fun _ => []⟩

/-- Modify the most recent entry of a log. -/
def setHead (f : LogEntry → LogEntry) : List LogEntry → List LogEntry
  | [] => []
  | e :: l => f e :: l

/-- One event (see `F2e2e/C/Tree/Event.lean` and the module docstring). -/
noncomputable def step (P : StreamParams) (S : TreeSt P) : TreeEv P → TreeSt P
  | .newRound => { S with t := S.t + 1, upd := 0 }
  | .birth d =>
      { S with r := Function.update S.r d (S.x d), C := Function.update S.C d 1,
               tb := Function.update S.tb d S.t, log := Function.update S.log d [] }
  | .phys i Δ =>
      { S with x0 := S.x0 + (Δ : ℝ) • unitVec (physIdx P i),
               upd := (Δ : ℝ) • unitVec (physIdx P i) }
  | .guard d g δ =>
      { S with r := Function.update S.r d (S.r d - δ • unitVec g),
               log := Function.update S.log d (⟨S.t, g.val, δ, S.C d, .pending⟩ :: S.log d) }
  | .accept d =>
      { S with log := Function.update S.log d (setHead (fun e => { e with out := .accepted }) (S.log d)) }
  | .correct d c =>
      { S with r := fun j => if j = d then S.r d - (c - 1) • S.y d else if d < j then c • S.r j else S.r j,
               C := fun j => if d < j then c * S.C j else S.C j,
               log := Function.update S.log d
                 (setHead (fun e => { e with out := .corrected c }) (S.log d)) }

/-- Run a list of events (first event first). -/
noncomputable def run (P : StreamParams) (S : TreeSt P) (evs : List (TreeEv P)) : TreeSt P :=
  evs.foldl (step P) S

/-! ## The fields after one event (definitional) -/

theorem step_correct_x0 (P : StreamParams) (S : TreeSt P) (d : ℕ) (c : ℝ) :
    (S.step P (.correct d c)).x0 = S.x0 := rfl

theorem step_correct_r (P : StreamParams) (S : TreeSt P) (d : ℕ) (c : ℝ) (j : ℕ) :
    (S.step P (.correct d c)).r j =
      if j = d then S.r d - (c - 1) • S.y d else if d < j then c • S.r j else S.r j := rfl

theorem step_correct_C (P : StreamParams) (S : TreeSt P) (d : ℕ) (c : ℝ) (j : ℕ) :
    (S.step P (.correct d c)).C j = if d < j then c * S.C j else S.C j := rfl

theorem step_guard_x0 (P : StreamParams) (S : TreeSt P) (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    (S.step P (.guard d g δ)).x0 = S.x0 := rfl

theorem step_guard_r (P : StreamParams) (S : TreeSt P) (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) :
    (S.step P (.guard d g δ)).r = Function.update S.r d (S.r d - δ • unitVec g) := rfl

theorem step_phys_x0 (P : StreamParams) (S : TreeSt P) (i : Fin P.n) (Δ : ℤ) :
    (S.step P (.phys i Δ)).x0 = S.x0 + (Δ : ℝ) • unitVec (physIdx P i) := rfl

theorem step_phys_r (P : StreamParams) (S : TreeSt P) (i : Fin P.n) (Δ : ℤ) :
    (S.step P (.phys i Δ)).r = S.r := rfl

theorem step_phys_upd (P : StreamParams) (S : TreeSt P) (i : Fin P.n) (Δ : ℤ) :
    (S.step P (.phys i Δ)).upd = (Δ : ℝ) • unitVec (physIdx P i) := rfl

/-! ## Basic identities -/

/-- `x_{d+1} = x_d − r_d` (eq. `R:eq:sec5-learner-decomposition`: `y_d = x_d − r_d`). -/
theorem x_succ (S : TreeState N) (d : ℕ) : S.x (d + 1) = S.x d - S.r d := by
  simp only [x, Finset.sum_range_succ]
  abel

/-- `x_d = r_d + y_d` (eq. `R:eq:sec5-learner-decomposition`). -/
theorem r_add_y (S : TreeState N) (d : ℕ) : S.r d + S.y d = S.x d := by
  rw [y, x_succ]
  abel

/-! ## The events on the derived vectors (Lemma 5.4 in the shadow model) -/

/-- A correction of depth `d` leaves `x_{d'}` unchanged for `d' ≤ d` (in particular its own input:
"a child's correction does not change that child's incoming vector", partIII.tex L1293). -/
theorem x_correct_of_le (P : StreamParams) (S : TreeSt P) {d d' : ℕ} (c : ℝ) (h : d' ≤ d) :
    (S.step P (.correct d c)).x d' = S.x d' := by
  have hs : ∑ j ∈ Finset.range d', (S.step P (.correct d c)).r j = ∑ j ∈ Finset.range d', S.r j := by
    refine Finset.sum_congr rfl fun j hj => ?_
    have hj' : j < d' := Finset.mem_range.mp hj
    rw [step_correct_r, if_neg (by omega), if_neg (by omega)]
  simp only [x, step_correct_x0, hs]

/-- Lemma 5.4 (i) in the shadow model (eq. `R:eq:single-step-child-rescaling`): a correction of depth `d` by
`c = 1 + a` gives `r_d⁺ = r_d − a y_d` and `y_d⁺ = c y_d`; every strict descendant input is rescaled,
`x_{d'}⁺ = c x_{d'}` (`d' > d`). -/
theorem correct_rescale (P : StreamParams) (S : TreeSt P) (d : ℕ) (c : ℝ) :
    (S.step P (.correct d c)).r d = S.r d - (c - 1) • S.y d ∧
      (S.step P (.correct d c)).y d = c • S.y d ∧
      ∀ d', d < d' → (S.step P (.correct d c)).x d' = c • S.x d' := by
  have h1 : (S.step P (.correct d c)).r d = S.r d - (c - 1) • S.y d := by
    rw [step_correct_r, if_pos rfl]
  have h2 : (S.step P (.correct d c)).y d = c • S.y d := by
    rw [y, x_succ, x_correct_of_le P S c le_rfl, h1]
    have : S.y d = S.x d - S.r d := by rw [y, x_succ]
    rw [this, sub_smul, one_smul]
    abel
  refine ⟨h1, h2, fun d' hd' => ?_⟩
  induction d', hd' using Nat.le_induction with
  | base => rw [← y, h2, y]
  | succ k hk ih =>
    rw [x_succ, x_succ, ih, step_correct_r, if_neg (by omega), if_pos (by omega), smul_sub]

/-- Lemma 5.4 (iii)(b) in the shadow model: a strict-ancestor correction (`d < d'`, `c ≠ 0`) leaves the
birth-normalized residual energy `Ẽ_{d'}` unchanged. -/
theorem Et_correct_of_lt (P : StreamParams) (S : TreeSt P) {d d' : ℕ} {c : ℝ} (hc : c ≠ 0)
    (h : d < d') : (S.step P (.correct d c)).Et d' = S.Et d' := by
  simp only [Et, E]
  rw [step_correct_r, if_neg (by omega), if_pos h, step_correct_C, if_pos h, norm_smul,
    Real.norm_eq_abs, mul_pow, sq_abs, mul_pow]
  exact mul_div_mul_left _ _ (pow_ne_zero 2 hc)

/-- A guard of depth `d` leaves `x_{d'}` unchanged for `d' ≤ d` and adds `δ e_g` to `x_{d'}` for `d' > d`
(Lemma 5.6 (1), (3)). -/
theorem x_guard (P : StreamParams) (S : TreeSt P) (d : ℕ) (g : Fin P.Dstar) (δ : ℝ) (d' : ℕ) :
    (S.step P (.guard d g δ)).x d' = if d < d' then S.x d' + δ • unitVec g else S.x d' := by
  have hpt : ∀ j, (S.step P (.guard d g δ)).r j = S.r j - (if j = d then δ • unitVec g else 0) := by
    intro j
    rw [step_guard_r]
    by_cases hj : j = d
    · subst hj; simp
    · simp [hj]
  simp only [x, step_guard_x0, hpt, Finset.sum_sub_distrib, Finset.sum_ite_eq', Finset.mem_range]
  split_ifs <;> abel

/-- A physical update adds `Δ e_i` to every `x_{d'}` and leaves every `r_{d'}` unchanged (Lemma 5.4 (iii)(a)). -/
theorem x_phys (P : StreamParams) (S : TreeSt P) (i : Fin P.n) (Δ : ℤ) (d' : ℕ) :
    (S.step P (.phys i Δ)).x d' = S.x d' + (Δ : ℝ) • unitVec (physIdx P i) ∧
      (S.step P (.phys i Δ)).r d' = S.r d' := by
  refine ⟨?_, by rw [step_phys_r]⟩
  simp only [x, step_phys_x0, step_phys_r]
  abel

/-- The norm of the physical update of a round is `|Δ|` (for Lemma 5.3). -/
theorem norm_upd_phys (P : StreamParams) (S : TreeSt P) (i : Fin P.n) (Δ : ℤ) :
    ‖(S.step P (.phys i Δ)).upd‖ ^ 2 = (Δ : ℝ) ^ 2 := by
  simp [step_phys_upd, unitVec, norm_smul, sq_abs]

/-- The norm of a vector bounds each of its coordinates (external input "a single coordinate is at most the
norm", used in Lemma 5.8 (iii) and Theorem 5.11 (1)). -/
theorem abs_coordAt_le_norm (v : VecN N) (j : ℕ) : |coordAt v j| ≤ ‖v‖ := by
  unfold coordAt
  split_ifs with h
  · rw [← Real.norm_eq_abs]
    exact PiLp.norm_apply_le v ⟨j, h⟩
  · rw [abs_zero]; exact norm_nonneg v

end TreeState

end F2e2e.C.Tree
