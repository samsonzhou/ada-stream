import F2e2e.C.ClosureProbAda
import F2e2e.C.ClosureProbCoarse

/-!
# Theorem 6.4, probability layer (C-PROB): the all-birth union bound for the bank events

Paper: `parts/partIII.tex` L1281–1285: "At most `2m(H+1)` bank labels can ever be born, and their birth schedule is
independent of corrections. Thus `Pr[any statistical failure] ≤ β₀/8 + 2m(H+1)β_B = 5β₀/32 < β`"
(eq. `R:eq:global-failure-budget`). This file proves the bank part `2m(H+1)β_B = β₀/32` as a tape count
(`card_not_bankGood_le`); the fingerprint part `β₀/8` is C-FP's, and C-CLOSE's `Final.lean` adds the two.

Per label `λ ∈ labelSet P` (`|labelSet P| ≤ 2m(H+1)`, `card_labelSet_le`): the ADA event fails on at most a `β_B/2`
fraction of the tapes (`card_not_adaGood_le`) and each of its `R_max` coarse events on at most `β_B/(2R_max)`
(`card_not_coarseGood_le`); labels outside `labelSet P` and groups `k ≥ R_max` never fail
(`adaGood_of_not_mem`, `coarseGood_of_not_mem`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-- The budget arithmetic: `|labelSet P|·(β_B/2 + R_max·β_B/(2R_max)) ≤ 2m(H+1)·β_B = β₀/32`
(partIII.tex L1283, with `β_B = β₀/(64m(H+1))`). -/
theorem labels_budget (P : StreamParams) (hP : ParamsOK P) (X : ℝ) (hX : 0 ≤ X) :
    ((labelSet P).card : ℝ) *
        ((P.betaB : ℝ) / 2 * X + (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X)) ≤
      (P.beta0 : ℝ) / 32 * X := by
  have hm : (1 : ℝ) ≤ P.m := by exact_mod_cast hP.one_le_m
  have hR : (P.Rmax : ℝ) ≠ 0 := by
    have : 0 < P.Rmax := by unfold StreamParams.Rmax; omega
    exact_mod_cast this.ne'
  have hβ : (P.betaB : ℝ) = (P.beta0 : ℝ) / (64 * P.m * (P.H + 1)) := by
    rw [StreamParams.betaB]; push_cast; ring
  have hβ0 : (0 : ℝ) ≤ P.beta0 := by exact_mod_cast (StreamParams.beta0_pos P).le
  have hlab : ((labelSet P).card : ℝ) ≤ 2 * P.m * (P.H + 1) := by
    exact_mod_cast card_labelSet_le P hP.one_le_m
  have hRβ : (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X) = (P.betaB : ℝ) / 2 * X := by
    field_simp
  have hinner : (P.betaB : ℝ) / 2 * X + (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X) =
      (P.betaB : ℝ) * X := by
    rw [hRβ]; ring
  rw [hinner]
  have hβX : 0 ≤ (P.betaB : ℝ) * X := by
    rw [hβ]; positivity
  have hH : (P.H : ℝ) + 1 ≠ 0 := by positivity
  have hm0 : (P.m : ℝ) ≠ 0 := by positivity
  calc ((labelSet P).card : ℝ) * ((P.betaB : ℝ) * X) ≤ (2 * P.m * (P.H + 1)) * ((P.betaB : ℝ) * X) :=
        mul_le_mul_of_nonneg_right hlab hβX
    _ = (P.beta0 : ℝ) / 32 * X := by
        rw [hβ]
        field_simp
        ring

/-- **C-PROB's target** (partIII.tex L1281–1285): the bank events fail on at most a `β₀/32` fraction of the tapes. -/
theorem card_not_bankGood_le (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) :
    (({tapes | ¬ BankGood P adv tapes} : Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      (P.beta0 : ℝ) / 32 * 2 ^ ((P.m + 1) * tapeBits P) := by
  classical
  set X : ℝ := 2 ^ ((P.m + 1) * tapeBits P) with hX
  let A : BankLabel → Finset (Fin (P.m + 1) → Fin (tapeBits P) → Bool) := fun lab =>
    Finset.univ.filter fun tapes => ∃ c, theAlgL.run P adv tapes P.m = some c ∧ ¬ AdaGood P lab c.1.2
  let C : BankLabel → ℕ → Finset (Fin (P.m + 1) → Fin (tapeBits P) → Bool) := fun lab k =>
    Finset.univ.filter fun tapes =>
      ∃ c, theAlgL.run P adv tapes P.m = some c ∧ ¬ CoarseGood P lab k c.1.2
  -- every bad tape is bad for the ADA event or a coarse event `k < R_max` of a label of `labelSet P`
  have hsub : (Finset.univ.filter fun tapes => ¬ BankGood P adv tapes) ⊆
      (labelSet P).biUnion fun lab => A lab ∪ (Finset.range P.Rmax).biUnion (C lab) := by
    intro tapes htapes
    rw [Finset.mem_filter] at htapes
    rw [Finset.mem_biUnion]
    by_contra hcon
    apply htapes.2
    intro c hc lab
    by_cases hlab : lab ∈ labelSet P
    · refine ⟨?_, fun k => ?_⟩
      · by_contra hAd
        exact hcon ⟨lab, hlab,
          Finset.mem_union_left _ (Finset.mem_filter.2 ⟨Finset.mem_univ _, c, hc, hAd⟩)⟩
      · by_cases hk : k < P.Rmax
        · by_contra hCo
          exact hcon ⟨lab, hlab, Finset.mem_union_right _ (Finset.mem_biUnion.2
            ⟨k, Finset.mem_range.2 hk, Finset.mem_filter.2 ⟨Finset.mem_univ _, c, hc, hCo⟩⟩)⟩
        · exact coarseGood_of_not_mem P adv tapes c hc lab k (Or.inr (not_lt.1 hk))
    · exact ⟨adaGood_of_not_mem P adv tapes c hc lab hlab,
        fun k => coarseGood_of_not_mem P adv tapes c hc lab k (Or.inl hlab)⟩
  -- the per-event counts
  have hA : ∀ lab, ((A lab).card : ℝ) ≤ (P.betaB : ℝ) / 2 * X := fun lab =>
    (congrArg (fun n : ℕ => (n : ℝ)) (ncard_setOf_eq_card_filter _).symm).trans_le
      (card_not_adaGood_le P hP adv lab)
  have hC : ∀ lab k, ((C lab k).card : ℝ) ≤ (P.betaB : ℝ) / (2 * P.Rmax) * X := fun lab k =>
    (congrArg (fun n : ℕ => (n : ℝ)) (ncard_setOf_eq_card_filter _).symm).trans_le
      (card_not_coarseGood_le P hP adv lab k)
  have hCsum : ∀ lab, ∑ k ∈ Finset.range P.Rmax, ((C lab k).card : ℝ) ≤
      (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X) := fun lab => by
    calc ∑ k ∈ Finset.range P.Rmax, ((C lab k).card : ℝ) ≤
          ∑ _k ∈ Finset.range P.Rmax, ((P.betaB : ℝ) / (2 * P.Rmax) * X) :=
          Finset.sum_le_sum fun k _ => hC lab k
      _ = (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X) := by
          rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  -- the union bound
  have hcardN : (Finset.univ.filter fun tapes => ¬ BankGood P adv tapes).card ≤
      ∑ lab ∈ labelSet P, ((A lab).card + ∑ k ∈ Finset.range P.Rmax, (C lab k).card) := by
    refine (Finset.card_le_card hsub).trans
      (Finset.card_biUnion_le.trans (Finset.sum_le_sum fun lab _ => ?_))
    exact (Finset.card_union_le _ _).trans (Nat.add_le_add_left Finset.card_biUnion_le _)
  have hcardR : ((Finset.univ.filter fun tapes => ¬ BankGood P adv tapes).card : ℝ) ≤
      ∑ lab ∈ labelSet P, (((A lab).card : ℝ) + ∑ k ∈ Finset.range P.Rmax, ((C lab k).card : ℝ)) := by
    exact_mod_cast hcardN
  have hsum : ∑ lab ∈ labelSet P,
        (((A lab).card : ℝ) + ∑ k ∈ Finset.range P.Rmax, ((C lab k).card : ℝ)) ≤
      ((labelSet P).card : ℝ) *
        ((P.betaB : ℝ) / 2 * X + (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X)) := by
    have := Finset.sum_le_card_nsmul (labelSet P)
      (fun lab => ((A lab).card : ℝ) + ∑ k ∈ Finset.range P.Rmax, ((C lab k).card : ℝ))
      ((P.betaB : ℝ) / 2 * X + (P.Rmax : ℝ) * ((P.betaB : ℝ) / (2 * P.Rmax) * X))
      (fun lab _ => add_le_add (hA lab) (hCsum lab))
    rwa [nsmul_eq_mul] at this
  have hX0 : (0 : ℝ) ≤ X := by positivity
  calc (({tapes | ¬ BankGood P adv tapes} : Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ)
        = ((Finset.univ.filter fun tapes => ¬ BankGood P adv tapes).card : ℝ) := by
          rw [ncard_setOf_eq_card_filter]
    _ ≤ _ := hcardR
    _ ≤ _ := hsum
    _ ≤ (P.beta0 : ℝ) / 32 * X := labels_budget P hP X hX0

end F2e2e.C.Closure
