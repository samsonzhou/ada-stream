import Mathlib
import F2e2e.C.ClosureInv
import F2e2e.C.ClosureTreeStepTree
import F2e2e.C.ClosureTreeWit

/-!
# Theorem 6.4, tree side: the tree part of the invariant through every block of a round
(proofs: C-TREE and 295bf129; statements: C-CLOSE)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree` (L466–517, as coded in
`F2e2e/C/Alg/AlgMCode.lean`), the chronological induction of Theorem `R:thm:chronological-closure-and-main-proof`
(L1287–1317), Lemma `R:lem:sec6-precision` (ii) (tags), Lemma `R:lem:sec6-covariant-cache` (caches), Lemma 5.3
(accumulator), and C-TREE's step lemmas `Tree.treeInv_*` (`F2e2e/C/Tree/Inv.lean`).

Every lemma is **pure** (no `AlgM`): for one block of the controller code it maps the tree part
`TreePart P ph c S nev` (`F2e2e/C/ClosureInv.lean`) at the moment `ph` to the tree part at the next moment, for the
controller state `c'` computed exactly as the code does and the tree shadow after the block's analysis event
(`(S.step P ev)`, `ev` the image under `toTreeEv` of the block's `noteM`), with `nev + 1` events; and it asserts
that the range / cap checks of the block pass (so the code does not enter the failure state). The bank outputs
used by a block enter as hypotheses in the certificate form produced by the bank side (`ValCertCore`, `NumCert`,
`F2e2e/C/ClosureBank.lean`), already translated to the tree shadow:
* `ValidateInterval(S, θ)` of depth `d` (bank `d`, primary array `= x_d`): `r = (‖x_d‖² + ω)/(S + ω)`;
* `ReleaseNumerical(PRIMARY)` of bank `d` (`N` at a birth, `N₁` at a rejection): `NumCert η ω ‖x_d‖² N`;
* `ReleaseNumerical(DIFF)` of bank `d` after the correction (`N₂`): `NumCert η ω ‖r_d⁺‖² N₂`.
`nev ≤ T` (the number of analysis events, `≤ (3H+2)m`) bounds the number of rounding errors in every witness.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Initialization and Step 1 -/

/-- Round `1` starts from the initial tree state with no learner. -/
theorem treePart_init (hP : ParamsOK P) (c : CState) (hc : c.learners = []) :
    TreePart P (.births 0) c ((Tree.TreeState.init P.Dstar).step P .newRound) 1 :=
  TreePart.mk_wit (tree_init hP c) (by rw [hc]; rfl)
    (fun D hD hlt => by cases hD; exact absurd hlt (Nat.not_lt_zero _)) (witSide_init c)

/-- A new round `t + 1 ≤ m` (`noteM newRound`, then Step 1's `bankRetainM (d₀+1)` and the retirement of the
learners `≥ d₀`, `d₀ = firstBorn H (t+1)`). -/
theorem treePart_newRound (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P .idle c S nev) (ht : S.t < P.m) :
    TreePart P (.births (firstBorn P.H (S.t + 1)))
      { c with learners := c.learners.take (firstBorn P.H (S.t + 1)) } (S.step P .newRound) (nev + 1) := by
  have hd0 : firstBorn P.H (S.t + 1) < P.H := firstBorn_lt P.H (S.t + 1) P.one_le_H
  refine TreePart.mk_wit (tree_newRound h ht) ?_ ?_ (witSide_newRound h)
  · show (c.learners.take (firstBorn P.H (S.t + 1))).length = firstBorn P.H (S.t + 1)
    rw [List.length_take, h.nLearners]
    exact min_eq_left hd0.le
  · intro D hD hlt
    cases hD
    exact absurd hlt (lt_irrefl _)

/-- The birth of depth `d` (`birthCode`, after its bank operations): the new learner `newLearner P cache` with
the birth cache `cache = 0` when the input `x_d` is known to vanish, or `cache = round_{h_P}(N)` for the release
`N ≥ 0` of `x_d` with its numerical certificate. The box promise for the current vector bounds `‖x_0‖ ≤ W`.
The range check of the birth cache passes. -/
theorem treePart_birth (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.births d) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) {cache : ℤ}
    (hcache : (cache = 0 ∧ S.x d = 0) ∨
      ∃ N : ℚ, 0 ≤ N ∧ cache = roundMant P.eHP N ∧
        NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N : ℝ)) :
    inRangeA P (gridVal P.eHP cache) = true ∧
      TreePart P (.births (d + 1)) { c with learners := c.learners ++ [newLearner P cache] }
        (S.step P (.birth d)) (nev + 1) :=
  ⟨wit_birth_range h hd hbox hcache,
    TreePart.mk_wit (tree_birth hP h hd hbox cache) (tree_nLearners_birth h cache) (tree_bornZero_birth S d)
      (witSide_birth h hcache)⟩

/-! ## Step 2 and the zero bypass -/

/-- Step 2 (`step2Code`): the physical update `x_{i+1} += Δ` (Lean index `i`), the accumulator
`round_{h_leaf}(Δ²)`; the box promise for the new vector. The range check of the accumulator passes. -/
theorem treePart_phys (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P (.births P.H) c S nev) (i : Fin P.n) (Δ : ℤ)
    (hbox : ‖(S.step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ)) :
    inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) = true ∧
      TreePart P (.guards 0) { c with leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2) } (S.step P (.phys i Δ))
        (nev + 1) := by
  have hT := tree_phys h i Δ (roundMant P.eHleaf ((Δ : ℚ) ^ 2))
  exact ⟨wit_phys_range h i Δ hT hbox,
    TreePart.mk_wit hT h.nLearners (fun D hD => by cases hD) (witSide_phys h i Δ)⟩

/-- The zero-round bypass (Steps 3–4 omitted). -/
theorem treePart_bypass {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards 0) c S nev) :
    TreePart P .idle c S nev :=
  TreePart.mk_wit (tree_bypass h) h.nLearners (fun D hD => by cases hD) (witSide_bypass h)

/-! ## Step 3 -/

/-- Step 3 at depth `d` of round `t = c.t + 1 = S.t` (`step3DepthCode`), omitted guard (`δ = 0`): the analysis
event `guard d g 0` on the Lean index `g(d,t) − 1`. -/
theorem treePart_guard_zero (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (hd : d < P.H) (ht : c.t + 1 = S.t) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hnev : nev + 1 ≤ P.T) {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (hδ : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0)
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    TreePart P (.guards (d + 1)) c
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg 0 : ℚ) : ℝ))) (nev + 1) :=
  TreePart.mk_wit (tree_guard_zero h hd ht hLd (TreePart.tagPrec h (by omega) hd) hδ hg) h.nLearners
    (fun D hD => by cases hD) (witSide_guard_zero h _ (by simp [gridVal]))

/-- Step 3 at depth `d`, injected guard `δ ≠ 0`: the cache `round_{h_P}(P_d + δ²)` and the accumulator
`round_{h_leaf}(acc + δ²)` (both range checks pass). -/
theorem treePart_guard (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (hd : d < P.H) (ht : c.t + 1 = S.t) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hnev : nev + 1 ≤ P.T) {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (hδ : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) ≠ 0)
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    inRangeA P (gridVal P.eHP (roundMant P.eHP (gridVal P.eHP Ld.cache +
        gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))) = true ∧
      inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHleaf c.leaf +
        gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))) = true ∧
      TreePart P (.guards (d + 1))
        { c with
          learners := setAt { Ld with cache := roundMant P.eHP (gridVal P.eHP Ld.cache +
            gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2) } d c.learners,
          leaf := roundMant P.eHleaf (gridVal P.eHleaf c.leaf +
            gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2) }
        (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩
          ((gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) : ℚ) : ℝ)))
        (nev + 1) := by
  have hT := tree_guard h hd ht hLd (TreePart.tagPrec h (by omega) hd) hg
    (roundMant P.eHP (gridVal P.eHP Ld.cache +
      gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))
    (roundMant P.eHleaf (gridVal P.eHleaf c.leaf +
      gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) ^ 2))
  obtain ⟨r1, r2⟩ := wit_guard_range h hd ht hbox hnev hLd _ hg hT
  exact ⟨r1, r2, TreePart.mk_wit hT (tree_nLearners_guard h _) (fun D hD => by cases hD)
    (witSide_guard h hd ht hLd _ hg)⟩

/-! ## Step 4 -/

/-- The end of Step 3 is the start of Step 4; the returned value starts as the accumulator `= ‖x_H‖²`. -/
theorem treePart_startStep4 {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards P.H) c S nev) :
    TreePart P (.evals P.H) c S nev ∧ leafVal P c = ‖S.x P.H‖ ^ 2 :=
  ⟨TreePart.mk_wit (tree_startStep4 h) h.nLearners (fun D hD => by cases hD) (witSide_startStep4 h).1,
    (witSide_startStep4 h).2⟩

/-- Step 4 at depth `d` (`step4DepthCode`), the range check of `S = P_d + Q̂` before the validation passes, for a
returned value `Q̂ = F ≥ 0` of the child accuracy (Theorem 5.9 (1) at height `ℓ − 1`, `ℓ = H − d`). -/
theorem treePart_eval_range (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (hnev : nev ≤ P.T)
    {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) :
    inRangeA P (gridVal P.eHP Ld.cache + F) = true :=
  wit_eval_range h hd hbox hnev hF0 hF hLd

/-- Step 4 at depth `d`, `ACCEPT` (Theorem 5.9 (2)): on a nonzero round, with the certificate of the validation
of `S = P_d + Q̂` at `θ = (8ℓ+4)η`, the returned value `S` has accuracy `8(ℓ+1)η` for `‖x_d‖²`. -/
theorem treePart_accept (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hnev : nev + 1 ≤ P.T) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (hcert : |(‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1| ≤
      (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) + (P.eta : ℝ) / 4) :
    TreePart P (.evals d) c (S.step P (.accept d)) (nev + 1) ∧
      |((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) - ‖S.x d‖ ^ 2| ≤
        8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 :=
  ⟨TreePart.mk_wit (tree_accept h hd) h.nLearners (fun D hD => by cases hD) (witSide_accept h hd),
    accept_acc h hd hx0 hF0 hLd hcert⟩

/-- Step 4 at depth `d`, rejection with sign `s = ±1` (`pos = true` iff `HIGH`), before the correction
(`rejectDepthCode`): the client cap and the positive-denominator rule pass; for the release `N₁ ≥ 0` of `x_d`
with its numerical certificate, its range check passes and it has accuracy `8(ℓ+1)η` (Theorem 5.9 (2),
eq. `R:eq:post-rejection-N1-handoff`); the multiplier `c = cInt h_step` lies in `[1/2, 3/2]`. -/
theorem treePart_reject_pre (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hnev : nev + 1 ≤ P.T) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1)) :
    ¬ (P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ F ≤ 0) ∧
      (1 / 2 : ℝ) ≤ ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ) ∧
      ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ) ≤ 3 / 2 ∧
      ∀ N1 : ℚ, 0 ≤ N1 → NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N1 : ℝ) →
        inRangeA P N1 = true ∧
          |(N1 : ℝ) - ‖S.x d‖ ^ 2| ≤ 8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 := by
  obtain ⟨h1, h2, h3, -, h5⟩ :=
    reject_pre_tree h hd hx0 hF0 hF hLd pos hcert (TreePart.cachePrec h (by omega) hd)
  exact ⟨h1, h2, h3, fun N1 hN0 hN => ⟨wit_N1_range h hd hbox N1 hN0 hN, h5 N1 hN⟩⟩

/-- Step 4 at depth `d`, rejection, the correction (`rejectTailCode`; Theorem 5.9 (3)–(4), Theorem 5.11): the
analysis event `correct d c` (`c = cInt h_step`, `cInt = stepCoeffMant …`); the strict descendants' learners are
rescaled (`Learner.rescale`), the accumulator becomes `round_{h_leaf}(c² acc)` (range checks pass); for the release
`N₂ ≥ 0` of the new residual `r_d⁺` (mode `DIFF`) with its numerical certificate, the refreshed cache
`round_{h_P}(N₂)` passes its range check, the local counters are updated (`countCorrection` succeeds), and the tree
part holds at the next moment. -/
theorem treePart_reject (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (hnev : nev + 1 ≤ P.T) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1)) :
    ((mapFrom (Learner.rescale P (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1)
        c.learners).drop (d + 1)).all (Learner.inRange P) = true ∧
      inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf
        (gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) ^ 2 *
          gridVal P.eHleaf c.leaf))) = true ∧
      ∀ N2 : ℚ, 0 ≤ N2 →
        NumCert (P.eta : ℝ) (P.omega : ℝ)
          (‖(S.step P (.correct d ((gridVal P.eHstep
            (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ))).r d‖ ^ 2) (N2 : ℝ) →
        inRangeA P (gridVal P.eHP (roundMant P.eHP N2)) = true ∧
          ∃ Ld' : Learner, Learner.countCorrection P { Ld with cache := roundMant P.eHP N2 } = some Ld' ∧
            TreePart P (.evals d)
              { c with
                learners := setAt Ld' d
                  (mapFrom (Learner.rescale P (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F))
                    (d + 1) c.learners),
                leaf := roundMant P.eHleaf
                  (gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) ^ 2 *
                    gridVal P.eHleaf c.leaf) }
              (S.step P (.correct d ((gridVal P.eHstep
                (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ))) (nev + 1) := by
  have hcacheP := TreePart.cachePrec h (by omega) hd
  have htag := TreePart.tagPrec h (by omega) hd
  obtain ⟨-, hc1, hc2, hcap, -⟩ := reject_pre_tree h hd hx0 hF0 hF hLd pos hcert hcacheP
  obtain ⟨r1, r2, r3⟩ := wit_reject_range h hd hbox (by omega) hc1 hc2
  refine ⟨r1, r2, fun N2 hN0 hN2 => ⟨r3 N2 hN0 hN2, ?_⟩⟩
  obtain ⟨Ld', hLd'⟩ := countCorrection_isSome P { Ld with cache := roundMant P.eHP N2 } hcap
  exact ⟨Ld', hLd', TreePart.mk_wit (tree_reject h hd hx0 hF0 hF hLd pos hcert htag hcacheP _ hLd' _)
    (tree_nLearners_reject h Ld' _) (fun D hD => by cases hD) (witSide_reject h hd hLd hc1 hN0 hN2 hLd')⟩

/-- The end of Step 4 (the round is closed by `finishC`, which only changes the round counter). -/
theorem treePart_endRound {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.evals 0) c S nev) :
    TreePart P .idle c S nev :=
  TreePart.mk_wit (tree_endRound h) h.nLearners (fun D hD => by cases hD) (witSide_endRound h)

/-! ## Facts used by the oracle side -/

/-- The live learners are stored. -/
theorem TreePart.learner_some {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P ph c S nev) (hd : d < ph.live P.H) :
    c.learners[d]? = some (c.learners.getD d dfltLearner) :=
  tree_learner_some h hd

/-- The lifetime correction counter stays below the client cap `J_*` (Theorem 5.11 (2c),
eq. `R:eq:Jstar-lifetime-cap`). -/
theorem TreePart.jUsed_lt {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P ph c S nev) (hd : d < ph.live P.H) :
    (c.learners.getD d dfltLearner).jUsed < P.Jstar :=
  tree_jUsed_lt h hd

end F2e2e.C.Closure
