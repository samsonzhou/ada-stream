import F2e2e.C.ParamsFacts

/-!
# Theorem (C) parameters: grids (Definition 1.7), Remark 1.8, Definition 5.2 ranges

* Definition 1.7 (partII.tex L196–207): `h_g = γην B^{-2H}/2^20` (`hg_eq`), `e_C γ V = 2^{-10} h_g`,
  and for each of `h_C, σ, h_P, h_b` that it is the largest power of two below the paper's bound:
  `x ≤ X < 2x` (`hC_le`/`lt_two_mul_hC`, `sigma_le`/…, `hP_le`/…, `hb_le`/…) together with the faithfulness
  lemmas `eHC_eq_ceil_logb`, … (our closed-form exponents equal the paper's `⌈log₂ ·⌉`); `h_step = η^2/2^20`;
  all spacings `≤ 1`; the divisibility relations among the grids used by the algorithm (`h_b ≤ h_g`, `h_b ≤ σ`);
* Remark 1.8 (L209–211): `h_g B^{2H} = h_{g,unrefined}`, the exact `+2H log₂ B` shift of the exponents,
  and the scale-cancellation identities used in Part III (partIII.tex L660, L694, L913, L961);
* Definition 5.2 (partIII.tex L446–461): `Z_max, C_max, A_max` are the smallest powers of two above their
  bounds; `h_leaf = h_g^2 h_step^{2H}`;
* the cache-grid repair numerics of §1.3(vii) (L149) / N13–N14: `2ωG^2 + TG^2 D_* h_P < η^3ν^2/2^39`.
-/

namespace F2e2e

namespace StreamParams

open ParamsAux

/-! ## `h_g` and Remark 1.8 -/

/-- `h_{g,unrefined} = γην/2^20` (L197). -/
theorem hgUnref_eq (P : StreamParams) : P.hgUnref = P.gamma * P.eta * P.nu / 2 ^ 20 := by
  unfold hgUnref eHgUnref gamma eta nu
  simp only [pow_add]
  ring

/-- Remark 1.8: `h_g B^{2H} = h_{g,unrefined}`. -/
theorem hg_mul_B_pow (P : StreamParams) : P.hg * (P.B : ℚ) ^ (2 * P.H) = P.hgUnref := by
  unfold hg eHg hgUnref B
  push_cast
  rw [pow_add, ← pow_mul, mul_assoc, show P.logB * (2 * P.H) = 2 * P.H * P.logB by ring,
    half_pow_mul_two_pow, mul_one]

/-- eq. `R:eq:grid-hg`: `h_g = γην B^{-2H}/2^20`. -/
theorem hg_eq (P : StreamParams) :
    P.hg = P.gamma * P.eta * P.nu * (1 / (P.B : ℚ)) ^ (2 * P.H) / 2 ^ 20 := by
  have hB : (P.B : ℚ) ^ (2 * P.H) ≠ 0 := pow_ne_zero _ (Nat.cast_ne_zero.mpr P.B_pos.ne')
  calc P.hg = P.hg * (P.B : ℚ) ^ (2 * P.H) / (P.B : ℚ) ^ (2 * P.H) :=
        (mul_div_cancel_right₀ _ hB).symm
    _ = P.gamma * P.eta * P.nu / 2 ^ 20 / (P.B : ℚ) ^ (2 * P.H) := by
        rw [P.hg_mul_B_pow, hgUnref_eq]
    _ = P.gamma * P.eta * P.nu * (1 / (P.B : ℚ)) ^ (2 * P.H) / 2 ^ 20 := by
        rw [div_pow, one_pow]; ring

/-- Remark 1.8: the refinement shifts `log₂(1/h_g)` by exactly `2H log₂ B`. -/
theorem eHg_eq (P : StreamParams) : P.eHg = P.eHgUnref + 2 * P.H * P.logB := rfl

/-- eq. `R:eq:overview-scale-cancellation` (L144): `2^14 h_{g,unrefined} = 2^14 B^{2H} h_g > 2h_g`. -/
theorem scale_cancellation (P : StreamParams) :
    2 ^ 14 * P.hgUnref = 2 ^ 14 * (P.B : ℚ) ^ (2 * P.H) * P.hg ∧
      2 * P.hg < 2 ^ 14 * (P.B : ℚ) ^ (2 * P.H) * P.hg := by
  refine ⟨by rw [← P.hg_mul_B_pow]; ring, ?_⟩
  have hg0 : 0 < P.hg := half_pow_pos _
  have hB : (1 : ℚ) ≤ (P.B : ℚ) ^ (2 * P.H) := by
    have : (1 : ℚ) ≤ P.B := by exact_mod_cast P.one_le_B
    exact one_le_pow₀ this
  nlinarith

/-- `(γ/4)(ην/16) = 2^14 h_{g,unrefined}` (partIII.tex L913, L961). -/
theorem gamma_div_four_mul_eta_nu (P : StreamParams) :
    P.gamma / 4 * (P.eta * P.nu / 16) = 2 ^ 14 * P.hgUnref := by
  rw [hgUnref_eq]; ring

/-- `h_{g,unrefined} < 2^{-20} ν` (partIII.tex L694). -/
theorem hgUnref_lt (P : StreamParams) : P.hgUnref < P.nu / 2 ^ 20 := by
  rw [hgUnref_eq]
  have hg := P.gamma_pos
  have he := P.eta_pos
  have hn := P.nu_pos
  have hg1 : P.gamma < 1 := by
    unfold gamma; exact pow_lt_one₀ (by norm_num) (by norm_num) (by have := P.one_le_eGamma; omega)
  have he1 := P.eta_le_one
  have : P.gamma * P.eta < 1 := by nlinarith
  rw [div_lt_div_iff_of_pos_right (by norm_num)]
  nlinarith

/-- The root-guard identity (partIII.tex L660, N8 squared): `(γη/64)^2/2 = 2^{2H+27} ν^2`, i.e.
`γη/(64√2) = 2^{H+13.5} ν`. -/
theorem root_guard_sq (P : StreamParams) :
    (P.gamma * P.eta / 64) ^ 2 / 2 = 2 ^ (2 * P.H + 27) * P.nu ^ 2 := by
  rw [nu_eq, show (64 : ℚ) = 2 ^ 6 by norm_num]
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-! ## `e_C`, `h_C` (eq. `R:eq:grid-eC-hC`) -/

theorem hg_pos (P : StreamParams) : 0 < P.hg := half_pow_pos _

theorem eC_pos (P : StreamParams) : 0 < P.eC :=
  div_pos P.hg_pos (mul_pos (mul_pos (by norm_num) P.gamma_pos) (Nat.cast_pos.mpr P.one_le_V))

/-- `e_C γ V = 2^{-10} h_g` (N4). -/
theorem eC_mul_gamma_mul_V (P : StreamParams) : P.eC * P.gamma * P.V = P.hg / 2 ^ 10 := by
  unfold eC
  have hg : P.gamma ≠ 0 := P.gamma_pos.ne'
  have hV : (P.V : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (by have := P.one_le_V; omega)
  rw [show P.hg / (2 ^ 10 * P.gamma * P.V) * P.gamma * P.V =
      P.hg / 2 ^ 10 * (P.gamma * P.V / (P.gamma * P.V)) by ring, div_self (mul_ne_zero hg hV),
    mul_one]

/-- `e_C/(TG) = 2^{-((H+1) log₂ B + 14 + log₂(1/h_g))}/(TV)`. -/
theorem eC_div_TG (P : StreamParams) :
    P.eC / ((P.T : ℚ) * P.G) =
      (1 / 2 : ℚ) ^ ((P.H + 1) * P.logB + 14 + P.eHg) / ((P.T * P.V : ℕ) : ℚ) := by
  unfold eC hg gamma G B logB
  push_cast
  have hT : (P.T : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.T_pos.ne'
  have hV : (P.V : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (by have := P.one_le_V; omega)
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

theorem one_le_T_mul_V (P : StreamParams) : 1 ≤ P.T * P.V := Nat.mul_pos P.T_pos P.one_le_V

/-- eq. `R:eq:grid-eC-hC`: `h_C ≤ e_C/(TG)`. -/
theorem hC_le (P : StreamParams) : P.hC ≤ P.eC / ((P.T : ℚ) * P.G) := by
  rw [eC_div_TG]
  exact half_pow_add_clog_le _ P.one_le_T_mul_V

/-- `h_C` is the largest power of two `≤ e_C/(TG)`: `e_C/(TG) < 2h_C`. -/
theorem eC_div_TG_lt (P : StreamParams) : P.eC / ((P.T : ℚ) * P.G) < 2 * P.hC := by
  rw [eC_div_TG]
  exact half_pow_div_lt_two_mul _ P.one_le_T_mul_V

/-- Faithfulness of `eHC` to eq. `R:eq:grid-eC-hC`: `h_C = 2^{-⌈log₂(TG/e_C)⌉}`. -/
theorem eHC_eq_ceil_logb (P : StreamParams) :
    (P.eHC : ℤ) = ⌈Real.logb 2 ((P.T : ℝ) * P.G / (P.eC : ℝ))⌉ := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) P.eC_div_TG
  push_cast at h
  have hTG : (0 : ℝ) < (P.T : ℝ) * P.G := mul_pos (Nat.cast_pos.mpr P.T_pos) (Nat.cast_pos.mpr P.G_pos)
  have hC : (0 : ℝ) < (P.eC : ℝ) := by exact_mod_cast P.eC_pos
  have e : (P.T : ℝ) * P.G / (P.eC : ℝ) =
      (2 : ℝ) ^ ((P.H + 1) * P.logB + 14 + P.eHg) * ((P.T * P.V : ℕ) : ℝ) := by
    have h' : (P.T : ℝ) * P.G / (P.eC : ℝ) = ((P.eC : ℝ) / ((P.T : ℝ) * P.G))⁻¹ := by
      rw [inv_div]
    rw [h', h, inv_div, half_pow_eq_inv, div_inv_eq_mul]
    push_cast; ring
  rw [e, ceil_logb_two_pow_mul_natCast _ P.one_le_T_mul_V]
  rfl

/-! ## `σ`, `ω` (eq. `R:eq:grid-sigma-omega`) -/

theorem Dstar_pos (P : StreamParams) : 0 < P.Dstar := by unfold Dstar; omega

theorem one_le_sigmaN (P : StreamParams) : 1 ≤ P.T * (P.V + 1) ^ 2 * P.Dstar :=
  Nat.mul_pos (Nat.mul_pos P.T_pos (pow_pos (Nat.succ_pos _) 2)) P.Dstar_pos

/-- `η^4ν^2/(2^40 T G^2 (V+1)^2 D_*) = 2^{-(40 + 2 log₂ G + 4 log₂(1/η) + 2 log₂(1/ν))}/(T(V+1)^2 D_*)`. -/
theorem sigma_bound_eq (P : StreamParams) :
    P.eta ^ 4 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * ((P.V : ℚ) + 1) ^ 2 * P.Dstar) =
      (1 / 2 : ℚ) ^ (40 + 2 * P.logG + 4 * P.eEta + 2 * P.eNu) /
        ((P.T * (P.V + 1) ^ 2 * P.Dstar : ℕ) : ℚ) := by
  unfold eta nu
  rw [P.G_eq_two_pow]
  push_cast
  have hT : (P.T : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.T_pos.ne'
  have hV : (P.V : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.V
  have hD : (P.Dstar : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.Dstar_pos.ne'
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-- eq. `R:eq:grid-sigma-omega`: `σ ≤ η^4ν^2/(2^40 T G^2 (V+1)^2 D_*)`. -/
theorem sigma_le (P : StreamParams) :
    P.sigma ≤ P.eta ^ 4 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * ((P.V : ℚ) + 1) ^ 2 * P.Dstar) := by
  rw [sigma_bound_eq]
  exact half_pow_add_clog_le _ P.one_le_sigmaN

/-- `σ` is the largest power of two below its bound. -/
theorem sigma_bound_lt (P : StreamParams) :
    P.eta ^ 4 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * ((P.V : ℚ) + 1) ^ 2 * P.Dstar) <
      2 * P.sigma := by
  rw [sigma_bound_eq]
  exact half_pow_div_lt_two_mul _ P.one_le_sigmaN

/-- Faithfulness of `eSigma`: `σ = 2^{-⌈log₂(2^40 T G^2 (V+1)^2 D_*/(η^4ν^2))⌉}`. -/
theorem eSigma_eq_ceil_logb (P : StreamParams) :
    (P.eSigma : ℤ) = ⌈Real.logb 2 (2 ^ 40 * (P.T : ℝ) * (P.G : ℝ) ^ 2 * ((P.V : ℝ) + 1) ^ 2 *
      P.Dstar / ((P.eta : ℝ) ^ 4 * (P.nu : ℝ) ^ 2))⌉ := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) P.sigma_bound_eq
  push_cast at h
  have e : 2 ^ 40 * (P.T : ℝ) * (P.G : ℝ) ^ 2 * ((P.V : ℝ) + 1) ^ 2 * P.Dstar /
      ((P.eta : ℝ) ^ 4 * (P.nu : ℝ) ^ 2) =
      (2 : ℝ) ^ (40 + 2 * P.logG + 4 * P.eEta + 2 * P.eNu) *
        ((P.T * (P.V + 1) ^ 2 * P.Dstar : ℕ) : ℝ) := by
    rw [← inv_div, h, inv_div, half_pow_eq_inv, div_inv_eq_mul]
    push_cast; ring
  rw [e, ceil_logb_two_pow_mul_natCast _ P.one_le_sigmaN]
  rfl

theorem sigma_pos (P : StreamParams) : 0 < P.sigma := half_pow_pos _

theorem omega_eq (P : StreamParams) : P.omega = (1 / 2 : ℚ) ^ P.eOmega := by
  unfold omega sigma eOmega; rw [← pow_mul, mul_comm]

theorem omega_pos (P : StreamParams) : 0 < P.omega := by unfold omega; exact pow_pos P.sigma_pos 2

/-! ## `h_P` (eq. `R:eq:grid-hP`) -/

theorem one_le_hPN (P : StreamParams) : 1 ≤ P.T * P.Dstar := Nat.mul_pos P.T_pos P.Dstar_pos

theorem hP_bound_eq (P : StreamParams) :
    P.eta ^ 3 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * P.Dstar) =
      (1 / 2 : ℚ) ^ (40 + 2 * P.logG + 3 * P.eEta + 2 * P.eNu) / ((P.T * P.Dstar : ℕ) : ℚ) := by
  unfold eta nu
  rw [P.G_eq_two_pow]
  push_cast
  have hT : (P.T : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.T_pos.ne'
  have hD : (P.Dstar : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.Dstar_pos.ne'
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-- eq. `R:eq:grid-hP`: `h_P ≤ η^3ν^2/(2^40 T G^2 D_*)`. -/
theorem hP_le (P : StreamParams) :
    P.hP ≤ P.eta ^ 3 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * P.Dstar) := by
  rw [hP_bound_eq]
  exact half_pow_add_clog_le _ P.one_le_hPN

theorem hP_bound_lt (P : StreamParams) :
    P.eta ^ 3 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * P.Dstar) < 2 * P.hP := by
  rw [hP_bound_eq]
  exact half_pow_div_lt_two_mul _ P.one_le_hPN

/-- Faithfulness of `eHP`: `h_P = 2^{-⌈log₂(2^40 T G^2 D_*/(η^3ν^2))⌉}`. -/
theorem eHP_eq_ceil_logb (P : StreamParams) :
    (P.eHP : ℤ) = ⌈Real.logb 2 (2 ^ 40 * (P.T : ℝ) * (P.G : ℝ) ^ 2 * P.Dstar /
      ((P.eta : ℝ) ^ 3 * (P.nu : ℝ) ^ 2))⌉ := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) P.hP_bound_eq
  push_cast at h
  have e : 2 ^ 40 * (P.T : ℝ) * (P.G : ℝ) ^ 2 * P.Dstar / ((P.eta : ℝ) ^ 3 * (P.nu : ℝ) ^ 2) =
      (2 : ℝ) ^ (40 + 2 * P.logG + 3 * P.eEta + 2 * P.eNu) * ((P.T * P.Dstar : ℕ) : ℝ) := by
    rw [← inv_div, h, inv_div, half_pow_eq_inv, div_inv_eq_mul]
    push_cast; ring
  rw [e, ceil_logb_two_pow_mul_natCast _ P.one_le_hPN]
  rfl

theorem hP_pos (P : StreamParams) : 0 < P.hP := half_pow_pos _

/-! ## `h_b` (eq. `R:eq:grid-hb`) -/

theorem one_le_hbN (P : StreamParams) : 1 ≤ (P.T + 1) * P.Dstar * (P.V + 1) :=
  Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) P.Dstar_pos) (Nat.succ_pos _)

theorem hb_bound_eq (P : StreamParams) :
    P.eta * P.omega / (2 ^ 40 * ((P.T : ℚ) + 1) * P.G * P.Dstar * ((P.V : ℚ) + 1)) =
      (1 / 2 : ℚ) ^ (40 + P.logG + P.eEta + P.eOmega) /
        (((P.T + 1) * P.Dstar * (P.V + 1) : ℕ) : ℚ) := by
  rw [omega_eq]
  unfold eta
  rw [P.G_eq_two_pow]
  push_cast
  have hT : (P.T : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.T
  have hV : (P.V : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.V
  have hD : (P.Dstar : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.Dstar_pos.ne'
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-- eq. `R:eq:grid-hb`: `h_b ≤ ηω/(2^40 (T+1) G D_* (V+1))`. -/
theorem hb_le (P : StreamParams) :
    P.hb ≤ P.eta * P.omega / (2 ^ 40 * ((P.T : ℚ) + 1) * P.G * P.Dstar * ((P.V : ℚ) + 1)) := by
  rw [hb_bound_eq]
  exact half_pow_add_clog_le _ P.one_le_hbN

theorem hb_bound_lt (P : StreamParams) :
    P.eta * P.omega / (2 ^ 40 * ((P.T : ℚ) + 1) * P.G * P.Dstar * ((P.V : ℚ) + 1)) < 2 * P.hb := by
  rw [hb_bound_eq]
  exact half_pow_div_lt_two_mul _ P.one_le_hbN

/-- Faithfulness of `eHb`: `h_b = 2^{-⌈log₂(2^40 (T+1) G D_* (V+1)/(ηω))⌉}`. -/
theorem eHb_eq_ceil_logb (P : StreamParams) :
    (P.eHb : ℤ) = ⌈Real.logb 2 (2 ^ 40 * ((P.T : ℝ) + 1) * P.G * P.Dstar * ((P.V : ℝ) + 1) /
      ((P.eta : ℝ) * (P.omega : ℝ)))⌉ := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) P.hb_bound_eq
  push_cast at h
  have e : 2 ^ 40 * ((P.T : ℝ) + 1) * P.G * P.Dstar * ((P.V : ℝ) + 1) /
      ((P.eta : ℝ) * (P.omega : ℝ)) =
      (2 : ℝ) ^ (40 + P.logG + P.eEta + P.eOmega) * (((P.T + 1) * P.Dstar * (P.V + 1) : ℕ) : ℝ) := by
    rw [← inv_div, h, inv_div, half_pow_eq_inv, div_inv_eq_mul]
    push_cast; ring
  rw [e, ceil_logb_two_pow_mul_natCast _ P.one_le_hbN]
  rfl

theorem hb_pos (P : StreamParams) : 0 < P.hb := half_pow_pos _

/-! ## `h_step` (eq. `R:eq:grid-hstep-hADA`) and `h_leaf` (eq. `R:eq:h-leaf`) -/

/-- `h_step = η^2/2^20` exactly. -/
theorem hstep_eq (P : StreamParams) : P.hstep = P.eta ^ 2 / 2 ^ 20 := by
  unfold hstep eHstep eta
  rw [pow_add, pow_mul']
  ring

/-- Faithfulness of `eHstep`: `h_step = 2^{-⌈log₂(2^20/η^2)⌉}`. -/
theorem eHstep_eq_ceil_logb (P : StreamParams) :
    (P.eHstep : ℤ) = ⌈Real.logb 2 (2 ^ 20 / (P.eta : ℝ) ^ 2)⌉ := by
  have e : 2 ^ 20 / (P.eta : ℝ) ^ 2 = (2 : ℝ) ^ P.eHstep := by
    unfold eHstep eta
    push_cast
    rw [half_pow_eq_inv, inv_pow, div_inv_eq_mul, pow_add, ← pow_mul, mul_comm P.eEta]
  rw [e, Real.logb_pow, Real.logb_self_eq_one (by norm_num), mul_one, Int.ceil_natCast]

/-- `h_leaf = h_g^2 h_step^{2H}` (eq. `R:eq:h-leaf`). -/
theorem hleaf_eq (P : StreamParams) : P.hleaf = P.hg ^ 2 * P.hstep ^ (2 * P.H) := by
  unfold hleaf eHleaf hg hstep
  rw [← pow_mul, ← pow_mul, ← pow_add,
    show P.eHg * 2 + P.eHstep * (2 * P.H) = 2 * P.eHg + 2 * P.H * P.eHstep by ring]

/-! ## Grid relations used by the algorithm -/

theorem hg_le_one (P : StreamParams) : P.hg ≤ 1 := half_pow_le_one _
theorem hC_le_one (P : StreamParams) : P.hC ≤ 1 := half_pow_le_one _
theorem sigma_le_one (P : StreamParams) : P.sigma ≤ 1 := half_pow_le_one _
theorem omega_le_one (P : StreamParams) : P.omega ≤ 1 := by rw [omega_eq]; exact half_pow_le_one _
theorem hP_le_one (P : StreamParams) : P.hP ≤ 1 := half_pow_le_one _
theorem hb_le_one (P : StreamParams) : P.hb ≤ 1 := half_pow_le_one _
theorem hstep_le_one (P : StreamParams) : P.hstep ≤ 1 := half_pow_le_one _
theorem hleaf_le_one (P : StreamParams) : P.hleaf ≤ 1 := half_pow_le_one _

/-- `log₂(1/h_g) ≤ log₂(1/h_b)`: `h_g ∈ h_b ℤ` (guards are exact on the counter grid). -/
theorem eHg_le_eHb (P : StreamParams) : P.eHg ≤ P.eHb := by
  unfold eHg eHgUnref eHb eOmega eSigma logG logB
  nlinarith [Nat.zero_le (P.H * P.eGamma)]

/-- `log₂(1/σ) ≤ log₂(1/h_b)`: `σ ∈ h_b ℤ` (the regularizer is exact on the counter grid). -/
theorem eSigma_le_eHb (P : StreamParams) : P.eSigma ≤ P.eHb := by
  unfold eHb eOmega; omega

theorem hb_le_hg (P : StreamParams) : P.hb ≤ P.hg := half_pow_antitone P.eHg_le_eHb

theorem hb_le_sigma (P : StreamParams) : P.hb ≤ P.sigma := half_pow_antitone P.eSigma_le_eHb

/-- `h_g / h_b = 2^{log₂(1/h_b) - log₂(1/h_g)}` is an integer. -/
theorem hg_eq_pow_mul_hb (P : StreamParams) : P.hg = 2 ^ (P.eHb - P.eHg) * P.hb := by
  obtain ⟨k, hk⟩ : ∃ k, P.eHb = P.eHg + k := ⟨P.eHb - P.eHg, by have := P.eHg_le_eHb; omega⟩
  unfold hg hb
  rw [hk, Nat.add_sub_cancel_left, pow_add, mul_comm, mul_assoc, half_pow_mul_two_pow, mul_one]

/-- `σ / h_b = 2^{log₂(1/h_b) - log₂(1/σ)}` is an integer. -/
theorem sigma_eq_pow_mul_hb (P : StreamParams) : P.sigma = 2 ^ (P.eHb - P.eSigma) * P.hb := by
  obtain ⟨k, hk⟩ : ∃ k, P.eHb = P.eSigma + k := ⟨P.eHb - P.eSigma, by have := P.eSigma_le_eHb; omega⟩
  unfold sigma hb
  rw [hk, Nat.add_sub_cancel_left, pow_add, mul_comm, mul_assoc, half_pow_mul_two_pow, mul_one]

/-! ## Definition 5.2 ranges (eq. `R:eq:totality-ranges`) -/

theorem le_Zmax (P : StreamParams) : 8 * P.Dstar * (P.V + 1) ≤ P.Zmax := le_pow_clog_two _

theorem Zmax_lt (P : StreamParams) : P.Zmax < 2 * (8 * P.Dstar * (P.V + 1)) :=
  two_pow_clog_two_lt (Nat.mul_pos (Nat.mul_pos (by norm_num) P.Dstar_pos) (Nat.succ_pos _))

/-- `Z_max` is the smallest power of two `≥ 8 D_* (V+1)`. -/
theorem Zmax_le_of_le {P : StreamParams} {k : ℕ} (hk : 8 * P.Dstar * (P.V + 1) ≤ 2 ^ k) :
    P.Zmax ≤ 2 ^ k :=
  Nat.pow_le_pow_right (by norm_num) (clog_two_le_iff.2 hk)

theorem le_Cmax (P : StreamParams) : 8 * (P.B ^ P.H + 1) ≤ P.Cmax := le_pow_clog_two _

theorem Cmax_lt (P : StreamParams) : P.Cmax < 2 * (8 * (P.B ^ P.H + 1)) :=
  two_pow_clog_two_lt (by omega)

/-- `C_max` is the smallest power of two `≥ 8 (B^H + 1)`. -/
theorem Cmax_le_of_le {P : StreamParams} {k : ℕ} (hk : 8 * (P.B ^ P.H + 1) ≤ 2 ^ k) :
    P.Cmax ≤ 2 ^ k :=
  Nat.pow_le_pow_right (by norm_num) (clog_two_le_iff.2 hk)

theorem le_Amax (P : StreamParams) : 16 * (P.V + 1) ^ 2 ≤ P.Amax := le_pow_clog_two _

theorem Amax_lt (P : StreamParams) : P.Amax < 2 * (16 * (P.V + 1) ^ 2) :=
  two_pow_clog_two_lt (Nat.mul_pos (by norm_num) (pow_pos (Nat.succ_pos _) 2))

/-- `A_max` is the smallest power of two `≥ 16 (V+1)^2`. -/
theorem Amax_le_of_le {P : StreamParams} {k : ℕ} (hk : 16 * (P.V + 1) ^ 2 ≤ 2 ^ k) :
    P.Amax ≤ 2 ^ k :=
  Nat.pow_le_pow_right (by norm_num) (clog_two_le_iff.2 hk)

/-! ## The cache-grid repair numerics (§1.3(vii), L149; N13–N14 of Part III §5) -/

/-- `σ G ≤ η^4ν^2/2^40`. -/
theorem sigma_mul_G_le (P : StreamParams) : P.sigma * P.G ≤ P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40 := by
  have hT : (1 : ℚ) ≤ P.T := Nat.one_le_cast.mpr P.T_pos
  have hG : (1 : ℚ) ≤ P.G := Nat.one_le_cast.mpr P.G_pos
  have hD : (1 : ℚ) ≤ P.Dstar := Nat.one_le_cast.mpr P.Dstar_pos
  have hV : (1 : ℚ) ≤ (P.V : ℚ) + 1 := by have : (0 : ℚ) ≤ P.V := Nat.cast_nonneg _; linarith
  have hT0 : (P.T : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.T_pos.ne'
  have hG0 : (P.G : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.G_pos.ne'
  have hD0 : (P.Dstar : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.Dstar_pos.ne'
  have hV0 : (P.V : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.V
  have hden : (1 : ℚ) ≤ (P.T : ℚ) * P.G * ((P.V : ℚ) + 1) ^ 2 * P.Dstar :=
    one_le_mul_of_one_le_of_one_le (one_le_mul_of_one_le_of_one_le
      (one_le_mul_of_one_le_of_one_le hT hG) (one_le_pow₀ hV)) hD
  have hnum : (0 : ℚ) ≤ P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40 :=
    div_nonneg (mul_nonneg (pow_nonneg P.eta_pos.le 4) (sq_nonneg _)) (by norm_num)
  calc P.sigma * P.G ≤ P.eta ^ 4 * P.nu ^ 2 /
        (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * ((P.V : ℚ) + 1) ^ 2 * P.Dstar) * P.G :=
        mul_le_mul_of_nonneg_right P.sigma_le (Nat.cast_nonneg _)
    _ = P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40 / ((P.T : ℚ) * P.G * ((P.V : ℚ) + 1) ^ 2 * P.Dstar) := by
        field_simp
    _ ≤ P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40 := div_le_self hnum hden

/-- `2ωG^2 ≤ 2(η^4ν^2/2^40)^2`. -/
theorem two_omega_G_sq_le (P : StreamParams) :
    2 * P.omega * (P.G : ℚ) ^ 2 ≤ 2 * (P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40) ^ 2 := by
  have e : 2 * P.omega * (P.G : ℚ) ^ 2 = 2 * (P.sigma * P.G) ^ 2 := by unfold omega; ring
  rw [e]
  have hsg : 0 ≤ P.sigma * P.G := mul_nonneg P.sigma_pos.le (Nat.cast_nonneg _)
  exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hsg P.sigma_mul_G_le 2) (by norm_num)

/-- `2ω ≤ 2ωG^2 < 2^{-40} η ν^2` (N14). -/
theorem two_omega_G_sq_lt (P : StreamParams) :
    2 * P.omega * (P.G : ℚ) ^ 2 < P.eta * P.nu ^ 2 / 2 ^ 40 := by
  have he0 := P.eta_pos
  have he1 := P.eta_le_one
  have hn0 := P.nu_pos
  have hn1 := P.nu_lt_one.le
  have h7 : P.eta ^ 7 * P.nu ^ 2 ≤ 1 :=
    mul_le_one₀ (pow_le_one₀ he0.le he1) (sq_nonneg _) (pow_le_one₀ hn0.le hn1)
  have hpos : 0 < P.eta * P.nu ^ 2 / 2 ^ 40 := div_pos (mul_pos he0 (pow_pos hn0 2)) (by norm_num)
  calc 2 * P.omega * (P.G : ℚ) ^ 2 ≤ 2 * (P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40) ^ 2 := P.two_omega_G_sq_le
    _ = (P.eta * P.nu ^ 2 / 2 ^ 40) * (2 * (P.eta ^ 7 * P.nu ^ 2) / 2 ^ 40) := by ring
    _ < (P.eta * P.nu ^ 2 / 2 ^ 40) * 1 := by
        apply mul_lt_mul_of_pos_left _ hpos
        rw [div_lt_one₀ (by norm_num)]
        linarith
    _ = P.eta * P.nu ^ 2 / 2 ^ 40 := mul_one _

/-- `2ω ≤ 2ωG^2`. -/
theorem two_omega_le_two_omega_G_sq (P : StreamParams) :
    2 * P.omega ≤ 2 * P.omega * (P.G : ℚ) ^ 2 := by
  have hG : (1 : ℚ) ≤ (P.G : ℚ) ^ 2 := one_le_pow₀ (Nat.one_le_cast.mpr P.G_pos)
  have := P.omega_pos
  nlinarith

/-- `2ωG^2 + T G^2 D_* h_P < η^3ν^2/2^39 = 2^{-19}(η/2^12) E_min` (L149, N13). -/
theorem two_omega_G_sq_add_lt (P : StreamParams) :
    2 * P.omega * (P.G : ℚ) ^ 2 + P.T * (P.G : ℚ) ^ 2 * P.Dstar * P.hP <
      P.eta ^ 3 * P.nu ^ 2 / 2 ^ 39 := by
  have hT0 : (P.T : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.T_pos.ne'
  have hG0 : (P.G : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.G_pos.ne'
  have hD0 : (P.Dstar : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.Dstar_pos.ne'
  have he0 := P.eta_pos
  have he1 := P.eta_le_one
  have hn0 := P.nu_pos
  have hn1 := P.nu_lt_one.le
  have h1 : (P.T : ℚ) * (P.G : ℚ) ^ 2 * P.Dstar * P.hP ≤ P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40 := by
    have hpos : (0 : ℚ) ≤ (P.T : ℚ) * (P.G : ℚ) ^ 2 * P.Dstar :=
      mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (sq_nonneg _)) (Nat.cast_nonneg _)
    calc (P.T : ℚ) * (P.G : ℚ) ^ 2 * P.Dstar * P.hP
        ≤ (P.T : ℚ) * (P.G : ℚ) ^ 2 * P.Dstar *
            (P.eta ^ 3 * P.nu ^ 2 / (2 ^ 40 * P.T * (P.G : ℚ) ^ 2 * P.Dstar)) :=
          mul_le_mul_of_nonneg_left P.hP_le hpos
      _ = P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40 := by field_simp
  have h5 : P.eta ^ 5 * P.nu ^ 2 ≤ 1 :=
    mul_le_one₀ (pow_le_one₀ he0.le he1) (sq_nonneg _) (pow_le_one₀ hn0.le hn1)
  have hpos : 0 < P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40 :=
    div_pos (mul_pos (pow_pos he0 3) (pow_pos hn0 2)) (by norm_num)
  have h3 : 2 * P.omega * (P.G : ℚ) ^ 2 < P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40 := by
    calc 2 * P.omega * (P.G : ℚ) ^ 2 ≤ 2 * (P.eta ^ 4 * P.nu ^ 2 / 2 ^ 40) ^ 2 :=
          P.two_omega_G_sq_le
      _ = (P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40) * (2 * (P.eta ^ 5 * P.nu ^ 2) / 2 ^ 40) := by ring
      _ < (P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40) * 1 := by
          apply mul_lt_mul_of_pos_left _ hpos
          rw [div_lt_one₀ (by norm_num)]
          linarith
      _ = P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40 := mul_one _
  have e39 : P.eta ^ 3 * P.nu ^ 2 / 2 ^ 39 = 2 * (P.eta ^ 3 * P.nu ^ 2 / 2 ^ 40) := by ring
  rw [e39]
  linarith

/-- The counter-drift budget of Lemma 6.1 (partIII.tex): `ξ = G(T+1)h_b ≤ ηω/(2^40 D_* (V+1))`. -/
theorem G_mul_T_add_one_mul_hb_le (P : StreamParams) :
    (P.G : ℚ) * ((P.T : ℚ) + 1) * P.hb ≤ P.eta * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℚ) + 1)) := by
  have hT0 : (P.T : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.T
  have hG0 : (P.G : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr P.G_pos.ne'
  have hpos : (0 : ℚ) ≤ (P.G : ℚ) * ((P.T : ℚ) + 1) :=
    mul_nonneg (Nat.cast_nonneg _) (by have : (0 : ℚ) ≤ P.T := Nat.cast_nonneg _; linarith)
  calc (P.G : ℚ) * ((P.T : ℚ) + 1) * P.hb
      ≤ (P.G : ℚ) * ((P.T : ℚ) + 1) *
          (P.eta * P.omega / (2 ^ 40 * ((P.T : ℚ) + 1) * P.G * P.Dstar * ((P.V : ℚ) + 1))) :=
        mul_le_mul_of_nonneg_left P.hb_le hpos
    _ = P.eta * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℚ) + 1)) := by field_simp

/-- `η^3ν^2/2^39 = 2^{-19} (η/2^12) E_min`. -/
theorem eta_cube_nu_sq_eq (P : StreamParams) :
    P.eta ^ 3 * P.nu ^ 2 / 2 ^ 39 = (1 / 2) ^ 19 * (P.eta / 2 ^ 12) * P.Emin := by
  unfold Emin; ring

end StreamParams

end F2e2e
