import Mathlib
import F2e2e.Lib.Discrete.BitProg

/-!
# Tagged bit programs and the multi-stream lemma (generic; Part III §6.4 information flow)

Part III's probability argument (partIII.tex L1271–1285) needs, for one component of the algorithm (one
bank's ADA sample and coins, one coarse group, the fingerprint seed), to view its fresh bits as a block of
randomness *independent* of all other bits, although the algorithm reads all its bits lazily, interleaved
on the round tapes. This file provides the generic tool:

* `TBitProg ι α`: programs reading fresh fair bits, every read carrying a tag `i : ι` (the component it
  belongs to); `bind`, `map`, `Monad`;
* `merge : TBitProg ι α → BitProg α` forgets the tags (this is how the algorithm actually runs: one fresh
  bit stream), `tag i : BitProg α → TBitProg ι α` tags every read of an untagged program by `i`,
  `retag f` coarsens tags; `merge` is a monad morphism (`merge_bind`), `merge (tag i p) = p`;
* `runS p σ`: the run with one separate tape `σ i` per tag (the "eager" model: every component has its
  own pre-sampled stream);
* `ReadsLE p n`: on every path at most `n i` reads carry the tag `i`;
* **`sum_streams_eq`** (multi-stream lemma): for `ReadsLE p n`, summing any function of the output of
  `runS p σ` over all per-tag tapes of lengths `n` gives `2^{Σ n}` times its expectation under the law of
  the merged program: `∑_{σ} g(runS p σ) = 2^{∑ᵢ nᵢ} · E_{law (merge p)}[g]`. So the lazily interleaved
  execution (`merge p`) and the execution with independent per-component blocks (`runS p`) have the same
  output law: the blocks are independent uniform bit strings.

The proof is an induction on the program: at a read tagged `i`, the first bit of tape `i` is a fair coin
independent of the remaining tapes (`streams_cons_bij`).
-/

namespace F2e2e.C.Closure

open F2e2e.Discrete ENNReal Finset

/-- Programs reading fresh fair bits, each read tagged with the component `i : ι` it belongs to. -/
inductive TBitProg (ι : Type) (α : Type) : Type
  | pure : α → TBitProg ι α
  | bit : ι → (Bool → TBitProg ι α) → TBitProg ι α

namespace TBitProg

variable {ι ι' : Type} {α β γ : Type}

/-- Sequential composition. -/
def bind : TBitProg ι α → (α → TBitProg ι β) → TBitProg ι β
  | pure a, f => f a
  | bit i k, f => bit i fun b => bind (k b) f

/-- Apply a function to the output. -/
def map (f : α → β) (p : TBitProg ι α) : TBitProg ι β := p.bind (pure ∘ f)

instance : Monad (TBitProg ι) where
  pure := pure
  bind := bind

@[simp] theorem bind_pure' (a : α) (f : α → TBitProg ι β) : (pure a).bind f = f a := rfl

@[simp] theorem bind_bit (i : ι) (k : Bool → TBitProg ι α) (f : α → TBitProg ι β) :
    (bit i k).bind f = bit i fun b => (k b).bind f := rfl

theorem bind_assoc (p : TBitProg ι α) (f : α → TBitProg ι β) (g : β → TBitProg ι γ) :
    (p.bind f).bind g = p.bind fun a => (f a).bind g := by
  induction p with
  | pure a => rfl
  | bit i k ih =>
    simp only [bind_bit]
    congr 1
    funext b
    exact ih b

theorem bind_pure (p : TBitProg ι α) : p.bind pure = p := by
  induction p with
  | pure a => rfl
  | bit i k ih =>
    simp only [bind_bit]
    congr 1
    funext b
    exact ih b

/-- Forget the tags: the program as it actually runs (one fresh bit stream). -/
def merge : TBitProg ι α → BitProg α
  | pure a => BitProg.pure a
  | bit _ k => BitProg.bit fun b => merge (k b)

@[simp] theorem merge_pure (a : α) : (pure a : TBitProg ι α).merge = BitProg.pure a := rfl

@[simp] theorem merge_bit (i : ι) (k : Bool → TBitProg ι α) :
    (bit i k).merge = BitProg.bit fun b => (k b).merge := rfl

/-- `merge` is a monad morphism. -/
theorem merge_bind (p : TBitProg ι α) (f : α → TBitProg ι β) :
    (p.bind f).merge = p.merge.bind fun a => (f a).merge := by
  induction p with
  | pure a => rfl
  | bit i k ih =>
    simp only [bind_bit, merge_bit, BitProg.bind_bit]
    congr 1
    funext b
    exact ih b

theorem merge_map (f : α → β) (p : TBitProg ι α) : (p.map f).merge = p.merge.map f := by
  unfold map BitProg.map
  rw [merge_bind]
  rfl

/-- Tag every read of an untagged program by `i`. -/
def tag (i : ι) : BitProg α → TBitProg ι α
  | BitProg.pure a => pure a
  | BitProg.bit k => bit i fun b => tag i (k b)

@[simp] theorem tag_pure (i : ι) (a : α) : tag i (BitProg.pure a) = (pure a : TBitProg ι α) := rfl

@[simp] theorem tag_bit (i : ι) (k : Bool → BitProg α) :
    tag i (BitProg.bit k) = bit i fun b => tag i (k b) := rfl

@[simp] theorem merge_tag (i : ι) (p : BitProg α) : (tag i p).merge = p := by
  induction p with
  | pure a => rfl
  | bit k ih =>
    simp only [tag_bit, merge_bit]
    congr 1
    funext b
    exact ih b

theorem tag_bind (i : ι) (p : BitProg α) (f : α → BitProg β) :
    tag i (p.bind f) = (tag i p).bind fun a => tag i (f a) := by
  induction p with
  | pure a => rfl
  | bit k ih =>
    simp only [BitProg.bind_bit, tag_bit, bind_bit]
    congr 1
    funext b
    exact ih b

/-- Coarsen (or rename) the tags. -/
def retag (f : ι → ι') : TBitProg ι α → TBitProg ι' α
  | pure a => pure a
  | bit i k => bit (f i) fun b => retag f (k b)

@[simp] theorem merge_retag (f : ι → ι') (p : TBitProg ι α) : (p.retag f).merge = p.merge := by
  induction p with
  | pure a => rfl
  | bit i k ih =>
    simp only [retag, merge_bit]
    congr 1
    funext b
    exact ih b

theorem retag_bind (f : ι → ι') (p : TBitProg ι α) (g : α → TBitProg ι β) :
    (p.bind g).retag f = (p.retag f).bind fun a => (g a).retag f := by
  induction p with
  | pure a => rfl
  | bit i k ih =>
    simp only [bind_bit, retag]
    congr 1
    funext b
    exact ih b

theorem retag_tag (f : ι → ι') (i : ι) (p : BitProg α) : (tag i p).retag f = tag (f i) p := by
  induction p with
  | pure a => rfl
  | bit k ih =>
    simp only [tag_bit, retag]
    congr 1
    funext b
    exact ih b

/-! ## Runs with one tape per tag -/

variable [DecidableEq ι]

/-- The run with one separate tape `σ i` per tag `i`: a read tagged `i` consumes the head of `σ i`
(`none` iff that tape runs out); returns the output and the unread rests of all tapes. -/
def runS : TBitProg ι α → (ι → List Bool) → Option (α × (ι → List Bool))
  | pure a, σ => some (a, σ)
  | bit i k, σ =>
    match σ i with
    | [] => none
    | b :: rest => runS (k b) (Function.update σ i rest)

@[simp] theorem runS_pure (a : α) (σ : ι → List Bool) : (pure a : TBitProg ι α).runS σ = some (a, σ) :=
  rfl

theorem runS_bit_cons (i : ι) (k : Bool → TBitProg ι α) (σ : ι → List Bool) (b : Bool)
    (rest : List Bool) (h : σ i = b :: rest) :
    (bit i k).runS σ = (k b).runS (Function.update σ i rest) := by
  simp only [runS, h]

theorem runS_bind (p : TBitProg ι α) (f : α → TBitProg ι β) (σ : ι → List Bool) :
    (p.bind f).runS σ = (p.runS σ).bind fun r => (f r.1).runS r.2 := by
  induction p generalizing σ with
  | pure a => rfl
  | bit i k ih =>
    simp only [bind_bit, runS]
    cases σ i with
    | nil => rfl
    | cons b rest => exact ih b _

/-- On every path, at most `n i` reads carry the tag `i`. -/
def ReadsLE : TBitProg ι α → (ι → ℕ) → Prop
  | pure _, _ => True
  | bit i k, n => 0 < n i ∧ ∀ b, ReadsLE (k b) (Function.update n i (n i - 1))

theorem ReadsLE.mono : ∀ {p : TBitProg ι α} {n n' : ι → ℕ}, ReadsLE p n → (∀ i, n i ≤ n' i) →
    ReadsLE p n'
  | pure _, _, _, _, _ => trivial
  | bit i k, n, n', ⟨hpos, hk⟩, hle => by
    refine ⟨lt_of_lt_of_le hpos (hle i), fun b => ReadsLE.mono (hk b) (fun j => ?_)⟩
    by_cases hj : j = i
    · subst hj; simp only [Function.update_self]; have := hle j; omega
    · simp only [Function.update_of_ne hj]; exact hle j

/-- Reads of a tagged untagged program: `depth p` reads with tag `i`, none with other tags. -/
theorem readsLE_tag (i : ι) : ∀ (p : BitProg α) (n : ι → ℕ), p.depth ≤ n i → ReadsLE (tag i p) n
  | BitProg.pure _, _, _ => trivial
  | BitProg.bit k, n, h => by
    refine ⟨lt_of_lt_of_le (Nat.succ_pos _) h, fun b => readsLE_tag i (k b) _ ?_⟩
    simp only [Function.update_self]
    have := BitProg.depth_le_bit k b
    omega

/-! ## Tapes of prescribed lengths -/

/-- The finite set of bit lists of length `k`. -/
def lenFinset : ℕ → Finset (List Bool)
  | 0 => {[]}
  | k + 1 => (lenFinset k).image (List.cons true) ∪ (lenFinset k).image (List.cons false)

theorem mem_lenFinset : ∀ {k : ℕ} {l : List Bool}, l ∈ lenFinset k ↔ l.length = k
  | 0, l => by cases l <;> simp [lenFinset]
  | k + 1, l => by
    cases l with
    | nil => simp [lenFinset]
    | cons b l =>
      simp only [lenFinset, mem_union, mem_image, List.cons.injEq, List.length_cons,
        Nat.add_right_cancel_iff]
      constructor
      · rintro (⟨l', hl', -, rfl⟩ | ⟨l', hl', -, rfl⟩) <;> exact mem_lenFinset.mp hl'
      · intro h
        cases b
        · exact Or.inr ⟨l, mem_lenFinset.mpr h, rfl, rfl⟩
        · exact Or.inl ⟨l, mem_lenFinset.mpr h, rfl, rfl⟩

theorem card_lenFinset : ∀ k : ℕ, (lenFinset k).card = 2 ^ k
  | 0 => rfl
  | k + 1 => by
    rw [lenFinset, card_union_of_disjoint, card_image_of_injective _ (List.cons_injective),
      card_image_of_injective _ (List.cons_injective), card_lenFinset k, pow_succ]
    · ring
    · rw [disjoint_left]
      intro l h1 h2
      obtain ⟨a, -, rfl⟩ := mem_image.mp h1
      obtain ⟨b, -, hb⟩ := mem_image.mp h2
      simp at hb

variable [Fintype ι]

/-- All families of per-tag tapes with lengths `n`. -/
def streams (n : ι → ℕ) : Finset (ι → List Bool) := Fintype.piFinset fun i => lenFinset (n i)

theorem mem_streams {n : ι → ℕ} {σ : ι → List Bool} : σ ∈ streams n ↔ ∀ i, (σ i).length = n i := by
  simp only [streams, Fintype.mem_piFinset, mem_lenFinset]

theorem card_streams (n : ι → ℕ) : (streams n).card = 2 ^ (∑ i, n i) := by
  rw [streams, Fintype.card_piFinset]
  simp only [card_lenFinset]
  rw [Finset.prod_pow_eq_pow_sum]

/-- Splitting off the head of tape `i`: tapes of lengths `n` (with `n i = m + 1`) are in bijection with
pairs (first bit of tape `i`, tapes of lengths `n` updated to `m` at `i`). -/
theorem sum_streams_cons (n : ι → ℕ) (i : ι) (m : ℕ) (hm : n i = m + 1)
    (F : (ι → List Bool) → ℝ≥0∞) :
    ∑ σ ∈ streams n, F σ =
      ∑ b : Bool, ∑ σ' ∈ streams (Function.update n i m), F (Function.update σ' i (b :: σ' i)) := by
  rw [← Finset.sum_product' (s := (univ : Finset Bool)) (t := streams (Function.update n i m))
    (f := fun b σ' => F (Function.update σ' i (b :: σ' i)))]
  symm
  refine Finset.sum_nbij' (fun p => Function.update p.2 i (p.1 :: p.2 i))
    (fun σ => ((σ i).headD false, Function.update σ i (σ i).tail)) ?_ ?_ ?_ ?_ ?_
  · rintro ⟨b, σ'⟩ h
    simp only [mem_product, mem_univ, true_and] at h
    simp only [mem_streams] at h ⊢
    intro j
    by_cases hj : j = i
    · subst hj
      have := h j
      simp only [Function.update_self] at this ⊢
      simp [this, hm]
    · have := h j
      simp only [Function.update_of_ne hj] at this ⊢
      exact this
  · intro σ h
    simp only [mem_streams] at h
    simp only [mem_product, mem_univ, true_and, mem_streams]
    intro j
    by_cases hj : j = i
    · subst hj
      simp only [Function.update_self, List.length_tail, h j, hm]
      omega
    · simp only [Function.update_of_ne hj]
      exact h j
  · rintro ⟨b, σ'⟩ _
    simp only [Function.update_self, List.headD_cons, List.tail_cons, Function.update_idem,
      Function.update_eq_self]
  · intro σ h
    simp only [mem_streams] at h
    have hi := h i
    rw [hm] at hi
    obtain ⟨b, rest, hbr⟩ : ∃ b rest, σ i = b :: rest := by
      cases hσ : σ i with
      | nil => rw [hσ] at hi; simp at hi
      | cons b rest => exact ⟨b, rest, rfl⟩
    simp only [hbr, List.headD_cons, List.tail_cons, Function.update_self, Function.update_idem]
    rw [← hbr, Function.update_eq_self]
  · rintro ⟨b, σ'⟩ _
    rfl

/-- **Multi-stream lemma.** If on every path at most `n i` reads carry the tag `i`, then for every
`g`, summing `g` of the output of the run with separate per-tag tapes over all tapes of lengths `n`
gives `2^{∑ n}` times the expectation of `g` under the law of the merged (interleaved) program. -/
theorem sum_streams_eq (p : TBitProg ι α) (n : ι → ℕ) (hp : ReadsLE p n) (g : α → ℝ≥0∞) :
    ∑ σ ∈ streams n, ((p.runS σ).map Prod.fst).elim 0 g =
      2 ^ (∑ i, n i) * ∑' a, p.merge.law a * g a := by
  induction p generalizing n with
  | pure a =>
    simp only [runS_pure, Option.map_some, Option.elim, merge_pure, BitProg.law_pure]
    rw [Finset.sum_const, card_streams, nsmul_eq_mul,
      tsum_eq_single a (fun b hb => by simp [PMF.pure_apply, hb])]
    simp
  | bit i k ih =>
    obtain ⟨hpos, hk⟩ := hp
    obtain ⟨m, hm⟩ : ∃ m, n i = m + 1 := ⟨n i - 1, by omega⟩
    rw [sum_streams_cons n i m hm]
    have hk' : ∀ b, ReadsLE (k b) (Function.update n i m) := by
      intro b
      have := hk b
      rwa [hm, Nat.add_sub_cancel] at this
    have hrun : ∀ (b : Bool) (σ' : ι → List Bool),
        (bit i k).runS (Function.update σ' i (b :: σ' i)) = (k b).runS σ' := by
      intro b σ'
      rw [runS_bit_cons i k _ b (σ' i) (by simp), Function.update_idem, Function.update_eq_self]
    simp only [hrun]
    rw [Fintype.sum_bool, ih true _ (hk' true), ih false _ (hk' false)]
    have hsum : ∑ j, n j = (∑ j, Function.update n i m j) + 1 := by
      rw [Finset.sum_update_of_mem (Finset.mem_univ i), ← Finset.add_sum_erase _ _ (Finset.mem_univ i),
        hm, Finset.sdiff_singleton_eq_erase]
      ring
    rw [hsum, merge_bit]
    simp only [BitProg.law_bit_apply, add_mul, ENNReal.tsum_add, mul_assoc, ENNReal.tsum_mul_left]
    rw [pow_succ, mul_assoc, ← mul_add, ← mul_add]
    congr 1
    rw [← mul_assoc, ENNReal.mul_inv_cancel two_ne_zero ofNat_ne_top, one_mul]

end TBitProg

end F2e2e.C.Closure
