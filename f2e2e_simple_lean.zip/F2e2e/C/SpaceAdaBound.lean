import F2e2e.C.SpaceRegs
import F2e2e.C.SpaceBound
import F2e2e.C.Impl.AdaPubMath

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`): the size bound of W4's encoded ADA state

W4's representation `adaRep` of the ADA module (`F2e2e/C/Impl/AdaRep.lean`) bounds the encoded state of
the bank ADA instance by `adaBoundA (bankAda P) = 2^10 (N + p + 16)(adaZ + 16)`, `N = ∑_j n_j`, with
`adaZ` the sum of the exponents and bit lengths of the module's parameters. This file proves the bound
`adaRep.bound P ≤ 2^79 N_bank ℒ³` used by `F2e2e/C/SpaceBound.lean` (hypothesis `hada`; partIII.tex
L1232–1237: "the ADA state of a bank has `O(N_bank ℒ)` bits"): every summand of `adaZ` is `O(ℒ)`
(`adaZ_le : adaZ (bankAda P) ≤ 2^10 ℒ`), using the closed forms of B-ARCH's parameters
(W4's `F2e2e/C/Impl/AdaPubMath.lean`) and C-PARAMS' bounds (`F2e2e/C/SpaceParams.lean`).
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (adaRep adaZ adaBoundA maxKs noiseKinds)

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate the parameters
symbolically and elaboration explodes. -/
attribute [local irreducible] Nat.clog Nat.log

namespace AdaBoundAux

theorem size_le_of_le {n k : ℕ} (h : n ≤ 2 ^ k) : Nat.size n ≤ k + 1 :=
  Nat.size_le.mpr (lt_of_le_of_lt h (Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self k)))

/-- `a / b` in lowest terms has numerator `≤ a` and denominator `≤ b`. -/
theorem num_den_div_le (a b : ℕ) (hb : 0 < b) :
    ((a : ℚ) / (b : ℚ)).num.natAbs ≤ a ∧ ((a : ℚ) / (b : ℚ)).den ≤ b := by
  have hb' : (0 : ℤ) < b := by exact_mod_cast hb
  have e : (a : ℚ) / (b : ℚ) = Rat.divInt (a : ℤ) (b : ℤ) := by
    rw [Rat.divInt_eq_div]; push_cast; rfl
  rw [e]
  constructor
  · rcases Nat.eq_zero_or_pos a with rfl | ha
    · simp
    · have ha' : (a : ℤ) ≠ 0 := by exact_mod_cast ha.ne'
      have := Nat.le_of_dvd (Int.natAbs_pos.mpr ha')
        (Int.natAbs_dvd_natAbs.mpr (Rat.num_dvd (a : ℤ) (ne_of_gt hb')))
      simpa using this
  · have := Int.le_of_dvd hb' (Rat.den_dvd (a : ℤ) (b : ℤ))
    exact_mod_cast this

theorem toNat_le_natAbs (x : ℤ) : x.toNat ≤ x.natAbs := by
  rcases le_total 0 x with h | h
  · have h1 : ((x.toNat : ℕ) : ℤ) = x := Int.toNat_of_nonneg h
    have h2 : ((x.natAbs : ℕ) : ℤ) = x := Int.natAbs_of_nonneg h
    have : ((x.toNat : ℕ) : ℤ) = ((x.natAbs : ℕ) : ℤ) := h1.trans h2.symm
    exact le_of_eq (by exact_mod_cast this)
  · rw [Int.toNat_eq_zero.mpr h]; exact Nat.zero_le _

/-- `1/n` has numerator `1` and denominator `n`. -/
theorem size_one_div (n k : ℕ) (hn : 0 < n) (hk : n ≤ 2 ^ k) :
    Nat.size ((1 : ℚ) / (n : ℚ)).den ≤ k + 1 ∧ Nat.size ((1 : ℚ) / (n : ℚ)).num.natAbs ≤ 1 := by
  have h := num_den_div_le 1 n hn
  rw [Nat.cast_one] at h
  refine ⟨size_le_of_le (h.2.trans hk), ?_⟩
  have := size_le_of_le (k := 0) (by simpa using h.1)
  simpa using this

/-! ## The parameters of the bank ADA instance -/

section Params

variable (P : StreamParams)

/-- Elementary facts about `ℒ`. -/
theorem calL_facts : 100 ≤ P.calL ∧ 100 * P.calL ≤ P.calL ^ 2 ∧ P.calL ^ 2 ≤ 2 ^ P.calL := by
  have hL := hundred_le_calL P
  have h4 := pow_four_le_two_pow (k := P.calL) (by omega)
  exact ⟨hL, hundred_mul_calL_le_sq P,
    le_trans (Nat.pow_le_pow_right (by omega) (by norm_num)) h4⟩

theorem p_le : 2 ≤ (bankAda P).p ∧ (bankAda P).p ≤ 13 * P.calL := by
  have hL := hundred_le_calL P
  have hA4 : 4 ≤ P.eBankA := by unfold StreamParams.eBankA; omega
  have hAle := eBankA_le P
  have hp := B.adaP_le_of_four_le hA4
  exact ⟨F2e2e.C.Impl.AP.two_le_adaP _, by show B.adaP P.eBankA ≤ 13 * P.calL; omega⟩

theorem chi_le : B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 57 * P.calL := by
  have hL := hundred_le_calL P
  have hA4 : 4 ≤ P.eBankA := by unfold StreamParams.eBankA; omega
  have hAle := eBankA_le P
  have hXle := eBankXi_le P
  have hcl := clog_bank_caps_le P
  have hchi := B.adaChi_le_of_four_le P.m P.Jmax P.Rmax P.eBankXi hA4
  show B.adaChi P.m P.Jmax P.Rmax P.eBankA P.eBankXi ≤ 57 * P.calL
  omega

theorem caps_le : P.bankM + P.bankJ + P.bankR + 2 ≤ 2 ^ (5 * P.calL + 14) := by
  have hcl := clog_bank_caps_le P
  calc P.bankM + P.bankJ + P.bankR + 2 = P.m + P.Jmax + P.Rmax + 2 := rfl
    _ ≤ 2 ^ Nat.clog 2 (P.m + P.Jmax + P.Rmax + 2) := Nat.le_pow_clog (by norm_num) _
    _ ≤ 2 ^ (5 * P.calL + 14) := Nat.pow_le_pow_right (by norm_num) hcl

theorem tmA_le : F2e2e.C.Impl.AP.tmA P.eBankA ≤ 2 ^ (14 * P.calL + 9) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨_, hp⟩ := p_le P
  have hAle := eBankA_le P
  have hp' : B.adaP P.eBankA ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  have hE : 2 ^ P.eBankA ≤ 2 ^ (6 * P.calL) := Nat.pow_le_pow_right (by norm_num) hAle
  unfold F2e2e.C.Impl.AP.tmA
  have h1 : 384 * B.adaP P.eBankA * B.adaP P.eBankA ≤ 2 ^ 9 * 2 ^ P.calL * 2 ^ P.calL :=
    Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp') hp'
  calc 384 * B.adaP P.eBankA * B.adaP P.eBankA * (2 ^ P.eBankA * 2 ^ P.eBankA)
      ≤ 2 ^ 9 * 2 ^ P.calL * 2 ^ P.calL * (2 ^ (6 * P.calL) * 2 ^ (6 * P.calL)) :=
        Nat.mul_le_mul h1 (Nat.mul_le_mul hE hE)
    _ = 2 ^ (14 * P.calL + 9) := by
        rw [← pow_add, ← pow_add, ← pow_add, ← pow_add]; congr 1; omega

theorem Tmax_sum_le : (bankAda P).Tmax.sum ≤ 2 ^ (15 * P.calL + 9) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have htm := tmA_le P
  have hT : (bankAda P).Tmax = (List.range (B.adaP P.eBankA)).map (B.adaTmax P.eBankA) := rfl
  have hentry : ∀ x ∈ (bankAda P).Tmax, x ≤ F2e2e.C.Impl.AP.tmA P.eBankA := by
    intro x hx
    rw [hT, List.mem_map] at hx
    obtain ⟨j, hj, rfl⟩ := hx
    rw [List.mem_range] at hj
    rw [F2e2e.C.Impl.AP.adaTmax_eq hj]
    have h1 : 1 ≤ F2e2e.C.Impl.AP.tmA P.eBankA := by
      have hp0 : 0 < B.adaP P.eBankA := by have := F2e2e.C.Impl.AP.two_le_adaP P.eBankA; omega
      have : 0 < F2e2e.C.Impl.AP.tmA P.eBankA := by unfold F2e2e.C.Impl.AP.tmA; positivity
      omega
    have h2 : 1 ≤ 2 ^ (2 * j) := Nat.one_le_two_pow
    apply Nat.div_le_of_le_mul
    have : F2e2e.C.Impl.AP.tmA P.eBankA + 2 ^ (2 * j) - 1 ≤ 2 ^ (2 * j) * F2e2e.C.Impl.AP.tmA P.eBankA := by
      have h3 : (2 ^ (2 * j) - 1) * (F2e2e.C.Impl.AP.tmA P.eBankA - 1) + (2 ^ (2 * j) - 1) +
          (F2e2e.C.Impl.AP.tmA P.eBankA - 1) + 1 = 2 ^ (2 * j) * F2e2e.C.Impl.AP.tmA P.eBankA := by
        obtain ⟨u, hu⟩ : ∃ u, 2 ^ (2 * j) = u + 1 := ⟨2 ^ (2 * j) - 1, by omega⟩
        obtain ⟨v, hv⟩ : ∃ v, F2e2e.C.Impl.AP.tmA P.eBankA = v + 1 := ⟨F2e2e.C.Impl.AP.tmA P.eBankA - 1, by omega⟩
        rw [hu, hv]; simp only [Nat.add_sub_cancel]; ring
      omega
    exact this
  have hlen : (bankAda P).Tmax.length = (bankAda P).p := by
    rw [hT, List.length_map, List.length_range]; rfl
  calc (bankAda P).Tmax.sum ≤ (bankAda P).Tmax.length * F2e2e.C.Impl.AP.tmA P.eBankA := by
        simpa using List.sum_le_card_nsmul _ _ hentry
    _ ≤ 2 ^ P.calL * 2 ^ (14 * P.calL + 9) := by
        rw [hlen]; exact Nat.mul_le_mul (by omega) htm
    _ = 2 ^ (15 * P.calL + 9) := by rw [← pow_add]; congr 1; omega

theorem Q_le : B.adaQ P.bankM P.bankJ P.bankR P.eBankA ≤ 2 ^ (16 * P.calL + 22) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hcaps := caps_le P
  have hT := Tmax_sum_le P
  have hTl : (B.adaTmaxList P.eBankA).sum ≤ 2 ^ (15 * P.calL + 9) := hT
  have hp' : B.adaP P.eBankA + 1 ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  unfold B.adaQ
  have hsum : P.bankM + P.bankR + P.bankJ + 2 + (B.adaTmaxList P.eBankA).sum ≤
      2 ^ (15 * P.calL + 15) := by
    have h1 : 2 ^ (5 * P.calL + 14) ≤ 2 ^ (15 * P.calL + 14) :=
      Nat.pow_le_pow_right (by norm_num) (by omega)
    have h2 : 2 ^ (15 * P.calL + 9) ≤ 2 ^ (15 * P.calL + 14) :=
      Nat.pow_le_pow_right (by norm_num) (by omega)
    have e : 2 ^ (15 * P.calL + 15) = 2 * 2 ^ (15 * P.calL + 14) := by rw [pow_succ]; ring
    omega
  calc 100 * (B.adaP P.eBankA + 1) * (P.bankM + P.bankR + P.bankJ + 2 + (B.adaTmaxList P.eBankA).sum)
      ≤ 2 ^ 7 * 2 ^ P.calL * 2 ^ (15 * P.calL + 15) :=
        Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp') hsum
    _ = 2 ^ (16 * P.calL + 22) := by rw [← pow_add, ← pow_add]; congr 1; omega

theorem zd_le : F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 2 ^ (27 * P.calL + 49) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hQ := Q_le P
  have hAle := eBankA_le P
  have hXle := eBankXi_le P
  have hp1 : B.adaP P.eBankA ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  have hp2' : B.adaP P.eBankA + 1 ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  unfold F2e2e.C.Impl.AP.zdQ
  calc 98304000 * B.adaP P.eBankA * (B.adaP P.eBankA + 1) * B.adaQ P.bankM P.bankJ P.bankR P.eBankA *
        (2 ^ P.eBankA * 2 ^ P.eBankXi)
      ≤ 2 ^ 27 * 2 ^ P.calL * 2 ^ P.calL * 2 ^ (16 * P.calL + 22) *
          (2 ^ (6 * P.calL) * 2 ^ (3 * P.calL)) :=
        Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp1) hp2') hQ)
          (Nat.mul_le_mul (Nat.pow_le_pow_right (by norm_num) hAle)
            (Nat.pow_le_pow_right (by norm_num) hXle))
    _ = 2 ^ (27 * P.calL + 49) := by
        rw [← pow_add, ← pow_add, ← pow_add, ← pow_add, ← pow_add]; congr 1; omega

theorem zd_pos : 0 < F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi := F2e2e.C.Impl.AP.zdQ_pos _ _ _ _ _

theorem B0_le : (bankAda P).B0 ≤ 27 * P.calL + 53 := by
  have hz := zd_le P
  show B.adaB0 P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 27 * P.calL + 53
  rw [F2e2e.C.Impl.AP.adaB0_eq]
  apply clog_two_le_of_le_two_pow
  calc 16 * F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 2 ^ 4 * 2 ^ (27 * P.calL + 49) :=
        Nat.mul_le_mul (by norm_num) hz
    _ = 2 ^ (27 * P.calL + 53) := by rw [← pow_add]; congr 1; omega

theorem mK_le (κ : NoiseKind) :
    F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ ≤ 2 ^ (8 * P.calL + 15) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hchi := chi_le P
  have hAle := eBankA_le P
  have hp1 : B.adaP P.eBankA ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  have hc1 : B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 2 ^ P.calL := by omega
  have hE : 2 ^ P.eBankA ≤ 2 ^ (6 * P.calL) := Nat.pow_le_pow_right (by norm_num) hAle
  have key : 32768 * B.adaP P.eBankA * 2 ^ P.eBankA *
      B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 2 ^ (8 * P.calL + 15) := by
    calc _ ≤ 2 ^ 15 * 2 ^ P.calL * 2 ^ (6 * P.calL) * 2 ^ P.calL :=
          Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp1) hE) hc1
      _ = 2 ^ (8 * P.calL + 15) := by rw [← pow_add, ← pow_add, ← pow_add]; congr 1; omega
  have hp0 : 1 ≤ B.adaP P.eBankA := by have := F2e2e.C.Impl.AP.two_le_adaP P.eBankA; omega
  cases κ <;> simp only [F2e2e.C.Impl.AP.mK]
  · exact key
  · calc _ ≤ 32768 * B.adaP P.eBankA * 2 ^ P.eBankA *
          B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi :=
          Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num)))
      _ ≤ _ := key
  · calc 256 * B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA
        ≤ 32768 * B.adaP P.eBankA * 2 ^ P.eBankA *
          B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi := by
          have : 256 ≤ 32768 * B.adaP P.eBankA := by omega
          calc _ = 256 * (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) := by
                ring
            _ ≤ (32768 * B.adaP P.eBankA) *
                (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) :=
                Nat.mul_le_mul_right _ this
            _ = _ := by ring
      _ ≤ _ := key
  · calc 128 * B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA
        ≤ 32768 * B.adaP P.eBankA * 2 ^ P.eBankA *
          B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi := by
          have : 128 ≤ 32768 * B.adaP P.eBankA := by omega
          calc _ = 128 * (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) := by
                ring
            _ ≤ (32768 * B.adaP P.eBankA) *
                (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) :=
                Nat.mul_le_mul_right _ this
            _ = _ := by ring
      _ ≤ _ := key
  · calc 64 * B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA
        ≤ 32768 * B.adaP P.eBankA * 2 ^ P.eBankA *
          B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi := by
          have : 64 ≤ 32768 * B.adaP P.eBankA := by omega
          calc _ = 64 * (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) := by
                ring
            _ ≤ (32768 * B.adaP P.eBankA) *
                (B.adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi * 2 ^ P.eBankA) :=
                Nat.mul_le_mul_right _ this
            _ = _ := by ring
      _ ≤ _ := key


theorem qA_pow_le : 2 ^ (bankAda P).qA ≤ 2 ^ (14 * P.calL) :=
  Nat.pow_le_pow_right (by norm_num) (qA_le P)

theorem scale_eq' (κ : NoiseKind) :
    (bankAda P).scale κ = 1 / ((F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ : ℕ) : ℚ) :=
  F2e2e.C.Impl.AP.scale_eq _ _ _ _ _ κ

theorem qA_add_mK_le (κ : NoiseKind) :
    2 ^ (bankAda P).qA + F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ ≤
      2 ^ (14 * P.calL + 1) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  have hq := qA_pow_le P
  have hm : F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ ≤ 2 ^ (14 * P.calL) :=
    le_trans (mK_le P κ) (Nat.pow_le_pow_right (by norm_num) (by omega))
  rw [pow_succ]
  omega

theorem Ks_le (κ : NoiseKind) : (bankAda P).Ks ((bankAda P).scale κ) ≤ 2 ^ (15 * P.calL + 2) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  have hm0 := F2e2e.C.Impl.AP.mK_pos P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ
  have hmle := mK_le P κ
  have h1 := qA_add_mK_le P κ
  have hB0 := B0_le P
  rw [scale_eq', F2e2e.C.Impl.AP.Ks_eq _ hm0]
  have hB0' : (bankAda P).B0 ≤ 2 ^ P.calL := by omega
  have h2 : F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ ≤ 2 ^ (15 * P.calL + 1) :=
    le_trans hmle (Nat.pow_le_pow_right (by norm_num) (by omega))
  have h3 := Nat.mul_le_mul h1 hB0'
  have h4 : 2 ^ (14 * P.calL + 1) * 2 ^ P.calL = 2 ^ (15 * P.calL + 1) := by
    rw [← pow_add]; congr 1; omega
  have h5 : 2 ^ (15 * P.calL + 2) = 2 * 2 ^ (15 * P.calL + 1) := by rw [pow_succ]; ring
  calc ((2 ^ (bankAda P).qA + F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ) * (bankAda P).B0 +
        F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ - 1) /
        F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ
      ≤ (2 ^ (bankAda P).qA + F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ) * (bankAda P).B0 +
        F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ - 1 := Nat.div_le_self _ _
    _ ≤ 2 ^ (15 * P.calL + 2) := by omega

theorem maxKs_le : maxKs (bankAda P) ≤ 2 ^ (15 * P.calL + 2) := by
  have h1 := Ks_le P NoiseKind.intThr
  have h2 := Ks_le P NoiseKind.intTest
  have h3 := Ks_le P NoiseKind.outThr
  have h4 := Ks_le P NoiseKind.outTest
  have h5 := Ks_le P NoiseKind.num
  unfold maxKs
  simp only [noiseKinds, List.map_cons, List.map_nil, List.foldr_cons, List.foldr_nil]
  omega

theorem rs_le (κ : NoiseKind) : (bankAda P).rs ((bankAda P).scale κ) ≤ 42 * P.calL + 57 := by
  have hz : (bankAda P).zeta = 1 / ((F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.adaZeta_eq _ _ _ _ _
  rw [F2e2e.C.Impl.AP.rs_eq _ _ hz]
  apply clog_two_le_of_le_two_pow
  have hK := Ks_le P κ
  have hzd := zd_le P
  have hK1 : (bankAda P).Ks ((bankAda P).scale κ) + 1 ≤ 2 ^ (15 * P.calL + 3) := by
    have : 1 ≤ 2 ^ (15 * P.calL + 2) := Nat.one_le_two_pow
    rw [pow_succ]; omega
  calc 32 * ((bankAda P).Ks ((bankAda P).scale κ) + 1) *
        F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi
      ≤ 2 ^ 5 * 2 ^ (15 * P.calL + 3) * 2 ^ (27 * P.calL + 49) :=
        Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hK1) hzd
    _ = 2 ^ (42 * P.calL + 57) := by rw [← pow_add, ← pow_add]; congr 1; omega

theorem rho_le (κ : NoiseKind) :
    Nat.size ((bankAda P).rho ((bankAda P).scale κ)).num.toNat ≤ 14 * P.calL + 1 ∧
      Nat.size ((bankAda P).rho ((bankAda P).scale κ)).den ≤ 14 * P.calL + 2 ∧
      Nat.clog 2 ((bankAda P).rho ((bankAda P).scale κ)).den ≤ 14 * P.calL + 1 := by
  have hm0 := F2e2e.C.Impl.AP.mK_pos P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ
  rw [scale_eq', F2e2e.C.Impl.AP.rho_eq _ hm0]
  obtain ⟨hn, hd⟩ := num_den_div_le (2 ^ (bankAda P).qA)
    (2 ^ (bankAda P).qA + F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ) (by positivity)
  have hq := qA_pow_le P
  have hden := qA_add_mK_le P κ
  refine ⟨size_le_of_le ((toNat_le_natAbs _).trans (hn.trans hq)), size_le_of_le (hd.trans hden),
    clog_two_le_of_le_two_pow (hd.trans hden)⟩

/-- The summand of `adaZ` for one noise kind is `≤ 107ℒ + 81`. -/
theorem samp_le (κ : NoiseKind) :
    Nat.size ((bankAda P).scale κ).den + Nat.size ((bankAda P).scale κ).num.natAbs +
      Nat.size ((bankAda P).Ks ((bankAda P).scale κ)) + (bankAda P).rs ((bankAda P).scale κ) +
      Nat.size ((bankAda P).rho ((bankAda P).scale κ)).num.toNat +
      Nat.size ((bankAda P).rho ((bankAda P).scale κ)).den +
      Nat.clog 2 ((bankAda P).rho ((bankAda P).scale κ)).den ≤ 107 * P.calL + 81 := by
  obtain ⟨hs1, hs2⟩ := size_one_div (F2e2e.C.Impl.AP.mK P.bankM P.bankJ P.bankR P.eBankA P.eBankXi κ)
    (8 * P.calL + 15) (F2e2e.C.Impl.AP.mK_pos _ _ _ _ _ κ) (mK_le P κ)
  rw [← scale_eq'] at hs1 hs2
  have hK := size_le_of_le (Ks_le P κ)
  have hr := rs_le P κ
  obtain ⟨hr1, hr2, hr3⟩ := rho_le P κ
  omega

/-! ## The global summands of `adaZ` -/

theorem size_fuel_le : Nat.size (bankAda P).fuel ≤ 15 * P.calL + 11 := by
  have hT := Tmax_sum_le P
  apply size_le_of_le
  show 1 + (bankAda P).Tmax.sum ≤ 2 ^ (15 * P.calL + 10)
  have : 1 ≤ 2 ^ (15 * P.calL + 9) := Nat.one_le_two_pow
  rw [pow_succ]
  omega

theorem size_caps_le :
    Nat.size ((bankAda P).M + (bankAda P).J + (bankAda P).R + 2) ≤ 5 * P.calL + 15 :=
  size_le_of_le (caps_le P)

theorem N_le : (bankAda P).N ≤ 2 ^ (199 + 6 * P.calL) := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  have hsum := (adaRows_le P).1
  have hEta := eEta_le P
  have h4 := pow_four_le_two_pow (k := P.calL) (by omega)
  have hL7 : P.calL ^ 7 ≤ 2 ^ (2 * P.calL) := by
    calc P.calL ^ 7 ≤ P.calL ^ 8 := Nat.pow_le_pow_right (by omega) (by norm_num)
      _ = (P.calL ^ 4) ^ 2 := by ring
      _ ≤ (2 ^ P.calL) ^ 2 := Nat.pow_le_pow_left h4 2
      _ = 2 ^ (2 * P.calL) := by rw [← pow_mul, mul_comm]
  show (bankAda P).blockSizes.sum ≤ _
  calc _ ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := hsum
    _ ≤ 2 ^ 199 * 2 ^ (4 * P.calL) * 2 ^ (2 * P.calL) :=
        Nat.mul_le_mul (Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by norm_num) (by omega))) hL7
    _ = 2 ^ (199 + 6 * P.calL) := by rw [← pow_add, ← pow_add]; congr 1; omega

theorem size_scoreScale_le :
    Nat.size (scoreScale (bankAda P)).den ≤ 21 * P.calL + 8 ∧
      Nat.size (scoreScale (bankAda P)).num.natAbs ≤ 1 := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hAle := eBankA_le P
  have hq := qA_le P
  have hp1 : B.adaP P.eBankA ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  have hp0 : 0 < B.adaP P.eBankA := by have := F2e2e.C.Impl.AP.two_le_adaP P.eBankA; omega
  have e := F2e2e.C.Impl.AP.scoreScale_eq P.eBankA P.eBankXi P.bankM P.bankJ P.bankR
  have e' : scoreScale (bankAda P) = 1 / ((128 * B.adaP P.eBankA * 2 ^ P.eBankA *
      2 ^ (bankAda P).qA : ℕ) : ℚ) := e
  rw [e']
  apply size_one_div _ _ (by positivity)
  calc 128 * B.adaP P.eBankA * 2 ^ P.eBankA * 2 ^ (bankAda P).qA
      ≤ 2 ^ 7 * 2 ^ P.calL * 2 ^ (6 * P.calL) * 2 ^ (14 * P.calL) :=
        Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp1)
          (Nat.pow_le_pow_right (by norm_num) hAle)) (Nat.pow_le_pow_right (by norm_num) hq)
    _ = 2 ^ (21 * P.calL + 7) := by rw [← pow_add, ← pow_add, ← pow_add]; congr 1; omega

theorem size_tau_le :
    Nat.size (bankAda P).tau.den ≤ 7 * P.calL + 4 ∧ Nat.size (bankAda P).tau.num.natAbs ≤ 1 := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hAle := eBankA_le P
  have hp1 : B.adaP P.eBankA ≤ 2 ^ P.calL := by
    have : (bankAda P).p = B.adaP P.eBankA := rfl
    omega
  have hp0 : 0 < B.adaP P.eBankA := by have := F2e2e.C.Impl.AP.two_le_adaP P.eBankA; omega
  have e : (bankAda P).tau = 1 / ((8 * B.adaP P.eBankA * 2 ^ P.eBankA : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.adaTau_eq P.eBankA
  rw [e]
  apply size_one_div _ _ (by positivity)
  calc 8 * B.adaP P.eBankA * 2 ^ P.eBankA ≤ 2 ^ 3 * 2 ^ P.calL * 2 ^ (6 * P.calL) :=
        Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hp1) (Nat.pow_le_pow_right (by norm_num) hAle)
    _ = 2 ^ (7 * P.calL + 3) := by rw [← pow_add, ← pow_add]; congr 1; omega

theorem size_a_half_le :
    Nat.size ((bankAda P).a / 2).den ≤ 6 * P.calL + 2 ∧
      Nat.size ((bankAda P).a / 2).num.natAbs ≤ 1 := by
  have hAle := eBankA_le P
  have e : (bankAda P).a / 2 = 1 / ((2 * 2 ^ P.eBankA : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.a_half_eq P.eBankA P.eBankXi P.bankM P.bankJ P.bankR
  rw [e]
  apply size_one_div _ _ (by positivity)
  calc 2 * 2 ^ P.eBankA ≤ 2 ^ 1 * 2 ^ (6 * P.calL) :=
        Nat.mul_le_mul (by norm_num) (Nat.pow_le_pow_right (by norm_num) hAle)
    _ = 2 ^ (6 * P.calL + 1) := by rw [← pow_add]; congr 1; omega

theorem size_zeta_le :
    Nat.size (bankAda P).zeta.den ≤ 27 * P.calL + 50 ∧
      Nat.size (bankAda P).zeta.num.natAbs ≤ 1 := by
  have e : (bankAda P).zeta = 1 / ((F2e2e.C.Impl.AP.zdQ P.bankM P.bankJ P.bankR P.eBankA P.eBankXi : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.adaZeta_eq _ _ _ _ _
  rw [e]
  exact size_one_div _ _ (zd_pos P) (zd_le P)

/-- **Every summand of `adaZ` is `O(ℒ)`**: `adaZ (bankAda P) ≤ 2^10 ℒ`. -/
theorem adaZ_le : adaZ (bankAda P) ≤ 1024 * P.calL := by
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hq := qA_le P
  have hB0 := B0_le P
  have hfuel := size_fuel_le P
  have hmax := size_le_of_le (maxKs_le P)
  have hcaps := size_caps_le P
  have hN := size_le_of_le (N_le P)
  obtain ⟨hc1, hc2⟩ := size_scoreScale_le P
  obtain ⟨ht1, ht2⟩ := size_tau_le P
  obtain ⟨ha1, ha2⟩ := size_a_half_le P
  obtain ⟨hz1, hz2⟩ := size_zeta_le P
  have k1 := samp_le P NoiseKind.intThr
  have k2 := samp_le P NoiseKind.intTest
  have k3 := samp_le P NoiseKind.outThr
  have k4 := samp_le P NoiseKind.outTest
  have k5 := samp_le P NoiseKind.num
  unfold adaZ
  simp only [noiseKinds, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  omega

end Params

end AdaBoundAux

open AdaBoundAux

/-- **The size bound of W4's encoded ADA state** (the hypothesis `hada` of `F2e2e/C/SpaceBound.lean`):
`adaBoundA (bankAda P) = 2^10 (N + p + 16)(adaZ + 16) ≤ 2^79 N_bank ℒ³`. -/
theorem adaRep_bound_le (P : StreamParams) (_hP : F2e2e.C.Top.ParamsOK P) :
    adaRep.bound P ≤ 2 ^ 79 * bankRows P * P.calL ^ 3 := by
  show adaBoundA (bankAda P) ≤ _
  unfold adaBoundA
  have hZ := adaZ_le P
  obtain ⟨hL, hLL, hL2⟩ := calL_facts P
  obtain ⟨hp2, hp⟩ := p_le P
  have hN : (bankAda P).N ≤ bankRows P := by
    show (bankAda P).blockSizes.sum ≤ (bankAda P).blockSizes.sum + P.Rmax * (P.gCoarse * 32)
    omega
  have hR : 2 ≤ P.Rmax := by unfold StreamParams.Rmax; omega
  have hg : 1 ≤ P.gCoarse := by unfold StreamParams.gCoarse; omega
  have hbr : 2 ≤ bankRows P := by
    have h1 : 2 * (1 * 32) ≤ P.Rmax * (P.gCoarse * 32) :=
      Nat.mul_le_mul hR (Nat.mul_le_mul_right _ hg)
    show 2 ≤ (bankAda P).blockSizes.sum + P.Rmax * (P.gCoarse * 32)
    omega
  have h1 : (bankAda P).N + (bankAda P).p + 16 ≤ bankRows P * (14 * P.calL) := by
    have := Nat.add_le_mul hbr (show 2 ≤ 14 * P.calL by omega)
    omega
  have h2 : adaZ (bankAda P) + 16 ≤ 2 ^ 11 * P.calL := by
    have : (2 : ℕ) ^ 11 = 2048 := by norm_num
    rw [this]
    omega
  have hL1 : 1 ≤ P.calL := by omega
  calc 2 ^ 10 * ((bankAda P).N + (bankAda P).p + 16) * (adaZ (bankAda P) + 16)
      ≤ 2 ^ 10 * (bankRows P * (14 * P.calL)) * (2 ^ 11 * P.calL) :=
        Nat.mul_le_mul (Nat.mul_le_mul_left _ h1) h2
    _ = (2 ^ 21 * 14) * bankRows P * P.calL ^ 2 := by ring
    _ ≤ 2 ^ 79 * bankRows P * P.calL ^ 3 :=
        Nat.mul_le_mul (Nat.mul_le_mul_right _ (by norm_num)) (Nat.pow_le_pow_right hL1 (by norm_num))

/-- **Lemma 6.3 with W4's ADA representation** (partIII.tex L1252–1260): for the parameters of
Theorem (C), every constant multiple `c ≤ 2^167` of the encoded-memory bound
`stateSizeBound P (adaRep.bound P)` fits in `2^512 ε^{-2} Λ^15` (e.g. C-TOP's uniform value bound
`Mv adaRep P = 2^32 · stateSizeBound P (adaRep.bound P)`). -/
theorem const_mul_stateSizeBound_adaRep_le_spaceBoundC {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n)
    (hm : 1 ≤ m) (hU : 1 ≤ U) (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {c : ℝ} (hc0 : 0 ≤ c)
    (hc : c ≤ 2 ^ 167) :
    c * (stateSizeBound (mkStreamParams n m U ε β) (adaRep.bound (mkStreamParams n m U ε β)) : ℝ) ≤
      spaceBoundC n m U ε β :=
  const_mul_stateSizeBound_le_spaceBoundC hn hm hU hε0 hε1 hβ0 hβ1 (adaRep_bound_le _ hP) hc0 hc

end F2e2e.C.Space
