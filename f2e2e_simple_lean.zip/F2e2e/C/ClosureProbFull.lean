import F2e2e.C.ClosureProbStreams
import F2e2e.C.ClosureWP

/-!
# Theorem 6.4, probability layer (C-PROB): the whole canonical interaction as one controller program

The `m`-round interaction of the instrumented algorithm with a deterministic adversary is one program of the
free monad `AlgM` (`fullCode`): the initialization code, then `t` rounds of the round code, each fed with the
adversary's update computed from the outputs so far. Its instrumented interpretation (`runL`) from the initial
oracle state and ghost is the tagged interaction `interactT` (`interactT_eq`). Consequently every path property of
the instrumented interpreter on the controller program `fullCode` (C-CLOSE's `Outcome`, `WP`) is a property of
the canonical run.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg

/-- The canonical interaction up to round `t` as one controller program: initialization, then the rounds
`0, …, t-1` against the deterministic adversary `adv`; returns the controller state and the outputs so far. -/
def fullCode (P : StreamParams) (adv : StreamAdversary P.n) : ℕ → AlgM (CState × List ℚ)
  | 0 => initCode.bind fun c => AlgM.pure (c, [])
  | t + 1 => (fullCode P adv t).bind fun co =>
      (roundCode P co.1 (adv co.2).1.val (adv co.2).2).bind fun r => AlgM.pure (r.1, co.2 ++ [r.2])

/-- A final result of the controller program, packed as a configuration of the tagged interaction. -/
def packC (r : (CState × List ℚ) × OState × Ghost) : Option ((State × Ghost) × List ℚ) :=
  some ((State.mk' r.1.1 r.2.1, r.2.2), r.1.2)

/-- **The tagged interaction is the instrumented interpretation of the controller program `fullCode`.** -/
theorem interactT_eq (P : StreamParams) (adv : StreamAdversary P.n) (t : ℕ) :
    interactT P adv t = (runL P (fullCode P adv t) initO Ghost.init).map packC := by
  induction t with
  | zero =>
    show ((runL P initCode initO Ghost.init).map fun r => (State.mk' r.1 r.2.1, r.2.2)).map
        (fun s => some (s, [])) = _
    rw [fullCode, runL_bind]
    simp only [TBitProg.map, TBitProg.bind_assoc]
    rfl
  | succ t ih =>
    show (interactT P adv t).bind (roundT P adv) = _
    rw [ih, fullCode, runL_bind]
    simp only [TBitProg.map, TBitProg.bind_assoc]
    congr 1
    funext r
    rw [runL_bind]
    simp only [Function.comp_apply, bind_pure', TBitProg.bind_assoc]
    show (algStepL P (State.mk' r.1.1 r.2.1, r.2.2) (adv r.1.2)).map _ = _
    simp only [algStepL, TBitProg.map, TBitProg.bind_assoc]
    rfl

end F2e2e.C.Closure
