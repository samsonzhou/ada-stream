import F2e2e.Spec
import F2e2e.Lib.Discrete.BitProg
import F2e2e.C.FingerprintPoly

/-!
# Generic stopping-time coupling for the homomorphic zero fingerprint

Paper: `parts/partII.tex` Lemma `R:lem:zero-fingerprint` (3) (L246–249, proof L267–285).

This file proves the coupling argument for an **abstract** streaming algorithm whose state carries
a fingerprint seed and a fingerprint register, and whose only use of these registers is the
zero test of Algorithm `R:alg:zero-fingerprint`, Line 6. The concrete algorithm of Theorem C
(`F2e2e/C/Alg/Round.lean`) is an instance (`F2e2e/C/FingerprintAlg.lean`).

**Abstract round.** `FpRound n q S` packages, for the state type `S`, projections `seed`, `val`,
`failed`, an "erasure" `erase` forgetting the fingerprint registers, and a round
`stepZ s u z : BitProg (S × ℚ)` in which the zero test of the update `u = (i, Δ)` is replaced by
the external bit `z`. Hypotheses: a failed state ignores `z`; the erased output depends only on
the erased input (the registers are never read except through `z`); the registers evolve by the
homomorphic update `F ← F + Δ r^{i+1}` (eq. `R:eq:fingerprint-recurrence`).

* The **real** execution uses `z = [F_zero(x^{(t+1)}) = 0]` computed from the registers
  (`realZ`); the **ideal** one uses the exact zero oracle `z = [x^{(t+1)} = 0]` (`idealZ`).
* `runZ_fp_inv`: the registers track `x` (part (1)).
* `runZ_ideal_erase`: the ideal execution does not depend on the seed (L269).
* `runZ_real_eq_ideal`: the two executions coincide up to the first disagreement (L271–275).
* `card_seeds_badFrom_le`: for a fixed rest of the randomness, at most `m n` of the `q` seeds lead
  to a false zero within the box promise (L277–283: union over `m` rounds of the `≤ n` roots of the
  nonzero polynomial `P_t`).
-/

namespace F2e2e.C.FP

open F2e2e.Discrete Finset

/-! ### Every-path predicate on bit programs -/

/-- `BPAll p Q`: every output of `p`, on every path of bits, satisfies `Q`. -/
def BPAll {α : Type} : BitProg α → (α → Prop) → Prop
  | BitProg.pure a, Q => Q a
  | BitProg.bit k, Q => ∀ b, BPAll (k b) Q

theorem BPAll.of_run {α : Type} {Q : α → Prop} :
    ∀ {p : BitProg α}, BPAll p Q → ∀ {t : List Bool} {a : α} {r : List Bool},
      p.run t = some (a, r) → Q a
  | BitProg.pure a, h, t, a', r, hr => by
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hr
    exact hr.1 ▸ h
  | BitProg.bit _, _, [], _, _, hr => by simp at hr
  | BitProg.bit k, h, b :: t, a', r, hr => by
    simp only [BitProg.run_bit_cons] at hr
    exact BPAll.of_run (h b) hr

/-! ### Stream vectors from output histories -/

variable {n : ℕ}

/-- The stream vector after the update of round `outs.length`, the update of round `s` being
`adv (outs.take s)` (the formula of `F2e2e.streamVec`). -/
def vecOf (adv : List ℚ → Fin n × ℤ) (outs : List ℚ) (i : Fin n) : ℤ :=
  ∑ s ∈ range (outs.length + 1), if (adv (outs.take s)).1 = i then (adv (outs.take s)).2 else 0

/-- The stream vector before the update of round `outs.length`. -/
def vecBefore (adv : List ℚ → Fin n × ℤ) (outs : List ℚ) (i : Fin n) : ℤ :=
  ∑ s ∈ range outs.length, if (adv (outs.take s)).1 = i then (adv (outs.take s)).2 else 0

theorem vecOf_eq (adv : List ℚ → Fin n × ℤ) (outs : List ℚ) :
    vecOf adv outs = fun i => vecBefore adv outs i + if i = (adv outs).1 then (adv outs).2 else 0 := by
  funext i
  simp only [vecOf, vecBefore, Finset.sum_range_succ, List.take_length]
  congr 1
  by_cases h : (adv outs).1 = i
  · simp [h]
  · simp [h, Ne.symm h]

theorem vecBefore_append (adv : List ℚ → Fin n × ℤ) (outs : List ℚ) (y : ℚ) :
    vecBefore adv (outs ++ [y]) = vecOf adv outs := by
  funext i
  simp only [vecBefore, vecOf, List.length_append, List.length_singleton]
  refine Finset.sum_congr rfl fun s hs => ?_
  have hs' : s ≤ outs.length := Nat.lt_succ_iff.mp (Finset.mem_range.mp hs)
  rw [List.take_append_of_le_length hs']

@[simp] theorem vecBefore_nil (adv : List ℚ → Fin n × ℤ) : vecBefore adv [] = 0 := by
  funext i
  simp [vecBefore]

/-! ### The abstract round -/

/-- The fingerprint register after the update `u = (i, Δ)`: `F + Δ r^{i+1}` (0-based `i`). -/
def fpNext (q : ℕ) (seed val : ℕ) (u : Fin n × ℤ) : ZMod q :=
  (val : ZMod q) + (u.2 : ZMod q) * (seed : ZMod q) ^ (u.1.val + 1)

/-- An abstract streaming round with a homomorphic zero fingerprint (see the module doc). -/
structure FpRound (n q : ℕ) (S : Type) where
  /-- The fingerprint seed `r_fp`. -/
  seed : S → ℕ
  /-- The fingerprint register `F_zero`. -/
  val : S → ℕ
  /-- The absorbing failure flag. -/
  failed : S → Bool
  /-- Forget the fingerprint registers. -/
  erase : S → S
  /-- One round for the update `u` with the zero test replaced by the bit `z`. -/
  stepZ : S → Fin n × ℤ → Bool → BitProg (S × ℚ)
  /-- A failed state ignores the zero bit. -/
  stepZ_failed : ∀ s u z z', failed s = true → stepZ s u z = stepZ s u z'
  /-- Erasure commutes with the failure flag. -/
  failed_erase : ∀ s, failed (erase s) = failed s
  /-- The registers are never read except through the zero bit. -/
  stepZ_erase : ∀ s u z, (stepZ s u z).map (fun r => (erase r.1, r.2)) =
    (stepZ (erase s) u z).map (fun r => (erase r.1, r.2))
  /-- The registers evolve by the homomorphic update (eq. `R:eq:fingerprint-recurrence`); a round
  ending in a non-failed state started from a non-failed state. -/
  stepZ_fp : ∀ s u z, BPAll (stepZ s u z) (fun r => seed r.1 = seed s ∧
    (failed r.1 = false → failed s = false ∧ (val r.1 : ZMod q) = fpNext q (seed s) (val s) u))

variable {q : ℕ} {S : Type}

/-- The run from the initial state `s0`, the zero bit of round `t` being `zf s outs` for the state
`s` before round `t` and the outputs `outs` of rounds `< t`; the bits of round `t` are `tp (t+1)`. -/
def runZ (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (zf : S → List ℚ → Bool)
    (tp : ℕ → List Bool) (s0 : S) : ℕ → Option (S × List ℚ)
  | 0 => some (s0, [])
  | t + 1 => (runZ A adv zf tp s0 t).bind fun c =>
      ((A.stepZ c.1 (adv c.2) (zf c.1 c.2)).run (tp (t + 1))).map
        fun r => (r.1.1, c.2 ++ [r.1.2])

/-- The real zero test (Algorithm `R:alg:zero-fingerprint`, Line 6): `F_zero(x^{(t+1)}) = 0`. -/
def realZ (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (s : S) (outs : List ℚ) : Bool :=
  decide (fpNext q (A.seed s) (A.val s) (adv outs) = 0)

/-- The exact zero oracle of the ideal execution: `x^{(t+1)} = 0`. -/
def idealZ (_A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (_s : S) (outs : List ℚ) : Bool :=
  decide (vecOf adv outs = 0)

/-- A false zero within the box promise: some round `t < m`, reached from a non-failed state, with
the box promise after the rounds `0, …, t`, has `x^{(t+1)} ≠ 0` but the real test reports zero. -/
def BadFrom (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (U m : ℕ) (tp : ℕ → List Bool)
    (s0 : S) : Prop :=
  ∃ t < m, ∃ c, runZ A adv (realZ A adv) tp s0 t = some c ∧ A.failed c.1 = false ∧
    (∀ s ≤ t, ∀ j, |vecOf adv (c.2.take s) j| ≤ (U : ℤ)) ∧ vecOf adv c.2 ≠ 0 ∧
      realZ A adv c.1 c.2 = true

section Lemmas

variable (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ) (tp : ℕ → List Bool)

theorem runZ_succ_some {zf : S → List ℚ → Bool} {s0 : S} {t : ℕ} {c' : S × List ℚ}
    (h : runZ A adv zf tp s0 (t + 1) = some c') :
    ∃ c, runZ A adv zf tp s0 t = some c ∧ ∃ (s' : S) (y : ℚ) (rest : List Bool),
      (A.stepZ c.1 (adv c.2) (zf c.1 c.2)).run (tp (t + 1)) = some ((s', y), rest) ∧
        c' = (s', c.2 ++ [y]) := by
  simp only [runZ] at h
  obtain ⟨c, hc, h⟩ := Option.bind_eq_some_iff.mp h
  obtain ⟨r, hr, rfl⟩ := Option.map_eq_some_iff.mp h
  exact ⟨c, hc, r.1.1, r.1.2, r.2, hr, rfl⟩

/-- The outputs before round `t` have length `t`. -/
theorem runZ_length {zf : S → List ℚ → Bool} {s0 : S} :
    ∀ {t : ℕ} {c : S × List ℚ}, runZ A adv zf tp s0 t = some c → c.2.length = t
  | 0, c, h => by
    simp only [runZ, Option.some.injEq] at h
    rw [← h]
    rfl
  | t + 1, c, h => by
    obtain ⟨c₀, h₀, s', y, rest, -, rfl⟩ := runZ_succ_some A adv tp h
    simp [runZ_length h₀]

/-- Earlier rounds of a run: the outputs are prefixes. -/
theorem runZ_prefix {zf : S → List ℚ → Bool} {s0 : S} :
    ∀ {t : ℕ} {c : S × List ℚ}, runZ A adv zf tp s0 t = some c →
      ∀ s ≤ t, ∃ c', runZ A adv zf tp s0 s = some c' ∧ c'.2 = c.2.take s
  | 0, c, h, s, hs => by
    have hs0 : s = 0 := Nat.le_zero.mp hs
    subst hs0
    refine ⟨c, h, ?_⟩
    simp only [runZ, Option.some.injEq] at h
    rw [← h]
    rfl
  | t + 1, c, h, s, hs => by
    obtain ⟨c₀, h₀, s', y, rest, -, rfl⟩ := runZ_succ_some A adv tp h
    rcases Nat.lt_or_eq_of_le hs with hs | rfl
    · obtain ⟨c', hc', hc'2⟩ := runZ_prefix h₀ s (Nat.lt_succ_iff.mp hs)
      refine ⟨c', hc', ?_⟩
      rw [hc'2]
      have hlen := runZ_length A adv tp h₀
      rw [List.take_append_of_le_length (by omega)]
    · refine ⟨_, h, ?_⟩
      have hlen := runZ_length A adv tp h₀
      simp [hlen]

/-- **Part (1), homomorphic invariant**: the seed never changes, and in a non-failed state the
register is the fingerprint `∑_j x_j r^{j+1}` of the current stream vector. -/
theorem runZ_fp_inv (zf : S → List ℚ → Bool) (s0 : S) (h0 : A.val s0 = 0) :
    ∀ (t : ℕ) (c : S × List ℚ), runZ A adv zf tp s0 t = some c →
      A.seed c.1 = A.seed s0 ∧ (A.failed c.1 = false →
        (A.val c.1 : ZMod q) = fpEval q (vecBefore adv c.2) (A.seed s0))
  | 0, c, h => by
    simp only [runZ, Option.some.injEq] at h
    subst h
    refine ⟨rfl, fun _ => ?_⟩
    simp [h0]
  | t + 1, c', h => by
    obtain ⟨c, hc, s', y, rest, hrun, rfl⟩ := runZ_succ_some A adv tp h
    obtain ⟨ih1, ih2⟩ := runZ_fp_inv zf s0 h0 t c hc
    have hfp := BPAll.of_run (A.stepZ_fp c.1 (adv c.2) (zf c.1 c.2)) hrun
    refine ⟨hfp.1.trans ih1, fun hf => ?_⟩
    obtain ⟨hf0, hval⟩ := hfp.2 hf
    rw [hval, vecBefore_append, vecOf_eq, fpNext, ih2 hf0, ih1]
    exact (fpEval_add_single _ _ _ _).symm

/-- The real test is the fingerprint test of the vector after the update. -/
theorem realZ_eq_of_inv {s0 : S} {c : S × List ℚ} (hseed : A.seed c.1 = A.seed s0)
    (hval : (A.val c.1 : ZMod q) = fpEval q (vecBefore adv c.2) (A.seed s0)) :
    realZ A adv c.1 c.2 = decide (fpEval q (vecOf adv c.2) (A.seed s0) = 0) := by
  simp only [realZ, fpNext, hval, hseed, vecOf_eq]
  rw [fpEval_add_single]

/-- **Coupling** (L271–275): if up to round `t` the real run has no false zero, then the real and
the ideal runs coincide up to round `t`. -/
theorem runZ_real_eq_ideal (s0 : S) (h0 : A.val s0 = 0) :
    ∀ t : ℕ, (∀ s < t, ∀ c, runZ A adv (realZ A adv) tp s0 s = some c → A.failed c.1 = false →
      realZ A adv c.1 c.2 = true → vecOf adv c.2 = 0) →
      runZ A adv (realZ A adv) tp s0 t = runZ A adv (idealZ A adv) tp s0 t
  | 0, _ => rfl
  | t + 1, hgood => by
    have ih := runZ_real_eq_ideal s0 h0 t (fun s hs c hc => hgood s (Nat.lt_succ_of_lt hs) c hc)
    simp only [runZ]
    rw [ih]
    refine Option.bind_congr fun c hc => ?_
    congr 2
    by_cases hf : A.failed c.1 = true
    · exact A.stepZ_failed _ _ _ _ hf
    · have hf' : A.failed c.1 = false := by simpa using hf
      congr 1
      have hc' : runZ A adv (realZ A adv) tp s0 t = some c := ih.trans hc
      obtain ⟨hseed, hval⟩ := runZ_fp_inv A adv tp (realZ A adv) s0 h0 t c hc'
      have hz := realZ_eq_of_inv A adv hseed (hval hf')
      by_cases hv : vecOf adv c.2 = 0
      · rw [hz, idealZ, hv]
        simp
      · have hr : realZ A adv c.1 c.2 = false := by
          by_contra hr
          exact hv (hgood t (Nat.lt_succ_self t) c hc' hf' (by simpa using hr))
        rw [hr, idealZ]
        simp [hv]

/-- **The ideal run does not depend on the seed** (L269): its erased states and its outputs depend
only on the erased initial state. -/
theorem runZ_ideal_erase {s0 s0' : S} (h : A.erase s0 = A.erase s0') :
    ∀ t, (runZ A adv (idealZ A adv) tp s0 t).map (fun c => (A.erase c.1, c.2)) =
      (runZ A adv (idealZ A adv) tp s0' t).map (fun c => (A.erase c.1, c.2))
  | 0 => by simp [runZ, h]
  | t + 1 => by
    have key : ∀ c : S × List ℚ,
        (((A.stepZ c.1 (adv c.2) (idealZ A adv c.1 c.2)).run (tp (t + 1))).map
          fun r => (r.1.1, c.2 ++ [r.1.2])).map (fun c => (A.erase c.1, c.2)) =
        (((A.stepZ (A.erase c.1) (adv c.2) (decide (vecOf adv c.2 = 0))).run (tp (t + 1))).map
          fun r => (A.erase r.1.1, c.2 ++ [r.1.2])) := by
      intro c
      have h1 := congrArg (fun p => p.run (tp (t + 1)))
        (A.stepZ_erase c.1 (adv c.2) (decide (vecOf adv c.2 = 0)))
      simp only [BitProg.run_map] at h1
      have h2 := congrArg (Option.map fun r : (S × ℚ) × List Bool => (r.1.1, c.2 ++ [r.1.2])) h1
      simp only [Option.map_map] at h2
      simp only [Option.map_map, idealZ]
      exact h2
    have hstep : ∀ s₀ : S,
        (runZ A adv (idealZ A adv) tp s₀ (t + 1)).map (fun c => (A.erase c.1, c.2)) =
        ((runZ A adv (idealZ A adv) tp s₀ t).map (fun c => (A.erase c.1, c.2))).bind (fun c =>
          ((A.stepZ c.1 (adv c.2) (decide (vecOf adv c.2 = 0))).run (tp (t + 1))).map
            fun r => (A.erase r.1.1, c.2 ++ [r.1.2])) := by
      intro s₀
      simp only [runZ]
      rw [Option.map_bind, Option.bind_map]
      congr 1
      funext c
      exact key c
    rw [hstep s0, hstep s0', runZ_ideal_erase h t]

/-- A real false zero within the box promise gives an ideal one at the same round (first
disagreement, L271–277). -/
theorem badFrom_ideal (s0 : S) (h0 : A.val s0 = 0) {U m : ℕ}
    (hbad : BadFrom A adv U m tp s0) :
    ∃ t < m, ∃ c, runZ A adv (idealZ A adv) tp s0 t = some c ∧ A.failed c.1 = false ∧
      (∀ j, |vecOf adv c.2 j| ≤ (U : ℤ)) ∧ vecOf adv c.2 ≠ 0 ∧ realZ A adv c.1 c.2 = true := by
  classical
  let Bad : ℕ → Prop := fun t => t < m ∧ ∃ c, runZ A adv (realZ A adv) tp s0 t = some c ∧
    A.failed c.1 = false ∧ (∀ s ≤ t, ∀ j, |vecOf adv (c.2.take s) j| ≤ (U : ℤ)) ∧
    vecOf adv c.2 ≠ 0 ∧ realZ A adv c.1 c.2 = true
  have hex : ∃ t, Bad t := by
    obtain ⟨t, ht, c, h1, h2, h3, h4, h5⟩ := hbad
    exact ⟨t, ht, c, h1, h2, h3, h4, h5⟩
  obtain ⟨t, ⟨htm, c, hc, hf, hbox, hv, hz⟩, hmin⟩ : ∃ t, Bad t ∧ ∀ s < t, ¬ Bad s :=
    ⟨Nat.find hex, Nat.find_spec hex, fun s hs => Nat.find_min hex hs⟩
  have hlen := runZ_length A adv tp hc
  -- no false zero before `t` in the real run
  have hgood : ∀ s < t, ∀ c', runZ A adv (realZ A adv) tp s0 s = some c' → A.failed c'.1 = false →
      realZ A adv c'.1 c'.2 = true → vecOf adv c'.2 = 0 := by
    intro s hs c' hc' hf' hz'
    by_contra hv'
    apply hmin s hs
    refine ⟨lt_trans hs htm, c', hc', hf', fun s' hs' j => ?_, hv', hz'⟩
    obtain ⟨c'', hc'', hc''2⟩ := runZ_prefix A adv tp hc s (le_of_lt hs)
    rw [hc''] at hc'
    cases hc'
    rw [hc''2, List.take_take, min_eq_left hs']
    exact hbox s' (le_trans hs' (le_of_lt hs)) j
  have heq := runZ_real_eq_ideal A adv tp s0 h0 t hgood
  refine ⟨t, htm, c, heq ▸ hc, hf, fun j => ?_, hv, hz⟩
  have := hbox t le_rfl j
  rwa [List.take_of_length_le (le_of_eq hlen)] at this

end Lemmas

/-! ### Counting the bad seeds -/

open Classical in
/-- **Seed count** (L277–283): for a fixed rest of the randomness (`mk r` is the initial state
with seed `r`; the initial register is `0`; the erased initial state does not depend on `r`), at
most `m · n` of the seeds `r ∈ {0, …, q-1}` lead to a false zero within the box promise `U < q`. -/
theorem card_seeds_badFrom_le [Fact q.Prime] (A : FpRound n q S) (adv : List ℚ → Fin n × ℤ)
    (U m : ℕ) (hU : U < q) (tp : ℕ → List Bool) (mk : ℕ → S)
    (hseed : ∀ r, A.seed (mk r) = r) (hval : ∀ r, A.val (mk r) = 0)
    (herase : ∀ r, A.erase (mk r) = A.erase (mk 0)) :
    ((range q).filter (fun r => BadFrom A adv U m tp (mk r))).card ≤ m * n := by
  classical
  -- the reference ideal run (seed `0`) and its stream vectors
  let X : ℕ → Fin n → ℤ := fun t =>
    match runZ A adv (idealZ A adv) tp (mk 0) t with
    | some c => vecOf adv c.2
    | none => 0
  let T : ℕ → Finset ℕ := fun t =>
    if X t ≠ 0 ∧ ∀ j, |X t j| ≤ (U : ℤ) then (range q).filter (fun r => fpEval q (X t) (r : ZMod q) = 0)
    else ∅
  have hT : ∀ t, (T t).card ≤ n := by
    intro t
    simp only [T]
    split_ifs with h
    · exact card_fpEval_eq_zero_le_nat h.1 fun j => lt_of_le_of_lt (h.2 j) (by exact_mod_cast hU)
    · simp
  have hsub : (range q).filter (fun r => BadFrom A adv U m tp (mk r)) ⊆ (range m).biUnion T := by
    intro r hr
    simp only [Finset.mem_filter, Finset.mem_range] at hr
    obtain ⟨hrq, hbad⟩ := hr
    obtain ⟨t, htm, c, hc, hf, hbox, hv, hz⟩ := badFrom_ideal A adv tp (mk r) (hval r) hbad
    simp only [Finset.mem_biUnion, Finset.mem_range]
    refine ⟨t, htm, ?_⟩
    -- the reference run has the same outputs at round `t`
    have he := runZ_ideal_erase A adv tp (herase r) t
    rw [hc] at he
    obtain ⟨c0, hc0, hce⟩ : ∃ c0, runZ A adv (idealZ A adv) tp (mk 0) t = some c0 ∧
        (A.erase c.1, c.2) = (A.erase c0.1, c0.2) := by
      cases h0 : runZ A adv (idealZ A adv) tp (mk 0) t with
      | none => rw [h0] at he; simp at he
      | some c0 =>
        rw [h0] at he
        simp only [Option.map_some, Option.some.injEq] at he
        exact ⟨c0, rfl, he⟩
    have hc2 : c.2 = c0.2 := (Prod.mk.inj hce).2
    have hX : X t = vecOf adv c.2 := by
      simp only [X, hc0, hc2]
    -- the real test at round `t` is the fingerprint test of `x^{(t+1)}` with seed `r`
    obtain ⟨hseed', hval'⟩ := runZ_fp_inv A adv tp (idealZ A adv) (mk r) (hval r) t c hc
    have hz' := realZ_eq_of_inv A adv hseed' (hval' hf)
    rw [hz, hseed] at hz'
    simp only [T, hX]
    rw [if_pos ⟨hv, hbox⟩]
    simp only [Finset.mem_filter, Finset.mem_range]
    exact ⟨hrq, by simpa using hz'.symm⟩
  calc ((range q).filter (fun r => BadFrom A adv U m tp (mk r))).card
      ≤ ((range m).biUnion T).card := Finset.card_le_card hsub
    _ ≤ ∑ t ∈ range m, (T t).card := Finset.card_biUnion_le
    _ ≤ ∑ _t ∈ range m, n := Finset.sum_le_sum fun t _ => hT t
    _ = m * n := by simp

end F2e2e.C.FP
