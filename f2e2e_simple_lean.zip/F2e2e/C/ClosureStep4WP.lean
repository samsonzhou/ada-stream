import Mathlib
import F2e2e.C.ClosureStep1WP

/-!
# Theorem 6.4: the invariant through Step 4 (proofs: C-ALG; statements: C-CLOSE)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree`, Step 4 (L495–513; Theorem 5.9: the returned value
of depth `d` has accuracy `8(ℓ+1)η`, `ℓ = H − d`), as coded in `F2e2e/C/Alg/AlgMCode.lean` (`step4DepthCode`,
`rejectDepthCode`, `rejectTailCode`, `step4LoopCode`, `step4Code`).

At the moment `evals D` (the depths `≥ D` evaluated) the returned value `F ≥ 0` approximates `‖x_D‖²` within
`8(H − D + 1)η‖x_D‖²` (exactly `‖x_H‖²` at the start, Lemma 5.3); at the end `F` approximates `‖x_0‖² = F₂(x)` within
`8(H+1)η`. The bank calls go through `val_glue` / `rel_glue` (`F2e2e/C/ClosureCalls.lean`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Helpers (C-ALG) -/

theorem s4_time {D : ℕ} {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.evals D) c o g) :
    (shadowOf P g).t = c.t + 1 := by
  have := h.time
  simpa [phIdle] using this

theorem s4_live (D : ℕ) : (Tree.Phase.evals D).live P.H = P.H := rfl

theorem s4_x_accept (S : Tree.TreeSt P) (d j : ℕ) : (S.step P (.accept d)).x j = S.x j := by
  unfold Tree.TreeState.x
  rfl

theorem s4_x_correct (S : Tree.TreeSt P) (d : ℕ) (c : ℝ) {j : ℕ} (hj : j ≤ d) :
    (S.step P (.correct d c)).x j = S.x j := by
  unfold Tree.TreeState.x
  rw [Tree.TreeState.step_correct_x0]
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  have hi' : i < d := by simp at hi; omega
  rw [Tree.TreeState.step_correct_r, if_neg (by omega), if_neg (by omega)]

theorem s4_x_sub_y (S : Tree.TreeSt P) (d : ℕ) : S.x d - S.y d = S.r d := by
  unfold Tree.TreeState.y Tree.TreeState.x
  rw [Finset.sum_range_succ]
  abel

/-- A rational value with a numerical certificate exists for every energy (used to obtain the tree invariant
after a correction before the refreshing release is made). -/
theorem s4_exists_numCert (P : StreamParams) (F : ℝ) (hF : 0 ≤ F) :
    ∃ q : ℚ, 0 ≤ q ∧ NumCert (P.eta : ℝ) (P.omega : ℝ) F (q : ℝ) := by
  have hω : (0 : ℝ) < P.omega := by exact_mod_cast omega_pos_q P
  have hη : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
  obtain ⟨q, hq1, hq2⟩ := exists_rat_btwn (show F < F + P.omega by linarith)
  refine ⟨q, ?_, ?_⟩
  · have : (0 : ℝ) ≤ q := le_trans hF hq1.le
    exact_mod_cast this
  · unfold NumCert
    rw [abs_of_nonneg (by linarith)]
    have : 0 ≤ (1 / 2 : ℝ) ^ 13 * P.eta * F := by positivity
    linarith

theorem s4_countCorrection_jUsed {L L' : Learner} (h : Learner.countCorrection P L = some L') :
    L'.jUsed = L.jUsed + 1 := by
  unfold Learner.countCorrection at h
  by_cases h1 : L.jEpoch + 1 = P.K0
  · rw [if_pos h1] at h
    by_cases h2 : L.epoch + 1 ≤ P.Kepoch
    · rw [if_pos h2] at h
      cases h
      rfl
    · rw [if_neg h2] at h
      cases h
  · rw [if_neg h1] at h
    cases h
    rfl

theorem s4_countCorrection_tag {L L' : Learner} (h : Learner.countCorrection P L = some L') :
    L'.tag = L.tag := by
  unfold Learner.countCorrection at h
  by_cases h1 : L.jEpoch + 1 = P.K0
  · rw [if_pos h1] at h
    by_cases h2 : L.epoch + 1 ≤ P.Kepoch
    · rw [if_pos h2] at h
      cases h
      rfl
    · rw [if_neg h2] at h
      cases h
  · rw [if_neg h1] at h
    cases h
    rfl

theorem s4_getD_setAt {α : Type} (b dflt : α) (l : List α) (k j : ℕ) (hk : k < l.length) :
    (setAt b k l).getD j dflt = if j = k then b else l.getD j dflt := by
  rw [List.getD_eq_getElem?_getD, getElem?_setAt, List.getD_eq_getElem?_getD]
  split_ifs with h1 h2 h2
  · rfl
  · exact absurd h1.1 h2
  · exact absurd ⟨h2, h2 ▸ hk⟩ h1
  · rfl

theorem s4_getD_mapFrom {α : Type} (f : α → α) (dflt : α) (l : List α) (k j : ℕ) (hj : j < l.length) :
    (mapFrom f k l).getD j dflt = if k ≤ j then f (l.getD j dflt) else l.getD j dflt := by
  rw [List.getD_eq_getElem?_getD, getElem?_mapFrom, List.getD_eq_getElem?_getD,
    List.getElem?_eq_getElem hj]
  split_ifs <;> rfl

/-- The joint invariant after `ACCEPT` at depth `d` (pure). -/
theorem s4_jointInv_accept {c : CState} {o o' : OState} {g g' : Ghost} {d : ℕ}
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H)
    (htp : TreePart P (.evals d) c ((shadowOf P g).step P (.accept d)) (g.events.length + 1))
    (hcp : CountPart P (.evals d) c g') (hsp : StatePart P o' g')
    (he : g'.events = g.events ++ [TreeEvent.accept d]) (hh : g'.hists = g.hists) :
    JointInv P (.evals d) c o' g' := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.accept d) := shadowOf_snoc P he (toTreeEv_accept d)
  have hlen : g'.events.length = g.events.length + 1 := by rw [he]; simp
  have hlenH : g.hists.length ≤ P.H := by rw [h.hists_len_H rfl]
  refine ⟨?_, ?_, hcp, hsp, h.notFailed, ?_⟩
  · rw [hS, hlen]; exact htp
  · rw [hS, hlen, hh]; exact bankPart_accept h.tp.tree h.bp hd hlenH
  · rw [hS]
    simp [phIdle, s4_time h]

/-- The joint invariant after a correction at depth `d` (pure). -/
theorem s4_jointInv_correct {c c' : CState} {o o' : OState} {g g' : Ghost} {d : ℕ} {cInt : ℤ}
    (h : JointInv P (.evals (d + 1)) c o g)
    (htp : TreePart P (.evals d) c'
      ((shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) (g.events.length + 1))
    (hbp : BankPart P (.evals d) ((shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)))
      g'.hists (g.events.length + 1))
    (hct : c'.t = c.t) (hcf : c'.failed = c.failed)
    (hcp : CountPart P (.evals d) c' g') (hsp : StatePart P o' g')
    (he : g'.events = g.events ++ [TreeEvent.correct d cInt]) :
    JointInv P (.evals d) c' o' g' := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)) :=
    shadowOf_snoc P he (toTreeEv_correct d cInt)
  have hlen : g'.events.length = g.events.length + 1 := by rw [he]; simp
  refine ⟨?_, ?_, hcp, hsp, ?_, ?_⟩
  · rw [hS, hlen]; exact htp
  · rw [hS, hlen]; exact hbp
  · rw [hcf]; exact h.notFailed
  · rw [hS]
    simp [phIdle, s4_time h, hct]

theorem s4_x_zero (S : Tree.TreeSt P) : S.x 0 = S.x0 := by
  unfold Tree.TreeState.x
  simp

/-! ## The postconditions of Step 4 at one depth (pure) -/

theorem s4_post_accept (hP : ParamsOK P) {c : CState} {o o' : OState} {g g' : Ghost} {d : ℕ}
    {S0 θ : ℚ} {Bd : Bank}
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H)
    (htp : TreePart P (.evals d) c ((shadowOf P g).step P (.accept d)) (g.events.length + 1))
    (hsp : StatePart P o' g')
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls ++ [valRec P g d Bd S0 θ AdaCert.accept])
    (he : g'.events = g.events ++ [TreeEvent.accept d]) (hh : g'.hists = g.hists)
    (hos : o'.fpSeed = o.fpSeed) (hov : o'.fpVal = o.fpVal)
    (hS0 : 0 ≤ S0)
    (hacc : |(S0 : ℝ) - ‖(shadowOf P g).x d‖ ^ 2| ≤
      8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g).x d‖ ^ 2) :
    JointInv P (.evals d) c o' g' ∧ Frame (P := P) c o g c o' g' ∧ 0 ≤ S0 ∧
      |(S0 : ℝ) - ‖(shadowOf P g').x d‖ ^ 2| ≤
        8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g').x d‖ ^ 2 := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.accept d) := shadowOf_snoc P he (toTreeEv_accept d)
  have hcp := countPart_accept hP h.cp hd (valRec P g d Bd S0 θ AdaCert.accept) rfl rfl rfl hl hcalls he
  refine ⟨s4_jointInv_accept h hd htp hcp hsp he hh, ⟨rfl, ?_, ?_, hos, hov⟩, hS0, ?_⟩
  · rw [hS]; rfl
  · rw [hS]; rfl
  · rw [hS, s4_x_accept]; exact hacc

theorem s4_post_reject {c : CState} {o o' : OState} {g g' : Ghost} {d : ℕ} {cInt : ℤ} {N1 : ℚ}
    {Ld Ld' : Learner} {S0 θ : ℚ} {r0 r1 r2 : CallRec} (hP : ParamsOK P)
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H)
    (htp : TreePart P (.evals d)
      { c with learners := setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners),
               leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf) }
      ((shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) (g.events.length + 1))
    (hbp : BankPart P (.evals d) ((shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)))
      (mapFrom (fun l => l ++ [RowOp.scaleXY cInt]) (d + 1) (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d g.hists))
      (g.events.length + 1))
    (hsp : StatePart P o' g') (hcalls : g'.calls = g.calls ++ [r0] ++ [r1] ++ [r2])
    (h0lab : r0.lab = g.labelAt d) (h0kind : r0.kind = CallKind.validate S0 θ)
    {cert : AdaCert} (hcert : cert = AdaCert.high ∨ cert = AdaCert.low) (h0out : r0.out = some (Sum.inl cert))
    (h1lab : r1.lab = g.labelAt d) (h1kind : r1.kind = CallKind.release Mode.primary) {a1 : AdaNum}
    (h1out : r1.out = some (Sum.inr a1))
    (h2lab : r2.lab = g.labelAt d) (h2kind : r2.kind = CallKind.release Mode.diff) {a2 : AdaNum}
    (h2out : r2.out = some (Sum.inr a2))
    (hl : g'.labels = g.labels)
    (he : g'.events = g.events ++ [TreeEvent.correct d cInt])
    (hh : g'.hists = mapFrom (fun l => l ++ [RowOp.scaleXY cInt]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d g.hists))
    (hos : o'.fpSeed = o.fpSeed) (hov : o'.fpVal = o.fpVal)
    {cache : ℤ} (hcc : Learner.countCorrection P { Ld with cache := cache } = some Ld')
    (hLdD : c.learners.getD d dfltLearner = Ld) (hN10 : 0 ≤ N1)
    (hacc : |(N1 : ℝ) - ‖(shadowOf P g).x d‖ ^ 2| ≤
      8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g).x d‖ ^ 2) :
    JointInv P (.evals d)
      { c with learners := setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners),
               leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf) } o' g' ∧
      Frame (P := P) c o g
        { c with learners := setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners),
                 leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf) } o' g' ∧
      0 ≤ N1 ∧
      |(N1 : ℝ) - ‖(shadowOf P g').x d‖ ^ 2| ≤
        8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g').x d‖ ^ 2 := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)) :=
    shadowOf_snoc P he (toTreeEv_correct d cInt)
  have hclen : c.learners.length = P.H := h.tp.nLearners
  have hjU : ∀ j, ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j
      dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed + (if j = d then 1 else 0) := by
    intro j
    rw [s4_getD_setAt _ _ _ _ _ (by rw [length_mapFrom, hclen]; exact hd)]
    by_cases hjd : j = d
    · rw [if_pos hjd, if_pos hjd, s4_countCorrection_jUsed hcc, hjd, hLdD]
    · rw [if_neg hjd, if_neg hjd, Nat.add_zero]
      by_cases hjl : j < c.learners.length
      · rw [s4_getD_mapFrom _ _ _ _ _ hjl]
        split_ifs <;> rfl
      · rw [List.getD_eq_getElem?_getD, List.getElem?_eq_none (by rw [length_mapFrom]; omega),
          List.getD_eq_getElem?_getD, List.getElem?_eq_none (by omega)]
        rfl
  have hcp : CountPart P (.evals d)
      { c with learners := setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners),
               leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf) } g' :=
    countPart_reject hP h.cp hd r0 r1 r2 h0lab h0kind hcert h0out h1lab h1kind h1out h2lab h2kind
      h2out cInt hl (by rw [hcalls]; simp only [List.append_assoc, List.cons_append, List.nil_append]) he
      (by show (setAt _ _ _).length = _; rw [length_setAt, length_mapFrom]) hjU
  refine ⟨s4_jointInv_correct h htp (by rw [hh]; exact hbp) rfl rfl hcp hsp he, ⟨rfl, ?_, ?_, hos, hov⟩,
    hN10, ?_⟩
  · rw [hS]; rfl
  · rw [hS]; rfl
  · rw [hS, s4_x_correct _ _ _ le_rfl]; exact hacc

/-! ## A Step-4 correction (rejection branch) -/

set_option maxHeartbeats 400000 in
theorem s4_wp_reject (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {c : CState} {o : OState} {g : Ghost} {d : ℕ}
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ))
    (ht : (shadowOf P g).t ≤ P.m) (hx0 : 1 ≤ ‖(shadowOf P g).x0‖) {Fv : ℚ} (hF0 : 0 ≤ Fv)
    (hFacc : |(Fv : ℝ) - ‖(shadowOf P g).x (d + 1)‖ ^ 2| ≤
      8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖(shadowOf P g).x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖(shadowOf P g).x d‖ ^ 2 + (P.omega : ℝ)) /
          (((gridVal P.eHP Ld.cache + Fv : ℚ) : ℝ) + (P.omega : ℝ)) - 1))
    {S0 θ : ℚ} {Bd B1 : Bank} {cert : AdaCert} (hcertp : cert = AdaCert.high ∨ cert = AdaCert.low)
    (hsp1 : StatePart P { o with banks := setAt B1 d o.banks }
      { g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] })
    (hlenB : d < o.banks.length) :
    WP P F (rejectDepthCode P d pos Fv c)
      (fun r o' g' => JointInv P (.evals d) r.1 o' g' ∧ Frame (P := P) c o g r.1 o' g' ∧ 0 ≤ r.2 ∧
        |(r.2 : ℝ) - ‖(shadowOf P g').x d‖ ^ 2| ≤
          8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g').x d‖ ^ 2)
      { o with banks := setAt B1 d o.banks } { g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] } := by
  have hlenH : g.hists.length = P.H := h.hists_len_H rfl
  have hlenL : g.labels.length = P.H := by rw [h.sp.rows.len_labels, ← h.sp.rows.len_hists, hlenH]
  have hnev : g.events.length + 1 ≤ P.T := h.nev_succ ht (by simp only [remEv]; omega)
  have hnev0 : g.events.length ≤ P.T := by omega
  have hdl : d < (Tree.Phase.evals (d + 1)).live P.H := hd
  have hclen : c.learners.length = P.H := h.tp.nLearners
  have hjU := h.tp.jUsed_lt hdl
  have hLdD : c.learners.getD d dfltLearner = Ld := by
    rw [List.getD_eq_getElem?_getD, hLd]; rfl
  obtain ⟨hnot, hc1, hc2, hN1⟩ := treePart_reject_pre hP h.tp hd hbox hnev hx0 hF0 hFacc hLd pos hcert
  obtain ⟨hall, hleafr, hN2⟩ := treePart_reject hP h.tp hd hbox hnev hx0 hF0 hFacc hLd pos hcert
  unfold rejectDepthCode
  simp only [hLd, AlgM.bind_eq, AlgM.pure_eq]
  refine wp_ite (fun hc => absurd hc hnot) (fun _ => ?_)
  have hB1 : ({ o with banks := setAt B1 d o.banks } : OState).banks[d]? = some B1 := by
    show (setAt B1 d o.banks)[d]? = some B1
    rw [getElem?_setAt, if_pos ⟨rfl, hlenB⟩]
  refine wp_releaseM hB1 ((bitAlways_releaseLog_shape P B1 Mode.primary).and
    (bitAlways_releaseLog_rej P B1 Mode.primary)) (fun r1 hr1 hpre1 => ?_)
  rw [← hF] at hpre1
  -- coverage of the release of `N₁` (the second record of `countPart_cov_reject` is a placeholder)
  have hcov1 := (countPart_cov_reject hP h.cp hd hjU (valRec P g d Bd S0 θ cert)
    ⟨g.labelAt d, d, [], Bd, CallKind.release Mode.primary, 0, some (Sum.inr AdaNum.abort)⟩
    rfl rfl rfl rfl rfl rfl).1
  obtain ⟨N1, hN1eq, hN10, hcert1, ⟨a1, hout1⟩, hsp2⟩ := rel_glue hP h.tp.tree hbox (by exact h.bp) hnev0 hsp1
    (by intro j hj hjd; exact countPart_label_inj h.cp hj (by rw [hlenL]; exact hd) hjd)
    (by show d < g.hists.length; rw [hlenH]; exact hd) hd (by show d ≤ P.H; omega)
    (fun hm => by cases hm) (fun _ hD => by cases hD) gF (hgood _).1 (hgood _).2 hB1 hcov1 r1
    hr1 hpre1
  have hcert1' : NumCert (P.eta : ℝ) (P.omega : ℝ) (‖(shadowOf P g).x d‖ ^ 2) (N1 : ℝ) := by
    have hx := h.bp.shadowX d (by rw [hlenH]; exact hd)
    have hsh : bankShadow P Mode.primary
        (({ g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] } : Ghost).histAt d) =
        (shadowOf P g).x d := by
      rw [← hx]; rfl
    rw [hsh] at hcert1
    exact hcert1
  obtain ⟨hrange1, hacc1⟩ := hN1 N1 hN10 hcert1'
  rw [hN1eq]
  simp only []
  refine wp_ite (fun _ => ?_) (fun hn => absurd hrange1 hn)
  apply wp_bankOpM
  unfold rejectTailCode
  simp only [AlgM.bind_eq, AlgM.pure_eq]
  apply wp_bankOpFromM
  apply wp_noteM
  refine wp_ite (fun _ => ?_) (fun hn => absurd (by rw [hall, hleafr]; rfl) hn)
  -- the bank of depth `d` before the release of `N₂`
  have hB4 : (mapFrom (Bank.mapRows (RowOp.apply P (RowOp.scaleXY
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)))) (d + 1)
      (modifyAt (Bank.mapRows (RowOp.apply P (RowOp.scaleY
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)))) d
        (setAt r1.1.2 d (setAt B1 d o.banks))))[d]? =
      some (Bank.mapRows (RowOp.apply P (RowOp.scaleY
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv))) r1.1.2) := by
    rw [getElem?_mapFrom, if_neg (by omega), getElem?_modifyAt, if_pos rfl, getElem?_setAt,
      if_pos ⟨rfl, by rw [length_setAt]; exact hlenB⟩]
    rfl
  -- the tree invariant after the correction (from a certified hypothetical refresh value)
  obtain ⟨q, hq0, hqcert⟩ := s4_exists_numCert P
    (‖((shadowOf P g).step P (.correct d ((gridVal P.eHstep
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv) : ℚ) : ℝ))).r d‖ ^ 2) (sq_nonneg _)
  obtain ⟨-, Ldq, -, htpq⟩ := hN2 q hq0 hqcert
  have hbp' := bankPart_correct hP _ hc1 hc2 h.tp.tree htpq.tree hbox h.bp hd hlenH hnev
  have hsp4 := statePart_events (statePart_bankOpFrom (statePart_bankOp hsp2 d
    (RowOp.scaleY (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv))) (d + 1)
    (RowOp.scaleXY (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)))
    (g.events ++ [TreeEvent.correct d (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)])
  refine wp_releaseM hB4 ((bitAlways_releaseLog_shape P _ Mode.diff).and
    (bitAlways_releaseLog_rej P _ Mode.diff)) (fun r2 hr2 hpre2 => ?_)
  rw [← hF] at hpre2
  have hcov2 := (countPart_cov_reject hP h.cp hd hjU (valRec P g d Bd S0 θ cert)
    (relRec { g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] } d B1 Mode.primary r1)
    rfl rfl rfl rfl rfl hout1).2
  rw [show g.calls ++ [valRec P g d Bd S0 θ cert,
      relRec { g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] } d B1 Mode.primary r1] =
      (g.calls ++ [valRec P g d Bd S0 θ cert]) ++
        [relRec { g with calls := g.calls ++ [valRec P g d Bd S0 θ cert] } d B1 Mode.primary r1] by
      simp only [List.append_assoc, List.cons_append, List.nil_append]] at hcov2
  have hlen5 : d < (mapFrom (fun l => l ++ [RowOp.scaleXY
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.scaleY
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv)]) d g.hists)).length := by
    rw [length_mapFrom, length_modifyAt, hlenH]; exact hd
  obtain ⟨N2, hN2eq, hN20, hcert2, ⟨a2, hout2⟩, hsp3⟩ := rel_glue hP htpq.tree
    (by rw [Tree.TreeState.step_correct_x0]; exact hbox) (by exact hbp') hnev hsp4
    (by intro j hj hjd; exact countPart_label_inj h.cp hj (by rw [hlenL]; exact hd) hjd)
    (by exact hlen5) hd (by show d ≤ P.H; omega) (fun _ => by show d < P.H; exact hd)
    (fun _ hD => by cases hD) gF (hgood _).1 (hgood _).2
    hB4 (by exact hcov2) r2 hr2 hpre2
  have hcert2' : NumCert (P.eta : ℝ) (P.omega : ℝ)
      (‖((shadowOf P g).step P (.correct d ((gridVal P.eHstep
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Fv) : ℚ) : ℝ))).r d‖ ^ 2) (N2 : ℝ) := by
    have hx := hbp'.shadowX d hlen5
    have hy := hbp'.shadowY d hlen5 (by show d < P.H; exact hd)
    rw [← s4_x_sub_y, ← hx, ← hy]
    exact hcert2
  obtain ⟨hrange2, Ld', hcc, htp⟩ := hN2 N2 hN20 hcert2'
  rw [hN2eq]
  simp only []
  apply wp_pure
  rw [hcc]
  simp only []
  rw [if_pos hrange2]
  exact s4_post_reject hP h hd htp hbp' hsp3 rfl rfl rfl hcertp rfl rfl rfl hout1 rfl rfl hout2
    rfl rfl rfl rfl rfl hcc hLdD hN10 hacc1

/-! ## Step 4: one depth, the loop, the whole step -/

set_option maxHeartbeats 400000 in
/-- **Step 4 at depth `d`** (`step4DepthCode`): on a nonzero round (`‖x_0‖ ≥ 1`), from `evals (d + 1)` with a
returned value of the child accuracy to `evals d` with a returned value of accuracy `8(ℓ+1)η` for `‖x_d‖²`. -/
theorem wp_step4DepthCode (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {c : CState} {o : OState} {g : Ghost} {d : ℕ}
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ))
    (ht : (shadowOf P g).t ≤ P.m) (hx0 : 1 ≤ ‖(shadowOf P g).x0‖) {Fv : ℚ} (hF0 : 0 ≤ Fv)
    (hFacc : |(Fv : ℝ) - ‖(shadowOf P g).x (d + 1)‖ ^ 2| ≤
      8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖(shadowOf P g).x (d + 1)‖ ^ 2) :
    WP P F (step4DepthCode P d c Fv)
      (fun r o' g' => JointInv P (.evals d) r.1 o' g' ∧ Frame (P := P) c o g r.1 o' g' ∧ 0 ≤ r.2 ∧
        |(r.2 : ℝ) - ‖(shadowOf P g').x d‖ ^ 2| ≤
          8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖(shadowOf P g').x d‖ ^ 2) o g := by
  have hlenH : g.hists.length = P.H := h.hists_len_H rfl
  have hlenB : o.banks.length = P.H := by rw [← h.sp.rows.len_hists, hlenH]
  have hnev : g.events.length + 1 ≤ P.T := h.nev_succ ht (by simp only [remEv]; omega)
  have hnev0 : g.events.length ≤ P.T := by omega
  have hdl : d < (Tree.Phase.evals (d + 1)).live P.H := hd
  obtain ⟨Ld, hLd⟩ : ∃ Ld, c.learners[d]? = some Ld := ⟨_, h.tp.learner_some hdl⟩
  obtain ⟨Bd, hBd⟩ : ∃ B, o.banks[d]? = some B :=
    ⟨o.banks[d]'(by rw [hlenB]; exact hd), List.getElem?_eq_getElem _⟩
  have hS := treePart_eval_range hP h.tp hd hbox hnev0 hF0 hFacc hLd
  have hS0 : (0 : ℚ) ≤ gridVal P.eHP Ld.cache + Fv := by
    have h1 := hS
    unfold inRangeA at h1
    exact (of_decide_eq_true h1).1
  have hθ0 : (0 : ℚ) ≤ (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta := by
    have := P.eta_pos
    positivity
  have hθ1 : (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta ≤ (1 / 2) ^ 16 := by
    have h1 := StreamParams.eight_H_add_five_mul_eta_lt P
    have h2 : ((P.H - d : ℕ) : ℚ) ≤ (P.H : ℚ) := by exact_mod_cast Nat.sub_le P.H d
    have h4 : (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta ≤ (8 * (P.H : ℚ) + 5) * P.eta :=
      mul_le_mul_of_nonneg_right (by linarith) P.eta_pos.le
    exact le_trans h4 h1.le
  have hθR : (((8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta : ℚ) : ℝ) =
      (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) := by
    push_cast
    ring
  unfold step4DepthCode
  simp only [hLd, AlgM.bind_eq, AlgM.pure_eq]
  refine wp_ite (fun _ => ?_) (fun hn => absurd hS hn)
  refine wp_validateM hBd ((bitAlways_validate P Bd _ _).and (bitAlways_validate_rej P Bd _ _))
    (fun r hr hpre => ?_)
  rw [← hF] at hpre
  obtain ⟨hcert3, hvc, hsp1⟩ := val_glue hP h hd ht hbox gF (hgood _).1 hBd hS0 hθ0 hθ1 r hr hpre
  obtain ⟨cert, B1⟩ := r
  dsimp only at hcert3 hvc hsp1 ⊢
  rcases hcert3 with rfl | rfl | rfl
  · have hc := hvc.1 rfl
    rw [hθR] at hc
    obtain ⟨htp, hacc'⟩ := treePart_accept hP h.tp hd hbox hnev hx0 hF0 hFacc hLd hc
    apply wp_noteM
    apply wp_pure
    exact s4_post_accept hP h hd htp (statePart_events hsp1 _) rfl rfl rfl rfl rfl rfl hS0 hacc'
  · have hc := hvc.2.1 (Or.inl rfl)
    rw [hθR] at hc
    exact s4_wp_reject hP gF hF hgood h hd hbox ht hx0 hF0 hFacc hLd true
      (by rw [if_pos rfl, one_mul]; exact hc) (Or.inl rfl) hsp1 (by rw [hlenB]; exact hd)
  · have hc := hvc.2.2 (Or.inl rfl)
    rw [hθR] at hc
    exact s4_wp_reject hP gF hF hgood h hd hbox ht hx0 hF0 hFacc hLd false
      (by rw [if_neg (by decide)]; linarith) (Or.inr rfl) hsp1 (by rw [hlenB]; exact hd)

/-- **Step 4 for the depths `D − 1, …, 0`** (`step4LoopCode` over `(List.range D).reverse`). -/
theorem wp_step4LoopCode (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) :
    ∀ (D : ℕ) (c : CState) (o : OState) (g : Ghost) (Fv : ℚ), D ≤ P.H →
      JointInv P (.evals D) c o g → ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ) → (shadowOf P g).t ≤ P.m →
      1 ≤ ‖(shadowOf P g).x0‖ → 0 ≤ Fv →
      |(Fv : ℝ) - ‖(shadowOf P g).x D‖ ^ 2| ≤
        8 * ((P.H - D + 1 : ℕ) : ℝ) * (P.eta : ℝ) * ‖(shadowOf P g).x D‖ ^ 2 →
      WP P F (step4LoopCode P (List.range D).reverse c Fv)
        (fun r o' g' => JointInv P (.evals 0) r.1 o' g' ∧ Frame (P := P) c o g r.1 o' g' ∧ 0 ≤ r.2 ∧
          |(r.2 : ℝ) - ‖(shadowOf P g').x0‖ ^ 2| ≤
            8 * ((P.H + 1 : ℕ) : ℝ) * (P.eta : ℝ) * ‖(shadowOf P g').x0‖ ^ 2) o g := by
  intro D
  induction D with
  | zero =>
    intro c o g Fv _ h _ _ _ hF0 hacc
    simp only [List.range_zero, List.reverse_nil, step4LoopCode, AlgM.pure_eq]
    apply wp_pure
    refine ⟨h, frame_refl c o g, hF0, ?_⟩
    rw [s4_x_zero, Nat.sub_zero] at hacc
    exact hacc
  | succ D ih =>
    intro c o g Fv hD h hbox ht hx0 hF0 hacc
    rw [List.range_succ, List.reverse_append, List.reverse_singleton, List.singleton_append]
    simp only [step4LoopCode, h.notFailed, Bool.false_eq_true, ↓reduceIte, AlgM.bind_eq]
    apply wp_bind
    have e1 : P.H - (D + 1) + 1 = P.H - D := by omega
    rw [e1] at hacc
    refine wp_mono (wp_step4DepthCode hP gF hF hgood h (by omega) hbox ht hx0 hF0 hacc) ?_
    intro r o' g' hr
    obtain ⟨h', hfr, hr0, hracc⟩ := hr
    have e2 : ((P.H - D + 1 : ℕ) : ℝ) = ((P.H - D : ℕ) : ℝ) + 1 := Nat.cast_succ _
    refine wp_mono (ih r.1 o' g' r.2 (by omega) h' (by rw [hfr.2.1]; exact hbox)
      (by rw [hfr.2.2.1]; exact ht) (by rw [hfr.2.1]; exact hx0) hr0 (by rw [e2]; exact hracc)) ?_
    intro r' o'' g'' hr'
    obtain ⟨h'', hfr', hr0', hracc'⟩ := hr'
    exact ⟨h'', frame_trans hfr hfr', hr0', hracc'⟩

/-- **Step 4** (`step4Code`): from its start (the accumulator is `‖x_H‖²`) to its end, with the returned value of
accuracy `8(H+1)η` for `‖x_0‖²`. -/
theorem wp_step4Code (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.evals P.H) c o g)
    (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t ≤ P.m) (hx0 : 1 ≤ ‖(shadowOf P g).x0‖)
    (hleaf : leafVal P c = ‖(shadowOf P g).x P.H‖ ^ 2) :
    WP P F (step4Code P c)
      (fun r o' g' => JointInv P (.evals 0) r.1 o' g' ∧ Frame (P := P) c o g r.1 o' g' ∧ 0 ≤ r.2 ∧
        |(r.2 : ℝ) - ‖(shadowOf P g').x0‖ ^ 2| ≤
          8 * ((P.H + 1 : ℕ) : ℝ) * (P.eta : ℝ) * ‖(shadowOf P g').x0‖ ^ 2) o g := by
  unfold step4Code
  have hlv : ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) = ‖(shadowOf P g).x P.H‖ ^ 2 := hleaf
  have hη : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  refine wp_step4LoopCode hP gF hF hgood P.H c o g (gridVal P.eHleaf c.leaf) le_rfl h hbox ht hx0 ?_ ?_
  · have h0 : (0 : ℝ) ≤ ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) := by
      rw [hlv]
      exact sq_nonneg _
    exact_mod_cast h0
  · rw [hlv, sub_self, abs_zero]
    exact mul_nonneg (mul_nonneg (by positivity) hη) (sq_nonneg _)

end F2e2e.C.Closure
