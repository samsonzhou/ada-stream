import F2e2e.C.ClosureProbCoarseAux

/-!
# Theorem 6.4, probability layer: the coupling for one coarse group

The coupling between the instrumented interpreter `runL` (with the group tape `l₀`) and the stopping placeholder
interpreter `runLs` (`F2e2e/C/ClosureProbCoarseAux.lean`), up to the `kc`-th consuming release of bank `lab`:
`coarse_coupling`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-! ### Tags under the retagging -/

theorem coarseSel_coarse (lab : BankLabel) (kc j : ℕ) :
    coarseSel lab kc (Tag.coarse lab j) = decide (j = kc) := by
  unfold coarseSel
  simp

theorem coarseSel_coarse_ne {lab l : BankLabel} (h : l ≠ lab) (kc j : ℕ) :
    coarseSel lab kc (Tag.coarse l j) = false := by
  unfold coarseSel
  simp [h]

theorem coarseSel_seeds (lab l : BankLabel) (kc : ℕ) : coarseSel lab kc (Tag.seeds l) = false := by
  unfold coarseSel
  simp

theorem coarseSel_coins (lab l : BankLabel) (kc : ℕ) : coarseSel lab kc (Tag.coins l) = false := by
  unfold coarseSel
  simp

theorem coarseSel_fp (lab : BankLabel) (kc : ℕ) : coarseSel lab kc Tag.fp = false := by
  unfold coarseSel
  simp

/-! ### Fresh banks -/

theorem gCoarse_pos (P : StreamParams) : 0 < P.gCoarse := by
  unfold StreamParams.gCoarse
  positivity

theorem bpAll_sampleList_mem {α : Type} (p : BitProg α) {Q : α → Prop} (hp : FP.BPAll p Q) :
    ∀ k, FP.BPAll (sampleList p k) (fun l => ∀ x ∈ l, Q x)
  | 0 => FP.BPAll.pure (fun x hx => absurd hx List.not_mem_nil)
  | k + 1 => by
    rw [sampleList_succ]
    refine FP.BPAll.bind (fun a ha => ?_) hp
    refine FP.BPAll.bind (fun l hl => ?_) (bpAll_sampleList_mem p hp k)
    exact FP.BPAll.pure fun x hx => by
      rcases List.mem_cons.mp hx with rfl | hx
      · exact ha
      · exact hl x hx

theorem bpAll_grpProg_ne (P : StreamParams) : FP.BPAll (grpProg P) (fun x => x ≠ []) :=
  FP.BPAll.mono (fun x hx => by
    intro h0
    rw [h0] at hx
    have := gCoarse_pos P
    simp at hx
    omega) (LabAux.bpAll_sampleList_length (sampleList (newRow P) 32) P.gCoarse)

theorem bpAll_newBank_grp (P : StreamParams) :
    FP.BPAll (newBank P) (fun B : Bank => ∀ x ∈ B.coarse, x ≠ []) := by
  have hnb : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
      (sampleList (grpProg P) P.Rmax).bind fun coarse =>
        (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl
  rw [hnb]
  refine FP.BPAll.bind (fun ada _ => ?_) (FP.BPAll.true _)
  refine FP.BPAll.bind (fun coarse hco => ?_)
    (bpAll_sampleList_mem (grpProg P) (bpAll_grpProg_ne P) P.Rmax)
  refine FP.BPAll.bind (fun st _ => ?_) (FP.BPAll.true _)
  exact FP.BPAll.pure hco

theorem retag_coarseT_ne {lab l : BankLabel} (h : l ≠ lab) (P : StreamParams) (kc : ℕ) :
    ∀ j n, (coarseT P l j n).retag (coarseSel lab kc) = tag false (sampleList (grpProg P) n)
  | _, 0 => rfl
  | j, n + 1 => by
    rw [sampleList_succ (grpProg P) n, tag_bind, coarseT, retag_bind, retag_tag,
      coarseSel_coarse_ne h]
    congr 1
    funext a
    rw [retag_bind, retag_coarseT_ne h P kc (j + 1) n, tag_bind]
    rfl

private theorem retag_newBankT_ne {lab l : BankLabel} (h : l ≠ lab) (P : StreamParams) (kc : ℕ) :
    (newBankT P l).retag (coarseSel lab kc) = tag false (newBank P) := by
  have hnb : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
      (sampleList (grpProg P) P.Rmax).bind fun coarse =>
        (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl
  rw [hnb, newBankT, retag_bind, retag_tag, coarseSel_seeds, tag_bind]
  congr 1
  funext ada
  rw [retag_bind, retag_coarseT_ne h P kc 0 P.Rmax, tag_bind]
  congr 1
  funext coarse
  rw [retag_bind, retag_tag, coarseSel_coins, tag_bind]
  rfl

/-! ### The coarse groups of `lab`: real against placeholder -/

theorem coarse_couple (P : StreamParams) (lab : BankLabel) (kc : ℕ)
    (s : Fin P.gCoarse → Fin 32 → Seed P) (l₀ : List Bool)
    (hs : ∀ z rest, (grpProg P).run l₀ = some (z, rest) → groupSeeds P z = s) :
    ∀ (n j : ℕ) (σ σ' : Bool → List Bool) (gs : List (List (List Row))) (τ : Bool → List Bool),
      σ' false = σ false → (j ≤ kc → σ true = l₀) →
      ((coarseT P lab j n).retag (coarseSel lab kc)).runS σ = some (gs, τ) →
      ∃ gs' τ', ((coarseTp P lab kc j n).retag (coarseSel lab kc)).runS σ' = some (gs', τ') ∧
        τ' false = τ false ∧ List.Forall₂ (GrpRel P s) gs gs' ∧
        (∀ i, gs'[i]? = some [] ↔ (j ≤ kc ∧ kc < j + n ∧ i + j = kc)) ∧
        (j ≤ kc → kc < j + n → ∃ z rest, (grpProg P).run l₀ = some (z, rest))
  | 0, j, σ, σ', gs, τ, hf, _, hr => by
    have hr' : some (([] : List (List (List Row))), σ) = some (gs, τ) := hr
    simp only [Option.some.injEq, Prod.mk.injEq] at hr'
    obtain ⟨rfl, rfl⟩ := hr'
    refine ⟨[], σ', rfl, hf, List.Forall₂.nil, fun i => ?_, fun _ h => by omega⟩
    simp only [List.getElem?_nil]
    constructor
    · intro h0; exact absurd h0 (by simp)
    · intro h0; omega
  | n + 1, j, σ, σ', gs, τ, hf, ht, hr => by
    have hreal : coarseT P lab j (n + 1) = (tag (Tag.coarse lab j) (grpProg P)).bind fun a =>
        (coarseT P lab (j + 1) n).bind fun l => TBitProg.pure (a :: l) := rfl
    rw [hreal, runS_retag_tag_bind, coarseSel_coarse] at hr
    obtain ⟨r, hr1, hr2⟩ := Option.bind_eq_some_iff.mp hr
    rw [retag_bind, runS_bind] at hr2
    obtain ⟨r2, hr3, hr4⟩ := Option.bind_eq_some_iff.mp hr2
    have hr4' : some (r.1 :: r2.1, r2.2) = some (gs, τ) := hr4
    simp only [Option.some.injEq, Prod.mk.injEq] at hr4'
    obtain ⟨rfl, rfl⟩ := hr4'
    have hph : coarseTp P lab kc j (n + 1) =
        (if j = kc then TBitProg.pure [] else tag (Tag.coarse lab j) (grpProg P)).bind fun a =>
          (coarseTp P lab kc (j + 1) n).bind fun l => TBitProg.pure (a :: l) := rfl
    by_cases hj : j = kc
    · -- the group `kc`: read from the group tape in the real run, the placeholder otherwise
      subst hj
      have hd : decide (j = j) = true := decide_eq_true rfl
      rw [hd] at hr1 hr3
      rw [ht le_rfl] at hr1
      obtain ⟨gs1', τ1', hy1, hf1, hrel1, hpos1, -⟩ := coarse_couple P lab j s l₀ hs n (j + 1)
        (Function.update σ true r.2) σ' r2.1 r2.2 (by rw [update_true_false, hf]) (fun h => by omega)
        hr3
      refine ⟨[] :: gs1', τ1', ?_, hf1, ?_, ?_, fun _ _ => ⟨r.1, r.2, hr1⟩⟩
      · rw [hph, if_pos rfl, retag_bind, runS_bind]
        show (((coarseTp P lab j (j + 1) n).bind fun l => TBitProg.pure ([] :: l)).retag
          (coarseSel lab j)).runS σ' = _
        rw [retag_bind, runS_bind, hy1]
        rfl
      · exact List.Forall₂.cons (Or.inr ⟨rfl, hs r.1 r.2 hr1⟩) hrel1
      · intro i
        cases i with
        | zero => simp
        | succ i =>
          simp only [List.getElem?_cons_succ, hpos1 i]
          omega
    · -- another group: the same bits in both runs
      have hd : decide (j = kc) = false := decide_eq_false hj
      rw [hd] at hr1 hr3
      have hne := FP.BPAll.of_run (bpAll_grpProg_ne P) hr1
      obtain ⟨gs1', τ1', hy1, hf1, hrel1, hpos1, hz1⟩ := coarse_couple P lab kc s l₀ hs n (j + 1)
        (Function.update σ false r.2) (Function.update σ' false r.2) r2.1 r2.2
        (by simp) (fun h => by rw [update_false_true]; exact ht (by omega)) hr3
      refine ⟨r.1 :: gs1', τ1', ?_, hf1, List.Forall₂.cons (Or.inl ⟨rfl, hne⟩) hrel1, ?_, ?_⟩
      · rw [hph, if_neg hj, runS_retag_tag_bind, coarseSel_coarse, decide_eq_false hj, hf, hr1,
          Option.bind_some, retag_bind, runS_bind, hy1]
        rfl
      · intro i
        cases i with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq]
          constructor
          · intro h0; exact absurd h0 hne
          · intro h0; omega
        | succ i =>
          simp only [List.getElem?_cons_succ, hpos1 i]
          omega
      · intro h1 h2
        exact hz1 (by omega) (by omega)

theorem newBank_couple (P : StreamParams) (lab : BankLabel) (kc : ℕ) (hkc : kc < P.Rmax)
    (s : Fin P.gCoarse → Fin 32 → Seed P) (l₀ : List Bool)
    (hs : ∀ z rest, (grpProg P).run l₀ = some (z, rest) → groupSeeds P z = s)
    (σ σ' : Bool → List Bool) (B : Bank) (τ : Bool → List Bool) (hf : σ' false = σ false)
    (ht : σ true = l₀) (hr : ((newBankT P lab).retag (coarseSel lab kc)).runS σ = some (B, τ)) :
    ∃ B' τ', ((newBankTp P lab kc).retag (coarseSel lab kc)).runS σ' = some (B', τ') ∧
      τ' false = τ false ∧ BankRel P s B B' ∧ (∀ j, B'.coarse[j]? = some [] ↔ j = kc) ∧
      ∃ z rest, (grpProg P).run l₀ = some (z, rest) := by
  rw [newBankT, runS_retag_tag_bind, coarseSel_seeds] at hr
  obtain ⟨r1, hr1, hr⟩ := Option.bind_eq_some_iff.mp hr
  rw [retag_bind, runS_bind] at hr
  obtain ⟨r2, hr2, hr⟩ := Option.bind_eq_some_iff.mp hr
  rw [runS_retag_tag_bind, coarseSel_coins] at hr
  obtain ⟨r3, hr3, hr⟩ := Option.bind_eq_some_iff.mp hr
  have hr' : some ((⟨r1.1, r2.1, r3.1⟩ : Bank), Function.update r2.2 false r3.2) = some (B, τ) := hr
  simp only [Option.some.injEq, Prod.mk.injEq] at hr'
  obtain ⟨rfl, rfl⟩ := hr'
  obtain ⟨gs', τ2', hy2, hf2, hrel2, hpos2, hz2⟩ := coarse_couple P lab kc s l₀ hs P.Rmax 0
    (Function.update σ false r1.2) (Function.update σ' false r1.2) r2.1 r2.2 (by simp)
    (fun _ => by rw [update_false_true]; exact ht) hr2
  refine ⟨⟨r1.1, gs', r3.1⟩, Function.update τ2' false r3.2, ?_, by simp, ⟨rfl, rfl, hrel2⟩,
    fun j => ?_, hz2 (Nat.zero_le _) (by omega)⟩
  · rw [newBankTp, runS_retag_tag_bind, coarseSel_seeds, hf, hr1, Option.bind_some, retag_bind,
      runS_bind, hy2, Option.bind_some]
    show (((tag (Tag.coins lab) (adaInit (bankAda P))).bind fun st =>
      TBitProg.pure (⟨r1.1, gs', st⟩ : Bank)).retag (coarseSel lab kc)).runS τ2' = _
    rw [runS_retag_tag_bind, coarseSel_coins, hf2, hr3, Option.bind_some]
    rfl
  · rw [hpos2 j]
    constructor
    · intro h0; omega
    · intro h0; omega

section NewBanks

variable {P : StreamParams} {lab : BankLabel} {kc : ℕ} {s : Fin P.gCoarse → Fin 32 → Seed P}
  {l₀ : List Bool} {born : Bool} {o o' : OState} {g g' : Ghost}

theorem labelAt_append_lt (g : Ghost) (l : BankLabel) {i : ℕ} (hi : i < g.labels.length) (hs : List (List RowOp)) :
    ({ g with labels := g.labels ++ [l], hists := hs } : Ghost).labelAt i = g.labelAt i := by
  unfold Ghost.labelAt
  simp only
  rw [List.getD_append _ _ _ _ hi]

theorem labelAt_append_eq (g : Ghost) (l : BankLabel) (hs : List (List RowOp)) :
    ({ g with labels := g.labels ++ [l], hists := hs } : Ghost).labelAt g.labels.length = l := by
  unfold Ghost.labelAt
  simp only
  rw [List.getD_append_right _ _ _ _ (le_refl _), Nat.sub_self]
  rfl

theorem CRel.newOther (h : CRel P lab kc s l₀ born o g o' g') {tr d : ℕ} (hne : (tr, d) ≠ lab)
    (B : Bank) (hB : ∀ x ∈ B.coarse, x ≠ []) :
    CRel P lab kc s l₀ born { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }
      { o' with banks := o'.banks ++ [B] }
      { g' with labels := g'.labels ++ [(tr, d)], hists := g'.hists ++ [[]] } := by
  have hBB : BankRel P s B B := ⟨rfl, rfl, List.forall₂_same.mpr fun x hx => Or.inl ⟨rfl, hB x hx⟩⟩
  have hlen' : o'.banks.length = o.banks.length := (List.Forall₂.length_eq h.banks).symm
  -- labels of the new ghost
  have hla : ∀ i, ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } : Ghost).labelAt i =
      if i < g.labels.length then g.labelAt i else (if i = g.labels.length then (tr, d) else (0, 0)) := by
    intro i
    split_ifs with h1 h2
    · exact labelAt_append_lt g _ h1 _
    · subst h2; exact labelAt_append_eq g _ _
    · unfold Ghost.labelAt
      simp only
      rw [List.getD_eq_default _ _ (by simp; omega)]
  have hcr : coarseRecs lab ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } :
      Ghost) = coarseRecs lab g := rfl
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := List.rel_append h.banks (List.Forall₂.cons hBB List.Forall₂.nil)
    labels := by simp only [h.labels]
    hists := by simp only [h.hists]
    calls := h.calls
    events := h.events
    fps := h.fps
    len := by simp only [List.length_append, List.length_singleton, h.len]
    uniq := fun i j hi hj h1 h2 => by
      simp only [List.length_append, List.length_singleton] at hi hj
      rw [hla] at h1 h2
      split_ifs at h1 h2 with hi' hj' hj'' hi''
      · exact h.uniq i j hi' hj' h1 h2
      all_goals first
        | (exfalso; exact hne h1) | (exfalso; exact hne h2) | omega
    other := fun j C C' h1 h2 h3 => by
      rw [hla] at h3
      by_cases hj : j < g.labels.length
      · rw [if_pos hj] at h3
        simp only at h1 h2
        rw [List.getElem?_append_left (by rw [← h.len]; exact hj)] at h1
        rw [List.getElem?_append_left (by rw [hlen', ← h.len]; exact hj)] at h2
        exact h.other j C C' h1 h2 h3
      · simp only at h1 h2
        rw [List.getElem?_append_right (by rw [← h.len]; omega)] at h1
        rw [List.getElem?_append_right (by rw [hlen', ← h.len]; omega), hlen'] at h2
        rw [h1] at h2
        cases h2
        rfl
    cnt_le := by rw [hcr]; exact h.cnt_le
    pos := fun j C' h1 h2 i => by
      rw [hla] at h2
      rw [hcr]
      by_cases hj : j < g.labels.length
      · rw [if_pos hj] at h2
        simp only at h1
        rw [List.getElem?_append_left (by rw [hlen', ← h.len]; exact hj)] at h1
        exact h.pos j C' h1 h2 i
      · rw [if_neg hj] at h2
        split_ifs at h2 with hj'
        · exact absurd h2 hne
        · exfalso
          simp only at h1
          have := (List.getElem?_eq_some_iff.mp h1).1
          simp only [List.length_append, List.length_singleton] at this
          rw [hlen', ← h.len] at this
          omega
    unborn := fun hb0 => ⟨fun l hl => by
      rcases List.mem_append.mp hl with hl | hl
      · exact (h.unborn hb0).1 l hl
      · rw [List.mem_singleton] at hl; subst hl; exact hne, (h.unborn hb0).2⟩
    bornOK := h.bornOK }

theorem CRel.newLab (h : CRel P lab kc s l₀ false o g o' g') {tr d : ℕ} (heq : (tr, d) = lab)
    {B B' : Bank} (hBB : BankRel P s B B') (hpos : ∀ j, B'.coarse[j]? = some [] ↔ j = kc)
    (hz : ∃ z rest, (grpProg P).run l₀ = some (z, rest)) :
    CRel P lab kc s l₀ true { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }
      { o' with banks := o'.banks ++ [B'] }
      { g' with labels := g'.labels ++ [(tr, d)], hists := g'.hists ++ [[]] } := by
  have hlen' : o'.banks.length = o.banks.length := (List.Forall₂.length_eq h.banks).symm
  have hla : ∀ i, ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } : Ghost).labelAt i =
      if i < g.labels.length then g.labelAt i else (if i = g.labels.length then (tr, d) else (0, 0)) := by
    intro i
    split_ifs with h1 h2
    · exact labelAt_append_lt g _ h1 _
    · subst h2; exact labelAt_append_eq g _ _
    · unfold Ghost.labelAt
      simp only
      rw [List.getD_eq_default _ _ (by simp; omega)]
  have hold : ∀ i, i < g.labels.length → g.labelAt i ≠ lab := fun i hi hl =>
    (h.unborn rfl).1 _ (Closure.labelAt_mem hi) hl
  have hcr : coarseRecs lab ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } :
      Ghost) = coarseRecs lab g := rfl
  have hc0 : coarseRecs lab g = [] := by
    unfold coarseRecs
    rw [List.filter_eq_nil_iff]
    intro r hr
    simp [(h.unborn rfl).2 r hr]
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := List.rel_append h.banks (List.Forall₂.cons hBB List.Forall₂.nil)
    labels := by simp only [h.labels]
    hists := by simp only [h.hists]
    calls := h.calls
    events := h.events
    fps := h.fps
    len := by simp only [List.length_append, List.length_singleton, h.len]
    uniq := fun i j hi hj h1 h2 => by
      simp only [List.length_append, List.length_singleton] at hi hj
      have key : ∀ m, m < g.labels.length + 1 →
          ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } : Ghost).labelAt m = lab →
            m = g.labels.length := by
        intro m hm hml
        by_contra hne
        have hm' : m < g.labels.length := by omega
        rw [labelAt_append_lt g _ hm'] at hml
        exact hold m hm' hml
      rw [key i hi h1, key j hj h2]
    other := fun j C C' h1 h2 h3 => by
      rw [hla] at h3
      by_cases hj : j < g.labels.length
      · rw [if_pos hj] at h3
        simp only at h1 h2
        rw [List.getElem?_append_left (by rw [← h.len]; exact hj)] at h1
        rw [List.getElem?_append_left (by rw [hlen', ← h.len]; exact hj)] at h2
        exact h.other j C C' h1 h2 h3
      · rw [if_neg hj] at h3
        split_ifs at h3 with hj'
        · exact absurd heq h3
        · exfalso
          simp only at h1
          have := (List.getElem?_eq_some_iff.mp h1).1
          simp only [List.length_append, List.length_singleton] at this
          rw [← h.len] at this
          omega
    cnt_le := by rw [hcr, hc0]; exact Nat.zero_le _
    pos := fun j C' h1 h2 i => by
      rw [hla] at h2
      rw [hcr, hc0, List.length_nil, Nat.sub_zero]
      by_cases hj : j < g.labels.length
      · rw [if_pos hj] at h2; exact absurd h2 (hold j hj)
      · rw [if_neg hj] at h2
        split_ifs at h2 with hj'
        · subst hj'
          simp only at h1
          rw [List.getElem?_append_right (by rw [hlen', ← h.len]), hlen', ← h.len, Nat.sub_self]
            at h1
          simp only [List.getElem?_cons_zero, Option.some.injEq] at h1
          subst h1
          exact hpos i
        · exfalso
          simp only at h1
          have := (List.getElem?_eq_some_iff.mp h1).1
          simp only [List.length_append, List.length_singleton] at this
          rw [hlen', ← h.len] at this
          omega
    unborn := fun hb0 => absurd hb0 (by decide)
    bornOK := fun _ => hz }

end NewBanks

theorem CRel.init (P : StreamParams) (lab : BankLabel) (kc : ℕ) (s : Fin P.gCoarse → Fin 32 → Seed P)
    (l₀ : List Bool) : CRel P lab kc s l₀ false initO Ghost.init initO Ghost.init where
  fpSeed := rfl
  fpVal := rfl
  banks := List.Forall₂.nil
  labels := rfl
  hists := rfl
  calls := List.Forall₂.nil
  events := rfl
  fps := rfl
  len := rfl
  uniq := fun i _ hi => absurd hi (Nat.not_lt_zero i)
  other := fun _ _ _ h1 => absurd h1 (by simp [initO])
  cnt_le := Nat.zero_le _
  pos := fun _ _ h1 => absurd h1 (by simp [initO])
  unborn := fun _ => ⟨fun _ hl => absurd hl List.not_mem_nil, fun _ hr => absurd hr List.not_mem_nil⟩
  bornOK := fun h => absurd h (by decide)

/-! ### The coupling -/

/-- **The coupling up to the `kc`-th consuming release of `lab`**: along every successful real run, the stopping
placeholder run (on any tapes with the same `false` tape) either ends with a related configuration, or stops with
the mode and history of the `kc`-th consuming release of `lab`, whose record (in the real final ghost) has a head
group with the seeds `s` of the group tape `l₀`. -/
theorem coarse_coupling (P : StreamParams) (lab : BankLabel) (kc : ℕ)
    (s : Fin P.gCoarse → Fin 32 → Seed P) (l₀ : List Bool) (hkc : kc < P.Rmax)
    (hs : ∀ z rest, (grpProg P).run l₀ = some (z, rest) → groupSeeds P z = s) {α : Type} :
    ∀ (p : AlgM α) (born : Bool) (o : OState) (g : Ghost) (o' : OState) (g' : Ghost)
      (σ σ' : Bool → List Bool) (x : α × OState × Ghost) (τ : Bool → List Bool),
      CRel P lab kc s l₀ born o g o' g' → BirthsOK lab born p (fun _ _ => True) →
      (born = false → σ true = l₀) → σ' false = σ false →
      ((runL P p o g).retag (coarseSel lab kc)).runS σ = some (x, τ) →
      ∃ y τ', ((runLs P lab kc p o' g').retag (coarseSel lab kc)).runS σ' = some (y, τ') ∧
        ((∃ born' x', y = Sum.inr x' ∧ CRel P lab kc s l₀ born' x.2.1 x.2.2 x'.2.1 x'.2.2) ∨
          (∃ info, y = Sum.inl info ∧ KthRec P lab kc s info x.2.2 ∧
            ∃ z rest, (grpProg P).run l₀ = some (z, rest)))
  | AlgM.pure a, born, o, g, o', g', σ, σ', x, τ, h, _, _, _, hr => by
    have hr' : some ((a, o, g), σ) = some (x, τ) := hr
    simp only [Option.some.injEq, Prod.mk.injEq] at hr'
    obtain ⟨rfl, rfl⟩ := hr'
    exact ⟨Sum.inr (a, o', g'), σ', rfl, Or.inl ⟨born, (a, o', g'), rfl, h⟩⟩
  | AlgM.fpInit k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    have hr' : ((((tag Tag.fp (fpSeedProg P)).bind fun r =>
        runL P k { o with fpSeed := r, fpVal := 0 } g)).retag (coarseSel lab kc)).runS σ = some (x, τ) := hr
    rw [runS_retag_tag_bind, coarseSel_fp] at hr'
    obtain ⟨r, hr1, hr2⟩ := Option.bind_eq_some_iff.mp hr'
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born
      { o with fpSeed := r.1, fpVal := 0 } g { o' with fpSeed := r.1, fpVal := 0 } g'
      (Function.update σ false r.2) (Function.update σ' false r.2) x τ
      (h.congr rfl rfl rfl rfl rfl rfl h.hists rfl rfl h.events h.fps) hb
      (fun hb0 => by rw [update_false_true]; exact ht hb0) (by simp) hr2
    refine ⟨y, τ', ?_, hc⟩
    show ((((tag Tag.fp (fpSeedProg P)).bind fun r =>
        runLs P lab kc k { o' with fpSeed := r, fpVal := 0 } g')).retag (coarseSel lab kc)).runS σ' =
      some (y, τ')
    rw [runS_retag_tag_bind, coarseSel_fp, hf, hr1, Option.bind_some]
    exact hy
  | AlgM.fpStep i Δ k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs
      (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0)) born
      { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }
      { o' with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g' with fps := g'.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }
      σ σ' x τ (h.congr rfl rfl h.fpSeed rfl rfl rfl h.hists rfl rfl h.events (by simp only [h.fps]))
      (hb _) ht hf hr
    refine ⟨y, τ', ?_, hc⟩
    show ((runLs P lab kc (k (fpUpdate P o'.fpSeed o'.fpVal i Δ == 0))
      { o' with fpVal := fpUpdate P o'.fpSeed o'.fpVal i Δ }
      { g' with fps := g'.fps ++ [(i, Δ, fpUpdate P o'.fpSeed o'.fpVal i Δ == 0)] }).retag
        (coarseSel lab kc)).runS σ' = some (y, τ')
    rw [show fpUpdate P o'.fpSeed o'.fpVal i Δ = fpUpdate P o.fpSeed o.fpVal i Δ by
      rw [h.fpSeed, h.fpVal]]
    exact hy
  | AlgM.bankNew tr d k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    have hb' : if (tr, d) = lab then born = false ∧ BirthsOK lab true k (fun _ _ => True)
        else BirthsOK lab born k (fun _ _ => True) := hb
    have hr' : (((newBankT P (tr, d)).bind fun B =>
        runL P k { o with banks := o.banks ++ [B] }
          { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }).retag
            (coarseSel lab kc)).runS σ = some (x, τ) := hr
    rw [retag_bind, runS_bind] at hr'
    obtain ⟨r, hr1, hr2⟩ := Option.bind_eq_some_iff.mp hr'
    by_cases hl : (tr, d) = lab
    · rw [if_pos hl] at hb'
      obtain ⟨hb0, hbk⟩ := hb'
      subst hb0
      rw [hl] at hr1
      obtain ⟨B', τ1', hy1, hf1, hBB, hpos, hz⟩ :=
        newBank_couple P lab kc hkc s l₀ hs σ σ' r.1 r.2 hf (ht rfl) hr1
      obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k true _ _ _ _ r.2 τ1' x τ
        (h.newLab hl hBB hpos hz) hbk (fun h0 => absurd h0 (by decide)) hf1 hr2
      refine ⟨y, τ', ?_, hc⟩
      show ((((if (tr, d) = lab then newBankTp P lab kc else newBankT P (tr, d)).bind fun B =>
          runLs P lab kc k { o' with banks := o'.banks ++ [B] }
            { g' with labels := g'.labels ++ [(tr, d)], hists := g'.hists ++ [[]] })).retag
              (coarseSel lab kc)).runS σ' = some (y, τ')
      rw [if_pos hl, retag_bind, runS_bind, hy1, Option.bind_some]
      exact hy
    · rw [if_neg hl] at hb'
      rw [retag_newBankT_ne hl, runS_tag] at hr1
      obtain ⟨q, hq, rfl⟩ := Option.map_eq_some_iff.mp hr1
      have hgrp := FP.BPAll.of_run (bpAll_newBank_grp P) hq
      obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born _ _ _ _
        (Function.update σ false q.2) (Function.update σ' false q.2) x τ
        (h.newOther hl q.1 hgrp) hb' (fun hb0 => by rw [update_false_true]; exact ht hb0) (by simp)
        hr2
      refine ⟨y, τ', ?_, hc⟩
      show ((((if (tr, d) = lab then newBankTp P lab kc else newBankT P (tr, d)).bind fun B =>
          runLs P lab kc k { o' with banks := o'.banks ++ [B] }
            { g' with labels := g'.labels ++ [(tr, d)], hists := g'.hists ++ [[]] })).retag
              (coarseSel lab kc)).runS σ' = some (y, τ')
      rw [if_neg hl, retag_bind, runS_bind, retag_newBankT_ne hl, runS_tag, hf, hq]
      exact hy
  | AlgM.bankRetain n k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born _ _ _ _ σ σ' x τ
      (h.retain n) hb ht hf hr
    exact ⟨y, τ', hy, hc⟩
  | AlgM.bankOp idx op k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born _ _ _ _ σ σ' x τ
      (h.bankOp idx op) hb ht hf hr
    exact ⟨y, τ', hy, hc⟩
  | AlgM.bankOpFrom idx op k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born _ _ _ _ σ σ' x τ
      (h.bankOpFrom idx op) hb ht hf hr
    exact ⟨y, τ', hy, hc⟩
  | AlgM.bankValidate idx S θ k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    rcases h.some_iff idx with ⟨h1, h2⟩ | ⟨B, B', h1, h2, hBB⟩
    · simp only [runL, h1] at hr
      obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs (k AdaCert.abort) born o g o' g'
        σ σ' x τ h (hb _) ht hf hr
      refine ⟨y, τ', ?_, hc⟩
      simp only [runLs, h2]
      exact hy
    · simp only [runL, h1] at hr
      rw [runS_retag_tag_bind, coarseSel_coins] at hr
      obtain ⟨r, hr1, hr2⟩ := Option.bind_eq_some_iff.mp hr
      have hco := FP.BPAll.of_run (LabAux.bpAll_validate P B S θ) hr1
      obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs (k r.1.1) born _ _ _ _
        (Function.update σ false r.2) (Function.update σ' false r.2) x τ
        (h.validate h1 h2 S θ r.1.1 r.1.2 hco) (hb _)
        (fun hb0 => by rw [update_false_true]; exact ht hb0) (by simp) hr2
      refine ⟨y, τ', ?_, hc⟩
      simp only [runLs, h2]
      rw [validate_congr P hBB.1 hBB.2.1, runS_retag_tag_bind, coarseSel_coins, BitProg.run_map, hf,
        hr1]
      exact hy
  | AlgM.bankRelease idx mode k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    rcases h.some_iff idx with ⟨h1, h2⟩ | ⟨B, B', h1, h2, hBB⟩
    · simp only [runL, h1] at hr
      obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs (k none) born o g o' g'
        σ σ' x τ h (hb _) ht hf hr
      refine ⟨y, τ', ?_, hc⟩
      simp only [runLs, h2]
      exact hy
    · simp only [runL, h1] at hr
      rw [runS_retag_tag_bind, coarseSel_coins] at hr
      obtain ⟨r, hr1, hr2⟩ := Option.bind_eq_some_iff.mp hr
      have hco := FP.BPAll.of_run (LabAux.bpAll_releaseLog P B mode) hr1
      by_cases hstop : g'.labelAt idx = lab ∧ phHead B' = true
      · -- the stopping release
        refine ⟨Sum.inl (mode, g'.histAt idx), σ', ?_, Or.inr ?_⟩
        · simp only [runLs, h2]
          rw [if_pos hstop]
          rfl
        · have hlab : g.labelAt idx = lab := by rw [← h.labelAt_eq]; exact hstop.1
          have hpre := TAll.of_runS ((tAll_runL_calls P (k r.1.1.1) _ _).retag (coarseSel lab kc)) hr2
          obtain ⟨hk, hz⟩ := h.stop h1 h2 hlab hstop.2 mode _ _ x.2.2 hpre
          exact ⟨(mode, g'.histAt idx), rfl, by rw [h.histAt_eq]; exact hk, hz⟩
      · by_cases hl : g.labelAt idx = lab
        · -- a consuming release of `lab` before the placeholder
          have hph : phHead B' = false := by
            cases hp : phHead B'
            · rfl
            · exact absurd ⟨by rw [h.labelAt_eq]; exact hl, hp⟩ hstop
          have hpos := h.pos idx B' h2 hl
          obtain ⟨y0, rest', hco', hy0⟩ : ∃ y0 rest', B'.coarse = y0 :: rest' ∧ y0 ≠ [] := by
            cases hc' : B'.coarse with
            | nil =>
              have := (hpos (kc - (coarseRecs lab g).length)).mpr rfl
              rw [hc'] at this
              exact absurd this (by simp)
            | cons y0 rest' =>
              refine ⟨y0, rest', rfl, fun h0 => ?_⟩
              unfold phHead at hph
              rw [hc', h0] at hph
              simp at hph
          obtain ⟨rest, hco1⟩ : ∃ rest, B.coarse = y0 :: rest := by
            have h3 := hBB.2.2
            rw [hco'] at h3
            cases hc : B.coarse with
            | nil => rw [hc] at h3; cases h3
            | cons x0 rest =>
              rw [hc] at h3
              cases h3 with
              | cons hg _ =>
                rcases hg with ⟨hx0, -⟩ | ⟨hx0, -⟩
                · exact ⟨rest, by rw [hx0]⟩
                · exact absurd hx0 hy0
          have hrc : r.1.1.2.coarse = rest := by rw [hco, hco1]; rfl
          obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs (k r.1.1.1) born _ _ _ _
            (Function.update σ false r.2) (Function.update σ' false r.2) x τ
            (h.releaseLab h1 h2 hl hco1 hco' hy0 mode r.1 hrc) (hb _)
            (fun hb0 => by rw [update_false_true]; exact ht hb0) (by simp) hr2
          refine ⟨y, τ', ?_, hc⟩
          simp only [runLs, h2]
          rw [if_neg hstop, releaseLog_congr P hBB.1 hBB.2.1 hco1 hco' mode, runS_retag_tag_bind,
            coarseSel_coins, BitProg.run_map, hf, hr1]
          exact hy
        · -- another bank
          have hBeq : B' = B := h.other idx B B' h1 h2 hl
          obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs (k r.1.1.1) born _ _ _ _
            (Function.update σ false r.2) (Function.update σ' false r.2) x τ
            (h.releaseOther h1 h2 hl mode r.1 hco) (hb _)
            (fun hb0 => by rw [update_false_true]; exact ht hb0) (by simp) hr2
          refine ⟨y, τ', ?_, hc⟩
          simp only [runLs, h2]
          rw [if_neg hstop, show releaseLog P B' mode = releaseLog P B mode by rw [hBeq],
            runS_retag_tag_bind, coarseSel_coins, hf, hr1]
          exact hy
  | AlgM.note ev k, born, o, g, o', g', σ, σ', x, τ, h, hb, ht, hf, hr => by
    obtain ⟨y, τ', hy, hc⟩ := coarse_coupling P lab kc s l₀ hkc hs k born o
      { g with events := g.events ++ [ev] } o' { g' with events := g'.events ++ [ev] } σ σ' x τ
      (h.congr rfl rfl h.fpSeed h.fpVal rfl rfl h.hists rfl rfl (by simp only [h.events]) h.fps)
      hb ht hf hr
    exact ⟨y, τ', hy, hc⟩

end F2e2e.C.Closure
