import F2e2e.C.Params
import F2e2e.C.Alg.Bits
import F2e2e.B.NumericsAda

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`), part 1: the parameters at the bit scale `ℒ`

`parts/partIII.tex` L1172–1262 (Lemma `R:lem:bit-length-accounting`, Table
`R:tab:bit-length-accounting`); exact transcription in `notes/PAPER_MAP_III_c.md` §III.6.3.

Every public parameter of the Theorem (C) algorithm (`F2e2e/C/ParamsDefs.lean`, namespace
`F2e2e.StreamParams`) is bounded by a polynomial in the integer bit scale `ℒ = P.calL`
(eq. `R:eq:calL-def`), with the paper's constants. Power-of-two parameters are bounded through their
exponents (`log₂ x ≤ k` is `eX ≤ k`); other parameters `x` through `x ≤ 2^k`. All statements hold for
every `P : StreamParams` (the paper's hypothesis `ℒ > 100` is automatic: `ℒ ≥ 100` by definition),
except where a hypothesis is displayed.

* Elementary bounds (L1185–1189): `H ≤ ℒ`, `log₂ T ≤ 2ℒ`, `log₂ D_* ≤ 3ℒ`, `log₂ W ≤ ℒ`,
  `log₂(1/η), log₂ B ≤ 2ℒ`, `log₂ G ≤ 3ℒ²`, `log₂(1/ν) ≤ 6ℒ`.
* eq. `R:eq:log-VH-bound` (L1192–1194): `log₂ V_H ≤ 2ℒ³`; then `log₂ 𝒰_* ≤ 5ℒ³`, `log₂ V ≤ 3ℒ³`,
  `K_epoch ≤ 6ℒ³` (L1196–1198) and `J_* ≤ 2^10 η^{-2} ℒ³` (first part of eq.
  `R:eq:Jstar-Nbank-bounds`).
* Table `R:tab:bit-length-accounting` (L1202–1218): the precision ceilings of all grids.
* Ranges of Definition `R:def:total-behavior`: `log₂ Z_max ≤ 4ℒ³`, `log₂ C_max ≤ 2ℒ²`,
  `log₂ A_max ≤ 7ℒ³` (our constants; the paper only says `O(ℒ³)`).
* Per bank (L1225–1233): `s ≤ 3ℒ`, `a^{-1} ≤ 2^21 η^{-1} ℒ`, `J + R + 1 ≤ 2^13 η^{-2} ℒ³`, the coarse
  rows `R_max · 32 g ≤ 2^26 η^{-2} ℒ⁴`, and `N_bank ≤ 2^200 η^{-2} ℒ⁷` (second part of eq.
  `R:eq:Jstar-Nbank-bounds`; `N_bank` = the rows of one bank, ADA blocks plus coarse groups).
* `η^{-2} < 2^44 ε^{-2} (H+1)^4 ≤ 2^48 ε^{-2} ℒ⁴` (L1253), in exponent form
  `2^{2 log₂(1/η)} ≤ 2^42 · 2^{2 epsExp} (H+1)^4`.

The rows of the bank's ADA blocks are bounded with Theorem B's parameter schedule (B-NUM's
`F2e2e.B.adaN_le_of_bounds`, `F2e2e/B/NumericsAda.lean`) applied to the bank instance
`bankAda P = adaParams P.eBankA P.eBankXi P.bankM P.bankJ P.bankR` of `F2e2e/C/Alg/AdaIface.lean`.

Proof structure: with `c = cP P = ⌈log₂((n+2)(m+2)(U+2))⌉`, `ℒ = 100 + epsExp + betaExp + c`; every
parameter is first bounded sharply in terms of `c` (and `epsExp`), then by a polynomial in `ℒ ≥ 100`.
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg

variable (P : StreamParams)

/-! ## Helpers: polynomials versus powers of two -/

theorem add_two_pow_three_le (k : ℕ) : (k + 2) ^ 3 ≤ 2 ^ (k + 20) := by
  induction k with
  | zero => norm_num
  | succ k ih =>
    rcases Nat.lt_or_ge k 2 with hk | hk
    · interval_cases k <;> norm_num
    · have h1 : (k + 1 + 2) ^ 3 ≤ 2 * (k + 2) ^ 3 := by
        have : k * k ≥ 2 * k := Nat.mul_le_mul_right k hk
        have : k * k * k ≥ 2 * k * k := Nat.mul_le_mul_right k this
        nlinarith
      calc (k + 1 + 2) ^ 3 ≤ 2 * (k + 2) ^ 3 := h1
        _ ≤ 2 * 2 ^ (k + 20) := by omega
        _ = 2 ^ (k + 1 + 20) := by ring

theorem pow_four_le_two_pow {k : ℕ} (hk : 16 ≤ k) : k ^ 4 ≤ 2 ^ k := by
  induction k, hk using Nat.le_induction with
  | base => norm_num
  | succ k hk ih =>
    have h1 : (k + 1) ^ 4 ≤ 2 * k ^ 4 := by
      have h2 : k * k ≥ 16 * k := Nat.mul_le_mul_right k hk
      have h3 : k * k * k ≥ 16 * k * k := Nat.mul_le_mul_right k h2
      have h4 : k * k * k * k ≥ 16 * k * k * k := Nat.mul_le_mul_right k h3
      nlinarith
    calc (k + 1) ^ 4 ≤ 2 * k ^ 4 := h1
      _ ≤ 2 * 2 ^ k := by omega
      _ = 2 ^ (k + 1) := by ring

theorem two_pow_le_two_pow {a b : ℕ} (h : a ≤ b) : 2 ^ a ≤ 2 ^ b :=
  Nat.pow_le_pow_right (by norm_num) h

theorem clog_two_le_of_le_two_pow {x y : ℕ} (h : x ≤ 2 ^ y) : Nat.clog 2 x ≤ y :=
  (Nat.clog_le_iff_le_pow (by norm_num)).2 h

theorem clog_two_le_self (x : ℕ) : Nat.clog 2 x ≤ x :=
  clog_two_le_of_le_two_pow (Nat.lt_two_pow_self).le

/-! ## The bit scale -/

/-- `c = ⌈log₂((n+2)(m+2)(U+2))⌉`, so that `ℒ = 100 + epsExp + betaExp + c`. -/
def cP : ℕ := Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2))

theorem calL_eq_cP : P.calL = 100 + P.epsExp + P.betaExp + cP P := rfl

/-- `ℒ ≥ 100`. -/
theorem hundred_le_calL : 100 ≤ P.calL := by
  unfold calL; omega

theorem prod_le_two_pow_cP : (P.n + 2) * (P.m + 2) * (P.U + 2) ≤ 2 ^ cP P :=
  Nat.le_pow_clog (by norm_num) _

theorem n_add_two_le : P.n + 2 ≤ 2 ^ cP P := by
  refine le_trans ?_ (prod_le_two_pow_cP P)
  calc P.n + 2 ≤ (P.n + 2) * (P.m + 2) := Nat.le_mul_of_pos_right _ (by omega)
    _ ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) := Nat.le_mul_of_pos_right _ (by omega)

theorem m_add_two_le : P.m + 2 ≤ 2 ^ cP P := by
  refine le_trans ?_ (prod_le_two_pow_cP P)
  calc P.m + 2 ≤ (P.n + 2) * (P.m + 2) := Nat.le_mul_of_pos_left _ (by omega)
    _ ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) := Nat.le_mul_of_pos_right _ (by omega)

theorem W_le_cP : P.W ≤ 2 ^ cP P := by
  refine le_trans ?_ (prod_le_two_pow_cP P)
  unfold W
  nlinarith [Nat.zero_le (P.n * P.m * P.U), Nat.zero_le (P.n * P.m), Nat.zero_le (P.m * P.U),
    Nat.zero_le (P.n * P.U)]

theorem H_le_cP : P.H ≤ cP P + 1 := by
  have h : Nat.clog 2 (max 1 P.m) ≤ cP P := by
    apply clog_two_le_of_le_two_pow
    have := m_add_two_le P
    exact le_trans (max_le (by omega) (by omega)) this
  unfold H; omega

theorem T_le_cP : P.T ≤ 2 ^ (2 * cP P + 32) := by
  unfold T
  have hm : P.m + 1 ≤ 2 ^ cP P := by have := m_add_two_le P; omega
  have hH : (P.H + 1) ^ 3 ≤ 2 ^ (cP P + 20) := by
    have h1 := P.one_le_H
    have h2 := H_le_cP P
    have := add_two_pow_three_le (P.H - 1)
    have e : P.H - 1 + 2 = P.H + 1 := by omega
    rw [e] at this
    exact this.trans (two_pow_le_two_pow (by omega))
  calc 2 ^ 12 * (P.m + 1) * (P.H + 1) ^ 3 ≤ 2 ^ 12 * 2 ^ cP P * 2 ^ (cP P + 20) :=
        Nat.mul_le_mul (Nat.mul_le_mul_left _ hm) hH
    _ = 2 ^ (2 * cP P + 32) := by
        rw [← pow_add, ← pow_add, show 12 + cP P + (cP P + 20) = 2 * cP P + 32 by ring]

theorem Dstar_le_cP : P.Dstar ≤ 2 ^ (2 * cP P + 33) := by
  have hT := T_le_cP P
  have hn := n_add_two_le P
  have h1 : 2 ^ cP P ≤ 2 ^ (2 * cP P + 32) := two_pow_le_two_pow (by omega)
  have e : 2 ^ (2 * cP P + 33) = 2 * 2 ^ (2 * cP P + 32) := by rw [pow_succ]; ring
  unfold Dstar
  omega

theorem eEta_le_cP : P.eEta ≤ 2 * cP P + P.epsExp + 24 := by
  have hH := H_le_cP P
  have h : Nat.clog 2 ((P.H + 1) ^ 2) ≤ 2 * (P.H + 1) := by
    apply clog_two_le_of_le_two_pow
    have h1 : (P.H + 1) ^ 2 ≤ (2 ^ (P.H + 1)) ^ 2 := Nat.pow_le_pow_left (Nat.lt_two_pow_self).le 2
    have h2 : (2 ^ (P.H + 1)) ^ 2 = 2 ^ (2 * (P.H + 1)) := by rw [← pow_mul, mul_comm]
    rw [h2] at h1; exact h1
  unfold eEta; omega

theorem eGamma_le_cP : P.eGamma ≤ cP P + 19 := by
  unfold eGamma
  rw [Nat.clog_le_iff_le_pow (by norm_num)]
  have hT := T_le_cP P
  have e : (4 : ℕ) ^ (cP P + 19) = 64 * 2 ^ (2 * cP P + 32) := by
    rw [show (4 : ℕ) = 2 ^ 2 by norm_num, ← pow_mul, show (64 : ℕ) = 2 ^ 6 by norm_num, ← pow_add,
      show 2 * (cP P + 19) = 6 + (2 * cP P + 32) by ring]
  rw [e]
  exact Nat.mul_le_mul_left 64 hT

theorem logB_le_cP : P.logB ≤ cP P + 23 := by
  have := eGamma_le_cP P; unfold logB; omega

theorem logG_le_cP : P.logG ≤ (cP P + 3) * (cP P + 23) := by
  unfold logG
  exact Nat.mul_le_mul (by have := H_le_cP P; omega) (logB_le_cP P)

theorem eNu_le_cP : P.eNu ≤ 4 * cP P + P.epsExp + 64 := by
  have := eGamma_le_cP P; have := eEta_le_cP P; have := H_le_cP P
  unfold eNu; omega

theorem cP_add_hundred_le : cP P + 100 ≤ P.calL := by rw [calL_eq_cP]; omega

theorem cP_add_epsExp_le : cP P + P.epsExp + 100 ≤ P.calL := by rw [calL_eq_cP]; omega

theorem hundred_mul_calL_le_sq : 100 * P.calL ≤ P.calL ^ 2 := by
  have h := hundred_le_calL P
  calc 100 * P.calL ≤ P.calL * P.calL := Nat.mul_le_mul_right _ h
    _ = P.calL ^ 2 := by ring

theorem hundred_mul_sq_le_cube : 100 * P.calL ^ 2 ≤ P.calL ^ 3 := by
  have h := hundred_le_calL P
  calc 100 * P.calL ^ 2 ≤ P.calL * P.calL ^ 2 := Nat.mul_le_mul_right _ h
    _ = P.calL ^ 3 := by ring

/-! ## Elementary bounds (partIII.tex L1185–1189) -/

/-- `m ≤ 2^ℒ`. -/
theorem m_le : P.m ≤ 2 ^ P.calL := by
  have h1 := m_add_two_le P
  have h2 : 2 ^ cP P ≤ 2 ^ P.calL := two_pow_le_two_pow (by have := cP_add_hundred_le P; omega)
  omega

/-- `H ≤ ℒ` (L1185). -/
theorem H_le : P.H ≤ P.calL := by
  have := H_le_cP P; have := cP_add_hundred_le P; omega

/-- `H + 1 ≤ 2ℒ` (used for `(H+1)^4 ≤ 16 ℒ^4`, L1253). -/
theorem H_add_one_le : P.H + 1 ≤ 2 * P.calL := by
  have := H_le_cP P; have := cP_add_hundred_le P; omega

/-- `log₂ T ≤ 2ℒ` (L1185). -/
theorem T_le : P.T ≤ 2 ^ (2 * P.calL) :=
  (T_le_cP P).trans (two_pow_le_two_pow (by have := cP_add_hundred_le P; omega))

/-- `log₂ D_* ≤ 3ℒ` (L1185). -/
theorem Dstar_le : P.Dstar ≤ 2 ^ (3 * P.calL) :=
  (Dstar_le_cP P).trans (two_pow_le_two_pow (by have := cP_add_hundred_le P; omega))

/-- `log₂ W ≤ ℒ` (L1185). -/
theorem W_le : P.W ≤ 2 ^ P.calL :=
  (W_le_cP P).trans (two_pow_le_two_pow (by have := cP_add_hundred_le P; omega))

/-- `log₂(1/η) ≤ 2ℒ` (L1188). -/
theorem eEta_le : P.eEta ≤ 2 * P.calL := by
  have := eEta_le_cP P; have := cP_add_epsExp_le P; omega

/-- `log₂(1/γ) ≤ ℒ + 4`. -/
theorem eGamma_le : P.eGamma ≤ P.calL + 4 := by
  have := eGamma_le_cP P; have := cP_add_hundred_le P; omega

/-- `log₂ B ≤ 2ℒ` (L1188). -/
theorem logB_le : P.logB ≤ 2 * P.calL := by
  have := logB_le_cP P; have := cP_add_hundred_le P; omega

/-- `log₂ G ≤ 3ℒ²` (L1188). -/
theorem logG_le : P.logG ≤ 3 * P.calL ^ 2 := by
  have h := logG_le_cP P
  have h2 := cP_add_hundred_le P
  have h3 : (cP P + 3) * (cP P + 23) ≤ P.calL * P.calL := Nat.mul_le_mul (by omega) (by omega)
  have e : P.calL ^ 2 = P.calL * P.calL := by ring
  omega

/-- `log₂(1/ν) ≤ 6ℒ` (L1188). -/
theorem eNu_le : P.eNu ≤ 6 * P.calL := by
  have := eNu_le_cP P; have := cP_add_epsExp_le P; omega

/-! ## `V_H`, `𝒰_*`, `V`, `K_epoch`, `J_*` (partIII.tex L1190–1198) -/

theorem Vd_le_aux (d : ℕ) : P.Vd d ≤ P.W * 4 ^ d * P.B ^ (d * d) := by
  induction d with
  | zero => simp [Vd]
  | succ d ih =>
    have hB : 1 ≤ P.B ^ d := Nat.one_le_pow _ _ P.B_pos
    have h1 : 1 + 2 * P.B ^ d ≤ 4 * P.B ^ d := by omega
    have hBB : P.B ^ (d * d) * P.B ^ d ≤ P.B ^ ((d + 1) * (d + 1)) := by
      rw [← pow_add]
      exact Nat.pow_le_pow_right P.B_pos (by nlinarith)
    calc P.Vd (d + 1) = (1 + 2 * P.B ^ d) * P.Vd d := rfl
      _ ≤ (4 * P.B ^ d) * (P.W * 4 ^ d * P.B ^ (d * d)) := Nat.mul_le_mul h1 ih
      _ = P.W * 4 ^ (d + 1) * (P.B ^ (d * d) * P.B ^ d) := by ring
      _ ≤ P.W * 4 ^ (d + 1) * P.B ^ ((d + 1) * (d + 1)) := Nat.mul_le_mul_left _ hBB

theorem Vd_le_two_pow (d : ℕ) : P.Vd d ≤ 2 ^ (cP P + 2 * d + P.logB * (d * d)) := by
  have h := Vd_le_aux P d
  have hW := W_le_cP P
  have e1 : (4 : ℕ) ^ d = 2 ^ (2 * d) := by rw [pow_mul]; norm_num
  have e2 : P.B ^ (d * d) = 2 ^ (P.logB * (d * d)) := by unfold B; rw [← pow_mul]
  calc P.Vd d ≤ P.W * 4 ^ d * P.B ^ (d * d) := h
    _ ≤ 2 ^ cP P * 2 ^ (2 * d) * 2 ^ (P.logB * (d * d)) := by
        rw [e1, e2]
        exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hW)
    _ = 2 ^ (cP P + 2 * d + P.logB * (d * d)) := by rw [← pow_add, ← pow_add]

/-- `V_d ≤ 2^{2ℒ³}` for every `d ≤ H`. -/
theorem Vd_le_calL {d : ℕ} (hd : d ≤ P.H) : P.Vd d ≤ 2 ^ (2 * P.calL ^ 3) := by
  refine (Vd_le_two_pow P d).trans (two_pow_le_two_pow ?_)
  have hH := H_le_cP P
  have hc := cP_add_hundred_le P
  have hB := logB_le_cP P
  have h1 : P.logB * (d * d) ≤ P.calL * (P.calL * P.calL) :=
    Nat.mul_le_mul (by omega) (Nat.mul_le_mul (by omega) (by omega))
  have h2 : cP P + 2 * d ≤ P.calL * (P.calL * P.calL) := by
    have h3 := hundred_mul_calL_le_sq P
    have h4 := hundred_mul_sq_le_cube P
    have e : P.calL ^ 3 = P.calL * (P.calL * P.calL) := by ring
    omega
  have e : P.calL ^ 3 = P.calL * (P.calL * P.calL) := by ring
  rw [e]; omega

/-- eq. `R:eq:log-VH-bound` (L1192–1194): `log₂ V_H ≤ log₂ W + 2H + (H(H-1)/2) log₂ B ≤ 2ℒ³`. -/
theorem Vd_H_le : P.Vd P.H ≤ 2 ^ (2 * P.calL ^ 3) := Vd_le_calL P le_rfl

/-- `log₂ 𝒰_* ≤ 5ℒ³` (L1196). -/
theorem eUstar_le : P.eUstar ≤ 5 * P.calL ^ 3 := by
  unfold eUstar eU
  apply clog_two_le_of_le_two_pow
  have hV := Vd_le_calL P (d := P.H - 1) (by omega)
  have hL : 1 ≤ P.calL ^ 3 := Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega)
  calc 2 * P.Vd (P.H - 1) ^ 2 ≤ 2 * (2 ^ (2 * P.calL ^ 3)) ^ 2 :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hV 2)
    _ = 2 ^ (4 * P.calL ^ 3 + 1) := by
        rw [← pow_mul, ← pow_succ', show 2 * P.calL ^ 3 * 2 + 1 = 4 * P.calL ^ 3 + 1 by ring]
    _ ≤ 2 ^ (5 * P.calL ^ 3) := two_pow_le_two_pow (by omega)

/-- `log₂ V ≤ 3ℒ³` (L1196). -/
theorem V_le : P.V ≤ 2 ^ (3 * P.calL ^ 3) := by
  have hV := Vd_H_le P
  have hBH : P.B ^ (P.H + 1) = 2 ^ (P.logB * (P.H + 1)) := by unfold B; rw [← pow_mul]
  have hBV : 1 ≤ P.B ^ (P.H + 1) * P.Vd P.H := Nat.mul_pos (pow_pos P.B_pos _) (P.Vd_pos _)
  have hexp : 4 + P.logB * (P.H + 1) + 2 * P.calL ^ 3 ≤ 3 * P.calL ^ 3 := by
    have hH := H_le_cP P
    have hc := cP_add_hundred_le P
    have hB := logB_le_cP P
    have h1 : P.logB * (P.H + 1) ≤ P.calL * P.calL := Nat.mul_le_mul (by omega) (by omega)
    have h3 := hundred_mul_calL_le_sq P
    have h4 := hundred_mul_sq_le_cube P
    have e : P.calL ^ 2 = P.calL * P.calL := by ring
    omega
  calc P.V = 8 * P.B ^ (P.H + 1) * P.Vd P.H + 2 := rfl
    _ ≤ 16 * (P.B ^ (P.H + 1) * P.Vd P.H) := by
        have e : 8 * P.B ^ (P.H + 1) * P.Vd P.H = 8 * (P.B ^ (P.H + 1) * P.Vd P.H) := by ring
        omega
    _ ≤ 16 * (2 ^ (P.logB * (P.H + 1)) * 2 ^ (2 * P.calL ^ 3)) := by
        rw [hBH]; exact Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hV)
    _ = 2 ^ (4 + P.logB * (P.H + 1) + 2 * P.calL ^ 3) := by
        rw [show (16 : ℕ) = 2 ^ 4 by norm_num, ← pow_add, ← pow_add, ← add_assoc]
    _ ≤ 2 ^ (3 * P.calL ^ 3) := two_pow_le_two_pow hexp

/-- `K_epoch ≤ 6ℒ³` (L1196). -/
theorem Kepoch_le : P.Kepoch ≤ 6 * P.calL ^ 3 := by
  have hU := eUstar_le P
  have hH := H_le P
  have hB := logB_le P
  have hE := eEta_le P
  have hN := eNu_le P
  have hL := hundred_le_calL P
  have h1 : 2 * P.H * P.logB ≤ 2 * P.calL * (2 * P.calL) :=
    Nat.mul_le_mul (Nat.mul_le_mul_left 2 hH) hB
  have h3 := hundred_mul_calL_le_sq P
  have h4 := hundred_mul_sq_le_cube P
  have e : 2 * P.calL * (2 * P.calL) = 4 * P.calL ^ 2 := by ring
  unfold Kepoch; omega

/-- First part of eq. `R:eq:Jstar-Nbank-bounds` (L1178): `J_* ≤ 2^10 η^{-2} ℒ³`. -/
theorem Jstar_le : P.Jstar ≤ 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := by
  have hK := Kepoch_le P
  have hL : 1 ≤ P.calL ^ 3 := Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega)
  unfold Jstar K0
  calc 2 ^ (7 + 2 * P.eEta) * (P.Kepoch + 1) ≤ 2 ^ (7 + 2 * P.eEta) * (8 * P.calL ^ 3) :=
        Nat.mul_le_mul_left _ (by omega)
    _ = 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := by
        rw [pow_add, show (2 : ℕ) ^ 10 = 2 ^ 7 * 8 by norm_num]; ring

/-! ## Table `R:tab:bit-length-accounting` (partIII.tex L1202–1218) -/

/-- `log₂(1/h_g) ≤ 5ℒ²` (including the `2H log₂ B` guard refinement, L1222). -/
theorem eHg_le : P.eHg ≤ 5 * P.calL ^ 2 := by
  have hG := eGamma_le_cP P
  have hE := eEta_le_cP P
  have hN := eNu_le_cP P
  have hH := H_le_cP P
  have hB := logB_le_cP P
  have hc := cP_add_epsExp_le P
  have h1 : 2 * P.H * P.logB ≤ 2 * P.calL * P.calL :=
    Nat.mul_le_mul (Nat.mul_le_mul_left 2 (by omega)) (by omega)
  have h3 := hundred_mul_calL_le_sq P
  have e : 2 * P.calL * P.calL = 2 * P.calL ^ 2 := by ring
  unfold eHg eHgUnref
  omega

/-- `log₂(1/e_C) ≤ 4ℒ³`. -/
theorem one_div_eC_le : (1 : ℚ) / P.eC ≤ 2 ^ (4 * P.calL ^ 3) := by
  have hV := V_le P
  have hHg := eHg_le P
  have hL := hundred_le_calL P
  have e : (1 : ℚ) / P.eC = 2 ^ 10 * P.gamma * P.V * 2 ^ P.eHg := by
    unfold eC StreamParams.hg
    rw [one_div, inv_div, ParamsAux.half_pow_eq_inv, div_inv_eq_mul]
  have hgam : P.gamma ≤ 1 := ParamsAux.half_pow_le_one _
  have hgam0 : 0 ≤ P.gamma := (ParamsAux.half_pow_pos _).le
  have hVq : (P.V : ℚ) ≤ 2 ^ (3 * P.calL ^ 3) := by exact_mod_cast hV
  have hexp : 10 + 3 * P.calL ^ 3 + P.eHg ≤ 4 * P.calL ^ 3 := by
    have h3 := hundred_mul_calL_le_sq P
    have h4 := hundred_mul_sq_le_cube P
    omega
  rw [e]
  have h1 : (2 : ℚ) ^ 10 * P.gamma ≤ 2 ^ 10 * 1 := mul_le_mul_of_nonneg_left hgam (by norm_num)
  have h2 : (2 : ℚ) ^ 10 * P.gamma * P.V ≤ 2 ^ 10 * 1 * 2 ^ (3 * P.calL ^ 3) :=
    mul_le_mul h1 hVq (Nat.cast_nonneg _) (by norm_num)
  calc (2 : ℚ) ^ 10 * P.gamma * P.V * 2 ^ P.eHg ≤ 2 ^ 10 * 1 * 2 ^ (3 * P.calL ^ 3) * 2 ^ P.eHg :=
        mul_le_mul_of_nonneg_right h2 (pow_nonneg (by norm_num) _)
    _ = 2 ^ (10 + 3 * P.calL ^ 3 + P.eHg) := by rw [mul_one, ← pow_add, ← pow_add]
    _ ≤ 2 ^ (4 * P.calL ^ 3) := pow_le_pow_right₀ (by norm_num) hexp

/-- `log₂(1/h_C) ≤ 5ℒ³`. -/
theorem eHC_le : P.eHC ≤ 5 * P.calL ^ 3 := by
  have hT := T_le P
  have hV := V_le P
  have hg := eHg_le P
  have hH := H_le_cP P
  have hB := logB_le_cP P
  have hc := cP_add_hundred_le P
  have hTV : Nat.clog 2 (P.T * P.V) ≤ 2 * P.calL + 3 * P.calL ^ 3 := by
    apply clog_two_le_of_le_two_pow
    rw [pow_add]; exact Nat.mul_le_mul hT hV
  have h1 : (P.H + 1) * P.logB ≤ P.calL * P.calL := Nat.mul_le_mul (by omega) (by omega)
  have h3 := hundred_mul_calL_le_sq P
  have h4 := hundred_mul_sq_le_cube P
  have e : P.calL ^ 2 = P.calL * P.calL := by ring
  unfold eHC; omega

/-- `V + 1 ≤ 2^{3ℒ³ + 1}`. -/
theorem V_add_one_le : P.V + 1 ≤ 2 ^ (3 * P.calL ^ 3 + 1) := by
  have hV := V_le P
  have h1 : 1 ≤ 2 ^ (3 * P.calL ^ 3) := Nat.one_le_two_pow
  rw [pow_succ]; omega

/-- `log₂(1/σ) ≤ 7ℒ³`. -/
theorem eSigma_le : P.eSigma ≤ 7 * P.calL ^ 3 := by
  have hT := T_le P
  have hV := V_add_one_le P
  have hD := Dstar_le P
  have hG := logG_le P
  have hE := eEta_le P
  have hN := eNu_le P
  have hc : Nat.clog 2 (P.T * (P.V + 1) ^ 2 * P.Dstar) ≤
      2 * P.calL + (3 * P.calL ^ 3 + 1) * 2 + 3 * P.calL := by
    apply clog_two_le_of_le_two_pow
    calc P.T * (P.V + 1) ^ 2 * P.Dstar
        ≤ 2 ^ (2 * P.calL) * (2 ^ (3 * P.calL ^ 3 + 1)) ^ 2 * 2 ^ (3 * P.calL) :=
          Nat.mul_le_mul (Nat.mul_le_mul hT (Nat.pow_le_pow_left hV 2)) hD
      _ = 2 ^ (2 * P.calL + (3 * P.calL ^ 3 + 1) * 2 + 3 * P.calL) := by
          rw [← pow_mul, ← pow_add, ← pow_add]
  have hL := hundred_le_calL P
  have h3 := hundred_mul_calL_le_sq P
  have h4 := hundred_mul_sq_le_cube P
  unfold eSigma; omega

/-- `log₂(1/ω) ≤ 14ℒ³`. -/
theorem eOmega_le : P.eOmega ≤ 14 * P.calL ^ 3 := by
  have := eSigma_le P; unfold eOmega; omega

/-- `log₂(1/h_P) ≤ 7ℒ²`. -/
theorem eHP_le : P.eHP ≤ 7 * P.calL ^ 2 := by
  have hT := T_le P
  have hD := Dstar_le P
  have hG := logG_le P
  have hE := eEta_le P
  have hN := eNu_le P
  have hc : Nat.clog 2 (P.T * P.Dstar) ≤ 2 * P.calL + 3 * P.calL := by
    apply clog_two_le_of_le_two_pow
    rw [pow_add]; exact Nat.mul_le_mul hT hD
  have hL := hundred_le_calL P
  have h3 := hundred_mul_calL_le_sq P
  unfold eHP; omega

/-- `log₂(1/h_b) ≤ 18ℒ³`. -/
theorem eHb_le : P.eHb ≤ 18 * P.calL ^ 3 := by
  have hT := T_le P
  have hV := V_add_one_le P
  have hD := Dstar_le P
  have hG := logG_le P
  have hE := eEta_le P
  have hO := eOmega_le P
  have hc : Nat.clog 2 ((P.T + 1) * P.Dstar * (P.V + 1)) ≤
      (2 * P.calL + 1) + 3 * P.calL + (3 * P.calL ^ 3 + 1) := by
    apply clog_two_le_of_le_two_pow
    have h1 : 1 ≤ 2 ^ (2 * P.calL) := Nat.one_le_two_pow
    have hT1 : P.T + 1 ≤ 2 ^ (2 * P.calL + 1) := by rw [pow_succ]; omega
    calc (P.T + 1) * P.Dstar * (P.V + 1)
        ≤ 2 ^ (2 * P.calL + 1) * 2 ^ (3 * P.calL) * 2 ^ (3 * P.calL ^ 3 + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul hT1 hD) hV
      _ = 2 ^ ((2 * P.calL + 1) + 3 * P.calL + (3 * P.calL ^ 3 + 1)) := by
          rw [← pow_add, ← pow_add]
  have hL := hundred_le_calL P
  have h3 := hundred_mul_calL_le_sq P
  have h4 := hundred_mul_sq_le_cube P
  unfold eHb; omega

/-- `log₂(1/h_step) ≤ 5ℒ`. -/
theorem eHstep_le : P.eHstep ≤ 5 * P.calL := by
  have := eEta_le_cP P; have := cP_add_epsExp_le P; unfold eHstep; omega

/-- `log₂(1/h_leaf) ≤ 20ℒ²`. -/
theorem eHleaf_le : P.eHleaf ≤ 20 * P.calL ^ 2 := by
  have hg := eHg_le P
  have hs := eHstep_le P
  have hH := H_le P
  have h1 : 2 * P.H * P.eHstep ≤ 2 * P.calL * (5 * P.calL) :=
    Nat.mul_le_mul (Nat.mul_le_mul_left 2 hH) hs
  have e : 2 * P.calL * (5 * P.calL) = 10 * P.calL ^ 2 := by ring
  unfold eHleaf; omega

/-! ## The ranges of Definition `R:def:total-behavior` (partIII.tex L446–449) -/

/-- `log₂ Z_max ≤ 4ℒ³`. -/
theorem eZmax_le : P.eZmax ≤ 4 * P.calL ^ 3 := by
  have hV := V_add_one_le P
  have hD := Dstar_le P
  have hc : 8 * P.Dstar * (P.V + 1) ≤ 2 ^ (3 + 3 * P.calL + (3 * P.calL ^ 3 + 1)) := by
    calc 8 * P.Dstar * (P.V + 1) ≤ 2 ^ 3 * 2 ^ (3 * P.calL) * 2 ^ (3 * P.calL ^ 3 + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hD) hV
      _ = 2 ^ (3 + 3 * P.calL + (3 * P.calL ^ 3 + 1)) := by rw [← pow_add, ← pow_add]
  have hL := hundred_le_calL P
  have h3 := hundred_mul_calL_le_sq P
  have h4 := hundred_mul_sq_le_cube P
  unfold eZmax
  exact (clog_two_le_of_le_two_pow hc).trans (by omega)

/-- `log₂ C_max ≤ 2ℒ²`. -/
theorem eCmax_le : P.eCmax ≤ 2 * P.calL ^ 2 := by
  have hH := H_le_cP P
  have hB := logB_le_cP P
  have hc := cP_add_hundred_le P
  have hBH : P.B ^ P.H = 2 ^ (P.logB * P.H) := by unfold B; rw [← pow_mul]
  have hB1 : 1 ≤ P.B ^ P.H := Nat.one_le_pow _ _ P.B_pos
  have h1 : 8 * (P.B ^ P.H + 1) ≤ 2 ^ (4 + P.logB * P.H) := by
    calc 8 * (P.B ^ P.H + 1) ≤ 16 * P.B ^ P.H := by omega
      _ = 2 ^ 4 * 2 ^ (P.logB * P.H) := by rw [hBH]; norm_num
      _ = 2 ^ (4 + P.logB * P.H) := by rw [← pow_add]
  have h2 : P.logB * P.H ≤ P.calL * P.calL := Nat.mul_le_mul (by omega) (by omega)
  have h3 := hundred_mul_calL_le_sq P
  have e : P.calL ^ 2 = P.calL * P.calL := by ring
  unfold eCmax
  exact (clog_two_le_of_le_two_pow h1).trans (by omega)

/-- `log₂ A_max ≤ 7ℒ³`. -/
theorem eAmax_le : P.eAmax ≤ 7 * P.calL ^ 3 := by
  have hV := V_add_one_le P
  have h1 : 16 * (P.V + 1) ^ 2 ≤ 2 ^ (4 + (3 * P.calL ^ 3 + 1) * 2) := by
    calc 16 * (P.V + 1) ^ 2 ≤ 2 ^ 4 * (2 ^ (3 * P.calL ^ 3 + 1)) ^ 2 :=
          Nat.mul_le_mul (by norm_num) (Nat.pow_le_pow_left hV 2)
      _ = 2 ^ (4 + (3 * P.calL ^ 3 + 1) * 2) := by rw [← pow_mul, ← pow_add]
  have h2 : 100 ≤ P.calL ^ 3 := le_trans (hundred_le_calL P) (Nat.le_self_pow (by norm_num) _)
  unfold eAmax
  exact (clog_two_le_of_le_two_pow h1).trans (by omega)

/-! ## Fingerprint and row field -/

/-- `M_q ≤ 2^{3(c + 4 + betaExp)}`. -/
theorem Mq_le : P.Mq ≤ 2 ^ (3 * (cP P + 4 + P.betaExp)) := by
  have hprod := prod_le_two_pow_cP P
  have h1 : 10 * P.n * P.m * (P.U + 1) ≤ 2 ^ (cP P + 4) := by
    have h0 : P.n * P.m * (P.U + 1) ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) :=
      Nat.mul_le_mul (Nat.mul_le_mul (by omega) (by omega)) (by omega)
    calc 10 * P.n * P.m * (P.U + 1) = 10 * (P.n * P.m * (P.U + 1)) := by ring
      _ ≤ 16 * ((P.n + 2) * (P.m + 2) * (P.U + 2)) := Nat.mul_le_mul (by norm_num) h0
      _ ≤ 16 * 2 ^ cP P := Nat.mul_le_mul_left _ hprod
      _ = 2 ^ (cP P + 4) := by rw [pow_add]; ring
  have h2 : 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp ≤ 2 ^ (cP P + 4 + P.betaExp) := by
    rw [pow_add (2 : ℕ) (cP P + 4)]
    exact Nat.mul_le_mul_right _ h1
  unfold Mq
  calc (10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp) ^ 3 ≤ (2 ^ (cP P + 4 + P.betaExp)) ^ 3 :=
        Nat.pow_le_pow_left h2 3
    _ = 2 ^ (3 * (cP P + 4 + P.betaExp)) := by rw [← pow_mul, mul_comm]

/-- The fingerprint prime has `O(ℒ)` bits (Lemma `R:lem:zero-fingerprint` (1), Bertrand):
`q ≤ 2^{3ℒ}`. -/
theorem q_le : P.q ≤ 2 ^ (3 * P.calL) := by
  have hMq := Mq_le P
  have hexp : 3 * (cP P + 4 + P.betaExp) + 1 ≤ 3 * P.calL := by rw [calL_eq_cP]; omega
  have hq : P.q ≤ max 2 (2 * P.Mq) := by
    rcases Nat.eq_zero_or_pos P.Mq with h0 | hpos
    · have : P.q ≤ 2 := P.q_le_of_prime (by omega) Nat.prime_two
      omega
    · obtain ⟨p, hp, hlt, hle⟩ := Nat.exists_prime_lt_and_le_two_mul P.Mq hpos.ne'
      have : P.q ≤ p := P.q_le_of_prime hlt.le hp
      omega
  refine hq.trans (max_le ?_ ?_)
  · calc 2 = 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (3 * P.calL) := two_pow_le_two_pow (by have := hundred_le_calL P; omega)
  · calc 2 * P.Mq ≤ 2 * 2 ^ (3 * (cP P + 4 + P.betaExp)) := Nat.mul_le_mul_left _ hMq
      _ = 2 ^ (3 * (cP P + 4 + P.betaExp) + 1) := by rw [pow_succ]; ring
      _ ≤ 2 ^ (3 * P.calL) := two_pow_le_two_pow hexp

/-- The row field degree `w = ⌈log₂(D_*+1)⌉ ≤ 3ℒ + 1`. -/
theorem w_le : P.w ≤ 3 * P.calL + 1 := by
  apply clog_two_le_of_le_two_pow
  have := Dstar_le P
  have h1 : 1 ≤ 2 ^ (3 * P.calL) := Nat.one_le_two_pow
  rw [pow_succ]; omega

/-! ## Per bank (partIII.tex L1225–1233) -/

/-- `s ≤ 3ℒ` (L1226). -/
theorem s_le : P.s ≤ 3 * P.calL := by
  have := eEta_le_cP P; have := cP_add_epsExp_le P; unfold s; omega

/-- `a^{-1} ≤ 2^21 η^{-1} ℒ` for the dyadic accuracy `a = 2^{-eBankA}` of every bank's ADA (L1226). -/
theorem two_pow_eBankA_le : 2 ^ P.eBankA ≤ 2 ^ 21 * 2 ^ P.eEta * P.calL := by
  have hs := s_le P
  have hs1 : 1 ≤ P.s := by unfold s; omega
  have hc : 2 ^ Nat.clog 2 P.s < 2 * P.s := ParamsAux.two_pow_clog_two_lt hs1
  have hc' : 2 ^ Nat.clog 2 P.s ≤ 8 * P.calL := by omega
  unfold eBankA
  calc 2 ^ (18 + P.eEta + Nat.clog 2 P.s) = 2 ^ 18 * 2 ^ P.eEta * 2 ^ Nat.clog 2 P.s := by
        rw [pow_add, pow_add]
    _ ≤ 2 ^ 18 * 2 ^ P.eEta * (8 * P.calL) := Nat.mul_le_mul_left _ hc'
    _ = 2 ^ 21 * 2 ^ P.eEta * P.calL := by
        rw [show (2 : ℕ) ^ 21 = 2 ^ 18 * 8 by norm_num]; ring

/-- `R_max ≤ 2^13 η^{-2} ℒ³`. -/
theorem Rmax_le : P.Rmax ≤ 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := by
  have hJ := Jstar_le P
  have h1 : 1 ≤ 2 ^ (2 * P.eEta) * P.calL ^ 3 :=
    Nat.mul_pos Nat.one_le_two_pow (Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega))
  have e1 : 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 = 1024 * (2 ^ (2 * P.eEta) * P.calL ^ 3) := by
    ring
  have e2 : 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 = 8192 * (2 ^ (2 * P.eEta) * P.calL ^ 3) := by
    ring
  unfold Rmax
  rw [e1] at hJ; rw [e2]
  omega

/-- `J + R + 1 ≤ 2^13 η^{-2} ℒ³` for the bank caps `J = J_max`, `R = R_max` (L1229). -/
theorem Jmax_add_Rmax_add_one_le : P.Jmax + P.Rmax + 1 ≤ 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := by
  have hJ := Jstar_le P
  have h1 : 1 ≤ 2 ^ (2 * P.eEta) * P.calL ^ 3 :=
    Nat.mul_pos Nat.one_le_two_pow (Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega))
  have e1 : 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 = 1024 * (2 ^ (2 * P.eEta) * P.calL ^ 3) := by
    ring
  have e2 : 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 = 8192 * (2 ^ (2 * P.eEta) * P.calL ^ 3) := by
    ring
  unfold Jmax Rmax
  rw [e1] at hJ; rw [e2]
  omega

/-- The coarse group parameter `g = 32 ⌈log₂(4R_max/β_B)⌉ ≤ 2^8 ℒ`. -/
theorem gCoarse_le : P.gCoarse ≤ 2 ^ 8 * P.calL := by
  have hR := Rmax_le P
  have hm := m_add_two_le P
  have hH := H_add_one_le P
  have hE := eEta_le_cP P
  have hL := hundred_le_calL P
  have hL4 : P.calL ^ 4 ≤ 2 ^ P.calL := pow_four_le_two_pow (by omega)
  have h1 : P.Rmax * P.m * (P.H + 1) ≤ 2 ^ (14 + 2 * P.eEta + cP P + P.calL) := by
    calc P.Rmax * P.m * (P.H + 1)
        ≤ (2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3) * 2 ^ cP P * (2 * P.calL) :=
          Nat.mul_le_mul (Nat.mul_le_mul hR (by omega)) hH
      _ = 2 ^ 14 * 2 ^ (2 * P.eEta) * 2 ^ cP P * P.calL ^ 4 := by ring
      _ ≤ 2 ^ 14 * 2 ^ (2 * P.eEta) * 2 ^ cP P * 2 ^ P.calL := Nat.mul_le_mul_left _ hL4
      _ = 2 ^ (14 + 2 * P.eEta + cP P + P.calL) := by rw [← pow_add, ← pow_add, ← pow_add]
  have h2 := clog_two_le_of_le_two_pow h1
  have hc := calL_eq_cP P
  unfold gCoarse
  omega

/-- `N_coarse = R_max · 32 g ≤ 2^26 η^{-2} ℒ⁴` (L1236: `N_coarse = O(η^{-2} ℒ⁴)`). -/
theorem Ncoarse_le : P.Ncoarse ≤ 2 ^ 26 * 2 ^ (2 * P.eEta) * P.calL ^ 4 := by
  have hR := Rmax_le P
  have hg := gCoarse_le P
  unfold Ncoarse coarseGroupRows
  calc P.Rmax * (32 * P.gCoarse) ≤ (2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3) * (32 * (2 ^ 8 * P.calL)) :=
        Nat.mul_le_mul hR (Nat.mul_le_mul_left 32 hg)
    _ = 2 ^ 26 * 2 ^ (2 * P.eEta) * P.calL ^ 4 := by ring

/-- `eBankA = 18 + log₂(1/η) + ⌈log₂ s⌉ ≤ 6ℒ`. -/
theorem eBankA_le : P.eBankA ≤ 6 * P.calL := by
  have hE := eEta_le P
  have hs := s_le P
  have hcs := clog_two_le_self P.s
  have hL := hundred_le_calL P
  unfold eBankA; omega

/-- `eBankXi = betaExp + 7 + ⌈log₂(m(H+1))⌉ ≤ 3ℒ`. -/
theorem eBankXi_le : P.eBankXi ≤ 3 * P.calL := by
  have hm := m_add_two_le P
  have hH := H_add_one_le P
  have hL := hundred_le_calL P
  have h2L : 2 * P.calL ≤ 2 ^ P.calL := by
    have := pow_four_le_two_pow (k := P.calL) (by omega)
    have h4 : 2 * P.calL ≤ P.calL ^ 4 := by
      have := hundred_mul_calL_le_sq P
      have : P.calL ^ 2 ≤ P.calL ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
      omega
    omega
  have h1 : P.m * (P.H + 1) ≤ 2 ^ (cP P + P.calL) := by
    calc P.m * (P.H + 1) ≤ 2 ^ cP P * (2 * P.calL) := Nat.mul_le_mul (by omega) hH
      _ ≤ 2 ^ cP P * 2 ^ P.calL := Nat.mul_le_mul_left _ h2L
      _ = 2 ^ (cP P + P.calL) := by rw [← pow_add]
  have h2 := clog_two_le_of_le_two_pow h1
  have hc := calL_eq_cP P
  unfold eBankXi
  omega

/-- `⌈log₂(m + J_max + R_max + 2)⌉ ≤ 5ℒ + 14`. -/
theorem clog_bank_caps_le : Nat.clog 2 (P.m + P.Jmax + P.Rmax + 2) ≤ 5 * P.calL + 14 := by
  have hJR := Jmax_add_Rmax_add_one_le P
  have hm := m_add_two_le P
  have hE := eEta_le P
  have hL := hundred_le_calL P
  have hL3 : P.calL ^ 3 ≤ 2 ^ P.calL := by
    have := pow_four_le_two_pow (k := P.calL) (by omega)
    have : P.calL ^ 3 ≤ P.calL ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
    omega
  have h2E : 2 ^ (2 * P.eEta) ≤ 2 ^ (4 * P.calL) := two_pow_le_two_pow (by omega)
  have hc : cP P ≤ P.calL := by have := cP_add_hundred_le P; omega
  have h2c : 2 ^ cP P ≤ 2 ^ P.calL := two_pow_le_two_pow hc
  have hJR' : P.Jmax + P.Rmax + 1 ≤ 2 ^ (5 * P.calL + 13) := by
    calc P.Jmax + P.Rmax + 1 ≤ 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := hJR
      _ ≤ 2 ^ 13 * 2 ^ (4 * P.calL) * 2 ^ P.calL :=
          Nat.mul_le_mul (Nat.mul_le_mul_left _ h2E) hL3
      _ = 2 ^ (5 * P.calL + 13) := by
          rw [← pow_add, ← pow_add, show 13 + 4 * P.calL + P.calL = 5 * P.calL + 13 by ring]
  have h5 : 2 ^ P.calL ≤ 2 ^ (5 * P.calL + 13) := two_pow_le_two_pow (by omega)
  have e : 2 ^ (5 * P.calL + 14) = 2 * 2 ^ (5 * P.calL + 13) := by rw [pow_succ]; ring
  apply clog_two_le_of_le_two_pow
  omega

/-- `N_ADA = Σ_j n_j ≤ 2^199 η^{-2} ℒ⁷` (L1235–1237, by substituting `p, χ ≤ 2^12 ℒ`,
`a^{-1} ≤ 2^21 η^{-1} ℒ`, `K = J + R + 1 ≤ 2^13 η^{-2} ℒ³` into eq. `R:eq:sec3_N_explicit`), and the
number of ADA blocks `p + 1 ≤ 2^12 ℒ`. -/
theorem adaRows_le :
    (bankAda P).blockSizes.sum ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 ∧
      (bankAda P).blockSizes.length ≤ 2 ^ 12 * P.calL := by
  have hL := hundred_le_calL P
  have hA4 : 4 ≤ P.eBankA := by unfold eBankA; omega
  have hXi2 : 2 ≤ P.eBankXi := by unfold eBankXi; omega
  have hAle := eBankA_le P
  have hXle := eBankXi_le P
  have hcl := clog_bank_caps_le P
  have hp := B.adaP_le_of_four_le hA4
  have hchi := B.adaChi_le_of_four_le P.m P.Jmax P.Rmax P.eBankXi hA4
  have hblocks : (bankAda P).blockSizes = B.adaBlockSizes P.m P.Jmax P.Rmax P.eBankA P.eBankXi := rfl
  refine ⟨?_, ?_⟩
  · rw [hblocks]
    have hP' : (B.adaP P.eBankA : ℝ) ≤ 2 ^ 12 * (P.calL : ℝ) := by
      have : B.adaP P.eBankA ≤ 2 ^ 12 * P.calL := by omega
      exact_mod_cast this
    have hX' : (B.adaChi P.m P.Jmax P.Rmax P.eBankA P.eBankXi : ℝ) ≤ 2 ^ 12 * (P.calL : ℝ) := by
      have : B.adaChi P.m P.Jmax P.Rmax P.eBankA P.eBankXi ≤ 2 ^ 12 * P.calL := by
        have e : P.m + P.Jmax + P.Rmax + 2 = P.m + P.Jmax + P.Rmax + 2 := rfl
        omega
      exact_mod_cast this
    have hAb' : (2 : ℝ) ^ P.eBankA ≤ 2 ^ 21 * (2 : ℝ) ^ P.eEta * (P.calL : ℝ) := by
      exact_mod_cast two_pow_eBankA_le P
    have hK' : (P.Jmax : ℝ) + P.Rmax + 1 ≤ 2 ^ 13 * ((2 : ℝ) ^ P.eEta) ^ 2 * (P.calL : ℝ) ^ 3 := by
      have h := Jmax_add_Rmax_add_one_le P
      have e : ((2 : ℝ) ^ P.eEta) ^ 2 = 2 ^ (2 * P.eEta) := by rw [← pow_mul, mul_comm]
      rw [e]
      exact_mod_cast h
    have hL1 : (1 : ℝ) ≤ P.calL := by exact_mod_cast (show 1 ≤ P.calL by omega)
    have hE1 : (1 : ℝ) ≤ (2 : ℝ) ^ P.eEta := one_le_pow₀ (by norm_num)
    have h := B.adaN_le_of_bounds P.m P.Jmax P.Rmax hA4 hXi2 hL1 hE1 hP' hX' hAb' hK'
    have e : ((2 : ℝ) ^ P.eEta) ^ 2 = 2 ^ (2 * P.eEta) := by rw [← pow_mul, mul_comm]
    rw [e] at h
    exact_mod_cast h
  · rw [hblocks, B.adaBlockSizes_length]
    omega

/-- Second part of eq. `R:eq:Jstar-Nbank-bounds` (L1178), from the ADA rows: the rows of one bank,
`N_bank = Σ_j n_j + R_max · 32 g ≤ 2^200 η^{-2} ℒ⁷`. -/
theorem bankRows_le_of_adaRows
    (hada : (bankAda P).blockSizes.sum ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7) :
    bankRows P ≤ 2 ^ 200 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := by
  have hN := Ncoarse_le P
  have hL := hundred_le_calL P
  have h47 : P.calL ^ 4 ≤ P.calL ^ 7 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have hc : P.Rmax * (P.gCoarse * 32) = P.Ncoarse := by unfold Ncoarse coarseGroupRows; ring
  unfold bankRows
  rw [hc]
  have h1 : 2 ^ 26 * 2 ^ (2 * P.eEta) * P.calL ^ 4 ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 :=
    Nat.mul_le_mul (Nat.mul_le_mul_right _ (two_pow_le_two_pow (by norm_num))) h47
  have e : 2 ^ 200 * 2 ^ (2 * P.eEta) * P.calL ^ 7 =
      2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 + 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := by ring
  rw [e]
  omega

/-- Second part of eq. `R:eq:Jstar-Nbank-bounds` (L1178): `N_bank ≤ 2^200 η^{-2} ℒ⁷`. -/
theorem bankRows_le : bankRows P ≤ 2 ^ 200 * 2 ^ (2 * P.eEta) * P.calL ^ 7 :=
  bankRows_le_of_adaRows P (adaRows_le P).1

/-! ## `η^{-2}` versus `ε₀^{-2}` (partIII.tex L1253) -/

/-- `η^{-2} = 2^{2 log₂(1/η)} ≤ 2^42 ε₀^{-2} (H+1)^4` (the paper: `η^{-2} < 2^44 ε^{-2} (H+1)^4`,
using `ε₀ > ε/2`). -/
theorem two_pow_two_eEta_le : 2 ^ (2 * P.eEta) ≤ 2 ^ 42 * 2 ^ (2 * P.epsExp) * (P.H + 1) ^ 4 := by
  have h1 : 1 ≤ (P.H + 1) ^ 2 := Nat.one_le_pow _ _ (by omega)
  have hc : 2 ^ Nat.clog 2 ((P.H + 1) ^ 2) ≤ 2 * (P.H + 1) ^ 2 :=
    (ParamsAux.two_pow_clog_two_lt h1).le
  unfold eEta
  calc 2 ^ (2 * (20 + P.epsExp + Nat.clog 2 ((P.H + 1) ^ 2)))
      = 2 ^ 40 * 2 ^ (2 * P.epsExp) * (2 ^ Nat.clog 2 ((P.H + 1) ^ 2)) ^ 2 := by
        rw [← pow_mul, ← pow_add, ← pow_add,
          show 2 * (20 + P.epsExp + Nat.clog 2 ((P.H + 1) ^ 2)) =
            40 + 2 * P.epsExp + Nat.clog 2 ((P.H + 1) ^ 2) * 2 by ring]
    _ ≤ 2 ^ 40 * 2 ^ (2 * P.epsExp) * (2 * (P.H + 1) ^ 2) ^ 2 :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hc 2)
    _ = 2 ^ 42 * 2 ^ (2 * P.epsExp) * (P.H + 1) ^ 4 := by ring

/-- `η^{-2} ≤ 2^46 ε₀^{-2} ℒ⁴` (L1253: `≤ 2^48 ε^{-2} ℒ⁴`). -/
theorem two_pow_two_eEta_le_calL : 2 ^ (2 * P.eEta) ≤ 2 ^ 46 * 2 ^ (2 * P.epsExp) * P.calL ^ 4 := by
  refine (two_pow_two_eEta_le P).trans ?_
  have hH := H_add_one_le P
  calc 2 ^ 42 * 2 ^ (2 * P.epsExp) * (P.H + 1) ^ 4 ≤ 2 ^ 42 * 2 ^ (2 * P.epsExp) * (2 * P.calL) ^ 4 :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hH 4)
    _ = 2 ^ 46 * 2 ^ (2 * P.epsExp) * P.calL ^ 4 := by ring

end F2e2e.C.Space
