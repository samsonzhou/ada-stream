import F2e2e.C.ParamsPublic
import F2e2e.B.ArchParams

/-!
# Theorem (C) parameters: the Theorem-B instance inside each norm bank

Algorithm `R:alg:regularized-norm-bank` (partIII.tex L204–206): every Regularized Norm Bank contains
"the ADA module of Theorem `R:thm:validation_ada` with requested accuracy `a_num`, failure probability `β_B/2`,
and caps `M = m`, `J = J_max`, `R = R_max`".

The algorithm uses B-ARCH's exact computable form `F2e2e.B.adaParams eA eXi M J R` (`F2e2e/B/ArchParams.lean`) at
the dyadic exponents `eA = P.eBankA = ⌈log₂(1/a_num)⌉`, `eXi = P.eBankXi = ⌈log₂(1/(β_B/2))⌉` (this instance is
`F2e2e.C.Alg.bankAda P` in `F2e2e/C/Alg/AdaIface.lean`). `bankAdaParams_eq_dyadicExp` rewrites it to
`adaParams (dyadicExp a_num) (dyadicExp (β_B/2)) m J_max R_max`, the form in which B's bridge lemmas
(`F2e2e/B/ArchParamsBridge.lean`) identify it with the paper form of `F2e2e/B/Params.lean` at `aReq = a_num`,
`ξReq = β_B/2` (whose hypotheses `0 < a_num < 1/10`, `0 < β_B/2 < 1/2` are `aNum_pos`, `aNum_lt_tenth`,
`bankXiReq_pos`, `bankXiReq_lt_half`).

This module is NOT re-exported by `F2e2e.C.Params` (it depends on Part II's files); import it directly.
-/

namespace F2e2e

namespace StreamParams

/-- The bank's ADA instance at the Spec's dyadic inputs `a = dyadicDown a_num`, `ξ_A = dyadicDown (β_B/2)`. -/
theorem bankAdaParams_eq_dyadicExp {P : StreamParams} (hm : 1 ≤ P.m) :
    B.adaParams P.eBankA P.eBankXi P.bankM P.bankJ P.bankR =
      B.adaParams (dyadicExp (P.aNum : ℝ)) (dyadicExp (P.bankXiReq : ℝ)) P.m P.Jmax P.Rmax := by
  rw [← eBankA_eq_dyadicExp, ← eBankXi_eq_dyadicExp hm]
  rfl

end StreamParams

end F2e2e
