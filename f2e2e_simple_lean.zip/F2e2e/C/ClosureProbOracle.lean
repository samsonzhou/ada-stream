import F2e2e.C.ClosureProbFull
import F2e2e.C.ClosureRows
import F2e2e.C.ClosureProbCoreDefs

/-!
# Theorem 6.4, probability layer (C-PROB): the selected bank's ADA module as an oracle

Paper: `parts/partIII.tex` L1271–1277 ("Fix one bank. Its updates, candidate scales, coefficients, guards, and stopping
decisions are functions of protected outputs and auxiliary randomness initially independent of its ADA sample. …
after fixing their complete initial tapes, they can be simulated from the selected bank's permitted history").

For a selected label `lab`, the instrumented run is rewritten as an *oracle program* (`OProg`): every fresh bit of
another component is a `bit` node; the birth of bank `lab` reads its ADA sample (`sample` node) and its ADA
initialization (`init` node); every call of bank `lab`'s ADA module is a `call` node carrying the core-level request
(`callReq`) and continuing with the response. The interpreter `runX` builds this program from the controller code;
bank `lab`'s ADA rows and ADA state are not stored (`eraseBank`): the requests are functions of the bank's history,
not of its sample.

* `handle P I ost`: runs an oracle program with bank `lab`'s ADA module implemented by B's online core
  (`coreStep` on the sample seeds `sOf P rows`), reading the selected bits (`true`) for the sample, the
  initialization and the calls, and recording the transcript;
* `SimRel`, `BirthOnce`: the simulation relation and the "born at most once" hypothesis (proved in
  `ClosureProbSim.lean`: the retagged instrumented run is `handle P (runX …)`, up to erasure).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-- The retagging selecting the ADA sample seeds and the ADA coins of bank `lab`. -/
def adaSel (lab : BankLabel) (τ : Tag) : Bool := decide (τ = Tag.seeds lab ∨ τ = Tag.coins lab)

/-- The final configurations on which bank `lab`'s ADA event fails. -/
def adaBad (P : StreamParams) (lab : BankLabel) : Set (Option ((State × Ghost) × List ℚ)) :=
  {o | ∃ c, o = some c ∧ ¬ AdaGood P lab c.1.2}

/-! ## Oracle programs -/

/-- Oracle programs: `bit` reads a fresh bit of another component, `sample`/`init` read the selected bank's ADA
sample / ADA initialization, `call q k` calls the selected bank's ADA module with the request `q`. -/
inductive OProg (Q : Type) (α : Type) : Type
  | pure : α → OProg Q α
  | bit : (Bool → OProg Q α) → OProg Q α
  | sample : OProg Q α → OProg Q α
  | init : OProg Q α → OProg Q α
  | call : Q → (CoreOut → OProg Q α) → OProg Q α

/-- Read the bits of a bit program as `bit` nodes. -/
def OProg.lift {Q α β : Type} : BitProg β → (β → OProg Q α) → OProg Q α
  | BitProg.pure b, k => k b
  | BitProg.bit f, k => OProg.bit fun x => OProg.lift (f x) k

/-! ## Erasing the selected bank's ADA part -/

/-- A fixed ADA state (the erased state of the selected bank). -/
def dfltSt : AdaState := ⟨[], [], [], [], 0, 0, 0, 0, false, false⟩

/-- A bank without its ADA rows and ADA state. -/
def eraseBank (B : Bank) : Bank := { B with ada := [], adaSt := dfltSt }

/-- Erase the banks labelled `lab` (labels parallel to the banks). -/
def eraseBanks (lab : BankLabel) (labels : List BankLabel) (banks : List Bank) : List Bank :=
  List.zipWith (fun l B => if l = lab then eraseBank B else B) labels banks

/-- The oracle state with the banks labelled `lab` erased. -/
def eraseO (lab : BankLabel) (labels : List BankLabel) (o : OState) : OState :=
  { o with banks := eraseBanks lab labels o.banks }

/-- A call record with an erased bank. -/
def eraseRec (rec : CallRec) : CallRec := { rec with bank := eraseBank rec.bank }

/-- The ghost data with erased banks in the call records. -/
def eraseG (g : Ghost) : Ghost := { g with calls := g.calls.map eraseRec }

/-- The certificate of a core output (`abort` for a numerical output). -/
def certOf : CoreOut → AdaCert
  | Sum.inl c => c
  | Sum.inr _ => AdaCert.abort

/-- The numerical output of a core output (`abort` for a certificate). -/
def numOf : CoreOut → AdaNum
  | Sum.inr x => x
  | Sum.inl _ => AdaNum.abort

/-- The released value of `ReleaseNumerical` at the scale `c` from the ADA output. -/
def relOut (P : StreamParams) (c : ℚ) : AdaNum → Option ℚ
  | AdaNum.val μ => some (max 0 ((P.L : ℚ) * c * μ - P.omega))
  | AdaNum.abort => none

/-- The reserved coarse groups of a fresh bank. -/
def coarseProg (P : StreamParams) : BitProg (List (List (List Row))) :=
  sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax

/-- The coarse scale of a release consuming the group `grp`. -/
def oRelScale (P : StreamParams) (mode : Mode) (grp : List (List Row)) : ℚ :=
  max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)

/-! ## The oracle-split interpreter -/

/-- The instrumented interpreter with bank `lab`'s ADA module as an oracle (`born`: bank `lab` was born). -/
def runX (P : StreamParams) (lab : BankLabel) {α : Type} :
    Bool → AlgM α → OState → Ghost → OProg (CoreReq (Seed P)) (α × OState × Ghost)
  | _, AlgM.pure a, o, g => OProg.pure (a, o, g)
  | b, AlgM.fpInit k, o, g =>
    OProg.lift (fpSeedProg P) fun r => runX P lab b k { o with fpSeed := r, fpVal := 0 } g
  | b, AlgM.fpStep i Δ k, o, g =>
    runX P lab b (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0)) { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }
  | b, AlgM.bankNew tr d k, o, g =>
    if (tr, d) = lab ∧ b = false then
      OProg.sample (OProg.lift (coarseProg P) fun coarse =>
        OProg.init (runX P lab true k { o with banks := o.banks ++ [⟨[], coarse, dfltSt⟩] }
          { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }))
    else
      OProg.lift (newBank P) fun B =>
        runX P lab b k { o with banks := o.banks ++ [B] }
          { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }
  | b, AlgM.bankRetain n k, o, g =>
    runX P lab b k { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }
  | b, AlgM.bankOp idx op k, o, g =>
    runX P lab b k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists }
  | b, AlgM.bankOpFrom idx op k, o, g =>
    runX P lab b k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists }
  | b, AlgM.bankValidate idx S θ k, o, g =>
    match o.banks[idx]? with
    | none => runX P lab b (k AdaCert.abort) o g
    | some B =>
      if g.labelAt idx = lab ∧ b = true then
        OProg.call (callReq P ⟨lab, idx, g.histAt idx, eraseBank B, CallKind.validate S θ, S + P.omega, none⟩)
          fun out => runX P lab b (k (certOf out)) o
            { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, eraseBank B, CallKind.validate S θ,
              S + P.omega, some out⟩] }
      else
        OProg.lift (B.validate P S θ) fun r =>
          runX P lab b (k r.1) { o with banks := setAt r.2 idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, eraseBank B, CallKind.validate S θ,
              S + P.omega, some (Sum.inl r.1)⟩] }
  | b, AlgM.bankRelease idx mode k, o, g =>
    match o.banks[idx]? with
    | none => runX P lab b (k none) o g
    | some B =>
      if g.labelAt idx = lab ∧ b = true then
        match B.coarse with
        | [] =>
          runX P lab b (k none) o
            { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, eraseBank B, CallKind.release mode, 0, none⟩] }
        | grp :: rest =>
          OProg.call (callReq P ⟨lab, idx, g.histAt idx, eraseBank B, CallKind.release mode, oRelScale P mode grp,
              none⟩) fun out =>
            runX P lab b (k (relOut P (oRelScale P mode grp) (numOf out)))
              { o with banks := setAt { B with coarse := rest } idx o.banks }
              { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, eraseBank B, CallKind.release mode,
                oRelScale P mode grp, some out⟩] }
      else
        OProg.lift (releaseLog P B mode) fun r =>
          runX P lab b (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, eraseBank B, CallKind.release mode,
              (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] }
  | b, AlgM.note ev k, o, g => runX P lab b k o { g with events := g.events ++ [ev] }

/-! ## Running the oracle with B's online core -/

/-- The state of the selected bank's ADA module: its sample rows (the seeds `sOf P rows`), its core state and its
transcript (requests and outputs so far, oldest first). -/
structure OrSt (P : StreamParams) where
  /-- the sample rows -/
  rows : List (List Row)
  /-- the core state -/
  st : AdaState
  /-- the requests and outputs so far, oldest first -/
  trv : List (CoreReq (Seed P) × CoreOut)

/-- The transcript of an oracle state (`[]` before the birth). -/
def trvOf {P : StreamParams} : Option (OrSt P) → List (CoreReq (Seed P) × CoreOut)
  | none => []
  | some os => os.trv

/-- Run an oracle program with the selected bank's ADA module implemented by B's online core: the selected bits
(tag `true`) are read for the sample (`sampleBlocks`), the initialization (`adaInit`) and the calls (`coreStep`);
the other bits have tag `false`. -/
def handle (P : StreamParams) {α : Type} :
    OProg (CoreReq (Seed P)) α → Option (OrSt P) → TBitProg Bool (α × Option (OrSt P))
  | OProg.pure x, ost => TBitProg.pure (x, ost)
  | OProg.bit k, ost => TBitProg.bit false fun b => handle P (k b) ost
  | OProg.sample k, _ =>
    (tag true (sampleBlocks P (bankAda P).blockSizes)).bind fun rows =>
      handle P k (some ⟨rows, dfltSt, []⟩)
  | OProg.init k, ost =>
    (tag true (adaInit (bankAda P))).bind fun st => handle P k (ost.map fun os => { os with st := st })
  | OProg.call _ k, none => handle P (k (Sum.inl AdaCert.abort)) none
  | OProg.call req k, some os =>
    (tag true (coreStep (bankAda P) (sOf P os.rows) req os.st)).bind fun r =>
      handle P (k r.1) (some { os with st := r.2, trv := os.trv ++ [(req, r.1)] })

theorem handle_lift (P : StreamParams) {α β : Type} (k : β → OProg (CoreReq (Seed P)) α)
    (ost : Option (OrSt P)) :
    ∀ q : BitProg β, handle P (OProg.lift q k) ost = (tag false q).bind fun b => handle P (k b) ost
  | BitProg.pure b => rfl
  | BitProg.bit f => by
    simp only [OProg.lift, handle, tag_bit, bind_bit]
    congr 1
    funext x
    exact handle_lift P k ost (f x)

/-! ## Shape of the oracle programs built by `runX` -/

/-- After the selected bank's initialization: only bits and calls. -/
inductive Phase3 {Q α : Type} : OProg Q α → Prop
  | pure (x : α) : Phase3 (OProg.pure x)
  | bit (k : Bool → OProg Q α) : (∀ b, Phase3 (k b)) → Phase3 (OProg.bit k)
  | call (q : Q) (k : CoreOut → OProg Q α) : (∀ r, Phase3 (k r)) → Phase3 (OProg.call q k)

/-- Between the selected bank's sample and its initialization: only bits, then the initialization. -/
inductive Phase2 {Q α : Type} : OProg Q α → Prop
  | pure (x : α) : Phase2 (OProg.pure x)
  | bit (k : Bool → OProg Q α) : (∀ b, Phase2 (k b)) → Phase2 (OProg.bit k)
  | init (k : OProg Q α) : Phase3 k → Phase2 (OProg.init k)

/-- Before the selected bank's birth: only bits, then (at most once) the birth. -/
inductive Phase1 {Q α : Type} : OProg Q α → Prop
  | pure (x : α) : Phase1 (OProg.pure x)
  | bit (k : Bool → OProg Q α) : (∀ b, Phase1 (k b)) → Phase1 (OProg.bit k)
  | sample (k : OProg Q α) : Phase2 k → Phase1 (OProg.sample k)

/-- Every call node carries a valid core request (`CoreCtrl.Valid`'s conditions). -/
inductive ValidCalls (A : AdaParams) {U α : Type} : OProg (CoreReq U) α → Prop
  | pure (x : α) : ValidCalls A (OProg.pure x)
  | bit (k : Bool → OProg (CoreReq U) α) : (∀ b, ValidCalls A (k b)) → ValidCalls A (OProg.bit k)
  | sample (k : OProg (CoreReq U) α) : ValidCalls A k → ValidCalls A (OProg.sample k)
  | init (k : OProg (CoreReq U) α) : ValidCalls A k → ValidCalls A (OProg.init k)
  | call (q : CoreReq U) (k : CoreOut → OProg (CoreReq U) α) :
      ((∀ x, q.f x ≤ 2 ^ A.qA) ∧ (q.isInterval = true → q.l ≤ q.u)) → (∀ r, ValidCalls A (k r)) →
      ValidCalls A (OProg.call q k)

/-! ## Births at most once -/

/-- Along every path (for all answers of the primitives), bank `lab` is born at most once, and not at all if
`born`. -/
def BirthOnce (lab : BankLabel) {α : Type} : Bool → AlgM α → Prop
  | _, AlgM.pure _ => True
  | b, AlgM.fpInit k => BirthOnce lab b k
  | b, AlgM.fpStep _ _ k => ∀ z, BirthOnce lab b (k z)
  | b, AlgM.bankNew tr d k => if (tr, d) = lab then b = false ∧ BirthOnce lab true k else BirthOnce lab b k
  | b, AlgM.bankRetain _ k => BirthOnce lab b k
  | b, AlgM.bankOp _ _ k => BirthOnce lab b k
  | b, AlgM.bankOpFrom _ _ k => BirthOnce lab b k
  | b, AlgM.bankValidate _ _ _ k => ∀ c, BirthOnce lab b (k c)
  | b, AlgM.bankRelease _ _ k => ∀ r, BirthOnce lab b (k r)
  | b, AlgM.note _ k => BirthOnce lab b k

/-! ## The simulation relation -/

/-- The relation between a state `(o, g)` of the instrumented run, the oracle state `ost` of the selected bank's
ADA module and the birth flag `f`. -/
structure SimRel (P : StreamParams) (lab : BankLabel) (o : OState) (g : Ghost) (ost : Option (OrSt P))
    (f : Bool) : Prop where
  rows : RowsOK P o g
  flag : ost = none ↔ f = false
  uniq : ∀ i j : ℕ, g.labels[i]? = some lab → g.labels[j]? = some lab → i = j
  none_lab : ost = none → lab ∉ g.labels ∧ adaTranscript P lab g = []
  some_trv : ∀ os, ost = some os → adaTranscript P lab g = os.trv
  some_bank : ∀ os, ost = some os → ∀ (idx : ℕ) (B : Bank), o.banks[idx]? = some B → g.labels[idx]? = some lab →
    B.adaSt = os.st ∧ sOf P B.ada = sOf P os.rows ∧ B.ada.map List.length = (bankAda P).blockSizes

/-- The observable result of the instrumented run, compared with the oracle-split run. -/
def simOut (P : StreamParams) (lab : BankLabel) {α : Type} (r : α × OState × Ghost) :
    (α × OState × Ghost) × List (CoreReq (Seed P) × CoreOut) :=
  ((r.1, eraseO lab r.2.2.labels r.2.1, eraseG r.2.2), adaTranscript P lab r.2.2)

end F2e2e.C.Closure
