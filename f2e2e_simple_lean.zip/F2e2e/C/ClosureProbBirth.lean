import F2e2e.C.ClosureProbFull
import F2e2e.C.ClosureProbLabelsAux

/-!
# Theorem 6.4, probability layer: every-path facts of the controller program

Interpreter-independent facts about C-ALG's controller code (`F2e2e/C/Alg/AlgMCode.lean`) and the whole canonical
interaction `fullCode` (C-PROB's `F2e2e/C/ClosureProbFull.lean`), stated on every path of the free monad `AlgM`
(every answer of every oracle call):

* `BirthsOK lab f p Q`: along every path, the bank label `lab` is born (`bankNew` with label `lab`) at most once,
  and not at all if it was already born (`f = true`); the final result and the flag satisfy `Q`.
  `birthsOK_roundCode` (round `t` births only labels `(t+1, d)`, each at most once), `birthsOK_initCode`
  (initialization births only `(0, 0)`), and `birthsOK_fullCode`: after the rounds `0, …, t-1` the round counter is
  `t` and labels with first component `> t` are not yet born; in particular every label is born at most once
  (`birthsOK_fullCode_once`). (partIII.tex L1281: "their birth schedule is independent of corrections"; Definition
  `R:def:binary-tree-architecture` (2), L432.)
* `ThetaOK p`: every `ValidateInterval(S, θ)` call along every path has `θ ≥ 0` (the only one is Step 4's
  `θ = (8(H − d) + 4) η`, partIII.tex L498); `thetaOK_fullCode`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-! ### Births of one label along every path -/

/-- `BirthsOK lab f p Q`: along every path of `p`, the label `lab` is born at most once, and not at all if
`f = true` (already born); the final result and flag satisfy `Q`. -/
def BirthsOK (lab : BankLabel) {α : Type} : Bool → AlgM α → (α → Bool → Prop) → Prop
  | f, AlgM.pure a, Q => Q a f
  | f, AlgM.fpInit k, Q => BirthsOK lab f k Q
  | f, AlgM.fpStep _ _ k, Q => ∀ b, BirthsOK lab f (k b) Q
  | f, AlgM.bankNew tr d k, Q =>
    if (tr, d) = lab then f = false ∧ BirthsOK lab true k Q else BirthsOK lab f k Q
  | f, AlgM.bankRetain _ k, Q => BirthsOK lab f k Q
  | f, AlgM.bankOp _ _ k, Q => BirthsOK lab f k Q
  | f, AlgM.bankOpFrom _ _ k, Q => BirthsOK lab f k Q
  | f, AlgM.bankValidate _ _ _ k, Q => ∀ c, BirthsOK lab f (k c) Q
  | f, AlgM.bankRelease _ _ k, Q => ∀ o, BirthsOK lab f (k o) Q
  | f, AlgM.note _ k, Q => BirthsOK lab f k Q

theorem BirthsOK.bind' (lab : BankLabel) {α β : Type} {R : α → Bool → Prop} {Q : β → Bool → Prop}
    {g : α → AlgM β} (hg : ∀ a f', R a f' → BirthsOK lab f' (g a) Q) :
    ∀ (f : Bool) (p : AlgM α), BirthsOK lab f p R → BirthsOK lab f (p.bind g) Q
  | f, AlgM.pure a, h => hg a f h
  | f, AlgM.fpInit k, h => BirthsOK.bind' lab hg f k h
  | f, AlgM.fpStep _ _ k, h => fun b => BirthsOK.bind' lab hg f (k b) (h b)
  | f, AlgM.bankNew tr d k, h => by
    have h' : if (tr, d) = lab then f = false ∧ BirthsOK lab true k R else BirthsOK lab f k R := h
    show if (tr, d) = lab then f = false ∧ BirthsOK lab true (k.bind g) Q
      else BirthsOK lab f (k.bind g) Q
    split_ifs at h' ⊢
    · exact ⟨h'.1, BirthsOK.bind' lab hg true k h'.2⟩
    · exact BirthsOK.bind' lab hg f k h'
  | f, AlgM.bankRetain _ k, h => BirthsOK.bind' lab hg f k h
  | f, AlgM.bankOp _ _ k, h => BirthsOK.bind' lab hg f k h
  | f, AlgM.bankOpFrom _ _ k, h => BirthsOK.bind' lab hg f k h
  | f, AlgM.bankValidate _ _ _ k, h => fun c => BirthsOK.bind' lab hg f (k c) (h c)
  | f, AlgM.bankRelease _ _ k, h => fun o => BirthsOK.bind' lab hg f (k o) (h o)
  | f, AlgM.note _ k, h => BirthsOK.bind' lab hg f k h

theorem BirthsOK.bind {lab : BankLabel} {α β : Type} {R : α → Bool → Prop} {Q : β → Bool → Prop}
    {f : Bool} {p : AlgM α} {g : α → AlgM β} (hp : BirthsOK lab f p R)
    (hg : ∀ a f', R a f' → BirthsOK lab f' (g a) Q) : BirthsOK lab f (p.bind g) Q :=
  BirthsOK.bind' lab hg f p hp

theorem BirthsOK.mono' (lab : BankLabel) {α : Type} {Q Q' : α → Bool → Prop}
    (hQ : ∀ a f', Q a f' → Q' a f') : ∀ (f : Bool) (p : AlgM α), BirthsOK lab f p Q → BirthsOK lab f p Q'
  | f, AlgM.pure a, h => hQ a f h
  | f, AlgM.fpInit k, h => BirthsOK.mono' lab hQ f k h
  | f, AlgM.fpStep _ _ k, h => fun b => BirthsOK.mono' lab hQ f (k b) (h b)
  | f, AlgM.bankNew tr d k, h => by
    have h' : if (tr, d) = lab then f = false ∧ BirthsOK lab true k Q else BirthsOK lab f k Q := h
    show if (tr, d) = lab then f = false ∧ BirthsOK lab true k Q' else BirthsOK lab f k Q'
    split_ifs at h' ⊢
    · exact ⟨h'.1, BirthsOK.mono' lab hQ true k h'.2⟩
    · exact BirthsOK.mono' lab hQ f k h'
  | f, AlgM.bankRetain _ k, h => BirthsOK.mono' lab hQ f k h
  | f, AlgM.bankOp _ _ k, h => BirthsOK.mono' lab hQ f k h
  | f, AlgM.bankOpFrom _ _ k, h => BirthsOK.mono' lab hQ f k h
  | f, AlgM.bankValidate _ _ _ k, h => fun c => BirthsOK.mono' lab hQ f (k c) (h c)
  | f, AlgM.bankRelease _ _ k, h => fun o => BirthsOK.mono' lab hQ f (k o) (h o)
  | f, AlgM.note _ k, h => BirthsOK.mono' lab hQ f k h

theorem BirthsOK.mono {lab : BankLabel} {α : Type} {Q Q' : α → Bool → Prop} {f : Bool} {p : AlgM α}
    (h : BirthsOK lab f p Q) (hQ : ∀ a f', Q a f' → Q' a f') : BirthsOK lab f p Q' :=
  BirthsOK.mono' lab hQ f p h

/-- A program without allocation births nothing. -/
theorem birthsOK_of_noNewR (lab : BankLabel) {α : Type} {Q : α → Prop} :
    ∀ (f : Bool) (p : AlgM α), NoNewR Q p → BirthsOK lab f p (fun a f' => Q a ∧ f' = f)
  | _, AlgM.pure _, h => ⟨h, rfl⟩
  | f, AlgM.fpInit k, h => birthsOK_of_noNewR lab f k h
  | f, AlgM.fpStep _ _ k, h => fun b => birthsOK_of_noNewR lab f (k b) (h b)
  | _, AlgM.bankNew _ _ _, h => False.elim h
  | f, AlgM.bankRetain _ k, h => birthsOK_of_noNewR lab f k h
  | f, AlgM.bankOp _ _ k, h => birthsOK_of_noNewR lab f k h
  | f, AlgM.bankOpFrom _ _ k, h => birthsOK_of_noNewR lab f k h
  | f, AlgM.bankValidate _ _ _ k, h => fun c => birthsOK_of_noNewR lab f (k c) (h c)
  | f, AlgM.bankRelease _ _ k, h => fun o => birthsOK_of_noNewR lab f (k o) (h o)
  | f, AlgM.note _ k, h => birthsOK_of_noNewR lab f k h

section Births

variable (lab : BankLabel) (P : StreamParams)

/-- The birth of depth `d` of round `tr` births at most the label `(tr, d)`. -/
theorem birthsOK_birthCode (tr d0 d : ℕ) (c : CState) (f : Bool) (hf : (tr, d) = lab → f = false) :
    BirthsOK lab f (birthCode P tr d0 d c) (fun c' f' => c'.t = c.t ∧ ((tr, d) ≠ lab → f' = f)) := by
  obtain ⟨R, hR, hEq⟩ := birthCode_shape P tr d0 d c
  rw [hEq]
  show BirthsOK lab f (if d + 2 ≤ P.H then AlgM.bankNew tr d R else R) _
  split_ifs with hd
  · show if (tr, d) = lab then f = false ∧ BirthsOK lab true R _ else BirthsOK lab f R _
    split_ifs with hl
    · exact ⟨hf hl, (birthsOK_of_noNewR lab true R hR).mono fun c' f' h =>
        ⟨h.1, fun hne => absurd hl hne⟩⟩
    · exact (birthsOK_of_noNewR lab f R hR).mono fun c' f' h => ⟨h.1, fun _ => h.2⟩
  · exact (birthsOK_of_noNewR lab f R hR).mono fun c' f' h => ⟨h.1, fun _ => h.2⟩

/-- The births of the depths `d, d+1, …, d+n-1` of round `tr`. -/
theorem birthsOK_birthLoopCode (tr d0 : ℕ) :
    ∀ (n d : ℕ) (c : CState) (f : Bool), (lab.1 = tr → d ≤ lab.2 → f = false) →
      BirthsOK lab f (birthLoopCode P tr d0 (List.range' d n) c)
        (fun c' f' => c'.t = c.t ∧ (lab.1 ≠ tr → f' = f) ∧ (lab.1 = tr → d + n ≤ lab.2 → f' = false))
  | 0, d, c, f, hf => by
    rw [List.range'_zero]
    exact ⟨rfl, fun _ => rfl, fun h1 h2 => hf h1 (by omega)⟩
  | n + 1, d, c, f, hf => by
    rw [List.range'_succ]
    simp only [birthLoopCode]
    split_ifs with hc
    · exact ⟨rfl, fun _ => rfl, fun h1 h2 => hf h1 (by omega)⟩
    · have hpre : (tr, d) = lab → f = false := fun hl => by
        have h1 : lab.1 = tr := by rw [← hl]
        have h2 : lab.2 = d := by rw [← hl]
        exact hf h1 (by omega)
      refine BirthsOK.bind (birthsOK_birthCode lab P tr d0 d c f hpre) fun c' f'' h => ?_
      have hne_of : d + 1 ≤ lab.2 → (tr, d) ≠ lab := fun h2 hl => by
        have : lab.2 = d := by rw [← hl]
        omega
      refine (birthsOK_birthLoopCode tr d0 n (d + 1) c' f'' (fun h1 h2 => ?_)).mono fun c2 f2 h2' => ?_
      · rw [h.2 (hne_of h2)]
        exact hf h1 (by omega)
      · refine ⟨h2'.1.trans h.1, fun hne => ?_, fun h1 h3 => h2'.2.2 h1 (by omega)⟩
        have hne' : (tr, d) ≠ lab := fun hl => hne (by rw [← hl])
        rw [h2'.2.1 hne, h.2 hne']

/-- Step 1 of round `c.t` births only labels `(c.t + 1, d)`, each at most once. -/
theorem birthsOK_step1Code (c : CState) (f : Bool) (hf : lab.1 = c.t + 1 → f = false) :
    BirthsOK lab f (step1Code P c) (fun c' f' => c'.t = c.t ∧ (lab.1 ≠ c.t + 1 → f' = f)) := by
  have hshape : step1Code P c = AlgM.bankRetain (firstBorn P.H (c.t + 1) + 1)
      ((birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1))
          (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1)))
          { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }).bind
        fun c2 => AlgM.pure { c2 with leaf := 0 }) := rfl
  rw [hshape]
  show BirthsOK lab f ((birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1))
          (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1)))
          { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }).bind
        fun c2 => AlgM.pure { c2 with leaf := 0 }) _
  refine BirthsOK.bind (birthsOK_birthLoopCode lab P (c.t + 1) _ _ _ _ f (fun h1 _ => hf h1))
    fun c2 f2 h => ?_
  exact ⟨h.1, h.2.1⟩

/-- **One round** births only labels `(c.t + 1, d)`, each at most once, and counts the round. -/
theorem birthsOK_roundCode (c : CState) (i : ℕ) (Δ : ℤ) (f : Bool)
    (hf : lab.1 = c.t + 1 → f = false) :
    BirthsOK lab f (roundCode P c i Δ) (fun r f' => r.1.t = c.t + 1 ∧ (lab.1 ≠ c.t + 1 → f' = f)) := by
  rw [FP.roundCode_eq]
  split_ifs with hc
  · exact ⟨rfl, fun _ => rfl⟩
  · show BirthsOK lab f ((step1Code P c).bind (FP.fpTail1 P i Δ)) _
    refine BirthsOK.bind (birthsOK_step1Code lab P c f hf) fun c1 f1 h => ?_
    unfold FP.fpTail1
    split_ifs with h1
    · exact ⟨by simp [finishC, h.1], h.2⟩
    · have hN : NoNewR (fun x : CState × ℚ => x.1.t = c1.t + 1)
          ((step2Code P i Δ c1).bind (FP.fpTail2 P)) :=
        NoNewR.bind (noNewR_step2Code P i Δ c1) fun r2 hr2 =>
          (noNewR_fpTail2 P r2).mono fun x hx => by rw [hx, hr2]
      exact (birthsOK_of_noNewR lab f1 _ hN).mono fun r f' h' =>
        ⟨by rw [h'.1, h.1], fun hne => by rw [h'.2, h.2 hne]⟩

end Births

/-- The initialization births only the root label `(0, 0)`. -/
theorem birthsOK_initCode (lab : BankLabel) :
    BirthsOK lab false initCode (fun c f => c.t = 0 ∧ (f = true ↔ lab = (0, 0))) := by
  have hshape : initCode = AlgM.fpInit (AlgM.bankNew 0 0 (AlgM.pure ⟨0, false, [], 0⟩)) := rfl
  rw [hshape]
  simp only [BirthsOK]
  split_ifs with hl
  · subst hl
    simp
  · simp [Ne.symm hl]

/-- **Births along the canonical interaction**: after the rounds `0, …, t-1` the round counter is `t`, and
labels with first component `> t` are not yet born; every label is born at most once. -/
theorem birthsOK_fullCode (P : StreamParams) (adv : StreamAdversary P.n) (lab : BankLabel) :
    ∀ t, BirthsOK lab false (fullCode P adv t) (fun co f => co.1.t = t ∧ (t < lab.1 → f = false))
  | 0 => by
    show BirthsOK lab false (initCode.bind fun c => AlgM.pure (c, [])) _
    refine BirthsOK.bind (birthsOK_initCode lab) fun c f h => ?_
    refine ⟨h.1, fun hlt => ?_⟩
    cases f with
    | false => rfl
    | true =>
      have he : lab = (0, 0) := h.2.mp rfl
      rw [he] at hlt
      exact absurd hlt (lt_irrefl 0)
  | t + 1 => by
    show BirthsOK lab false ((fullCode P adv t).bind fun co =>
      (roundCode P co.1 (adv co.2).1.val (adv co.2).2).bind fun r => AlgM.pure (r.1, co.2 ++ [r.2])) _
    refine BirthsOK.bind (birthsOK_fullCode P adv lab t) fun co f h => ?_
    refine BirthsOK.bind (birthsOK_roundCode lab P co.1 _ _ f (fun h1 => h.2 (by rw [h1, h.1]; omega)))
      fun r f' h' => ?_
    refine ⟨by rw [h'.1, h.1], fun hlt => ?_⟩
    rw [h'.2 (by rw [h.1]; omega)]
    exact h.2 (by omega)

/-- Every label is born at most once along every path of the canonical interaction. -/
theorem birthsOK_fullCode_once (P : StreamParams) (adv : StreamAdversary P.n) (lab : BankLabel) (t : ℕ) :
    BirthsOK lab false (fullCode P adv t) (fun _ _ => True) :=
  (birthsOK_fullCode P adv lab t).mono fun _ _ _ => trivial

/-! ### Validation radii are nonnegative -/

/-- `ThetaOK p`: every `ValidateInterval(S, θ)` call along every path of `p` has `θ ≥ 0`. -/
def ThetaOK {α : Type} : AlgM α → Prop
  | AlgM.pure _ => True
  | AlgM.fpInit k => ThetaOK k
  | AlgM.fpStep _ _ k => ∀ b, ThetaOK (k b)
  | AlgM.bankNew _ _ k => ThetaOK k
  | AlgM.bankRetain _ k => ThetaOK k
  | AlgM.bankOp _ _ k => ThetaOK k
  | AlgM.bankOpFrom _ _ k => ThetaOK k
  | AlgM.bankValidate _ _ θ k => 0 ≤ θ ∧ ∀ c, ThetaOK (k c)
  | AlgM.bankRelease _ _ k => ∀ o, ThetaOK (k o)
  | AlgM.note _ k => ThetaOK k

theorem ThetaOK.bind' {α β : Type} {f : α → AlgM β} (hf : ∀ a, ThetaOK (f a)) :
    ∀ (p : AlgM α), ThetaOK p → ThetaOK (p.bind f)
  | AlgM.pure a, _ => hf a
  | AlgM.fpInit k, h => ThetaOK.bind' hf k h
  | AlgM.fpStep _ _ k, h => fun b => ThetaOK.bind' hf (k b) (h b)
  | AlgM.bankNew _ _ k, h => ThetaOK.bind' hf k h
  | AlgM.bankRetain _ k, h => ThetaOK.bind' hf k h
  | AlgM.bankOp _ _ k, h => ThetaOK.bind' hf k h
  | AlgM.bankOpFrom _ _ k, h => ThetaOK.bind' hf k h
  | AlgM.bankValidate _ _ _ k, h => ⟨h.1, fun c => ThetaOK.bind' hf (k c) (h.2 c)⟩
  | AlgM.bankRelease _ _ k, h => fun o => ThetaOK.bind' hf (k o) (h o)
  | AlgM.note _ k, h => ThetaOK.bind' hf k h

theorem ThetaOK.bind {α β : Type} {p : AlgM α} {f : α → AlgM β} (hp : ThetaOK p)
    (hf : ∀ a, ThetaOK (f a)) : ThetaOK (p.bind f) :=
  ThetaOK.bind' hf p hp

@[simp] theorem thetaOK_ite {α : Type} (c : Prop) [Decidable c] (a b : AlgM α) :
    ThetaOK (if c then a else b) ↔ (c → ThetaOK a) ∧ (¬c → ThetaOK b) := by
  by_cases h : c <;> simp [h]

/-- A program without allocation has no validation with a negative radius if … (used below only through
the code lemmas). -/
theorem theta_nonneg (P : StreamParams) (d : ℕ) : (0 : ℚ) ≤ (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta := by
  unfold StreamParams.eta
  positivity

section Theta

variable (P : StreamParams)

theorem thetaOK_birthCode (tr d0 d : ℕ) (c : CState) : ThetaOK (birthCode P tr d0 d c) := by
  simp [birthCode, bankOpM, bankNewM, noteM, releaseM, AlgM.bind, ThetaOK, Option.forall]

theorem thetaOK_birthLoopCode (tr d0 : ℕ) :
    ∀ (ds : List ℕ) (c : CState), ThetaOK (birthLoopCode P tr d0 ds c)
  | [], _ => trivial
  | d :: ds, c => by
    simp only [birthLoopCode]
    split_ifs
    · trivial
    · exact ThetaOK.bind (thetaOK_birthCode P tr d0 d c) fun c' => thetaOK_birthLoopCode tr d0 ds c'

theorem thetaOK_step1Code (c : CState) : ThetaOK (step1Code P c) := by
  simp only [step1Code, bankRetainM, AlgM.bind_eq, AlgM.bind, ThetaOK]
  exact ThetaOK.bind (thetaOK_birthLoopCode P _ _ _ _) fun _ => trivial

theorem thetaOK_step2Code (i : ℕ) (Δ : ℤ) (c : CState) : ThetaOK (step2Code P i Δ c) := by
  simp [step2Code, fpStepM, bankOpFromM, noteM, AlgM.bind, ThetaOK]

theorem thetaOK_step3DepthCode (tr : ℕ) (c : CState) (d : ℕ) : ThetaOK (step3DepthCode P tr c d) := by
  unfold step3DepthCode
  split
  · trivial
  · simp [bankOpM, bankOpFromM, noteM, AlgM.bind, ThetaOK]

theorem thetaOK_step3LoopCode (tr : ℕ) :
    ∀ (ds : List ℕ) (c : CState), ThetaOK (step3LoopCode P tr ds c)
  | [], _ => trivial
  | d :: ds, c => by
    simp only [step3LoopCode]
    split_ifs
    · trivial
    · exact ThetaOK.bind (thetaOK_step3DepthCode P tr c d) fun c' => thetaOK_step3LoopCode tr ds c'

theorem thetaOK_rejectTailCode (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (c : CState) :
    ThetaOK (rejectTailCode P d Ld cInt N1 c) := by
  simp only [rejectTailCode, bankOpFromM, noteM, releaseM, AlgM.bind_eq, AlgM.pure_eq, AlgM.bind,
    ThetaOK, thetaOK_ite]
  refine ⟨fun _ o => ?_, fun _ => trivial⟩
  rcases o with _ | N2
  · trivial
  · simp only
    split <;> simp [ThetaOK]

theorem thetaOK_rejectDepthCode (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState) :
    ThetaOK (rejectDepthCode P d pos Qhat c) := by
  unfold rejectDepthCode
  split
  · trivial
  · simp [releaseM, bankOpM, AlgM.bind, ThetaOK, Option.forall, thetaOK_rejectTailCode]

theorem thetaOK_step4DepthCode (d : ℕ) (c : CState) (F : ℚ) : ThetaOK (step4DepthCode P d c F) := by
  unfold step4DepthCode
  split
  · trivial
  · simp [validateM, noteM, AlgM.bind, ThetaOK, FP.adaCert_forall, thetaOK_rejectDepthCode,
      theta_nonneg]

theorem thetaOK_step4LoopCode : ∀ (ds : List ℕ) (c : CState) (F : ℚ), ThetaOK (step4LoopCode P ds c F)
  | [], _, _ => trivial
  | d :: ds, c, F => by
    simp only [step4LoopCode]
    split_ifs
    · trivial
    · exact ThetaOK.bind (thetaOK_step4DepthCode P d c F) fun r => thetaOK_step4LoopCode ds r.1 r.2

theorem thetaOK_roundCode (c : CState) (i : ℕ) (Δ : ℤ) : ThetaOK (roundCode P c i Δ) := by
  rw [FP.roundCode_eq]
  split_ifs
  · trivial
  · show ThetaOK ((step1Code P c).bind (FP.fpTail1 P i Δ))
    refine ThetaOK.bind (thetaOK_step1Code P c) fun c1 => ?_
    unfold FP.fpTail1
    split_ifs
    · trivial
    · refine ThetaOK.bind (thetaOK_step2Code P i Δ c1) fun r2 => ?_
      unfold FP.fpTail2
      split_ifs
      · trivial
      · refine ThetaOK.bind (thetaOK_step3LoopCode P _ _ _) fun c3 => ?_
        unfold FP.fpTail3
        split_ifs
        · trivial
        · exact ThetaOK.bind (thetaOK_step4LoopCode P _ _ _) fun _ => trivial

theorem thetaOK_initCode : ThetaOK initCode := by
  have hshape : initCode = AlgM.fpInit (AlgM.bankNew 0 0 (AlgM.pure ⟨0, false, [], 0⟩)) := rfl
  rw [hshape]
  trivial

/-- **Every validation of the canonical interaction has a nonnegative radius.** -/
theorem thetaOK_fullCode (adv : StreamAdversary P.n) : ∀ t, ThetaOK (fullCode P adv t)
  | 0 => ThetaOK.bind thetaOK_initCode fun _ => trivial
  | t + 1 => ThetaOK.bind (thetaOK_fullCode adv t) fun co =>
      ThetaOK.bind (thetaOK_roundCode P co.1 _ _) fun _ => trivial

end Theta

end F2e2e.C.Closure
