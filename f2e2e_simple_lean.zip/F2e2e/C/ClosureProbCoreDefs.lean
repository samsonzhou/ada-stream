import F2e2e.C.ClosureEvents

/-!
# Theorem 6.4, probability layer (C-PROB): the sample-then-core program of one bank

The selected bank's ADA module, run in isolation by B's online core (Theorem 3.6 for the bank, partIII.tex L1277):
draw the ADA sample rows (`sampleBlocks` for the block sizes of `bankAda P`), take their seeds (`sOf`), then run the
core (`coreRun`: `adaInit`, then `T` online rounds) against a deterministic controller.

* `sOf P rows`: the seeds of the ADA rows in block order (`seedOfRow`, C-CLOSE's seed map);
* `coreQ P ctrl T`: the sample-then-core bit program.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.NormBank

/-- The sample seeds of the ADA rows (rows in block order). -/
def sOf (P : StreamParams) (rows : List (List Row)) : Fin (bankAda P).N → Seed P :=
  fun ℓ => seedOfRow P (rows.flatten.getD ℓ ⟨[], 0, 0⟩)

/-- The selected bank's ADA module in isolation: its sample, then B's online core for `T` rounds against the
deterministic controller `ctrl`. -/
def coreQ (P : StreamParams) (ctrl : CoreCtrl (Seed P)) (T : ℕ) : BitProg (List CoreOut) :=
  (sampleBlocks P (bankAda P).blockSizes).bind fun rows => coreRun (bankAda P) ctrl (sOf P rows) T

end F2e2e.C.Closure
