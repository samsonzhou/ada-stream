import F2e2e.C.ParamsGrids

/-!
# Theorem (C) parameters: the parameter numerics used in Part III §5

Pure parameter arithmetic stated and used in Part III Section 5 (`parts/partIII.tex`), collected here so that
the tree/precision proofs only cite them:

* eq. `R:eq:sec5-eta-H-small` (L759–761): `(8H+5)η < 2^{-16}`, `(64ℓ²+64ℓ+16)η ≤ 64(H+1)²η ≤ 2^{-14}` (`ℓ ≤ H`),
  and the companions `(8ℓ+5)²η ≤ 2^{-14}`, `(8ℓ + 2^{-11})η < 2^{-15}` (L744, L836), `8Hη < 2^{-16}`;
* eq. `R:eq:sec5-additive-drift-vs-Emin` (L764): `η³ν²/2^39 < 2^{-39}ην²`; `4h_step/η = η/2^18` (N24);
* Lemma 5.7/5.8 (L619–700): `√𝒰_{d,0} < 2V_d ≤ 2V_H < V` (squared: `𝒰_d < V²`), `(γ/4)√𝒰_* < γV` (squared:
  `𝒰_* < 16V²`), `𝒰_{0,0} ≥ 2W² ≥ 8 > η²/64`, the root-guard magnitudes `γη/(64√2) = 2^{H+13.5}ν > 2^{H+33}h_{g,unref}
  ≥ 2^34 h_g` and `γη/(240√2) > 2^{H+11.5}ν` (in squared form);
* Theorem 5.11 (L896–987): `2^14 B^{2H} h_g − 2^{-10} h_g > 2^14 h_g > 2h_g`, `B^{d+1} ≤ B^{H+1} < G`,
  `3B^H V_H + σ < V`, `√n U < W`, `k < log₂(256𝒰_* B^{2H}/(η²ν²)) ⇒ k + 12 < K_epoch`;
* Definition 5.2 ranges (N34): `B^H + e_C < C_max` (with `e_C ≤ 2^{-10}`), `√D_* V + 1 < Z_max`; `m < T`.
-/

namespace F2e2e

namespace StreamParams

open ParamsAux

/-! ## Smallness of `η` (eq. `R:eq:sec5-eta-H-small`) -/

theorem eta_lt_one (P : StreamParams) : P.eta < 1 := by
  unfold eta
  exact pow_lt_one₀ (by norm_num) (by norm_num) (by unfold eEta; omega)

/-- `64(H+1)²η ≤ ε₀/2^14 ≤ 2^{-14}` (eq. `R:eq:sec5-eta-H-small`). -/
theorem sixtyfour_H_add_one_sq_mul_eta_le (P : StreamParams) :
    64 * ((P.H : ℚ) + 1) ^ 2 * P.eta ≤ (1 / 2) ^ 14 := by
  have h := P.eta_le
  have he := P.eps0_le_one
  have hH0 : (0 : ℚ) < ((P.H : ℚ) + 1) ^ 2 := by positivity
  have h64 : (0 : ℚ) ≤ 64 * ((P.H : ℚ) + 1) ^ 2 := by positivity
  calc 64 * ((P.H : ℚ) + 1) ^ 2 * P.eta
      ≤ 64 * ((P.H : ℚ) + 1) ^ 2 * (P.eps0 / (2 ^ 20 * ((P.H : ℚ) + 1) ^ 2)) :=
        mul_le_mul_of_nonneg_left h h64
    _ = P.eps0 / 2 ^ 14 := by field_simp; ring
    _ ≤ 1 / 2 ^ 14 := by gcongr
    _ = (1 / 2) ^ 14 := by norm_num

/-- `(8H+5)η < 2^{-16}` (eq. `R:eq:sec5-eta-H-small`; the paper uses `ε < 1/10`, we only need `ε₀ ≤ 1`). -/
theorem eight_H_add_five_mul_eta_lt (P : StreamParams) :
    (8 * (P.H : ℚ) + 5) * P.eta < (1 / 2) ^ 16 := by
  have h := P.sixtyfour_H_add_one_sq_mul_eta_le
  have hH : (1 : ℚ) ≤ P.H := by exact_mod_cast P.one_le_H
  have he := P.eta_pos
  -- `(8H+5) ≤ 64(H+1)^2 / 32` since `32(8H+5) ≤ 64(H+1)^2 ⟺ 0 ≤ 64H^2 - 128H + 64 - 96`? use `H ≥ 1`
  have hpoly : 2 ^ 4 * (8 * (P.H : ℚ) + 5) ≤ 64 * ((P.H : ℚ) + 1) ^ 2 := by nlinarith
  have : 2 ^ 4 * ((8 * (P.H : ℚ) + 5) * P.eta) ≤ (1 / 2) ^ 14 := by
    calc 2 ^ 4 * ((8 * (P.H : ℚ) + 5) * P.eta) = (2 ^ 4 * (8 * (P.H : ℚ) + 5)) * P.eta := by ring
      _ ≤ 64 * ((P.H : ℚ) + 1) ^ 2 * P.eta := mul_le_mul_of_nonneg_right hpoly he.le
      _ ≤ (1 / 2) ^ 14 := h
  have h16 : ((1 : ℚ) / 2) ^ 14 = 2 ^ 4 * (1 / 2) ^ 18 := by norm_num
  have h18 : ((1 : ℚ) / 2) ^ 18 < (1 / 2) ^ 16 := by norm_num
  linarith

/-- `8Hη < 2^{-16}` (L836). -/
theorem eight_H_mul_eta_lt (P : StreamParams) : 8 * (P.H : ℚ) * P.eta < (1 / 2) ^ 16 := by
  have h := P.eight_H_add_five_mul_eta_lt
  have he := P.eta_pos
  nlinarith

/-- `(64ℓ² + 64ℓ + 16)η ≤ 64(H+1)²η ≤ 2^{-14}` for `ℓ ≤ H` (eq. `R:eq:sec5-eta-H-small`). -/
theorem ell_poly_mul_eta_le (P : StreamParams) {ℓ : ℕ} (hℓ : ℓ ≤ P.H) :
    (64 * (ℓ : ℚ) ^ 2 + 64 * ℓ + 16) * P.eta ≤ (1 / 2) ^ 14 := by
  have h := P.sixtyfour_H_add_one_sq_mul_eta_le
  have hℓ' : (ℓ : ℚ) ≤ P.H := by exact_mod_cast hℓ
  have hℓ0 : (0 : ℚ) ≤ ℓ := Nat.cast_nonneg _
  have he := P.eta_pos
  have hpoly : 64 * (ℓ : ℚ) ^ 2 + 64 * ℓ + 16 ≤ 64 * ((P.H : ℚ) + 1) ^ 2 := by nlinarith
  calc (64 * (ℓ : ℚ) ^ 2 + 64 * ℓ + 16) * P.eta ≤ 64 * ((P.H : ℚ) + 1) ^ 2 * P.eta :=
        mul_le_mul_of_nonneg_right hpoly he.le
    _ ≤ (1 / 2) ^ 14 := h

/-- `(8ℓ+5)²η ≤ 2^{-14}` for `ℓ ≤ H` (N17). -/
theorem eight_ell_add_five_sq_mul_eta_le (P : StreamParams) {ℓ : ℕ} (hℓ : ℓ ≤ P.H) :
    (8 * (ℓ : ℚ) + 5) ^ 2 * P.eta ≤ (1 / 2) ^ 14 := by
  have h := P.sixtyfour_H_add_one_sq_mul_eta_le
  have hℓ' : (ℓ : ℚ) ≤ P.H := by exact_mod_cast hℓ
  have hℓ0 : (0 : ℚ) ≤ ℓ := Nat.cast_nonneg _
  have he := P.eta_pos
  have hpoly : (8 * (ℓ : ℚ) + 5) ^ 2 ≤ 64 * ((P.H : ℚ) + 1) ^ 2 := by nlinarith
  calc (8 * (ℓ : ℚ) + 5) ^ 2 * P.eta ≤ 64 * ((P.H : ℚ) + 1) ^ 2 * P.eta :=
        mul_le_mul_of_nonneg_right hpoly he.le
    _ ≤ (1 / 2) ^ 14 := h

/-- `(8ℓ + 2^{-11})η < 2^{-15}` for `ℓ ≤ H` (eq. `R:eq:sec5-multiplicative-P-Qhat`, L744). -/
theorem eight_ell_add_mul_eta_lt (P : StreamParams) {ℓ : ℕ} (hℓ : ℓ ≤ P.H) :
    (8 * (ℓ : ℚ) + (1 / 2) ^ 11) * P.eta < (1 / 2) ^ 15 := by
  have h := P.eight_H_add_five_mul_eta_lt
  have hℓ' : (ℓ : ℚ) ≤ P.H := by exact_mod_cast hℓ
  have he := P.eta_pos
  have hpoly : 8 * (ℓ : ℚ) + (1 / 2) ^ 11 ≤ 8 * (P.H : ℚ) + 5 := by
    have : ((1 : ℚ) / 2) ^ 11 ≤ 5 := by norm_num
    linarith
  calc (8 * (ℓ : ℚ) + (1 / 2) ^ 11) * P.eta ≤ (8 * (P.H : ℚ) + 5) * P.eta :=
        mul_le_mul_of_nonneg_right hpoly he.le
    _ < (1 / 2) ^ 16 := h
    _ ≤ (1 / 2) ^ 15 := by norm_num

/-- `η³ν²/2^39 < 2^{-39}ην²` (eq. `R:eq:sec5-additive-drift-vs-Emin`). -/
theorem eta_cube_nu_sq_lt (P : StreamParams) :
    P.eta ^ 3 * P.nu ^ 2 / 2 ^ 39 < P.eta * P.nu ^ 2 / 2 ^ 39 := by
  have he := P.eta_pos
  have he1 := P.eta_lt_one
  have hn := P.nu_pos
  have h2 : P.eta ^ 2 < 1 := pow_lt_one₀ he.le he1 (by norm_num)
  have hpos : 0 < P.eta * P.nu ^ 2 := mul_pos he (pow_pos hn 2)
  have : P.eta ^ 3 * P.nu ^ 2 < P.eta * P.nu ^ 2 := by
    calc P.eta ^ 3 * P.nu ^ 2 = P.eta ^ 2 * (P.eta * P.nu ^ 2) := by ring
      _ < 1 * (P.eta * P.nu ^ 2) := mul_lt_mul_of_pos_right h2 hpos
      _ = P.eta * P.nu ^ 2 := one_mul _
  exact div_lt_div_of_pos_right this (by norm_num)

/-- `4h_step/η = η/2^18` (N24). -/
theorem four_mul_hstep_div_eta (P : StreamParams) : 4 * P.hstep / P.eta = P.eta / 2 ^ 18 := by
  rw [hstep_eq]
  have he : P.eta ≠ 0 := P.eta_pos.ne'
  field_simp
  ring

/-! ## Envelopes and vector bounds (Lemmas 5.7–5.8, Theorem 5.11) -/

/-- `2V_d ≤ 2V_H < V` for `d ≤ H`. -/
theorem two_mul_Vd_lt_V (P : StreamParams) {d : ℕ} (hd : d ≤ P.H) : 2 * P.Vd d < P.V := by
  have h1 : P.Vd d ≤ P.Vd P.H := P.Vd_mono hd
  have h2 : 1 ≤ P.B ^ (P.H + 1) := Nat.one_le_pow _ _ P.B_pos
  have h3 : 8 * P.Vd P.H ≤ 8 * P.B ^ (P.H + 1) * P.Vd P.H := by
    calc 8 * P.Vd P.H = 8 * 1 * P.Vd P.H := by ring
      _ ≤ 8 * P.B ^ (P.H + 1) * P.Vd P.H :=
          Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ h2)
  unfold V
  omega

/-- `√𝒰_{d,0} < 2V_d < V`, squared: `𝒰_d < V²` for `d ≤ H` (Lemma 5.7, L634). -/
theorem Ud_lt_V_sq (P : StreamParams) {d : ℕ} (hd : d ≤ P.H) : P.Ud d < P.V ^ 2 := by
  have h1 := P.Ud_lt_four_mul_Vd_sq d
  have h2 := P.two_mul_Vd_lt_V hd
  have h3 : (2 * P.Vd d) ^ 2 < P.V ^ 2 := Nat.pow_lt_pow_left h2 (by norm_num)
  calc P.Ud d < 4 * P.Vd d ^ 2 := h1
    _ = (2 * P.Vd d) ^ 2 := by ring
    _ < P.V ^ 2 := h3

/-- `(γ/4)√𝒰_* < γV`, squared: `𝒰_* < 16V²` (Lemma 5.7, L619). -/
theorem Ustar_lt_sixteen_mul_V_sq (P : StreamParams) : P.Ustar < 16 * P.V ^ 2 := by
  have h := P.Ud_lt_V_sq (d := P.H - 1) (by omega)
  rw [Ustar_eq_Ud]
  omega

/-- `𝒰_{0,0} ≥ 2V_0² = 2W² ≥ 8 > η²/64` (Lemma 5.8, L684), for `n, U ≥ 1`. -/
theorem eta_sq_div_lt_Ud_zero {P : StreamParams} (hn : 1 ≤ P.n) (hU : 1 ≤ P.U) :
    P.eta ^ 2 / 64 < P.Ud 0 := by
  have hW : 2 ≤ P.W := by unfold W; have := Nat.mul_pos hn hU; omega
  have h1 : 2 * P.Vd 0 ^ 2 ≤ P.Ud 0 := P.two_mul_Vd_sq_le_Ud 0
  have h8 : 8 ≤ P.Ud 0 := by
    rw [Vd_zero] at h1
    have : 4 ≤ P.W ^ 2 := by nlinarith
    omega
  have h8' : (8 : ℚ) ≤ P.Ud 0 := by exact_mod_cast h8
  have he := P.eta_le_one
  have he0 := P.eta_pos
  have : P.eta ^ 2 ≤ 1 := pow_le_one₀ he0.le he
  linarith

/-- `B > 1` (indeed `log₂ B = 4 + log₂(1/γ) ≥ 5`). -/
theorem one_lt_B (P : StreamParams) : 1 < P.B := by
  unfold B logB
  have := P.one_le_eGamma
  calc 1 < 2 ^ 1 := by norm_num
    _ ≤ 2 ^ (4 + P.eGamma) := Nat.pow_le_pow_right (by norm_num) (by omega)

/-- `B^{d+1} ≤ B^{H+1} < B^{H+2} = G` for `d ≤ H` (eq. `R:eq:compound-product-G`). -/
theorem B_pow_succ_lt_G (P : StreamParams) {d : ℕ} (hd : d ≤ P.H) : P.B ^ (d + 1) < P.G := by
  unfold G
  calc P.B ^ (d + 1) ≤ P.B ^ (P.H + 1) := Nat.pow_le_pow_right P.B_pos (by omega)
    _ < P.B ^ (P.H + 2) := Nat.pow_lt_pow_right P.one_lt_B (by omega)

/-- `3B^H V_H + σ < 8B^{H+1}V_H + 2 = V` (Theorem 5.11(2b), L985). -/
theorem three_B_pow_H_mul_VH_add_sigma_lt_V (P : StreamParams) :
    3 * (P.B : ℚ) ^ P.H * P.Vd P.H + P.sigma < P.V := by
  have hB : (1 : ℚ) ≤ P.B := Nat.one_le_cast.mpr P.B_pos
  have hBH : (0 : ℚ) ≤ (P.B : ℚ) ^ P.H := pow_nonneg (Nat.cast_nonneg _) _
  have hVH : (0 : ℚ) ≤ P.Vd P.H := Nat.cast_nonneg _
  have hs := P.sigma_le_one
  have hV : (P.V : ℚ) = 8 * (P.B : ℚ) ^ (P.H + 1) * P.Vd P.H + 2 := by unfold V; push_cast; ring
  have h3 : 3 * (P.B : ℚ) ^ P.H * P.Vd P.H ≤ 8 * (P.B : ℚ) ^ (P.H + 1) * P.Vd P.H := by
    have : (P.B : ℚ) ^ P.H ≤ (P.B : ℚ) ^ (P.H + 1) := by
      rw [pow_succ]; nlinarith
    nlinarith
  rw [hV]
  linarith

/-- `√n U < nU + 1 = W` (Theorem 5.11(2b), L981). -/
theorem sqrt_n_mul_U_lt_W (P : StreamParams) : Real.sqrt P.n * P.U < P.W := by
  have hn : (0 : ℝ) ≤ P.n := Nat.cast_nonneg _
  have hU : (0 : ℝ) ≤ P.U := Nat.cast_nonneg _
  have hs : 0 ≤ Real.sqrt P.n := Real.sqrt_nonneg _
  have hss : Real.sqrt P.n ^ 2 = P.n := Real.sq_sqrt hn
  have hW : (P.W : ℝ) = P.n * P.U + 1 := by unfold W; push_cast; ring
  rw [hW]
  have hnn : (P.n : ℝ) ≤ (P.n : ℝ) ^ 2 := by
    rcases Nat.eq_zero_or_pos P.n with h0 | hpos
    · rw [h0]; norm_num
    · have : (1 : ℝ) ≤ P.n := by exact_mod_cast hpos
      nlinarith
  refine lt_of_pow_lt_pow_left₀ 2 (by positivity) ?_
  rw [mul_pow, hss]
  nlinarith [sq_nonneg ((P.n : ℝ) * P.U)]

/-! ## Root-guard magnitudes (Lemma 5.8, L660–698) -/

/-- `γη = 2^{H+20} ν`. -/
theorem gamma_mul_eta_eq (P : StreamParams) : P.gamma * P.eta = 2 ^ (P.H + 20) * P.nu := by
  rw [nu_eq]
  have h := half_pow_mul_two_pow (K := ℚ) (P.H + 20)
  calc P.gamma * P.eta = P.gamma * P.eta * ((1 / 2) ^ (P.H + 20) * 2 ^ (P.H + 20)) := by
        rw [h, mul_one]
    _ = 2 ^ (P.H + 20) * (P.gamma * P.eta * (1 / 2) ^ (P.H + 20)) := by ring

/-- `γη/(64√2) = 2^{H+13.5}ν > 2^{H+33} h_{g,unrefined}` (L660, L694), squared:
`(2^{H+33} h_{g,unrefined})² < 2^{2H+27} ν²`. -/
theorem root_guard_gt_sq (P : StreamParams) :
    (2 ^ (P.H + 33) * P.hgUnref) ^ 2 < 2 ^ (2 * P.H + 27) * P.nu ^ 2 := by
  rw [hgUnref_eq]
  have hg := P.gamma_pos
  have he := P.eta_pos
  have hn := P.nu_pos
  have hg1 : P.gamma ≤ 1 := half_pow_le_one _
  have he1 := P.eta_le_one
  have hge : (P.gamma * P.eta) ^ 2 ≤ 1 := pow_le_one₀ (mul_pos hg he).le (mul_le_one₀ hg1 he.le he1)
  have e : (2 ^ (P.H + 33) * (P.gamma * P.eta * P.nu / 2 ^ 20)) ^ 2 =
      2 ^ (2 * P.H + 26) * ((P.gamma * P.eta) ^ 2 * P.nu ^ 2) := by
    have h2 : (2 : ℚ) ≠ 0 := by norm_num
    generalize (2 : ℚ) = x at h2 ⊢
    field_simp
    ring
  rw [e]
  have h26 : (0 : ℚ) < 2 ^ (2 * P.H + 26) := by positivity
  have hn2 : (0 : ℚ) < P.nu ^ 2 := pow_pos hn 2
  calc 2 ^ (2 * P.H + 26) * ((P.gamma * P.eta) ^ 2 * P.nu ^ 2)
      ≤ 2 ^ (2 * P.H + 26) * (1 * P.nu ^ 2) := by
        apply mul_le_mul_of_nonneg_left _ h26.le
        exact mul_le_mul_of_nonneg_right hge hn2.le
    _ < 2 ^ (2 * P.H + 26) * 2 * P.nu ^ 2 := by nlinarith
    _ = 2 ^ (2 * P.H + 27) * P.nu ^ 2 := by ring

/-- `2^{H+33} h_{g,unrefined} = 2^{H+33} B^{2H} h_g ≥ 2^34 h_g` (L660). -/
theorem two_pow_34_mul_hg_le (P : StreamParams) :
    2 ^ 34 * P.hg ≤ 2 ^ (P.H + 33) * P.hgUnref := by
  rw [← P.hg_mul_B_pow]
  have hB : (1 : ℚ) ≤ (P.B : ℚ) ^ (2 * P.H) := one_le_pow₀ (Nat.one_le_cast.mpr P.B_pos)
  have h34 : (2 : ℚ) ^ 34 ≤ 2 ^ (P.H + 33) :=
    pow_le_pow_right₀ (by norm_num) (by have := P.one_le_H; omega)
  have hg := P.hg_pos
  calc (2 : ℚ) ^ 34 * P.hg = 2 ^ 34 * P.hg * 1 := (mul_one _).symm
    _ ≤ 2 ^ (P.H + 33) * P.hg * (P.B : ℚ) ^ (2 * P.H) := by
        apply mul_le_mul _ hB (by norm_num) (by positivity)
        exact mul_le_mul_of_nonneg_right h34 hg.le
    _ = 2 ^ (P.H + 33) * (P.hg * (P.B : ℚ) ^ (2 * P.H)) := by ring

/-- `γη/(240√2) > 2^{H+11.5} ν` (L664, L696: `log₂(240√2) < 8.5`), squared:
`2^{2H+23} ν² < (γη/240)²/2`. -/
theorem root_guard_floor_sq (P : StreamParams) :
    2 ^ (2 * P.H + 23) * P.nu ^ 2 < (P.gamma * P.eta / 240) ^ 2 / 2 := by
  rw [gamma_mul_eta_eq]
  have hn := P.nu_pos
  have hn2 : (0 : ℚ) < P.nu ^ 2 := pow_pos hn 2
  have e : (2 ^ (P.H + 20) * P.nu / 240) ^ 2 / 2 = 2 ^ (2 * P.H + 23) * P.nu ^ 2 * (2 ^ 17 / 115200) := by
    have : (2 : ℚ) ^ (2 * P.H + 23) * 2 ^ 17 = (2 ^ (P.H + 20)) ^ 2 := by
      rw [← pow_add, ← pow_mul]; congr 1; omega
    field_simp
    rw [← this]
    ring
  rw [e]
  have hpos : (0 : ℚ) < 2 ^ (2 * P.H + 23) * P.nu ^ 2 := by positivity
  have h1 : (1 : ℚ) < 2 ^ 17 / 115200 := by norm_num
  nlinarith

/-! ## First-correction margin and Definition 5.2 ranges -/

/-- `2^14 B^{2H} h_g − 2^{-10} h_g > 2^14 h_g > 2h_g` (eq. `R:eq:first-correction-non-omission`, L913). -/
theorem first_correction_margin (P : StreamParams) :
    2 ^ 14 * P.hg < 2 ^ 14 * (P.B : ℚ) ^ (2 * P.H) * P.hg - (1 / 2) ^ 10 * P.hg ∧
      2 * P.hg < 2 ^ 14 * P.hg := by
  have hg := P.hg_pos
  have hB2 : (2 : ℚ) ≤ (P.B : ℚ) ^ (2 * P.H) := by
    have hB : (2 : ℚ) ≤ P.B := by exact_mod_cast P.one_lt_B
    calc (2 : ℚ) = 2 ^ 1 := by norm_num
      _ ≤ (P.B : ℚ) ^ 1 := by gcongr
      _ ≤ (P.B : ℚ) ^ (2 * P.H) :=
          pow_le_pow_right₀ (by linarith) (by have := P.one_le_H; omega)
  constructor
  · have : (1 / 2 : ℚ) ^ 10 * P.hg < 2 ^ 14 * P.hg := by
      apply mul_lt_mul_of_pos_right _ hg; norm_num
    nlinarith
  · nlinarith

/-- `e_C = ην B^{-2H}/(2^30 V) ≤ 2^{-10}` (in fact `≤ 2^{-30}`). -/
theorem eC_le (P : StreamParams) : P.eC ≤ (1 / 2) ^ 10 := by
  have hγ : P.gamma ≠ 0 := P.gamma_pos.ne'
  have hV : (1 : ℚ) ≤ P.V := Nat.one_le_cast.mpr P.one_le_V
  have hV0 : (P.V : ℚ) ≠ 0 := by linarith
  have hB : (1 : ℚ) ≤ P.B := Nat.one_le_cast.mpr P.B_pos
  have hBinv : (1 / (P.B : ℚ)) ^ (2 * P.H) ≤ 1 :=
    pow_le_one₀ (div_nonneg zero_le_one (Nat.cast_nonneg _))
      (by rw [div_le_one₀ (by linarith)]; exact hB)
  have hBinv0 : (0 : ℚ) ≤ (1 / (P.B : ℚ)) ^ (2 * P.H) :=
    pow_nonneg (div_nonneg zero_le_one (Nat.cast_nonneg _)) _
  have e : P.eC = P.eta * P.nu * (1 / (P.B : ℚ)) ^ (2 * P.H) / (2 ^ 30 * P.V) := by
    unfold eC
    rw [hg_eq]
    field_simp
  rw [e]
  have he := P.eta_le_one
  have he0 := P.eta_pos
  have hn := P.nu_lt_one.le
  have hn0 := P.nu_pos
  have hnum : P.eta * P.nu * (1 / (P.B : ℚ)) ^ (2 * P.H) ≤ 1 :=
    mul_le_one₀ (mul_le_one₀ he hn0.le hn) hBinv0 hBinv
  have hden : (2 : ℚ) ^ 30 ≤ 2 ^ 30 * P.V := by nlinarith
  calc P.eta * P.nu * (1 / (P.B : ℚ)) ^ (2 * P.H) / (2 ^ 30 * P.V) ≤ 1 / (2 ^ 30 * P.V) :=
        div_le_div_of_nonneg_right hnum (by positivity)
    _ ≤ 1 / 2 ^ 30 := div_le_div_of_nonneg_left (by norm_num) (by norm_num) hden
    _ ≤ (1 / 2) ^ 10 := by norm_num

/-- `C_max ≥ 8(B^H + 1) > B^H + e_C` (Definition 5.2, N34). -/
theorem B_pow_H_add_eC_lt_Cmax (P : StreamParams) : (P.B : ℚ) ^ P.H + P.eC < P.Cmax := by
  have h := P.le_Cmax
  have h' : (8 * ((P.B : ℚ) ^ P.H + 1)) ≤ (P.Cmax : ℚ) := by exact_mod_cast h
  have he := P.eC_le
  have hBH : (0 : ℚ) ≤ (P.B : ℚ) ^ P.H := pow_nonneg (Nat.cast_nonneg _) _
  have : ((1 : ℚ) / 2) ^ 10 ≤ 1 := by norm_num
  linarith

/-- `Z_max ≥ 8D_*(V+1) > √D_* V + 1` (Definition 5.2, N34). -/
theorem sqrt_Dstar_mul_V_add_one_lt_Zmax (P : StreamParams) :
    Real.sqrt P.Dstar * P.V + 1 < P.Zmax := by
  have h := P.le_Zmax
  have h' : (8 * (P.Dstar : ℝ) * ((P.V : ℝ) + 1)) ≤ (P.Zmax : ℝ) := by exact_mod_cast h
  have hD : (1 : ℝ) ≤ P.Dstar := Nat.one_le_cast.mpr P.Dstar_pos
  have hV : (0 : ℝ) ≤ P.V := Nat.cast_nonneg _
  have hDD : (P.Dstar : ℝ) ≤ (P.Dstar : ℝ) ^ 2 := by
    rw [sq]; exact le_mul_of_one_le_left (by linarith) hD
  have hs : Real.sqrt P.Dstar ≤ P.Dstar := by
    calc Real.sqrt P.Dstar ≤ Real.sqrt ((P.Dstar : ℝ) ^ 2) := Real.sqrt_le_sqrt hDD
      _ = P.Dstar := Real.sqrt_sq (by linarith)
  have h1 : Real.sqrt P.Dstar * P.V ≤ P.Dstar * P.V := mul_le_mul_of_nonneg_right hs hV
  have h2 : (0 : ℝ) ≤ (P.Dstar : ℝ) * P.V := mul_nonneg (by linarith) hV
  have h3 : 8 * (P.Dstar : ℝ) * ((P.V : ℝ) + 1) = 8 * ((P.Dstar : ℝ) * P.V) + 8 * P.Dstar := by ring
  linarith

/-- `m < T`. -/
theorem m_lt_T (P : StreamParams) : P.m < P.T := by
  have h := P.m_mul_H_add_one_lt_T
  have : P.m ≤ P.m * (P.H + 1) := Nat.le_mul_of_pos_right _ (Nat.succ_pos _)
  omega

/-! ## The epoch cap (Theorem 5.11(2c), eq. `R:eq:epoch-halving-termination`) -/

/-- If `2^{-k} 𝒰_* > η²ν²/(256 B^{2H})` then `k < log₂(256 𝒰_* B^{2H}/(η²ν²)) = K_epoch − 12 < K_epoch`. -/
theorem add_twelve_lt_Kepoch_of {P : StreamParams} {k : ℕ}
    (h : P.eta ^ 2 * P.nu ^ 2 / (256 * (P.B : ℚ) ^ (2 * P.H)) < (P.Ustar : ℚ) / 2 ^ k) :
    k + 12 < P.Kepoch := by
  have hK := P.two_pow_Kepoch
  have he := P.eta_pos
  have hn := P.nu_pos
  have hen : (0 : ℚ) < P.eta ^ 2 * P.nu ^ 2 := mul_pos (pow_pos he 2) (pow_pos hn 2)
  have hB : (0 : ℚ) < (P.B : ℚ) ^ (2 * P.H) := pow_pos (Nat.cast_pos.mpr P.B_pos) _
  have h2k : (0 : ℚ) < 2 ^ k := by positivity
  rw [div_lt_div_iff₀ (mul_pos (by norm_num) hB) h2k] at h
  -- `η²ν² 2^k < 256 𝒰_* B^{2H}`
  have hK' : (2 : ℚ) ^ P.Kepoch * (P.eta ^ 2 * P.nu ^ 2) = 2 ^ 20 * P.Ustar * (P.B : ℚ) ^ (2 * P.H) := by
    rw [hK]; field_simp
  have : (2 : ℚ) ^ (k + 12) * (P.eta ^ 2 * P.nu ^ 2) < 2 ^ P.Kepoch * (P.eta ^ 2 * P.nu ^ 2) := by
    rw [hK', pow_add]
    nlinarith
  have hlt : (2 : ℚ) ^ (k + 12) < 2 ^ P.Kepoch := lt_of_mul_lt_mul_right this hen.le
  exact (pow_lt_pow_iff_right₀ (by norm_num : (1 : ℚ) < 2)).1 hlt

end StreamParams

end F2e2e
