import F2e2e.C.ClosureProbOracle
import F2e2e.C.ClosureProbBirth

/-!
# Theorem 6.4, probability layer (C-PROB): shape and validity of the oracle-split interpreter

Facts about C-PROB's interpreter `runX` (`F2e2e/C/ClosureProbOracle.lean`) needed by `handle_count`
(`F2e2e/C/ClosureProbHandle.lean`):

* `phase3_runX`, `phase1_runX`: after the selected bank's birth (flag `true`) the oracle program has only other
  bits and calls (`Phase3`); before it (flag `false`) only other bits and at most one birth (`Phase1`: the birth
  reads the sample, the reserved coarse groups (other bits), then the initialization, then continues in `Phase3`);
* `validCalls_runX`: every call node carries a valid core request (grid indices `≤ 2^{qA}`; interval endpoints
  `(1 − θ)/L ≤ (1 + θ)/L` since `θ ≥ 0` on every path, C-FP's `ThetaOK`);
* `birthOnce_of_birthsOK`: C-FP's `BirthsOK` (births at most once, with a postcondition) implies C-PROB's
  `BirthOnce`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

namespace ShapeAux

theorem phase3_lift {Q α β : Type} {k : β → OProg Q α} (hk : ∀ b, Phase3 (k b)) :
    ∀ q : BitProg β, Phase3 (OProg.lift q k)
  | BitProg.pure b => hk b
  | BitProg.bit f => Phase3.bit _ fun x => phase3_lift hk (f x)

theorem phase2_lift {Q α β : Type} {k : β → OProg Q α} (hk : ∀ b, Phase2 (k b)) :
    ∀ q : BitProg β, Phase2 (OProg.lift q k)
  | BitProg.pure b => hk b
  | BitProg.bit f => Phase2.bit _ fun x => phase2_lift hk (f x)

theorem phase1_lift {Q α β : Type} {k : β → OProg Q α} (hk : ∀ b, Phase1 (k b)) :
    ∀ q : BitProg β, Phase1 (OProg.lift q k)
  | BitProg.pure b => hk b
  | BitProg.bit f => Phase1.bit _ fun x => phase1_lift hk (f x)

theorem validCalls_lift (A : AdaParams) {U α β : Type} {k : β → OProg (CoreReq U) α}
    (hk : ∀ b, ValidCalls A (k b)) : ∀ q : BitProg β, ValidCalls A (OProg.lift q k)
  | BitProg.pure b => hk b
  | BitProg.bit f => ValidCalls.bit _ fun x => validCalls_lift A hk (f x)

/-- The grid index of a query value is at most `2^{qA}`. -/
theorem queryIdx_le' (qA L : ℕ) (c z : ℚ) : queryIdx qA L c z ≤ 2 ^ qA := by
  simp only [queryIdx]
  split_ifs with h
  · exact le_refl _
  · have h := not_le.mp h
    have h2 : roundMant qA (z ^ 2 / ((L : ℚ) * c)) ≤ 2 ^ qA := by
      unfold roundMant
      rw [Int.floor_le_iff]
      push_cast
      have : (0 : ℚ) < 2 ^ qA := by positivity
      nlinarith
    exact Int.toNat_le.mpr (show roundMant qA (z ^ 2 / ((L : ℚ) * c)) ≤ ((2 ^ qA : ℕ) : ℤ) by
      push_cast; exact h2)

end ShapeAux

open ShapeAux

/-- After the selected bank's birth, the oracle program has only other bits and calls. -/
theorem phase3_runX (P : StreamParams) (lab : BankLabel) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost), Phase3 (runX P lab true p o g) := by
  intro p
  induction p with
  | pure a => intro o g; exact Phase3.pure _
  | fpInit k ih =>
    intro o g
    simp only [runX]
    exact phase3_lift (fun r => ih _ _) _
  | fpStep i Δ k ih =>
    intro o g
    simp only [runX]
    exact ih _ _ _
  | bankNew tr d k ih =>
    intro o g
    simp only [runX]
    split
    · rename_i h
      simp at h
    · exact phase3_lift (fun B => ih _ _) _
  | bankRetain n k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankOp idx op k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankOpFrom idx op k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankValidate idx S θ k ih =>
    intro o g
    simp only [runX]
    split
    · exact ih _ _ _
    · split
      · exact Phase3.call _ _ fun out => ih _ _ _
      · exact phase3_lift (fun r => ih _ _ _) _
  | bankRelease idx mode k ih =>
    intro o g
    simp only [runX]
    split
    · exact ih _ _ _
    · split
      · split
        · exact ih _ _ _
        · exact Phase3.call _ _ fun out => ih _ _ _
      · exact phase3_lift (fun r => ih _ _ _) _
  | note ev k ih =>
    intro o g
    simp only [runX]
    exact ih _ _

/-- Before the selected bank's birth, the oracle program has only other bits and at most one birth. -/
theorem phase1_runX (P : StreamParams) (lab : BankLabel) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost), Phase1 (runX P lab false p o g) := by
  intro p
  induction p with
  | pure a => intro o g; exact Phase1.pure _
  | fpInit k ih =>
    intro o g
    simp only [runX]
    exact phase1_lift (fun r => ih _ _) _
  | fpStep i Δ k ih =>
    intro o g
    simp only [runX]
    exact ih _ _ _
  | bankNew tr d k ih =>
    intro o g
    simp only [runX]
    split
    · exact Phase1.sample _ (phase2_lift (fun c => Phase2.init _ (phase3_runX P lab k _ _)) _)
    · exact phase1_lift (fun B => ih _ _) _
  | bankRetain n k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankOp idx op k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankOpFrom idx op k ih =>
    intro o g
    simp only [runX]
    exact ih _ _
  | bankValidate idx S θ k ih =>
    intro o g
    simp only [runX]
    split
    · exact ih _ _ _
    · split
      · rename_i h
        simp at h
      · exact phase1_lift (fun r => ih _ _ _) _
  | bankRelease idx mode k ih =>
    intro o g
    simp only [runX]
    split
    · exact ih _ _ _
    · split
      · rename_i h
        simp at h
      · exact phase1_lift (fun r => ih _ _ _) _
  | note ev k ih =>
    intro o g
    simp only [runX]
    exact ih _ _

/-- Every call node of the oracle program carries a valid core request. -/
theorem validCalls_runX (P : StreamParams) (lab : BankLabel) {α : Type} :
    ∀ (p : AlgM α) (b : Bool) (o : OState) (g : Ghost), ThetaOK p →
      ValidCalls (bankAda P) (runX P lab b p o g) := by
  intro p
  induction p with
  | pure a => intro b o g _; exact ValidCalls.pure _
  | fpInit k ih =>
    intro b o g hθ
    simp only [runX]
    exact validCalls_lift _ (fun r => ih _ _ _ hθ) _
  | fpStep i Δ k ih =>
    intro b o g hθ
    simp only [runX]
    exact ih _ _ _ _ (hθ _)
  | bankNew tr d k ih =>
    intro b o g hθ
    simp only [runX]
    split
    · exact ValidCalls.sample _ (validCalls_lift _ (fun c => ValidCalls.init _ (ih _ _ _ hθ)) _)
    · exact validCalls_lift _ (fun B => ih _ _ _ hθ) _
  | bankRetain n k ih =>
    intro b o g hθ
    simp only [runX]
    exact ih _ _ _ hθ
  | bankOp idx op k ih =>
    intro b o g hθ
    simp only [runX]
    exact ih _ _ _ hθ
  | bankOpFrom idx op k ih =>
    intro b o g hθ
    simp only [runX]
    exact ih _ _ _ hθ
  | bankValidate idx S θ k ih =>
    intro b o g hθ
    obtain ⟨hθ0, hk⟩ := hθ
    simp only [runX]
    split
    · exact ih _ _ _ _ (hk _)
    · split
      · refine ValidCalls.call _ _ ⟨fun x => queryIdx_le' _ _ _ _, fun _ => ?_⟩
          fun out => ih _ _ _ _ (hk _)
        show (1 - θ) / (P.L : ℚ) ≤ (1 + θ) / (P.L : ℚ)
        exact div_le_div_of_nonneg_right (by linarith) (Nat.cast_nonneg _)
      · exact validCalls_lift _ (fun r => ih _ _ _ _ (hk _)) _
  | bankRelease idx mode k ih =>
    intro b o g hθ
    simp only [runX]
    split
    · exact ih _ _ _ _ (hθ _)
    · split
      · split
        · exact ih _ _ _ _ (hθ _)
        · refine ValidCalls.call _ _ ⟨fun x => queryIdx_le' _ _ _ _, fun h => ?_⟩
            fun out => ih _ _ _ _ (hθ _)
          exact absurd h (by simp [callReq])
      · exact validCalls_lift _ (fun r => ih _ _ _ _ (hθ _)) _
  | note ev k ih =>
    intro b o g hθ
    simp only [runX]
    exact ih _ _ _ hθ

/-- C-FP's `BirthsOK` implies C-PROB's `BirthOnce`. -/
theorem birthOnce_of_birthsOK (lab : BankLabel) {α : Type} :
    ∀ (p : AlgM α) (f : Bool) (Q : α → Bool → Prop), BirthsOK lab f p Q → BirthOnce lab f p := by
  intro p
  induction p with
  | pure a => intro f Q _; trivial
  | fpInit k ih => intro f Q h; exact ih f Q h
  | fpStep i Δ k ih => intro f Q h; exact fun z => ih z f Q (h z)
  | bankNew tr d k ih =>
    intro f Q h
    have h' : if (tr, d) = lab then f = false ∧ BirthsOK lab true k Q else BirthsOK lab f k Q := h
    show if (tr, d) = lab then f = false ∧ BirthOnce lab true k else BirthOnce lab f k
    split_ifs with hl
    · rw [if_pos hl] at h'
      exact ⟨h'.1, ih true Q h'.2⟩
    · rw [if_neg hl] at h'
      exact ih f Q h'
  | bankRetain n k ih => intro f Q h; exact ih f Q h
  | bankOp idx op k ih => intro f Q h; exact ih f Q h
  | bankOpFrom idx op k ih => intro f Q h; exact ih f Q h
  | bankValidate idx S θ k ih => intro f Q h; exact fun c => ih c f Q (h c)
  | bankRelease idx mode k ih => intro f Q h; exact fun r => ih r f Q (h r)
  | note ev k ih => intro f Q h; exact ih f Q h

end F2e2e.C.Closure
