import F2e2e.C.Alg.AlgMCode
import F2e2e.C.Alg.Facts
import F2e2e.C.Top.AlgInstance
import F2e2e.C.FingerprintRun

/-!
# The zero fingerprint of the Theorem C algorithm as an abstract `FpRound`

Paper: `parts/partII.tex` Algorithm `R:alg:zero-fingerprint` (L216–231) and Lemma
`R:lem:zero-fingerprint` (L233–286).

Instantiation of the generic coupling (`F2e2e/C/FingerprintCoupling.lean`,
`F2e2e/C/FingerprintCount.lean`, `F2e2e/C/FingerprintRun.lean`) for C-ALG's algorithm `theAlg`,
through its presentation as controller code over oracle calls (`F2e2e/C/Alg/AlgM.lean`,
`F2e2e/C/Alg/AlgMCode.lean`; `algStep_eq_interp`):

* `runOzf P zf`: the interpreter `runO` in which the answer of the fingerprint test `fpStep i Δ` is
  `zf o i Δ` (the registers are updated exactly as by `runO`); `runO_eq_runOzf`: the real
  interpreter answers with the real test `realZf`;
* `runOzf_banks`: with a constant test answer, the output and the final banks depend only on the
  initial banks, not on the fingerprint registers (the registers are never read except through the
  test answer);
* `NoFp`: programs without fingerprint calls; Steps 1, 3, 4 (`step1Code`, `step3Code`, `step4Code`)
  are such programs, so they keep the registers (`runOzf_noFp_regs`) and ignore the test answers
  (`runOzf_noFp_indep`);
* `roundCode_regs`, `roundCode_zf_congr`: the only fingerprint call of a round is Step 2's
  `fpStep (i+1) Δ`, made with the registers of the state before the round;
* `fpRoundAlg P : FpRound P.n P.q theAlg.State`; `theAlg_init_eq`, `theAlg_step_eq` (the canonical
  run of `theAlg` is the abstract real run);
* `card_falseZeroRun_theAlg_le`: the failure count `2^{(m+1) tapeLen} (m n/q + 2^{-seedTrials})`;
* `theAlg_run_fp_inv`, `fpBitOf_theAlg_run`: the deterministic invariant (part (1)) on the
  canonical run.
-/

namespace F2e2e.C.FP

open F2e2e.C.Alg F2e2e.C.Top F2e2e.Discrete F2e2e.B
open scoped ENNReal

/-! ### Bit-program helpers -/

theorem BPAll.pure {α : Type} {Q : α → Prop} {a : α} (h : Q a) : BPAll (BitProg.pure a) Q := h

theorem BPAll.mono {α : Type} {Q R : α → Prop} (h : ∀ a, Q a → R a) :
    ∀ {p : BitProg α}, BPAll p Q → BPAll p R
  | BitProg.pure a, hp => h a hp
  | BitProg.bit _, hp => fun b => BPAll.mono h (hp b)

theorem BPAll.true {α : Type} : ∀ p : BitProg α, BPAll p (fun _ => True)
  | BitProg.pure _ => trivial
  | BitProg.bit k => fun b => BPAll.true (k b)

theorem BPAll.bind {α β : Type} {R : α → Prop} {Q : β → Prop} {f : α → BitProg β}
    (hf : ∀ a, R a → BPAll (f a) Q) : ∀ {p : BitProg α}, BPAll p R → BPAll (p.bind f) Q
  | BitProg.pure a, hp => hf a hp
  | BitProg.bit _, hp => fun b => BPAll.bind hf (hp b)

/-- Two continuations agreeing on every possible output give the same program. -/
theorem bind_congr_of_BPAll {α β : Type} {R : α → Prop} {f g : α → BitProg β}
    (hfg : ∀ a, R a → f a = g a) : ∀ {p : BitProg α}, BPAll p R → p.bind f = p.bind g
  | BitProg.pure a, hp => hfg a hp
  | BitProg.bit k, hp => by
    show BitProg.bit (fun b => (k b).bind f) = BitProg.bit (fun b => (k b).bind g)
    congr 1
    funext b
    exact bind_congr_of_BPAll hfg (hp b)

theorem bp_map_bind {α β γ : Type} (g : β → γ) (f : α → BitProg β) (p : BitProg α) :
    (p.bind f).map g = p.bind (fun a => (f a).map g) :=
  bp_bind_assoc f _ p

/-! ### The interpreter with a given fingerprint-test answer -/

/-- The interpreter `runO` with the answer of the fingerprint test `fpStep i Δ` given by
`zf o i Δ` (`o` the oracle state before the call); the registers are updated as by `runO`. -/
def runOzf (P : StreamParams) (zf : OState → ℕ → ℤ → Bool) {α : Type} :
    AlgM α → OState → BitProg (α × OState)
  | AlgM.pure a, o => BitProg.pure (a, o)
  | AlgM.fpInit k, o =>
    (fpSeedProg P).bind fun r => runOzf P zf k { o with fpSeed := r, fpVal := 0 }
  | AlgM.fpStep i Δ k, o =>
    runOzf P zf (k (zf o i Δ)) { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
  | AlgM.bankNew tr d k, o =>
    (bankNewImpl P tr d).bind fun B => runOzf P zf k { o with banks := o.banks ++ [B] }
  | AlgM.bankRetain n k, o => runOzf P zf k { o with banks := o.banks.take n }
  | AlgM.bankOp idx op k, o =>
    runOzf P zf k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
  | AlgM.bankOpFrom idx op k, o =>
    runOzf P zf k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
  | AlgM.bankValidate idx S θ k, o =>
    match o.banks[idx]? with
    | none => runOzf P zf (k AdaCert.abort) o
    | some B =>
      (B.validate P S θ).bind fun r => runOzf P zf (k r.1) { o with banks := setAt r.2 idx o.banks }
  | AlgM.bankRelease idx mode k, o =>
    match o.banks[idx]? with
    | none => runOzf P zf (k none) o
    | some B =>
      (B.release P mode).bind fun r => runOzf P zf (k r.1) { o with banks := setAt r.2 idx o.banks }
  | AlgM.note _ k, o => runOzf P zf k o

section runOzf_eqns

variable (P : StreamParams) (zf : OState → ℕ → ℤ → Bool) {α : Type}

@[simp] theorem runOzf_pure (a : α) (o : OState) :
    runOzf P zf (AlgM.pure a) o = BitProg.pure (a, o) := rfl

@[simp] theorem runOzf_fpInit (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.fpInit k) o =
      (fpSeedProg P).bind fun r => runOzf P zf k { o with fpSeed := r, fpVal := 0 } := rfl

@[simp] theorem runOzf_fpStep (i : ℕ) (Δ : ℤ) (k : Bool → AlgM α) (o : OState) :
    runOzf P zf (AlgM.fpStep i Δ k) o =
      runOzf P zf (k (zf o i Δ)) { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ } := rfl

@[simp] theorem runOzf_bankNew (tr d : ℕ) (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankNew tr d k) o =
      (bankNewImpl P tr d).bind fun B => runOzf P zf k { o with banks := o.banks ++ [B] } := rfl

@[simp] theorem runOzf_bankRetain (n : ℕ) (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankRetain n k) o = runOzf P zf k { o with banks := o.banks.take n } := rfl

@[simp] theorem runOzf_bankOp (idx : ℕ) (op : RowOp) (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankOp idx op k) o =
      runOzf P zf k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks } := rfl

@[simp] theorem runOzf_bankOpFrom (idx : ℕ) (op : RowOp) (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankOpFrom idx op k) o =
      runOzf P zf k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks } := rfl

@[simp] theorem runOzf_bankValidate (idx : ℕ) (S θ : ℚ) (k : AdaCert → AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankValidate idx S θ k) o =
      match o.banks[idx]? with
      | none => runOzf P zf (k AdaCert.abort) o
      | some B =>
        (B.validate P S θ).bind fun r =>
          runOzf P zf (k r.1) { o with banks := setAt r.2 idx o.banks } := by
  rw [runOzf]

@[simp] theorem runOzf_bankRelease (idx : ℕ) (mode : Mode) (k : Option ℚ → AlgM α) (o : OState) :
    runOzf P zf (AlgM.bankRelease idx mode k) o =
      match o.banks[idx]? with
      | none => runOzf P zf (k none) o
      | some B =>
        (B.release P mode).bind fun r =>
          runOzf P zf (k r.1) { o with banks := setAt r.2 idx o.banks } := by
  rw [runOzf]

@[simp] theorem runOzf_note (ev : TreeEvent) (k : AlgM α) (o : OState) :
    runOzf P zf (AlgM.note ev k) o = runOzf P zf k o := rfl

theorem runOzf_fpStep_bind {β : Type} (i : ℕ) (Δ : ℤ) (k : Bool → AlgM α) (f : α → AlgM β)
    (o : OState) :
    runOzf P zf ((AlgM.fpStep i Δ k).bind f) o =
      runOzf P zf ((k (zf o i Δ)).bind f) { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ } :=
  rfl

end runOzf_eqns

/-- The real answer of the fingerprint test (Algorithm `R:alg:zero-fingerprint`, Line 6). -/
def realZf (P : StreamParams) (o : OState) (i : ℕ) (Δ : ℤ) : Bool :=
  fpUpdate P o.fpSeed o.fpVal i Δ == 0

/-- The real interpreter answers the fingerprint test with the real test. -/
theorem runO_eq_runOzf (P : StreamParams) {α : Type} :
    ∀ (p : AlgM α) (o : OState), runO P p o = runOzf P (realZf P) p o
  | AlgM.pure _, _ => rfl
  | AlgM.fpInit k, o => by
    rw [runO_fpInit, runOzf_fpInit]
    congr 1
    funext r
    exact runO_eq_runOzf P k _
  | AlgM.fpStep i Δ k, o => by
    rw [runO_fpStep, runOzf_fpStep]
    exact runO_eq_runOzf P (k _) _
  | AlgM.bankNew tr d k, o => by
    rw [runO_bankNew, runOzf_bankNew]
    congr 1
    funext B
    exact runO_eq_runOzf P k _
  | AlgM.bankRetain n k, o => by
    rw [runO_bankRetain, runOzf_bankRetain]
    exact runO_eq_runOzf P k _
  | AlgM.bankOp idx op k, o => by
    rw [runO_bankOp, runOzf_bankOp]
    exact runO_eq_runOzf P k _
  | AlgM.bankOpFrom idx op k, o => by
    rw [runO_bankOpFrom, runOzf_bankOpFrom]
    exact runO_eq_runOzf P k _
  | AlgM.bankValidate idx S θ k, o => by
    rw [runO_bankValidate, runOzf_bankValidate]
    cases o.banks[idx]? with
    | none => exact runO_eq_runOzf P (k AdaCert.abort) o
    | some B =>
      show (B.validate P S θ).bind _ = (B.validate P S θ).bind _
      congr 1
      funext r
      exact runO_eq_runOzf P (k _) _
  | AlgM.bankRelease idx mode k, o => by
    rw [runO_bankRelease, runOzf_bankRelease]
    cases o.banks[idx]? with
    | none => exact runO_eq_runOzf P (k none) o
    | some B =>
      show (B.release P mode).bind _ = (B.release P mode).bind _
      congr 1
      funext r
      exact runO_eq_runOzf P (k _) _
  | AlgM.note ev k, o => by
    rw [runO_note, runOzf_note]
    exact runO_eq_runOzf P k _

/-- The interpreter commutes with sequential composition. -/
theorem runOzf_bind (P : StreamParams) (zf : OState → ℕ → ℤ → Bool) {α β : Type}
    (f : α → AlgM β) : ∀ (p : AlgM α) (o : OState),
      runOzf P zf (p.bind f) o = (runOzf P zf p o).bind (fun r => runOzf P zf (f r.1) r.2)
  | AlgM.pure _, _ => rfl
  | AlgM.fpInit k, o => by
    simp only [AlgM.bind, runOzf_fpInit, bp_bind_assoc]
    congr 1
    funext r
    exact runOzf_bind P zf f k _
  | AlgM.fpStep i Δ k, o => by
    simp only [AlgM.bind, runOzf_fpStep]
    exact runOzf_bind P zf f (k _) _
  | AlgM.bankNew tr d k, o => by
    simp only [AlgM.bind, runOzf_bankNew, bp_bind_assoc]
    congr 1
    funext B
    exact runOzf_bind P zf f k _
  | AlgM.bankRetain n k, o => by
    simp only [AlgM.bind, runOzf_bankRetain]
    exact runOzf_bind P zf f k _
  | AlgM.bankOp idx op k, o => by
    simp only [AlgM.bind, runOzf_bankOp]
    exact runOzf_bind P zf f k _
  | AlgM.bankOpFrom idx op k, o => by
    simp only [AlgM.bind, runOzf_bankOpFrom]
    exact runOzf_bind P zf f k _
  | AlgM.bankValidate idx S θ k, o => by
    simp only [AlgM.bind, runOzf_bankValidate]
    split
    · exact runOzf_bind P zf f (k _) _
    · rw [bp_bind_assoc]
      congr 1
      funext r
      exact runOzf_bind P zf f (k _) _
  | AlgM.bankRelease idx mode k, o => by
    simp only [AlgM.bind, runOzf_bankRelease]
    split
    · exact runOzf_bind P zf f (k _) _
    · rw [bp_bind_assoc]
      congr 1
      funext r
      exact runOzf_bind P zf f (k _) _
  | AlgM.note ev k, o => by
    simp only [AlgM.bind, runOzf_note]
    exact runOzf_bind P zf f k _

/-- **Erasure naturality**: with a constant test answer, the output and the final banks depend
only on the initial banks (the fingerprint registers are never read). -/
theorem runOzf_banks (P : StreamParams) (z : Bool) {α : Type} :
    ∀ (p : AlgM α) (o o' : OState), o.banks = o'.banks →
      (runOzf P (fun _ _ _ => z) p o).map (fun r => (r.1, r.2.banks)) =
        (runOzf P (fun _ _ _ => z) p o').map (fun r => (r.1, r.2.banks))
  | AlgM.pure a, o, o', h => by
    show BitProg.pure (a, o.banks) = BitProg.pure (a, o'.banks)
    rw [h]
  | AlgM.fpInit k, o, o', h => by
    simp only [runOzf_fpInit, bp_map_bind]
    congr 1
    funext r
    exact runOzf_banks P z k _ _ h
  | AlgM.fpStep i Δ k, o, o', h => by
    simp only [runOzf_fpStep]
    exact runOzf_banks P z (k z) _ _ h
  | AlgM.bankNew tr d k, o, o', h => by
    simp only [runOzf_bankNew, bp_map_bind]
    congr 1
    funext B
    exact runOzf_banks P z k _ _ (by simp only [h])
  | AlgM.bankRetain n k, o, o', h => by
    simp only [runOzf_bankRetain]
    exact runOzf_banks P z k _ _ (by simp only [h])
  | AlgM.bankOp idx op k, o, o', h => by
    simp only [runOzf_bankOp]
    exact runOzf_banks P z k _ _ (by simp only [h])
  | AlgM.bankOpFrom idx op k, o, o', h => by
    simp only [runOzf_bankOpFrom]
    exact runOzf_banks P z k _ _ (by simp only [h])
  | AlgM.bankValidate idx S θ k, o, o', h => by
    rw [runOzf_bankValidate, runOzf_bankValidate, ← h]
    split
    · exact runOzf_banks P z (k _) _ _ h
    · simp only [bp_map_bind]
      congr 1
      funext r
      exact runOzf_banks P z (k _) _ _ rfl
  | AlgM.bankRelease idx mode k, o, o', h => by
    rw [runOzf_bankRelease, runOzf_bankRelease, ← h]
    split
    · exact runOzf_banks P z (k _) _ _ h
    · simp only [bp_map_bind]
      congr 1
      funext r
      exact runOzf_banks P z (k _) _ _ rfl
  | AlgM.note ev k, o, o', h => by
    simp only [runOzf_note]
    exact runOzf_banks P z k _ _ h

/-! ### Programs without fingerprint calls -/

/-- `NoFp p`: the program `p` makes no fingerprint call (`fpInit`, `fpStep`). -/
def NoFp {α : Type} : AlgM α → Prop
  | AlgM.pure _ => True
  | AlgM.fpInit _ => False
  | AlgM.fpStep _ _ _ => False
  | AlgM.bankNew _ _ k => NoFp k
  | AlgM.bankRetain _ k => NoFp k
  | AlgM.bankOp _ _ k => NoFp k
  | AlgM.bankOpFrom _ _ k => NoFp k
  | AlgM.bankValidate _ _ _ k => ∀ c, NoFp (k c)
  | AlgM.bankRelease _ _ k => ∀ o, NoFp (k o)
  | AlgM.note _ k => NoFp k

theorem NoFp.bind' {α β : Type} {f : α → AlgM β} (hf : ∀ a, NoFp (f a)) :
    ∀ (p : AlgM α), NoFp p → NoFp (p.bind f)
  | AlgM.pure a, _ => hf a
  | AlgM.fpInit _, h => False.elim h
  | AlgM.fpStep _ _ _, h => False.elim h
  | AlgM.bankNew _ _ k, h => NoFp.bind' hf k h
  | AlgM.bankRetain _ k, h => NoFp.bind' hf k h
  | AlgM.bankOp _ _ k, h => NoFp.bind' hf k h
  | AlgM.bankOpFrom _ _ k, h => NoFp.bind' hf k h
  | AlgM.bankValidate _ _ _ k, h => fun c => NoFp.bind' hf (k c) (h c)
  | AlgM.bankRelease _ _ k, h => fun o => NoFp.bind' hf (k o) (h o)
  | AlgM.note _ k, h => NoFp.bind' hf k h

theorem NoFp.bind {α β : Type} {p : AlgM α} {f : α → AlgM β} (hp : NoFp p)
    (hf : ∀ a, NoFp (f a)) : NoFp (p.bind f) :=
  NoFp.bind' hf p hp

@[simp] theorem noFp_ite {α : Type} (c : Prop) [Decidable c] (a b : AlgM α) :
    NoFp (if c then a else b) ↔ (c → NoFp a) ∧ (¬c → NoFp b) := by
  by_cases h : c <;> simp [h]

theorem adaCert_forall {p : AdaCert → Prop} :
    (∀ c, p c) ↔ p AdaCert.accept ∧ p AdaCert.high ∧ p AdaCert.low ∧ p AdaCert.termHigh ∧
      p AdaCert.termLow ∧ p AdaCert.abort := by
  constructor
  · intro h
    exact ⟨h _, h _, h _, h _, h _, h _⟩
  · rintro ⟨h1, h2, h3, h4, h5, h6⟩ c
    cases c <;> assumption

/-- A program without fingerprint calls keeps the fingerprint registers. -/
theorem runOzf_noFp_regs (P : StreamParams) (zf : OState → ℕ → ℤ → Bool) {α : Type} :
    ∀ (p : AlgM α) (o : OState), NoFp p →
      BPAll (runOzf P zf p o) (fun r => r.2.fpSeed = o.fpSeed ∧ r.2.fpVal = o.fpVal)
  | AlgM.pure _, _, _ => ⟨rfl, rfl⟩
  | AlgM.fpInit _, _, h => False.elim h
  | AlgM.fpStep _ _ _, _, h => False.elim h
  | AlgM.bankNew tr d k, o, h => by
    rw [runOzf_bankNew]
    exact BPAll.bind (fun B _ => runOzf_noFp_regs P zf k { o with banks := o.banks ++ [B] } h)
      (BPAll.true _)
  | AlgM.bankRetain n k, o, h => by
    rw [runOzf_bankRetain]
    exact runOzf_noFp_regs P zf k _ h
  | AlgM.bankOp idx op k, o, h => by
    rw [runOzf_bankOp]
    exact runOzf_noFp_regs P zf k _ h
  | AlgM.bankOpFrom idx op k, o, h => by
    rw [runOzf_bankOpFrom]
    exact runOzf_noFp_regs P zf k _ h
  | AlgM.bankValidate idx S θ k, o, h => by
    rw [runOzf_bankValidate]
    split
    · exact runOzf_noFp_regs P zf (k _) o (h _)
    · exact BPAll.bind (fun r _ =>
        runOzf_noFp_regs P zf (k r.1) { o with banks := setAt r.2 idx o.banks } (h _))
        (BPAll.true _)
  | AlgM.bankRelease idx mode k, o, h => by
    rw [runOzf_bankRelease]
    split
    · exact runOzf_noFp_regs P zf (k _) o (h _)
    · exact BPAll.bind (fun r _ =>
        runOzf_noFp_regs P zf (k r.1) { o with banks := setAt r.2 idx o.banks } (h _))
        (BPAll.true _)
  | AlgM.note _ k, o, h => by
    rw [runOzf_note]
    exact runOzf_noFp_regs P zf k o h

/-- A program without fingerprint calls ignores the test answers. -/
theorem runOzf_noFp_indep (P : StreamParams) (zf zf' : OState → ℕ → ℤ → Bool) {α : Type} :
    ∀ (p : AlgM α) (o : OState), NoFp p → runOzf P zf p o = runOzf P zf' p o
  | AlgM.pure _, _, _ => rfl
  | AlgM.fpInit _, _, h => False.elim h
  | AlgM.fpStep _ _ _, _, h => False.elim h
  | AlgM.bankNew tr d k, o, h => by
    simp only [runOzf_bankNew]
    congr 1
    funext B
    exact runOzf_noFp_indep P zf zf' k _ h
  | AlgM.bankRetain n k, o, h => by
    simp only [runOzf_bankRetain]
    exact runOzf_noFp_indep P zf zf' k _ h
  | AlgM.bankOp idx op k, o, h => by
    simp only [runOzf_bankOp]
    exact runOzf_noFp_indep P zf zf' k _ h
  | AlgM.bankOpFrom idx op k, o, h => by
    simp only [runOzf_bankOpFrom]
    exact runOzf_noFp_indep P zf zf' k _ h
  | AlgM.bankValidate idx S θ k, o, h => by
    simp only [runOzf_bankValidate]
    split
    · exact runOzf_noFp_indep P zf zf' (k _) o (h _)
    · congr 1
      funext r
      exact runOzf_noFp_indep P zf zf' (k _) _ (h _)
  | AlgM.bankRelease idx mode k, o, h => by
    simp only [runOzf_bankRelease]
    split
    · exact runOzf_noFp_indep P zf zf' (k _) o (h _)
    · congr 1
      funext r
      exact runOzf_noFp_indep P zf zf' (k _) _ (h _)
  | AlgM.note _ k, o, h => by
    simp only [runOzf_note]
    exact runOzf_noFp_indep P zf zf' k o h

/-! ### Steps 1, 3, 4 make no fingerprint call -/

theorem noFp_birthCode (P : StreamParams) (tr d0 d : ℕ) (c : CState) :
    NoFp (birthCode P tr d0 d c) := by
  simp [birthCode, bankOpM, bankNewM, noteM, releaseM, AlgM.bind, NoFp, Option.forall]

theorem noFp_birthLoopCode (P : StreamParams) (tr d0 : ℕ) :
    ∀ (ds : List ℕ) (c : CState), NoFp (birthLoopCode P tr d0 ds c)
  | [], _ => trivial
  | d :: ds, c => by
    simp only [birthLoopCode]
    split_ifs
    · trivial
    · exact NoFp.bind (noFp_birthCode P tr d0 d c) (fun c' => noFp_birthLoopCode P tr d0 ds c')

theorem noFp_step1Code (P : StreamParams) (c : CState) : NoFp (step1Code P c) := by
  simp only [step1Code, bankRetainM, AlgM.bind_eq, AlgM.bind, NoFp]
  exact NoFp.bind (noFp_birthLoopCode P _ _ _ _) (fun _ => by simp [NoFp])

theorem noFp_step3DepthCode (P : StreamParams) (tr : ℕ) (c : CState) (d : ℕ) :
    NoFp (step3DepthCode P tr c d) := by
  unfold step3DepthCode
  split
  · trivial
  · simp [bankOpM, bankOpFromM, noteM, AlgM.bind, NoFp]

theorem noFp_step3LoopCode (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (c : CState), NoFp (step3LoopCode P tr ds c)
  | [], _ => trivial
  | d :: ds, c => by
    simp only [step3LoopCode]
    split_ifs
    · trivial
    · exact NoFp.bind (noFp_step3DepthCode P tr c d) (fun c' => noFp_step3LoopCode P tr ds c')

theorem noFp_step3Code (P : StreamParams) (c : CState) : NoFp (step3Code P c) :=
  noFp_step3LoopCode P _ _ _

theorem noFp_rejectTailCode (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (c : CState) : NoFp (rejectTailCode P d Ld cInt N1 c) := by
  simp only [rejectTailCode, bankOpFromM, noteM, releaseM, AlgM.bind_eq, AlgM.pure_eq, AlgM.bind,
    NoFp, noFp_ite]
  refine ⟨fun _ o => ?_, fun _ => trivial⟩
  rcases o with _ | N2
  · trivial
  · simp only
    split <;> simp [NoFp]

theorem noFp_rejectDepthCode (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState) :
    NoFp (rejectDepthCode P d pos Qhat c) := by
  unfold rejectDepthCode
  split
  · trivial
  · simp [releaseM, bankOpM, AlgM.bind, NoFp, Option.forall, noFp_rejectTailCode]

theorem noFp_step4DepthCode (P : StreamParams) (d : ℕ) (c : CState) (F : ℚ) :
    NoFp (step4DepthCode P d c F) := by
  unfold step4DepthCode
  split
  · trivial
  · simp [validateM, noteM, AlgM.bind, NoFp, adaCert_forall, noFp_rejectDepthCode]

theorem noFp_step4LoopCode (P : StreamParams) :
    ∀ (ds : List ℕ) (c : CState) (F : ℚ), NoFp (step4LoopCode P ds c F)
  | [], _, _ => trivial
  | d :: ds, c, F => by
    simp only [step4LoopCode]
    split_ifs
    · trivial
    · exact NoFp.bind (noFp_step4DepthCode P d c F) (fun r => noFp_step4LoopCode P ds r.1 r.2)

theorem noFp_step4Code (P : StreamParams) (c : CState) : NoFp (step4Code P c) :=
  noFp_step4LoopCode P _ _ _

/-! ### The round: one fingerprint call, with the registers of the state before the round -/

/-- The part of a round after Step 3 (as in `roundCode`). -/
def fpTail3 (P : StreamParams) (c3 : CState) : AlgM (CState × ℚ) :=
  if c3.failed = true then AlgM.pure (finishC c3 0)
  else (step4Code P c3).bind fun r4 => AlgM.pure (finishC r4.1 r4.2)

/-- The part of a round after Step 2 (as in `roundCode`). -/
def fpTail2 (P : StreamParams) (r2 : CState × Bool) : AlgM (CState × ℚ) :=
  if (r2.1.failed || r2.2) = true then AlgM.pure (finishC r2.1 0)
  else (step3Code P r2.1).bind (fpTail3 P)

/-- The part of a round after Step 1 (as in `roundCode`). -/
def fpTail1 (P : StreamParams) (i : ℕ) (Δ : ℤ) (c1 : CState) : AlgM (CState × ℚ) :=
  if c1.failed = true then AlgM.pure (finishC c1 0)
  else (step2Code P i Δ c1).bind (fpTail2 P)

theorem roundCode_eq (P : StreamParams) (c : CState) (i : ℕ) (Δ : ℤ) :
    roundCode P c i Δ = if c.failed = true then AlgM.pure (finishC c 0)
      else AlgM.note TreeEvent.newRound ((step1Code P c).bind (fpTail1 P i Δ)) := rfl

theorem noFp_fpTail3 (P : StreamParams) (c3 : CState) : NoFp (fpTail3 P c3) := by
  unfold fpTail3
  split_ifs
  · trivial
  · exact NoFp.bind (noFp_step4Code P c3) (fun _ => by simp [NoFp])

theorem noFp_fpTail2 (P : StreamParams) (r2 : CState × Bool) : NoFp (fpTail2 P r2) := by
  unfold fpTail2
  split_ifs
  · trivial
  · exact NoFp.bind (noFp_step3Code P r2.1) (fun c3 => noFp_fpTail3 P c3)

/-- Step 2 is the fingerprint call followed by a program without fingerprint calls. -/
theorem step2Code_shape (P : StreamParams) (i : ℕ) (Δ : ℤ) (c : CState) :
    ∃ T : Bool → AlgM (CState × Bool), (∀ z, NoFp (T z)) ∧
      step2Code P i Δ c = AlgM.fpStep (i + 1) Δ T :=
  ⟨_, fun z => by simp [bankOpFromM, noteM, AlgM.bind, NoFp], rfl⟩

/-- **The registers in a round**: the seed is kept, and a round ending in a non-failed state
started from a non-failed state and its register is the Step-2 update of the initial registers. -/
theorem roundCode_regs (P : StreamParams) (zf : OState → ℕ → ℤ → Bool) (c : CState) (i : ℕ)
    (Δ : ℤ) (o : OState) :
    BPAll (runOzf P zf (roundCode P c i Δ) o) (fun r => r.2.fpSeed = o.fpSeed ∧
      (r.1.1.failed = false → c.failed = false ∧
        r.2.fpVal = fpUpdate P o.fpSeed o.fpVal (i + 1) Δ)) := by
  rw [roundCode_eq]
  by_cases hc : c.failed = true
  · rw [if_pos hc, runOzf_pure]
    exact BPAll.pure ⟨rfl, fun h => by simp [finishC, hc] at h⟩
  · have hc' : c.failed = false := by simpa using hc
    rw [if_neg hc, runOzf_note, runOzf_bind]
    refine BPAll.bind (R := fun r => r.2.fpSeed = o.fpSeed ∧ r.2.fpVal = o.fpVal)
      (fun r hr => ?_) (runOzf_noFp_regs P zf _ o (noFp_step1Code P c))
    unfold fpTail1
    by_cases h1 : r.1.failed = true
    · rw [if_pos h1, runOzf_pure]
      exact BPAll.pure ⟨hr.1, fun h => by simp [finishC, h1] at h⟩
    · rw [if_neg h1]
      obtain ⟨T, hT, hEq⟩ := step2Code_shape P i Δ r.1
      rw [hEq, runOzf_fpStep_bind]
      refine BPAll.mono (fun x hx => ?_)
        (runOzf_noFp_regs P zf _ _ (NoFp.bind (hT _) (fun r2 => noFp_fpTail2 P r2)))
      refine ⟨hx.1.trans hr.1, fun _ => ⟨hc', ?_⟩⟩
      rw [hx.2, hr.1, hr.2]

/-- **The test answer of a round**: two test answers agreeing on the registers of the state before
the round give the same round. -/
theorem roundCode_zf_congr (P : StreamParams) (zf zf' : OState → ℕ → ℤ → Bool) (c : CState)
    (i : ℕ) (Δ : ℤ) (o : OState)
    (hzf : ∀ o' : OState, o'.fpSeed = o.fpSeed → o'.fpVal = o.fpVal →
      zf o' (i + 1) Δ = zf' o' (i + 1) Δ) :
    runOzf P zf (roundCode P c i Δ) o = runOzf P zf' (roundCode P c i Δ) o := by
  rw [roundCode_eq]
  by_cases hc : c.failed = true
  · rw [if_pos hc]
    rfl
  · rw [if_neg hc, runOzf_note, runOzf_note, runOzf_bind, runOzf_bind,
      runOzf_noFp_indep P zf zf' _ o (noFp_step1Code P c)]
    refine bind_congr_of_BPAll (R := fun r => r.2.fpSeed = o.fpSeed ∧ r.2.fpVal = o.fpVal)
      (fun r hr => ?_) (runOzf_noFp_regs P zf' _ o (noFp_step1Code P c))
    unfold fpTail1
    by_cases h1 : r.1.failed = true
    · rw [if_pos h1]
      rfl
    · rw [if_neg h1]
      obtain ⟨T, hT, hEq⟩ := step2Code_shape P i Δ r.1
      rw [hEq, runOzf_fpStep_bind, runOzf_fpStep_bind, hzf r.2 hr.1 hr.2]
      exact runOzf_noFp_indep P zf zf' _ _ (NoFp.bind (hT _) (fun r2 => noFp_fpTail2 P r2))

/-! ### The fingerprint registers -/

theorem fpUpdate_cast (P : StreamParams) (seed val : ℕ) (u : Fin P.n × ℤ) :
    ((fpUpdate P seed val (u.1.val + 1) u.2 : ℕ) : ZMod P.q) = fpNext P.q seed val u := by
  have h := (ZMod.intCast_eq_intCast_iff _ _ _).mpr
    (fpUpdate_modEq P (q_pos P) seed val (u.1.val + 1) u.2)
  unfold fpNext
  push_cast at h
  exact h

theorem fpUpdate_eq_zero_iff (P : StreamParams) (seed val : ℕ) (u : Fin P.n × ℤ) :
    fpUpdate P seed val (u.1.val + 1) u.2 = 0 ↔ fpNext P.q seed val u = 0 := by
  rw [← fpUpdate_cast]
  constructor
  · intro h
    rw [h, Nat.cast_zero]
  · intro h
    rw [ZMod.natCast_eq_zero_iff] at h
    have hlt := fpUpdate_lt P (q_pos P) seed val (u.1.val + 1) u.2
    by_contra hne
    exact absurd (Nat.le_of_dvd (Nat.pos_of_ne_zero hne) h) (not_le.mpr hlt)

theorem realZf_eq (P : StreamParams) (o : OState) (u : Fin P.n × ℤ) :
    realZf P o (u.1.val + 1) u.2 = decide (fpNext P.q o.fpSeed o.fpVal u = 0) := by
  unfold realZf
  rw [Bool.eq_iff_iff, beq_iff_eq, decide_eq_true_iff]
  exact fpUpdate_eq_zero_iff P _ _ u

/-! ### The abstract round of the Theorem C algorithm -/

/-- Forget the fingerprint registers. -/
def eraseFp (s : Alg.State) : Alg.State := { s with fpSeed := 0, fpVal := 0 }

/-- One round with the fingerprint test answered by the bit `z`. -/
def stepZAlg (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) (z : Bool) :
    BitProg (Alg.State × ℚ) :=
  (runOzf P (fun _ _ _ => z) (roundCode P s.ctrl u.1.val u.2) s.orc).bind
    fun r => BitProg.pure (State.mk' r.1.1 r.2, r.1.2)

theorem stepZAlg_failed (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) (z z' : Bool)
    (h : s.failed = true) : stepZAlg P s u z = stepZAlg P s u z' := by
  unfold stepZAlg
  rw [roundCode_eq, if_pos (show s.ctrl.failed = true from h)]
  rfl

theorem stepZAlg_erase (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) (z : Bool) :
    (stepZAlg P s u z).map (fun r => (eraseFp r.1, r.2)) =
      (stepZAlg P (eraseFp s) u z).map (fun r => (eraseFp r.1, r.2)) := by
  have key : ∀ s' : Alg.State, (stepZAlg P s' u z).map (fun r => (eraseFp r.1, r.2)) =
      ((runOzf P (fun _ _ _ => z) (roundCode P s'.ctrl u.1.val u.2) s'.orc).map
        (fun r => (r.1, r.2.banks))).bind
        (fun x => BitProg.pure (State.mk' x.1.1 ⟨0, 0, x.2⟩, x.1.2)) := by
    intro s'
    unfold stepZAlg
    simp only [BitProg.map, bp_bind_assoc, BitProg.bind_pure', Function.comp_apply]
    rfl
  rw [key s, key (eraseFp s)]
  have hc : (eraseFp s).ctrl = s.ctrl := rfl
  rw [hc, runOzf_banks P z _ s.orc (eraseFp s).orc rfl]

theorem stepZAlg_fp (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) (z : Bool) :
    BPAll (stepZAlg P s u z) (fun r => r.1.fpSeed = s.fpSeed ∧
      (r.1.failed = false → s.failed = false ∧
        (r.1.fpVal : ZMod P.q) = fpNext P.q s.fpSeed s.fpVal u)) := by
  unfold stepZAlg
  refine BPAll.bind (fun r hr => ?_) (roundCode_regs P _ s.ctrl u.1.val u.2 s.orc)
  obtain ⟨h1, h2⟩ := hr
  refine BPAll.pure ⟨h1, fun hf => ?_⟩
  obtain ⟨h3, h4⟩ := h2 hf
  refine ⟨h3, ?_⟩
  show ((r.2.fpVal : ℕ) : ZMod P.q) = _
  rw [h4]
  exact fpUpdate_cast P s.fpSeed s.fpVal u

/-- **The Theorem C algorithm as an abstract fingerprint round.** -/
def fpRoundAlg (P : StreamParams) : FpRound P.n P.q theAlg.State where
  seed := State.fpSeed
  val := State.fpVal
  failed := State.failed
  erase := eraseFp
  stepZ := stepZAlg P
  stepZ_failed := stepZAlg_failed P
  failed_erase _ := rfl
  stepZ_erase := stepZAlg_erase P
  stepZ_fp := stepZAlg_fp P

/-- The initial state for the seed `r` and the root bank `B`. -/
def initMk (r : ℕ) (B : Bank) : Alg.State := ⟨0, false, r, 0, [], [B], 0⟩

theorem theAlg_init_eq (P : StreamParams) (tape : List Bool) :
    theAlg.init P tape = ((fpSeedProg P).bind fun r => (newBank P).map (initMk r)).run tape :=
  rfl

/-- The rounds of `theAlg` are the abstract rounds with the real zero test (through C-ALG's
`algStep_eq_interp`). -/
theorem theAlg_step_eq (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) (tape : List Bool) :
    theAlg.step P s u tape = ((fpRoundAlg P).stepZ s u (fpBitOf (fpRoundAlg P) s u)).run tape := by
  show (theStep P s u).run tape = (stepZAlg P s u (fpBitOf (fpRoundAlg P) s u)).run tape
  congr 1
  unfold theStep stepZAlg
  rw [algStep_eq_interp]
  unfold algStepM
  rw [runO_eq_runOzf]
  congr 1
  refine roundCode_zf_congr P _ _ _ _ _ _ fun o' h1 h2 => ?_
  rw [realZf_eq, h1, h2]
  rfl

theorem initProg_fpVal (P : StreamParams) :
    BPAll ((fpSeedProg P).bind fun r => (newBank P).map (initMk r)) (fun s => s.fpVal = 0) := by
  refine BPAll.bind (R := fun _ => True) (fun r _ => ?_) (BPAll.true _)
  refine BPAll.bind (R := fun _ => True) (fun B _ => ?_) (BPAll.true _)
  exact BPAll.pure rfl

/-- **The failure count for `theAlg`** (Lemma `R:lem:zero-fingerprint` (3)). -/
theorem card_falseZeroRun_theAlg_le (P : StreamParams) (hP : ParamsOK P)
    (adv : StreamAdversary P.n) :
    (({tapes | FalseZeroRun (fpRoundAlg P) adv tapes} :
        Set (Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool)).ncard : ℝ≥0∞) ≤
      2 ^ ((P.m + 1) * theAlg.tapeLen P) * ((P.m * P.n : ℝ≥0∞) / P.q + 2⁻¹ ^ P.seedTrials) := by
  have : Fact P.q.Prime := ⟨q_prime P⟩
  exact card_falseZeroRun_le (fpRoundAlg P) adv (U_lt_q P hP.one_le_n hP.one_le_m) (fpSeedProg P)
    (newBank P) initMk (theAlg_init_eq P) (theAlg_step_eq P) (fun _ _ => rfl) (fun _ _ => rfl)
    (fun _ _ => rfl) (theAlg_init_depth P) (fun r => law_seed_le (q_pos P) P.seedTrials r)

/-! ### The deterministic invariant on the canonical run -/

theorem run_zero_of_run {P : StreamParams} {A' : MathStreamAlg} {adv : StreamAdversary P.n}
    {tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool} :
    ∀ {t : ℕ} {c : A'.State × List ℚ}, A'.run P adv tapes t = some c →
      ∃ c0, A'.run P adv tapes 0 = some c0
  | 0, c, h => ⟨c, h⟩
  | _ + 1, _, h => by
    obtain ⟨c', hc', -⟩ := run_succ_some h
    exact run_zero_of_run hc'

/-- The update of round `s ≤ t` is the adversary's answer to the first `s` estimates. -/
theorem advUpdate_eq_adv_take {P : StreamParams} {A' : MathStreamAlg}
    {adv : StreamAdversary P.n} {tapes : Fin (P.m + 1) → Fin (A'.tapeLen P) → Bool} {t : ℕ}
    {c : A'.State × List ℚ} (hc : A'.run P adv tapes t = some c) {s : ℕ} (hs : s ≤ t) :
    advUpdate adv (A'.outs P adv tapes) s = adv (c.2.take s) := by
  have hlen := run_length hc
  have hout := outs_eq_of_run hc
  unfold advUpdate
  congr 1
  rw [← ofFn_getD_eq_take c.2 (by omega)]
  congr 1
  funext r
  exact hout r.val (by omega)

/-- **Part (1)** on the canonical run of `theAlg`: the seed is the initial one, and in a
non-failed state the register is the fingerprint of the stream vector before the round. -/
theorem theAlg_run_fp_inv (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) {t : ℕ}
    {c c0 : Alg.State × List ℚ} (hc : theAlg.run P adv tapes t = some c)
    (hc0 : theAlg.run P adv tapes 0 = some c0) :
    c.1.fpSeed = c0.1.fpSeed ∧ (c.1.failed = false →
      ((c.1.fpVal : ℕ) : ZMod P.q) = fpEval P.q (vecBefore adv c.2) (c0.1.fpSeed : ZMod P.q)) := by
  have hi := theAlg_init_eq P
  have hs := theAlg_step_eq P
  have hc' := hc
  rw [run_eq_bind_runZ (fpRoundAlg P) adv _ hi hs tapes t] at hc'
  obtain ⟨c0', hc0', hrun⟩ := Option.bind_eq_some_iff.mp hc'
  have h0 : c0.1 = c0'.1 := by
    have e := run_eq_bind_runZ (fpRoundAlg P) adv _ hi hs tapes 0
    rw [hc0', hc0] at e
    simp only [Option.bind_some, runZ] at e
    exact congrArg Prod.fst (Option.some.inj e)
  have hval0 : (fpRoundAlg P).val c0'.1 = 0 := BPAll.of_run (initProg_fpVal P) hc0'
  obtain ⟨h1, h2⟩ := runZ_fp_inv (fpRoundAlg P) adv (tapeAt tapes) (realZ (fpRoundAlg P) adv)
    c0'.1 hval0 t c hrun
  rw [h0]
  exact ⟨h1, h2⟩

/-- The real zero test of a non-failed round of the canonical run is the fingerprint test of the
stream vector after the round's update. -/
theorem fpBitOf_theAlg_run (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) {t : ℕ}
    {c : Alg.State × List ℚ} (hc : theAlg.run P adv tapes t = some c) (hf : c.1.failed = false) :
    fpBitOf (fpRoundAlg P) c.1 (adv c.2) =
      decide (fpEval P.q (vecOf adv c.2) (c.1.fpSeed : ZMod P.q) = 0) := by
  obtain ⟨c0, hc0⟩ := run_zero_of_run hc
  obtain ⟨h1, h2⟩ := theAlg_run_fp_inv P adv tapes hc hc0
  have hval : ((fpRoundAlg P).val c.1 : ZMod P.q) =
      fpEval P.q (vecBefore adv c.2) ((fpRoundAlg P).seed c.1 : ZMod P.q) := by
    show ((c.1.fpVal : ℕ) : ZMod P.q) = fpEval P.q (vecBefore adv c.2) (c.1.fpSeed : ZMod P.q)
    rw [h2 hf, h1]
  exact realZ_eq_of_inv (fpRoundAlg P) adv (s0 := c.1) rfl hval

end F2e2e.C.FP
