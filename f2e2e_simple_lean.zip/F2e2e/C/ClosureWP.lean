import Mathlib
import F2e2e.C.ClosureEvents

/-!
# Theorem 6.4: a weakest-precondition calculus for the instrumented interpreter

The chronological closure walks through the controller code (`F2e2e/C/Alg/AlgMCode.lean`) step by step, in
the within-round order of the paper (Step 1 births, Step 2, Step 3 depth `0..H−1`, Step 4 depth `H−1..0`), and
uses at every bank call the statistical event of that call (read off the final call log). This file provides
the generic tools:

* `Outcome P p o g a o' g'`: some tape run of the instrumented program `runL P p o g` ends with `(a, o', g')`;
* `outcome_bind`: outcomes of `p.bind f` decompose; `outcome_calls_prefix`: call logs only grow;
* `WP P F p Q o g`: every outcome whose call log is a prefix of the final log `F` satisfies `Q`; `wp_bind`,
  `wp_pure`, `wp_mono`, and one rule per primitive (`wp_note`, `wp_bankOp`, …).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg

/-! ## `runL` and sequential composition -/

theorem runL_bind (P : StreamParams) {α β : Type} (f : α → AlgM β) :
    ∀ (p : AlgM α) (o : OState) (g : Ghost),
      runL P (p.bind f) o g = (runL P p o g).bind fun r => runL P (f r.1) r.2.1 r.2.2
  | AlgM.pure _, _, _ => rfl
  | AlgM.fpInit k, o, g => by
    simp only [AlgM.bind, runL, TBitProg.bind_assoc]
    congr 1; funext r; exact runL_bind P f k _ _
  | AlgM.fpStep i Δ k, o, g => by
    simp only [AlgM.bind, runL]; exact runL_bind P f (k _) _ _
  | AlgM.bankNew tr d k, o, g => by
    simp only [AlgM.bind, runL, TBitProg.bind_assoc]
    congr 1; funext B; exact runL_bind P f k _ _
  | AlgM.bankRetain n k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankOp idx op k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankOpFrom idx op k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankValidate idx S θ k, o, g => by
    simp only [AlgM.bind, runL]
    cases o.banks[idx]? with
    | none => exact runL_bind P f (k _) _ _
    | some B =>
      simp only [TBitProg.bind_assoc]
      congr 1; funext r; exact runL_bind P f (k _) _ _
  | AlgM.bankRelease idx mode k, o, g => by
    simp only [AlgM.bind, runL]
    cases o.banks[idx]? with
    | none => exact runL_bind P f (k _) _ _
    | some B =>
      simp only [TBitProg.bind_assoc]
      congr 1; funext r; exact runL_bind P f (k _) _ _
  | AlgM.note ev k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _

/-! ## Outcomes -/

/-- Some tape run of the instrumented program `runL P p o g` ends with the result `a`, the oracle state `o'`
and the ghost data `g'`. -/
def Outcome (P : StreamParams) {α : Type} (p : AlgM α) (o : OState) (g : Ghost) (a : α) (o' : OState)
    (g' : Ghost) : Prop :=
  ∃ tape rest : List Bool, (runL P p o g).merge.run tape = some ((a, o', g'), rest)

theorem outcome_pure {P : StreamParams} {α : Type} {a a' : α} {o o' : OState} {g g' : Ghost}
    (h : Outcome P (AlgM.pure a) o g a' o' g') : a' = a ∧ o' = o ∧ g' = g := by
  obtain ⟨tape, rest, h⟩ := h
  simp only [runL, merge_pure, BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at h
  exact ⟨h.1.1.symm, h.1.2.1.symm, h.1.2.2.symm⟩

/-- Outcomes of a sequential composition decompose. -/
theorem outcome_bind {P : StreamParams} {α β : Type} {p : AlgM α} {f : α → AlgM β} {o o'' : OState}
    {g g'' : Ghost} {b : β} (h : Outcome P (p.bind f) o g b o'' g'') :
    ∃ (a : α) (o' : OState) (g' : Ghost), Outcome P p o g a o' g' ∧ Outcome P (f a) o' g' b o'' g'' := by
  obtain ⟨tape, rest, h⟩ := h
  rw [runL_bind, merge_bind, BitProg.run_bind] at h
  obtain ⟨r, hr, h⟩ := Option.bind_eq_some_iff.mp h
  exact ⟨r.1.1, r.1.2.1, r.1.2.2, ⟨tape, r.2, hr⟩, ⟨r.2, rest, h⟩⟩

/-! ## Monotonicity of the ghost logs -/

theorem outcome_tag_bind {α β : Type} (i : Tag) (q : BitProg β)
    (k : β → TBitProg Tag α) {tape rest : List Bool} {a : α}
    (h : ((tag i q).bind k).merge.run tape = some (a, rest)) :
    ∃ (b : β) (mid : List Bool), q.run tape = some (b, mid) ∧ (k b).merge.run mid = some (a, rest) := by
  rw [merge_bind, merge_tag, BitProg.run_bind] at h
  obtain ⟨r, hr, h⟩ := Option.bind_eq_some_iff.mp h
  exact ⟨r.1, r.2, hr, h⟩

/-- **Call logs only grow** along every outcome (and so do the event logs). -/
theorem outcome_calls_prefix (P : StreamParams) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost) (a : α) (o' : OState) (g' : Ghost),
      Outcome P p o g a o' g' → g.calls <+: g'.calls ∧ g.events <+: g'.events
  | AlgM.pure _, o, g, a, o', g', h => by
    obtain ⟨-, -, rfl⟩ := outcome_pure h
    exact ⟨List.prefix_refl _, List.prefix_refl _⟩
  | AlgM.fpInit k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    obtain ⟨b, mid, -, h⟩ := outcome_tag_bind _ _ _ h
    have hh := outcome_calls_prefix P k _ _ a o' g' ⟨mid, rest, h⟩
    exact hh
  | AlgM.fpStep i Δ k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    have hh := outcome_calls_prefix P _ _ _ a o' g' ⟨tape, rest, h⟩
    exact hh
  | AlgM.bankNew tr d k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    rw [merge_bind, BitProg.run_bind] at h
    obtain ⟨r, -, h⟩ := Option.bind_eq_some_iff.mp h
    have hh := outcome_calls_prefix P k _ _ a o' g' ⟨r.2, rest, h⟩
    exact hh
  | AlgM.bankRetain n k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    have hh := outcome_calls_prefix P k _ _ a o' g' ⟨tape, rest, h⟩
    exact hh
  | AlgM.bankOp idx op k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    have hh := outcome_calls_prefix P k _ _ a o' g' ⟨tape, rest, h⟩
    exact hh
  | AlgM.bankOpFrom idx op k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    have hh := outcome_calls_prefix P k _ _ a o' g' ⟨tape, rest, h⟩
    exact hh
  | AlgM.bankValidate idx S θ k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    cases hB : o.banks[idx]? with
    | none =>
      rw [hB] at h
      have hh := outcome_calls_prefix P _ _ _ a o' g' ⟨tape, rest, h⟩
      exact hh
    | some B =>
      rw [hB] at h
      obtain ⟨b, mid, -, h⟩ := outcome_tag_bind _ _ _ h
      have := outcome_calls_prefix P _ _ _ a o' g' ⟨mid, rest, h⟩
      exact ⟨(List.prefix_append _ _).trans this.1, this.2⟩
  | AlgM.bankRelease idx mode k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    cases hB : o.banks[idx]? with
    | none =>
      rw [hB] at h
      have hh := outcome_calls_prefix P _ _ _ a o' g' ⟨tape, rest, h⟩
      exact hh
    | some B =>
      rw [hB] at h
      obtain ⟨b, mid, -, h⟩ := outcome_tag_bind _ _ _ h
      have := outcome_calls_prefix P _ _ _ a o' g' ⟨mid, rest, h⟩
      exact ⟨(List.prefix_append _ _).trans this.1, this.2⟩
  | AlgM.note ev k, o, g, a, o', g', ⟨tape, rest, h⟩ => by
    simp only [runL] at h
    have := outcome_calls_prefix P k _ _ a o' g' ⟨tape, rest, h⟩
    exact ⟨this.1, (List.prefix_append _ _).trans this.2⟩

/-! ## Weakest preconditions -/

/-- `WP P F p Q o g`: every outcome of the instrumented program from `(o, g)` whose call log is a prefix of the
final call log `F` satisfies `Q`. (The statistical events are hypotheses on `F`.) -/
def WP (P : StreamParams) (F : List CallRec) {α : Type} (p : AlgM α)
    (Q : α → OState → Ghost → Prop) (o : OState) (g : Ghost) : Prop :=
  ∀ a o' g', Outcome P p o g a o' g' → g'.calls <+: F → Q a o' g'

theorem wp_pure {P : StreamParams} {F : List CallRec} {α : Type} {a : α}
    {Q : α → OState → Ghost → Prop} {o : OState} {g : Ghost} (h : Q a o g) :
    WP P F (AlgM.pure a) Q o g := by
  intro a' o' g' hout _
  obtain ⟨rfl, rfl, rfl⟩ := outcome_pure hout
  exact h

theorem wp_mono {P : StreamParams} {F : List CallRec} {α : Type} {p : AlgM α}
    {Q Q' : α → OState → Ghost → Prop} {o : OState} {g : Ghost} (h : WP P F p Q o g)
    (hQ : ∀ a o' g', Q a o' g' → Q' a o' g') : WP P F p Q' o g :=
  fun a o' g' hout hF => hQ a o' g' (h a o' g' hout hF)

/-- Sequential composition. -/
theorem wp_bind {P : StreamParams} {F : List CallRec} {α β : Type} {p : AlgM α} {f : α → AlgM β}
    {Q : β → OState → Ghost → Prop} {o : OState} {g : Ghost}
    (h : WP P F p (fun a o' g' => WP P F (f a) Q o' g') o g) : WP P F (p.bind f) Q o g := by
  intro b o'' g'' hout hF
  obtain ⟨a, o', g', h1, h2⟩ := outcome_bind hout
  have hpre := (outcome_calls_prefix P _ _ _ _ _ _ h2).1
  exact h a o' g' h1 (hpre.trans hF) b o'' g'' h2 hF

/-- A precondition that holds of every outcome without using the log can be assumed. -/
theorem wp_intro {P : StreamParams} {F : List CallRec} {α : Type} {p : AlgM α}
    {Q : α → OState → Ghost → Prop} {o : OState} {g : Ghost}
    (h : ∀ a o' g', Outcome P p o g a o' g' → g'.calls <+: F → Q a o' g') : WP P F p Q o g := h

end F2e2e.C.Closure
