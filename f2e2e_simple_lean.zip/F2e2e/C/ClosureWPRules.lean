import Mathlib
import F2e2e.C.ClosureRows

/-!
# Theorem 6.4: weakest-precondition rules for the primitives of the controller code

One rule per primitive of `AlgM` (`F2e2e/C/Alg/AlgM.lean`) for the instrumented interpreter `runL`
(`F2e2e/C/ClosureFreeM.lean`) and the calculus of `F2e2e/C/ClosureWP.lean`. A rule reduces `WP` of
`primitive; continuation` to `WP` of the continuation from the updated oracle state and ghost data. The fresh-bit
primitives (`bankNew`, `bankValidate`, `bankRelease`) take a property of every output of the bit program
(`BitAlways`), and the bank calls also give the prefix property of the extended call log (which is how the
statistical events of the final log reach a call).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg

variable {P : StreamParams} {F : List CallRec}

theorem wp_note {α : Type} {ev : TreeEvent} {k : AlgM α} {Q : α → OState → Ghost → Prop} {o : OState}
    {g : Ghost} (h : WP P F k Q o { g with events := g.events ++ [ev] }) : WP P F (AlgM.note ev k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  exact h a o' g' ⟨tape, rest, hrun⟩ hF

theorem wp_bankOp {α : Type} {idx : ℕ} {op : RowOp} {k : AlgM α} {Q : α → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F k Q { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun l => l ++ [op]) idx g.hists }) :
    WP P F (AlgM.bankOp idx op k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  exact h a o' g' ⟨tape, rest, hrun⟩ hF

theorem wp_bankOpFrom {α : Type} {idx : ℕ} {op : RowOp} {k : AlgM α} {Q : α → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F k Q { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun l => l ++ [op]) idx g.hists }) :
    WP P F (AlgM.bankOpFrom idx op k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  exact h a o' g' ⟨tape, rest, hrun⟩ hF

theorem wp_bankRetain {α : Type} {n : ℕ} {k : AlgM α} {Q : α → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F k Q { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }) :
    WP P F (AlgM.bankRetain n k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  exact h a o' g' ⟨tape, rest, hrun⟩ hF

theorem wp_fpStep {α : Type} {i : ℕ} {Δ : ℤ} {k : Bool → AlgM α} {Q : α → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0)) Q
      { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }) :
    WP P F (AlgM.fpStep i Δ k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  exact h a o' g' ⟨tape, rest, hrun⟩ hF

theorem wp_fpInit {α : Type} {k : AlgM α} {Q : α → OState → Ghost → Prop} {o : OState} {g : Ghost}
    (h : ∀ r, WP P F k Q { o with fpSeed := r, fpVal := 0 } g) : WP P F (AlgM.fpInit k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  simp only [runL] at hrun
  obtain ⟨b, mid, -, hrun⟩ := outcome_tag_bind _ _ _ hrun
  exact h b a o' g' ⟨mid, rest, hrun⟩ hF

theorem wp_bankNew {α : Type} {tr d : ℕ} {k : AlgM α} {Q : α → OState → Ghost → Prop}
    {o : OState} {g : Ghost} {Qb : Bank → Prop} (hB : BitAlways Qb (newBank P))
    (h : ∀ B, Qb B → WP P F k Q { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }) :
    WP P F (AlgM.bankNew tr d k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  simp only [runL] at hrun
  rw [merge_bind, BitProg.run_bind] at hrun
  obtain ⟨r, hr, hrun⟩ := Option.bind_eq_some_iff.mp hrun
  rw [merge_newBankT] at hr
  exact h r.1 (hB.of_run hr) a o' g' ⟨r.2, rest, hrun⟩ hF

/-- The record of a `ValidateInterval(S, θ)` call on bank `idx` (bank `B` before the call) with certificate `c`. -/
def valRec (P : StreamParams) (g : Ghost) (idx : ℕ) (B : Bank) (S θ : ℚ) (c : AdaCert) : CallRec :=
  ⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ, S + P.omega, some (Sum.inl c)⟩

/-- The record of a `ReleaseNumerical(mode)` call on bank `idx` with the logged result `r` of `releaseLog`. -/
def relRec (g : Ghost) (idx : ℕ) (B : Bank) (mode : Mode) (r : (Option ℚ × Bank) × Option (ℚ × AdaNum)) :
    CallRec :=
  ⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode, (r.2.map Prod.fst).getD 0,
    r.2.map (fun x => Sum.inr x.2)⟩

theorem wp_bankValidate {α : Type} {idx : ℕ} {S θ : ℚ} {k : AdaCert → AlgM α}
    {Q : α → OState → Ghost → Prop} {o : OState} {g : Ghost} {B : Bank} (hB : o.banks[idx]? = some B)
    {Qv : AdaCert × Bank → Prop} (hv : BitAlways Qv (B.validate P S θ))
    (h : ∀ r : AdaCert × Bank, Qv r → g.calls ++ [valRec P g idx B S θ r.1] <+: F →
      WP P F (k r.1) Q { o with banks := setAt r.2 idx o.banks }
        { g with calls := g.calls ++ [valRec P g idx B S θ r.1] }) :
    WP P F (AlgM.bankValidate idx S θ k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  simp only [runL] at hrun
  rw [hB] at hrun
  obtain ⟨b, mid, hb, hrun⟩ := outcome_tag_bind _ _ _ hrun
  have hcont : Outcome P (k b.1) { o with banks := setAt b.2 idx o.banks }
      { g with calls := g.calls ++ [valRec P g idx B S θ b.1] } a o' g' := ⟨mid, rest, hrun⟩
  have hpre := (outcome_calls_prefix P _ _ _ _ _ _ hcont).1
  exact h b (hv.of_run hb) (hpre.trans hF) a o' g' hcont hF

theorem wp_bankRelease {α : Type} {idx : ℕ} {mode : Mode} {k : Option ℚ → AlgM α}
    {Q : α → OState → Ghost → Prop} {o : OState} {g : Ghost} {B : Bank} (hB : o.banks[idx]? = some B)
    {Qr : (Option ℚ × Bank) × Option (ℚ × AdaNum) → Prop} (hr : BitAlways Qr (releaseLog P B mode))
    (h : ∀ r : (Option ℚ × Bank) × Option (ℚ × AdaNum), Qr r → g.calls ++ [relRec g idx B mode r] <+: F →
      WP P F (k r.1.1) Q { o with banks := setAt r.1.2 idx o.banks }
        { g with calls := g.calls ++ [relRec g idx B mode r] }) :
    WP P F (AlgM.bankRelease idx mode k) Q o g := by
  intro a o' g' hout hF
  obtain ⟨tape, rest, hrun⟩ := hout
  simp only [runL] at hrun
  rw [hB] at hrun
  obtain ⟨b, mid, hb, hrun⟩ := outcome_tag_bind _ _ _ hrun
  have hcont : Outcome P (k b.1.1) { o with banks := setAt b.1.2 idx o.banks }
      { g with calls := g.calls ++ [relRec g idx B mode b] } a o' g' := ⟨mid, rest, hrun⟩
  have hpre := (outcome_calls_prefix P _ _ _ _ _ _ hcont).1
  exact h b (hr.of_run hb) (hpre.trans hF) a o' g' hcont hF

/-! ## The `M`-forms used by the controller code -/

theorem wp_noteM {β : Type} {ev : TreeEvent} {f : Unit → AlgM β} {Q : β → OState → Ghost → Prop}
    {o : OState} {g : Ghost} (h : WP P F (f ()) Q o { g with events := g.events ++ [ev] }) :
    WP P F ((noteM ev).bind f) Q o g := wp_note h

theorem wp_bankOpM {β : Type} {idx : ℕ} {op : RowOp} {f : Unit → AlgM β} {Q : β → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F (f ()) Q { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun l => l ++ [op]) idx g.hists }) :
    WP P F ((bankOpM idx op).bind f) Q o g := wp_bankOp h

theorem wp_bankOpFromM {β : Type} {idx : ℕ} {op : RowOp} {f : Unit → AlgM β}
    {Q : β → OState → Ghost → Prop} {o : OState} {g : Ghost}
    (h : WP P F (f ()) Q { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun l => l ++ [op]) idx g.hists }) :
    WP P F ((bankOpFromM idx op).bind f) Q o g := wp_bankOpFrom h

theorem wp_bankRetainM {β : Type} {n : ℕ} {f : Unit → AlgM β} {Q : β → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F (f ()) Q { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }) :
    WP P F ((bankRetainM n).bind f) Q o g := wp_bankRetain h

theorem wp_fpStepM {β : Type} {i : ℕ} {Δ : ℤ} {f : Bool → AlgM β} {Q : β → OState → Ghost → Prop}
    {o : OState} {g : Ghost}
    (h : WP P F (f (fpUpdate P o.fpSeed o.fpVal i Δ == 0)) Q
      { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }) :
    WP P F ((fpStepM i Δ).bind f) Q o g := wp_fpStep h

theorem wp_bankNewM {β : Type} {tr d : ℕ} {f : Unit → AlgM β} {Q : β → OState → Ghost → Prop}
    {o : OState} {g : Ghost} {Qb : Bank → Prop} (hB : BitAlways Qb (newBank P))
    (h : ∀ B, Qb B → WP P F (f ()) Q { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }) :
    WP P F ((bankNewM tr d).bind f) Q o g := wp_bankNew hB h

theorem wp_validateM {β : Type} {idx : ℕ} {S θ : ℚ} {f : AdaCert → AlgM β}
    {Q : β → OState → Ghost → Prop} {o : OState} {g : Ghost} {B : Bank} (hB : o.banks[idx]? = some B)
    {Qv : AdaCert × Bank → Prop} (hv : BitAlways Qv (B.validate P S θ))
    (h : ∀ r : AdaCert × Bank, Qv r → g.calls ++ [valRec P g idx B S θ r.1] <+: F →
      WP P F (f r.1) Q { o with banks := setAt r.2 idx o.banks }
        { g with calls := g.calls ++ [valRec P g idx B S θ r.1] }) :
    WP P F ((validateM idx S θ).bind f) Q o g := wp_bankValidate hB hv h

theorem wp_releaseM {β : Type} {idx : ℕ} {mode : Mode} {f : Option ℚ → AlgM β}
    {Q : β → OState → Ghost → Prop} {o : OState} {g : Ghost} {B : Bank} (hB : o.banks[idx]? = some B)
    {Qr : (Option ℚ × Bank) × Option (ℚ × AdaNum) → Prop} (hr : BitAlways Qr (releaseLog P B mode))
    (h : ∀ r : (Option ℚ × Bank) × Option (ℚ × AdaNum), Qr r → g.calls ++ [relRec g idx B mode r] <+: F →
      WP P F (f r.1.1) Q { o with banks := setAt r.1.2 idx o.banks }
        { g with calls := g.calls ++ [relRec g idx B mode r] }) :
    WP P F ((releaseM idx mode).bind f) Q o g := wp_bankRelease hB hr h

theorem wp_pure_bind {α β : Type} {a : α} {f : α → AlgM β} {Q : β → OState → Ghost → Prop} {o : OState}
    {g : Ghost} (h : WP P F (f a) Q o g) : WP P F ((AlgM.pure a).bind f) Q o g := h

theorem wp_ite {α : Type} {c : Prop} [Decidable c] {p q : AlgM α} {Q : α → OState → Ghost → Prop} {o : OState}
    {g : Ghost} (hp : c → WP P F p Q o g) (hq : ¬ c → WP P F q Q o g) : WP P F (if c then p else q) Q o g := by
  split_ifs with hc
  · exact hp hc
  · exact hq hc

end F2e2e.C.Closure
