import F2e2e.C.ClosureEvents
import F2e2e.C.FingerprintAlg

/-!
# Theorem 6.4, probability layer: bank-label invariants of the instrumented run

Helpers for `F2e2e/C/ClosureProbLabels.lean` (C-PROB's bank labels; paper: `parts/partIII.tex` L1281–1285
"At most `2m(H+1)` bank labels can ever be born, and their birth schedule is independent of corrections";
Definition `R:def:binary-tree-architecture` (2), L432; Algorithm `R:alg:regularized-norm-bank` L206).

The controller code (C-ALG's `initCode`, `roundCode`, `F2e2e/C/Alg/AlgMCode.lean`) allocates banks only by
`bankNew 0 0` at initialization and by `bankNew tr d` (`tr = t + 1`, `d + 2 ≤ H`, increasing `d`) in Step 1 of
round `t`. Along every execution of the instrumented interpreter `runL` (`F2e2e/C/ClosureFreeM.lean`) we keep the
invariant `LabInv P L b o g`:

* the ghost labels are parallel to the banks;
* every live label and every recorded call label satisfies `L` and is lexicographically below the bound `b`
  (the next label that may be born; so every label is born at most once);
* for every label `lab`: (number of consuming releases of `lab` so far) + (remaining coarse groups of the live
  banks labelled `lab`) `≤ R_max` (a fresh bank has `R_max` groups, a consuming release pops one, nothing else
  changes the number of groups).

* `NoNewR Q p`: `p` allocates no bank and every result satisfies `Q`; Steps 2–4 are such programs
  (`noNewR_step2Code`, `noNewR_step3Code`, `noNewR_step4Code`, …), and they keep `LabInv` (`runL_noNewR`);
* `birthCode_labInv`, `birthLoopCode_labInv`, `step1Code_labInv`: the births of Step 1;
* `roundCode_labInv`, `initCode_labInv`: one round (the bound goes from `(t+1, 0)` to `(t+2, 0)`, the round
  counter from `t` to `t+1`) and the initialization;
* `run_labInv`: the invariant on the instrumented canonical run.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg

/-! ### Local copies of generic helpers

(The same statements as in C-CLOSE's `F2e2e/C/ClosureRows.lean` / `ClosureWP.lean`, kept here so that the
probability layer does not depend on those files; every-path predicates are C-FP's `FP.BPAll`.) -/

namespace LabAux

theorem length_modifyAt {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (modifyAt f k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [modifyAt]
  | k + 1, _ :: l => by simp [modifyAt, length_modifyAt f k l]

theorem length_mapFrom {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (mapFrom f k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [mapFrom, length_mapFrom f 0 l]
  | k + 1, _ :: l => by simp [mapFrom, length_mapFrom f k l]

theorem length_setAt {α : Type} (b : α) : ∀ (k : ℕ) (l : List α), (setAt b k l).length = l.length
  | k, [] => by cases k <;> rfl
  | 0, _ :: l => by simp [setAt]
  | k + 1, _ :: l => by simp [setAt, length_setAt b k l]

theorem getElem?_modifyAt {α : Type} (f : α → α) :
    ∀ (k j : ℕ) (l : List α), (modifyAt f k l)[j]? = if j = k then l[j]?.map f else l[j]?
  | _, _, [] => by simp [modifyAt]
  | 0, 0, a :: l => by simp [modifyAt]
  | 0, j + 1, a :: l => by simp [modifyAt]
  | k + 1, 0, a :: l => by simp [modifyAt]
  | k + 1, j + 1, a :: l => by
    simp only [modifyAt, List.getElem?_cons_succ, getElem?_modifyAt f k j l, Nat.add_right_cancel_iff]

theorem getElem?_mapFrom {α : Type} (f : α → α) :
    ∀ (k j : ℕ) (l : List α), (mapFrom f k l)[j]? = if k ≤ j then l[j]?.map f else l[j]?
  | _, _, [] => by simp [mapFrom]
  | 0, 0, a :: l => by simp [mapFrom]
  | 0, j + 1, a :: l => by
    simp only [mapFrom, List.getElem?_cons_succ, getElem?_mapFrom f 0 j l]
    simp
  | k + 1, 0, a :: l => by simp [mapFrom]
  | k + 1, j + 1, a :: l => by
    simp only [mapFrom, List.getElem?_cons_succ, getElem?_mapFrom f k j l, Nat.add_le_add_iff_right]

theorem getElem?_setAt {α : Type} (b : α) :
    ∀ (k j : ℕ) (l : List α), (setAt b k l)[j]? = if j = k ∧ j < l.length then some b else l[j]?
  | _, _, [] => by simp [setAt]
  | 0, 0, a :: l => by simp [setAt]
  | 0, j + 1, a :: l => by simp [setAt]
  | k + 1, 0, a :: l => by simp [setAt]
  | k + 1, j + 1, a :: l => by
    simp only [setAt, List.getElem?_cons_succ, getElem?_setAt b k j l, Nat.add_right_cancel_iff,
      List.length_cons, Nat.add_lt_add_iff_right]

theorem runL_bind (P : StreamParams) {α β : Type} (f : α → AlgM β) :
    ∀ (p : AlgM α) (o : OState) (g : Ghost),
      runL P (p.bind f) o g = (runL P p o g).bind fun r => runL P (f r.1) r.2.1 r.2.2
  | AlgM.pure _, _, _ => rfl
  | AlgM.fpInit k, o, g => by
    simp only [AlgM.bind, runL, TBitProg.bind_assoc]
    congr 1; funext r; exact runL_bind P f k _ _
  | AlgM.fpStep i Δ k, o, g => by
    simp only [AlgM.bind, runL]; exact runL_bind P f (k _) _ _
  | AlgM.bankNew tr d k, o, g => by
    simp only [AlgM.bind, runL, TBitProg.bind_assoc]
    congr 1; funext B; exact runL_bind P f k _ _
  | AlgM.bankRetain n k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankOp idx op k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankOpFrom idx op k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _
  | AlgM.bankValidate idx S θ k, o, g => by
    simp only [AlgM.bind, runL]
    cases o.banks[idx]? with
    | none => exact runL_bind P f (k _) _ _
    | some B =>
      simp only [TBitProg.bind_assoc]
      congr 1; funext r; exact runL_bind P f (k _) _ _
  | AlgM.bankRelease idx mode k, o, g => by
    simp only [AlgM.bind, runL]
    cases o.banks[idx]? with
    | none => exact runL_bind P f (k _) _ _
    | some B =>
      simp only [TBitProg.bind_assoc]
      congr 1; funext r; exact runL_bind P f (k _) _ _
  | AlgM.note ev k, o, g => by simp only [AlgM.bind, runL]; exact runL_bind P f k _ _

theorem bpAll_validate (P : StreamParams) (B : Bank) (S θ : ℚ) :
    FP.BPAll (B.validate P S θ) (fun r => r.2.coarse = B.coarse) := by
  unfold Bank.validate
  simp only [bp_bind_eq, bp_pure_eq]
  refine FP.BPAll.bind (fun res _ => ?_) (FP.BPAll.true _)
  exact FP.BPAll.pure rfl

theorem releaseLog_nil (P : StreamParams) (B : Bank) (mode : Mode) (h : B.coarse = []) :
    releaseLog P B mode = BitProg.pure ((none, B), none) := by
  unfold releaseLog; rw [h]

theorem releaseLog_cons (P : StreamParams) (B : Bank) (mode : Mode) {grp : List (List Row)}
    {rest : List (List (List Row))} (h : B.coarse = grp :: rest) :
    releaseLog P B mode =
      (adaNumerical (bankAda P) B.adaSt
          (adaVals P mode (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) B)).bind
        fun res =>
          match res.1 with
          | AdaNum.val μ =>
            BitProg.pure ((some (max 0 ((P.L : ℚ) *
                (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) * μ - P.omega)),
                { B with coarse := rest, adaSt := res.2 }),
              some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1))
          | AdaNum.abort =>
            BitProg.pure ((none, { B with coarse := rest, adaSt := res.2 }),
              some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1)) := by
  unfold releaseLog; rw [h]; rfl

theorem bpAll_releaseLog (P : StreamParams) (B : Bank) (mode : Mode) :
    FP.BPAll (releaseLog P B mode) (fun r => r.1.2.coarse = B.coarse.tail) := by
  cases h : B.coarse with
  | nil =>
    rw [releaseLog_nil P B mode h]
    exact FP.BPAll.pure (by simp [h])
  | cons grp rest =>
    rw [releaseLog_cons P B mode h]
    refine FP.BPAll.bind (fun res _ => ?_) (FP.BPAll.true _)
    rcases res with ⟨out, st⟩
    cases out with
    | val μ => exact FP.BPAll.pure (by simp)
    | abort => exact FP.BPAll.pure (by simp)

theorem bpAll_sampleList_length {α : Type} (p : BitProg α) :
    ∀ k, FP.BPAll (sampleList p k) (fun l => l.length = k)
  | 0 => FP.BPAll.pure rfl
  | k + 1 => by
    rw [sampleList_succ]
    exact FP.BPAll.bind (fun _ _ => FP.BPAll.bind (fun l hl => FP.BPAll.pure (by simp [hl]))
      (bpAll_sampleList_length p k)) (FP.BPAll.true _)

end LabAux

/-! ### Lexicographic order on labels -/

/-- `l` is lexicographically below `b`. -/
def LabLT (l b : BankLabel) : Prop := l.1 < b.1 ∨ (l.1 = b.1 ∧ l.2 < b.2)

/-- `b` is lexicographically at most `b'`. -/
def LabLE (b b' : BankLabel) : Prop := b.1 < b'.1 ∨ (b.1 = b'.1 ∧ b.2 ≤ b'.2)

theorem LabLT.trans_le {l b b' : BankLabel} (h1 : LabLT l b) (h2 : LabLE b b') : LabLT l b' := by
  unfold LabLT LabLE at *
  omega

theorem LabLT.ne {l b : BankLabel} (h : LabLT l b) : l ≠ b := by
  rintro rfl
  unfold LabLT at h
  omega

/-! ### Programs without bank allocation, with a postcondition on the result -/

/-- `NoNewR Q p`: the program `p` makes no `bankNew` call and every result satisfies `Q`. -/
def NoNewR {α : Type} (Q : α → Prop) : AlgM α → Prop
  | AlgM.pure a => Q a
  | AlgM.fpInit k => NoNewR Q k
  | AlgM.fpStep _ _ k => ∀ b, NoNewR Q (k b)
  | AlgM.bankNew _ _ _ => False
  | AlgM.bankRetain _ k => NoNewR Q k
  | AlgM.bankOp _ _ k => NoNewR Q k
  | AlgM.bankOpFrom _ _ k => NoNewR Q k
  | AlgM.bankValidate _ _ _ k => ∀ c, NoNewR Q (k c)
  | AlgM.bankRelease _ _ k => ∀ o, NoNewR Q (k o)
  | AlgM.note _ k => NoNewR Q k

theorem NoNewR.bind' {α β : Type} {R : α → Prop} {Q : β → Prop} {f : α → AlgM β}
    (hf : ∀ a, R a → NoNewR Q (f a)) : ∀ (p : AlgM α), NoNewR R p → NoNewR Q (p.bind f)
  | AlgM.pure a, h => hf a h
  | AlgM.fpInit k, h => NoNewR.bind' hf k h
  | AlgM.fpStep _ _ k, h => fun b => NoNewR.bind' hf (k b) (h b)
  | AlgM.bankNew _ _ _, h => False.elim h
  | AlgM.bankRetain _ k, h => NoNewR.bind' hf k h
  | AlgM.bankOp _ _ k, h => NoNewR.bind' hf k h
  | AlgM.bankOpFrom _ _ k, h => NoNewR.bind' hf k h
  | AlgM.bankValidate _ _ _ k, h => fun c => NoNewR.bind' hf (k c) (h c)
  | AlgM.bankRelease _ _ k, h => fun o => NoNewR.bind' hf (k o) (h o)
  | AlgM.note _ k, h => NoNewR.bind' hf k h

theorem NoNewR.bind {α β : Type} {R : α → Prop} {Q : β → Prop} {p : AlgM α} {f : α → AlgM β}
    (hp : NoNewR R p) (hf : ∀ a, R a → NoNewR Q (f a)) : NoNewR Q (p.bind f) :=
  NoNewR.bind' hf p hp

theorem NoNewR.mono' {α : Type} {Q Q' : α → Prop} (hQ : ∀ a, Q a → Q' a) :
    ∀ (p : AlgM α), NoNewR Q p → NoNewR Q' p
  | AlgM.pure a, h => hQ a h
  | AlgM.fpInit k, h => NoNewR.mono' hQ k h
  | AlgM.fpStep _ _ k, h => fun b => NoNewR.mono' hQ (k b) (h b)
  | AlgM.bankNew _ _ _, h => False.elim h
  | AlgM.bankRetain _ k, h => NoNewR.mono' hQ k h
  | AlgM.bankOp _ _ k, h => NoNewR.mono' hQ k h
  | AlgM.bankOpFrom _ _ k, h => NoNewR.mono' hQ k h
  | AlgM.bankValidate _ _ _ k, h => fun c => NoNewR.mono' hQ (k c) (h c)
  | AlgM.bankRelease _ _ k, h => fun o => NoNewR.mono' hQ (k o) (h o)
  | AlgM.note _ k, h => NoNewR.mono' hQ k h

theorem NoNewR.mono {α : Type} {Q Q' : α → Prop} {p : AlgM α} (h : NoNewR Q p)
    (hQ : ∀ a, Q a → Q' a) : NoNewR Q' p :=
  NoNewR.mono' hQ p h

@[simp] theorem noNewR_ite {α : Type} (Q : α → Prop) (c : Prop) [Decidable c] (a b : AlgM α) :
    NoNewR Q (if c then a else b) ↔ (c → NoNewR Q a) ∧ (¬c → NoNewR Q b) := by
  by_cases h : c <;> simp [h]

/-! ### Steps 2–4 allocate no bank and keep the round counter -/

theorem ite_fst' {α β : Type} (c : Prop) [Decidable c] (a b : α × β) :
    (if c then a else b).1 = if c then a.1 else b.1 := by
  split_ifs <;> rfl

theorem ite_cstate_t (c : Prop) [Decidable c] (a b : CState) :
    (if c then a else b).t = if c then a.t else b.t := by
  split_ifs <;> rfl

theorem noNewR_step2Code (P : StreamParams) (i : ℕ) (Δ : ℤ) (c : CState) :
    NoNewR (fun r : CState × Bool => r.1.t = c.t) (step2Code P i Δ c) := by
  simp [step2Code, fpStepM, bankOpFromM, noteM, AlgM.bind, NoNewR, CState.fail, ite_fst',
    ite_cstate_t]

theorem noNewR_step3DepthCode (P : StreamParams) (tr : ℕ) (c : CState) (d : ℕ) :
    NoNewR (fun c' : CState => c'.t = c.t) (step3DepthCode P tr c d) := by
  unfold step3DepthCode
  split
  · simp [NoNewR, CState.fail]
  · simp [bankOpM, bankOpFromM, noteM, AlgM.bind, NoNewR, CState.fail, ite_cstate_t]

theorem noNewR_step3LoopCode (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (c : CState), NoNewR (fun c' : CState => c'.t = c.t) (step3LoopCode P tr ds c)
  | [], c => by simp [step3LoopCode, NoNewR]
  | d :: ds, c => by
    simp only [step3LoopCode]
    split_ifs
    · simp [NoNewR]
    · exact NoNewR.bind (noNewR_step3DepthCode P tr c d) fun c' hc' =>
        (noNewR_step3LoopCode P tr ds c').mono fun c'' h => h.trans hc'

theorem noNewR_step3Code (P : StreamParams) (c : CState) :
    NoNewR (fun c' : CState => c'.t = c.t) (step3Code P c) :=
  noNewR_step3LoopCode P _ _ _

theorem noNewR_rejectTailCode (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ)
    (c : CState) : NoNewR (fun r : CState × ℚ => r.1.t = c.t) (rejectTailCode P d Ld cInt N1 c) := by
  simp only [rejectTailCode, bankOpFromM, noteM, releaseM, AlgM.bind_eq, AlgM.pure_eq, AlgM.bind,
    NoNewR, noNewR_ite]
  refine ⟨fun _ o => ?_, fun _ => ?_⟩
  · rcases o with _ | N2
    · simp [NoNewR, CState.fail]
    · simp only
      split <;> simp [NoNewR, CState.fail, ite_fst', ite_cstate_t]
  · simp [CState.fail]

theorem noNewR_rejectDepthCode (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (c : CState) :
    NoNewR (fun r : CState × ℚ => r.1.t = c.t) (rejectDepthCode P d pos Qhat c) := by
  unfold rejectDepthCode
  split
  · simp [NoNewR, CState.fail]
  · simp [releaseM, bankOpM, AlgM.bind, NoNewR, Option.forall, CState.fail, noNewR_rejectTailCode]

theorem noNewR_step4DepthCode (P : StreamParams) (d : ℕ) (c : CState) (F : ℚ) :
    NoNewR (fun r : CState × ℚ => r.1.t = c.t) (step4DepthCode P d c F) := by
  unfold step4DepthCode
  split
  · simp [NoNewR, CState.fail]
  · simp [validateM, noteM, AlgM.bind, NoNewR, FP.adaCert_forall, CState.fail,
      noNewR_rejectDepthCode]

theorem noNewR_step4LoopCode (P : StreamParams) :
    ∀ (ds : List ℕ) (c : CState) (F : ℚ),
      NoNewR (fun r : CState × ℚ => r.1.t = c.t) (step4LoopCode P ds c F)
  | [], c, F => by simp [step4LoopCode, NoNewR]
  | d :: ds, c, F => by
    simp only [step4LoopCode]
    split_ifs
    · simp [NoNewR]
    · exact NoNewR.bind (noNewR_step4DepthCode P d c F) fun r hr =>
        (noNewR_step4LoopCode P ds r.1 r.2).mono fun r' h => h.trans hr

theorem noNewR_step4Code (P : StreamParams) (c : CState) :
    NoNewR (fun r : CState × ℚ => r.1.t = c.t) (step4Code P c) :=
  noNewR_step4LoopCode P _ _ _

theorem noNewR_fpTail3 (P : StreamParams) (c3 : CState) :
    NoNewR (fun r : CState × ℚ => r.1.t = c3.t + 1) (FP.fpTail3 P c3) := by
  unfold FP.fpTail3
  split_ifs
  · simp [NoNewR, finishC]
  · exact NoNewR.bind (noNewR_step4Code P c3) fun r4 h4 => by simp [NoNewR, finishC, h4]

theorem noNewR_fpTail2 (P : StreamParams) (r2 : CState × Bool) :
    NoNewR (fun r : CState × ℚ => r.1.t = r2.1.t + 1) (FP.fpTail2 P r2) := by
  unfold FP.fpTail2
  split_ifs
  · simp [NoNewR, finishC]
  · exact NoNewR.bind (noNewR_step3Code P r2.1) fun c3 h3 =>
      (noNewR_fpTail3 P c3).mono fun r hr => by rw [hr, h3]

/-! ### The invariant -/

/-- The number of remaining coarse groups of the live bank at index `idx`, if its label is `lab`. -/
def labLiveAt (lab : BankLabel) (o : OState) (g : Ghost) (idx : ℕ) : ℕ :=
  (o.banks[idx]?.map fun B => if g.labelAt idx = lab then B.coarse.length else 0).getD 0

/-- The remaining coarse groups of the live banks labelled `lab`. -/
def labLive (lab : BankLabel) (o : OState) (g : Ghost) : ℕ :=
  ∑ idx ∈ Finset.range o.banks.length, labLiveAt lab o g idx

/-- **The label invariant** (see the module docstring). -/
structure LabInv (P : StreamParams) (L : BankLabel → Prop) (b : BankLabel) (o : OState) (g : Ghost) :
    Prop where
  len : g.labels.length = o.banks.length
  labels_mem : ∀ l ∈ g.labels, L l ∧ LabLT l b
  calls_mem : ∀ rec ∈ g.calls, L rec.lab ∧ LabLT rec.lab b
  count : ∀ lab, (coarseRecs lab g).length + labLive lab o g ≤ P.Rmax

theorem labelAt_mem {g : Ghost} {idx : ℕ} (h : idx < g.labels.length) : g.labelAt idx ∈ g.labels := by
  unfold Ghost.labelAt
  rw [List.getD_eq_getElem _ _ h]
  exact List.getElem_mem h

section Pres

variable {P : StreamParams} {L : BankLabel → Prop} {b : BankLabel} {o : OState} {g : Ghost}

theorem LabInv.mono (h : LabInv P L b o g) {b' : BankLabel} (hb : LabLE b b') : LabInv P L b' o g where
  len := h.len
  labels_mem l hl := ⟨(h.labels_mem l hl).1, (h.labels_mem l hl).2.trans_le hb⟩
  calls_mem rec hr := ⟨(h.calls_mem rec hr).1, (h.calls_mem rec hr).2.trans_le hb⟩
  count := h.count

theorem labLive_congr {lab : BankLabel} {o' : OState} {g' : Ghost} (hb : o'.banks = o.banks)
    (hl : g'.labels = g.labels) : labLive lab o' g' = labLive lab o g := by
  unfold labLive labLiveAt Ghost.labelAt
  rw [hb, hl]

theorem coarseRecs_congr {lab : BankLabel} {g' : Ghost} (hc : g'.calls = g.calls) :
    coarseRecs lab g' = coarseRecs lab g := by
  unfold coarseRecs
  rw [hc]

theorem LabInv.congr (h : LabInv P L b o g) {o' : OState} {g' : Ghost} (hb : o'.banks = o.banks)
    (hl : g'.labels = g.labels) (hc : g'.calls = g.calls) : LabInv P L b o' g' where
  len := by rw [hb, hl]; exact h.len
  labels_mem := by rw [hl]; exact h.labels_mem
  calls_mem := by rw [hc]; exact h.calls_mem
  count lab := by rw [coarseRecs_congr hc, labLive_congr hb hl]; exact h.count lab

theorem LabInv.retain (h : LabInv P L b o g) (n : ℕ) :
    LabInv P L b { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n } where
  len := by simp [h.len]
  labels_mem l hl := h.labels_mem l (List.mem_of_mem_take hl)
  calls_mem := h.calls_mem
  count lab := by
    refine le_trans ?_ (h.count lab)
    have hc : coarseRecs lab ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost) =
        coarseRecs lab g := rfl
    rw [hc]
    refine Nat.add_le_add_left ?_ _
    unfold labLive
    simp only [List.length_take]
    calc ∑ idx ∈ Finset.range (min n o.banks.length), labLiveAt lab { o with banks := o.banks.take n }
          { g with labels := g.labels.take n, hists := g.hists.take n } idx
        = ∑ idx ∈ Finset.range (min n o.banks.length), labLiveAt lab o g idx := by
          refine Finset.sum_congr rfl fun idx hidx => ?_
          have hn : idx < n := lt_of_lt_of_le (Finset.mem_range.mp hidx) (min_le_left _ _)
          unfold labLiveAt Ghost.labelAt
          simp only [List.getElem?_take, if_pos hn, List.getD_eq_getElem?_getD]
      _ ≤ ∑ idx ∈ Finset.range o.banks.length, labLiveAt lab o g idx :=
          Finset.sum_le_sum_of_subset (Finset.range_mono (min_le_right _ _))

theorem LabInv.bankOp (h : LabInv P L b o g) (idx : ℕ) (op : RowOp) :
    LabInv P L b { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } where
  len := by simp [h.len]
  labels_mem := h.labels_mem
  calls_mem := h.calls_mem
  count lab := by
    have hl : labLive lab { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
        { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } = labLive lab o g := by
      unfold labLive
      simp only [LabAux.length_modifyAt]
      refine Finset.sum_congr rfl fun j _ => ?_
      unfold labLiveAt Ghost.labelAt
      simp only [LabAux.getElem?_modifyAt]
      split_ifs <;> cases o.banks[j]? <;> simp [Bank.mapRows]
    rw [hl]
    exact h.count lab

theorem LabInv.bankOpFrom (h : LabInv P L b o g) (idx : ℕ) (op : RowOp) :
    LabInv P L b { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists } where
  len := by simp [h.len]
  labels_mem := h.labels_mem
  calls_mem := h.calls_mem
  count lab := by
    have hl : labLive lab { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
        { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists } = labLive lab o g := by
      unfold labLive
      simp only [LabAux.length_mapFrom]
      refine Finset.sum_congr rfl fun j _ => ?_
      unfold labLiveAt Ghost.labelAt
      simp only [LabAux.getElem?_mapFrom]
      split_ifs <;> cases o.banks[j]? <;> simp [Bank.mapRows]
    rw [hl]
    exact h.count lab

/-- A sum over `range n` of a function changed at one index `idx < n`. -/
theorem sum_range_modify (n idx : ℕ) (h : idx < n) (f f' : ℕ → ℕ) (hf : ∀ j, j ≠ idx → f' j = f j) :
    (∑ j ∈ Finset.range n, f' j) + f idx = (∑ j ∈ Finset.range n, f j) + f' idx := by
  have hm : idx ∈ Finset.range n := Finset.mem_range.mpr h
  have h1 := Finset.add_sum_erase (Finset.range n) f' hm
  have h2 := Finset.add_sum_erase (Finset.range n) f hm
  have h3 : ∑ j ∈ (Finset.range n).erase idx, f' j = ∑ j ∈ (Finset.range n).erase idx, f j :=
    Finset.sum_congr rfl fun j hj => hf j (Finset.ne_of_mem_erase hj)
  linarith

/-- `setAt` at a valid index changes the live groups only at that index. -/
theorem labLiveAt_setAt_of_ne {lab : BankLabel} {idx j : ℕ} (B' : Bank) {g' : Ghost}
    (hl : g'.labels = g.labels) (hj : j ≠ idx) :
    labLiveAt lab { o with banks := setAt B' idx o.banks } g' j = labLiveAt lab o g j := by
  unfold labLiveAt Ghost.labelAt
  rw [hl]
  simp only [LabAux.getElem?_setAt]
  rw [if_neg (fun h => hj h.1)]

theorem labLiveAt_setAt_self {lab : BankLabel} {idx : ℕ} {B : Bank} (B' : Bank) {g' : Ghost}
    (hl : g'.labels = g.labels) (hB : o.banks[idx]? = some B) :
    labLiveAt lab { o with banks := setAt B' idx o.banks } g' idx =
      if g.labelAt idx = lab then B'.coarse.length else 0 := by
  have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  unfold labLiveAt Ghost.labelAt
  rw [hl]
  simp only [LabAux.getElem?_setAt, hlt, and_self, if_true, Option.map_some, Option.getD_some]

theorem labLiveAt_self {lab : BankLabel} {idx : ℕ} {B : Bank} (hB : o.banks[idx]? = some B) :
    labLiveAt lab o g idx = if g.labelAt idx = lab then B.coarse.length else 0 := by
  unfold labLiveAt
  rw [hB]
  rfl

theorem LabInv.validate (h : LabInv P L b o g) {idx : ℕ} {B B' : Bank} (hB : o.banks[idx]? = some B)
    (hco : B'.coarse = B.coarse) (rec : CallRec) (hlab : rec.lab = g.labelAt idx) {S θ : ℚ}
    (hkind : rec.kind = CallKind.validate S θ) :
    LabInv P L b { o with banks := setAt B' idx o.banks } { g with calls := g.calls ++ [rec] } where
  len := by simp [h.len]
  labels_mem := h.labels_mem
  calls_mem r hr := by
    rcases List.mem_append.mp hr with hr | hr
    · exact h.calls_mem r hr
    · rw [List.mem_singleton] at hr
      subst hr
      have hlt : idx < g.labels.length := by
        rw [h.len]; exact (List.getElem?_eq_some_iff.mp hB).1
      rw [hlab]
      exact h.labels_mem _ (labelAt_mem hlt)
  count lab := by
    have hrecs : coarseRecs lab ({ g with calls := g.calls ++ [rec] } : Ghost) = coarseRecs lab g := by
      unfold coarseRecs
      simp [List.filter_append, hkind]
    have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
    have hl : labLive lab { o with banks := setAt B' idx o.banks } { g with calls := g.calls ++ [rec] } =
        labLive lab o g := by
      unfold labLive
      simp only [LabAux.length_setAt]
      refine Finset.sum_congr rfl fun j _ => ?_
      by_cases hj : j = idx
      · subst hj
        rw [labLiveAt_setAt_self (g := g) (g' := { g with calls := g.calls ++ [rec] }) B' rfl hB,
          labLiveAt_self hB, hco]
      · exact labLiveAt_setAt_of_ne B' rfl hj
    rw [hrecs, hl]
    exact h.count lab

theorem LabInv.release (h : LabInv P L b o g) {idx : ℕ} {B B' : Bank} (hB : o.banks[idx]? = some B)
    (hco : B'.coarse = B.coarse.tail) (rec : CallRec) (hlab : rec.lab = g.labelAt idx)
    (hbank : rec.bank = B) {mode : Mode} (hkind : rec.kind = CallKind.release mode) :
    LabInv P L b { o with banks := setAt B' idx o.banks } { g with calls := g.calls ++ [rec] } where
  len := by simp [h.len]
  labels_mem := h.labels_mem
  calls_mem r hr := by
    rcases List.mem_append.mp hr with hr | hr
    · exact h.calls_mem r hr
    · rw [List.mem_singleton] at hr
      subst hr
      have hlt : idx < g.labels.length := by
        rw [h.len]; exact (List.getElem?_eq_some_iff.mp hB).1
      rw [hlab]
      exact h.labels_mem _ (labelAt_mem hlt)
  count lab := by
    have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
    have hrecs : (coarseRecs lab ({ g with calls := g.calls ++ [rec] } : Ghost)).length =
        (coarseRecs lab g).length + (if g.labelAt idx = lab ∧ B.coarse ≠ [] then 1 else 0) := by
      unfold coarseRecs
      rw [List.filter_append, List.length_append]
      congr 1
      by_cases h1 : g.labelAt idx = lab <;> by_cases h2 : B.coarse = [] <;>
        simp [h1, h2, hkind, hbank, hlab]
    have hsum := sum_range_modify o.banks.length idx hlt (labLiveAt lab o g)
      (labLiveAt lab { o with banks := setAt B' idx o.banks } { g with calls := g.calls ++ [rec] })
      (fun j hj => labLiveAt_setAt_of_ne (g := g) B' rfl hj)
    rw [labLiveAt_setAt_self (g := g) (g' := { g with calls := g.calls ++ [rec] }) B' rfl hB,
      labLiveAt_self hB, hco] at hsum
    have hc := h.count lab
    unfold labLive at hc ⊢
    simp only [LabAux.length_setAt]
    rw [hrecs]
    by_cases h1 : g.labelAt idx = lab
    · cases hcB : B.coarse with
      | nil =>
        simp only [h1, hcB, if_true, List.tail_nil, List.length_nil, ne_eq, not_true_eq_false,
          and_false, if_false] at hsum ⊢
        omega
      | cons x xs =>
        simp only [h1, hcB, if_true, List.tail_cons, List.length_cons, ne_eq, reduceCtorEq,
          not_false_eq_true, and_self] at hsum ⊢
        omega
    · simp only [h1, if_false, false_and] at hsum ⊢
      omega

theorem LabInv.bankNew (h : LabInv P L b o g) {tr d : ℕ} (hb : LabLE b (tr, d)) (hL : L (tr, d))
    (B : Bank) (hB : B.coarse.length = P.Rmax) :
    LabInv P L (tr, d + 1) { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } where
  len := by simp [h.len]
  labels_mem l hl := by
    have hb' : LabLE b (tr, d + 1) := by unfold LabLE at *; omega
    rcases List.mem_append.mp hl with hl | hl
    · exact ⟨(h.labels_mem l hl).1, (h.labels_mem l hl).2.trans_le hb'⟩
    · rw [List.mem_singleton] at hl
      subst hl
      exact ⟨hL, Or.inr ⟨rfl, Nat.lt_succ_self d⟩⟩
  calls_mem rec hr := by
    have hb' : LabLE b (tr, d + 1) := by unfold LabLE at *; omega
    exact ⟨(h.calls_mem rec hr).1, (h.calls_mem rec hr).2.trans_le hb'⟩
  count lab := by
    have hrecs : coarseRecs lab ({ g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } :
        Ghost) = coarseRecs lab g := rfl
    rw [hrecs]
    have hlive : labLive lab { o with banks := o.banks ++ [B] }
        { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } =
        labLive lab o g + (if (tr, d) = lab then B.coarse.length else 0) := by
      unfold labLive
      rw [List.length_append, List.length_singleton, Finset.sum_range_succ]
      congr 1
      · refine Finset.sum_congr rfl fun j hj => ?_
        have hj' := Finset.mem_range.mp hj
        unfold labLiveAt Ghost.labelAt
        simp only
        rw [List.getElem?_append_left hj', List.getD_append _ _ _ _ (by rw [h.len]; exact hj')]
      · unfold labLiveAt Ghost.labelAt
        simp only
        rw [List.getElem?_append_right (le_refl _), Nat.sub_self,
          List.getD_append_right _ _ _ _ (by rw [h.len]), h.len, Nat.sub_self]
        simp
    rw [hlive]
    by_cases hl : (tr, d) = lab
    · subst hl
      have h0 : coarseRecs (tr, d) g = [] := by
        unfold coarseRecs
        rw [List.filter_eq_nil_iff]
        intro rec hr
        have hne := ((h.calls_mem rec hr).2.trans_le hb).ne
        simp [hne]
      have h1 : labLive (tr, d) o g = 0 := by
        unfold labLive
        refine Finset.sum_eq_zero fun j _ => ?_
        unfold labLiveAt
        cases hj' : o.banks[j]? with
        | none => rfl
        | some B0 =>
          have hjl : j < g.labels.length := by
            rw [h.len]; exact (List.getElem?_eq_some_iff.mp hj').1
          have hne := ((h.labels_mem _ (labelAt_mem hjl)).2.trans_le hb).ne
          simp [hne]
      rw [h0, h1, if_pos rfl, hB]
      simp
    · rw [if_neg hl, add_zero]
      exact h.count lab

end Pres

theorem bpAll_newBank_coarse (P : StreamParams) :
    FP.BPAll (newBank P) (fun B : Bank => B.coarse.length = P.Rmax) := by
  have hnb : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
      (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind fun coarse =>
        (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl
  rw [hnb]
  refine FP.BPAll.bind (fun ada _ => ?_) (FP.BPAll.true _)
  refine FP.BPAll.bind (fun coarse hco => ?_)
    (LabAux.bpAll_sampleList_length (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax)
  refine FP.BPAll.bind (fun st _ => ?_) (FP.BPAll.true _)
  exact FP.BPAll.pure hco

/-! ### Programs without bank allocation keep the invariant -/

theorem runL_pure_bitAlways {α : Type} {Q : α × OState × Ghost → Prop} (P : StreamParams) (a : α)
    (o : OState) (g : Ghost) (h : Q (a, o, g)) : FP.BPAll (runL P (AlgM.pure a) o g).merge Q :=
  FP.BPAll.pure h

theorem runL_noNewR (P : StreamParams) (L : BankLabel → Prop) (b : BankLabel) {α : Type}
    {Q : α → Prop} : ∀ (p : AlgM α) (o : OState) (g : Ghost), NoNewR Q p → LabInv P L b o g →
      FP.BPAll (runL P p o g).merge (fun r => LabInv P L b r.2.1 r.2.2 ∧ Q r.1)
  | AlgM.pure a, o, g, hp, h => by
    simp only [runL, merge_pure]
    exact FP.BPAll.pure ⟨h, hp⟩
  | AlgM.fpInit k, o, g, hp, h => by
    simp only [runL, merge_bind, merge_tag]
    exact FP.BPAll.bind (fun r _ => runL_noNewR P L b k { o with fpSeed := r, fpVal := 0 } g hp
      (h.congr rfl rfl rfl)) (FP.BPAll.true _)
  | AlgM.fpStep i Δ k, o, g, hp, h => by
    simp only [runL]
    exact runL_noNewR P L b _ _ _ (hp _) (h.congr rfl rfl rfl)
  | AlgM.bankNew _ _ _, _, _, hp, _ => False.elim hp
  | AlgM.bankRetain n k, o, g, hp, h => by
    simp only [runL]
    exact runL_noNewR P L b k _ _ hp (h.retain n)
  | AlgM.bankOp idx op k, o, g, hp, h => by
    simp only [runL]
    exact runL_noNewR P L b k _ _ hp (h.bankOp idx op)
  | AlgM.bankOpFrom idx op k, o, g, hp, h => by
    simp only [runL]
    exact runL_noNewR P L b k _ _ hp (h.bankOpFrom idx op)
  | AlgM.bankValidate idx S θ k, o, g, hp, h => by
    simp only [runL]
    cases hB : o.banks[idx]? with
    | none => exact runL_noNewR P L b _ o g (hp _) h
    | some B =>
      simp only [merge_bind, merge_tag]
      refine FP.BPAll.bind (fun r hr => ?_) (LabAux.bpAll_validate P B S θ)
      exact runL_noNewR P L b _ _ _ (hp _) (h.validate hB hr _ rfl rfl)
  | AlgM.bankRelease idx mode k, o, g, hp, h => by
    simp only [runL]
    cases hB : o.banks[idx]? with
    | none => exact runL_noNewR P L b _ o g (hp _) h
    | some B =>
      simp only [merge_bind, merge_tag]
      refine FP.BPAll.bind (fun r hr => ?_) (LabAux.bpAll_releaseLog P B mode)
      exact runL_noNewR P L b _ _ _ (hp _) (h.release hB hr _ rfl rfl rfl)
  | AlgM.note ev k, o, g, hp, h => by
    simp only [runL]
    exact runL_noNewR P L b k _ _ hp (h.congr rfl rfl rfl)

/-! ### Step 1: the births -/

/-- The shape of the birth of depth `d`: reset, the allocation `bankNew tr d` if `d + 2 ≤ H`, then a
program without allocation. -/
theorem birthCode_shape (P : StreamParams) (tr d0 d : ℕ) (c : CState) :
    ∃ R : AlgM CState, NoNewR (fun c' : CState => c'.t = c.t) R ∧
      birthCode P tr d0 d c =
        AlgM.bankOp d RowOp.resetY (if d + 2 ≤ P.H then AlgM.bankNew tr d R else R) :=
  ⟨_, by simp [noteM, releaseM, AlgM.bind, NoNewR, Option.forall, CState.fail, ite_cstate_t], rfl⟩

section Births

variable (P : StreamParams) (L : BankLabel → Prop)
  (hL : ∀ tr d, 1 ≤ tr → tr ≤ P.m → d + 2 ≤ P.H → L (tr, d))

include hL in
theorem birthCode_labInv (tr d0 d : ℕ) (c : CState) (o : OState) (g : Ghost) (htr : 1 ≤ tr)
    (htm : tr ≤ P.m) (h : LabInv P L (tr, d) o g) :
    FP.BPAll (runL P (birthCode P tr d0 d c) o g).merge
      (fun r => LabInv P L (tr, d + 1) r.2.1 r.2.2 ∧ r.1.t = c.t) := by
  obtain ⟨R, hR, hEq⟩ := birthCode_shape P tr d0 d c
  rw [hEq]
  simp only [runL]
  have h1 := h.bankOp d RowOp.resetY
  split_ifs with hd
  · simp only [runL, merge_bind, merge_newBankT]
    refine FP.BPAll.bind (fun B hB => ?_) (bpAll_newBank_coarse P)
    exact runL_noNewR P L _ R _ _ hR
      (h1.bankNew (Or.inr ⟨rfl, le_refl d⟩) (hL tr d htr htm hd) B hB)
  · refine FP.BPAll.mono (fun r hr => ⟨hr.1.mono (Or.inr ⟨rfl, Nat.le_succ d⟩), hr.2⟩)
      (runL_noNewR P L _ R _ _ hR h1)

include hL in
theorem birthLoopCode_labInv (tr d0 : ℕ) (htr : 1 ≤ tr) (htm : tr ≤ P.m) :
    ∀ (n d : ℕ) (c : CState) (o : OState) (g : Ghost), LabInv P L (tr, d) o g →
      FP.BPAll (runL P (birthLoopCode P tr d0 (List.range' d n) c) o g).merge
        (fun r => LabInv P L (tr, d + n) r.2.1 r.2.2 ∧ r.1.t = c.t)
  | 0, d, c, o, g, h => by
    rw [List.range'_zero]
    exact runL_pure_bitAlways P c o g ⟨h, rfl⟩
  | n + 1, d, c, o, g, h => by
    rw [List.range'_succ]
    simp only [birthLoopCode]
    split_ifs with hf
    · exact runL_pure_bitAlways P c o g ⟨h.mono (Or.inr ⟨rfl, by omega⟩), rfl⟩
    · rw [AlgM.bind_eq, LabAux.runL_bind, merge_bind]
      refine FP.BPAll.bind (fun r hr => ?_) (birthCode_labInv P L hL tr d0 d c o g htr htm h)
      refine FP.BPAll.mono (fun x hx => ⟨?_, hx.2.trans hr.2⟩)
        (birthLoopCode_labInv tr d0 htr htm n (d + 1) r.1 r.2.1 r.2.2 hr.1)
      have e : d + 1 + n = d + (n + 1) := by omega
      rw [← e]
      exact hx.1

include hL in
theorem step1Code_labInv (c : CState) (o : OState) (g : Ghost) (hct : c.t < P.m)
    (h : LabInv P L (c.t + 1, 0) o g) :
    FP.BPAll (runL P (step1Code P c) o g).merge
      (fun r => LabInv P L (c.t + 2, 0) r.2.1 r.2.2 ∧ r.1.t = c.t) := by
  have hshape : step1Code P c = AlgM.bankRetain (firstBorn P.H (c.t + 1) + 1)
      ((birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1))
          (List.range' (firstBorn P.H (c.t + 1)) (P.H - firstBorn P.H (c.t + 1)))
          { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }).bind
        fun c2 => AlgM.pure { c2 with leaf := 0 }) := rfl
  rw [hshape]
  simp only [runL]
  rw [LabAux.runL_bind, merge_bind]
  have h1 := (h.retain (firstBorn P.H (c.t + 1) + 1)).mono
    (b' := (c.t + 1, firstBorn P.H (c.t + 1))) (Or.inr ⟨rfl, Nat.zero_le _⟩)
  refine FP.BPAll.bind (fun r hr => ?_)
    (birthLoopCode_labInv P L hL (c.t + 1) _ (by omega) (by omega) _ _ _ _ _ h1)
  exact runL_pure_bitAlways P _ _ _ ⟨hr.1.mono (Or.inl (by simp)), hr.2⟩

include hL in
/-- **One round**: from the bound `(t+1, 0)` and the round counter `t < m` to the bound `(t+2, 0)` and the
counter `t + 1`. -/
theorem roundCode_labInv (c : CState) (i : ℕ) (Δ : ℤ) (o : OState) (g : Ghost) (hct : c.t < P.m)
    (h : LabInv P L (c.t + 1, 0) o g) :
    FP.BPAll (runL P (roundCode P c i Δ) o g).merge
      (fun r => LabInv P L (c.t + 2, 0) r.2.1 r.2.2 ∧ r.1.1.t = c.t + 1) := by
  rw [FP.roundCode_eq]
  split_ifs with hc
  · exact runL_pure_bitAlways P _ o g ⟨h.mono (Or.inl (by simp)), rfl⟩
  · simp only [runL]
    rw [LabAux.runL_bind, merge_bind]
    refine FP.BPAll.bind (fun r hr => ?_)
      (step1Code_labInv P L hL c _ _ hct (h.congr rfl rfl rfl))
    unfold FP.fpTail1
    split_ifs with h1
    · exact runL_pure_bitAlways P _ _ _ ⟨hr.1, by simp [finishC, hr.2]⟩
    · have hN : NoNewR (fun x : CState × ℚ => x.1.t = c.t + 1)
          ((step2Code P i Δ r.1).bind (FP.fpTail2 P)) :=
        NoNewR.bind (noNewR_step2Code P i Δ r.1) fun r2 hr2 =>
          (noNewR_fpTail2 P r2).mono fun x hx => by rw [hx, hr2, hr.2]
      exact runL_noNewR P L _ _ _ _ hN hr.1

end Births

/-- **The initialization**: the root bank `(0, 0)` is born; then the bound is `(1, 0)` and the round
counter `0`. -/
theorem initCode_labInv (P : StreamParams) (L : BankLabel → Prop) (hL0 : L (0, 0)) :
    FP.BPAll (runL P initCode initO Ghost.init).merge
      (fun r => LabInv P L (1, 0) r.2.1 r.2.2 ∧ r.1.t = 0) := by
  have hshape : initCode = AlgM.fpInit (AlgM.bankNew 0 0 (AlgM.pure ⟨0, false, [], 0⟩)) := rfl
  have h0 : LabInv P L (0, 0) initO Ghost.init :=
    ⟨rfl, fun l hl => absurd hl List.not_mem_nil, fun rec hr => absurd hr List.not_mem_nil,
      fun lab => by simp [coarseRecs, labLive, initO, Ghost.init]⟩
  rw [hshape]
  simp only [runL, merge_bind, merge_tag, merge_newBankT, merge_pure]
  refine FP.BPAll.bind (fun r _ => ?_) (FP.BPAll.true _)
  refine FP.BPAll.bind (fun B hB => ?_) (bpAll_newBank_coarse P)
  refine FP.BPAll.pure ⟨?_, rfl⟩
  exact ((h0.congr (o' := { initO with fpSeed := r, fpVal := 0 }) (g' := Ghost.init) rfl rfl
    rfl).bankNew (Or.inr ⟨rfl, le_refl 0⟩) hL0 B hB).mono (b' := (1, 0)) (Or.inl Nat.zero_lt_one)

/-! ### The invariant on the instrumented canonical run -/

/-- **The label invariant along the instrumented canonical run**: before round `t ≤ m`, the bound is
`(t+1, 0)` and the round counter is `t`. -/
theorem run_labInv (P : StreamParams) (L : BankLabel → Prop) (hL0 : L (0, 0))
    (hL : ∀ tr d, 1 ≤ tr → tr ≤ P.m → d + 2 ≤ P.H → L (tr, d)) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) :
    ∀ (t : ℕ) (c : (State × Ghost) × List ℚ), theAlgL.run P adv tapes t = some c → t ≤ P.m →
      LabInv P L (t + 1, 0) c.1.1.orc c.1.2 ∧ c.1.1.t = t
  | 0, c, hc, _ => by
    have hc' : ((((runL P initCode initO Ghost.init).map fun r => (State.mk' r.1 r.2.1, r.2.2)).merge.run
        (tapeAt tapes 0)).map fun r => (r.1, ([] : List ℚ))) = some c := hc
    rw [merge_map, BitProg.run_map] at hc'
    obtain ⟨r, hr, rfl⟩ := Option.map_eq_some_iff.mp hc'
    obtain ⟨x, hx, rfl⟩ := Option.map_eq_some_iff.mp hr
    exact FP.BPAll.of_run (initCode_labInv P L hL0) hx
  | t + 1, c', hc', ht => by
    obtain ⟨c, hc, s', q, rest, hstep, rfl⟩ := run_succ_some hc'
    obtain ⟨h1, h2⟩ := run_labInv P L hL0 hL adv tapes t c hc (by omega)
    have hstep' : (((runL P (roundCode P c.1.1.ctrl (adv c.2).1.val (adv c.2).2) c.1.1.orc c.1.2).map
        fun r => ((State.mk' r.1.1 r.2.1, r.2.2), r.1.2)).merge.run (tapeAt tapes (t + 1))) =
        some ((s', q), rest) := hstep
    rw [merge_map, BitProg.run_map] at hstep'
    obtain ⟨x, hx, hxe⟩ := Option.map_eq_some_iff.mp hstep'
    have hct : c.1.1.ctrl.t = t := h2
    have hinv : LabInv P L (c.1.1.ctrl.t + 1, 0) c.1.1.orc c.1.2 := by rw [hct]; exact h1
    have hr := FP.BPAll.of_run
      (roundCode_labInv P L hL c.1.1.ctrl (adv c.2).1.val (adv c.2).2 c.1.1.orc c.1.2
        (by rw [hct]; omega) hinv) hx
    have hs : s' = (State.mk' x.1.1.1 x.1.2.1, x.1.2.2) := (congrArg (fun y => y.1.1) hxe).symm
    subst hs
    rw [hct] at hr
    exact ⟨hr.1, hr.2⟩

end F2e2e.C.Closure
