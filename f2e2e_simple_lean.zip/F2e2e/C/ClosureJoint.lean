import Mathlib
import F2e2e.C.ClosureTreeStep
import F2e2e.C.ClosureBankStep
import F2e2e.C.ClosureOrcStep
import F2e2e.C.ClosureWPRules

/-!
# Theorem 6.4: the joint invariant and the bank-state part

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1287–1317).

`JointInv P ph c o g` at the moment `ph` of a round, for the controller state `c`, the oracle state `o` and the ghost
data `g` (tree shadow `S = shadowOf P g`, `nev = |g.events|`):
* `TreePart` (C-TREE / 295bf129, `F2e2e/C/ClosureTreeStep.lean`), `BankPart` (C-BANK,
  `F2e2e/C/ClosureBankStep.lean`), `CountPart` (C-ORC, `F2e2e/C/ClosureOrcStep.lean`);
* `StatePart` (here): stored rows are hypothetical rows (`RowsOK`), the coarse groups have their shape, the ADA
  rejection counter of every live bank is the number of rejections in its transcript, and its remaining coarse
  groups are `R_max` minus its numerical requests;
* no failure, and the round counters.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## The bank-state part -/

/- `CoarseShape P B` (the shape of a bank's coarse groups: `g` subgroups of `32` rows) is C-BANK's
(`F2e2e/C/NormBank/AdaRej.lean`), with `bitAlways_newBank_shape`. -/

/-- **The bank-state part of the invariant.** -/
structure StatePart (P : StreamParams) (o : OState) (g : Ghost) : Prop where
  rows : RowsOK P o g
  shape : ∀ B ∈ o.banks, CoarseShape P B
  rej : ∀ (idx : ℕ) (B : Bank), o.banks[idx]? = some B → B.adaSt.rej = nRej (g.labelAt idx) g.calls
  coarseLen : ∀ (idx : ℕ) (B : Bank), o.banks[idx]? = some B →
    B.coarse.length + nNum (g.labelAt idx) g.calls = P.Rmax

/-- Whether the moment is the end of a round. -/
def phIdle : Tree.Phase → Bool
  | .idle => true
  | _ => false

/-- **The joint invariant** at the moment `ph`. -/
structure JointInv (P : StreamParams) (ph : Tree.Phase) (c : CState) (o : OState) (g : Ghost) : Prop where
  tp : TreePart P ph c (shadowOf P g) g.events.length
  bp : BankPart P ph (shadowOf P g) g.hists g.events.length
  cp : CountPart P ph c g
  sp : StatePart P o g
  notFailed : c.failed = false
  time : (shadowOf P g).t = c.t + (if phIdle ph then 0 else 1)

/-! ## Counting lemmas on call logs -/

theorem length_filter_snoc {α : Type} (p : α → Bool) (l : List α) (a : α) :
    ((l ++ [a]).filter p).length = (l.filter p).length + (if p a = true then 1 else 0) := by
  rw [List.filter_append, List.length_append]
  cases h : p a <;> simp [List.filter, h]

theorem nInt_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nInt lab (calls ++ [rec]) = nInt lab calls +
      (if (decide (rec.lab = lab) && rec.out.isSome &&
        (match rec.kind with
          | CallKind.validate _ _ => true
          | CallKind.release _ => false)) = true then 1 else 0) :=
  length_filter_snoc _ _ _

theorem nNum_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nNum lab (calls ++ [rec]) = nNum lab calls +
      (if (decide (rec.lab = lab) && rec.out.isSome &&
        (match rec.kind with
          | CallKind.validate _ _ => false
          | CallKind.release _ => true)) = true then 1 else 0) :=
  length_filter_snoc _ _ _

theorem nRej_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nRej lab (calls ++ [rec]) = nRej lab calls +
      (if (decide (rec.lab = lab) &&
        (match rec.out with
          | some o => coreIsReject o
          | none => false)) = true then 1 else 0) :=
  length_filter_snoc _ _ _

/-- A call on another label does not change the counts of `lab`. -/
theorem counts_append_other {lab : BankLabel} (calls : List CallRec) (rec : CallRec) (h : rec.lab ≠ lab) :
    nInt lab (calls ++ [rec]) = nInt lab calls ∧ nNum lab (calls ++ [rec]) = nNum lab calls ∧
      nRej lab (calls ++ [rec]) = nRej lab calls := by
  refine ⟨?_, ?_, ?_⟩
  · rw [nInt_append]; simp [h]
  · rw [nNum_append]; simp [h]
  · rw [nRej_append]; simp [h]

/-! ## The bank-state part under the primitives -/

theorem coarseShape_mapRows (f : Row → Row) {B : Bank} (h : CoarseShape P B) :
    CoarseShape P (Bank.mapRows f B) := by
  intro grp hgrp
  unfold Bank.mapRows at hgrp
  obtain ⟨grp0, hgrp0, rfl⟩ := List.mem_map.mp hgrp
  obtain ⟨h1, h2⟩ := h grp0 hgrp0
  refine ⟨by simp [h1], fun sub hsub => ?_⟩
  obtain ⟨sub0, hsub0, rfl⟩ := List.mem_map.mp hsub
  simp [h2 sub0 hsub0]

theorem mem_modifyAt {α : Type} {f : α → α} {k : ℕ} {l : List α} {b : α} (hb : b ∈ modifyAt f k l) :
    b ∈ l ∨ ∃ a ∈ l, b = f a := by
  obtain ⟨j, hj, hjb⟩ := List.getElem_of_mem hb
  have h := getElem?_modifyAt f k j l
  rw [List.getElem?_eq_getElem hj, hjb] at h
  split_ifs at h with hjk
  · cases hl : l[j]? with
    | none => rw [hl] at h; simp at h
    | some a =>
      rw [hl] at h
      simp only [Option.map_some, Option.some.injEq] at h
      exact Or.inr ⟨a, List.mem_of_getElem? hl, h⟩
  · exact Or.inl (List.mem_of_getElem? h.symm)

theorem mem_mapFrom {α : Type} {f : α → α} {k : ℕ} {l : List α} {b : α} (hb : b ∈ mapFrom f k l) :
    b ∈ l ∨ ∃ a ∈ l, b = f a := by
  obtain ⟨j, hj, hjb⟩ := List.getElem_of_mem hb
  have h := getElem?_mapFrom f k j l
  rw [List.getElem?_eq_getElem hj, hjb] at h
  split_ifs at h with hjk
  · cases hl : l[j]? with
    | none => rw [hl] at h; simp at h
    | some a =>
      rw [hl] at h
      simp only [Option.map_some, Option.some.injEq] at h
      exact Or.inr ⟨a, List.mem_of_getElem? hl, h⟩
  · exact Or.inl (List.mem_of_getElem? h.symm)

theorem statePart_bankOp {o : OState} {g : Ghost} (h : StatePart P o g) (idx : ℕ) (op : RowOp) :
    StatePart P { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun l => l ++ [op]) idx g.hists } where
  rows := rowsOK_bankOp h.rows idx op
  shape B hB := by
    rcases mem_modifyAt hB with hB | ⟨B0, hB0, rfl⟩
    · exact h.shape B hB
    · exact coarseShape_mapRows _ (h.shape B0 hB0)
  rej j B hB := by
    simp only [getElem?_modifyAt] at hB
    split_ifs at hB with hj
    · cases h0 : o.banks[j]? with
      | none => rw [h0] at hB; simp at hB
      | some B0 =>
        rw [h0] at hB
        simp only [Option.map_some, Option.some.injEq] at hB
        subst hB
        exact h.rej j B0 h0
    · exact h.rej j B hB
  coarseLen j B hB := by
    simp only [getElem?_modifyAt] at hB
    split_ifs at hB with hj
    · cases h0 : o.banks[j]? with
      | none => rw [h0] at hB; simp at hB
      | some B0 =>
        rw [h0] at hB
        simp only [Option.map_some, Option.some.injEq] at hB
        subst hB
        have := h.coarseLen j B0 h0
        show (Bank.mapRows _ B0).coarse.length + nNum (g.labelAt j) g.calls = P.Rmax
        simpa only [Bank.mapRows, List.length_map] using this
    · exact h.coarseLen j B hB

theorem statePart_bankOpFrom {o : OState} {g : Ghost} (h : StatePart P o g) (idx : ℕ) (op : RowOp) :
    StatePart P { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun l => l ++ [op]) idx g.hists } where
  rows := rowsOK_bankOpFrom h.rows idx op
  shape B hB := by
    rcases mem_mapFrom hB with hB | ⟨B0, hB0, rfl⟩
    · exact h.shape B hB
    · exact coarseShape_mapRows _ (h.shape B0 hB0)
  rej j B hB := by
    simp only [getElem?_mapFrom] at hB
    split_ifs at hB with hj
    · cases h0 : o.banks[j]? with
      | none => rw [h0] at hB; simp at hB
      | some B0 =>
        rw [h0] at hB
        simp only [Option.map_some, Option.some.injEq] at hB
        subst hB
        exact h.rej j B0 h0
    · exact h.rej j B hB
  coarseLen j B hB := by
    simp only [getElem?_mapFrom] at hB
    split_ifs at hB with hj
    · cases h0 : o.banks[j]? with
      | none => rw [h0] at hB; simp at hB
      | some B0 =>
        rw [h0] at hB
        simp only [Option.map_some, Option.some.injEq] at hB
        subst hB
        have := h.coarseLen j B0 h0
        show (Bank.mapRows _ B0).coarse.length + nNum (g.labelAt j) g.calls = P.Rmax
        simpa only [Bank.mapRows, List.length_map] using this
    · exact h.coarseLen j B hB

theorem statePart_events {o : OState} {g : Ghost} (h : StatePart P o g) (evs : List TreeEvent) :
    StatePart P o { g with events := evs } where
  rows := rowsOK_of_eq h.rows rfl rfl rfl
  shape := h.shape
  rej := h.rej
  coarseLen := h.coarseLen

theorem statePart_fps {o : OState} {g : Ghost} (h : StatePart P o g) (v : ℕ) (l : List (ℕ × ℤ × Bool)) :
    StatePart P { o with fpVal := v } { g with fps := l } where
  rows := rowsOK_of_eq h.rows rfl rfl rfl
  shape := h.shape
  rej := h.rej
  coarseLen := h.coarseLen

theorem statePart_retain {o : OState} {g : Ghost} (h : StatePart P o g) (n : ℕ) :
    StatePart P { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n } where
  rows := rowsOK_retain h.rows n
  shape B hB := h.shape B (List.mem_of_mem_take hB)
  rej j B hB := by
    have hj : j < n := by
      by_contra hj
      simp [hj] at hB
    have hB' : o.banks[j]? = some B := by simpa [List.getElem?_take, hj] using hB
    have hl : ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost).labelAt j =
        g.labelAt j := by
      unfold Ghost.labelAt
      simp only [List.getD_eq_getElem?_getD, List.getElem?_take, hj, if_true]
    rw [hl]
    exact h.rej j B hB'
  coarseLen j B hB := by
    have hj : j < n := by
      by_contra hj
      simp [hj] at hB
    have hB' : o.banks[j]? = some B := by simpa [List.getElem?_take, hj] using hB
    have hl : ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost).labelAt j =
        g.labelAt j := by
      unfold Ghost.labelAt
      simp only [List.getD_eq_getElem?_getD, List.getElem?_take, hj, if_true]
    rw [hl]
    exact h.coarseLen j B hB'

end F2e2e.C.Closure
