import F2e2e.C.Top.Run

/-!
# Theorem (C), top level: deterministic and dyadic forms of `MathAlgGood`

These forms remove all measure theory (and the real `ε`, `β`) from the Part III analysis.

* `MathAlgGoodDet A`: for every **deterministic** adversary, the number of tape tuples on which the
  canonical run of `A` (`MathStreamAlg.outs`) is not accurate up to the first violation of the box promise
  is at most `β · 2^((m+1)·tapeLen)` (= `β` times the number of tape tuples).
* `mathAlgGood_of_det : A.Total → MathAlgGoodDet A → MathAlgGood A`. Randomized adversaries are mixtures of
  deterministic ones: for fixed tapes the failure set is measurable in the adversary's coins because the
  failure depends on finitely many values of the strategy (`measurableSet_of_finitelyDetermined`,
  `streamAccurate_outs_congr`); then Tonelli for the finite sum over the tapes (`sum_measure_le_of_count`).
* `MathAlgGoodDyadic A`: for every record `P` with `ParamsOK P` and every deterministic adversary, the
  count with the dyadic accuracy `ε₀ = (1/2)^epsExp` is at most `β₀ · 2^((m+1)·tapeLen)`,
  `β₀ = (1/2)^betaExp` (the algorithm sees only `P`); `mathAlgGoodDet_of_dyadic` (since `ε₀ ≤ ε`,
  `β₀ ≤ β`, `half_pow_dyadicExp_le`) and `mathAlgGood_of_dyadic`.

Counts are `Set.ncard`, as in `F2e2e.FinProb.P_mul_card` (`P A * card Ω = ncard {ω | A ω}`), and the
number of tape tuples is `2^((m+1)·tapeLen)` (`card_tapes`).
-/

namespace F2e2e.C.Top

open MeasureTheory

/-! ## Definitions -/

/-- **Accuracy against deterministic adversaries** (tape count for the canonical run). -/
def MathAlgGoodDet (A : MathStreamAlg) : Prop :=
  ∀ (n m U : ℕ) (ε β : ℝ), 1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1 / 10 → 0 < β → β < 1 / 10 →
    ∀ adv : StreamAdversary (mkStreamParams n m U ε β).n,
      (({tapes | ¬ StreamAccurate m U ε adv (A.outs (mkStreamParams n m U ε β) adv tapes)} :
          Set (Fin ((mkStreamParams n m U ε β).m + 1) →
            Fin (A.tapeLen (mkStreamParams n m U ε β)) → Bool)).ncard : ℝ) ≤
        β * 2 ^ (((mkStreamParams n m U ε β).m + 1) * A.tapeLen (mkStreamParams n m U ε β))

/-- **Dyadic accuracy against deterministic adversaries**, indexed by the parameter record: accuracy
`ε₀ = (1/2)^epsExp`, failure count `≤ β₀ · 2^((m+1)·tapeLen)` with `β₀ = (1/2)^betaExp`. -/
def MathAlgGoodDyadic (A : MathStreamAlg) : Prop :=
  ∀ P : StreamParams, ParamsOK P → ∀ adv : StreamAdversary P.n,
    (({tapes | ¬ StreamAccurate P.m P.U ((1 / 2 : ℝ) ^ P.epsExp) adv (A.outs P adv tapes)} :
        Set (Fin (P.m + 1) → Fin (A.tapeLen P) → Bool)).ncard : ℝ) ≤
      (1 / 2 : ℝ) ^ P.betaExp * 2 ^ ((P.m + 1) * A.tapeLen P)

/-- The number of tape tuples. -/
theorem card_tapes (m B : ℕ) : Fintype.card (Fin (m + 1) → Fin B → Bool) = 2 ^ ((m + 1) * B) := by
  rw [Fintype.card_fun, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin, Fintype.card_fin,
    ← pow_mul, mul_comm]

/-! ## Accuracy: monotonicity in `ε` and dependence on the adversary -/

theorem F2_nonneg {n : ℕ} (x : Fin n → ℤ) : 0 ≤ F2 x :=
  Finset.sum_nonneg (fun _ _ => sq_nonneg _)

/-- Accuracy is monotone in `ε`. -/
theorem streamAccurate_mono {n m U : ℕ} {ε ε' : ℝ} (h0 : 0 ≤ ε) (hle : ε ≤ ε')
    {adv : StreamAdversary n} {outs : ℕ → ℚ} (h : StreamAccurate m U ε adv outs) :
    StreamAccurate m U ε' adv outs := by
  intro t ht hbox
  obtain ⟨h1, h2⟩ := h t ht hbox
  have hF := F2_nonneg (streamVec adv outs t)
  constructor
  · calc F2 (streamVec adv outs t) / (1 + ε') ≤ F2 (streamVec adv outs t) / (1 + ε) :=
          div_le_div_of_nonneg_left hF (by linarith) (by linarith)
      _ ≤ _ := h1
  · calc (outs t : ℝ) ≤ (1 + ε) * F2 (streamVec adv outs t) := h2
      _ ≤ (1 + ε') * F2 (streamVec adv outs t) := mul_le_mul_of_nonneg_right (by linarith) hF

theorem streamVec_congr {n : ℕ} {a a' : StreamAdversary n} {o o' : ℕ → ℚ} {t : ℕ}
    (h : ∀ s ≤ t, advUpdate a' o' s = advUpdate a o s) : streamVec a' o' t = streamVec a o t := by
  funext i
  unfold streamVec
  refine Finset.sum_congr rfl (fun s hs => ?_)
  rw [h s (Nat.lt_succ_iff.mp (Finset.mem_range.mp hs))]

theorem boxUpTo_congr {n U : ℕ} {a a' : StreamAdversary n} {o o' : ℕ → ℚ} {t : ℕ}
    (h : ∀ s ≤ t, advUpdate a' o' s = advUpdate a o s) : BoxUpTo U a' o' t ↔ BoxUpTo U a o t := by
  constructor
  · intro hb s hs i
    rw [← streamVec_congr (fun r hr => h r (hr.trans hs))]
    exact hb s hs i
  · intro hb s hs i
    rw [streamVec_congr (fun r hr => h r (hr.trans hs))]
    exact hb s hs i

/-- Accuracy up to round `m` depends only on the updates and estimates of the rounds `< m`. -/
theorem streamAccurate_congr {n m U : ℕ} {ε : ℝ} {a a' : StreamAdversary n} {o o' : ℕ → ℚ}
    (hu : ∀ s < m, advUpdate a' o' s = advUpdate a o s) (ho : ∀ t < m, o' t = o t) :
    StreamAccurate m U ε a' o' ↔ StreamAccurate m U ε a o := by
  unfold StreamAccurate
  refine forall_congr' (fun t => forall_congr' (fun ht => ?_))
  have hu' : ∀ s ≤ t, advUpdate a' o' s = advUpdate a o s :=
    fun s hs => hu s (lt_of_le_of_lt hs ht)
  rw [boxUpTo_congr hu', streamVec_congr hu', ho t ht]

section congr

variable {A : MathStreamAlg} {P : StreamParams} {a a' : StreamAdversary P.n}
  {tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool} {T : ℕ}

/-- Two adversaries that agree on the histories of the canonical run of `a` before round `T` produce the
same canonical run up to round `T`. -/
theorem run_congr
    (h : ∀ t < T, a' (List.ofFn (fun r : Fin t => A.outs P a tapes r.val)) =
      a (List.ofFn (fun r : Fin t => A.outs P a tapes r.val))) :
    ∀ t ≤ T, A.run P a' tapes t = A.run P a tapes t := by
  intro t
  induction t with
  | zero => intro _; rfl
  | succ t ih =>
    intro ht
    rw [run_succ_eq, run_succ_eq, ih (Nat.le_of_succ_le ht)]
    cases hc : A.run P a tapes t with
    | none => rfl
    | some c =>
      have hh := h t ht
      rw [run_hist hc] at hh
      simp only [Option.bind_some]
      rw [hh]

theorem outs_congr
    (h : ∀ t < T, a' (List.ofFn (fun r : Fin t => A.outs P a tapes r.val)) =
      a (List.ofFn (fun r : Fin t => A.outs P a tapes r.val))) :
    ∀ t < T, A.outs P a' tapes t = A.outs P a tapes t := by
  intro t ht
  unfold MathStreamAlg.outs
  rw [run_congr h (t + 1) ht]

theorem advUpdate_outs_congr
    (h : ∀ t < T, a' (List.ofFn (fun r : Fin t => A.outs P a tapes r.val)) =
      a (List.ofFn (fun r : Fin t => A.outs P a tapes r.val))) :
    ∀ t < T, advUpdate a' (A.outs P a' tapes) t = advUpdate a (A.outs P a tapes) t := by
  intro t ht
  unfold advUpdate
  have hl : List.ofFn (fun r : Fin t => A.outs P a' tapes r.val) =
      List.ofFn (fun r : Fin t => A.outs P a tapes r.val) := by
    congr 1
    funext r
    exact outs_congr h r.val (lt_trans r.isLt ht)
  rw [hl, h t ht]

/-- The accuracy of the canonical run up to round `m` depends only on the values of the strategy on the
(at most `m`) histories of the canonical run before round `m`. -/
theorem streamAccurate_outs_congr {m U : ℕ} {ε : ℝ}
    (h : ∀ t < m, a' (List.ofFn (fun r : Fin t => A.outs P a tapes r.val)) =
      a (List.ofFn (fun r : Fin t => A.outs P a tapes r.val))) :
    StreamAccurate m U ε a' (A.outs P a' tapes) ↔ StreamAccurate m U ε a (A.outs P a tapes) :=
  streamAccurate_congr (advUpdate_outs_congr h) (outs_congr h)

end congr

/-! ## Measurability in the adversary's coins -/

/-- A predicate `F` on strategies `H → X` that depends, near every strategy, only on finitely many
values defines a measurable set of coins, when `H` and `X` are countable, `X` has measurable singletons,
and the strategy is measurable in the coins for each fixed `h`. -/
theorem measurableSet_of_finitelyDetermined {Ω H X : Type*} [MeasurableSpace Ω] [MeasurableSpace X]
    [MeasurableSingletonClass X] [Countable H] [Countable X] (adv : Ω → H → X)
    (hadv : ∀ h, Measurable (fun ω => adv ω h)) (F : (H → X) → Prop)
    (hF : ∀ a, ∃ S : Finset H, ∀ a', (∀ h ∈ S, a' h = a h) → (F a' ↔ F a)) :
    MeasurableSet {ω | F (adv ω)} := by
  classical
  have hC : ∀ p : Finset (H × X), MeasurableSet {ω | ∀ hx ∈ p, adv ω hx.1 = hx.2} := by
    intro p
    have hp : {ω | ∀ hx ∈ p, adv ω hx.1 = hx.2} =
        ⋂ hx ∈ p, (fun ω => adv ω hx.1) ⁻¹' {hx.2} := by
      ext ω
      simp
    rw [hp]
    exact Finset.measurableSet_biInter p (fun hx _ => hadv hx.1 (measurableSet_singleton hx.2))
  have heq : {ω | F (adv ω)} =
      ⋃ p ∈ {p : Finset (H × X) | ∀ a : H → X, (∀ hx ∈ p, a hx.1 = hx.2) → F a},
        {ω | ∀ hx ∈ p, adv ω hx.1 = hx.2} := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, exists_prop]
    constructor
    · intro hω
      obtain ⟨S, hS⟩ := hF (adv ω)
      refine ⟨S.image (fun h => (h, adv ω h)), ?_, ?_⟩
      · intro a ha
        exact (hS a (fun h hh => ha (h, adv ω h) (Finset.mem_image_of_mem _ hh))).mpr hω
      · intro hx hhx
        obtain ⟨h, -, rfl⟩ := Finset.mem_image.mp hhx
        rfl
    · rintro ⟨p, hp, hω⟩
      exact hp (adv ω) hω
  rw [heq]
  exact MeasurableSet.biUnion (Set.to_countable _) (fun p _ => hC p)

/-- For fixed tapes, the failure set of the canonical run is measurable in the adversary's coins. -/
theorem measurableSet_not_streamAccurate {A : MathStreamAlg} {P : StreamParams} {Ω : Type*}
    [MeasurableSpace Ω] (adv : Ω → StreamAdversary P.n)
    (hadv : ∀ h : List ℚ, Measurable (fun ω => adv ω h))
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (m U : ℕ) (ε : ℝ) :
    MeasurableSet {ω | ¬ StreamAccurate m U ε (adv ω) (A.outs P (adv ω) tapes)} := by
  refine measurableSet_of_finitelyDetermined adv hadv
    (fun a => ¬ StreamAccurate m U ε a (A.outs P a tapes)) (fun a => ?_)
  refine ⟨(Finset.range m).image (fun t => List.ofFn (fun r : Fin t => A.outs P a tapes r.val)),
    fun a' ha' => ?_⟩
  rw [streamAccurate_outs_congr (fun t ht => ha' _ (Finset.mem_image_of_mem _
    (Finset.mem_range.mpr ht)))]

/-! ## Tonelli for a finite family of events -/

/-- If every outcome lies in at most `c` of the finitely many measurable events `E i`, the sum of their
probabilities is at most `c`. -/
theorem sum_measure_le_of_count {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι] (μ : Measure Ω)
    [IsProbabilityMeasure μ] (E : ι → Set Ω) (hE : ∀ i, MeasurableSet (E i)) (c : ℝ)
    (hc : ∀ ω, (({i | ω ∈ E i} : Set ι).ncard : ℝ) ≤ c) :
    ∑ i, μ (E i) ≤ ENNReal.ofReal c := by
  classical
  have hcount : ∀ ω, ∑ i, (E i).indicator (1 : Ω → ENNReal) ω =
      (({i | ω ∈ E i} : Set ι).ncard : ENNReal) := by
    intro ω
    have hset : ({i | ω ∈ E i} : Set ι) = ↑(Finset.univ.filter (fun i => ω ∈ E i)) := by
      ext i
      simp
    simp only [Set.indicator_apply, Pi.one_apply]
    rw [Finset.sum_boole, hset, Set.ncard_coe_finset]
  calc ∑ i, μ (E i) = ∑ i, ∫⁻ ω, (E i).indicator 1 ω ∂μ := by
        refine Finset.sum_congr rfl (fun i _ => ?_)
        rw [lintegral_indicator_one (hE i)]
    _ = ∫⁻ ω, ∑ i, (E i).indicator 1 ω ∂μ :=
        (lintegral_finsetSum _ (fun i _ => measurable_one.indicator (hE i))).symm
    _ ≤ ∫⁻ _, ENNReal.ofReal c ∂μ := by
        refine lintegral_mono (fun ω => ?_)
        rw [hcount ω, ← ENNReal.ofReal_natCast]
        exact ENNReal.ofReal_le_ofReal (hc ω)
    _ = ENNReal.ofReal c := by
        rw [lintegral_const, measure_univ, mul_one]

/-! ## The reductions -/

/-- **Deterministic adversaries suffice.** -/
theorem mathAlgGood_of_det {A : MathStreamAlg} (hT : A.Total) (h : MathAlgGoodDet A) :
    MathAlgGood A := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 Ω _ μ _ adv hadv
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  calc ∑ tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
          Fin (A.tapeLen (mkStreamParams n m U ε β)) → Bool,
        μ {ω | ¬ ∃ (states : ℕ → A.State) (outs : ℕ → ℚ),
          MathExec A (mkStreamParams n m U ε β) (adv ω) tapes states outs ∧
          StreamAccurate m U ε (adv ω) outs}
      ≤ ∑ tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
          Fin (A.tapeLen (mkStreamParams n m U ε β)) → Bool,
        μ {ω | ¬ StreamAccurate m U ε (adv ω) (A.outs (mkStreamParams n m U ε β) (adv ω) tapes)} := by
        refine Finset.sum_le_sum (fun tapes _ => measure_mono (fun ω hω hacc => hω ?_))
        obtain ⟨states, hex⟩ := exists_mathExec hT hP (adv ω) tapes
        exact ⟨states, _, hex, hacc⟩
    _ ≤ ENNReal.ofReal
          (β * 2 ^ (((mkStreamParams n m U ε β).m + 1) * A.tapeLen (mkStreamParams n m U ε β))) :=
        sum_measure_le_of_count μ _
          (fun tapes => measurableSet_not_streamAccurate adv hadv tapes m U ε) _
          (fun ω => h n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 (adv ω))
    _ = ENNReal.ofReal β *
          2 ^ (((mkStreamParams n m U ε β).m + 1) * A.tapeLen (mkStreamParams n m U ε β)) := by
        rw [ENNReal.ofReal_mul hβ0.le, ENNReal.ofReal_pow (by norm_num), ENNReal.ofReal_ofNat]

/-- `2^{-⌈log₂ x⁻¹⌉} ≤ x` for `x > 0`. -/
theorem half_pow_dyadicExp_le {x : ℝ} (hx : 0 < x) : (1 / 2 : ℝ) ^ dyadicExp x ≤ x := by
  have h1 : x⁻¹ ≤ (⌈x⁻¹⌉₊ : ℝ) := Nat.le_ceil _
  have h2 : (⌈x⁻¹⌉₊ : ℝ) ≤ (2 : ℝ) ^ dyadicExp x := by
    have := Nat.le_pow_clog (by norm_num : 1 < 2) ⌈x⁻¹⌉₊
    unfold dyadicExp
    exact_mod_cast this
  rw [one_div, inv_pow]
  calc ((2 : ℝ) ^ dyadicExp x)⁻¹ ≤ (x⁻¹)⁻¹ := inv_anti₀ (inv_pos.mpr hx) (h1.trans h2)
    _ = x := inv_inv x

/-- **The dyadic form suffices** (deterministic adversaries). -/
theorem mathAlgGoodDet_of_dyadic {A : MathStreamAlg} (h : MathAlgGoodDyadic A) :
    MathAlgGoodDet A := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 adv
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hb := h (mkStreamParams n m U ε β) hP adv
  have hε' : (1 / 2 : ℝ) ^ (mkStreamParams n m U ε β).epsExp ≤ ε := half_pow_dyadicExp_le hε0
  have hβ' : (1 / 2 : ℝ) ^ (mkStreamParams n m U ε β).betaExp ≤ β := half_pow_dyadicExp_le hβ0
  have hsub : {tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
        Fin (A.tapeLen (mkStreamParams n m U ε β)) → Bool |
        ¬ StreamAccurate m U ε adv (A.outs (mkStreamParams n m U ε β) adv tapes)} ⊆
      {tapes | ¬ StreamAccurate (mkStreamParams n m U ε β).m (mkStreamParams n m U ε β).U
        ((1 / 2 : ℝ) ^ (mkStreamParams n m U ε β).epsExp) adv
        (A.outs (mkStreamParams n m U ε β) adv tapes)} :=
    fun tapes ht hacc => ht (streamAccurate_mono (by positivity) hε' hacc)
  refine le_trans ?_ (hb.trans (mul_le_mul_of_nonneg_right hβ' (by positivity)))
  exact_mod_cast Set.ncard_le_ncard hsub (Set.toFinite _)

/-- **The dyadic form suffices** (randomized adversaries, for a total algorithm). -/
theorem mathAlgGood_of_dyadic {A : MathStreamAlg} (hT : A.Total) (h : MathAlgGoodDyadic A) :
    MathAlgGood A :=
  mathAlgGood_of_det hT (mathAlgGoodDet_of_dyadic h)

end F2e2e.C.Top
