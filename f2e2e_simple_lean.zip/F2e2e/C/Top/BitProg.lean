import F2e2e.C.Top.Run
import F2e2e.Lib.Discrete.BitProg

/-!
# Theorem (C), top level: mathematical algorithms given by `BitProg` programs

The Part III algorithm is written with `F2e2e.Discrete.BitProg` (the free monad over "read one fresh fair
bit"): `algInit P : BitProg State`, `algStep P s u : BitProg (State × ℚ)`. This file plugs such programs
into the interface of `F2e2e/C/Top/Interface.lean`:

* `MathStreamAlg.ofBitProg State tapeLen init step`: the runs read the tape from the head
  (`BitProg.run`), returning the unread rest, exactly as `F2e2e.eval` threads the tape through
  `Expr.coin`;
* `total_ofBitProg`: totality from depth bounds (`BitProg.depth ≤ tapeLen P`) on reachable states with
  box-respecting updates; `total_ofBitProg_of_uniform`: from uniform depth bounds.
-/

namespace F2e2e.C.Top

open F2e2e.Discrete

/-- The mathematical streaming algorithm whose initialization and rounds are `BitProg` programs. -/
def MathStreamAlg.ofBitProg (State : Type) (tapeLen : StreamParams → ℕ)
    (init : StreamParams → BitProg State)
    (step : (P : StreamParams) → State → Fin P.n × ℤ → BitProg (State × ℚ)) : MathStreamAlg where
  State := State
  tapeLen := tapeLen
  init := fun P tape => (init P).run tape
  step := fun P s u tape => (step P s u).run tape

section ofBitProg

variable {State : Type} {tapeLen : StreamParams → ℕ} {init : StreamParams → BitProg State}
  {step : (P : StreamParams) → State → Fin P.n × ℤ → BitProg (State × ℚ)}

@[simp] theorem ofBitProg_init (P : StreamParams) (tape : List Bool) :
    (MathStreamAlg.ofBitProg State tapeLen init step).init P tape = (init P).run tape :=
  rfl

@[simp] theorem ofBitProg_step (P : StreamParams) (s : State) (u : Fin P.n × ℤ)
    (tape : List Bool) :
    (MathStreamAlg.ofBitProg State tapeLen init step).step P s u tape = (step P s u).run tape :=
  rfl

@[simp] theorem ofBitProg_tapeLen :
    (MathStreamAlg.ofBitProg State tapeLen init step).tapeLen = tapeLen :=
  rfl

/-- **Totality from depth bounds**: the initialization program and every round program from a
reachable state with a box-respecting update read at most `tapeLen P` bits. -/
theorem total_ofBitProg (hinit : ∀ P : StreamParams, ParamsOK P → (init P).depth ≤ tapeLen P)
    (hstep : ∀ P : StreamParams, ParamsOK P → ∀ (us : ℕ → Fin P.n × ℤ) (t : ℕ) (s : State),
      Reach (MathStreamAlg.ofBitProg State tapeLen init step) P us t s → t < P.m →
        BoxSeq P.U us t → (step P s (us t)).depth ≤ tapeLen P) :
    (MathStreamAlg.ofBitProg State tapeLen init step).Total := by
  refine ⟨fun P hP tape htape => ?_, fun P hP us t s hreach ht hbox tape htape => ?_⟩
  · have h := BitProg.run_isSome (init P) tape (by rw [htape]; exact hinit P hP)
    obtain ⟨⟨s, rest⟩, hr⟩ := Option.isSome_iff_exists.mp h
    exact ⟨s, rest, hr⟩
  · have h := BitProg.run_isSome (step P s (us t)) tape
      (by rw [htape]; exact hstep P hP us t s hreach ht hbox)
    obtain ⟨⟨⟨s', q⟩, rest⟩, hr⟩ := Option.isSome_iff_exists.mp h
    exact ⟨s', q, rest, hr⟩

/-- **Totality from uniform depth bounds.** -/
theorem total_ofBitProg_of_uniform
    (hinit : ∀ P : StreamParams, ParamsOK P → (init P).depth ≤ tapeLen P)
    (hstep : ∀ P : StreamParams, ParamsOK P → ∀ (s : State) (u : Fin P.n × ℤ),
      (step P s u).depth ≤ tapeLen P) :
    (MathStreamAlg.ofBitProg State tapeLen init step).Total :=
  total_ofBitProg hinit (fun P hP us t s _ _ _ => hstep P hP s (us t))

end ofBitProg

end F2e2e.C.Top
