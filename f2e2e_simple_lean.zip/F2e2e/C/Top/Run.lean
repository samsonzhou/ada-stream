import F2e2e.C.Top.Interface

/-!
# Theorem (C), top level: the canonical run of a mathematical algorithm

* `paramsOK_mkStreamParams`: the parameter records of `Theorem_C` satisfy `ParamsOK`.
* `MathStreamAlg.run`, `MathStreamAlg.outs`: the canonical (functional) run of `A` against a
  deterministic adversary with given tapes: the state before round `t` and the estimates of the rounds
  `0, …, t-1` (`none` once a run fails); `outs t` is the estimate of round `t` (`0` if undefined).
* `exists_mathExec`: for a total algorithm the canonical run is a `MathExec` (so one exists for every
  adversary and all tapes); `reach_of_mathExec`: the states of an execution are reachable up to the first
  violation of the box promise.
-/

namespace F2e2e.C.Top

/-! ## Parameters -/

theorem four_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1 / 10) : 4 ≤ dyadicExp x := by
  have h10 : (10 : ℝ) < x⁻¹ := by
    have h := one_div_lt_one_div_of_lt hx0 hx1
    rw [one_div x] at h
    norm_num at h
    exact h
  have hc : 8 < ⌈x⁻¹⌉₊ := by
    have h1 := Nat.le_ceil x⁻¹
    have h2 : ((8 : ℕ) : ℝ) < (⌈x⁻¹⌉₊ : ℝ) := by push_cast; linarith
    exact_mod_cast h2
  have h3 : 3 < Nat.clog 2 ⌈x⁻¹⌉₊ :=
    (Nat.lt_clog_iff_pow_lt (by norm_num)).mpr (by norm_num; omega)
  unfold dyadicExp
  omega

theorem paramsOK_mkStreamParams {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10) :
    ParamsOK (mkStreamParams n m U ε β) :=
  ⟨hn, hm, hU, four_le_dyadicExp hε0 hε1, four_le_dyadicExp hβ0 hβ1⟩

/-- `⌈log₂ (2^e)⌉ = e`. -/
theorem dyadicExp_half_pow (e : ℕ) : dyadicExp ((1 / 2 : ℝ) ^ e) = e := by
  unfold dyadicExp
  have h1 : ((1 / 2 : ℝ) ^ e)⁻¹ = ((2 ^ e : ℕ) : ℝ) := by
    rw [one_div, inv_pow, inv_inv]
    push_cast
    ring
  rw [h1, Nat.ceil_natCast, Nat.clog_pow 2 e (by norm_num)]

/-- Conversely to `paramsOK_mkStreamParams`, every record with `ParamsOK` is a parameter record of
`Theorem_C` (with `ε = 2^{-epsExp}`, `β = 2^{-betaExp}`): quantifying over `ParamsOK P` loses nothing. -/
theorem exists_mkStreamParams_of_paramsOK {P : StreamParams} (hP : ParamsOK P) :
    ∃ ε β : ℝ, 0 < ε ∧ ε < 1 / 10 ∧ 0 < β ∧ β < 1 / 10 ∧ P = mkStreamParams P.n P.m P.U ε β := by
  have hsmall : ∀ e : ℕ, 4 ≤ e → (1 / 2 : ℝ) ^ e < 1 / 10 := by
    intro e he
    calc (1 / 2 : ℝ) ^ e ≤ (1 / 2 : ℝ) ^ 4 := pow_le_pow_of_le_one (by norm_num) (by norm_num) he
      _ < 1 / 10 := by norm_num
  refine ⟨(1 / 2 : ℝ) ^ P.epsExp, (1 / 2 : ℝ) ^ P.betaExp, by positivity,
    hsmall _ hP.four_le_epsExp, by positivity, hsmall _ hP.four_le_betaExp, ?_⟩
  unfold mkStreamParams
  rw [dyadicExp_half_pow, dyadicExp_half_pow]

/-! ## The box promise -/

theorem boxUpTo_mono {n U : ℕ} {adv : StreamAdversary n} {outs : ℕ → ℚ} {t r : ℕ}
    (h : BoxUpTo U adv outs t) (hr : r ≤ t) : BoxUpTo U adv outs r :=
  fun s hs i => h s (hs.trans hr) i

theorem boxSeq_mono {n U : ℕ} {us : ℕ → Fin n × ℤ} {t r : ℕ} (h : BoxSeq U us t) (hr : r ≤ t) :
    BoxSeq U us r :=
  fun s hs i => h s (hs.trans hr) i

theorem seqVec_zero {n : ℕ} (us : ℕ → Fin n × ℤ) (i : Fin n) :
    seqVec us 0 i = if (us 0).1 = i then (us 0).2 else 0 := by
  simp [seqVec]

theorem seqVec_succ {n : ℕ} (us : ℕ → Fin n × ℤ) (t : ℕ) (i : Fin n) :
    seqVec us (t + 1) i = seqVec us t i + (if (us (t + 1)).1 = i then (us (t + 1)).2 else 0) := by
  unfold seqVec
  rw [Finset.sum_range_succ]

/-- Under the box promise after rounds `0, …, t`, the increment of round `t` satisfies `|Δ| ≤ 2U`. -/
theorem abs_update_le_of_boxSeq {n U : ℕ} {us : ℕ → Fin n × ℤ} {t : ℕ} (h : BoxSeq U us t) :
    |(us t).2| ≤ 2 * (U : ℤ) := by
  cases t with
  | zero =>
    have h0 := h 0 le_rfl (us 0).1
    rw [seqVec_zero, if_pos rfl] at h0
    have hU : (0 : ℤ) ≤ U := Int.natCast_nonneg U
    linarith
  | succ t =>
    have h1 := h (t + 1) le_rfl (us (t + 1)).1
    have h0 := h t (Nat.le_succ t) (us (t + 1)).1
    rw [seqVec_succ, if_pos rfl] at h1
    have key : (us (t + 1)).2 =
        (seqVec us t (us (t + 1)).1 + (us (t + 1)).2) - seqVec us t (us (t + 1)).1 := by ring
    rw [key]
    calc |(seqVec us t (us (t + 1)).1 + (us (t + 1)).2) - seqVec us t (us (t + 1)).1|
        ≤ |seqVec us t (us (t + 1)).1 + (us (t + 1)).2| + |seqVec us t (us (t + 1)).1| :=
          abs_sub _ _
      _ ≤ (U : ℤ) + U := add_le_add h1 h0
      _ = 2 * (U : ℤ) := by ring

/-! ## The tapes of the runs -/

/-- The tape of run `j` as a list (`[]` beyond the last run `m`). -/
def tapeAt {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) (j : ℕ) : List Bool :=
  if h : j < P.m + 1 then List.ofFn (tapes ⟨j, h⟩) else []

theorem tapeAt_of_lt {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) {j : ℕ}
    (h : j < P.m + 1) : tapeAt tapes j = List.ofFn (tapes ⟨j, h⟩) :=
  dif_pos h

theorem length_tapeAt {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) {j : ℕ}
    (h : j < P.m + 1) : (tapeAt tapes j).length = B := by
  rw [tapeAt_of_lt tapes h, List.length_ofFn]

theorem tapeAt_zero {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) :
    tapeAt tapes 0 = List.ofFn (tapes 0) :=
  tapeAt_of_lt tapes (Nat.succ_pos _)

theorem tapeAt_succ {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool) {t : ℕ}
    (ht : t < P.m) : tapeAt tapes (t + 1) = List.ofFn (tapes (Fin.succ ⟨t, ht⟩)) :=
  tapeAt_of_lt tapes (Nat.succ_lt_succ ht)

/-! ## The canonical run -/

/-- The canonical run of `A` against the deterministic adversary `adv` with the tapes `tapes`:
`A.run P adv tapes t = some (s, qs)` means that the initialization and the rounds `0, …, t-1` succeeded,
`s` is the state before round `t` and `qs` the list of the estimates of rounds `0, …, t-1`; the update
of round `t` is `adv qs`. -/
def MathStreamAlg.run (A : MathStreamAlg) (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) : ℕ → Option (A.State × List ℚ)
  | 0 => (A.init P (tapeAt tapes 0)).map (fun r => (r.1, []))
  | t + 1 => (A.run P adv tapes t).bind (fun c =>
      (A.step P c.1 (adv c.2) (tapeAt tapes (t + 1))).map (fun r => (r.1.1, c.2 ++ [r.1.2])))

/-- The estimate of round `t` in the canonical run (`0` if the run failed before). -/
def MathStreamAlg.outs (A : MathStreamAlg) (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (t : ℕ) : ℚ :=
  ((A.run P adv tapes (t + 1)).map (fun c => c.2.getD t 0)).getD 0

section run

variable {A : MathStreamAlg} {P : StreamParams} {adv : StreamAdversary P.n}
  {tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool}

theorem run_zero_eq :
    A.run P adv tapes 0 = (A.init P (tapeAt tapes 0)).map (fun r => (r.1, [])) :=
  rfl

theorem run_succ_eq (t : ℕ) :
    A.run P adv tapes (t + 1) = (A.run P adv tapes t).bind (fun c =>
      (A.step P c.1 (adv c.2) (tapeAt tapes (t + 1))).map (fun r => (r.1.1, c.2 ++ [r.1.2]))) :=
  rfl

theorem run_succ_of_some {t : ℕ} {c : A.State × List ℚ} (hc : A.run P adv tapes t = some c)
    {s' : A.State} {q : ℚ} {rest : List Bool}
    (hs : A.step P c.1 (adv c.2) (tapeAt tapes (t + 1)) = some ((s', q), rest)) :
    A.run P adv tapes (t + 1) = some (s', c.2 ++ [q]) := by
  rw [run_succ_eq, hc, Option.bind_some, hs, Option.map_some]

theorem run_succ_some {t : ℕ} {c' : A.State × List ℚ} (h : A.run P adv tapes (t + 1) = some c') :
    ∃ c, A.run P adv tapes t = some c ∧ ∃ (s' : A.State) (q : ℚ) (rest : List Bool),
      A.step P c.1 (adv c.2) (tapeAt tapes (t + 1)) = some ((s', q), rest) ∧
        c' = (s', c.2 ++ [q]) := by
  rw [run_succ_eq] at h
  obtain ⟨c, hc, h⟩ := Option.bind_eq_some_iff.mp h
  obtain ⟨r, hr, rfl⟩ := Option.map_eq_some_iff.mp h
  exact ⟨c, hc, r.1.1, r.1.2, r.2, hr, rfl⟩

/-- The estimate list before round `t` has length `t`. -/
theorem run_length {t : ℕ} {c : A.State × List ℚ} (h : A.run P adv tapes t = some c) :
    c.2.length = t := by
  induction t generalizing c with
  | zero =>
    rw [run_zero_eq] at h
    obtain ⟨r, -, rfl⟩ := Option.map_eq_some_iff.mp h
    rfl
  | succ t ih =>
    obtain ⟨c₀, h₀, s', q, rest, -, rfl⟩ := run_succ_some h
    simp [ih h₀]

/-- The estimates of the canonical run before round `t` are `A.outs` of the rounds `< t`. -/
theorem outs_eq_of_run {t : ℕ} {c : A.State × List ℚ} (h : A.run P adv tapes t = some c) :
    ∀ r < t, A.outs P adv tapes r = c.2.getD r 0 := by
  induction t generalizing c with
  | zero => exact fun r hr => absurd hr (Nat.not_lt_zero r)
  | succ t ih =>
    intro r hr
    obtain ⟨c₀, h₀, s', q, rest, -, rfl⟩ := run_succ_some h
    have hlen := run_length h₀
    rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hr | rfl
    · rw [ih h₀ r hr]
      exact (List.getD_append _ _ _ _ (by omega)).symm
    · rw [MathStreamAlg.outs, h]
      rfl

/-- The history seen by the adversary before round `t` is the estimate list of the canonical run. -/
theorem run_hist {t : ℕ} {c : A.State × List ℚ} (h : A.run P adv tapes t = some c) :
    List.ofFn (fun r : Fin t => A.outs P adv tapes r.val) = c.2 := by
  have hlen := run_length h
  apply List.ext_getElem
  · simp [hlen]
  · intro r h1 h2
    simp only [List.getElem_ofFn]
    rw [outs_eq_of_run h r (by simpa using h1), List.getD_eq_getElem _ _ h2]

theorem advUpdate_outs_of_run {t : ℕ} {c : A.State × List ℚ} (h : A.run P adv tapes t = some c) :
    advUpdate adv (A.outs P adv tapes) t = adv c.2 := by
  unfold advUpdate
  rw [run_hist h]

/-- For a total algorithm the canonical run succeeds up to round `t` (and its state is reachable) as
long as the box promise held after all rounds before `t`. -/
theorem run_reach (hT : A.Total) (hP : ParamsOK P) :
    ∀ t : ℕ, (∀ r < t, r < P.m ∧ BoxUpTo P.U adv (A.outs P adv tapes) r) →
      ∃ c, A.run P adv tapes t = some c ∧
        Reach A P (advUpdate adv (A.outs P adv tapes)) t c.1 := by
  intro t
  induction t with
  | zero =>
    intro _
    have hlen := length_tapeAt tapes (Nat.succ_pos P.m)
    obtain ⟨s, rest, hs⟩ := hT.init_total P hP (tapeAt tapes 0) hlen
    refine ⟨(s, []), ?_, Reach.init hlen hs⟩
    rw [run_zero_eq, hs, Option.map_some]
  | succ t ih =>
    intro hr
    obtain ⟨htm, hbox⟩ := hr t (Nat.lt_succ_self t)
    obtain ⟨c, hc, hreach⟩ := ih (fun r hrt => hr r (Nat.lt_succ_of_lt hrt))
    have hlen := length_tapeAt tapes (Nat.succ_lt_succ htm)
    obtain ⟨s', q, rest, hs⟩ := hT.step_total P hP _ t c.1 hreach htm hbox _ hlen
    have hs' : A.step P c.1 (adv c.2) (tapeAt tapes (t + 1)) = some ((s', q), rest) := by
      rw [← advUpdate_outs_of_run hc]
      exact hs
    exact ⟨(s', c.2 ++ [q]), run_succ_of_some hc hs', Reach.step hreach hlen hs⟩

end run

/-! ## Executions -/

/-- The states of an execution are reachable (for the adversary's update sequence) as long as the box
promise held after all previous rounds. -/
theorem reach_of_mathExec {A : MathStreamAlg} {P : StreamParams} {adv : StreamAdversary P.n}
    {tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool} {states : ℕ → A.State} {outs : ℕ → ℚ}
    (h : MathExec A P adv tapes states outs) :
    ∀ t : ℕ, (∀ r < t, r < P.m ∧ BoxUpTo P.U adv outs r) →
      Reach A P (advUpdate adv outs) t (states t) := by
  intro t
  induction t with
  | zero =>
    intro _
    obtain ⟨rest, hi⟩ := h.1
    exact Reach.init List.length_ofFn hi
  | succ t ih =>
    intro hr
    obtain ⟨htm, hbox⟩ := hr t (Nat.lt_succ_self t)
    have hreach := ih (fun r hrt => hr r (Nat.lt_succ_of_lt hrt))
    obtain ⟨rest, hs⟩ := h.2 t htm hbox
    exact Reach.step hreach List.length_ofFn hs

/-- For a total algorithm, executions exist for every adversary and all tapes: the canonical run (with
its estimates `A.outs`) is one. -/
theorem exists_mathExec {A : MathStreamAlg} (hT : A.Total) {P : StreamParams} (hP : ParamsOK P)
    (adv : StreamAdversary P.n) (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) :
    ∃ states : ℕ → A.State, MathExec A P adv tapes states (A.outs P adv tapes) := by
  obtain ⟨c₀, hc₀, -⟩ := run_reach (adv := adv) (tapes := tapes) hT hP 0
    (fun r hr => absurd hr (Nat.not_lt_zero r))
  refine ⟨fun t => ((A.run P adv tapes t).map Prod.fst).getD c₀.1, ?_, ?_⟩
  · -- initialization
    have h0 := hc₀
    rw [run_zero_eq] at h0
    obtain ⟨r, hr, hrc⟩ := Option.map_eq_some_iff.mp h0
    refine ⟨r.2, ?_⟩
    simp only [hc₀, Option.map_some, Option.getD_some]
    rw [← tapeAt_zero, hr, ← hrc]
  · -- round `t`
    intro t ht hbox
    obtain ⟨c, hc, hreach⟩ := run_reach hT hP t
      (fun r hr => ⟨lt_trans hr ht, boxUpTo_mono hbox hr.le⟩)
    have hlen := length_tapeAt tapes (Nat.succ_lt_succ ht)
    obtain ⟨s', q, rest, hs⟩ := hT.step_total P hP _ t c.1 hreach ht hbox _ hlen
    have hs' : A.step P c.1 (adv c.2) (tapeAt tapes (t + 1)) = some ((s', q), rest) := by
      rw [← advUpdate_outs_of_run hc]
      exact hs
    have hc' := run_succ_of_some hc hs'
    have hq : A.outs P adv tapes t = q := by
      rw [outs_eq_of_run hc' t (Nat.lt_succ_self t),
        List.getD_append_right _ _ _ _ (le_of_eq (run_length hc)), run_length hc, Nat.sub_self]
      rfl
    refine ⟨rest, ?_⟩
    simp only [hc, hc', Option.map_some, Option.getD_some]
    rw [hq, ← tapeAt_succ tapes ht]
    exact hs

end F2e2e.C.Top
