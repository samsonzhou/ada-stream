import F2e2e.C.Top.BitProgLaw
import F2e2e.C.Alg.Bits

/-!
# Theorem (C), top level: the interface instance for C-ALG's algorithm

* `theAlg`: C-ALG's mathematical algorithm (`F2e2e.C.Alg.algInit`, `F2e2e.C.Alg.algStep`, tape length
  `F2e2e.C.Alg.tapeBits`) as a `MathStreamAlg` (`MathStreamAlg.ofBitProg`; the coordinate `i : Fin n`
  is passed as the natural number `i.val`, 0-based as in C-ALG).
* `theAlg_total`: totality, from C-ALG's uniform depth bounds (`depth_algInit_le`,
  `depth_algStep_le`).
* `TheLawBound`: **the Part III target** (C-CLOSE): for every parameter record with `ParamsOK` and every
  deterministic adversary, the law of the sequential interaction (`interact`, `BitProgLaw.lean`) gives
  probability at most `β₀ = 2^{-betaExp}` to the event that the estimate list is not `ε₀`-accurate
  (`ε₀ = 2^{-epsExp}`) up to the first violation of the box promise (`BadOutcome`).
* `theAlg_good : TheLawBound → MathAlgGood theAlg` (via `total_and_mathAlgGood_ofBitProg`).

With the DSL side (`I : Impl theAlg S`, `hB : RunsBound RunsWithinBits I`), `theorem_C_of_runsBound theAlg
theAlg_total (theAlg_good h) S I hB : Theorem_C` (`F2e2e/C/Top/AssembleW.lean`; the Spec v1 text:
`theorem_C_of_impl theAlg theAlg_total (theAlg_good h) S I hS : Theorem_C_v1` from `hS : SpaceOK S`).
-/

namespace F2e2e.C.Top

open F2e2e.Discrete F2e2e.C.Alg

/-- The round program of C-ALG's algorithm for the parameters `P`, on the update `u`. -/
def theStep (P : StreamParams) (s : State) (u : Fin P.n × ℤ) : BitProg (State × ℚ) :=
  algStep P s u.1.val u.2

/-- C-ALG's algorithm in the interface of `F2e2e/C/Top/Interface.lean`. -/
def theAlg : MathStreamAlg :=
  MathStreamAlg.ofBitProg State tapeBits algInit theStep

theorem theAlg_init_depth (P : StreamParams) : (algInit P).depth ≤ tapeBits P :=
  (depth_algInit_le P).trans (le_max_left _ _)

theorem theAlg_step_depth (P : StreamParams) (s : State) (u : Fin P.n × ℤ) :
    (theStep P s u).depth ≤ tapeBits P :=
  (depth_algStep_le P s u.1.val u.2).trans (le_max_right _ _)

/-- **Totality** of C-ALG's algorithm. -/
theorem theAlg_total : theAlg.Total :=
  total_ofBitProg_of_uniform (fun P _ => theAlg_init_depth P) (fun P _ s u => theAlg_step_depth P s u)

/-- **The Part III target**: the failure event of the sequential interaction has probability at most
`β₀ = 2^{-betaExp}` (accuracy `ε₀ = 2^{-epsExp}`), for every parameter record and every deterministic
adversary. -/
def TheLawBound : Prop :=
  ∀ P : StreamParams, ParamsOK P → ∀ adv : StreamAdversary P.n,
    (interact (algInit P) (theStep P) adv P.m).law.toOuterMeasure
        (BadOutcome P adv ((1 / 2 : ℝ) ^ P.epsExp)) ≤
      ENNReal.ofReal ((1 / 2 : ℝ) ^ P.betaExp)

/-- **Accuracy** of C-ALG's algorithm in the Spec's probability model, from the Part III target. -/
theorem theAlg_good (h : TheLawBound) : MathAlgGood theAlg :=
  (total_and_mathAlgGood_ofBitProg (fun P _ => theAlg_init_depth P)
    (fun P _ s u => theAlg_step_depth P s u) h).2

end F2e2e.C.Top
