import F2e2e.Spec

/-!
# Theorem (C): top-level interface (mathematical algorithm + DSL implementation)

This file fixes the contract between the two halves of the proof of `F2e2e.Theorem_C`:

* the **Part III side** defines an exact mathematical streaming algorithm `A : MathStreamAlg` (a state
  machine reading fresh fair bits from a tape) and proves
  - `A.Total`: on every run the algorithm never fails on a tape of `A.tapeLen P` bits (a priori bound on
    the randomness per run: capped samplers, row seeds, …), and
  - `MathAlgGood A`: the accuracy statement of `Theorem_C` (conjunct 2) for `A`, in exactly the Spec's
    probability model (uniform tapes of `A.tapeLen P` bits per run, an arbitrary randomized adaptive
    adversary, accuracy up to the first violation of the box promise);
* the **DSL side** provides `I : Impl A S`: programs `initProg`, `updProg` (in the cost model of Spec §3)
  that compute `A`'s initialization and rounds on the encoded states (encoding `I.enc` of its choice),
  consume exactly the same fresh bits, and run within peak space `S P`; and proves `SpaceOK S`
  (`S P ≤ spaceBoundC n m U ε β` on the parameters of Theorem C).

`F2e2e.C.Top.theorem_C_of_runsBound` (`F2e2e/C/Top/AssembleW.lean`) derives the Spec's `Theorem_C` from
`A.Total`, `MathAlgGood A`, `I : Impl A S` and `RunsBound RunsWithinBits I` (every run of the programs within
`S P` is a small-step machine run within `spaceBoundC` bits), with `StreamAlgorithm.tapeLen := A.tapeLen`;
`F2e2e.C.Top.theorem_C_of_impl` (`F2e2e/C/Top/Assemble.lean`) derives the Spec v1 text `Theorem_C_v1`
(`F2e2e/SpecV1Compat.lean`) from `SpaceOK S` instead.

## Conventions
* Rounds are numbered `t = 0, 1, …` as in the Spec (Lean round `t` = paper update `t + 1`); run `0` is the
  initialization (tape `0`), run `t + 1` is round `t` (tape `t + 1`).
* Update histories are sequences `us : ℕ → Fin P.n × ℤ` (`us t` = update of round `t`); `seqVec` and
  `BoxSeq` are `streamVec`/`BoxUpTo` for a fixed sequence, so that
  `BoxUpTo U adv outs t ↔ BoxSeq U (advUpdate adv outs) t` holds by `Iff.rfl` (`boxUpTo_iff_boxSeq`).
* `Reach A P us t s`: `s` is a possible state before round `t` after the updates `us 0, …, us (t-1)`,
  every run having a tape of exactly `A.tapeLen P` bits. `Total` and `Impl` are required only for reachable
  states, rounds `t < m`, and updates keeping the box promise after rounds `0, …, t` (`BoxSeq P.U us t`):
  this is exactly what `StreamExec` (every execution, up to the first box violation) needs.
* The estimate of a round is a rational `q`; the DSL may output any `[a, d]` with `parseEstimate [a, d] = q`
  (e.g. a non-reduced fraction); `q ≥ 0` is therefore needed (and is the DSL side's to establish).
* Parameter records: `ParamsOK P` (`n, m, U ≥ 1`, `epsExp, betaExp ≥ 4`) holds for every
  `mkStreamParams n m U ε β` under the hypotheses of `Theorem_C` (`paramsOK_mkStreamParams`,
  `F2e2e/C/Top/Run.lean`), and conversely every record with `ParamsOK` arises this way
  (`ε = 2^{-epsExp}`, `β = 2^{-betaExp}`), so quantifying over `ParamsOK P` loses nothing.

This file imports only the Spec (no proofs depend on other project modules).
-/

namespace F2e2e.C.Top

open MeasureTheory

/-! ## Parameters -/

/-- The parameter records on which the algorithm must work: those with `n, m, U ≥ 1` and
`epsExp, betaExp ≥ 4` (every `mkStreamParams n m U ε β` with `n, m, U ≥ 1`, `ε, β ∈ (0, 1/10)`). -/
structure ParamsOK (P : StreamParams) : Prop where
  one_le_n : 1 ≤ P.n
  one_le_m : 1 ≤ P.m
  one_le_U : 1 ≤ P.U
  four_le_epsExp : 4 ≤ P.epsExp
  four_le_betaExp : 4 ≤ P.betaExp

/-! ## The mathematical algorithm -/

/-- An exact single-pass streaming algorithm as mathematics: a state machine that reads fresh fair bits
sequentially from a tape (`List Bool`) and returns the unread rest of the tape.
* `State`: the algorithm's entire memory between updates;
* `tapeLen P`: the number of fresh bits given to each run (the initialization or one round);
* `init P tape = some (s, rest)`: the initialization with parameters `P` produces the state `s` and leaves
  the bits `rest` unread;
* `step P s (i, Δ) tape = some ((s', q), rest)`: the round processing the update `x_i ← x_i + Δ` from
  the state `s` produces the state `s'` and the estimate `F̂ = q`, leaving `rest` unread.
`none` means failure (e.g. the tape ran out). -/
structure MathStreamAlg where
  State : Type
  tapeLen : StreamParams → ℕ
  init : (P : StreamParams) → List Bool → Option (State × List Bool)
  step : (P : StreamParams) → State → Fin P.n × ℤ → List Bool → Option ((State × ℚ) × List Bool)

/-! ## Update sequences and the box promise -/

/-- The stream vector `x^{(t+1)}` after the updates `us 0, …, us t` (the formula of `streamVec`). -/
def seqVec {n : ℕ} (us : ℕ → Fin n × ℤ) (t : ℕ) (i : Fin n) : ℤ :=
  ∑ s ∈ Finset.range (t + 1), if (us s).1 = i then (us s).2 else 0

/-- The box promise `‖x^{(s+1)}‖_∞ ≤ U` holds after each of the updates `us 0, …, us t` (the formula of
`BoxUpTo`). -/
def BoxSeq {n : ℕ} (U : ℕ) (us : ℕ → Fin n × ℤ) (t : ℕ) : Prop :=
  ∀ s ≤ t, ∀ i : Fin n, |seqVec us s i| ≤ (U : ℤ)

/-- The Spec's box promise is `BoxSeq` for the adversary's update sequence. -/
theorem boxUpTo_iff_boxSeq {n : ℕ} (U : ℕ) (adv : StreamAdversary n) (outs : ℕ → ℚ) (t : ℕ) :
    BoxUpTo U adv outs t ↔ BoxSeq U (advUpdate adv outs) t :=
  Iff.rfl

/-! ## Reachable states and totality -/

/-- `Reach A P us t s`: `s` is a possible state of `A` (parameters `P`) before round `t` when the updates
of the rounds `0, …, t-1` are `us 0, …, us (t-1)` and every run gets a tape of exactly `A.tapeLen P`
bits. -/
inductive Reach (A : MathStreamAlg) (P : StreamParams) (us : ℕ → Fin P.n × ℤ) :
    ℕ → A.State → Prop
  | init {tape : List Bool} {s : A.State} {rest : List Bool} :
      tape.length = A.tapeLen P → A.init P tape = some (s, rest) → Reach A P us 0 s
  | step {t : ℕ} {s : A.State} {tape : List Bool} {s' : A.State} {q : ℚ} {rest : List Bool} :
      Reach A P us t s → tape.length = A.tapeLen P →
        A.step P s (us t) tape = some ((s', q), rest) → Reach A P us (t + 1) s'

/-- **Totality** (a mathematical property of `A`, for the Part III side): for every parameter record of
Theorem C, the initialization and every round `t < m` from a reachable state, whose update keeps the box
promise after rounds `0, …, t`, succeed on every tape of exactly `A.tapeLen P` bits. -/
structure MathStreamAlg.Total (A : MathStreamAlg) : Prop where
  init_total : ∀ P : StreamParams, ParamsOK P → ∀ tape : List Bool, tape.length = A.tapeLen P →
    ∃ (s : A.State) (rest : List Bool), A.init P tape = some (s, rest)
  step_total : ∀ P : StreamParams, ParamsOK P → ∀ (us : ℕ → Fin P.n × ℤ) (t : ℕ) (s : A.State),
    Reach A P us t s → t < P.m → BoxSeq P.U us t →
    ∀ tape : List Bool, tape.length = A.tapeLen P →
      ∃ (s' : A.State) (q : ℚ) (rest : List Bool), A.step P s (us t) tape = some ((s', q), rest)

/-! ## Executions and accuracy of the mathematical algorithm -/

/-- An execution of the mathematical algorithm `A` against the deterministic adversary `adv` with the
tapes `tapes`, in the format of the Spec's `StreamExec` (tape `0` for the initialization, tape `t + 1`
for round `t`): the states `states t` (before round `t`) and the estimates `outs t` (after round `t`)
are produced by `A.init` and by `A.step` for every round `t < m` up to the first violation of the box
promise. (For a total algorithm one execution exists for all `adv` and `tapes`:
`F2e2e.C.Top.exists_mathExec`, `F2e2e/C/Top/Run.lean`, via the canonical run `MathStreamAlg.run`.) -/
def MathExec (A : MathStreamAlg) (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (states : ℕ → A.State) (outs : ℕ → ℚ) :
    Prop :=
  (∃ rest : List Bool, A.init P (List.ofFn (tapes 0)) = some (states 0, rest)) ∧
  ∀ (t : ℕ) (ht : t < P.m), BoxUpTo P.U adv outs t →
    ∃ rest : List Bool,
      A.step P (states t) (advUpdate adv outs t) (List.ofFn (tapes (Fin.succ ⟨t, ht⟩))) =
        some ((states (t + 1), outs t), rest)

/-- **Accuracy of the mathematical algorithm** (for the Part III side): conjunct 2 of `Theorem_C` with
`A` in place of the DSL programs, in exactly the Spec's probability model: for all `n, m, U ≥ 1`,
`ε, β ∈ (0, 1/10)` and every randomized adaptive adversary (any coin probability space, measurable in the
coins for each fixed history), the probability over the adversary's coins and the `(m + 1)` uniform
tapes of `A.tapeLen P` bits that no execution of `A` is accurate up to the first violation of the box
promise is at most `β`. -/
def MathAlgGood (A : MathStreamAlg) : Prop :=
  ∀ (n m U : ℕ) (ε β : ℝ), 1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1 / 10 → 0 < β → β < 1 / 10 →
    ∀ (Ω : Type) [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
      (adv : Ω → StreamAdversary (mkStreamParams n m U ε β).n),
      (∀ h : List ℚ, Measurable (fun ω => adv ω h)) →
        ∑ tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
            Fin (A.tapeLen (mkStreamParams n m U ε β)) → Bool,
          P {ω | ¬ ∃ (states : ℕ → A.State) (outs : ℕ → ℚ),
              MathExec A (mkStreamParams n m U ε β) (adv ω) tapes states outs ∧
              StreamAccurate m U ε (adv ω) outs} ≤
          ENNReal.ofReal β *
            2 ^ (((mkStreamParams n m U ε β).m + 1) * A.tapeLen (mkStreamParams n m U ε β))

/-! ## The DSL implementation -/

/-- `RunsOn` with a prescribed leftover tape: the program `prog` (entry point: function `0`) runs on
`input` with the tape `tape`, halts with output `out` within peak space `S`, and leaves exactly the bits
`rest` unread. -/
def RunsOnRest (prog : List Expr) (input : Val) (tape : List Bool) (out : Val) (S : ℝ)
    (rest : List Bool) : Prop :=
  ∃ (body : Expr) (fuel cost peak : ℕ), prog[0]? = some body ∧
    eval prog fuel (valSize input) [input] tape body = some (out, cost, peak, rest) ∧
    (peak : ℝ) ≤ S

/-- A **DSL implementation** of `A` with peak space `S P` per run (for the DSL side): an encoding `enc`
of the states and two programs such that, for every parameter record of Theorem C and every tape of
`A.tapeLen P` bits,
* `init_runs`: whenever `A.init P tape = some (s, rest)`, `initProg` on the encoded parameters returns
  `enc s`, consumes exactly the bits before `rest`, with peak `≤ S P`;
* `upd_runs`: for every reachable state `s` before a round `t < m` whose update `us t` keeps the box
  promise, whenever `A.step P s (us t) tape = some ((s', q), rest)`, `updProg` on the Spec's input
  `[params, enc s, i, Δ]` returns `[enc s', outV]` with `parseEstimate outV = some q`, consumes exactly
  the bits before `rest`, with peak `≤ S P`. -/
structure Impl (A : MathStreamAlg) (S : StreamParams → ℝ) where
  enc : A.State → Val
  initProg : List Expr
  updProg : List Expr
  init_runs : ∀ P : StreamParams, ParamsOK P → ∀ tape : List Bool, tape.length = A.tapeLen P →
    ∀ (s : A.State) (rest : List Bool), A.init P tape = some (s, rest) →
      RunsOnRest initProg (encStreamParams P) tape (enc s) (S P) rest
  upd_runs : ∀ P : StreamParams, ParamsOK P → ∀ (us : ℕ → Fin P.n × ℤ) (t : ℕ) (s : A.State),
    Reach A P us t s → t < P.m → BoxSeq P.U us t →
    ∀ tape : List Bool, tape.length = A.tapeLen P →
    ∀ (s' : A.State) (q : ℚ) (rest : List Bool), A.step P s (us t) tape = some ((s', q), rest) →
      ∃ outV : Val, parseEstimate outV = some q ∧
        RunsOnRest updProg
          (Val.list [encStreamParams P, enc s, Val.int ((us t).1 : ℤ), Val.int (us t).2]) tape
          (Val.list [enc s', outV]) (S P) rest

/-- The **space budget** (for the DSL side): the peak-space function `S` is at most the bound
`2^512 ε^{-2} Λ^15` of Theorem C on its parameter records. -/
def SpaceOK (S : StreamParams → ℝ) : Prop :=
  ∀ (n m U : ℕ) (ε β : ℝ), 1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1 / 10 → 0 < β → β < 1 / 10 →
    S (mkStreamParams n m U ε β) ≤ spaceBoundC n m U ε β

/-- The Spec's streaming algorithm assembled from an implementation: `tapeLen := A.tapeLen`. -/
def Impl.alg {A : MathStreamAlg} {S : StreamParams → ℝ} (I : Impl A S) : StreamAlgorithm where
  tapeLen := A.tapeLen
  initProg := I.initProg
  updProg := I.updProg

end F2e2e.C.Top
