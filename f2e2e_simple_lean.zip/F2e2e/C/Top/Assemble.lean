import F2e2e.C.Top.Run
import F2e2e.SpecV1Compat

/-!
# Theorem (C) from a mathematical algorithm and a DSL implementation (Spec v1 form)

`theorem_C_of_impl`: the Spec v1 headline `F2e2e.Theorem_C_v1` (`F2e2e/SpecV1Compat.lean`: the v1 text, with
`StreamExecV1`, i.e. `RunsOn`) follows from
* a mathematical algorithm `A : MathStreamAlg` with `A.Total` and `MathAlgGood A` (Part III side), and
* a DSL implementation `I : Impl A S` with `SpaceOK S` (DSL side),
for the Spec algorithm `I.alg` (`tapeLen := A.tapeLen`, programs `I.initProg`, `I.updProg`).

Proof: an execution of `A` (`MathExec`) is turned into an execution of the programs (`StreamExecV1`) with the
encoded states and the same estimates (`streamExec_of_mathExec`, using `reach_of_mathExec` for the
hypotheses of `Impl.upd_runs`); conjunct 1 uses the canonical run of `A` (`exists_mathExec`, from totality);
conjunct 2 is `MathAlgGood A` and monotonicity of the measure (the Spec's failure set is contained in the
mathematical one).

The Spec's `Theorem_C` (run predicate `RunsWithinBits`) is `theorem_C_of_runsBound`
(`F2e2e/C/Top/AssembleW.lean`), which uses `streamExec_of_mathExec` and converts every run.
-/

namespace F2e2e.C.Top

open MeasureTheory

theorem RunsOnRest.runsOn {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S : ℝ}
    {rest : List Bool} (h : RunsOnRest prog input tape out S rest) :
    RunsOn prog input tape out S := by
  obtain ⟨body, fuel, cost, peak, hb, he, hp⟩ := h
  exact ⟨body, fuel, cost, peak, rest, hb, he, hp⟩

theorem RunsOnRest.mono {prog : List Expr} {input : Val} {tape : List Bool} {out : Val} {S S' : ℝ}
    {rest : List Bool} (h : RunsOnRest prog input tape out S rest) (hS : S ≤ S') :
    RunsOnRest prog input tape out S' rest := by
  obtain ⟨body, fuel, cost, peak, hb, he, hp⟩ := h
  exact ⟨body, fuel, cost, peak, hb, he, hp.trans hS⟩

/-- An execution of `A` gives an execution of the implementing programs, with the encoded states and the
same estimates, within any space bound `≥ S P`. -/
theorem streamExec_of_mathExec {A : MathStreamAlg} {S : StreamParams → ℝ} (I : Impl A S)
    {P : StreamParams} (hP : ParamsOK P) {Sb : ℝ} (hSb : S P ≤ Sb) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (states : ℕ → A.State) (outs : ℕ → ℚ)
    (h : MathExec A P adv tapes states outs) :
    StreamExecV1 I.alg P Sb adv tapes (fun t => I.enc (states t)) outs := by
  refine ⟨?_, ?_⟩
  · obtain ⟨rest, hi⟩ := h.1
    exact ((I.init_runs P hP _ List.length_ofFn _ _ hi).mono hSb).runsOn
  · intro t ht hbox
    obtain ⟨rest, hs⟩ := h.2 t ht hbox
    have hreach := reach_of_mathExec h t (fun r hr => ⟨lt_trans hr ht, boxUpTo_mono hbox hr.le⟩)
    obtain ⟨outV, hparse, hrun⟩ :=
      I.upd_runs P hP (advUpdate adv outs) t (states t) hreach ht
        ((boxUpTo_iff_boxSeq _ _ _ _).mp hbox) _ List.length_ofFn _ _ _ hs
    exact ⟨outV, (hrun.mono hSb).runsOn, hparse⟩

/-- **Theorem (C) from a mathematical algorithm and a DSL implementation** (Spec v1 text). -/
theorem theorem_C_of_impl (A : MathStreamAlg) (hT : A.Total) (hG : MathAlgGood A)
    (S : StreamParams → ℝ) (I : Impl A S) (hS : SpaceOK S) : Theorem_C_v1 := by
  refine ⟨I.alg, fun n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 => ?_⟩
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hSb := hS n m U ε β hn hm hU hε0 hε1 hβ0 hβ1
  refine ⟨fun adv tapes => ?_, fun Ω _ μ _ adv hadv => ?_⟩
  · -- conjunct 1: the canonical run of `A`, implemented by the programs
    obtain ⟨states, hex⟩ := exists_mathExec hT hP adv tapes
    exact ⟨_, _, streamExec_of_mathExec I hP hSb adv tapes states _ hex⟩
  · -- conjunct 2: the Spec's failure set is contained in the mathematical one
    refine le_trans (Finset.sum_le_sum fun tapes _ => measure_mono ?_)
      (hG n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 Ω μ adv hadv)
    intro ω hω hex
    obtain ⟨states, outs, hexec, hacc⟩ := hex
    exact hω ⟨_, outs, streamExec_of_mathExec I hP hSb (adv ω) tapes states outs hexec, hacc⟩

end F2e2e.C.Top
