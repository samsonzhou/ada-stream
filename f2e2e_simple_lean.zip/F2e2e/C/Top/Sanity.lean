import F2e2e.Cost.Facts
import F2e2e.Cost.MachineRun
import F2e2e.C.Top.Det
import F2e2e.C.Top.AssembleW

/-!
# Theorem (C): determinism of executions (sanity check of the Spec, STATEMENT_REVIEW.md C.3.8)

`StreamExec` asserts the *existence* of states and estimates produced by the program runs. Since the
small-step machine is deterministic (the output of a run is unique, `runsWithinBits_out_unique`) and the box
promise `BoxUpTo … t` depends only on the estimates `outs 0, …, outs (t-1)`, these are **unique up to the
first violation of the box promise**, whatever the space bounds: the prover of `Theorem_C` cannot choose them
(in particular it cannot falsify `BoxUpTo` by choosing `outs`).

* `advUpdate_congr`: the update of round `s` depends only on the estimates of the rounds `< s`;
* `streamExecW_unique`: for any run predicate whose outputs are unique, two executions of the same algorithm
  against the same adversary with the same tapes have the same states before every round `t ≤ m` and the
  same estimates of the rounds `< t`, as long as the box promise held after all rounds `< t` (for either
  execution: they agree);
* `streamExec_unique`: the instance for the Spec's `StreamExec` (`RunsWithinBits`);
* `streamExecV1_unique`: the instance for the Spec v1 `StreamExecV1` (`RunsOn`, `Cost.runsOn_out_unique`).
-/

namespace F2e2e.C.Top

/-- The update of round `s` depends only on the estimates of the rounds `< s`. -/
theorem advUpdate_congr {n : ℕ} (adv : StreamAdversary n) {outs outs' : ℕ → ℚ} {s : ℕ}
    (h : ∀ r < s, outs r = outs' r) : advUpdate adv outs s = advUpdate adv outs' s := by
  unfold advUpdate
  congr 1
  exact List.ofFn_inj.mpr (funext fun r => h r.val r.isLt)

/-- From a halting configuration the machine makes no step. -/
theorem stepN_halted {prog : List Expr} {v : Val} {r : List Bool} {c : Conf} :
    ∀ {k : ℕ}, stepN prog k ⟨Ctrl.ret v, [], r⟩ = some c → k = 0 ∧ c = ⟨Ctrl.ret v, [], r⟩
  | 0, h => ⟨rfl, (Option.some.inj h).symm⟩
  | k + 1, h => by simp [stepN, step] at h

/-- The output of a machine run is unique. -/
theorem runsWithinBits_out_unique {prog : List Expr} {input : Val} {tape : List Bool} {out out' : Val}
    {S S' : ℝ} (h : RunsWithinBits prog input tape out S) (h' : RunsWithinBits prog input tape out' S') :
    out = out' := by
  obtain ⟨n, rest, hn, -⟩ := h
  obtain ⟨n', rest', hn', -⟩ := h'
  rcases le_total n n' with hle | hle
  · obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hle
    rw [Machine.stepN_add, hn, Option.bind_some] at hn'
    have h2 := (stepN_halted hn').2
    simp only [Conf.mk.injEq, Ctrl.ret.injEq] at h2
    exact h2.1.symm
  · obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hle
    rw [Machine.stepN_add, hn', Option.bind_some] at hn
    have h2 := (stepN_halted hn).2
    simp only [Conf.mk.injEq, Ctrl.ret.injEq] at h2
    exact h2.1

/-- **Determinism of executions** (any run predicate with unique outputs): the states and estimates of
`StreamExecW Runs` are unique up to the first violation of the box promise. -/
theorem streamExecW_unique {Runs : List Expr → Val → List Bool → Val → ℝ → Prop}
    (hU : ∀ {prog : List Expr} {input : Val} {tape : List Bool} {o₁ o₂ : Val} {S₁ S₂ : ℝ},
      Runs prog input tape o₁ S₁ → Runs prog input tape o₂ S₂ → o₁ = o₂)
    {alg : StreamAlgorithm} {P : StreamParams} {S S' : ℝ}
    {adv : StreamAdversary P.n} {tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool}
    {states states' : ℕ → Val} {outs outs' : ℕ → ℚ}
    (h : StreamExecW Runs alg P S adv tapes states outs)
    (h' : StreamExecW Runs alg P S' adv tapes states' outs') :
    ∀ t : ℕ, t ≤ P.m → (∀ r < t, BoxUpTo P.U adv outs r) →
      states t = states' t ∧ ∀ r < t, outs r = outs' r := by
  intro t
  induction t with
  | zero =>
    intro _ _
    exact ⟨hU h.1 h'.1, fun r hr => absurd hr (Nat.not_lt_zero r)⟩
  | succ t ih =>
    intro ht hbox
    have htm : t < P.m := ht
    obtain ⟨hst, hout⟩ := ih (Nat.le_of_succ_le ht) (fun r hr => hbox r (Nat.lt_succ_of_lt hr))
    have hb : BoxUpTo P.U adv outs t := hbox t (Nat.lt_succ_self t)
    -- the updates of the rounds `≤ t` agree, hence so does the box promise
    have hupd : ∀ s ≤ t, advUpdate adv outs' s = advUpdate adv outs s :=
      fun s hs => (advUpdate_congr adv (fun r hr => hout r (lt_of_lt_of_le hr hs))).symm
    have hb' : BoxUpTo P.U adv outs' t := (boxUpTo_congr hupd).mpr hb
    obtain ⟨outV, hrun, hparse⟩ := h.2 t htm hb
    obtain ⟨outV', hrun', hparse'⟩ := h'.2 t htm hb'
    rw [hst, ← hupd t le_rfl] at hrun
    have heq := hU hrun hrun'
    simp only [Val.list.injEq, List.cons.injEq, and_true] at heq
    obtain ⟨hs1, hv⟩ := heq
    refine ⟨hs1, fun r hr => ?_⟩
    rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hr | rfl
    · exact hout r hr
    · rw [hv] at hparse
      rw [hparse] at hparse'
      exact Option.some.inj hparse'

/-- **Determinism of executions** (the Spec's `StreamExec`): the states and estimates are unique up to the
first violation of the box promise. -/
theorem streamExec_unique {alg : StreamAlgorithm} {P : StreamParams} {S S' : ℝ}
    {adv : StreamAdversary P.n} {tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool}
    {states states' : ℕ → Val} {outs outs' : ℕ → ℚ}
    (h : StreamExec alg P S adv tapes states outs)
    (h' : StreamExec alg P S' adv tapes states' outs') :
    ∀ t : ℕ, t ≤ P.m → (∀ r < t, BoxUpTo P.U adv outs r) →
      states t = states' t ∧ ∀ r < t, outs r = outs' r :=
  streamExecW_unique (Runs := RunsWithinBits) runsWithinBits_out_unique h h'

/-- **Determinism of executions** (Spec v1 `StreamExecV1`). -/
theorem streamExecV1_unique {alg : StreamAlgorithm} {P : StreamParams} {S S' : ℝ}
    {adv : StreamAdversary P.n} {tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool}
    {states states' : ℕ → Val} {outs outs' : ℕ → ℚ}
    (h : StreamExecV1 alg P S adv tapes states outs)
    (h' : StreamExecV1 alg P S' adv tapes states' outs') :
    ∀ t : ℕ, t ≤ P.m → (∀ r < t, BoxUpTo P.U adv outs r) →
      states t = states' t ∧ ∀ r < t, outs r = outs' r :=
  streamExecW_unique (Runs := RunsOn) Cost.runsOn_out_unique h h'

end F2e2e.C.Top
