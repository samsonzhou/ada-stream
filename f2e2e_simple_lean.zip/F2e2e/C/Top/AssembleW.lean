import F2e2e.C.Top.Assemble

/-!
# Theorem (C), machine-generic form

The Spec's `StreamExec` and `Theorem_C` are stated here verbatim with the run predicate as a parameter `Runs`
(`StreamExecW Runs`, `Theorem_CW Runs`):
* `StreamExecW RunsWithinBits = StreamExec` and `Theorem_CW RunsWithinBits = Theorem_C` (by `rfl`,
  `streamExecW_runsWithinBits`, `theorem_CW_runsWithinBits`): the Spec's statements (small-step machine,
  footprint plus per-step workspace in bits);
* `StreamExecW RunsOn = StreamExecV1` and `Theorem_CW RunsOn = Theorem_C_v1` (by `rfl`, `streamExecW_runsOn`,
  `theorem_CW_runsOn`): the Spec v1 statements (`F2e2e/SpecV1Compat.lean`, big-step peak space).

`theorem_CW_of_impl`: from a mathematical algorithm (`A.Total`, `MathAlgGood A`) and a DSL implementation
`I : Impl A S`, `Theorem_CW Runs` holds as soon as every run of the two programs within the big-step bound
`S P` is a `Runs`-run within `spaceBoundC` (`RunsBound`); the v1 headline needed `S ≤ spaceBoundC`
(`SpaceOK S`). **`theorem_C_of_runsBound`**: the Spec's `Theorem_C` from `RunsBound RunsWithinBits I`.
`theorem_CW_mono`: `Theorem_CW` is monotone in the run predicate.
-/

namespace F2e2e.C.Top

open MeasureTheory

/-- The Spec's `StreamExec`, verbatim, with the run predicate `Runs` as a parameter. -/
def StreamExecW (Runs : List Expr → Val → List Bool → Val → ℝ → Prop) (alg : StreamAlgorithm)
    (P : StreamParams) (S : ℝ) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool) (states : ℕ → Val) (outs : ℕ → ℚ) :
    Prop :=
  Runs alg.initProg (encStreamParams P) (List.ofFn (tapes 0)) (states 0) S ∧
  ∀ (t : ℕ) (ht : t < P.m), BoxUpTo P.U adv outs t →
    ∃ outV : Val,
      Runs alg.updProg
        (Val.list [encStreamParams P, states t, Val.int ((advUpdate adv outs t).1 : ℤ),
          Val.int (advUpdate adv outs t).2])
        (List.ofFn (tapes (Fin.succ ⟨t, ht⟩))) (Val.list [states (t + 1), outV]) S ∧
      parseEstimate outV = some (outs t)

/-- The Spec's `Theorem_C`, verbatim, with the run predicate `Runs` as a parameter. -/
def Theorem_CW (Runs : List Expr → Val → List Bool → Val → ℝ → Prop) : Prop :=
  ∃ alg : StreamAlgorithm,
    ∀ (n m U : ℕ) (ε β : ℝ), 1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1 / 10 → 0 < β → β < 1 / 10 →
      (∀ (adv : StreamAdversary (mkStreamParams n m U ε β).n)
          (tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
            Fin (alg.tapeLen (mkStreamParams n m U ε β)) → Bool),
        ∃ (states : ℕ → Val) (outs : ℕ → ℚ),
          StreamExecW Runs alg (mkStreamParams n m U ε β) (spaceBoundC n m U ε β) adv tapes states
            outs) ∧
      (∀ (Ω : Type) [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
          (adv : Ω → StreamAdversary (mkStreamParams n m U ε β).n),
        (∀ h : List ℚ, Measurable (fun ω => adv ω h)) →
          ∑ tapes : Fin ((mkStreamParams n m U ε β).m + 1) →
              Fin (alg.tapeLen (mkStreamParams n m U ε β)) → Bool,
            P {ω | ¬ ∃ (states : ℕ → Val) (outs : ℕ → ℚ),
                StreamExecW Runs alg (mkStreamParams n m U ε β) (spaceBoundC n m U ε β) (adv ω)
                  tapes states outs ∧
                StreamAccurate m U ε (adv ω) outs} ≤
            ENNReal.ofReal β *
              2 ^ (((mkStreamParams n m U ε β).m + 1) * alg.tapeLen (mkStreamParams n m U ε β)))

/-- The Spec's `StreamExec` is the instance `Runs := RunsWithinBits`. -/
theorem streamExecW_runsWithinBits : StreamExecW RunsWithinBits = StreamExec := rfl

/-- The Spec's `Theorem_C` is the instance `Runs := RunsWithinBits`. -/
theorem theorem_CW_runsWithinBits : Theorem_CW RunsWithinBits = Theorem_C := rfl

theorem streamExecW_runsOn : StreamExecW RunsOn = StreamExecV1 := rfl

theorem theorem_CW_runsOn : Theorem_CW RunsOn = Theorem_C_v1 := rfl

/-- `StreamExecW` is monotone in the run predicate. -/
theorem streamExecW_mono {Runs Runs' : List Expr → Val → List Bool → Val → ℝ → Prop}
    (hR : ∀ prog input tape out S, Runs prog input tape out S → Runs' prog input tape out S)
    {alg : StreamAlgorithm} {P : StreamParams} {S : ℝ} {adv : StreamAdversary P.n}
    {tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool} {states : ℕ → Val} {outs : ℕ → ℚ}
    (h : StreamExecW Runs alg P S adv tapes states outs) :
    StreamExecW Runs' alg P S adv tapes states outs := by
  refine ⟨hR _ _ _ _ _ h.1, fun t ht hbox => ?_⟩
  obtain ⟨outV, hrun, hparse⟩ := h.2 t ht hbox
  exact ⟨outV, hR _ _ _ _ _ hrun, hparse⟩

/-- `Theorem_CW` is monotone in the run predicate. -/
theorem theorem_CW_mono {Runs Runs' : List Expr → Val → List Bool → Val → ℝ → Prop}
    (hR : ∀ prog input tape out S, Runs prog input tape out S → Runs' prog input tape out S)
    (h : Theorem_CW Runs) : Theorem_CW Runs' := by
  obtain ⟨alg, halg⟩ := h
  refine ⟨alg, fun n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 => ?_⟩
  obtain ⟨h1, h2⟩ := halg n m U ε β hn hm hU hε0 hε1 hβ0 hβ1
  refine ⟨fun adv tapes => ?_, fun Ω _ μ _ adv hadv => ?_⟩
  · obtain ⟨states, outs, hexec⟩ := h1 adv tapes
    exact ⟨states, outs, streamExecW_mono hR hexec⟩
  · refine le_trans (Finset.sum_le_sum fun tapes _ => measure_mono ?_) (h2 Ω μ adv hadv)
    intro ω hω hex
    obtain ⟨states, outs, hexec, hacc⟩ := hex
    exact hω ⟨states, outs, streamExecW_mono hR hexec, hacc⟩

/-- The obligation of the DSL side for a run predicate `Runs`: every run of the two programs within the
big-step bound `S P` is a `Runs`-run within the space bound of Theorem C. -/
def RunsBound (Runs : List Expr → Val → List Bool → Val → ℝ → Prop) {A : MathStreamAlg}
    {S : StreamParams → ℝ} (I : Impl A S) : Prop :=
  ∀ (n m U : ℕ) (ε β : ℝ), 1 ≤ n → 1 ≤ m → 1 ≤ U → 0 < ε → ε < 1 / 10 → 0 < β → β < 1 / 10 →
    ∀ (prog : List Expr), (prog = I.initProg ∨ prog = I.updProg) →
      ∀ (input : Val) (tape : List Bool) (out : Val),
        RunsOn prog input tape out (S (mkStreamParams n m U ε β)) →
          Runs prog input tape out (spaceBoundC n m U ε β)

/-- `SpaceOK` gives the obligation for `RunsOn` itself. -/
theorem runsBound_runsOn {A : MathStreamAlg} {S : StreamParams → ℝ} (I : Impl A S)
    (hS : SpaceOK S) : RunsBound RunsOn I := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 prog _ input tape out h
  obtain ⟨body, fuel, cost, peak, rest, hb, he, hp⟩ := h
  exact ⟨body, fuel, cost, peak, rest, hb, he, hp.trans (hS n m U ε β hn hm hU hε0 hε1 hβ0 hβ1)⟩

/-- Changing the run predicate of an execution, run by run. -/
theorem streamExecW_of_streamExec {Runs : List Expr → Val → List Bool → Val → ℝ → Prop}
    {alg : StreamAlgorithm} {P : StreamParams} {S S' : ℝ} {adv : StreamAdversary P.n}
    {tapes : Fin (P.m + 1) → Fin (alg.tapeLen P) → Bool} {states : ℕ → Val} {outs : ℕ → ℚ}
    (hR : ∀ prog, (prog = alg.initProg ∨ prog = alg.updProg) → ∀ input tape out,
      RunsOn prog input tape out S → Runs prog input tape out S')
    (h : StreamExecV1 alg P S adv tapes states outs) :
    StreamExecW Runs alg P S' adv tapes states outs := by
  refine ⟨hR _ (Or.inl rfl) _ _ _ h.1, fun t ht hbox => ?_⟩
  obtain ⟨outV, hrun, hparse⟩ := h.2 t ht hbox
  exact ⟨outV, hR _ (Or.inr rfl) _ _ _ hrun, hparse⟩

/-- **Theorem (C), machine-generic form.** -/
theorem theorem_CW_of_impl (Runs : List Expr → Val → List Bool → Val → ℝ → Prop)
    (A : MathStreamAlg) (hT : A.Total) (hG : MathAlgGood A) (S : StreamParams → ℝ) (I : Impl A S)
    (hB : RunsBound Runs I) : Theorem_CW Runs := by
  refine ⟨I.alg, fun n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 => ?_⟩
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hR := hB n m U ε β hn hm hU hε0 hε1 hβ0 hβ1
  refine ⟨fun adv tapes => ?_, fun Ω _ μ _ adv hadv => ?_⟩
  · obtain ⟨states, hex⟩ := exists_mathExec hT hP adv tapes
    exact ⟨_, _, streamExecW_of_streamExec hR
      (streamExec_of_mathExec I hP le_rfl adv tapes states _ hex)⟩
  · refine le_trans (Finset.sum_le_sum fun tapes _ => measure_mono ?_)
      (hG n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 Ω μ adv hadv)
    intro ω hω hex
    obtain ⟨states, outs, hexec, hacc⟩ := hex
    exact hω ⟨_, outs, streamExecW_of_streamExec hR
      (streamExec_of_mathExec I hP le_rfl (adv ω) tapes states outs hexec), hacc⟩

/-- **Theorem (C)** (the Spec's statement) from a mathematical algorithm and a DSL implementation whose
runs within the big-step bound are `RunsWithinBits`-runs within the space bound of Theorem C. -/
theorem theorem_C_of_runsBound (A : MathStreamAlg) (hT : A.Total) (hG : MathAlgGood A)
    (S : StreamParams → ℝ) (I : Impl A S) (hB : RunsBound RunsWithinBits I) : Theorem_C :=
  theorem_CW_of_impl RunsWithinBits A hT hG S I hB

/-- The v1 headline is the instance `Runs := RunsOn`. -/
theorem theorem_C_of_impl' (A : MathStreamAlg) (hT : A.Total) (hG : MathAlgGood A)
    (S : StreamParams → ℝ) (I : Impl A S) (hS : SpaceOK S) : Theorem_C_v1 :=
  theorem_CW_of_impl RunsOn A hT hG S I (runsBound_runsOn I hS)

end F2e2e.C.Top
