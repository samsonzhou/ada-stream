import F2e2e.C.Top.BitProg
import F2e2e.C.Top.Det

/-!
# Theorem (C), top level: the tape count of a `BitProg` algorithm as a law

For an algorithm whose initialization and rounds (for the parameters `P`) are `BitProg` programs
`initB`, `stepB` (e.g. `A = MathStreamAlg.ofBitProg State tapeLen init step` with C-ALG's
`algInit`/`algStep`) reading at most `tapeLen P` bits on every path (uniform depth bounds), the uniform
tapes of the Spec (`m + 1` blocks of `tapeLen P` bits, unread bits of a block wasted) can be replaced by
the law of the **sequential interaction** `interact initB stepB adv t : BitProg (Option (σ × List ℚ))`
(initialization, then the rounds `0, …, t-1`, the update of a round chosen by the deterministic adversary
from the estimates so far, bits read one after the other; `law_interact_zero`, `law_interact_succ`):

* `sum_tapes_run_eq`: `∑ tapes, g (A.run P adv tapes t) = 2^((m+1)·tapeLen P) · ∑' o, (interact … t).law o · g o`
  for every `g` and `t ≤ m`;
* `ncard_not_streamAccurate_eq`: the number of tape tuples on which the canonical run is not
  `ε`-accurate is `2^((m+1)·tapeLen P)` times the law of `BadOutcome P adv ε` under `interact … m`;
* `mathAlgGoodDyadic_of_law`: `MathAlgGoodDyadic A` from `law (BadOutcome P adv ε₀) ≤ β₀` for every `P`
  with `ParamsOK P` and every deterministic adversary;
* `total_and_mathAlgGood_ofBitProg`: for `ofBitProg`, `A.Total ∧ MathAlgGood A` from the uniform depth
  bounds and that law bound (both Part III obligations of `theorem_C_of_impl`).

The proof peels off one tape block at a time: the run up to round `t` does not depend on the block of
round `t + 1` (`run_congr_tapes`), averaging over one coordinate (`card_mul_sum_eq_sum_sum`), and
`BitProg.sum_tapes_eq` for that block (`sum_block_eq`); `BitProg.law_bind` assembles the law.
-/

namespace F2e2e.C.Top

open F2e2e.Discrete

/-! ## Generic facts -/

/-- Averaging over one coordinate: if `G τ x` does not depend on the coordinate `j` of `τ`, then summing
`G τ (τ j)` over all `τ` is the average over `x` of summing `G τ x`. -/
theorem card_mul_sum_eq_sum_sum {ι X : Type*} [Fintype ι] [DecidableEq ι] [Fintype X] (j : ι)
    (G : (ι → X) → X → ENNReal) (hG : ∀ τ x x', G (Function.update τ j x') x = G τ x) :
    (Fintype.card X : ENNReal) * ∑ τ : ι → X, G τ (τ j) = ∑ τ : ι → X, ∑ x, G τ x := by
  classical
  set S := (Equiv.funSplitAt j X).symm with hSdef
  have hSj : ∀ (y : X) (r : {k // k ≠ j} → X), S (y, r) j = y := by
    intro y r
    simp [hSdef, Equiv.funSplitAt_symm_apply]
  have hSupd : ∀ (y y' : X) (r : {k // k ≠ j} → X), S (y', r) = Function.update (S (y, r)) j y' := by
    intro y y' r
    funext k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, hSj]
    · rw [Function.update_of_ne hk]
      simp [hSdef, Equiv.funSplitAt_symm_apply, hk]
  have hGS : ∀ (y y' : X) (r : {k // k ≠ j} → X) (x : X), G (S (y', r)) x = G (S (y, r)) x := by
    intro y y' r x
    rw [hSupd y y' r, hG]
  rw [← Equiv.sum_comp S (fun τ => G τ (τ j)), ← Equiv.sum_comp S (fun τ => ∑ x, G τ x)]
  simp only [Fintype.sum_prod_type, hSj]
  have h1 : ∀ (y : X) (r : {k // k ≠ j} → X), ∑ x, G (S (y, r)) x = ∑ x, G (S (x, r)) x :=
    fun y r => Finset.sum_congr rfl (fun x _ => hGS x y r x)
  simp only [h1]
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  congr 1
  exact Finset.sum_comm

theorem tsum_bind_mul {α β : Type*} (p : PMF α) (f : α → PMF β) (g : β → ENNReal) :
    ∑' b, (p.bind f) b * g b = ∑' a, p a * ∑' b, f a b * g b := by
  simp only [PMF.bind_apply]
  simp_rw [← ENNReal.tsum_mul_right, ← ENNReal.tsum_mul_left]
  rw [ENNReal.tsum_comm]
  refine tsum_congr (fun a => tsum_congr (fun b => ?_))
  ring

theorem tsum_pure_mul {α : Type*} (a : α) (g : α → ENNReal) :
    ∑' b, PMF.pure a b * g b = g a := by
  classical
  rw [tsum_eq_single a (fun b hb => by simp [PMF.pure_apply, hb])]
  simp [PMF.pure_apply]

theorem tsum_map_mul {α β : Type*} (p : PMF α) (f : α → β) (g : β → ENNReal) :
    ∑' b, (p.map f) b * g b = ∑' a, p a * g (f a) := by
  rw [← PMF.bind_pure_comp, tsum_bind_mul]
  simp only [Function.comp_apply, tsum_pure_mul]

/-! ## The run depends only on the tape blocks used so far -/

theorem run_congr_tapes {A : MathStreamAlg} {P : StreamParams} {adv : StreamAdversary P.n}
    {tapes tapes' : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool} :
    ∀ t : ℕ, (∀ j ≤ t, tapeAt tapes j = tapeAt tapes' j) →
      A.run P adv tapes t = A.run P adv tapes' t := by
  intro t
  induction t with
  | zero =>
    intro h
    rw [run_zero_eq, run_zero_eq, h 0 le_rfl]
  | succ t ih =>
    intro h
    rw [run_succ_eq, run_succ_eq, ih (fun j hj => h j (Nat.le_succ_of_le hj)),
      h (t + 1) le_rfl]

theorem tapeAt_update_of_ne {P : StreamParams} {B : ℕ} (tapes : Fin (P.m + 1) → Fin B → Bool)
    (k : Fin (P.m + 1)) (x : Fin B → Bool) {j : ℕ} (hj : j ≠ k.val) :
    tapeAt (Function.update tapes k x) j = tapeAt tapes j := by
  unfold tapeAt
  split_ifs with h
  · rw [Function.update_of_ne]
    intro e
    exact hj (by rw [← e])
  · rfl

/-! ## The sequential interaction -/

section interact

variable {σ : Type} {n : ℕ}

/-- One round of the sequential interaction from the configuration `o` (state and estimates so far;
`none` = failed, absorbing): the adversary picks the update from the estimates so far. -/
def roundProg (stepB : σ → Fin n × ℤ → BitProg (σ × ℚ)) (adv : StreamAdversary n) :
    Option (σ × List ℚ) → BitProg (Option (σ × List ℚ))
  | none => BitProg.pure none
  | some c => (stepB c.1 (adv c.2)).map (fun r => some (r.1, c.2 ++ [r.2]))

/-- The sequential interaction up to round `t`: the initialization followed by the rounds `0, …, t-1`,
reading the bits one after the other. -/
def interact (initB : BitProg σ) (stepB : σ → Fin n × ℤ → BitProg (σ × ℚ))
    (adv : StreamAdversary n) : ℕ → BitProg (Option (σ × List ℚ))
  | 0 => initB.map (fun s => some (s, []))
  | t + 1 => (interact initB stepB adv t).bind (roundProg stepB adv)

theorem law_interact_zero (initB : BitProg σ) (stepB : σ → Fin n × ℤ → BitProg (σ × ℚ))
    (adv : StreamAdversary n) :
    (interact initB stepB adv 0).law = initB.law.map (fun s => some (s, [])) :=
  BitProg.law_map _ _

theorem law_interact_succ (initB : BitProg σ) (stepB : σ → Fin n × ℤ → BitProg (σ × ℚ))
    (adv : StreamAdversary n) (t : ℕ) :
    (interact initB stepB adv (t + 1)).law =
      (interact initB stepB adv t).law.bind (fun o => (roundProg stepB adv o).law) :=
  BitProg.law_bind _ _

/-- One block: summing over the bits of one round. -/
theorem sum_block_eq (stepB : σ → Fin n × ℤ → BitProg (σ × ℚ)) (adv : StreamAdversary n) {B : ℕ}
    (hstep : ∀ (s : σ) (u : Fin n × ℤ), (stepB s u).depth ≤ B)
    (g : Option (σ × List ℚ) → ENNReal) (o : Option (σ × List ℚ)) :
    ∑ x : Fin B → Bool,
        g (o.bind (fun c => ((stepB c.1 (adv c.2)).run (List.ofFn x)).map
          (fun r => (r.1.1, c.2 ++ [r.1.2])))) =
      2 ^ B * ∑' o', (roundProg stepB adv o).law o' * g o' := by
  cases o with
  | none =>
    simp only [Option.bind_none, roundProg, BitProg.law_pure, tsum_pure_mul, Finset.sum_const,
      Finset.card_univ, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin, nsmul_eq_mul]
    push_cast
    ring
  | some c =>
    simp only [Option.bind_some, roundProg, BitProg.law_map, tsum_map_mul]
    rw [← BitProg.sum_tapes_eq (stepB c.1 (adv c.2)) (hstep c.1 (adv c.2))
      (fun r => g (some (r.1, c.2 ++ [r.2])))]
    refine Finset.sum_congr rfl (fun x _ => ?_)
    have h := BitProg.run_isSome (stepB c.1 (adv c.2)) (List.ofFn x)
      (by rw [List.length_ofFn]; exact hstep c.1 (adv c.2))
    obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp h
    rw [hr]
    rfl

end interact

/-! ## The tape count of the canonical run -/

/-- **The tape count of the canonical run is the law of the sequential interaction**: for an algorithm
whose initialization and rounds (for the parameters `P`) are the `BitProg` programs `initB`, `stepB`,
reading at most `tapeLen P` bits on every path. -/
theorem sum_tapes_run_eq {A : MathStreamAlg} {P : StreamParams} (adv : StreamAdversary P.n)
    (initB : BitProg A.State) (stepB : A.State → Fin P.n × ℤ → BitProg (A.State × ℚ))
    (hi : ∀ tape, A.init P tape = initB.run tape)
    (hs : ∀ s u tape, A.step P s u tape = (stepB s u).run tape)
    (hinit : initB.depth ≤ A.tapeLen P) (hstep : ∀ s u, (stepB s u).depth ≤ A.tapeLen P) :
    ∀ t : ℕ, t ≤ P.m → ∀ g : Option (A.State × List ℚ) → ENNReal,
      ∑ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool, g (A.run P adv tapes t) =
        2 ^ ((P.m + 1) * A.tapeLen P) * ∑' o, (interact initB stepB adv t).law o * g o := by
  classical
  have hcardX : (Fintype.card (Fin (A.tapeLen P) → Bool) : ENNReal) = 2 ^ A.tapeLen P := by
    simp [Fintype.card_bool, Fintype.card_fin]
  have hX0 : (2 : ENNReal) ^ A.tapeLen P ≠ 0 := by positivity
  have hXt : (2 : ENNReal) ^ A.tapeLen P ≠ ⊤ := ENNReal.pow_ne_top ENNReal.ofNat_ne_top
  have hcardT : (Fintype.card (Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) : ENNReal) =
      2 ^ ((P.m + 1) * A.tapeLen P) := by
    rw [card_tapes]
    norm_num
  intro t
  induction t with
  | zero =>
    intro _ g
    -- the run before round `0` reads only block `0`
    have hrun : ∀ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool,
        A.run P adv tapes 0 = (initB.run (List.ofFn (tapes 0))).map (fun r => (r.1, [])) := by
      intro tapes
      rw [run_zero_eq, tapeAt_zero, hi]
    have hblock : ∑ x : Fin (A.tapeLen P) → Bool,
        g ((initB.run (List.ofFn x)).map (fun r => (r.1, []))) =
          2 ^ A.tapeLen P * ∑' s, initB.law s * g (some (s, [])) := by
      rw [← BitProg.sum_tapes_eq initB hinit (fun s => g (some (s, [])))]
      refine Finset.sum_congr rfl (fun x _ => ?_)
      have h := BitProg.run_isSome initB (List.ofFn x) (by rw [List.length_ofFn]; exact hinit)
      obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp h
      rw [hr]
      rfl
    have havg := card_mul_sum_eq_sum_sum (0 : Fin (P.m + 1))
      (fun (_ : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (x : Fin (A.tapeLen P) → Bool) =>
        g ((initB.run (List.ofFn x)).map (fun r => (r.1, [])))) (fun _ _ _ => rfl)
    simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, hblock] at havg
    rw [hcardX, hcardT] at havg
    simp only [hrun]
    rw [law_interact_zero, tsum_map_mul]
    apply (ENNReal.mul_right_inj hX0 hXt).mp
    rw [havg]
    ring
  | succ t ih =>
    intro ht g
    have htm : t + 1 < P.m + 1 := Nat.succ_lt_succ ht
    set k : Fin (P.m + 1) := ⟨t + 1, htm⟩ with hk
    set H : Option (A.State × List ℚ) → ENNReal :=
      fun o => ∑' o', (roundProg stepB adv o).law o' * g o' with hH
    -- the run before round `t + 1` = one more block applied to the run before round `t`
    have hrun : ∀ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool,
        A.run P adv tapes (t + 1) =
          (A.run P adv tapes t).bind (fun c => ((stepB c.1 (adv c.2)).run (List.ofFn (tapes k))).map
            (fun r => (r.1.1, c.2 ++ [r.1.2]))) := by
      intro tapes
      rw [run_succ_eq, tapeAt_of_lt tapes htm]
      simp only [hs]
      rfl
    -- the run before round `t` does not read block `t + 1`
    have hindep : ∀ (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (x : Fin (A.tapeLen P) → Bool),
        A.run P adv (Function.update tapes k x) t = A.run P adv tapes t :=
      fun tapes x => run_congr_tapes t (fun j hj => tapeAt_update_of_ne tapes k x (by
        show j ≠ t + 1
        omega))
    have havg := card_mul_sum_eq_sum_sum k
      (fun (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) (x : Fin (A.tapeLen P) → Bool) =>
        g ((A.run P adv tapes t).bind
        (fun c => ((stepB c.1 (adv c.2)).run (List.ofFn x)).map
          (fun r => (r.1.1, c.2 ++ [r.1.2])))))
      (fun tapes x x' => by simp only [hindep])
    simp only [sum_block_eq stepB adv hstep g] at havg
    rw [hcardX, ← Finset.mul_sum] at havg
    have hsum : ∑ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool, g (A.run P adv tapes (t + 1)) =
        ∑ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool, H (A.run P adv tapes t) := by
      apply (ENNReal.mul_right_inj hX0 hXt).mp
      simp only [hrun]
      exact havg
    rw [hsum, ih (Nat.le_of_succ_le ht) H, law_interact_succ, tsum_bind_mul]

/-! ## Consequences: the accuracy statement as a bound on the law -/

/-- With uniform depth bounds the canonical run never fails up to round `m`. -/
theorem run_isSome_of_depth {A : MathStreamAlg} {P : StreamParams} (adv : StreamAdversary P.n)
    (initB : BitProg A.State) (stepB : A.State → Fin P.n × ℤ → BitProg (A.State × ℚ))
    (hi : ∀ tape, A.init P tape = initB.run tape)
    (hs : ∀ s u tape, A.step P s u tape = (stepB s u).run tape)
    (hinit : initB.depth ≤ A.tapeLen P) (hstep : ∀ s u, (stepB s u).depth ≤ A.tapeLen P)
    (tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool) :
    ∀ t : ℕ, t ≤ P.m → ∃ c, A.run P adv tapes t = some c := by
  intro t
  induction t with
  | zero =>
    intro _
    have h := BitProg.run_isSome initB (tapeAt tapes 0)
      (by rw [length_tapeAt tapes (Nat.succ_pos P.m)]; exact hinit)
    obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp h
    exact ⟨(r.1, []), by rw [run_zero_eq, hi, hr]; rfl⟩
  | succ t ih =>
    intro ht
    obtain ⟨c, hc⟩ := ih (Nat.le_of_succ_le ht)
    have h := BitProg.run_isSome (stepB c.1 (adv c.2)) (tapeAt tapes (t + 1))
      (by rw [length_tapeAt tapes (Nat.succ_lt_succ ht)]; exact hstep c.1 (adv c.2))
    obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp h
    exact ⟨_, run_succ_of_some hc (by rw [hs]; exact hr)⟩

/-- The failure event of an estimate list: not accurate (with accuracy `ε`) up to the first violation of
the box promise. -/
def BadOutcome {σ : Type} (P : StreamParams) (adv : StreamAdversary P.n) (ε : ℝ) :
    Set (Option (σ × List ℚ)) :=
  {o | ∃ c, o = some c ∧ ¬ StreamAccurate P.m P.U ε adv (fun r => c.2.getD r 0)}

/-- **Tape count = law of the failure event** (ENNReal form). -/
theorem ncard_not_streamAccurate_eq {A : MathStreamAlg} {P : StreamParams}
    (adv : StreamAdversary P.n)
    (initB : BitProg A.State) (stepB : A.State → Fin P.n × ℤ → BitProg (A.State × ℚ))
    (hi : ∀ tape, A.init P tape = initB.run tape)
    (hs : ∀ s u tape, A.step P s u tape = (stepB s u).run tape)
    (hinit : initB.depth ≤ A.tapeLen P) (hstep : ∀ s u, (stepB s u).depth ≤ A.tapeLen P)
    (ε : ℝ) :
    ((({tapes | ¬ StreamAccurate P.m P.U ε adv (A.outs P adv tapes)} :
        Set (Fin (P.m + 1) → Fin (A.tapeLen P) → Bool)).ncard : ENNReal)) =
      2 ^ ((P.m + 1) * A.tapeLen P) *
        (interact initB stepB adv P.m).law.toOuterMeasure (BadOutcome P adv ε) := by
  classical
  -- the failure of the canonical outputs is the failure event of the run before round `m`
  have hiff : ∀ tapes : Fin (P.m + 1) → Fin (A.tapeLen P) → Bool,
      ¬ StreamAccurate P.m P.U ε adv (A.outs P adv tapes) ↔
        A.run P adv tapes P.m ∈ BadOutcome P adv ε := by
    intro tapes
    obtain ⟨c, hc⟩ := run_isSome_of_depth adv initB stepB hi hs hinit hstep tapes P.m le_rfl
    have ho : ∀ r < P.m, A.outs P adv tapes r = c.2.getD r 0 := outs_eq_of_run hc
    have hu : ∀ s < P.m, advUpdate adv (A.outs P adv tapes) s =
        advUpdate adv (fun r => c.2.getD r 0) s := by
      intro s hs'
      unfold advUpdate
      congr 1
      exact List.ofFn_inj.mpr (funext fun r => ho r.val (lt_trans r.isLt hs'))
    rw [hc, streamAccurate_congr hu ho]
    constructor
    · intro h
      exact ⟨c, rfl, h⟩
    · rintro ⟨c', hc', h⟩
      cases hc'
      exact h
  have hset : ({tapes | ¬ StreamAccurate P.m P.U ε adv (A.outs P adv tapes)} :
      Set (Fin (P.m + 1) → Fin (A.tapeLen P) → Bool)) =
      ↑(Finset.univ.filter (fun tapes => A.run P adv tapes P.m ∈ BadOutcome P adv ε)) := by
    ext tapes
    simp [hiff]
  rw [hset, Set.ncard_coe_finset]
  have hsum := sum_tapes_run_eq adv initB stepB hi hs hinit hstep P.m le_rfl
    (fun o => (BadOutcome P adv ε).indicator 1 o)
  simp only [Set.indicator_apply, Pi.one_apply, Finset.sum_boole] at hsum
  rw [hsum, PMF.toOuterMeasure_apply]
  congr 1
  refine tsum_congr (fun o => ?_)
  simp only [Set.indicator_apply]
  split_ifs <;> simp

/-- **`MathAlgGoodDyadic` from a bound on the law of the sequential interaction.** -/
theorem mathAlgGoodDyadic_of_law {A : MathStreamAlg}
    (initB : (P : StreamParams) → BitProg A.State)
    (stepB : (P : StreamParams) → A.State → Fin P.n × ℤ → BitProg (A.State × ℚ))
    (hi : ∀ P tape, A.init P tape = (initB P).run tape)
    (hs : ∀ P s u tape, A.step P s u tape = (stepB P s u).run tape)
    (hinit : ∀ P : StreamParams, ParamsOK P → (initB P).depth ≤ A.tapeLen P)
    (hstep : ∀ P : StreamParams, ParamsOK P → ∀ s u, (stepB P s u).depth ≤ A.tapeLen P)
    (h : ∀ P : StreamParams, ParamsOK P → ∀ adv : StreamAdversary P.n,
      (interact (initB P) (stepB P) adv P.m).law.toOuterMeasure
          (BadOutcome P adv ((1 / 2 : ℝ) ^ P.epsExp)) ≤
        ENNReal.ofReal ((1 / 2 : ℝ) ^ P.betaExp)) :
    MathAlgGoodDyadic A := by
  intro P hP adv
  have heq := ncard_not_streamAccurate_eq adv (initB P) (stepB P) (hi P) (hs P) (hinit P hP)
    (hstep P hP) ((1 / 2 : ℝ) ^ P.epsExp)
  have hle := h P hP adv
  have hβ : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ P.betaExp * 2 ^ ((P.m + 1) * A.tapeLen P) := by positivity
  rw [← ENNReal.ofReal_le_ofReal_iff hβ, ENNReal.ofReal_natCast, heq,
    ENNReal.ofReal_mul (by positivity),
    ENNReal.ofReal_pow (show (0 : ℝ) ≤ 2 by norm_num) ((P.m + 1) * A.tapeLen P),
    ENNReal.ofReal_ofNat, mul_comm (ENNReal.ofReal _)]
  exact mul_le_mul_of_nonneg_left hle zero_le

/-- **Both Part III obligations for a `BitProg` algorithm**: totality and accuracy follow from uniform
depth bounds and the bound on the law of the sequential interaction. -/
theorem total_and_mathAlgGood_ofBitProg {State : Type} {tapeLen : StreamParams → ℕ}
    {init : StreamParams → BitProg State}
    {step : (P : StreamParams) → State → Fin P.n × ℤ → BitProg (State × ℚ)}
    (hinit : ∀ P : StreamParams, ParamsOK P → (init P).depth ≤ tapeLen P)
    (hstep : ∀ P : StreamParams, ParamsOK P → ∀ s u, (step P s u).depth ≤ tapeLen P)
    (h : ∀ P : StreamParams, ParamsOK P → ∀ adv : StreamAdversary P.n,
      (interact (init P) (step P) adv P.m).law.toOuterMeasure
          (BadOutcome P adv ((1 / 2 : ℝ) ^ P.epsExp)) ≤
        ENNReal.ofReal ((1 / 2 : ℝ) ^ P.betaExp)) :
    (MathStreamAlg.ofBitProg State tapeLen init step).Total ∧
      MathAlgGood (MathStreamAlg.ofBitProg State tapeLen init step) := by
  have hT := total_ofBitProg_of_uniform hinit hstep
  exact ⟨hT, mathAlgGood_of_dyadic hT
    (mathAlgGoodDyadic_of_law init step (fun _ _ => rfl) (fun _ _ _ _ => rfl) hinit hstep h)⟩

end F2e2e.C.Top
