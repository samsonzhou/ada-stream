import Mathlib
import F2e2e.C.Alg.AlgMCode
import F2e2e.C.ClosureStreams
import F2e2e.C.Top.AlgInstance
import F2e2e.B.ArchOnline

/-!
# The instrumented, tagged interpreter of the Theorem C algorithm (Part III §6.4)

The chronological closure (Theorem `R:thm:chronological-closure-and-main-proof`, partIII.tex L1266–1318) and
its information-flow argument (L1271–1285) look at the algorithm through C-ALG's controller/oracle presentation
(`F2e2e/C/Alg/AlgM.lean`, `AlgMCode.lean`): controller code `AlgM` over primitive oracle calls, interpreted by
`runO` with the real Norm Bank / fingerprint procedures. This file adds the analysis interpreter `runL`:

* every fresh bit is **tagged** with the component it belongs to (`Tag`: the fingerprint seed, the ADA sample
  seeds of a bank, one coarse group of a bank, the ADA coins of a bank), so that `TBitProg.sum_streams_eq`
  (`F2e2e/C/ClosureStreams.lean`) can view the bits of one component as an independent block;
* it keeps **ghost data** (`Ghost`): the label `(tr, d)` and the row-operation history of every live bank (the
  bank's "public history": partIII.tex L1273 "fixing that history defines the rounded, saturated recurrence on
  every possible row seed"), a record of every bank call (`CallRec`: the bank before the call, the request, the
  ADA output), the analysis events (`TreeEvent` notes), and the fingerprint tests.

`merge_runL`: forgetting tags and ghosts gives back `runO`. The instrumented algorithm `theAlgL` (state
`State × Ghost`) therefore has the same canonical runs and estimates as C-TOP's `theAlg` (`run_theAlgL`,
`outs_theAlgL`), on every tape.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg

/-! ## Labels, tags, ghost data -/

/-- Bank labels: `(0, 0)` is the root bank `𝓑_{-1}` (`bankNew 0 0` at initialization), `(tr, d)` with
`tr ≥ 1` the outgoing bank `𝓑_d` of the depth-`d` learner born at the start of round `tr`
(Definition `R:def:binary-tree-architecture` (2), partIII.tex L432). -/
abbrev BankLabel := ℕ × ℕ

/-- The component a fresh bit belongs to. -/
inductive Tag where
  /-- the fingerprint seed (Algorithm `R:alg:zero-fingerprint`, partII.tex L219) -/
  | fp : Tag
  /-- the seeds of the ADA sample rows `S_0, …, S_p` of a bank (partIII.tex L205–207) -/
  | seeds (lab : BankLabel) : Tag
  /-- the seeds of the reserved coarse group `k` of a bank (partIII.tex L206) -/
  | coarse (lab : BankLabel) (k : ℕ) : Tag
  /-- the noise bits of a bank's ADA module (initial thresholds and all calls) -/
  | coins (lab : BankLabel) : Tag
  deriving DecidableEq

/-- The kind of a bank call. -/
inductive CallKind where
  /-- `ValidateInterval(S, θ)` -/
  | validate (S θ : ℚ) : CallKind
  /-- `ReleaseNumerical(mode)` -/
  | release (mode : Mode) : CallKind

/-- The record of one bank call. -/
structure CallRec where
  /-- the label of the bank -/
  lab : BankLabel
  /-- its index in the bank list -/
  idx : ℕ
  /-- its row-operation history since its birth (before the call) -/
  hist : List RowOp
  /-- the bank before the call -/
  bank : Bank
  /-- the request -/
  kind : CallKind
  /-- the scale `c` of the query `f̂ = round_{h_A} min{Ẑ²/(Lc), 1}` (`S + ω`, resp. `max(c_raw, ω/2)`;
  `0` if a release found no coarse group left) -/
  scale : ℚ
  /-- the output of the bank's ADA module (`none` if the ADA was not called: no coarse group left) -/
  out : Option CoreOut

/-- Ghost data of the instrumented interpreter. -/
structure Ghost where
  /-- the labels of the live banks (parallel to `OState.banks`) -/
  labels : List BankLabel
  /-- the row-operation histories of the live banks since their births (parallel to `OState.banks`) -/
  hists : List (List RowOp)
  /-- every bank call, oldest first -/
  calls : List CallRec
  /-- every analysis event (`note`), oldest first -/
  events : List TreeEvent
  /-- every fingerprint test `(i, Δ, F_zero = 0?)`, oldest first -/
  fps : List (ℕ × ℤ × Bool)

/-- The initial ghost data. -/
def Ghost.init : Ghost := ⟨[], [], [], [], []⟩

/-! ## Tagged primitive implementations -/

/-- The reserved coarse groups `j, j+1, …, j+k−1` of the bank `lab`, group `i` tagged `coarse lab i`. -/
def coarseT (P : StreamParams) (lab : BankLabel) : ℕ → ℕ → TBitProg Tag (List (List (List Row)))
  | _, 0 => TBitProg.pure []
  | j, k + 1 =>
    (tag (Tag.coarse lab j) (sampleList (sampleList (newRow P) 32) P.gCoarse)).bind fun a =>
      (coarseT P lab (j + 1) k).bind fun l => TBitProg.pure (a :: l)

/-- A fresh bank with tagged bits: ADA sample seeds (`seeds lab`), coarse groups (`coarse lab k`), the ADA
initialization (`coins lab`); untagged, this is C-ALG's `newBank` (`merge_newBankT`). -/
def newBankT (P : StreamParams) (lab : BankLabel) : TBitProg Tag Bank :=
  (tag (Tag.seeds lab) (sampleBlocks P (bankAda P).blockSizes)).bind fun ada =>
    (coarseT P lab 0 P.Rmax).bind fun coarse =>
      (tag (Tag.coins lab) (adaInit (bankAda P))).bind fun st => TBitProg.pure ⟨ada, coarse, st⟩

/-- `ReleaseNumerical`, additionally returning the scale `c` and the ADA output (`Bank.release` is its first
component, `releaseLog_fst`). -/
def releaseLog (P : StreamParams) (B : Bank) (mode : Mode) :
    BitProg ((Option ℚ × Bank) × Option (ℚ × AdaNum)) :=
  match B.coarse with
  | [] => BitProg.pure ((none, B), none)
  | grp :: rest =>
    (adaNumerical (bankAda P) B.adaSt
        (adaVals P mode (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) B)).bind
      fun res =>
        match res.1 with
        | AdaNum.val μ =>
          BitProg.pure ((some (max 0 ((P.L : ℚ) *
              (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)) * μ - P.omega)),
              { B with coarse := rest, adaSt := res.2 }),
            some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1))
        | AdaNum.abort =>
          BitProg.pure ((none, { B with coarse := rest, adaSt := res.2 }),
            some (max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2), res.1))

/-! ## The instrumented interpreter -/

/-- The label of the bank at index `idx` (`(0, 0)` if out of range). -/
def Ghost.labelAt (g : Ghost) (idx : ℕ) : BankLabel := g.labels.getD idx (0, 0)

/-- The history of the bank at index `idx` (`[]` if out of range). -/
def Ghost.histAt (g : Ghost) (idx : ℕ) : List RowOp := g.hists.getD idx []

/-- The instrumented, tagged interpreter: as `runO`, with every fresh bit tagged by its component and with
the ghost data updated (see the module docstring). -/
def runL (P : StreamParams) {α : Type} : AlgM α → OState → Ghost → TBitProg Tag (α × OState × Ghost)
  | AlgM.pure a, o, g => TBitProg.pure (a, o, g)
  | AlgM.fpInit k, o, g =>
    (tag Tag.fp (fpSeedProg P)).bind fun r => runL P k { o with fpSeed := r, fpVal := 0 } g
  | AlgM.fpStep i Δ k, o, g =>
    runL P (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0)) { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }
  | AlgM.bankNew tr d k, o, g =>
    (newBankT P (tr, d)).bind fun B =>
      runL P k { o with banks := o.banks ++ [B] }
        { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }
  | AlgM.bankRetain n k, o, g =>
    runL P k { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }
  | AlgM.bankOp idx op k, o, g =>
    runL P k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists }
  | AlgM.bankOpFrom idx op k, o, g =>
    runL P k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists }
  | AlgM.bankValidate idx S θ k, o, g =>
    match o.banks[idx]? with
    | none => runL P (k AdaCert.abort) o g
    | some B =>
      (tag (Tag.coins (g.labelAt idx)) (B.validate P S θ)).bind fun r =>
        runL P (k r.1) { o with banks := setAt r.2 idx o.banks }
          { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl r.1)⟩] }
  | AlgM.bankRelease idx mode k, o, g =>
    match o.banks[idx]? with
    | none => runL P (k none) o g
    | some B =>
      (tag (Tag.coins (g.labelAt idx)) (releaseLog P B mode)).bind fun r =>
        runL P (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
          { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
            (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] }
  | AlgM.note ev k, o, g => runL P k o { g with events := g.events ++ [ev] }

/-! ## Forgetting tags and ghosts gives the real interpreter -/

theorem bp_map_eq_bind {α β : Type} (f : α → β) (p : BitProg α) :
    p.map f = p.bind fun a => BitProg.pure (f a) := rfl

theorem bp_map_bind {α β γ : Type} (p : BitProg α) (f : α → BitProg β) (h : β → γ) :
    (p.bind f).map h = p.bind fun a => (f a).map h :=
  bp_bind_assoc f (fun b => BitProg.pure (h b)) p

theorem bp_bind_map {α β γ : Type} (p : BitProg α) (f : α → β) (g : β → BitProg γ) :
    (p.map f).bind g = p.bind fun a => g (f a) :=
  bp_bind_assoc (fun a => BitProg.pure (f a)) g p

theorem bp_map_map {α β γ : Type} (p : BitProg α) (f : α → β) (g : β → γ) :
    (p.map f).map g = p.map (g ∘ f) :=
  bp_bind_map p f (fun b => BitProg.pure (g b))

@[simp] theorem bp_map_pure {α β : Type} (a : α) (f : α → β) :
    (BitProg.pure a).map f = BitProg.pure (f a) := rfl

theorem sampleList_succ {α : Type} (p : BitProg α) (k : ℕ) :
    sampleList p (k + 1) = p.bind fun a => (sampleList p k).bind fun l => BitProg.pure (a :: l) := rfl

theorem merge_coarseT (P : StreamParams) (lab : BankLabel) :
    ∀ (j k : ℕ), (coarseT P lab j k).merge =
      sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) k
  | _, 0 => rfl
  | j, k + 1 => by
    rw [coarseT, merge_bind, merge_tag,
      sampleList_succ (sampleList (sampleList (newRow P) 32) P.gCoarse) k]
    congr 1
    funext a
    rw [merge_bind, merge_coarseT P lab (j + 1) k]
    rfl

theorem merge_newBankT (P : StreamParams) (lab : BankLabel) : (newBankT P lab).merge = newBank P := by
  simp only [newBankT, newBank, merge_bind, merge_tag, merge_pure, merge_coarseT, bp_bind_eq,
    bp_pure_eq]

theorem releaseLog_fst (P : StreamParams) (B : Bank) (mode : Mode) :
    (releaseLog P B mode).map Prod.fst = B.release P mode := by
  unfold releaseLog Bank.release
  cases h : B.coarse with
  | nil => rfl
  | cons grp rest =>
    simp only [bp_bind_eq, bp_pure_eq, bp_map_bind]
    congr 1
    funext res
    cases res.1 <;> rfl

/-- **Forgetting tags and ghost data gives C-ALG's real interpreter.** -/
theorem merge_runL (P : StreamParams) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost),
      (runL P p o g).merge.map (fun r => (r.1, r.2.1)) = runO P p o
  | AlgM.pure a, o, g => rfl
  | AlgM.fpInit k, o, g => by
    simp only [runL, merge_bind, merge_tag, runO_fpInit, bp_map_bind]
    congr 1
    funext r
    exact merge_runL P k _ _
  | AlgM.fpStep i Δ k, o, g => by
    simp only [runL, runO_fpStep]
    exact merge_runL P _ _ _
  | AlgM.bankNew tr d k, o, g => by
    simp only [runL, merge_bind, merge_newBankT, runO_bankNew, bp_map_bind, bankNewImpl]
    congr 1
    funext B
    exact merge_runL P k _ _
  | AlgM.bankRetain n k, o, g => by
    simp only [runL, runO_bankRetain]
    exact merge_runL P k _ _
  | AlgM.bankOp idx op k, o, g => by
    simp only [runL, runO_bankOp]
    exact merge_runL P k _ _
  | AlgM.bankOpFrom idx op k, o, g => by
    simp only [runL, runO_bankOpFrom]
    exact merge_runL P k _ _
  | AlgM.bankValidate idx S θ k, o, g => by
    simp only [runL, runO_bankValidate]
    cases h : o.banks[idx]? with
    | none => exact merge_runL P _ _ _
    | some B =>
      simp only [merge_bind, merge_tag, bp_map_bind]
      congr 1
      funext r
      exact merge_runL P _ _ _
  | AlgM.bankRelease idx mode k, o, g => by
    simp only [runL, runO_bankRelease]
    cases h : o.banks[idx]? with
    | none => exact merge_runL P _ _ _
    | some B =>
      simp only [merge_bind, merge_tag, bp_map_bind]
      rw [← releaseLog_fst, bp_bind_map]
      congr 1
      funext r
      exact merge_runL P _ _ _
  | AlgM.note ev k, o, g => by
    simp only [runL, runO_note]
    exact merge_runL P k _ _

/-! ## The instrumented algorithm -/

/-- The instrumented initialization. -/
def algInitL (P : StreamParams) : TBitProg Tag (State × Ghost) :=
  (runL P initCode initO Ghost.init).map fun r => (State.mk' r.1 r.2.1, r.2.2)

/-- The instrumented round for the update `u`. -/
def algStepL (P : StreamParams) (sg : State × Ghost) (u : Fin P.n × ℤ) :
    TBitProg Tag ((State × Ghost) × ℚ) :=
  (runL P (roundCode P sg.1.ctrl u.1.val u.2) sg.1.orc sg.2).map fun r =>
    ((State.mk' r.1.1 r.2.1, r.2.2), r.1.2)

theorem merge_algInitL (P : StreamParams) : (algInitL P).merge.map Prod.fst = algInit P := by
  rw [algInit_eq_interp, algInitL, merge_map, bp_map_map]
  have h := merge_runL P initCode initO Ghost.init
  rw [algInitM, ← h, bp_bind_map]
  rfl

theorem merge_algStepL (P : StreamParams) (sg : State × Ghost) (u : Fin P.n × ℤ) :
    (algStepL P sg u).merge.map (fun r => (r.1.1, r.2)) = theStep P sg.1 u := by
  rw [theStep, algStep_eq_interp, algStepL, merge_map, bp_map_map]
  have h := merge_runL P (roundCode P sg.1.ctrl u.1.val u.2) sg.1.orc sg.2
  rw [algStepM, ← h, bp_bind_map]
  rfl

/-- The instrumented algorithm: C-TOP's `theAlg` with ghost data in the state. -/
def theAlgL : MathStreamAlg :=
  MathStreamAlg.ofBitProg (State × Ghost) tapeBits (fun P => (algInitL P).merge)
    (fun P sg u => (algStepL P sg u).merge)

theorem theAlgL_init_depth (P : StreamParams) : (algInitL P).merge.depth ≤ tapeBits P := by
  have h := congrArg BitProg.depth (merge_algInitL P)
  rw [BitProg.depth_map] at h
  rw [h]
  exact theAlg_init_depth P

theorem theAlgL_step_depth (P : StreamParams) (sg : State × Ghost) (u : Fin P.n × ℤ) :
    (algStepL P sg u).merge.depth ≤ tapeBits P := by
  have h := congrArg BitProg.depth (merge_algStepL P sg u)
  rw [BitProg.depth_map] at h
  rw [h]
  exact theAlg_step_depth P sg.1 u

/-- The canonical runs of `theAlgL` and `theAlg` agree (on every tape), after forgetting the ghosts. -/
theorem run_theAlgL (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) :
    ∀ t, (theAlgL.run P adv tapes t).map (fun c => (c.1.1, c.2)) = theAlg.run P adv tapes t
  | 0 => by
    show (((algInitL P).merge.run (tapeAt tapes 0)).map fun r => (r.1, ([] : List ℚ))).map
        (fun c : (State × Ghost) × List ℚ => (c.1.1, c.2)) =
      ((algInit P).run (tapeAt tapes 0)).map fun r => (r.1, ([] : List ℚ))
    rw [← merge_algInitL P, BitProg.run_map]
    cases (algInitL P).merge.run (tapeAt tapes 0) <;> rfl
  | t + 1 => by
    show ((theAlgL.run P adv tapes t).bind fun c =>
        ((algStepL P c.1 (adv c.2)).merge.run (tapeAt tapes (t + 1))).map
          fun r => (r.1.1, c.2 ++ [r.1.2])).map
        (fun c : (State × Ghost) × List ℚ => (c.1.1, c.2)) =
      (theAlg.run P adv tapes t).bind fun c =>
        ((theStep P c.1 (adv c.2)).run (tapeAt tapes (t + 1))).map fun r => (r.1.1, c.2 ++ [r.1.2])
    rw [← run_theAlgL P adv tapes t]
    cases theAlgL.run P adv tapes t with
    | none => rfl
    | some c =>
      obtain ⟨sg, l⟩ := c
      show Option.map (fun c : (State × Ghost) × List ℚ => (c.1.1, c.2))
          (Option.map (fun r : ((State × Ghost) × ℚ) × List Bool => (r.1.1, l ++ [r.1.2]))
            ((algStepL P sg (adv l)).merge.run (tapeAt tapes (t + 1)))) =
        Option.map (fun r : (State × ℚ) × List Bool => (r.1.1, l ++ [r.1.2]))
          ((theStep P sg.1 (adv l)).run (tapeAt tapes (t + 1)))
      rw [← merge_algStepL P sg (adv l), BitProg.run_map]
      cases (algStepL P sg (adv l)).merge.run (tapeAt tapes (t + 1)) <;> rfl

theorem outs_theAlgL (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (t : ℕ) :
    theAlgL.outs P adv tapes t = theAlg.outs P adv tapes t := by
  unfold MathStreamAlg.outs
  rw [← run_theAlgL P adv tapes (t + 1)]
  cases theAlgL.run P adv tapes (t + 1) <;> rfl

end F2e2e.C.Closure
