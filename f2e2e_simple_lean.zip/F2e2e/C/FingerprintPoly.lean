import Mathlib

/-!
# Algebra of the homomorphic zero fingerprint (Lemma `R:lem:zero-fingerprint`)

Paper: `parts/partII.tex` Lemma `R:lem:zero-fingerprint` (L233–286), parts (1)–(3); external inputs
E1–E3 of `notes/PAPER_MAP_II_a.md` (§II.1.9).

The fingerprint of an integer vector `x : Fin n → ℤ` at the seed `r ∈ 𝔽_q` is
`F_zero(x) = ∑_{i=1}^n x_i r^i` (eq. `R:eq:fingerprint-recurrence`; coordinates are 1-based in the
paper, so the 0-based coordinate `j` carries `r^{j+1}`): `fpEval q x r`.

* `fpEval_zero`: `F_zero(0) = 0` for every seed (part (2), exact completeness);
* `fpEval_add_single`: the homomorphic update `F_zero(x + Δ e_i) = F_zero(x) + Δ r^{i+1}` (part (1));
* `card_fpEval_eq_zero_le`: for a nonzero `x` with `|x_j| < q` (the box promise `‖x‖_∞ ≤ U < q`),
  at most `n` seeds `r ∈ 𝔽_q` give `F_zero(x) = 0` (part (3): `P_t` is a nonzero polynomial of degree
  `≤ n`, Lagrange's root bound); `card_fpEval_eq_zero_le_nat` is the same count for seeds
  `r ∈ {0, …, q-1} ⊂ ℕ`.
-/

namespace F2e2e.C.FP

open Polynomial Finset

variable {q : ℕ} {n : ℕ}

/-- The fingerprint `∑_j x_j r^{j+1}` of `x : Fin n → ℤ` at the seed `r` over `ZMod q`
(eq. `R:eq:fingerprint-recurrence`, 1-based exponents). -/
def fpEval (q : ℕ) {n : ℕ} (x : Fin n → ℤ) (r : ZMod q) : ZMod q :=
  ∑ j, (x j : ZMod q) * r ^ (j.val + 1)

/-- The fingerprint polynomial `P(Z) = ∑_j (x_j mod q) Z^{j+1}` (paper: `P_t`, L277). -/
noncomputable def fpPoly (q : ℕ) {n : ℕ} (x : Fin n → ℤ) : (ZMod q)[X] :=
  ∑ j, C (x j : ZMod q) * X ^ (j.val + 1)

theorem fpPoly_eval (x : Fin n → ℤ) (r : ZMod q) : (fpPoly q x).eval r = fpEval q x r := by
  simp [fpPoly, fpEval, eval_finsetSum]

theorem fpPoly_natDegree_le (x : Fin n → ℤ) : (fpPoly q x).natDegree ≤ n := by
  unfold fpPoly
  refine natDegree_sum_le_of_forall_le _ _ fun j _ => ?_
  exact (natDegree_C_mul_X_pow_le _ _).trans (by omega)

theorem fpPoly_coeff_succ (x : Fin n → ℤ) (j : Fin n) :
    (fpPoly q x).coeff (j.val + 1) = (x j : ZMod q) := by
  unfold fpPoly
  rw [finsetSum_coeff]
  simp only [coeff_C_mul_X_pow]
  rw [Finset.sum_eq_single j]
  · simp
  · intro j' _ hj'
    rw [if_neg]
    intro h
    exact hj' (Fin.ext (by omega))
  · simp

/-- An integer of absolute value `< q` is zero modulo `q` only if it is zero. -/
theorem intCast_eq_zero_of_abs_lt {a : ℤ} (ha : |a| < q) (h : (a : ZMod q) = 0) : a = 0 := by
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd] at h
  exact Int.eq_zero_of_abs_lt_dvd h ha

/-- The fingerprint polynomial of a nonzero vector with entries of absolute value `< q` is nonzero
(paper L277: "any nonzero integer vector in `[-U, U]^n` has a coordinate `≢ 0 (mod q)`"). -/
theorem fpPoly_ne_zero {x : Fin n → ℤ} (hx : x ≠ 0) (hU : ∀ j, |x j| < q) : fpPoly q x ≠ 0 := by
  obtain ⟨j, hj⟩ : ∃ j, x j ≠ 0 := Function.ne_iff.mp hx
  intro h0
  have hc := fpPoly_coeff_succ (q := q) x j
  rw [h0, coeff_zero] at hc
  exact hj (intCast_eq_zero_of_abs_lt (hU j) hc.symm)

/-- **Root bound** (paper L277–279, Lagrange / univariate Schwartz–Zippel over `𝔽_q`): for a
nonzero `x` with `|x_j| < q`, at most `n` seeds `r ∈ ZMod q` satisfy `F_zero(x) = 0`. -/
theorem card_fpEval_eq_zero_le [Fact q.Prime] {x : Fin n → ℤ} (hx : x ≠ 0)
    (hU : ∀ j, |x j| < q) :
    (univ.filter (fun r : ZMod q => fpEval q x r = 0)).card ≤ n := by
  classical
  have hp := fpPoly_ne_zero hx hU
  have hsub : univ.filter (fun r : ZMod q => fpEval q x r = 0) ⊆ (fpPoly q x).roots.toFinset := by
    intro r hr
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hr
    rw [Multiset.mem_toFinset, mem_roots hp, IsRoot, fpPoly_eval]
    exact hr
  calc (univ.filter (fun r : ZMod q => fpEval q x r = 0)).card
      ≤ (fpPoly q x).roots.toFinset.card := Finset.card_le_card hsub
    _ ≤ Multiset.card (fpPoly q x).roots := Multiset.toFinset_card_le _
    _ ≤ (fpPoly q x).natDegree := card_roots' _
    _ ≤ n := fpPoly_natDegree_le x

/-- The root bound for seeds `r ∈ {0, …, q-1}` as natural numbers. -/
theorem card_fpEval_eq_zero_le_nat [Fact q.Prime] {x : Fin n → ℤ} (hx : x ≠ 0)
    (hU : ∀ j, |x j| < q) :
    ((Finset.range q).filter (fun r : ℕ => fpEval q x (r : ZMod q) = 0)).card ≤ n := by
  classical
  have hq : 0 < q := (Fact.out : q.Prime).pos
  have : NeZero q := ⟨hq.ne'⟩
  refine le_trans ?_ (card_fpEval_eq_zero_le hx hU)
  refine Finset.card_le_card_of_injOn (fun r : ℕ => (r : ZMod q)) ?_ ?_
  · intro r hr
    simp only [Finset.coe_filter, Finset.mem_range, Set.mem_ofPred_eq] at hr
    simp only [Finset.coe_filter, Finset.mem_univ, true_and, Set.mem_ofPred_eq]
    exact hr.2
  · intro a ha b hb hab
    simp only [Finset.coe_filter, Finset.mem_range, Set.mem_ofPred_eq] at ha hb
    have := congrArg ZMod.val hab
    simp only [ZMod.val_natCast, Nat.mod_eq_of_lt ha.1, Nat.mod_eq_of_lt hb.1] at this
    exact this

/-- Exact completeness (part (2)): the zero vector has fingerprint `0` for every seed. -/
@[simp] theorem fpEval_zero (r : ZMod q) : fpEval q (0 : Fin n → ℤ) r = 0 := by
  simp [fpEval]

/-- The homomorphic update (part (1), L259–262): `F_zero(x + Δ e_i) = F_zero(x) + Δ r^{i+1}`. -/
theorem fpEval_add_single (x : Fin n → ℤ) (i : Fin n) (Δ : ℤ) (r : ZMod q) :
    fpEval q (fun j => x j + if j = i then Δ else 0) r = fpEval q x r + (Δ : ZMod q) * r ^ (i.val + 1) := by
  simp only [fpEval, Int.cast_add, add_mul, Finset.sum_add_distrib]
  congr 1
  rw [Finset.sum_eq_single i]
  · simp
  · intro j _ hj
    simp [hj]
  · simp

end F2e2e.C.FP
