import F2e2e.C.SpaceParams
import F2e2e.C.Alg.Facts

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`): the bounds on the stored state (definitions)

`parts/partIII.tex` L1238–1262: "Each row stores `2s⌈log₂(D_*+1)⌉ = O(ℒ²)` seed bits; two
`O(ℒ³)`-bit fixed-point counters; … Live learners additionally store tags, caches, epoch and
correction counters … this is a worst-case bound: samplers have finite loop caps, scores have
deterministic correction caps, rows are silently saturated, protected scalars have explicit ranges,
and all failures enter an absorbing state."

For the exact memory of the Theorem (C) algorithm (`F2e2e/C/Alg/State.lean`: `Row`, `Bank`,
`Learner`, `State`) this file defines

* the per-component bounds `RowOK`, `BankOK`, `LearnerOK`, `StateOK` (number of stored scalars and
  list cells; magnitude of every stored integer), and the invariant `StateInv` (exact ranges of
  Definition `R:def:total-behavior` in a non-failed state, the same ranges up to the factor `4`
  always);
* the interface `AdaInvariant` to the ADA module (an invariant of its state preserved on every path);
* a canonical encoding `encState` of the memory as a `Val` of the §3 cost model (every structure as
  the list of its fields, every scalar as one integer) and the explicit tree size bounds
  `bankSizeBound`, `stateSizeBound`.

The statements about them: `F2e2e/C/SpaceSteps.lean` (the invariant through every sub-step of a
round), `F2e2e/C/SpaceSize.lean` (bit lengths and tree sizes), `F2e2e/C/SpaceState.lean` (the
invariant on every execution), `F2e2e/C/SpaceBound.lean` (the final arithmetic).
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete

/-! ## Per-component bounds -/

/-- A stored sign row (partIII.tex L207–208, L451): `2s` seed elements of `𝔽_{2^w}` (`w`-bit
patterns) and two counters saturated to `[-Z_max, Z_max]` (mantissas on `h_b`). -/
structure RowOK (P : StreamParams) (r : Row) : Prop where
  seed_length : r.seed.length = 2 * P.s
  seed_lt : ∀ z ∈ r.seed, z < 2 ^ P.w
  abs_X_le : |r.X| ≤ zSat P
  abs_Y_le : |r.Y| ≤ zSat P

/-- A stored bank (Algorithm `R:alg:regularized-norm-bank`, partIII.tex L204–207, L216): the ADA
blocks have the sizes `n_0, …, n_p` of the bank's ADA instance; at most `R_max` reserved coarse groups
remain, each of `g` subgroups of `32` rows; all rows are `RowOK`; the ADA state satisfies the
invariant `adaOK` of the ADA module. -/
structure BankOK (P : StreamParams) (adaOK : AdaState → Prop) (B : Bank) : Prop where
  ada_sizes : B.ada.map List.length = (bankAda P).blockSizes
  coarse_length_le : B.coarse.length ≤ P.Rmax
  coarse_shape : ∀ grp ∈ B.coarse, grp.length = P.gCoarse ∧ ∀ sub ∈ grp, sub.length = 32
  ada_rows : ∀ blk ∈ B.ada, ∀ r ∈ blk, RowOK P r
  coarse_rows : ∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P r
  ada_ok : adaOK B.adaSt

/-- A stored learner (partIII.tex L440, L452–453, L474, L509): tag in `[0, c · C_max]` (mantissa on
`h_C`), cache in `[0, c · A_max]` (mantissa on `h_P`), `k_d ≤ K_epoch`, `j_epoch < K_0`,
`J_used ≤ J_*`. (`c = 1`: the ranges of Definition `R:def:total-behavior`; `c = 4`: the failure
state.) -/
structure LearnerOK (P : StreamParams) (c : ℕ) (L : Learner) : Prop where
  tag_nonneg : 0 ≤ L.tag
  tag_le : L.tag ≤ c * (P.Cmax * 2 ^ P.eHC)
  cache_nonneg : 0 ≤ L.cache
  cache_le : L.cache ≤ c * (P.Amax * 2 ^ P.eHP)
  epoch_le : L.epoch ≤ P.Kepoch
  jEpoch_lt : L.jEpoch < P.K0
  jUsed_le : L.jUsed ≤ P.Jstar

/-- The whole memory: fingerprint registers in `𝔽_q`, at most `H` live learners and `H` live banks,
all within their bounds, and the terminal accumulator in `[0, c · A_max]` (mantissa on `h_leaf`).
(The round counter `t` is bounded separately, by the number of rounds.) -/
structure StateOK (P : StreamParams) (adaOK : AdaState → Prop) (c : ℕ) (s : State) : Prop where
  fpSeed_lt : s.fpSeed < P.q
  fpVal_lt : s.fpVal < P.q
  learners_length_le : s.learners.length ≤ P.H
  banks_length_le : s.banks.length ≤ P.H
  learners_ok : ∀ L ∈ s.learners, LearnerOK P c L
  banks_ok : ∀ B ∈ s.banks, BankOK P adaOK B
  leaf_nonneg : 0 ≤ s.leaf
  leaf_le : s.leaf ≤ c * (P.Amax * 2 ^ P.eHleaf)

/-- The invariant on every execution: the exact ranges in a non-failed state, and the ranges up to the
factor `4` always. (With C-ALG's current `Round.lean` every reachable state even satisfies the exact
ranges, since rescaled values are range-checked before they are stored; the factor `4` is slack.) -/
def StateInv (P : StreamParams) (adaOK : AdaState → Prop) (s : State) : Prop :=
  StateOK P adaOK 4 s ∧ (s.failed = false → StateOK P adaOK 1 s)

/-! ## The interface to the ADA module -/

/-- What the space proof needs from the ADA module (B-ARCH's mechanism; discharged by W4's ADA
representation, `F2e2e/C/Impl/AdaRep.lean`): an invariant `adaOK` of its state established by the
initialization and preserved by both interfaces, on every path of fresh bits and for all inputs. -/
structure AdaInvariant (P : StreamParams) (adaOK : AdaState → Prop) : Prop where
  init : Always (adaInit (bankAda P)) adaOK
  interval : ∀ (st : AdaState) (vals : List (List ℕ)) (l u : ℚ), adaOK st →
    Always (adaInterval (bankAda P) st vals l u) (fun r => adaOK r.2)
  numerical : ∀ (st : AdaState) (vals : List (List ℕ)), adaOK st →
    Always (adaNumerical (bankAda P) st vals) (fun r => adaOK r.2)

/-! ## The canonical encoding and the tree size bounds -/

/-- A row as the list `[seed, X, Y]` (the seed as a list of integers). -/
def encRow (r : Row) : Val :=
  Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X, Val.int r.Y]

/-- A learner as the list `[tag, cache, k_d, j_epoch, J_used]`. -/
def encLearner (L : Learner) : Val :=
  encInts [L.tag, L.cache, (L.epoch : ℤ), (L.jEpoch : ℤ), (L.jUsed : ℤ)]

/-- A bank as the list `[ADA blocks, coarse groups, ADA state]`, given an encoding of ADA states. -/
def encBank (adaEnc : AdaState → Val) (B : Bank) : Val :=
  Val.list [Val.list (B.ada.map fun blk => Val.list (blk.map encRow)),
    Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))),
    adaEnc B.adaSt]

/-- The memory as the list `[t, failed, r_fp, F_zero, learners, banks, accumulator]`. -/
def encState (adaEnc : AdaState → Val) (s : State) : Val :=
  Val.list [Val.int (s.t : ℤ), Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ),
    Val.int (s.fpVal : ℤ), Val.list (s.learners.map encLearner),
    Val.list (s.banks.map (encBank adaEnc)), Val.int s.leaf]

/-- The explicit tree size bound of one encoded bank, given the bound `adaBound` on the encoded ADA
state: `N_bank (2^6 ℒ³ + 1)` for the rows plus the list cells of the blocks, groups and subgroups. -/
def bankSizeBound (P : StreamParams) (adaBound : ℕ) : ℕ :=
  bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) + 2 * (bankAda P).blockSizes.length +
    4 * P.Rmax * (P.gCoarse + 1) + adaBound + 8

/-- The explicit tree size bound of the encoded memory: at most `H` banks, at most `H` learners and the
global registers. -/
def stateSizeBound (P : StreamParams) (adaBound : ℕ) : ℕ :=
  P.H * (bankSizeBound P adaBound + 1) + P.H * (2 ^ 6 * P.calL ^ 3 + 1) + 2 ^ 5 * P.calL ^ 3

end F2e2e.C.Space
