import Mathlib
import F2e2e.C.ClosureRows
import F2e2e.C.NormBank.Core
import F2e2e.C.Precision
import F2e2e.C.NormBank.RowErr
import F2e2e.C.NormBank.AdaRej
import F2e2e.C.NormBank.Transcript

/-!
# Theorem 6.4, the bank side of the chronological closure (proofs: C-BANK; statements: C-CLOSE)

Sources: `parts/partIII.tex` Lemma `R:lem:sec6-precision` (iv) (L1053–1066: one-step error recurrence of a
row counter, rounding error `|ζ_τ| ≤ h_b`, no saturation), Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step`
(certificates of `ValidateInterval` / `ReleaseNumerical`, partIII.tex L345–406), Algorithm 2 line [15] (terminal
rejection), and the coverage clause of Theorem `R:thm:validation_ada` (B's `coreCovered`).

The closure (`F2e2e/C/Closure*.lean`) tracks, for every live bank with row-operation history `hist`:
* the counter errors `errX P hist ζ`, `errY P hist ζ` of the hypothetical row of every seed `ζ` against the exact
  shadow measurements (`meas`), via an exact product-weighted representation over the tree logs; this file gives
  the **one-step error recurrence** `err_step` (pure bank algebra);
* the bank's ADA rejection counter (`bitAlways_*_rej`), to exclude terminal rejections;
* the certificates of the bank's calls from correct ADA outputs (`validate_cert`, `release_cert`), and the
  correctness of a covered call from the ADA event (`coreCorrect_of_adaGood`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Exact measurements and counter errors -/

/-- The exact measurement `⟨b(ζ), v⟩` of a shadow vector by the sign row of seed `ζ`. -/
noncomputable def meas (P : StreamParams) (ζ : Seed P) (v : EuclideanSpace ℝ (Fin P.Dstar)) : ℝ :=
  ∑ j, sgn P ζ j * v j

theorem meas_add (P : StreamParams) (ζ : Seed P) (v w : EuclideanSpace ℝ (Fin P.Dstar)) :
    meas P ζ (v + w) = meas P ζ v + meas P ζ w := by
  unfold meas
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [PiLp.add_apply]
  ring

theorem meas_sub (P : StreamParams) (ζ : Seed P) (v w : EuclideanSpace ℝ (Fin P.Dstar)) :
    meas P ζ (v - w) = meas P ζ v - meas P ζ w := by
  unfold meas
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [PiLp.sub_apply]
  ring

theorem meas_smul (P : StreamParams) (ζ : Seed P) (c : ℝ) (v : EuclideanSpace ℝ (Fin P.Dstar)) :
    meas P ζ (c • v) = c * meas P ζ v := by
  unfold meas
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [PiLp.smul_apply, smul_eq_mul]
  ring

theorem meas_zero (P : StreamParams) (ζ : Seed P) : meas P ζ 0 = 0 := by
  unfold meas
  simp

theorem meas_unitAt (P : StreamParams) (ζ : Seed P) {j : ℕ} (hj : j < P.Dstar) :
    meas P ζ (Tree.unitAt P.Dstar j) = sgn P ζ ⟨j, hj⟩ := by
  unfold meas Tree.unitAt
  rw [dif_pos hj]
  simp

/-- The error of the primary counter of the hypothetical row of seed `ζ` after the history `hist` (real units:
the counter is a mantissa on `h_b`). -/
noncomputable def errX (P : StreamParams) (hist : List RowOp) (ζ : Seed P) : ℝ :=
  ((rowFun P hist ζ).X : ℝ) * (P.hb : ℝ) - meas P ζ (bankShadowXY P hist).1

/-- The error of the secondary counter. -/
noncomputable def errY (P : StreamParams) (hist : List RowOp) (ζ : Seed P) : ℝ :=
  ((rowFun P hist ζ).Y : ℝ) * (P.hb : ℝ) - meas P ζ (bankShadowXY P hist).2

/-- Well-formed row operations: coordinates (1-based) in `[1, D_*]`, multipliers `|c| ≤ 2`. -/
def opOK (P : StreamParams) : RowOp → Prop
  | RowOp.phys i _ => 1 ≤ i ∧ i ≤ P.Dstar
  | RowOp.guardY g _ => 1 ≤ g ∧ g ≤ P.Dstar
  | RowOp.guardXY g _ => 1 ≤ g ∧ g ≤ P.Dstar
  | RowOp.scaleY c => |((gridVal P.eHstep c : ℚ) : ℝ)| ≤ 2
  | RowOp.scaleXY c => |((gridVal P.eHstep c : ℚ) : ℝ)| ≤ 2
  | RowOp.resetY => True

/-- The multiplier of a row operation on the primary counter. -/
noncomputable def opMultX (P : StreamParams) : RowOp → ℝ
  | RowOp.scaleXY c => ((gridVal P.eHstep c : ℚ) : ℝ)
  | _ => 1

/-- The multiplier of a row operation on the secondary counter. -/
noncomputable def opMultY (P : StreamParams) : RowOp → ℝ
  | RowOp.scaleY c => ((gridVal P.eHstep c : ℚ) : ℝ)
  | RowOp.scaleXY c => ((gridVal P.eHstep c : ℚ) : ℝ)
  | RowOp.resetY => 0
  | _ => 1

/-- **Lemma 6.1 (iv), one step** (partIII.tex L1053–1066 and the error recurrence of Lemma 6.1 (i),
L1060: `e_{τ+1} = a_τ e_τ + ζ_τ`, `|ζ_τ| ≤ h_b`): if the new exact measurement plus twice the old error plus one
grid step stays within `Z_max`, no saturation occurs and each counter error follows the recurrence with the
operation's multiplier. -/
theorem err_step (P : StreamParams) (hist : List RowOp) (op : RowOp) (hop : opOK P op) (ζ : Seed P)
    (hsatX : |meas P ζ (bankShadowXY P (hist ++ [op])).1| + 2 * |errX P hist ζ| + (P.hb : ℝ) ≤ (P.Zmax : ℝ))
    (hsatY : |meas P ζ (bankShadowXY P (hist ++ [op])).2| + 2 * |errY P hist ζ| + (P.hb : ℝ) ≤ (P.Zmax : ℝ)) :
    (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errX P (hist ++ [op]) ζ = opMultX P op * errX P hist ζ + z) ∧
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errY P (hist ++ [op]) ζ = opMultY P op * errY P hist ζ + z) := by
  have hb0 : (0 : ℝ) < P.hb := hb_pos P
  have hz0 : |(0 : ℝ)| ≤ P.hb := by rw [abs_zero]; exact hb0.le
  have hsign : ∀ i, 1 ≤ i → i ≤ P.Dstar → ∀ h : i - 1 < P.Dstar,
      ((rowSign P (rowFun P hist ζ) i : ℤ) : ℝ) = sgn P ζ ⟨i - 1, h⟩ :=
    fun i h1 h2 _ => rowSign_rowFun P hist ζ h1 h2
  unfold errX errY at *
  rw [rowFun_append, bankShadowXY_append]
  rw [bankShadowXY_append] at hsatX hsatY
  generalize rowFun P hist ζ = r at *
  generalize bankShadowXY P hist = v at *
  cases op with
  | phys i Δ =>
    obtain ⟨h1, h2⟩ := hop
    have hi : i - 1 < P.Dstar := by omega
    have hs := hsign i h1 h2 hi
    have hmX : meas P ζ (shadowStep P v (RowOp.phys i Δ)).1 =
        1 * meas P ζ v.1 + (Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩ := by
      show meas P ζ (v.1 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1)) = _
      rw [meas_add, meas_smul, meas_unitAt P ζ hi]
      ring
    have hmY : meas P ζ (shadowStep P v (RowOp.phys i Δ)).2 =
        1 * meas P ζ v.2 + (Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩ := by
      show meas P ζ (v.2 + (Δ : ℝ) • Tree.unitAt P.Dstar (i - 1)) = _
      rw [meas_add, meas_smul, meas_unitAt P ζ hi]
      ring
    have hyX : ((r.X + Δ * rowSign P r i * 2 ^ P.eHb : ℤ) : ℝ) * P.hb =
        1 * ((r.X : ℝ) * P.hb) + (Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩ + 0 := by
      push_cast
      rw [hs]
      linear_combination ((Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩) * hb_mul_two_pow P
    have hyY : ((r.Y + Δ * rowSign P r i * 2 ^ P.eHb : ℤ) : ℝ) * P.hb =
        1 * ((r.Y : ℝ) * P.hb) + (Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩ + 0 := by
      push_cast
      rw [hs]
      linear_combination ((Δ : ℝ) * sgn P ζ ⟨i - 1, hi⟩) * hb_mul_two_pow P
    have ha : |(1 : ℝ)| ≤ 2 := by norm_num
    exact ⟨⟨0, hz0, counter_step P hyX hmX hz0 ha hsatX⟩,
      ⟨0, hz0, counter_step P hyY hmY hz0 ha hsatY⟩⟩
  | guardY g δ =>
    obtain ⟨h1, h2⟩ := hop
    have hi : g - 1 < P.Dstar := by omega
    have hs := hsign g h1 h2 hi
    have hmY : meas P ζ (shadowStep P v (RowOp.guardY g δ)).2 =
        1 * meas P ζ v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ := by
      show meas P ζ (v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1)) = _
      rw [meas_add, meas_smul, meas_unitAt P ζ hi]
      ring
    have hz : |((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩| ≤
        P.hb := by
      have := abs_guardIncr_sub_le P r g δ
      rw [hs] at this
      linarith
    have hyY : ((r.Y + guardIncr P r g δ : ℤ) : ℝ) * P.hb = 1 * ((r.Y : ℝ) * P.hb) +
        ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ +
          (((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩) := by
      push_cast
      ring
    have ha : |(1 : ℝ)| ≤ 2 := by norm_num
    refine ⟨⟨0, hz0, ?_⟩, ⟨_, hz, counter_step P hyY hmY hz ha hsatY⟩⟩
    show (r.X : ℝ) * P.hb - meas P ζ v.1 = 1 * ((r.X : ℝ) * P.hb - meas P ζ v.1) + 0
    ring
  | guardXY g δ =>
    obtain ⟨h1, h2⟩ := hop
    have hi : g - 1 < P.Dstar := by omega
    have hs := hsign g h1 h2 hi
    have hmX : meas P ζ (shadowStep P v (RowOp.guardXY g δ)).1 =
        1 * meas P ζ v.1 + ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ := by
      show meas P ζ (v.1 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1)) = _
      rw [meas_add, meas_smul, meas_unitAt P ζ hi]
      ring
    have hmY : meas P ζ (shadowStep P v (RowOp.guardXY g δ)).2 =
        1 * meas P ζ v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ := by
      show meas P ζ (v.2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (g - 1)) = _
      rw [meas_add, meas_smul, meas_unitAt P ζ hi]
      ring
    have hz : |((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩| ≤
        P.hb := by
      have := abs_guardIncr_sub_le P r g δ
      rw [hs] at this
      linarith
    have hyX : ((r.X + guardIncr P r g δ : ℤ) : ℝ) * P.hb = 1 * ((r.X : ℝ) * P.hb) +
        ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ +
          (((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩) := by
      push_cast
      ring
    have hyY : ((r.Y + guardIncr P r g δ : ℤ) : ℝ) * P.hb = 1 * ((r.Y : ℝ) * P.hb) +
        ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩ +
          (((guardIncr P r g δ : ℤ) : ℝ) * P.hb - ((gridVal P.eHg δ : ℚ) : ℝ) * sgn P ζ ⟨g - 1, hi⟩) := by
      push_cast
      ring
    have ha : |(1 : ℝ)| ≤ 2 := by norm_num
    exact ⟨⟨_, hz, counter_step P hyX hmX hz ha hsatX⟩,
      ⟨_, hz, counter_step P hyY hmY hz ha hsatY⟩⟩
  | scaleY c =>
    have hmY : meas P ζ (shadowStep P v (RowOp.scaleY c)).2 =
        ((gridVal P.eHstep c : ℚ) : ℝ) * meas P ζ v.2 + 0 := by
      show meas P ζ (((gridVal P.eHstep c : ℚ) : ℝ) • v.2) = _
      rw [meas_smul]
      ring
    have hz : |((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb -
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb)| ≤ P.hb := by
      have := abs_scaleMant_sub_le P c r.Y
      linarith
    have hyY : ((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb =
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb) + 0 +
          (((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb -
            ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb)) := by
      ring
    have ha : |((gridVal P.eHstep c : ℚ) : ℝ)| ≤ 2 := hop
    refine ⟨⟨0, hz0, ?_⟩, ⟨_, hz, counter_step P hyY hmY hz ha hsatY⟩⟩
    show (r.X : ℝ) * P.hb - meas P ζ v.1 = 1 * ((r.X : ℝ) * P.hb - meas P ζ v.1) + 0
    ring
  | scaleXY c =>
    have hmX : meas P ζ (shadowStep P v (RowOp.scaleXY c)).1 =
        ((gridVal P.eHstep c : ℚ) : ℝ) * meas P ζ v.1 + 0 := by
      show meas P ζ (((gridVal P.eHstep c : ℚ) : ℝ) • v.1) = _
      rw [meas_smul]
      ring
    have hmY : meas P ζ (shadowStep P v (RowOp.scaleXY c)).2 =
        ((gridVal P.eHstep c : ℚ) : ℝ) * meas P ζ v.2 + 0 := by
      show meas P ζ (((gridVal P.eHstep c : ℚ) : ℝ) • v.2) = _
      rw [meas_smul]
      ring
    have hzX : |((scaleMant P.eHstep c r.X : ℤ) : ℝ) * P.hb -
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.X : ℝ) * P.hb)| ≤ P.hb := by
      have := abs_scaleMant_sub_le P c r.X
      linarith
    have hzY : |((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb -
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb)| ≤ P.hb := by
      have := abs_scaleMant_sub_le P c r.Y
      linarith
    have hyX : ((scaleMant P.eHstep c r.X : ℤ) : ℝ) * P.hb =
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.X : ℝ) * P.hb) + 0 +
          (((scaleMant P.eHstep c r.X : ℤ) : ℝ) * P.hb -
            ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.X : ℝ) * P.hb)) := by
      ring
    have hyY : ((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb =
        ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb) + 0 +
          (((scaleMant P.eHstep c r.Y : ℤ) : ℝ) * P.hb -
            ((gridVal P.eHstep c : ℚ) : ℝ) * ((r.Y : ℝ) * P.hb)) := by
      ring
    have ha : |((gridVal P.eHstep c : ℚ) : ℝ)| ≤ 2 := hop
    exact ⟨⟨_, hzX, counter_step P hyX hmX hzX ha hsatX⟩,
      ⟨_, hzY, counter_step P hyY hmY hzY ha hsatY⟩⟩
  | resetY =>
    refine ⟨⟨0, hz0, ?_⟩, ⟨0, hz0, ?_⟩⟩
    · show (r.X : ℝ) * P.hb - meas P ζ v.1 = 1 * ((r.X : ℝ) * P.hb - meas P ζ v.1) + 0
      ring
    · show ((0 : ℤ) : ℝ) * P.hb - meas P ζ 0 = 0 * ((r.Y : ℝ) * P.hb - meas P ζ v.2) + 0
      rw [meas_zero]
      push_cast
      ring

/-! ## The ADA module's rejection counter -/

/-- `ValidateInterval` keeps the stored rows; its ADA rejection counter counts the rejections it returns, and a
terminal rejection (Algorithm 2 line [15], `F2e2e.B.outerReject`) needs `J` earlier ones. -/
theorem bitAlways_validate_rej (P : StreamParams) (B : Bank) (S θ : ℚ) :
    BitAlways (fun r : AdaCert × Bank =>
      r.2.adaSt.rej = B.adaSt.rej + (if coreIsReject (Sum.inl r.1) = true then 1 else 0) ∧
        (r.1 = AdaCert.termHigh ∨ r.1 = AdaCert.termLow → (bankAda P).J ≤ B.adaSt.rej))
      (B.validate P S θ) :=
  bitAlways_validate_rej' P B S θ

/-- `ReleaseNumerical` does not change the ADA rejection counter. -/
theorem bitAlways_releaseLog_rej (P : StreamParams) (B : Bank) (mode : Mode) :
    BitAlways (fun r : (Option ℚ × Bank) × Option (ℚ × AdaNum) => r.1.2.adaSt.rej = B.adaSt.rej)
      (releaseLog P B mode) :=
  bitAlways_releaseLog_rej' P B mode

/-- A fresh bank's ADA module has returned no rejection. -/
theorem bitAlways_newBank_rej (P : StreamParams) : BitAlways (fun B : Bank => B.adaSt.rej = 0) (newBank P) :=
  bitAlways_newBank_rej' P

/-! ## Certificates of the bank calls -/

/-- **Theorem 4.9, interval certificates, for a logged call**: a correct ADA output (`coreCorrect` at accuracy
`a_num`) to the request of a `ValidateInterval(S, θ)` call of a bank whose counters have drift `≤ ξ` on every
seed gives the certificates for `r = (‖v_X‖² + ω)/(S + ω)`, `v_X` the bank's exact primary shadow. -/
theorem validate_cert (P : StreamParams) (hP : ParamsOK P) (rec : CallRec) {S θ : ℚ}
    (hkind : rec.kind = CallKind.validate S θ) (hscale : rec.scale = S + P.omega)
    (hreg : (bankShadowXY P rec.hist).1 (regIdx P) = 0)
    (hV : √(‖(bankShadowXY P rec.hist).1‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ))
    (hprec : ∀ ζ, |errX P rec.hist ζ| ≤ Precision.xi P)
    (hS : 0 ≤ S) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16) (out : CoreOut)
    (hada : coreCorrect (unifD P) (bankAda P).hA (P.aNum : ℝ) (callReq P rec) out) :
    ValCertCore (P.eta : ℝ) (θ : ℝ)
      ((‖(bankShadowXY P rec.hist).1‖ ^ 2 + (P.omega : ℝ)) / ((S : ℝ) + (P.omega : ℝ))) out := by
  rw [callReq_validate_eq P rec hkind hscale] at hada
  refine normBank_validate_core P hP le_rfl (precLhs_xi_le P) _ hreg (norm_aug_le_of_sqrt P hreg hV)
    (rowCtr P rec.hist) (fun ζ => ?_) hS hθ0 hθ1 out hada
  have h := hprec ζ
  unfold errX meas at h
  simp only [cntVal, modeCnt, rowCtr]
  exact h

/-- **Theorem 4.9, numerical certificate, for a logged call**: a `ReleaseNumerical(mode)` call that consumed the
coarse group `grp` (whose rows are hypothetical rows of the history, `g` subgroups of `32`), at the algorithm's
scale `c = max(lowerMedian(subgroup means), ω/2)`, on the coarse event of that group (`CoarseOK`), with counter
drift `≤ ξ` (both counters in mode `DIFF`), and a correct ADA value `μ̂`, releases
`N = max(0, Lcμ̂ − ω)` with `|N − ‖v‖²| ≤ 2^{-13}η‖v‖² + ω`, `v` the exact mode shadow. -/
theorem release_cert (P : StreamParams) (hP : ParamsOK P) (rec : CallRec) {mode : Mode}
    (hkind : rec.kind = CallKind.release mode) {grp : List (List Row)} {rest : List (List (List Row))}
    (hcoarse : rec.bank.coarse = grp :: rest)
    (hshape : grp.length = P.gCoarse ∧ ∀ sub ∈ grp, sub.length = 32)
    (hrows : ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P rec.hist r)
    (hscale : rec.scale = max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2))
    (hreg : bankShadow P mode rec.hist (regIdx P) = 0)
    (hV : √(‖bankShadow P mode rec.hist‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ))
    (hprecX : ∀ ζ, |errX P rec.hist ζ| ≤ Precision.xi P)
    (hprecY : mode = Mode.diff → ∀ ζ, |errY P rec.hist ζ| ≤ Precision.xi P)
    (hcoarseOK : CoarseOK P rec) (μ : ℚ)
    (hada : coreCorrect (unifD P) (bankAda P).hA (P.aNum : ℝ) (callReq P rec) (Sum.inr (AdaNum.val μ))) :
    NumCert (P.eta : ℝ) (P.omega : ℝ) (‖bankShadow P mode rec.hist‖ ^ 2)
      ((max 0 ((P.L : ℚ) * rec.scale * μ - P.omega) : ℚ) : ℝ) := by
  have hrs := releaseScale_eq_of_rows P mode rec.hist grp hshape.1 hshape.2 hrows
  rw [← hscale] at hrs
  rw [callReq_release_eq P rec hkind, ← hrs] at hada
  have hmed : 9 / 16 * ‖aug P P.sigma (bankShadow P mode rec.hist)‖ ^ 2 ≤
        FinProb.coarseEst (FinProb.rowVals (sgn P) (aug P P.sigma (bankShadow P mode rec.hist))
          (groupSeeds P grp)) ∧
      FinProb.coarseEst (FinProb.rowVals (sgn P) (aug P P.sigma (bankShadow P mode rec.hist))
          (groupSeeds P grp)) ≤ 23 / 16 * ‖aug P P.sigma (bankShadow P mode rec.hist)‖ ^ 2 := by
    unfold CoarseOK at hcoarseOK
    rw [hkind, hcoarse] at hcoarseOK
    exact hcoarseOK
  have hξ0 := Precision.xi_nonneg P
  have hdrift : ∀ ζ, |cntVal P mode (rowCtr P rec.hist) ζ -
      ∑ i, sgn P ζ i * bankShadow P mode rec.hist i| ≤ 2 * Precision.xi P := by
    intro ζ
    have hX := hprecX ζ
    unfold errX meas at hX
    cases mode with
    | primary =>
      simp only [cntVal, modeCnt, rowCtr, bankShadow]
      linarith
    | diff =>
      have hY := hprecY rfl ζ
      unfold errY meas at hY
      simp only [cntVal, modeCnt, rowCtr, bankShadow]
      have hsub := meas_sub P ζ (bankShadowXY P rec.hist).1 (bankShadowXY P rec.hist).2
      unfold meas at hsub
      rw [hsub]
      push_cast
      have e : ((rowFun P rec.hist ζ).X : ℝ) * P.hb - ((rowFun P rec.hist ζ).Y : ℝ) * P.hb -
          (∑ j, sgn P ζ j * (bankShadowXY P rec.hist).1 j -
            ∑ j, sgn P ζ j * (bankShadowXY P rec.hist).2 j) =
          (((rowFun P rec.hist ζ).X : ℝ) * P.hb - ∑ j, sgn P ζ j * (bankShadowXY P rec.hist).1 j) -
            (((rowFun P rec.hist ζ).Y : ℝ) * P.hb - ∑ j, sgn P ζ j * (bankShadowXY P rec.hist).2 j) := by
        ring
      have e2 : (((rowFun P rec.hist ζ).X : ℝ) - ((rowFun P rec.hist ζ).Y : ℝ)) * P.hb =
          ((rowFun P rec.hist ζ).X : ℝ) * P.hb - ((rowFun P rec.hist ζ).Y : ℝ) * P.hb := by ring
      rw [e2, e]
      have := abs_sub
        (((rowFun P rec.hist ζ).X : ℝ) * P.hb - ∑ j, sgn P ζ j * (bankShadowXY P rec.hist).1 j)
        (((rowFun P rec.hist ζ).Y : ℝ) * P.hb - ∑ j, sgn P ζ j * (bankShadowXY P rec.hist).2 j)
      linarith
  have h := normBank_release_core P hP le_rfl (precLhs_xi_le P) (bankShadow P mode rec.hist) hreg
    (norm_aug_le_of_sqrt P hreg hV) mode (rowCtr P rec.hist) hdrift (groupSeeds P grp) hmed μ hada
  rw [hrs] at h
  exact h

/-! ## Correctness of a covered call from the ADA event -/

/-- The number of interval requests of bank `lab` in a call log. -/
def nInt (lab : BankLabel) (calls : List CallRec) : ℕ :=
  (calls.filter fun rec => decide (rec.lab = lab) && rec.out.isSome &&
    (match rec.kind with
      | CallKind.validate _ _ => true
      | CallKind.release _ => false)).length

/-- The number of numerical requests of bank `lab` that reached its ADA module. -/
def nNum (lab : BankLabel) (calls : List CallRec) : ℕ :=
  (calls.filter fun rec => decide (rec.lab = lab) && rec.out.isSome &&
    (match rec.kind with
      | CallKind.validate _ _ => false
      | CallKind.release _ => true)).length

/-- The number of rejections (`HIGH`/`LOW`, terminal or not) returned by bank `lab`'s ADA module. -/
def nRej (lab : BankLabel) (calls : List CallRec) : ℕ :=
  (calls.filter fun rec => decide (rec.lab = lab) &&
    (match rec.out with
      | some o => coreIsReject o
      | none => false)).length

/-- The rejections of a bank's transcript are counted by `nRej`. -/
theorem callsTranscript_rej_count (P : StreamParams) (lab : BankLabel) (calls : List CallRec) :
    ((callsTranscript P lab calls).filter fun x => coreIsReject x.2).length = nRej lab calls := by
  unfold callsTranscript nRej
  rw [length_filter_filterMap]
  congr 1
  apply List.filter_congr
  intro rec _
  by_cases hl : rec.lab = lab
  · cases rec.out <;> simp [hl]
  · simp [hl]

/-- The interval requests of a bank's transcript are counted by `nInt`. -/
theorem callsTranscript_int_count (P : StreamParams) (lab : BankLabel) (calls : List CallRec) :
    ((callsTranscript P lab calls).filter fun x => x.1.isInterval).length = nInt lab calls := by
  unfold callsTranscript nInt
  rw [length_filter_filterMap]
  congr 1
  apply List.filter_congr
  intro rec _
  by_cases hl : rec.lab = lab
  · cases rec.out <;> cases hk : rec.kind <;> simp [hl, hk, callReq]
  · simp [hl]

/-- The numerical requests of a bank's transcript are counted by `nNum`. -/
theorem callsTranscript_num_count (P : StreamParams) (lab : BankLabel) (calls : List CallRec) :
    ((callsTranscript P lab calls).filter fun x => !x.1.isInterval).length = nNum lab calls := by
  unfold callsTranscript nNum
  rw [length_filter_filterMap]
  congr 1
  apply List.filter_congr
  intro rec _
  by_cases hl : rec.lab = lab
  · cases rec.out <;> cases hk : rec.kind <;> simp [hl, hk, callReq]
  · simp [hl]

/-- **The ADA event at one call** (Theorem 3.6 applied to the bank, partIII.tex L1277): if the call log `calls`
followed by the call `rec` of bank `lab` is a prefix of the final log of a run on which bank `lab`'s ADA event
holds, and the call is covered (at most `J` earlier rejections; at most `M` interval, resp. `R` numerical,
requests including this one), then the ADA output of the call is correct at accuracy `a_num`. -/
theorem coreCorrect_of_adaGood (P : StreamParams) (lab : BankLabel) (gF : Ghost) (hgood : AdaGood P lab gF)
    (calls : List CallRec) (rec : CallRec) (hpre : calls ++ [rec] <+: gF.calls) (hlab : rec.lab = lab)
    {out : CoreOut} (hout : rec.out = some out)
    (hrej : nRej lab calls ≤ (bankAda P).J)
    (hint : (callReq P rec).isInterval = true → nInt lab calls + 1 ≤ (bankAda P).M)
    (hnum : (callReq P rec).isInterval = false → nNum lab calls + 1 ≤ (bankAda P).R) :
    coreCorrect (unifD P) (bankAda P).hA (P.aNum : ℝ) (callReq P rec) out := by
  have htr1 : callsTranscript P lab (calls ++ [rec]) =
      callsTranscript P lab calls ++ [(callReq P rec, out)] := by
    rw [callsTranscript_append, callsTranscript_singleton P hlab hout]
  have hpreT : callsTranscript P lab calls ++ [(callReq P rec, out)] <+: adaTranscript P lab gF := by
    rw [← htr1, adaTranscript_eq_calls]
    exact callsTranscript_prefix P lab hpre
  have hcov := coreCovered_last (bankAda P) (callsTranscript P lab calls) (callReq P rec, out)
    (by rw [callsTranscript_rej_count]; exact hrej)
    (fun hI => by rw [callsTranscript_int_count]; exact hint hI)
    (fun hI => by rw [callsTranscript_num_count]; exact hnum hI)
  exact coreCorrect_of_noFail (bankAda P) hgood hpreT hcov

end F2e2e.C.Closure
