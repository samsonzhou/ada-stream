import F2e2e.C.SpaceState
import F2e2e.C.ParamsFacts

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`), part 3: the final space arithmetic

`parts/partIII.tex` L1252–1258: "A conservative bound for all row storage and bank workspace is
`2^80 N_bank ℒ³` bits per bank, plus `2^80 ℒ⁵` global overhead. At most `H ≤ H+1` banks are live.
Moreover, `η^{-2} < 2^44 ε^{-2} (H+1)^4 ≤ 2^48 ε^{-2} ℒ^4`. Thus the factors are exactly
`O(ℒ) · O(ε^{-2} ℒ⁴) · O(ℒ⁷) · O(ℒ³) = O(ε^{-2} ℒ^15)` (eq. `R:eq:space-factorization`). The displayed
conservative constants, including `ℒ ≤ Λ + 3 < 2Λ`, are below `2^512`."

* `stateSizeBound_le_paper`: the encoded memory (`F2e2e.C.Space.stateSizeBound`) is at most
  `(H+1) · 2^80 N_bank ℒ³ + 2^80 ℒ⁵`, if every ADA state has at most `2^79 N_bank ℒ³` units.
* `stateSizeBound_le_calL`: with `N_bank ≤ 2^200 η^{-2} ℒ⁷` and `η^{-2} ≤ 2^46 ε₀^{-2} ℒ⁴`, at most
  `2^328 ε₀^{-2} ℒ^15` (`ε₀ = 2^{-epsExp}`).
* `two_pow_mul_le_spaceBoundC`: for the parameters of Theorem (C),
  `2^167 · 2^328 ε₀^{-2} ℒ^15 ≤ 2^512 ε^{-2} Λ^15` (`spaceBoundC`): a factor `2^167` is left for the
  DSL encoding, transient copies and workspace (the paper-map estimate of these overheads is far
  smaller).
* `const_mul_stateSizeBound_le_spaceBoundC`: the combination, for every constant `c ≤ 2^167`.
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg

/-- The paper's conservative bound (L1252): `(H+1) · 2^80 N_bank ℒ³ + 2^80 ℒ⁵`, given at most
`2^12 ℒ` ADA blocks per bank and at most `2^79 N_bank ℒ³` units per encoded ADA state. -/
theorem stateSizeBound_le_paper (P : StreamParams) {adaBound : ℕ}
    (hblocks : (bankAda P).blockSizes.length ≤ 2 ^ 12 * P.calL)
    (hada : adaBound ≤ 2 ^ 79 * bankRows P * P.calL ^ 3) :
    stateSizeBound P adaBound ≤
      (P.H + 1) * (2 ^ 80 * bankRows P * P.calL ^ 3) + 2 ^ 80 * P.calL ^ 5 := by
  have hL := hundred_le_calL P
  have hH := H_le P
  have hg : 256 ≤ P.gCoarse := by unfold gCoarse; omega
  have hR : 2 ≤ P.Rmax := by unfold Rmax; omega
  have hNc : P.Rmax * (P.gCoarse * 32) ≤ bankRows P := by unfold bankRows; omega
  unfold stateSizeBound bankSizeBound
  set N := bankRows P with hNdef
  set L := P.calL with hLdef
  have hN14 : 2 ^ 14 ≤ N := by
    have : 2 * (256 * 32) ≤ P.Rmax * (P.gCoarse * 32) :=
      Nat.mul_le_mul hR (Nat.mul_le_mul_right 32 hg)
    omega
  have hL3 : L ≤ L ^ 3 := by
    calc L = L * 1 * 1 := by ring
      _ ≤ L * L * L := Nat.mul_le_mul (Nat.mul_le_mul_left _ (by omega)) (by omega)
      _ = L ^ 3 := by ring
  set X := N * L ^ 3 with hX
  have hX1 : N ≤ X := Nat.le_mul_of_pos_right _ (by positivity)
  have hXL : 2 ^ 14 * L ^ 3 ≤ X := Nat.mul_le_mul_right _ hN14
  have c1 : N * (2 ^ 6 * L ^ 3 + 1) = 64 * X + N := by rw [hX]; ring
  have c2 : 2 * (bankAda P).blockSizes.length ≤ X := by
    have : 2 * (2 ^ 12 * L) ≤ 2 ^ 14 * L ^ 3 := by
      have := Nat.mul_le_mul_left (2 ^ 14) hL3
      have e : 2 * (2 ^ 12 * L) = 2 ^ 13 * L := by ring
      rw [e]
      calc 2 ^ 13 * L ≤ 2 ^ 14 * L := Nat.mul_le_mul_right _ (by norm_num)
        _ ≤ 2 ^ 14 * L ^ 3 := this
    omega
  have c3 : 4 * P.Rmax * (P.gCoarse + 1) ≤ 4 * X := by
    have h1 : P.Rmax * (P.gCoarse + 1) ≤ P.Rmax * (P.gCoarse * 32) :=
      Nat.mul_le_mul_left _ (by omega)
    have e : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * (P.gCoarse + 1)) := by ring
    omega
  have c4 : adaBound ≤ 2 ^ 79 * X := by
    have e : 2 ^ 79 * N * L ^ 3 = 2 ^ 79 * X := by rw [hX]; ring
    omega
  have c5 : 9 ≤ X := by
    have : 2 ^ 14 ≤ 2 ^ 14 * L ^ 3 := Nat.le_mul_of_pos_right _ (by positivity)
    omega
  have hbank : N * (2 ^ 6 * L ^ 3 + 1) + 2 * (bankAda P).blockSizes.length +
      4 * P.Rmax * (P.gCoarse + 1) + adaBound + 8 + 1 ≤ 2 ^ 80 * X := by
    have e : (2 : ℕ) ^ 80 = 2 ^ 79 + 2 ^ 79 := by norm_num
    have h79 : 80 * X ≤ 2 ^ 79 * X := Nat.mul_le_mul_right _ (by norm_num)
    rw [c1, e]
    omega
  have hlearn : P.H * (2 ^ 6 * L ^ 3 + 1) + 2 ^ 5 * L ^ 3 ≤ 2 ^ 80 * L ^ 5 := by
    have h1 : P.H * (2 ^ 6 * L ^ 3 + 1) ≤ L * (2 ^ 6 * L ^ 3 + 1) := Nat.mul_le_mul_right _ hH
    have h2 : L * (2 ^ 6 * L ^ 3 + 1) + 2 ^ 5 * L ^ 3 ≤ 2 ^ 7 * L ^ 4 := by
      have h3 : L ≤ L ^ 4 := le_trans hL3 (Nat.pow_le_pow_right (by omega) (by norm_num))
      have h4 : 2 ^ 5 * L ^ 3 ≤ 2 ^ 5 * L ^ 4 :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by norm_num))
      have e : L * (2 ^ 6 * L ^ 3 + 1) = 2 ^ 6 * L ^ 4 + L := by ring
      rw [e]
      have e2 : (2 : ℕ) ^ 7 * L ^ 4 = 2 ^ 6 * L ^ 4 + 2 ^ 5 * L ^ 4 + 2 ^ 5 * L ^ 4 := by ring
      rw [e2]
      have h5 : L ≤ 2 ^ 5 * L ^ 4 := le_trans h3 (Nat.le_mul_of_pos_left _ (by norm_num))
      omega
    have h6 : 2 ^ 7 * L ^ 4 ≤ 2 ^ 80 * L ^ 5 :=
      Nat.mul_le_mul (Nat.pow_le_pow_right (by norm_num) (by norm_num))
        (Nat.pow_le_pow_right (by omega) (by norm_num))
    omega
  have hmain : P.H * (2 ^ 80 * X) ≤ (P.H + 1) * (2 ^ 80 * N * L ^ 3) := by
    have e : 2 ^ 80 * N * L ^ 3 = 2 ^ 80 * X := by rw [hX]; ring
    rw [e]
    exact Nat.mul_le_mul_right _ (by omega)
  have hb2 := Nat.mul_le_mul_left P.H hbank
  have e3 : P.H * (N * (2 ^ 6 * L ^ 3 + 1) + 2 * (bankAda P).blockSizes.length +
      4 * P.Rmax * (P.gCoarse + 1) + adaBound + 8 + 1) =
      P.H * (N * (2 ^ 6 * L ^ 3 + 1) + 2 * (bankAda P).blockSizes.length +
      4 * P.Rmax * (P.gCoarse + 1) + adaBound + 8 + 1) := rfl
  omega

/-- eq. `R:eq:space-factorization` (L1255–1258): live banks `≤ 2ℒ`, `η^{-2} ≤ 2^46 ε₀^{-2} ℒ⁴`, rows
beyond `η^{-2}`: `2^200 ℒ⁷`, bits per row `2^80 ℒ³`; altogether `2^328 ε₀^{-2} ℒ^15`. -/
theorem stateSizeBound_le_calL (P : StreamParams) {adaBound : ℕ}
    (hblocks : (bankAda P).blockSizes.length ≤ 2 ^ 12 * P.calL)
    (hada : adaBound ≤ 2 ^ 79 * bankRows P * P.calL ^ 3)
    (hN : bankRows P ≤ 2 ^ 200 * 2 ^ (2 * P.eEta) * P.calL ^ 7) :
    stateSizeBound P adaBound ≤ 2 ^ 328 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 := by
  have h1 := stateSizeBound_le_paper P hblocks hada
  have hH := H_add_one_le P
  have hE := two_pow_two_eEta_le_calL P
  have hL := hundred_le_calL P
  have hF : 1 ≤ 2 ^ (2 * P.epsExp) := Nat.one_le_two_pow
  have h5 : P.calL ^ 5 ≤ P.calL ^ 15 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have hN' : bankRows P ≤ 2 ^ 200 * (2 ^ 46 * 2 ^ (2 * P.epsExp) * P.calL ^ 4) * P.calL ^ 7 :=
    hN.trans (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hE))
  have h2 : (P.H + 1) * (2 ^ 80 * bankRows P * P.calL ^ 3) ≤
      (2 * P.calL) * (2 ^ 80 * (2 ^ 200 * (2 ^ 46 * 2 ^ (2 * P.epsExp) * P.calL ^ 4) * P.calL ^ 7) *
        P.calL ^ 3) :=
    Nat.mul_le_mul hH (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hN'))
  have e : (2 * P.calL) * (2 ^ 80 * (2 ^ 200 * (2 ^ 46 * 2 ^ (2 * P.epsExp) * P.calL ^ 4) *
      P.calL ^ 7) * P.calL ^ 3) = 2 ^ 327 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 := by
    rw [show (327 : ℕ) = 80 + 1 + 200 + 46 by norm_num, pow_add, pow_add, pow_add, pow_one]
    ring
  have h6 : 2 ^ 80 * P.calL ^ 5 ≤ 2 ^ 327 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 := by
    have h80 : 2 ^ 80 ≤ 2 ^ 327 * 2 ^ (2 * P.epsExp) := by
      rw [← pow_add]; exact Nat.pow_le_pow_right (by norm_num) (by omega)
    exact Nat.mul_le_mul h80 h5
  have e2 : 2 ^ 328 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 =
      2 ^ 327 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 + 2 ^ 327 * 2 ^ (2 * P.epsExp) * P.calL ^ 15 := by
    rw [show (328 : ℕ) = 327 + 1 by norm_num, pow_succ]
    generalize (2 : ℕ) ^ 327 = K
    ring
  rw [e] at h2
  omega

/-- The real-valued closing (L1258–1260): `ε₀ > ε/2` and `ℒ ≤ Λ + 3 < 2Λ` give
`2^167 · 2^328 ε₀^{-2} ℒ^15 ≤ 2^512 ε^{-2} Λ^15`. -/
theorem two_pow_mul_le_spaceBoundC {n m U : ℕ} {ε β : ℝ} (_hn : 1 ≤ n) (_hm : 1 ≤ m) (_hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10) :
    (2 : ℝ) ^ 167 * (2 ^ 328 * 2 ^ (2 * (mkStreamParams n m U ε β).epsExp) *
        ((mkStreamParams n m U ε β).calL : ℝ) ^ 15) ≤ spaceBoundC n m U ε β := by
  set P := mkStreamParams n m U ε β with hP
  have hεe : P.epsExp = dyadicExp ε := rfl
  have hβe : P.betaExp = dyadicExp β := rfl
  have hε1' : ε < 1 := by linarith
  have hβ1' : β < 1 := by linarith
  have h0 := StreamParams.half_lt_eps0 hεe hε0 hε1'
  have heps : ((P.eps0 : ℚ) : ℝ) = (1 / 2 : ℝ) ^ P.epsExp := by
    simp [StreamParams.eps0]
  rw [heps] at h0
  have h2e : (2 : ℝ) ^ P.epsExp ≤ 2 * ε⁻¹ := by
    have hpos : (0 : ℝ) < 2 ^ P.epsExp := by positivity
    have e1 : (1 / 2 : ℝ) ^ P.epsExp * 2 ^ P.epsExp = 1 := by
      rw [← mul_pow]; norm_num
    have h3 : ε * 2 ^ P.epsExp < 2 := by
      have := mul_lt_mul_of_pos_right h0 hpos
      rw [e1] at this
      linarith
    rw [le_mul_inv_iff₀ hε0]
    linarith
  have hLt := StreamParams.calL_lt_masterLambda_add_three hεe hβe hε0 hε1' hβ0 hβ1'
  have hΛ := StreamParams.hundred_lt_masterLambda n m U hε0 hε1'.le hβ0 hβ1'.le
  have hLΛ : (P.calL : ℝ) ≤ 2 * masterLambda n m U ε β := by
    have : masterLambda P.n P.m P.U ε β = masterLambda n m U ε β := rfl
    rw [this] at hLt
    linarith
  have hε2 : (2 : ℝ) ^ (2 * P.epsExp) ≤ 4 * ε⁻¹ ^ 2 := by
    calc (2 : ℝ) ^ (2 * P.epsExp) = ((2 : ℝ) ^ P.epsExp) ^ 2 := by rw [← pow_mul, mul_comm]
      _ ≤ (2 * ε⁻¹) ^ 2 := by gcongr
      _ = 4 * ε⁻¹ ^ 2 := by ring
  have hL15 : (P.calL : ℝ) ^ 15 ≤ 2 ^ 15 * masterLambda n m U ε β ^ 15 := by
    calc (P.calL : ℝ) ^ 15 ≤ (2 * masterLambda n m U ε β) ^ 15 := by gcongr
      _ = 2 ^ 15 * masterLambda n m U ε β ^ 15 := by ring
  unfold spaceBoundC
  have h512 : (2 : ℝ) ^ 512 = 2 ^ 167 * 2 ^ 328 * 2 ^ 2 * 2 ^ 15 := by
    rw [show (512 : ℕ) = 167 + 328 + 2 + 15 by norm_num, pow_add, pow_add, pow_add]
  calc (2 : ℝ) ^ 167 * (2 ^ 328 * 2 ^ (2 * P.epsExp) * (P.calL : ℝ) ^ 15)
      ≤ 2 ^ 167 * (2 ^ 328 * (4 * ε⁻¹ ^ 2) * (2 ^ 15 * masterLambda n m U ε β ^ 15)) := by
        gcongr
    _ = 2 ^ 512 * ε⁻¹ ^ 2 * masterLambda n m U ε β ^ 15 := by
        rw [h512]; generalize (2 : ℝ) ^ 328 = K; ring

/-- **Lemma 6.3, total space** (the arithmetic of L1252–1260): for the parameters of Theorem (C),
every constant multiple `c ≤ 2^167` of the encoded-memory bound fits in `2^512 ε^{-2} Λ^15`, provided
every encoded ADA state has at most `2^79 N_bank ℒ³` units. -/
theorem const_mul_stateSizeBound_le_spaceBoundC {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m)
    (hU : 1 ≤ U) (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10) {adaBound : ℕ}
    (hada : adaBound ≤
      2 ^ 79 * bankRows (mkStreamParams n m U ε β) * (mkStreamParams n m U ε β).calL ^ 3)
    {c : ℝ} (_hc0 : 0 ≤ c) (hc : c ≤ 2 ^ 167) :
    c * (stateSizeBound (mkStreamParams n m U ε β) adaBound : ℝ) ≤ spaceBoundC n m U ε β := by
  set P := mkStreamParams n m U ε β with hP
  have h1 := stateSizeBound_le_calL P (adaRows_le P).2 hada (bankRows_le P)
  have h2 := two_pow_mul_le_spaceBoundC hn hm hU hε0 hε1 hβ0 hβ1
  have h1' : (stateSizeBound P adaBound : ℝ) ≤ 2 ^ 328 * 2 ^ (2 * P.epsExp) * (P.calL : ℝ) ^ 15 := by
    exact_mod_cast h1
  calc c * (stateSizeBound P adaBound : ℝ)
      ≤ 2 ^ 167 * (2 ^ 328 * 2 ^ (2 * P.epsExp) * (P.calL : ℝ) ^ 15) :=
        mul_le_mul hc h1' (Nat.cast_nonneg _) (by positivity)
    _ ≤ spaceBoundC n m U ε β := h2

end F2e2e.C.Space
