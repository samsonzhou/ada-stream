import Mathlib
import F2e2e.C.ClosureGlue

/-!
# Theorem 6.4: frames, and the bank calls (glue between the ADA events and the tree certificates)

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1287–1317): at every bank call
of the round, the statistical event of the bank (its ADA event, Theorem 3.6 / B's `coreFails`, and the coarse
event of the consumed group, Lemma 4.2) gives the certificate of the call (Theorem 4.9), provided the call is
covered (Theorem 5.11 (2c), `CountPart`) and the bank's counters have drift `≤ ξ` (Lemma 6.1 (iv), `BankPart`).

* `Frame`: the data a block does not change (round counter, root input, round of the shadow, fingerprint);
* the bank-call glue `val_glue`, `rel_glue`, `statePart_bankNew` is in `F2e2e/C/ClosureGlue.lean` (C-BANK);
* congruence lemmas for the parts of the invariant under equal fields.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Frames and small facts -/

/-- The frame of a block: the round counter, the root input, the round of the shadow and the fingerprint
registers are unchanged. -/
def Frame (c : CState) (o : OState) (g : Ghost) (c' : CState) (o' : OState) (g' : Ghost) : Prop :=
  c'.t = c.t ∧ (shadowOf P g').x0 = (shadowOf P g).x0 ∧ (shadowOf P g').t = (shadowOf P g).t ∧
    o'.fpSeed = o.fpSeed ∧ o'.fpVal = o.fpVal

theorem frame_refl (c : CState) (o : OState) (g : Ghost) : Frame (P := P) c o g c o g :=
  ⟨rfl, rfl, rfl, rfl, rfl⟩

theorem frame_trans {c c' c'' : CState} {o o' o'' : OState} {g g' g'' : Ghost}
    (h1 : Frame (P := P) c o g c' o' g') (h2 : Frame (P := P) c' o' g' c'' o'' g'') :
    Frame (P := P) c o g c'' o'' g'' :=
  ⟨h2.1.trans h1.1, h2.2.1.trans h1.2.1, h2.2.2.1.trans h1.2.2.1, h2.2.2.2.1.trans h1.2.2.2.1,
    h2.2.2.2.2.trans h1.2.2.2.2⟩

theorem JointInv.hists_len {ph : Tree.Phase} {c : CState} {o : OState} {g : Ghost} (h : JointInv P ph c o g) :
    g.hists.length = min (ph.live P.H) (P.H - 1) + 1 := by
  rw [h.sp.rows.len_hists, ← h.sp.rows.len_labels, h.cp.nLab]

theorem JointInv.hists_len_H {ph : Tree.Phase} {c : CState} {o : OState} {g : Ghost} (h : JointInv P ph c o g)
    (hlive : ph.live P.H = P.H) : g.hists.length = P.H := by
  rw [h.hists_len, hlive]
  have := P.one_le_H
  omega

theorem JointInv.nev_succ {ph : Tree.Phase} {c : CState} {o : OState} {g : Ghost} (h : JointInv P ph c o g)
    (ht : (shadowOf P g).t ≤ P.m) (hrem : 1 ≤ remEv P.H ph) : g.events.length + 1 ≤ P.T := by
  have := countPart_nev_le h.cp ht
  omega

theorem toTreeEv_phys (i : Fin P.n) (Δ : ℤ) :
    toTreeEv P (TreeEvent.phys (i.val + 1) Δ) = some (Tree.TreeEvent.phys i Δ) := by
  have h : i.val + 1 - 1 < P.n := by simp
  simp only [toTreeEv, dif_pos h]
  congr 2

theorem guardCoord_lt (P : StreamParams) {d t : ℕ} (hd : d < P.H) (ht : 1 ≤ t) (htm : t ≤ P.m) :
    P.guardCoord d t - 1 < P.Dstar := by
  have := Tree.guardCoord_range P hd ht htm
  omega

theorem toTreeEv_guard (d gc : ℕ) (δ : ℤ) (hg : gc - 1 < P.Dstar) :
    toTreeEv P (TreeEvent.guard d gc δ) =
      some (Tree.TreeEvent.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ)) := by
  simp only [toTreeEv, dif_pos hg]

theorem toTreeEv_newRound : toTreeEv P TreeEvent.newRound = some Tree.TreeEvent.newRound := rfl

theorem toTreeEv_birth (d : ℕ) : toTreeEv P (TreeEvent.birth d) = some (Tree.TreeEvent.birth d) := rfl

theorem toTreeEv_accept (d : ℕ) : toTreeEv P (TreeEvent.accept d) = some (Tree.TreeEvent.accept d) := rfl

theorem toTreeEv_correct (d : ℕ) (cInt : ℤ) :
    toTreeEv P (TreeEvent.correct d cInt) = some (Tree.TreeEvent.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)) :=
  rfl

/-! ## Congruence of the parts under equal fields (state the block lemmas over variables) -/

theorem Ghost.labelAt_congr {g g' : Ghost} (hl : g'.labels = g.labels) (idx : ℕ) :
    g'.labelAt idx = g.labelAt idx := by
  unfold Ghost.labelAt; rw [hl]

theorem Ghost.histAt_congr {g g' : Ghost} (hh : g'.hists = g.hists) (idx : ℕ) :
    g'.histAt idx = g.histAt idx := by
  unfold Ghost.histAt; rw [hh]

theorem StatePart.congr {o o' : OState} {g g' : Ghost} (h : StatePart P o g) (hb : o'.banks = o.banks)
    (hl : g'.labels = g.labels) (hh : g'.hists = g.hists) (hc : g'.calls = g.calls) : StatePart P o' g' where
  rows := rowsOK_of_eq h.rows hb hh hl
  shape B hB := h.shape B (by rw [← hb]; exact hB)
  rej idx B hB := by
    rw [Ghost.labelAt_congr hl, hc]
    exact h.rej idx B (by rw [← hb]; exact hB)
  coarseLen idx B hB := by
    rw [Ghost.labelAt_congr hl, hc]
    exact h.coarseLen idx B (by rw [← hb]; exact hB)

theorem CountPart.congr {ph : Tree.Phase} {c c' : CState} {g g' : Ghost} (h : CountPart P ph c g)
    (hl : g'.labels = g.labels) (hc : g'.calls = g.calls) (he : g'.events = g.events)
    (hlearn : c'.learners = c.learners) : CountPart P ph c' g' := by
  have hS : shadowOf P g' = shadowOf P g := shadowOf_congr P he
  have hlab := Ghost.labelAt_congr hl
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hl]; exact h.nLab
  · rw [hlab]; exact h.label0
  · intro idx h1 h2; rw [hlab, hS]; exact h.labelSucc idx h1 (by rw [← hl]; exact h2)
  · intro rec hrec; rw [hl, hS]; exact h.fresh rec (by rw [← hc]; exact hrec)
  · intro idx hidx; rw [hlab, hc, hS]; exact h.cntInt idx (by rw [← hl]; exact hidx)
  · intro idx hidx hlive; rw [hlab, hc, hS, hlearn]; exact h.cntLive idx (by rw [← hl]; exact hidx) hlive
  · intro idx hidx hlive; rw [hlab, hc, hS]; exact h.cntNew idx (by rw [← hl]; exact hidx) hlive
  · intro d hd; rw [hS]; exact h.tbLast d hd
  · rw [he, hS]; exact h.nev

theorem TreePart.congr_c {ph : Tree.Phase} {c c' : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P ph c S nev) (hlearn : c'.learners = c.learners) (hleaf : c'.leaf = c.leaf) :
    TreePart P ph c' S nev := by
  have hr : regsOf P c' = regsOf P c := by unfold regsOf tagVal; rw [hlearn]
  have ht : tagVal P c' = tagVal P c := by funext d; unfold tagVal; rw [hlearn]
  have hcv : cacheVal P c' = cacheVal P c := by funext d; unfold cacheVal; rw [hlearn]
  have hlv : leafVal P c' = leafVal P c := by unfold leafVal; rw [hleaf]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hr]; exact h.tree
  · rw [hlearn]; exact h.nLearners
  · rw [hlearn]; exact h.root
  · rw [ht]; exact h.tagW
  · rw [hcv]; exact h.cacheW
  · rw [hlearn]; exact h.cacheNonneg
  · rw [hlearn]; exact h.tagNonneg
  · rw [hlv]; exact h.leafExact
  · rw [hlv]; exact h.leafW
  · rw [hleaf]; exact h.leafNonneg
  · exact h.bornZero

end F2e2e.C.Closure
