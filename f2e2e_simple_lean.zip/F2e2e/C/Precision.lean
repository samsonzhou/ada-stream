import Mathlib
import F2e2e.C.Params

/-!
# Part III §6.1–6.2: pathwise shadow drift and the covariant cache recurrence (pure lemmas)

Sources: `parts/partIII.tex` Lemma `R:lem:pathwise-shadow-drift` (L1001–1092) and Lemma
`R:lem:covariant-cache-recurrence` (L1094–1170).

Everything here is deterministic real arithmetic on sequences; the link to the algorithm (which counter, tag
or cache trace is meant, and where the all-interval product bounds come from) is made in the chronological
closure (`F2e2e/C/Closure*.lean`), where these lemmas are applied at every moment of the execution.

* `pathwise_expansion`: Lemma 6.1 (i), identity `R:eq:pathwise-expansion-identity` (L1014).
* `pathwise_drift_bound`: Lemma 6.1 (i), bound `R:eq:pathwise-drift-bound` (L1018). The all-interval product
  hypothesis is stated for half-open intervals `[i, j)`, `i ≤ j ≤ t`, including the empty ones; this encodes
  the paper's convention "empty product := 1" together with the implicit `1 ≤ G` (map III.6.1, hazards).
* `scale_tag_drift`: Lemma 6.1 (ii), `|Ĉ_d − C_d| ≤ G T h_C ≤ e_C` (eq. `R:eq:scale-tag-drift-bound`, L1024).
* `xi_quadratic_closure`, `xi_quadratic_closure_diff`: Lemma 6.1 (iv), eq. `R:eq:xi-quadratic-closure`
  (L1049), for `ξ = G(T+1)h_b`.
* `exact_energy_unrolled`, `covariance_inequality`: Lemma 6.2 (i), eqs. `R:eq:exact-energy-unrolled`,
  `R:eq:covariance-inequality` (L1108, L1140).
* `covariant_cache_bound`: Lemma 6.2 (i), eq. `R:eq:global-cache-invariant` (L1112), both forms.
* `cache_relative_at_Emin`: Lemma 6.2 (ii), eq. `R:eq:cache-relative-at-Emin` (L1124).
-/

namespace F2e2e.C.Precision

open Finset

/-! ## Lemma 6.1 (i): pathwise telescopic expansion -/

/-- **Lemma 6.1 (i)**, the pathwise expansion identity `R:eq:pathwise-expansion-identity`
(partIII.tex L1014): for the exact recurrence `z_{τ+1} = a_τ z_τ + d_τ` and its rounded implementation
`ẑ_{τ+1} = a_τ ẑ_τ + d_τ + ζ_τ` (`τ < t`),
`ẑ_t − z_t = (∏_{s<t} a_s)(ẑ_0 − z_0) + ∑_{k<t} (∏_{k<s<t} a_s) ζ_k`. -/
theorem pathwise_expansion (a d ζ z zh : ℕ → ℝ) (t : ℕ)
    (hz : ∀ τ < t, z (τ + 1) = a τ * z τ + d τ)
    (hzh : ∀ τ < t, zh (τ + 1) = a τ * zh τ + d τ + ζ τ) :
    zh t - z t = (∏ s ∈ range t, a s) * (zh 0 - z 0) +
      ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, a s) * ζ k := by
  induction t with
  | zero => simp
  | succ t ih =>
    have ih' := ih (fun τ hτ => hz τ (Nat.lt_succ_of_lt hτ))
      (fun τ hτ => hzh τ (Nat.lt_succ_of_lt hτ))
    have e : zh (t + 1) - z (t + 1) = a t * (zh t - z t) + ζ t := by
      rw [hzh t (Nat.lt_succ_self t), hz t (Nat.lt_succ_self t)]; ring
    have h1 : ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) (t + 1), a s) * ζ k =
        a t * ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, a s) * ζ k := by
      rw [mul_sum]
      refine sum_congr rfl (fun k hk => ?_)
      rw [prod_Ico_succ_top (Nat.succ_le_of_lt (mem_range.mp hk))]
      ring
    rw [e, ih', prod_range_succ, sum_range_succ, Ico_self, prod_empty, one_mul, h1]
    ring

/-- **Lemma 6.1 (i)**, the pathwise drift bound `R:eq:pathwise-drift-bound` (partIII.tex L1018):
if every forward interval product of multipliers (including the empty ones) has absolute value at most
`G`, and every rounding error is at most `h_err`, then `|ẑ_t − z_t| ≤ G(|ẑ_0 − z_0| + t h_err)`. -/
theorem pathwise_drift_bound (a d ζ z zh : ℕ → ℝ) (t : ℕ) (G herr : ℝ)
    (hz : ∀ τ < t, z (τ + 1) = a τ * z τ + d τ)
    (hzh : ∀ τ < t, zh (τ + 1) = a τ * zh τ + d τ + ζ τ)
    (hprod : ∀ i j, i ≤ j → j ≤ t → |∏ s ∈ Ico i j, a s| ≤ G)
    (hζ : ∀ k < t, |ζ k| ≤ herr) :
    |zh t - z t| ≤ G * (|zh 0 - z 0| + t * herr) := by
  rw [pathwise_expansion a d ζ z zh t hz hzh]
  have hG0 : 0 ≤ G := le_trans (abs_nonneg _) (hprod 0 0 le_rfl (Nat.zero_le _))
  calc |(∏ s ∈ range t, a s) * (zh 0 - z 0) + ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, a s) * ζ k|
      ≤ |∏ s ∈ range t, a s| * |zh 0 - z 0| +
          ∑ k ∈ range t, |∏ s ∈ Ico (k + 1) t, a s| * |ζ k| := by
        refine (abs_add_le _ _).trans (add_le_add (le_of_eq (abs_mul _ _)) ?_)
        refine (abs_sum_le_sum_abs _ _).trans (le_of_eq ?_)
        exact sum_congr rfl (fun k _ => abs_mul _ _)
    _ ≤ G * |zh 0 - z 0| + ∑ k ∈ range t, G * herr := by
        refine add_le_add ?_ (sum_le_sum (fun k hk => ?_))
        · rw [← Nat.Ico_zero_eq_range]
          exact mul_le_mul_of_nonneg_right (hprod 0 t (Nat.zero_le _) le_rfl) (abs_nonneg _)
        · have hk' := mem_range.mp hk
          exact mul_le_mul (hprod (k + 1) t hk' le_rfl) (hζ k hk') (abs_nonneg _) hG0
    _ = G * (|zh 0 - z 0| + t * herr) := by
        rw [sum_const, card_range, nsmul_eq_mul]; ring

/-- Variant of `pathwise_drift_bound` with nonnegative multipliers and the paper's closed-interval form of the
product hypothesis (`∏_{s=i}^{j} a_s ≤ G` for `i ≤ j < t`), plus `1 ≤ G` for the empty products. -/
theorem pathwise_drift_bound_Icc (a d ζ z zh : ℕ → ℝ) (t : ℕ) (G herr : ℝ)
    (hz : ∀ τ < t, z (τ + 1) = a τ * z τ + d τ)
    (hzh : ∀ τ < t, zh (τ + 1) = a τ * zh τ + d τ + ζ τ)
    (ha : ∀ s < t, 0 ≤ a s) (hG : 1 ≤ G)
    (hprod : ∀ i j, i ≤ j → j < t → ∏ s ∈ Icc i j, a s ≤ G)
    (hζ : ∀ k < t, |ζ k| ≤ herr) :
    |zh t - z t| ≤ G * (|zh 0 - z 0| + t * herr) := by
  refine pathwise_drift_bound a d ζ z zh t G herr hz hzh (fun i j hij hjt => ?_) hζ
  have hnn : 0 ≤ ∏ s ∈ Ico i j, a s :=
    prod_nonneg (fun s hs => ha s (lt_of_lt_of_le (mem_Ico.mp hs).2 hjt))
  rw [abs_of_nonneg hnn]
  rcases Nat.eq_or_lt_of_le hij with h | h
  · rw [h, Ico_self, prod_empty]; exact hG
  · obtain ⟨j', rfl⟩ : ∃ j', j = j' + 1 := ⟨j - 1, by omega⟩
    have hI : Ico i (j' + 1) = Icc i j' := by
      ext x; simp only [mem_Ico, mem_Icc]; omega
    rw [hI]
    exact hprod i j' (by omega) (by omega)

/-! ## Lemma 6.1 (ii): scale-tag drift -/

/-- **Lemma 6.1 (ii)** (eq. `R:eq:scale-tag-drift-bound`, partIII.tex L1022–1024): the exact strict-ancestor
tag `C` (`C_0 = 1`, `C_{τ+1} = c_τ C_τ`) and the stored tag `Ĉ` (`Ĉ_0 = 1`,
`Ĉ_{τ+1} = round_{h_C}(c_τ Ĉ_τ) = c_τ Ĉ_τ + ζ_τ`, `|ζ_τ| ≤ h_C`) over at most `T` ancestor corrections whose
forward interval products are at most `G` satisfy `|Ĉ_t − C_t| ≤ G T h_C ≤ e_C`. -/
theorem scale_tag_drift (P : StreamParams) (c ζ C Ch : ℕ → ℝ) (t : ℕ)
    (hC0 : C 0 = 1) (hCh0 : Ch 0 = 1)
    (hC : ∀ τ < t, C (τ + 1) = c τ * C τ) (hCh : ∀ τ < t, Ch (τ + 1) = c τ * Ch τ + ζ τ)
    (hprod : ∀ i j, i ≤ j → j ≤ t → |∏ s ∈ Ico i j, c s| ≤ (P.G : ℝ))
    (hζ : ∀ k < t, |ζ k| ≤ (P.hC : ℝ)) (ht : t ≤ P.T) :
    |Ch t - C t| ≤ (P.eC : ℝ) := by
  have h := pathwise_drift_bound c (fun _ => 0) ζ C Ch t (P.G : ℝ) (P.hC : ℝ)
    (fun τ hτ => by rw [hC τ hτ]; ring) (fun τ hτ => by rw [hCh τ hτ]; ring) hprod hζ
  rw [hC0, hCh0, sub_self, abs_zero, zero_add] at h
  have hG : (0 : ℝ) < P.G := by exact_mod_cast P.G_pos
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have hhC : (0 : ℝ) ≤ P.hC := by
    have : (0 : ℚ) ≤ P.hC := by unfold StreamParams.hC; positivity
    exact_mod_cast this
  have hhC' : (P.hC : ℝ) ≤ (P.eC : ℝ) / ((P.T : ℝ) * P.G) := by
    have := P.hC_le
    exact_mod_cast this
  have ht' : (t : ℝ) ≤ P.T := by exact_mod_cast ht
  calc |Ch t - C t| ≤ (P.G : ℝ) * (t * P.hC) := h
    _ ≤ (P.G : ℝ) * (P.T * ((P.eC : ℝ) / ((P.T : ℝ) * P.G))) := by
        apply mul_le_mul_of_nonneg_left _ hG.le
        exact mul_le_mul ht' hhC' hhC hT.le
    _ = (P.eC : ℝ) := by field_simp

/-! ## Lemma 6.1 (iv): the `ξ` and `2ξ` quadratic closure -/

/-- `ξ := G (T+1) h_b` (eq. `R:eq:counter-xi-bound`, partIII.tex L1041). -/
noncomputable def xi (P : StreamParams) : ℝ := (P.G : ℝ) * ((P.T : ℝ) + 1) * (P.hb : ℝ)

theorem xi_nonneg (P : StreamParams) : 0 ≤ xi P := by
  unfold xi
  have : (0 : ℝ) ≤ P.hb := by exact_mod_cast P.hb_pos.le
  positivity

/-- `ξ ≤ ηω/(2^40 D_* (V+1))` (the last inequality of `R:eq:counter-xi-bound`, from `R:eq:grid-hb`). -/
theorem xi_le (P : StreamParams) :
    xi P ≤ (P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1)) := by
  have h := P.G_mul_T_add_one_mul_hb_le
  unfold xi
  exact_mod_cast h

/-- `ξ ≤ 1`. -/
theorem xi_le_one (P : StreamParams) : xi P ≤ 1 := by
  refine (xi_le P).trans ?_
  have he : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have he0 : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
  have ho : (P.omega : ℝ) ≤ 1 := by exact_mod_cast P.omega_le_one
  have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
  have hD : (1 : ℝ) ≤ P.Dstar := by exact_mod_cast P.Dstar_pos
  have hV : (1 : ℝ) ≤ (P.V : ℝ) + 1 := by
    have : (0 : ℝ) ≤ P.V := Nat.cast_nonneg _
    linarith
  have hden : (1 : ℝ) ≤ 2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1) := by
    have h1 : (1 : ℝ) ≤ 2 ^ 40 := by norm_num
    calc (1 : ℝ) = 1 * 1 * 1 := by ring
      _ ≤ 2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1) := by gcongr
  rw [div_le_one (by linarith)]
  calc (P.eta : ℝ) * P.omega ≤ 1 * 1 := mul_le_mul he ho ho0 zero_le_one
    _ ≤ _ := by linarith

/-- **Lemma 6.1 (iv)**, first half of `R:eq:xi-quadratic-closure` (partIII.tex L1049, L1089):
`2√D_* V ξ + ξ² ≤ ηω/2^38` (the Norm-Bank premise `R:eq:bank-precision-premise` asks for `ηω/2^30`). -/
theorem xi_quadratic_closure (P : StreamParams) :
    2 * Real.sqrt P.Dstar * P.V * xi P + xi P ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 38 := by
  set ξ := xi P with hξdef
  have hξ0 : 0 ≤ ξ := xi_nonneg P
  have hξ1 : ξ ≤ 1 := xi_le_one P
  have hD : (1 : ℝ) ≤ P.Dstar := by exact_mod_cast P.Dstar_pos
  have hsD : 1 ≤ Real.sqrt P.Dstar := by
    rw [show (1 : ℝ) = Real.sqrt 1 from Real.sqrt_one.symm]
    exact Real.sqrt_le_sqrt hD
  have hsD2 : Real.sqrt P.Dstar * Real.sqrt P.Dstar = P.Dstar :=
    Real.mul_self_sqrt (by linarith)
  have hV0 : (0 : ℝ) ≤ P.V := Nat.cast_nonneg _
  have he0 : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
  have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
  have hxi := xi_le P
  -- ξ² ≤ 2√D_* ξ, so the left side is ≤ 2√D_* (V+1) ξ
  have h1 : 2 * Real.sqrt P.Dstar * P.V * ξ + ξ ^ 2 ≤ 2 * Real.sqrt P.Dstar * ((P.V : ℝ) + 1) * ξ := by
    have : ξ ^ 2 ≤ 2 * Real.sqrt P.Dstar * ξ := by
      rw [sq]
      exact mul_le_mul_of_nonneg_right (by linarith) hξ0
    nlinarith
  have hsDle : Real.sqrt P.Dstar ≤ P.Dstar := by nlinarith
  have hX0 : 0 ≤ (P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1)) := by
    apply div_nonneg (mul_nonneg he0 ho0)
    have : (0 : ℝ) < P.Dstar := by linarith
    positivity
  have hV1 : (0 : ℝ) ≤ (P.V : ℝ) + 1 := by linarith
  have h2 : 2 * Real.sqrt P.Dstar * ((P.V : ℝ) + 1) * ξ ≤
      2 * P.Dstar * ((P.V : ℝ) + 1) *
        ((P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1))) := by
    have hsD0 : 0 ≤ 2 * Real.sqrt P.Dstar * ((P.V : ℝ) + 1) := by
      have := Real.sqrt_nonneg (P.Dstar : ℝ)
      positivity
    calc 2 * Real.sqrt P.Dstar * ((P.V : ℝ) + 1) * ξ
        ≤ 2 * Real.sqrt P.Dstar * ((P.V : ℝ) + 1) *
            ((P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1))) :=
          mul_le_mul_of_nonneg_left hxi hsD0
      _ ≤ 2 * P.Dstar * ((P.V : ℝ) + 1) *
            ((P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1))) := by
          apply mul_le_mul_of_nonneg_right _ hX0
          have : 2 * Real.sqrt P.Dstar ≤ 2 * P.Dstar := by linarith
          exact mul_le_mul_of_nonneg_right this hV1
  have h3 : 2 * P.Dstar * ((P.V : ℝ) + 1) *
        ((P.eta : ℝ) * P.omega / (2 ^ 40 * P.Dstar * ((P.V : ℝ) + 1))) =
      (P.eta : ℝ) * P.omega / 2 ^ 39 := by
    have hD0 : (P.Dstar : ℝ) ≠ 0 := by linarith
    have hV0' : (P.V : ℝ) + 1 ≠ 0 := by linarith
    field_simp
  have h4 : (P.eta : ℝ) * P.omega / 2 ^ 39 ≤ (P.eta : ℝ) * P.omega / 2 ^ 38 :=
    div_le_div_of_nonneg_left (mul_nonneg he0 ho0) (by norm_num) (by norm_num)
  linarith

/-- **Lemma 6.1 (iv)**, second half of `R:eq:xi-quadratic-closure` (difference counters, drift `2ξ`):
`4√D_* V ξ + 4ξ² ≤ ηω/2^36`. -/
theorem xi_quadratic_closure_diff (P : StreamParams) :
    4 * Real.sqrt P.Dstar * P.V * xi P + 4 * xi P ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 36 := by
  have h := xi_quadratic_closure P
  have e : 4 * Real.sqrt P.Dstar * P.V * xi P + 4 * xi P ^ 2 =
      2 * (2 * Real.sqrt P.Dstar * P.V * xi P + xi P ^ 2) + 2 * xi P ^ 2 := by ring
  have hsq : 0 ≤ xi P ^ 2 := sq_nonneg _
  have he0 : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
  have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
  have h' : xi P ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 38 := by
    have : 0 ≤ 2 * Real.sqrt P.Dstar * P.V * xi P :=
      mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (Real.sqrt_nonneg _)) (Nat.cast_nonneg _))
        (xi_nonneg P)
    linarith
  have e2 : (P.eta : ℝ) * P.omega / 2 ^ 36 = 4 * ((P.eta : ℝ) * P.omega / 2 ^ 38) := by ring
  rw [e, e2]
  linarith

/-- The Norm-Bank precision premise `R:eq:bank-precision-premise` (Theorem 4.9) with `17` spare bits:
`2√D_* V ξ + ξ² ≤ ηω/2^30`. -/
theorem bank_precision_premise (P : StreamParams) :
    2 * Real.sqrt P.Dstar * P.V * xi P + xi P ^ 2 ≤ (P.eta : ℝ) * P.omega / 2 ^ 30 := by
  refine (xi_quadratic_closure P).trans ?_
  have : (0 : ℝ) ≤ (P.eta : ℝ) * P.omega := by
    have he0 : (0 : ℝ) ≤ P.eta := by exact_mod_cast P.eta_pos.le
    have ho0 : (0 : ℝ) ≤ P.omega := by exact_mod_cast P.omega_pos.le
    positivity
  exact div_le_div_of_nonneg_left this (by norm_num) (by norm_num)

/-! ## Lemma 6.2: the covariant cache recurrence -/

/-- **Lemma 6.2 (i)**, first part (eq. `R:eq:exact-energy-unrolled`, partIII.tex L1108): unrolling
`E_{τ+1} = c_τ² E_τ + δ_τ²`. -/
theorem exact_energy_unrolled (c δ E : ℕ → ℝ) (t : ℕ)
    (hE : ∀ τ < t, E (τ + 1) = c τ ^ 2 * E τ + δ τ ^ 2) :
    E t = (∏ s ∈ range t, c s ^ 2) * E 0 + ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * δ k ^ 2 := by
  have h := pathwise_expansion (fun s => c s ^ 2) (fun _ => 0) (fun s => δ s ^ 2) (fun _ => 0) E t
    (fun τ _ => by ring) (fun τ hτ => by rw [hE τ hτ]; ring)
  simpa using h

/-- **Lemma 6.2 (i)**, the covariance inequality `R:eq:covariance-inequality` (partIII.tex L1140):
guard energies are nonnegative, so `(∏_{s<t} c_s²) E_0 ≤ E_t`. -/
theorem covariance_inequality (c δ E : ℕ → ℝ) (t : ℕ)
    (hE : ∀ τ < t, E (τ + 1) = c τ ^ 2 * E τ + δ τ ^ 2) :
    (∏ s ∈ range t, c s ^ 2) * E 0 ≤ E t := by
  rw [exact_energy_unrolled c δ E t hE]
  have : 0 ≤ ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * δ k ^ 2 :=
    sum_nonneg (fun k _ => mul_nonneg (prod_nonneg (fun s _ => sq_nonneg _)) (sq_nonneg _))
  linarith

/-- **Lemma 6.2 (i)** (eq. `R:eq:global-cache-invariant`, partIII.tex L1112, first form), in re-indexed time
(`τ = 0` is the last initialization/refresh `t_0`): if `|P_0 − E_0| ≤ c₀ηE_0 + ω + h_P` with `c₀ = 2^{-13}`
(`R:eq:cache-refresh-base`), every operation is `E ↦ c_τ²E + δ_τ²`, `P ↦ c_τ²P + δ_τ² + ζ_τ` with
`|ζ_τ| ≤ h_P`, every forward interval product of the `c_s²` is at most `G²`, and `t + 1 ≤ T`, then
`|P_t − E_t| ≤ 2^{-13}ηE_t + ωG² + TG²h_P`. -/
theorem covariant_cache_bound (c δ ζ E Pc : ℕ → ℝ) (t : ℕ) (η ω hP G T : ℝ)
    (hη : 0 ≤ η) (hω : 0 ≤ ω) (hhP : 0 ≤ hP)
    (hE : ∀ τ < t, E (τ + 1) = c τ ^ 2 * E τ + δ τ ^ 2)
    (hPc : ∀ τ < t, Pc (τ + 1) = c τ ^ 2 * Pc τ + δ τ ^ 2 + ζ τ)
    (hζ : ∀ k < t, |ζ k| ≤ hP)
    (hprod : ∀ i j, i ≤ j → j ≤ t → ∏ s ∈ Ico i j, c s ^ 2 ≤ G ^ 2)
    (hbase : |Pc 0 - E 0| ≤ (1 / 2) ^ 13 * η * E 0 + ω + hP)
    (hT : (t : ℝ) + 1 ≤ T) :
    |Pc t - E t| ≤ (1 / 2) ^ 13 * η * E t + ω * G ^ 2 + T * G ^ 2 * hP := by
  have hexp := pathwise_expansion (fun s => c s ^ 2) (fun s => δ s ^ 2) ζ E Pc t hE hPc
  have hcov := covariance_inequality c δ E t hE
  have hG2 : 0 ≤ G ^ 2 := sq_nonneg G
  set Pi0 := ∏ s ∈ range t, c s ^ 2 with hPi0
  have hPi0nn : 0 ≤ Pi0 := prod_nonneg (fun s _ => sq_nonneg _)
  have hPi0G : Pi0 ≤ G ^ 2 := by
    have := hprod 0 t (Nat.zero_le _) le_rfl
    rwa [Nat.Ico_zero_eq_range] at this
  rw [hexp]
  have hsum : |∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * ζ k| ≤ t * (G ^ 2 * hP) := by
    calc |∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * ζ k|
        ≤ ∑ k ∈ range t, |(∏ s ∈ Ico (k + 1) t, c s ^ 2) * ζ k| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ k ∈ range t, G ^ 2 * hP := by
          refine sum_le_sum (fun k hk => ?_)
          have hk' := mem_range.mp hk
          have hnn : 0 ≤ ∏ s ∈ Ico (k + 1) t, c s ^ 2 := prod_nonneg (fun s _ => sq_nonneg _)
          rw [abs_mul, abs_of_nonneg hnn]
          exact mul_le_mul (hprod (k + 1) t hk' le_rfl) (hζ k hk') (abs_nonneg _) hG2
      _ = t * (G ^ 2 * hP) := by rw [sum_const, card_range, nsmul_eq_mul]
  have hfirst : |Pi0 * (Pc 0 - E 0)| ≤ (1 / 2) ^ 13 * η * E t + G ^ 2 * ω + G ^ 2 * hP := by
    rw [abs_mul, abs_of_nonneg hPi0nn]
    calc Pi0 * |Pc 0 - E 0| ≤ Pi0 * ((1 / 2) ^ 13 * η * E 0 + ω + hP) :=
          mul_le_mul_of_nonneg_left hbase hPi0nn
      _ = (1 / 2) ^ 13 * η * (Pi0 * E 0) + Pi0 * ω + Pi0 * hP := by ring
      _ ≤ (1 / 2) ^ 13 * η * E t + G ^ 2 * ω + G ^ 2 * hP := by
          have hc : (0 : ℝ) ≤ (1 / 2) ^ 13 * η := by positivity
          have h1 : (1 / 2) ^ 13 * η * (Pi0 * E 0) ≤ (1 / 2) ^ 13 * η * E t :=
            mul_le_mul_of_nonneg_left hcov hc
          have h2 : Pi0 * ω ≤ G ^ 2 * ω := mul_le_mul_of_nonneg_right hPi0G hω
          have h3 : Pi0 * hP ≤ G ^ 2 * hP := mul_le_mul_of_nonneg_right hPi0G hhP
          linarith
  calc |Pi0 * (Pc 0 - E 0) + ∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * ζ k|
      ≤ |Pi0 * (Pc 0 - E 0)| + |∑ k ∈ range t, (∏ s ∈ Ico (k + 1) t, c s ^ 2) * ζ k| :=
        abs_add_le _ _
    _ ≤ ((1 / 2) ^ 13 * η * E t + G ^ 2 * ω + G ^ 2 * hP) + t * (G ^ 2 * hP) :=
        add_le_add hfirst hsum
    _ = (1 / 2) ^ 13 * η * E t + ω * G ^ 2 + ((t : ℝ) + 1) * G ^ 2 * hP := by ring
    _ ≤ (1 / 2) ^ 13 * η * E t + ω * G ^ 2 + T * G ^ 2 * hP := by
        have : ((t : ℝ) + 1) * G ^ 2 * hP ≤ T * G ^ 2 * hP :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hT hG2) hhP
        linarith

/-- **Lemma 6.2 (i)**, second form of `R:eq:global-cache-invariant`:
`2^{-13}ηE + ωG² + TG²h_P ≤ (η/2^12)E + 2ωG² + TG²D_*h_P` (for `E ≥ 0`, `D_* ≥ 1`); this is hypothesis (H2) of
Theorem 5.9. -/
theorem cache_bound_weaken (η ω hP G T D E : ℝ) (hη : 0 ≤ η) (hω : 0 ≤ ω) (hhP : 0 ≤ hP)
    (hT : 0 ≤ T) (hD : 1 ≤ D) (hE : 0 ≤ E) :
    (1 / 2) ^ 13 * η * E + ω * G ^ 2 + T * G ^ 2 * hP ≤
      η / 2 ^ 12 * E + 2 * ω * G ^ 2 + T * G ^ 2 * D * hP := by
  have h1 : (1 / 2) ^ 13 * η * E ≤ η / 2 ^ 12 * E := by
    have : (1 / 2 : ℝ) ^ 13 * η ≤ η / 2 ^ 12 := by
      have : (1 / 2 : ℝ) ^ 13 * η = η / 2 ^ 12 / 2 := by ring
      rw [this]; linarith [div_nonneg hη (by norm_num : (0 : ℝ) ≤ 2 ^ 12)]
    exact mul_le_mul_of_nonneg_right this hE
  have h2 : ω * G ^ 2 ≤ 2 * ω * G ^ 2 := by nlinarith [sq_nonneg G]
  have h3 : T * G ^ 2 * hP ≤ T * G ^ 2 * D * hP := by
    have h0 : 0 ≤ T * G ^ 2 * hP := by positivity
    nlinarith
  linarith

/-- **Lemma 6.2 (ii)** (eqs. `R:eq:cache-margin-20bits`, `R:eq:omega-margin-at-Emin`,
`R:eq:cache-relative-at-Emin`, partIII.tex L1114–1124): under the committed grids,
`2ωG² + TG²D_*h_P < 2^{-19}(η/2^12)E_min`, hence whenever `E ≥ E_min`, a cache error within the second form of
`R:eq:global-cache-invariant` is below `(η/2^11)E`. -/
theorem cache_relative_at_Emin (P : StreamParams) (Pc E : ℝ) (hEmin : (P.Emin : ℝ) ≤ E)
    (h : |Pc - E| ≤ (P.eta : ℝ) / 2 ^ 12 * E + 2 * P.omega * (P.G : ℝ) ^ 2 +
      P.T * (P.G : ℝ) ^ 2 * P.Dstar * P.hP) :
    |Pc - E| < (P.eta : ℝ) / 2 ^ 11 * E := by
  have hadd : 2 * (P.omega : ℝ) * (P.G : ℝ) ^ 2 + P.T * (P.G : ℝ) ^ 2 * P.Dstar * P.hP <
      (1 / 2) ^ 19 * ((P.eta : ℝ) / 2 ^ 12) * P.Emin := by
    have h1 := P.two_omega_G_sq_add_lt
    have h2 := P.eta_cube_nu_sq_eq
    rw [h2] at h1
    have h1' : ((2 * P.omega * (P.G : ℚ) ^ 2 + P.T * (P.G : ℚ) ^ 2 * P.Dstar * P.hP : ℚ) : ℝ) <
        (((1 / 2) ^ 19 * (P.eta / 2 ^ 12) * P.Emin : ℚ) : ℝ) := by exact_mod_cast h1
    push_cast at h1'
    exact h1'
  have he0 : (0 : ℝ) < P.eta := by exact_mod_cast P.eta_pos
  have hEm0 : (0 : ℝ) < P.Emin := by
    have : (0 : ℚ) < P.Emin := by
      unfold StreamParams.Emin
      have := P.eta_pos
      have := P.nu_pos
      positivity
    exact_mod_cast this
  have hE0 : 0 < E := lt_of_lt_of_le hEm0 hEmin
  have h3 : (1 / 2 : ℝ) ^ 19 * ((P.eta : ℝ) / 2 ^ 12) * P.Emin ≤
      (1 / 2 : ℝ) ^ 19 * ((P.eta : ℝ) / 2 ^ 12) * E :=
    mul_le_mul_of_nonneg_left hEmin (by positivity)
  have h4 : (P.eta : ℝ) / 2 ^ 12 * E + (1 / 2 : ℝ) ^ 19 * ((P.eta : ℝ) / 2 ^ 12) * E <
      (P.eta : ℝ) / 2 ^ 11 * E := by
    have : (P.eta : ℝ) / 2 ^ 12 * E + (1 / 2 : ℝ) ^ 19 * ((P.eta : ℝ) / 2 ^ 12) * E =
        (1 + (1 / 2) ^ 19) / 2 ^ 12 * (P.eta * E) := by ring
    rw [this]
    have : (P.eta : ℝ) / 2 ^ 11 * E = 2 / 2 ^ 12 * (P.eta * E) := by ring
    rw [this]
    apply mul_lt_mul_of_pos_right _ (mul_pos he0 hE0)
    norm_num
  linarith

end F2e2e.C.Precision
