import F2e2e.C.ClosureProbCoreDefs
import F2e2e.B.Final
import F2e2e.C.ParamsBank

/-!
# Theorem 6.4, probability layer (C-PROB): the B-side count for one bank

Paper: `parts/partIII.tex` L1271–1277 (Theorem `R:thm:validation_ada` supplies each bank's capped ADA event,
budget `β_B/2`); the bank ADA instance is `bankAda P = adaAlg2Params m J_max R_max a_num (β_B/2)`
(`bankAdaParams_eq_dyadicExp`).

`coreQ_count`: for every deterministic valid controller, at most a `β_B/2` fraction of the bit strings of any
length `n ≥ depth` make the sample-then-core program `coreQ P ctrl T` (`F2e2e/C/ClosureProbCoreDefs.lean`) end
with an output list on which B's core-level failure event occurs at accuracy `a_num`.

Proof: the tape sum is `2^n` times the law (`BitProg.sum_tapes_eq`); the ADA sample rows, flattened, are `N`
independent fresh rows (`sampleBlocks_map_flatten`), whose seeds are independent uniform seeds
(`law_sampleList_map`, `law_seed`: a seed is `2s` uniform `w`-bit words); B's core-level guarantee for deterministic
controllers (`F2e2e.B.core_guarantee_det`, accuracy `a_num − h_A`, monotone in the accuracy: `coreFails_mono`)
bounds the failure probability by `β_B/2`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.NormBank F2e2e.C.Top
open scoped ENNReal

namespace CoreQCount

/-! ## Bit strings of length `n` -/

theorem lenFinset_eq_image (n : ℕ) :
    TBitProg.lenFinset n = Finset.univ.image (List.ofFn : (Fin n → Bool) → List Bool) := by
  ext l
  rw [TBitProg.mem_lenFinset, Finset.mem_image]
  constructor
  · intro hl
    subst hl
    exact ⟨l.get, Finset.mem_univ _, List.ofFn_get l⟩
  · rintro ⟨ω, -, rfl⟩
    exact List.length_ofFn

theorem sum_lenFinset (n : ℕ) (G : List Bool → ℝ≥0∞) :
    ∑ l ∈ TBitProg.lenFinset n, G l = ∑ ω : Fin n → Bool, G (List.ofFn ω) := by
  rw [lenFinset_eq_image, Finset.sum_image (fun ω _ ω' _ h => List.ofFn_injective h)]

/-! ## The ADA sample rows -/

theorem sampleList_add {α : Type} (p : BitProg α) (b : ℕ) :
    ∀ a : ℕ, sampleList p (a + b) = (sampleList p a).bind fun l1 => (sampleList p b).map (l1 ++ ·)
  | 0 => by
      rw [Nat.zero_add]
      show sampleList p b = BitProg.bind (BitProg.pure []) fun l1 => (sampleList p b).map (l1 ++ ·)
      rw [BitProg.bind_pure']
      show sampleList p b = (sampleList p b).bind (BitProg.pure ∘ (([] : List α) ++ ·))
      have h : (BitProg.pure ∘ (([] : List α) ++ ·)) = BitProg.pure := by
        funext l
        simp
      rw [h, BitProg.bind_pure_right]
  | a + 1 => by
      rw [show a + 1 + b = (a + b) + 1 by omega, sampleList_succ, sampleList_add p b a, sampleList_succ]
      simp only [BitProg.map, BitProg.bind_assoc, BitProg.bind_pure', Function.comp_def,
        List.cons_append]

/-- The ADA sample rows, flattened, are `∑ n_j` independent fresh rows. -/
theorem sampleBlocks_map_flatten (P : StreamParams) :
    ∀ sizes : List ℕ, (sampleBlocks P sizes).map List.flatten = sampleList (newRow P) sizes.sum
  | [] => rfl
  | nj :: rest => by
      rw [List.sum_cons, sampleList_add (newRow P) rest.sum nj, ← sampleBlocks_map_flatten P rest,
        show sampleBlocks P (nj :: rest) = (sampleList (newRow P) nj).bind (fun blk =>
          (sampleBlocks P rest).bind fun l => BitProg.pure (blk :: l)) from rfl]
      simp only [BitProg.map, BitProg.bind_assoc, BitProg.bind_pure', Function.comp_def,
        List.flatten_cons]

/-! ## Laws of independent draws -/

open Classical in
theorem map_cons_apply {N : ℕ} {β : Type} (ν : PMF (Fin N → β)) (x : β) (s : Fin (N + 1) → β) :
    (ν.map (fun t => (Fin.cons x t : Fin (N + 1) → β))) s = if x = s 0 then ν (Fin.tail s) else 0 := by
  rw [PMF.map_apply]
  split_ifs with hx
  · rw [tsum_eq_single (Fin.tail s)]
    · rw [if_pos]
      rw [hx]
      exact (Fin.cons_self_tail s).symm
    · intro t ht
      rw [if_neg]
      intro hst
      apply ht
      rw [hst, Fin.tail_cons]
  · refine ENNReal.tsum_eq_zero.2 fun t => ?_
    rw [if_neg]
    intro hst
    apply hx
    rw [hst, Fin.cons_zero]

/-- The law of `N` independent draws of `p`, each pushed through `f`: the product of the pushed laws. -/
theorem law_sampleList_map {α β : Type} (p : BitProg α) (f : α → β) (d : α) :
    ∀ (N : ℕ) (s : Fin N → β),
      ((sampleList p N).law.map fun L => fun ℓ : Fin N => f (L.getD ℓ d)) s =
        ∏ ℓ, (p.law.map f) (s ℓ)
  | 0, s => by
      show (PMF.map (fun L => fun ℓ : Fin 0 => f (L.getD ℓ d)) (PMF.pure [])) s = _
      rw [PMF.pure_map, PMF.pure_apply, if_pos (funext fun ℓ => ℓ.elim0)]
      simp
  | N + 1, s => by
      have hF : ∀ (a : α) (L : List α), (fun ℓ : Fin (N + 1) => f ((a :: L).getD ℓ d)) =
          (Fin.cons (f a) (fun ℓ : Fin N => f (L.getD ℓ d)) : Fin (N + 1) → β) := by
        intro a L
        funext ℓ
        refine Fin.cases ?_ (fun i => ?_) ℓ
        · simp
        · simp
      have hlaw : (sampleList p (N + 1)).law.map (fun L => fun ℓ : Fin (N + 1) => f (L.getD ℓ d)) =
          p.law.bind fun a => ((sampleList p N).law.map fun L => fun ℓ : Fin N => f (L.getD ℓ d)).map
            (fun t => (Fin.cons (f a) t : Fin (N + 1) → β)) := by
        rw [sampleList_succ, BitProg.law_bind, PMF.map_bind]
        congr 1
        funext a
        rw [BitProg.law_bind, PMF.map_bind, PMF.map_comp]
        simp only [BitProg.law_pure, PMF.pure_map, Function.comp_def]
        rw [← PMF.bind_pure_comp]
        congr 1
        funext L
        rw [hF a L]
        rfl
      rw [hlaw, PMF.bind_apply]
      simp only [map_cons_apply]
      rw [law_sampleList_map p f d N (Fin.tail s), Fin.prod_univ_succ, PMF.map_apply]
      rw [← ENNReal.tsum_mul_right]
      refine tsum_congr fun a => ?_
      by_cases ha : f a = s 0
      · rw [if_pos ha, if_pos ha.symm]
        rfl
      · rw [if_neg ha, if_neg (Ne.symm ha), mul_zero, zero_mul]

/-- A `w`-bit word as a coefficient of a seed. -/
def wordCoeff (P : StreamParams) (x : ℕ) : Fin (2 ^ Hash.seedDeg P.Dstar) :=
  ⟨x % 2 ^ Hash.seedDeg P.Dstar, Nat.mod_lt _ (by positivity)⟩

theorem law_wordCoeff (P : StreamParams) (y : Fin (2 ^ Hash.seedDeg P.Dstar)) :
    ((uniformBits P.w).law.map (wordCoeff P)) y = ((2 : ℝ≥0∞) ^ P.w)⁻¹ := by
  have hw : Hash.seedDeg P.Dstar = P.w := rfl
  rw [PMF.map_apply, tsum_eq_single y.val]
  · rw [if_pos, law_uniformBits, if_pos]
    · rw [← hw]; exact y.isLt
    · ext
      simp only [wordCoeff]
      exact (Nat.mod_eq_of_lt y.isLt).symm
  · intro x hx
    rw [law_uniformBits]
    by_cases hxw : x < 2 ^ P.w
    · rw [if_neg]
      intro hyx
      apply hx
      rw [hyx]
      simp only [wordCoeff]
      rw [hw]
      exact (Nat.mod_eq_of_lt hxw).symm
    · rw [if_neg hxw]
      simp

/-- A fresh row's seed is a uniform seed. -/
theorem law_seed (P : StreamParams) (ζ : Seed P) :
    ((newRow P).law.map (seedOfRow P)) ζ = ((Fintype.card (Seed P) : ℝ≥0∞))⁻¹ := by
  have h1 : (newRow P).law.map (seedOfRow P) =
      (sampleList (uniformBits P.w) (2 * P.s)).law.map
        (fun L => fun k : Fin (2 * P.s) => wordCoeff P (L.getD k 0)) := by
    rw [show newRow P = (sampleSeed P).bind fun z => BitProg.pure ⟨z, 0, 0⟩ from rfl,
      BitProg.law_bind, PMF.map_bind]
    simp only [BitProg.law_pure, PMF.pure_map]
    rw [show (fun a => PMF.pure (seedOfRow P ⟨a, 0, 0⟩)) =
      PMF.pure ∘ (fun L => fun k : Fin (2 * P.s) => wordCoeff P (L.getD k 0)) from rfl,
      PMF.bind_pure_comp]
    rfl
  rw [h1, law_sampleList_map]
  simp only [law_wordCoeff]
  rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin, Hash.card_radSeed]
  have hpow : ((2 : ℝ≥0∞) ^ P.w)⁻¹ ^ (2 * P.s) =
      (((2 ^ (2 * P.s * Hash.seedDeg P.Dstar) : ℕ) : ℝ≥0∞))⁻¹ := by
    rw [ENNReal.inv_pow, ← pow_mul, Nat.cast_pow, Nat.cast_ofNat,
      show P.w * (2 * P.s) = 2 * P.s * Hash.seedDeg P.Dstar by
        rw [show Hash.seedDeg P.Dstar = P.w from rfl]; ring, ENNReal.inv_pow]
  exact hpow

/-! ## B's guarantee for the bank instance -/

theorem unifD_nonneg (P : StreamParams) (ζ : Seed P) : 0 ≤ unifD P ζ := by
  unfold unifD
  positivity

theorem card_seed_pos (P : StreamParams) : 0 < Fintype.card (Seed P) := by
  rw [Hash.card_radSeed]
  positivity

theorem sum_unifD (P : StreamParams) : ∑ ζ, unifD P ζ = 1 := by
  unfold unifD
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have h : (Fintype.card (Seed P) : ℝ) ≠ 0 := by exact_mod_cast (card_seed_pos P).ne'
  field_simp

theorem ofReal_prod_unifD (P : StreamParams) {N : ℕ} (s : Fin N → Seed P) :
    ENNReal.ofReal (∏ ℓ, unifD P (s ℓ)) = ∏ _ℓ : Fin N, ((Fintype.card (Seed P) : ℝ≥0∞))⁻¹ := by
  rw [ENNReal.ofReal_prod_of_nonneg (fun ℓ _ => unifD_nonneg P (s ℓ))]
  refine Finset.prod_congr rfl fun ℓ _ => ?_
  have hpos : (0 : ℝ) < (Fintype.card (Seed P) : ℝ) := by exact_mod_cast card_seed_pos P
  rw [unifD, one_div, ENNReal.ofReal_inv_of_pos hpos, ENNReal.ofReal_natCast]

/-- B's guarantee for the bank instance, written for any parameter record equal to it. -/
theorem guarantee_of_eq (P : StreamParams) (hP : ParamsOK P) (A : AdaParams)
    (hA : A = adaAlg2Params P.m P.Jmax P.Rmax (P.aNum : ℝ) (P.bankXiReq : ℝ)) (ctrl : CoreCtrl (Seed P))
    (hctrl : ctrl.Valid A) (T : ℕ) :
    ∑ s : Fin A.N → Seed P, (∏ _ℓ : Fin A.N, ((Fintype.card (Seed P) : ℝ≥0∞))⁻¹) *
        (coreRun A ctrl s T).law.toOuterMeasure {o | coreFails A (unifD P) (P.aNum : ℝ) ctrl o} ≤
      ENNReal.ofReal ((P.betaB : ℝ) / 2) := by
  subst hA
  have hm := hP.one_le_m
  have ha0 : (0 : ℝ) < (P.aNum : ℝ) := by exact_mod_cast StreamParams.aNum_pos P
  have ha1 : (P.aNum : ℝ) < 1 / 10 := by
    have := StreamParams.aNum_lt_tenth P
    exact (Rat.cast_lt.2 this).trans_eq (by norm_num)
  have hξ0 : (0 : ℝ) < (P.bankXiReq : ℝ) := by exact_mod_cast StreamParams.bankXiReq_pos hm
  have hξ1 : (P.bankXiReq : ℝ) < 1 / 2 := by
    have := StreamParams.bankXiReq_lt_half hm
    exact (Rat.cast_lt.2 this).trans_eq (by norm_num)
  have hB := core_guarantee_det P.m P.Jmax P.Rmax ha0 ha1 hξ0 hξ1 (Seed P) (unifD P)
    (unifD_nonneg P) (sum_unifD P) ctrl hctrl T
  have hA0 : (0 : ℝ) ≤ ((adaAlg2Params P.m P.Jmax P.Rmax (P.aNum : ℝ) (P.bankXiReq : ℝ)).hA : ℝ) := by
    have : (0 : ℚ) ≤ (adaAlg2Params P.m P.Jmax P.Rmax (P.aNum : ℝ) (P.bankXiReq : ℝ)).hA := by
      unfold AdaParams.hA
      positivity
    exact_mod_cast this
  refine le_trans (Finset.sum_le_sum fun s _ => ?_) (hB.trans (le_of_eq ?_))
  · rw [← ofReal_prod_unifD P s]
    refine mul_le_mul_of_nonneg_left (MeasureTheory.measure_mono fun o ho => ?_) zero_le
    exact coreFails_mono _ _ (by linarith) ctrl o ho
  · congr 1
    rw [StreamParams.bankXiReq]
    push_cast
    ring

end CoreQCount

open Classical in
/-- **The B-side count** (Theorem 3.6 for one bank, as a count of bit strings). -/
theorem coreQ_count (P : StreamParams) (hP : ParamsOK P) (ctrl : CoreCtrl (Seed P))
    (hctrl : ctrl.Valid (bankAda P)) (T n : ℕ) (hn : (coreQ P ctrl T).depth ≤ n) :
    ∑ l ∈ TBitProg.lenFinset n,
        (if ∃ o rest, (coreQ P ctrl T).run l = some (o, rest) ∧
            coreFails (bankAda P) (unifD P) (P.aNum : ℝ) ctrl o then (1 : ℝ≥0∞) else 0) ≤
      ENNReal.ofReal ((P.betaB : ℝ) / 2) * 2 ^ n := by
  set F : List CoreOut → Prop := fun o => coreFails (bankAda P) (unifD P) (P.aNum : ℝ) ctrl o with hFdef
  set q := coreQ P ctrl T with hq
  -- the tape sum is `2^n` times the law
  have hsum := BitProg.sum_tapes_eq q hn (fun o => if F o then 1 else 0)
  rw [CoreQCount.sum_lenFinset]
  have hterm : ∀ ω : Fin n → Bool,
      (if ∃ o rest, q.run (List.ofFn ω) = some (o, rest) ∧ F o then (1 : ℝ≥0∞) else 0) =
        (q.run (List.ofFn ω)).elim 0 (fun r => if F r.1 then 1 else 0) := by
    intro ω
    cases h : q.run (List.ofFn ω) with
    | none => simp
    | some r =>
      obtain ⟨o, rest⟩ := r
      simp only [Option.elim]
      by_cases hF : F o
      · rw [if_pos ⟨o, rest, rfl, hF⟩, if_pos hF]
      · rw [if_neg (by rintro ⟨o', rest', h', hF'⟩; cases h'; exact hF hF'), if_neg hF]
  rw [Finset.sum_congr rfl fun ω _ => hterm ω, hsum, mul_comm]
  refine mul_le_mul_of_nonneg_right ?_ zero_le
  -- the law of the failure event
  have htoOuter : ∑' o, q.law o * (if F o then 1 else 0) = q.law.toOuterMeasure {o | F o} := by
    rw [PMF.toOuterMeasure_apply]
    refine tsum_congr fun o => ?_
    by_cases h : F o
    · rw [if_pos h, mul_one, Set.indicator_of_mem (show o ∈ {o | F o} from h)]
    · rw [if_neg h, mul_zero, Set.indicator_of_notMem (show o ∉ {o | F o} from h)]
  rw [htoOuter]
  -- the program: `N` fresh rows, their seeds, then the core
  have hq' : q = (sampleList (newRow P) (bankAda P).N).bind fun L =>
      coreRun (bankAda P) ctrl (fun ℓ => seedOfRow P (L.getD ℓ ⟨[], 0, 0⟩)) T := by
    have hfl := CoreQCount.sampleBlocks_map_flatten P (bankAda P).blockSizes
    rw [hq, coreQ]
    change _ = (sampleList (newRow P) (bankAda P).blockSizes.sum).bind _
    rw [← hfl, bp_bind_map]
    rfl
  rw [hq', BitProg.law_bind]
  rw [show ((sampleList (newRow P) (bankAda P).N).law.bind fun L =>
      (coreRun (bankAda P) ctrl (fun ℓ => seedOfRow P (L.getD ℓ ⟨[], 0, 0⟩)) T).law) =
      ((sampleList (newRow P) (bankAda P).N).law.map fun L =>
        fun ℓ : Fin (bankAda P).N => seedOfRow P (L.getD ℓ ⟨[], 0, 0⟩)).bind fun s =>
          (coreRun (bankAda P) ctrl s T).law from
      (PMF.bind_map (sampleList (newRow P) (bankAda P).N).law
        (fun L => fun ℓ : Fin (bankAda P).N => seedOfRow P (L.getD ℓ ⟨[], 0, 0⟩))
        (fun s => (coreRun (bankAda P) ctrl s T).law)).symm]
  rw [PMF.toOuterMeasure_bind_apply, tsum_fintype]
  simp only [CoreQCount.law_sampleList_map, CoreQCount.law_seed]
  exact CoreQCount.guarantee_of_eq P hP (bankAda P)
    (StreamParams.bankAdaParams_eq_dyadicExp hP.one_le_m) ctrl hctrl T

end F2e2e.C.Closure
