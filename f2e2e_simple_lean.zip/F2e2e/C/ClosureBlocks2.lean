import Mathlib
import F2e2e.C.ClosureCalls

/-!
# Theorem 6.4: the invariant through Step 2 and Step 3 (weakest preconditions of the controller code)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree`, Step 2 (L480–484) and Step 3 (L486–493), as
coded in `F2e2e/C/Alg/AlgMCode.lean` (`step2Code`, `step3DepthCode`, `step3LoopCode`, `step3Code`).

Each block has a pure lemma `jointInv_*` stated over variables (the data after the block given by field
equations), and a WP lemma walking the code and closing with the pure lemma.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Step 2 -/

/-- Step 2, pure form. -/
theorem jointInv_phys (hP : ParamsOK P) {c c' : CState} {o o' : OState} {g g' : Ghost}
    (h : JointInv P (.births P.H) c o g) (i : Fin P.n) (Δ : ℤ)
    (hbox : ‖((shadowOf P g).step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t ≤ P.m)
    (hc' : c' = { c with leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2) })
    (hb : o'.banks = mapFrom (Bank.mapRows ((RowOp.phys (i.val + 1) Δ).apply P)) 0 o.banks)
    (hl : g'.labels = g.labels) (hh : g'.hists = mapFrom (fun l => l ++ [RowOp.phys (i.val + 1) Δ]) 0 g.hists)
    (hcl : g'.calls = g.calls) (he : g'.events = g.events ++ [TreeEvent.phys (i.val + 1) Δ]) :
    JointInv P (.guards 0) c' o' g' := by
  obtain ⟨-, htp⟩ := treePart_phys hP h.tp i Δ hbox
  have hS : shadowOf P g' = (shadowOf P g).step P (.phys i Δ) := shadowOf_snoc P he (toTreeEv_phys i Δ)
  have hlen : g.hists.length = P.H := h.hists_len_H rfl
  have hnev := h.nev_succ ht (by simp [remEv])
  have hev : g'.events.length = g.events.length + 1 := by rw [he]; simp
  subst hc'
  refine ⟨?_, ?_, ?_, ?_, h.notFailed, ?_⟩
  · rw [hS, hev]; exact htp
  · rw [hS, hev, hh]; exact bankPart_phys hP i Δ h.tp.tree htp.tree hbox h.bp hlen hnev
  · exact countPart_phys hP (i.val + 1) Δ h.cp (by simp) hl hcl he rfl (fun _ => rfl)
  · exact (statePart_bankOpFrom h.sp 0 (RowOp.phys (i.val + 1) Δ)).congr hb hl hh hcl
  · rw [hS]
    have := h.time
    simp only [phIdle] at this ⊢
    simpa [Tree.TreeState.step] using this

/-- **Step 2** (`step2Code`): the physical update, from the end of Step 1 to the start of Step 3; the returned
bit is the fingerprint test of the update. -/
theorem wp_step2 (hP : ParamsOK P) {F : List CallRec} {c : CState} {o : OState} {g : Ghost}
    (h : JointInv P (.births P.H) c o g) (i : Fin P.n) (Δ : ℤ)
    (hbox : ‖((shadowOf P g).step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t ≤ P.m) :
    WP P F (step2Code P i.val Δ c)
      (fun r o' g' => JointInv P (.guards 0) r.1 o' g' ∧
        r.2 = (fpUpdate P o.fpSeed o.fpVal (i.val + 1) Δ == 0) ∧ o'.fpSeed = o.fpSeed ∧
        shadowOf P g' = (shadowOf P g).step P (.phys i Δ) ∧ r.1.t = c.t) o g := by
  obtain ⟨hrange, -⟩ := treePart_phys hP h.tp i Δ hbox
  unfold step2Code
  simp only [AlgM.bind_eq, AlgM.pure_eq]
  apply wp_fpStepM
  apply wp_bankOpFromM
  apply wp_noteM
  apply wp_pure
  rw [if_pos hrange]
  exact ⟨jointInv_phys hP h i Δ hbox ht rfl rfl rfl rfl rfl rfl, rfl, rfl,
    shadowOf_snoc P rfl (toTreeEv_phys i Δ), rfl⟩

/-! ## Step 3 -/

/-- Step 3 at depth `d`, omitted guard, pure form. -/
theorem jointInv_guard_zero (hP : ParamsOK P) {c : CState} {o : OState} {g g' : Ghost} {d : ℕ}
    (h : JointInv P (.guards d) c o g) (hd : d < P.H) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ))
    (ht : (shadowOf P g).t ≤ P.m) {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (hδ : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0)
    (hl : g'.labels = g.labels) (hh : g'.hists = g.hists) (hcl : g'.calls = g.calls)
    (he : g'.events = g.events ++ [TreeEvent.guard d (P.guardCoord d (c.t + 1)) 0]) :
    JointInv P (.guards (d + 1)) c o g' ∧ Frame (P := P) c o g c o g' := by
  have htime : (shadowOf P g).t = c.t + 1 := by simpa [phIdle] using h.time
  have hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar := guardCoord_lt P hd (by omega) (by omega)
  have hnev := h.nev_succ ht (by simp only [remEv]; omega)
  have hS : shadowOf P g' =
      (shadowOf P g).step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg 0 : ℚ) : ℝ)) :=
    shadowOf_snoc P he (toTreeEv_guard d _ 0 hg)
  have hev : g'.events.length = g.events.length + 1 := by rw [he]; simp
  have htp := treePart_guard_zero hP h.tp hd htime.symm hbox hnev hLd hδ hg
  refine ⟨⟨?_, ?_, ?_, ?_, h.notFailed, ?_⟩, rfl, ?_, ?_, rfl, rfl⟩
  · rw [hS, hev]; exact htp
  · rw [hS, hev, hh]; exact bankPart_guard_zero h.tp.tree h.bp hd _
  · exact countPart_guard hP _ 0 h.cp hd hg hl hcl he rfl (fun _ => rfl)
  · exact h.sp.congr rfl hl hh hcl
  · rw [hS]; simpa [phIdle, Tree.TreeState.step] using htime
  · rw [hS]; rfl
  · rw [hS]; rfl

/-- Replacing the cache of a stored learner keeps every lifetime counter (stated over a variable cache, so that
no unification ever compares a computed cache with a stored one). -/
theorem getD_setAt_cache_jUsed (L : List Learner) {d : ℕ} {Ld : Learner} (hLd : L[d]? = some Ld) (x : ℤ)
    (j : ℕ) : ((setAt { Ld with cache := x } d L).getD j dfltLearner).jUsed = (L.getD j dfltLearner).jUsed := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_setAt]
  by_cases hj : j = d ∧ j < L.length
  · rw [if_pos hj]
    obtain ⟨rfl, -⟩ := hj
    rw [hLd]
    rfl
  · rw [if_neg hj]

/-- Step 3 at depth `d`, injected guard, pure form. -/
theorem jointInv_guard (hP : ParamsOK P) {c c' : CState} {o o' : OState} {g g' : Ghost} {d : ℕ}
    (h : JointInv P (.guards d) c o g) (hd : d < P.H) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ))
    (ht : (shadowOf P g).t ≤ P.m) {Ld : Learner} (hLd : c.learners[d]? = some Ld) {δ : ℤ}
    (hδdef : δ = guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) (hδ : δ ≠ 0)
    (hc' : c' = { c with
      learners := setAt { Ld with cache := roundMant P.eHP (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2) } d
        c.learners,
      leaf := roundMant P.eHleaf (gridVal P.eHleaf c.leaf + gridVal P.eHg δ ^ 2) })
    (hb : o'.banks = mapFrom (Bank.mapRows ((RowOp.guardXY (P.guardCoord d (c.t + 1)) δ).apply P)) (d + 1)
      (modifyAt (Bank.mapRows ((RowOp.guardY (P.guardCoord d (c.t + 1)) δ).apply P)) d o.banks))
    (hl : g'.labels = g.labels)
    (hh : g'.hists = mapFrom (fun l => l ++ [RowOp.guardXY (P.guardCoord d (c.t + 1)) δ]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.guardY (P.guardCoord d (c.t + 1)) δ]) d g.hists))
    (hcl : g'.calls = g.calls) (he : g'.events = g.events ++ [TreeEvent.guard d (P.guardCoord d (c.t + 1)) δ])
    (hfp : o'.fpSeed = o.fpSeed ∧ o'.fpVal = o.fpVal) :
    JointInv P (.guards (d + 1)) c' o' g' ∧ Frame (P := P) c o g c' o' g' := by
  subst hδdef
  have htime : (shadowOf P g).t = c.t + 1 := by simpa [phIdle] using h.time
  have hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar := guardCoord_lt P hd (by omega) (by omega)
  have hlen : g.hists.length = P.H := h.hists_len_H rfl
  have hnev := h.nev_succ ht (by simp only [remEv]; omega)
  obtain ⟨-, -, htp⟩ := treePart_guard hP h.tp hd htime.symm hbox hnev hLd hδ hg
  have hS : shadowOf P g' = (shadowOf P g).step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩
      ((gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) : ℚ) : ℝ)) :=
    shadowOf_snoc P he (toTreeEv_guard d _ _ hg)
  have hev : g'.events.length = g.events.length + 1 := by rw [he]; simp
  have hgc : 1 ≤ P.guardCoord d (c.t + 1) := by
    have := Tree.guardCoord_range P hd (show 1 ≤ c.t + 1 by omega) (show c.t + 1 ≤ P.m by omega)
    omega
  subst hc'
  refine ⟨⟨?_, ?_, ?_, ?_, h.notFailed, ?_⟩, rfl, ?_, ?_, hfp.1, hfp.2⟩
  · rw [hS, hev]; exact htp
  · rw [hS, hev, hh]
    exact bankPart_guard hP (P.guardCoord d (c.t + 1)) hgc hg _ h.tp.tree htp.tree hbox h.bp hd hlen hnev
  · exact countPart_guard hP _ _ h.cp hd hg hl hcl he (length_setAt _ _ _)
      (fun j => getD_setAt_cache_jUsed c.learners hLd _ j)
  · exact (statePart_bankOpFrom (statePart_bankOp h.sp d _) (d + 1) _).congr hb hl hh hcl
  · rw [hS]; simpa [phIdle, Tree.TreeState.step] using htime
  · rw [hS]; rfl
  · rw [hS]; rfl

/-- **Step 3 at depth `d`** (`step3DepthCode`). -/
theorem wp_step3Depth (hP : ParamsOK P) {F : List CallRec} {c : CState} {o : OState} {g : Ghost} {d : ℕ}
    (h : JointInv P (.guards d) c o g) (hd : d < P.H) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ))
    (ht : (shadowOf P g).t ≤ P.m) :
    WP P F (step3DepthCode P (c.t + 1) c d)
      (fun c' o' g' => JointInv P (.guards (d + 1)) c' o' g' ∧ Frame (P := P) c o g c' o' g') o g := by
  have htime : (shadowOf P g).t = c.t + 1 := by simpa [phIdle] using h.time
  have hLd := h.tp.learner_some (d := d) (by simpa [Tree.Phase.live] using hd)
  generalize hLdv : c.learners.getD d dfltLearner = Ld at hLd
  have hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar := guardCoord_lt P hd (by omega) (by omega)
  have hnev := h.nev_succ ht (by simp only [remEv]; omega)
  unfold step3DepthCode
  simp only [hLd]
  generalize hδv : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = δ
  by_cases hδ : δ = 0
  · subst hδ
    simp only [if_true, AlgM.bind_eq, AlgM.pure_eq]
    apply wp_noteM
    apply wp_pure
    exact jointInv_guard_zero hP h hd hbox ht hLd hδv rfl rfl rfl rfl
  · simp only [hδ, if_false, AlgM.bind_eq, AlgM.pure_eq]
    apply wp_bankOpM
    apply wp_bankOpFromM
    apply wp_noteM
    apply wp_pure
    have hδ' : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) ≠ 0 := by rw [hδv]; exact hδ
    obtain ⟨hr1, hr2, -⟩ := treePart_guard hP h.tp hd htime.symm hbox hnev hLd hδ' hg
    rw [hδv] at hr1 hr2
    rw [hr1, hr2, Bool.and_self, if_pos rfl]
    exact jointInv_guard hP h hd hbox ht hLd hδv.symm hδ rfl rfl rfl rfl rfl rfl ⟨rfl, rfl⟩

/-- **Step 3 for the depths `D, …, H − 1`** (`step3LoopCode`). -/
theorem wp_step3Loop (hP : ParamsOK P) {F : List CallRec} (k : ℕ) :
    ∀ (D : ℕ) (c : CState) (o : OState) (g : Ghost), D + k = P.H →
      JointInv P (.guards D) c o g → ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ) → (shadowOf P g).t ≤ P.m →
      WP P F (step3LoopCode P (c.t + 1) (List.range' D k) c)
        (fun c' o' g' => JointInv P (.guards P.H) c' o' g' ∧ Frame (P := P) c o g c' o' g') o g := by
  induction k with
  | zero =>
    intro D c o g hk h _ _
    have hD : P.H = D := by omega
    rw [List.range'_zero]
    apply wp_pure
    rw [hD]
    exact ⟨h, frame_refl c o g⟩
  | succ k ih =>
    intro D c o g hk h hbox ht
    rw [List.range'_succ]
    show WP P F (if c.failed = true then AlgM.pure c else
      (step3DepthCode P (c.t + 1) c D).bind fun c' => step3LoopCode P (c.t + 1) (List.range' (D + 1) k) c') _ o g
    rw [h.notFailed]
    simp only [Bool.false_eq_true, if_false]
    apply wp_bind
    refine wp_mono (wp_step3Depth hP h (by omega) hbox ht) ?_
    rintro c' o' g' ⟨h', hfr⟩
    have hc't : c'.t + 1 = c.t + 1 := by rw [hfr.1]
    rw [← hc't]
    refine wp_mono (ih (D + 1) c' o' g' (by omega) h' (by rw [hfr.2.1]; exact hbox)
      (by rw [hfr.2.2.1]; exact ht)) ?_
    rintro c'' o'' g'' ⟨h'', hfr'⟩
    exact ⟨h'', frame_trans hfr hfr'⟩

/-- **Step 3** (`step3Code`): from the start to the end of Step 3. -/
theorem wp_step3 (hP : ParamsOK P) {F : List CallRec} {c : CState} {o : OState} {g : Ghost}
    (h : JointInv P (.guards 0) c o g) (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t ≤ P.m) :
    WP P F (step3Code P c)
      (fun c' o' g' => JointInv P (.guards P.H) c' o' g' ∧ Frame (P := P) c o g c' o' g') o g := by
  unfold step3Code
  rw [List.range_eq_range']
  exact wp_step3Loop hP P.H 0 c o g (by omega) h hbox ht

end F2e2e.C.Closure
