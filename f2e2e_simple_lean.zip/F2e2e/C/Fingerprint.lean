import F2e2e.C.FingerprintAlg

/-!
# Lemma `R:lem:zero-fingerprint`: the homomorphic zero fingerprint of the Theorem C algorithm

Paper: `parts/partII.tex` Algorithm `R:alg:zero-fingerprint` (L216–231) and Lemma
`R:lem:zero-fingerprint` (alias `R:lem:zero-fingerprint-coupling`, L233–286); the failure budget
`β₀/8` of Theorem 6.4 (`parts/partIII.tex` L1279–1283).

For C-ALG's algorithm `theAlg` (`F2e2e/C/Top/AlgInstance.lean`) and its canonical run
(`F2e2e/C/Top/Run.lean`) against a deterministic adversary `adv` with the tapes `tapes`
(`us = advUpdate adv (theAlg.outs P adv tapes)` the updates, `seqVec us t = x^{(t+1)}` the stream
vector after round `t`):

* `fpZeroTest P s u`: the zero test of Algorithm `R:alg:zero-fingerprint`, Line 6, for the update
  `u` of the round, computed from the state `s` before the round (Step 1 never touches the
  fingerprint registers, so this is Step 2's test bit);
* `FpFalseZero P adv tapes`: some round `t < m`, within the box promise after the rounds
  `0, …, t`, from a non-failed state, has `x^{(t+1)} ≠ 0` but the zero test reports zero;
* **`card_fpFalseZero_le`** (part (3), with the paper's parameters): at most a `β₀/8` fraction of
  the tape tuples are in `FpFalseZero` (`card_fpFalseZero_le_two`: `2 β₀/1000`, eq.
  `R:eq:fingerprint-collision-prob`: `m n/q + 2^{-(betaExp+10)} ≤ 2β₀/1000`);
* deterministic facts on the canonical run (parts (1), (2) and the floor `‖x^{(t+1)}‖ ≥ 1` of the
  rounds entering Steps 3–4): `fpSeed_run_eq`, `fpVal_run_eq`, `fpVal_run_succ_eq` (the register
  fingerprints the stream vector), `fpZeroTest_run_eq` (the test is the fingerprint test of
  `x^{(t+1)}`), `fpZeroTest_of_seqVec_eq_zero` (completeness), `seqVec_eq_zero_of_fpZeroTest`
  (soundness off `FpFalseZero`), `fpZeroTest_iff_seqVec_eq_zero`, `seqVec_ne_zero_of_fpZeroTest_false`
  (floor `1 ≤ F₂(x^{(t+1)})`).

The proof is the stopping-time coupling of L267–285 (`F2e2e/C/FingerprintCoupling.lean`), the
tape counting of `F2e2e/C/FingerprintCount.lean` and its instantiation for `theAlg`
(`F2e2e/C/FingerprintAlg.lean`).
-/

namespace F2e2e.C

open F2e2e.C.Alg F2e2e.C.Top F2e2e.C.FP F2e2e.Discrete
open scoped ENNReal

/-- The zero test (Algorithm `R:alg:zero-fingerprint`, Line 6) of the round processing the update
`u = (i, Δ)` (0-based coordinate `i`), computed from the state `s` before the round:
`F_zero + (Δ mod q) r_fp^{i+1} ≡ 0 (mod q)`. -/
def fpZeroTest (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) : Bool :=
  fpUpdate P s.fpSeed s.fpVal (u.1.val + 1) u.2 == 0

/-- **The fingerprint failure event** on the canonical run of `theAlg`: some round `t < m`, within
the box promise after the rounds `0, …, t`, from a non-failed state, has `x^{(t+1)} ≠ 0` but the
zero test reports zero. -/
def FpFalseZero (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) : Prop :=
  ∃ t < P.m, BoxUpTo P.U adv (theAlg.outs P adv tapes) t ∧
    ∃ c : Alg.State × List ℚ, theAlg.run P adv tapes t = some c ∧ c.1.failed = false ∧
      seqVec (advUpdate adv (theAlg.outs P adv tapes)) t ≠ 0 ∧ fpZeroTest P c.1 (adv c.2) = true

theorem fpZeroTest_eq_true_iff (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) :
    fpZeroTest P s u = true ↔ fpUpdate P s.fpSeed s.fpVal (u.1.val + 1) u.2 = 0 := by
  unfold fpZeroTest
  exact beq_iff_eq

theorem fpZeroTest_eq_fpBitOf (P : StreamParams) (s : Alg.State) (u : Fin P.n × ℤ) :
    fpZeroTest P s u = fpBitOf (fpRoundAlg P) s u := by
  unfold fpZeroTest fpBitOf
  rw [Bool.eq_iff_iff, beq_iff_eq, decide_eq_true_iff]
  exact fpUpdate_eq_zero_iff P _ _ u

theorem fpFalseZero_iff (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) :
    FpFalseZero P adv tapes ↔ FalseZeroRun (fpRoundAlg P) adv tapes := by
  unfold FpFalseZero FalseZeroRun
  simp only [fpZeroTest_eq_fpBitOf]
  rfl

/-! ### Part (3): the failure count -/

/-- **Lemma `R:lem:zero-fingerprint` (3)**, sharp form: at most a `2 β₀/1000` fraction of the
tape tuples have a false zero (eq. `R:eq:fingerprint-collision-prob`). -/
theorem card_fpFalseZero_le_two (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) :
    (({tapes | FpFalseZero P adv tapes} :
        Set (Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool)).ncard : ℝ) ≤
      2 * ((1 / 2 : ℝ) ^ P.betaExp / 1000) * 2 ^ ((P.m + 1) * theAlg.tapeLen P) := by
  have hset : ({tapes | FpFalseZero P adv tapes} :
      Set (Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool)) =
      {tapes | FalseZeroRun (fpRoundAlg P) adv tapes} := by
    ext tapes
    exact fpFalseZero_iff P adv tapes
  rw [hset]
  have h := card_falseZeroRun_theAlg_le P hP adv
  set N := (P.m + 1) * theAlg.tapeLen P with hN
  have hq0 : (P.q : ℝ≥0∞) ≠ 0 := by exact_mod_cast (q_pos P).ne'
  have ha : (P.m * P.n : ℝ≥0∞) / P.q ≠ ⊤ :=
    ENNReal.div_ne_top (ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) (ENNReal.natCast_ne_top _))
      hq0
  have hc : (2⁻¹ : ℝ≥0∞) ^ P.seedTrials ≠ ⊤ :=
    ENNReal.pow_ne_top (ENNReal.inv_ne_top.mpr two_ne_zero)
  have h2 : (2 : ℝ≥0∞) ^ N ≠ ⊤ := ENNReal.pow_ne_top ENNReal.ofNat_ne_top
  have hfin : (2 : ℝ≥0∞) ^ N * ((P.m * P.n : ℝ≥0∞) / P.q + 2⁻¹ ^ P.seedTrials) ≠ ⊤ :=
    ENNReal.mul_ne_top h2 (ENNReal.add_ne_top.mpr ⟨ha, hc⟩)
  have hreal := ENNReal.toReal_mono hfin h
  rw [ENNReal.toReal_natCast] at hreal
  have hval : ((2 : ℝ≥0∞) ^ N * ((P.m * P.n : ℝ≥0∞) / P.q + 2⁻¹ ^ P.seedTrials)).toReal =
      2 ^ N * (((P.m * P.n : ℕ) : ℝ) / P.q + (1 / 2 : ℝ) ^ P.seedTrials) := by
    rw [ENNReal.toReal_mul, ENNReal.toReal_add ha hc, ENNReal.toReal_div, ENNReal.toReal_pow,
      ENNReal.toReal_pow, ENNReal.toReal_inv, ENNReal.toReal_mul]
    simp [one_div]
  rw [hval] at hreal
  calc _ ≤ 2 ^ N * (((P.m * P.n : ℕ) : ℝ) / P.q + (1 / 2 : ℝ) ^ P.seedTrials) := hreal
    _ ≤ 2 ^ N * (2 * ((1 / 2 : ℝ) ^ P.betaExp / 1000)) :=
        mul_le_mul_of_nonneg_left (fp_budget P hP.one_le_n hP.one_le_m) (by positivity)
    _ = 2 * ((1 / 2 : ℝ) ^ P.betaExp / 1000) * 2 ^ N := by ring

/-- **Lemma `R:lem:zero-fingerprint` (3)** with the budget of Theorem 6.4 (`parts/partIII.tex`
L1279–1283): at most a `β₀/8` fraction of the tape tuples have a false zero. -/
theorem card_fpFalseZero_le (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) :
    (({tapes | FpFalseZero P adv tapes} :
        Set (Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool)).ncard : ℝ) ≤
      (1 / 2 : ℝ) ^ P.betaExp / 8 * 2 ^ ((P.m + 1) * theAlg.tapeLen P) :=
  (card_fpFalseZero_le_two P hP adv).trans
    (mul_le_mul_of_nonneg_right (two_div_thousand_le_eighth P.betaExp) (by positivity))

/-- The failure count in the form of `F2e2e/C/Final.lean` (`β₀ = P.beta0`, tape length
`tapeBits P`). -/
theorem card_fpFalseZero_le_beta0 (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) :
    (({tapes | FpFalseZero P adv tapes} : Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      (P.beta0 : ℝ) / 8 * 2 ^ ((P.m + 1) * tapeBits P) := by
  have h := card_fpFalseZero_le P hP adv
  have hb : ((P.beta0 : ℚ) : ℝ) = (1 / 2 : ℝ) ^ P.betaExp := by
    simp [StreamParams.beta0]
  rw [hb]
  exact h

/-- `FpFalseZero` with the zero test written out as `fpUpdate … = 0`. -/
theorem fpFalseZero_iff_fpUpdate (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) :
    FpFalseZero P adv tapes ↔ ∃ t < P.m, BoxUpTo P.U adv (theAlg.outs P adv tapes) t ∧
      ∃ c : Alg.State × List ℚ, theAlg.run P adv tapes t = some c ∧ c.1.failed = false ∧
        seqVec (advUpdate adv (theAlg.outs P adv tapes)) t ≠ 0 ∧
        fpUpdate P c.1.fpSeed c.1.fpVal ((adv c.2).1.val + 1) (adv c.2).2 = 0 := by
  unfold FpFalseZero
  simp only [fpZeroTest_eq_true_iff]

/-! ### Parts (1), (2) and the floor: deterministic facts on the canonical run -/

section Det

variable (P : StreamParams) (adv : StreamAdversary P.n)
  (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool)

/-- **Part (1)**, the seed: it is the seed of the initial state. -/
theorem fpSeed_run_eq {t : ℕ} {c c0 : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes t = some c) (hc0 : theAlg.run P adv tapes 0 = some c0) :
    c.1.fpSeed = c0.1.fpSeed :=
  (theAlg_run_fp_inv P adv tapes hc hc0).1

/-- **Part (1)**, the register (eq. `R:eq:fingerprint-recurrence`): in a non-failed state before
round `t`, `F_zero ≡ ∑_j x^{(t)}_j r_fp^{j+1} (mod q)`, `x^{(t)}` the stream vector of the updates
of the rounds `0, …, t-1`. -/
theorem fpVal_run_eq {t : ℕ} {c : Alg.State × List ℚ} (hc : theAlg.run P adv tapes t = some c)
    (hf : c.1.failed = false) :
    ((c.1.fpVal : ℕ) : ZMod P.q) = ∑ j : Fin P.n,
      (((∑ s ∈ Finset.range t, if (advUpdate adv (theAlg.outs P adv tapes) s).1 = j then
          (advUpdate adv (theAlg.outs P adv tapes) s).2 else 0 : ℤ)) : ZMod P.q) *
        ((c.1.fpSeed : ℕ) : ZMod P.q) ^ (j.val + 1) := by
  obtain ⟨c0, hc0⟩ := run_zero_of_run hc
  obtain ⟨h1, h2⟩ := theAlg_run_fp_inv P adv tapes hc hc0
  have hvec : ∀ j, vecBefore adv c.2 j = ∑ s ∈ Finset.range t,
      if (advUpdate adv (theAlg.outs P adv tapes) s).1 = j then
        (advUpdate adv (theAlg.outs P adv tapes) s).2 else 0 := by
    intro j
    unfold vecBefore
    rw [run_length hc]
    refine Finset.sum_congr rfl fun s hs => ?_
    rw [advUpdate_eq_adv_take hc (Finset.mem_range.mp hs).le]
  rw [h2 hf, h1]
  unfold fpEval
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [hvec j]

/-- **Part (1)** after round `t`: in a non-failed state after round `t`, the register is the
fingerprint `∑_j x^{(t+1)}_j r_fp^{j+1}` of the stream vector `x^{(t+1)} = seqVec us t`. -/
theorem fpVal_run_succ_eq {t : ℕ} {c : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes (t + 1) = some c) (hf : c.1.failed = false) :
    ((c.1.fpVal : ℕ) : ZMod P.q) = ∑ j : Fin P.n,
      ((seqVec (advUpdate adv (theAlg.outs P adv tapes)) t j : ℤ) : ZMod P.q) *
        ((c.1.fpSeed : ℕ) : ZMod P.q) ^ (j.val + 1) :=
  fpVal_run_eq P adv tapes hc hf

/-- The zero test of a non-failed round `t` of the canonical run is the fingerprint test of the
stream vector `x^{(t+1)}` after the round's update. -/
theorem fpZeroTest_run_eq {t : ℕ} {c : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes t = some c) (hf : c.1.failed = false) :
    fpZeroTest P c.1 (adv c.2) = decide (∑ j : Fin P.n,
      ((seqVec (advUpdate adv (theAlg.outs P adv tapes)) t j : ℤ) : ZMod P.q) *
        ((c.1.fpSeed : ℕ) : ZMod P.q) ^ (j.val + 1) = 0) := by
  rw [fpZeroTest_eq_fpBitOf, fpBitOf_theAlg_run P adv tapes hc hf]
  have hv : seqVec (advUpdate adv (theAlg.outs P adv tapes)) t = vecOf adv c.2 := by
    rw [seqVec_eq_vecOf hc le_rfl, List.take_of_length_le (le_of_eq (run_length hc))]
  rw [hv]
  rfl

/-- **Part (2), completeness** (deterministic): on a non-failed round with `x^{(t+1)} = 0` the
zero test reports zero. -/
theorem fpZeroTest_of_seqVec_eq_zero {t : ℕ} {c : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes t = some c) (hf : c.1.failed = false)
    (h0 : seqVec (advUpdate adv (theAlg.outs P adv tapes)) t = 0) :
    fpZeroTest P c.1 (adv c.2) = true := by
  rw [fpZeroTest_run_eq P adv tapes hc hf, h0]
  simp

/-- **Soundness off the failure event**: within the box promise, a non-failed round `t < m` whose
zero test reports zero has `x^{(t+1)} = 0`, unless `FpFalseZero`. -/
theorem seqVec_eq_zero_of_fpZeroTest (hgood : ¬ FpFalseZero P adv tapes) {t : ℕ} (ht : t < P.m)
    (hbox : BoxUpTo P.U adv (theAlg.outs P adv tapes) t) {c : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes t = some c) (hf : c.1.failed = false)
    (hz : fpZeroTest P c.1 (adv c.2) = true) :
    seqVec (advUpdate adv (theAlg.outs P adv tapes)) t = 0 := by
  by_contra hne
  exact hgood ⟨t, ht, hbox, c, hc, hf, hne, hz⟩

/-- **Exactness of the zero test off the failure event** (Lemma `R:lem:zero-fingerprint` (2)–(3)):
within the box promise, on a non-failed round `t < m`, the zero test reports zero iff
`x^{(t+1)} = 0`. -/
theorem fpZeroTest_iff_seqVec_eq_zero (hgood : ¬ FpFalseZero P adv tapes) {t : ℕ}
    (ht : t < P.m) (hbox : BoxUpTo P.U adv (theAlg.outs P adv tapes) t)
    {c : Alg.State × List ℚ} (hc : theAlg.run P adv tapes t = some c)
    (hf : c.1.failed = false) :
    fpZeroTest P c.1 (adv c.2) = true ↔ seqVec (advUpdate adv (theAlg.outs P adv tapes)) t = 0 :=
  ⟨seqVec_eq_zero_of_fpZeroTest P adv tapes hgood ht hbox hc hf,
    fpZeroTest_of_seqVec_eq_zero P adv tapes hc hf⟩

end Det

/-- A nonzero integer vector has `F₂ ≥ 1`. -/
theorem one_le_F2_of_ne_zero {n : ℕ} {x : Fin n → ℤ} (hx : x ≠ 0) : 1 ≤ F2 x := by
  obtain ⟨j, hj⟩ := Function.ne_iff.mp hx
  have hj' : x j ≠ 0 := hj
  have h1 : (1 : ℝ) ≤ ((x j : ℤ) : ℝ) ^ 2 := by
    have : (1 : ℤ) ≤ (x j) ^ 2 := (one_le_sq_iff_one_le_abs _).mpr (Int.one_le_abs hj')
    exact_mod_cast this
  unfold F2
  calc (1 : ℝ) ≤ ((x j : ℤ) : ℝ) ^ 2 := h1
    _ ≤ ∑ i, ((x i : ℤ) : ℝ) ^ 2 :=
      Finset.single_le_sum (f := fun i => ((x i : ℤ) : ℝ) ^ 2) (fun i _ => sq_nonneg _)
        (Finset.mem_univ j)

/-- **The floor of the rounds entering Steps 3–4** (deterministic): on a non-failed round whose
zero test reports nonzero, `x^{(t+1)} ≠ 0`, hence `F₂(x^{(t+1)}) ≥ 1`. -/
theorem seqVec_ne_zero_of_fpZeroTest_false (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (theAlg.tapeLen P) → Bool) {t : ℕ} {c : Alg.State × List ℚ}
    (hc : theAlg.run P adv tapes t = some c) (hf : c.1.failed = false)
    (hz : fpZeroTest P c.1 (adv c.2) = false) :
    seqVec (advUpdate adv (theAlg.outs P adv tapes)) t ≠ 0 ∧
      1 ≤ F2 (seqVec (advUpdate adv (theAlg.outs P adv tapes)) t) := by
  have hne : seqVec (advUpdate adv (theAlg.outs P adv tapes)) t ≠ 0 := fun h0 => by
    rw [fpZeroTest_of_seqVec_eq_zero P adv tapes hc hf h0] at hz
    exact Bool.noConfusion hz
  exact ⟨hne, one_le_F2_of_ne_zero hne⟩

end F2e2e.C
