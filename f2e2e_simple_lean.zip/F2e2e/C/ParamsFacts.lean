import F2e2e.C.ParamsDefs
import F2e2e.C.ParamsAux

/-!
# Theorem (C) parameters: facts of Definitions 1.5 and 1.6

* standing assumptions `StreamParams.Valid` (`n, m, U ≥ 1`, `ε₀, β₀ ≤ 1/16`), implied by the hypotheses of
  `Theorem_C` (`mkStreamParams_valid`);
* Definition 1.5 (partII.tex L154–164): `ε/2 < ε₀ ≤ ε`, `β/2 < β₀ ≤ β` for the real `ε, β`
  (`half_lt_eps0`, `eps0_le`, …), `ℒ = ⌈log₂(2^100 (n+2)(m+2)(U+2)/(ε₀β₀))⌉` (`calL_eq_ceil_logb`),
  `Λ ≤ ℒ < Λ + 3` with the Spec's `masterLambda` (`masterLambda_le_calL`, `calL_lt_masterLambda_add_three`),
  `Λ > 100` (`hundred_lt_masterLambda`), `ℒ > 100`;
* Definition 1.6 (L166–194): the interval/characterization of every parameter (`m ≤ 2^{H-1}`, `m(H+1) < T`,
  `η ∈ (ε₀/(2^21(H+1)^2), ε₀/(2^20(H+1)^2)]`, `γ ∈ (1/(16√T), 1/(8√T)]`, `Tγ^2 ≤ 1/64`, `B = 16/γ ∈ [128√T, 256√T)`,
  `𝒰_d ∈ [2V_d^2, 4V_d^2)`, `𝒰_* = max_{d<H} 𝒰_d`, `ν = γη2^{-H-20}`, `E_min = 2^{-8}η^2ν^2`,
  `2^{K_epoch} = 2^20 𝒰_* B^{2H}/(η^2ν^2)`, `K_0 = ⌈128/η^2⌉`, …), the faithfulness lemmas `*_eq_ceil_logb`
  (our closed forms equal the paper's `⌈log₂ ·⌉` expressions), eq. `R:eq:param-s-bound`
  (`two_mul_s_div_four_pow_le`), and the downstream budget facts (`eight_mul_H_add_one_mul_eta_lt`,
  `failure_budget`, guard coordinates).
-/

namespace F2e2e

namespace StreamParams

open ParamsAux

/-! ## Standing assumptions -/

/-- The standing assumptions of Theorem (C) on the public parameters: `n, m, U ≥ 1` and
`⌈log₂ ε⁻¹⌉, ⌈log₂ β⁻¹⌉ ≥ 4` (i.e. `ε₀, β₀ ≤ 1/16`, which holds for `ε, β < 1/10`). -/
structure Valid (P : StreamParams) : Prop where
  one_le_n : 1 ≤ P.n
  one_le_m : 1 ≤ P.m
  one_le_U : 1 ≤ P.U
  four_le_epsExp : 4 ≤ P.epsExp
  four_le_betaExp : 4 ≤ P.betaExp

@[simp] theorem mkStreamParams_n (n m U : ℕ) (ε β : ℝ) : (mkStreamParams n m U ε β).n = n := rfl
@[simp] theorem mkStreamParams_m (n m U : ℕ) (ε β : ℝ) : (mkStreamParams n m U ε β).m = m := rfl
@[simp] theorem mkStreamParams_U (n m U : ℕ) (ε β : ℝ) : (mkStreamParams n m U ε β).U = U := rfl
@[simp] theorem mkStreamParams_epsExp (n m U : ℕ) (ε β : ℝ) :
    (mkStreamParams n m U ε β).epsExp = dyadicExp ε := rfl
@[simp] theorem mkStreamParams_betaExp (n m U : ℕ) (ε β : ℝ) :
    (mkStreamParams n m U ε β).betaExp = dyadicExp β := rfl

/-- The hypotheses of `Theorem_C` imply the standing assumptions. -/
theorem mkStreamParams_valid {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10) :
    (mkStreamParams n m U ε β).Valid :=
  ⟨hn, hm, hU, four_le_dyadicExp hε0 hε1, four_le_dyadicExp hβ0 hβ1⟩

/-! ## Definition 1.5: `ε₀`, `β₀`, `ℒ`, `Λ` -/

theorem eps0_pos (P : StreamParams) : 0 < P.eps0 := half_pow_pos _

theorem beta0_pos (P : StreamParams) : 0 < P.beta0 := half_pow_pos _

theorem eps0_le_one (P : StreamParams) : P.eps0 ≤ 1 := half_pow_le_one _

theorem beta0_le_one (P : StreamParams) : P.beta0 ≤ 1 := half_pow_le_one _

/-- `ε₀ ≤ 1/16` under the standing assumptions. -/
theorem eps0_le_sixteenth {P : StreamParams} (h : 4 ≤ P.epsExp) : P.eps0 ≤ 1 / 16 := by
  unfold eps0
  calc (1 / 2 : ℚ) ^ P.epsExp ≤ (1 / 2) ^ 4 := half_pow_antitone h
    _ = 1 / 16 := by norm_num

/-- `β₀ ≤ 1/16` under the standing assumptions. -/
theorem beta0_le_sixteenth {P : StreamParams} (h : 4 ≤ P.betaExp) : P.beta0 ≤ 1 / 16 := by
  unfold beta0
  calc (1 / 2 : ℚ) ^ P.betaExp ≤ (1 / 2) ^ 4 := half_pow_antitone h
    _ = 1 / 16 := by norm_num

/-- `ε₀ = dyadicDown ε` whenever `epsExp = ⌈log₂ ε⁻¹⌉`. -/
theorem eps0_cast_eq {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) :
    (P.eps0 : ℝ) = dyadicDown ε := by
  simp [eps0, dyadicDown, h]

/-- `β₀ = dyadicDown β` whenever `betaExp = ⌈log₂ β⁻¹⌉`. -/
theorem beta0_cast_eq {P : StreamParams} {β : ℝ} (h : P.betaExp = dyadicExp β) :
    (P.beta0 : ℝ) = dyadicDown β := by
  simp [beta0, dyadicDown, h]

/-- `ε₀ ≤ ε` (Def 1.5, L163). -/
theorem eps0_le {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) (hε : 0 < ε) :
    (P.eps0 : ℝ) ≤ ε := by
  rw [eps0_cast_eq h]; exact dyadicDown_le hε

/-- `ε/2 < ε₀` (Def 1.5, L163). -/
theorem half_lt_eps0 {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) (hε0 : 0 < ε)
    (hε1 : ε < 1) : ε / 2 < (P.eps0 : ℝ) := by
  rw [eps0_cast_eq h]; exact half_lt_dyadicDown hε0 hε1

/-- `β₀ ≤ β` (Def 1.5, L163). -/
theorem beta0_le {P : StreamParams} {β : ℝ} (h : P.betaExp = dyadicExp β) (hβ : 0 < β) :
    (P.beta0 : ℝ) ≤ β := by
  rw [beta0_cast_eq h]; exact dyadicDown_le hβ

/-- `β/2 < β₀` (Def 1.5, L163). -/
theorem half_lt_beta0 {P : StreamParams} {β : ℝ} (h : P.betaExp = dyadicExp β) (hβ0 : 0 < β)
    (hβ1 : β < 1) : β / 2 < (P.beta0 : ℝ) := by
  rw [beta0_cast_eq h]; exact half_lt_dyadicDown hβ0 hβ1

/-- Faithfulness of `epsExp` (for `P = mkStreamParams …`): `epsExp = ⌈log₂(1/ε)⌉` (eq. `R:eq:dyadic-eps-beta`). -/
theorem epsExp_eq_ceil_logb {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) (hε0 : 0 < ε)
    (hε1 : ε ≤ 1) : (P.epsExp : ℤ) = ⌈Real.logb 2 ε⁻¹⌉ := by
  rw [h]; exact dyadicExp_eq_ceil_logb hε0 hε1

/-- Faithfulness of `betaExp`: `betaExp = ⌈log₂(1/β)⌉` (eq. `R:eq:dyadic-eps-beta`). -/
theorem betaExp_eq_ceil_logb {P : StreamParams} {β : ℝ} (h : P.betaExp = dyadicExp β)
    (hβ0 : 0 < β) (hβ1 : β ≤ 1) : (P.betaExp : ℤ) = ⌈Real.logb 2 β⁻¹⌉ := by
  rw [h]; exact dyadicExp_eq_ceil_logb hβ0 hβ1

/-- Faithfulness of `calL` to eq. `R:eq:calL-def` (L161):
`ℒ = ⌈log₂(2^100 (n+2)(m+2)(U+2)/(ε₀β₀))⌉`. -/
theorem calL_eq_ceil_logb (P : StreamParams) :
    (P.calL : ℤ) = ⌈Real.logb 2 (2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) /
      ((P.eps0 : ℝ) * (P.beta0 : ℝ)))⌉ := by
  have e : (2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) /
      ((P.eps0 : ℝ) * (P.beta0 : ℝ))) =
      (2 : ℝ) ^ (100 + P.epsExp + P.betaExp) * (((P.n + 2) * (P.m + 2) * (P.U + 2) : ℕ) : ℝ) := by
    simp only [eps0, beta0]
    push_cast
    rw [half_pow_eq_inv, half_pow_eq_inv, ← mul_inv, div_inv_eq_mul, pow_add, pow_add]
    ring
  rw [e, ceil_logb_two_pow_mul_natCast _ (Nat.one_le_iff_ne_zero.mpr (by positivity))]
  rfl

/-- `Λ > 100` (eq. `R:eq:master-lambda`, `R:eq:param-Lambda`) for `0 < ε, β ≤ 1`. -/
theorem hundred_lt_masterLambda (n m U : ℕ) {ε β : ℝ} (hε0 : 0 < ε) (hε1 : ε ≤ 1) (hβ0 : 0 < β)
    (hβ1 : β ≤ 1) : 100 < masterLambda n m U ε β := by
  unfold masterLambda
  have hεβ : 0 < ε * β := mul_pos hε0 hβ0
  have hεβ1 : ε * β ≤ 1 := mul_le_one₀ hε1 hβ0.le hβ1
  have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
  have hU : (0 : ℝ) ≤ U := Nat.cast_nonneg U
  have hN : (8 : ℝ) ≤ ((n : ℝ) + 2) * ((m : ℝ) + 2) * ((U : ℝ) + 2) := by
    have h1 : (4 : ℝ) ≤ ((n : ℝ) + 2) * ((m : ℝ) + 2) := by nlinarith
    nlinarith
  have hX : 0 < 2 ^ 100 * ((n : ℝ) + 2) * ((m : ℝ) + 2) * ((U : ℝ) + 2) / (ε * β) := by positivity
  rw [Real.lt_logb_iff_rpow_lt (by norm_num) hX]
  have e : (2 : ℝ) ^ (100 : ℝ) = 2 ^ (100 : ℕ) := by norm_num
  rw [e, lt_div_iff₀ hεβ]
  have h2 : (0 : ℝ) < 2 ^ 100 := by positivity
  calc (2 : ℝ) ^ 100 * (ε * β) ≤ 2 ^ 100 * 1 := mul_le_mul_of_nonneg_left hεβ1 h2.le
    _ < 2 ^ 100 * 8 := by norm_num
    _ ≤ 2 ^ 100 * (((n : ℝ) + 2) * ((m : ℝ) + 2) * ((U : ℝ) + 2)) :=
        mul_le_mul_of_nonneg_left hN h2.le
    _ = 2 ^ 100 * ((n : ℝ) + 2) * ((m : ℝ) + 2) * ((U : ℝ) + 2) := by ring

/-- `Λ ≤ ℒ` with the real `ε, β` (`masterLambda`, eq. `R:eq:master-lambda`). -/
theorem masterLambda_le_calL {P : StreamParams} {ε β : ℝ} (hε : P.epsExp = dyadicExp ε)
    (hβ : P.betaExp = dyadicExp β) (hε0 : 0 < ε) (hβ0 : 0 < β) :
    masterLambda P.n P.m P.U ε β ≤ P.calL := by
  unfold masterLambda
  have hεβ : 0 < ε * β := mul_pos hε0 hβ0
  have hX : 0 < 2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) / (ε * β) := by
    positivity
  rw [Real.logb_le_iff_le_rpow (by norm_num) hX, Real.rpow_natCast]
  have hNc : (((P.n + 2) * (P.m + 2) * (P.U + 2) : ℕ) : ℝ) ≤
      (2 : ℝ) ^ Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) := by
    exact_mod_cast le_pow_clog_two _
  push_cast at hNc
  have hie := inv_le_two_pow_dyadicExp ε
  have hib := inv_le_two_pow_dyadicExp β
  rw [← hε] at hie
  rw [← hβ] at hib
  have he1 : 1 ≤ ε * 2 ^ P.epsExp := by
    rw [← inv_le_iff_one_le_mul₀' hε0]; exact hie
  have hb1 : 1 ≤ β * 2 ^ P.betaExp := by
    rw [← inv_le_iff_one_le_mul₀' hβ0]; exact hib
  unfold calL
  rw [div_le_iff₀ hεβ, pow_add, pow_add, pow_add]
  have hN0 : (0 : ℝ) ≤ ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) := by positivity
  have h100 : (0 : ℝ) < 2 ^ 100 := by positivity
  calc 2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2)
      = 2 ^ 100 * (((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2)) * 1 * 1 := by ring
    _ ≤ 2 ^ 100 * 2 ^ Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) * (ε * 2 ^ P.epsExp) *
          (β * 2 ^ P.betaExp) := by
        gcongr
    _ = 2 ^ 100 * 2 ^ P.epsExp * 2 ^ P.betaExp *
          2 ^ Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) * (ε * β) := by ring

/-- `ℒ < Λ + 3` with the real `ε, β` (Def 1.5, L163: `ℒ ≤ Λ + 3`). -/
theorem calL_lt_masterLambda_add_three {P : StreamParams} {ε β : ℝ}
    (hε : P.epsExp = dyadicExp ε) (hβ : P.betaExp = dyadicExp β) (hε0 : 0 < ε) (hε1 : ε < 1)
    (hβ0 : 0 < β) (hβ1 : β < 1) :
    (P.calL : ℝ) < masterLambda P.n P.m P.U ε β + 3 := by
  unfold masterLambda
  have hεβ : 0 < ε * β := mul_pos hε0 hβ0
  have hX : 0 < 2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) / (ε * β) := by
    positivity
  have he1 := one_le_dyadicExp hε0 hε1
  have hb1 := one_le_dyadicExp hβ0 hβ1
  rw [← hε] at he1
  rw [← hβ] at hb1
  have hie := two_pow_dyadicExp_pred_lt hε0 hε1
  have hib := two_pow_dyadicExp_pred_lt hβ0 hβ1
  rw [← hε] at hie
  rw [← hβ] at hib
  have hN2 : 2 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) := by
    have h1 : 1 ≤ P.U + 2 := by omega
    have h2 : 2 ≤ (P.n + 2) * (P.m + 2) := by nlinarith
    nlinarith
  have hc1 := one_le_clog_two hN2
  have hNc : ((2 ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1) : ℕ) : ℝ) <
      (((P.n + 2) * (P.m + 2) * (P.U + 2) : ℕ) : ℝ) := by
    exact_mod_cast pow_clog_two_pred_lt hN2
  push_cast at hNc
  have hcalL : 3 ≤ P.calL := by unfold calL; omega
  suffices h : ((P.calL - 3 : ℕ) : ℝ) < Real.logb 2
      (2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) / (ε * β)) by
    rw [Nat.cast_sub hcalL] at h
    push_cast at h
    linarith
  rw [Real.lt_logb_iff_rpow_lt (by norm_num) hX, Real.rpow_natCast, lt_div_iff₀ hεβ]
  have e : P.calL - 3 = 100 + (P.epsExp - 1) + (P.betaExp - 1) +
      (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1) := by
    unfold calL; omega
  rw [e, pow_add, pow_add, pow_add]
  have ha : (2 : ℝ) ^ (P.epsExp - 1) * ε < 1 := by
    calc (2 : ℝ) ^ (P.epsExp - 1) * ε < ε⁻¹ * ε := mul_lt_mul_of_pos_right hie hε0
      _ = 1 := inv_mul_cancel₀ hε0.ne'
  have hb : (2 : ℝ) ^ (P.betaExp - 1) * β < 1 := by
    calc (2 : ℝ) ^ (P.betaExp - 1) * β < β⁻¹ * β := mul_lt_mul_of_pos_right hib hβ0
      _ = 1 := inv_mul_cancel₀ hβ0.ne'
  have habc : ((2 : ℝ) ^ (P.epsExp - 1) * ε) * ((2 : ℝ) ^ (P.betaExp - 1) * β) *
      (2 : ℝ) ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1) <
      ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) := by
    have ha' := ha.le
    have hb' := hb.le
    calc ((2 : ℝ) ^ (P.epsExp - 1) * ε) * ((2 : ℝ) ^ (P.betaExp - 1) * β) *
          (2 : ℝ) ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1)
        ≤ 1 * 1 * (2 : ℝ) ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1) := by
          gcongr
      _ < ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) := by
          rw [one_mul, one_mul]; exact hNc
  have h100 : (0 : ℝ) < 2 ^ 100 := by positivity
  calc (2 : ℝ) ^ 100 * 2 ^ (P.epsExp - 1) * 2 ^ (P.betaExp - 1) *
        2 ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1) * (ε * β)
      = 2 ^ 100 * (((2 : ℝ) ^ (P.epsExp - 1) * ε) * ((2 : ℝ) ^ (P.betaExp - 1) * β) *
          (2 : ℝ) ^ (Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) - 1)) := by ring
    _ < 2 ^ 100 * (((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2)) :=
        mul_lt_mul_of_pos_left habc h100
    _ = 2 ^ 100 * ((P.n : ℝ) + 2) * ((P.m : ℝ) + 2) * ((P.U : ℝ) + 2) := by ring

/-- `ℒ ≥ 113 > 100` under the standing assumptions. -/
theorem hundred_thirteen_le_calL {P : StreamParams} (hP : P.Valid) : 113 ≤ P.calL := by
  unfold calL
  have h27 : 27 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) := by
    have h1 := hP.one_le_n
    have h2 := hP.one_le_m
    have h3 := hP.one_le_U
    have h9 : 9 ≤ (P.n + 2) * (P.m + 2) := by nlinarith
    nlinarith
  have h5 : 4 < Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2)) := by
    rw [Nat.lt_clog_iff_pow_lt (by norm_num)]; omega
  have := hP.four_le_epsExp
  have := hP.four_le_betaExp
  omega

/-! ## Definition 1.6: `H`, `T`, `D_*`, `W` -/

theorem one_le_H (P : StreamParams) : 1 ≤ P.H := by unfold H; omega

theorem H_pos (P : StreamParams) : 0 < P.H := P.one_le_H

/-- `2^{H-1} ≥ m` (eq. `R:eq:sec5-depth-H`, partIII.tex L425). -/
theorem m_le_two_pow_H_sub_one (P : StreamParams) : P.m ≤ 2 ^ (P.H - 1) := by
  unfold H
  rw [Nat.add_sub_cancel_left]
  exact le_trans (le_max_right _ _) (le_pow_clog_two _)

/-- `H = 1 + ⌈log₂ m⌉` for `m ≥ 1`. -/
theorem H_eq_of_one_le_m {P : StreamParams} (h : 1 ≤ P.m) : P.H = 1 + Nat.clog 2 P.m := by
  unfold H; rw [max_eq_right h]

/-- Faithfulness of `H` to eq. `R:eq:param-H` (L169): `H = 1 + ⌈log₂ max{1, m}⌉`. -/
theorem H_eq_ceil_logb (P : StreamParams) :
    (P.H : ℤ) = 1 + ⌈Real.logb 2 (max 1 (P.m : ℝ))⌉ := by
  have e : max 1 (P.m : ℝ) = ((max 1 P.m : ℕ) : ℝ) := by push_cast; rfl
  rw [e, ceil_logb_two_natCast (le_max_left _ _)]
  unfold H; push_cast; ring

theorem T_pos (P : StreamParams) : 0 < P.T := by unfold T; positivity

/-- `T ≥ 2^16` (for `m ≥ 1`). -/
theorem two_pow_sixteen_le_T {P : StreamParams} (hm : 1 ≤ P.m) : 2 ^ 16 ≤ P.T := by
  unfold T
  have h1 : 2 ≤ P.m + 1 := by omega
  have h2 : 2 ≤ P.H + 1 := by have := P.one_le_H; omega
  have h3 : 2 ^ 3 ≤ (P.H + 1) ^ 3 := Nat.pow_le_pow_left h2 3
  calc 2 ^ 16 = 2 ^ 12 * 2 * 2 ^ 3 := by norm_num
    _ ≤ 2 ^ 12 * (P.m + 1) * (P.H + 1) ^ 3 := by gcongr

/-- `m(H+1) < T` (L189: the number of guard coordinates is `≤ m(H+1) < T`). -/
theorem m_mul_H_add_one_lt_T (P : StreamParams) : P.m * (P.H + 1) < P.T := by
  unfold T
  have h1 : P.H + 1 ≤ (P.H + 1) ^ 3 := by
    calc P.H + 1 = (P.H + 1) ^ 1 := (pow_one _).symm
      _ ≤ (P.H + 1) ^ 3 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have h2 : P.m * (P.H + 1) < (P.m + 1) * (P.H + 1) :=
    Nat.mul_lt_mul_of_pos_right (by omega) (by omega)
  calc P.m * (P.H + 1) < (P.m + 1) * (P.H + 1) := h2
    _ ≤ (P.m + 1) * (P.H + 1) ^ 3 := Nat.mul_le_mul_left _ h1
    _ ≤ 2 ^ 12 * ((P.m + 1) * (P.H + 1) ^ 3) := Nat.le_mul_of_pos_left _ (by norm_num)
    _ = 2 ^ 12 * (P.m + 1) * (P.H + 1) ^ 3 := by ring

theorem one_le_W (P : StreamParams) : 1 ≤ P.W := by unfold W; omega

theorem Dstar_eq (P : StreamParams) : P.Dstar = P.n + P.T + 1 := rfl

theorem T_lt_Dstar (P : StreamParams) : P.T < P.Dstar := by unfold Dstar; omega

/-! ## `η` (eq. `R:eq:param-eta`) -/

theorem eta_pos (P : StreamParams) : 0 < P.eta := half_pow_pos _

theorem eta_le_one (P : StreamParams) : P.eta ≤ 1 := half_pow_le_one _

theorem eta_mul_two_pow (P : StreamParams) : P.eta * 2 ^ P.eEta = 1 := half_pow_mul_two_pow _

/-- `η ≤ ε₀/(2^20 (H+1)^2)` (eq. `R:eq:param-eta`). -/
theorem eta_le (P : StreamParams) : P.eta ≤ P.eps0 / (2 ^ 20 * ((P.H : ℚ) + 1) ^ 2) := by
  have e : P.eps0 / (2 ^ 20 * ((P.H : ℚ) + 1) ^ 2) =
      (1 / 2 : ℚ) ^ (20 + P.epsExp) / (((P.H + 1) ^ 2 : ℕ) : ℚ) := by
    unfold eps0
    push_cast
    have hH : (P.H : ℚ) + 1 ≠ 0 := by positivity
    simp only [one_div, inv_pow]
    have h2 : (2 : ℚ) ≠ 0 := by norm_num
    generalize (2 : ℚ) = x at h2 ⊢
    field_simp
    ring
  rw [e]
  exact half_pow_add_clog_le (20 + P.epsExp) (Nat.one_le_pow _ _ (by omega))

/-- `ε₀/(2^21 (H+1)^2) < η` (eq. `R:eq:param-eta`). -/
theorem lt_eta (P : StreamParams) : P.eps0 / (2 ^ 21 * ((P.H : ℚ) + 1) ^ 2) < P.eta := by
  have e : P.eps0 / (2 ^ 21 * ((P.H : ℚ) + 1) ^ 2) =
      (1 / 2 : ℚ) ^ (20 + P.epsExp) / (2 * (((P.H + 1) ^ 2 : ℕ) : ℚ)) := by
    unfold eps0
    push_cast
    have hH : (P.H : ℚ) + 1 ≠ 0 := by positivity
    simp only [one_div, inv_pow]
    have h2 : (2 : ℚ) ≠ 0 := by norm_num
    generalize (2 : ℚ) = x at h2 ⊢
    field_simp
    ring
  rw [e]
  exact half_pow_div_two_mul_lt (20 + P.epsExp) (Nat.one_le_pow _ _ (by omega))

/-- Faithfulness of `eEta` to eq. `R:eq:param-eta`: `η = 2^{-⌈log₂(2^20 (H+1)^2/ε₀)⌉}`. -/
theorem eEta_eq_ceil_logb (P : StreamParams) :
    (P.eEta : ℤ) = ⌈Real.logb 2 (2 ^ 20 * ((P.H : ℝ) + 1) ^ 2 / (P.eps0 : ℝ))⌉ := by
  have e : 2 ^ 20 * ((P.H : ℝ) + 1) ^ 2 / (P.eps0 : ℝ) =
      (2 : ℝ) ^ (20 + P.epsExp) * (((P.H + 1) ^ 2 : ℕ) : ℝ) := by
    simp only [eps0]
    push_cast
    rw [half_pow_eq_inv, div_inv_eq_mul, pow_add]
    ring
  rw [e, ceil_logb_two_pow_mul_natCast _ (Nat.one_le_pow _ _ (by omega))]
  rfl

/-- `η ≤ ε/(2^20 (H+1)^2)` with the real `ε`. -/
theorem eta_le_eps {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) (hε : 0 < ε) :
    (P.eta : ℝ) ≤ ε / (2 ^ 20 * ((P.H : ℝ) + 1) ^ 2) := by
  have h1 : (P.eta : ℝ) ≤ (P.eps0 : ℝ) / (2 ^ 20 * ((P.H : ℝ) + 1) ^ 2) := by
    exact_mod_cast P.eta_le
  have h2 := eps0_le h hε
  calc (P.eta : ℝ) ≤ (P.eps0 : ℝ) / (2 ^ 20 * ((P.H : ℝ) + 1) ^ 2) := h1
    _ ≤ ε / (2 ^ 20 * ((P.H : ℝ) + 1) ^ 2) := by gcongr

/-- `ε/(2^22 (H+1)^2) < η` with the real `ε` (used for `η^{-2} < 2^44 ε^{-2} (H+1)^4`, partIII.tex L1253). -/
theorem eps_div_lt_eta {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε) (hε0 : 0 < ε)
    (hε1 : ε < 1) : ε / (2 ^ 22 * ((P.H : ℝ) + 1) ^ 2) < (P.eta : ℝ) := by
  have h1 : (P.eps0 : ℝ) / (2 ^ 21 * ((P.H : ℝ) + 1) ^ 2) < (P.eta : ℝ) := by
    exact_mod_cast P.lt_eta
  have h2 := half_lt_eps0 h hε0 hε1
  have hH : (0 : ℝ) < 2 ^ 21 * ((P.H : ℝ) + 1) ^ 2 := by positivity
  calc ε / (2 ^ 22 * ((P.H : ℝ) + 1) ^ 2) = (ε / 2) / (2 ^ 21 * ((P.H : ℝ) + 1) ^ 2) := by
        rw [div_div, show (2 : ℝ) * (2 ^ 21 * ((P.H : ℝ) + 1) ^ 2) = 2 ^ 22 * ((P.H : ℝ) + 1) ^ 2 by
          ring]
    _ < (P.eps0 : ℝ) / (2 ^ 21 * ((P.H : ℝ) + 1) ^ 2) := div_lt_div_of_pos_right h2 hH
    _ < (P.eta : ℝ) := h1

/-- `log₂(1/η) ≥ 26` when `ε₀ ≤ 2^{-4}` (`(H+1)^2 ≥ 4`). -/
theorem twentysix_le_eEta {P : StreamParams} (h : 4 ≤ P.epsExp) : 26 ≤ P.eEta := by
  unfold eEta
  have h4 : 1 < Nat.clog 2 ((P.H + 1) ^ 2) := by
    rw [Nat.lt_clog_iff_pow_lt (by norm_num)]
    have := P.one_le_H
    nlinarith
  omega

/-! ## `γ`, `B` (eqs. `R:eq:param-gamma`, `R:eq:param-B`) -/

theorem one_le_eGamma (P : StreamParams) : 1 ≤ P.eGamma :=
  Nat.clog_pos (by norm_num) (by have := P.T_pos; omega)

/-- `64 T ≤ 4^{log₂(1/γ)}`, i.e. `γ ≤ 1/(8√T)`. -/
theorem sixtyfour_mul_T_le_four_pow (P : StreamParams) : 64 * P.T ≤ 4 ^ P.eGamma :=
  Nat.le_pow_clog (by norm_num) _

/-- `4^{log₂(1/γ) - 1} < 64 T`. -/
theorem four_pow_pred_lt (P : StreamParams) : 4 ^ (P.eGamma - 1) < 64 * P.T := by
  have := Nat.pow_pred_clog_lt_self (b := 4) (by norm_num) (x := 64 * P.T)
    (by have := P.T_pos; omega)
  unfold eGamma
  simpa [Nat.pred_eq_sub_one] using this

/-- `4^{log₂(1/γ)} < 256 T`, i.e. `1/(16√T) < γ`. -/
theorem four_pow_lt (P : StreamParams) : 4 ^ P.eGamma < 256 * P.T := by
  have h1 := P.one_le_eGamma
  have h2 := P.four_pow_pred_lt
  calc 4 ^ P.eGamma = 4 * 4 ^ (P.eGamma - 1) := by
        nth_rw 1 [show P.eGamma = (P.eGamma - 1) + 1 by omega]; rw [pow_succ']
    _ < 4 * (64 * P.T) := by omega
    _ = 256 * P.T := by ring

theorem gamma_pos (P : StreamParams) : 0 < P.gamma := half_pow_pos _

theorem gamma_sq (P : StreamParams) : P.gamma ^ 2 = 1 / 4 ^ P.eGamma := by
  unfold gamma
  rw [← pow_mul, mul_comm, pow_mul, show ((1 : ℚ) / 2) ^ 2 = 1 / 4 by norm_num, one_div_pow]

/-- `Tγ^2 ≤ 1/64` (eq. `R:eq:param-gamma`). -/
theorem T_mul_gamma_sq_le (P : StreamParams) : (P.T : ℚ) * P.gamma ^ 2 ≤ 1 / 64 := by
  rw [gamma_sq, mul_one_div, div_le_div_iff₀ (by positivity) (by norm_num)]
  have h : ((64 * P.T : ℕ) : ℚ) ≤ ((4 ^ P.eGamma : ℕ) : ℚ) := by
    exact_mod_cast P.sixtyfour_mul_T_le_four_pow
  push_cast at h
  linarith

/-- `1 < 256 T γ^2`, i.e. `γ > 1/(16√T)` (eq. `R:eq:param-gamma`). -/
theorem one_lt_T_mul_gamma_sq (P : StreamParams) : 1 < 256 * (P.T : ℚ) * P.gamma ^ 2 := by
  rw [gamma_sq, mul_one_div, one_lt_div (by positivity)]
  have h : ((4 ^ P.eGamma : ℕ) : ℚ) < ((256 * P.T : ℕ) : ℚ) := by
    exact_mod_cast P.four_pow_lt
  push_cast at h
  linarith

/-- `γ ≤ 1/(8√T)` (eq. `R:eq:param-gamma`). -/
theorem gamma_le_inv_eight_sqrt (P : StreamParams) :
    (P.gamma : ℝ) ≤ 1 / (8 * Real.sqrt P.T) := by
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have htt : Real.sqrt P.T ^ 2 = P.T := Real.sq_sqrt hT.le
  have hg : (P.T : ℝ) * (P.gamma : ℝ) ^ 2 ≤ 1 / 64 := by
    have h' : (((P.T : ℚ) * P.gamma ^ 2 : ℚ) : ℝ) ≤ ((1 / 64 : ℚ) : ℝ) :=
      Rat.cast_le.mpr P.T_mul_gamma_sq_le
    push_cast at h'
    exact h'
  rw [le_div_iff₀ (by positivity)]
  have h8 : ((P.gamma : ℝ) * (8 * Real.sqrt P.T)) ^ 2 ≤ 1 := by
    rw [mul_pow, mul_pow, htt]; nlinarith
  exact (pow_le_one_iff_of_nonneg (by have := P.gamma_pos; positivity) (by norm_num)).1 h8

/-- `1/(16√T) < γ` (eq. `R:eq:param-gamma`). -/
theorem inv_sixteen_sqrt_lt_gamma (P : StreamParams) :
    1 / (16 * Real.sqrt P.T) < (P.gamma : ℝ) := by
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have htt : Real.sqrt P.T ^ 2 = P.T := Real.sq_sqrt hT.le
  have hg : 1 < 256 * (P.T : ℝ) * (P.gamma : ℝ) ^ 2 := by
    have h' : ((1 : ℚ) : ℝ) < ((256 * (P.T : ℚ) * P.gamma ^ 2 : ℚ) : ℝ) :=
      Rat.cast_lt.mpr P.one_lt_T_mul_gamma_sq
    push_cast at h'
    exact h'
  rw [div_lt_iff₀ (by positivity)]
  have h8 : 1 < ((P.gamma : ℝ) * (16 * Real.sqrt P.T)) ^ 2 := by
    rw [mul_pow, mul_pow, htt]; nlinarith
  by_contra hc
  have hc' := not_lt.mp hc
  have : ((P.gamma : ℝ) * (16 * Real.sqrt P.T)) ^ 2 ≤ 1 :=
    (pow_le_one_iff_of_nonneg (by have := P.gamma_pos; positivity) (by norm_num)).2 hc'
  linarith

/-- Faithfulness of `eGamma` to eq. `R:eq:param-gamma`: `γ = 2^{-⌈log₂(8√T)⌉}`. -/
theorem eGamma_eq_ceil_logb (P : StreamParams) :
    (P.eGamma : ℤ) = ⌈Real.logb 2 (8 * Real.sqrt P.T)⌉ := by
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have htt : Real.sqrt P.T ^ 2 = P.T := Real.sq_sqrt hT.le
  have hs : 0 ≤ 8 * Real.sqrt P.T := by positivity
  have h64 : (8 * Real.sqrt P.T) ^ 2 = 64 * P.T := by rw [mul_pow, htt]; norm_num
  have h4 : ∀ k : ℕ, ((2 : ℝ) ^ k) ^ 2 = 4 ^ k := fun k => by
    rw [← pow_mul, mul_comm, pow_mul]; norm_num
  symm
  apply ceil_logb_two_eq
  · have h1 := P.one_le_eGamma
    rw [show ((P.eGamma : ℤ) - 1) = ((P.eGamma - 1 : ℕ) : ℤ) by omega, zpow_natCast]
    have h2 : ((4 ^ (P.eGamma - 1) : ℕ) : ℝ) < ((64 * P.T : ℕ) : ℝ) := by
      exact_mod_cast P.four_pow_pred_lt
    push_cast at h2
    apply lt_of_pow_lt_pow_left₀ 2 hs
    rw [h64, h4]
    exact h2
  · rw [zpow_natCast]
    have h2 : ((64 * P.T : ℕ) : ℝ) ≤ ((4 ^ P.eGamma : ℕ) : ℝ) := by
      exact_mod_cast P.sixtyfour_mul_T_le_four_pow
    push_cast at h2
    refine le_of_pow_le_pow_left₀ (n := 2) (by norm_num) (by positivity) ?_
    rw [h64, h4]
    exact h2

/-- `B = 16/γ` (eq. `R:eq:param-B`). -/
theorem B_eq_sixteen_div_gamma (P : StreamParams) : (P.B : ℚ) = 16 / P.gamma := by
  unfold B gamma logB
  push_cast
  rw [half_pow_eq_inv, div_inv_eq_mul, pow_add]
  norm_num

/-- `γ = 16/B`. -/
theorem gamma_eq_sixteen_div_B (P : StreamParams) : P.gamma = 16 / (P.B : ℚ) := by
  rw [B_eq_sixteen_div_gamma, div_div_cancel₀ (by norm_num)]

theorem B_pos (P : StreamParams) : 0 < P.B := by unfold B; positivity

theorem one_le_B (P : StreamParams) : 1 ≤ P.B := P.B_pos

/-- `B^2 = 2^8 · 4^{log₂(1/γ)}`. -/
theorem B_sq (P : StreamParams) : P.B ^ 2 = 2 ^ 8 * 4 ^ P.eGamma := by
  unfold B logB
  rw [← pow_mul, show (4 : ℕ) ^ P.eGamma = 2 ^ (2 * P.eGamma) by rw [pow_mul]; norm_num,
    ← pow_add, show (4 + P.eGamma) * 2 = 8 + 2 * P.eGamma by ring]

/-- `2^14 T ≤ B^2 < 2^16 T`, i.e. `B ∈ [128√T, 256√T)` (eq. `R:eq:param-B`). -/
theorem B_sq_bounds (P : StreamParams) : 2 ^ 14 * P.T ≤ P.B ^ 2 ∧ P.B ^ 2 < 2 ^ 16 * P.T := by
  rw [B_sq]
  constructor
  · have := P.sixtyfour_mul_T_le_four_pow
    calc 2 ^ 14 * P.T = 2 ^ 8 * (64 * P.T) := by ring
      _ ≤ 2 ^ 8 * 4 ^ P.eGamma := Nat.mul_le_mul_left _ this
  · have := P.four_pow_lt
    calc 2 ^ 8 * 4 ^ P.eGamma < 2 ^ 8 * (256 * P.T) := (Nat.mul_lt_mul_left (by norm_num)).2 this
      _ = 2 ^ 16 * P.T := by ring

/-- `128√T ≤ B` (eq. `R:eq:param-B`). -/
theorem le_B (P : StreamParams) : 128 * Real.sqrt P.T ≤ (P.B : ℝ) := by
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have htt : Real.sqrt P.T ^ 2 = P.T := Real.sq_sqrt hT.le
  have h := P.B_sq_bounds.1
  have h' : ((2 ^ 14 * P.T : ℕ) : ℝ) ≤ ((P.B ^ 2 : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at h'
  refine le_of_pow_le_pow_left₀ (n := 2) (by norm_num) (Nat.cast_nonneg _) ?_
  rw [mul_pow, htt]
  linarith

/-- `B < 256√T` (eq. `R:eq:param-B`). -/
theorem B_lt (P : StreamParams) : (P.B : ℝ) < 256 * Real.sqrt P.T := by
  have hT : (0 : ℝ) < P.T := by exact_mod_cast P.T_pos
  have htt : Real.sqrt P.T ^ 2 = P.T := Real.sq_sqrt hT.le
  have h := P.B_sq_bounds.2
  have h' : ((P.B ^ 2 : ℕ) : ℝ) < ((2 ^ 16 * P.T : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at h'
  have hs : 0 ≤ 256 * Real.sqrt P.T := by have := Real.sqrt_nonneg (P.T : ℝ); linarith
  refine lt_of_pow_lt_pow_left₀ 2 hs ?_
  rw [mul_pow, htt]
  linarith

/-- `log₂(1/γ) ≥ 11` for `m ≥ 1` (`T ≥ 2^16`). -/
theorem eleven_le_eGamma {P : StreamParams} (hm : 1 ≤ P.m) : 11 ≤ P.eGamma := by
  have hT := two_pow_sixteen_le_T hm
  have : 10 < P.eGamma := by
    unfold eGamma
    rw [Nat.lt_clog_iff_pow_lt (by norm_num)]
    calc 4 ^ 10 < 64 * 2 ^ 16 := by norm_num
      _ ≤ 64 * P.T := Nat.mul_le_mul_left _ hT
  omega

/-- `B ≥ 2^15` for `m ≥ 1`. -/
theorem two_pow_fifteen_le_B {P : StreamParams} (hm : 1 ≤ P.m) : 2 ^ 15 ≤ P.B := by
  unfold B logB
  exact Nat.pow_le_pow_right (by norm_num) (by have := eleven_le_eGamma hm; omega)

/-- `γ ≤ 2^{-11}` for `m ≥ 1`. -/
theorem gamma_le {P : StreamParams} (hm : 1 ≤ P.m) : P.gamma ≤ (1 / 2) ^ 11 :=
  half_pow_antitone (eleven_le_eGamma hm)

/-! ## `V_d`, `𝒰_d`, `𝒰_*`, `V`, `G` (eqs. `R:eq:param-Vd`, `R:eq:param-Ud`, `R:eq:param-V-G`) -/

theorem Vd_zero (P : StreamParams) : P.Vd 0 = P.W := rfl

theorem Vd_succ (P : StreamParams) (d : ℕ) : P.Vd (d + 1) = (1 + 2 * P.B ^ d) * P.Vd d := rfl

theorem one_le_Vd (P : StreamParams) (d : ℕ) : 1 ≤ P.Vd d := by
  induction d with
  | zero => exact P.one_le_W
  | succ d ih =>
    rw [Vd_succ]
    calc 1 = 1 * 1 := rfl
      _ ≤ (1 + 2 * P.B ^ d) * P.Vd d := Nat.mul_le_mul (by omega) ih

theorem Vd_pos (P : StreamParams) (d : ℕ) : 0 < P.Vd d := P.one_le_Vd d

theorem Vd_le_Vd_succ (P : StreamParams) (d : ℕ) : P.Vd d ≤ P.Vd (d + 1) := by
  rw [Vd_succ]; exact Nat.le_mul_of_pos_left _ (by omega)

/-- `V_d` is nondecreasing. -/
theorem Vd_mono (P : StreamParams) : Monotone P.Vd := monotone_nat_of_le_succ P.Vd_le_Vd_succ

/-- `2V_d^2 ≤ 𝒰_d` (eq. `R:eq:param-Ud`). -/
theorem two_mul_Vd_sq_le_Ud (P : StreamParams) (d : ℕ) : 2 * P.Vd d ^ 2 ≤ P.Ud d :=
  le_pow_clog_two _

/-- `𝒰_d < 4V_d^2` (eq. `R:eq:param-Ud`). -/
theorem Ud_lt_four_mul_Vd_sq (P : StreamParams) (d : ℕ) : P.Ud d < 4 * P.Vd d ^ 2 := by
  have h1 := P.one_le_Vd d
  have h2 : 1 ≤ 2 * P.Vd d ^ 2 := by nlinarith
  have := two_pow_clog_two_lt h2
  unfold Ud eU
  linarith

/-- Faithfulness of `eU` to eq. `R:eq:param-Ud`: `𝒰_d = 2^{⌈log₂(2V_d^2)⌉}`. -/
theorem eU_eq_ceil_logb (P : StreamParams) (d : ℕ) :
    (P.eU d : ℤ) = ⌈Real.logb 2 (2 * (P.Vd d : ℝ) ^ 2)⌉ := by
  have h1 := P.one_le_Vd d
  have e : 2 * (P.Vd d : ℝ) ^ 2 = ((2 * P.Vd d ^ 2 : ℕ) : ℝ) := by push_cast; ring
  rw [e, ceil_logb_two_natCast (by nlinarith)]
  rfl

theorem eU_mono (P : StreamParams) : Monotone P.eU := fun _ _ h =>
  Nat.clog_mono_right 2 (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (P.Vd_mono h) 2))

theorem Ud_mono (P : StreamParams) : Monotone P.Ud := fun _ _ h =>
  Nat.pow_le_pow_right (by norm_num) (P.eU_mono h)

theorem Ustar_eq_Ud (P : StreamParams) : P.Ustar = P.Ud (P.H - 1) := rfl

/-- `𝒰_d ≤ 𝒰_*` for `d < H`. -/
theorem Ud_le_Ustar (P : StreamParams) {d : ℕ} (hd : d < P.H) : P.Ud d ≤ P.Ustar :=
  P.Ud_mono (by omega)

/-- Faithfulness of `Ustar` to eq. `R:eq:param-Ustar`: `𝒰_* = max_{0 ≤ d < H} 𝒰_d`. -/
theorem Ustar_eq_sup (P : StreamParams) : P.Ustar = (Finset.range P.H).sup P.Ud := by
  apply le_antisymm
  · rw [Ustar_eq_Ud]
    exact Finset.le_sup (f := P.Ud) (Finset.mem_range.2 (by have := P.one_le_H; omega))
  · exact Finset.sup_le fun d hd => P.Ud_le_Ustar (Finset.mem_range.1 hd)

theorem G_eq_two_pow (P : StreamParams) : P.G = 2 ^ P.logG := by
  unfold G B logG; rw [← pow_mul, mul_comm]

theorem G_pos (P : StreamParams) : 0 < P.G := by unfold G; exact pow_pos P.B_pos _

theorem one_le_V (P : StreamParams) : 1 ≤ P.V := by unfold V; omega

/-! ## `ν`, `E_min`, `K_epoch`, `K_0`, `J_*` (eqs. `R:eq:param-nu-Emin`, `R:eq:param-Kepoch-Jstar`) -/

/-- `ν = γη 2^{-H-20}` (eq. `R:eq:param-nu-Emin`). -/
theorem nu_eq (P : StreamParams) : P.nu = P.gamma * P.eta * (1 / 2) ^ (P.H + 20) := by
  unfold nu eNu gamma eta
  rw [pow_add, pow_add, pow_add, pow_add]
  ring

theorem nu_pos (P : StreamParams) : 0 < P.nu := half_pow_pos _

theorem nu_lt_one (P : StreamParams) : P.nu < 1 := by
  unfold nu
  exact pow_lt_one₀ (by norm_num) (by norm_num) (by unfold eNu; omega)

/-- `E_min = 2^{-8} η^2 ν^2` is the power of two `2^{-(8 + 2 log₂(1/η) + 2 log₂(1/ν))}`. -/
theorem Emin_eq (P : StreamParams) : P.Emin = (1 / 2) ^ (8 + 2 * P.eEta + 2 * P.eNu) := by
  unfold Emin eta nu
  rw [show (256 : ℚ) = 2 ^ 8 by norm_num]
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-- `2^{K_epoch} = 2^20 𝒰_* B^{2H}/(η^2 ν^2)` (eq. `R:eq:param-Kepoch-Jstar`; the argument is a power of two). -/
theorem two_pow_Kepoch (P : StreamParams) :
    (2 : ℚ) ^ P.Kepoch = 2 ^ 20 * P.Ustar * (P.B : ℚ) ^ (2 * P.H) / (P.eta ^ 2 * P.nu ^ 2) := by
  unfold Kepoch Ustar B eta nu
  push_cast
  simp only [one_div, inv_pow]
  have h2 : (2 : ℚ) ≠ 0 := by norm_num
  generalize (2 : ℚ) = x at h2 ⊢
  field_simp
  ring

/-- Faithfulness of `Kepoch` to eq. `R:eq:param-Kepoch-Jstar`:
`K_epoch = ⌈log₂(2^20 𝒰_* B^{2H}/(η^2ν^2))⌉`. -/
theorem Kepoch_eq_ceil_logb (P : StreamParams) :
    (P.Kepoch : ℤ) = ⌈Real.logb 2 (2 ^ 20 * (P.Ustar : ℝ) * (P.B : ℝ) ^ (2 * P.H) /
      ((P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2))⌉ := by
  have hR : 2 ^ 20 * (P.Ustar : ℝ) * (P.B : ℝ) ^ (2 * P.H) / ((P.eta : ℝ) ^ 2 * (P.nu : ℝ) ^ 2) =
      (2 : ℝ) ^ P.Kepoch := by
    have := congrArg (fun q : ℚ => (q : ℝ)) P.two_pow_Kepoch
    push_cast at this
    exact this.symm
  rw [hR, Real.logb_pow, Real.logb_self_eq_one (by norm_num), mul_one, Int.ceil_natCast]

/-- `K_0 = 128/η^2` (L188). -/
theorem K0_eq (P : StreamParams) : (P.K0 : ℚ) = 128 / P.eta ^ 2 := by
  unfold K0 eta
  push_cast
  rw [half_pow_eq_inv, inv_pow, div_inv_eq_mul, pow_add, ← pow_mul, mul_comm P.eEta]
  norm_num

/-- `K_0 = ⌈128/η^2⌉` (L188). -/
theorem K0_eq_ceil (P : StreamParams) : P.K0 = ⌈(128 : ℚ) / P.eta ^ 2⌉₊ := by
  rw [← K0_eq, Nat.ceil_natCast]

/-- `J_* = ⌈128/η^2⌉ (K_epoch + 1)` (eq. `R:eq:param-Kepoch-Jstar`). -/
theorem Jstar_eq (P : StreamParams) : P.Jstar = ⌈(128 : ℚ) / P.eta ^ 2⌉₊ * (P.Kepoch + 1) := by
  rw [← K0_eq_ceil]; rfl

theorem Jmax_eq (P : StreamParams) : P.Jmax = 2 * P.Jstar := rfl

theorem Rmax_eq (P : StreamParams) : P.Rmax = 4 * P.Jstar + 2 := rfl

/-! ## `s`, `L`, `a_num`, `a_val`, `β_B` (eq. `R:eq:param-s-L-a-betaB`) and eq. `R:eq:param-s-bound` -/

/-- `s = log₂(1/η) + 22` is an integer: `η = 2^{-(s - 22)}`. -/
theorem eta_eq_half_pow_s (P : StreamParams) : P.eta = (1 / 2) ^ (P.s - 22) := by
  unfold s; rw [Nat.add_sub_cancel]; rfl

/-- eq. `R:eq:param-s-bound` (L185–187): `2s 4^{-(s-1)} ≤ 2^{-16} η`, because `2(e+22) ≤ 2^{e+26}`. -/
theorem two_mul_s_div_four_pow_le (P : StreamParams) :
    2 * (P.s : ℚ) / 4 ^ (P.s - 1) ≤ P.eta / 2 ^ 16 := by
  have hs : P.s - 1 = P.eEta + 21 := by unfold s; omega
  have key : 2 * (P.eEta + 22) * 2 ^ 16 ≤ 2 ^ (P.eEta + 42) := by
    have h1 : P.eEta + 22 < 2 ^ (P.eEta + 22) := Nat.lt_two_pow_self
    calc 2 * (P.eEta + 22) * 2 ^ 16 ≤ 2 * 2 ^ (P.eEta + 22) * 2 ^ 16 :=
          Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ h1.le)
      _ = 2 ^ (P.eEta + 39) := by ring
      _ ≤ 2 ^ (P.eEta + 42) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have key' : ((2 * (P.eEta + 22) * 2 ^ 16 : ℕ) : ℚ) ≤ ((2 ^ (P.eEta + 42) : ℕ) : ℚ) := by
    exact_mod_cast key
  push_cast at key'
  have e1 : P.eta * (4 : ℚ) ^ (P.eEta + 21) = 2 ^ (P.eEta + 42) := by
    unfold eta
    rw [show (4 : ℚ) = 2 ^ 2 by norm_num]
    simp only [one_div, inv_pow]
    have h2 : (2 : ℚ) ≠ 0 := by norm_num
    generalize (2 : ℚ) = x at h2 ⊢
    field_simp
    ring
  rw [hs, div_le_div_iff₀ (by positivity) (by positivity), e1]
  unfold s
  push_cast
  linarith

theorem s_pos (P : StreamParams) : 0 < P.s := by unfold s; omega

theorem L_pos (P : StreamParams) : 0 < P.L := by unfold L; have := P.s_pos; omega

/-- `s ≥ 48` when `ε₀ ≤ 2^{-4}`. -/
theorem fortyeight_le_s {P : StreamParams} (h : 4 ≤ P.epsExp) : 48 ≤ P.s := by
  unfold s; have := twentysix_le_eEta h; omega

/-- `L = 16 s ≥ 768` when `ε₀ ≤ 2^{-4}` (partIII.tex L167: `L ≥ 64`). -/
theorem L_ge {P : StreamParams} (h : 4 ≤ P.epsExp) : 768 ≤ P.L := by
  unfold L; have := fortyeight_le_s h; omega

theorem aNum_pos (P : StreamParams) : 0 < P.aNum := by
  unfold aNum; have := P.eta_pos; have : (0 : ℚ) < P.L := by exact_mod_cast P.L_pos
  positivity

theorem aVal_pos (P : StreamParams) : 0 < P.aVal := by
  unfold aVal; have := P.eta_pos; have : (0 : ℚ) < P.L := by exact_mod_cast P.L_pos
  positivity

/-- `a_num ≤ a_val`. -/
theorem aNum_le_aVal (P : StreamParams) : P.aNum ≤ P.aVal := by
  unfold aNum aVal
  have := P.eta_pos
  have hL : (0 : ℚ) < P.L := by exact_mod_cast P.L_pos
  apply div_le_div_of_nonneg_left this.le (by positivity)
  nlinarith

/-- `a_num < 1/10`, the accuracy hypothesis of Theorem B for the bank instance. -/
theorem aNum_lt_tenth (P : StreamParams) : P.aNum < 1 / 10 := by
  unfold aNum
  have he := P.eta_le_one
  have he0 := P.eta_pos
  have hL : (1 : ℚ) ≤ P.L := by exact_mod_cast P.L_pos
  rw [div_lt_div_iff₀ (by positivity) (by norm_num)]
  nlinarith

theorem betaB_pos {P : StreamParams} (hm : 1 ≤ P.m) : 0 < P.betaB := by
  unfold betaB
  have := P.beta0_pos
  have : (1 : ℚ) ≤ P.m := by exact_mod_cast hm
  positivity

/-- `β_B ≤ β₀/128` (for `m ≥ 1`). -/
theorem betaB_le {P : StreamParams} (hm : 1 ≤ P.m) : P.betaB ≤ P.beta0 / 128 := by
  unfold betaB
  have := P.beta0_pos
  have hm' : (1 : ℚ) ≤ P.m := by exact_mod_cast hm
  have hH : (1 : ℚ) ≤ P.H := by exact_mod_cast P.one_le_H
  apply div_le_div_of_nonneg_left this.le (by norm_num)
  nlinarith

/-- `0 < β_B/2 < 1/2`, the failure-probability hypothesis of Theorem B for the bank instance. -/
theorem bankXiReq_pos {P : StreamParams} (hm : 1 ≤ P.m) : 0 < P.bankXiReq := by
  unfold bankXiReq; have := betaB_pos hm; positivity

theorem bankXiReq_lt_half {P : StreamParams} (hm : 1 ≤ P.m) : P.bankXiReq < 1 / 2 := by
  unfold bankXiReq
  have h1 := betaB_le hm
  have h2 := P.beta0_le_one
  linarith

theorem bankAReq_pos (P : StreamParams) : 0 < P.bankAReq := P.aNum_pos

theorem bankAReq_lt_tenth (P : StreamParams) : P.bankAReq < 1 / 10 := P.aNum_lt_tenth

/-! ## Budgets used in the final assembly (partIII.tex L1281–1317) -/

/-- `8(H+1)η < ε₀/2` (partIII.tex L1311). -/
theorem eight_mul_H_add_one_mul_eta_lt (P : StreamParams) :
    8 * ((P.H : ℚ) + 1) * P.eta < P.eps0 / 2 := by
  have h := P.eta_le
  have hH : (1 : ℚ) ≤ P.H := by exact_mod_cast P.one_le_H
  have he := P.eps0_pos
  have hH1 : (P.H : ℚ) + 1 ≠ 0 := by positivity
  calc 8 * ((P.H : ℚ) + 1) * P.eta ≤ 8 * ((P.H : ℚ) + 1) * (P.eps0 / (2 ^ 20 * ((P.H : ℚ) + 1) ^ 2)) := by
        gcongr
    _ = P.eps0 / (2 ^ 17 * ((P.H : ℚ) + 1)) := by field_simp; ring
    _ < P.eps0 / 2 := div_lt_div_of_pos_left he (by norm_num) (by nlinarith)

/-- `8(H+1)η < ε/2` with the real `ε`. -/
theorem eight_mul_H_add_one_mul_eta_lt_eps {P : StreamParams} {ε : ℝ} (h : P.epsExp = dyadicExp ε)
    (hε : 0 < ε) : 8 * ((P.H : ℝ) + 1) * (P.eta : ℝ) < ε / 2 := by
  have h1 : 8 * ((P.H : ℝ) + 1) * (P.eta : ℝ) < (P.eps0 : ℝ) / 2 := by
    exact_mod_cast P.eight_mul_H_add_one_mul_eta_lt
  have h2 := eps0_le h hε
  linarith

/-- eq. `R:eq:global-failure-budget`: `β₀/8 + 2m(H+1)β_B = 5β₀/32`. -/
theorem failure_budget {P : StreamParams} (hm : 1 ≤ P.m) :
    P.beta0 / 8 + 2 * P.m * ((P.H : ℚ) + 1) * P.betaB = 5 * P.beta0 / 32 := by
  unfold betaB
  have hm1 : (1 : ℚ) ≤ P.m := by exact_mod_cast hm
  have hm' : (P.m : ℚ) ≠ 0 := by positivity
  have hH1 : (P.H : ℚ) + 1 ≠ 0 := by positivity
  field_simp
  ring

/-- eq. `R:eq:global-failure-budget`: `5β₀/32 < β` with the real `β`. -/
theorem five_beta0_div_lt {P : StreamParams} {β : ℝ} (h : P.betaExp = dyadicExp β) (hβ : 0 < β) :
    5 * (P.beta0 : ℝ) / 32 < β := by
  have := beta0_le h hβ
  linarith

/-! ## Guard coordinates `g(d,t) = n + H(t-1) + d + 1` (L189; partIII.tex Lemma 5.6) -/

theorem guardCoord_ge (P : StreamParams) (d t : ℕ) : P.n + 1 ≤ P.guardCoord d t := by
  unfold guardCoord; omega

/-- `g(d,t) ≤ n + mH` for `d < H`, `1 ≤ t ≤ m`. -/
theorem guardCoord_le {P : StreamParams} {d t : ℕ} (hd : d < P.H) (ht : 1 ≤ t) (htm : t ≤ P.m) :
    P.guardCoord d t ≤ P.n + P.H * P.m := by
  unfold guardCoord
  have : P.H * (t - 1) + d + 1 ≤ P.H * P.m := by
    have h1 : P.H * (t - 1) ≤ P.H * (P.m - 1) := Nat.mul_le_mul_left _ (by omega)
    have h2 : P.H * (P.m - 1) + P.H = P.H * P.m := by
      rw [← Nat.mul_succ]; congr 1; omega
    omega
  omega

/-- `g(d,t) < n + T = D_* - 1` for `d < H`, `1 ≤ t ≤ m`. -/
theorem guardCoord_lt {P : StreamParams} {d t : ℕ} (hd : d < P.H) (ht : 1 ≤ t) (htm : t ≤ P.m) :
    P.guardCoord d t < P.n + P.T := by
  have h1 := guardCoord_le hd ht htm
  have h2 := P.m_mul_H_add_one_lt_T
  have h3 : P.H * P.m ≤ P.m * (P.H + 1) := by rw [mul_comm]; exact Nat.mul_le_mul_left _ (by omega)
  omega

/-- Distinct (depth, round) pairs get distinct guard coordinates. -/
theorem guardCoord_inj {P : StreamParams} {d t d' t' : ℕ} (hd : d < P.H) (hd' : d' < P.H)
    (ht : 1 ≤ t) (ht' : 1 ≤ t') (h : P.guardCoord d t = P.guardCoord d' t') : d = d' ∧ t = t' := by
  unfold guardCoord at h
  have h1 : d + P.H * (t - 1) = d' + P.H * (t' - 1) := by omega
  have hH := P.H_pos
  have e1 : (d + P.H * (t - 1)) % P.H = d := by
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hd]
  have e2 : (d' + P.H * (t' - 1)) % P.H = d' := by
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hd']
  have hdd : d = d' := by rw [← e1, ← e2, h1]
  subst hdd
  have : P.H * (t - 1) = P.H * (t' - 1) := by omega
  have := Nat.eq_of_mul_eq_mul_left hH this
  exact ⟨rfl, by omega⟩

end StreamParams

end F2e2e
