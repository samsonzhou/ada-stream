import F2e2e.C.Impl.Fingerprint
import F2e2e.Lib.Hash.Rademacher
import F2e2e.C.Alg.Bank
import F2e2e.C.Alg.Fingerprint

/-!
# Bridges from the HASH / fingerprint DSL routines to C-ALG's reference functions

* `leastPrimeGE_Mq`: the DSL search `leastPrimeGE` started at `P.Mq` returns C-ALG's fingerprint
  modulus `P.q = Nat.find (exists_prime_ge P.Mq)` (for `P.Mq ≥ 1`);
* `fpUpdateQ_eq_fpUpdate`: `fpUpdateQ P.q = F2e2e.C.Alg.fpUpdate P` (definitional);
* `isIrrPoly_irrW`, `lt_two_pow_w`: `irrW P = Hash.irrPoly P.w` is irreducible of degree
  `P.w = ⌈log₂(D_* + 1)⌉` and every coordinate `i ≤ D_*` is a field element (`i < 2^w`);
* `rowSign_spec_alg`: the DSL routine `rowSign` on `[w, irrW P, seed, i]` returns
  `encZ (F2e2e.C.Alg.rowSign P r i)`; `fpUpdate_spec_alg`: the DSL routine `fpUpdate` on
  `[q, seed, val, i, Δ]` returns `encN (F2e2e.C.Alg.fpUpdate P seed val i Δ)`.
-/

namespace F2e2e.Cost.HashDSL

open F2e2e.C.Alg

/-- The least prime `≥ M` computed by search equals `Nat.find` of any existence proof. -/
theorem leastPrimeGE_eq_find {M : ℕ} (hM : 1 ≤ M) (h : ∃ p, M ≤ p ∧ p.Prime) :
    Hash.leastPrimeGE M = Nat.find h := by
  obtain ⟨h1, -, h3, h4⟩ := Hash.leastPrimeGE_spec hM
  apply le_antisymm
  · by_contra hlt
    exact h4 (Nat.find h) (Nat.find_spec h).1 (not_le.mp hlt) (Nat.find_spec h).2
  · exact Nat.find_min' h ⟨h1, h3⟩

/-- The DSL search computes C-ALG's fingerprint modulus `P.q` from `P.Mq`. -/
theorem leastPrimeGE_Mq (P : StreamParams) (hM : 1 ≤ P.Mq) : Hash.leastPrimeGE P.Mq = P.q :=
  leastPrimeGE_eq_find hM _

theorem fpUpdateQ_eq_fpUpdate (P : StreamParams) (seed val i : ℕ) (Δ : ℤ) :
    fpUpdateQ P.q seed val i Δ = F2e2e.C.Alg.fpUpdate P seed val i Δ := rfl

theorem w_eq_seedDeg (P : StreamParams) : P.w = Hash.seedDeg P.Dstar := rfl

/-- `irrW P` is an irreducible polynomial of degree `P.w` (for `D_* ≥ 1`). -/
theorem isIrrPoly_irrW (P : StreamParams) (hD : 1 ≤ P.Dstar) : Hash.IsIrrPoly P.w (irrW P) :=
  Hash.isIrrPoly_seedDeg hD

/-- Every coordinate `i ≤ D_*` is an element of `𝔽_{2^w}`. -/
theorem lt_two_pow_w (P : StreamParams) {i : ℕ} (hi : i ≤ P.Dstar) : i < 2 ^ P.w :=
  lt_of_le_of_lt hi (Hash.lt_two_pow_seedDeg P.Dstar)

/-- **The DSL `rowSign` computes C-ALG's `rowSign`** (`D_* ≥ 1`, seed entries in `𝔽_{2^w}`,
coordinate `i ≤ D_*`). -/
theorem rowSign_spec_alg {prog : List Expr} (hL : HornerLib prog) (P : StreamParams) (r : Row)
    (i : ℕ) (hD : 1 ≤ P.Dstar) (hseed : ∀ c ∈ r.seed, c < 2 ^ P.w) (hi : i ≤ P.Dstar)
    (base : ℕ) :
    EvalsSp prog base [Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]] body_rowSign
      (encZ (rowSign P r i))
      (base + 3 * valSize (Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]) +
        S_gfHorner P.w r.seed + 4 * P.w + 60) := by
  obtain ⟨hp1, hp2, -⟩ := isIrrPoly_irrW P hD
  exact rowSign_spec hL P.w (irrW P) r.seed i hp1 hp2 hseed (lt_two_pow_w P hi) base

/-- **The DSL `fpUpdate` computes C-ALG's `fpUpdate`** (`q = P.q`). -/
theorem fpUpdate_spec_alg {prog : List Expr} (hL : FpLib prog) (P : StreamParams)
    (seed val i : ℕ) (Δ : ℤ) (hq : P.q ≠ 0) (base : ℕ) :
    EvalsSp prog base [Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]] body_fpUpdate
      (encN (F2e2e.C.Alg.fpUpdate P seed val i Δ))
      (base + 8 * valSize (Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]) +
        S_fpUpdate P.q seed i) :=
  fpUpdate_spec hL P.q seed val i Δ hq base

/-- `P.q` is a prime, hence nonzero. -/
theorem q_ne_zero (P : StreamParams) : P.q ≠ 0 :=
  (Nat.find_spec (StreamParams.exists_prime_ge P.Mq)).2.ne_zero

end F2e2e.Cost.HashDSL
