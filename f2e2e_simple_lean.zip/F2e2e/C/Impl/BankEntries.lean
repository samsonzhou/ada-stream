import F2e2e.C.Impl.BankArith

/-!
# W5: the arithmetic and learner entries (758–765)

The `spec` parts of C-TOP's `W5Contract` fields (`F2e2e/C/Impl/W6Contracts.lean`) for the bodies of
`F2e2e/C/Impl/BankDefs.lean`:

* 758 `roundMantQ_spec`, 759 `guardMant_spec`, 760 `stepCoeffMant_spec` (arithmetic, from
  `BankLib` alone);
* 761 `rescaleLearner_spec`, 762 `countCorrection_spec`, 763 `inRangeA_spec`, 764 `inRangeC_spec`,
  765 `learnerInRange_spec` (they call W1's parameter routines, `W1Contract`).

`F2e2e/C/Impl/BankContract.lean` assembles each field as `⟨body_X, hlib.X, X_spec …⟩`.
**The statements are fixed** (they are the contract fields verbatim).

Proofs (A-VAL 914e80f8): goal-directed `EvalsVal` derivations with W5's rules (`BankRules`), the
library specs (`pow2_spec`, `natSqrt_val`, `floorSqrtND_val`, `ceilSqrtND_val`, `clampZ_val`,
`bkRDiv_val`) and W1's `ParamSpec` (`bkE_param`). Every value bound follows from
`Mv R P ≥ 2^16 · regBits P` (`bkE_RM`) and the bit lengths of the stored integers. The reference
values are rewritten to the integer forms computed by the bodies: `bkE_guardMant_eq` (`⌊4 C² 2^k⌋` as
`bkE_gN`), `bkE_stepCoeffMant_eq` (`M = MN/MD`, `bkE_sMN`/`bkE_sMD`), `rdivZ_eq_roundMant`.
Helper names carry the prefix `bkE_`.
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## Size helpers -/

/-- The value bound dominates `2^16 · regBits P`, and `regBits P ≥ 100`. -/
theorem bkE_RM (R : AdaRep) (P : StreamParams) {M : ℕ} (hM : Mv R P ≤ M) :
    65536 * regBits P ≤ M ∧ 100 ≤ regBits P := by
  have h := W2.calL_cube_le_Mv R P
  have h1 := hundred_le_calL P
  have h3 : 100 ≤ P.calL ^ 3 := h1.trans (Nat.le_self_pow (by norm_num) _)
  unfold regBits
  constructor
  · calc 65536 * (2 ^ 7 * P.calL ^ 3) ≤ 2 ^ 37 * P.calL ^ 3 := by
          rw [← mul_assoc]; exact Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ M := h.trans hM
  · calc 100 ≤ P.calL ^ 3 := h3
      _ ≤ 2 ^ 7 * P.calL ^ 3 := Nat.le_mul_of_pos_left _ (by norm_num)

/-- `ℒ ≤ ℒ² ≤ ℒ³ ≤ regBits P`. -/
theorem bkE_calL_le (P : StreamParams) :
    P.calL ≤ P.calL ^ 2 ∧ P.calL ^ 2 ≤ P.calL ^ 3 ∧ P.calL ^ 3 ≤ regBits P := by
  have h1 := hundred_le_calL P
  refine ⟨Nat.le_self_pow (by norm_num) _, Nat.pow_le_pow_right (by omega) (by norm_num), ?_⟩
  unfold regBits
  exact Nat.le_mul_of_pos_left _ (by norm_num)

theorem bkE_num_le {P : StreamParams} {x : ℚ} (h : QOK P x) : bitLen x.num ≤ 4 * regBits P + 1 :=
  SizeAux.bitLen_le_of_abs_le h.1

theorem bkE_den_le {P : StreamParams} {x : ℚ} (h : QOK P x) :
    bitLen (x.den : ℤ) ≤ 4 * regBits P + 1 :=
  SizeAux.bitLen_le_of_nonneg_le (by positivity) h.2

theorem bkE_encQ_eq (x : ℚ) : encQ x = Val.list [Val.int x.num, Val.int (x.den : ℤ)] := rfl

theorem bkE_encLearner_eq (L : Learner) :
    encLearner L = Val.list [Val.int L.tag, Val.int L.cache, Val.int (L.epoch : ℤ),
      Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)] := rfl

/-- The encoded parameters have size at most `5ℒ + 11` (as C-TOP's `W6.valSize_encStreamParams_le`). -/
theorem bkE_valSize_encP_le (P : StreamParams) : valSize (encStreamParams P) ≤ 5 * P.calL + 11 := by
  have hn : P.n < 2 ^ cP P := by have := n_add_two_le P; omega
  have hm : P.m < 2 ^ cP P := by have := m_add_two_le P; omega
  have hU : P.U < 2 ^ cP P := by
    have h := prod_le_two_pow_cP P
    have h1 : P.U + 2 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) :=
      Nat.le_mul_of_pos_left _ (by positivity)
    omega
  have hc := cP_add_hundred_le P
  have he : P.epsExp ≤ P.calL := by rw [calL_eq_cP]; omega
  have hb : P.betaExp ≤ P.calL := by rw [calL_eq_cP]; omega
  simp only [encStreamParams, valSize_encInts, List.map_cons, List.map_nil, List.sum_cons,
    List.sum_nil, bitLen_natCast]
  have h1 := Nat.size_le.mpr hn
  have h2 := Nat.size_le.mpr hm
  have h3 := Nat.size_le.mpr hU
  have h4 := size_le_self P.epsExp
  have h5 := size_le_self P.betaExp
  omega

/-- `bitLen (a + b) ≤ bitLen a + bitLen b + 1`. -/
theorem bkE_bitLen_add (a b : ℤ) : bitLen (a + b) ≤ bitLen a + bitLen b + 1 :=
  (bitLen_add_le a b).trans (Nat.add_le_add_right (max_le (Nat.le_add_right _ _)
    (Nat.le_add_left _ _)) 1)

/-- `bitLen (a - b) ≤ bitLen a + bitLen b + 1`. -/
theorem bkE_bitLen_sub (a b : ℤ) : bitLen (a - b) ≤ bitLen a + bitLen b + 1 := by
  have h := bkE_bitLen_add a (-b)
  rw [bitLen_neg] at h
  rwa [sub_eq_add_neg]

/-- An integer with `|z| ≤ n` has at most `n` bits. -/
theorem bkE_bitLen_le_of_abs_le_nat {z : ℤ} {n : ℕ} (h : |z| ≤ (n : ℤ)) : bitLen z ≤ n := by
  apply bitLen_le_of_abs_lt
  have h2 : (n : ℤ) < 2 ^ n := by exact_mod_cast Nat.lt_two_pow_self
  linarith

theorem bkE_bitLen_two_pow (k : ℕ) : bitLen (((2 ^ k : ℕ) : ℤ)) = k + 1 := by
  rw [bitLen_natCast, Nat.size_pow]

/-! ## Calls of library routines and parameters -/

section calls

variable {prog : List Expr} {M : ℕ}

/-- `pow2` on a natural argument. -/
theorem bkE_pow2 (hlib : BankLib prog) {env : List Val} {a : Expr} {k : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.int (k : ℤ))) (hM : 20 * k + 100 ≤ M) :
    EvalsVal prog M env [] (.inl (ePow2 a)) (Val.int ((2 ^ k : ℕ) : ℤ)) := by
  have hs := size_le_self k
  exact ev_call hlib.pow2 ha ((pow2_spec hlib.pow2Step k 0).toVal.mono_M (by unfold Cost.S_pow2; omega))

/-- `pow2` on a nonnegative integer argument. -/
theorem bkE_pow2_int (hlib : BankLib prog) {env : List Val} {a : Expr} {z : ℤ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.int z)) (hz : 0 ≤ z) (hM : 20 * z.toNat + 100 ≤ M) :
    EvalsVal prog M env [] (.inl (ePow2 a)) (Val.int ((2 ^ z.toNat : ℕ) : ℤ)) := by
  have e : z = ((z.toNat : ℕ) : ℤ) := (Int.toNat_of_nonneg hz).symm
  rw [e] at ha
  exact bkE_pow2 hlib ha hM

/-- A W1 parameter routine called on the encoded parameters. -/
theorem bkE_param {R : AdaRep} {idx : ℕ} {f : StreamParams → ℕ} (h : ParamSpec R prog M idx f)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {env : List Val} {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (encStreamParams P)) :
    EvalsVal prog M env [] (.inl (eCall idx a)) (Val.int (f P : ℤ)) := by
  obtain ⟨b, hb, hs⟩ := h
  exact ev_call hb ha (hs P hP hM)

end calls

/-! ## Order facts for the range checks -/

theorem bkE_rat_le_nat_iff (x : ℚ) (A : ℕ) : x ≤ (A : ℚ) ↔ x.num ≤ (A : ℤ) * (x.den : ℤ) := by
  have hd : (0 : ℚ) < x.den := by exact_mod_cast x.pos
  conv_lhs => rw [← Rat.num_div_den x]
  rw [div_le_iff₀ hd]
  constructor
  · intro h; exact_mod_cast h
  · intro h; exact_mod_cast h

theorem bkE_inRange_iff (x : ℚ) (A : ℕ) :
    (0 ≤ x ∧ x ≤ (A : ℚ)) ↔ (0 ≤ x.num ∧ x.num ≤ (A : ℤ) * (x.den : ℤ)) := by
  rw [bkE_rat_le_nat_iff, Rat.num_nonneg]

theorem bkE_grid_iff (m : ℤ) (q C : ℕ) :
    (0 ≤ gridVal q m ∧ gridVal q m ≤ (C : ℚ)) ↔ (0 ≤ m ∧ m ≤ (C : ℤ) * ((2 ^ q : ℕ) : ℤ)) := by
  unfold gridVal
  have hp : (0 : ℚ) < 2 ^ q := by positivity
  rw [le_div_iff₀ hp, div_le_iff₀ hp, zero_mul]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨by exact_mod_cast h1, ?_⟩
    have h2' : (m : ℚ) ≤ (((C : ℤ) * ((2 ^ q : ℕ) : ℤ) : ℤ) : ℚ) := by push_cast; exact h2
    exact_mod_cast h2'
  · rintro ⟨h1, h2⟩
    refine ⟨by exact_mod_cast h1, ?_⟩
    have h2' : (m : ℚ) ≤ (((C : ℤ) * ((2 ^ q : ℕ) : ℤ) : ℤ) : ℚ) := by exact_mod_cast h2
    push_cast at h2'
    exact h2'

/-! ## `guardMant`: the reference value and the two conditional steps -/

/-- The integer `N = ⌊4 C² 2^k⌋` computed by `body_guardMant` (`k = 2α + e`). -/
def bkE_gN (C k : ℤ) : ℤ :=
  if k < 0 then 4 * (C * C) / ((2 ^ (-k).toNat : ℕ) : ℤ) else 4 * (C * C) * ((2 ^ k.toNat : ℕ) : ℤ)

theorem bkE_floor_gN (C k : ℤ) : ⌊4 * ((C : ℚ) ^ 2 * (2 : ℚ) ^ k)⌋ = bkE_gN C k := by
  unfold bkE_gN
  split_ifs with hk
  · obtain ⟨m, rfl⟩ : ∃ m : ℕ, k = -(m : ℤ) :=
      ⟨(-k).toNat, by rw [Int.toNat_of_nonneg (by omega)]; ring⟩
    have e1 : (-(-(m : ℤ))).toNat = m := by simp
    rw [e1, zpow_neg, zpow_natCast]
    have e2 : 4 * ((C : ℚ) ^ 2 * ((2 : ℚ) ^ m)⁻¹) =
        ((4 * (C * C) : ℤ) : ℚ) / ((((2 ^ m : ℕ) : ℤ)) : ℚ) := by
      push_cast; ring
    rw [e2, floor_div_intCast _ _ (by positivity)]
  · obtain ⟨m, rfl⟩ : ∃ m : ℕ, k = (m : ℤ) := ⟨k.toNat, (Int.toNat_of_nonneg (by omega)).symm⟩
    have e1 : ((m : ℤ)).toNat = m := by simp
    rw [e1, zpow_natCast]
    have e2 : 4 * ((C : ℚ) ^ 2 * (2 : ℚ) ^ m) = ((4 * (C * C) * ((2 ^ m : ℕ) : ℤ) : ℤ) : ℚ) := by
      push_cast; ring
    rw [e2, Int.floor_intCast]

/-- `guardMant` in the integer form of `body_guardMant`. -/
theorem bkE_guardMant_eq (C α e : ℤ) :
    guardMant C α e = if bkE_gN C (2 * α + e) < 16 then 0
      else (((Nat.sqrt (bkE_gN C (2 * α + e)).toNat : ℕ) : ℤ) + 1) / 2 := by
  have hfl := bkE_floor_gN C (2 * α + e)
  have hlt : ((C : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e) < 4) ↔ bkE_gN C (2 * α + e) < 16 := by
    rw [← hfl, Int.floor_lt]
    push_cast
    constructor <;> intro h <;> linarith
  unfold guardMant floorSqrtQ
  dsimp only
  by_cases h : bkE_gN C (2 * α + e) < 16
  · rw [if_pos (hlt.mpr h), if_pos h]
  · rw [if_neg (fun h' => h (hlt.mp h')), if_neg h, hfl]
    push_cast
    rfl

section guardSteps

variable {prog : List Expr} {M : ℕ}

/-- The `N`-step of `body_guardMant` (environment `[4C², k, …]`). -/
theorem bkE_guardN_val (hlib : BankLib prog) (C k : ℤ) (rest : List Val) (K B : ℕ)
    (hk : |k| ≤ (K : ℤ)) (hFb : bitLen (4 * (C * C)) ≤ B) (hM : 2 * B + 24 * K + 200 ≤ M) :
    EvalsVal prog M (Val.int (4 * (C * C)) :: Val.int k :: rest) [] (.inl (eIte (eLt (eV 1) (eLit 0))
        (eDiv (eV 0) (ePow2 (eNeg (eV 1)))) (eMul (eV 0) (ePow2 (eV 1)))))
      (Val.int (bkE_gN C k)) := by
  have hkb : bitLen k ≤ K := bkE_bitLen_le_of_abs_le_nat hk
  have hk' := abs_le.mp hk
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  unfold bkE_gN
  by_cases hk0 : k < 0
  · rw [if_pos hk0]
    have hnk : 0 ≤ -k := by omega
    have hcast : (((-k).toNat : ℕ) : ℤ) = -k := Int.toNat_of_nonneg hnk
    have hmK : (-k).toNat ≤ K := by omega
    have hd := bitLen_ediv_le (4 * (C * C)) ((2 ^ (-k).toNat : ℕ) : ℤ)
    exact ev_ite_t (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_pos hk0]; exact one_ne_zero)
      (ev_div (ev_var rfl) (bkE_pow2_int hlib (ev_neg (ev_var rfl) (by simp only [valSize_int]; omega))
          hnk (by omega)) (by positivity) (by simp only [valSize_int]; omega))
  · rw [if_neg hk0]
    have hk0' : 0 ≤ k := by omega
    have hcast : ((k.toNat : ℕ) : ℤ) = k := Int.toNat_of_nonneg hk0'
    have hmK : k.toNat ≤ K := by omega
    have hp := bkE_bitLen_two_pow k.toNat
    have hmul := bitLen_mul_le' (4 * (C * C)) ((2 ^ k.toNat : ℕ) : ℤ)
    exact ev_ite_f (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_neg hk0])
      (ev_mul (ev_var rfl) (bkE_pow2_int hlib (ev_var rfl) hk0' (by omega))
        (by simp only [valSize_int]; omega))

/-- The final step of `body_guardMant` (environment `[N, …]`, `N ≥ 0`). -/
theorem bkE_guardFin_val (hlib : BankLib prog) (N : ℤ) (rest : List Val) (hN : 0 ≤ N) (B : ℕ)
    (hNb : bitLen N ≤ B) (hM : 30 * B + 200 ≤ M) :
    EvalsVal prog M (Val.int N :: rest) [] (.inl (eIte (eLt (eV 0) (eLit 16)) (eLit 0)
        (eDiv (eAdd (eCall Cost.Idx.natSqrt (eV 0)) (eLit 1)) (eLit 2))))
      (Val.int (if N < 16 then 0 else (((Nat.sqrt N.toNat : ℕ) : ℤ) + 1) / 2)) := by
  obtain ⟨n, rfl⟩ : ∃ n : ℕ, N = (n : ℤ) := ⟨N.toNat, (Int.toNat_of_nonneg hN).symm⟩
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have h16 : bitLen (16 : ℤ) ≤ 5 := bitLen_le_of_abs_lt (by norm_num)
  have hl16 : valSize (Val.int 16) ≤ M := by simp only [valSize_int]; omega
  have hsn : Nat.size n ≤ B := by rw [← bitLen_natCast]; exact hNb
  have hsqb : bitLen ((Nat.sqrt n : ℕ) : ℤ) ≤ B := (bitLen_mono_nat (Nat.sqrt_le_self n)).trans hNb
  have hs1 := bkE_bitLen_add ((Nat.sqrt n : ℕ) : ℤ) 1
  have hdv := bitLen_ediv_le (((Nat.sqrt n : ℕ) : ℤ) + 1) 2
  have e1 : ((n : ℤ)).toNat = n := by simp
  rw [e1]
  by_cases h16' : (n : ℤ) < 16
  · rw [if_pos h16']
    exact ev_ite_t (ev_lt (ev_var rfl) (ev_lit hl16) hM2) (by rw [if_pos h16']; exact one_ne_zero)
      (ev_lit hl0)
  · rw [if_neg h16']
    exact ev_ite_f (ev_lt (ev_var rfl) (ev_lit hl16) hM2) (by rw [if_neg h16'])
      (ev_div (ev_add (ev_call hlib.natSqrt (ev_var rfl) (natSqrt_val hlib.natSqrtStep n (by omega)))
          (ev_lit hl1) (by simp only [valSize_int, bitLen_one] at hs1 ⊢; omega))
        (ev_lit hl2) (by norm_num) (by simp only [valSize_int, bitLen_one] at hs1 ⊢; omega))

end guardSteps

/-! ## `stepCoeffMant`: the reference value and the conditional steps -/

/-- The numerator `MN` of `M = (P/Q̂) 2^k = MN/MD` computed by `body_stepCoeffMant`. -/
def bkE_sMN (num k : ℤ) : ℤ := if k < 0 then num else num * ((2 ^ k.toNat : ℕ) : ℤ)

/-- The denominator `MD` of `M = MN/MD`. -/
def bkE_sMD (den k : ℤ) : ℤ := if k < 0 then den * ((2 ^ (-k).toNat : ℕ) : ℤ) else den

theorem bkE_sM_eq (num den k : ℤ) :
    ((num : ℚ) / (den : ℚ)) * (2 : ℚ) ^ k = ((bkE_sMN num k : ℤ) : ℚ) / ((bkE_sMD den k : ℤ) : ℚ) := by
  unfold bkE_sMN bkE_sMD
  split_ifs with hk
  · obtain ⟨m, rfl⟩ : ∃ m : ℕ, k = -(m : ℤ) :=
      ⟨(-k).toNat, by rw [Int.toNat_of_nonneg (by omega)]; ring⟩
    have e1 : (-(-(m : ℤ))).toNat = m := by simp
    rw [e1, zpow_neg, zpow_natCast]
    push_cast
    rw [← div_eq_mul_inv, div_div]
  · obtain ⟨m, rfl⟩ : ∃ m : ℕ, k = (m : ℤ) := ⟨k.toNat, (Int.toNat_of_nonneg (by omega)).symm⟩
    have e1 : ((m : ℤ)).toNat = m := by simp
    rw [e1, zpow_natCast]
    push_cast
    rw [div_mul_eq_mul_div]

theorem bkE_floorSqrtND_le (num den : ℤ) (hnum : 0 ≤ num) (hden : 0 < den) :
    ((floorSqrtND num den : ℕ) : ℤ) ≤ num := by
  unfold floorSqrtND
  have h1 : Nat.sqrt (num / den).toNat ≤ (num / den).toNat := Nat.sqrt_le_self _
  have h2 : (((num / den).toNat : ℕ) : ℤ) = num / den :=
    Int.toNat_of_nonneg (Int.ediv_nonneg hnum hden.le)
  have h3 : num / den ≤ num := Int.ediv_le_self den hnum
  have h1' : ((Nat.sqrt (num / den).toNat : ℕ) : ℤ) ≤ (((num / den).toNat : ℕ) : ℤ) := by
    exact_mod_cast h1
  linarith

theorem bkE_ceilSqrtND_le (num den : ℤ) (hnum : 0 ≤ num) (hden : 0 < den) :
    ((ceilSqrtND num den : ℕ) : ℤ) ≤ num + 1 := by
  have hq0 : (-num) / den ≤ 0 := Int.ediv_nonpos_of_nonpos_of_neg (by omega) hden
  have hq : -((-num) / den) ≤ num := by
    have := (Int.le_ediv_iff_mul_le hden).mpr (show (-num) * den ≤ -num by nlinarith)
    linarith
  have hN : (((-((-num) / den)).toNat : ℕ) : ℤ) = -((-num) / den) :=
    Int.toNat_of_nonneg (by linarith)
  have hs : ((Nat.sqrt (-((-num) / den)).toNat : ℕ) : ℤ) ≤ (((-((-num) / den)).toNat : ℕ) : ℤ) := by
    exact_mod_cast Nat.sqrt_le_self _
  unfold ceilSqrtND
  dsimp only
  split_ifs
  · linarith
  · push_cast
    linarith

theorem bkE_bitLen_le_of_le {a b : ℤ} (h0 : 0 ≤ a) (h : a ≤ b) : bitLen a ≤ bitLen b := by
  apply bitLen_le_bitLen_of_natAbs_le
  have h1 := Int.natAbs_of_nonneg h0
  have h2 := Int.natAbs_of_nonneg (h0.trans h)
  omega

theorem bkE_sA_bitLen (pos : Bool) (MN MD : ℤ) (hMN : 0 ≤ MN) (hMD : 0 < MD) :
    bitLen (if pos then (((floorSqrtND MN MD : ℕ) : ℤ) + 1) / 2
      else -(((ceilSqrtND MN MD : ℕ) : ℤ) / 2)) ≤ bitLen MN + 2 := by
  have hf := bkE_floorSqrtND_le MN MD hMN hMD
  have hc := bkE_ceilSqrtND_le MN MD hMN hMD
  have hfb : bitLen ((floorSqrtND MN MD : ℕ) : ℤ) ≤ bitLen MN := bkE_bitLen_le_of_le (by positivity) hf
  have h1 := bkE_bitLen_add MN 1
  have hcb : bitLen ((ceilSqrtND MN MD : ℕ) : ℤ) ≤ bitLen (MN + 1) :=
    bkE_bitLen_le_of_le (by positivity) hc
  rw [bitLen_one] at h1
  split_ifs
  · have := bitLen_ediv_le (((floorSqrtND MN MD : ℕ) : ℤ) + 1) 2
    have := bkE_bitLen_add ((floorSqrtND MN MD : ℕ) : ℤ) 1
    rw [bitLen_one] at this
    omega
  · rw [bitLen_neg]
    have := bitLen_ediv_le ((ceilSqrtND MN MD : ℕ) : ℤ) 2
    omega

theorem bkE_sMN_bounds (num k : ℤ) (K : ℕ) (hnum : 0 ≤ num) (hk : |k| ≤ (K : ℤ)) :
    0 ≤ bkE_sMN num k ∧ bitLen (bkE_sMN num k) ≤ bitLen num + K + 1 := by
  have hk' := abs_le.mp hk
  unfold bkE_sMN
  split_ifs with hk0
  · exact ⟨hnum, by omega⟩
  · have hcast : ((k.toNat : ℕ) : ℤ) = k := Int.toNat_of_nonneg (by omega)
    have hp := bkE_bitLen_two_pow k.toNat
    have hmul := bitLen_mul_le' num ((2 ^ k.toNat : ℕ) : ℤ)
    exact ⟨by positivity, by omega⟩

theorem bkE_sMD_bounds (den k : ℤ) (K : ℕ) (hden : 0 < den) (hk : |k| ≤ (K : ℤ)) :
    0 < bkE_sMD den k ∧ bitLen (bkE_sMD den k) ≤ bitLen den + K + 1 := by
  have hk' := abs_le.mp hk
  unfold bkE_sMD
  split_ifs with hk0
  · have hcast : (((-k).toNat : ℕ) : ℤ) = -k := Int.toNat_of_nonneg (by omega)
    have hp := bkE_bitLen_two_pow (-k).toNat
    have hmul := bitLen_mul_le' den ((2 ^ (-k).toNat : ℕ) : ℤ)
    exact ⟨by positivity, by omega⟩
  · exact ⟨hden, by omega⟩

/-- `stepCoeffMant` in the integer form of `body_stepCoeffMant`. -/
theorem bkE_stepCoeffMant_eq (pos : Bool) (qη qs : ℕ) (Pval Qhat : ℚ) (hP0 : 0 < Pval)
    (hQ0 : 0 < Qhat) :
    stepCoeffMant pos qη qs Pval Qhat =
      ((2 ^ qs : ℕ) : ℤ) + max (-(((2 ^ qs : ℕ) : ℤ) / 2)) (min (((2 ^ qs : ℕ) : ℤ) / 2)
        (if pos then (((floorSqrtND (bkE_sMN (Pval.num * Qhat.den) (2 * ((qs : ℤ) - (qη : ℤ)) - 6))
              (bkE_sMD (Pval.den * Qhat.num) (2 * ((qs : ℤ) - (qη : ℤ)) - 6)) : ℕ) : ℤ) + 1) / 2
          else -(((ceilSqrtND (bkE_sMN (Pval.num * Qhat.den) (2 * ((qs : ℤ) - (qη : ℤ)) - 6))
              (bkE_sMD (Pval.den * Qhat.num) (2 * ((qs : ℤ) - (qη : ℤ)) - 6)) : ℕ) : ℤ) / 2))) := by
  have hQn : 0 < Qhat.num := Rat.num_pos.mpr hQ0
  have hden : (0 : ℤ) < (Pval.den : ℤ) * Qhat.num := mul_pos (by exact_mod_cast Pval.pos) hQn
  have hMD : 0 < bkE_sMD (Pval.den * Qhat.num) (2 * ((qs : ℤ) - (qη : ℤ)) - 6) := by
    unfold bkE_sMD; split_ifs <;> positivity
  have e1 : Pval / Qhat = ((Pval.num * Qhat.den : ℤ) : ℚ) / (((Pval.den : ℤ) * Qhat.num : ℤ) : ℚ) := by
    have hQn' : (Qhat.num : ℚ) ≠ 0 := by exact_mod_cast hQn.ne'
    have hPd : (Pval.den : ℚ) ≠ 0 := by positivity
    have hQd : (Qhat.den : ℚ) ≠ 0 := by positivity
    conv_lhs => rw [← Rat.num_div_den Pval, ← Rat.num_div_den Qhat]
    push_cast
    field_simp
  have hMeq : Pval / Qhat * (2 : ℚ) ^ (2 * (qs : ℤ) - 2 * (qη : ℤ) - 6) =
      ((bkE_sMN (Pval.num * Qhat.den) (2 * ((qs : ℤ) - (qη : ℤ)) - 6) : ℤ) : ℚ) /
        ((bkE_sMD (Pval.den * Qhat.num) (2 * ((qs : ℤ) - (qη : ℤ)) - 6) : ℤ) : ℚ) := by
    rw [show (2 * (qs : ℤ) - 2 * (qη : ℤ) - 6) = 2 * ((qs : ℤ) - (qη : ℤ)) - 6 by ring, e1,
      bkE_sM_eq]
  unfold stepCoeffMant floorSqrtQ ceilSqrtQ clampZ
  dsimp only
  rw [hMeq, ← floorDivZ_eq _ _ hMD, ← ceilDivZ_eq _ _ hMD]
  unfold floorSqrtND ceilSqrtND
  cases pos <;> simp

section stepSteps

variable {prog : List Expr} {M : ℕ}

/-- The `MN`-step of `body_stepCoeffMant` (environment `[den, num, k, …]`). -/
theorem bkE_sMN_val (hlib : BankLib prog) (den num k : ℤ) (rest : List Val) (K B : ℕ)
    (hk : |k| ≤ (K : ℤ)) (hnb : bitLen num ≤ B) (hM : 2 * B + 24 * K + 200 ≤ M) :
    EvalsVal prog M (Val.int den :: Val.int num :: Val.int k :: rest) []
      (.inl (eIte (eLt (eV 2) (eLit 0)) (eV 1) (eMul (eV 1) (ePow2 (eV 2)))))
      (Val.int (bkE_sMN num k)) := by
  have hkb : bitLen k ≤ K := bkE_bitLen_le_of_abs_le_nat hk
  have hk' := abs_le.mp hk
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  unfold bkE_sMN
  by_cases hk0 : k < 0
  · rw [if_pos hk0]
    exact ev_ite_t (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_pos hk0]; exact one_ne_zero)
      (ev_var rfl)
  · rw [if_neg hk0]
    have hk0' : 0 ≤ k := by omega
    have hcast : ((k.toNat : ℕ) : ℤ) = k := Int.toNat_of_nonneg hk0'
    have hmK : k.toNat ≤ K := by omega
    have hp := bkE_bitLen_two_pow k.toNat
    have hmul := bitLen_mul_le' num ((2 ^ k.toNat : ℕ) : ℤ)
    exact ev_ite_f (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_neg hk0])
      (ev_mul (ev_var rfl) (bkE_pow2_int hlib (ev_var rfl) hk0' (by omega))
        (by simp only [valSize_int]; omega))

/-- The `MD`-step of `body_stepCoeffMant` (environment `[MN, den, num, k, …]`). -/
theorem bkE_sMD_val (hlib : BankLib prog) (MN den num k : ℤ) (rest : List Val) (K B : ℕ)
    (hk : |k| ≤ (K : ℤ)) (hdb : bitLen den ≤ B) (hM : 2 * B + 24 * K + 200 ≤ M) :
    EvalsVal prog M (Val.int MN :: Val.int den :: Val.int num :: Val.int k :: rest) []
      (.inl (eIte (eLt (eV 3) (eLit 0)) (eMul (eV 1) (ePow2 (eNeg (eV 3)))) (eV 1)))
      (Val.int (bkE_sMD den k)) := by
  have hkb : bitLen k ≤ K := bkE_bitLen_le_of_abs_le_nat hk
  have hk' := abs_le.mp hk
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  unfold bkE_sMD
  by_cases hk0 : k < 0
  · rw [if_pos hk0]
    have hnk : 0 ≤ -k := by omega
    have hcast : (((-k).toNat : ℕ) : ℤ) = -k := Int.toNat_of_nonneg hnk
    have hmK : (-k).toNat ≤ K := by omega
    have hp := bkE_bitLen_two_pow (-k).toNat
    have hmul := bitLen_mul_le' den ((2 ^ (-k).toNat : ℕ) : ℤ)
    exact ev_ite_t (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_pos hk0]; exact one_ne_zero)
      (ev_mul (ev_var rfl) (bkE_pow2_int hlib (ev_neg (ev_var rfl)
          (by simp only [valSize_int]; omega)) hnk (by omega))
        (by simp only [valSize_int]; omega))
  · rw [if_neg hk0]
    exact ev_ite_f (ev_lt (ev_var rfl) (ev_lit hl0) hM2) (by rw [if_neg hk0]) (ev_var rfl)

/-- The `a`-step of `body_stepCoeffMant` (environment `[MD, MN, _, _, _, _, _, I, …]`). -/
theorem bkE_sA_val (hlib : BankLib prog) (pos : Bool) (MD MN : ℤ) (v2 v3 v4 v5 v6 : Val)
    (restI rest : List Val) (hMN : 0 ≤ MN) (hMD : 0 < MD) (B : ℕ) (hNb : bitLen MN ≤ B)
    (hDb : bitLen MD ≤ B) (hI : valSize (Val.list (Val.int (if pos then 1 else 0) :: restI)) ≤ M)
    (hM : 40 * B + 300 ≤ M) :
    EvalsVal prog M (Val.int MD :: Val.int MN :: v2 :: v3 :: v4 :: v5 :: v6 ::
        Val.list (Val.int (if pos then 1 else 0) :: restI) :: rest) []
      (.inl (eIte (eEq (eHd (eV 7)) (eLit 0))
        (eNeg (eDiv (eCall Cost.Idx.ceilSqrtND (ePair (eV 1) (eV 0))) (eLit 2)))
        (eDiv (eAdd (eCall Cost.Idx.floorSqrtND (ePair (eV 1) (eV 0))) (eLit 1)) (eLit 2))))
      (Val.int (if pos then (((floorSqrtND MN MD : ℕ) : ℤ) + 1) / 2
        else -(((ceilSqrtND MN MD : ℕ) : ℤ) / 2))) := by
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have hpair : valSize (Val.list [Val.int MN, Val.int MD]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hf := bkE_floorSqrtND_le MN MD hMN hMD
  have hc := bkE_ceilSqrtND_le MN MD hMN hMD
  have hfb : bitLen ((floorSqrtND MN MD : ℕ) : ℤ) ≤ bitLen MN :=
    bkE_bitLen_le_of_le (by positivity) hf
  have h1 := bkE_bitLen_add MN 1
  have hcb : bitLen ((ceilSqrtND MN MD : ℕ) : ℤ) ≤ bitLen (MN + 1) :=
    bkE_bitLen_le_of_le (by positivity) hc
  rw [bitLen_one] at h1
  have hf1 := bkE_bitLen_add ((floorSqrtND MN MD : ℕ) : ℤ) 1
  rw [bitLen_one] at hf1
  have hdf := bitLen_ediv_le (((floorSqrtND MN MD : ℕ) : ℤ) + 1) 2
  have hdc := bitLen_ediv_le ((ceilSqrtND MN MD : ℕ) : ℤ) 2
  cases pos
  · rw [if_neg Bool.false_ne_true]
    exact ev_ite_t (ev_eq (ev_hd (ev_var rfl) hI) (ev_lit hl0) hM2) (by simp)
      (ev_neg (ev_div (ev_call hlib.ceilSqrtND (ev_pair (ev_var rfl) (ev_var rfl) hpair)
          (ceilSqrtND_val hlib.natSqrt hlib.natSqrtStep MN MD hMN hMD (by omega)))
        (ev_lit hl2) (by norm_num) (by simp only [valSize_int]; omega))
        (by simp only [valSize_int]; omega))
  · rw [if_pos rfl]
    exact ev_ite_f (ev_eq (ev_hd (ev_var rfl) hI) (ev_lit hl0) hM2) (by simp)
      (ev_div (ev_add (ev_call hlib.floorSqrtND (ev_pair (ev_var rfl) (ev_var rfl) hpair)
          (floorSqrtND_val hlib.natSqrt hlib.natSqrtStep MN MD hMN hMD (by omega)))
          (ev_lit hl1) (by simp only [valSize_int]; omega))
        (ev_lit hl2) (by norm_num) (by simp only [valSize_int]; omega))

/-- The final step of `body_stepCoeffMant` (environment `[T, a, …]`). -/
theorem bkE_sFin_val (hlib : BankLib prog) (T a : ℤ) (rest : List Val) (B : ℕ)
    (hTb : bitLen T ≤ B) (hab : bitLen a ≤ B) (hM : 40 * B + 200 ≤ M) :
    EvalsVal prog M (Val.int T :: Val.int a :: rest) []
      (.inl (eAdd (eV 0) (eCall Cost.Idx.clampZ
        (eList [eNeg (eDiv (eV 0) (eLit 2)), eDiv (eV 0) (eLit 2), eV 1]))))
      (Val.int (T + max (-(T / 2)) (min (T / 2) a))) := by
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have hd := bitLen_ediv_le T 2
  have hmx : bitLen (max (-(T / 2)) (min (T / 2) a)) ≤ B := by
    rw [max_def, min_def]
    split_ifs <;> (try simp only [bitLen_neg]) <;> omega
  have hadd := bkE_bitLen_add T (max (-(T / 2)) (min (T / 2) a))
  exact ev_add (ev_var rfl) (ev_call hlib.clampZ
      (ev_list (.cons (ev_neg (ev_div (ev_var rfl) (ev_lit hl2) (by norm_num)
          (by simp only [valSize_int]; omega)) (by simp only [valSize_int]; omega))
        (.cons (ev_div (ev_var rfl) (ev_lit hl2) (by norm_num) (by simp only [valSize_int]; omega))
          (.cons (ev_var rfl) .nil)))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_neg]; omega))
      (clampZ_val prog _ _ _ (by simp only [bitLen_neg]; omega)))
    (by simp only [valSize_int]; omega)

end stepSteps

section entries

variable (R : AdaRep) {prog : List Expr} {M : ℕ}

/-- 758 (`W5Contract.roundMantQ`). -/
theorem roundMantQ_spec (hlib : BankLib prog) (P : StreamParams) (q : ℕ) (z : ℚ)
    (hP : ParamsOK P) (hq : q ≤ regBits P) (hz : QOK P z) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encN q, encQ z]] [] (.inl body_roundMantQ)
      (Val.int (roundMant q z)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hn := bkE_num_le hz
  have hd := bkE_den_le hz
  have hsq : Nat.size q ≤ q := size_le_self q
  have hden : (0 : ℤ) < (z.den : ℤ) := by exact_mod_cast z.pos
  have hp2 := bkE_bitLen_two_pow q
  have hmulb := bitLen_mul_le' z.num ((2 ^ q : ℕ) : ℤ)
  have hval : rdivZ (z.num * ((2 ^ q : ℕ) : ℤ)) (z.den : ℤ) = roundMant q z := by
    rw [rdivZ_eq _ _ hden]
    unfold roundMant
    congr 1
    have hd0 : (z.den : ℚ) ≠ 0 := by positivity
    have key : (z.num : ℚ) = z * z.den := (Rat.mul_den_eq_num z).symm
    push_cast
    rw [key]
    field_simp
  have hqb : bitLen (q : ℤ) ≤ q := by rw [bitLen_natCast]; exact hsq
  rw [← hval, bkE_encQ_eq, show encN q = Val.int (q : ℤ) from rfl]
  have hI : valSize (Val.list [Val.int (q : ℤ), Val.list [Val.int z.num, Val.int (z.den : ℤ)]]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hQ : valSize (Val.list [Val.int z.num, Val.int (z.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  exact ev_call hlib.bkRDiv
    (ev_pair (ev_mul (ev_hd (ev_at1 (ev_var rfl) hI) hQ)
        (bkE_pow2 hlib (ev_hd (ev_var rfl) hI) (by omega)) (by simp only [valSize_int]; omega))
      (ev_at1 (ev_at1 (ev_var rfl) hI) hQ)
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
    (bkRDiv_val _ _ hden (by omega))

/-- 763 (`W5Contract.inRangeA`). -/
theorem inRangeA_spec (hlib : BankLib prog) (hw1 : W1Contract R prog M) (P : StreamParams)
    (x : ℚ) (hP : ParamsOK P) (hx : QOK P x) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encQ x]] [] (.inl body_inRangeA)
      (encB (inRangeA P x)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hn := bkE_num_le hx
  have hd := bkE_den_le hx
  have hPs := bkE_valSize_encP_le P
  obtain ⟨c1, c2, c3⟩ := bkE_calL_le P
  have hAb : bitLen (P.Amax : ℤ) ≤ 7 * P.calL ^ 3 + 1 := by
    unfold StreamParams.Amax
    rw [bitLen_natCast, Nat.size_pow]
    have := eAmax_le P
    omega
  have hmb := bitLen_mul_le' (P.Amax : ℤ) (x.den : ℤ)
  rw [bkE_encQ_eq]
  have hQ : valSize (Val.list [Val.int x.num, Val.int (x.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hI : valSize (Val.list [encStreamParams P, Val.list [Val.int x.num, Val.int (x.den : ℤ)]]) ≤
      M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hAd : valSize (Val.int ((P.Amax : ℤ) * (x.den : ℤ))) ≤ M := by
    simp only [valSize_int]; omega
  refine ev_let (ev_at1 (ev_var rfl) hI) ?_
  by_cases h0 : x.num < 0
  · have hres : inRangeA P x = false := by
      unfold inRangeA
      rw [decide_eq_false_iff_not, bkE_inRange_iff]
      omega
    rw [hres, encB_false]
    exact ev_ite_t (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_pos h0]; exact one_ne_zero)
      (ev_lit hl0)
  · by_cases h1 : (P.Amax : ℤ) * (x.den : ℤ) < x.num
    · have hres : inRangeA P x = false := by
        unfold inRangeA
        rw [decide_eq_false_iff_not, bkE_inRange_iff]
        omega
      rw [hres, encB_false]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_neg h0])
        (ev_ite_t (ev_lt (ev_mul (bkE_param hw1.pAmax hP hM (ev_hd (ev_var rfl) hI))
          (ev_at1 (ev_var rfl) hQ) hAd) (ev_hd (ev_var rfl) hQ) hM2) (by rw [if_pos h1]; exact one_ne_zero) (ev_lit hl0))
    · have hres : inRangeA P x = true := by
        unfold inRangeA
        rw [decide_eq_true_iff, bkE_inRange_iff]
        omega
      rw [hres, encB_true]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_neg h0])
        (ev_ite_f (ev_lt (ev_mul (bkE_param hw1.pAmax hP hM (ev_hd (ev_var rfl) hI))
          (ev_at1 (ev_var rfl) hQ) hAd) (ev_hd (ev_var rfl) hQ) hM2) (by rw [if_neg h1]) (ev_lit hl1))

/-- 764 (`W5Contract.inRangeC`). -/
theorem inRangeC_spec (hlib : BankLib prog) (hw1 : W1Contract R prog M) (P : StreamParams)
    (x : ℚ) (hP : ParamsOK P) (hx : QOK P x) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encQ x]] [] (.inl body_inRangeC)
      (encB (inRangeC P x)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hn := bkE_num_le hx
  have hd := bkE_den_le hx
  have hPs := bkE_valSize_encP_le P
  obtain ⟨c1, c2, c3⟩ := bkE_calL_le P
  have hCb : bitLen (P.Cmax : ℤ) ≤ 2 * P.calL ^ 2 + 1 := by
    unfold StreamParams.Cmax
    rw [bitLen_natCast, Nat.size_pow]
    have := eCmax_le P
    omega
  have hmb := bitLen_mul_le' (P.Cmax : ℤ) (x.den : ℤ)
  rw [bkE_encQ_eq]
  have hQ : valSize (Val.list [Val.int x.num, Val.int (x.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hI : valSize (Val.list [encStreamParams P, Val.list [Val.int x.num, Val.int (x.den : ℤ)]]) ≤
      M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hCd : valSize (Val.int ((P.Cmax : ℤ) * (x.den : ℤ))) ≤ M := by
    simp only [valSize_int]; omega
  refine ev_let (ev_at1 (ev_var rfl) hI) ?_
  by_cases h0 : x.num < 0
  · have hres : inRangeC P x = false := by
      unfold inRangeC
      rw [decide_eq_false_iff_not, bkE_inRange_iff]
      omega
    rw [hres, encB_false]
    exact ev_ite_t (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_pos h0]; exact one_ne_zero)
      (ev_lit hl0)
  · by_cases h1 : (P.Cmax : ℤ) * (x.den : ℤ) < x.num
    · have hres : inRangeC P x = false := by
        unfold inRangeC
        rw [decide_eq_false_iff_not, bkE_inRange_iff]
        omega
      rw [hres, encB_false]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_neg h0])
        (ev_ite_t (ev_lt (ev_mul (bkE_param hw1.pCmax hP hM (ev_hd (ev_var rfl) hI))
          (ev_at1 (ev_var rfl) hQ) hCd) (ev_hd (ev_var rfl) hQ) hM2) (by rw [if_pos h1]; exact one_ne_zero) (ev_lit hl0))
    · have hres : inRangeC P x = true := by
        unfold inRangeC
        rw [decide_eq_true_iff, bkE_inRange_iff]
        omega
      rw [hres, encB_true]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hQ) (ev_lit hl0) hM2) (by rw [if_neg h0])
        (ev_ite_f (ev_lt (ev_mul (bkE_param hw1.pCmax hP hM (ev_hd (ev_var rfl) hI))
          (ev_at1 (ev_var rfl) hQ) hCd) (ev_hd (ev_var rfl) hQ) hM2) (by rw [if_neg h1]) (ev_lit hl1))

/-- 762 (`W5Contract.countCorrection`). -/
theorem countCorrection_spec (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (P : StreamParams) (L : Learner) (hP : ParamsOK P) (hL : LearnerOK P 4 L) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encLearner L]] [] (.inl body_countCorrection)
      (encOptLearner (Learner.countCorrection P L)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hPs := bkE_valSize_encP_le P
  obtain ⟨c1, c2, c3⟩ := bkE_calL_le P
  obtain ⟨t1, t2, t3, t4, t5⟩ := hL.bitLen_le
  have a1 := bkE_bitLen_add (L.epoch : ℤ) 1
  have a2 := bkE_bitLen_add (L.jEpoch : ℤ) 1
  have a3 := bkE_bitLen_add (L.jUsed : ℤ) 1
  rw [bkE_encLearner_eq]
  have hLe : valSize (Val.list [Val.int L.tag, Val.int L.cache, Val.int (L.epoch : ℤ),
      Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hI : valSize (Val.list [encStreamParams P, Val.list [Val.int L.tag, Val.int L.cache,
      Val.int (L.epoch : ℤ), Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hM2 : 2 ≤ M := by omega
  have hn1 : 1 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hjE1 : valSize (Val.int ((L.jEpoch : ℤ) + 1)) ≤ M := by
    simp only [valSize_int, bitLen_one] at a2 ⊢; omega
  have hep1 : valSize (Val.int ((L.epoch : ℤ) + 1)) ≤ M := by
    simp only [valSize_int, bitLen_one] at a1 ⊢; omega
  have hjU1 : valSize (Val.int ((L.jUsed : ℤ) + 1)) ≤ M := by
    simp only [valSize_int, bitLen_one] at a3 ⊢; omega
  refine ev_let (ev_at1 (ev_var rfl) hI) (ev_let (ev_at2 (ev_var rfl) hLe)
    (ev_let (ev_at3 (ev_var rfl) hLe) (ev_let (ev_at4 (ev_var rfl) hLe) ?_)))
  -- environment `[jU, jE, ep, Le, I]`
  by_cases h1 : L.jEpoch + 1 = P.K0
  · have h1' : (L.jEpoch : ℤ) + 1 = (P.K0 : ℤ) := by exact_mod_cast h1
    by_cases h2 : L.epoch + 1 ≤ P.Kepoch
    · have h2' : ¬ (P.Kepoch : ℤ) < (L.epoch : ℤ) + 1 := by omega
      have hres : encOptLearner (L.countCorrection P) = Val.list [Val.list [Val.int L.tag,
          Val.int L.cache, Val.int ((L.epoch : ℤ) + 1), Val.int 0, Val.int ((L.jUsed : ℤ) + 1)]] := by
        simp [Learner.countCorrection, h1, h2, encOptLearner, bkE_encLearner_eq]
      rw [hres]
      have hout : valSize (Val.list [Val.int L.tag, Val.int L.cache, Val.int ((L.epoch : ℤ) + 1),
          Val.int 0, Val.int ((L.jUsed : ℤ) + 1)]) ≤ M := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero,
          bitLen_one] at a1 a3 ⊢
        omega
      exact ev_ite_t (ev_eq (ev_add (ev_var rfl) (ev_lit hl1) hjE1)
          (bkE_param hw1.pK0 hP hM (ev_hd (ev_var rfl) hI)) hM2)
          (by rw [if_pos h1']; exact one_ne_zero)
        (ev_ite_f (ev_lt (bkE_param hw1.pKepoch hP hM (ev_hd (ev_var rfl) hI))
            (ev_add (ev_var rfl) (ev_lit hl1) hep1) hM2) (by rw [if_neg h2'])
          (ev_list (.cons (ev_list (.cons (ev_hd (ev_var rfl) hLe) (.cons (ev_at1 (ev_var rfl) hLe)
              (.cons (ev_add (ev_var rfl) (ev_lit hl1) hep1) (.cons (ev_lit hl0)
                (.cons (ev_add (ev_var rfl) (ev_lit hl1) hjU1) .nil))))) hout) .nil)
            (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero,
                  bitLen_one] at a1 a3 ⊢
                omega)))
    · have h2' : (P.Kepoch : ℤ) < (L.epoch : ℤ) + 1 := by omega
      have hres : encOptLearner (L.countCorrection P) = Val.list [] := by
        simp [Learner.countCorrection, h1, h2, encOptLearner]
      rw [hres]
      exact ev_ite_t (ev_eq (ev_add (ev_var rfl) (ev_lit hl1) hjE1)
          (bkE_param hw1.pK0 hP hM (ev_hd (ev_var rfl) hI)) hM2)
          (by rw [if_pos h1']; exact one_ne_zero)
        (ev_ite_t (ev_lt (bkE_param hw1.pKepoch hP hM (ev_hd (ev_var rfl) hI))
            (ev_add (ev_var rfl) (ev_lit hl1) hep1) hM2) (by rw [if_pos h2']; exact one_ne_zero)
          (ev_nil hn1))
  · have h1' : ¬ (L.jEpoch : ℤ) + 1 = (P.K0 : ℤ) := by omega
    have hres : encOptLearner (L.countCorrection P) = Val.list [Val.list [Val.int L.tag,
        Val.int L.cache, Val.int (L.epoch : ℤ), Val.int ((L.jEpoch : ℤ) + 1),
        Val.int ((L.jUsed : ℤ) + 1)]] := by
      simp [Learner.countCorrection, h1, encOptLearner, bkE_encLearner_eq]
    rw [hres]
    have hout : valSize (Val.list [Val.int L.tag, Val.int L.cache, Val.int (L.epoch : ℤ),
        Val.int ((L.jEpoch : ℤ) + 1), Val.int ((L.jUsed : ℤ) + 1)]) ≤ M := by
      simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one] at a2 a3 ⊢
      omega
    exact ev_ite_f (ev_eq (ev_add (ev_var rfl) (ev_lit hl1) hjE1)
        (bkE_param hw1.pK0 hP hM (ev_hd (ev_var rfl) hI)) hM2) (by rw [if_neg h1'])
      (ev_list (.cons (ev_list (.cons (ev_hd (ev_var rfl) hLe) (.cons (ev_at1 (ev_var rfl) hLe)
          (.cons (ev_var rfl) (.cons (ev_add (ev_var rfl) (ev_lit hl1) hjE1)
            (.cons (ev_add (ev_var rfl) (ev_lit hl1) hjU1) .nil))))) hout) .nil)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one] at a2 a3 ⊢
            omega))

/-- 761 (`W5Contract.rescaleLearner`). -/
theorem rescaleLearner_spec (hlib : BankLib prog) (hw1 : W1Contract R prog M) (P : StreamParams)
    (cInt : ℤ) (L : Learner) (hP : ParamsOK P) (hL : LearnerOK P 4 L)
    (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encZ cInt, encLearner L]] []
      (.inl body_rescaleLearner) (encLearner (Learner.rescale P cInt L)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hPs := bkE_valSize_encP_le P
  obtain ⟨c1, c2, c3⟩ := bkE_calL_le P
  obtain ⟨t1, t2, t3, t4, t5⟩ := hL.bitLen_le
  have hH := eHstep_le P
  have hcb : bitLen cInt ≤ P.eHstep + 2 := SizeAux.bitLen_le_of_abs_le hc
  have hT := bkE_bitLen_two_pow P.eHstep
  have hTpos : (0 : ℤ) < ((2 ^ P.eHstep : ℕ) : ℤ) := by positivity
  have m1 := bitLen_mul_le' cInt L.tag
  have m2 := bitLen_mul_le' cInt cInt
  have m3 := bitLen_mul_le' (cInt * cInt) L.cache
  have m4 := bitLen_mul_le' ((2 ^ P.eHstep : ℕ) : ℤ) ((2 ^ P.eHstep : ℕ) : ℤ)
  have h1 : rdivZ (cInt * L.tag) ((2 ^ P.eHstep : ℕ) : ℤ) = scaleMant P.eHstep cInt L.tag := by
    rw [rdivZ_eq_roundMant _ _ hTpos]
    unfold scaleMant
    refine congrArg (roundMant 0) ?_
    push_cast
    ring
  have h2 : rdivZ (cInt * cInt * L.cache) (((2 ^ P.eHstep : ℕ) : ℤ) * ((2 ^ P.eHstep : ℕ) : ℤ)) =
      scaleMant (2 * P.eHstep) (cInt ^ 2) L.cache := by
    rw [rdivZ_eq_roundMant _ _ (by positivity)]
    unfold scaleMant
    refine congrArg (roundMant 0) ?_
    push_cast
    ring
  have hres : encLearner (Learner.rescale P cInt L) = Val.list [
      Val.int (rdivZ (cInt * L.tag) ((2 ^ P.eHstep : ℕ) : ℤ)),
      Val.int (rdivZ (cInt * cInt * L.cache) (((2 ^ P.eHstep : ℕ) : ℤ) * ((2 ^ P.eHstep : ℕ) : ℤ))),
      Val.int (L.epoch : ℤ), Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)] := by
    rw [h1, h2]
    rfl
  have r1 := bitLen_rdivZ_le (cInt * L.tag) ((2 ^ P.eHstep : ℕ) : ℤ)
  have r2 := bitLen_rdivZ_le (cInt * cInt * L.cache)
    (((2 ^ P.eHstep : ℕ) : ℤ) * ((2 ^ P.eHstep : ℕ) : ℤ))
  rw [hres, bkE_encLearner_eq, show encZ cInt = Val.int cInt from rfl]
  have hLe : valSize (Val.list [Val.int L.tag, Val.int L.cache, Val.int (L.epoch : ℤ),
      Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hI : valSize (Val.list [encStreamParams P, Val.int cInt, Val.list [Val.int L.tag,
      Val.int L.cache, Val.int (L.epoch : ℤ), Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]]) ≤
      M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  refine ev_let (bkE_pow2 hlib (bkE_param hw1.peHstep hP hM (ev_hd (ev_var rfl) hI)) (by omega))
    (ev_let (ev_at1 (ev_var rfl) hI) (ev_let (ev_at2 (ev_var rfl) hI) ?_))
  -- environment `[Le, c, T, I]`
  refine ev_cons (ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_var rfl) (ev_hd (ev_var rfl) hLe) ?_)
      (ev_var rfl) ?_) (bkRDiv_val _ _ hTpos ?_))
    (ev_cons (ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_mul (ev_var rfl) (ev_var rfl) ?_)
        (ev_at1 (ev_var rfl) hLe) ?_) (ev_mul (ev_var rfl) (ev_var rfl) ?_) ?_)
        (bkRDiv_val _ _ (by positivity) ?_))
      (ev_tl (ev_tl (ev_var rfl) hLe) ?_) ?_) ?_
  all_goals first
    | omega
    | (simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)

/-- 765 (`W5Contract.learnerInRange`). -/
theorem learnerInRange_spec (hlib : BankLib prog) (hw1 : W1Contract R prog M) (P : StreamParams)
    (L : Learner) (hP : ParamsOK P) (hL : LearnerOK P 16 L) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encLearner L]] [] (.inl body_learnerInRange)
      (encB (L.inRange P)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hPs := bkE_valSize_encP_le P
  obtain ⟨c1, c2, c3⟩ := bkE_calL_le P
  have hCmax : P.Cmax = 2 ^ P.eCmax := rfl
  have hAmax : P.Amax = 2 ^ P.eAmax := rfl
  have t1 : bitLen L.tag ≤ P.eCmax + P.eHC + 5 := by
    have e : ((16 : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) = 2 ^ (P.eCmax + P.eHC + 4) := by
      rw [hCmax]; push_cast; ring
    exact SizeAux.bitLen_le_of_nonneg_le hL.tag_nonneg (hL.tag_le.trans_eq e)
  have t2 : bitLen L.cache ≤ P.eAmax + P.eHP + 5 := by
    have e : ((16 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) = 2 ^ (P.eAmax + P.eHP + 4) := by
      rw [hAmax]; push_cast; ring
    exact SizeAux.bitLen_le_of_nonneg_le hL.cache_nonneg (hL.cache_le.trans_eq e)
  have t3 : bitLen (L.epoch : ℤ) ≤ P.Kepoch := (SizeAux.bitLen_nat_le_self _).trans hL.epoch_le
  have t4 : bitLen (L.jEpoch : ℤ) ≤ 7 + 2 * P.eEta := by
    have hK : P.K0 = 2 ^ (7 + 2 * P.eEta) := rfl
    exact SizeAux.bitLen_nat_le_of_lt (hK ▸ hL.jEpoch_lt)
  have t5 : bitLen (L.jUsed : ℤ) ≤ 10 + 2 * P.eEta + 3 * P.calL := by
    apply SizeAux.bitLen_nat_le_of_lt
    have h3 : P.calL ^ 3 < 2 ^ (3 * P.calL) := by
      rw [pow_mul']
      exact Nat.pow_lt_pow_left Nat.lt_two_pow_self (by norm_num)
    calc L.jUsed ≤ P.Jstar := hL.jUsed_le
      _ ≤ 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := Jstar_le P
      _ < 2 ^ 10 * 2 ^ (2 * P.eEta) * 2 ^ (3 * P.calL) := mul_lt_mul_of_pos_left h3 (by positivity)
      _ = 2 ^ (10 + 2 * P.eEta + 3 * P.calL) := by rw [pow_add, pow_add]
  have a1 := eCmax_le P
  have a2 := eHC_le P
  have a3 := eAmax_le P
  have a4 := eHP_le P
  have a5 := Kepoch_le P
  have a6 := eEta_le P
  have hCb : bitLen (P.Cmax : ℤ) = P.eCmax + 1 := by rw [hCmax, bitLen_natCast, Nat.size_pow]
  have hAb : bitLen (P.Amax : ℤ) = P.eAmax + 1 := by rw [hAmax, bitLen_natCast, Nat.size_pow]
  have hC2 := bkE_bitLen_two_pow P.eHC
  have hA2 := bkE_bitLen_two_pow P.eHP
  have mC := bitLen_mul_le' (P.Cmax : ℤ) ((2 ^ P.eHC : ℕ) : ℤ)
  have mA := bitLen_mul_le' (P.Amax : ℤ) ((2 ^ P.eHP : ℕ) : ℤ)
  rw [bkE_encLearner_eq]
  have hLe : valSize (Val.list [Val.int L.tag, Val.int L.cache, Val.int (L.epoch : ℤ),
      Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hI : valSize (Val.list [encStreamParams P, Val.list [Val.int L.tag, Val.int L.cache,
      Val.int (L.epoch : ℤ), Val.int (L.jEpoch : ℤ), Val.int (L.jUsed : ℤ)]]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hc0 : ¬ L.tag < 0 := not_lt.mpr hL.tag_nonneg
  have hc0' : ¬ L.cache < 0 := not_lt.mpr hL.cache_nonneg
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI)
    (ev_let (ev_mul (bkE_param hw1.pCmax hP hM (ev_var rfl))
      (bkE_pow2 hlib (bkE_param hw1.peHC hP hM (ev_var rfl)) (by omega)) ?_)
    (ev_let (ev_mul (bkE_param hw1.pAmax hP hM (ev_var rfl))
      (bkE_pow2 hlib (bkE_param hw1.peHP hP hM (ev_var rfl)) (by omega)) ?_) ?_)))
  · simp only [valSize_int]; omega
  · simp only [valSize_int]; omega
  -- environment `[Ab, Cb, Le, P, I]`
  by_cases hCt : (P.Cmax : ℤ) * ((2 ^ P.eHC : ℕ) : ℤ) < L.tag
  · have hres : L.inRange P = false := by
      unfold Learner.inRange
      rw [Bool.and_eq_false_iff]
      left
      unfold inRangeC
      rw [decide_eq_false_iff_not, bkE_grid_iff]
      omega
    rw [hres, encB_false]
    exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hLe) (ev_lit hl0) hM2) (by rw [if_neg hc0])
      (ev_ite_t (ev_lt (ev_var rfl) (ev_hd (ev_var rfl) hLe) hM2)
        (by rw [if_pos hCt]; exact one_ne_zero) (ev_lit hl0))
  · by_cases hAc : (P.Amax : ℤ) * ((2 ^ P.eHP : ℕ) : ℤ) < L.cache
    · have hres : L.inRange P = false := by
        unfold Learner.inRange
        rw [Bool.and_eq_false_iff]
        right
        unfold inRangeA
        rw [decide_eq_false_iff_not, bkE_grid_iff]
        omega
      rw [hres, encB_false]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hLe) (ev_lit hl0) hM2) (by rw [if_neg hc0])
        (ev_ite_f (ev_lt (ev_var rfl) (ev_hd (ev_var rfl) hLe) hM2) (by rw [if_neg hCt])
          (ev_ite_f (ev_lt (ev_at1 (ev_var rfl) hLe) (ev_lit hl0) hM2) (by rw [if_neg hc0'])
            (ev_ite_t (ev_lt (ev_var rfl) (ev_at1 (ev_var rfl) hLe) hM2)
              (by rw [if_pos hAc]; exact one_ne_zero) (ev_lit hl0))))
    · have hres : L.inRange P = true := by
        unfold Learner.inRange
        rw [Bool.and_eq_true]
        unfold inRangeC inRangeA
        rw [decide_eq_true_iff, decide_eq_true_iff, bkE_grid_iff, bkE_grid_iff]
        omega
      rw [hres, encB_true]
      exact ev_ite_f (ev_lt (ev_hd (ev_var rfl) hLe) (ev_lit hl0) hM2) (by rw [if_neg hc0])
        (ev_ite_f (ev_lt (ev_var rfl) (ev_hd (ev_var rfl) hLe) hM2) (by rw [if_neg hCt])
          (ev_ite_f (ev_lt (ev_at1 (ev_var rfl) hLe) (ev_lit hl0) hM2) (by rw [if_neg hc0'])
            (ev_ite_f (ev_lt (ev_var rfl) (ev_at1 (ev_var rfl) hLe) hM2) (by rw [if_neg hAc])
              (ev_lit hl1))))

/-- 759 (`W5Contract.guardMant`). -/
theorem guardMant_spec (hlib : BankLib prog) (P : StreamParams) (Cint α e : ℤ)
    (hP : ParamsOK P) (hC0 : 0 ≤ Cint) (hC : Cint ≤ 2 ^ regBits P) (hα : |α| ≤ (regBits P : ℤ))
    (he : |e| ≤ (regBits P : ℤ)) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encZ Cint, encZ α, encZ e]] [] (.inl body_guardMant)
      (Val.int (guardMant Cint α e)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hCb : bitLen Cint ≤ regBits P + 1 := SizeAux.bitLen_le_of_nonneg_le hC0 hC
  have hαb : bitLen α ≤ regBits P := bkE_bitLen_le_of_abs_le_nat hα
  have heb : bitLen e ≤ regBits P := bkE_bitLen_le_of_abs_le_nat he
  have hα' := abs_le.mp hα
  have he' := abs_le.mp he
  have hk : |2 * α + e| ≤ ((3 * regBits P : ℕ) : ℤ) := by
    rw [abs_le]; push_cast; constructor <;> omega
  have hkb : bitLen (2 * α + e) ≤ 3 * regBits P := bkE_bitLen_le_of_abs_le_nat hk
  have h2α : bitLen (2 * α) ≤ regBits P + 2 := by
    have := bitLen_mul_le' 2 α; rw [bitLen_two_eq] at this; omega
  have hCC := bitLen_mul_le' Cint Cint
  have h4 : bitLen (4 : ℤ) ≤ 3 := bitLen_le_of_abs_lt (by norm_num)
  have hF := bitLen_mul_le' 4 (Cint * Cint)
  have hFnn : 0 ≤ 4 * (Cint * Cint) := by positivity
  have hN0 : 0 ≤ bkE_gN Cint (2 * α + e) := by
    unfold bkE_gN
    split_ifs
    · exact Int.ediv_nonneg hFnn (by positivity)
    · positivity
  have hNb : bitLen (bkE_gN Cint (2 * α + e)) ≤ 6 * regBits P + 10 := by
    unfold bkE_gN
    split_ifs with hk0
    · have := bitLen_ediv_le (4 * (Cint * Cint)) ((2 ^ (-(2 * α + e)).toNat : ℕ) : ℤ)
      omega
    · have hcast : (((2 * α + e).toNat : ℕ) : ℤ) = 2 * α + e := Int.toNat_of_nonneg (by omega)
      have hp := bkE_bitLen_two_pow (2 * α + e).toNat
      have hmul := bitLen_mul_le' (4 * (Cint * Cint)) ((2 ^ (2 * α + e).toNat : ℕ) : ℤ)
      omega
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have hl4 : valSize (Val.int 4) ≤ M := by simp only [valSize_int]; omega
  rw [bkE_guardMant_eq, show encZ Cint = Val.int Cint from rfl, show encZ α = Val.int α from rfl,
    show encZ e = Val.int e from rfl]
  have hI : valSize (Val.list [Val.int Cint, Val.int α, Val.int e]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_add (ev_mul (ev_lit hl2) (ev_at1 (ev_var rfl) hI) ?_)
      (ev_at2 (ev_var rfl) hI) ?_)
    (ev_let (ev_mul (ev_lit hl4) (ev_mul (ev_var rfl) (ev_var rfl) ?_) ?_)
      (ev_let (bkE_guardN_val hlib Cint (2 * α + e) _ (3 * regBits P) (2 * regBits P + 5) hk
          (by omega) (by omega))
        (bkE_guardFin_val hlib _ _ hN0 (6 * regBits P + 10) hNb (by omega)))))
  all_goals (simp only [valSize_int]; omega)

/-- 760 (`W5Contract.stepCoeffMant`). -/
theorem stepCoeffMant_spec (hlib : BankLib prog) (P : StreamParams) (pos : Bool) (qη qs : ℕ)
    (Pval Qhat : ℚ) (hP : ParamsOK P) (hqη : qη ≤ regBits P) (hqs : qs ≤ regBits P)
    (hP0 : 0 < Pval) (hPq : QOK P Pval) (hQ0 : 0 < Qhat) (hQq : QOK P Qhat) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encB pos, encN qη, encN qs, encQ Pval, encQ Qhat]] []
      (.inl body_stepCoeffMant) (Val.int (stepCoeffMant pos qη qs Pval Qhat)) := by
  obtain ⟨hRM, hR1⟩ := bkE_RM R P hM
  have hPn := bkE_num_le hPq
  have hPd := bkE_den_le hPq
  have hQn := bkE_num_le hQq
  have hQd := bkE_den_le hQq
  have hPn0 : 0 < Pval.num := Rat.num_pos.mpr hP0
  have hQn0 : 0 < Qhat.num := Rat.num_pos.mpr hQ0
  have hPd0 : (0 : ℤ) < (Pval.den : ℤ) := by exact_mod_cast Pval.pos
  have hQd0 : (0 : ℤ) < (Qhat.den : ℤ) := by exact_mod_cast Qhat.pos
  have hqηb : bitLen (qη : ℤ) ≤ regBits P := by rw [bitLen_natCast]; exact (size_le_self _).trans hqη
  have hqsb : bitLen (qs : ℤ) ≤ regBits P := by rw [bitLen_natCast]; exact (size_le_self _).trans hqs
  have hk : |2 * ((qs : ℤ) - (qη : ℤ)) - 6| ≤ ((2 * regBits P + 6 : ℕ) : ℤ) := by
    rw [abs_le]; push_cast; constructor <;> omega
  have hsub := bkE_bitLen_sub (qs : ℤ) (qη : ℤ)
  have h2sub := bitLen_mul_le' 2 ((qs : ℤ) - (qη : ℤ))
  rw [bitLen_two_eq] at h2sub
  have hkb : bitLen (2 * ((qs : ℤ) - (qη : ℤ)) - 6) ≤ 2 * regBits P + 6 :=
    bkE_bitLen_le_of_abs_le_nat hk
  have h6 : bitLen (6 : ℤ) ≤ 3 := bitLen_le_of_abs_lt (by norm_num)
  have hnum := bitLen_mul_le' Pval.num (Qhat.den : ℤ)
  have hden := bitLen_mul_le' (Pval.den : ℤ) Qhat.num
  have hnum0 : 0 ≤ Pval.num * (Qhat.den : ℤ) := by positivity
  have hden0 : 0 < (Pval.den : ℤ) * Qhat.num := by positivity
  obtain ⟨hMN0, hMNb⟩ := bkE_sMN_bounds (Pval.num * (Qhat.den : ℤ))
    (2 * ((qs : ℤ) - (qη : ℤ)) - 6) _ hnum0 hk
  obtain ⟨hMD0, hMDb⟩ := bkE_sMD_bounds ((Pval.den : ℤ) * Qhat.num)
    (2 * ((qs : ℤ) - (qη : ℤ)) - 6) _ hden0 hk
  have hab := bkE_sA_bitLen pos _ _ hMN0 hMD0
  have hT := bkE_bitLen_two_pow qs
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have hl6 : valSize (Val.int 6) ≤ M := by simp only [valSize_int]; omega
  rw [bkE_stepCoeffMant_eq pos qη qs Pval Qhat hP0 hQ0, bkE_encQ_eq, bkE_encQ_eq,
    show encN qη = Val.int (qη : ℤ) from rfl, show encN qs = Val.int (qs : ℤ) from rfl,
    show encB pos = Val.int (if pos then 1 else 0) from rfl]
  have hPq' : valSize (Val.list [Val.int Pval.num, Val.int (Pval.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hQq' : valSize (Val.list [Val.int Qhat.num, Val.int (Qhat.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hpos : bitLen (if pos then (1 : ℤ) else 0) ≤ 1 := by
    split_ifs <;> simp only [bitLen_one, bitLen_zero] <;> omega
  have hI : valSize (Val.list [Val.int (if pos then 1 else 0), Val.int (qη : ℤ), Val.int (qs : ℤ),
      Val.list [Val.int Pval.num, Val.int (Pval.den : ℤ)],
      Val.list [Val.int Qhat.num, Val.int (Qhat.den : ℤ)]]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  refine ev_let (ev_at3 (ev_var rfl) hI) (ev_let (ev_at4 (ev_var rfl) hI)
    (ev_let (ev_sub (ev_mul (ev_lit hl2) (ev_sub (ev_at2 (ev_var rfl) hI) (ev_at1 (ev_var rfl) hI)
        ?_) ?_) (ev_lit hl6) ?_)
    (ev_let (ev_mul (ev_hd (ev_var rfl) hPq') (ev_at1 (ev_var rfl) hQq') ?_)
    (ev_let (ev_mul (ev_at1 (ev_var rfl) hPq') (ev_hd (ev_var rfl) hQq') ?_)
    (ev_let (bkE_sMN_val hlib _ _ _ _ (2 * regBits P + 6) (8 * regBits P + 2) hk ?_ ?_)
    (ev_let (bkE_sMD_val hlib _ _ _ _ _ (2 * regBits P + 6) (8 * regBits P + 2) hk ?_ ?_)
    (ev_let (bkE_sA_val hlib pos _ _ _ _ _ _ _ _ _ hMN0 hMD0 (12 * regBits P + 20) ?_ ?_ hI ?_)
    (ev_let (bkE_pow2 hlib (ev_at2 (ev_var rfl) hI) ?_)
      (bkE_sFin_val hlib _ _ _ (12 * regBits P + 23) ?_ ?_ ?_)))))))))
  all_goals first
    | omega
    | (simp only [valSize_int]; omega)

end entries

end F2e2e.C.Impl.BankDSL
