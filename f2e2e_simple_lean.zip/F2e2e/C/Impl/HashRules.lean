import F2e2e.C.Impl.HashBasic

/-!
# HASH area (DSL): generic forward-rule helpers

Small derived rules of the cost calculus used by the HASH proofs: reading list elements
(`evals_hd`, `evals_at1` … `evals_at5`), building lists of three/four/six elements
(`evals_list3`, `evals_list4`), and size facts.
-/

namespace F2e2e.Cost.HashDSL

theorem valSize_le_of_mem {v : Val} {l : List Val} (h : v ∈ l) : valSize v ≤ valSize (Val.list l) :=
  le_of_lt (valSize_lt_of_mem h)

theorem valSize_tail_le (x : Val) (l : List Val) :
    valSize (Val.list l) ≤ valSize (Val.list (x :: l)) := by
  simp only [valSize_list, listSize_cons]
  omega

theorem valSize_head_add_tail_le (x : Val) (l : List Val) :
    valSize x + valSize (Val.list l) ≤ valSize (Val.list (x :: l)) := by
  simp only [valSize_list, listSize_cons]
  omega

section reads

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem evals_hd {i : ℕ} {x : Val} {l : List Val} (h : env[i]? = some (Val.list (x :: l))) :
    EvalsLe prog base env (eHd (eV i)) x 3 (base + 2 * valSize (Val.list (x :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.var (prog := prog) (base := base) h)
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x l
  simp only [max_le_iff]
  omega

theorem evals_at1 {i : ℕ} {x0 x1 : Val} {l : List Val}
    (h : env[i]? = some (Val.list (x0 :: x1 :: l))) :
    EvalsLe prog base env (eAt1 (eV i)) x1 5 (base + 2 * valSize (Val.list (x0 :: x1 :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.tail (EvalsLe.var (prog := prog) (base := base) h))
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x0 (x1 :: l)
  have := valSize_head_add_tail_le x1 l
  simp only [max_le_iff]
  omega

theorem evals_at2 {i : ℕ} {x0 x1 x2 : Val} {l : List Val}
    (h : env[i]? = some (Val.list (x0 :: x1 :: x2 :: l))) :
    EvalsLe prog base env (eAt2 (eV i)) x2 7
      (base + 2 * valSize (Val.list (x0 :: x1 :: x2 :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.var (prog := prog) (base := base) h)))
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x0 (x1 :: x2 :: l)
  have := valSize_head_add_tail_le x1 (x2 :: l)
  have := valSize_head_add_tail_le x2 l
  simp only [max_le_iff]
  omega

theorem evals_at3 {i : ℕ} {x0 x1 x2 x3 : Val} {l : List Val}
    (h : env[i]? = some (Val.list (x0 :: x1 :: x2 :: x3 :: l))) :
    EvalsLe prog base env (eAt3 (eV i)) x3 9
      (base + 2 * valSize (Val.list (x0 :: x1 :: x2 :: x3 :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail
    (EvalsLe.var (prog := prog) (base := base) h))))
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x0 (x1 :: x2 :: x3 :: l)
  have := valSize_head_add_tail_le x1 (x2 :: x3 :: l)
  have := valSize_head_add_tail_le x2 (x3 :: l)
  have := valSize_head_add_tail_le x3 l
  simp only [max_le_iff]
  omega

theorem evals_at4 {i : ℕ} {x0 x1 x2 x3 x4 : Val} {l : List Val}
    (h : env[i]? = some (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: l))) :
    EvalsLe prog base env (eAt4 (eV i)) x4 11
      (base + 2 * valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail
    (EvalsLe.var (prog := prog) (base := base) h)))))
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x0 (x1 :: x2 :: x3 :: x4 :: l)
  have := valSize_head_add_tail_le x1 (x2 :: x3 :: x4 :: l)
  have := valSize_head_add_tail_le x2 (x3 :: x4 :: l)
  have := valSize_head_add_tail_le x3 (x4 :: l)
  have := valSize_head_add_tail_le x4 l
  simp only [max_le_iff]
  omega

theorem evals_at5 {i : ℕ} {x0 x1 x2 x3 x4 x5 : Val} {l : List Val}
    (h : env[i]? = some (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: l))) :
    EvalsLe prog base env (eAt5 (eV i)) x5 13
      (base + 2 * valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: l))) := by
  have h1 := EvalsLe.head (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail (EvalsLe.tail
    (EvalsLe.var (prog := prog) (base := base) h))))))
  refine h1.mono (by omega) ?_
  have := valSize_head_add_tail_le x0 (x1 :: x2 :: x3 :: x4 :: x5 :: l)
  have := valSize_head_add_tail_le x1 (x2 :: x3 :: x4 :: x5 :: l)
  have := valSize_head_add_tail_le x2 (x3 :: x4 :: x5 :: l)
  have := valSize_head_add_tail_le x3 (x4 :: x5 :: l)
  have := valSize_head_add_tail_le x4 (x5 :: l)
  have := valSize_head_add_tail_le x5 l
  simp only [max_le_iff]
  omega

end reads

section lists

variable {prog : List Expr} {base : ℕ} {env : List Val}

theorem evals_list2 {e0 e1 : Expr} {x0 x1 : Val} {C0 S0 C1 S1 : ℕ}
    (h0 : EvalsLe prog base env e0 x0 C0 S0)
    (h1 : EvalsLe prog (base + valSize x0) env e1 x1 C1 S1) :
    EvalsLe prog base env (eList [e0, e1]) (Val.list [x0, x1]) (C0 + C1 + 5)
      (max (max S0 S1) (base + 2 * valSize (Val.list [x0, x1]))) := by
  have h := EvalsLe.cons h0 (EvalsLe.cons h1 (EvalsLe.nil (prog := prog)
    (base := base + valSize x0 + valSize x1) (env := env)))
  refine h.mono (by omega) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
  omega

theorem evals_list3 {e0 e1 e2 : Expr} {x0 x1 x2 : Val} {C0 S0 C1 S1 C2 S2 : ℕ}
    (h0 : EvalsLe prog base env e0 x0 C0 S0)
    (h1 : EvalsLe prog (base + valSize x0) env e1 x1 C1 S1)
    (h2 : EvalsLe prog (base + valSize x0 + valSize x1) env e2 x2 C2 S2) :
    EvalsLe prog base env (eList [e0, e1, e2]) (Val.list [x0, x1, x2]) (C0 + C1 + C2 + 7)
      (max (max S0 (max S1 S2)) (base + 2 * valSize (Val.list [x0, x1, x2]))) := by
  have h := EvalsLe.cons h0 (EvalsLe.cons h1 (EvalsLe.cons h2 (EvalsLe.nil (prog := prog)
    (base := base + valSize x0 + valSize x1 + valSize x2) (env := env))))
  refine h.mono (by omega) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
  omega

theorem evals_list4 {e0 e1 e2 e3 : Expr} {x0 x1 x2 x3 : Val} {C0 S0 C1 S1 C2 S2 C3 S3 : ℕ}
    (h0 : EvalsLe prog base env e0 x0 C0 S0)
    (h1 : EvalsLe prog (base + valSize x0) env e1 x1 C1 S1)
    (h2 : EvalsLe prog (base + valSize x0 + valSize x1) env e2 x2 C2 S2)
    (h3 : EvalsLe prog (base + valSize x0 + valSize x1 + valSize x2) env e3 x3 C3 S3) :
    EvalsLe prog base env (eList [e0, e1, e2, e3]) (Val.list [x0, x1, x2, x3])
      (C0 + C1 + C2 + C3 + 9)
      (max (max S0 (max S1 (max S2 S3))) (base + 2 * valSize (Val.list [x0, x1, x2, x3]))) := by
  have h := EvalsLe.cons h0 (EvalsLe.cons h1 (EvalsLe.cons h2 (EvalsLe.cons h3
    (EvalsLe.nil (prog := prog)
      (base := base + valSize x0 + valSize x1 + valSize x2 + valSize x3) (env := env)))))
  refine h.mono (by omega) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, max_le_iff]
  omega

end lists

end F2e2e.Cost.HashDSL
