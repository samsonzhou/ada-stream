import F2e2e.C.Impl.AdaPubMath
import F2e2e.C.Impl.W6Lib
import F2e2e.Cost.Arith.Helpers
import F2e2e.Cost.Arith.AExpBound

/-!
# The ADA parameter record: `EvalsVal` rules for natural-number code

Helpers for the DSL routine `adaPub` (`F2e2e/C/Impl/AdaPub.lean`), namespace `F2e2e.C.Impl.AP`:

* deterministic `EvalsVal` rules on `encN` values (`evN_var`, `evN_lit`, `evN_add`, `evN_sub`,
  `evN_mul`, `evN_div`), comparison flags as `encB` (`evN_lt_true/false`, `evN_eq_true/false`) and
  the two branches of `ite` (`ev_ite_true`, `ev_ite_false`), `ev_cast` (rewrite the value);
* library calls in `EvalsVal` form: `pow2_ev`, `clog2_ev`, `natSqrt_ev`;
* contract calls: `param_ev` (W1's `ParamSpec`), `normQ_ev` (W5's `normQ`);
* size facts (`size_two_pow`, `size_mul_le`, `size_add_le`).
-/

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.C.Impl.W6

/-! ## Size facts -/

theorem size_two_pow (k : ℕ) : Nat.size (2 ^ k) = k + 1 := Nat.size_pow

theorem size_mul_le (a b : ℕ) : Nat.size (a * b) ≤ Nat.size a + Nat.size b :=
  Arith.size_mul_le' a b

theorem size_add_le (a b : ℕ) : Nat.size (a + b) ≤ max (Nat.size a) (Nat.size b) + 1 :=
  Arith.size_add_le' a b

theorem size_le_of_le {a b : ℕ} (h : a ≤ b) : Nat.size a ≤ Nat.size b := Nat.size_le_size h

theorem size_le_self' (n : ℕ) : Nat.size n ≤ n := Nat.size_le.2 Nat.lt_two_pow_self

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-! ## Deterministic rules on natural numbers -/

theorem ev_cast {bits : List Bool} {e : Expr} {v w : Val}
    (h : EvalsVal prog M env bits (.inl e) v) (hvw : v = w) : EvalsVal prog M env bits (.inl e) w :=
  hvw ▸ h

theorem evN_var {i n : ℕ} (h : env[i]? = some (encN n)) :
    EvalsVal prog M env [] (.inl (Expr.var i)) (encN n) := EvalsVal.var h

theorem evN_lit (n : ℕ) (hM : Nat.size n + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.lit (n : ℤ))) (encN n) :=
  EvalsVal.lit (by rw [valSize_int, bitLen_natCast]; exact hM)

theorem evN_add {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hM : Nat.size (x + y) + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.add a b)) (encN (x + y)) := by
  have e : encN (x + y) = Val.int ((x : ℤ) + (y : ℤ)) := by simp [encN]
  have h := EvalsVal.add ha hb (by rw [← e, valSize_encN]; exact hM)
  rw [List.append_nil] at h
  rw [e]
  exact h

theorem evN_sub {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hyx : y ≤ x) (hM : Nat.size x + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.sub a b)) (encN (x - y)) := by
  have e : encN (x - y) = Val.int ((x : ℤ) - (y : ℤ)) := by simp [encN, Nat.cast_sub hyx]
  have hs : Nat.size (x - y) + 1 ≤ M := le_trans (Nat.add_le_add_right
    (size_le_of_le (Nat.sub_le x y)) 1) hM
  have h := EvalsVal.sub ha hb (by rw [← e, valSize_encN]; exact hs)
  rw [List.append_nil] at h
  rw [e]
  exact h

theorem evN_mul {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hM : Nat.size (x * y) + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.mul a b)) (encN (x * y)) := by
  have e : encN (x * y) = Val.int ((x : ℤ) * (y : ℤ)) := by simp [encN]
  have h := EvalsVal.mul ha hb (by rw [← e, valSize_encN]; exact hM)
  rw [List.append_nil] at h
  rw [e]
  exact h

theorem evN_div {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hy : y ≠ 0) (hM : Nat.size x + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.div a b)) (encN (x / y)) := by
  have e : encN (x / y) = Val.int ((x : ℤ) / (y : ℤ)) := by simp [encN]
  have hs : Nat.size (x / y) + 1 ≤ M := le_trans (Nat.add_le_add_right
    (size_le_of_le (Nat.div_le_self x y)) 1) hM
  have hy' : (y : ℤ) ≠ 0 := by exact_mod_cast hy
  have h := EvalsVal.div ha hb hy' (by rw [← e, valSize_encN]; exact hs)
  rw [List.append_nil] at h
  rw [e]
  exact h

theorem evN_lt_true {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hxy : x < y) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (encB true) := by
  have h := EvalsVal.lt ha hb hM
  rw [List.append_nil] at h
  have e : Val.int (if (x : ℤ) < (y : ℤ) then 1 else 0) = encB true := by
    simp [encB, hxy]
  rw [e] at h
  exact h

theorem evN_lt_false {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hxy : ¬ x < y) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (encB false) := by
  have h := EvalsVal.lt ha hb hM
  rw [List.append_nil] at h
  have e : Val.int (if (x : ℤ) < (y : ℤ) then 1 else 0) = encB false := by
    simp [encB, hxy]
  rw [e] at h
  exact h

theorem evN_eq_true {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hxy : x = y) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.eq a b)) (encB true) := by
  have h := EvalsVal.eq ha hb hM
  rw [List.append_nil] at h
  have e : Val.int (if (x : ℤ) = (y : ℤ) then 1 else 0) = encB true := by
    simp [encB, hxy]
  rw [e] at h
  exact h

theorem evN_eq_false {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hxy : x ≠ y) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.eq a b)) (encB false) := by
  have h := EvalsVal.eq ha hb hM
  rw [List.append_nil] at h
  have e : Val.int (if (x : ℤ) = (y : ℤ) then 1 else 0) = encB false := by
    simp [encB, hxy]
  rw [e] at h
  exact h

theorem ev_ite_true {c t f : Expr} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (encB true))
    (ht : EvalsVal prog M env [] (.inl t) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  ev_ite_encB hc (by simpa using ht)

theorem ev_ite_false {c t f : Expr} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (encB false))
    (hf : EvalsVal prog M env [] (.inl f) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  ev_ite_encB hc (by simpa using hf)

theorem ev_call {i : ℕ} {a body : Expr} {x v : Val} (hbody : prog[i]? = some body)
    (ha : EvalsVal prog M env [] (.inl a) x) (hf : EvalsVal prog M [x] [] (.inl body) v) :
    EvalsVal prog M env [] (.inl (Expr.call i a)) v :=
  F2e2e.C.Impl.evalsVal_call_det hbody ha hf

theorem ev_cons {a b : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) x) (hb : EvalsVal prog M env [] (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.cons a b)) (Val.list (x :: l)) := by
  have h := EvalsVal.cons ha hb hM
  rw [List.append_nil] at h
  exact h

/-! ## Library calls -/

theorem pow2_ev (h0 : prog[Cost.Idx.pow2]? = some body_pow2)
    (h1 : prog[Cost.Idx.pow2Step]? = some body_pow2Step) {a : Expr} {k : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (encN k)) (hM : S_pow2 k ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call Cost.Idx.pow2 a)) (encN (2 ^ k)) :=
  ev_call h0 ha ((pow2_spec h1 k 0).toVal.mono_M hM)

theorem clog2_ev (h0 : prog[Cost.Idx.clog2]? = some body_clog2)
    (h1 : prog[Cost.Idx.clog2Step]? = some body_clog2Step) {a : Expr} {m : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (encN m)) (hM : S_clog2 m ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call Cost.Idx.clog2 a)) (encN (Nat.clog 2 m)) :=
  ev_call h0 ha ((clog2_spec h1 m 0).toVal.mono_M hM)

theorem natSqrt_ev (h0 : prog[Cost.Idx.natSqrt]? = some body_natSqrt)
    (h1 : prog[Cost.Idx.natSqrtStep]? = some body_natSqrtStep) {a : Expr} {n : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (encN n)) (hM : 25 * Nat.size n + 100 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call Cost.Idx.natSqrt a)) (encN (Nat.sqrt n)) :=
  ev_call h0 ha (natSqrt_val h1 n hM)

/-! ## Contract calls -/

theorem param_ev {R : AdaRep} {idx : ℕ} {f : StreamParams → ℕ} (hs : ParamSpec R prog M idx f)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (encStreamParams P)) :
    EvalsVal prog M env [] (.inl (Expr.call idx a)) (encN (f P)) := by
  obtain ⟨body, hb, hspec⟩ := hs
  exact ev_call hb ha (hspec P hP hM)

theorem normQ_ev (hq : NormQSpec prog M) {a : Expr} {x y : ℤ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [Val.int x, Val.int y])) (hy : 0 < y)
    (hM : 2 * (bitLen x + bitLen y) + 64 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.normQ a))
      (encQ ((x : ℚ) / (y : ℚ))) := by
  obtain ⟨body, hb, hspec⟩ := hq
  exact ev_call hb ha (hspec x y hy hM)

end rules

end F2e2e.C.Impl.AP
