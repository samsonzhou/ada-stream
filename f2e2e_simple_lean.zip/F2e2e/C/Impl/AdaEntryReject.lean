import F2e2e.C.Impl.AdaEntryDefs
import F2e2e.C.Impl.AdaPrepScan

/-!
# ADA module (W4), `adaInterval`: the outer rejection `adaIvReject` (Idx 607)

`adaIvReject_impl`: on `[adaPubEnc A, adaEnc st, encB high]`, `body_adaIvReject` implements
`(outerReject A st high).toBits (adaDraw A)` (`F2e2e/B/ArchCore.lean` L262–268) with the output
`[encCert cert, adaEnc st']`.

Owner: 4a7299ed (handed over by W2, a2ff64c3, 2026-10-25 09:22Z; statement fixed by W2).
Proof: `st' = set st 4 (rej + 1)` (library `set`, `ap_set_call`); the test `rej < J` (the reference's
`¬ (J + 1 ≤ rej + 1)`); the terminal branch `[4 − high, set st' 7 1]` (deterministic) or the draw
branch `k ← adaDraw outThr` (`draw_impl`), `[2 − high, set st' 3 k]`. The encoded states are
`adaFields` lists, so every `set` is `rfl` on the reference state; the sizes come from `AdaOK` of
the final states (as in C-SPACE's `outerReject_ok`) and the field decomposition `valSize_adaFields`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## The fields of an encoded state -/

/-- The fields of `adaEnc st`. -/
def adaFields (st : AdaState) : List Val :=
  [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt, encZ st.thrOut, encN st.rej,
    encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted]

theorem adaEnc_eq_fields (st : AdaState) : adaEnc st = Val.list (adaFields st) := rfl

theorem adaFields_set_rej (st : AdaState) (r : ℕ) :
    Val.list ((adaFields st).set 4 (encN r)) = adaEnc { st with rej := r } := rfl

theorem adaFields_set_halted (st : AdaState) :
    Val.list ((adaFields st).set 7 (Val.int 1)) = adaEnc { st with halted := true } := rfl

theorem adaFields_set_thrOut (st : AdaState) (k : ℤ) :
    Val.list ((adaFields st).set 3 (encZ k)) = adaEnc { st with thrOut := k } := rfl

theorem valSize_adaFields (s : AdaState) :
    valSize (Val.list (adaFields s)) = valSize (encL (encL encZ) s.scores) +
      valSize (encL encN s.T) + valSize (encL encZ s.thrInt) + valSize (encZ s.thrOut) +
      valSize (encN s.rej) + valSize (encN s.nInt) + valSize (encN s.nNum) +
      valSize (encB s.halted) + valSize (encB s.capAborted) + 10 := by
  simp only [adaFields, valSize_list, listSize_cons, listSize_nil]
  omega

/-- The size bound dominates its product of factors. -/
theorem rj_bound_ge (A : AdaParams) : (A.N + A.p + 16) * (adaZ A + 16) ≤ adaBoundA A := by
  unfold adaBoundA
  rw [mul_assoc]
  exact Nat.le_mul_of_pos_left _ (by norm_num)

/-! ## Small evaluation rules -/

section Rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem rj_letE_det {α : Type} {a b : Expr} {va : Val} {enc : α → Val} {p : BitProg α}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : Implements prog M (va :: env) b enc p) :
    Implements prog M env (Expr.letE a b) enc p := by
  intro bits x h
  have := EvalsVal.letE ha (hb bits x h)
  simpa using this

theorem rj_add_one {e : Expr} {n : ℕ} (h : EvalsVal prog M env [] (.inl e) (encN n))
    (hM : Nat.size (n + 1) + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (eAdd e (eLit 1))) (encN (n + 1)) := by
  have hpos : 0 < Nat.size (n + 1) := Nat.size_pos.mpr (Nat.succ_pos n)
  have h1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have e1 : encN (n + 1) = Val.int ((n : ℤ) + 1) := by simp [encN]
  rw [e1]
  exact EvalsVal.add h (EvalsVal.lit h1) (by rw [← e1, valSize_encN]; exact hM)

theorem rj_small {z : ℤ} (hz : bitLen z ≤ 8) (hM : 16 ≤ M) : valSize (Val.int z) ≤ M := by
  rw [valSize_int]; omega

theorem rj_lit {z : ℤ} (hz : bitLen z ≤ 8) (hM : 16 ≤ M) :
    EvalsVal prog M env [] (.inl (eLit z)) (Val.int z) :=
  EvalsVal.lit (rj_small hz hM)

theorem rj_ite_eq {p : Prop} [Decidable p] (h : ¬ p) : (if p then (1 : ℤ) else 0) = 0 := by
  rw [if_neg h]

theorem rj_ite_ne {p : Prop} [Decidable p] (h : p) : (if p then (1 : ℤ) else 0) ≠ 0 := by
  rw [if_pos h]; exact one_ne_zero

end Rules

/-! ## The routine -/

/-- **Spec of `adaIvReject`** (one fresh draw of kind `outThr` on the non-terminal branch). -/
theorem adaIvReject_impl {prog : List Expr} {M : ℕ} (hS : SampLib prog) (hL : ListLib prog)
    {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) (hh : st.halted = false) (high : Bool)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] body_adaIvReject
      (fun r => Val.list [encCert r.1, adaEnc r.2]) ((outerReject A st high).toBits (adaDraw A)) := by
  -- sizes
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hstB := valSize_adaEnc_le hok
  have hstB' : valSize (Val.list (adaFields st)) ≤ adaBoundA A := hstB
  have hZ16 := sixteen_le_adaZ A
  have hB1 := rj_bound_ge A
  have hBZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hrej : st.rej ≤ A.J := hok.rej_halt hh
  have hrsz : Nat.size (st.rej + 1) ≤ adaZ A :=
    (Nat.size_le_size (by omega : st.rej + 1 ≤ A.M + A.J + A.R + 2)).trans (size_MJR_le_adaZ A)
  have hrsz1 : Nat.size (st.rej + 1) ≤ Nat.size st.rej + 1 := by
    apply Nat.size_le.mpr
    have := Nat.lt_size_self st.rej
    rw [pow_succ]
    omega
  have hbsz : valSize (encB high) ≤ 2 := by cases high <;> simp [encB]
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hXM : valSize (Val.list [adaPubEnc A, adaEnc st, encB high]) ≤ M := by
    rw [ap_valSize_list3]; omega
  have hst'B : valSize (Val.list (adaFields { st with rej := st.rej + 1 })) ≤ adaBoundA A + 1 := by
    have e1 := valSize_adaFields { st with rej := st.rej + 1 }
    have e2 := valSize_adaFields st
    simp only [valSize_encN] at e1 e2
    omega
  have hdraw : drawM A NoiseKind.outThr ≤ M := by have := drawM_le A NoiseKind.outThr; omega
  have h16 : 16 ≤ M := by omega
  have s3 : Nat.size 3 ≤ 3 := size_le_self 3
  have s4 : Nat.size 4 ≤ 4 := size_le_self 4
  have s7 : Nat.size 7 ≤ 7 := size_le_self 7
  -- the input
  have hX0 : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 0))
      (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
  have hst0 := evalsVal_atN' hX0 hXM (n := 1) rfl
  have hrej0 : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] []
      (.inl (eAtN 4 (eAtN 1 (eV 0)))) (encN st.rej) :=
    evalsVal_atN' (l := adaFields st) hst0 hstM rfl
  unfold body_adaIvReject
  -- `st' = st with rej := rej + 1`
  refine rj_letE_det (va := adaEnc { st with rej := st.rej + 1 }) ?_ ?_
  · show EvalsVal _ _ _ _ _ (Val.list ((adaFields st).set 4 (encN (st.rej + 1))))
    exact ap_set_call hL (n := 4) (l := adaFields st) hst0 (rj_lit (by decide) h16)
      (rj_add_one hrej0 (by omega)) (by unfold S_set; rw [valSize_encN]; omega)
  -- the test `rej < J`
  have hX1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 1))
      (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
  have hpub1 := evalsVal_atN' hX1 hXM (n := 0) rfl
  have hst1 := evalsVal_atN' hX1 hXM (n := 1) rfl
  have hhigh1 := evalsVal_atN' hX1 hXM (n := 2) rfl
  have hrej1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eAtN 4 (eAtN 1 (eV 1))))
      (encN st.rej) := evalsVal_atN' (l := adaFields st) hst1 hstM rfl
  have hJ1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eAtN 5 (eAtN 0 (eV 1))))
      (encN A.J) := evalsVal_atN' (l := pubFields A) hpub1 hpubM rfl
  have hcond := EvalsVal.lt hrej1 hJ1 (by omega)
  unfold outerReject
  by_cases hc : A.J + 1 ≤ st.rej + 1
  · -- the terminal rejection: `[4 − high, set st' 7 1]`
    rw [if_pos hc]
    refine ap_implements_ite_false hcond (rj_ite_eq (by omega)) ?_
    have hokT : AdaOK A { st with rej := st.rej + 1, halted := true } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hok.thrOut_le, hok.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
        fun h' => absurd h' (by simp), hok.nInt_le, hok.nNum_le⟩
    have hfinB := valSize_adaEnc_le hokT
    have hset : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] []
        (.inl (eCall Idx.set (eList [eV 0, eLit 7, eLit 1])))
        (adaEnc { st with rej := st.rej + 1, halted := true }) := by
      show EvalsVal _ _ _ _ _
        (Val.list ((adaFields { st with rej := st.rej + 1 }).set 7 (Val.int 1)))
      exact ap_set_call hL (n := 7) (l := adaFields { st with rej := st.rej + 1 })
        (EvalsVal.var rfl) (rj_lit (by decide) h16) (rj_lit (by decide) h16)
        (by unfold S_set; simp only [valSize_int, bitLen_one]; omega)
    apply Implements.of_det
    cases high
    · have h1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (eSub (eLit 4) (eAtN 2 (eV 1)))) (Val.int 4) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh1 (rj_small (z := 4) (by decide) h16)
      have hb4 : bitLen (4 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (ePair (eSub (eLit 4) (eAtN 2 (eV 1))) (eCall Idx.set (eList [eV 0, eLit 7, eLit 1]))))
          (Val.list [Val.int 4, adaEnc { st with rej := st.rej + 1, halted := true }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
    · have h1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (eSub (eLit 4) (eAtN 2 (eV 1)))) (Val.int 3) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh1 (rj_small (z := 3) (by decide) h16)
      have hb3 : bitLen (3 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (ePair (eSub (eLit 4) (eAtN 2 (eV 1))) (eCall Idx.set (eList [eV 0, eLit 7, eLit 1]))))
          (Val.list [Val.int 3, adaEnc { st with rej := st.rej + 1, halted := true }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
  · -- a new outer phase: `k ← outThr`, `[2 − high, set st' 3 k]`
    rw [if_neg hc, DrawProg.toBits_bind, toBits_drawNoise]
    refine ap_implements_ite_true hcond (rj_ite_ne (by omega)) ?_
    refine implements_letE_of (draw_impl hS hpub1 hpubM NoiseKind.outThr hdraw)
      (fun k => |k| ≤ (maxKs A : ℤ))
      (fun bits k h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A _)) ?_
    intro k hk
    have hokD : AdaOK A { st with rej := st.rej + 1, thrOut := k } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hk, hok.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
        fun _ => by show st.rej + 1 ≤ A.J; omega, hok.nInt_le, hok.nNum_le⟩
    have hfinB := valSize_adaEnc_le hokD
    have hksz : valSize (encZ k) ≤ adaZ A + 1 := by
      rw [valSize_encZ]
      have := bitLen_le_size_of_abs_le hk
      have := size_maxKs_le_adaZ A
      omega
    have hset : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] []
        (.inl (eCall Idx.set (eList [eV 1, eLit 3, eV 0])))
        (adaEnc { st with rej := st.rej + 1, thrOut := k }) := by
      show EvalsVal _ _ _ _ _
        (Val.list ((adaFields { st with rej := st.rej + 1 }).set 3 (encZ k)))
      exact ap_set_call hL (n := 3) (l := adaFields { st with rej := st.rej + 1 })
        (EvalsVal.var rfl) (rj_lit (by decide) h16) (EvalsVal.var rfl)
        (by unfold S_set; omega)
    have hX2 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 2))
        (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
    have hhigh2 := evalsVal_atN' hX2 hXM (n := 2) rfl
    apply Implements.of_det
    cases high
    · have h1 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (eSub (eLit 2) (eAtN 2 (eV 2)))) (Val.int 2) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh2 (rj_small (z := 2) (by decide) h16)
      have hb2 : bitLen (2 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (ePair (eSub (eLit 2) (eAtN 2 (eV 2))) (eCall Idx.set (eList [eV 1, eLit 3, eV 0]))))
          (Val.list [Val.int 2, adaEnc { st with rej := st.rej + 1, thrOut := k }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
    · have h1 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (eSub (eLit 2) (eAtN 2 (eV 2)))) (Val.int 1) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh2 (rj_small (z := 1) (by decide) h16)
      have hp : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (ePair (eSub (eLit 2) (eAtN 2 (eV 2))) (eCall Idx.set (eList [eV 1, eLit 3, eV 0]))))
          (Val.list [Val.int 1, adaEnc { st with rej := st.rej + 1, thrOut := k }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int, bitLen_one]; omega)
      exact hp

/-! ## O2b (iii) family 6: the tight value premise (W3's `adaIvReject_impl_t`; append-only staging)

`adaIvReject_impl_t`: `adaIvReject_impl` with `(hMt : TightM A M)` (`TightM`, `tightA` from `AdaBounds`) for
`(hM : 2 ^ 32 * adaBoundA A ≤ M)`; same proof as the original with the tight size lemmas. Source: the DELTA
`F2e2e/Scratch/O2T/AdaEntryRejectT.lean` (W3 4a7299ed, reviewed by A-VAL); it changes no helper of this file.
The `example` checks that the statement of `adaIvReject_impl` follows via `TightM.of_old`. -/

section O2bTight

/-- **Spec of `adaIvReject`, tight premise** (O2b family 6): one fresh draw of kind `outThr` on the
non-terminal branch. -/
theorem adaIvReject_impl_t {prog : List Expr} {M : ℕ} (hS : SampLib prog) (hL : ListLib prog)
    {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) (hh : st.halted = false) (high : Bool)
    (hMt : TightM A M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] body_adaIvReject
      (fun r => Val.list [encCert r.1, adaEnc r.2]) ((outerReject A st high).toBits (adaDraw A)) := by
  -- sizes
  have hM : 2 ^ 8 * tightA A ≤ M := by unfold TightM at hMt; omega
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hstB' : valSize (Val.list (adaFields st)) ≤ tightA A := hstB
  have hZ16 := sixteen_le_adaZ A
  have hB1 : 2 * ((A.N + A.p + 16) * (adaZ A + 16)) = tightA A := by
    unfold tightA; ring
  have hBZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hrej : st.rej ≤ A.J := hok.rej_halt hh
  have hrsz : Nat.size (st.rej + 1) ≤ adaZ A :=
    (Nat.size_le_size (by omega : st.rej + 1 ≤ A.M + A.J + A.R + 2)).trans (size_MJR_le_adaZ A)
  have hrsz1 : Nat.size (st.rej + 1) ≤ Nat.size st.rej + 1 := by
    apply Nat.size_le.mpr
    have := Nat.lt_size_self st.rej
    rw [pow_succ]
    omega
  have hbsz : valSize (encB high) ≤ 2 := by cases high <;> simp [encB]
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hXM : valSize (Val.list [adaPubEnc A, adaEnc st, encB high]) ≤ M := by
    rw [ap_valSize_list3]; omega
  have hst'B : valSize (Val.list (adaFields { st with rej := st.rej + 1 })) ≤ tightA A + 1 := by
    have e1 := valSize_adaFields { st with rej := st.rej + 1 }
    have e2 := valSize_adaFields st
    simp only [valSize_encN] at e1 e2
    omega
  have hdraw : drawM A NoiseKind.outThr ≤ M := by have := drawM_le A NoiseKind.outThr; omega
  have h16 : 16 ≤ M := by omega
  have s3 : Nat.size 3 ≤ 3 := size_le_self 3
  have s4 : Nat.size 4 ≤ 4 := size_le_self 4
  have s7 : Nat.size 7 ≤ 7 := size_le_self 7
  -- the input
  have hX0 : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 0))
      (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
  have hst0 := evalsVal_atN' hX0 hXM (n := 1) rfl
  have hrej0 : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] []
      (.inl (eAtN 4 (eAtN 1 (eV 0)))) (encN st.rej) :=
    evalsVal_atN' (l := adaFields st) hst0 hstM rfl
  unfold body_adaIvReject
  -- `st' = st with rej := rej + 1`
  refine rj_letE_det (va := adaEnc { st with rej := st.rej + 1 }) ?_ ?_
  · show EvalsVal _ _ _ _ _ (Val.list ((adaFields st).set 4 (encN (st.rej + 1))))
    exact ap_set_call hL (n := 4) (l := adaFields st) hst0 (rj_lit (by decide) h16)
      (rj_add_one hrej0 (by omega)) (by unfold S_set; rw [valSize_encN]; omega)
  -- the test `rej < J`
  have hX1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 1))
      (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
  have hpub1 := evalsVal_atN' hX1 hXM (n := 0) rfl
  have hst1 := evalsVal_atN' hX1 hXM (n := 1) rfl
  have hhigh1 := evalsVal_atN' hX1 hXM (n := 2) rfl
  have hrej1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eAtN 4 (eAtN 1 (eV 1))))
      (encN st.rej) := evalsVal_atN' (l := adaFields st) hst1 hstM rfl
  have hJ1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
      Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eAtN 5 (eAtN 0 (eV 1))))
      (encN A.J) := evalsVal_atN' (l := pubFields A) hpub1 hpubM rfl
  have hcond := EvalsVal.lt hrej1 hJ1 (by omega)
  unfold outerReject
  by_cases hc : A.J + 1 ≤ st.rej + 1
  · -- the terminal rejection: `[4 − high, set st' 7 1]`
    rw [if_pos hc]
    refine ap_implements_ite_false hcond (rj_ite_eq (by omega)) ?_
    have hokT : AdaOK A { st with rej := st.rej + 1, halted := true } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hok.thrOut_le, hok.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
        fun h' => absurd h' (by simp), hok.nInt_le, hok.nNum_le⟩
    have hfinB := valSize_adaEnc_le_t hokT
    have hset : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] []
        (.inl (eCall Idx.set (eList [eV 0, eLit 7, eLit 1])))
        (adaEnc { st with rej := st.rej + 1, halted := true }) := by
      show EvalsVal _ _ _ _ _
        (Val.list ((adaFields { st with rej := st.rej + 1 }).set 7 (Val.int 1)))
      exact ap_set_call hL (n := 7) (l := adaFields { st with rej := st.rej + 1 })
        (EvalsVal.var rfl) (rj_lit (by decide) h16) (rj_lit (by decide) h16)
        (by unfold S_set; simp only [valSize_int, bitLen_one]; omega)
    apply Implements.of_det
    cases high
    · have h1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (eSub (eLit 4) (eAtN 2 (eV 1)))) (Val.int 4) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh1 (rj_small (z := 4) (by decide) h16)
      have hb4 : bitLen (4 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (ePair (eSub (eLit 4) (eAtN 2 (eV 1))) (eCall Idx.set (eList [eV 0, eLit 7, eLit 1]))))
          (Val.list [Val.int 4, adaEnc { st with rej := st.rej + 1, halted := true }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
    · have h1 : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (eSub (eLit 4) (eAtN 2 (eV 1)))) (Val.int 3) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh1 (rj_small (z := 3) (by decide) h16)
      have hb3 : bitLen (3 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (ePair (eSub (eLit 4) (eAtN 2 (eV 1))) (eCall Idx.set (eList [eV 0, eLit 7, eLit 1]))))
          (Val.list [Val.int 3, adaEnc { st with rej := st.rej + 1, halted := true }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
  · -- a new outer phase: `k ← outThr`, `[2 − high, set st' 3 k]`
    rw [if_neg hc, DrawProg.toBits_bind, toBits_drawNoise]
    refine ap_implements_ite_true hcond (rj_ite_ne (by omega)) ?_
    refine implements_letE_of (draw_impl hS hpub1 hpubM NoiseKind.outThr hdraw)
      (fun k => |k| ≤ (maxKs A : ℤ))
      (fun bits k h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A _)) ?_
    intro k hk
    have hokD : AdaOK A { st with rej := st.rej + 1, thrOut := k } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hk, hok.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
        fun _ => by show st.rej + 1 ≤ A.J; omega, hok.nInt_le, hok.nNum_le⟩
    have hfinB := valSize_adaEnc_le_t hokD
    have hksz : valSize (encZ k) ≤ adaZ A + 1 := by
      rw [valSize_encZ]
      have := bitLen_le_size_of_abs_le hk
      have := size_maxKs_le_adaZ A
      omega
    have hset : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] []
        (.inl (eCall Idx.set (eList [eV 1, eLit 3, eV 0])))
        (adaEnc { st with rej := st.rej + 1, thrOut := k }) := by
      show EvalsVal _ _ _ _ _
        (Val.list ((adaFields { st with rej := st.rej + 1 }).set 3 (encZ k)))
      exact ap_set_call hL (n := 3) (l := adaFields { st with rej := st.rej + 1 })
        (EvalsVal.var rfl) (rj_lit (by decide) h16) (EvalsVal.var rfl)
        (by unfold S_set; omega)
    have hX2 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
        Val.list [adaPubEnc A, adaEnc st, encB high]] [] (.inl (eV 2))
        (Val.list [adaPubEnc A, adaEnc st, encB high]) := EvalsVal.var rfl
    have hhigh2 := evalsVal_atN' hX2 hXM (n := 2) rfl
    apply Implements.of_det
    cases high
    · have h1 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (eSub (eLit 2) (eAtN 2 (eV 2)))) (Val.int 2) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh2 (rj_small (z := 2) (by decide) h16)
      have hb2 : bitLen (2 : ℤ) ≤ 8 := by decide
      have hp : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB false]] []
          (.inl (ePair (eSub (eLit 2) (eAtN 2 (eV 2))) (eCall Idx.set (eList [eV 1, eLit 3, eV 0]))))
          (Val.list [Val.int 2, adaEnc { st with rej := st.rej + 1, thrOut := k }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int]; omega)
      exact hp
    · have h1 : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (eSub (eLit 2) (eAtN 2 (eV 2)))) (Val.int 1) :=
        EvalsVal.sub (rj_lit (by decide) h16) hhigh2 (rj_small (z := 1) (by decide) h16)
      have hp : EvalsVal prog M [encZ k, adaEnc { st with rej := st.rej + 1 },
          Val.list [adaPubEnc A, adaEnc st, encB true]] []
          (.inl (ePair (eSub (eLit 2) (eAtN 2 (eV 2))) (eCall Idx.set (eList [eV 1, eLit 3, eV 0]))))
          (Val.list [Val.int 1, adaEnc { st with rej := st.rej + 1, thrOut := k }]) :=
        EvalsVal.pair h1 hset (by rw [ap_valSize_list2, valSize_int, bitLen_one]; omega)
      exact hp

/-- The old statement as a corollary (shape check for the integration). -/
example {prog : List Expr} {M : ℕ} (hS : SampLib prog) (hL : ListLib prog)
    {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) (hh : st.halted = false) (high : Bool)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encB high]] body_adaIvReject
      (fun r => Val.list [encCert r.1, adaEnc r.2]) ((outerReject A st high).toBits (adaDraw A)) :=
  adaIvReject_impl_t hS hL hbs hT hok hh high (TightM.of_old hM)

end O2bTight

end F2e2e.C.Impl
