import F2e2e.C.Impl.BankDefs
import F2e2e.C.Impl.HashContracts
import F2e2e.Cost.ValRules

/-!
# W5: derivation rules for the bank routines

Deterministic `EvalsVal` rules (empty tape) in the shape of the helper expressions of
`F2e2e/C/Impl/HashBasic.lean` (`eLet`, `eCall`, `eIte`, `eHd`, `eTl`, `eAt1` … `eAt7`, `eList`, …), the
sequencing rule of a deterministic `let` before a randomized body (`impl_let_det`), and the
deterministic `mapB` with a **total** size condition (`mapD_val`: the value bound only has to
dominate the sizes of the input list, of the output list and of the extra argument, not
`|l| ·` a uniform element bound).
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## Size helpers -/

theorem valSize_tail_le' (x : Val) (l : List Val) :
    valSize (Val.list l) ≤ valSize (Val.list (x :: l)) := by
  simp only [valSize_list, listSize_cons]
  omega

theorem valSize_head_le' (x : Val) (l : List Val) : valSize x ≤ valSize (Val.list (x :: l)) :=
  le_of_lt (valSize_lt_of_mem List.mem_cons_self)

theorem listSize_reverse (l : List Val) : listSize l.reverse = listSize l := by
  induction l with
  | nil => rfl
  | cons v l ih =>
    rw [List.reverse_cons, listSize_append, ih]
    simp only [listSize_cons, listSize_nil]
    omega

theorem listSize_le_of_prefix {r l : List Val} (h : r <+: l) : listSize r ≤ listSize l := by
  obtain ⟨p, rfl⟩ := h
  rw [listSize_append]
  omega

theorem valSize_reverse (l : List Val) : valSize (Val.list l.reverse) = valSize (Val.list l) := by
  simp only [valSize_list, listSize_reverse]

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-! ## Deterministic rules -/

theorem ev_var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsVal prog M env [] (.inl (eV i)) v :=
  EvalsVal.var h

theorem ev_lit {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
    EvalsVal prog M env [] (.inl (eLit z)) (Val.int z) :=
  EvalsVal.lit hM

theorem ev_nil (hM : 1 ≤ M) : EvalsVal prog M env [] (.inl Expr.nil) (Val.list []) :=
  EvalsVal.nil (by simpa using hM)

theorem ev_let {a b : Expr} {va vb : Val} (ha : EvalsVal prog M env [] (.inl a) va)
    (hb : EvalsVal prog M (va :: env) [] (.inl b) vb) :
    EvalsVal prog M env [] (.inl (eLet a b)) vb :=
  EvalsVal.letE ha hb

theorem ev_call {i : ℕ} {a body : Expr} {va vb : Val} (hbody : prog[i]? = some body)
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : EvalsVal prog M [va] [] (.inl body) vb) :
    EvalsVal prog M env [] (.inl (eCall i a)) vb :=
  EvalsVal.call ha hbody hb

theorem ev_ite_t {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsVal prog M env [] (.inl t) v) :
    EvalsVal prog M env [] (.inl (eIte c t f)) v :=
  EvalsVal.ite_true hc hz ht

theorem ev_ite_f {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsVal prog M env [] (.inl f) v) :
    EvalsVal prog M env [] (.inl (eIte c t f)) v :=
  EvalsVal.ite_false hc hz hf

/-- `ite` on a condition `if p then 1 else 0` (the value of `lt`/`eq`). -/
theorem ev_ite_dec {c t f : Expr} {p : Prop} [Decidable p] {v w : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int (if p then 1 else 0)))
    (ht : p → EvalsVal prog M env [] (.inl t) v) (hf : ¬ p → EvalsVal prog M env [] (.inl f) w) :
    EvalsVal prog M env [] (.inl (eIte c t f)) (if p then v else w) := by
  by_cases hp : p
  · rw [if_pos hp] at hc ⊢
    exact ev_ite_t hc one_ne_zero (ht hp)
  · rw [if_neg hp] at hc ⊢
    exact ev_ite_f hc rfl (hf hp)

theorem ev_hd {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list (x :: l)) ≤ M) : EvalsVal prog M env [] (.inl (eHd a)) x :=
  EvalsVal.head ha ((valSize_head_le' x l).trans hM)

theorem ev_tl {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list (x :: l)) ≤ M) : EvalsVal prog M env [] (.inl (eTl a)) (Val.list l) :=
  EvalsVal.tail ha ((valSize_tail_le' x l).trans hM)

theorem ev_at1 {a : Expr} {x0 x1 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: l)) ≤ M) : EvalsVal prog M env [] (.inl (eAt1 a)) x1 :=
  ev_hd (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at2 {a : Expr} {x0 x1 x2 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: x2 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt2 a)) x2 :=
  ev_at1 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at3 {a : Expr} {x0 x1 x2 x3 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: x2 :: x3 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: x3 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt3 a)) x3 :=
  ev_at2 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at4 {a : Expr} {x0 x1 x2 x3 x4 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt4 a)) x4 :=
  ev_at3 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at5 {a : Expr} {x0 x1 x2 x3 x4 x5 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt5 a)) x5 :=
  ev_at4 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at6 {a : Expr} {x0 x1 x2 x3 x4 x5 x6 : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: x6 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: x6 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt6 a)) x6 :=
  ev_at5 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_at7 {a : Expr} {x0 x1 x2 x3 x4 x5 x6 x7 : Val} {l : List Val}
    (ha : EvalsVal prog M env []
      (.inl a) (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: x6 :: x7 :: l)))
    (hM : valSize (Val.list (x0 :: x1 :: x2 :: x3 :: x4 :: x5 :: x6 :: x7 :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt7 a)) x7 :=
  ev_at6 (ev_tl ha hM) ((valSize_tail_le' _ _).trans hM)

theorem ev_cons {a b : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) x) (hb : EvalsVal prog M env [] (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (eCons a b)) (Val.list (x :: l)) :=
  EvalsVal.cons ha hb hM

/-- **List construction** (`HashDSL.eList`, deterministic elements). -/
theorem ev_list :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsVal prog M env [] (.inl e) v) es vs →
        valSize (Val.list vs) ≤ M → EvalsVal prog M env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsVal.nil hM
  | _ :: _, v :: vs, List.Forall₂.cons he hrest, hM =>
    ev_cons he (ev_list hrest ((valSize_tail_le' v vs).trans hM)) hM

theorem ev_pair {a b : Expr} {x y : Val} (ha : EvalsVal prog M env [] (.inl a) x)
    (hb : EvalsVal prog M env [] (.inl b) y) (hM : valSize (Val.list [x, y]) ≤ M) :
    EvalsVal prog M env [] (.inl (ePair a b)) (Val.list [x, y]) :=
  EvalsVal.pair ha hb hM

theorem ev_add {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ M) :
    EvalsVal prog M env [] (.inl (eAdd a b)) (Val.int (x + y)) :=
  EvalsVal.add ha hb hM

theorem ev_sub {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x - y)) ≤ M) :
    EvalsVal prog M env [] (.inl (eSub a b)) (Val.int (x - y)) :=
  EvalsVal.sub ha hb hM

theorem ev_mul {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x * y)) ≤ M) :
    EvalsVal prog M env [] (.inl (eMul a b)) (Val.int (x * y)) :=
  EvalsVal.mul ha hb hM

theorem ev_div {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ M) :
    EvalsVal prog M env [] (.inl (eDiv a b)) (Val.int (x / y)) :=
  EvalsVal.div ha hb hy hM

theorem ev_mod {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x % y)) ≤ M) :
    EvalsVal prog M env [] (.inl (eMod a b)) (Val.int (x % y)) :=
  EvalsVal.mod ha hb hy hM

theorem ev_lt {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (eLt a b)) (Val.int (if x < y then 1 else 0)) :=
  EvalsVal.lt ha hb hM

theorem ev_eq {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (eEq a b)) (Val.int (if x = y then 1 else 0)) :=
  EvalsVal.eq ha hb hM

theorem ev_neg {a : Expr} {x : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hM : valSize (Val.int x) ≤ M) :
    EvalsVal prog M env [] (.inl (eNeg a)) (Val.int (-x)) := by
  have h := ev_sub (ev_lit (prog := prog) (M := M) (env := env) (z := 0)
    (by simp only [valSize_int, bitLen_zero]; have := valSize_pos (Val.int x); omega)) ha
    (by simpa using hM)
  simpa using h

theorem ev_isNil_nil {a : Expr} (ha : EvalsVal prog M env [] (.inl a) (Val.list [])) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.un UnOp.isNil a)) (Val.int 1) :=
  EvalsVal.isNil_nil ha hM

theorem ev_isNil_cons {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x :: l))) (hM : 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.un UnOp.isNil a)) (Val.int 0) :=
  EvalsVal.isNil_cons ha hM

/-! ## A deterministic prefix before a randomized body -/

theorem impl_let_det {α : Type} {a b : Expr} {va : Val} {enc : α → Val} {p : BitProg α}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : Implements prog M (va :: env) b enc p) :
    Implements prog M env (eLet a b) enc p := by
  intro bits c h
  exact EvalsVal.letE ha (hb bits c h)

/-! ## `mapB` of a deterministic function, with a total size condition -/

theorem mapD_loop {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) {α β : Type} (encA : α → Val) (encB : β → Val) (extra : Val)
    (g : α → β) (l : List α)
    (hFi : ∀ x ∈ l, EvalsVal prog M [Val.list [encA x, extra]] [] (.inl bodyF) (encB (g x)))
    (hM : valSize (encL encA l) + valSize (encL encB (l.map g)) + valSize extra + 20 ≤ M) :
    ∀ r done : List α, done ++ r = l →
      EvalsVal prog M [] []
        (.inr (iStep, Val.list [encL encA r, Val.list ((done.map g).map encB).reverse, extra]))
        (Val.list ((l.map g).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro done hd
    simp only [List.append_nil] at hd
    subst hd
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil]
    refine mapBStep_nil_val iF _ extra ?_
    have h1 := valSize_reverse ((done.map g).map encB)
    simp only [encL, valSize_list, listSize_cons, listSize_nil] at hM h1 ⊢
    omega
  | cons x r ih =>
    intro done hd
    have hx : x ∈ l := by rw [← hd]; simp
    have hrest := ih (done ++ [x]) (by rw [← hd]; simp)
    have hcall := hFi x hx
    -- sizes
    have hsuf : (x :: r).map encA <:+ l.map encA := by
      rw [← hd, List.map_append]; exact List.suffix_append _ _
    have hpre : ((done ++ [x]).map g).map encB <+: (l.map g).map encB := by
      exact ⟨(r.map g).map encB, by rw [← hd]; simp⟩
    have hS1 := listSize_le_of_suffix hsuf
    have hS2 := listSize_le_of_prefix hpre
    have hrev := listSize_reverse ((done.map g).map encB)
    simp only [List.map_append, List.map_cons, List.map_nil, listSize_append, listSize_cons,
      listSize_nil] at hS1 hS2
    have hbody := mapBStep_cons_val (R := r.map encA) (A := ((done.map g).map encB).reverse)
      (x := encA x) hF hcall (by
        simp only [encL, valSize_list, listSize_cons, listSize_nil] at hM ⊢
        rw [hrev]
        omega)
    have hacc : Val.list (encB (g x) :: ((done.map g).map encB).reverse) =
        Val.list (((done ++ [x]).map g).map encB).reverse := by simp
    rw [hacc] at hbody
    have h := EvalsVal.cont hstep hbody one_ne_zero hrest
    simpa [encL] using h

/-- **`mapB` of a deterministic element routine** (`body_mapB iStep`, element routine at `iF`). -/
theorem mapD_val {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) (hrev : prog[Cost.Idx.reverse]? = some body_reverse)
    (hra : prog[Cost.Idx.revAppendStep]? = some body_revAppendStep)
    {α β : Type} (encA : α → Val) (encB : β → Val) (extra : Val) (g : α → β) (l : List α)
    (hFi : ∀ x ∈ l, EvalsVal prog M [Val.list [encA x, extra]] [] (.inl bodyF) (encB (g x)))
    (hM : valSize (encL encA l) + 5 * valSize (encL encB (l.map g)) + valSize extra + 60 ≤ M) :
    EvalsVal prog M [Val.list [encL encA l, extra]] [] (.inl (body_mapB iStep))
      (encL encB (l.map g)) := by
  have hloop := mapD_loop hstep hF encA encB extra g l hFi (by omega) l [] (by simp)
  simp only [List.map_nil, List.reverse_nil] at hloop
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [encL encA l, Val.list [], extra]) := by
    have := EvalsVal.triple (EvalsVal.head (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (by omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hl := EvalsVal.loop hinit hloop
  have hrs := (reverse_spec hra ((l.map g).map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  have hsz := valSize_reverse ((l.map g).map encB)
  have hcall := EvalsVal.call hl hrev (hrs.mono_M (by
    simp only [S_reverse]
    rw [hsz]
    simp only [encL] at hM
    omega))
  simpa [encL, body_mapB] using hcall

end rules

end F2e2e.C.Impl.BankDSL
