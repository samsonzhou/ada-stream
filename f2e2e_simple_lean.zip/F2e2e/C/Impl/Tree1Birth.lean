import F2e2e.C.Impl.Tree1Born

/-!
# W6, Tree1: one birth (`birthDepth`) in the DSL — the parts

`body_birthDepth = letE d (letE st (letE ex (letE b1 (letE bd_b2 bd_cont))))` (Tree1Defs). This file
proves the parts against C-ALG's `birthDepth`, split at the allocation of the outgoing bank
(`birthDepth_eq : birthDepth P d₀ d s = (s2Prog P d s).bind (birthCont P d₀ d)`, Tree1Facts):

* `resetAt_val`: `b1 = modifyAt (Bank.mapRows Row.resetY) d banks` (DSL-CALC `mapIdx`, W5 `resetYBank`);
* `bd_b2_impl`: `bd_b2` implements `s2Prog P d s` (banks only; W3 `newBank`, library `append`);
  `s2Prog_facts`: every run only replaces the banks, by at most `H` valid banks;
* `leaf_fail_val`, `leaf_learner_val`: the result states (`fail`, or a new learner appended with the
  library `append`), generic in the positions of `st`, `ex` and the banks in the environment;
* `bd_N_some_of`, `bd_N_some`, `bd_N_none`, `bd_rel_impl`, `bd_B_impl`, `bd_cont_impl`: the
  continuation implements `birthCont` (W5 `release`, `roundMantQ`, `normQ`, `inRangeA`; C-SPACE
  `release_qok`; library `getOpt`, `set`);
* `birthDepth_impl` (one birth) and `birthElem_impl` (the element routine of the birth loop).

The size of every result state is taken from a post-condition `Always … (valSize (encState …) ≤ M)`
(C-SPACE `birthDepth_ok`, C-ALG `birthDepth_birth`) carried along the runs (`always_of_bind_run`).
-/

namespace F2e2e.C.Impl.T1

open F2e2e F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-! ## Values of the environment -/

/-- The input `Y = [d, st, ex]` of one birth. -/
def yVal (R : AdaRep) (P : StreamParams) (d0 d : ℕ) (s : State) : Val :=
  Val.list [encN d, encState R.enc s, exVal P d0]

/-- The banks after the reset of the incoming secondary array. -/
def b1Val (R : AdaRep) (d : ℕ) (s : State) : Val :=
  encL (encBank R.enc) (modifyAt (Bank.mapRows Row.resetY) d s.banks)

/-! ## Field access -/

section Fields

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_stfields {adaEnc : F2e2e.B.AdaState → Val} {e : Expr} {s : State}
    (h : EvalsVal prog M env [] (.inl e) (encState adaEnc s)) (hM : valSize (encState adaEnc s) ≤ M) :
    EvalsVal prog M env [] (.inl (eGet 0 e)) (Val.int (s.t : ℤ)) ∧
    EvalsVal prog M env [] (.inl (eGet 1 e)) (Val.int (if s.failed then 1 else 0)) ∧
    EvalsVal prog M env [] (.inl (eGet 2 e)) (Val.int (s.fpSeed : ℤ)) ∧
    EvalsVal prog M env [] (.inl (eGet 3 e)) (Val.int (s.fpVal : ℤ)) ∧
    EvalsVal prog M env [] (.inl (eGet 4 e)) (encL encLearner s.learners) ∧
    EvalsVal prog M env [] (.inl (eGet 5 e)) (encL (encBank adaEnc) s.banks) ∧
    EvalsVal prog M env [] (.inl (eGet 6 e)) (Val.int s.leaf) := by
  rw [encState_eq] at h hM
  exact ⟨ev_get 0 h hM rfl, ev_get 1 h hM rfl, ev_get 2 h hM rfl, ev_get 3 h hM rfl,
    ev_get 4 h hM rfl, ev_get 5 h hM rfl, ev_get 6 h hM rfl⟩

theorem ev_exfields {P : StreamParams} {d0 : ℕ} {e : Expr}
    (h : EvalsVal prog M env [] (.inl e) (exVal P d0)) (hM : valSize (exVal P d0) ≤ M) :
    EvalsVal prog M env [] (.inl (eGet 0 e)) (encStreamParams P) ∧
    EvalsVal prog M env [] (.inl (eGet 1 e)) (encN d0) ∧
    EvalsVal prog M env [] (.inl (eGet 2 e)) (encN P.H) ∧
    EvalsVal prog M env [] (.inl (eGet 3 e)) (encN (2 ^ P.eHC)) ∧
    EvalsVal prog M env [] (.inl (eGet 4 e)) (encN P.eHP) ∧
    EvalsVal prog M env [] (.inl (eGet 5 e)) (encN (2 ^ P.eHP)) := by
  unfold exVal at h hM
  exact ⟨ev_get 0 h hM rfl, ev_get 1 h hM rfl, ev_get 2 h hM rfl, ev_get 3 h hM rfl,
    ev_get 4 h hM rfl, ev_get 5 h hM rfl⟩

end Fields

/-! ## Common size facts -/

section SizeFacts

variable {R : AdaRep} {P : StreamParams}

theorem ssb_ge (P : StreamParams) (a : ℕ) : 2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P a :=
  W6.stateSizeBound_ge P a

theorem Mv_eq (R : AdaRep) (P : StreamParams) : Mv R P = 2 ^ 32 * stateSizeBound P (R.bound P) := rfl

theorem valSize_newLearnerVal (P : StreamParams) {c : ℤ} (hc : bitLen c ≤ 2 ^ 9 * P.calL ^ 3) :
    valSize (Val.list [encN (2 ^ P.eHC), Val.int c, Val.int 0, Val.int 0, Val.int 0]) ≤
      2 ^ 10 * P.calL ^ 3 := by
  have hHC := eHC_le P
  have s3 : Nat.size (2 ^ P.eHC) = P.eHC + 1 := Nat.size_pow
  have hc1 := hundred_le_calL P
  have hc3 : 1 ≤ P.calL ^ 3 := Nat.one_le_pow _ _ (by omega)
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen_zero]
  omega

end SizeFacts

/-! ## `b1`: the reset of the incoming secondary array (`mapIdx`, W5 `resetYBank`) -/

section ResetAt

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

theorem resetAtElem_val (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {d i : ℕ} {B : Bank} (hB : BankOK P (R.ok P) B)
    (hsz : valSize (Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encN d, encStreamParams P]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
        Val.list [encN d, encStreamParams P]]] [] (.inl body_resetAtElem)
      (encBank R.enc (if i = d then B.mapRows Row.resetY else B)) := by
  obtain ⟨bY, hbY, hY⟩ := hC.w5.resetYBank
  have hX : EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encN d, encStreamParams P]]] [] (.inl (Expr.var 0))
      (Val.list [Val.int (i : ℤ), encBank R.enc B, Val.list [encN d, encStreamParams P]]) :=
    EvalsVal.var rfl
  have hEsz : valSize (Val.list [encN d, encStreamParams P]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encN d, encStreamParams P]]) rfl).trans hsz
  have hE := ev_get 2 hX hsz rfl
  have h2M : 2 ≤ M := by
    have := valSize_pos (Val.int (i : ℤ))
    simp only [valSize_list, listSize_cons, listSize_nil] at hsz
    omega
  have hc := ev_eq (ev_get 0 hX hsz rfl) (ev_get 0 hE hEsz rfl) h2M
  by_cases hid : i = d
  · subst hid
    rw [if_pos rfl]
    refine ev_ite_true hc (by simp) ?_
    have hBsz : valSize (Val.list [encStreamParams P, encBank R.enc B]) ≤ M := by
      refine le_trans ?_ hsz
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    exact evalsVal_call_det hbY (ev_list (.cons (ev_get 1 hE hEsz rfl) (.cons (ev_get 1 hX hsz rfl)
      .nil)) hBsz) (hY P B hP hB hM)
  · rw [if_neg hid]
    refine ev_ite_false hc (by simp [hid]) ?_
    exact ev_get 1 hX hsz rfl

/-- **`b1`** (`mapIdx` with the element routine `resetAtElem`). -/
theorem resetAt_val (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d : ℕ} {banks : List Bank}
    (hB : ∀ B ∈ banks, BankOK P (R.ok P) B) (hlen : banks.length ≤ P.H) (hd : d < P.H) :
    EvalsVal prog M [Val.list [encL (encBank R.enc) banks, Val.list [encN d, encStreamParams P]]] []
      (.inl body_resetAt) (encL (encBank R.enc) (modifyAt (Bank.mapRows Row.resetY) d banks)) := by
  have hVS := Mv_eq R P
  have hss := ssb_ge P (R.bound P)
  have hbanks := banks_size_le hR hP hB hlen
  have hp := valSize_encStreamParams_le P
  have hH := H_le P
  have hdsz : Nat.size d ≤ P.calL := (size_le_self d).trans (hd.le.trans hH)
  have hc3 := hundred_mul_sq_le_cube P
  have hc2 := hundred_mul_calL_le_sq P
  have hext : valSize (Val.list [encN d, encStreamParams P]) ≤ 2 ^ 4 * P.calL ^ 3 := by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have hNB : ∀ B, BankOK P (R.ok P) B → valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) :=
    fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) hB
  have hval := mapIdx_val (prog := prog) (M := M) hT.resetAtStep hT.resetAtElem hT.reverse
    hT.revAppendStep (encBank R.enc) (encBank R.enc) (Val.list [encN d, encStreamParams P])
    (fun i B => if i = d then B.mapRows Row.resetY else B) banks (bankSizeBound P (R.bound P))
    (fun i B hBm hi => resetAtElem_val hC hP hM (hB B hBm) (by
      have h1 := bank_size_le hR hP (hB B hBm)
      have h2 : bitLen (i : ℤ) ≤ P.calL := by
        rw [bitLen_natCast]
        exact (size_le_self i).trans (by omega)
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hext ⊢
      omega))
    (fun i B hBm => by
      by_cases hid : i = d
      · rw [if_pos hid]; exact hNB _ (BankOK.resetY (hB B hBm))
      · rw [if_neg hid]; exact hNB _ (hB B hBm))
    (by
      unfold mapIdx_M
      have h2 : banks.length * (bankSizeBound P (R.bound P) + 1) ≤
          P.H * (bankSizeBound P (R.bound P) + 1) := Nat.mul_le_mul_right _ hlen
      have h3 : P.H * (bankSizeBound P (R.bound P) + 1) ≤ stateSizeBound P (R.bound P) := by
        unfold stateSizeBound; omega
      have h4 := bankSizeBound_le_ssb P (R.bound P)
      have hsl : Nat.size banks.length ≤ P.calL := (size_le_self _).trans (hlen.trans hH)
      omega)
  rw [modifyAt_eq_modifyAtL, modifyAtL_eq]
  exact hval

end ResetAt

/-! ## Small `Implements` and size helpers -/

section Helpers2

variable {prog : List Expr} {M : ℕ} {env : List Val} {β : Type}

/-- `letE` whose continuation only needs to implement `f a` for the outputs `a` of `p`. -/
theorem impl_letE_run {α : Type} {ea eb : Expr} {encA : α → Val} {encC : β → Val} {p : BitProg α}
    {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

/-- `letE` with a deterministic bound expression. -/
theorem impl_letE_det {ea eb : Expr} {va : Val} {enc : β → Val} {p : BitProg β}
    (ha : EvalsVal prog M env [] (.inl ea) va) (hb : Implements prog M (va :: env) eb enc p) :
    Implements prog M env (Expr.letE ea eb) enc p := by
  intro bits c h
  simpa using EvalsVal.letE ha (hb bits c h)

theorem implements_pure {e : Expr} {enc : β → Val} {a : β}
    (h : EvalsVal prog M env [] (.inl e) (enc a)) : Implements prog M env e enc (BitProg.pure a) := by
  intro bits a' hr
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp hr
  exact h

theorem implements_ite_ne {c t f : Expr} {z : ℤ} {enc : β → Val} {p : BitProg β}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : Implements prog M env t enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  implements_ite hc (by rw [if_pos hz]; exact ht)

theorem implements_ite_eq {c t f : Expr} {z : ℤ} {enc : β → Val} {p : BitProg β}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : Implements prog M env f enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  implements_ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem ev_lt1 {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (Val.int (if x < y then 1 else 0)) :=
  EvalsVal.lt ha hb hM

theorem ite_one_zero_ne {p : Prop} [Decidable p] (h : p) : (if p then (1 : ℤ) else 0) ≠ 0 := by
  rw [if_pos h]; exact one_ne_zero

theorem ite_one_zero_eq {p : Prop} [Decidable p] (h : ¬ p) : (if p then (1 : ℤ) else 0) = 0 := by
  rw [if_neg h]

theorem vs_single (a : Val) : valSize (Val.list [a]) = valSize a + 2 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem vs_pair (a b : Val) : valSize (Val.list [a, b]) = valSize a + valSize b + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem vs_triple (a b c : Val) :
    valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

end Helpers2

/-- The size facts used everywhere below. -/
theorem sz_facts (R : AdaRep) (P : StreamParams) {M : ℕ} (hM : Mv R P ≤ M) :
    2 ^ 32 * stateSizeBound P (R.bound P) ≤ M ∧ 2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P (R.bound P) ∧
      100 ≤ P.calL ∧ 100 ≤ P.calL ^ 3 ∧ 100 * P.calL ≤ P.calL ^ 2 ∧
      100 * P.calL ^ 2 ≤ P.calL ^ 3 ∧ regBits P = 2 ^ 7 * P.calL ^ 3 :=
  ⟨hM, ssb_ge P _, hundred_le_calL P, SizeAux.hundred_le_calL_cube P, hundred_mul_calL_le_sq P,
    hundred_mul_sq_le_cube P, regBits_eq P⟩

/-- An optional `QOK` rational is small. -/
theorem valSize_encOptQ_le {P : StreamParams} {o : Option ℚ} (h : ∀ N, o = some N → QOK P N) :
    valSize (encOptQ o) ≤ 8 * regBits P + 9 := by
  cases o with
  | none => simp only [encOptQ, valSize_list, listSize_nil]; omega
  | some N =>
    have := valSize_encQ_le_of_QOK (h N rfl)
    simp only [encOptQ, vs_single]
    omega

/-- The environment after the first three `let`s of `body_birthDepth`: `[ex, st, d, Y]`. -/
def env3 (R : AdaRep) (P : StreamParams) (d0 d : ℕ) (s : State) : List Val :=
  [exVal P d0, encState R.enc s, encN d, yVal R P d0 d s]

/-! ## The five result states -/

section Leaves

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

/-- The leaf `{s with banks := bs}.fail` from the fields of `st = env[k]` and the banks `env[j]`. -/
theorem leaf_fail_val {env : List Val} (k j : ℕ) {s : State} {bs : List Bank}
    (hst : env[k]? = some (encState R.enc s)) (hbs : env[j]? = some (encL (encBank R.enc) bs))
    (hstM : valSize (encState R.enc s) ≤ M)
    (hout : valSize (encState R.enc ({ s with banks := bs } : State).fail) ≤ M) :
    EvalsVal prog M env [] (.inl (eList [eGet 0 (Expr.var k), Expr.lit 1, eGet 2 (Expr.var k),
        eGet 3 (Expr.var k), eGet 4 (Expr.var k), Expr.var j, eGet 6 (Expr.var k)]))
      (encState R.enc ({ s with banks := bs } : State).fail) := by
  obtain ⟨h0, -, h2, h3, h4, -, h6⟩ := ev_stfields (e := Expr.var k) (EvalsVal.var hst) hstM
  have e : encState R.enc ({ s with banks := bs } : State).fail = Val.list [Val.int (s.t : ℤ),
      Val.int 1, Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ), encL encLearner s.learners,
      encL (encBank R.enc) bs, Val.int s.leaf] := rfl
  rw [e] at hout ⊢
  have h1 : valSize (Val.int 1) ≤ M := by
    simp only [valSize_list, listSize_cons] at hout
    omega
  exact ev_list (.cons h0 (.cons (EvalsVal.lit' h1) (.cons h2 (.cons h3 (.cons h4
    (.cons (EvalsVal.var hbs) (.cons h6 .nil))))))) hout

/-- The leaf `{s with banks := bs, learners := learners ++ [newLearner P c]}`: fields of
`st = env[k]`, the banks `env[j]`, the tag `2^{eHC}` from `ex = env[i]`, the cache from `cacheE`
(library `append`). -/
theorem leaf_learner_val (hT : Tree1Lib prog) {P : StreamParams} {d0 : ℕ} {env : List Val}
    (k j i : ℕ) {cacheE : Expr} {c : ℤ} {s : State} {bs : List Bank}
    (hst : env[k]? = some (encState R.enc s)) (hbs : env[j]? = some (encL (encBank R.enc) bs))
    (hex : env[i]? = some (exVal P d0)) (hc : EvalsVal prog M env [] (.inl cacheE) (Val.int c))
    (hcb : bitLen c ≤ 2 ^ 9 * P.calL ^ 3) (hM : Mv R P ≤ M)
    (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P)) (hd0 : d0 ≤ P.H)
    (hout : valSize (encState R.enc
      ({ s with banks := bs, learners := s.learners ++ [newLearner P c] } : State)) ≤ M) :
    EvalsVal prog M env [] (.inl (eList [eGet 0 (Expr.var k), eGet 1 (Expr.var k),
        eGet 2 (Expr.var k), eGet 3 (Expr.var k), Expr.call F2e2e.Cost.Idx.append
          (eList [eGet 4 (Expr.var k), eList [eLearner (eGet 3 (Expr.var i)) cacheE]]),
        Expr.var j, eGet 6 (Expr.var k)]))
      (encState R.enc
        ({ s with banks := bs, learners := s.learners ++ [newLearner P c] } : State)) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hstM : valSize (encState R.enc s) ≤ M := by omega
  have hexM : valSize (exVal P d0) ≤ M := by have := valSize_exVal_le P hd0; omega
  obtain ⟨h0, h1, h2, h3, h4, -, h6⟩ := ev_stfields (e := Expr.var k) (EvalsVal.var hst) hstM
  obtain ⟨-, -, -, hx3, -, -⟩ := ev_exfields (e := Expr.var i) (EvalsVal.var hex) hexM
  have hnl := valSize_newLearnerVal P hcb
  have hlsz : valSize (Val.list (s.learners.map encLearner)) ≤ stateSizeBound P (R.bound P) := by
    have : valSize (encL encLearner s.learners) ≤ valSize (encState R.enc s) := by
      rw [encState_eq]; exact valSize_of_getElem?_le (k := 4) rfl
    exact this.trans hss
  have h0M : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hL : EvalsVal prog M env [] (.inl (eLearner (eGet 3 (Expr.var i)) cacheE))
      (Val.list [encN (2 ^ P.eHC), Val.int c, Val.int 0, Val.int 0, Val.int 0]) :=
    ev_list (.cons hx3 (.cons hc (.cons (EvalsVal.lit' h0M) (.cons (EvalsVal.lit' h0M)
      (.cons (EvalsVal.lit' h0M) .nil))))) (by omega)
  rw [← encLearner_newLearner] at hL hnl
  have hL1 : EvalsVal prog M env [] (.inl (eList [eLearner (eGet 3 (Expr.var i)) cacheE]))
      (Val.list [encLearner (newLearner P c)]) :=
    ev_list (.cons hL .nil) (by rw [vs_single]; omega)
  have harg : EvalsVal prog M env [] (.inl (eList [eGet 4 (Expr.var k),
      eList [eLearner (eGet 3 (Expr.var i)) cacheE]]))
      (Val.list [Val.list (s.learners.map encLearner), Val.list [encLearner (newLearner P c)]]) :=
    ev_list (.cons h4 (.cons hL1 .nil)) (by rw [vs_pair, vs_single]; omega)
  have happ := (append_spec hT.revAppendStep (s.learners.map encLearner)
    [encLearner (newLearner P c)] 0).toVal.mono_M (M' := M)
    (by unfold S_append; rw [vs_pair, vs_single]; omega)
  have hcall := evalsVal_call_det hT.append harg happ
  have e2 : Val.list (s.learners.map encLearner ++ [encLearner (newLearner P c)]) =
      encL encLearner (s.learners ++ [newLearner P c]) := by
    simp only [encL, List.map_append, List.map_cons, List.map_nil]
  rw [e2] at hcall
  have e : encState R.enc
      ({ s with banks := bs, learners := s.learners ++ [newLearner P c] } : State) =
      Val.list [Val.int (s.t : ℤ), Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ),
        Val.int (s.fpVal : ℤ), encL encLearner (s.learners ++ [newLearner P c]),
        encL (encBank R.enc) bs, Val.int s.leaf] := rfl
  rw [e] at hout ⊢
  exact ev_list (.cons h0 (.cons h1 (.cons h2 (.cons h3 (.cons hcall (.cons (EvalsVal.var hbs)
    (.cons h6 .nil))))))) hout

end Leaves

/-! ## The allocation of the outgoing bank (`bd_b2`) -/

section Alloc

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

/-- Every run of `s2Prog` changes only the banks, to a list of at most `H` valid banks. -/
theorem s2Prog_facts {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop}
    (hA : AdaInvariant P adaOK) {c d : ℕ} {s : State} (hs : StateOK P adaOK c s)
    (hb : s.banks.length ≤ d + 1) :
    Always (s2Prog P d s) (fun s2 => ∃ bs, s2 = { s with banks := bs } ∧
      (∀ B ∈ bs, BankOK P adaOK B) ∧ bs.length ≤ P.H) := by
  have hb1 : ∀ B ∈ modifyAt (Bank.mapRows Row.resetY) d s.banks, BankOK P adaOK B :=
    Aux.forall_mem_modifyAt _ (fun B hB => hB.resetY) _ _ hs.banks_ok
  unfold s2Prog
  split_ifs with hd2
  · refine Always.bind (fun B hB => always_pure ⟨_, rfl, ?_, ?_⟩) (always_newBank P hA)
    · intro B' hB'
      rw [List.mem_append, List.mem_singleton] at hB'
      rcases hB' with hB' | rfl
      · exact hb1 B' hB'
      · exact hB
    · simp only [s1Of, List.length_append, length_modifyAt, List.length_cons, List.length_nil]
      omega
  · exact always_pure ⟨_, rfl, hb1, by simp only [length_modifyAt]; exact hs.banks_length_le⟩

/-- **`bd_b2`** implements the allocation `s2Prog P d s` (banks only; W3 `newBank`, library
`append`). -/
theorem bd_b2_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State}
    (hs : StateOK P (R.ok P) 4 s) (hd : d < P.H) (hd0 : d0 ≤ P.H) :
    Implements prog M (b1Val R d s :: env3 R P d0 d s) bd_b2
      (fun s2 => encL (encBank R.enc) s2.banks) (s2Prog P d s) := by
  obtain ⟨bnb, hbnb, hnb⟩ := hC.w3.newBank
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hA := hR.invariant P hP
  have hex := valSize_exVal_le P hd0
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have hH := H_le P
  have hb1 : ∀ B ∈ modifyAt (Bank.mapRows Row.resetY) d s.banks, BankOK P (R.ok P) B :=
    Aux.forall_mem_modifyAt _ (fun B hB => hB.resetY) _ _ hs.banks_ok
  have hb1sz : valSize (b1Val R d s) ≤ stateSizeBound P (R.bound P) :=
    banks_size_le hR hP hb1 (by rw [length_modifyAt]; exact hs.banks_length_le)
  have hb1sz' : valSize (Val.list ((modifyAt (Bank.mapRows Row.resetY) d s.banks).map
      (encBank R.enc))) ≤ stateSizeBound P (R.bound P) := hb1sz
  have hd1 : valSize (Val.int ((d : ℤ) + 1)) ≤ M := by
    have e : ((d : ℤ) + 1) = ((d + 1 : ℕ) : ℤ) := by push_cast; ring
    rw [e, valSize_int, bitLen_natCast]
    have := size_le_self (d + 1)
    omega
  have h1M : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hc : EvalsVal prog M (b1Val R d s :: env3 R P d0 d s) []
      (.inl (Expr.bin BinOp.lt (Expr.bin BinOp.add (Expr.var 3) (Expr.lit 1))
        (eGet 2 (Expr.var 1))))
      (Val.int (if (d : ℤ) + 1 < (P.H : ℤ) then 1 else 0)) :=
    ev_lt1 (ev_add (EvalsVal.var rfl) (EvalsVal.lit' h1M) hd1)
      (ev_get 2 (EvalsVal.var rfl) hexM rfl) h2M
  unfold s2Prog bd_b2
  by_cases h2 : d + 2 ≤ P.H
  · rw [if_pos h2]
    refine implements_ite_ne hc (ite_one_zero_ne (by omega)) ?_
    refine impl_letE_run (implements_call_det hbnb (ev_get 0 (EvalsVal.var rfl) hexM rfl)
      (hnb P hP hM)) (fun bits B hrun => ?_)
    have hB : BankOK P (R.ok P) B := Always.of_run (always_newBank P hA) hrun
    have hBsz : valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) :=
      BankOK.valSize_encBank_le (hR.enc_le P hP) hB
    have hbb := bankSizeBound_le_ssb P (R.bound P)
    apply implements_pure
    have happ := (append_spec hT.revAppendStep
      ((modifyAt (Bank.mapRows Row.resetY) d s.banks).map (encBank R.enc)) [encBank R.enc B]
      0).toVal.mono_M (M' := M) (by unfold S_append; rw [vs_pair, vs_single]; omega)
    have e : encL (encBank R.enc) (modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B]) =
        Val.list ((modifyAt (Bank.mapRows Row.resetY) d s.banks).map (encBank R.enc) ++
          [encBank R.enc B]) := by
      simp only [encL, List.map_append, List.map_cons, List.map_nil]
    show EvalsVal prog M _ [] _
      (encL (encBank R.enc) (modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B]))
    rw [e]
    exact evalsVal_call_det hT.append (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_list (.cons
      (EvalsVal.var rfl) .nil) (by rw [vs_single]; omega)) .nil))
      (by rw [vs_pair, vs_single]; omega)) happ
  · rw [if_neg h2]
    refine implements_ite_eq hc (ite_one_zero_eq (by omega)) ?_
    exact implements_pure (EvalsVal.var rfl)

end Alloc

/-! ## The release branch -/

section Release

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

/-- After the release returned `some N`: the cache `roundMant eHP N` (W5 `roundMantQ`) and the range
check of `cache / 2^{eHP}` (`normQ`, W5 `inRangeA`); then the final branch. -/
theorem bd_N_some_of (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {d0 : ℕ} (hd0 : d0 ≤ P.H) {N : ℚ}
    (hN : QOK P N ∧ 0 ≤ N ∧ |roundMant P.eHP N| < 2 ^ (2 * regBits P)) {B' : Bank}
    (hB' : valSize (encBank R.enc B') ≤ stateSizeBound P (R.bound P)) {b3 ob b2 b1 : Val}
    {rest : List Val} {v : Val}
    (hleaf : EvalsVal prog M (encB (inRangeA P (gridVal P.eHP (roundMant P.eHP N))) ::
      Val.int (roundMant P.eHP N) :: b3 :: Val.list [encOptQ (some N), encBank R.enc B'] :: ob ::
      b2 :: b1 :: exVal P d0 :: rest) [] (.inl (Expr.ite (Expr.var 0) bd_succ bd_fail4)) v) :
    EvalsVal prog M (b3 :: Val.list [encOptQ (some N), encBank R.enc B'] :: ob :: b2 :: b1 ::
      exVal P d0 :: rest) [] (.inl bd_N) v := by
  obtain ⟨brm, hbrm, hrm⟩ := hC.w5.roundMantQ
  obtain ⟨bnq, hbnq, hnq⟩ := hC.normQ
  obtain ⟨bir, hbir, hir⟩ := hC.w5.inRangeA
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  obtain ⟨hQN, -, hcabs⟩ := hN
  have hex := valSize_exVal_le P hd0
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have hp := valSize_encStreamParams_le P
  have hHP := eHP_le P
  have hHPreg : P.eHP ≤ regBits P := by omega
  have hQsz := valSize_encQ_le_of_QOK hQN
  have hresM : valSize (Val.list [encOptQ (some N), encBank R.enc B']) ≤ M := by
    rw [vs_pair]; simp only [encOptQ, vs_single]; omega
  have hcb : bitLen (roundMant P.eHP N) ≤ 2 * regBits P := bitLen_le_of_abs_lt hcabs
  have hpb : bitLen (((2 ^ P.eHP : ℕ)) : ℤ) = P.eHP + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hQg : QOK P (gridVal P.eHP (roundMant P.eHP N)) := qok_gridVal hcabs (by omega) (by omega)
  have hQgsz := valSize_encQ_le_of_QOK hQg
  have hgcast : ((roundMant P.eHP N : ℤ) : ℚ) / ((((2 ^ P.eHP : ℕ)) : ℤ) : ℚ) =
      gridVal P.eHP (roundMant P.eHP N) := by
    unfold gridVal; push_cast; rfl
  have hnqv := hnq (roundMant P.eHP N) ((2 ^ P.eHP : ℕ) : ℤ) (by positivity) (by rw [hpb]; omega)
  rw [hgcast] at hnqv
  have hHPsz : valSize (encN P.eHP) ≤ 7 * P.calL ^ 2 + 1 := by
    rw [valSize_encN]; have := size_le_self P.eHP; omega
  have hpow : valSize (encN (2 ^ P.eHP)) = P.eHP + 2 := by rw [valSize_encN, Nat.size_pow]
  unfold bd_N
  refine ev_ite_false (EvalsVal.isNil_cons (ev_get 0 (EvalsVal.var rfl) hresM rfl) (by omega)) rfl ?_
  refine ev_letE (evalsVal_call_det hbrm (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hexM rfl)
    (.cons (EvalsVal.head (ev_get 0 (EvalsVal.var rfl) hresM rfl) (by omega)) .nil))
    (by rw [vs_pair]; omega)) (hrm P P.eHP N hP hHPreg hQN hM)) ?_
  refine ev_letE (evalsVal_call_det hbir (ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hexM rfl)
    (.cons (evalsVal_call_det hbnq (ev_list (.cons (EvalsVal.var rfl) (.cons
      (ev_get 5 (EvalsVal.var rfl) hexM rfl) .nil))
      (by rw [vs_pair, hpow, valSize_int]; omega)) hnqv) .nil))
    (by rw [vs_pair]; omega)) (hir P _ hP hQg hM)) ?_
  exact hleaf

/-- After the release returned `some N`. -/
theorem bd_N_some (hC : Contracts R prog M) (hT : Tree1Lib prog) {P : StreamParams}
    (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State} {bs : List Bank} {N : ℚ}
    {B' : Bank} {ob : Val} (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P))
    (hd0 : d0 ≤ P.H) (hB' : valSize (encBank R.enc B') ≤ stateSizeBound P (R.bound P))
    (hN : QOK P N ∧ 0 ≤ N ∧ |roundMant P.eHP N| < 2 ^ (2 * regBits P))
    (hq : Always (if inRangeA P (gridVal P.eHP (roundMant P.eHP N)) then
        BitProg.pure ({ s with
          banks := setAt B' d bs
          learners := s.learners ++ [newLearner P (roundMant P.eHP N)] } : State)
      else BitProg.pure ({ s with banks := setAt B' d bs } : State).fail)
      (fun a => valSize (encState R.enc a) ≤ M)) :
    Implements prog M (encL (encBank R.enc) (setAt B' d bs) ::
        Val.list [encOptQ (some N), encBank R.enc B'] :: ob :: encL (encBank R.enc) bs ::
        b1Val R d s :: env3 R P d0 d s) bd_N (encState R.enc)
      (if inRangeA P (gridVal P.eHP (roundMant P.eHP N)) then
        BitProg.pure ({ s with
          banks := setAt B' d bs
          learners := s.learners ++ [newLearner P (roundMant P.eHP N)] } : State)
      else BitProg.pure ({ s with banks := setAt B' d bs } : State).fail) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hstM : valSize (encState R.enc s) ≤ M := by omega
  have hcb : bitLen (roundMant P.eHP N) ≤ 2 ^ 9 * P.calL ^ 3 := by
    have := bitLen_le_of_abs_lt hN.2.2; omega
  cases hr : inRangeA P (gridVal P.eHP (roundMant P.eHP N))
  · rw [hr, if_neg Bool.false_ne_true] at hq
    rw [if_neg Bool.false_ne_true]
    refine implements_pure (bd_N_some_of hC hP hM hd0 hN hB' ?_)
    rw [hr]
    refine ev_ite_encB (b := false) (EvalsVal.var rfl) ?_
    rw [if_neg Bool.false_ne_true]
    exact leaf_fail_val 8 2 rfl rfl hstM hq
  · rw [hr, if_pos rfl] at hq
    rw [if_pos rfl]
    refine implements_pure (bd_N_some_of hC hP hM hd0 hN hB' ?_)
    rw [hr]
    refine ev_ite_encB (b := true) (EvalsVal.var rfl) ?_
    rw [if_pos rfl]
    exact leaf_learner_val hT 8 2 7 rfl rfl rfl (EvalsVal.var rfl) hcb hM hss hd0 hq

/-- After the release returned nothing. -/
theorem bd_N_none {P : StreamParams} (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State} {bs : List Bank}
    {B' : Bank} {ob : Val} (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P))
    (hB' : valSize (encBank R.enc B') ≤ stateSizeBound P (R.bound P))
    (hout : valSize (encState R.enc ({ s with banks := setAt B' d bs } : State).fail) ≤ M) :
    EvalsVal prog M (encL (encBank R.enc) (setAt B' d bs) ::
        Val.list [encOptQ none, encBank R.enc B'] :: ob :: encL (encBank R.enc) bs ::
        b1Val R d s :: env3 R P d0 d s) [] (.inl bd_N)
      (encState R.enc ({ s with banks := setAt B' d bs } : State).fail) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hstM : valSize (encState R.enc s) ≤ M := by omega
  have hresM : valSize (Val.list [encOptQ none, encBank R.enc B']) ≤ M := by
    rw [vs_pair]; simp only [encOptQ, valSize_list, listSize_nil]; omega
  unfold bd_N
  exact ev_ite_true (EvalsVal.isNil_nil (ev_get 0 (EvalsVal.var rfl) hresM rfl) (by omega))
    one_ne_zero (leaf_fail_val 6 0 rfl rfl hstM hout)

/-- **The release branch** (`ob = some B`): W5 `release` (fresh bits), library `set`, then `bd_N`. -/
theorem bd_rel_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State} {bs : List Bank}
    {B : Bank} (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P)) (_hd : d < P.H)
    (hd0 : d0 ≤ P.H) (hbs : ∀ B ∈ bs, BankOK P (R.ok P) B) (hlen : bs.length ≤ P.H)
    (hB : bs[d]? = some B) (hnot : ¬ (d = 0 ∨ d0 < d))
    (hq : Always (birthCont P d0 d { s with banks := bs })
      (fun a => valSize (encState R.enc a) ≤ M)) :
    Implements prog M (Val.list [encBank R.enc B] :: encL (encBank R.enc) bs :: b1Val R d s ::
      env3 R P d0 d s) bd_rel (encState R.enc) (birthCont P d0 d { s with banks := bs }) := by
  obtain ⟨brel, hbrel, hrel⟩ := hC.w5.release
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hA := hR.invariant P hP
  have hH := H_le P
  have hp := valSize_encStreamParams_le P
  have hex := valSize_exVal_le P hd0
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have hBok : BankOK P (R.ok P) B := hbs B (List.mem_of_getElem? hB)
  have hBsz : valSize (encBank R.enc B) ≤ stateSizeBound P (R.bound P) := bank_size_le hR hP hBok
  have hbsz : valSize (encL (encBank R.enc) bs) ≤ stateSizeBound P (R.bound P) :=
    banks_size_le hR hP hbs hlen
  have hbsz' : valSize (Val.list (bs.map (encBank R.enc))) ≤ stateSizeBound P (R.bound P) := hbsz
  have hdsz : Nat.size d ≤ P.calL := (size_le_self d).trans (by omega)
  simp only [birthCont, if_neg hnot, hB] at hq ⊢
  unfold bd_rel
  refine impl_letE_run (implements_call_det hbrel
    (ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hexM rfl) (.cons (EvalsVal.head (EvalsVal.var rfl)
      (by omega)) (.cons (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega)) .nil)))
      (by rw [vs_triple]; simp only [valSize_int, bitLen_zero]; omega))
    (hrel P B Mode.primary hP hBok hM)) (fun bits res hrun => ?_)
  have hq' := always_of_bind_run hq hrun
  obtain ⟨hres2, hres1⟩ := Always.of_run (always_and (BankOK.release hA hBok Mode.primary)
    (release_qok hBok Mode.primary)) hrun
  have hB'sz : valSize (encBank R.enc res.2) ≤ stateSizeBound P (R.bound P) :=
    bank_size_le hR hP hres2
  have hoq := valSize_encOptQ_le (P := P) (fun N hN => (hres1 N hN).1)
  have hresM : valSize (Val.list [encOptQ res.1, encBank R.enc res.2]) ≤ M := by
    rw [vs_pair]; omega
  refine impl_letE_det (va := encL (encBank R.enc) (setAt res.2 d bs)) ?_ ?_
  · have e : encL (encBank R.enc) (setAt res.2 d bs) =
        Val.list ((bs.map (encBank R.enc)).set d (encBank R.enc res.2)) := by
      rw [setAt_eq_set]; simp only [encL, List.map_set]
    rw [e]
    exact evalsVal_call_det hT.set (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (ev_get 1 (EvalsVal.var rfl) hresM rfl) .nil)))
      (by rw [vs_triple, valSize_encN]; omega))
      ((set_spec hT.setStep hT.revAppendStep (bs.map (encBank R.enc)) d (encBank R.enc res.2)
        0).toVal.mono_M (by unfold S_set; omega))
  · obtain ⟨o, B'⟩ := res
    cases o with
    | none => exact implements_pure (bd_N_none hM hss hB'sz hq')
    | some N => exact bd_N_some hC hT hP hM hss hd0 hB'sz (hres1 N rfl) hq'

/-- The branch `¬ (d = 0 ∨ d₀ < d)`: `ob = b2[d]?` (library `getOpt`), then fail or release. -/
theorem bd_B_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State} {bs : List Bank}
    (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P)) (hd : d < P.H)
    (hd0 : d0 ≤ P.H) (hbs : ∀ B ∈ bs, BankOK P (R.ok P) B) (hlen : bs.length ≤ P.H)
    (hnot : ¬ (d = 0 ∨ d0 < d))
    (hq : Always (birthCont P d0 d { s with banks := bs })
      (fun a => valSize (encState R.enc a) ≤ M)) :
    Implements prog M (encL (encBank R.enc) bs :: b1Val R d s :: env3 R P d0 d s) bd_B
      (encState R.enc) (birthCont P d0 d { s with banks := bs }) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hH := H_le P
  have hbsz : valSize (encL (encBank R.enc) bs) ≤ stateSizeBound P (R.bound P) :=
    banks_size_le hR hP hbs hlen
  have hdsz : Nat.size d ≤ P.calL := (size_le_self d).trans (by omega)
  have hstM : valSize (encState R.enc s) ≤ M := by omega
  have hgo := getOpt_val_encL hT.getOptStep (encBank R.enc) bs d (M := M) (by omega)
  unfold bd_B
  refine impl_letE_det (evalsVal_call_det hT.getOpt (ev_list (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.var rfl) .nil)) (by rw [vs_pair, valSize_encN]; omega)) hgo) ?_
  cases hB : bs[d]? with
  | none =>
    simp only [birthCont, if_neg hnot, hB] at hq ⊢
    apply implements_pure
    exact ev_ite_true (EvalsVal.isNil_nil (EvalsVal.var rfl) (by omega)) one_ne_zero
      (leaf_fail_val 4 1 rfl rfl hstM hq)
  | some B =>
    exact implements_ite_eq (EvalsVal.isNil_cons (EvalsVal.var rfl) (by omega)) rfl
      (bd_rel_impl hR hC hT hP hM hss hd hd0 hbs hlen hB hnot hq)

/-- **The continuation after `b2`** implements `birthCont`. -/
theorem bd_cont_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State} {bs : List Bank}
    (hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P)) (hd : d < P.H)
    (hd0 : d0 ≤ P.H) (hbs : ∀ B ∈ bs, BankOK P (R.ok P) B) (hlen : bs.length ≤ P.H)
    (hq : Always (birthCont P d0 d { s with banks := bs })
      (fun a => valSize (encState R.enc a) ≤ M)) :
    Implements prog M (encL (encBank R.enc) bs :: b1Val R d s :: env3 R P d0 d s) bd_cont
      (encState R.enc) (birthCont P d0 d { s with banks := bs }) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hex := valSize_exVal_le P hd0
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have h0M : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  have hce : EvalsVal prog M (encL (encBank R.enc) bs :: b1Val R d s :: env3 R P d0 d s) []
      (.inl (Expr.bin BinOp.eq (Expr.var 4) (Expr.lit 0)))
      (Val.int (if (d : ℤ) = 0 then 1 else 0)) :=
    ev_eq (EvalsVal.var rfl) (EvalsVal.lit' h0M) h2M
  have hcl : EvalsVal prog M (encL (encBank R.enc) bs :: b1Val R d s :: env3 R P d0 d s) []
      (.inl (Expr.bin BinOp.lt (eGet 1 (Expr.var 2)) (Expr.var 4)))
      (Val.int (if (d0 : ℤ) < (d : ℤ) then 1 else 0)) :=
    ev_lt1 (ev_get 1 (EvalsVal.var rfl) hexM rfl) (EvalsVal.var rfl) h2M
  unfold bd_cont
  by_cases hA' : d = 0 ∨ d0 < d
  · unfold birthCont at hq ⊢
    rw [if_pos hA'] at hq ⊢
    have hleaf := leaf_learner_val (env := encL (encBank R.enc) bs :: b1Val R d s :: env3 R P d0 d s)
      hT 3 0 2 rfl rfl rfl (EvalsVal.lit' h0M) (by simp) hM hss hd0 hq
    apply implements_pure
    by_cases h0 : d = 0
    · exact ev_ite_true hce (ite_one_zero_ne (by exact_mod_cast h0)) hleaf
    · exact ev_ite_false hce (ite_one_zero_eq (by exact_mod_cast h0))
        (ev_ite_true hcl (ite_one_zero_ne (by exact_mod_cast hA'.resolve_left h0)) hleaf)
  · have h0 : ¬ d = 0 := fun h => hA' (Or.inl h)
    have hlt : ¬ d0 < d := fun h => hA' (Or.inr h)
    exact implements_ite_eq hce (ite_one_zero_eq (by exact_mod_cast h0))
      (implements_ite_eq hcl (ite_one_zero_eq (by exact_mod_cast hlt))
        (bd_B_impl hR hC hT hP hM hss hd hd0 hbs hlen hA' hq))

end Release

/-! ## One birth -/

section Birth

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

/-- **One birth in the DSL**: `body_birthDepth` implements C-ALG's `birthDepth P d₀ d s`. -/
theorem birthDepth_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State}
    (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) (hl : s.learners.length ≤ d)
    (hb : s.banks.length ≤ d + 1) (hd : d < P.H) (hd0 : d0 ≤ P.H) :
    Implements prog M [yVal R P d0 d s] body_birthDepth (encState R.enc) (birthDepth P d0 d s) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hA := hR.invariant P hP
  have hada := hR.enc_le P hP
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := hss.trans hSM
  have hex := valSize_exVal_le P hd0
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have hH := H_le P
  have hp := valSize_encStreamParams_le P
  have hdsz : valSize (encN d) ≤ P.calL + 1 := by
    rw [valSize_encN]; have := size_le_self d; omega
  have hYM : valSize (yVal R P d0 d s) ≤ M := by
    unfold yVal; rw [vs_triple]; omega
  have hbanks : valSize (encL (encBank R.enc) s.banks) ≤ stateSizeBound P (R.bound P) :=
    banks_size_le hR hP hs.banks_ok hs.banks_length_le
  have hpost : Always (birthDepth P d0 d s) (fun a => valSize (encState R.enc a) ≤ M) :=
    Always.mono (fun a h => (StateOK.valSize_encState_le hada h.1.1
        (by rw [h.2.1.1]; exact ht)).trans hSM)
      (always_and (birthDepth_ok hA (by norm_num) hs hl hb hd d0) (birthDepth_birth P d0 d s))
  have harg : EvalsVal prog M (env3 R P d0 d s) [] (.inl (eList [eGet 5 (Expr.var 1),
      eList [Expr.var 2, eGet 0 (Expr.var 0)]]))
      (Val.list [encL (encBank R.enc) s.banks, Val.list [encN d, encStreamParams P]]) := by
    obtain ⟨-, -, -, -, -, h5, -⟩ := ev_stfields (env := env3 R P d0 d s) (e := Expr.var 1)
      (EvalsVal.var rfl) hstM
    obtain ⟨h0, -, -, -, -, -⟩ := ev_exfields (env := env3 R P d0 d s) (e := Expr.var 0)
      (EvalsVal.var rfl) hexM
    exact ev_list (.cons h5 (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons h0 .nil))
      (by rw [vs_pair]; omega)) .nil)) (by rw [vs_pair, vs_pair]; omega)
  rw [birthDepth_eq] at hpost ⊢
  unfold body_birthDepth
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hYM rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hYM rfl) ?_
  refine impl_letE_det (ev_get 2 (EvalsVal.var rfl) hYM rfl) ?_
  refine impl_letE_det (va := b1Val R d s) (evalsVal_call_det hT.resetAt harg
    (resetAt_val hR hC hT hP hM hs.banks_ok hs.banks_length_le hd)) ?_
  refine impl_letE_run (bd_b2_impl hR hC hT hP hM hs hd hd0) (fun bits s2 hrun => ?_)
  obtain ⟨bs, rfl, hbs, hlen⟩ := Always.of_run (s2Prog_facts hA hs hb) hrun
  exact bd_cont_impl hR hC hT hP hM hss hd hd0 hbs hlen (always_of_bind_run hpost hrun)

/-- **The element routine of the birth loop**: skip if failed, else one birth. -/
theorem birthElem_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 d : ℕ} {s : State}
    (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) (hl : s.learners.length ≤ d)
    (hb : s.banks.length ≤ d + 1) (hd : d < P.H) (hd0 : d0 ≤ P.H) :
    Implements prog M [Val.list [encN d, encState R.enc s, exVal P d0]] body_birthElem
      (encState R.enc) (if s.failed then BitProg.pure s else birthDepth P d0 d s) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hada := hR.enc_le P hP
  have hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := by omega
  have hex := valSize_exVal_le P hd0
  have hH := H_le P
  have hdsz : valSize (encN d) ≤ P.calL + 1 := by
    rw [valSize_encN]; have := size_le_self d; omega
  have hYM : valSize (Val.list [encN d, encState R.enc s, exVal P d0]) ≤ M := by
    rw [vs_triple]; omega
  have hc : EvalsVal prog M [Val.list [encN d, encState R.enc s, exVal P d0]] []
      (.inl (eGet 1 (eGet 1 (Expr.var 0)))) (Val.int (if s.failed then 1 else 0)) :=
    (ev_stfields (e := eGet 1 (Expr.var 0)) (ev_get 1 (EvalsVal.var rfl) hYM rfl) hstM).2.1
  unfold body_birthElem
  cases hf : s.failed
  · rw [if_neg Bool.false_ne_true]
    refine implements_ite_eq hc (by simp [hf]) ?_
    exact implements_call_det hT.birthDepth (EvalsVal.var rfl)
      (birthDepth_impl hR hC hT hP hM hs ht hl hb hd hd0)
  · rw [if_pos rfl]
    refine implements_ite_ne hc (by simp [hf]) ?_
    exact implements_pure (ev_get 1 (EvalsVal.var rfl) hYM rfl)

end Birth

end F2e2e.C.Impl.T1
