import F2e2e.C.Impl.Tree4Reject

/-!
# W6, Tree4: the DSL implementation of `step4Depth`

(`rejectScale_impl`, `rejectDepth_impl`: `F2e2e/C/Impl/Tree4Reject.lean`.)

* `step4Validate_impl`: `body_step4Validate` implements `step4ValidateRef` (`θ_ℓ`,
  `ValidateInterval`, the branch on the certificate; L498–511);
* `step4Depth_impl`: `body_step4Depth` implements C-ALG's `step4Depth`.
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

theorem valSize_int_le_nat {z : ℤ} {n : ℕ} (h0 : 0 ≤ z) (h : z ≤ n) : valSize (Val.int z) ≤ n + 1 := by
  rw [valSize_int]
  have e : z = ((z.toNat : ℕ) : ℤ) := (Int.toNat_of_nonneg h0).symm
  rw [e, bitLen_natCast]
  have : z.toNat ≤ n := by omega
  have := size_le_self z.toNat
  have := Nat.size_le_size this
  omega

theorem ev_lit_small {prog : List Expr} {M : ℕ} {env : List Val} (z : ℤ) (h0 : 0 ≤ z)
    (hz : z ≤ 8) (hM : 9 ≤ M) : EvalsVal prog M env [] (.inl (Expr.lit z)) (Val.int z) :=
  EvalsVal.lit ((valSize_int_le_nat (n := 8) h0 hz).trans hM)

/-- The threshold `θ_ℓ = (8ℓ + 4) η` computed by `normQ [8 (H − d) + 4, 2^{eEta}]`. -/
theorem ev_theta {R : AdaRep} {prog : List Expr} {M : ℕ} {env : List Val}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} {d : ℕ} (hd : d < P.H)
    {a b c : Expr} (ha : EvalsVal prog M env [] (.inl a) (encN P.H))
    (hb : EvalsVal prog M env [] (.inl b) (encN d))
    (hc : EvalsVal prog M env [] (.inl c) (encN P.eEta)) (hM : 2 ^ 12 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M env [] (.inl (eNormQ (Expr.bin BinOp.add (Expr.bin BinOp.mul (Expr.lit 8)
      (Expr.bin BinOp.sub a b)) (Expr.lit 4)) (ePow2 c)))
      (encQ ((8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta)) := by
  have hH := H_le P
  have hE := eEta_le P
  have hL := hundred_le_calL P
  have h1 := hundred_mul_calL_le_sq P
  have h2 := hundred_mul_sq_le_cube P
  have hsub := ev_sub' (x := (P.H : ℤ)) (y := (d : ℤ)) ha hb
    (valSize_int_le_nat (n := P.H) (by omega) (by omega) |>.trans (by omega))
  have hmul := ev_mul (ev_lit_small 8 (by norm_num) (by norm_num) (by omega)) hsub
    (valSize_int_le_nat (n := 8 * P.H) (by omega) (by omega) |>.trans (by omega))
  have hadd := ev_add hmul (ev_lit_small 4 (by norm_num) (by norm_num) (by omega))
    (valSize_int_le_nat (n := 8 * P.H + 4) (by omega) (by omega) |>.trans (by omega))
  have hpow : S_pow2 P.eEta ≤ M := by
    unfold S_pow2; have := size_le_self P.eEta; omega
  have hbl : bitLen (8 * ((P.H : ℤ) - d) + 4) ≤ 8 * P.H + 4 := by
    have := valSize_int_le_nat (z := 8 * ((P.H : ℤ) - d) + 4) (n := 8 * P.H + 4) (by omega)
      (by omega)
    rw [valSize_int] at this; omega
  have h := ev_normQ hC hadd (ev_pow2 hT hc hpow) (by positivity)
    (by rw [bitLen_natCast, Nat.size_pow]; omega)
  rw [theta_eq P hd]
  exact h

/-! ## `step4Validate` -/

/-- **`step4Validate`** implements `step4ValidateRef`. -/
theorem step4Validate_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) {F : ℚ} (hF : FOK P F) {Bd : Bank} (hBd : BankOK P (R.ok P) Bd) {S : ℚ}
    (hS : inRangeA P S = true) (hSg : OnGrid P S) :
    Implements prog M [Val.list [encStreamParams P, encN d, encState R.enc s, encQ F,
      encBank R.enc Bd, encQ S]] body_step4Validate (encSF R) (step4ValidateRef P d s F Bd S) := by
  have hA := hR.invariant P hP
  have hS' : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hSc := SSB_c3 R P
  have hRB := regBits_le_SSB R P
  have hpz := vs_params R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hFz := vs_encQ R P hF.qok
  have hSF : FOK P S := fok_of_inRange hSg hS
  have hSz := vs_encQ R P hSF.qok
  have hsz := vs_state hR hP hs ht
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hBz := vs_bank hR hP hBd
  have hXz : valSize (Val.list [encStreamParams P, encN d, encState R.enc s, encQ F,
      encBank R.enc Bd, encQ S]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  obtain ⟨hθ0, hθ1, hθd⟩ := theta_facts P hd
  have hθq : QOK P ((8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta) := by
    rw [theta_eq P hd]
    have hpos : (0 : ℤ) < ((2 ^ P.eEta : ℕ) : ℤ) := by positivity
    have h1 := div_num_abs_le (8 * ((P.H : ℤ) - d) + 4) ((2 ^ P.eEta : ℕ) : ℤ) hpos
    have h2 := div_den_le (8 * ((P.H : ℤ) - d) + 4) ((2 ^ P.eEta : ℕ) : ℤ) hpos
    have h3 := eight_H_add_four_le P
    have h3' : ((8 * P.H + 4 : ℕ) : ℤ) ≤ ((2 ^ P.eEta : ℕ) : ℤ) := by exact_mod_cast h3
    have h4 : ((2 ^ P.eEta : ℕ) : ℤ) ≤ 2 ^ (4 * regBits P) := by
      push_cast; exact pow_le_pow_right₀ (by norm_num) (by have := eEta_le_R P; omega)
    refine ⟨h1.trans ?_, h2.trans h4⟩
    rw [abs_of_nonneg (by omega)]
    omega
  have hθz := vs_encQ R P hθq
  have hc3 : 2 ^ 12 * P.calL ^ 3 ≤ M := by omega
  unfold body_step4Validate step4ValidateRef
  simp only [bp_bind_eq, bp_pure_eq]
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_paramCall hC.w1.pH hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peEta hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_theta hC hT hd (EvalsVal.var rfl) (EvalsVal.var rfl) (EvalsVal.var rfl)
    hc3) ?_
  obtain ⟨hS0, hS1'⟩ := (inRangeA_iff P S).mp hS
  refine impl_letE_run (impl_validateCall hC hP hM hBd hS0 hS1' hSF.qok hθ0 hθ1 hθd
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hXz rfl)
      (.cons (ev_get 5 (EvalsVal.var rfl) hXz rfl) (.cons (EvalsVal.var rfl) .nil))))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)))
    (fun bits res hrun => ?_)
  rcases res with ⟨cert, B'⟩
  dsimp only
  have hB' : BankOK P (R.ok P) B' :=
    Always.of_run (BankOK.validate hA hBd S ((8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta)) hrun
  have hB'z := vs_bank hR hP hB'
  have hs1 : StateOK P (R.ok P) 4 { s with banks := setAt B' d s.banks } := hs.setBank hB' d
  have hs1z := vs_state hR hP hs1 ht
  have hs1M := hs1z.trans (show SSB R P ≤ M by omega)
  have hMI := mapIdx_M_banks_le hR hP hs.banks_ok hs.banks_length_le
    (Val.list [encN d, encBank R.enc B'])
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have hcz : valSize (encCert cert) ≤ 6 := by
    cases cert <;> exact valSize_int_le_nat (by norm_num) (by norm_num)
  have hresz : valSize (Val.list [encCert cert, encBank R.enc B']) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  refine impl_letE_det (ev_eWithBanks (ev_get 2 (EvalsVal.var rfl) hXz rfl)
    (ev_eSetAt hT (encBank R.enc) s.banks d B' (bankSizeBound P (R.bound P))
      (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hs.banks_ok B hB))
      (BankOK.valSize_encBank_le (hR.enc_le P hP) hB')
      (ev_get 5 (ev_get 2 (EvalsVal.var rfl) hXz rfl) hsM rfl) (EvalsVal.var rfl)
      (ev_get 1 (EvalsVal.var rfl) hresz rfl) (by omega))
    hsM hs1M) ?_
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hresz rfl) ?_
  have hfail : valSize (encState R.enc { s with banks := setAt B' d s.banks }) + 10 ≤ M := by
    omega
  cases cert with
  | accept =>
    refine impl_ite_true (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    exact Implements.of_det (ev_list (.cons (EvalsVal.var rfl)
      (.cons (ev_get 5 (EvalsVal.var rfl) hXz rfl) .nil))
      ((vs_pair hs1z hSz).trans (by omega)))
  | high =>
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_true (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 1) (by simp; omega))
      (by omega)) (by norm_num) ?_
    exact implements_call_det hT.rejectDepth (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.lit (z := 1) (by simp; omega))
      (.cons (EvalsVal.var rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hXz rfl) .nil)))))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one]; omega))
      (rejectDepth_impl hR hC hT hP hM hs1 ht hd true hF)
  | low =>
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 1) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_true (ev_eq (EvalsVal.var rfl) (ev_lit_small 2 (by norm_num) (by norm_num) (by omega))
      (by omega)) (by norm_num) ?_
    exact implements_call_det hT.rejectDepth (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.lit (z := 0) (by simp; omega))
      (.cons (EvalsVal.var rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hXz rfl) .nil)))))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]; omega))
      (rejectDepth_impl hR hC hT hP hM hs1 ht hd false hF)
  | termHigh =>
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 1) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (ev_lit_small 2 (by norm_num) (by norm_num) (by omega))
      (by omega)) (by norm_num) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)
  | termLow =>
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 1) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (ev_lit_small 2 (by norm_num) (by norm_num) (by omega))
      (by omega)) (by norm_num) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)
  | abort =>
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 0) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (EvalsVal.lit (z := 1) (by simp; omega))
      (by omega)) (by norm_num) ?_
    refine impl_ite_false (ev_eq (EvalsVal.var rfl) (ev_lit_small 2 (by norm_num) (by norm_num) (by omega))
      (by omega)) (by norm_num) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)

/-! ## `step4Depth` -/

/-- The candidate `S = P_d + Q̂` as computed by `normQ [cache · den + num · 2^q, 2^q · den]`. -/
theorem S_eq (q : ℕ) (c : ℤ) (F : ℚ) :
    (((c * (F.den : ℤ) + F.num * ((2 ^ q : ℕ) : ℤ) : ℤ)) : ℚ) /
      (((((2 ^ q : ℕ) : ℤ) * (F.den : ℤ) : ℤ)) : ℚ) = gridVal q c + F := by
  have hden : (F.den : ℚ) ≠ 0 := by positivity
  have hF : F = (F.num : ℚ) / (F.den : ℚ) := (Rat.num_div_den F).symm
  unfold gridVal
  push_cast
  conv_rhs => rw [hF]
  field_simp

theorem bitLen_mul_le4 (a b : ℤ) : bitLen (a * b) ≤ bitLen a + bitLen b := by
  unfold bitLen
  rw [Nat.size_le, Int.natAbs_mul, pow_add]
  exact Nat.mul_lt_mul'' (Nat.lt_size_self _) (Nat.lt_size_self _)

/-- The candidate `S = P_d + Q̂` computed by `normQ [cache · den + num · 2^{eHP}, 2^{eHP} · den]`. -/
theorem ev_S {R : AdaRep} {prog : List Expr} {M : ℕ} {env : List Val} (hC : Contracts R prog M)
    {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) {F : ℚ} (hF : QOK P F)
    {lo tp fq : Expr}
    (hc : EvalsVal prog M env [] (.inl (eGet 1 (Expr.un UnOp.head lo))) (Val.int L.cache))
    (htp : EvalsVal prog M env [] (.inl tp) (encN (2 ^ P.eHP)))
    (hnum : EvalsVal prog M env [] (.inl (eGet 0 fq)) (Val.int F.num))
    (hden : EvalsVal prog M env [] (.inl (eGet 1 fq)) (Val.int (F.den : ℤ)))
    (hM : 2 ^ 12 * P.calL ^ 3 + 100 ≤ M) :
    EvalsVal prog M env [] (.inl (eNormQ
      (Expr.bin BinOp.add (Expr.bin BinOp.mul (eGet 1 (Expr.un UnOp.head lo)) (eGet 1 fq))
        (Expr.bin BinOp.mul (eGet 0 fq) tp))
      (Expr.bin BinOp.mul tp (eGet 1 fq)))) (encQ (gridVal P.eHP L.cache + F)) := by
  have hR := regBits_eq P
  have hc3 := one_le_calL_cube P
  have hcb := SizeAux.bitLen_cache_le hL
  have hnb : bitLen F.num ≤ 4 * regBits P + 1 := SizeAux.bitLen_le_of_abs_le hF.1
  have hdb : bitLen (F.den : ℤ) ≤ 4 * regBits P + 1 := SizeAux.bitLen_le_of_abs_le
    (by rw [abs_of_nonneg (by positivity)]; exact hF.2)
  have htb : bitLen (((2 ^ P.eHP : ℕ)) : ℤ) = P.eHP + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have heA := eAmax_le_R P
  have heH := eHP_le_R P
  have hm1 := bitLen_mul_le4 L.cache (F.den : ℤ)
  have hm2 := bitLen_mul_le4 F.num ((2 ^ P.eHP : ℕ) : ℤ)
  have ha := bitLen_add_le (L.cache * (F.den : ℤ)) (F.num * ((2 ^ P.eHP : ℕ) : ℤ))
  have hb := bitLen_mul_le4 ((2 ^ P.eHP : ℕ) : ℤ) (F.den : ℤ)
  have hmax : max (bitLen (L.cache * (F.den : ℤ))) (bitLen (F.num * ((2 ^ P.eHP : ℕ) : ℤ))) ≤
      6 * regBits P + 4 := max_le (by omega) (by omega)
  have h := ev_normQ hC
    (ev_add (ev_mul hc hden (by rw [valSize_int]; omega))
      (ev_mul hnum htp (by rw [valSize_int]; omega)) (by rw [valSize_int]; omega))
    (ev_mul htp hden (by rw [valSize_int]; omega)) (by positivity) (by omega)
  rwa [S_eq] at h

/-- **`step4Depth`** implements C-ALG's `step4Depth`. -/
theorem step4Depth_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) {F : ℚ} (hF : FOK P F) :
    Implements prog M [Val.list [encStreamParams P, encN d, encState R.enc s, encQ F]]
      body_step4Depth (encSF R) (step4Depth P d s F) := by
  have hS' : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hSc := SSB_c3 R P
  have hRB := regBits_le_SSB R P
  have hpz := vs_params R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hFq := hF.qok
  have hFz := vs_encQ R P hFq
  have hsz := vs_state hR hP hs ht
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hbz := vs_banks_le R.enc s
  have hlz := vs_learners_le R.enc s
  have hXz : valSize (Val.list [encStreamParams P, encN d, encState R.enc s, encQ F]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hsd := size_le_self d
  rw [valSize_encN] at hdz
  unfold body_step4Depth
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 2 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 3 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_getOpt hT encLearner s.learners d
    (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hsM rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
    (by omega)) ?_
  refine impl_letE_det (ev_getOpt hT (encBank R.enc) s.banks d
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hsM rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
    (by omega)) ?_
  have hfail : valSize (encState R.enc s) + 10 ≤ M := by omega
  rcases hL : s.learners[d]? with _ | Ld
  · rw [step4Depth_none P d s F (Or.inl hL)]
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)
  have hLd : LearnerOK P 4 Ld := hs.learners_ok Ld (List.mem_of_getElem? hL)
  have hLz := vs_learner R P (hLd.mono (by norm_num) : LearnerOK P 16 Ld)
  rcases hB : s.banks[d]? with _ | Bd
  · rw [step4Depth_none P d s F (Or.inr hB)]
    refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)
  have hBd : BankOK P (R.ok P) Bd := hs.banks_ok Bd (List.mem_of_getElem? hB)
  have hBz := vs_bank hR hP hBd
  rw [step4Depth_some P d s F hL hB]
  refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
  refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peHP hP hM (EvalsVal.var rfl)) ?_
  have heHP := eHP_le_R P
  have hpow : S_pow2 P.eHP ≤ M := by unfold S_pow2; have := size_le_self P.eHP; omega
  refine impl_letE_det (ev_pow2 hT (EvalsVal.var rfl) hpow) ?_
  -- the candidate `S`
  have hSq : QOK P (gridVal P.eHP Ld.cache + F) := qok_S hLd hF
  have hSz := vs_encQ R P hSq
  have hLM : valSize (encLearner Ld) ≤ M := by omega
  have hoLM : valSize (Val.list [encLearner Ld]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hFM : valSize (encQ F) ≤ M := by omega
  have hc3' : 2 ^ 12 * P.calL ^ 3 + 100 ≤ M := by omega
  refine impl_letE_det (ev_S hC hLd hFq (ev_get 1 (ev_head' (EvalsVal.var rfl) hoLM) hLM rfl)
    (EvalsVal.var rfl) (ev_get 0 (EvalsVal.var rfl) hFM rfl) (ev_get 1 (EvalsVal.var rfl) hFM rfl)
    hc3') ?_
  refine impl_letE_det (ev_inRangeACall hC hP hM hSq
    (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
  refine impl_ite_encB (EvalsVal.var rfl) ?_
  cases hin : inRangeA P (gridVal P.eHP Ld.cache + F)
  · simp only [Bool.false_eq_true, if_false]
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) hfail)
  · simp only [if_true]
    exact implements_call_det hT.step4Validate
      (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) (.cons (ev_head' (EvalsVal.var rfl)
          (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
          (.cons (EvalsVal.var rfl) .nil))))))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
      (step4Validate_impl hR hC hT hP hM hs ht hd hF hBd hin (onGrid_S Ld.cache hF.2.2))

end F2e2e.C.Impl.T4
