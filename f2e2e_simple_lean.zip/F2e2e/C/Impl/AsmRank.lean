import F2e2e.C.Impl.AsmTable

/-!
# Theorem (C), assembly: the two programs and their rank certificate

Owner: C-SPACE (assembly end of W6).

* `initProg = mkProg body_init theTable`, `updProg = mkProg body_round theTable`: the programs of
  Theorem (C) (the Spec's `StreamAlgorithm.initProg` / `updProg`), sharing the routine table `theTable`
  (`F2e2e/C/Impl/AsmTable.lean`).
* The **rank certificate** of C-TOP's generic space theorem (`RankOK`, `F2e2e/Cost/Generic.lean`): the
  ranks `rAsm` are computed by the kernel from the call graph of `theTable` itself (a depth-first
  search with a memo of 8-bit slots coded as one natural number, "rank = `1 +` the largest rank of a
  callee"; the entry point `0` gets `65`, above every routine), and are checked by the kernel in one
  evaluation, entry by entry (`rankCheck_ok`, `rankOK_mkProg`), with the depth bound `asmK = 128` (the
  deepest body, W1's `body_w1All`, has depth `81`). The peak factor at the entry point is
  `(r₀ + 1)(K + 3) + 1 = 66 · 131 + 1 = 8647 ≤ 2^20` (`asmD_le`).
* The constants of 17fc0802's machine bridge: `progDepth ≤ 2^8` (largest height `80`) and
  `|prog| + 1 ≤ 2^10` (keys `≤ 899`).

All finite checks are `decide +kernel` (kernel reduction only; nothing added to the trusted base).
-/

namespace F2e2e.C.Impl.Asm

open F2e2e.Cost

/-- The initialization program of Theorem (C). -/
def initProg : List Expr := mkProg W6.body_init theTable

/-- The update program of Theorem (C). -/
def updProg : List Expr := mkProg W6.body_round theTable

/-- The routines called or looped by an expression. -/
def calleesOf : Expr → List ℕ
  | Expr.bin _ a b => calleesOf a ++ calleesOf b
  | Expr.un _ a => calleesOf a
  | Expr.ite c t f => calleesOf c ++ calleesOf t ++ calleesOf f
  | Expr.letE a b => calleesOf a ++ calleesOf b
  | Expr.call j a => j :: calleesOf a
  | Expr.loop j a => j :: calleesOf a
  | _ => []

/-- The body of the routine `j` in `theTable` (`Expr.nil` if there is none). -/
def bodyAt (j : ℕ) : Expr := (theTable.lookup j).getD Expr.nil

/-- Slot `j` (8 bits) of a vector of small numbers coded as one natural number. -/
def slot (code j : ℕ) : ℕ := (code >>> (8 * j)) % 256

/-- Depth-first computation of the ranks of the routine `j` and of every routine it calls, with fuel
`f` (a bound on the call depth). The memo `memo` holds `rank i + 1` in slot `i` for every finished
routine `i` (`0`: not yet computed); the rank of a routine is `1 +` the largest rank of its callees
(`0` without callees). -/
def dfs : ℕ → ℕ → ℕ → ℕ
  | 0, _, memo => memo
  | f + 1, j, memo =>
    if slot memo j = 0 then
      let res := (calleesOf (bodyAt j)).foldl
        (fun (acc : ℕ × ℕ) c => let m := dfs f c acc.1; (m, max acc.2 (slot m c))) (memo, 0)
      res.1 ||| ((res.2 + 1) <<< (8 * j))
    else memo

/-- The ranks of all routines of `theTable` (memo of `dfs` with fuel `64` from every key). -/
def rankCode : ℕ := theTable.foldl (fun m e => dfs 64 e.1 m) 0

/-- **The ranks of the routines**: the longest call chain from each routine of `theTable` (computed by
the kernel from the table itself, so it follows the areas' tables); the entry point `0` gets `65`, above
every routine (ranks computed with fuel `64` are `≤ 63`). Checked by `rankCheck_ok`. -/
def rAsm (j : ℕ) : ℕ := if j = 0 then 65 else slot rankCode j - 1

theorem rAsm_zero : rAsm 0 = 65 := rfl

/-- The depth bound of all bodies (the deepest body, W1's `body_w1All`, has depth `81`). -/
def asmK : ℕ := 128

/-- All conditions of the rank certificate in one Boolean (one kernel evaluation of the ranks): every
table entry and both entry bodies have depth `≤ asmK` and call only routines of smaller rank. -/
def rankCheckB : Bool :=
  tblRankB rAsm asmK theTable &&
    (decide (exprDepth W6.body_init ≤ asmK) && calleesLtB rAsm (rAsm 0) W6.body_init) &&
    (decide (exprDepth W6.body_round ≤ asmK) && calleesLtB rAsm (rAsm 0) W6.body_round)

theorem rankCheck_ok : rankCheckB = true := by
  decide +kernel

theorem rank_facts : (∀ e ∈ theTable, exprDepth e.2 ≤ asmK ∧ CalleesLt rAsm (rAsm e.1) e.2) ∧
    (exprDepth W6.body_init ≤ asmK ∧ CalleesLt rAsm (rAsm 0) W6.body_init) ∧
    (exprDepth W6.body_round ≤ asmK ∧ CalleesLt rAsm (rAsm 0) W6.body_round) := by
  have h := rankCheck_ok
  simp only [rankCheckB, Bool.and_eq_true, decide_eq_true_eq] at h
  exact ⟨tblRankB_sound h.1.1, ⟨h.1.2.1, (calleesLtB_iff _ _ _).mp h.1.2.2⟩,
    ⟨h.2.1, (calleesLtB_iff _ _ _).mp h.2.2⟩⟩

/-- **Rank certificate of the initialization program.** -/
theorem rankOK_init : RankOK initProg rAsm asmK :=
  rankOK_mkProg (by decide) rank_facts.2.1 rank_facts.1

/-- **Rank certificate of the update program.** -/
theorem rankOK_upd : RankOK updProg rAsm asmK :=
  rankOK_mkProg (by decide) rank_facts.2.2 rank_facts.1

/-- The peak factor of the generic space theorem at the entry point: `(r₀ + 1)(K + 3) + 1 ≤ 2^20`. -/
theorem asmD_le : (rAsm 0 + 1) * (asmK + 3) + 1 ≤ 2 ^ 20 := by
  rw [rAsm_zero]
  decide

/-! ## The constants of the machine bridge -/

theorem tblHeight_ok : theTable.all (fun e => decide (F2e2e.Machine.height e.2 ≤ 2 ^ 8)) = true := by
  decide +kernel

theorem height_tbl : ∀ e ∈ theTable, F2e2e.Machine.height e.2 ≤ 2 ^ 8 := fun e he => by
  simpa using List.all_eq_true.mp tblHeight_ok e he

theorem progDepth_initProg_le : F2e2e.Machine.progDepth initProg ≤ 2 ^ 8 :=
  progDepth_mkProg_le (by decide +kernel) height_tbl

theorem progDepth_updProg_le : F2e2e.Machine.progDepth updProg ≤ 2 ^ 8 :=
  progDepth_mkProg_le (by decide +kernel) height_tbl

theorem tblMax_le : tblMax theTable ≤ 899 := by
  decide +kernel

theorem length_initProg_le : initProg.length + 1 ≤ 2 ^ 10 := by
  have h := tblMax_le
  rw [initProg, length_mkProg]
  norm_num
  omega

theorem length_updProg_le : updProg.length + 1 ≤ 2 ^ 10 := by
  have h := tblMax_le
  rw [updProg, length_mkProg]
  norm_num
  omega

end F2e2e.C.Impl.Asm
