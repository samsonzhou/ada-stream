import F2e2e.C.Impl.W6Contracts
import F2e2e.B.ArchCoreSpec

/-!
# ADA module (W4): the representation `adaRep : AdaRep`

Owner: W4 (cc77ceaa). The representation of B-ARCH's ADA core (`F2e2e/B/ArchCore.lean`) chosen for the
DSL implementation of Theorem C (contract `W4Contract`, `F2e2e/C/Impl/W6Contracts.lean`):

* **state** `adaEnc st = [scores, T, thrInt, thrOut, rej, nInt, nNum, halted, capAborted]` (integers only).
  The weights are **not** encoded: on every reachable state they equal `scores.map (capWeightsQ c)`
  (`c = scoreScale A`, invariant field `AdaOK.weights`), and the DSL recomputes them exactly from the
  scores whenever a prediction is needed (time is free);
* **parameter record** `adaPubEnc A` (computed from `encStreamParams P` by `Idx.adaPub`): `p`, the block
  sizes, the caps `T_j^max`, `fuel`, `M`, `J`, `R`, `qA`, `2^qA`, `τ`, `a/2`, `c = κ h_A/4` (canonical
  rationals `encQ`), and for each of the five noise kinds the sampler parameters `[K_s, r_s, A, D, ⌈log₂ D⌉]`
  of `adaDraw` (`ϱ = A/D` in lowest terms);
* **invariant** `AdaOK A st` (shapes, weights consistency, caps, magnitude bounds of every stored integer);
* **size bound** `adaBoundA A = 2^10 (N + p + 16)(adaZ A + 16)`, with `adaZ A` a bound on the bit length of
  every integer handled by the module (state, parameters and intermediate values).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top

/-! ## Parameters -/

/-- The five noise kinds in a fixed order. -/
def noiseKinds : List NoiseKind :=
  [NoiseKind.intThr, NoiseKind.intTest, NoiseKind.outThr, NoiseKind.outTest, NoiseKind.num]

/-- The sampler parameters `[K_s, r_s, A, D, ⌈log₂ D⌉]` of a draw of kind `κ` (`adaDraw A κ =
latticeSampler A D r_s K_s`). -/
def samplerParams (A : AdaParams) (κ : NoiseKind) : List ℕ :=
  [A.Ks (A.scale κ), A.rs (A.scale κ), (A.rho (A.scale κ)).num.toNat, (A.rho (A.scale κ)).den,
    Nat.clog 2 (A.rho (A.scale κ)).den]

/-- The largest count cap `K_s` over the five kinds (bound of every lattice noise index). -/
def maxKs (A : AdaParams) : ℕ := (noiseKinds.map fun κ => A.Ks (A.scale κ)).foldr max 0

/-- **The parameter record** read by W4's routines. -/
def adaPubEnc (A : AdaParams) : Val :=
  Val.list [encN A.p, encL encN A.blockSizes, encL encN A.Tmax, encN A.fuel, encN A.M, encN A.J,
    encN A.R, encN A.qA, encN (2 ^ A.qA), encQ A.tau, encQ (A.a / 2), encQ (scoreScale A),
    Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))]

/-! ## State encoding -/

/-- **The state encoding** (weights omitted, see the module docstring). -/
def adaEnc (st : AdaState) : Val :=
  Val.list [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt, encZ st.thrOut,
    encN st.rej, encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted]

/-! ## Invariant -/

/-- **The ADA invariant** for the parameters `A`. -/
structure AdaOK (A : AdaParams) (st : AdaState) : Prop where
  scores_len : st.scores.length = A.p
  scores_blk : ∀ j < A.p, (st.scores.getD j []).length = A.blockSizes.getD j 0
  weights : st.weights = st.scores.map (capWeightsQ (scoreScale A))
  T_len : st.T.length = A.p
  T_le : ∀ j < A.p, st.T.getD j 0 ≤ A.Tmax.getD j 0
  thr_len : st.thrInt.length = A.p
  thr_le : ∀ z ∈ st.thrInt, |z| ≤ (maxKs A : ℤ)
  thrOut_le : |st.thrOut| ≤ (maxKs A : ℤ)
  scores_le : ∀ g ∈ st.scores, ∀ z ∈ g, |z| ≤ 4 * 2 ^ A.qA * (st.T.sum : ℤ)
  rej_le : st.rej ≤ A.J + 1
  rej_halt : st.halted = false → st.rej ≤ A.J
  nInt_le : st.nInt ≤ A.M
  nNum_le : st.nNum ≤ A.R

/-! ## Size bounds -/

/-- Bit-length scale of the module: every integer handled (state, parameters, intermediate values) has
at most a small multiple of `adaZ A` bits. Every summand is `O(ℒ)`: the exponents `q_A`, `p`, `B_0`,
the trial caps `r_s` and `⌈log₂ D_ϱ⌉` linearly, every other parameter through its bit length. -/
def adaZ (A : AdaParams) : ℕ :=
  A.qA + A.p + A.B0 + Nat.size A.fuel + Nat.size (maxKs A) + Nat.size (A.M + A.J + A.R + 2) +
    Nat.size A.N + Nat.size (scoreScale A).den + Nat.size (scoreScale A).num.natAbs +
    Nat.size A.tau.den + Nat.size A.tau.num.natAbs + Nat.size (A.a / 2).den +
    Nat.size (A.a / 2).num.natAbs + Nat.size A.zeta.den + Nat.size A.zeta.num.natAbs +
    (noiseKinds.map fun κ => Nat.size (A.scale κ).den + Nat.size (A.scale κ).num.natAbs +
      Nat.size (A.Ks (A.scale κ)) + A.rs (A.scale κ) + Nat.size (A.rho (A.scale κ)).num.toNat +
      Nat.size (A.rho (A.scale κ)).den + Nat.clog 2 (A.rho (A.scale κ)).den).sum + 16

/-- **The size bound** of an encoded state (and of every value produced by the module). -/
def adaBoundA (A : AdaParams) : ℕ := 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16)

/-- **W4's representation of the ADA module.** -/
def adaRep : AdaRep where
  enc := adaEnc
  pub := adaPubEnc
  ok := fun P st => AdaOK (bankAda P) st
  bound := fun P => adaBoundA (bankAda P)

/-! ## The value bound `Mv` -/

/-- The bound of an encoded ADA state and `2^5 ℒ³` are below C-SPACE's state size bound. -/
theorem le_stateSizeBound (P : StreamParams) (b : ℕ) :
    b ≤ stateSizeBound P b ∧ 2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P b := by
  have hH : 1 ≤ P.H := by unfold StreamParams.H; omega
  constructor
  · calc b ≤ bankSizeBound P b + 1 := by unfold bankSizeBound; omega
      _ ≤ P.H * (bankSizeBound P b + 1) := Nat.le_mul_of_pos_left _ hH
      _ ≤ stateSizeBound P b := by unfold stateSizeBound; omega
  · unfold stateSizeBound; omega

/-- **What `Mv adaRep P ≤ M` gives W4's routines**: integers of `≤ 2^31 adaBoundA` bits and of
`≤ 2^36 ℒ³` bits (e.g. the canonical endpoints `l, u` with `QOK`) are below `M`. -/
theorem Mv_adaRep_ge {P : StreamParams} {M : ℕ} (h : Mv adaRep P ≤ M) :
    2 ^ 32 * adaBoundA (bankAda P) ≤ M ∧ 2 ^ 37 * P.calL ^ 3 ≤ M := by
  obtain ⟨h1, h2⟩ := le_stateSizeBound P (adaRep.bound P)
  unfold Mv at h
  constructor
  · exact le_trans (Nat.mul_le_mul_left _ h1) h
  · calc 2 ^ 37 * P.calL ^ 3 = 2 ^ 32 * (2 ^ 5 * P.calL ^ 3) := by ring
      _ ≤ 2 ^ 32 * stateSizeBound P (adaRep.bound P) := Nat.mul_le_mul_left _ h2
      _ ≤ M := h

/-! The validity `adaRep_valid : adaRep.Valid` (C-SPACE's `AdaInvariant` and the size bounds) is in
`F2e2e/C/Impl/AdaValid.lean` (it needs the size bounds of `AdaBounds.lean` and `adaInit_ok` of
`AdaInit.lean`, which import this file). -/

end F2e2e.C.Impl
