import F2e2e.C.Impl.BankValidateCore
import F2e2e.C.Impl.BankRelease

/-!
# W5: `ReleaseNumerical` (757) in the DSL

Owner: B-ACC (6f8aab0c), for W5 (c1b4f720). `ValidateInterval` (756) is in
`F2e2e/C/Impl/BankValidateCore.lean`; the release-side routines (784–788, 790, 791, 793) and the
integer references `subSumZ`, `coarseD`, `lowerMedianZ`, `coarseScaleND` are in A-VAL's
`F2e2e/C/Impl/BankRelease.lean`.

`release_spec`: `body_release` implements C-ALG's `Bank.release P B mode` (`F2e2e/C/Alg/Bank.lean`,
partIII.tex L215–219) on `[encStreamParams P, encBank B, encMode mode]`:
* no reserved coarse group left: `(none, B)`;
* otherwise, for the first group `grp`: the scale `c = max(lowerMedian of the subgroup means, ω/2)`
  is the fraction `coarseScaleND P mode grp` (`coarse_c_eq`: the subgroup means are
  `subSumZ / coarseD` (`subgroupMean_eq`), the DSL's insertion sort is `List.insertionSort`
  (`isortRef_eq_insertionSort`), and the lower median commutes with the increasing scaling
  (`lowerMedian_map_div`)); then W4's `adaNumerical` on the query table `adaVals P mode c B`, and
  `N = max(0, L c μ − ω)` (A-VAL's `bkReleaseN`).
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## The coarse scale as a fraction -/

theorem coarseD_pos (P : StreamParams) : 0 < coarseD P := by
  unfold coarseD
  positivity

/-- `∑ f = (∑ g) / K` when `f = g / K` pointwise (over variables only, so that the kernel never
has to evaluate the parameter-dependent constant `K`). -/
theorem list_sum_map_div_cast {α : Type} (l : List α) (f : α → ℚ) (g : α → ℤ) (K : ℚ)
    (h : ∀ a, f a = (g a : ℚ) / K) : (l.map f).sum = ((l.map g).sum : ℚ) / K := by
  induction l with
  | nil => simp
  | cons a t ih =>
    simp only [List.map_cons, List.sum_cons]
    rw [ih, h a, Int.cast_add, add_div]

theorem sq_div_two_pow (z : ℤ) (e : ℕ) :
    ((z : ℚ) / 2 ^ e) ^ 2 = ((z ^ 2 : ℤ) : ℚ) / (2 : ℚ) ^ (2 * e) := by
  rw [div_pow, ← pow_mul, mul_comm e 2, Int.cast_pow]

theorem cast_thirtytwo_mul_two_pow (e : ℕ) : ((32 * 2 ^ e : ℤ) : ℚ) = (2 : ℚ) ^ e * 32 := by
  push_cast
  ring

theorem subgroupMean_eq (P : StreamParams) (mode : Mode) (sub : List Row) :
    subgroupMean P mode sub = (subSumZ P mode sub : ℚ) / (coarseD P : ℚ) := by
  have hpt : ∀ r : Row, regZ P mode r ^ 2 =
      ((zNOf P mode r ^ 2 : ℤ) : ℚ) / (2 : ℚ) ^ (2 * (P.eHb + P.eSigma)) := by
    intro r
    rw [regZ_eq]
    exact sq_div_two_pow (zNOf P mode r) (P.eHb + P.eSigma)
  unfold subgroupMean subSumZ coarseD
  rw [list_sum_map_div_cast sub (fun r => regZ P mode r ^ 2) (fun r => zNOf P mode r ^ 2) _ hpt,
    div_div, cast_thirtytwo_mul_two_pow]

/-- The DSL's insertion sort is the list's insertion sort. -/
theorem isortRef_eq_insertionSort (l : List ℤ) : isortRef l = l.insertionSort (· ≤ ·) := by
  have hp : (isortRef l).Perm (l.insertionSort (· ≤ ·)) :=
    (Arith.isortAux_perm l []).trans (List.perm_insertionSort _ l).symm
  exact hp.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba)
    (Arith.isortAux_sorted l [] List.Pairwise.nil) (List.pairwise_insertionSort _ l)

/-- Insertion sort commutes with a monotone map. -/
theorem insertionSort_map_mono {α β : Type*} [LinearOrder α] [LinearOrder β] (f : α → β)
    (hf : Monotone f) (l : List α) :
    (l.map f).insertionSort (· ≤ ·) = (l.insertionSort (· ≤ ·)).map f := by
  have h1 := List.pairwise_insertionSort (· ≤ ·) (l.map f)
  have h2 : ((l.insertionSort (· ≤ ·)).map f).Pairwise (· ≤ ·) :=
    List.Pairwise.map f (fun a b h => hf h) (List.pairwise_insertionSort (· ≤ ·) l)
  have hperm : ((l.map f).insertionSort (· ≤ ·)).Perm ((l.insertionSort (· ≤ ·)).map f) :=
    (List.perm_insertionSort _ _).trans ((List.perm_insertionSort _ l).map f).symm
  exact hperm.eq_of_pairwise (fun a b _ _ hab hba => le_antisymm hab hba) h1 h2

theorem lowerMedian_map_div (l : List ℤ) (D : ℚ) (hD : 0 < D) :
    lowerMedian (l.map (fun z : ℤ => (z : ℚ) / D)) = (lowerMedianZ l : ℚ) / D := by
  unfold lowerMedian lowerMedianZ
  have hmono : Monotone (fun z : ℤ => (z : ℚ) / D) := fun a b h =>
    div_le_div_of_nonneg_right (by exact_mod_cast h) hD.le
  rw [insertionSort_map_mono _ hmono, isortRef_eq_insertionSort, List.length_map]
  have h0 : (0 : ℚ) = ((0 : ℤ) : ℚ) / D := by simp
  conv_lhs => rw [h0]
  exact List.getD_map _ _ _

/-- `c = max(lowerMedian of the subgroup means, ω/2) = cN / cD` (`coarseScaleND`). -/
theorem coarse_c_eq (P : StreamParams) (mode : Mode) (grp : List (List Row)) :
    max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2) =
      ((coarseScaleND P mode grp).1 : ℚ) / ((coarseScaleND P mode grp).2 : ℚ) := by
  have hD := coarseD_pos P
  have hDq : (0 : ℚ) < (coarseD P : ℚ) := by exact_mod_cast hD
  have hmap : grp.map (subgroupMean P mode) =
      (grp.map (subSumZ P mode)).map (fun z : ℤ => (z : ℚ) / (coarseD P : ℚ)) := by
    rw [List.map_map]
    exact List.map_congr_left (fun sub _ => subgroupMean_eq P mode sub)
  rw [hmap, lowerMedian_map_div _ _ hDq]
  have hω : P.omega / 2 = 1 / (2 : ℚ) ^ (P.eOmega + 1) := by
    rw [omega_eq, pow_succ, div_div]
  rw [hω]
  unfold coarseScaleND
  have hO : (0 : ℚ) < (2 : ℚ) ^ (P.eOmega + 1) := by positivity
  split_ifs with h
  · have h' : ((lowerMedianZ (grp.map (subSumZ P mode)) : ℚ)) * (2 : ℚ) ^ (P.eOmega + 1) <
        (coarseD P : ℚ) := by exact_mod_cast h
    have hlt : (lowerMedianZ (grp.map (subSumZ P mode)) : ℚ) / (coarseD P : ℚ) <
        1 / (2 : ℚ) ^ (P.eOmega + 1) := by
      rw [div_lt_div_iff₀ hDq hO]
      linarith
    rw [max_eq_right hlt.le]
    show (1 : ℚ) / 2 ^ (P.eOmega + 1) = ((1 : ℤ) : ℚ) / (((2 : ℤ) ^ (P.eOmega + 1) : ℤ) : ℚ)
    rw [Int.cast_one, Int.cast_pow, Int.cast_ofNat]
  · have h' : (coarseD P : ℚ) ≤
        ((lowerMedianZ (grp.map (subSumZ P mode)) : ℚ)) * (2 : ℚ) ^ (P.eOmega + 1) := by
      exact_mod_cast (not_lt.mp h)
    have hle : 1 / (2 : ℚ) ^ (P.eOmega + 1) ≤
        (lowerMedianZ (grp.map (subSumZ P mode)) : ℚ) / (coarseD P : ℚ) := by
      rw [div_le_div_iff₀ hO hDq]
      linarith
    rw [max_eq_left hle]

/-! ## Rules -/

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-- `ite` whose condition evaluates to `0` (deterministically), before a randomized else-branch. -/
theorem impl_ite_f {α : Type} {c t f : Expr} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int 0)) (hf : Implements prog M env f enc p) :
    Implements prog M env (eIte c t f) enc p := by
  intro bits a h
  have hv : EvalsVal prog M env bits (.inl (if (0 : ℤ) ≠ 0 then t else f)) (enc a) := by
    rw [if_neg (by simp)]
    exact hf bits a h
  have h2 := EvalsVal.ite hc hv
  rw [List.nil_append] at h2
  exact h2

theorem encBank_eq' (enc : AdaState → Val) (B : Bank) :
    encBank enc B = Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) B.coarse,
      enc B.adaSt] := rfl

theorem valSize_encBank_parts' (enc : AdaState → Val) (B : Bank) :
    valSize (encL (encL encRow) B.ada) + valSize (encL (encL (encL encRow)) B.coarse) +
      valSize (enc B.adaSt) ≤ valSize (encBank enc B) := by
  rw [encBank_eq']
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem ev_bank_coarse' {enc : AdaState → Val} {B : Bank} {e : Expr}
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt1 e)) (encL (encL (encL encRow)) B.coarse) := by
  rw [encBank_eq'] at h hs
  exact ev_at1 h hs

theorem ev_bank_coarse_nil {enc : AdaState → Val} {B : Bank} {e : Expr} (hc : B.coarse = [])
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt1 e)) (Val.list []) := by
  have h1 := ev_bank_coarse' h hs
  rw [hc] at h1
  exact h1

theorem ev_bank_coarse_cons {enc : AdaState → Val} {B : Bank} {e : Expr} {grp : List (List Row)}
    {rest : List (List (List Row))} (hc : B.coarse = grp :: rest)
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt1 e))
      (Val.list (encL (encL encRow) grp :: rest.map (encL (encL encRow)))) := by
  have h1 := ev_bank_coarse' h hs
  rw [hc] at h1
  exact h1

theorem valSize_coarse_cons {B : Bank} {grp : List (List Row)} {rest : List (List (List Row))}
    (hc : B.coarse = grp :: rest) :
    valSize (Val.list (encL (encL encRow) grp :: rest.map (encL (encL encRow)))) =
      valSize (encL (encL (encL encRow)) B.coarse) := by
  rw [hc]
  rfl

theorem ev_bank_grp {enc : AdaState → Val} {B : Bank} {e : Expr} {grp : List (List Row)}
    {rest : List (List (List Row))} (hc : B.coarse = grp :: rest)
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eHd (eAt1 e))) (encL (encL encRow) grp) := by
  have hp := valSize_encBank_parts' enc B
  have hv := valSize_coarse_cons hc
  exact ev_hd (ev_bank_coarse_cons hc h hs) (by omega)

theorem ev_bank_rest {enc : AdaState → Val} {B : Bank} {e : Expr} {grp : List (List Row)}
    {rest : List (List (List Row))} (hc : B.coarse = grp :: rest)
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eTl (eAt1 e))) (encL (encL (encL encRow)) rest) := by
  have hp := valSize_encBank_parts' enc B
  have hv := valSize_coarse_cons hc
  exact ev_tl (ev_bank_coarse_cons hc h hs) (by omega)

end rules

/-! ## `ReleaseNumerical` (757) -/

section release

variable {prog : List Expr} {M : ℕ}

set_option maxHeartbeats 1000000 in
/-- **757 (`W5Contract.release`).** -/
theorem release_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (hw2 : HornerLib prog) (hw4 : W4Contract R prog M) (P : StreamParams) (B : Bank) (mode : Mode)
    (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hM : Mv R P ≤ M) :
    Implements prog M [Val.list [encStreamParams P, encBank R.enc B, encMode mode]] body_release
      (fun r => Val.list [encOptQ r.1, encBank R.enc r.2]) (B.release P mode) := by
  -- size facts
  have hs1 := bank_size_le R hR hP hB
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hm := valSize_encMode_le mode
  have hc100 := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hRb := bound_le_bankSizeBound P (R.bound P)
  have hparts := valSize_encBank_parts' R.enc B
  have hI : valSize (Val.list [encStreamParams P, encBank R.enc B, encMode mode]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hs1' : valSize (encBank R.enc B) ≤ M := by omega
  unfold body_release
  refine impl_let_det (ev_at1 (ev_var rfl) hI) ?_
  rcases hc : B.coarse with _ | ⟨grp, rest⟩
  · -- no reserved coarse group left: `(none, B)`
    unfold Bank.release
    rw [hc]
    dsimp only
    rw [bitProg_pure_eq]
    refine Implements.of_det ?_
    show EvalsVal prog M _ [] _ (Val.list [Val.list [], encBank R.enc B])
    exact ev_ite_t (ev_isNil_nil (ev_bank_coarse_nil hc (ev_var rfl) hs1') (by omega)) one_ne_zero
      (ev_pair (ev_nil (by omega)) (ev_var rfl)
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
  · -- the first reserved coarse group `grp`
    have hg : grp ∈ B.coarse := by rw [hc]; exact List.mem_cons_self
    obtain ⟨hcN, hcD, hbN, hbD⟩ := coarseScaleND_bounds mode (hB.coarse_shape grp hg)
      (hB.coarse_rows grp hg)
    unfold Bank.release
    rw [hc]
    dsimp only
    rw [coarse_c_eq, bitProg_bind_eq]
    -- sizes
    have hz := valSize_zxVal_le P mode
    have hgs : valSize (encL (encL encRow) grp) < valSize (encL (encL (encL encRow)) B.coarse) :=
      valSize_lt_encL (encL (encL encRow)) hg
    have hq := valSize_qxVal_le R hR hP mode hbN hbD
    have hcs : valSize (Val.list [Val.int (coarseScaleND P mode grp).1,
        Val.int (coarseScaleND P mode grp).2]) ≤ M := by
      simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
      omega
    obtain ⟨bodyN, hbodyN, hspecN⟩ := hw4.adaNumerical
    obtain ⟨bodyP, hbodyP, hspecP⟩ := hw4.adaPub
    have hvOK := valsOK_adaVals hB mode
      (((coarseScaleND P mode grp).1 : ℚ) / ((coarseScaleND P mode grp).2 : ℚ))
    have hvs := hR.vals_le P hP _ hvOK
    have hpub := hR.pub_le P hP
    have henc := hR.enc_le P hP B.adaSt hB.ada_ok
    -- `isNil coarse = 0`
    refine impl_ite_f (ev_isNil_cons (ev_bank_coarse_cons hc (ev_var rfl) hs1') (by omega)) ?_
    -- `P`
    refine impl_let_det (ev_hd (ev_var rfl) hI) ?_
    -- `zx`
    refine impl_let_det (ev_call hlib.bkZExtra (ev_pair (ev_var rfl) (ev_at2 (ev_var rfl) hI)
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (bkZExtra_val R hlib hw1 P hP hM mode)) ?_
    -- `c = [cN, cD]`
    refine impl_let_det (ev_call hlib.bkCoarseScale (ev_list (.cons (ev_var rfl) (.cons (ev_var rfl)
      (.cons (ev_bank_grp hc (ev_var rfl) hs1') .nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (bkCoarseScale_val R hR hlib hw1 hw2 P hP hM mode B hB grp hg)) ?_
    -- `vals`
    refine impl_let_det (ev_call hlib.bkValsQ (ev_pair (ev_bank_ada (ev_var rfl) hs1')
      (ev_call hlib.bkQExtra (ev_list (.cons (ev_var rfl) (.cons (ev_var rfl)
        (.cons (ev_hd (ev_var rfl) hcs) (.cons (ev_at1 (ev_var rfl) hcs) .nil))))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (bkQExtra_val R hR hlib hw1 hw4 P hP hM mode _ _ hbN hbD))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (bkValsQ_val R hR hlib hw2 P hP hM mode B hB _ _ hcN hcD hbN hbD)) ?_
    -- `res = adaNumerical …`
    refine impl_letE_of_run (implements_call_det hbodyN ?_
      (hspecN P B.adaSt _ hP hB.ada_ok hvOK hM)) ?_
    · exact ev_list (.cons (ev_call hbodyP (ev_var rfl) (hspecP P hP hM))
        (.cons (ev_bank_st (ev_var rfl) hs1') (.cons (ev_var rfl) .nil)))
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    intro bits r hrun
    obtain ⟨r1, st'⟩ := r
    have hok : R.ok P st' :=
      Always.of_run ((hR.invariant P hP).numerical B.adaSt _ hB.ada_ok) hrun
    have hnum : valSize (encNum r1) ≤ R.bound P :=
      Always.of_run (hR.num_le P hP B.adaSt _ hB.ada_ok hvOK) hrun
    have hencr := hR.enc_le P hP st' hok
    have hres : valSize (Val.list [encNum r1, R.enc st']) ≤ M := by
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    have hB'ok : BankOK P (R.ok P) { B with coarse := rest, adaSt := st' } := by
      refine ⟨hB.ada_sizes, ?_, ?_, hB.ada_rows, ?_, hok⟩
      · have h1 := hB.coarse_length_le
        rw [hc] at h1
        simp only [List.length_cons] at h1
        show rest.length ≤ P.Rmax
        omega
      · intro g hg'
        exact hB.coarse_shape g (by rw [hc]; exact List.mem_cons.mpr (Or.inr hg'))
      · intro g hg'
        exact hB.coarse_rows g (by rw [hc]; exact List.mem_cons.mpr (Or.inr hg'))
    have hs3 := bank_size_le R hR hP hB'ok
    have hs3' : valSize (Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) rest,
        R.enc st']) ≤ bankSizeBound P (R.bound P) := hs3
    have hB'v : valSize (Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) rest,
        R.enc st']) ≤ M := by omega
    -- `B' = [ada, rest, st']`
    refine impl_let_det (ev_list (.cons (ev_bank_ada (ev_var rfl) hs1')
      (.cons (ev_bank_rest hc (ev_var rfl) hs1') (.cons (ev_at1 (ev_var rfl) hres) .nil))) hB'v) ?_
    -- the output
    cases r1 with
    | val μ =>
      have hμ : valSize (encQ μ) ≤ R.bound P := by
        simp only [encNum, valSize_list, listSize_cons, listSize_nil] at hnum
        omega
      have hN := valSize_releaseN_le R P _ _ hcN hcD hbN hbD μ hμ
      have hresμ : valSize (Val.list [Val.list [encQ μ], R.enc st']) ≤ M := hres
      have hμ1 : valSize (Val.list [encQ μ]) ≤ M := by
        simp only [valSize_list, listSize_cons, listSize_nil] at hresμ ⊢
        omega
      have hrin : valSize (Val.list [encStreamParams P, Val.list [Val.int (coarseScaleND P mode grp).1,
          Val.int (coarseScaleND P mode grp).2], encQ μ]) ≤ M := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
        omega
      have hN1 : valSize (Val.list [encQ (max 0 ((P.L : ℚ) *
          (((coarseScaleND P mode grp).1 : ℚ) / ((coarseScaleND P mode grp).2 : ℚ)) * μ -
            P.omega))]) ≤ M := by
        simp only [valSize_list, listSize_cons, listSize_nil]
        omega
      have hout : valSize (Val.list [Val.list [encQ (max 0 ((P.L : ℚ) *
          (((coarseScaleND P mode grp).1 : ℚ) / ((coarseScaleND P mode grp).2 : ℚ)) * μ -
            P.omega))], Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) rest,
          R.enc st']]) ≤ M := by
        simp only [valSize_list, listSize_cons, listSize_nil] at hs3' ⊢
        omega
      dsimp only
      rw [bitProg_pure_eq]
      refine Implements.of_det ?_
      show EvalsVal prog M _ [] _ (Val.list [Val.list [encQ (max 0 ((P.L : ℚ) *
        (((coarseScaleND P mode grp).1 : ℚ) / ((coarseScaleND P mode grp).2 : ℚ)) * μ - P.omega))],
        Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) rest, R.enc st']])
      refine ev_ite_f (ev_isNil_cons (ev_hd (ev_var rfl) hresμ) (by omega)) rfl ?_
      exact ev_pair (ev_list (.cons (ev_call hlib.bkReleaseN (ev_list (.cons (ev_var rfl)
          (.cons (ev_var rfl) (.cons (ev_hd (ev_hd (ev_var rfl) hresμ) hμ1) .nil))) hrin)
          (bkReleaseN_val R hR hlib hw1 P hP hM _ _ hcN hcD hbN hbD μ hμ)) .nil) hN1)
        (ev_var rfl) hout
    | abort =>
      have hresA : valSize (Val.list [Val.list [], R.enc st']) ≤ M := hres
      have hout : valSize (Val.list [Val.list [], Val.list [encL (encL encRow) B.ada,
          encL (encL (encL encRow)) rest, R.enc st']]) ≤ M := by
        simp only [valSize_list, listSize_cons, listSize_nil] at hs3' ⊢
        omega
      dsimp only
      rw [bitProg_pure_eq]
      refine Implements.of_det ?_
      show EvalsVal prog M _ [] _ (Val.list [Val.list [],
        Val.list [encL (encL encRow) B.ada, encL (encL (encL encRow)) rest, R.enc st']])
      exact ev_ite_t (ev_isNil_nil (ev_hd (ev_var rfl) hresA) (by omega)) one_ne_zero
        (ev_pair (ev_nil (by omega)) (ev_var rfl) hout)

end release

end F2e2e.C.Impl.BankDSL
