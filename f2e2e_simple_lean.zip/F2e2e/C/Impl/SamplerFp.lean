import F2e2e.C.Impl.SamplerRep
import F2e2e.Cost.Lib.Coins
import F2e2e.Cost.Arith.Basic
import F2e2e.Lib.Discrete.Sampler

/-!
# W3: the capped rejection sampler of the fingerprint seed (DSL)

Owner: W3 (4a7299ed). Reference: C-ALG's `F2e2e.C.Alg.fpSeedProg` (`F2e2e/C/Alg/Fingerprint.lean`,
Algorithm `R:alg:zero-fingerprint`, `parts/partII.tex` L219: the secret seed `r_fp ∈ 𝔽_q` by capped
uniform-integer rejection sampling with `⌈log₂(1000/β₀)⌉` trials and fallback seed zero):

`fpSeedProg P = (rejectUniform P.q (Nat.clog 2 P.q) P.seedTrials).map (·.getD 0)`.

This file contains the parameter-independent part: the loop body `body_fpSeedStep` (Idx 552) on the
accumulator `[r, D, k]` and its spec `fpSeed_loop`: from `[r, D, k]` the loop consumes exactly the bits
of an exact run of `rejectUniform D k r` (`F2e2e/Lib/Discrete/Sampler.lean`) and returns
`encN (o.getD 0)`. Each trial reads `k` fresh bits with the library routine `readNat`
(`F2e2e/Cost/Lib/Coins.lean`, big-endian like `uniformBits`). The entry routine (Idx 551, parameters
from W1's `pq`, `pSeedTrials` and the library `clog2`) is in `F2e2e/C/Impl/NewBank.lean`.
-/

namespace F2e2e.C.Impl.W3

open F2e2e F2e2e.Cost F2e2e.Discrete

namespace Idx

/-- Loop body of the fingerprint-seed sampler (accumulator `[r, D, k]`). -/
abbrev fpSeedStep : ℕ := 552

end Idx

/-! ## Reference facts -/

/-- Exact runs of `uniformBits k` read exactly `k` bits, valued `natOfBits` (big-endian). -/
theorem uniformBits_run_exact {k : ℕ} {bits : List Bool} {x : ℕ}
    (h : (uniformBits k).run bits = some (x, [])) : bits.length = k ∧ x = natOfBits bits := by
  rw [run_uniformBits] at h
  split_ifs at h with hk
  simp only [Option.some.injEq, Prod.mk.injEq] at h
  obtain ⟨hx, hd⟩ := h
  have hlen : bits.length ≤ k := List.drop_eq_nil_iff.mp hd
  have hlen' : bits.length = k := le_antisymm hlen hk
  refine ⟨hlen', ?_⟩
  rw [← hx, List.take_of_length_le (by omega)]
  rfl

theorem rejectUniform_zero_eq (D k : ℕ) : rejectUniform D k 0 = BitProg.pure none := rfl

theorem rejectUniform_succ_eq (D k r : ℕ) :
    rejectUniform D k (r + 1) = (uniformBits k).bind (fun x =>
      if x < D then BitProg.pure (some x) else rejectUniform D k r) := rfl

/-- Exact runs of one more trial. -/
theorem rejectUniform_succ_run_exact {D k r : ℕ} {bits : List Bool} {o : Option ℕ}
    (h : (rejectUniform D k (r + 1)).run bits = some (o, [])) :
    ∃ b₁ b₂ x, bits = b₁ ++ b₂ ∧ (uniformBits k).run b₁ = some (x, []) ∧
      ((x < D ∧ b₂ = [] ∧ o = some x) ∨ (¬ x < D ∧ (rejectUniform D k r).run b₂ = some (o, []))) := by
  rw [rejectUniform_succ_eq] at h
  obtain ⟨b₁, b₂, x, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  refine ⟨b₁, b₂, x, rfl, h1, ?_⟩
  by_cases hx : x < D
  · rw [if_pos hx] at h2
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
    exact Or.inl ⟨hx, rfl, rfl⟩
  · rw [if_neg hx] at h2
    exact Or.inr ⟨hx, h2⟩

section Read

variable {prog : List Expr} {M : ℕ}

/-- The library routine `readNat` implements `uniformBits w` (in the environment `[encN w]`). -/
theorem readNat_impl (hrn : prog[F2e2e.Cost.Idx.readNatStep]? = some body_readNatStep) (w : ℕ)
    (hM : S_readNat w ≤ M) : Implements prog M [encN w] body_readNat encN (uniformBits w) := by
  intro bits x h
  obtain ⟨hlen, rfl⟩ := uniformBits_run_exact h
  have := (readNat_spec hrn bits 0).toVal
  rw [hlen] at this
  exact this.mono_M hM

end Read

/-! ## The loop body -/

/-- Step of the fingerprint-seed sampler; accumulator `[r, D, k]`: no trial left (`r = 0`) ⇒ stop
with the fallback `0`; otherwise read `x` (`k` fresh bits, `readNat`); `x < D` ⇒ stop with `x`;
else continue with `[r - 1, D, k]`. -/
def body_fpSeedStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                     -- r; [r, acc]
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
      (ePair (Expr.lit 0) (Expr.lit 0))
      (Expr.letE (Expr.call F2e2e.Cost.Idx.readNat
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))  -- x; [x, r, acc]
        (Expr.ite (Expr.bin BinOp.lt (Expr.var 0)
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2))))
          (ePair (Expr.lit 0) (Expr.var 0))
          (ePair (Expr.lit 1)
            (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
              (Expr.un UnOp.tail (Expr.var 2)))))))

/-- The accumulator `[r, D, k]` of the seed sampler. -/
def fpAcc (r D k : ℕ) : Val := Val.list [encN r, encN D, encN k]

theorem valSize_fpAcc (r D k : ℕ) :
    valSize (fpAcc r D k) = Nat.size r + Nat.size D + Nat.size k + 7 := by
  simp only [fpAcc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

/-- The value bound of the seed sampler's loop (at most `r₀` trials of `k` bits, modulus `D`). -/
def fpM (r0 D k : ℕ) : ℕ := 4 * (Nat.size r0 + Nat.size D + k) + S_readNat k + 60

section Body

variable {prog : List Expr} {M : ℕ}

theorem fpSeedStep_zero_val (D k : ℕ) (hM : valSize (fpAcc 0 D k) + 8 ≤ M) :
    EvalsVal prog M [fpAcc 0 D k] [] (.inl body_fpSeedStep) (Val.list [Val.int 0, Val.int 0]) := by
  have hs := valSize_fpAcc 0 D k
  have h1 : EvalsVal prog M [fpAcc 0 D k] [] (.inl (Expr.un UnOp.head (Expr.var 0))) (encN 0) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_encN, Nat.size_zero]; omega)
  have hc : EvalsVal prog M [encN 0, fpAcc 0 D k] []
      (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 1) := by
    have := EvalsVal.eq (prog := prog) (M := M) (y := 0)
      (EvalsVal.var0 (v := Val.int ((0 : ℕ) : ℤ)) (rest := [fpAcc 0 D k]))
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega)) (by omega)
    simpa [encN] using this
  have ht : EvalsVal prog M [encN 0, fpAcc 0 D k] [] (.inl (ePair (Expr.lit 0) (Expr.lit 0)))
      (Val.list [Val.int 0, Val.int 0]) := by
    have := EvalsVal.pair (prog := prog) (M := M) (env := [encN 0, fpAcc 0 D k])
      (EvalsVal.lit' (z := 0) (by simp only [valSize_int, bitLen_zero]; omega))
      (EvalsVal.lit' (z := 0) (by simp only [valSize_int, bitLen_zero]; omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  exact (EvalsVal.letE h1 (EvalsVal.ite_true hc one_ne_zero ht)).cast_bits (by simp)

/-- The first steps of a trial (`r = j + 1`): read `x`, then evaluate the test in the environment
`[x, r, acc]`. -/
theorem fpSeedStep_succ_val (hrd : prog[F2e2e.Cost.Idx.readNat]? = some body_readNat)
    {j D k x : ℕ} {b1 : List Bool} {out : Val}
    (hread : EvalsVal prog M [encN k] b1 (.inl body_readNat) (encN x))
    (hM : valSize (fpAcc (j + 1) D k) + 4 ≤ M)
    (htest : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.ite (Expr.bin BinOp.lt (Expr.var 0)
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2))))
          (ePair (Expr.lit 0) (Expr.var 0))
          (ePair (Expr.lit 1)
            (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
              (Expr.un UnOp.tail (Expr.var 2)))))) out) :
    EvalsVal prog M [fpAcc (j + 1) D k] b1 (.inl body_fpSeedStep) out := by
  have hs := valSize_fpAcc (j + 1) D k
  have hj0 : (((j + 1 : ℕ) : ℤ)) ≠ 0 := by positivity
  have hj0' : (j : ℤ) + 1 ≠ 0 := by omega
  have h1 : EvalsVal prog M [fpAcc (j + 1) D k] [] (.inl (Expr.un UnOp.head (Expr.var 0)))
      (encN (j + 1)) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_encN]; omega)
  have hc : EvalsVal prog M [encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 0) := by
    have := EvalsVal.eq (prog := prog) (M := M) (y := 0)
      (EvalsVal.var0 (v := Val.int ((j + 1 : ℕ) : ℤ)) (rest := [fpAcc (j + 1) D k]))
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega)) (by omega)
    simpa [encN, hj0, hj0'] using this
  have harg : EvalsVal prog M [encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) (encN k) :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
      (by simp only [valSize_encN]; omega)
  have hcall := EvalsVal.call harg hrd hread
  exact (EvalsVal.letE h1 (EvalsVal.ite_false hc rfl (EvalsVal.letE hcall htest))).cast_bits
    (by simp)

theorem fpSeed_test_found {j D k x : ℕ} (hx : x < D)
    (hM : valSize (fpAcc (j + 1) D k) + 2 * valSize (encN x) + 10 ≤ M) :
    EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.ite (Expr.bin BinOp.lt (Expr.var 0)
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2))))
          (ePair (Expr.lit 0) (Expr.var 0))
          (ePair (Expr.lit 1)
            (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
              (Expr.un UnOp.tail (Expr.var 2))))))
      (Val.list [Val.int 0, encN x]) := by
  have hs := valSize_fpAcc (j + 1) D k
  have hxD : ((x : ℕ) : ℤ) < ((D : ℕ) : ℤ) := by exact_mod_cast hx
  have hD : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2)))) (encN D) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var2
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
      (by simp only [valSize_encN]; omega)
  have hc : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.bin BinOp.lt (Expr.var 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2)))))
      (Val.int 1) := by
    have := EvalsVal.lt (EvalsVal.var0 (v := Val.int ((x : ℕ) : ℤ))) hD (by omega)
    simpa [encN, hx, hxD] using this
  have ht : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (ePair (Expr.lit 0) (Expr.var 0))) (Val.list [Val.int 0, encN x]) := by
    have := EvalsVal.pair (EvalsVal.lit' (prog := prog) (M := M)
      (env := [encN x, encN (j + 1), fpAcc (j + 1) D k]) (z := 0)
      (by simp only [valSize_int, bitLen_zero]; omega)) EvalsVal.var0
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  exact (EvalsVal.ite_true hc one_ne_zero ht).cast_bits (by simp)

theorem fpSeed_test_retry {j D k x : ℕ} (hx : ¬ x < D)
    (hM : valSize (fpAcc (j + 1) D k) + 2 * valSize (encN x) + 10 ≤ M) :
    EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.ite (Expr.bin BinOp.lt (Expr.var 0)
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2))))
          (ePair (Expr.lit 0) (Expr.var 0))
          (ePair (Expr.lit 1)
            (Expr.bin BinOp.cons (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))
              (Expr.un UnOp.tail (Expr.var 2))))))
      (Val.list [Val.int 1, fpAcc j D k]) := by
  have hs := valSize_fpAcc (j + 1) D k
  have hs' := valSize_fpAcc j D k
  have hjs : Nat.size j ≤ Nat.size (j + 1) := Nat.size_le_size (by omega)
  have hxD : ¬ ((x : ℕ) : ℤ) < ((D : ℕ) : ℤ) := by exact_mod_cast hx
  have hsub1 : ((j + 1 : ℕ) : ℤ) - 1 = (j : ℤ) := by push_cast; ring
  have hD : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2)))) (encN D) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var2
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
      (by simp only [valSize_encN]; omega)
  have hc : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.bin BinOp.lt (Expr.var 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 2)))))
      (Val.int 0) := by
    have := EvalsVal.lt (EvalsVal.var0 (v := Val.int ((x : ℕ) : ℤ))) hD (by omega)
    simpa [encN, hx, hxD] using this
  have hsub : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.bin BinOp.sub (Expr.var 1) (Expr.lit 1))) (encN j) := by
    have := EvalsVal.sub (prog := prog) (M := M) (y := 1)
      (EvalsVal.var1 (v := Val.int ((j + 1 : ℕ) : ℤ)) (w := encN x) (rest := [fpAcc (j + 1) D k]))
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_one]; omega))
      (by rw [hsub1]; simp only [valSize_int, bitLen_natCast]; omega)
    rw [hsub1] at this
    simpa [encN] using this
  have htl : EvalsVal prog M [encN x, encN (j + 1), fpAcc (j + 1) D k] []
      (.inl (Expr.un UnOp.tail (Expr.var 2))) (Val.list [encN D, encN k]) :=
    EvalsVal.tail EvalsVal.var2
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega)
  have hcons := EvalsVal.cons hsub htl
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega)
  have hf := EvalsVal.pair (EvalsVal.lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega))
    hcons (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, valSize_encN,
      bitLen_one]; omega)
  have := EvalsVal.cast_bits (bits' := [])
    (EvalsVal.ite_false (t := ePair (Expr.lit 0) (Expr.var 0)) hc rfl hf) (by simp)
  simpa [fpAcc] using this

end Body

/-! ## The loop -/

section Loop

variable {prog : List Expr} {M : ℕ}

/-- **The seed sampler's loop**: from `[r, D, k]` (`r ≤ r₀`), the loop consumes exactly the bits of
an exact run of `rejectUniform D k r` and returns the accepted value, or the fallback `0`. -/
theorem fpSeed_loop (hstep : prog[Idx.fpSeedStep]? = some body_fpSeedStep)
    (hrd : prog[F2e2e.Cost.Idx.readNat]? = some body_readNat)
    (hrn : prog[F2e2e.Cost.Idx.readNatStep]? = some body_readNatStep) (r0 D k : ℕ)
    (hM : fpM r0 D k ≤ M) :
    ∀ r, r ≤ r0 → ∀ bits o, (rejectUniform D k r).run bits = some (o, []) →
      EvalsVal prog M [] bits (.inr (Idx.fpSeedStep, fpAcc r D k)) (encN (o.getD 0)) := by
  have hkS : Nat.size k ≤ k := size_le_self k
  intro r
  induction r with
  | zero =>
    intro _ bits o h
    rw [rejectUniform_zero_eq] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    refine EvalsVal.stop hstep ?_
    have hs := valSize_fpAcc 0 D k
    simp only [Nat.size_zero] at hs
    exact fpSeedStep_zero_val D k (by simp only [fpM] at hM; omega)
  | succ j ih =>
    intro hj bits o h
    obtain ⟨b₁, b₂, x, rfl, h1, hcase⟩ := rejectUniform_succ_run_exact h
    have hread := readNat_impl (M := M) hrn k (by simp only [fpM] at hM; omega) b₁ x h1
    have hxk : Nat.size x ≤ k := by
      obtain ⟨hlen, rfl⟩ := uniformBits_run_exact h1
      rw [Nat.size_le, ← hlen]
      exact natOfBits_lt b₁
    have hs := valSize_fpAcc (j + 1) D k
    have hjs : Nat.size (j + 1) ≤ Nat.size r0 := Nat.size_le_size hj
    have hxs : valSize (encN x) = Nat.size x + 1 := valSize_encN x
    have hM' : valSize (fpAcc (j + 1) D k) + 2 * valSize (encN x) + 10 ≤ M := by
      simp only [fpM] at hM; omega
    rcases hcase with ⟨hx, rfl, rfl⟩ | ⟨hx, h2⟩
    · refine EvalsVal.stop hstep ?_
      exact (fpSeedStep_succ_val hrd hread (by omega) (fpSeed_test_found hx hM')).cast_bits
        (by simp)
    · have hrest := ih (by omega) b₂ o h2
      exact EvalsVal.cont hstep (fpSeedStep_succ_val hrd hread (by omega) (fpSeed_test_retry hx hM'))
        one_ne_zero hrest

end Loop

end F2e2e.C.Impl.W3
