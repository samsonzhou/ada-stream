import F2e2e.C.Impl.AdaEntryDefs

/-!
# ADA module (W4), `adaInterval`: the endpoint rounding `adaIvRound` (Idx 608)

`adaIvRound_val`: on `[encQ x, encN 2^q]`, `body_adaIvRound` returns the lattice index
`roundIdxQ (1/2)^q (clipQ (-1) 2 x)` of the endpoint `x` clipped to `[-1, 2]`
(`B-ARCH`'s `adaIntervalD`, `F2e2e/B/ArchCore.lean` L286–287; `h_A = (1/2)^{qA}`).

Owner: 4a7299ed (handed over by W2, a2ff64c3, 2026-10-25 09:22Z; statement fixed by W2).
Proof: the body is the compiled integer expression `ivRoundZE` (W4's `ZE`, `AdaFrame.lean`);
`roundIdx_clip_eq` is the arithmetic (three branches: `x > 2`, `x < -1`, `-1 ≤ x ≤ 2`; in the last
one `⌊x 2^q + 1/2⌋ = ⌊(2 xn 2^q + xd) / (2 xd)⌋` is Lean's integer division).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## The arithmetic -/

/-- The lattice index of the clipped endpoint, in the integer form computed by `adaIvRound`. -/
theorem roundIdx_clip_eq (x : ℚ) (q : ℕ) :
    roundIdxQ ((1 / 2 : ℚ) ^ q) (clipQ (-1) 2 x) =
      if 2 * (x.den : ℤ) < x.num then 2 * ((2 ^ q : ℕ) : ℤ)
      else if x.num < 0 - (x.den : ℤ) then 0 - ((2 ^ q : ℕ) : ℤ)
      else (2 * x.num * ((2 ^ q : ℕ) : ℤ) + x.den) / (2 * (x.den : ℤ)) := by
  have hd : (0 : ℚ) < x.den := by exact_mod_cast x.den_pos
  have hd' : (x.den : ℚ) ≠ 0 := hd.ne'
  have hx : (x.num : ℚ) / x.den = x := Rat.num_div_den x
  have hdiv : ∀ r : ℚ, r / (1 / 2) ^ q = r * 2 ^ q := fun r => by
    rw [one_div, inv_pow, div_inv_eq_mul]
  unfold roundIdxQ clipQ
  rw [hdiv]
  split_ifs with h1 h2
  · have hx2 : (2 : ℚ) < x := by
      rw [← hx, lt_div_iff₀ hd]; exact_mod_cast h1
    rw [min_eq_left hx2.le, max_eq_right (by norm_num : (-1 : ℚ) ≤ 2), Int.floor_eq_iff]
    push_cast
    constructor <;> linarith
  · have h2' : (x.num : ℚ) < 0 - (x.den : ℚ) := by exact_mod_cast h2
    have hx1 : x < -1 := by
      rw [← hx, div_lt_iff₀ hd]; linarith
    rw [min_eq_right (by linarith : x ≤ 2), max_eq_left hx1.le, Int.floor_eq_iff]
    push_cast
    constructor <;> linarith
  · have h1' : ¬ (2 * (x.den : ℚ) < x.num) := by exact_mod_cast h1
    have h2' : ¬ ((x.num : ℚ) < 0 - (x.den : ℚ)) := by exact_mod_cast h2
    have hlo : -1 ≤ x := by
      rw [← hx, le_div_iff₀ hd]; linarith
    have hhi : x ≤ 2 := by
      rw [← hx, div_le_iff₀ hd]; linarith
    rw [min_eq_right hhi, max_eq_right hlo]
    have e : x * 2 ^ q + 1 / 2 = ((2 * x.num * ((2 ^ q : ℕ) : ℤ) + x.den : ℤ) : ℚ) /
        ((2 * x.den : ℕ) : ℚ) := by
      conv_lhs => rw [← hx]
      push_cast
      field_simp
    rw [e, Rat.floor_intCast_div_natCast]
    simp only [Nat.cast_mul, Nat.cast_ofNat]

/-! ## The compiled integer expression -/

/-- `adaIvRound`'s body as an integer expression (leaves `x.num`, `x.den`, `2^q`). -/
def ivRoundZE (x : ℚ) (q : ℕ) : ZE :=
  ZE.cnd (ZE.lt (ZE.mul (ZE.lit 2) (ZE.leaf (eAtN 1 (eAtN 0 (eV 0))) (x.den : ℤ)))
      (ZE.leaf (eAtN 0 (eAtN 0 (eV 0))) x.num))
    (ZE.mul (ZE.lit 2) (ZE.leaf (eAtN 1 (eV 0)) ((2 ^ q : ℕ) : ℤ)))
    (ZE.cnd (ZE.lt (ZE.leaf (eAtN 0 (eAtN 0 (eV 0))) x.num)
        (ZE.sub (ZE.lit 0) (ZE.leaf (eAtN 1 (eAtN 0 (eV 0))) (x.den : ℤ))))
      (ZE.sub (ZE.lit 0) (ZE.leaf (eAtN 1 (eV 0)) ((2 ^ q : ℕ) : ℤ)))
      (ZE.div (ZE.add (ZE.mul (ZE.mul (ZE.lit 2) (ZE.leaf (eAtN 0 (eAtN 0 (eV 0))) x.num))
          (ZE.leaf (eAtN 1 (eV 0)) ((2 ^ q : ℕ) : ℤ)))
          (ZE.leaf (eAtN 1 (eAtN 0 (eV 0))) (x.den : ℤ)))
        (ZE.mul (ZE.lit 2) (ZE.leaf (eAtN 1 (eAtN 0 (eV 0))) (x.den : ℤ)))))

theorem ivRoundZE_toExpr (x : ℚ) (q : ℕ) : (ivRoundZE x q).toExpr = body_adaIvRound := rfl

theorem ivRoundZE_val (x : ℚ) (q : ℕ) :
    (ivRoundZE x q).val = roundIdxQ ((1 / 2 : ℚ) ^ q) (clipQ (-1) 2 x) := by
  rw [roundIdx_clip_eq]
  simp only [ivRoundZE, ZE.val]
  by_cases h1 : 2 * (x.den : ℤ) < x.num
  · simp only [h1, if_true, ne_eq, one_ne_zero, not_false_eq_true]
  · by_cases h2 : x.num < 0 - (x.den : ℤ)
    · simp only [h1, h2, if_true, if_false, ne_eq, one_ne_zero, not_false_eq_true,
        not_true_eq_false]
    · simp only [h1, h2, if_false, ne_eq, not_true_eq_false]

theorem ivRoundZE_mx (x : ℚ) (q : ℕ) {Bq : ℕ} (hx : bitLen x.num ≤ Bq ∧ bitLen (x.den : ℤ) ≤ Bq) :
    (ivRoundZE x q).mx ≤ Bq + q + 4 := by
  have h2 : bitLen (2 : ℤ) = 2 := by decide
  have hH : bitLen (((2 ^ q : ℕ)) : ℤ) = q + 1 := by rw [bitLen_natCast, Nat.size_pow]
  simp only [ivRoundZE, ZE.mx, ZE.bnd, h2, hH, bitLen_zero, max_le_iff, Nat.add_one_le_iff,
    max_lt_iff]
  omega

/-! ## The routine -/

/-- **Spec of `adaIvRound`** (deterministic). -/
theorem adaIvRound_val {prog : List Expr} {M : ℕ} (x : ℚ) (q : ℕ) {Bq : ℕ}
    (hx : bitLen x.num ≤ Bq ∧ bitLen (x.den : ℤ) ≤ Bq) (hM : 2 ^ 4 * (Bq + q + 8) ≤ M) :
    EvalsVal prog M [Val.list [encQ x, encN (2 ^ q)]] [] (.inl body_adaIvRound)
      (Val.int (roundIdxQ ((1 / 2 : ℚ) ^ q) (clipQ (-1) 2 x))) := by
  have hden := x.den_pos
  have hvM : valSize (Val.list [encQ x, encN (2 ^ q)]) ≤ M := by
    simp only [encQ, valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN,
      Nat.size_pow]
    omega
  have hv : EvalsVal prog M [Val.list [encQ x, encN (2 ^ q)]] [] (.inl (eV 0))
      (Val.list [encQ x, encN (2 ^ q)]) := EvalsVal.var rfl
  have hQ := evalsVal_atN' hv hvM (n := 0) rfl
  have hQM : valSize (encQ x) ≤ M :=
    le_trans (valSize_le_of_getElem? (l := [encQ x, encN (2 ^ q)]) (n := 0) rfl) hvM
  have hnum : EvalsVal prog M [Val.list [encQ x, encN (2 ^ q)]] []
      (.inl (eAtN 0 (eAtN 0 (eV 0)))) (Val.int x.num) :=
    evalsVal_atN' (l := [Val.int x.num, Val.int (x.den : ℤ)]) hQ hQM rfl
  have hdenv : EvalsVal prog M [Val.list [encQ x, encN (2 ^ q)]] []
      (.inl (eAtN 1 (eAtN 0 (eV 0)))) (Val.int (x.den : ℤ)) :=
    evalsVal_atN' (l := [Val.int x.num, Val.int (x.den : ℤ)]) hQ hQM rfl
  have hH : EvalsVal prog M [Val.list [encQ x, encN (2 ^ q)]] [] (.inl (eAtN 1 (eV 0)))
      (Val.int ((2 ^ q : ℕ) : ℤ)) := evalsVal_atN' hv hvM rfl
  have hOK : (ivRoundZE x q).OK prog M [Val.list [encQ x, encN (2 ^ q)]] := by
    simp only [ivRoundZE, ZE.OK, ZE.val]
    exact ⟨⟨⟨trivial, hdenv⟩, hnum⟩, ⟨trivial, hH⟩, ⟨hnum, trivial, hdenv⟩, ⟨trivial, hH⟩,
      ⟨⟨⟨trivial, hnum⟩, hH⟩, hdenv⟩, ⟨trivial, hdenv⟩, by omega⟩
  have hmx := ivRoundZE_mx x q hx
  have h := ZE.spec (ivRoundZE x q) hOK (by omega)
  rw [ivRoundZE_toExpr, ivRoundZE_val] at h
  exact h

end F2e2e.C.Impl
