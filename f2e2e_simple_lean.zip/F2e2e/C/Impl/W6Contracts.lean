import F2e2e.Cost.BitProgBridge
import F2e2e.C.SpaceState
import F2e2e.C.Top.Interface
import F2e2e.C.Alg.Round

/-!
# Theorem (C), DSL implementation: the contracts of the W1–W5 routines called by W6

Owner: C-TOP (W6 integration). This file fixes, for every DSL routine that the tree controller (W6,
`F2e2e/C/Impl/Tree*.lean`) or another work package calls across a package boundary,

* its **function index** (`F2e2e.C.Impl.Idx.*`; ranges below),
* its **argument layout** (the routine's body runs in the environment `[input]`, `input` = the value
  listed in the contract) and its **output encoding**,
* its **reference function** (C-ALG's `F2e2e/C/Alg/*.lean`, B-ARCH's `F2e2e/B/ArchCore.lean`, C-PARAMS'
  `F2e2e/C/ParamsDefs.lean`),
* its **preconditions** and the **value bound**: every contract holds for every `M ≥ Mv R P`, the uniform
  bound on the size of every value produced in a round (Generic Space Theorem, `F2e2e/Cost/Generic.lean`,
  `notes/C_IMPL_DESIGN.md`).

Contracts are `Prop`s about an arbitrary program `prog`, of the form `AtIdx prog idx spec`: there is a
routine at index `idx` and it satisfies `spec` (they never name the body): the owner of a routine proves
`∀ prog, <its table is in prog> → <contract> prog M R` for its own bodies (witness: its body); W6 proves the tree controller from `Contracts R prog M`; `F2e2e/C/Impl/Assemble.lean` combines them
for the final program. Deterministic routines are stated with `EvalsVal … [] …` (no fresh bits), routines
reading fresh bits with `Implements` (`F2e2e/Cost/BitProgBridge.lean`).

## Index ranges (agreed with the lead; DSL-CALC's library keeps `1–149`, verbatim HASH `150–249`)
| range | package | owner |
|---|---|---|
| 250–399 | W6: tree controller, entry points | C-TOP 95aff426 |
| 400–449 | W1: public parameters | C-PARAMS e26ae4ae |
| 150–249 | W2: hashing / fingerprint (cut2 HASH layout 150–173, fingerprint 200+, e.g. `fpUpdate = 206`) | a2ff64c3 |
| 450–549 | spare (W2 overflow) | — |
| 550–599 | W3: samplers, row seeds, bank creation | (new worker) |
| 600–749 | W4: ADA module | cc77ceaa |
| 750–899 | W5: bank operations | c1b4f720 |
Each owner allocates its internal helper indices inside its range; the entry indices below are fixed.

## Conventions
* Parameters: every contracted routine of W1, W3, W5 receives the Spec's `encStreamParams P` and computes
  what it needs (time is free); W4's routines receive W4's own parameter record `R.pub (bankAda P)`,
  computed from `encStreamParams P` by W4's routine `Idx.adaPub`.
* Rationals crossing a routine boundary are **canonical**: `encQ x = [x.num, x.den]` (reduced, `den > 0`;
  use the shared `Idx.normQ` (W5) to normalise); inside a routine any representation may be used.
* `Option ℚ ↦ [] / [encQ x]`; `AdaNum ↦ [] (abort) / [encQ μ]`; `AdaCert ↦ 0 accept, 1 high, 2 low,
  3 termHigh, 4 termLow, 5 abort`; `Mode ↦ 0 primary / 1 diff`; query tables `vals ↦ encVals`.
* States, banks, rows, learners: C-SPACE's canonical encodings `encState`, `encBank`, `encRow`,
  `encLearner` (`F2e2e/C/SpaceState.lean`), with the ADA state encoded by `R.enc`.
* The ADA representation `R : AdaRep` (state encoding, parameter record, invariant, size bound) is chosen
  by W4, who also proves `R.Valid`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-! ## Function indices of the contracted entry routines -/

namespace Idx

/-- W1: `encStreamParams P ↦ Val.int P.H`. -/
abbrev pH : ℕ := 400
/-- W1: `encStreamParams P ↦ Val.int P.eHC`. -/
abbrev peHC : ℕ := 401
/-- W1: `encStreamParams P ↦ Val.int P.eHP`. -/
abbrev peHP : ℕ := 402
/-- W1: `encStreamParams P ↦ Val.int P.eHleaf`. -/
abbrev peHleaf : ℕ := 403
/-- W1: `encStreamParams P ↦ Val.int P.eHg`. -/
abbrev peHg : ℕ := 404
/-- W1: `encStreamParams P ↦ Val.int P.eHstep`. -/
abbrev peHstep : ℕ := 405
/-- W1: `encStreamParams P ↦ Val.int P.eEta`. -/
abbrev peEta : ℕ := 406
/-- W1: `encStreamParams P ↦ Val.int P.eGamma`. -/
abbrev peGamma : ℕ := 407
/-- W1: `encStreamParams P ↦ Val.int P.Jstar`. -/
abbrev pJstar : ℕ := 408
/-- W1: `encStreamParams P ↦ Val.int P.K0`. -/
abbrev pK0 : ℕ := 409
/-- W1: `encStreamParams P ↦ Val.int P.Kepoch`. -/
abbrev pKepoch : ℕ := 410
/-- W1: `encStreamParams P ↦ Val.int P.Amax`. -/
abbrev pAmax : ℕ := 411
/-- W1: `encStreamParams P ↦ Val.int P.Cmax`. -/
abbrev pCmax : ℕ := 412
/-- W1: `encStreamParams P ↦ Val.int P.q`. -/
abbrev pq : ℕ := 413
/-- W1: `[encStreamParams P, d] ↦ Val.int (P.eU d)`. -/
abbrev peU : ℕ := 414
/-- W1: `[encStreamParams P, d, t] ↦ Val.int (P.guardCoord d t)`. -/
abbrev pGuardCoord : ℕ := 415
/-- W1: `encStreamParams P ↦ Val.int P.eHb`. -/
abbrev peHb : ℕ := 416
/-- W1: `encStreamParams P ↦ Val.int P.Zmax`. -/
abbrev pZmax : ℕ := 417
/-- W1: `encStreamParams P ↦ Val.int P.Dstar`. -/
abbrev pDstar : ℕ := 418
/-- W1: `encStreamParams P ↦ Val.int P.eSigma` (`σ = 2^{-eSigma}`). -/
abbrev peSigma : ℕ := 419
/-- W1: `encStreamParams P ↦ Val.int P.eOmega` (`ω = 2^{-eOmega}`). -/
abbrev peOmega : ℕ := 420
/-- W1: `encStreamParams P ↦ Val.int P.L`. -/
abbrev pL : ℕ := 421
/-- W1: `encStreamParams P ↦ Val.int P.w`. -/
abbrev pw : ℕ := 422
/-- W1: `encStreamParams P ↦ Val.int (irrW P)` (the field polynomial of `𝔽_{2^w}`). -/
abbrev pIrrW : ℕ := 423
/-- W1: `encStreamParams P ↦ Val.int P.s`. -/
abbrev ps : ℕ := 424
/-- W1: `encStreamParams P ↦ Val.int P.gCoarse`. -/
abbrev pgCoarse : ℕ := 425
/-- W1: `encStreamParams P ↦ Val.int P.Rmax`. -/
abbrev pRmax : ℕ := 426
/-- W1: `encStreamParams P ↦ Val.int P.eBankA`. -/
abbrev peBankA : ℕ := 427
/-- W1: `encStreamParams P ↦ Val.int P.eBankXi`. -/
abbrev peBankXi : ℕ := 428
/-- W1: `encStreamParams P ↦ Val.int P.bankM`. -/
abbrev pbankM : ℕ := 429
/-- W1: `encStreamParams P ↦ Val.int P.bankJ`. -/
abbrev pbankJ : ℕ := 430
/-- W1: `encStreamParams P ↦ Val.int P.bankR`. -/
abbrev pbankR : ℕ := 431
/-- W1: `encStreamParams P ↦ Val.int P.seedTrials`. -/
abbrev pSeedTrials : ℕ := 432

/-- W2 (verbatim HASH layout): the fingerprint update `[q, seed, val, i, Δ] ↦ fpUpdate` (this is
`F2e2e.Cost.Idx.fpUpdate`, `F2e2e/C/Impl/Fingerprint.lean`). -/
abbrev fpUpdate : ℕ := 206

/-- W3: `encStreamParams P ↦` a fresh bank (`newBank P`). -/
abbrev newBank : ℕ := 550
/-- W3: `encStreamParams P ↦` the fingerprint seed (`fpSeedProg P`). -/
abbrev fpSeed : ℕ := 551

/-- W4: `encStreamParams P ↦ R.pub (bankAda P)`. -/
abbrev adaPub : ℕ := 600
/-- W4: `R.pub (bankAda P) ↦` a fresh ADA state (`adaInit`). -/
abbrev adaInit : ℕ := 601
/-- W4: the interval interface (`adaInterval`). -/
abbrev adaInterval : ℕ := 602
/-- W4: the numerical interface (`adaNumerical`). -/
abbrev adaNumerical : ℕ := 603
/-- W4: `encStreamParams P ↦ Val.int (bankAda P).qA`. -/
abbrev adaQA : ℕ := 604
/-- W4: `encStreamParams P ↦ encL encN (bankAda P).blockSizes`. -/
abbrev adaBlockSizes : ℕ := 605

/-- W5: `Bank.mapRows Row.resetY`. -/
abbrev resetYBank : ℕ := 750
/-- W5: `Bank.mapRows (Row.addPhys P i Δ)`. -/
abbrev addPhysBank : ℕ := 751
/-- W5: `Bank.mapRows (Row.addGuardY P g δ)`. -/
abbrev addGuardYBank : ℕ := 752
/-- W5: `Bank.mapRows (Row.addGuardXY P g δ)`. -/
abbrev addGuardXYBank : ℕ := 753
/-- W5: `Bank.mapRows (Row.scaleY P cInt)`. -/
abbrev scaleYBank : ℕ := 754
/-- W5: `Bank.mapRows (Row.scaleXY P cInt)`. -/
abbrev scaleXYBank : ℕ := 755
/-- W5: `Bank.validate` (`ValidateInterval`). -/
abbrev validate : ℕ := 756
/-- W5: `Bank.release` (`ReleaseNumerical`). -/
abbrev release : ℕ := 757
/-- W5: `[q, encQ z] ↦ roundMant q z`. -/
abbrev roundMantQ : ℕ := 758
/-- W5: `[Cint, α, e] ↦ guardMant Cint α e`. -/
abbrev guardMant : ℕ := 759
/-- W5: `[pos, qη, qs, encQ Pval, encQ Q̂] ↦ stepCoeffMant pos qη qs Pval Q̂`. -/
abbrev stepCoeffMant : ℕ := 760
/-- W5: `[encStreamParams P, cInt, encLearner L] ↦ encLearner (Learner.rescale P cInt L)`. -/
abbrev rescaleLearner : ℕ := 761
/-- W5: `[encStreamParams P, encLearner L] ↦ encOptLearner (Learner.countCorrection P L)`. -/
abbrev countCorrection : ℕ := 762
/-- W5: `[encStreamParams P, encQ x] ↦ encB (inRangeA P x)`. -/
abbrev inRangeA : ℕ := 763
/-- W5: `[encStreamParams P, encQ x] ↦ encB (inRangeC P x)`. -/
abbrev inRangeC : ℕ := 764
/-- W5: `[encStreamParams P, encLearner L] ↦ encB (L.inRange P)`. -/
abbrev learnerInRange : ℕ := 765
/-- W5 (shared utility, any package may call it): `[a, b] ↦ encQ (a / b)` for `b > 0`. -/
abbrev normQ : ℕ := 766

end Idx

/-! ## Encodings at routine boundaries -/

/-- Canonical rationals: `[num, den]` (reduced, `den > 0`). -/
def encQ (x : ℚ) : Val := Val.list [Val.int x.num, Val.int (x.den : ℤ)]

/-- Optional rationals: `[]` or `[encQ x]`. -/
def encOptQ : Option ℚ → Val
  | none => Val.list []
  | some x => Val.list [encQ x]

/-- ADA certificates as integer codes. -/
def encCert : AdaCert → Val
  | AdaCert.accept => Val.int 0
  | AdaCert.high => Val.int 1
  | AdaCert.low => Val.int 2
  | AdaCert.termHigh => Val.int 3
  | AdaCert.termLow => Val.int 4
  | AdaCert.abort => Val.int 5

/-- ADA numerical outputs: `[]` (abort) or `[encQ μ]`. -/
def encNum : AdaNum → Val
  | AdaNum.val μ => Val.list [encQ μ]
  | AdaNum.abort => Val.list []

/-- Evaluation modes: `0` primary, `1` diff. -/
def encMode : Mode → Val
  | Mode.primary => Val.int 0
  | Mode.diff => Val.int 1

/-- Optional learners: `[]` or `[encLearner L]`. -/
def encOptLearner : Option Learner → Val
  | none => Val.list []
  | some L => Val.list [encLearner L]

/-- Query tables (grid indices, block by block). -/
def encVals (vals : List (List ℕ)) : Val :=
  Val.list (vals.map fun blk => Val.list (blk.map fun v => Val.int (v : ℤ)))

/-! ## The ADA representation (chosen by W4) -/

/-- The representation of the ADA module: the encoding of its states, its parameter record, the state
invariant (per parameter record of Theorem C) and the size bound of an encoded state. -/
structure AdaRep where
  /-- Encoding of an ADA state. -/
  enc : AdaState → Val
  /-- Encoding of the ADA parameters (the record passed to W4's routines). -/
  pub : AdaParams → Val
  /-- The invariant of the ADA state (for the bank ADA instance of `P`). -/
  ok : StreamParams → AdaState → Prop
  /-- The size bound of an encoded ADA state satisfying the invariant. -/
  bound : StreamParams → ℕ

/-- A query table of the bank ADA instance: block sizes `n_0, …, n_p`, grid indices in `[0, 2^{qA}]`. -/
def ValsOK (P : StreamParams) (vals : List (List ℕ)) : Prop :=
  vals.map List.length = (bankAda P).blockSizes ∧
    ∀ blk ∈ vals, ∀ v ∈ blk, v ≤ 2 ^ (bankAda P).qA

/-- W4's obligations on its representation: the invariant is established and preserved by the ADA
module on every path (C-SPACE's `AdaInvariant`), and `R.bound P` bounds every value of the module that
its callers handle: the encoded state, the parameter record, the grid exponent `qA`, the encoded query
tables and the encoded numerical outputs (W5's request, 08:00Z). -/
structure AdaRep.Valid (R : AdaRep) : Prop where
  invariant : ∀ P : StreamParams, ParamsOK P → AdaInvariant P (R.ok P)
  enc_le : ∀ P : StreamParams, ParamsOK P → ∀ st : AdaState, R.ok P st → valSize (R.enc st) ≤ R.bound P
  pub_le : ∀ P : StreamParams, ParamsOK P → valSize (R.pub (bankAda P)) ≤ R.bound P
  qA_le : ∀ P : StreamParams, ParamsOK P → (bankAda P).qA ≤ R.bound P
  vals_le : ∀ P : StreamParams, ParamsOK P → ∀ vals : List (List ℕ), ValsOK P vals →
    valSize (encVals vals) ≤ R.bound P
  num_le : ∀ P : StreamParams, ParamsOK P → ∀ (st : AdaState) (vals : List (List ℕ)), R.ok P st →
    ValsOK P vals → Always (adaNumerical (bankAda P) st vals) (fun r => valSize (encNum r.1) ≤ R.bound P)

/-! ## The value bound and boundary conditions -/

/-- The register bit bound `2^7 ℒ³` (C-SPACE's register lemmas, `F2e2e/C/SpaceRegs.lean`). -/
def regBits (P : StreamParams) : ℕ := 2 ^ 7 * P.calL ^ 3

/-- **The uniform value bound of a round**: every contract holds for every `M ≥ Mv R P`, and every value
produced by a contracted routine must have `valSize ≤ M`. (`stateSizeBound` is C-SPACE's bound of the
encoded state; it is `≥ 2^5 ℒ³`, so integers of `≤ 2^20 ℒ³` bits fit; the factor `2^32` is far inside the
`2^167` available, see `const_mul_stateSizeBound_le_spaceBoundC`.) -/
def Mv (R : AdaRep) (P : StreamParams) : ℕ := 2 ^ 32 * stateSizeBound P (R.bound P)

/-- A rational crossing a routine boundary has numerator and denominator of at most `4 · regBits P`
bits. -/
def QOK (P : StreamParams) (x : ℚ) : Prop :=
  |x.num| ≤ 2 ^ (4 * regBits P) ∧ (x.den : ℤ) ≤ 2 ^ (4 * regBits P)

/-! ## The routine at an index -/

/-- The program `prog` has a routine at index `idx` and it satisfies `spec` (contracts are stated in
this form, so a caller obtains the body from the contract). -/
def AtIdx (prog : List Expr) (idx : ℕ) (spec : Expr → Prop) : Prop :=
  ∃ body, prog[idx]? = some body ∧ spec body

/-! ## W1: public parameters (deterministic) -/

/-- A parameter routine: `encStreamParams P ↦ Val.int (f P)`. -/
def ParamSpec (R : AdaRep) (prog : List Expr) (M : ℕ) (idx : ℕ) (f : StreamParams → ℕ) : Prop :=
  AtIdx prog idx fun body => ∀ P : StreamParams, ParamsOK P → Mv R P ≤ M →
    EvalsVal prog M [encStreamParams P] [] (.inl body) (Val.int (f P : ℤ))

/-- The W1 contract (parameters used by W6). -/
structure W1Contract (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  pH : ParamSpec R prog M Idx.pH StreamParams.H
  peHC : ParamSpec R prog M Idx.peHC StreamParams.eHC
  peHP : ParamSpec R prog M Idx.peHP StreamParams.eHP
  peHleaf : ParamSpec R prog M Idx.peHleaf StreamParams.eHleaf
  peHg : ParamSpec R prog M Idx.peHg StreamParams.eHg
  peHstep : ParamSpec R prog M Idx.peHstep StreamParams.eHstep
  peEta : ParamSpec R prog M Idx.peEta StreamParams.eEta
  peGamma : ParamSpec R prog M Idx.peGamma StreamParams.eGamma
  pJstar : ParamSpec R prog M Idx.pJstar StreamParams.Jstar
  pK0 : ParamSpec R prog M Idx.pK0 StreamParams.K0
  pKepoch : ParamSpec R prog M Idx.pKepoch StreamParams.Kepoch
  pAmax : ParamSpec R prog M Idx.pAmax StreamParams.Amax
  pCmax : ParamSpec R prog M Idx.pCmax StreamParams.Cmax
  pq : ParamSpec R prog M Idx.pq StreamParams.q
  peHb : ParamSpec R prog M Idx.peHb StreamParams.eHb
  pZmax : ParamSpec R prog M Idx.pZmax StreamParams.Zmax
  pDstar : ParamSpec R prog M Idx.pDstar StreamParams.Dstar
  peSigma : ParamSpec R prog M Idx.peSigma StreamParams.eSigma
  peOmega : ParamSpec R prog M Idx.peOmega StreamParams.eOmega
  pL : ParamSpec R prog M Idx.pL StreamParams.L
  pw : ParamSpec R prog M Idx.pw StreamParams.w
  pIrrW : ParamSpec R prog M Idx.pIrrW irrW
  ps : ParamSpec R prog M Idx.ps StreamParams.s
  pgCoarse : ParamSpec R prog M Idx.pgCoarse StreamParams.gCoarse
  pRmax : ParamSpec R prog M Idx.pRmax StreamParams.Rmax
  peBankA : ParamSpec R prog M Idx.peBankA StreamParams.eBankA
  peBankXi : ParamSpec R prog M Idx.peBankXi StreamParams.eBankXi
  pbankM : ParamSpec R prog M Idx.pbankM StreamParams.bankM
  pbankJ : ParamSpec R prog M Idx.pbankJ StreamParams.bankJ
  pbankR : ParamSpec R prog M Idx.pbankR StreamParams.bankR
  pSeedTrials : ParamSpec R prog M Idx.pSeedTrials StreamParams.seedTrials
  /-- `[encStreamParams P, d] ↦ Val.int (P.eU d)` for depths `d < H`. -/
  peU : AtIdx prog Idx.peU fun body => ∀ (P : StreamParams) (d : ℕ), ParamsOK P → d < P.H →
    Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encN d]] [] (.inl body) (Val.int (P.eU d : ℤ))
  /-- `[encStreamParams P, d, t] ↦ Val.int (P.guardCoord d t)` for `d < H`, `1 ≤ t ≤ m`. -/
  pGuardCoord : AtIdx prog Idx.pGuardCoord fun body => ∀ (P : StreamParams) (d t : ℕ),
    ParamsOK P → d < P.H → 1 ≤ t → t ≤ P.m → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encN d, encN t]] [] (.inl body)
      (Val.int (P.guardCoord d t : ℤ))

/-! ## W2: the fingerprint update (verbatim HASH routine `Cost.Idx.fpUpdate`) -/

/-- The W2 contract used by W6: C-ALG's fingerprint update on `[q, seed, val, i, Δ]`. -/
structure W2Contract (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  fpUpdate : AtIdx prog Idx.fpUpdate fun body =>
    ∀ (P : StreamParams) (seed val i : ℕ) (Δ : ℤ), ParamsOK P → seed < P.q → val < P.q →
      1 ≤ i → i ≤ P.n → |Δ| ≤ 2 * (P.U : ℤ) → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]] [] (.inl body)
        (encN (fpUpdate P seed val i Δ))

/-! ## W3: samplers and bank creation (fresh bits) -/

/-- The W3 contract: a fresh bank and the fingerprint seed. -/
structure W3Contract (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  newBank : AtIdx prog Idx.newBank fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → Implements prog M [encStreamParams P] body (encBank R.enc) (newBank P)
  fpSeed : AtIdx prog Idx.fpSeed fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → Implements prog M [encStreamParams P] body encN (fpSeedProg P)

/-! ## W4: the ADA module (fresh bits) -/

/-- The W4 contract: the parameter record, the initialization and the two interfaces of the bank ADA
instance `bankAda P`, for states satisfying the invariant and well-formed query tables. -/
structure W4Contract (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  adaPub : AtIdx prog Idx.adaPub fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → EvalsVal prog M [encStreamParams P] [] (.inl body) (R.pub (bankAda P))
  adaQA : AtIdx prog Idx.adaQA fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → EvalsVal prog M [encStreamParams P] [] (.inl body) (Val.int ((bankAda P).qA : ℤ))
  adaBlockSizes : AtIdx prog Idx.adaBlockSizes fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → EvalsVal prog M [encStreamParams P] [] (.inl body) (encL encN (bankAda P).blockSizes)
  adaInit : AtIdx prog Idx.adaInit fun body => ∀ P : StreamParams, ParamsOK P →
    Mv R P ≤ M → Implements prog M [R.pub (bankAda P)] body R.enc (adaInit (bankAda P))
  adaInterval : AtIdx prog Idx.adaInterval fun body =>
    ∀ (P : StreamParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ),
      ParamsOK P → R.ok P st → ValsOK P vals → QOK P l → QOK P u → Mv R P ≤ M →
      Implements prog M [Val.list [R.pub (bankAda P), R.enc st, encVals vals, encQ l, encQ u]] body
        (fun r => Val.list [encCert r.1, R.enc r.2]) (adaInterval (bankAda P) st vals l u)
  adaNumerical : AtIdx prog Idx.adaNumerical fun body =>
    ∀ (P : StreamParams) (st : AdaState) (vals : List (List ℕ)),
      ParamsOK P → R.ok P st → ValsOK P vals → Mv R P ≤ M →
      Implements prog M [Val.list [R.pub (bankAda P), R.enc st, encVals vals]] body
        (fun r => Val.list [encNum r.1, R.enc r.2]) (adaNumerical (bankAda P) st vals)

/-! ## W5: bank operations -/

/-- The W5 contract: the row operations mapped over a bank (deterministic), `ValidateInterval` and
`ReleaseNumerical` (fresh bits, through W4), for banks satisfying C-SPACE's `BankOK`. -/
structure W5Contract (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  resetYBank : AtIdx prog Idx.resetYBank fun body => ∀ (P : StreamParams) (B : Bank),
    ParamsOK P → BankOK P (R.ok P) B → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B]] [] (.inl body)
      (encBank R.enc (B.mapRows Row.resetY))
  addPhysBank : AtIdx prog Idx.addPhysBank fun body =>
    ∀ (P : StreamParams) (B : Bank) (i : ℕ) (Δ : ℤ),
      ParamsOK P → BankOK P (R.ok P) B → 1 ≤ i → i ≤ P.n → |Δ| ≤ 2 * (P.U : ℤ) → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN i, encZ Δ]] [] (.inl body)
        (encBank R.enc (B.mapRows (Row.addPhys P i Δ)))
  addGuardYBank : AtIdx prog Idx.addGuardYBank fun body =>
    ∀ (P : StreamParams) (B : Bank) (g : ℕ) (δ : ℤ),
      ParamsOK P → BankOK P (R.ok P) B → 1 ≤ g → g ≤ P.Dstar → |δ| ≤ 2 ^ regBits P → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]] [] (.inl body)
        (encBank R.enc (B.mapRows (Row.addGuardY P g δ)))
  addGuardXYBank : AtIdx prog Idx.addGuardXYBank fun body =>
    ∀ (P : StreamParams) (B : Bank) (g : ℕ) (δ : ℤ),
      ParamsOK P → BankOK P (R.ok P) B → 1 ≤ g → g ≤ P.Dstar → |δ| ≤ 2 ^ regBits P → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]] [] (.inl body)
        (encBank R.enc (B.mapRows (Row.addGuardXY P g δ)))
  scaleYBank : AtIdx prog Idx.scaleYBank fun body =>
    ∀ (P : StreamParams) (B : Bank) (cInt : ℤ),
      ParamsOK P → BankOK P (R.ok P) B → |cInt| ≤ 2 ^ (P.eHstep + 1) → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] [] (.inl body)
        (encBank R.enc (B.mapRows (Row.scaleY P cInt)))
  scaleXYBank : AtIdx prog Idx.scaleXYBank fun body =>
    ∀ (P : StreamParams) (B : Bank) (cInt : ℤ),
      ParamsOK P → BankOK P (R.ok P) B → |cInt| ≤ 2 ^ (P.eHstep + 1) → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] [] (.inl body)
        (encBank R.enc (B.mapRows (Row.scaleXY P cInt)))
  validate : AtIdx prog Idx.validate fun body =>
    ∀ (P : StreamParams) (B : Bank) (S θ : ℚ),
      ParamsOK P → BankOK P (R.ok P) B → 0 ≤ S → S ≤ (P.Amax : ℚ) → QOK P S → 0 < θ → θ ≤ 1 →
      (θ.den : ℤ) ≤ 2 ^ (2 * regBits P) → Mv R P ≤ M →
      Implements prog M [Val.list [encStreamParams P, encBank R.enc B, encQ S, encQ θ]] body
        (fun r => Val.list [encCert r.1, encBank R.enc r.2]) (B.validate P S θ)
  release : AtIdx prog Idx.release fun body =>
    ∀ (P : StreamParams) (B : Bank) (mode : Mode),
      ParamsOK P → BankOK P (R.ok P) B → Mv R P ≤ M →
      Implements prog M [Val.list [encStreamParams P, encBank R.enc B, encMode mode]] body
        (fun r => Val.list [encOptQ r.1, encBank R.enc r.2]) (B.release P mode)
  roundMantQ : AtIdx prog Idx.roundMantQ fun body => ∀ (P : StreamParams) (q : ℕ) (z : ℚ),
    ParamsOK P → q ≤ regBits P → QOK P z → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encN q, encQ z]] [] (.inl body) (Val.int (roundMant q z))
  guardMant : AtIdx prog Idx.guardMant fun body => ∀ (P : StreamParams) (Cint α e : ℤ),
    ParamsOK P → 0 ≤ Cint → Cint ≤ 2 ^ regBits P → |α| ≤ (regBits P : ℤ) → |e| ≤ (regBits P : ℤ) →
    Mv R P ≤ M →
    EvalsVal prog M [Val.list [encZ Cint, encZ α, encZ e]] [] (.inl body) (Val.int (guardMant Cint α e))
  stepCoeffMant : AtIdx prog Idx.stepCoeffMant fun body =>
    ∀ (P : StreamParams) (pos : Bool) (qη qs : ℕ) (Pval Qhat : ℚ),
      ParamsOK P → qη ≤ regBits P → qs ≤ regBits P → 0 < Pval → QOK P Pval → 0 < Qhat → QOK P Qhat →
      Mv R P ≤ M →
      EvalsVal prog M [Val.list [encB pos, encN qη, encN qs, encQ Pval, encQ Qhat]] [] (.inl body)
        (Val.int (stepCoeffMant pos qη qs Pval Qhat))
  rescaleLearner : AtIdx prog Idx.rescaleLearner fun body =>
    ∀ (P : StreamParams) (cInt : ℤ) (L : Learner),
      ParamsOK P → LearnerOK P 4 L → |cInt| ≤ 2 ^ (P.eHstep + 1) → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encZ cInt, encLearner L]] [] (.inl body)
        (encLearner (Learner.rescale P cInt L))
  countCorrection : AtIdx prog Idx.countCorrection fun body =>
    ∀ (P : StreamParams) (L : Learner), ParamsOK P → LearnerOK P 4 L → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encLearner L]] [] (.inl body)
        (encOptLearner (Learner.countCorrection P L))
  inRangeA : AtIdx prog Idx.inRangeA fun body => ∀ (P : StreamParams) (x : ℚ),
    ParamsOK P → QOK P x → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encQ x]] [] (.inl body) (encB (inRangeA P x))
  inRangeC : AtIdx prog Idx.inRangeC fun body => ∀ (P : StreamParams) (x : ℚ),
    ParamsOK P → QOK P x → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encQ x]] [] (.inl body) (encB (inRangeC P x))
  learnerInRange : AtIdx prog Idx.learnerInRange fun body => ∀ (P : StreamParams) (L : Learner),
    ParamsOK P → LearnerOK P 16 L → Mv R P ≤ M →
    EvalsVal prog M [Val.list [encStreamParams P, encLearner L]] [] (.inl body) (encB (L.inRange P))

/-! ## The shared utility `normQ` (implemented by W5) -/

/-- `normQ`: `[a, b] ↦ encQ (a / b)` for `b > 0` (W5 implements it; every package may call it). -/
def NormQSpec (prog : List Expr) (M : ℕ) : Prop :=
  AtIdx prog Idx.normQ fun body => ∀ a b : ℤ, 0 < b → 2 * (bitLen a + bitLen b) + 64 ≤ M →
    EvalsVal prog M [Val.list [Val.int a, Val.int b]] [] (.inl body) (encQ ((a : ℚ) / (b : ℚ)))

/-! ## All contracts -/

/-- Everything the tree controller (W6) assumes about the program. -/
structure Contracts (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  w1 : W1Contract R prog M
  w2 : W2Contract R prog M
  w3 : W3Contract R prog M
  w4 : W4Contract R prog M
  w5 : W5Contract R prog M
  normQ : NormQSpec prog M

/-! ## Calling a contracted routine -/

/-- **Call rule** (callee form ⇒ caller form): if the body at index `i` implements every `f a` on the
encoded argument, then `call i argE` implements `pA.bind f` whenever `argE` implements `pA`. -/
theorem implements_call {prog : List Expr} {M : ℕ} {env : List Val} {α β : Type} {argE : Expr}
    {encA : α → Val} {encB : β → Val} {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr}
    (hbody : prog[i]? = some body) (hA : Implements prog M env argE encA pA)
    (hf : ∀ a, Implements prog M [encA a] body encB (f a)) :
    Implements prog M env (Expr.call i argE) encB (pA.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.call (hA b₁ a h1) hbody (hf a b₂ c h2)

/-- **Call rule with a deterministic argument.** -/
theorem implements_call_det {prog : List Expr} {M : ℕ} {env : List Val} {β : Type} {argE : Expr}
    {x : Val} {encB : β → Val} {p : BitProg β} {i : ℕ} {body : Expr}
    (hbody : prog[i]? = some body) (hA : EvalsVal prog M env [] (.inl argE) x)
    (hf : Implements prog M [x] body encB p) :
    Implements prog M env (Expr.call i argE) encB p := by
  intro bits c h
  have := EvalsVal.call hA hbody (hf bits c h)
  simpa using this

/-- **Call rule for a deterministic routine.** -/
theorem evalsVal_call_det {prog : List Expr} {M : ℕ} {env : List Val} {argE : Expr} {x v : Val}
    {i : ℕ} {body : Expr} (hbody : prog[i]? = some body) (hA : EvalsVal prog M env [] (.inl argE) x)
    (hf : EvalsVal prog M [x] [] (.inl body) v) :
    EvalsVal prog M env [] (.inl (Expr.call i argE)) v := by
  simpa using EvalsVal.call hA hbody hf

end F2e2e.C.Impl
