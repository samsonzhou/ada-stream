import F2e2e.C.Impl.AdaPubBlocks

/-!
# The ADA parameter record: one block size and the loop over the blocks

* `body_apNB` (656): `[j, 4^j, A, p, J, R, χ, K₁, K₂, d_p] ↦ K₁ d ⌈√(C χ)⌉ + K₂` with the four caps
  around `j` (`apCap`), `C = C_j` (`apC`) and `d = ⌈√(p 4^j)⌉` for `j < p`, `d = d_p` for `j = p`;
  `apNB_ev` (values), `apNB_ada` (`= adaNBlock`);
* `body_apBStep` (654): the loop over `j = p, …, 0` (state
  `[k, acc, max acc, 4^k/4, A, p, J, R, χ, K₁, K₂, d_p]`, `j = k - 1`), `apB_loop`.
-/

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

/-! ## `body_apNB` (656) -/

/-- One block size; environment `[X]`, `X = [j, f, A, p, J, R, χ, K₁, K₂, d_p]`, `f = 4^j`. The
let-bound values are `T₀, T₁, T₂, T₃, C, cs, d`. -/
def body_apNB : Expr :=
  Expr.letE (Expr.call Cost.Idx.apCap (eList [eGet 2 (Expr.var 0),
    Expr.bin BinOp.div (eGet 1 (Expr.var 0)) (Expr.lit 16),
    Expr.bin BinOp.lt (Expr.lit 1) (eGet 0 (Expr.var 0))])) <|
  Expr.letE (Expr.call Cost.Idx.apCap (eList [eGet 2 (Expr.var 1),
    Expr.bin BinOp.div (eGet 1 (Expr.var 1)) (Expr.lit 4),
    Expr.bin BinOp.lt (Expr.lit 0) (eGet 0 (Expr.var 1))])) <|
  Expr.letE (Expr.call Cost.Idx.apCap (eList [eGet 2 (Expr.var 2), eGet 1 (Expr.var 2),
    Expr.bin BinOp.lt (eGet 0 (Expr.var 2)) (eGet 3 (Expr.var 2))])) <|
  Expr.letE (Expr.call Cost.Idx.apCap (eList [eGet 2 (Expr.var 3),
    Expr.bin BinOp.mul (Expr.lit 4) (eGet 1 (Expr.var 3)),
    Expr.bin BinOp.lt (Expr.bin BinOp.add (eGet 0 (Expr.var 3)) (Expr.lit 1))
      (eGet 3 (Expr.var 3))])) <|
  Expr.letE (Expr.call Cost.Idx.apC (eList [eGet 0 (Expr.var 4), eGet 3 (Expr.var 4),
    eGet 4 (Expr.var 4), eGet 5 (Expr.var 4), Expr.var 3, Expr.var 2, Expr.var 1, Expr.var 0])) <|
  Expr.letE (Expr.call Cost.Idx.apCeilSqrt (Expr.bin BinOp.mul (Expr.var 0) (eGet 6 (Expr.var 5)))) <|
  Expr.letE (Expr.ite (Expr.bin BinOp.lt (eGet 0 (Expr.var 6)) (eGet 3 (Expr.var 6)))
    (Expr.call Cost.Idx.apCeilSqrt (Expr.bin BinOp.mul (eGet 3 (Expr.var 6)) (eGet 1 (Expr.var 6))))
    (eGet 9 (Expr.var 6))) <|
  Expr.bin BinOp.add (Expr.bin BinOp.mul (Expr.bin BinOp.mul (eGet 7 (Expr.var 7)) (Expr.var 0))
    (Expr.var 1)) (eGet 8 (Expr.var 7))

/-- The library routines and helpers used by the block computation. -/
structure BlkLib (prog : List Expr) : Prop where
  apCap : prog[Cost.Idx.apCap]? = some body_apCap
  apC : prog[Cost.Idx.apC]? = some body_apC
  apCeilSqrt : prog[Cost.Idx.apCeilSqrt]? = some body_apCeilSqrt
  apNB : prog[Cost.Idx.apNB]? = some body_apNB
  natSqrt : prog[Cost.Idx.natSqrt]? = some body_natSqrt
  natSqrtStep : prog[Cost.Idx.natSqrtStep]? = some body_natSqrtStep

/-- The value of `body_apNB` on `[j, 4^j, A, p, J, R, χ, K₁, K₂, d_p]`. -/
def nbV (j A p J R χ K1 K2 dp : ℕ) : ℕ :=
  K1 * (if j < p then ceilSqrt (p * 2 ^ (2 * j)) else dp) *
    ceilSqrt (cV j p J R (capV A (2 ^ (2 * j) / 16) (decide (1 < j)))
      (capV A (2 ^ (2 * j) / 4) (decide (0 < j))) (capV A (2 ^ (2 * j)) (decide (j < p)))
      (capV A (4 * 2 ^ (2 * j)) (decide (j + 1 < p))) * χ) + K2

theorem capV_le {A g : ℕ} {b : Bool} (hA : 1 ≤ A) (hg : b = true → 1 ≤ g) : capV A g b ≤ A := by
  unfold capV
  cases b
  · simp
  · simpa using ceilDiv_le_self hA (hg rfl)

theorem cV_le (j p J R t0 t1 t2 t3 : ℕ) :
    cV j p J R t0 t1 t2 t3 ≤ 2 * (t0 + t1 + t2 + t3) + J + R + 2 := by
  unfold cV
  split_ifs <;> omega

section

variable {prog : List Expr} {M : ℕ}

theorem apNB_ev (hL : BlkLib prog) {j A p J R χ K1 K2 dp W : ℕ} (hA1 : 1 ≤ A)
    (hj : j < 2 ^ W) (hf : 2 ^ (2 * j) < 2 ^ W) (hA : A < 2 ^ W) (hp : p < 2 ^ W)
    (hJ : J < 2 ^ W) (hR : R < 2 ^ W) (hχ : χ < 2 ^ W) (hK1 : K1 < 2 ^ W) (hK2 : K2 < 2 ^ W)
    (hdp : dp < 2 ^ W) (hM : 60 * W + 300 ≤ M) :
    EvalsVal prog M [Val.list [encN j, encN (2 ^ (2 * j)), encN A, encN p, encN J, encN R,
      encN χ, encN K1, encN K2, encN dp]] [] (.inl body_apNB) (encN (nbV j A p J R χ K1 K2 dp)) := by
  set f := 2 ^ (2 * j) with hfd
  set X := Val.list [encN j, encN f, encN A, encN p, encN J, encN R, encN χ, encN K1, encN K2,
    encN dp] with hXd
  have sj := size_le_of_lt_pow hj
  have sf := size_le_of_lt_pow hf
  have sA := size_le_of_lt_pow hA
  have sp := size_le_of_lt_pow hp
  have sJ := size_le_of_lt_pow hJ
  have sR := size_le_of_lt_pow hR
  have sχ := size_le_of_lt_pow hχ
  have sK1 := size_le_of_lt_pow hK1
  have sK2 := size_le_of_lt_pow hK2
  have sdp := size_le_of_lt_pow hdp
  have hX : valSize X ≤ M := by
    simp only [hXd, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have getX : ∀ (env : List Val) (k i : ℕ) (v : Val), env[k]? = some X →
      [encN j, encN f, encN A, encN p, encN J, encN R, encN χ, encN K1, encN K2, encN dp][i]? =
        some v → EvalsVal prog M env [] (.inl (eGet i (Expr.var k))) v :=
    fun env k i v hk hi => ev_get i (EvalsVal.var hk) hX hi
  have hf1 : 1 ≤ f := Nat.one_le_two_pow
  have h4 : Nat.size 4 ≤ 3 := Nat.size_le.2 (by norm_num)
  have h16 : Nat.size 16 ≤ 5 := Nat.size_le.2 (by norm_num)
  have hlit : ∀ (env : List Val) (n : ℕ), Nat.size n ≤ 5 →
      EvalsVal prog M env [] (.inl (Expr.lit (n : ℤ))) (encN n) :=
    fun env n hn => evN_lit n (by omega)
  -- sizes of the caps
  have hcapArg : ∀ (g : ℕ) (b : Bool), Nat.size g ≤ W + 3 →
      valSize (Val.list [encN A, encN g, encB b]) ≤ M := by
    intro g b hg
    have hb1 : bitLen (if b then (1 : ℤ) else 0) ≤ 1 := by cases b <;> simp
    simp only [encB, valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
    omega
  -- T₀
  set t0 := capV A (f / 16) (decide (1 < j)) with ht0
  have hf16 : (decide (1 < j)) = true → 1 ≤ f / 16 := by
    intro h
    have hj1 : 1 < j := by simpa using h
    obtain ⟨i, rfl⟩ : ∃ i, j = i + 2 := ⟨j - 2, by omega⟩
    have : f = 2 ^ (2 * i) * 16 := by
      rw [hfd, show 2 * (i + 2) = 2 * i + 4 by ring, pow_add]; norm_num
    rw [this, Nat.mul_div_cancel _ (by norm_num)]
    exact Nat.one_le_two_pow
  have sf16 : Nat.size (f / 16) ≤ W := (size_le_of_le (Nat.div_le_self _ _)).trans sf
  have eT0 : EvalsVal prog M [X] [] (.inl (Expr.call Cost.Idx.apCap (eList [eGet 2 (Expr.var 0),
      Expr.bin BinOp.div (eGet 1 (Expr.var 0)) (Expr.lit 16),
      Expr.bin BinOp.lt (Expr.lit 1) (eGet 0 (Expr.var 0))]))) (encN t0) :=
    ev_call hL.apCap (ev_list (.cons (getX _ 0 2 _ rfl rfl)
      (.cons (evN_div (getX _ 0 1 _ rfl rfl) (hlit _ 16 h16) (by norm_num) (by omega))
      (.cons (evN_ltB (hlit _ 1 (by simp)) (getX _ 0 0 _ rfl rfl) (by omega)) .nil)))
      (hcapArg _ _ (by omega))) (apCap_ev hf16 (by omega))
  refine ev_letE eT0 ?_
  -- T₁
  set t1 := capV A (f / 4) (decide (0 < j)) with ht1
  have hf4 : (decide (0 < j)) = true → 1 ≤ f / 4 := by
    intro h
    have hj1 : 0 < j := by simpa using h
    obtain ⟨i, rfl⟩ : ∃ i, j = i + 1 := ⟨j - 1, by omega⟩
    rw [hfd, four_pow_div_four]
    exact Nat.one_le_two_pow
  have sf4 : Nat.size (f / 4) ≤ W := (size_le_of_le (Nat.div_le_self _ _)).trans sf
  have eT1 : EvalsVal prog M [encN t0, X] [] (.inl (Expr.call Cost.Idx.apCap
      (eList [eGet 2 (Expr.var 1), Expr.bin BinOp.div (eGet 1 (Expr.var 1)) (Expr.lit 4),
        Expr.bin BinOp.lt (Expr.lit 0) (eGet 0 (Expr.var 1))]))) (encN t1) :=
    ev_call hL.apCap (ev_list (.cons (getX _ 1 2 _ rfl rfl)
      (.cons (evN_div (getX _ 1 1 _ rfl rfl) (hlit _ 4 (by omega)) (by norm_num) (by omega))
      (.cons (evN_ltB (hlit _ 0 (by simp)) (getX _ 1 0 _ rfl rfl) (by omega)) .nil)))
      (hcapArg _ _ (by omega))) (apCap_ev hf4 (by omega))
  refine ev_letE eT1 ?_
  -- T₂
  set t2 := capV A f (decide (j < p)) with ht2
  have eT2 : EvalsVal prog M [encN t1, encN t0, X] [] (.inl (Expr.call Cost.Idx.apCap
      (eList [eGet 2 (Expr.var 2), eGet 1 (Expr.var 2),
        Expr.bin BinOp.lt (eGet 0 (Expr.var 2)) (eGet 3 (Expr.var 2))]))) (encN t2) :=
    ev_call hL.apCap (ev_list (.cons (getX _ 2 2 _ rfl rfl)
      (.cons (getX _ 2 1 _ rfl rfl)
      (.cons (evN_ltB (getX _ 2 0 _ rfl rfl) (getX _ 2 3 _ rfl rfl) (by omega)) .nil)))
      (hcapArg _ _ (by omega))) (apCap_ev (fun _ => hf1) (by omega))
  refine ev_letE eT2 ?_
  -- T₃
  set t3 := capV A (4 * f) (decide (j + 1 < p)) with ht3
  have s4f : Nat.size (4 * f) ≤ W + 3 := (size_mul_le 4 f).trans (by omega)
  have hj1 : Nat.size (j + 1) ≤ W + 1 := (size_succ_le j).trans (by omega)
  have eT3 : EvalsVal prog M [encN t2, encN t1, encN t0, X] [] (.inl (Expr.call Cost.Idx.apCap
      (eList [eGet 2 (Expr.var 3), Expr.bin BinOp.mul (Expr.lit 4) (eGet 1 (Expr.var 3)),
        Expr.bin BinOp.lt (Expr.bin BinOp.add (eGet 0 (Expr.var 3)) (Expr.lit 1))
          (eGet 3 (Expr.var 3))]))) (encN t3) :=
    ev_call hL.apCap (ev_list (.cons (getX _ 3 2 _ rfl rfl)
      (.cons (evN_mul (hlit _ 4 (by omega)) (getX _ 3 1 _ rfl rfl) (by omega))
      (.cons (evN_ltB (evN_add (getX _ 3 0 _ rfl rfl) (hlit _ 1 (by simp)) (by omega))
        (getX _ 3 3 _ rfl rfl) (by omega)) .nil)))
      (hcapArg _ _ (by omega))) (apCap_ev (fun _ => by omega) (by omega))
  refine ev_letE eT3 ?_
  -- C
  have ht0A : t0 ≤ A := capV_le hA1 hf16
  have ht1A : t1 ≤ A := capV_le hA1 hf4
  have ht2A : t2 ≤ A := capV_le hA1 (fun _ => hf1)
  have ht3A : t3 ≤ A := capV_le hA1 (fun _ => by omega)
  set C := cV j p J R t0 t1 t2 t3 with hC
  have eC : EvalsVal prog M [encN t3, encN t2, encN t1, encN t0, X] [] (.inl (Expr.call
      Cost.Idx.apC (eList [eGet 0 (Expr.var 4), eGet 3 (Expr.var 4), eGet 4 (Expr.var 4),
        eGet 5 (Expr.var 4), Expr.var 3, Expr.var 2, Expr.var 1, Expr.var 0]))) (encN C) := by
    have st0 := size_le_of_le ht0A
    have st1 := size_le_of_le ht1A
    have st2 := size_le_of_le ht2A
    have st3 := size_le_of_le ht3A
    refine ev_call hL.apC (ev_list (.cons (getX _ 4 0 _ rfl rfl) (.cons (getX _ 4 3 _ rfl rfl)
      (.cons (getX _ 4 4 _ rfl rfl) (.cons (getX _ 4 5 _ rfl rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))))))))
      ?_) (apC_ev hj hp hJ hR (by omega) (by omega) (by omega) (by omega) (by omega))
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  refine ev_letE eC ?_
  -- cs = ⌈√(C χ)⌉
  have hCle : C ≤ 2 * (t0 + t1 + t2 + t3) + J + R + 2 := cV_le _ _ _ _ _ _ _ _
  have hC8 : C < 2 ^ (W + 4) := by
    rw [pow_add]
    omega
  have sC : Nat.size C ≤ W + 4 := size_le_of_lt_pow hC8
  have sCχ : Nat.size (C * χ) ≤ 2 * W + 4 := (size_mul_le C χ).trans (by omega)
  set cs := ceilSqrt (C * χ) with hcs
  have ecs : EvalsVal prog M [encN C, encN t3, encN t2, encN t1, encN t0, X] []
      (.inl (Expr.call Cost.Idx.apCeilSqrt (Expr.bin BinOp.mul (Expr.var 0)
        (eGet 6 (Expr.var 5))))) (encN cs) :=
    ev_call hL.apCeilSqrt (evN_mul (EvalsVal.var rfl) (getX _ 5 6 _ rfl rfl) (by omega))
      (apCeilSqrt_ev hL.natSqrt hL.natSqrtStep _ (by omega))
  refine ev_letE ecs ?_
  -- d
  have spf : Nat.size (p * f) ≤ 2 * W := (size_mul_le p f).trans (by omega)
  set d := if j < p then ceilSqrt (p * f) else dp with hd
  have sd : Nat.size d ≤ 2 * W + 1 := by
    rw [hd]
    split_ifs
    · exact (size_le_of_le (ceilSqrt_le_succ _)).trans ((size_succ_le _).trans (by omega))
    · omega
  have ed : EvalsVal prog M [encN cs, encN C, encN t3, encN t2, encN t1, encN t0, X] []
      (.inl (Expr.ite (Expr.bin BinOp.lt (eGet 0 (Expr.var 6)) (eGet 3 (Expr.var 6)))
        (Expr.call Cost.Idx.apCeilSqrt (Expr.bin BinOp.mul (eGet 3 (Expr.var 6))
          (eGet 1 (Expr.var 6)))) (eGet 9 (Expr.var 6)))) (encN d) := by
    by_cases hjp : j < p
    · have e : d = ceilSqrt (p * f) := by rw [hd, if_pos hjp]
      rw [e]
      exact ev_ite_true (evN_lt_true (getX _ 6 0 _ rfl rfl) (getX _ 6 3 _ rfl rfl) hjp (by omega))
        (ev_call hL.apCeilSqrt (evN_mul (getX _ 6 3 _ rfl rfl) (getX _ 6 1 _ rfl rfl) (by omega))
          (apCeilSqrt_ev hL.natSqrt hL.natSqrtStep _ (by omega)))
    · have e : d = dp := by rw [hd, if_neg hjp]
      rw [e]
      exact ev_ite_false (evN_lt_false (getX _ 6 0 _ rfl rfl) (getX _ 6 3 _ rfl rfl) hjp (by omega))
        (getX _ 6 9 _ rfl rfl)
  refine ev_letE ed ?_
  -- n = K₁ d cs + K₂
  have scs : Nat.size cs ≤ 2 * W + 5 :=
    (size_le_of_le (ceilSqrt_le_succ _)).trans ((size_succ_le _).trans (by omega))
  have sK1d : Nat.size (K1 * d) ≤ 3 * W + 1 := (size_mul_le K1 d).trans (by omega)
  have sK1dc : Nat.size (K1 * d * cs) ≤ 5 * W + 6 := (size_mul_le _ cs).trans (by omega)
  have sn : Nat.size (K1 * d * cs + K2) ≤ 5 * W + 7 := (size_add_le _ _).trans (by omega)
  have hval : nbV j A p J R χ K1 K2 dp = K1 * d * cs + K2 := rfl
  rw [hval]
  exact evN_add (evN_mul (evN_mul (getX _ 7 7 _ rfl rfl) (EvalsVal.var rfl) (by omega))
    (EvalsVal.var rfl) (by omega)) (getX _ 7 8 _ rfl rfl) (by omega)

end

/-- For the ADA parameters, `nbV` is the block size `n_j` (`j ≤ p`). -/
theorem nbV_ada (Mc J R eA eXi j : ℕ) (hj : j ≤ adaP eA) :
    nbV j (tmA eA) (adaP eA) J R (adaChi Mc J R eA eXi)
      (1048576 * adaChi Mc J R eA eXi * adaHInv eA)
      (4096 * adaChi Mc J R eA eXi * (adaHInv eA * adaHInv eA)) (2 ^ (eA + 11) * adaP eA) =
      adaNBlock Mc J R eA eXi j := by
  rw [adaNBlock_eq, adaD_eq, adaC_eq_cV J R eA j hj, ← capV_tmax_pred2 eA j hj,
    ← capV_tmax_pred eA j hj, ← capV_tmax eA j, ← capV_tmax_succ eA j]
  unfold nbV
  ring

end F2e2e.C.Impl.AP
