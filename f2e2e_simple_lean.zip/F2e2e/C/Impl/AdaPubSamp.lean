import F2e2e.C.Impl.AdaPubBLoop

/-!
# The ADA parameter record: the sampler parameters of one noise kind

`body_apSamp` (657): `[2^{q_A}, m, B_0, Z_d] ↦ [K_s, r_s, ϱ.num, ϱ.den, ⌈log₂ ϱ.den⌉]` for the noise
scale `b = 1/m` (`K_s = ((2^{q_A} + m) B_0 + m - 1)/m`, `r_s = ⌈log₂(32 (K_s + 1) Z_d)⌉`,
`ϱ = 2^{q_A}/(2^{q_A} + m)` reduced by W5's `normQ`); `apSamp_ev`, and `sampV_eq`: for the ADA
parameters these are `samplerParams A κ` (`F2e2e/C/Impl/AdaRep.lean`).
-/

namespace F2e2e.Cost.Idx

/-- `adaPub` helper: the sampler parameters of one noise kind. -/
abbrev apSamp : ℕ := 657

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

/-! ## Reference values -/

/-- `ϱ = 2^{q_A}/(2^{q_A} + m)` as computed by `normQ`. -/
def rhoQ (q2 m : ℕ) : ℚ := ((q2 : ℤ) : ℚ) / (((q2 + m : ℕ) : ℤ) : ℚ)

/-- `K_s = ⌈(2^{q_A} + m) B_0 / m⌉`. -/
def ksV (q2 m B0 : ℕ) : ℕ := ((q2 + m) * B0 + m - 1) / m

/-- The sampler parameters `[K_s, r_s, ϱ.num, ϱ.den, ⌈log₂ ϱ.den⌉]`. -/
def sampV (q2 m B0 Zd : ℕ) : List ℕ :=
  [ksV q2 m B0, Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd), (rhoQ q2 m).num.toNat, (rhoQ q2 m).den,
    Nat.clog 2 (rhoQ q2 m).den]

theorem rhoQ_num_le (q2 m : ℕ) (hs : 0 < q2 + m) : (rhoQ q2 m).num ≤ q2 := by
  unfold rhoQ
  have hb : (0 : ℤ) < ((q2 + m : ℕ) : ℤ) := by exact_mod_cast hs
  rw [← Rat.divInt_eq_div]
  by_cases ha : (q2 : ℤ) = 0
  · rw [ha]; simp
  · have hd := Rat.num_dvd (q2 : ℤ) (ne_of_gt hb)
    have := Int.natAbs_le_of_dvd_ne_zero hd ha
    have h2 := Int.le_natAbs (a := (Rat.divInt (q2 : ℤ) ((q2 + m : ℕ) : ℤ)).num)
    simp only [Int.natAbs_natCast] at this
    omega

theorem rhoQ_num_nonneg (q2 m : ℕ) : 0 ≤ (rhoQ q2 m).num := by
  unfold rhoQ
  apply Rat.num_nonneg.2
  positivity

theorem rhoQ_den_le (q2 m : ℕ) (hs : 0 < q2 + m) : (rhoQ q2 m).den ≤ q2 + m := by
  unfold rhoQ
  have hb : (0 : ℤ) < ((q2 + m : ℕ) : ℤ) := by exact_mod_cast hs
  rw [← Rat.divInt_eq_div]
  have h := Int.le_of_dvd hb (Rat.den_dvd (q2 : ℤ) ((q2 + m : ℕ) : ℤ))
  exact_mod_cast h

theorem ksV_le (q2 m B0 : ℕ) : ksV q2 m B0 ≤ (q2 + m) * B0 + m := by
  unfold ksV
  exact (Nat.div_le_self _ _).trans (Nat.sub_le _ _)

/-! ## The routine -/

/-- The sampler parameters; environment `[X]`, `X = [q2, m, B0, Zd]`; let-bound `s = q2 + m`, `K_s`,
`r_s`, `r = encQ ϱ`. -/
def body_apSamp : Expr :=
  Expr.letE (Expr.bin BinOp.add (eGet 0 (Expr.var 0)) (eGet 1 (Expr.var 0))) <|
  Expr.letE (Expr.bin BinOp.div (Expr.bin BinOp.sub (Expr.bin BinOp.add
      (Expr.bin BinOp.mul (Expr.var 0) (eGet 2 (Expr.var 1))) (eGet 1 (Expr.var 1))) (Expr.lit 1))
      (eGet 1 (Expr.var 1))) <|
  Expr.letE (Expr.call Cost.Idx.clog2 (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 32)
      (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1))) (eGet 3 (Expr.var 2)))) <|
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.normQ (eList [eGet 0 (Expr.var 3), Expr.var 2])) <|
  eList [Expr.var 2, Expr.var 1, eGet 0 (Expr.var 0), eGet 1 (Expr.var 0),
    Expr.call Cost.Idx.clog2 (eGet 1 (Expr.var 0))]

section

variable {prog : List Expr} {M : ℕ}

theorem apSamp_ev (hq : NormQSpec prog M) (hc0 : prog[Cost.Idx.clog2]? = some body_clog2)
    (hc1 : prog[Cost.Idx.clog2Step]? = some body_clog2Step) {q2 m B0 Zd W : ℕ} (hm : 1 ≤ m)
    (hq2W : q2 < 2 ^ W) (hmW : m < 2 ^ W) (hB0 : B0 < 2 ^ W) (hZd : Zd < 2 ^ W)
    (hM : 80 * W + 400 ≤ M) :
    EvalsVal prog M [Val.list [encN q2, encN m, encN B0, encN Zd]] [] (.inl body_apSamp)
      (encL encN (sampV q2 m B0 Zd)) := by
  set X := Val.list [encN q2, encN m, encN B0, encN Zd] with hXd
  have sq := size_le_of_lt_pow hq2W
  have sm := size_le_of_lt_pow hmW
  have sB := size_le_of_lt_pow hB0
  have sZ := size_le_of_lt_pow hZd
  have hX : valSize X ≤ M := by
    simp only [hXd, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have getX : ∀ (env : List Val) (k i : ℕ) (v : Val), env[k]? = some X →
      [encN q2, encN m, encN B0, encN Zd][i]? = some v →
        EvalsVal prog M env [] (.inl (eGet i (Expr.var k))) v :=
    fun env k i v hk hi => ev_get i (EvalsVal.var hk) hX hi
  have hlit : ∀ (env : List Val) (n : ℕ), Nat.size n ≤ 6 →
      EvalsVal prog M env [] (.inl (Expr.lit (n : ℤ))) (encN n) :=
    fun env n hn => evN_lit n (by omega)
  -- s = q2 + m
  have ss : Nat.size (q2 + m) ≤ W + 1 := (size_add_le _ _).trans (by omega)
  refine ev_letE (evN_add (getX [X] 0 0 _ rfl rfl) (getX [X] 0 1 _ rfl rfl) (by omega)) ?_
  -- K_s
  have ssB : Nat.size ((q2 + m) * B0) ≤ 2 * W + 1 := (size_mul_le _ _).trans (by omega)
  have ssBm : Nat.size ((q2 + m) * B0 + m) ≤ 2 * W + 2 := (size_add_le _ _).trans (by omega)
  have hKsle := ksV_le q2 m B0
  have sKs : Nat.size (ksV q2 m B0) ≤ 2 * W + 2 := (size_le_of_le hKsle).trans ssBm
  have eKs : EvalsVal prog M [encN (q2 + m), X] [] (.inl (Expr.bin BinOp.div (Expr.bin BinOp.sub
      (Expr.bin BinOp.add (Expr.bin BinOp.mul (Expr.var 0) (eGet 2 (Expr.var 1)))
        (eGet 1 (Expr.var 1))) (Expr.lit 1)) (eGet 1 (Expr.var 1)))) (encN (ksV q2 m B0)) := by
    refine evN_div (evN_sub (evN_add (evN_mul (EvalsVal.var rfl) (getX _ 1 2 _ rfl rfl)
      (by omega)) (getX _ 1 1 _ rfl rfl) (by omega)) (hlit _ 1 (by simp)) (by omega) (by omega))
      (getX _ 1 1 _ rfl rfl) (by omega) ?_
    have := size_le_of_le (Nat.sub_le ((q2 + m) * B0 + m) 1)
    omega
  refine ev_letE eKs ?_
  -- r_s
  have sK1 : Nat.size (ksV q2 m B0 + 1) ≤ 2 * W + 3 := (size_succ_le _).trans (by omega)
  have h32 : Nat.size 32 ≤ 6 := Nat.size_le.2 (by norm_num)
  have s32K : Nat.size (32 * (ksV q2 m B0 + 1)) ≤ 2 * W + 9 := (size_mul_le _ _).trans (by omega)
  have s32KZ : Nat.size (32 * (ksV q2 m B0 + 1) * Zd) ≤ 3 * W + 9 :=
    (size_mul_le _ _).trans (by omega)
  have ers : EvalsVal prog M [encN (ksV q2 m B0), encN (q2 + m), X] [] (.inl (Expr.call
      Cost.Idx.clog2 (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 32)
        (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1))) (eGet 3 (Expr.var 2)))))
      (encN (Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd))) :=
    clog2_ev hc0 hc1 (evN_mul (evN_mul (hlit _ 32 h32) (evN_add (EvalsVal.var rfl)
      (hlit _ 1 (by simp)) (by omega)) (by omega)) (getX _ 2 3 _ rfl rfl) (by omega))
      (by simp only [S_clog2]; omega)
  refine ev_letE ers ?_
  -- r = encQ ϱ
  have hs0 : 0 < q2 + m := by omega
  have bq : bitLen (q2 : ℤ) ≤ W := by rw [bitLen_natCast]; exact sq
  have bs : bitLen ((q2 + m : ℕ) : ℤ) ≤ W + 1 := by rw [bitLen_natCast]; exact ss
  have er : EvalsVal prog M [encN (Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd)), encN (ksV q2 m B0),
      encN (q2 + m), X] [] (.inl (Expr.call F2e2e.C.Impl.Idx.normQ
        (eList [eGet 0 (Expr.var 3), Expr.var 2]))) (encQ (rhoQ q2 m)) := by
    refine normQ_ev hq (ev_list (.cons (getX _ 3 0 _ rfl rfl) (.cons (EvalsVal.var rfl) .nil))
      ?_) (by exact_mod_cast hs0) (by omega)
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int,
      bitLen_natCast]
    omega
  refine ev_letE er ?_
  -- the result
  set ρ := rhoQ q2 m with hρ
  have hnum0 := rhoQ_num_nonneg q2 m
  have hnumle := rhoQ_num_le q2 m hs0
  have hdenle := rhoQ_den_le q2 m hs0
  have snum : Nat.size ρ.num.toNat ≤ W := by
    have : ρ.num.toNat ≤ q2 := Int.toNat_le.2 hnumle
    exact (size_le_of_le this).trans sq
  have sden : Nat.size ρ.den ≤ W + 1 := (size_le_of_le hdenle).trans ss
  have bnum : bitLen ρ.num ≤ W := by
    have e : ρ.num = ((ρ.num.toNat : ℕ) : ℤ) := (Int.toNat_of_nonneg hnum0).symm
    rw [e, bitLen_natCast]; exact snum
  have hr : valSize (encQ ρ) ≤ M := by
    simp only [encQ, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
    omega
  have hv0 : EvalsVal prog M [encQ ρ, encN (Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd)),
      encN (ksV q2 m B0), encN (q2 + m), X] [] (.inl (Expr.var 0)) (encQ ρ) := EvalsVal.var rfl
  have r0 := ev_cast (ev_get 0 hv0 hr (v := Val.int ρ.num) rfl)
    (show Val.int ρ.num = encN ρ.num.toNat by
      simp only [encN]; rw [Int.toNat_of_nonneg hnum0])
  have r1 := ev_get 1 hv0 hr (v := encN ρ.den) rfl
  have scl : Nat.size (Nat.clog 2 ρ.den) ≤ W + 1 :=
    (size_le_of_le ((clog2_le_size _).trans (size_le_self' _))).trans (by omega)
  have scr : Nat.size (Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd)) ≤ 3 * W + 9 :=
    (size_le_of_le ((clog2_le_size _).trans (size_le_self' _))).trans s32KZ
  have rcl := clog2_ev hc0 hc1 r1 (by simp only [S_clog2]; omega)
  have hout : encL encN (sampV q2 m B0 Zd) = Val.list [encN (ksV q2 m B0),
      encN (Nat.clog 2 (32 * (ksV q2 m B0 + 1) * Zd)), encN ρ.num.toNat, encN ρ.den,
      encN (Nat.clog 2 ρ.den)] := rfl
  rw [hout]
  refine ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons r0 (.cons r1
    (.cons rcl .nil))))) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

end

/-- For the ADA parameters, `sampV` is `samplerParams A κ`. -/
theorem sampV_eq (eA eXi Mc J R : ℕ) (κ : NoiseKind) :
    sampV (2 ^ (adaParams eA eXi Mc J R).qA) (mK Mc J R eA eXi κ) (adaB0 Mc J R eA eXi)
      (zdQ Mc J R eA eXi) = samplerParams (adaParams eA eXi Mc J R) κ := by
  have hm := mK_pos Mc J R eA eXi κ
  have hz : (adaParams eA eXi Mc J R).zeta = 1 / ((zdQ Mc J R eA eXi : ℕ) : ℚ) :=
    adaZeta_eq Mc J R eA eXi
  have hB : (adaParams eA eXi Mc J R).B0 = adaB0 Mc J R eA eXi := rfl
  have hrho : rhoQ (2 ^ (adaParams eA eXi Mc J R).qA) (mK Mc J R eA eXi κ) =
      (adaParams eA eXi Mc J R).rho ((adaParams eA eXi Mc J R).scale κ) := by
    rw [scale_eq, rho_eq _ hm]
    unfold rhoQ
    push_cast
    ring
  have hKs : ksV (2 ^ (adaParams eA eXi Mc J R).qA) (mK Mc J R eA eXi κ) (adaB0 Mc J R eA eXi) =
      (adaParams eA eXi Mc J R).Ks ((adaParams eA eXi Mc J R).scale κ) := by
    rw [scale_eq, Ks_eq _ hm, hB]
    rfl
  have hrs : (adaParams eA eXi Mc J R).rs ((adaParams eA eXi Mc J R).scale κ) =
      Nat.clog 2 (32 * ((adaParams eA eXi Mc J R).Ks ((adaParams eA eXi Mc J R).scale κ) + 1) *
        zdQ Mc J R eA eXi) := rs_eq _ _ hz
  unfold sampV samplerParams
  rw [hrho, hKs, hrs]

end F2e2e.C.Impl.AP
