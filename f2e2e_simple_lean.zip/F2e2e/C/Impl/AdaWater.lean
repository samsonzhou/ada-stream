import F2e2e.C.Impl.AdaInit
import F2e2e.C.Impl.AdaWaterMath

/-!
# ADA module (W4), part 6: the water level in the DSL

Routines (Idx 621–630):

| idx | routine | input | output |
|---|---|---|---|
| 621/622/623 | `wlFKFold` (fold of `fkStep`) | `[[F, k], g, [B, cn, cd]]` | `[F', k']` |
| 624/625/626 | `wlMassFold` (fold of `massStep`) | `[m, g, [N, D, cn, cd]]` | `m'` |
| 627 | `wlTryR` | `[B, g, cn, cd, n]` | `encOptPair (wlTry cn cd g B)` |
| 628/629/630 | `wlLevelFold` (fold of `wlStep`) | `[s, l, [g, cn, cd, n]]` | `encOptPair (foldP …)` |

The folds use the library loop body `body_foldBStep` (`F2e2e/Cost/Lib/BitFold.lean`) with a fold lemma
`foldP_val'` whose invariant may depend on the remaining list. Arithmetic is compiled with `ZE`
(`AdaFrame.lean`); `ZE.cb` is a crude (max-free) bound of `ZE.mx`.
-/

namespace F2e2e.Cost.Idx

abbrev wlFKFold : ℕ := 621
abbrev wlFKStep : ℕ := 622
abbrev wlFKEl : ℕ := 623
abbrev wlMassFold : ℕ := 624
abbrev wlMassStep : ℕ := 625
abbrev wlMassEl : ℕ := 626
abbrev wlTryR : ℕ := 627
abbrev wlLevelFold : ℕ := 628
abbrev wlLevelStep : ℕ := 629
abbrev wlLevelEl : ℕ := 630

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section Frame2

variable {prog : List Expr} {M : ℕ}

/-! ## A deterministic fold with a position-dependent invariant -/

theorem foldP_val' {α σ : Type} {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (g : α → σ → σ) (P : List α → σ → Prop)
    (VS : ℕ) (l : List α)
    (hG : ∀ x r s, (x :: r) <:+ l → P (x :: r) s →
      EvalsVal prog M [Val.list [encA x, encS s, extra]] [] (.inl bodyF) (encS (g x s)) ∧
        P r (g x s))
    (hV : ∀ r s, r <:+ l → P r s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) :
    ∀ r, r <:+ l → ∀ s, P r s →
      EvalsVal prog M [] [] (.inr (iStep, Val.list [encS s, encL encA r, extra]))
        (encS (foldP g r s)) := by
  intro r
  induction r with
  | nil =>
    intro hsuf s hs
    have hVs := hV [] s hsuf hs
    have hL := valSize_encL_ge encA l
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil]
    exact foldBStep_nil_val iF (encS s) extra
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  | cons x r ih =>
    intro hsuf s hs
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨hcall, hs'⟩ := hG x r s hsuf hs
    have hrest := ih hsuf' (g x s) hs'
    have hVs := hV _ s hsuf hs
    have hVs' := hV r (g x s) hsuf' hs'
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hbody := foldBStep_cons_val (R := r.map encA) hF hcall
      (by simp only [encL, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hR hM ⊢
          omega)
    have := EvalsVal.cont hstep hbody one_ne_zero hrest
    simpa [foldP] using this

/-- **The fold, as a body**: input `[encS s, encL encA l, extra]`. -/
theorem foldP_body' {α σ : Type} {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (g : α → σ → σ) (P : List α → σ → Prop)
    (VS : ℕ) (l : List α)
    (hG : ∀ x r s, (x :: r) <:+ l → P (x :: r) s →
      EvalsVal prog M [Val.list [encA x, encS s, extra]] [] (.inl bodyF) (encS (g x s)) ∧
        P r (g x s))
    (hV : ∀ r s, r <:+ l → P r s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : P l s) :
    EvalsVal prog M [Val.list [encS s, encL encA l, extra]] [] (.inl (body_foldB iStep))
      (encS (foldP g l s)) := by
  have := EvalsVal.loop (EvalsVal.var0 (v := Val.list [encS s, encL encA l, extra]) (rest := []))
    (foldP_val' hstep hF encA encS extra g P VS l hG hV hM l (List.suffix_refl l) s hs)
  simpa [body_foldB] using this

/-! ## Crude bounds of integer expressions -/

namespace ZE

/-- A max-free bound of `mx` when every leaf has at most `W` bits. -/
def cb (W : ℕ) : ZE → ℕ
  | leaf _ _ => W
  | lit z => bitLen z
  | add a b => a.cb W + b.cb W + 1
  | sub a b => a.cb W + b.cb W + 1
  | mul a b => a.cb W + b.cb W
  | div a b => a.cb W + b.cb W
  | lt a b => a.cb W + b.cb W + 1
  | eq a b => a.cb W + b.cb W + 1
  | cnd c t f => c.cb W + t.cb W + f.cb W

/-- Every leaf has at most `W` bits. -/
def LeafLe (W : ℕ) : ZE → Prop
  | leaf _ z => bitLen z ≤ W
  | lit _ => True
  | add a b => a.LeafLe W ∧ b.LeafLe W
  | sub a b => a.LeafLe W ∧ b.LeafLe W
  | mul a b => a.LeafLe W ∧ b.LeafLe W
  | div a b => a.LeafLe W ∧ b.LeafLe W
  | lt a b => a.LeafLe W ∧ b.LeafLe W
  | eq a b => a.LeafLe W ∧ b.LeafLe W
  | cnd c t f => c.LeafLe W ∧ t.LeafLe W ∧ f.LeafLe W

theorem mx_le_cb (W : ℕ) : ∀ e : ZE, e.LeafLe W → e.mx ≤ e.cb W
  | leaf _ _, h => h
  | lit _, _ => le_rfl
  | add a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    have h3 := a.bnd_le_mx; have h4 := b.bnd_le_mx
    simp only [mx, cb]; omega
  | sub a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    have h3 := a.bnd_le_mx; have h4 := b.bnd_le_mx
    simp only [mx, cb]; omega
  | mul a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    have h3 := a.bnd_le_mx; have h4 := b.bnd_le_mx
    simp only [mx, cb]; omega
  | div a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    simp only [mx, cb]; omega
  | lt a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    simp only [mx, cb]; omega
  | eq a b, ⟨ha, hb⟩ => by
    have h1 := a.mx_le_cb W ha; have h2 := b.mx_le_cb W hb
    simp only [mx, cb]; omega
  | cnd c t f, ⟨hc, ht, hf⟩ => by
    have h1 := c.mx_le_cb W hc; have h2 := t.mx_le_cb W ht; have h3 := f.mx_le_cb W hf
    simp only [mx, cb]; omega

/-- **Compiled integer expressions with the crude bound.** -/
theorem spec' {env : List Val} {e : ZE} {W : ℕ} (h : e.OK prog M env) (hW : e.LeafLe W)
    (hM : e.cb W + 1 ≤ M) : EvalsVal prog M env [] (.inl e.toExpr) (Val.int e.val) :=
  e.spec h (le_trans (Nat.succ_le_succ (e.mx_le_cb W hW)) hM)

theorem bitLen_val_le_cb {e : ZE} {W : ℕ} (hW : e.LeafLe W) : bitLen e.val ≤ e.cb W :=
  e.bitLen_val_le.trans (e.bnd_le_mx.trans (e.mx_le_cb W hW))

end ZE

/-- `clip_{[0,H]}(y)` (for `H ≥ 0`). -/
def zClip0 (H y : ZE) : ZE := ZE.cnd (ZE.lt y (ZE.lit 0)) (ZE.lit 0) (ZE.cnd (ZE.lt H y) H y)

theorem zClip0_val (H y : ZE) (hH : 0 ≤ H.val) : (zClip0 H y).val = clipZ 0 H.val y.val := by
  simp only [zClip0, ZE.val, clipZ]
  split_ifs <;> simp_all [max_def, min_def] <;> omega

/-- `S(x) = cd + cn x`. -/
def zS (x cn cd : ZE) : ZE := ZE.add cd (ZE.mul cn x)

theorem zS_val (x cn cd : ZE) : (zS x cn cd).val = wlS cn.val cd.val x.val := rfl

/-- A leaf with a dummy value (code only). -/
def lf (e : Expr) : ZE := ZE.leaf e 0

/-! ## Two-level field access -/

theorem evalsVal_at2 {env : List Val} {k : ℕ} {l : List Val} (henv : env[k]? = some (Val.list l))
    (hM : valSize (Val.list l) ≤ M) {i : ℕ} {l2 : List Val} (h1 : l[i]? = some (Val.list l2))
    {j : ℕ} {v : Val} (h2 : l2[j]? = some v) :
    EvalsVal prog M env [] (.inl (eAtN j (eAtN i (eV k)))) v :=
  evalsVal_atN' (evalsVal_atN' (EvalsVal.var henv) hM h1)
    (le_trans (valSize_le_of_getElem? h1) hM) h2

theorem evalsVal_at1 {env : List Val} {k : ℕ} {l : List Val} (henv : env[k]? = some (Val.list l))
    (hM : valSize (Val.list l) ≤ M) {i : ℕ} {v : Val} (h1 : l[i]? = some v) :
    EvalsVal prog M env [] (.inl (eAtN i (eV k))) v :=
  evalsVal_atN' (EvalsVal.var henv) hM h1

end Frame2

/-! ## Encodings -/

/-- An optional pair of integers: `[]` or `[N, D]`. -/
def encOptPair : Option (ℤ × ℤ) → Val
  | none => Val.list []
  | some r => Val.list [Val.int r.1, Val.int r.2]

/-- A pair of integers `[a, b]`. -/
def encPZ (r : ℤ × ℤ) : Val := Val.list [Val.int r.1, Val.int r.2]

/-! ## `fkStep` -/

/-- Leaves of a fold element routine: the element, the state (field `i`), the extra (field `i`). -/
abbrev eFx : Expr := eAtN 0 (eV 0)
abbrev eFs (i : ℕ) : Expr := eAtN i (eAtN 1 (eV 0))
abbrev eFe (i : ℕ) : Expr := eAtN i (eAtN 2 (eV 0))

def zFK1 (x F B cn cd : ZE) : ZE :=
  ZE.add F (zClip0 (ZE.mul (ZE.lit 8) cd) (ZE.sub (zS x cn cd) B))

def zFK2 (x k B cn cd : ZE) : ZE :=
  ZE.add k (ZE.cnd (ZE.lt B (ZE.sub (zS x cn cd) (ZE.mul (ZE.lit 8) cd))) (ZE.lit 0)
    (ZE.cnd (ZE.lt B (zS x cn cd)) (ZE.lit 1) (ZE.lit 0)))

/-- Element routine of `wlFKFold`: `[x, [F, k], [B, cn, cd]] ↦ fkStep cn cd B x (F, k)`. -/
def body_wlFKEl : Expr :=
  eList [(zFK1 (lf eFx) (lf (eFs 0)) (lf (eFe 0)) (lf (eFe 1)) (lf (eFe 2))).toExpr,
    (zFK2 (lf eFx) (lf (eFs 1)) (lf (eFe 0)) (lf (eFe 1)) (lf (eFe 2))).toExpr]

theorem zFK1_val {x F B cn cd : ZE} (hcd : 0 ≤ cd.val) :
    (zFK1 x F B cn cd).val = F.val + clipZ 0 (8 * cd.val) (wlS cn.val cd.val x.val - B.val) := by
  simp only [zFK1, ZE.val]
  rw [zClip0_val _ _ (by simp only [ZE.val]; omega)]
  rfl

theorem zFK2_val (x k B cn cd : ZE) :
    (zFK2 x k B cn cd).val = k.val +
      if wlS cn.val cd.val x.val - 8 * cd.val ≤ B.val ∧ B.val < wlS cn.val cd.val x.val
      then 1 else 0 := by
  simp only [zFK2, ZE.val, zS_val]
  split_ifs <;> simp_all <;> omega

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## Bit-length helpers -/

theorem bitLen_eight : bitLen 8 = 4 := by decide

theorem bitLen_sub_le (a b : ℤ) : bitLen (a - b) ≤ max (bitLen a) (bitLen b) + 1 := by
  have h := bitLen_add_le a (-b)
  rwa [bitLen_neg, ← sub_eq_add_neg] at h

theorem bitLen_le_of_nonneg_le {a b : ℤ} (h0 : 0 ≤ a) (h : a ≤ b) : bitLen a ≤ bitLen b :=
  bitLen_le_bitLen_of_natAbs_le (by omega)

theorem bitLen_natCast_le_size {n : ℕ} : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n

/-- Bit budget of one water-level computation: scores `g` and the factor `cn/cd`. -/
structure WB (cn cd : ℤ) (g : List ℤ) (W : ℕ) : Prop where
  cd_pos : 0 < cd
  cn_le : bitLen cn ≤ W
  cd_le : bitLen cd ≤ W
  g_le : ∀ x ∈ g, bitLen x ≤ W
  n_le : Nat.size g.length ≤ W

namespace WB

variable {cn cd : ℤ} {g : List ℤ} {W : ℕ}

theorem S_le (h : WB cn cd g W) {x : ℤ} (hx : x ∈ g) : bitLen (wlS cn cd x) ≤ 2 * W + 1 := by
  have h1 := bitLen_add_le cd (cn * x)
  have h2 := bitLen_mul_le cn x
  have := h.cn_le; have := h.cd_le; have := h.g_le x hx
  unfold wlS; omega

theorem B_le (h : WB cn cd g W) {x : ℤ} (hx : x ∈ g) {B : ℤ}
    (hB : B = wlS cn cd x ∨ B = wlS cn cd x - 8 * cd) : bitLen B ≤ 2 * W + 6 := by
  have h1 := h.S_le hx
  rcases hB with rfl | rfl
  · omega
  · have h2 := bitLen_sub_le (wlS cn cd x) (8 * cd)
    have h3 := bitLen_mul_le 8 cd
    have := h.cd_le
    rw [bitLen_eight] at h3
    omega

theorem n_cast_le (h : WB cn cd g W) : bitLen (g.length : ℤ) ≤ W := by
  rw [bitLen_natCast]; exact h.n_le

/-- `0 ≤ a ≤ 8 cd n` has at most `2W + 4` bits. -/
theorem le_8cdn (h : WB cn cd g W) {a : ℤ} (h0 : 0 ≤ a) (ha : a ≤ 8 * cd * g.length) :
    bitLen a ≤ 2 * W + 4 := by
  have h1 := bitLen_le_of_nonneg_le h0 ha
  have h2 := bitLen_mul_le (8 * cd) (g.length : ℤ)
  have h3 := bitLen_mul_le 8 cd
  have := h.cd_le; have := h.n_cast_le
  rw [bitLen_eight] at h3
  omega

/-- `0 ≤ k ≤ n` has at most `W` bits. -/
theorem le_n (h : WB cn cd g W) {k : ℤ} (h0 : 0 ≤ k) (hk : k ≤ g.length) : bitLen k ≤ W :=
  (bitLen_le_of_nonneg_le h0 hk).trans h.n_cast_le

end WB

/-! ## The element routine of `wlFKFold` -/

section FK

variable {prog : List Expr} {M : ℕ}

theorem wlFKEl_val {x F k B cn cd : ℤ} (hcd : 0 ≤ cd) {W : ℕ}
    (hx : bitLen x ≤ W) (hF : bitLen F ≤ W) (hk : bitLen k ≤ W) (hB : bitLen B ≤ W)
    (hcn : bitLen cn ≤ W) (hcd' : bitLen cd ≤ W)
    (hV : valSize (Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn, Val.int cd]]) ≤ M)
    (hM : 2 * (16 * W + 20) + 10 ≤ M) :
    EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn, Val.int cd]]]
      [] (.inl body_wlFKEl) (encPZ (fkStep cn cd B x (F, k))) := by
  have lx : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl eFx) (Val.int x) := evalsVal_at1 rfl hV rfl
  have lF : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl (eFs 0)) (Val.int F) := evalsVal_at2 rfl hV rfl rfl
  have lk : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl (eFs 1)) (Val.int k) := evalsVal_at2 rfl hV rfl rfl
  have lB : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl (eFe 0)) (Val.int B) := evalsVal_at2 rfl hV rfl rfl
  have lcn : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl (eFe 1)) (Val.int cn) := evalsVal_at2 rfl hV rfl rfl
  have lcd : EvalsVal prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] [] (.inl (eFe 2)) (Val.int cd) := evalsVal_at2 rfl hV rfl rfl
  set e1 := zFK1 (ZE.leaf eFx x) (ZE.leaf (eFs 0) F) (ZE.leaf (eFe 0) B) (ZE.leaf (eFe 1) cn)
    (ZE.leaf (eFe 2) cd) with he1
  set e2 := zFK2 (ZE.leaf eFx x) (ZE.leaf (eFs 1) k) (ZE.leaf (eFe 0) B) (ZE.leaf (eFe 1) cn)
    (ZE.leaf (eFe 2) cd) with he2
  have hok1 : e1.OK prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] := by
    simp only [he1, zFK1, zClip0, zS, ZE.OK]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hok2 : e2.OK prog M [Val.list [encZ x, encPZ (F, k), Val.list [Val.int B, Val.int cn,
      Val.int cd]]] := by
    simp only [he2, zFK2, zS, ZE.OK]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hl1 : e1.LeafLe W := by
    simp only [he1, zFK1, zClip0, zS, ZE.LeafLe]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hl2 : e2.LeafLe W := by
    simp only [he2, zFK2, zS, ZE.LeafLe]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hc1 : e1.cb W ≤ 16 * W + 20 := by
    simp only [he1, zFK1, zClip0, zS, ZE.cb, bitLen_eight, bitLen_zero]; omega
  have hc2 : e2.cb W ≤ 16 * W + 20 := by
    simp only [he2, zFK2, zS, ZE.cb, bitLen_eight, bitLen_zero, bitLen_one]; omega
  have h1 := ZE.spec' hok1 hl1 (by omega)
  have h2 := ZE.spec' hok2 hl2 (by omega)
  have hb1 := ZE.bitLen_val_le_cb hl1
  have hb2 := ZE.bitLen_val_le_cb hl2
  have hres := evalsVal_list (es := [e1.toExpr, e2.toExpr]) (vs := [Val.int e1.val, Val.int e2.val])
    (List.Forall₂.cons h1 (List.Forall₂.cons h2 List.Forall₂.nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
  have hv1 : e1.val = (fkStep cn cd B x (F, k)).1 := by
    rw [he1, zFK1_val (cd := ZE.leaf (eFe 2) cd) hcd]; rfl
  have hv2 : e2.val = (fkStep cn cd B x (F, k)).2 := by
    rw [he2, zFK2_val]; rfl
  rw [hv1, hv2] at hres
  exact hres

end FK

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The fold `wlFKFold` -/

section FKFold

variable {prog : List Expr} {M : ℕ}

theorem clipZ_nonneg {H y : ℤ} (_hH : 0 ≤ H) : 0 ≤ clipZ 0 H y := by
  unfold clipZ; omega

theorem clipZ_le {H y : ℤ} (hH : 0 ≤ H) : clipZ 0 H y ≤ H := by
  unfold clipZ; omega

theorem fk_inv_step {cn cd B : ℤ} (hcd : 0 < cd) (x : ℤ) (s : ℤ × ℤ) :
    s.1 ≤ (fkStep cn cd B x s).1 ∧ (fkStep cn cd B x s).1 ≤ s.1 + 8 * cd ∧
      s.2 ≤ (fkStep cn cd B x s).2 ∧ (fkStep cn cd B x s).2 ≤ s.2 + 1 := by
  have h1 := clipZ_nonneg (H := 8 * cd) (y := wlS cn cd x - B) (by omega)
  have h2 := clipZ_le (H := 8 * cd) (y := wlS cn cd x - B) (by omega)
  simp only [fkStep]
  refine ⟨by omega, by omega, ?_, ?_⟩ <;> split_ifs <;> omega

theorem valSize_encPZ (a b : ℤ) : valSize (encPZ (a, b)) = bitLen a + bitLen b + 5 := by
  simp only [encPZ, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega

/-- **The fold of `(F, k)`.** -/
theorem wlFKFold_val (hstep : prog[Idx.wlFKStep]? = some (body_foldBStep Idx.wlFKEl))
    (hF : prog[Idx.wlFKEl]? = some body_wlFKEl) {cn cd : ℤ} {g : List ℤ} {W : ℕ}
    (hW : WB cn cd g W) {B : ℤ} (hB : bitLen B ≤ 2 * W + 6)
    (hM : 2 * valSize (encL encZ g) + 128 * W + 1024 ≤ M) :
    EvalsVal prog M [Val.list [encPZ (0, 0), encL encZ g,
      Val.list [Val.int B, Val.int cn, Val.int cd]]] [] (.inl (body_foldB Idx.wlFKStep))
      (encPZ (wlFK cn cd g B)) := by
  have hcd := hW.cd_pos
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  refine foldP_body' hstep hF encZ encPZ (Val.list [Val.int B, Val.int cn, Val.int cd])
    (fkStep cn cd B)
    (fun r s => 0 ≤ s.1 ∧ s.1 + 8 * cd * r.length ≤ 8 * cd * g.length ∧ 0 ≤ s.2 ∧
      s.2 + r.length ≤ g.length)
    (3 * W + 9) g ?_ ?_ ?_ (0, 0) ?_
  · rintro x r ⟨F, k⟩ hsuf ⟨h1, h2, h3, h4⟩
    have hx : x ∈ g := hsuf.subset List.mem_cons_self
    obtain ⟨a1, a2, a3, a4⟩ := fk_inv_step (cn := cn) (B := B) hcd x (F, k)
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one] at h2 h4
    simp only at a1 a2 a3 a4 h1 h3
    have hpos : 0 ≤ 8 * cd * ((r.length : ℤ) + 1) := by positivity
    have hpos' : 0 ≤ 8 * cd * (r.length : ℤ) := by positivity
    have hF1 : bitLen F ≤ 2 * W + 4 := hW.le_8cdn h1 (by linarith)
    have hk1 : bitLen k ≤ W := hW.le_n h3 (by linarith)
    have hxW := hW.g_le x hx
    refine ⟨wlFKEl_val (W := 4 * W + 8) hcd.le (by omega) (by omega) (by omega) (by omega)
      (by omega) (by omega) ?_ (by omega), ?_⟩
    · rw [valSize_list]
      simp only [listSize_cons, listSize_nil, valSize_encPZ, encZ, valSize_int, valSize_list]
      omega
    · refine ⟨by linarith, by linarith, by linarith, by linarith⟩
  · rintro r ⟨F, k⟩ hsuf ⟨h1, h2, h3, h4⟩
    have hpos' : 0 ≤ 8 * cd * (r.length : ℤ) := by positivity
    have hF1 : bitLen F ≤ 2 * W + 4 := hW.le_8cdn h1 (by linarith)
    have hk1 : bitLen k ≤ W := hW.le_n h3 (by linarith)
    rw [valSize_encPZ]
    omega
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega
  · simp

end FKFold

/-! ## The mass fold `wlMassFold` -/

/-- `m + clip_{[0, 8 cd D]}(S(x) D − N cd)`. -/
def zMass (x m N D cn cd : ZE) : ZE :=
  ZE.add m (zClip0 (ZE.mul (ZE.mul (ZE.lit 8) cd) D) (ZE.sub (ZE.mul (zS x cn cd) D) (ZE.mul N cd)))

/-- Element routine of `wlMassFold`: `[x, m, [N, D, cn, cd]] ↦ massStep cn cd N D x m`. -/
def body_wlMassEl : Expr :=
  (zMass (lf eFx) (lf (eAtN 1 (eV 0))) (lf (eFe 0)) (lf (eFe 1)) (lf (eFe 2)) (lf (eFe 3))).toExpr

section Mass

variable {prog : List Expr} {M : ℕ}

theorem zMass_val {x m N D cn cd : ZE} (hcd : 0 ≤ cd.val) (hD : 0 ≤ D.val) :
    (zMass x m N D cn cd).val = massStep cn.val cd.val N.val D.val x.val m.val := by
  simp only [zMass, ZE.val]
  rw [zClip0_val _ _ (by simp only [ZE.val]; positivity)]
  rfl

theorem wlMassEl_val {x m N D cn cd : ℤ} (hcd : 0 ≤ cd) (hD : 0 ≤ D) {W : ℕ}
    (hx : bitLen x ≤ W) (hm : bitLen m ≤ W) (hN : bitLen N ≤ W) (hD' : bitLen D ≤ W)
    (hcn : bitLen cn ≤ W) (hcd' : bitLen cd ≤ W)
    (hV : valSize (Val.list [encZ x, Val.int m,
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]) ≤ M)
    (hM : 24 * W + 20 ≤ M) :
    EvalsVal prog M [Val.list [encZ x, Val.int m,
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]]
      [] (.inl body_wlMassEl) (Val.int (massStep cn cd N D x m)) := by
  have lx : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl eFx) (Val.int x) := evalsVal_at1 rfl hV rfl
  have lm : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl (eAtN 1 (eV 0))) (Val.int m) := evalsVal_at1 rfl hV rfl
  have lN : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl (eFe 0)) (Val.int N) := evalsVal_at2 rfl hV rfl rfl
  have lD : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl (eFe 1)) (Val.int D) := evalsVal_at2 rfl hV rfl rfl
  have lcn : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl (eFe 2)) (Val.int cn) := evalsVal_at2 rfl hV rfl rfl
  have lcd : EvalsVal prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] [] (.inl (eFe 3)) (Val.int cd) := evalsVal_at2 rfl hV rfl rfl
  set e := zMass (ZE.leaf eFx x) (ZE.leaf (eAtN 1 (eV 0)) m) (ZE.leaf (eFe 0) N)
    (ZE.leaf (eFe 1) D) (ZE.leaf (eFe 2) cn) (ZE.leaf (eFe 3) cd) with he
  have hok : e.OK prog M [Val.list [encZ x, Val.int m, Val.list [Val.int N, Val.int D,
      Val.int cn, Val.int cd]]] := by
    simp only [he, zMass, zClip0, zS, ZE.OK]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hl : e.LeafLe W := by
    simp only [he, zMass, zClip0, zS, ZE.LeafLe]
    repeat' apply And.intro
    all_goals first | trivial | assumption
  have hc : e.cb W ≤ 24 * W + 18 := by
    simp only [he, zMass, zClip0, zS, ZE.cb, bitLen_eight, bitLen_zero]; omega
  have h := ZE.spec' hok hl (by omega)
  have hv : e.val = massStep cn cd N D x m := by
    rw [he, zMass_val (cd := ZE.leaf (eFe 3) cd) (D := ZE.leaf (eFe 1) D) hcd hD]; rfl
  rw [hv] at h
  exact h

theorem mass_inv_step {cn cd N D : ℤ} (hcd : 0 < cd) (hD : 0 < D) (x m : ℤ) :
    m ≤ massStep cn cd N D x m ∧ massStep cn cd N D x m ≤ m + 8 * cd * D := by
  have hH : 0 ≤ 8 * cd * D := by positivity
  have h1 := clipZ_nonneg (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
  have h2 := clipZ_le (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
  simp only [massStep]
  constructor <;> omega

/-- **The mass fold** at a candidate `(N, D)` with `0 < D ≤ n cd` and `|N|` of `≤ 3W + 8` bits. -/
theorem wlMassFold_val (hstep : prog[Idx.wlMassStep]? = some (body_foldBStep Idx.wlMassEl))
    (hF : prog[Idx.wlMassEl]? = some body_wlMassEl) {cn cd : ℤ} {g : List ℤ} {W : ℕ}
    (hW : WB cn cd g W) {N D : ℤ} (hN : bitLen N ≤ 3 * W + 8) (hD0 : 0 < D)
    (hD : D ≤ g.length * cd)
    (hM : 2 * valSize (encL encZ g) + 128 * W + 1024 ≤ M) :
    EvalsVal prog M [Val.list [Val.int 0, encL encZ g,
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]] [] (.inl (body_foldB Idx.wlMassStep))
      (Val.int (wlMass cn cd g N D)) := by
  have hcd := hW.cd_pos
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  have hDW : bitLen D ≤ 2 * W := by
    have := bitLen_le_of_nonneg_le hD0.le hD
    have := bitLen_mul_le (g.length : ℤ) cd
    omega
  -- the masses: `0 ≤ m ≤ 8 cd D n`, at most `4W + 4` bits
  have hbig : ∀ m : ℤ, 0 ≤ m → m ≤ 8 * cd * D * g.length → bitLen m ≤ 4 * W + 4 := by
    intro m h0 hm
    have h1 := bitLen_le_of_nonneg_le h0 hm
    have h2 := bitLen_mul_le (8 * cd * D) (g.length : ℤ)
    have h3 := bitLen_mul_le (8 * cd) D
    have h4 := bitLen_mul_le 8 cd
    rw [bitLen_eight] at h4
    omega
  refine foldP_body' (σ := ℤ) hstep hF encZ (fun m => Val.int m)
    (Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]) (massStep cn cd N D)
    (fun r m => 0 ≤ m ∧ m + 8 * cd * D * r.length ≤ 8 * cd * D * g.length)
    (4 * W + 5) g ?_ ?_ ?_ 0 ?_
  · rintro x r m hsuf ⟨h1, h2⟩
    have hx : x ∈ g := hsuf.subset List.mem_cons_self
    obtain ⟨a1, a2⟩ := mass_inv_step (cn := cn) (N := N) hcd hD0 x m
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one] at h2
    have hpos : 0 ≤ 8 * cd * D * (r.length : ℤ) := by positivity
    have hm1 := hbig m h1 (by nlinarith)
    have hxW := hW.g_le x hx
    refine ⟨wlMassEl_val (W := 4 * W + 8) hcd.le hD0.le (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) ?_ (by omega), ?_⟩
    · simp only [valSize_list, listSize_cons, listSize_nil, encZ, valSize_int]
      omega
    · exact ⟨by linarith, by nlinarith⟩
  · rintro r m hsuf ⟨h1, h2⟩
    have hpos : 0 ≤ 8 * cd * D * (r.length : ℤ) := by positivity
    have := hbig m h1 (by linarith)
    simp only [valSize_int]
    omega
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega
  · refine ⟨le_refl _, ?_⟩
    simp

end Mass

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## `wlTryR` -/

/-- `k B + F − n cd`. -/
def zN (k B F n cd : ZE) : ZE := ZE.sub (ZE.add (ZE.mul k B) F) (ZE.mul n cd)
/-- `k cd`. -/
def zD (k cd : ZE) : ZE := ZE.mul k cd

/-- `wlTryR : [B, g, cn, cd, n] ↦ encOptPair (wlTry cn cd g B)`. -/
def body_wlTry : Expr :=
  eLet (eCall Idx.wlFKFold (eList [eList [eLit 0, eLit 0], eAtN 1 (eV 0),
      eList [eAtN 0 (eV 0), eAtN 2 (eV 0), eAtN 3 (eV 0)]]))
  (eIte (ZE.eq (lf (eAtN 0 (eV 0))) (ZE.mul (lf (eAtN 4 (eV 1))) (lf (eAtN 3 (eV 1))))).toExpr
    (eList [eAtN 0 (eV 1), eAtN 3 (eV 1)])
    (eIte (ZE.eq (lf (eAtN 1 (eV 0))) (ZE.lit 0)).toExpr
      Expr.nil
      (eLet (eCall Idx.wlMassFold (eList [eLit 0, eAtN 1 (eV 1),
          eList [(zN (lf (eAtN 1 (eV 0))) (lf (eAtN 0 (eV 1))) (lf (eAtN 0 (eV 0)))
              (lf (eAtN 4 (eV 1))) (lf (eAtN 3 (eV 1)))).toExpr,
            (zD (lf (eAtN 1 (eV 0))) (lf (eAtN 3 (eV 1)))).toExpr, eAtN 2 (eV 1), eAtN 3 (eV 1)]]))
        (eIte (ZE.eq (lf (eV 0)) (ZE.mul (ZE.mul (lf (eAtN 4 (eV 2))) (lf (eAtN 3 (eV 2))))
            (zD (lf (eAtN 1 (eV 1))) (lf (eAtN 3 (eV 2)))))).toExpr
          (eList [(zN (lf (eAtN 1 (eV 1))) (lf (eAtN 0 (eV 2))) (lf (eAtN 0 (eV 1)))
              (lf (eAtN 4 (eV 2))) (lf (eAtN 3 (eV 2)))).toExpr,
            (zD (lf (eAtN 1 (eV 1))) (lf (eAtN 3 (eV 2)))).toExpr])
          Expr.nil))))

section Try

variable {prog : List Expr} {M : ℕ}

/-- The lookups of the two inner folds. -/
structure FoldLib (prog : List Expr) : Prop where
  fkFold : prog[Idx.wlFKFold]? = some (body_foldB Idx.wlFKStep)
  fkStep : prog[Idx.wlFKStep]? = some (body_foldBStep Idx.wlFKEl)
  fkEl : prog[Idx.wlFKEl]? = some body_wlFKEl
  massFold : prog[Idx.wlMassFold]? = some (body_foldB Idx.wlMassStep)
  massStep : prog[Idx.wlMassStep]? = some (body_foldBStep Idx.wlMassEl)
  massEl : prog[Idx.wlMassEl]? = some body_wlMassEl

theorem wlFK_bounds {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) (B : ℤ) :
    0 ≤ (wlFK cn cd g B).1 ∧ (wlFK cn cd g B).1 ≤ 8 * cd * g.length ∧
      0 ≤ (wlFK cn cd g B).2 ∧ (wlFK cn cd g B).2 ≤ g.length := by
  have hcd := hW.cd_pos
  rw [wlFK_fst, wlFK_snd]
  refine ⟨List.sum_nonneg (fun y hy => ?_), ?_, List.sum_nonneg (fun y hy => ?_), ?_⟩
  · obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
    exact clipZ_nonneg (by omega)
  · have := List.sum_le_card_nsmul (g.map fun x => clipZ 0 (8 * cd) (wlS cn cd x - B)) (8 * cd)
      (fun y hy => by
        obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
        exact clipZ_le (by omega))
    simp only [List.length_map, nsmul_eq_mul] at this
    linarith
  · obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
    split_ifs <;> norm_num
  · have := List.sum_le_card_nsmul
      (g.map fun x => if wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x then (1 : ℤ) else 0) 1
      (fun y hy => by
        obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
        split_ifs <;> norm_num)
    simp only [List.length_map, nsmul_eq_mul, mul_one] at this
    exact this

/-- **Spec of `wlTryR`.** -/
theorem wlTry_val (hF : FoldLib prog) {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W)
    {B : ℤ} (hB : bitLen B ≤ 2 * W + 6)
    (hM : 2 * valSize (encL encZ g) + 128 * W + 1024 ≤ M) :
    EvalsVal prog M [Val.list [Val.int B, encL encZ g, Val.int cn, Val.int cd,
      Val.int (g.length : ℤ)]] [] (.inl body_wlTry) (encOptPair (wlTry cn cd g B)) := by
  have hcd := hW.cd_pos
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  set a := Val.list [Val.int B, encL encZ g, Val.int cn, Val.int cd, Val.int (g.length : ℤ)]
    with ha
  have haM : valSize a ≤ M := by
    simp only [ha, valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : valSize (encL encZ g) = 1 + listSize ((g.map encZ)) := rfl
    omega
  -- fields of the argument
  have fB : EvalsVal prog M [a] [] (.inl (eAtN 0 (eV 0))) (Val.int B) := evalsVal_at1 rfl haM rfl
  have fg : EvalsVal prog M [a] [] (.inl (eAtN 1 (eV 0))) (encL encZ g) := evalsVal_at1 rfl haM rfl
  have fcn : EvalsVal prog M [a] [] (.inl (eAtN 2 (eV 0))) (Val.int cn) := evalsVal_at1 rfl haM rfl
  have fcd : EvalsVal prog M [a] [] (.inl (eAtN 3 (eV 0))) (Val.int cd) := evalsVal_at1 rfl haM rfl
  -- the fold of `(F, k)`
  have hfk : EvalsVal prog M [a] [] (.inl (eCall Idx.wlFKFold (eList [eList [eLit 0, eLit 0],
      eAtN 1 (eV 0), eList [eAtN 0 (eV 0), eAtN 2 (eV 0), eAtN 3 (eV 0)]])))
      (encPZ (wlFK cn cd g B)) := by
    refine evalsVal_call_det hF.fkFold ?_ (wlFKFold_val hF.fkStep hF.fkEl hW hB hM)
    have h00 : EvalsVal prog M [a] [] (.inl (eList [eLit 0, eLit 0])) (encPZ (0, 0)) :=
      evalsVal_list (List.Forall₂.cons (EvalsVal.lit (by simp; omega))
        (List.Forall₂.cons (EvalsVal.lit (by simp; omega)) List.Forall₂.nil))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]; omega)
    have hex : EvalsVal prog M [a] [] (.inl (eList [eAtN 0 (eV 0), eAtN 2 (eV 0), eAtN 3 (eV 0)]))
        (Val.list [Val.int B, Val.int cn, Val.int cd]) :=
      evalsVal_list (List.Forall₂.cons fB (List.Forall₂.cons fcn (List.Forall₂.cons fcd
        List.Forall₂.nil)))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
    exact evalsVal_list (List.Forall₂.cons h00 (List.Forall₂.cons fg (List.Forall₂.cons hex
      List.Forall₂.nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encPZ,
            bitLen_zero] at hM ⊢; omega)
  obtain ⟨hF0, hF1, hk0, hk1⟩ := wlFK_bounds hW B
  set F := (wlFK cn cd g B).1 with hFdef
  set k := (wlFK cn cd g B).2 with hkdef
  have hFW : bitLen F ≤ 2 * W + 4 := hW.le_8cdn hF0 hF1
  have hkW : bitLen k ≤ W := hW.le_n hk0 hk1
  have hpz : encPZ (wlFK cn cd g B) = Val.list [Val.int F, Val.int k] := rfl
  rw [hpz] at hfk
  refine EvalsVal.letE hfk ?_
  set e1 := [Val.list [Val.int F, Val.int k], a] with he1
  have he1M : valSize (Val.list [Val.int F, Val.int k]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega
  have lF : EvalsVal prog M e1 [] (.inl (eAtN 0 (eV 0))) (Val.int F) := evalsVal_at1 rfl he1M rfl
  have lk : EvalsVal prog M e1 [] (.inl (eAtN 1 (eV 0))) (Val.int k) := evalsVal_at1 rfl he1M rfl
  have lB : EvalsVal prog M e1 [] (.inl (eAtN 0 (eV 1))) (Val.int B) := evalsVal_at1 rfl haM rfl
  have lg : EvalsVal prog M e1 [] (.inl (eAtN 1 (eV 1))) (encL encZ g) := evalsVal_at1 rfl haM rfl
  have lcn : EvalsVal prog M e1 [] (.inl (eAtN 2 (eV 1))) (Val.int cn) := evalsVal_at1 rfl haM rfl
  have lcd : EvalsVal prog M e1 [] (.inl (eAtN 3 (eV 1))) (Val.int cd) := evalsVal_at1 rfl haM rfl
  have ln : EvalsVal prog M e1 [] (.inl (eAtN 4 (eV 1))) (Val.int (g.length : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  -- the first test `F = n cd`
  set c1 := ZE.eq (ZE.leaf (eAtN 0 (eV 0)) F)
    (ZE.mul (ZE.leaf (eAtN 4 (eV 1)) (g.length : ℤ)) (ZE.leaf (eAtN 3 (eV 1)) cd)) with hc1
  have hc1E : EvalsVal prog M e1 [] (.inl c1.toExpr) (Val.int c1.val) :=
    ZE.spec' (W := 2 * W + 4) (by simp only [hc1, ZE.OK]; exact ⟨lF, ln, lcd⟩)
      (by simp only [hc1, ZE.LeafLe]; omega) (by simp only [hc1, ZE.cb]; omega)
  by_cases h1 : F = (g.length : ℤ) * cd
  · have hv : c1.val ≠ 0 := by simp [hc1, ZE.val, h1]
    have hres : encOptPair (wlTry cn cd g B) = Val.list [Val.int B, Val.int cd] := by
      unfold wlTry; rw [if_pos h1]; rfl
    rw [hres]
    refine EvalsVal.ite_true hc1E hv ?_
    exact evalsVal_list (List.Forall₂.cons lB (List.Forall₂.cons lcd List.Forall₂.nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
  have hv1 : c1.val = 0 := by simp [hc1, ZE.val, h1]
  refine EvalsVal.ite_false hc1E hv1 ?_
  -- the second test `k = 0`
  set c2 := ZE.eq (ZE.leaf (eAtN 1 (eV 0)) k) (ZE.lit 0) with hc2
  have hc2E : EvalsVal prog M e1 [] (.inl c2.toExpr) (Val.int c2.val) :=
    ZE.spec' (W := W) (by simp only [hc2, ZE.OK]; exact ⟨lk, trivial⟩)
      (by simp only [hc2, ZE.LeafLe]; exact ⟨hkW, trivial⟩)
      (by simp only [hc2, ZE.cb, bitLen_zero]; omega)
  by_cases h2 : k = 0
  · have hv : c2.val ≠ 0 := by simp [hc2, ZE.val, h2]
    have hres : encOptPair (wlTry cn cd g B) = Val.list [] := by
      unfold wlTry; rw [if_neg h1, if_neg (fun h => h.1 h2)]; rfl
    rw [hres]
    exact EvalsVal.ite_true hc2E hv (EvalsVal.nil (by simp; omega))
  have hv2 : c2.val = 0 := by simp [hc2, ZE.val, h2]
  refine EvalsVal.ite_false hc2E hv2 ?_
  -- the interpolated candidate
  have hkpos : 0 < k := lt_of_le_of_ne hk0 (Ne.symm h2)
  set N := k * B + F - (g.length : ℤ) * cd with hNdef
  set D := k * cd with hDdef
  have hD0 : 0 < D := mul_pos hkpos hcd
  have hDle : D ≤ g.length * cd := mul_le_mul_of_nonneg_right hk1 hcd.le
  have hNW : bitLen N ≤ 3 * W + 8 := by
    rw [hNdef]
    have h1 := bitLen_sub_le (k * B + F) ((g.length : ℤ) * cd)
    have h2 := bitLen_add_le (k * B) F
    have h3 := bitLen_mul_le k B
    have h4 := bitLen_mul_le (g.length : ℤ) cd
    omega
  have hDW : bitLen D ≤ 2 * W := by
    rw [hDdef]
    have := bitLen_mul_le k cd
    omega
  set zN1 := zN (ZE.leaf (eAtN 1 (eV 0)) k) (ZE.leaf (eAtN 0 (eV 1)) B)
    (ZE.leaf (eAtN 0 (eV 0)) F) (ZE.leaf (eAtN 4 (eV 1)) (g.length : ℤ))
    (ZE.leaf (eAtN 3 (eV 1)) cd) with hzN1
  set zD1 := zD (ZE.leaf (eAtN 1 (eV 0)) k) (ZE.leaf (eAtN 3 (eV 1)) cd) with hzD1
  have hzN1E : EvalsVal prog M e1 [] (.inl zN1.toExpr) (Val.int N) :=
    ZE.spec' (W := 2 * W + 6) (by simp only [hzN1, zN, ZE.OK]; exact ⟨⟨⟨lk, lB⟩, lF⟩, ln, lcd⟩)
      (by simp only [hzN1, zN, ZE.LeafLe]; omega) (by simp only [hzN1, zN, ZE.cb]; omega)
  have hzD1E : EvalsVal prog M e1 [] (.inl zD1.toExpr) (Val.int D) :=
    ZE.spec' (W := W) (by simp only [hzD1, zD, ZE.OK]; exact ⟨lk, lcd⟩)
      (by simp only [hzD1, zD, ZE.LeafLe]; omega) (by simp only [hzD1, zD, ZE.cb]; omega)
  have hmass : EvalsVal prog M e1 [] (.inl (eCall Idx.wlMassFold (eList [eLit 0, eAtN 1 (eV 1),
      eList [zN1.toExpr, zD1.toExpr, eAtN 2 (eV 1), eAtN 3 (eV 1)]])))
      (Val.int (wlMass cn cd g N D)) := by
    refine evalsVal_call_det hF.massFold ?_ (wlMassFold_val hF.massStep hF.massEl hW hNW hD0 hDle hM)
    have hex : EvalsVal prog M e1 [] (.inl (eList [zN1.toExpr, zD1.toExpr, eAtN 2 (eV 1),
        eAtN 3 (eV 1)])) (Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]) :=
      evalsVal_list (List.Forall₂.cons hzN1E (List.Forall₂.cons hzD1E (List.Forall₂.cons lcn
        (List.Forall₂.cons lcd List.Forall₂.nil))))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
    exact evalsVal_list (List.Forall₂.cons (EvalsVal.lit (by simp; omega))
      (List.Forall₂.cons lg (List.Forall₂.cons hex List.Forall₂.nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero] at hM ⊢
          omega)
  have hmB : bitLen (wlMass cn cd g N D) ≤ 4 * W + 4 := by
    rw [wlMass_eq]
    have h0 : 0 ≤ (g.map fun x => clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd)).sum :=
      List.sum_nonneg (fun y hy => by
        obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
        exact clipZ_nonneg (by positivity))
    have hle := List.sum_le_card_nsmul
      (g.map fun x => clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd)) (8 * cd * D)
      (fun y hy => by
        obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
        exact clipZ_le (by positivity))
    simp only [List.length_map, nsmul_eq_mul] at hle
    have h1 := bitLen_le_of_nonneg_le h0 hle
    have h2 := bitLen_mul_le (g.length : ℤ) (8 * cd * D)
    have h3 := bitLen_mul_le (8 * cd) D
    have h4 := bitLen_mul_le 8 cd
    rw [bitLen_eight] at h4
    omega
  refine EvalsVal.letE hmass ?_
  set e2 := Val.int (wlMass cn cd g N D) :: e1 with he2
  have lm : EvalsVal prog M e2 [] (.inl (eV 0)) (Val.int (wlMass cn cd g N D)) := EvalsVal.var rfl
  have lF' : EvalsVal prog M e2 [] (.inl (eAtN 0 (eV 1))) (Val.int F) := evalsVal_at1 rfl he1M rfl
  have lk' : EvalsVal prog M e2 [] (.inl (eAtN 1 (eV 1))) (Val.int k) := evalsVal_at1 rfl he1M rfl
  have lB' : EvalsVal prog M e2 [] (.inl (eAtN 0 (eV 2))) (Val.int B) := evalsVal_at1 rfl haM rfl
  have lcd' : EvalsVal prog M e2 [] (.inl (eAtN 3 (eV 2))) (Val.int cd) := evalsVal_at1 rfl haM rfl
  have ln' : EvalsVal prog M e2 [] (.inl (eAtN 4 (eV 2))) (Val.int (g.length : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  set zD2 := zD (ZE.leaf (eAtN 1 (eV 1)) k) (ZE.leaf (eAtN 3 (eV 2)) cd) with hzD2
  set c3 := ZE.eq (ZE.leaf (eV 0) (wlMass cn cd g N D))
    (ZE.mul (ZE.mul (ZE.leaf (eAtN 4 (eV 2)) (g.length : ℤ)) (ZE.leaf (eAtN 3 (eV 2)) cd)) zD2)
    with hc3
  have hc3E : EvalsVal prog M e2 [] (.inl c3.toExpr) (Val.int c3.val) :=
    ZE.spec' (W := 4 * W + 4) (by simp only [hc3, hzD2, zD, ZE.OK]; exact ⟨lm, ⟨ln', lcd'⟩, lk', lcd'⟩)
      (by simp only [hc3, hzD2, zD, ZE.LeafLe]; omega)
      (by simp only [hc3, hzD2, zD, ZE.cb]; omega)
  have hc3v : c3.val = if wlMass cn cd g N D = (g.length : ℤ) * cd * D then 1 else 0 := by
    simp only [hc3, hzD2, zD, ZE.val]
    rw [hDdef]
    split_ifs <;> simp_all
  by_cases h3 : wlMass cn cd g N D = (g.length : ℤ) * cd * D
  · have hv : c3.val ≠ 0 := by rw [hc3v, if_pos h3]; norm_num
    have hres : encOptPair (wlTry cn cd g B) = Val.list [Val.int N, Val.int D] := by
      unfold wlTry
      rw [if_neg h1, if_pos ⟨h2, h3⟩]
      rfl
    rw [hres]
    set zN2 := zN (ZE.leaf (eAtN 1 (eV 1)) k) (ZE.leaf (eAtN 0 (eV 2)) B)
      (ZE.leaf (eAtN 0 (eV 1)) F) (ZE.leaf (eAtN 4 (eV 2)) (g.length : ℤ))
      (ZE.leaf (eAtN 3 (eV 2)) cd) with hzN2
    have hzN2E : EvalsVal prog M e2 [] (.inl zN2.toExpr) (Val.int N) :=
      ZE.spec' (W := 2 * W + 6) (by simp only [hzN2, zN, ZE.OK]; exact ⟨⟨⟨lk', lB'⟩, lF'⟩, ln', lcd'⟩)
        (by simp only [hzN2, zN, ZE.LeafLe]; omega) (by simp only [hzN2, zN, ZE.cb]; omega)
    have hzD2E : EvalsVal prog M e2 [] (.inl zD2.toExpr) (Val.int D) :=
      ZE.spec' (W := W) (by simp only [hzD2, zD, ZE.OK]; exact ⟨lk', lcd'⟩)
        (by simp only [hzD2, zD, ZE.LeafLe]; omega) (by simp only [hzD2, zD, ZE.cb]; omega)
    refine EvalsVal.ite_true hc3E hv ?_
    exact evalsVal_list (List.Forall₂.cons hzN2E (List.Forall₂.cons hzD2E List.Forall₂.nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
  · have hv : c3.val = 0 := by rw [hc3v, if_neg h3]
    have hres : encOptPair (wlTry cn cd g B) = Val.list [] := by
      unfold wlTry
      rw [if_neg h1, if_neg (fun h => h3 h.2)]
      rfl
    rw [hres]
    exact EvalsVal.ite_false hc3E hv (EvalsVal.nil (by simp; omega))

end Try

end F2e2e.C.Impl
