import F2e2e.C.Impl.Tree4Lists

/-!
# W6, Tree4: sizes, and the DSL implementation of `rejectTail` (`rejectRelease`, `rejectTail`)

* the size bounds used by the routine proofs, in units of C-SPACE's state size bound
  `SSB R P = stateSizeBound P (R.bound P)` (`Mv R P = 2^32 SSB R P`);
* `rejectRelease_impl`: `body_rejectRelease` implements `rejectReleaseRef` (DIFF release, counters);
  (`rejectTail_impl`: `F2e2e/C/Impl/Tree4TailImpl.lean`).
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-! ## Sizes -/

/-- The encoded output `[state, F]` of a Step-4 routine. -/
def encSF (R : AdaRep) (r : State × ℚ) : Val := Val.list [encState R.enc r.1, encQ r.2]

/-- C-SPACE's state size bound. -/
abbrev SSB (R : AdaRep) (P : StreamParams) : ℕ := stateSizeBound P (R.bound P)

section Size

variable (R : AdaRep) (P : StreamParams)

theorem SSB_HB : P.H * (bankSizeBound P (R.bound P) + 1) ≤ SSB R P := by
  unfold SSB stateSizeBound; omega

theorem SSB_HL : P.H * (2 ^ 6 * P.calL ^ 3 + 1) ≤ SSB R P := by
  unfold SSB stateSizeBound; omega

theorem SSB_c3 : 2 ^ 5 * P.calL ^ 3 ≤ SSB R P := by
  unfold SSB stateSizeBound; omega

theorem SSB_bank : bankSizeBound P (R.bound P) + 1 ≤ SSB R P :=
  (Nat.le_mul_of_pos_left _ P.one_le_H).trans (SSB_HB R P)

theorem SSB_learner : 2 ^ 6 * P.calL ^ 3 + 1 ≤ SSB R P :=
  (Nat.le_mul_of_pos_left _ P.one_le_H).trans (SSB_HL R P)

theorem SSB_H : P.H ≤ SSB R P :=
  (Nat.le_mul_of_pos_right _ (by omega)).trans (SSB_HL R P)

theorem regBits_le_SSB : regBits P ≤ 2 * SSB R P := by
  have h1 := SSB_learner R P
  rw [regBits_eq]; omega

theorem vs_params : valSize (encStreamParams P) ≤ SSB R P := by
  have h1 := valSize_encStreamParams_le P
  have h2 := SSB_c3 R P
  have h3 := SizeAux.hundred_calL_le_cube P
  have h4 := hundred_le_calL P
  omega

theorem vs_encQ {x : ℚ} (h : QOK P x) : valSize (encQ x) ≤ 2 ^ 4 * SSB R P := by
  have h1 := valSize_encQ_le_of_QOK h
  have h3 := SSB_learner R P
  rw [regBits_eq] at h1; omega

theorem vs_encN {n : ℕ} (h : n ≤ regBits P) : valSize (encN n) ≤ 2 * SSB R P + 1 := by
  rw [valSize_encN]
  have := size_le_self n
  have := regBits_le_SSB R P
  omega

theorem vs_learner {L : Learner} (h : LearnerOK P 16 L) : valSize (encLearner L) ≤ SSB R P := by
  have := valSize_encLearner_le16 h
  have := SSB_learner R P
  omega

theorem vs_int {z : ℤ} {k : ℕ} (hz : |z| < 2 ^ k) (hk : k ≤ 4 * regBits P) :
    valSize (Val.int z) ≤ 2 ^ 4 * SSB R P := by
  have := valSize_int_le_of_abs_lt hz
  have := regBits_le_SSB R P
  have := SSB_learner R P
  omega

theorem vs_two_pow {e : ℕ} (he : e ≤ regBits P) : valSize (encN (2 ^ e)) ≤ 2 * SSB R P + 2 := by
  rw [valSize_encN, Nat.size_pow]
  have := regBits_le_SSB R P
  omega

end Size

theorem vs_state {R : AdaRep} (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P) {s : State}
    (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) : valSize (encState R.enc s) ≤ SSB R P :=
  StateOK.valSize_encState_le (hR.enc_le P hP) hs ht

theorem vs_bank {R : AdaRep} (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P) {B : Bank}
    (hB : BankOK P (R.ok P) B) : valSize (encBank R.enc B) ≤ SSB R P :=
  (BankOK.valSize_encBank_le (hR.enc_le P hP) hB).trans (by have := SSB_bank R P; omega)

theorem vs_banks_le (adaEnc : AdaState → Val) (s : State) :
    valSize (encL (encBank adaEnc) s.banks) ≤ valSize (encState adaEnc s) := by
  simp only [encState, encL, valSize_list, listSize_cons, listSize_nil]; omega

theorem vs_learners_le (adaEnc : AdaState → Val) (s : State) :
    valSize (encL encLearner s.learners) ≤ valSize (encState adaEnc s) := by
  simp only [encState, encL, valSize_list, listSize_cons, listSize_nil]; omega

theorem vs_leaf_le (adaEnc : AdaState → Val) (s : State) :
    valSize (Val.int s.leaf) ≤ valSize (encState adaEnc s) := by
  simp only [encState, valSize_list, listSize_cons, listSize_nil]; omega

theorem vs_pair {a b : Val} {A B : ℕ} (ha : valSize a ≤ A) (hb : valSize b ≤ B) :
    valSize (Val.list [a, b]) ≤ A + B + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem mapIdx_M_le {α : Type} (enc : α → Val) (l : List α) (extra : Val) (VB S : ℕ)
    (hl : valSize (encL enc l) ≤ S) (hlen : l.length * (VB + 1) ≤ S) (hVB : VB ≤ S)
    (hx : valSize extra ≤ S) (hn : l.length ≤ S) : mapIdx_M enc l extra VB ≤ 16 * S + 106 := by
  unfold mapIdx_M
  have := size_le_self l.length
  omega

theorem mapIdx_M_banks_le {R : AdaRep} (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P)
    {bs : List Bank} (hbs : ∀ B ∈ bs, BankOK P (R.ok P) B) (hlen : bs.length ≤ P.H) (extra : Val)
    (hx : valSize extra ≤ 2 ^ 6 * SSB R P) :
    mapIdx_M (encBank R.enc) bs extra (bankSizeBound P (R.bound P)) ≤ 2 ^ 11 * SSB R P := by
  have h0 := SSB_bank R P
  have h1 : valSize (encL (encBank R.enc) bs) ≤ 1 + bs.length * (bankSizeBound P (R.bound P) + 1) :=
    valSize_encL_le _ _ _ (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hbs B hB))
  have h2 : bs.length * (bankSizeBound P (R.bound P) + 1) ≤ SSB R P :=
    (Nat.mul_le_mul_right _ hlen).trans (SSB_HB R P)
  have h4 := SSB_H R P
  have := mapIdx_M_le (encBank R.enc) bs extra (bankSizeBound P (R.bound P)) (2 ^ 6 * SSB R P)
    (by omega) (by omega) (by omega) hx (by omega)
  omega

theorem mapIdx_M_learners_le {R : AdaRep} {P : StreamParams} {ls : List Learner}
    (hls : ∀ L ∈ ls, LearnerOK P 16 L) (hlen : ls.length ≤ P.H) (extra : Val)
    (hx : valSize extra ≤ 2 ^ 6 * SSB R P) :
    mapIdx_M encLearner ls extra (2 ^ 6 * P.calL ^ 3) ≤ 2 ^ 11 * SSB R P := by
  have h0 := SSB_learner R P
  have h1 : valSize (encL encLearner ls) ≤ 1 + ls.length * (2 ^ 6 * P.calL ^ 3 + 1) :=
    valSize_encL_le _ _ _ (fun L hL => valSize_encLearner_le16 (hls L hL))
  have h2 : ls.length * (2 ^ 6 * P.calL ^ 3 + 1) ≤ SSB R P :=
    (Nat.mul_le_mul_right _ hlen).trans (SSB_HL R P)
  have h4 := SSB_H R P
  have := mapIdx_M_le encLearner ls extra (2 ^ 6 * P.calL ^ 3) (2 ^ 6 * SSB R P)
    (by omega) (by omega) (by omega) hx (by omega)
  omega

theorem gridVal_eq_div (q : ℕ) (m : ℤ) :
    ((m : ℚ) / (((2 ^ q : ℕ) : ℤ) : ℚ)) = gridVal q m := by
  unfold gridVal; push_cast; ring

theorem ev_normQ_grid {R : AdaRep} {prog : List Expr} {M : ℕ} {env : List Val}
    (hC : Contracts R prog M) {a b : Expr} {m : ℤ} {q : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.int m))
    (hb : EvalsVal prog M env [] (.inl b) (encN (2 ^ q)))
    (hsz : 2 * (bitLen m + (q + 1)) + 64 ≤ M) :
    EvalsVal prog M env [] (.inl (eNormQ a b)) (encQ (gridVal q m)) := by
  have h := ev_normQ hC ha hb (by positivity) (by rw [bitLen_natCast, Nat.size_pow]; omega)
  rwa [gridVal_eq_div] at h

/-! ## `rejectRelease` -/

/-- **`rejectRelease`** implements `rejectReleaseRef` (the DIFF release, the counters and the
cache refresh at the end of `rejectTail`, partIII.tex L508–510). -/
theorem rejectRelease_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s1 : State} (hs1 : StateOK P (R.ok P) 4 s1) (ht : s1.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) {Ld : Learner} (hLd : LearnerOK P 4 Ld) (hj : Ld.jUsed < P.Jstar) {N1 : ℚ}
    (hN1 : FOK P N1) :
    Implements prog M [Val.list [encStreamParams P, encN d, encLearner Ld, encQ N1,
      encState R.enc s1]] body_rejectRelease (encSF R) (rejectReleaseRef P d Ld N1 s1) := by
  have hA := hR.invariant P hP
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hpz := vs_params R P
  have hRB := regBits_le_SSB R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hLz := vs_learner R P (hLd.mono (by norm_num) : LearnerOK P 16 Ld)
  have hNz := vs_encQ R P hN1.qok
  have hsz := vs_state hR hP hs1 ht
  have hsM : valSize (encState R.enc s1) ≤ M := by omega
  have hXz : valSize (Val.list [encStreamParams P, encN d, encLearner Ld, encQ N1,
      encState R.enc s1]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hbz := vs_banks_le R.enc s1
  have hlz := vs_learners_le R.enc s1
  have hsd := size_le_self d
  rw [valSize_encN] at hdz
  unfold body_rejectRelease
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 4 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_getOpt hT (encBank R.enc) s1.banks d
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hsM rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
    (by omega)) ?_
  unfold rejectReleaseRef
  rcases hBd : s1.banks[d]? with _ | Bd
  · -- no bank at `d`
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  · have hBd' : BankOK P (R.ok P) Bd := hs1.banks_ok Bd (List.mem_of_getElem? hBd)
    have hBz := vs_bank hR hP hBd'
    refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
    simp only [bp_bind_eq, bp_pure_eq]
    refine impl_letE_run (impl_releaseCall hC hP hM hBd' Mode.diff
      (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_head' (EvalsVal.var rfl)
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (.cons (EvalsVal.lit (by simp; omega)) .nil)))
        (by simp only [encMode, valSize_list, listSize_cons, listSize_nil, valSize_int,
              bitLen_one]; omega))) (fun bits r2 hrun => ?_)
    rcases r2 with ⟨N2o, B2⟩
    dsimp only
    have hB2 : BankOK P (R.ok P) B2 := Always.of_run (BankOK.release hA hBd' Mode.diff) hrun
    have hq2 : ∀ N, N2o = some N →
        QOK P N ∧ 0 ≤ N ∧ |roundMant P.eHP N| < 2 ^ (2 * regBits P) :=
      Always.of_run (release_qok hBd' Mode.diff) hrun
    have hB2z := vs_bank hR hP hB2
    have hs2 : StateOK P (R.ok P) 4 { s1 with banks := setAt B2 d s1.banks } := hs1.setBank hB2 d
    have hs2z := vs_state hR hP hs2 ht
    have hMI := mapIdx_M_banks_le hR hP hs1.banks_ok hs1.banks_length_le
      (Val.list [encN d, encBank R.enc B2])
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega)
    have hres : valSize (Val.list [encOptQ N2o, encBank R.enc B2]) ≤ 2 ^ 6 * SSB R P := by
      cases N2o with
      | none => simp only [encOptQ, valSize_list, listSize_cons, listSize_nil] at hB2z ⊢; omega
      | some N2 =>
        have h := vs_encQ R P (hq2 N2 rfl).1
        simp only [encOptQ, valSize_list, listSize_cons, listSize_nil] at hB2z ⊢; omega
    refine impl_letE_det (ev_eWithBanks (EvalsVal.var rfl)
      (ev_eSetAt hT (encBank R.enc) s1.banks d B2 (bankSizeBound P (R.bound P))
        (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hs1.banks_ok B hB))
        (BankOK.valSize_encBank_le (hR.enc_le P hP) hB2)
        (ev_get 5 (EvalsVal.var rfl) hsM rfl) (EvalsVal.var rfl)
        (ev_get 1 (EvalsVal.var rfl) (by omega) rfl) (by omega))
      hsM (by omega)) ?_
    refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) (by omega) rfl) ?_
    cases N2o with
    | none =>
      refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
      exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
    | some N2 =>
      obtain ⟨hN2q, hN20, hcache⟩ := hq2 N2 rfl
      have hN2z := vs_encQ R P hN2q
      have hcz := vs_int R P hcache (by omega)
      refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
      have heHP := eHP_le_R P
      refine impl_letE_det (ev_paramCall hC.w1.peHP hP hM (EvalsVal.var rfl)) ?_
      refine impl_letE_det (ev_roundMantQCall hC hP hM heHP hN2q
        (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_head' (EvalsVal.var rfl)
          (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) .nil))
          (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
              have := size_le_self P.eHP; omega))) ?_
      refine impl_letE_det (ev_countCorrectionCall hC hP hM hLd
        (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hXz rfl) .nil))
          (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
      simp only [countCorrection_withCache]
      rcases hcc : Learner.countCorrection P Ld with _ | L'
      · refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
        exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
      · have hL' : LearnerOK P 4 L' := hLd.countCorrection hj hcc
        have hL'z := vs_learner R P (hL'.mono (by norm_num) : LearnerOK P 16 L')
        refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
        simp only [Option.map_some]
        have hszc : 2 * (bitLen (roundMant P.eHP N2) + (P.eHP + 1)) + 64 ≤ M := by
          have := valSize_int_le_of_abs_lt hcache
          rw [valSize_int] at this
          omega
        have hpow : S_pow2 P.eHP ≤ M := by unfold S_pow2; have := size_le_self P.eHP; omega
        have hcqq : QOK P (gridVal P.eHP (roundMant P.eHP N2)) :=
          qok_gridVal (k := 2 * regBits P) hcache (by omega) (by omega)
        have hcqz := vs_encQ R P hcqq
        refine impl_letE_det (ev_normQ_grid hC (EvalsVal.var rfl)
          (ev_pow2 hT (EvalsVal.var rfl) hpow) hszc) ?_
        refine impl_letE_det (ev_inRangeACall hC hP hM hcqq
          (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
            (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
        refine impl_ite_encB (EvalsVal.var rfl) ?_
        cases hin : inRangeA P (gridVal P.eHP (roundMant P.eHP N2))
        · simp only [Bool.false_eq_true, if_false]
          exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
        · simp only [if_true]
          have hL'' : LearnerOK P 4 { L' with cache := roundMant P.eHP N2 } :=
            hL'.with_cache (by norm_num) hin
          have hL''z := vs_learner R P (hL''.mono (by norm_num) : LearnerOK P 16 _)
          have hs3 : StateOK P (R.ok P) 4 { { s1 with banks := setAt B2 d s1.banks } with
              learners := setAt { L' with cache := roundMant P.eHP N2 } d s1.learners } :=
            ⟨hs2.fpSeed_lt, hs2.fpVal_lt, by rw [length_setAt]; exact hs1.learners_length_le,
              hs2.banks_length_le, Aux.forall_mem_setAt _ hL'' _ _ hs1.learners_ok, hs2.banks_ok,
              hs2.leaf_nonneg, hs2.leaf_le⟩
          have hs3z := vs_state hR hP hs3 ht
          have hMIL := mapIdx_M_learners_le (R := R)
            (fun L hL => (hs1.learners_ok L hL).mono (by norm_num)) hs1.learners_length_le
            (Val.list [encN d, encLearner { L' with cache := roundMant P.eHP N2 }])
            (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega)
          have hL'e : valSize (encLearner L') ≤ M := by omega
          have hL''e : valSize (encLearner { L' with cache := roundMant P.eHP N2 }) ≤ M := by
            omega
          have hocz : valSize (Val.list [encLearner L']) ≤ M := by
            simp only [valSize_list, listSize_cons, listSize_nil]; omega
          have hMIL' : mapIdx_M encLearner s1.learners
              (Val.list [encN d, encLearner { L' with cache := roundMant P.eHP N2 }])
              (2 ^ 6 * P.calL ^ 3) ≤ M := by omega
          have hs2M := (vs_state hR hP hs2 ht).trans (show SSB R P ≤ M by omega)
          have hs3M := (vs_state hR hP hs3 ht).trans (show SSB R P ≤ M by omega)
          have hout := (vs_pair (vs_state hR hP hs3 ht) hNz).trans
            (show SSB R P + 2 ^ 4 * SSB R P + 3 ≤ M by omega)
          refine Implements.of_det (ev_list (.cons (ev_eWithLearners (EvalsVal.var rfl)
            (ev_eSetAt hT encLearner s1.learners d { L' with cache := roundMant P.eHP N2 }
              (2 ^ 6 * P.calL ^ 3)
              (fun L hL => valSize_encLearner_le16 ((hs1.learners_ok L hL).mono (by norm_num)))
              (valSize_encLearner_le16 (hL''.mono (by norm_num)))
              (ev_get 4 (EvalsVal.var rfl) hsM rfl) (EvalsVal.var rfl)
              (ev_eWithCache (ev_head' (EvalsVal.var rfl) hocz) (EvalsVal.var rfl) hL'e hL''e)
              hMIL')
            hs2M hs3M)
            (.cons (ev_get 3 (EvalsVal.var rfl) hXz rfl) .nil)) hout)

end F2e2e.C.Impl.T4
