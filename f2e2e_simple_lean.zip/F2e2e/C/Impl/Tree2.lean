import F2e2e.C.Impl.W6Facts
import F2e2e.Cost.Lib.MapB
import F2e2e.Cost.Arith.Basic

/-!
# W6, Tree2: Step 2 of the round (C-ALG `step2`, `F2e2e/C/Alg/Round.lean`), in the DSL

Step 2 of round `t + 1` for the update `(i, Δ)` (0-based coordinate `i`, paper coordinate `i + 1`):
the zero fingerprint (W2's `fpUpdate`), `Δ b_{i+1}` added to every row of every live bank (W5's
`addPhysBank`, mapped over the bank list with DSL-CALC's `mapB`), the terminal accumulator
`roundMant P.eHleaf (Δ²)` with its range check (W5's `roundMantQ`, `normQ`, `inRangeA`).

* `body_step2` (Idx `Idx.step2 = 250`): input `[encStreamParams P, encState R.enc s, encN i, encZ Δ]`,
  output `[encState R.enc s', encB z]` for `(s', z) = step2 P i Δ s`;
* `body_step2Elem` (251): the element routine of the bank map, `[B, [p, i1, Δ]] ↦ addPhysBank`;
* the bank map itself: `body_mapBStep 251` at 252, `body_mapB 252` at 253.

Main theorem: `step2_val` (deterministic `EvalsVal`), from the contracts (`Contracts R prog M`), the
invariant `StateInv P (R.ok P) s`, `s.t ≤ P.m`, `i < P.n`, `|Δ| ≤ 2U`, and `Mv R P ≤ M`.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

namespace Idx

/-- Step 2 (entry). -/
abbrev step2 : ℕ := 250
/-- Element routine of the bank map of Step 2. -/
abbrev step2Elem : ℕ := 251
/-- Loop step of the bank map of Step 2. -/
abbrev step2MapStep : ℕ := 252
/-- The bank map of Step 2. -/
abbrev step2Map : ℕ := 253

end Idx

/-! ## The DSL code -/

/-- Element routine: `[B, [p, i1, Δ]] ↦ addPhysBank [p, B, i1, Δ]`. -/
def body_step2Elem : Expr :=
  Expr.call Idx.addPhysBank (eList [eGet 0 (eGet 1 (Expr.var 0)), eGet 0 (Expr.var 0),
    eGet 1 (eGet 1 (Expr.var 0)), eGet 2 (eGet 1 (Expr.var 0))])

/-- The bank map of Step 2 (DSL-CALC's `mapB`). -/
def body_step2Map : Expr := body_mapB Idx.step2MapStep

/-- Step 2. Environment `[X]`, `X = [p, st, i, Δ]`; the let-bound values are, in order:
`p, st, i1 = i + 1, Δ, q = P.q, fp, banks', eh = eHleaf, leaf, gq = encQ (leaf / 2^eh), inr`. -/
def body_step2 : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|
  Expr.letE (eGet 1 (Expr.var 1)) <|
  Expr.letE (Expr.bin BinOp.add (eGet 2 (Expr.var 2)) (Expr.lit 1)) <|
  Expr.letE (eGet 3 (Expr.var 3)) <|
  Expr.letE (Expr.call Idx.pq (Expr.var 3)) <|
  Expr.letE (Expr.call Idx.fpUpdate
    (eList [Expr.var 0, eGet 2 (Expr.var 3), eGet 3 (Expr.var 3), Expr.var 2, Expr.var 1])) <|
  Expr.letE (Expr.call Idx.step2Map
    (eList [eGet 5 (Expr.var 4), eList [Expr.var 5, Expr.var 3, Expr.var 2]])) <|
  Expr.letE (Expr.call Idx.peHleaf (Expr.var 6)) <|
  Expr.letE (Expr.call Idx.roundMantQ
    (eList [Expr.var 0, eList [Expr.bin BinOp.mul (Expr.var 4) (Expr.var 4), Expr.lit 1]])) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.var 0, Expr.call Cost.Idx.pow2 (Expr.var 1)])) <|
  Expr.letE (Expr.call Idx.inRangeA (eList [Expr.var 9, Expr.var 0])) <|
  Expr.ite (Expr.var 0)
    (eList [eList [eGet 0 (Expr.var 9), eGet 1 (Expr.var 9), eGet 2 (Expr.var 9), Expr.var 5,
        eGet 4 (Expr.var 9), Expr.var 4, Expr.var 2], Expr.bin BinOp.eq (Expr.var 5) (Expr.lit 0)])
    (eList [eList [eGet 0 (Expr.var 9), Expr.lit 1, eGet 2 (Expr.var 9), Expr.var 5,
        eGet 4 (Expr.var 9), Expr.var 4, eGet 6 (Expr.var 9)],
      Expr.bin BinOp.eq (Expr.var 5) (Expr.lit 0)])

/-- The program contains Step 2's routines and the library routines they use. -/
structure Tree2Lib (prog : List Expr) : Prop where
  step2Elem : prog[Idx.step2Elem]? = some body_step2Elem
  step2MapStep : prog[Idx.step2MapStep]? = some (body_mapBStep Idx.step2Elem)
  step2Map : prog[Idx.step2Map]? = some body_step2Map
  reverse : prog[Cost.Idx.reverse]? = some body_reverse
  revAppendStep : prog[Cost.Idx.revAppendStep]? = some body_revAppendStep
  pow2 : prog[Cost.Idx.pow2]? = some body_pow2
  pow2Step : prog[Cost.Idx.pow2Step]? = some body_pow2Step

/-! ## The element routine and the bank map -/

theorem step2Elem_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B)
    {i : ℕ} (hi1 : 1 ≤ i) (hin : i ≤ P.n) {Δ : ℤ} (hΔ : |Δ| ≤ 2 * (P.U : ℤ))
    (hsz : valSize (Val.list [encBank R.enc B, Val.list [encStreamParams P, encN i, encZ Δ]]) ≤ M) :
    EvalsVal prog M [Val.list [encBank R.enc B, Val.list [encStreamParams P, encN i, encZ Δ]]] []
      (.inl body_step2Elem) (encBank R.enc (B.mapRows (Row.addPhys P i Δ))) := by
  obtain ⟨bA, hbA, hA⟩ := hC.w5.addPhysBank
  have hY := EvalsVal.var (prog := prog) (M := M)
    (env := [Val.list [encBank R.enc B, Val.list [encStreamParams P, encN i, encZ Δ]]]) (i := 0) rfl
  have hEsz : valSize (Val.list [encStreamParams P, encN i, encZ Δ]) ≤ M :=
    (valSize_of_getElem?_le (k := 1) (l := [encBank R.enc B, Val.list [encStreamParams P, encN i,
      encZ Δ]]) rfl).trans hsz
  have hE := ev_get 1 hY hsz rfl
  have h1 := ev_get 0 hE hEsz rfl
  have h2 := ev_get 0 hY hsz rfl
  have h3 := ev_get 1 hE hEsz rfl
  have h4 := ev_get 2 hE hEsz rfl
  have hsz' : valSize (Val.list [encStreamParams P, encBank R.enc B, encN i, encZ Δ]) ≤ M := by
    refine le_trans ?_ hsz
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have harg := ev_list (prog := prog) (M := M)
    (.cons h1 (.cons h2 (.cons h3 (.cons h4 .nil)))) hsz'
  exact evalsVal_call_det hbA harg (hA P B i Δ hP hB hi1 hin hΔ hM)

/-! ## Size facts for Step 2 -/

theorem fpUpdate_lt (P : StreamParams) (seed val i : ℕ) (Δ : ℤ) (hq : 0 < P.q) :
    fpUpdate P seed val i Δ < P.q := by
  unfold fpUpdate
  have hq' : (0 : ℤ) < P.q := by exact_mod_cast hq
  have h1 := Int.emod_nonneg ((val : ℤ) + Δ % (P.q : ℤ) * ((seed ^ i % P.q : ℕ) : ℤ)) (ne_of_gt hq')
  have h2 := Int.emod_lt_of_pos ((val : ℤ) + Δ % (P.q : ℤ) * ((seed ^ i % P.q : ℕ) : ℤ)) hq'
  omega

theorem roundMant_sq_nonneg (q : ℕ) (Δ : ℤ) : 0 ≤ roundMant q ((Δ : ℚ) ^ 2) := by
  unfold roundMant
  apply Int.floor_nonneg.mpr
  positivity

theorem roundMant_sq_le (q : ℕ) (Δ : ℤ) : roundMant q ((Δ : ℚ) ^ 2) ≤ Δ ^ 2 * 2 ^ q := by
  unfold roundMant
  have h : ((Δ : ℚ) ^ 2 * 2 ^ q + 1 / 2) < ((Δ ^ 2 * 2 ^ q + 1 : ℤ) : ℚ) := by push_cast; linarith
  have := Int.floor_lt.mpr h
  omega

/-- The terminal accumulator of Step 2 is a nonnegative integer `< 2^(2 c_P + 2 + q_leaf)`. -/
theorem leaf_bound (P : StreamParams) {Δ : ℤ} (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    0 ≤ roundMant P.eHleaf ((Δ : ℚ) ^ 2) ∧
      roundMant P.eHleaf ((Δ : ℚ) ^ 2) < 2 ^ (2 * cP P + 2 + P.eHleaf) := by
  refine ⟨roundMant_sq_nonneg _ _, ?_⟩
  have h1 := roundMant_sq_le P.eHleaf Δ
  have h3 := sq_update_lt P hΔ
  have h4 : (0 : ℤ) < 2 ^ P.eHleaf := by positivity
  calc roundMant P.eHleaf ((Δ : ℚ) ^ 2) ≤ Δ ^ 2 * 2 ^ P.eHleaf := h1
    _ = (Δ * Δ) * 2 ^ P.eHleaf := by ring
    _ < 2 ^ (2 * cP P + 2) * 2 ^ P.eHleaf := mul_lt_mul_of_pos_right h3 h4
    _ = 2 ^ (2 * cP P + 2 + P.eHleaf) := by ring

/-! ## The bank map -/

theorem step2Map_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree2Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {banks : List Bank} (hB : ∀ B ∈ banks, BankOK P (R.ok P) B)
    (hlen : banks.length ≤ P.H) {i : ℕ} (hi1 : 1 ≤ i) (hin : i ≤ P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ))
    (hext : valSize (Val.list [encStreamParams P, encN i, encZ Δ]) ≤ 8 * P.calL + 20) :
    EvalsVal prog M
      [Val.list [encL (encBank R.enc) banks, Val.list [encStreamParams P, encN i, encZ Δ]]] []
      (.inl body_step2Map) (encL (encBank R.enc) (banks.map (Bank.mapRows (Row.addPhys P i Δ)))) := by
  have hada := hR.enc_le P hP
  have hBsz : ∀ B ∈ banks, valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) := fun B hBm =>
    BankOK.valSize_encBank_le hada (hB B hBm)
  have hL : valSize (encL (encBank R.enc) banks) ≤
      1 + banks.length * (bankSizeBound P (R.bound P) + 1) := valSize_encL_le _ _ _ hBsz
  have hHV : banks.length * (bankSizeBound P (R.bound P) + 1) ≤
      P.H * (bankSizeBound P (R.bound P) + 1) := Nat.mul_le_mul_right _ hlen
  have hH1 : 1 ≤ P.H := P.one_le_H
  have hVBH : bankSizeBound P (R.bound P) + 1 ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
    Nat.le_mul_of_pos_left _ hH1
  have hSSB : stateSizeBound P (R.bound P) = P.H * (bankSizeBound P (R.bound P) + 1) +
      P.H * (2 ^ 6 * P.calL ^ 3 + 1) + 2 ^ 5 * P.calL ^ 3 := rfl
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hMv : Mv R P = 2 ^ 32 * stateSizeBound P (R.bound P) := rfl
  have hMB : mapB_M (encBank R.enc) banks (Val.list [encStreamParams P, encN i, encZ Δ])
      (bankSizeBound P (R.bound P)) ≤ M := by
    unfold mapB_M
    omega
  have himpl := mapB_impl hT.step2MapStep hT.step2Elem hT.reverse hT.revAppendStep
    (encBank R.enc) (encBank R.enc) (Val.list [encStreamParams P, encN i, encZ Δ])
    (fun B => BitProg.pure (B.mapRows (Row.addPhys P i Δ))) banks (bankSizeBound P (R.bound P))
    (fun B hBm => Implements.of_det (step2Elem_val hC hP hM (hB B hBm) hi1 hin hΔ (by
      have h1 := hBsz B hBm
      simp only [valSize_list, listSize_cons, listSize_nil] at hext ⊢
      omega)))
    (fun B hBm bits b hrun => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hrun
      exact BankOK.valSize_encBank_le hada (bankOK_addPhys' (hB B hBm) i Δ))
    hMB
  rw [mapB_pure_eq] at himpl
  exact himpl [] _ rfl

/-! ## Step 2: the two branches -/

theorem step2_snd (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).2 = (fpUpdate P s.fpSeed s.fpVal (i + 1) Δ == 0) := by
  simp only [step2]
  split <;> rfl

theorem step2_t (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) : (step2 P i Δ s).1.t = s.t := by
  simp only [step2]
  split <;> rfl

theorem encState_step2_of_inRange (adaEnc : F2e2e.B.AdaState → Val) (P : StreamParams) (i : ℕ)
    (Δ : ℤ) (s : State)
    (hr : inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) = true) :
    encState adaEnc (step2 P i Δ s).1 = Val.list [Val.int (s.t : ℤ),
      Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ),
      Val.int (fpUpdate P s.fpSeed s.fpVal (i + 1) Δ : ℤ), Val.list (s.learners.map encLearner),
      encL (encBank adaEnc) (s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ))),
      Val.int (roundMant P.eHleaf ((Δ : ℚ) ^ 2))] := by
  simp only [step2]
  rw [if_pos hr]
  rfl

theorem encState_step2_of_not_inRange (adaEnc : F2e2e.B.AdaState → Val) (P : StreamParams) (i : ℕ)
    (Δ : ℤ) (s : State)
    (hr : inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) = false) :
    encState adaEnc (step2 P i Δ s).1 = Val.list [Val.int (s.t : ℤ), Val.int 1,
      Val.int (s.fpSeed : ℤ),
      Val.int (fpUpdate P s.fpSeed s.fpVal (i + 1) Δ : ℤ), Val.list (s.learners.map encLearner),
      encL (encBank adaEnc) (s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ))),
      Val.int s.leaf] := by
  simp only [step2]
  rw [if_neg (by rw [hr]; decide)]
  rfl

theorem encB_beq_zero (n : ℕ) :
    Val.int (if ((n : ℤ) = 0) then 1 else 0) = encB (n == 0) := by
  by_cases h : n = 0 <;> simp [encB, h]


theorem step2_banks (P : StreamParams) (i : ℕ) (Δ : ℤ) (s : State) :
    (step2 P i Δ s).1.banks = s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ)) := by
  simp only [step2]
  split <;> rfl

theorem valSize_banks_le_encState (adaEnc : F2e2e.B.AdaState → Val) (s : State) :
    valSize (encL (encBank adaEnc) s.banks) ≤ valSize (encState adaEnc s) := by
  simp only [encState, encL, valSize_list, listSize_cons, listSize_nil]
  omega

theorem valSize_pair (a b : Val) : valSize (Val.list [a, b]) = valSize a + valSize b + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-! ## Step 2 -/

/-- **Step 2 in the DSL** (deterministic): on `[encStreamParams P, encState R.enc s, encN i, encZ Δ]`
the body `body_step2` evaluates to `[encState R.enc s', encB z]` for `(s', z) = step2 P i Δ s`. -/
theorem step2_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    (hT : Tree2Lib prog) {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {s : State}
    (hs : StateInv P (R.ok P) s) (ht : s.t ≤ P.m) {i : ℕ} (hi : i < P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    EvalsVal prog M [Val.list [encStreamParams P, encState R.enc s, encN i, encZ Δ]] []
      (.inl body_step2)
      (Val.list [encState R.enc (step2 P i Δ s).1, encB (step2 P i Δ s).2]) := by
  obtain ⟨bq, hbq, hq⟩ := hC.w1.pq
  obtain ⟨bfp, hbfp, hfp⟩ := hC.w2.fpUpdate
  obtain ⟨beh, hbeh, heh⟩ := hC.w1.peHleaf
  obtain ⟨brm, hbrm, hrm⟩ := hC.w5.roundMantQ
  obtain ⟨bnq, hbnq, hnq⟩ := hC.normQ
  obtain ⟨bir, hbir, hir⟩ := hC.w5.inRangeA
  have hada := hR.enc_le P hP
  have hs1 : StateOK P (R.ok P) 4 s := hs.1
  -- size facts
  have hSSB := stateSizeBound_ge P (R.bound P)
  have hMv : Mv R P = 2 ^ 32 * stateSizeBound P (R.bound P) := rfl
  have hc1 := hundred_le_calL P
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hcP := cP_add_hundred_le P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs1 ht
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hn := n_add_two_le P
  have hisz : valSize (encN i) ≤ cP P + 1 := valSize_encN_le_of_lt (by omega)
  have hi1sz : valSize (encN (i + 1)) ≤ cP P + 1 := valSize_encN_le_of_lt (by omega)
  have hΔsz : valSize (encZ Δ) ≤ cP P + 2 := valSize_int_le_of_abs_lt (abs_update_lt P hΔ)
  have hseed := hs1.fpSeed_lt
  have hval := hs1.fpVal_lt
  have hqle := q_le P
  have h2p : 0 < 2 ^ (3 * P.calL) := by positivity
  have hqlt : P.q < 2 ^ (3 * P.calL + 1) := by rw [pow_succ]; omega
  have hqsz : valSize (encN P.q) ≤ 3 * P.calL + 2 := valSize_encN_le_of_lt hqlt
  have hfplt : fpUpdate P s.fpSeed s.fpVal (i + 1) Δ < P.q := fpUpdate_lt P _ _ _ _ (by omega)
  have hfpsz : valSize (encN (fpUpdate P s.fpSeed s.fpVal (i + 1) Δ)) ≤ 3 * P.calL + 2 :=
    valSize_encN_le_of_lt (by omega)
  have hseedsz : valSize (encN s.fpSeed) ≤ 3 * P.calL + 2 := valSize_encN_le_of_lt (by omega)
  have hvalsz : valSize (encN s.fpVal) ≤ 3 * P.calL + 2 := valSize_encN_le_of_lt (by omega)
  have hehle := eHleaf_le P
  have hehsz : valSize (encN P.eHleaf) ≤ 20 * P.calL ^ 2 + 1 := by
    rw [valSize_encN]; have := size_le_self P.eHleaf; omega
  obtain ⟨hl0, hllt⟩ := leaf_bound P hΔ
  have hlabs : |roundMant P.eHleaf ((Δ : ℚ) ^ 2)| < 2 ^ (2 * cP P + 2 + P.eHleaf) := by
    rw [abs_of_nonneg hl0]; exact hllt
  have hlbit : bitLen (roundMant P.eHleaf ((Δ : ℚ) ^ 2)) ≤ 2 * cP P + 2 + P.eHleaf :=
    bitLen_le_of_abs_lt hlabs
  have hsqabs : |Δ * Δ| < 2 ^ (2 * cP P + 2) := by
    rw [abs_of_nonneg (mul_self_nonneg Δ)]; exact sq_update_lt P hΔ
  have hsqsz : valSize (Val.int (Δ * Δ)) ≤ 2 * cP P + 3 := valSize_int_le_of_abs_lt hsqabs
  have hreg : 2 * cP P + 2 + P.eHleaf ≤ 4 * regBits P := by unfold regBits; omega
  have hehReg : P.eHleaf ≤ regBits P := by unfold regBits; omega
  have hQsq : QOK P ((Δ * Δ : ℤ) : ℚ) := qok_intCast hsqabs (by omega)
  have hQgrid : QOK P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) :=
    qok_gridVal hlabs hreg (by omega)
  have hgqsz := valSize_encQ_le_of_QOK hQgrid
  have hregM : 8 * regBits P + 7 + 5 * P.calL + 20 ≤ M := by unfold regBits; omega
  -- the output state
  have hinv2 := step2_ok' (by norm_num) hs1 i Δ
  have ht2 : (step2 P i Δ s).1.t ≤ P.m := by rw [step2_t]; exact ht
  have hst2 : valSize (encState R.enc (step2 P i Δ s).1) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hinv2 ht2
  -- the input
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s, encN i, encZ Δ]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hext : valSize (Val.list [encStreamParams P, encN (i + 1), encZ Δ]) ≤ 8 * P.calL + 20 := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hbsz := valSize_banks_le_encState R.enc s
  unfold body_step2
  -- 1. `p`
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  -- 2. `st`
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  -- 3. `i1 = i + 1`
  refine ev_letE (va := encN (i + 1)) ?_ ?_
  · have he : encN (i + 1) = Val.int ((i : ℤ) + 1) := by simp [encN]
    have hsz1 : valSize (Val.int ((i : ℤ) + 1)) ≤ M := by rw [← he]; omega
    rw [he]
    exact ev_add (ev_get 2 (EvalsVal.var rfl) hXsz rfl) (EvalsVal.lit' (by simp; omega)) hsz1
  -- 4. `Δ`
  refine ev_letE (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  -- 5. `q`
  refine ev_letE (evalsVal_call_det hbq (EvalsVal.var rfl) (hq P hP hM)) ?_
  -- 6. the fingerprint
  refine ev_letE (evalsVal_call_det hbfp
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) .nil)))))
      (show valSize (Val.list [encN P.q, encN s.fpSeed, encN s.fpVal, encN (i + 1), encZ Δ]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]
        omega))
    (hfp P s.fpSeed s.fpVal (i + 1) Δ hP hseed hval (by omega) (by omega) hΔ hM)) ?_
  -- 7. the banks
  refine ev_letE (evalsVal_call_det hT.step2Map
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        .nil))) (show valSize (Val.list [encStreamParams P, encN (i + 1), encZ Δ]) ≤ M by omega))
        .nil))
      (show valSize (Val.list [encL (encBank R.enc) s.banks,
          Val.list [encStreamParams P, encN (i + 1), encZ Δ]]) ≤ M by
        rw [valSize_pair]
        omega))
    (step2Map_val hR hC hT hP hM hs1.banks_ok hs1.banks_length_le (by omega) (by omega) hΔ hext)) ?_
  -- 8. `eHleaf`
  refine ev_letE (evalsVal_call_det hbeh (EvalsVal.var rfl) (heh P hP hM)) ?_
  -- 9. the terminal accumulator
  refine ev_letE (va := Val.int (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) ?_ ?_
  · have hc := hrm P P.eHleaf ((Δ * Δ : ℤ) : ℚ) hP hehReg hQsq hM
    have hsqcast : (((Δ * Δ : ℤ)) : ℚ) = (Δ : ℚ) ^ 2 := by push_cast; ring
    rw [encQ_intCast, hsqcast] at hc
    exact evalsVal_call_det hbrm
      (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_list (.cons (ev_mul (EvalsVal.var rfl)
        (EvalsVal.var rfl) (by omega)) (.cons (EvalsVal.lit' (by simp; omega)) .nil))
        (show valSize (Val.list [Val.int (Δ * Δ), Val.int 1]) ≤ M by
          simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one] at hsqsz ⊢
          omega)) .nil))
        (show valSize (Val.list [encN P.eHleaf, Val.list [Val.int (Δ * Δ), Val.int 1]]) ≤ M by
          simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one] at hsqsz ⊢
          omega))
      hc
  -- 10. the grid value `leaf / 2^eHleaf`
  refine ev_letE (va := encQ (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)))) ?_ ?_
  · have hpowS : S_pow2 P.eHleaf ≤ M := by
      unfold S_pow2; have := size_le_self P.eHleaf; omega
    have hpow := ((pow2_spec hT.pow2Step P.eHleaf 0).toVal).mono_M hpowS
    have hpb : bitLen (((2 ^ P.eHleaf : ℕ)) : ℤ) ≤ P.eHleaf + 1 := by
      rw [bitLen_natCast]
      apply Nat.size_le.mpr
      have : 0 < 2 ^ P.eHleaf := by positivity
      rw [pow_succ]; omega
    have hc := hnq (roundMant P.eHleaf ((Δ : ℚ) ^ 2)) ((2 ^ P.eHleaf : ℕ) : ℤ) (by positivity)
      (by omega)
    have hgcast : ((roundMant P.eHleaf ((Δ : ℚ) ^ 2) : ℤ) : ℚ) / ((((2 ^ P.eHleaf : ℕ)) : ℤ) : ℚ) =
        gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)) := by
      unfold gridVal; push_cast; rfl
    rw [hgcast] at hc
    exact evalsVal_call_det hbnq (ev_list (.cons (EvalsVal.var rfl)
      (.cons (evalsVal_call_det hT.pow2 (EvalsVal.var rfl) hpow) .nil))
      (show valSize (Val.list [Val.int (roundMant P.eHleaf ((Δ : ℚ) ^ 2)),
          encN (2 ^ P.eHleaf)]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, encN] at hpb ⊢
        omega)) hc
  -- 11. the range check
  refine ev_letE (evalsVal_call_det hbir (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    .nil)) (show valSize (Val.list [encStreamParams P,
      encQ (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)))]) ≤ M by
        rw [valSize_pair]; omega)) (hir P _ hP hQgrid hM)) ?_
  -- the branch
  refine ev_ite_encB (EvalsVal.var rfl) ?_
  rw [step2_snd, ← encB_beq_zero]
  have hz : valSize (Val.int (if ((fpUpdate P s.fpSeed s.fpVal (i + 1) Δ : ℕ) : ℤ) = 0 then 1 else 0))
      ≤ 2 := by split_ifs <;> simp
  cases hr : inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)))
  · rw [encState_step2_of_not_inRange R.enc P i Δ s hr] at hst2 ⊢
    simp only [Bool.false_eq_true, if_false]
    refine ev_list (.cons ?_ (.cons (ev_eq (EvalsVal.var rfl) (EvalsVal.lit' (by simp; omega)) h2M)
      .nil)) (by rw [valSize_pair]; omega)
    exact ev_list
      (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.lit' (by simp; omega))
        (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
            (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl) .nil)))))))
      (hst2.trans hSM)
  · rw [encState_step2_of_inRange R.enc P i Δ s hr] at hst2 ⊢
    simp only [if_true]
    refine ev_list (.cons ?_ (.cons (ev_eq (EvalsVal.var rfl) (EvalsVal.lit' (by simp; omega)) h2M)
      .nil)) (by rw [valSize_pair]; omega)
    exact ev_list
      (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 1 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
            (.cons (EvalsVal.var rfl) .nil)))))))
      (hst2.trans hSM)

end F2e2e.C.Impl.W6
