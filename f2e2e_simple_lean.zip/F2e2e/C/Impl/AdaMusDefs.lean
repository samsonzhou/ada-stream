import F2e2e.C.Impl.AdaWater

/-!
# ADA module (W4): the integer model of the predictions `μ_0, …, μ_p`

`musZ A scores vals` (pairs `(num, den)`): for a learned block `j < p` with scores `g = scores[j]` and
values `v = vals[j]`, `(predNum, 2^{qA} n cd D)` at the exact water level `(N, D) = wlLevel cn cd g`
(`c = scoreScale A = cn/cd`); for the anchor `j = p`, `(∑ v, 2^{qA} n_p)`.
Also: `ValsOKA` (well-formed query tables), `encOptSt` (optional states), `Idx.adaMusR` (640).
-/

namespace F2e2e.Cost.Idx

/-- `adaMusR : [pub, scores, vals] ↦ the predictions (pairs `[num, den]`)`. -/
abbrev adaMusR : ℕ := 640

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## Definitions -/

/-- Well-formed query tables of the instance `A` (`ValsOK P vals ↔ ValsOKA (bankAda P) vals`). -/
def ValsOKA (A : AdaParams) (vals : List (List ℕ)) : Prop :=
  vals.map List.length = A.blockSizes ∧ ∀ blk ∈ vals, ∀ v ∈ blk, v ≤ 2 ^ A.qA

theorem valsOK_iff (P : F2e2e.StreamParams) (vals : List (List ℕ)) :
    ValsOK P vals ↔ ValsOKA (C.Alg.bankAda P) vals := Iff.rfl

/-- Optional states: `[]` or `[adaEnc st]`. -/
def encOptSt : Option AdaState → Val
  | none => Val.list []
  | some st => Val.list [adaEnc st]

/-- The learned-block pair `(num, den)`. -/
def muLZ (A : AdaParams) (g : List ℤ) (v : List ℕ) : ℤ × ℤ :=
  match wlLevel (scoreScale A).num ((scoreScale A).den : ℤ) g with
  | some r => (predNum (scoreScale A).num ((scoreScale A).den : ℤ) r.1 r.2 g v,
      2 ^ A.qA * g.length * ((scoreScale A).den : ℤ) * r.2)
  | none => (0, 1)

/-- The anchor pair `(∑ v, 2^{qA} n_p)`. -/
def muAZ (A : AdaParams) (v : List ℕ) : ℤ × ℤ :=
  ((v.map fun x : ℕ => (x : ℤ)).sum, 2 ^ A.qA * v.length)

/-- **The predictions in integers.** -/
def musZ (A : AdaParams) (scores : List (List ℤ)) (vals : List (List ℕ)) : List (ℤ × ℤ) :=
  (List.range (A.p + 1)).map fun j =>
    if j < A.p then muLZ A (scores.getD j []) (vals.getD j []) else muAZ A (vals.getD j [])

theorem musZ_length (A : AdaParams) (scores : List (List ℤ)) (vals : List (List ℕ)) :
    (musZ A scores vals).length = A.p + 1 := by
  simp [musZ]

end F2e2e.C.Impl
