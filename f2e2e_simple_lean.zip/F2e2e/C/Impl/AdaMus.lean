import F2e2e.C.Impl.AdaWater2
import F2e2e.C.Impl.AdaMusSpec

/-!
# ADA module (W4), part 7: the predictions `μ_0, …, μ_p` (interface)

`musZ_spec`: the integer pairs `musZ` (`AdaMusDefs.lean`) represent `adaMus A st vals` (positive
denominators); `musZ_bits`: their bit lengths (both proved by A-ARCH in `AdaMusSpec.lean`). DSL
routine `adaMusR` (Idx 640, implementation `AdaWater2.lean`):
`[pub, scores, vals] ↦ encL encPZ (musZ A st.scores vals)` (`adaMusR_val`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-- **The integer predictions represent `adaMus`** (positive denominators). -/
theorem musZ_spec {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) :
    ∀ j, j < A.p + 1 → 0 < ((musZ A st.scores vals).getD j (0, 1)).2 ∧
      ((((musZ A st.scores vals).getD j (0, 1)).1 : ℚ) /
        ((musZ A st.scores vals).getD j (0, 1)).2) = (adaMus A st vals).getD j 0 :=
  musZ_spec_proof hok hv hpos

/-- **Bit lengths of the integer predictions.** -/
theorem musZ_bits {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) :
    ∀ r ∈ musZ A st.scores vals, bitLen r.1 ≤ 2 ^ 6 * (adaZ A + 16) ∧
      bitLen r.2 ≤ 2 ^ 6 * (adaZ A + 16) :=
  musZ_bits_proof hok hv

/-! ## The DSL routine -/

/-- `adaMusR : [pub, scores, vals] ↦ encL encPZ (musZ A st.scores vals)`. -/
def body_adaMusR : Expr := body_adaMusRImpl

/-- The lookups needed by `adaMusR`: the entry 640 and all routines it calls. -/
def MusLib (prog : List Expr) : Prop := prog[Idx.adaMusR]? = some body_adaMusR ∧ MusLibImpl prog

/-- **Spec of `adaMusR`.** -/
theorem adaMusR_val {prog : List Expr} {M : ℕ} (hlib : MusLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusR) (encL encPZ (musZ A st.scores vals)) :=
  adaMusRImpl_val hlib.2 hbs hT hpos hok hv hM

end F2e2e.C.Impl
