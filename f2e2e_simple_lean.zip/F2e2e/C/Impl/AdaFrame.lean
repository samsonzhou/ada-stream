import F2e2e.C.Impl.AdaRep
import F2e2e.C.Impl.AdaSampler
import F2e2e.Cost.Arith.Helpers
import F2e2e.Cost.Lib.ZipWithAdd
import F2e2e.Cost.Lib.Get
import F2e2e.Cost.Lib.Set
import F2e2e.Cost.Lib.Length
import F2e2e.Cost.Lib.Replicate
import F2e2e.Cost.Lib.TakeDrop
import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.MapB

/-!
# ADA module (W4), part 2: the proof frame

Generic tools for W4's DSL routines (package L: `EvalsVal` / `Implements`):

* `implements_loop` : **loops with fresh bits** following a reference recursion
  `R s = (q s).bind (Sum.elim R pure)` (one iteration `q s : BitProg (σ ⊕ τ)`, continue/stop);
* `eAtN` / `evalsVal_atN` : field access in a list value; `eList` / `evalsVal_list` : list building;
* `ZE` : integer expressions with leaves (arbitrary deterministic sub-evaluations), compiled to DSL
  code; `ZE.spec` needs only the crude bit-length bound `ZE.mx e + 1 ≤ M`;
* `ListLib` + `get_val`, `set_val`, `length_val`, `replicate_val`, `reverse_val`, `take_val` : the
  library list routines in `EvalsVal` form;
* `SampLib`, `eDraw`, `draw_impl` : one fresh lattice noise of kind `κ`, read from the parameter
  record `adaPubEnc A`; `adaDraw_run_abs_le` : its support `|k| ≤ K_s`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section Frame

variable {prog : List Expr} {M : ℕ}

/-! ## Loops with fresh bits -/

/-- Encoding of a loop-body result: `[1, enc s]` (continue with `s`) or `[0, encOut t]` (stop with
the output `t`). -/
def loopEnc {σ τ : Type} (enc : σ → Val) (encOut : τ → Val) : σ ⊕ τ → Val
  | Sum.inl s => Val.list [Val.int 1, enc s]
  | Sum.inr t => Val.list [Val.int 0, encOut t]

/-- The iterations of `loop i` follow the reference recursion `R`. -/
theorem loop_iter {σ τ : Type} {i : ℕ} {body : Expr} (hbody : prog[i]? = some body)
    (enc : σ → Val) (encOut : τ → Val) (Inv : σ → Prop) (μ : σ → ℕ) (R : σ → BitProg τ)
    (q : σ → BitProg (σ ⊕ τ))
    (hq : ∀ s, Inv s → Implements prog M [enc s] body (loopEnc enc encOut) (q s))
    (hR : ∀ s, Inv s → R s = (q s).bind (Sum.elim R BitProg.pure))
    (hinv : ∀ s, Inv s → ∀ bits s', (q s).run bits = some (Sum.inl s', []) → Inv s' ∧ μ s' < μ s) :
    ∀ s, Inv s → ∀ bits t, (R s).run bits = some (t, []) →
      EvalsVal prog M [] bits (.inr (i, enc s)) (encOut t) := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs bits t hrun
    rw [hR s hs] at hrun
    obtain ⟨b₁, b₂, r, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp hrun
    have hb := hq s hs b₁ r h1
    cases r with
    | inl s' =>
      obtain ⟨hs', hlt⟩ := hinv s hs b₁ s' h1
      simp only [Sum.elim_inl] at h2
      exact EvalsVal.cont hbody hb one_ne_zero (ih (μ s') (by omega) s' rfl hs' b₂ t h2)
    | inr t' =>
      simp only [Sum.elim_inr] at h2
      obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
      rw [List.append_nil]
      exact EvalsVal.stop hbody hb

/-- **Loop rule with fresh bits.** If one iteration of the body implements `q s` (continue with
`s'` or stop with `t`), the reference program unfolds as `R s = (q s).bind (Sum.elim R pure)`, and
continuing preserves an invariant and decreases a measure, then `loop i a` implements `R s₀`. -/
theorem implements_loop {σ τ : Type} {env : List Val} {i : ℕ} {a body : Expr}
    (hbody : prog[i]? = some body) (enc : σ → Val) (encOut : τ → Val) (Inv : σ → Prop)
    (μ : σ → ℕ) (R : σ → BitProg τ) (q : σ → BitProg (σ ⊕ τ))
    (hq : ∀ s, Inv s → Implements prog M [enc s] body (loopEnc enc encOut) (q s))
    (hR : ∀ s, Inv s → R s = (q s).bind (Sum.elim R BitProg.pure))
    (hinv : ∀ s, Inv s → ∀ bits s', (q s).run bits = some (Sum.inl s', []) → Inv s' ∧ μ s' < μ s)
    {s₀ : σ} (hs₀ : Inv s₀) (ha : EvalsVal prog M env [] (.inl a) (enc s₀)) :
    Implements prog M env (Expr.loop i a) encOut (R s₀) := by
  intro bits t hrun
  have := EvalsVal.loop ha (loop_iter hbody enc encOut Inv μ R q hq hR hinv s₀ hs₀ bits t hrun)
  simpa using this

/-! ## Field access and list building -/

/-- `tail^n e`. -/
def eTlN : ℕ → Expr → Expr
  | 0, e => e
  | n + 1, e => eTl (eTlN n e)

/-- Element `n` of a list. -/
def eAtN (n : ℕ) (e : Expr) : Expr := eHd (eTlN n e)

theorem listSize_drop_le (l : List Val) (n : ℕ) : listSize (l.drop n) ≤ listSize l :=
  listSize_le_of_suffix (List.drop_suffix n l)

theorem valSize_getElem_lt {l : List Val} {n : ℕ} (hn : n < l.length) :
    valSize l[n] < valSize (Val.list l) :=
  valSize_lt_of_mem (List.getElem_mem hn)

theorem evalsVal_tlN {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsVal prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M) :
    ∀ n, n ≤ l.length → EvalsVal prog M env bits (.inl (eTlN n e)) (Val.list (l.drop n))
  | 0, _ => by simpa [eTlN] using he
  | n + 1, hn => by
    have ih := evalsVal_tlN he hM n (by omega)
    rw [List.drop_eq_getElem_cons (by omega)] at ih
    show EvalsVal prog M env bits (.inl (eTl (eTlN n e))) _
    refine EvalsVal.tail ih (le_trans ?_ hM)
    simp only [valSize_list]
    have := listSize_drop_le l (n + 1)
    omega

/-- **Field access**: element `n` of a list value. -/
theorem evalsVal_atN {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsVal prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M) {n : ℕ}
    (hn : n < l.length) : EvalsVal prog M env bits (.inl (eAtN n e)) l[n] := by
  have h := evalsVal_tlN he hM n hn.le
  rw [List.drop_eq_getElem_cons hn] at h
  exact EvalsVal.head h (le_trans (valSize_getElem_lt hn).le hM)

/-- **Field access** with the element given by `getElem?`. -/
theorem evalsVal_atN' {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsVal prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M) {n : ℕ}
    {v : Val} (hget : l[n]? = some v) : EvalsVal prog M env bits (.inl (eAtN n e)) v := by
  obtain ⟨hn, rfl⟩ := List.getElem?_eq_some_iff.mp hget
  exact evalsVal_atN he hM hn

theorem valSize_le_of_getElem? {l : List Val} {n : ℕ} {v : Val} (hget : l[n]? = some v) :
    valSize v ≤ valSize (Val.list l) :=
  (valSize_lt_of_mem (List.mem_of_getElem? hget)).le

/-- The list expression `[e₀, e₁, …]`. -/
def eList : List Expr → Expr
  | [] => Expr.nil
  | e :: es => eCons e (eList es)

/-- **List building.** -/
theorem evalsVal_list {env : List Val} :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsVal prog M env [] (.inl e) v) es vs →
      valSize (Val.list vs) ≤ M → EvalsVal prog M env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsVal.nil hM
  | _ :: _, _ :: vs, List.Forall₂.cons h hs, hM => by
    have hM' : valSize (Val.list vs) ≤ M := by
      simp only [valSize_list, listSize_cons] at hM ⊢; omega
    have := EvalsVal.cons h (evalsVal_list hs hM') hM
    simpa [eList] using this

/-! ## Integer expressions -/

/-- Integer expressions over deterministic leaves: `leaf e z` is a DSL expression `e` evaluating to
`Val.int z`. -/
inductive ZE : Type where
  | leaf : Expr → ℤ → ZE
  | lit : ℤ → ZE
  | add : ZE → ZE → ZE
  | sub : ZE → ZE → ZE
  | mul : ZE → ZE → ZE
  | div : ZE → ZE → ZE
  | lt : ZE → ZE → ZE
  | eq : ZE → ZE → ZE
  | cnd : ZE → ZE → ZE → ZE

namespace ZE

/-- The compiled DSL expression. -/
def toExpr : ZE → Expr
  | leaf e _ => e
  | lit z => Expr.lit z
  | add a b => Expr.bin BinOp.add a.toExpr b.toExpr
  | sub a b => Expr.bin BinOp.sub a.toExpr b.toExpr
  | mul a b => Expr.bin BinOp.mul a.toExpr b.toExpr
  | div a b => Expr.bin BinOp.div a.toExpr b.toExpr
  | lt a b => Expr.bin BinOp.lt a.toExpr b.toExpr
  | eq a b => Expr.bin BinOp.eq a.toExpr b.toExpr
  | cnd c t f => Expr.ite c.toExpr t.toExpr f.toExpr

/-- The value (Lean's `Int` division, as the DSL). -/
def val : ZE → ℤ
  | leaf _ z => z
  | lit z => z
  | add a b => a.val + b.val
  | sub a b => a.val - b.val
  | mul a b => a.val * b.val
  | div a b => a.val / b.val
  | lt a b => if a.val < b.val then 1 else 0
  | eq a b => if a.val = b.val then 1 else 0
  | cnd c t f => if c.val ≠ 0 then t.val else f.val

/-- A crude bound on the bit length of the value. -/
def bnd : ZE → ℕ
  | leaf _ z => bitLen z
  | lit z => bitLen z
  | add a b => max a.bnd b.bnd + 1
  | sub a b => max a.bnd b.bnd + 1
  | mul a b => a.bnd + b.bnd
  | div a _ => a.bnd
  | lt _ _ => 1
  | eq _ _ => 1
  | cnd _ t f => max t.bnd f.bnd

/-- The maximum of `bnd` over all subterms. -/
def mx : ZE → ℕ
  | leaf _ z => bitLen z
  | lit z => bitLen z
  | add a b => max (max a.mx b.mx) (max a.bnd b.bnd + 1)
  | sub a b => max (max a.mx b.mx) (max a.bnd b.bnd + 1)
  | mul a b => max (max a.mx b.mx) (a.bnd + b.bnd)
  | div a b => max a.mx b.mx
  | lt a b => max (max a.mx b.mx) 1
  | eq a b => max (max a.mx b.mx) 1
  | cnd c t f => max c.mx (max t.mx f.mx)

/-- Side conditions: the leaves evaluate to their values, the divisors are nonzero. -/
def OK (prog : List Expr) (M : ℕ) (env : List Val) : ZE → Prop
  | leaf e z => EvalsVal prog M env [] (.inl e) (Val.int z)
  | lit _ => True
  | add a b => a.OK prog M env ∧ b.OK prog M env
  | sub a b => a.OK prog M env ∧ b.OK prog M env
  | mul a b => a.OK prog M env ∧ b.OK prog M env
  | div a b => a.OK prog M env ∧ b.OK prog M env ∧ b.val ≠ 0
  | lt a b => a.OK prog M env ∧ b.OK prog M env
  | eq a b => a.OK prog M env ∧ b.OK prog M env
  | cnd c t f => c.OK prog M env ∧ t.OK prog M env ∧ f.OK prog M env

theorem bitLen_val_le : ∀ e : ZE, bitLen e.val ≤ e.bnd
  | leaf _ _ => le_rfl
  | lit _ => le_rfl
  | add a b => by
    have h := bitLen_add_le a.val b.val
    have ha := a.bitLen_val_le
    have hb := b.bitLen_val_le
    simp only [val, bnd]
    exact h.trans (Nat.succ_le_succ (max_le_max ha hb))
  | sub a b => by
    have h := bitLen_add_le a.val (-b.val)
    rw [bitLen_neg, ← sub_eq_add_neg] at h
    have ha := a.bitLen_val_le
    have hb := b.bitLen_val_le
    simp only [val, bnd]
    exact h.trans (Nat.succ_le_succ (max_le_max ha hb))
  | mul a b => (bitLen_mul_le _ _).trans (Nat.add_le_add a.bitLen_val_le b.bitLen_val_le)
  | div a _ => (bitLen_ediv_le _ _).trans a.bitLen_val_le
  | lt a b => by
    simp only [val, bnd]
    split_ifs <;> simp
  | eq a b => by
    simp only [val, bnd]
    split_ifs <;> simp
  | cnd c t f => by
    simp only [val, bnd]
    split_ifs
    · exact t.bitLen_val_le.trans (le_max_left _ _)
    · exact f.bitLen_val_le.trans (le_max_right _ _)

theorem bnd_le_mx : ∀ e : ZE, e.bnd ≤ e.mx
  | leaf _ _ => le_rfl
  | lit _ => le_rfl
  | add _ _ => le_max_right _ _
  | sub _ _ => le_max_right _ _
  | mul _ _ => le_max_right _ _
  | div a _ => a.bnd_le_mx.trans (le_max_left _ _)
  | lt _ _ => le_max_right _ _
  | eq _ _ => le_max_right _ _
  | cnd _ t f => (max_le_max t.bnd_le_mx f.bnd_le_mx).trans (le_max_right _ _)

theorem valSize_le {e : ZE} (hM : e.mx + 1 ≤ M) : valSize (Val.int e.val) ≤ M := by
  rw [valSize_int]
  have := e.bitLen_val_le
  have := e.bnd_le_mx
  omega

theorem one_le_mx_lt (a b : ZE) : 1 ≤ (lt a b).mx := le_max_right _ _

/-- **Compiled integer expressions are correct.** -/
theorem spec {env : List Val} : ∀ e : ZE, e.OK prog M env → e.mx + 1 ≤ M →
    EvalsVal prog M env [] (.inl e.toExpr) (Val.int e.val)
  | leaf _ _, h, _ => h
  | lit z, _, hM => EvalsVal.lit (by rw [valSize_int]; simp only [mx] at hM; omega)
  | add a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.add (a.spec ha hma) (b.spec hb hmb) (valSize_le (e := add a b) hM)
  | sub a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.sub (a.spec ha hma) (b.spec hb hmb) (valSize_le (e := sub a b) hM)
  | mul a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.mul (a.spec ha hma) (b.spec hb hmb) (valSize_le (e := mul a b) hM)
  | div a b, ⟨ha, hb, hb0⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.div (a.spec ha hma) (b.spec hb hmb) hb0 (valSize_le (e := div a b) hM)
  | lt a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.lt (a.spec ha hma) (b.spec hb hmb) (by simp only [mx] at hM; omega)
  | eq a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    exact EvalsVal.eq (a.spec ha hma) (b.spec hb hmb) (by simp only [mx] at hM; omega)
  | cnd c t f, ⟨hc, ht, hf⟩, hM => by
    have hmc : c.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmt : t.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    have hmf : f.mx + 1 ≤ M := le_trans (by simp only [mx]; omega) hM
    by_cases hz : c.val ≠ 0
    · have h := EvalsVal.ite_true (f := f.toExpr) (c.spec hc hmc) hz (t.spec ht hmt)
      have hv : (cnd c t f).val = t.val := if_pos hz
      rw [hv]
      exact h
    · have h := EvalsVal.ite_false (t := t.toExpr) (c.spec hc hmc) (not_not.mp hz) (f.spec hf hmf)
      have hv : (cnd c t f).val = f.val := if_neg hz
      rw [hv]
      exact h

end ZE

/-! ## Library list routines in `EvalsVal` form -/

/-- The library list routines called by W4's bodies. -/
structure ListLib (prog : List Expr) : Prop where
  get : prog[Idx.get]? = some body_get
  getStep : prog[Idx.getStep]? = some body_getStep
  set : prog[Idx.set]? = some body_set
  setStep : prog[Idx.setStep]? = some body_setStep
  revAppendStep : prog[Idx.revAppendStep]? = some body_revAppendStep
  reverse : prog[Idx.reverse]? = some body_reverse
  length : prog[Idx.length]? = some body_length
  lengthStep : prog[Idx.lengthStep]? = some body_lengthStep
  replicate : prog[Idx.replicate]? = some body_replicate
  replicateStep : prog[Idx.replicateStep]? = some body_replicateStep
  take : prog[Idx.take]? = some body_take

theorem get_val (hL : ListLib prog) {env : List Val} {a : Expr} {l : List Val} {n : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [Val.list l, Val.int (n : ℤ)]))
    (hM : S_get l n ≤ M) : EvalsVal prog M env [] (.inl (eCall Idx.get a)) (l.getD n (Val.int 0)) :=
  evalsVal_call_det hL.get ha ((get_spec hL.getStep l n 0).toVal.mono_M hM)

theorem set_val (hL : ListLib prog) {env : List Val} {a : Expr} {l : List Val} {n : ℕ} {x : Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [Val.list l, Val.int (n : ℤ), x]))
    (hM : S_set l n x ≤ M) : EvalsVal prog M env [] (.inl (eCall Idx.set a)) (Val.list (l.set n x)) :=
  evalsVal_call_det hL.set ha ((set_spec hL.setStep hL.revAppendStep l n x 0).toVal.mono_M hM)

theorem length_val (hL : ListLib prog) {env : List Val} {a : Expr} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list l)) (hM : S_length l ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.length a)) (encN l.length) :=
  evalsVal_call_det hL.length ha ((length_spec hL.lengthStep l 0).toVal.mono_M hM)

theorem replicate_val (hL : ListLib prog) {env : List Val} {a : Expr} {n : ℕ} {x : Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [Val.int (n : ℤ), x]))
    (hM : S_replicate n x ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.replicate a)) (Val.list (List.replicate n x)) :=
  evalsVal_call_det hL.replicate ha ((replicate_spec hL.replicateStep n x 0).toVal.mono_M hM)

theorem reverse_val (hL : ListLib prog) {env : List Val} {a : Expr} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list l)) (hM : S_reverse l ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.reverse a)) (Val.list l.reverse) :=
  evalsVal_call_det hL.reverse ha ((reverse_spec hL.revAppendStep l 0).toVal.mono_M hM)

theorem take_val (hL : ListLib prog) {env : List Val} {a : Expr} {l : List Val} {n : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [Val.list l, Val.int (n : ℤ)]))
    (hM : S_take l n ≤ M) : EvalsVal prog M env [] (.inl (eCall Idx.take a)) (Val.list (l.take n)) :=
  evalsVal_call_det hL.take ha ((take_spec hL.setStep hL.revAppendStep l n 0).toVal.mono_M hM)

/-! ## Fresh lattice noises -/

/-- The sampler routines (W4's 610–614 and the library `readNat`). -/
structure SampLib (prog : List Expr) : Prop where
  lat : prog[Idx.adaLattice]? = some body_adaLattice
  cnt : prog[Idx.adaCount]? = some body_adaCount
  cntStep : prog[Idx.adaCountStep]? = some body_adaCountStep
  coinStep : prog[Idx.adaCoinStep]? = some body_adaCoinStep
  coin : prog[Idx.adaCoin]? = some body_adaCoin
  rnStep : prog[Idx.readNatStep]? = some body_readNatStep
  rn : prog[Idx.readNat]? = some body_readNat

/-- Position of a noise kind in `noiseKinds`. -/
def kindIdx : NoiseKind → ℕ
  | NoiseKind.intThr => 0
  | NoiseKind.intTest => 1
  | NoiseKind.outThr => 2
  | NoiseKind.outTest => 3
  | NoiseKind.num => 4

theorem kindIdx_lt (κ : NoiseKind) : kindIdx κ < noiseKinds.length := by
  cases κ <;> decide

theorem noiseKinds_getElem (κ : NoiseKind) : noiseKinds[kindIdx κ]'(kindIdx_lt κ) = κ := by
  cases κ <;> rfl

/-- A fresh lattice noise of kind `κ`, the parameter record being the value of `pubE`. -/
def eDraw (κ : NoiseKind) (pubE : Expr) : Expr :=
  eCall Idx.adaLattice (eAtN (kindIdx κ) (eAtN 12 pubE))

/-- The value bound of a draw of kind `κ`. -/
def drawM (A : AdaParams) (κ : NoiseKind) : ℕ :=
  countM (A.Ks (A.scale κ)) (A.rs (A.scale κ)) (A.rho (A.scale κ)).num.toNat
    (A.rho (A.scale κ)).den (Nat.clog 2 (A.rho (A.scale κ)).den)

/-- The fields of the parameter record. -/
def pubFields (A : AdaParams) : List Val :=
  [encN A.p, encL encN A.blockSizes, encL encN A.Tmax, encN A.fuel, encN A.M, encN A.J,
    encN A.R, encN A.qA, encN (2 ^ A.qA), encQ A.tau, encQ (A.a / 2), encQ (scoreScale A),
    Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))]

theorem adaPubEnc_eq (A : AdaParams) : adaPubEnc A = Val.list (pubFields A) := rfl

/-- **One fresh lattice noise** of kind `κ` implements `adaDraw A κ`. -/
theorem draw_impl (hS : SampLib prog) {env : List Val} {pubE : Expr} {A : AdaParams}
    (hpub : EvalsVal prog M env [] (.inl pubE) (adaPubEnc A)) (hpubM : valSize (adaPubEnc A) ≤ M)
    (κ : NoiseKind) (hM : drawM A κ ≤ M) :
    Implements prog M env (eDraw κ pubE) encZ (adaDraw A κ) := by
  rw [adaPubEnc_eq] at hpub hpubM
  have hget12 : (pubFields A)[12]? =
      some (Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))) := rfl
  have h12 := evalsVal_atN' hpub hpubM hget12
  have h12M := le_trans (valSize_le_of_getElem? hget12) hpubM
  have hgetκ : (noiseKinds.map fun κ => encL encN (samplerParams A κ))[kindIdx κ]? =
      some (latticeIn (A.Ks (A.scale κ)) (A.rs (A.scale κ)) (A.rho (A.scale κ)).num.toNat
        (A.rho (A.scale κ)).den (Nat.clog 2 (A.rho (A.scale κ)).den)) := by
    cases κ <;> rfl
  exact implements_call_det hS.lat (evalsVal_atN' h12 h12M hgetκ)
    (lattice_impl hS.cnt hS.cntStep hS.coinStep hS.coin hS.rnStep hS.rn rfl hM)

/-- **Support of a draw**: `|k| ≤ K_s`. -/
theorem adaDraw_run_abs_le {A : AdaParams} {κ : NoiseKind} {bits : List Bool} {k : ℤ}
    (h : (adaDraw A κ).run bits = some (k, [])) : |k| ≤ (A.Ks (A.scale κ) : ℤ) := by
  unfold adaDraw at h
  rw [latticeSampler_eq] at h
  obtain ⟨b₁, b₂, g₁, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨g₂, h2', rfl⟩ := bitProg_run_map_exact.mp h2
  have hg₁ := countSucc_run_le _ _ _ _ h1
  have hg₂ := countSucc_run_le _ _ _ _ h2'
  rw [abs_le]
  constructor <;> omega

end Frame

end F2e2e.C.Impl
