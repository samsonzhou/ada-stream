import F2e2e.C.Impl.Tree4Facts

/-!
# W6, Tree4: generic `EvalsVal` / `Implements` glue

* `Implements` rules for `letE` (deterministic bound expression, or a randomized one whose
  continuation is needed only on its outputs) and `ite` (integer flag, `isNil`);
* evaluation lemmas of the expression builders of `Tree4Defs` (`eFail`, `eFailOut`, `eWithBanks`,
  `eWithLearners`, `eWithLBA`, `eWithCache`, `eNormQ`, `ePow2`);
* call wrappers for the contracted W1/W5 routines and the library routines (`getOpt`, `pow2`,
  `range`, `reverse`).
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

section Rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-! ## `Implements` rules -/

/-- `letE` with a deterministic bound expression. -/
theorem impl_letE_det {α : Type} {ea eb : Expr} {va : Val} {enc : α → Val} {p : BitProg α}
    (ha : EvalsVal prog M env [] (.inl ea) va) (hb : Implements prog M (va :: env) eb enc p) :
    Implements prog M env (Expr.letE ea eb) enc p := by
  intro bits c h
  simpa using EvalsVal.letE ha (hb bits c h)

/-- `letE` whose continuation is needed only on the outputs of the bound program. -/
theorem impl_letE_run {α β : Type} {ea eb : Expr} {encA : α → Val} {encC : β → Val}
    {p : BitProg α} {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

/-- `ite` on an integer flag. -/
theorem impl_ite {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (h : Implements prog M env (if z ≠ 0 then t else f) enc p) :
    Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a hp
  simpa using EvalsVal.ite hc (h bits a hp)

theorem impl_ite_true {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : Implements prog M env t enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  impl_ite hc (by rw [if_pos hz]; exact ht)

theorem impl_ite_false {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : Implements prog M env f enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  impl_ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem impl_ite_isNil_nil {α : Type} {c t f : Expr} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (Val.list [])) (hM : 2 ≤ M)
    (ht : Implements prog M env t enc p) :
    Implements prog M env (Expr.ite (Expr.un UnOp.isNil c) t f) enc p :=
  impl_ite_true (EvalsVal.isNil_nil hc hM) one_ne_zero ht

theorem impl_ite_isNil_cons {α : Type} {c t f : Expr} {x : Val} {l : List Val} {enc : α → Val}
    {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.list (x :: l))) (hM : 1 ≤ M)
    (hf : Implements prog M env f enc p) :
    Implements prog M env (Expr.ite (Expr.un UnOp.isNil c) t f) enc p :=
  impl_ite_false (EvalsVal.isNil_cons hc hM) rfl hf

/-- `ite` on a Boolean flag `encB b`. -/
theorem impl_ite_encB {α : Type} {c t f : Expr} {b : Bool} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (encB b))
    (h : Implements prog M env (if b then t else f) enc p) :
    Implements prog M env (Expr.ite c t f) enc p := by
  cases b
  · exact impl_ite_false (z := 0) hc rfl h
  · exact impl_ite_true (z := 1) hc one_ne_zero h

/-! ## Deterministic `ite` -/

theorem ev_ite_true' {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsVal prog M env [] (.inl t) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v := by
  simpa using EvalsVal.ite_true hc hz ht

theorem ev_ite_false' {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsVal prog M env [] (.inl f) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v := by
  simpa using EvalsVal.ite_false hc hz hf

theorem ev_var' {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsVal prog M env [] (.inl (Expr.var i)) v :=
  EvalsVal.var h

theorem ev_lit' {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.lit z)) (Val.int z) :=
  EvalsVal.lit hM

theorem ev_head' {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x :: l))) (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.un UnOp.head a)) x :=
  EvalsVal.head ha ((valSize_head_le x l).trans hM)

theorem ev_tail' {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list (x :: l))) (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.un UnOp.tail a)) (Val.list l) :=
  EvalsVal.tail ha ((valSize_tail_le x l).trans hM)

end Rules

/-! ## Expression builders -/

section Builders

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem encQ_zero : encQ 0 = Val.list [Val.int 0, Val.int 1] := by
  simpa using encQ_intCast 0

theorem valSize_encQ_zero : valSize (encQ 0) = 6 := by
  rw [encQ_zero]; simp

theorem valSize_encState_fail (adaEnc : AdaState → Val) (s : State) :
    valSize (encState adaEnc s.fail) ≤ valSize (encState adaEnc s) + 1 := by
  simp only [encState, State.fail, valSize_list, listSize_cons, listSize_nil, valSize_int, if_true,
    bitLen_one]
  omega

theorem ev_eFail {st : Expr} {adaEnc : AdaState → Val} {s : State}
    (hst : EvalsVal prog M env [] (.inl st) (encState adaEnc s))
    (hM : valSize (encState adaEnc s) + 2 ≤ M) :
    EvalsVal prog M env [] (.inl (eFail st)) (encState adaEnc s.fail) := by
  have hs : valSize (encState adaEnc s) ≤ M := by omega
  have hf := valSize_encState_fail adaEnc s
  unfold eFail
  exact ev_list (.cons (ev_get 0 hst hs rfl) (.cons (EvalsVal.lit (by simp; omega))
    (.cons (ev_get 2 hst hs rfl) (.cons (ev_get 3 hst hs rfl) (.cons (ev_get 4 hst hs rfl)
    (.cons (ev_get 5 hst hs rfl) (.cons (ev_get 6 hst hs rfl) .nil)))))))
    (by have h : valSize (encState adaEnc s.fail) ≤ M := by omega
        exact h)

theorem ev_eFailOut {st : Expr} {adaEnc : AdaState → Val} {s : State}
    (hst : EvalsVal prog M env [] (.inl st) (encState adaEnc s))
    (hM : valSize (encState adaEnc s) + 10 ≤ M) :
    EvalsVal prog M env [] (.inl (eFailOut st)) (Val.list [encState adaEnc s.fail, encQ 0]) := by
  have hf := valSize_encState_fail adaEnc s
  have h1 := ev_eFail hst (by omega)
  unfold eFailOut
  rw [encQ_zero]
  have h0 : EvalsVal prog M env [] (.inl (eList [Expr.lit 0, Expr.lit 1]))
      (Val.list [Val.int 0, Val.int 1]) :=
    ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons (EvalsVal.lit (by simp; omega)) .nil))
      (by simp; omega)
  exact ev_list (.cons h1 (.cons h0 .nil)) (by simp only [valSize_list, listSize_cons,
    listSize_nil, valSize_int, bitLen_zero, bitLen_one] at hf ⊢; omega)

theorem ev_eWithBanks {st bs : Expr} {adaEnc : AdaState → Val} {s : State} {B : List Bank}
    (hst : EvalsVal prog M env [] (.inl st) (encState adaEnc s))
    (hbs : EvalsVal prog M env [] (.inl bs) (encL (encBank adaEnc) B))
    (hs : valSize (encState adaEnc s) ≤ M)
    (hM : valSize (encState adaEnc { s with banks := B }) ≤ M) :
    EvalsVal prog M env [] (.inl (eWithBanks st bs)) (encState adaEnc { s with banks := B }) := by
  unfold eWithBanks
  exact ev_list (.cons (ev_get 0 hst hs rfl) (.cons (ev_get 1 hst hs rfl)
    (.cons (ev_get 2 hst hs rfl) (.cons (ev_get 3 hst hs rfl) (.cons (ev_get 4 hst hs rfl)
    (.cons hbs (.cons (ev_get 6 hst hs rfl) .nil))))))) hM

theorem ev_eWithLearners {st ls : Expr} {adaEnc : AdaState → Val} {s : State} {L : List Learner}
    (hst : EvalsVal prog M env [] (.inl st) (encState adaEnc s))
    (hls : EvalsVal prog M env [] (.inl ls) (encL encLearner L))
    (hs : valSize (encState adaEnc s) ≤ M)
    (hM : valSize (encState adaEnc { s with learners := L }) ≤ M) :
    EvalsVal prog M env [] (.inl (eWithLearners st ls)) (encState adaEnc { s with learners := L }) := by
  unfold eWithLearners
  exact ev_list (.cons (ev_get 0 hst hs rfl) (.cons (ev_get 1 hst hs rfl)
    (.cons (ev_get 2 hst hs rfl) (.cons (ev_get 3 hst hs rfl) (.cons hls
    (.cons (ev_get 5 hst hs rfl) (.cons (ev_get 6 hst hs rfl) .nil))))))) hM

theorem ev_eWithLBA {st ls bs lf : Expr} {adaEnc : AdaState → Val} {s : State} {L : List Learner}
    {B : List Bank} {leaf : ℤ}
    (hst : EvalsVal prog M env [] (.inl st) (encState adaEnc s))
    (hls : EvalsVal prog M env [] (.inl ls) (encL encLearner L))
    (hbs : EvalsVal prog M env [] (.inl bs) (encL (encBank adaEnc) B))
    (hlf : EvalsVal prog M env [] (.inl lf) (Val.int leaf))
    (hs : valSize (encState adaEnc s) ≤ M)
    (hM : valSize (encState adaEnc { s with learners := L, banks := B, leaf := leaf }) ≤ M) :
    EvalsVal prog M env [] (.inl (eWithLBA st ls bs lf))
      (encState adaEnc { s with learners := L, banks := B, leaf := leaf }) := by
  unfold eWithLBA
  exact ev_list (.cons (ev_get 0 hst hs rfl) (.cons (ev_get 1 hst hs rfl)
    (.cons (ev_get 2 hst hs rfl) (.cons (ev_get 3 hst hs rfl) (.cons hls
    (.cons hbs (.cons hlf .nil))))))) hM

theorem ev_eWithCache {Le c : Expr} {L : Learner} {z : ℤ}
    (hL : EvalsVal prog M env [] (.inl Le) (encLearner L))
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hs : valSize (encLearner L) ≤ M) (hM : valSize (encLearner { L with cache := z }) ≤ M) :
    EvalsVal prog M env [] (.inl (eWithCache Le c)) (encLearner { L with cache := z }) := by
  unfold eWithCache
  exact ev_list (.cons (ev_get 0 hL hs rfl) (.cons hc (.cons (ev_get 2 hL hs rfl)
    (.cons (ev_get 3 hL hs rfl) (.cons (ev_get 4 hL hs rfl) .nil))))) hM

end Builders

/-! ## Calls of contracted and library routines -/

section Calls

variable {R : AdaRep} {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_normQ (hC : Contracts R prog M) {a b : Expr} {x y : ℤ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hy : 0 < y)
    (hsz : 2 * (bitLen x + bitLen y) + 64 ≤ M) :
    EvalsVal prog M env [] (.inl (eNormQ a b)) (encQ ((x : ℚ) / (y : ℚ))) := by
  obtain ⟨body, hbody, h⟩ := hC.normQ
  have harg := ev_list (prog := prog) (M := M) (env := env) (.cons ha (.cons hb .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
  exact evalsVal_call_det hbody harg (h x y hy hsz)

theorem ev_pow2 (hT : Tree4Lib prog) {k : Expr} {n : ℕ}
    (hk : EvalsVal prog M env [] (.inl k) (encN n)) (hM : S_pow2 n ≤ M) :
    EvalsVal prog M env [] (.inl (ePow2 k)) (encN (2 ^ n)) := by
  have h := (pow2_spec hT.pow2Step n 0).toVal
  exact evalsVal_call_det hT.pow2 hk (h.mono_M hM)

theorem ev_getOpt (hT : Tree4Lib prog) {α : Type} (enc : α → Val) (xs : List α) (n : ℕ)
    {a : Expr} (ha : EvalsVal prog M env [] (.inl a) (Val.list [encL enc xs, encN n]))
    (hM : 5 * valSize (encL enc xs) + 6 * Nat.size n + 40 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call Cost.Idx.getOpt a)) (encOpt enc xs[n]?) :=
  evalsVal_call_det hT.getOpt ha (getOpt_val_encL hT.getOptStep enc xs n hM)

theorem ev_paramCall {idx : ℕ} {f : StreamParams → ℕ} (hs : ParamSpec R prog M idx f)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (encStreamParams P)) :
    EvalsVal prog M env [] (.inl (Expr.call idx a)) (encN (f P)) := by
  obtain ⟨b, hb, h⟩ := hs
  exact evalsVal_call_det hb ha (h P hP hM)

theorem impl_validateCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B) {S θ : ℚ} (h0 : 0 ≤ S)
    (h1 : S ≤ (P.Amax : ℚ)) (hq : QOK P S) (ht0 : 0 < θ) (ht1 : θ ≤ 1)
    (htd : (θ.den : ℤ) ≤ 2 ^ (2 * regBits P)) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a)
      (Val.list [encStreamParams P, encBank R.enc B, encQ S, encQ θ])) :
    Implements prog M env (Expr.call F2e2e.C.Impl.Idx.validate a)
      (fun r => Val.list [encCert r.1, encBank R.enc r.2]) (B.validate P S θ) := by
  obtain ⟨b, hb, h⟩ := hC.w5.validate
  exact implements_call_det hb ha (h P B S θ hP hB h0 h1 hq ht0 ht1 htd hM)

theorem impl_releaseCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B) (mode : Mode) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a)
      (Val.list [encStreamParams P, encBank R.enc B, encMode mode])) :
    Implements prog M env (Expr.call F2e2e.C.Impl.Idx.release a)
      (fun r => Val.list [encOptQ r.1, encBank R.enc r.2]) (B.release P mode) := by
  obtain ⟨b, hb, h⟩ := hC.w5.release
  exact implements_call_det hb ha (h P B mode hP hB hM)

theorem ev_scaleYCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B) {cInt : ℤ}
    (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encBank R.enc B, encZ cInt])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.scaleYBank a))
      (encBank R.enc (B.mapRows (Row.scaleY P cInt))) := by
  obtain ⟨b, hb, h⟩ := hC.w5.scaleYBank
  exact evalsVal_call_det hb ha (h P B cInt hP hB hc hM)

theorem ev_scaleXYCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B) {cInt : ℤ}
    (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encBank R.enc B, encZ cInt])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.scaleXYBank a))
      (encBank R.enc (B.mapRows (Row.scaleXY P cInt))) := by
  obtain ⟨b, hb, h⟩ := hC.w5.scaleXYBank
  exact evalsVal_call_det hb ha (h P B cInt hP hB hc hM)

theorem ev_roundMantQCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {q : ℕ} (hq : q ≤ regBits P) {z : ℚ} (hz : QOK P z) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encN q, encQ z])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.roundMantQ a))
      (Val.int (roundMant q z)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.roundMantQ
  exact evalsVal_call_det hb ha (h P q z hP hq hz hM)

theorem ev_stepCoeffCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) (pos : Bool) {qη qs : ℕ} (hqη : qη ≤ regBits P) (hqs : qs ≤ regBits P)
    {Pval Qhat : ℚ} (hP0 : 0 < Pval) (hPq : QOK P Pval) (hQ0 : 0 < Qhat) (hQq : QOK P Qhat)
    {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a)
      (Val.list [encB pos, encN qη, encN qs, encQ Pval, encQ Qhat])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.stepCoeffMant a))
      (Val.int (stepCoeffMant pos qη qs Pval Qhat)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.stepCoeffMant
  exact evalsVal_call_det hb ha (h P pos qη qs Pval Qhat hP hqη hqs hP0 hPq hQ0 hQq hM)

theorem ev_rescaleCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {L : Learner} (hL : LearnerOK P 4 L) {cInt : ℤ}
    (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encZ cInt, encLearner L])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.rescaleLearner a))
      (encLearner (Learner.rescale P cInt L)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.rescaleLearner
  exact evalsVal_call_det hb ha (h P cInt L hP hL hc hM)

theorem ev_countCorrectionCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {L : Learner} (hL : LearnerOK P 4 L) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encLearner L])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.countCorrection a))
      (encOptLearner (Learner.countCorrection P L)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.countCorrection
  exact evalsVal_call_det hb ha (h P L hP hL hM)

theorem ev_inRangeACall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {x : ℚ} (hx : QOK P x) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encQ x])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.inRangeA a)) (encB (inRangeA P x)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.inRangeA
  exact evalsVal_call_det hb ha (h P x hP hx hM)

theorem ev_learnerInRangeCall (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {L : Learner} (hL : LearnerOK P 16 L) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (Val.list [encStreamParams P, encLearner L])) :
    EvalsVal prog M env [] (.inl (Expr.call F2e2e.C.Impl.Idx.learnerInRange a))
      (encB (L.inRange P)) := by
  obtain ⟨b, hb, h⟩ := hC.w5.learnerInRange
  exact evalsVal_call_det hb ha (h P L hP hL hM)

end Calls

theorem encOptQ_none : encOptQ none = Val.list [] := rfl
theorem encOptQ_some (x : ℚ) : encOptQ (some x) = Val.list [encQ x] := rfl
theorem encOptLearner_none : encOptLearner none = Val.list [] := rfl
theorem encOptLearner_some (L : Learner) : encOptLearner (some L) = Val.list [encLearner L] := rfl

end F2e2e.C.Impl.T4
