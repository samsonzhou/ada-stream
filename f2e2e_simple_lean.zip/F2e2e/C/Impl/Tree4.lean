import F2e2e.C.Impl.Tree4Depth

/-!
# W6, Tree4: Step 4 of the round (C-ALG `step4`, `F2e2e/C/Alg/Round.lean`), in the DSL

Step 4 of round `t + 1` (`parts/partIII.tex` L495–513): the returned value starts as the exact
terminal accumulator `F = gridVal eHleaf leaf` (L496), then the depths `d = H − 1, …, 0` are
processed by `step4Depth` (fold with early exit at a failure, `step4Loop`), and the root's `F` is
reported (L513).

Deliverables (statements fixed by C-TOP):
* `step4_impl`: `body_step4` (Idx `330`) implements `step4 P s` on `[encStreamParams P, encState R.enc s]`
  with the output `[encState R.enc s', encQ F]`, for a non-failed state with the invariant, `t ≤ m`;
* `step4_out`: the reported `F` is `≥ 0` and `QOK` (on every path of fresh bits);
* `tree4Table`, `Tree4Lib`, `Tree4Lib.of_lookup` (`F2e2e/C/Impl/Tree4Defs.lean`).

Structure: `body_step4` computes `H`, the depths `[H − 1, …, 0]` (library `range`, `reverse`), `F₀`
(W5's `normQ`, library `pow2`) and calls the fold `body_step4Fold` (DSL-CALC's `foldB`) whose step
`body_step4Elem` keeps a failed state and otherwise calls `body_step4Depth`. The fold invariant
`Inv4` (`StateOK 4`, `t ≤ m`, `FOK` of the threaded value) is preserved by every step
(C-SPACE's `step4Depth_ok`, C-ALG's `step4Depth_out`, `step4Depth_fok`).
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-- The invariant of the fold state `(s, F)`. -/
def Inv4 (R : AdaRep) (P : StreamParams) (r : State × ℚ) : Prop :=
  StateOK P (R.ok P) 4 r.1 ∧ r.1.t ≤ P.m ∧ FOK P r.2

theorem step4Step_inv {R : AdaRep} (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P) (d : ℕ)
    {r : State × ℚ} (hr : Inv4 R P r) : Always (step4Step P d r) (Inv4 R P) := by
  have hA := hR.invariant P hP
  unfold step4Step
  split_ifs
  · exact hr
  · refine Always.mono (fun r' h => ?_) (always_and (always_and
      (step4Depth_ok hA (by norm_num) hr.1 d r.2) (F2e2e.C.Alg.step4Depth_out P d r.1 r.2))
      (step4Depth_fok hA hr.1.banks_ok d hr.2.2))
    exact ⟨h.1.1, by rw [h.1.2.1.1]; exact hr.2.1, h.2⟩

/-- **The step of the fold**: `body_step4Elem` implements `step4Step`. -/
theorem step4Elem_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {d : ℕ} (hd : d < P.H) {r : State × ℚ} (hr : Inv4 R P r) :
    Implements prog M [Val.list [encN d, encSF R r, encStreamParams P]] body_step4Elem (encSF R)
      (step4Step P d r) := by
  obtain ⟨s, F⟩ := r
  obtain ⟨hs, ht, hF⟩ : StateOK P (R.ok P) 4 s ∧ s.t ≤ P.m ∧ FOK P F := hr
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hpz := vs_params R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hFz := vs_encQ R P hF.qok
  have hsz := vs_state hR hP hs ht
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hSFz' : valSize (encSF R (s, F)) ≤ SSB R P + 2 ^ 4 * SSB R P + 3 := vs_pair hsz hFz
  have hSFz : valSize (encSF R (s, F)) ≤ M := hSFz'.trans (by omega)
  have hXz : valSize (Val.list [encN d, encSF R (s, F), encStreamParams P]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hSF : EvalsVal prog M [Val.list [encN d, encSF R (s, F), encStreamParams P]] []
      (.inl (eGet 1 (Expr.var 0))) (encSF R (s, F)) := ev_get 1 (EvalsVal.var rfl) hXz rfl
  have hst := ev_get 0 hSF hSFz rfl
  have hfl := ev_get 1 hst hsM rfl
  unfold body_step4Elem
  show Implements prog M _ _ (encSF R) (if s.failed = true then BitProg.pure (s, F)
    else step4Depth P d s F)
  by_cases hf : s.failed = true
  · rw [if_pos hf]
    refine impl_ite_true (z := 1) (by simpa [hf] using hfl) one_ne_zero ?_
    exact Implements.of_det hSF
  · rw [if_neg hf]
    refine impl_ite_false (z := 0) (by simpa [hf] using hfl) rfl ?_
    refine implements_call_det hT.step4Depth (ev_list (.cons (ev_get 2 (EvalsVal.var rfl) hXz rfl)
      (.cons (ev_get 0 (EvalsVal.var rfl) hXz rfl) (.cons hst (.cons (ev_get 1 hSF hSFz rfl) .nil))))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (step4Depth_impl hR hC hT hP hM hs ht hd hF)

theorem encL_range_reverse (n : ℕ) :
    Val.list (((List.range n).map (fun i : ℕ => (i : ℤ))).map Val.int).reverse =
      encL encN (List.range n).reverse := by
  simp [encL, encN, List.map_reverse, List.map_map, Function.comp_def]

theorem ev_rangeRev {prog : List Expr} {M : ℕ} {env : List Val} (hT : Tree4Lib prog) (n : ℕ)
    {a : Expr} (ha : EvalsVal prog M env [] (.inl a) (encN n)) (h1 : S_range n ≤ M)
    (h2 : S_reverse (((List.range n).map (fun i : ℕ => (i : ℤ))).map Val.int) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.call Cost.Idx.reverse (Expr.call Cost.Idx.range a)))
      (encL encN (List.range n).reverse) := by
  have hds := evalsVal_call_det hT.reverse
    (evalsVal_call_det hT.range ha ((range_spec hT.rangeStep n 0).toVal.mono_M h1))
    ((reverse_spec hT.revAppendStep (((List.range n).map (fun i : ℕ => (i : ℤ))).map Val.int)
      0).toVal.mono_M h2)
  rwa [encL_range_reverse] at hds

theorem H_mul_size_le (P : StreamParams) : P.H * (Nat.size P.H + 2) ≤ P.calL ^ 3 := by
  have h1 := H_le P
  have h2 := size_le_self P.H
  have h3 : P.H * (Nat.size P.H + 2) ≤ P.calL * (P.calL + 2) := Nat.mul_le_mul h1 (by omega)
  have h4 : P.calL * (P.calL + 2) = P.calL ^ 2 + 2 * P.calL := by ring
  have h5 := hundred_mul_calL_le_sq P
  have h6 := hundred_mul_sq_le_cube P
  omega

/-- **Step 4** (deliverable): `body_step4` implements C-ALG's `step4` on
`[encStreamParams P, encState R.enc s]`, output `[encState R.enc s', encQ F]`. -/
theorem step4_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateInv P (R.ok P) s) (ht : s.t ≤ P.m)
    (hf : s.failed = false) :
    Implements prog M [Val.list [encStreamParams P, encState R.enc s]] body_step4
      (fun r => Val.list [encState R.enc r.1, encQ r.2]) (step4 P s) := by
  have hs1 : StateOK P (R.ok P) 1 s := hs.2 hf
  have hs4 : StateOK P (R.ok P) 4 s := hs.1
  have hF0 : FOK P (gridVal P.eHleaf s.leaf) := fok_leaf hs1
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hSc := SSB_c3 R P
  have hRB := regBits_le_SSB R P
  have hpz := vs_params R P
  have hsz := vs_state hR hP hs4 ht
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hF0z := vs_encQ R P hF0.qok
  have hXz : valSize (Val.list [encStreamParams P, encState R.enc s]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hHz := vs_encN R P (H_le_R P)
  have hHs := H_mul_size_le P
  -- the depths `[H − 1, …, 0]`
  have hLz : valSize (encL encN (List.range P.H).reverse) ≤ 1 + P.H * (Nat.size P.H + 2) := by
    have := valSize_encL_le encN (List.range P.H).reverse (Nat.size P.H + 1) (fun x hx => by
      rw [List.mem_reverse, List.mem_range] at hx
      rw [valSize_encN]
      have := Nat.size_le_size hx.le
      omega)
    simpa using this
  have hrng : S_range P.H ≤ M := by
    unfold S_range; have := size_le_self P.H; have := SSB_H R P; omega
  have hrev : S_reverse (((List.range P.H).map (fun i : ℕ => (i : ℤ))).map Val.int) ≤ M := by
    unfold S_reverse
    have e : valSize (Val.list (((List.range P.H).map (fun i : ℕ => (i : ℤ))).map Val.int)) =
        valSize (encL encN (List.range P.H).reverse) := by
      rw [← encL_range_reverse]; simp only [valSize_list, listSize_reverse]
    rw [e]; omega
  have hpow : S_pow2 P.eHleaf ≤ M := by
    unfold S_pow2; have := size_le_self P.eHleaf; have := eHleaf_le_R P; omega
  have hszl : 2 * (bitLen s.leaf + (P.eHleaf + 1)) + 64 ≤ M := by
    have := SizeAux.bitLen_leaf_le hs4; have := eHleaf_le_R P; have := eAmax_le_R P; omega
  -- the fold
  have hVS : ∀ r, Inv4 R P r → valSize (encSF R r) ≤ SSB R P + 2 ^ 4 * SSB R P + 3 :=
    fun r hr => vs_pair (vs_state hR hP hr.1 hr.2.1) (vs_encQ R P hr.2.2.qok)
  have hfold := foldB_impl hT.step4FoldStep hT.step4Elem encN (encSF R) (encStreamParams P)
    (step4Step P) (Inv4 R P) (List.range P.H).reverse (SSB R P + 2 ^ 4 * SSB R P + 3)
    (fun x r bits r' _ hr hrun => Always.of_run (step4Step_inv hR hP x hr) hrun)
    (fun x r hx hr => step4Elem_impl hR hC hT hP hM
      (by rw [List.mem_reverse, List.mem_range] at hx; exact hx) hr)
    hVS (by omega) (s, gridVal P.eHleaf s.leaf) ⟨hs4, ht, hF0⟩
  have heq : step4 P s =
      foldB (step4Step P) (List.range P.H).reverse (s, gridVal P.eHleaf s.leaf) :=
    step4Loop_eq_foldB P _ _ _
  rw [heq]
  unfold body_step4
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_paramCall hC.w1.pH hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_rangeRev hT P.H (EvalsVal.var rfl) hrng hrev) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peHleaf hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_normQ_grid hC (ev_get 6 (EvalsVal.var rfl) hsM rfl)
    (ev_pow2 hT (EvalsVal.var rfl) hpow) hszl) ?_
  have hSF0 : valSize (encSF R (s, gridVal P.eHleaf s.leaf)) ≤ SSB R P + 2 ^ 4 * SSB R P + 3 :=
    hVS _ ⟨hs4, ht, hF0⟩
  have h1 : valSize (Val.list [encState R.enc s, encQ (gridVal P.eHleaf s.leaf)]) ≤ M :=
    hSF0.trans (show SSB R P + 2 ^ 4 * SSB R P + 3 ≤ M by omega)
  have h2 : valSize (Val.list [Val.list [encState R.enc s, encQ (gridVal P.eHleaf s.leaf)],
      encL encN (List.range P.H).reverse, encStreamParams P]) ≤ M := by
    have h3 : valSize (Val.list [encState R.enc s, encQ (gridVal P.eHleaf s.leaf)]) ≤
        SSB R P + 2 ^ 4 * SSB R P + 3 := hSF0
    simp only [valSize_list, listSize_cons, listSize_nil] at h3 ⊢
    omega
  refine implements_call_det (x := Val.list [Val.list [encState R.enc s,
    encQ (gridVal P.eHleaf s.leaf)], encL encN (List.range P.H).reverse, encStreamParams P])
    hT.step4Fold ?_ hfold
  exact ev_list (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)) h1)
    (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))) h2

/-- **The reported value** (deliverable): on every path of fresh bits, Step 4 reports `F ≥ 0` with
`QOK P F`. -/
theorem step4_out {R : AdaRep} (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P) {s : State}
    (hs : StateInv P (R.ok P) s) (ht : s.t ≤ P.m) (hf : s.failed = false) :
    Always (step4 P s) (fun r => 0 ≤ r.2 ∧ QOK P r.2) :=
  Always.mono (fun _ h => ⟨h.1, h.qok⟩) (step4_fok (hR.invariant P hP) (hs.2 hf))

end F2e2e.C.Impl.T4
