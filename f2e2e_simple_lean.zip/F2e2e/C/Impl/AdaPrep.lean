import F2e2e.C.Impl.AdaPrepScan

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 5: `adaPrepR` (Idx 700, B-NUM)

* `adaPassStep` (Idx 704): one iteration of `PrepareRoot` on `prepEnc A vals (f, st, cache) =
  [f, st, cache, pub, vals]`: no fuel left (`[0, []]`), or the predictions of `st` (`adaMusR`, Idx 640),
  one scan pass (the loop `loop 703`, `scanLoop_impl`), and its outcome: `done` stops with `[st']`,
  `corrected` continues with `[f - 1, st', cache', pub, vals]`, `abort` stops with `[]`;
* `adaPrepR` (Idx 700) = `loop 704` on its input; `adaPrep_impl` (W4's contract, with `hf : f ≤ A.fuel`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- The accumulator of the `PrepareRoot` loop: `[f, st, cache, pub, vals]`. -/
def prepEnc (A : AdaParams) (vals : List (List ℕ)) (s : ℕ × AdaState × List Bool) : Val :=
  Val.list [encN s.1, adaEnc s.2.1, encL encB s.2.2, adaPubEnc A, encVals vals]

/-- **`adaPassStep`** (Idx 704). -/
def body_adaPassStep : Expr :=
  eIte (eEq (eAtN 0 (eV 0)) (eLit 0))
    (ePair (eLit 0) Expr.nil)
    (eLet (eCall Idx.adaMusR (eList [eAtN 3 (eV 0), eAtN 0 (eAtN 1 (eV 0)), eAtN 4 (eV 0)]))
      (eLet (eLoop Idx.adaScanStep (eList [eLit 0, eAtN 1 (eV 1), eAtN 2 (eV 1), eAtN 3 (eV 1),
          eAtN 4 (eV 1), eV 0]))
        (eIte (eEq (eAtN 0 (eV 0)) (eLit 0))
          (ePair (eLit 0) (eList [eAtN 1 (eV 0)]))
          (eIte (eEq (eAtN 0 (eV 0)) (eLit 1))
            (ePair (eLit 1) (eList [eSub (eAtN 0 (eV 2)) (eLit 1), eAtN 1 (eV 0), eAtN 2 (eV 0),
              eAtN 3 (eV 2), eAtN 4 (eV 2)]))
            (ePair (eLit 0) Expr.nil)))))

/-- **`adaPrepR`** (Idx 700): the `PrepareRoot` loop on its input `[f, st, cache, pub, vals]`. -/
def body_adaPrep : Expr := eLoop Idx.adaPassStep (eV 0)

/-- **The routines of `adaPrepR`** (`(index, body)`), including the correction routines of
`AdaPrepCorr.lean` and the library routines they call outside `ListLib`/`SampLib`. -/
def adaPrepTable : List (ℕ × Expr) :=
  [(Idx.adaPrepR, body_adaPrep), (Idx.adaEdge, body_adaEdge), (Idx.adaScanStep, body_adaScanStep),
    (Idx.adaPassStep, body_adaPassStep), (Idx.adaReset, body_adaReset)] ++ adaCorrTable

/-- The invariant of the `PrepareRoot` loop. -/
def PrepInv (A : AdaParams) (s : ℕ × AdaState × List Bool) : Prop :=
  AdaOK A s.2.1 ∧ s.2.2.length = A.p ∧ s.1 ≤ A.fuel

section Prep

variable {prog : List Expr} {M : ℕ}

theorem scanLib_of_table (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) : ScanLib prog where
  edge := hlib (Idx.adaEdge, body_adaEdge) (by simp [adaPrepTable])
  reset := hlib (Idx.adaReset, body_adaReset) (by simp [adaPrepTable])
  corr := fun e he => hlib e (List.mem_append_right _ he)
  step := hlib (Idx.adaScanStep, body_adaScanStep) (by simp [adaPrepTable])

/-- A deterministic `letE`. -/
theorem ap_implements_letE_det {α : Type} {env : List Val} {a b : Expr} {va : Val} {enc : α → Val}
    {p : BitProg α} (ha : EvalsVal prog M env [] (.inl a) va)
    (hb : Implements prog M (va :: env) b enc p) : Implements prog M env (Expr.letE a b) enc p := by
  intro bits x h
  have := EvalsVal.letE ha (hb bits x h)
  simpa using this

theorem valSize_prepEnc_le {A : AdaParams} {vals : List (List ℕ)} {f : ℕ} {st : AdaState}
    {c : List Bool} {Bd : ℕ} (hf : Nat.size f ≤ Bd) (hc : c.length = A.p)
    (h1 : valSize (adaPubEnc A) ≤ Bd) (h2 : valSize (adaEnc st) ≤ Bd)
    (h3 : valSize (encVals vals) ≤ Bd) (hp : 8 * (A.p + 16) ≤ Bd) :
    valSize (prepEnc A vals (f, st, c)) ≤ 5 * Bd := by
  have hcS := ap_valSize_encL_encB c
  rw [hc] at hcS
  simp only [prepEnc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

/-- **The pass step implements one iteration of `PrepareRoot`.** -/
theorem passStep_impl (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) (hmus : MusLib prog)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    (s : ℕ × AdaState × List Bool) (hs : PrepInv A s) :
    Implements prog M [prepEnc A vals s] body_adaPassStep (loopEnc (prepEnc A vals) encOptSt)
      (prepQ A vals s) := by
  obtain ⟨f, st, cache⟩ := s
  obtain ⟨hok, hcl, hf⟩ := hs
  simp only at hok hcl hf
  obtain ⟨hPub, hSt, hVals, hMz, hB⟩ := adaBound_facts hbs hT hok hv
  have hZ16 := sixteen_le_adaZ A
  have hp16 : 8 * (A.p + 16) ≤ adaBoundA A := by omega
  have hBM : 2 ^ 32 * adaBoundA A ≤ M := hM
  have h3 : 3 ≤ M := by omega
  have hsf : Nat.size f ≤ adaBoundA A := by
    have := Nat.size_le_size hf
    have := size_fuel_le_adaZ A
    omega
  have hacc5 := valSize_prepEnc_le (vals := vals) hsf hcl hPub hSt hVals hp16
  have haccM : valSize (prepEnc A vals (f, st, cache)) ≤ M := by omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  set acc := prepEnc A vals (f, st, cache) with hacc
  have hfield : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some acc →
      [encN f, adaEnc st, encL encB cache, adaPubEnc A, encVals vals][n]? = some v →
      EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (EvalsVal.var henv) haccM hget
  have hfE : EvalsVal prog M [acc] [] (.inl (eAtN 0 (eV 0))) (encN f) := hfield rfl rfl
  unfold body_adaPassStep prepQ
  cases f with
  | zero =>
    dsimp only
    have hcz := EvalsVal.eq hfE (ap_lit_small (z := 0) (by decide) h3) (by omega)
    rw [if_pos (by rfl)] at hcz
    refine ap_implements_ite_true hcz one_ne_zero ?_
    apply Implements.of_det
    refine EvalsVal.pair (ap_lit_small (by decide) h3) (EvalsVal.nil (by simp; omega)) ?_
    show valSize (Val.list [Val.int 0, Val.list []]) ≤ M
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : bitLen (0 : ℤ) = 0 := by decide
    omega
  | succ f =>
    dsimp only
    have hcz := EvalsVal.eq hfE (ap_lit_small (z := 0) (by decide) h3) (by omega)
    rw [if_neg (by push_cast; omega)] at hcz
    refine ap_implements_ite_false hcz rfl ?_
    -- the predictions
    set mz := musZ A st.scores vals with hmz
    have hscE : EvalsVal prog M [acc] [] (.inl (eAtN 0 (eAtN 1 (eV 0)))) (encL (encL encZ) st.scores) :=
      evalsVal_atN' (hfield (n := 1) rfl rfl) hstM rfl
    have hmusArgs : EvalsVal prog M [acc] [] (.inl (eList [eAtN 3 (eV 0), eAtN 0 (eAtN 1 (eV 0)),
        eAtN 4 (eV 0)])) (Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]) := by
      have hscS : valSize (encL (encL encZ) st.scores) ≤ adaBoundA A :=
        le_trans (valSize_lt_of_mem (l := [encL (encL encZ) st.scores, encL encN st.T,
          encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
          encB st.halted, encB st.capAborted]) (by simp)).le hSt
      refine evalsVal_list (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons hscE
        (List.Forall₂.cons (hfield rfl rfl) List.Forall₂.nil))) ?_
      rw [ap_valSize_list3]
      omega
    have hmusE : EvalsVal prog M [acc] [] (.inl (eCall Idx.adaMusR (eList [eAtN 3 (eV 0),
        eAtN 0 (eAtN 1 (eV 0)), eAtN 4 (eV 0)]))) (encL encPZ mz) :=
      evalsVal_call_det hmus.1 hmusArgs (adaMusR_val hmus hbs hT hpos hok hv hM)
    refine ap_implements_letE_det hmusE ?_
    -- the scan pass
    have hmzM : valSize (encL encPZ mz) ≤ M := by omega
    have hinit : EvalsVal prog M [encL encPZ mz, acc] [] (.inl (eList [eLit 0, eAtN 1 (eV 1),
        eAtN 2 (eV 1), eAtN 3 (eV 1), eAtN 4 (eV 1), eV 0])) (scanEnc A vals mz (0, st, cache)) := by
      have h5 := valSize_scanEnc_le (A := A) (vals := vals) (mz := mz) (j := 0) (st := st)
        (c := cache) (by omega) hcl hPub hSt hVals hMz hp16
      refine evalsVal_list (List.Forall₂.cons (ap_lit_small (z := 0) (by decide) h3)
        (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons (hfield rfl rfl)
        (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons (hfield rfl rfl)
        (List.Forall₂.cons EvalsVal.var0 List.Forall₂.nil)))))) ?_
      show valSize (scanEnc A vals mz (0, st, cache)) ≤ M
      omega
    have hscan := scanLoop_impl (scanLib_of_table hlib) hS hL hbs hT hpos hok hv hM hcl hinit
    show Implements prog M [encL encPZ mz, acc] _ (loopEnc (prepEnc A vals) encOptSt)
      ((scanRef A vals (adaMus A st vals) (0, st, cache)).bind fun r =>
        BitProg.pure (passOutcome f r))
    refine implements_letE_of hscan (fun r => AdaOK A r.2.1 ∧ r.2.2.length = A.p)
      (fun bits r h => Always.of_run (scanRef_always vals _ hok hcl) h) ?_
    rintro ⟨o, st1, c1⟩ ⟨hok1, hc1⟩
    replace hok1 : AdaOK A st1 := hok1
    replace hc1 : c1.length = A.p := hc1
    apply Implements.of_det
    have hSt1 := valSize_adaEnc_le hok1
    have hc1S := ap_valSize_encL_encB c1
    rw [hc1] at hc1S
    have houtM : valSize (scanOut (o, st1, c1)) ≤ M := by
      simp only [scanOut, valSize_list, listSize_cons, listSize_nil]
      have : valSize (encPO o) ≤ 3 := by cases o <;> decide
      omega
    set env : List Val := [scanOut (o, st1, c1), encL encPZ mz, acc] with henv
    have hoE : EvalsVal prog M env [] (.inl (eAtN 0 (eV 0))) (encPO o) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    have hst1E : EvalsVal prog M env [] (.inl (eAtN 1 (eV 0))) (adaEnc st1) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    have hc1E : EvalsVal prog M env [] (.inl (eAtN 2 (eV 0))) (encL encB c1) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    cases o with
    | done =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_pos rfl] at he
      refine EvalsVal.ite_true he one_ne_zero ?_
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (evalsVal_list (List.Forall₂.cons hst1E
        List.Forall₂.nil) (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) ?_
      show valSize (Val.list [Val.int 0, Val.list [adaEnc st1]]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
      have : bitLen (0 : ℤ) = 0 := by decide
      omega
    | corrected =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he
      refine EvalsVal.ite_false he rfl ?_
      have he1 := EvalsVal.eq hoE (ap_lit_small (z := 1) (by decide) h3) (by omega)
      rw [if_pos rfl] at he1
      refine EvalsVal.ite_true he1 one_ne_zero ?_
      have hfE' : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (encN (f + 1)) :=
        evalsVal_atN' EvalsVal.var2 haccM rfl
      have hsf' : Nat.size f ≤ adaBoundA A := le_trans (Nat.size_le_size (Nat.le_succ f)) hsf
      have hsub := EvalsVal.sub hfE' (ap_lit_small (z := 1) (by decide) h3) (by
        rw [show ((f + 1 : ℕ) : ℤ) - 1 = (f : ℤ) by omega, valSize_int, bitLen_natCast]
        omega)
      rw [show ((f + 1 : ℕ) : ℤ) - 1 = (f : ℤ) by omega] at hsub
      have hnext := valSize_prepEnc_le (vals := vals) (f := f) (st := st1) (c := c1)
        (le_trans (Nat.size_le_size (Nat.le_succ f)) hsf) hc1 hPub hSt1 hVals hp16
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (evalsVal_list (List.Forall₂.cons hsub
        (List.Forall₂.cons hst1E (List.Forall₂.cons hc1E (List.Forall₂.cons
          (evalsVal_atN' EvalsVal.var2 haccM rfl) (List.Forall₂.cons
          (evalsVal_atN' EvalsVal.var2 haccM rfl) List.Forall₂.nil))))) (by
            show valSize (prepEnc A vals (f, st1, c1)) ≤ M
            omega)) ?_
      show valSize (Val.list [Val.int 1, prepEnc A vals (f, st1, c1)]) ≤ M
      rw [ap_valSize_list2, valSize_int]
      have : bitLen (1 : ℤ) = 1 := by decide
      omega
    | abort =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he
      refine EvalsVal.ite_false he rfl ?_
      have he1 := EvalsVal.eq hoE (ap_lit_small (z := 1) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he1
      refine EvalsVal.ite_false he1 rfl ?_
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (EvalsVal.nil (by simp; omega)) ?_
      show valSize (Val.list [Val.int 0, Val.list []]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
      have : bitLen (0 : ℤ) = 0 := by decide
      omega

/-- `prepQ` continues only to states satisfying the invariant, with less fuel. -/
theorem prepQ_always (A : AdaParams) (vals : List (List ℕ)) (s : ℕ × AdaState × List Bool)
    (hs : PrepInv A s) :
    Always (prepQ A vals s) (fun r => ∀ s', r = Sum.inl s' → PrepInv A s' ∧ s'.1 < s.1) := by
  obtain ⟨f, st, cache⟩ := s
  obtain ⟨hok, hcl, hf⟩ := hs
  simp only at hok hcl hf
  cases f with
  | zero => exact fun s' h => by cases h
  | succ f =>
    show Always ((scanRef A vals (adaMus A st vals) (0, st, cache)).bind fun r =>
      BitProg.pure (passOutcome f r)) _
    refine Always.bind (fun r hr => ?_) (scanRef_always vals _ hok hcl)
    obtain ⟨o, st1, c1⟩ := r
    obtain ⟨hok1, hc1⟩ := hr
    cases o with
    | done => exact fun s' h => by cases h
    | corrected =>
      exact fun s' h => by
        cases h
        exact ⟨⟨hok1, hc1, by simp only; omega⟩, by simp only; omega⟩
    | abort => exact fun s' h => by cases h

/-- **Spec of `adaPrepR`** (W4's contract, with `hf : f ≤ A.fuel`). -/
theorem adaPrep_impl {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2)
    (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (f : ℕ) (hf : f ≤ A.fuel) {cache : List Bool}
    (hc : cache.length = A.p) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [encN f, adaEnc st, encL encB cache, adaPubEnc A, encVals vals]]
      body_adaPrep encOptSt ((prepareRoot A vals f st cache).toBits (adaDraw A)) :=
  implements_loop (hlib (Idx.adaPassStep, body_adaPassStep) (by simp [adaPrepTable]))
    (prepEnc A vals) encOptSt (PrepInv A) (fun s => s.1) (prepRef A vals) (prepQ A vals)
    (fun s hs => passStep_impl hlib hmus hS hL hbs hT hpos hv hM s hs)
    (fun s _ => prepRef_unfold A vals s)
    (fun s hs _ s' h => Always.of_run (prepQ_always A vals s hs) h s' rfl)
    (s₀ := (f, st, cache)) ⟨hok, hc, hf⟩ EvalsVal.var0

end Prep

end F2e2e.C.Impl
