import F2e2e.C.Impl.W6Table
import F2e2e.C.Impl.Tree1Defs
import F2e2e.C.Impl.Tree4Defs
import F2e2e.C.Impl.NewBank
import F2e2e.C.Impl.AdaContract
import F2e2e.C.Impl.BankDefs
import F2e2e.C.Impl.Fingerprint
import F2e2e.C.Impl.ParamsBodies
import F2e2e.Cost.Assembly
import F2e2e.Cost.MachineBits

/-!
# Theorem (C), assembly: the routine table of the two DSL programs

Owner: C-SPACE (assembly end of W6). The two programs of Theorem (C) are
`initProg = mkProg body_init theTable` and `updProg = mkProg body_round theTable`
(`F2e2e/Cost/Assembly.lean`): entry body at index `0`, every other index `i` holds the first body of
key `i` in `theTable` (`Expr.nil` if there is none).

* `theTable`: the concatenation of the routine tables of all areas (their own routines and the DSL-CALC
  library routines they call), each referenced by name so that it follows the areas' tables:
  W6 (`w6Table ++ w6LibDeps`), Tree1 (`tree1Needs`), Tree4 (`tree4Table ++ tree4LibDeps`),
  W1 (`w1Table` and W1's library routines `asmW1Deps`), W2 (`asmFpTable`, `asmHashTable`,
  `asmHornerTable`: the entries of `FpLib`, `HashLib`, `HornerLib`, written here field by field),
  W3 (`w3Needs`), W4 (`w4AllTable`), W5 (`asmBankTable`: the entries of
  `BankLib`, field by field). Keys occurring in several tables carry the same body (the shared DSL-CALC
  routines); `List.lookup` returns the first one.
* Generic facts about `mkProg` (any table): `mkProg_get_cases` (every body is the entry body, a table
  body at its own key, or the filler), `rankOK_mkProg` (a rank certificate from the entry body and the
  table entries, checked entry by entry: `tblRankB`), `progDepth_mkProg_le`.
* The library predicates of all areas for `mkProg main theTable`, for every entry body `main`
  (`fpLib`, `hashLib`, `hornerLib`, `w1Lib`, `w3Lib`, `w4Lib`, `bankLib`, `mainLib`, `tree1Lib`,
  `tree4Lib`). Every lookup is checked by `decide +kernel` (kernel reduction only, nothing added to
  the trusted base), with the structural decidable equality of `Expr` derived here (the Spec's `Expr`
  derives no instances): the kernel walks the numeral keys to the first match and compares the two
  bodies.
-/

/-! ## W2's and W5's library entries (field by field, in the namespaces of the library predicates) -/

namespace F2e2e.Cost.HashDSL

/-- The entries of `FpLib` (`F2e2e/C/Impl/Fingerprint.lean`). -/
def asmFpTable : List (ℕ × Expr) :=
  [(Idx.primeTest, body_primeTest), (Idx.primeTestStep, body_primeTestStep),
    (Idx.leastPrimeGE, body_leastPrimeGE), (Idx.leastPrimeGEStep, body_leastPrimeGEStep),
    (Idx.powMod, body_powMod), (Idx.powModStep, body_powModStep),
    (Idx.fpUpdate, body_fpUpdate)]

/-- The entries of `HashLib` (`F2e2e/C/Impl/HashBasic.lean`). -/
def asmHashTable : List (ℕ × Expr) :=
  [(Idx.xorNat, body_xorNat), (Idx.xorNatStep, body_xorNatStep),
    (Idx.pow2H, body_pow2), (Idx.pow2HStep, body_pow2Step),
    (Idx.sizeNat, body_sizeNat), (Idx.sizeNatStep, body_sizeNatStep),
    (Idx.clmul, body_clmul), (Idx.clmulStep, body_clmulStep),
    (Idx.pmodDeg, body_pmodDeg), (Idx.pmodDegStep, body_pmodDegStep),
    (Idx.gfMul, body_gfMul), (Idx.irrTest, body_irrTest), (Idx.irrTestStep, body_irrTestStep),
    (Idx.irrPoly, body_irrPoly), (Idx.irrPolyStep, body_irrPolyStep)]

/-- The entries of `HornerLib` beyond `HashLib` (`F2e2e/C/Impl/HashHorner.lean`). -/
def asmHornerTable : List (ℕ × Expr) :=
  [(Idx.reverse, body_reverse), (Idx.revAppendStep, body_revAppendStep),
    (Idx.gfHorner, body_gfHorner), (Idx.gfHornerStep, body_gfHornerStep),
    (Idx.signBit, body_signBit), (Idx.rowSign, body_rowSign)]

end F2e2e.Cost.HashDSL

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top

/-- The entries of `BankLib` (`F2e2e/C/Impl/BankDefs.lean`). -/
def asmBankTable : List (ℕ × Expr) :=
  [(Idx.resetYBank, body_resetYBank), (Idx.addPhysBank, body_addPhysBank),
    (Idx.addGuardYBank, body_addGuardYBank), (Idx.addGuardXYBank, body_addGuardXYBank),
    (Idx.scaleYBank, body_scaleYBank), (Idx.scaleXYBank, body_scaleXYBank),
    (Idx.validate, body_validate), (Idx.release, body_release),
    (Idx.roundMantQ, body_roundMantQ), (Idx.guardMant, body_guardMant),
    (Idx.stepCoeffMant, body_stepCoeffMant), (Idx.rescaleLearner, body_rescaleLearner),
    (Idx.countCorrection, body_countCorrection), (Idx.inRangeA, body_inRangeA),
    (Idx.inRangeC, body_inRangeC), (Idx.learnerInRange, body_learnerInRange),
    (Idx.normQ, body_normQ),
    (Idx.bkGcdStep, body_bkGcdStep), (Idx.bkSat, body_bkSat), (Idx.bkRDiv, body_bkRDiv),
    (Idx.bkRowOp, body_bkRowOp), (Idx.bkRowOpStep, body_mapBStep Idx.bkRowOp),
    (Idx.bkBlockOp, body_mapB Idx.bkRowOpStep), (Idx.bkBlockOpStep, body_mapBStep Idx.bkBlockOp),
    (Idx.bkBlocksOp, body_mapB Idx.bkBlockOpStep),
    (Idx.bkBlocksOpStep, body_mapBStep Idx.bkBlocksOp),
    (Idx.bkGroupsOp, body_mapB Idx.bkBlocksOpStep), (Idx.bkBankMap, body_bkBankMap),
    (Idx.bkZN, body_bkZN), (Idx.bkRowQ, body_bkRowQ), (Idx.bkRowQStep, body_mapBStep Idx.bkRowQ),
    (Idx.bkBlockQ, body_mapB Idx.bkRowQStep), (Idx.bkBlockQStep, body_mapBStep Idx.bkBlockQ),
    (Idx.bkValsQ, body_mapB Idx.bkBlockQStep), (Idx.bkRowSq, body_bkRowSq),
    (Idx.bkRowSqStep, body_mapBStep Idx.bkRowSq), (Idx.bkSubSum, body_bkSubSum),
    (Idx.bkSubSumStep, body_mapBStep Idx.bkSubSum), (Idx.bkGroupSums, body_mapB Idx.bkSubSumStep),
    (Idx.bkZExtra, body_bkZExtra), (Idx.bkLowerMedian, body_bkLowerMedian),
    (Idx.bkCoarseScale, body_bkCoarseScale), (Idx.bkQExtra, body_bkQExtra),
    (Idx.bkReleaseN, body_bkReleaseN),
    (Cost.Idx.pow2, Cost.body_pow2), (Cost.Idx.pow2Step, Cost.body_pow2Step),
    (Cost.Idx.natSqrt, body_natSqrt), (Cost.Idx.natSqrtStep, body_natSqrtStep),
    (Cost.Idx.floorSqrtND, body_floorSqrtND), (Cost.Idx.ceilSqrtND, body_ceilSqrtND),
    (Cost.Idx.clampZ, body_clampZ), (Cost.Idx.reverse, body_reverse),
    (Cost.Idx.revAppendStep, body_revAppendStep), (Cost.Idx.sum, body_sum),
    (Cost.Idx.sumStep, body_sumStep), (Cost.Idx.get, body_get), (Cost.Idx.getStep, body_getStep),
    (Cost.Idx.length, body_length), (Cost.Idx.lengthStep, body_lengthStep),
    (Cost.Idx.isortZ, body_isortZ), (Cost.Idx.isortZStep, body_isortZStep),
    (Cost.Idx.insertZ, body_insertZ), (Cost.Idx.insertZStep, body_insertZStep)]

end F2e2e.C.Impl.BankDSL

namespace F2e2e.C.Impl.Asm

open F2e2e.Cost

/-! ## Structural decidable equality of programs (for the kernel checks of the table lookups) -/

deriving instance DecidableEq for BinOp, UnOp, Expr

/-! ## Generic facts about `mkProg` -/

/-- An entry found by `List.lookup` is an entry of the table. -/
theorem mem_of_lookup {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr} (h : tbl.lookup i = some b) :
    (i, b) ∈ tbl := by
  obtain ⟨l₁, l₂, htbl, -⟩ := List.lookup_eq_some_iff.mp h
  rw [htbl]
  simp

/-- Every body of `mkProg main tbl` is the entry body (index `0`), a body of the table at its own
key, or the filler `Expr.nil`. -/
theorem mkProg_get_cases {main : Expr} {tbl : List (ℕ × Expr)} {j : ℕ} {b : Expr}
    (h : (mkProg main tbl)[j]? = some b) : (j = 0 ∧ b = main) ∨ (j, b) ∈ tbl ∨ b = Expr.nil := by
  cases j with
  | zero =>
    left
    simp only [mkProg, List.getElem?_cons_zero, Option.some.injEq] at h
    exact ⟨rfl, h.symm⟩
  | succ j =>
    right
    simp only [mkProg, List.getElem?_cons_succ, List.getElem?_map] at h
    by_cases hj : j < tblMax tbl
    · rw [List.getElem?_range hj] at h
      simp only [Option.map_some, Option.some.injEq] at h
      cases hl : tbl.lookup (j + 1) with
      | none =>
        right
        rw [hl] at h
        exact h.symm
      | some b' =>
        left
        rw [hl] at h
        simp only [Option.getD_some] at h
        subst h
        exact mem_of_lookup hl
    · rw [List.getElem?_eq_none (by simpa using hj)] at h
      simp at h

/-- Boolean check of the rank certificate on the entries of a table. -/
def tblRankB (r : ℕ → ℕ) (K : ℕ) (tbl : List (ℕ × Expr)) : Bool :=
  tbl.all fun e => decide (exprDepth e.2 ≤ K) && calleesLtB r (r e.1) e.2

theorem tblRankB_sound {r : ℕ → ℕ} {K : ℕ} {tbl : List (ℕ × Expr)} (h : tblRankB r K tbl = true) :
    ∀ e ∈ tbl, exprDepth e.2 ≤ K ∧ CalleesLt r (r e.1) e.2 := by
  intro e he
  have := List.all_eq_true.mp h e he
  simp only [Bool.and_eq_true, decide_eq_true_eq] at this
  exact ⟨this.1, (calleesLtB_iff r (r e.1) e.2).mp this.2⟩

/-- **Rank certificate of an assembled program** from its entry body and its table entries (the
filler `Expr.nil` has depth `1` and no callees). -/
theorem rankOK_mkProg {main : Expr} {tbl : List (ℕ × Expr)} {r : ℕ → ℕ} {K : ℕ} (hK : 1 ≤ K)
    (hmain : exprDepth main ≤ K ∧ CalleesLt r (r 0) main)
    (htbl : ∀ e ∈ tbl, exprDepth e.2 ≤ K ∧ CalleesLt r (r e.1) e.2) :
    RankOK (mkProg main tbl) r K := by
  intro j b hj
  rcases mkProg_get_cases hj with ⟨rfl, rfl⟩ | hmem | rfl
  · exact hmain
  · exact htbl _ hmem
  · exact ⟨by simpa [exprDepth] using hK, trivial⟩

theorem foldr_max_le {l : List ℕ} {D : ℕ} (h : ∀ x ∈ l, x ≤ D) : l.foldr max 0 ≤ D := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.foldr_cons]
    exact max_le (h a (by simp)) (ih fun x hx => h x (by simp [hx]))

/-- The machine depth of an assembled program from its entry body and its table entries. -/
theorem progDepth_mkProg_le {main : Expr} {tbl : List (ℕ × Expr)} {D : ℕ}
    (hmain : F2e2e.Machine.height main ≤ D)
    (htbl : ∀ e ∈ tbl, F2e2e.Machine.height e.2 ≤ D) :
    F2e2e.Machine.progDepth (mkProg main tbl) ≤ D := by
  unfold F2e2e.Machine.progDepth
  refine foldr_max_le fun x hx => ?_
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hx
  obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hb
  rcases mkProg_get_cases hj with ⟨-, rfl⟩ | hmem | rfl
  · exact hmain
  · exact htbl _ hmem
  · simp [F2e2e.Machine.height]

/-- A lookup in a table with positive keys has a positive key. -/
theorem pos_of_lookup {tbl : List (ℕ × Expr)} (hpos : ∀ e ∈ tbl, 0 < e.1) {i : ℕ} {b : Expr}
    (h : tbl.lookup i = some b) : 0 < i :=
  hpos _ (mem_of_lookup h)

/-! ## The table -/

/-- W1's DSL-CALC library routines (`W1Lib`: `pow2`, `clog2`). -/
def asmW1Deps : List (ℕ × Expr) :=
  [(Cost.Idx.pow2, Cost.body_pow2), (Cost.Idx.pow2Step, Cost.body_pow2Step),
    (Cost.Idx.clog2, Cost.body_clog2), (Cost.Idx.clog2Step, Cost.body_clog2Step)]

/-- **The routine table of Theorem (C)**: all areas' tables, each by name. -/
def theTable : List (ℕ × Expr) :=
  W6.w6Table ++ W6.w6LibDeps ++ T1.tree1Needs ++ T4.tree4Table ++ T4.tree4LibDeps ++
    W1.w1Table ++ asmW1Deps ++ HashDSL.asmFpTable ++ HashDSL.asmHashTable ++
    HashDSL.asmHornerTable ++ w3Needs ++ w4AllTable ++ BankDSL.asmBankTable

/-- All keys of `theTable` are positive (index `0` is the entry point). -/
theorem theTable_pos : ∀ e ∈ theTable, 0 < e.1 := by
  have h : theTable.all (fun e => decide (0 < e.1)) = true := by decide +kernel
  intro e he
  simpa using List.all_eq_true.mp h e he

/-- A lookup in `theTable` is a body of every program assembled from it. -/
theorem get_of_lookup {main : Expr} {i : ℕ} {b : Expr} (h : theTable.lookup i = some b) :
    (mkProg main theTable)[i]? = some b :=
  mkProg_get_of_lookup h (pos_of_lookup theTable_pos h)

/-! ## The lookups of the areas' tables -/

theorem lookups_w1 : ∀ e ∈ W1.w1Table, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_w3 : ∀ e ∈ w3Needs, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_w4 : ∀ e ∈ w4AllTable, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_w6 : ∀ e ∈ W6.w6Table ++ W6.w6LibDeps, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_tree1 : ∀ e ∈ T1.tree1Needs, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_tree4 :
    ∀ e ∈ T4.tree4Table ++ T4.tree4LibDeps, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_fp : ∀ e ∈ HashDSL.asmFpTable, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_hash : ∀ e ∈ HashDSL.asmHashTable, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_horner : ∀ e ∈ HashDSL.asmHornerTable, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_bank : ∀ e ∈ BankDSL.asmBankTable, theTable.lookup e.1 = some e.2 := by
  decide +kernel

theorem lookups_w1deps : ∀ e ∈ asmW1Deps, theTable.lookup e.1 = some e.2 := by
  decide +kernel

/-! ## The library predicates of all areas -/

variable (main : Expr)

/-- A body of an entry of `L` is in the program, once every entry of `L` is found in `theTable`. -/
theorem get_of_mem {L : List (ℕ × Expr)} (hL : ∀ e ∈ L, theTable.lookup e.1 = some e.2)
    {i : ℕ} {b : Expr} (h : (i, b) ∈ L) : (mkProg main theTable)[i]? = some b :=
  get_of_lookup (hL (i, b) h)

theorem fpLib : HashDSL.FpLib (mkProg main theTable) := by
  constructor <;> exact get_of_mem main lookups_fp (by simp [HashDSL.asmFpTable])

theorem hashLib : HashDSL.HashLib (mkProg main theTable) := by
  constructor <;> exact get_of_mem main lookups_hash (by simp [HashDSL.asmHashTable])

theorem hornerLib : HashDSL.HornerLib (mkProg main theTable) :=
  { hashLib main with
    reverse := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable])
    revAppendStep := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable])
    gfHorner := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable])
    gfHornerStep := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable])
    signBit := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable])
    rowSign := get_of_mem main lookups_horner (by simp [HashDSL.asmHornerTable]) }

theorem w1Lib : W1Lib (mkProg main theTable) :=
  W1Lib.of_table (fpLib main) (hashLib main) (get_of_mem main lookups_w1deps (by simp [asmW1Deps]))
    (get_of_mem main lookups_w1deps (by simp [asmW1Deps]))
    (get_of_mem main lookups_w1deps (by simp [asmW1Deps]))
    (get_of_mem main lookups_w1deps (by simp [asmW1Deps]))
    fun _ _ hib => get_of_mem main lookups_w1 hib

theorem w3Lib : W3Lib (mkProg main theTable) :=
  W3Lib.of_entries fun e he => get_of_lookup (lookups_w3 e he)

theorem w4Lib : W4Lib (mkProg main theTable) :=
  W4Lib.of_lookup lookups_w4

theorem bankLib : BankDSL.BankLib (mkProg main theTable) := by
  constructor <;> exact get_of_mem main lookups_bank (by simp [BankDSL.asmBankTable])

theorem mainLib : W6.MainLib (mkProg main theTable) :=
  W6.MainLib.of_table fun e he => get_of_lookup (lookups_w6 e he)

theorem tree1Lib : T1.Tree1Lib (mkProg main theTable) :=
  T1.Tree1Lib.of_entries fun e he => get_of_lookup (lookups_tree1 e he)

theorem tree4Lib : T4.Tree4Lib (mkProg main theTable) :=
  T4.Tree4Lib.of_lookup lookups_tree4

end F2e2e.C.Impl.Asm
