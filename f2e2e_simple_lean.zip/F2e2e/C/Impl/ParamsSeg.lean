import F2e2e.C.Impl.ParamsVal

/-!
# W1 (public parameters, DSL), part 4b: segments A–D of the master chain

Owner: C-PARAMS (e26ae4ae). The segments of `body_w1All` (`F2e2e/C/Impl/ParamsBodies.lean`) push the
claimed values `valsA P`, …, `valsD P` (the public parameters of `F2e2e/C/ParamsDefs.lean`), every value
`≤ 2^{8ℒ³}` (`ChainOK`, `F2e2e/C/Impl/ParamsPE.lean`). Segments E and F: `ParamsSegE.lean`,
`ParamsSegF.lean`. Every `PE.val … = P.X` goal is closed with the propositional lemmas of
`F2e2e/C/Impl/ParamsVal.lean` (never by a bare `rfl`, see there).
-/

set_option linter.unusedSimpArgs false

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

/-! ## Segment A: unpacking `encStreamParams P` -/

theorem segA_ok (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segA (valsA P) [] := by
  have hS := valSize_params_le P hM
  refine ChainOK.raw_cons (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp,
    encN P.betaExp]) (EvalsVal.var rfl) hS rfl) (n_le_A P) ?_
  refine ChainOK.raw_cons (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp,
    encN P.betaExp]) (EvalsVal.var rfl) hS rfl) (m_le_A P) ?_
  refine ChainOK.raw_cons (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp,
    encN P.betaExp]) (EvalsVal.var rfl) hS rfl) (U_le_A P) ?_
  refine ChainOK.raw_cons (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp,
    encN P.betaExp]) (EvalsVal.var rfl) hS rfl) (epsExp_le_A P) ?_
  refine ChainOK.raw_cons (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp,
    encN P.betaExp]) (EvalsVal.var rfl) hS rfl) (betaExp_le_A P) ?_
  exact ChainOK.nil

/-! ## Segment B: `H, T, D_*, W, log₂(1/η), ⌈log₂(8√T)⌉, log₂ B, B` -/

theorem segB_ok (hlib : W1Lib prog) (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segB (valsB P)
      [P.betaExp, P.epsExp, P.U, P.m, P.n] := by
  -- H
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.H])
    (H_le_Abnd P) ?_
  -- T
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.T]
      ring) (T_le_A P) ?_
  -- D_*
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.Dstar])
    (Dstar_le_A P) ?_
  -- W
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.W])
    (W_le_Abnd P) ?_
  -- log₂(1/η)
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.eEta, sq])
    (eEta_le_A P) ?_
  -- ⌈log₂(8√T)⌉ = ⌈(⌈log₂(64T)⌉)/2⌉
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.eGamma]
      rw [show (4 : ℕ) = 2 ^ 2 by norm_num, Nat.clog_pow_left]) (eGamma_le_A P) ?_
  -- log₂ B
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.logB])
    (logB_le_A P) ?_
  -- B
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        true_and]
      exact pow2_cond hlib hM (by have := Space.logB_le P; have := calL_le_cube P; omega))
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.B])
    (B_le_Abnd P) ?_
  exact ChainOK.nil

/-! ## Segment C: `V_H, H - 1, V_{H-1}` -/

theorem segC_ok (hlib : W1Lib prog) (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segC (valsC P)
      [P.B, P.logB, P.eGamma, P.eEta, P.W, P.Dstar, P.T, P.H, P.betaExp, P.epsExp, P.U, P.m,
        P.n] := by
  refine ChainOK.raw_cons (eVd_evals hlib.vdStep P rfl rfl rfl le_rfl hM) (Vd_le_Abnd P le_rfl) ?_
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ'])
    (Hm1_le_A P) ?_
  refine ChainOK.raw_cons (eVd_evals hlib.vdStep P rfl rfl rfl (Nat.sub_le _ _) hM)
    (Vd_le_Abnd P (Nat.sub_le _ _)) ?_
  exact ChainOK.nil

/-! ## Segment D: `V, log₂ G, log₂(1/ν), log₂ 𝒰_*, K_epoch, K_0, J_*, J_max, R_max, s, L` -/

theorem segD_ok (hlib : W1Lib prog) (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segD (valsD P)
      [P.Vd (P.H - 1), P.H - 1, P.Vd P.H, P.B, P.logB, P.eGamma, P.eEta, P.W, P.Dstar, P.T, P.H,
        P.betaExp, P.epsExp, P.U, P.m, P.n] := by
  -- V
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true]
      refine pow2_cond hlib hM ?_
      calc P.logB * (P.H + 1) ≤ (2 * P.calL) * (2 * P.calL) :=
            Nat.mul_le_mul (Space.logB_le P) (Space.H_add_one_le P)
        _ = 4 * P.calL ^ 2 := by ring
        _ ≤ 8 * P.calL ^ 3 := by have := calL_sq_le_cube P; omega)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.V,
        StreamParams.B]
      rw [← pow_mul]) (V_le_A P) ?_
  -- log₂ G
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.logG])
    (logG_le_A P) ?_
  -- log₂(1/ν)
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.eNu])
    (eNu_le_A P) ?_
  -- log₂ 𝒰_*
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.eUstar,
        StreamParams.eU, sq])
    (eUstar_le_A P) ?_
  -- K_epoch
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.Kepoch])
    (Kepoch_le_A P) ?_
  -- K_0
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true]
      exact pow2_cond hlib hM (by
        have := Space.eEta_le P; have := calL_le_cube P; have := Space.hundred_le_calL P; omega))
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.K0])
    (K0_le_A P) ?_
  -- J_*
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.Jstar])
    (Jstar_le_A P) ?_
  -- J_max
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.Jmax])
    (Jmax_le_A P) ?_
  -- R_max
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.Rmax])
    (Rmax_le_A P) ?_
  -- s
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.s])
    (s_le_A P) ?_
  -- L
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE',
        val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ', StreamParams.L])
    (L_le_A P) ?_
  exact ChainOK.nil

end W1

end F2e2e.C.Impl
