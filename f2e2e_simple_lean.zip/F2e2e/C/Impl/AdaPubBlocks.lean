import F2e2e.C.Impl.AdaPubLoops

/-!
# The ADA parameter record: the block sizes `[n_0, …, n_p]`

Routines of `adaPub` (`F2e2e/C/Impl/AdaPub.lean`) computing the block sizes `adaNBlock M J R eA eXi j`
(`F2e2e/B/ArchParams.lean`), namespace `F2e2e.C.Impl.AP`:

* `body_apCap` (652): `[A, g, b] ↦ if b then ⌈A/g⌉ else 0` (one cap `T_i^max`);
* `body_apC` (653): `[j, p, J, R, T_{j-2}, T_{j-1}, T_j, T_{j+1}] ↦ C_j` (`adaC`);
* `body_apCeilSqrt` (655): `m ↦ ⌈√m⌉` (`ceilSqrt`, via the library `natSqrt`);
* `body_apNB` (656): `[j, 4^j, A, p, J, R, χ, K₁, K₂, d_p] ↦ n_j = K₁ d_j ⌈√(C_j χ)⌉ + K₂`;
* `body_apBStep` (654): the loop building `[n_0, …, n_p]` from `j = p` down to `0`, with the running
  maximum (`apB_loop`).
-/

namespace F2e2e.Cost.Idx

/-- `adaPub` helper: one cap `T_i^max`. -/
abbrev apCap : ℕ := 652
/-- `adaPub` helper: `C_j`. -/
abbrev apC : ℕ := 653
/-- `adaPub` helper: loop step of the block sizes. -/
abbrev apBStep : ℕ := 654
/-- `adaPub` helper: `⌈√m⌉`. -/
abbrev apCeilSqrt : ℕ := 655
/-- `adaPub` helper: one block size `n_j`. -/
abbrev apNB : ℕ := 656

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

/-! ## Reference values -/

/-- One cap: `⌈A/g⌉` if `b`, else `0`. -/
def capV (A g : ℕ) (b : Bool) : ℕ := if b then (A + g - 1) / g else 0

/-- `C_j` from the four caps around `j`. -/
def cV (j p J R t0 t1 t2 t3 : ℕ) : ℕ :=
  if j = 0 then t2 + t3 + J + R + 2
  else if j < p then t0 + (t1 + t1) + (t2 + t2) + t3 + 2 else t0 + t1 + 1

theorem capV_tmax (eA j : ℕ) :
    capV (tmA eA) (2 ^ (2 * j)) (decide (j < adaP eA)) = adaTmax eA j := by
  unfold capV
  by_cases hj : j < adaP eA
  · simp [hj, adaTmax_eq hj]
  · simp [hj, adaTmax]

theorem capV_tmax_succ (eA j : ℕ) :
    capV (tmA eA) (4 * 2 ^ (2 * j)) (decide (j + 1 < adaP eA)) = adaTmax eA (j + 1) := by
  have e : 4 * 2 ^ (2 * j) = 2 ^ (2 * (j + 1)) := by
    rw [show 2 * (j + 1) = 2 * j + 2 by ring, pow_add]; ring
  rw [e, capV_tmax]

theorem capV_tmax_pred (eA j : ℕ) (hj : j ≤ adaP eA) :
    capV (tmA eA) (2 ^ (2 * j) / 4) (decide (0 < j)) =
      if 1 ≤ j then adaTmax eA (j - 1) else 0 := by
  unfold capV
  by_cases h : 1 ≤ j
  · have e : 2 ^ (2 * j) / 4 = 2 ^ (2 * (j - 1)) := by
      obtain ⟨i, rfl⟩ : ∃ i, j = i + 1 := ⟨j - 1, by omega⟩
      rw [four_pow_div_four, Nat.add_sub_cancel]
    have hlt : j - 1 < adaP eA := by omega
    simp [show 0 < j by omega, h, e, adaTmax_eq hlt]
  · simp [show ¬ 0 < j by omega, h]

theorem capV_tmax_pred2 (eA j : ℕ) (hj : j ≤ adaP eA) :
    capV (tmA eA) (2 ^ (2 * j) / 16) (decide (1 < j)) =
      if 2 ≤ j then adaTmax eA (j - 2) else 0 := by
  unfold capV
  by_cases h : 2 ≤ j
  · have e : 2 ^ (2 * j) / 16 = 2 ^ (2 * (j - 2)) := by
      obtain ⟨i, rfl⟩ : ∃ i, j = i + 2 := ⟨j - 2, by omega⟩
      rw [show 2 * (i + 2) = 2 * i + 4 by ring, pow_add, Nat.add_sub_cancel]
      norm_num
    have hlt : j - 2 < adaP eA := by omega
    simp [show 1 < j by omega, h, e, adaTmax_eq hlt]
  · simp [show ¬ 1 < j by omega, h]

theorem adaTmaxZ_sub (eA j k : ℕ) :
    adaTmaxZ eA ((j : ℤ) - k) = if k ≤ j then adaTmax eA (j - k) else 0 := by
  unfold adaTmaxZ
  by_cases h : k ≤ j
  · have e : (j : ℤ) - k = ((j - k : ℕ) : ℤ) := by omega
    rw [if_pos (by omega), if_pos h, e, Int.toNat_natCast]
  · rw [if_neg (by omega), if_neg h]

theorem adaC_eq_cV (J R eA j : ℕ) (hj : j ≤ adaP eA) :
    adaC J R eA j = cV j (adaP eA) J R (if 2 ≤ j then adaTmax eA (j - 2) else 0)
      (if 1 ≤ j then adaTmax eA (j - 1) else 0) (adaTmax eA j) (adaTmax eA (j + 1)) := by
  unfold adaC cV
  have h2 := adaTmaxZ_sub eA j 2
  have h1 := adaTmaxZ_sub eA j 1
  push_cast at h1 h2
  by_cases h0 : j = 0
  · subst h0
    simp
  · by_cases hlt : j < adaP eA
    · rw [if_neg h0, if_pos hlt, if_neg h0, if_pos hlt, h1, h2]
      ring
    · have hjp : j = adaP eA := by omega
      rw [if_neg h0, if_neg hlt, if_pos hjp, if_neg h0, if_neg hlt, h1, h2]

theorem adaD_eq (eA j : ℕ) :
    adaD eA j = if j < adaP eA then ceilSqrt (adaP eA * 2 ^ (2 * j)) else 2 ^ (eA + 11) * adaP eA := by
  unfold adaD
  rw [pow_mul]
  norm_num

/-- `n_j = K₁ d_j ⌈√(C_j χ)⌉ + K₂` with `K₁ = 2^20 χ h⁻¹`, `K₂ = 2^12 χ h⁻²`. -/
theorem adaNBlock_eq (Mc J R eA eXi j : ℕ) :
    adaNBlock Mc J R eA eXi j =
      1048576 * adaChi Mc J R eA eXi * adaHInv eA * adaD eA j *
        ceilSqrt (adaC J R eA j * adaChi Mc J R eA eXi) +
      4096 * adaChi Mc J R eA eXi * (adaHInv eA * adaHInv eA) := by
  unfold adaNBlock
  ring

theorem ceilSqrt_pos {m : ℕ} (hm : 1 ≤ m) : 1 ≤ ceilSqrt m := by
  unfold ceilSqrt
  have h := Nat.sqrt_pos.2 hm
  split_ifs <;> omega

theorem ceilSqrt_le_succ (m : ℕ) : ceilSqrt m ≤ m + 1 := by
  unfold ceilSqrt
  have h := Nat.sqrt_le_self m
  split_ifs <;> omega

/-! ## Size helpers -/

theorem size_le_of_lt_pow {x W : ℕ} (h : x < 2 ^ W) : Nat.size x ≤ W := Nat.size_le.2 h

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem evN_ltB {a b : Expr} {x y : ℕ} (ha : EvalsVal prog M env [] (.inl a) (encN x))
    (hb : EvalsVal prog M env [] (.inl b) (encN y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (encB (decide (x < y))) := by
  by_cases h : x < y
  · simpa [h] using evN_lt_true ha hb h hM
  · simpa [h] using evN_lt_false ha hb h hM

end rules

/-! ## `body_apCap` (652) -/

/-- `[A, g, b] ↦ if b then (A + g - 1)/g else 0`. -/
def body_apCap : Expr :=
  Expr.ite (eGet 2 (Expr.var 0))
    (Expr.bin BinOp.div
      (Expr.bin BinOp.sub (Expr.bin BinOp.add (eGet 0 (Expr.var 0)) (eGet 1 (Expr.var 0)))
        (Expr.lit 1))
      (eGet 1 (Expr.var 0)))
    (Expr.lit 0)

theorem apCap_ev {prog : List Expr} {M A g : ℕ} {b : Bool} (hg : b = true → 1 ≤ g)
    (hM : Nat.size A + Nat.size g + 12 ≤ M) :
    EvalsVal prog M [Val.list [encN A, encN g, encB b]] [] (.inl body_apCap)
      (encN (capV A g b)) := by
  have hb1 : bitLen (if b then (1 : ℤ) else 0) ≤ 1 := by cases b <;> simp
  have hX : valSize (Val.list [encN A, encN g, encB b]) ≤ M := by
    simp only [encB, valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
    omega
  have hv : EvalsVal prog M [Val.list [encN A, encN g, encB b]] [] (.inl (Expr.var 0))
      (Val.list [encN A, encN g, encB b]) := EvalsVal.var rfl
  have g0 := ev_get 0 hv hX (v := encN A) rfl
  have g1 := ev_get 1 hv hX (v := encN g) rfl
  have g2 := ev_get 2 hv hX (v := encB b) rfl
  cases b with
  | true =>
    have hg1 := hg rfl
    refine ev_ite_true g2 ?_
    have hAg := size_add_le A g
    have := size_le_of_le (Nat.sub_le (A + g) 1)
    refine evN_div (evN_sub (evN_add g0 g1 (by omega))
      (evN_lit 1 (by simp; omega)) (by omega) (by omega)) g1 (by omega) (by omega)
  | false =>
    refine ev_ite_false g2 ?_
    exact evN_lit 0 (by simp; omega)

/-! ## `body_apC` (653) -/

/-- `[j, p, J, R, T₀, T₁, T₂, T₃] ↦ C_j`. -/
def body_apC : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 (Expr.var 0)) (Expr.lit 0))
    (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add
      (Expr.bin BinOp.add (eGet 6 (Expr.var 0)) (eGet 7 (Expr.var 0))) (eGet 2 (Expr.var 0)))
      (eGet 3 (Expr.var 0))) (Expr.lit 2))
    (Expr.ite (Expr.bin BinOp.lt (eGet 0 (Expr.var 0)) (eGet 1 (Expr.var 0)))
      (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add
        (eGet 4 (Expr.var 0)) (Expr.bin BinOp.add (eGet 5 (Expr.var 0)) (eGet 5 (Expr.var 0))))
        (Expr.bin BinOp.add (eGet 6 (Expr.var 0)) (eGet 6 (Expr.var 0))))
        (eGet 7 (Expr.var 0))) (Expr.lit 2))
      (Expr.bin BinOp.add (Expr.bin BinOp.add (eGet 4 (Expr.var 0)) (eGet 5 (Expr.var 0)))
        (Expr.lit 1)))

theorem apC_ev {prog : List Expr} {M j p J R t0 t1 t2 t3 W : ℕ} (hj : j < 2 ^ W) (hp : p < 2 ^ W)
    (hJ : J < 2 ^ W) (hR : R < 2 ^ W) (h0 : t0 < 2 ^ W) (h1 : t1 < 2 ^ W) (h2 : t2 < 2 ^ W)
    (h3 : t3 < 2 ^ W) (hM : 8 * W + 40 ≤ M) :
    EvalsVal prog M [Val.list [encN j, encN p, encN J, encN R, encN t0, encN t1, encN t2, encN t3]]
      [] (.inl body_apC) (encN (cV j p J R t0 t1 t2 t3)) := by
  set X := Val.list [encN j, encN p, encN J, encN R, encN t0, encN t1, encN t2, encN t3] with hXd
  have sj := size_le_of_lt_pow hj
  have sp := size_le_of_lt_pow hp
  have sJ := size_le_of_lt_pow hJ
  have sR := size_le_of_lt_pow hR
  have s0 := size_le_of_lt_pow h0
  have s1 := size_le_of_lt_pow h1
  have s2 := size_le_of_lt_pow h2
  have s3 := size_le_of_lt_pow h3
  have hX : valSize X ≤ M := by
    simp only [hXd, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have hv : EvalsVal prog M [X] [] (.inl (Expr.var 0)) X := EvalsVal.var rfl
  have g0 := ev_get 0 hv hX (v := encN j) rfl
  have g1 := ev_get 1 hv hX (v := encN p) rfl
  have g2 := ev_get 2 hv hX (v := encN J) rfl
  have g3 := ev_get 3 hv hX (v := encN R) rfl
  have g4 := ev_get 4 hv hX (v := encN t0) rfl
  have g5 := ev_get 5 hv hX (v := encN t1) rfl
  have g6 := ev_get 6 hv hX (v := encN t2) rfl
  have g7 := ev_get 7 hv hX (v := encN t3) rfl
  have hW8 : 8 * 2 ^ W = 2 ^ (W + 3) := by rw [pow_add]; ring
  have hsz : ∀ x, x < 8 * 2 ^ W → Nat.size x + 1 ≤ M := by
    intro x hx
    have := size_le_of_lt_pow (show x < 2 ^ (W + 3) by omega)
    omega
  have l0 := evN_lit (prog := prog) (M := M) (env := [X]) 0 (by simp; omega)
  have l1 := evN_lit (prog := prog) (M := M) (env := [X]) 1 (by simp; omega)
  have l2 := evN_lit (prog := prog) (M := M) (env := [X]) 2 (by
    have : Nat.size 2 ≤ 2 := Nat.size_le.2 (by norm_num)
    omega)
  unfold cV
  by_cases hj0 : j = 0
  · rw [if_pos hj0]
    refine ev_ite_true (evN_eq_true g0 l0 hj0 (by omega)) ?_
    exact evN_add (evN_add (evN_add (evN_add g6 g7 (hsz _ (by omega))) g2 (hsz _ (by omega)))
      g3 (hsz _ (by omega))) l2 (hsz _ (by omega))
  · rw [if_neg hj0]
    refine ev_ite_false (evN_eq_false g0 l0 hj0 (by omega)) ?_
    by_cases hjp : j < p
    · rw [if_pos hjp]
      refine ev_ite_true (evN_lt_true g0 g1 hjp (by omega)) ?_
      exact evN_add (evN_add (evN_add (evN_add g4 (evN_add g5 g5 (hsz _ (by omega)))
        (hsz _ (by omega))) (evN_add g6 g6 (hsz _ (by omega))) (hsz _ (by omega))) g7
        (hsz _ (by omega))) l2 (hsz _ (by omega))
    · rw [if_neg hjp]
      refine ev_ite_false (evN_lt_false g0 g1 hjp (by omega)) ?_
      exact evN_add (evN_add g4 g5 (hsz _ (by omega))) l1 (hsz _ (by omega))

/-! ## `body_apCeilSqrt` (655) -/

/-- `m ↦ ⌈√m⌉ = if s² = m then s else s + 1`, `s = ⌊√m⌋` (library `natSqrt`). -/
def body_apCeilSqrt : Expr :=
  Expr.letE (Expr.call Cost.Idx.natSqrt (Expr.var 0))
    (Expr.ite (Expr.bin BinOp.eq (Expr.bin BinOp.mul (Expr.var 0) (Expr.var 0)) (Expr.var 1))
      (Expr.var 0) (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1)))

theorem apCeilSqrt_ev {prog : List Expr} {M : ℕ}
    (h0 : prog[Cost.Idx.natSqrt]? = some body_natSqrt)
    (h1 : prog[Cost.Idx.natSqrtStep]? = some body_natSqrtStep) (m : ℕ)
    (hM : 25 * Nat.size m + 100 ≤ M) :
    EvalsVal prog M [encN m] [] (.inl body_apCeilSqrt) (encN (ceilSqrt m)) := by
  have hs := natSqrt_ev (env := [encN m]) h0 h1 (EvalsVal.var (i := 0) rfl) hM
  refine ev_letE hs ?_
  have hsq : Nat.sqrt m * Nat.sqrt m ≤ m := Nat.sqrt_le m
  have hss : Nat.size (Nat.sqrt m * Nat.sqrt m) ≤ Nat.size m := size_le_of_le hsq
  have hs1 : Nat.size (Nat.sqrt m + 1) ≤ Nat.size m + 1 :=
    (size_succ_le _).trans (Nat.add_le_add_right (size_le_of_le (Nat.sqrt_le_self m)) 1)
  have v0 : EvalsVal prog M [encN (Nat.sqrt m), encN m] [] (.inl (Expr.var 0))
      (encN (Nat.sqrt m)) := EvalsVal.var rfl
  have v1 : EvalsVal prog M [encN (Nat.sqrt m), encN m] [] (.inl (Expr.var 1)) (encN m) :=
    EvalsVal.var rfl
  have hmul := evN_mul v0 v0 (by omega)
  unfold ceilSqrt
  by_cases he : Nat.sqrt m * Nat.sqrt m = m
  · rw [if_pos he]
    exact ev_ite_true (evN_eq_true hmul v1 he (by omega)) v0
  · rw [if_neg he]
    exact ev_ite_false (evN_eq_false hmul v1 he (by omega))
      (evN_add v0 (evN_lit 1 (by simp; omega)) (by omega))

end F2e2e.C.Impl.AP
