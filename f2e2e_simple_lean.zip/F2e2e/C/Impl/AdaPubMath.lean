import F2e2e.C.Impl.AdaRep

/-!
# The ADA parameter record: closed forms of B-ARCH's parameters (`F2e2e/B/ArchParams.lean`)

Pure arithmetic facts used by the DSL routine `adaPub` (`F2e2e/C/Impl/AdaPub.lean`), for the
parameters `adaParams eA eXi M J R` (namespace `F2e2e.C.Impl.AP`):

* `natCeil_div_eq`: `⌈a / b⌉₊ = (a + b - 1) / b` for naturals, `b > 0`;
* `adaP_spec`, `adaP_min`: the level count `p` is the least `p ≥ 2` with `p 2^{eA+3} ≤ 2^{p-1}`;
* `adaTau_eq`: `τ = 1/(8 p 2^{eA})`; `adaTmax_eq`: `T_j^max = (A + 4^j - 1)/4^j`, `A = 384 p² 4^{eA}`;
* `adaZeta_eq`: `ζ = 1/Z_d`, `Z_d = 98304000 p (p+1) Q 2^{eA} 2^{eXi}`; `adaB0_eq`: `B_0 = ⌈log₂(16 Z_d)⌉`;
* `scale_eq`: the five noise scales are `1/m_κ` (`mK`); `rho_eq`, `Ks_eq`, `rs_eq` for scales `1/m`;
* `a_half_eq`, `scoreScale_eq`: `a/2 = 1/(2·2^{eA})`, `κ h_A/4 = 1/(128 p 2^{eA} 2^{q_A})`.
-/

namespace F2e2e.C.Impl.AP

open F2e2e.B

/-! ## Ceiling of a quotient of naturals -/

theorem natCeil_div_eq (a b : ℕ) (hb : 0 < b) : ⌈((a : ℚ) / (b : ℚ))⌉₊ = (a + b - 1) / b := by
  have hb' : (0 : ℚ) < b := by exact_mod_cast hb
  apply le_antisymm
  · apply Nat.ceil_le.2
    rw [div_le_iff₀ hb']
    have h1 : a ≤ (a + b - 1) / b * b := by
      have h2 := Nat.div_add_mod (a + b - 1) b
      have h3 := Nat.mod_lt (a + b - 1) hb
      have h4 : (a + b - 1) / b * b = b * ((a + b - 1) / b) := Nat.mul_comm _ _
      omega
    exact_mod_cast h1
  · have h := Nat.le_ceil ((a : ℚ) / (b : ℚ))
    rw [div_le_iff₀ hb'] at h
    have h' : a ≤ ⌈((a : ℚ) / (b : ℚ))⌉₊ * b := by exact_mod_cast h
    have h2 : (a + b - 1) / b < ⌈((a : ℚ) / (b : ℚ))⌉₊ + 1 := by
      rw [Nat.div_lt_iff_lt_mul hb, Nat.add_mul, one_mul]
      omega
    omega

/-! ## The level count `p` -/

theorem adaP_spec (eA : ℕ) : 2 ≤ adaP eA ∧ adaP eA * 2 ^ (eA + 3) ≤ 2 ^ (adaP eA - 1) :=
  Nat.find_spec (exists_adaP eA)

theorem two_le_adaP (eA : ℕ) : 2 ≤ adaP eA := (adaP_spec eA).1

theorem adaP_min {eA q : ℕ} (h2 : 2 ≤ q) (h : q * 2 ^ (eA + 3) ≤ 2 ^ (q - 1)) : adaP eA ≤ q :=
  Nat.find_min' (exists_adaP eA) ⟨h2, h⟩

theorem adaP_cast_ne_zero (eA : ℕ) : (adaP eA : ℚ) ≠ 0 := by
  have := two_le_adaP eA
  exact_mod_cast (show adaP eA ≠ 0 by omega)

/-! ## Margins, caps, `ζ` and `B_0` -/

/-- `τ = a/(8p) = 1/(8 p 2^{eA})`. -/
theorem adaTau_eq (eA : ℕ) : adaTauQ eA = 1 / ((8 * adaP eA * 2 ^ eA : ℕ) : ℚ) := by
  have hp := adaP_cast_ne_zero eA
  unfold adaTauQ adaA
  push_cast
  rw [one_div_pow]
  field_simp

/-- The numerator `A = 384 p² 4^{eA}` of `T_j^max = ⌈A/4^j⌉`. -/
def tmA (eA : ℕ) : ℕ := 384 * adaP eA * adaP eA * (2 ^ eA * 2 ^ eA)

theorem adaTmax_eq {eA j : ℕ} (hj : j < adaP eA) :
    adaTmax eA j = (tmA eA + 2 ^ (2 * j) - 1) / 2 ^ (2 * j) := by
  unfold adaTmax
  rw [if_pos hj]
  have hp := adaP_cast_ne_zero eA
  have h : (6 : ℚ) / (4 ^ j * adaTauQ eA ^ 2) = ((tmA eA : ℕ) : ℚ) / ((2 ^ (2 * j) : ℕ) : ℚ) := by
    rw [adaTau_eq]
    unfold tmA
    push_cast
    rw [pow_mul]
    norm_num
    field_simp
    ring
  rw [h, natCeil_div_eq _ _ (by positivity)]

theorem adaQ_pos (M J R eA : ℕ) : 0 < adaQ M J R eA := by
  unfold adaQ
  positivity

theorem adaChi_pos (M J R eA eXi : ℕ) : 0 < adaChi M J R eA eXi := by
  unfold adaChi
  omega

/-- `Z_d = 1/ζ = 98304000 p (p+1) Q 2^{eA} 2^{eXi}`. -/
def zdQ (M J R eA eXi : ℕ) : ℕ :=
  98304000 * adaP eA * (adaP eA + 1) * adaQ M J R eA * (2 ^ eA * 2 ^ eXi)

theorem zdQ_pos (M J R eA eXi : ℕ) : 0 < zdQ M J R eA eXi := by
  have hp := two_le_adaP eA
  have hQ := adaQ_pos M J R eA
  unfold zdQ
  positivity

/-- `ζ = δ/(1000 Q) = 1/Z_d`. -/
theorem adaZeta_eq (M J R eA eXi : ℕ) : adaZeta M J R eA eXi = 1 / ((zdQ M J R eA eXi : ℕ) : ℚ) := by
  have hp := adaP_cast_ne_zero eA
  have hQ : (adaQ M J R eA : ℚ) ≠ 0 := by
    have := adaQ_pos M J R eA
    exact_mod_cast this.ne'
  unfold adaZeta adaDelta adaH adaXiJ adaXiA
  rw [adaTau_eq]
  unfold zdQ
  push_cast
  rw [one_div_pow]
  field_simp
  ring

/-- `B_0 = ⌈log₂(16/ζ)⌉ = ⌈log₂(16 Z_d)⌉`. -/
theorem adaB0_eq (M J R eA eXi : ℕ) : adaB0 M J R eA eXi = Nat.clog 2 (16 * zdQ M J R eA eXi) := by
  unfold adaB0
  rw [adaZeta_eq]
  have h : (16 : ℚ) / (1 / ((zdQ M J R eA eXi : ℕ) : ℚ)) = ((16 * zdQ M J R eA eXi : ℕ) : ℚ) := by
    rw [div_div_eq_mul_div, div_one]
    push_cast
    ring
  rw [h, Nat.ceil_natCast]

/-! ## Noise scales and the sampler parameters -/

/-- The denominators `m_κ` of the five noise scales (`scale κ = 1/m_κ`). -/
def mK (M J R eA eXi : ℕ) : NoiseKind → ℕ
  | NoiseKind.intThr => 32768 * adaP eA * 2 ^ eA * adaChi M J R eA eXi
  | NoiseKind.intTest => 16384 * adaP eA * 2 ^ eA * adaChi M J R eA eXi
  | NoiseKind.outThr => 256 * adaChi M J R eA eXi * 2 ^ eA
  | NoiseKind.outTest => 128 * adaChi M J R eA eXi * 2 ^ eA
  | NoiseKind.num => 64 * adaChi M J R eA eXi * 2 ^ eA

theorem mK_pos (M J R eA eXi : ℕ) (κ : NoiseKind) : 0 < mK M J R eA eXi κ := by
  have hp := two_le_adaP eA
  have hc := adaChi_pos M J R eA eXi
  cases κ <;> simp only [mK] <;> positivity

theorem scale_eq (M J R eA eXi : ℕ) (κ : NoiseKind) :
    (adaParams eA eXi M J R).scale κ = 1 / ((mK M J R eA eXi κ : ℕ) : ℚ) := by
  have hp := adaP_cast_ne_zero eA
  have hc : (adaChi M J R eA eXi : ℚ) ≠ 0 := by
    have := adaChi_pos M J R eA eXi
    exact_mod_cast this.ne'
  cases κ <;> simp only [AdaParams.scale, adaParams, mK, adaH, adaTau_eq, adaA, one_div_pow] <;>
    push_cast <;> field_simp <;> ring

theorem hA_eq (A : AdaParams) : A.hA = 1 / ((2 ^ A.qA : ℕ) : ℚ) := by
  unfold AdaParams.hA
  push_cast
  rw [one_div_pow]

/-- `ϱ = b/(b + h_A) = 2^{q_A}/(2^{q_A} + m)` for `b = 1/m`. -/
theorem rho_eq (A : AdaParams) {m : ℕ} (hm : 0 < m) :
    A.rho (1 / (m : ℚ)) = ((2 ^ A.qA : ℕ) : ℚ) / ((2 ^ A.qA + m : ℕ) : ℚ) := by
  have hm' : (m : ℚ) ≠ 0 := by exact_mod_cast hm.ne'
  unfold AdaParams.rho
  rw [hA_eq]
  push_cast
  field_simp

/-- `K_s = ⌈((b + h_A)/h_A) B_0⌉ = ((2^{q_A} + m) B_0 + m - 1)/m` for `b = 1/m`. -/
theorem Ks_eq (A : AdaParams) {m : ℕ} (hm : 0 < m) :
    A.Ks (1 / (m : ℚ)) = ((2 ^ A.qA + m) * A.B0 + m - 1) / m := by
  have hm' : (m : ℚ) ≠ 0 := by exact_mod_cast hm.ne'
  unfold AdaParams.Ks
  rw [hA_eq]
  have h : (1 / (m : ℚ) + 1 / ((2 ^ A.qA : ℕ) : ℚ)) / (1 / ((2 ^ A.qA : ℕ) : ℚ)) * (A.B0 : ℚ) =
      (((2 ^ A.qA + m) * A.B0 : ℕ) : ℚ) / (m : ℚ) := by
    push_cast
    field_simp
  rw [h, natCeil_div_eq _ _ hm]

/-- `r_s = ⌈log₂(32 (K_s + 1)/ζ)⌉ = ⌈log₂(32 (K_s + 1) Z)⌉` for `ζ = 1/Z`. -/
theorem rs_eq (A : AdaParams) (b : ℚ) {Z : ℕ} (hz : A.zeta = 1 / (Z : ℚ)) :
    A.rs b = Nat.clog 2 (32 * (A.Ks b + 1) * Z) := by
  unfold AdaParams.rs
  rw [hz]
  have h : 32 * ((A.Ks b : ℚ) + 1) / (1 / (Z : ℚ)) = ((32 * (A.Ks b + 1) * Z : ℕ) : ℚ) := by
    rw [div_div_eq_mul_div, div_one]
    push_cast
    ring
  rw [h, Nat.ceil_natCast]

/-- `a/2 = 1/(2·2^{eA})`. -/
theorem a_half_eq (eA eXi M J R : ℕ) : (adaParams eA eXi M J R).a / 2 = 1 / ((2 * 2 ^ eA : ℕ) : ℚ) := by
  simp only [adaParams, adaA]
  push_cast
  rw [one_div_pow]
  field_simp

/-- `κ h_A/4 = 1/(128 p 2^{eA} 2^{q_A})`. -/
theorem scoreScale_eq (eA eXi M J R : ℕ) :
    scoreScale (adaParams eA eXi M J R) =
      1 / ((128 * adaP eA * 2 ^ eA * 2 ^ (adaQA M J R eA eXi) : ℕ) : ℚ) := by
  have hp := adaP_cast_ne_zero eA
  unfold scoreScale
  rw [hA_eq]
  simp only [adaParams, adaKappa, adaTau_eq]
  push_cast
  field_simp
  ring

end F2e2e.C.Impl.AP
