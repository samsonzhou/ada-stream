import F2e2e.C.Impl.AdaPrepEdge
import F2e2e.C.Impl.AdaPrepCorr

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 4: the scan pass (B-NUM)

* `adaReset` (Idx 707): `[j, cache, p] ↦ encL encB (resetCache A j cache)`;
* `adaScanStep` (Idx 703): one iteration of a scan pass, the body of the inner loop, on the accumulator
  `scanEnc A vals mz (j, st, cache) = [j, st, cache, pub, vals, mus]` (`mus` the integer predictions of
  the pass); it implements `scanQ A vals mus` (`AdaPrepRef.lean`) with the loop encoding
  `[1, next accumulator]` / `[0, scanOut (outcome, st', cache')]`;
* `scanLoop_impl`: the loop `loop 703` from `(0, st, cache)` implements the whole scan pass
  `scanRef A vals (adaMus A st vals) (0, st, cache)`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

section Generic

variable {prog : List Expr} {M : ℕ}

/-! ## Generic rules -/

theorem ap_implements_ite_true {α : Type} {env : List Val} {c t f : Expr} {z : ℤ} {enc : α → Val}
    {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : Implements prog M env t enc p) : Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  have := EvalsVal.ite_true (f := f) hc hz (ht bits a h)
  simpa using this

theorem ap_implements_ite_false {α : Type} {env : List Val} {c t f : Expr} {z : ℤ} {enc : α → Val}
    {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : Implements prog M env f enc p) : Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  have := EvalsVal.ite_false (t := t) hc hz (hf bits a h)
  simpa using this

/-- Reading an encoded list with the library `get` (default `Val.int 0`). -/
theorem ap_getD_map_int0 {β : Type} (l : List β) (f : β → Val) {d : β} (hd : f d = Val.int 0) (j : ℕ) :
    (l.map f).getD j (Val.int 0) = f (l.getD j d) := by
  rw [← hd, List.getD_map]

theorem ap_getD_map_lt {β : Type} (l : List β) (f : β → Val) (d : β) (v : Val) {j : ℕ}
    (hj : j < l.length) : (l.map f).getD j v = f (l.getD j d) := by
  rw [List.getD_eq_getElem _ _ (by simpa using hj), List.getD_eq_getElem _ _ hj, List.getElem_map]

theorem ap_valSize_list3 (a b c : Val) :
    valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem ap_valSize_list2 (a b : Val) : valSize (Val.list [a, b]) = valSize a + valSize b + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- `set` on a deterministic triple `[l, n, x]`. -/
theorem ap_set_call (hL : ListLib prog) {env : List Val} {eL eN eX : Expr} {l : List Val} {n : ℕ}
    {x : Val} (h1 : EvalsVal prog M env [] (.inl eL) (Val.list l))
    (h2 : EvalsVal prog M env [] (.inl eN) (Val.int (n : ℤ))) (h3 : EvalsVal prog M env [] (.inl eX) x)
    (hM : S_set l n x ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.set (eList [eL, eN, eX]))) (Val.list (l.set n x)) := by
  refine set_val hL ?_ hM
  refine evalsVal_list (List.Forall₂.cons h1 (List.Forall₂.cons h2 (List.Forall₂.cons h3
    List.Forall₂.nil))) ?_
  refine le_trans ?_ hM
  rw [ap_valSize_list3, valSize_int, bitLen_natCast]
  unfold S_set
  omega

/-- `get` on a deterministic pair `[l, n]`. -/
theorem ap_get_call (hL : ListLib prog) {env : List Val} {eL eN : Expr} {l : List Val} {n : ℕ}
    (h1 : EvalsVal prog M env [] (.inl eL) (Val.list l))
    (h2 : EvalsVal prog M env [] (.inl eN) (Val.int (n : ℤ))) (hM : S_get l n ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.get (ePair eL eN))) (l.getD n (Val.int 0)) := by
  refine get_val hL (EvalsVal.pair h1 h2 ?_) hM
  refine le_trans ?_ hM
  rw [ap_valSize_list2, valSize_int, bitLen_natCast]
  unfold S_get
  omega

/-- A literal `0` or `1`. -/
theorem ap_lit_small {env : List Val} {z : ℤ} (hz : bitLen z ≤ 2) (hM : 3 ≤ M) :
    EvalsVal prog M env [] (.inl (eLit z)) (Val.int z) :=
  EvalsVal.lit (by rw [valSize_int]; omega)

end Generic

/-! ## Encodings -/

/-- Pass outcomes: `done ↦ 0`, `corrected ↦ 1`, `abort ↦ 2`. -/
def encPO : PassOut → Val
  | PassOut.done => Val.int 0
  | PassOut.corrected => Val.int 1
  | PassOut.abort => Val.int 2

/-- The output of a scan pass: `[outcome, st', cache']`. -/
def scanOut (r : PassOut × AdaState × List Bool) : Val :=
  Val.list [encPO r.1, adaEnc r.2.1, encL encB r.2.2]

/-- The accumulator of the scan loop: `[j, st, cache, pub, vals, mus]`. -/
def scanEnc (A : AdaParams) (vals : List (List ℕ)) (mz : List (ℤ × ℤ))
    (s : ℕ × AdaState × List Bool) : Val :=
  Val.list [encN s.1, adaEnc s.2.1, encL encB s.2.2, adaPubEnc A, encVals vals, encL encPZ mz]

theorem ap_encL_encB_set (c : List Bool) (n : ℕ) (b : Bool) :
    Val.list ((c.map encB).set n (encB b)) = encL encB (c.set n b) := by
  simp [encL, List.map_set]

theorem ap_valSize_encL_encB (c : List Bool) : valSize (encL encB c) ≤ 1 + 3 * c.length := by
  have := valSize_encL_le encB c 2 (fun b _ => valSize_encB_le b)
  omega

/-! ## `adaReset` (Idx 707) -/

theorem resetCache_eq (A : AdaParams) (j : ℕ) (cache : List Bool) :
    resetCache A j cache =
      (if j + 1 < A.p then
        ((if 1 ≤ j then cache.set (j - 1) false else cache).set j false).set (j + 1) false
      else (if 1 ≤ j then cache.set (j - 1) false else cache).set j false) := by
  unfold resetCache reopenEdges
  by_cases h1 : 1 ≤ j <;> by_cases h2 : j + 1 < A.p <;> simp [h1, h2]

/-- **`adaReset`** (Idx 707): `[j, cache, p] ↦` the cache with the reopened edges invalidated. -/
def body_adaReset : Expr :=
  eLet (eIte (eLt (eLit 0) (eAtN 0 (eV 0)))
      (eCall Idx.set (eList [eAtN 1 (eV 0), eSub (eAtN 0 (eV 0)) (eLit 1), eLit 0]))
      (eAtN 1 (eV 0)))
    (eLet (eCall Idx.set (eList [eV 0, eAtN 0 (eV 1), eLit 0]))
      (eIte (eLt (eAdd (eAtN 0 (eV 2)) (eLit 1)) (eAtN 2 (eV 2)))
        (eCall Idx.set (eList [eV 0, eAdd (eAtN 0 (eV 2)) (eLit 1), eLit 0]))
        (eV 0)))

section Reset

variable {prog : List Expr} {M : ℕ}

/-- **Spec of `adaReset`.** -/
theorem adaReset_val (hL : ListLib prog) (A : AdaParams) {j : ℕ} {cache : List Bool}
    (hj : j ≤ A.p) (hc : cache.length = A.p) (hM : 2 ^ 6 * (A.p + 8) ≤ M) :
    EvalsVal prog M [Val.list [encN j, encL encB cache, encN A.p]] [] (.inl body_adaReset)
      (encL encB (resetCache A j cache)) := by
  set z : Val := Val.list [encN j, encL encB cache, encN A.p] with hz
  have hsj : Nat.size j ≤ A.p := (size_le_self j).trans hj
  have hsp : Nat.size A.p ≤ A.p := size_le_self A.p
  have hcS : ∀ c : List Bool, c.length = A.p → valSize (encL encB c) ≤ 1 + 3 * A.p := by
    intro c hcl
    have := ap_valSize_encL_encB c
    rw [hcl] at this
    exact this
  have hzM : valSize z ≤ M := by
    have := hcS cache hc
    rw [hz, ap_valSize_list3, valSize_encN, valSize_encN]
    omega
  have h3 : 3 ≤ M := by omega
  -- set on a cache-shaped list at an index `≤ p + 1`
  have hsetM : ∀ (c : List Bool) (n : ℕ), c.length = A.p → n ≤ A.p + 1 →
      S_set (c.map encB) n (Val.int 0) ≤ M := by
    intro c n hcl hn
    unfold S_set
    have h1 := hcS c hcl
    have h2 : Nat.size n ≤ A.p + 1 := (size_le_self n).trans hn
    simp only [encL] at h1
    simp only [valSize_int, bitLen_zero]
    omega
  have hzj : ∀ {env : List Val}, env[0]? = some z →
      EvalsVal prog M env [] (.inl (eAtN 0 (eV 0))) (encN j) :=
    fun h => evalsVal_atN' (EvalsVal.var h) hzM rfl
  -- c1
  set c1 : List Bool := if 1 ≤ j then cache.set (j - 1) false else cache with hc1
  have hc1l : c1.length = A.p := by rw [hc1]; split_ifs <;> simp [hc]
  have he1 : EvalsVal prog M [z] [] (.inl (eIte (eLt (eLit 0) (eAtN 0 (eV 0)))
      (eCall Idx.set (eList [eAtN 1 (eV 0), eSub (eAtN 0 (eV 0)) (eLit 1), eLit 0]))
      (eAtN 1 (eV 0)))) (encL encB c1) := by
    have hcond := EvalsVal.lt (ap_lit_small (env := [z]) (z := 0) (by decide) h3) (hzj rfl) (by omega)
    by_cases h1 : 1 ≤ j
    · have hjp : (0 : ℤ) < (j : ℤ) := by exact_mod_cast h1
      refine EvalsVal.ite_true hcond (by rw [if_pos hjp]; exact one_ne_zero) ?_
      have hcast : (j : ℤ) - 1 = ((j - 1 : ℕ) : ℤ) := by omega
      have hsub := EvalsVal.sub (hzj rfl) (ap_lit_small (env := [z]) (z := 1) (by decide) h3) (by
        rw [hcast, valSize_int, bitLen_natCast]
        have := size_le_self (j - 1)
        omega)
      rw [hcast] at hsub
      have := ap_set_call hL (evalsVal_atN' EvalsVal.var0 hzM (rfl : [encN j, encL encB cache,
        encN A.p][1]? = some (encL encB cache))) hsub (ap_lit_small (z := 0) (by decide) h3)
        (hsetM cache (j - 1) hc (by omega))
      rw [show (Val.int 0 : Val) = encB false from rfl, ap_encL_encB_set] at this
      rw [hc1, if_pos h1]
      exact this
    · have hj0 : ¬ ((0 : ℤ) < (j : ℤ)) := by exact_mod_cast h1
      refine EvalsVal.ite_false hcond (by rw [if_neg hj0]) ?_
      rw [hc1, if_neg h1]
      exact evalsVal_atN' EvalsVal.var0 hzM rfl
  -- c2
  have he2 : EvalsVal prog M [encL encB c1, z] [] (.inl (eCall Idx.set (eList [eV 0, eAtN 0 (eV 1),
      eLit 0]))) (encL encB (c1.set j false)) := by
    have h1 : EvalsVal prog M [encL encB c1, z] [] (.inl (eV 0)) (Val.list (c1.map encB)) :=
      EvalsVal.var0
    have h2 : EvalsVal prog M [encL encB c1, z] [] (.inl (eAtN 0 (eV 1))) (Val.int (j : ℤ)) :=
      evalsVal_atN' (n := 0) EvalsVal.var1 hzM rfl
    have := ap_set_call hL h1 h2 (ap_lit_small (z := 0) (by decide) h3) (hsetM c1 j hc1l (by omega))
    rw [show (Val.int 0 : Val) = encB false from rfl, ap_encL_encB_set] at this
    exact this
  -- c3
  have hres : resetCache A j cache =
      if j + 1 < A.p then (c1.set j false).set (j + 1) false else c1.set j false := by
    rw [resetCache_eq]
  have hc2l : (c1.set j false).length = A.p := by simp [hc1l]
  have he3 : EvalsVal prog M [encL encB (c1.set j false), encL encB c1, z] []
      (.inl (eIte (eLt (eAdd (eAtN 0 (eV 2)) (eLit 1)) (eAtN 2 (eV 2)))
        (eCall Idx.set (eList [eV 0, eAdd (eAtN 0 (eV 2)) (eLit 1), eLit 0])) (eV 0)))
      (encL encB (resetCache A j cache)) := by
    have hjE : EvalsVal prog M [encL encB (c1.set j false), encL encB c1, z] [] (.inl (eAtN 0 (eV 2)))
        (encN j) := evalsVal_atN' EvalsVal.var2 hzM rfl
    have hcast : (j : ℤ) + 1 = ((j + 1 : ℕ) : ℤ) := by push_cast; ring
    have hadd := EvalsVal.add hjE (ap_lit_small (z := 1) (by decide) h3) (by
      rw [hcast, valSize_int, bitLen_natCast]
      have := size_le_self (j + 1)
      omega)
    rw [hcast] at hadd
    have hpE : EvalsVal prog M [encL encB (c1.set j false), encL encB c1, z] [] (.inl (eAtN 2 (eV 2)))
        (encN A.p) := evalsVal_atN' EvalsVal.var2 hzM rfl
    have hcond := EvalsVal.lt hadd hpE (by omega)
    by_cases h2 : j + 1 < A.p
    · have h2' : ((j + 1 : ℕ) : ℤ) < (A.p : ℤ) := by exact_mod_cast h2
      refine EvalsVal.ite_true hcond (by rw [if_pos h2']; exact one_ne_zero) ?_
      have := ap_set_call hL (l := (c1.set j false).map encB) EvalsVal.var0 hadd
        (ap_lit_small (z := 0) (by decide) h3) (hsetM (c1.set j false) (j + 1) hc2l (by omega))
      rw [show (Val.int 0 : Val) = encB false from rfl, ap_encL_encB_set] at this
      rw [hres, if_pos h2]
      exact this
    · have h2' : ¬ (((j + 1 : ℕ) : ℤ) < (A.p : ℤ)) := by exact_mod_cast h2
      refine EvalsVal.ite_false hcond (by rw [if_neg h2']) ?_
      rw [hres, if_neg h2]
      exact EvalsVal.var0
  exact EvalsVal.letE he1 (EvalsVal.letE he2 he3)

end Reset

/-! ## The scan step (Idx 703) -/

/-- Field `n` of the accumulator at de Bruijn index `k`. -/
abbrev aF (n k : ℕ) : Expr := eAtN n (eV k)

/-- **`adaScanStep`** (Idx 703): one iteration of a scan pass on `[j, st, cache, pub, vals, mus]`. -/
def body_adaScanStep : Expr :=
  eIte (eLt (aF 0 0) (eAtN 0 (aF 3 0)))
    (eIte (eCall Idx.get (ePair (aF 2 0) (aF 0 0)))
      (ePair (eLit 1) (eList [eAdd (aF 0 0) (eLit 1), aF 1 0, aF 2 0, aF 3 0, aF 4 0, aF 5 0]))
      (eLet (eCall Idx.adaEdge (eList [aF 3 0,
            eCall Idx.get (ePair (eAtN 2 (aF 1 0)) (aF 0 0)),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1)))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1))))]))
        (eIte (eEq (eV 0) (eLit 0))
          (ePair (eLit 1) (eList [eAdd (aF 0 1) (eLit 1), aF 1 1,
            eCall Idx.set (eList [aF 2 1, aF 0 1, eLit 1]), aF 3 1, aF 4 1, aF 5 1]))
          (eIte (eLt (eCall Idx.get (ePair (eAtN 1 (aF 1 1)) (aF 0 1)))
                (eCall Idx.get (ePair (eAtN 2 (aF 3 1)) (aF 0 1))))
            (eLet (eCall Idx.adaCorr (eList [aF 0 1, eIte (eEq (eV 0) (eLit 1)) (eLit 1) (eLit (-1)),
                aF 1 1, aF 3 1, aF 4 1]))
              (ePair (eLit 0) (eList [eLit 1, eV 0,
                eCall Idx.adaReset (eList [aF 0 2, aF 2 2, eAtN 0 (aF 3 2)])])))
            (ePair (eLit 0) (eList [eLit 2, aF 1 1, aF 2 1]))))))
    (ePair (eLit 0) (eList [eLit 0, aF 1 0, aF 2 0]))

/-- The invariant of the scan loop for the pass that started in the state `st0`. -/
def ScanInv (A : AdaParams) (st0 : AdaState) (s : ℕ × AdaState × List Bool) : Prop :=
  s.2.1 = st0 ∧ s.2.2.length = A.p ∧ s.1 ≤ A.p

/-- The size budget `adaBoundA` covers the parameter record, the state, the query table, the cache,
the predictions and small integers. -/
theorem adaBound_facts {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) :
    valSize (adaPubEnc A) ≤ adaBoundA A ∧ valSize (adaEnc st) ≤ adaBoundA A ∧
      valSize (encVals vals) ≤ adaBoundA A ∧
      valSize (encL encPZ (musZ A st.scores vals)) ≤ adaBoundA A ∧
      2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  have hB : 2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    have h1 : 16 * (A.p + adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := by nlinarith
    calc 2 ^ 14 * (A.p + adaZ A + 16) = 2 ^ 10 * (16 * (A.p + adaZ A + 16)) := by ring
      _ ≤ 2 ^ 10 * ((A.N + A.p + 16) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
      _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring
  refine ⟨valSize_adaPubEnc_le A hbs hT, valSize_adaEnc_le hok,
    valSize_encVals_le hbs hv.1 hv.2, ?_, hB⟩
  have hbits := musZ_bits hok hv
  have h1 := valSize_encL_le encPZ (musZ A st.scores vals) (2 ^ 7 * (adaZ A + 16) + 5) (by
    intro r hr
    obtain ⟨a, b⟩ := r
    rw [valSize_encPZ]
    have := hbits (a, b) hr
    simp only at this
    omega)
  rw [musZ_length] at h1
  unfold adaBoundA
  have h2 : (A.p + 1) * (2 ^ 7 * (adaZ A + 16) + 5 + 1) ≤ (A.N + A.p + 16) * (2 ^ 8 * (adaZ A + 16)) :=
    Nat.mul_le_mul (by omega) (by omega)
  nlinarith

/-! ### Sizes -/

theorem valSize_scanEnc_le {A : AdaParams} {vals : List (List ℕ)} {mz : List (ℤ × ℤ)} {j : ℕ}
    {st : AdaState} {c : List Bool} {Bd : ℕ} (hj : j ≤ A.p + 1) (hc : c.length = A.p)
    (h1 : valSize (adaPubEnc A) ≤ Bd) (h2 : valSize (adaEnc st) ≤ Bd)
    (h3 : valSize (encVals vals) ≤ Bd) (h4 : valSize (encL encPZ mz) ≤ Bd) (hp : 8 * (A.p + 16) ≤ Bd) :
    valSize (scanEnc A vals mz (j, st, c)) ≤ 5 * Bd := by
  have hcS := ap_valSize_encL_encB c
  have hjS : Nat.size j ≤ A.p + 1 := (size_le_self j).trans hj
  rw [hc] at hcS
  simp only [scanEnc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

section ScanBranches

variable {prog : List Expr} {M : ℕ} {A : AdaParams} {vals : List (List ℕ)} {mz : List (ℤ × ℤ)}
  {j : ℕ} {st : AdaState} {cache : List Bool}

/-- Field `n` of the accumulator. -/
theorem ap_acc_field {env : List Val} {k : ℕ}
    (henv : env[k]? = some (scanEnc A vals mz (j, st, cache)))
    (hM : valSize (scanEnc A vals mz (j, st, cache)) ≤ M) {n : ℕ}
    {v : Val} (hget : [encN j, adaEnc st, encL encB cache, adaPubEnc A, encVals vals,
      encL encPZ mz][n]? = some v) : EvalsVal prog M env [] (.inl (aF n k)) v :=
  evalsVal_atN' (EvalsVal.var henv) hM hget

/-- `j + 1` from the accumulator. -/
theorem ap_acc_succ {env : List Val} {k : ℕ} (henv : env[k]? = some (scanEnc A vals mz (j, st, cache)))
    (hM : valSize (scanEnc A vals mz (j, st, cache)) ≤ M) (hjM : Nat.size (j + 1) + 1 ≤ M) (h3 : 3 ≤ M) :
    EvalsVal prog M env [] (.inl (eAdd (aF 0 k) (eLit 1))) (encN (j + 1)) := by
  have hcast : (j : ℤ) + 1 = ((j + 1 : ℕ) : ℤ) := by push_cast; ring
  have := EvalsVal.add (prog := prog) (ap_acc_field (n := 0) henv hM rfl)
    (ap_lit_small (z := 1) (by decide) h3)
    (by rw [hcast, valSize_int, bitLen_natCast]; exact hjM)
  rw [hcast] at this
  exact this

/-- The next accumulator `[j + 1, st, c', pub, vals, mus]` as a continue-result of the loop body. -/
theorem ap_acc_next {env : List Val} {eC : Expr} {c' : List Bool} {k : ℕ}
    (henv : env[k]? = some (scanEnc A vals mz (j, st, cache)))
    (hM : valSize (scanEnc A vals mz (j, st, cache)) ≤ M)
    (hC : EvalsVal prog M env [] (.inl eC) (encL encB c'))
    (hjM : Nat.size (j + 1) + 1 ≤ M) (h3 : 3 ≤ M)
    (hout : valSize (Val.list [Val.int 1, scanEnc A vals mz (j + 1, st, c')]) ≤ M) :
    EvalsVal prog M env [] (.inl (ePair (eLit 1) (eList [eAdd (aF 0 k) (eLit 1), aF 1 k, eC, aF 3 k,
      aF 4 k, aF 5 k]))) (loopEnc (scanEnc A vals mz) scanOut (Sum.inl (j + 1, st, c'))) := by
  have hnext : valSize (scanEnc A vals mz (j + 1, st, c')) ≤ M :=
    le_trans (valSize_lt_of_mem (by simp)).le hout
  refine EvalsVal.pair (ap_lit_small (by decide) h3) ?_ hout
  refine evalsVal_list ?_ hnext
  exact List.Forall₂.cons (ap_acc_succ henv hM hjM h3) (List.Forall₂.cons (ap_acc_field henv hM rfl)
    (List.Forall₂.cons hC (List.Forall₂.cons (ap_acc_field henv hM rfl)
      (List.Forall₂.cons (ap_acc_field henv hM rfl) (List.Forall₂.cons (ap_acc_field henv hM rfl)
        List.Forall₂.nil)))))

/-- A stop-result `[0, [o, st', c']]` of the loop body. -/
theorem ap_acc_stop {env : List Val} {eO eS eC : Expr} {o : PassOut} {st' : AdaState} {c' : List Bool}
    (hO : EvalsVal prog M env [] (.inl eO) (encPO o)) (hS : EvalsVal prog M env [] (.inl eS) (adaEnc st'))
    (hC : EvalsVal prog M env [] (.inl eC) (encL encB c')) (h3 : 3 ≤ M)
    (hout : valSize (Val.list [Val.int 0, scanOut (o, st', c')]) ≤ M) :
    EvalsVal prog M env [] (.inl (ePair (eLit 0) (eList [eO, eS, eC])))
      (loopEnc (scanEnc A vals mz) scanOut (Sum.inr (o, st', c'))) := by
  have hs : valSize (scanOut (o, st', c')) ≤ M := le_trans (valSize_lt_of_mem (by simp)).le hout
  refine EvalsVal.pair (ap_lit_small (by decide) h3) ?_ hout
  exact evalsVal_list (List.Forall₂.cons hO (List.Forall₂.cons hS (List.Forall₂.cons hC
    List.Forall₂.nil))) hs

end ScanBranches

/-! ### The scan step -/

/-- The lookups used by the scan step. -/
structure ScanLib (prog : List Expr) : Prop where
  edge : prog[Idx.adaEdge]? = some body_adaEdge
  reset : prog[Idx.adaReset]? = some body_adaReset
  corr : ∀ e ∈ adaCorrTable, prog[e.1]? = some e.2
  step : prog[Idx.adaScanStep]? = some body_adaScanStep

theorem ap_corr_lookup {prog : List Expr} (h : ∀ e ∈ adaCorrTable, prog[e.1]? = some e.2) :
    prog[Idx.adaCorr]? = some body_adaCorr :=
  h (Idx.adaCorr, body_adaCorr) (by simp [adaCorrTable])

theorem ap_obZ_ne_zero (q : Bool) : obZ (some q) ≠ 0 := by cases q <;> decide

theorem ap_bitLen_le_edgeW_of_mem {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {i : ℕ} (hi : i < A.p + 1) :
    bitLen ((musZ A st.scores vals).getD i (0, 1)).1 ≤ edgeW A ∧
      bitLen ((musZ A st.scores vals).getD i (0, 1)).2 ≤ edgeW A := by
  have hlen := musZ_length A st.scores vals
  have hmem : (musZ A st.scores vals).getD i (0, 1) ∈ musZ A st.scores vals := by
    rw [List.getD_eq_getElem _ _ (by omega)]
    exact List.getElem_mem _
  exact musZ_bits hok hv _ hmem

/-- **The scan step implements one iteration of a scan pass.** -/
theorem scanStep_impl {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st0 : AdaState}
    (hok : AdaOK A st0) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    (s : ℕ × AdaState × List Bool) (hs : ScanInv A st0 s) :
    Implements prog M [scanEnc A vals (musZ A st0.scores vals) s] body_adaScanStep
      (loopEnc (scanEnc A vals (musZ A st0.scores vals)) scanOut)
      (scanQ A vals (adaMus A st0 vals) s) := by
  obtain ⟨j, st, cache⟩ := s
  obtain ⟨hst, hcl, hjp⟩ := hs
  simp only at hst hcl hjp
  subst hst
  obtain ⟨hPub, hSt, hVals, hMz, hB⟩ := adaBound_facts hbs hT hok hv
  have hZ16 := sixteen_le_adaZ A
  have hp16 : 8 * (A.p + 16) ≤ adaBoundA A := by omega
  have hBM : 2 ^ 32 * adaBoundA A ≤ M := hM
  have hacc5 : valSize (scanEnc A vals (musZ A st.scores vals) (j, st, cache)) ≤ 5 * adaBoundA A :=
    valSize_scanEnc_le (by omega) hcl hPub hSt hVals hMz hp16
  have haccM : valSize (scanEnc A vals (musZ A st.scores vals) (j, st, cache)) ≤ M := by omega
  have h3 : 3 ≤ M := by omega
  have hpubM : valSize (Val.list (pubFields A)) ≤ M := by
    rw [← adaPubEnc_eq]; omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hcS : valSize (encL encB cache) ≤ 1 + 3 * A.p := by
    have := ap_valSize_encL_encB cache; rw [hcl] at this; exact this
  have hsj : Nat.size j ≤ A.p := (size_le_self j).trans hjp
  have hsj1 : Nat.size (j + 1) + 1 ≤ M := by
    have := size_le_self (j + 1); omega
  set mz := musZ A st.scores vals with hmz
  set acc := scanEnc A vals mz (j, st, cache) with hacc
  -- fields of the state
  have hstL : adaEnc st = Val.list [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt,
      encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted] := rfl
  have hTS : valSize (encL encN st.T) ≤ adaBoundA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hSt
  have hthS : valSize (encL encZ st.thrInt) ≤ adaBoundA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hSt
  have hTmS : valSize (encL encN A.Tmax) ≤ adaBoundA A := by
    rw [adaPubEnc_eq] at hPub
    exact le_trans (valSize_lt_of_mem (by simp [pubFields])).le hPub
  unfold scanQ body_adaScanStep
  dsimp only
  by_cases hj : j < A.p
  · rw [if_pos hj]
    have hcond : EvalsVal prog M [acc] [] (.inl (eLt (aF 0 0) (eAtN 0 (aF 3 0)))) (Val.int 1) := by
      have h1 : EvalsVal prog M [acc] [] (.inl (aF 0 0)) (encN j) := ap_acc_field (env := [acc]) (k := 0) rfl haccM rfl
      have h2 : EvalsVal prog M [acc] [] (.inl (eAtN 0 (aF 3 0))) (encN A.p) :=
        evalsVal_atN' (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl) hpubM rfl
      have := EvalsVal.lt h1 h2 (by omega)
      rwa [if_pos (by exact_mod_cast hj)] at this
    refine ap_implements_ite_true hcond one_ne_zero ?_
    -- the cache bit
    have hget : EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (aF 2 0) (aF 0 0))))
        (encB (cache.getD j false)) := by
      have := ap_get_call hL (l := cache.map encB) (n := j) (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl)
        (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl) (by unfold S_get; simp only [encL] at hcS; omega)
      rwa [ap_getD_map_int0 cache encB (d := false) rfl] at this
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      rw [hc] at hget
      refine ap_implements_ite_true hget one_ne_zero ?_
      apply Implements.of_det
      refine ap_acc_next (k := 0) rfl haccM (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl) hsj1 h3 ?_
      have := valSize_scanEnc_le (A := A) (vals := vals) (mz := mz) (j := j + 1) (st := st)
        (c := cache) (by omega) hcl hPub hSt hVals hMz hp16
      rw [ap_valSize_list2, valSize_int]
      have : bitLen (1 : ℤ) = 1 := by decide
      omega
    · rw [if_neg hc]
      have hc' : cache.getD j false = false := by simpa using hc
      rw [hc'] at hget
      refine ap_implements_ite_false hget rfl ?_
      rw [edgeTest_toBits]
      obtain ⟨hD0, hμ0⟩ := musZ_spec hok hv hpos j (by omega)
      obtain ⟨hD1, hμ1⟩ := musZ_spec hok hv hpos (j + 1) (by omega)
      rw [← hμ0, ← hμ1]
      obtain ⟨bN0, bD0⟩ : bitLen (mz.getD j (0, 1)).1 ≤ edgeW A ∧
          bitLen (mz.getD j (0, 1)).2 ≤ edgeW A := ap_bitLen_le_edgeW_of_mem hok hv (by omega)
      obtain ⟨bN1, bD1⟩ : bitLen (mz.getD (j + 1) (0, 1)).1 ≤ edgeW A ∧
          bitLen (mz.getD (j + 1) (0, 1)).2 ≤ edgeW A :=
        ap_bitLen_le_edgeW_of_mem hok hv (by omega)
      have ht : |st.thrInt.getD j 0| ≤ (maxKs A : ℤ) := by
        by_cases hjt : j < st.thrInt.length
        · rw [List.getD_eq_getElem _ _ hjt]
          exact hok.thr_le _ (List.getElem_mem _)
        · rw [List.getD_eq_default _ _ (by omega)]
          simp
      have hEdge := adaEdge_impl (prog := prog) hS hD0 hD1 ht bN0 bD0 bN1 bD1 hPub hM
      -- the arguments of the edge test
      have hmusL : (mz.map encPZ).length = A.p + 1 := by simp [hmz, musZ_length]
      have hmusS : S_get (mz.map encPZ) (j + 1) ≤ M := by
        unfold S_get
        have : valSize (Val.list (mz.map encPZ)) ≤ adaBoundA A := hMz
        have := size_le_self (j + 1)
        omega
      have hmusS0 : S_get (mz.map encPZ) j ≤ M := by
        unfold S_get
        have : valSize (Val.list (mz.map encPZ)) ≤ adaBoundA A := hMz
        omega
      have hpz : ∀ i, i < A.p + 1 → valSize (encPZ (mz.getD i (0, 1))) ≤ M := by
        intro i hi
        have h1 : encPZ (mz.getD i (0, 1)) ∈ mz.map encPZ := by
          rw [← ap_getD_map_lt mz encPZ (0, 1) (Val.int 0) (by rw [hmz, musZ_length]; exact hi)]
          rw [List.getD_eq_getElem _ _ (by rw [hmusL]; exact hi)]
          exact List.getElem_mem _
        have := (valSize_lt_of_mem h1).le
        have : valSize (Val.list (mz.map encPZ)) ≤ adaBoundA A := hMz
        omega
      have hgetMu : ∀ (ie : Expr) (i : ℕ), i < A.p + 1 → S_get (mz.map encPZ) i ≤ M →
          EvalsVal prog M [acc] [] (.inl ie) (Val.int (i : ℤ)) →
          EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (aF 5 0) ie))) (encPZ (mz.getD i (0, 1))) := by
        intro ie i hi hSg hie
        have := ap_get_call hL (l := mz.map encPZ) (n := i) (ap_acc_field (env := [acc]) (k := 0) (n := 5) rfl haccM rfl) hie hSg
        rwa [ap_getD_map_lt mz encPZ (0, 1) (Val.int 0) (by rw [hmz, musZ_length]; exact hi)] at this
      have hj1E : EvalsVal prog M [acc] [] (.inl (eAdd (aF 0 0) (eLit 1))) (Val.int ((j + 1 : ℕ) : ℤ)) :=
        ap_acc_succ (k := 0) rfl haccM hsj1 h3
      have hm0 := hgetMu (aF 0 0) j (by omega) hmusS0 (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl)
      have hm1 := hgetMu _ (j + 1) (by omega) hmusS hj1E
      have hthrE : EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (eAtN 2 (aF 1 0)) (aF 0 0))))
          (Val.int (st.thrInt.getD j 0)) := by
        have := ap_get_call hL (l := st.thrInt.map encZ) (n := j)
          (evalsVal_atN' (n := 2) (ap_acc_field (env := [acc]) (k := 0) (n := 1) rfl haccM rfl) hstM rfl) (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl)
          (by unfold S_get; simp only [encL] at hthS; omega)
        rwa [ap_getD_map_int0 st.thrInt encZ (d := 0) rfl] at this
      have hargs : EvalsVal prog M [acc] [] (.inl (eList [aF 3 0,
            eCall Idx.get (ePair (eAtN 2 (aF 1 0)) (aF 0 0)),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1)))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1))))]))
          (Val.list [adaPubEnc A, Val.int (st.thrInt.getD j 0), Val.int (mz.getD j (0, 1)).1,
            Val.int (mz.getD j (0, 1)).2, Val.int (mz.getD (j + 1) (0, 1)).1,
            Val.int (mz.getD (j + 1) (0, 1)).2]) := by
        have hp0 := hpz j (by omega)
        have hp1 := hpz (j + 1) (by omega)
        refine evalsVal_list (List.Forall₂.cons (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl)
          (List.Forall₂.cons hthrE
          (List.Forall₂.cons (evalsVal_atN' hm0 hp0 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm0 hp0 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm1 hp1 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm1 hp1 rfl) List.Forall₂.nil)))))) ?_
        have hbt := ap_bitLen_le_edgeW_of_abs ht
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
        unfold edgeW at hbt bN0 bD0 bN1 bD1
        omega
      refine implements_letE_of (implements_call_det hlib.edge hargs hEdge) (fun _ => True)
        (fun _ _ _ => trivial) ?_
      intro r _
      cases r with
      | none =>
        dsimp only
        have hcz : EvalsVal prog M [encOB none, acc] [] (.inl (eEq (eV 0) (eLit 0))) (Val.int 1) := by
          have := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB none) (rest := [acc])) (ap_lit_small (z := 0) (by decide) h3)
            (by omega)
          simpa [encOB, obZ] using this
        refine ap_implements_ite_true hcz one_ne_zero ?_
        apply Implements.of_det
        have hsetE : EvalsVal prog M [encOB none, acc] [] (.inl (eCall Idx.set (eList [aF 2 1, aF 0 1,
            eLit 1]))) (encL encB (cache.set j true)) := by
          have := ap_set_call hL (l := cache.map encB) (n := j) (x := Val.int 1)
            (ap_acc_field (env := [encOB none, acc]) (k := 1) (n := 2) rfl haccM rfl) (ap_acc_field (env := [encOB none, acc]) (k := 1) (n := 0) rfl haccM rfl)
            (ap_lit_small (z := 1) (by decide) h3) (by
              unfold S_set
              simp only [encL] at hcS
              simp only [valSize_int]
              have : bitLen (1 : ℤ) = 1 := by decide
              omega)
          rwa [show (Val.int 1 : Val) = encB true from rfl, ap_encL_encB_set] at this
        refine ap_acc_next (k := 1) rfl haccM hsetE hsj1 h3 ?_
        have := valSize_scanEnc_le (A := A) (vals := vals) (mz := mz) (j := j + 1) (st := st)
          (c := cache.set j true) (by omega) (by simp [hcl]) hPub hSt hVals hMz hp16
        rw [ap_valSize_list2, valSize_int]
        have : bitLen (1 : ℤ) = 1 := by decide
        omega
      | some q =>
        dsimp only
        have hcz : EvalsVal prog M [encOB (some q), acc] [] (.inl (eEq (eV 0) (eLit 0))) (Val.int 0) := by
          have := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB (some q)) (rest := [acc])) (ap_lit_small (z := 0) (by decide) h3)
            (by omega)
          rwa [if_neg (ap_obZ_ne_zero q)] at this
        refine ap_implements_ite_false hcz rfl ?_
        -- the cap test
        have hTE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eCall Idx.get
            (ePair (eAtN 1 (aF 1 1)) (aF 0 1)))) (encN (st.T.getD j 0)) := by
          have := ap_get_call hL (l := st.T.map encN) (n := j)
            (evalsVal_atN' (n := 1) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl) hstM rfl) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
            (by unfold S_get; simp only [encL] at hTS; omega)
          rwa [ap_getD_map_int0 st.T encN (d := 0) rfl] at this
        have hTmE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eCall Idx.get
            (ePair (eAtN 2 (aF 3 1)) (aF 0 1)))) (encN (A.Tmax.getD j 0)) := by
          have := ap_get_call hL (l := A.Tmax.map encN) (n := j)
            (evalsVal_atN' (n := 2) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 3) rfl haccM rfl) hpubM rfl) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
            (by unfold S_get; simp only [encL] at hTmS; omega)
          rwa [ap_getD_map_int0 A.Tmax encN (d := 0) rfl] at this
        have hlt := EvalsVal.lt hTE hTmE (by omega)
        by_cases hcap : A.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hcap]
          have hlt0 : ¬ (((st.T.getD j 0 : ℕ) : ℤ) < ((A.Tmax.getD j 0 : ℕ) : ℤ)) := by
            exact_mod_cast not_lt.mpr hcap
          rw [if_neg hlt0] at hlt
          refine ap_implements_ite_false hlt rfl ?_
          apply Implements.of_det
          refine ap_acc_stop (ap_lit_small (z := 2) (by decide) h3) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl)
            (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 2) rfl haccM rfl) h3 ?_
          simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : bitLen (2 : ℤ) = 2 := by decide
          have : bitLen (0 : ℤ) = 0 := by decide
          omega
        · rw [if_neg hcap]
          have hTj : st.T.getD j 0 < A.Tmax.getD j 0 := by omega
          have hlt1 : (((st.T.getD j 0 : ℕ) : ℤ) < ((A.Tmax.getD j 0 : ℕ) : ℤ)) := by exact_mod_cast hTj
          rw [if_pos hlt1] at hlt
          refine ap_implements_ite_true hlt one_ne_zero ?_
          -- the correction
          have hqE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eIte (eEq (eV 0) (eLit 1)) (eLit 1)
              (eLit (-1)))) (Val.int (avSign q)) := by
            have he := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB (some q)) (rest := [acc])) (ap_lit_small (z := 1) (by decide) h3)
              (by omega)
            cases q
            · rw [show obZ (some false) = 2 from rfl, if_neg (by decide)] at he
              exact EvalsVal.ite_false he rfl (ap_lit_small (by decide) h3)
            · rw [show obZ (some true) = 1 from rfl, if_pos rfl] at he
              exact EvalsVal.ite_true he one_ne_zero (ap_lit_small (by decide) h3)
          have hcargs : EvalsVal prog M [encOB (some q), acc] [] (.inl (eList [aF 0 1,
              eIte (eEq (eV 0) (eLit 1)) (eLit 1) (eLit (-1)), aF 1 1, aF 3 1, aF 4 1]))
              (Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]) := by
            refine evalsVal_list (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
              (List.Forall₂.cons hqE (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl)
              (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 3) rfl haccM rfl)
              (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 4) rfl haccM rfl) List.Forall₂.nil))))) ?_
            have : bitLen (avSign q) ≤ 1 := by cases q <;> decide
            simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN]
            omega
          have hcorr := adaCorr_impl (prog := prog) hlib.corr hS hL hbs hT hok hv hj hTj q hM
          have hsupp : ∀ bits st', ((applyCorrection A st vals j q).toBits (adaDraw A)).run bits =
              some (st', []) → AdaOK A st' := fun bits st' h =>
            (Always.of_run (DAlw.toBits (adaDraw_adaKB A) (applyCorrection_ok hok vals q hj hTj)) h).1
          refine implements_letE_of (implements_call_det (ap_corr_lookup hlib.corr) hcargs hcorr) (AdaOK A)
            hsupp ?_
          intro st' hst'
          apply Implements.of_det
          have hst'M := valSize_adaEnc_le hst'
          have hrE : EvalsVal prog M [adaEnc st', encOB (some q), acc] [] (.inl (eCall Idx.adaReset
              (eList [aF 0 2, aF 2 2, eAtN 0 (aF 3 2)]))) (encL encB (resetCache A j cache)) := by
            refine evalsVal_call_det hlib.reset (evalsVal_list (List.Forall₂.cons
              (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 0) rfl haccM rfl) (List.Forall₂.cons (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 2) rfl haccM rfl)
              (List.Forall₂.cons (evalsVal_atN' (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 3) rfl haccM rfl) hpubM rfl)
              List.Forall₂.nil))) ?_) (adaReset_val hL A (by omega) hcl (by omega))
            rw [ap_valSize_list3, valSize_encN, valSize_encN]
            have := size_le_self A.p
            omega
          have hrl : (resetCache A j cache).length = A.p := by
            rw [resetCache_eq]; split_ifs <;> simp [hcl]
          refine ap_acc_stop (ap_lit_small (z := 1) (by decide) h3) EvalsVal.var0 hrE h3 ?_
          have := ap_valSize_encL_encB (resetCache A j cache)
          rw [hrl] at this
          simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : bitLen (1 : ℤ) = 1 := by decide
          have : bitLen (0 : ℤ) = 0 := by decide
          omega
  · rw [if_neg hj]
    have hcond : EvalsVal prog M [acc] [] (.inl (eLt (aF 0 0) (eAtN 0 (aF 3 0)))) (Val.int 0) := by
      have h1 : EvalsVal prog M [acc] [] (.inl (aF 0 0)) (encN j) := ap_acc_field (env := [acc]) (k := 0) rfl haccM rfl
      have h2 : EvalsVal prog M [acc] [] (.inl (eAtN 0 (aF 3 0))) (encN A.p) :=
        evalsVal_atN' (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl) hpubM rfl
      have := EvalsVal.lt h1 h2 (by omega)
      rwa [if_neg (by exact_mod_cast hj)] at this
    refine ap_implements_ite_false hcond rfl ?_
    apply Implements.of_det
    refine ap_acc_stop (ap_lit_small (z := 0) (by decide) h3) (ap_acc_field (env := [acc]) (k := 0) (n := 1) rfl haccM rfl)
      (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl) h3 ?_
    simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : bitLen (0 : ℤ) = 0 := by decide
    omega

/-! ### The scan loop -/

/-- `scanQ` continues only to states satisfying the invariant, with a smaller measure. -/
theorem scanQ_always (A : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) (st0 : AdaState)
    (s : ℕ × AdaState × List Bool) (hs : ScanInv A st0 s) :
    Always (scanQ A vals mus s)
      (fun r => ∀ s', r = Sum.inl s' → ScanInv A st0 s' ∧ A.p - s'.1 < A.p - s.1) := by
  obtain ⟨j, st, cache⟩ := s
  obtain ⟨hst, hcl, hjp⟩ := hs
  simp only at hst hcl hjp
  unfold scanQ
  dsimp only
  by_cases hj : j < A.p
  · rw [if_pos hj]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact fun s' h => by
        cases h
        exact ⟨⟨hst, hcl, by simp only; omega⟩, by simp only; omega⟩
    · rw [if_neg hc]
      refine Always.bind_all (fun r => ?_) _
      cases r with
      | none =>
        exact fun s' h => by
          cases h
          exact ⟨⟨hst, by simp [hcl], by simp only; omega⟩, by simp only; omega⟩
      | some q =>
        dsimp only
        split_ifs
        · exact fun s' h => by cases h
        · exact Always.bind_all (fun _ => fun s' h => by cases h) _
  · rw [if_neg hj]
    exact fun s' h => by cases h

/-- **The scan loop implements a whole scan pass** (from edge `0`, with the predictions of the
pass-start state `st`). -/
theorem scanLoop_impl {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    {cache : List Bool} (hc : cache.length = A.p) {env : List Val} {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (scanEnc A vals (musZ A st.scores vals) (0, st, cache))) :
    Implements prog M env (eLoop Idx.adaScanStep a) scanOut
      (scanRef A vals (adaMus A st vals) (0, st, cache)) :=
  implements_loop hlib.step (scanEnc A vals (musZ A st.scores vals)) scanOut (ScanInv A st)
    (fun s => A.p - s.1) (scanRef A vals (adaMus A st vals)) (scanQ A vals (adaMus A st vals))
    (fun s hs => scanStep_impl hlib hS hL hbs hT hpos hok hv hM s hs)
    (fun s _ => scanRef_unfold A vals _ s)
    (fun s hs _ s' h => Always.of_run (scanQ_always A vals _ st s hs) h s' rfl)
    ⟨rfl, hc, Nat.zero_le _⟩ ha

/-- Conjunction of every-leaf properties. -/
theorem DAlw.and {B : ℤ → Prop} {α : Type} {Q R : α → Prop} :
    ∀ {prog : NoiseProg α}, DAlw B prog Q → DAlw B prog R → DAlw B prog (fun a => Q a ∧ R a)
  | DrawProg.ret _, h₁, h₂ => ⟨h₁, h₂⟩
  | DrawProg.draw _ _, h₁, h₂ => fun z hz => DAlw.and (h₁ z hz) (h₂ z hz)

theorem resetCache_length (A : AdaParams) (j : ℕ) (cache : List Bool) :
    (resetCache A j cache).length = cache.length := by
  rw [resetCache_eq]
  split_ifs <;> simp

/-- A scan pass keeps the length of the cache. -/
theorem scanPass_cacheLen {A : AdaParams} (vals : List (List ℕ)) (mus : List ℚ) (B : ℤ → Prop) :
    ∀ (es : List ℕ) (st : AdaState) (cache : List Bool),
      DAlw B (scanPass A vals mus es st cache) (fun r => r.2.2.length = cache.length)
  | [], _, _ => rfl
  | j :: es, st, cache => by
    rw [scanPass]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact scanPass_cacheLen vals mus B es st cache
    · rw [if_neg hc]
      refine DAlw.bind_all (fun r => ?_) _
      cases r with
      | none =>
        exact DAlw.mono (fun r hr => by rw [hr, List.length_set])
          (scanPass_cacheLen vals mus B es st (cache.set j true))
      | some q =>
        dsimp only
        by_cases hcap : A.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hcap]
          exact rfl
        · rw [if_neg hcap]
          refine DAlw.bind_all (fun _ => ?_) _
          exact resetCache_length A j cache

/-- **The outcome of a scan pass** satisfies the invariant and keeps the cache length. -/
theorem scanRef_always {A : AdaParams} (vals : List (List ℕ)) (mus : List ℚ) {st : AdaState}
    (hok : AdaOK A st) {cache : List Bool} (hc : cache.length = A.p) :
    Always (scanRef A vals mus (0, st, cache)) (fun r => AdaOK A r.2.1 ∧ r.2.2.length = A.p) := by
  unfold scanRef
  refine DAlw.toBits (adaDraw_adaKB A) (DAlw.mono (fun r hr => ⟨hr.1.1, hr.2.trans hc⟩)
    (DAlw.and (scanPass_ok vals mus _ (fun j hj => ?_) st cache hok)
      (scanPass_cacheLen vals mus _ _ st cache)))
  simp only [Nat.sub_zero, List.mem_range'_1] at hj
  omega

end F2e2e.C.Impl
