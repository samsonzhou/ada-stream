import F2e2e.C.Impl.Tree4Tail

/-!
# W6, Tree4: the DSL implementation of `rejectTail` (helper file)

Owner of this proof: W1/C-PARAMS (e26ae4ae), as a helper of Tree4 (1beb339b), who owns the
statement below (fixed; do not change it) and the rest of `F2e2e/C/Impl/Tree4*.lean`.

**Statement** `rejectTail_impl`: `body_rejectTail` (`F2e2e/C/Impl/Tree4Defs.lean`, Idx 338) implements
C-ALG's `rejectTail` on `[p, d, L_d, cInt, N₁, st]`, output `encSF R` (`[encState, encQ]`).

**Proof plan** (all helpers exist and compile; model proof: `rejectRelease_impl` in
`F2e2e/C/Impl/Tree4Tail.lean`, same style):
* `rw [rejectTail_eq]` (Tree4Defs): the BitProg becomes `if (okL && okA) then rejectReleaseRef … s₁
  else pure ({ s with banks := banks' }.fail, 0)` with `banks' = mapFrom (mapRows (scaleXY P cInt))
  (d+1) s.banks`, `learners' = mapFrom (rescale P cInt) (d+1) s.learners`,
  `leaf' = roundMant eHleaf (gridVal eHstep cInt ^ 2 * gridVal eHleaf s.leaf)`.
* body bindings (envs in the docstring of `body_rejectTail`): `p, d, c, st` by `ev_get … hXz rfl`;
  `d + 1` (`EvalsVal.add`, rewrite `(d:ℤ) + 1 = ((d+1 : ℕ) : ℤ)` to get `encN (d+1)`);
  `banks'` by `evalsVal_call_det hT.mfXY _ (mfXY_val …)` with `mapIdx_M_banks_le`;
  `learners'` by `mfResc_val` (cInt range `hc0 hc1`) with `mapIdx_M_learners_le`;
  `eHleaf, eHstep` by `ev_paramCall hC.w1.peHleaf/peHstep`;
  `z` by `ev_normQ_grid` (numerator `cInt * cInt * leaf` via `ev_mul`, exponent
  `eHstep + eHstep + eHleaf` via `ev_add` + cast to `encN`), then rewrite
  `gridVal (es+es+eh) (c*c*l) = gridVal es c ^ 2 * gridVal eh l`;
  `leaf'` by `ev_roundMantQCall` (`QOK` of `z` from `qok_gridVal`, `|c c l| < 2^(2es+eAmax+eh+4)`);
  `okL` by `allFrom_val` (input `encAF P (learners', d+1)`; learners' are `LearnerOK P 16`:
  `Aux.forall_mem_mapFrom_of_drop` + `LearnerOK.rescale`);
  `okA` by `ev_inRangeACall` on `ev_normQ_grid` (`QOK (gridVal eh leaf')`, bound on `leaf'`).
* branch: `impl_ite_encB` twice; failure: `Implements.of_det (ev_eFailOut (ev_eWithBanks …))`
  (`StateOK.withBanks`); success: `implements_call_det hT.rejectRelease (ev_list …)
  (rejectRelease_impl …)` with `StateOK 4` of `s₁` as in C-SPACE's `rejectTail_ok` proof
  (`F2e2e/C/SpaceSteps.lean` L709–756: `LearnerOK.of_inRange`, `Aux.inRangeA_gridVal`).
* sizes: units of `SSB R P` (`Mv R P = 2^32 SSB`): `vs_state`, `vs_bank`, `vs_encQ`, `vs_int`,
  `vs_encN`, `vs_learner`, `vs_pair`, `mapIdx_M_*_le`. Never let `omega` see two differently
  elaborated state terms (nested `{ … with … }`): build size facts by `(vs_state …).trans (by omega)`.
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-- The dyadic product `c² l / 2^{2 e_s + e_h}` as a product of grid values. -/
theorem rt_gridVal_sq_mul (es eh : ℕ) (c l : ℤ) :
    gridVal (es + es + eh) (c * c * l) = gridVal es c ^ 2 * gridVal eh l := by
  unfold gridVal
  rw [pow_add, pow_add]
  push_cast
  field_simp

/-- The rounding to a grid of a bounded rational (a copy of W6's `abs_roundMant_le`, which lives
in a module not imported here). -/
theorem rt_abs_roundMant_le {q k : ℕ} {z : ℚ} (hz : |z| ≤ 2 ^ k) :
    |roundMant q z| ≤ 2 ^ (k + q + 1) := by
  unfold roundMant
  have h2q : (0 : ℚ) < 2 ^ q := by positivity
  have hz' := abs_le.mp hz
  have hkq : (2 : ℚ) ^ (k + q) = 2 ^ k * 2 ^ q := pow_add 2 k q
  have hup : z * 2 ^ q + 1 / 2 ≤ (2 : ℚ) ^ (k + q) + 1 / 2 := by rw [hkq]; nlinarith
  have hlo : -(2 : ℚ) ^ (k + q) - 1 / 2 ≤ z * 2 ^ q + 1 / 2 := by rw [hkq]; nlinarith
  have h1 := Int.floor_le (z * 2 ^ q + 1 / 2)
  have h2 := Int.lt_floor_add_one (z * 2 ^ q + 1 / 2)
  have hA : ((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) < ((2 ^ (k + q) + 1 : ℤ) : ℚ) := by push_cast; linarith
  have hB : ((-(2 ^ (k + q)) - 1 - 1 : ℤ) : ℚ) < ((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) := by
    push_cast; linarith
  have hA' : ⌊z * 2 ^ q + 1 / 2⌋ < 2 ^ (k + q) + 1 := by exact_mod_cast hA
  have hB' : -(2 ^ (k + q)) - 1 - 1 < ⌊z * 2 ^ q + 1 / 2⌋ := by exact_mod_cast hB
  have hpos : (1 : ℤ) ≤ 2 ^ (k + q) := one_le_pow₀ (by norm_num)
  have hpow : (2 : ℤ) ^ (k + q + 1) = 2 * 2 ^ (k + q) := by ring
  rw [abs_le, hpow]
  constructor <;> omega

/-- **`rejectTail`** implements C-ALG's `rejectTail` (partIII.tex L506–510) for the learner `L_d`
of depth `d` (`J_used < J_*`), a multiplier `c ∈ [1/2, 3/2]` (C-ALG's `stepCoeffMant_mem`) and a
released `N₁` with `FOK`. -/
theorem rejectTail_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) {Ld : Learner} (hLd : LearnerOK P 4 Ld) (hj : Ld.jUsed < P.Jstar) {cInt : ℤ}
    (hc0 : 2 ^ (P.eHstep - 1) ≤ cInt) (hc1 : cInt ≤ 3 * 2 ^ (P.eHstep - 1)) {N1 : ℚ}
    (hN1 : FOK P N1) :
    Implements prog M [Val.list [encStreamParams P, encN d, encLearner Ld, encZ cInt, encQ N1,
      encState R.enc s]] body_rejectTail (encSF R) (rejectTail P d Ld cInt N1 s) := by
  have hA := hR.invariant P hP
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hpz := vs_params R P
  have hRB := regBits_le_SSB R P
  have hHR := H_le_R P
  have hsum : 2 * P.eHstep + P.eAmax + P.eHleaf + 6 ≤ regBits P := by
    have h1 := F2e2e.C.Space.eHstep_le P
    have h2 := F2e2e.C.Space.eHleaf_le P
    have h3 := F2e2e.C.Space.eAmax_le P
    have h4 := F2e2e.C.Space.hundred_mul_calL_le_sq P
    have h5 := F2e2e.C.Space.hundred_mul_sq_le_cube P
    have h6 := F2e2e.C.Space.hundred_le_calL P
    rw [regBits_eq]
    omega
  have hdz := vs_encN R P (show d ≤ regBits P by omega)
  have hd1z := vs_encN R P (show d + 1 ≤ regBits P by omega)
  have hLz := vs_learner R P (hLd.mono (by norm_num) : LearnerOK P 16 Ld)
  have hNz := vs_encQ R P hN1.qok
  have hsz := vs_state hR hP hs ht
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hesR := eHstep_le_R P
  have hehR := eHleaf_le_R P
  have heAR := eAmax_le_R P
  have hesz := vs_encN R P hesR
  have hehz := vs_encN R P hehR
  -- the multiplier `c ∈ [1/2, 3/2]`
  have hq1 : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
  have hu : (2 : ℤ) ^ P.eHstep = 2 * 2 ^ (P.eHstep - 1) := by
    rw [← pow_succ']; congr 1; omega
  have hu0 : (0 : ℤ) < 2 ^ (P.eHstep - 1) := by positivity
  have hcpos : 0 ≤ cInt := by linarith
  have hcle : cInt ≤ 2 * 2 ^ P.eHstep := by rw [hu]; linarith
  have hcabs : |cInt| ≤ 2 ^ (P.eHstep + 1) := by
    rw [abs_of_nonneg hcpos, pow_succ]; linarith
  have hclt : |cInt| < 2 ^ (P.eHstep + 2) := by
    have : (2 : ℤ) ^ (P.eHstep + 1) < 2 ^ (P.eHstep + 2) :=
      pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith
  have hcz := vs_int R P hclt (by omega)
  have hXz : valSize (Val.list [encStreamParams P, encN d, encLearner Ld, encZ cInt, encQ N1,
      encState R.enc s]) ≤ M := by
    simp only [encZ, valSize_list, listSize_cons, listSize_nil] at hcz ⊢; omega
  -- the numerator `c² · leaf` of the rescaled accumulator
  have hleaf0 := hs.leaf_nonneg
  have hleaf1 : s.leaf ≤ 4 * ((P.Amax : ℤ) * 2 ^ P.eHleaf) := by
    have h := hs.leaf_le
    push_cast at h
    exact h
  have hcc0 : 0 ≤ cInt * cInt := mul_nonneg hcpos hcpos
  have hm0 : 0 ≤ cInt * cInt * s.leaf := mul_nonneg hcc0 hleaf0
  have hpowE : (2 : ℤ) ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 4) =
      (2 * 2 ^ P.eHstep) * (2 * 2 ^ P.eHstep) * (4 * ((P.Amax : ℤ) * 2 ^ P.eHleaf)) := by
    rw [Amax_eq_int, show 2 * P.eHstep + P.eAmax + P.eHleaf + 4 =
      P.eHstep + P.eHstep + P.eAmax + P.eHleaf + 4 by ring, pow_add, pow_add, pow_add, pow_add]
    ring
  have hm1 : cInt * cInt * s.leaf ≤ 2 ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 4) := by
    rw [hpowE]
    have h1 : cInt * cInt ≤ (2 * 2 ^ P.eHstep) * (2 * 2 ^ P.eHstep) :=
      mul_le_mul hcle hcle hcpos (by positivity)
    exact mul_le_mul h1 hleaf1 hleaf0 (by positivity)
  have hmlt : |cInt * cInt * s.leaf| < 2 ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 5) := by
    rw [abs_of_nonneg hm0]
    have : (2 : ℤ) ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 4) <
        2 ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 5) := pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith
  have hcclt : |cInt * cInt| < 2 ^ (2 * P.eHstep + 4) := by
    rw [abs_of_nonneg hcc0]
    have h1 : cInt * cInt ≤ (2 * 2 ^ P.eHstep) * (2 * 2 ^ P.eHstep) :=
      mul_le_mul hcle hcle hcpos (by positivity)
    have e : (2 : ℤ) ^ (2 * P.eHstep + 4) = 4 * ((2 * 2 ^ P.eHstep) * (2 * 2 ^ P.eHstep)) := by
      rw [show 2 * P.eHstep + 4 = P.eHstep + P.eHstep + 4 by ring, pow_add, pow_add]; ring
    have h2 : (0 : ℤ) < (2 * 2 ^ P.eHstep) * (2 * 2 ^ P.eHstep) := by positivity
    rw [e]; linarith
  have hccz := vs_int R P hcclt (by omega)
  have hmz := vs_int R P hmlt (by omega)
  have hbm := bitLen_le_of_abs_lt hmlt
  -- the rescaled accumulator `leaf' = round_{h_leaf}(c² · leaf)`
  have hzQ0 : QOK P (gridVal (P.eHstep + P.eHstep + P.eHleaf) (cInt * cInt * s.leaf)) :=
    qok_gridVal hmlt (by omega) (by omega)
  have hzQ : QOK P (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf) := by
    rw [← rt_gridVal_sq_mul]; exact hzQ0
  have hzz := vs_encQ R P hzQ
  have hzle : gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf ≤ 2 ^ (P.eAmax + 4) := by
    rw [← rt_gridVal_sq_mul]
    refine gridVal_le_of_le ?_
    have h := (show ((cInt * cInt * s.leaf : ℤ) : ℚ) ≤
        ((2 ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 4) : ℤ) : ℚ) by exact_mod_cast hm1)
    have e : (((2 ^ (2 * P.eHstep + P.eAmax + P.eHleaf + 4) : ℤ) : ℚ)) =
        (2 : ℚ) ^ (P.eAmax + 4) * 2 ^ (P.eHstep + P.eHstep + P.eHleaf) := by
      push_cast
      rw [← pow_add]; congr 1; ring
    rw [e] at h
    exact h
  have hz0 : 0 ≤ gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf := by
    rw [← rt_gridVal_sq_mul]; exact gridVal_nonneg hm0
  have hzabs : |gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf| ≤ 2 ^ (P.eAmax + 4) := by
    rw [abs_of_nonneg hz0]; exact hzle
  have hlfle := rt_abs_roundMant_le (q := P.eHleaf) hzabs
  have hlflt : |roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf)| <
      2 ^ (P.eAmax + P.eHleaf + 6) := by
    have : (2 : ℤ) ^ (P.eAmax + 4 + P.eHleaf + 1) < 2 ^ (P.eAmax + P.eHleaf + 6) :=
      pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith
  have hlfz := vs_int R P hlflt (by omega)
  have hblf := bitLen_le_of_abs_lt hlflt
  have hlfQ : QOK P (gridVal P.eHleaf
      (roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf))) :=
    qok_gridVal hlflt (by omega) (by omega)
  have hlfQz := vs_encQ R P hlfQ
  -- the rescaled banks and learners
  have hbsOK : ∀ B ∈ mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks,
      BankOK P (R.ok P) B :=
    Aux.forall_mem_mapFrom _ (fun B hB => hB.scaleXY cInt) _ _ hs.banks_ok
  have hbslen : (mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks).length ≤ P.H := by
    rw [length_mapFrom]; exact hs.banks_length_le
  have hls16 : ∀ L ∈ mapFrom (Learner.rescale P cInt) (d + 1) s.learners, LearnerOK P 16 L := by
    refine Aux.forall_mem_mapFrom_of_drop _ _ _
      (fun L hL => (hs.learners_ok L hL).mono (by norm_num)) ?_
    intro L hL
    rw [List.mem_map] at hL
    obtain ⟨L0, hL0, rfl⟩ := hL
    exact (hs.learners_ok L0 (List.mem_of_mem_drop hL0)).rescale hc0 hc1
  have hlslen : (mapFrom (Learner.rescale P cInt) (d + 1) s.learners).length ≤ P.H := by
    rw [length_mapFrom]; exact hs.learners_length_le
  have hsB := hs.withBanks hbslen hbsOK
  have hbsz := vs_state hR hP hsB ht
  have hbsL : valSize (encL (encBank R.enc) (mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1)
      s.banks)) ≤ SSB R P := (vs_banks_le R.enc _).trans hbsz
  have hlsL : valSize (encL encLearner (mapFrom (Learner.rescale P cInt) (d + 1) s.learners)) ≤
      SSB R P + 1 := by
    have h1 := valSize_encL_le encLearner (mapFrom (Learner.rescale P cInt) (d + 1) s.learners)
      (2 ^ 6 * P.calL ^ 3) (fun L hL => valSize_encLearner_le16 (hls16 L hL))
    have h2 : (mapFrom (Learner.rescale P cInt) (d + 1) s.learners).length *
        (2 ^ 6 * P.calL ^ 3 + 1) ≤ SSB R P :=
      (Nat.mul_le_mul_right _ hlslen).trans (SSB_HL R P)
    omega
  have hsbz := vs_banks_le R.enc s
  have hslz := vs_learners_le R.enc s
  have hext : valSize (Val.list [encStreamParams P, encN (d + 1), encZ cInt]) ≤
      2 ^ 6 * SSB R P := by
    simp only [encZ, valSize_list, listSize_cons, listSize_nil] at hcz ⊢; omega
  have hMIb := mapIdx_M_banks_le hR hP hs.banks_ok hs.banks_length_le _ hext
  have hMIl := mapIdx_M_learners_le (R := R)
    (fun L hL => (hs.learners_ok L hL).mono (by norm_num)) hs.learners_length_le _ hext
  have hpow : S_pow2 (P.eHstep + P.eHstep + P.eHleaf) ≤ M := by
    unfold S_pow2; have := size_le_self (P.eHstep + P.eHstep + P.eHleaf); omega
  have hpowh : S_pow2 P.eHleaf ≤ M := by
    unfold S_pow2; have := size_le_self P.eHleaf; omega
  -- the reference
  rw [rejectTail_eq]
  unfold body_rejectTail
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 3 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 5 (EvalsVal.var rfl) hXz rfl) ?_
  -- d + 1
  refine impl_letE_det (va := encN (d + 1)) ?_ ?_
  · rw [show encN (d + 1) = Val.int ((d : ℤ) + 1) from congrArg Val.int (Nat.cast_succ d)]
    refine ev_add (EvalsVal.var rfl) (EvalsVal.lit (by simp; omega)) ?_
    rw [show ((d : ℤ) + 1) = ((d + 1 : ℕ) : ℤ) by push_cast; ring]
    exact hd1z.trans (by omega)
  -- banks'
  refine impl_letE_det (evalsVal_call_det hT.mfXY
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hsM rfl) (.cons (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))) (by omega)) .nil))
      ((vs_pair (hsbz.trans hsz) hext).trans (by omega)))
    (mfXY_val hR hC hT hP hM s.banks hs.banks_ok (d + 1) cInt hcabs (by omega))) ?_
  -- learners'
  refine impl_letE_det (evalsVal_call_det hT.mfResc
    (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hsM rfl) (.cons (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))) (by omega)) .nil))
      ((vs_pair (hslz.trans hsz) hext).trans (by omega)))
    (mfResc_val hC hT hP hM s.learners hs.learners_ok (d + 1) hc0 hc1 (by omega))) ?_
  -- eHleaf, eHstep
  refine impl_letE_det (ev_paramCall hC.w1.peHleaf hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peHstep hP hM (EvalsVal.var rfl)) ?_
  -- z = c² leaf / 2^{2 e_s + e_h}
  refine impl_letE_det (va := encQ (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf)) ?_ ?_
  · rw [← rt_gridVal_sq_mul]
    refine ev_normQ_grid hC (ev_mul (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (by omega))
      (ev_get 6 (EvalsVal.var rfl) hsM rfl) (by omega))
      (ev_pow2 hT (n := P.eHstep + P.eHstep + P.eHleaf) ?_ hpow) (by omega)
    rw [show encN (P.eHstep + P.eHstep + P.eHleaf) =
      Val.int ((P.eHstep : ℤ) + (P.eHstep : ℤ) + (P.eHleaf : ℤ)) from
        congrArg Val.int (by rw [Nat.cast_add, Nat.cast_add])]
    refine ev_add (ev_add (EvalsVal.var rfl) (EvalsVal.var rfl) ?_) (EvalsVal.var rfl) ?_
    · rw [show ((P.eHstep : ℤ) + (P.eHstep : ℤ)) = ((P.eHstep + P.eHstep : ℕ) : ℤ) by push_cast; ring]
      have h1 := valSize_encN (P.eHstep + P.eHstep)
      have h2 := size_le_self (P.eHstep + P.eHstep)
      simp only [encN] at h1
      omega
    · rw [show ((P.eHstep : ℤ) + (P.eHstep : ℤ) + (P.eHleaf : ℤ)) =
        ((P.eHstep + P.eHstep + P.eHleaf : ℕ) : ℤ) by push_cast; ring]
      have h1 := valSize_encN (P.eHstep + P.eHstep + P.eHleaf)
      have h2 := size_le_self (P.eHstep + P.eHstep + P.eHleaf)
      simp only [encN] at h1
      omega
  -- leaf'
  refine impl_letE_det (ev_roundMantQCall hC hP hM hehR hzQ
    (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
  -- okL
  refine impl_letE_det (evalsVal_call_det hT.allFrom
    (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (allFrom_val hC hT hP hM _ hls16 (d + 1)
      (by simp only [encAF, valSize_list, listSize_cons, listSize_nil]; omega))) ?_
  -- okA
  refine impl_letE_det (ev_inRangeACall hC hP hM hlfQ
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_normQ_grid hC (EvalsVal.var rfl)
      (ev_pow2 hT (EvalsVal.var rfl) hpowh) (by omega)) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
  -- the two range checks
  refine impl_ite_encB (EvalsVal.var rfl) ?_
  cases hb1 : ((mapFrom (Learner.rescale P cInt) (d + 1) s.learners).drop (d + 1)).all
      (Learner.inRange P)
  · -- a rescaled learner is out of range: failure (with the rescaled banks)
    rw [if_neg (show ¬ (false = true) by decide), Bool.false_and,
      if_neg (show ¬ (false = true) by decide)]
    exact Implements.of_det (ev_eFailOut (ev_eWithBanks (EvalsVal.var rfl) (EvalsVal.var rfl) hsM
      (hbsz.trans (by omega))) ((Nat.add_le_add_right hbsz 10).trans (by omega)))
  · rw [if_pos (rfl : true = true), Bool.true_and]
    refine impl_ite_encB (EvalsVal.var rfl) ?_
    cases hb2 : inRangeA P (gridVal P.eHleaf
        (roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf)))
    · -- the rescaled accumulator is out of range: failure (with the rescaled banks)
      rw [if_neg (show ¬ (false = true) by decide), if_neg (show ¬ (false = true) by decide)]
      exact Implements.of_det (ev_eFailOut (ev_eWithBanks (EvalsVal.var rfl) (EvalsVal.var rfl)
        hsM (hbsz.trans (by omega))) ((Nat.add_le_add_right hbsz 10).trans (by omega)))
    · -- both checks passed: the DIFF release on the rescaled state `s₁`
      rw [if_pos (rfl : true = true), if_pos (rfl : true = true)]
      obtain ⟨hlf0, hlf1⟩ := Aux.inRangeA_gridVal hb2
      have hl4 : ∀ L ∈ mapFrom (Learner.rescale P cInt) (d + 1) s.learners, LearnerOK P 4 L := by
        refine Aux.forall_mem_mapFrom_of_drop _ _ _ hs.learners_ok ?_
        intro L hL
        have hr : L.inRange P = true := by
          rw [← Aux.drop_mapFrom] at hL
          exact List.all_eq_true.mp hb1 L hL
        rw [List.mem_map] at hL
        obtain ⟨L0, hL0, rfl⟩ := hL
        exact (LearnerOK.of_inRange (hs.learners_ok L0 (List.mem_of_mem_drop hL0)) hr rfl rfl
          rfl).mono (by norm_num)
      have hs1 := hs.update hlslen hbslen hl4 hbsOK hlf0
        (Aux.le_cmul (by norm_num) (Aux.natCast_mul_two_pow_nonneg _ _) hlf1)
      have hs1z := vs_state hR hP hs1 ht
      exact implements_call_det hT.rejectRelease
        (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 2 (EvalsVal.var rfl) hXz rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hXz rfl)
          (.cons (ev_eWithLBA (EvalsVal.var rfl) (EvalsVal.var rfl) (EvalsVal.var rfl)
            (EvalsVal.var rfl) hsM (hs1z.trans (by omega))) .nil)))))
          (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (rejectRelease_impl hR hC hT hP hM hs1 ht hd hLd hj hN1)

end F2e2e.C.Impl.T4
