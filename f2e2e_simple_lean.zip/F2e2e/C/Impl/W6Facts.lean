import F2e2e.C.Impl.W6Lib
import F2e2e.C.SpaceParams
import F2e2e.C.SpaceRegs
import F2e2e.C.ParamsFacts
import F2e2e.Cost.Lib.MapIdx

/-!
# W6: facts used by the `EvalsVal` proofs of the tree controller

* C-SPACE's step and register lemmas under W6 names (`bankOK_addPhys'`, `step2_ok'`, `step3Depth_ok'`,
  `bankOK_addGuardY'`, `bankOK_addGuardXY'`, `guardMant_abs_le'`).
* Size facts for the uniform value bound `Mv R P` (`stateSizeBound_le_Mv`, `Mv_ge_calL_cube`,
  `valSize_int_le_of_abs_lt`, `valSize_int_le_Mv`, `valSize_encStreamParams_le`, …) and `QOK` facts.
* Canonical rationals: `encQ_intCast`, `div_num_abs_le`, `div_den_le`.
* C-ALG's `modifyAt`/`setAt`/`mapFrom` are DSL-CALC's `modifyAtL`/`setAtL`/`mapFromL`; register bounds of
  stored tags, of `guardAlpha` and of `u_d − k_d`.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

/-! ## C-SPACE's step and register lemmas (`F2e2e/C/SpaceSteps.lean`, `F2e2e/C/SpaceRegs.lean`) under
W6 names -/

/-- (C-SPACE `BankOK.addPhys`, announced for `F2e2e/C/SpaceSteps.lean`.) -/
theorem bankOK_addPhys' {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (i : ℕ) (Δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addPhys P i Δ)) :=
  h.addPhys i Δ

/-- (C-SPACE `step2_ok`, scratch form of `F2e2e/C/SpaceSteps.lean`.) -/
theorem step2_ok' {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {c : ℕ} (hc : 1 ≤ c)
    {s : State} (h : StateOK P adaOK c s) (i : ℕ) (Δ : ℤ) : StateOK P adaOK c (step2 P i Δ s).1 :=
  step2_ok hc h i Δ

/-- (C-SPACE `step3Depth_ok`, scratch form.) -/
theorem step3Depth_ok' {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {c : ℕ} (hc : 1 ≤ c)
    {s : State} (h : StateOK P adaOK c s) (tr d : ℕ) : StateOK P adaOK c (step3Depth P tr s d) :=
  step3Depth_ok hc h tr d

/-- (C-SPACE `BankOK.addGuardY`, scratch form.) -/
theorem bankOK_addGuardY' {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (g : ℕ) (δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addGuardY P g δ)) :=
  h.addGuardY g δ

/-- (C-SPACE `BankOK.addGuardXY`, scratch form.) -/
theorem bankOK_addGuardXY' {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (g : ℕ) (δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addGuardXY P g δ)) :=
  h.addGuardXY g δ

/-- (C-SPACE `guardMant_abs_le`, `F2e2e/C/SpaceRegs.lean`.) -/
theorem guardMant_abs_le' {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) {d : ℕ}
    (hd : d < P.H) :
    |guardMant L.tag (guardAlpha P) ((P.eU d : ℤ) - (L.epoch : ℤ))| ≤ 2 ^ regBits P :=
  guardMant_abs_le hL hd

/-! ## The uniform value bound -/

theorem stateSizeBound_ge (P : StreamParams) (b : ℕ) : 2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P b := by
  unfold stateSizeBound
  omega

theorem stateSizeBound_le_Mv (R : AdaRep) (P : StreamParams) :
    stateSizeBound P (R.bound P) ≤ Mv R P := by
  unfold Mv
  exact Nat.le_mul_of_pos_left _ (by positivity)

theorem Mv_ge_calL_cube (R : AdaRep) (P : StreamParams) : 2 ^ 37 * P.calL ^ 3 ≤ Mv R P := by
  have h := stateSizeBound_ge P (R.bound P)
  unfold Mv
  calc 2 ^ 37 * P.calL ^ 3 = 2 ^ 32 * (2 ^ 5 * P.calL ^ 3) := by ring
    _ ≤ 2 ^ 32 * stateSizeBound P (R.bound P) := Nat.mul_le_mul_left _ h

/-- An integer of absolute value `< 2^k` has size `≤ k + 1`. -/
theorem valSize_int_le_of_abs_lt {z : ℤ} {k : ℕ} (h : |z| < 2 ^ k) : valSize (Val.int z) ≤ k + 1 := by
  rw [valSize_int]
  have := bitLen_le_of_abs_lt h
  omega

/-- A register of at most `2^36 ℒ³` bits fits in the value bound. -/
theorem valSize_int_le_Mv (R : AdaRep) (P : StreamParams) {z : ℤ}
    (h : |z| < 2 ^ (2 ^ 36 * P.calL ^ 3)) : valSize (Val.int z) ≤ Mv R P := by
  have h1 := valSize_int_le_of_abs_lt h
  have h2 := Mv_ge_calL_cube R P
  have h3 : 1 ≤ P.calL ^ 3 := Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega)
  omega

/-! ## Canonical rationals -/

theorem encQ_intCast (z : ℤ) : encQ (z : ℚ) = Val.list [Val.int z, Val.int 1] := by
  simp [encQ, Rat.num_intCast, Rat.den_intCast]

theorem div_num_abs_le (a b : ℤ) (hb : 0 < b) : |((a : ℚ) / (b : ℚ)).num| ≤ |a| := by
  rw [← Rat.divInt_eq_div]
  by_cases ha : a = 0
  · subst ha
    simp
  · have hd := Rat.num_dvd a (ne_of_gt hb)
    have := Int.natAbs_le_of_dvd_ne_zero hd ha
    rw [Int.abs_eq_natAbs, Int.abs_eq_natAbs]
    exact_mod_cast this

theorem div_den_le (a b : ℤ) (hb : 0 < b) : (((a : ℚ) / (b : ℚ)).den : ℤ) ≤ b := by
  rw [← Rat.divInt_eq_div]
  exact Int.le_of_dvd hb (Rat.den_dvd a b)

/-! ## Sizes of parameters, coordinates, updates; `QOK` -/

theorem size_lt_of_lt_two_pow {x k : ℕ} (h : x < 2 ^ k) : Nat.size x ≤ k := Nat.size_le.mpr h

theorem valSize_encN_le_of_lt {n k : ℕ} (h : n < 2 ^ k) : valSize (encN n) ≤ k + 1 := by
  rw [valSize_encN]
  have := Nat.size_le.mpr h
  omega

theorem valSize_encStreamParams_le (P : StreamParams) : valSize (encStreamParams P) ≤ 5 * P.calL + 11 := by
  have hn : P.n < 2 ^ cP P := by have := n_add_two_le P; omega
  have hm : P.m < 2 ^ cP P := by have := m_add_two_le P; omega
  have hU : P.U < 2 ^ cP P := by
    have h := prod_le_two_pow_cP P
    have h1 : P.U + 2 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) :=
      Nat.le_mul_of_pos_left _ (by positivity)
    omega
  have hc := cP_add_hundred_le P
  have he : P.epsExp ≤ P.calL := by rw [calL_eq_cP]; omega
  have hb : P.betaExp ≤ P.calL := by rw [calL_eq_cP]; omega
  simp only [encStreamParams, valSize_encInts, List.map_cons, List.map_nil, List.sum_cons,
    List.sum_nil, bitLen_natCast]
  have h1 := size_lt_of_lt_two_pow hn
  have h2 := size_lt_of_lt_two_pow hm
  have h3 := size_lt_of_lt_two_pow hU
  have h4 := size_le_self P.epsExp
  have h5 := size_le_self P.betaExp
  omega

theorem U_add_two_le (P : StreamParams) : P.U + 2 ≤ 2 ^ cP P := by
  have h := prod_le_two_pow_cP P
  have h1 : P.U + 2 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) := Nat.le_mul_of_pos_left _ (by positivity)
  omega

theorem abs_update_lt (P : StreamParams) {Δ : ℤ} (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    |Δ| < 2 ^ (cP P + 1) := by
  have h := U_add_two_le P
  have h' : ((P.U : ℤ) + 2) ≤ (2 : ℤ) ^ cP P := by exact_mod_cast h
  rw [pow_succ]
  linarith

theorem sq_update_lt (P : StreamParams) {Δ : ℤ} (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    Δ * Δ < 2 ^ (2 * cP P + 2) := by
  have h2 := abs_update_lt P hΔ
  rw [← abs_mul_abs_self Δ]
  calc |Δ| * |Δ| < 2 ^ (cP P + 1) * 2 ^ (cP P + 1) := mul_self_lt_mul_self (abs_nonneg Δ) h2
    _ = 2 ^ (2 * cP P + 2) := by ring

theorem two_pow_le_two_pow_int {a b : ℕ} (h : a ≤ b) : (2 : ℤ) ^ a ≤ 2 ^ b :=
  pow_le_pow_right₀ (by norm_num) h

/-- `QOK` for an integer below `2^k`, `k ≤ 4 · regBits`. -/
theorem qok_intCast {P : StreamParams} {z : ℤ} {k : ℕ} (hz : |z| < 2 ^ k) (hk : k ≤ 4 * regBits P) :
    QOK P (z : ℚ) := by
  unfold QOK
  rw [Rat.num_intCast, Rat.den_intCast]
  have h := two_pow_le_two_pow_int hk
  have h1 : (1 : ℤ) ≤ 2 ^ (4 * regBits P) := one_le_pow₀ (by norm_num)
  constructor
  · linarith
  · push_cast; exact h1

/-- `QOK` for a dyadic `m / 2^e` with `|m| < 2^k`, `k, e ≤ 4 · regBits`. -/
theorem qok_gridVal {P : StreamParams} {m : ℤ} {k e : ℕ} (hm : |m| < 2 ^ k) (hk : k ≤ 4 * regBits P)
    (he : e ≤ 4 * regBits P) : QOK P (gridVal e m) := by
  unfold QOK gridVal
  have hb : (0 : ℤ) < 2 ^ e := by positivity
  have hcast : ((m : ℚ) / 2 ^ e) = (m : ℚ) / (((2 ^ e : ℤ)) : ℚ) := by push_cast; ring
  rw [hcast]
  have h1 := div_num_abs_le m (2 ^ e) hb
  have h2 := div_den_le m (2 ^ e) hb
  have h3 := two_pow_le_two_pow_int hk
  have h4 := two_pow_le_two_pow_int he
  constructor
  · linarith
  · linarith

/-- The encoded size of a rational with `QOK`. -/
theorem valSize_encQ_le_of_QOK {P : StreamParams} {x : ℚ} (h : QOK P x) :
    valSize (encQ x) ≤ 8 * regBits P + 7 := by
  obtain ⟨h1, h2⟩ := h
  have hpos : (0 : ℤ) < 2 ^ (4 * regBits P) := by positivity
  have h1' : |x.num| < 2 ^ (4 * regBits P + 1) := by rw [pow_succ]; linarith
  have h2' : |(x.den : ℤ)| < 2 ^ (4 * regBits P + 1) := by
    rw [abs_of_nonneg (by positivity), pow_succ]; linarith
  have b1 := bitLen_le_of_abs_lt h1'
  have b2 := bitLen_le_of_abs_lt h2'
  simp only [encQ, valSize_list, listSize_cons, listSize_nil, valSize_int]
  omega

/-! ## C-ALG's list updates are DSL-CALC's `modifyAtL`, `setAtL`, `mapFromL` -/

theorem modifyAt_eq_L {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), modifyAt f k l = modifyAtL f k l
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [modifyAt, modifyAtL, modifyAt_eq_L f k l]

theorem setAt_eq_L {α : Type} (b : α) : ∀ (k : ℕ) (l : List α), setAt b k l = setAtL b k l
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [setAt, setAtL, setAt_eq_L b k l]

theorem mapFrom_eq_L {α : Type} (f : α → α) : ∀ (k : ℕ) (l : List α), mapFrom f k l = mapFromL f k l
  | k, [] => by cases k <;> rfl
  | 0, a :: l => by simp only [mapFrom, mapFromL, mapFrom_eq_L f 0 l]
  | k + 1, a :: l => by simp only [mapFrom, mapFromL, mapFrom_eq_L f k l]

/-! ## Register facts derived from the parameters -/

theorem regBits_eq (P : StreamParams) : regBits P = 2 ^ 7 * P.calL ^ 3 := rfl

/-- Stored tags have at most `regBits` bits. -/
theorem LearnerOK.tag_le_regBits {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) :
    L.tag ≤ 2 ^ regBits P := by
  have h := hL.tag_le
  have h1 := eCmax_le P
  have h2 := eHC_le P
  have hc3 := hundred_mul_sq_le_cube P
  have hc1 := hundred_le_calL P
  have hc2 := hundred_mul_calL_le_sq P
  have hk : 2 + P.eCmax + P.eHC ≤ regBits P := by unfold regBits; omega
  have hC : ((P.Cmax : ℕ) : ℤ) = 2 ^ P.eCmax := by simp [StreamParams.Cmax]
  calc L.tag ≤ ((4 : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) := h
    _ = 2 ^ (2 + P.eCmax + P.eHC) := by rw [hC]; push_cast; ring
    _ ≤ 2 ^ regBits P := pow_le_pow_right₀ (by norm_num) hk

theorem abs_guardAlpha_le (P : StreamParams) : |guardAlpha P| ≤ (regBits P : ℤ) := by
  have h1 := eHg_le P
  have h2 := eHC_le P
  have h3 := eGamma_le P
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hc1 := hundred_le_calL P
  have hk : P.eHg + P.eHC + P.eGamma + 2 ≤ regBits P := by unfold regBits; omega
  have hk' : ((P.eHg + P.eHC + P.eGamma + 2 : ℕ) : ℤ) ≤ (regBits P : ℤ) := by exact_mod_cast hk
  unfold guardAlpha
  push_cast at hk'
  rw [abs_le]
  constructor <;> omega

theorem abs_eU_sub_epoch_le {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) {d : ℕ}
    (hd : d < P.H) : |(P.eU d : ℤ) - (L.epoch : ℤ)| ≤ (regBits P : ℤ) := by
  have h1 : P.eU d ≤ P.eUstar := P.eU_mono (by omega)
  have h2 := eUstar_le P
  have h3 := hL.epoch_le
  have h4 := Kepoch_le P
  have hc1 := hundred_le_calL P
  have hk1 : P.eU d ≤ regBits P := by unfold regBits; omega
  have hk2 : L.epoch ≤ regBits P := by unfold regBits; omega
  rw [abs_le]
  constructor <;> omega

end F2e2e.C.Impl.W6
