import F2e2e.C.Impl.ParamsBodies

/-!
# W1 (public parameters, DSL), part 4a: propositional evaluation lemmas and shared helpers

Owner: C-PARAMS (e26ae4ae).

**Why propositional lemmas.** The equation lemmas of `PE.val` and the core lemmas
`List.getElem?_cons_succ`, `Option.getD_some` are `rfl`-lemmas, so `simp` uses them as definitional
rewrites and the *kernel* must then check `PE.val [P.L, …] e ≡ P.eGamma + …` by its own lazy delta
reduction, which unfolds the parameter definitions (`Nat.clog` is well-founded recursion) — 15 s and
10+ GB for a single goal. The primed lemmas below are proved by `Eq.trans`/`congrArg` (not `rfl`), so
`simp only [val_var', …, getD0_cons_succ']` produces explicit rewrite proofs that the kernel checks
syntactically (milliseconds).

Use for every goal `PE.val env e = v`:
`simp only [val_var', val_lit', val_add', val_mul', val_subL', val_divL', val_maxE', val_call',
  Nat.reduceSub, getD0_cons_zero', getD0_cons_succ']`, then unfold the parameter definitions on the
right-hand side.

Also: the call conditions `clog2_cond`, `pow2_cond` and the size lemmas `valSize_map_encN_le`,
`valSize_params_le` shared by the segment files `ParamsSeg*.lean` and `ParamsSpecs.lean`.
-/

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

/-! ## Propositional evaluation lemmas -/

theorem val_var' (env : List ℕ) (i : ℕ) : PE.val env (PE.var i) = (env[i]?).getD 0 :=
  (PE.val.eq_1 env i).trans (Eq.refl _)

theorem val_lit' (env : List ℕ) (k : ℕ) : PE.val env (PE.lit k) = k :=
  (PE.val.eq_2 env k).trans (Eq.refl _)

theorem val_add' (env : List ℕ) (a b : PE) :
    PE.val env (PE.add a b) = PE.val env a + PE.val env b :=
  (PE.val.eq_3 env a b).trans (Eq.refl _)

theorem val_mul' (env : List ℕ) (a b : PE) :
    PE.val env (PE.mul a b) = PE.val env a * PE.val env b :=
  (PE.val.eq_4 env a b).trans (Eq.refl _)

theorem val_subL' (env : List ℕ) (a : PE) (k : ℕ) : PE.val env (PE.subL a k) = PE.val env a - k :=
  (PE.val.eq_5 env a k).trans (Eq.refl _)

theorem val_divL' (env : List ℕ) (a : PE) (k : ℕ) : PE.val env (PE.divL a k) = PE.val env a / k :=
  (PE.val.eq_6 env a k).trans (Eq.refl _)

theorem val_maxE' (env : List ℕ) (a b : PE) :
    PE.val env (PE.maxE a b) = Max.max (PE.val env a) (PE.val env b) :=
  (PE.val.eq_7 env a b).trans (Eq.refl _)

theorem val_call' (env : List ℕ) (j : ℕ) (f : ℕ → ℕ) (a : PE) :
    PE.val env (PE.call j f a) = f (PE.val env a) :=
  (PE.val.eq_8 env j f a).trans (Eq.refl _)

theorem getD0_cons_zero' (a : ℕ) (l : List ℕ) : ((a :: l)[0]?).getD 0 = a :=
  (congrArg (fun o => Option.getD o 0) (List.getElem?_cons_zero (a := a) (l := l))).trans
    Option.getD_some

theorem getD0_cons_succ' (a : ℕ) (l : List ℕ) (i : ℕ) :
    ((a :: l)[i + 1]?).getD 0 = (l[i]?).getD 0 :=
  congrArg (fun o => Option.getD o 0) (List.getElem?_cons_succ (a := a) (l := l) (i := i))

/-! ## The calls of the chain -/

theorem clog2_cond (hlib : W1Lib prog) {P : StreamParams} (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) (v : ℕ) :
    ∀ x, x = v → x ≤ Abnd P ^ 16 →
      CalleeOK prog M Cost.Idx.clog2 (Nat.clog 2) x ∧ Nat.clog 2 x ≤ Abnd P :=
  fun x _ hx => clog2_node hlib.clog2 hlib.clog2Step hM x hx

theorem pow2_cond (hlib : W1Lib prog) {P : StreamParams} (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) {v : ℕ}
    (hv : v ≤ 8 * P.calL ^ 3) :
    ∀ x, x = v → x ≤ Abnd P ^ 16 →
      CalleeOK prog M Cost.Idx.pow2 (fun k => 2 ^ k) x ∧ 2 ^ x ≤ Abnd P := by
  intro x hx _
  subst hx
  exact pow2_node hlib.pow2 hlib.pow2Step hM x hv

/-! ## Sizes -/

theorem valSize_map_encN_le (X : ℕ) : ∀ xs : List ℕ, (∀ x ∈ xs, x ≤ X) →
    valSize (Val.list (xs.map encN)) ≤ 1 + xs.length * (Nat.size X + 2)
  | [], _ => by simp
  | x :: xs, h => by
    have ih := valSize_map_encN_le X xs (fun y hy => h y (List.mem_cons_of_mem x hy))
    have hx := valSize_encN_le_of_le (h x List.mem_cons_self)
    simp only [List.map_cons, valSize_list, listSize_cons, List.length_cons, add_mul,
      one_mul] at ih ⊢
    omega

theorem valSize_params_le (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    valSize (Val.list [encN P.n, encN P.m, encN P.U, encN P.epsExp, encN P.betaExp]) ≤ M := by
  have h := valSize_map_encN_le (Abnd P) [P.n, P.m, P.U, P.epsExp, P.betaExp] (by
    intro x hx
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl
    exacts [n_le_A P, m_le_A P, U_le_A P, epsExp_le_A P, betaExp_le_A P])
  have hs := size_Abnd_le P hM
  simp only [List.map_cons, List.map_nil, List.length_cons, List.length_nil] at h
  omega

end W1

end F2e2e.C.Impl
