import F2e2e.C.Impl.HashBasic

/-!
# HASH area (DSL): bit operations `xorNat`, `pow2`, `sizeNat`

Specs (`notes/DSL_CONVENTION.md` §2) for the loops of `Cut2/Cost/Hash/Basic.lean`:
* `xorNat_spec`: `[a, b] ↦ a ^^^ b` for `a, b < 2^B`, cost `C_xorNat B`, space `S_xorNat B`;
* `pow2_spec`: `m ↦ 2^m`, cost `C_pow2 m`, space `S_pow2 m`;
* `sizeNat_spec`: `n ↦ Nat.size n` for `n < 2^B`, cost `C_sizeNat B`, space `S_sizeNat B`;
with the caller forms `*_call`.
-/

namespace F2e2e.Cost.HashDSL

/-- Cost bound of `xorNat` (`a, b < 2^B`). -/
def C_xorNat (B : ℕ) : ℕ := (B + 1) * (60 * (B + 3) * (B + 3) + 200) + 40

/-- Space bound of `xorNat` (`a, b < 2^B`). -/
def S_xorNat (B : ℕ) : ℕ := 50 * B + 300

/-- Cost bound of `pow2`. -/
def C_pow2 (m : ℕ) : ℕ := (m + 1) * (20 * m + 120) + 20

/-- Space bound of `pow2`. -/
def S_pow2 (m : ℕ) : ℕ := 30 * m + 200

/-- Cost bound of `sizeNat` (`n < 2^B`). -/
def C_sizeNat (B : ℕ) : ℕ := (B + 1) * (30 * B + 120) + 20

/-- Space bound of `sizeNat` (`n < 2^B`). -/
def S_sizeNat (B : ℕ) : ℕ := 30 * B + 200

/-! ### Helpers: bit lengths -/

set_option linter.unusedSimpArgs false

theorem bitLen_two : bitLen 2 = 2 := by decide

theorem bitLen_two_pow (j : ℕ) : bitLen ((2 : ℤ) ^ j) = j + 1 := by
  have : ((2 : ℤ) ^ j) = ((2 ^ j : ℕ) : ℤ) := by push_cast; ring
  rw [this, bitLen_natCast, Nat.size_pow]

theorem bitLen_nat_le_of_lt {n B : ℕ} (h : n < 2 ^ B) : bitLen (n : ℤ) ≤ B := by
  rw [bitLen_natCast]
  exact Nat.size_le.2 h

theorem encN_two_pow (m : ℕ) : encN (2 ^ m) = Val.int ((2 : ℤ) ^ m) := by
  simp [encN]

/-! ### Helpers: `pow2` -/

theorem pow2Step_stop (prog : List Expr) (base : ℕ) (acc : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int acc]] body_pow2Step
      (Val.list [Val.int 0, Val.int acc]) 30
      (base + 4 * valSize (Val.list [Val.int 0, Val.int acc]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_pow2Step, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eSub, eMul, ePair,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem pow2Step_cont (prog : List Expr) (base : ℕ) (m acc : ℤ) (hm : m ≠ 0) :
    EvalsLe prog base [Val.list [Val.int m, Val.int acc]] body_pow2Step
      (Val.list [Val.int 1, Val.list [Val.int (m - 1), Val.int (acc * 2)]])
      (50 + 2 * bitLen m + 3 * bitLen acc)
      (base + 4 * valSize (Val.list [Val.int m, Val.int acc]) + 2 * bitLen (m - 1) +
        2 * bitLen (acc * 2) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_pow2Step, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eSub, eMul, ePair,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hm, not_false_eq_true, ↓reduceIte, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two] <;> omega

/-- Encoding of the `pow2` loop state with `k` steps left: `[k, 2^(m-k)]`. -/
def encPow2 (m k : ℕ) : Val := Val.list [Val.int (k : ℤ), Val.int ((2 : ℤ) ^ (m - k))]

theorem valSize_encPow2 {m k : ℕ} (hk : k ≤ m) : valSize (encPow2 m k) ≤ 2 * m + 6 := by
  have h1 : bitLen (k : ℤ) ≤ m := le_trans (bitLen_natCast_le k) hk
  have h2 := bitLen_two_pow (m - k)
  simp only [encPow2, valSize_int, valSize_list, listSize_cons, listSize_nil]
  omega

theorem pow2_loop {prog : List Expr} (h : prog[Idx.pow2HStep]? = some body_pow2Step)
    (m base : ℕ) :
    ∀ k : ℕ, k ≤ m → ∃ out, out = encN (2 ^ m) ∧
      LoopLe prog base Idx.pow2HStep (encPow2 m k) out ((k + 1) * (53 + 5 * m + 1))
        (base + S_pow2 m) := by
  refine LoopLe.of_measure h (encPow2 m) (fun k => k ≤ m) (· = encN (2 ^ m)) (fun k => k)
    (53 + 5 * m) ?_
  intro k hk
  have hsz := valSize_encPow2 hk
  cases k with
  | zero =>
    left
    refine ⟨Val.int ((2 : ℤ) ^ m), ?_, ?_⟩
    · have e : encPow2 m 0 = Val.list [Val.int 0, Val.int ((2 : ℤ) ^ m)] := by
        simp [encPow2]
      rw [e] at hsz ⊢
      refine (pow2Step_stop prog _ _).mono (by omega) ?_
      simp only [S_pow2]
      omega
    · rw [encN_two_pow]
  | succ k =>
    right
    have hk' : k + 1 ≤ m := hk
    refine ⟨1, k, one_ne_zero, ?_, by omega, by omega⟩
    have hb1 : bitLen (((k + 1 : ℕ) : ℤ)) ≤ m := le_trans (bitLen_natCast_le _) hk'
    have hb2 : bitLen ((2 : ℤ) ^ (m - (k + 1))) = m - (k + 1) + 1 := bitLen_two_pow _
    have hb3 : bitLen (((k + 1 : ℕ) : ℤ) - 1) ≤ m := by
      have : (((k + 1 : ℕ) : ℤ) - 1) = ((k : ℕ) : ℤ) := by push_cast; ring
      rw [this]
      exact le_trans (bitLen_natCast_le _) (by omega)
    have hb4 : bitLen ((2 : ℤ) ^ (m - (k + 1)) * 2) = m - (k + 1) + 2 := by
      have : (2 : ℤ) ^ (m - (k + 1)) * 2 = 2 ^ (m - (k + 1) + 1) := by ring
      rw [this, bitLen_two_pow]
    have hstep := pow2Step_cont prog (base + valSize (encPow2 m (k + 1)))
      (((k + 1 : ℕ) : ℤ)) ((2 : ℤ) ^ (m - (k + 1))) (by omega)
    have henc : Val.list [Val.int (((k + 1 : ℕ) : ℤ) - 1), Val.int ((2 : ℤ) ^ (m - (k + 1)) * 2)] =
        encPow2 m k := by
      have e1 : (((k + 1 : ℕ) : ℤ) - 1) = ((k : ℕ) : ℤ) := by push_cast; ring
      have e2 : (2 : ℤ) ^ (m - (k + 1)) * 2 = 2 ^ (m - k) := by
        rw [show m - k = m - (k + 1) + 1 by omega, pow_succ]
      rw [e1, e2]
      rfl
    rw [henc] at hstep
    have hv : valSize (Val.list [Val.int (((k + 1 : ℕ) : ℤ)), Val.int ((2 : ℤ) ^ (m - (k + 1)))]) =
        valSize (encPow2 m (k + 1)) := rfl
    rw [hv] at hstep
    refine hstep.mono (by omega) ?_
    simp only [S_pow2]
    omega

/-! ### Helpers: `sizeNat` -/

theorem size_div_two_add_one {m : ℕ} (h : m ≠ 0) : Nat.size (m / 2) + 1 = Nat.size m := by
  conv_rhs => rw [← Nat.bit_bodd_div2 m]
  rw [Nat.size_bit (by rw [Nat.bit_bodd_div2]; exact h), Nat.div2_val]

theorem sizeNatStep_stop (prog : List Expr) (base : ℕ) (c : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int c]] body_sizeNatStep
      (Val.list [Val.int 0, Val.int c]) 30
      (base + 4 * valSize (Val.list [Val.int 0, Val.int c]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_sizeNatStep, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eDiv, eAdd, ePair,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem sizeNatStep_cont (prog : List Expr) (base : ℕ) (n c : ℤ) (hn : n ≠ 0) :
    EvalsLe prog base [Val.list [Val.int n, Val.int c]] body_sizeNatStep
      (Val.list [Val.int 1, Val.list [Val.int (n / 2), Val.int (c + 1)]])
      (50 + 4 * bitLen n + bitLen c)
      (base + 4 * valSize (Val.list [Val.int n, Val.int c]) + 2 * bitLen (n / 2) +
        2 * bitLen (c + 1) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_sizeNatStep, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eDiv, eAdd, ePair,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hn, not_false_eq_true, ↓reduceIte, OfNat.ofNat_ne_zero,
    not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two] <;> omega

/-- Encoding of the `sizeNat` loop state `[n', c]`. -/
def encSize (s : ℕ × ℕ) : Val := Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ)]

theorem sizeNat_loop {prog : List Expr} (h : prog[Idx.sizeNatStep]? = some body_sizeNatStep)
    (n B : ℕ) (hn : n < 2 ^ B) (base : ℕ) :
    ∀ s : ℕ × ℕ, (s.1 ≤ n ∧ s.2 + Nat.size s.1 = Nat.size n) → ∃ out, out = encN (Nat.size n) ∧
      LoopLe prog base Idx.sizeNatStep (encSize s) out
        ((Nat.size s.1 + 1) * (50 + 5 * B + 1)) (base + S_sizeNat B) := by
  refine LoopLe.of_measure h encSize _ _ (fun s => Nat.size s.1) (50 + 5 * B) ?_
  rintro ⟨n', c⟩ ⟨hle, hsz⟩
  simp only at hle hsz
  have hsB : Nat.size n ≤ B := Nat.size_le.2 hn
  have hb1 : bitLen (n' : ℤ) ≤ B := bitLen_nat_le_of_lt (lt_of_le_of_lt hle hn)
  have hb2 : bitLen (c : ℤ) ≤ B := le_trans (bitLen_natCast_le c) (by omega)
  have hvs : valSize (encSize (n', c)) ≤ 2 * B + 5 := by
    simp only [encSize, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  rcases Nat.eq_zero_or_pos n' with rfl | hpos
  · left
    refine ⟨Val.int (c : ℤ), ?_, ?_⟩
    · have e : encSize (0, c) = Val.list [Val.int 0, Val.int (c : ℤ)] := by simp [encSize]
      rw [e] at hvs ⊢
      refine (sizeNatStep_stop prog _ _).mono (by omega) ?_
      simp only [S_sizeNat]
      omega
    · simp only [Nat.size_zero, Nat.add_zero] at hsz
      simp [encN, hsz]
  · right
    have hn0 : (n' : ℤ) ≠ 0 := by omega
    have hdiv := size_div_two_add_one (show n' ≠ 0 by omega)
    refine ⟨1, (n' / 2, c + 1), one_ne_zero, ?_, ⟨?_, ?_⟩, ?_⟩
    · have hstep := sizeNatStep_cont prog (base + valSize (encSize (n', c))) (n' : ℤ) (c : ℤ) hn0
      have henc : Val.list [Val.int ((n' : ℤ) / 2), Val.int ((c : ℤ) + 1)] =
          encSize (n' / 2, c + 1) := by
        simp [encSize]
      rw [henc] at hstep
      have hv : valSize (Val.list [Val.int (n' : ℤ), Val.int (c : ℤ)]) = valSize (encSize (n', c)) :=
        rfl
      rw [hv] at hstep
      have hb3 : bitLen ((n' : ℤ) / 2) ≤ B := by
        rw [show (n' : ℤ) / 2 = ((n' / 2 : ℕ) : ℤ) by push_cast; rfl]
        exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) (lt_of_le_of_lt hle hn))
      have hb4 : bitLen ((c : ℤ) + 1) ≤ B + 1 := by
        have := bitLen_add_le (c : ℤ) 1
        simp only [bitLen_one] at this
        omega
      refine hstep.mono (by omega) ?_
      simp only [S_sizeNat]
      omega
    · simp only
      exact le_trans (Nat.div_le_self _ _) hle
    · simp only
      omega
    · simp only
      omega

/-! ### Helpers: `xorNat` -/

theorem bitLen_emod_two_le (x : ℤ) : bitLen (x % 2) ≤ 1 := by
  have h0 : 0 ≤ x % 2 := Int.emod_nonneg x (by norm_num)
  have h1 : x % 2 < 2 := Int.emod_lt_of_pos x (by norm_num)
  have : x % 2 = 0 ∨ x % 2 = 1 := by omega
  rcases this with h | h <;> rw [h] <;> simp

theorem xorNatStep_stop (prog : List Expr) (base : ℕ) (r w : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int 0, Val.int r, Val.int w]] body_xorNatStep
      (Val.list [Val.int 0, Val.int r]) 60
      (base + 4 * valSize (Val.list [Val.int 0, Val.int 0, Val.int r, Val.int w]) + 30) := by
  apply EvalsLe.of_eval 20
  simp only [body_xorNatStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eAdd,
    eMod, eMul, eList, eCons, ePair,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte, add_zero]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem xorNatStep_eq (prog : List Expr) (base : ℕ) (a b r w : ℤ) (hab : a + b ≠ 0)
    (hm : a % 2 = b % 2) :
    EvalsLe prog base [Val.list [Val.int a, Val.int b, Val.int r, Val.int w]] body_xorNatStep
      (Val.list [Val.int 1, Val.list [Val.int (a / 2), Val.int (b / 2), Val.int r,
        Val.int (w * 2)]])
      (150 + 2 * bitLen (a + b) + 8 * bitLen a + 8 * bitLen b + 4 * bitLen r + 6 * bitLen w)
      (base + 4 * valSize (Val.list [Val.int a, Val.int b, Val.int r, Val.int w]) +
        3 * (bitLen (a + b) + bitLen (a / 2) + bitLen (b / 2) + bitLen (r + w) + bitLen r +
          bitLen (w * 2)) + 80) := by
  have ha2 := bitLen_emod_two_le a
  have hb2 := bitLen_emod_two_le b
  apply EvalsLe.of_eval 20
  simp only [body_xorNatStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eAdd,
      eMod, eMul, eList, eCons, ePair,
      eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
      eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, ne_eq, hab, hm, not_false_eq_true, ↓reduceIte, OfNat.ofNat_ne_zero,
      one_ne_zero, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
        bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one, bitLen_two]
    omega

theorem xorNatStep_ne (prog : List Expr) (base : ℕ) (a b r w : ℤ) (hab : a + b ≠ 0)
    (hm : ¬ a % 2 = b % 2) :
    EvalsLe prog base [Val.list [Val.int a, Val.int b, Val.int r, Val.int w]] body_xorNatStep
      (Val.list [Val.int 1, Val.list [Val.int (a / 2), Val.int (b / 2), Val.int (r + w),
        Val.int (w * 2)]])
      (150 + 2 * bitLen (a + b) + 8 * bitLen a + 8 * bitLen b + 4 * bitLen r + 6 * bitLen w)
      (base + 4 * valSize (Val.list [Val.int a, Val.int b, Val.int r, Val.int w]) +
        3 * (bitLen (a + b) + bitLen (a / 2) + bitLen (b / 2) + bitLen (r + w) + bitLen r +
          bitLen (w * 2)) + 80) := by
  have ha2 := bitLen_emod_two_le a
  have hb2 := bitLen_emod_two_le b
  apply EvalsLe.of_eval 20
  simp only [body_xorNatStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eAdd,
      eMod, eMul, eList, eCons, ePair,
      eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
      eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, ne_eq, hab, hm, not_false_eq_true, ↓reduceIte, OfNat.ofNat_ne_zero,
      one_ne_zero, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
        bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one, bitLen_two]
    omega

theorem xor_mod_two (x y : ℕ) : (x ^^^ y) % 2 = if x % 2 = y % 2 then 0 else 1 := by
  have h := Nat.xor_mod_two_eq_one (a := x) (b := y)
  rcases Nat.mod_two_eq_zero_or_one x with hx | hx <;>
    rcases Nat.mod_two_eq_zero_or_one y with hy | hy <;>
    rcases Nat.mod_two_eq_zero_or_one (x ^^^ y) with hz | hz <;> simp_all

/-- The new low bit of `a ^^^ b`. -/
theorem xor_mod_two_pow_succ (a b i : ℕ) :
    (a ^^^ b) % 2 ^ (i + 1) =
      if a / 2 ^ i % 2 = b / 2 ^ i % 2 then (a ^^^ b) % 2 ^ i else (a ^^^ b) % 2 ^ i + 2 ^ i := by
  rw [Nat.mod_pow_succ, Nat.xor_div_two_pow, xor_mod_two]
  split_ifs <;> simp

/-- Encoding of the `xorNat` loop state `[a', b', r, 2^i]`. -/
def encXor (s : ℕ × ℕ × ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2.1 : ℤ), Val.int (s.2.2.1 : ℤ),
    Val.int ((2 : ℤ) ^ s.2.2.2)]

theorem xorNat_loop {prog : List Expr} (h : prog[Idx.xorNatStep]? = some body_xorNatStep)
    (a b B : ℕ) (ha : a < 2 ^ B) (hb : b < 2 ^ B) (base : ℕ) :
    ∀ s : ℕ × ℕ × ℕ × ℕ, (s.1 = a / 2 ^ s.2.2.2 ∧ s.2.1 = b / 2 ^ s.2.2.2 ∧
        s.2.2.1 = (a ^^^ b) % 2 ^ s.2.2.2 ∧ s.2.2.2 ≤ B) →
      ∃ out, out = encN (a ^^^ b) ∧
        LoopLe prog base Idx.xorNatStep (encXor s) out
          ((B - s.2.2.2 + 1) * (60 * (B + 3) * (B + 3) + 199 + 1)) (base + S_xorNat B) := by
  refine LoopLe.of_measure h encXor _ _ (fun s => B - s.2.2.2) (60 * (B + 3) * (B + 3) + 199) ?_
  rintro ⟨a', b', r, i⟩ ⟨ha', hb', hr, hi⟩
  simp only at ha' hb' hr hi
  have hpi : 0 < 2 ^ i := Nat.two_pow_pos i
  have hab' : a' < 2 ^ B := lt_of_le_of_lt (by rw [ha']; exact Nat.div_le_self _ _) ha
  have hbb' : b' < 2 ^ B := lt_of_le_of_lt (by rw [hb']; exact Nat.div_le_self _ _) hb
  have hr' : r < 2 ^ B := by
    rw [hr]
    exact lt_of_lt_of_le (Nat.mod_lt _ hpi) (Nat.pow_le_pow_right (by norm_num) hi)
  have hba := bitLen_nat_le_of_lt hab'
  have hbb := bitLen_nat_le_of_lt hbb'
  have hbr := bitLen_nat_le_of_lt hr'
  have hbw : bitLen ((2 : ℤ) ^ i) = i + 1 := bitLen_two_pow i
  have hvs : valSize (encXor (a', b', r, i)) ≤ 4 * B + 10 := by
    simp only [encXor, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  by_cases h0 : a' + b' = 0
  · -- stop
    left
    have ha0 : a' = 0 := by omega
    have hb0 : b' = 0 := by omega
    refine ⟨Val.int (r : ℤ), ?_, ?_⟩
    · have e : encXor (a', b', r, i) = Val.list [Val.int 0, Val.int 0, Val.int (r : ℤ),
          Val.int ((2 : ℤ) ^ i)] := by simp [encXor, ha0, hb0]
      rw [e] at hvs ⊢
      refine (xorNatStep_stop prog _ _ _).mono (by nlinarith) ?_
      simp only [S_xorNat]
      omega
    · have hai : a < 2 ^ i := by
        rw [ha0] at ha'
        exact (Nat.div_eq_zero_iff_lt hpi).1 ha'.symm
      have hbi : b < 2 ^ i := by
        rw [hb0] at hb'
        exact (Nat.div_eq_zero_iff_lt hpi).1 hb'.symm
      rw [hr, Nat.mod_eq_of_lt (Nat.xor_lt_two_pow hai hbi)]
      rfl
  · -- continue
    right
    have hiB : i < B := by
      by_contra hcon
      have h1 : a / 2 ^ i = 0 :=
        Nat.div_eq_of_lt (lt_of_lt_of_le ha (Nat.pow_le_pow_right (by norm_num) (by omega)))
      have h2 : b / 2 ^ i = 0 :=
        Nat.div_eq_of_lt (lt_of_lt_of_le hb (Nat.pow_le_pow_right (by norm_num) (by omega)))
      omega
    have hz : (a' : ℤ) + (b' : ℤ) ≠ 0 := by omega
    set r' := if a' % 2 = b' % 2 then r else r + 2 ^ i with hr'def
    refine ⟨1, (a' / 2, b' / 2, r', i + 1), one_ne_zero, ?_, ⟨?_, ?_, ?_, ?_⟩, ?_⟩
    · have hcond : ((a' : ℤ) % 2 = (b' : ℤ) % 2) ↔ (a' % 2 = b' % 2) := by
        rw [show (a' : ℤ) % 2 = ((a' % 2 : ℕ) : ℤ) by push_cast; rfl,
          show (b' : ℤ) % 2 = ((b' % 2 : ℕ) : ℤ) by push_cast; rfl]
        exact Int.natCast_inj
      have hd1 : (a' : ℤ) / 2 = ((a' / 2 : ℕ) : ℤ) := by push_cast; rfl
      have hd2 : (b' : ℤ) / 2 = ((b' / 2 : ℕ) : ℤ) := by push_cast; rfl
      have hw : (2 : ℤ) ^ i * 2 = 2 ^ (i + 1) := by ring
      have hstep : EvalsLe prog (base + valSize (encXor (a', b', r, i)))
          [encXor (a', b', r, i)] body_xorNatStep
          (Val.list [Val.int 1, encXor (a' / 2, b' / 2, r', i + 1)])
          (150 + 2 * bitLen ((a' : ℤ) + (b' : ℤ)) + 8 * bitLen (a' : ℤ) + 8 * bitLen (b' : ℤ) +
            4 * bitLen (r : ℤ) + 6 * bitLen ((2 : ℤ) ^ i))
          (base + valSize (encXor (a', b', r, i)) + 4 * valSize (encXor (a', b', r, i)) +
            3 * (bitLen ((a' : ℤ) + (b' : ℤ)) + bitLen ((a' : ℤ) / 2) + bitLen ((b' : ℤ) / 2) +
              bitLen ((r : ℤ) + 2 ^ i) + bitLen (r : ℤ) + bitLen ((2 : ℤ) ^ i * 2)) + 80) := by
        by_cases hc : a' % 2 = b' % 2
        · have h1 := xorNatStep_eq prog (base + valSize (encXor (a', b', r, i))) (a' : ℤ)
            (b' : ℤ) (r : ℤ) ((2 : ℤ) ^ i) hz (hcond.2 hc)
          have e : Val.list [Val.int ((a' : ℤ) / 2), Val.int ((b' : ℤ) / 2), Val.int (r : ℤ),
              Val.int ((2 : ℤ) ^ i * 2)] = encXor (a' / 2, b' / 2, r', i + 1) := by
            simp only [encXor, hr'def, if_pos hc, hd1, hd2, hw]
          rw [e] at h1
          exact h1
        · have h1 := xorNatStep_ne prog (base + valSize (encXor (a', b', r, i))) (a' : ℤ)
            (b' : ℤ) (r : ℤ) ((2 : ℤ) ^ i) hz (fun h => hc (hcond.1 h))
          have e : Val.list [Val.int ((a' : ℤ) / 2), Val.int ((b' : ℤ) / 2),
              Val.int ((r : ℤ) + 2 ^ i), Val.int ((2 : ℤ) ^ i * 2)] =
              encXor (a' / 2, b' / 2, r', i + 1) := by
            simp only [encXor, hr'def, if_neg hc, hd1, hd2, hw]
            push_cast
            rfl
          rw [e] at h1
          exact h1
      have hsum : bitLen ((a' : ℤ) + (b' : ℤ)) ≤ B + 1 := by
        have := bitLen_add_le (a' : ℤ) (b' : ℤ)
        omega
      have hda : bitLen ((a' : ℤ) / 2) ≤ B := by
        rw [show (a' : ℤ) / 2 = ((a' / 2 : ℕ) : ℤ) by push_cast; rfl]
        exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) hab')
      have hdb : bitLen ((b' : ℤ) / 2) ≤ B := by
        rw [show (b' : ℤ) / 2 = ((b' / 2 : ℕ) : ℤ) by push_cast; rfl]
        exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) hbb')
      have hrw : bitLen ((r : ℤ) + 2 ^ i) ≤ B + 2 := by
        have := bitLen_add_le (r : ℤ) ((2 : ℤ) ^ i)
        omega
      have hw2 : bitLen ((2 : ℤ) ^ i * 2) = i + 2 := by
        have : (2 : ℤ) ^ i * 2 = 2 ^ (i + 1) := by ring
        rw [this, bitLen_two_pow]
      refine hstep.mono ?_ ?_
      · nlinarith
      · simp only [S_xorNat]
        omega
    · simp only
      rw [ha', Nat.div_div_eq_div_mul, ← pow_succ]
    · simp only
      rw [hb', Nat.div_div_eq_div_mul, ← pow_succ]
    · simp only
      rw [xor_mod_two_pow_succ, ← ha', ← hb', ← hr]
    · simp only
      omega
    · simp only
      omega

section specs

variable {prog : List Expr}

/-- **Spec of `xorNat`.** -/
theorem xorNat_spec (h : prog[Idx.xorNatStep]? = some body_xorNatStep) (a b B : ℕ)
    (ha : a < 2 ^ B) (hb : b < 2 ^ B) (base : ℕ) :
    EvalsLe prog base [Val.list [encN a, encN b]] body_xorNat (encN (a ^^^ b)) (C_xorNat B)
      (base + S_xorNat B) := by
  obtain ⟨out, rfl, hloop⟩ := xorNat_loop h a b B ha hb base (a, b, 0, 0)
    ⟨by simp, by simp, by simp [Nat.mod_one], Nat.zero_le _⟩
  have hba := bitLen_nat_le_of_lt ha
  have hbb := bitLen_nat_le_of_lt hb
  have hinit : EvalsLe prog base [Val.list [encN a, encN b]]
      (eList [eHd (eV 0), eAt1 (eV 0), eLit 0, eLit 1]) (encXor (a, b, 0, 0)) 30
      (base + 4 * valSize (Val.list [encN a, encN b]) + 20) := by
    apply EvalsLe.of_eval 20
    simp only [encXor, encN, eList, eCons, eHd, eAt1, eTl, eV, eLit, eval_succ_var, eval_succ_lit,
      eval_succ_nil, eval_succ_bin, eval_succ_un, evalBin, evalUn, Option.bind_some,
      Option.map_some, List.getElem?_cons_zero, Nat.cast_zero, pow_zero]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega
  have hsz : valSize (Val.list [encN a, encN b]) ≤ 2 * B + 5 := by
    simp only [encN, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_xorNat, Nat.sub_zero]
    nlinarith
  · simp only [S_xorNat, max_le_iff]
    omega

/-- **Spec of `call Idx.xorNat`.** -/
theorem xorNat_call (h1 : prog[Idx.xorNat]? = some body_xorNat)
    (h2 : prog[Idx.xorNatStep]? = some body_xorNatStep) {base : ℕ} {env : List Val} {e : Expr}
    {a b B : ℕ} (ha : a < 2 ^ B) (hb : b < 2 ^ B) {Ce Se : ℕ}
    (he : EvalsLe prog base env e (Val.list [encN a, encN b]) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.xorNat e) (encN (a ^^^ b)) (1 + Ce + C_xorNat B)
      (max Se (base + valSize (Val.list [encN a, encN b]) + S_xorNat B)) :=
  EvalsLe.call he h1 (xorNat_spec h2 a b B ha hb _)

/-- **Spec of `pow2`.** -/
theorem pow2_spec (h : prog[Idx.pow2HStep]? = some body_pow2Step) (m base : ℕ) :
    EvalsLe prog base [encN m] body_pow2 (encN (2 ^ m)) (C_pow2 m) (base + S_pow2 m) := by
  obtain ⟨out, rfl, hloop⟩ := pow2_loop h m base m le_rfl
  have hinit : EvalsLe prog base [encN m] (ePair (eV 0) (eLit 1)) (encPow2 m m) 8
      (base + 2 * valSize (encN m) + 9) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [encN m])
      (EvalsLe.var (i := 0) (v := encN m) rfl) (EvalsLe.lit 1)
    have e : Val.list [encN m, Val.int 1] = encPow2 m m := by simp [encPow2, encN]
    rw [e] at this
    refine this.mono (by simp) ?_
    simp only [valSize_int, bitLen_one, max_le_iff]
    omega
  have hsz : valSize (encN m) ≤ m + 1 := by
    rw [valSize_encN]; have := size_le_self m; omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_pow2]
    nlinarith
  · simp only [S_pow2, max_le_iff]
    omega

/-- **Spec of `call Idx.pow2H`.** -/
theorem pow2_call (h1 : prog[Idx.pow2H]? = some body_pow2)
    (h2 : prog[Idx.pow2HStep]? = some body_pow2Step) {base : ℕ} {env : List Val} {e : Expr}
    {m Ce Se : ℕ} (he : EvalsLe prog base env e (encN m) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.pow2H e) (encN (2 ^ m)) (1 + Ce + C_pow2 m)
      (max Se (base + valSize (encN m) + S_pow2 m)) :=
  EvalsLe.call he h1 (pow2_spec h2 m _)

/-- **Spec of `sizeNat`.** -/
theorem sizeNat_spec (h : prog[Idx.sizeNatStep]? = some body_sizeNatStep) (n B : ℕ)
    (hn : n < 2 ^ B) (base : ℕ) :
    EvalsLe prog base [encN n] body_sizeNat (encN (Nat.size n)) (C_sizeNat B)
      (base + S_sizeNat B) := by
  obtain ⟨out, rfl, hloop⟩ := sizeNat_loop h n B hn base (n, 0) ⟨le_rfl, by simp⟩
  have hsB : Nat.size n ≤ B := Nat.size_le.2 hn
  have hinit : EvalsLe prog base [encN n] (ePair (eV 0) (eLit 0)) (encSize (n, 0)) 8
      (base + 2 * valSize (encN n) + 9) := by
    have := EvalsLe.pair (prog := prog) (base := base) (env := [encN n])
      (EvalsLe.var (i := 0) (v := encN n) rfl) (EvalsLe.lit 0)
    have e : Val.list [encN n, Val.int 0] = encSize (n, 0) := by simp [encSize, encN]
    rw [e] at this
    refine this.mono (by simp) ?_
    simp only [valSize_int, bitLen_zero, max_le_iff]
    omega
  have hsz : valSize (encN n) ≤ B + 1 := by
    rw [valSize_encN]; omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_sizeNat]
    nlinarith
  · simp only [S_sizeNat, max_le_iff]
    omega

/-- **Spec of `call Idx.sizeNat`.** -/
theorem sizeNat_call (h1 : prog[Idx.sizeNat]? = some body_sizeNat)
    (h2 : prog[Idx.sizeNatStep]? = some body_sizeNatStep) {base : ℕ} {env : List Val} {e : Expr}
    {n B : ℕ} (hn : n < 2 ^ B) {Ce Se : ℕ} (he : EvalsLe prog base env e (encN n) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.sizeNat e) (encN (Nat.size n)) (1 + Ce + C_sizeNat B)
      (max Se (base + valSize (encN n) + S_sizeNat B)) :=
  EvalsLe.call he h1 (sizeNat_spec h2 n B hn _)

end specs

end F2e2e.Cost.HashDSL
