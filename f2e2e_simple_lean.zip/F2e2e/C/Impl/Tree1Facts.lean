import F2e2e.C.Impl.Tree1Defs
import F2e2e.C.SpaceRegs

/-!
# W6, Tree1: facts used by the Step 1 proofs

* `foldB_impl_idx`: DSL-CALC's `foldB` routine with an invariant that may depend on the remaining
  list (the birth loop's invariant relates the state to the next depth).
* List facts: `setAt_eq_set`, `modifyAt_eq_modifyAtL`, `suffix_range'`, `drop_range_eq`,
  `birthLoop_eq_foldB`.
* `Implements` rules: `implements_ite`.
-/

namespace F2e2e.C.Impl.T1

open F2e2e F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate parameters such as
`P.eHC` symbolically (C-SPACE's tip). -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## `Implements` rules -/

section ImplRules

variable {prog : List Expr} {M : ℕ} {env : List Val} {β : Type}

theorem implements_ite {c t f : Expr} {z : ℤ} {enc : β → Val} {p : BitProg β}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hb : Implements prog M env (if z ≠ 0 then t else f) enc p) :
    Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  simpa using EvalsVal.ite hc (hb bits a h)

/-- A deterministic `ite` whose condition is a nonzero integer. -/
theorem ev_ite_true {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsVal prog M env [] (.inl t) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v := by
  simpa using EvalsVal.ite_true hc hz ht

/-- A deterministic `ite` whose condition is zero. -/
theorem ev_ite_false {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsVal prog M env [] (.inl f) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v := by
  simpa using EvalsVal.ite_false hc hz hf

end ImplRules

/-! ## `foldB` with a list-dependent invariant -/

section FoldIdx

variable {prog : List Expr} {M : ℕ} {α σ : Type}

theorem foldB_loop_idx {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (f : α → σ → BitProg σ) (l : List α)
    (I : List α → σ → Prop) (VS : ℕ)
    (hI : ∀ x r s bits s', (x :: r) <:+ l → I (x :: r) s → (f x s).run bits = some (s', []) →
      I r s')
    (hFi : ∀ x r s, (x :: r) <:+ l → I (x :: r) s →
      Implements prog M [Val.list [encA x, encS s, extra]] bodyF encS (f x s))
    (hV : ∀ r s, r <:+ l → I r s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) :
    ∀ r : List α, r <:+ l → ∀ s, I r s → ∀ bits s', (foldB f r s).run bits = some (s', []) →
      EvalsVal prog M [] bits (.inr (iStep, Val.list [encS s, encL encA r, extra])) (encS s') := by
  intro r
  induction r with
  | nil =>
    intro hsuf s hs bits s' h
    obtain ⟨hb1, hb2⟩ := bitProg_run_pure_exact.mp h
    subst hb1
    rw [hb2]
    have hVs := hV [] s hsuf hs
    have hL := valSize_encL_ge encA l
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil]
    exact foldBStep_nil_val iF (encS s) extra
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  | cons x r ih =>
    intro hsuf s hs bits s' h
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    rw [foldB_cons] at h
    obtain ⟨b₁, b₂, s'', rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    have hs'' := hI x r s b₁ s'' hsuf hs h1
    have hcall := hFi x r s hsuf hs b₁ s'' h1
    have hrest := ih hsuf' s'' hs'' b₂ s' h2
    have hVs := hV (x :: r) s hsuf hs
    have hVs'' := hV r s'' hsuf' hs''
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hbody := foldBStep_cons_val (R := r.map encA) hF hcall
      (by simp only [encL, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hR hM ⊢
          omega)
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- **Spec of `foldB` with a list-dependent invariant** (`Implements` form): the invariant `I r s`
may depend on the remaining list `r`. -/
theorem foldB_impl_idx {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (f : α → σ → BitProg σ) (l : List α)
    (I : List α → σ → Prop) (VS : ℕ)
    (hI : ∀ x r s bits s', (x :: r) <:+ l → I (x :: r) s → (f x s).run bits = some (s', []) →
      I r s')
    (hFi : ∀ x r s, (x :: r) <:+ l → I (x :: r) s →
      Implements prog M [Val.list [encA x, encS s, extra]] bodyF encS (f x s))
    (hV : ∀ r s, r <:+ l → I r s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : I l s) :
    Implements prog M [Val.list [encS s, encL encA l, extra]] (body_foldB iStep) encS
      (foldB f l s) := by
  intro bits s' h
  exact EvalsVal.loop EvalsVal.var0
    (foldB_loop_idx hstep hF encA encS extra f l I VS hI hFi hV hM l (List.suffix_refl l) s hs
      bits s' h)

end FoldIdx

/-! ## List facts -/

theorem setAt_eq_set {α : Type} (b : α) : ∀ (k : ℕ) (l : List α), setAt b k l = l.set k b
  | 0, [] => rfl
  | _ + 1, [] => rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [setAt, List.set_cons_succ, setAt_eq_set b k l]

theorem modifyAt_eq_modifyAtL {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), modifyAt f k l = modifyAtL f k l
  | 0, [] => rfl
  | _ + 1, [] => rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [modifyAt, modifyAtL, modifyAt_eq_modifyAtL f k l]

theorem length_modifyAt' {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (modifyAt f k l).length = l.length
  | 0, [] => rfl
  | _ + 1, [] => rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [modifyAt, List.length_cons, length_modifyAt' f k l]

/-- The head of a nonempty suffix of `range' a n` is `a + n - |suffix|`. -/
theorem suffix_range' {a n x : ℕ} {r : List ℕ} (h : (x :: r) <:+ List.range' a n) :
    x + (r.length + 1) = a + n ∧ r.length + 1 ≤ n := by
  have hlen := h.length_le
  simp only [List.length_cons, List.length_range'] at hlen
  rw [List.suffix_iff_eq_drop] at h
  simp only [List.length_range', List.length_cons, List.drop_range', Nat.mul_one] at h
  rw [eq_comm, List.range'_eq_cons_iff] at h
  omega

/-- `(range H).drop d = range' d (H - d)`. -/
theorem drop_range_eq (H d : ℕ) : (List.range H).drop d = List.range' d (H - d) := by
  rw [List.range_eq_range', List.drop_range']
  simp

/-- The birth loop is DSL-CALC's `foldB` with the failure check folded into the step. -/
theorem birthLoop_eq_foldB (P : StreamParams) (d0 : ℕ) :
    ∀ (ds : List ℕ) (s : State), birthLoop P d0 ds s =
      foldB (fun d s => if s.failed then BitProg.pure s else birthDepth P d0 d s) ds s := by
  intro ds s
  have h : ∀ (ds : List ℕ) (s : State), birthLoop P d0 ds s =
      foldBE (fun s => s.failed) (birthDepth P d0) ds s := by
    intro ds
    induction ds with
    | nil => intro s; rfl
    | cons d ds ih =>
      intro s
      simp only [birthLoop, foldBE]
      split_ifs
      · rfl
      · show (birthDepth P d0 d s).bind (fun s' => birthLoop P d0 ds s') = _
        congr 1
        funext s'
        exact ih s'
  rw [h, foldBE_eq_foldB]

/-! ## `Always` along a run -/

/-- A post-condition of `p.bind f` holds for the continuation of every run of `p`. -/
theorem always_of_bind_run {α β : Type} {Q : β → Prop} :
    ∀ {p : BitProg α} {f : α → BitProg β}, Always (p.bind f) Q →
      ∀ {t : List Bool} {a : α} {r : List Bool}, p.run t = some (a, r) → Always (f a) Q
  | BitProg.pure a', f, h, t, a, r, hr => by
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hr
    obtain ⟨rfl, -⟩ := hr
    exact h
  | BitProg.bit k, f, h, t, a, r, hr => by
    cases t with
    | nil => simp at hr
    | cons b t => exact always_of_bind_run (h b) hr

/-! ## The reference birth, split at the allocation of the outgoing bank -/

/-- The state after the reset of the incoming secondary array (partIII.tex L475). -/
def s1Of (s : State) (d : ℕ) : State :=
  { s with banks := modifyAt (Bank.mapRows Row.resetY) d s.banks }

/-- The allocation of the outgoing bank (partIII.tex L476). -/
def s2Prog (P : StreamParams) (d : ℕ) (s : State) : BitProg State :=
  if d + 2 ≤ P.H then
    (newBank P).bind (fun B => BitProg.pure { s1Of s d with banks := (s1Of s d).banks ++ [B] })
  else BitProg.pure (s1Of s d)

/-- The rest of one birth: the birth cache and the learner record (partIII.tex L477, L474). -/
def birthCont (P : StreamParams) (d0 d : ℕ) (s2 : State) : BitProg State :=
  if d = 0 ∨ d0 < d then
    BitProg.pure { s2 with learners := s2.learners ++ [newLearner P 0] }
  else
    match s2.banks[d]? with
    | none => BitProg.pure s2.fail
    | some B =>
      (B.release P Mode.primary).bind (fun res =>
        let s3 : State := { s2 with banks := setAt res.2 d s2.banks }
        match res.1 with
        | none => BitProg.pure s3.fail
        | some N =>
          let cache := roundMant P.eHP N
          if inRangeA P (gridVal P.eHP cache) then
            BitProg.pure { s3 with learners := s2.learners ++ [newLearner P cache] }
          else BitProg.pure s3.fail)

theorem birthDepth_eq (P : StreamParams) (d0 d : ℕ) (s : State) :
    birthDepth P d0 d s = (s2Prog P d s).bind (birthCont P d0 d) := by
  rfl

/-- The encoded new learner `[2^{eHC}, cache, 0, 0, 0]`. -/
theorem encLearner_newLearner (P : StreamParams) (c : ℤ) :
    encLearner (newLearner P c) =
      Val.list [encN (2 ^ P.eHC), Val.int c, Val.int 0, Val.int 0, Val.int 0] := by
  have h : ((2 ^ P.eHC : ℕ) : ℤ) = (2 : ℤ) ^ P.eHC := by push_cast; rfl
  simp only [encLearner, newLearner, encInts, encN, List.map_cons, List.map_nil, h, Nat.cast_zero]

/-- The encoded state, field by field. -/
theorem encState_eq (adaEnc : F2e2e.B.AdaState → Val) (s : State) :
    encState adaEnc s = Val.list [Val.int (s.t : ℤ), Val.int (if s.failed then 1 else 0),
      Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ), encL encLearner s.learners,
      encL (encBank adaEnc) s.banks, Val.int s.leaf] := rfl

/-! ## Sizes -/

section Sizes

variable {R : AdaRep} {P : StreamParams}

theorem bankSizeBound_le_ssb (P : StreamParams) (a : ℕ) :
    bankSizeBound P a + 1 ≤ stateSizeBound P a := by
  have hH := StreamParams.one_le_H P
  unfold stateSizeBound
  have h1 : bankSizeBound P a + 1 ≤ P.H * (bankSizeBound P a + 1) := Nat.le_mul_of_pos_left _ hH
  omega

/-- A list of at most `H` valid banks fits in the state size bound. -/
theorem banks_size_le (hR : R.Valid) (hP : ParamsOK P) {bs : List Bank}
    (hok : ∀ B ∈ bs, BankOK P (R.ok P) B) (hlen : bs.length ≤ P.H) :
    valSize (encL (encBank R.enc) bs) ≤ stateSizeBound P (R.bound P) := by
  have h1 := valSize_encL_le (encBank R.enc) bs (bankSizeBound P (R.bound P))
    (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hok B hB))
  have h2 : bs.length * (bankSizeBound P (R.bound P) + 1) ≤
      P.H * (bankSizeBound P (R.bound P) + 1) := Nat.mul_le_mul_right _ hlen
  have hH := StreamParams.one_le_H P
  have h3 : 1 ≤ P.H * (2 ^ 6 * P.calL ^ 3 + 1) := Nat.one_le_iff_ne_zero.mpr (by positivity)
  unfold stateSizeBound
  omega

theorem bank_size_le (hR : R.Valid) (hP : ParamsOK P) {B : Bank} (hB : BankOK P (R.ok P) B) :
    valSize (encBank R.enc B) ≤ stateSizeBound P (R.bound P) :=
  (BankOK.valSize_encBank_le (hR.enc_le P hP) hB).trans
    ((Nat.le_succ _).trans (bankSizeBound_le_ssb P _))

theorem valSize_exVal_le (P : StreamParams) {d0 : ℕ} (hd0 : d0 ≤ P.H) :
    valSize (exVal P d0) ≤ 2 ^ 5 * P.calL ^ 3 := by
  have hp := valSize_encStreamParams_le P
  have hH := H_le P
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hc1 := hundred_le_calL P
  have hHC := eHC_le P
  have hHP := eHP_le P
  have s1 : Nat.size d0 ≤ P.calL := (size_le_self _).trans (hd0.trans hH)
  have s2 : Nat.size P.H ≤ P.calL := (size_le_self _).trans hH
  have s3 : Nat.size (2 ^ P.eHC) = P.eHC + 1 := Nat.size_pow
  have s4 : Nat.size P.eHP ≤ 7 * P.calL ^ 2 := (size_le_self _).trans hHP
  have s5 : Nat.size (2 ^ P.eHP) = P.eHP + 1 := Nat.size_pow
  simp only [exVal, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

end Sizes

end F2e2e.C.Impl.T1
