import F2e2e.C.Impl.HashBits
import F2e2e.Lib.Hash.Contracts
import F2e2e.C.Impl.HashRules
import F2e2e.C.Impl.HashUniform

/-!
# HASH area (DSL): GF(2)[x] arithmetic `clmul`, `pmodDeg`, `gfMul`

Reference functions: `Cut2.Hash.clmul`, `Cut2.Hash.pmodDeg`, `Cut2.Hash.gfMul`.
* `clmul_spec`: `[a, b] ↦ clmul a b` (`a < 2^A`, `b < 2^Bb`);
* `pmodDeg_spec`: `[d, p, a] ↦ pmodDeg d p a` (`2^d ≤ p < 2^(d+1)`, `a < 2^A`);
* `gfMul_spec`: `[q, p, x, y] ↦ gfMul q p x y` (`2^q ≤ p < 2^(q+1)`, `x, y < 2^q`).
-/

namespace F2e2e.Cost.HashDSL

/-- Cost bound of `clmul` (`a < 2^A`, `b < 2^Bb`). -/
def C_clmul (A Bb : ℕ) : ℕ :=
  (A + 1) * (C_xorNat (A + Bb) + 60 * (A + Bb + 3) * (A + Bb + 3) + 200) + 40

/-- Space bound of `clmul`. -/
def S_clmul (A Bb : ℕ) : ℕ := S_xorNat (A + Bb) + 60 * (A + Bb) + 400

/-- Cost bound of `pmodDeg` (`2^d ≤ p < 2^(d+1)`, `a < 2^A`). -/
def C_pmodDeg (d A : ℕ) : ℕ :=
  C_sizeNat A + C_pow2 (d + A) + C_pow2 A +
    (A + 1) * (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 200) +
    60 * (d + A + 4) * (d + A + 4) + 300

/-- Space bound of `pmodDeg`. -/
def S_pmodDeg (d A : ℕ) : ℕ :=
  S_sizeNat A + S_pow2 (d + A) + S_xorNat (d + A + 1) + 60 * (d + A) + 400

/-- Cost bound of `gfMul` (`q`-bit field elements). -/
def C_gfMul (q : ℕ) : ℕ := C_clmul q q + C_pmodDeg q (2 * q) + 60 * (q + 3) * (q + 3) + 200

/-- Space bound of `gfMul`. -/
def S_gfMul (q : ℕ) : ℕ := S_clmul q q + S_pmodDeg q (2 * q) + 60 * q + 300

set_option linter.unusedSimpArgs false

/-! ### Lean-side facts about `clmul` -/

theorem clmul_zero_left (b : ℕ) : Hash.clmul 0 b = 0 := by
  rw [Hash.clmul]; simp

theorem clmul_two_mul_right (a b : ℕ) : Hash.clmul a (2 * b) = 2 * Hash.clmul a b := by
  apply Hash.toPoly_injective
  rw [Hash.toPoly_clmul, Hash.toPoly_two_mul, Hash.toPoly_two_mul, Hash.toPoly_clmul]
  ring

theorem clmul_step {a : ℕ} (ha : a ≠ 0) (b : ℕ) :
    Hash.clmul a b = (if a % 2 = 1 then b else 0) ^^^ Hash.clmul (a / 2) (2 * b) := by
  rw [Hash.clmul, if_neg ha, clmul_two_mul_right]

theorem clmul_lt {a b A B : ℕ} (ha : a < 2 ^ A) (hb : b < 2 ^ B) :
    Hash.clmul a b < 2 ^ (A + B) := by
  apply Hash.lt_two_pow_of_degree_toPoly_lt
  rw [Hash.toPoly_clmul, Polynomial.degree_lt_iff_coeff_zero]
  intro N hN
  rw [Polynomial.coeff_mul]
  apply Finset.sum_eq_zero
  intro x hx
  have hx := Finset.HasAntidiagonal.mem_antidiagonal.1 hx
  by_cases hi : A ≤ x.1
  · rw [Hash.coeff_toPoly', Hash.testBit_eq_false_of_lt_two_pow ha hi]
    simp
  · have hj : B ≤ x.2 := by omega
    rw [Hash.coeff_toPoly' b, Hash.testBit_eq_false_of_lt_two_pow hb hj]
    simp

/-! ### `clmul`: loop steps -/

theorem clmulStep_stop (prog : List Expr) (base : ℕ) (b r : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int b, Val.int r]] body_clmulStep
      (Val.list [Val.int 0, Val.int r]) 40
      (base + 4 * valSize (Val.list [Val.int 0, Val.int b, Val.int r]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_clmulStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eDiv, eMod, eMul,
    eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one] <;> omega

theorem clmulStep_even (prog : List Expr) (base : ℕ) (a b r : ℤ) (ha0 : a ≠ 0)
    (heven : ¬ a % 2 = 1) :
    EvalsLe prog base [Val.list [Val.int a, Val.int b, Val.int r]] body_clmulStep
      (Val.list [Val.int 1, Val.list [Val.int (a / 2), Val.int (b * 2), Val.int r]])
      (100 + 10 * bitLen a + 4 * bitLen b + bitLen r)
      (base + 4 * valSize (Val.list [Val.int a, Val.int b, Val.int r]) +
        3 * (bitLen (a / 2) + bitLen (b * 2) + bitLen r) + 60) := by
  have ha2 := bitLen_emod_two_le a
  apply EvalsLe.of_eval 20
  simp only [body_clmulStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eDiv, eMod, eMul,
    eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, ha0, heven, not_false_eq_true, ↓reduceIte,
    OfNat.ofNat_ne_zero, one_ne_zero, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two]
    omega

theorem clmulStep_odd {prog : List Expr} (hL : HashLib prog) (base a b r W : ℕ) (ha0 : a ≠ 0)
    (hodd : a % 2 = 1) (hbW : b < 2 ^ W) (hrW : r < 2 ^ W) :
    EvalsLe prog base [Val.list [Val.int a, Val.int b, Val.int r]] body_clmulStep
      (Val.list [Val.int 1, Val.list [Val.int ((a : ℤ) / 2), Val.int ((b : ℤ) * 2),
        Val.int ((r ^^^ b : ℕ) : ℤ)]])
      (C_xorNat W + 110 + 10 * bitLen (a : ℤ) + 4 * bitLen (b : ℤ) + bitLen (r : ℤ))
      (base + 4 * valSize (Val.list [Val.int a, Val.int b, Val.int r]) +
        3 * (bitLen ((a : ℤ) / 2) + bitLen ((b : ℤ) * 2) + bitLen (r : ℤ) + bitLen (b : ℤ) + W) +
        S_xorNat W + 100) := by
  obtain ⟨f, c, p, hc, hp, hu⟩ := uniform_of_spec (xorNat_spec hL.xorNatStep r b W hrW hbW 0)
  simp only [encN, zero_add] at hu hp
  have ha2 : (a : ℤ) % 2 = 1 := by exact_mod_cast hodd
  have ha0' : (a : ℤ) ≠ 0 := by exact_mod_cast ha0
  have hb2 := bitLen_emod_two_le (a : ℤ)
  have hx : bitLen ((r ^^^ b : ℕ) : ℤ) ≤ W := bitLen_nat_le_of_lt (Nat.xor_lt_two_pow hrW hbW)
  apply EvalsLe.of_eval (f + 30)
  simp only [body_clmulStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit,
      eDiv, eMod, eMul, eList, eCons, ePair, eCall,
      eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
      eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, ha0', ha2, not_false_eq_true,
      ↓reduceIte, OfNat.ofNat_ne_zero, one_ne_zero, not_true_eq_false, hL.xorNat]
  rw [hu _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, evalBin]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two]
    omega

/-! ### `clmul`: the loop -/

/-- Encoding of the `clmul` loop state `[a', b', r]` (the last component `i` is a ghost). -/
def encClmul (s : ℕ × ℕ × ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2.1 : ℤ), Val.int (s.2.2.1 : ℤ)]

theorem clmul_loop {prog : List Expr} (hL : HashLib prog) (a b A Bb base : ℕ) (ha : a < 2 ^ A)
    (hb : b < 2 ^ Bb) :
    ∀ s : ℕ × ℕ × ℕ × ℕ, (s.1 = a / 2 ^ s.2.2.2 ∧ s.2.1 = b * 2 ^ s.2.2.2 ∧
        s.2.2.1 ^^^ Hash.clmul s.1 s.2.1 = Hash.clmul a b ∧ s.2.2.2 ≤ A) →
      ∃ out, out = encN (Hash.clmul a b) ∧
        LoopLe prog base Idx.clmulStep (encClmul s) out
          ((A - s.2.2.2 + 1) *
            (C_xorNat (A + Bb) + 60 * (A + Bb + 3) * (A + Bb + 3) + 199 + 1))
          (base + S_clmul A Bb) := by
  refine LoopLe.of_measure hL.clmulStep encClmul _ _ (fun s => A - s.2.2.2)
    (C_xorNat (A + Bb) + 60 * (A + Bb + 3) * (A + Bb + 3) + 199) ?_
  rintro ⟨a', b', r, i⟩ ⟨ha', hb', hr, hi⟩
  simp only at ha' hb' hr hi
  have hpi : 0 < 2 ^ i := Nat.two_pow_pos i
  -- bit bounds
  have hAi : a' < 2 ^ (A - i) := by
    rw [ha', Nat.div_lt_iff_lt_mul hpi, ← pow_add, Nat.sub_add_cancel hi]
    exact ha
  have hb'W : b' < 2 ^ (Bb + i) := by
    rw [hb', pow_add]
    exact Nat.mul_lt_mul_of_pos_right hb hpi
  have hcl : Hash.clmul a' b' < 2 ^ (A + Bb) := by
    have := clmul_lt hAi hb'W
    rwa [show A - i + (Bb + i) = A + Bb by omega] at this
  have hrW : r < 2 ^ (A + Bb) := by
    have h1 : r = Hash.clmul a b ^^^ Hash.clmul a' b' := by
      rw [← hr, Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
    rw [h1]
    exact Nat.xor_lt_two_pow (clmul_lt ha hb) hcl
  have hWa : a' < 2 ^ (A + Bb) := lt_of_lt_of_le hAi (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hWb : b' < 2 ^ (A + Bb) :=
    lt_of_lt_of_le hb'W (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hba := bitLen_nat_le_of_lt hWa
  have hbb := bitLen_nat_le_of_lt hWb
  have hbr := bitLen_nat_le_of_lt hrW
  have hvs : valSize (encClmul (a', b', r, i)) ≤ 3 * (A + Bb) + 10 := by
    simp only [encClmul, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  by_cases h0 : a' = 0
  · -- stop
    left
    refine ⟨Val.int (r : ℤ), ?_, ?_⟩
    · have e : encClmul (a', b', r, i) =
          Val.list [Val.int 0, Val.int (b' : ℤ), Val.int (r : ℤ)] := by simp [encClmul, h0]
      rw [e] at hvs ⊢
      refine (clmulStep_stop prog _ _ _).mono (by omega) ?_
      simp only [S_clmul]
      omega
    · rw [h0, clmul_zero_left, Nat.xor_zero] at hr
      rw [hr]
      rfl
  · -- continue
    right
    have hiA : i < A := by
      by_contra hcon
      apply h0
      rw [ha']
      exact Nat.div_eq_of_lt (lt_of_lt_of_le ha (Nat.pow_le_pow_right (by norm_num) (by omega)))
    have hb'W2 : b' * 2 < 2 ^ (A + Bb) := by
      have : b' * 2 < 2 ^ (Bb + i + 1) := by rw [pow_succ]; omega
      exact lt_of_lt_of_le this (Nat.pow_le_pow_right (by norm_num) (by omega))
    set r' := if a' % 2 = 1 then r ^^^ b' else r with hr'def
    have hd1 : (a' : ℤ) / 2 = ((a' / 2 : ℕ) : ℤ) := by push_cast; rfl
    have hd2 : (b' : ℤ) * 2 = ((b' * 2 : ℕ) : ℤ) := by push_cast; rfl
    have hbd1 : bitLen ((a' : ℤ) / 2) ≤ A + Bb := by
      rw [hd1]; exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) hWa)
    have hbd2 : bitLen ((b' : ℤ) * 2) ≤ A + Bb := by
      rw [hd2]; exact bitLen_nat_le_of_lt hb'W2
    refine ⟨1, (a' / 2, b' * 2, r', i + 1), one_ne_zero, ?_, ⟨?_, ?_, ?_, ?_⟩, ?_⟩
    · by_cases hodd : a' % 2 = 1
      · have h1 := clmulStep_odd hL (base + valSize (encClmul (a', b', r, i))) a' b' r (A + Bb)
          h0 hodd hWb hrW
        have e : Val.list [Val.int ((a' : ℤ) / 2), Val.int ((b' : ℤ) * 2),
            Val.int ((r ^^^ b' : ℕ) : ℤ)] = encClmul (a' / 2, b' * 2, r', i + 1) := by
          simp only [encClmul, hr'def, if_pos hodd, hd1, hd2]
        rw [e] at h1
        refine h1.mono ?_ ?_
        · nlinarith
        · simp only [S_clmul]
          have hv : valSize (Val.list [Val.int (a' : ℤ), Val.int (b' : ℤ), Val.int (r : ℤ)]) =
              valSize (encClmul (a', b', r, i)) := rfl
          rw [hv]
          omega
      · have h1 := clmulStep_even prog (base + valSize (encClmul (a', b', r, i))) (a' : ℤ)
          (b' : ℤ) (r : ℤ) (by exact_mod_cast h0)
          (by intro h; apply hodd; exact_mod_cast h)
        have e : Val.list [Val.int ((a' : ℤ) / 2), Val.int ((b' : ℤ) * 2), Val.int (r : ℤ)] =
            encClmul (a' / 2, b' * 2, r', i + 1) := by
          simp only [encClmul, hr'def, if_neg hodd, hd1, hd2]
        rw [e] at h1
        refine h1.mono ?_ ?_
        · nlinarith
        · simp only [S_clmul]
          have hv : valSize (Val.list [Val.int (a' : ℤ), Val.int (b' : ℤ), Val.int (r : ℤ)]) =
              valSize (encClmul (a', b', r, i)) := rfl
          rw [hv]
          omega
    · simp only
      rw [ha', Nat.div_div_eq_div_mul, ← pow_succ]
    · simp only
      rw [hb', pow_succ, Nat.mul_assoc]
    · simp only
      rw [← hr, clmul_step h0, mul_comm b' 2, hr'def]
      by_cases hodd : a' % 2 = 1
      · rw [if_pos hodd, if_pos hodd, Nat.xor_assoc]
      · rw [if_neg hodd, if_neg hodd, Nat.zero_xor]
    · simp only
      omega
    · simp only
      omega

theorem clmul_spec_aux {prog : List Expr} (hL : HashLib prog) (a b A Bb : ℕ) (ha : a < 2 ^ A)
    (hb : b < 2 ^ Bb) (base : ℕ) :
    EvalsLe prog base [Val.list [encN a, encN b]] body_clmul (encN (Hash.clmul a b))
      (C_clmul A Bb) (base + S_clmul A Bb) := by
  obtain ⟨out, rfl, hloop⟩ := clmul_loop hL a b A Bb base ha hb (a, b, 0, 0)
    ⟨by simp, by simp, by simp [Nat.zero_xor], Nat.zero_le _⟩
  have hba := bitLen_nat_le_of_lt ha
  have hbb := bitLen_nat_le_of_lt hb
  have hinit : EvalsLe prog base [Val.list [encN a, encN b]]
      (eList [eHd (eV 0), eAt1 (eV 0), eLit 0]) (encClmul (a, b, 0, 0)) 30
      (base + 4 * valSize (Val.list [encN a, encN b]) + 20) := by
    apply EvalsLe.of_eval 20
    simp only [encClmul, encN, eList, eCons, eHd, eAt1, eTl, eV, eLit, eval_succ_var,
      eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, evalBin, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, Nat.cast_zero]
    refine ⟨_, _, rfl, ?_, ?_⟩ <;>
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
        bitLen_one] <;> omega
  have hsz : valSize (Val.list [encN a, encN b]) ≤ 2 * (A + Bb) + 5 := by
    simp only [encN, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  refine (EvalsLe.loop hinit hloop).mono ?_ ?_
  · simp only [C_clmul, Nat.sub_zero]
    nlinarith
  · simp only [S_clmul, max_le_iff]
    omega

/-! ### Monotonicity of the leaf bounds -/

theorem C_pow2_mono {m m' : ℕ} (h : m ≤ m') : C_pow2 m ≤ C_pow2 m' := by
  unfold C_pow2
  have := Nat.mul_le_mul (Nat.add_le_add_right h 1) (Nat.add_le_add_right (Nat.mul_le_mul_left 20 h) 120)
  omega

theorem S_pow2_mono {m m' : ℕ} (h : m ≤ m') : S_pow2 m ≤ S_pow2 m' := by
  unfold S_pow2; omega

/-! ### `pmodDeg`: loop steps -/

theorem pmodDegStep_stop (prog : List Expr) (base : ℕ) (a t pk : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int a, Val.int t, Val.int pk]] body_pmodDegStep
      (Val.list [Val.int 0, Val.int a]) (80 + 3 * bitLen t + 3 * bitLen pk)
      (base + 4 * valSize (Val.list [Val.int 0, Val.int a, Val.int t, Val.int pk]) +
        2 * bitLen (t / 2) + 2 * bitLen (pk / 2) + 40) := by
  apply EvalsLe.of_eval 20
  simp only [body_pmodDegStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eMod,
    eSub, eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte,
    OfNat.ofNat_ne_zero]
  refine ⟨_, _, rfl, ?_, ?_⟩ <;>
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two] <;> omega

theorem pmodDegStep_clear (prog : List Expr) (base k a t pk k' t' pk' : ℕ) (hk : k ≠ 0)
    (hk1 : (k : ℤ) - 1 = (k' : ℤ))
    (ht2 : (t : ℤ) / 2 = (t' : ℤ)) (hpk2 : (pk : ℤ) / 2 = (pk' : ℤ))
    (htz : (t' : ℤ) ≠ 0)
    (hclr : ¬ (a : ℤ) / (t' : ℤ) % 2 = 1) :
    EvalsLe prog base [Val.list [Val.int k, Val.int a, Val.int t, Val.int pk]] body_pmodDegStep
      (Val.list [Val.int 1, Val.list [Val.int (k' : ℤ), Val.int (a : ℤ),
        Val.int (t' : ℤ), Val.int (pk' : ℤ)]])
      (150 + 4 * bitLen (k : ℤ) + 4 * bitLen (t : ℤ) + 4 * bitLen (pk : ℤ) +
        (bitLen (a : ℤ) + 1) * (bitLen (t' : ℤ) + 1) +
        3 * bitLen ((a : ℤ) / (t' : ℤ)))
      (base + 4 * valSize (Val.list [Val.int k, Val.int a, Val.int t, Val.int pk]) +
        3 * (bitLen (t' : ℤ) + bitLen (pk' : ℤ) + bitLen (k' : ℤ) +
          bitLen (a : ℤ) + bitLen ((a : ℤ) / (t' : ℤ))) + 80) := by
  have hk' : (k : ℤ) ≠ 0 := by exact_mod_cast hk
  have hm2 := bitLen_emod_two_le ((a : ℤ) / (t' : ℤ))
  apply EvalsLe.of_eval 20
  simp only [body_pmodDegStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eMod,
    eSub, eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hk', htz, hclr, ht2, hpk2, hk1, not_false_eq_true,
    ↓reduceIte, OfNat.ofNat_ne_zero, one_ne_zero, not_true_eq_false]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two]
    omega

theorem pmodDegStep_set {prog : List Expr} (hL : HashLib prog) (base k a t pk k' t' pk' W : ℕ)
    (hk : k ≠ 0) (hk1 : (k : ℤ) - 1 = (k' : ℤ))
    (ht2 : (t : ℤ) / 2 = (t' : ℤ)) (hpk2 : (pk : ℤ) / 2 = (pk' : ℤ))
    (htz : (t' : ℤ) ≠ 0)
    (hset : (a : ℤ) / (t' : ℤ) % 2 = 1) (haW : a < 2 ^ W) (hpW : pk' < 2 ^ W) :
    EvalsLe prog base [Val.list [Val.int k, Val.int a, Val.int t, Val.int pk]] body_pmodDegStep
      (Val.list [Val.int 1, Val.list [Val.int (k' : ℤ), Val.int ((a ^^^ pk' : ℕ) : ℤ),
        Val.int (t' : ℤ), Val.int (pk' : ℤ)]])
      (C_xorNat W + 160 + 4 * bitLen (k : ℤ) + 4 * bitLen (t : ℤ) + 4 * bitLen (pk : ℤ) +
        (bitLen (a : ℤ) + 1) * (bitLen (t' : ℤ) + 1) +
        3 * bitLen ((a : ℤ) / (t' : ℤ)))
      (base + 4 * valSize (Val.list [Val.int k, Val.int a, Val.int t, Val.int pk]) +
        3 * (bitLen (t' : ℤ) + bitLen (pk' : ℤ) + bitLen (k' : ℤ) +
          bitLen (a : ℤ) + bitLen ((a : ℤ) / (t' : ℤ)) + W) + S_xorNat W + 100) := by
  obtain ⟨f, c, p, hc, hp, hu⟩ :=
    uniform_of_spec (xorNat_spec hL.xorNatStep a pk' W haW hpW 0)
  simp only [encN, zero_add] at hu hp
  have hk' : (k : ℤ) ≠ 0 := by exact_mod_cast hk
  have hm2 := bitLen_emod_two_le ((a : ℤ) / (t' : ℤ))
  have hx : bitLen ((a ^^^ pk' : ℕ) : ℤ) ≤ W :=
    bitLen_nat_le_of_lt (Nat.xor_lt_two_pow haW hpW)
  apply EvalsLe.of_eval (f + 30)
  simp only [body_pmodDegStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eDiv, eMod,
    eSub, eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk', htz, hset, ht2, hpk2, hk1,
    not_false_eq_true, ↓reduceIte, OfNat.ofNat_ne_zero, one_ne_zero, not_true_eq_false,
    hL.xorNat]
  rw [hu _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, evalBin]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one, bitLen_two]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one, bitLen_two]
    omega

/-! ### `pmodDeg`: the loop -/

/-- Encoding of the `pmodDeg` loop state `[k, a', 2^(d+k), 2^k p]`. -/
def encPmod (d p : ℕ) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int ((2 ^ (d + s.1) : ℕ) : ℤ),
    Val.int ((2 ^ s.1 * p : ℕ) : ℤ)]

theorem bitLen_natCast_div_two_le {n B : ℕ} (h : n < 2 ^ B) : bitLen ((n : ℤ) / 2) ≤ B := by
  have e : (n : ℤ) / 2 = ((n / 2 : ℕ) : ℤ) := (Int.natCast_ediv n 2).symm
  rw [e]
  exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) h)

theorem bitLen_natCast_div_le {n m B : ℕ} (h : n < 2 ^ B) : bitLen ((n : ℤ) / (m : ℤ)) ≤ B := by
  rw [← Int.natCast_ediv]
  exact bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.div_le_self _ _) h)

/-- One stopping iteration of the `pmodDeg` loop (`k = 0`). -/
theorem pmodDeg_iter_stop (prog : List Expr) (d p A base a' : ℕ) (hp2 : p < 2 ^ (d + 1))
    (ha' : a' < 2 ^ (d + 0)) :
    EvalsLe prog (base + valSize (encPmod d p (0, a'))) [encPmod d p (0, a')] body_pmodDegStep
      (Val.list [Val.int 0, Val.int (a' : ℤ)])
      (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 199)
      (base + (S_xorNat (d + A + 1) + 40 * (d + A) + 200)) := by
  have hpk : 2 ^ 0 * p < 2 ^ (d + A + 1) := by
    rw [pow_zero, one_mul]
    exact lt_of_lt_of_le hp2 (Nat.pow_le_pow_right (by norm_num) (by omega))
  have ht : 2 ^ (d + 0) < 2 ^ (d + A + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)
  have ha'W : a' < 2 ^ (d + A) :=
    lt_of_lt_of_le ha' (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hba := bitLen_nat_le_of_lt ha'W
  have hbt := bitLen_nat_le_of_lt ht
  have hbpk := bitLen_nat_le_of_lt hpk
  have h1 := bitLen_natCast_div_two_le ht
  have h2 := bitLen_natCast_div_two_le hpk
  have e : encPmod d p (0, a') = Val.list [Val.int 0, Val.int (a' : ℤ),
      Val.int ((2 ^ (d + 0) : ℕ) : ℤ), Val.int ((2 ^ 0 * p : ℕ) : ℤ)] := by
    simp only [encPmod, Nat.cast_zero]
  rw [e]
  have hvs : valSize (Val.list [Val.int 0, Val.int (a' : ℤ),
      Val.int ((2 ^ (d + 0) : ℕ) : ℤ), Val.int ((2 ^ 0 * p : ℕ) : ℤ)]) ≤ 3 * (d + A) + 11 := by
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero]
    omega
  have hsq : 60 * (d + A + 4) * (d + A + 4) = 60 * ((d + A + 4) * (d + A + 4)) := by ring
  have hX : 4 * (d + A + 4) ≤ (d + A + 4) * (d + A + 4) := Nat.mul_le_mul_right _ (by omega)
  refine (pmodDegStep_stop prog _ _ _ _).mono ?_ ?_
  · omega
  · omega

/-- One continuing iteration of the `pmodDeg` loop (`k = k' + 1`): one step of
`Hash.reduceTop`. -/
theorem pmodDeg_iter_cont {prog : List Expr} (hL : HashLib prog) (d p A base k' a' : ℕ)
    (hp2 : p < 2 ^ (d + 1)) (ha' : a' < 2 ^ (d + (k' + 1))) (hk : k' + 1 ≤ A) :
    EvalsLe prog (base + valSize (encPmod d p (k' + 1, a'))) [encPmod d p (k' + 1, a')]
      body_pmodDegStep
      (Val.list [Val.int 1,
        encPmod d p (k', if a'.testBit (d + k') then a' ^^^ (2 ^ k' * p) else a')])
      (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 199)
      (base + (S_xorNat (d + A + 1) + 40 * (d + A) + 200)) := by
  have hpk : 2 ^ (k' + 1) * p < 2 ^ (d + A + 1) := by
    calc 2 ^ (k' + 1) * p < 2 ^ (k' + 1) * 2 ^ (d + 1) :=
          Nat.mul_lt_mul_of_pos_left hp2 (Nat.two_pow_pos _)
      _ = 2 ^ (k' + 1 + (d + 1)) := (pow_add 2 (k' + 1) (d + 1)).symm
      _ ≤ 2 ^ (d + A + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have ht : 2 ^ (d + (k' + 1)) < 2 ^ (d + A + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)
  have ha'W : a' < 2 ^ (d + A) :=
    lt_of_lt_of_le ha' (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hbk : bitLen ((k' + 1 : ℕ) : ℤ) ≤ A := le_trans (bitLen_natCast_le _) hk
  have hba := bitLen_nat_le_of_lt ha'W
  have hbt := bitLen_nat_le_of_lt ht
  have hbpk := bitLen_nat_le_of_lt hpk
  have hvs : valSize (encPmod d p (k' + 1, a')) ≤ 4 * (d + A) + 11 := by
    simp only [encPmod, valSize_int, valSize_list, listSize_cons, listSize_nil]
    omega
  have ht' : 2 ^ (d + (k' + 1)) / 2 = 2 ^ (d + k') := by
    rw [← Nat.add_assoc, pow_succ, Nat.mul_div_cancel _ (by norm_num)]
  have hpk' : 2 ^ (k' + 1) * p / 2 = 2 ^ k' * p := by
    rw [pow_succ, Nat.mul_right_comm, Nat.mul_div_cancel _ (by norm_num)]
  have ht2 : ((2 ^ (d + (k' + 1)) : ℕ) : ℤ) / 2 = ((2 ^ (d + k') : ℕ) : ℤ) := by
    rw [← ht']
    exact (Int.natCast_ediv _ 2).symm
  have hpk2 : ((2 ^ (k' + 1) * p : ℕ) : ℤ) / 2 = ((2 ^ k' * p : ℕ) : ℤ) := by
    rw [← hpk']
    exact (Int.natCast_ediv _ 2).symm
  have hk1 : ((k' + 1 : ℕ) : ℤ) - 1 = (k' : ℤ) := by push_cast; ring
  have htz : ((2 ^ (d + k') : ℕ) : ℤ) ≠ 0 := by positivity
  have ht'A : 2 ^ (d + k') < 2 ^ (d + A) := Nat.pow_lt_pow_right (by norm_num) (by omega)
  have hpk'A : 2 ^ k' * p < 2 ^ (d + A) := by
    calc 2 ^ k' * p < 2 ^ k' * 2 ^ (d + 1) :=
          Nat.mul_lt_mul_of_pos_left hp2 (Nat.two_pow_pos k')
      _ = 2 ^ (k' + (d + 1)) := (pow_add 2 k' (d + 1)).symm
      _ ≤ 2 ^ (d + A) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hbt' := bitLen_nat_le_of_lt ht'A
  have hbpk' := bitLen_nat_le_of_lt hpk'A
  have hbk' : bitLen (k' : ℤ) ≤ A := le_trans (bitLen_natCast_le k') (by omega)
  have hdiv : bitLen ((a' : ℤ) / ((2 ^ (d + k') : ℕ) : ℤ)) ≤ d + A :=
    bitLen_natCast_div_le ha'W
  have hprod : (bitLen (a' : ℤ) + 1) * (bitLen ((2 ^ (d + k') : ℕ) : ℤ) + 1) ≤
      (d + A + 4) * (d + A + 4) := Nat.mul_le_mul (by omega) (by omega)
  have hsq : 60 * (d + A + 4) * (d + A + 4) = 60 * ((d + A + 4) * (d + A + 4)) := by ring
  have hX : 4 * (d + A + 4) ≤ (d + A + 4) * (d + A + 4) := Nat.mul_le_mul_right _ (by omega)
  have e1 : encPmod d p (k' + 1, a') = Val.list [Val.int ((k' + 1 : ℕ) : ℤ), Val.int (a' : ℤ),
      Val.int ((2 ^ (d + (k' + 1)) : ℕ) : ℤ), Val.int ((2 ^ (k' + 1) * p : ℕ) : ℤ)] := rfl
  by_cases hb : a'.testBit (d + k')
  · rw [if_pos hb]
    have hb' : a' / 2 ^ (d + k') % 2 = 1 := by
      have := (Nat.testBit_eq_decide_div_mod_eq (x := a') (i := d + k')).symm.trans hb
      exact of_decide_eq_true this
    have hset : (a' : ℤ) / ((2 ^ (d + k') : ℕ) : ℤ) % 2 = 1 := by exact_mod_cast hb'
    have h1 := pmodDegStep_set hL (base + valSize (encPmod d p (k' + 1, a'))) (k' + 1) a'
      (2 ^ (d + (k' + 1))) (2 ^ (k' + 1) * p) k' (2 ^ (d + k')) (2 ^ k' * p) (d + A + 1)
      (Nat.succ_ne_zero k') hk1 ht2 hpk2 htz hset
      (lt_of_lt_of_le ha'W (Nat.pow_le_pow_right (by norm_num) (by omega)))
      (lt_of_lt_of_le hpk'A (Nat.pow_le_pow_right (by norm_num) (by omega)))
    have e2 : Val.list [Val.int (k' : ℤ), Val.int ((a' ^^^ (2 ^ k' * p) : ℕ) : ℤ),
        Val.int ((2 ^ (d + k') : ℕ) : ℤ), Val.int ((2 ^ k' * p : ℕ) : ℤ)] =
        encPmod d p (k', a' ^^^ (2 ^ k' * p)) := rfl
    rw [← e1, e2] at h1
    refine h1.mono ?_ ?_
    · omega
    · omega
  · rw [if_neg hb]
    have hb' : ¬ a' / 2 ^ (d + k') % 2 = 1 := by
      intro h
      apply hb
      rw [Nat.testBit_eq_decide_div_mod_eq]
      exact decide_eq_true h
    have hclr : ¬ (a' : ℤ) / ((2 ^ (d + k') : ℕ) : ℤ) % 2 = 1 := by exact_mod_cast hb'
    have h1 := pmodDegStep_clear prog (base + valSize (encPmod d p (k' + 1, a'))) (k' + 1) a'
      (2 ^ (d + (k' + 1))) (2 ^ (k' + 1) * p) k' (2 ^ (d + k')) (2 ^ k' * p)
      (Nat.succ_ne_zero k') hk1 ht2 hpk2 htz hclr
    have e2 : Val.list [Val.int (k' : ℤ), Val.int (a' : ℤ),
        Val.int ((2 ^ (d + k') : ℕ) : ℤ), Val.int ((2 ^ k' * p : ℕ) : ℤ)] =
        encPmod d p (k', a') := rfl
    rw [← e1, e2] at h1
    refine h1.mono ?_ ?_
    · omega
    · omega

theorem pmodDeg_loop {prog : List Expr} (hL : HashLib prog) (d p a A base : ℕ)
    (hp1 : 2 ^ d ≤ p) (hp2 : p < 2 ^ (d + 1)) :
    ∀ s : ℕ × ℕ, (Hash.reduceTop d p s.1 s.2 = Hash.pmodDeg d p a ∧ s.2 < 2 ^ (d + s.1) ∧
        s.1 ≤ A) →
      ∃ out, out = encN (Hash.pmodDeg d p a) ∧
        LoopLe prog base Idx.pmodDegStep (encPmod d p s) out
          ((s.1 + 1) * (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 199 + 1))
          (base + (S_xorNat (d + A + 1) + 40 * (d + A) + 200)) := by
  refine LoopLe.of_measure hL.pmodDegStep (encPmod d p) _ _ (fun s => s.1)
    (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 199) ?_
  rintro ⟨k, a'⟩ ⟨hred, ha', hk⟩
  simp only at hred ha' hk
  rcases k with _ | k'
  · left
    refine ⟨Val.int (a' : ℤ), pmodDeg_iter_stop prog d p A base a' hp2 ha', ?_⟩
    rw [← hred]
    rfl
  · right
    have ha'' : a' < 2 ^ (d + k' + 1) := by rwa [Nat.add_assoc]
    obtain ⟨hlt, -⟩ := Hash.reduce_step (k := k') hp1 hp2 ha''
    refine ⟨1, (k', if a'.testBit (d + k') then a' ^^^ (2 ^ k' * p) else a'), one_ne_zero,
      pmodDeg_iter_cont hL d p A base k' a' hp2 ha' hk, ⟨?_, hlt, Nat.le_of_succ_le hk⟩,
      Nat.lt_succ_self k'⟩
    rw [← hred]
    rfl

/-! ### `pmodDeg`: the body -/

/-- The truncated difference `K = x ∸ y` as computed by `pmodDeg`'s `ite`. -/
theorem truncSub_evals (prog : List Expr) (base x y : ℕ) (v1 v2 : Val) (rest : List Val) :
    EvalsLe prog base (encN x :: v1 :: v2 :: encN y :: rest)
      (eIte (eLt (eV 0) (eV 3)) (eLit 0) (eSub (eV 0) (eV 3))) (encN (x - y))
      (10 + 2 * bitLen (x : ℤ) + 2 * bitLen (y : ℤ))
      (base + 2 * valSize (encN x) + valSize (encN y) + 2) := by
  rcases Nat.lt_or_ge x y with h | h
  · have h' : (x : ℤ) < (y : ℤ) := by exact_mod_cast h
    have e : x - y = 0 := by omega
    rw [e]
    apply EvalsLe.of_eval 10
    simp only [encN, eIte, eLt, eV, eLit, eSub, eval_succ_var, eval_succ_lit, eval_succ_bin,
      eval_succ_ite, evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, h', ↓reduceIte, ne_eq, one_ne_zero, not_false_eq_true,
      Nat.cast_zero]
    refine ⟨_, _, rfl, ?_, ?_⟩
    · simp only [bitLen_zero]
      omega
    · simp only [valSize_int, max_le_iff, bitLen_zero, bitLen_one]
      omega
  · have h' : ¬ (x : ℤ) < (y : ℤ) := by exact_mod_cast Nat.not_lt.2 h
    have hs : (x : ℤ) - (y : ℤ) = ((x - y : ℕ) : ℤ) := (Nat.cast_sub h).symm
    have hb : bitLen ((x - y : ℕ) : ℤ) ≤ bitLen (x : ℤ) := bitLen_mono_nat (Nat.sub_le x y)
    apply EvalsLe.of_eval 10
    simp only [encN, eIte, eLt, eV, eLit, eSub, eval_succ_var, eval_succ_lit, eval_succ_bin,
      eval_succ_ite, evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, h', hs, ↓reduceIte, ne_eq, not_true_eq_false]
    refine ⟨_, _, rfl, ?_, ?_⟩
    · omega
    · simp only [valSize_int, max_le_iff, bitLen_zero, bitLen_one]
      omega

set_option maxHeartbeats 1000000 in
theorem pmodDeg_spec_aux {prog : List Expr} (hL : HashLib prog) (d p a A : ℕ) (hp1 : 2 ^ d ≤ p)
    (hp2 : p < 2 ^ (d + 1)) (ha : a < 2 ^ A) (base : ℕ) :
    EvalsLe prog base [Val.list [encN d, encN p, encN a]] body_pmodDeg (encN (Hash.pmodDeg d p a))
      (C_pmodDeg d A) (base + S_pmodDeg d A) := by
  have hszA : Nat.size a ≤ A := Nat.size_le.2 ha
  have hKA : Nat.size a - d ≤ A := by omega
  have haK : a < 2 ^ (d + (Nat.size a - d)) :=
    lt_of_lt_of_le (Nat.lt_size_self a) (Nat.pow_le_pow_right (by norm_num) (by omega))
  obtain ⟨f1, c1, q1, hc1, hq1, hu1⟩ := uniform_of_spec (sizeNat_spec hL.sizeNatStep a A ha 0)
  obtain ⟨f5, c5, q5, hc5, hq5, hu5⟩ := uniform_of_spec (truncSub_evals prog 0 (Nat.size a) d
    (encN a) (encN p) [Val.list [encN d, encN p, encN a]])
  obtain ⟨f2, c2, q2, hc2, hq2, hu2⟩ :=
    uniform_of_spec (pow2_spec hL.pow2Step (d + (Nat.size a - d)) 0)
  obtain ⟨f3, c3, q3, hc3, hq3, hu3⟩ := uniform_of_spec (pow2_spec hL.pow2Step (Nat.size a - d) 0)
  obtain ⟨out, hout, hloop⟩ := pmodDeg_loop hL d p a A 0 hp1 hp2 (Nat.size a - d, a)
    ⟨rfl, haK, hKA⟩
  obtain ⟨f4, c4, q4, hc4, hq4, hu4⟩ := uniform_of_loop hloop
  subst hout
  simp only [encN, zero_add] at hu1 hu2 hu3 hu5 hq1 hq2 hq3 hq4 hq5
  simp only [valSize_int] at hq5
  simp only [encPmod] at hu4
  simp only [eIte, eLt, eV, eLit, eSub] at hu5
  have hdK : (d : ℤ) + ((Nat.size a - d : ℕ) : ℤ) = ((d + (Nat.size a - d) : ℕ) : ℤ) :=
    (Nat.cast_add _ _).symm
  have hmulc : ((2 ^ (Nat.size a - d) : ℕ) : ℤ) * (p : ℤ) =
      ((2 ^ (Nat.size a - d) * p : ℕ) : ℤ) := (Nat.cast_mul _ _).symm
  -- bit-length bounds
  have hbd : bitLen (d : ℤ) ≤ d := bitLen_natCast_le d
  have hbp : bitLen (p : ℤ) ≤ d + 1 := bitLen_nat_le_of_lt hp2
  have hba : bitLen (a : ℤ) ≤ A := bitLen_nat_le_of_lt ha
  have hbsz : bitLen ((Nat.size a : ℕ) : ℤ) ≤ A := le_trans (bitLen_natCast_le _) hszA
  have hbK : bitLen ((Nat.size a - d : ℕ) : ℤ) ≤ A := le_trans (bitLen_natCast_le _) hKA
  have hbdK : bitLen ((d + (Nat.size a - d) : ℕ) : ℤ) ≤ d + A :=
    le_trans (bitLen_natCast_le _) (by omega)
  have hb2dK : bitLen ((2 ^ (d + (Nat.size a - d)) : ℕ) : ℤ) ≤ d + A + 1 :=
    bitLen_nat_le_of_lt (Nat.pow_lt_pow_right (by norm_num) (by omega))
  have hb2K : bitLen ((2 ^ (Nat.size a - d) : ℕ) : ℤ) ≤ A + 1 :=
    bitLen_nat_le_of_lt (Nat.pow_lt_pow_right (by norm_num) (by omega))
  have hb2Kp : bitLen ((2 ^ (Nat.size a - d) * p : ℕ) : ℤ) ≤ d + A + 1 := by
    apply bitLen_nat_le_of_lt
    calc 2 ^ (Nat.size a - d) * p < 2 ^ (Nat.size a - d) * 2 ^ (d + 1) :=
          Nat.mul_lt_mul_of_pos_left hp2 (Nat.two_pow_pos _)
      _ = 2 ^ (Nat.size a - d + (d + 1)) := (pow_add 2 _ (d + 1)).symm
      _ ≤ 2 ^ (d + A + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hmb : (bitLen ((2 ^ (Nat.size a - d) : ℕ) : ℤ) + 1) * (bitLen (p : ℤ) + 1) ≤
      (d + A + 4) * (d + A + 4) := Nat.mul_le_mul (by omega) (by omega)
  have hsq : 60 * (d + A + 4) * (d + A + 4) = 60 * ((d + A + 4) * (d + A + 4)) := by ring
  have hX : 4 * (d + A + 4) ≤ (d + A + 4) * (d + A + 4) := Nat.mul_le_mul_right _ (by omega)
  have hc2' : c2 ≤ C_pow2 (d + A) := le_trans hc2 (C_pow2_mono (by omega))
  have hc3' : c3 ≤ C_pow2 A := le_trans hc3 (C_pow2_mono hKA)
  have hq2' : q2 ≤ S_pow2 (d + A) := le_trans hq2 (S_pow2_mono (by omega))
  have hq3' : q3 ≤ S_pow2 (d + A) := le_trans hq3 (S_pow2_mono (by omega))
  have hc4' : c4 ≤ (A + 1) * (C_xorNat (d + A + 1) + 60 * (d + A + 4) * (d + A + 4) + 200) :=
    le_trans hc4 (Nat.mul_le_mul (by omega) (by omega))
  apply EvalsLe.of_eval (f1 + f2 + f3 + f4 + f5 + 40)
  simp only [body_pmodDeg, eLet, eHd, eAt1, eAt2, eTl, eV, eLit, eAdd, eMul, eList, eCons, eCall,
    eLoop, eIte, eLt, eSub, encN,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
    eval_succ_letE, eval_succ_call, eval_succ_loop, evalBin, evalUn, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, hL.sizeNat, hL.pow2]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  rw [hu5 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_bin, eval_succ_call,
    evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ, hdK, hL.pow2]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_bin, eval_succ_call,
    evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ, hL.pow2]
  rw [hu3 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_bin, eval_succ_nil,
    evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ, hmulc]
  rw [hu4 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [C_pmodDeg]
    omega
  · simp only [S_pmodDeg, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega

theorem gfMul_spec_aux {prog : List Expr} (hL : HashLib prog) (q p x y : ℕ) (hp1 : 2 ^ q ≤ p)
    (hp2 : p < 2 ^ (q + 1)) (hx : x < 2 ^ q) (hy : y < 2 ^ q) (base : ℕ) :
    EvalsLe prog base [Val.list [encN q, encN p, encN x, encN y]] body_gfMul
      (encN (Hash.gfMul q p x y)) (C_gfMul q) (base + S_gfMul q) := by
  have hcl : Hash.clmul x y < 2 ^ (2 * q) := by
    have := clmul_lt hx hy
    rwa [← two_mul] at this
  obtain ⟨f1, c1, q1, hc1, hq1, hu1⟩ := uniform_of_spec (clmul_spec_aux hL x y q q hx hy 0)
  obtain ⟨f2, c2, q2, hc2, hq2, hu2⟩ :=
    uniform_of_spec (pmodDeg_spec_aux hL q p (Hash.clmul x y) (2 * q) hp1 hp2 hcl 0)
  simp only [encN, zero_add] at hu1 hu2 hq1 hq2
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  have hbp : bitLen (p : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hp2
  have hbx : bitLen (x : ℤ) ≤ q := bitLen_nat_le_of_lt hx
  have hby : bitLen (y : ℤ) ≤ q := bitLen_nat_le_of_lt hy
  have hbc : bitLen ((Hash.clmul x y : ℕ) : ℤ) ≤ 2 * q := bitLen_nat_le_of_lt hcl
  rw [show Hash.gfMul q p x y = Hash.pmodDeg q p (Hash.clmul x y) from rfl]
  apply EvalsLe.of_eval (f1 + f2 + 30)
  simp only [body_gfMul, eLet, eHd, eAt1, eAt2, eAt3, eTl, eV, eList, eCons, ePair, eCall, encN,
    eval_succ_var, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_letE, eval_succ_call,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, hL.clmul, hL.pmodDeg]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_nil, eval_succ_bin,
    eval_succ_un, evalBin, evalUn, List.getElem?_cons_zero, List.getElem?_cons_succ]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [C_gfMul]
    omega
  · simp only [S_gfMul, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega


section specs

variable {prog : List Expr}

/-- **Spec of `clmul`.** -/
theorem clmul_spec (hL : HashLib prog) (a b A Bb : ℕ) (ha : a < 2 ^ A) (hb : b < 2 ^ Bb)
    (base : ℕ) :
    EvalsLe prog base [Val.list [encN a, encN b]] body_clmul (encN (Hash.clmul a b))
      (C_clmul A Bb) (base + S_clmul A Bb) := by
  exact clmul_spec_aux hL a b A Bb ha hb base

/-- **Spec of `call Idx.clmul`.** -/
theorem clmul_call (hL : HashLib prog) {base : ℕ} {env : List Val} {e : Expr}
    {a b A Bb : ℕ} (ha : a < 2 ^ A) (hb : b < 2 ^ Bb) {Ce Se : ℕ}
    (he : EvalsLe prog base env e (Val.list [encN a, encN b]) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.clmul e) (encN (Hash.clmul a b)) (1 + Ce + C_clmul A Bb)
      (max Se (base + valSize (Val.list [encN a, encN b]) + S_clmul A Bb)) :=
  EvalsLe.call he hL.clmul (clmul_spec hL a b A Bb ha hb _)

/-- **Spec of `pmodDeg`.** -/
theorem pmodDeg_spec (hL : HashLib prog) (d p a A : ℕ) (hp1 : 2 ^ d ≤ p) (hp2 : p < 2 ^ (d + 1))
    (ha : a < 2 ^ A) (base : ℕ) :
    EvalsLe prog base [Val.list [encN d, encN p, encN a]] body_pmodDeg (encN (Hash.pmodDeg d p a))
      (C_pmodDeg d A) (base + S_pmodDeg d A) := by
  exact pmodDeg_spec_aux hL d p a A hp1 hp2 ha base

/-- **Spec of `call Idx.pmodDeg`.** -/
theorem pmodDeg_call (hL : HashLib prog) {base : ℕ} {env : List Val} {e : Expr}
    {d p a A : ℕ} (hp1 : 2 ^ d ≤ p) (hp2 : p < 2 ^ (d + 1)) (ha : a < 2 ^ A) {Ce Se : ℕ}
    (he : EvalsLe prog base env e (Val.list [encN d, encN p, encN a]) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.pmodDeg e) (encN (Hash.pmodDeg d p a))
      (1 + Ce + C_pmodDeg d A)
      (max Se (base + valSize (Val.list [encN d, encN p, encN a]) + S_pmodDeg d A)) :=
  EvalsLe.call he hL.pmodDeg (pmodDeg_spec hL d p a A hp1 hp2 ha _)

/-- **Spec of `gfMul`.** -/
theorem gfMul_spec (hL : HashLib prog) (q p x y : ℕ) (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1))
    (hx : x < 2 ^ q) (hy : y < 2 ^ q) (base : ℕ) :
    EvalsLe prog base [Val.list [encN q, encN p, encN x, encN y]] body_gfMul
      (encN (Hash.gfMul q p x y)) (C_gfMul q) (base + S_gfMul q) := by
  exact gfMul_spec_aux hL q p x y hp1 hp2 hx hy base

/-- **Spec of `call Idx.gfMul`.** -/
theorem gfMul_call (hL : HashLib prog) {base : ℕ} {env : List Val} {e : Expr}
    {q p x y : ℕ} (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1)) (hx : x < 2 ^ q) (hy : y < 2 ^ q)
    {Ce Se : ℕ} (he : EvalsLe prog base env e (Val.list [encN q, encN p, encN x, encN y]) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.gfMul e) (encN (Hash.gfMul q p x y)) (1 + Ce + C_gfMul q)
      (max Se (base + valSize (Val.list [encN q, encN p, encN x, encN y]) + S_gfMul q)) :=
  EvalsLe.call he hL.gfMul (gfMul_spec hL q p x y hp1 hp2 hx hy _)

end specs

end F2e2e.Cost.HashDSL
