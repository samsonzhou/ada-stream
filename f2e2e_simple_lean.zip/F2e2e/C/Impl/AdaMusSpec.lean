import F2e2e.C.Impl.AdaMusDefs

/-!
# ADA module (W4): the integer predictions represent `adaMus` (pure mathematics)

Owner: A-ARCH (a99d156c), for W4 (cc77ceaa). Statements fixed by W4 (copies of the frozen interface of
`F2e2e/C/Impl/AdaMus.lean`, renamed):
* `musZ_spec_proof`: for every block `j ≤ p`, the integer pair `musZ … j = (num, den)` has `den > 0` and
  `num/den = μ_j = (adaMus A st vals)[j]`: for a learned block via the exact water level (`wlLevel_spec`,
  `predLearned_eq`), for the anchor via `predAnchor_eq`;
* `musZ_bits_proof`: every numerator and denominator has at most `2^6 (adaZ A + 16)` bits (the level's
  denominator is `cd` or `k cd` with `k ≤ n`; the numerator is a sum of `≤ n` clipped terms `≤ 8 cd D 2^{qA}`).

All helper lemmas are `private` (to avoid clashes with same-named lemmas elsewhere in `F2e2e.C.Impl`);
only `musZ_spec_proof` and `musZ_bits_proof` are exported.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## Indexing -/

private theorem musZ_getD {A : AdaParams} {scores : List (List ℤ)} {vals : List (List ℕ)} {j : ℕ}
    (hj : j < A.p + 1) :
    (musZ A scores vals).getD j (0, 1) =
      if j < A.p then muLZ A (scores.getD j []) (vals.getD j []) else muAZ A (vals.getD j []) := by
  unfold musZ
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj]
  rfl

private theorem adaMus_getD {A : AdaParams} {st : AdaState} {vals : List (List ℕ)} {j : ℕ}
    (hj : j < A.p + 1) :
    (adaMus A st vals).getD j 0 =
      if j < A.p then predLearned A.hA (st.weights.getD j []) (blockVals A vals j)
      else predAnchor A.hA (A.blockSizes.getD j 0) (blockVals A vals j) := by
  unfold adaMus
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj]
  rfl

private theorem mem_getD_vals {vals : List (List ℕ)} {j x : ℕ} (hx : x ∈ vals.getD j []) :
    ∃ blk ∈ vals, x ∈ blk := by
  by_cases h : j < vals.length
  · rw [List.getD_eq_getElem _ _ h] at hx
    exact ⟨_, List.getElem_mem h, hx⟩
  · rw [List.getD_eq_default _ _ (not_lt.mp h)] at hx
    simp at hx

private theorem getD_vals_le {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) {j x : ℕ}
    (hx : x ∈ vals.getD j []) : x ≤ 2 ^ A.qA := by
  obtain ⟨blk, hb, hxb⟩ := mem_getD_vals hx
  exact hv.2 blk hb x hxb

private theorem blockVals_eq {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) (j : ℕ) :
    blockVals A vals j = vals.getD j [] := by
  unfold blockVals
  conv_rhs => rw [← List.map_id (vals.getD j [])]
  apply List.map_congr_left
  intro x hx
  exact min_eq_left (getD_vals_le hv hx)

private theorem length_vals_getD {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) (j : ℕ) :
    (vals.getD j []).length = A.blockSizes.getD j 0 := by
  rw [← hv.1, List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_map]
  cases vals[j]? <;> rfl

private theorem weights_getD {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {j : ℕ} (hj : j < A.p) :
    st.weights.getD j [] = capWeightsQ (scoreScale A) (st.scores.getD j []) := by
  have hj' : j < st.scores.length := hok.scores_len ▸ hj
  have hj'' : j < (st.scores.map (capWeightsQ (scoreScale A))).length := by
    rw [List.length_map]
    exact hj'
  rw [hok.weights, List.getD_eq_getElem _ _ hj'', List.getElem_map, List.getD_eq_getElem _ _ hj']

private theorem scoreScale_num_div_den (A : AdaParams) :
    ((scoreScale A).num : ℚ) / (((scoreScale A).den : ℤ) : ℚ) = scoreScale A := by
  rw [Int.cast_natCast]
  exact Rat.num_div_den _

/-! ## The predictions -/

/-- **The integer predictions represent `adaMus`** (positive denominators). -/
theorem musZ_spec_proof {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) :
    ∀ j, j < A.p + 1 → 0 < ((musZ A st.scores vals).getD j (0, 1)).2 ∧
      ((((musZ A st.scores vals).getD j (0, 1)).1 : ℚ) /
        ((musZ A st.scores vals).getD j (0, 1)).2) = (adaMus A st vals).getD j 0 := by
  intro j hj
  rw [musZ_getD hj, adaMus_getD hj, blockVals_eq hv]
  have hcd : (0 : ℤ) < ((scoreScale A).den : ℤ) := by exact_mod_cast (scoreScale A).den_pos
  by_cases hjp : j < A.p
  · rw [if_pos hjp, if_pos hjp, weights_getD hok hjp]
    have hglen : (st.scores.getD j []).length = A.blockSizes.getD j 0 := hok.scores_blk j hjp
    have hgpos : 0 < (st.scores.getD j []).length := hglen ▸ hpos j hjp.le
    have hgne : st.scores.getD j [] ≠ [] := List.ne_nil_of_length_pos hgpos
    obtain ⟨N, D, hL, hD, hmass⟩ := wlLevel_spec (cn := (scoreScale A).num) hcd hgne
    have hmu : muLZ A (st.scores.getD j []) (vals.getD j []) =
        (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j []) (vals.getD j []),
          2 ^ A.qA * ((st.scores.getD j []).length : ℤ) * ((scoreScale A).den : ℤ) * D) := by
      unfold muLZ
      rw [hL]
    rw [hmu]
    refine ⟨mul_pos (mul_pos (mul_pos (pow_pos two_pos _) (by exact_mod_cast hgpos)) hcd) hD, ?_⟩
    have h := predLearned_eq hcd hgne hD hmass A.qA (vals.getD j [])
    rw [scoreScale_num_div_den] at h
    have hhA : A.hA = (1 / 2) ^ A.qA := rfl
    rw [hhA, h]
    push_cast
    ring
  · rw [if_neg hjp, if_neg hjp]
    have hvlen : (vals.getD j []).length = A.blockSizes.getD j 0 := length_vals_getD hv j
    have hvpos : 0 < (vals.getD j []).length := hvlen ▸ hpos j (by omega)
    have hhA : A.hA = (1 / 2) ^ A.qA := rfl
    unfold muAZ
    refine ⟨mul_pos (pow_pos two_pos _) (by exact_mod_cast hvpos), ?_⟩
    rw [hhA, predAnchor_eq, ← hvlen]
    push_cast
    ring

/-! ## Bit lengths -/

private theorem bitLen_two_pow (k : ℕ) : bitLen ((2 : ℤ) ^ k) = k + 1 := by
  unfold bitLen
  rw [Int.natAbs_pow]
  exact Nat.size_pow

private theorem wlFK_snd_le (cn cd : ℤ) (g : List ℤ) (B : ℤ) : (wlFK cn cd g B).2 ≤ g.length := by
  rw [wlFK_snd]
  have h := List.sum_le_card_nsmul
    (g.map fun x => if wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x then (1 : ℤ) else 0) 1
    (fun y hy => by
      obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
      split_ifs <;> norm_num)
  rw [List.length_map, nsmul_eq_mul, mul_one] at h
  exact h

/-- The level's denominator: `0 < D ≤ n cd`. -/
private theorem wlLevel_D_le {cn cd : ℤ} (hcd : 0 < cd) {g : List ℤ} {N D : ℤ}
    (h : wlLevel cn cd g = some (N, D)) : 0 < D ∧ D ≤ (g.length : ℤ) * cd := by
  have hgne : g ≠ [] := by
    rintro rfl
    simp [wlLevel, foldP] at h
  have hglen : (1 : ℤ) ≤ g.length := by exact_mod_cast List.length_pos_iff.mpr hgne
  obtain ⟨B, hB⟩ := foldP_wlStep_mem cn cd g g (N, D) h
  unfold wlTry at hB
  split_ifs at hB with h1 h2
  · simp only [Option.some.injEq, Prod.mk.injEq] at hB
    obtain ⟨-, rfl⟩ := hB
    exact ⟨hcd, by nlinarith⟩
  · simp only [Option.some.injEq, Prod.mk.injEq] at hB
    obtain ⟨-, rfl⟩ := hB
    have hk0 := wlFK_snd_nonneg cn cd g B
    have hk1 := wlFK_snd_le cn cd g B
    exact ⟨mul_pos (lt_of_le_of_ne hk0 (Ne.symm h2.1)) hcd, by nlinarith⟩

/-- The numerator of a learned prediction: `0 ≤ predNum ≤ n · 8 cd D Q` for values `≤ Q`. -/
private theorem predNum_nonneg_le {cn cd N D Q : ℤ} (hcd : 0 ≤ cd) (hD : 0 ≤ D) (hQ : 0 ≤ Q) :
    ∀ (g : List ℤ) (v : List ℕ), (∀ x ∈ v, (x : ℤ) ≤ Q) →
      0 ≤ predNum cn cd N D g v ∧ predNum cn cd N D g v ≤ (g.length : ℤ) * (8 * cd * D * Q)
  | [], v, _ => by simp [predNum]
  | x :: xs, [], _ => by
      simp only [predNum, List.zipWith_nil_right, List.sum_nil, le_refl, true_and]
      exact mul_nonneg (Nat.cast_nonneg _)
        (mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) hcd) hD) hQ)
  | x :: xs, vi :: vs, hv => by
      obtain ⟨ih0, ih1⟩ := predNum_nonneg_le hcd hD hQ xs vs
        (fun y hy => hv y (List.mem_cons_of_mem _ hy))
      have hvi : (vi : ℤ) ≤ Q := hv vi List.mem_cons_self
      have hvi0 : (0 : ℤ) ≤ vi := Nat.cast_nonneg _
      have h8 : (0 : ℤ) ≤ 8 * cd * D := mul_nonneg (mul_nonneg (by norm_num) hcd) hD
      have hc0 := clipZ_nonneg (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) h8
      have hc1 := clipZ_le (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) h8
      have hpn : predNum cn cd N D (x :: xs) (vi :: vs) =
          clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (vi : ℤ) + predNum cn cd N D xs vs := by
        simp only [predNum, List.zipWith_cons_cons, List.sum_cons]
      rw [hpn]
      have hterm : clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (vi : ℤ) ≤ 8 * cd * D * Q :=
        mul_le_mul hc1 hvi hvi0 h8
      refine ⟨add_nonneg (mul_nonneg hc0 hvi0) ih0, ?_⟩
      have e : (((x :: xs).length : ℕ) : ℤ) * (8 * cd * D * Q) =
          (xs.length : ℤ) * (8 * cd * D * Q) + 8 * cd * D * Q := by
        simp only [List.length_cons]
        push_cast
        ring
      rw [e]
      linarith

private theorem muAZ_bits {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) (j : ℕ) :
    bitLen (muAZ A (vals.getD j [])).1 ≤ 2 ^ 6 * (adaZ A + 16) ∧
      bitLen (muAZ A (vals.getD j [])).2 ≤ 2 ^ 6 * (adaZ A + 16) := by
  have hlen : (vals.getD j []).length ≤ A.N := by
    rw [length_vals_getD hv]
    exact getD_le_sum _ _
  have hsN : Nat.size (vals.getD j []).length ≤ adaZ A :=
    (Nat.size_le_size hlen).trans (size_N_le_adaZ (A := A))
  have hq := qA_le_adaZ (A := A)
  have hsum0 : 0 ≤ ((vals.getD j []).map fun x : ℕ => (x : ℤ)).sum :=
    List.sum_nonneg (fun y hy => by
      obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
      exact Nat.cast_nonneg _)
  have hsum : ((vals.getD j []).map fun x : ℕ => (x : ℤ)).sum ≤
      ((vals.getD j []).length : ℤ) * 2 ^ A.qA := by
    have h := List.sum_le_card_nsmul ((vals.getD j []).map fun x : ℕ => (x : ℤ)) (2 ^ A.qA)
      (fun y hy => by
        obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
        exact_mod_cast getD_vals_le hv hx)
    rw [List.length_map, nsmul_eq_mul] at h
    exact h
  unfold muAZ
  constructor
  · calc bitLen ((vals.getD j []).map fun x : ℕ => (x : ℤ)).sum
        ≤ bitLen (((vals.getD j []).length : ℤ) * 2 ^ A.qA) := bitLen_le_of_nonneg_le hsum0 hsum
      _ ≤ bitLen ((vals.getD j []).length : ℤ) + bitLen ((2 : ℤ) ^ A.qA) := bitLen_mul_le _ _
      _ = Nat.size (vals.getD j []).length + (A.qA + 1) := by rw [bitLen_natCast, bitLen_two_pow]
      _ ≤ 2 ^ 6 * (adaZ A + 16) := by omega
  · calc bitLen (2 ^ A.qA * ((vals.getD j []).length : ℤ))
        ≤ bitLen ((2 : ℤ) ^ A.qA) + bitLen ((vals.getD j []).length : ℤ) := bitLen_mul_le _ _
      _ = (A.qA + 1) + Nat.size (vals.getD j []).length := by rw [bitLen_natCast, bitLen_two_pow]
      _ ≤ 2 ^ 6 * (adaZ A + 16) := by omega

private theorem muLZ_bits {A : AdaParams} {g : List ℤ} {v : List ℕ} (hglen : g.length ≤ A.N)
    (hv : ∀ x ∈ v, x ≤ 2 ^ A.qA) :
    bitLen (muLZ A g v).1 ≤ 2 ^ 6 * (adaZ A + 16) ∧ bitLen (muLZ A g v).2 ≤ 2 ^ 6 * (adaZ A + 16) := by
  have hcd : (0 : ℤ) < ((scoreScale A).den : ℤ) := by exact_mod_cast (scoreScale A).den_pos
  have hq := qA_le_adaZ (A := A)
  have hz := sixteen_le_adaZ (A := A)
  have hsg : bitLen (g.length : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]
    exact (Nat.size_le_size hglen).trans (size_N_le_adaZ (A := A))
  have hscd : bitLen ((scoreScale A).den : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]
    exact size_cden_le_adaZ (A := A)
  have h2q : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := bitLen_two_pow _
  have h8 : bitLen (8 : ℤ) = 4 := bitLen_eight
  unfold muLZ
  cases hL : wlLevel (scoreScale A).num ((scoreScale A).den : ℤ) g with
  | none => exact ⟨by simp, by simp only [bitLen_one]; omega⟩
  | some r =>
    obtain ⟨N, D⟩ := r
    obtain ⟨hD, hDle⟩ := wlLevel_D_le hcd hL
    have hsD : bitLen D ≤ 2 * adaZ A :=
      (bitLen_le_of_nonneg_le hD.le hDle).trans ((bitLen_mul_le _ _).trans (by omega))
    obtain ⟨hp0, hp1⟩ := predNum_nonneg_le (cn := (scoreScale A).num) (N := N) hcd.le hD.le
      (pow_nonneg (by norm_num : (0 : ℤ) ≤ 2) A.qA) g v (fun x hx => by exact_mod_cast hv x hx)
    simp only []
    constructor
    · calc bitLen (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D g v)
          ≤ bitLen ((g.length : ℤ) * (8 * ((scoreScale A).den : ℤ) * D * 2 ^ A.qA)) :=
            bitLen_le_of_nonneg_le hp0 hp1
        _ ≤ bitLen (g.length : ℤ) + (bitLen (8 : ℤ) + bitLen ((scoreScale A).den : ℤ) + bitLen D +
            bitLen ((2 : ℤ) ^ A.qA)) := by
            refine (bitLen_mul_le _ _).trans (Nat.add_le_add_left ?_ _)
            refine (bitLen_mul_le _ _).trans (Nat.add_le_add_right ?_ _)
            refine (bitLen_mul_le _ _).trans (Nat.add_le_add_right ?_ _)
            exact bitLen_mul_le _ _
        _ ≤ 2 ^ 6 * (adaZ A + 16) := by omega
    · calc bitLen (2 ^ A.qA * (g.length : ℤ) * ((scoreScale A).den : ℤ) * D)
          ≤ bitLen ((2 : ℤ) ^ A.qA) + bitLen (g.length : ℤ) + bitLen ((scoreScale A).den : ℤ) +
            bitLen D := by
            refine (bitLen_mul_le _ _).trans (Nat.add_le_add_right ?_ _)
            refine (bitLen_mul_le _ _).trans (Nat.add_le_add_right ?_ _)
            exact bitLen_mul_le _ _
        _ ≤ 2 ^ 6 * (adaZ A + 16) := by omega

/-- **Bit lengths of the integer predictions.** -/
theorem musZ_bits_proof {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) :
    ∀ r ∈ musZ A st.scores vals, bitLen r.1 ≤ 2 ^ 6 * (adaZ A + 16) ∧
      bitLen r.2 ≤ 2 ^ 6 * (adaZ A + 16) := by
  intro r hr
  unfold musZ at hr
  obtain ⟨j, hj, rfl⟩ := List.mem_map.mp hr
  rw [List.mem_range] at hj
  by_cases hjp : j < A.p
  · rw [if_pos hjp]
    refine muLZ_bits ?_ (fun x hx => getD_vals_le hv hx)
    rw [hok.scores_blk j hjp]
    exact getD_le_sum _ _
  · rw [if_neg hjp]
    exact muAZ_bits hv j

end F2e2e.C.Impl
