import F2e2e.C.Impl.Tree3Apply

/-!
# W6, Tree3 (proofs, part 3): the guard amplitude, the learner lookup, the fold step and Step 3

* `step3Guard_val` (Idx 265), `step3Depth_val` (Idx 264), `step3Step_val` (Idx 261);
* `step3_val` (Idx 260): on `[encStreamParams P, encState R.enc s]` the body evaluates to
  `encState R.enc (step3 P s)` (DSL-CALC's `foldP` over `List.range H`).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

attribute [local irreducible] Nat.clog Nat.log

theorem valSize_int_le_of_abs_le_nat {z : ℤ} {K : ℕ} (h : |z| ≤ (K : ℤ)) :
    valSize (Val.int z) ≤ K + 1 := by
  rw [valSize_int]
  have h1 : z.natAbs ≤ K := by
    have : ((z.natAbs : ℕ) : ℤ) ≤ (K : ℤ) := by rw [Int.natCast_natAbs]; exact h
    exact_mod_cast this
  have h2 : bitLen z ≤ z.natAbs := size_le_self z.natAbs
  omega

theorem guardCoord_le_Dstar {P : StreamParams} {d t : ℕ} (hd : d < P.H) (ht1 : 1 ≤ t)
    (htm : t ≤ P.m) : P.guardCoord d t ≤ P.Dstar := by
  have := P.guardCoord_lt hd ht1 htm
  unfold StreamParams.Dstar
  omega

theorem step3ApplyRef_t (P : StreamParams) (s : State) (d : ℕ) (Ld : Learner) (g : ℕ) (δ : ℤ) :
    (step3ApplyRef P s d Ld g δ).t = s.t := by
  unfold step3ApplyRef
  split <;> rfl

theorem step3Depth_t (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) :
    (step3Depth P tr s d).t = s.t := by
  rcases h : s.learners[d]? with _ | Ld
  · rw [step3Depth_none P tr s d h]
    rfl
  · rw [step3Depth_some P tr s d h]
    unfold step3GuardRef
    split
    · rfl
    · exact step3ApplyRef_t _ _ _ _ _ _

/-! ## The guard amplitude -/

set_option maxHeartbeats 1000000 in
theorem step3Guard_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {tr d : ℕ}
    (htr1 : 1 ≤ tr) (htrm : tr ≤ P.m) (hd : d < P.H) {Ld : Learner}
    (hLd : s.learners[d]? = some Ld) :
    EvalsVal prog M [Val.list [encStreamParams P, encState R.enc s, encN tr, encN d, encLearner Ld]]
      [] (.inl body_step3Guard) (encState R.enc (step3GuardRef P tr s d Ld)) := by
  obtain ⟨bgc, hbgc, hgc⟩ := hC.w1.pGuardCoord
  obtain ⟨bhg, hbhg, hhg⟩ := hC.w1.peHg
  obtain ⟨bhC, hbhC, hhC⟩ := hC.w1.peHC
  obtain ⟨bgm, hbgm, hgm⟩ := hC.w1.peGamma
  obtain ⟨beU, hbeU, heU⟩ := hC.w1.peU
  obtain ⟨bGM, hbGM, hGM⟩ := hC.w5.guardMant
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have hLd4 : LearnerOK P 4 Ld := hs.learners_ok Ld (List.mem_of_getElem? hLd)
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hLsz : valSize (encLearner Ld) ≤ 2 ^ 6 * P.calL ^ 3 := LearnerOK.valSize_encLearner_le hLd4
  have hLM : valSize (encLearner Ld) ≤ M := by omega
  have hpsz := valSize_encStreamParams_le P
  have hdsz : valSize (encN d) ≤ P.H + 1 := by rw [valSize_encN]; have := size_le_self d; omega
  have hmle := m_le P
  have htrsz : valSize (encN tr) ≤ P.calL + 2 := valSize_encN_le_of_lt (by
    have : 0 < 2 ^ P.calL := by positivity
    rw [pow_succ]; omega)
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s, encN tr, encN d,
      encLearner Ld]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  -- the guard coordinate and the exponents
  have hgD := guardCoord_le_Dstar hd htr1 htrm
  have hg1 : 1 ≤ P.guardCoord d tr := by have := P.guardCoord_ge d tr; omega
  have hDs := Dstar_le P
  have hgsz : valSize (encN (P.guardCoord d tr)) ≤ 3 * P.calL + 2 := by
    apply valSize_encN_le_of_lt
    have : 0 < 2 ^ (3 * P.calL) := by positivity
    rw [pow_succ]; omega
  have hal := abs_guardAlpha_le P
  have he := abs_eU_sub_epoch_le hLd4 hd
  have htag := LearnerOK.tag_le_regBits hLd4
  have htag0 := hLd4.tag_nonneg
  have hδ := guardMant_abs_le' hLd4 hd
  have hδsz : valSize (encZ (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)))) ≤
      regBits P + 2 := valSize_int_le_of_abs_le hδ
  have hregM : 4 * regBits P + 64 ≤ M := by omega
  have hHg := eHg_le P
  have hHC := eHC_le P
  have hGa := eGamma_le P
  have hsmall : ∀ {z : ℤ}, |z| ≤ (regBits P : ℤ) → valSize (Val.int z) ≤ M := fun h =>
    (valSize_int_le_of_abs_le_nat h).trans (by omega)
  have hlt : ∀ {a b : ℕ}, a ≤ regBits P → b ≤ regBits P → |((a : ℤ) - (b : ℤ))| ≤ (regBits P : ℤ) :=
    fun {a b} ha hb => by rw [abs_le]; constructor <;> omega
  have hkHg : P.eHg ≤ regBits P := by rw [hreg]; omega
  have hkHC : P.eHC ≤ regBits P := by rw [hreg]; omega
  have hkGa : P.eHg + P.eGamma ≤ regBits P := by rw [hreg]; omega
  have hkHCG : P.eHg + P.eHC + P.eGamma + 2 ≤ regBits P := by rw [hreg]; omega
  unfold body_step3Guard
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 2 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 4 (EvalsVal.var rfl) hXsz rfl) ?_
  -- g = guardCoord d tr
  refine ev_letE (evalsVal_call_det hbgc (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.var rfl) .nil)))
    (show valSize (Val.list [encStreamParams P, encN d, encN tr]) ≤ M by
      simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (hgc P d tr hP hd htr1 htrm hM)) ?_
  refine ev_letE (evalsVal_call_det hbhg (EvalsVal.var rfl) (hhg P hP hM)) ?_
  refine ev_letE (evalsVal_call_det hbhC (EvalsVal.var rfl) (hhC P hP hM)) ?_
  refine ev_letE (evalsVal_call_det hbgm (EvalsVal.var rfl) (hgm P hP hM)) ?_
  -- α = q_g − q_C − q_γ − 2
  refine ev_letE (va := Val.int (guardAlpha P)) (ev_sub (ev_sub (ev_sub (EvalsVal.var rfl)
    (EvalsVal.var rfl) (hsmall (hlt hkHg hkHC))) (EvalsVal.var rfl) (hsmall (by
      rw [abs_le]; constructor <;> omega))) (EvalsVal.lit' (hsmall (by simp; omega))) (hsmall hal)) ?_
  -- u_d and e = u_d − k_d
  refine ev_letE (evalsVal_call_det hbeU (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    .nil)) (show valSize (Val.list [encStreamParams P, encN d]) ≤ M by
      simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (heU P d hP hd hM)) ?_
  refine ev_letE (ev_sub (EvalsVal.var rfl) (ev_get 2 (EvalsVal.var rfl) hLM rfl) (hsmall he)) ?_
  -- δ
  refine ev_letE (evalsVal_call_det hbGM (ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hLM rfl)
    (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)))
    (show valSize (Val.list [encZ Ld.tag, encZ (guardAlpha P),
        encZ ((P.eU d : ℤ) - (Ld.epoch : ℤ))]) ≤ M by
      have h1 := valSize_int_le_of_abs_le (show |Ld.tag| ≤ 2 ^ regBits P by
        rw [abs_of_nonneg htag0]; exact htag)
      have h2 := valSize_int_le_of_abs_le_nat hal
      have h3 := valSize_int_le_of_abs_le_nat he
      simp only [valSize_list, listSize_cons, listSize_nil, encZ] at h1 h2 h3 ⊢
      omega))
    (hGM P Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) hP htag0 htag hal he hM)) ?_
  -- δ = 0 ?
  by_cases hδ0 : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0
  · have hres : step3GuardRef P tr s d Ld = s := by unfold step3GuardRef; rw [if_pos hδ0]
    rw [hres]
    refine ev_ite_t (ev_eq (EvalsVal.var rfl) (EvalsVal.lit' (by simp; omega)) h2M)
      (by simp [hδ0]) ?_
    exact EvalsVal.var rfl
  · have hres : step3GuardRef P tr s d Ld = step3ApplyRef P s d Ld (P.guardCoord d tr)
        (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) := by
      unfold step3GuardRef; rw [if_neg hδ0]
    have hout : StateOK P (R.ok P) 4 (step3ApplyRef P s d Ld (P.guardCoord d tr)
        (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)))) := by
      rw [← hres, ← step3Depth_some P tr s d hLd]
      exact step3Depth_ok' (by norm_num) hs tr d
    rw [hres]
    refine ev_ite_f (ev_eq (EvalsVal.var rfl) (EvalsVal.lit' (by simp; omega)) h2M)
      (by simp [hδ0]) ?_
    exact evalsVal_call_det hT.step3Apply (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) .nil))))))
      (show valSize (Val.list [encStreamParams P, encState R.enc s, encN d, encLearner Ld,
          encN (P.guardCoord d tr),
          encZ (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)))]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (step3Apply_val hR hC hT hP hM hs ht hd hLd hg1 hgD hδ hout)

/-! ## The learner lookup -/

theorem step3Depth_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {tr d : ℕ}
    (htr1 : 1 ≤ tr) (htrm : tr ≤ P.m) (hd : d < P.H) :
    EvalsVal prog M [Val.list [encStreamParams P, encState R.enc s, encN tr, encN d]] []
      (.inl body_step3Depth) (encState R.enc (step3Depth P tr s d)) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hdsz : valSize (encN d) ≤ P.H + 1 := by rw [valSize_encN]; have := size_le_self d; omega
  have hmle := m_le P
  have htrsz : valSize (encN tr) ≤ P.calL + 2 := valSize_encN_le_of_lt (by
    have : 0 < 2 ^ P.calL := by positivity
    rw [pow_succ]; omega)
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s, encN tr, encN d]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hlsz : valSize (encL encLearner s.learners) ≤ valSize (encState R.enc s) := by
    simp only [encState, encL, valSize_list, listSize_cons, listSize_nil]
    omega
  have hsd := size_le_self d
  have hgo := getOpt_val_encL hT.getOptStep encLearner s.learners d (M := M) (by omega)
  have hopt : valSize (encOpt encLearner s.learners[d]?) ≤ valSize (encL encLearner s.learners) + 2 := by
    cases hx : s.learners[d]? with
    | none => simp [encOpt]
    | some L =>
      have hm := List.mem_of_getElem? hx
      have := valSize_lt_of_mem (List.mem_map_of_mem (f := encLearner) hm)
      simp only [encOpt, encL, valSize_list, listSize_cons, listSize_nil] at this ⊢
      omega
  unfold body_step3Depth
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 2 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (evalsVal_call_det hT.getOpt (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl)
    (.cons (EvalsVal.var rfl) .nil))
    (show valSize (Val.list [encL encLearner s.learners, encN d]) ≤ M by
      rw [valSize_pair]; omega)) hgo) ?_
  rcases hx : s.learners[d]? with _ | Ld
  · rw [step3Depth_none P tr s d hx]
    simp only [encOpt]
    refine ev_ite_t (EvalsVal.isNil_nil (EvalsVal.var rfl) h2M) one_ne_zero ?_
    have hfs : valSize (encState R.enc s.fail) ≤ M := by
      have := StateOK.valSize_encState_le hada hs.fail ht
      exact this.trans hSM
    exact ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.lit' (by simp; omega))
      (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl)
          (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl) .nil))))))) hfs
  · rw [step3Depth_some P tr s d hx]
    simp only [hx, encOpt] at hopt ⊢
    have hLd4 : LearnerOK P 4 Ld := hs.learners_ok Ld (List.mem_of_getElem? hx)
    have hLsz : valSize (encLearner Ld) ≤ 2 ^ 6 * P.calL ^ 3 := LearnerOK.valSize_encLearner_le hLd4
    refine ev_ite_f (EvalsVal.isNil_cons (EvalsVal.var rfl) (by omega)) rfl ?_
    exact evalsVal_call_det hT.step3Guard (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.head (EvalsVal.var rfl)
        (by omega)) .nil)))))
      (show valSize (Val.list [encStreamParams P, encState R.enc s, encN tr, encN d,
          encLearner Ld]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (step3Guard_val hR hC hT hP hM hs ht htr1 htrm hd hx)

/-! ## The fold step -/

theorem step3Step_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {tr d : ℕ}
    (htr1 : 1 ≤ tr) (htrm : tr ≤ P.m) (hd : d < P.H) :
    EvalsVal prog M [Val.list [encN d, encState R.enc s, Val.list [encStreamParams P, encN tr]]] []
      (.inl body_step3Step)
      (encState R.enc (if s.failed then s else step3Depth P tr s d)) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hdsz : valSize (encN d) ≤ P.H + 1 := by rw [valSize_encN]; have := size_le_self d; omega
  have hmle := m_le P
  have htrsz : valSize (encN tr) ≤ P.calL + 2 := valSize_encN_le_of_lt (by
    have : 0 < 2 ^ P.calL := by positivity
    rw [pow_succ]; omega)
  have hXsz : valSize (Val.list [encN d, encState R.enc s, Val.list [encStreamParams P, encN tr]])
      ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hEsz : valSize (Val.list [encStreamParams P, encN tr]) ≤ M := by
    rw [valSize_pair]; omega
  unfold body_step3Step
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  cases hf : s.failed
  · simp only [Bool.false_eq_true, if_false]
    refine ev_ite_f (ev_get 1 (EvalsVal.var rfl) hstM rfl) (by simp [hf]) ?_
    exact evalsVal_call_det hT.step3Depth (ev_list (.cons (ev_get 0 (ev_get 2 (EvalsVal.var rfl) hXsz
      rfl) hEsz rfl) (.cons (EvalsVal.var rfl) (.cons (ev_get 1 (ev_get 2 (EvalsVal.var rfl) hXsz rfl)
        hEsz rfl) (.cons (ev_get 0 (EvalsVal.var rfl) hXsz rfl) .nil))))
      (show valSize (Val.list [encStreamParams P, encState R.enc s, encN tr, encN d]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (step3Depth_val hR hC hT hP hM hs ht htr1 htrm hd)
  · simp only [if_true]
    refine ev_ite_t (ev_get 1 (EvalsVal.var rfl) hstM rfl) (by simp [hf]) ?_
    exact EvalsVal.var rfl

/-! ## Step 3 -/

theorem step3Loop_eq_foldPE (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State),
      step3Loop P tr ds s = foldPE State.failed (fun d s => step3Depth P tr s d) ds s
  | [], _ => rfl
  | d :: ds, s => by
    simp only [step3Loop, foldPE]
    split
    · rfl
    · exact step3Loop_eq_foldPE P tr ds _

theorem step3_eq_foldP (P : StreamParams) (s : State) :
    step3 P s = foldP (fun d s' => if s'.failed then s' else step3Depth P (s.t + 1) s' d)
      (List.range P.H) s := by
  unfold step3
  rw [step3Loop_eq_foldPE, foldPE_eq_foldP]

theorem encInts_range (n : ℕ) :
    encInts ((List.range n).map (fun i : ℕ => (i : ℤ))) = encL encN (List.range n) := by
  simp only [encInts, encL, List.map_map]
  rfl

/-- **Step 3 in the DSL** (deterministic): on `[encStreamParams P, encState R.enc s]` the body
`body_step3` evaluates to `encState R.enc (step3 P s)`. -/
theorem step3_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t < P.m) :
    EvalsVal prog M [Val.list [encStreamParams P, encState R.enc s]] []
      (.inl body_step3) (encState R.enc (step3 P s)) := by
  obtain ⟨bH, hbH, hH⟩ := hC.w1.pH
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs (le_of_lt ht)
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hmle := m_le P
  have htrsz : valSize (encN (s.t + 1)) ≤ P.calL + 2 := valSize_encN_le_of_lt (by
    have : 0 < 2 ^ P.calL := by positivity
    rw [pow_succ]; omega)
  have hHsz : valSize (encN P.H) ≤ P.calL + 1 := by
    rw [valSize_encN]; have := size_le_self P.H; omega
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s]) ≤ M := by
    rw [valSize_pair]; omega
  -- the list `range H`
  have hrsz : valSize (encL encN (List.range P.H)) ≤ 1 + P.H * (P.calL + 2) := by
    have h := valSize_encL_le encN (List.range P.H) (P.calL + 1) (fun a ha => by
      have := List.mem_range.mp ha
      rw [valSize_encN]; have := size_le_self a; omega)
    rw [List.length_range] at h
    exact h
  have hHH : P.H * (P.calL + 2) ≤ P.calL * (P.calL + 2) := Nat.mul_le_mul_right _ hHc
  have hcc : P.calL * (P.calL + 2) = P.calL ^ 2 + 2 * P.calL := by ring
  have hrange := ((range_spec hT.rangeStep P.H 0).toVal).mono_M (M' := M) (by
    unfold S_range
    have h1 := size_le_self P.H
    have h2 : P.H * (Nat.size P.H + 2) ≤ P.calL * (P.calL + 2) :=
      Nat.mul_le_mul hHc (by omega)
    omega)
  rw [encInts_range] at hrange
  -- the fold
  have hfold := foldP_val (M := M) hT.step3FoldStep hT.step3Step encN (encState R.enc)
    (Val.list [encStreamParams P, encN (s.t + 1)])
    (fun d s' => if s'.failed then s' else step3Depth P (s.t + 1) s' d)
    (fun s' => StateOK P (R.ok P) 4 s' ∧ s'.t = s.t) (List.range P.H) (stateSizeBound P (R.bound P))
    (fun d s' hd hs' => by
      refine ⟨?_, ?_⟩
      · split
        · exact hs'.1
        · exact step3Depth_ok' (by norm_num) hs'.1 _ d
      · split
        · exact hs'.2
        · rw [step3Depth_t]; exact hs'.2)
    (fun d s' hd hs' => step3Step_val hR hC hT hP hM hs'.1 (by rw [hs'.2]; omega) (by omega)
      (by omega) (List.mem_range.mp hd))
    (fun s' hs' => StateOK.valSize_encState_le hada hs'.1 (by rw [hs'.2]; omega))
    (by
      have : valSize (Val.list [encStreamParams P, encN (s.t + 1)]) ≤ 6 * P.calL + 16 := by
        rw [valSize_pair]; omega
      omega)
    s ⟨hs, rfl⟩
  rw [← step3_eq_foldP] at hfold
  unfold body_step3
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (va := encN (s.t + 1)) ?_ ?_
  · have he : encN (s.t + 1) = Val.int ((s.t : ℤ) + 1) := by simp [encN]
    have hs1 : valSize (Val.int ((s.t : ℤ) + 1)) ≤ M := by rw [← he]; omega
    rw [he]
    exact ev_add (ev_get 0 (EvalsVal.var rfl) hstM rfl) (EvalsVal.lit' (by simp; omega)) hs1
  refine ev_letE (evalsVal_call_det hbH (EvalsVal.var rfl) (hH P hP hM)) ?_
  refine ev_letE (evalsVal_call_det hT.range (EvalsVal.var rfl) hrange) ?_
  exact evalsVal_call_det hT.step3Fold (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
      (show valSize (Val.list [encStreamParams P, encN (s.t + 1)]) ≤ M by rw [valSize_pair]; omega))
      .nil)))
    (show valSize (Val.list [encState R.enc s, encL encN (List.range P.H),
        Val.list [encStreamParams P, encN (s.t + 1)]]) ≤ M by
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega))
    hfold

end F2e2e.C.Impl.W6
