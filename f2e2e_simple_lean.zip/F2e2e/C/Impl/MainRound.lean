import F2e2e.C.Impl.Main

/-!
# W6, Main (proofs, part 2): the round and the initialization

* `roundB_impl` (Steps 3–4), `roundA_impl` (Step 2 and the zero bypass);
* `round_impl`: `body_round` implements C-ALG's `roundStep P s i Δ` on
  `[encStreamParams P, encState R.enc s, encN i, encZ Δ]`, output `[encState s', encQ F]`;
* `init_impl`: `body_init` implements C-ALG's `initState P` on `encStreamParams P`.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

attribute [local irreducible] Nat.clog Nat.log

/-! ## The reference decomposition of `roundStep` -/

/-- Steps 3–4 of a round (after a nonzero, non-failed Step 2). -/
def roundBRef (P : StreamParams) (s2 : State) : BitProg (State × ℚ) :=
  if (step3 P s2).failed then pure (finishRound (step3 P s2) 0)
  else (step4 P (step3 P s2)).bind (fun r4 => pure (finishRound r4.1 r4.2))

/-- Steps 2–4 of a round (after Step 1). -/
def roundARef (P : StreamParams) (s1 : State) (i : ℕ) (Δ : ℤ) : BitProg (State × ℚ) :=
  if s1.failed then pure (finishRound s1 0)
  else if (step2 P i Δ s1).1.failed || (step2 P i Δ s1).2 then pure (finishRound (step2 P i Δ s1).1 0)
  else roundBRef P (step2 P i Δ s1).1

theorem roundStep_eq (P : StreamParams) (s : State) (i : ℕ) (Δ : ℤ) :
    roundStep P s i Δ = if s.failed then pure (finishRound s 0)
      else (step1 P s).bind (fun s1 => roundARef P s1 i Δ) := rfl

/-! ## Steps 3–4 -/

theorem roundB_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hL : MainLib prog) (hH : TreeHelpers R prog M) (h4 : Step4Out R)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {s2 : State}
    (hs : StateInv P (R.ok P) s2) (ht : s2.t < P.m) :
    Implements prog M [Val.list [encStreamParams P, encState R.enc s2]] body_roundB
      (fun r => Val.list [encState R.enc r.1, encQ r.2]) (roundBRef P s2) := by
  obtain ⟨b4, hb4, h4spec⟩ := hH.step4
  have hada := hR.enc_le P hP
  have hA := hR.invariant P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s2) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs.1 (le_of_lt ht)
  have hpsz := valSize_encStreamParams_le P
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s2]) ≤ M := by
    rw [valSize_pair]; omega
  have hs3 : StateInv P (R.ok P) (step3 P s2) := step3_inv hs
  have ht3 : (step3 P s2).t = s2.t := step3_t P s2
  have hst3 : valSize (encState R.enc (step3 P s2)) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs3.1 (by omega)
  have hst3M : valSize (encState R.enc (step3 P s2)) ≤ M := hst3.trans hSM
  unfold body_roundB
  refine implements_letE_det' (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (evalsVal_call_det hL.step3 (ev_list (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.var rfl) .nil)) hXsz) (step3_val hR hC hL.tree3 hP hM hs.1 ht)) ?_
  refine implements_ite_encB (b := (step3 P s2).failed) (ev_get 1 (EvalsVal.var rfl) hst3M rfl) ?_
  unfold roundBRef
  cases hf : (step3 P s2).failed
  · simp only [Bool.false_eq_true, if_false]
    refine implements_letE_run (implements_call_det hb4 (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) .nil)) (show valSize (Val.list [encStreamParams P,
        encState R.enc (step3 P s2)]) ≤ M by rw [valSize_pair]; omega))
      (h4spec P _ hP hM hs3 (by omega) hf)) ?_
    intro bits r4 hrun
    have hQ := Always.of_run (h4 P _ hP hs3 (by omega) hf) hrun
    have hI := Always.of_run (step4_inv hA hs3) hrun
    have hT : r4.1.t = (step3 P s2).t := (Always.of_run (F2e2e.C.Alg.step4_out P _) hrun).1.1
    have hst4 : valSize (encState R.enc r4.1) ≤ stateSizeBound P (R.bound P) :=
      StateOK.valSize_encState_le hada hI.1 (by omega)
    have hq4 := valSize_encQ_le_of_QOK hQ.2
    have hr4sz : valSize (Val.list [encState R.enc r4.1, encQ r4.2]) ≤ M := by
      rw [valSize_pair]; omega
    refine Implements.of_det ?_
    exact evalsVal_call_det hL.finQ (ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hr4sz rfl)
      (.cons (ev_get 1 (EvalsVal.var rfl) hr4sz rfl) .nil)) hr4sz)
      (finQ_val hR hP hM hI.1 (by omega) hQ.2)
  · rw [if_pos rfl]
    exact Implements.of_det (evalsVal_call_det hL.fin0 (ev_list (.cons (EvalsVal.var rfl) .nil)
      (show valSize (Val.list [encState R.enc (step3 P s2)]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (fin0_val hR hP hM hs3.1 (by omega)))

/-! ## Steps 2–4 -/

theorem roundA_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hL : MainLib prog) (hH : TreeHelpers R prog M) (h4 : Step4Out R)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {s1 : State}
    (hs : StateInv P (R.ok P) s1) (ht : s1.t < P.m) {i : ℕ} (hi : i < P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    Implements prog M [Val.list [encStreamParams P, encState R.enc s1, encN i, encZ Δ]] body_roundA
      (fun r => Val.list [encState R.enc r.1, encQ r.2]) (roundARef P s1 i Δ) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s1) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs.1 (le_of_lt ht)
  have hstM : valSize (encState R.enc s1) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hn := n_add_two_le P
  have hcP := cP_add_hundred_le P
  have hisz : valSize (encN i) ≤ cP P + 1 := valSize_encN_le_of_lt (by omega)
  have hΔsz : valSize (encZ Δ) ≤ cP P + 2 := valSize_int_le_of_abs_lt (abs_update_lt P hΔ)
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s1, encN i, encZ Δ]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hs2 : StateInv P (R.ok P) (step2 P i Δ s1).1 := step2_inv hs i Δ
  have ht2 : (step2 P i Δ s1).1.t = s1.t := step2_t P i Δ s1
  have hst2 : valSize (encState R.enc (step2 P i Δ s1).1) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs2.1 (by omega)
  have hst2M : valSize (encState R.enc (step2 P i Δ s1).1) ≤ M := hst2.trans hSM
  have hr2sz : valSize (Val.list [encState R.enc (step2 P i Δ s1).1, encB (step2 P i Δ s1).2])
      ≤ M := by
    rw [valSize_pair]; have := valSize_encB_le (step2 P i Δ s1).2; omega
  unfold body_roundA
  refine implements_letE_det' (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 2 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_ite_encB (b := s1.failed) (ev_get 1 (EvalsVal.var rfl) hstM rfl) ?_
  unfold roundARef
  cases hf : s1.failed
  · simp only [Bool.false_eq_true, if_false]
    refine implements_letE_det' (evalsVal_call_det hL.step2 (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)))) hXsz)
      (step2_val hR hC hL.tree2 hP hM hs (le_of_lt ht) hi hΔ)) ?_
    refine implements_letE_det' (ev_get 0 (EvalsVal.var rfl) hr2sz rfl) ?_
    refine implements_ite_encB (b := (step2 P i Δ s1).1.failed)
      (ev_get 1 (EvalsVal.var rfl) hst2M rfl) ?_
    have hfin : ∀ z : Bool, Implements prog M (encState R.enc (step2 P i Δ s1).1 ::
        Val.list [encState R.enc (step2 P i Δ s1).1, encB z] ::
        encZ Δ :: encN i :: encState R.enc s1 :: encStreamParams P ::
        [Val.list [encStreamParams P, encState R.enc s1, encN i, encZ Δ]])
        (Expr.call Idx.fin0 (eList [Expr.var 0])) (fun r => Val.list [encState R.enc r.1, encQ r.2])
        (pure (finishRound (step2 P i Δ s1).1 0)) := fun z =>
      Implements.of_det (evalsVal_call_det hL.fin0 (ev_list (.cons (EvalsVal.var rfl) .nil)
        (show valSize (Val.list [encState R.enc (step2 P i Δ s1).1]) ≤ M by
          simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (fin0_val hR hP hM hs2.1 (by omega)))
    cases hf2 : (step2 P i Δ s1).1.failed
    · simp only [Bool.false_eq_true, if_false, Bool.false_or]
      refine implements_ite_encB (b := (step2 P i Δ s1).2) (ev_get 1 (EvalsVal.var rfl) hr2sz rfl) ?_
      cases hz : (step2 P i Δ s1).2
      · simp only [Bool.false_eq_true, if_false]
        exact implements_call_det hL.roundB (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
          .nil)) (show valSize (Val.list [encStreamParams P, encState R.enc (step2 P i Δ s1).1]) ≤ M by
            rw [valSize_pair]; omega))
          (roundB_impl hR hC hL hH h4 hP hM hs2 (by omega))
      · rw [if_pos rfl]
        exact hfin true
    · simp only [if_true, Bool.true_or]
      exact hfin _
  · rw [if_pos rfl]
    exact Implements.of_det (evalsVal_call_det hL.fin0 (ev_list (.cons (EvalsVal.var rfl) .nil)
      (show valSize (Val.list [encState R.enc s1]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (fin0_val hR hP hM hs.1 ht))

/-! ## The round -/

/-- **One round in the DSL**: `body_round` implements C-ALG's `roundStep P s i Δ` on
`[encStreamParams P, encState R.enc s, encN i, encZ Δ]`, with output `[encState s', encQ F]`. -/
theorem round_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hL : MainLib prog) (hH : TreeHelpers R prog M) (h4 : Step4Out R)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {s : State}
    (hs : StateInv P (R.ok P) s) (ht : s.t < P.m) {i : ℕ} (hi : i < P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    Implements prog M [Val.list [encStreamParams P, encState R.enc s, encN i, encZ Δ]] body_round
      (fun r => Val.list [encState R.enc r.1, encQ r.2]) (roundStep P s i Δ) := by
  obtain ⟨b1, hb1, h1spec⟩ := hH.step1
  have hada := hR.enc_le P hP
  have hA := hR.invariant P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs.1 (le_of_lt ht)
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hpsz := valSize_encStreamParams_le P
  have hn := n_add_two_le P
  have hcP := cP_add_hundred_le P
  have hisz : valSize (encN i) ≤ cP P + 1 := valSize_encN_le_of_lt (by omega)
  have hΔsz : valSize (encZ Δ) ≤ cP P + 2 := valSize_int_le_of_abs_lt (abs_update_lt P hΔ)
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s, encN i, encZ Δ]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  rw [roundStep_eq]
  unfold body_round
  refine implements_letE_det' (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 2 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_letE_det' (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  refine implements_ite_encB (b := s.failed) (ev_get 1 (EvalsVal.var rfl) hstM rfl) ?_
  cases hf : s.failed
  · simp only [Bool.false_eq_true, if_false]
    refine implements_letE_run (implements_call_det hb1 (ev_list (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) .nil)) (show valSize (Val.list [encStreamParams P,
        encState R.enc s]) ≤ M by rw [valSize_pair]; omega))
      (h1spec P s hP hM hs ht hf)) ?_
    intro bits s1 hrun
    have hI := Always.of_run (step1_inv hA hs) hrun
    have hT : s1.t = s.t := (Always.of_run (step1_frame P s) hrun).1
    have hst1 : valSize (encState R.enc s1) ≤ stateSizeBound P (R.bound P) :=
      StateOK.valSize_encState_le hada hI.1 (by omega)
    exact implements_call_det hL.roundA (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))))
      (show valSize (Val.list [encStreamParams P, encState R.enc s1, encN i, encZ Δ]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (roundA_impl hR hC hL hH h4 hP hM hI (by omega) hi hΔ)
  · rw [if_pos rfl]
    exact Implements.of_det (evalsVal_call_det hL.fin0 (ev_list (.cons (EvalsVal.var rfl) .nil)
      (show valSize (Val.list [encState R.enc s]) ≤ M by
        simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (fin0_val hR hP hM hs.1 ht))

/-! ## The initialization -/

/-- **The initialization in the DSL**: `body_init` implements C-ALG's `initState P` on
`encStreamParams P`. -/
theorem init_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) :
    Implements prog M [encStreamParams P] body_init (encState R.enc) (initState P) := by
  obtain ⟨bfs, hbfs, hfs⟩ := hC.w3.fpSeed
  obtain ⟨bnb, hbnb, hnb⟩ := hC.w3.newBank
  have hada := hR.enc_le P hP
  have hA := hR.invariant P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hqle := q_le P
  have h2p : 0 < 2 ^ (3 * P.calL) := by positivity
  have hVBH : bankSizeBound P (R.bound P) + 1 ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
    Nat.le_mul_of_pos_left _ hH1
  unfold body_init initState
  simp only [bp_bind_eq, bp_pure_eq]
  refine implements_letE_run (implements_call_det hbfs (EvalsVal.var rfl) (hfs P hP hM)) ?_
  intro bits r hr
  have hrq : r < P.q := Always.of_run (always_fpSeedProg P) hr
  refine implements_letE_run (implements_call_det hbnb (EvalsVal.var rfl) (hnb P hP hM)) ?_
  intro bits' B hB
  have hBok : BankOK P (R.ok P) B := Always.of_run (always_newBank P hA) hB
  have hBsz := BankOK.valSize_encBank_le hada hBok
  have hrlt : r < 2 ^ (3 * P.calL + 1) := by rw [pow_succ]; omega
  have hrsz : valSize (encN r) ≤ 3 * P.calL + 2 := valSize_encN_le_of_lt hrlt
  refine Implements.of_det ?_
  have hBl : valSize (Val.list [encBank R.enc B]) ≤ bankSizeBound P (R.bound P) + 2 := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have h0 : valSize (Val.int 0) ≤ M := by simp; omega
  have hnil : valSize (Val.list []) ≤ M := by simp; omega
  have hBlM : valSize (Val.list [encBank R.enc B]) ≤ M := by omega
  have hsz : valSize (Val.list [Val.int 0, Val.int 0, encN r, Val.int 0, Val.list [],
      Val.list [encBank R.enc B], Val.int 0]) ≤ M := by
    have h0' : valSize (Val.int 0) = 1 := by simp
    have hnil' : valSize (Val.list []) = 1 := by simp
    simp only [valSize_list, listSize_cons, listSize_nil] at hBl ⊢
    rw [h0', hnil'] at *
    omega
  exact ev_list (.cons (EvalsVal.lit' h0) (.cons (EvalsVal.lit' h0) (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.lit' h0) (.cons (EvalsVal.nil hnil) (.cons (ev_list (.cons (EvalsVal.var rfl)
      .nil) hBlM) (.cons (EvalsVal.lit' h0) .nil))))))) hsz

end F2e2e.C.Impl.W6
