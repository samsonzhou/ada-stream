import F2e2e.C.Impl.AdaPubEv

/-!
# The ADA parameter record: the search for `p` and the list of caps `T_j^max`

Loops of the DSL routine `adaPub` (`F2e2e/C/Impl/AdaPub.lean`), namespace `F2e2e.C.Impl.AP`:

* `body_apPStep` (index 650): the search for `p = adaP eA`, the least `q ≥ 2` with
  `q 2^{eA+3} ≤ 2^{q-1}` (state `[q, 2^{q-1}, 2^{eA+3}]`, from `q = 2`); `apP_loop`;
* `body_apTStep` (index 651): the list `[T_0^max, …, T_{p-1}^max]` and its sum, built from `j = p - 1`
  down to `0` (state `[k, acc, sum, A, 4^k/4]`, `T_j = (A + 4^j - 1)/4^j`, `A = 384 p² 4^{eA}`); `apT_loop`.
-/

namespace F2e2e.Cost.Idx

/-- `adaPub` helper: loop step of the search for `p`. -/
abbrev apPStep : ℕ := 650
/-- `adaPub` helper: loop step of the list of caps `T_j^max`. -/
abbrev apTStep : ℕ := 651

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

theorem size_succ_le (n : ℕ) : Nat.size (n + 1) ≤ Nat.size n + 1 := by
  apply Nat.size_le.2
  have := Nat.lt_size_self n
  rw [pow_succ]
  omega

/-! ## The search for `p` -/

/-- Loop step of the search for `p`; state `[q, t, c]` (`t = 2^{q-1}`, `c = 2^{eA+3}`): stop with
`q` if `q c ≤ t`, else continue with `[q + 1, 2t, c]`. -/
def body_apPStep : Expr :=
  Expr.ite (Expr.bin BinOp.lt (eGet 1 (Expr.var 0))
      (Expr.bin BinOp.mul (eGet 0 (Expr.var 0)) (eGet 2 (Expr.var 0))))
    (eList [Expr.lit 1, eList [Expr.bin BinOp.add (eGet 0 (Expr.var 0)) (Expr.lit 1),
      Expr.bin BinOp.add (eGet 1 (Expr.var 0)) (eGet 1 (Expr.var 0)), eGet 2 (Expr.var 0)]])
    (eList [Expr.lit 0, eGet 0 (Expr.var 0)])

/-- The state `[q, 2^{q-1}, c]` of the search. -/
def encPS (c q : ℕ) : Val := Val.list [encN q, encN (2 ^ (q - 1)), encN c]

theorem valSize_encPS (c q : ℕ) (hq : 1 ≤ q) :
    valSize (encPS c q) = Nat.size q + q + Nat.size c + 7 := by
  simp only [encPS, valSize_list, listSize_cons, listSize_nil, valSize_encN, size_two_pow]
  omega

section

variable {prog : List Expr} {M : ℕ}

theorem apPStep_stop {c q : ℕ} (hq : 2 ≤ q) (hs : q * c ≤ 2 ^ (q - 1))
    (hM : 2 * (Nat.size q + q + Nat.size c) + 30 ≤ M) :
    EvalsVal prog M [encPS c q] [] (.inl body_apPStep) (Val.list [Val.int 0, encN q]) := by
  have hX := valSize_encPS c q (by omega)
  have hXM : valSize (encPS c q) ≤ M := by omega
  have hv : EvalsVal prog M [encPS c q] [] (.inl (Expr.var 0)) (encPS c q) := EvalsVal.var rfl
  have g0 : EvalsVal prog M [encPS c q] [] (.inl (eGet 0 (Expr.var 0))) (encN q) :=
    ev_get 0 hv hXM rfl
  have g1 : EvalsVal prog M [encPS c q] [] (.inl (eGet 1 (Expr.var 0))) (encN (2 ^ (q - 1))) :=
    ev_get 1 hv hXM rfl
  have g2 : EvalsVal prog M [encPS c q] [] (.inl (eGet 2 (Expr.var 0))) (encN c) :=
    ev_get 2 hv hXM rfl
  have hmul := size_mul_le q c
  have hc := evN_lt_false g1 (evN_mul g0 g2 (by omega)) (by omega) (by omega)
  refine ev_ite_false hc ?_
  refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons g0 .nil)) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN, bitLen_zero]
  omega

theorem apPStep_cont {c q : ℕ} (hq : 2 ≤ q) (hs : ¬ q * c ≤ 2 ^ (q - 1))
    (hM : 2 * (Nat.size q + q + Nat.size c) + 30 ≤ M) :
    EvalsVal prog M [encPS c q] [] (.inl body_apPStep) (Val.list [Val.int 1, encPS c (q + 1)]) := by
  have hX := valSize_encPS c q (by omega)
  have hX1 := valSize_encPS c (q + 1) (by omega)
  have hsq1 := size_succ_le q
  have hXM : valSize (encPS c q) ≤ M := by omega
  have hv : EvalsVal prog M [encPS c q] [] (.inl (Expr.var 0)) (encPS c q) := EvalsVal.var rfl
  have g0 : EvalsVal prog M [encPS c q] [] (.inl (eGet 0 (Expr.var 0))) (encN q) :=
    ev_get 0 hv hXM rfl
  have g1 : EvalsVal prog M [encPS c q] [] (.inl (eGet 1 (Expr.var 0))) (encN (2 ^ (q - 1))) :=
    ev_get 1 hv hXM rfl
  have g2 : EvalsVal prog M [encPS c q] [] (.inl (eGet 2 (Expr.var 0))) (encN c) :=
    ev_get 2 hv hXM rfl
  have hmul := size_mul_le q c
  have hc := evN_lt_true g1 (evN_mul g0 g2 (by omega)) (by omega) (by omega)
  refine ev_ite_true hc ?_
  have e2 : 2 ^ (q - 1) + 2 ^ (q - 1) = 2 ^ (q + 1 - 1) := by
    rw [show q + 1 - 1 = (q - 1) + 1 by omega, pow_succ]
    ring
  have hs2 : Nat.size (2 ^ (q - 1) + 2 ^ (q - 1)) = q + 1 := by
    rw [e2, size_two_pow]
    omega
  have h1 := evN_add g0 (evN_lit (prog := prog) (env := [encPS c q]) 1 (by simp; omega))
    (by omega)
  have h2 := ev_cast (evN_add g1 g1 (by omega)) (by rw [e2])
  have hin : EvalsVal prog M [encPS c q] [] (.inl (eList [Expr.bin BinOp.add (eGet 0 (Expr.var 0))
      (Expr.lit 1), Expr.bin BinOp.add (eGet 1 (Expr.var 0)) (eGet 1 (Expr.var 0)),
      eGet 2 (Expr.var 0)])) (encPS c (q + 1)) := by
    refine ev_list (.cons h1 (.cons h2 (.cons g2 .nil))) ?_
    rw [← encPS]
    omega
  refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons hin .nil)) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one] at hX1 ⊢
  omega

/-- **The search for `p`.** From any `q` with `2 ≤ q ≤ p`, the loop returns `p = adaP eA`. -/
theorem apP_loop (hb : prog[Cost.Idx.apPStep]? = some body_apPStep) (eA : ℕ)
    (hM : 2 * (2 * adaP eA + eA + 4) + 30 ≤ M) :
    ∀ q, (2 ≤ q ∧ q ≤ adaP eA) → ∃ out, out = encN (adaP eA) ∧
      EvalsVal prog M [] [] (.inr (Cost.Idx.apPStep, encPS (2 ^ (eA + 3)) q)) out := by
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hb (encPS (2 ^ (eA + 3)))
    (fun _ => []) (fun q => 2 ≤ q ∧ q ≤ adaP eA) (fun out => out = encN (adaP eA))
    (fun q => adaP eA - q) ?_
  · intro q hq
    obtain ⟨out, h1, h2⟩ := key q hq
    exact ⟨out, h1, h2⟩
  · rintro q ⟨hq2, hqp⟩
    have hsc : Nat.size (2 ^ (eA + 3)) = eA + 4 := size_two_pow _
    have hsq : Nat.size q ≤ q := size_le_self' q
    have hM' : 2 * (Nat.size q + q + Nat.size (2 ^ (eA + 3))) + 30 ≤ M := by omega
    by_cases hs : q * 2 ^ (eA + 3) ≤ 2 ^ (q - 1)
    · left
      refine ⟨encN q, apPStep_stop hq2 hs hM', ?_⟩
      have := adaP_min hq2 hs
      rw [show q = adaP eA by omega]
    · right
      have hlt : q < adaP eA := by
        rcases Nat.lt_or_ge q (adaP eA) with h | h
        · exact h
        · exfalso
          have hq' : q = adaP eA := by omega
          exact hs (hq' ▸ (adaP_spec eA).2)
      exact ⟨1, q + 1, [], one_ne_zero, rfl, apPStep_cont hq2 hs hM', ⟨by omega, by omega⟩,
        by omega⟩

end

/-! ## The list of caps `T_j^max` -/

/-- Loop step of the list of caps; state `[k, acc, sum, A, f]` (`f = 4^{k-1}` for `k ≥ 1`): stop with
`[acc, sum]` if `k = 0`, else continue with `[k - 1, T :: acc, sum + T, A, f / 4]`,
`T = (A + f - 1)/f`. -/
def body_apTStep : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 (Expr.var 0)) (Expr.lit 0))
    (eList [Expr.lit 0, eList [eGet 1 (Expr.var 0), eGet 2 (Expr.var 0)]])
    (Expr.letE
      (Expr.bin BinOp.div
        (Expr.bin BinOp.sub (Expr.bin BinOp.add (eGet 3 (Expr.var 0)) (eGet 4 (Expr.var 0)))
          (Expr.lit 1))
        (eGet 4 (Expr.var 0)))
      (eList [Expr.lit 1, eList [Expr.bin BinOp.sub (eGet 0 (Expr.var 1)) (Expr.lit 1),
        Expr.bin BinOp.cons (Expr.var 0) (eGet 1 (Expr.var 1)),
        Expr.bin BinOp.add (eGet 2 (Expr.var 1)) (Expr.var 0), eGet 3 (Expr.var 1),
        Expr.bin BinOp.div (eGet 4 (Expr.var 1)) (Expr.lit 4)]]))

/-- The state `[k, acc, sum acc, A, 4^k/4]` of the list of caps. -/
def encTS (A k : ℕ) (acc : List ℕ) : Val :=
  Val.list [encN k, encL encN acc, encN acc.sum, encN A, encN (2 ^ (2 * k) / 4)]

theorem four_pow_div_four (k : ℕ) : 2 ^ (2 * (k + 1)) / 4 = 2 ^ (2 * k) := by
  rw [show 2 * (k + 1) = 2 * k + 2 by ring, pow_add]
  norm_num

theorem size_four_pow_div_le (k : ℕ) : Nat.size (2 ^ (2 * k) / 4) ≤ 2 * k + 1 := by
  calc Nat.size (2 ^ (2 * k) / 4) ≤ Nat.size (2 ^ (2 * k)) := size_le_of_le (Nat.div_le_self _ _)
    _ = 2 * k + 1 := size_two_pow _

/-- `⌈A/f⌉ ≤ A` for `A, f ≥ 1`. -/
theorem ceilDiv_le_self {A f : ℕ} (hA : 1 ≤ A) (hf : 1 ≤ f) : (A + f - 1) / f ≤ A := by
  apply Nat.div_le_of_le_mul
  obtain ⟨a, rfl⟩ : ∃ a, A = a + 1 := ⟨A - 1, by omega⟩
  obtain ⟨b, rfl⟩ : ∃ b, f = b + 1 := ⟨f - 1, by omega⟩
  have : a + 1 + (b + 1) - 1 = a + b + 1 := by omega
  rw [this]
  nlinarith [Nat.zero_le (a * b)]

theorem tmA_pos (eA : ℕ) : 1 ≤ tmA eA := by
  have hp := two_le_adaP eA
  unfold tmA
  have h1 : 1 ≤ 2 ^ eA * 2 ^ eA := Nat.one_le_iff_ne_zero.mpr (by positivity)
  have h2 : 1 ≤ adaP eA * adaP eA := Nat.one_le_iff_ne_zero.mpr (by positivity)
  nlinarith

theorem adaTmax_le_tmA {eA j : ℕ} (hj : j < adaP eA) : adaTmax eA j ≤ tmA eA := by
  rw [adaTmax_eq hj]
  exact ceilDiv_le_self (tmA_pos eA) (Nat.one_le_two_pow)

theorem adaTmaxList_length (eA : ℕ) : (adaTmaxList eA).length = adaP eA := by
  simp [adaTmaxList]

theorem adaTmaxList_getElem {eA j : ℕ} (hj : j < (adaTmaxList eA).length) :
    (adaTmaxList eA)[j] = adaTmax eA j := by
  simp [adaTmaxList]

theorem mem_adaTmaxList_le {eA x : ℕ} (hx : x ∈ adaTmaxList eA) : x ≤ tmA eA := by
  simp only [adaTmaxList, List.mem_map, List.mem_range] at hx
  obtain ⟨j, hj, rfl⟩ := hx
  exact adaTmax_le_tmA hj

theorem adaTmaxList_sum_le (eA : ℕ) : (adaTmaxList eA).sum ≤ adaP eA * tmA eA := by
  have h := List.sum_le_card_nsmul (adaTmaxList eA) (tmA eA) (fun x hx => mem_adaTmaxList_le hx)
  rw [adaTmaxList_length, smul_eq_mul] at h
  exact h

section

variable {prog : List Expr} {M : ℕ}

theorem apTStep_stop (A : ℕ) (acc : List ℕ) (hM : valSize (encTS A 0 acc) + 10 ≤ M) :
    EvalsVal prog M [encTS A 0 acc] [] (.inl body_apTStep)
      (Val.list [Val.int 0, Val.list [encL encN acc, encN acc.sum]]) := by
  have hXM : valSize (encTS A 0 acc) ≤ M := by omega
  have hv : EvalsVal prog M [encTS A 0 acc] [] (.inl (Expr.var 0)) (encTS A 0 acc) :=
    EvalsVal.var rfl
  have g0 : EvalsVal prog M [encTS A 0 acc] [] (.inl (eGet 0 (Expr.var 0))) (encN 0) :=
    ev_get 0 hv hXM rfl
  have g1 : EvalsVal prog M [encTS A 0 acc] [] (.inl (eGet 1 (Expr.var 0))) (encL encN acc) :=
    ev_get 1 hv hXM rfl
  have g2 : EvalsVal prog M [encTS A 0 acc] [] (.inl (eGet 2 (Expr.var 0))) (encN acc.sum) :=
    ev_get 2 hv hXM rfl
  have hc := evN_eq_true g0 (evN_lit (prog := prog) (env := [encTS A 0 acc]) 0 (by simp; omega))
    rfl (by omega)
  refine ev_ite_true hc ?_
  have hX : valSize (encTS A 0 acc) = valSize (encL encN acc) + Nat.size acc.sum + Nat.size A +
      Nat.size (2 ^ (2 * 0) / 4) + 10 := by
    simp only [encTS, valSize_list, listSize_cons, listSize_nil, valSize_encN, Nat.size_zero]
    omega
  have hin := ev_list (prog := prog) (M := M) (env := [encTS A 0 acc])
    (.cons g1 (.cons g2 .nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
      omega)
  refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons hin .nil)) ?_
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN, bitLen_zero]
  omega

theorem apTStep_cont (A k : ℕ) (acc : List ℕ) (hA : 1 ≤ A)
    (hM : valSize (encTS A (k + 1) acc) + 2 * Nat.size A + 4 * k + 20 ≤ M) :
    EvalsVal prog M [encTS A (k + 1) acc] [] (.inl body_apTStep)
      (Val.list [Val.int 1, encTS A k ((A + 2 ^ (2 * k) - 1) / 2 ^ (2 * k) :: acc)]) := by
  set S := encTS A (k + 1) acc with hS
  set f := 2 ^ (2 * k) with hf
  set T := (A + f - 1) / f with hT
  have hf1 : 1 ≤ f := Nat.one_le_two_pow
  have hsf : Nat.size f = 2 * k + 1 := size_two_pow _
  have hTA : T ≤ A := ceilDiv_le_self hA hf1
  have hsT : Nat.size T ≤ Nat.size A := size_le_of_le hTA
  have hfe : 2 ^ (2 * (k + 1)) / 4 = f := four_pow_div_four k
  have hX : valSize S = Nat.size (k + 1) + valSize (encL encN acc) + Nat.size acc.sum +
      Nat.size A + Nat.size f + 10 := by
    simp only [hS, encTS, valSize_list, listSize_cons, listSize_nil, valSize_encN, hfe]
    omega
  have hXM : valSize S ≤ M := by omega
  have hv : EvalsVal prog M [S] [] (.inl (Expr.var 0)) S := EvalsVal.var rfl
  have g0 : EvalsVal prog M [S] [] (.inl (eGet 0 (Expr.var 0))) (encN (k + 1)) :=
    ev_get 0 hv hXM rfl
  have g3 : EvalsVal prog M [S] [] (.inl (eGet 3 (Expr.var 0))) (encN A) := ev_get 3 hv hXM rfl
  have g4 : EvalsVal prog M [S] [] (.inl (eGet 4 (Expr.var 0))) (encN f) :=
    ev_get 4 hv hXM (by simp only [hS, encTS, hfe]; rfl)
  have hc := evN_eq_false g0 (evN_lit (prog := prog) (env := [S]) 0 (by simp; omega))
    (by omega) (by omega)
  refine ev_ite_false hc ?_
  -- the cap `T`
  have hAf := size_add_le A f
  have hT' : EvalsVal prog M [S] [] (.inl (Expr.bin BinOp.div
      (Expr.bin BinOp.sub (Expr.bin BinOp.add (eGet 3 (Expr.var 0)) (eGet 4 (Expr.var 0)))
        (Expr.lit 1)) (eGet 4 (Expr.var 0)))) (encN T) := by
    refine evN_div (evN_sub (evN_add g3 g4 (by omega))
      (evN_lit (prog := prog) (env := [S]) 1 (by simp; omega)) (by omega) (by omega)) g4
      (by omega) ?_
    have := size_le_of_le (Nat.sub_le (A + f) 1)
    omega
  refine ev_letE hT' ?_
  -- the new state, in the environment `[T, S]`
  have hv1 : EvalsVal prog M [encN T, S] [] (.inl (Expr.var 1)) S := EvalsVal.var rfl
  have hT0 : EvalsVal prog M [encN T, S] [] (.inl (Expr.var 0)) (encN T) := EvalsVal.var rfl
  have k0 : EvalsVal prog M [encN T, S] [] (.inl (eGet 0 (Expr.var 1))) (encN (k + 1)) :=
    ev_get 0 hv1 hXM rfl
  have k1 : EvalsVal prog M [encN T, S] [] (.inl (eGet 1 (Expr.var 1))) (encL encN acc) :=
    ev_get 1 hv1 hXM rfl
  have k2 : EvalsVal prog M [encN T, S] [] (.inl (eGet 2 (Expr.var 1))) (encN acc.sum) :=
    ev_get 2 hv1 hXM rfl
  have k3 : EvalsVal prog M [encN T, S] [] (.inl (eGet 3 (Expr.var 1))) (encN A) :=
    ev_get 3 hv1 hXM rfl
  have k4 : EvalsVal prog M [encN T, S] [] (.inl (eGet 4 (Expr.var 1))) (encN f) :=
    ev_get 4 hv1 hXM (by simp only [hS, encTS, hfe]; rfl)
  have hsk : Nat.size k ≤ Nat.size (k + 1) := size_le_of_le (Nat.le_succ k)
  have hsum := size_add_le acc.sum T
  have n0 := ev_cast (evN_sub k0 (evN_lit (prog := prog) (env := [encN T, S]) 1 (by simp; omega))
    (by omega) (by omega)) (show encN (k + 1 - 1) = encN k by rfl)
  have hlist : valSize (encL encN (T :: acc)) = Nat.size T + 2 + valSize (encL encN acc) := by
    simp only [encL, List.map_cons, valSize_list, listSize_cons, valSize_encN]
    omega
  have n1 : EvalsVal prog M [encN T, S] [] (.inl (Expr.bin BinOp.cons (Expr.var 0)
      (eGet 1 (Expr.var 1)))) (encL encN (T :: acc)) := by
    have h := ev_cons hT0 k1 (by
      have e : Val.list (encN T :: List.map encN acc) = encL encN (T :: acc) := rfl
      rw [e, hlist]
      omega)
    exact h
  have n2 := ev_cast (evN_add k2 hT0 (by omega))
    (show encN (acc.sum + T) = encN (T :: acc).sum by rw [List.sum_cons, Nat.add_comm])
  have hsf4 : Nat.size (f / 4) ≤ Nat.size f := size_le_of_le (Nat.div_le_self _ _)
  have h4 : Nat.size 4 ≤ 3 := Nat.size_le.2 (by norm_num)
  have n4 := evN_div k4 (evN_lit (prog := prog) (env := [encN T, S]) 4 (by omega))
    (by norm_num) (by omega)
  have hnew : valSize (encTS A k (T :: acc)) ≤ Nat.size (k + 1) + Nat.size T + 2 +
      valSize (encL encN acc) + (max (Nat.size acc.sum) (Nat.size T) + 1) + Nat.size A +
      Nat.size f + 10 := by
    have hs2 : Nat.size (T :: acc).sum ≤ max (Nat.size acc.sum) (Nat.size T) + 1 := by
      rw [List.sum_cons, Nat.add_comm]
      exact hsum
    have hf4 : Nat.size (2 ^ (2 * k) / 4) ≤ Nat.size f := hsf4
    simp only [encTS, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    rw [hlist]
    omega
  have hin : EvalsVal prog M [encN T, S] [] (.inl (eList
      [Expr.bin BinOp.sub (eGet 0 (Expr.var 1)) (Expr.lit 1),
        Expr.bin BinOp.cons (Expr.var 0) (eGet 1 (Expr.var 1)),
        Expr.bin BinOp.add (eGet 2 (Expr.var 1)) (Expr.var 0), eGet 3 (Expr.var 1),
        Expr.bin BinOp.div (eGet 4 (Expr.var 1)) (Expr.lit 4)])) (encTS A k (T :: acc)) := by
    refine ev_list (.cons n0 (.cons n1 (.cons n2 (.cons k3 (.cons n4 .nil))))) ?_
    rw [← encTS]
    have := max_le (show Nat.size acc.sum ≤ Nat.size acc.sum + Nat.size T from by omega)
      (show Nat.size T ≤ Nat.size acc.sum + Nat.size T from by omega)
    omega
  refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons hin .nil)) ?_
  have := max_le (show Nat.size acc.sum ≤ Nat.size acc.sum + Nat.size T from by omega)
    (show Nat.size T ≤ Nat.size acc.sum + Nat.size T from by omega)
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one]
  omega

/-- **The list of caps.** From `k ≤ p` (with the suffix `drop k` already built), the loop returns
`[[T_0^max, …, T_{p-1}^max], ∑ T_j^max]`. -/
theorem apT_loop (hb : prog[Cost.Idx.apTStep]? = some body_apTStep) (eA : ℕ)
    (hM : adaP eA * (Nat.size (tmA eA) + 2) + 4 * Nat.size (tmA eA) + 8 * adaP eA + 60 ≤ M) :
    ∀ k, k ≤ adaP eA → ∃ out,
      out = Val.list [encL encN (adaTmaxList eA), encN (adaTmaxList eA).sum] ∧
      EvalsVal prog M [] [] (.inr (Cost.Idx.apTStep,
        encTS (tmA eA) k ((adaTmaxList eA).drop k))) out := by
  set L := adaTmaxList eA with hL
  set A := tmA eA with hA
  set p := adaP eA with hp
  have hLlen : L.length = p := adaTmaxList_length eA
  have hA1 : 1 ≤ A := tmA_pos eA
  have hsumL : L.sum ≤ p * A := adaTmaxList_sum_le eA
  have hsizesum : Nat.size L.sum ≤ Nat.size p + Nat.size A :=
    (size_le_of_le hsumL).trans (size_mul_le p A)
  -- bounds of a state
  have hstate : ∀ k, k ≤ p → valSize (encTS A k (L.drop k)) ≤
      Nat.size p + p * (Nat.size A + 2) + 2 * Nat.size A + Nat.size p + 2 * p + 13 := by
    intro k hk
    have h1 : valSize (encL encN (L.drop k)) ≤ 1 + (L.drop k).length * (Nat.size A + 2) :=
      valSize_encL_le encN (L.drop k) (Nat.size A + 1) (fun x hx => by
        rw [valSize_encN]
        have := size_le_of_le (mem_adaTmaxList_le (List.mem_of_mem_drop hx))
        rw [← hA] at this
        omega)
    have h2 : (L.drop k).length * (Nat.size A + 2) ≤ p * (Nat.size A + 2) :=
      Nat.mul_le_mul_right _ (by rw [List.length_drop]; omega)
    have h3 : (L.drop k).sum ≤ L.sum := by
      conv_rhs => rw [← List.take_append_drop k L]
      rw [List.sum_append]
      omega
    have h4 := size_le_of_le h3
    have h5 := size_four_pow_div_le k
    have h6 : Nat.size k ≤ Nat.size p := size_le_of_le hk
    simp only [encTS, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hb
    (fun k => encTS A k (L.drop k)) (fun _ => []) (fun k => k ≤ p)
    (fun out => out = Val.list [encL encN L, encN L.sum]) (fun k => k) ?_
  · intro k hk
    obtain ⟨out, h1, h2⟩ := key k hk
    exact ⟨out, h1, h2⟩
  · intro k hk
    have hsk := hstate k hk
    have hsp : Nat.size p ≤ p := size_le_self' p
    cases k with
    | zero =>
      left
      refine ⟨Val.list [encL encN L, encN L.sum], ?_, rfl⟩
      have h := apTStep_stop (prog := prog) (M := M) A (L.drop 0) (by omega)
      simpa only [List.drop_zero] using h
    | succ k =>
      right
      have hkp : k < p := by omega
      have hk' : k < L.length := by omega
      have hTk : (A + 2 ^ (2 * k) - 1) / 2 ^ (2 * k) = L[k] := by
        rw [adaTmaxList_getElem hk', adaTmax_eq hkp]
      have hdrop : L.drop k = L[k] :: L.drop (k + 1) := List.drop_eq_getElem_cons hk'
      have h := apTStep_cont (prog := prog) (M := M) A k (L.drop (k + 1)) hA1 (by omega)
      rw [hTk, ← hdrop] at h
      exact ⟨1, k, [], one_ne_zero, rfl, h, by omega, by omega⟩

end

end F2e2e.C.Impl.AP
