import F2e2e.C.Impl.ParamsSeg
import F2e2e.C.Impl.ParamsSegE
import F2e2e.C.Impl.ParamsSegF

/-!
# W1 (public parameters, DSL), part 5: the master routine and the single-parameter routines

Owner: C-PARAMS (e26ae4ae).

* `w1All_evals`: the master routine `body_w1All` (index `449`) maps `encStreamParams P` to
  `(outs P).map encN`, every value of size `≤ M`, for `ParamsOK P` and `M ≥ 2^37 ℒ³` (composition of the
  six segments `segA_ok`, …, `segF_ok` of `F2e2e/C/Impl/ParamsSeg{,E,F}.lean` with `chain_evals`);
* `outs_le`, `outs_valSize_le`: the outputs are `≤ 2^{8ℒ³}`, their list has size `≤ M`;
* `param_spec`: the routine `body_param k = eNth k (call 449 (var 0))` satisfies C-TOP's `ParamSpec` for
  the reference function `f` as soon as `(outs P)[k]? = some (f P)`.
-/

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

/-- Every output of the master routine is `≤ A = 2^{8ℒ³}`. -/
theorem outs_le (P : StreamParams) : ∀ x ∈ outs P, x ≤ Abnd P := by
  refine List.forall_iff_forall_mem.mp ?_
  exact ⟨H_le_Abnd P, eHC_le_A P, eHP_le_A P, eHleaf_le_A P, eHg_le_A P, eHstep_le_A P,
    eEta_le_A P, eGamma_le_A P, Jstar_le_A P, K0_le_A P, Kepoch_le_A P, Amax_le_A P, Cmax_le_A P,
    q_le_A P, B_le_Abnd P, W_le_Abnd P, eHb_le_A P, Zmax_le_A P, Dstar_le_A P, eSigma_le_A P,
    eOmega_le_A P, L_le_A P, w_le_A P, irrW_le_A P, s_le_A P, gCoarse_le_A P, Rmax_le_A P,
    eBankA_le_A P, eBankXi_le_A P, m_le_A P, Jmax_le_A P, Rmax_le_A P, seedTrials_le_A P⟩

/-- The output list of the master routine has size `≤ 264ℒ³ + 100 ≤ M`. -/
theorem outs_valSize_le (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    valSize (Val.list ((outs P).map encN)) ≤ M := by
  have h := valSize_map_encN_le (Abnd P) (outs P) (outs_le P)
  have hlen : (outs P).length = 33 := rfl
  have hs : Nat.size (Abnd P) = 8 * P.calL ^ 3 + 1 := by rw [Abnd, Nat.size_pow]
  rw [hlen, hs] at h
  have := calL_cube_ge P
  omega

/-- **The master routine** (index `449`): `encStreamParams P ↦ (outs P).map encN`. -/
theorem w1All_evals (hlib : W1Lib prog) (P : StreamParams) (hP : C.Top.ParamsOK P)
    (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_w1All) (Val.list ((outs P).map encN)) := by
  have hA := four096_le_Abnd P
  have hM16 := valSize_Abnd_pow_le (M := M) hM
  have hF := chain_evals (prog := prog) (M := M) [encStreamParams P] hA hM16
  exact hF segA (valsA P) [] _ _ (segA_ok P hM) (by simp)
    (fun h1 => hF segB (valsB P) _ _ _ (segB_ok hlib P hM) h1
      (fun h2 => hF segC (valsC P) _ _ _ (segC_ok hlib P hM) h2
        (fun h3 => hF segD (valsD P) _ _ _ (segD_ok hlib P hM) h3
          (fun h4 => hF segE (valsE P) _ _ _ (segE_ok hlib P hM) h4
            (fun h5 => hF segF (valsF P) _ _ _ (segF_ok hlib P hP hM) h5
              (fun _ => eVars_evals outIdx _ rfl (outs_valSize_le P hM)))))))

/-- **The single-parameter routines** (`body_param k` at index `idx`). -/
theorem param_spec (R : AdaRep) (hlib : W1Lib prog) (k : ℕ) {idx : ℕ} {f : StreamParams → ℕ}
    (hidx : prog[idx]? = some (body_param k)) (hk : ∀ P, (outs P)[k]? = some (f P)) :
    ParamSpec R prog M idx f := by
  refine ⟨body_param k, hidx, fun P hP hMv => ?_⟩
  have hM : 2 ^ 37 * P.calL ^ 3 ≤ M := (W2.calL_cube_le_Mv R P).trans hMv
  have hc : EvalsVal prog M [encStreamParams P] [] (.inl (Expr.call Idx.w1All (Expr.var 0)))
      (Val.list ((outs P).map encN)) :=
    call0 (EvalsVal.var rfl) hlib.all (w1All_evals hlib P hP hM)
  exact eNth_evals hc (outs_valSize_le P hM) (by rw [List.getElem?_map, hk P]; rfl)

end W1

end F2e2e.C.Impl
