import F2e2e.C.Impl.W6Contracts
import F2e2e.Cost.ValRules
import F2e2e.Cost.Lib.MapB

/-!
# W6 helpers: list access and list construction in `EvalsVal` form

* `eGet k e` = `head (tail^k e)`: the `k`-th element of the list value of `e` (`ev_get`);
* `eList [e₁, …, eₙ]` = `cons e₁ (… (cons eₙ nil))`: the list of the values (`ev_list`, deterministic
  elements);
* size facts for sublists (`valSize_tail_le`, `valSize_of_getElem?_le`).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.Discrete

/-- The `k`-th element of a list: `head (tail^k e)`. -/
def eGet : ℕ → Expr → Expr
  | 0, e => Expr.un UnOp.head e
  | k + 1, e => eGet k (Expr.un UnOp.tail e)

/-- A list literal: `[e₁, …, eₙ]`. -/
def eList : List Expr → Expr
  | [] => Expr.nil
  | e :: es => Expr.bin BinOp.cons e (eList es)

theorem valSize_tail_le (x : Val) (l : List Val) :
    valSize (Val.list l) ≤ valSize (Val.list (x :: l)) := by
  simp only [valSize_list, listSize_cons]
  omega

theorem valSize_head_le (x : Val) (l : List Val) : valSize x ≤ valSize (Val.list (x :: l)) :=
  le_of_lt (valSize_lt_of_mem List.mem_cons_self)

theorem valSize_of_getElem?_le {l : List Val} {k : ℕ} {v : Val} (h : l[k]? = some v) :
    valSize v ≤ valSize (Val.list l) :=
  le_of_lt (valSize_lt_of_mem (List.mem_of_getElem? h))

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-- **Element access.** -/
theorem ev_get {bits : List Bool} :
    ∀ (k : ℕ) {e : Expr} {l : List Val} {v : Val},
      EvalsVal prog M env bits (.inl e) (Val.list l) → valSize (Val.list l) ≤ M →
        l[k]? = some v → EvalsVal prog M env bits (.inl (eGet k e)) v
  | 0, e, l, v, h, hM, hk => by
    cases l with
    | nil => simp at hk
    | cons x l' =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hk
      subst hk
      exact EvalsVal.head h ((valSize_head_le _ l').trans hM)
  | k + 1, e, l, v, h, hM, hk => by
    cases l with
    | nil => simp at hk
    | cons x l' =>
      simp only [List.getElem?_cons_succ] at hk
      have ht := EvalsVal.tail h ((valSize_tail_le x l').trans hM)
      exact ev_get k ht ((valSize_tail_le x l').trans hM) hk

/-- **List construction** (deterministic elements). -/
theorem ev_list :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsVal prog M env [] (.inl e) v) es vs →
        valSize (Val.list vs) ≤ M → EvalsVal prog M env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsVal.nil hM
  | e :: es, v :: vs, List.Forall₂.cons he hrest, hM => by
    have hr := ev_list hrest ((valSize_tail_le v vs).trans hM)
    have h := EvalsVal.cons he hr hM
    rw [List.append_nil] at h
    simp only [eList]
    exact h

end rules

/-! ## Deterministic `letE`, `ite`, `pure` -/

/-- A deterministic `letE`. -/
theorem ev_letE {prog : List Expr} {M : ℕ} {env : List Val} {a b : Expr} {va vb : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : EvalsVal prog M (va :: env) [] (.inl b) vb) :
    EvalsVal prog M env [] (.inl (Expr.letE a b)) vb := by
  simpa using EvalsVal.letE ha hb

/-- A deterministic `ite` on a Boolean flag. -/
theorem ev_ite_encB {prog : List Expr} {M : ℕ} {env : List Val} {c t f : Expr} {b : Bool} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (encB b))
    (hb : EvalsVal prog M env [] (.inl (if b then t else f)) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v := by
  have h := EvalsVal.ite (prog := prog) (M := M) (env := env) (t := t) (f := f) (z := if b then 1 else 0)
    hc (by cases b <;> simpa using hb)
  simpa using h

/-- Implementations of `pure` are deterministic evaluations. -/
theorem Implements.toVal_pure {prog : List Expr} {M : ℕ} {env : List Val} {e : Expr} {α : Type}
    {enc : α → Val} {a : α} (h : Implements prog M env e enc (BitProg.pure a)) :
    EvalsVal prog M env [] (.inl e) (enc a) :=
  h [] a rfl

theorem mapB_pure_eq {α β : Type} (g : α → β) :
    ∀ l : List α, mapB (fun x => BitProg.pure (g x)) l = BitProg.pure (l.map g)
  | [] => rfl
  | x :: xs => by
    simp only [mapB, BitProg.bind_pure', List.map_cons]
    rw [mapB_pure_eq g xs]
    rfl

/-! ## Deterministic forms of the arithmetic rules -/

section detRules

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_add {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.add a b)) (Val.int (x + y)) :=
  EvalsVal.add ha hb hM

theorem ev_mul {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x * y)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.mul a b)) (Val.int (x * y)) :=
  EvalsVal.mul ha hb hM

theorem ev_eq {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.eq a b)) (Val.int (if x = y then 1 else 0)) :=
  EvalsVal.eq ha hb hM

end detRules

end F2e2e.C.Impl.W6
