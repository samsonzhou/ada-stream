import F2e2e.C.Impl.AdaPrepRef
import F2e2e.C.Impl.AdaInit

/-!
# ADA module (W4): the interval interface `adaInterval` (Idx 602), routines

Owner: W2 (a2ff64c3), for W4 (cc77ceaa). Reference: `adaInterval A st vals l u =
(adaIntervalD A st vals l u).toBits (adaDraw A)` (`F2e2e/B/ArchCore.lean` L262–293, L350–352):
enforce the cap `M` (and halting), run `PrepareRoot` from `{st with nInt := nInt + 1}` with an empty
cache, then the outer test with two fresh directed noises (kind `outTest`) and, on a rejection,
`outerReject` (a fresh outer threshold of kind `outThr`, or the terminal rejection).

DSL routines (indices in W2's share 606–609 of W4's range):

| idx | body | input | output |
|---|---|---|---|
| 602 | `body_adaInterval` | `[pub, st, vals, l, u]` | `[cert, st']` |
| 606 | `body_adaIvOuter` | `[pub, st2, vals, l, u]` (after `PrepareRoot`) | `[cert, st']` |
| 607 | `body_adaIvReject` | `[pub, st, high]` | `[cert, st']` (`outerReject`) |
| 608 | `body_adaIvRound` | `[x, 2^qA]` | `roundIdxQ h_A (clip_{[-1,2]} x)` |

Called routines: B-NUM's `adaPrepR` (700, `adaPrepTable`), W4's `adaMusR` (640), the sampler
(`eDraw`, `SampLib`) and the library list routines `set`, `replicate` (`ListLib`).

Integer forms of the outer tests (`h_A = 1/H`, `H = 2^{qA}`, `a/2 = an/ad`, `μ_0 = N/D` with `D > 0`,
`ũ = h_A U`, `l̃ = h_A Lr`, all multiplied by `H · ad · D > 0`):
* HIGH: `a/2 + h_A ϑ ≤ μ_0 − ũ + h_A k_H ⟺ an H D + ϑ ad D ≤ N ad H − U ad D + k_H ad D`;
* LOW:  `a/2 + h_A ϑ ≤ l̃ − μ_0 + h_A k_L ⟺ an H D + ϑ ad D ≤ Lr ad D − N ad H + k_L ad D`.
-/

namespace F2e2e.Cost.Idx

/-- `adaIvOuter : [pub, st2, vals, l, u] ↦ [cert, st']`: the outer test after `PrepareRoot`. -/
abbrev adaIvOuter : ℕ := 606
/-- `adaIvReject : [pub, st, high] ↦ [cert, st']`: an outer rejection (`outerReject`). -/
abbrev adaIvReject : ℕ := 607
/-- `adaIvRound : [x, 2^qA] ↦ roundIdxQ h_A (clipQ (-1) 2 x)`. -/
abbrev adaIvRound : ℕ := 608

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## The routines -/

/-- **`adaIvRound`** (Idx 608), environment `[[[xn, xd], H]]`: the lattice index of the endpoint `x`
clipped to `[-1, 2]`: `2H` if `2 xd < xn`, `-H` if `xn < -xd`, else `⌊(2 xn H + xd)/(2 xd)⌋`. -/
def body_adaIvRound : Expr :=
  eIte (eLt (eMul (eLit 2) (eAtN 1 (eAtN 0 (eV 0)))) (eAtN 0 (eAtN 0 (eV 0))))
    (eMul (eLit 2) (eAtN 1 (eV 0)))
    (eIte (eLt (eAtN 0 (eAtN 0 (eV 0))) (eSub (eLit 0) (eAtN 1 (eAtN 0 (eV 0)))))
      (eSub (eLit 0) (eAtN 1 (eV 0)))
      (eDiv (eAdd (eMul (eMul (eLit 2) (eAtN 0 (eAtN 0 (eV 0)))) (eAtN 1 (eV 0)))
          (eAtN 1 (eAtN 0 (eV 0))))
        (eMul (eLit 2) (eAtN 1 (eAtN 0 (eV 0))))))

/-- **`adaIvReject`** (Idx 607), environment `[[pub, st, high]]` (`high` as `encB`): the state with
`rej + 1`; if `rej < J` a fresh outer threshold (kind `outThr`) and the certificate `2 - high`
(`HIGH = 1`, `LOW = 2`), otherwise `halted` and the terminal certificate `4 - high`. -/
def body_adaIvReject : Expr :=
  eLet (eCall Idx.set (eList [eAtN 1 (eV 0), eLit 4, eAdd (eAtN 4 (eAtN 1 (eV 0))) (eLit 1)]))
  (eIte (eLt (eAtN 4 (eAtN 1 (eV 1))) (eAtN 5 (eAtN 0 (eV 1))))
    (eLet (eDraw NoiseKind.outThr (eAtN 0 (eV 1)))
      (ePair (eSub (eLit 2) (eAtN 2 (eV 2))) (eCall Idx.set (eList [eV 1, eLit 3, eV 0]))))
    (ePair (eSub (eLit 4) (eAtN 2 (eV 1))) (eCall Idx.set (eList [eV 0, eLit 7, eLit 1]))))

/-- The left-hand side `an H D + ϑ ad D` of both outer tests, in the environment
`[kL, kH, U, Lr, mus, inp]`. -/
def ivLhs : Expr :=
  eAdd (eMul (eMul (eAtN 0 (eAtN 10 (eAtN 0 (eV 5)))) (eAtN 8 (eAtN 0 (eV 5))))
      (eAtN 1 (eHd (eV 4))))
    (eMul (eMul (eAtN 3 (eAtN 1 (eV 5))) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5))))) (eAtN 1 (eHd (eV 4))))

/-- The right-hand side `N ad H − U ad D + k_H ad D` of the HIGH test. -/
def ivRhsH : Expr :=
  eAdd (eSub (eMul (eMul (eAtN 0 (eHd (eV 4))) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5)))))
        (eAtN 8 (eAtN 0 (eV 5))))
      (eMul (eMul (eV 2) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5))))) (eAtN 1 (eHd (eV 4)))))
    (eMul (eMul (eV 1) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5))))) (eAtN 1 (eHd (eV 4))))

/-- The right-hand side `Lr ad D − N ad H + k_L ad D` of the LOW test. -/
def ivRhsL : Expr :=
  eAdd (eSub (eMul (eMul (eV 3) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5))))) (eAtN 1 (eHd (eV 4))))
      (eMul (eMul (eAtN 0 (eHd (eV 4))) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5)))))
        (eAtN 8 (eAtN 0 (eV 5)))))
    (eMul (eMul (eV 0) (eAtN 1 (eAtN 10 (eAtN 0 (eV 5))))) (eAtN 1 (eHd (eV 4))))

/-- **`adaIvOuter`** (Idx 606), environment `[[pub, st2, vals, l, u]]`: the predictions of `st2`
(`adaMusR`), the lattice indices `Lr, U` of the clipped endpoints, two fresh directed noises
`k_H, k_L` (kind `outTest`), then HIGH (priority), LOW or ACCEPT. -/
def body_adaIvOuter : Expr :=
  eLet (eCall Idx.adaMusR (eList [eAtN 0 (eV 0), eAtN 0 (eAtN 1 (eV 0)), eAtN 2 (eV 0)]))
  (eLet (eCall Idx.adaIvRound (ePair (eAtN 3 (eV 1)) (eAtN 8 (eAtN 0 (eV 1)))))
  (eLet (eCall Idx.adaIvRound (ePair (eAtN 4 (eV 2)) (eAtN 8 (eAtN 0 (eV 2)))))
  (eLet (eDraw NoiseKind.outTest (eAtN 0 (eV 3)))
  (eLet (eDraw NoiseKind.outTest (eAtN 0 (eV 4)))
    (eIte (eLt ivRhsH ivLhs)
      (eIte (eLt ivRhsL ivLhs)
        (ePair (eLit 0) (eAtN 1 (eV 5)))
        (eCall Idx.adaIvReject (eList [eAtN 0 (eV 5), eAtN 1 (eV 5), eLit 0])))
      (eCall Idx.adaIvReject (eList [eAtN 0 (eV 5), eAtN 1 (eV 5), eLit 1])))))))

/-- **`adaInterval`** (Idx 602), environment `[[pub, st, vals, l, u]]`: abort (state unchanged) if
halted or `M ≤ nInt`; otherwise `PrepareRoot` (`adaPrepR`, fuel `A.fuel`) from
`{st with nInt := nInt + 1}` and the empty cache `replicate p false`; on `CAP_ABORT` the state with
`halted`, `capAborted` set; otherwise the outer test (`adaIvOuter`). -/
def body_adaInterval : Expr :=
  eLet (eAtN 1 (eV 0))
  (eIte (eAtN 7 (eV 0))
    (ePair (eLit 5) (eV 0))
    (eIte (eLt (eAtN 5 (eV 0)) (eAtN 4 (eAtN 0 (eV 1))))
      (eLet (eCall Idx.set (eList [eV 0, eLit 5, eAdd (eAtN 5 (eV 0)) (eLit 1)]))
        (eLet (eCall Idx.adaPrepR (eList [eAtN 3 (eAtN 0 (eV 2)), eV 0,
            eCall Idx.replicate (ePair (eAtN 0 (eAtN 0 (eV 2))) (eLit 0)), eAtN 0 (eV 2),
            eAtN 2 (eV 2)]))
          (eIte (Expr.un UnOp.isNil (eV 0))
            (ePair (eLit 5)
              (eCall Idx.set (eList [eCall Idx.set (eList [eV 1, eLit 7, eLit 1]), eLit 8, eLit 1])))
            (eCall Idx.adaIvOuter (eList [eAtN 0 (eV 3), eHd (eV 0), eAtN 2 (eV 3), eAtN 3 (eV 3),
              eAtN 4 (eV 3)])))))
      (ePair (eLit 5) (eV 0))))

/-- **The routines of `adaInterval`** (`(index, body)`): the entry 602 and the helpers 606–608. The
other routines it calls are in `adaPrepTable` (B-NUM), `MusLib` (W4's `adaMusR`), `SampLib` and
`ListLib`. -/
def adaEntryTable : List (ℕ × Expr) :=
  [(Idx.adaInterval, body_adaInterval), (Idx.adaIvOuter, body_adaIvOuter),
    (Idx.adaIvReject, body_adaIvReject), (Idx.adaIvRound, body_adaIvRound)]

end F2e2e.C.Impl
