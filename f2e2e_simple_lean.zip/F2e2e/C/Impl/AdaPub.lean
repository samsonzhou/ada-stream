import F2e2e.C.Impl.AdaPubCore

/-!
# ADA module (W4), the parameter record: `adaPub` (600), `adaQA` (604), `adaBlockSizes` (605)

Owner: W2 (a2ff64c3), for W4 (cc77ceaa). The routine `adaPub` computes W4's parameter record
`adaPubEnc (bankAda P)` (`F2e2e/C/Impl/AdaRep.lean`) from `encStreamParams P`, through W1's parameter
routines `peBankA`, `peBankXi`, `pbankM`, `pbankJ`, `pbankR` and W5's `normQ` (canonical rationals);
`adaQA` and `adaBlockSizes` project fields of it.

* the bodies and the table `adaPubTable` (entries 600, 604, 605, the helpers 650–657 and the library
  routines `pow2`, `clog2`, `natSqrt`): `F2e2e/C/Impl/AdaPubBody.lean`;
* the correctness of the body (`adaPub_core`): `F2e2e/C/Impl/AdaPubCore.lean`, from the helpers in
  `F2e2e/C/Impl/AdaPub{Math,Ev,Loops,Blocks,NB,BLoop,Samp}.lean` (namespace `F2e2e.C.Impl.AP`);
* here: `adaPub_eval`, `adaQA_eval`, `adaBlockSizes_eval`, the three `EvalsVal` specs used by W4's
  `w4Contract`, for `ParamsOK P` and `Mv adaRep P ≤ M`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.C.Impl.W6
  F2e2e.C.Impl.AP

/-! ## Specs -/

/-- The parameter record and its size (both from `adaPub_core`). -/
theorem adaPub_eval_size {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2)
    (hw1 : W1Contract adaRep prog M) (hq : NormQSpec prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv adaRep P ≤ M) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_adaPub) (adaPubEnc (bankAda P)) ∧
      valSize (adaPubEnc (bankAda P)) ≤ M := by
  have get : ∀ (k : ℕ) (hk : k < adaPubTable.length),
      prog[(adaPubTable[k]).1]? = some (adaPubTable[k]).2 :=
    fun k hk => hlib _ (List.getElem_mem hk)
  have hlen : adaPubTable.length = 17 := rfl
  have hBL : BlkLib prog := ⟨get 5 (by omega), get 6 (by omega), get 8 (by omega),
    get 9 (by omega), get 15 (by omega), get 16 (by omega)⟩
  obtain ⟨-, hML⟩ := Mv_adaRep_ge hM
  obtain ⟨bA, hbA, sA⟩ := hw1.peBankA
  obtain ⟨bX, hbX, sX⟩ := hw1.peBankXi
  obtain ⟨bM, hbM, sM⟩ := hw1.pbankM
  obtain ⟨bJ, hbJ, sJ⟩ := hw1.pbankJ
  obtain ⟨bR, hbR, sR⟩ := hw1.pbankR
  have heA4 : 4 ≤ P.eBankA := by unfold StreamParams.eBankA; omega
  have hcaps : P.bankM + P.bankJ + P.bankR + 2 ≤ 2 ^ (5 * P.calL + 14) :=
    (Nat.clog_le_iff_le_pow (by norm_num)).1 (clog_bank_caps_le P)
  have hχ : adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi ≤ 56 * P.calL + 82 := by
    have h1 := adaChi_le_of_four_le P.bankM P.bankJ P.bankR P.eBankXi heA4
    have h2 : Nat.clog 2 (P.bankM + P.bankJ + P.bankR + 2) ≤ 5 * P.calL + 14 :=
      clog_bank_caps_le P
    have h3 := eBankA_le P
    have h4 := eBankXi_le P
    omega
  have hN : (adaBlockSizes P.bankM P.bankJ P.bankR P.eBankA P.eBankXi).sum <
      2 ^ (11 * P.calL + 199) := by
    have h1 : (adaBlockSizes P.bankM P.bankJ P.bankR P.eBankA P.eBankXi).sum ≤
        2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := (adaRows_le P).1
    have h2 := eEta_le P
    have h3 : 2 ^ (2 * P.eEta) ≤ 2 ^ (4 * P.calL) := Nat.pow_le_pow_right (by norm_num) (by omega)
    have h4 : P.calL ^ 7 < (2 ^ P.calL) ^ 7 :=
      Nat.pow_lt_pow_left Nat.lt_two_pow_self (by norm_num)
    have h5 : (2 ^ P.calL) ^ 7 = 2 ^ (7 * P.calL) := by rw [← pow_mul, mul_comm]
    calc (adaBlockSizes P.bankM P.bankJ P.bankR P.eBankA P.eBankXi).sum
        ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := h1
      _ < 2 ^ 199 * 2 ^ (4 * P.calL) * 2 ^ (7 * P.calL) := by
          rw [← h5]
          exact Nat.mul_lt_mul_of_le_of_lt (Nat.mul_le_mul_left _ h3) h4 (by positivity)
      _ = 2 ^ (11 * P.calL + 199) := by
          rw [← pow_add, ← pow_add]; ring_nf
  exact adaPub_core hBL (get 3 (by omega)) (get 4 (by omega)) (get 7 (by omega))
    (get 10 (by omega)) (get 11 (by omega)) (get 12 (by omega)) (get 13 (by omega))
    (get 14 (by omega)) hq hbA hbX hbM hbJ hbR (sA P hP hM) (sX P hP hM) (sM P hP hM)
    (sJ P hP hM) (sR P hP hM) (hundred_le_calL P) hML (eBankA_le P) heA4 (eBankXi_le P) hcaps hχ hN

/-- **The parameter record.** -/
theorem adaPub_eval {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2)
    (hw1 : W1Contract adaRep prog M) (hq : NormQSpec prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv adaRep P ≤ M) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_adaPub) (adaPubEnc (bankAda P)) :=
  (adaPub_eval_size hlib hw1 hq hP hM).1

/-- The record fits in the value bound. -/
theorem adaPub_valSize_le {P : StreamParams} {M : ℕ} {prog : List Expr}
    (hlib : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2) (hw1 : W1Contract adaRep prog M)
    (hq : NormQSpec prog M) (hP : ParamsOK P) (hM : Mv adaRep P ≤ M) :
    valSize (adaPubEnc (bankAda P)) ≤ M :=
  (adaPub_eval_size hlib hw1 hq hP hM).2

/-- **The lattice exponent `q_A`.** -/
theorem adaQA_eval {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2)
    (hw1 : W1Contract adaRep prog M) (hq : NormQSpec prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv adaRep P ≤ M) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_adaQA) (Val.int ((bankAda P).qA : ℤ)) := by
  have h600 : prog[Idx.adaPub]? = some body_adaPub := hlib _ (List.getElem_mem (n := 0) (by
    show 0 < adaPubTable.length; rw [show adaPubTable.length = 17 from rfl]; omega))
  have hc := ev_call h600 (EvalsVal.var (env := [encStreamParams P]) (i := 0) rfl)
    (adaPub_eval hlib hw1 hq hP hM)
  exact ev_get 7 hc (adaPub_valSize_le hlib hw1 hq hP hM) rfl

/-- **The block sizes `[n_0, …, n_p]`.** -/
theorem adaBlockSizes_eval {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2)
    (hw1 : W1Contract adaRep prog M) (hq : NormQSpec prog M) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv adaRep P ≤ M) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_adaBlockSizes)
      (encL encN (bankAda P).blockSizes) := by
  have h600 : prog[Idx.adaPub]? = some body_adaPub := hlib _ (List.getElem_mem (n := 0) (by
    show 0 < adaPubTable.length; rw [show adaPubTable.length = 17 from rfl]; omega))
  have hc := ev_call h600 (EvalsVal.var (env := [encStreamParams P]) (i := 0) rfl)
    (adaPub_eval hlib hw1 hq hP hM)
  exact ev_get 1 hc (adaPub_valSize_le hlib hw1 hq hP hM) rfl

end F2e2e.C.Impl
