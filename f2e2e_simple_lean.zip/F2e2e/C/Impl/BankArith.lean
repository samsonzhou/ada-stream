import F2e2e.C.Impl.BankRules

/-!
# W5: the arithmetic helpers (`bkSat`, `bkRDiv`, Euclid's `normQ`)

* `bkSat_val`: `[Z, z] ↦ sat Z z` (`Z ≥ 0`);
* `bkRDiv_val`: `[n, d] ↦ rdivZ n d = (2n + d)/(2d)` (`= ⌊n/d + 1/2⌋`, `rdivZ_eq`);
* `gcd_loop`, `normQ_val`: `[a, b] ↦ encQ (a / b)` for `b > 0` (C-TOP's `NormQSpec`).
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-- Rounding of `n/d` to the nearest integer, ties up: `(2n + d)/(2d)`. -/
def rdivZ (n d : ℤ) : ℤ := (2 * n + d) / (2 * d)

theorem rdivZ_eq (n d : ℤ) (hd : 0 < d) : rdivZ n d = ⌊((n : ℚ) / (d : ℚ)) + 1 / 2⌋ := by
  have h := roundMantZ_eq 0 n d hd
  simp only [roundMantZ, pow_zero, mul_one] at h
  simpa [rdivZ] using h

theorem rdivZ_eq_roundMant (n d : ℤ) (hd : 0 < d) :
    rdivZ n d = roundMant 0 ((n : ℚ) / (d : ℚ)) := by
  rw [rdivZ_eq n d hd]
  simp [roundMant]

/-- `rdivZ n 1 = n`. -/
theorem rdivZ_one (n : ℤ) : rdivZ n 1 = n := by
  unfold rdivZ
  omega

theorem bitLen_two_mul_le (a : ℤ) : bitLen (2 * a) ≤ bitLen a + 2 := by
  have := bitLen_mul_le' 2 a
  rw [bitLen_two_eq] at this
  omega

theorem bitLen_rdivZ_le (n d : ℤ) : bitLen (rdivZ n d) ≤ bitLen n + bitLen d + 3 := by
  unfold rdivZ
  have h1 := bitLen_ediv_le (2 * n + d) (2 * d)
  have h2 := bitLen_add_le (2 * n) d
  have h3 := bitLen_two_mul_le n
  have h4 : max (bitLen (2 * n)) (bitLen d) ≤ bitLen n + bitLen d + 2 := by
    rw [max_le_iff]; constructor <;> omega
  omega

section rules

variable {prog : List Expr} {M : ℕ}

/-! ## `bkSat` -/

theorem bkSat_val (Z z : ℤ) (hZ : 0 ≤ Z) (hM : 4 * (bitLen Z + bitLen z) + 20 ≤ M) :
    EvalsVal prog M [Val.list [Val.int Z, Val.int z]] [] (.inl body_bkSat)
      (Val.int (sat Z z)) := by
  by_cases h1 : Z < z
  · have hr : sat Z z = Z := by
      unfold sat; rw [min_eq_left h1.le, max_eq_right (by omega)]
    rw [hr]
    apply EvalsVal.of_eval (base := 0) 20
    simp only [body_bkSat, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un,
      eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
      List.getElem?_cons_zero, List.getElem?_cons_succ, h1, if_true, ne_eq, one_ne_zero,
      not_false_eq_true]
    refine ⟨_, _, rfl, ?_⟩
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_one,
      zero_add]
    omega
  · by_cases h2 : z < -Z
    · have hr : sat Z z = -Z := by
        unfold sat; rw [min_eq_right (by omega), max_eq_left (by omega)]
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_bkSat, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un,
        eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, zero_sub, h2, if_true, if_false,
        ne_eq, one_ne_zero, not_false_eq_true, not_true_eq_false]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_one,
        bitLen_zero, bitLen_neg, zero_add]
      omega
    · have hr : sat Z z = z := by
        unfold sat; rw [min_eq_right (by omega), max_eq_right (by omega)]
      rw [hr]
      apply EvalsVal.of_eval (base := 0) 20
      simp only [body_bkSat, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un,
        eval_succ_ite, eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, List.getElem?_cons_succ, h1, zero_sub, h2, if_false, ne_eq,
        not_true_eq_false]
      refine ⟨_, _, rfl, ?_⟩
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_one,
        bitLen_zero, bitLen_neg, zero_add]
      omega

/-! ## `bkRDiv` -/

theorem bkRDiv_val (n d : ℤ) (hd : 0 < d) (hM : 6 * (bitLen n + bitLen d) + 40 ≤ M) :
    EvalsVal prog M [Val.list [Val.int n, Val.int d]] [] (.inl body_bkRDiv)
      (Val.int (rdivZ n d)) := by
  have h2 : 2 * d ≠ 0 := by omega
  have e1 := bitLen_two_mul_le n
  have e2 := bitLen_two_mul_le d
  have e3 : bitLen (2 * n + d) ≤ bitLen n + bitLen d + 3 := by
    have := bitLen_add_le (2 * n) d
    have h4 : max (bitLen (2 * n)) (bitLen d) ≤ bitLen n + bitLen d + 2 := by
      rw [max_le_iff]; constructor <;> omega
    omega
  have e5 := bitLen_rdivZ_le n d
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_bkRDiv, eval_succ_var, eval_succ_lit, eval_succ_bin, eval_succ_un,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, h2, if_false]
  refine ⟨_, _, rfl, ?_⟩
  simp only [rdivZ] at e5
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_two_eq,
    zero_add]
  omega

/-! ## Euclid's loop and `normQ` -/

/-- Euclid's loop state `[x, y]`. -/
def encGS (s : ℕ × ℕ) : Val := Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ)]

theorem gcdStep_stop {K : ℕ} (x : ℕ) (hx : bitLen (x : ℤ) ≤ K) (hM : 2 * K + 12 ≤ M) :
    EvalsVal prog M [encGS (x, 0)] [] (.inl body_bkGcdStep)
      (Val.list [Val.int 0, Val.int (x : ℤ)]) := by
  have hI : valSize (Val.list [Val.int (x : ℤ), Val.int ((0 : ℕ) : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, Nat.cast_zero, bitLen_zero]
    omega
  have h2 : 2 ≤ M := by omega
  show EvalsVal prog M [Val.list [Val.int (x : ℤ), Val.int ((0 : ℕ) : ℤ)]] [] (.inl body_bkGcdStep) _
  unfold body_bkGcdStep
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_ite_t (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  exact ev_pair (ev_lit (by simp; omega)) (ev_var rfl)
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)

theorem gcdStep_cont {K : ℕ} (x y : ℕ) (hy : y ≠ 0) (hx : bitLen (x : ℤ) ≤ K)
    (hyK : bitLen (y : ℤ) ≤ K) (hM : 2 * K + 12 ≤ M) :
    EvalsVal prog M [encGS (x, y)] [] (.inl body_bkGcdStep)
      (Val.list [Val.int 1, encGS (y, x % y)]) := by
  have hy' : (y : ℤ) ≠ 0 := by exact_mod_cast hy
  have hmod : ((x % y : ℕ) : ℤ) = (x : ℤ) % (y : ℤ) := Int.natCast_mod x y
  have hb : bitLen ((x : ℤ) % (y : ℤ)) ≤ bitLen (y : ℤ) := by
    rw [← hmod]
    exact bitLen_mono_nat (Nat.mod_lt x (Nat.pos_of_ne_zero hy)).le
  have hI : valSize (Val.list [Val.int (x : ℤ), Val.int (y : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have h2 : 2 ≤ M := by omega
  show EvalsVal prog M [Val.list [Val.int (x : ℤ), Val.int (y : ℤ)]] [] (.inl body_bkGcdStep) _
  unfold body_bkGcdStep
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_ite_f (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp [hy]) ?_
  rw [show encGS (y, x % y) = Val.list [Val.int (y : ℤ), Val.int ((x : ℤ) % (y : ℤ))] by
    simp [encGS, hmod]]
  exact ev_pair (ev_lit (by simp; omega))
    (ev_pair (ev_var rfl) (ev_mod (ev_var rfl) (ev_var rfl) hy' (by simp only [valSize_int]; omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)

/-- **Euclid's loop**: from `[x, y]` (naturals of at most `K` bits) the loop returns `gcd x y`. -/
theorem gcd_loop (hstep : prog[Idx.bkGcdStep]? = some body_bkGcdStep) (K : ℕ)
    (hM : 2 * K + 12 ≤ M) (x y : ℕ) (hx : bitLen (x : ℤ) ≤ K) (hy : bitLen (y : ℤ) ≤ K) :
    EvalsVal prog M [] [] (.inr (Idx.bkGcdStep, encGS (x, y))) (Val.int (Nat.gcd x y : ℤ)) := by
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hstep encGS (fun _ => [])
    (fun s => bitLen (s.1 : ℤ) ≤ K ∧ bitLen (s.2 : ℤ) ≤ K ∧ Nat.gcd s.1 s.2 = Nat.gcd x y)
    (fun out => out = Val.int (Nat.gcd x y : ℤ)) (fun s => s.2)
    (by
      rintro ⟨a, b⟩ ⟨ha, hb, hg⟩
      simp only at ha hb hg
      by_cases hb0 : b = 0
      · subst hb0
        left
        refine ⟨Val.int (a : ℤ), gcdStep_stop a ha hM, ?_⟩
        simp only [Nat.gcd_zero_right] at hg
        rw [hg]
      · right
        refine ⟨1, (b, a % b), [], one_ne_zero, rfl, gcdStep_cont a b hb0 ha hb hM, ?_, ?_⟩
        · refine ⟨hb, ?_, ?_⟩
          · exact le_trans (bitLen_mono_nat (Nat.mod_lt a (Nat.pos_of_ne_zero hb0)).le) hb
          · simp only
            rw [← hg, Nat.gcd_comm a b, Nat.gcd_rec b a, Nat.gcd_comm]
        · exact Nat.mod_lt a (Nat.pos_of_ne_zero hb0))
  obtain ⟨out, rfl, h⟩ := key (x, y) ⟨hx, hy, rfl⟩
  exact h

theorem normQ_num_den (a b : ℤ) (hb : 0 < b) :
    ((a : ℚ) / (b : ℚ)).num = a / (Nat.gcd b.natAbs a.natAbs : ℤ) ∧
      (((a : ℚ) / (b : ℚ)).den : ℤ) = b / (Nat.gcd b.natAbs a.natAbs : ℤ) := by
  rw [← Rat.divInt_eq_div]
  constructor
  · rw [Rat.num_divInt, Int.sign_eq_one_of_pos hb, one_mul]
    rfl
  · rw [Rat.den_divInt, if_neg (by omega)]
    have hb' : (b.natAbs : ℤ) = b := Int.natAbs_of_nonneg hb.le
    rw [Int.natCast_div, hb']
    rfl

/-- **`normQ`** (C-TOP's `NormQSpec`): `[a, b] ↦ encQ (a / b)` for `b > 0`. -/
theorem normQ_val (hstep : prog[Idx.bkGcdStep]? = some body_bkGcdStep) (a b : ℤ) (hb : 0 < b)
    (hM : 2 * (bitLen a + bitLen b) + 64 ≤ M) :
    EvalsVal prog M [Val.list [Val.int a, Val.int b]] [] (.inl body_normQ)
      (encQ ((a : ℚ) / (b : ℚ))) := by
  obtain ⟨hnum, hden⟩ := normQ_num_den a b hb
  set g : ℕ := Nat.gcd b.natAbs a.natAbs with hg
  have hgpos : 0 < g := Nat.gcd_pos_of_pos_left _ (by omega)
  have hg0 : (g : ℤ) ≠ 0 := by exact_mod_cast hgpos.ne'
  have hbn : ((b.natAbs : ℕ) : ℤ) = b := Int.natAbs_of_nonneg hb.le
  have han : ((a.natAbs : ℕ) : ℤ) = |a| := Int.natCast_natAbs a
  have hBb : bitLen ((b.natAbs : ℕ) : ℤ) = bitLen b := by rw [hbn]
  have hBa : bitLen ((a.natAbs : ℕ) : ℤ) = bitLen a := by
    rw [han]; unfold bitLen; rw [Int.natAbs_abs]
  have hI : valSize (Val.list [Val.int a, Val.int b]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hq1 : bitLen (a / (g : ℤ)) ≤ bitLen a := bitLen_ediv_le _ _
  have hq2 : bitLen (b / (g : ℤ)) ≤ bitLen b := bitLen_ediv_le _ _
  have h2 : 2 ≤ M := by omega
  -- the tail after `|a|` is bound
  have htail : ∀ aa : ℤ, aa = ((a.natAbs : ℕ) : ℤ) →
      EvalsVal prog M [Val.int aa, Val.int b, Val.int a, Val.list [Val.int a, Val.int b]] []
        (.inl (eLet (eLoop Idx.bkGcdStep (ePair (eV 1) (eV 0)))
          (ePair (eDiv (eV 3) (eV 0)) (eDiv (eV 2) (eV 0)))))
        (encQ ((a : ℚ) / (b : ℚ))) := by
    intro aa haa
    subst haa
    have hinit : EvalsVal prog M [Val.int ((a.natAbs : ℕ) : ℤ), Val.int b, Val.int a,
        Val.list [Val.int a, Val.int b]] [] (.inl (ePair (eV 1) (eV 0)))
        (encGS (b.natAbs, a.natAbs)) := by
      simp only [encGS, hbn]
      exact ev_pair (ev_var rfl) (ev_var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; rw [hBa]; omega)
    have hloop := gcd_loop (M := M) hstep (bitLen a + bitLen b) (by omega) b.natAbs a.natAbs
      (by rw [hBb]; omega) (by rw [hBa]; omega)
    refine ev_let (EvalsVal.loop hinit hloop) ?_
    rw [encQ, hnum, hden]
    refine ev_pair (ev_div (ev_var rfl) (ev_var rfl) hg0 ?_) (ev_div (ev_var rfl) (ev_var rfl) hg0 ?_)
      ?_
    · simp only [valSize_int]; omega
    · simp only [valSize_int]; omega
    · simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  by_cases ha : a < 0
  · refine ev_let (ev_ite_t (ev_lt (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp [ha])
      (ev_neg (ev_var rfl) (by simp only [valSize_int]; omega))) (htail _ ?_)
    rw [han, abs_of_neg ha]
  · refine ev_let (ev_ite_f (ev_lt (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp [ha])
      (ev_var rfl)) (htail _ ?_)
    rw [han, abs_of_nonneg (by omega)]

end rules

end F2e2e.C.Impl.BankDSL
