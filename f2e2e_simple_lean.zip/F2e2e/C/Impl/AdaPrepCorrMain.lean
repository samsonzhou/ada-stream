import F2e2e.C.Impl.AdaPrepRef

/-!
# ADA module (W4), `PrepareRoot` in the DSL: the assembly of a correction `adaCorr` (Idx 702)

Owner: B-NUM (b5a655d4), written at B-ARCH's request (dc387564). B-ARCH's `AdaPrepCorr.lean`
imports this file and supplies the two parts (`adaCorrDet`, Idx 705, and `adaRedraw`, Idx 706).

* `corrIn A st vals j q = [j, avSign q, st, pub, vals]`: the input of `adaCorr` and `adaCorrDet`.
* `redrawIn A j thr = [j, thr, pub]`: the input of `adaRedraw`.
* `body_adaCorrMain` runs three steps:
  1. `let d := call 705 (input)`, the deterministic part `[scores', T']`;
  2. `let t := call 706 [j, st.thrInt, pub]`, the threshold redraws;
  3. return `[d.0, d.1, t, st.thrOut, st.rej, st.nInt, st.nNum, st.halted, st.capAborted]`,
     which is `adaEnc` of the corrected state.
* `adaCorr_of_parts`: given the specs of the two parts, `body_adaCorrMain` implements
  `(applyCorrection A st vals j q).toBits (adaDraw A)` with the state encoding `adaEnc`.
  The reference splitting is `applyCorrection_toBits`: the redraws, then `avState`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- The input of `adaCorr` (Idx 702) and of `adaCorrDet` (Idx 705): `[j, avSign q, st, pub, vals]`. -/
def corrIn (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) : Val :=
  Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]

/-- The input of `adaRedraw` (Idx 706): `[j, thr, pub]`. -/
def redrawIn (A : AdaParams) (j : ℕ) (thr : List ℤ) : Val :=
  Val.list [encN j, encL encZ thr, adaPubEnc A]

/-- **The body of `adaCorr`** (Idx 702) on `corrIn A st vals j q`: the deterministic part (705),
the threshold redraws (706) on `[j, st.thrInt, pub]`, then the nine fields of the new state. -/
def body_adaCorrMain : Expr :=
  eLet (eCall Idx.adaCorrDet (eV 0))
    (eLet (eCall Idx.adaRedraw (eList [eAtN 0 (eV 1), eAtN 2 (eAtN 2 (eV 1)), eAtN 3 (eV 1)]))
      (eList [eAtN 0 (eV 1), eAtN 1 (eV 1), eV 0, eAtN 3 (eAtN 2 (eV 2)), eAtN 4 (eAtN 2 (eV 2)),
        eAtN 5 (eAtN 2 (eV 2)), eAtN 6 (eAtN 2 (eV 2)), eAtN 7 (eAtN 2 (eV 2)),
        eAtN 8 (eAtN 2 (eV 2))]))

section Main

variable {prog : List Expr} {M : ℕ}

/-- A deterministic `letE`. -/
theorem cm_implements_letE_det {α : Type} {env : List Val} {a b : Expr} {va : Val} {enc : α → Val}
    {p : BitProg α} (ha : EvalsVal prog M env [] (.inl a) va)
    (hb : Implements prog M (va :: env) b enc p) : Implements prog M env (Expr.letE a b) enc p := by
  intro bits x h
  have := EvalsVal.letE ha (hb bits x h)
  simpa using this

/-- The size budget covers `p` and the bit length scale. -/
theorem cm_bound (A : AdaParams) : 2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  unfold adaBoundA
  have h1 : 16 * (A.p + adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := by nlinarith
  calc 2 ^ 14 * (A.p + adaZ A + 16) = 2 ^ 10 * (16 * (A.p + adaZ A + 16)) := by ring
    _ ≤ 2 ^ 10 * ((A.N + A.p + 16) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
    _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring

theorem cm_bitLen_avSign_le (q : Bool) : bitLen (avSign q) ≤ 1 := by
  cases q <;> decide

/-- The size of the input of `adaCorr`. -/
theorem valSize_corrIn_le {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (q : Bool) :
    valSize (corrIn A st vals j q) ≤ 4 * adaBoundA A := by
  have hPub := valSize_adaPubEnc_le A hbs hT
  have hSt := valSize_adaEnc_le hok
  have hVals := valSize_encVals_le hbs hv.1 hv.2
  have hB := cm_bound A
  have hjS : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have hsg := cm_bitLen_avSign_le q
  unfold corrIn
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
  omega

/-- The size of the input of `adaRedraw`. -/
theorem valSize_redrawIn_le {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {j : ℕ} (hj : j < A.p) :
    valSize (redrawIn A j st.thrInt) ≤ 3 * adaBoundA A := by
  have hPub := valSize_adaPubEnc_le A hbs hT
  have hSt := valSize_adaEnc_le hok
  have hB := cm_bound A
  have hjS : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have hthrS : valSize (encL encZ st.thrInt) ≤ adaBoundA A :=
    le_trans (valSize_lt_of_mem (l := [encL (encL encZ) st.scores, encL encN st.T,
      encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
      encB st.halted, encB st.capAborted]) (by simp)).le hSt
  unfold redrawIn
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

/-- **`adaCorr` from its two parts.** If routine 705 evaluates (deterministically) the new scores and
counters `[scores', T']` on `corrIn A st vals j q`, and routine 706 implements the threshold redraws on
`redrawIn A j st.thrInt`, then `body_adaCorrMain` implements the correction
`applyCorrection A st vals j q` (in fresh bits) with the state encoding `adaEnc`. -/
theorem adaCorr_of_parts {A : AdaParams} {st : AdaState} {vals : List (List ℕ)} {j : ℕ} {q : Bool}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) (hok : AdaOK A st)
    (hv : ValsOKA A vals) (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) {bDet bRed : Expr}
    (hdetL : prog[Idx.adaCorrDet]? = some bDet) (hredL : prog[Idx.adaRedraw]? = some bRed)
    (hdet : EvalsVal prog M [corrIn A st vals j q] [] (.inl bDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]))
    (hred : Implements prog M [redrawIn A j st.thrInt] bRed (encL encZ)
      ((redrawThresholds A (reopenEdges A j) st.thrInt).toBits (adaDraw A))) :
    Implements prog M [corrIn A st vals j q] body_adaCorrMain adaEnc
      ((applyCorrection A st vals j q).toBits (adaDraw A)) := by
  rw [applyCorrection_toBits]
  have hB := cm_bound A
  have hSt := valSize_adaEnc_le hok
  have hxM : valSize (corrIn A st vals j q) ≤ M := by
    have := valSize_corrIn_le hbs hT hok hv hj q
    omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hrM : valSize (redrawIn A j st.thrInt) ≤ M := by
    have := valSize_redrawIn_le hbs hT hok hj
    omega
  -- the deterministic part (705)
  have hdvM : valSize (Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))]) ≤ M := by
    have hokD := avState_ok hok vals q hj hTj hok.thr_len hok.thr_le
    have hS' := valSize_adaEnc_le hokD
    have hle : valSize (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) ≤
        valSize (adaEnc (avState A st vals j q st.thrInt)) := by
      simp only [adaEnc, avState, valSize_list, listSize_cons, listSize_nil]
      omega
    omega
  have hd : EvalsVal prog M [corrIn A st vals j q] [] (.inl (eCall Idx.adaCorrDet (eV 0)))
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) :=
    evalsVal_call_det hdetL EvalsVal.var0 hdet
  unfold body_adaCorrMain
  refine cm_implements_letE_det hd ?_
  -- the redraws (706)
  have hargs : EvalsVal prog M [Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
      (.inl (eList [eAtN 0 (eV 1), eAtN 2 (eAtN 2 (eV 1)), eAtN 3 (eV 1)]))
      (redrawIn A j st.thrInt) := by
    have hstE : EvalsVal prog M [Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
        (.inl (eAtN 2 (eV 1))) (adaEnc st) :=
      evalsVal_atN' (n := 2) EvalsVal.var1 hxM rfl
    exact evalsVal_list (List.Forall₂.cons (evalsVal_atN' (n := 0) EvalsVal.var1 hxM rfl)
      (List.Forall₂.cons (evalsVal_atN' (n := 2) hstE hstM rfl)
      (List.Forall₂.cons (evalsVal_atN' (n := 3) EvalsVal.var1 hxM rfl) List.Forall₂.nil))) hrM
  refine implements_letE_of (implements_call_det hredL hargs hred)
    (fun t => t.length = A.p ∧ ∀ z ∈ t, adaKB A z) (fun bits t h => ?_) ?_
  · have hall := DAlw.toBits (adaDraw_adaKB A)
      (redrawThresholds_ok A (reopenEdges A j) st.thrInt hok.thr_le)
    obtain ⟨h1, h2⟩ := Always.of_run hall h
    exact ⟨h1.trans hok.thr_len, h2⟩
  rintro t ⟨htl, htK⟩
  apply Implements.of_det
  have hok' := avState_ok hok vals q hj hTj htl htK
  have hS' := valSize_adaEnc_le hok'
  have hstE : EvalsVal prog M [encL encZ t, Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
      (.inl (eAtN 2 (eV 2))) (adaEnc st) :=
    evalsVal_atN' (n := 2) EvalsVal.var2 hxM rfl
  refine evalsVal_list (List.Forall₂.cons (evalsVal_atN' (n := 0) EvalsVal.var1 hdvM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 1) EvalsVal.var1 hdvM rfl)
    (List.Forall₂.cons EvalsVal.var0
    (List.Forall₂.cons (evalsVal_atN' (n := 3) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 4) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 5) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 6) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 7) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 8) hstE hstM rfl) List.Forall₂.nil))))))))) ?_
  exact le_trans hS' (by omega)

end Main

end F2e2e.C.Impl
