import F2e2e.C.Impl.MainDefs
import F2e2e.C.Impl.Tree3

/-!
# W6, Main (proofs): one round and the initialization in the DSL

* `fin0_val`, `finQ_val`: closing a round;
* `roundB_impl` (Steps 3–4), `roundA_impl` (Step 2 and the zero bypass), `round_impl` (the round:
  C-ALG's `roundStep`), `init_impl` (C-ALG's `initState`).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

attribute [local irreducible] Nat.clog Nat.log

/-! ## `Implements` helpers -/

section implRules

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem implements_ite_encB {c t f : Expr} {b : Bool} {α : Type} {enc : α → Val} {p : BitProg α}
    (hc : EvalsVal prog M env [] (.inl c) (encB b))
    (hb : Implements prog M env (if b then t else f) enc p) :
    Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  have h2 := hb bits a h
  have := EvalsVal.ite (prog := prog) (M := M) (env := env) (t := t) (f := f)
    (z := if b then 1 else 0) hc (by cases b <;> simpa using h2)
  simpa using this

theorem implements_letE_run {α β : Type} {ea eb : Expr} {encA : α → Val} {encC : β → Val}
    {p : BitProg α} {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

theorem implements_letE_det' {β : Type} {ea eb : Expr} {va : Val} {enc : β → Val} {p : BitProg β}
    (ha : EvalsVal prog M env [] (.inl ea) va) (hb : Implements prog M (va :: env) eb enc p) :
    Implements prog M env (Expr.letE ea eb) enc p := by
  intro bits c h
  simpa using EvalsVal.letE ha (hb bits c h)

end implRules

/-! ## Facts about the rounds -/

theorem encState_finish (adaEnc : F2e2e.B.AdaState → Val) (s : State) (F : ℚ) :
    encState adaEnc (finishRound s F).1 = Val.list [Val.int ((s.t : ℤ) + 1),
      Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ),
      Val.list (s.learners.map encLearner), Val.list (s.banks.map (encBank adaEnc)),
      Val.int s.leaf] := by
  simp only [finishRound, encState]
  push_cast
  rfl

theorem finishRound_snd' (s : State) (F : ℚ) : (finishRound s F).2 = if s.failed then 0 else F :=
  rfl

theorem finishRound_t (s : State) (F : ℚ) : (finishRound s F).1.t = s.t + 1 := rfl

theorem encQ_zero : encQ 0 = Val.list [Val.int 0, Val.int 1] := rfl

theorem valSize_encQ_zero : valSize (Val.list [Val.int 0, Val.int 1]) = 6 := by
  simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero, bitLen_one]

theorem step3Loop_t (P : StreamParams) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State), (step3Loop P tr ds s).t = s.t
  | [], _ => rfl
  | d :: ds, s => by
    simp only [step3Loop]
    split
    · rfl
    · rw [step3Loop_t P tr ds _, step3Depth_t]

theorem step3_t (P : StreamParams) (s : State) : (step3 P s).t = s.t :=
  step3Loop_t P _ _ _

/-! ## Closing a round -/

theorem fin0_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ} {P : StreamParams}
    (hP : ParamsOK P) (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t < P.m) :
    EvalsVal prog M [Val.list [encState R.enc s]] [] (.inl body_fin0)
      (Val.list [encState R.enc (finishRound s 0).1, encQ (finishRound s 0).2]) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs (le_of_lt ht)
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hfin : valSize (encState R.enc (finishRound s 0).1) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada (hs.finish 0) (by rw [finishRound_t]; omega)
  have hq0 : encQ (finishRound s 0).2 = Val.list [Val.int 0, Val.int 1] := by
    rw [finishRound_snd']
    split <;> rfl
  have hXsz : valSize (Val.list [encState R.enc s]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  rw [hq0]
  rw [encState_finish R.enc s 0] at hfin ⊢
  unfold body_fin0
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  have ht1 : valSize (Val.int ((s.t : ℤ) + 1)) ≤ M := by
    have h := valSize_of_getElem?_le (k := 0) (l := [Val.int ((s.t : ℤ) + 1),
      Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ),
      Val.list (s.learners.map encLearner), Val.list (s.banks.map (encBank R.enc)),
      Val.int s.leaf]) rfl
    omega
  exact ev_list (.cons (ev_list (.cons (ev_add (ev_get 0 (EvalsVal.var rfl) hstM rfl)
      (EvalsVal.lit' (by simp; omega)) ht1)
    (.cons (ev_get 1 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl)
          .nil))))))) (hfin.trans hSM))
    (.cons (ev_list (.cons (EvalsVal.lit' (by simp; omega)) (.cons (EvalsVal.lit' (by simp; omega))
      .nil)) (by rw [valSize_encQ_zero]; omega))
      .nil))
    (by rw [valSize_pair, valSize_encQ_zero]; omega)

theorem finQ_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ} {P : StreamParams}
    (hP : ParamsOK P) (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t < P.m)
    {q : ℚ} (hq : QOK P q) :
    EvalsVal prog M [Val.list [encState R.enc s, encQ q]] [] (.inl body_finQ)
      (Val.list [encState R.enc (finishRound s q).1, encQ (finishRound s q).2]) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs (le_of_lt ht)
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hfin : valSize (encState R.enc (finishRound s q).1) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada (hs.finish q) (by rw [finishRound_t]; omega)
  have hqsz := valSize_encQ_le_of_QOK hq
  have hXsz : valSize (Val.list [encState R.enc s, encQ q]) ≤ M := by
    rw [valSize_pair]; omega
  have hout2 : valSize (encQ (finishRound s q).2) ≤ 8 * regBits P + 7 := by
    rw [finishRound_snd']
    split
    · rw [encQ_zero, valSize_encQ_zero]; omega
    · exact hqsz
  rw [encState_finish R.enc s q] at hfin ⊢
  unfold body_finQ
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  have ht1 : valSize (Val.int ((s.t : ℤ) + 1)) ≤ M := by
    have h := valSize_of_getElem?_le (k := 0) (l := [Val.int ((s.t : ℤ) + 1),
      Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ),
      Val.list (s.learners.map encLearner), Val.list (s.banks.map (encBank R.enc)),
      Val.int s.leaf]) rfl
    omega
  refine ev_list (.cons (ev_list (.cons (ev_add (ev_get 0 (EvalsVal.var rfl) hstM rfl)
      (EvalsVal.lit' (by simp; omega)) ht1)
    (.cons (ev_get 1 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl)
          .nil))))))) (hfin.trans hSM))
    (.cons ?_ .nil)) (by rw [valSize_pair]; omega)
  rw [finishRound_snd']
  cases hf : s.failed
  · simp only [Bool.false_eq_true, if_false]
    exact ev_ite_f (ev_get 1 (EvalsVal.var rfl) hstM rfl) (by simp [hf]) (EvalsVal.var rfl)
  · rw [if_pos rfl, encQ_zero]
    exact ev_ite_t (ev_get 1 (EvalsVal.var rfl) hstM rfl) (by simp [hf])
      (ev_list (.cons (EvalsVal.lit' (by simp; omega)) (.cons (EvalsVal.lit' (by simp; omega)) .nil))
        (by rw [valSize_encQ_zero]; omega))

end F2e2e.C.Impl.W6
