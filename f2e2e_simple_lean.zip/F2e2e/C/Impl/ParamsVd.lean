import F2e2e.C.Impl.ParamsPE

/-!
# W1 (public parameters, DSL), part 2: the loop computing `V_d`

Owner: C-PARAMS (e26ae4ae). `V_0 = W`, `V_{d+1} = (1 + 2B^d) V_d` (eq. `R:eq:param-Vd`, partII.tex
L175; `F2e2e.StreamParams.Vd`) is computed by a `loop` (internal index `Idx.w1VdStep = 448`) on the
state `[r, B^k, B, V_k]` (`r = d - k` steps left), from `[d, 1, B, W]`:

* `body_vdStep`: stop with `V_k` when `r = 0`, else continue with `[r - 1, B^k · B, B, (1 + 2B^k) V_k]`;
* `vdLoop_evals`: the loop from `[d, 1, B, W]` returns `V_d` for `d ≤ H`, every value `≤ 2^{8ℒ³}`;
* `eVd i b w = loop 448 [var i, 1, var b, var w]` and its rule `eVd_evals`.

Internal indices of W1 (range `400–449`, `F2e2e/C/Impl/W6Contracts.lean`): `w1VdStep = 448`,
`w1All = 449` (the master routine, `F2e2e/C/Impl/ParamsW1.lean`).
-/

namespace F2e2e.C.Impl

namespace Idx

/-- W1 internal: the loop step computing `V_d` (state `[r, B^k, B, V_k]`). -/
abbrev w1VdStep : ℕ := 448
/-- W1 internal: the master routine `encStreamParams P ↦` the list of all public parameters. -/
abbrev w1All : ℕ := 449

end Idx

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

/-- The four-element list `[a, b, c, d]`. -/
def eL4 (a b c d : Expr) : Expr :=
  Expr.bin BinOp.cons a
    (Expr.bin BinOp.cons b (Expr.bin BinOp.cons c (Expr.bin BinOp.cons d Expr.nil)))

theorem eL4_evals {env : List Val} {a b c d : Expr} {va vb vc vd : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : EvalsVal prog M env [] (.inl b) vb)
    (hc : EvalsVal prog M env [] (.inl c) vc) (hd : EvalsVal prog M env [] (.inl d) vd)
    (hM : valSize (Val.list [va, vb, vc, vd]) ≤ M) :
    EvalsVal prog M env [] (.inl (eL4 a b c d)) (Val.list [va, vb, vc, vd]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h0 : valSize (Val.list []) ≤ M := by
    simp only [valSize_list, listSize_nil]; omega
  have h1 : valSize (Val.list [vd]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have h2 : valSize (Val.list [vc, vd]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have h3 : valSize (Val.list [vb, vc, vd]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have h4 : valSize (Val.list [va, vb, vc, vd]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  exact (EvalsVal.cons ha (EvalsVal.cons hb (EvalsVal.cons hc (EvalsVal.cons hd (EvalsVal.nil h0)
    h1) h2) h3) h4).cast_bits rfl

/-- Step of the `V_d` loop; state `[r, Bk, B, V]`: stop with `V` when `r = 0`, else continue with
`[r - 1, Bk · B, B, (1 + 2 Bk) V]`. -/
def body_vdStep : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                -- r   env [r, S]
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
      (ePair (Expr.lit 0) (eNth 3 (Expr.var 1)))
      (ePair (Expr.lit 1)
        (eL4 (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
          (Expr.bin BinOp.mul (eNth 1 (Expr.var 1)) (eNth 2 (Expr.var 1)))
          (eNth 2 (Expr.var 1))
          (Expr.bin BinOp.mul
            (Expr.bin BinOp.add (Expr.lit 1) (Expr.bin BinOp.mul (Expr.lit 2) (eNth 1 (Expr.var 1))))
            (eNth 3 (Expr.var 1))))))

/-- The loop state `[r, Bk, B, V]`. -/
def encVd (r Bk B V : ℕ) : Val := Val.list [encN r, encN Bk, encN B, encN V]

theorem valSize_encN_le_of_le {y X : ℕ} (h : y ≤ X) : valSize (encN y) ≤ Nat.size X + 1 := by
  rw [valSize_encN]
  have := Nat.size_le_size h
  omega

theorem valSize_encVd_le {r Bk B V X : ℕ} (hr : r ≤ X) (hBk : Bk ≤ X) (hB : B ≤ X) (hV : V ≤ X) :
    valSize (encVd r Bk B V) ≤ 4 * Nat.size X + 9 := by
  have h1 := valSize_encN_le_of_le hr
  have h2 := valSize_encN_le_of_le hBk
  have h3 := valSize_encN_le_of_le hB
  have h4 := valSize_encN_le_of_le hV
  simp only [encVd, valSize_list, listSize_cons, listSize_nil]
  omega

theorem vdStep_stop {Bk B V X : ℕ} (hBk : Bk ≤ X) (hB : B ≤ X) (hV : V ≤ X)
    (hM : 8 * Nat.size X + 30 ≤ M) :
    EvalsVal prog M [encVd 0 Bk B V] [] (.inl body_vdStep) (Val.list [Val.int 0, encN V]) := by
  have hS := valSize_encVd_le (Nat.zero_le X) hBk hB hV
  have hVs := valSize_encN_le_of_le hV
  have hS' : valSize (Val.list [encN 0, encN Bk, encN B, encN V]) ≤ M := by
    have : valSize (encVd 0 Bk B V) = valSize (Val.list [encN 0, encN Bk, encN B, encN V]) := rfl
    omega
  have hr : EvalsVal prog M [encVd 0 Bk B V] [] (.inl (Expr.un UnOp.head (Expr.var 0))) (encN 0) :=
    EvalsVal.head (EvalsVal.var (v := Val.list [encN 0, encN Bk, encN B, encN V]) rfl)
      (by simp only [valSize_encN, Nat.size_zero]; omega)
  have h2M : 2 ≤ M := by omega
  have hc := EvalsVal.eq (prog := prog) (M := M) (x := ((0 : ℕ) : ℤ)) (y := 0)
    (EvalsVal.var (env := [encN 0, encVd 0 Bk B V]) (i := 0) (v := encN 0) rfl)
    (EvalsVal.lit (by simp only [valSize_int, bitLen_zero]; omega)) h2M
  have hz : (if ((0 : ℕ) : ℤ) = 0 then (1 : ℤ) else 0) ≠ 0 := by simp
  have hV3 : EvalsVal prog M [encN 0, encVd 0 Bk B V] [] (.inl (eNth 3 (Expr.var 1))) (encN V) :=
    eNth_evals (l := [encN 0, encN Bk, encN B, encN V]) (EvalsVal.var rfl) hS' rfl
  have hp := EvalsVal.pair (EvalsVal.lit (env := [encN 0, encVd 0 Bk B V]) (z := 0)
    (by simp only [valSize_int, bitLen_zero]; omega)) hV3
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]; omega)
  have hite := EvalsVal.ite_true (f := ePair (Expr.lit 1)
        (eL4 (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
          (Expr.bin BinOp.mul (eNth 1 (Expr.var 1)) (eNth 2 (Expr.var 1)))
          (eNth 2 (Expr.var 1))
          (Expr.bin BinOp.mul
            (Expr.bin BinOp.add (Expr.lit 1) (Expr.bin BinOp.mul (Expr.lit 2) (eNth 1 (Expr.var 1))))
            (eNth 3 (Expr.var 1))))) hc hz hp
  exact letE0 hr (hite.cast_bits rfl)

theorem vdStep_cont {r Bk B V X : ℕ} (hr : r + 1 ≤ X) (hBk : Bk ≤ X) (hB : B ≤ X) (hV : V ≤ X)
    (hBkB : Bk * B ≤ X) (h1 : 1 + 2 * Bk ≤ X) (hV' : (1 + 2 * Bk) * V ≤ X)
    (hM : 8 * Nat.size X + 30 ≤ M) :
    EvalsVal prog M [encVd (r + 1) Bk B V] [] (.inl body_vdStep)
      (Val.list [Val.int 1, encVd r (Bk * B) B ((1 + 2 * Bk) * V)]) := by
  have hS := valSize_encVd_le hr hBk hB hV
  have hS' : valSize (Val.list [encN (r + 1), encN Bk, encN B, encN V]) ≤ M := by
    have : valSize (encVd (r + 1) Bk B V) =
      valSize (Val.list [encN (r + 1), encN Bk, encN B, encN V]) := rfl
    omega
  have hS2 := valSize_encVd_le (show r ≤ X by omega) hBkB hB hV'
  have fits : ∀ y : ℕ, y ≤ X → valSize (Val.int (y : ℤ)) ≤ M := by
    intro y hy
    have := valSize_encN_le_of_le hy
    have e : valSize (Val.int (y : ℤ)) = valSize (encN y) := rfl
    omega
  have h2M : 2 ≤ M := by omega
  set env' : List Val := [encN (r + 1), encVd (r + 1) Bk B V] with henv'
  have hhd : EvalsVal prog M [encVd (r + 1) Bk B V] [] (.inl (Expr.un UnOp.head (Expr.var 0)))
      (encN (r + 1)) :=
    EvalsVal.head (EvalsVal.var (v := Val.list [encN (r + 1), encN Bk, encN B, encN V]) rfl)
      (fits (r + 1) hr)
  have hv0 : EvalsVal prog M env' [] (.inl (Expr.var 0)) (Val.int ((r + 1 : ℕ) : ℤ)) :=
    EvalsVal.var rfl
  have hS1 : EvalsVal prog M env' [] (.inl (Expr.var 1))
      (Val.list [encN (r + 1), encN Bk, encN B, encN V]) := EvalsVal.var rfl
  have hc := EvalsVal.eq (y := 0) hv0
    (EvalsVal.lit (by simp only [valSize_int, bitLen_zero]; omega)) h2M
  have hz : (if ((r + 1 : ℕ) : ℤ) = 0 then (1 : ℤ) else 0) = 0 := by
    rw [if_neg (by positivity)]
  have hBk1 : EvalsVal prog M env' [] (.inl (eNth 1 (Expr.var 1))) (Val.int (Bk : ℤ)) :=
    eNth_evals hS1 hS' rfl
  have hB2 : EvalsVal prog M env' [] (.inl (eNth 2 (Expr.var 1))) (Val.int (B : ℤ)) :=
    eNth_evals hS1 hS' rfl
  have hV3 : EvalsVal prog M env' [] (.inl (eNth 3 (Expr.var 1))) (Val.int (V : ℤ)) :=
    eNth_evals hS1 hS' rfl
  -- the four new state entries
  have d1 : EvalsVal prog M env' [] (.inl (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1)))
      (encN r) := by
    have e : ((r + 1 : ℕ) : ℤ) - 1 = ((r : ℕ) : ℤ) := by push_cast; ring
    have h := EvalsVal.sub (y := 1) hv0 (EvalsVal.lit (by simp only [valSize_int, bitLen_one]; omega))
      (by rw [e]; exact fits r (by omega))
    rw [e] at h
    exact h.cast_bits rfl
  have d2 : EvalsVal prog M env' []
      (.inl (Expr.bin BinOp.mul (eNth 1 (Expr.var 1)) (eNth 2 (Expr.var 1)))) (encN (Bk * B)) := by
    have e : (Bk : ℤ) * (B : ℤ) = ((Bk * B : ℕ) : ℤ) := by push_cast; ring
    have h := EvalsVal.mul hBk1 hB2 (by rw [e]; exact fits _ hBkB)
    rw [e] at h
    exact h.cast_bits rfl
  have d4 : EvalsVal prog M env' []
      (.inl (Expr.bin BinOp.mul
        (Expr.bin BinOp.add (Expr.lit 1) (Expr.bin BinOp.mul (Expr.lit 2) (eNth 1 (Expr.var 1))))
        (eNth 3 (Expr.var 1)))) (encN ((1 + 2 * Bk) * V)) := by
    have e2 : (2 : ℤ) * (Bk : ℤ) = ((2 * Bk : ℕ) : ℤ) := by push_cast; ring
    have e3 : (1 : ℤ) + ((2 * Bk : ℕ) : ℤ) = ((1 + 2 * Bk : ℕ) : ℤ) := by push_cast; ring
    have e4 : ((1 + 2 * Bk : ℕ) : ℤ) * (V : ℤ) = (((1 + 2 * Bk) * V : ℕ) : ℤ) := by push_cast; ring
    have hl2 : EvalsVal prog M env' [] (.inl (Expr.lit 2)) (Val.int 2) :=
      EvalsVal.lit (by simp only [valSize_int]; have : bitLen (2 : ℤ) = 2 := rfl; omega)
    have hm := EvalsVal.mul hl2 hBk1 (by rw [e2]; exact fits _ (by omega))
    rw [e2] at hm
    have hl1 : EvalsVal prog M env' [] (.inl (Expr.lit 1)) (Val.int 1) :=
      EvalsVal.lit (by simp only [valSize_int, bitLen_one]; omega)
    have ha := EvalsVal.add hl1 (hm.cast_bits rfl) (by rw [e3]; exact fits _ h1)
    rw [e3] at ha
    have hmm := EvalsVal.mul (ha.cast_bits rfl) hV3 (by rw [e4]; exact fits _ hV')
    rw [e4] at hmm
    exact hmm.cast_bits rfl
  have hB2' : EvalsVal prog M env' [] (.inl (eNth 2 (Expr.var 1))) (encN B) := hB2
  have hlist := eL4_evals d1 d2 hB2' d4 (by
    have : valSize (encVd r (Bk * B) B ((1 + 2 * Bk) * V)) =
      valSize (Val.list [encN r, encN (Bk * B), encN B, encN ((1 + 2 * Bk) * V)]) := rfl
    omega)
  have hp := EvalsVal.pair (EvalsVal.lit (env := env') (z := 1)
    (by simp only [valSize_int, bitLen_one]; omega)) hlist (by
      have : valSize (encVd r (Bk * B) B ((1 + 2 * Bk) * V)) =
        valSize (Val.list [encN r, encN (Bk * B), encN B, encN ((1 + 2 * Bk) * V)]) := rfl
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one] at this ⊢
      omega)
  have hite := EvalsVal.ite_false (t := ePair (Expr.lit 0) (eNth 3 (Expr.var 1))) hc hz hp
  exact letE0 hhd (hite.cast_bits rfl)

/-! ## Bounds along the loop -/

theorem Vd_mono (P : StreamParams) {a b : ℕ} (h : a ≤ b) : P.Vd a ≤ P.Vd b := by
  induction b, h using Nat.le_induction with
  | base => exact le_rfl
  | succ b _ ih =>
    refine ih.trans ?_
    show P.Vd b ≤ (1 + 2 * P.B ^ b) * P.Vd b
    exact Nat.le_mul_of_pos_left _ (by omega)

theorem B_pow_le (P : StreamParams) {k : ℕ} (hk : k ≤ P.H) :
    P.B ^ k ≤ 2 ^ (2 * P.calL ^ 2) := by
  have hB : P.B ^ k = 2 ^ (P.logB * k) := by
    rw [StreamParams.B, ← pow_mul]
  rw [hB]
  refine Nat.pow_le_pow_right (by norm_num) ?_
  have h1 := Space.logB_le P
  have h2 := Space.H_le P
  calc P.logB * k ≤ (2 * P.calL) * P.calL := Nat.mul_le_mul h1 (hk.trans h2)
    _ = 2 * P.calL ^ 2 := by ring

theorem B_pow_le_Abnd (P : StreamParams) {k : ℕ} (hk : k ≤ P.H) : P.B ^ k ≤ Abnd P := by
  refine le_Abnd_of_le_two_pow (B_pow_le P hk) ?_
  have := Space.hundred_mul_sq_le_cube P
  omega

theorem one_add_two_B_pow_le_Abnd (P : StreamParams) {k : ℕ} (hk : k ≤ P.H) :
    1 + 2 * P.B ^ k ≤ Abnd P := by
  have h := B_pow_le P hk
  have h1 : 1 + 2 * P.B ^ k ≤ 2 ^ (2 * P.calL ^ 2 + 2) := by
    have : 1 ≤ 2 ^ (2 * P.calL ^ 2) := Nat.one_le_two_pow
    rw [pow_add]
    omega
  refine le_Abnd_of_le_two_pow h1 ?_
  have := Space.hundred_mul_sq_le_cube P
  have := calL_cube_ge P
  omega

theorem Vd_le_Abnd (P : StreamParams) {d : ℕ} (hd : d ≤ P.H) : P.Vd d ≤ Abnd P :=
  le_Abnd_of_le_two_pow (Space.Vd_le_calL P hd) (by omega)

theorem H_le_Abnd (P : StreamParams) : P.H ≤ Abnd P :=
  le_Abnd_of_le ((Space.H_le P).trans (by
    have := Nat.le_self_pow (n := 3) (by norm_num) P.calL
    omega))

theorem B_le_Abnd (P : StreamParams) : P.B ≤ Abnd P := by
  have h := B_pow_le_Abnd P (k := 1) (by have := Space.H_le P; unfold StreamParams.H; omega)
  simpa using h

theorem W_le_Abnd (P : StreamParams) : P.W ≤ Abnd P :=
  le_Abnd_of_le_two_pow (Space.W_le P) (by
    have := Nat.le_self_pow (n := 3) (by norm_num) P.calL
    omega)

theorem size_Abnd_le (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    8 * Nat.size (Abnd P) + 30 ≤ M := by
  rw [Abnd, Nat.size_pow]
  have := calL_cube_ge P
  omega

/-- **The `V_d` loop** from `[d, 1, B, W]` returns `V_d` (`d ≤ H`). -/
theorem vdLoop_evals (hstep : prog[Idx.w1VdStep]? = some body_vdStep) (P : StreamParams) {d : ℕ}
    (hd : d ≤ P.H) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M [] [] (.inr (Idx.w1VdStep, encVd d 1 P.B P.W)) (encN (P.Vd d)) := by
  have hMX := size_Abnd_le P hM
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hstep
    (fun k : ℕ => encVd (d - k) (P.B ^ k) P.B (P.Vd k)) (fun _ => [])
    (fun k => k ≤ d) (fun out => out = encN (P.Vd d)) (fun k => d - k) ?_ 0 (Nat.zero_le d)
  · obtain ⟨out, hout, h⟩ := key
    subst hout
    have e : encVd (d - 0) (P.B ^ 0) P.B (P.Vd 0) = encVd d 1 P.B P.W := by
      rw [Nat.sub_zero, pow_zero]
      rfl
    rw [e] at h
    exact h
  · intro k hk
    have hkH : k ≤ P.H := hk.trans hd
    have hBk := B_pow_le_Abnd P hkH
    have hB := B_le_Abnd P
    have hV := Vd_le_Abnd P hkH
    by_cases hdk : d - k = 0
    · left
      have hkd : k = d := by omega
      refine ⟨encN (P.Vd k), ?_, by rw [hkd]⟩
      show EvalsVal prog M [encVd (d - k) (P.B ^ k) P.B (P.Vd k)] [] (.inl body_vdStep)
        (Val.list [Val.int 0, encN (P.Vd k)])
      rw [hdk]
      exact vdStep_stop hBk hB hV hMX
    · right
      obtain ⟨r, hr⟩ : ∃ r, d - k = r + 1 := ⟨d - k - 1, by omega⟩
      have hk1 : k + 1 ≤ P.H := by omega
      refine ⟨1, k + 1, [], one_ne_zero, rfl, ?_, by omega, by omega⟩
      have e : encVd (d - (k + 1)) (P.B ^ (k + 1)) P.B (P.Vd (k + 1)) =
          encVd r (P.B ^ k * P.B) P.B ((1 + 2 * P.B ^ k) * P.Vd k) := by
        rw [show d - (k + 1) = r by omega, pow_succ]
        rfl
      show EvalsVal prog M [encVd (d - k) (P.B ^ k) P.B (P.Vd k)] [] (.inl body_vdStep)
        (Val.list [Val.int 1, encVd (d - (k + 1)) (P.B ^ (k + 1)) P.B (P.Vd (k + 1))])
      rw [e, hr]
      have hBkB : P.B ^ k * P.B ≤ Abnd P := by
        rw [← pow_succ]; exact B_pow_le_Abnd P hk1
      have hV' : (1 + 2 * P.B ^ k) * P.Vd k ≤ Abnd P := Vd_le_Abnd P hk1
      have hr1 : r + 1 ≤ Abnd P := by
        have := H_le_Abnd P
        omega
      exact vdStep_cont hr1 hBk hB hV hBkB (one_add_two_B_pow_le_Abnd P hkH) hV' hMX

/-- `loop 448 [var i, 1, var b, var w]`: `V_d` for `d = env[i]`, `B = env[b]`, `W = env[w]`. -/
def eVd (i b w : ℕ) : Expr :=
  Expr.loop Idx.w1VdStep (eL4 (Expr.var i) (Expr.lit 1) (Expr.var b) (Expr.var w))

theorem eVd_evals (hstep : prog[Idx.w1VdStep]? = some body_vdStep) (P : StreamParams)
    {env : List Val} {i b w d : ℕ} (hi : env[i]? = some (encN d))
    (hb : env[b]? = some (encN P.B)) (hw : env[w]? = some (encN P.W)) (hd : d ≤ P.H)
    (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M env [] (.inl (eVd i b w)) (encN (P.Vd d)) := by
  have hMX := size_Abnd_le P hM
  have hdX : d ≤ Abnd P := hd.trans (H_le_Abnd P)
  have h1X : 1 ≤ Abnd P := by have := four096_le_Abnd P; omega
  have hS := valSize_encVd_le hdX h1X (B_le_Abnd P) (W_le_Abnd P)
  have hl1 : EvalsVal prog M env [] (.inl (Expr.lit 1)) (encN 1) :=
    EvalsVal.lit (by simp only [valSize_int, bitLen_one]; omega)
  have hlist := eL4_evals (EvalsVal.var hi) hl1 (EvalsVal.var hb) (EvalsVal.var hw)
    (by
      have : valSize (encVd d 1 P.B P.W) = valSize (Val.list [encN d, encN 1, encN P.B, encN P.W]) :=
        rfl
      omega)
  exact loop0 hlist (vdLoop_evals hstep P hd hM)

end W1

end F2e2e.C.Impl
