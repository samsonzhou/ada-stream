import F2e2e.C.Impl.Tree2
import F2e2e.C.Impl.Tree3Defs

/-!
# W6, Main: one round of the algorithm (C-ALG `roundStep`) and the initialization (`initState`)

Routines (W6 range, Main sub-range 370–399):
* 370 `body_round`: `[p, st, i, Δ] ↦ [encState s', encQ F]` for `(s', F) = roundStep P s i Δ`;
* 371 `body_roundA`: after Step 1 (`[p, s1, i, Δ]`): Step 2 and the zero bypass;
* 372 `body_roundB`: Steps 3–4 (`[p, s2]`);
* 373 `body_fin0`: `[st] ↦ [encState (finishRound s 0).1, encQ 0]`;
* 374 `body_finQ`: `[st, encQ F] ↦ [encState (finishRound s F).1, encQ (finishRound s F).2]`;
* 375 `body_init`: `encStreamParams P ↦ encState s₀` for `s₀ ← initState P`.
Step 1 (Idx 290, Tree1 helper) and Step 4 (Idx 330, Tree4 helper) enter through the contract-style
hypotheses `TreeHelpers` (discharged in `Assemble.lean`).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

attribute [local irreducible] Nat.clog Nat.log

namespace Idx

/-- Step 1 (Tree1 helper, `F2e2e.C.Impl.T1`). -/
abbrev step1Entry : ℕ := 290
/-- Step 4 (Tree4 helper, `F2e2e.C.Impl.T4`). -/
abbrev step4Entry : ℕ := 330
abbrev round : ℕ := 370
abbrev roundA : ℕ := 371
abbrev roundB : ℕ := 372
abbrev fin0 : ℕ := 373
abbrev finQ : ℕ := 374
abbrev init : ℕ := 375

end Idx

/-! ## The DSL code -/

/-- One round: `[p, st, i, Δ]`; a failed state reports `0`, otherwise Step 1 and `roundA`. -/
def body_round : Expr :=
(Expr.letE (eGet 0 (Expr.var 0)) <|
  (Expr.letE (eGet 1 (Expr.var 1)) <|
  (Expr.letE (eGet 2 (Expr.var 2)) <|
  (Expr.letE (eGet 3 (Expr.var 3)) <|
  (Expr.ite (eGet 1 (Expr.var 2))
  (Expr.call Idx.fin0 (eList [(Expr.var 2)]))
  (Expr.letE (Expr.call Idx.step1Entry (eList [(Expr.var 3), (Expr.var 2)])) <|
  (Expr.call Idx.roundA (eList [(Expr.var 4), (Expr.var 0), (Expr.var 2), (Expr.var 1)]))))))))

/-- After Step 1: `[p, s1, i, Δ]`; Step 2, then the zero bypass, then `roundB`. -/
def body_roundA : Expr :=
(Expr.letE (eGet 0 (Expr.var 0)) <|
  (Expr.letE (eGet 1 (Expr.var 1)) <|
  (Expr.letE (eGet 2 (Expr.var 2)) <|
  (Expr.letE (eGet 3 (Expr.var 3)) <|
  (Expr.ite (eGet 1 (Expr.var 2))
  (Expr.call Idx.fin0 (eList [(Expr.var 2)]))
  (Expr.letE (Expr.call Idx.step2 (eList [(Expr.var 3), (Expr.var 2), (Expr.var 1), (Expr.var 0)])) <|
  (Expr.letE (eGet 0 (Expr.var 0)) <|
  (Expr.ite (eGet 1 (Expr.var 0))
  (Expr.call Idx.fin0 (eList [(Expr.var 0)]))
  (Expr.ite (eGet 1 (Expr.var 1))
  (Expr.call Idx.fin0 (eList [(Expr.var 0)]))
  (Expr.call Idx.roundB (eList [(Expr.var 5), (Expr.var 0)])))))))))))

/-- Steps 3 and 4: `[p, s2]`. -/
def body_roundB : Expr :=
(Expr.letE (eGet 0 (Expr.var 0)) <|
  (Expr.letE (eGet 1 (Expr.var 1)) <|
  (Expr.letE (Expr.call Idx.step3 (eList [(Expr.var 1), (Expr.var 0)])) <|
  (Expr.ite (eGet 1 (Expr.var 0))
  (Expr.call Idx.fin0 (eList [(Expr.var 0)]))
  (Expr.letE (Expr.call Idx.step4Entry (eList [(Expr.var 2), (Expr.var 0)])) <|
  (Expr.call Idx.finQ (eList [(eGet 0 (Expr.var 0)), (eGet 1 (Expr.var 0))])))))))

/-- Close a round reporting `0`: `[st] ↦ [[t + 1, …], [0, 1]]`. -/
def body_fin0 : Expr :=
(Expr.letE (eGet 0 (Expr.var 0)) <|
  (eList [(eList [(Expr.bin BinOp.add (eGet 0 (Expr.var 0)) (Expr.lit 1)), (eGet 1 (Expr.var 0)), (eGet 2 (Expr.var 0)), (eGet 3 (Expr.var 0)), (eGet 4 (Expr.var 0)), (eGet 5 (Expr.var 0)), (eGet 6 (Expr.var 0))]), (eList [(Expr.lit 0), (Expr.lit 1)])]))

/-- Close a round reporting `F` (or `0` if failed): `[st, q] ↦ [[t + 1, …], failed ? [0, 1] : q]`. -/
def body_finQ : Expr :=
(Expr.letE (eGet 0 (Expr.var 0)) <|
  (Expr.letE (eGet 1 (Expr.var 1)) <|
  (eList [(eList [(Expr.bin BinOp.add (eGet 0 (Expr.var 1)) (Expr.lit 1)), (eGet 1 (Expr.var 1)), (eGet 2 (Expr.var 1)), (eGet 3 (Expr.var 1)), (eGet 4 (Expr.var 1)), (eGet 5 (Expr.var 1)), (eGet 6 (Expr.var 1))]), (Expr.ite (eGet 1 (Expr.var 1))
  (eList [(Expr.lit 0), (Expr.lit 1)])
  (Expr.var 0))])))

/-- The initialization: `encStreamParams P ↦ [0, 0, r_fp, 0, [], [B], 0]`. -/
def body_init : Expr :=
(Expr.letE (Expr.call Idx.fpSeed (Expr.var 0)) <|
  (Expr.letE (Expr.call Idx.newBank (Expr.var 1)) <|
  (eList [(Expr.lit 0), (Expr.lit 0), (Expr.var 1), (Expr.lit 0), Expr.nil, (eList [(Expr.var 0)]), (Expr.lit 0)])))

/-- The program contains the routines of Main, Tree2 and Tree3. -/
structure MainLib (prog : List Expr) : Prop where
  round : prog[Idx.round]? = some body_round
  roundA : prog[Idx.roundA]? = some body_roundA
  roundB : prog[Idx.roundB]? = some body_roundB
  fin0 : prog[Idx.fin0]? = some body_fin0
  finQ : prog[Idx.finQ]? = some body_finQ
  init : prog[Idx.init]? = some body_init
  step2 : prog[Idx.step2]? = some body_step2
  step3 : prog[Idx.step3]? = some body_step3
  tree2 : Tree2Lib prog
  tree3 : Tree3Lib prog

/-- The deliverables of the Tree1 and Tree4 helpers, in contract form. -/
structure TreeHelpers (R : AdaRep) (prog : List Expr) (M : ℕ) : Prop where
  step1 : AtIdx prog Idx.step1Entry fun body => ∀ (P : StreamParams) (s : State), ParamsOK P →
    Mv R P ≤ M → StateInv P (R.ok P) s → s.t < P.m → s.failed = false →
    Implements prog M [Val.list [encStreamParams P, encState R.enc s]] body (encState R.enc)
      (step1 P s)
  step4 : AtIdx prog Idx.step4Entry fun body => ∀ (P : StreamParams) (s : State), ParamsOK P →
    Mv R P ≤ M → StateInv P (R.ok P) s → s.t ≤ P.m → s.failed = false →
    Implements prog M [Val.list [encStreamParams P, encState R.enc s]] body
      (fun r => Val.list [encState R.enc r.1, encQ r.2]) (step4 P s)

/-- The semantic output fact of Step 4 (Tree4 helper's `step4_out`). -/
def Step4Out (R : AdaRep) : Prop :=
  ∀ (P : StreamParams) (s : State), ParamsOK P → StateInv P (R.ok P) s → s.t ≤ P.m →
    s.failed = false → Always (step4 P s) (fun r => 0 ≤ r.2 ∧ QOK P r.2)

end F2e2e.C.Impl.W6
