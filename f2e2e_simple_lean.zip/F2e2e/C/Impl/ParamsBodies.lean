import F2e2e.C.Impl.ParamsVd

/-!
# W1 (public parameters, DSL), part 3: the bodies, the table and the library predicate

Owner: C-PARAMS (e26ae4ae). The routines of work package W1 (indices `400–449`,
`F2e2e/C/Impl/W6Contracts.lean`):

* `body_w1All` (internal index `Idx.w1All = 449`): `encStreamParams P ↦` the list `outs P` of all public
  parameters used by W6/W4/W5, computed by one chain of `let`s (`chainE`, `F2e2e/C/Impl/ParamsPE.lean`)
  in exact integer arithmetic, exactly as `F2e2e/C/ParamsDefs.lean` defines them (`H`, `T`, `D_*`, `W`,
  `log₂(1/η)`, `⌈log₂(8√T)⌉ = ⌈(⌈log₂(64T)⌉)/2⌉`, `log₂ B`, `B`, `V_H`, `V_{H-1}` (loop
  `Idx.w1VdStep = 448`), `V`, …, the fingerprint prime `q` (W2's `leastPrimeGE` on `M_q`) and the field
  polynomial `irrW P` (W2's `irrPoly` on `w`));
* `body_param k = eNth k (call 449 (var 0))` at index `400 + k` for every single-parameter routine of
  `W1Contract` (slots `14`, `15` of `outs P` hold `B` and `W`, used by `body_peU`);
* `body_peU` (index `414`): `[encStreamParams P, d] ↦ ⌈log₂(2 V_d²)⌉` (loop for `V_d`);
* `body_pGuardCoord` (index `415`): `[encStreamParams P, d, t] ↦ n + H(t-1) + d + 1`.

`W1Lib prog`: the program contains these bodies, W2's fingerprint and HASH tables (`FpLib`, `HashLib`)
and DSL-CALC's `pow2` / `clog2`; `w1Table` lists W1's own `(index, body)` pairs (`W1Lib.of_table`).
-/

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

/-! ## Expression shorthands -/

/-- Variable number `i` (in push order) after `j` pushes. -/
abbrev pv (j i : ℕ) : PE := PE.var (j - 1 - i)
/-- `⌈log₂ ·⌉` (DSL-CALC's `clog2`, index `102`). -/
abbrev clog (a : PE) : PE := PE.call Cost.Idx.clog2 (Nat.clog 2) a
/-- `2^·` (DSL-CALC's `pow2`, index `100`). -/
abbrev pw2 (a : PE) : PE := PE.call Cost.Idx.pow2 (fun k => 2 ^ k) a

/-! ## The chain of the master routine (push indices in the comments) -/

/-- Unpacking `encStreamParams P = [n, m, U, epsExp, betaExp]` (push indices `0–4`). -/
def segA : List CE :=
  [CE.raw (eNth 0 (Expr.var 0)), CE.raw (eNth 1 (Expr.var 1)), CE.raw (eNth 2 (Expr.var 2)),
    CE.raw (eNth 3 (Expr.var 3)), CE.raw (eNth 4 (Expr.var 4))]

open PE in
/-- `H, T, D_*, W, log₂(1/η), ⌈log₂(8√T)⌉, log₂ B, B` (push indices `5–12`). -/
def segB : List CE :=
  [CE.pe (add (lit 1) (clog (maxE (lit 1) (pv 5 1)))),
   CE.pe (mul (mul (lit 4096) (add (pv 6 1) (lit 1)))
     (mul (mul (add (pv 6 5) (lit 1)) (add (pv 6 5) (lit 1))) (add (pv 6 5) (lit 1)))),
   CE.pe (add (add (pv 7 0) (pv 7 6)) (lit 1)),
   CE.pe (add (mul (pv 8 0) (pv 8 2)) (lit 1)),
   CE.pe (add (add (lit 20) (pv 9 3)) (clog (mul (add (pv 9 5) (lit 1)) (add (pv 9 5) (lit 1))))),
   CE.pe (divL (add (clog (mul (lit 64) (pv 10 6))) (lit 1)) 2),
   CE.pe (add (lit 4) (pv 11 10)),
   CE.pe (pw2 (pv 12 11))]

/-- `V_H, H - 1, V_{H-1}` (push indices `13–15`). -/
def segC : List CE :=
  [CE.raw (eVd 7 0 4), CE.pe (PE.subL (pv 14 5) 1), CE.raw (eVd 0 2 6)]

open PE in
/-- `V, log₂ G, log₂(1/ν), log₂ 𝒰_*, K_epoch, K_0, J_*, J_max, R_max, s, L` (push indices `16–26`). -/
def segD : List CE :=
  [CE.pe (add (mul (mul (lit 8) (pw2 (mul (pv 16 11) (add (pv 16 5) (lit 1))))) (pv 16 13)) (lit 2)),
   CE.pe (mul (add (pv 17 5) (lit 2)) (pv 17 11)),
   CE.pe (add (add (add (pv 18 10) (pv 18 9)) (pv 18 5)) (lit 20)),
   CE.pe (clog (mul (lit 2) (mul (pv 19 15) (pv 19 15)))),
   CE.pe (add (add (add (add (lit 20) (pv 20 19)) (mul (mul (lit 2) (pv 20 5)) (pv 20 11)))
     (mul (lit 2) (pv 20 9))) (mul (lit 2) (pv 20 18))),
   CE.pe (pw2 (add (lit 7) (mul (lit 2) (pv 21 9)))),
   CE.pe (mul (pv 22 21) (add (pv 22 20) (lit 1))),
   CE.pe (mul (lit 2) (pv 23 22)),
   CE.pe (add (mul (lit 4) (pv 24 22)) (lit 2)),
   CE.pe (add (pv 25 9) (lit 22)),
   CE.pe (mul (lit 16) (pv 26 25))]

open PE in
/-- The grid exponents `log₂(1/h_g), log₂(1/h_C), log₂(1/σ), log₂(1/ω), log₂(1/h_P), log₂(1/h_b),
`log₂(1/h_step), log₂(1/h_leaf)` (push indices `27–34`). -/
def segE : List CE :=
  [CE.pe (add (add (add (add (pv 27 10) (pv 27 9)) (pv 27 18)) (lit 20))
     (mul (mul (lit 2) (pv 27 5)) (pv 27 11))),
   CE.pe (add (add (add (mul (add (pv 28 5) (lit 1)) (pv 28 11)) (lit 14)) (pv 28 27))
     (clog (mul (pv 28 6) (pv 28 16)))),
   CE.pe (add (add (add (add (lit 40) (mul (lit 2) (pv 29 17))) (mul (lit 4) (pv 29 9)))
     (mul (lit 2) (pv 29 18)))
     (clog (mul (mul (pv 29 6) (mul (add (pv 29 16) (lit 1)) (add (pv 29 16) (lit 1)))) (pv 29 7)))),
   CE.pe (mul (lit 2) (pv 30 29)),
   CE.pe (add (add (add (add (lit 40) (mul (lit 2) (pv 31 17))) (mul (lit 3) (pv 31 9)))
     (mul (lit 2) (pv 31 18))) (clog (mul (pv 31 6) (pv 31 7)))),
   CE.pe (add (add (add (add (lit 40) (pv 32 17)) (pv 32 9)) (pv 32 30))
     (clog (mul (mul (add (pv 32 6) (lit 1)) (pv 32 7)) (add (pv 32 16) (lit 1))))),
   CE.pe (add (lit 20) (mul (lit 2) (pv 33 9))),
   CE.pe (add (mul (lit 2) (pv 34 27)) (mul (mul (lit 2) (pv 34 5)) (pv 34 33)))]

open PE in
/-- `Z_max, C_max, A_max`, `10nm(U+1)2^{betaExp}`, `M_q`, `q`, the seed trials, `w`, `irrW`,
the bank ADA exponents and `g` (push indices `35–46`). -/
def segF : List CE :=
  [CE.pe (pw2 (clog (mul (mul (lit 8) (pv 35 7)) (add (pv 35 16) (lit 1))))),
   CE.pe (pw2 (clog (mul (lit 8) (add (pw2 (mul (pv 36 11) (pv 36 5))) (lit 1))))),
   CE.pe (pw2 (clog (mul (lit 16) (mul (add (pv 37 16) (lit 1)) (add (pv 37 16) (lit 1)))))),
   CE.pe (mul (mul (mul (mul (lit 10) (pv 38 0)) (pv 38 1)) (add (pv 38 2) (lit 1))) (pw2 (pv 38 4))),
   CE.pe (mul (mul (pv 39 38) (pv 39 38)) (pv 39 38)),
   CE.pe (call Cost.Idx.leastPrimeGE Hash.leastPrimeGE (pv 40 39)),
   CE.pe (add (pv 41 4) (lit 10)),
   CE.pe (clog (add (pv 42 7) (lit 1))),
   CE.pe (call Cost.Idx.irrPoly Hash.irrPoly (pv 43 42)),
   CE.pe (add (add (lit 18) (pv 44 9)) (clog (pv 44 25))),
   CE.pe (add (add (pv 45 4) (lit 7)) (clog (mul (pv 45 1) (add (pv 45 5) (lit 1))))),
   CE.pe (mul (lit 32) (add (add (pv 46 4) (lit 8))
     (clog (mul (mul (pv 46 24) (pv 46 1)) (add (pv 46 5) (lit 1))))))]

/-- The de Bruijn indices (after the `47` pushes) of the outputs `outs P`. -/
def outIdx : List ℕ :=
  [41, 18, 15, 12, 19, 13, 37, 36, 24, 25, 26, 9, 10, 6, 34, 38, 14, 11, 39, 17, 16, 20, 4, 3, 21, 0,
    22, 2, 1, 45, 23, 22, 5]

/-- **The master routine** (index `449`): `encStreamParams P ↦ (outs P).map encN`. -/
def body_w1All : Expr :=
  chainE segA (chainE segB (chainE segC (chainE segD (chainE segE (chainE segF (eVars outIdx))))))

/-- The single-parameter routine at index `400 + k`: element `k` of the master routine's output. -/
def body_param (k : ℕ) : Expr := eNth k (Expr.call Idx.w1All (Expr.var 0))

/-- `peU` (index `414`): `[encStreamParams P, d] ↦ ⌈log₂(2 V_d²)⌉`. -/
def body_peU : Expr :=
  Expr.letE (Expr.call Idx.w1All (eNth 0 (Expr.var 0)))                -- env [L, In]
    (chainE [CE.raw (eNth 14 (Expr.var 0)),                              -- B
      CE.raw (eNth 15 (Expr.var 1)),                                     -- W
      CE.raw (eNth 1 (Expr.var 3)),                                      -- d
      CE.raw (eVd 0 2 1),                                                -- V_d
      CE.pe (clog (PE.mul (PE.lit 2) (PE.mul (PE.var 0) (PE.var 0))))]   -- ⌈log₂(2V_d²)⌉
      (Expr.var 0))

/-- `pGuardCoord` (index `415`): `[encStreamParams P, d, t] ↦ n + H(t-1) + d + 1`. -/
def body_pGuardCoord : Expr :=
  Expr.letE (Expr.call Idx.w1All (eNth 0 (Expr.var 0)))                -- env [L, In]
    (chainE [CE.raw (eNth 0 (Expr.var 0)),                               -- H
      CE.raw (eNth 0 (eNth 0 (Expr.var 2))),                             -- n
      CE.raw (eNth 1 (Expr.var 3)),                                      -- d
      CE.raw (eNth 2 (Expr.var 4)),                                      -- t
      CE.pe (PE.add (PE.add (PE.add (PE.var 2) (PE.mul (PE.var 3) (PE.subL (PE.var 0) 1)))
        (PE.var 1)) (PE.lit 1))]
      (Expr.var 0))

/-! ## The claimed values -/

/-- `10 n m (U+1) 2^{betaExp}` (so `M_q = Mq0 P ^ 3`). -/
def Mq0 (P : StreamParams) : ℕ := 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp

def valsA (P : StreamParams) : List ℕ := [P.n, P.m, P.U, P.epsExp, P.betaExp]
def valsB (P : StreamParams) : List ℕ := [P.H, P.T, P.Dstar, P.W, P.eEta, P.eGamma, P.logB, P.B]
def valsC (P : StreamParams) : List ℕ := [P.Vd P.H, P.H - 1, P.Vd (P.H - 1)]
def valsD (P : StreamParams) : List ℕ :=
  [P.V, P.logG, P.eNu, P.eUstar, P.Kepoch, P.K0, P.Jstar, P.Jmax, P.Rmax, P.s, P.L]
def valsE (P : StreamParams) : List ℕ :=
  [P.eHg, P.eHC, P.eSigma, P.eOmega, P.eHP, P.eHb, P.eHstep, P.eHleaf]
def valsF (P : StreamParams) : List ℕ :=
  [P.Zmax, P.Cmax, P.Amax, Mq0 P, P.Mq, P.q, P.seedTrials, P.w, C.Alg.irrW P, P.eBankA, P.eBankXi,
    P.gCoarse]

/-- The outputs of the master routine: element `k` is the parameter of index `400 + k`
(`k ≠ 14, 15`); elements `14`, `15` are `B` and `W`. -/
def outs (P : StreamParams) : List ℕ :=
  [P.H, P.eHC, P.eHP, P.eHleaf, P.eHg, P.eHstep, P.eEta, P.eGamma, P.Jstar, P.K0, P.Kepoch, P.Amax,
    P.Cmax, P.q, P.B, P.W, P.eHb, P.Zmax, P.Dstar, P.eSigma, P.eOmega, P.L, P.w, C.Alg.irrW P, P.s,
    P.gCoarse, P.Rmax, P.eBankA, P.eBankXi, P.bankM, P.bankJ, P.bankR, P.seedTrials]

/-- W1's own routines: `(index, body)`. -/
def w1Table : List (ℕ × Expr) :=
  [(Idx.w1VdStep, body_vdStep), (Idx.w1All, body_w1All),
   (Idx.pH, body_param 0), (Idx.peHC, body_param 1), (Idx.peHP, body_param 2),
   (Idx.peHleaf, body_param 3), (Idx.peHg, body_param 4), (Idx.peHstep, body_param 5),
   (Idx.peEta, body_param 6), (Idx.peGamma, body_param 7), (Idx.pJstar, body_param 8),
   (Idx.pK0, body_param 9), (Idx.pKepoch, body_param 10), (Idx.pAmax, body_param 11),
   (Idx.pCmax, body_param 12), (Idx.pq, body_param 13), (Idx.peU, body_peU),
   (Idx.pGuardCoord, body_pGuardCoord), (Idx.peHb, body_param 16), (Idx.pZmax, body_param 17),
   (Idx.pDstar, body_param 18), (Idx.peSigma, body_param 19), (Idx.peOmega, body_param 20),
   (Idx.pL, body_param 21), (Idx.pw, body_param 22), (Idx.pIrrW, body_param 23),
   (Idx.ps, body_param 24), (Idx.pgCoarse, body_param 25), (Idx.pRmax, body_param 26),
   (Idx.peBankA, body_param 27), (Idx.peBankXi, body_param 28), (Idx.pbankM, body_param 29),
   (Idx.pbankJ, body_param 30), (Idx.pbankR, body_param 31), (Idx.pSeedTrials, body_param 32)]

end W1

/-- **W1's library predicate**: the program contains W1's routines (`W1.w1Table`), W2's fingerprint
and HASH tables and DSL-CALC's `pow2` / `clog2`. -/
structure W1Lib (prog : List Expr) : Prop where
  fp : Cost.HashDSL.FpLib prog
  hash : Cost.HashDSL.HashLib prog
  pow2 : prog[Cost.Idx.pow2]? = some Cost.body_pow2
  pow2Step : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step
  clog2 : prog[Cost.Idx.clog2]? = some Cost.body_clog2
  clog2Step : prog[Cost.Idx.clog2Step]? = some Cost.body_clog2Step
  vdStep : prog[Idx.w1VdStep]? = some W1.body_vdStep
  all : prog[Idx.w1All]? = some W1.body_w1All
  pH : prog[Idx.pH]? = some (W1.body_param 0)
  peHC : prog[Idx.peHC]? = some (W1.body_param 1)
  peHP : prog[Idx.peHP]? = some (W1.body_param 2)
  peHleaf : prog[Idx.peHleaf]? = some (W1.body_param 3)
  peHg : prog[Idx.peHg]? = some (W1.body_param 4)
  peHstep : prog[Idx.peHstep]? = some (W1.body_param 5)
  peEta : prog[Idx.peEta]? = some (W1.body_param 6)
  peGamma : prog[Idx.peGamma]? = some (W1.body_param 7)
  pJstar : prog[Idx.pJstar]? = some (W1.body_param 8)
  pK0 : prog[Idx.pK0]? = some (W1.body_param 9)
  pKepoch : prog[Idx.pKepoch]? = some (W1.body_param 10)
  pAmax : prog[Idx.pAmax]? = some (W1.body_param 11)
  pCmax : prog[Idx.pCmax]? = some (W1.body_param 12)
  pq : prog[Idx.pq]? = some (W1.body_param 13)
  peU : prog[Idx.peU]? = some W1.body_peU
  pGuardCoord : prog[Idx.pGuardCoord]? = some W1.body_pGuardCoord
  peHb : prog[Idx.peHb]? = some (W1.body_param 16)
  pZmax : prog[Idx.pZmax]? = some (W1.body_param 17)
  pDstar : prog[Idx.pDstar]? = some (W1.body_param 18)
  peSigma : prog[Idx.peSigma]? = some (W1.body_param 19)
  peOmega : prog[Idx.peOmega]? = some (W1.body_param 20)
  pL : prog[Idx.pL]? = some (W1.body_param 21)
  pw : prog[Idx.pw]? = some (W1.body_param 22)
  pIrrW : prog[Idx.pIrrW]? = some (W1.body_param 23)
  ps : prog[Idx.ps]? = some (W1.body_param 24)
  pgCoarse : prog[Idx.pgCoarse]? = some (W1.body_param 25)
  pRmax : prog[Idx.pRmax]? = some (W1.body_param 26)
  peBankA : prog[Idx.peBankA]? = some (W1.body_param 27)
  peBankXi : prog[Idx.peBankXi]? = some (W1.body_param 28)
  pbankM : prog[Idx.pbankM]? = some (W1.body_param 29)
  pbankJ : prog[Idx.pbankJ]? = some (W1.body_param 30)
  pbankR : prog[Idx.pbankR]? = some (W1.body_param 31)
  pSeedTrials : prog[Idx.pSeedTrials]? = some (W1.body_param 32)

/-- `W1Lib` from the table (for the assembly). -/
theorem W1Lib.of_table {prog : List Expr} (hfp : Cost.HashDSL.FpLib prog)
    (hhash : Cost.HashDSL.HashLib prog) (hp1 : prog[Cost.Idx.pow2]? = some Cost.body_pow2)
    (hp2 : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step)
    (hc1 : prog[Cost.Idx.clog2]? = some Cost.body_clog2)
    (hc2 : prog[Cost.Idx.clog2Step]? = some Cost.body_clog2Step)
    (htbl : ∀ i b, (i, b) ∈ W1.w1Table → prog[i]? = some b) : W1Lib prog where
  fp := hfp
  hash := hhash
  pow2 := hp1
  pow2Step := hp2
  clog2 := hc1
  clog2Step := hc2
  vdStep := htbl _ _ (List.mem_of_getElem? (i := 0) rfl)
  all := htbl _ _ (List.mem_of_getElem? (i := 1) rfl)
  pH := htbl _ _ (List.mem_of_getElem? (i := 2) rfl)
  peHC := htbl _ _ (List.mem_of_getElem? (i := 3) rfl)
  peHP := htbl _ _ (List.mem_of_getElem? (i := 4) rfl)
  peHleaf := htbl _ _ (List.mem_of_getElem? (i := 5) rfl)
  peHg := htbl _ _ (List.mem_of_getElem? (i := 6) rfl)
  peHstep := htbl _ _ (List.mem_of_getElem? (i := 7) rfl)
  peEta := htbl _ _ (List.mem_of_getElem? (i := 8) rfl)
  peGamma := htbl _ _ (List.mem_of_getElem? (i := 9) rfl)
  pJstar := htbl _ _ (List.mem_of_getElem? (i := 10) rfl)
  pK0 := htbl _ _ (List.mem_of_getElem? (i := 11) rfl)
  pKepoch := htbl _ _ (List.mem_of_getElem? (i := 12) rfl)
  pAmax := htbl _ _ (List.mem_of_getElem? (i := 13) rfl)
  pCmax := htbl _ _ (List.mem_of_getElem? (i := 14) rfl)
  pq := htbl _ _ (List.mem_of_getElem? (i := 15) rfl)
  peU := htbl _ _ (List.mem_of_getElem? (i := 16) rfl)
  pGuardCoord := htbl _ _ (List.mem_of_getElem? (i := 17) rfl)
  peHb := htbl _ _ (List.mem_of_getElem? (i := 18) rfl)
  pZmax := htbl _ _ (List.mem_of_getElem? (i := 19) rfl)
  pDstar := htbl _ _ (List.mem_of_getElem? (i := 20) rfl)
  peSigma := htbl _ _ (List.mem_of_getElem? (i := 21) rfl)
  peOmega := htbl _ _ (List.mem_of_getElem? (i := 22) rfl)
  pL := htbl _ _ (List.mem_of_getElem? (i := 23) rfl)
  pw := htbl _ _ (List.mem_of_getElem? (i := 24) rfl)
  pIrrW := htbl _ _ (List.mem_of_getElem? (i := 25) rfl)
  ps := htbl _ _ (List.mem_of_getElem? (i := 26) rfl)
  pgCoarse := htbl _ _ (List.mem_of_getElem? (i := 27) rfl)
  pRmax := htbl _ _ (List.mem_of_getElem? (i := 28) rfl)
  peBankA := htbl _ _ (List.mem_of_getElem? (i := 29) rfl)
  peBankXi := htbl _ _ (List.mem_of_getElem? (i := 30) rfl)
  pbankM := htbl _ _ (List.mem_of_getElem? (i := 31) rfl)
  pbankJ := htbl _ _ (List.mem_of_getElem? (i := 32) rfl)
  pbankR := htbl _ _ (List.mem_of_getElem? (i := 33) rfl)
  pSeedTrials := htbl _ _ (List.mem_of_getElem? (i := 34) rfl)

namespace W1

/-! ## Every claimed value is `≤ A = 2^{8ℒ³}` -/

section bounds

variable (P : StreamParams)

theorem calL_le_cube : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _

theorem calL_sq_le_cube : P.calL ^ 2 ≤ P.calL ^ 3 := by
  have := Space.hundred_mul_sq_le_cube P
  omega

theorem le_A_of_le_lin {x : ℕ} (h : x ≤ 2 ^ 10 * P.calL) : x ≤ Abnd P :=
  le_Abnd_of_le (h.trans (Nat.mul_le_mul_left _ (calL_le_cube P)))

theorem le_A_of_le_sq {x : ℕ} (h : x ≤ 2 ^ 10 * P.calL ^ 2) : x ≤ Abnd P :=
  le_Abnd_of_le (h.trans (Nat.mul_le_mul_left _ (calL_sq_le_cube P)))

theorem le_A_of_le_pow_lin {x c : ℕ} (hx : x ≤ 2 ^ c) (hc : c ≤ 7 * P.calL) : x ≤ Abnd P :=
  le_Abnd_of_le_two_pow hx (by have := calL_le_cube P; omega)

theorem epsExp_le_calL : P.epsExp ≤ P.calL := by
  have := Space.calL_eq_cP P
  omega

theorem betaExp_le_calL : P.betaExp + 100 ≤ P.calL := by
  have := Space.calL_eq_cP P
  omega

theorem n_le_A : P.n ≤ Abnd P :=
  le_A_of_le_pow_lin P (W2.n_lt_two_pow_calL P).le (by omega)

theorem m_le_A : P.m ≤ Abnd P := le_A_of_le_pow_lin P (Space.m_le P) (by omega)

theorem U_le_A : P.U ≤ Abnd P :=
  le_A_of_le_pow_lin P (c := P.calL) (by have := W2.two_U_lt_two_pow_calL P; omega) (by omega)

theorem epsExp_le_A : P.epsExp ≤ Abnd P :=
  le_A_of_le_lin P (by have := epsExp_le_calL P; omega)

theorem betaExp_le_A : P.betaExp ≤ Abnd P :=
  le_A_of_le_lin P (by have := betaExp_le_calL P; omega)

theorem T_le_A : P.T ≤ Abnd P := le_A_of_le_pow_lin P (Space.T_le P) (by omega)

theorem Dstar_le_A : P.Dstar ≤ Abnd P := le_A_of_le_pow_lin P (Space.Dstar_le P) (by omega)

theorem eEta_le_A : P.eEta ≤ Abnd P := le_A_of_le_lin P (by have := Space.eEta_le P; omega)

theorem eGamma_le_A : P.eGamma ≤ Abnd P :=
  le_A_of_le_lin P (by have := Space.eGamma_le P; have := Space.hundred_le_calL P; omega)

theorem logB_le_A : P.logB ≤ Abnd P := le_A_of_le_lin P (by have := Space.logB_le P; omega)

theorem Hm1_le_A : P.H - 1 ≤ Abnd P := (Nat.sub_le _ _).trans (H_le_Abnd P)

theorem V_le_A : P.V ≤ Abnd P := le_Abnd_of_le_two_pow (Space.V_le P) (by omega)

theorem logG_le_A : P.logG ≤ Abnd P := le_A_of_le_sq P (by have := Space.logG_le P; omega)

theorem eNu_le_A : P.eNu ≤ Abnd P := le_A_of_le_lin P (by have := Space.eNu_le P; omega)

theorem eUstar_le_A : P.eUstar ≤ Abnd P := le_Abnd_of_le (by have := Space.eUstar_le P; omega)

theorem Kepoch_le_A : P.Kepoch ≤ Abnd P := le_Abnd_of_le (by have := Space.Kepoch_le P; omega)

theorem K0_le_A : P.K0 ≤ Abnd P :=
  le_A_of_le_pow_lin P (c := 7 + 2 * P.eEta) (le_of_eq rfl)
    (by have := Space.eEta_le P; have := Space.hundred_le_calL P; omega)

theorem Rmax_le_A : P.Rmax ≤ Abnd P := by
  have hR := Space.Rmax_le P
  have hL := Space.hundred_le_calL P
  have h4 : P.calL ^ 4 ≤ 2 ^ P.calL := Space.pow_four_le_two_pow (by omega)
  have h34 : P.calL ^ 3 ≤ P.calL ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have h1 : P.Rmax ≤ 2 ^ (13 + 2 * P.eEta + P.calL) := by
    calc P.Rmax ≤ 2 ^ 13 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := hR
      _ ≤ 2 ^ 13 * 2 ^ (2 * P.eEta) * 2 ^ P.calL := Nat.mul_le_mul_left _ (h34.trans h4)
      _ = 2 ^ (13 + 2 * P.eEta + P.calL) := by rw [pow_add, pow_add]
  exact le_A_of_le_pow_lin P h1 (by have := Space.eEta_le P; omega)

theorem Jstar_le_A : P.Jstar ≤ Abnd P :=
  le_trans (by unfold StreamParams.Rmax; omega) (Rmax_le_A P)

theorem Jmax_le_A : P.Jmax ≤ Abnd P :=
  le_trans (by unfold StreamParams.Rmax StreamParams.Jmax; omega) (Rmax_le_A P)

theorem s_le_A : P.s ≤ Abnd P := le_A_of_le_lin P (by have := Space.s_le P; omega)

theorem L_le_A : P.L ≤ Abnd P :=
  le_A_of_le_lin P (by have := Space.s_le P; unfold StreamParams.L; omega)

theorem eHg_le_A : P.eHg ≤ Abnd P := le_A_of_le_sq P (by have := Space.eHg_le P; omega)

theorem eHC_le_A : P.eHC ≤ Abnd P := le_Abnd_of_le (by have := Space.eHC_le P; omega)

theorem eSigma_le_A : P.eSigma ≤ Abnd P := le_Abnd_of_le (by have := Space.eSigma_le P; omega)

theorem eOmega_le_A : P.eOmega ≤ Abnd P := le_Abnd_of_le (by have := Space.eOmega_le P; omega)

theorem eHP_le_A : P.eHP ≤ Abnd P := le_A_of_le_sq P (by have := Space.eHP_le P; omega)

theorem eHb_le_A : P.eHb ≤ Abnd P := le_Abnd_of_le (by have := Space.eHb_le P; omega)

theorem eHstep_le_A : P.eHstep ≤ Abnd P := le_A_of_le_lin P (by have := Space.eHstep_le P; omega)

theorem eHleaf_le_A : P.eHleaf ≤ Abnd P := le_A_of_le_sq P (by have := Space.eHleaf_le P; omega)

theorem Zmax_le_A : P.Zmax ≤ Abnd P :=
  le_Abnd_of_le_two_pow (le_of_eq rfl) (by have := Space.eZmax_le P; omega)

theorem Cmax_le_A : P.Cmax ≤ Abnd P :=
  le_Abnd_of_le_two_pow (le_of_eq rfl)
    (by have := Space.eCmax_le P; have := calL_sq_le_cube P; omega)

theorem Amax_le_A : P.Amax ≤ Abnd P :=
  le_Abnd_of_le_two_pow (le_of_eq rfl) (by have := Space.eAmax_le P; omega)

theorem Mq_le_A : P.Mq ≤ Abnd P :=
  le_A_of_le_pow_lin P (Space.Mq_le P) (by have := Space.calL_eq_cP P; omega)

theorem Mq0_le_A : Mq0 P ≤ Abnd P :=
  calc Mq0 P ≤ Mq0 P ^ 3 := Nat.le_self_pow (by norm_num) _
    _ = P.Mq := rfl
    _ ≤ Abnd P := Mq_le_A P

theorem q_le_A : P.q ≤ Abnd P := le_A_of_le_pow_lin P (Space.q_le P) (by omega)

theorem seedTrials_le_A : P.seedTrials ≤ Abnd P :=
  le_A_of_le_lin P (by have := betaExp_le_calL P; unfold StreamParams.seedTrials; omega)

theorem w_le_A : P.w ≤ Abnd P :=
  le_A_of_le_lin P (by have := Space.w_le P; have := Space.hundred_le_calL P; omega)

theorem irrW_le_A : C.Alg.irrW P ≤ Abnd P := by
  obtain ⟨-, hp2, -⟩ := Cost.HashDSL.isIrrPoly_irrW P (W2.one_le_Dstar P)
  exact le_A_of_le_pow_lin P hp2.le
    (by have := Space.w_le P; have := Space.hundred_le_calL P; omega)

theorem eBankA_le_A : P.eBankA ≤ Abnd P := le_A_of_le_lin P (by have := Space.eBankA_le P; omega)

theorem eBankXi_le_A : P.eBankXi ≤ Abnd P :=
  le_A_of_le_lin P (by have := Space.eBankXi_le P; omega)

theorem gCoarse_le_A : P.gCoarse ≤ Abnd P :=
  le_A_of_le_lin P (by have := Space.gCoarse_le P; omega)

end bounds

end W1

end F2e2e.C.Impl
