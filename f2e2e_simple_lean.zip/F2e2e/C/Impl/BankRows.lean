import F2e2e.C.Impl.BankArith

/-!
# W5: the row operations mapped over a bank (750–755)

* `ev_param`, `ev_pow2`: calls of W1's parameter routines and of ARITH's `pow2`;
* the row-operation dispatcher `bkRowOp` (770) on `[encRow r, ex]`: `bkRowOp_reset_val`,
  `bkRowOp_add_val`, `bkRowOp_scale_val` (references `Row.resetY`, `rowAddRef`, `rowScaleRef`);
* the bank map `bkBankMap` (777, nested `mapB` 771–776): `bkBankMap_val`;
* the six entries in contract form: `resetYBank_spec`, `addPhysBank_spec`, `addGuardYBank_spec`,
  `addGuardXYBank_spec`, `scaleYBank_spec`, `scaleXYBank_spec`.
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## Size facts -/

theorem valSize_encStreamParams_le' (P : StreamParams) :
    valSize (encStreamParams P) ≤ 5 * P.calL + 11 := by
  have hn : P.n < 2 ^ cP P := by have := n_add_two_le P; omega
  have hm : P.m < 2 ^ cP P := by have := m_add_two_le P; omega
  have hU : P.U < 2 ^ cP P := by
    have h := prod_le_two_pow_cP P
    have h1 : P.U + 2 ≤ (P.n + 2) * (P.m + 2) * (P.U + 2) :=
      Nat.le_mul_of_pos_left _ (by positivity)
    omega
  have hc := cP_add_hundred_le P
  have he : P.epsExp ≤ P.calL := by rw [calL_eq_cP]; omega
  have hb : P.betaExp ≤ P.calL := by rw [calL_eq_cP]; omega
  simp only [encStreamParams, valSize_encInts, List.map_cons, List.map_nil, List.sum_cons,
    List.sum_nil, bitLen_natCast]
  have h1 := Nat.size_le.mpr hn
  have h2 := Nat.size_le.mpr hm
  have h3 := Nat.size_le.mpr hU
  have h4 := size_le_self P.epsExp
  have h5 := size_le_self P.betaExp
  omega

theorem bitLen_sat_le {Z : ℤ} (hZ : 0 ≤ Z) (z : ℤ) : bitLen (sat Z z) ≤ bitLen Z := by
  apply bitLen_le_bitLen_of_natAbs_le
  have h1 : -Z ≤ sat Z z := le_max_left _ _
  have h2 : sat Z z ≤ Z := max_le (by omega) (min_le_left _ _)
  omega

theorem abs_sat_le {Z : ℤ} (hZ : 0 ≤ Z) (z : ℤ) : |sat Z z| ≤ Z := by
  have h1 : -Z ≤ sat Z z := le_max_left _ _
  have h2 : sat Z z ≤ Z := max_le (by omega) (min_le_left _ _)
  exact abs_le.mpr ⟨h1, h2⟩

theorem zSat_nonneg (P : StreamParams) : 0 ≤ zSat P := by
  unfold zSat
  exact mul_nonneg (Int.natCast_nonneg _) (pow_nonneg (by norm_num) _)

theorem bitLen_rowSign_le (P : StreamParams) (r : Row) (i : ℕ) : bitLen (rowSign P r i) ≤ 1 := by
  unfold rowSign
  split_ifs <;> simp

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-! ## Parameters and powers of two -/

/-- A call of a W1 parameter routine. -/
theorem ev_param {R : AdaRep} {idx : ℕ} {f : StreamParams → ℕ} (hs : ParamSpec R prog M idx f)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (encStreamParams P)) :
    EvalsVal prog M env [] (.inl (eCall idx a)) (Val.int (f P : ℤ)) := by
  obtain ⟨body, hb, hspec⟩ := hs
  exact ev_call hb ha (hspec P hP hM)

/-- A call of ARITH's `pow2`. -/
theorem ev_pow2 (hlib : BankLib prog) {a : Expr} {k : ℕ}
    (ha : EvalsVal prog M env [] (.inl a) (Val.int (k : ℤ))) (hM : Cost.S_pow2 k ≤ M) :
    EvalsVal prog M env [] (.inl (ePow2 a)) (Val.int ((2 : ℤ) ^ k)) := by
  have h := ev_call hlib.pow2 ha ((Cost.pow2_spec hlib.pow2Step k 0).toVal.mono_M hM)
  simpa [encN] using h

/-! ## The row-operation dispatcher -/

/-- The `ex` record of the row-operation dispatcher `[kind, Z, w, irrW, coord, a, b, both]`. -/
def exVal (kind Z w irr coord a b both : ℤ) : Val :=
  Val.list [Val.int kind, Val.int Z, Val.int w, Val.int irr, Val.int coord, Val.int a, Val.int b,
    Val.int both]

/-- Kind `1`: add `rdiv(a b_coord, b)` to `Y` (and to `X` if `both ≠ 0`), saturated. -/
def rowAddRef (P : StreamParams) (coord : ℕ) (a b both : ℤ) (r : Row) : Row :=
  { r with X := if both = 0 then r.X else sat (zSat P) (r.X + rdivZ (a * rowSign P r coord) b),
           Y := sat (zSat P) (r.Y + rdivZ (a * rowSign P r coord) b) }

/-- Kind `2`: replace `Y` (and `X` if `both ≠ 0`) by `rdiv(a ·, b)`, saturated. -/
def rowScaleRef (P : StreamParams) (a b both : ℤ) (r : Row) : Row :=
  { r with X := if both = 0 then r.X else sat (zSat P) (rdivZ (a * r.X) b),
           Y := sat (zSat P) (rdivZ (a * r.Y) b) }

theorem bkRowOp_reset_val (r : Row) {K : ℕ} (hKr : valSize (encRow r) ≤ K) (hM : 2 * K + 40 ≤ M) :
    EvalsVal prog M [Val.list [encRow r, exVal 0 0 0 0 0 0 1 0]] [] (.inl body_bkRowOp)
      (encRow r.resetY) := by
  have hr' := hKr
  simp only [encRow, valSize_list, valSize_int, listSize_cons, listSize_nil] at hr'
  have hI : valSize (Val.list [encRow r, exVal 0 0 0 0 0 0 1 0]) ≤ M := by
    simp only [encRow, exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero,
      bitLen_one]
    omega
  have hrow : valSize (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X,
      Val.int r.Y]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hex : valSize (Val.list [Val.int 0, Val.int 0, Val.int 0, Val.int 0, Val.int 0, Val.int 0,
      Val.int 1, Val.int 0]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero, bitLen_one]
    omega
  have h2 : 2 ≤ M := by omega
  show EvalsVal prog M [Val.list [encRow r, exVal 0 0 0 0 0 0 1 0]] [] (.inl body_bkRowOp)
    (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X, Val.int 0])
  unfold body_bkRowOp
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_let (ev_hd (ev_var rfl) hrow) (ev_let (ev_at1 (ev_var rfl) hrow)
    (ev_let (ev_at2 (ev_var rfl) hrow) (ev_let (ev_hd (ev_var rfl) hex) ?_)))
  refine ev_ite_t (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  exact ev_list (.cons (ev_var rfl) (.cons (ev_var rfl) (.cons (ev_lit (by simp; omega)) .nil)))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)

theorem bkRowOp_add_val (hlib : BankLib prog) (hw2 : HornerLib prog) (P : StreamParams)
    (hP : ParamsOK P) (r : Row) (hr : RowOK P r) (coord : ℕ) (hc1 : 1 ≤ coord)
    (hc : coord ≤ P.Dstar) (a b both : ℤ) (hb : 0 < b) {K : ℕ}
    (hKr : valSize (encRow r) ≤ K)
    (hKe : valSize (exVal 1 (zSat P) P.w (irrW P) coord a b both) ≤ K)
    (hM : 2 ^ 20 * P.calL ^ 3 + 64 * K + 200 ≤ M) :
    EvalsVal prog M [Val.list [encRow r, exVal 1 (zSat P) P.w (irrW P) coord a b both]] []
      (.inl body_bkRowOp) (encRow (rowAddRef P coord a b both r)) := by
  have hZ0 : 0 ≤ zSat P := zSat_nonneg P
  have hr' := hKr
  simp only [encRow, valSize_list, valSize_int, listSize_cons, listSize_nil] at hr'
  have he' := hKe
  simp only [exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one] at he'
  have hs : bitLen (rowSign P r coord) ≤ 1 := bitLen_rowSign_le P r coord
  have has : bitLen (a * rowSign P r coord) ≤ K + 1 :=
    (bitLen_mul_le' a (rowSign P r coord)).trans (by omega)
  have hinc : bitLen (rdivZ (a * rowSign P r coord) b) ≤ 2 * K + 4 :=
    (bitLen_rdivZ_le _ _).trans (by omega)
  have hXi : bitLen (r.X + rdivZ (a * rowSign P r coord) b) ≤ 2 * K + 5 := by
    have h1 := bitLen_add_le r.X (rdivZ (a * rowSign P r coord) b)
    have h2 : max (bitLen r.X) (bitLen (rdivZ (a * rowSign P r coord) b)) ≤ 2 * K + 4 :=
      max_le (by omega) hinc
    omega
  have hYi : bitLen (r.Y + rdivZ (a * rowSign P r coord) b) ≤ 2 * K + 5 := by
    have h1 := bitLen_add_le r.Y (rdivZ (a * rowSign P r coord) b)
    have h2 : max (bitLen r.Y) (bitLen (rdivZ (a * rowSign P r coord) b)) ≤ 2 * K + 4 :=
      max_le (by omega) hinc
    omega
  have hsX := bitLen_sat_le hZ0 (r.X + rdivZ (a * rowSign P r coord) b)
  have hsY := bitLen_sat_le hZ0 (r.Y + rdivZ (a * rowSign P r coord) b)
  have hI : valSize (Val.list [encRow r, exVal 1 (zSat P) P.w (irrW P) coord a b both]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hrow : valSize (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X,
      Val.int r.Y]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hex : valSize (Val.list [Val.int 1, Val.int (zSat P), Val.int (P.w : ℤ),
      Val.int (irrW P : ℤ), Val.int (coord : ℤ), Val.int a, Val.int b, Val.int both]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega
  have h2 : 2 ≤ M := by omega
  have h20 : 2 ^ 20 * P.calL ^ 3 ≤ M := by omega
  have hXv : (if both = 0 then Val.int r.X else
      Val.int (sat (zSat P) (r.X + rdivZ (a * rowSign P r coord) b))) =
      Val.int (if both = 0 then r.X else sat (zSat P) (r.X + rdivZ (a * rowSign P r coord) b)) := by
    split_ifs <;> rfl
  show EvalsVal prog M [Val.list [encRow r, exVal 1 (zSat P) P.w (irrW P) coord a b both]] []
    (.inl body_bkRowOp) (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)),
      Val.int (if both = 0 then r.X else sat (zSat P) (r.X + rdivZ (a * rowSign P r coord) b)),
      Val.int (sat (zSat P) (r.Y + rdivZ (a * rowSign P r coord) b))])
  rw [← hXv]
  unfold body_bkRowOp
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_let (ev_hd (ev_var rfl) hrow) (ev_let (ev_at1 (ev_var rfl) hrow)
    (ev_let (ev_at2 (ev_var rfl) hrow) (ev_let (ev_hd (ev_var rfl) hex) ?_)))
  refine ev_ite_f (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  refine ev_let (ev_at1 (ev_var rfl) hex) (ev_let (ev_at5 (ev_var rfl) hex)
    (ev_let (ev_at6 (ev_var rfl) hex) (ev_let (ev_at7 (ev_var rfl) hex) ?_)))
  refine ev_ite_t (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  have hsd : encInts (r.seed.map fun z : ℕ => (z : ℤ)) = encL encN r.seed := encInts_seed r
  refine ev_let (rowSign_call_val hw2 P hP r hr coord hc1 hc h20 ?_) ?_
  · rw [← hsd]
    exact ev_list (.cons (ev_at2 (ev_var rfl) hex) (.cons (ev_at3 (ev_var rfl) hex)
      (.cons (ev_var rfl) (.cons (ev_at4 (ev_var rfl) hex) .nil))))
      (by simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  refine ev_let (ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_var rfl) (ev_var rfl)
    (by simp only [encZ, valSize_int]; omega)) (ev_var rfl)
    (by simp only [encZ, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
    (bkRDiv_val (a * rowSign P r coord) b hb (by omega))) ?_
  refine ev_list (.cons (ev_var rfl) (.cons ?_ (.cons ?_ .nil))) ?_
  · exact ev_ite_dec (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (fun _ => ev_var rfl)
      (fun _ => ev_call hlib.bkSat (ev_pair (ev_var rfl) (ev_add (ev_var rfl) (ev_var rfl)
        (by simp only [valSize_int]; omega))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (bkSat_val _ _ hZ0 (by omega)))
  · exact ev_call hlib.bkSat (ev_pair (ev_var rfl) (ev_add (ev_var rfl) (ev_var rfl)
        (by simp only [valSize_int]; omega))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (bkSat_val _ _ hZ0 (by omega))
  · rw [hXv]
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    split_ifs <;> omega

theorem bkRowOp_scale_val (hlib : BankLib prog) (P : StreamParams) (r : Row)
    (a b both : ℤ) (hb : 0 < b) {K : ℕ}
    (hKr : valSize (encRow r) ≤ K)
    (hKe : valSize (exVal 2 (zSat P) 0 0 0 a b both) ≤ K)
    (hM : 64 * K + 200 ≤ M) :
    EvalsVal prog M [Val.list [encRow r, exVal 2 (zSat P) 0 0 0 a b both]] []
      (.inl body_bkRowOp) (encRow (rowScaleRef P a b both r)) := by
  have hZ0 : 0 ≤ zSat P := zSat_nonneg P
  have hr' := hKr
  simp only [encRow, valSize_list, valSize_int, listSize_cons, listSize_nil] at hr'
  have he' := hKe
  simp only [exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero] at he'
  have haX : bitLen (a * r.X) ≤ 2 * K := (bitLen_mul_le' a r.X).trans (by omega)
  have haY : bitLen (a * r.Y) ≤ 2 * K := (bitLen_mul_le' a r.Y).trans (by omega)
  have hqX : bitLen (rdivZ (a * r.X) b) ≤ 3 * K + 3 := (bitLen_rdivZ_le _ _).trans (by omega)
  have hqY : bitLen (rdivZ (a * r.Y) b) ≤ 3 * K + 3 := (bitLen_rdivZ_le _ _).trans (by omega)
  have hsX := bitLen_sat_le hZ0 (rdivZ (a * r.X) b)
  have hsY := bitLen_sat_le hZ0 (rdivZ (a * r.Y) b)
  have hI : valSize (Val.list [encRow r, exVal 2 (zSat P) 0 0 0 a b both]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hrow : valSize (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X,
      Val.int r.Y]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hex : valSize (Val.list [Val.int 2, Val.int (zSat P), Val.int 0, Val.int 0, Val.int 0,
      Val.int a, Val.int b, Val.int both]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega
  have h2 : 2 ≤ M := by omega
  have hXv : (if both = 0 then Val.int r.X else Val.int (sat (zSat P) (rdivZ (a * r.X) b))) =
      Val.int (if both = 0 then r.X else sat (zSat P) (rdivZ (a * r.X) b)) := by
    split_ifs <;> rfl
  show EvalsVal prog M [Val.list [encRow r, exVal 2 (zSat P) 0 0 0 a b both]] []
    (.inl body_bkRowOp) (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)),
      Val.int (if both = 0 then r.X else sat (zSat P) (rdivZ (a * r.X) b)),
      Val.int (sat (zSat P) (rdivZ (a * r.Y) b))])
  rw [← hXv]
  unfold body_bkRowOp
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_let (ev_hd (ev_var rfl) hrow) (ev_let (ev_at1 (ev_var rfl) hrow)
    (ev_let (ev_at2 (ev_var rfl) hrow) (ev_let (ev_hd (ev_var rfl) hex) ?_)))
  refine ev_ite_f (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  refine ev_let (ev_at1 (ev_var rfl) hex) (ev_let (ev_at5 (ev_var rfl) hex)
    (ev_let (ev_at6 (ev_var rfl) hex) (ev_let (ev_at7 (ev_var rfl) hex) ?_)))
  refine ev_ite_f (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (by simp) ?_
  refine ev_list (.cons (ev_var rfl) (.cons ?_ (.cons ?_ .nil))) ?_
  · exact ev_ite_dec (ev_eq (ev_var rfl) (ev_lit (by simp; omega)) h2) (fun _ => ev_var rfl)
      (fun _ => ev_call hlib.bkSat (ev_pair (ev_var rfl)
        (ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_var rfl) (ev_var rfl)
          (by simp only [valSize_int]; omega)) (ev_var rfl)
          (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
          (bkRDiv_val _ b hb (by omega)))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (bkSat_val _ _ hZ0 (by omega)))
  · exact ev_call hlib.bkSat (ev_pair (ev_var rfl)
        (ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_var rfl) (ev_var rfl)
          (by simp only [valSize_int]; omega)) (ev_var rfl)
          (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
          (bkRDiv_val _ b hb (by omega)))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (bkSat_val _ _ hZ0 (by omega))
  · rw [hXv]
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    split_ifs <;> omega

/-! ## The bank map -/

theorem valSize_lt_encL {α : Type} (f : α → Val) {x : α} {l : List α} (h : x ∈ l) :
    valSize (f x) < valSize (encL f l) :=
  valSize_lt_of_mem (List.mem_map.mpr ⟨x, h, rfl⟩)

/-- Rows: `[encL encRow l, ex] ↦ encL encRow (l.map f)` (`body_mapB bkRowOpStep`, at `bkBlockOp`). -/
theorem bkRowsMap_val (hlib : BankLib prog) (f : Row → Row) (Q : Row → Prop) (ex : Val)
    (hF : ∀ r, Q r → EvalsVal prog M [Val.list [encRow r, ex]] [] (.inl body_bkRowOp) (encRow (f r)))
    (l : List Row) (hl : ∀ r ∈ l, Q r)
    (hM : valSize (encL encRow l) + 5 * valSize (encL encRow (l.map f)) + valSize ex + 60 ≤ M) :
    EvalsVal prog M [Val.list [encL encRow l, ex]] [] (.inl (body_mapB Idx.bkRowOpStep))
      (encL encRow (l.map f)) :=
  mapD_val hlib.bkRowOpStep hlib.bkRowOp hlib.reverse hlib.revAppendStep encRow encRow ex f l
    (fun r hr => hF r (hl r hr)) hM

/-- Blocks: `[encL (encL encRow) L, ex] ↦ …` (`body_mapB bkBlockOpStep`, at `bkBlocksOp`). -/
theorem bkBlocksMap_val (hlib : BankLib prog) (f : Row → Row) (Q : Row → Prop) (ex : Val)
    (hF : ∀ r, Q r → EvalsVal prog M [Val.list [encRow r, ex]] [] (.inl body_bkRowOp) (encRow (f r)))
    (L : List (List Row)) (hL : ∀ blk ∈ L, ∀ r ∈ blk, Q r)
    (hM : 6 * valSize (encL (encL encRow) L) + 6 * valSize (encL (encL encRow) (L.map (·.map f))) +
      valSize ex + 60 ≤ M) :
    EvalsVal prog M [Val.list [encL (encL encRow) L, ex]] [] (.inl (body_mapB Idx.bkBlockOpStep))
      (encL (encL encRow) (L.map (·.map f))) :=
  mapD_val hlib.bkBlockOpStep hlib.bkBlockOp hlib.reverse hlib.revAppendStep (encL encRow)
    (encL encRow) ex (·.map f) L
    (fun blk hblk => bkRowsMap_val hlib f Q ex hF blk (hL blk hblk) (by
      have h1 := valSize_lt_encL (encL encRow) hblk
      have h2 := valSize_lt_encL (encL encRow) (List.mem_map.mpr ⟨blk, hblk, rfl⟩ :
        blk.map f ∈ L.map (·.map f))
      omega)) (by omega)

/-- Groups: `[encL (encL (encL encRow)) G, ex] ↦ …` (`body_mapB bkBlocksOpStep`, at `bkGroupsOp`). -/
theorem bkGroupsMap_val (hlib : BankLib prog) (f : Row → Row) (Q : Row → Prop) (ex : Val)
    (hF : ∀ r, Q r → EvalsVal prog M [Val.list [encRow r, ex]] [] (.inl body_bkRowOp) (encRow (f r)))
    (G : List (List (List Row))) (hG : ∀ grp ∈ G, ∀ sub ∈ grp, ∀ r ∈ sub, Q r)
    (hM : 6 * valSize (encL (encL (encL encRow)) G) +
      6 * valSize (encL (encL (encL encRow)) (G.map (·.map (·.map f)))) + valSize ex + 60 ≤ M) :
    EvalsVal prog M [Val.list [encL (encL (encL encRow)) G, ex]] []
      (.inl (body_mapB Idx.bkBlocksOpStep)) (encL (encL (encL encRow)) (G.map (·.map (·.map f)))) :=
  mapD_val hlib.bkBlocksOpStep hlib.bkBlocksOp hlib.reverse hlib.revAppendStep
    (encL (encL encRow)) (encL (encL encRow)) ex (·.map (·.map f)) G
    (fun grp hgrp => bkBlocksMap_val hlib f Q ex hF grp (hG grp hgrp) (by
      have h1 := valSize_lt_encL (encL (encL encRow)) hgrp
      have h2 := valSize_lt_encL (encL (encL encRow)) (List.mem_map.mpr ⟨grp, hgrp, rfl⟩ :
        grp.map (·.map f) ∈ G.map (·.map (·.map f)))
      omega)) (by omega)

/-- **The bank map** `[encBank B, ex] ↦ encBank (B.mapRows f)`, if the dispatcher maps every row
of `B` (`Q`) to `f r`. -/
theorem bkBankMap_val (hlib : BankLib prog) (f : Row → Row) (Q : Row → Prop) (ex : Val)
    (enc : AdaState → Val) (B : Bank)
    (hF : ∀ r, Q r → EvalsVal prog M [Val.list [encRow r, ex]] [] (.inl body_bkRowOp) (encRow (f r)))
    (hQa : ∀ blk ∈ B.ada, ∀ r ∈ blk, Q r) (hQc : ∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, Q r)
    (hM : 6 * valSize (encBank enc B) + 6 * valSize (encBank enc (B.mapRows f)) + valSize ex + 100
      ≤ M) :
    EvalsVal prog M [Val.list [encBank enc B, ex]] [] (.inl body_bkBankMap)
      (encBank enc (B.mapRows f)) := by
  have e1 : encBank enc B = Val.list [encL (encL encRow) B.ada,
      encL (encL (encL encRow)) B.coarse, enc B.adaSt] := rfl
  have e2 : encBank enc (B.mapRows f) = Val.list [encL (encL encRow) (B.ada.map (·.map f)),
      encL (encL (encL encRow)) (B.coarse.map (·.map (·.map f))), enc B.adaSt] := rfl
  rw [e1, e2] at hM ⊢
  have hS1 := valSize_head_le' (encL (encL encRow) B.ada)
    [encL (encL (encL encRow)) B.coarse, enc B.adaSt]
  have hS2 := valSize_head_le' (encL (encL encRow) (B.ada.map (·.map f)))
    [encL (encL (encL encRow)) (B.coarse.map (·.map (·.map f))), enc B.adaSt]
  have hS3 : valSize (encL (encL (encL encRow)) B.coarse) ≤ valSize (Val.list
      [encL (encL encRow) B.ada, encL (encL (encL encRow)) B.coarse, enc B.adaSt]) :=
    le_of_lt (valSize_lt_of_mem (by simp))
  have hS4 : valSize (encL (encL (encL encRow)) (B.coarse.map (·.map (·.map f)))) ≤
      valSize (Val.list [encL (encL encRow) (B.ada.map (·.map f)),
        encL (encL (encL encRow)) (B.coarse.map (·.map (·.map f))), enc B.adaSt]) :=
    le_of_lt (valSize_lt_of_mem (by simp))
  have hI : valSize (Val.list [Val.list [encL (encL encRow) B.ada,
      encL (encL (encL encRow)) B.coarse, enc B.adaSt], ex]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hbank : valSize (Val.list [encL (encL encRow) B.ada,
      encL (encL (encL encRow)) B.coarse, enc B.adaSt]) ≤ M := by omega
  have hAda := bkBlocksMap_val hlib f Q ex hF B.ada hQa (by omega)
  have hCoarse := bkGroupsMap_val hlib f Q ex hF B.coarse hQc (by omega)
  unfold body_bkBankMap
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  refine ev_list (.cons (ev_call hlib.bkBlocksOp (ev_pair (ev_hd (ev_var rfl) hbank) (ev_var rfl)
      (by simp only [valSize_list, listSize_cons, listSize_nil] at hbank hI ⊢; omega)) hAda)
    (.cons (ev_call hlib.bkGroupsOp (ev_pair (ev_at1 (ev_var rfl) hbank) (ev_var rfl)
      (by simp only [valSize_list, listSize_cons, listSize_nil] at hbank hI ⊢; omega)) hCoarse)
    (.cons (ev_at2 (ev_var rfl) hbank) .nil))) (by omega)

end rules

/-! ## Invariants and sizes -/

theorem rowOK_resetY {P : StreamParams} {r : Row} (hr : RowOK P r) : RowOK P r.resetY :=
  ⟨hr.seed_length, hr.seed_lt, hr.abs_X_le, by simp only [Row.resetY, abs_zero]; exact zSat_nonneg P⟩

theorem rowOK_rowAddRef {P : StreamParams} {r : Row} (hr : RowOK P r) (coord : ℕ) (a b both : ℤ) :
    RowOK P (rowAddRef P coord a b both r) := by
  refine ⟨hr.seed_length, hr.seed_lt, ?_, abs_sat_le (zSat_nonneg P) _⟩
  simp only [rowAddRef]
  split_ifs
  · exact hr.abs_X_le
  · exact abs_sat_le (zSat_nonneg P) _

theorem rowOK_rowScaleRef {P : StreamParams} {r : Row} (hr : RowOK P r) (a b both : ℤ) :
    RowOK P (rowScaleRef P a b both r) := by
  refine ⟨hr.seed_length, hr.seed_lt, ?_, abs_sat_le (zSat_nonneg P) _⟩
  simp only [rowScaleRef]
  split_ifs
  · exact hr.abs_X_le
  · exact abs_sat_le (zSat_nonneg P) _

theorem bankOK_mapRows {P : StreamParams} {ok : AdaState → Prop} {B : Bank} (hB : BankOK P ok B)
    {f : Row → Row} (hf : ∀ r, RowOK P r → RowOK P (f r)) : BankOK P ok (B.mapRows f) where
  ada_sizes := by
    rw [← hB.ada_sizes]
    simp [Bank.mapRows, List.map_map, Function.comp_def]
  coarse_length_le := by simpa [Bank.mapRows] using hB.coarse_length_le
  coarse_shape := by
    intro grp hgrp
    simp only [Bank.mapRows, List.mem_map] at hgrp
    obtain ⟨g, hg, rfl⟩ := hgrp
    obtain ⟨h1, h2⟩ := hB.coarse_shape g hg
    refine ⟨by simp [h1], ?_⟩
    intro sub hsub
    simp only [List.mem_map] at hsub
    obtain ⟨s, hs, rfl⟩ := hsub
    simp [h2 s hs]
  ada_rows := by
    intro blk hblk r hr
    simp only [Bank.mapRows, List.mem_map] at hblk
    obtain ⟨b, hb, rfl⟩ := hblk
    simp only [List.mem_map] at hr
    obtain ⟨r0, hr0, rfl⟩ := hr
    exact hf r0 (hB.ada_rows b hb r0 hr0)
  coarse_rows := by
    intro grp hgrp sub hsub r hr
    simp only [Bank.mapRows, List.mem_map] at hgrp
    obtain ⟨g, hg, rfl⟩ := hgrp
    simp only [List.mem_map] at hsub
    obtain ⟨s, hs, rfl⟩ := hsub
    simp only [List.mem_map] at hr
    obtain ⟨r0, hr0, rfl⟩ := hr
    exact hf r0 (hB.coarse_rows g hg s hs r0 hr0)
  ada_ok := hB.ada_ok

theorem bank_size_le (R : AdaRep) (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P) {B : Bank}
    (hB : BankOK P (R.ok P) B) : valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) :=
  BankOK.valSize_encBank_le (hR.enc_le P hP) hB

theorem Mv_ge (R : AdaRep) (P : StreamParams) :
    2 ^ 31 * bankSizeBound P (R.bound P) + 2 ^ 36 * P.calL ^ 3 ≤ Mv R P := by
  have h1 := W2.calL_cube_le_Mv R P
  have h2 : 2 ^ 32 * (bankSizeBound P (R.bound P) + 1) ≤ Mv R P := by
    unfold Mv stateSizeBound
    have hH := P.one_le_H
    have h3 : bankSizeBound P (R.bound P) + 1 ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
      Nat.le_mul_of_pos_left _ (by omega)
    exact Nat.mul_le_mul_left _ (by omega)
  omega

theorem bitLen_two_pow (k : ℕ) : bitLen ((2 : ℤ) ^ k) = k + 1 := by
  have h : ((2 : ℤ) ^ k) = ((2 ^ k : ℕ) : ℤ) := by push_cast; ring
  rw [h, bitLen_natCast, Nat.size_pow]

theorem bitLen_zSat_le (P : StreamParams) : bitLen (zSat P) ≤ 22 * P.calL ^ 3 + 2 := by
  unfold zSat
  have h1 := bitLen_mul_le' (P.Zmax : ℤ) ((2 : ℤ) ^ P.eHb)
  have h2 : bitLen (P.Zmax : ℤ) = P.eZmax + 1 := by
    rw [bitLen_natCast]; unfold StreamParams.Zmax; exact Nat.size_pow
  rw [bitLen_two_pow] at h1
  have := eZmax_le P
  have := eHb_le P
  omega

theorem bitLen_natCast_le_of_le {n k : ℕ} (h : n ≤ k) : bitLen (n : ℤ) ≤ k :=
  (bitLen_mono_nat h).trans (bitLen_natCast_le k)

/-! ## Reference equalities of the row operations -/

theorem addPhys_eq (P : StreamParams) (i : ℕ) (Δ : ℤ) :
    Row.addPhys P i Δ = rowAddRef P i (Δ * 2 ^ P.eHb) 1 1 := by
  funext r
  simp only [Row.addPhys, rowAddRef, one_ne_zero, if_false, rdivZ_one]
  rw [mul_right_comm Δ]

theorem guardIncr_eq (P : StreamParams) (r : Row) (g : ℕ) (δ : ℤ) :
    guardIncr P r g δ = rdivZ (δ * 2 ^ P.eHb * rowSign P r g) (2 ^ P.eHg) := by
  rw [rdivZ_eq_roundMant _ _ (by positivity)]
  unfold guardIncr roundMant gridVal
  congr 1
  push_cast
  ring

theorem addGuardY_eq (P : StreamParams) (g : ℕ) (δ : ℤ) :
    Row.addGuardY P g δ = rowAddRef P g (δ * 2 ^ P.eHb) (2 ^ P.eHg) 0 := by
  funext r
  simp only [Row.addGuardY, rowAddRef, if_true, guardIncr_eq]

theorem addGuardXY_eq (P : StreamParams) (g : ℕ) (δ : ℤ) :
    Row.addGuardXY P g δ = rowAddRef P g (δ * 2 ^ P.eHb) (2 ^ P.eHg) 1 := by
  funext r
  simp only [Row.addGuardXY, rowAddRef, one_ne_zero, if_false, guardIncr_eq]

theorem scaleMant_eq (qs : ℕ) (cInt m : ℤ) : scaleMant qs cInt m = rdivZ (cInt * m) (2 ^ qs) := by
  rw [rdivZ_eq_roundMant _ _ (by positivity)]
  unfold scaleMant
  push_cast
  rfl

theorem scaleY_eq (P : StreamParams) (cInt : ℤ) :
    Row.scaleY P cInt = rowScaleRef P cInt (2 ^ P.eHstep) 0 := by
  funext r
  simp only [Row.scaleY, rowScaleRef, if_true, scaleMant_eq]

theorem scaleXY_eq (P : StreamParams) (cInt : ℤ) :
    Row.scaleXY P cInt = rowScaleRef P cInt (2 ^ P.eHstep) 1 := by
  funext r
  simp only [Row.scaleXY, rowScaleRef, one_ne_zero, if_false, scaleMant_eq]

theorem bitLen_le_regBits_succ {P : StreamParams} {δ : ℤ} (hδ : |δ| ≤ 2 ^ regBits P) :
    bitLen δ ≤ regBits P + 1 := by
  apply bitLen_le_of_abs_lt
  have : (2 : ℤ) ^ regBits P < 2 ^ (regBits P + 1) := pow_lt_pow_right₀ (by norm_num) (by omega)
  linarith

/-! ## The six entries (750–755) -/

section entries

variable {prog : List Expr} {M : ℕ}

/-- The common part of 751–753: `[encP, encBank B, coord, d] ↦ encBank (B.mapRows (rowAddRef P
coord (d 2^{eHb}) bv bothv))`, `bv`/`bothv` given by the expressions `eB`/`eBoth`. -/
theorem addBank_core (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (hw2 : HornerLib prog) (P : StreamParams) (B : Bank) (coord : ℕ) (d bv bothv : ℤ)
    (eB eBoth : Expr) (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hc1 : 1 ≤ coord)
    (hc : coord ≤ P.Dstar) (hbv : 0 < bv) (hM : Mv R P ≤ M)
    (hd : bitLen d ≤ 2 ^ 8 * P.calL ^ 3) (hbvK : bitLen bv ≤ P.calL ^ 3) (hbo : bitLen bothv ≤ 1)
    (heB : EvalsVal prog M [encStreamParams P,
      Val.list [encStreamParams P, encBank R.enc B, encN coord, encZ d]] [] (.inl eB) (Val.int bv))
    (heBoth : EvalsVal prog M [encStreamParams P,
      Val.list [encStreamParams P, encBank R.enc B, encN coord, encZ d]] [] (.inl eBoth)
      (Val.int bothv)) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN coord, encZ d]] []
      (.inl (eLet (eHd (eV 0)) (eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
        (eList [eLit 1, eZsat (eV 0), eCall Idx.pw (eV 0), eCall Idx.pIrrW (eV 0), eAt2 (eV 1),
          eMul (eAt3 (eV 1)) (ePow2 (eCall Idx.peHb (eV 0))), eB, eBoth])))))
      (encBank R.enc (B.mapRows (rowAddRef P coord (d * 2 ^ P.eHb) bv bothv))) := by
  have hB' : BankOK P (R.ok P) (B.mapRows (rowAddRef P coord (d * 2 ^ P.eHb) bv bothv)) :=
    bankOK_mapRows hB (fun r hr => rowOK_rowAddRef hr coord (d * 2 ^ P.eHb) bv bothv)
  have hs1 := bank_size_le R hR hP hB
  have hs2 := bank_size_le R hR hP hB'
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hc100 := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hZ := bitLen_zSat_le P
  have hZ' : bitLen ((P.Zmax : ℤ) * 2 ^ P.eHb) ≤ 22 * P.calL ^ 3 + 2 := hZ
  have hw := w_le P
  have hwb : bitLen (P.w : ℤ) ≤ 3 * P.calL + 1 := bitLen_natCast_le_of_le hw
  obtain ⟨-, hirr, -⟩ := isIrrPoly_irrW P (W2.one_le_Dstar P)
  have hirrb : bitLen (irrW P : ℤ) ≤ 3 * P.calL + 2 :=
    (bitLen_nat_le_of_lt hirr).trans (by omega)
  have hcb : bitLen (coord : ℤ) ≤ 3 * P.calL + 1 := by
    have h1 := Dstar_le P
    have h2 : coord < 2 ^ (3 * P.calL + 1) := by
      calc coord ≤ 2 ^ (3 * P.calL) := hc.trans h1
        _ < 2 ^ (3 * P.calL + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)
    exact bitLen_nat_le_of_lt h2
  have hHb := eHb_le P
  have hpow : Cost.S_pow2 P.eHb ≤ M := by
    have := size_le_self P.eHb
    simp only [Cost.S_pow2]
    omega
  have hdH : bitLen (d * 2 ^ P.eHb) ≤ 2 ^ 8 * P.calL ^ 3 + 18 * P.calL ^ 3 + 1 := by
    have := bitLen_mul_le' d ((2 : ℤ) ^ P.eHb)
    rw [bitLen_two_pow] at this
    omega
  have hex : valSize (exVal 1 (zSat P) P.w (irrW P) coord (d * 2 ^ P.eHb) bv bothv) ≤
      2 ^ 9 * P.calL ^ 3 := by
    simp only [exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]
    omega
  have hI : valSize (Val.list [encStreamParams P, encBank R.enc B, encN coord, encZ d]) ≤ M := by
    simp only [encN, encZ, valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hZs : EvalsVal prog M [encStreamParams P,
      Val.list [encStreamParams P, encBank R.enc B, encN coord, encZ d]] []
      (.inl (eZsat (eV 0))) (Val.int (zSat P)) :=
    ev_mul (ev_param hw1.pZmax P hP hM (ev_var rfl))
      (ev_pow2 hlib (ev_param hw1.peHb P hP hM (ev_var rfl)) hpow)
      (by simp only [valSize_int]; omega)
  refine ev_let (ev_hd (ev_var rfl) hI) ?_
  refine ev_call hlib.bkBankMap (ev_pair (ev_at1 (ev_var rfl) hI)
    (ev_list (.cons (ev_lit (by simp; omega)) (.cons hZs
      (.cons (ev_param hw1.pw P hP hM (ev_var rfl)) (.cons (ev_param hw1.pIrrW P hP hM (ev_var rfl))
      (.cons (ev_at2 (ev_var rfl) hI) (.cons (ev_mul (ev_at3 (ev_var rfl) hI)
        (ev_pow2 hlib (ev_param hw1.peHb P hP hM (ev_var rfl)) hpow)
        (by simp only [encZ, valSize_int]; omega))
      (.cons heB (.cons heBoth .nil))))))))
      (by simp only [exVal, encN, valSize_list, valSize_int, listSize_cons, listSize_nil,
        bitLen_one] at hex ⊢; omega))
    (by simp only [exVal, encN, valSize_list, valSize_int, listSize_cons, listSize_nil,
        bitLen_one] at hex ⊢; omega)) ?_
  exact bkBankMap_val hlib (rowAddRef P coord (d * 2 ^ P.eHb) bv bothv) (RowOK P)
    (exVal 1 (zSat P) P.w (irrW P) coord (d * 2 ^ P.eHb) bv bothv)
    R.enc B (fun r hr => bkRowOp_add_val hlib hw2 P hP r hr coord hc1 hc _ _ _ hbv
      (K := 2 ^ 9 * P.calL ^ 3) (by have := hr.valSize_encRow_le; omega) hex (by omega))
    hB.ada_rows hB.coarse_rows (by omega)

/-- 751 (`W5Contract.addPhysBank`). -/
theorem addPhysBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (hw2 : HornerLib prog) (P : StreamParams) (B : Bank) (i : ℕ)
    (Δ : ℤ) (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hi1 : 1 ≤ i) (hin : i ≤ P.n)
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN i, encZ Δ]] []
      (.inl body_addPhysBank) (encBank R.enc (B.mapRows (Row.addPhys P i Δ))) := by
  rw [addPhys_eq]
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hΔb : bitLen Δ ≤ P.calL := by
    apply bitLen_le_of_abs_lt
    have h1 := W2.two_U_lt_two_pow_calL P
    have h2 : ((2 * P.U : ℕ) : ℤ) < ((2 ^ P.calL : ℕ) : ℤ) := by exact_mod_cast h1
    push_cast at h2
    linarith
  have hMv := Mv_ge R P
  exact addBank_core R hR hlib hw1 hw2 P B i Δ 1 1 (eLit 1) (eLit 1) hP hB hi1
    (hin.trans (by unfold StreamParams.Dstar; omega)) one_pos hM (by omega)
    (by simp; have := hundred_le_calL P; nlinarith) (by simp)
    (ev_lit (by simp; omega)) (ev_lit (by simp; omega))

/-- 752 (`W5Contract.addGuardYBank`). -/
theorem addGuardYBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (hw2 : HornerLib prog) (P : StreamParams) (B : Bank) (g : ℕ)
    (δ : ℤ) (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hg1 : 1 ≤ g) (hgD : g ≤ P.Dstar)
    (hδ : |δ| ≤ 2 ^ regBits P) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]] []
      (.inl body_addGuardYBank) (encBank R.enc (B.mapRows (Row.addGuardY P g δ))) := by
  rw [addGuardY_eq]
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hc100 := hundred_le_calL P
  have hδb := bitLen_le_regBits_succ hδ
  have hHg := eHg_le P
  have hMv := Mv_ge R P
  have hpowg : Cost.S_pow2 P.eHg ≤ M := by
    have := size_le_self P.eHg
    simp only [Cost.S_pow2]
    omega
  exact addBank_core R hR hlib hw1 hw2 P B g δ (2 ^ P.eHg) 0 (ePow2 (eCall Idx.peHg (eV 0)))
    (eLit 0) hP hB hg1 hgD (by positivity) hM (by unfold regBits at hδb; omega)
    (by rw [bitLen_two_pow]; omega) (by simp)
    (ev_pow2 hlib (ev_param hw1.peHg P hP hM (ev_var rfl)) hpowg) (ev_lit (by simp; omega))

/-- 753 (`W5Contract.addGuardXYBank`). -/
theorem addGuardXYBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (hw2 : HornerLib prog) (P : StreamParams) (B : Bank) (g : ℕ)
    (δ : ℤ) (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hg1 : 1 ≤ g) (hgD : g ≤ P.Dstar)
    (hδ : |δ| ≤ 2 ^ regBits P) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]] []
      (.inl body_addGuardXYBank) (encBank R.enc (B.mapRows (Row.addGuardXY P g δ))) := by
  rw [addGuardXY_eq]
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hc100 := hundred_le_calL P
  have hδb := bitLen_le_regBits_succ hδ
  have hHg := eHg_le P
  have hMv := Mv_ge R P
  have hpowg : Cost.S_pow2 P.eHg ≤ M := by
    have := size_le_self P.eHg
    simp only [Cost.S_pow2]
    omega
  exact addBank_core R hR hlib hw1 hw2 P B g δ (2 ^ P.eHg) 1 (ePow2 (eCall Idx.peHg (eV 0)))
    (eLit 1) hP hB hg1 hgD (by positivity) hM (by unfold regBits at hδb; omega)
    (by rw [bitLen_two_pow]; omega) (by simp)
    (ev_pow2 hlib (ev_param hw1.peHg P hP hM (ev_var rfl)) hpowg) (ev_lit (by simp; omega))

/-- The common part of 754–755. -/
theorem scaleBank_core (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (P : StreamParams) (B : Bank) (cInt bothv : ℤ) (eBoth : Expr)
    (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1))
    (hM : Mv R P ≤ M) (hbo : bitLen bothv ≤ 1)
    (heBoth : EvalsVal prog M [encStreamParams P,
      Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] [] (.inl eBoth) (Val.int bothv)) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] []
      (.inl (eLet (eHd (eV 0)) (eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
        (eList [eLit 2, eZsat (eV 0), eLit 0, eLit 0, eLit 0, eAt2 (eV 1),
          ePow2 (eCall Idx.peHstep (eV 0)), eBoth])))))
      (encBank R.enc (B.mapRows (rowScaleRef P cInt (2 ^ P.eHstep) bothv))) := by
  have hB' : BankOK P (R.ok P) (B.mapRows (rowScaleRef P cInt (2 ^ P.eHstep) bothv)) :=
    bankOK_mapRows hB (fun r hr => rowOK_rowScaleRef hr cInt (2 ^ P.eHstep) bothv)
  have hs1 := bank_size_le R hR hP hB
  have hs2 := bank_size_le R hR hP hB'
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hc100 := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hZ := bitLen_zSat_le P
  have hZ' : bitLen ((P.Zmax : ℤ) * 2 ^ P.eHb) ≤ 22 * P.calL ^ 3 + 2 := hZ
  have hHb := eHb_le P
  have hHs := eHstep_le P
  have hpow : Cost.S_pow2 P.eHb ≤ M := by
    have := size_le_self P.eHb
    simp only [Cost.S_pow2]
    omega
  have hpows : Cost.S_pow2 P.eHstep ≤ M := by
    have := size_le_self P.eHstep
    simp only [Cost.S_pow2]
    omega
  have hcb : bitLen cInt ≤ P.eHstep + 2 := by
    apply bitLen_le_of_abs_lt
    have : (2 : ℤ) ^ (P.eHstep + 1) < 2 ^ (P.eHstep + 2) :=
      pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith
  have hsb := bitLen_two_pow P.eHstep
  have hex : valSize (exVal 2 (zSat P) 0 0 0 cInt (2 ^ P.eHstep) bothv) ≤ 2 ^ 9 * P.calL ^ 3 := by
    simp only [exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero, bitLen_two_eq]
    omega
  have hI : valSize (Val.list [encStreamParams P, encBank R.enc B, encZ cInt]) ≤ M := by
    simp only [encZ, valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hZs : EvalsVal prog M [encStreamParams P,
      Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] []
      (.inl (eZsat (eV 0))) (Val.int (zSat P)) :=
    ev_mul (ev_param hw1.pZmax P hP hM (ev_var rfl))
      (ev_pow2 hlib (ev_param hw1.peHb P hP hM (ev_var rfl)) hpow)
      (by simp only [valSize_int]; omega)
  refine ev_let (ev_hd (ev_var rfl) hI) ?_
  refine ev_call hlib.bkBankMap (ev_pair (ev_at1 (ev_var rfl) hI)
    (ev_list (.cons (ev_lit (by simp [bitLen_two_eq]; omega)) (.cons hZs
      (.cons (ev_lit (by simp; omega)) (.cons (ev_lit (by simp; omega))
      (.cons (ev_lit (by simp; omega)) (.cons (ev_at2 (ev_var rfl) hI)
      (.cons (ev_pow2 hlib (ev_param hw1.peHstep P hP hM (ev_var rfl)) hpows)
      (.cons heBoth .nil))))))))
      (by simp only [exVal, encZ, valSize_list, valSize_int, listSize_cons, listSize_nil,
        bitLen_zero, bitLen_two_eq] at hex ⊢; omega))
    (by simp only [exVal, encZ, valSize_list, valSize_int, listSize_cons, listSize_nil,
        bitLen_zero, bitLen_two_eq] at hex ⊢; omega)) ?_
  exact bkBankMap_val hlib (rowScaleRef P cInt (2 ^ P.eHstep) bothv) (RowOK P)
    (exVal 2 (zSat P) 0 0 0 cInt (2 ^ P.eHstep) bothv)
    R.enc B (fun r hr => bkRowOp_scale_val hlib P r _ _ _ (by positivity)
      (K := 2 ^ 9 * P.calL ^ 3) (by have := hr.valSize_encRow_le; omega) hex (by omega))
    hB.ada_rows hB.coarse_rows (by omega)

/-- 754 (`W5Contract.scaleYBank`). -/
theorem scaleYBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (P : StreamParams) (B : Bank) (cInt : ℤ) (hP : ParamsOK P)
    (hB : BankOK P (R.ok P) B) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] []
      (.inl body_scaleYBank) (encBank R.enc (B.mapRows (Row.scaleY P cInt))) := by
  rw [scaleY_eq]
  have hMv := Mv_ge R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  exact scaleBank_core R hR hlib hw1 P B cInt 0 (eLit 0) hP hB hc hM (by simp)
    (ev_lit (by simp; omega))

/-- 755 (`W5Contract.scaleXYBank`). -/
theorem scaleXYBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (P : StreamParams) (B : Bank) (cInt : ℤ) (hP : ParamsOK P)
    (hB : BankOK P (R.ok P) B) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1)) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B, encZ cInt]] []
      (.inl body_scaleXYBank) (encBank R.enc (B.mapRows (Row.scaleXY P cInt))) := by
  rw [scaleXY_eq]
  have hMv := Mv_ge R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  exact scaleBank_core R hR hlib hw1 P B cInt 1 (eLit 1) hP hB hc hM (by simp)
    (ev_lit (by simp; omega))

/-- 750 (`W5Contract.resetYBank`). -/
theorem resetYBank_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (P : StreamParams)
    (B : Bank) (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hM : Mv R P ≤ M) :
    EvalsVal prog M [Val.list [encStreamParams P, encBank R.enc B]] [] (.inl body_resetYBank)
      (encBank R.enc (B.mapRows Row.resetY)) := by
  have hB' : BankOK P (R.ok P) (B.mapRows Row.resetY) :=
    bankOK_mapRows hB (fun r hr => rowOK_resetY hr)
  have hs1 := bank_size_le R hR hP hB
  have hs2 := bank_size_le R hR hP hB'
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hc100 := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hI : valSize (Val.list [encStreamParams P, encBank R.enc B]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hex : valSize (exVal 0 0 0 0 0 0 1 0) ≤ 30 := by
    simp [exVal, bitLen_zero, bitLen_one]
  unfold body_resetYBank
  refine ev_call hlib.bkBankMap (ev_pair (ev_at1 (ev_var rfl) hI)
    (ev_list (.cons (ev_lit (by simp; omega)) (.cons (ev_lit (by simp; omega))
      (.cons (ev_lit (by simp; omega)) (.cons (ev_lit (by simp; omega))
      (.cons (ev_lit (by simp; omega)) (.cons (ev_lit (by simp; omega))
      (.cons (ev_lit (by simp; omega)) (.cons (ev_lit (by simp; omega)) .nil))))))))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero,
        bitLen_one]; omega))
    (by simp only [exVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero,
        bitLen_one] at hex ⊢; omega)) ?_
  exact bkBankMap_val hlib Row.resetY (RowOK P) (exVal 0 0 0 0 0 0 1 0) R.enc B
    (fun r hr => bkRowOp_reset_val r (K := 2 ^ 6 * P.calL ^ 3) hr.valSize_encRow_le (by omega))
    hB.ada_rows hB.coarse_rows (by omega)

end entries

end F2e2e.C.Impl.BankDSL
