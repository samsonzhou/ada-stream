import F2e2e.C.Impl.AdaPrepCorrParts

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 3: a correction `adaCorr` (Idx 702)

OWNER: B-ARCH (dc387564) from 2026-10-25 09:05Z (contract fixed by B-NUM, b5a655d4; `AdaPrepScan.lean`
calls it). Indices 702 (`adaCorr`, entry), 705 (`adaCorrDet`), 706 (`adaRedraw`) and the library
`linComb` (21/22) are this file's; list them all in `adaCorrTable`.

Reference (`AdaPrepRef.lean`, `AdaValid.lean`): `applyCorrection_toBits`
(`= (redraws).bind (pure ∘ avState A st vals j q)`), `redraw_reopen_toBits` (`thrStepIf`/`thrStep`), and
`avState`, `avScores`, `avRow`, `avRow1`, `avSign` (`AdaValid.lean`).

**Contract (frozen)**: `adaCorr_impl` below. Input `[encN j, Val.int (avSign q), adaEnc st, adaPubEnc A,
encVals vals]`, output `adaEnc` of the corrected state.

Implementation: `body_adaCorr = body_adaCorrMain` (B-NUM, `AdaPrepCorrMain.lean`: call 705 on the
input, call 706 on `[j, st.thrInt, pub]`, then the nine fields of the new state; assembly lemma
`adaCorr_of_parts`), with the parts `body_adaCorrDet` (705, spec `adaCorrDet_val`) and `body_adaRedraw`
(706, spec `adaRedraw_impl`) of `AdaPrepCorrParts.lean`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- `adaCorr` (Idx 702): the assembly `body_adaCorrMain` of `AdaPrepCorrMain.lean`. -/
def body_adaCorr : Expr := body_adaCorrMain

/-- The routines of a correction (`(index, body)`): 702, 705, 706, and the library `linComb` 21/22. -/
def adaCorrTable : List (ℕ × Expr) :=
  [(Idx.adaCorr, body_adaCorr), (Idx.adaCorrDet, body_adaCorrDet), (Idx.adaRedraw, body_adaRedraw),
    (Idx.linComb, body_linComb), (Idx.linCombStep, body_linCombStep)]

/-- **Spec of `adaCorr`** (contract). -/
theorem adaCorr_impl {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaCorrTable, prog[e.1]? = some e.2)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]]
      body_adaCorr adaEnc ((applyCorrection A st vals j q).toBits (adaDraw A)) := by
  have h705 : prog[Idx.adaCorrDet]? = some body_adaCorrDet :=
    hlib (Idx.adaCorrDet, body_adaCorrDet) (by simp [adaCorrTable])
  have h706 : prog[Idx.adaRedraw]? = some body_adaRedraw :=
    hlib (Idx.adaRedraw, body_adaRedraw) (by simp [adaCorrTable])
  have hlc : prog[Idx.linComb]? = some body_linComb :=
    hlib (Idx.linComb, body_linComb) (by simp [adaCorrTable])
  have hlcs : prog[Idx.linCombStep]? = some body_linCombStep :=
    hlib (Idx.linCombStep, body_linCombStep) (by simp [adaCorrTable])
  exact adaCorr_of_parts hbs hT hok hv hj hTj hM h705 h706
    (adaCorrDet_val hL hlc hlcs hbs hT hok hv hj hTj q hM)
    (adaRedraw_impl hS hL hbs hT hj ⟨hok.thr_len, hok.thr_le⟩ hM)

end F2e2e.C.Impl
