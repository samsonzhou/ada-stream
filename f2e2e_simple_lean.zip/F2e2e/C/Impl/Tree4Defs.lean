import F2e2e.C.Impl.W6Lib
import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.MapIdx
import F2e2e.Cost.Lib.GetOpt
import F2e2e.Cost.Lib.Replicate
import F2e2e.Cost.Lib.RevAppend
import F2e2e.Cost.Arith.Basic
import F2e2e.Cost.Assembly

/-!
# W6, Tree4: Step 4 of the round in the DSL — indices, bodies, table, reference splits

Owner: W6-T4 (helper of C-TOP). Mirrors C-ALG's Step 4 (`F2e2e/C/Alg/Round.lean`: `step4`,
`step4Loop`, `step4Depth`, `rejectDepth`, `rejectTail`; `parts/partIII.tex` L495–513).

## Routines (Idx 330–350; the W1/W5 routines are called through `Contracts R prog M`)
| idx | body | input ↦ output |
|---|---|---|
| 330 | `body_step4` | `[p, st] ↦ [st', F]` (`step4`) |
| 331 | `body_step4Fold` (`foldB`) | `[[st, F], ds, p] ↦ [st', F']` (`step4Loop` on `ds`) |
| 332 | `body_step4FoldStep` | loop body of the fold |
| 333 | `body_step4Elem` | `[d, [st, F], p] ↦` one depth unless failed |
| 334 | `body_step4Depth` | `[p, d, st, F] ↦` `step4Depth` |
| 335 | `body_step4Validate` | `[p, d, st, F, B_d, S] ↦` validation and branch (`step4ValidateRef`) |
| 336 | `body_rejectDepth` | `[p, d, pos, st, Q̂] ↦` `rejectDepth` |
| 337 | `body_rejectScale` | `[p, d, pos, Q̂, L_d, st, B₁, N₁] ↦` multiplier, `Y_d · c`, `rejectTail` |
| 338 | `body_rejectTail` | `[p, d, L_d, cInt, N₁, st] ↦` `rejectTail` |
| 339 | `body_rejectRelease` | `[p, d, L_d, N₁, st₁] ↦` DIFF release and counters (`rejectReleaseRef`) |
| 340–342 | `setAtV` (`mapIdx`) | `[l, [k, b]] ↦ setAt b k l` |
| 343–345 | `mfXY` (`mapIdx`) | `[banks, [p, k, cInt]] ↦ mapFrom (mapRows (scaleXY P cInt)) k banks` |
| 346–348 | `mfResc` (`mapIdx`) | `[learners, [p, k, cInt]] ↦ mapFrom (rescale P cInt) k learners` |
| 349–350 | `allFrom` (loop) | `[learners, k, p] ↦ (learners.drop k).all (inRange P)` |

Encodings: C-SPACE's `encState R.enc`, `encBank R.enc`, `encLearner`; rationals `encQ`
(canonical); `p = encStreamParams P`; naturals `encN`; Booleans `encB`.

The reference splits `step4ValidateRef`, `rejectScaleRef`, `rejectReleaseRef` are verbatim
sub-blocks of C-ALG's functions; the equations `step4Depth_some`, `rejectDepth_some`, `rejectTail_eq`
glue them back.
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

namespace Idx

/-- Step 4 (entry). -/
abbrev step4 : ℕ := 330
/-- The fold over the depths `H − 1, …, 0`. -/
abbrev step4Fold : ℕ := 331
/-- Loop body of the fold. -/
abbrev step4FoldStep : ℕ := 332
/-- Step function of the fold. -/
abbrev step4Elem : ℕ := 333
/-- `step4Depth`. -/
abbrev step4Depth : ℕ := 334
/-- Validation of a depth and the branch on the certificate. -/
abbrev step4Validate : ℕ := 335
/-- `rejectDepth`. -/
abbrev rejectDepth : ℕ := 336
/-- The multiplier and the secondary rescaling of the rejection branch. -/
abbrev rejectScale : ℕ := 337
/-- `rejectTail`. -/
abbrev rejectTail : ℕ := 338
/-- The DIFF release and the counters at the end of `rejectTail`. -/
abbrev rejectRelease : ℕ := 339
/-- `setAt` on lists of values. -/
abbrev setAtV : ℕ := 340
/-- Loop body of `setAtV`. -/
abbrev setAtVStep : ℕ := 341
/-- Element routine of `setAtV`. -/
abbrev setAtVElem : ℕ := 342
/-- `mapFrom (Bank.mapRows (Row.scaleXY P cInt))`. -/
abbrev mfXY : ℕ := 343
/-- Loop body of `mfXY`. -/
abbrev mfXYStep : ℕ := 344
/-- Element routine of `mfXY`. -/
abbrev mfXYElem : ℕ := 345
/-- `mapFrom (Learner.rescale P cInt)`. -/
abbrev mfResc : ℕ := 346
/-- Loop body of `mfResc`. -/
abbrev mfRescStep : ℕ := 347
/-- Element routine of `mfResc`. -/
abbrev mfRescElem : ℕ := 348
/-- `(learners.drop k).all (Learner.inRange P)`. -/
abbrev allFrom : ℕ := 349
/-- Loop body of `allFrom`. -/
abbrev allFromStep : ℕ := 350

end Idx

/-! ## Expression builders -/

/-- The encoded state `st` with the failure flag set (`State.fail`). -/
def eFail (st : Expr) : Expr :=
  eList [eGet 0 st, Expr.lit 1, eGet 2 st, eGet 3 st, eGet 4 st, eGet 5 st, eGet 6 st]

/-- `[fail st, encQ 0]`: the output of a failed depth. -/
def eFailOut (st : Expr) : Expr := eList [eFail st, eList [Expr.lit 0, Expr.lit 1]]

/-- The encoded state `st` with its bank list replaced by `bs`. -/
def eWithBanks (st bs : Expr) : Expr :=
  eList [eGet 0 st, eGet 1 st, eGet 2 st, eGet 3 st, eGet 4 st, bs, eGet 6 st]

/-- The encoded state `st` with its learner list replaced by `ls`. -/
def eWithLearners (st ls : Expr) : Expr :=
  eList [eGet 0 st, eGet 1 st, eGet 2 st, eGet 3 st, ls, eGet 5 st, eGet 6 st]

/-- The encoded state `st` with learners, banks and terminal accumulator replaced. -/
def eWithLBA (st ls bs lf : Expr) : Expr :=
  eList [eGet 0 st, eGet 1 st, eGet 2 st, eGet 3 st, ls, bs, lf]

/-- The encoded learner `L` with its cache replaced by `c`. -/
def eWithCache (L c : Expr) : Expr := eList [eGet 0 L, c, eGet 2 L, eGet 3 L, eGet 4 L]

/-- `setAt b k l` (routine `setAtV`). -/
def eSetAt (l k b : Expr) : Expr := Expr.call Idx.setAtV (eList [l, eList [k, b]])

/-- `encQ (a / b)` (W5's `normQ`). -/
def eNormQ (a b : Expr) : Expr := Expr.call F2e2e.C.Impl.Idx.normQ (eList [a, b])

/-- `2 ^ k` (library `pow2`). -/
def ePow2 (k : Expr) : Expr := Expr.call Cost.Idx.pow2 k

/-! ## List routines -/

/-- Element routine of `setAtV`: `[i, x, [k, b]] ↦ if i = k then b else x`. -/
def body_setAtVElem : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 (Expr.var 0)) (eGet 0 (eGet 2 (Expr.var 0))))
    (eGet 1 (eGet 2 (Expr.var 0)))
    (eGet 1 (Expr.var 0))

/-- `setAtV : [l, [k, b]] ↦ setAt b k l`. -/
def body_setAtV : Expr := body_mapIdx Idx.setAtVStep

/-- Element routine of `mfXY`: `[i, B, [p, k, c]] ↦ if i < k then B else scaleXYBank [p, B, c]`. -/
def body_mfXYElem : Expr :=
  Expr.ite (Expr.bin BinOp.lt (eGet 0 (Expr.var 0)) (eGet 1 (eGet 2 (Expr.var 0))))
    (eGet 1 (Expr.var 0))
    (Expr.call F2e2e.C.Impl.Idx.scaleXYBank
      (eList [eGet 0 (eGet 2 (Expr.var 0)), eGet 1 (Expr.var 0), eGet 2 (eGet 2 (Expr.var 0))]))

/-- `mfXY : [banks, [p, k, c]] ↦ mapFrom (Bank.mapRows (Row.scaleXY P c)) k banks`. -/
def body_mfXY : Expr := body_mapIdx Idx.mfXYStep

/-- Element routine of `mfResc`: `[i, L, [p, k, c]] ↦ if i < k then L else rescaleLearner [p, c, L]`. -/
def body_mfRescElem : Expr :=
  Expr.ite (Expr.bin BinOp.lt (eGet 0 (Expr.var 0)) (eGet 1 (eGet 2 (Expr.var 0))))
    (eGet 1 (Expr.var 0))
    (Expr.call F2e2e.C.Impl.Idx.rescaleLearner
      (eList [eGet 0 (eGet 2 (Expr.var 0)), eGet 2 (eGet 2 (Expr.var 0)), eGet 1 (Expr.var 0)]))

/-- `mfResc : [learners, [p, k, c]] ↦ mapFrom (Learner.rescale P c) k learners`. -/
def body_mfResc : Expr := body_mapIdx Idx.mfRescStep

/-- Loop body of `allFrom`. Environment `[acc]`, `acc = [rest, k, p]`: `[] ↦ [0, 1]`; with
`k = 0`: check the head (`learnerInRange`), continue with `[tail, 0, p]` or stop with `[0, 0]`;
with `k ≠ 0`: continue with `[tail, k - 1, p]`. -/
def body_allFromStep : Expr :=
  Expr.letE (eGet 0 (Expr.var 0))                                         -- rest   [rest, acc]
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
      (eList [Expr.lit 0, Expr.lit 1])
      (Expr.letE (eGet 1 (Expr.var 1))                                    -- k      [k, rest, acc]
        (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
          (Expr.letE (Expr.call F2e2e.C.Impl.Idx.learnerInRange
              (eList [eGet 2 (Expr.var 2), Expr.un UnOp.head (Expr.var 1)]))  -- ok [ok, k, rest, acc]
            (Expr.ite (Expr.var 0)
              (eList [Expr.lit 1, eList [Expr.un UnOp.tail (Expr.var 2), Expr.lit 0,
                eGet 2 (Expr.var 3)]])
              (eList [Expr.lit 0, Expr.lit 0])))
          (eList [Expr.lit 1, eList [Expr.un UnOp.tail (Expr.var 1),
            Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1), eGet 2 (Expr.var 2)]]))))

/-- `allFrom : [learners, k, p] ↦ encB ((learners.drop k).all (Learner.inRange P))`. -/
def body_allFrom : Expr := Expr.loop Idx.allFromStep (Expr.var 0)

/-! ## Step 4 -/

/-- `rejectRelease`. Environment `[X]`, `X = [p, d, L_d, N₁, st₁]`; bindings in order:
`p, d, st₁, bo = st₁.banks[d]?, r₂ = release DIFF, st₂, n₂o, eHP, cache, oc, cq, okc`. -/
def body_rejectRelease : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- d
  Expr.letE (eGet 4 (Expr.var 2)) <|                                       -- st₁
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 5 (Expr.var 0), Expr.var 1])) <|   -- bo
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (eFailOut (Expr.var 1)) <|
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.release
    (eList [Expr.var 3, Expr.un UnOp.head (Expr.var 0), Expr.lit 1])) <|   -- r₂
  Expr.letE (eWithBanks (Expr.var 2)
    (eSetAt (eGet 5 (Expr.var 2)) (Expr.var 3) (eGet 1 (Expr.var 0)))) <|  -- st₂
  Expr.letE (eGet 0 (Expr.var 1)) <|                                       -- n₂o
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (eFailOut (Expr.var 1)) <|
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHP (Expr.var 6)) <|              -- eHP
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.roundMantQ
    (eList [Expr.var 0, Expr.un UnOp.head (Expr.var 1)])) <|               -- cache
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.countCorrection
    (eList [Expr.var 8, eGet 2 (Expr.var 9)])) <|                          -- oc
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (eFailOut (Expr.var 4)) <|
  Expr.letE (eNormQ (Expr.var 1) (ePow2 (Expr.var 2))) <|                  -- cq
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.inRangeA (eList [Expr.var 10, Expr.var 0])) <|  -- okc
  Expr.ite (Expr.var 0)
    (eList [eWithLearners (Expr.var 6) (eSetAt (eGet 4 (Expr.var 9)) (Expr.var 10)
        (eWithCache (Expr.un UnOp.head (Expr.var 2)) (Expr.var 3))),
      eGet 3 (Expr.var 12)])
    (eFailOut (Expr.var 6))

/-- `rejectTail`. Environment `[X]`, `X = [p, d, L_d, cInt, N₁, st]`; bindings in order:
`p, d, c, st, d + 1, banks', learners', eHleaf, eHstep, z, leaf', okL, okA`. -/
def body_rejectTail : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- d
  Expr.letE (eGet 3 (Expr.var 2)) <|                                       -- c
  Expr.letE (eGet 5 (Expr.var 3)) <|                                       -- st
  Expr.letE (Expr.bin BinOp.add (Expr.var 2) (Expr.lit 1)) <|             -- d + 1
  Expr.letE (Expr.call Idx.mfXY
    (eList [eGet 5 (Expr.var 1), eList [Expr.var 4, Expr.var 0, Expr.var 2]])) <|   -- banks'
  Expr.letE (Expr.call Idx.mfResc
    (eList [eGet 4 (Expr.var 2), eList [Expr.var 5, Expr.var 1, Expr.var 3]])) <|   -- learners'
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHleaf (Expr.var 6)) <|           -- eHleaf
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHstep (Expr.var 7)) <|           -- eHstep
  Expr.letE (eNormQ
    (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.var 6) (Expr.var 6)) (eGet 6 (Expr.var 5)))
    (ePow2 (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.var 0) (Expr.var 0)) (Expr.var 1)))) <|  -- z
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.roundMantQ (eList [Expr.var 2, Expr.var 0])) <|  -- leaf'
  Expr.letE (Expr.call Idx.allFrom (eList [Expr.var 4, Expr.var 6, Expr.var 10])) <|     -- okL
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.inRangeA
    (eList [Expr.var 11, eNormQ (Expr.var 1) (ePow2 (Expr.var 4))])) <|    -- okA
  Expr.ite (Expr.var 1)
    (Expr.ite (Expr.var 0)
      (Expr.call Idx.rejectRelease (eList [Expr.var 12, Expr.var 11, eGet 2 (Expr.var 13),
        eGet 4 (Expr.var 13), eWithLBA (Expr.var 9) (Expr.var 6) (Expr.var 7) (Expr.var 2)]))
      (eFailOut (eWithBanks (Expr.var 9) (Expr.var 7))))
    (eFailOut (eWithBanks (Expr.var 9) (Expr.var 7)))

/-- `rejectScale`. Environment `[X]`, `X = [p, d, pos, Q̂, L_d, st, B₁, N₁]`; bindings in order:
`p, eEta, eHstep, eHP, P_d (as encQ), cInt, B₁' = scaleYBank B₁`. -/
def body_rejectScale : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peEta (Expr.var 0)) <|             -- eEta
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHstep (Expr.var 1)) <|           -- eHstep
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHP (Expr.var 2)) <|              -- eHP
  Expr.letE (eNormQ (eGet 1 (eGet 4 (Expr.var 4))) (ePow2 (Expr.var 0))) <|     -- P_d
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.stepCoeffMant
    (eList [eGet 2 (Expr.var 5), Expr.var 3, Expr.var 2, Expr.var 0, eGet 3 (Expr.var 5)])) <|  -- cInt
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.scaleYBank
    (eList [Expr.var 5, eGet 6 (Expr.var 6), Expr.var 0])) <|              -- B₁'
  Expr.call Idx.rejectTail (eList [Expr.var 6, eGet 1 (Expr.var 7), eGet 4 (Expr.var 7),
    Expr.var 1, eGet 7 (Expr.var 7),
    eWithBanks (eGet 5 (Expr.var 7))
      (eSetAt (eGet 5 (eGet 5 (Expr.var 7))) (eGet 1 (Expr.var 7)) (Expr.var 0))])

/-- `rejectDepth`. Environment `[X]`, `X = [p, d, pos, st, Q̂]`; bindings in order:
`p, d, st, lo = learners[d]?, bo = banks[d]?, J_*, r₁ = release PRIMARY, n₁o, okN`. -/
def body_rejectDepth : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- d
  Expr.letE (eGet 3 (Expr.var 2)) <|                                       -- st
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 4 (Expr.var 0), Expr.var 1])) <|   -- lo
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 5 (Expr.var 1), Expr.var 2])) <|   -- bo
  Expr.ite (Expr.un UnOp.isNil (Expr.var 1)) (eFailOut (Expr.var 2)) <|
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (eFailOut (Expr.var 2)) <|
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pJstar (Expr.var 4)) <|            -- J_*
  Expr.ite (Expr.bin BinOp.lt (eGet 4 (Expr.un UnOp.head (Expr.var 2))) (Expr.var 0))
    (Expr.ite (Expr.bin BinOp.lt (Expr.lit 0) (eGet 1 (Expr.un UnOp.head (Expr.var 2))))
      (Expr.ite (Expr.bin BinOp.lt (Expr.lit 0) (eGet 0 (eGet 4 (Expr.var 6))))
        (Expr.letE (Expr.call F2e2e.C.Impl.Idx.release
            (eList [Expr.var 5, Expr.un UnOp.head (Expr.var 1), Expr.lit 0])) <|   -- r₁
          Expr.letE (eGet 0 (Expr.var 0)) <|                               -- n₁o
          Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
            (eFailOut (eWithBanks (Expr.var 5)
              (eSetAt (eGet 5 (Expr.var 5)) (Expr.var 6) (eGet 1 (Expr.var 1))))) <|
          Expr.letE (Expr.call F2e2e.C.Impl.Idx.inRangeA
            (eList [Expr.var 7, Expr.un UnOp.head (Expr.var 0)])) <|       -- okN
          Expr.ite (Expr.var 0)
            (Expr.call Idx.rejectScale (eList [Expr.var 8, Expr.var 7, eGet 2 (Expr.var 9),
              eGet 4 (Expr.var 9), Expr.un UnOp.head (Expr.var 5), Expr.var 6,
              eGet 1 (Expr.var 2), Expr.un UnOp.head (Expr.var 1)]))
            (eFailOut (eWithBanks (Expr.var 6)
              (eSetAt (eGet 5 (Expr.var 6)) (Expr.var 7) (eGet 1 (Expr.var 2))))))
        (eFailOut (Expr.var 3)))
      (eFailOut (Expr.var 3)))
    (eFailOut (Expr.var 3))

/-- `step4Validate`. Environment `[X]`, `X = [p, d, st, F, B_d, S]`; bindings in order:
`p, d, H, eEta, θ, res = validate, st₁, cert`. -/
def body_step4Validate : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- d
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pH (Expr.var 1)) <|                -- H
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peEta (Expr.var 2)) <|             -- eEta
  Expr.letE (eNormQ
    (Expr.bin BinOp.add (Expr.bin BinOp.mul (Expr.lit 8)
      (Expr.bin BinOp.sub (Expr.var 1) (Expr.var 2))) (Expr.lit 4))
    (ePow2 (Expr.var 0))) <|                                               -- θ
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.validate
    (eList [Expr.var 4, eGet 4 (Expr.var 5), eGet 5 (Expr.var 5), Expr.var 0])) <|  -- res
  Expr.letE (eWithBanks (eGet 2 (Expr.var 6))
    (eSetAt (eGet 5 (eGet 2 (Expr.var 6))) (Expr.var 4) (eGet 1 (Expr.var 0)))) <|  -- st₁
  Expr.letE (eGet 0 (Expr.var 1)) <|                                       -- cert
  Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
    (eList [Expr.var 1, eGet 5 (Expr.var 8)])
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 1))
      (Expr.call Idx.rejectDepth
        (eList [Expr.var 7, Expr.var 6, Expr.lit 1, Expr.var 1, eGet 3 (Expr.var 8)]))
      (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 2))
        (Expr.call Idx.rejectDepth
          (eList [Expr.var 7, Expr.var 6, Expr.lit 0, Expr.var 1, eGet 3 (Expr.var 8)]))
        (eFailOut (Expr.var 1))))

/-- `step4Depth`. Environment `[X]`, `X = [p, d, st, F]`; bindings in order:
`p, d, st, F, lo = learners[d]?, bo = banks[d]?, eHP, 2^eHP, S, okS`. -/
def body_step4Depth : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- d
  Expr.letE (eGet 2 (Expr.var 2)) <|                                       -- st
  Expr.letE (eGet 3 (Expr.var 3)) <|                                       -- F
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 4 (Expr.var 1), Expr.var 2])) <|   -- lo
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 5 (Expr.var 2), Expr.var 3])) <|   -- bo
  Expr.ite (Expr.un UnOp.isNil (Expr.var 1)) (eFailOut (Expr.var 3)) <|
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) (eFailOut (Expr.var 3)) <|
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHP (Expr.var 5)) <|              -- eHP
  Expr.letE (ePow2 (Expr.var 0)) <|                                        -- 2^eHP
  Expr.letE (eNormQ
    (Expr.bin BinOp.add
      (Expr.bin BinOp.mul (eGet 1 (Expr.un UnOp.head (Expr.var 3))) (eGet 1 (Expr.var 4)))
      (Expr.bin BinOp.mul (eGet 0 (Expr.var 4)) (Expr.var 0)))
    (Expr.bin BinOp.mul (Expr.var 0) (eGet 1 (Expr.var 4)))) <|            -- S
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.inRangeA (eList [Expr.var 8, Expr.var 0])) <|  -- okS
  Expr.ite (Expr.var 0)
    (Expr.call Idx.step4Validate (eList [Expr.var 9, Expr.var 8, Expr.var 7, Expr.var 6,
      Expr.un UnOp.head (Expr.var 4), Expr.var 1]))
    (eFailOut (Expr.var 7))

/-- Step function of the fold. Environment `[[d, [st, F], p]]`: a failed state is returned
unchanged, otherwise `step4Depth [p, d, st, F]`. -/
def body_step4Elem : Expr :=
  Expr.ite (eGet 1 (eGet 0 (eGet 1 (Expr.var 0))))
    (eGet 1 (Expr.var 0))
    (Expr.call Idx.step4Depth (eList [eGet 2 (Expr.var 0), eGet 0 (Expr.var 0),
      eGet 0 (eGet 1 (Expr.var 0)), eGet 1 (eGet 1 (Expr.var 0))]))

/-- The fold over the depths (`foldB`). -/
def body_step4Fold : Expr := body_foldB Idx.step4FoldStep

/-- **Step 4** (entry). Environment `[[p, st]]`; bindings: `p, st, H, ds = [H-1, …, 0], eHleaf,
F₀ = encQ (gridVal eHleaf leaf)`; then the fold from `[[st, F₀], ds, p]`. -/
def body_step4 : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- st
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pH (Expr.var 1)) <|                -- H
  Expr.letE (Expr.call Cost.Idx.reverse (Expr.call Cost.Idx.range (Expr.var 0))) <|  -- ds
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHleaf (Expr.var 3)) <|           -- eHleaf
  Expr.letE (eNormQ (eGet 6 (Expr.var 3)) (ePow2 (Expr.var 0))) <|         -- F₀
  Expr.call Idx.step4Fold (eList [eList [Expr.var 4, Expr.var 0], Expr.var 2, Expr.var 5])

/-! ## The table and the library predicate -/

/-- **Tree4's routine table** (`(index, body)` entries; all indices in `330–350`). -/
def tree4Table : List (ℕ × Expr) :=
  [(Idx.step4, body_step4), (Idx.step4Fold, body_step4Fold),
    (Idx.step4FoldStep, body_foldBStep Idx.step4Elem), (Idx.step4Elem, body_step4Elem),
    (Idx.step4Depth, body_step4Depth), (Idx.step4Validate, body_step4Validate),
    (Idx.rejectDepth, body_rejectDepth), (Idx.rejectScale, body_rejectScale),
    (Idx.rejectTail, body_rejectTail), (Idx.rejectRelease, body_rejectRelease),
    (Idx.setAtV, body_setAtV), (Idx.setAtVStep, body_mapIdxStep Idx.setAtVElem),
    (Idx.setAtVElem, body_setAtVElem),
    (Idx.mfXY, body_mfXY), (Idx.mfXYStep, body_mapIdxStep Idx.mfXYElem),
    (Idx.mfXYElem, body_mfXYElem),
    (Idx.mfResc, body_mfResc), (Idx.mfRescStep, body_mapIdxStep Idx.mfRescElem),
    (Idx.mfRescElem, body_mfRescElem),
    (Idx.allFrom, body_allFrom), (Idx.allFromStep, body_allFromStep)]

/-- The DSL-CALC library routines called by Tree4's bodies. -/
def tree4LibDeps : List (ℕ × Expr) :=
  [(Cost.Idx.getOpt, body_getOpt), (Cost.Idx.getOptStep, body_getOptStep),
    (Cost.Idx.pow2, body_pow2), (Cost.Idx.pow2Step, body_pow2Step),
    (Cost.Idx.range, body_range), (Cost.Idx.rangeStep, body_rangeStep),
    (Cost.Idx.reverse, body_reverse), (Cost.Idx.revAppendStep, body_revAppendStep)]

/-- **Tree4's library predicate**: the program contains Tree4's routines and the library routines
they call (the W1/W5 routines come with `Contracts R prog M`). -/
structure Tree4Lib (prog : List Expr) : Prop where
  step4 : prog[Idx.step4]? = some body_step4
  step4Fold : prog[Idx.step4Fold]? = some body_step4Fold
  step4FoldStep : prog[Idx.step4FoldStep]? = some (body_foldBStep Idx.step4Elem)
  step4Elem : prog[Idx.step4Elem]? = some body_step4Elem
  step4Depth : prog[Idx.step4Depth]? = some body_step4Depth
  step4Validate : prog[Idx.step4Validate]? = some body_step4Validate
  rejectDepth : prog[Idx.rejectDepth]? = some body_rejectDepth
  rejectScale : prog[Idx.rejectScale]? = some body_rejectScale
  rejectTail : prog[Idx.rejectTail]? = some body_rejectTail
  rejectRelease : prog[Idx.rejectRelease]? = some body_rejectRelease
  setAtV : prog[Idx.setAtV]? = some body_setAtV
  setAtVStep : prog[Idx.setAtVStep]? = some (body_mapIdxStep Idx.setAtVElem)
  setAtVElem : prog[Idx.setAtVElem]? = some body_setAtVElem
  mfXY : prog[Idx.mfXY]? = some body_mfXY
  mfXYStep : prog[Idx.mfXYStep]? = some (body_mapIdxStep Idx.mfXYElem)
  mfXYElem : prog[Idx.mfXYElem]? = some body_mfXYElem
  mfResc : prog[Idx.mfResc]? = some body_mfResc
  mfRescStep : prog[Idx.mfRescStep]? = some (body_mapIdxStep Idx.mfRescElem)
  mfRescElem : prog[Idx.mfRescElem]? = some body_mfRescElem
  allFrom : prog[Idx.allFrom]? = some body_allFrom
  allFromStep : prog[Idx.allFromStep]? = some body_allFromStep
  getOpt : prog[Cost.Idx.getOpt]? = some body_getOpt
  getOptStep : prog[Cost.Idx.getOptStep]? = some body_getOptStep
  pow2 : prog[Cost.Idx.pow2]? = some body_pow2
  pow2Step : prog[Cost.Idx.pow2Step]? = some body_pow2Step
  range : prog[Cost.Idx.range]? = some body_range
  rangeStep : prog[Cost.Idx.rangeStep]? = some body_rangeStep
  reverse : prog[Cost.Idx.reverse]? = some body_reverse
  revAppendStep : prog[Cost.Idx.revAppendStep]? = some body_revAppendStep

/-- All indices of Tree4's tables are positive. -/
theorem tree4_indices_pos : ∀ e ∈ tree4Table ++ tree4LibDeps, 0 < e.1 := by
  decide

/-- `Tree4Lib` from the table entries. -/
theorem Tree4Lib.of_entries {prog : List Expr}
    (h : ∀ e ∈ tree4Table ++ tree4LibDeps, prog[e.1]? = some e.2) : Tree4Lib prog := by
  have H : ∀ i b, (i, b) ∈ tree4Table ++ tree4LibDeps → prog[i]? = some b :=
    fun i b hm => h (i, b) hm
  exact
    { step4 := H _ _ (by simp [tree4Table])
      step4Fold := H _ _ (by simp [tree4Table])
      step4FoldStep := H _ _ (by simp [tree4Table])
      step4Elem := H _ _ (by simp [tree4Table])
      step4Depth := H _ _ (by simp [tree4Table])
      step4Validate := H _ _ (by simp [tree4Table])
      rejectDepth := H _ _ (by simp [tree4Table])
      rejectScale := H _ _ (by simp [tree4Table])
      rejectTail := H _ _ (by simp [tree4Table])
      rejectRelease := H _ _ (by simp [tree4Table])
      setAtV := H _ _ (by simp [tree4Table])
      setAtVStep := H _ _ (by simp [tree4Table])
      setAtVElem := H _ _ (by simp [tree4Table])
      mfXY := H _ _ (by simp [tree4Table])
      mfXYStep := H _ _ (by simp [tree4Table])
      mfXYElem := H _ _ (by simp [tree4Table])
      mfResc := H _ _ (by simp [tree4Table])
      mfRescStep := H _ _ (by simp [tree4Table])
      mfRescElem := H _ _ (by simp [tree4Table])
      allFrom := H _ _ (by simp [tree4Table])
      allFromStep := H _ _ (by simp [tree4Table])
      getOpt := H _ _ (by simp [tree4LibDeps])
      getOptStep := H _ _ (by simp [tree4LibDeps])
      pow2 := H _ _ (by simp [tree4LibDeps])
      pow2Step := H _ _ (by simp [tree4LibDeps])
      range := H _ _ (by simp [tree4LibDeps])
      rangeStep := H _ _ (by simp [tree4LibDeps])
      reverse := H _ _ (by simp [tree4LibDeps])
      revAppendStep := H _ _ (by simp [tree4LibDeps]) }

/-- `Tree4Lib` for a program assembled by `mkProg` from a table in which every entry of
`tree4Table ++ tree4LibDeps` is found by `List.lookup` (proved by `rfl`/`decide` on the final
table). -/
theorem Tree4Lib.of_lookup {main : Expr} {tbl : List (ℕ × Expr)}
    (h : ∀ e ∈ tree4Table ++ tree4LibDeps, tbl.lookup e.1 = some e.2) :
    Tree4Lib (mkProg main tbl) :=
  Tree4Lib.of_entries fun e he => mkProg_get_of_lookup (h e he) (tree4_indices_pos e he)

/-! ## Reference splits of C-ALG's Step 4 (verbatim sub-blocks of `F2e2e/C/Alg/Round.lean`) -/

/-- The validation part of `step4Depth` (after the candidate `S` passed its range check). -/
def step4ValidateRef (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) (Bd : Bank) (S : ℚ) :
    BitProg (State × ℚ) := do
  let θ : ℚ := (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta
  let res ← Bd.validate P S θ
  let s1 : State := { s with banks := setAt res.2 d s.banks }
  match res.1 with
  | AdaCert.accept => pure (s1, S)
  | AdaCert.high => rejectDepth P d true F s1
  | AdaCert.low => rejectDepth P d false F s1
  | _ => pure (s1.fail, 0)

/-- The part of `rejectDepth` after `N₁` passed its range check, with the incoming bank `B₁`
returned by the PRIMARY release (stored at index `d` of `s`). -/
def rejectScaleRef (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (Ld : Learner) (s : State)
    (B1 : Bank) (N1 : ℚ) : BitProg (State × ℚ) :=
  let cInt := stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat
  rejectTail P d Ld cInt N1 { s with banks := setAt (B1.mapRows (Row.scaleY P cInt)) d s.banks }

/-- The DIFF release and the counter update at the end of `rejectTail` (after the range checks
of the rescaled values). -/
def rejectReleaseRef (P : StreamParams) (d : ℕ) (Ld : Learner) (N1 : ℚ) (s1 : State) :
    BitProg (State × ℚ) :=
  match s1.banks[d]? with
  | none => pure (s1.fail, 0)
  | some Bd => do
    let r2 ← Bd.release P Mode.diff
    let s2 : State := { s1 with banks := setAt r2.2 d s1.banks }
    match r2.1 with
    | none => pure (s2.fail, 0)
    | some N2 =>
      let cache := roundMant P.eHP N2
      match Learner.countCorrection P { Ld with cache := cache } with
      | none => pure (s2.fail, 0)
      | some Ld' =>
        if inRangeA P (gridVal P.eHP cache) then
          pure ({ s2 with learners := setAt Ld' d s1.learners }, N1)
        else pure (s2.fail, 0)

theorem step4Depth_none (P : StreamParams) (d : ℕ) (s : State) (F : ℚ)
    (h : s.learners[d]? = none ∨ s.banks[d]? = none) : step4Depth P d s F = pure (s.fail, 0) := by
  unfold step4Depth
  rcases h with h | h
  · rw [h]
  · cases s.learners[d]? <;> rw [h]

theorem step4Depth_some (P : StreamParams) (d : ℕ) (s : State) (F : ℚ) {Ld : Learner} {Bd : Bank}
    (hL : s.learners[d]? = some Ld) (hB : s.banks[d]? = some Bd) :
    step4Depth P d s F = if inRangeA P (gridVal P.eHP Ld.cache + F) then
      step4ValidateRef P d s F Bd (gridVal P.eHP Ld.cache + F) else pure (s.fail, 0) := by
  unfold step4Depth
  rw [hL, hB]
  rfl

theorem rejectDepth_none (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State)
    (h : s.learners[d]? = none ∨ s.banks[d]? = none) :
    rejectDepth P d pos Qhat s = pure (s.fail, 0) := by
  unfold rejectDepth
  rcases h with h | h
  · rw [h]
  · cases s.learners[d]? <;> rw [h]

theorem modifyAt_setAt {α : Type} (f : α → α) (b : α) :
    ∀ (k : ℕ) (l : List α), modifyAt f k (setAt b k l) = setAt (f b) k l
  | _, [] => by cases ‹ℕ› <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [setAt, modifyAt, modifyAt_setAt f b k l]

theorem rejectDepth_some (P : StreamParams) (d : ℕ) (pos : Bool) (Qhat : ℚ) (s : State)
    {Ld : Learner} {Bd : Bank} (hL : s.learners[d]? = some Ld) (hB : s.banks[d]? = some Bd) :
    rejectDepth P d pos Qhat s =
      if P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ Qhat ≤ 0 then BitProg.pure (s.fail, 0)
      else (Bd.release P Mode.primary).bind fun r1 =>
        match r1.1 with
        | none => BitProg.pure ({ s with banks := setAt r1.2 d s.banks }.fail, 0)
        | some N1 =>
          if inRangeA P N1 then rejectScaleRef P d pos Qhat Ld s r1.2 N1
          else BitProg.pure ({ s with banks := setAt r1.2 d s.banks }.fail, 0) := by
  unfold rejectDepth
  rw [hL, hB]
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hc
  · rfl
  · congr 1
    funext r1
    rcases r1 with ⟨N1o, B1⟩
    cases N1o with
    | none => rfl
    | some N1 =>
      simp only
      split_ifs with hN
      · simp only [rejectScaleRef, modifyAt_setAt]
      · rfl

theorem rejectTail_eq (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (s : State) :
    rejectTail P d Ld cInt N1 s =
      if ((mapFrom (Learner.rescale P cInt) (d + 1) s.learners).drop (d + 1)).all
          (Learner.inRange P) &&
        inRangeA P (gridVal P.eHleaf
          (roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf))) then
        rejectReleaseRef P d Ld N1 { s with
          banks := mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks,
          learners := mapFrom (Learner.rescale P cInt) (d + 1) s.learners,
          leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf s.leaf) }
      else BitProg.pure ({ s with
        banks := mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks }.fail, 0) := by
  rfl

end F2e2e.C.Impl.T4
