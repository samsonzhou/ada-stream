import F2e2e.C.Impl.AdaFrame

/-!
# ADA module (W4), part 3: size bounds

* the atoms of `adaZ` (`qA_le_adaZ`, `size_fuel_le_adaZ`, …, `sampTerm_le_adaZ`);
* `drawM_le` : the value bound of a draw is `≤ 2^7 (adaZ + 16)`;
* `valSize_adaPubEnc_le` : the parameter record is `≤ adaBoundA`;
* `valSize_adaEnc_le` : an encoded state satisfying `AdaOK` is `≤ adaBoundA`;
* `valSize_encVals_le` : a well-formed query table is `≤ adaBoundA`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The atoms of `adaZ` -/

section Atoms

variable (A : AdaParams)

/-- The summand of `adaZ` for the noise kind `κ`. -/
def sampTerm (κ : NoiseKind) : ℕ :=
  Nat.size (A.scale κ).den + Nat.size (A.scale κ).num.natAbs + Nat.size (A.Ks (A.scale κ)) +
    A.rs (A.scale κ) + Nat.size (A.rho (A.scale κ)).num.toNat + Nat.size (A.rho (A.scale κ)).den +
    Nat.clog 2 (A.rho (A.scale κ)).den

theorem adaZ_eq : adaZ A =
    A.qA + A.p + A.B0 + Nat.size A.fuel + Nat.size (maxKs A) + Nat.size (A.M + A.J + A.R + 2) +
    Nat.size A.N + Nat.size (scoreScale A).den + Nat.size (scoreScale A).num.natAbs +
    Nat.size A.tau.den + Nat.size A.tau.num.natAbs + Nat.size (A.a / 2).den +
    Nat.size (A.a / 2).num.natAbs + Nat.size A.zeta.den + Nat.size A.zeta.num.natAbs +
    (noiseKinds.map (sampTerm A)).sum + 16 := rfl

theorem qA_le_adaZ : A.qA ≤ adaZ A := by rw [adaZ_eq]; omega
theorem p_le_adaZ : A.p ≤ adaZ A := by rw [adaZ_eq]; omega
theorem B0_le_adaZ : A.B0 ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_fuel_le_adaZ : Nat.size A.fuel ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_maxKs_le_adaZ : Nat.size (maxKs A) ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_MJR_le_adaZ : Nat.size (A.M + A.J + A.R + 2) ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_N_le_adaZ : Nat.size A.N ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_cden_le_adaZ : Nat.size (scoreScale A).den ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_cnum_le_adaZ : Nat.size (scoreScale A).num.natAbs ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_tauden_le_adaZ : Nat.size A.tau.den ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_taunum_le_adaZ : Nat.size A.tau.num.natAbs ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_a2den_le_adaZ : Nat.size (A.a / 2).den ≤ adaZ A := by rw [adaZ_eq]; omega
theorem size_a2num_le_adaZ : Nat.size (A.a / 2).num.natAbs ≤ adaZ A := by rw [adaZ_eq]; omega
theorem sixteen_le_adaZ : 16 ≤ adaZ A := by rw [adaZ_eq]; omega
theorem qA_add_size_fuel_le_adaZ : A.qA + Nat.size A.fuel ≤ adaZ A := by rw [adaZ_eq]; omega

theorem sampTerm_le_adaZ (κ : NoiseKind) : sampTerm A κ ≤ adaZ A := by
  have hmem : sampTerm A κ ∈ noiseKinds.map (sampTerm A) :=
    List.mem_map.mpr ⟨κ, by cases κ <;> simp [noiseKinds], rfl⟩
  have := List.le_sum_of_mem hmem
  rw [adaZ_eq]
  omega

theorem Ks_le_maxKs (κ : NoiseKind) : A.Ks (A.scale κ) ≤ maxKs A := by
  unfold maxKs
  cases κ <;> simp [noiseKinds]

theorem size_le_two_pow_le {n k : ℕ} (h : n < 2 ^ k) : Nat.size n ≤ k := Nat.size_le.mpr h

theorem size_succ_le (n : ℕ) : Nat.size (n + 1) ≤ Nat.size n + 1 := by
  rw [Nat.size_le, pow_succ]
  have := Nat.lt_size_self n
  omega

/-- **The value bound of a draw.** -/
theorem drawM_le (κ : NoiseKind) : drawM A κ ≤ 2 ^ 7 * (adaZ A + 16) := by
  have h := sampTerm_le_adaZ A κ
  unfold sampTerm at h
  unfold drawM countM coinM S_readNat
  have h1 := size_le_self (A.rs (A.scale κ))
  have h2 := size_le_self (Nat.clog 2 (A.rho (A.scale κ)).den)
  have h3 := size_succ_le (A.Ks (A.scale κ))
  omega

end Atoms

/-! ## Helpers -/

theorem sum_le_of_getD_le : ∀ (T l : List ℕ), (∀ j, T.getD j 0 ≤ l.getD j 0) → T.sum ≤ l.sum
  | [], _, _ => by simp
  | t :: T, [], h => by
    have h0 := h 0
    have hT : T.sum ≤ ([] : List ℕ).sum := sum_le_of_getD_le T [] (fun j => by
      have := h (j + 1); simpa using this)
    simp at h0 hT ⊢
    omega
  | t :: T, x :: l, h => by
    have h0 := h 0
    have hT := sum_le_of_getD_le T l (fun j => by have := h (j + 1); simpa using this)
    simp at h0 ⊢
    omega

theorem getD_le_sum (l : List ℕ) (j : ℕ) : l.getD j 0 ≤ l.sum := by
  by_cases hj : j < l.length
  · rw [List.getD_eq_getElem _ _ hj]
    exact List.le_sum_of_mem (List.getElem_mem hj)
  · rw [List.getD_eq_default _ _ (by omega)]
    exact Nat.zero_le _

theorem valSize_encQ (x : ℚ) :
    valSize (encQ x) = Nat.size x.num.natAbs + Nat.size x.den + 5 := by
  simp only [encQ, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen,
    Int.natAbs_natCast]
  omega

/-! ## The parameter record -/

/-- **The parameter record is below `adaBoundA`.** -/
theorem valSize_adaPubEnc_le (A : AdaParams) (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) : valSize (adaPubEnc A) ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  -- block sizes
  have hbsV : valSize (encL encN A.blockSizes) ≤ 1 + (A.p + 1) * (adaZ A + 2) := by
    have := valSize_encL_le encN A.blockSizes (adaZ A + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.N := List.le_sum_of_mem hx
      have := Nat.size_le_size hx'
      have := size_N_le_adaZ A
      omega)
    rw [hbs] at this
    exact this
  -- caps
  have hTV : valSize (encL encN A.Tmax) ≤ 1 + A.p * (adaZ A + 2) := by
    have := valSize_encL_le encN A.Tmax (adaZ A + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.fuel := by
        have := List.le_sum_of_mem hx
        unfold AdaParams.fuel
        omega
      have := Nat.size_le_size hx'
      have := size_fuel_le_adaZ A
      omega)
    rw [hT] at this
    exact this
  -- samplers
  have hsampV : valSize (Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))) ≤
      5 * (adaZ A + 20) + 1 := by
    have hκ : ∀ κ, valSize (encL encN (samplerParams A κ)) ≤ adaZ A + 16 := by
      intro κ
      have h := sampTerm_le_adaZ A κ
      unfold sampTerm at h
      have h1 := size_le_self (A.rs (A.scale κ))
      have h2 := size_le_self (Nat.clog 2 (A.rho (A.scale κ)).den)
      simp only [samplerParams, valSize_encL, List.map_cons, List.map_nil, List.sum_cons,
        List.sum_nil, valSize_encN]
      omega
    have h0 := hκ NoiseKind.intThr
    have h1 := hκ NoiseKind.intTest
    have h2 := hκ NoiseKind.outThr
    have h3 := hκ NoiseKind.outTest
    have h4 := hκ NoiseKind.num
    simp only [noiseKinds, List.map_cons, List.map_nil, valSize_list, listSize_cons,
      listSize_nil]
    omega
  have hq1 := valSize_encQ A.tau
  have hq2 := valSize_encQ (A.a / 2)
  have hq3 := valSize_encQ (scoreScale A)
  have := size_tauden_le_adaZ A
  have := size_taunum_le_adaZ A
  have := size_a2den_le_adaZ A
  have := size_a2num_le_adaZ A
  have := size_cden_le_adaZ A
  have := size_cnum_le_adaZ A
  have hp := p_le_adaZ A
  have hqA := qA_le_adaZ A
  have hfuel := size_fuel_le_adaZ A
  have hMJR := size_MJR_le_adaZ A
  have hpsz := size_le_self A.p
  have hqsz := size_le_self A.qA
  have hM' : Nat.size A.M ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hJ' : Nat.size A.J ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hR' : Nat.size A.R ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have h2q : Nat.size (2 ^ A.qA) = A.qA + 1 := Nat.size_pow
  rw [adaPubEnc_eq]
  simp only [pubFields, valSize_list, listSize_cons, listSize_nil, valSize_encN] at *
  unfold adaBoundA
  have hpZ : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

/-! ## The state -/

/-- **An encoded state satisfying the invariant is below `adaBoundA`.** -/
theorem valSize_adaEnc_le {A : AdaParams} {st : AdaState} (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  set B := A.qA + 2 + Nat.size A.fuel with hB
  -- the corrections
  have hTsum : st.T.sum < A.fuel := by
    have := sum_le_of_getD_le st.T A.Tmax (fun j => by
      by_cases hj : j < A.p
      · exact hok.T_le j hj
      · rw [List.getD_eq_default _ _ (by rw [hok.T_len]; omega)]
        exact Nat.zero_le _)
    unfold AdaParams.fuel
    omega
  -- the scores
  have hz : ∀ g ∈ st.scores, ∀ z ∈ g, bitLen z ≤ B := by
    intro g hg z hz
    apply bitLen_le_of_abs_lt
    have h1 := hok.scores_le g hg z hz
    have h2 : (A.fuel : ℤ) < 2 ^ Nat.size A.fuel := by exact_mod_cast Nat.lt_size_self A.fuel
    have h3 : (st.T.sum : ℤ) < A.fuel := by exact_mod_cast hTsum
    have h4 : (0 : ℤ) < 2 ^ A.qA := by positivity
    calc |z| ≤ 4 * 2 ^ A.qA * (st.T.sum : ℤ) := h1
      _ < 4 * 2 ^ A.qA * 2 ^ Nat.size A.fuel := by
          apply mul_lt_mul_of_pos_left (h3.trans h2); positivity
      _ = 2 ^ B := by rw [hB, pow_add, pow_add]; ring
  have hlen : (st.scores.map List.length).sum ≤ A.N := by
    apply sum_le_of_getD_le
    intro j
    by_cases hj : j < A.p
    · rw [List.getD_eq_getElem _ _ (by simp [hok.scores_len]; omega), List.getElem_map]
      have := hok.scores_blk j hj
      rw [List.getD_eq_getElem _ _ (by rw [hok.scores_len]; omega)] at this
      rw [this]
    · rw [List.getD_eq_default _ _ (by simp [hok.scores_len]; omega)]
      exact Nat.zero_le _
  have hscV : valSize (encL (encL encZ) st.scores) ≤ 1 + 2 * A.p + A.N * (B + 2) := by
    rw [valSize_encL]
    have : ∀ g ∈ st.scores, valSize (encL encZ g) + 1 ≤ 2 + g.length * (B + 2) := by
      intro g hg
      have := valSize_encL_le encZ g (B + 1) (fun z hz' => by
        simp only [encZ, valSize_int]; have := hz g hg z hz'; omega)
      rw [show B + 1 + 1 = B + 2 by omega] at this
      omega
    have hsum : (st.scores.map fun g => valSize (encL encZ g) + 1).sum ≤
        (st.scores.map fun g => 2 + g.length * (B + 2)).sum :=
      List.sum_le_sum (fun g hg => this g hg)
    have hsum2 : (st.scores.map fun g => 2 + g.length * (B + 2)).sum =
        2 * st.scores.length + (st.scores.map List.length).sum * (B + 2) := by
      clear hsum this hlen
      induction st.scores with
      | nil => simp
      | cons g gs ih => simp [ih]; ring
    rw [hok.scores_len] at hsum2
    have : (st.scores.map List.length).sum * (B + 2) ≤ A.N * (B + 2) :=
      Nat.mul_le_mul_right _ hlen
    omega
  have hTV : valSize (encL encN st.T) ≤ 1 + A.p * (Nat.size A.fuel + 2) := by
    have := valSize_encL_le encN st.T (Nat.size A.fuel + 1) (fun t ht => by
      rw [valSize_encN]
      have : t ≤ st.T.sum := List.le_sum_of_mem ht
      have := Nat.size_le_size (show t ≤ A.fuel by omega)
      omega)
    rwa [hok.T_len] at this
  have hthrV : valSize (encL encZ st.thrInt) ≤ 1 + A.p * (Nat.size (maxKs A) + 2) := by
    have := valSize_encL_le encZ st.thrInt (Nat.size (maxKs A) + 1) (fun z hz' => by
      simp only [encZ, valSize_int]
      have h1 := hok.thr_le z hz'
      have : bitLen z ≤ Nat.size (maxKs A) := by
        unfold bitLen
        apply Nat.size_le_size
        have : (z.natAbs : ℤ) ≤ (maxKs A : ℤ) := by rw [Int.natCast_natAbs]; exact h1
        exact_mod_cast this
      omega)
    rwa [hok.thr_len] at this
  have hthrO : bitLen st.thrOut ≤ Nat.size (maxKs A) := by
    unfold bitLen
    apply Nat.size_le_size
    have : (st.thrOut.natAbs : ℤ) ≤ (maxKs A : ℤ) := by
      rw [Int.natCast_natAbs]; exact hok.thrOut_le
    exact_mod_cast this
  have hMJR := size_MJR_le_adaZ A
  have hrej : Nat.size st.rej ≤ adaZ A :=
    (Nat.size_le_size (show st.rej ≤ A.M + A.J + A.R + 2 by have := hok.rej_le; omega)).trans hMJR
  have hnI : Nat.size st.nInt ≤ adaZ A :=
    (Nat.size_le_size (show st.nInt ≤ A.M + A.J + A.R + 2 by have := hok.nInt_le; omega)).trans hMJR
  have hnN : Nat.size st.nNum ≤ adaZ A :=
    (Nat.size_le_size (show st.nNum ≤ A.M + A.J + A.R + 2 by have := hok.nNum_le; omega)).trans hMJR
  have hb1 := valSize_encB_le st.halted
  have hb2 := valSize_encB_le st.capAborted
  have hqA := qA_le_adaZ A
  have hfuel := size_fuel_le_adaZ A
  have hmK := size_maxKs_le_adaZ A
  have hqf := qA_add_size_fuel_le_adaZ A
  have hB2 : B + 2 ≤ adaZ A + 16 := by rw [hB]; omega
  unfold adaEnc
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, encZ, valSize_int] at *
  unfold adaBoundA
  have h1 : A.N * (B + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h2 : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h3 : A.p * (Nat.size A.fuel + 2) ≤ A.p * (adaZ A + 2) := Nat.mul_le_mul_left _ (by omega)
  have h4 : A.p * (Nat.size (maxKs A) + 2) ≤ A.p * (adaZ A + 2) :=
    Nat.mul_le_mul_left _ (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

/-! ## Query tables -/

theorem map_bind_cast (l : List ℕ) :
    (List.map (fun v : ℤ => Val.int v) do let a ← l; pure (a : ℤ)) =
      l.map fun n : ℕ => Val.int (n : ℤ) := by
  induction l with
  | nil => rfl
  | cons a l ih => simp_all

/-- `encVals` in `encL` form. -/
theorem encVals_eq (vals : List (List ℕ)) :
    encVals vals = Val.list (vals.map fun blk => encL encN blk) := by
  unfold encVals encL encN
  congr 1
  apply List.map_congr_left
  intro blk _
  rw [map_bind_cast]

theorem encVals_eq_encL (vals : List (List ℕ)) : encVals vals = encL (encL encN) vals :=
  encVals_eq vals

/-- **A query table with the block sizes of `A` and entries `≤ 2^{qA}` is below `adaBoundA`.** -/
theorem valSize_encVals_le {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    {vals : List (List ℕ)} (hlen : vals.map List.length = A.blockSizes)
    (hv : ∀ blk ∈ vals, ∀ v ∈ blk, v ≤ 2 ^ A.qA) : valSize (encVals vals) ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  have hqA := qA_le_adaZ A
  have hent : ∀ blk ∈ vals, valSize (encL encN blk) + 1 ≤ 2 + blk.length * (A.qA + 3) := by
    intro blk hblk
    have := valSize_encL_le encN blk (A.qA + 2) (fun v hv' => by
      rw [valSize_encN]
      have := Nat.size_le_size (hv blk hblk v hv')
      rw [Nat.size_pow] at this
      omega)
    rw [show A.qA + 2 + 1 = A.qA + 3 by omega] at this
    omega
  have hsum : (vals.map fun blk => valSize (encL encN blk) + 1).sum ≤
      (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum :=
    List.sum_le_sum (fun blk hblk => hent blk hblk)
  have hsum2 : (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum =
      2 * vals.length + (vals.map List.length).sum * (A.qA + 3) := by
    clear hsum hent hlen hv
    induction vals with
    | nil => simp
    | cons g gs ih => simp [ih]; ring
  have hvl : vals.length = A.p + 1 := by
    have := congrArg List.length hlen
    simp at this
    omega
  rw [hlen, hvl] at hsum2
  have hN : A.blockSizes.sum = A.N := rfl
  rw [encVals_eq_encL, valSize_encL]
  unfold adaBoundA
  have h1 : A.N * (A.qA + 3) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

/-! ## The tight value bound (O2b, family 1; adopted from B-ACC's `Scratch/O2T/TightDefs.lean`)

* `tightA A = 2 (N + p + 16)(adaZ A + 16)` (`adaBoundA A = 2^9 · tightA A`, `adaBoundA_eq_tightA`);
* `cAddA A = 2^18 (p + adaZ A + 16)`: the N-free additive term of the tight value premise;
* `TightM A M := 2^8 · tightA A + cAddA A ≤ M`, implied by the old premise `2^32 · adaBoundA A ≤ M`
  (`TightM.of_old`), so every `_t` lemma of the module has the old statement as a corollary;
* the tight size lemmas `valSize_adaPubEnc_le_t`, `valSize_adaEnc_le_t`, `valSize_encVals_le_t`.
-/

/-! ## Definitions -/

/-- **The tight value scale** of the ADA module: `2 (N + p + 16)(adaZ A + 16)` (`adaBoundA = 2^9 · tightA`). -/
def tightA (A : AdaParams) : ℕ := 2 * (A.N + A.p + 16) * (adaZ A + 16)

/-- The N-free additive term of the tight value premise: `2^18 (p + adaZ A + 16)`. -/
def cAddA (A : AdaParams) : ℕ := 2 ^ 18 * (A.p + adaZ A + 16)

/-- **The tight value premise**: `2^8 · tightA A + cAddA A ≤ M` (`2^8` of slack: B-ARCH's reading of
`AdaPrepCorrParts`, every value `≤ 4 · bound`, every library call `≤ 64 · (4 · bound)`). -/
def TightM (A : AdaParams) (M : ℕ) : Prop := 2 ^ 8 * tightA A + cAddA A ≤ M

/-! ## Relations -/

theorem adaBoundA_eq_tightA (A : AdaParams) : adaBoundA A = 2 ^ 9 * tightA A := by
  unfold adaBoundA tightA
  ring

/-- `p + adaZ + 16 ≤ (N + p + 16)(adaZ + 16) / 16`, i.e. `32 (p + adaZ A + 16) ≤ tightA A`. -/
theorem thirtytwo_le_tightA (A : AdaParams) : 32 * (A.p + adaZ A + 16) ≤ tightA A := by
  unfold tightA
  have h1 : 16 * (adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := Nat.mul_le_mul_right _ (by omega)
  have h2 : (A.p + 16) * 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) := Nat.mul_le_mul (by omega) (by omega)
  nlinarith

/-- `cAddA A ≤ 2^13 · tightA A`. -/
theorem cAddA_le_tightA (A : AdaParams) : cAddA A ≤ 2 ^ 13 * tightA A := by
  have h := thirtytwo_le_tightA A
  unfold cAddA
  omega

/-- The tight premise follows from the old one: `2^32 · adaBoundA A ≤ M → TightM A M`. -/
theorem TightM.of_old {A : AdaParams} {M : ℕ} (h : 2 ^ 32 * adaBoundA A ≤ M) : TightM A M := by
  have h1 := cAddA_le_tightA A
  have h2 := adaBoundA_eq_tightA A
  unfold TightM
  omega

/-- The fact used for the old statements as corollaries: `2^8 · tightA A + 2^18 (p + adaZ A + 16) ≤ 2^32 · adaBoundA A`. -/
theorem tight_le_old (A : AdaParams) :
    2 ^ 8 * tightA A + 2 ^ 18 * (A.p + adaZ A + 16) ≤ 2 ^ 32 * adaBoundA A := by
  have h1 := cAddA_le_tightA A
  unfold cAddA at h1
  calc 2 ^ 8 * tightA A + 2 ^ 18 * (A.p + adaZ A + 16)
      ≤ 2 ^ 8 * tightA A + 2 ^ 13 * tightA A := Nat.add_le_add_left h1 _
    _ = (2 ^ 8 + 2 ^ 13) * tightA A := by ring
    _ ≤ (2 ^ 32 * 2 ^ 9) * tightA A := Nat.mul_le_mul_right _ (by norm_num)
    _ = 2 ^ 32 * (2 ^ 9 * tightA A) := by ring
    _ = 2 ^ 32 * adaBoundA A := by rw [adaBoundA_eq_tightA]

/-! ## The tight size lemmas -/

/-- **The parameter record is below `tightA`.** -/
theorem valSize_adaPubEnc_le_t (A : AdaParams) (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) : valSize (adaPubEnc A) ≤ tightA A := by
  have hZ16 := sixteen_le_adaZ A
  -- block sizes
  have hbsV : valSize (encL encN A.blockSizes) ≤ 1 + (A.p + 1) * (adaZ A + 2) := by
    have := valSize_encL_le encN A.blockSizes (adaZ A + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.N := List.le_sum_of_mem hx
      have := Nat.size_le_size hx'
      have := size_N_le_adaZ A
      omega)
    rw [hbs] at this
    exact this
  -- caps
  have hTV : valSize (encL encN A.Tmax) ≤ 1 + A.p * (adaZ A + 2) := by
    have := valSize_encL_le encN A.Tmax (adaZ A + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.fuel := by
        have := List.le_sum_of_mem hx
        unfold AdaParams.fuel
        omega
      have := Nat.size_le_size hx'
      have := size_fuel_le_adaZ A
      omega)
    rw [hT] at this
    exact this
  -- samplers
  have hsampV : valSize (Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))) ≤
      5 * (adaZ A + 20) + 1 := by
    have hκ : ∀ κ, valSize (encL encN (samplerParams A κ)) ≤ adaZ A + 16 := by
      intro κ
      have h := sampTerm_le_adaZ A κ
      unfold sampTerm at h
      have h1 := size_le_self (A.rs (A.scale κ))
      have h2 := size_le_self (Nat.clog 2 (A.rho (A.scale κ)).den)
      simp only [samplerParams, valSize_encL, List.map_cons, List.map_nil, List.sum_cons,
        List.sum_nil, valSize_encN]
      omega
    have h0 := hκ NoiseKind.intThr
    have h1 := hκ NoiseKind.intTest
    have h2 := hκ NoiseKind.outThr
    have h3 := hκ NoiseKind.outTest
    have h4 := hκ NoiseKind.num
    simp only [noiseKinds, List.map_cons, List.map_nil, valSize_list, listSize_cons,
      listSize_nil]
    omega
  have hq1 := valSize_encQ A.tau
  have hq2 := valSize_encQ (A.a / 2)
  have hq3 := valSize_encQ (scoreScale A)
  have := size_tauden_le_adaZ A
  have := size_taunum_le_adaZ A
  have := size_a2den_le_adaZ A
  have := size_a2num_le_adaZ A
  have := size_cden_le_adaZ A
  have := size_cnum_le_adaZ A
  have hp := p_le_adaZ A
  have hqA := qA_le_adaZ A
  have hfuel := size_fuel_le_adaZ A
  have hMJR := size_MJR_le_adaZ A
  have hpsz := size_le_self A.p
  have hqsz := size_le_self A.qA
  have hM' : Nat.size A.M ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hJ' : Nat.size A.J ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hR' : Nat.size A.R ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have h2q : Nat.size (2 ^ A.qA) = A.qA + 1 := Nat.size_pow
  rw [adaPubEnc_eq]
  simp only [pubFields, valSize_list, listSize_cons, listSize_nil, valSize_encN] at *
  unfold tightA
  have hpZ : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

/-- **An encoded state satisfying the invariant is below `tightA`.** -/
theorem valSize_adaEnc_le_t {A : AdaParams} {st : AdaState} (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ tightA A := by
  have hZ16 := sixteen_le_adaZ A
  set B := A.qA + 2 + Nat.size A.fuel with hB
  -- the corrections
  have hTsum : st.T.sum < A.fuel := by
    have := sum_le_of_getD_le st.T A.Tmax (fun j => by
      by_cases hj : j < A.p
      · exact hok.T_le j hj
      · rw [List.getD_eq_default _ _ (by rw [hok.T_len]; omega)]
        exact Nat.zero_le _)
    unfold AdaParams.fuel
    omega
  -- the scores
  have hz : ∀ g ∈ st.scores, ∀ z ∈ g, bitLen z ≤ B := by
    intro g hg z hz
    apply bitLen_le_of_abs_lt
    have h1 := hok.scores_le g hg z hz
    have h2 : (A.fuel : ℤ) < 2 ^ Nat.size A.fuel := by exact_mod_cast Nat.lt_size_self A.fuel
    have h3 : (st.T.sum : ℤ) < A.fuel := by exact_mod_cast hTsum
    have h4 : (0 : ℤ) < 2 ^ A.qA := by positivity
    calc |z| ≤ 4 * 2 ^ A.qA * (st.T.sum : ℤ) := h1
      _ < 4 * 2 ^ A.qA * 2 ^ Nat.size A.fuel := by
          apply mul_lt_mul_of_pos_left (h3.trans h2); positivity
      _ = 2 ^ B := by rw [hB, pow_add, pow_add]; ring
  have hlen : (st.scores.map List.length).sum ≤ A.N := by
    apply sum_le_of_getD_le
    intro j
    by_cases hj : j < A.p
    · rw [List.getD_eq_getElem _ _ (by simp [hok.scores_len]; omega), List.getElem_map]
      have := hok.scores_blk j hj
      rw [List.getD_eq_getElem _ _ (by rw [hok.scores_len]; omega)] at this
      rw [this]
    · rw [List.getD_eq_default _ _ (by simp [hok.scores_len]; omega)]
      exact Nat.zero_le _
  have hscV : valSize (encL (encL encZ) st.scores) ≤ 1 + 2 * A.p + A.N * (B + 2) := by
    rw [valSize_encL]
    have : ∀ g ∈ st.scores, valSize (encL encZ g) + 1 ≤ 2 + g.length * (B + 2) := by
      intro g hg
      have := valSize_encL_le encZ g (B + 1) (fun z hz' => by
        simp only [encZ, valSize_int]; have := hz g hg z hz'; omega)
      rw [show B + 1 + 1 = B + 2 by omega] at this
      omega
    have hsum : (st.scores.map fun g => valSize (encL encZ g) + 1).sum ≤
        (st.scores.map fun g => 2 + g.length * (B + 2)).sum :=
      List.sum_le_sum (fun g hg => this g hg)
    have hsum2 : (st.scores.map fun g => 2 + g.length * (B + 2)).sum =
        2 * st.scores.length + (st.scores.map List.length).sum * (B + 2) := by
      clear hsum this hlen
      induction st.scores with
      | nil => simp
      | cons g gs ih => simp [ih]; ring
    rw [hok.scores_len] at hsum2
    have : (st.scores.map List.length).sum * (B + 2) ≤ A.N * (B + 2) :=
      Nat.mul_le_mul_right _ hlen
    omega
  have hTV : valSize (encL encN st.T) ≤ 1 + A.p * (Nat.size A.fuel + 2) := by
    have := valSize_encL_le encN st.T (Nat.size A.fuel + 1) (fun t ht => by
      rw [valSize_encN]
      have : t ≤ st.T.sum := List.le_sum_of_mem ht
      have := Nat.size_le_size (show t ≤ A.fuel by omega)
      omega)
    rwa [hok.T_len] at this
  have hthrV : valSize (encL encZ st.thrInt) ≤ 1 + A.p * (Nat.size (maxKs A) + 2) := by
    have := valSize_encL_le encZ st.thrInt (Nat.size (maxKs A) + 1) (fun z hz' => by
      simp only [encZ, valSize_int]
      have h1 := hok.thr_le z hz'
      have : bitLen z ≤ Nat.size (maxKs A) := by
        unfold bitLen
        apply Nat.size_le_size
        have : (z.natAbs : ℤ) ≤ (maxKs A : ℤ) := by rw [Int.natCast_natAbs]; exact h1
        exact_mod_cast this
      omega)
    rwa [hok.thr_len] at this
  have hthrO : bitLen st.thrOut ≤ Nat.size (maxKs A) := by
    unfold bitLen
    apply Nat.size_le_size
    have : (st.thrOut.natAbs : ℤ) ≤ (maxKs A : ℤ) := by
      rw [Int.natCast_natAbs]; exact hok.thrOut_le
    exact_mod_cast this
  have hMJR := size_MJR_le_adaZ A
  have hrej : Nat.size st.rej ≤ adaZ A :=
    (Nat.size_le_size (show st.rej ≤ A.M + A.J + A.R + 2 by have := hok.rej_le; omega)).trans hMJR
  have hnI : Nat.size st.nInt ≤ adaZ A :=
    (Nat.size_le_size (show st.nInt ≤ A.M + A.J + A.R + 2 by have := hok.nInt_le; omega)).trans hMJR
  have hnN : Nat.size st.nNum ≤ adaZ A :=
    (Nat.size_le_size (show st.nNum ≤ A.M + A.J + A.R + 2 by have := hok.nNum_le; omega)).trans hMJR
  have hb1 := valSize_encB_le st.halted
  have hb2 := valSize_encB_le st.capAborted
  have hqA := qA_le_adaZ A
  have hfuel := size_fuel_le_adaZ A
  have hmK := size_maxKs_le_adaZ A
  have hqf := qA_add_size_fuel_le_adaZ A
  have hB2 : B + 2 ≤ adaZ A + 16 := by rw [hB]; omega
  unfold adaEnc
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, encZ, valSize_int] at *
  unfold tightA
  have h1 : A.N * (B + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h2 : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h3 : A.p * (Nat.size A.fuel + 2) ≤ A.p * (adaZ A + 2) := Nat.mul_le_mul_left _ (by omega)
  have h4 : A.p * (Nat.size (maxKs A) + 2) ≤ A.p * (adaZ A + 2) :=
    Nat.mul_le_mul_left _ (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

/-- **A query table with the block sizes of `A` and entries `≤ 2^{qA}` is below `tightA`.** -/
theorem valSize_encVals_le_t {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    {vals : List (List ℕ)} (hlen : vals.map List.length = A.blockSizes)
    (hv : ∀ blk ∈ vals, ∀ v ∈ blk, v ≤ 2 ^ A.qA) : valSize (encVals vals) ≤ tightA A := by
  have hZ16 := sixteen_le_adaZ A
  have hqA := qA_le_adaZ A
  have hent : ∀ blk ∈ vals, valSize (encL encN blk) + 1 ≤ 2 + blk.length * (A.qA + 3) := by
    intro blk hblk
    have := valSize_encL_le encN blk (A.qA + 2) (fun v hv' => by
      rw [valSize_encN]
      have := Nat.size_le_size (hv blk hblk v hv')
      rw [Nat.size_pow] at this
      omega)
    rw [show A.qA + 2 + 1 = A.qA + 3 by omega] at this
    omega
  have hsum : (vals.map fun blk => valSize (encL encN blk) + 1).sum ≤
      (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum :=
    List.sum_le_sum (fun blk hblk => hent blk hblk)
  have hsum2 : (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum =
      2 * vals.length + (vals.map List.length).sum * (A.qA + 3) := by
    clear hsum hent hlen hv
    induction vals with
    | nil => simp
    | cons g gs ih => simp [ih]; ring
  have hvl : vals.length = A.p + 1 := by
    have := congrArg List.length hlen
    simp at this
    omega
  rw [hlen, hvl] at hsum2
  have hN : A.blockSizes.sum = A.N := rfl
  rw [encVals_eq_encL, valSize_encL]
  unfold tightA
  have h1 : A.N * (A.qA + 3) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have hZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  nlinarith

end F2e2e.C.Impl
