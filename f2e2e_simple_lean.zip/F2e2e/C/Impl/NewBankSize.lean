import F2e2e.C.Impl.SamplerRows
import F2e2e.C.Impl.W6Contracts

/-!
# W3: value bounds of bank creation and of the fingerprint seed

Owner: W3 (4a7299ed). Every value produced by the W3 routines is bounded by `Mv R P`
(`F2e2e/C/Impl/W6Contracts.lean`, `notes/C_IMPL_DESIGN.md` §1): the routines' value-bound premises
(`rowRepM`, `coarseRepM`, `blocksM`, `fpM`, …, `F2e2e/C/Impl/SamplerRows.lean`,
`F2e2e/C/Impl/SamplerFp.lean`) are bounded by small multiples of C-SPACE's bank size bound
`NB = bankSizeBound P (R.bound P)` and of `ℒ = P.calL`, and `2^32 (NB + 2^5 ℒ³) ≤ Mv R P`.

* pure arithmetic: `rowRepM_le`, `coarseRepM_le`, `blocksM_le`, `valSize_encL_encN_le`;
* the parameters: `RB_le` (a fresh row has size `≤ 2^6 ℒ³`, C-SPACE's per-row allowance),
  `nw_le`, `bankRows_ge`, the bank-shape inequalities `blocks_*`, `coarse_*`, `final_le`;
* `Mv_ge`, `calL_le_Mv`.
-/

namespace F2e2e.C.Impl.W3

open F2e2e F2e2e.Cost F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.B

/-! ## Pure arithmetic -/

theorem valSize_nwVal (n w : ℕ) : valSize (nwVal n w) = Nat.size n + Nat.size w + 5 := by
  simp only [nwVal, valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega

theorem valSize_subArg (n w : ℕ) : valSize (subArg n w) = Nat.size 32 + Nat.size n + Nat.size w + 9 := by
  simp only [subArg, nwVal, valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega

theorem valSize_groupArg (g n w : ℕ) :
    valSize (groupArg g n w) = Nat.size g + Nat.size 32 + Nat.size n + Nat.size w + 13 := by
  simp only [groupArg, subArg, nwVal, valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega

theorem valSize_encL_encN_le (l : List ℕ) : valSize (encL encN l) ≤ 1 + 2 * l.length + l.sum := by
  induction l with
  | nil => simp [encL]
  | cons a l ih =>
    have := size_le_self a
    simp only [encL, valSize_list, List.map_cons, listSize_cons, valSize_encN, List.length_cons,
      List.sum_cons] at ih ⊢
    omega

theorem rowRepM_le {k n w Q B : ℕ} (hRB : RB n w ≤ Q) (hk : k * (RB n w + 1) ≤ B)
    (hnw : n + w + 200 ≤ Q) : rowRepM k n w ≤ 50 * Q + 5 * B + k := by
  have e1 : n * (w + 1 + 1) + 7 = RB n w := by unfold RB; ring
  have hsn := size_le_self n
  have hsw := size_le_self w
  have hsk := size_le_self k
  have hnv := valSize_nwVal n w
  have hew := valSize_encN w
  unfold rowRepM repB_M S_readNat
  omega

theorem coarseRepM_le {Rm g n w Q B : ℕ} (hRB : RB n w ≤ Q) (h32 : 32 * (RB n w + 1) ≤ B)
    (hg : g * (SB n w + 1) ≤ B) (hGB : GB g n w ≤ B) (hRm : Rm * (GB g n w + 1) ≤ B)
    (hnw : n + w + 200 ≤ Q) (hgR : g + Rm ≤ B) :
    coarseRepM Rm g n w ≤ 100 * Q + 30 * B := by
  have h1 := rowRepM_le (k := 32) hRB h32 hnw
  have hSB : SB n w ≤ B + 1 := by unfold SB; omega
  have hsg := size_le_self g
  have hsR := size_le_self Rm
  have hs32 : Nat.size 32 ≤ 32 := size_le_self 32
  have hsn := size_le_self n
  have hsw := size_le_self w
  have hsa := valSize_subArg n w
  have hga := valSize_groupArg g n w
  unfold coarseRepM groupRepM repB_M
  omega

theorem blocksM_le {bs : List ℕ} {n w Q B : ℕ} (hBB : BB bs n w ≤ B)
    (hl : 1 + 2 * bs.length + bs.sum ≤ B) (hnw : n + w + 200 ≤ Q) :
    blocksM bs n w ≤ 6 * B + Q := by
  have h1 := valSize_encL_encN_le bs
  have hnv := valSize_nwVal n w
  have hsn := size_le_self n
  have hsw := size_le_self w
  unfold blocksM
  omega

/-! ## The parameters -/

theorem calL_ge_hundred (P : StreamParams) : 100 ≤ P.calL := by
  unfold StreamParams.calL; omega

theorem seedTrials_le_calL (P : StreamParams) : P.seedTrials ≤ P.calL := by
  unfold StreamParams.seedTrials StreamParams.calL; omega

theorem Rmax_pos (P : StreamParams) : 1 ≤ P.Rmax := by
  unfold StreamParams.Rmax; omega

theorem gCoarse_pos (P : StreamParams) : 1 ≤ P.gCoarse := by
  unfold StreamParams.gCoarse; omega

theorem bankRows_ge (P : StreamParams) : 32 ≤ bankRows P := by
  have h1 := Rmax_pos P
  have h2 := gCoarse_pos P
  have h3 : 1 * (1 * 32) ≤ P.Rmax * (P.gCoarse * 32) :=
    Nat.mul_le_mul h1 (Nat.mul_le_mul h2 le_rfl)
  unfold bankRows
  omega

theorem stateSizeBound_ge (P : StreamParams) (a : ℕ) :
    bankSizeBound P a + 2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P a := by
  have hH := StreamParams.one_le_H P
  unfold stateSizeBound
  have h1 : bankSizeBound P a + 1 ≤ P.H * (bankSizeBound P a + 1) := by nlinarith
  omega

theorem Mv_ge (R : AdaRep) (P : StreamParams) :
    2 ^ 32 * (bankSizeBound P (R.bound P) + 2 ^ 5 * P.calL ^ 3) ≤ Mv R P := by
  unfold Mv
  exact Nat.mul_le_mul_left _ (stateSizeBound_ge P (R.bound P))

theorem calL_sq_ge (P : StreamParams) : 100 * P.calL ≤ P.calL ^ 2 := by
  calc 100 * P.calL ≤ P.calL * P.calL := Nat.mul_le_mul_right _ (calL_ge_hundred P)
    _ = P.calL ^ 2 := (sq _).symm

theorem calL_cube_ge (P : StreamParams) : 100 * P.calL ^ 2 ≤ P.calL ^ 3 := by
  calc 100 * P.calL ^ 2 ≤ P.calL * P.calL ^ 2 := Nat.mul_le_mul_right _ (calL_ge_hundred P)
    _ = P.calL ^ 3 := by ring

theorem calL_le_Mv (R : AdaRep) (P : StreamParams) : 2 ^ 20 * P.calL ≤ Mv R P := by
  have h := Mv_ge R P
  have hL := calL_ge_hundred P
  have h3 : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _
  calc 2 ^ 20 * P.calL ≤ 2 ^ 20 * P.calL ^ 3 := Nat.mul_le_mul_left _ h3
    _ ≤ 2 ^ 32 * (bankSizeBound P (R.bound P) + 2 ^ 5 * P.calL ^ 3) := by nlinarith
    _ ≤ Mv R P := h

theorem NB_le_Mv (R : AdaRep) (P : StreamParams) :
    2 ^ 32 * bankSizeBound P (R.bound P) ≤ Mv R P :=
  le_trans (Nat.mul_le_mul_left _ (Nat.le_add_right _ _)) (Mv_ge R P)

/-- A fresh row has size at most C-SPACE's per-row allowance `2^6 ℒ³`. -/
theorem RB_le (P : StreamParams) : RB (2 * P.s) P.w ≤ 2 ^ 6 * P.calL ^ 3 := by
  have hs := F2e2e.C.Space.s_le P
  have hw := F2e2e.C.Space.w_le P
  have hL := calL_ge_hundred P
  unfold RB
  have h1 : 2 * P.s * (P.w + 2) ≤ (6 * P.calL) * (3 * P.calL + 3) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h2 : (6 * P.calL) * (3 * P.calL + 3) + 7 ≤ 2 ^ 6 * P.calL ^ 3 := by
    have e : (6 * P.calL) * (3 * P.calL + 3) = 18 * P.calL ^ 2 + 18 * P.calL := by ring
    have h2 := calL_sq_ge P
    have h3 := calL_cube_ge P
    omega
  omega

theorem nw_le (P : StreamParams) : 2 * P.s + P.w + 200 ≤ 2 ^ 6 * P.calL ^ 3 := by
  have hs := F2e2e.C.Space.s_le P
  have hw := F2e2e.C.Space.w_le P
  have hL := calL_ge_hundred P
  have h2 : 9 * P.calL + 201 ≤ 2 ^ 6 * P.calL ^ 3 := by
    have h2 := calL_sq_ge P
    have h3 := calL_cube_ge P
    omega
  omega

/-- The definition of C-SPACE's bank size bound. -/
theorem NB_eq (P : StreamParams) (a : ℕ) :
    bankSizeBound P a = bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) + 2 * (bankAda P).blockSizes.length +
      4 * P.Rmax * (P.gCoarse + 1) + a + 8 := rfl

section Shape

variable (P : StreamParams) (a : ℕ)

theorem one_add_Q_le_NB : 2 ^ 6 * P.calL ^ 3 + 1 ≤ bankSizeBound P a := by
  have h := bankRows_ge P
  have : 1 * (2 ^ 6 * P.calL ^ 3 + 1) ≤ bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul_right _ (by omega)
  rw [NB_eq]; omega

theorem rows_mul_le_NB {k : ℕ} (hk : k ≤ bankRows P) :
    k * (RB (2 * P.s) P.w + 1) ≤ bankSizeBound P a := by
  have h1 : k * (RB (2 * P.s) P.w + 1) ≤ bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul hk (by have := RB_le P; omega)
  rw [NB_eq]; omega

theorem coarse_g_le_NB : P.gCoarse * (SB (2 * P.s) P.w + 1) ≤ bankSizeBound P a := by
  have hR := Rmax_pos P
  have e : P.gCoarse * (SB (2 * P.s) P.w + 1) =
      2 * P.gCoarse + (P.gCoarse * 32) * (RB (2 * P.s) P.w + 1) := by unfold SB; ring
  have h0 : P.gCoarse * 32 ≤ P.Rmax * (P.gCoarse * 32) := by nlinarith
  have h1 : (P.gCoarse * 32) * (RB (2 * P.s) P.w + 1) ≤
      (P.Rmax * (P.gCoarse * 32)) * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul h0 (by have := RB_le P; omega)
  have h2 : (P.Rmax * (P.gCoarse * 32)) * (2 ^ 6 * P.calL ^ 3 + 1) ≤
      bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) := Nat.mul_le_mul_right _ (coarse_rows_le' P)
  have h3 : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * P.gCoarse) + 4 * P.Rmax := by ring
  have h4 : P.gCoarse ≤ P.Rmax * P.gCoarse := by nlinarith
  rw [NB_eq]; omega
where
  coarse_rows_le' (P : StreamParams) : P.Rmax * (P.gCoarse * 32) ≤ bankRows P := by
    unfold bankRows; omega

theorem coarse_rows_le : P.Rmax * (P.gCoarse * 32) ≤ bankRows P := by
  unfold bankRows; omega

theorem blocks_rows_le : (bankAda P).blockSizes.sum ≤ bankRows P := by
  unfold bankRows; omega

theorem coarse_GB_le_NB : GB P.gCoarse (2 * P.s) P.w ≤ bankSizeBound P a := by
  have hR := Rmax_pos P
  have e : GB P.gCoarse (2 * P.s) P.w =
      1 + 2 * P.gCoarse + (P.gCoarse * 32) * (RB (2 * P.s) P.w + 1) := by unfold GB SB; ring
  have h0 : P.gCoarse * 32 ≤ P.Rmax * (P.gCoarse * 32) := by nlinarith
  have h1 : (P.gCoarse * 32) * (RB (2 * P.s) P.w + 1) ≤
      (P.Rmax * (P.gCoarse * 32)) * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul h0 (by have := RB_le P; omega)
  have h2 : (P.Rmax * (P.gCoarse * 32)) * (2 ^ 6 * P.calL ^ 3 + 1) ≤
      bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) := Nat.mul_le_mul_right _ (coarse_rows_le P)
  have h3 : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * P.gCoarse) + 4 * P.Rmax := by ring
  have h4 : P.gCoarse ≤ P.Rmax * P.gCoarse := by nlinarith
  rw [NB_eq]; omega

theorem coarse_Rm_le_NB :
    P.Rmax * (GB P.gCoarse (2 * P.s) P.w + 1) ≤ bankSizeBound P a := by
  have e : P.Rmax * (GB P.gCoarse (2 * P.s) P.w + 1) =
      2 * P.Rmax + 2 * (P.Rmax * P.gCoarse) +
        (P.Rmax * (P.gCoarse * 32)) * (RB (2 * P.s) P.w + 1) := by unfold GB SB; ring
  have h1 : (P.Rmax * (P.gCoarse * 32)) * (RB (2 * P.s) P.w + 1) ≤
      bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul (coarse_rows_le P) (by have := RB_le P; omega)
  have h3 : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * P.gCoarse) + 4 * P.Rmax := by ring
  rw [NB_eq]; omega

theorem gR_le_NB : P.gCoarse + P.Rmax ≤ bankSizeBound P a := by
  have hR := Rmax_pos P
  have h3 : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * P.gCoarse) + 4 * P.Rmax := by ring
  have h4 : P.gCoarse ≤ P.Rmax * P.gCoarse := by nlinarith
  rw [NB_eq]; omega

theorem blocks_BB_le_NB : BB (bankAda P).blockSizes (2 * P.s) P.w ≤ bankSizeBound P a := by
  have h1 : (bankAda P).blockSizes.sum * (RB (2 * P.s) P.w + 1) ≤
      bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul (blocks_rows_le P) (by have := RB_le P; omega)
  unfold BB
  rw [NB_eq]; omega

theorem blocks_l_le_NB :
    1 + 2 * (bankAda P).blockSizes.length + (bankAda P).blockSizes.sum ≤ bankSizeBound P a := by
  have h1 : (bankAda P).blockSizes.sum * 1 ≤ bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul (blocks_rows_le P) (by omega)
  rw [NB_eq]; omega

/-- The fresh bank fits C-SPACE's bank size bound (blocks, coarse groups and the ADA state). -/
theorem final_le_NB :
    BB (bankAda P).blockSizes (2 * P.s) P.w + CB P.Rmax P.gCoarse (2 * P.s) P.w + a + 4 ≤
      bankSizeBound P a := by
  have eCB : CB P.Rmax P.gCoarse (2 * P.s) P.w = 1 + 2 * P.Rmax + 2 * (P.Rmax * P.gCoarse) +
      (P.Rmax * (P.gCoarse * 32)) * (RB (2 * P.s) P.w + 1) := by unfold CB GB SB; ring
  have e2 : (bankAda P).blockSizes.sum * (RB (2 * P.s) P.w + 1) +
      (P.Rmax * (P.gCoarse * 32)) * (RB (2 * P.s) P.w + 1) =
        bankRows P * (RB (2 * P.s) P.w + 1) := by unfold bankRows; ring
  have h1 : bankRows P * (RB (2 * P.s) P.w + 1) ≤ bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul_left _ (by have := RB_le P; omega)
  have h3 : 4 * P.Rmax * (P.gCoarse + 1) = 4 * (P.Rmax * P.gCoarse) + 4 * P.Rmax := by ring
  unfold BB
  rw [NB_eq]; omega

/-! ### The routines' value bounds -/

theorem rowRepM_le_NB {k : ℕ} (hk : k ≤ bankRows P) :
    rowRepM k (2 * P.s) P.w ≤ 2 ^ 8 * bankSizeBound P a := by
  have h := rowRepM_le (Q := 2 ^ 6 * P.calL ^ 3) (B := bankSizeBound P a) (RB_le P)
    (rows_mul_le_NB P a hk) (nw_le P)
  have hQ := one_add_Q_le_NB P a
  have hBR : bankRows P ≤ bankSizeBound P a := by
    have : bankRows P * 1 ≤ bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) := Nat.mul_le_mul_left _ (by omega)
    rw [NB_eq]; omega
  omega

theorem coarseRepM_le_NB :
    coarseRepM P.Rmax P.gCoarse (2 * P.s) P.w ≤ 2 ^ 8 * bankSizeBound P a := by
  have h := coarseRepM_le (Q := 2 ^ 6 * P.calL ^ 3) (B := bankSizeBound P a) (RB_le P)
    (rows_mul_le_NB P a (bankRows_ge P)) (coarse_g_le_NB P a) (coarse_GB_le_NB P a)
    (coarse_Rm_le_NB P a) (nw_le P) (gR_le_NB P a)
  have hQ := one_add_Q_le_NB P a
  omega

theorem blocksM_le_NB :
    blocksM (bankAda P).blockSizes (2 * P.s) P.w ≤ 2 ^ 8 * bankSizeBound P a := by
  have h := blocksM_le (Q := 2 ^ 6 * P.calL ^ 3) (blocks_BB_le_NB P a) (blocks_l_le_NB P a)
    (nw_le P)
  have hQ := one_add_Q_le_NB P a
  omega

end Shape

end F2e2e.C.Impl.W3
