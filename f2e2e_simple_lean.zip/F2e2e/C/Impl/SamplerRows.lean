import F2e2e.C.Impl.SamplerFp
import F2e2e.C.Alg.Bank

/-!
# W3: row seeds, fresh rows, ADA sample blocks and coarse groups of a new bank (DSL)

Owner: W3 (4a7299ed). References: C-ALG's `F2e2e/C/Alg/Bank.lean` (Algorithm
`R:alg:regularized-norm-bank`, `parts/partIII.tex` L204–207): `sampleList`, `sampleSeed`, `newRow`,
`sampleBlocks`. A row seed is `2s` uniform elements of `𝔽_{2^w}`, i.e. `2s` draws of `w` fresh bits
(big-endian, `uniformBits w`); a fresh row has zero counters.

Generic in the seed length `n` and the field degree `w` (instantiated with `n = 2s`, `w = P.w` in
`F2e2e/C/Impl/NewBank.lean`):

| idx | body | input | output (reference) |
|---|---|---|---|
| 553/554 | `body_seedRep` / step | `[n, w]` | `encL encN` of `replicateB (uniformBits w) n` |
| 555 | `body_rowNew` | `[n, w]` | `rowVal` of `rowProg n w` (`= newRow P`) |
| 556/557 | `body_rowRep` / step | `[k, [n, w]]` | `encL rowVal` of `replicateB (rowProg n w) k` |
| 558/559 | `body_groupRep` / step | `[k, [32, [n, w]]]` | `k` subgroups of `32` rows |
| 560/561 | `body_coarseRep` / step | `[k, [g, [32, [n, w]]]]` | `k` groups of `g` subgroups |
| 562/563 | `body_blocksMap` / step | `[bs, [n, w]]` | `mapB (fun nj => replicateB (rowProg n w) nj) bs` |

All loops are `repB` (`F2e2e/C/Impl/SamplerRep.lean`) or DSL-CALC's `mapB`; `rowVal` is C-SPACE's
`encRow` (`F2e2e/C/SpaceState.lean`; equal by `rfl`, see `NewBank.lean`).
-/

namespace F2e2e.C.Impl.W3

open F2e2e F2e2e.Cost F2e2e.Discrete F2e2e.C.Alg

namespace Idx

/-- `[n, w] ↦` a seed of `n` draws of `w` bits. -/
abbrev seedRep : ℕ := 553
/-- Loop body of `seedRep`. -/
abbrev seedRepStep : ℕ := 554
/-- `[n, w] ↦` a fresh row. -/
abbrev rowNew : ℕ := 555
/-- `[k, [n, w]] ↦` `k` fresh rows. -/
abbrev rowRep : ℕ := 556
/-- Loop body of `rowRep`. -/
abbrev rowRepStep : ℕ := 557
/-- `[k, [32, [n, w]]] ↦` `k` subgroups of `32` fresh rows. -/
abbrev groupRep : ℕ := 558
/-- Loop body of `groupRep`. -/
abbrev groupRepStep : ℕ := 559
/-- `[k, [g, [32, [n, w]]]] ↦` `k` coarse groups. -/
abbrev coarseRep : ℕ := 560
/-- Loop body of `coarseRep`. -/
abbrev coarseRepStep : ℕ := 561
/-- `[bs, [n, w]] ↦` the ADA sample blocks of sizes `bs`. -/
abbrev blocksMap : ℕ := 562
/-- Loop body of `blocksMap`. -/
abbrev blocksMapStep : ℕ := 563

end Idx

/-! ## Reference programs -/

/-- A fresh row whose seed is `n` draws of `w` fresh bits (C-ALG's `newRow P` for `n = 2s`,
`w = P.w`). -/
def rowProg (n w : ℕ) : BitProg Row :=
  (replicateB (uniformBits w) n).bind (fun z => BitProg.pure ⟨z, 0, 0⟩)

/-- C-ALG's `sampleList` is DSL-CALC's `replicateB`. -/
theorem sampleList_eq_replicateB {α : Type} (p : BitProg α) :
    ∀ k, sampleList p k = replicateB p k
  | 0 => rfl
  | k + 1 => by
    show p.bind (fun a => (sampleList p k).bind (fun l => BitProg.pure (a :: l))) = _
    rw [sampleList_eq_replicateB p k]
    rfl

theorem newRow_eq (P : StreamParams) : newRow P = rowProg (2 * P.s) P.w := by
  show (sampleSeed P).bind (fun z => BitProg.pure (⟨z, 0, 0⟩ : Row)) = _
  rw [sampleSeed, sampleList_eq_replicateB]
  rfl

/-- C-ALG's `sampleBlocks` is DSL-CALC's `mapB`. -/
theorem sampleBlocks_eq (P : StreamParams) :
    ∀ l, sampleBlocks P l = mapB (fun nj => replicateB (rowProg (2 * P.s) P.w) nj) l
  | [] => rfl
  | nj :: rest => by
    show (sampleList (newRow P) nj).bind (fun blk =>
      (sampleBlocks P rest).bind (fun l => BitProg.pure (blk :: l))) = _
    rw [sampleBlocks_eq P rest, sampleList_eq_replicateB, newRow_eq]
    rfl

/-! ## Encodings and sizes -/

/-- A row as `[seed, X, Y]` (C-SPACE's `encRow`). -/
def rowVal (r : Row) : Val :=
  Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X, Val.int r.Y]

theorem rowVal_fresh (z : List ℕ) :
    rowVal ⟨z, 0, 0⟩ = Val.list [encL encN z, Val.int 0, Val.int 0] := by
  simp only [rowVal, encInts, encL, List.map_map]
  rfl

/-- Size bound of a fresh row (`n` seed elements of `w` bits). -/
def RB (n w : ℕ) : ℕ := n * (w + 2) + 7

/-- Size bound of a coarse subgroup (`32` fresh rows). -/
def SB (n w : ℕ) : ℕ := 1 + 32 * (RB n w + 1)

/-- Size bound of a coarse group (`g` subgroups). -/
def GB (g n w : ℕ) : ℕ := 1 + g * (SB n w + 1)

/-- Size bound of `R` coarse groups. -/
def CB (R g n w : ℕ) : ℕ := 1 + R * (GB g n w + 1)

/-- Size bound of the ADA sample blocks of sizes `bs`. -/
def BB (bs : List ℕ) (n w : ℕ) : ℕ := 1 + 2 * bs.length + bs.sum * (RB n w + 1)

/-- The parameter pair `[n, w]`. -/
def nwVal (n w : ℕ) : Val := Val.list [encN n, encN w]

theorem uniformBits_run_lt {w : ℕ} {bits : List Bool} {x : ℕ}
    (h : (uniformBits w).run bits = some (x, [])) : x < 2 ^ w := by
  obtain ⟨hlen, rfl⟩ := uniformBits_run_exact h
  rw [← hlen]
  exact natOfBits_lt bits

theorem valSize_encN_le_of_lt {x w : ℕ} (h : x < 2 ^ w) : valSize (encN x) ≤ w + 1 := by
  rw [valSize_encN]
  have := Nat.size_le.mpr h
  omega

/-- Exact runs of `rowProg n w`: a seed of `n` elements `< 2^w`, zero counters. -/
theorem rowProg_run {n w : ℕ} {bits : List Bool} {r : Row}
    (h : (rowProg n w).run bits = some (r, [])) :
    ∃ z : List ℕ, r = ⟨z, 0, 0⟩ ∧ z.length = n ∧ ∀ x ∈ z, x < 2 ^ w := by
  unfold rowProg at h
  obtain ⟨b₁, b₂, z, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
  obtain ⟨hlen, hall⟩ := replicateB_run_forall n b₁ z h1
  refine ⟨z, rfl, hlen, fun x hx => ?_⟩
  obtain ⟨bits', hb⟩ := hall x hx
  exact uniformBits_run_lt hb

theorem valSize_seed_le {n w : ℕ} {z : List ℕ} (hlen : z.length = n) (hz : ∀ x ∈ z, x < 2 ^ w) :
    valSize (encL encN z) ≤ 1 + n * (w + 2) := by
  have := valSize_encL_le encN z (w + 1) (fun x hx => valSize_encN_le_of_lt (hz x hx))
  rw [hlen] at this
  exact this

theorem valSize_rowVal_le {n w : ℕ} {bits : List Bool} {r : Row}
    (h : (rowProg n w).run bits = some (r, [])) : valSize (rowVal r) ≤ RB n w := by
  obtain ⟨z, rfl, hlen, hz⟩ := rowProg_run h
  have hs := valSize_seed_le hlen hz
  rw [rowVal_fresh]
  simp only [RB, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]
  omega

/-- Encoded size of the results of an exact run of `replicateB p k`. -/
theorem valSize_replicateB_le {β : Type} {p : BitProg β} (encB : β → Val) {VB k : ℕ}
    (hVb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ VB) {bits : List Bool}
    {bs : List β} (h : (replicateB p k).run bits = some (bs, [])) :
    valSize (encL encB bs) ≤ 1 + k * (VB + 1) := by
  obtain ⟨hlen, hall⟩ := replicateB_run_forall k bits bs h
  have := valSize_encL_le encB bs VB (fun b hb => by
    obtain ⟨bits', hb'⟩ := hall b hb
    exact hVb bits' b hb')
  rwa [hlen] at this

theorem valSize_rows_le {n w k : ℕ} {bits : List Bool} {rows : List Row}
    (h : (replicateB (rowProg n w) k).run bits = some (rows, [])) :
    valSize (encL rowVal rows) ≤ 1 + k * (RB n w + 1) :=
  valSize_replicateB_le rowVal (fun _ _ hb => valSize_rowVal_le hb) h

theorem valSize_sub_le {n w : ℕ} {bits : List Bool} {sub : List Row}
    (h : (replicateB (rowProg n w) 32).run bits = some (sub, [])) :
    valSize (encL rowVal sub) ≤ SB n w :=
  valSize_rows_le h

theorem valSize_group_le {g n w : ℕ} {bits : List Bool} {grp : List (List Row)}
    (h : (replicateB (replicateB (rowProg n w) 32) g).run bits = some (grp, [])) :
    valSize (encL (encL rowVal) grp) ≤ GB g n w :=
  valSize_replicateB_le (encL rowVal) (fun _ _ hb => valSize_sub_le hb) h

theorem valSize_coarse_le {R g n w : ℕ} {bits : List Bool} {coarse : List (List (List Row))}
    (h : (replicateB (replicateB (replicateB (rowProg n w) 32) g) R).run bits =
      some (coarse, [])) :
    valSize (encL (encL (encL rowVal)) coarse) ≤ CB R g n w :=
  valSize_replicateB_le (encL (encL rowVal)) (fun _ _ hb => valSize_group_le hb) h

/-- Encoded size of the ADA sample blocks of an exact run. -/
theorem valSize_blocks_le {n w : ℕ} :
    ∀ (bs : List ℕ) {bits : List Bool} {ada : List (List Row)},
      (mapB (fun nj => replicateB (rowProg n w) nj) bs).run bits = some (ada, []) →
      valSize (encL (encL rowVal) ada) ≤ BB bs n w := by
  intro bs bits ada h
  have hF := mapB_run_forall₂ bs bits ada h
  clear h
  induction hF with
  | nil => simp [BB, encL]
  | @cons nj blk bs' ada' hrun _ ih =>
    obtain ⟨bits', hb⟩ := hrun
    have h1 := valSize_rows_le hb
    simp only [BB, encL, valSize_list, List.map_cons, listSize_cons, List.length_cons,
      List.sum_cons] at ih h1 ⊢
    nlinarith

/-! ## Bodies -/

/-- `seedRep : [n, w] ↦` `n` draws of `w` fresh bits (`repB` with element `readNat`). -/
def body_seedRep : Expr := body_repB Idx.seedRepStep

/-- Loop body of `seedRep`. -/
def body_seedRepStep : Expr := body_repBStep F2e2e.Cost.Idx.readNat

/-- `rowNew : [n, w] ↦ [seed, 0, 0]`. -/
def body_rowNew : Expr :=
  Arith.eTriple (Expr.call Idx.seedRep (Expr.var 0)) (Expr.lit 0) (Expr.lit 0)

/-- `rowRep : [k, [n, w]] ↦` `k` fresh rows (`repB` with element `rowNew`). -/
def body_rowRep : Expr := body_repB Idx.rowRepStep

/-- Loop body of `rowRep`. -/
def body_rowRepStep : Expr := body_repBStep Idx.rowNew

/-- `groupRep : [k, [32, [n, w]]] ↦` `k` subgroups (`repB` with element `rowRep`). -/
def body_groupRep : Expr := body_repB Idx.groupRepStep

/-- Loop body of `groupRep`. -/
def body_groupRepStep : Expr := body_repBStep Idx.rowRep

/-- `coarseRep : [k, [g, [32, [n, w]]]] ↦` `k` coarse groups (`repB` with element `groupRep`). -/
def body_coarseRep : Expr := body_repB Idx.coarseRepStep

/-- Loop body of `coarseRep`. -/
def body_coarseRepStep : Expr := body_repBStep Idx.groupRep

/-- `blocksMap : [bs, [n, w]] ↦` the ADA sample blocks (`mapB` with element `rowRep`). -/
def body_blocksMap : Expr := body_mapB Idx.blocksMapStep

/-- Loop body of `blocksMap`. -/
def body_blocksMapStep : Expr := body_mapBStep Idx.rowRep

/-- A program containing the row routines and the library routines they call. -/
structure RowsLib (prog : List Expr) : Prop where
  seedRep : prog[Idx.seedRep]? = some body_seedRep
  seedRepStep : prog[Idx.seedRepStep]? = some body_seedRepStep
  rowNew : prog[Idx.rowNew]? = some body_rowNew
  rowRep : prog[Idx.rowRep]? = some body_rowRep
  rowRepStep : prog[Idx.rowRepStep]? = some body_rowRepStep
  groupRep : prog[Idx.groupRep]? = some body_groupRep
  groupRepStep : prog[Idx.groupRepStep]? = some body_groupRepStep
  coarseRep : prog[Idx.coarseRep]? = some body_coarseRep
  coarseRepStep : prog[Idx.coarseRepStep]? = some body_coarseRepStep
  blocksMap : prog[Idx.blocksMap]? = some body_blocksMap
  blocksMapStep : prog[Idx.blocksMapStep]? = some body_blocksMapStep
  readNat : prog[F2e2e.Cost.Idx.readNat]? = some body_readNat
  readNatStep : prog[F2e2e.Cost.Idx.readNatStep]? = some body_readNatStep
  reverse : prog[F2e2e.Cost.Idx.reverse]? = some body_reverse
  revAppendStep : prog[F2e2e.Cost.Idx.revAppendStep]? = some body_revAppendStep

/-! ## Specs -/

section Specs

variable {prog : List Expr} {M : ℕ}

theorem seedRep_impl (hL : RowsLib prog) (n w : ℕ) (hM1 : S_readNat w ≤ M)
    (hM2 : repB_M n (encN w) (w + 1) ≤ M) :
    Implements prog M [nwVal n w] body_seedRep (encL encN) (replicateB (uniformBits w) n) :=
  repB_impl hL.seedRepStep hL.readNat hL.reverse hL.revAppendStep encN (encN w) (uniformBits w)
    n (w + 1) (readNat_impl hL.readNatStep w hM1)
    (fun _ _ hb => valSize_encN_le_of_lt (uniformBits_run_lt hb)) hM2

theorem rowNew_impl (hL : RowsLib prog) (n w : ℕ) (hM1 : S_readNat w ≤ M)
    (hM2 : repB_M n (encN w) (w + 1) ≤ M) (hM3 : RB n w ≤ M) :
    Implements prog M [nwVal n w] body_rowNew rowVal (rowProg n w) := by
  intro bits r h
  have hr := (valSize_rowVal_le h).trans hM3
  have h7 : 7 ≤ RB n w := by unfold RB; omega
  unfold rowProg at h
  obtain ⟨b₁, b₂, z, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
  have hseed := seedRep_impl hL n w hM1 hM2 b₁ z h1
  have hcall := EvalsVal.call (EvalsVal.var0 (v := nwVal n w) (rest := [])) hL.seedRep hseed
  rw [rowVal_fresh] at hr ⊢
  have htr := EvalsVal.triple hcall
    (EvalsVal.lit' (z := 0) (by simp only [valSize_int, bitLen_zero]; omega))
    (EvalsVal.lit' (z := 0) (by simp only [valSize_int, bitLen_zero]; omega)) hr
  simpa [body_rowNew] using htr

/-- The value bound of `rowRep` with `k` rows: the seed sampler, the row triple and the `repB`
loop. -/
def rowRepM (k n w : ℕ) : ℕ :=
  S_readNat w + repB_M n (encN w) (w + 1) + RB n w + repB_M k (nwVal n w) (RB n w)

theorem rowRep_impl (hL : RowsLib prog) (k n w : ℕ) (hM : rowRepM k n w ≤ M) :
    Implements prog M [Val.list [encN k, nwVal n w]] body_rowRep (encL rowVal)
      (replicateB (rowProg n w) k) := by
  simp only [rowRepM] at hM
  exact repB_impl hL.rowRepStep hL.rowNew hL.reverse hL.revAppendStep rowVal (nwVal n w)
    (rowProg n w) k (RB n w) (rowNew_impl hL n w (by omega) (by omega) (by omega))
    (fun _ _ hb => valSize_rowVal_le hb) (by omega)

/-- The `[32, [n, w]]` argument of a subgroup. -/
def subArg (n w : ℕ) : Val := Val.list [encN 32, nwVal n w]

/-- The value bound of `groupRep` with `k` subgroups. -/
def groupRepM (k n w : ℕ) : ℕ := rowRepM 32 n w + repB_M k (subArg n w) (SB n w)

theorem groupRep_impl (hL : RowsLib prog) (k n w : ℕ) (hM : groupRepM k n w ≤ M) :
    Implements prog M [Val.list [encN k, subArg n w]] body_groupRep (encL (encL rowVal))
      (replicateB (replicateB (rowProg n w) 32) k) := by
  simp only [groupRepM] at hM
  exact repB_impl hL.groupRepStep hL.rowRep hL.reverse hL.revAppendStep (encL rowVal)
    (subArg n w) (replicateB (rowProg n w) 32) k (SB n w) (rowRep_impl hL 32 n w (by omega))
    (fun _ _ hb => valSize_sub_le hb) (by omega)

/-- The `[g, [32, [n, w]]]` argument of a coarse group. -/
def groupArg (g n w : ℕ) : Val := Val.list [encN g, subArg n w]

/-- The value bound of `coarseRep` with `k` groups of `g` subgroups. -/
def coarseRepM (k g n w : ℕ) : ℕ := groupRepM g n w + repB_M k (groupArg g n w) (GB g n w)

theorem coarseRep_impl (hL : RowsLib prog) (k g n w : ℕ) (hM : coarseRepM k g n w ≤ M) :
    Implements prog M [Val.list [encN k, groupArg g n w]] body_coarseRep
      (encL (encL (encL rowVal))) (replicateB (replicateB (replicateB (rowProg n w) 32) g) k) := by
  simp only [coarseRepM] at hM
  exact repB_impl hL.coarseRepStep hL.groupRep hL.reverse hL.revAppendStep (encL (encL rowVal))
    (groupArg g n w) (replicateB (replicateB (rowProg n w) 32) g) k (GB g n w)
    (groupRep_impl hL g n w (by omega)) (fun _ _ hb => valSize_group_le hb) (by omega)

/-- The value bound of `blocksMap` with block sizes `bs`. -/
def blocksM (bs : List ℕ) (n w : ℕ) : ℕ :=
  valSize (encL encN bs) + 5 * BB bs n w + valSize (nwVal n w) + 60

theorem blocksMap_impl (hL : RowsLib prog) (bs : List ℕ) (n w : ℕ)
    (hrow : ∀ nj ∈ bs, rowRepM nj n w ≤ M) (hM : blocksM bs n w ≤ M) :
    Implements prog M [Val.list [encL encN bs, nwVal n w]] body_blocksMap (encL (encL rowVal))
      (mapB (fun nj => replicateB (rowProg n w) nj) bs) :=
  mapB_impl_tot hL.blocksMapStep hL.rowRep hL.reverse hL.revAppendStep encN (encL rowVal)
    (nwVal n w) (fun nj => replicateB (rowProg n w) nj) bs (BB bs n w)
    (fun nj hnj => rowRep_impl hL nj n w (hrow nj hnj)) (fun _ _ h => valSize_blocks_le bs h) hM

end Specs

end F2e2e.C.Impl.W3
