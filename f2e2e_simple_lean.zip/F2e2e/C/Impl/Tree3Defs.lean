import F2e2e.C.Impl.W6Facts
import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.MapIdx
import F2e2e.Cost.Lib.GetOpt
import F2e2e.Cost.Lib.Replicate
import F2e2e.Cost.Arith.Basic

/-!
# W6, Tree3 (definitions): Step 3 of the round (C-ALG `step3`, `F2e2e/C/Alg/Round.lean` L133–168)

Top-down guards: for `d = 0, …, H − 1` (stopping at a failure) the guard amplitude
`δ_d = guardMant Ĉ_d α (u_d − k_d)` is computed; if `δ_d ≠ 0` it is added to `Y_d` (bank index `d`)
and to both arrays of the strict nonleaf descendants (bank indices `≥ d + 1`), the cache `P_d` and the
terminal accumulator absorb `δ_d²` (rounded, range-checked).

Routines (W6 range, Tree3 sub-range 260–289):
* 260 `body_step3`: `[p, st] ↦ encState (step3 P s)` (the fold over `List.range H`);
* 261 `body_step3Step`: the fold step `[d, st, [p, tr]] ↦ st` if failed, else `step3Depth`;
* 262 `body_foldBStep 261`, 263 `body_foldB 262` (DSL-CALC's fold);
* 264 `body_step3Depth`: `[p, st, tr, d]`, the learner lookup (`getOpt`);
* 265 `body_step3Guard`: `[p, st, tr, d, L]`, the guard amplitude;
* 266 `body_step3Apply`: `[p, st, d, L, g, δ]`, the bank updates, roundings and range checks;
* 267–269: `modifyAt` of the banks (`addGuardYBank`), 270–272: `mapFrom` of the banks
  (`addGuardXYBank`), 273–275: `setAt` of the learners (DSL-CALC's `mapIdx`).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

namespace Idx

abbrev step3 : ℕ := 260
abbrev step3Step : ℕ := 261
abbrev step3FoldStep : ℕ := 262
abbrev step3Fold : ℕ := 263
abbrev step3Depth : ℕ := 264
abbrev step3Guard : ℕ := 265
abbrev step3Apply : ℕ := 266
abbrev step3ModYElem : ℕ := 267
abbrev step3ModYStep : ℕ := 268
abbrev step3ModY : ℕ := 269
abbrev step3MapXYElem : ℕ := 270
abbrev step3MapXYStep : ℕ := 271
abbrev step3MapXY : ℕ := 272
abbrev step3SetLElem : ℕ := 273
abbrev step3SetLStep : ℕ := 274
abbrev step3SetL : ℕ := 275

end Idx

/-! ## The DSL code (generated from named-variable descriptions; environments documented) -/

/-- Step 3: `[p, st] ↦` the fold of `body_step3Step` over `List.range H` from `st`, with extra
`[p, t + 1]`. Bindings: `p, st, tr = t + 1, H, l = range H`. -/
def body_step3 : Expr :=
  Expr.letE (eGet 0 ((Expr.var 0))) <|
  Expr.letE (eGet 1 ((Expr.var 1))) <|
  Expr.letE (Expr.bin BinOp.add (eGet 0 ((Expr.var 0))) ((Expr.lit 1))) <|
  Expr.letE (Expr.call Idx.pH ((Expr.var 2))) <|
  Expr.letE (Expr.call Cost.Idx.range ((Expr.var 0))) <|
  Expr.call Idx.step3Fold (eList [(Expr.var 3), (Expr.var 0), eList [(Expr.var 4), (Expr.var 2)]])

/-- The fold step: `[d, st, [p, tr]] ↦ st` if `st` is failed, else `step3Depth [p, st, tr, d]`. -/
def body_step3Step : Expr :=
  Expr.letE (eGet 1 ((Expr.var 0))) <|
  Expr.ite (eGet 1 ((Expr.var 0)))
    ((Expr.var 0))
    (Expr.call Idx.step3Depth (eList [eGet 0 (eGet 2 ((Expr.var 1))), (Expr.var 0), eGet 1 (eGet 2 ((Expr.var 1))), eGet 0 ((Expr.var 1))]))

/-- Depth `d`: `[p, st, tr, d]`; bindings `p, st, tr, d, o = getOpt (learners, d)`; a missing
learner fails the state, otherwise `step3Guard [p, st, tr, d, L]`. -/
def body_step3Depth : Expr :=
  Expr.letE (eGet 0 ((Expr.var 0))) <|
  Expr.letE (eGet 1 ((Expr.var 1))) <|
  Expr.letE (eGet 2 ((Expr.var 2))) <|
  Expr.letE (eGet 3 ((Expr.var 3))) <|
  Expr.letE (Expr.call Cost.Idx.getOpt (eList [eGet 4 ((Expr.var 2)), (Expr.var 0)])) <|
  Expr.ite (Expr.un UnOp.isNil (Expr.var 0))
    (eList [eGet 0 ((Expr.var 3)), (Expr.lit 1), eGet 2 ((Expr.var 3)), eGet 3 ((Expr.var 3)), eGet 4 ((Expr.var 3)), eGet 5 ((Expr.var 3)), eGet 6 ((Expr.var 3))])
    (Expr.call Idx.step3Guard (eList [(Expr.var 4), (Expr.var 3), (Expr.var 2), (Expr.var 1), Expr.un UnOp.head (Expr.var 0)]))

/-- The guard amplitude: `[p, st, tr, d, L]`; bindings `p, st, tr, d, L, g = guardCoord d tr,
q_g, q_C, q_γ, α, u_d, e = u_d − k_d, δ`; `δ = 0` keeps the state, otherwise `step3Apply`. -/
def body_step3Guard : Expr :=
  Expr.letE (eGet 0 ((Expr.var 0))) <|
  Expr.letE (eGet 1 ((Expr.var 1))) <|
  Expr.letE (eGet 2 ((Expr.var 2))) <|
  Expr.letE (eGet 3 ((Expr.var 3))) <|
  Expr.letE (eGet 4 ((Expr.var 4))) <|
  Expr.letE (Expr.call Idx.pGuardCoord (eList [(Expr.var 4), (Expr.var 1), (Expr.var 2)])) <|
  Expr.letE (Expr.call Idx.peHg ((Expr.var 5))) <|
  Expr.letE (Expr.call Idx.peHC ((Expr.var 6))) <|
  Expr.letE (Expr.call Idx.peGamma ((Expr.var 7))) <|
  Expr.letE (Expr.bin BinOp.sub (Expr.bin BinOp.sub (Expr.bin BinOp.sub ((Expr.var 2)) ((Expr.var 1))) ((Expr.var 0))) ((Expr.lit 2))) <|
  Expr.letE (Expr.call Idx.peU (eList [(Expr.var 9), (Expr.var 6)])) <|
  Expr.letE (Expr.bin BinOp.sub ((Expr.var 0)) (eGet 2 ((Expr.var 6)))) <|
  Expr.letE (Expr.call Idx.guardMant (eList [eGet 0 ((Expr.var 7)), (Expr.var 2), (Expr.var 0)])) <|
  Expr.ite (Expr.bin BinOp.eq ((Expr.var 0)) ((Expr.lit 0)))
    ((Expr.var 11))
    (Expr.call Idx.step3Apply (eList [(Expr.var 12), (Expr.var 11), (Expr.var 9), (Expr.var 8), (Expr.var 7), (Expr.var 0)]))

/-- The guard update: `[p, st, d, L, g, δ]`; bindings `p, st, d, L, g, δ, b1 = modifyAt (addGuardY),
b2 = mapFrom (addGuardXY), q_P, q_leaf, q_g, δ², 2^(2q_g), 2^q_P, 2^q_leaf, cq, cache', lq, leaf',
r1, r2`, then the two range checks. -/
def body_step3Apply : Expr :=
  Expr.letE (eGet 0 ((Expr.var 0))) <|
  Expr.letE (eGet 1 ((Expr.var 1))) <|
  Expr.letE (eGet 2 ((Expr.var 2))) <|
  Expr.letE (eGet 3 ((Expr.var 3))) <|
  Expr.letE (eGet 4 ((Expr.var 4))) <|
  Expr.letE (eGet 5 ((Expr.var 5))) <|
  Expr.letE (Expr.call Idx.step3ModY (eList [eGet 5 ((Expr.var 4)), eList [(Expr.var 5), (Expr.var 3), (Expr.var 1), (Expr.var 0)]])) <|
  Expr.letE (Expr.call Idx.step3MapXY (eList [(Expr.var 0), eList [(Expr.var 6), Expr.bin BinOp.add ((Expr.var 4)) ((Expr.lit 1)), (Expr.var 2), (Expr.var 1)]])) <|
  Expr.letE (Expr.call Idx.peHP ((Expr.var 7))) <|
  Expr.letE (Expr.call Idx.peHleaf ((Expr.var 8))) <|
  Expr.letE (Expr.call Idx.peHg ((Expr.var 9))) <|
  Expr.letE (Expr.bin BinOp.mul ((Expr.var 5)) ((Expr.var 5))) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.bin BinOp.add ((Expr.var 1)) ((Expr.var 1)))) <|
  Expr.letE (Expr.call Cost.Idx.pow2 ((Expr.var 4))) <|
  Expr.letE (Expr.call Cost.Idx.pow2 ((Expr.var 4))) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.bin BinOp.add (Expr.bin BinOp.mul (eGet 1 ((Expr.var 11))) ((Expr.var 2))) (Expr.bin BinOp.mul ((Expr.var 3)) ((Expr.var 1))), Expr.bin BinOp.mul ((Expr.var 1)) ((Expr.var 2))])) <|
  Expr.letE (Expr.call Idx.roundMantQ (eList [(Expr.var 7), (Expr.var 0)])) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.bin BinOp.add (Expr.bin BinOp.mul (eGet 6 ((Expr.var 15))) ((Expr.var 4))) (Expr.bin BinOp.mul ((Expr.var 5)) ((Expr.var 2))), Expr.bin BinOp.mul ((Expr.var 2)) ((Expr.var 4))])) <|
  Expr.letE (Expr.call Idx.roundMantQ (eList [(Expr.var 8), (Expr.var 0)])) <|
  Expr.letE (Expr.call Idx.inRangeA (eList [(Expr.var 18), Expr.call Idx.normQ (eList [(Expr.var 2), (Expr.var 5)])])) <|
  Expr.letE (Expr.call Idx.inRangeA (eList [(Expr.var 19), Expr.call Idx.normQ (eList [(Expr.var 1), (Expr.var 5)])])) <|
  Expr.ite ((Expr.var 1))
    (Expr.ite ((Expr.var 0))
    (eList [eGet 0 ((Expr.var 19)), eGet 1 ((Expr.var 19)), eGet 2 ((Expr.var 19)), eGet 3 ((Expr.var 19)), Expr.call Idx.step3SetL (eList [eGet 4 ((Expr.var 19)), eList [(Expr.var 18), eList [eGet 0 ((Expr.var 17)), (Expr.var 4), eGet 2 ((Expr.var 17)), eGet 3 ((Expr.var 17)), eGet 4 ((Expr.var 17))]]]), (Expr.var 13), (Expr.var 2)])
    (eList [eGet 0 ((Expr.var 19)), (Expr.lit 1), eGet 2 ((Expr.var 19)), eGet 3 ((Expr.var 19)), eGet 4 ((Expr.var 19)), (Expr.var 13), eGet 6 ((Expr.var 19))]))
    (eList [eGet 0 ((Expr.var 19)), (Expr.lit 1), eGet 2 ((Expr.var 19)), eGet 3 ((Expr.var 19)), eGet 4 ((Expr.var 19)), (Expr.var 13), eGet 6 ((Expr.var 19))])

/-- `modifyAt` element routine: `[i, B, [p, d, g, δ]] ↦ addGuardYBank [p, B, g, δ]` if `i = d`. -/
def body_step3ModYElem : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 ((Expr.var 0))) (eGet 1 (eGet 2 ((Expr.var 0)))))
    (Expr.call Idx.addGuardYBank (eList [eGet 0 (eGet 2 ((Expr.var 0))), eGet 1 ((Expr.var 0)), eGet 2 (eGet 2 ((Expr.var 0))), eGet 3 (eGet 2 ((Expr.var 0)))]))
    (eGet 1 ((Expr.var 0)))

/-- `mapFrom` element routine: `[i, B, [p, d1, g, δ]] ↦ B` if `i < d1`, else
`addGuardXYBank [p, B, g, δ]`. -/
def body_step3MapXYElem : Expr :=
  Expr.ite (Expr.bin BinOp.lt (eGet 0 ((Expr.var 0))) (eGet 1 (eGet 2 ((Expr.var 0)))))
    (eGet 1 ((Expr.var 0)))
    (Expr.call Idx.addGuardXYBank (eList [eGet 0 (eGet 2 ((Expr.var 0))), eGet 1 ((Expr.var 0)), eGet 2 (eGet 2 ((Expr.var 0))), eGet 3 (eGet 2 ((Expr.var 0)))]))

/-- `setAt` element routine: `[i, L, [d, L']] ↦ L'` if `i = d`, else `L`. -/
def body_step3SetLElem : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 ((Expr.var 0))) (eGet 0 (eGet 2 ((Expr.var 0)))))
    (eGet 1 (eGet 2 ((Expr.var 0))))
    (eGet 1 ((Expr.var 0)))

/-- The program contains Step 3's routines and the library routines they use. -/
structure Tree3Lib (prog : List Expr) : Prop where
  step3 : prog[Idx.step3]? = some body_step3
  step3Step : prog[Idx.step3Step]? = some body_step3Step
  step3FoldStep : prog[Idx.step3FoldStep]? = some (body_foldBStep Idx.step3Step)
  step3Fold : prog[Idx.step3Fold]? = some (body_foldB Idx.step3FoldStep)
  step3Depth : prog[Idx.step3Depth]? = some body_step3Depth
  step3Guard : prog[Idx.step3Guard]? = some body_step3Guard
  step3Apply : prog[Idx.step3Apply]? = some body_step3Apply
  modYElem : prog[Idx.step3ModYElem]? = some body_step3ModYElem
  modYStep : prog[Idx.step3ModYStep]? = some (body_mapIdxStep Idx.step3ModYElem)
  modY : prog[Idx.step3ModY]? = some (body_mapIdx Idx.step3ModYStep)
  mapXYElem : prog[Idx.step3MapXYElem]? = some body_step3MapXYElem
  mapXYStep : prog[Idx.step3MapXYStep]? = some (body_mapIdxStep Idx.step3MapXYElem)
  mapXY : prog[Idx.step3MapXY]? = some (body_mapIdx Idx.step3MapXYStep)
  setLElem : prog[Idx.step3SetLElem]? = some body_step3SetLElem
  setLStep : prog[Idx.step3SetLStep]? = some (body_mapIdxStep Idx.step3SetLElem)
  setL : prog[Idx.step3SetL]? = some (body_mapIdx Idx.step3SetLStep)
  reverse : prog[Cost.Idx.reverse]? = some body_reverse
  revAppendStep : prog[Cost.Idx.revAppendStep]? = some body_revAppendStep
  pow2 : prog[Cost.Idx.pow2]? = some body_pow2
  pow2Step : prog[Cost.Idx.pow2Step]? = some body_pow2Step
  range : prog[Cost.Idx.range]? = some body_range
  rangeStep : prog[Cost.Idx.rangeStep]? = some body_rangeStep
  getOpt : prog[Cost.Idx.getOpt]? = some body_getOpt
  getOptStep : prog[Cost.Idx.getOptStep]? = some body_getOptStep

/-! ## The reference decomposition of `step3Depth` -/

/-- The rounded cache of the guard update. -/
def cache3 (P : StreamParams) (Ld : Learner) (δ : ℤ) : ℤ :=
  roundMant P.eHP (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2)

/-- The rounded terminal accumulator of the guard update. -/
def leaf3 (P : StreamParams) (s : State) (δ : ℤ) : ℤ :=
  roundMant P.eHleaf (gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2)

/-- The banks after the guard update. -/
def banks3 (P : StreamParams) (s : State) (d g : ℕ) (δ : ℤ) : List Bank :=
  mapFrom (Bank.mapRows (Row.addGuardXY P g δ)) (d + 1)
    (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d s.banks)

/-- The learner after the guard update. -/
def learner3 (P : StreamParams) (Ld : Learner) (δ : ℤ) : Learner := { Ld with cache := cache3 P Ld δ }

/-- The guard update of `step3Depth` (after `δ ≠ 0`). -/
def step3ApplyRef (P : StreamParams) (s : State) (d : ℕ) (Ld : Learner) (g : ℕ) (δ : ℤ) : State :=
  if inRangeA P (gridVal P.eHP (cache3 P Ld δ)) && inRangeA P (gridVal P.eHleaf (leaf3 P s δ)) then
    { s with banks := banks3 P s d g δ, learners := setAt (learner3 P Ld δ) d s.learners,
             leaf := leaf3 P s δ }
  else { s with banks := banks3 P s d g δ }.fail

/-- `step3Depth` after the learner lookup. -/
def step3GuardRef (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) (Ld : Learner) : State :=
  if guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0 then s
  else step3ApplyRef P s d Ld (P.guardCoord d tr)
    (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)))

theorem step3Depth_none (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ)
    (h : s.learners[d]? = none) : step3Depth P tr s d = s.fail := by
  simp only [step3Depth, h]

theorem step3Depth_some (P : StreamParams) (tr : ℕ) (s : State) (d : ℕ) {Ld : Learner}
    (h : s.learners[d]? = some Ld) : step3Depth P tr s d = step3GuardRef P tr s d Ld := by
  simp only [step3Depth, h]
  rfl

/-- The two outcomes of the guard update, encoded. -/
theorem encState_step3ApplyRef (adaEnc : F2e2e.B.AdaState → Val) (P : StreamParams) (s : State)
    (d : ℕ) (Ld : Learner) (g : ℕ) (δ : ℤ) :
    encState adaEnc (step3ApplyRef P s d Ld g δ) =
      if inRangeA P (gridVal P.eHP (cache3 P Ld δ)) && inRangeA P (gridVal P.eHleaf (leaf3 P s δ)) then
        Val.list [Val.int (s.t : ℤ), Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ),
          Val.int (s.fpVal : ℤ), encL encLearner (setAt (learner3 P Ld δ) d s.learners),
          encL (encBank adaEnc) (banks3 P s d g δ), Val.int (leaf3 P s δ)]
      else
        Val.list [Val.int (s.t : ℤ), Val.int 1, Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ),
          encL encLearner s.learners, encL (encBank adaEnc) (banks3 P s d g δ), Val.int s.leaf] := by
  unfold step3ApplyRef
  split <;> rfl

/-! ## Deterministic `ite` on an integer flag -/

section iteRules

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_ite_t {c t f : Expr} {z : ℤ} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hz : z ≠ 0) (ht : EvalsVal prog M env [] (.inl t) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_true hc hz ht

theorem ev_ite_f {c t f : Expr} {z : ℤ} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hz : z = 0) (hf : EvalsVal prog M env [] (.inl f) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_false hc hz hf

end iteRules

end F2e2e.C.Impl.W6
