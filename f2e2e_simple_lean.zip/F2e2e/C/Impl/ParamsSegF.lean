import F2e2e.C.Impl.ParamsVal

/-!
# W1 (public parameters, DSL), part 4f: segment F of the master chain

Owner: A-ARCH (a99d156c), for C-PARAMS (e26ae4ae). `Z_max, C_max, A_max`, `M_q`, `q`, the seed trials, `w`, `irrW`, the bank ADA exponents and `g` (push indices `35–46`).
Statement fixed (C-PARAMS); every `PE.val … = P.X` goal must be closed with the propositional lemmas of
`F2e2e/C/Impl/ParamsVal.lean` (never by a bare `rfl`).
-/

set_option linter.unusedSimpArgs false

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

theorem segF_ok (hlib : W1Lib prog) (P : StreamParams) (hP : C.Top.ParamsOK P)
    (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segF (valsF P)
      [P.eHleaf, P.eHstep, P.eHb, P.eHP, P.eOmega, P.eSigma, P.eHC, P.eHg,
        P.L, P.s, P.Rmax, P.Jmax, P.Jstar, P.K0, P.Kepoch, P.eUstar, P.eNu, P.logG, P.V,
        P.Vd (P.H - 1), P.H - 1, P.Vd P.H, P.B, P.logB, P.eGamma, P.eEta, P.W, P.Dstar, P.T, P.H,
        P.betaExp, P.epsExp, P.U, P.m, P.n] := by
  have hBH : P.B ^ P.H = 2 ^ (P.logB * P.H) := by
    unfold StreamParams.B
    rw [← pow_mul]
  -- Z_max
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true, and_assoc]
      refine ⟨clog2_cond hlib hM _, pow2_cond hlib hM ?_⟩
      have := Space.eZmax_le P
      unfold StreamParams.eZmax at this
      omega)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.Zmax, StreamParams.eZmax])
    (Zmax_le_A P) ?_
  -- C_max
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true, and_assoc]
      refine ⟨pow2_cond hlib hM ?_, clog2_cond hlib hM _, pow2_cond hlib hM ?_⟩
      · have h1 : P.logB * P.H ≤ (2 * P.calL) * P.calL :=
          Nat.mul_le_mul (Space.logB_le P) (Space.H_le P)
        have h2 : (2 * P.calL) * P.calL = 2 * P.calL ^ 2 := by ring
        have := calL_sq_le_cube P
        omega
      · have := Space.eCmax_le P
        unfold StreamParams.eCmax at this
        rw [hBH] at this
        have := calL_sq_le_cube P
        omega)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.Cmax, StreamParams.eCmax, hBH])
    (Cmax_le_A P) ?_
  -- A_max
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true, and_assoc]
      refine ⟨clog2_cond hlib hM _, pow2_cond hlib hM ?_⟩
      have := Space.eAmax_le P
      unfold StreamParams.eAmax at this
      rw [sq] at this
      omega)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.Amax, StreamParams.eAmax, sq])
    (Amax_le_A P) ?_
  -- 10 n m (U+1) 2^{betaExp}
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', true_and, and_true]
      exact pow2_cond hlib hM (by have := betaExp_le_calL P; have := calL_le_cube P; omega))
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', Mq0])
    (Mq0_le_A P) ?_
  -- M_q
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_mul', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        StreamParams.Mq, Mq0]
      ring) (Mq_le_A P) ?_
  -- q
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        true_and]
      intro x hx _
      subst hx
      exact lp_node hlib.fp hP hM)
    (by
      simp only [val_var', val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ']
      exact HashDSL.leastPrimeGE_Mq P (W2.one_le_Mq P hP)) (q_le_A P) ?_
  -- seed trials
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        StreamParams.seedTrials])
    (seedTrials_le_A P) ?_
  -- w
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_call', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.w])
    (w_le_A P) ?_
  -- irrW
  refine ChainOK.pe_cons rfl (by decide)
    (by
      simp only [PE.calls, val_var', val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        true_and]
      intro x hx _
      subst hx
      exact irr_node hlib.hash hM)
    (by
      simp only [val_var', val_call', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        C.Alg.irrW])
    (irrW_le_A P) ?_
  -- bank ADA exponents, g
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_call', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.eBankA])
    (eBankA_le_A P) ?_
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.eBankXi])
    (eBankXi_le_A P) ?_
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.gCoarse])
    (gCoarse_le_A P) ?_
  exact ChainOK.nil

end W1

end F2e2e.C.Impl
