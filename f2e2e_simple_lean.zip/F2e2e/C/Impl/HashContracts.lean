import F2e2e.C.Impl.HashAlg
import F2e2e.C.Impl.W6Contracts

/-!
# W2's contracts: `W2Contract` (for W6) and the row sign (for W5)

* `w2Contract`: C-TOP's `W2Contract` (`F2e2e/C/Impl/W6Contracts.lean`) holds for every program that
  contains the fingerprint routines (`FpLib prog`): the DSL routine `fpUpdate` (index `206`) on
  `[q, seed, val, i, Δ]` returns `encN (fpUpdate P seed val i Δ)` (C-ALG's reference,
  `F2e2e/C/Alg/Fingerprint.lean`) with every value of size `≤ Mv R P`.
* `rowSign_val` / `rowSign_call_val`: for W5's bank routines, the DSL routine `rowSign` (index `177`)
  on `[w, irrW P, seed, i]` returns `encZ (rowSign P r i)` (C-ALG's reference,
  `F2e2e/C/Alg/Bank.lean`) for rows with `RowOK P r` and coordinates `1 ≤ i ≤ D_*`, with every value
  of size `≤ 2^20 ℒ³ ≤ Mv R P`.
* `encInts_seed`: the seed component of C-SPACE's `encRow r` is `encL encN r.seed`.

The value bounds come from the parameter bounds of `F2e2e/C/SpaceParams.lean` (`q ≤ 2^{3ℒ}`,
`w ≤ 3ℒ + 1`, `s ≤ 3ℒ`, `n, 2U < 2^ℒ`): the peaks are `O(ℒ)` (fingerprint) and `O(ℒ²)` (row sign),
far below `Mv R P ≥ 2^37 ℒ³` (`W2.calL_cube_le_Mv`). The helper lemmas live in the namespace
`F2e2e.C.Impl.W2` so that they never shadow other packages' names in `F2e2e.C.Impl`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space

namespace W2

/-! ### Parameter bounds at the scale `ℒ` -/

/-- The value bound `Mv R P` dominates `2^37 ℒ³`. -/
theorem calL_cube_le_Mv (R : AdaRep) (P : StreamParams) : 2 ^ 37 * P.calL ^ 3 ≤ Mv R P := by
  unfold Mv stateSizeBound
  have h1 : 2 ^ 5 * P.calL ^ 3 ≤ P.H * (bankSizeBound P (R.bound P) + 1) +
      P.H * (2 ^ 6 * P.calL ^ 3 + 1) + 2 ^ 5 * P.calL ^ 3 := Nat.le_add_left _ _
  calc 2 ^ 37 * P.calL ^ 3 = 2 ^ 32 * (2 ^ 5 * P.calL ^ 3) := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ h1

/-- `10⁴ ℒ ≤ ℒ³` and `100 ℒ² ≤ ℒ³` (`ℒ ≥ 100`). -/
theorem calL_pow_bounds (P : StreamParams) :
    10000 * P.calL ≤ P.calL ^ 3 ∧ 100 * P.calL ^ 2 ≤ P.calL ^ 3 := by
  have hc := hundred_le_calL P
  constructor
  · have h1 : 100 * 100 ≤ P.calL * P.calL := Nat.mul_le_mul hc hc
    calc 10000 * P.calL = (100 * 100) * P.calL := by norm_num
      _ ≤ (P.calL * P.calL) * P.calL := Nat.mul_le_mul_right _ h1
      _ = P.calL ^ 3 := by ring
  · calc 100 * P.calL ^ 2 ≤ P.calL * P.calL ^ 2 := Nat.mul_le_mul_right _ hc
      _ = P.calL ^ 3 := by ring

/-- The fingerprint prime has at most `3ℒ + 1` bits. -/
theorem size_q_le (P : StreamParams) : Nat.size P.q ≤ 3 * P.calL + 1 := by
  apply Nat.size_le.2
  calc P.q ≤ 2 ^ (3 * P.calL) := q_le P
    _ < 2 ^ (3 * P.calL + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)

theorem n_lt_two_pow_calL (P : StreamParams) : P.n < 2 ^ P.calL := by
  have h1 := n_add_two_le P
  have h2 : 2 ^ cP P ≤ 2 ^ P.calL :=
    two_pow_le_two_pow (by have := cP_add_hundred_le P; omega)
  omega

theorem two_U_lt_two_pow_calL (P : StreamParams) : 2 * P.U < 2 ^ P.calL := by
  have h1 : P.U + 2 ≤ 2 ^ cP P := by
    refine le_trans ?_ (prod_le_two_pow_cP P)
    exact Nat.le_mul_of_pos_left _ (by positivity)
  have h2 : 2 ^ (cP P + 1) ≤ 2 ^ P.calL :=
    two_pow_le_two_pow (by have := cP_add_hundred_le P; omega)
  have h3 : 2 ^ (cP P + 1) = 2 * 2 ^ cP P := by rw [pow_succ]; ring
  omega

theorem one_le_Dstar (P : StreamParams) : 1 ≤ P.Dstar := by
  unfold StreamParams.Dstar
  omega

/-! ### Peak bounds -/

/-- The peak of `fpUpdate` is below the value bound `Mv R P`. -/
theorem fpUpdate_peak_le (R : AdaRep) (P : StreamParams) {seed val i : ℕ} {Δ : ℤ}
    (hseed : seed < P.q) (hval : val < P.q) (hin : i ≤ P.n) (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    8 * valSize (Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]) +
      S_fpUpdate P.q seed i ≤ Mv R P := by
  have hc := hundred_le_calL P
  have hMv := calL_cube_le_Mv R P
  have e37 : (2 : ℕ) ^ 37 = 137438953472 := by norm_num
  rw [e37] at hMv
  have hc3 := (calL_pow_bounds P).1
  have hq := size_q_le P
  have hbq : bitLen (P.q : ℤ) = Nat.size P.q := bitLen_natCast P.q
  have hbs : bitLen (seed : ℤ) ≤ Nat.size P.q := bitLen_le_size_of_le hseed.le
  have hbv : bitLen (val : ℤ) ≤ Nat.size P.q := bitLen_le_size_of_le hval.le
  have hin' : i < 2 ^ P.calL := lt_of_le_of_lt hin (n_lt_two_pow_calL P)
  have hsi : Nat.size i ≤ P.calL := Nat.size_le.2 hin'
  have hbi : bitLen (i : ℤ) = Nat.size i := bitLen_natCast i
  have hss : Nat.size seed ≤ Nat.size P.q := Nat.size_le_size hseed.le
  have hbΔ : bitLen Δ ≤ P.calL := by
    apply bitLen_le_of_abs_lt
    have h1 := two_U_lt_two_pow_calL P
    have h2 : ((2 * P.U : ℕ) : ℤ) < ((2 ^ P.calL : ℕ) : ℤ) := by exact_mod_cast h1
    push_cast at h2
    linarith
  simp only [S_fpUpdate, S_powMod, encN, encZ, valSize_list, listSize_cons, listSize_nil,
    valSize_int]
  omega

/-- Size of an encoded list of `q`-bit naturals (each entry costs `bitLen + 2`). -/
theorem valSize_encL_encN_le (q : ℕ) (cs : List ℕ) (hcs : ∀ c ∈ cs, c < 2 ^ q) :
    valSize (encL encN cs) ≤ 1 + cs.length * (q + 2) := by
  induction cs with
  | nil => simp [encL]
  | cons c cs ih =>
    have hc := hcs c List.mem_cons_self
    have ih' := ih (fun c' h => hcs c' (List.mem_cons_of_mem c h))
    have hb : bitLen (c : ℤ) ≤ q := bitLen_nat_le_of_lt hc
    have e : valSize (encN c) = bitLen (c : ℤ) + 1 := valSize_int _
    simp only [encL, List.map_cons, valSize_list, listSize_cons, List.length_cons] at ih' ⊢
    rw [e]
    have e2 : (cs.length + 1) * (q + 2) = cs.length * (q + 2) + (q + 2) := by ring
    rw [e2]
    omega

/-- The peak of `rowSign` is below `2^20 ℒ³` (it is `O(ℒ²)`: `w ≤ 3ℒ + 1`, `2s` seed entries). -/
theorem rowSign_peak_le (P : StreamParams) {r : Row} {i : ℕ} (hr : RowOK P r)
    (hi : i ≤ P.Dstar) :
    3 * valSize (Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]) +
      S_gfHorner P.w r.seed + 4 * P.w + 60 ≤ 2 ^ 20 * P.calL ^ 3 := by
  have hc := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := calL_pow_bounds P
  have e20 : (2 : ℕ) ^ 20 = 1048576 := by norm_num
  rw [e20]
  have hw := w_le P
  obtain ⟨hp1, hp2, -⟩ := isIrrPoly_irrW P (one_le_Dstar P)
  have hbw : bitLen (P.w : ℤ) ≤ P.w := bitLen_nat_le_of_lt Nat.lt_two_pow_self
  have hbp : bitLen (irrW P : ℤ) ≤ P.w + 1 := bitLen_nat_le_of_lt hp2
  have hbi : bitLen (i : ℤ) ≤ P.w := bitLen_nat_le_of_lt (lt_two_pow_w P hi)
  have e1 : valSize (encN P.w) = bitLen (P.w : ℤ) + 1 := valSize_int _
  have e2 : valSize (encN (irrW P)) = bitLen (irrW P : ℤ) + 1 := valSize_int _
  have e3 : valSize (encN i) = bitLen (i : ℤ) + 1 := valSize_int _
  have hV := valSize_encL_encN_le P.w r.seed hr.seed_lt
  have hsw : r.seed.length * (P.w + 2) ≤ 24 * P.calL ^ 2 := by
    rw [hr.seed_length]
    have h1 : 2 * P.s ≤ 6 * P.calL := by have := s_le P; omega
    have h2 : P.w + 2 ≤ 4 * P.calL := by omega
    calc 2 * P.s * (P.w + 2) ≤ (6 * P.calL) * (4 * P.calL) := Nat.mul_le_mul h1 h2
      _ = 24 * P.calL ^ 2 := by ring
  simp only [S_gfHorner, S_hornerLoop, S_gfMul, S_clmul, S_pmodDeg, S_xorNat, S_sizeNat, S_pow2,
    valSize_list, listSize_cons, listSize_nil]
  omega

end W2

/-! ### The fingerprint update (`W2Contract`) -/

/-- **W2's contract for W6** (`F2e2e/C/Impl/W6Contracts.lean`): in every program containing the
fingerprint routines, the routine at index `206` computes C-ALG's fingerprint update. -/
theorem w2Contract (R : AdaRep) {prog : List Expr} {M : ℕ} (hL : FpLib prog) :
    W2Contract R prog M := by
  refine ⟨⟨body_fpUpdate, hL.fpUpdate, fun P seed val i Δ _hP hseed hval _hi1 hin hΔ hM => ?_⟩⟩
  have h := fpUpdate_spec_alg hL P seed val i Δ (HashDSL.q_ne_zero P) 0
  have h' : EvalsSp prog 0 [Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]]
      body_fpUpdate (encN (F2e2e.C.Alg.fpUpdate P seed val i Δ))
      (0 + (8 * valSize (Val.list [encN P.q, encN seed, encN val, encN i, encZ Δ]) +
        S_fpUpdate P.q seed i)) := h.mono (by omega)
  exact h'.toVal.mono_M ((W2.fpUpdate_peak_le R P hseed hval hin hΔ).trans hM)

/-! ### The row sign (for W5) -/

/-- The seed component of C-SPACE's `encRow r` is `encL encN r.seed`. -/
theorem encInts_seed (r : Row) : encInts (r.seed.map fun z : ℕ => (z : ℤ)) = encL encN r.seed := by
  simp only [encInts, encL, List.map_map]
  rfl

/-- **The row sign for W5**: for a row with `RowOK P r` and a coordinate `1 ≤ i ≤ D_*`, the body of
`rowSign` (index `177`) on `[w, irrW P, seed, i]` returns `encZ (rowSign P r i)`, every value of
size `≤ M` for `M ≥ 2^20 ℒ³` (e.g. `M ≥ Mv R P`, see `W2.calL_cube_le_Mv`). (`hP`, `hi1` are not
needed; they are kept so that the statement is the one agreed with W5.) -/
theorem rowSign_val {prog : List Expr} (hL : HornerLib prog) (P : StreamParams)
    (_hP : F2e2e.C.Top.ParamsOK P) (r : Row) (hr : RowOK P r) (i : ℕ) (_hi1 : 1 ≤ i)
    (hi : i ≤ P.Dstar) {M : ℕ} (hM : 2 ^ 20 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M [Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]] []
      (.inl body_rowSign) (encZ (rowSign P r i)) := by
  have h := rowSign_spec_alg hL P r i (W2.one_le_Dstar P) hr.seed_lt hi 0
  have h' : EvalsSp prog 0 [Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]]
      body_rowSign (encZ (rowSign P r i))
      (0 + (3 * valSize (Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i]) +
        S_gfHorner P.w r.seed + 4 * P.w + 60)) := h.mono (by omega)
  exact h'.toVal.mono_M ((W2.rowSign_peak_le P hr hi).trans hM)

/-- **Calling the row sign** (`call 177 e` with `e` evaluating to `[w, irrW P, seed, i]`). -/
theorem rowSign_call_val {prog : List Expr} (hL : HornerLib prog) (P : StreamParams)
    (hP : F2e2e.C.Top.ParamsOK P) (r : Row) (hr : RowOK P r) (i : ℕ) (hi1 : 1 ≤ i)
    (hi : i ≤ P.Dstar) {M : ℕ} (hM : 2 ^ 20 * P.calL ^ 3 ≤ M)
    {env : List Val} {bits : List Bool} {e : Expr}
    (he : EvalsVal prog M env bits (.inl e)
      (Val.list [encN P.w, encN (irrW P), encL encN r.seed, encN i])) :
    EvalsVal prog M env bits (.inl (Expr.call F2e2e.Cost.Idx.rowSign e)) (encZ (rowSign P r i)) := by
  have h := EvalsVal.call he hL.rowSign (rowSign_val hL P hP r hr i hi1 hi hM)
  rw [List.append_nil] at h
  exact h

end F2e2e.C.Impl
