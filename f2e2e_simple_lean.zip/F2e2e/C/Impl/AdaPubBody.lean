import F2e2e.C.Impl.AdaPubSamp

/-!
# ADA module (W4), the parameter record: the DSL bodies of `adaPub`, `adaQA`, `adaBlockSizes`

Owner: W2 (a2ff64c3), for W4 (cc77ceaa). The routine `adaPub` computes W4's parameter record
`adaPubEnc (bankAda P)` (`F2e2e/C/Impl/AdaRep.lean`) from `encStreamParams P`, through W1's parameter
routines `peBankA`, `peBankXi`, `pbankM`, `pbankJ`, `pbankR` and W5's `normQ` (canonical rationals);
`adaQA` and `adaBlockSizes` project fields of it. Helpers (`F2e2e/C/Impl/AdaPub{Loops,Blocks,NB,BLoop,
Samp}.lean`, namespace `F2e2e.C.Impl.AP`) use the indices `650–657`; the library routines `pow2`,
`clog2`, `natSqrt` (`100–103`, `118–119`).

The parameters are recomputed exactly (B-ARCH's `adaParams`, `F2e2e/B/ArchParams.lean`): the level
count `p` by search, the caps `T_j^max = ⌈A/4^j⌉`, `Q`, `χ`, the block sizes, `q_A`, `ζ = 1/Z_d`,
`B_0`, `τ`, `a/2`, `κ h_A/4` and the five sampler parameter lists (closed forms in
`F2e2e/C/Impl/AdaPubMath.lean`). Every value has bit length `O(ℒ)`, below the value bound `2^37 ℒ³`.

* `adaPubTable`: the `(index, body)` entries (600, 604, 605, the helpers 650–657 and the library);
* `adaPub_eval`, `adaQA_eval`, `adaBlockSizes_eval`: the three `EvalsVal` specs used by W4's
  `w4Contract`.
-/

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

theorem le_sum_of_mem' {l : List ℕ} {x : ℕ} (h : x ∈ l) : x ≤ l.sum := by
  induction l with
  | nil => simp at h
  | cons y l ih =>
    simp only [List.sum_cons]
    rcases List.mem_cons.1 h with rfl | h'
    · omega
    · have := ih h'; omega

theorem foldl_max_eq (l : List ℕ) (a : ℕ) : l.foldl max a = max a (l.foldr max 0) := by
  induction l generalizing a with
  | nil => simp
  | cons x l ih =>
    simp only [List.foldl_cons, List.foldr_cons, ih]
    omega

theorem foldl_max_zero (l : List ℕ) : l.foldl max 0 = l.foldr max 0 := by
  rw [foldl_max_eq]; simp

/-- The search interval's top: `2^{2p}/4 = 2^{p + p - 2}` (`p ≥ 1`). -/
theorem four_pow_div_four' {p : ℕ} (hp : 1 ≤ p) : 2 ^ (2 * p) / 4 = 2 ^ (p + p - 2) := by
  obtain ⟨i, rfl⟩ : ∃ i, p = i + 1 := ⟨p - 1, by omega⟩
  rw [four_pow_div_four, show i + 1 + (i + 1) - 2 = 2 * i by omega]

end F2e2e.C.Impl.AP

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.C.Impl.W6
  F2e2e.C.Impl.AP

set_option linter.unusedSimpArgs false

/-! ## Bodies -/

/-- A sampler call `apSamp [q2, m, B0, Zd]` in the final environment of `body_adaPub`. -/
def apSampCall (m : Expr) : Expr :=
  Expr.call Cost.Idx.apSamp (eList [Expr.var 6, m, Expr.var 3, Expr.var 4])

/-- `adaPub : encStreamParams P ↦ adaPubEnc (bankAda P)`. Environment `[Π]`; the let-bound values
are, in order: `eA, eXi, M, J, R, 2^eA, 2^{eA+3}, p, A, 2^{2p-2}, [caps, sum], sum, Q, χ, h⁻¹,
2^{eA+11}, [blocks, max], a₁, a₂, q_A, 2^{q_A}, 2^{eXi}, Z_d, B_0, τ, a/2, κ h_A/4`. -/
def body_adaPub : Expr :=
  Expr.letE (Expr.call Idx.peBankA (Expr.var 0)) <|
  Expr.letE (Expr.call Idx.peBankXi (Expr.var 1)) <|
  Expr.letE (Expr.call Idx.pbankM (Expr.var 2)) <|
  Expr.letE (Expr.call Idx.pbankJ (Expr.var 3)) <|
  Expr.letE (Expr.call Idx.pbankR (Expr.var 4)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.var 4)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.bin BinOp.add (Expr.var 5) (Expr.lit 3))) <|
  Expr.letE (Expr.loop Cost.Idx.apPStep (eList [Expr.lit 2, Expr.lit 2, Expr.var 0])) <|
  Expr.letE (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul
    (Expr.lit 384) (Expr.var 0)) (Expr.var 0)) (Expr.var 2)) (Expr.var 2)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.bin BinOp.sub (Expr.bin BinOp.add (Expr.var 1) (Expr.var 1))
    (Expr.lit 2))) <|
  Expr.letE (Expr.loop Cost.Idx.apTStep (eList [Expr.var 2, Expr.nil, Expr.lit 0, Expr.var 1,
    Expr.var 0])) <|
  Expr.letE (eGet 1 (Expr.var 0)) <|
  Expr.letE (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 100)
      (Expr.bin BinOp.add (Expr.var 4) (Expr.lit 1)))
    (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.var 9)
      (Expr.var 7)) (Expr.var 8)) (Expr.lit 2)) (Expr.var 0))) <|
  Expr.letE (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.lit 49) (Expr.var 12))
      (Expr.var 11))
    (Expr.call Cost.Idx.clog2 (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.var 5)
      (Expr.bin BinOp.add (Expr.var 5) (Expr.lit 1))) (Expr.var 0)))) <|
  Expr.letE (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 512) (Expr.var 6)) (Expr.var 8)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.bin BinOp.add (Expr.var 14) (Expr.lit 11))) <|
  Expr.letE (Expr.loop Cost.Idx.apBStep (eList [Expr.bin BinOp.add (Expr.var 8) (Expr.lit 1),
    Expr.nil, Expr.lit 0, Expr.bin BinOp.mul (Expr.lit 4) (Expr.var 6), Expr.var 7, Expr.var 8,
    Expr.var 12, Expr.var 11, Expr.var 2,
    Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 1048576) (Expr.var 2)) (Expr.var 1),
    Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 4096) (Expr.var 2))
      (Expr.bin BinOp.mul (Expr.var 1) (Expr.var 1)),
    Expr.bin BinOp.mul (Expr.var 0) (Expr.var 8)])) <|
  Expr.letE (Expr.bin BinOp.add (Expr.bin BinOp.add (Expr.lit 29) (Expr.var 16))
    (Expr.call Cost.Idx.clog2 (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.var 9)
      (Expr.bin BinOp.add (Expr.var 9) (Expr.lit 1))) (Expr.var 3)))) <|
  Expr.letE (Expr.bin BinOp.add (Expr.lit 20) (Expr.call Cost.Idx.clog2 (eGet 1 (Expr.var 1)))) <|
  Expr.letE (Expr.ite (Expr.bin BinOp.lt (Expr.var 1) (Expr.var 0)) (Expr.var 0) (Expr.var 1)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.var 0)) <|
  Expr.letE (Expr.call Cost.Idx.pow2 (Expr.var 19)) <|
  Expr.letE (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul
      (Expr.lit 98304000) (Expr.var 14)) (Expr.bin BinOp.add (Expr.var 14) (Expr.lit 1))) (Expr.var 9))
    (Expr.bin BinOp.mul (Expr.var 16) (Expr.var 0))) <|
  Expr.letE (Expr.call Cost.Idx.clog2 (Expr.bin BinOp.mul (Expr.lit 16) (Expr.var 0))) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.lit 1,
    Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 8) (Expr.var 16)) (Expr.var 18)])) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.lit 1, Expr.bin BinOp.mul (Expr.lit 2) (Expr.var 19)])) <|
  Expr.letE (Expr.call Idx.normQ (eList [Expr.lit 1, Expr.bin BinOp.mul (Expr.bin BinOp.mul
    (Expr.bin BinOp.mul (Expr.lit 128) (Expr.var 18)) (Expr.var 20)) (Expr.var 5)])) <|
  eList [Expr.var 19, eGet 0 (Expr.var 10), eGet 0 (Expr.var 16),
    Expr.bin BinOp.add (Expr.lit 1) (Expr.var 15), Expr.var 24, Expr.var 23, Expr.var 22,
    Expr.var 7, Expr.var 6, Expr.var 2, Expr.var 1, Expr.var 0,
    eList [apSampCall (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 32768)
        (Expr.var 19)) (Expr.var 21)) (Expr.var 13)),
      apSampCall (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 16384)
        (Expr.var 19)) (Expr.var 21)) (Expr.var 13)),
      apSampCall (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 256) (Expr.var 13)) (Expr.var 21)),
      apSampCall (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 128) (Expr.var 13)) (Expr.var 21)),
      apSampCall (Expr.bin BinOp.mul (Expr.bin BinOp.mul (Expr.lit 64) (Expr.var 13)) (Expr.var 21))]]

/-- `adaQA : encStreamParams P ↦ Val.int (bankAda P).qA` (field 7 of the record). -/
def body_adaQA : Expr := eGet 7 (Expr.call Idx.adaPub (Expr.var 0))

/-- `adaBlockSizes : encStreamParams P ↦ encL encN (bankAda P).blockSizes` (field 1 of the record). -/
def body_adaBlockSizes : Expr := eGet 1 (Expr.call Idx.adaPub (Expr.var 0))

/-- The routine table of the parameter record: the entries 600, 604, 605, the helpers (650–657)
and every library routine they call (`pow2`, `clog2`, `natSqrt`). -/
def adaPubTable : List (ℕ × Expr) :=
  [(Idx.adaPub, body_adaPub), (Idx.adaQA, body_adaQA), (Idx.adaBlockSizes, body_adaBlockSizes),
    (Cost.Idx.apPStep, body_apPStep), (Cost.Idx.apTStep, body_apTStep),
    (Cost.Idx.apCap, body_apCap), (Cost.Idx.apC, body_apC), (Cost.Idx.apBStep, body_apBStep),
    (Cost.Idx.apCeilSqrt, body_apCeilSqrt), (Cost.Idx.apNB, body_apNB),
    (Cost.Idx.apSamp, body_apSamp),
    (Cost.Idx.pow2, body_pow2), (Cost.Idx.pow2Step, body_pow2Step),
    (Cost.Idx.clog2, body_clog2), (Cost.Idx.clog2Step, body_clog2Step),
    (Cost.Idx.natSqrt, body_natSqrt), (Cost.Idx.natSqrtStep, body_natSqrtStep)]

end F2e2e.C.Impl
