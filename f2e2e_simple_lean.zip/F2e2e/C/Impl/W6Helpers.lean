import F2e2e.C.Impl.MainDefs
import F2e2e.C.Impl.Tree1
import F2e2e.C.Impl.Tree4

/-!
# W6: the Tree1 and Tree4 deliverables discharge Main's hypotheses

* `treeHelpers_of`: `TreeHelpers R prog M` from `T1.step1_impl` and `T4.step4_impl`;
* `step4Out_of`: `Step4Out R` from `T4.step4_out`.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

/-- The Tree1 and Tree4 routines implement Steps 1 and 4 (contract form used by `round_impl`). -/
theorem treeHelpers_of {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT1 : T1.Tree1Lib prog) (hT4 : T4.Tree4Lib prog) :
    TreeHelpers R prog M where
  step1 := ⟨T1.body_step1, hT1.step1, fun _ _ hP hM hs ht hf => T1.step1_impl hR hC hT1 hP hM hs ht hf⟩
  step4 := ⟨T4.body_step4, hT4.step4, fun _ _ hP hM hs ht hf => T4.step4_impl hR hC hT4 hP hM hs ht hf⟩

/-- The semantic output fact of Step 4. -/
theorem step4Out_of {R : AdaRep} (hR : R.Valid) : Step4Out R :=
  fun _ _ hP hs ht hf => T4.step4_out hR hP hs ht hf

end F2e2e.C.Impl.W6
