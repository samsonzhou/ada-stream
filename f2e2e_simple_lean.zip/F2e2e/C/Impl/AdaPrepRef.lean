import F2e2e.C.Impl.AdaMus
import F2e2e.C.Impl.AdaValid

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 1: reference facts (B-NUM)

Owner: B-NUM (b5a655d4), for W4 (cc77ceaa). The DSL routine `adaPrepR` (Idx 700, `AdaPrep.lean`)
implements `(prepareRoot A vals f st cache).toBits (adaDraw A)` (B-ARCH's `F2e2e/B/ArchCore.lean`).
This file contains the reference-level facts used by its proof:

* `edgeDec`, `edgeTest_toBits`: the internal edge test as two draws and a decision; `edge_test_iff`:
  the decision in integers (cross-multiplication with positive denominators);
* `thrStep`, `thrStepIf`, `redraw_reopen_toBits`: the (at most three) threshold redraws of a
  correction; `applyCorrection_toBits`;
* `scanRef`, `scanQ`, `scanRef_unfold`: one iteration of a scan pass (the inner loop);
* `prepRef`, `prepQ`, `prepRef_unfold`: one iteration of `PrepareRoot` (the outer loop).
-/

namespace F2e2e.Cost.Idx

/-- `adaPrepR : [f, st, cache, pub, vals] ↦ encOptSt (PrepareRoot)` (the entry; a loop of `adaPassStep`). -/
abbrev adaPrepR : ℕ := 700
/-- `adaEdge : [pub, t, N0, D0, N1, D1] ↦` the internal edge test (two fresh noises). -/
abbrev adaEdge : ℕ := 701
/-- `adaCorr : [j, q, st, pub, vals] ↦` the state after a correction (fresh thresholds). -/
abbrev adaCorr : ℕ := 702
/-- `adaScanStep`: one iteration of a scan pass (body of the inner loop). -/
abbrev adaScanStep : ℕ := 703
/-- `adaPassStep`: one iteration of `PrepareRoot` (body of the outer loop). -/
abbrev adaPassStep : ℕ := 704
/-- `adaCorrDet : [j, q, st, pub, vals] ↦ [scores', T']` (deterministic part of a correction). -/
abbrev adaCorrDet : ℕ := 705
/-- `adaRedraw : [j, thrInt, pub] ↦` the redrawn thresholds of a correction. -/
abbrev adaRedraw : ℕ := 706
/-- `adaReset : [j, cache, p] ↦` the cache after a correction. -/
abbrev adaReset : ℕ := 707

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## The edge test -/

/-- The decision of the internal test of an edge: threshold index `t`, predictions `μ0, μ1` of the
two blocks, noise indices `kp, km` (`ArchCore.edgeTest`). -/
def edgeDec (A : AdaParams) (t : ℤ) (μ0 μ1 : ℚ) (kp km : ℤ) : Option Bool :=
  if A.tau + A.hA * (t : ℚ) ≤ (μ1 - μ0) + A.hA * (kp : ℚ) then some true
  else if A.tau + A.hA * (t : ℚ) ≤ -(μ1 - μ0) + A.hA * (km : ℚ) then some false
  else none

theorem edgeTest_toBits (A : AdaParams) (st : AdaState) (mus : List ℚ) (j : ℕ) :
    (edgeTest A st mus j).toBits (adaDraw A) =
      (adaDraw A NoiseKind.intTest).bind fun kp => (adaDraw A NoiseKind.intTest).bind fun km =>
        BitProg.pure (edgeDec A (st.thrInt.getD j 0) (mus.getD j 0) (mus.getD (j + 1) 0) kp km) := by
  unfold edgeTest
  rw [toBits_bind, toBits_drawNoise]
  congr 1

/-- **The edge comparisons in integers**: with `τ = τn/τd`, `h_A = 1/H`, `μ0 = N0/D0`, `μ1 = N1/D1`
(positive denominators), `τ + h_A t ≤ ±(μ1 − μ0) + h_A k` iff
`τn H D0 D1 + t τd D0 D1 ≤ ±((N1 D0 − N0 D1) τd H) + k τd D0 D1`. -/
theorem edge_test_iff {τ hA μ0 μ1 : ℚ} {τn τd H N0 D0 N1 D1 : ℤ} (t k : ℤ)
    (hτ : τ = τn / τd) (hhA : hA = 1 / H) (h0 : μ0 = N0 / D0) (h1 : μ1 = N1 / D1)
    (hτd : 0 < τd) (hH : 0 < H) (hD0 : 0 < D0) (hD1 : 0 < D1) :
    (τ + hA * t ≤ (μ1 - μ0) + hA * k ↔
      τn * H * D0 * D1 + t * τd * D0 * D1 ≤ (N1 * D0 - N0 * D1) * τd * H + k * τd * D0 * D1) ∧
    (τ + hA * t ≤ -(μ1 - μ0) + hA * k ↔
      τn * H * D0 * D1 + t * τd * D0 * D1 ≤ -((N1 * D0 - N0 * D1) * τd * H) + k * τd * D0 * D1) := by
  subst hτ hhA h0 h1
  have hτd' : (0 : ℚ) < τd := by exact_mod_cast hτd
  have hH' : (0 : ℚ) < H := by exact_mod_cast hH
  have hD0' : (0 : ℚ) < D0 := by exact_mod_cast hD0
  have hD1' : (0 : ℚ) < D1 := by exact_mod_cast hD1
  have hK : (0 : ℚ) < τd * H * D0 * D1 := by positivity
  have eL : ((τn : ℚ) / τd + 1 / (H : ℚ) * t) * (τd * H * D0 * D1) =
      ((τn * H * D0 * D1 + t * τd * D0 * D1 : ℤ) : ℚ) := by
    push_cast
    field_simp
  have eR1 : ((N1 : ℚ) / D1 - (N0 : ℚ) / D0 + 1 / (H : ℚ) * k) * (τd * H * D0 * D1) =
      (((N1 * D0 - N0 * D1) * τd * H + k * τd * D0 * D1 : ℤ) : ℚ) := by
    push_cast
    field_simp
  have eR2 : (-((N1 : ℚ) / D1 - (N0 : ℚ) / D0) + 1 / (H : ℚ) * k) * (τd * H * D0 * D1) =
      ((-((N1 * D0 - N0 * D1) * τd * H) + k * τd * D0 * D1 : ℤ) : ℚ) := by
    push_cast
    field_simp
  constructor
  · rw [← mul_le_mul_iff_of_pos_right hK, eL, eR1]
    exact Int.cast_le
  · rw [← mul_le_mul_iff_of_pos_right hK, eL, eR2]
    exact Int.cast_le

/-! ## The threshold redraws of a correction -/

theorem redraw_nil (A : AdaParams) (thr : List ℤ) :
    redrawThresholds A [] thr = DrawProg.ret thr := rfl

theorem redraw_append (A : AdaParams) :
    ∀ (es₁ es₂ : List ℕ) (thr : List ℤ),
      redrawThresholds A (es₁ ++ es₂) thr = (redrawThresholds A es₁ thr).bind (redrawThresholds A es₂)
  | [], _, _ => rfl
  | e :: es₁, es₂, thr => by
    show (drawNoise NoiseKind.intThr).bind (fun k => redrawThresholds A (es₁ ++ es₂) (thr.set e k)) =
      ((drawNoise NoiseKind.intThr).bind fun k => redrawThresholds A es₁ (thr.set e k)).bind
        (redrawThresholds A es₂)
    rw [DrawProg.bind_assoc]
    congr 1
    funext k
    exact redraw_append A es₁ es₂ (thr.set e k)

/-- One redraw: a fresh threshold of kind `intThr` at edge `e`. -/
def thrStep (A : AdaParams) (e : ℕ) (thr : List ℤ) : BitProg (List ℤ) :=
  (adaDraw A NoiseKind.intThr).bind fun k => BitProg.pure (thr.set e k)

/-- A conditional redraw. -/
def thrStepIf (A : AdaParams) (c : Bool) (e : ℕ) (thr : List ℤ) : BitProg (List ℤ) :=
  if c = true then thrStep A e thr else BitProg.pure thr

theorem redraw_single_toBits (A : AdaParams) (e : ℕ) (thr : List ℤ) :
    (redrawThresholds A [e] thr).toBits (adaDraw A) = thrStep A e thr := by
  show ((drawNoise NoiseKind.intThr).bind fun k => DrawProg.ret (thr.set e k)).toBits (adaDraw A) = _
  rw [toBits_bind, toBits_drawNoise]
  rfl

/-- **The redraws of a correction on edge `j`**: `j − 1` (if `j ≥ 1`), `j`, `j + 1` (if `j + 1 < p`). -/
theorem redraw_reopen_toBits (A : AdaParams) (j : ℕ) (thr : List ℤ) :
    (redrawThresholds A (reopenEdges A j) thr).toBits (adaDraw A) =
      (thrStepIf A (decide (1 ≤ j)) (j - 1) thr).bind fun thr₁ =>
        (thrStep A j thr₁).bind fun thr₂ => thrStepIf A (decide (j + 1 < A.p)) (j + 1) thr₂ := by
  unfold reopenEdges
  rw [redraw_append, toBits_bind, redraw_append, toBits_bind]
  have hA : ∀ (thr' : List ℤ), ((redrawThresholds A ((if 1 ≤ j then [j - 1] else []) : List ℕ)
      thr').toBits (adaDraw A)) = thrStepIf A (decide (1 ≤ j)) (j - 1) thr' := by
    intro thr'
    unfold thrStepIf
    split_ifs with h1 h2 h2
    · exact redraw_single_toBits A (j - 1) thr'
    · simp at h2; omega
    · simp at h2; omega
    · rfl
  have hC : ∀ (thr' : List ℤ), ((redrawThresholds A ((if j + 1 < A.p then [j + 1] else []) : List ℕ)
      thr').toBits (adaDraw A)) = thrStepIf A (decide (j + 1 < A.p)) (j + 1) thr' := by
    intro thr'
    unfold thrStepIf
    split_ifs with h1 h2 h2
    · exact redraw_single_toBits A (j + 1) thr'
    · simp at h2; omega
    · simp at h2; omega
    · rfl
  rw [hA, bitProg_bind_assoc]
  congr 1
  funext thr₁
  rw [redraw_single_toBits]
  congr 1
  funext thr₂
  exact hC thr₂

/-- **A correction in fresh bits**: the redraws, then the pure update `avState`. -/
theorem applyCorrection_toBits (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ)
    (q : Bool) : (applyCorrection A st vals j q).toBits (adaDraw A) =
      ((redrawThresholds A (reopenEdges A j) st.thrInt).toBits (adaDraw A)).bind fun thr =>
        BitProg.pure (avState A st vals j q thr) := by
  rw [applyCorrection_eq_avState, toBits_bind]
  rfl

/-! ## One iteration of a scan pass -/

/-- The cache after a correction on edge `j`: the reopened edges are invalidated. -/
def resetCache (A : AdaParams) (j : ℕ) (cache : List Bool) : List Bool :=
  (reopenEdges A j).foldl (fun c e => c.set e false) cache

/-- The rest of a scan pass from edge `j` (state `(j, st, cache)`), in fresh bits, for the
predictions `mus` of the pass. -/
def scanRef (A : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) (s : ℕ × AdaState × List Bool) :
    BitProg (PassOut × AdaState × List Bool) :=
  (scanPass A vals mus (List.range' s.1 (A.p - s.1)) s.2.1 s.2.2).toBits (adaDraw A)

/-- One iteration of a scan pass: continue with the next edge, or stop with the pass outcome. -/
def scanQ (A : AdaParams) (vals : List (List ℕ)) (mus : List ℚ) (s : ℕ × AdaState × List Bool) :
    BitProg ((ℕ × AdaState × List Bool) ⊕ (PassOut × AdaState × List Bool)) :=
  if s.1 < A.p then
    if s.2.2.getD s.1 false = true then BitProg.pure (Sum.inl (s.1 + 1, s.2.1, s.2.2))
    else ((edgeTest A s.2.1 mus s.1).toBits (adaDraw A)).bind fun r =>
      match r with
      | none => BitProg.pure (Sum.inl (s.1 + 1, s.2.1, s.2.2.set s.1 true))
      | some q =>
        if A.Tmax.getD s.1 0 ≤ s.2.1.T.getD s.1 0 then
          BitProg.pure (Sum.inr (PassOut.abort, s.2.1, s.2.2))
        else ((applyCorrection A s.2.1 vals s.1 q).toBits (adaDraw A)).bind fun st' =>
          BitProg.pure (Sum.inr (PassOut.corrected, st', resetCache A s.1 s.2.2))
  else BitProg.pure (Sum.inr (PassOut.done, s.2.1, s.2.2))

theorem range'_succ_eq {j p : ℕ} (h : j < p) : List.range' j (p - j) = j :: List.range' (j + 1) (p - (j + 1)) := by
  rw [show p - j = (p - (j + 1)) + 1 by omega, List.range'_succ]

/-- **The scan pass unfolds by one iteration.** -/
theorem scanRef_unfold (A : AdaParams) (vals : List (List ℕ)) (mus : List ℚ)
    (s : ℕ × AdaState × List Bool) :
    scanRef A vals mus s = (scanQ A vals mus s).bind (Sum.elim (scanRef A vals mus) BitProg.pure) := by
  obtain ⟨j, st, cache⟩ := s
  unfold scanRef scanQ
  dsimp only
  by_cases hj : j < A.p
  · rw [if_pos hj, range'_succ_eq hj, scanPass]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc, if_pos hc]
      rfl
    · rw [if_neg hc, if_neg hc, toBits_bind, bitProg_bind_assoc]
      congr 1
      funext r
      cases r with
      | none => rfl
      | some q =>
        dsimp only
        by_cases hcap : A.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hcap, if_pos hcap]
          rfl
        · rw [if_neg hcap, if_neg hcap, toBits_bind, bitProg_bind_assoc]
          rfl
  · rw [if_neg hj, show A.p - j = 0 by omega]
    rfl

/-! ## One iteration of `PrepareRoot` -/

/-- `PrepareRoot` from the state `(f, st, cache)` in fresh bits. -/
def prepRef (A : AdaParams) (vals : List (List ℕ)) (s : ℕ × AdaState × List Bool) :
    BitProg (Option AdaState) :=
  (prepareRoot A vals s.1 s.2.1 s.2.2).toBits (adaDraw A)

/-- The outcome of a pass, as a loop step. -/
def passOutcome (f : ℕ) (r : PassOut × AdaState × List Bool) :
    (ℕ × AdaState × List Bool) ⊕ Option AdaState :=
  match r.1 with
  | PassOut.done => Sum.inr (some r.2.1)
  | PassOut.corrected => Sum.inl (f, r.2.1, r.2.2)
  | PassOut.abort => Sum.inr none

/-- One iteration of `PrepareRoot`: no fuel left, or one scan pass. -/
def prepQ (A : AdaParams) (vals : List (List ℕ)) (s : ℕ × AdaState × List Bool) :
    BitProg ((ℕ × AdaState × List Bool) ⊕ Option AdaState) :=
  match s.1 with
  | 0 => BitProg.pure (Sum.inr none)
  | f + 1 => (scanRef A vals (adaMus A s.2.1 vals) (0, s.2.1, s.2.2)).map (passOutcome f)

/-- **`PrepareRoot` unfolds by one iteration.** -/
theorem prepRef_unfold (A : AdaParams) (vals : List (List ℕ)) (s : ℕ × AdaState × List Bool) :
    prepRef A vals s = (prepQ A vals s).bind (Sum.elim (prepRef A vals) BitProg.pure) := by
  obtain ⟨f, st, cache⟩ := s
  cases f with
  | zero => rfl
  | succ f =>
    unfold prepRef prepQ scanRef
    dsimp only
    rw [prepareRoot, toBits_bind, Nat.sub_zero, ← List.range_eq_range', BitProg.map,
      bitProg_bind_assoc]
    congr 1
    funext r
    obtain ⟨o, st1, c1⟩ := r
    cases o <;> rfl

end F2e2e.C.Impl
