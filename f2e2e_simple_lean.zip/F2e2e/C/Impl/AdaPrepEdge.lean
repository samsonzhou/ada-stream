import F2e2e.C.Impl.AdaPrepRef

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 2: the edge test `adaEdge` (Idx 701, B-NUM)

`adaEdge : [pub, t, N0, D0, N1, D1] ↦ obZ r` (`r : Option Bool`, `none ↦ 0`, `some true ↦ 1`,
`some false ↦ 2`): two fresh noises `kp, km` of kind `intTest`, then the decision `edgeDec A t μ0 μ1 kp km`
with `μ0 = N0/D0`, `μ1 = N1/D1`, compared in integers (`edge_test_iff`):
`L = τn H D0 D1 + t τd D0 D1`, `G = (N1 D0 − N0 D1) τd H`, `P = kp τd D0 D1`, `Q = km τd D0 D1`;
`1` if `L ≤ G + P`, else `2` if `L ≤ Q − G`, else `0`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- `Option Bool` as an integer: `none ↦ 0`, `some true ↦ 1`, `some false ↦ 2`. -/
def obZ : Option Bool → ℤ
  | none => 0
  | some true => 1
  | some false => 2

/-- The encoding of an edge-test outcome. -/
def encOB (r : Option Bool) : Val := Val.int (obZ r)

/-- The integer edge decision, with leaves in the environment `[km, kp, x]`,
`x = [pub, t, N0, D0, N1, D1]`. -/
def edgeZE (km kp t N0 D0 N1 D1 τn τd H : ℤ) : ZE :=
  ZE.cnd
    (ZE.lt
      (ZE.add
        (ZE.mul (ZE.mul (ZE.sub (ZE.mul (ZE.leaf (eAtN 4 (eV 2)) N1) (ZE.leaf (eAtN 3 (eV 2)) D0))
          (ZE.mul (ZE.leaf (eAtN 2 (eV 2)) N0) (ZE.leaf (eAtN 5 (eV 2)) D1)))
          (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd)) (ZE.leaf (eAtN 8 (eAtN 0 (eV 2))) H))
        (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eV 1) kp) (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd))
          (ZE.leaf (eAtN 3 (eV 2)) D0)) (ZE.leaf (eAtN 5 (eV 2)) D1)))
      (ZE.add
        (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 0 (eAtN 9 (eAtN 0 (eV 2)))) τn)
          (ZE.leaf (eAtN 8 (eAtN 0 (eV 2))) H)) (ZE.leaf (eAtN 3 (eV 2)) D0))
          (ZE.leaf (eAtN 5 (eV 2)) D1))
        (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 1 (eV 2)) t)
          (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd)) (ZE.leaf (eAtN 3 (eV 2)) D0))
          (ZE.leaf (eAtN 5 (eV 2)) D1))))
    (ZE.cnd
      (ZE.lt
        (ZE.sub
          (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eV 0) km) (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd))
            (ZE.leaf (eAtN 3 (eV 2)) D0)) (ZE.leaf (eAtN 5 (eV 2)) D1))
          (ZE.mul (ZE.mul (ZE.sub (ZE.mul (ZE.leaf (eAtN 4 (eV 2)) N1) (ZE.leaf (eAtN 3 (eV 2)) D0))
            (ZE.mul (ZE.leaf (eAtN 2 (eV 2)) N0) (ZE.leaf (eAtN 5 (eV 2)) D1)))
            (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd)) (ZE.leaf (eAtN 8 (eAtN 0 (eV 2))) H)))
        (ZE.add
          (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 0 (eAtN 9 (eAtN 0 (eV 2)))) τn)
            (ZE.leaf (eAtN 8 (eAtN 0 (eV 2))) H)) (ZE.leaf (eAtN 3 (eV 2)) D0))
            (ZE.leaf (eAtN 5 (eV 2)) D1))
          (ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 1 (eV 2)) t)
            (ZE.leaf (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))) τd)) (ZE.leaf (eAtN 3 (eV 2)) D0))
            (ZE.leaf (eAtN 5 (eV 2)) D1))))
      (ZE.lit 0) (ZE.lit 2))
    (ZE.lit 1)

/-- **`adaEdge`** (Idx 701). -/
def body_adaEdge : Expr :=
  eLet (eDraw NoiseKind.intTest (eAtN 0 (eV 0)))
    (eLet (eDraw NoiseKind.intTest (eAtN 0 (eV 1)))
      (edgeZE 0 0 0 0 0 0 0 0 0 0).toExpr)

theorem edgeZE_toExpr (km kp t N0 D0 N1 D1 τn τd H : ℤ) :
    (edgeZE km kp t N0 D0 N1 D1 τn τd H).toExpr = (edgeZE 0 0 0 0 0 0 0 0 0 0).toExpr := rfl

/-- The value of a conditional on a comparison. -/
theorem ap_ZE_cnd_lt_val (a b t f : ZE) :
    (ZE.cnd (ZE.lt a b) t f).val = if a.val < b.val then t.val else f.val := by
  simp only [ZE.val]
  by_cases h : a.val < b.val <;> simp [h]

theorem edgeZE_val (km kp t N0 D0 N1 D1 τn τd H : ℤ) :
    (edgeZE km kp t N0 D0 N1 D1 τn τd H).val =
      if (N1 * D0 - N0 * D1) * τd * H + kp * τd * D0 * D1 < τn * H * D0 * D1 + t * τd * D0 * D1 then
        (if km * τd * D0 * D1 - (N1 * D0 - N0 * D1) * τd * H < τn * H * D0 * D1 + t * τd * D0 * D1
          then 0 else 2)
      else 1 := by
  unfold edgeZE
  rw [ap_ZE_cnd_lt_val, ap_ZE_cnd_lt_val]
  rfl

theorem edgeZE_cb (km kp t N0 D0 N1 D1 τn τd H : ℤ) (W : ℕ) :
    (edgeZE km kp t N0 D0 N1 D1 τn τd H).cb W = 36 * W + 11 := by
  simp only [edgeZE, ZE.cb]
  have h0 : bitLen 0 = 0 := by decide
  have h1 : bitLen 1 = 1 := by decide
  have h2 : bitLen 2 = 2 := by decide
  rw [h0, h1, h2]
  ring

/-- **The integer decision is the edge test.** -/
theorem obZ_edgeDec (A : AdaParams) {t N0 D0 N1 D1 kp km : ℤ} (hD0 : 0 < D0) (hD1 : 0 < D1) :
    obZ (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km) =
      (edgeZE km kp t N0 D0 N1 D1 A.tau.num (A.tau.den : ℤ) ((2 ^ A.qA : ℕ) : ℤ)).val := by
  have hτd : (0 : ℤ) < (A.tau.den : ℤ) := by exact_mod_cast A.tau.den_pos
  have hH : (0 : ℤ) < ((2 ^ A.qA : ℕ) : ℤ) := by positivity
  have hτ : A.tau = (A.tau.num : ℚ) / ((A.tau.den : ℤ) : ℚ) := by
    rw [Int.cast_natCast]; exact (Rat.num_div_den A.tau).symm
  have hhA : A.hA = 1 / ((((2 ^ A.qA : ℕ) : ℤ)) : ℚ) := by
    rw [Int.cast_natCast, AdaParams.hA, one_div_pow]
    push_cast
    rfl
  obtain ⟨i1, i2⟩ := edge_test_iff t kp hτ hhA rfl rfl hτd hH hD0 hD1
  obtain ⟨-, i3⟩ := edge_test_iff t km hτ hhA rfl rfl hτd hH hD0 hD1
  rw [edgeZE_val]
  unfold edgeDec
  by_cases c1 : A.tau + A.hA * (t : ℚ) ≤ ((N1 : ℚ) / D1 - (N0 : ℚ) / D0) + A.hA * (kp : ℚ)
  · rw [if_pos c1, if_neg (not_lt.mpr (i1.mp c1))]
    rfl
  · rw [if_neg c1, if_pos (lt_of_not_ge (fun h => c1 (i1.mpr h)))]
    by_cases c2 : A.tau + A.hA * (t : ℚ) ≤ -((N1 : ℚ) / D1 - (N0 : ℚ) / D0) + A.hA * (km : ℚ)
    · have h3 := i3.mp c2
      rw [if_pos c2, if_neg (by
        intro h
        have : km * (A.tau.den : ℤ) * D0 * D1 - (N1 * D0 - N0 * D1) * (A.tau.den : ℤ) *
            ((2 ^ A.qA : ℕ) : ℤ) =
          -((N1 * D0 - N0 * D1) * (A.tau.den : ℤ) * ((2 ^ A.qA : ℕ) : ℤ)) +
            km * (A.tau.den : ℤ) * D0 * D1 := by ring
        rw [this] at h
        exact absurd h3 (not_le.mpr h))]
      rfl
    · rw [if_neg c2, if_pos (by
        have h3 : ¬ _ := fun h => c2 (i3.mpr h)
        have : km * (A.tau.den : ℤ) * D0 * D1 - (N1 * D0 - N0 * D1) * (A.tau.den : ℤ) *
            ((2 ^ A.qA : ℕ) : ℤ) =
          -((N1 * D0 - N0 * D1) * (A.tau.den : ℤ) * ((2 ^ A.qA : ℕ) : ℤ)) +
            km * (A.tau.den : ℤ) * D0 * D1 := by ring
        rw [this]
        exact lt_of_not_ge h3)]
      rfl

section Edge

variable {prog : List Expr} {M : ℕ}

/-- The bit width of the edge test's operands. -/
def edgeW (A : AdaParams) : ℕ := 2 ^ 6 * (adaZ A + 16)

theorem ap_draw_support (A : AdaParams) (κ : NoiseKind) :
    ∀ bits k, (adaDraw A κ).run bits = some (k, []) → |k| ≤ (maxKs A : ℤ) :=
  fun _ _ h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ)

theorem ap_bitLen_le_edgeW_of_abs {A : AdaParams} {z : ℤ} (h : |z| ≤ (maxKs A : ℤ)) :
    bitLen z ≤ edgeW A := by
  have h1 := bitLen_le_size_of_abs_le h
  have h2 := size_maxKs_le_adaZ A
  unfold edgeW
  omega

/-- **Spec of `adaEdge`.** -/
theorem adaEdge_impl (hS : SampLib prog) {A : AdaParams} {t N0 D0 N1 D1 : ℤ}
    (hD0 : 0 < D0) (hD1 : 0 < D1) (ht : |t| ≤ (maxKs A : ℤ))
    (hN0 : bitLen N0 ≤ edgeW A) (hD0b : bitLen D0 ≤ edgeW A) (hN1 : bitLen N1 ≤ edgeW A)
    (hD1b : bitLen D1 ≤ edgeW A) (hpubB : valSize (adaPubEnc A) ≤ adaBoundA A)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1,
        Val.int D1]] body_adaEdge encOB
      ((adaDraw A NoiseKind.intTest).bind fun kp => (adaDraw A NoiseKind.intTest).bind fun km =>
        BitProg.pure (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km)) := by
  have hZ16 := sixteen_le_adaZ A
  have hB : 2 ^ 14 * (adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    calc 2 ^ 14 * (adaZ A + 16) = 2 ^ 10 * 16 * (adaZ A + 16) := by ring
      _ ≤ 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (by omega))
  have hBM : adaBoundA A ≤ M := le_trans (Nat.le_mul_of_pos_left _ (by positivity)) hM
  set x : Val := Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1, Val.int D1]
    with hx
  have htW : bitLen t ≤ edgeW A := ap_bitLen_le_edgeW_of_abs ht
  have hW : edgeW A ≤ 2 ^ 6 * (adaZ A + 16) := le_rfl
  have hxM : valSize x ≤ 2 * adaBoundA A := by
    simp only [hx, valSize_list, listSize_cons, listSize_nil, valSize_int]
    unfold edgeW at htW hN0 hD0b hN1 hD1b
    omega
  have hxM' : valSize x ≤ M := by omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : drawM A NoiseKind.intTest ≤ M := by
    have := drawM_le A NoiseKind.intTest
    omega
  rw [adaPubEnc_eq] at hpubM
  -- the first draw
  have hpub0 : EvalsVal prog M [x] [] (.inl (eAtN 0 (eV 0))) (adaPubEnc A) :=
    evalsVal_atN' EvalsVal.var0 hxM' rfl
  refine implements_letE_of (draw_impl hS hpub0 (by rw [adaPubEnc_eq]; exact hpubM)
    NoiseKind.intTest hdraw) (fun k => |k| ≤ (maxKs A : ℤ)) (ap_draw_support A _) ?_
  intro kp hkp
  have hpub1 : EvalsVal prog M [encZ kp, x] [] (.inl (eAtN 0 (eV 1))) (adaPubEnc A) :=
    evalsVal_atN' EvalsVal.var1 hxM' rfl
  refine implements_letE_of (draw_impl hS hpub1 (by rw [adaPubEnc_eq]; exact hpubM)
    NoiseKind.intTest hdraw) (fun k => |k| ≤ (maxKs A : ℤ)) (ap_draw_support A _) ?_
  intro km hkm
  apply Implements.of_det
  show EvalsVal prog M [encZ km, encZ kp, x] [] (.inl (edgeZE 0 0 0 0 0 0 0 0 0 0).toExpr)
    (encOB (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km))
  rw [← edgeZE_toExpr km kp t N0 D0 N1 D1 A.tau.num (A.tau.den : ℤ) ((2 ^ A.qA : ℕ) : ℤ)]
  unfold encOB
  rw [obZ_edgeDec A hD0 hD1]
  -- leaves
  set env : List Val := [encZ km, encZ kp, x] with henv
  have hX : EvalsVal prog M env [] (.inl (eV 2)) x := EvalsVal.var2
  have lkm : EvalsVal prog M env [] (.inl (eV 0)) (Val.int km) := EvalsVal.var0
  have lkp : EvalsVal prog M env [] (.inl (eV 1)) (Val.int kp) := EvalsVal.var1
  have lt' : EvalsVal prog M env [] (.inl (eAtN 1 (eV 2))) (Val.int t) := evalsVal_atN' hX hxM' rfl
  have lN0 : EvalsVal prog M env [] (.inl (eAtN 2 (eV 2))) (Val.int N0) := evalsVal_atN' hX hxM' rfl
  have lD0 : EvalsVal prog M env [] (.inl (eAtN 3 (eV 2))) (Val.int D0) := evalsVal_atN' hX hxM' rfl
  have lN1 : EvalsVal prog M env [] (.inl (eAtN 4 (eV 2))) (Val.int N1) := evalsVal_atN' hX hxM' rfl
  have lD1 : EvalsVal prog M env [] (.inl (eAtN 5 (eV 2))) (Val.int D1) := evalsVal_atN' hX hxM' rfl
  have lpub : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (Val.list (pubFields A)) :=
    evalsVal_atN' hX hxM' rfl
  have hτM : valSize (encQ A.tau) ≤ M :=
    le_trans (valSize_le_of_getElem? (l := pubFields A) (n := 9) rfl) hpubM
  have lτ : EvalsVal prog M env [] (.inl (eAtN 9 (eAtN 0 (eV 2)))) (encQ A.tau) :=
    evalsVal_atN' lpub hpubM rfl
  have lτn : EvalsVal prog M env [] (.inl (eAtN 0 (eAtN 9 (eAtN 0 (eV 2))))) (Val.int A.tau.num) :=
    evalsVal_atN' lτ hτM rfl
  have lτd : EvalsVal prog M env [] (.inl (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))))
      (Val.int (A.tau.den : ℤ)) := evalsVal_atN' lτ hτM rfl
  have lH : EvalsVal prog M env [] (.inl (eAtN 8 (eAtN 0 (eV 2)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_atN' lpub hpubM rfl
  -- bit widths
  have bkm : bitLen km ≤ edgeW A := ap_bitLen_le_edgeW_of_abs hkm
  have bkp : bitLen kp ≤ edgeW A := ap_bitLen_le_edgeW_of_abs hkp
  have bτn : bitLen A.tau.num ≤ edgeW A := by
    have := size_taunum_le_adaZ A
    unfold bitLen edgeW
    omega
  have bτd : bitLen (A.tau.den : ℤ) ≤ edgeW A := by
    have := size_tauden_le_adaZ A
    rw [bitLen_natCast]
    unfold edgeW
    omega
  have bH : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ edgeW A := by
    have := qA_le_adaZ A
    rw [bitLen_natCast, Nat.size_pow]
    unfold edgeW
    omega
  refine ZE.spec' (W := edgeW A) ?_ ?_ ?_
  · simp only [edgeZE, ZE.OK, lkm, lkp, lt', lN0, lD0, lN1, lD1, lτn, lτd, lH, and_self]
  · simp only [edgeZE, ZE.LeafLe, bkm, bkp, htW, hN0, hD0b, hN1, hD1b, bτn, bτd, bH, and_self]
  · rw [edgeZE_cb]
    have h1 : 36 * edgeW A + 11 + 1 ≤ adaBoundA A := by
      unfold edgeW
      linarith
    exact h1.trans hBM

end Edge

end F2e2e.C.Impl
