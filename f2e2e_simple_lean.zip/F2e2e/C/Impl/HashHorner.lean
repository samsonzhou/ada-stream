import F2e2e.C.Impl.HashGF
import F2e2e.Cost.Lib.RevAppend
import F2e2e.Cost.Space

/-!
# HASH area (DSL): Horner evaluation over `GF(2^q)`, sign bits and row signs

New routines (not in cut2) for the sign rows of Lemma `R:lem:2s-moment-bound`
(partIII.tex l. 13: `b_i(ζ) = (-1)^{lsb(∑_d ζ_d α_i^d)}`) and C-ALG's `F2e2e.C.Alg.rowSign`:

| index | body | input | output (reference) |
|---|---|---|---|
| 174/175 | `body_gfHorner` / step | `[q, p, cs, x]` | `encN (Hash.gfHorner q p cs x)` |
| 176 | `body_signBit` | `[q, p, cs, x]` | `encB (Hash.signBit q p cs x)` |
| 177 | `body_rowSign` | `[q, p, cs, x]` | `encZ (if Hash.signBit q p cs x then -1 else 1)` |

The coefficient list `cs` (constant term first, `encL encN cs`) is reversed by the list library's
`reverse` (index `Idx.reverse`), then the loop `gfHornerStep` runs Horner's rule from the highest
coefficient: state `[rest, acc, q, p, x]`, `acc ← gfMul q p acc x ^^^ c`. Every iteration is a
`loop` step (no recursion).

Specs are space-only (`EvalsSp`, `F2e2e/Cost/Space.lean`); they are obtained by symbolic evaluation
(`EvalsSp.of_eval'`) with the uniform evaluation equations of the callees (`uniform_of_sp`).
-/

namespace F2e2e.Cost.Idx

/-- `gfHorner : [q, p, cs, x] ↦ Hash.gfHorner q p cs x`. -/
abbrev gfHorner : ℕ := 174
abbrev gfHornerStep : ℕ := 175
/-- `signBit : [q, p, cs, x] ↦ encB (Hash.signBit q p cs x)`. -/
abbrev signBit : ℕ := 176
/-- `rowSign : [q, p, cs, x] ↦ ±1`. -/
abbrev rowSign : ℕ := 177

end F2e2e.Cost.Idx

namespace F2e2e.Cost.HashDSL

/-! ### Bodies -/

/-- Step of `gfHorner`; state `[rest, acc, q, p, x]` (`rest` = the remaining coefficients, highest
first): stop with `acc` when `rest = []`, else `[tail rest, gfMul q p acc x ^^^ head rest, q, p, x]`. -/
def body_gfHornerStep : Expr :=
  eLet (eHd (eV 0))                                   -- rest  [rest, S]
    (eIte (Expr.un UnOp.isNil (eV 0))
      (ePair (eLit 0) (eAt1 (eV 1)))
      (ePair (eLit 1)
        (eList [eTl (eV 0),
          eCall Idx.xorNat (ePair
            (eCall Idx.gfMul (eList [eAt2 (eV 1), eAt3 (eV 1), eAt1 (eV 1), eAt4 (eV 1)]))
            (eHd (eV 0))),
          eAt2 (eV 1), eAt3 (eV 1), eAt4 (eV 1)])))

/-- `gfHorner : [q, p, cs, x] ↦ Hash.gfHorner q p cs x`: reverse the coefficient list, then the
loop from `[cs.reverse, 0, q, p, x]`. -/
def body_gfHorner : Expr :=
  eLet (eCall Idx.reverse (eAt2 (eV 0)))              -- rev  [rev, X]
    (eLoop Idx.gfHornerStep (eList [eV 0, eLit 0, eHd (eV 1), eAt1 (eV 1), eAt3 (eV 1)]))

/-- `signBit : [q, p, cs, x] ↦ gfHorner q p cs x % 2` (bit `0` of the hash value). -/
def body_signBit : Expr := eMod (eCall Idx.gfHorner (eV 0)) (eLit 2)

/-- `rowSign : [q, p, cs, x] ↦ 1 - 2 · signBit` (`+1` or `-1`). -/
def body_rowSign : Expr := eSub (eLit 1) (eMul (eLit 2) (eCall Idx.signBit (eV 0)))

/-- A program containing the HASH area, the list library's `reverse`, and the Horner routines. -/
structure HornerLib (prog : List Expr) : Prop extends HashLib prog where
  reverse : prog[Idx.reverse]? = some body_reverse
  revAppendStep : prog[Idx.revAppendStep]? = some body_revAppendStep
  gfHorner : prog[Idx.gfHorner]? = some body_gfHorner
  gfHornerStep : prog[Idx.gfHornerStep]? = some body_gfHornerStep
  signBit : prog[Idx.signBit]? = some body_signBit
  rowSign : prog[Idx.rowSign]? = some body_rowSign

/-! ### Reference: Horner's rule on the reversed coefficient list -/

/-- Horner's rule from the highest coefficient: `hornerRev acc [c_{m-1}, …, c_0]`. -/
def hornerRev (q p x : ℕ) : ℕ → List ℕ → ℕ
  | acc, [] => acc
  | acc, c :: rest => hornerRev q p x (Hash.gfAdd (Hash.gfMul q p acc x) c) rest

theorem hornerRev_append (q p x : ℕ) (c : ℕ) :
    ∀ (l : List ℕ) (acc : ℕ),
      hornerRev q p x acc (l ++ [c]) = Hash.gfAdd (Hash.gfMul q p (hornerRev q p x acc l) x) c
  | [], _ => rfl
  | _ :: l, _ => hornerRev_append q p x c l _

theorem gfHorner_eq_hornerRev (q p x : ℕ) :
    ∀ cs : List ℕ, Hash.gfHorner q p cs x = hornerRev q p x 0 cs.reverse
  | [] => rfl
  | c :: cs => by
      rw [List.reverse_cons, hornerRev_append, ← gfHorner_eq_hornerRev q p x cs]
      rfl

/-! ### Space-only helpers -/

/-- Symbolic evaluation for the space-only judgment (the cost is the exact one). -/
theorem EvalsSp.of_eval' {prog : List Expr} {base : ℕ} {env : List Val} {e : Expr} {v : Val}
    {S : ℕ} (fuel : ℕ) (h : ∃ c p, eval prog fuel base env [] e = some (v, c, p, []) ∧ p ≤ S) :
    EvalsSp prog base env e v S := by
  obtain ⟨c, p, h, hp⟩ := h
  exact ⟨c, EvalsLe.of_eval fuel ⟨c, p, h, le_refl c, hp⟩⟩

/-- Uniform evaluation equation from a space-only spec. -/
theorem uniform_of_sp {prog : List Expr} {env : List Val} {e : Expr} {v : Val} {S : ℕ}
    (h : EvalsSp prog 0 env e v S) :
    ∃ f c p, p ≤ S ∧ ∀ m b, f ≤ m → ∀ tape : List Bool,
      eval prog m b env tape e = some (v, c, b + p, tape) := by
  obtain ⟨C, h⟩ := h
  obtain ⟨f, c, p, -, hp, hu⟩ := uniform_of_spec h
  exact ⟨f, c, p, hp, hu⟩

/-! ### The loop step -/

/-- Encoding of the `gfHorner` loop state `[rest, acc, q, p, x]`. -/
def encHS (rest : List ℕ) (acc q p x : ℕ) : Val :=
  Val.list [encL encN rest, encN acc, encN q, encN p, encN x]

theorem gfHornerStep_stop (prog : List Expr) (base acc q p x : ℕ) :
    EvalsSp prog base [encHS [] acc q p x] body_gfHornerStep (Val.list [Val.int 0, encN acc])
      (base + 4 * valSize (encHS [] acc q p x) + 20) := by
  apply EvalsSp.of_eval' 20
  simp only [encHS, encL, encN, List.map_nil, body_gfHornerStep, eLet, eHd, eAt1, eAt2, eAt3,
    eAt4, eTl, eIte, eV, eLit, eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

set_option maxHeartbeats 1000000 in
theorem gfHornerStep_cont {prog : List Expr} (hL : HornerLib prog) (base : ℕ) (c : ℕ)
    (rest : List ℕ) (acc q p x : ℕ) (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1))
    (hacc : acc < 2 ^ q) (hx : x < 2 ^ q) (hc : c < 2 ^ q) :
    EvalsSp prog base [encHS (c :: rest) acc q p x] body_gfHornerStep
      (Val.list [Val.int 1, encHS rest (Hash.gfAdd (Hash.gfMul q p acc x) c) q p x])
      (base + 6 * valSize (encHS (c :: rest) acc q p x) + 6 * q + S_gfMul q + S_xorNat q +
        100) := by
  have hg : Hash.gfMul q p acc x < 2 ^ q := Hash.gfMul_lt' hp1 hp2 acc x
  have hgx : Hash.gfMul q p acc x ^^^ c < 2 ^ q := Nat.xor_lt_two_pow hg hc
  obtain ⟨f1, c1, p1, hp1', hu1⟩ :=
    uniform_of_sp (gfMul_spec hL.toHashLib q p acc x hp1 hp2 hacc hx 0).toSp
  obtain ⟨f2, c2, p2, hp2', hu2⟩ :=
    uniform_of_sp (xorNat_spec hL.xorNatStep (Hash.gfMul q p acc x) c q hg hc 0).toSp
  simp only [encN, zero_add] at hu1 hu2 hp1' hp2'
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  have hbp : bitLen (p : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hp2
  have hba : bitLen (acc : ℤ) ≤ q := bitLen_nat_le_of_lt hacc
  have hbx : bitLen (x : ℤ) ≤ q := bitLen_nat_le_of_lt hx
  have hbc : bitLen (c : ℤ) ≤ q := bitLen_nat_le_of_lt hc
  have hbg : bitLen ((Hash.gfMul q p acc x : ℕ) : ℤ) ≤ q := bitLen_nat_le_of_lt hg
  have hbgx : bitLen ((Hash.gfMul q p acc x ^^^ c : ℕ) : ℤ) ≤ q := bitLen_nat_le_of_lt hgx
  apply EvalsSp.of_eval' (f1 + f2 + 40)
  simp (config := { maxSteps := 2000000 }) only [encHS, encL, encN, List.map_cons,
    body_gfHornerStep, eLet, eHd, eAt1, eAt2, eAt3,
    eAt4, eTl, eIte, eV, eLit, eList, eCons, ePair, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, not_true_eq_false, ↓reduceIte,
    hL.gfMul, hL.xorNat]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
    bitLen_zero, bitLen_one]
  omega

/-! ### The loop -/

/-- Space bound of the `gfHorner` loop, for remaining coefficient lists of size `≤ V`. -/
def S_hornerLoop (q V : ℕ) : ℕ := 7 * (V + 4 * q + 20) + 6 * q + S_gfMul q + S_xorNat q + 100

theorem valSize_encHS_le (rest : List ℕ) (acc q p x : ℕ) (hacc : acc < 2 ^ q)
    (hp2 : p < 2 ^ (q + 1)) (hx : x < 2 ^ q) :
    valSize (encHS rest acc q p x) ≤ valSize (encL encN rest) + 4 * q + 20 := by
  have h1 := bitLen_nat_le_of_lt hacc
  have h2 := bitLen_natCast_le q
  have h3 := bitLen_nat_le_of_lt hp2
  have h4 := bitLen_nat_le_of_lt hx
  simp only [encHS, valSize_list, listSize_cons, listSize_nil, encN, valSize_int]
  omega

theorem valSize_encL_cons_le (c : ℕ) (rest : List ℕ) :
    valSize (encL encN rest) ≤ valSize (encL encN (c :: rest)) := by
  simp only [encL, List.map_cons, valSize_list, listSize_cons]
  omega

theorem valSize_encL_reverse (cs : List ℕ) :
    valSize (encL encN cs.reverse) = valSize (encL encN cs) := by
  simp only [encL, valSize_list, List.map_reverse, listSize_reverse]

theorem gfHorner_loop {prog : List Expr} (hL : HornerLib prog) (q p x V base T : ℕ)
    (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1)) (hx : x < 2 ^ q) :
    ∀ s : List ℕ × ℕ, ((∀ c ∈ s.1, c < 2 ^ q) ∧ s.2 < 2 ^ q ∧ valSize (encL encN s.1) ≤ V ∧
        hornerRev q p x s.2 s.1 = T) →
      ∃ out, out = encN T ∧
        LoopSp prog base Idx.gfHornerStep (encHS s.1 s.2 q p x) out (base + S_hornerLoop q V) := by
  have key := LoopSp.of_measure (prog := prog) (base := base) hL.gfHornerStep
    (fun s : List ℕ × ℕ => encHS s.1 s.2 q p x)
    (fun s => (∀ c ∈ s.1, c < 2 ^ q) ∧ s.2 < 2 ^ q ∧ valSize (encL encN s.1) ≤ V ∧
      hornerRev q p x s.2 s.1 = T)
    (fun out => out = encN T) (fun s => s.1.length) (S := base + S_hornerLoop q V) ?_
  · intro s hs
    obtain ⟨out, h1, h2⟩ := key s hs
    exact ⟨out, h1, h2⟩
  · rintro ⟨rest, acc⟩ ⟨hcs, hacc, hV, hT⟩
    simp only at hcs hacc hV hT
    have hsz := valSize_encHS_le rest acc q p x hacc hp2 hx
    cases rest with
    | nil =>
      left
      refine ⟨encN acc, ?_, ?_⟩
      · refine (gfHornerStep_stop prog _ acc q p x).mono ?_
        simp only [S_hornerLoop]
        omega
      · simp only [hornerRev] at hT
        rw [hT]
    | cons c rest =>
      right
      have hc : c < 2 ^ q := hcs c List.mem_cons_self
      have hrest := valSize_encL_cons_le c rest
      refine ⟨1, (rest, Hash.gfAdd (Hash.gfMul q p acc x) c), one_ne_zero, ?_, ⟨?_, ?_, ?_, ?_⟩, ?_⟩
      · refine (gfHornerStep_cont hL _ c rest acc q p x hp1 hp2 hacc hx hc).mono ?_
        simp only [S_hornerLoop]
        omega
      · intro c' hc'
        exact hcs c' (List.mem_cons_of_mem c hc')
      · exact Nat.xor_lt_two_pow (Hash.gfMul_lt' hp1 hp2 acc x) hc
      · simp only
        omega
      · simpa only [hornerRev] using hT
      · simp

/-! ### Specs -/

/-- Space bound of `gfHorner` (on top of the base). -/
def S_gfHorner (q : ℕ) (cs : List ℕ) : ℕ :=
  12 * (valSize (encL encN cs) + 4 * q + 20) + S_hornerLoop q (valSize (encL encN cs)) + 200

/-- **Spec of `gfHorner`.** For a degree-`q` modulus `p`, coefficients and point in `[0, 2^q)`. -/
theorem gfHorner_spec {prog : List Expr} (hL : HornerLib prog) (q p : ℕ) (cs : List ℕ) (x : ℕ)
    (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1)) (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q)
    (base : ℕ) :
    EvalsSp prog base [Val.list [encN q, encN p, encL encN cs, encN x]] body_gfHorner
      (encN (Hash.gfHorner q p cs x)) (base + S_gfHorner q cs) := by
  set X := Val.list [encN q, encN p, encL encN cs, encN x] with hX
  obtain ⟨V, hV⟩ : ∃ V, valSize (encL encN cs) = V := ⟨_, rfl⟩
  have hXsz : valSize X ≤ V + 4 * q + 20 := by
    have h2 := bitLen_natCast_le q
    have h3 := bitLen_nat_le_of_lt hp2
    have h4 := bitLen_nat_le_of_lt hx
    rw [← hV]
    simp only [hX, valSize_list, listSize_cons, listSize_nil, encN, valSize_int]
    omega
  -- reverse the coefficient list
  have hrevV : Val.list ((cs.map encN).reverse) = encL encN cs.reverse := by
    simp only [encL, List.map_reverse]
  have hrevsz : valSize (encL encN cs.reverse) = V := (valSize_encL_reverse cs).trans hV
  have h1 : EvalsSp prog base [X] (eCall Idx.reverse (eAt2 (eV 0))) (encL encN cs.reverse)
      (max (base + 2 * valSize X) (base + valSize (encL encN cs) + S_reverse (cs.map encN))) := by
    have ha := (evals_at2 (prog := prog) (base := base) (env := [X]) (i := 0)
      (x0 := encN q) (x1 := encN p) (x2 := encL encN cs) (l := [encN x]) rfl).toSp
    have hb := (reverse_spec hL.revAppendStep (cs.map encN) (base + valSize (encL encN cs))).toSp
    rw [hrevV] at hb
    exact EvalsSp.call ha hL.reverse hb
  -- the loop
  obtain ⟨out, hout, hloop⟩ := gfHorner_loop hL q p x V (base + valSize (encL encN cs.reverse))
    (hornerRev q p x 0 cs.reverse) hp1 hp2 hx (cs.reverse, 0)
    ⟨fun c hc => hcs c (List.mem_reverse.mp hc), Nat.two_pow_pos q, by rw [hrevsz], rfl⟩
  subst hout
  have h2 : EvalsSp prog (base + valSize (encL encN cs.reverse)) [encL encN cs.reverse, X]
      (eList [eV 0, eLit 0, eHd (eV 1), eAt1 (eV 1), eAt3 (eV 1)])
      (encHS cs.reverse 0 q p x)
      (base + valSize (encL encN cs.reverse) + 4 * (valSize (encL encN cs.reverse) + valSize X) +
        40) := by
    apply EvalsSp.of_eval' 20
    simp only [hX, encHS, eList, eCons, eHd, eAt1, eAt3, eTl, eV, eLit, eval_succ_var,
      eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, evalBin, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ]
    refine ⟨_, _, rfl, ?_⟩
    simp only [encN, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_zero]
    omega
  have h3 := EvalsSp.letE h1 (EvalsSp.loop h2 hloop)
  rw [gfHorner_eq_hornerRev]
  refine h3.mono ?_
  have hrs : valSize (Val.list (cs.map encN)) = V := hV
  simp only [S_gfHorner, S_reverse, max_le_iff, hrevsz, hV, hrs]
  omega

/-- **Spec of `call Idx.gfHorner`.** -/
theorem gfHorner_call {prog : List Expr} (hL : HornerLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {q p : ℕ} {cs : List ℕ} {x : ℕ} (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1))
    (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q) {Se : ℕ}
    (he : EvalsSp prog base env e (Val.list [encN q, encN p, encL encN cs, encN x]) Se) :
    EvalsSp prog base env (Expr.call Idx.gfHorner e) (encN (Hash.gfHorner q p cs x))
      (max Se (base + valSize (Val.list [encN q, encN p, encL encN cs, encN x]) +
        S_gfHorner q cs)) :=
  EvalsSp.call he hL.gfHorner (gfHorner_spec hL q p cs x hp1 hp2 hcs hx _)

theorem intCast_mod_two_eq (h : ℕ) : ((h : ℤ) % 2) = if h.testBit 0 then 1 else 0 := by
  rw [Nat.testBit_zero]
  rcases Nat.mod_two_eq_zero_or_one h with h0 | h1
  · have : ((h : ℤ) % 2) = 0 := by omega
    simp [h0, this]
  · have : ((h : ℤ) % 2) = 1 := by omega
    simp [h1, this]

/-- **Spec of `signBit`**: bit `0` of the Horner value, as `encB`. -/
theorem signBit_spec {prog : List Expr} (hL : HornerLib prog) (q p : ℕ) (cs : List ℕ) (x : ℕ)
    (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1)) (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q)
    (base : ℕ) :
    EvalsSp prog base [Val.list [encN q, encN p, encL encN cs, encN x]] body_signBit
      (encB (Hash.signBit q p cs x))
      (base + 2 * valSize (Val.list [encN q, encN p, encL encN cs, encN x]) + S_gfHorner q cs +
        4 * q + 20) := by
  set X := Val.list [encN q, encN p, encL encN cs, encN x] with hX
  have hg : Hash.gfHorner q p cs x < 2 ^ q := Hash.gfHorner_lt hp1 hp2 hcs x
  have hbg : bitLen ((Hash.gfHorner q p cs x : ℕ) : ℤ) ≤ q := bitLen_nat_le_of_lt hg
  have h1 := EvalsSp.mod
    (EvalsSp.call (EvalsSp.var (prog := prog) (base := base) (env := [X]) (i := 0) rfl)
      hL.gfHorner (gfHorner_spec hL q p cs x hp1 hp2 hcs hx (base + valSize X)))
    (EvalsSp.lit (prog := prog) (base := base + valSize (encN (Hash.gfHorner q p cs x)))
      (env := [X]) 2) (by norm_num)
  have hv : Val.int (((Hash.gfHorner q p cs x : ℕ) : ℤ) % 2) = encB (Hash.signBit q p cs x) := by
    rw [intCast_mod_two_eq]
    rfl
  rw [hv] at h1
  refine h1.mono ?_
  have hm2 : bitLen (((Hash.gfHorner q p cs x : ℕ) : ℤ) % 2) ≤ 1 := bitLen_emod_two_le _
  simp only [encN, valSize_int, max_le_iff]
  have : bitLen (2 : ℤ) = 2 := bitLen_two
  have hvs : valSize (encB (Hash.signBit q p cs x)) ≤ 2 := by
    cases Hash.signBit q p cs x <;> simp [encB, valSize_int, bitLen_zero, bitLen_one]
  omega

/-- **Spec of `call Idx.signBit`.** -/
theorem signBit_call {prog : List Expr} (hL : HornerLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {q p : ℕ} {cs : List ℕ} {x : ℕ} (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1))
    (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q) {Se : ℕ}
    (he : EvalsSp prog base env e (Val.list [encN q, encN p, encL encN cs, encN x]) Se) :
    EvalsSp prog base env (Expr.call Idx.signBit e) (encB (Hash.signBit q p cs x))
      (max Se (base + 3 * valSize (Val.list [encN q, encN p, encL encN cs, encN x]) +
        S_gfHorner q cs + 4 * q + 20)) := by
  refine (EvalsSp.call he hL.signBit (signBit_spec hL q p cs x hp1 hp2 hcs hx _)).mono ?_
  simp only [max_le_iff]
  omega

/-- **Spec of `rowSign`**: `+1` if the sign bit is `0`, `-1` if it is `1`
(`F2e2e.C.Alg.rowSign` with `q = w`, `p = irrW P`). -/
theorem rowSign_spec {prog : List Expr} (hL : HornerLib prog) (q p : ℕ) (cs : List ℕ) (x : ℕ)
    (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1)) (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q)
    (base : ℕ) :
    EvalsSp prog base [Val.list [encN q, encN p, encL encN cs, encN x]] body_rowSign
      (encZ (if Hash.signBit q p cs x then -1 else 1))
      (base + 3 * valSize (Val.list [encN q, encN p, encL encN cs, encN x]) + S_gfHorner q cs +
        4 * q + 60) := by
  set X := Val.list [encN q, encN p, encL encN cs, encN x] with hX
  have hs := signBit_spec hL q p cs x hp1 hp2 hcs hx
    (base + valSize (Val.int 1) + valSize (Val.int 2) + valSize X)
  have hc := EvalsSp.call (EvalsSp.var (prog := prog)
    (base := base + valSize (Val.int 1) + valSize (Val.int 2)) (env := [X]) (i := 0) rfl)
    hL.signBit hs
  have hb1 : bitLen (1 : ℤ) = 1 := by decide
  have hb2 : bitLen (2 : ℤ) = 2 := by decide
  cases hsb : Hash.signBit q p cs x
  · rw [hsb, encB_false] at hc
    have hm := EvalsSp.mul (EvalsSp.lit (prog := prog) (base := base + valSize (Val.int 1))
      (env := [X]) 2) hc
    have h1 := EvalsSp.sub (EvalsSp.lit (prog := prog) (base := base) (env := [X]) 1) hm
    have hv : Val.int (1 - 2 * 0) = encZ (if false = true then -1 else 1) := by simp [encZ]
    rw [hv] at h1
    refine h1.mono ?_
    have hb3 : bitLen ((2 : ℤ) * 0) = 0 := by decide
    have hXX : valSize (Val.list [encN q, encN p, encL encN cs, encN x]) = valSize X := rfl
    simp only [encZ, valSize_int, max_le_iff, hb1, hb2, hb3, bitLen_zero, Bool.false_eq_true,
      ↓reduceIte]
    omega
  · rw [hsb, encB_true] at hc
    have hm := EvalsSp.mul (EvalsSp.lit (prog := prog) (base := base + valSize (Val.int 1))
      (env := [X]) 2) hc
    have h1 := EvalsSp.sub (EvalsSp.lit (prog := prog) (base := base) (env := [X]) 1) hm
    have hv : Val.int (1 - 2 * 1) = encZ (if true = true then -1 else 1) := by simp [encZ]
    rw [hv] at h1
    refine h1.mono ?_
    have hb3 : bitLen ((2 : ℤ) * 1) = 2 := by decide
    have hXX : valSize (Val.list [encN q, encN p, encL encN cs, encN x]) = valSize X := rfl
    simp only [encZ, valSize_int, max_le_iff, hb1, hb2, hb3, ↓reduceIte, bitLen_neg]
    omega

/-- **Spec of `call Idx.rowSign`.** -/
theorem rowSign_call {prog : List Expr} (hL : HornerLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {q p : ℕ} {cs : List ℕ} {x : ℕ} (hp1 : 2 ^ q ≤ p) (hp2 : p < 2 ^ (q + 1))
    (hcs : ∀ c ∈ cs, c < 2 ^ q) (hx : x < 2 ^ q) {Se : ℕ}
    (he : EvalsSp prog base env e (Val.list [encN q, encN p, encL encN cs, encN x]) Se) :
    EvalsSp prog base env (Expr.call Idx.rowSign e)
      (encZ (if Hash.signBit q p cs x then -1 else 1))
      (max Se (base + 4 * valSize (Val.list [encN q, encN p, encL encN cs, encN x]) +
        S_gfHorner q cs + 4 * q + 60)) := by
  refine (EvalsSp.call he hL.rowSign (rowSign_spec hL q p cs x hp1 hp2 hcs hx _)).mono ?_
  simp only [max_le_iff]
  omega

end F2e2e.Cost.HashDSL
