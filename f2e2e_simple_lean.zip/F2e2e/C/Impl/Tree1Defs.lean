import F2e2e.C.Impl.W6Facts
import F2e2e.C.SpaceSteps
import F2e2e.Cost.Lib.BitFold
import F2e2e.Cost.Lib.MapIdx
import F2e2e.Cost.Lib.GetOpt
import F2e2e.Cost.Lib.TakeDrop
import F2e2e.Cost.Lib.Replicate
import F2e2e.Cost.Arith.Basic

/-!
# W6, Tree1: Step 1 of the round (C-ALG `step1`, `birthLoop`, `birthDepth`) — the DSL code

Owner: Tree1 worker (4a7299ed). Reference: `F2e2e/C/Alg/Round.lean` L60–116 (Algorithm
`R:alg:within-round-tree` Step 1, `parts/partIII.tex` L472–478): scheduled retirements (`take`) and
births of the depths `d₀, …, H − 1` (`birthLoop`/`birthDepth`), then the terminal accumulator `0`.

| idx | body | input | output (reference) |
|---|---|---|---|
| 290 | `body_step1` | `[p, encState s]` | `encState` of `step1 P s` |
| 291/292 | `body_firstBorn` / step | `[H, tr]` | `encN (firstBorn H tr)` |
| 293/294 | `body_birthLoop` / step | `[encState s, ds, ex]` (DSL-CALC `foldB`) | `birthLoop P d₀ ds s` |
| 295 | `body_birthElem` | `[d, encState s, ex]` | `if s.failed then s else birthDepth P d₀ d s` |
| 296 | `body_birthDepth` | `[d, encState s, ex]` | `birthDepth P d₀ d s` |
| 297/298/299 | `body_resetAt` / step / element | `[banks, [d, p]]` (DSL-CALC `mapIdx`) | `modifyAt (Bank.mapRows Row.resetY) d banks` |

`ex = [p, d₀, H, 2^{eHC}, eHP, 2^{eHP}]` (`exVal`), `p = encStreamParams P`. External routines: W1
`pH`, `peHC`, `peHP`; W3 `newBank`; W5 `resetYBank`, `release`, `roundMantQ`, `inRangeA`, `normQ`;
DSL-CALC `pow2`, `take`, `drop`, `range`, `append`, `set`, `getOpt`, `reverse`.
-/

namespace F2e2e.C.Impl.T1

open F2e2e F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

namespace Idx

/-- Step 1 (entry). -/
abbrev step1 : ℕ := 290
/-- `[H, tr] ↦ firstBorn H tr`. -/
abbrev firstBorn : ℕ := 291
/-- Loop body of `firstBorn`. -/
abbrev firstBornStep : ℕ := 292
/-- The birth loop (DSL-CALC `foldB`). -/
abbrev birthLoop : ℕ := 293
/-- Loop body of the birth loop. -/
abbrev birthLoopStep : ℕ := 294
/-- Element routine of the birth loop (failure check, then one birth). -/
abbrev birthElem : ℕ := 295
/-- One birth. -/
abbrev birthDepth : ℕ := 296
/-- The reset of the incoming secondary arrays (DSL-CALC `mapIdx`). -/
abbrev resetAt : ℕ := 297
/-- Loop body of `resetAt`. -/
abbrev resetAtStep : ℕ := 298
/-- Element routine of `resetAt`. -/
abbrev resetAtElem : ℕ := 299

end Idx

/-! ## Values -/

/-- The fixed data of the birth loop: `[p, d₀, H, 2^{eHC}, eHP, 2^{eHP}]`. -/
def exVal (P : StreamParams) (d0 : ℕ) : Val :=
  Val.list [encStreamParams P, encN d0, encN P.H, encN (2 ^ P.eHC), encN P.eHP, encN (2 ^ P.eHP)]

/-! ## Bodies -/

/-- Loop body of `firstBorn`; accumulator `[d, H, tr]`: `d < H` and `2^{H-1-d} ∣ tr - 1` ⇒ stop with
`d`; `d < H` otherwise ⇒ continue with `d + 1`; `d ≥ H` ⇒ stop with `d`. -/
def body_firstBornStep : Expr :=
  Expr.letE (eGet 0 (Expr.var 0))                                         -- d   [d, acc]
    (Expr.ite (Expr.bin BinOp.lt (Expr.var 0) (eGet 1 (Expr.var 1)))
      (Expr.ite (Expr.bin BinOp.eq
          (Expr.bin BinOp.mod (Expr.bin BinOp.sub (eGet 2 (Expr.var 1)) (Expr.lit 1))
            (Expr.call F2e2e.Cost.Idx.pow2
              (Expr.bin BinOp.sub (Expr.bin BinOp.sub (eGet 1 (Expr.var 1)) (Expr.lit 1))
                (Expr.var 0))))
          (Expr.lit 0))
        (eList [Expr.lit 0, Expr.var 0])
        (eList [Expr.lit 1, eList [Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1),
          eGet 1 (Expr.var 1), eGet 2 (Expr.var 1)]]))
      (eList [Expr.lit 0, Expr.var 0]))

/-- `firstBorn : [H, tr] ↦ firstBorn H tr` (loop from `[0, H, tr]`). -/
def body_firstBorn : Expr :=
  Expr.loop Idx.firstBornStep (Expr.bin BinOp.cons (Expr.lit 0) (Expr.var 0))

/-- Element routine of `resetAt`: `[i, B, [d, p]] ↦ if i = d then resetYBank [p, B] else B`. -/
def body_resetAtElem : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 (Expr.var 0)) (eGet 0 (eGet 2 (Expr.var 0))))
    (Expr.call F2e2e.C.Impl.Idx.resetYBank
      (eList [eGet 1 (eGet 2 (Expr.var 0)), eGet 1 (Expr.var 0)]))
    (eGet 1 (Expr.var 0))

/-- `resetAt : [banks, [d, p]] ↦ modifyAt (Bank.mapRows Row.resetY) d banks`. -/
def body_resetAt : Expr := body_mapIdx Idx.resetAtStep

/-- Loop body of `resetAt`. -/
def body_resetAtStep : Expr := body_mapIdxStep Idx.resetAtElem

/-- The new learner record `[tag, cache, 0, 0, 0]` from expressions for the tag and the cache. -/
def eLearner (tag cache : Expr) : Expr :=
  eList [tag, cache, Expr.lit 0, Expr.lit 0, Expr.lit 0]

/-- `b2 = b1 ++ [newBank]` if `d + 2 ≤ H` (i.e. `d + 1 < H`), else `b1`.
Environment `[b1, ex, st, d, Y]`. -/
def bd_b2 : Expr :=
  Expr.ite (Expr.bin BinOp.lt (Expr.bin BinOp.add (Expr.var 3) (Expr.lit 1)) (eGet 2 (Expr.var 1)))
    (Expr.letE (Expr.call F2e2e.C.Impl.Idx.newBank (eGet 0 (Expr.var 1)))
      (Expr.call F2e2e.Cost.Idx.append (eList [Expr.var 1, eList [Expr.var 0]])))
    (Expr.var 0)

/-- The state with the new learner of cache `0`. Environment `[b2, b1, ex, st, d, Y]`. -/
def bd_A : Expr :=
  eList [eGet 0 (Expr.var 3), eGet 1 (Expr.var 3), eGet 2 (Expr.var 3), eGet 3 (Expr.var 3),
    Expr.call F2e2e.Cost.Idx.append
      (eList [eGet 4 (Expr.var 3), eList [eLearner (eGet 3 (Expr.var 2)) (Expr.lit 0)]]),
    Expr.var 0, eGet 6 (Expr.var 3)]

/-- `s2.fail` (no bank at index `d`). Environment `[ob, b2, b1, ex, st, d, Y]`. -/
def bd_fail2 : Expr :=
  eList [eGet 0 (Expr.var 4), Expr.lit 1, eGet 2 (Expr.var 4), eGet 3 (Expr.var 4),
    eGet 4 (Expr.var 4), Expr.var 1, eGet 6 (Expr.var 4)]

/-- `s3.fail` (the release returned nothing). Environment `[b3, res, ob, b2, b1, ex, st, d, Y]`. -/
def bd_fail3 : Expr :=
  eList [eGet 0 (Expr.var 6), Expr.lit 1, eGet 2 (Expr.var 6), eGet 3 (Expr.var 6),
    eGet 4 (Expr.var 6), Expr.var 0, eGet 6 (Expr.var 6)]

/-- The state with the new learner of cache `cache`. Environment
`[ok, cache, b3, res, ob, b2, b1, ex, st, d, Y]`. -/
def bd_succ : Expr :=
  eList [eGet 0 (Expr.var 8), eGet 1 (Expr.var 8), eGet 2 (Expr.var 8), eGet 3 (Expr.var 8),
    Expr.call F2e2e.Cost.Idx.append
      (eList [eGet 4 (Expr.var 8), eList [eLearner (eGet 3 (Expr.var 7)) (Expr.var 1)]]),
    Expr.var 2, eGet 6 (Expr.var 8)]

/-- `s3.fail` (the cache is out of range). Environment `[ok, cache, b3, res, ob, b2, b1, ex, st, d, Y]`. -/
def bd_fail4 : Expr :=
  eList [eGet 0 (Expr.var 8), Expr.lit 1, eGet 2 (Expr.var 8), eGet 3 (Expr.var 8),
    eGet 4 (Expr.var 8), Expr.var 2, eGet 6 (Expr.var 8)]

/-- After the release and `b3 = setAt res.2 d b2`: the released value's branch.
Environment `[b3, res, ob, b2, b1, ex, st, d, Y]`. -/
def bd_N : Expr :=
  Expr.ite (Expr.un UnOp.isNil (eGet 0 (Expr.var 1))) bd_fail3
    (Expr.letE (Expr.call F2e2e.C.Impl.Idx.roundMantQ
        (eList [eGet 4 (Expr.var 5), Expr.un UnOp.head (eGet 0 (Expr.var 1))]))
      (Expr.letE (Expr.call F2e2e.C.Impl.Idx.inRangeA (eList [eGet 0 (Expr.var 6),
          Expr.call F2e2e.C.Impl.Idx.normQ (eList [Expr.var 0, eGet 5 (Expr.var 6)])]))
        (Expr.ite (Expr.var 0) bd_succ bd_fail4)))

/-- The release branch. Environment `[ob, b2, b1, ex, st, d, Y]`. -/
def bd_rel : Expr :=
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.release
      (eList [eGet 0 (Expr.var 3), Expr.un UnOp.head (Expr.var 0), Expr.lit 0]))
    (Expr.letE (Expr.call F2e2e.Cost.Idx.set (eList [Expr.var 2, Expr.var 6, eGet 1 (Expr.var 0)]))
      bd_N)

/-- The branch `¬ (d = 0 ∨ d₀ < d)`. Environment `[b2, b1, ex, st, d, Y]`. -/
def bd_B : Expr :=
  Expr.letE (Expr.call F2e2e.Cost.Idx.getOpt (eList [Expr.var 0, Expr.var 4]))
    (Expr.ite (Expr.un UnOp.isNil (Expr.var 0)) bd_fail2 bd_rel)

/-- The continuation after `b2`. Environment `[b2, b1, ex, st, d, Y]`. -/
def bd_cont : Expr :=
  Expr.ite (Expr.bin BinOp.eq (Expr.var 4) (Expr.lit 0)) bd_A
    (Expr.ite (Expr.bin BinOp.lt (eGet 1 (Expr.var 2)) (Expr.var 4)) bd_A bd_B)

/-- One birth (`birthDepth P d₀ d s`). Environment `[Y]`, `Y = [d, st, ex]`; the let-bound values are,
in order: `d, st, ex, b1 = modifyAt resetY d banks, b2 = b1 (++ [newBank])`; then `bd_cont`: the
branch `d = 0 ∨ d₀ < d` (learner with cache `0`) or the release branch (`ob = b2[d]?`,
`res = release`, `b3 = setAt res.2 d b2`, `cache = roundMant eHP N`, `ok = inRangeA (cache / 2^eHP)`). -/
def body_birthDepth : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- d    [d, Y]
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- st   [st, d, Y]
  Expr.letE (eGet 2 (Expr.var 2)) <|                                       -- ex   [ex, st, d, Y]
  Expr.letE (Expr.call Idx.resetAt
    (eList [eGet 5 (Expr.var 1), eList [Expr.var 2, eGet 0 (Expr.var 0)]])) <|  -- b1
  Expr.letE bd_b2 bd_cont

/-- Element routine of the birth loop: `[d, st, ex] ↦ st` if `st` has failed, else one birth. -/
def body_birthElem : Expr :=
  Expr.ite (eGet 1 (eGet 1 (Expr.var 0))) (eGet 1 (Expr.var 0))
    (Expr.call Idx.birthDepth (Expr.var 0))

/-- The birth loop (DSL-CALC's `foldB`): input `[st, ds, ex]`. -/
def body_birthLoop : Expr := body_foldB Idx.birthLoopStep

/-- Loop body of the birth loop. -/
def body_birthLoopStep : Expr := body_foldBStep Idx.birthElem

/-- Step 1. Environment `[X]`, `X = [p, st]`; the let-bound values are, in order:
`p, st, H, d₀ = firstBorn H (t + 1), eHC, 2^{eHC}, eHP, 2^{eHP}, learners.take d₀,
banks.take (d₀ + 1), ds = (range H).drop d₀, s₂ = birthLoop`; output `s₂` with `leaf := 0`. -/
def body_step1 : Expr :=
  Expr.letE (eGet 0 (Expr.var 0)) <|                                       -- p
  Expr.letE (eGet 1 (Expr.var 1)) <|                                       -- st
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pH (Expr.var 1)) <|                -- H
  Expr.letE (Expr.call Idx.firstBorn (eList [Expr.var 0,
    Expr.bin BinOp.add (eGet 0 (Expr.var 1)) (Expr.lit 1)])) <|            -- d0
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHC (Expr.var 3)) <|              -- eHC
  Expr.letE (Expr.call F2e2e.Cost.Idx.pow2 (Expr.var 0)) <|                -- tag
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.peHP (Expr.var 5)) <|              -- eHP
  Expr.letE (Expr.call F2e2e.Cost.Idx.pow2 (Expr.var 0)) <|                -- twoP
  Expr.letE (Expr.call F2e2e.Cost.Idx.take (eList [eGet 4 (Expr.var 6), Expr.var 4])) <|  -- lrn
  Expr.letE (Expr.call F2e2e.Cost.Idx.take (eList [eGet 5 (Expr.var 7),
    Expr.bin BinOp.add (Expr.var 5) (Expr.lit 1)])) <|                     -- bks
  Expr.letE (Expr.call F2e2e.Cost.Idx.drop
    (eList [Expr.call F2e2e.Cost.Idx.range (Expr.var 7), Expr.var 6])) <|  -- ds
  Expr.letE (Expr.call Idx.birthLoop (eList [
    eList [eGet 0 (Expr.var 9), eGet 1 (Expr.var 9), eGet 2 (Expr.var 9), eGet 3 (Expr.var 9),
      Expr.var 2, Expr.var 1, eGet 6 (Expr.var 9)],
    Expr.var 0,
    eList [Expr.var 10, Expr.var 7, Expr.var 8, Expr.var 5, Expr.var 4, Expr.var 3]])) <|  -- s2
  eList [eGet 0 (Expr.var 0), eGet 1 (Expr.var 0), eGet 2 (Expr.var 0), eGet 3 (Expr.var 0),
    eGet 4 (Expr.var 0), eGet 5 (Expr.var 0), Expr.lit 0]

/-! ## The table -/

/-- The Tree1 routines as table entries `(index, body)`. -/
def tree1Table : List (ℕ × Expr) :=
  [(Idx.step1, body_step1), (Idx.firstBorn, body_firstBorn),
    (Idx.firstBornStep, body_firstBornStep), (Idx.birthLoop, body_birthLoop),
    (Idx.birthLoopStep, body_birthLoopStep), (Idx.birthElem, body_birthElem),
    (Idx.birthDepth, body_birthDepth), (Idx.resetAt, body_resetAt),
    (Idx.resetAtStep, body_resetAtStep), (Idx.resetAtElem, body_resetAtElem)]

/-- Every table entry Tree1 needs: its own routines and the DSL-CALC library routines it calls. -/
def tree1Needs : List (ℕ × Expr) :=
  tree1Table ++
    [(F2e2e.Cost.Idx.pow2, body_pow2), (F2e2e.Cost.Idx.pow2Step, body_pow2Step),
      (F2e2e.Cost.Idx.take, body_take), (F2e2e.Cost.Idx.drop, body_drop),
      (F2e2e.Cost.Idx.setStep, body_setStep), (F2e2e.Cost.Idx.set, body_set),
      (F2e2e.Cost.Idx.range, body_range), (F2e2e.Cost.Idx.rangeStep, body_rangeStep),
      (F2e2e.Cost.Idx.append, body_append), (F2e2e.Cost.Idx.revAppendStep, body_revAppendStep),
      (F2e2e.Cost.Idx.reverse, body_reverse), (F2e2e.Cost.Idx.getOpt, body_getOpt),
      (F2e2e.Cost.Idx.getOptStep, body_getOptStep)]

/-- The program contains Step 1's routines and the library routines they use. -/
structure Tree1Lib (prog : List Expr) : Prop where
  step1 : prog[Idx.step1]? = some body_step1
  firstBorn : prog[Idx.firstBorn]? = some body_firstBorn
  firstBornStep : prog[Idx.firstBornStep]? = some body_firstBornStep
  birthLoop : prog[Idx.birthLoop]? = some body_birthLoop
  birthLoopStep : prog[Idx.birthLoopStep]? = some body_birthLoopStep
  birthElem : prog[Idx.birthElem]? = some body_birthElem
  birthDepth : prog[Idx.birthDepth]? = some body_birthDepth
  resetAt : prog[Idx.resetAt]? = some body_resetAt
  resetAtStep : prog[Idx.resetAtStep]? = some body_resetAtStep
  resetAtElem : prog[Idx.resetAtElem]? = some body_resetAtElem
  pow2 : prog[F2e2e.Cost.Idx.pow2]? = some body_pow2
  pow2Step : prog[F2e2e.Cost.Idx.pow2Step]? = some body_pow2Step
  take : prog[F2e2e.Cost.Idx.take]? = some body_take
  drop : prog[F2e2e.Cost.Idx.drop]? = some body_drop
  setStep : prog[F2e2e.Cost.Idx.setStep]? = some body_setStep
  set : prog[F2e2e.Cost.Idx.set]? = some body_set
  range : prog[F2e2e.Cost.Idx.range]? = some body_range
  rangeStep : prog[F2e2e.Cost.Idx.rangeStep]? = some body_rangeStep
  append : prog[F2e2e.Cost.Idx.append]? = some body_append
  revAppendStep : prog[F2e2e.Cost.Idx.revAppendStep]? = some body_revAppendStep
  reverse : prog[F2e2e.Cost.Idx.reverse]? = some body_reverse
  getOpt : prog[F2e2e.Cost.Idx.getOpt]? = some body_getOpt
  getOptStep : prog[F2e2e.Cost.Idx.getOptStep]? = some body_getOptStep

/-- `Tree1Lib` from the table entries (e.g. `mkProg_get` on an assembled table containing
`tree1Needs`). -/
theorem Tree1Lib.of_entries {prog : List Expr} (h : ∀ p ∈ tree1Needs, prog[p.1]? = some p.2) :
    Tree1Lib prog := by
  have H : ∀ i b, (i, b) ∈ tree1Needs → prog[i]? = some b := fun i b hm => h (i, b) hm
  exact
    { step1 := H _ _ (by simp [tree1Needs, tree1Table])
      firstBorn := H _ _ (by simp [tree1Needs, tree1Table])
      firstBornStep := H _ _ (by simp [tree1Needs, tree1Table])
      birthLoop := H _ _ (by simp [tree1Needs, tree1Table])
      birthLoopStep := H _ _ (by simp [tree1Needs, tree1Table])
      birthElem := H _ _ (by simp [tree1Needs, tree1Table])
      birthDepth := H _ _ (by simp [tree1Needs, tree1Table])
      resetAt := H _ _ (by simp [tree1Needs, tree1Table])
      resetAtStep := H _ _ (by simp [tree1Needs, tree1Table])
      resetAtElem := H _ _ (by simp [tree1Needs, tree1Table])
      pow2 := H _ _ (by simp [tree1Needs, tree1Table])
      pow2Step := H _ _ (by simp [tree1Needs, tree1Table])
      take := H _ _ (by simp [tree1Needs, tree1Table])
      drop := H _ _ (by simp [tree1Needs, tree1Table])
      setStep := H _ _ (by simp [tree1Needs, tree1Table])
      set := H _ _ (by simp [tree1Needs, tree1Table])
      range := H _ _ (by simp [tree1Needs, tree1Table])
      rangeStep := H _ _ (by simp [tree1Needs, tree1Table])
      append := H _ _ (by simp [tree1Needs, tree1Table])
      revAppendStep := H _ _ (by simp [tree1Needs, tree1Table])
      reverse := H _ _ (by simp [tree1Needs, tree1Table])
      getOpt := H _ _ (by simp [tree1Needs, tree1Table])
      getOptStep := H _ _ (by simp [tree1Needs, tree1Table]) }

end F2e2e.C.Impl.T1
