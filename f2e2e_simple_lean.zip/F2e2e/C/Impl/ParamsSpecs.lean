import F2e2e.C.Impl.ParamsW1

/-!
# W1 (public parameters, DSL), part 6: the routine specifications and W1's contract

Owner: c186bcb5 (for C-PARAMS e26ae4ae; draft by e26ae4ae).

* `W1.peU_spec`: the routine `body_peU` (index `414`) maps `[encStreamParams P, d]` to `P.eU d`
  (`⌈log₂(2 V_d²)⌉`) for depths `d < H`;
* `W1.pGuardCoord_spec`: the routine `body_pGuardCoord` (index `415`) maps `[encStreamParams P, d, t]` to
  `P.guardCoord d t` for `d < H`, `1 ≤ t ≤ m`;
* **`w1Contract`**: C-TOP's `W1Contract R prog M` (`F2e2e/C/Impl/W6Contracts.lean`) for every program
  containing W1's routines (`W1Lib prog`): the single-parameter routines by `W1.param_spec`, the two
  routines above.
-/

set_option linter.unusedSimpArgs false

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

theorem valSize_params_bound (P : StreamParams) :
    valSize (encStreamParams P) ≤ 5 * Nat.size (Abnd P) + 11 := by
  have h := valSize_map_encN_le (Abnd P) [P.n, P.m, P.U, P.epsExp, P.betaExp] (by
    intro x hx
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl
    exacts [n_le_A P, m_le_A P, U_le_A P, epsExp_le_A P, betaExp_le_A P])
  simp only [List.map_cons, List.map_nil, List.length_cons, List.length_nil] at h
  have e : valSize (encStreamParams P) =
      valSize (Val.list [encN P.n, encN P.m, encN P.U, encN P.epsExp, encN P.betaExp]) := rfl
  omega

theorem guardCoord_le_A (P : StreamParams) {d t : ℕ} (hd : d < P.H) (ht : t ≤ P.m) :
    P.guardCoord d t ≤ Abnd P := by
  have hn := (W2.n_lt_two_pow_calL P).le
  have hm := Space.m_le P
  have hH := Space.H_le P
  have hL := Space.hundred_le_calL P
  have hY1 : 1 ≤ 2 ^ P.calL := Nat.one_le_two_pow
  have hLY : P.calL ≤ 2 ^ P.calL := Nat.lt_two_pow_self.le
  have h1 : P.H * (t - 1) ≤ 2 ^ P.calL * 2 ^ P.calL :=
    Nat.mul_le_mul (hH.trans hLY) ((Nat.sub_le _ _).trans (ht.trans hm))
  have h2 : 2 ^ P.calL ≤ 2 ^ P.calL * 2 ^ P.calL := Nat.le_mul_of_pos_left _ (Nat.two_pow_pos _)
  have h3 : P.guardCoord d t ≤ 2 ^ (2 * P.calL + 2) := by
    have e : (2 : ℕ) ^ (2 * P.calL + 2) = 4 * (2 ^ P.calL * 2 ^ P.calL) := by
      rw [pow_add, show 2 * P.calL = P.calL + P.calL by ring, pow_add]; ring
    rw [e]
    unfold StreamParams.guardCoord
    omega
  exact le_A_of_le_pow_lin P h3 (by omega)

theorem peU_spec (R : AdaRep) (hlib : W1Lib prog) :
    AtIdx prog Idx.peU fun body => ∀ (P : StreamParams) (d : ℕ), C.Top.ParamsOK P → d < P.H →
      Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encN d]] [] (.inl body)
        (Val.int (P.eU d : ℤ)) := by
  refine ⟨body_peU, hlib.peU, fun P d hP hd hMv => ?_⟩
  have hM : 2 ^ 37 * P.calL ^ 3 ≤ M := (W2.calL_cube_le_Mv R P).trans hMv
  have hA := four096_le_Abnd P
  have hM16 := valSize_Abnd_pow_le (M := M) hM
  have hLs := outs_valSize_le P hM
  have hdA : d ≤ Abnd P := hd.le.trans (H_le_Abnd P)
  have hIn : valSize (Val.list [encStreamParams P, encN d]) ≤ M := by
    have h1 := valSize_params_bound P
    have h2 := valSize_encN_le_of_le hdA
    have hs := size_Abnd_le P hM
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hS : EvalsVal prog M [Val.list [encStreamParams P, encN d]] [] (.inl (eNth 0 (Expr.var 0)))
      (encStreamParams P) :=
    eNth_evals (l := [encStreamParams P, encN d]) (EvalsVal.var rfl) hIn rfl
  refine letE0 (call0 hS hlib.all (w1All_evals hlib P hP hM)) ?_
  have hV := Vd_le_Abnd P hd.le
  have hA2 : 2 ≤ Abnd P := by omega
  have hx : 2 * (P.Vd d * P.Vd d) ≤ Abnd P ^ 16 :=
    calc 2 * (P.Vd d * P.Vd d) ≤ Abnd P * (Abnd P * Abnd P) :=
          Nat.mul_le_mul hA2 (Nat.mul_le_mul hV hV)
      _ = Abnd P ^ 3 := by ring
      _ ≤ Abnd P ^ 16 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have heU : P.eU d = Nat.clog 2 (2 * (P.Vd d * P.Vd d)) := by
    unfold StreamParams.eU
    rw [sq]
  have hok : ChainOK prog M (Abnd P)
      [Val.list ((outs P).map encN), Val.list [encStreamParams P, encN d]]
      [CE.raw (eNth 14 (Expr.var 0)), CE.raw (eNth 15 (Expr.var 1)), CE.raw (eNth 1 (Expr.var 3)),
        CE.raw (eVd 0 2 1), CE.pe (clog (PE.mul (PE.lit 2) (PE.mul (PE.var 0) (PE.var 0))))]
      [P.B, P.W, d, P.Vd d, P.eU d] [] := by
    refine ChainOK.raw_cons (eNth_evals (EvalsVal.var rfl) hLs rfl) (B_le_Abnd P) ?_
    refine ChainOK.raw_cons (eNth_evals (EvalsVal.var rfl) hLs rfl) (W_le_Abnd P) ?_
    refine ChainOK.raw_cons
      (eNth_evals (l := [encStreamParams P, encN d]) (EvalsVal.var rfl) hIn rfl) hdA ?_
    refine ChainOK.raw_cons (eVd_evals hlib.vdStep P rfl rfl rfl hd.le hM) hV ?_
    refine ChainOK.pe_cons rfl (by decide)
      (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
      (by rw [heU]; rfl)
      (by rw [heU]; exact (clog2_node hlib.clog2 hlib.clog2Step hM _ hx).2) ?_
    exact ChainOK.nil
  exact chain_evals _ hA hM16 _ _ [] (Expr.var 0) _ hok (by simp) (fun _ => EvalsVal.var rfl)

theorem pGuardCoord_spec (R : AdaRep) (hlib : W1Lib prog) :
    AtIdx prog Idx.pGuardCoord fun body => ∀ (P : StreamParams) (d t : ℕ),
      C.Top.ParamsOK P → d < P.H → 1 ≤ t → t ≤ P.m → Mv R P ≤ M →
      EvalsVal prog M [Val.list [encStreamParams P, encN d, encN t]] [] (.inl body)
        (Val.int (P.guardCoord d t : ℤ)) := by
  refine ⟨body_pGuardCoord, hlib.pGuardCoord, fun P d t hP hd _ ht hMv => ?_⟩
  have hM : 2 ^ 37 * P.calL ^ 3 ≤ M := (W2.calL_cube_le_Mv R P).trans hMv
  have hA := four096_le_Abnd P
  have hM16 := valSize_Abnd_pow_le (M := M) hM
  have hLs := outs_valSize_le P hM
  have hdA : d ≤ Abnd P := hd.le.trans (H_le_Abnd P)
  have htA : t ≤ Abnd P := ht.trans (m_le_A P)
  have hIn : valSize (Val.list [encStreamParams P, encN d, encN t]) ≤ M := by
    have h1 := valSize_params_bound P
    have h2 := valSize_encN_le_of_le hdA
    have h3 := valSize_encN_le_of_le htA
    have hs := size_Abnd_le P hM
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hS : EvalsVal prog M [Val.list [encStreamParams P, encN d, encN t]] []
      (.inl (eNth 0 (Expr.var 0))) (encStreamParams P) :=
    eNth_evals (l := [encStreamParams P, encN d, encN t]) (EvalsVal.var rfl) hIn rfl
  refine letE0 (call0 hS hlib.all (w1All_evals hlib P hP hM)) ?_
  have hok : ChainOK prog M (Abnd P)
      [Val.list ((outs P).map encN), Val.list [encStreamParams P, encN d, encN t]]
      [CE.raw (eNth 0 (Expr.var 0)), CE.raw (eNth 0 (eNth 0 (Expr.var 2))),
        CE.raw (eNth 1 (Expr.var 3)), CE.raw (eNth 2 (Expr.var 4)),
        CE.pe (PE.add (PE.add (PE.add (PE.var 2) (PE.mul (PE.var 3) (PE.subL (PE.var 0) 1)))
          (PE.var 1)) (PE.lit 1))]
      [P.H, P.n, d, t, P.guardCoord d t] [] := by
    refine ChainOK.raw_cons (eNth_evals (EvalsVal.var rfl) hLs rfl) (H_le_Abnd P) ?_
    refine ChainOK.raw_cons
      (eNth_evals (l := [encN P.n, encN P.m, encN P.U, encN P.epsExp, encN P.betaExp])
        (eNth_evals (l := [encStreamParams P, encN d, encN t]) (EvalsVal.var rfl) hIn rfl)
        (valSize_params_le P hM) rfl) (n_le_A P) ?_
    refine ChainOK.raw_cons
      (eNth_evals (l := [encStreamParams P, encN d, encN t]) (EvalsVal.var rfl) hIn rfl) hdA ?_
    refine ChainOK.raw_cons
      (eNth_evals (l := [encStreamParams P, encN d, encN t]) (EvalsVal.var rfl) hIn rfl) htA ?_
    refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true]) rfl
      (guardCoord_le_A P hd ht) ?_
    exact ChainOK.nil
  exact chain_evals _ hA hM16 _ _ [] (Expr.var 0) _ hok (by simp) (fun _ => EvalsVal.var rfl)

end W1

/-- **W1's contract** (C-TOP's `W1Contract`, `F2e2e/C/Impl/W6Contracts.lean`). -/
theorem w1Contract (R : AdaRep) {prog : List Expr} {M : ℕ} (hlib : W1Lib prog) :
    W1Contract R prog M where
  pH := W1.param_spec R hlib 0 hlib.pH (fun _ => rfl)
  peHC := W1.param_spec R hlib 1 hlib.peHC (fun _ => rfl)
  peHP := W1.param_spec R hlib 2 hlib.peHP (fun _ => rfl)
  peHleaf := W1.param_spec R hlib 3 hlib.peHleaf (fun _ => rfl)
  peHg := W1.param_spec R hlib 4 hlib.peHg (fun _ => rfl)
  peHstep := W1.param_spec R hlib 5 hlib.peHstep (fun _ => rfl)
  peEta := W1.param_spec R hlib 6 hlib.peEta (fun _ => rfl)
  peGamma := W1.param_spec R hlib 7 hlib.peGamma (fun _ => rfl)
  pJstar := W1.param_spec R hlib 8 hlib.pJstar (fun _ => rfl)
  pK0 := W1.param_spec R hlib 9 hlib.pK0 (fun _ => rfl)
  pKepoch := W1.param_spec R hlib 10 hlib.pKepoch (fun _ => rfl)
  pAmax := W1.param_spec R hlib 11 hlib.pAmax (fun _ => rfl)
  pCmax := W1.param_spec R hlib 12 hlib.pCmax (fun _ => rfl)
  pq := W1.param_spec R hlib 13 hlib.pq (fun _ => rfl)
  peHb := W1.param_spec R hlib 16 hlib.peHb (fun _ => rfl)
  pZmax := W1.param_spec R hlib 17 hlib.pZmax (fun _ => rfl)
  pDstar := W1.param_spec R hlib 18 hlib.pDstar (fun _ => rfl)
  peSigma := W1.param_spec R hlib 19 hlib.peSigma (fun _ => rfl)
  peOmega := W1.param_spec R hlib 20 hlib.peOmega (fun _ => rfl)
  pL := W1.param_spec R hlib 21 hlib.pL (fun _ => rfl)
  pw := W1.param_spec R hlib 22 hlib.pw (fun _ => rfl)
  pIrrW := W1.param_spec R hlib 23 hlib.pIrrW (fun _ => rfl)
  ps := W1.param_spec R hlib 24 hlib.ps (fun _ => rfl)
  pgCoarse := W1.param_spec R hlib 25 hlib.pgCoarse (fun _ => rfl)
  pRmax := W1.param_spec R hlib 26 hlib.pRmax (fun _ => rfl)
  peBankA := W1.param_spec R hlib 27 hlib.peBankA (fun _ => rfl)
  peBankXi := W1.param_spec R hlib 28 hlib.peBankXi (fun _ => rfl)
  pbankM := W1.param_spec R hlib 29 hlib.pbankM (fun _ => rfl)
  pbankJ := W1.param_spec R hlib 30 hlib.pbankJ (fun _ => rfl)
  pbankR := W1.param_spec R hlib 31 hlib.pbankR (fun _ => rfl)
  pSeedTrials := W1.param_spec R hlib 32 hlib.pSeedTrials (fun _ => rfl)
  peU := W1.peU_spec R hlib
  pGuardCoord := W1.pGuardCoord_spec R hlib

end F2e2e.C.Impl
