import F2e2e.C.Impl.BankRows
import F2e2e.C.Impl.BankEntries
import F2e2e.C.Impl.BankValidate

/-!
# W5: the contract of the Norm Bank operations

Owner: W5 (c1b4f720). **Main theorem** `w5Contract`: every program containing W5's routines
(`BankDSL.BankLib prog`, bodies in `F2e2e/C/Impl/BankDefs.lean`) and W2's Horner routines
(`HashDSL.HornerLib prog`, for the row signs), and satisfying W1's and W4's contracts, satisfies C-TOP's
`W5Contract` and `NormQSpec` (`F2e2e/C/Impl/W6Contracts.lean`).

The fields are proved in
* `F2e2e/C/Impl/BankRows.lean` (750–755: the row operations mapped over a bank),
* `F2e2e/C/Impl/BankValidateCore.lean` (756: `ValidateInterval`, B-ACC),
* `F2e2e/C/Impl/BankValidate.lean` (757: `ReleaseNumerical`, B-ACC; helpers in `BankRelease.lean`, A-VAL),
* `F2e2e/C/Impl/BankEntries.lean` (758–765: arithmetic and learner entries),
* `F2e2e/C/Impl/BankArith.lean` (766: `normQ`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top
open BankDSL

/-- `NormQSpec` from `normQ_val`. -/
theorem normQSpec_of_lib {prog : List Expr} {M : ℕ} (hlib : BankLib prog) : NormQSpec prog M :=
  ⟨body_normQ, hlib.normQ, fun a b hb hM => normQ_val hlib.bkGcdStep a b hb hM⟩

/-- **W5's contract** (C-TOP's `W5Contract` and the shared `normQ`). -/
theorem w5Contract (R : AdaRep) (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hlib : BankDSL.BankLib prog) (hw1 : W1Contract R prog M) (hw4 : W4Contract R prog M)
    (hw2 : HornerLib prog) :
    W5Contract R prog M ∧ NormQSpec prog M := by
  refine ⟨⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩, normQSpec_of_lib hlib⟩
  · exact ⟨body_resetYBank, hlib.resetYBank,
      fun P B hP hB hM => resetYBank_spec R hR hlib P B hP hB hM⟩
  · exact ⟨body_addPhysBank, hlib.addPhysBank,
      fun P B i Δ hP hB hi1 hin hΔ hM => addPhysBank_spec R hR hlib hw1 hw2 P B i Δ hP hB hi1 hin hΔ hM⟩
  · exact ⟨body_addGuardYBank, hlib.addGuardYBank,
      fun P B g δ hP hB hg1 hgD hδ hM =>
        addGuardYBank_spec R hR hlib hw1 hw2 P B g δ hP hB hg1 hgD hδ hM⟩
  · exact ⟨body_addGuardXYBank, hlib.addGuardXYBank,
      fun P B g δ hP hB hg1 hgD hδ hM =>
        addGuardXYBank_spec R hR hlib hw1 hw2 P B g δ hP hB hg1 hgD hδ hM⟩
  · exact ⟨body_scaleYBank, hlib.scaleYBank,
      fun P B cInt hP hB hc hM => scaleYBank_spec R hR hlib hw1 P B cInt hP hB hc hM⟩
  · exact ⟨body_scaleXYBank, hlib.scaleXYBank,
      fun P B cInt hP hB hc hM => scaleXYBank_spec R hR hlib hw1 P B cInt hP hB hc hM⟩
  · exact ⟨body_validate, hlib.validate,
      fun P B S θ hP hB hS0 hSA hSq hθ0 hθ1 hθd hM =>
        validate_spec R hR hlib hw1 hw2 hw4 P B S θ hP hB hS0 hSA hSq hθ0 hθ1 hθd hM⟩
  · exact ⟨body_release, hlib.release,
      fun P B mode hP hB hM => release_spec R hR hlib hw1 hw2 hw4 P B mode hP hB hM⟩
  · exact ⟨body_roundMantQ, hlib.roundMantQ,
      fun P q z hP hq hz hM => roundMantQ_spec R hlib P q z hP hq hz hM⟩
  · exact ⟨body_guardMant, hlib.guardMant,
      fun P Cint α e hP hC0 hC hα he hM => guardMant_spec R hlib P Cint α e hP hC0 hC hα he hM⟩
  · exact ⟨body_stepCoeffMant, hlib.stepCoeffMant,
      fun P pos qη qs Pval Qhat hP hqη hqs hP0 hPq hQ0 hQq hM =>
        stepCoeffMant_spec R hlib P pos qη qs Pval Qhat hP hqη hqs hP0 hPq hQ0 hQq hM⟩
  · exact ⟨body_rescaleLearner, hlib.rescaleLearner,
      fun P cInt L hP hL hc hM => rescaleLearner_spec R hlib hw1 P cInt L hP hL hc hM⟩
  · exact ⟨body_countCorrection, hlib.countCorrection,
      fun P L hP hL hM => countCorrection_spec R hlib hw1 P L hP hL hM⟩
  · exact ⟨body_inRangeA, hlib.inRangeA, fun P x hP hx hM => inRangeA_spec R hlib hw1 P x hP hx hM⟩
  · exact ⟨body_inRangeC, hlib.inRangeC, fun P x hP hx hM => inRangeC_spec R hlib hw1 P x hP hx hM⟩
  · exact ⟨body_learnerInRange, hlib.learnerInRange,
      fun P L hP hL hM => learnerInRange_spec R hlib hw1 P L hP hL hM⟩

end F2e2e.C.Impl
