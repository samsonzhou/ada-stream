import F2e2e.Cost.Lib.Coins
import F2e2e.Cost.ValRules
import F2e2e.Cost.BitProgBridge
import F2e2e.Lib.Discrete.Sampler

/-!
# ADA module (W4), part 1: the bounded lattice-noise sampler in the DSL

Reference functions (`F2e2e/Lib/Discrete/Sampler.lean`, used by B-ARCH's `adaDraw`):
* `ratCoin A D r` : Bernoulli(`A/D`) by at most `r` rejection trials of `⌈log₂ D⌉` fresh bits;
* `countSucc K` (via `DrawProg.toBits`) : consecutive successful coins, capped at `K`;
* `latticeSampler A D r K` : the difference of two capped counts (a lattice index).

DSL routines (Idx 610–614, inside the W4 range 600–749):

| idx | body | input | output |
|---|---|---|---|
| 610/611 | `body_adaCoin` / step | `[r, A, D, k]` (`k = ⌈log₂ D⌉`) | `encB (ratCoin A D r)` |
| 612/613 | `body_adaCount` / step | `[K, r, A, D, k]` | `encN (count)` |
| 614 | `body_adaLattice` | `[K, r, A, D, k]` | `encZ (latticeSampler A D r K)` |

`uniformBits k` is the library routine `readNat` (Idx 92/93, `F2e2e/Cost/Lib/Coins.lean`).
Specs are in `Implements` form (`F2e2e/Cost/BitProgBridge.lean`): `coin_impl`, `count_impl`,
`lattice_impl`, under the value bounds `coinM r A D k ≤ M`, `countM K r A D k ≤ M`. Support facts:
`countSucc_run_le` (a count is at most `K`).
-/

namespace F2e2e.Cost.Idx

/-- `adaCoin : [r, A, D, k] ↦ encB (ratCoin A D r)`. -/
abbrev adaCoin : ℕ := 610
abbrev adaCoinStep : ℕ := 611
/-- `adaCount : [K, r, A, D, k] ↦ encN (count of successful coins, capped at K)`. -/
abbrev adaCount : ℕ := 612
abbrev adaCountStep : ℕ := 613
/-- `adaLattice : [K, r, A, D, k] ↦ encZ (latticeSampler A D r K)`. -/
abbrev adaLattice : ℕ := 614

end F2e2e.Cost.Idx

namespace F2e2e.Cost.AdaDSL

open F2e2e.Discrete

/-! ### Expression shorthands -/

abbrev eV (i : ℕ) : Expr := Expr.var i
abbrev eLit (z : ℤ) : Expr := Expr.lit z
abbrev eHd (e : Expr) : Expr := Expr.un UnOp.head e
abbrev eTl (e : Expr) : Expr := Expr.un UnOp.tail e
abbrev eAdd (a b : Expr) : Expr := Expr.bin BinOp.add a b
abbrev eSub (a b : Expr) : Expr := Expr.bin BinOp.sub a b
abbrev eMul (a b : Expr) : Expr := Expr.bin BinOp.mul a b
abbrev eDiv (a b : Expr) : Expr := Expr.bin BinOp.div a b
abbrev eMod (a b : Expr) : Expr := Expr.bin BinOp.mod a b
abbrev eLt (a b : Expr) : Expr := Expr.bin BinOp.lt a b
abbrev eEq (a b : Expr) : Expr := Expr.bin BinOp.eq a b
abbrev eCons (a b : Expr) : Expr := Expr.bin BinOp.cons a b
abbrev eIte (c t f : Expr) : Expr := Expr.ite c t f
abbrev eLet (a b : Expr) : Expr := Expr.letE a b
abbrev eCall (i : ℕ) (a : Expr) : Expr := Expr.call i a
abbrev eLoop (i : ℕ) (a : Expr) : Expr := Expr.loop i a
/-- Element `1` of a list. -/
abbrev eAt1 (e : Expr) : Expr := eHd (eTl e)
/-- Element `2` of a list. -/
abbrev eAt2 (e : Expr) : Expr := eHd (eTl (eTl e))
/-- Element `3` of a list. -/
abbrev eAt3 (e : Expr) : Expr := eHd (eTl (eTl (eTl e)))

/-! ### Bit-program facts -/

section BitProgFacts

variable {α β γ : Type}

theorem bitProg_bind_assoc (p : BitProg α) (f : α → BitProg β) (g : β → BitProg γ) :
    (p.bind f).bind g = p.bind (fun a => (f a).bind g) := by
  induction p with
  | pure a => rfl
  | bit k ih =>
    simp only [BitProg.bind_bit]
    congr 1
    funext b
    exact ih b

theorem bitProg_map_bind (p : BitProg α) (f : α → BitProg β) (g : β → γ) :
    (p.bind f).map g = p.bind (fun a => (f a).map g) := by
  simp only [BitProg.map]
  exact bitProg_bind_assoc p f _

theorem toBits_bind {P : Type} (s : P → BitProg β) (prog : DrawProg P β α)
    (f : α → DrawProg P β γ) :
    DrawProg.toBits s (prog.bind f) =
      (DrawProg.toBits s prog).bind (fun a => DrawProg.toBits s (f a)) := by
  induction prog with
  | ret a => rfl
  | draw p k ih =>
    rw [DrawProg.bind_draw, DrawProg.toBits_draw, DrawProg.toBits_draw, bitProg_bind_assoc]
    congr 1
    funext b
    exact ih b

theorem toBits_map {P : Type} (s : P → BitProg β) (f : α → γ) (prog : DrawProg P β α) :
    DrawProg.toBits s (prog.map f) = (DrawProg.toBits s prog).map f := by
  rw [DrawProg.map, toBits_bind]
  rfl

end BitProgFacts

theorem ratCoin_zero (A D : ℕ) : ratCoin A D 0 = BitProg.pure false := rfl

theorem ratCoin_succ (A D r : ℕ) :
    ratCoin A D (r + 1) = (uniformBits (Nat.clog 2 D)).bind (fun x =>
      if x < D then BitProg.pure (decide (x < A)) else ratCoin A D r) := by
  unfold ratCoin
  rw [show rejectUniform D (Nat.clog 2 D) (r + 1) = (uniformBits (Nat.clog 2 D)).bind (fun x =>
      if x < D then BitProg.pure (some x) else rejectUniform D (Nat.clog 2 D) r) from rfl,
    bitProg_map_bind]
  congr 1
  funext x
  split_ifs <;> rfl

/-- Exact runs of `uniformBits k` read exactly `k` bits, valued `natOfBits`. -/
theorem uniformBits_run_exact {k : ℕ} {bits : List Bool} {x : ℕ}
    (h : (uniformBits k).run bits = some (x, [])) : bits.length = k ∧ x = natOfBits bits := by
  rw [run_uniformBits] at h
  split_ifs at h with hk
  simp only [Option.some.injEq, Prod.mk.injEq] at h
  obtain ⟨hx, hd⟩ := h
  have hlen : bits.length ≤ k := List.drop_eq_nil_iff.mp hd
  have hlen' : bits.length = k := le_antisymm hlen hk
  refine ⟨hlen', ?_⟩
  rw [← hx, List.take_of_length_le (by omega)]
  rfl

theorem toBits_countSucc_zero (s : Unit → BitProg Bool) :
    DrawProg.toBits s (countSucc 0) = BitProg.pure 0 := rfl

theorem toBits_countSucc_succ (s : Unit → BitProg Bool) (K : ℕ) :
    DrawProg.toBits s (countSucc (K + 1)) = (s ()).bind (fun b =>
      if b then (DrawProg.toBits s (countSucc K)).map (· + 1) else BitProg.pure 0) := by
  show (s ()).bind (fun b => DrawProg.toBits s
    (if b then (countSucc K).map (· + 1) else DrawProg.ret 0)) = _
  congr 1
  funext b
  cases b
  · rfl
  · exact toBits_map s _ _

theorem latticeSampler_eq (A D r K : ℕ) : latticeSampler A D r K =
    (DrawProg.toBits (fun _ => ratCoin A D r) (countSucc K)).bind (fun g₁ =>
      (DrawProg.toBits (fun _ => ratCoin A D r) (countSucc K)).map
        (fun g₂ : ℕ => (g₁ : ℤ) - (g₂ : ℤ))) := by
  unfold latticeSampler latticeProg
  rw [toBits_bind]
  congr 1
  funext g₁
  exact toBits_map _ _ _

/-! ### The DSL bodies -/

/-- The part of the `adaCoin` step after reading `x`; environment `[x, r, acc]`. -/
def coinTail : Expr :=
  eIte (eLt (eV 0) (eAt2 (eV 2)))
    (ePair (eLit 0) (eLt (eV 0) (eAt1 (eV 2))))
    (ePair (eLit 1) (eCons (eSub (eV 1) (eLit 1)) (eTl (eV 2))))

/-- Step of `adaCoin`; accumulator `[r, A, D, k]`: no trial left ⇒ stop with `0` (false);
otherwise read `x` (`k` fresh bits); `x < D` ⇒ stop with `x < A`; else continue with `r - 1`. -/
def body_adaCoinStep : Expr :=
  eLet (eHd (eV 0))                                            -- r     [r, acc]
    (eIte (eEq (eV 0) (eLit 0))
      (ePair (eLit 0) (eLit 0))
      (eLet (eCall Idx.readNat (eAt3 (eV 1))) coinTail))        -- x     [x, r, acc]

/-- `adaCoin : [r, A, D, k] ↦ encB (ratCoin A D r)`. -/
def body_adaCoin : Expr := eLoop Idx.adaCoinStep (eV 0)

/-- The part of the `adaCount` step after the coin; environment `[b, K', acc]`. -/
def countTail : Expr :=
  eIte (eV 0)
    (ePair (eLit 1)
      (eCons (eAdd (eHd (eV 2)) (eLit 1))
        (eCons (eSub (eV 1) (eLit 1)) (eTl (eTl (eV 2))))))
    (ePair (eLit 0) (eHd (eV 2)))

/-- Step of `adaCount`; accumulator `[c, K', r, A, D, k]`: `K' = 0` ⇒ stop with `c`; otherwise draw a
coin `b`; `b` ⇒ continue with `[c + 1, K' - 1, r, A, D, k]`; else stop with `c`. -/
def body_adaCountStep : Expr :=
  eLet (eAt1 (eV 0))                                           -- K'    [K', acc]
    (eIte (eEq (eV 0) (eLit 0))
      (ePair (eLit 0) (eHd (eV 1)))
      (eLet (eCall Idx.adaCoin (eTl (eTl (eV 1)))) countTail))  -- b     [b, K', acc]

/-- `adaCount : [K, r, A, D, k] ↦ encN (count)` (loop from `[0, K, r, A, D, k]`). -/
def body_adaCount : Expr := eLoop Idx.adaCountStep (eCons (eLit 0) (eV 0))

/-- `adaLattice : [K, r, A, D, k] ↦ encZ (g₁ - g₂)` with two independent capped counts. -/
def body_adaLattice : Expr :=
  eLet (eCall Idx.adaCount (eV 0))                             -- g₁    [g₁, inp]
    (eLet (eCall Idx.adaCount (eV 1))                          -- g₂    [g₂, g₁, inp]
      (eSub (eV 1) (eV 0)))

/-! ### Encodings and the value bound -/

/-- The accumulator of `adaCoin`. -/
def coinAcc (r A D k : ℕ) : Val := Val.list [encN r, encN A, encN D, encN k]

/-- The accumulator of `adaCount`. -/
def countAcc (c K r A D k : ℕ) : Val := Val.list [encN c, encN K, encN r, encN A, encN D, encN k]



section Steps

variable {prog : List Expr} {M : ℕ}

theorem valSize_coinAcc_le (r A D k : ℕ) :
    valSize (coinAcc r A D k) ≤ Nat.size r + Nat.size A + Nat.size D + Nat.size k + 9 := by
  simp only [coinAcc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

theorem readNat_val (hrn : prog[Idx.readNatStep]? = some body_readNatStep) (bs : List Bool)
    (hM : S_readNat bs.length ≤ M) :
    EvalsVal prog M [encN bs.length] bs (.inl body_readNat) (encN (natOfBits bs)) :=
  (EvalsLeT.toVal (readNat_spec hrn bs 0)).mono_M hM

theorem coinStep_zero (A D k : ℕ) (hM : 3 * valSize (coinAcc 0 A D k) + 30 ≤ M) :
    EvalsVal prog M [coinAcc 0 A D k] [] (.inl body_adaCoinStep)
      (Val.list [Val.int 0, encB false]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_adaCoinStep, coinAcc, encN, encB, ePair, eV, eLit, eHd, eTl, eEq, eIte, eLet,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, Nat.cast_zero, ne_eq, if_true, Bool.false_eq_true, if_false,
    not_true_eq_false, one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_⟩
  simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
    Nat.cast_zero, bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
  omega

theorem coinTail_lt {x r A D k : ℕ} (hxD : x < D) (hr : r ≠ 0)
    (hM : 3 * valSize (coinAcc r A D k) + 2 * bitLen (x : ℤ) + 30 ≤ M) :
    EvalsVal prog M [encN x, encN r, coinAcc r A D k] [] (.inl coinTail)
      (Val.list [Val.int 0, encB (decide (x < A))]) := by
  apply EvalsVal.of_eval (base := 0) 20
  have hxD' : (x : ℤ) < (D : ℤ) := by exact_mod_cast hxD
  simp only [coinTail, coinAcc, encN, encB, ePair, eV, eLit, eHd, eTl, eLt, eSub, eCons, eIte,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, hxD', if_true, ne_eq, one_ne_zero, not_false_eq_true,
    decide_eq_true_eq, Nat.cast_lt]
  refine ⟨_, _, rfl, ?_⟩
  simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
    bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
  have h01 : bitLen (if x < A then (1 : ℤ) else 0) ≤ 1 := by split_ifs <;> simp
  omega

theorem coinTail_ge {x r A D k : ℕ} (hxD : ¬ x < D) (hr : r ≠ 0)
    (hM : 3 * valSize (coinAcc r A D k) + 2 * bitLen (x : ℤ) + 30 ≤ M) :
    EvalsVal prog M [encN x, encN r, coinAcc r A D k] [] (.inl coinTail)
      (Val.list [Val.int 1, coinAcc (r - 1) A D k]) := by
  apply EvalsVal.of_eval (base := 0) 20
  have hxD' : ¬ (x : ℤ) < (D : ℤ) := by exact_mod_cast hxD
  have hr1 : ((r - 1 : ℕ) : ℤ) = (r : ℤ) - 1 := by omega
  simp only [coinTail, coinAcc, encN, encB, ePair, eV, eLit, eHd, eTl, eLt, eSub, eCons, eIte,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, hxD', if_false, ne_eq, not_true_eq_false, hr1]
  refine ⟨_, _, rfl, ?_⟩
  have hb1 : bitLen ((r : ℤ) - 1) ≤ bitLen (r : ℤ) := by
    rw [← hr1, bitLen_natCast, bitLen_natCast]; exact Nat.size_le_size (by omega)
  simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
    bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
  omega

theorem coinStep_try (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {r A D : ℕ} (bs : List Bool) (hr : r ≠ 0)
    (hM : 3 * valSize (coinAcc r A D bs.length) + S_readNat bs.length + 2 * bs.length + 30 ≤ M) :
    EvalsVal prog M [coinAcc r A D bs.length] bs (.inl body_adaCoinStep)
      (if natOfBits bs < D then Val.list [Val.int 0, encB (decide (natOfBits bs < A))]
       else Val.list [Val.int 1, coinAcc (r - 1) A D bs.length]) := by
  have hxk : bitLen (natOfBits bs : ℤ) ≤ bs.length := bitLen_natOfBits_le bs
  have hacc := valSize_coinAcc_le r A D bs.length
  have hsz : ∀ n : ℕ, valSize (encN n) = Nat.size n + 1 := valSize_encN
  have hr' : ((r : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hr
  have h1 : EvalsVal prog M [coinAcc r A D bs.length] [] (.inl (eHd (eV 0))) (encN r) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [coinAcc, encN, eV, eHd, eval_succ_var, eval_succ_un, evalUn, Option.bind_some,
      Option.map_some, List.getElem?_cons_zero]
    refine ⟨_, _, rfl, ?_⟩
    simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      max_le_iff] at hM ⊢
    omega
  have hc : EvalsVal prog M [encN r, coinAcc r A D bs.length] [] (.inl (eEq (eV 0) (eLit 0)))
      (Val.int 0) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [coinAcc, encN, eV, eLit, eEq, eval_succ_var, eval_succ_lit, eval_succ_bin, evalBin,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, hr', if_false]
    refine ⟨_, _, rfl, ?_⟩
    simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      bitLen_zero, max_le_iff] at hM ⊢
    omega
  have harg : EvalsVal prog M [encN r, coinAcc r A D bs.length] [] (.inl (eAt3 (eV 1)))
      (encN bs.length) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [coinAcc, encN, eV, eHd, eTl, eAt3, eval_succ_var, eval_succ_un, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ]
    refine ⟨_, _, rfl, ?_⟩
    simp only [coinAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      max_le_iff] at hM ⊢
    omega
  have hcall : EvalsVal prog M [encN r, coinAcc r A D bs.length] bs
      (.inl (eCall Idx.readNat (eAt3 (eV 1)))) (encN (natOfBits bs)) := by
    have := EvalsVal.call harg hr0 (readNat_val hrn bs (by omega))
    simpa using this
  by_cases hxD : natOfBits bs < D
  · rw [if_pos hxD]
    have hY := coinTail_lt (prog := prog) (M := M) (r := r) (A := A) (k := bs.length) hxD hr
      (by omega)
    have := EvalsVal.letE h1 (EvalsVal.ite_false (t := ePair (eLit 0) (eLit 0)) hc rfl
      (EvalsVal.letE hcall hY))
    exact this.cast_bits (by simp)
  · rw [if_neg hxD]
    have hY := coinTail_ge (prog := prog) (M := M) (r := r) (A := A) (k := bs.length) hxD hr
      (by omega)
    have := EvalsVal.letE h1 (EvalsVal.ite_false (t := ePair (eLit 0) (eLit 0)) hc rfl
      (EvalsVal.letE hcall hY))
    exact this.cast_bits (by simp)

end Steps

section Loops

variable {prog : List Expr} {M : ℕ}

/-- The value bound of `adaCoin` with at most `r0` trials. -/
def coinM (r0 A D k : ℕ) : ℕ :=
  3 * (Nat.size r0 + Nat.size A + Nat.size D + Nat.size k + 9) + S_readNat k + 2 * k + 30

theorem coin_loop (hstep : prog[Idx.adaCoinStep]? = some body_adaCoinStep)
    (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {A D k r0 : ℕ} (hk : k = Nat.clog 2 D)
    (hM : coinM r0 A D k ≤ M) :
    ∀ r, r ≤ r0 → ∀ bits b, (ratCoin A D r).run bits = some (b, []) →
      EvalsVal prog M [] bits (.inr (Idx.adaCoinStep, coinAcc r A D k)) (encB b) := by
  intro r
  induction r with
  | zero =>
    intro _ bits b h
    rw [ratCoin_zero] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    refine EvalsVal.stop hstep (coinStep_zero A D k ?_)
    have := valSize_coinAcc_le 0 A D k
    unfold coinM at hM
    simp only [Nat.size_zero] at this
    omega
  | succ r ih =>
    intro hr bits b h
    rw [ratCoin_succ] at h
    obtain ⟨b₁, b₂, x, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    obtain ⟨hlen, rfl⟩ := uniformBits_run_exact h1
    have hkl : b₁.length = k := by rw [hlen, hk]
    subst hkl
    have hsz : Nat.size (r + 1) ≤ Nat.size r0 := Nat.size_le_size hr
    have hstepv := coinStep_try (prog := prog) (M := M) (A := A) (D := D) hrn hr0 b₁
      (r := r + 1) (by omega) (by
        have := valSize_coinAcc_le (r + 1) A D b₁.length
        unfold coinM at hM
        omega)
    by_cases hxD : natOfBits b₁ < D
    · rw [if_pos hxD] at h2 hstepv
      obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
      exact (EvalsVal.stop hstep hstepv).cast_bits (by simp)
    · rw [if_neg hxD] at h2 hstepv
      exact EvalsVal.cont hstep hstepv one_ne_zero (ih (by omega) b₂ b h2)

/-- **Spec of `adaCoin`**: on `[r, A, D, ⌈log₂ D⌉]` it implements `ratCoin A D r`. -/
theorem coin_impl (hstep : prog[Idx.adaCoinStep]? = some body_adaCoinStep)
    (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {r A D k : ℕ} (hk : k = Nat.clog 2 D)
    (hM : coinM r A D k ≤ M) :
    Implements prog M [coinAcc r A D k] body_adaCoin encB (ratCoin A D r) := by
  intro bits b h
  exact (EvalsVal.loop EvalsVal.var0 (coin_loop hstep hrn hr0 hk hM r le_rfl bits b h)).cast_bits
    (by simp)

theorem valSize_countAcc_le (c K r A D k : ℕ) :
    valSize (countAcc c K r A D k) ≤
      Nat.size c + Nat.size K + Nat.size r + Nat.size A + Nat.size D + Nat.size k + 13 := by
  simp only [countAcc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

theorem countStep_zero (c r A D k : ℕ) (hM : 3 * valSize (countAcc c 0 r A D k) + 30 ≤ M) :
    EvalsVal prog M [countAcc c 0 r A D k] [] (.inl body_adaCountStep)
      (Val.list [Val.int 0, encN c]) := by
  apply EvalsVal.of_eval (base := 0) 20
  simp only [body_adaCountStep, countAcc, encN, ePair, eV, eLit, eHd, eTl, eAt1, eEq, eIte, eLet,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, Nat.cast_zero, ne_eq, if_true, one_ne_zero, not_false_eq_true]
  refine ⟨_, _, rfl, ?_⟩
  simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
    Nat.cast_zero, bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
  omega

theorem countTail_val {c K' r A D k : ℕ} (b : Bool) (hK : K' ≠ 0)
    (hM : 3 * valSize (countAcc c K' r A D k) + 3 * Nat.size (c + 1) + 40 ≤ M) :
    EvalsVal prog M [encB b, encN K', countAcc c K' r A D k] [] (.inl countTail)
      (if b then Val.list [Val.int 1, countAcc (c + 1) (K' - 1) r A D k]
       else Val.list [Val.int 0, encN c]) := by
  apply EvalsVal.of_eval (base := 0) 20
  have hK1 : ((K' - 1 : ℕ) : ℤ) = (K' : ℤ) - 1 := by omega
  have hc1 : ((c + 1 : ℕ) : ℤ) = (c : ℤ) + 1 := by push_cast; ring
  have hb1 : bitLen ((K' : ℤ) - 1) ≤ bitLen (K' : ℤ) := by
    rw [← hK1, bitLen_natCast, bitLen_natCast]; exact Nat.size_le_size (by omega)
  have hb2 : bitLen ((c : ℤ) + 1) = Nat.size (c + 1) := by rw [← hc1, bitLen_natCast]
  cases b with
  | true =>
    simp only [countTail, countAcc, encN, encB, ePair, eV, eLit, eHd, eTl, eAdd, eSub, eCons, eIte,
      eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
      evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, if_true, ne_eq, one_ne_zero, not_false_eq_true, hK1, hc1]
    refine ⟨_, _, rfl, ?_⟩
    simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
    omega
  | false =>
    simp only [countTail, countAcc, encN, encB, ePair, eV, eLit, eHd, eTl, eAdd, eSub, eCons, eIte,
      eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
      evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      List.getElem?_cons_succ, Bool.false_eq_true, if_false, ne_eq, not_true_eq_false]
    refine ⟨_, _, rfl, ?_⟩
    simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      bitLen_zero, bitLen_one, max_le_iff] at hM ⊢
    omega

theorem countStep_coin (hcoin : prog[Idx.adaCoin]? = some body_adaCoin) {c K' r A D k : ℕ}
    (hK : K' ≠ 0) {b1 : List Bool} {b : Bool}
    (hcall : EvalsVal prog M [coinAcc r A D k] b1 (.inl body_adaCoin) (encB b))
    (hM : 3 * valSize (countAcc c K' r A D k) + 3 * Nat.size (c + 1) + 40 ≤ M) :
    EvalsVal prog M [countAcc c K' r A D k] b1 (.inl body_adaCountStep)
      (if b then Val.list [Val.int 1, countAcc (c + 1) (K' - 1) r A D k]
       else Val.list [Val.int 0, encN c]) := by
  have hK' : ((K' : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hK
  have h1 : EvalsVal prog M [countAcc c K' r A D k] [] (.inl (eAt1 (eV 0))) (encN K') := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [countAcc, encN, eV, eHd, eTl, eAt1, eval_succ_var, eval_succ_un, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero]
    refine ⟨_, _, rfl, ?_⟩
    simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      max_le_iff] at hM ⊢
    omega
  have hc : EvalsVal prog M [encN K', countAcc c K' r A D k] [] (.inl (eEq (eV 0) (eLit 0)))
      (Val.int 0) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [countAcc, encN, eV, eLit, eEq, eval_succ_var, eval_succ_lit, eval_succ_bin, evalBin,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, hK', if_false]
    refine ⟨_, _, rfl, ?_⟩
    simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      bitLen_zero, max_le_iff] at hM ⊢
    omega
  have harg : EvalsVal prog M [encN K', countAcc c K' r A D k] [] (.inl (eTl (eTl (eV 1))))
      (coinAcc r A D k) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [countAcc, coinAcc, encN, eV, eTl, eval_succ_var, eval_succ_un, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ]
    refine ⟨_, _, rfl, ?_⟩
    simp only [countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      max_le_iff] at hM ⊢
    omega
  have hcall' : EvalsVal prog M [encN K', countAcc c K' r A D k] b1
      (.inl (eCall Idx.adaCoin (eTl (eTl (eV 1))))) (encB b) := by
    have := EvalsVal.call harg hcoin hcall
    simpa using this
  have hY := countTail_val (prog := prog) (M := M) (r := r) (A := A) (D := D) (k := k) (c := c) b hK
    hM
  have := EvalsVal.letE h1 (EvalsVal.ite_false (t := ePair (eLit 0) (eHd (eV 1))) hc rfl
    (EvalsVal.letE hcall' hY))
  exact this.cast_bits (by simp)

/-- The value bound of `adaCount` (and `adaLattice`). -/
def countM (K r A D k : ℕ) : ℕ :=
  3 * (2 * Nat.size K + Nat.size r + Nat.size A + Nat.size D + Nat.size k + 13) +
    3 * Nat.size (K + 1) + coinM r A D k + 40

theorem count_loop (hstep : prog[Idx.adaCountStep]? = some body_adaCountStep)
    (hcstep : prog[Idx.adaCoinStep]? = some body_adaCoinStep)
    (hcoin : prog[Idx.adaCoin]? = some body_adaCoin)
    (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {K r A D k : ℕ} (hk : k = Nat.clog 2 D)
    (hM : countM K r A D k ≤ M) :
    ∀ K', ∀ c, c + K' ≤ K → ∀ bits g,
      (DrawProg.toBits (fun _ => ratCoin A D r) (countSucc K')).run bits = some (g, []) →
      EvalsVal prog M [] bits (.inr (Idx.adaCountStep, countAcc c K' r A D k)) (encN (c + g)) := by
  intro K'
  induction K' with
  | zero =>
    intro c hc bits g h
    rw [toBits_countSucc_zero] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    refine EvalsVal.stop hstep (countStep_zero c r A D k ?_)
    have := valSize_countAcc_le c 0 r A D k
    have hcK : Nat.size c ≤ Nat.size K := Nat.size_le_size (by omega)
    unfold countM at hM
    simp only [Nat.size_zero] at this
    omega
  | succ K' ih =>
    intro c hc bits g h
    rw [toBits_countSucc_succ] at h
    obtain ⟨b₁, b₂, b, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    have hcall := coin_impl (prog := prog) (M := M) (r := r) hcstep hrn hr0 hk
      (by unfold countM at hM; omega) b₁ b h1
    have hcK : Nat.size c ≤ Nat.size K := Nat.size_le_size (by omega)
    have hcK1 : Nat.size (c + 1) ≤ Nat.size (K + 1) := Nat.size_le_size (by omega)
    have hK'K : Nat.size (K' + 1) ≤ Nat.size K := Nat.size_le_size (by omega)
    have hstepv := countStep_coin (prog := prog) (M := M) (c := c) hcoin (K' := K' + 1)
      (by omega) hcall (by
        have := valSize_countAcc_le c (K' + 1) r A D k
        unfold countM at hM
        omega)
    cases b with
    | true =>
      rw [if_pos rfl] at h2 hstepv
      rw [bitProg_run_map_exact] at h2
      obtain ⟨g', hg', rfl⟩ := h2
      have hrest := ih (c + 1) (by omega) b₂ g' hg'
      rw [show c + 1 + g' = c + (g' + 1) by ring] at hrest
      exact EvalsVal.cont hstep hstepv one_ne_zero (by simpa using hrest)
    | false =>
      rw [if_neg Bool.false_ne_true] at h2 hstepv
      obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
      exact (EvalsVal.stop hstep hstepv).cast_bits (by simp)

/-- The input of `adaCount` / `adaLattice`. -/
def latticeIn (K r A D k : ℕ) : Val := Val.list [encN K, encN r, encN A, encN D, encN k]

/-- **Spec of `adaCount`**: on `[K, r, A, D, ⌈log₂ D⌉]` it implements the capped count. -/
theorem count_impl (hstep : prog[Idx.adaCountStep]? = some body_adaCountStep)
    (hcstep : prog[Idx.adaCoinStep]? = some body_adaCoinStep)
    (hcoin : prog[Idx.adaCoin]? = some body_adaCoin)
    (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {K r A D k : ℕ} (hk : k = Nat.clog 2 D)
    (hM : countM K r A D k ≤ M) :
    Implements prog M [latticeIn K r A D k] body_adaCount encN
      (DrawProg.toBits (fun _ => ratCoin A D r) (countSucc K)) := by
  intro bits g h
  have hloop := count_loop hstep hcstep hcoin hrn hr0 hk hM K 0 (by omega) bits g h
  rw [zero_add] at hloop
  have hinit : EvalsVal prog M [latticeIn K r A D k] [] (.inl (eCons (eLit 0) (eV 0)))
      (countAcc 0 K r A D k) := by
    apply EvalsVal.of_eval (base := 0) 10
    simp only [latticeIn, countAcc, encN, eV, eLit, eCons, eval_succ_var, eval_succ_lit,
      eval_succ_bin, evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
      Nat.cast_zero]
    refine ⟨_, _, rfl, ?_⟩
    have := valSize_countAcc_le 0 K r A D k
    unfold countM at hM
    simp only [latticeIn, countAcc, encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
      bitLen_zero, Nat.cast_zero, max_le_iff, Nat.size_zero] at hM this ⊢
    omega
  exact (EvalsVal.loop hinit hloop).cast_bits (by simp)

/-- Exact runs of the capped count return at most `K`. -/
theorem countSucc_run_le (s : Unit → BitProg Bool) :
    ∀ K bits g, (DrawProg.toBits s (countSucc K)).run bits = some (g, []) → g ≤ K := by
  intro K
  induction K with
  | zero =>
    intro bits g h
    rw [toBits_countSucc_zero] at h
    obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
    exact le_rfl
  | succ K ih =>
    intro bits g h
    rw [toBits_countSucc_succ] at h
    obtain ⟨b₁, b₂, b, rfl, -, h2⟩ := bitProg_run_bind_exact.mp h
    cases b with
    | true =>
      rw [if_pos rfl, bitProg_run_map_exact] at h2
      obtain ⟨g', hg', rfl⟩ := h2
      have := ih b₂ g' hg'
      omega
    | false =>
      rw [if_neg Bool.false_ne_true] at h2
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h2
      omega

/-- `letE` for bit programs with a support condition on the first output. -/
theorem implements_letE_of {α β : Type} {env : List Val} {ea eb : Expr} {encA : α → Val}
    {encC : β → Val} {p : BitProg α} {f : α → BitProg β}
    (hp : Implements prog M env ea encA p) (Q : α → Prop)
    (hQ : ∀ bits a, p.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf a (hQ b₁ a h1) b₂ c h2)

/-- Calling a routine on a deterministic argument. -/
theorem implements_call_det' {β : Type} {env : List Val} {argE : Expr} {x : Val}
    {encB : β → Val} {p : BitProg β} {i : ℕ} {body : Expr}
    (hbody : prog[i]? = some body) (hA : EvalsVal prog M env [] (.inl argE) x)
    (hf : Implements prog M [x] body encB p) :
    Implements prog M env (Expr.call i argE) encB p := by
  intro bits c h
  have := EvalsVal.call hA hbody (hf bits c h)
  simpa using this

/-- **Spec of `adaLattice`**: on `[K, r, A, D, ⌈log₂ D⌉]` it implements `latticeSampler A D r K`. -/
theorem lattice_impl (hcnt : prog[Idx.adaCount]? = some body_adaCount)
    (hstep : prog[Idx.adaCountStep]? = some body_adaCountStep)
    (hcstep : prog[Idx.adaCoinStep]? = some body_adaCoinStep)
    (hcoin : prog[Idx.adaCoin]? = some body_adaCoin)
    (hrn : prog[Idx.readNatStep]? = some body_readNatStep)
    (hr0 : prog[Idx.readNat]? = some body_readNat) {K r A D k : ℕ} (hk : k = Nat.clog 2 D)
    (hM : countM K r A D k ≤ M) :
    Implements prog M [latticeIn K r A D k] body_adaLattice encZ (latticeSampler A D r K) := by
  rw [latticeSampler_eq]
  have hC := count_impl hstep hcstep hcoin hrn hr0 hk hM
  have hQ := countSucc_run_le (fun _ => ratCoin A D r) K
  refine implements_letE_of (implements_call_det' hcnt EvalsVal.var0 hC) (· ≤ K) hQ ?_
  intro g₁ hg₁
  show Implements prog M (encN g₁ :: [latticeIn K r A D k])
    (eLet (eCall Idx.adaCount (eV 1)) (eSub (eV 1) (eV 0))) encZ
    ((DrawProg.toBits (fun _ => ratCoin A D r) (countSucc K)).bind
      (BitProg.pure ∘ fun g₂ : ℕ => (g₁ : ℤ) - (g₂ : ℤ)))
  refine implements_letE_of (implements_call_det' hcnt EvalsVal.var1 hC) (· ≤ K) hQ ?_
  intro g₂ hg₂
  apply Implements.of_det
  apply EvalsVal.of_eval (base := 0) 10
  simp only [encN, encZ, eV, eSub, eval_succ_var, eval_succ_bin, evalBin, Option.bind_some,
    Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ, Function.comp]
  refine ⟨_, _, rfl, ?_⟩
  have h1 : bitLen (g₁ : ℤ) ≤ Nat.size K := by rw [bitLen_natCast]; exact Nat.size_le_size hg₁
  have h2 : bitLen (g₂ : ℤ) ≤ Nat.size K := by rw [bitLen_natCast]; exact Nat.size_le_size hg₂
  have h3 := bitLen_add_le (g₁ : ℤ) (-(g₂ : ℤ))
  rw [bitLen_neg, ← sub_eq_add_neg] at h3
  unfold countM at hM
  simp only [valSize_int, max_le_iff]
  omega

end Loops

end F2e2e.Cost.AdaDSL
