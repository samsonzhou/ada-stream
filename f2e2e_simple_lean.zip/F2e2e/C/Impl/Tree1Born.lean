import F2e2e.C.Impl.Tree1Facts

/-!
# W6, Tree1: the first born depth `firstBorn H tr` (DSL)

`firstBorn H tr = (List.range H).findIdx (bornAt H · tr)` with
`bornAt H d tr = ((tr - 1) % 2^{H-1-d} == 0)` (C-ALG, `F2e2e/C/Alg/Round.lean` L50–59;
Definition `R:def:binary-tree-architecture` (1), `parts/partIII.tex` L431). The loop (Idx 292) scans
`d = 0, 1, …` on the accumulator `[d, H, tr]` and stops at the first born depth (which exists, since
depth `H - 1` is born every round: `firstBorn_lt`). Spec: `firstBorn_val`.
-/

namespace F2e2e.C.Impl.T1

open F2e2e F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

/-- The loop state `[d, H, tr]` of `firstBorn`. -/
def fbAcc (d H tr : ℕ) : Val := Val.list [encN d, encN H, encN tr]

theorem valSize_fbAcc (d H tr : ℕ) :
    valSize (fbAcc d H tr) = Nat.size d + Nat.size H + Nat.size tr + 7 := by
  simp only [fbAcc, valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega

/-- The value bound of `firstBorn` (for `H` depths and the round `tr`). -/
def fbM (H tr : ℕ) : ℕ := 8 * (H + Nat.size tr) + S_pow2 H + 100

theorem bornAt_iff (H d tr : ℕ) : bornAt H d tr = true ↔ (tr - 1) % 2 ^ (H - 1 - d) = 0 := by
  simp [bornAt]

section Step

variable {prog : List Expr} {M : ℕ}

/-- The divisibility test of the loop body (`d < H`). -/
theorem firstBorn_test (hT : Tree1Lib prog) {d H tr : ℕ} (hdH : d < H) (htr : 1 ≤ tr)
    (hM : fbM H tr ≤ M) :
    EvalsVal prog M [encN d, fbAcc d H tr] []
      (.inl (Expr.bin BinOp.eq
          (Expr.bin BinOp.mod (Expr.bin BinOp.sub (eGet 2 (Expr.var 1)) (Expr.lit 1))
            (Expr.call F2e2e.Cost.Idx.pow2
              (Expr.bin BinOp.sub (Expr.bin BinOp.sub (eGet 1 (Expr.var 1)) (Expr.lit 1))
                (Expr.var 0))))
          (Expr.lit 0)))
      (Val.int (if (tr - 1) % 2 ^ (H - 1 - d) = 0 then 1 else 0)) := by
  have hs := valSize_fbAcc d H tr
  have hsd : Nat.size d ≤ H := (size_le_self d).trans hdH.le
  have hsH := size_le_self H
  have hS : S_pow2 (H - 1 - d) ≤ S_pow2 H := by
    unfold S_pow2
    have := Nat.size_le_size (show H - 1 - d ≤ H by omega)
    omega
  simp only [fbM] at hM
  have hacc : valSize (Val.list [encN d, encN H, encN tr]) ≤ M := by
    have : valSize (Val.list [encN d, encN H, encN tr]) = valSize (fbAcc d H tr) := rfl
    omega
  have hX : EvalsVal prog M [encN d, fbAcc d H tr] [] (.inl (Expr.var 1))
      (Val.list [encN d, encN H, encN tr]) := EvalsVal.var rfl
  have htrv := ev_get 2 hX hacc rfl
  have hHv := ev_get 1 hX hacc rfl
  -- `tr - 1`
  have e1 : ((tr : ℤ) - 1) = ((tr - 1 : ℕ) : ℤ) := by omega
  have hb1 : bitLen ((tr - 1 : ℕ) : ℤ) ≤ Nat.size tr := bitLen_le_size_of_le (by omega)
  have hsub1 := EvalsVal.sub (y := 1) htrv (EvalsVal.lit' (by simp only [valSize_int, bitLen_one]; omega))
    (by rw [show ((tr : ℕ) : ℤ) = (tr : ℤ) from rfl, e1, valSize_int]; omega)
  rw [show ((tr : ℕ) : ℤ) = (tr : ℤ) from rfl, e1] at hsub1
  -- `H - 1 - d`
  have e2 : ((H : ℤ) - 1) = ((H - 1 : ℕ) : ℤ) := by omega
  have e3 : ((H - 1 : ℕ) : ℤ) - (d : ℤ) = ((H - 1 - d : ℕ) : ℤ) := by omega
  have hb2 : bitLen ((H - 1 : ℕ) : ℤ) ≤ Nat.size H := bitLen_le_size_of_le (by omega)
  have hb3 : bitLen ((H - 1 - d : ℕ) : ℤ) ≤ Nat.size H := bitLen_le_size_of_le (by omega)
  have hsubH := EvalsVal.sub (y := 1) hHv (EvalsVal.lit' (by simp only [valSize_int, bitLen_one]; omega))
    (by rw [show ((H : ℕ) : ℤ) = (H : ℤ) from rfl, e2, valSize_int]; omega)
  rw [show ((H : ℕ) : ℤ) = (H : ℤ) from rfl, e2] at hsubH
  have hk := EvalsVal.sub hsubH (EvalsVal.var0 (v := encN d) (rest := [fbAcc d H tr]))
    (by rw [show (encN d) = Val.int (d : ℤ) from rfl] at *; rw [e3, valSize_int]; omega)
  rw [e3] at hk
  -- `2^(H-1-d)`
  have hpow := evalsVal_call_det hT.pow2 hk
    (((pow2_spec hT.pow2Step (H - 1 - d) 0).toVal).mono_M (by omega))
  -- `(tr - 1) % 2^(H-1-d)`
  have hpos : ((2 ^ (H - 1 - d) : ℕ) : ℤ) ≠ 0 := by positivity
  have e4 : ((tr - 1 : ℕ) : ℤ) % ((2 ^ (H - 1 - d) : ℕ) : ℤ) = (((tr - 1) % 2 ^ (H - 1 - d) : ℕ) : ℤ) :=
    (Int.natCast_mod _ _).symm
  have hb4 : bitLen ((((tr - 1) % 2 ^ (H - 1 - d) : ℕ)) : ℤ) ≤ Nat.size tr :=
    bitLen_le_size_of_le ((Nat.mod_le _ _).trans (by omega))
  have hmod := EvalsVal.mod hsub1 hpow hpos (by rw [e4, valSize_int]; omega)
  rw [e4] at hmod
  have heq := EvalsVal.eq (y := 0) hmod (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega))
    (by omega)
  have e5 : ((((tr - 1) % 2 ^ (H - 1 - d) : ℕ) : ℤ) = 0) ↔ ((tr - 1) % 2 ^ (H - 1 - d) = 0) :=
    Nat.cast_eq_zero
  simp only [e5, List.append_nil] at heq
  exact heq

theorem firstBornStep_found (hT : Tree1Lib prog) {d H tr : ℕ} (hdH : d < H) (htr : 1 ≤ tr)
    (hM : fbM H tr ≤ M) (hb : (tr - 1) % 2 ^ (H - 1 - d) = 0) :
    EvalsVal prog M [fbAcc d H tr] [] (.inl body_firstBornStep) (Val.list [Val.int 0, encN d]) := by
  have hs := valSize_fbAcc d H tr
  have hsd : Nat.size d ≤ H := (size_le_self d).trans hdH.le
  have hsH := size_le_self H
  have hS0 : 100 ≤ S_pow2 H := by unfold S_pow2; omega
  simp only [fbM] at hM
  have hacc : valSize (Val.list [encN d, encN H, encN tr]) ≤ M := by
    have : valSize (Val.list [encN d, encN H, encN tr]) = valSize (fbAcc d H tr) := rfl
    omega
  have hX : EvalsVal prog M [fbAcc d H tr] [] (.inl (Expr.var 0))
      (Val.list [encN d, encN H, encN tr]) := EvalsVal.var rfl
  refine ev_letE (ev_get 0 hX hacc rfl) ?_
  have hX1 : EvalsVal prog M [encN d, fbAcc d H tr] [] (.inl (Expr.var 1))
      (Val.list [encN d, encN H, encN tr]) := EvalsVal.var rfl
  have hlt : EvalsVal prog M [encN d, fbAcc d H tr] []
      (.inl (Expr.bin BinOp.lt (Expr.var 0) (eGet 1 (Expr.var 1)))) (Val.int 1) := by
    have := EvalsVal.lt (EvalsVal.var0 (v := encN d) (rest := [fbAcc d H tr]))
      (ev_get 1 hX1 hacc rfl) (by omega)
    simpa [encN, hdH] using this
  refine ev_ite_true hlt one_ne_zero ?_
  refine ev_ite_true (firstBorn_test hT hdH htr (by simp only [fbM]; omega)) (by simp [hb]) ?_
  exact ev_list (.cons (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega))
    (.cons EvalsVal.var0 .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN,
          bitLen_zero]; omega)

theorem firstBornStep_next (hT : Tree1Lib prog) {d H tr : ℕ} (hdH : d < H) (htr : 1 ≤ tr)
    (hM : fbM H tr ≤ M) (hb : (tr - 1) % 2 ^ (H - 1 - d) ≠ 0) :
    EvalsVal prog M [fbAcc d H tr] [] (.inl body_firstBornStep)
      (Val.list [Val.int 1, fbAcc (d + 1) H tr]) := by
  have hs := valSize_fbAcc d H tr
  have hs' := valSize_fbAcc (d + 1) H tr
  have hsd : Nat.size (d + 1) ≤ H := (size_le_self (d + 1)).trans hdH
  have hsd0 : Nat.size d ≤ H := (size_le_self d).trans hdH.le
  have hsH := size_le_self H
  have hS0 : 100 ≤ S_pow2 H := by unfold S_pow2; omega
  simp only [fbM] at hM
  have hacc : valSize (Val.list [encN d, encN H, encN tr]) ≤ M := by
    have : valSize (Val.list [encN d, encN H, encN tr]) = valSize (fbAcc d H tr) := rfl
    omega
  have hX : EvalsVal prog M [fbAcc d H tr] [] (.inl (Expr.var 0))
      (Val.list [encN d, encN H, encN tr]) := EvalsVal.var rfl
  refine ev_letE (ev_get 0 hX hacc rfl) ?_
  have hX1 : EvalsVal prog M [encN d, fbAcc d H tr] [] (.inl (Expr.var 1))
      (Val.list [encN d, encN H, encN tr]) := EvalsVal.var rfl
  have hlt : EvalsVal prog M [encN d, fbAcc d H tr] []
      (.inl (Expr.bin BinOp.lt (Expr.var 0) (eGet 1 (Expr.var 1)))) (Val.int 1) := by
    have := EvalsVal.lt (EvalsVal.var0 (v := encN d) (rest := [fbAcc d H tr]))
      (ev_get 1 hX1 hacc rfl) (by omega)
    simpa [encN, hdH] using this
  refine ev_ite_true hlt one_ne_zero ?_
  refine ev_ite_false (firstBorn_test hT hdH htr (by simp only [fbM]; omega)) (by simp [hb]) ?_
  have hd1 : EvalsVal prog M [encN d, fbAcc d H tr] []
      (.inl (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1))) (encN (d + 1)) := by
    have := ev_add (EvalsVal.var0 (v := Val.int (d : ℤ)) (rest := [fbAcc d H tr]))
      (EvalsVal.lit' (prog := prog) (M := M) (z := 1)
        (by simp only [valSize_int, bitLen_one]; omega))
      (by
        have : valSize (Val.int ((d : ℤ) + 1)) = Nat.size (d + 1) + 1 := by
          rw [valSize_int, show ((d : ℤ) + 1) = ((d + 1 : ℕ) : ℤ) by push_cast; ring, bitLen_natCast]
        omega)
    rw [show ((d : ℤ) + 1) = ((d + 1 : ℕ) : ℤ) by push_cast; ring] at this
    exact this
  have hinner := ev_list (prog := prog) (M := M) (.cons hd1 (.cons (ev_get 1 hX1 hacc rfl)
    (.cons (ev_get 2 hX1 hacc rfl) .nil)))
    (show valSize (Val.list [encN (d + 1), encN H, encN tr]) ≤ M by
      have : valSize (Val.list [encN (d + 1), encN H, encN tr]) = valSize (fbAcc (d + 1) H tr) := rfl
      omega)
  exact ev_list (.cons (EvalsVal.lit' (by simp only [valSize_int, bitLen_one]; omega))
    (.cons hinner .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one]
        have : valSize (Val.list [encN (d + 1), encN H, encN tr]) = valSize (fbAcc (d + 1) H tr) := rfl
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN] at this
        omega)

end Step

/-! ## The loop and the spec -/

section Loop

variable {prog : List Expr} {M : ℕ}

theorem firstBorn_loop (hT : Tree1Lib prog) {H tr : ℕ} (hH : 1 ≤ H) (htr : 1 ≤ tr)
    (hM : fbM H tr ≤ M) :
    ∀ k d, d + k = firstBorn H tr →
      EvalsVal prog M [] [] (.inr (Idx.firstBornStep, fbAcc d H tr)) (encN (firstBorn H tr)) := by
  have hF := firstBorn_lt H tr hH
  intro k
  induction k with
  | zero =>
    intro d hd
    simp only [Nat.add_zero] at hd
    subst hd
    have hb : bornAt H (firstBorn H tr) tr = true := by
      have hlt : (List.range H).findIdx (fun d => bornAt H d tr) < (List.range H).length := by
        simpa [firstBorn] using hF
      have := List.findIdx_getElem (w := hlt)
      simpa [firstBorn] using this
    refine EvalsVal.stop hBody (firstBornStep_found hT hF htr hM ((bornAt_iff _ _ _).mp hb))
  | succ k ih =>
    intro d hd
    have hdF : d < firstBorn H tr := by omega
    have hb : bornAt H d tr = false := by
      have hlt : d < (List.range H).findIdx (fun d => bornAt H d tr) := by simpa [firstBorn] using hdF
      have := List.not_of_lt_findIdx hlt
      simpa using this
    have hb' : (tr - 1) % 2 ^ (H - 1 - d) ≠ 0 := by
      intro h
      rw [(bornAt_iff _ _ _).mpr h] at hb
      exact Bool.noConfusion hb
    exact EvalsVal.cont hBody (firstBornStep_next hT (by omega) htr hM hb') one_ne_zero
      (ih (d + 1) (by omega))
where
  hBody : prog[Idx.firstBornStep]? = some body_firstBornStep := hT.firstBornStep

/-- **Spec of `firstBorn`**: `[H, tr] ↦ firstBorn H tr` (for `H ≥ 1`, `tr ≥ 1`). -/
theorem firstBorn_val (hT : Tree1Lib prog) {H tr : ℕ} (hH : 1 ≤ H) (htr : 1 ≤ tr)
    (hM : fbM H tr ≤ M) :
    EvalsVal prog M [Val.list [encN H, encN tr]] [] (.inl body_firstBorn)
      (encN (firstBorn H tr)) := by
  have hl := firstBorn_loop hT hH htr hM (firstBorn H tr) 0 (by omega)
  have hsH := size_le_self H
  have hS0 : 100 ≤ S_pow2 H := by unfold S_pow2; omega
  simp only [fbM] at hM
  have hinit : EvalsVal prog M [Val.list [encN H, encN tr]] []
      (.inl (Expr.bin BinOp.cons (Expr.lit 0) (Expr.var 0))) (fbAcc 0 H tr) := by
    have := EvalsVal.cons (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.list [encN H, encN tr]]) (z := 0) (by simp only [valSize_int, bitLen_zero]; omega))
      (EvalsVal.var0 (v := Val.list [encN H, encN tr]) (rest := []))
      (by
        have := valSize_fbAcc 0 H tr
        simp only [fbAcc, valSize_list, listSize_cons, listSize_nil, valSize_encN, Nat.size_zero,
          valSize_int, bitLen_zero] at this ⊢
        omega)
    simpa [fbAcc, encN] using this
  simpa [body_firstBorn] using EvalsVal.loop hinit hl

end Loop

end F2e2e.C.Impl.T1
