import F2e2e.C.Impl.Tree4Defs
import F2e2e.C.Impl.W6Facts
import F2e2e.C.SpaceSteps
import F2e2e.C.SpaceRegs

/-!
# W6, Tree4: semantic facts about Step 4 (no DSL)

* Released values (C-SPACE's `release_grid`, `F2e2e/C/SpaceRegs.lean`) are on the grid.
* The grid `2^{-regBits P} ℤ` (`OnGrid`) and the invariant `FOK` of the value `F` threaded
  through Step 4 (`0 ≤ F ≤ A_max`, on the grid); `FOK.qok`, the `QOK` facts for the arguments of
  `inRangeA`, `validate`, `stepCoeffMant`, `roundMantQ`; the threshold `θ` (`theta_*`).
* `step4Loop` is DSL-CALC's `foldB` with the step `step4Step` (`step4Loop_eq_foldB`).
* The value threaded through Step 4 always satisfies `FOK` (`step4Depth_fok`, `step4Loop_fok`,
  `step4_fok`), and the deliverable's semantic half `step4_out` is derived in `Tree4.lean`.
* `countCorrection_withCache`: the counters do not look at the cache.
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating the parameters. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Parameter bounds at the scale `regBits P = 2^7 ℒ³` -/

theorem regBits_eq (P : StreamParams) : regBits P = 128 * P.calL ^ 3 := by
  unfold regBits; norm_num

theorem one_le_calL_cube (P : StreamParams) : 1 ≤ P.calL ^ 3 :=
  Nat.one_le_pow _ _ (by have := hundred_le_calL P; omega)

theorem eHP_le_R (P : StreamParams) : P.eHP ≤ regBits P := by
  have := eHP_le P; have := hundred_mul_sq_le_cube P; rw [regBits_eq]; omega

theorem eHleaf_le_R (P : StreamParams) : P.eHleaf ≤ regBits P := by
  have := eHleaf_le P; have := hundred_mul_sq_le_cube P; rw [regBits_eq]; omega

theorem eEta_le_R (P : StreamParams) : P.eEta ≤ regBits P := by
  have := eEta_le P; have := hundred_mul_calL_le_sq P; have := hundred_mul_sq_le_cube P
  rw [regBits_eq]; omega

theorem eHstep_le_R (P : StreamParams) : P.eHstep ≤ regBits P := by
  have := eHstep_le P; have := hundred_mul_calL_le_sq P; have := hundred_mul_sq_le_cube P
  rw [regBits_eq]; omega

theorem eAmax_le_R (P : StreamParams) : P.eAmax ≤ regBits P := by
  have := eAmax_le P; rw [regBits_eq]; omega

theorem eHC_le_R (P : StreamParams) : P.eHC ≤ regBits P := by
  have := eHC_le P; rw [regBits_eq]; omega

theorem eCmax_le_R (P : StreamParams) : P.eCmax ≤ regBits P := by
  have := eCmax_le P; have := hundred_mul_sq_le_cube P; rw [regBits_eq]; omega

theorem H_le_R (P : StreamParams) : P.H ≤ regBits P := by
  have := H_le P; have := hundred_mul_calL_le_sq P; have := hundred_mul_sq_le_cube P
  rw [regBits_eq]; omega

theorem Amax_eq (P : StreamParams) : (P.Amax : ℚ) = 2 ^ P.eAmax := by
  unfold StreamParams.Amax; push_cast; rfl

theorem Amax_eq_int (P : StreamParams) : (P.Amax : ℤ) = 2 ^ P.eAmax := by
  unfold StreamParams.Amax; push_cast; rfl

theorem two_pow_le_two_pow_q {a b : ℕ} (h : a ≤ b) : (2 : ℚ) ^ a ≤ 2 ^ b :=
  pow_le_pow_right₀ (by norm_num) h

/-! ## The grid `2^{-regBits P} ℤ` and the invariant of the threaded value -/

/-- `x` lies on the grid `2^{-regBits P} ℤ`. -/
def OnGrid (P : StreamParams) (x : ℚ) : Prop := ∃ m : ℤ, x = (m : ℚ) / 2 ^ regBits P

/-- **The invariant of the value `F` threaded through Step 4**: `0 ≤ F ≤ A_max`, on the grid
`2^{-regBits P} ℤ` (`F` is the terminal accumulator `gridVal eHleaf leaf`, a candidate
`S_d = P_d + Q̂_d`, a released `N₁` or `0`). -/
def FOK (P : StreamParams) (F : ℚ) : Prop := 0 ≤ F ∧ F ≤ (P.Amax : ℚ) ∧ OnGrid P F

theorem onGrid_zero (P : StreamParams) : OnGrid P 0 := ⟨0, by simp⟩

theorem onGrid_gridVal {P : StreamParams} {e : ℕ} (he : e ≤ regBits P) (m : ℤ) :
    OnGrid P (gridVal e m) := by
  refine ⟨m * 2 ^ (regBits P - e), ?_⟩
  unfold gridVal
  have h2 : (2 : ℚ) ^ regBits P = 2 ^ e * 2 ^ (regBits P - e) := by
    rw [← pow_add]; congr 1; omega
  rw [h2]
  push_cast
  field_simp

theorem OnGrid.add {P : StreamParams} {x y : ℚ} (hx : OnGrid P x) (hy : OnGrid P y) :
    OnGrid P (x + y) := by
  obtain ⟨a, rfl⟩ := hx
  obtain ⟨b, rfl⟩ := hy
  exact ⟨a + b, by push_cast; ring⟩

/-- A grid value of absolute value `≤ 2^{3 regBits}` is `QOK`. -/
theorem qok_of_onGrid {P : StreamParams} {x : ℚ} (hx : OnGrid P x)
    (hb : |x| ≤ 2 ^ (3 * regBits P)) : QOK P x := by
  obtain ⟨m, rfl⟩ := hx
  have hpos : (0 : ℤ) < 2 ^ regBits P := by positivity
  have hposq : (0 : ℚ) < 2 ^ regBits P := by positivity
  have hcast : ((m : ℚ) / 2 ^ regBits P) = (m : ℚ) / ((2 ^ regBits P : ℤ) : ℚ) := by
    push_cast; ring
  have h1 := div_num_abs_le m (2 ^ regBits P) hpos
  have h2 := div_den_le m (2 ^ regBits P) hpos
  rw [← hcast] at h1 h2
  have hm : |m| ≤ 2 ^ (4 * regBits P) := by
    rw [abs_div, abs_of_pos hposq, div_le_iff₀ hposq, ← pow_add] at hb
    have e : 3 * regBits P + regBits P = 4 * regBits P := by ring
    rw [e] at hb
    have : ((|m| : ℤ) : ℚ) ≤ ((2 ^ (4 * regBits P) : ℤ) : ℚ) := by push_cast; exact hb
    exact_mod_cast this
  refine ⟨h1.trans hm, h2.trans ?_⟩
  exact pow_le_pow_right₀ (by norm_num) (by omega)

theorem fok_zero (P : StreamParams) : FOK P 0 :=
  ⟨le_rfl, by positivity, onGrid_zero P⟩

theorem FOK.qok {P : StreamParams} {F : ℚ} (h : FOK P F) : QOK P F := by
  obtain ⟨h0, h1, hg⟩ := h
  refine qok_of_onGrid hg ?_
  rw [abs_of_nonneg h0]
  refine h1.trans ?_
  rw [Amax_eq]
  exact two_pow_le_two_pow_q (by have := eAmax_le_R P; omega)

theorem fok_of_inRange {P : StreamParams} {x : ℚ} (hx : OnGrid P x) (hr : inRangeA P x = true) :
    FOK P x := by
  obtain ⟨h0, h1⟩ := (inRangeA_iff P x).mp hr
  exact ⟨h0, h1, hx⟩

/-- A released value (C-SPACE's `release_grid`) is `QOK`. -/
theorem qok_of_release {P : StreamParams} {N : ℚ}
    (h : 0 ≤ N ∧ N ≤ 2 ^ regBits P ∧ ∃ m : ℤ, N = (m : ℚ) / 2 ^ regBits P) : QOK P N := by
  obtain ⟨h0, h1, hg⟩ := h
  refine qok_of_onGrid hg ?_
  rw [abs_of_nonneg h0]
  exact h1.trans (two_pow_le_two_pow_q (by omega))

/-- A released value that passed the range check satisfies `FOK`. -/
theorem fok_of_release {P : StreamParams} {N : ℚ}
    (h : 0 ≤ N ∧ N ≤ 2 ^ regBits P ∧ ∃ m : ℤ, N = (m : ℚ) / 2 ^ regBits P)
    (hr : inRangeA P N = true) : FOK P N :=
  fok_of_inRange h.2.2 hr

theorem gridVal_nonneg {e : ℕ} {m : ℤ} (hm : 0 ≤ m) : 0 ≤ gridVal e m := by
  unfold gridVal; positivity

theorem gridVal_le_of_le {e : ℕ} {m : ℤ} {A : ℚ} (hm : (m : ℚ) ≤ A * 2 ^ e) : gridVal e m ≤ A := by
  unfold gridVal
  rw [div_le_iff₀ (by positivity)]
  exact hm

/-- The candidate `S = gridVal eHP cache + F` (before its range check) is on the grid. -/
theorem onGrid_S {P : StreamParams} (cache : ℤ) {F : ℚ} (hF : OnGrid P F) :
    OnGrid P (gridVal P.eHP cache + F) :=
  (onGrid_gridVal (eHP_le_R P) cache).add hF

/-- The candidate `S = gridVal eHP cache + F` is `QOK` (cache of a `LearnerOK 4` learner). -/
theorem qok_S {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) {F : ℚ} (hF : FOK P F) :
    QOK P (gridVal P.eHP L.cache + F) := by
  refine qok_of_onGrid (onGrid_S L.cache hF.2.2) ?_
  have hc0 : 0 ≤ gridVal P.eHP L.cache := gridVal_nonneg hL.cache_nonneg
  have hc1 : gridVal P.eHP L.cache ≤ 4 * (P.Amax : ℚ) := by
    apply gridVal_le_of_le
    have := hL.cache_le
    have h' : (L.cache : ℚ) ≤ ((4 : ℕ) : ℚ) * ((P.Amax : ℚ) * 2 ^ P.eHP) := by exact_mod_cast this
    push_cast at h'
    linarith
  rw [abs_of_nonneg (by linarith [hF.1])]
  have hA : (P.Amax : ℚ) = 2 ^ P.eAmax := Amax_eq P
  have h8 : (8 : ℚ) * 2 ^ P.eAmax = 2 ^ (P.eAmax + 3) := by rw [pow_add]; norm_num; ring
  have hle : (2 : ℚ) ^ (P.eAmax + 3) ≤ 2 ^ (3 * regBits P) :=
    two_pow_le_two_pow_q (by have := eAmax_le_R P; have := regBits_eq P
                             have := one_le_calL_cube P; omega)
  linarith [hF.2.1]

/-- `P_d = gridVal eHP cache` of a `LearnerOK 4` learner is `QOK`. -/
theorem qok_cache {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) :
    QOK P (gridVal P.eHP L.cache) := by
  have hb := SizeAux.bitLen_cache_le hL
  refine qok_gridVal (k := P.eAmax + P.eHP + 3) ?_ ?_ ?_
  · have h1 : |L.cache| ≤ 2 ^ (P.eAmax + P.eHP + 2) := by
      rw [abs_of_nonneg hL.cache_nonneg]
      have := hL.cache_le
      rw [Amax_eq_int] at this
      calc L.cache ≤ ((4 : ℕ) : ℤ) * (2 ^ P.eAmax * 2 ^ P.eHP) := this
        _ = 2 ^ (P.eAmax + P.eHP + 2) := by push_cast; ring
    calc |L.cache| ≤ 2 ^ (P.eAmax + P.eHP + 2) := h1
      _ < 2 ^ (P.eAmax + P.eHP + 3) := pow_lt_pow_right₀ (by norm_num) (by omega)
  · have := eAmax_le_R P; have := eHP_le_R P; have := regBits_eq P
    have := one_le_calL_cube P; omega
  · have := eHP_le_R P; omega

/-! ## The threshold `θ_ℓ = (8ℓ + 4) η` -/

theorem theta_eq (P : StreamParams) {d : ℕ} (hd : d < P.H) :
    (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta =
      (((8 * ((P.H : ℤ) - d) + 4 : ℤ)) : ℚ) / (((2 ^ P.eEta : ℕ) : ℤ) : ℚ) := by
  unfold StreamParams.eta
  rw [Nat.cast_sub hd.le]
  push_cast
  rw [one_div_pow]
  field_simp

theorem eight_H_add_four_le (P : StreamParams) : 8 * P.H + 4 ≤ 2 ^ P.eEta := by
  have h1 : (P.H + 1) ^ 2 ≤ 2 ^ Nat.clog 2 ((P.H + 1) ^ 2) := Nat.le_pow_clog (by norm_num) _
  have h2 : 2 ^ P.eEta = 2 ^ 20 * 2 ^ P.epsExp * 2 ^ Nat.clog 2 ((P.H + 1) ^ 2) := by
    unfold StreamParams.eEta; rw [pow_add, pow_add]
  have h3 : 1 ≤ 2 ^ P.epsExp := Nat.one_le_two_pow
  have h4 : 8 * P.H + 4 ≤ 2 ^ 20 * (P.H + 1) ^ 2 := by nlinarith
  calc 8 * P.H + 4 ≤ 2 ^ 20 * (P.H + 1) ^ 2 := h4
    _ ≤ 2 ^ 20 * 2 ^ Nat.clog 2 ((P.H + 1) ^ 2) := Nat.mul_le_mul_left _ h1
    _ ≤ 2 ^ 20 * 2 ^ P.epsExp * 2 ^ Nat.clog 2 ((P.H + 1) ^ 2) := by
        apply Nat.mul_le_mul_right; nlinarith
    _ = 2 ^ P.eEta := h2.symm

theorem theta_facts (P : StreamParams) {d : ℕ} (hd : d < P.H) :
    0 < (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta ∧ (8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta ≤ 1 ∧
      (((8 * ((P.H - d : ℕ) : ℚ) + 4) * P.eta).den : ℤ) ≤ 2 ^ (2 * regBits P) := by
  rw [theta_eq P hd]
  have hpos : (0 : ℤ) < ((2 ^ P.eEta : ℕ) : ℤ) := by positivity
  have ha : (0 : ℤ) < 8 * ((P.H : ℤ) - d) + 4 := by omega
  have hle : 8 * ((P.H : ℤ) - d) + 4 ≤ ((2 ^ P.eEta : ℕ) : ℤ) := by
    have := eight_H_add_four_le P
    have h' : (8 * P.H + 4 : ℤ) ≤ ((2 ^ P.eEta : ℕ) : ℤ) := by exact_mod_cast this
    omega
  refine ⟨?_, ?_, ?_⟩
  · have ha' : (0 : ℚ) < ((8 * ((P.H : ℤ) - d) + 4 : ℤ) : ℚ) := by exact_mod_cast ha
    have hpos' : (0 : ℚ) < (((2 ^ P.eEta : ℕ) : ℤ) : ℚ) := by exact_mod_cast hpos
    exact div_pos ha' hpos'
  · have hpos' : (0 : ℚ) < (((2 ^ P.eEta : ℕ) : ℤ) : ℚ) := by exact_mod_cast hpos
    rw [div_le_one hpos']
    exact_mod_cast hle
  · refine (div_den_le _ _ hpos).trans ?_
    push_cast
    exact pow_le_pow_right₀ (by norm_num) (by have := eEta_le_R P; omega)

/-! ## `step4Loop` as DSL-CALC's `foldB` -/

/-- The step of the fold: a failed state is kept, otherwise one depth. -/
def step4Step (P : StreamParams) (d : ℕ) (r : State × ℚ) : BitProg (State × ℚ) :=
  if r.1.failed then BitProg.pure r else step4Depth P d r.1 r.2

theorem step4Loop_eq_foldB (P : StreamParams) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), step4Loop P ds s F = foldB (step4Step P) ds (s, F)
  | [], s, F => rfl
  | d :: ds, s, F => by
    rw [foldB_cons]
    simp only [step4Loop, step4Step, bp_bind_eq, bp_pure_eq]
    split_ifs with hf
    · rw [BitProg.bind_pure']
      exact (foldB_of_stop (fun r : State × ℚ => r.1.failed)
        (fun d r => step4Depth P d r.1 r.2) ds (s, F) hf).symm
    · congr 1
      funext r
      exact step4Loop_eq_foldB P ds r.1 r.2

/-! ## The counters do not look at the cache -/

theorem countCorrection_withCache (P : StreamParams) (L : Learner) (c : ℤ) :
    Learner.countCorrection P { L with cache := c } =
      (Learner.countCorrection P L).map (fun L' => { L' with cache := c }) := by
  unfold Learner.countCorrection
  by_cases h1 : L.jEpoch + 1 = P.K0
  · by_cases h2 : L.epoch + 1 ≤ P.Kepoch
    · simp [h1, h2]
    · simp [h1, h2]
  · simp [h1]

/-! ## The threaded value always satisfies `FOK` -/

theorem rejectReleaseRef_val (P : StreamParams) (d : ℕ) (Ld : Learner) (N1 : ℚ) (s1 : State) :
    Always (rejectReleaseRef P d Ld N1 s1) (fun r => r.2 = N1 ∨ r.2 = 0) := by
  unfold rejectReleaseRef
  split
  · exact always_pure (Or.inr rfl)
  · simp only [bp_bind_eq, bp_pure_eq]
    refine Always.bind_all (fun r2 => ?_) _
    split
    · exact always_pure (Or.inr rfl)
    · split
      · exact always_pure (Or.inr rfl)
      · split_ifs
        · exact always_pure (Or.inl rfl)
        · exact always_pure (Or.inr rfl)

theorem rejectTail_val (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (s : State) :
    Always (rejectTail P d Ld cInt N1 s) (fun r => r.2 = N1 ∨ r.2 = 0) := by
  rw [rejectTail_eq]
  split_ifs
  · exact rejectReleaseRef_val P d Ld N1 _
  · exact always_pure (Or.inr rfl)

theorem rejectTail_fok (P : StreamParams) (d : ℕ) (Ld : Learner) (cInt : ℤ) {N1 : ℚ}
    (hN1 : FOK P N1) (s : State) : Always (rejectTail P d Ld cInt N1 s) (fun r => FOK P r.2) :=
  Always.mono (fun r h => by rcases h with h | h <;> rw [h]; exacts [hN1, fok_zero P])
    (rejectTail_val P d Ld cInt N1 s)

theorem rejectDepth_fok {P : StreamParams} {adaOK : AdaState → Prop} {s : State}
    (hb : ∀ B ∈ s.banks, BankOK P adaOK B) (d : ℕ) (pos : Bool) (Qhat : ℚ) :
    Always (rejectDepth P d pos Qhat s) (fun r => FOK P r.2) := by
  rcases hL : s.learners[d]? with _ | Ld
  · rw [rejectDepth_none P d pos Qhat s (Or.inl hL)]; exact fok_zero P
  rcases hB : s.banks[d]? with _ | Bd
  · rw [rejectDepth_none P d pos Qhat s (Or.inr hB)]; exact fok_zero P
  rw [rejectDepth_some P d pos Qhat s hL hB]
  split_ifs
  · exact fok_zero P
  · refine Always.bind (fun r1 hr1 => ?_)
      (release_grid (hb Bd (List.mem_of_getElem? hB)) Mode.primary)
    rcases r1 with ⟨N1o, B1⟩
    cases N1o with
    | none => exact fok_zero P
    | some N1 =>
      simp only
      split_ifs with hN
      · exact rejectTail_fok P d Ld _ (fok_of_release (hr1 N1 rfl) hN) _
      · exact fok_zero P

theorem step4Depth_fok {P : StreamParams} {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {s : State} (hb : ∀ B ∈ s.banks, BankOK P adaOK B) (d : ℕ) {F : ℚ} (hF : FOK P F) :
    Always (step4Depth P d s F) (fun r => FOK P r.2) := by
  rcases hL : s.learners[d]? with _ | Ld
  · rw [step4Depth_none P d s F (Or.inl hL)]; exact fok_zero P
  rcases hB : s.banks[d]? with _ | Bd
  · rw [step4Depth_none P d s F (Or.inr hB)]; exact fok_zero P
  rw [step4Depth_some P d s F hL hB]
  split_ifs with hS
  · unfold step4ValidateRef
    simp only [bp_bind_eq, bp_pure_eq]
    refine Always.bind (fun res hres => ?_)
      (BankOK.validate hA (hb Bd (List.mem_of_getElem? hB)) _ _)
    have hb1 : ∀ B ∈ setAt res.2 d s.banks, BankOK P adaOK B :=
      Aux.forall_mem_setAt _ hres _ _ hb
    split
    · exact fok_of_inRange (onGrid_S Ld.cache hF.2.2) hS
    · exact rejectDepth_fok hb1 d true F
    · exact rejectDepth_fok hb1 d false F
    · exact fok_zero P
  · exact fok_zero P

theorem step4Loop_fok {P : StreamParams} {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), StateOK P adaOK 4 s → FOK P F →
      Always (step4Loop P ds s F) (fun r => FOK P r.2)
  | [], _, _, _, hF => hF
  | d :: ds, s, F, hs, hF => by
    simp only [step4Loop, bp_bind_eq]
    split_ifs
    · exact hF
    · refine Always.bind (fun r hr => ?_)
        (always_and (step4Depth_ok hA (by norm_num) hs d F) (step4Depth_fok hA hs.banks_ok d hF))
      exact step4Loop_fok hA ds r.1 r.2 hr.1 hr.2

/-- The terminal accumulator of a state with the exact ranges satisfies `FOK`. -/
theorem fok_leaf {P : StreamParams} {adaOK : AdaState → Prop} {s : State}
    (hs : StateOK P adaOK 1 s) : FOK P (gridVal P.eHleaf s.leaf) := by
  refine ⟨gridVal_nonneg hs.leaf_nonneg, gridVal_le_of_le ?_, onGrid_gridVal (eHleaf_le_R P) _⟩
  have := hs.leaf_le
  have h' : (s.leaf : ℚ) ≤ ((1 : ℕ) : ℚ) * ((P.Amax : ℚ) * 2 ^ P.eHleaf) := by exact_mod_cast this
  simpa using h'

theorem step4_fok {P : StreamParams} {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {s : State} (hs : StateOK P adaOK 1 s) : Always (step4 P s) (fun r => FOK P r.2) :=
  step4Loop_fok hA _ _ _ (hs.mono (by norm_num)) (fok_leaf hs)

end F2e2e.C.Impl.T4
