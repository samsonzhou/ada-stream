import F2e2e.C.Impl.AdaPubNB

/-!
# The ADA parameter record: the loop over the blocks

`body_apBStep` (654): the block sizes `[nb 0, …, nb p]` and their maximum, built from `j = p` down to
`0` by calling `body_apNB` (656); state `[k, acc, max acc, 4^k/4, A, p, J, R, χ, K₁, K₂, d_p]`
(`j = k - 1`). `apB_loop` is generic in the block function `nb` computed by `body_apNB`.
-/

namespace F2e2e.C.Impl.AP

open F2e2e.Cost F2e2e.B F2e2e.C.Alg F2e2e.C.Impl.W6

set_option linter.unusedSimpArgs false

/-- Loop step over the blocks. -/
def body_apBStep : Expr :=
  Expr.ite (Expr.bin BinOp.eq (eGet 0 (Expr.var 0)) (Expr.lit 0))
    (eList [Expr.lit 0, eList [eGet 1 (Expr.var 0), eGet 2 (Expr.var 0)]])
    (Expr.letE (Expr.call Cost.Idx.apNB (eList [Expr.bin BinOp.sub (eGet 0 (Expr.var 0)) (Expr.lit 1),
        eGet 3 (Expr.var 0), eGet 4 (Expr.var 0), eGet 5 (Expr.var 0), eGet 6 (Expr.var 0),
        eGet 7 (Expr.var 0), eGet 8 (Expr.var 0), eGet 9 (Expr.var 0), eGet 10 (Expr.var 0),
        eGet 11 (Expr.var 0)]))
      (eList [Expr.lit 1, eList [Expr.bin BinOp.sub (eGet 0 (Expr.var 1)) (Expr.lit 1),
        Expr.bin BinOp.cons (Expr.var 0) (eGet 1 (Expr.var 1)),
        Expr.ite (Expr.bin BinOp.lt (Expr.var 0) (eGet 2 (Expr.var 1))) (eGet 2 (Expr.var 1))
          (Expr.var 0),
        Expr.bin BinOp.div (eGet 3 (Expr.var 1)) (Expr.lit 4),
        eGet 4 (Expr.var 1), eGet 5 (Expr.var 1), eGet 6 (Expr.var 1), eGet 7 (Expr.var 1),
        eGet 8 (Expr.var 1), eGet 9 (Expr.var 1), eGet 10 (Expr.var 1), eGet 11 (Expr.var 1)]]))

/-- The state of the loop over the blocks. -/
def encBS (A p J R χ K1 K2 dp k : ℕ) (acc : List ℕ) : Val :=
  Val.list [encN k, encL encN acc, encN (acc.foldr max 0), encN (2 ^ (2 * k) / 4), encN A, encN p,
    encN J, encN R, encN χ, encN K1, encN K2, encN dp]

theorem foldr_max_lt {l : List ℕ} {B : ℕ} (hB : 0 < B) (h : ∀ x ∈ l, x < B) : l.foldr max 0 < B := by
  induction l with
  | nil => simpa using hB
  | cons x l ih =>
    simp only [List.foldr_cons]
    have hx := h x List.mem_cons_self
    have hl := ih (fun y hy => h y (List.mem_cons_of_mem x hy))
    omega

section

variable {prog : List Expr} {M : ℕ}

/-- **The loop over the blocks.** -/
theorem apB_loop (hb : prog[Cost.Idx.apBStep]? = some body_apBStep)
    (hnb : prog[Cost.Idx.apNB]? = some body_apNB) {A p J R χ K1 K2 dp W : ℕ} (nb : ℕ → ℕ)
    (hnbev : ∀ j, j ≤ p → EvalsVal prog M [Val.list [encN j, encN (2 ^ (2 * j)), encN A, encN p,
      encN J, encN R, encN χ, encN K1, encN K2, encN dp]] [] (.inl body_apNB) (encN (nb j)))
    (hnbW : ∀ j, j ≤ p → nb j < 2 ^ W)
    (hA : A < 2 ^ W) (hp : p + 1 < 2 ^ W) (hJ : J < 2 ^ W) (hR : R < 2 ^ W) (hχ : χ < 2 ^ W)
    (hK1 : K1 < 2 ^ W) (hK2 : K2 < 2 ^ W) (hdp : dp < 2 ^ W) (hf : 2 ^ (2 * (p + 1)) < 2 ^ W)
    (hM : (p + 2) * (W + 2) + 20 * W + 200 ≤ M) :
    ∀ k, k ≤ p + 1 → ∃ out,
      out = Val.list [encL encN ((List.range (p + 1)).map nb),
        encN (((List.range (p + 1)).map nb).foldr max 0)] ∧
      EvalsVal prog M [] [] (.inr (Cost.Idx.apBStep,
        encBS A p J R χ K1 K2 dp k (((List.range (p + 1)).map nb).drop k))) out := by
  set L := (List.range (p + 1)).map nb with hLd
  have hLlen : L.length = p + 1 := by simp [hLd]
  have hLW : ∀ x ∈ L, x < 2 ^ W := by
    intro x hx
    simp only [hLd, List.mem_map, List.mem_range] at hx
    obtain ⟨j, hj, rfl⟩ := hx
    exact hnbW j (by omega)
  have hW0 : 0 < 2 ^ W := Nat.two_pow_pos W
  have sA := size_le_of_lt_pow hA
  have sp1 := size_le_of_lt_pow hp
  have sJ := size_le_of_lt_pow hJ
  have sR := size_le_of_lt_pow hR
  have sχ := size_le_of_lt_pow hχ
  have sK1 := size_le_of_lt_pow hK1
  have sK2 := size_le_of_lt_pow hK2
  have sdp := size_le_of_lt_pow hdp
  have sp : Nat.size p ≤ W := (size_le_of_le (Nat.le_succ p)).trans sp1
  have hpW : (p + 2) * (W + 2) = (p + 1) * (W + 2) + (W + 2) := by ring
  -- the size of a state
  have hstate : ∀ k, k ≤ p + 1 → ∀ acc : List ℕ, acc.length ≤ p + 1 → (∀ x ∈ acc, x < 2 ^ W) →
      valSize (encBS A p J R χ K1 K2 dp k acc) ≤ (p + 1) * (W + 2) + 12 * W + 40 := by
    intro k hk acc hlen hacc
    have h1 : valSize (encL encN acc) ≤ 1 + acc.length * (W + 2) :=
      valSize_encL_le encN acc (W + 1) (fun x hx => by
        rw [valSize_encN]; have := size_le_of_lt_pow (hacc x hx); omega)
    have h2 : acc.length * (W + 2) ≤ (p + 1) * (W + 2) := Nat.mul_le_mul_right _ hlen
    have h3 : Nat.size (acc.foldr max 0) ≤ W := size_le_of_lt_pow (foldr_max_lt hW0 hacc)
    have h4 : Nat.size (2 ^ (2 * k) / 4) ≤ W := by
      have : 2 ^ (2 * k) / 4 < 2 ^ W := by
        calc 2 ^ (2 * k) / 4 ≤ 2 ^ (2 * k) := Nat.div_le_self _ _
          _ ≤ 2 ^ (2 * (p + 1)) := Nat.pow_le_pow_right (by norm_num) (by omega)
          _ < 2 ^ W := hf
      exact size_le_of_lt_pow this
    have h5 : Nat.size k ≤ W := (size_le_of_le hk).trans sp1
    simp only [encBS, valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hb
    (fun k => encBS A p J R χ K1 K2 dp k (L.drop k)) (fun _ => []) (fun k => k ≤ p + 1)
    (fun out => out = Val.list [encL encN L, encN (L.foldr max 0)]) (fun k => k) ?_
  · intro k hk
    obtain ⟨out, h1, h2⟩ := key k hk
    exact ⟨out, h1, h2⟩
  · intro k hk
    have hdlen : (L.drop k).length ≤ p + 1 := by rw [List.length_drop]; omega
    have hdW : ∀ x ∈ L.drop k, x < 2 ^ W := fun x hx => hLW x (List.mem_of_mem_drop hx)
    have hS := hstate k hk (L.drop k) hdlen hdW
    set S := encBS A p J R χ K1 K2 dp k (L.drop k) with hSd
    have hSM : valSize S ≤ M := by omega
    have getS : ∀ (env : List Val) (m i : ℕ) (v : Val), env[m]? = some S →
        [encN k, encL encN (L.drop k), encN ((L.drop k).foldr max 0),
          encN (2 ^ (2 * k) / 4), encN A, encN p, encN J, encN R, encN χ, encN K1, encN K2,
          encN dp][i]? = some v → EvalsVal prog M env [] (.inl (eGet i (Expr.var m))) v :=
      fun env m i v hm hi => ev_get i (EvalsVal.var hm) hSM hi
    have hlit : ∀ (env : List Val) (n : ℕ), Nat.size n ≤ 3 →
        EvalsVal prog M env [] (.inl (Expr.lit (n : ℤ))) (encN n) :=
      fun env n hn => evN_lit n (by omega)
    cases k with
    | zero =>
      left
      refine ⟨Val.list [encL encN L, encN (L.foldr max 0)], ?_, rfl⟩
      refine ev_ite_true (evN_eq_true (getS _ 0 0 _ rfl rfl) (hlit _ 0 (by simp)) rfl (by omega))
        ?_
      have hin : EvalsVal prog M [S] [] (.inl (eList [eGet 1 (Expr.var 0), eGet 2 (Expr.var 0)]))
          (Val.list [encL encN L, encN (L.foldr max 0)]) := by
        have h := ev_list (prog := prog) (M := M) (env := [S])
          (.cons (getS _ 0 1 _ rfl rfl) (.cons (getS _ 0 2 _ rfl rfl) .nil)) (by
            have e1 : valSize (Val.list [encL encN (L.drop 0), encN ((L.drop 0).foldr max 0)]) ≤
                valSize S := by
              simp only [hSd, encBS, valSize_list, listSize_cons, listSize_nil]
              omega
            omega)
        simpa only [List.drop_zero] using h
      refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons hin .nil)) ?_
      have e1 : valSize (Val.list [encL encN L, encN (L.foldr max 0)]) ≤ valSize S := by
        simp only [hSd, encBS, valSize_list, listSize_cons, listSize_nil, List.drop_zero]
        omega
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero] at e1 ⊢
      omega
    | succ j =>
      right
      have hjp : j ≤ p := by omega
      have hjL : j < L.length := by omega
      have hLj : L[j] = nb j := by simp [hLd]
      have hdrop : L.drop j = nb j :: L.drop (j + 1) := by
        rw [List.drop_eq_getElem_cons hjL, hLj]
      have hfe : 2 ^ (2 * (j + 1)) / 4 = 2 ^ (2 * j) := four_pow_div_four j
      refine ⟨1, j, [], one_ne_zero, rfl, ?_, by omega, by omega⟩
      refine ev_ite_false (evN_eq_false (getS _ 0 0 _ rfl rfl) (hlit _ 0 (by simp)) (by omega)
        (by omega)) ?_
      -- the call of `body_apNB`
      have sj : Nat.size j ≤ W := (size_le_of_le (show j ≤ p + 1 by omega)).trans sp1
      have sj1 : Nat.size (j + 1) ≤ W := (size_le_of_le (show j + 1 ≤ p + 1 by omega)).trans sp1
      have sf : Nat.size (2 ^ (2 * j)) ≤ W := by
        have : 2 ^ (2 * j) < 2 ^ W :=
          lt_of_le_of_lt (Nat.pow_le_pow_right (by norm_num) (by omega)) hf
        exact size_le_of_lt_pow this
      have hargs : valSize (Val.list [encN j, encN (2 ^ (2 * j)), encN A, encN p, encN J, encN R,
          encN χ, encN K1, encN K2, encN dp]) ≤ M := by
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
        omega
      have earg : EvalsVal prog M [S] [] (.inl (eList [Expr.bin BinOp.sub (eGet 0 (Expr.var 0))
          (Expr.lit 1), eGet 3 (Expr.var 0), eGet 4 (Expr.var 0), eGet 5 (Expr.var 0),
          eGet 6 (Expr.var 0), eGet 7 (Expr.var 0), eGet 8 (Expr.var 0), eGet 9 (Expr.var 0),
          eGet 10 (Expr.var 0), eGet 11 (Expr.var 0)])) (Val.list [encN j, encN (2 ^ (2 * j)),
          encN A, encN p, encN J, encN R, encN χ, encN K1, encN K2, encN dp]) := by
        have hsub := ev_cast (evN_sub (getS [S] 0 0 _ rfl rfl) (hlit [S] 1 (by simp)) (by omega)
          (by omega)) (show encN (j + 1 - 1) = encN j by rfl)
        exact ev_list (.cons hsub (.cons (getS _ 0 3 _ rfl (by rw [hfe]; rfl))
          (.cons (getS _ 0 4 _ rfl rfl) (.cons (getS _ 0 5 _ rfl rfl) (.cons (getS _ 0 6 _ rfl rfl)
          (.cons (getS _ 0 7 _ rfl rfl) (.cons (getS _ 0 8 _ rfl rfl) (.cons (getS _ 0 9 _ rfl rfl)
          (.cons (getS _ 0 10 _ rfl rfl) (.cons (getS _ 0 11 _ rfl rfl) .nil)))))))))) hargs
      refine ev_letE (ev_call hnb earg (hnbev j hjp)) ?_
      -- the new state, in the environment `[nb j, S]`
      set n := nb j with hn
      have hnW : n < 2 ^ W := hnbW j hjp
      have sn := size_le_of_lt_pow hnW
      set acc := L.drop (j + 1) with hacc
      set mx := acc.foldr max 0 with hmx
      have hmxW : mx < 2 ^ W :=
        foldr_max_lt hW0 (fun x hx => hLW x (List.mem_of_mem_drop hx))
      have smx := size_le_of_lt_pow hmxW
      have hnew : S = encBS A p J R χ K1 K2 dp (j + 1) (L.drop (j + 1)) := rfl
      have g0 : EvalsVal prog M [encN n, S] [] (.inl (eGet 0 (Expr.var 1))) (encN (j + 1)) :=
        getS _ 1 0 _ rfl rfl
      have g1 : EvalsVal prog M [encN n, S] [] (.inl (eGet 1 (Expr.var 1))) (encL encN acc) :=
        getS _ 1 1 _ rfl rfl
      have g2 : EvalsVal prog M [encN n, S] [] (.inl (eGet 2 (Expr.var 1))) (encN mx) :=
        getS _ 1 2 _ rfl rfl
      have g3 : EvalsVal prog M [encN n, S] [] (.inl (eGet 3 (Expr.var 1)))
          (encN (2 ^ (2 * j))) := getS _ 1 3 _ rfl (by rw [hfe]; rfl)
      have vn : EvalsVal prog M [encN n, S] [] (.inl (Expr.var 0)) (encN n) := EvalsVal.var rfl
      have hdj : L.drop j = n :: acc := hdrop
      have hstj := hstate j (by omega) (L.drop j) (by rw [List.length_drop]; omega)
        (fun x hx => hLW x (List.mem_of_mem_drop hx))
      have hdjlen : acc.length ≤ p + 1 := by rw [hacc, List.length_drop]; omega
      have hlist : valSize (encL encN (n :: acc)) = Nat.size n + 2 + valSize (encL encN acc) := by
        simp only [encL, List.map_cons, valSize_list, listSize_cons, valSize_encN]
        omega
      have n0 := ev_cast (evN_sub g0 (hlit _ 1 (by simp)) (by omega) (by omega))
        (show encN (j + 1 - 1) = encN j by rfl)
      have hSj : valSize S ≥ valSize (encL encN acc) := by
        simp only [hSd, encBS, valSize_list, listSize_cons, listSize_nil]
        omega
      have n1 : EvalsVal prog M [encN n, S] [] (.inl (Expr.bin BinOp.cons (Expr.var 0)
          (eGet 1 (Expr.var 1)))) (encL encN (n :: acc)) :=
        ev_cons vn g1 (by
          have e : Val.list (encN n :: List.map encN acc) = encL encN (n :: acc) := rfl
          rw [e, hlist]
          omega)
      have n2 : EvalsVal prog M [encN n, S] [] (.inl (Expr.ite (Expr.bin BinOp.lt (Expr.var 0)
          (eGet 2 (Expr.var 1))) (eGet 2 (Expr.var 1)) (Expr.var 0)))
          (encN ((n :: acc).foldr max 0)) := by
        rw [List.foldr_cons]
        by_cases hlt : n < mx
        · rw [show max n (acc.foldr max 0) = mx by rw [← hmx]; omega]
          exact ev_ite_true (evN_lt_true vn g2 hlt (by omega)) g2
        · rw [show max n (acc.foldr max 0) = n by rw [← hmx]; omega]
          exact ev_ite_false (evN_lt_false vn g2 hlt (by omega)) vn
      have h4 : Nat.size 4 ≤ 3 := Nat.size_le.2 (by norm_num)
      have n3 := evN_div g3 (hlit _ 4 h4) (by norm_num) (by omega)
      have hin : EvalsVal prog M [encN n, S] [] (.inl (eList [Expr.bin BinOp.sub
          (eGet 0 (Expr.var 1)) (Expr.lit 1), Expr.bin BinOp.cons (Expr.var 0) (eGet 1 (Expr.var 1)),
          Expr.ite (Expr.bin BinOp.lt (Expr.var 0) (eGet 2 (Expr.var 1))) (eGet 2 (Expr.var 1))
            (Expr.var 0),
          Expr.bin BinOp.div (eGet 3 (Expr.var 1)) (Expr.lit 4),
          eGet 4 (Expr.var 1), eGet 5 (Expr.var 1), eGet 6 (Expr.var 1), eGet 7 (Expr.var 1),
          eGet 8 (Expr.var 1), eGet 9 (Expr.var 1), eGet 10 (Expr.var 1), eGet 11 (Expr.var 1)]))
          (encBS A p J R χ K1 K2 dp j (L.drop j)) := by
        rw [hdj]
        refine ev_list (.cons n0 (.cons n1 (.cons n2 (.cons n3 (.cons (getS _ 1 4 _ rfl rfl)
          (.cons (getS _ 1 5 _ rfl rfl) (.cons (getS _ 1 6 _ rfl rfl) (.cons (getS _ 1 7 _ rfl rfl)
          (.cons (getS _ 1 8 _ rfl rfl) (.cons (getS _ 1 9 _ rfl rfl)
          (.cons (getS _ 1 10 _ rfl rfl) (.cons (getS _ 1 11 _ rfl rfl) .nil)))))))))))) ?_
        rw [← encBS, ← hdj]
        omega
      refine ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons hin .nil)) ?_
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one]
      omega

end

end F2e2e.C.Impl.AP
