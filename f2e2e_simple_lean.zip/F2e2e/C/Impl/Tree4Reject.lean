import F2e2e.C.Impl.Tree4TailImpl

/-!
# W6, Tree4: the DSL implementation of `rejectDepth` (helper file)

Owner of these proofs: B-PRIV (22fc6ea9), as a helper of Tree4 (1beb339b), who owns the statements
below (fixed; do not change them) and the rest of `F2e2e/C/Impl/Tree4*.lean`.

* `rejectScale_impl`: `body_rejectScale` (Idx 337, `F2e2e/C/Impl/Tree4Defs.lean`) implements
  `rejectScaleRef` (multiplier `c = stepCoeffMant …`, `Y_d · c` on the released bank `B₁` stored at
  `d`, then `rejectTail`; partIII.tex L504–506);
* `rejectDepth_impl`: `body_rejectDepth` (Idx 336) implements C-ALG's `rejectDepth` (L501–510).

**Proof plan** (model proof: `rejectRelease_impl` in `F2e2e/C/Impl/Tree4Tail.lean`, same style):

`rejectScale_impl`: bindings `p` (`ev_get 0 … hXz rfl`), `eEta`, `eHstep`, `eHP`
(`ev_paramCall hC.w1.peEta/peHstep/peHP`), `P_d = encQ (gridVal eHP cache)` (`ev_normQ_grid` with
`ev_get 1 (ev_get 4 …)` and `ev_pow2`), `cInt` (`ev_stepCoeffCall`: needs `eEta_le_R`, `eHstep_le_R`,
`0 < gridVal eHP cache` from `hc`, `qok_cache hLd`, `hQ0`, `hQ.qok`), `B₁' = scaleYBank [p, B₁, cInt]`
(`ev_scaleYCall`, `|cInt| ≤ 2^(eHstep+1)` from C-ALG's `stepCoeffMant_mem`), then
`implements_call_det hT.rejectTail (ev_list …) (rejectTail_impl …)` with the state
`{ s with banks := setAt (B₁.mapRows (Row.scaleY P cInt)) d s.banks }` (`ev_eWithBanks`,
`ev_eSetAt`; `StateOK.setBank` + `BankOK.scaleY`). `rejectScaleRef` unfolds by `rfl`/`unfold`.

`rejectDepth_impl`: bindings `p, d, st` (`ev_get`), `lo, bo` (`ev_getOpt hT encLearner …`,
`ev_getOpt hT (encBank R.enc) …`); case on `s.learners[d]?`, `s.banks[d]?` (`rejectDepth_none` /
`rejectDepth_some`, Tree4Defs) with `impl_ite_isNil_nil/cons`; `J_*` (`ev_paramCall hC.w1.pJstar`);
the three checks via `ev_lt'` (Tree4Lists) + `impl_ite_true/false` (note `Qhat ≤ 0 ↔ Qhat.num ≤ 0`,
`Rat.num_pos`); the PRIMARY release `impl_letE_run (impl_releaseCall … Mode.primary …)`; on its output
`(N1o, B1)`: `BankOK.release`, `release_grid` (C-SPACE, `F2e2e/C/SpaceRegs.lean`) give `BankOK B1`,
`QOK N1` (`qok_of_release`), `FOK N1` after the range check (`fok_of_release`); `none`/range failure:
`Implements.of_det (ev_eFailOut (ev_eWithBanks … (ev_eSetAt …)))`; success:
`implements_call_det hT.rejectScale (ev_list …) (rejectScale_impl …)` (`hj : Ld.jUsed < P.Jstar`,
`0 < Ld.cache`, `0 < Qhat` from the checks; `LearnerOK 4 Ld` from `hs.learners_ok`).

Sizes: units of `SSB R P` (`Mv R P = 2^32 SSB`): `vs_state`, `vs_bank`, `vs_encQ`, `vs_int`,
`vs_encN`, `vs_learner`, `vs_pair`, `mapIdx_M_banks_le`, `vs_banks_le` (Tree4Tail). Pitfalls: see the
docstring of `F2e2e/C/Impl/Tree4TailImpl.lean`.
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-- **`rejectScale`** implements `rejectScaleRef`. -/
theorem rejectScale_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) (pos : Bool) {Qhat : ℚ} (hQ : FOK P Qhat) (hQ0 : 0 < Qhat) {Ld : Learner}
    (hLd : LearnerOK P 4 Ld) (hc : 0 < Ld.cache) (hj : Ld.jUsed < P.Jstar) {B1 : Bank}
    (hB1 : BankOK P (R.ok P) B1) {N1 : ℚ} (hN1 : FOK P N1) :
    Implements prog M [Val.list [encStreamParams P, encN d, encB pos, encQ Qhat, encLearner Ld,
      encState R.enc s, encBank R.enc B1, encQ N1]] body_rejectScale (encSF R)
      (rejectScaleRef P d pos Qhat Ld s B1 N1) := by
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hpz := vs_params R P
  have hRB := regBits_le_SSB R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hLz := vs_learner R P (hLd.mono (by norm_num) : LearnerOK P 16 Ld)
  have hQz := vs_encQ R P hQ.qok
  have hNz := vs_encQ R P hN1.qok
  have hsz := vs_state hR hP hs ht
  have hBz := vs_bank hR hP hB1
  have hposz := valSize_encB_le pos
  have hXz : valSize (Val.list [encStreamParams P, encN d, encB pos, encQ Qhat, encLearner Ld,
      encState R.enc s, encBank R.enc B1, encQ N1]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hbz := vs_banks_le R.enc s
  have heEta := eEta_le_R P
  have heHstep := eHstep_le_R P
  have heHP := eHP_le_R P
  have heAmax := eAmax_le_R P
  have hq1 : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
  have hcpos : 0 < gridVal P.eHP Ld.cache := by
    unfold gridVal
    have : (0 : ℚ) < (Ld.cache : ℚ) := by exact_mod_cast hc
    positivity
  have hPdq := qok_cache hLd
  have hPdz := vs_encQ R P hPdq
  have hcacheb := SizeAux.bitLen_cache_le hLd
  have hszc : 2 * (bitLen Ld.cache + (P.eHP + 1)) + 64 ≤ M := by omega
  have hpow : S_pow2 P.eHP ≤ M := by unfold S_pow2; have := size_le_self P.eHP; omega
  have hEtaz := vs_encN R P heEta
  have hHstz := vs_encN R P heHstep
  simp only [body_rejectScale, rejectScaleRef]
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peEta hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peHstep hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_paramCall hC.w1.peHP hP hM (EvalsVal.var rfl)) ?_
  refine impl_letE_det (ev_normQ_grid hC
    (ev_get 1 (ev_get 4 (EvalsVal.var rfl) hXz rfl) (show valSize (encLearner Ld) ≤ M by omega) rfl)
    (ev_pow2 hT (EvalsVal.var rfl) hpow) hszc) ?_
  refine impl_letE_det (ev_stepCoeffCall hC hP hM pos heEta heHstep hcpos hPdq hQ0 hQ.qok
    (ev_list (.cons (ev_get 2 (EvalsVal.var rfl) hXz rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        (.cons (ev_get 3 (EvalsVal.var rfl) hXz rfl) .nil)))))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
  obtain ⟨hc0, hc1⟩ := stepCoeffMant_mem pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat hq1
  generalize hcI : stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) Qhat = cInt at hc0 hc1 ⊢
  have hcabs : |cInt| ≤ 2 ^ (P.eHstep + 1) := by
    have h4 : (2 : ℤ) ^ (P.eHstep + 1) = 4 * 2 ^ (P.eHstep - 1) := by
      rw [show P.eHstep + 1 = (P.eHstep - 1) + 2 by omega, pow_add]; ring
    have hpos : (0 : ℤ) < 2 ^ (P.eHstep - 1) := by positivity
    rw [abs_of_nonneg (by linarith), h4]
    linarith
  have hcz : valSize (Val.int cInt) ≤ 2 ^ 4 * SSB R P :=
    vs_int R P (k := P.eHstep + 2) (lt_of_le_of_lt hcabs (pow_lt_pow_right₀ (by norm_num) (by omega)))
      (by omega)
  have hB1' : BankOK P (R.ok P) (B1.mapRows (Row.scaleY P cInt)) := hB1.scaleY cInt
  have hB1'z := vs_bank hR hP hB1'
  have hs' : StateOK P (R.ok P) 4 { s with banks := setAt (B1.mapRows (Row.scaleY P cInt)) d s.banks } :=
    hs.setBank hB1' d
  have hs'M := (vs_state hR hP hs' ht).trans (show SSB R P ≤ M by omega)
  refine impl_letE_det (ev_scaleYCall hC hP hM hB1 hcabs
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 6 (EvalsVal.var rfl) hXz rfl)
      (.cons (EvalsVal.var rfl) .nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil, encZ]; omega))) ?_
  have hMI := mapIdx_M_banks_le hR hP hs.banks_ok hs.banks_length_le
    (Val.list [encN d, encBank R.enc (B1.mapRows (Row.scaleY P cInt))])
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have hs'z := vs_state hR hP hs' ht
  refine implements_call_det hT.rejectTail
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 1 (EvalsVal.var rfl) hXz rfl)
      (.cons (ev_get 4 (EvalsVal.var rfl) hXz rfl) (.cons (EvalsVal.var rfl)
      (.cons (ev_get 7 (EvalsVal.var rfl) hXz rfl)
      (.cons (ev_eWithBanks (ev_get 5 (EvalsVal.var rfl) hXz rfl)
        (ev_eSetAt hT (encBank R.enc) s.banks d (B1.mapRows (Row.scaleY P cInt))
          (bankSizeBound P (R.bound P))
          (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hs.banks_ok B hB))
          (BankOK.valSize_encBank_le (hR.enc_le P hP) hB1')
          (ev_get 5 (ev_get 5 (EvalsVal.var rfl) hXz rfl) hsM rfl)
          (ev_get 1 (EvalsVal.var rfl) hXz rfl) (EvalsVal.var rfl) (by omega))
        hsM hs'M) .nil))))))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (rejectTail_impl hR hC hT hP hM hs' ht hd hLd hj hc0 hc1 hN1)

/-- **`rejectDepth`** implements C-ALG's `rejectDepth`. -/
theorem rejectDepth_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) (pos : Bool) {Qhat : ℚ} (hQ : FOK P Qhat) :
    Implements prog M [Val.list [encStreamParams P, encN d, encB pos, encState R.enc s,
      encQ Qhat]] body_rejectDepth (encSF R) (rejectDepth P d pos Qhat s) := by
  have hA := hR.invariant P hP
  have hS : 2 ^ 32 * SSB R P ≤ M := hM
  have hS1 := SSB_learner R P
  have hpz := vs_params R P
  have hRB := regBits_le_SSB R P
  have hdz := vs_encN R P (show d ≤ regBits P by have := H_le_R P; omega)
  have hQz := vs_encQ R P hQ.qok
  have hsz := vs_state hR hP hs ht
  have hposz := valSize_encB_le pos
  have hXz : valSize (Val.list [encStreamParams P, encN d, encB pos, encState R.enc s,
      encQ Qhat]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hsM : valSize (encState R.enc s) ≤ M := by omega
  have hbz := vs_banks_le R.enc s
  have hlz := vs_learners_le R.enc s
  have hsd := size_le_self d
  rw [valSize_encN] at hdz
  unfold body_rejectDepth
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_get 3 (EvalsVal.var rfl) hXz rfl) ?_
  refine impl_letE_det (ev_getOpt hT encLearner s.learners d
    (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hsM rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
    (by omega)) ?_
  refine impl_letE_det (ev_getOpt hT (encBank R.enc) s.banks d
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hsM rfl) (.cons (EvalsVal.var rfl) .nil))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
    (by omega)) ?_
  rcases hLd' : s.learners[d]? with _ | Ld
  · rw [rejectDepth_none P d pos Qhat s (Or.inl hLd')]
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  rcases hBd' : s.banks[d]? with _ | Bd
  · rw [rejectDepth_none P d pos Qhat s (Or.inr hBd')]
    refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  have hLdOK : LearnerOK P 4 Ld := hs.learners_ok Ld (List.mem_of_getElem? hLd')
  have hBdOK : BankOK P (R.ok P) Bd := hs.banks_ok Bd (List.mem_of_getElem? hBd')
  have hLz := vs_learner R P (hLdOK.mono (by norm_num) : LearnerOK P 16 Ld)
  have hBz := vs_bank hR hP hBdOK
  have hlo : valSize (Val.list [encLearner Ld]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hbo : valSize (Val.list [encBank R.enc Bd]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  rw [rejectDepth_some P d pos Qhat s hLd' hBd']
  refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
  refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
  refine impl_letE_det (ev_paramCall hC.w1.pJstar hP hM (EvalsVal.var rfl)) ?_
  by_cases hj : Ld.jUsed < P.Jstar
  swap
  · rw [if_pos (Or.inl (not_lt.1 hj))]
    refine impl_ite_false (ev_lt' (ev_get 4 (ev_head' (EvalsVal.var rfl) hlo)
      (show valSize (encLearner Ld) ≤ M by omega) rfl) (EvalsVal.var rfl) (by omega))
      (by simp [hj]) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  refine impl_ite_true (ev_lt' (ev_get 4 (ev_head' (EvalsVal.var rfl) hlo)
    (show valSize (encLearner Ld) ≤ M by omega) rfl) (EvalsVal.var rfl) (by omega))
    (by simp [hj]) ?_
  by_cases hc : 0 < Ld.cache
  swap
  · rw [if_pos (Or.inr (Or.inl (not_lt.1 hc)))]
    refine impl_ite_false (ev_lt' (EvalsVal.lit (by simp; omega)) (ev_get 1 (ev_head' (EvalsVal.var rfl) hlo)
      (show valSize (encLearner Ld) ≤ M by omega) rfl) (by omega))
      (by simp [hc]) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  refine impl_ite_true (ev_lt' (EvalsVal.lit (by simp; omega)) (ev_get 1 (ev_head' (EvalsVal.var rfl) hlo)
    (show valSize (encLearner Ld) ≤ M by omega) rfl) (by omega))
    (by simp [hc]) ?_
  by_cases hq : 0 < Qhat
  swap
  · rw [if_pos (Or.inr (Or.inr (not_lt.1 hq)))]
    refine impl_ite_false (ev_lt' (EvalsVal.lit (by simp; omega)) (ev_get 0 (ev_get 4 (EvalsVal.var rfl) hXz rfl)
      (show valSize (encQ Qhat) ≤ M by omega) rfl) (by omega))
      (by simp [Rat.num_pos, hq]) ?_
    exact Implements.of_det (ev_eFailOut (EvalsVal.var rfl) (by omega))
  refine impl_ite_true (ev_lt' (EvalsVal.lit (by simp; omega)) (ev_get 0 (ev_get 4 (EvalsVal.var rfl) hXz rfl)
    (show valSize (encQ Qhat) ≤ M by omega) rfl) (by omega))
    (by simp [Rat.num_pos, hq]) ?_
  rw [if_neg (fun h => by rcases h with h | h | h <;> [omega; omega; linarith])]
  refine impl_letE_run (impl_releaseCall hC hP hM hBdOK Mode.primary
    (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_head' (EvalsVal.var rfl) hbo)
      (.cons (EvalsVal.lit (by simp; omega)) .nil)))
      (by simp only [encMode, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]
          omega))) (fun bits r1 hrun => ?_)
  rcases r1 with ⟨N1o, B1⟩
  dsimp only
  have hB1 : BankOK P (R.ok P) B1 := Always.of_run (BankOK.release hA hBdOK Mode.primary) hrun
  have hg1 : ∀ N, N1o = some N →
      0 ≤ N ∧ N ≤ 2 ^ regBits P ∧ ∃ m : ℤ, N = (m : ℚ) / 2 ^ regBits P :=
    Always.of_run (release_grid hBdOK Mode.primary) hrun
  have hB1z := vs_bank hR hP hB1
  have hs1 : StateOK P (R.ok P) 4 { s with banks := setAt B1 d s.banks } := hs.setBank hB1 d
  have hs1M := (vs_state hR hP hs1 ht).trans (show SSB R P ≤ M by omega)
  have hs1M' : valSize (encState R.enc { s with banks := setAt B1 d s.banks }) + 10 ≤ M :=
    (Nat.add_le_add_right (vs_state hR hP hs1 ht) 10).trans (by omega)
  have hMI := mapIdx_M_banks_le hR hP hs.banks_ok hs.banks_length_le
    (Val.list [encN d, encBank R.enc B1])
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega)
  have hres : valSize (Val.list [encOptQ N1o, encBank R.enc B1]) ≤ 2 ^ 6 * SSB R P := by
    cases N1o with
    | none => simp only [encOptQ, valSize_list, listSize_cons, listSize_nil] at hB1z ⊢; omega
    | some N1 =>
      have h := vs_encQ R P (qok_of_release (hg1 N1 rfl))
      simp only [encOptQ, valSize_list, listSize_cons, listSize_nil] at hB1z ⊢; omega
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) (by omega) rfl) ?_
  cases N1o with
  | none =>
    refine impl_ite_isNil_nil (EvalsVal.var rfl) (by omega) ?_
    exact Implements.of_det (ev_eFailOut (ev_eWithBanks (EvalsVal.var rfl)
      (ev_eSetAt hT (encBank R.enc) s.banks d B1 (bankSizeBound P (R.bound P))
        (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hs.banks_ok B hB))
        (BankOK.valSize_encBank_le (hR.enc_le P hP) hB1)
        (ev_get 5 (EvalsVal.var rfl) hsM rfl) (EvalsVal.var rfl)
        (ev_get 1 (EvalsVal.var rfl) (by omega) rfl) (by omega))
      hsM hs1M) hs1M')
  | some N1 =>
    have hg := hg1 N1 rfl
    have hN1q := qok_of_release hg
    have hN1z := vs_encQ R P hN1q
    refine impl_ite_isNil_cons (EvalsVal.var rfl) (by omega) ?_
    refine impl_letE_det (ev_inRangeACall hC hP hM hN1q
      (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_head' (EvalsVal.var rfl)
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) .nil))
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))) ?_
    refine impl_ite_encB (EvalsVal.var rfl) ?_
    dsimp only
    cases hin : inRangeA P N1
    · simp only [Bool.false_eq_true, if_false]
      exact Implements.of_det (ev_eFailOut (ev_eWithBanks (EvalsVal.var rfl)
        (ev_eSetAt hT (encBank R.enc) s.banks d B1 (bankSizeBound P (R.bound P))
          (fun B hB => BankOK.valSize_encBank_le (hR.enc_le P hP) (hs.banks_ok B hB))
          (BankOK.valSize_encBank_le (hR.enc_le P hP) hB1)
          (ev_get 5 (EvalsVal.var rfl) hsM rfl) (EvalsVal.var rfl)
          (ev_get 1 (EvalsVal.var rfl) (by omega) rfl) (by omega))
        hsM hs1M) hs1M')
    · simp only [if_true]
      have hN1 : FOK P N1 := fok_of_release hg hin
      exact implements_call_det hT.rejectScale
        (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 2 (EvalsVal.var rfl) hXz rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hXz rfl)
          (.cons (ev_head' (EvalsVal.var rfl) hlo) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 1 (EvalsVal.var rfl) (by omega) rfl)
          (.cons (ev_head' (EvalsVal.var rfl)
            (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) .nil))))))))
          (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]; omega))
        (rejectScale_impl hR hC hT hP hM hs ht hd pos hQ hq hLdOK hc hj hB1 hN1)

end F2e2e.C.Impl.T4
