import F2e2e.C.Impl.ParamsVal

/-!
# W1 (public parameters, DSL), part 4e: segment E of the master chain

Owner: A-ARCH (a99d156c), for C-PARAMS (e26ae4ae). The grid exponents `log₂(1/h_g), log₂(1/h_C), log₂(1/σ), log₂(1/ω), log₂(1/h_P), log₂(1/h_b), log₂(1/h_step), log₂(1/h_leaf)` (push indices `27–34`).
Statement fixed (C-PARAMS); every `PE.val … = P.X` goal must be closed with the propositional lemmas of
`F2e2e/C/Impl/ParamsVal.lean` (never by a bare `rfl`).
-/

set_option linter.unusedSimpArgs false

namespace F2e2e.C.Impl

namespace W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

theorem segE_ok (hlib : W1Lib prog) (P : StreamParams) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    ChainOK prog M (Abnd P) [encStreamParams P] segE (valsE P)
      [P.L, P.s, P.Rmax, P.Jmax, P.Jstar, P.K0, P.Kepoch, P.eUstar, P.eNu, P.logG, P.V,
        P.Vd (P.H - 1), P.H - 1, P.Vd P.H, P.B, P.logB, P.eGamma, P.eEta, P.W, P.Dstar, P.T, P.H,
        P.betaExp, P.epsExp, P.U, P.m, P.n] := by
  -- log₂(1/h_g)
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.eHg, StreamParams.eHgUnref])
    (eHg_le_A P) ?_
  -- log₂(1/h_C)
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.eHC])
    (eHC_le_A P) ?_
  -- log₂(1/σ)
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.eSigma, sq])
    (eSigma_le_A P) ?_
  -- log₂(1/ω)
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_mul', Nat.reduceSub, getD0_cons_zero', getD0_cons_succ',
        StreamParams.eOmega])
    (eOmega_le_A P) ?_
  -- log₂(1/h_P)
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.eHP])
    (eHP_le_A P) ?_
  -- log₂(1/h_b)
  refine ChainOK.pe_cons rfl (by decide)
    (by simp only [PE.calls, true_and, and_true]; exact clog2_cond hlib hM _)
    (by
      simp only [val_var', val_lit', val_add', val_mul', val_call', Nat.reduceSub,
        getD0_cons_zero', getD0_cons_succ', StreamParams.eHb])
    (eHb_le_A P) ?_
  -- log₂(1/h_step)
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.eHstep])
    (eHstep_le_A P) ?_
  -- log₂(1/h_leaf)
  refine ChainOK.pe_cons rfl (by decide) (by simp only [PE.calls, true_and, and_true])
    (by
      simp only [val_var', val_lit', val_add', val_mul', Nat.reduceSub, getD0_cons_zero',
        getD0_cons_succ', StreamParams.eHleaf])
    (eHleaf_le_A P) ?_
  exact ChainOK.nil

end W1

end F2e2e.C.Impl
