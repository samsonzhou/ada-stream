import F2e2e.C.Impl.HashHorner
import F2e2e.Lib.Hash.Fingerprint
import F2e2e.Cost.Lib.ZipWithAdd

/-!
# Zero-fingerprint arithmetic (DSL): primes, modular powers, the fingerprint update

Routines for Algorithm `R:alg:zero-fingerprint` (partII.tex l. 219–221) and C-ALG's
`F2e2e.C.Alg.fpUpdate` / `P.q` (Idx 200–206). Reference functions: `F2e2e.Hash.primeTest`,
`F2e2e.Hash.leastPrimeGE` (`F2e2e/Lib/Hash/Fingerprint.lean`), `r ^ i % q`, and `fpUpdateQ` below.

| index | body | input | output (reference) |
|---|---|---|---|
| 200/201 | `body_primeTest` / step | `n` | `encB (Hash.primeTest n)` |
| 202/203 | `body_leastPrimeGE` / step | `M` | `encN (Hash.leastPrimeGE M)` |
| 204/205 | `body_powMod` / step | `[r, i, q]` | `encN (r ^ i % q)` (`q ≥ 1`) |
| 206 | `body_fpUpdate` | `[q, seed, val, i, Δ]` | `encN (fpUpdateQ q seed val i Δ)` (`q ≥ 1`) |

* `primeTest`: `n < 2 ↦ 0`, else the loop over the divisors `d = 2, …, n - 1` (state
  `[cnt, d, n]`, stop with `1` when `cnt = 0`, with `0` when `n % d = 0`).
* `leastPrimeGE`: `Hash.searchFrom primeTest M (M + 1)` (state `[s, k]`).
* `powMod`: `k` multiplications modulo `q` (state `[k, acc, r, q]`, `acc ← acc · r mod q`; repeated
  multiplication instead of repeated squaring: time is not charged, space stays `O(log q)`).
* `fpUpdate`: `(val + (Δ mod q) · (seed^i mod q)) mod q` with Lean's (Euclidean) `%` on `ℤ`.
All iterations are `loop` steps. Specs are space-only (`EvalsSp`).
-/

namespace F2e2e.Cost.Idx

/-- `primeTest : n ↦ encB (Hash.primeTest n)`. -/
abbrev primeTest : ℕ := 200
abbrev primeTestStep : ℕ := 201
/-- `leastPrimeGE : M ↦ Hash.leastPrimeGE M`. -/
abbrev leastPrimeGE : ℕ := 202
abbrev leastPrimeGEStep : ℕ := 203
/-- `powMod : [r, i, q] ↦ r ^ i % q`. -/
abbrev powMod : ℕ := 204
abbrev powModStep : ℕ := 205
/-- `fpUpdate : [q, seed, val, i, Δ] ↦ fpUpdateQ q seed val i Δ`. -/
abbrev fpUpdate : ℕ := 206

end F2e2e.Cost.Idx

namespace F2e2e.Cost.HashDSL

set_option linter.unusedSimpArgs false

/-! ### Reference -/

/-- The zero-fingerprint update with modulus `q` (partII.tex l. 221; C-ALG's `fpUpdate P` with
`P.q = q`): `(val + (Δ mod q) · (seed^i mod q)) mod q`. -/
def fpUpdateQ (q seed val i : ℕ) (Δ : ℤ) : ℕ :=
  (((val : ℤ) + Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ)) % (q : ℤ)).toNat

/-! ### Bodies -/

/-- Step of `primeTest`; state `[cnt, d, n]`: stop with `1` when `cnt = 0`, with `0` when
`n % d = 0`, else `[cnt - 1, d + 1, n]`. -/
def body_primeTestStep : Expr :=
  eLet (eHd (eV 0))                                         -- cnt  [cnt, S]
    (eLet (eAt1 (eV 1))                                     -- d    [d, cnt, S]
      (eLet (eAt2 (eV 2))                                   -- n    [n, d, cnt, S]
        (eIte (eEq (eV 2) (eLit 0))
          (ePair (eLit 0) (eLit 1))
          (eIte (eEq (eMod (eV 0) (eV 1)) (eLit 0))
            (ePair (eLit 0) (eLit 0))
            (ePair (eLit 1) (eList [eSub (eV 2) (eLit 1), eAdd (eV 1) (eLit 1), eV 0]))))))

/-- `primeTest : n ↦ encB (Hash.primeTest n)`: `0` for `n < 2`, else the loop from `[n - 2, 2, n]`. -/
def body_primeTest : Expr :=
  eIte (eLt (eV 0) (eLit 2))
    (eLit 0)
    (eLoop Idx.primeTestStep (eList [eSub (eV 0) (eLit 2), eLit 2, eV 0]))

/-- Step of `leastPrimeGE` (`Hash.searchFrom primeTest`); state `[s, k]`: stop with `s` when
`k = 0` or `primeTest s`, else `[s + 1, k - 1]`. -/
def body_leastPrimeGEStep : Expr :=
  eLet (eHd (eV 0))                                         -- s    [s, S]
    (eLet (eAt1 (eV 1))                                     -- k    [k, s, S]
      (eIte (eEq (eV 0) (eLit 0))
        (ePair (eLit 0) (eV 1))
        (eIte (eEq (eCall Idx.primeTest (eV 1)) (eLit 1))
          (ePair (eLit 0) (eV 1))
          (ePair (eLit 1) (ePair (eAdd (eV 1) (eLit 1)) (eSub (eV 0) (eLit 1)))))))

/-- `leastPrimeGE : M ↦ Hash.leastPrimeGE M` (loop from `[M, M + 1]`). -/
def body_leastPrimeGE : Expr :=
  eLoop Idx.leastPrimeGEStep (ePair (eV 0) (eAdd (eV 0) (eLit 1)))

/-- Step of `powMod`; state `[k, acc, r, q]`: stop with `acc` when `k = 0`, else
`[k - 1, acc · r mod q, r, q]`. -/
def body_powModStep : Expr :=
  eLet (eHd (eV 0))                                         -- k    [k, S]
    (eIte (eEq (eV 0) (eLit 0))
      (ePair (eLit 0) (eAt1 (eV 1)))
      (ePair (eLit 1)
        (eList [eSub (eV 0) (eLit 1), eMod (eMul (eAt1 (eV 1)) (eAt2 (eV 1))) (eAt3 (eV 1)),
          eAt2 (eV 1), eAt3 (eV 1)])))

/-- `powMod : [r, i, q] ↦ r ^ i % q` (loop from `[i, 1 % q, r, q]`). -/
def body_powMod : Expr :=
  eLoop Idx.powModStep
    (eList [eAt1 (eV 0), eMod (eLit 1) (eAt2 (eV 0)), eHd (eV 0), eAt2 (eV 0)])

/-- `fpUpdate : [q, seed, val, i, Δ] ↦ (val + (Δ % q) · powMod [seed, i, q]) % q`. -/
def body_fpUpdate : Expr :=
  eMod
    (eAdd (eAt2 (eV 0))
      (eMul (eMod (eAt4 (eV 0)) (eHd (eV 0)))
        (eCall Idx.powMod (eList [eAt1 (eV 0), eAt3 (eV 0), eHd (eV 0)]))))
    (eHd (eV 0))

/-- A program containing the fingerprint routines. -/
structure FpLib (prog : List Expr) : Prop where
  primeTest : prog[Idx.primeTest]? = some body_primeTest
  primeTestStep : prog[Idx.primeTestStep]? = some body_primeTestStep
  leastPrimeGE : prog[Idx.leastPrimeGE]? = some body_leastPrimeGE
  leastPrimeGEStep : prog[Idx.leastPrimeGEStep]? = some body_leastPrimeGEStep
  powMod : prog[Idx.powMod]? = some body_powMod
  powModStep : prog[Idx.powModStep]? = some body_powModStep
  fpUpdate : prog[Idx.fpUpdate]? = some body_fpUpdate

/-! ### Reference facts -/

theorem primeTest_true_of {n : ℕ} (h2 : 2 ≤ n) (h : ∀ j, 2 ≤ j → j < n → n % j ≠ 0) :
    Hash.primeTest n = true := by
  unfold Hash.primeTest
  rw [Bool.and_eq_true, decide_eq_true_eq, List.all_eq_true]
  refine ⟨h2, fun i hi => ?_⟩
  rw [List.mem_range] at hi
  rw [bne_iff_ne, ne_eq]
  exact h (i + 2) (by omega) (by omega)

theorem primeTest_false_of {n d : ℕ} (hd2 : 2 ≤ d) (hdn : d < n) (h : n % d = 0) :
    Hash.primeTest n = false := by
  unfold Hash.primeTest
  rw [Bool.eq_false_iff]
  intro hall
  rw [Bool.and_eq_true, List.all_eq_true] at hall
  have := hall.2 (d - 2) (List.mem_range.2 (by omega))
  rw [show d - 2 + 2 = d by omega, h] at this
  simp at this

theorem primeTest_false_of_lt_two {n : ℕ} (h : n < 2) : Hash.primeTest n = false := by
  unfold Hash.primeTest
  simp [show ¬ 2 ≤ n by omega]

theorem bitLen_emod_le_nat (n d : ℕ) : bitLen ((n : ℤ) % (d : ℤ)) ≤ bitLen (n : ℤ) := by
  apply bitLen_le_bitLen_of_natAbs_le
  rw [← Int.natCast_mod, Int.natAbs_natCast, Int.natAbs_natCast]
  exact Nat.mod_le n d

/-! ### `primeTest`: loop steps -/

theorem primeTestStep_done (prog : List Expr) (base : ℕ) (d n : ℤ) :
    EvalsSp prog base [Val.list [Val.int 0, Val.int d, Val.int n]] body_primeTestStep
      (Val.list [Val.int 0, Val.int 1])
      (base + 4 * valSize (Val.list [Val.int 0, Val.int d, Val.int n]) + 20) := by
  apply EvalsSp.of_eval' 20
  simp only [body_primeTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eMod, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

theorem primeTestStep_found (prog : List Expr) (base c' d n : ℕ) (hd : d ≠ 0) (hr : n % d = 0) :
    EvalsSp prog base [Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int d, Val.int n]]
      body_primeTestStep (Val.list [Val.int 0, Val.int 0])
      (base + 4 * valSize (Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int d, Val.int n]) + 20) := by
  have hc0 : ((c' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hd0 : (d : ℤ) ≠ 0 := by exact_mod_cast hd
  have hmod : (n : ℤ) % (d : ℤ) = 0 := by
    rw [← Int.natCast_mod, hr]
    rfl
  apply EvalsSp.of_eval' 20
  simp only [body_primeTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eMod, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hc0, hd0, hmod, not_false_eq_true, not_true_eq_false,
    one_ne_zero, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

theorem primeTestStep_next (prog : List Expr) (base c' d n : ℕ) (hd : d ≠ 0) (hr : n % d ≠ 0) :
    EvalsSp prog base [Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int d, Val.int n]]
      body_primeTestStep
      (Val.list [Val.int 1, Val.list [Val.int (c' : ℤ), Val.int ((d + 1 : ℕ) : ℤ), Val.int n]])
      (base + 4 * valSize (Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int d, Val.int n]) +
        3 * bitLen (n : ℤ) + 3 * bitLen ((d + 1 : ℕ) : ℤ) + 40) := by
  have hc0 : ((c' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hd0 : (d : ℤ) ≠ 0 := by exact_mod_cast hd
  have hmod : ¬ (n : ℤ) % (d : ℤ) = 0 := by
    rw [← Int.natCast_mod]
    exact_mod_cast hr
  have hcc : ((c' + 1 : ℕ) : ℤ) - 1 = (c' : ℤ) := by push_cast; ring
  have hdd : (d : ℤ) + 1 = ((d + 1 : ℕ) : ℤ) := by push_cast; ring
  have hbr := bitLen_emod_le_nat n d
  have hbc : bitLen (c' : ℤ) ≤ bitLen ((c' + 1 : ℕ) : ℤ) := bitLen_mono_nat (by omega)
  apply EvalsSp.of_eval' 20
  simp only [body_primeTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eMod, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hc0, hd0, hmod, not_false_eq_true, not_true_eq_false,
    zero_ne_one, ↓reduceIte, hcc, hdd]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

/-! ### `primeTest`: the loop and the spec -/

/-- Encoding of the `primeTest` loop state `[cnt, d, n]`. -/
def encPT (n : ℕ) (s : ℕ × ℕ) : Val := Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int (n : ℤ)]

/-- Space bound of `primeTest` (on top of the base). -/
def S_primeTest (n : ℕ) : ℕ := 30 * Nat.size n + 200

theorem primeTest_loop {prog : List Expr} (hL : FpLib prog) (n base : ℕ) :
    ∀ s : ℕ × ℕ, (2 ≤ s.2 ∧ s.2 + s.1 = n ∧ ∀ j, 2 ≤ j → j < s.2 → n % j ≠ 0) →
      ∃ out, out = encB (Hash.primeTest n) ∧
        LoopSp prog base Idx.primeTestStep (encPT n s) out (base + S_primeTest n) := by
  have key := LoopSp.of_measure (prog := prog) (base := base) hL.primeTestStep (encPT n)
    (fun s : ℕ × ℕ => 2 ≤ s.2 ∧ s.2 + s.1 = n ∧ ∀ j, 2 ≤ j → j < s.2 → n % j ≠ 0)
    (fun out => out = encB (Hash.primeTest n)) (fun s => s.1) (S := base + S_primeTest n) ?_
  · intro s hs
    obtain ⟨out, h1, h2⟩ := key s hs
    exact ⟨out, h1, h2⟩
  · rintro ⟨cnt, d⟩ ⟨hd2, hsum, hall⟩
    simp only at hd2 hsum hall
    have hbn : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
    have hbd : bitLen (d : ℤ) ≤ Nat.size n := bitLen_le_size_of_le (by omega)
    have hbc : bitLen (cnt : ℤ) ≤ Nat.size n := bitLen_le_size_of_le (by omega)
    have hvs : valSize (encPT n (cnt, d)) ≤ 3 * Nat.size n + 7 := by
      simp only [encPT, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    rcases cnt with _ | c'
    · -- all divisors tested: prime
      left
      refine ⟨Val.int 1, ?_, ?_⟩
      · have e : encPT n (0, d) = Val.list [Val.int 0, Val.int (d : ℤ), Val.int (n : ℤ)] := by
          simp only [encPT, Nat.cast_zero]
        rw [e] at hvs ⊢
        refine (primeTestStep_done prog _ _ _).mono ?_
        simp only [S_primeTest]
        omega
      · rw [primeTest_true_of (by omega) (fun j hj1 hj2 => hall j hj1 (by omega))]
        rfl
    · have hd0 : d ≠ 0 := by omega
      have e1 : encPT n (c' + 1, d) =
          Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int (d : ℤ), Val.int (n : ℤ)] := rfl
      by_cases hr : n % d = 0
      · -- `d` divides `n`: not prime
        left
        refine ⟨Val.int 0, ?_, ?_⟩
        · have h1 := primeTestStep_found prog (base + valSize (encPT n (c' + 1, d))) c' d n hd0 hr
          rw [← e1] at h1
          refine h1.mono ?_
          simp only [S_primeTest]
          omega
        · rw [primeTest_false_of hd2 (by omega) hr]
          rfl
      · -- next divisor
        right
        have h1 := primeTestStep_next prog (base + valSize (encPT n (c' + 1, d))) c' d n hd0 hr
        have e2 : Val.list [Val.int (c' : ℤ), Val.int ((d + 1 : ℕ) : ℤ), Val.int (n : ℤ)] =
            encPT n (c', d + 1) := rfl
        rw [← e1, e2] at h1
        have hbd1 : bitLen ((d + 1 : ℕ) : ℤ) ≤ Nat.size n := bitLen_le_size_of_le (by omega)
        refine ⟨1, (c', d + 1), one_ne_zero, h1.mono ?_, ⟨?_, ?_, ?_⟩, Nat.lt_succ_self c'⟩
        · simp only [S_primeTest]
          omega
        · simp only
          omega
        · simp only
          omega
        · simp only
          intro j hj1 hj2
          rcases Nat.lt_or_ge j d with h | h
          · exact hall j hj1 h
          · have : j = d := by omega
            rw [this]
            exact hr

/-- **Spec of `primeTest`.** -/
theorem primeTest_spec {prog : List Expr} (hL : FpLib prog) (n base : ℕ) :
    EvalsSp prog base [encN n] body_primeTest (encB (Hash.primeTest n))
      (base + 2 * valSize (encN n) + S_primeTest n + 20) := by
  have hbn : bitLen (n : ℤ) = Nat.size n := bitLen_natCast n
  have hb2 : bitLen (2 : ℤ) = 2 := by decide
  by_cases hn : n < 2
  · have hlt : (n : ℤ) < 2 := by exact_mod_cast hn
    have h1 := EvalsSp.ite_true
      (EvalsSp.lt (EvalsSp.var (prog := prog) (base := base) (env := [encN n]) (i := 0) rfl)
        (EvalsSp.lit (prog := prog) (base := base + valSize (encN n)) (env := [encN n]) 2))
      (by simp [encN, hlt])
      (EvalsSp.lit (prog := prog) (base := base) (env := [encN n]) 0)
      (t := Expr.lit 0) (f := eLoop Idx.primeTestStep (eList [eSub (eV 0) (eLit 2), eLit 2, eV 0]))
    rw [primeTest_false_of_lt_two hn]
    refine h1.mono ?_
    simp only [encN, valSize_int, max_le_iff, bitLen_zero, hb2, S_primeTest, hlt, ↓reduceIte,
      bitLen_one]
    omega
  · have hge : ¬ (n : ℤ) < 2 := by exact_mod_cast hn
    have h2n : 2 ≤ n := by omega
    obtain ⟨out, hout, hloop⟩ := primeTest_loop hL n base (n - 2, 2)
      ⟨le_rfl, by simp only; omega, fun j hj1 hj2 => by simp only at hj2; omega⟩
    subst hout
    have hinit : EvalsSp prog base [encN n] (eList [eSub (eV 0) (eLit 2), eLit 2, eV 0])
        (encPT n (n - 2, 2)) (base + 4 * valSize (encN n) + 30) := by
      apply EvalsSp.of_eval' 20
      have hsub : (n : ℤ) - 2 = ((n - 2 : ℕ) : ℤ) := by
        rw [Nat.cast_sub h2n]
        rfl
      simp only [encN, encPT, eList, eCons, eSub, eV, eLit, eval_succ_var, eval_succ_lit,
        eval_succ_nil, eval_succ_bin, evalBin, Option.bind_some, Option.map_some,
        List.getElem?_cons_zero, hsub, Nat.cast_ofNat]
      refine ⟨_, _, rfl, ?_⟩
      have hb2' : bitLen ((n - 2 : ℕ) : ℤ) ≤ Nat.size n := bitLen_le_size_of_le (by omega)
      simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, hb2]
      omega
    have h1 := EvalsSp.ite_false
      (EvalsSp.lt (EvalsSp.var (prog := prog) (base := base) (env := [encN n]) (i := 0) rfl)
        (EvalsSp.lit (prog := prog) (base := base + valSize (encN n)) (env := [encN n]) 2))
      (by simp [encN, hge])
      (EvalsSp.loop hinit hloop) (t := Expr.lit 0)
    refine h1.mono ?_
    simp only [encN, valSize_int, max_le_iff, hb2, S_primeTest, hge, ↓reduceIte, bitLen_zero]
    omega

/-- **Spec of `call Idx.primeTest`.** -/
theorem primeTest_call {prog : List Expr} (hL : FpLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {n Se : ℕ} (he : EvalsSp prog base env e (encN n) Se) :
    EvalsSp prog base env (Expr.call Idx.primeTest e) (encB (Hash.primeTest n))
      (max Se (base + 3 * valSize (encN n) + S_primeTest n + 20)) := by
  refine (EvalsSp.call he hL.primeTest (primeTest_spec hL n _)).mono ?_
  simp only [max_le_iff]
  omega

/-! ### `leastPrimeGE`: loop steps -/

theorem leastPrimeGEStep_stop (prog : List Expr) (base : ℕ) (s : ℤ) :
    EvalsSp prog base [Val.list [Val.int s, Val.int 0]] body_leastPrimeGEStep
      (Val.list [Val.int 0, Val.int s]) (base + 4 * valSize (Val.list [Val.int s, Val.int 0]) + 20) := by
  apply EvalsSp.of_eval' 20
  simp only [body_leastPrimeGEStep, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

theorem leastPrimeGEStep_found {prog : List Expr} (hL : FpLib prog) (base s k' : ℕ)
    (ht : Hash.primeTest s = true) :
    EvalsSp prog base [Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ)]] body_leastPrimeGEStep
      (Val.list [Val.int 0, Val.int s])
      (base + 4 * valSize (Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ)]) +
        2 * valSize (encN s) + S_primeTest s + 60) := by
  obtain ⟨f1, c1, p1, hp1, hu1⟩ := uniform_of_sp (primeTest_spec hL s 0)
  simp only [encN, encB, ht, zero_add, ↓reduceIte] at hu1 hp1
  have hk0 : ((k' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  apply EvalsSp.of_eval' (f1 + 30)
  simp only [body_leastPrimeGEStep, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte, hL.primeTest]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, ↓reduceIte, ne_eq, one_ne_zero, not_false_eq_true,
    List.getElem?_cons_zero, List.getElem?_cons_succ]
  refine ⟨_, _, rfl, ?_⟩
  have hes : valSize (encN s) = valSize (Val.int (s : ℤ)) := rfl
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hes hp1 ⊢
  omega

theorem leastPrimeGEStep_next {prog : List Expr} (hL : FpLib prog) (base s k' : ℕ)
    (ht : Hash.primeTest s = false) :
    EvalsSp prog base [Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ)]] body_leastPrimeGEStep
      (Val.list [Val.int 1, Val.list [Val.int ((s + 1 : ℕ) : ℤ), Val.int (k' : ℤ)]])
      (base + 4 * valSize (Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ)]) +
        2 * valSize (encN s) + S_primeTest s + 2 * bitLen ((s + 1 : ℕ) : ℤ) + 60) := by
  obtain ⟨f1, c1, p1, hp1, hu1⟩ := uniform_of_sp (primeTest_spec hL s 0)
  simp only [encN, encB, ht, zero_add, Bool.false_eq_true, ↓reduceIte] at hu1 hp1
  have hk0 : ((k' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hss : (s : ℤ) + 1 = ((s + 1 : ℕ) : ℤ) := by push_cast; ring
  have hkk : ((k' + 1 : ℕ) : ℤ) - 1 = (k' : ℤ) := by push_cast; ring
  have hbk : bitLen (k' : ℤ) ≤ bitLen ((k' + 1 : ℕ) : ℤ) := bitLen_mono_nat (by omega)
  apply EvalsSp.of_eval' (f1 + 30)
  simp only [body_leastPrimeGEStep, eLet, eHd, eAt1, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte, hL.primeTest]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, ↓reduceIte, ne_eq, not_true_eq_false,
    List.getElem?_cons_zero, List.getElem?_cons_succ, hss, hkk, zero_ne_one, not_false_eq_true]
  refine ⟨_, _, rfl, ?_⟩
  have hes : valSize (encN s) = valSize (Val.int (s : ℤ)) := rfl
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one] at hes hp1 ⊢
  omega

/-! ### `leastPrimeGE`: the loop and the spec -/

/-- Encoding of the `leastPrimeGE` loop state `[s, k]`. -/
def encLP (s : ℕ × ℕ) : Val := Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ)]

theorem S_primeTest_mono {a b : ℕ} (h : a ≤ b) : S_primeTest a ≤ S_primeTest b := by
  unfold S_primeTest
  have := Nat.size_le_size h
  omega

/-- Space bound of the `leastPrimeGE` loop, for candidates and counters `≤ B`. -/
def S_leastPrimeLoop (B : ℕ) : ℕ := 20 * Nat.size B + S_primeTest B + 200

theorem leastPrimeGE_loop {prog : List Expr} (hL : FpLib prog) (B T base : ℕ) :
    ∀ s : ℕ × ℕ, (Hash.searchFrom Hash.primeTest s.1 s.2 = T ∧ s.1 + s.2 ≤ B) →
      ∃ out, out = encN T ∧
        LoopSp prog base Idx.leastPrimeGEStep (encLP s) out (base + S_leastPrimeLoop B) := by
  have key := LoopSp.of_measure (prog := prog) (base := base) hL.leastPrimeGEStep encLP
    (fun s : ℕ × ℕ => Hash.searchFrom Hash.primeTest s.1 s.2 = T ∧ s.1 + s.2 ≤ B)
    (fun out => out = encN T) (fun s => s.2) (S := base + S_leastPrimeLoop B) ?_
  · intro s hs
    obtain ⟨out, h1, h2⟩ := key s hs
    exact ⟨out, h1, h2⟩
  · rintro ⟨s, k⟩ ⟨hsrch, hle⟩
    simp only at hsrch hle
    have hbs : bitLen (s : ℤ) ≤ Nat.size B := bitLen_le_size_of_le (by omega)
    have hbk : bitLen (k : ℤ) ≤ Nat.size B := bitLen_le_size_of_le (by omega)
    have hvs : valSize (encLP (s, k)) ≤ 2 * Nat.size B + 5 := by
      simp only [encLP, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    have hSp := S_primeTest_mono (show s ≤ B by omega)
    have hvsN : valSize (encN s) ≤ Nat.size B + 1 := by
      simp only [encN, valSize_int]
      omega
    rcases k with _ | k'
    · left
      refine ⟨Val.int (s : ℤ), ?_, ?_⟩
      · have e : encLP (s, 0) = Val.list [Val.int (s : ℤ), Val.int 0] := by
          simp only [encLP, Nat.cast_zero]
        rw [e] at hvs ⊢
        refine (leastPrimeGEStep_stop prog _ _).mono ?_
        simp only [S_leastPrimeLoop]
        omega
      · rw [← hsrch]
        rfl
    · have e1 : encLP (s, k' + 1) = Val.list [Val.int (s : ℤ), Val.int ((k' + 1 : ℕ) : ℤ)] := rfl
      have hstep : Hash.searchFrom Hash.primeTest s (k' + 1) =
          if Hash.primeTest s then s else Hash.searchFrom Hash.primeTest (s + 1) k' := rfl
      cases ht : Hash.primeTest s
      · right
        have h1 := leastPrimeGEStep_next hL (base + valSize (encLP (s, k' + 1))) s k' ht
        have e2 : Val.list [Val.int ((s + 1 : ℕ) : ℤ), Val.int (k' : ℤ)] = encLP (s + 1, k') := rfl
        rw [← e1, e2] at h1
        have hbs1 : bitLen ((s + 1 : ℕ) : ℤ) ≤ Nat.size B := bitLen_le_size_of_le (by omega)
        refine ⟨1, (s + 1, k'), one_ne_zero, h1.mono ?_, ⟨?_, ?_⟩, Nat.lt_succ_self k'⟩
        · simp only [S_leastPrimeLoop]
          omega
        · simp only
          rw [← hsrch, hstep, ht]
          rfl
        · simp only
          omega
      · left
        refine ⟨Val.int (s : ℤ), ?_, ?_⟩
        · have h1 := leastPrimeGEStep_found hL (base + valSize (encLP (s, k' + 1))) s k' ht
          rw [← e1] at h1
          refine h1.mono ?_
          simp only [S_leastPrimeLoop]
          omega
        · rw [← hsrch, hstep, ht]
          rfl

/-- Space bound of `leastPrimeGE` (on top of the base). -/
def S_leastPrimeGE (M : ℕ) : ℕ := 6 * Nat.size (2 * M + 1) + S_leastPrimeLoop (2 * M + 1) + 40

/-- **Spec of `leastPrimeGE`** (the least prime `≥ M`, found by search in `[M, 2M]`). -/
theorem leastPrimeGE_spec {prog : List Expr} (hL : FpLib prog) (M base : ℕ) :
    EvalsSp prog base [encN M] body_leastPrimeGE (encN (Hash.leastPrimeGE M))
      (base + S_leastPrimeGE M) := by
  obtain ⟨out, hout, hloop⟩ := leastPrimeGE_loop hL (2 * M + 1) (Hash.leastPrimeGE M) base
    (M, M + 1) ⟨rfl, by simp only; omega⟩
  subst hout
  have hinit : EvalsSp prog base [encN M] (ePair (eV 0) (eAdd (eV 0) (eLit 1))) (encLP (M, M + 1))
      (base + 6 * Nat.size (2 * M + 1) + 30) := by
    apply EvalsSp.of_eval' 20
    have hMM : (M : ℤ) + 1 = ((M + 1 : ℕ) : ℤ) := by push_cast; ring
    simp only [encN, encLP, ePair, eAdd, eV, eLit, eval_succ_var, eval_succ_lit, eval_succ_nil,
      eval_succ_bin, evalBin, Option.bind_some, Option.map_some, List.getElem?_cons_zero, hMM]
    refine ⟨_, _, rfl, ?_⟩
    have h1 : bitLen (M : ℤ) ≤ Nat.size (2 * M + 1) := bitLen_le_size_of_le (by omega)
    have h2 : bitLen ((M + 1 : ℕ) : ℤ) ≤ Nat.size (2 * M + 1) := bitLen_le_size_of_le (by omega)
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_one]
    omega
  refine (EvalsSp.loop hinit hloop).mono ?_
  simp only [S_leastPrimeGE, max_le_iff]
  omega

/-- **Spec of `call Idx.leastPrimeGE`.** -/
theorem leastPrimeGE_call {prog : List Expr} (hL : FpLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {M Se : ℕ} (he : EvalsSp prog base env e (encN M) Se) :
    EvalsSp prog base env (Expr.call Idx.leastPrimeGE e) (encN (Hash.leastPrimeGE M))
      (max Se (base + valSize (encN M) + S_leastPrimeGE M)) :=
  EvalsSp.call he hL.leastPrimeGE (leastPrimeGE_spec hL M _)

/-! ### `powMod` -/

theorem powModStep_stop (prog : List Expr) (base : ℕ) (acc r q : ℤ) :
    EvalsSp prog base [Val.list [Val.int 0, Val.int acc, Val.int r, Val.int q]] body_powModStep
      (Val.list [Val.int 0, Val.int acc])
      (base + 4 * valSize (Val.list [Val.int 0, Val.int acc, Val.int r, Val.int q]) + 20) := by
  apply EvalsSp.of_eval' 20
  simp only [body_powModStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eSub, eMod, eMul,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

theorem powModStep_cont (prog : List Expr) (base k acc r q : ℕ) (hq : q ≠ 0) :
    EvalsSp prog base [Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.int acc, Val.int r, Val.int q]]
      body_powModStep
      (Val.list [Val.int 1, Val.list [Val.int (k : ℤ), Val.int ((acc * r % q : ℕ) : ℤ),
        Val.int r, Val.int q]])
      (base + 4 * valSize (Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.int acc, Val.int r,
        Val.int q]) + 3 * (bitLen (acc : ℤ) + bitLen (r : ℤ)) + 3 * bitLen (q : ℤ) + 40) := by
  have hk0 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hq0 : (q : ℤ) ≠ 0 := by exact_mod_cast hq
  have hkk : ((k + 1 : ℕ) : ℤ) - 1 = (k : ℤ) := by push_cast; ring
  have hm : (acc : ℤ) * (r : ℤ) % (q : ℤ) = ((acc * r % q : ℕ) : ℤ) := by
    rw [Int.natCast_mod, Nat.cast_mul]
  have hbm := bitLen_mul_le (acc : ℤ) (r : ℤ)
  have hbmod : bitLen ((acc * r % q : ℕ) : ℤ) ≤ bitLen (q : ℤ) :=
    bitLen_mono_nat (Nat.le_of_lt (Nat.mod_lt _ (Nat.pos_of_ne_zero hq)))
  have hbk : bitLen (k : ℤ) ≤ bitLen ((k + 1 : ℕ) : ℤ) := bitLen_mono_nat (by omega)
  apply EvalsSp.of_eval' 20
  simp only [body_powModStep, eLet, eHd, eAt1, eAt2, eAt3, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eSub, eMod, eMul,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, hk0, hq0, not_false_eq_true, not_true_eq_false, ↓reduceIte,
    hkk, hm]
  refine ⟨_, _, rfl, ?_⟩
  simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
    bitLen_one]
  omega

/-- Encoding of the `powMod` loop state `[k, acc, r, q]`. -/
def encPM (r q : ℕ) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int (r : ℤ), Val.int (q : ℤ)]

/-- Space bound of `powMod` (on top of the base). -/
def S_powMod (r i q : ℕ) : ℕ := 12 * (Nat.size i + Nat.size r) + 20 * Nat.size q + 200

theorem powMod_loop {prog : List Expr} (hL : FpLib prog) (r i q base : ℕ) (hq : q ≠ 0) :
    ∀ s : ℕ × ℕ, (s.1 ≤ i ∧ s.2 = r ^ (i - s.1) % q) →
      ∃ out, out = encN (r ^ i % q) ∧
        LoopSp prog base Idx.powModStep (encPM r q s) out (base + S_powMod r i q) := by
  have key := LoopSp.of_measure (prog := prog) (base := base) hL.powModStep (encPM r q)
    (fun s : ℕ × ℕ => s.1 ≤ i ∧ s.2 = r ^ (i - s.1) % q)
    (fun out => out = encN (r ^ i % q)) (fun s => s.1) (S := base + S_powMod r i q) ?_
  · intro s hs
    obtain ⟨out, h1, h2⟩ := key s hs
    exact ⟨out, h1, h2⟩
  · rintro ⟨k, acc⟩ ⟨hk, hacc⟩
    simp only at hk hacc
    have hqpos : 0 < q := Nat.pos_of_ne_zero hq
    have haccq : acc < q := by rw [hacc]; exact Nat.mod_lt _ hqpos
    have hbk : bitLen (k : ℤ) ≤ Nat.size i := bitLen_le_size_of_le hk
    have hba : bitLen (acc : ℤ) ≤ Nat.size q := bitLen_le_size_of_le haccq.le
    have hbr : bitLen (r : ℤ) = Nat.size r := bitLen_natCast r
    have hbq : bitLen (q : ℤ) = Nat.size q := bitLen_natCast q
    have hvs : valSize (encPM r q (k, acc)) ≤ Nat.size i + Nat.size r + 2 * Nat.size q + 9 := by
      simp only [encPM, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    rcases k with _ | k'
    · left
      refine ⟨Val.int (acc : ℤ), ?_, ?_⟩
      · have e : encPM r q (0, acc) =
            Val.list [Val.int 0, Val.int (acc : ℤ), Val.int (r : ℤ), Val.int (q : ℤ)] := by
          simp only [encPM, Nat.cast_zero]
        rw [e] at hvs ⊢
        refine (powModStep_stop prog _ _ _ _).mono ?_
        simp only [S_powMod]
        omega
      · rw [hacc, Nat.sub_zero]
        rfl
    · right
      have h1 := powModStep_cont prog (base + valSize (encPM r q (k' + 1, acc))) k' acc r q hq
      have e1 : encPM r q (k' + 1, acc) =
          Val.list [Val.int ((k' + 1 : ℕ) : ℤ), Val.int (acc : ℤ), Val.int (r : ℤ),
            Val.int (q : ℤ)] := rfl
      have e2 : Val.list [Val.int (k' : ℤ), Val.int ((acc * r % q : ℕ) : ℤ), Val.int (r : ℤ),
          Val.int (q : ℤ)] = encPM r q (k', acc * r % q) := rfl
      rw [← e1, e2] at h1
      refine ⟨1, (k', acc * r % q), one_ne_zero, h1.mono ?_, ⟨?_, ?_⟩, Nat.lt_succ_self k'⟩
      · simp only [S_powMod]
        omega
      · simp only
        omega
      · simp only
        rw [hacc, show i - k' = i - (k' + 1) + 1 by omega, pow_succ, Nat.mul_mod, Nat.mod_mod,
          ← Nat.mul_mod]

/-- **Spec of `powMod`**: `[r, i, q] ↦ r ^ i % q` (`q ≥ 1`). -/
theorem powMod_spec {prog : List Expr} (hL : FpLib prog) (r i q : ℕ) (hq : q ≠ 0) (base : ℕ) :
    EvalsSp prog base [Val.list [encN r, encN i, encN q]] body_powMod (encN (r ^ i % q))
      (base + 4 * valSize (Val.list [encN r, encN i, encN q]) + S_powMod r i q + 40) := by
  obtain ⟨out, hout, hloop⟩ := powMod_loop hL r i q base hq (i, 1 % q)
    ⟨le_rfl, by simp only [Nat.sub_self, pow_zero]⟩
  subst hout
  have hq0 : (q : ℤ) ≠ 0 := by exact_mod_cast hq
  have hinit : EvalsSp prog base [Val.list [encN r, encN i, encN q]]
      (eList [eAt1 (eV 0), eMod (eLit 1) (eAt2 (eV 0)), eHd (eV 0), eAt2 (eV 0)])
      (encPM r q (i, 1 % q)) (base + 4 * valSize (Val.list [encN r, encN i, encN q]) + 40) := by
    apply EvalsSp.of_eval' 20
    have h1q : (1 : ℤ) % (q : ℤ) = ((1 % q : ℕ) : ℤ) := by
      rw [Int.natCast_mod, Nat.cast_one]
    simp only [encN, encPM, eList, eCons, eMod, eHd, eAt1, eAt2, eTl, eV, eLit, eval_succ_var,
      eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, evalBin, evalUn,
      Option.bind_some, Option.map_some, List.getElem?_cons_zero, hq0, ↓reduceIte, h1q]
    refine ⟨_, _, rfl, ?_⟩
    have hb1 : bitLen ((1 % q : ℕ) : ℤ) ≤ 1 := by
      apply bitLen_le_of_abs_lt
      have : 1 % q ≤ 1 := Nat.mod_le 1 q
      rw [abs_of_nonneg (by positivity)]
      norm_num
      omega
    simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_one]
    omega
  refine (EvalsSp.loop hinit hloop).mono ?_
  simp only [max_le_iff]
  omega

/-- **Spec of `call Idx.powMod`.** -/
theorem powMod_call {prog : List Expr} (hL : FpLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {r i q Se : ℕ} (hq : q ≠ 0)
    (he : EvalsSp prog base env e (Val.list [encN r, encN i, encN q]) Se) :
    EvalsSp prog base env (Expr.call Idx.powMod e) (encN (r ^ i % q))
      (max Se (base + 5 * valSize (Val.list [encN r, encN i, encN q]) + S_powMod r i q + 40)) := by
  refine (EvalsSp.call he hL.powMod (powMod_spec hL r i q hq _)).mono ?_
  simp only [max_le_iff]
  omega

/-! ### `fpUpdate` -/

/-- Space bound of `fpUpdate` (on top of the base). -/
def S_fpUpdate (q seed i : ℕ) : ℕ := S_powMod seed i q + 30 * Nat.size q + 200

theorem fpUpdate_val (q seed val i : ℕ) (Δ : ℤ) (hq : q ≠ 0) :
    Val.int (((val : ℤ) + Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ)) % (q : ℤ)) =
      encN (fpUpdateQ q seed val i Δ) := by
  have hq' : (q : ℤ) ≠ 0 := by exact_mod_cast hq
  simp only [encN, fpUpdateQ]
  rw [Int.toNat_of_nonneg (Int.emod_nonneg _ hq')]

/-- **Spec of `fpUpdate`**: `[q, seed, val, i, Δ] ↦ fpUpdateQ q seed val i Δ` (`q ≥ 1`). -/
theorem fpUpdate_spec {prog : List Expr} (hL : FpLib prog) (q seed val i : ℕ) (Δ : ℤ)
    (hq : q ≠ 0) (base : ℕ) :
    EvalsSp prog base [Val.list [encN q, encN seed, encN val, encN i, encZ Δ]] body_fpUpdate
      (encN (fpUpdateQ q seed val i Δ))
      (base + 8 * valSize (Val.list [encN q, encN seed, encN val, encN i, encZ Δ]) +
        S_fpUpdate q seed i) := by
  set X := Val.list [encN q, encN seed, encN val, encN i, encZ Δ] with hX
  have hq0 : (q : ℤ) ≠ 0 := by exact_mod_cast hq
  have hqpos : (0 : ℤ) < q := by positivity
  obtain ⟨f1, c1, p1, hp1, hu1⟩ := uniform_of_sp (powMod_spec hL seed i q hq 0)
  simp only [encN, zero_add] at hu1 hp1
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hp1
  rw [← fpUpdate_val q seed val i Δ hq]
  -- bit-length facts
  have hbq : bitLen (q : ℤ) = Nat.size q := bitLen_natCast q
  have hpm : seed ^ i % q < q := Nat.mod_lt _ (Nat.pos_of_ne_zero hq)
  have hbpm : bitLen ((seed ^ i % q : ℕ) : ℤ) ≤ Nat.size q := bitLen_le_size_of_le hpm.le
  have hdm0 : 0 ≤ Δ % (q : ℤ) := Int.emod_nonneg _ hq0
  have hdm1 : Δ % (q : ℤ) < q := Int.emod_lt_of_pos _ hqpos
  have hbdm : bitLen (Δ % (q : ℤ)) ≤ Nat.size q := by
    rw [← hbq]
    apply bitLen_le_bitLen_of_natAbs_le
    rw [Int.natAbs_natCast]
    have h := Int.natAbs_of_nonneg hdm0
    omega
  have hprod := bitLen_mul_le (Δ % (q : ℤ)) ((seed ^ i % q : ℕ) : ℤ)
  have hsum := bitLen_add_le (val : ℤ) (Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ))
  have hres0 : 0 ≤ ((val : ℤ) + Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ)) % (q : ℤ) :=
    Int.emod_nonneg _ hq0
  have hres1 : ((val : ℤ) + Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ)) % (q : ℤ) < q :=
    Int.emod_lt_of_pos _ hqpos
  have hbres : bitLen (((val : ℤ) + Δ % (q : ℤ) * ((seed ^ i % q : ℕ) : ℤ)) % (q : ℤ)) ≤
      Nat.size q := by
    rw [← hbq]
    apply bitLen_le_bitLen_of_natAbs_le
    rw [Int.natAbs_natCast]
    have h := Int.natAbs_of_nonneg hres0
    omega
  apply EvalsSp.of_eval' (f1 + 30)
  simp only [hX, encN, encZ, body_fpUpdate, eMod, eAdd, eMul, eHd, eAt1, eAt2, eAt3, eAt4, eTl,
    eV, eLit, eList, eCons, eCall,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_call,
    evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, hq0, ↓reduceIte, hL.powMod]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, evalBin, hq0, ↓reduceIte]
  refine ⟨_, _, rfl, ?_⟩
  simp only [S_fpUpdate, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
  omega

/-- **Spec of `call Idx.fpUpdate`.** -/
theorem fpUpdate_call {prog : List Expr} (hL : FpLib prog) {base : ℕ} {env : List Val}
    {e : Expr} {q seed val i : ℕ} {Δ : ℤ} (hq : q ≠ 0) {Se : ℕ}
    (he : EvalsSp prog base env e (Val.list [encN q, encN seed, encN val, encN i, encZ Δ]) Se) :
    EvalsSp prog base env (Expr.call Idx.fpUpdate e) (encN (fpUpdateQ q seed val i Δ))
      (max Se (base + 9 * valSize (Val.list [encN q, encN seed, encN val, encN i, encZ Δ]) +
        S_fpUpdate q seed i)) := by
  refine (EvalsSp.call he hL.fpUpdate (fpUpdate_spec hL q seed val i Δ hq _)).mono ?_
  simp only [max_le_iff]
  omega

end F2e2e.Cost.HashDSL
