import F2e2e.C.Impl.HashBasic

/-!
# HASH area (DSL): generic helpers for proofs with calls and loops (uniform evaluation)

Port of cut2's `Cut2/Cost/Hash/Uniform.lean`, adapted to the tape-threading `eval` of the f2e2e
cost model. A deterministic callee spec `EvalsLe prog 0 env e v C S` yields a *uniform* evaluation
equation: for all large fuels `m`, every base `b` and every tape, `eval prog m b env tape e =
some (v, c, b + p, tape)` with fixed `c ≤ C`, `p ≤ S` (`uniform_of_spec`); the same for loops
(`uniform_of_loop`). The tape is the last (universally quantified) argument, so that the cut2
proofs' `rw [hu _ _ (by omega)]` work unchanged. With these equations, bodies containing calls and
loops can be evaluated symbolically (`simp (disch := omega)` with the `eval_succ_*` lemmas and the
uniform equations), the call costs/peaks staying opaque variables bounded by `C`/`S`.
-/

namespace F2e2e.Cost.HashDSL

theorem uniform_of_spec {prog : List Expr} {env : List Val} {e : Expr} {v : Val} {C S : ℕ}
    (h : EvalsLe prog 0 env e v C S) :
    ∃ f c p, c ≤ C ∧ p ≤ S ∧ ∀ m b, f ≤ m → ∀ tape : List Bool,
      eval prog m b env tape e = some (v, c, b + p, tape) := by
  obtain ⟨c, p, ⟨f, hf⟩, hc, hp⟩ := h
  refine ⟨f, c, p, hc, hp, fun m b hm tape => ?_⟩
  have h0 := eval_tape_indep prog hf tape
  have h1 := eval_fuel_mono prog hm 0 env tape e _ h0
  have h2 := eval_base_shift prog m 0 b env tape e
  rw [Nat.zero_add, h1] at h2
  rw [h2]
  simp [Nat.add_comm]

theorem uniform_of_loop {prog : List Expr} {i : ℕ} {v w : Val} {C S : ℕ}
    (h : LoopLe prog 0 i v w C S) :
    ∃ f c p, c ≤ C ∧ p ≤ S ∧ ∀ m b, f ≤ m → ∀ tape : List Bool,
      loopRun prog m b i v tape = some (w, c, b + p, tape) := by
  obtain ⟨c, p, ⟨f, hf⟩, hc, hp⟩ := h
  refine ⟨f, c, p, hc, hp, fun m b hm tape => ?_⟩
  have h0 := loopRun_tape_indep prog hf tape
  have h1 := loopRun_fuel_mono prog hm 0 i v tape _ h0
  have h2 := loopRun_base_shift prog m 0 b i v tape
  rw [Nat.zero_add, h1] at h2
  rw [h2]
  simp [Nat.add_comm]

end F2e2e.Cost.HashDSL
