import F2e2e.B.ArchCoreSpec
import F2e2e.Cost.Lib.BitFold

/-!
# ADA module (W4), part 5: the exact water level in integers (mathematics)

For integer scores `g` (one learned block, `n = |g|`) and the factor `c = cn/cd` (`cd > 0`), write
`S(x) = cd + cn x`, so that `s = 1 + c x = S(x)/cd` (the list of `capWeightsQ c g`). A level
`ν = N/D` (`D > 0`) is **valid** iff `Φ(ν) = n`, i.e. (`wfMass_eq_wlMass`)

  `wlMass N D = ∑_x clip_{[0, 8 cd D]}(S(x) D − N cd) = n cd D`.

The integer search `wlLevel` (the DSL's): for each `x ∈ g` and each breakpoint `B ∈ {S(x), S(x) − 8cd}`
(`b = B/cd`), with `F = cd Φ(b)` and `k = k_b` computed by one fold (`wlFK`), try the candidates
`(B, cd)` (valid iff `F = n cd`) and, if `k ≠ 0`, `(k B + F − n cd, k cd)` (the interpolated level
`b + (Φ(b) − n)/k`); return the first valid one. These are exactly B-ARCH's `wfCands`, so a valid one
exists (`exists_wfCand`): `wlLevel_spec`. Any valid level gives the weights of `capWeightsQ`
(`capWeightsQ_eq_of_valid`, via the uniqueness of the clipped values `clip_eq_of_wfMass_eq`), hence
the learned predictions (`predLearned_eq`).
-/

namespace F2e2e.C.Impl

open F2e2e.B F2e2e.Cost

/-! ## The integer model -/

/-- `clip_{[lo,hi]}` on integers. -/
def clipZ (lo hi x : ℤ) : ℤ := max lo (min hi x)

/-- `S(x) = cd + cn x`. -/
def wlS (cn cd x : ℤ) : ℤ := cd + cn * x

/-- Fold step of `(F, k)` at the breakpoint `B`. -/
def fkStep (cn cd B : ℤ) (x : ℤ) (s : ℤ × ℤ) : ℤ × ℤ :=
  (s.1 + clipZ 0 (8 * cd) (wlS cn cd x - B),
    s.2 + if wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x then 1 else 0)

/-- `(F, k)` at the breakpoint `B`: `F = cd Φ(B/cd)`, `k = k_{B/cd}`. -/
def wlFK (cn cd : ℤ) (g : List ℤ) (B : ℤ) : ℤ × ℤ := foldP (fkStep cn cd B) g (0, 0)

/-- Fold step of the mass at the level `N/D`. -/
def massStep (cn cd N D : ℤ) (x : ℤ) (m : ℤ) : ℤ :=
  m + clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd)

/-- `cd D Φ(N/D)`. -/
def wlMass (cn cd : ℤ) (g : List ℤ) (N D : ℤ) : ℤ := foldP (massStep cn cd N D) g 0

/-- The candidates of the breakpoint `B`: the first valid one, if any. -/
def wlTry (cn cd : ℤ) (g : List ℤ) (B : ℤ) : Option (ℤ × ℤ) :=
  if (wlFK cn cd g B).1 = (g.length : ℤ) * cd then some (B, cd)
  else if (wlFK cn cd g B).2 ≠ 0 ∧
      wlMass cn cd g ((wlFK cn cd g B).2 * B + (wlFK cn cd g B).1 - (g.length : ℤ) * cd)
        ((wlFK cn cd g B).2 * cd) = (g.length : ℤ) * cd * ((wlFK cn cd g B).2 * cd) then
    some ((wlFK cn cd g B).2 * B + (wlFK cn cd g B).1 - (g.length : ℤ) * cd,
      (wlFK cn cd g B).2 * cd)
  else none

/-- Search step at the score `x` (breakpoints `S(x)`, then `S(x) − 8cd`). -/
def wlStep (cn cd : ℤ) (g : List ℤ) (x : ℤ) (s : Option (ℤ × ℤ)) : Option (ℤ × ℤ) :=
  match s with
  | some r => some r
  | none =>
    match wlTry cn cd g (wlS cn cd x) with
    | some r => some r
    | none => wlTry cn cd g (wlS cn cd x - 8 * cd)

/-- **The exact water level** `(N, D)` (first valid candidate). -/
def wlLevel (cn cd : ℤ) (g : List ℤ) : Option (ℤ × ℤ) := foldP (wlStep cn cd g) g none

/-! ## Folds as sums -/

theorem foldP_add {α : Type} (f : α → ℤ) :
    ∀ (l : List α) (a : ℤ), foldP (fun x s => s + f x) l a = a + (l.map f).sum
  | [], a => by simp [foldP]
  | x :: xs, a => by
    simp only [foldP, List.map_cons, List.sum_cons]
    rw [foldP_add f xs]
    ring

theorem wlMass_eq (cn cd : ℤ) (g : List ℤ) (N D : ℤ) :
    wlMass cn cd g N D = (g.map fun x => clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd)).sum := by
  unfold wlMass
  rw [show massStep cn cd N D = fun x m => m + clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd)
    from rfl, foldP_add]
  simp

theorem foldP_fk (cn cd B : ℤ) :
    ∀ (g : List ℤ) (a b : ℤ), foldP (fkStep cn cd B) g (a, b) =
      (a + (g.map fun x => clipZ 0 (8 * cd) (wlS cn cd x - B)).sum,
        b + (g.map fun x => if wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x then (1 : ℤ) else 0).sum)
  | [], a, b => by simp [foldP]
  | x :: xs, a, b => by
    simp only [foldP, fkStep, List.map_cons, List.sum_cons]
    rw [foldP_fk cn cd B xs]
    simp only [Prod.mk.injEq]
    constructor <;> ring

theorem wlFK_fst (cn cd : ℤ) (g : List ℤ) (B : ℤ) :
    (wlFK cn cd g B).1 = (g.map fun x => clipZ 0 (8 * cd) (wlS cn cd x - B)).sum := by
  unfold wlFK; rw [foldP_fk]; simp

theorem wlFK_snd (cn cd : ℤ) (g : List ℤ) (B : ℤ) :
    (wlFK cn cd g B).2 =
      (g.map fun x => if wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x then (1 : ℤ) else 0).sum := by
  unfold wlFK; rw [foldP_fk]; simp

theorem wlFK_snd_nonneg (cn cd : ℤ) (g : List ℤ) (B : ℤ) : 0 ≤ (wlFK cn cd g B).2 := by
  rw [wlFK_snd]
  apply List.sum_nonneg
  intro y hy
  obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy
  split_ifs <;> norm_num

/-! ## Rational scaling -/

theorem clipQ_div (y q : ℤ) (hq : 0 < q) :
    clipQ 0 8 ((y : ℚ) / q) = (clipZ 0 (8 * q) y : ℚ) / q := by
  have hq' : (0 : ℚ) < q := by exact_mod_cast hq
  unfold clipQ clipZ
  push_cast
  rw [← max_div_div_right hq'.le, ← min_div_div_right hq'.le, zero_div,
    mul_div_cancel_right₀ _ hq'.ne']

theorem clipZ_mul_pos (H y c : ℤ) (hc : 0 < c) : clipZ 0 (H * c) (y * c) = clipZ 0 H y * c := by
  unfold clipZ
  rw [max_mul_of_nonneg _ _ hc.le, min_mul_of_nonneg _ _ hc.le, zero_mul]

theorem sum_map_div_q {α : Type} (l : List α) (f : α → ℤ) (q : ℚ) :
    (l.map fun x => (f x : ℚ) / q).sum = ((l.map f).sum : ℚ) / q := by
  induction l with
  | nil => simp
  | cons x xs ih => simp [ih, add_div]

/-- The list `s` of `capWeightsQ (cn/cd) g`. -/
theorem wl_s_eq {cn cd : ℤ} (hcd : 0 < cd) (x : ℤ) :
    1 + (cn : ℚ) / cd * (x : ℚ) = (wlS cn cd x : ℚ) / cd := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  unfold wlS
  push_cast
  field_simp

/-- **The mass in integers.** -/
theorem wfMass_eq_wlMass {cn cd : ℤ} (hcd : 0 < cd) (g : List ℤ) {N D : ℤ} (hD : 0 < D) :
    wfMass (g.map fun x : ℤ => 1 + (cn : ℚ) / cd * (x : ℚ)) ((N : ℚ) / D) =
      (wlMass cn cd g N D : ℚ) / (cd * D) := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  have hD' : (D : ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  have hq : 0 < cd * D := mul_pos hcd hD
  unfold wfMass
  rw [List.map_map, wlMass_eq]
  have : ∀ x : ℤ, ((fun y => clipQ 0 8 (y - (N : ℚ) / D)) ∘ fun x : ℤ => 1 + (cn : ℚ) / cd * x) x =
      (clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) : ℚ) / ((cd * D : ℤ) : ℚ) := by
    intro x
    simp only [Function.comp]
    rw [wl_s_eq hcd x]
    have h1 : (wlS cn cd x : ℚ) / cd - (N : ℚ) / D =
        ((wlS cn cd x * D - N * cd : ℤ) : ℚ) / ((cd * D : ℤ) : ℚ) := by
      push_cast
      field_simp
    rw [h1, clipQ_div _ _ hq, show 8 * (cd * D) = 8 * cd * D by ring]
  rw [List.map_congr_left (fun x _ => this x), sum_map_div_q]
  push_cast
  rfl

/-- **`F` is `cd Φ(B/cd)`.** -/
theorem wlFK_fst_eq {cn cd : ℤ} (hcd : 0 < cd) (g : List ℤ) (B : ℤ) :
    ((wlFK cn cd g B).1 : ℚ) =
      cd * wfMass (g.map fun x : ℤ => 1 + (cn : ℚ) / cd * (x : ℚ)) ((B : ℚ) / cd) := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  unfold wfMass
  rw [List.map_map, wlFK_fst]
  have : ∀ x : ℤ, ((fun y => clipQ 0 8 (y - (B : ℚ) / cd)) ∘ fun x : ℤ => 1 + (cn : ℚ) / cd * x) x =
      (clipZ 0 (8 * cd) (wlS cn cd x - B) : ℚ) / (cd : ℚ) := by
    intro x
    simp only [Function.comp]
    rw [wl_s_eq hcd x]
    have h1 : (wlS cn cd x : ℚ) / cd - (B : ℚ) / cd = ((wlS cn cd x - B : ℤ) : ℚ) / (cd : ℚ) := by
      push_cast
      field_simp
    rw [h1, clipQ_div _ _ hcd]
  rw [List.map_congr_left (fun x _ => this x), sum_map_div_q]
  field_simp

theorem wl_slope_cond {cn cd : ℤ} (hcd : 0 < cd) (x B : ℤ) :
    ((wlS cn cd x : ℚ) / cd - 8 ≤ (B : ℚ) / cd ∧ (B : ℚ) / cd < (wlS cn cd x : ℚ) / cd) ↔
      (wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x) := by
  have hcd' : (0 : ℚ) < cd := by exact_mod_cast hcd
  have e1 : (wlS cn cd x : ℚ) / cd - 8 = ((wlS cn cd x - 8 * cd : ℤ) : ℚ) / cd := by
    push_cast
    field_simp
  rw [e1, div_le_div_iff_of_pos_right hcd', div_lt_div_iff_of_pos_right hcd']
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨by exact_mod_cast h1, by exact_mod_cast h2⟩
  · rintro ⟨h1, h2⟩
    exact ⟨by exact_mod_cast h1, by exact_mod_cast h2⟩

/-- **`k` is the slope count `k_{B/cd}`.** -/
theorem wlFK_snd_eq {cn cd : ℤ} (hcd : 0 < cd) (g : List ℤ) (B : ℤ) :
    (wlFK cn cd g B).2 =
      (wfSlope (g.map fun x : ℤ => 1 + (cn : ℚ) / cd * (x : ℚ)) ((B : ℚ) / cd) : ℤ) := by
  rw [wlFK_snd]
  induction g with
  | nil => simp [wfSlope_nil]
  | cons x xs ih =>
    rw [List.map_cons, List.sum_cons, ih, List.map_cons, wfSlope_cons, wl_s_eq hcd x]
    by_cases h : wlS cn cd x - 8 * cd ≤ B ∧ B < wlS cn cd x
    · rw [if_pos h, if_pos ((wl_slope_cond hcd x B).mpr h)]
      push_cast; ring
    · rw [if_neg h, if_neg (fun h' => h ((wl_slope_cond hcd x B).mp h'))]
      push_cast; ring

/-! ## Uniqueness of the clipped values -/

theorem clip_eq_of_wfMass_eq_of_le :
    ∀ (s : List ℚ) {ν₁ ν₂ : ℚ}, ν₁ ≤ ν₂ → wfMass s ν₁ = wfMass s ν₂ →
      ∀ x ∈ s, clipQ 0 8 (x - ν₁) = clipQ 0 8 (x - ν₂)
  | [], _, _, _, _, x, hx => by simp at hx
  | y :: t, ν₁, ν₂, h12, h, x, hx => by
    rw [wfMass_cons, wfMass_cons] at h
    have ha := clipQ_sub_anti y h12
    have hA := wfMass_antitone t h12
    have hy : clipQ 0 8 (y - ν₁) = clipQ 0 8 (y - ν₂) := by linarith
    have ht : wfMass t ν₁ = wfMass t ν₂ := by linarith
    rcases List.mem_cons.mp hx with rfl | hx
    · exact hy
    · exact clip_eq_of_wfMass_eq_of_le t h12 ht x hx

/-- **Any two valid levels give the same clipped values.** -/
theorem clip_eq_of_wfMass_eq (s : List ℚ) {ν₁ ν₂ : ℚ} (h : wfMass s ν₁ = wfMass s ν₂) :
    ∀ x ∈ s, clipQ 0 8 (x - ν₁) = clipQ 0 8 (x - ν₂) := by
  rcases le_total ν₁ ν₂ with h12 | h21
  · exact clip_eq_of_wfMass_eq_of_le s h12 h
  · intro x hx
    exact (clip_eq_of_wfMass_eq_of_le s h21 h.symm x hx).symm

/-! ## The search -/

theorem foldP_wlStep_some (cn cd : ℤ) (g : List ℤ) :
    ∀ (l : List ℤ) (r : ℤ × ℤ), foldP (wlStep cn cd g) l (some r) = some r
  | [], _ => rfl
  | _ :: xs, r => foldP_wlStep_some cn cd g xs r

theorem foldP_wlStep_none (cn cd : ℤ) (g : List ℤ) :
    ∀ (l : List ℤ), foldP (wlStep cn cd g) l none = none →
      ∀ x ∈ l, wlTry cn cd g (wlS cn cd x) = none ∧ wlTry cn cd g (wlS cn cd x - 8 * cd) = none
  | [], _, x, hx => by simp at hx
  | y :: xs, h, x, hx => by
    simp only [foldP] at h
    have hy : wlStep cn cd g y none = none := by
      cases hs : wlStep cn cd g y none with
      | none => rfl
      | some r => rw [hs, foldP_wlStep_some] at h; exact absurd h (by simp)
    have hy' : wlTry cn cd g (wlS cn cd y) = none ∧ wlTry cn cd g (wlS cn cd y - 8 * cd) = none := by
      simp only [wlStep] at hy
      cases h1 : wlTry cn cd g (wlS cn cd y) with
      | none => rw [h1] at hy; exact ⟨rfl, hy⟩
      | some r => rw [h1] at hy; exact absurd hy (by simp)
    rw [hy] at h
    rcases List.mem_cons.mp hx with rfl | hx
    · exact hy'
    · exact foldP_wlStep_none cn cd g xs h x hx

theorem foldP_wlStep_mem (cn cd : ℤ) (g : List ℤ) :
    ∀ (l : List ℤ) (r : ℤ × ℤ), foldP (wlStep cn cd g) l none = some r →
      ∃ B, wlTry cn cd g B = some r
  | [], _, h => by simp [foldP] at h
  | y :: xs, r, h => by
    simp only [foldP] at h
    cases hs : wlStep cn cd g y none with
    | none => rw [hs] at h; exact foldP_wlStep_mem cn cd g xs r h
    | some r' =>
      rw [hs, foldP_wlStep_some] at h
      cases h
      simp only [wlStep] at hs
      cases h1 : wlTry cn cd g (wlS cn cd y) with
      | none => rw [h1] at hs; exact ⟨_, hs⟩
      | some r'' => rw [h1] at hs; exact ⟨_, h1.trans hs⟩

/-- Every candidate returned by `wlTry` is valid. -/
theorem wlTry_valid {cn cd : ℤ} (hcd : 0 < cd) (g : List ℤ) {B N D : ℤ}
    (h : wlTry cn cd g B = some (N, D)) :
    0 < D ∧ wlMass cn cd g N D = (g.length : ℤ) * cd * D := by
  unfold wlTry at h
  split_ifs at h with h1 h2
  · simp only [Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨hN, hD⟩ := h
    rw [← hN, ← hD]
    refine ⟨hcd, ?_⟩
    rw [wlMass_eq]
    have : ∀ x : ℤ, clipZ 0 (8 * cd * cd) (wlS cn cd x * cd - B * cd) =
        clipZ 0 (8 * cd) (wlS cn cd x - B) * cd := by
      intro x
      rw [← clipZ_mul_pos _ _ _ hcd]
      congr 1 <;> ring
    rw [List.map_congr_left (fun x _ => this x), List.sum_map_mul_right, ← wlFK_fst, h1]
  · simp only [Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨hN, hD⟩ := h
    rw [← hN, ← hD]
    refine ⟨mul_pos (lt_of_le_of_ne (wlFK_snd_nonneg cn cd g B) (Ne.symm h2.1)) hcd, h2.2⟩

/-- **The water level exists and is valid.** -/
theorem wlLevel_spec {cn cd : ℤ} (hcd : 0 < cd) {g : List ℤ} (hg : g ≠ []) :
    ∃ N D, wlLevel cn cd g = some (N, D) ∧ 0 < D ∧
      wlMass cn cd g N D = (g.length : ℤ) * cd * D := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  have hcdpos : (0 : ℚ) < cd := by exact_mod_cast hcd
  set s := g.map fun x : ℤ => 1 + (cn : ℚ) / cd * (x : ℚ) with hs
  have hsne : s ≠ [] := by simpa [hs] using hg
  have hslen : s.length = g.length := by simp [hs]
  cases hL : wlLevel cn cd g with
  | some r =>
    obtain ⟨N, D⟩ := r
    obtain ⟨B, hB⟩ := foldP_wlStep_mem cn cd g g (N, D) hL
    exact ⟨N, D, rfl, wlTry_valid hcd g hB⟩
  | none =>
    exfalso
    have hnone := foldP_wlStep_none cn cd g g hL
    obtain ⟨ν, hν, hνv⟩ := exists_wfCand s hsne
    -- the breakpoints of `s` are `B/cd` with `B ∈ {S x, S x − 8cd}`, `x ∈ g`
    have hbreak : ∀ b ∈ wfBreaks s, ∃ x ∈ g, ∃ B : ℤ, b = (B : ℚ) / cd ∧
        (B = wlS cn cd x ∨ B = wlS cn cd x - 8 * cd) := by
      intro b hb
      unfold wfBreaks at hb
      rcases List.mem_append.mp hb with hb | hb
      · obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hb
        exact ⟨x, hx, wlS cn cd x, wl_s_eq hcd x, Or.inl rfl⟩
      · obtain ⟨y, hy, rfl⟩ := List.mem_map.mp hb
        obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
        refine ⟨x, hx, wlS cn cd x - 8 * cd, ?_, Or.inr rfl⟩
        rw [wl_s_eq hcd x]
        push_cast
        field_simp
    have hfail : ∀ x ∈ g, ∀ B, (B = wlS cn cd x ∨ B = wlS cn cd x - 8 * cd) →
        wlTry cn cd g B = none := by
      intro x hx B hB
      rcases hB with rfl | rfl
      · exact (hnone x hx).1
      · exact (hnone x hx).2
    unfold wfCands at hν
    rcases List.mem_append.mp hν with hν | hν
    · -- a breakpoint is valid: `F = n cd`
      obtain ⟨x, hx, B, rfl, hB⟩ := hbreak ν hν
      have hT := hfail x hx B hB
      unfold wlTry at hT
      have hF : (wlFK cn cd g B).1 = (g.length : ℤ) * cd := by
        have := wlFK_fst_eq (cn := cn) hcd g B
        rw [← hs, hνv, hslen] at this
        have : ((wlFK cn cd g B).1 : ℚ) = ((g.length * cd : ℤ) : ℚ) := by
          rw [this]; push_cast; ring
        exact_mod_cast this
      rw [if_pos hF] at hT
      exact absurd hT (by simp)
    · -- an interpolated level is valid
      obtain ⟨b, hb, hbν⟩ := List.mem_filterMap.mp hν
      obtain ⟨x, hx, B, rfl, hB⟩ := hbreak b hb
      have hT := hfail x hx B hB
      split_ifs at hbν with hk
      have hk' : (wlFK cn cd g B).2 ≠ 0 := by
        rw [wlFK_snd_eq hcd, ← hs]
        exact_mod_cast hk
      simp only [Option.some.injEq] at hbν
      set F := (wlFK cn cd g B).1 with hFdef
      set k := (wlFK cn cd g B).2 with hkdef
      have hkpos : 0 < k := lt_of_le_of_ne (wlFK_snd_nonneg cn cd g B) (Ne.symm hk')
      have hFq : (F : ℚ) = cd * wfMass s ((B : ℚ) / cd) := wlFK_fst_eq hcd g B
      have hkq : (k : ℚ) = (wfSlope s ((B : ℚ) / cd) : ℚ) := by
        have := wlFK_snd_eq (cn := cn) hcd g B
        rw [← hs] at this
        exact_mod_cast this
      have hkq0 : (k : ℚ) ≠ 0 := by exact_mod_cast hk'
      -- the interpolated level is `(k B + F − n cd)/(k cd)`
      have hνeq : ν = ((k * B + F - (g.length : ℤ) * cd : ℤ) : ℚ) / ((k * cd : ℤ) : ℚ) := by
        rw [← hbν, hslen]
        have hW : wfMass s ((B : ℚ) / cd) = F / cd := by rw [hFq]; field_simp
        rw [hW, ← hkq]
        push_cast
        field_simp
        ring
      have hvalid : wlMass cn cd g (k * B + F - (g.length : ℤ) * cd) (k * cd) =
          (g.length : ℤ) * cd * (k * cd) := by
        have h1 := wfMass_eq_wlMass (cn := cn) hcd g (N := k * B + F - (g.length : ℤ) * cd)
          (mul_pos hkpos hcd)
        rw [← hs, ← hνeq, hνv, hslen] at h1
        have hq : ((cd * (k * cd) : ℤ) : ℚ) ≠ 0 := by
          exact_mod_cast (mul_pos hcd (mul_pos hkpos hcd)).ne'
        have : (wlMass cn cd g (k * B + F - (g.length : ℤ) * cd) (k * cd) : ℚ) =
            ((g.length * cd * (k * cd) : ℤ) : ℚ) := by
          have h2 : (wlMass cn cd g (k * B + F - (g.length : ℤ) * cd) (k * cd) : ℚ) =
              (g.length : ℚ) * ((cd : ℚ) * ((k * cd : ℤ) : ℚ)) := by
            rw [h1]; push_cast; field_simp
          rw [h2]; push_cast; ring
        exact_mod_cast this
      unfold wlTry at hT
      rw [← hFdef, ← hkdef] at hT
      by_cases hF1 : F = (g.length : ℤ) * cd
      · rw [if_pos hF1] at hT
        exact absurd hT (by simp)
      · rw [if_neg hF1, if_pos ⟨hk', hvalid⟩] at hT
        exact absurd hT (by simp)

/-! ## The weights and the predictions -/

/-- **Any valid level gives the exact weights.** -/
theorem capWeightsQ_eq_of_valid {cn cd : ℤ} (hcd : 0 < cd) {g : List ℤ} (hg : g ≠ []) {N D : ℤ}
    (hD : 0 < D) (hv : wlMass cn cd g N D = (g.length : ℤ) * cd * D) :
    capWeightsQ ((cn : ℚ) / cd) g = g.map fun x =>
      (clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) : ℚ) / ((g.length : ℚ) * cd * D) := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  have hD' : (D : ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  have hn : (g.length : ℚ) ≠ 0 := by
    have : 0 < g.length := List.length_pos_iff.mpr hg
    exact_mod_cast this.ne'
  set s := g.map fun x : ℤ => 1 + (cn : ℚ) / cd * (x : ℚ) with hs
  have hsne : s ≠ [] := by simpa [hs] using hg
  have hslen : s.length = g.length := by simp [hs]
  have h1 : wfMass s (wfLevel s) = s.length := wfMass_wfLevel s hsne
  have h2 : wfMass s ((N : ℚ) / D) = s.length := by
    rw [hs, wfMass_eq_wlMass hcd g hD, hv, ← hs, hslen]
    push_cast
    field_simp
  have huniq := clip_eq_of_wfMass_eq s (h1.trans h2.symm)
  unfold capWeightsQ
  simp only []
  rw [← hs, hslen, hs, List.map_map]
  apply List.map_congr_left
  intro x hx
  simp only [Function.comp]
  have hxs : 1 + (cn : ℚ) / cd * (x : ℚ) ∈ s := List.mem_map.mpr ⟨x, hx, rfl⟩
  rw [huniq _ hxs, wl_s_eq hcd x]
  have hq : 0 < cd * D := mul_pos hcd hD
  have h3 : (wlS cn cd x : ℚ) / cd - (N : ℚ) / D =
      ((wlS cn cd x * D - N * cd : ℤ) : ℚ) / ((cd * D : ℤ) : ℚ) := by
    push_cast
    field_simp
  rw [h3, clipQ_div _ _ hq, show 8 * (cd * D) = 8 * cd * D by ring]
  push_cast
  field_simp

/-- The numerator of a learned prediction (the DSL's zip fold). -/
def predNum (cn cd N D : ℤ) (g : List ℤ) (v : List ℕ) : ℤ :=
  (List.zipWith (fun x (vi : ℕ) => clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (vi : ℤ)) g v).sum

/-- **The learned prediction** `μ_j = predNum/(2^{qA} n cd D)`. -/
theorem predLearned_eq {cn cd : ℤ} (hcd : 0 < cd) {g : List ℤ} (hg : g ≠ []) {N D : ℤ}
    (hD : 0 < D) (hv : wlMass cn cd g N D = (g.length : ℤ) * cd * D) (qA : ℕ) (v : List ℕ) :
    predLearned ((1 / 2) ^ qA) (capWeightsQ ((cn : ℚ) / cd) g) v =
      (predNum cn cd N D g v : ℚ) / (2 ^ qA * g.length * cd * D) := by
  have hcd' : (cd : ℚ) ≠ 0 := by exact_mod_cast hcd.ne'
  have hD' : (D : ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  have hn : (g.length : ℚ) ≠ 0 := by
    have : 0 < g.length := List.length_pos_iff.mpr hg
    exact_mod_cast this.ne'
  rw [capWeightsQ_eq_of_valid hcd hg hD hv]
  unfold predLearned predNum
  set q : ℚ := (g.length : ℚ) * cd * D with hq
  have hq0 : q ≠ 0 := by rw [hq]; exact mul_ne_zero (mul_ne_zero hn hcd') hD'
  have key : ∀ (g : List ℤ) (v : List ℕ),
      (List.zipWith (fun (wi : ℚ) (vi : ℕ) => wi * (vi : ℚ))
        (g.map fun x => (clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) : ℚ) / q) v).sum =
      ((List.zipWith (fun x (vi : ℕ) => clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (vi : ℤ))
        g v).sum : ℚ) / q := by
    intro g v
    induction g generalizing v with
    | nil => simp
    | cons x xs ih =>
      cases v with
      | nil => simp
      | cons vi vs =>
        simp only [List.map_cons, List.zipWith_cons_cons, List.sum_cons]
        rw [ih vs]
        push_cast
        ring
  rw [key, hq, one_div_pow]
  ring

/-- **The anchor prediction** `μ_p = (∑ v)/(2^{qA} n_p)`. -/
theorem predAnchor_eq (qA np : ℕ) (v : List ℕ) :
    predAnchor ((1 / 2) ^ qA) np v = ((v.map fun x : ℕ => (x : ℤ)).sum : ℚ) / (2 ^ qA * np) := by
  unfold predAnchor
  have h : ((v.map fun x => (x : ℚ)).sum) = ((v.map fun x : ℕ => (x : ℤ)).sum : ℚ) := by
    induction v with
    | nil => rfl
    | cons a l ih => simp_all
  rw [h, one_div_pow]
  ring

end F2e2e.C.Impl
