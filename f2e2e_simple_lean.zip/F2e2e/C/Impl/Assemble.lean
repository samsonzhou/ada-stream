import F2e2e.C.Impl.AsmRank
import F2e2e.C.Impl.W6Helpers
import F2e2e.C.Impl.ParamsSpecs
import F2e2e.C.Impl.HashContracts
import F2e2e.C.Impl.BankContract
import F2e2e.C.Impl.AdaValid
import F2e2e.C.Top.AssembleW
import F2e2e.C.Top.AlgInstance
import F2e2e.C.SpaceChain

/-!
# Theorem (C), assembly: the DSL implementation of C-ALG's algorithm and the top-level theorems

Owner: C-SPACE (assembly end of W6). With the routine table and the two programs
(`F2e2e/C/Impl/AsmTable.lean`, `F2e2e/C/Impl/AsmRank.lean`):

* `contracts`: every area's contract for `mkProg main theTable` (any entry body `main`, any value bound
  `M`), in C-TOP's order: `normQ` and W1 first, then W4 (from W1 and `normQ`), W5 and W3 (from W1, W4),
  W2;
* `theImpl : Impl theAlg asmS` (C-TOP's interface, `F2e2e/C/Top/Interface.lean`): the encoding
  `encState adaRep.enc`, the programs `initProg`, `updProg`, and their runs (`asm_init_runs`,
  `asm_upd_runs`) from W6's `init_impl` / `round_impl` and C-TOP's generic space theorem at the entry
  point, with the per-run peak bound `asmS P = D · Mv adaRep P`, `D = (r₀ + 1)(K + 3) + 1` (`asmD`);
* `spaceOK : SpaceOK asmS` (C-SPACE's chain: `D · 2^32 ≤ 2^167`);
* **`theorem_C_of_lawBound : TheLawBound → F2e2e.Theorem_C`** (the Spec's statement: footprint plus per-step
  workspace in bits of the small-step machine): C-TOP's `theorem_C_of_runsBound` with `theAlg_total`,
  `theAlg_good`, `theImpl`, `runsBound_W`; the hypothesis `TheLawBound` (`F2e2e/C/Top/AlgInstance.lean`) is
  the Part III target (`F2e2e.C.Closure.theLawBound`, `F2e2e/C/Final.lean`);
* `theorem_C_v1_of_lawBound : TheLawBound → F2e2e.Theorem_C_v1` (the Spec v1 text, `F2e2e/SpecV1Compat.lean`):
  C-TOP's `theorem_C_of_impl` with `spaceOK`;
* Spec v2 / v2.1 (machine-generic form of C-TOP's `F2e2e/C/Top/AssembleW.lean`):
  `theorem_CW_FP : TheLawBound → Theorem_CW Machine.RunsWithinBitsFP` (footprint in bits) and
  `theorem_CW_W : TheLawBound → Theorem_CW Machine.RunsWithinBitsW` (footprint plus per-step
  workspace), from `runsBound_FP` / `runsBound_W` (C-SPACE's `runsWithinBitsFP_spaceBoundC'`,
  `runsWithinBitsW_spaceBoundC'` with `progDepth ≤ 2^8`, `|prog| + 1 ≤ 2^10`, `D ≤ 2^20`).
-/

namespace F2e2e.C.Impl.Asm

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` evaluates parameters symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## The contracts -/

/-- Every area's contract holds for every program assembled from `theTable`. -/
theorem contracts (main : Expr) (M : ℕ) : Contracts adaRep (mkProg main theTable) M := by
  have hq : NormQSpec (mkProg main theTable) M := normQSpec_of_lib (bankLib main)
  have hw1 : W1Contract adaRep (mkProg main theTable) M := w1Contract adaRep (w1Lib main)
  have hw4 : W4Contract adaRep (mkProg main theTable) M := w4Contract (w4Lib main) hw1 hq
  exact ⟨hw1, w2Contract adaRep (fpLib main), w3Contract adaRep adaRep_valid (w3Lib main) hw1 hw4,
    hw4, (w5Contract adaRep adaRep_valid (bankLib main) hw1 hw4 (hornerLib main)).1, hq⟩

/-- Steps 1 and 4 (Tree1, Tree4) in contract form. -/
theorem treeHelpers (main : Expr) (M : ℕ) : W6.TreeHelpers adaRep (mkProg main theTable) M :=
  W6.treeHelpers_of adaRep_valid (contracts main M) (tree1Lib main) (tree4Lib main)

/-! ## The peak bound -/

/-- The peak factor of the generic space theorem at the entry point: `(r₀ + 1)(K + 3) + 1`. -/
def asmD : ℕ := (rAsm 0 + 1) * (asmK + 3) + 1

/-- **The per-run peak bound** `asmS P = D · Mv adaRep P` (tree units of C-TOP's big-step semantics). -/
def asmS (P : StreamParams) : ℝ := ((asmD * Mv adaRep P : ℕ) : ℝ)

theorem asmS_eq (P : StreamParams) : asmS P = (asmD : ℝ) * (Mv adaRep P : ℝ) := by
  unfold asmS
  push_cast
  ring

/-- **The space budget** (Spec v1): `asmS P ≤ spaceBoundC` on the parameters of Theorem C. -/
theorem spaceOK : SpaceOK asmS := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hD : (asmD : ℝ) ≤ 2 ^ 20 := by exact_mod_cast asmD_le
  refine le_spaceBoundC_of_le_Mv hn hm hU hε0 hε1 hβ0 hβ1 hP (α := (asmD : ℝ)) (γ := 0)
    (Nat.cast_nonneg _) le_rfl (by nlinarith) ?_
  rw [asmS_eq, add_zero]

/-! ## The runs -/

/-- The parameter record fits the value bound. -/
theorem valSize_params_le (P : StreamParams) : valSize (encStreamParams P) ≤ Mv adaRep P := by
  obtain ⟨hS1, hMv, -, -, -, hL, hc1, hc2, -⟩ := W6.size_facts adaRep P
  have hpsz := W6.valSize_encStreamParams_le P
  omega

/-- The input of a round fits the value bound. -/
theorem valSize_roundInput_le {P : StreamParams} (hP : ParamsOK P) {s : State}
    (hs : StateInv P (adaRep.ok P) s) (ht : s.t < P.m) {i : ℕ} (hi : i < P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    valSize (Val.list [encStreamParams P, encState adaRep.enc s, encN i, encZ Δ]) ≤
      Mv adaRep P := by
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := W6.size_facts adaRep P
  have hada := adaRep_valid.enc_le P hP
  have hst : valSize (encState adaRep.enc s) ≤ stateSizeBound P (adaRep.bound P) :=
    StateOK.valSize_encState_le hada hs.1 (le_of_lt ht)
  have hpsz := W6.valSize_encStreamParams_le P
  have hn := n_add_two_le P
  have hcP := cP_add_hundred_le P
  have hisz : valSize (encN i) ≤ cP P + 1 := W6.valSize_encN_le_of_lt (by omega)
  have hΔsz : valSize (encZ Δ) ≤ cP P + 2 :=
    W6.valSize_int_le_of_abs_lt (W6.abs_update_lt P hΔ)
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **The initialization runs** within `asmS P`, consuming exactly the bits of C-ALG's `algInit`. -/
theorem asm_init_runs (P : StreamParams) (hP : ParamsOK P) {tape rest : List Bool} {s : State}
    (h : (algInit P).run tape = some (s, rest)) :
    RunsOnRest initProg (encStreamParams P) tape (encState adaRep.enc s) (asmS P) rest := by
  have hI : Implements initProg (Mv adaRep P) [encStreamParams P] W6.body_init
      (encState adaRep.enc) (initState P) :=
    W6.init_impl adaRep_valid (contracts W6.body_init (Mv adaRep P)) hP le_rfl
  obtain ⟨fuel, c, pk, hpk, hf⟩ :=
    hI.eval_entry rankOK_init (mkProg_zero _ _) (valSize_params_le P) h
  exact ⟨W6.body_init, fuel, c, pk, mkProg_zero _ _, hf, by unfold asmS asmD; exact_mod_cast hpk⟩

/-- **A round runs** within `asmS P`, consuming exactly the bits of C-ALG's `roundStep`. -/
theorem asm_upd_runs (P : StreamParams) (hP : ParamsOK P) {s : State}
    (hs : StateInv P (adaRep.ok P) s) (ht : s.t < P.m) {i : ℕ} (hi : i < P.n) {Δ : ℤ}
    (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) {tape rest : List Bool} {s' : State} {q : ℚ}
    (h : (roundStep P s i Δ).run tape = some ((s', q), rest)) :
    RunsOnRest updProg (Val.list [encStreamParams P, encState adaRep.enc s, encN i, encZ Δ]) tape
      (Val.list [encState adaRep.enc s', encQ q]) (asmS P) rest := by
  have hI := W6.round_impl adaRep_valid (contracts W6.body_round (Mv adaRep P))
    (mainLib W6.body_round) (treeHelpers W6.body_round (Mv adaRep P)) (W6.step4Out_of adaRep_valid)
    hP le_rfl hs ht hi hΔ
  obtain ⟨fuel, c, pk, hpk, hf⟩ :=
    hI.eval_entry rankOK_upd (mkProg_zero _ _) (valSize_roundInput_le hP hs ht hi hΔ) h
  exact ⟨W6.body_round, fuel, c, pk, mkProg_zero _ _, hf, by unfold asmS asmD; exact_mod_cast hpk⟩

/-! ## Reachable states -/

theorem asm_algInit_t (P : StreamParams) : Always (algInit P) (fun s => s.t = 0) := by
  show Always ((fpSeedProg P).bind fun r => (newBank P).bind fun B =>
    BitProg.pure (⟨0, false, r, 0, [], [B], 0⟩ : State)) _
  refine @Always.bind_all _ _ (fun s : State => s.t = 0) _ (fun r => ?_) _
  exact @Always.bind_all _ _ (fun s : State => s.t = 0) _ (fun B => always_pure rfl) _

/-- Every reachable state of `theAlg` satisfies C-SPACE's invariant, and its round counter is the number
of rounds. -/
theorem reach_inv {P : StreamParams} (hP : ParamsOK P) {us : ℕ → Fin P.n × ℤ} {t : ℕ}
    {s : theAlg.State} (h : Reach theAlg P us t s) :
    StateInv P (adaRep.ok P) s ∧ State.t s = t := by
  have hA := adaRep_valid.invariant P hP
  induction h with
  | init _ h => exact ⟨initRun_inv P hA h, Always.of_run (asm_algInit_t P) h⟩
  | step _ _ h ih =>
    refine ⟨stepRun_inv P hA ih.1 h, ?_⟩
    have h2 := Always.of_run (algStep_t P _ _ _) h
    simp only at h2
    rw [h2, ih.2]

/-- The estimate of a round is parsed back exactly (`encQ q` is in lowest terms, `q ≥ 0`). -/
theorem parseEstimate_encQ {q : ℚ} (hq : 0 ≤ q) : parseEstimate (encQ q) = some q := by
  have h1 : 0 ≤ q.num := Rat.num_nonneg.mpr hq
  have h2 : (0 : ℤ) < (q.den : ℤ) := by exact_mod_cast q.den_pos
  simp only [encQ, parseEstimate, h1, h2, and_self, if_true, Int.cast_natCast, Rat.num_div_den]

/-! ## The implementation -/

/-- **The DSL implementation of C-ALG's algorithm** (C-TOP's interface `Impl`). -/
def theImpl : Impl theAlg asmS where
  enc := encState adaRep.enc
  initProg := initProg
  updProg := updProg
  init_runs := fun P hP _tape _ s rest h => asm_init_runs P hP h
  upd_runs := fun P hP us t s hR ht hbox _tape _ s' q rest h => by
    obtain ⟨hs, hst⟩ := reach_inv hP hR
    have hq : 0 ≤ q := (Always.of_run (algStep_estimate_mem P s (us t).1.val (us t).2) h).1
    exact ⟨encQ q, parseEstimate_encQ hq,
      asm_upd_runs P hP hs (by omega) (us t).1.isLt (abs_update_le_of_boxSeq hbox) h⟩

/-! ## Theorem (C) -/

/-- **Theorem (C)** (Spec v1 text), from the Part III target `TheLawBound`. -/
theorem theorem_C_v1_of_lawBound (h : TheLawBound) : F2e2e.Theorem_C_v1 :=
  theorem_C_of_impl theAlg theAlg_total (theAlg_good h) asmS theImpl spaceOK

/-- Spec v2's obligation: every run of the two programs within `asmS P` is a machine run whose every step
has footprint at most `spaceBoundC` bits. -/
theorem runsBound_FP : RunsBound F2e2e.Machine.RunsWithinBitsFP theImpl := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 prog hprog input tape out h
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hD : asmD ≤ 2 ^ 40 := asmD_le.trans (by norm_num)
  have hS0 := (asmS_eq (mkStreamParams n m U ε β)).le
  rcases hprog with rfl | rfl
  · exact runsWithinBitsFP_spaceBoundC' hn hm hU hε0 hε1 hβ0 hβ1 hP progDepth_initProg_le
      length_initProg_le (by norm_num) (by norm_num) hD hS0 h
  · exact runsWithinBitsFP_spaceBoundC' hn hm hU hε0 hε1 hβ0 hβ1 hP progDepth_updProg_le
      length_updProg_le (by norm_num) (by norm_num) hD hS0 h

/-- **Theorem (C)** (Spec v2 form: space in bits of the small-step machine), from `TheLawBound`. -/
theorem theorem_CW_FP (h : TheLawBound) : Theorem_CW F2e2e.Machine.RunsWithinBitsFP :=
  theorem_CW_of_impl _ theAlg theAlg_total (theAlg_good h) asmS theImpl runsBound_FP

/-- Spec v2.1's obligation: footprint plus per-step workspace at most `spaceBoundC` bits. -/
theorem runsBound_W : RunsBound F2e2e.Machine.RunsWithinBitsW theImpl := by
  intro n m U ε β hn hm hU hε0 hε1 hβ0 hβ1 prog hprog input tape out h
  have hP := paramsOK_mkStreamParams hn hm hU hε0 hε1 hβ0 hβ1
  have hD : asmD ≤ 2 ^ 40 := asmD_le.trans (by norm_num)
  have hS0 := (asmS_eq (mkStreamParams n m U ε β)).le
  rcases hprog with rfl | rfl
  · exact runsWithinBitsW_spaceBoundC' hn hm hU hε0 hε1 hβ0 hβ1 hP progDepth_initProg_le
      length_initProg_le (by norm_num) (by norm_num) hD hS0 h
  · exact runsWithinBitsW_spaceBoundC' hn hm hU hε0 hε1 hβ0 hβ1 hP progDepth_updProg_le
      length_updProg_le (by norm_num) (by norm_num) hD hS0 h

/-- **Theorem (C)** (Spec v2.1 form: footprint plus per-step workspace), from `TheLawBound`. -/
theorem theorem_CW_W (h : TheLawBound) : Theorem_CW F2e2e.Machine.RunsWithinBitsW :=
  theorem_CW_of_impl _ theAlg theAlg_total (theAlg_good h) asmS theImpl runsBound_W

/-- **Theorem (C)** (the Spec's statement), from the Part III target `TheLawBound`. -/
theorem theorem_C_of_lawBound (h : TheLawBound) : F2e2e.Theorem_C :=
  theorem_C_of_runsBound theAlg theAlg_total (theAlg_good h) asmS theImpl runsBound_W

end F2e2e.C.Impl.Asm
