import F2e2e.C.Impl.MainRound

/-!
# W6: the table of the tree-controller routines (for the assembly)

* `w6Table`: the W6 bodies (Tree2: 250–253, Tree3: 260–275, Main: 370–375);
* `w6LibDeps`: the DSL-CALC library routines they use (reverse, revAppendStep, pow2, range, getOpt);
* `MainLib.of_table`: `MainLib prog` from the lookups of `w6Table ++ w6LibDeps` in `prog`.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

/-- The W6 routines. -/
def w6Table : List (ℕ × Expr) :=
  [(Idx.step2, body_step2), (Idx.step2Elem, body_step2Elem),
   (Idx.step2MapStep, body_mapBStep Idx.step2Elem), (Idx.step2Map, body_step2Map),
   (Idx.step3, body_step3), (Idx.step3Step, body_step3Step),
   (Idx.step3FoldStep, body_foldBStep Idx.step3Step), (Idx.step3Fold, body_foldB Idx.step3FoldStep),
   (Idx.step3Depth, body_step3Depth), (Idx.step3Guard, body_step3Guard),
   (Idx.step3Apply, body_step3Apply),
   (Idx.step3ModYElem, body_step3ModYElem), (Idx.step3ModYStep, body_mapIdxStep Idx.step3ModYElem),
   (Idx.step3ModY, body_mapIdx Idx.step3ModYStep),
   (Idx.step3MapXYElem, body_step3MapXYElem),
   (Idx.step3MapXYStep, body_mapIdxStep Idx.step3MapXYElem),
   (Idx.step3MapXY, body_mapIdx Idx.step3MapXYStep),
   (Idx.step3SetLElem, body_step3SetLElem), (Idx.step3SetLStep, body_mapIdxStep Idx.step3SetLElem),
   (Idx.step3SetL, body_mapIdx Idx.step3SetLStep),
   (Idx.round, body_round), (Idx.roundA, body_roundA), (Idx.roundB, body_roundB),
   (Idx.fin0, body_fin0), (Idx.finQ, body_finQ), (Idx.init, body_init)]

/-- The DSL-CALC library routines used by the W6 routines. -/
def w6LibDeps : List (ℕ × Expr) :=
  [(Cost.Idx.reverse, body_reverse), (Cost.Idx.revAppendStep, body_revAppendStep),
   (Cost.Idx.pow2, body_pow2), (Cost.Idx.pow2Step, body_pow2Step),
   (Cost.Idx.range, body_range), (Cost.Idx.rangeStep, body_rangeStep),
   (Cost.Idx.getOpt, body_getOpt), (Cost.Idx.getOptStep, body_getOptStep)]

/-- `MainLib` (Tree2, Tree3 and Main routines with their library routines) from table lookups. -/
theorem MainLib.of_table {prog : List Expr}
    (h : ∀ p ∈ w6Table ++ w6LibDeps, prog[p.1]? = some p.2) : MainLib prog := by
  have hm : ∀ i b, (i, b) ∈ w6Table ++ w6LibDeps → prog[i]? = some b := fun i b hib => h (i, b) hib
  refine ⟨hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_,
    ⟨hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_⟩,
    ⟨hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_,
      hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_,
      hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_, hm _ _ ?_⟩⟩ <;>
  simp only [w6Table, w6LibDeps, List.cons_append, List.nil_append, List.mem_cons, List.not_mem_nil,
    true_or, or_true]

end F2e2e.C.Impl.W6
