import F2e2e.C.Impl.W6Contracts
import F2e2e.C.Impl.HashHorner
import F2e2e.Cost.Lib.MapB
import F2e2e.Cost.Lib.Sum
import F2e2e.Cost.Lib.Get
import F2e2e.Cost.Lib.Length
import F2e2e.Cost.Arith.Helpers
import F2e2e.Cost.Arith.Median

/-!
# W5: the Norm Bank operations in the DSL — bodies and the library predicate

Owner: W5 (c1b4f720). Reference: C-ALG's `F2e2e/C/Alg/Bank.lean` (`Row.addPhys`, `Row.addGuardY`,
`Row.addGuardXY`, `Row.scaleY`, `Row.scaleXY`, `Row.resetY`, `Bank.mapRows`, `regZ`, `queryIdx`,
`adaVals`, `Bank.validate`, `subgroupMean`, `Bank.release`), `F2e2e/C/Alg/Arith.lean` (`roundMant`,
`guardMant`, `stepCoeffMant`, `lowerMedian`), `F2e2e/C/Alg/State.lean` (`inRangeA`, `inRangeC`,
`Learner.inRange`, `zSat`), `F2e2e/C/Alg/Round.lean` (`Learner.rescale`, `Learner.countCorrection`).
Contracts: C-TOP's `F2e2e/C/Impl/W6Contracts.lean` (`W5Contract`, `NormQSpec`).

## Index table (range 750–899; entries 750–766 fixed by `W6Contracts`)
| idx | body | input | output |
|---|---|---|---|
| 750–755 | `body_resetYBank` … `body_scaleXYBank` | `[encP, encBank B, args…]` | `encBank (B.mapRows op)` |
| 756 | `body_validate` | `[encP, encBank B, encQ S, encQ θ]` | `[encCert, encBank B']` |
| 757 | `body_release` | `[encP, encBank B, encMode mode]` | `[encOptQ, encBank B']` |
| 758 | `body_roundMantQ` | `[encN q, encQ z]` | `roundMant q z` |
| 759 | `body_guardMant` | `[Cint, α, e]` | `guardMant Cint α e` |
| 760 | `body_stepCoeffMant` | `[encB pos, qη, qs, encQ P, encQ Q̂]` | `stepCoeffMant …` |
| 761 | `body_rescaleLearner` | `[encP, cInt, encLearner L]` | `encLearner (L.rescale P cInt)` |
| 762 | `body_countCorrection` | `[encP, encLearner L]` | `encOptLearner (L.countCorrection P)` |
| 763/764 | `body_inRangeA` / `body_inRangeC` | `[encP, encQ x]` | `encB (inRangeA/C P x)` |
| 765 | `body_learnerInRange` | `[encP, encLearner L]` | `encB (L.inRange P)` |
| 766 | `body_normQ` | `[a, b]` (`b > 0`) | `encQ (a / b)` |
| 767 | `body_bkGcdStep` | loop state `[x, y]` | Euclid step |
| 768 | `body_bkSat` | `[Z, z]` | `max (-Z) (min Z z)` (`Z ≥ 0`) |
| 769 | `body_bkRDiv` | `[n, d]` | `(2n + d) / (2d) = ⌊n/d + 1/2⌋` (`d > 0`) |
| 770 | `body_bkRowOp` | `[encRow r, ex]` | `encRow (op r)` (op coded in `ex`) |
| 771–776 | nested `mapB` | rows / blocks / groups | mapped |
| 777 | `body_bkBankMap` | `[encBank B, ex]` | `encBank (B.mapRows op)` |
| 778 | `body_bkZN` | `[encRow r, zx]` | `zN = cnt·2^{eSigma} + b_{D*}·2^{eHb}` (`regZ = zN/2^{eHb+eSigma}`) |
| 779–783 | `body_bkRowQ` + nested `mapB` | rows / blocks | query grid indices (`adaVals`) |
| 784–788 | `body_bkRowSq`, `body_bkSubSum` + `mapB` | subgroups | `∑ zN²` per subgroup |
| 789 | `body_bkZExtra` | `[encP, mode]` | `zx = [mode, 2^eSigma, 2^eHb, w, irrW, D*]` |
| 790 | `body_bkLowerMedian` | list of ints | lower median |
| 791 | `body_bkCoarseScale` | `[encP, zx, grp]` | `[cN, cD]` (`c = cN/cD`) |
| 792 | `body_bkQExtra` | `[encP, zx, cN, cD]` | `qx = [zx, cD, 2^{2(eHb+eSigma)} L cN, 2^{qA}]` |
| 793 | `body_bkReleaseN` | `[encP, [cN, cD], encQ μ]` | `encQ (max 0 (L c μ − ω))` |

Row operations share one dispatcher: `ex = [kind, Z, w, irrW, coord, a, b, both]` with `kind = 0`
(reset `Y`), `1` (add `⌊a·b_coord/b + 1/2⌋` to `Y`, and to `X` if `both = 1`; `addPhys`: `a = Δ 2^{eHb}`,
`b = 1`; guards: `a = δ 2^{eHb}`, `b = 2^{eHg}`) or `2` (replace `Y` (and `X`) by `⌊a·cnt/b + 1/2⌋`;
`a = cInt`, `b = 2^{eHstep}`), every update saturated by `Z = zSat P`.
-/

namespace F2e2e.C.Impl

namespace Idx

/-- Loop body of Euclid's algorithm (`normQ`). -/
abbrev bkGcdStep : ℕ := 767
/-- `[Z, z] ↦ max (-Z) (min Z z)`. -/
abbrev bkSat : ℕ := 768
/-- `[n, d] ↦ (2n + d) / (2d)`. -/
abbrev bkRDiv : ℕ := 769
/-- `[encRow r, ex] ↦ encRow (op r)`. -/
abbrev bkRowOp : ℕ := 770
/-- `mapB` step over the rows of a block (element `bkRowOp`). -/
abbrev bkRowOpStep : ℕ := 771
/-- `[blk, ex] ↦ blk.map op`. -/
abbrev bkBlockOp : ℕ := 772
/-- `mapB` step over blocks (element `bkBlockOp`). -/
abbrev bkBlockOpStep : ℕ := 773
/-- `[blks, ex] ↦ blks.map (map op)`. -/
abbrev bkBlocksOp : ℕ := 774
/-- `mapB` step over groups (element `bkBlocksOp`). -/
abbrev bkBlocksOpStep : ℕ := 775
/-- `[grps, ex] ↦ grps.map (map (map op))`. -/
abbrev bkGroupsOp : ℕ := 776
/-- `[encBank B, ex] ↦ encBank (B.mapRows op)`. -/
abbrev bkBankMap : ℕ := 777
/-- `[encRow r, zx] ↦ zN`. -/
abbrev bkZN : ℕ := 778
/-- `[encRow r, qx] ↦ queryIdx …`. -/
abbrev bkRowQ : ℕ := 779
/-- `mapB` step over rows (element `bkRowQ`). -/
abbrev bkRowQStep : ℕ := 780
/-- `[blk, qx] ↦` the query indices of a block. -/
abbrev bkBlockQ : ℕ := 781
/-- `mapB` step over blocks (element `bkBlockQ`). -/
abbrev bkBlockQStep : ℕ := 782
/-- `[ada, qx] ↦ encVals (adaVals …)`. -/
abbrev bkValsQ : ℕ := 783
/-- `[encRow r, zx] ↦ zN²`. -/
abbrev bkRowSq : ℕ := 784
/-- `mapB` step over rows (element `bkRowSq`). -/
abbrev bkRowSqStep : ℕ := 785
/-- `[sub, zx] ↦ ∑ zN²`. -/
abbrev bkSubSum : ℕ := 786
/-- `mapB` step over subgroups (element `bkSubSum`). -/
abbrev bkSubSumStep : ℕ := 787
/-- `[grp, zx] ↦` the subgroup sums. -/
abbrev bkGroupSums : ℕ := 788
/-- `[encP, mode] ↦ zx`. -/
abbrev bkZExtra : ℕ := 789
/-- `l ↦` the lower median of a list of integers. -/
abbrev bkLowerMedian : ℕ := 790
/-- `[encP, zx, grp] ↦ [cN, cD]`. -/
abbrev bkCoarseScale : ℕ := 791
/-- `[encP, zx, cN, cD] ↦ qx`. -/
abbrev bkQExtra : ℕ := 792
/-- `[encP, [cN, cD], encQ μ] ↦ encQ (max 0 (L c μ − ω))`. -/
abbrev bkReleaseN : ℕ := 793

end Idx

namespace BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top

/-- Element `6` of a list. -/
abbrev eAt6 (e : Expr) : Expr := eHd (eTl (eTl (eTl (eTl (eTl (eTl e))))))
/-- Element `7` of a list. -/
abbrev eAt7 (e : Expr) : Expr := eHd (eTl (eTl (eTl (eTl (eTl (eTl (eTl e)))))))
/-- `0 - e`. -/
abbrev eNeg (e : Expr) : Expr := eSub (eLit 0) e
/-- `2 ^ e` (ARITH's `pow2`). -/
abbrev ePow2 (e : Expr) : Expr := eCall Cost.Idx.pow2 e
/-- `zSat P = Z_max 2^{eHb}` from the parameter record `p`. -/
abbrev eZsat (p : Expr) : Expr := eMul (eCall Idx.pZmax p) (ePow2 (eCall Idx.peHb p))

/-! ## Arithmetic helpers -/

/-- `normQ : [a, b] ↦ [a/g, b/g]`, `g = gcd(b, |a|)` (Euclid's loop from `[b, |a|]`). -/
def body_normQ : Expr :=
  eLet (eHd (eV 0)) <|                                          -- a    [a, I]
  eLet (eAt1 (eV 1)) <|                                         -- b    [b, a, I]
  eLet (eIte (eLt (eV 1) (eLit 0)) (eNeg (eV 1)) (eV 1)) <|     -- |a|  [aa, b, a, I]
  eLet (eLoop Idx.bkGcdStep (ePair (eV 1) (eV 0))) <|           -- g    [g, aa, b, a, I]
  ePair (eDiv (eV 3) (eV 0)) (eDiv (eV 2) (eV 0))

/-- Euclid step; state `[x, y]`: stop with `x` if `y = 0`, else continue with `[y, x mod y]`. -/
def body_bkGcdStep : Expr :=
  eLet (eHd (eV 0)) <|                                          -- x  [x, S]
  eLet (eAt1 (eV 1)) <|                                         -- y  [y, x, S]
  eIte (eEq (eV 0) (eLit 0))
    (ePair (eLit 0) (eV 1))
    (ePair (eLit 1) (ePair (eV 0) (eMod (eV 1) (eV 0))))

/-- `[Z, z] ↦ max (-Z) (min Z z)` (for `Z ≥ 0`). -/
def body_bkSat : Expr :=
  eLet (eHd (eV 0)) <|                                          -- Z  [Z, I]
  eLet (eAt1 (eV 1)) <|                                         -- z  [z, Z, I]
  eIte (eLt (eV 1) (eV 0)) (eV 1)
    (eIte (eLt (eV 0) (eNeg (eV 1))) (eNeg (eV 1)) (eV 0))

/-- `[n, d] ↦ (2n + d) / (2d)` (`= ⌊n/d + 1/2⌋` for `d > 0`). -/
def body_bkRDiv : Expr :=
  eDiv (eAdd (eMul (eLit 2) (eHd (eV 0))) (eAt1 (eV 0))) (eMul (eLit 2) (eAt1 (eV 0)))

/-- `roundMantQ : [q, encQ z] ↦ ⌊z 2^q + 1/2⌋ = rdiv(num 2^q, den)`. -/
def body_roundMantQ : Expr :=
  eCall Idx.bkRDiv (ePair (eMul (eHd (eAt1 (eV 0))) (ePow2 (eHd (eV 0)))) (eAt1 (eAt1 (eV 0))))

/-- `guardMant : [C, α, e]`: `k = 2α + e`, `N = ⌊4 C² 2^k⌋`; `0` if `N < 16`, else
`(⌊√N⌋ + 1) / 2`. -/
def body_guardMant : Expr :=
  eLet (eHd (eV 0)) <|                                          -- C  [C, I]
  eLet (eAdd (eMul (eLit 2) (eAt1 (eV 1))) (eAt2 (eV 1))) <|    -- k  [k, C, I]
  eLet (eMul (eLit 4) (eMul (eV 1) (eV 1))) <|                  -- F  [F, k, C, I]
  eLet (eIte (eLt (eV 1) (eLit 0))
          (eDiv (eV 0) (ePow2 (eNeg (eV 1))))
          (eMul (eV 0) (ePow2 (eV 1)))) <|                      -- N  [N, F, k, C, I]
  eIte (eLt (eV 0) (eLit 16)) (eLit 0)
    (eDiv (eAdd (eCall Cost.Idx.natSqrt (eV 0)) (eLit 1)) (eLit 2))

/-- `stepCoeffMant : [pos, qη, qs, encQ Pval, encQ Q̂]`: `M = MN/MD = (Pval/Q̂) 2^{2qs − 2qη − 6}`;
`a = (⌊√M⌋ + 1)/2` (`pos`) or `-(⌈√M⌉ / 2)` (ARITH's `floorSqrtND` / `ceilSqrtND` on `[MN, MD]`);
result `2^qs + clamp_{[-2^qs/2, 2^qs/2]} a`. -/
def body_stepCoeffMant : Expr :=
  eLet (eAt3 (eV 0)) <|                                         -- Pq   [Pq, I]
  eLet (eAt4 (eV 1)) <|                                         -- Qq   [Qq, Pq, I]
  eLet (eSub (eMul (eLit 2) (eSub (eAt2 (eV 2)) (eAt1 (eV 2)))) (eLit 6)) <|  -- k [k, Qq, Pq, I]
  eLet (eMul (eHd (eV 2)) (eAt1 (eV 1))) <|                     -- num  [num, k, Qq, Pq, I]
  eLet (eMul (eAt1 (eV 3)) (eHd (eV 2))) <|                     -- den  [den, num, k, Qq, Pq, I]
  eLet (eIte (eLt (eV 2) (eLit 0)) (eV 1) (eMul (eV 1) (ePow2 (eV 2)))) <|
                                                                -- MN   [MN, den, num, k, Qq, Pq, I]
  eLet (eIte (eLt (eV 3) (eLit 0)) (eMul (eV 1) (ePow2 (eNeg (eV 3)))) (eV 1)) <|
                                                                -- MD   [MD, MN, den, num, k, Qq, Pq, I]
  eLet (eIte (eEq (eHd (eV 7)) (eLit 0))
      (eNeg (eDiv (eCall Cost.Idx.ceilSqrtND (ePair (eV 1) (eV 0))) (eLit 2)))
      (eDiv (eAdd (eCall Cost.Idx.floorSqrtND (ePair (eV 1) (eV 0))) (eLit 1)) (eLit 2))) <|
                                                                -- a    [a, MD, MN, den, num, k, Qq, Pq, I]
  eLet (ePow2 (eAt2 (eV 8))) <|                                 -- T = 2^qs  [T, a, …]
  eAdd (eV 0) (eCall Cost.Idx.clampZ
    (eList [eNeg (eDiv (eV 0) (eLit 2)), eDiv (eV 0) (eLit 2), eV 1]))

/-- `rescaleLearner : [encP, cInt, encLearner L] ↦` the learner with
`tag' = rdiv(cInt tag, 2^{eHstep})`, `cache' = rdiv(cInt² cache, 2^{2 eHstep})`. -/
def body_rescaleLearner : Expr :=
  eLet (ePow2 (eCall Idx.peHstep (eHd (eV 0)))) <|              -- T   [T, I]
  eLet (eAt1 (eV 1)) <|                                         -- c   [c, T, I]
  eLet (eAt2 (eV 2)) <|                                         -- Le  [Le, c, T, I]
  eCons (eCall Idx.bkRDiv (ePair (eMul (eV 1) (eHd (eV 0))) (eV 2)))
    (eCons (eCall Idx.bkRDiv (ePair (eMul (eMul (eV 1) (eV 1)) (eAt1 (eV 0)))
        (eMul (eV 2) (eV 2))))
      (eTl (eTl (eV 0))))

/-- `countCorrection : [encP, encLearner L] ↦ [] / [encLearner L']`. -/
def body_countCorrection : Expr :=
  eLet (eAt1 (eV 0)) <|                                         -- Le  [Le, I]
  eLet (eAt2 (eV 0)) <|                                         -- ep  [ep, Le, I]
  eLet (eAt3 (eV 1)) <|                                         -- jE  [jE, ep, Le, I]
  eLet (eAt4 (eV 2)) <|                                         -- jU  [jU, jE, ep, Le, I]
  eIte (eEq (eAdd (eV 1) (eLit 1)) (eCall Idx.pK0 (eHd (eV 4))))
    (eIte (eLt (eCall Idx.pKepoch (eHd (eV 4))) (eAdd (eV 2) (eLit 1)))
      Expr.nil
      (eList [eList [eHd (eV 3), eAt1 (eV 3), eAdd (eV 2) (eLit 1), eLit 0,
        eAdd (eV 0) (eLit 1)]]))
    (eList [eList [eHd (eV 3), eAt1 (eV 3), eV 2, eAdd (eV 1) (eLit 1), eAdd (eV 0) (eLit 1)]])

/-- `inRangeA : [encP, encQ x] ↦ encB (0 ≤ num ∧ num ≤ A_max den)`. -/
def body_inRangeA : Expr :=
  eLet (eAt1 (eV 0)) <|                                         -- xq  [xq, I]
  eIte (eLt (eHd (eV 0)) (eLit 0)) (eLit 0)
    (eIte (eLt (eMul (eCall Idx.pAmax (eHd (eV 1))) (eAt1 (eV 0))) (eHd (eV 0))) (eLit 0)
      (eLit 1))

/-- `inRangeC : [encP, encQ x] ↦ encB (0 ≤ num ∧ num ≤ C_max den)`. -/
def body_inRangeC : Expr :=
  eLet (eAt1 (eV 0)) <|                                         -- xq  [xq, I]
  eIte (eLt (eHd (eV 0)) (eLit 0)) (eLit 0)
    (eIte (eLt (eMul (eCall Idx.pCmax (eHd (eV 1))) (eAt1 (eV 0))) (eHd (eV 0))) (eLit 0)
      (eLit 1))

/-- `learnerInRange : [encP, encLearner L] ↦
encB (0 ≤ tag ≤ C_max 2^{eHC} ∧ 0 ≤ cache ≤ A_max 2^{eHP})`. -/
def body_learnerInRange : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P   [P, I]
  eLet (eAt1 (eV 1)) <|                                         -- Le  [Le, P, I]
  eLet (eMul (eCall Idx.pCmax (eV 1)) (ePow2 (eCall Idx.peHC (eV 1)))) <|   -- Cb  [Cb, Le, P, I]
  eLet (eMul (eCall Idx.pAmax (eV 2)) (ePow2 (eCall Idx.peHP (eV 2)))) <|   -- Ab  [Ab, Cb, Le, P, I]
  eIte (eLt (eHd (eV 2)) (eLit 0)) (eLit 0)
    (eIte (eLt (eV 1) (eHd (eV 2))) (eLit 0)
      (eIte (eLt (eAt1 (eV 2)) (eLit 0)) (eLit 0)
        (eIte (eLt (eV 0) (eAt1 (eV 2))) (eLit 0) (eLit 1))))

/-! ## Row operations mapped over a bank -/

/-- The row-operation dispatcher on `[encRow r, ex]`, `ex = [kind, Z, w, irrW, coord, a, b, both]`. -/
def body_bkRowOp : Expr :=
  eLet (eHd (eV 0)) <|                                          -- row  [row, I]
  eLet (eAt1 (eV 1)) <|                                         -- ex   [ex, row, I]
  eLet (eHd (eV 1)) <|                                          -- sd   [sd, ex, row, I]
  eLet (eAt1 (eV 2)) <|                                         -- X    [X, sd, ex, row, I]
  eLet (eAt2 (eV 3)) <|                                         -- Y    [Y, X, sd, ex, row, I]
  eLet (eHd (eV 3)) <|                                          -- k    [k, Y, X, sd, ex, row, I]
  eIte (eEq (eV 0) (eLit 0))
    (eList [eV 3, eV 2, eLit 0]) <|
  eLet (eAt1 (eV 4)) <|                                         -- Z    [Z, k, Y, X, sd, ex, row, I]
  eLet (eAt5 (eV 5)) <|                                         -- a    [a, Z, k, Y, X, sd, ex, …]
  eLet (eAt6 (eV 6)) <|                                         -- b    [b, a, Z, k, Y, X, sd, ex, …]
  eLet (eAt7 (eV 7)) <|                                         -- bo   [bo, b, a, Z, k, Y, X, sd, ex, …]
  eIte (eEq (eV 4) (eLit 1))
    (eLet (eCall Cost.Idx.rowSign (eList [eAt2 (eV 8), eAt3 (eV 8), eV 7, eAt4 (eV 8)])) <|  -- s
     eLet (eCall Idx.bkRDiv (ePair (eMul (eV 3) (eV 0)) (eV 2))) <|                          -- inc
     -- env [inc, s, bo, b, a, Z, k, Y, X, sd, ex, row, I]
     eList [eV 9,
       eIte (eEq (eV 2) (eLit 0)) (eV 8) (eCall Idx.bkSat (ePair (eV 5) (eAdd (eV 8) (eV 0)))),
       eCall Idx.bkSat (ePair (eV 5) (eAdd (eV 7) (eV 0)))])
    (eList [eV 7,
      eIte (eEq (eV 0) (eLit 0)) (eV 6)
        (eCall Idx.bkSat (ePair (eV 3) (eCall Idx.bkRDiv (ePair (eMul (eV 2) (eV 6)) (eV 1))))),
      eCall Idx.bkSat (ePair (eV 3) (eCall Idx.bkRDiv (ePair (eMul (eV 2) (eV 5)) (eV 1))))])

/-- `[encBank B, ex] ↦ [map (map op) ada, map (map (map op)) coarse, st]`. -/
def body_bkBankMap : Expr :=
  eLet (eHd (eV 0)) <|                                          -- bank  [bank, I]
  eLet (eAt1 (eV 1)) <|                                         -- ex    [ex, bank, I]
  eList [eCall Idx.bkBlocksOp (ePair (eHd (eV 1)) (eV 0)),
    eCall Idx.bkGroupsOp (ePair (eAt1 (eV 1)) (eV 0)),
    eAt2 (eV 1)]

/-- 750: `Bank.mapRows Row.resetY`. -/
def body_resetYBank : Expr :=
  eCall Idx.bkBankMap (ePair (eAt1 (eV 0))
    (eList [eLit 0, eLit 0, eLit 0, eLit 0, eLit 0, eLit 0, eLit 1, eLit 0]))

/-- 751: `Bank.mapRows (Row.addPhys P i Δ)` on `[encP, encBank B, encN i, encZ Δ]`. -/
def body_addPhysBank : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
    (eList [eLit 1, eZsat (eV 0), eCall Idx.pw (eV 0), eCall Idx.pIrrW (eV 0), eAt2 (eV 1),
      eMul (eAt3 (eV 1)) (ePow2 (eCall Idx.peHb (eV 0))), eLit 1, eLit 1]))

/-- 752: `Bank.mapRows (Row.addGuardY P g δ)` on `[encP, encBank B, encN g, encZ δ]`. -/
def body_addGuardYBank : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
    (eList [eLit 1, eZsat (eV 0), eCall Idx.pw (eV 0), eCall Idx.pIrrW (eV 0), eAt2 (eV 1),
      eMul (eAt3 (eV 1)) (ePow2 (eCall Idx.peHb (eV 0))), ePow2 (eCall Idx.peHg (eV 0)), eLit 0]))

/-- 753: `Bank.mapRows (Row.addGuardXY P g δ)` on `[encP, encBank B, encN g, encZ δ]`. -/
def body_addGuardXYBank : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
    (eList [eLit 1, eZsat (eV 0), eCall Idx.pw (eV 0), eCall Idx.pIrrW (eV 0), eAt2 (eV 1),
      eMul (eAt3 (eV 1)) (ePow2 (eCall Idx.peHb (eV 0))), ePow2 (eCall Idx.peHg (eV 0)), eLit 1]))

/-- 754: `Bank.mapRows (Row.scaleY P cInt)` on `[encP, encBank B, encZ cInt]`. -/
def body_scaleYBank : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
    (eList [eLit 2, eZsat (eV 0), eLit 0, eLit 0, eLit 0, eAt2 (eV 1),
      ePow2 (eCall Idx.peHstep (eV 0)), eLit 0]))

/-- 755: `Bank.mapRows (Row.scaleXY P cInt)` on `[encP, encBank B, encZ cInt]`. -/
def body_scaleXYBank : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eCall Idx.bkBankMap (ePair (eAt1 (eV 1))
    (eList [eLit 2, eZsat (eV 0), eLit 0, eLit 0, eLit 0, eAt2 (eV 1),
      ePow2 (eCall Idx.peHstep (eV 0)), eLit 1]))

/-! ## Regularized counters, query values, subgroup means -/

/-- `[encP, mode] ↦ [mode, 2^{eSigma}, 2^{eHb}, w, irrW, D*]`. -/
def body_bkZExtra : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eList [eAt1 (eV 1), ePow2 (eCall Idx.peSigma (eV 0)), ePow2 (eCall Idx.peHb (eV 0)),
    eCall Idx.pw (eV 0), eCall Idx.pIrrW (eV 0), eCall Idx.pDstar (eV 0)]

/-- `[encRow r, zx] ↦ zN = cnt·2^{eSigma} + b_{D*}·2^{eHb}` (`cnt = X` or `X − Y`). -/
def body_bkZN : Expr :=
  eLet (eHd (eV 0)) <|                                          -- row  [row, I]
  eLet (eAt1 (eV 1)) <|                                         -- zx   [zx, row, I]
  eLet (eIte (eEq (eHd (eV 0)) (eLit 0)) (eAt1 (eV 1)) (eSub (eAt1 (eV 1)) (eAt2 (eV 1)))) <|
                                                                -- cnt  [cnt, zx, row, I]
  eLet (eCall Cost.Idx.rowSign (eList [eAt3 (eV 1), eAt4 (eV 1), eHd (eV 2), eAt5 (eV 1)])) <|
                                                                -- s    [s, cnt, zx, row, I]
  eAdd (eMul (eV 1) (eAt1 (eV 2))) (eMul (eV 0) (eAt2 (eV 2)))

/-- `[encP, zx, cN, cD] ↦ [zx, cD, 2^{2(eHb+eSigma)} L cN, 2^{qA}]`. -/
def body_bkQExtra : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P  [P, I]
  eList [eAt1 (eV 1), eAt3 (eV 1),
    eMul (eMul (ePow2 (eMul (eLit 2) (eAdd (eCall Idx.peHb (eV 0)) (eCall Idx.peSigma (eV 0)))))
      (eCall Idx.pL (eV 0))) (eAt2 (eV 1)),
    ePow2 (eCall Idx.adaQA (eV 0))]

/-- `[encRow r, qx] ↦ queryIdx qA L c (regZ P mode r)`: with `num = zN² cD`, `den = 2^{2E} L cN`,
`2^{qA}` if `den ≤ num`, else `rdiv(num 2^{qA}, den)`. -/
def body_bkRowQ : Expr :=
  eLet (eAt1 (eV 0)) <|                                         -- qx   [q, I]
  eLet (eCall Idx.bkZN (ePair (eHd (eV 1)) (eHd (eV 0)))) <|    -- zN   [zN, q, I]
  eLet (eMul (eMul (eV 0) (eV 0)) (eAt1 (eV 1))) <|             -- num  [num, zN, q, I]
  eLet (eAt2 (eV 2)) <|                                         -- den  [den, num, zN, q, I]
  eIte (eLt (eV 1) (eV 0))
    (eCall Idx.bkRDiv (ePair (eMul (eV 1) (eAt3 (eV 3))) (eV 0)))
    (eAt3 (eV 3))

/-- `[encRow r, zx] ↦ zN²`. -/
def body_bkRowSq : Expr := eLet (eCall Idx.bkZN (eV 0)) (eMul (eV 0) (eV 0))

/-- `[sub, zx] ↦ ∑_{r ∈ sub} zN(r)²`. -/
def body_bkSubSum : Expr := eCall Cost.Idx.sum (body_mapB Idx.bkRowSqStep)

/-- `l ↦` the entry of index `(|l| − 1)/2` of the sorted list. -/
def body_bkLowerMedian : Expr :=
  eCall Cost.Idx.get (ePair (eCall Cost.Idx.isortZ (eV 0))
    (eDiv (eSub (eCall Cost.Idx.length (eV 0)) (eLit 1)) (eLit 2)))

/-- `[encP, zx, grp] ↦ c = max(med/D, 1/2^{eOmega+1})` as `[cN, cD]`, `D = 32·2^{2(eHb+eSigma)}`,
`med` = the lower median of the subgroup sums. -/
def body_bkCoarseScale : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P    [P, I]
  eLet (eCall Idx.bkLowerMedian (eCall Idx.bkGroupSums (ePair (eAt2 (eV 1)) (eAt1 (eV 1))))) <|
                                                                -- med  [med, P, I]
  eLet (eMul (eLit 32) (ePow2 (eMul (eLit 2)
      (eAdd (eCall Idx.peHb (eV 1)) (eCall Idx.peSigma (eV 1)))))) <|  -- D  [D, med, P, I]
  eLet (ePow2 (eAdd (eCall Idx.peOmega (eV 2)) (eLit 1))) <|   -- O2   [O2, D, med, P, I]
  eIte (eLt (eMul (eV 2) (eV 0)) (eV 1))
    (ePair (eLit 1) (eV 0))
    (ePair (eV 2) (eV 1))

/-- `[encP, [cN, cD], encQ μ] ↦ encQ (max 0 (L c μ − ω))` (`ω = 2^{-eOmega}`). -/
def body_bkReleaseN : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P   [P, I]
  eLet (ePow2 (eCall Idx.peOmega (eV 0))) <|                    -- O   [O, P, I]
  eLet (eAt1 (eV 2)) <|                                         -- c   [c, O, P, I]
  eLet (eAt2 (eV 3)) <|                                         -- μ   [μ, c, O, P, I]
  eLet (eSub (eMul (eMul (eMul (eCall Idx.pL (eV 3)) (eHd (eV 1))) (eHd (eV 0))) (eV 2))
      (eMul (eAt1 (eV 1)) (eAt1 (eV 0)))) <|                    -- nu  [nu, μ, c, O, P, I]
  eCall Idx.normQ (ePair (eIte (eLt (eV 0) (eLit 0)) (eLit 0) (eV 0))
    (eMul (eMul (eAt1 (eV 2)) (eAt1 (eV 1))) (eV 3)))

/-- 756: `ValidateInterval` on `[encP, encBank B, encQ S, encQ θ]`. -/
def body_validate : Expr :=
  eLet (eHd (eV 0)) <|                                          -- P    [P, I]
  eLet (ePow2 (eCall Idx.peOmega (eV 0))) <|                    -- O    [O, P, I]
  eLet (eAt2 (eV 2)) <|                                         -- Sq   [Sq, O, P, I]
  eLet (eAt3 (eV 3)) <|                                         -- θq   [θq, Sq, O, P, I]
  eLet (eCall Idx.bkQExtra (eList [eV 3, eCall Idx.bkZExtra (ePair (eV 3) (eLit 0)),
      eAdd (eMul (eHd (eV 1)) (eV 2)) (eAt1 (eV 1)), eMul (eAt1 (eV 1)) (eV 2)])) <|
                                                                -- qx   [qx, θq, Sq, O, P, I]
  eLet (eCall Idx.bkValsQ (ePair (eHd (eAt1 (eV 5))) (eV 0))) <|  -- vals [vals, qx, θq, Sq, O, P, I]
  eLet (eCall Idx.pL (eV 5)) <|                                 -- L    [L, vals, qx, θq, Sq, O, P, I]
  eLet (eCall Idx.normQ (ePair (eSub (eAt1 (eV 3)) (eHd (eV 3))) (eMul (eAt1 (eV 3)) (eV 0)))) <|
                                                                -- l    [l, L, vals, qx, θq, …]
  eLet (eCall Idx.normQ (ePair (eAdd (eAt1 (eV 4)) (eHd (eV 4))) (eMul (eAt1 (eV 4)) (eV 1)))) <|
                                                                -- u    [u, l, L, vals, qx, θq, Sq, O, P, I]
  eLet (eCall Idx.adaInterval (eList [eCall Idx.adaPub (eV 8), eAt2 (eAt1 (eV 9)), eV 3, eV 1,
      eV 0])) <|                                                -- res  [res, u, …, P, I]
  ePair (eHd (eV 0)) (eList [eHd (eAt1 (eV 10)), eAt1 (eAt1 (eV 10)), eAt1 (eV 0)])

/-- 757: `ReleaseNumerical` on `[encP, encBank B, encMode mode]`. -/
def body_release : Expr :=
  eLet (eAt1 (eV 0)) <|                                         -- B    [B, I]
  eIte (Expr.un UnOp.isNil (eAt1 (eV 0)))
    (ePair Expr.nil (eV 0)) <|
  eLet (eHd (eV 1)) <|                                          -- P    [P, B, I]
  eLet (eCall Idx.bkZExtra (ePair (eV 0) (eAt2 (eV 2)))) <|     -- zx   [zx, P, B, I]
  eLet (eCall Idx.bkCoarseScale (eList [eV 1, eV 0, eHd (eAt1 (eV 2))])) <|  -- c  [c, zx, P, B, I]
  eLet (eCall Idx.bkValsQ (ePair (eHd (eV 3))
      (eCall Idx.bkQExtra (eList [eV 2, eV 1, eHd (eV 0), eAt1 (eV 0)])))) <|
                                                                -- vals [vals, c, zx, P, B, I]
  eLet (eCall Idx.adaNumerical (eList [eCall Idx.adaPub (eV 3), eAt2 (eV 4), eV 0])) <|
                                                                -- res  [res, vals, c, zx, P, B, I]
  eLet (eList [eHd (eV 5), eTl (eAt1 (eV 5)), eAt1 (eV 0)]) <|  -- B'   [B', res, vals, …]
  eIte (Expr.un UnOp.isNil (eHd (eV 1)))
    (ePair Expr.nil (eV 0))
    (ePair (eList [eCall Idx.bkReleaseN (eList [eV 5, eV 3, eHd (eHd (eV 1))])]) (eV 0))

/-! ## The library predicate -/

/-- A program containing the W5 routines and the library routines they call. (The external routines,
W1's parameters and W4's ADA routines, come with their bodies from the contracts `W1Contract` /
`W4Contract`; W2's `rowSign` from `HashDSL.HornerLib`.) -/
structure BankLib (prog : List Expr) : Prop where
  -- entries
  resetYBank : prog[Idx.resetYBank]? = some body_resetYBank
  addPhysBank : prog[Idx.addPhysBank]? = some body_addPhysBank
  addGuardYBank : prog[Idx.addGuardYBank]? = some body_addGuardYBank
  addGuardXYBank : prog[Idx.addGuardXYBank]? = some body_addGuardXYBank
  scaleYBank : prog[Idx.scaleYBank]? = some body_scaleYBank
  scaleXYBank : prog[Idx.scaleXYBank]? = some body_scaleXYBank
  validate : prog[Idx.validate]? = some body_validate
  release : prog[Idx.release]? = some body_release
  roundMantQ : prog[Idx.roundMantQ]? = some body_roundMantQ
  guardMant : prog[Idx.guardMant]? = some body_guardMant
  stepCoeffMant : prog[Idx.stepCoeffMant]? = some body_stepCoeffMant
  rescaleLearner : prog[Idx.rescaleLearner]? = some body_rescaleLearner
  countCorrection : prog[Idx.countCorrection]? = some body_countCorrection
  inRangeA : prog[Idx.inRangeA]? = some body_inRangeA
  inRangeC : prog[Idx.inRangeC]? = some body_inRangeC
  learnerInRange : prog[Idx.learnerInRange]? = some body_learnerInRange
  normQ : prog[Idx.normQ]? = some body_normQ
  -- internal helpers
  bkGcdStep : prog[Idx.bkGcdStep]? = some body_bkGcdStep
  bkSat : prog[Idx.bkSat]? = some body_bkSat
  bkRDiv : prog[Idx.bkRDiv]? = some body_bkRDiv
  bkRowOp : prog[Idx.bkRowOp]? = some body_bkRowOp
  bkRowOpStep : prog[Idx.bkRowOpStep]? = some (body_mapBStep Idx.bkRowOp)
  bkBlockOp : prog[Idx.bkBlockOp]? = some (body_mapB Idx.bkRowOpStep)
  bkBlockOpStep : prog[Idx.bkBlockOpStep]? = some (body_mapBStep Idx.bkBlockOp)
  bkBlocksOp : prog[Idx.bkBlocksOp]? = some (body_mapB Idx.bkBlockOpStep)
  bkBlocksOpStep : prog[Idx.bkBlocksOpStep]? = some (body_mapBStep Idx.bkBlocksOp)
  bkGroupsOp : prog[Idx.bkGroupsOp]? = some (body_mapB Idx.bkBlocksOpStep)
  bkBankMap : prog[Idx.bkBankMap]? = some body_bkBankMap
  bkZN : prog[Idx.bkZN]? = some body_bkZN
  bkRowQ : prog[Idx.bkRowQ]? = some body_bkRowQ
  bkRowQStep : prog[Idx.bkRowQStep]? = some (body_mapBStep Idx.bkRowQ)
  bkBlockQ : prog[Idx.bkBlockQ]? = some (body_mapB Idx.bkRowQStep)
  bkBlockQStep : prog[Idx.bkBlockQStep]? = some (body_mapBStep Idx.bkBlockQ)
  bkValsQ : prog[Idx.bkValsQ]? = some (body_mapB Idx.bkBlockQStep)
  bkRowSq : prog[Idx.bkRowSq]? = some body_bkRowSq
  bkRowSqStep : prog[Idx.bkRowSqStep]? = some (body_mapBStep Idx.bkRowSq)
  bkSubSum : prog[Idx.bkSubSum]? = some body_bkSubSum
  bkSubSumStep : prog[Idx.bkSubSumStep]? = some (body_mapBStep Idx.bkSubSum)
  bkGroupSums : prog[Idx.bkGroupSums]? = some (body_mapB Idx.bkSubSumStep)
  bkZExtra : prog[Idx.bkZExtra]? = some body_bkZExtra
  bkLowerMedian : prog[Idx.bkLowerMedian]? = some body_bkLowerMedian
  bkCoarseScale : prog[Idx.bkCoarseScale]? = some body_bkCoarseScale
  bkQExtra : prog[Idx.bkQExtra]? = some body_bkQExtra
  bkReleaseN : prog[Idx.bkReleaseN]? = some body_bkReleaseN
  -- DSL-CALC library routines
  pow2 : prog[Cost.Idx.pow2]? = some Cost.body_pow2
  pow2Step : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step
  natSqrt : prog[Cost.Idx.natSqrt]? = some body_natSqrt
  natSqrtStep : prog[Cost.Idx.natSqrtStep]? = some body_natSqrtStep
  floorSqrtND : prog[Cost.Idx.floorSqrtND]? = some body_floorSqrtND
  ceilSqrtND : prog[Cost.Idx.ceilSqrtND]? = some body_ceilSqrtND
  clampZ : prog[Cost.Idx.clampZ]? = some body_clampZ
  reverse : prog[Cost.Idx.reverse]? = some body_reverse
  revAppendStep : prog[Cost.Idx.revAppendStep]? = some body_revAppendStep
  sum : prog[Cost.Idx.sum]? = some body_sum
  sumStep : prog[Cost.Idx.sumStep]? = some body_sumStep
  get : prog[Cost.Idx.get]? = some body_get
  getStep : prog[Cost.Idx.getStep]? = some body_getStep
  length : prog[Cost.Idx.length]? = some body_length
  lengthStep : prog[Cost.Idx.lengthStep]? = some body_lengthStep
  isortZ : prog[Cost.Idx.isortZ]? = some body_isortZ
  isortZStep : prog[Cost.Idx.isortZStep]? = some body_isortZStep
  insertZ : prog[Cost.Idx.insertZ]? = some body_insertZ
  insertZStep : prog[Cost.Idx.insertZStep]? = some body_insertZStep

end BankDSL

end F2e2e.C.Impl
