import F2e2e.C.Impl.AdaMusDefs

/-!
# ADA module (W4): small facts for the contract assembly

Owner: A-ARCH (a99d156c), for W4 (cc77ceaa). Statements fixed by W4:
* `bankAda_blockSizes_pos`: the block sizes `n_j = adaNBlock … j` (`F2e2e/B/ArchParams.lean` L107–114) of
  the bank instance are positive (`n_j ≥ 2^12 χ hInv² > 0`, `χ ≥ 49`, `hInv = 512 p 2^{eA}`, `p ≥ 2`);
* `QOK.bits`: a boundary rational (`QOK`, `W6Contracts.lean`) has numerator and denominator of at most
  `4 · regBits P + 1` bits (`bitLen_le_of_abs_lt`);
* `Mv_adaRep_q`: `Mv adaRep P ≤ M` gives `2^28 (4 · regBits P + 1) ≤ M` (`stateSizeBound P b ≥ 2^5 ℒ³ + 1`,
  since `H ≥ 1`, and `regBits P = 2^7 ℒ³`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top

/-- The block sizes of the bank instance are positive. -/
theorem bankAda_blockSizes_pos (P : F2e2e.StreamParams) :
    ∀ j, j ≤ (C.Alg.bankAda P).p → 0 < (C.Alg.bankAda P).blockSizes.getD j 0 := by
  intro j hj
  have hj' : j < adaP P.eBankA + 1 := Nat.lt_succ_of_le hj
  have hbs : (C.Alg.bankAda P).blockSizes =
      (List.range (adaP P.eBankA + 1)).map (adaNBlock P.bankM P.bankJ P.bankR P.eBankA P.eBankXi) :=
    rfl
  rw [hbs, List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj']
  show 0 < adaNBlock P.bankM P.bankJ P.bankR P.eBankA P.eBankXi j
  have hp2 : 2 ≤ adaP P.eBankA := (Nat.find_spec (exists_adaP P.eBankA)).1
  have hchi : 0 < adaChi P.bankM P.bankJ P.bankR P.eBankA P.eBankXi := by
    unfold adaChi
    omega
  have hh : 0 < adaHInv P.eBankA := by
    unfold adaHInv
    exact Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (pow_pos (by norm_num) _)
  unfold adaNBlock
  exact lt_of_lt_of_le (Nat.mul_pos (Nat.mul_pos (by norm_num) hchi) (pow_pos hh 2))
    (Nat.le_add_left _ _)

/-- Boundary rationals have at most `4·regBits P` bits. -/
theorem QOK.bits {P : F2e2e.StreamParams} {x : ℚ} (h : QOK P x) :
    bitLen x.num ≤ 4 * regBits P + 1 ∧ bitLen (x.den : ℤ) ≤ 4 * regBits P + 1 := by
  obtain ⟨h1, h2⟩ := h
  have hlt : (2 : ℤ) ^ (4 * regBits P) < 2 ^ (4 * regBits P + 1) :=
    pow_lt_pow_right₀ (by norm_num) (Nat.lt_succ_self _)
  constructor
  · exact bitLen_le_of_abs_lt (lt_of_le_of_lt h1 hlt)
  · refine bitLen_le_of_abs_lt (lt_of_le_of_lt ?_ hlt)
    rw [abs_of_nonneg (Nat.cast_nonneg _)]
    exact h2

/-- What `Mv adaRep P ≤ M` gives the entry routines. -/
theorem Mv_adaRep_q {P : F2e2e.StreamParams} {M : ℕ} (h : Mv adaRep P ≤ M) :
    2 ^ 28 * (4 * regBits P + 1) ≤ M := by
  have hH : 1 ≤ P.H := by unfold StreamParams.H; omega
  have hs : 2 ^ 5 * P.calL ^ 3 + 1 ≤ stateSizeBound P (adaRep.bound P) := by
    have h1 : 1 ≤ P.H * (bankSizeBound P (adaRep.bound P) + 1) :=
      Nat.mul_pos (by omega) (Nat.succ_pos _)
    unfold stateSizeBound
    omega
  unfold Mv at h
  unfold regBits
  have e1 : 2 ^ 28 * (4 * (2 ^ 7 * P.calL ^ 3) + 1) = 2 ^ 37 * P.calL ^ 3 + 2 ^ 28 := by ring
  have e2 : 2 ^ 32 * (2 ^ 5 * P.calL ^ 3 + 1) = 2 ^ 37 * P.calL ^ 3 + 2 ^ 32 := by ring
  have h3 : 2 ^ 32 * (2 ^ 5 * P.calL ^ 3 + 1) ≤ 2 ^ 32 * stateSizeBound P (adaRep.bound P) :=
    Nat.mul_le_mul_left _ hs
  rw [e1]
  rw [e2] at h3
  omega

end F2e2e.C.Impl
