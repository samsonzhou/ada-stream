import F2e2e.C.Impl.AdaBounds

/-!
# ADA module (W4), part 4: `adaInit` (Idx 601)

Reference: `adaInit A = (adaInitD A).toBits (adaDraw A)` (`F2e2e/B/ArchCore.lean` L331–346): `p`
internal thresholds (kind `intThr`), one outer threshold (kind `outThr`), then the initial state
`adaInitState A thr ko` (zero scores of the block sizes `n_0, …, n_{p-1}`, no corrections).

DSL (`body_adaInit`, input the parameter record `adaPubEnc A`):
* the thresholds by W4's `mapB` instance 615/616 with element routine 617 (one draw of kind `intThr`)
  over the list `replicate p 0` (`replicateB_eq_mapB`);
* the outer threshold by `eDraw outThr`;
* the zero scores by the `mapB` instance 618/619 with element routine 620 (library `replicate`) over
  `take p blockSizes`; the corrections by `replicate p 0`.

Spec: `adaInit_impl : Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A)`.
Also: `adaInitState_ok` (the initial state satisfies `AdaOK`), `adaInit_ok` (on every path).
-/

namespace F2e2e.Cost.Idx

/-- `adaThrMap : [replicate p 0, pub] ↦ p fresh thresholds of kind `intThr``. -/
abbrev adaThrMap : ℕ := 615
abbrev adaThrMapStep : ℕ := 616
/-- `adaThrEl : [x, pub] ↦ one fresh noise of kind `intThr``. -/
abbrev adaThrEl : ℕ := 617
/-- `adaRepMap : [take p blockSizes, 0] ↦ the zero score lists`. -/
abbrev adaRepMap : ℕ := 618
abbrev adaRepMapStep : ℕ := 619
/-- `adaRepEl : [n, 0] ↦ replicate n 0`. -/
abbrev adaRepEl : ℕ := 620

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## Reference facts -/

theorem toBits_drawNoise (s : NoiseKind → BitProg ℤ) (κ : NoiseKind) :
    (drawNoise κ).toBits s = s κ :=
  BitProg.bind_pure_right (s κ)

theorem toBits_drawList (s : NoiseKind → BitProg ℤ) (κ : NoiseKind) :
    ∀ n, (drawList κ n).toBits s = replicateB (s κ) n
  | 0 => rfl
  | n + 1 => by
    show ((drawNoise κ).bind fun z => (drawList κ n).map (z :: ·)).toBits s = _
    rw [DrawProg.toBits_bind, toBits_drawNoise]
    show _ = (s κ).bind (fun a => (replicateB (s κ) n).bind (fun l => BitProg.pure (a :: l)))
    congr 1
    funext z
    rw [DrawProg.toBits_map, toBits_drawList s κ n]
    rfl

theorem adaInit_eq (A : AdaParams) : adaInit A =
    (replicateB (adaDraw A NoiseKind.intThr) A.p).bind fun thr =>
      (adaDraw A NoiseKind.outThr).bind fun ko => BitProg.pure (adaInitState A thr ko) := by
  unfold adaInit adaInitD
  rw [DrawProg.toBits_bind, toBits_drawList]
  congr 1

theorem replicateB_run_support {β : Type} {p : BitProg β} {Q : β → Prop}
    (hp : ∀ bits b, p.run bits = some (b, []) → Q b) :
    ∀ n bits l, (replicateB p n).run bits = some (l, []) → l.length = n ∧ ∀ b ∈ l, Q b
  | 0, bits, l, h => by
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    simp
  | n + 1, bits, l, h => by
    simp only [replicateB] at h
    obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    obtain ⟨b₂₁, b₂₂, l', rfl, h21, h22⟩ := bitProg_run_bind_exact.mp h2
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h22
    obtain ⟨hlen, hall⟩ := replicateB_run_support hp n b₂₁ l' h21
    refine ⟨by simp [hlen], ?_⟩
    intro b hb
    rcases List.mem_cons.mp hb with rfl | hb
    · exact hp _ _ h1
    · exact hall b hb

theorem mapB_pure {α β : Type} (g : α → β) :
    ∀ l : List α, mapB (fun x => BitProg.pure (g x)) l = BitProg.pure (l.map g)
  | [] => rfl
  | x :: xs => by
    rw [mapB, mapB_pure g xs]
    rfl

theorem bitLen_le_size_of_abs_le {z : ℤ} {K : ℕ} (h : |z| ≤ (K : ℤ)) : bitLen z ≤ Nat.size K := by
  unfold bitLen
  apply Nat.size_le_size
  have : (z.natAbs : ℤ) ≤ (K : ℤ) := by rw [Int.natCast_natAbs]; exact h
  exact_mod_cast this

/-- The block sizes and caps of the bank ADA instance have `p + 1` and `p` entries. -/
theorem bankAda_blockSizes_length (P : F2e2e.StreamParams) :
    (bankAda P).blockSizes.length = (bankAda P).p + 1 := by
  simp [bankAda, adaParams, adaBlockSizes]

theorem bankAda_Tmax_length (P : F2e2e.StreamParams) : (bankAda P).Tmax.length = (bankAda P).p := by
  simp [bankAda, adaParams, adaTmaxList]

/-- **The initial state satisfies the invariant.** -/
theorem adaInitState_ok {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) {thr : List ℤ}
    {ko : ℤ} (hthr : thr.length = A.p) (hthrK : ∀ z ∈ thr, |z| ≤ (maxKs A : ℤ))
    (hko : |ko| ≤ (maxKs A : ℤ)) : AdaOK A (adaInitState A thr ko) where
  scores_len := by simp [adaInitState, hbs]
  scores_blk := by
    intro j hj
    have hj' : j < A.blockSizes.length := by omega
    simp only [adaInitState]
    rw [List.getD_eq_getElem _ _ (by simp; omega), List.getD_eq_getElem _ _ hj']
    simp [List.getElem_take]
  weights := by simp [adaInitState, List.map_map, Function.comp_def]
  T_len := by simp [adaInitState]
  T_le := by
    intro j hj
    simp only [adaInitState]
    rw [List.getD_eq_getElem _ _ (by simp; omega)]
    simp
  thr_len := hthr
  thr_le := hthrK
  thrOut_le := hko
  scores_le := by
    intro g hg z hz
    simp only [adaInitState, List.mem_map] at hg
    obtain ⟨n, -, rfl⟩ := hg
    rw [(List.mem_replicate.mp hz).2]
    simp [adaInitState]
  rej_le := by simp [adaInitState]
  rej_halt := by simp [adaInitState]
  nInt_le := by simp [adaInitState]
  nNum_le := by simp [adaInitState]

/-! ## The DSL routines -/

/-- `[x, pub] ↦ one fresh noise of kind `intThr``. -/
def body_adaThrEl : Expr := eDraw NoiseKind.intThr (eAtN 1 (eV 0))

/-- `[n, 0] ↦ replicate n 0`. -/
def body_adaRepEl : Expr := eCall Idx.replicate (eV 0)

/-- **`adaInit`**: environment `[pub]`. -/
def body_adaInit : Expr :=
  eLet (eCall Idx.adaThrMap (ePair (eCall Idx.replicate (ePair (eAtN 0 (eV 0)) (eLit 0))) (eV 0)))
  (eLet (eDraw NoiseKind.outThr (eV 1))
  (eLet (eCall Idx.adaRepMap
      (ePair (eCall Idx.take (ePair (eAtN 1 (eV 2)) (eAtN 0 (eV 2)))) (eLit 0)))
  (eLet (eCall Idx.replicate (ePair (eAtN 0 (eV 3)) (eLit 0)))
  (eList [eV 1, eV 0, eV 3, eV 2, eLit 0, eLit 0, eLit 0, eLit 0, eLit 0]))))

/-- The routines of `adaInit` (indices 615–620). -/
structure InitLib (prog : List Expr) : Prop where
  thrMap : prog[Idx.adaThrMap]? = some (body_mapB Idx.adaThrMapStep)
  thrMapStep : prog[Idx.adaThrMapStep]? = some (body_mapBStep Idx.adaThrEl)
  thrEl : prog[Idx.adaThrEl]? = some body_adaThrEl
  repMap : prog[Idx.adaRepMap]? = some (body_mapB Idx.adaRepMapStep)
  repMapStep : prog[Idx.adaRepMapStep]? = some (body_mapBStep Idx.adaRepEl)
  repEl : prog[Idx.adaRepEl]? = some body_adaRepEl

section Proof

variable {prog : List Expr} {M : ℕ}

/-- A field of the parameter record in the environment. -/
theorem pub_field {env : List Val} {k n : ℕ} {A : AdaParams} {v : Val}
    (henv : env[k]? = some (adaPubEnc A)) (hM : valSize (adaPubEnc A) ≤ M)
    (hget : (pubFields A)[n]? = some v) : EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
  evalsVal_atN' (l := pubFields A) (EvalsVal.var henv) hM hget

theorem valSize_replicate_int0 (n : ℕ) :
    valSize (Val.list (List.replicate n (Val.int 0))) = 1 + 2 * n := by
  rw [valSize_list, listSize_replicate, valSize_int, bitLen_zero]
  ring

theorem replicate_int0_eq (n : ℕ) :
    Val.list (List.replicate n (Val.int 0)) = encL encZ (List.replicate n 0) := by
  simp [encL, encZ, List.map_replicate]

theorem replicate_int0_eq_N (n : ℕ) :
    Val.list (List.replicate n (Val.int 0)) = encL encN (List.replicate n 0) := by
  simp [encL, encN, List.map_replicate]

/-- **Spec of `adaInit`.** -/
theorem adaInit_impl (hS : SampLib prog) (hL : ListLib prog) (hI : InitLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A) := by
  rw [adaInit_eq]
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hZ16 := sixteen_le_adaZ A
  have hpZ := p_le_adaZ A
  have hB1 : (A.N + A.p + 16) * (adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA; nlinarith
  have hBN : A.N + A.p + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_right _ (by omega)
  have hBZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hBpN : A.p * A.N ≤ (A.N + A.p + 16) * (adaZ A + 16) := by
    rw [mul_comm]; exact Nat.mul_le_mul (by omega) (by omega)
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : ∀ κ, drawM A κ ≤ M := fun κ => by have := drawM_le A κ; omega
  have hKs : ∀ κ bits (z : ℤ), (adaDraw A κ).run bits = some (z, []) → |z| ≤ (maxKs A : ℤ) :=
    fun κ bits z h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ)
  have hsK := size_maxKs_le_adaZ A
  -- the thresholds
  have hthr : Implements prog M [adaPubEnc A]
      (eCall Idx.adaThrMap (ePair (eCall Idx.replicate (ePair (eAtN 0 (eV 0)) (eLit 0))) (eV 0)))
      (encL encZ) (replicateB (adaDraw A NoiseKind.intThr) A.p) := by
    rw [replicateB_eq_mapB _ (0 : ℤ)]
    have hrepV := valSize_replicate_int0 A.p
    refine implements_call_det hI.thrMap ?_ (mapB_impl hI.thrMapStep hI.thrEl hL.reverse
      hL.revAppendStep encZ encZ (adaPubEnc A) (fun _ => adaDraw A NoiseKind.intThr)
      (List.replicate A.p 0) (Nat.size (maxKs A) + 1) ?_ ?_ ?_)
    · have hp0 : EvalsVal prog M [adaPubEnc A] [] (.inl (eAtN 0 (eV 0))) (encN A.p) :=
        pub_field rfl hpubM rfl
      have hpair := EvalsVal.pair hp0 (EvalsVal.lit (z := 0) (by simp; omega))
        (by simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
              bitLen_zero, bitLen_natCast]
            have := size_le_self A.p; omega)
      have hSr : S_replicate A.p (Val.int 0) ≤ M := by
        unfold S_replicate
        simp only [valSize_int, bitLen_zero]
        have := size_le_self A.p
        omega
      have hrep := replicate_val hL hpair hSr
      rw [replicate_int0_eq] at hrep
      have := EvalsVal.pair hrep EvalsVal.var0 (by
        rw [← replicate_int0_eq]; simp only [valSize_list, listSize_cons, listSize_nil] at *
        omega)
      simpa using this
    · intro x _
      exact draw_impl hS (evalsVal_atN' (l := [encZ x, adaPubEnc A]) EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil] at *
            have : valSize (encZ x) ≤ 1 := by
              rw [List.mem_replicate] at *; simp_all [encZ]
            omega) rfl) hpubM NoiseKind.intThr (hdraw _)
    · intro x _ bits b hb
      rw [valSize_encZ]
      have := bitLen_le_size_of_abs_le (hKs _ bits b hb)
      omega
    · unfold mapB_M
      rw [← replicate_int0_eq, hrepV]
      have : A.p * (Nat.size (maxKs A) + 1 + 1) ≤ A.p * (adaZ A + 2) :=
        Nat.mul_le_mul_left _ (by omega)
      have : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
        Nat.mul_le_mul (by omega) (by omega)
      simp only [List.length_replicate]
      omega
  refine implements_letE_of hthr (fun thr => thr.length = A.p ∧ ∀ z ∈ thr, |z| ≤ (maxKs A : ℤ))
    (fun bits thr h => replicateB_run_support (hKs NoiseKind.intThr) A.p bits thr h) ?_
  rintro thr ⟨hthrl, hthrK⟩
  refine implements_letE_of (draw_impl hS (EvalsVal.var1) hpubM NoiseKind.outThr (hdraw _))
    (fun ko => |ko| ≤ (maxKs A : ℤ)) (fun bits ko h => hKs _ bits ko h) ?_
  intro ko hko
  apply Implements.of_det
  -- the final state and its size
  have hok := adaInitState_ok hbs hthrl hthrK hko
  have hstB := valSize_adaEnc_le hok
  have hstM : valSize (adaEnc (adaInitState A thr ko)) ≤ M := by omega
  set env : List Val := [encZ ko, encL encZ thr, adaPubEnc A] with henv
  have hstL : adaEnc (adaInitState A thr ko) = Val.list
      [encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0),
        encL encN (List.replicate A.p 0), encL encZ thr, encZ ko, Val.int 0, Val.int 0,
        Val.int 0, Val.int 0, Val.int 0] := by
    simp [adaEnc, adaInitState, encN, encB]
  have hsub : ∀ v ∈ [encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0),
      encL encN (List.replicate A.p 0), encL encZ thr, encZ ko, Val.int 0, Val.int 0,
      Val.int 0, Val.int 0, Val.int 0], valSize v ≤ valSize (adaEnc (adaInitState A thr ko)) := by
    intro v hv
    rw [hstL]
    exact (valSize_lt_of_mem hv).le
  have hscB : valSize (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
      List.replicate nj 0)) ≤ valSize (adaEnc (adaInitState A thr ko)) :=
    hsub _ List.mem_cons_self
  have hTB : valSize (encL encN (List.replicate A.p 0)) ≤ valSize (adaEnc (adaInitState A thr ko)) :=
    hsub _ (List.mem_cons_of_mem _ List.mem_cons_self)
  -- the zero scores
  have hbsT : valSize (encL encN (A.blockSizes.take A.p)) ≤ valSize (encL encN A.blockSizes) := by
    simp only [valSize_encL]
    have : ((A.blockSizes.take A.p).map fun a => valSize (encN a) + 1).sum ≤
        (A.blockSizes.map fun a => valSize (encN a) + 1).sum := by
      rw [List.map_take]
      exact List.Sublist.sum_le_sum (List.take_sublist _ _) (fun _ _ => Nat.zero_le _)
    omega
  have hbsP : valSize (encL encN A.blockSizes) ≤ valSize (adaPubEnc A) := by
    rw [adaPubEnc_eq]
    exact (valSize_lt_of_mem (by simp [pubFields])).le
  have hsc : EvalsVal prog M env [] (.inl (eCall Idx.adaRepMap
      (ePair (eCall Idx.take (ePair (eAtN 1 (eV 2)) (eAtN 0 (eV 2)))) (eLit 0))))
      (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0)) := by
    have hrm := mapB_impl hI.repMapStep hI.repEl hL.reverse hL.revAppendStep encN (encL encZ)
      (Val.int 0) (fun n => BitProg.pure (List.replicate n (0 : ℤ))) (A.blockSizes.take A.p)
      (1 + 3 * A.N)
      (fun n hn => Implements.of_det (by
        have := replicate_val (M := M) hL (n := n) (x := Val.int 0) (EvalsVal.var0 (rest := []))
          (by unfold S_replicate
              have hn' : n ≤ A.N := List.le_sum_of_mem (List.mem_of_mem_take hn)
              have := size_le_self n
              simp only [valSize_int, bitLen_zero]
              have : 5 * (n * (0 + 1 + 1)) ≤ 10 * A.N := by omega
              omega)
        rw [replicate_int0_eq] at this
        exact this))
      (fun n hn bits b hb => by
        obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hb
        rw [← replicate_int0_eq, valSize_replicate_int0]
        have : n ≤ A.N := List.le_sum_of_mem (List.mem_of_mem_take hn)
        omega)
      (by unfold mapB_M
          have hl : (A.blockSizes.take A.p).length ≤ A.p := List.length_take_le _ _
          have h2 : (A.blockSizes.take A.p).length * (1 + 3 * A.N + 1) ≤
              3 * (A.p * A.N) + 2 * A.p :=
            calc _ ≤ A.p * (1 + 3 * A.N + 1) := Nat.mul_le_mul_right _ hl
              _ = 3 * (A.p * A.N) + 2 * A.p := by ring
          simp only [valSize_int, bitLen_zero]
          omega)
    rw [mapB_pure] at hrm
    refine evalsVal_call_det hI.repMap ?_ (hrm [] _ rfl)
    have hbsE : EvalsVal prog M env [] (.inl (eAtN 1 (eV 2))) (encL encN A.blockSizes) :=
      pub_field rfl hpubM rfl
    have hpE : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (encN A.p) :=
      pub_field rfl hpubM rfl
    have hpair := EvalsVal.pair hbsE hpE (by
      simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
      have := size_le_self A.p; omega)
    have hbsTM : valSize (encL encN (A.blockSizes.take A.p)) + 10 ≤ M := by omega
    have htake := take_val hL (l := A.blockSizes.map encN) hpair (by
      unfold S_take
      have h1 : valSize (Val.list (A.blockSizes.map encN)) ≤ valSize (adaPubEnc A) := hbsP
      have := size_le_self A.p
      omega)
    rw [← List.map_take] at htake
    have := EvalsVal.pair htake (EvalsVal.lit (z := 0) (by simp; omega)) (by
      show valSize (Val.list [encL encN (A.blockSizes.take A.p), Val.int 0]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]
      omega)
    simpa [encL] using this
  -- the corrections
  have hTE : EvalsVal prog M (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
      List.replicate nj 0) :: env) [] (.inl (eCall Idx.replicate (ePair (eAtN 0 (eV 3)) (eLit 0))))
      (encL encN (List.replicate A.p 0)) := by
    have hpE : EvalsVal prog M (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
        List.replicate nj 0) :: env) [] (.inl (eAtN 0 (eV 3))) (encN A.p) :=
      pub_field rfl hpubM rfl
    have hpair := EvalsVal.pair hpE (EvalsVal.lit (z := 0) (by simp; omega)) (by
      simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero,
        bitLen_natCast]
      have := size_le_self A.p; omega)
    have := replicate_val hL hpair (by
      unfold S_replicate; simp only [valSize_int, bitLen_zero]; have := size_le_self A.p; omega)
    rwa [replicate_int0_eq_N] at this
  refine EvalsVal.letE hsc (EvalsVal.letE hTE ?_)
  rw [hstL]
  refine evalsVal_list ?_ (by rw [← hstL]; exact hstM)
  refine List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (EvalsVal.var rfl)
    (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (EvalsVal.var rfl) ?_)))
  have hl0 : ∀ {env' : List Val}, EvalsVal prog M env' [] (.inl (eLit 0)) (Val.int 0) :=
    EvalsVal.lit (by simp; omega)
  exact List.Forall₂.cons hl0 (List.Forall₂.cons hl0 (List.Forall₂.cons hl0
    (List.Forall₂.cons hl0 (List.Forall₂.cons hl0 List.Forall₂.nil))))

end Proof

/-! ## The invariant on every path -/

/-- A property of every exact run holds on every path. -/
theorem always_of_run {α : Type} {Q : α → Prop} :
    ∀ {p : BitProg α}, (∀ bits a, p.run bits = some (a, []) → Q a) → Always p Q
  | BitProg.pure a, h => h [] a rfl
  | BitProg.bit k, h => fun b => always_of_run (fun bits a hr => h (b :: bits) a hr)

/-- Every draw is in its support. -/
theorem adaDraw_always (A : AdaParams) (κ : NoiseKind) :
    Always (adaDraw A κ) (fun z => |z| ≤ (maxKs A : ℤ)) :=
  always_of_run (fun _ _ h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ))

/-- **`adaInit` establishes the invariant on every path.** -/
theorem adaInit_ok {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) :
    Always (adaInit A) (AdaOK A) := by
  rw [adaInit_eq]
  refine Always.bind (Q := fun thr => thr.length = A.p ∧ ∀ z ∈ thr, |z| ≤ (maxKs A : ℤ))
    (fun thr hthr => ?_) (always_of_run (fun bits thr h => replicateB_run_support
      (fun bits b hb => (adaDraw_run_abs_le hb).trans (by exact_mod_cast Ks_le_maxKs A _))
      A.p bits thr h))
  exact Always.bind (fun ko hko => always_pure (adaInitState_ok hbs hthr.1 hthr.2 hko))
    (adaDraw_always A NoiseKind.outThr)

/-! ## O2b (iii) family 3: the tight value premise (W4's `adaInit_impl_t`; append-only staging)

`adaInit_impl_t`: `adaInit_impl` with `(hMt : TightM A M)` (`TightM`, `tightA` from `AdaBounds`) for
`(hM : 2 ^ 32 * adaBoundA A ≤ M)`. The `example` checks that the statement of `adaInit_impl` follows via
`TightM.of_old`. Source: `F2e2e/Scratch/O2T/AdaInitT.lean` (W4). -/

section O2bTight

variable {prog : List Expr} {M : ℕ}

/-- **Spec of `adaInit`, tight premise** (O2b family 3). -/
theorem adaInit_impl_t (hS : SampLib prog) (hL : ListLib prog) (hI : InitLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hMt : TightM A M) :
    Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A) := by
  rw [adaInit_eq]
  have hM : 2 ^ 4 * tightA A ≤ M := by unfold TightM at hMt; omega
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hZ16 := sixteen_le_adaZ A
  have hpZ := p_le_adaZ A
  have hB1 : 2 * ((A.N + A.p + 16) * (adaZ A + 16)) = tightA A := by
    unfold tightA; ring
  have hPZ16 : 16 * (adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul_right _ (by omega)
  have hPN32 : (A.N + A.p + 16) * 32 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul_left _ (by omega)
  have hBN : A.N + A.p + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_right _ (by omega)
  have hBZ : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hBpN : A.p * A.N ≤ (A.N + A.p + 16) * (adaZ A + 16) := by
    rw [mul_comm]; exact Nat.mul_le_mul (by omega) (by omega)
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : ∀ κ, drawM A κ ≤ M := fun κ => by have := drawM_le A κ; omega
  have hKs : ∀ κ bits (z : ℤ), (adaDraw A κ).run bits = some (z, []) → |z| ≤ (maxKs A : ℤ) :=
    fun κ bits z h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ)
  have hsK := size_maxKs_le_adaZ A
  -- the thresholds
  have hthr : Implements prog M [adaPubEnc A]
      (eCall Idx.adaThrMap (ePair (eCall Idx.replicate (ePair (eAtN 0 (eV 0)) (eLit 0))) (eV 0)))
      (encL encZ) (replicateB (adaDraw A NoiseKind.intThr) A.p) := by
    rw [replicateB_eq_mapB _ (0 : ℤ)]
    have hrepV := valSize_replicate_int0 A.p
    refine implements_call_det hI.thrMap ?_ (mapB_impl hI.thrMapStep hI.thrEl hL.reverse
      hL.revAppendStep encZ encZ (adaPubEnc A) (fun _ => adaDraw A NoiseKind.intThr)
      (List.replicate A.p 0) (Nat.size (maxKs A) + 1) ?_ ?_ ?_)
    · have hp0 : EvalsVal prog M [adaPubEnc A] [] (.inl (eAtN 0 (eV 0))) (encN A.p) :=
        pub_field rfl hpubM rfl
      have hpair := EvalsVal.pair hp0 (EvalsVal.lit (z := 0) (by simp; omega))
        (by simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int,
              bitLen_zero, bitLen_natCast]
            have := size_le_self A.p; omega)
      have hSr : S_replicate A.p (Val.int 0) ≤ M := by
        unfold S_replicate
        simp only [valSize_int, bitLen_zero]
        have := size_le_self A.p
        omega
      have hrep := replicate_val hL hpair hSr
      rw [replicate_int0_eq] at hrep
      have := EvalsVal.pair hrep EvalsVal.var0 (by
        rw [← replicate_int0_eq]; simp only [valSize_list, listSize_cons, listSize_nil] at *
        omega)
      simpa using this
    · intro x _
      exact draw_impl hS (evalsVal_atN' (l := [encZ x, adaPubEnc A]) EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil] at *
            have : valSize (encZ x) ≤ 1 := by
              rw [List.mem_replicate] at *; simp_all [encZ]
            omega) rfl) hpubM NoiseKind.intThr (hdraw _)
    · intro x _ bits b hb
      rw [valSize_encZ]
      have := bitLen_le_size_of_abs_le (hKs _ bits b hb)
      omega
    · unfold mapB_M
      rw [← replicate_int0_eq, hrepV]
      have : A.p * (Nat.size (maxKs A) + 1 + 1) ≤ A.p * (adaZ A + 2) :=
        Nat.mul_le_mul_left _ (by omega)
      have : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
        Nat.mul_le_mul (by omega) (by omega)
      simp only [List.length_replicate]
      omega
  refine implements_letE_of hthr (fun thr => thr.length = A.p ∧ ∀ z ∈ thr, |z| ≤ (maxKs A : ℤ))
    (fun bits thr h => replicateB_run_support (hKs NoiseKind.intThr) A.p bits thr h) ?_
  rintro thr ⟨hthrl, hthrK⟩
  refine implements_letE_of (draw_impl hS (EvalsVal.var1) hpubM NoiseKind.outThr (hdraw _))
    (fun ko => |ko| ≤ (maxKs A : ℤ)) (fun bits ko h => hKs _ bits ko h) ?_
  intro ko hko
  apply Implements.of_det
  -- the final state and its size
  have hok := adaInitState_ok hbs hthrl hthrK hko
  have hstB := valSize_adaEnc_le_t hok
  have hstM : valSize (adaEnc (adaInitState A thr ko)) ≤ M := by omega
  set env : List Val := [encZ ko, encL encZ thr, adaPubEnc A] with henv
  have hstL : adaEnc (adaInitState A thr ko) = Val.list
      [encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0),
        encL encN (List.replicate A.p 0), encL encZ thr, encZ ko, Val.int 0, Val.int 0,
        Val.int 0, Val.int 0, Val.int 0] := by
    simp [adaEnc, adaInitState, encN, encB]
  have hsub : ∀ v ∈ [encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0),
      encL encN (List.replicate A.p 0), encL encZ thr, encZ ko, Val.int 0, Val.int 0,
      Val.int 0, Val.int 0, Val.int 0], valSize v ≤ valSize (adaEnc (adaInitState A thr ko)) := by
    intro v hv
    rw [hstL]
    exact (valSize_lt_of_mem hv).le
  have hscB : valSize (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
      List.replicate nj 0)) ≤ valSize (adaEnc (adaInitState A thr ko)) :=
    hsub _ List.mem_cons_self
  have hTB : valSize (encL encN (List.replicate A.p 0)) ≤ valSize (adaEnc (adaInitState A thr ko)) :=
    hsub _ (List.mem_cons_of_mem _ List.mem_cons_self)
  -- the zero scores
  have hbsT : valSize (encL encN (A.blockSizes.take A.p)) ≤ valSize (encL encN A.blockSizes) := by
    simp only [valSize_encL]
    have : ((A.blockSizes.take A.p).map fun a => valSize (encN a) + 1).sum ≤
        (A.blockSizes.map fun a => valSize (encN a) + 1).sum := by
      rw [List.map_take]
      exact List.Sublist.sum_le_sum (List.take_sublist _ _) (fun _ _ => Nat.zero_le _)
    omega
  have hbsP : valSize (encL encN A.blockSizes) ≤ valSize (adaPubEnc A) := by
    rw [adaPubEnc_eq]
    exact (valSize_lt_of_mem (by simp [pubFields])).le
  have hsc : EvalsVal prog M env [] (.inl (eCall Idx.adaRepMap
      (ePair (eCall Idx.take (ePair (eAtN 1 (eV 2)) (eAtN 0 (eV 2)))) (eLit 0))))
      (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj => List.replicate nj 0)) := by
    have hrm := mapB_impl hI.repMapStep hI.repEl hL.reverse hL.revAppendStep encN (encL encZ)
      (Val.int 0) (fun n => BitProg.pure (List.replicate n (0 : ℤ))) (A.blockSizes.take A.p)
      (1 + 3 * A.N)
      (fun n hn => Implements.of_det (by
        have := replicate_val (M := M) hL (n := n) (x := Val.int 0) (EvalsVal.var0 (rest := []))
          (by unfold S_replicate
              have hn' : n ≤ A.N := List.le_sum_of_mem (List.mem_of_mem_take hn)
              have := size_le_self n
              simp only [valSize_int, bitLen_zero]
              have : 5 * (n * (0 + 1 + 1)) ≤ 10 * A.N := by omega
              omega)
        rw [replicate_int0_eq] at this
        exact this))
      (fun n hn bits b hb => by
        obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hb
        rw [← replicate_int0_eq, valSize_replicate_int0]
        have : n ≤ A.N := List.le_sum_of_mem (List.mem_of_mem_take hn)
        omega)
      (by unfold mapB_M
          have hl : (A.blockSizes.take A.p).length ≤ A.p := List.length_take_le _ _
          have h2 : (A.blockSizes.take A.p).length * (1 + 3 * A.N + 1) ≤
              3 * (A.p * A.N) + 2 * A.p :=
            calc _ ≤ A.p * (1 + 3 * A.N + 1) := Nat.mul_le_mul_right _ hl
              _ = 3 * (A.p * A.N) + 2 * A.p := by ring
          simp only [valSize_int, bitLen_zero]
          omega)
    rw [mapB_pure] at hrm
    refine evalsVal_call_det hI.repMap ?_ (hrm [] _ rfl)
    have hbsE : EvalsVal prog M env [] (.inl (eAtN 1 (eV 2))) (encL encN A.blockSizes) :=
      pub_field rfl hpubM rfl
    have hpE : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (encN A.p) :=
      pub_field rfl hpubM rfl
    have hpair := EvalsVal.pair hbsE hpE (by
      simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
      have := size_le_self A.p; omega)
    have hbsTM : valSize (encL encN (A.blockSizes.take A.p)) + 10 ≤ M := by omega
    have htake := take_val hL (l := A.blockSizes.map encN) hpair (by
      unfold S_take
      have h1 : valSize (Val.list (A.blockSizes.map encN)) ≤ valSize (adaPubEnc A) := hbsP
      have := size_le_self A.p
      omega)
    rw [← List.map_take] at htake
    have := EvalsVal.pair htake (EvalsVal.lit (z := 0) (by simp; omega)) (by
      show valSize (Val.list [encL encN (A.blockSizes.take A.p), Val.int 0]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]
      omega)
    simpa [encL] using this
  -- the corrections
  have hTE : EvalsVal prog M (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
      List.replicate nj 0) :: env) [] (.inl (eCall Idx.replicate (ePair (eAtN 0 (eV 3)) (eLit 0))))
      (encL encN (List.replicate A.p 0)) := by
    have hpE : EvalsVal prog M (encL (encL encZ) ((A.blockSizes.take A.p).map fun nj =>
        List.replicate nj 0) :: env) [] (.inl (eAtN 0 (eV 3))) (encN A.p) :=
      pub_field rfl hpubM rfl
    have hpair := EvalsVal.pair hpE (EvalsVal.lit (z := 0) (by simp; omega)) (by
      simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero,
        bitLen_natCast]
      have := size_le_self A.p; omega)
    have := replicate_val hL hpair (by
      unfold S_replicate; simp only [valSize_int, bitLen_zero]; have := size_le_self A.p; omega)
    rwa [replicate_int0_eq_N] at this
  refine EvalsVal.letE hsc (EvalsVal.letE hTE ?_)
  rw [hstL]
  refine evalsVal_list ?_ (by rw [← hstL]; exact hstM)
  refine List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (EvalsVal.var rfl)
    (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (EvalsVal.var rfl) ?_)))
  have hl0 : ∀ {env' : List Val}, EvalsVal prog M env' [] (.inl (eLit 0)) (Val.int 0) :=
    EvalsVal.lit (by simp; omega)
  exact List.Forall₂.cons hl0 (List.Forall₂.cons hl0 (List.Forall₂.cons hl0
    (List.Forall₂.cons hl0 (List.Forall₂.cons hl0 List.Forall₂.nil))))

/-- The old statement as a corollary (shape check for the integration). -/
example (hS : SampLib prog) (hL : ListLib prog) (hI : InitLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A) :=
  adaInit_impl_t hS hL hI hbs hT (TightM.of_old hM)

end O2bTight

end F2e2e.C.Impl
