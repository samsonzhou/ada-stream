import F2e2e.C.Impl.Tree4Glue

/-!
# W6, Tree4: the list routines `setAtV`, `mfXY`, `mfResc`, `allFrom`

* `setAtV_val`: `[encL enc l, [k, enc b]] ↦ encL enc (setAt b k l)` (DSL-CALC's `mapIdx` with the
  element routine `body_setAtVElem`);
* `mfXY_val`: `mapFrom (Bank.mapRows (Row.scaleXY P cInt)) k` on encoded banks (W5's
  `scaleXYBank` on the entries of index `≥ k`);
* `mfResc_val`: `mapFrom (Learner.rescale P cInt) k` on encoded learners (W5's `rescaleLearner`);
* `allFrom_val`: `(learners.drop k).all (Learner.inRange P)` (own loop, W5's `learnerInRange`).
-/

namespace F2e2e.C.Impl.T4

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-! ## List equalities -/

theorem setAt_eq_setAtL {α : Type} (b : α) : ∀ (k : ℕ) (l : List α), setAt b k l = setAtL b k l
  | k, [] => by cases k <;> rfl
  | 0, _ :: _ => rfl
  | k + 1, a :: l => by simp only [setAt, setAtL, setAt_eq_setAtL b k l]

theorem mapFrom_eq_mapFromL {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), mapFrom f k l = mapFromL f k l
  | _, [] => rfl
  | 0, a :: l => by simp only [mapFrom, mapFromL, mapFrom_eq_mapFromL f 0 l]
  | k + 1, a :: l => by simp only [mapFrom, mapFromL, mapFrom_eq_mapFromL f k l]

theorem setAt_eq_mapIdxFrom {α : Type} (b : α) (k : ℕ) (l : List α) :
    setAt b k l = mapIdxFrom (fun i a => if i = k then b else a) 0 l := by
  rw [setAt_eq_setAtL, setAtL_eq]

theorem mapFrom_eq_mapIdxFrom {α : Type} (f : α → α) (k : ℕ) (l : List α) :
    mapFrom f k l = mapIdxFrom (fun i a => if k ≤ i then f a else a) 0 l := by
  rw [mapFrom_eq_mapFromL, mapFromL_eq]

/-! ## Deterministic comparisons -/

section Cmp

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_lt' {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (Val.int (if x < y then 1 else 0)) := by
  have h := EvalsVal.lt ha hb hM
  rwa [List.nil_append] at h

theorem ev_sub' {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x - y)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.sub a b)) (Val.int (x - y)) := by
  have h := EvalsVal.sub ha hb hM
  rwa [List.nil_append] at h

end Cmp

/-! ## The size of a learner within the failure ranges -/

theorem valSize_encLearner_le16 {P : StreamParams} {L : Learner} (h : LearnerOK P 16 L) :
    valSize (encLearner L) ≤ 2 ^ 6 * P.calL ^ 3 := by
  have e1 : ((16 : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) = 2 ^ (P.eCmax + P.eHC + 4) := by
    unfold StreamParams.Cmax; push_cast; ring
  have e2 : ((16 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) = 2 ^ (P.eAmax + P.eHP + 4) := by
    unfold StreamParams.Amax; push_cast; ring
  have t1 : bitLen L.tag ≤ P.eCmax + P.eHC + 5 :=
    SizeAux.bitLen_le_of_nonneg_le h.tag_nonneg (h.tag_le.trans_eq e1)
  have t2 : bitLen L.cache ≤ P.eAmax + P.eHP + 5 :=
    SizeAux.bitLen_le_of_nonneg_le h.cache_nonneg (h.cache_le.trans_eq e2)
  have t3 : bitLen (L.epoch : ℤ) ≤ P.Kepoch := (SizeAux.bitLen_nat_le_self L.epoch).trans h.epoch_le
  have t4 : bitLen (L.jEpoch : ℤ) ≤ 7 + 2 * P.eEta := by
    have hK : P.K0 = 2 ^ (7 + 2 * P.eEta) := rfl
    exact SizeAux.bitLen_nat_le_of_lt (hK ▸ h.jEpoch_lt)
  have t5 : bitLen (L.jUsed : ℤ) ≤ 10 + 2 * P.eEta + 3 * P.calL := by
    apply SizeAux.bitLen_nat_le_of_lt
    have h3 : P.calL ^ 3 < 2 ^ (3 * P.calL) := by
      rw [pow_mul']
      exact Nat.pow_lt_pow_left Nat.lt_two_pow_self (by norm_num)
    calc L.jUsed ≤ P.Jstar := h.jUsed_le
      _ ≤ 2 ^ 10 * 2 ^ (2 * P.eEta) * P.calL ^ 3 := Jstar_le P
      _ < 2 ^ 10 * 2 ^ (2 * P.eEta) * 2 ^ (3 * P.calL) := mul_lt_mul_of_pos_left h3 (by positivity)
      _ = 2 ^ (10 + 2 * P.eEta + 3 * P.calL) := by rw [pow_add, pow_add]
  have a1 := eCmax_le P
  have a2 := eHC_le P
  have a3 := eAmax_le P
  have a4 := eHP_le P
  have a5 := Kepoch_le P
  have a6 := eEta_le P
  have b1 := hundred_mul_sq_le_cube P
  have b2 := SizeAux.hundred_calL_le_cube P
  have b3 := SizeAux.hundred_le_calL_cube P
  have hv := SizeAux.valSize_encInts_le [L.tag, L.cache, (L.epoch : ℤ), (L.jEpoch : ℤ),
    (L.jUsed : ℤ)] (8 * P.calL ^ 3) (by
      intro z hz
      simp only [List.mem_cons, List.mem_nil_iff, or_false] at hz
      rcases hz with rfl | rfl | rfl | rfl | rfl <;> omega)
  have hlen : [L.tag, L.cache, (L.epoch : ℤ), (L.jEpoch : ℤ), (L.jUsed : ℤ)].length = 5 := rfl
  rw [hlen] at hv
  unfold encLearner
  rw [show (2 : ℕ) ^ 6 = 64 by norm_num]
  omega

/-! ## `setAtV` -/

theorem setAtVElem_val {prog : List Expr} {M : ℕ} {α : Type} (enc : α → Val) (i : ℕ) (x y : α)
    (j : ℕ) (hM : valSize (Val.list [Val.int (i : ℤ), enc x, Val.list [encN j, enc y]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), enc x, Val.list [encN j, enc y]]] []
      (.inl body_setAtVElem) (enc (if i = j then y else x)) := by
  have hX : EvalsVal prog M [Val.list [Val.int (i : ℤ), enc x, Val.list [encN j, enc y]]] []
      (.inl (Expr.var 0)) (Val.list [Val.int (i : ℤ), enc x, Val.list [encN j, enc y]]) :=
    EvalsVal.var rfl
  have hE : valSize (Val.list [encN j, enc y]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), enc x, Val.list [encN j, enc y]])
      rfl).trans hM
  have h2 : 2 ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM; omega
  have hi := ev_get 0 hX hM rfl
  have hx := ev_get 1 hX hM rfl
  have hext := ev_get 2 hX hM rfl
  have hj := ev_get 0 hext hE rfl
  have hy := ev_get 1 hext hE rfl
  have heq := ev_eq (x := (i : ℤ)) (y := (j : ℤ)) hi hj h2
  unfold body_setAtVElem
  by_cases hij : i = j
  · subst hij
    rw [if_pos rfl]
    exact ev_ite_true' heq (by simp) hy
  · rw [if_neg hij]
    exact ev_ite_false' heq (by simp [hij]) hx

/-- **`setAtV`**: `[encL enc l, [k, enc b]] ↦ encL enc (setAt b k l)`. -/
theorem setAtV_val {prog : List Expr} {M : ℕ} (hT : Tree4Lib prog) {α : Type} (enc : α → Val)
    (xs : List α) (j : ℕ) (y : α) (VB : ℕ) (hxs : ∀ x ∈ xs, valSize (enc x) ≤ VB)
    (hy : valSize (enc y) ≤ VB) (hM : mapIdx_M enc xs (Val.list [encN j, enc y]) VB ≤ M) :
    EvalsVal prog M [Val.list [encL enc xs, Val.list [encN j, enc y]]] [] (.inl body_setAtV)
      (encL enc (setAt y j xs)) := by
  rw [setAt_eq_mapIdxFrom]
  refine mapIdx_val hT.setAtVStep hT.setAtVElem hT.reverse hT.revAppendStep enc enc
    (Val.list [encN j, enc y]) (fun i a => if i = j then y else a) xs VB
    (fun i x hx hi => setAtVElem_val enc i x y j ?_) (fun i x hx => ?_) hM
  · have h1 := hxs x hx
    have h2 : bitLen (i : ℤ) ≤ Nat.size xs.length := bitLen_le_size_of_le hi.le
    simp only [mapIdx_M] at hM
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hM ⊢
    omega
  · split_ifs
    · exact hy
    · exact hxs x hx

/-- `eSetAt` in any environment. -/
theorem ev_eSetAt {prog : List Expr} {M : ℕ} {env : List Val} (hT : Tree4Lib prog) {α : Type}
    (enc : α → Val) (xs : List α) (j : ℕ) (y : α) (VB : ℕ) (hxs : ∀ x ∈ xs, valSize (enc x) ≤ VB)
    (hy : valSize (enc y) ≤ VB) {l k b : Expr}
    (hl : EvalsVal prog M env [] (.inl l) (encL enc xs))
    (hk : EvalsVal prog M env [] (.inl k) (encN j))
    (hb : EvalsVal prog M env [] (.inl b) (enc y))
    (hM : mapIdx_M enc xs (Val.list [encN j, enc y]) VB ≤ M) :
    EvalsVal prog M env [] (.inl (eSetAt l k b)) (encL enc (setAt y j xs)) := by
  have hL := valSize_encL_ge enc xs
  have hext : valSize (Val.list [encN j, enc y]) ≤ M := by
    simp only [mapIdx_M] at hM; omega
  have hin := ev_list (.cons hk (.cons hb .nil)) hext
  have harg := ev_list (.cons hl (.cons hin .nil)) (by
    simp only [mapIdx_M] at hM
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢
    omega)
  exact evalsVal_call_det hT.setAtV harg (setAtV_val hT enc xs j y VB hxs hy hM)

/-! ## `mfXY` -/

theorem mfXYElem_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) (i : ℕ) {B : Bank}
    (hB : BankOK P (R.ok P) B) (k : ℕ) (cInt : ℤ) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1))
    (hsz : valSize (Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN k, encZ cInt]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
        Val.list [encStreamParams P, encN k, encZ cInt]]] []
      (.inl body_mfXYElem)
      (encBank R.enc (if k ≤ i then B.mapRows (Row.scaleXY P cInt) else B)) := by
  have hX : EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN k, encZ cInt]]] [] (.inl (Expr.var 0))
      (Val.list [Val.int (i : ℤ), encBank R.enc B,
        Val.list [encStreamParams P, encN k, encZ cInt]]) := EvalsVal.var rfl
  have hE : valSize (Val.list [encStreamParams P, encN k, encZ cInt]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN k, encZ cInt]]) rfl).trans hsz
  have h2 : 2 ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hsz; omega
  have hi := ev_get 0 hX hsz rfl
  have hB' := ev_get 1 hX hsz rfl
  have hext := ev_get 2 hX hsz rfl
  have hp := ev_get 0 hext hE rfl
  have hk := ev_get 1 hext hE rfl
  have hcz := ev_get 2 hext hE rfl
  have hlt := ev_lt' (x := (i : ℤ)) (y := (k : ℤ)) hi hk h2
  unfold body_mfXYElem
  by_cases hik : i < k
  · rw [if_neg (by omega)]
    exact ev_ite_true' hlt (by simp [hik]) hB'
  · rw [if_pos (by omega)]
    have harg := ev_list (prog := prog) (M := M) (.cons hp (.cons hB' (.cons hcz .nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil] at hsz ⊢; omega)
    exact ev_ite_false' hlt (by simp [hik]) (ev_scaleXYCall hC hP hM hB hc harg)

/-- **`mfXY`**: `mapFrom (Bank.mapRows (Row.scaleXY P cInt)) k` on encoded banks. -/
theorem mfXY_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) (bs : List Bank)
    (hbs : ∀ B ∈ bs, BankOK P (R.ok P) B) (k : ℕ) (cInt : ℤ) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1))
    (hMI : mapIdx_M (encBank R.enc) bs (Val.list [encStreamParams P, encN k, encZ cInt])
      (bankSizeBound P (R.bound P)) ≤ M) :
    EvalsVal prog M [Val.list [encL (encBank R.enc) bs,
        Val.list [encStreamParams P, encN k, encZ cInt]]] []
      (.inl body_mfXY) (encL (encBank R.enc) (mapFrom (Bank.mapRows (Row.scaleXY P cInt)) k bs)) := by
  have hada := hR.enc_le P hP
  rw [mapFrom_eq_mapIdxFrom]
  refine mapIdx_val hT.mfXYStep hT.mfXYElem hT.reverse hT.revAppendStep (encBank R.enc)
    (encBank R.enc) (Val.list [encStreamParams P, encN k, encZ cInt])
    (fun i a => if k ≤ i then a.mapRows (Row.scaleXY P cInt) else a) bs
    (bankSizeBound P (R.bound P)) (fun i B hB hi => mfXYElem_val hC hP hM i (hbs B hB) k cInt hc ?_)
    (fun i B hB => ?_) hMI
  · have h1 := BankOK.valSize_encBank_le hada (hbs B hB)
    have h2 : bitLen (i : ℤ) ≤ Nat.size bs.length := bitLen_le_size_of_le hi.le
    simp only [mapIdx_M] at hMI
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hMI ⊢
    omega
  · split_ifs
    · exact BankOK.valSize_encBank_le hada ((hbs B hB).scaleXY cInt)
    · exact BankOK.valSize_encBank_le hada (hbs B hB)

/-! ## `mfResc` -/

theorem mfRescElem_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) (i : ℕ) {L : Learner}
    (hL : LearnerOK P 4 L) (k : ℕ) (cInt : ℤ) (hc : |cInt| ≤ 2 ^ (P.eHstep + 1))
    (hsz : valSize (Val.list [Val.int (i : ℤ), encLearner L,
      Val.list [encStreamParams P, encN k, encZ cInt]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encLearner L,
        Val.list [encStreamParams P, encN k, encZ cInt]]] []
      (.inl body_mfRescElem)
      (encLearner (if k ≤ i then Learner.rescale P cInt L else L)) := by
  have hX : EvalsVal prog M [Val.list [Val.int (i : ℤ), encLearner L,
      Val.list [encStreamParams P, encN k, encZ cInt]]] [] (.inl (Expr.var 0))
      (Val.list [Val.int (i : ℤ), encLearner L,
        Val.list [encStreamParams P, encN k, encZ cInt]]) := EvalsVal.var rfl
  have hE : valSize (Val.list [encStreamParams P, encN k, encZ cInt]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encLearner L,
      Val.list [encStreamParams P, encN k, encZ cInt]]) rfl).trans hsz
  have h2 : 2 ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hsz; omega
  have hi := ev_get 0 hX hsz rfl
  have hL' := ev_get 1 hX hsz rfl
  have hext := ev_get 2 hX hsz rfl
  have hp := ev_get 0 hext hE rfl
  have hk := ev_get 1 hext hE rfl
  have hcz := ev_get 2 hext hE rfl
  have hlt := ev_lt' (x := (i : ℤ)) (y := (k : ℤ)) hi hk h2
  unfold body_mfRescElem
  by_cases hik : i < k
  · rw [if_neg (by omega)]
    exact ev_ite_true' hlt (by simp [hik]) hL'
  · rw [if_pos (by omega)]
    have harg := ev_list (prog := prog) (M := M) (.cons hp (.cons hcz (.cons hL' .nil)))
      (by simp only [valSize_list, listSize_cons, listSize_nil] at hsz ⊢; omega)
    exact ev_ite_false' hlt (by simp [hik]) (ev_rescaleCall hC hP hM hL hc harg)

/-- **`mfResc`**: `mapFrom (Learner.rescale P cInt) k` on encoded learners (multiplier in
`[1/2, 3/2]`, as produced by `stepCoeffMant`). -/
theorem mfResc_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    (hT : Tree4Lib prog) {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) (ls : List Learner)
    (hls : ∀ L ∈ ls, LearnerOK P 4 L) (k : ℕ) {cInt : ℤ} (hc0 : 2 ^ (P.eHstep - 1) ≤ cInt)
    (hc1 : cInt ≤ 3 * 2 ^ (P.eHstep - 1))
    (hMI : mapIdx_M encLearner ls (Val.list [encStreamParams P, encN k, encZ cInt])
      (2 ^ 6 * P.calL ^ 3) ≤ M) :
    EvalsVal prog M [Val.list [encL encLearner ls,
        Val.list [encStreamParams P, encN k, encZ cInt]]] []
      (.inl body_mfResc) (encL encLearner (mapFrom (Learner.rescale P cInt) k ls)) := by
  have hc : |cInt| ≤ 2 ^ (P.eHstep + 1) := by
    have hq : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
    have e : (2 : ℤ) ^ (P.eHstep + 1) = 4 * 2 ^ (P.eHstep - 1) := by
      rw [show P.eHstep + 1 = (P.eHstep - 1) + 2 by omega, pow_add]; ring
    have hpos : (0 : ℤ) < 2 ^ (P.eHstep - 1) := by positivity
    rw [abs_of_nonneg (by linarith), e]
    linarith
  rw [mapFrom_eq_mapIdxFrom]
  refine mapIdx_val hT.mfRescStep hT.mfRescElem hT.reverse hT.revAppendStep encLearner encLearner
    (Val.list [encStreamParams P, encN k, encZ cInt])
    (fun i a => if k ≤ i then Learner.rescale P cInt a else a) ls (2 ^ 6 * P.calL ^ 3)
    (fun i L hL hi => mfRescElem_val hC hP hM i (hls L hL) k cInt hc ?_) (fun i L hL => ?_) hMI
  · have h1 := (hls L hL).valSize_encLearner_le
    have h2 : bitLen (i : ℤ) ≤ Nat.size ls.length := bitLen_le_size_of_le hi.le
    simp only [mapIdx_M] at hMI
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hMI ⊢
    omega
  · split_ifs
    · exact valSize_encLearner_le16 ((hls L hL).rescale hc0 hc1)
    · exact (hls L hL).valSize_encLearner_le

/-! ## `allFrom` -/

/-- The loop state of `allFrom`: `[rest, k, p]`. -/
def encAF (P : StreamParams) (st : List Learner × ℕ) : Val :=
  Val.list [encL encLearner st.1, encN st.2, encStreamParams P]

section AllFrom

variable {R : AdaRep} {prog : List Expr} {M : ℕ}

theorem allFromStep_nil (P : StreamParams) (k : ℕ) (hM : valSize (encAF P ([], k)) + 10 ≤ M) :
    EvalsVal prog M [encAF P ([], k)] [] (.inl body_allFromStep)
      (Val.list [Val.int 0, encB true]) := by
  have hA : EvalsVal prog M [encAF P ([], k)] [] (.inl (Expr.var 0)) (encAF P ([], k)) :=
    EvalsVal.var rfl
  have hs : valSize (Val.list [Val.list [], encN k, encStreamParams P]) ≤ M := by
    have : valSize (encAF P ([], k)) = valSize (Val.list [Val.list [], encN k, encStreamParams P]) :=
      rfl
    omega
  have h1 := ev_get 0 hA hs rfl
  have hc := EvalsVal.isNil_nil (prog := prog) (M := M)
    (env := [Val.list [], encAF P ([], k)]) (a := Expr.var 0) (EvalsVal.var rfl) (by omega)
  have ht : EvalsVal prog M [Val.list [], encAF P ([], k)] []
      (.inl (eList [Expr.lit 0, Expr.lit 1])) (Val.list [Val.int 0, encB true]) :=
    ev_list (.cons (EvalsVal.lit (by simp; omega)) (.cons (EvalsVal.lit (by simp; omega)) .nil))
      (by simp [encB]; omega)
  unfold body_allFromStep
  exact ev_letE h1 (ev_ite_true' hc one_ne_zero ht)

theorem allFromStep_cons_zero (hC : Contracts R prog M) {P : StreamParams} (hP : ParamsOK P)
    (hMv : Mv R P ≤ M) (x : Learner) (r : List Learner) (hx : LearnerOK P 16 x)
    (hM : valSize (encAF P (x :: r, 0)) + 10 ≤ M) :
    EvalsVal prog M [encAF P (x :: r, 0)] [] (.inl body_allFromStep)
      (if x.inRange P then Val.list [Val.int 1, encAF P (r, 0)]
        else Val.list [Val.int 0, encB false]) := by
  set A := encAF P (x :: r, 0) with hAdef
  have hAe : A = Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0,
      encStreamParams P] := rfl
  have hM' : valSize (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0,
      encStreamParams P]) + 10 ≤ M := by rw [← hAe]; exact hM
  have hsA : valSize (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0,
      encStreamParams P]) ≤ M := by omega
  have hsz := hM'
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero] at hsz
  have hA : EvalsVal prog M [A] [] (.inl (Expr.var 0))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0, encStreamParams P]) :=
    EvalsVal.var (by rw [hAe]; rfl)
  have h1 := ev_get 0 hA hsA rfl
  -- env₁ = [rest, A]
  have hrest : EvalsVal prog M [Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 0)) (Val.list (encLearner x :: r.map encLearner)) := EvalsVal.var rfl
  have hc1 := EvalsVal.isNil_cons hrest (by omega)
  have hA1 : EvalsVal prog M [Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 1))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0, encStreamParams P]) :=
    EvalsVal.var (by rw [hAe]; rfl)
  have hk := ev_get 1 hA1 hsA rfl
  -- env₂ = [k, rest, A]
  have hk0 : EvalsVal prog M [Val.int 0, Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 0)) (Val.int 0) := EvalsVal.var rfl
  have hc2 := ev_eq (x := 0) (y := 0) hk0 (EvalsVal.lit (by simp; omega)) (by omega)
  have hA2 : EvalsVal prog M [Val.int 0, Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 2))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0, encStreamParams P]) :=
    EvalsVal.var (by rw [hAe]; rfl)
  have hp2 := ev_get 2 hA2 hsA rfl
  have hrest2 : EvalsVal prog M [Val.int 0, Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 1)) (Val.list (encLearner x :: r.map encLearner)) := EvalsVal.var rfl
  have hhd := ev_head' hrest2 (by simp only [valSize_list, listSize_cons] at hsz ⊢; omega)
  have harg := ev_list (prog := prog) (M := M) (.cons hp2 (.cons hhd .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have hok := ev_learnerInRangeCall hC hP hMv hx harg
  -- env₃ = [ok, k, rest, A]
  have hok0 : EvalsVal prog M [encB (x.inRange P), Val.int 0,
      Val.list (encLearner x :: r.map encLearner), A] [] (.inl (Expr.var 0))
      (encB (x.inRange P)) := EvalsVal.var rfl
  have hrest3 : EvalsVal prog M [encB (x.inRange P), Val.int 0,
      Val.list (encLearner x :: r.map encLearner), A] [] (.inl (Expr.var 2))
      (Val.list (encLearner x :: r.map encLearner)) := EvalsVal.var rfl
  have hA3 : EvalsVal prog M [encB (x.inRange P), Val.int 0,
      Val.list (encLearner x :: r.map encLearner), A] [] (.inl (Expr.var 3))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int 0, encStreamParams P]) :=
    EvalsVal.var (by rw [hAe]; rfl)
  have htl := ev_tail' hrest3 (by simp only [valSize_list, listSize_cons] at hsz ⊢; omega)
  have hp3 := ev_get 2 hA3 hsA rfl
  have hnext := ev_list (prog := prog) (M := M) (.cons htl (.cons (EvalsVal.lit (z := 0)
    (by simp; omega)) (.cons hp3 .nil)))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero] at hsz ⊢
        omega)
  have hyes := ev_list (prog := prog) (M := M) (.cons (EvalsVal.lit (z := 1) (by simp; omega))
    (.cons hnext .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero,
          bitLen_one] at hsz ⊢
        omega)
  have hno := ev_list (prog := prog) (M := M) (env := [encB (x.inRange P), Val.int 0,
      Val.list (encLearner x :: r.map encLearner), A])
    (.cons (EvalsVal.lit (z := 0) (by simp; omega)) (.cons (EvalsVal.lit (z := 0) (by simp; omega))
      .nil)) (by simp; omega)
  unfold body_allFromStep
  refine ev_letE h1 (ev_ite_false' hc1 rfl (ev_letE hk (ev_ite_true' hc2 (by simp)
    (ev_letE hok (ev_ite_encB hok0 ?_)))))
  revert hyes hno
  cases x.inRange P <;> intro hyes hno
  · exact hno
  · exact hyes

theorem allFromStep_cons_succ (P : StreamParams) (x : Learner) (r : List Learner) (k : ℕ)
    (hM : valSize (encAF P (x :: r, k + 1)) + 10 ≤ M) :
    EvalsVal prog M [encAF P (x :: r, k + 1)] [] (.inl body_allFromStep)
      (Val.list [Val.int 1, encAF P (r, k)]) := by
  set A := encAF P (x :: r, k + 1) with hAdef
  have hAe : A = Val.list [Val.list (encLearner x :: r.map encLearner), Val.int ((k + 1 : ℕ) : ℤ),
      encStreamParams P] := rfl
  have hM' : valSize (Val.list [Val.list (encLearner x :: r.map encLearner),
      Val.int ((k + 1 : ℕ) : ℤ), encStreamParams P]) + 10 ≤ M := by rw [← hAe]; exact hM
  have hsA : valSize (Val.list [Val.list (encLearner x :: r.map encLearner),
      Val.int ((k + 1 : ℕ) : ℤ), encStreamParams P]) ≤ M := by omega
  have hsz := hM'
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hsz
  have hkb : bitLen (k : ℤ) ≤ bitLen ((k + 1 : ℕ) : ℤ) := bitLen_mono_nat (by omega)
  have hA : EvalsVal prog M [A] [] (.inl (Expr.var 0))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int ((k + 1 : ℕ) : ℤ),
        encStreamParams P]) := EvalsVal.var (by rw [hAe]; rfl)
  have h1 := ev_get 0 hA hsA rfl
  have hrest : EvalsVal prog M [Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 0)) (Val.list (encLearner x :: r.map encLearner)) := EvalsVal.var rfl
  have hc1 := EvalsVal.isNil_cons hrest (by omega)
  have hA1 : EvalsVal prog M [Val.list (encLearner x :: r.map encLearner), A] []
      (.inl (Expr.var 1))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int ((k + 1 : ℕ) : ℤ),
        encStreamParams P]) := EvalsVal.var (by rw [hAe]; rfl)
  have hk := ev_get 1 hA1 hsA rfl
  have hk0 : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ), Val.list (encLearner x :: r.map encLearner),
      A] [] (.inl (Expr.var 0)) (Val.int ((k + 1 : ℕ) : ℤ)) := EvalsVal.var rfl
  have hc2 := ev_eq (y := 0) hk0 (EvalsVal.lit (by simp; omega)) (by omega)
  have hA2 : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ), Val.list (encLearner x :: r.map encLearner),
      A] [] (.inl (Expr.var 2))
      (Val.list [Val.list (encLearner x :: r.map encLearner), Val.int ((k + 1 : ℕ) : ℤ),
        encStreamParams P]) := EvalsVal.var (by rw [hAe]; rfl)
  have hrest2 : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ),
      Val.list (encLearner x :: r.map encLearner), A] [] (.inl (Expr.var 1))
      (Val.list (encLearner x :: r.map encLearner)) := EvalsVal.var rfl
  have htl := ev_tail' hrest2 (by simp only [valSize_list, listSize_cons] at hsz ⊢; omega)
  have hsub := ev_sub' (y := 1) hk0 (EvalsVal.lit (by simp; omega))
    (by have e : ((k + 1 : ℕ) : ℤ) - 1 = (k : ℤ) := by push_cast; ring
        rw [e]; simp only [valSize_int]; omega)
  have e : ((k + 1 : ℕ) : ℤ) - 1 = (k : ℤ) := by push_cast; ring
  rw [e] at hsub
  have hp2 := ev_get 2 hA2 hsA rfl
  have hnext := ev_list (prog := prog) (M := M) (.cons htl (.cons hsub (.cons hp2 .nil)))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hsz ⊢; omega)
  have hyes := ev_list (prog := prog) (M := M) (.cons (EvalsVal.lit (z := 1) (by simp; omega))
    (.cons hnext .nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_one] at hsz ⊢
        omega)
  unfold body_allFromStep
  exact ev_letE h1 (ev_ite_false' hc1 rfl (ev_letE hk (ev_ite_false' hc2
    (by rw [if_neg (by omega)]) hyes)))

theorem valSize_encAF_le {P : StreamParams} {r ls : List Learner} (hsuf : r <:+ ls) {k k0 : ℕ}
    (hk : k ≤ k0) : valSize (encAF P (r, k)) ≤ valSize (encAF P (ls, k0)) := by
  have h1 : listSize (r.map encLearner) ≤ listSize (ls.map encLearner) :=
    listSize_le_of_suffix (hsuf.map encLearner)
  have h2 : bitLen (k : ℤ) ≤ bitLen (k0 : ℤ) := bitLen_mono_nat hk
  simp only [encAF, encL, encN, valSize_list, listSize_cons, listSize_nil, valSize_int]
  omega

/-- **`allFrom`**: `[encL encLearner ls, k, p] ↦ encB ((ls.drop k).all (Learner.inRange P))` for
learners within the failure ranges (`LearnerOK P 16`). -/
theorem allFrom_val (hC : Contracts R prog M) (hT : Tree4Lib prog) {P : StreamParams}
    (hP : ParamsOK P) (hMv : Mv R P ≤ M) (ls : List Learner) (hls : ∀ L ∈ ls, LearnerOK P 16 L)
    (k0 : ℕ) (hM : valSize (encAF P (ls, k0)) + 10 ≤ M) :
    EvalsVal prog M [encAF P (ls, k0)] [] (.inl body_allFrom)
      (encB ((ls.drop k0).all (Learner.inRange P))) := by
  have key := EvalsVal.loop_of_measure (prog := prog) (M := M) hT.allFromStep (encAF P)
    (fun _ => [])
    (fun st : List Learner × ℕ => st.1 <:+ ls ∧
      (st.1.drop st.2).all (Learner.inRange P) = (ls.drop k0).all (Learner.inRange P) ∧ st.2 ≤ k0)
    (· = encB ((ls.drop k0).all (Learner.inRange P))) (fun st => st.1.length) ?_ (ls, k0)
    ⟨List.suffix_refl ls, rfl, le_rfl⟩
  · obtain ⟨out, rfl, hloop⟩ := key
    unfold body_allFrom
    exact EvalsVal.loop (EvalsVal.var rfl) hloop
  · rintro ⟨r, k⟩ ⟨hsuf, hall, hk⟩
    dsimp only at hsuf hall hk ⊢
    have hsz : valSize (encAF P (r, k)) + 10 ≤ M := by
      have := valSize_encAF_le (P := P) hsuf hk; omega
    cases r with
    | nil =>
      left
      refine ⟨encB true, allFromStep_nil P k hsz, ?_⟩
      rw [← hall]; simp
    | cons x r =>
      have hx : LearnerOK P 16 x := hls x (hsuf.subset List.mem_cons_self)
      have hsuf' : r <:+ ls := (List.suffix_cons x r).trans hsuf
      cases k with
      | zero =>
        have hstep := allFromStep_cons_zero hC hP hMv x r hx hsz
        cases hxr : x.inRange P
        · left
          rw [hxr] at hstep
          refine ⟨encB false, hstep, ?_⟩
          rw [← hall]; simp [hxr]
        · right
          rw [hxr] at hstep
          refine ⟨1, (r, 0), [], one_ne_zero, rfl, hstep, ⟨hsuf', ?_, Nat.zero_le _⟩, by simp⟩
          rw [← hall]; simp [hxr]
      | succ k =>
        right
        refine ⟨1, (r, k), [], one_ne_zero, rfl, allFromStep_cons_succ P x r k hsz,
          ⟨hsuf', ?_, by omega⟩, by simp⟩
        rw [← hall]; simp

end AllFrom

end F2e2e.C.Impl.T4
