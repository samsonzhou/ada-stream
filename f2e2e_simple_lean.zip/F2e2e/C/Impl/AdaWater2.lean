import F2e2e.C.Impl.AdaMusDefs
import F2e2e.Cost.Lib.Sum

/-!
# ADA module (W4), part 8: the search fold and the predictions in the DSL

* `wlLevelFold` (Idx 628–630): the exact water level `wlLevel cn cd g` (search over the breakpoints);
* `predNumFold` (Idx 631–633): the numerator `predNum` of a learned prediction (zip fold);
* `adaMuJ` (Idx 634) / `adaMusMap` (635/636): the prediction pair of block `j`, mapped over `0..p`;
* `adaMusR` (Idx 640): `[pub, scores, vals] ↦ encL encPZ (musZ A st.scores vals)`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The search fold `wlLevelFold` -/

/-- Element routine of `wlLevelFold`: `[x, s, [g, cn, cd, n]] ↦ wlStep cn cd g x s`. -/
def body_wlLevelEl : Expr :=
  eIte (Expr.un UnOp.isNil (eAtN 1 (eV 0)))
    (eLet (eCall Idx.wlTryR (eList [(zS (lf eFx) (lf (eFe 1)) (lf (eFe 2))).toExpr, eFe 0, eFe 1,
        eFe 2, eFe 3]))
      (eIte (Expr.un UnOp.isNil (eV 0))
        (eCall Idx.wlTryR (eList [(ZE.sub (zS (lf (eAtN 0 (eV 1))) (lf (eAtN 1 (eAtN 2 (eV 1))))
            (lf (eAtN 2 (eAtN 2 (eV 1))))) (ZE.mul (ZE.lit 8) (lf (eAtN 2 (eAtN 2 (eV 1)))))).toExpr,
          eAtN 0 (eAtN 2 (eV 1)), eAtN 1 (eAtN 2 (eV 1)), eAtN 2 (eAtN 2 (eV 1)),
          eAtN 3 (eAtN 2 (eV 1))]))
        (eV 0)))
    (eAtN 1 (eV 0))

/-- Bounds of a found level. -/
def OptOK (W : ℕ) (s : Option (ℤ × ℤ)) : Prop :=
  ∀ N D, s = some (N, D) → bitLen N ≤ 3 * W + 8 ∧ bitLen D ≤ 2 * W

theorem wlTry_bounds {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) {B : ℤ}
    (hB : bitLen B ≤ 2 * W + 6) : OptOK W (wlTry cn cd g B) := by
  intro N D h
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  obtain ⟨hF0, hF1, hk0, hk1⟩ := wlFK_bounds hW B
  have hFW : bitLen (wlFK cn cd g B).1 ≤ 2 * W + 4 := hW.le_8cdn hF0 hF1
  have hkW : bitLen (wlFK cn cd g B).2 ≤ W := hW.le_n hk0 hk1
  unfold wlTry at h
  split_ifs at h with h1 h2
  · simp only [Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨hN, hD⟩ := h
    rw [← hN, ← hD]
    omega
  · simp only [Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨hN, hD⟩ := h
    rw [← hN, ← hD]
    have e1 := bitLen_sub_le ((wlFK cn cd g B).2 * B + (wlFK cn cd g B).1)
      ((g.length : ℤ) * cd)
    have e2 := bitLen_add_le ((wlFK cn cd g B).2 * B) (wlFK cn cd g B).1
    have e3 := bitLen_mul_le (wlFK cn cd g B).2 B
    have e4 := bitLen_mul_le (g.length : ℤ) cd
    have e5 := bitLen_mul_le (wlFK cn cd g B).2 cd
    omega

theorem valSize_encOptPair_le {W : ℕ} {s : Option (ℤ × ℤ)} (hs : OptOK W s) :
    valSize (encOptPair s) ≤ 5 * W + 13 := by
  cases s with
  | none => simp [encOptPair]
  | some r =>
    obtain ⟨N, D⟩ := r
    obtain ⟨h1, h2⟩ := hs N D rfl
    simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega

section Level

variable {prog : List Expr} {M : ℕ}

theorem wlLevelEl_val (hF : FoldLib prog) (htry : prog[Idx.wlTryR]? = some body_wlTry)
    {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) {x : ℤ} (hx : x ∈ g)
    {s : Option (ℤ × ℤ)} (hs : OptOK W s)
    (hM : 4 * valSize (encL encZ g) + 128 * W + 1024 ≤ M) :
    EvalsVal prog M [Val.list [encZ x, encOptPair s, Val.list [encL encZ g, Val.int cn,
      Val.int cd, Val.int (g.length : ℤ)]]] [] (.inl body_wlLevelEl)
      (encOptPair (wlStep cn cd g x s)) := by
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  have hxW := hW.g_le x hx
  have hsV := valSize_encOptPair_le hs
  set ex := Val.list [encL encZ g, Val.int cn, Val.int cd, Val.int (g.length : ℤ)] with hex
  set a := Val.list [encZ x, encOptPair s, ex] with ha
  have hexM : valSize ex ≤ valSize (encL encZ g) + 4 * W + 20 := by
    simp only [hex, valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : valSize (encL encZ g) = 1 + listSize (g.map encZ) := rfl
    omega
  have haM : valSize a ≤ M := by
    simp only [ha, valSize_list, listSize_cons, listSize_nil, encZ, valSize_int]
    have : valSize ex = 1 + listSize [encL encZ g, Val.int cn, Val.int cd,
      Val.int (g.length : ℤ)] := rfl
    omega
  have ls : EvalsVal prog M [a] [] (.inl (eAtN 1 (eV 0))) (encOptPair s) := evalsVal_at1 rfl haM rfl
  cases s with
  | some r =>
    obtain ⟨N, D⟩ := r
    have hnil : EvalsVal prog M [a] [] (.inl (Expr.un UnOp.isNil (eAtN 1 (eV 0)))) (Val.int 0) :=
      EvalsVal.isNil_cons (x := Val.int N) (l := [Val.int D]) ls (by omega)
    exact EvalsVal.ite_false hnil rfl ls
  | none =>
    have hnil : EvalsVal prog M [a] [] (.inl (Expr.un UnOp.isNil (eAtN 1 (eV 0)))) (Val.int 1) :=
      EvalsVal.isNil_nil ls (by omega)
    refine EvalsVal.ite_true hnil one_ne_zero ?_
    have lx : EvalsVal prog M [a] [] (.inl eFx) (Val.int x) := evalsVal_at1 rfl haM rfl
    have lg : EvalsVal prog M [a] [] (.inl (eFe 0)) (encL encZ g) := evalsVal_at2 rfl haM rfl rfl
    have lcn : EvalsVal prog M [a] [] (.inl (eFe 1)) (Val.int cn) := evalsVal_at2 rfl haM rfl rfl
    have lcd : EvalsVal prog M [a] [] (.inl (eFe 2)) (Val.int cd) := evalsVal_at2 rfl haM rfl rfl
    have ln : EvalsVal prog M [a] [] (.inl (eFe 3)) (Val.int (g.length : ℤ)) :=
      evalsVal_at2 rfl haM rfl rfl
    set eS := zS (ZE.leaf eFx x) (ZE.leaf (eFe 1) cn) (ZE.leaf (eFe 2) cd) with heS
    have hSE : EvalsVal prog M [a] [] (.inl eS.toExpr) (Val.int (wlS cn cd x)) :=
      ZE.spec' (W := W) (by simp only [heS, zS, ZE.OK]; exact ⟨lcd, lcn, lx⟩)
        (by simp only [heS, zS, ZE.LeafLe]; omega) (by simp only [heS, zS, ZE.cb]; omega)
    have hS := hW.S_le hx
    have harg1 : EvalsVal prog M [a] [] (.inl (eList [eS.toExpr, eFe 0, eFe 1, eFe 2, eFe 3]))
        (Val.list [Val.int (wlS cn cd x), encL encZ g, Val.int cn, Val.int cd,
          Val.int (g.length : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons hSE (List.Forall₂.cons lg (List.Forall₂.cons lcn
        (List.Forall₂.cons lcd (List.Forall₂.cons ln List.Forall₂.nil)))))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
            have : valSize (encL encZ g) = 1 + listSize (g.map encZ) := rfl
            omega)
    have ht1 := evalsVal_call_det htry harg1
      (wlTry_val hF hW (by omega) (by omega))
    refine EvalsVal.letE ht1 ?_
    have hb1 := wlTry_bounds hW (B := wlS cn cd x) (by omega)
    have hr1V := valSize_encOptPair_le hb1
    set e1 := encOptPair (wlTry cn cd g (wlS cn cd x)) :: [a] with he1
    have l0 : EvalsVal prog M e1 [] (.inl (eV 0)) (encOptPair (wlTry cn cd g (wlS cn cd x))) :=
      EvalsVal.var rfl
    cases h1 : wlTry cn cd g (wlS cn cd x) with
    | some r =>
      obtain ⟨N, D⟩ := r
      rw [h1] at l0
      have hnil : EvalsVal prog M e1 [] (.inl (Expr.un UnOp.isNil (eV 0))) (Val.int 0) :=
        EvalsVal.isNil_cons (x := Val.int N) (l := [Val.int D]) l0 (by omega)
      have hres : encOptPair (wlStep cn cd g x none) = encOptPair (some (N, D)) := by
        simp only [wlStep, h1]
      rw [hres]
      exact EvalsVal.ite_false hnil rfl l0
    | none =>
      rw [h1] at l0
      have hnil : EvalsVal prog M e1 [] (.inl (Expr.un UnOp.isNil (eV 0))) (Val.int 1) :=
        EvalsVal.isNil_nil l0 (by omega)
      have hres : encOptPair (wlStep cn cd g x none) =
          encOptPair (wlTry cn cd g (wlS cn cd x - 8 * cd)) := by
        simp only [wlStep, h1]
      rw [hres]
      refine EvalsVal.ite_true hnil one_ne_zero ?_
      have lx' : EvalsVal prog M e1 [] (.inl (eAtN 0 (eV 1))) (Val.int x) :=
        evalsVal_at1 rfl haM rfl
      have lg' : EvalsVal prog M e1 [] (.inl (eAtN 0 (eAtN 2 (eV 1)))) (encL encZ g) :=
        evalsVal_at2 rfl haM rfl rfl
      have lcn' : EvalsVal prog M e1 [] (.inl (eAtN 1 (eAtN 2 (eV 1)))) (Val.int cn) :=
        evalsVal_at2 rfl haM rfl rfl
      have lcd' : EvalsVal prog M e1 [] (.inl (eAtN 2 (eAtN 2 (eV 1)))) (Val.int cd) :=
        evalsVal_at2 rfl haM rfl rfl
      have ln' : EvalsVal prog M e1 [] (.inl (eAtN 3 (eAtN 2 (eV 1)))) (Val.int (g.length : ℤ)) :=
        evalsVal_at2 rfl haM rfl rfl
      set eS8 := ZE.sub (zS (ZE.leaf (eAtN 0 (eV 1)) x) (ZE.leaf (eAtN 1 (eAtN 2 (eV 1))) cn)
        (ZE.leaf (eAtN 2 (eAtN 2 (eV 1))) cd)) (ZE.mul (ZE.lit 8) (ZE.leaf (eAtN 2 (eAtN 2 (eV 1))) cd))
        with heS8
      have hS8E : EvalsVal prog M e1 [] (.inl eS8.toExpr) (Val.int (wlS cn cd x - 8 * cd)) :=
        ZE.spec' (W := W) (by simp only [heS8, zS, ZE.OK]; exact ⟨⟨lcd', lcn', lx'⟩, trivial, lcd'⟩)
          (by simp only [heS8, zS, ZE.LeafLe]; exact ⟨⟨hcdW, hcnW, hxW⟩, trivial, hcdW⟩)
          (by simp only [heS8, zS, ZE.cb, bitLen_eight]; omega)
      have hB8 := hW.B_le hx (B := wlS cn cd x - 8 * cd) (Or.inr rfl)
      have harg2 : EvalsVal prog M e1 [] (.inl (eList [eS8.toExpr, eAtN 0 (eAtN 2 (eV 1)),
          eAtN 1 (eAtN 2 (eV 1)), eAtN 2 (eAtN 2 (eV 1)), eAtN 3 (eAtN 2 (eV 1))]))
          (Val.list [Val.int (wlS cn cd x - 8 * cd), encL encZ g, Val.int cn, Val.int cd,
            Val.int (g.length : ℤ)]) :=
        evalsVal_list (List.Forall₂.cons hS8E (List.Forall₂.cons lg' (List.Forall₂.cons lcn'
          (List.Forall₂.cons lcd' (List.Forall₂.cons ln' List.Forall₂.nil)))))
          (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
              have : valSize (encL encZ g) = 1 + listSize (g.map encZ) := rfl
              omega)
      exact evalsVal_call_det htry harg2 (wlTry_val hF hW hB8 (by omega))

/-- **The water level fold.** -/
theorem wlLevelFold_val (hF : FoldLib prog) (htry : prog[Idx.wlTryR]? = some body_wlTry)
    (hstep : prog[Idx.wlLevelStep]? = some (body_foldBStep Idx.wlLevelEl))
    (hel : prog[Idx.wlLevelEl]? = some body_wlLevelEl) {cn cd : ℤ} {g : List ℤ} {W : ℕ}
    (hW : WB cn cd g W) (hM : 4 * valSize (encL encZ g) + 128 * W + 1024 ≤ M) :
    EvalsVal prog M [Val.list [encOptPair none, encL encZ g, Val.list [encL encZ g, Val.int cn,
      Val.int cd, Val.int (g.length : ℤ)]]] [] (.inl (body_foldB Idx.wlLevelStep))
      (encOptPair (wlLevel cn cd g)) := by
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  refine foldP_body' hstep hel encZ encOptPair
    (Val.list [encL encZ g, Val.int cn, Val.int cd, Val.int (g.length : ℤ)])
    (wlStep cn cd g) (fun _ s => OptOK W s) (5 * W + 13) g ?_ ?_ ?_ none ?_
  · intro x r s hsuf hs
    have hx : x ∈ g := hsuf.subset List.mem_cons_self
    refine ⟨wlLevelEl_val hF htry hW hx hs hM, ?_⟩
    intro N D h
    cases s with
    | some r' => exact hs N D h
    | none =>
      simp only [wlStep] at h
      cases h1 : wlTry cn cd g (wlS cn cd x) with
      | some r'' =>
        rw [h1] at h
        exact wlTry_bounds hW (B := wlS cn cd x) (by have := hW.S_le hx; omega) N D (h1.trans h)
      | none =>
        rw [h1] at h
        exact wlTry_bounds hW (hW.B_le hx (Or.inr rfl)) N D h
  · intro r s _ hs
    exact valSize_encOptPair_le hs
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : valSize (encL encZ g) = 1 + listSize (g.map encZ) := rfl
    omega
  · intro N D h
    exact absurd h (by simp)

end Level

end F2e2e.C.Impl

namespace F2e2e.Cost.Idx

abbrev pnFold : ℕ := 631
abbrev pnStep : ℕ := 632
abbrev pnEl : ℕ := 633

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The numerator fold `pnFold` -/

/-- Fold step of the numerator: `(acc, v) ↦ (acc + clip(S x D − N cd) v₀, tail v)`. -/
def pnStepF (cn cd N D : ℤ) (x : ℤ) (s : ℤ × List ℕ) : ℤ × List ℕ :=
  (s.1 + clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * ((s.2.headD 0 : ℕ) : ℤ), s.2.tail)

theorem foldP_pnStep (cn cd N D : ℤ) :
    ∀ (g : List ℤ) (a : ℤ) (v : List ℕ), g.length ≤ v.length →
      foldP (pnStepF cn cd N D) g (a, v) = (a + predNum cn cd N D g v, v.drop g.length)
  | [], a, v, _ => by simp [foldP, predNum]
  | x :: xs, a, v, h => by
    cases v with
    | nil => simp at h
    | cons v0 vs =>
      simp only [foldP, pnStepF, List.headD_cons, List.tail_cons]
      rw [foldP_pnStep cn cd N D xs _ vs (by simp at h; omega)]
      simp only [predNum, List.zipWith_cons_cons, List.sum_cons, List.length_cons,
        List.drop_succ_cons, Prod.mk.injEq, and_true]
      ring

/-- The state `(acc, v)`: `[acc, v]`. -/
def encPN (s : ℤ × List ℕ) : Val := Val.list [Val.int s.1, encL encN s.2]

/-- `acc + clip_{[0, 8 cd D]}(S(x) D − N cd) v₀`. -/
def zPN (x acc v0 N D cn cd : ZE) : ZE :=
  ZE.add acc (ZE.mul (zClip0 (ZE.mul (ZE.mul (ZE.lit 8) cd) D)
    (ZE.sub (ZE.mul (zS x cn cd) D) (ZE.mul N cd))) v0)

/-- Element routine of `pnFold`: `[x, [acc, v], [N, D, cn, cd]] ↦ pnStepF cn cd N D x (acc, v)`. -/
def body_pnEl : Expr :=
  eList [(zPN (lf eFx) (lf (eFs 0)) (lf (eHd (eFs 1))) (lf (eFe 0)) (lf (eFe 1)) (lf (eFe 2))
    (lf (eFe 3))).toExpr, eTl (eFs 1)]

section PN

variable {prog : List Expr} {M : ℕ}

theorem pnEl_val {x acc N D cn cd : ℤ} {v0 : ℕ} {vs : List ℕ} (hcd : 0 ≤ cd) (hD : 0 ≤ D)
    {W : ℕ} (hx : bitLen x ≤ W) (hacc : bitLen acc ≤ W) (hv0 : bitLen (v0 : ℤ) ≤ W)
    (hN : bitLen N ≤ W) (hD' : bitLen D ≤ W) (hcn : bitLen cn ≤ W) (hcd' : bitLen cd ≤ W)
    (hVM : valSize (Val.list [encZ x, encPN (acc, v0 :: vs),
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]) + 2 * (32 * W + 40) ≤ M) :
    EvalsVal prog M [Val.list [encZ x, encPN (acc, v0 :: vs),
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]]
      [] (.inl body_pnEl) (encPN (pnStepF cn cd N D x (acc, v0 :: vs))) := by
  set a := Val.list [encZ x, encPN (acc, v0 :: vs),
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]] with ha
  have hV : valSize a ≤ M := by omega
  have hM : 2 * (32 * W + 40) ≤ M := by omega
  have lx : EvalsVal prog M [a] [] (.inl eFx) (Val.int x) := evalsVal_at1 rfl hV rfl
  have lacc : EvalsVal prog M [a] [] (.inl (eFs 0)) (Val.int acc) := evalsVal_at2 rfl hV rfl rfl
  have lvs : EvalsVal prog M [a] [] (.inl (eFs 1)) (Val.list (encN v0 :: vs.map encN)) :=
    evalsVal_at2 rfl hV rfl rfl
  have hvsV : valSize (Val.list (encN v0 :: vs.map encN)) ≤ M := by
    refine le_trans ?_ hV
    have h1 : valSize (Val.list (encN v0 :: vs.map encN)) < valSize (encPN (acc, v0 :: vs)) :=
      valSize_lt_of_mem (by simp [encPN, encL])
    have h2 : valSize (encPN (acc, v0 :: vs)) < valSize a := valSize_lt_of_mem (by simp [ha])
    omega
  have lv0 : EvalsVal prog M [a] [] (.inl (eHd (eFs 1))) (Val.int (v0 : ℤ)) :=
    EvalsVal.head lvs (le_trans (by simp only [encN, valSize_list, listSize_cons, valSize_int]; omega)
      hvsV)
  have ltl : EvalsVal prog M [a] [] (.inl (eTl (eFs 1))) (encL encN vs) :=
    EvalsVal.tail lvs (le_trans (by simp only [valSize_list, listSize_cons]; omega) hvsV)
  have lN : EvalsVal prog M [a] [] (.inl (eFe 0)) (Val.int N) := evalsVal_at2 rfl hV rfl rfl
  have lD : EvalsVal prog M [a] [] (.inl (eFe 1)) (Val.int D) := evalsVal_at2 rfl hV rfl rfl
  have lcn : EvalsVal prog M [a] [] (.inl (eFe 2)) (Val.int cn) := evalsVal_at2 rfl hV rfl rfl
  have lcd : EvalsVal prog M [a] [] (.inl (eFe 3)) (Val.int cd) := evalsVal_at2 rfl hV rfl rfl
  set e := zPN (ZE.leaf eFx x) (ZE.leaf (eFs 0) acc) (ZE.leaf (eHd (eFs 1)) (v0 : ℤ))
    (ZE.leaf (eFe 0) N) (ZE.leaf (eFe 1) D) (ZE.leaf (eFe 2) cn) (ZE.leaf (eFe 3) cd) with he
  have hok : e.OK prog M [a] := by
    simp only [he, zPN, zClip0, zS, ZE.OK]
    repeat' apply And.intro
    all_goals trivial
  have hl : e.LeafLe W := by
    simp only [he, zPN, zClip0, zS, ZE.LeafLe]
    repeat' apply And.intro
    all_goals trivial
  have hc : e.cb W ≤ 32 * W + 40 := by
    simp only [he, zPN, zClip0, zS, ZE.cb, bitLen_eight, bitLen_zero]; omega
  have h := ZE.spec' hok hl (by omega)
  have hb := ZE.bitLen_val_le_cb hl
  have hv : e.val = (pnStepF cn cd N D x (acc, v0 :: vs)).1 := by
    simp only [he, zPN, ZE.val, pnStepF, List.headD_cons]
    rw [show (zClip0 (((ZE.lit 8).mul (ZE.leaf (eFe 3) cd)).mul (ZE.leaf (eFe 1) D))
        (((zS (ZE.leaf eFx x) (ZE.leaf (eFe 2) cn) (ZE.leaf (eFe 3) cd)).mul (ZE.leaf (eFe 1) D)).sub
          ((ZE.leaf (eFe 0) N).mul (ZE.leaf (eFe 3) cd)))).val =
        clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) from by
      rw [zClip0_val _ _ (by simp only [ZE.val]; positivity)]; rfl]
  rw [hv] at h
  have hres := evalsVal_list (es := [e.toExpr, eTl (eFs 1)])
    (vs := [Val.int (pnStepF cn cd N D x (acc, v0 :: vs)).1, encL encN vs])
    (List.Forall₂.cons h (List.Forall₂.cons ltl List.Forall₂.nil))
    (by
      rw [← hv]
      have h1 : valSize (encL encN vs) ≤ valSize (Val.list (encN v0 :: vs.map encN)) := by
        simp only [encL, valSize_list, listSize_cons]; omega
      have h2 : valSize (Val.list (encN v0 :: vs.map encN)) < valSize (encPN (acc, v0 :: vs)) :=
        valSize_lt_of_mem (by simp [encPN, encL])
      have h3 : valSize (encPN (acc, v0 :: vs)) < valSize a := valSize_lt_of_mem (by simp [ha])
      show 1 + (valSize (Val.int e.val) + 1 + (valSize (encL encN vs) + 1 + 0)) ≤ M
      simp only [valSize_int]
      omega)
  exact hres

private theorem valSize_list3 (a b c : Val) :
    valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

private theorem valSize_ints4 (a b c d : ℤ) :
    valSize (Val.list [Val.int a, Val.int b, Val.int c, Val.int d]) =
      bitLen a + bitLen b + bitLen c + bitLen d + 9 := by
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega

theorem valSize_encPN (a : ℤ) (vs : List ℕ) :
    valSize (encPN (a, vs)) = bitLen a + valSize (encL encN vs) + 4 := by
  simp only [encPN, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega

private theorem valSize_encL_drop_le (v : List ℕ) (k : ℕ) :
    valSize (encL encN (v.drop k)) ≤ valSize (encL encN v) := by
  simp only [encL, valSize_list, List.map_drop]
  have := listSize_drop_le (v.map encN) k
  omega

private theorem pn_bound {x acc N D cn cd : ℤ} {v0 : ℕ} {vs : List ℕ} {W M VV : ℕ}
    (hx : bitLen x ≤ W) (hacc : bitLen acc ≤ 5 * W + 5) (hN : bitLen N ≤ 3 * W + 8)
    (hD : bitLen D ≤ 2 * W) (hcn : bitLen cn ≤ W) (hcd : bitLen cd ≤ W)
    (hvs : valSize (encL encN (v0 :: vs)) ≤ VV) (hM : VV + 512 * W + 4096 ≤ M) :
    valSize (Val.list [encZ x, encPN (acc, v0 :: vs),
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]) + 2 * (32 * (5 * W + 8) + 40) ≤ M := by
  rw [valSize_list3, valSize_encPN, valSize_ints4, valSize_encZ]
  generalize valSize (encL encN (v0 :: vs)) = VVs at hvs ⊢
  have hx' : (bitLen x : ℤ) ≤ W := by exact_mod_cast hx
  have hacc' : (bitLen acc : ℤ) ≤ 5 * W + 5 := by exact_mod_cast hacc
  have hN' : (bitLen N : ℤ) ≤ 3 * W + 8 := by exact_mod_cast hN
  have hD' : (bitLen D : ℤ) ≤ 2 * W := by exact_mod_cast hD
  have hcn' : (bitLen cn : ℤ) ≤ W := by exact_mod_cast hcn
  have hcd' : (bitLen cd : ℤ) ≤ W := by exact_mod_cast hcd
  have hvs' : (VVs : ℤ) ≤ VV := by exact_mod_cast hvs
  have hM' : (VV : ℤ) + 512 * W + 4096 ≤ M := by exact_mod_cast hM
  have : ((bitLen x + 1 + (bitLen acc + VVs + 4) + (bitLen N + bitLen D + bitLen cn + bitLen cd + 9) +
      4 + 2 * (32 * (5 * W + 8) + 40) : ℕ) : ℤ) ≤ M := by push_cast; linarith
  exact_mod_cast this

/-- **The numerator fold** (`|v| = |g|`, entries of `≤ W` bits). -/
theorem pnFold_val (hstep : prog[Idx.pnStep]? = some (body_foldBStep Idx.pnEl))
    (hel : prog[Idx.pnEl]? = some body_pnEl) {cn cd : ℤ} {g : List ℤ} {W : ℕ}
    (hW : WB cn cd g W) {N D : ℤ} (hN : bitLen N ≤ 3 * W + 8) (hD0 : 0 < D)
    (hDW : bitLen D ≤ 2 * W) {v : List ℕ} (hvl : v.length = g.length)
    (hvW : ∀ y ∈ v, bitLen (y : ℤ) ≤ W)
    (hM : 2 * valSize (encL encZ g) + 2 * valSize (encL encN v) + 512 * W + 4096 ≤ M) :
    EvalsVal prog M [Val.list [encPN (0, v), encL encZ g,
      Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]]] [] (.inl (body_foldB Idx.pnStep))
      (encPN (predNum cn cd N D g v, [])) := by
  have hcd := hW.cd_pos
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hnW := hW.n_cast_le
  set V : ℤ := 2 ^ W with hVdef
  have hVpos : 0 < V := by positivity
  have hvV : ∀ y ∈ v, (y : ℤ) < V := by
    intro y hy
    have h1 := hvW y hy
    rw [bitLen_natCast] at h1
    have := Nat.lt_size_self y
    have h2 : y < 2 ^ W := lt_of_lt_of_le this (Nat.pow_le_pow_right (by norm_num) h1)
    rw [hVdef]; exact_mod_cast h2
  have hbig : ∀ m : ℤ, 0 ≤ m → m ≤ 8 * cd * D * V * g.length → bitLen m ≤ 5 * W + 5 := by
    intro m h0 hm
    have h1 := bitLen_le_of_nonneg_le h0 hm
    have h2 := bitLen_mul_le (8 * cd * D * V) (g.length : ℤ)
    have h3 := bitLen_mul_le (8 * cd * D) V
    have h4 := bitLen_mul_le (8 * cd) D
    have h5 := bitLen_mul_le 8 cd
    have h6 : bitLen V = W + 1 := by rw [hVdef]; unfold bitLen; simp [Nat.size_pow]
    rw [bitLen_eight] at h5
    omega
  have hres := foldP_body' (M := M) (σ := ℤ × List ℕ) hstep hel encZ encPN
    (Val.list [Val.int N, Val.int D, Val.int cn, Val.int cd]) (pnStepF cn cd N D)
    (fun r s => s.2.length = r.length ∧ s.2 <:+ v ∧ 0 ≤ s.1 ∧
      s.1 + 8 * cd * D * V * r.length ≤ 8 * cd * D * V * g.length)
    (5 * W + valSize (encL encN v) + 10) g ?_ ?_ ?_ (0, v) ?_
  · rw [foldP_pnStep cn cd N D g 0 v (by omega), zero_add, ← hvl, List.drop_length] at hres
    exact hres
  · rintro x r ⟨acc, vs⟩ hsuf ⟨h1, h2, h3, h4⟩
    have hx : x ∈ g := hsuf.subset List.mem_cons_self
    simp only [List.length_cons] at h1
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one] at h4
    obtain ⟨v0, vs', rfl⟩ : ∃ v0 vs', vs = v0 :: vs' := by
      cases vs with
      | nil => simp at h1
      | cons v0 vs' => exact ⟨v0, vs', rfl⟩
    have hv0 : v0 ∈ v := h2.subset List.mem_cons_self
    have hv0V := hvV v0 hv0
    have hv0W := hvW v0 hv0
    have hpos : 0 ≤ 8 * cd * D * V * ((r.length : ℤ) + 1) := by positivity
    have hacc := hbig acc h3 (by linarith)
    have hxW := hW.g_le x hx
    have hcl0 := clipZ_nonneg (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) (by positivity)
    have hcl1 := clipZ_le (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) (by positivity)
    have hvsV : valSize (encL encN (v0 :: vs')) ≤ valSize (encL encN v) := by
      obtain ⟨t, ht⟩ := h2
      rw [← ht]
      simp only [encL, List.map_append, valSize_list, listSize_append]
      omega
    have hx8 : bitLen x ≤ 5 * W + 8 := by omega
    have hacc8 : bitLen acc ≤ 5 * W + 8 := by omega
    have hv08 : bitLen (v0 : ℤ) ≤ 5 * W + 8 := by omega
    have hN8 : bitLen N ≤ 5 * W + 8 := by omega
    have hD8 : bitLen D ≤ 5 * W + 8 := by omega
    have hcn8 : bitLen cn ≤ 5 * W + 8 := by omega
    have hcd8 : bitLen cd ≤ 5 * W + 8 := by omega
    have hMV : valSize (encL encN v) + 512 * W + 4096 ≤ M := by omega
    have hVa := pn_bound (x := x) (acc := acc) (N := N) (D := D) (cn := cn) (cd := cd)
      hxW hacc hN hDW hcnW hcdW hvsV hMV
    refine ⟨pnEl_val (x := x) (acc := acc) (N := N) (D := D) (cn := cn) (cd := cd) (v0 := v0)
      (vs := vs') (W := 5 * W + 8) hcd.le hD0.le hx8 hacc8 hv08 hN8 hD8 hcn8 hcd8 hVa, ?_⟩
    · refine ⟨?_, ?_, ?_, ?_⟩
      · simp only [pnStepF, List.tail_cons]
        simp only [List.length_cons] at h1
        omega
      · simp only [pnStepF, List.tail_cons]
        exact (List.suffix_cons v0 vs').trans h2
      · simp only [pnStepF, List.headD_cons]
        have : 0 ≤ clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (v0 : ℤ) :=
          mul_nonneg hcl0 (by positivity)
        linarith
      · simp only [pnStepF, List.headD_cons]
        have : clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (v0 : ℤ) ≤ 8 * cd * D * V :=
          mul_le_mul hcl1 hv0V.le (by positivity) (by positivity)
        linarith
  · rintro r ⟨acc, vs⟩ hsuf ⟨h1, h2, h3, h4⟩
    have hpos : 0 ≤ 8 * cd * D * V * (r.length : ℤ) := by positivity
    have := hbig acc h3 (by linarith)
    have hvsV : valSize (encL encN vs) ≤ valSize (encL encN v) := by
      obtain ⟨t, ht⟩ := h2
      rw [← ht]
      simp only [encL, List.map_append, valSize_list, listSize_append]
      omega
    rw [valSize_encPN]
    omega
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega
  · exact ⟨hvl, List.suffix_refl v, le_refl _, by simp⟩

end PN

end F2e2e.C.Impl

namespace F2e2e.Cost.Idx

abbrev adaMuJ : ℕ := 634
abbrev adaMusMap : ℕ := 635
abbrev adaMusMapStep : ℕ := 636

end F2e2e.Cost.Idx

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The level and score bounds -/

theorem wlStep_ok {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) {x : ℤ} (hx : x ∈ g)
    {s : Option (ℤ × ℤ)} (hs : OptOK W s) : OptOK W (wlStep cn cd g x s) := by
  intro N D h
  cases s with
  | some r' => exact hs N D h
  | none =>
    simp only [wlStep] at h
    cases h1 : wlTry cn cd g (wlS cn cd x) with
    | some r'' =>
      rw [h1] at h
      exact wlTry_bounds hW (B := wlS cn cd x) (by have := hW.S_le hx; omega) N D (h1.trans h)
    | none =>
      rw [h1] at h
      exact wlTry_bounds hW (hW.B_le hx (Or.inr rfl)) N D h

theorem foldP_wlStep_ok {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) :
    ∀ (l : List ℤ), (∀ x ∈ l, x ∈ g) → ∀ s, OptOK W s → OptOK W (foldP (wlStep cn cd g) l s)
  | [], _, _, hs => hs
  | x :: xs, hl, s, hs => by
    simp only [foldP]
    exact foldP_wlStep_ok hW xs (fun y hy => hl y (List.mem_cons_of_mem _ hy)) _
      (wlStep_ok hW (hl x List.mem_cons_self) hs)

theorem wlLevel_ok {cn cd : ℤ} {g : List ℤ} {W : ℕ} (hW : WB cn cd g W) :
    OptOK W (wlLevel cn cd g) :=
  foldP_wlStep_ok hW g (fun _ h => h) none (fun _ _ h => absurd h (by simp))

/-- Stored scores have at most `adaZ + 2` bits. -/
theorem AdaOK.score_bits {A : AdaParams} {st : AdaState} (hok : AdaOK A st) :
    ∀ g ∈ st.scores, ∀ z ∈ g, bitLen z ≤ adaZ A + 2 := by
  have hTsum : st.T.sum < A.fuel := by
    have := sum_le_of_getD_le st.T A.Tmax (fun j => by
      by_cases hj : j < A.p
      · exact hok.T_le j hj
      · rw [List.getD_eq_default _ _ (by rw [hok.T_len]; omega)]
        exact Nat.zero_le _)
    unfold AdaParams.fuel
    omega
  intro g hg z hz
  have hqf := qA_add_size_fuel_le_adaZ A
  have : bitLen z ≤ A.qA + 2 + Nat.size A.fuel := by
    apply bitLen_le_of_abs_lt
    have h1 := hok.scores_le g hg z hz
    have h2 : (A.fuel : ℤ) < 2 ^ Nat.size A.fuel := by exact_mod_cast Nat.lt_size_self A.fuel
    have h3 : (st.T.sum : ℤ) < A.fuel := by exact_mod_cast hTsum
    calc |z| ≤ 4 * 2 ^ A.qA * (st.T.sum : ℤ) := h1
      _ < 4 * 2 ^ A.qA * 2 ^ Nat.size A.fuel := by
          apply mul_lt_mul_of_pos_left (h3.trans h2); positivity
      _ = 2 ^ (A.qA + 2 + Nat.size A.fuel) := by rw [pow_add, pow_add]; ring
  omega

/-- The water-level budget of block `j < p`. -/
theorem wb_block {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {j : ℕ} (hj : j < A.p) :
    WB (scoreScale A).num ((scoreScale A).den : ℤ) (st.scores.getD j []) (adaZ A + 2) := by
  have hjs : j < st.scores.length := by rw [hok.scores_len]; exact hj
  have hmem : st.scores.getD j [] ∈ st.scores := by
    rw [List.getD_eq_getElem _ _ hjs]; exact List.getElem_mem hjs
  refine ⟨by exact_mod_cast (scoreScale A).den_pos, ?_, ?_, hok.score_bits _ hmem, ?_⟩
  · unfold bitLen; have := size_cnum_le_adaZ A; omega
  · rw [bitLen_natCast]; have := size_cden_le_adaZ A; omega
  · rw [hok.scores_blk j hj]
    have h1 : A.blockSizes.getD j 0 ≤ A.N := getD_le_sum _ _
    have := Nat.size_le_size h1
    have := size_N_le_adaZ A
    omega

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## The prediction pair of block `j`: `adaMuJ` -/

/-- The fixed data of the predictions: `[scores, vals, 2^{qA}, cn, cd, p]`. -/
def musExtra (A : AdaParams) (scores : List (List ℤ)) (vals : List (List ℕ)) : Val :=
  Val.list [encL (encL encZ) scores, encVals vals, encN (2 ^ A.qA), Val.int (scoreScale A).num,
    Val.int ((scoreScale A).den : ℤ), encN A.p]

/-- The learned branch (environment `[[j, extra]]`). -/
def muJL : Expr :=
  eLet (eCall Idx.get (ePair (eAtN 0 (eAtN 1 (eV 0))) (eAtN 0 (eV 0))))
  (eLet (eCall Idx.get (ePair (eAtN 1 (eAtN 1 (eV 1))) (eAtN 0 (eV 1))))
  (eLet (eCall Idx.length (eV 1))
  (eLet (eCall Idx.wlLevelFold (eList [Expr.nil, eV 2,
      eList [eV 2, eAtN 3 (eAtN 1 (eV 3)), eAtN 4 (eAtN 1 (eV 3)), eV 0]]))
  (eLet (eCall Idx.pnFold (eList [eList [eLit 0, eV 2], eV 3,
      eList [eAtN 0 (eV 0), eAtN 1 (eV 0), eAtN 3 (eAtN 1 (eV 4)), eAtN 4 (eAtN 1 (eV 4))]]))
  (eList [eAtN 0 (eV 0), (ZE.mul (ZE.mul (ZE.mul (lf (eAtN 2 (eAtN 1 (eV 5)))) (lf (eV 2)))
      (lf (eAtN 4 (eAtN 1 (eV 5))))) (lf (eAtN 1 (eV 1)))).toExpr])))))

/-- The anchor branch (environment `[[j, extra]]`). -/
def muJA : Expr :=
  eLet (eCall Idx.get (ePair (eAtN 1 (eAtN 1 (eV 0))) (eAtN 0 (eV 0))))
  (eList [eCall Idx.sum (eV 0),
    (ZE.mul (lf (eAtN 2 (eAtN 1 (eV 1)))) (lf (eCall Idx.length (eV 0)))).toExpr])

/-- `adaMuJ : [j, extra] ↦ the pair of block `j``. -/
def body_muJ : Expr :=
  eIte (ZE.lt (lf (eAtN 0 (eV 0))) (lf (eAtN 5 (eAtN 1 (eV 0))))).toExpr muJL muJA

/-- The pair of block `j` (the model mapped by `musZ`). -/
def muJZ (A : AdaParams) (scores : List (List ℤ)) (vals : List (List ℕ)) (j : ℕ) : ℤ × ℤ :=
  if j < A.p then muLZ A (scores.getD j []) (vals.getD j []) else muAZ A (vals.getD j [])

theorem musZ_eq_map (A : AdaParams) (scores : List (List ℤ)) (vals : List (List ℕ)) :
    musZ A scores vals = (List.range (A.p + 1)).map (muJZ A scores vals) := rfl

/-- All routines and library functions of the predictions. -/
structure MusLibImpl (prog : List Expr) : Prop where
  list : ListLib prog
  range : prog[Idx.range]? = some body_range
  rangeStep : prog[Idx.rangeStep]? = some body_rangeStep
  sum : prog[Idx.sum]? = some body_sum
  sumStep : prog[Idx.sumStep]? = some body_sumStep
  folds : FoldLib prog
  tryR : prog[Idx.wlTryR]? = some body_wlTry
  levelFold : prog[Idx.wlLevelFold]? = some (body_foldB Idx.wlLevelStep)
  levelStep : prog[Idx.wlLevelStep]? = some (body_foldBStep Idx.wlLevelEl)
  levelEl : prog[Idx.wlLevelEl]? = some body_wlLevelEl
  pnFold : prog[Idx.pnFold]? = some (body_foldB Idx.pnStep)
  pnStep : prog[Idx.pnStep]? = some (body_foldBStep Idx.pnEl)
  pnEl : prog[Idx.pnEl]? = some body_pnEl
  muJ : prog[Idx.adaMuJ]? = some body_muJ
  musMap : prog[Idx.adaMusMap]? = some (body_mapB Idx.adaMusMapStep)
  musMapStep : prog[Idx.adaMusMapStep]? = some (body_mapBStep Idx.adaMuJ)

private theorem getD_map_lt {α β : Type} (f : α → β) (l : List α) {j : ℕ} (hj : j < l.length)
    (d : β) (d' : α) : (l.map f).getD j d = f (l.getD j d') := by
  rw [List.getD_eq_getElem _ _ (by simpa using hj), List.getElem_map,
    List.getD_eq_getElem _ _ hj]

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## Bounds of the pairs -/

private theorem predNum_bounds {cn cd N D : ℤ} (hcd : 0 ≤ cd) (hD : 0 ≤ D) {V : ℤ} (hV0 : 0 ≤ V) :
    ∀ (g : List ℤ) (v : List ℕ), (∀ y ∈ v, (y : ℤ) ≤ V) →
      0 ≤ predNum cn cd N D g v ∧ predNum cn cd N D g v ≤ g.length * (8 * cd * D * V)
  | [], v, _ => by simp [predNum]
  | x :: xs, [], _ => by
    simp only [predNum, List.zipWith_nil_right, List.sum_nil, le_refl, true_and]
    exact mul_nonneg (by positivity) (mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) hcd) hD) hV0)
  | x :: xs, y :: ys, hv => by
    obtain ⟨h1, h2⟩ := predNum_bounds hcd hD hV0 xs ys (fun z hz => hv z (List.mem_cons_of_mem _ hz))
    have hy := hv y List.mem_cons_self
    have hH : 0 ≤ 8 * cd * D := by positivity
    have hc0 := clipZ_nonneg (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
    have hc1 := clipZ_le (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
    have hy0 : (0 : ℤ) ≤ y := by positivity
    have e : predNum cn cd N D (x :: xs) (y :: ys) =
        clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) + predNum cn cd N D xs ys := by
      simp [predNum, List.zipWith_cons_cons]
    rw [e]
    have hm0 : 0 ≤ clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) := mul_nonneg hc0 hy0
    have hm1 : clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) ≤ 8 * cd * D * V :=
      mul_le_mul hc1 hy hy0 hH
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
    constructor <;> nlinarith

/-- **Bit lengths of the pair of block `j`.** -/
private theorem vals_length_getD {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ}
    (hj : j < vals.length) : (vals.getD j []).length = A.blockSizes.getD j 0 := by
  have := getD_map_lt List.length vals hj 0 []
  rw [hv.1] at this
  exact this.symm

private theorem vals_length_eq {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    vals.length = A.blockSizes.length := by
  have := congrArg List.length hv.1
  simpa using this

theorem muJZ_bits {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {vals : List (List ℕ)} (hv : ValsOKA A vals)
    {j : ℕ} (hj : j < A.p + 1) :
    bitLen (muJZ A st.scores vals j).1 ≤ 8 * (adaZ A + 2) + 8 ∧
      bitLen (muJZ A st.scores vals j).2 ≤ 8 * (adaZ A + 2) + 8 := by
  have hqA := qA_le_adaZ A
  have hNz := size_N_le_adaZ A
  unfold muJZ
  split_ifs with hjp
  · have hW := wb_block hok hpos hjp
    set W := adaZ A + 2
    have hcd := hW.cd_pos
    have hcdW := hW.cd_le
    have hnW := hW.n_cast_le
    unfold muLZ
    have hOK := wlLevel_ok hW
    cases hL : wlLevel (scoreScale A).num ((scoreScale A).den : ℤ) (st.scores.getD j []) with
    | none => simp
    | some r =>
      obtain ⟨N, D⟩ := r
      obtain ⟨hN, hD⟩ := hOK N D hL
      have hD0 : 0 ≤ D := by
        obtain ⟨N', D', hL', hD', -⟩ := wlLevel_spec (cn := (scoreScale A).num) hcd (g := st.scores.getD j [])
          (by
            intro h
            have := hpos j (by omega)
            rw [← hok.scores_blk j hjp, h] at this
            simp at this)
        rw [hL] at hL'
        simp only [Option.some.injEq, Prod.mk.injEq] at hL'
        rw [hL'.2]; exact hD'.le
      simp only
      have hvj : ∀ y ∈ vals.getD j [], (y : ℤ) ≤ 2 ^ A.qA := by
        intro y hy
        have hjv : j < vals.length := by rw [vals_length_eq hv, hbs]; omega
        rw [List.getD_eq_getElem _ _ hjv] at hy
        exact_mod_cast hv.2 _ (List.getElem_mem hjv) y hy
      obtain ⟨h1, h2⟩ := predNum_bounds (cn := (scoreScale A).num) (N := N) hcd.le hD0
        (by positivity) (st.scores.getD j []) (vals.getD j []) hvj
      have hq : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
        unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
      constructor
      · have e1 := bitLen_le_of_nonneg_le h1 h2
        have e2 := bitLen_mul_le ((st.scores.getD j []).length : ℤ) (8 * ((scoreScale A).den : ℤ) * D * 2 ^ A.qA)
        have e3 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ) * D) (2 ^ A.qA)
        have e4 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ)) D
        have e5 := bitLen_mul_le 8 ((scoreScale A).den : ℤ)
        rw [bitLen_eight] at e5
        omega
      · have e2 := bitLen_mul_le (2 ^ A.qA * ((st.scores.getD j []).length : ℤ) *
          ((scoreScale A).den : ℤ)) D
        have e3 := bitLen_mul_le (2 ^ A.qA * ((st.scores.getD j []).length : ℤ))
          ((scoreScale A).den : ℤ)
        have e4 := bitLen_mul_le ((2 : ℤ) ^ A.qA) ((st.scores.getD j []).length : ℤ)
        omega
  · unfold muAZ
    have hjv : j < vals.length := by rw [vals_length_eq hv, hbs]; omega
    have hvmem : vals.getD j [] ∈ vals := by
      rw [List.getD_eq_getElem _ _ hjv]; exact List.getElem_mem hjv
    have hvlen : (vals.getD j []).length ≤ A.N := by
      rw [vals_length_getD hv hjv]; exact getD_le_sum _ _
    have hvb : ∀ y ∈ (vals.getD j []).map (fun x : ℕ => (x : ℤ)), y ≤ 2 ^ A.qA := by
      intro y hy
      obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
      exact_mod_cast hv.2 _ hvmem x hx
    have hs0 : 0 ≤ ((vals.getD j []).map fun x : ℕ => (x : ℤ)).sum :=
      List.sum_nonneg (by intro y hy; obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy; positivity)
    have hs1 : ((vals.getD j []).map fun x : ℕ => (x : ℤ)).sum ≤
        ((vals.getD j []).length : ℤ) * 2 ^ A.qA := by
      have := List.sum_le_card_nsmul ((vals.getD j []).map fun x : ℕ => (x : ℤ)) (2 ^ A.qA) hvb
      simpa using this
    have hq : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
      unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
    have hnv : bitLen ((vals.getD j []).length : ℤ) ≤ adaZ A := by
      rw [bitLen_natCast]; exact (Nat.size_le_size hvlen).trans hNz
    constructor
    · have e1 := bitLen_le_of_nonneg_le hs0 hs1
      have e2 := bitLen_mul_le ((vals.getD j []).length : ℤ) (2 ^ A.qA)
      simp only
      omega
    · have e2 := bitLen_mul_le ((2 : ℤ) ^ A.qA) ((vals.getD j []).length : ℤ)
      simp only
      omega

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section MuJ

variable {prog : List Expr} {M : ℕ}

theorem valSize_musExtra_le {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (musExtra A st.scores vals) ≤ 3 * adaBoundA A := by
  have h1 : valSize (encL (encL encZ) st.scores) ≤ valSize (adaEnc st) :=
    (valSize_lt_of_mem (by simp [adaEnc])).le
  have h2 := valSize_adaEnc_le hok
  have h3 := valSize_encVals_le hbs hv.1 hv.2
  have hZ16 := sixteen_le_adaZ A
  have hqA := qA_le_adaZ A
  have hpZ := p_le_adaZ A
  have hcn := size_cnum_le_adaZ A
  have hcd := size_cden_le_adaZ A
  have hB : 8 * (adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    have : 8 ≤ 2 ^ 10 * (A.N + A.p + 16) := by
      have : 1 ≤ A.N + A.p + 16 := by omega
      calc 8 ≤ 2 ^ 10 * 1 := by norm_num
        _ ≤ 2 ^ 10 * (A.N + A.p + 16) := Nat.mul_le_mul_left _ this
    exact Nat.mul_le_mul_right _ this
  unfold musExtra
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen,
    Int.natAbs_natCast, Nat.size_pow]
  have := size_le_self A.p
  omega

/-- The common environment facts of `adaMuJ`. -/
theorem muJ_env {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals)
    {j : ℕ} (hj : j < A.p + 1) :
    valSize (Val.list [encN j, musExtra A st.scores vals]) ≤ 4 * adaBoundA A := by
  have h := valSize_musExtra_le hok hbs hv
  have hpZ := p_le_adaZ A
  have hZ16 := sixteen_le_adaZ A
  have hB : adaZ A + 16 ≤ adaBoundA A := by unfold adaBoundA; nlinarith
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
  have := Nat.size_le_size (show j ≤ A.p by omega)
  have := size_le_self A.p
  omega

end MuJ

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section MuJ2

variable {prog : List Expr} {M : ℕ}

private theorem adaZ16_le_bound (A : AdaParams) : adaZ A + 16 ≤ adaBoundA A := by
  have hZ16 := sixteen_le_adaZ A
  unfold adaBoundA
  have : 1 ≤ A.N + A.p + 16 := by omega
  calc adaZ A + 16 = 1 * 1 * (adaZ A + 16) := by ring
    _ ≤ 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul (by norm_num) this)

/-- **The learned branch.** -/
theorem muJL_val (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJL)
      (encPZ (muLZ A (st.scores.getD j []) (vals.getD j []))) := by
  have hW : WB (scoreScale A).num ((scoreScale A).den : ℤ) (st.scores.getD j []) (adaZ A + 2) :=
    wb_block hok hpos hj
  have hcdpos := hW.cd_pos
  have hgne : st.scores.getD j [] ≠ [] := by
    intro h
    have := hpos j (by omega)
    rw [← hok.scores_blk j hj, h] at this
    simp at this
  obtain ⟨N, D, hLv, hD0, -⟩ := wlLevel_spec (cn := (scoreScale A).num) hcdpos hgne
  obtain ⟨hNW, hDW⟩ := wlLevel_ok hW N D hLv
  have hjs : j < st.scores.length := by rw [hok.scores_len]; exact hj
  have hjv : j < vals.length := by rw [vals_length_eq hv, hbs]; omega
  have hgmem : st.scores.getD j [] ∈ st.scores := by
    rw [List.getD_eq_getElem _ _ hjs]; exact List.getElem_mem hjs
  have hvmem : vals.getD j [] ∈ vals := by
    rw [List.getD_eq_getElem _ _ hjv]; exact List.getElem_mem hjv
  have hvl : (vals.getD j []).length = (st.scores.getD j []).length := by
    rw [vals_length_getD hv hjv, hok.scores_blk j hj]
  have hvW : ∀ y ∈ vals.getD j [], bitLen (y : ℤ) ≤ adaZ A + 2 := by
    intro y hy
    have h1 := hv.2 _ hvmem y hy
    rw [bitLen_natCast]
    have h2 := Nat.size_le_size h1
    rw [Nat.size_pow] at h2
    have := qA_le_adaZ A
    omega
  -- sizes
  have hstB := valSize_adaEnc_le hok
  have hscB : valSize (encL (encL encZ) st.scores) ≤ adaBoundA A :=
    le_trans (valSize_lt_of_mem (by simp [adaEnc])).le hstB
  have hgB : valSize (encL encZ (st.scores.getD j [])) ≤ adaBoundA A := by
    have : valSize (encL encZ (st.scores.getD j [])) < valSize (encL (encL encZ) st.scores) :=
      valSize_lt_of_mem (List.mem_map.mpr ⟨_, hgmem, rfl⟩)
    omega
  have hvsB := valSize_encVals_le hbs hv.1 hv.2
  have hvB : valSize (encL encN (vals.getD j [])) ≤ adaBoundA A := by
    have : valSize (encL encN (vals.getD j [])) < valSize (encVals vals) := by
      rw [encVals_eq]; exact valSize_lt_of_mem (List.mem_map.mpr ⟨_, hvmem, rfl⟩)
    omega
  have hZB := adaZ16_le_bound A
  have henvB := muJ_env hok hbs hv (j := j) (by omega)
  set a := Val.list [encN j, musExtra A st.scores vals] with ha
  have haM : valSize a ≤ M := by omega
  have hexM : valSize (musExtra A st.scores vals) ≤ M := by
    have := valSize_musExtra_le hok hbs hv; omega
  -- step 1: the scores of block `j`
  have lj : EvalsVal prog M [a] [] (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  have lsc : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 1 (eV 0))))
      (Val.list (st.scores.map (encL encZ))) := evalsVal_at2 rfl haM rfl rfl
  have hp1 := EvalsVal.pair lsc lj (by
    have : valSize (Val.list (st.scores.map (encL encZ))) = valSize (encL (encL encZ) st.scores) := rfl
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at this ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h1 := get_val hL.list (l := st.scores.map (encL encZ)) (n := j) hp1 (by
    unfold S_get
    have : valSize (Val.list (st.scores.map (encL encZ))) = valSize (encL (encL encZ) st.scores) := rfl
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [getD_map_lt (encL encZ) st.scores hjs (Val.int 0) []] at h1
  refine EvalsVal.letE h1 ?_
  -- step 2: the values of block `j`
  have lvals : EvalsVal prog M [encL encZ (st.scores.getD j []), a] [] (.inl (eAtN 1 (eAtN 1 (eV 1))))
      (Val.list (vals.map fun blk => encL encN blk)) := by
    have := evalsVal_at2 (prog := prog) (M := M) (env := [encL encZ (st.scores.getD j []), a]) (k := 1)
      (l := [encN j, musExtra A st.scores vals]) rfl haM (i := 1) (l2 := [encL (encL encZ) st.scores,
        encVals vals, encN (2 ^ A.qA), Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
        encN A.p]) rfl (j := 1) rfl
    rwa [encVals_eq] at this
  have lj1 : EvalsVal prog M [encL encZ (st.scores.getD j []), a] [] (.inl (eAtN 0 (eV 1)))
      (Val.int (j : ℤ)) := evalsVal_at1 rfl haM rfl
  have hvalsM : valSize (Val.list (vals.map fun blk => encL encN blk)) ≤ adaBoundA A := by
    rw [← encVals_eq]; exact hvsB
  have hp2 := EvalsVal.pair lvals lj1 (by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hvalsM ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h2 := get_val hL.list (l := vals.map fun blk => encL encN blk) (n := j) hp2 (by
    unfold S_get
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [getD_map_lt (fun blk => encL encN blk) vals hjv (Val.int 0) []] at h2
  refine EvalsVal.letE h2 ?_
  -- step 3: the block size
  have hSl : S_length ((st.scores.getD j []).map encZ) ≤ M := by
    unfold S_length
    have e : valSize (Val.list ((st.scores.getD j []).map encZ)) =
        valSize (encL encZ (st.scores.getD j [])) := rfl
    have := hW.n_le
    simp only [List.length_map]
    omega
  have h3 := length_val (M := M) hL.list (l := (st.scores.getD j []).map encZ)
    (EvalsVal.var (env := [encL encN (vals.getD j []), encL encZ (st.scores.getD j []), a]) (i := 1)
      rfl) hSl
  rw [List.length_map] at h3
  refine EvalsVal.letE h3 ?_
  -- step 4: the water level
  set e3 := [encN (st.scores.getD j []).length, encL encN (vals.getD j []),
    encL encZ (st.scores.getD j []), a] with he3
  have lcn3 : EvalsVal prog M e3 [] (.inl (eAtN 3 (eAtN 1 (eV 3)))) (Val.int (scoreScale A).num) :=
    evalsVal_at2 rfl haM rfl rfl
  have lcd3 : EvalsVal prog M e3 [] (.inl (eAtN 4 (eAtN 1 (eV 3))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lg3 : EvalsVal prog M e3 [] (.inl (eV 2)) (encL encZ (st.scores.getD j [])) := EvalsVal.var rfl
  have ln3 : EvalsVal prog M e3 [] (.inl (eV 0)) (Val.int ((st.scores.getD j []).length : ℤ)) :=
    EvalsVal.var rfl
  have hnW := hW.n_cast_le
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hlvlArg : EvalsVal prog M e3 [] (.inl (eList [Expr.nil, eV 2,
      eList [eV 2, eAtN 3 (eAtN 1 (eV 3)), eAtN 4 (eAtN 1 (eV 3)), eV 0]]))
      (Val.list [encOptPair none, encL encZ (st.scores.getD j []),
        Val.list [encL encZ (st.scores.getD j []), Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ), Val.int ((st.scores.getD j []).length : ℤ)]]) := by
    have hin : EvalsVal prog M e3 [] (.inl (eList [eV 2, eAtN 3 (eAtN 1 (eV 3)),
        eAtN 4 (eAtN 1 (eV 3)), eV 0])) (Val.list [encL encZ (st.scores.getD j []),
          Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
          Val.int ((st.scores.getD j []).length : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons lg3 (List.Forall₂.cons lcn3 (List.Forall₂.cons lcd3
        (List.Forall₂.cons ln3 List.Forall₂.nil))))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
            have : valSize (encL encZ (st.scores.getD j [])) = 1 + listSize ((st.scores.getD j []).map encZ) := rfl
            omega)
    exact evalsVal_list (List.Forall₂.cons (EvalsVal.nil (by simp; omega))
      (List.Forall₂.cons lg3 (List.Forall₂.cons hin List.Forall₂.nil)))
      (by simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : valSize (encL encZ (st.scores.getD j [])) = 1 + listSize ((st.scores.getD j []).map encZ) := rfl
          omega)
  have h4 := evalsVal_call_det hL.levelFold hlvlArg
    (wlLevelFold_val hL.folds hL.tryR hL.levelStep hL.levelEl hW (by omega))
  rw [hLv] at h4
  refine EvalsVal.letE h4 ?_
  -- step 5: the numerator
  set e4 := encOptPair (some (N, D)) :: e3 with he4
  have lN4 : EvalsVal prog M e4 [] (.inl (eAtN 0 (eV 0))) (Val.int N) :=
    evalsVal_at1 rfl (by simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lD4 : EvalsVal prog M e4 [] (.inl (eAtN 1 (eV 0))) (Val.int D) :=
    evalsVal_at1 rfl (by simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lcn4 : EvalsVal prog M e4 [] (.inl (eAtN 3 (eAtN 1 (eV 4)))) (Val.int (scoreScale A).num) :=
    evalsVal_at2 rfl haM rfl rfl
  have lcd4 : EvalsVal prog M e4 [] (.inl (eAtN 4 (eAtN 1 (eV 4))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lv4 : EvalsVal prog M e4 [] (.inl (eV 2)) (encL encN (vals.getD j [])) := EvalsVal.var rfl
  have lg4 : EvalsVal prog M e4 [] (.inl (eV 3)) (encL encZ (st.scores.getD j [])) := EvalsVal.var rfl
  have hpnArg : EvalsVal prog M e4 [] (.inl (eList [eList [eLit 0, eV 2], eV 3,
      eList [eAtN 0 (eV 0), eAtN 1 (eV 0), eAtN 3 (eAtN 1 (eV 4)), eAtN 4 (eAtN 1 (eV 4))]]))
      (Val.list [encPN (0, vals.getD j []), encL encZ (st.scores.getD j []),
        Val.list [Val.int N, Val.int D, Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ)]]) := by
    have hpn0 : EvalsVal prog M e4 [] (.inl (eList [eLit 0, eV 2])) (encPN (0, vals.getD j [])) :=
      evalsVal_list (List.Forall₂.cons (EvalsVal.lit (by simp; omega))
        (List.Forall₂.cons lv4 List.Forall₂.nil))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]; omega)
    have hex4 : EvalsVal prog M e4 [] (.inl (eList [eAtN 0 (eV 0), eAtN 1 (eV 0),
        eAtN 3 (eAtN 1 (eV 4)), eAtN 4 (eAtN 1 (eV 4))]))
        (Val.list [Val.int N, Val.int D, Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons lN4 (List.Forall₂.cons lD4 (List.Forall₂.cons lcn4
        (List.Forall₂.cons lcd4 List.Forall₂.nil))))
        (by rw [valSize_ints4]; omega)
    exact evalsVal_list (List.Forall₂.cons hpn0 (List.Forall₂.cons lg4 (List.Forall₂.cons hex4
      List.Forall₂.nil)))
      (by rw [valSize_list3, valSize_encPN, valSize_ints4]; simp only [bitLen_zero]; omega)
  have h5 := evalsVal_call_det hL.pnFold hpnArg
    (pnFold_val hL.pnStep hL.pnEl hW hNW hD0 hDW hvl hvW (by omega))
  refine EvalsVal.letE h5 ?_
  -- step 6: the pair
  set e5 := encPN (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
    (vals.getD j []), []) :: e4 with he5
  have hpnB := predNum_bounds (cn := (scoreScale A).num) (N := N) hcdpos.le hD0.le
    (V := 2 ^ A.qA) (by positivity) (st.scores.getD j []) (vals.getD j [])
    (fun y hy => by exact_mod_cast hv.2 _ hvmem y hy)
  have hq : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
    unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
  have hqZ := qA_le_adaZ A
  have hPB : bitLen (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
      (vals.getD j [])) ≤ 8 * (adaZ A + 2) + 8 := by
    have e1 := bitLen_le_of_nonneg_le hpnB.1 hpnB.2
    have e2 := bitLen_mul_le ((st.scores.getD j []).length : ℤ)
      (8 * ((scoreScale A).den : ℤ) * D * 2 ^ A.qA)
    have e3 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ) * D) (2 ^ A.qA)
    have e4 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ)) D
    have e5 := bitLen_mul_le 8 ((scoreScale A).den : ℤ)
    rw [bitLen_eight] at e5
    omega
  have lpr : EvalsVal prog M e5 [] (.inl (eAtN 0 (eV 0)))
      (Val.int (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
        (vals.getD j []))) :=
    evalsVal_at1 rfl (by simp only [encL_nil, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lH : EvalsVal prog M e5 [] (.inl (eAtN 2 (eAtN 1 (eV 5)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_at2 rfl haM rfl rfl
  have ln5 : EvalsVal prog M e5 [] (.inl (eV 2)) (Val.int ((st.scores.getD j []).length : ℤ)) :=
    EvalsVal.var rfl
  have lcd5 : EvalsVal prog M e5 [] (.inl (eAtN 4 (eAtN 1 (eV 5))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lD5 : EvalsVal prog M e5 [] (.inl (eAtN 1 (eV 1))) (Val.int D) :=
    evalsVal_at1 rfl (by simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  set zden := ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 2 (eAtN 1 (eV 5))) ((2 ^ A.qA : ℕ) : ℤ))
      (ZE.leaf (eV 2) ((st.scores.getD j []).length : ℤ)))
      (ZE.leaf (eAtN 4 (eAtN 1 (eV 5))) ((scoreScale A).den : ℤ))) (ZE.leaf (eAtN 1 (eV 1)) D)
    with hzden
  have hcast : ((2 ^ A.qA : ℕ) : ℤ) = (2 : ℤ) ^ A.qA := by push_cast; rfl
  have hHb : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ 2 * (adaZ A + 2) := by rw [hcast, hq]; omega
  have hzE : EvalsVal prog M e5 [] (.inl zden.toExpr) (Val.int zden.val) :=
    ZE.spec' (W := 2 * (adaZ A + 2)) (by simp only [hzden, ZE.OK]; exact ⟨⟨⟨lH, ln5⟩, lcd5⟩, lD5⟩)
      (by simp only [hzden, ZE.LeafLe]; omega) (by simp only [hzden, ZE.cb]; omega)
  have hzB := ZE.bitLen_val_le_cb (e := zden) (W := 2 * (adaZ A + 2))
    (by simp only [hzden, ZE.LeafLe]; omega)
  have hzcb : zden.cb (2 * (adaZ A + 2)) ≤ 8 * (adaZ A + 2) := by simp only [hzden, ZE.cb]; omega
  have hres : encPZ (muLZ A (st.scores.getD j []) (vals.getD j [])) =
      Val.list [Val.int (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
        (vals.getD j [])), Val.int zden.val] := by
    unfold muLZ
    rw [hLv]
    simp only [encPZ, hzden, ZE.val, hcast]
  rw [hres]
  exact evalsVal_list (List.Forall₂.cons lpr (List.Forall₂.cons hzE List.Forall₂.nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)

end MuJ2

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section MuJ3

variable {prog : List Expr} {M : ℕ}

private theorem encL_encN_eq_encInts (v : List ℕ) :
    encL encN v = encInts (v.map fun x : ℕ => (x : ℤ)) := by
  simp [encL, encN, encInts, List.map_map, Function.comp_def]

/-- **The anchor branch.** -/
theorem muJA_val (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ}
    (hj : j < A.p + 1) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJA)
      (encPZ (muAZ A (vals.getD j []))) := by
  have hjv : j < vals.length := by rw [vals_length_eq hv, hbs]; exact hj
  have hvmem : vals.getD j [] ∈ vals := by
    rw [List.getD_eq_getElem _ _ hjv]; exact List.getElem_mem hjv
  have hvsB := valSize_encVals_le hbs hv.1 hv.2
  have hvB : valSize (encL encN (vals.getD j [])) ≤ adaBoundA A := by
    have : valSize (encL encN (vals.getD j [])) < valSize (encVals vals) := by
      rw [encVals_eq]; exact valSize_lt_of_mem (List.mem_map.mpr ⟨_, hvmem, rfl⟩)
    omega
  have hZB := adaZ16_le_bound A
  have henvB := muJ_env hok hbs hv hj
  set a := Val.list [encN j, musExtra A st.scores vals] with ha
  have haM : valSize a ≤ M := by omega
  have lvals : EvalsVal prog M [a] [] (.inl (eAtN 1 (eAtN 1 (eV 0))))
      (Val.list (vals.map fun blk => encL encN blk)) := by
    have := evalsVal_at2 (prog := prog) (M := M) (env := [a]) (k := 0)
      (l := [encN j, musExtra A st.scores vals]) rfl haM (i := 1) (l2 := [encL (encL encZ) st.scores,
        encVals vals, encN (2 ^ A.qA), Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
        encN A.p]) rfl (j := 1) rfl
    rwa [encVals_eq] at this
  have lj : EvalsVal prog M [a] [] (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  have hvalsM : valSize (Val.list (vals.map fun blk => encL encN blk)) ≤ adaBoundA A := by
    rw [← encVals_eq]; exact hvsB
  have hp := EvalsVal.pair lvals lj (by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hvalsM ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h1 := get_val hL.list (l := vals.map fun blk => encL encN blk) (n := j) hp (by
    unfold S_get
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [getD_map_lt (fun blk => encL encN blk) vals hjv (Val.int 0) []] at h1
  refine EvalsVal.letE h1 ?_
  -- the sum and the length
  set v := vals.getD j [] with hvdef
  have hvlen : v.length ≤ A.N := by rw [hvdef, vals_length_getD hv hjv]; exact getD_le_sum _ _
  have hvb : ∀ z ∈ v.map (fun x : ℕ => (x : ℤ)), |z| < 2 ^ (A.qA + 1) := by
    intro z hz
    obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hz
    have h1 : x ≤ 2 ^ A.qA := hv.2 _ hvmem x hx
    have h2 : (x : ℤ) < 2 ^ (A.qA + 1) := by
      have : (x : ℤ) ≤ 2 ^ A.qA := by exact_mod_cast h1
      have : (2 : ℤ) ^ A.qA < 2 ^ (A.qA + 1) := by
        rw [pow_succ]; have : (0:ℤ) < 2 ^ A.qA := by positivity
        linarith
      linarith
    rw [abs_of_nonneg (by positivity)]
    exact h2
  have hqZ := qA_le_adaZ A
  have hNZ := size_N_le_adaZ A
  set e1 := encL encN v :: [a] with he1
  have hSs : S_sum (v.map fun x : ℕ => (x : ℤ)) (A.qA + 1) ≤ M := by
    unfold S_sum
    rw [← encL_encN_eq_encInts]
    have := Nat.size_le_size hvlen
    simp only [List.length_map]
    omega
  have hs : EvalsVal prog M e1 [] (.inl (eCall Idx.sum (eV 0)))
      (Val.int (v.map fun x : ℕ => (x : ℤ)).sum) :=
    evalsVal_call_det hL.sum (EvalsVal.var (env := e1) (i := 0)
      (v := encInts (v.map fun x : ℕ => (x : ℤ))) (by rw [he1, encL_encN_eq_encInts]; rfl))
      ((sum_spec hL.sumStep (v.map fun x : ℕ => (x : ℤ)) (A.qA + 1) hvb 0).toVal.mono_M hSs)
  have hlen := length_val (M := M) hL.list (l := v.map encN) (EvalsVal.var (env := e1) (i := 0) rfl)
    (by unfold S_length
        have := Nat.size_le_size hvlen
        have : valSize (Val.list (v.map encN)) = valSize (encL encN v) := rfl
        simp only [List.length_map]
        omega)
  rw [List.length_map] at hlen
  have lH : EvalsVal prog M e1 [] (.inl (eAtN 2 (eAtN 1 (eV 1)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_at2 rfl haM rfl rfl
  set zden := ZE.mul (ZE.leaf (eAtN 2 (eAtN 1 (eV 1))) ((2 ^ A.qA : ℕ) : ℤ))
    (ZE.leaf (eCall Idx.length (eV 0)) (v.length : ℤ)) with hzden
  have hq : bitLen (((2 ^ A.qA : ℕ) : ℤ)) = A.qA + 1 := by
    rw [bitLen_natCast, Nat.size_pow]
  have hnv : bitLen (v.length : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]; exact (Nat.size_le_size hvlen).trans hNZ
  have hzE : EvalsVal prog M e1 [] (.inl zden.toExpr) (Val.int zden.val) :=
    ZE.spec' (W := adaZ A + 1) (by simp only [hzden, ZE.OK]; exact ⟨lH, hlen⟩)
      (by simp only [hzden, ZE.LeafLe]; omega) (by simp only [hzden, ZE.cb]; omega)
  have hs0 : 0 ≤ (v.map fun x : ℕ => (x : ℤ)).sum :=
    List.sum_nonneg (by intro y hy; obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy; positivity)
  have hs1 : (v.map fun x : ℕ => (x : ℤ)).sum ≤ (v.length : ℤ) * 2 ^ A.qA := by
    have := List.sum_le_card_nsmul (v.map fun x : ℕ => (x : ℤ)) (2 ^ A.qA) (by
      intro y hy
      obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
      exact_mod_cast hv.2 _ hvmem x hx)
    simpa using this
  have hq' : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
    unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
  have hsB : bitLen (v.map fun x : ℕ => (x : ℤ)).sum ≤ 2 * adaZ A + 1 := by
    have e1 := bitLen_le_of_nonneg_le hs0 hs1
    have e2 := bitLen_mul_le (v.length : ℤ) (2 ^ A.qA)
    omega
  have hres : encPZ (muAZ A v) = Val.list [Val.int (v.map fun x : ℕ => (x : ℤ)).sum,
      Val.int zden.val] := by
    simp only [encPZ, muAZ, hzden, ZE.val]
    push_cast
    rfl
  rw [hres]
  have hzB := ZE.bitLen_val_le_cb (e := zden) (W := adaZ A + 1)
    (by simp only [hzden, ZE.LeafLe]; omega)
  have hzcb : zden.cb (adaZ A + 1) ≤ 2 * adaZ A + 2 := by simp only [hzden, ZE.cb]; omega
  exact evalsVal_list (List.Forall₂.cons hs (List.Forall₂.cons hzE List.Forall₂.nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)

/-- **The pair of block `j`.** -/
theorem muJ_val (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p + 1)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl body_muJ)
      (encPZ (muJZ A st.scores vals j)) := by
  have hZB := adaZ16_le_bound A
  have henvB := muJ_env hok hbs hv hj
  have haM : valSize (Val.list [encN j, musExtra A st.scores vals]) ≤ M := by omega
  have lj : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] []
      (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) := evalsVal_at1 rfl haM rfl
  have lp : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] []
      (.inl (eAtN 5 (eAtN 1 (eV 0)))) (Val.int (A.p : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  set c := ZE.lt (ZE.leaf (eAtN 0 (eV 0)) (j : ℤ)) (ZE.leaf (eAtN 5 (eAtN 1 (eV 0))) (A.p : ℤ))
    with hc
  have hpZ := p_le_adaZ A
  have hcE : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl c.toExpr)
      (Val.int c.val) :=
    ZE.spec' (W := adaZ A) (by simp only [hc, ZE.OK]; exact ⟨lj, lp⟩)
      (by
        simp only [hc, ZE.LeafLe, bitLen_natCast]
        have := Nat.size_le_size (show j ≤ A.p by omega)
        have := size_le_self A.p
        omega)
      (by simp only [hc, ZE.cb]; omega)
  unfold muJZ
  by_cases hjp : j < A.p
  · rw [if_pos hjp]
    have hv1 : c.val ≠ 0 := by simp [hc, ZE.val, hjp]
    exact EvalsVal.ite_true hcE hv1 (muJL_val hL hok hbs hpos hv hjp hM)
  · rw [if_neg hjp]
    have hv0 : c.val = 0 := by simp [hc, ZE.val, hjp]
    exact EvalsVal.ite_false hcE hv0 (muJA_val hL hok hbs hv hj hM)

end MuJ3

end F2e2e.C.Impl

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-! ## `adaMusR` -/

/-- **`adaMusR`** (implementation): `[pub, scores, vals] ↦ encL encPZ (musZ A st.scores vals)`. -/
def body_adaMusRImpl : Expr :=
  eCall Idx.adaMusMap (eList [
    eCall Idx.range (ZE.add (lf (eAtN 0 (eAtN 0 (eV 0)))) (ZE.lit 1)).toExpr,
    eList [eAtN 1 (eV 0), eAtN 2 (eV 0), eAtN 8 (eAtN 0 (eV 0)),
      eAtN 0 (eAtN 11 (eAtN 0 (eV 0))), eAtN 1 (eAtN 11 (eAtN 0 (eV 0))),
      eAtN 0 (eAtN 0 (eV 0))]])

section MusR

variable {prog : List Expr} {M : ℕ}

private theorem encInts_range_eq (n : ℕ) :
    encInts ((List.range n).map fun i : ℕ => (i : ℤ)) = encL encN (List.range n) := by
  simp [encL, encN, encInts, List.map_map, Function.comp_def]

/-- **Spec of `adaMusR`.** -/
theorem adaMusRImpl_val (hL : MusLibImpl prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusRImpl) (encL encPZ (musZ A st.scores vals)) := by
  have hZB := adaZ16_le_bound A
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hstB := valSize_adaEnc_le hok
  have hscB : valSize (encL (encL encZ) st.scores) ≤ adaBoundA A :=
    le_trans (valSize_lt_of_mem (by simp [adaEnc])).le hstB
  have hvsB := valSize_encVals_le hbs hv.1 hv.2
  have hpZ := p_le_adaZ A
  set a := Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals] with ha
  have haM : valSize a ≤ M := by
    simp only [ha, valSize_list, listSize_cons, listSize_nil]
    omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  -- pub fields
  have lp : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 0 (eV 0)))) (encN A.p) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have lH : EvalsVal prog M [a] [] (.inl (eAtN 8 (eAtN 0 (eV 0)))) (encN (2 ^ A.qA)) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have lc : EvalsVal prog M [a] [] (.inl (eAtN 11 (eAtN 0 (eV 0)))) (encQ (scoreScale A)) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have hcM : valSize (encQ (scoreScale A)) ≤ M :=
    le_trans (valSize_le_of_getElem? (l := pubFields A) (n := 11) rfl) hpubM
  have lcn : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 11 (eAtN 0 (eV 0)))))
      (Val.int (scoreScale A).num) := evalsVal_atN' lc hcM rfl
  have lcd : EvalsVal prog M [a] [] (.inl (eAtN 1 (eAtN 11 (eAtN 0 (eV 0)))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_atN' lc hcM rfl
  have lsc : EvalsVal prog M [a] [] (.inl (eAtN 1 (eV 0))) (encL (encL encZ) st.scores) :=
    evalsVal_at1 rfl haM rfl
  have lvs : EvalsVal prog M [a] [] (.inl (eAtN 2 (eV 0))) (encVals vals) :=
    evalsVal_at1 rfl haM rfl
  -- the extra record
  have hexB := valSize_musExtra_le hok hbs hv
  have hex : EvalsVal prog M [a] [] (.inl (eList [eAtN 1 (eV 0), eAtN 2 (eV 0),
      eAtN 8 (eAtN 0 (eV 0)), eAtN 0 (eAtN 11 (eAtN 0 (eV 0))), eAtN 1 (eAtN 11 (eAtN 0 (eV 0))),
      eAtN 0 (eAtN 0 (eV 0))])) (musExtra A st.scores vals) :=
    evalsVal_list (List.Forall₂.cons lsc (List.Forall₂.cons lvs (List.Forall₂.cons lH
      (List.Forall₂.cons lcn (List.Forall₂.cons lcd (List.Forall₂.cons lp List.Forall₂.nil))))))
      (by unfold musExtra at hexB; omega)
  -- size facts
  have hB1 : (A.N + A.p + 16) * (adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA; nlinarith
  have hsp1 : Nat.size (A.p + 1) ≤ A.p + 1 := size_le_self _
  have hPZ : (A.p + 1) * (adaZ A + 16) ≤ adaBoundA A := le_trans (Nat.mul_le_mul_right _ (by omega)) hB1
  have hPZ2 : (A.p + 2) * (adaZ A + 16) ≤ adaBoundA A :=
    le_trans (Nat.mul_le_mul_right _ (by omega)) hB1
  have hPZ3 : (A.p + 2) * (adaZ A + 16) = (A.p + 1) * (adaZ A + 16) + (adaZ A + 16) := by ring
  have hrangeV : valSize (encL encN (List.range (A.p + 1))) ≤ adaBoundA A := by
    have := valSize_encL_le encN (List.range (A.p + 1)) (adaZ A + 2) (fun i hi => by
      rw [valSize_encN]
      have := Nat.size_le_size (show i ≤ A.p + 1 by have := List.mem_range.mp hi; omega)
      omega)
    simp only [List.length_range] at this
    have : (A.p + 1) * (adaZ A + 2 + 1) ≤ (A.p + 1) * (adaZ A + 16) := Nat.mul_le_mul_left _ (by omega)
    omega
  -- the index list `0..p`
  set zp := ZE.add (ZE.leaf (eAtN 0 (eAtN 0 (eV 0))) (A.p : ℤ)) (ZE.lit 1) with hzp
  have hzpOK : zp.OK prog M [a] := by simp only [hzp, ZE.OK]; exact ⟨lp, trivial⟩
  have hspZ : bitLen (A.p : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]; exact (size_le_self A.p).trans hpZ
  have hzpL : zp.LeafLe (adaZ A) := by simp only [hzp, ZE.LeafLe]; exact ⟨hspZ, trivial⟩
  have hzpC : zp.cb (adaZ A) + 1 ≤ M := by simp only [hzp, ZE.cb, bitLen_one]; omega
  have hzpE : EvalsVal prog M [a] [] (.inl zp.toExpr) (Val.int zp.val) := ZE.spec' hzpOK hzpL hzpC
  have hzpv : zp.val = ((A.p + 1 : ℕ) : ℤ) := by simp [hzp, ZE.val]
  rw [hzpv] at hzpE
  have hrange := evalsVal_call_det hL.range hzpE
    ((range_spec hL.rangeStep (A.p + 1) 0).toVal.mono_M (by
      unfold S_range
      have : (A.p + 1) * (Nat.size (A.p + 1) + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
        Nat.mul_le_mul_left _ (by omega)
      omega))
  rw [encInts_range_eq] at hrange
  -- the map
  have hmap := mapB_impl hL.musMapStep hL.muJ hL.list.reverse hL.list.revAppendStep encN encPZ
    (musExtra A st.scores vals) (fun j => BitProg.pure (muJZ A st.scores vals j))
    (List.range (A.p + 1)) (16 * (adaZ A + 2) + 21)
    (fun j hj => Implements.of_det (muJ_val hL hok hbs hpos hv (List.mem_range.mp hj) hM))
    (fun j hj bits b hb => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hb
      obtain ⟨h1, h2⟩ := muJZ_bits hok hbs hpos hv (List.mem_range.mp hj)
      rw [show muJZ A st.scores vals j = ((muJZ A st.scores vals j).1, (muJZ A st.scores vals j).2)
        from rfl, valSize_encPZ]
      omega)
    (by
      unfold mapB_M
      simp only [List.length_range]
      have : (A.p + 1) * (16 * (adaZ A + 2) + 21 + 1) ≤ 16 * ((A.p + 1) * (adaZ A + 16)) := by
        nlinarith
      omega)
  rw [mapB_pure] at hmap
  have := evalsVal_call_det hL.musMap
    (evalsVal_list (List.Forall₂.cons hrange (List.Forall₂.cons hex List.Forall₂.nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil]
      have : valSize (musExtra A st.scores vals) ≤ 3 * adaBoundA A := hexB
      omega))
    (hmap [] _ rfl)
  rw [musZ_eq_map]
  exact this

end MusR

end F2e2e.C.Impl
