import F2e2e.Cost.Lib.Get

/-!
# HASH area (DSL): indices, expression helpers, bodies, the library predicate

Port of cut2's `Cut2/Cost/Hash/Basic.lean` (namespace/imports renamed; the cut2-specific bodies of
the fine sketch — `polyHash`, `pairCodeT`, `pairBucket`, `pairSign`, `bitsNum`, `seedCoeffs`,
`fineHashAt`, `fineSignAt` — are dropped). Idx range 150–249 (`F2e2e/Cost/Index.lean`). Reference
functions are the Lean definitions of `F2e2e/Lib/Hash/Defs.lean` (cut2's ℕ bit-pattern
representation, verbatim):

| index | body | input | output (reference) |
|---|---|---|---|
| 150/151 | `body_xorNat` / step | `[a, b]` | `a ^^^ b` |
| 152/153 | `body_pow2` / step | `m` | `2 ^ m` |
| 154/155 | `body_sizeNat` / step | `n` | `Nat.size n` |
| 156/157 | `body_clmul` / step | `[a, b]` | `Hash.clmul a b` |
| 158/159 | `body_pmodDeg` / step | `[d, p, a]` | `Hash.pmodDeg d p a` |
| 160 | `body_gfMul` | `[q, p, x, y]` | `Hash.gfMul q p x y` |
| 165/166 | `body_irrTest` / step | `[q, n]` | `encB (Hash.irrTest q n)` |
| 167/168 | `body_irrPoly` / step | `q` | `Hash.irrPoly q` |

Horner evaluation and signs (Idx 174–177) are in `F2e2e/C/Impl/HashHorner.lean`, the zero-fingerprint
arithmetic (Idx 200–206) in `F2e2e/C/Impl/Fingerprint.lean` (W2's range is 150–249, with 450–549 spare;
the fingerprint update `fpUpdate = 206` is fixed by `F2e2e/C/Impl/W6Contracts.lean`).
All integers are natural numbers (`encN`). Loops follow `notes/DSL_CONVENTION.md` (state lists,
`[0, result]` / `[1, state']`).
-/

namespace F2e2e.Cost.Idx

/-- `xorNat : [a, b] ↦ a ^^^ b`. -/
abbrev xorNat : ℕ := 150
abbrev xorNatStep : ℕ := 151
/-- `pow2H : m ↦ 2 ^ m` (HASH copy; ARITH has its own `Idx.pow2`). -/
abbrev pow2H : ℕ := 152
abbrev pow2HStep : ℕ := 153
/-- `sizeNat : n ↦ Nat.size n`. -/
abbrev sizeNat : ℕ := 154
abbrev sizeNatStep : ℕ := 155
/-- `clmul : [a, b] ↦ Hash.clmul a b`. -/
abbrev clmul : ℕ := 156
abbrev clmulStep : ℕ := 157
/-- `pmodDeg : [d, p, a] ↦ Hash.pmodDeg d p a`. -/
abbrev pmodDeg : ℕ := 158
abbrev pmodDegStep : ℕ := 159
/-- `gfMul : [q, p, x, y] ↦ Hash.gfMul q p x y`. -/
abbrev gfMul : ℕ := 160
/-- `irrTest : [q, n] ↦ encB (Hash.irrTest q n)`. -/
abbrev irrTest : ℕ := 165
abbrev irrTestStep : ℕ := 166
/-- `irrPoly : q ↦ Hash.irrPoly q`. -/
abbrev irrPoly : ℕ := 167
abbrev irrPolyStep : ℕ := 168

end F2e2e.Cost.Idx

namespace F2e2e.Cost.HashDSL

/-! ### Expression shorthands (plain definitions) -/

/-- Variable `i`. -/
abbrev eV (i : ℕ) : Expr := Expr.var i
/-- Literal. -/
abbrev eLit (z : ℤ) : Expr := Expr.lit z
/-- `head`. -/
abbrev eHd (e : Expr) : Expr := Expr.un UnOp.head e
/-- `tail`. -/
abbrev eTl (e : Expr) : Expr := Expr.un UnOp.tail e
/-- Element `1` of a list. -/
abbrev eAt1 (e : Expr) : Expr := eHd (eTl e)
/-- Element `2` of a list. -/
abbrev eAt2 (e : Expr) : Expr := eHd (eTl (eTl e))
/-- Element `3` of a list. -/
abbrev eAt3 (e : Expr) : Expr := eHd (eTl (eTl (eTl e)))
/-- Element `4` of a list. -/
abbrev eAt4 (e : Expr) : Expr := eHd (eTl (eTl (eTl (eTl e))))
/-- Element `5` of a list. -/
abbrev eAt5 (e : Expr) : Expr := eHd (eTl (eTl (eTl (eTl (eTl e)))))
abbrev eAdd (a b : Expr) : Expr := Expr.bin BinOp.add a b
abbrev eSub (a b : Expr) : Expr := Expr.bin BinOp.sub a b
abbrev eMul (a b : Expr) : Expr := Expr.bin BinOp.mul a b
abbrev eDiv (a b : Expr) : Expr := Expr.bin BinOp.div a b
abbrev eMod (a b : Expr) : Expr := Expr.bin BinOp.mod a b
abbrev eLt (a b : Expr) : Expr := Expr.bin BinOp.lt a b
abbrev eEq (a b : Expr) : Expr := Expr.bin BinOp.eq a b
abbrev eCons (a b : Expr) : Expr := Expr.bin BinOp.cons a b
/-- The list `[e₀, …, e_k]`. -/
@[reducible] def eList : List Expr → Expr
  | [] => Expr.nil
  | e :: es => eCons e (eList es)
abbrev eIte (c t f : Expr) : Expr := Expr.ite c t f
abbrev eLet (a b : Expr) : Expr := Expr.letE a b
abbrev eCall (i : ℕ) (a : Expr) : Expr := Expr.call i a
abbrev eLoop (i : ℕ) (a : Expr) : Expr := Expr.loop i a

/-! ### Bit operations -/

/-- Step of `xorNat`; state `[a, b, res, pw]`: stop with `res` when `a + b = 0`, else
`[a / 2, b / 2, res + (a % 2 ≠ b % 2) · pw, 2 pw]`. -/
def body_xorNatStep : Expr :=
  eLet (eHd (eV 0))                                         -- a    [a, S]
    (eLet (eAt1 (eV 1))                                     -- b    [b, a, S]
      (eLet (eAt2 (eV 2))                                   -- res  [res, b, a, S]
        (eLet (eAt3 (eV 3))                                 -- pw   [pw, res, b, a, S]
          (eIte (eEq (eAdd (eV 3) (eV 2)) (eLit 0))
            (ePair (eLit 0) (eV 1))
            (ePair (eLit 1)
              (eList [eDiv (eV 3) (eLit 2), eDiv (eV 2) (eLit 2),
                eIte (eEq (eMod (eV 3) (eLit 2)) (eMod (eV 2) (eLit 2))) (eV 1)
                  (eAdd (eV 1) (eV 0)),
                eMul (eV 0) (eLit 2)]))))))

/-- `xorNat : [a, b] ↦ a ^^^ b` (loop from `[a, b, 0, 1]`). -/
def body_xorNat : Expr :=
  eLoop Idx.xorNatStep (eList [eHd (eV 0), eAt1 (eV 0), eLit 0, eLit 1])

/-- Step of `pow2`; state `[m, acc]`: stop with `acc` when `m = 0`, else `[m - 1, 2 acc]`. -/
def body_pow2Step : Expr :=
  eLet (eHd (eV 0))                                         -- m    [m, S]
    (eLet (eAt1 (eV 1))                                     -- acc  [acc, m, S]
      (eIte (eEq (eV 1) (eLit 0))
        (ePair (eLit 0) (eV 0))
        (ePair (eLit 1) (ePair (eSub (eV 1) (eLit 1)) (eMul (eV 0) (eLit 2))))))

/-- `pow2 : m ↦ 2 ^ m` (loop from `[m, 1]`). -/
def body_pow2 : Expr := eLoop Idx.pow2HStep (ePair (eV 0) (eLit 1))

/-- Step of `sizeNat`; state `[n, c]`: stop with `c` when `n = 0`, else `[n / 2, c + 1]`. -/
def body_sizeNatStep : Expr :=
  eLet (eHd (eV 0))                                         -- n    [n, S]
    (eLet (eAt1 (eV 1))                                     -- c    [c, n, S]
      (eIte (eEq (eV 1) (eLit 0))
        (ePair (eLit 0) (eV 0))
        (ePair (eLit 1) (ePair (eDiv (eV 1) (eLit 2)) (eAdd (eV 0) (eLit 1))))))

/-- `sizeNat : n ↦ Nat.size n` (loop from `[n, 0]`). -/
def body_sizeNat : Expr := eLoop Idx.sizeNatStep (ePair (eV 0) (eLit 0))

/-! ### GF(2)[x] arithmetic -/

/-- Step of `clmul`; state `[a, b, res]`: stop with `res` when `a = 0`, else
`[a / 2, 2 b, if a % 2 = 1 then res ^^^ b else res]`. -/
def body_clmulStep : Expr :=
  eLet (eHd (eV 0))                                         -- a    [a, S]
    (eLet (eAt1 (eV 1))                                     -- b    [b, a, S]
      (eLet (eAt2 (eV 2))                                   -- res  [res, b, a, S]
        (eIte (eEq (eV 2) (eLit 0))
          (ePair (eLit 0) (eV 0))
          (ePair (eLit 1)
            (eList [eDiv (eV 2) (eLit 2), eMul (eV 1) (eLit 2),
              eIte (eEq (eMod (eV 2) (eLit 2)) (eLit 1))
                (eCall Idx.xorNat (ePair (eV 0) (eV 1))) (eV 0)])))))

/-- `clmul : [a, b] ↦ Hash.clmul a b` (loop from `[a, b, 0]`). -/
def body_clmul : Expr :=
  eLoop Idx.clmulStep (eList [eHd (eV 0), eAt1 (eV 0), eLit 0])

/-- Step of `pmodDeg` (one step of `Hash.reduceTop`); state `[k, a, t, pk]` with
`t = 2^(d+k)`, `pk = 2^k p`: stop with `a` when `k = 0`, else with `t' = t / 2`, `pk' = pk / 2`:
`[k - 1, if (a / t') % 2 = 1 then a ^^^ pk' else a, t', pk']`. -/
def body_pmodDegStep : Expr :=
  eLet (eHd (eV 0))                                         -- k    [k, S]
    (eLet (eAt1 (eV 1))                                     -- a    [a, k, S]
      (eLet (eDiv (eAt2 (eV 2)) (eLit 2))                   -- t'   [t', a, k, S]
        (eLet (eDiv (eAt3 (eV 3)) (eLit 2))                 -- pk'  [pk', t', a, k, S]
          (eIte (eEq (eV 3) (eLit 0))
            (ePair (eLit 0) (eV 2))
            (ePair (eLit 1)
              (eList [eSub (eV 3) (eLit 1),
                eIte (eEq (eMod (eDiv (eV 2) (eV 1)) (eLit 2)) (eLit 1))
                  (eCall Idx.xorNat (ePair (eV 2) (eV 0))) (eV 2),
                eV 1, eV 0]))))))

/-- `pmodDeg : [d, p, a] ↦ Hash.pmodDeg d p a`: `K = Nat.size a - d`, then the loop from
`[K, a, 2^(d+K), 2^K p]`. -/
def body_pmodDeg : Expr :=
  eLet (eHd (eV 0))                                         -- d    [d, X]
    (eLet (eAt1 (eV 1))                                     -- p    [p, d, X]
      (eLet (eAt2 (eV 2))                                   -- a    [a, p, d, X]
        (eLet (eCall Idx.sizeNat (eV 0))                    -- sz   [sz, a, p, d, X]
          (eLet (eIte (eLt (eV 0) (eV 3)) (eLit 0) (eSub (eV 0) (eV 3)))   -- K [K, sz, a, p, d, X]
            (eLoop Idx.pmodDegStep
              (eList [eV 0, eV 2, eCall Idx.pow2H (eAdd (eV 4) (eV 0)),
                eMul (eCall Idx.pow2H (eV 0)) (eV 3)]))))))

/-- `gfMul : [q, p, x, y] ↦ Hash.gfMul q p x y = pmodDeg q p (clmul x y)`. -/
def body_gfMul : Expr :=
  eLet (eCall Idx.clmul (ePair (eAt2 (eV 0)) (eAt3 (eV 0))))   -- c   [c, X]
    (eCall Idx.pmodDeg (eList [eHd (eV 1), eAt1 (eV 1), eV 0]))

/-! ### Irreducible polynomials -/

/-- Step of `irrTest`; state `[cnt, m, n]` (`cnt` divisors left, current divisor `m`): stop with
`1` when `cnt = 0`, stop with `0` when `pmodDeg (size m - 1) m n = 0`, else `[cnt - 1, m + 1, n]`. -/
def body_irrTestStep : Expr :=
  eLet (eHd (eV 0))                                         -- cnt  [cnt, S]
    (eLet (eAt1 (eV 1))                                     -- m    [m, cnt, S]
      (eLet (eAt2 (eV 2))                                   -- n    [n, m, cnt, S]
        (eIte (eEq (eV 2) (eLit 0))
          (ePair (eLit 0) (eLit 1))
          (eIte (eEq (eCall Idx.pmodDeg
                (eList [eSub (eCall Idx.sizeNat (eV 1)) (eLit 1), eV 1, eV 0])) (eLit 0))
            (ePair (eLit 0) (eLit 0))
            (ePair (eLit 1) (eList [eSub (eV 2) (eLit 1), eAdd (eV 1) (eLit 1), eV 0]))))))

/-- `irrTest : [q, n] ↦ encB (Hash.irrTest q n)` (loop from `[2^(q/2+1) - 2, 2, n]`). -/
def body_irrTest : Expr :=
  eLoop Idx.irrTestStep
    (eList [eSub (eCall Idx.pow2H (eAdd (eDiv (eHd (eV 0)) (eLit 2)) (eLit 1))) (eLit 2),
      eLit 2, eAt1 (eV 0)])

/-- Step of `irrPoly` (`Hash.searchFrom (irrTest q)`); state `[s, k, q]`: stop with `s` when
`k = 0` or `irrTest q s`, else `[s + 1, k - 1, q]`. -/
def body_irrPolyStep : Expr :=
  eLet (eHd (eV 0))                                         -- s    [s, S]
    (eLet (eAt1 (eV 1))                                     -- k    [k, s, S]
      (eLet (eAt2 (eV 2))                                   -- q    [q, k, s, S]
        (eIte (eEq (eV 1) (eLit 0))
          (ePair (eLit 0) (eV 2))
          (eIte (eEq (eCall Idx.irrTest (ePair (eV 0) (eV 2))) (eLit 1))
            (ePair (eLit 0) (eV 2))
            (ePair (eLit 1) (eList [eAdd (eV 2) (eLit 1), eSub (eV 1) (eLit 1), eV 0]))))))

/-- `irrPoly : q ↦ Hash.irrPoly q` (loop from `[2^q, 2^q, q]`). -/
def body_irrPoly : Expr :=
  eLet (eCall Idx.pow2H (eV 0))                              -- t    [t, q]
    (eLoop Idx.irrPolyStep (eList [eV 0, eV 0, eV 1]))

/-! ### The library predicate -/

/-- A program containing all bodies of the HASH area. -/
structure HashLib (prog : List Expr) : Prop where
  xorNat : prog[Idx.xorNat]? = some body_xorNat
  xorNatStep : prog[Idx.xorNatStep]? = some body_xorNatStep
  pow2 : prog[Idx.pow2H]? = some body_pow2
  pow2Step : prog[Idx.pow2HStep]? = some body_pow2Step
  sizeNat : prog[Idx.sizeNat]? = some body_sizeNat
  sizeNatStep : prog[Idx.sizeNatStep]? = some body_sizeNatStep
  clmul : prog[Idx.clmul]? = some body_clmul
  clmulStep : prog[Idx.clmulStep]? = some body_clmulStep
  pmodDeg : prog[Idx.pmodDeg]? = some body_pmodDeg
  pmodDegStep : prog[Idx.pmodDegStep]? = some body_pmodDegStep
  gfMul : prog[Idx.gfMul]? = some body_gfMul
  irrTest : prog[Idx.irrTest]? = some body_irrTest
  irrTestStep : prog[Idx.irrTestStep]? = some body_irrTestStep
  irrPoly : prog[Idx.irrPoly]? = some body_irrPoly
  irrPolyStep : prog[Idx.irrPolyStep]? = some body_irrPolyStep

end F2e2e.Cost.HashDSL
