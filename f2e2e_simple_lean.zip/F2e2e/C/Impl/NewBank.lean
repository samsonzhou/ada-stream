import F2e2e.C.Impl.NewBankSize

/-!
# W3: bank creation and the fingerprint seed — entry routines and the W3 contract

Owner: W3 (4a7299ed). The two contracted routines of `F2e2e.C.Impl.W3Contract`
(`F2e2e/C/Impl/W6Contracts.lean`):

| idx | body | input | output (reference) |
|---|---|---|---|
| 550 | `W3.body_newBank` | `encStreamParams P` | `encBank R.enc` of `newBank P` (C-ALG, `Bank.lean`) |
| 551 | `W3.body_fpSeed` | `encStreamParams P` | `encN` of `fpSeedProg P` (C-ALG, `Fingerprint.lean`) |

`newBank P` (Algorithm `R:alg:regularized-norm-bank`, `parts/partIII.tex` L204–207): the ADA sample
blocks `S_0, …, S_p` (`sampleBlocks`, sizes `(bankAda P).blockSizes` from W4's `adaBlockSizes`), then
`R_max` reserved coarse groups of `g` subgroups of `32` fresh rows (`sampleList`³), then a fresh ADA
state (W4's `adaInit` on W4's `adaPub`), in this order of fresh bits. Rows: `2s` draws of `w` fresh
bits each (`P.s`, `P.w` from W1's `ps`, `pw`), zero counters (`F2e2e/C/Impl/SamplerRows.lean`).

`fpSeedProg P` (Algorithm `R:alg:zero-fingerprint`, `parts/partII.tex` L219): `P.seedTrials` trials of
`⌈log₂ q⌉` fresh bits (W1's `pq`, `pSeedTrials`; the library `clog2`), the first value `< q`, or `0`
(`F2e2e/C/Impl/SamplerFp.lean`).

Main theorem: `F2e2e.C.Impl.w3Contract : R.Valid → W3Lib prog → W1Contract R prog M →
W4Contract R prog M → W3Contract R prog M`. Every produced value is bounded by `Mv R P` (generic space
theorem): the fresh bank by C-SPACE's `bankSizeBound` (`final_le_NB`), all temporaries by
`2^8 · bankSizeBound` or `2^10 ℒ` (`F2e2e/C/Impl/NewBankSize.lean`).
-/

namespace F2e2e.C.Impl

open F2e2e F2e2e.Cost F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.B

namespace W3

/-! ## Bodies -/

/-- `fpSeed : encStreamParams P ↦ (rejectUniform q ⌈log₂ q⌉ seedTrials).getD 0`. -/
def body_fpSeed : Expr :=
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pq (Expr.var 0))                         -- q; [q, par]
    (Expr.letE (Expr.call F2e2e.Cost.Idx.clog2 (Expr.var 0))                      -- k; [k, q, par]
      (Expr.letE (Expr.call F2e2e.C.Impl.Idx.pSeedTrials (Expr.var 2))            -- r; [r, k, q, par]
        (Expr.loop Idx.fpSeedStep (Arith.eTriple (Expr.var 0) (Expr.var 2) (Expr.var 1)))))

/-- `newBank : encStreamParams P ↦ encBank R.enc (newBank P)`. -/
def body_newBank : Expr :=
  Expr.letE (Expr.call F2e2e.C.Impl.Idx.pw (Expr.var 0))                         -- w     [w, par]
  (Expr.letE (Expr.call F2e2e.C.Impl.Idx.ps (Expr.var 1))                        -- s     [s, w, par]
  (Expr.letE (ePair (Expr.bin BinOp.add (Expr.var 0) (Expr.var 0)) (Expr.var 1)) -- nw = [2s, w]
  (Expr.letE (Expr.call F2e2e.C.Impl.Idx.adaBlockSizes (Expr.var 3))             -- bs
  (Expr.letE (Expr.call F2e2e.C.Impl.Idx.pgCoarse (Expr.var 4))                  -- g
  (Expr.letE (Expr.call F2e2e.C.Impl.Idx.pRmax (Expr.var 5))                     -- Rm
  (Expr.letE (Expr.call Idx.blocksMap (ePair (Expr.var 2) (Expr.var 3)))         -- ada
  (Expr.letE (Expr.call Idx.coarseRep                                            -- coarse
      (ePair (Expr.var 1) (ePair (Expr.var 2) (ePair (Expr.lit 32) (Expr.var 4)))))
  (Expr.letE (Expr.call F2e2e.C.Impl.Idx.adaInit
      (Expr.call F2e2e.C.Impl.Idx.adaPub (Expr.var 8)))                          -- st
  (Arith.eTriple (Expr.var 2) (Expr.var 1) (Expr.var 0))))))))))

/-- The W3 routines as table entries `(index, body)` (for `mkProg`; the library routines they call
are DSL-CALC's: `readNat` 92/93, `clog2` 102/103, `reverse` 5, `revAppendStep` 4). -/
def w3Table : List (ℕ × Expr) :=
  [(F2e2e.C.Impl.Idx.newBank, body_newBank), (F2e2e.C.Impl.Idx.fpSeed, body_fpSeed),
    (Idx.fpSeedStep, body_fpSeedStep), (Idx.seedRep, body_seedRep),
    (Idx.seedRepStep, body_seedRepStep), (Idx.rowNew, body_rowNew), (Idx.rowRep, body_rowRep),
    (Idx.rowRepStep, body_rowRepStep), (Idx.groupRep, body_groupRep),
    (Idx.groupRepStep, body_groupRepStep), (Idx.coarseRep, body_coarseRep),
    (Idx.coarseRepStep, body_coarseRepStep), (Idx.blocksMap, body_blocksMap),
    (Idx.blocksMapStep, body_blocksMapStep)]

end W3

/-! ## The W3 library -/

/-- A program containing the W3 routines and the library routines they call (the W1/W4 routines
come with their contracts). -/
structure W3Lib (prog : List Expr) : Prop where
  rows : W3.RowsLib prog
  newBank : prog[Idx.newBank]? = some W3.body_newBank
  fpSeed : prog[Idx.fpSeed]? = some W3.body_fpSeed
  fpSeedStep : prog[W3.Idx.fpSeedStep]? = some W3.body_fpSeedStep
  clog2 : prog[F2e2e.Cost.Idx.clog2]? = some body_clog2
  clog2Step : prog[F2e2e.Cost.Idx.clog2Step]? = some body_clog2Step

/-- Every table entry W3 needs: its own routines (`W3.w3Table`) and the DSL-CALC library routines
they call. -/
def w3Needs : List (ℕ × Expr) :=
  W3.w3Table ++
    [(F2e2e.Cost.Idx.readNat, body_readNat), (F2e2e.Cost.Idx.readNatStep, body_readNatStep),
      (F2e2e.Cost.Idx.clog2, body_clog2), (F2e2e.Cost.Idx.clog2Step, body_clog2Step),
      (F2e2e.Cost.Idx.reverse, body_reverse), (F2e2e.Cost.Idx.revAppendStep, body_revAppendStep)]

/-- `W3Lib` from the table entries (e.g. `mkProg_get` on an assembled table containing
`w3Needs`). -/
theorem W3Lib.of_entries {prog : List Expr} (h : ∀ p ∈ w3Needs, prog[p.1]? = some p.2) :
    W3Lib prog := by
  have H : ∀ i b, (i, b) ∈ w3Needs → prog[i]? = some b := fun i b hm => h (i, b) hm
  exact
    { rows :=
        { seedRep := H _ _ (by simp [w3Needs, W3.w3Table])
          seedRepStep := H _ _ (by simp [w3Needs, W3.w3Table])
          rowNew := H _ _ (by simp [w3Needs, W3.w3Table])
          rowRep := H _ _ (by simp [w3Needs, W3.w3Table])
          rowRepStep := H _ _ (by simp [w3Needs, W3.w3Table])
          groupRep := H _ _ (by simp [w3Needs, W3.w3Table])
          groupRepStep := H _ _ (by simp [w3Needs, W3.w3Table])
          coarseRep := H _ _ (by simp [w3Needs, W3.w3Table])
          coarseRepStep := H _ _ (by simp [w3Needs, W3.w3Table])
          blocksMap := H _ _ (by simp [w3Needs, W3.w3Table])
          blocksMapStep := H _ _ (by simp [w3Needs, W3.w3Table])
          readNat := H _ _ (by simp [w3Needs, W3.w3Table])
          readNatStep := H _ _ (by simp [w3Needs, W3.w3Table])
          reverse := H _ _ (by simp [w3Needs, W3.w3Table])
          revAppendStep := H _ _ (by simp [w3Needs, W3.w3Table]) }
      newBank := H _ _ (by simp [w3Needs, W3.w3Table])
      fpSeed := H _ _ (by simp [w3Needs, W3.w3Table])
      fpSeedStep := H _ _ (by simp [w3Needs, W3.w3Table])
      clog2 := H _ _ (by simp [w3Needs, W3.w3Table])
      clog2Step := H _ _ (by simp [w3Needs, W3.w3Table]) }

namespace W3

/-! ## The fingerprint seed -/

theorem fpSeed_bounds (P : StreamParams) :
    fpM P.seedTrials P.q (Nat.clog 2 P.q) ≤ 2 ^ 10 * P.calL ∧ S_clog2 P.q ≤ 2 ^ 10 * P.calL ∧
      valSize (fpAcc P.seedTrials P.q (Nat.clog 2 P.q)) ≤ 2 ^ 10 * P.calL := by
  have hL := calL_ge_hundred P
  have hq := F2e2e.C.Space.q_le P
  have hqs : Nat.size P.q ≤ 3 * P.calL + 1 := by
    rw [Nat.size_le]
    calc P.q ≤ 2 ^ (3 * P.calL) := hq
      _ < 2 ^ (3 * P.calL + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)
  have hk : Nat.clog 2 P.q ≤ 3 * P.calL := F2e2e.C.Space.clog_two_le_of_le_two_pow hq
  have hr := seedTrials_le_calL P
  have hrs : Nat.size P.seedTrials ≤ P.calL := (size_le_self _).trans hr
  have hks : Nat.size (Nat.clog 2 P.q) ≤ 3 * P.calL := (size_le_self _).trans hk
  refine ⟨?_, ?_, ?_⟩
  · simp only [fpM, S_readNat]; omega
  · simp only [S_clog2]; omega
  · rw [valSize_fpAcc]; omega

/-- **The fingerprint-seed routine implements `fpSeedProg P`.** -/
theorem fpSeed_impl {R : AdaRep} {prog : List Expr} {M : ℕ} (hL : W3Lib prog)
    {bq bt : Expr} (hbq : prog[F2e2e.C.Impl.Idx.pq]? = some bq)
    (hq : ∀ P : StreamParams, ParamsOK P → Mv R P ≤ M →
      EvalsVal prog M [encStreamParams P] [] (.inl bq) (Val.int (P.q : ℤ)))
    (hbt : prog[F2e2e.C.Impl.Idx.pSeedTrials]? = some bt)
    (ht : ∀ P : StreamParams, ParamsOK P → Mv R P ≤ M →
      EvalsVal prog M [encStreamParams P] [] (.inl bt) (Val.int (P.seedTrials : ℤ)))
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) :
    Implements prog M [encStreamParams P] body_fpSeed encN (fpSeedProg P) := by
  obtain ⟨hb1, hb2, hb3⟩ := fpSeed_bounds P
  have hLM := calL_le_Mv R P
  intro bits a h
  have hfp : fpSeedProg P = (rejectUniform P.q (Nat.clog 2 P.q) P.seedTrials).bind
      (fun o => BitProg.pure (o.getD 0)) := rfl
  rw [hfp] at h
  obtain ⟨b₁, b₂, o, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
  have hQ : EvalsVal prog M [encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.pq (Expr.var 0))) (encN P.q) :=
    evalsVal_call_det hbq EvalsVal.var0 (hq P hP hM)
  have hK : EvalsVal prog M [encN P.q, encStreamParams P] []
      (.inl (Expr.call F2e2e.Cost.Idx.clog2 (Expr.var 0))) (encN (Nat.clog 2 P.q)) :=
    evalsVal_call_det hL.clog2 EvalsVal.var0
      ((clog2_spec hL.clog2Step P.q 0).toVal.mono_M (by omega))
  have hR : EvalsVal prog M [encN (Nat.clog 2 P.q), encN P.q, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.pSeedTrials (Expr.var 2))) (encN P.seedTrials) :=
    evalsVal_call_det hbt EvalsVal.var2 (ht P hP hM)
  have hacc : valSize (Val.list [encN P.seedTrials, encN P.q, encN (Nat.clog 2 P.q)]) ≤ M := by
    have := hb3
    unfold fpAcc at this
    omega
  have hinit : EvalsVal prog M
      [encN P.seedTrials, encN (Nat.clog 2 P.q), encN P.q, encStreamParams P] []
      (.inl (Arith.eTriple (Expr.var 0) (Expr.var 2) (Expr.var 1)))
      (fpAcc P.seedTrials P.q (Nat.clog 2 P.q)) :=
    EvalsVal.triple EvalsVal.var0 EvalsVal.var2 EvalsVal.var1 hacc
  have hloop := fpSeed_loop (M := M) hL.fpSeedStep hL.rows.readNat hL.rows.readNatStep
    P.seedTrials P.q (Nat.clog 2 P.q) (by omega) P.seedTrials le_rfl b₁ o h1
  have := EvalsVal.letE hQ (EvalsVal.letE hK (EvalsVal.letE hR (EvalsVal.loop hinit hloop)))
  simpa [body_fpSeed] using this

/-! ## Bank creation -/

/-- `newBank P` in terms of DSL-CALC's `mapB` / `replicateB` and the generic row program. -/
theorem newBank_eq (P : StreamParams) :
    newBank P = (mapB (fun nj => replicateB (rowProg (2 * P.s) P.w) nj)
      (bankAda P).blockSizes).bind (fun ada =>
        (replicateB (replicateB (replicateB (rowProg (2 * P.s) P.w) 32) P.gCoarse) P.Rmax).bind
          (fun coarse => (adaInit (bankAda P)).bind (fun st => BitProg.pure ⟨ada, coarse, st⟩))) := by
  show (sampleBlocks P (bankAda P).blockSizes).bind (fun ada =>
      (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind (fun coarse =>
        (adaInit (bankAda P)).bind (fun st => BitProg.pure (⟨ada, coarse, st⟩ : Bank)))) = _
  rw [sampleBlocks_eq]
  simp only [sampleList_eq_replicateB, newRow_eq]

theorem encBank_fresh (enc : AdaState → Val) (ada : List (List Row))
    (coarse : List (List (List Row))) (st : AdaState) :
    encBank enc ⟨ada, coarse, st⟩ =
      Val.list [encL (encL rowVal) ada, encL (encL (encL rowVal)) coarse, enc st] := rfl

/-- **The bank-creation routine implements `newBank P`.** -/
theorem newBank_impl {R : AdaRep} {prog : List Expr} {M : ℕ} (hR : R.Valid) (hL : W3Lib prog)
    (hw1 : W1Contract R prog M) (hw4 : W4Contract R prog M)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) :
    Implements prog M [encStreamParams P] body_newBank (encBank R.enc) (newBank P) := by
  obtain ⟨bw, hbw, hw⟩ := hw1.pw
  obtain ⟨bs', hbs, hs⟩ := hw1.ps
  obtain ⟨bg, hbg, hg⟩ := hw1.pgCoarse
  obtain ⟨bR, hbR, hRm⟩ := hw1.pRmax
  obtain ⟨bB, hbB, hB⟩ := hw4.adaBlockSizes
  obtain ⟨bP, hbP, hPub⟩ := hw4.adaPub
  obtain ⟨bI, hbI, hInit⟩ := hw4.adaInit
  -- value bounds
  have hNB := NB_le_Mv R P
  have hQ := one_add_Q_le_NB P (R.bound P)
  have hnw := nw_le P
  have hgR := gR_le_NB P (R.bound P)
  have hl := blocks_l_le_NB P (R.bound P)
  have hrow : ∀ nj ∈ (bankAda P).blockSizes, rowRepM nj (2 * P.s) P.w ≤ M := fun nj hnj =>
    le_trans (rowRepM_le_NB P (R.bound P)
      (le_trans (List.le_sum_of_mem hnj) (blocks_rows_le P))) (by omega)
  have hblk : blocksM (bankAda P).blockSizes (2 * P.s) P.w ≤ M :=
    le_trans (blocksM_le_NB P (R.bound P)) (by omega)
  have hco : coarseRepM P.Rmax P.gCoarse (2 * P.s) P.w ≤ M :=
    le_trans (coarseRepM_le_NB P (R.bound P)) (by omega)
  have hsz2 := size_le_self (2 * P.s)
  have hszw := size_le_self P.w
  have hszg := size_le_self P.gCoarse
  have hszR := size_le_self P.Rmax
  have hsz32 : Nat.size 32 ≤ 32 := size_le_self 32
  have hnwv := valSize_nwVal (2 * P.s) P.w
  have hbsv := valSize_encL_encN_le (bankAda P).blockSizes
  rw [newBank_eq]
  -- the deterministic prefix: parameters
  have h1 : EvalsVal prog M [encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.pw (Expr.var 0))) (encN P.w) :=
    evalsVal_call_det hbw EvalsVal.var0 (hw P hP hM)
  have h2 : EvalsVal prog M [encN P.w, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.ps (Expr.var 1))) (encN P.s) :=
    evalsVal_call_det hbs EvalsVal.var1 (hs P hP hM)
  have e2s : ((P.s : ℤ) + (P.s : ℤ)) = ((2 * P.s : ℕ) : ℤ) := by push_cast; ring
  have h3 : EvalsVal prog M [encN P.s, encN P.w, encStreamParams P] []
      (.inl (ePair (Expr.bin BinOp.add (Expr.var 0) (Expr.var 0)) (Expr.var 1)))
      (nwVal (2 * P.s) P.w) := by
    have hadd := EvalsVal.add (prog := prog) (M := M)
      (env := [encN P.s, encN P.w, encStreamParams P])
      (EvalsVal.var0 (v := Val.int (P.s : ℤ))) (EvalsVal.var0 (v := Val.int (P.s : ℤ)))
      (by rw [e2s, valSize_int, bitLen_natCast]; omega)
    rw [e2s] at hadd
    have := EvalsVal.pair hadd (EvalsVal.var1 (v := encN P.w))
      (show valSize (nwVal (2 * P.s) P.w) ≤ M by omega)
    simpa [nwVal, encN] using this
  have h4 : EvalsVal prog M [nwVal (2 * P.s) P.w, encN P.s, encN P.w, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.adaBlockSizes (Expr.var 3)))
      (encL encN (bankAda P).blockSizes) :=
    evalsVal_call_det hbB EvalsVal.var3 (hB P hP hM)
  have h5 : EvalsVal prog M [encL encN (bankAda P).blockSizes, nwVal (2 * P.s) P.w, encN P.s,
      encN P.w, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.pgCoarse (Expr.var 4))) (encN P.gCoarse) :=
    evalsVal_call_det hbg (EvalsVal.var rfl) (hg P hP hM)
  have h6 : EvalsVal prog M [encN P.gCoarse, encL encN (bankAda P).blockSizes,
      nwVal (2 * P.s) P.w, encN P.s, encN P.w, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.pRmax (Expr.var 5))) (encN P.Rmax) :=
    evalsVal_call_det hbR (EvalsVal.var rfl) (hRm P hP hM)
  refine implements_letE_det h1 (implements_letE_det h2 (implements_letE_det h3
    (implements_letE_det h4 (implements_letE_det h5 (implements_letE_det h6 ?_)))))
  -- the ADA sample blocks
  have hArgB : EvalsVal prog M [encN P.Rmax, encN P.gCoarse, encL encN (bankAda P).blockSizes,
      nwVal (2 * P.s) P.w, encN P.s, encN P.w, encStreamParams P] []
      (.inl (ePair (Expr.var 2) (Expr.var 3)))
      (Val.list [encL encN (bankAda P).blockSizes, nwVal (2 * P.s) P.w]) :=
    EvalsVal.pair (EvalsVal.var rfl) (EvalsVal.var rfl)
      (by simp only [valSize_list, listSize_cons, listSize_nil] at hnwv hbsv ⊢; omega)
  refine implements_letE_of_run (implements_call_det hL.rows.blocksMap hArgB
    (blocksMap_impl hL.rows _ _ _ hrow hblk)) (fun b1 ada hada => ?_)
  -- the coarse groups
  have hArgC : EvalsVal prog M [encL (encL rowVal) ada, encN P.Rmax, encN P.gCoarse,
      encL encN (bankAda P).blockSizes, nwVal (2 * P.s) P.w, encN P.s, encN P.w,
      encStreamParams P] []
      (.inl (ePair (Expr.var 1) (ePair (Expr.var 2) (ePair (Expr.lit 32) (Expr.var 4)))))
      (Val.list [encN P.Rmax, groupArg P.gCoarse (2 * P.s) P.w]) := by
    have hs32 : valSize (Val.int 32) ≤ M := by
      have : valSize (Val.int 32) = 7 := rfl
      omega
    have i1 := EvalsVal.pair (prog := prog) (M := M) (EvalsVal.lit' (z := 32)
      (env := [encL (encL rowVal) ada, encN P.Rmax, encN P.gCoarse,
        encL encN (bankAda P).blockSizes, nwVal (2 * P.s) P.w, encN P.s, encN P.w,
        encStreamParams P]) hs32) (EvalsVal.var (i := 4) (v := nwVal (2 * P.s) P.w) rfl)
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hnwv ⊢
          have : bitLen 32 = 6 := rfl
          omega)
    have i2 := EvalsVal.pair (EvalsVal.var (i := 2) (v := encN P.gCoarse) rfl) i1
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN]
            at hnwv ⊢
          have : bitLen 32 = 6 := rfl
          omega)
    have i3 := EvalsVal.pair (EvalsVal.var (i := 1) (v := encN P.Rmax) rfl) i2
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN]
            at hnwv ⊢
          have : bitLen 32 = 6 := rfl
          omega)
    simpa [groupArg, subArg, encN] using i3
  refine implements_letE_of_run (implements_call_det hL.rows.coarseRep hArgC
    (coarseRep_impl hL.rows P.Rmax P.gCoarse (2 * P.s) P.w hco)) (fun b2 coarse hcoarse => ?_)
  -- the ADA state
  have hArgI : EvalsVal prog M [encL (encL (encL rowVal)) coarse, encL (encL rowVal) ada,
      encN P.Rmax, encN P.gCoarse, encL encN (bankAda P).blockSizes, nwVal (2 * P.s) P.w,
      encN P.s, encN P.w, encStreamParams P] []
      (.inl (Expr.call F2e2e.C.Impl.Idx.adaPub (Expr.var 8))) (R.pub (bankAda P)) :=
    evalsVal_call_det hbP (EvalsVal.var rfl) (hPub P hP hM)
  refine implements_letE_of_run (implements_call_det hbI hArgI (hInit P hP hM))
    (fun b3 st hst => ?_)
  -- the fresh bank
  have hok : R.ok P st := Always.of_run ((hR.invariant P hP).init) hst
  have hstb := hR.enc_le P hP st hok
  have hA := valSize_blocks_le (bankAda P).blockSizes hada
  have hC := valSize_coarse_le hcoarse
  have hfin := final_le_NB P (R.bound P)
  refine Implements.of_det ?_
  rw [encBank_fresh]
  exact EvalsVal.triple (EvalsVal.var rfl) (EvalsVal.var rfl) (EvalsVal.var rfl)
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)

end W3

/-! ## The W3 contract -/

/-- **W3 contract**: bank creation (Idx 550) and the fingerprint seed (Idx 551) implement C-ALG's
`newBank P` and `fpSeedProg P`, for every parameter record of Theorem C and every value bound
`M ≥ Mv R P`, given the W3 library, W1's parameter routines, W4's ADA routines and the validity of
W4's ADA representation. -/
theorem w3Contract (R : AdaRep) (hR : R.Valid) {prog : List Expr} {M : ℕ} (hL : W3Lib prog)
    (hw1 : W1Contract R prog M) (hw4 : W4Contract R prog M) : W3Contract R prog M := by
  obtain ⟨bq, hbq, hq⟩ := hw1.pq
  obtain ⟨bt, hbt, ht⟩ := hw1.pSeedTrials
  exact ⟨⟨W3.body_newBank, hL.newBank, fun P hP hM => W3.newBank_impl hR hL hw1 hw4 P hP hM⟩,
    ⟨W3.body_fpSeed, hL.fpSeed, fun P hP hM => W3.fpSeed_impl hL hbq hq hbt ht P hP hM⟩⟩

end F2e2e.C.Impl
