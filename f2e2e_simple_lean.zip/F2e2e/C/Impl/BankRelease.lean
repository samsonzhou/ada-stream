import F2e2e.C.Impl.BankQuery

/-!
# W5: the release-side helpers of the Norm Bank (784–788, 790, 791, 793)

Owner: A-VAL (914e80f8), for W5 (c1b4f720); consumed by B-ACC's `release_spec` (757).

* References (definitions of B-ACC, 6f8aab0c, shared): `subSumZ P mode sub = ∑_{r ∈ sub} zN(r)²`,
  `coarseD P = 32 · 2^{2(eHb+eSigma)}`, `lowerMedianZ l` (entry `(|l| − 1)/2` of the sorted list),
  `coarseScaleND P mode grp = (cN, cD)` with `cN / cD = max(med/D, 1/2^{eOmega+1})`.
* Routines: `bkRowSq_val` (784), `bkSubSum_val` (786 = `sum` ∘ `mapB` 785), `bkGroupSums_val`
  (788 = `mapB` 787 of 786), `bkLowerMedian_val` (790), `bkCoarseScale_val` (791), `bkReleaseN_val`
  (793), and the bounds `coarseScaleND_bounds` (positivity and `2^10 ℒ³` bit bounds of `cN`, `cD`, as
  required by `bkQExtra_val` / `bkValsQ_val`);
* `releaseN_eq` (the released value as `max 0 nu / (cD μ.den 2^{eOmega})`) and its size bound
  `valSize_releaseN_le` (B-ACC's request for `release_spec`).

Value bounds: `Mv R P ≥ 2^31 bankSizeBound + 2^36 ℒ³` (`Mv_ge`); a reserved coarse group has
`g = gCoarse` subgroups and `2^12 g ℒ³ ≤ bankSizeBound` (`rel_gCoarse_le_bankSizeBound`); every `zN`
has `≤ 31ℒ³` bits (`bitLen_zNOf_le`), so subgroup sums have `≤ 62ℒ³ + 6` bits.
-/


namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## References -/

/-- The integer subgroup sum `∑_{r ∈ sub} zN(r)²`. -/
def subSumZ (P : StreamParams) (mode : Mode) (sub : List Row) : ℤ :=
  (sub.map fun r => zNOf P mode r ^ 2).sum

/-- The scale `D = 32 · 2^{2(eHb+eSigma)}` of the subgroup means. -/
def coarseD (P : StreamParams) : ℤ := 32 * 2 ^ (2 * (P.eHb + P.eSigma))

/-- The integer lower median: the entry of index `(|l| − 1)/2` of the sorted list. -/
def lowerMedianZ (l : List ℤ) : ℤ := (isortRef l).getD ((l.length - 1) / 2) 0

/-- The coarse scale `c = cN / cD = max(med / D, 1/2^{eOmega+1})`. -/
def coarseScaleND (P : StreamParams) (mode : Mode) (grp : List (List Row)) : ℤ × ℤ :=
  if lowerMedianZ (grp.map (subSumZ P mode)) * 2 ^ (P.eOmega + 1) < coarseD P then
    (1, 2 ^ (P.eOmega + 1))
  else (lowerMedianZ (grp.map (subSumZ P mode)), coarseD P)

/-! ## Facts on the references -/

theorem rel_abs_lt_two_pow_bitLen (z : ℤ) : |z| < 2 ^ bitLen z := by
  have h := Nat.lt_size_self z.natAbs
  have h' : ((z.natAbs : ℕ) : ℤ) < ((2 ^ Nat.size z.natAbs : ℕ) : ℤ) := by exact_mod_cast h
  rw [Int.natCast_natAbs] at h'
  unfold bitLen
  push_cast at h'
  exact h'

theorem rel_abs_sum_le (l : List ℤ) (B : ℕ) (h : ∀ z ∈ l, |z| < 2 ^ B) :
    |l.sum| ≤ l.length * 2 ^ B := by
  induction l with
  | nil => simp
  | cons z t ih =>
    simp only [List.sum_cons, List.length_cons]
    have hz := h z List.mem_cons_self
    have ht := ih (fun w hw => h w (List.mem_cons_of_mem z hw))
    calc |z + t.sum| ≤ |z| + |t.sum| := abs_add_le _ _
      _ ≤ 2 ^ B + (t.length : ℤ) * 2 ^ B := by linarith
      _ = ((t.length + 1 : ℕ) : ℤ) * 2 ^ B := by push_cast; ring

theorem rel_bitLen_sq_le {P : StreamParams} {r : Row} (hr : RowOK P r) (mode : Mode) :
    bitLen (zNOf P mode r ^ 2) ≤ 62 * P.calL ^ 3 := by
  have h1 := bitLen_zNOf_le hr mode
  have h2 := bitLen_mul_le' (zNOf P mode r) (zNOf P mode r)
  rw [sq]
  omega

theorem rel_subSumZ_nonneg (P : StreamParams) (mode : Mode) (sub : List Row) :
    0 ≤ subSumZ P mode sub := by
  unfold subSumZ
  apply List.sum_nonneg
  intro z hz
  obtain ⟨r, -, rfl⟩ := List.mem_map.mp hz
  positivity

theorem rel_bitLen_subSumZ_le {P : StreamParams} (mode : Mode) {sub : List Row}
    (hrows : ∀ r ∈ sub, RowOK P r) (hlen : sub.length = 32) :
    bitLen (subSumZ P mode sub) ≤ 62 * P.calL ^ 3 + 6 := by
  apply bitLen_le_of_abs_lt
  have hb : ∀ z ∈ sub.map (fun r => zNOf P mode r ^ 2), |z| < 2 ^ (62 * P.calL ^ 3) := by
    intro z hz
    obtain ⟨r, hr, rfl⟩ := List.mem_map.mp hz
    exact lt_of_lt_of_le (rel_abs_lt_two_pow_bitLen _)
      (pow_le_pow_right₀ (by norm_num) (rel_bitLen_sq_le (hrows r hr) mode))
  have h := rel_abs_sum_le _ _ hb
  rw [List.length_map, hlen] at h
  unfold subSumZ
  calc |(sub.map fun r => zNOf P mode r ^ 2).sum| ≤ ((32 : ℕ) : ℤ) * 2 ^ (62 * P.calL ^ 3) := h
    _ < 2 ^ (62 * P.calL ^ 3 + 6) := by
      rw [pow_add]
      have : (0 : ℤ) < 2 ^ (62 * P.calL ^ 3) := by positivity
      push_cast
      linarith

theorem rel_lowerMedianZ_mem (l : List ℤ) (hl : l ≠ []) : lowerMedianZ l ∈ l := by
  have hperm : (isortRef l).Perm l := by
    have h := Arith.isortAux_perm l []
    rw [List.nil_append] at h
    exact h
  have hlen : 1 ≤ l.length := by
    cases l with
    | nil => exact absurd rfl hl
    | cons a t => simp
  have hlt : (l.length - 1) / 2 < (isortRef l).length := by
    rw [hperm.length_eq]
    omega
  unfold lowerMedianZ
  rw [List.getD_eq_getElem _ _ hlt]
  exact hperm.subset (List.getElem_mem hlt)

theorem rel_gCoarse_le_bankSizeBound (P : StreamParams) (b : ℕ) :
    2 ^ 12 * (P.gCoarse * P.calL ^ 3) ≤ bankSizeBound P b := by
  have hR : 2 ≤ P.Rmax := by unfold StreamParams.Rmax; omega
  have hb : P.Rmax * (P.gCoarse * 32) ≤ bankRows P := by unfold bankRows; omega
  have h1 : P.Rmax * (P.gCoarse * 32) * (2 ^ 6 * P.calL ^ 3) ≤
      bankRows P * (2 ^ 6 * P.calL ^ 3 + 1) := Nat.mul_le_mul hb (by omega)
  have h2 : 2 * (P.gCoarse * 32) * (2 ^ 6 * P.calL ^ 3) ≤
      P.Rmax * (P.gCoarse * 32) * (2 ^ 6 * P.calL ^ 3) :=
    Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hR)
  have e : 2 ^ 12 * (P.gCoarse * P.calL ^ 3) = 2 * (P.gCoarse * 32) * (2 ^ 6 * P.calL ^ 3) := by
    ring
  unfold bankSizeBound
  omega

theorem rel_valSize_grp_lt {enc : AdaState → Val} {B : Bank} {grp : List (List Row)}
    (hg : grp ∈ B.coarse) : valSize (encL (encL encRow) grp) < valSize (encBank enc B) := by
  have h1 : valSize (encL (encL encRow) grp) < valSize (encL (encL (encL encRow)) B.coarse) :=
    valSize_lt_encL (encL (encL encRow)) hg
  have h2 : valSize (encL (encL (encL encRow)) B.coarse) < valSize (encBank enc B) :=
    valSize_lt_of_mem (l := [encL (encL encRow) B.ada, encL (encL (encL encRow)) B.coarse,
      enc B.adaSt]) (by simp)
  omega

theorem rel_bound_le_Mv (R : AdaRep) (P : StreamParams) :
    2 ^ 31 * R.bound P + 2 ^ 36 * P.calL ^ 3 ≤ Mv R P := by
  have h1 := Mv_ge R P
  have h2 := bound_le_bankSizeBound P (R.bound P)
  omega

theorem rel_bitLen_sub (a b : ℤ) : bitLen (a - b) ≤ bitLen a + bitLen b + 1 := by
  have h := bitLen_add_le a (-b)
  rw [bitLen_neg] at h
  rw [sub_eq_add_neg]
  have : max (bitLen a) (bitLen b) ≤ bitLen a + bitLen b :=
    max_le (Nat.le_add_right _ _) (Nat.le_add_left _ _)
  omega

/-- The value of `ReleaseNumerical` in the integer form of `body_bkReleaseN`:
`max 0 (L c μ − ω) = max 0 nu / (cD μ.den 2^{eOmega})`, `nu = L cN μ.num 2^{eOmega} − cD μ.den`. -/
theorem releaseN_eq (P : StreamParams) (cN cD : ℤ) (hcD : 0 < cD) (μ : ℚ) :
    max 0 ((P.L : ℚ) * ((cN : ℚ) / (cD : ℚ)) * μ - P.omega) =
      (((if (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) < 0 then 0
          else (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) : ℤ) : ℚ) /
        ((cD * (μ.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ) := by
  have hμd : (0 : ℤ) < (μ.den : ℤ) := by exact_mod_cast μ.pos
  have hdenpos : 0 < cD * (μ.den : ℤ) * 2 ^ P.eOmega := by positivity
  have homega : P.omega = 1 / (2 : ℚ) ^ P.eOmega := by
    unfold StreamParams.omega StreamParams.sigma StreamParams.eOmega
    rw [← pow_mul, one_div_pow, mul_comm]
  have hμq : μ = (μ.num : ℚ) / (μ.den : ℚ) := (Rat.num_div_den μ).symm
  have hcDq : (cD : ℚ) ≠ 0 := by exact_mod_cast hcD.ne'
  have hμdq : (μ.den : ℚ) ≠ 0 := by positivity
  have hdenq : (0 : ℚ) < ((cD * (μ.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ) := by
    exact_mod_cast hdenpos
  have hfrac : (P.L : ℚ) * ((cN : ℚ) / (cD : ℚ)) * μ - P.omega =
      (((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) : ℤ) : ℚ) /
        ((cD * (μ.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ) := by
    rw [homega]
    conv_lhs => rw [hμq]
    push_cast
    field_simp
  rw [hfrac]
  have hmax : ((if (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) < 0 then 0
        else (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) : ℤ) : ℚ) =
      max 0 ((((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) : ℤ) : ℚ)) := by
    split_ifs with h
    · rw [max_eq_left (by exact_mod_cast h.le)]; simp
    · rw [max_eq_right (by exact_mod_cast not_lt.mp h)]
  rw [hmax, ← max_div_div_right hdenq.le, zero_div]

/-- Numerator and denominator of a fraction `a / b` (`b > 0`) are at most `|a|` and `b`. -/
theorem rel_num_den_le (a b : ℤ) (hb : 0 < b) :
    bitLen ((a : ℚ) / (b : ℚ)).num ≤ bitLen a ∧ bitLen ((((a : ℚ) / (b : ℚ)).den : ℕ) : ℤ) ≤ bitLen b := by
  obtain ⟨hn, hd⟩ := normQ_num_den a b hb
  have hg : (0 : ℤ) < (Nat.gcd b.natAbs a.natAbs : ℤ) := by
    have : 0 < Nat.gcd b.natAbs a.natAbs := Nat.gcd_pos_of_pos_left _ (by omega)
    exact_mod_cast this
  constructor
  · rw [hn]
    exact bitLen_le_bitLen_of_natAbs_le (by
      have h := Int.abs_ediv_le_abs a (Nat.gcd b.natAbs a.natAbs : ℤ)
      rw [Int.abs_eq_natAbs, Int.abs_eq_natAbs] at h
      exact_mod_cast h)
  · rw [hd]
    have h1 : b / (Nat.gcd b.natAbs a.natAbs : ℤ) ≤ b := Int.ediv_le_self _ hb.le
    have h2 : 0 ≤ b / (Nat.gcd b.natAbs a.natAbs : ℤ) := Int.ediv_nonneg hb.le hg.le
    exact bitLen_le_bitLen_of_natAbs_le (by
      have e1 := Int.natAbs_of_nonneg h2
      have e2 := Int.natAbs_of_nonneg hb.le
      omega)

/-- Size of the released value (B-ACC's request for `release_spec`). -/
theorem valSize_releaseN_le (R : AdaRep) (P : StreamParams) (cN cD : ℤ) (hcN : 0 < cN)
    (hcD : 0 < cD) (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3) (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3)
    (μ : ℚ) (hμ : valSize (encQ μ) ≤ R.bound P) :
    valSize (encQ (max 0 ((P.L : ℚ) * ((cN : ℚ) / (cD : ℚ)) * μ - P.omega))) ≤
      2 ^ 12 * P.calL ^ 3 + 2 * R.bound P := by
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hO := eOmega_le P
  have hL := bitLen_L_le P
  have hμd : (0 : ℤ) < (μ.den : ℤ) := by exact_mod_cast μ.pos
  have hμ' : bitLen μ.num + bitLen (μ.den : ℤ) + 5 ≤ R.bound P := by
    simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil] at hμ
    omega
  have hOv := bitLen_two_pow P.eOmega
  have hdenpos : 0 < cD * (μ.den : ℤ) * 2 ^ P.eOmega := by positivity
  rw [releaseN_eq P cN cD hcD μ]
  obtain ⟨hn, hd⟩ := rel_num_den_le
    (if (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) < 0 then 0
      else (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) _ hdenpos
  have m1 := bitLen_mul_le' (P.L : ℤ) cN
  have m2 := bitLen_mul_le' ((P.L : ℤ) * cN) μ.num
  have m3 := bitLen_mul_le' ((P.L : ℤ) * cN * μ.num) ((2 : ℤ) ^ P.eOmega)
  have m4 := bitLen_mul_le' cD (μ.den : ℤ)
  have m5 := bitLen_mul_le' (cD * (μ.den : ℤ)) ((2 : ℤ) ^ P.eOmega)
  have m6 := rel_bitLen_sub ((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega) (cD * (μ.den : ℤ))
  have hmx : bitLen (if (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) < 0 then 0
      else (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) ≤
      bitLen ((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) := by
    split_ifs <;> simp
  simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil]
  omega

section rules

variable {prog : List Expr} {M : ℕ}

/-- `ite` on a comparison, with integer branches, as an integer `ite`. -/
theorem rel_ite_int {env : List Val} {c t f : Expr} {p : Prop} [Decidable p] {a b : ℤ}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int (if p then 1 else 0)))
    (ht : p → EvalsVal prog M env [] (.inl t) (Val.int a))
    (hf : ¬ p → EvalsVal prog M env [] (.inl f) (Val.int b)) :
    EvalsVal prog M env [] (.inl (eIte c t f)) (Val.int (if p then a else b)) := by
  by_cases hp : p
  · rw [if_pos hp] at hc ⊢
    exact ev_ite_t hc one_ne_zero (ht hp)
  · rw [if_neg hp] at hc ⊢
    exact ev_ite_f hc rfl (hf hp)

/-- `pow2` on an integer argument equal to a natural number. -/
theorem rel_pow2 (hlib : BankLib prog) {env : List Val} {a : Expr} {z : ℤ} (k : ℕ)
    (ha : EvalsVal prog M env [] (.inl a) (Val.int z)) (hz : z = (k : ℤ))
    (hM : Cost.S_pow2 k ≤ M) :
    EvalsVal prog M env [] (.inl (ePow2 a)) (Val.int ((2 : ℤ) ^ k)) := by
  subst hz
  exact ev_pow2 hlib ha hM

/-- 784: `[encRow r, zx] ↦ zN²`. -/
theorem bkRowSq_val (R : AdaRep) (hlib : BankLib prog) (hw2 : HornerLib prog) (P : StreamParams)
    (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (r : Row) (hr : RowOK P r) :
    EvalsVal prog M [Val.list [encRow r, zxVal P mode]] [] (.inl body_bkRowSq)
      (Val.int (zNOf P mode r ^ 2)) := by
  have hMv := Mv_ge R P
  have hc100 := SizeAux.hundred_le_calL_cube P
  have hsq := rel_bitLen_sq_le hr mode
  rw [sq] at hsq ⊢
  unfold body_bkRowSq
  exact ev_let (ev_call hlib.bkZN (ev_var rfl) (bkZN_val R hlib hw2 P hP hM mode r hr))
    (ev_mul (ev_var rfl) (ev_var rfl) (by simp only [valSize_int]; omega))

/-- 786: `[encL encRow sub, zx] ↦ ∑_{r ∈ sub} zN(r)²` (a subgroup of `32` rows). -/
theorem bkSubSum_val (R : AdaRep) (hlib : BankLib prog) (hw2 : HornerLib prog) (P : StreamParams)
    (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (sub : List Row)
    (hrows : ∀ r ∈ sub, RowOK P r) (hlen : sub.length = 32) :
    EvalsVal prog M [Val.list [encL encRow sub, zxVal P mode]] [] (.inl body_bkSubSum)
      (Val.int (subSumZ P mode sub)) := by
  have hMv := Mv_ge R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hzx := valSize_zxVal_le P mode
  have hrowsz : valSize (encL encRow sub) ≤ 1 + 32 * (2 ^ 6 * P.calL ^ 3 + 1) := by
    have := valSize_encL_le encRow sub (2 ^ 6 * P.calL ^ 3)
      (fun r hr => (hrows r hr).valSize_encRow_le)
    rw [hlen] at this
    exact this
  have hsqsz : valSize (encInts (sub.map fun r => zNOf P mode r ^ 2)) ≤
      1 + 32 * (62 * P.calL ^ 3 + 2) := by
    have := valSize_encInts_le (sub.map fun r => zNOf P mode r ^ 2) (62 * P.calL ^ 3) (by
      intro z hz
      obtain ⟨r, hr, rfl⟩ := List.mem_map.mp hz
      exact rel_bitLen_sq_le (hrows r hr) mode)
    rw [List.length_map, hlen] at this
    exact this
  have hmap := mapD_val hlib.bkRowSqStep hlib.bkRowSq hlib.reverse hlib.revAppendStep encRow encZ
    (zxVal P mode) (fun r => zNOf P mode r ^ 2) sub
    (fun r hr => bkRowSq_val R hlib hw2 P hP hM mode r (hrows r hr)) (by
      rw [← encInts_eq_encL]
      omega)
  have hb : ∀ z ∈ sub.map (fun r => zNOf P mode r ^ 2), |z| < 2 ^ (62 * P.calL ^ 3) := by
    intro z hz
    obtain ⟨r, hr, rfl⟩ := List.mem_map.mp hz
    exact lt_of_lt_of_le (rel_abs_lt_two_pow_bitLen _)
      (pow_le_pow_right₀ (by norm_num) (rel_bitLen_sq_le (hrows r hr) mode))
  have hs32 : Nat.size (sub.map fun r => zNOf P mode r ^ 2).length ≤ 6 := by
    rw [List.length_map, hlen]
    exact Nat.size_le.mpr (by norm_num)
  have hsum := (sum_spec hlib.sumStep (sub.map fun r => zNOf P mode r ^ 2) (62 * P.calL ^ 3) hb
    0).toVal.mono_M (M' := M) (by unfold S_sum; omega)
  unfold body_bkSubSum
  exact ev_call hlib.sum hmap hsum

/-- 788 (`body_mapB bkSubSumStep`): `[encL (encL encRow) grp, zx] ↦` the subgroup sums. -/
theorem bkGroupSums_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw2 : HornerLib prog)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (B : Bank)
    (hB : BankOK P (R.ok P) B) (grp : List (List Row)) (hg : grp ∈ B.coarse) :
    EvalsVal prog M [Val.list [encL (encL encRow) grp, zxVal P mode]] []
      (.inl (body_mapB Idx.bkSubSumStep)) (encInts (grp.map (subSumZ P mode))) := by
  have hMv := Mv_ge R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hzx := valSize_zxVal_le P mode
  obtain ⟨hglen, hsub32⟩ := hB.coarse_shape grp hg
  have hgsz := rel_valSize_grp_lt (enc := R.enc) hg
  have hbank := bank_size_le R hR hP hB
  have hgL := rel_gCoarse_le_bankSizeBound P (R.bound P)
  have hsumsz : valSize (encInts (grp.map (subSumZ P mode))) ≤
      1 + P.gCoarse * (62 * P.calL ^ 3 + 8) := by
    have := valSize_encInts_le (grp.map (subSumZ P mode)) (62 * P.calL ^ 3 + 6) (by
      intro z hz
      obtain ⟨sub, hsub, rfl⟩ := List.mem_map.mp hz
      exact rel_bitLen_subSumZ_le mode (fun r hr => hB.coarse_rows grp hg sub hsub r hr)
        (hsub32 sub hsub))
    rw [List.length_map, hglen] at this
    exact this
  have e : P.gCoarse * (62 * P.calL ^ 3 + 8) = 62 * (P.gCoarse * P.calL ^ 3) + 8 * P.gCoarse := by
    ring
  have hg1 : P.gCoarse ≤ P.gCoarse * P.calL ^ 3 :=
    Nat.le_mul_of_pos_right _ (by positivity)
  rw [encInts_eq_encL]
  exact mapD_val hlib.bkSubSumStep hlib.bkSubSum hlib.reverse hlib.revAppendStep (encL encRow) encZ
    (zxVal P mode) (subSumZ P mode) grp
    (fun sub hsub => bkSubSum_val R hlib hw2 P hP hM mode sub
      (fun r hr => hB.coarse_rows grp hg sub hsub r hr) (hsub32 sub hsub))
    (by rw [← encInts_eq_encL]; omega)

/-- 790: `encInts l ↦ lowerMedianZ l` for a nonempty list. -/
theorem bkLowerMedian_val (hlib : BankLib prog) (l : List ℤ) (hl : l ≠ []) (K : ℕ)
    (hK : ∀ z ∈ l, bitLen z ≤ K) (hM : S_medZ l.length K + 8 * valSize (encInts l) + 100 ≤ M) :
    EvalsVal prog M [encInts l] [] (.inl body_bkLowerMedian) (Val.int (lowerMedianZ l)) := by
  have hperm : (isortRef l).Perm l := by
    have h := Arith.isortAux_perm l []
    rw [List.nil_append] at h
    exact h
  have hlen : 1 ≤ l.length := by
    cases l with
    | nil => exact absurd rfl hl
    | cons a t => simp
  have hVs : valSize (encInts (isortRef l)) = valSize (encInts l) := Arith.valSize_encInts_perm hperm
  have hsl : Nat.size l.length ≤ l.length := size_le_self _
  have hSm : 7 * l.length + 50 ≤ S_medZ l.length K := by
    unfold S_medZ
    have h1 : 1 ≤ K + 3 := by omega
    have h2 : 100 * (l.length + 1) * 1 ≤ 100 * (l.length + 1) * (K + 3) := Nat.mul_le_mul_left _ h1
    omega
  have hVl : 2 * l.length + 1 ≤ valSize (encInts l) := by
    have := valSize_encL_ge encZ l
    rw [← encInts_eq_encL] at this
    omega
  have hsort := (isortZ_spec hlib.isortZStep hlib.insertZ hlib.insertZStep hlib.revAppendStep l K hK
    0).toVal.mono_M (M' := M) (by omega)
  have hlenE := (length_spec hlib.lengthStep (l.map Val.int) 0).toVal.mono_M (M' := M) (by
    unfold S_length
    rw [List.length_map]
    have : valSize (Val.list (l.map Val.int)) = valSize (encInts l) := rfl
    omega)
  rw [List.length_map] at hlenE
  set n := (l.length - 1) / 2 with hn
  have hnl : n ≤ l.length := by omega
  have hsn : Nat.size n ≤ l.length := (Nat.size_le_size hnl).trans hsl
  have hget := (get_spec hlib.getStep ((isortRef l).map Val.int) n 0).toVal.mono_M (M' := M) (by
    unfold S_get
    have : valSize (Val.list ((isortRef l).map Val.int)) = valSize (encInts (isortRef l)) := rfl
    omega)
  rw [List.getD_map] at hget
  have hdiv : ((l.length : ℤ) - 1) / 2 = (n : ℤ) := by omega
  have hbl : bitLen (l.length : ℤ) ≤ l.length := bitLen_natCast_le _
  have hb1 : bitLen ((l.length : ℤ) - 1) ≤ l.length := by
    have h1 : ((l.length : ℤ) - 1) = ((l.length - 1 : ℕ) : ℤ) := by omega
    rw [h1]
    exact bitLen_natCast_le_of_le (by omega)
  have hbn : bitLen (n : ℤ) ≤ l.length := bitLen_natCast_le_of_le hnl
  have hbd := bitLen_ediv_le ((l.length : ℤ) - 1) 2
  have hM2 : 2 ≤ M := by omega
  unfold body_bkLowerMedian lowerMedianZ
  have hl1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have hl2 : valSize (Val.int 2) ≤ M := by simp only [valSize_int, bitLen_two_eq]; omega
  have hs1 : valSize (Val.int ((l.length : ℤ) - 1)) ≤ M := by simp only [valSize_int]; omega
  have hs2 : valSize (Val.int (((l.length : ℤ) - 1) / 2)) ≤ M := by simp only [valSize_int]; omega
  have hs3 : valSize (Val.list [encInts (isortRef l), Val.int (((l.length : ℤ) - 1) / 2)]) ≤ M := by
    rw [hdiv]
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  rw [← hdiv] at hget
  exact ev_call hlib.get (ev_pair (ev_call hlib.isortZ (ev_var rfl) hsort)
    (ev_div (ev_sub (ev_call hlib.length (ev_var rfl) hlenE) (ev_lit hl1) hs1) (ev_lit hl2)
      (by norm_num) hs2) hs3) hget

/-- The coarse scale is positive with numerator and denominator of at most `2^10 ℒ³` bits. -/
theorem coarseScaleND_bounds {P : StreamParams} (mode : Mode) {grp : List (List Row)}
    (hshape : grp.length = P.gCoarse ∧ ∀ sub ∈ grp, sub.length = 32)
    (hrows : ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P r) :
    0 < (coarseScaleND P mode grp).1 ∧ 0 < (coarseScaleND P mode grp).2 ∧
      bitLen (coarseScaleND P mode grp).1 ≤ 2 ^ 10 * P.calL ^ 3 ∧
      bitLen (coarseScaleND P mode grp).2 ≤ 2 ^ 10 * P.calL ^ 3 := by
  have hc100 := hundred_le_calL P
  have hc3 := (W2.calL_pow_bounds P).1
  have hO := eOmega_le P
  have hH := eHb_le P
  have hS := eSigma_le P
  have hne : grp.map (subSumZ P mode) ≠ [] := by
    intro h
    have hg0 : 0 < (grp.map (subSumZ P mode)).length := by
      rw [List.length_map, hshape.1]; unfold StreamParams.gCoarse; omega
    rw [h] at hg0
    simp at hg0
  have hmem := rel_lowerMedianZ_mem _ hne
  obtain ⟨sub, hsub, hmed⟩ := List.mem_map.mp hmem
  have hmed0 : 0 ≤ lowerMedianZ (grp.map (subSumZ P mode)) := by
    rw [← hmed]; exact rel_subSumZ_nonneg P mode sub
  have hmedb : bitLen (lowerMedianZ (grp.map (subSumZ P mode))) ≤ 62 * P.calL ^ 3 + 6 := by
    rw [← hmed]
    exact rel_bitLen_subSumZ_le mode (hrows sub hsub) (hshape.2 sub hsub)
  have hDb : bitLen (coarseD P) ≤ 2 * (P.eHb + P.eSigma) + 7 := by
    unfold coarseD
    have h1 := bitLen_mul_le' 32 ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)))
    rw [bitLen_two_pow] at h1
    have h32 : bitLen (32 : ℤ) ≤ 6 := bitLen_le_of_abs_lt (by norm_num)
    omega
  have hD0 : 0 < coarseD P := by unfold coarseD; positivity
  have hOb := bitLen_two_pow (P.eOmega + 1)
  unfold coarseScaleND
  split_ifs with h
  · dsimp only
    refine ⟨by norm_num, by positivity, ?_, ?_⟩
    · simp only [bitLen_one]; omega
    · omega
  · dsimp only
    refine ⟨?_, hD0, ?_, ?_⟩
    · by_contra hc
      have h0 : lowerMedianZ (grp.map (subSumZ P mode)) = 0 := by omega
      rw [h0, zero_mul] at h
      exact h hD0
    · omega
    · omega

/-- 791: `[encP, zx, encL (encL encRow) grp] ↦ [cN, cD] = coarseScaleND P mode grp` for a reserved
coarse group of a bank. -/
theorem bkCoarseScale_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (hw2 : HornerLib prog) (P : StreamParams) (hP : ParamsOK P)
    (hM : Mv R P ≤ M) (mode : Mode) (B : Bank) (hB : BankOK P (R.ok P) B)
    (grp : List (List Row)) (hg : grp ∈ B.coarse) :
    EvalsVal prog M [Val.list [encStreamParams P, zxVal P mode, encL (encL encRow) grp]] []
      (.inl body_bkCoarseScale)
      (Val.list [Val.int (coarseScaleND P mode grp).1, Val.int (coarseScaleND P mode grp).2]) := by
  have hMv := Mv_ge R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hzx := valSize_zxVal_le P mode
  have hPs := valSize_encStreamParams_le' P
  have hO := eOmega_le P
  have hH := eHb_le P
  have hS := eSigma_le P
  obtain ⟨hglen, hsub32⟩ := hB.coarse_shape grp hg
  have hrows : ∀ sub ∈ grp, ∀ r ∈ sub, RowOK P r := hB.coarse_rows grp hg
  have hgsz := rel_valSize_grp_lt (enc := R.enc) hg
  have hbank := bank_size_le R hR hP hB
  have hgL := rel_gCoarse_le_bankSizeBound P (R.bound P)
  have hg1 : P.gCoarse ≤ P.gCoarse * P.calL ^ 3 := Nat.le_mul_of_pos_right _ (by positivity)
  -- the list of subgroup sums
  have hK : ∀ z ∈ grp.map (subSumZ P mode), bitLen z ≤ 62 * P.calL ^ 3 + 6 := by
    intro z hz
    obtain ⟨sub, hsub, rfl⟩ := List.mem_map.mp hz
    exact rel_bitLen_subSumZ_le mode (hrows sub hsub) (hsub32 sub hsub)
  have hsumsz : valSize (encInts (grp.map (subSumZ P mode))) ≤
      1 + P.gCoarse * (62 * P.calL ^ 3 + 8) := by
    have := valSize_encInts_le (grp.map (subSumZ P mode)) (62 * P.calL ^ 3 + 6) hK
    rw [List.length_map, hglen] at this
    exact this
  have e1 : P.gCoarse * (62 * P.calL ^ 3 + 8) = 62 * (P.gCoarse * P.calL ^ 3) + 8 * P.gCoarse := by
    ring
  have hSm : S_medZ (grp.map (subSumZ P mode)).length (62 * P.calL ^ 3 + 6) ≤
      6300 * (P.gCoarse * P.calL ^ 3) + 6300 * P.calL ^ 3 + 1000 := by
    rw [List.length_map, hglen]
    unfold S_medZ
    have h1 : 62 * P.calL ^ 3 + 6 + 3 ≤ 63 * P.calL ^ 3 := by omega
    have h2 : 100 * (P.gCoarse + 1) * (62 * P.calL ^ 3 + 6 + 3) ≤
        100 * (P.gCoarse + 1) * (63 * P.calL ^ 3) := Nat.mul_le_mul_left _ h1
    have h3 : 100 * (P.gCoarse + 1) * (63 * P.calL ^ 3) =
        6300 * (P.gCoarse * P.calL ^ 3) + 6300 * P.calL ^ 3 := by ring
    omega
  have hne : grp.map (subSumZ P mode) ≠ [] := by
    intro h
    have hg0 : 0 < (grp.map (subSumZ P mode)).length := by
      rw [List.length_map, hglen]; unfold StreamParams.gCoarse; omega
    rw [h] at hg0
    simp at hg0
  obtain ⟨hcN, hcD, hbN, hbD⟩ := coarseScaleND_bounds mode ⟨hglen, hsub32⟩ hrows
  have hmem := rel_lowerMedianZ_mem _ hne
  obtain ⟨sub0, hsub0, hmed⟩ := List.mem_map.mp hmem
  have hmedb : bitLen (lowerMedianZ (grp.map (subSumZ P mode))) ≤ 62 * P.calL ^ 3 + 6 := by
    rw [← hmed]
    exact rel_bitLen_subSumZ_le mode (hrows sub0 hsub0) (hsub32 sub0 hsub0)
  have hI : valSize (Val.list [encStreamParams P, zxVal P mode, encL (encL encRow) grp]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hDv : bitLen ((32 : ℤ) * 2 ^ (2 * (P.eHb + P.eSigma))) ≤ 2 * (P.eHb + P.eSigma) + 7 := by
    have h1 := bitLen_mul_le' 32 ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)))
    rw [bitLen_two_pow] at h1
    have h32 : bitLen (32 : ℤ) ≤ 6 := bitLen_le_of_abs_lt (by norm_num)
    omega
  have hOv := bitLen_two_pow (P.eOmega + 1)
  have hEv := bitLen_two_pow (2 * (P.eHb + P.eSigma))
  have hmO := bitLen_mul_le' (lowerMedianZ (grp.map (subSumZ P mode))) ((2 : ℤ) ^ (P.eOmega + 1))
  have hEb : bitLen ((P.eHb : ℤ) + (P.eSigma : ℤ)) ≤ P.eHb + P.eSigma := by
    have := bitLen_natCast_le_of_le (le_refl (P.eHb + P.eSigma))
    push_cast at this
    exact this
  have hE2b : bitLen (2 * ((P.eHb : ℤ) + (P.eSigma : ℤ))) ≤ 2 * (P.eHb + P.eSigma) := by
    have := bitLen_natCast_le_of_le (le_refl (2 * (P.eHb + P.eSigma)))
    push_cast at this
    exact this
  have hO1b : bitLen ((P.eOmega : ℤ) + 1) ≤ P.eOmega + 1 := by
    have := bitLen_natCast_le_of_le (le_refl (P.eOmega + 1))
    push_cast at this
    exact this
  have hsHS := size_le_self (2 * (P.eHb + P.eSigma))
  have hsO := size_le_self (P.eOmega + 1)
  have hbHb := bitLen_natCast_le_of_le (le_refl P.eHb)
  have hbS := bitLen_natCast_le_of_le (le_refl P.eSigma)
  have hbO := bitLen_natCast_le_of_le (le_refl P.eOmega)
  have h32v : bitLen (32 : ℤ) ≤ 6 := bitLen_le_of_abs_lt (by norm_num)
  have hM2 : 2 ≤ M := by omega
  unfold body_bkCoarseScale
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_call hlib.bkLowerMedian
      (ev_call hlib.bkGroupSums (ev_pair (ev_at2 (ev_var rfl) hI) (ev_at1 (ev_var rfl) hI) ?_)
        (bkGroupSums_val R hR hlib hw2 P hP hM mode B hB grp hg))
      (bkLowerMedian_val hlib _ hne (62 * P.calL ^ 3 + 6) hK ?_))
    (ev_let (ev_mul (ev_lit ?_) (rel_pow2 hlib (2 * (P.eHb + P.eSigma))
        (ev_mul (ev_lit ?_) (ev_add (ev_param hw1.peHb P hP hM (ev_var rfl))
          (ev_param hw1.peSigma P hP hM (ev_var rfl)) ?_) ?_) (by push_cast; ring) ?_) ?_)
    (ev_let (rel_pow2 hlib (P.eOmega + 1) (ev_add (ev_param hw1.peOmega P hP hM (ev_var rfl))
        (ev_lit ?_) ?_) (by push_cast; ring) ?_) ?_)))
  any_goals first
    | omega
    | (unfold Cost.S_pow2; omega)
    | (simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one,
        bitLen_two_eq]; omega)
  -- the final comparison; environment `[O2, D, med, P, I]`
  have hcD' : coarseD P = 32 * 2 ^ (2 * (P.eHb + P.eSigma)) := rfl
  unfold coarseScaleND
  rw [hcD']
  split_ifs with h
  · exact ev_ite_t (ev_lt (ev_mul (ev_var rfl) (ev_var rfl) (by simp only [valSize_int]; omega))
        (ev_var rfl) hM2) (by rw [if_pos h]; exact one_ne_zero)
      (ev_pair (ev_lit (by simp only [valSize_int, bitLen_one]; omega)) (ev_var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega))
  · exact ev_ite_f (ev_lt (ev_mul (ev_var rfl) (ev_var rfl) (by simp only [valSize_int]; omega))
        (ev_var rfl) hM2) (by rw [if_neg h])
      (ev_pair (ev_var rfl) (ev_var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))

/-- 793: `[encP, [cN, cD], encQ μ] ↦ encQ (max 0 (L (cN/cD) μ − ω))`. -/
theorem bkReleaseN_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog)
    (hw1 : W1Contract R prog M) (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M)
    (cN cD : ℤ) (hcN : 0 < cN) (hcD : 0 < cD) (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3)
    (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3) (μ : ℚ) (hμ : valSize (encQ μ) ≤ R.bound P) :
    EvalsVal prog M [Val.list [encStreamParams P, Val.list [Val.int cN, Val.int cD], encQ μ]] []
      (.inl body_bkReleaseN)
      (encQ (max 0 ((P.L : ℚ) * ((cN : ℚ) / (cD : ℚ)) * μ - P.omega))) := by
  have hMv := rel_bound_le_Mv R P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hPs := valSize_encStreamParams_le' P
  have hO := eOmega_le P
  have hL := bitLen_L_le P
  have hLpos : (0 : ℤ) < (P.L : ℤ) := by exact_mod_cast L_pos P
  have hμd : (0 : ℤ) < (μ.den : ℤ) := by exact_mod_cast μ.pos
  have hμ' : bitLen μ.num + bitLen (μ.den : ℤ) + 5 ≤ R.bound P := by
    simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil] at hμ
    omega
  have hOv := bitLen_two_pow P.eOmega
  have hsO := size_le_self P.eOmega
  have hbO := bitLen_natCast_le_of_le (le_refl P.eOmega)
  have hOpos : (0 : ℤ) < 2 ^ P.eOmega := by positivity
  have hdenpos : 0 < cD * (μ.den : ℤ) * 2 ^ P.eOmega := by positivity
  rw [releaseN_eq P cN cD hcD μ, show encQ μ = Val.list [Val.int μ.num, Val.int (μ.den : ℤ)] from rfl]
  -- bit lengths
  have m1 := bitLen_mul_le' (P.L : ℤ) cN
  have m2 := bitLen_mul_le' ((P.L : ℤ) * cN) μ.num
  have m3 := bitLen_mul_le' ((P.L : ℤ) * cN * μ.num) ((2 : ℤ) ^ P.eOmega)
  have m4 := bitLen_mul_le' cD (μ.den : ℤ)
  have m5 := bitLen_mul_le' (cD * (μ.den : ℤ)) ((2 : ℤ) ^ P.eOmega)
  have m6 := rel_bitLen_sub ((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega) (cD * (μ.den : ℤ))
  have hmx : bitLen (if (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ) < 0 then 0
      else (P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) ≤
      bitLen ((P.L : ℤ) * cN * μ.num * 2 ^ P.eOmega - cD * (μ.den : ℤ)) := by
    split_ifs <;> simp
  have hI : valSize (Val.list [encStreamParams P, Val.list [Val.int cN, Val.int cD],
      Val.list [Val.int μ.num, Val.int (μ.den : ℤ)]]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hc : valSize (Val.list [Val.int cN, Val.int cD]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hq : valSize (Val.list [Val.int μ.num, Val.int (μ.den : ℤ)]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hM2 : 2 ≤ M := by omega
  have hl0 : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  unfold body_bkReleaseN
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_pow2 hlib (ev_param hw1.peOmega P hP hM
      (ev_var rfl)) (by unfold Cost.S_pow2; omega))
    (ev_let (ev_at1 (ev_var rfl) hI) (ev_let (ev_at2 (ev_var rfl) hI)
    (ev_let (ev_sub (ev_mul (ev_mul (ev_mul (ev_param hw1.pL P hP hM (ev_var rfl))
        (ev_hd (ev_var rfl) hc) ?_) (ev_hd (ev_var rfl) hq) ?_) (ev_var rfl) ?_)
      (ev_mul (ev_at1 (ev_var rfl) hc) (ev_at1 (ev_var rfl) hq) ?_) ?_)
    (ev_call hlib.normQ (ev_pair (rel_ite_int (ev_lt (ev_var rfl) (ev_lit hl0) hM2)
        (fun _ => ev_lit hl0) (fun _ => ev_var rfl))
      (ev_mul (ev_mul (ev_at1 (ev_var rfl) hc) (ev_at1 (ev_var rfl) hq) ?_) (ev_var rfl) ?_) ?_)
      (normQ_val hlib.bkGcdStep _ _ hdenpos ?_))))))
  all_goals first
    | omega
    | (simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)

end rules

end F2e2e.C.Impl.BankDSL
