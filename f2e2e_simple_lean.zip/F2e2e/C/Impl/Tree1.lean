import F2e2e.C.Impl.Tree1Birth

/-!
# W6, Tree1: Step 1 of the round in the DSL (`step1_impl`)

Owner: Tree1 worker (4a7299ed). The deliverable `step1_impl`: on `[encStreamParams P, encState s]`
the body `body_step1` (index `Idx.step1 = 290`) implements C-ALG's `step1 P s` (`F2e2e/C/Alg/Round.lean`,
Algorithm `R:alg:within-round-tree` Step 1, partIII.tex L472–478):

* `d₀ = firstBorn H (t + 1)` (`firstBorn_val`, Tree1Born);
* the scheduled retirements `learners.take d₀`, `banks.take (d₀ + 1)` (library `take`);
* the depths `range' d₀ (H − d₀)` as `drop d₀ (range H)` (library `range`, `drop`);
* the birth loop (DSL-CALC `foldB` with the element routine `birthElem`; `birthLoop_impl`, invariant
  `StateOK 4`, the round counter and the length budget `|learners| + |remaining| ≤ H`,
  `|banks| + |remaining| ≤ H + 1`);
* the terminal accumulator `0`.
-/

namespace F2e2e.C.Impl.T1

open F2e2e F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top F2e2e.C.Impl.W6

attribute [local irreducible] Nat.clog Nat.log

/-- The state after the scheduled retirements (partIII.tex L472–473). -/
def take1 (s : State) (d0 : ℕ) : State :=
  { s with learners := s.learners.take d0, banks := s.banks.take (d0 + 1) }

theorem step1_eq (P : StreamParams) (s : State) :
    step1 P s = (birthLoop P (firstBorn P.H (s.t + 1))
      (List.range' (firstBorn P.H (s.t + 1)) (P.H - firstBorn P.H (s.t + 1)))
      (take1 s (firstBorn P.H (s.t + 1)))).bind (fun s2 => BitProg.pure { s2 with leaf := 0 }) :=
  rfl

/-- The depths `drop d₀ (range H)` as computed by the DSL are `range' d₀ (H − d₀)`. -/
theorem ds_val_eq (H d0 : ℕ) :
    encInts (((List.range H).map (fun i : ℕ => (i : ℤ))).drop d0) =
      encL encN (List.range' d0 (H - d0)) := by
  rw [← List.map_drop, drop_range_eq, encInts_eq_encL]
  simp only [encL, List.map_map]
  rfl

section Step1

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-- `n ↦ n + 1` on a natural number. -/
theorem ev_add_one {e : Expr} {n : ℕ} (h : EvalsVal prog M env [] (.inl e) (encN n))
    (hM : Nat.size (n + 1) + 1 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.add e (Expr.lit 1))) (encN (n + 1)) := by
  have hpos : 0 < Nat.size (n + 1) := Nat.size_pos.mpr (Nat.succ_pos n)
  have h1 : valSize (Val.int 1) ≤ M := by simp only [valSize_int, bitLen_one]; omega
  have e1 : encN (n + 1) = Val.int ((n : ℤ) + 1) := by simp [encN]
  rw [e1]
  exact ev_add h (EvalsVal.lit' h1) (by rw [← e1, valSize_encN]; exact hM)

variable {R : AdaRep}

/-- **The birth loop** (DSL-CALC `foldB` with the element routine `birthElem`). -/
theorem birthLoop_impl (hR : R.Valid) (hC : Contracts R prog M) (hT : Tree1Lib prog)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {d0 : ℕ} (hd0 : d0 < P.H) {s : State}
    (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) (hl : s.learners.length ≤ d0)
    (hb : s.banks.length ≤ d0 + 1) :
    Implements prog M [Val.list [encState R.enc s, encL encN (List.range' d0 (P.H - d0)),
      exVal P d0]] body_birthLoop (encState R.enc) (birthLoop P d0 (List.range' d0 (P.H - d0)) s) := by
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hA := hR.invariant P hP
  have hada := hR.enc_le P hP
  have hH := H_le P
  have hex := valSize_exVal_le P hd0.le
  have hlsz : valSize (encL encN (List.range' d0 (P.H - d0))) ≤ 1 + P.calL * (P.calL + 2) := by
    have h1 := valSize_encL_le encN (List.range' d0 (P.H - d0)) (P.calL + 1) (fun x hx => by
      rw [List.mem_range'_1] at hx
      rw [valSize_encN]
      have := size_le_self x
      omega)
    rw [List.length_range'] at h1
    have h2 : (P.H - d0) * (P.calL + 1 + 1) ≤ P.calL * (P.calL + 2) :=
      Nat.mul_le_mul (by omega) (by omega)
    omega
  have hcc : P.calL * (P.calL + 2) = P.calL ^ 2 + 2 * P.calL := by ring
  rw [birthLoop_eq_foldB]
  refine foldB_impl_idx hT.birthLoopStep hT.birthElem encN (encState R.enc) (exVal P d0)
    (fun d s => if s.failed then BitProg.pure s else birthDepth P d0 d s) (List.range' d0 (P.H - d0))
    (fun r s => StateOK P (R.ok P) 4 s ∧ s.t ≤ P.m ∧ s.learners.length + r.length ≤ P.H ∧
      s.banks.length + r.length ≤ P.H + 1)
    (stateSizeBound P (R.bound P)) ?_ ?_ ?_ ?_ s ⟨hs, ht, ?_, ?_⟩
  · -- the invariant
    rintro x r s' bits s'' hsuf ⟨h1, h2, h3, h4⟩ hrun
    obtain ⟨hx1, hx2⟩ := suffix_range' hsuf
    simp only [List.length_cons] at h3 h4
    by_cases hf : s'.failed
    · simp only [hf, if_true] at hrun
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hrun
      exact ⟨h1, h2, by omega, by omega⟩
    · simp only [hf, Bool.false_eq_true, if_false] at hrun
      obtain ⟨⟨h5, h6, h7⟩, h8⟩ := Always.of_run (always_and (birthDepth_ok hA (by norm_num) h1
        (d := x) (by omega) (by omega) (by omega) d0) (birthDepth_birth P d0 x s')) hrun
      exact ⟨h5, by rw [h8.1.1]; exact h2, by omega, by omega⟩
  · -- the element routine
    rintro x r s' hsuf ⟨h1, h2, h3, h4⟩
    obtain ⟨hx1, hx2⟩ := suffix_range' hsuf
    simp only [List.length_cons] at h3 h4
    exact birthElem_impl hR hC hT hP hM h1 h2 (by omega) (by omega) (by omega) hd0.le
  · -- the value bound
    rintro r s' - ⟨h1, h2, -, -⟩
    exact StateOK.valSize_encState_le hada h1 h2
  · -- the space
    omega
  · simp only [List.length_range']; omega
  · simp only [List.length_range']; omega

/-- **Step 1 of the round in the DSL** (C-TOP's contract `TreeHelpers.step1`, index `290`): on
`[encStreamParams P, encState R.enc s]` the body `body_step1` implements C-ALG's `step1 P s`. -/
theorem step1_impl {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    (hT : Tree1Lib prog) {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {s : State}
    (hs : StateInv P (R.ok P) s) (ht : s.t < P.m) (hf : s.failed = false) :
    Implements prog M [Val.list [encStreamParams P, encState R.enc s]] body_step1
      (encState R.enc) (step1 P s) := by
  -- (the failure flag is not needed: the DSL code implements `step1` on every state)
  have _ := hf
  obtain ⟨bpH, hbpH, hpHc⟩ := hC.w1.pH
  obtain ⟨bHC, hbHC, hHCc⟩ := hC.w1.peHC
  obtain ⟨bHP, hbHP, hHPc⟩ := hC.w1.peHP
  obtain ⟨hM1, hss0, hc1, hc3, hc12, hc23, hrb⟩ := sz_facts R P hM
  have hs4 : StateOK P (R.ok P) 4 s := hs.1
  have hA := hR.invariant P hP
  have hada := hR.enc_le P hP
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have hss : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs4 ht.le
  have hstM : valSize (encState R.enc s) ≤ M := hss.trans hSM
  have hp := valSize_encStreamParams_le P
  have hH := H_le P
  have hH1 := F2e2e.C.Alg.H_pos P
  have hcP := cP_add_hundred_le P
  have hm2 := m_add_two_le P
  have hHCle := eHC_le P
  have hHPle := eHP_le P
  have hXM : valSize (Val.list [encStreamParams P, encState R.enc s]) ≤ M := by
    rw [vs_pair]; omega
  have hlsz : valSize (Val.list (s.learners.map encLearner)) ≤ stateSizeBound P (R.bound P) := by
    have : valSize (Val.list (s.learners.map encLearner)) ≤ valSize (encState R.enc s) := by
      unfold encState; exact valSize_of_getElem?_le (k := 4) rfl
    omega
  have hbsz : valSize (Val.list (s.banks.map (encBank R.enc))) ≤ stateSizeBound P (R.bound P) := by
    have : valSize (Val.list (s.banks.map (encBank R.enc))) ≤ valSize (encState R.enc s) := by
      unfold encState; exact valSize_of_getElem?_le (k := 5) rfl
    omega
  have htsz : Nat.size (s.t + 1) ≤ cP P := Nat.size_le.mpr (by omega)
  have hHsz : Nat.size P.H ≤ P.calL := (size_le_self _).trans hH
  have hfbM : fbM P.H (s.t + 1) ≤ M := by unfold fbM S_pow2; omega
  have hpost : Always (step1 P s) (fun a => valSize (encState R.enc a) ≤ M) :=
    Always.mono (fun a h => (StateOK.valSize_encState_le hada h.1
        (by rw [h.2.1]; exact ht.le)).trans hSM)
      (always_and (step1_ok hA (by norm_num) hs4) (step1_frame P s))
  have hfb := firstBorn_val hT hH1 (by omega : 1 ≤ s.t + 1) hfbM
  have hd0 : firstBorn P.H (s.t + 1) < P.H := firstBorn_lt P.H (s.t + 1) hH1
  rw [step1_eq] at hpost ⊢
  generalize firstBorn P.H (s.t + 1) = d0 at hpost hfb hd0 ⊢
  have hd0sz : Nat.size d0 ≤ P.calL := (size_le_self _).trans (by omega)
  have hd1sz : Nat.size (d0 + 1) ≤ P.calL := (size_le_self _).trans (by omega)
  have hHCsz : Nat.size P.eHC ≤ 5 * P.calL ^ 3 := (size_le_self _).trans hHCle
  have hHPsz : Nat.size P.eHP ≤ 7 * P.calL ^ 2 := (size_le_self _).trans hHPle
  -- sizes of the library calls
  have hS1 : S_pow2 P.eHC ≤ M := by unfold S_pow2; omega
  have hS2 : S_pow2 P.eHP ≤ M := by unfold S_pow2; omega
  have htk1 := (take_spec hT.setStep hT.revAppendStep (s.learners.map encLearner) d0
    0).toVal.mono_M (M' := M) (by unfold S_take; omega)
  rw [← List.map_take] at htk1
  have htk2 := (take_spec hT.setStep hT.revAppendStep (s.banks.map (encBank R.enc)) (d0 + 1)
    0).toVal.mono_M (M' := M) (by unfold S_take; omega)
  rw [← List.map_take] at htk2
  have hHc : P.H * (Nat.size P.H + 2) ≤ P.calL * (P.calL + 2) := Nat.mul_le_mul hH (by omega)
  have hcc : P.calL * (P.calL + 2) = P.calL ^ 2 + 2 * P.calL := by ring
  have hrg := (range_spec hT.rangeStep P.H 0).toVal.mono_M (M' := M) (by unfold S_range; omega)
  have hil : valSize (encInts ((List.range P.H).map (fun i : ℕ => (i : ℤ)))) ≤
      1 + P.H * (P.calL + 2) := by
    have h := valSize_encInts_le ((List.range P.H).map (fun i : ℕ => (i : ℤ))) P.calL (fun z hz => by
      rw [List.mem_map] at hz
      obtain ⟨i, hi, rfl⟩ := hz
      rw [List.mem_range] at hi
      rw [bitLen_natCast]
      exact (size_le_self i).trans (by omega))
    simpa using h
  have hHc2 : P.H * (P.calL + 2) ≤ P.calL * (P.calL + 2) := Nat.mul_le_mul_right _ hH
  have hdr := (drop_spec_ints hT.setStep ((List.range P.H).map (fun i : ℕ => (i : ℤ))) d0
    0).toVal.mono_M (M' := M) (by unfold S_drop; change 7 * valSize (encInts _) + _ + _ ≤ M; omega)
  rw [ds_val_eq] at hdr
  -- the state after the retirements
  have hs1 : StateOK P (R.ok P) 4 (take1 s d0) := hs4.take d0 (d0 + 1)
  have hs1S : valSize (encState R.enc (take1 s d0)) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs1 ht.le
  have hs1M : valSize (encState R.enc (take1 s d0)) ≤ M := hs1S.trans hSM
  have hl1 : (take1 s d0).learners.length ≤ d0 := List.length_take_le _ _
  have hb1 : (take1 s d0).banks.length ≤ d0 + 1 := List.length_take_le _ _
  have hex := valSize_exVal_le P hd0.le
  have hexM : valSize (exVal P d0) ≤ M := by omega
  have hdsz : valSize (encL encN (List.range' d0 (P.H - d0))) ≤ 1 + P.calL * (P.calL + 2) := by
    have h1 := valSize_encL_le encN (List.range' d0 (P.H - d0)) (P.calL + 1) (fun x hx => by
      rw [List.mem_range'_1] at hx
      rw [valSize_encN]
      have := size_le_self x
      omega)
    rw [List.length_range'] at h1
    have h2 : (P.H - d0) * (P.calL + 1 + 1) ≤ P.calL * (P.calL + 2) :=
      Nat.mul_le_mul (by omega) (by omega)
    omega
  unfold body_step1
  -- p, st
  refine impl_letE_det (ev_get 0 (EvalsVal.var rfl) hXM rfl) ?_
  refine impl_letE_det (ev_get 1 (EvalsVal.var rfl) hXM rfl) ?_
  -- H
  refine impl_letE_det (evalsVal_call_det hbpH (EvalsVal.var rfl) (hpHc P hP hM)) ?_
  -- d₀
  refine impl_letE_det (evalsVal_call_det hT.firstBorn (ev_list (.cons (EvalsVal.var rfl)
    (.cons (ev_add_one (ev_get 0 (EvalsVal.var rfl) hstM rfl) (by omega)) .nil))
    (by simp only [vs_pair, valSize_int, valSize_encN, bitLen_natCast]; omega)) hfb) ?_
  -- eHC, 2^eHC, eHP, 2^eHP
  refine impl_letE_det (evalsVal_call_det hbHC (EvalsVal.var rfl) (hHCc P hP hM)) ?_
  refine impl_letE_det (evalsVal_call_det hT.pow2 (EvalsVal.var rfl)
    ((pow2_spec hT.pow2Step P.eHC 0).toVal.mono_M hS1)) ?_
  refine impl_letE_det (evalsVal_call_det hbHP (EvalsVal.var rfl) (hHPc P hP hM)) ?_
  refine impl_letE_det (evalsVal_call_det hT.pow2 (EvalsVal.var rfl)
    ((pow2_spec hT.pow2Step P.eHP 0).toVal.mono_M hS2)) ?_
  -- the retirements
  refine impl_letE_det (evalsVal_call_det hT.take (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl)
    (.cons (EvalsVal.var rfl) .nil))
    (by simp only [vs_pair, valSize_encN]; omega)) htk1) ?_
  refine impl_letE_det (evalsVal_call_det hT.take (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl)
    (.cons (ev_add_one (EvalsVal.var rfl) (by omega)) .nil))
    (by simp only [vs_pair, valSize_encN]; omega)) htk2) ?_
  -- the depths
  refine impl_letE_det (evalsVal_call_det hT.drop (ev_list (.cons (evalsVal_call_det hT.range
    (EvalsVal.var rfl) hrg) (.cons (EvalsVal.var rfl) .nil))
    (by simp only [vs_pair, valSize_encN]; omega)) hdr) ?_
  -- the birth loop
  refine impl_letE_run (implements_call_det hT.birthLoop (ev_list (.cons
    (ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 1 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl)
        (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl)
          .nil))))))) hs1M : EvalsVal _ _ _ _ (.inl _) (encState R.enc (take1 s d0)))
    (.cons (EvalsVal.var rfl) (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) .nil)))))) hexM : EvalsVal _ _ _ _ (.inl _) (exVal P d0)) .nil)))
    (by
      change valSize (Val.list [encState R.enc (take1 s d0), encL encN (List.range' d0 (P.H - d0)),
        exVal P d0]) ≤ M
      rw [vs_triple]; omega))
    (birthLoop_impl hR hC hT hP hM hd0 hs1 ht.le hl1 hb1)) (fun bits s2 hrun => ?_)
  -- the terminal accumulator
  have hq : valSize (encState R.enc { s2 with leaf := 0 }) ≤ M := always_of_bind_run hpost hrun
  obtain ⟨hs2, hfr⟩ := Always.of_run (always_and (birthLoop_ok hA (by norm_num) d0 (P.H - d0) d0
    (take1 s d0) (by omega) hs1 hl1 hb1) (birthLoop_frame1 P d0 _ (take1 s d0))) hrun
  have hs2M : valSize (encState R.enc s2) ≤ M :=
    (StateOK.valSize_encState_le hada hs2 (by rw [hfr.1]; exact ht.le)).trans hSM
  have h0M : valSize (Val.int 0) ≤ M := by simp only [valSize_int, bitLen_zero]; omega
  apply implements_pure
  have e : encState R.enc { s2 with leaf := 0 } = Val.list [Val.int (s2.t : ℤ),
      Val.int (if s2.failed then 1 else 0), Val.int (s2.fpSeed : ℤ), Val.int (s2.fpVal : ℤ),
      Val.list (s2.learners.map encLearner), Val.list (s2.banks.map (encBank R.enc)), Val.int 0] :=
    rfl
  rw [e] at hq ⊢
  exact ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hs2M rfl) (.cons (ev_get 1 (EvalsVal.var rfl) hs2M rfl)
    (.cons (ev_get 2 (EvalsVal.var rfl) hs2M rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hs2M rfl)
      (.cons (ev_get 4 (EvalsVal.var rfl) hs2M rfl) (.cons (ev_get 5 (EvalsVal.var rfl) hs2M rfl)
        (.cons (EvalsVal.lit' h0M) .nil))))))) hq

end Step1

end F2e2e.C.Impl.T1
