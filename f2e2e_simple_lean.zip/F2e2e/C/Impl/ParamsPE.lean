import F2e2e.C.Impl.HashW1
import F2e2e.Cost.ValRules

/-!
# W1 (public parameters, DSL), part 1: straight-line `ℕ` arithmetic for the value judgment

Owner: C-PARAMS (e26ae4ae). Work package W1 of `notes/C_IMPL_DESIGN.md`: the DSL routines computing the
public parameters of Theorem (C) (`F2e2e/C/ParamsDefs.lean`) from the Spec's `encStreamParams P`.
This file provides the generic machinery, stated for C-TOP's value judgment `EvalsVal`
(`F2e2e/Cost/Generic.lean`: no time and no peak bookkeeping, only "every produced value has size
`≤ M`"):

* `PE`: natural-number expressions (variables = de Bruijn indices into a numeric environment,
  literals, `+`, `*`, truncated subtraction of / division by a literal, `max`, and calls of routines
  `encN x ↦ encN (f x)`), compiled by `PE.toE` without auxiliary `let`s (operands of `max` and of
  the truncated subtraction are evaluated twice: time is free);
* `PE.evals`: if the environment values are `≤ A`, the literals are `≤ 4096 ≤ A`, the expression has
  at most `16` leaves and every call is correct on its argument (`PE.calls`), then the compiled code
  evaluates to `encN (e.val env)` with every value of size `≤ M`, as soon as
  `valSize (encN (A ^ 16)) ≤ M` (every node value is `≤ A ^ (its number of leaves)`, `PE.val_le`);
* `CE`, `chainE`, `ChainOK`, `chain_evals`: chains of `let`-bound elements (compiled `PE`s, or raw
  expressions with a given `EvalsVal` evaluation), each pushing a natural number with a *claimed*
  value, so that the environments stay short symbolic lists (`[P.T, P.H, …]`);
* `eNth` (list projection) and `eVars` (the list of some variables) with their `EvalsVal` rules;
* the routines called by W1 in the form required by `PE.calls`, for the value bound
  `A = Abnd P = 2^{8ℒ³}`: DSL-CALC's `clog2` and `pow2` (`F2e2e/Cost/Arith/Basic.lean`) and W2's
  `leastPrimeGE` / `irrPoly` (`F2e2e/C/Impl/HashW1.lean`).
-/

namespace F2e2e.C.Impl.W1

open F2e2e.Cost

variable {prog : List Expr} {M : ℕ}

/-! ## Deterministic rules with empty bit lists -/

theorem letE0 {env : List Val} {a b : Expr} {va vb : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : EvalsVal prog M (va :: env) [] (.inl b) vb) :
    EvalsVal prog M env [] (.inl (Expr.letE a b)) vb :=
  (EvalsVal.letE ha hb).cast_bits rfl

theorem call0 {env : List Val} {i : ℕ} {a body : Expr} {va vb : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hbody : prog[i]? = some body)
    (hb : EvalsVal prog M [va] [] (.inl body) vb) :
    EvalsVal prog M env [] (.inl (Expr.call i a)) vb :=
  (EvalsVal.call ha hbody hb).cast_bits rfl

theorem loop0 {env : List Val} {i : ℕ} {a : Expr} {va w : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hl : EvalsVal prog M [] [] (.inr (i, va)) w) :
    EvalsVal prog M env [] (.inl (Expr.loop i a)) w :=
  (EvalsVal.loop ha hl).cast_bits rfl

/-! ## Sizes of lists -/

theorem listSize_drop_le : ∀ (l : List Val) (k : ℕ), listSize (l.drop k) ≤ listSize l
  | [], k => by simp
  | _ :: _, 0 => le_rfl
  | v :: l, k + 1 => by
    simp only [List.drop_succ_cons, listSize_cons]
    have := listSize_drop_le l k
    omega

theorem valSize_le_listSize_of_mem : ∀ {l : List Val} {v : Val}, v ∈ l → valSize v ≤ listSize l
  | [], _, h => by simp at h
  | w :: l, v, h => by
    rcases List.mem_cons.mp h with rfl | h'
    · simp only [listSize_cons]; omega
    · have := valSize_le_listSize_of_mem h'
      simp only [listSize_cons]; omega

/-! ## List projections and lists of variables -/

/-- `tailᵏ e`. -/
def eTails : ℕ → Expr → Expr
  | 0, e => e
  | k + 1, e => Expr.un UnOp.tail (eTails k e)

/-- Element `k` of the list `e`: `head (tailᵏ e)`. -/
def eNth (k : ℕ) (e : Expr) : Expr := Expr.un UnOp.head (eTails k e)

theorem eTails_evals {env : List Val} {e : Expr} {l : List Val}
    (he : EvalsVal prog M env [] (.inl e) (Val.list l)) (hl : valSize (Val.list l) ≤ M) :
    ∀ k, k ≤ l.length → EvalsVal prog M env [] (.inl (eTails k e)) (Val.list (l.drop k))
  | 0, _ => by simpa only [eTails, List.drop_zero] using he
  | k + 1, hk => by
    have ih := eTails_evals he hl k (by omega)
    rw [List.drop_eq_getElem_cons (by omega)] at ih
    refine EvalsVal.tail ih ?_
    have h1 := listSize_drop_le l (k + 1)
    simp only [valSize_list] at hl ⊢
    omega

theorem eNth_evals {env : List Val} {e : Expr} {l : List Val} {v : Val}
    (he : EvalsVal prog M env [] (.inl e) (Val.list l)) (hl : valSize (Val.list l) ≤ M) {k : ℕ}
    (hk : l[k]? = some v) : EvalsVal prog M env [] (.inl (eNth k e)) v := by
  obtain ⟨hlt, hv⟩ := List.getElem?_eq_some_iff.mp hk
  have h := eTails_evals he hl k hlt.le
  rw [List.drop_eq_getElem_cons hlt, hv] at h
  refine EvalsVal.head h ?_
  have := valSize_le_listSize_of_mem (List.mem_of_getElem? hk)
  simp only [valSize_list] at hl
  omega

/-- The list `[var i₀, var i₁, …]`. -/
def eVars : List ℕ → Expr
  | [] => Expr.nil
  | i :: is => Expr.bin BinOp.cons (Expr.var i) (eVars is)

theorem eVars_evals {env : List Val} :
    ∀ (is : List ℕ) (vs : List Val), is.map (fun i => env[i]?) = vs.map some →
      valSize (Val.list vs) ≤ M → EvalsVal prog M env [] (.inl (eVars is)) (Val.list vs)
  | [], [], _, hM => EvalsVal.nil hM
  | [], _ :: _, h, _ => by simp at h
  | _ :: _, [], h, _ => by simp at h
  | i :: is, v :: vs, h, hM => by
    simp only [List.map_cons, List.cons.injEq] at h
    have hrest := eVars_evals is vs h.2
      (by simp only [valSize_list, listSize_cons] at hM ⊢; omega)
    exact (EvalsVal.cons (EvalsVal.var h.1) hrest hM).cast_bits rfl

/-! ## Callees -/

/-- The routine `j` of `prog` maps `encN x` to `encN (f x)`, every value of size `≤ M`. -/
def CalleeOK (prog : List Expr) (M j : ℕ) (f : ℕ → ℕ) (x : ℕ) : Prop :=
  ∃ body, prog[j]? = some body ∧ EvalsVal prog M [encN x] [] (.inl body) (encN (f x))

/-! ## Expressions -/

/-- Natural-number expressions: variables (de Bruijn indices into a numeric environment), literals,
`+`, `*`, truncated subtraction of a literal, division by a literal, `max`, and `call j f a` (the
routine `j`, computing `f`, applied to `a`). -/
inductive PE : Type where
  | var : ℕ → PE
  | lit : ℕ → PE
  | add : PE → PE → PE
  | mul : PE → PE → PE
  | subL : PE → ℕ → PE
  | divL : PE → ℕ → PE
  | maxE : PE → PE → PE
  | call : ℕ → (ℕ → ℕ) → PE → PE

namespace PE

/-- Semantics (`var i` reads `env[i]`, `0` if out of range). -/
def val (env : List ℕ) : PE → ℕ
  | var i => (env[i]?).getD 0
  | lit k => k
  | add a b => a.val env + b.val env
  | mul a b => a.val env * b.val env
  | subL a k => a.val env - k
  | divL a k => a.val env / k
  | maxE a b => Max.max (a.val env) (b.val env)
  | call _ f a => f (a.val env)

/-- Compilation (no auxiliary `let`s). -/
def toE : PE → Expr
  | var i => Expr.var i
  | lit k => Expr.lit (k : ℤ)
  | add a b => Expr.bin BinOp.add a.toE b.toE
  | mul a b => Expr.bin BinOp.mul a.toE b.toE
  | subL a k => Expr.ite (Expr.bin BinOp.lt a.toE (Expr.lit (k : ℤ))) (Expr.lit 0)
      (Expr.bin BinOp.sub a.toE (Expr.lit (k : ℤ)))
  | divL a k => Expr.bin BinOp.div a.toE (Expr.lit (k : ℤ))
  | maxE a b => Expr.ite (Expr.bin BinOp.lt a.toE b.toE) b.toE a.toE
  | call j _ a => Expr.call j a.toE

/-- Number of leaves (a call counts as its argument): every node value is `≤ A ^ leaves`. -/
def leaves : PE → ℕ
  | var _ => 1
  | lit _ => 1
  | add a b => a.leaves + b.leaves
  | mul a b => a.leaves + b.leaves
  | subL a _ => a.leaves + 1
  | divL a _ => a.leaves + 1
  | maxE a b => a.leaves + b.leaves
  | call _ _ a => a.leaves

/-- Syntactic conditions: variables `< n`, literals `≤ 4096`, nonzero divisors. -/
def wf (n : ℕ) : PE → Bool
  | var i => decide (i < n)
  | lit k => decide (k ≤ 4096)
  | add a b => a.wf n && b.wf n
  | mul a b => a.wf n && b.wf n
  | subL a k => a.wf n && decide (k ≤ 4096)
  | divL a k => a.wf n && (decide (k ≤ 4096) && decide (k ≠ 0))
  | maxE a b => a.wf n && b.wf n
  | call _ _ a => a.wf n

/-- The calls are correct on their arguments (arguments `≤ A ^ 16`, results `≤ A`). -/
def calls (prog : List Expr) (M A : ℕ) (env : List ℕ) : PE → Prop
  | var _ => True
  | lit _ => True
  | add a b => a.calls prog M A env ∧ b.calls prog M A env
  | mul a b => a.calls prog M A env ∧ b.calls prog M A env
  | subL a _ => a.calls prog M A env
  | divL a _ => a.calls prog M A env
  | maxE a b => a.calls prog M A env ∧ b.calls prog M A env
  | call j f a => a.calls prog M A env ∧
      ∀ x, x = a.val env → x ≤ A ^ 16 → CalleeOK prog M j f x ∧ f x ≤ A

theorem one_le_leaves : ∀ e : PE, 1 ≤ e.leaves
  | var _ => le_rfl
  | lit _ => le_rfl
  | add a _ => by have := one_le_leaves a; simp only [leaves]; omega
  | mul a _ => by have := one_le_leaves a; simp only [leaves]; omega
  | subL _ _ => by simp only [leaves]; omega
  | divL _ _ => by simp only [leaves]; omega
  | maxE a _ => by have := one_le_leaves a; simp only [leaves]; omega
  | call _ _ a => one_le_leaves a

theorem add_le_pow_add {A x y p q : ℕ} (hA : 2 ≤ A) (hp : 1 ≤ p) (hq : 1 ≤ q) (hx : x ≤ A ^ p)
    (hy : y ≤ A ^ q) : x + y ≤ A ^ (p + q) := by
  obtain ⟨s, hs⟩ : ∃ s, p + q = s + 1 := ⟨p + q - 1, by omega⟩
  have h1 : A ^ p ≤ A ^ s := Nat.pow_le_pow_right (by omega) (by omega)
  have h2 : A ^ q ≤ A ^ s := Nat.pow_le_pow_right (by omega) (by omega)
  rw [hs, pow_succ]
  have : A ^ s * 2 ≤ A ^ s * A := Nat.mul_le_mul_left _ hA
  omega

/-- Every node value is `≤ A ^ (its leaves)`. -/
theorem val_le {A : ℕ} {env : List ℕ} (hA : 4096 ≤ A) (henv : ∀ x ∈ env, x ≤ A) :
    ∀ e : PE, e.wf env.length = true → e.calls prog M A env → e.leaves ≤ 16 →
      e.val env ≤ A ^ e.leaves
  | var i, _, _, _ => by
      simp only [val, leaves, pow_one]
      cases h : env[i]? with
      | none => simp
      | some x => simpa using henv x (List.mem_of_getElem? h)
  | lit k, hwf, _, _ => by
      simp only [wf, decide_eq_true_eq] at hwf
      simp only [val, leaves, pow_one]
      omega
  | add a b, hwf, hc, hl => by
      simp only [wf, Bool.and_eq_true] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf.1 hc.1 (by omega)
      have hb := val_le hA henv b hwf.2 hc.2 (by omega)
      exact add_le_pow_add (by omega) (one_le_leaves a) (one_le_leaves b) ha hb
  | mul a b, hwf, hc, hl => by
      simp only [wf, Bool.and_eq_true] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf.1 hc.1 (by omega)
      have hb := val_le hA henv b hwf.2 hc.2 (by omega)
      simp only [val, pow_add]
      exact Nat.mul_le_mul ha hb
  | subL a k, hwf, hc, hl => by
      simp only [wf, Bool.and_eq_true] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf.1 hc (by omega)
      simp only [val]
      exact (Nat.sub_le _ _).trans (ha.trans (Nat.pow_le_pow_right (by omega) (by omega)))
  | divL a k, hwf, hc, hl => by
      simp only [wf, Bool.and_eq_true] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf.1 hc (by omega)
      simp only [val]
      exact (Nat.div_le_self _ _).trans (ha.trans (Nat.pow_le_pow_right (by omega) (by omega)))
  | maxE a b, hwf, hc, hl => by
      simp only [wf, Bool.and_eq_true] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf.1 hc.1 (by omega)
      have hb := val_le hA henv b hwf.2 hc.2 (by omega)
      simp only [val]
      exact max_le (ha.trans (Nat.pow_le_pow_right (by omega) (by omega)))
        (hb.trans (Nat.pow_le_pow_right (by omega) (by omega)))
  | call j f a, hwf, hc, hl => by
      simp only [wf] at hwf
      simp only [calls] at hc
      simp only [leaves] at hl ⊢
      have ha := val_le hA henv a hwf hc.1 hl
      have h16 : a.val env ≤ A ^ 16 := ha.trans (Nat.pow_le_pow_right (by omega) hl)
      have hfa := (hc.2 _ rfl h16).2
      simp only [val]
      calc f (a.val env) ≤ A := hfa
        _ = A ^ 1 := (pow_one A).symm
        _ ≤ A ^ a.leaves := Nat.pow_le_pow_right (by omega) (one_le_leaves a)

/-- **Evaluation of compiled expressions.** -/
theorem evals {A : ℕ} {env : List ℕ} (rest : List Val) (hA : 4096 ≤ A) (henv : ∀ x ∈ env, x ≤ A)
    (hM : valSize (encN (A ^ 16)) ≤ M) :
    ∀ e : PE, e.wf env.length = true → e.calls prog M A env → e.leaves ≤ 16 →
      EvalsVal prog M (env.map encN ++ rest) [] (.inl e.toE) (encN (e.val env)) := by
  have fits : ∀ v : ℕ, v ≤ A ^ 16 → valSize (Val.int (v : ℤ)) ≤ M := by
    intro v hv
    have h1 := Nat.size_le_size hv
    have h2 : valSize (Val.int (v : ℤ)) = Nat.size v + 1 := valSize_encN v
    rw [valSize_encN] at hM
    omega
  have hA16 : A ≤ A ^ 16 := Nat.le_self_pow (by norm_num) A
  have h2M : 2 ≤ M := by
    have h1 : 0 < Nat.size (A ^ 16) := Nat.size_pos.mpr (by positivity)
    rw [valSize_encN] at hM
    omega
  intro e
  induction e with
  | var i =>
    intro hwf _ _
    simp only [wf, decide_eq_true_eq] at hwf
    refine EvalsVal.var ?_
    rw [List.getElem?_append_left (by simpa using hwf), List.getElem?_map,
      List.getElem?_eq_getElem hwf]
    simp [val, List.getElem?_eq_getElem hwf]
  | lit k =>
    intro hwf _ _
    simp only [wf, decide_eq_true_eq] at hwf
    exact EvalsVal.lit (fits k (by omega))
  | add a b iha ihb =>
    intro hwf hc hl
    simp only [wf, Bool.and_eq_true] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf.1 hc.1 (by omega)
    have hb := ihb hwf.2 hc.2 (by omega)
    have hva := val_le hA henv a hwf.1 hc.1 (by omega)
    have hvb := val_le hA henv b hwf.2 hc.2 (by omega)
    have hs : a.val env + b.val env ≤ A ^ 16 :=
      (add_le_pow_add (by omega) (one_le_leaves a) (one_le_leaves b) hva hvb).trans
        (Nat.pow_le_pow_right (by omega) hl)
    have h := EvalsVal.add (x := ((a.val env : ℕ) : ℤ)) (y := ((b.val env : ℕ) : ℤ)) ha hb
      (by rw [← Nat.cast_add]; exact fits _ hs)
    rw [← Nat.cast_add] at h
    exact h.cast_bits rfl
  | mul a b iha ihb =>
    intro hwf hc hl
    simp only [wf, Bool.and_eq_true] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf.1 hc.1 (by omega)
    have hb := ihb hwf.2 hc.2 (by omega)
    have hva := val_le hA henv a hwf.1 hc.1 (by omega)
    have hvb := val_le hA henv b hwf.2 hc.2 (by omega)
    have hs : a.val env * b.val env ≤ A ^ 16 := by
      calc a.val env * b.val env ≤ A ^ a.leaves * A ^ b.leaves := Nat.mul_le_mul hva hvb
        _ = A ^ (a.leaves + b.leaves) := (pow_add A _ _).symm
        _ ≤ A ^ 16 := Nat.pow_le_pow_right (by omega) hl
    have h := EvalsVal.mul (x := ((a.val env : ℕ) : ℤ)) (y := ((b.val env : ℕ) : ℤ)) ha hb
      (by rw [← Nat.cast_mul]; exact fits _ hs)
    rw [← Nat.cast_mul] at h
    exact h.cast_bits rfl
  | subL a k iha =>
    intro hwf hc hl
    simp only [wf, Bool.and_eq_true, decide_eq_true_eq] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf.1 hc (by omega)
    have hva := val_le hA henv a hwf.1 hc (by omega)
    have hva16 : a.val env ≤ A ^ 16 := hva.trans (Nat.pow_le_pow_right (by omega) (by omega))
    have hk : EvalsVal prog M (env.map encN ++ rest) [] (.inl (Expr.lit (k : ℤ)))
        (Val.int ((k : ℕ) : ℤ)) := EvalsVal.lit (fits k (by omega))
    have hlt := EvalsVal.lt (x := ((a.val env : ℕ) : ℤ)) (y := ((k : ℕ) : ℤ)) ha hk h2M
    by_cases hak : a.val env < k
    · have hz : (if ((a.val env : ℕ) : ℤ) < ((k : ℕ) : ℤ) then (1 : ℤ) else 0) ≠ 0 := by
        rw [if_pos (by exact_mod_cast hak)]; norm_num
      have h0 : EvalsVal prog M (env.map encN ++ rest) [] (.inl (Expr.lit 0)) (Val.int 0) :=
        EvalsVal.lit (by simp only [valSize_int, bitLen_zero]; omega)
      have h := EvalsVal.ite_true (f := Expr.bin BinOp.sub a.toE (Expr.lit (k : ℤ))) hlt hz h0
      have e : encN ((subL a k).val env) = Val.int 0 := by
        simp only [val, encN, Nat.sub_eq_zero_of_le hak.le, Nat.cast_zero]
      rw [e]
      exact h.cast_bits rfl
    · have hz : (if ((a.val env : ℕ) : ℤ) < ((k : ℕ) : ℤ) then (1 : ℤ) else 0) = 0 := by
        rw [if_neg (by exact_mod_cast hak)]
      have hle : k ≤ a.val env := not_lt.mp hak
      have hsub := EvalsVal.sub (x := ((a.val env : ℕ) : ℤ)) (y := ((k : ℕ) : ℤ)) ha hk
        (by rw [← Nat.cast_sub hle]; exact fits _ ((Nat.sub_le _ _).trans hva16))
      have h := EvalsVal.ite_false (t := Expr.lit 0) hlt hz hsub
      rw [← Nat.cast_sub hle] at h
      exact h.cast_bits rfl
  | divL a k iha =>
    intro hwf hc hl
    simp only [wf, Bool.and_eq_true, decide_eq_true_eq] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf.1 hc (by omega)
    have hva := val_le hA henv a hwf.1 hc (by omega)
    have hva16 : a.val env ≤ A ^ 16 := hva.trans (Nat.pow_le_pow_right (by omega) (by omega))
    have hk : EvalsVal prog M (env.map encN ++ rest) [] (.inl (Expr.lit (k : ℤ)))
        (Val.int ((k : ℕ) : ℤ)) := EvalsVal.lit (fits k (by omega))
    have hk0 : ((k : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hwf.2.2
    have h := EvalsVal.div (x := ((a.val env : ℕ) : ℤ)) (y := ((k : ℕ) : ℤ)) ha hk hk0
      (by rw [← Int.natCast_ediv]; exact fits _ ((Nat.div_le_self _ _).trans hva16))
    rw [← Int.natCast_ediv] at h
    exact h.cast_bits rfl
  | maxE a b iha ihb =>
    intro hwf hc hl
    simp only [wf, Bool.and_eq_true] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf.1 hc.1 (by omega)
    have hb := ihb hwf.2 hc.2 (by omega)
    have hlt := EvalsVal.lt (x := ((a.val env : ℕ) : ℤ)) (y := ((b.val env : ℕ) : ℤ)) ha hb h2M
    by_cases hab : a.val env < b.val env
    · have hz : (if ((a.val env : ℕ) : ℤ) < ((b.val env : ℕ) : ℤ) then (1 : ℤ) else 0) ≠ 0 := by
        rw [if_pos (by exact_mod_cast hab)]; norm_num
      have h := EvalsVal.ite_true (f := a.toE) hlt hz hb
      have e : encN ((maxE a b).val env) = encN (b.val env) := by
        simp only [val, max_eq_right hab.le]
      rw [e]
      exact h.cast_bits rfl
    · have hz : (if ((a.val env : ℕ) : ℤ) < ((b.val env : ℕ) : ℤ) then (1 : ℤ) else 0) = 0 := by
        rw [if_neg (by exact_mod_cast hab)]
      have h := EvalsVal.ite_false (t := b.toE) hlt hz ha
      have e : encN ((maxE a b).val env) = encN (a.val env) := by
        simp only [val, max_eq_left (not_lt.mp hab)]
      rw [e]
      exact h.cast_bits rfl
  | call j f a iha =>
    intro hwf hc hl
    simp only [wf] at hwf
    simp only [calls] at hc
    simp only [leaves] at hl
    have ha := iha hwf hc.1 hl
    have hva := val_le hA henv a hwf hc.1 hl
    obtain ⟨⟨body, hbody, hcb⟩, -⟩ :=
      hc.2 _ rfl (hva.trans (Nat.pow_le_pow_right (by omega) hl))
    exact call0 ha hbody hcb

end PE

/-! ## Chains of `let`-bound elements -/

/-- A chain element: a compiled expression, or a raw expression (with a separately proved
evaluation). -/
inductive CE : Type where
  | pe : PE → CE
  | raw : Expr → CE

/-- The expression of a chain element. -/
def CE.toE : CE → Expr
  | CE.pe e => e.toE
  | CE.raw e => e

/-- `chainE [c₀, c₁, …] body = letE c₀ (letE c₁ (… body))`. -/
def chainE : List CE → Expr → Expr
  | [], body => body
  | c :: cs, body => Expr.letE c.toE (chainE cs body)

/-- The numeric environment after pushing `v₀, v₁, …` in turn. -/
def pushAll : List ℕ → List ℕ → List ℕ
  | [], env => env
  | v :: vs, env => pushAll vs (v :: env)

/-- The chain `cs` pushes the claimed values `vs` (each `≤ A`) on the numeric environment `env`
(followed by the values `rest`). -/
def ChainOK (prog : List Expr) (M A : ℕ) (rest : List Val) : List CE → List ℕ → List ℕ → Prop
  | [], [], _ => True
  | CE.pe e :: cs, v :: vs, env =>
      (e.wf env.length = true ∧ e.leaves ≤ 16 ∧ e.calls prog M A env ∧ e.val env = v ∧ v ≤ A) ∧
        ChainOK prog M A rest cs vs (v :: env)
  | CE.raw e :: cs, v :: vs, env =>
      (EvalsVal prog M (env.map encN ++ rest) [] (.inl e) (encN v) ∧ v ≤ A) ∧
        ChainOK prog M A rest cs vs (v :: env)
  | [], _ :: _, _ => False
  | CE.pe _ :: _, [], _ => False
  | CE.raw _ :: _, [], _ => False

theorem ChainOK.pe_cons {A : ℕ} {rest : List Val} {e : PE} {cs : List CE} {v : ℕ} {vs env : List ℕ}
    (hwf : e.wf env.length = true) (hl : e.leaves ≤ 16) (hc : e.calls prog M A env)
    (hv : e.val env = v) (hvA : v ≤ A) (hrest : ChainOK prog M A rest cs vs (v :: env)) :
    ChainOK prog M A rest (CE.pe e :: cs) (v :: vs) env :=
  ⟨⟨hwf, hl, hc, hv, hvA⟩, hrest⟩

theorem ChainOK.raw_cons {A : ℕ} {rest : List Val} {e : Expr} {cs : List CE} {v : ℕ}
    {vs env : List ℕ} (he : EvalsVal prog M (env.map encN ++ rest) [] (.inl e) (encN v))
    (hvA : v ≤ A) (hrest : ChainOK prog M A rest cs vs (v :: env)) :
    ChainOK prog M A rest (CE.raw e :: cs) (v :: vs) env :=
  ⟨⟨he, hvA⟩, hrest⟩

theorem ChainOK.nil {A : ℕ} {rest : List Val} {env : List ℕ} :
    ChainOK prog M A rest [] [] env :=
  trivial

/-- **Evaluation of a chain.** -/
theorem chain_evals {A : ℕ} (rest : List Val) (hA : 4096 ≤ A) (hM : valSize (encN (A ^ 16)) ≤ M) :
    ∀ (cs : List CE) (vs env : List ℕ) (body : Expr) (out : Val),
      ChainOK prog M A rest cs vs env → (∀ x ∈ env, x ≤ A) →
      ((∀ x ∈ pushAll vs env, x ≤ A) →
        EvalsVal prog M ((pushAll vs env).map encN ++ rest) [] (.inl body) out) →
      EvalsVal prog M (env.map encN ++ rest) [] (.inl (chainE cs body)) out
  | [], [], _, _, _, _, henv, hb => hb henv
  | [], _ :: _, _, _, _, h, _, _ => h.elim
  | CE.pe _ :: _, [], _, _, _, h, _, _ => h.elim
  | CE.raw _ :: _, [], _, _, _, h, _, _ => h.elim
  | CE.pe e :: cs, v :: vs, env, body, out, h, henv, hb => by
      obtain ⟨⟨hwf, hl, hc, hv, hvA⟩, hrest⟩ := h
      have he := PE.evals rest hA henv hM e hwf hc hl
      rw [hv] at he
      have henv' : ∀ x ∈ v :: env, x ≤ A := by
        intro x hx
        rcases List.mem_cons.mp hx with rfl | hx
        · exact hvA
        · exact henv x hx
      exact letE0 he (chain_evals rest hA hM cs vs (v :: env) body out hrest henv' hb)
  | CE.raw e :: cs, v :: vs, env, body, out, h, henv, hb => by
      obtain ⟨⟨he, hvA⟩, hrest⟩ := h
      have henv' : ∀ x ∈ v :: env, x ≤ A := by
        intro x hx
        rcases List.mem_cons.mp hx with rfl | hx
        · exact hvA
        · exact henv x hx
      exact letE0 he (chain_evals rest hA hM cs vs (v :: env) body out hrest henv' hb)

/-! ## The value bound `A = 2^{8ℒ³}` -/

/-- The value bound of the parameter computations: `A = 2^{8ℒ³}` (every public parameter and
every intermediate result is `≤ A ^ 16 = 2^{128ℒ³}`, far below C-TOP's value bound
`Mv R P ≥ 2^37 ℒ³` bits). -/
def Abnd (P : StreamParams) : ℕ := 2 ^ (8 * P.calL ^ 3)

theorem calL_cube_ge (P : StreamParams) : 1000000 ≤ P.calL ^ 3 := by
  have h := Space.hundred_le_calL P
  calc 1000000 = 100 ^ 3 := by norm_num
    _ ≤ P.calL ^ 3 := Nat.pow_le_pow_left h 3

theorem le_Abnd_of_le_two_pow {P : StreamParams} {x k : ℕ} (hx : x ≤ 2 ^ k)
    (hk : k ≤ 8 * P.calL ^ 3) : x ≤ Abnd P :=
  hx.trans (Nat.pow_le_pow_right (by norm_num) hk)

/-- Polynomially bounded values are `≤ A`. -/
theorem le_Abnd_of_le {P : StreamParams} {x : ℕ} (hx : x ≤ 2 ^ 10 * P.calL ^ 3) : x ≤ Abnd P := by
  have hL := Space.hundred_le_calL P
  have h4 : P.calL ^ 4 ≤ 2 ^ P.calL := Space.pow_four_le_two_pow (by omega)
  have h34 : P.calL ^ 3 ≤ P.calL ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
  have h1 : x ≤ 2 ^ (10 + P.calL) := by
    rw [pow_add]
    calc x ≤ 2 ^ 10 * P.calL ^ 3 := hx
      _ ≤ 2 ^ 10 * 2 ^ P.calL := Nat.mul_le_mul_left _ (h34.trans h4)
  refine le_Abnd_of_le_two_pow h1 ?_
  have : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _
  omega

theorem four096_le_Abnd (P : StreamParams) : 4096 ≤ Abnd P :=
  le_Abnd_of_le (by have := calL_cube_ge P; omega)

/-- `valSize (encN (A ^ 16)) = 128ℒ³ + 2 ≤ 2^37 ℒ³`. -/
theorem valSize_Abnd_pow_le {P : StreamParams} (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    valSize (encN (Abnd P ^ 16)) ≤ M := by
  rw [valSize_encN, Abnd, ← pow_mul, Nat.size_pow]
  have := calL_cube_ge P
  omega

/-! ## The routines called by W1 -/

/-- DSL-CALC's `clog2` (index `102`) on arguments `≤ A ^ 16`. -/
theorem clog2_node {P : StreamParams} (h1 : prog[Cost.Idx.clog2]? = some body_clog2)
    (h2 : prog[Cost.Idx.clog2Step]? = some body_clog2Step) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M)
    (x : ℕ) (hx : x ≤ Abnd P ^ 16) :
    CalleeOK prog M Cost.Idx.clog2 (Nat.clog 2) x ∧ Nat.clog 2 x ≤ Abnd P := by
  have hsz : Nat.size x ≤ 128 * P.calL ^ 3 + 1 := by
    have h := Nat.size_le_size hx
    rw [Abnd, ← pow_mul, Nat.size_pow] at h
    omega
  have hc := calL_cube_ge P
  refine ⟨⟨body_clog2, h1, (clog2_spec h2 x 0).toVal.mono_M ?_⟩, ?_⟩
  · simp only [S_clog2]
    omega
  · exact le_Abnd_of_le ((clog2_le_size x).trans (by omega))

/-- DSL-CALC's `pow2` (index `100`) on exponents `≤ 8ℒ³`. -/
theorem pow2_node {P : StreamParams} (h1 : prog[Cost.Idx.pow2]? = some body_pow2)
    (h2 : prog[Cost.Idx.pow2Step]? = some body_pow2Step) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M)
    (x : ℕ) (hx : x ≤ 8 * P.calL ^ 3) :
    CalleeOK prog M Cost.Idx.pow2 (fun k => 2 ^ k) x ∧ 2 ^ x ≤ Abnd P := by
  refine ⟨⟨body_pow2, h1, (pow2_spec h2 x 0).toVal.mono_M ?_⟩,
    Nat.pow_le_pow_right (by norm_num) hx⟩
  have := size_le_self x
  have hc := calL_cube_ge P
  simp only [S_pow2]
  omega

/-- W2's `leastPrimeGE` (index `202`) on `M_q`: the fingerprint prime `q`. -/
theorem lp_node {P : StreamParams} (hL : HashDSL.FpLib prog) (hP : C.Top.ParamsOK P)
    (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    CalleeOK prog M Cost.Idx.leastPrimeGE Hash.leastPrimeGE P.Mq ∧
      Hash.leastPrimeGE P.Mq ≤ Abnd P := by
  have hq := HashDSL.leastPrimeGE_Mq P (W2.one_le_Mq P hP)
  have hM20 : 2 ^ 20 * P.calL ^ 3 ≤ M :=
    le_trans (Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) (by norm_num))) hM
  refine ⟨⟨HashDSL.body_leastPrimeGE, hL.leastPrimeGE, ?_⟩, ?_⟩
  · rw [hq]
    exact leastPrimeGE_q_val hL P hP hM20
  · rw [hq]
    refine le_Abnd_of_le_two_pow (Space.q_le P) ?_
    have := calL_cube_ge P
    have : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _
    omega

/-- W2's `irrPoly` (index `167`) on `w`: the field polynomial `irrW P`. -/
theorem irr_node {P : StreamParams} (hL : HashDSL.HashLib prog) (hM : 2 ^ 37 * P.calL ^ 3 ≤ M) :
    CalleeOK prog M Cost.Idx.irrPoly Hash.irrPoly P.w ∧ Hash.irrPoly P.w ≤ Abnd P := by
  have hM20 : 2 ^ 20 * P.calL ^ 3 ≤ M :=
    le_trans (Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) (by norm_num))) hM
  refine ⟨⟨HashDSL.body_irrPoly, hL.irrPoly, irrPoly_w_val hL P hM20⟩, ?_⟩
  obtain ⟨-, hp2, -⟩ := HashDSL.isIrrPoly_irrW P (W2.one_le_Dstar P)
  refine le_Abnd_of_le_two_pow hp2.le ?_
  have := Space.w_le P
  have := calL_cube_ge P
  have : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _
  omega

end F2e2e.C.Impl.W1
