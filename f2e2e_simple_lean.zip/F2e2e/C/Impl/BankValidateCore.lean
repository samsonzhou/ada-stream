import F2e2e.C.Impl.BankQuery

/-!
# W5: `ValidateInterval` (756) in the DSL

Owner: B-ACC (6f8aab0c), for W5 (c1b4f720). `ReleaseNumerical` (757) is in
`F2e2e/C/Impl/BankValidate.lean`, which imports this file.

`validate_spec`: `body_validate` implements C-ALG's `Bank.validate P B S θ` (`F2e2e/C/Alg/Bank.lean`,
partIII.tex L210–213) on `[encStreamParams P, encBank B, encQ S, encQ θ]`:
`c = S + ω` as the fraction `(S.num 2^{eOmega} + S.den) / (S.den 2^{eOmega})`, the query table
`adaVals P PRIMARY c B` (W5's `bkValsQ`), the endpoints `(1 ∓ θ)/L` (W5's `normQ`) and W4's
`adaInterval` (through `W4Contract`); the output is `[cert, encBank B']` with the updated ADA state.
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete


/-! ## Arithmetic facts -/

/-- Reduced fractions: `|num (a/b)| ≤ |a|` and `den (a/b) ≤ b` for `b > 0`. -/
theorem num_den_div_le (a b : ℤ) (hb : 0 < b) :
    |((a : ℚ) / (b : ℚ)).num| ≤ |a| ∧ ((((a : ℚ) / (b : ℚ)).den : ℕ) : ℤ) ≤ b := by
  obtain ⟨hnum, hden⟩ := normQ_num_den a b hb
  refine ⟨?_, ?_⟩
  · rw [hnum]
    exact Int.abs_ediv_le_abs _ _
  · rw [hden]
    exact Int.ediv_le_self _ hb.le

theorem bitLen_le_of_abs_le_two_pow {z : ℤ} {k : ℕ} (h : |z| ≤ 2 ^ k) : bitLen z ≤ k + 1 := by
  apply bitLen_le_of_abs_lt
  calc |z| ≤ 2 ^ k := h
    _ < 2 ^ (k + 1) := by
        have : (0 : ℤ) < 2 ^ k := by positivity
        rw [pow_succ]
        linarith

theorem omega_eq (P : StreamParams) : P.omega = 1 / (2 : ℚ) ^ P.eOmega := by
  unfold StreamParams.omega StreamParams.sigma StreamParams.eOmega
  rw [← pow_mul, one_div_pow, mul_comm]

/-- The scale `c = S + ω` as the fraction `(S.num 2^e + S.den)/(S.den 2^e)`, `ω = 2^{-e}`. -/
theorem validate_scale_eq (P : StreamParams) (S : ℚ) :
    (((S.num * 2 ^ P.eOmega + (S.den : ℤ) : ℤ) : ℚ) / (((S.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ)) =
      S + P.omega := by
  rw [omega_eq]
  have hd : (S.den : ℚ) ≠ 0 := by exact_mod_cast S.den_nz
  have h2 : (2 : ℚ) ^ P.eOmega ≠ 0 := by positivity
  have hS : S = (S.num : ℚ) / (S.den : ℚ) := (Rat.num_div_den S).symm
  conv_rhs => rw [hS]
  push_cast
  field_simp

/-- The endpoints `(1 ∓ θ)/L` as fractions of integers. -/
theorem validate_lo_eq (θ : ℚ) (L : ℕ) :
    ((((θ.den : ℤ) - θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * (L : ℤ) : ℤ) : ℚ)) = (1 - θ) / (L : ℚ) := by
  have hd : (θ.den : ℚ) ≠ 0 := by exact_mod_cast θ.den_nz
  have hθ : θ = (θ.num : ℚ) / (θ.den : ℚ) := (Rat.num_div_den θ).symm
  rcases Nat.eq_zero_or_pos L with hL | hL
  · subst hL
    simp
  · have hL' : (L : ℚ) ≠ 0 := by exact_mod_cast hL.ne'
    conv_rhs => rw [hθ]
    push_cast
    field_simp

theorem validate_hi_eq (θ : ℚ) (L : ℕ) :
    ((((θ.den : ℤ) + θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * (L : ℤ) : ℤ) : ℚ)) = (1 + θ) / (L : ℚ) := by
  have hd : (θ.den : ℚ) ≠ 0 := by exact_mod_cast θ.den_nz
  have hθ : θ = (θ.num : ℚ) / (θ.den : ℚ) := (Rat.num_div_den θ).symm
  rcases Nat.eq_zero_or_pos L with hL | hL
  · subst hL
    simp
  · have hL' : (L : ℚ) ≠ 0 := by exact_mod_cast hL.ne'
    conv_rhs => rw [hθ]
    push_cast
    field_simp

/-- `θ ∈ (0, 1]`: `0 < θ.num ≤ θ.den`. -/
theorem num_pos_le_den {θ : ℚ} (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) : 0 < θ.num ∧ θ.num ≤ (θ.den : ℤ) := by
  refine ⟨Rat.num_pos.mpr hθ0, ?_⟩
  have h := Rat.mul_den_eq_num θ
  have hd : (0 : ℚ) < θ.den := by exact_mod_cast θ.den_pos
  have h2 : (θ.num : ℚ) ≤ (θ.den : ℚ) := by
    rw [← h]
    calc θ * (θ.den : ℚ) ≤ 1 * (θ.den : ℚ) := mul_le_mul_of_nonneg_right hθ1 hd.le
      _ = θ.den := one_mul _
  exact_mod_cast h2

/-! ## Rules -/

section rules

variable {prog : List Expr} {M : ℕ} {env : List Val}

/-- `letE` whose continuation only needs to implement `f a` for the outputs `a` of `p`. -/
theorem impl_letE_of_run {α β : Type} {ea eb : Expr} {encA : α → Val} {encC : β → Val}
    {p : BitProg α} {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

theorem encBank_eq (enc : AdaState → Val) (B : Bank) :
    encBank enc B = Val.list [encL (encL encRow) B.ada,
      Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))),
      enc B.adaSt] := rfl

theorem valSize_encBank_parts (enc : AdaState → Val) (B : Bank) :
    valSize (encL (encL encRow) B.ada) +
      valSize (Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow)))) +
      valSize (enc B.adaSt) ≤ valSize (encBank enc B) := by
  rw [encBank_eq]
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem ev_bank_ada {enc : AdaState → Val} {B : Bank} {e : Expr}
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eHd e)) (encL (encL encRow) B.ada) := by
  rw [encBank_eq] at h hs
  exact ev_hd h hs

theorem ev_bank_coarse {enc : AdaState → Val} {B : Bank} {e : Expr}
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt1 e))
      (Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow)))) := by
  rw [encBank_eq] at h hs
  exact ev_at1 h hs

theorem ev_bank_st {enc : AdaState → Val} {B : Bank} {e : Expr}
    (h : EvalsVal prog M env [] (.inl e) (encBank enc B)) (hs : valSize (encBank enc B) ≤ M) :
    EvalsVal prog M env [] (.inl (eAt2 e)) (enc B.adaSt) := by
  rw [encBank_eq] at h hs
  exact ev_at2 h hs

end rules

/-! ## `ValidateInterval` (756) -/

section validate

variable {prog : List Expr} {M : ℕ}

set_option maxHeartbeats 1000000 in
/-- **756 (`W5Contract.validate`).** -/
theorem validate_spec (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (hw2 : HornerLib prog) (hw4 : W4Contract R prog M) (P : StreamParams) (B : Bank) (S θ : ℚ)
    (hP : ParamsOK P) (hB : BankOK P (R.ok P) B) (hS0 : 0 ≤ S) (hSA : S ≤ (P.Amax : ℚ))
    (hSq : QOK P S) (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (hθd : (θ.den : ℤ) ≤ 2 ^ (2 * regBits P))
    (hM : Mv R P ≤ M) :
    Implements prog M [Val.list [encStreamParams P, encBank R.enc B, encQ S, encQ θ]] body_validate
      (fun r => Val.list [encCert r.1, encBank R.enc r.2]) (B.validate P S θ) := by
  have _hyp : S ≤ (P.Amax : ℚ) := hSA
  -- size facts
  have hs1 := bank_size_le R hR hP hB
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hc100 := hundred_le_calL P
  obtain ⟨hc3, hc2⟩ := W2.calL_pow_bounds P
  have hreg : regBits P = 2 ^ 7 * P.calL ^ 3 := rfl
  have hbs_ge : R.bound P ≤ bankSizeBound P (R.bound P) := by unfold bankSizeBound; omega
  have hpub := hR.pub_le P hP
  have henc := hR.enc_le P hP B.adaSt hB.ada_ok
  have heO := eOmega_le P
  have heS := eSigma_le P
  have heH := eHb_le P
  have hsP := s_le P
  -- the rationals
  obtain ⟨hSn, hSd⟩ := hSq
  have hSnum0 : 0 ≤ S.num := Rat.num_nonneg.mpr hS0
  have hSden0 : (0 : ℤ) < S.den := by exact_mod_cast S.den_pos
  obtain ⟨hθn0, hθnd⟩ := num_pos_le_den hθ0 hθ1
  have hθden0 : (0 : ℤ) < θ.den := by exact_mod_cast θ.den_pos
  have hbSn : bitLen S.num ≤ 2 ^ 9 * P.calL ^ 3 + 1 := by
    have := bitLen_le_of_abs_le_two_pow hSn; rw [hreg] at this; omega
  have hbSd : bitLen (S.den : ℤ) ≤ 2 ^ 9 * P.calL ^ 3 + 1 := by
    have := bitLen_le_of_abs_le_two_pow (z := (S.den : ℤ)) (by rw [abs_of_pos hSden0]; exact hSd)
    rw [hreg] at this; omega
  have hbθd : bitLen (θ.den : ℤ) ≤ 2 ^ 8 * P.calL ^ 3 + 1 := by
    have := bitLen_le_of_abs_le_two_pow (z := (θ.den : ℤ)) (by rw [abs_of_pos hθden0]; exact hθd)
    rw [hreg] at this; omega
  have hbθn : bitLen θ.num ≤ 2 ^ 8 * P.calL ^ 3 + 1 := by
    have h1 : |θ.num| ≤ 2 ^ (2 * regBits P) := by rw [abs_of_pos hθn0]; exact hθnd.trans hθd
    have := bitLen_le_of_abs_le_two_pow h1
    rw [hreg] at this; omega
  have hbO : bitLen ((2 : ℤ) ^ P.eOmega) = P.eOmega + 1 := bitLen_two_pow _
  -- cN, cD
  have hbSnO : bitLen (S.num * 2 ^ P.eOmega) ≤ 2 ^ 9 * P.calL ^ 3 + 14 * P.calL ^ 3 + 2 := by
    have := bitLen_mul_le' S.num ((2 : ℤ) ^ P.eOmega); omega
  have hbcN : bitLen (S.num * 2 ^ P.eOmega + (S.den : ℤ)) ≤ 2 ^ 10 * P.calL ^ 3 := by
    have := bitLen_add_le (S.num * 2 ^ P.eOmega) (S.den : ℤ)
    have : max (bitLen (S.num * 2 ^ P.eOmega)) (bitLen (S.den : ℤ)) ≤
        2 ^ 9 * P.calL ^ 3 + 14 * P.calL ^ 3 + 2 := max_le hbSnO (by omega)
    omega
  have hbcD : bitLen ((S.den : ℤ) * 2 ^ P.eOmega) ≤ 2 ^ 10 * P.calL ^ 3 := by
    have := bitLen_mul_le' (S.den : ℤ) ((2 : ℤ) ^ P.eOmega); omega
  have hcN0 : 0 < S.num * 2 ^ P.eOmega + (S.den : ℤ) := by
    have : 0 ≤ S.num * 2 ^ P.eOmega := mul_nonneg hSnum0 (by positivity)
    omega
  have hcD0 : 0 < (S.den : ℤ) * 2 ^ P.eOmega := mul_pos hSden0 (by positivity)
  -- L and the endpoints
  have hL : (P.L : ℕ) ≤ 48 * P.calL := by unfold StreamParams.L; omega
  have hLpos : 0 < P.L := by unfold StreamParams.L StreamParams.s; omega
  have hLz : (0 : ℤ) < (P.L : ℤ) := by exact_mod_cast hLpos
  have hbL : bitLen (P.L : ℤ) ≤ 48 * P.calL := bitLen_natCast_le_of_le hL
  have hb0 : (0 : ℤ) < (θ.den : ℤ) * P.L := mul_pos hθden0 hLz
  have hbθdL : bitLen ((θ.den : ℤ) * P.L) ≤ 2 ^ 8 * P.calL ^ 3 + 48 * P.calL + 1 := by
    have := bitLen_mul_le' (θ.den : ℤ) (P.L : ℤ); omega
  have hblo : bitLen ((θ.den : ℤ) - θ.num) ≤ 2 ^ 8 * P.calL ^ 3 + 1 := by
    refine le_trans (bitLen_le_bitLen_of_natAbs_le (b := (θ.den : ℤ)) ?_) hbθd
    omega
  have hbhi : bitLen ((θ.den : ℤ) + θ.num) ≤ 2 ^ 8 * P.calL ^ 3 + 2 := by
    have := bitLen_add_le (θ.den : ℤ) θ.num
    have : max (bitLen (θ.den : ℤ)) (bitLen θ.num) ≤ 2 ^ 8 * P.calL ^ 3 + 1 := max_le hbθd hbθn
    omega
  -- QOK of the endpoints
  have hpow4 : (2 : ℤ) ^ (2 * regBits P) * 2 ^ (2 * regBits P) = 2 ^ (4 * regBits P) := by
    rw [← pow_add, show 2 * regBits P + 2 * regBits P = 4 * regBits P by ring]
  have hLle : (P.L : ℤ) ≤ 2 ^ (2 * regBits P) := by
    have h1 : P.L < 2 ^ P.L := Nat.lt_two_pow_self
    have hL2 : P.L ≤ 2 * regBits P := by rw [hreg]; omega
    have h2 : 2 ^ P.L ≤ 2 ^ (2 * regBits P) := Nat.pow_le_pow_right (by norm_num) hL2
    have h3 : (P.L : ℤ) < ((2 ^ P.L : ℕ) : ℤ) := by exact_mod_cast h1
    have h4 : ((2 ^ P.L : ℕ) : ℤ) ≤ ((2 ^ (2 * regBits P) : ℕ) : ℤ) := by exact_mod_cast h2
    push_cast at h3 h4
    linarith
  have hpow2le : (2 : ℤ) ^ (2 * regBits P) ≤ 2 ^ (4 * regBits P) :=
    pow_le_pow_right₀ (by norm_num) (by omega)
  have hden4 : (θ.den : ℤ) * P.L ≤ 2 ^ (4 * regBits P) := by
    rw [← hpow4]
    exact mul_le_mul hθd hLle hLz.le (by positivity)
  have hQlo : QOK P ((((θ.den : ℤ) - θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * P.L : ℤ) : ℚ)) := by
    obtain ⟨h1, h2⟩ := num_den_div_le ((θ.den : ℤ) - θ.num) ((θ.den : ℤ) * P.L) hb0
    refine ⟨h1.trans ?_, h2.trans hden4⟩
    rw [abs_of_nonneg (by omega)]
    linarith
  have hQhi : QOK P ((((θ.den : ℤ) + θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * P.L : ℤ) : ℚ)) := by
    obtain ⟨h1, h2⟩ := num_den_div_le ((θ.den : ℤ) + θ.num) ((θ.den : ℤ) * P.L) hb0
    refine ⟨h1.trans ?_, h2.trans hden4⟩
    rw [abs_of_nonneg (by omega)]
    have h3 : (2 : ℤ) * 2 ^ (2 * regBits P) ≤ 2 ^ (4 * regBits P) := by
      rw [← hpow4]
      have : (2 : ℤ) ≤ 2 ^ (2 * regBits P) := by
        calc (2 : ℤ) = 2 ^ 1 := by norm_num
          _ ≤ 2 ^ (2 * regBits P) := pow_le_pow_right₀ (by norm_num) (by rw [hreg]; omega)
      exact mul_le_mul_of_nonneg_right this (by positivity)
    linarith
  -- sizes of the encoded endpoints
  have hsizeQ : ∀ x : ℚ, QOK P x → valSize (encQ x) ≤ 2 ^ 11 * P.calL ^ 3 := by
    intro x hx
    obtain ⟨h1, h2⟩ := hx
    have hb1 := bitLen_le_of_abs_le_two_pow h1
    have hb2 := bitLen_le_of_abs_le_two_pow (z := (x.den : ℤ))
      (by rw [abs_of_pos (by exact_mod_cast x.den_pos)]; exact h2)
    simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil]
    rw [hreg] at hb1 hb2
    omega
  have hSs := hsizeQ S ⟨hSn, hSd⟩
  have hθs : valSize (encQ θ) ≤ 2 ^ 11 * P.calL ^ 3 := by
    simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hlos := hsizeQ _ hQlo
  have hhis := hsizeQ _ hQhi
  -- the input
  have hI : valSize (Val.list [encStreamParams P, encBank R.enc B, encQ S, encQ θ]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hs1 ⊢
    omega
  -- auxiliary sizes
  have hs1' : valSize (encBank R.enc B) ≤ M := by omega
  have hparts := valSize_encBank_parts R.enc B
  have hSqs : valSize (Val.list [Val.int S.num, Val.int (S.den : ℤ)]) ≤ M := by
    have : valSize (encQ S) ≤ 2 ^ 11 * P.calL ^ 3 := hSs
    simp only [encQ] at this
    omega
  have hθqs : valSize (Val.list [Val.int θ.num, Val.int (θ.den : ℤ)]) ≤ M := by
    have : valSize (encQ θ) ≤ 2 ^ 11 * P.calL ^ 3 := hθs
    simp only [encQ] at this
    omega
  have hpowO : Cost.S_pow2 P.eOmega ≤ M := by
    have := size_le_self P.eOmega
    simp only [Cost.S_pow2]
    omega
  have hzxs : valSize (zxVal P Mode.primary) ≤ 2 ^ 6 * P.calL ^ 3 := by
    have hw := w_le P
    have hwb : bitLen (P.w : ℤ) ≤ 3 * P.calL + 1 := bitLen_natCast_le_of_le hw
    obtain ⟨-, hirr, -⟩ := isIrrPoly_irrW P (W2.one_le_Dstar P)
    have hirrb : bitLen (irrW P : ℤ) ≤ 3 * P.calL + 2 :=
      (bitLen_nat_le_of_lt hirr).trans (by omega)
    have hDb : bitLen (P.Dstar : ℤ) ≤ 3 * P.calL + 1 := by
      have h1 := Dstar_le P
      have h2 : P.Dstar < 2 ^ (3 * P.calL + 1) :=
        lt_of_le_of_lt h1 (Nat.pow_lt_pow_right (by norm_num) (by omega))
      exact bitLen_nat_le_of_lt h2
    simp only [zxVal, encMode, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_pow,
      bitLen_zero]
    omega
  have hqA := hR.qA_le P hP
  have hbig : bitLen ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) *
      (S.num * 2 ^ P.eOmega + (S.den : ℤ))) ≤ 2 ^ 11 * P.calL ^ 3 := by
    have h1 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ))
      (S.num * 2 ^ P.eOmega + (S.den : ℤ))
    have h2 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma))) (P.L : ℤ)
    rw [bitLen_two_pow] at h2
    omega
  have hqxs : valSize (qxVal P Mode.primary (S.num * 2 ^ P.eOmega + (S.den : ℤ))
      ((S.den : ℤ) * 2 ^ P.eOmega)) ≤ 2 ^ 13 * P.calL ^ 3 + R.bound P := by
    simp only [qxVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_pow] at hzxs ⊢
    omega
  -- the program
  have hprog : B.validate P S θ = (adaInterval (bankAda P) B.adaSt
      (adaVals P Mode.primary (((S.num * 2 ^ P.eOmega + (S.den : ℤ) : ℤ) : ℚ) /
        (((S.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ)) B)
      ((((θ.den : ℤ) - θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * P.L : ℤ) : ℚ))
      ((((θ.den : ℤ) + θ.num : ℤ) : ℚ) / (((θ.den : ℤ) * P.L : ℤ) : ℚ))).bind
      (fun res => BitProg.pure (res.1, { B with adaSt := res.2 })) := by
    rw [validate_scale_eq, validate_lo_eq, validate_hi_eq]
    rfl
  rw [hprog]
  obtain ⟨bodyI, hbodyI, hspecI⟩ := hw4.adaInterval
  obtain ⟨bodyP, hbodyP, hspecP⟩ := hw4.adaPub
  have hvOK := valsOK_adaVals hB Mode.primary (((S.num * 2 ^ P.eOmega + (S.den : ℤ) : ℤ) : ℚ) /
        (((S.den : ℤ) * 2 ^ P.eOmega : ℤ) : ℚ))
  have hvs := hR.vals_le P hP _ hvOK
  unfold body_validate
  -- `P`, `O = 2^{eOmega}`, `encQ S`, `encQ θ`
  refine impl_let_det (ev_hd (ev_var rfl) hI) ?_
  refine impl_let_det (ev_pow2 hlib (ev_param hw1.peOmega P hP hM (ev_var rfl)) hpowO) ?_
  refine impl_let_det (ev_at2 (ev_var rfl) hI) ?_
  refine impl_let_det (ev_at3 (ev_var rfl) hI) ?_
  -- `qx`
  refine impl_let_det (ev_call hlib.bkQExtra (ev_list (.cons (ev_var rfl) (.cons
      (ev_call hlib.bkZExtra (ev_pair (ev_var rfl) (ev_lit (by simp only [valSize_int, bitLen_zero]; omega))
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega))
        (bkZExtra_val R hlib hw1 P hP hM Mode.primary))
      (.cons (ev_add (ev_mul (ev_hd (ev_var rfl) hSqs) (ev_var rfl)
          (by simp only [valSize_int]; omega)) (ev_at1 (ev_var rfl) hSqs)
          (by simp only [valSize_int]; omega))
      (.cons (ev_mul (ev_at1 (ev_var rfl) hSqs) (ev_var rfl) (by simp only [valSize_int]; omega))
        .nil))))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil] at hzxs ⊢; omega))
    (bkQExtra_val R hR hlib hw1 hw4 P hP hM Mode.primary _ _ hbcN hbcD)) ?_
  -- `vals`
  refine impl_let_det (ev_call hlib.bkValsQ (ev_pair (ev_bank_ada (ev_at1 (ev_var rfl) hI) hs1')
      (ev_var rfl) (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (bkValsQ_val R hR hlib hw2 P hP hM Mode.primary B hB _ _ hcN0 hcD0 hbcN hbcD)) ?_
  -- `L`
  refine impl_let_det (ev_param hw1.pL P hP hM (ev_var rfl)) ?_
  -- `l = (1 - θ)/L`
  refine impl_let_det (ev_call hlib.normQ (ev_pair (ev_sub (ev_at1 (ev_var rfl) hθqs)
      (ev_hd (ev_var rfl) hθqs) (by simp only [valSize_int]; omega))
      (ev_mul (ev_at1 (ev_var rfl) hθqs) (ev_var rfl) (by simp only [valSize_int]; omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
    (normQ_val hlib.bkGcdStep _ _ hb0 (by omega))) ?_
  -- `u = (1 + θ)/L`
  refine impl_let_det (ev_call hlib.normQ (ev_pair (ev_add (ev_at1 (ev_var rfl) hθqs)
      (ev_hd (ev_var rfl) hθqs) (by simp only [valSize_int]; omega))
      (ev_mul (ev_at1 (ev_var rfl) hθqs) (ev_var rfl) (by simp only [valSize_int]; omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
    (normQ_val hlib.bkGcdStep _ _ hb0 (by omega))) ?_
  -- `res = adaInterval …`
  refine impl_letE_of_run (implements_call_det hbodyI ?_
    (hspecI P B.adaSt _ _ _ hP hB.ada_ok hvOK hQlo hQhi hM)) ?_
  · exact ev_list (.cons (ev_call hbodyP (ev_var rfl) (hspecP P hP hM))
      (.cons (ev_bank_st (ev_at1 (ev_var rfl) hI) hs1') (.cons (ev_var rfl) (.cons (ev_var rfl)
        (.cons (ev_var rfl) .nil)))))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  intro bits r hrun
  have hok : R.ok P r.2 :=
    Always.of_run ((hR.invariant P hP).interval B.adaSt _ _ _ hB.ada_ok) hrun
  have hencr := hR.enc_le P hP r.2 hok
  have hcert : valSize (encCert r.1) ≤ 4 := by
    cases r.1 <;> simp only [encCert, valSize_int] <;> decide
  have hres : valSize (Val.list [encCert r.1, R.enc r.2]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hB' : BankOK P (R.ok P) { B with adaSt := r.2 } :=
    ⟨hB.ada_sizes, hB.coarse_length_le, hB.coarse_shape, hB.ada_rows, hB.coarse_rows, hok⟩
  have hs2 := bank_size_le R hR hP hB'
  have hs2' : valSize (encBank R.enc { B with adaSt := r.2 }) ≤ M := by omega
  have hout : valSize (Val.list [encCert r.1, encBank R.enc { B with adaSt := r.2 }]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  refine Implements.of_det ?_
  have hs3 : valSize (Val.list [encL (encL encRow) B.ada,
      Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))),
      R.enc r.2]) ≤ M := hs2'
  have hout' : valSize (Val.list [encCert r.1, Val.list [encL (encL encRow) B.ada,
      Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))),
      R.enc r.2]]) ≤ M := hout
  show EvalsVal prog M _ [] _ (Val.list [encCert r.1, Val.list [encL (encL encRow) B.ada,
      Val.list (B.coarse.map fun grp => Val.list (grp.map fun sub => Val.list (sub.map encRow))),
      R.enc r.2]])
  exact ev_pair (ev_hd (ev_var rfl) hres)
    (ev_list (.cons (ev_bank_ada (B := B) (ev_at1 (ev_var rfl) hI) hs1')
      (.cons (ev_bank_coarse (B := B) (ev_at1 (ev_var rfl) hI) hs1')
        (.cons (ev_at1 (ev_var rfl) hres) .nil)))
      hs3) hout'

end validate

end F2e2e.C.Impl.BankDSL
