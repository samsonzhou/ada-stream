import F2e2e.C.Impl.HashContracts
import F2e2e.C.Impl.HashIrr

/-!
# W2's routines used by W1 (public parameters): the fingerprint prime `P.q` and `irrW P`

* `leastPrimeGE_q_val`: the DSL search `leastPrimeGE` (index `202`, `F2e2e/C/Impl/Fingerprint.lean`)
  on `M_q` returns `P.q = Nat.find (exists_prime_ge P.Mq)`;
* `irrPoly_w_val`: the DSL search `irrPoly` (index `167`, `F2e2e/C/Impl/HashIrr.lean`) on `w`
  returns `irrW P = Hash.irrPoly P.w`;

both as `EvalsVal` judgments in which every value has size `≤ M`, for `M ≥ 2^20 ℒ³` (e.g. `M ≥ Mv R P`,
`W2.calL_cube_le_Mv`). The peaks are `O(ℒ)`: `log₂ M_q ≤ 3(c + 4 + betaExp)` and `w ≤ 3ℒ + 1`
(`F2e2e/C/SpaceParams.lean`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space

namespace W2

/-- `M_q ≥ 1` (all factors are positive). -/
theorem one_le_Mq (P : StreamParams) (hP : F2e2e.C.Top.ParamsOK P) : 1 ≤ P.Mq := by
  have h1 := hP.one_le_n
  have h2 := hP.one_le_m
  have h : 0 < 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by norm_num) h1) h2) (Nat.succ_pos _))
      (Nat.two_pow_pos _)
  unfold StreamParams.Mq
  exact Nat.one_le_pow _ _ h

/-- The search range `[M_q, 2 M_q]` of `leastPrimeGE` has numbers of at most `3ℒ` bits. -/
theorem size_two_Mq_le (P : StreamParams) : Nat.size (2 * P.Mq + 1) ≤ 3 * P.calL := by
  apply Nat.size_le.2
  have h1 := Mq_le P
  have h2 : 1 ≤ 2 ^ (3 * (cP P + 4 + P.betaExp)) := Nat.one_le_two_pow
  have hexp : 3 * (cP P + 4 + P.betaExp) + 2 ≤ 3 * P.calL := by rw [calL_eq_cP]; omega
  calc 2 * P.Mq + 1 < 4 * 2 ^ (3 * (cP P + 4 + P.betaExp)) := by omega
    _ = 2 ^ (3 * (cP P + 4 + P.betaExp) + 2) := by rw [pow_add]; ring
    _ ≤ 2 ^ (3 * P.calL) := two_pow_le_two_pow hexp

end W2

/-- **The fingerprint prime for W1**: the body of `leastPrimeGE` (index `202`) on `M_q` returns
`P.q`, every value of size `≤ M` for `M ≥ 2^20 ℒ³`. -/
theorem leastPrimeGE_q_val {prog : List Expr} (hL : FpLib prog) (P : StreamParams)
    (hP : F2e2e.C.Top.ParamsOK P) {M : ℕ} (hM : 2 ^ 20 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M [encN P.Mq] [] (.inl body_leastPrimeGE) (encN P.q) := by
  have h := leastPrimeGE_spec hL P.Mq 0
  rw [leastPrimeGE_Mq P (W2.one_le_Mq P hP)] at h
  have hS : S_leastPrimeGE P.Mq ≤ 2 ^ 20 * P.calL ^ 3 := by
    have hc := hundred_le_calL P
    obtain ⟨hc3, -⟩ := W2.calL_pow_bounds P
    have hsz := W2.size_two_Mq_le P
    have e20 : (2 : ℕ) ^ 20 = 1048576 := by norm_num
    rw [e20]
    simp only [S_leastPrimeGE, S_leastPrimeLoop, S_primeTest]
    omega
  exact h.toVal.mono_M (hS.trans hM)

/-- **The field polynomial for W1**: the body of `irrPoly` (index `167`) on `w` returns `irrW P`,
every value of size `≤ M` for `M ≥ 2^20 ℒ³`. -/
theorem irrPoly_w_val {prog : List Expr} (hL : HashLib prog) (P : StreamParams)
    {M : ℕ} (hM : 2 ^ 20 * P.calL ^ 3 ≤ M) :
    EvalsVal prog M [encN P.w] [] (.inl body_irrPoly) (encN (irrW P)) := by
  have h := irrPoly_spec hL P.w 0
  have hS : S_irrPoly P.w ≤ 2 ^ 20 * P.calL ^ 3 := by
    have hc := hundred_le_calL P
    obtain ⟨hc3, -⟩ := W2.calL_pow_bounds P
    have hw := w_le P
    have e20 : (2 : ℕ) ^ 20 = 1048576 := by norm_num
    rw [e20]
    simp only [S_irrPoly, S_irrTest, S_pow2, S_sizeNat, S_pmodDeg, S_xorNat]
    omega
  exact h.toVal.mono_M (hS.trans hM)

end F2e2e.C.Impl
