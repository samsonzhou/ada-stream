import F2e2e.C.Impl.HashGF

/-!
# HASH area (DSL): irreducible polynomials `irrTest`, `irrPoly`

Reference functions: `Cut2.Hash.irrTest` (trial division by all `m ∈ [2, 2^(q/2+1))`) and
`Cut2.Hash.irrPoly` (`searchFrom (irrTest q) (2^q) (2^q)`).
* `irrTest_spec`: `[q, n] ↦ encB (irrTest q n)` for `n < 2^(q+1)`;
* `irrPoly_spec`: `q ↦ irrPoly q`; the cost is polynomial in `2^q` (brute force).
-/

namespace F2e2e.Cost.HashDSL

/-- Cost bound of `irrTest`. -/
def C_irrTest (q : ℕ) : ℕ :=
  C_pow2 (q / 2 + 1) +
    2 ^ (q / 2 + 1) * (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) +
      60 * (q + 4) * (q + 4) + 300) + 300

/-- Space bound of `irrTest`. -/
def S_irrTest (q : ℕ) : ℕ :=
  S_pow2 (q / 2 + 1) + S_sizeNat (q / 2 + 1) + S_pmodDeg (q / 2) (q + 1) + 100 * q + 600

/-- Cost bound of `irrPoly`. -/
def C_irrPoly (q : ℕ) : ℕ :=
  C_pow2 q + (2 ^ q + 1) * (C_irrTest q + 60 * (q + 4) * (q + 4) + 300) + 300

/-- Space bound of `irrPoly`. -/
def S_irrPoly (q : ℕ) : ℕ := S_pow2 q + S_irrTest q + 100 * q + 600

set_option linter.unusedSimpArgs false

/-! ### Monotonicity of the `pmodDeg` bounds in the degree -/

theorem C_xorNat_mono {B B' : ℕ} (h : B ≤ B') : C_xorNat B ≤ C_xorNat B' := by
  unfold C_xorNat
  gcongr

theorem C_pow2_mono' {m m' : ℕ} (h : m ≤ m') : C_pow2 m ≤ C_pow2 m' := by
  unfold C_pow2
  gcongr

theorem C_pmodDeg_mono {d d' A : ℕ} (h : d ≤ d') : C_pmodDeg d A ≤ C_pmodDeg d' A := by
  unfold C_pmodDeg
  have h1 := C_pow2_mono' (Nat.add_le_add_right h A)
  have h2 := C_xorNat_mono (Nat.add_le_add_right (Nat.add_le_add_right h A) 1)
  gcongr

theorem S_pmodDeg_mono {d d' A : ℕ} (h : d ≤ d') : S_pmodDeg d A ≤ S_pmodDeg d' A := by
  unfold S_pmodDeg S_pow2 S_xorNat
  omega

/-! ### `pmod` with the degree computed by `sizeNat` -/

theorem size_sub_one_bounds {m : ℕ} (hm : 1 ≤ m) :
    2 ^ (Nat.size m - 1) ≤ m ∧ m < 2 ^ (Nat.size m - 1 + 1) := by
  have hs : 0 < Nat.size m := Nat.size_pos.2 hm
  constructor
  · exact Nat.lt_size.1 (by omega)
  · rw [Nat.sub_add_cancel hs]
    exact Nat.lt_size_self m

theorem pmod_eq_pmodDeg {m : ℕ} (hm : 1 ≤ m) (n : ℕ) :
    Hash.pmod n m = Hash.pmodDeg (Nat.size m - 1) m n := by
  obtain ⟨h1, h2⟩ := size_sub_one_bounds hm
  unfold Hash.pmod
  rw [Hash.log_two_eq_of_bounds h1 h2]

/-! ### `irrTest`: loop steps -/

theorem irrTestStep_done (prog : List Expr) (base : ℕ) (m n : ℤ) :
    EvalsLe prog base [Val.list [Val.int 0, Val.int m, Val.int n]] body_irrTestStep
      (Val.list [Val.int 0, Val.int 1]) 60
      (base + 4 * valSize (Val.list [Val.int 0, Val.int m, Val.int n]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_irrTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

theorem irrTestStep_found {prog : List Expr} (hL : HashLib prog) (base c' m n W A : ℕ)
    (hm1 : 1 ≤ m) (hcW : c' + 1 < 2 ^ W) (hmW : m < 2 ^ W) (hnA : n < 2 ^ A)
    (hr : Hash.pmodDeg (Nat.size m - 1) m n = 0) :
    EvalsLe prog base [Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int m, Val.int n]]
      body_irrTestStep (Val.list [Val.int 0, Val.int 0])
      (C_sizeNat W + C_pmodDeg (Nat.size m - 1) A + 20 * (A + W) + 100)
      (base + 4 * valSize (Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int m, Val.int n]) +
        S_sizeNat W + S_pmodDeg (Nat.size m - 1) A + 10 * (A + W) + 100) := by
  obtain ⟨hd1, hd2⟩ := size_sub_one_bounds hm1
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (sizeNat_spec hL.sizeNatStep m W hmW 0)
  obtain ⟨f2, c2, p2, hc2, hp2, hu2⟩ :=
    uniform_of_spec (pmodDeg_spec hL (Nat.size m - 1) m n A hd1 hd2 hnA 0)
  simp only [encN, zero_add] at hu1 hu2 hp1 hp2
  have hc0 : ((c' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hs0 : 0 < Nat.size m := Nat.size_pos.2 hm1
  have hs1 : ((Nat.size m : ℕ) : ℤ) - 1 = ((Nat.size m - 1 : ℕ) : ℤ) := by
    rw [Nat.cast_sub (by omega : 1 ≤ Nat.size m), Nat.cast_one]
  have hr' : ((Hash.pmodDeg (Nat.size m - 1) m n : ℕ) : ℤ) = 0 := by rw [hr]; rfl
  have hszW : Nat.size m ≤ W := Nat.size_le.2 hmW
  have hbc : bitLen ((c' + 1 : ℕ) : ℤ) ≤ W := bitLen_nat_le_of_lt hcW
  have hbm : bitLen (m : ℤ) ≤ W := bitLen_nat_le_of_lt hmW
  have hbn : bitLen (n : ℤ) ≤ A := bitLen_nat_le_of_lt hnA
  have hbs : bitLen ((Nat.size m : ℕ) : ℤ) ≤ W := le_trans (bitLen_natCast_le _) hszW
  have hbs1 : bitLen ((Nat.size m - 1 : ℕ) : ℤ) ≤ W := le_trans (bitLen_natCast_le _) (by omega)
  apply EvalsLe.of_eval (f1 + f2 + 30)
  simp only [body_irrTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hc0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte,
    hL.sizeNat, hL.pmodDeg]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_call, evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ,
    hs1, hL.pmodDeg]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, hr', ↓reduceIte, ne_eq, one_ne_zero,
    not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

theorem irrTestStep_next {prog : List Expr} (hL : HashLib prog) (base c' m n W A : ℕ)
    (hm1 : 1 ≤ m) (hcW : c' + 1 < 2 ^ W) (hmW : m < 2 ^ W) (hnA : n < 2 ^ A)
    (hr : Hash.pmodDeg (Nat.size m - 1) m n ≠ 0) :
    EvalsLe prog base [Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int m, Val.int n]]
      body_irrTestStep
      (Val.list [Val.int 1, Val.list [Val.int (c' : ℤ), Val.int ((m + 1 : ℕ) : ℤ), Val.int n]])
      (C_sizeNat W + C_pmodDeg (Nat.size m - 1) A + 20 * (A + W) + 100)
      (base + 4 * valSize (Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int m, Val.int n]) +
        S_sizeNat W + S_pmodDeg (Nat.size m - 1) A + 10 * (A + W) + 100) := by
  obtain ⟨hd1, hd2⟩ := size_sub_one_bounds hm1
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (sizeNat_spec hL.sizeNatStep m W hmW 0)
  obtain ⟨f2, c2, p2, hc2, hp2, hu2⟩ :=
    uniform_of_spec (pmodDeg_spec hL (Nat.size m - 1) m n A hd1 hd2 hnA 0)
  simp only [encN, zero_add] at hu1 hu2 hp1 hp2
  have hc0 : ((c' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hs0 : 0 < Nat.size m := Nat.size_pos.2 hm1
  have hs1 : ((Nat.size m : ℕ) : ℤ) - 1 = ((Nat.size m - 1 : ℕ) : ℤ) := by
    rw [Nat.cast_sub (by omega : 1 ≤ Nat.size m), Nat.cast_one]
  have hr' : ¬ ((Hash.pmodDeg (Nat.size m - 1) m n : ℕ) : ℤ) = 0 := by exact_mod_cast hr
  have hcc : ((c' + 1 : ℕ) : ℤ) - 1 = (c' : ℤ) := by push_cast; ring
  have hmm : (m : ℤ) + 1 = ((m + 1 : ℕ) : ℤ) := by push_cast; ring
  have hszW : Nat.size m ≤ W := Nat.size_le.2 hmW
  have hrlt : Hash.pmodDeg (Nat.size m - 1) m n < 2 ^ W :=
    lt_of_lt_of_le (Hash.pmodDeg_lt hd1 hd2 n) (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hbc : bitLen ((c' + 1 : ℕ) : ℤ) ≤ W := bitLen_nat_le_of_lt hcW
  have hbc' : bitLen (c' : ℤ) ≤ W := bitLen_nat_le_of_lt (by omega)
  have hbm : bitLen (m : ℤ) ≤ W := bitLen_nat_le_of_lt hmW
  have hbm1 : bitLen ((m + 1 : ℕ) : ℤ) ≤ W + 1 :=
    bitLen_nat_le_of_lt (by rw [pow_succ]; omega)
  have hbn : bitLen (n : ℤ) ≤ A := bitLen_nat_le_of_lt hnA
  have hbs : bitLen ((Nat.size m : ℕ) : ℤ) ≤ W := le_trans (bitLen_natCast_le _) hszW
  have hbs1 : bitLen ((Nat.size m - 1 : ℕ) : ℤ) ≤ W := le_trans (bitLen_natCast_le _) (by omega)
  have hbr := bitLen_nat_le_of_lt hrlt
  apply EvalsLe.of_eval (f1 + f2 + 30)
  simp only [body_irrTestStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hc0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte,
    hL.sizeNat, hL.pmodDeg]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_call, evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ,
    hs1, hL.pmodDeg]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, hr', ↓reduceIte, ne_eq, not_true_eq_false,
    List.getElem?_cons_zero, List.getElem?_cons_succ, hcc, hmm]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

/-! ### `irrTest`: the loop -/

/-- Encoding of the `irrTest` loop state `[cnt, m, n]`. -/
def encIrr (n : ℕ) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int (n : ℤ)]

theorem irrTest_true_of {q n : ℕ} (h : ∀ i < 2 ^ (q / 2 + 1) - 2, Hash.pmod n (i + 2) ≠ 0) :
    Hash.irrTest q n = true := by
  unfold Hash.irrTest
  rw [List.all_eq_true]
  intro i hi
  rw [List.mem_range] at hi
  simpa using h i hi

theorem irrTest_false_of {q n i : ℕ} (hi : i < 2 ^ (q / 2 + 1) - 2) (h : Hash.pmod n (i + 2) = 0) :
    Hash.irrTest q n = false := by
  unfold Hash.irrTest
  rw [Bool.eq_false_iff]
  intro hall
  rw [List.all_eq_true] at hall
  have := hall i (List.mem_range.2 hi)
  simp [h] at this

theorem irrTest_loop {prog : List Expr} (hL : HashLib prog) (q n base : ℕ)
    (hn : n < 2 ^ (q + 1)) :
    ∀ s : ℕ × ℕ, (s.2 + s.1 = 2 ^ (q / 2 + 1) ∧ 2 ≤ s.2 ∧
        ∀ i < s.2 - 2, Hash.pmod n (i + 2) ≠ 0) →
      ∃ out, out = encB (Hash.irrTest q n) ∧
        LoopLe prog base Idx.irrTestStep (encIrr n s) out
          ((s.1 + 1) * (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) +
            60 * (q + 4) * (q + 4) + 299 + 1))
          (base + (S_sizeNat (q / 2 + 1) + S_pmodDeg (q / 2) (q + 1) + 100 * q + 500)) := by
  refine LoopLe.of_measure hL.irrTestStep (encIrr n) _ _ (fun s => s.1)
    (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) + 60 * (q + 4) * (q + 4) + 299) ?_
  rintro ⟨cnt, m⟩ ⟨hsum, hm2, hall⟩
  simp only at hsum hm2 hall
  have hmW : m ≤ 2 ^ (q / 2 + 1) := by omega
  have hbm : bitLen (m : ℤ) ≤ q / 2 + 2 :=
    bitLen_nat_le_of_lt (lt_of_le_of_lt hmW (Nat.pow_lt_pow_right (by norm_num) (by omega)))
  have hbn : bitLen (n : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hn
  have hsq : 60 * (q + 4) * (q + 4) = 60 * ((q + 4) * (q + 4)) := by ring
  have hX : 4 * (q + 4) ≤ (q + 4) * (q + 4) := Nat.mul_le_mul_right _ (by omega)
  rcases cnt with _ | c'
  · -- all divisors tested: irreducible
    left
    refine ⟨Val.int 1, ?_, ?_⟩
    · have e : encIrr n (0, m) = Val.list [Val.int 0, Val.int (m : ℤ), Val.int (n : ℤ)] := by
        simp only [encIrr, Nat.cast_zero]
      rw [e]
      have hvs : valSize (Val.list [Val.int 0, Val.int (m : ℤ), Val.int (n : ℤ)]) ≤ 2 * q + 10 := by
        simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero]
        omega
      refine (irrTestStep_done prog _ _ _).mono ?_ ?_
      · omega
      · omega
    · rw [irrTest_true_of (fun i hi => hall i (by omega))]
      rfl
  · -- test the divisor `m`
    have hm1 : 1 ≤ m := by omega
    have hmlt : m < 2 ^ (q / 2 + 1) := by omega
    have hcW : c' + 1 < 2 ^ (q / 2 + 1) := by omega
    have hnA : n < 2 ^ (q + 1) := hn
    have hszW : Nat.size m ≤ q / 2 + 1 := Nat.size_le.2 hmlt
    have hCm := C_pmodDeg_mono (A := q + 1) (by omega : Nat.size m - 1 ≤ q / 2)
    have hSm := S_pmodDeg_mono (A := q + 1) (by omega : Nat.size m - 1 ≤ q / 2)
    have hbc : bitLen ((c' + 1 : ℕ) : ℤ) ≤ q / 2 + 1 := bitLen_nat_le_of_lt hcW
    have hbm' : bitLen (m : ℤ) ≤ q / 2 + 1 := bitLen_nat_le_of_lt hmlt
    have hvs : valSize (encIrr n (c' + 1, m)) ≤ 2 * q + 10 := by
      simp only [encIrr, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    have e1 : encIrr n (c' + 1, m) =
        Val.list [Val.int ((c' + 1 : ℕ) : ℤ), Val.int (m : ℤ), Val.int (n : ℤ)] := rfl
    by_cases hr : Hash.pmodDeg (Nat.size m - 1) m n = 0
    · -- `m` divides `n`: reducible
      left
      refine ⟨Val.int 0, ?_, ?_⟩
      · have h1 := irrTestStep_found hL (base + valSize (encIrr n (c' + 1, m))) c' m n
          (q / 2 + 1) (q + 1) hm1 hcW hmlt hnA hr
        rw [← e1] at h1
        refine h1.mono ?_ ?_
        · omega
        · omega
      · rw [irrTest_false_of (i := m - 2) (by omega)
          (by rw [Nat.sub_add_cancel hm2, pmod_eq_pmodDeg hm1]; exact hr)]
        rfl
    · -- next divisor
      right
      have h1 := irrTestStep_next hL (base + valSize (encIrr n (c' + 1, m))) c' m n
        (q / 2 + 1) (q + 1) hm1 hcW hmlt hnA hr
      have e2 : Val.list [Val.int (c' : ℤ), Val.int ((m + 1 : ℕ) : ℤ), Val.int (n : ℤ)] =
          encIrr n (c', m + 1) := rfl
      rw [← e1, e2] at h1
      refine ⟨1, (c', m + 1), one_ne_zero, h1.mono ?_ ?_, ⟨?_, ?_, ?_⟩, Nat.lt_succ_self c'⟩
      · omega
      · omega
      · simp only
        omega
      · simp only
        omega
      · simp only
        intro i hi
        rcases Nat.lt_or_ge i (m - 2) with h | h
        · exact hall i h
        · have hi' : i = m - 2 := by omega
          rw [hi', Nat.sub_add_cancel hm2, pmod_eq_pmodDeg hm1]
          exact hr

/-- Proof of `irrTest_spec`. -/
theorem irrTest_spec_aux {prog : List Expr} (hL : HashLib prog) (q n : ℕ) (hn : n < 2 ^ (q + 1))
    (base : ℕ) :
    EvalsLe prog base [Val.list [encN q, encN n]] body_irrTest (encB (Hash.irrTest q n))
      (C_irrTest q) (base + S_irrTest q) := by
  have h2le : 2 ≤ 2 ^ (q / 2 + 1) := by
    calc 2 = 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (q / 2 + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (pow2_spec hL.pow2Step (q / 2 + 1) 0)
  obtain ⟨out, hout, hloop⟩ := irrTest_loop hL q n 0 hn (2 ^ (q / 2 + 1) - 2, 2)
    ⟨by simp only; omega, le_rfl, fun i hi => by simp only at hi; omega⟩
  obtain ⟨f2, c2, p2, hc2, hp2, hu2⟩ := uniform_of_loop hloop
  subst hout
  simp only [encN, zero_add] at hu1 hp1 hp2
  simp only [encIrr, Nat.cast_ofNat] at hu2
  have hq2 : (q : ℤ) / 2 = ((q / 2 : ℕ) : ℤ) := (Int.natCast_ediv q 2).symm
  have hq21 : ((q / 2 : ℕ) : ℤ) + 1 = ((q / 2 + 1 : ℕ) : ℤ) := by push_cast; ring
  have hN : ((2 ^ (q / 2 + 1) : ℕ) : ℤ) - 2 = ((2 ^ (q / 2 + 1) - 2 : ℕ) : ℤ) := by
    rw [Nat.cast_sub h2le, Nat.cast_ofNat]
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  have hbn : bitLen (n : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hn
  have hbq2 : bitLen ((q / 2 : ℕ) : ℤ) ≤ q := le_trans (bitLen_natCast_le _) (Nat.div_le_self _ _)
  have hbq21 : bitLen ((q / 2 + 1 : ℕ) : ℤ) ≤ q + 1 := le_trans (bitLen_natCast_le _) (by omega)
  have hbT : bitLen ((2 ^ (q / 2 + 1) : ℕ) : ℤ) ≤ q + 2 :=
    bitLen_nat_le_of_lt (Nat.pow_lt_pow_right (by norm_num) (by omega))
  have hbN : bitLen ((2 ^ (q / 2 + 1) - 2 : ℕ) : ℤ) ≤ q + 2 :=
    bitLen_nat_le_of_lt (lt_of_le_of_lt (Nat.sub_le _ _)
      (Nat.pow_lt_pow_right (by norm_num) (by omega)))
  have hbqq : (bitLen (q : ℤ) + 1) * (bitLen (2 : ℤ) + 1) ≤ 3 * q + 3 := by
    rw [bitLen_two]
    omega
  have hc2b : c2 ≤ (2 ^ (q / 2 + 1) - 2 + 1) * (C_sizeNat (q / 2 + 1) +
      C_pmodDeg (q / 2) (q + 1) + 60 * (q + 4) * (q + 4) + 299 + 1) := hc2
  have key : (2 ^ (q / 2 + 1) - 2 + 1) * (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) +
      60 * (q + 4) * (q + 4) + 299 + 1) + (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) +
      60 * (q + 4) * (q + 4) + 300) = 2 ^ (q / 2 + 1) * (C_sizeNat (q / 2 + 1) +
      C_pmodDeg (q / 2) (q + 1) + 60 * (q + 4) * (q + 4) + 300) := by
    obtain ⟨T', hT'⟩ : ∃ T', 2 ^ (q / 2 + 1) = T' + 2 := ⟨_, (Nat.sub_add_cancel h2le).symm⟩
    rw [hT', Nat.add_sub_cancel]
    ring
  have hc2' : c2 + (C_sizeNat (q / 2 + 1) + C_pmodDeg (q / 2) (q + 1) +
      60 * (q + 4) * (q + 4) + 300) ≤ 2 ^ (q / 2 + 1) * (C_sizeNat (q / 2 + 1) +
      C_pmodDeg (q / 2) (q + 1) + 60 * (q + 4) * (q + 4) + 300) := by
    omega
  have hsq : 60 * (q + 4) * (q + 4) = 60 * ((q + 4) * (q + 4)) := by ring
  have hX : 4 * (q + 4) ≤ (q + 4) * (q + 4) := Nat.mul_le_mul_right _ (by omega)
  apply EvalsLe.of_eval (f1 + f2 + 30)
  simp only [body_irrTest, eLoop, eList, eCons, eSub, eCall, eAdd, eDiv, eHd, eAt1, eTl, eV, eLit,
    encN, eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un,
    eval_succ_call, eval_succ_loop, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, OfNat.ofNat_ne_zero, ↓reduceIte, hq2, hq21,
    hL.pow2]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_un, evalBin, evalUn, List.getElem?_cons_zero, hN]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [C_irrTest, bitLen_two, bitLen_one, bitLen_zero]
    omega
  · simp only [S_irrTest, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff,
      bitLen_two, bitLen_one]
    omega

/-! ### `irrPoly`: loop steps -/

theorem irrPolyStep_stop (prog : List Expr) (base : ℕ) (s q : ℤ) :
    EvalsLe prog base [Val.list [Val.int s, Val.int 0, Val.int q]] body_irrPolyStep
      (Val.list [Val.int 0, Val.int s]) 60
      (base + 4 * valSize (Val.list [Val.int s, Val.int 0, Val.int q]) + 20) := by
  apply EvalsLe.of_eval 20
  simp only [body_irrPolyStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, evalBin, evalUn, Option.bind_some, Option.map_some, List.getElem?_cons_zero,
    List.getElem?_cons_succ, ne_eq, one_ne_zero, not_false_eq_true, ↓reduceIte]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

theorem irrPolyStep_found {prog : List Expr} (hL : HashLib prog) (base s k' q : ℕ)
    (hs : s < 2 ^ (q + 1)) (hk : k' + 1 < 2 ^ (q + 1)) (ht : Hash.irrTest q s = true) :
    EvalsLe prog base [Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ), Val.int q]]
      body_irrPolyStep (Val.list [Val.int 0, Val.int s])
      (C_irrTest q + 20 * q + 100)
      (base + 4 * valSize (Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ), Val.int q]) +
        S_irrTest q + 10 * q + 100) := by
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (irrTest_spec_aux hL q s hs 0)
  simp only [encN, encB, ht, zero_add, ↓reduceIte] at hu1 hp1
  have hk0 : ((k' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hbs : bitLen (s : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hs
  have hbk : bitLen ((k' + 1 : ℕ) : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hk
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  apply EvalsLe.of_eval (f1 + 30)
  simp only [body_irrPolyStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte,
    hL.irrTest]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, ↓reduceIte, ne_eq, one_ne_zero, not_false_eq_true,
    List.getElem?_cons_zero, List.getElem?_cons_succ]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

theorem irrPolyStep_next {prog : List Expr} (hL : HashLib prog) (base s k' q : ℕ)
    (hs : s < 2 ^ (q + 1)) (hk : k' + 1 < 2 ^ (q + 1)) (ht : Hash.irrTest q s = false) :
    EvalsLe prog base [Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ), Val.int q]]
      body_irrPolyStep
      (Val.list [Val.int 1, Val.list [Val.int ((s + 1 : ℕ) : ℤ), Val.int (k' : ℤ), Val.int q]])
      (C_irrTest q + 20 * q + 100)
      (base + 4 * valSize (Val.list [Val.int s, Val.int ((k' + 1 : ℕ) : ℤ), Val.int q]) +
        S_irrTest q + 10 * q + 100) := by
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (irrTest_spec_aux hL q s hs 0)
  simp only [encN, encB, ht, zero_add, Bool.false_eq_true, ↓reduceIte] at hu1 hp1
  have hk0 : ((k' + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hss : (s : ℤ) + 1 = ((s + 1 : ℕ) : ℤ) := by push_cast; ring
  have hkk : ((k' + 1 : ℕ) : ℤ) - 1 = (k' : ℤ) := by push_cast; ring
  have hbs : bitLen (s : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hs
  have hbs1 : bitLen ((s + 1 : ℕ) : ℤ) ≤ q + 2 :=
    bitLen_nat_le_of_lt (by rw [pow_succ 2 (q + 1)]; omega)
  have hbk : bitLen ((k' + 1 : ℕ) : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hk
  have hbk' : bitLen (k' : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt (by omega)
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  apply EvalsLe.of_eval (f1 + 30)
  simp only [body_irrPolyStep, eLet, eHd, eAt1, eAt2, eTl, eIte, eEq, eV, eLit, eList, eCons,
    ePair, eCall, eSub, eAdd,
    eval_succ_var, eval_succ_lit, eval_succ_nil, eval_succ_bin, eval_succ_un, eval_succ_ite,
    eval_succ_letE, eval_succ_call, evalBin, evalUn, Option.bind_some, Option.map_some,
    List.getElem?_cons_zero, List.getElem?_cons_succ, ne_eq, hk0, not_false_eq_true,
    not_true_eq_false, ↓reduceIte,
    hL.irrTest]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_lit, eval_succ_nil,
    eval_succ_bin, eval_succ_ite, evalBin, ↓reduceIte, ne_eq, not_true_eq_false,
    List.getElem?_cons_zero, List.getElem?_cons_succ, hss, hkk, zero_ne_one, not_false_eq_true]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [bitLen_zero, bitLen_one]
    omega
  · simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff, bitLen_zero,
      bitLen_one]
    omega

/-! ### `irrPoly`: the loop -/

/-- Encoding of the `irrPoly` loop state `[s, k, q]`. -/
def encIrrP (q : ℕ) (s : ℕ × ℕ) : Val :=
  Val.list [Val.int (s.1 : ℤ), Val.int (s.2 : ℤ), Val.int (q : ℤ)]

theorem irrPoly_loop {prog : List Expr} (hL : HashLib prog) (q base : ℕ) :
    ∀ s : ℕ × ℕ, (Hash.searchFrom (Hash.irrTest q) s.1 s.2 = Hash.irrPoly q ∧
        s.1 + s.2 = 2 ^ (q + 1) ∧ 2 ^ q ≤ s.1) →
      ∃ out, out = encN (Hash.irrPoly q) ∧
        LoopLe prog base Idx.irrPolyStep (encIrrP q s) out
          ((s.2 + 1) * (C_irrTest q + 60 * (q + 4) * (q + 4) + 299 + 1))
          (base + (S_irrTest q + 60 * q + 300)) := by
  refine LoopLe.of_measure hL.irrPolyStep (encIrrP q) _ _ (fun s => s.2)
    (C_irrTest q + 60 * (q + 4) * (q + 4) + 299) ?_
  rintro ⟨s, k⟩ ⟨hsrch, hsum, hs⟩
  simp only at hsrch hsum hs
  have hsq : 60 * (q + 4) * (q + 4) = 60 * ((q + 4) * (q + 4)) := by ring
  have hX : 4 * (q + 4) ≤ (q + 4) * (q + 4) := Nat.mul_le_mul_right _ (by omega)
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  have hsle : s ≤ 2 ^ (q + 1) := by omega
  rcases k with _ | k'
  · left
    refine ⟨Val.int (s : ℤ), ?_, ?_⟩
    · have e : encIrrP q (s, 0) = Val.list [Val.int (s : ℤ), Val.int 0, Val.int (q : ℤ)] := by
        simp only [encIrrP, Nat.cast_zero]
      rw [e]
      have hbs : bitLen (s : ℤ) ≤ q + 2 :=
        bitLen_nat_le_of_lt (lt_of_le_of_lt hsle (Nat.pow_lt_pow_right (by norm_num) (by omega)))
      have hvs : valSize (Val.list [Val.int (s : ℤ), Val.int 0, Val.int (q : ℤ)]) ≤ 2 * q + 10 := by
        simp only [valSize_int, valSize_list, listSize_cons, listSize_nil, bitLen_zero]
        omega
      refine (irrPolyStep_stop prog _ _ _).mono ?_ ?_
      · omega
      · omega
    · rw [← hsrch]
      rfl
  · have hslt : s < 2 ^ (q + 1) := by omega
    have hk : k' + 1 < 2 ^ (q + 1) := by
      have : 1 ≤ 2 ^ q := Nat.one_le_two_pow
      omega
    have hbs : bitLen (s : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hslt
    have hbk : bitLen ((k' + 1 : ℕ) : ℤ) ≤ q + 1 := bitLen_nat_le_of_lt hk
    have hvs : valSize (encIrrP q (s, k' + 1)) ≤ 3 * q + 10 := by
      simp only [encIrrP, valSize_int, valSize_list, listSize_cons, listSize_nil]
      omega
    have e1 : encIrrP q (s, k' + 1) =
        Val.list [Val.int (s : ℤ), Val.int ((k' + 1 : ℕ) : ℤ), Val.int (q : ℤ)] := rfl
    have hstep : Hash.searchFrom (Hash.irrTest q) s (k' + 1) =
        if Hash.irrTest q s then s else Hash.searchFrom (Hash.irrTest q) (s + 1) k' := rfl
    cases ht : Hash.irrTest q s
    · -- not irreducible: next candidate
      right
      have h1 := irrPolyStep_next hL (base + valSize (encIrrP q (s, k' + 1))) s k' q hslt hk ht
      have e2 : Val.list [Val.int ((s + 1 : ℕ) : ℤ), Val.int (k' : ℤ), Val.int (q : ℤ)] =
          encIrrP q (s + 1, k') := rfl
      rw [← e1, e2] at h1
      refine ⟨1, (s + 1, k'), one_ne_zero, h1.mono ?_ ?_, ⟨?_, ?_, ?_⟩, Nat.lt_succ_self k'⟩
      · omega
      · omega
      · simp only
        rw [← hsrch, hstep, ht]
        rfl
      · simp only
        omega
      · simp only
        omega
    · -- irreducible: stop
      left
      refine ⟨Val.int (s : ℤ), ?_, ?_⟩
      · have h1 := irrPolyStep_found hL (base + valSize (encIrrP q (s, k' + 1))) s k' q hslt hk ht
        rw [← e1] at h1
        refine h1.mono ?_ ?_
        · omega
        · omega
      · rw [← hsrch, hstep, ht]
        rfl

/-- Proof of `irrPoly_spec`. -/
theorem irrPoly_spec_aux {prog : List Expr} (hL : HashLib prog) (q base : ℕ) :
    EvalsLe prog base [encN q] body_irrPoly (encN (Hash.irrPoly q)) (C_irrPoly q)
      (base + S_irrPoly q) := by
  obtain ⟨f1, c1, p1, hc1, hp1, hu1⟩ := uniform_of_spec (pow2_spec hL.pow2Step q 0)
  obtain ⟨out, hout, hloop⟩ := irrPoly_loop hL q 0 (2 ^ q, 2 ^ q)
    ⟨rfl, by simp only; rw [pow_succ]; omega, le_rfl⟩
  obtain ⟨f2, c2, p2, hc2, hp2, hu2⟩ := uniform_of_loop hloop
  subst hout
  simp only [encN, zero_add] at hu1 hp1 hp2
  simp only [encIrrP] at hu2
  have hc2' : c2 ≤ (2 ^ q + 1) * (C_irrTest q + 60 * (q + 4) * (q + 4) + 300) :=
    le_trans hc2 (Nat.mul_le_mul le_rfl (by omega))
  have hbq : bitLen (q : ℤ) ≤ q := bitLen_natCast_le q
  have hbt : bitLen ((2 ^ q : ℕ) : ℤ) ≤ q + 1 :=
    bitLen_nat_le_of_lt (Nat.pow_lt_pow_right (by norm_num) (by omega))
  apply EvalsLe.of_eval (f1 + f2 + 30)
  simp only [body_irrPoly, eLet, eLoop, eList, eCons, eCall, eV, encN, eval_succ_var,
    eval_succ_nil, eval_succ_bin, eval_succ_letE, eval_succ_call, eval_succ_loop, evalBin,
    Option.bind_some, Option.map_some, List.getElem?_cons_zero, List.getElem?_cons_succ,
    hL.pow2]
  rw [hu1 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some, eval_succ_var, eval_succ_nil, eval_succ_bin,
    evalBin, List.getElem?_cons_zero, List.getElem?_cons_succ]
  rw [hu2 _ _ (by omega)]
  simp only [Option.map_some, Option.bind_some]
  refine ⟨_, _, rfl, ?_, ?_⟩
  · simp only [C_irrPoly]
    omega
  · simp only [S_irrPoly, valSize_int, valSize_list, listSize_cons, listSize_nil, max_le_iff]
    omega


section specs

variable {prog : List Expr}

/-- **Spec of `irrTest`.** -/
theorem irrTest_spec (hL : HashLib prog) (q n : ℕ) (hn : n < 2 ^ (q + 1)) (base : ℕ) :
    EvalsLe prog base [Val.list [encN q, encN n]] body_irrTest (encB (Hash.irrTest q n))
      (C_irrTest q) (base + S_irrTest q) := by
  exact irrTest_spec_aux hL q n hn base

/-- **Spec of `call Idx.irrTest`.** -/
theorem irrTest_call (hL : HashLib prog) {base : ℕ} {env : List Val} {e : Expr}
    {q n : ℕ} (hn : n < 2 ^ (q + 1)) {Ce Se : ℕ}
    (he : EvalsLe prog base env e (Val.list [encN q, encN n]) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.irrTest e) (encB (Hash.irrTest q n))
      (1 + Ce + C_irrTest q)
      (max Se (base + valSize (Val.list [encN q, encN n]) + S_irrTest q)) :=
  EvalsLe.call he hL.irrTest (irrTest_spec hL q n hn _)

/-- **Spec of `irrPoly`.** -/
theorem irrPoly_spec (hL : HashLib prog) (q base : ℕ) :
    EvalsLe prog base [encN q] body_irrPoly (encN (Hash.irrPoly q)) (C_irrPoly q)
      (base + S_irrPoly q) := by
  exact irrPoly_spec_aux hL q base

/-- **Spec of `call Idx.irrPoly`** (used by the PARAMS routine). -/
theorem irrPoly_call (hL : HashLib prog) {base : ℕ} {env : List Val} {e : Expr}
    {q Ce Se : ℕ} (he : EvalsLe prog base env e (encN q) Ce Se) :
    EvalsLe prog base env (Expr.call Idx.irrPoly e) (encN (Hash.irrPoly q)) (1 + Ce + C_irrPoly q)
      (max Se (base + valSize (encN q) + S_irrPoly q)) :=
  EvalsLe.call he hL.irrPoly (irrPoly_spec hL q _)

end specs

end F2e2e.Cost.HashDSL
