import F2e2e.C.Impl.Tree3Defs

/-!
# W6, Tree3 (proofs, part 1): helpers, the element routines and the three indexed maps of Step 3

* `step3ModY_val`: `modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d` on the encoded banks;
* `step3MapXY_val`: `mapFrom (Bank.mapRows (Row.addGuardXY P g δ)) d1` on the encoded banks;
* `step3SetL_val`: `setAt L' d` on the encoded learners.
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

/-! ## Arithmetic helpers -/

section detRules2

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem ev_lt {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.lt a b)) (Val.int (if x < y then 1 else 0)) :=
  EvalsVal.lt ha hb hM

theorem ev_sub {a b : Expr} {x y : ℤ} (ha : EvalsVal prog M env [] (.inl a) (Val.int x))
    (hb : EvalsVal prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x - y)) ≤ M) :
    EvalsVal prog M env [] (.inl (Expr.bin BinOp.sub a b)) (Val.int (x - y)) :=
  EvalsVal.sub ha hb hM

end detRules2

theorem valSize_int_le_of_abs_le {z : ℤ} {k : ℕ} (h : |z| ≤ 2 ^ k) : valSize (Val.int z) ≤ k + 2 := by
  have hpos : (0 : ℤ) < 2 ^ k := by positivity
  have h' : |z| < 2 ^ (k + 1) := lt_of_le_of_lt h (by rw [pow_succ]; linarith)
  have := valSize_int_le_of_abs_lt h'
  omega

theorem abs_mul_le_pow {x y : ℤ} {a b : ℕ} (hx : |x| ≤ 2 ^ a) (hy : |y| ≤ 2 ^ b) :
    |x * y| ≤ 2 ^ (a + b) := by
  rw [abs_mul, pow_add]
  exact mul_le_mul hx hy (abs_nonneg _) (by positivity)

theorem abs_add_le_pow {x y : ℤ} {a : ℕ} (hx : |x| ≤ 2 ^ a) (hy : |y| ≤ 2 ^ a) :
    |x + y| ≤ 2 ^ (a + 1) := by
  calc |x + y| ≤ |x| + |y| := abs_add_le x y
    _ ≤ 2 ^ a + 2 ^ a := add_le_add hx hy
    _ = 2 ^ (a + 1) := by ring

theorem abs_le_pow_mono {z : ℤ} {k k' : ℕ} (h : |z| ≤ 2 ^ k) (hk : k ≤ k') : |z| ≤ 2 ^ k' :=
  h.trans (two_pow_le_two_pow_int hk)

theorem abs_natCast_two_pow (k : ℕ) : |((2 ^ k : ℕ) : ℤ)| ≤ 2 ^ k := by
  push_cast
  rw [abs_of_pos (by positivity)]

/-- `QOK` of a quotient with bounded numerator and denominator. -/
theorem qok_div {P : StreamParams} {a b : ℤ} {k e : ℕ} (ha : |a| ≤ 2 ^ k) (hb0 : 0 < b)
    (hb : b ≤ 2 ^ e) (hk : k ≤ 4 * regBits P) (he : e ≤ 4 * regBits P) :
    QOK P ((a : ℚ) / (b : ℚ)) := by
  have h1 := div_num_abs_le a b hb0
  have h2 := div_den_le a b hb0
  have h3 := two_pow_le_two_pow_int hk
  have h4 := two_pow_le_two_pow_int he
  exact ⟨by linarith, by linarith⟩

theorem abs_div_le_of_one_le {a b : ℤ} {k : ℕ} (ha : |a| ≤ 2 ^ k) (hb : 1 ≤ b) :
    |(a : ℚ) / (b : ℚ)| ≤ 2 ^ k := by
  have hb' : (1 : ℚ) ≤ b := by exact_mod_cast hb
  have hb0 : (0 : ℚ) < b := by linarith
  have ha' : |(a : ℚ)| ≤ 2 ^ k := by exact_mod_cast ha
  rw [abs_div, abs_of_pos hb0, div_le_iff₀ hb0]
  have : (0 : ℚ) ≤ 2 ^ k := by positivity
  nlinarith [abs_nonneg (a : ℚ)]

/-- The rounding to a grid of a bounded rational. -/
theorem abs_roundMant_le {q k : ℕ} {z : ℚ} (hz : |z| ≤ 2 ^ k) :
    |roundMant q z| ≤ 2 ^ (k + q + 1) := by
  unfold roundMant
  have h2q : (0 : ℚ) < 2 ^ q := by positivity
  have hz' := abs_le.mp hz
  have hkq : (2 : ℚ) ^ (k + q) = 2 ^ k * 2 ^ q := pow_add 2 k q
  have hup : z * 2 ^ q + 1 / 2 ≤ (2 : ℚ) ^ (k + q) + 1 / 2 := by rw [hkq]; nlinarith
  have hlo : -(2 : ℚ) ^ (k + q) - 1 / 2 ≤ z * 2 ^ q + 1 / 2 := by rw [hkq]; nlinarith
  have h1 := Int.floor_le (z * 2 ^ q + 1 / 2)
  have h2 := Int.lt_floor_add_one (z * 2 ^ q + 1 / 2)
  have hA : ((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) < ((2 ^ (k + q) + 1 : ℤ) : ℚ) := by push_cast; linarith
  have hB : ((-(2 ^ (k + q)) - 1 - 1 : ℤ) : ℚ) < ((⌊z * 2 ^ q + 1 / 2⌋ : ℤ) : ℚ) := by
    push_cast; linarith
  have hA' : ⌊z * 2 ^ q + 1 / 2⌋ < 2 ^ (k + q) + 1 := by exact_mod_cast hA
  have hB' : -(2 ^ (k + q)) - 1 - 1 < ⌊z * 2 ^ q + 1 / 2⌋ := by exact_mod_cast hB
  have hpos : (1 : ℤ) ≤ 2 ^ (k + q) := one_le_pow₀ (by norm_num)
  have hpow : (2 : ℤ) ^ (k + q + 1) = 2 * 2 ^ (k + q) := by ring
  rw [abs_le, hpow]
  constructor <;> omega

/-! ## The element routines -/

theorem step3ModYElem_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B)
    {i d g : ℕ} {δ : ℤ} (hg1 : 1 ≤ g) (hg2 : g ≤ P.Dstar) (hδ : |δ| ≤ 2 ^ regBits P)
    (hsz : valSize (Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN d, encN g, encZ δ]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
        Val.list [encStreamParams P, encN d, encN g, encZ δ]]] []
      (.inl body_step3ModYElem)
      (encBank R.enc (if i = d then B.mapRows (Row.addGuardY P g δ) else B)) := by
  obtain ⟨bY, hbY, hY⟩ := hC.w5.addGuardYBank
  have h2M : 2 ≤ M := le_trans (by simp only [valSize_list, listSize_cons]; omega) hsz
  have hE : valSize (Val.list [encStreamParams P, encN d, encN g, encZ δ]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN d, encN g, encZ δ]]) rfl).trans hsz
  unfold body_step3ModYElem
  by_cases hid : i = d
  · subst hid
    rw [if_pos rfl]
    refine ev_ite_t (ev_eq (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 1 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp) ?_
    have hsz' : valSize (Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]) ≤ M := by
      refine le_trans ?_ hsz
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    exact evalsVal_call_det hbY
      (ev_list (.cons (ev_get 0 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl)
        (.cons (ev_get 1 (EvalsVal.var rfl) hsz rfl)
          (.cons (ev_get 2 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl)
            (.cons (ev_get 3 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) .nil)))) hsz')
      (hY P B g δ hP hB hg1 hg2 hδ hM)
  · rw [if_neg hid]
    refine ev_ite_f (ev_eq (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 1 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp [hid]) ?_
    exact ev_get 1 (EvalsVal.var rfl) hsz rfl

theorem step3MapXYElem_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hC : Contracts R prog M)
    {P : StreamParams} (hP : ParamsOK P) (hM : Mv R P ≤ M) {B : Bank} (hB : BankOK P (R.ok P) B)
    {i d1 g : ℕ} {δ : ℤ} (hg1 : 1 ≤ g) (hg2 : g ≤ P.Dstar) (hδ : |δ| ≤ 2 ^ regBits P)
    (hsz : valSize (Val.list [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN d1, encN g, encZ δ]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encBank R.enc B,
        Val.list [encStreamParams P, encN d1, encN g, encZ δ]]] []
      (.inl body_step3MapXYElem)
      (encBank R.enc (if d1 ≤ i then B.mapRows (Row.addGuardXY P g δ) else B)) := by
  obtain ⟨bX, hbX, hX⟩ := hC.w5.addGuardXYBank
  have h2M : 2 ≤ M := le_trans (by simp only [valSize_list, listSize_cons]; omega) hsz
  have hE : valSize (Val.list [encStreamParams P, encN d1, encN g, encZ δ]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encBank R.enc B,
      Val.list [encStreamParams P, encN d1, encN g, encZ δ]]) rfl).trans hsz
  unfold body_step3MapXYElem
  by_cases hid : d1 ≤ i
  · rw [if_pos hid]
    refine ev_ite_f (ev_lt (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 1 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp; omega) ?_
    have hsz' : valSize (Val.list [encStreamParams P, encBank R.enc B, encN g, encZ δ]) ≤ M := by
      refine le_trans ?_ hsz
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    exact evalsVal_call_det hbX
      (ev_list (.cons (ev_get 0 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl)
        (.cons (ev_get 1 (EvalsVal.var rfl) hsz rfl)
          (.cons (ev_get 2 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl)
            (.cons (ev_get 3 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) .nil)))) hsz')
      (hX P B g δ hP hB hg1 hg2 hδ hM)
  · rw [if_neg hid]
    refine ev_ite_t (ev_lt (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 1 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp; omega) ?_
    exact ev_get 1 (EvalsVal.var rfl) hsz rfl

theorem step3SetLElem_val {prog : List Expr} {M : ℕ} {i d : ℕ} {L Lnew : Learner}
    (hsz : valSize (Val.list [Val.int (i : ℤ), encLearner L,
      Val.list [encN d, encLearner Lnew]]) ≤ M) :
    EvalsVal prog M [Val.list [Val.int (i : ℤ), encLearner L, Val.list [encN d, encLearner Lnew]]] []
      (.inl body_step3SetLElem) (encLearner (if i = d then Lnew else L)) := by
  have h2M : 2 ≤ M := le_trans (by simp only [valSize_list, listSize_cons]; omega) hsz
  have hE : valSize (Val.list [encN d, encLearner Lnew]) ≤ M :=
    (valSize_of_getElem?_le (k := 2) (l := [Val.int (i : ℤ), encLearner L,
      Val.list [encN d, encLearner Lnew]]) rfl).trans hsz
  unfold body_step3SetLElem
  by_cases hid : i = d
  · subst hid
    rw [if_pos rfl]
    refine ev_ite_t (ev_eq (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 0 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp) ?_
    exact ev_get 1 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl
  · rw [if_neg hid]
    refine ev_ite_f (ev_eq (ev_get 0 (EvalsVal.var rfl) hsz rfl)
      (ev_get 0 (ev_get 2 (EvalsVal.var rfl) hsz rfl) hE rfl) h2M) (by simp [hid]) ?_
    exact ev_get 1 (EvalsVal.var rfl) hsz rfl

/-! ## The indexed maps -/

/-- Common size facts. -/
theorem size_facts (R : AdaRep) (P : StreamParams) :
    2 ^ 5 * P.calL ^ 3 ≤ stateSizeBound P (R.bound P) ∧
      Mv R P = 2 ^ 32 * stateSizeBound P (R.bound P) ∧
      stateSizeBound P (R.bound P) = P.H * (bankSizeBound P (R.bound P) + 1) +
        P.H * (2 ^ 6 * P.calL ^ 3 + 1) + 2 ^ 5 * P.calL ^ 3 ∧
      1 ≤ P.H ∧ P.H ≤ P.calL ∧ 100 ≤ P.calL ∧ 100 * P.calL ≤ P.calL ^ 2 ∧
      100 * P.calL ^ 2 ≤ P.calL ^ 3 ∧ regBits P = 2 ^ 7 * P.calL ^ 3 :=
  ⟨stateSizeBound_ge P (R.bound P), rfl, rfl, P.one_le_H, H_le P, hundred_le_calL P,
    hundred_mul_calL_le_sq P, hundred_mul_sq_le_cube P, rfl⟩

theorem step3ModY_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {banks : List Bank} (hB : ∀ B ∈ banks, BankOK P (R.ok P) B)
    (hlen : banks.length ≤ P.H) {d g : ℕ} {δ : ℤ} (hg1 : 1 ≤ g) (hg2 : g ≤ P.Dstar)
    (hδ : |δ| ≤ 2 ^ regBits P)
    (hext : valSize (Val.list [encStreamParams P, encN d, encN g, encZ δ]) ≤ 2 * regBits P) :
    EvalsVal prog M
      [Val.list [encL (encBank R.enc) banks, Val.list [encStreamParams P, encN d, encN g, encZ δ]]]
      [] (.inl (body_mapIdx Idx.step3ModYStep))
      (encL (encBank R.enc) (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d banks)) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hBsz : ∀ B ∈ banks, valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) := fun B hBm =>
    BankOK.valSize_encBank_le hada (hB B hBm)
  have hL : valSize (encL (encBank R.enc) banks) ≤
      1 + banks.length * (bankSizeBound P (R.bound P) + 1) := valSize_encL_le _ _ _ hBsz
  have hHV : banks.length * (bankSizeBound P (R.bound P) + 1) ≤
      P.H * (bankSizeBound P (R.bound P) + 1) := Nat.mul_le_mul_right _ hlen
  have hVBH : bankSizeBound P (R.bound P) + 1 ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
    Nat.le_mul_of_pos_left _ hH1
  have hsl := size_le_self banks.length
  have hMI : mapIdx_M (encBank R.enc) banks (Val.list [encStreamParams P, encN d, encN g, encZ δ])
      (bankSizeBound P (R.bound P)) ≤ M := by
    unfold mapIdx_M
    omega
  have h := mapIdx_val hT.modYStep hT.modYElem hT.reverse hT.revAppendStep (encBank R.enc)
    (encBank R.enc) (Val.list [encStreamParams P, encN d, encN g, encZ δ])
    (fun i B => if i = d then B.mapRows (Row.addGuardY P g δ) else B) banks
    (bankSizeBound P (R.bound P))
    (fun i B hBm hi => step3ModYElem_val hC hP hM (hB B hBm) hg1 hg2 hδ (by
      have h1 := hBsz B hBm
      have h2 : valSize (Val.int (i : ℤ)) ≤ banks.length + 1 := by
        rw [valSize_int, bitLen_natCast]; have := size_le_self i; omega
      simp only [valSize_list, listSize_cons, listSize_nil] at hext ⊢
      omega))
    (fun i B hBm => by
      split_ifs
      · exact BankOK.valSize_encBank_le hada (bankOK_addGuardY' (hB B hBm) g δ)
      · exact hBsz B hBm)
    hMI
  rw [modifyAt_eq_L, modifyAtL_eq]
  exact h

theorem step3MapXY_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {banks : List Bank} (hB : ∀ B ∈ banks, BankOK P (R.ok P) B)
    (hlen : banks.length ≤ P.H) {d1 g : ℕ} {δ : ℤ} (hg1 : 1 ≤ g) (hg2 : g ≤ P.Dstar)
    (hδ : |δ| ≤ 2 ^ regBits P)
    (hext : valSize (Val.list [encStreamParams P, encN d1, encN g, encZ δ]) ≤ 2 * regBits P) :
    EvalsVal prog M
      [Val.list [encL (encBank R.enc) banks, Val.list [encStreamParams P, encN d1, encN g, encZ δ]]]
      [] (.inl (body_mapIdx Idx.step3MapXYStep))
      (encL (encBank R.enc) (mapFrom (Bank.mapRows (Row.addGuardXY P g δ)) d1 banks)) := by
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hBsz : ∀ B ∈ banks, valSize (encBank R.enc B) ≤ bankSizeBound P (R.bound P) := fun B hBm =>
    BankOK.valSize_encBank_le hada (hB B hBm)
  have hL : valSize (encL (encBank R.enc) banks) ≤
      1 + banks.length * (bankSizeBound P (R.bound P) + 1) := valSize_encL_le _ _ _ hBsz
  have hHV : banks.length * (bankSizeBound P (R.bound P) + 1) ≤
      P.H * (bankSizeBound P (R.bound P) + 1) := Nat.mul_le_mul_right _ hlen
  have hVBH : bankSizeBound P (R.bound P) + 1 ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
    Nat.le_mul_of_pos_left _ hH1
  have hsl := size_le_self banks.length
  have hMI : mapIdx_M (encBank R.enc) banks (Val.list [encStreamParams P, encN d1, encN g, encZ δ])
      (bankSizeBound P (R.bound P)) ≤ M := by
    unfold mapIdx_M
    omega
  have h := mapIdx_val hT.mapXYStep hT.mapXYElem hT.reverse hT.revAppendStep (encBank R.enc)
    (encBank R.enc) (Val.list [encStreamParams P, encN d1, encN g, encZ δ])
    (fun i B => if d1 ≤ i then B.mapRows (Row.addGuardXY P g δ) else B) banks
    (bankSizeBound P (R.bound P))
    (fun i B hBm hi => step3MapXYElem_val hC hP hM (hB B hBm) hg1 hg2 hδ (by
      have h1 := hBsz B hBm
      have h2 : valSize (Val.int (i : ℤ)) ≤ banks.length + 1 := by
        rw [valSize_int, bitLen_natCast]; have := size_le_self i; omega
      simp only [valSize_list, listSize_cons, listSize_nil] at hext ⊢
      omega))
    (fun i B hBm => by
      split_ifs
      · exact BankOK.valSize_encBank_le hada (bankOK_addGuardXY' (hB B hBm) g δ)
      · exact hBsz B hBm)
    hMI
  rw [mapFrom_eq_L, mapFromL_eq]
  exact h

theorem step3SetL_val {R : AdaRep} {prog : List Expr} {M : ℕ} (hT : Tree3Lib prog)
    {P : StreamParams} (hM : Mv R P ≤ M) {learners : List Learner}
    (hL : ∀ L ∈ learners, LearnerOK P 4 L) (hlen : learners.length ≤ P.H) {d : ℕ} (hd : d < P.H)
    {Lnew : Learner} (hnew : LearnerOK P 4 Lnew) :
    EvalsVal prog M [Val.list [encL encLearner learners, Val.list [encN d, encLearner Lnew]]] []
      (.inl (body_mapIdx Idx.step3SetLStep)) (encL encLearner (setAt Lnew d learners)) := by
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hLsz : ∀ L ∈ learners, valSize (encLearner L) ≤ 2 ^ 6 * P.calL ^ 3 := fun L hLm =>
    LearnerOK.valSize_encLearner_le (hL L hLm)
  have hnsz : valSize (encLearner Lnew) ≤ 2 ^ 6 * P.calL ^ 3 := LearnerOK.valSize_encLearner_le hnew
  have hLL : valSize (encL encLearner learners) ≤ 1 + learners.length * (2 ^ 6 * P.calL ^ 3 + 1) :=
    valSize_encL_le _ _ _ hLsz
  have hHV : learners.length * (2 ^ 6 * P.calL ^ 3 + 1) ≤ P.H * (2 ^ 6 * P.calL ^ 3 + 1) :=
    Nat.mul_le_mul_right _ hlen
  have hsl := size_le_self learners.length
  have hdsz : valSize (encN d) ≤ P.H + 1 := by
    rw [valSize_encN]; have := size_le_self d; omega
  have hext : valSize (Val.list [encN d, encLearner Lnew]) ≤ 2 ^ 6 * P.calL ^ 3 + P.H + 6 := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hMI : mapIdx_M encLearner learners (Val.list [encN d, encLearner Lnew])
      (2 ^ 6 * P.calL ^ 3) ≤ M := by
    unfold mapIdx_M
    omega
  have h := mapIdx_val hT.setLStep hT.setLElem hT.reverse hT.revAppendStep encLearner encLearner
    (Val.list [encN d, encLearner Lnew]) (fun i L => if i = d then Lnew else L) learners
    (2 ^ 6 * P.calL ^ 3)
    (fun i L hLm hi => step3SetLElem_val (by
      have h1 := hLsz L hLm
      have h2 : valSize (Val.int (i : ℤ)) ≤ learners.length + 1 := by
        rw [valSize_int, bitLen_natCast]; have := size_le_self i; omega
      simp only [valSize_list, listSize_cons, listSize_nil] at hext ⊢
      omega))
    (fun i L hLm => by
      split_ifs
      · exact hnsz
      · exact hLsz L hLm)
    hMI
  rw [setAt_eq_L, setAtL_eq]
  exact h

end F2e2e.C.Impl.W6
