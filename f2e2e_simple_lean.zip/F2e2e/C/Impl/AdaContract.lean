import F2e2e.C.Impl.AdaRep
import F2e2e.C.Impl.AdaSampler
import F2e2e.C.Impl.AdaPub
import F2e2e.C.Impl.AdaInit
import F2e2e.C.Impl.AdaMus
import F2e2e.C.Impl.AdaPrep
import F2e2e.C.Impl.AdaEntry
import F2e2e.C.Impl.AdaEntryNum
import F2e2e.C.Impl.AdaContractAux

/-!
# ADA module (W4): the routine table and the contract `W4Contract adaRep`

Owner: W4 (cc77ceaa). Entry routines (indices fixed by `F2e2e/C/Impl/W6Contracts.lean`):
`adaPub` 600, `adaInit` 601, `adaInterval` 602, `adaNumerical` 603, `adaQA` 604, `adaBlockSizes` 605;
internal helpers in 606–749 (sampler 610–614, `AdaSampler.lean`; initialization 615–620,
`AdaInit.lean`; the parameter record 600/604/605 and its helpers 650–699 are W2's `AdaPub.lean`,
table `adaPubTable`).

* `w4Table` : the `(index, body)` entries of W4 outside `adaPubTable` (to be included in the final
  `mkProg` table, together with `adaPubTable` and `w4LibDeps`);
* `w4AllTable` : ALL entries of the module (the table to include in the final program);
* `W4Lib prog` : every entry of `w4AllTable` is in `prog`;
* `w4Contract` : the contract, from W1's parameter routines and W5's `normQ`.

**Assembly.** `adaPub`, `adaQA`, `adaBlockSizes` (W2, `AdaPub.lean`), `adaInit` (`AdaInit.lean`),
`adaInterval` (W2, `AdaEntry.lean`), `adaNumerical` (A-ARCH, `AdaEntryNum.lean`); the predictions
(`AdaMus.lean`) and `PrepareRoot` (B-NUM/B-ARCH, `AdaPrep.lean`) are called through their specs.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## The table and the library predicate -/

/-- **W4's routine table** outside the parameter record (`(index, body)` entries; all indices in
`600–749`). -/
def w4Table : List (ℕ × Expr) :=
  [(Idx.adaInit, body_adaInit),
    (Cost.Idx.adaCoin, body_adaCoin), (Cost.Idx.adaCoinStep, body_adaCoinStep),
    (Cost.Idx.adaCount, body_adaCount), (Cost.Idx.adaCountStep, body_adaCountStep),
    (Cost.Idx.adaLattice, body_adaLattice),
    (Cost.Idx.adaThrMap, body_mapB Cost.Idx.adaThrMapStep),
    (Cost.Idx.adaThrMapStep, body_mapBStep Cost.Idx.adaThrEl),
    (Cost.Idx.adaThrEl, body_adaThrEl),
    (Cost.Idx.adaRepMap, body_mapB Cost.Idx.adaRepMapStep),
    (Cost.Idx.adaRepMapStep, body_mapBStep Cost.Idx.adaRepEl),
    (Cost.Idx.adaRepEl, body_adaRepEl),
    (Cost.Idx.wlFKFold, body_foldB Cost.Idx.wlFKStep),
    (Cost.Idx.wlFKStep, body_foldBStep Cost.Idx.wlFKEl),
    (Cost.Idx.wlFKEl, body_wlFKEl),
    (Cost.Idx.wlMassFold, body_foldB Cost.Idx.wlMassStep),
    (Cost.Idx.wlMassStep, body_foldBStep Cost.Idx.wlMassEl),
    (Cost.Idx.wlMassEl, body_wlMassEl),
    (Cost.Idx.wlTryR, body_wlTry),
    (Cost.Idx.wlLevelFold, body_foldB Cost.Idx.wlLevelStep),
    (Cost.Idx.wlLevelStep, body_foldBStep Cost.Idx.wlLevelEl),
    (Cost.Idx.wlLevelEl, body_wlLevelEl),
    (Cost.Idx.pnFold, body_foldB Cost.Idx.pnStep),
    (Cost.Idx.pnStep, body_foldBStep Cost.Idx.pnEl),
    (Cost.Idx.pnEl, body_pnEl),
    (Cost.Idx.adaMuJ, body_muJ),
    (Cost.Idx.adaMusMap, body_mapB Cost.Idx.adaMusMapStep),
    (Cost.Idx.adaMusMapStep, body_mapBStep Cost.Idx.adaMuJ),
    (Cost.Idx.adaMusR, body_adaMusR)]

/-- The library routines (outside `600–749`) called by W4's bodies (outside `adaPubTable`). -/
def w4LibDeps : List (ℕ × Expr) :=
  [(Cost.Idx.readNat, body_readNat), (Cost.Idx.readNatStep, body_readNatStep),
    (Cost.Idx.get, body_get), (Cost.Idx.getStep, body_getStep),
    (Cost.Idx.set, body_set), (Cost.Idx.setStep, body_setStep),
    (Cost.Idx.revAppendStep, body_revAppendStep), (Cost.Idx.reverse, body_reverse),
    (Cost.Idx.length, body_length), (Cost.Idx.lengthStep, body_lengthStep),
    (Cost.Idx.replicate, body_replicate), (Cost.Idx.replicateStep, body_replicateStep),
    (Cost.Idx.take, body_take),
    (Cost.Idx.range, body_range), (Cost.Idx.rangeStep, body_rangeStep),
    (Cost.Idx.sum, body_sum), (Cost.Idx.sumStep, body_sumStep)]

/-- **All of W4's routines** (`(index, body)` entries of the whole ADA module, its helpers and the
library routines it calls): the table to include in the final `mkProg` table. -/
def w4AllTable : List (ℕ × Expr) :=
  w4Table ++ adaPubTable ++ adaPrepTable ++ adaEntryTable ++ adaNumTable ++ w4LibDeps

/-- **W4's library predicate**: every entry of `w4AllTable` is in `prog`. -/
def W4Lib (prog : List Expr) : Prop := ∀ e ∈ w4AllTable, prog[e.1]? = some e.2

/-- All indices of W4's tables are positive. -/
theorem w4_indices_pos : ∀ e ∈ w4AllTable, 0 < e.1 := by
  decide

/-- `W4Lib` for a program assembled by `mkProg` from a table in which every entry of
`w4AllTable` is found by `List.lookup` (proved by `rfl` / `decide` on the final table). -/
theorem W4Lib.of_lookup {main : Expr} {tbl : List (ℕ × Expr)}
    (h : ∀ e ∈ w4AllTable, tbl.lookup e.1 = some e.2) :
    W4Lib (mkProg main tbl) :=
  fun e he => mkProg_get_of_lookup (h e he) (w4_indices_pos e he)

section Lookups

variable {prog : List Expr}

theorem W4Lib.tbl (h : W4Lib prog) {e : ℕ × Expr} (he : e ∈ w4Table) : prog[e.1]? = some e.2 :=
  h e (by unfold w4AllTable; simp [he])

theorem W4Lib.pubTbl (h : W4Lib prog) : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2 :=
  fun e he => h e (by unfold w4AllTable; simp [he])

theorem W4Lib.dep (h : W4Lib prog) {e : ℕ × Expr} (he : e ∈ w4LibDeps) : prog[e.1]? = some e.2 :=
  h e (by unfold w4AllTable; simp [he])

theorem W4Lib.prepTbl (h : W4Lib prog) : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2 :=
  fun e he => h e (by unfold w4AllTable; simp [he])

theorem W4Lib.entryTbl (h : W4Lib prog) : ∀ e ∈ adaEntryTable, prog[e.1]? = some e.2 :=
  fun e he => h e (by unfold w4AllTable; simp [he])

theorem W4Lib.numTbl (h : W4Lib prog) : ∀ e ∈ adaNumTable, prog[e.1]? = some e.2 :=
  fun e he => h e (by unfold w4AllTable; simp [he])

theorem W4Lib.samp (h : W4Lib prog) : SampLib prog where
  lat := h.tbl (e := (_, body_adaLattice)) (by simp [w4Table])
  cnt := h.tbl (e := (_, body_adaCount)) (by simp [w4Table])
  cntStep := h.tbl (e := (_, body_adaCountStep)) (by simp [w4Table])
  coinStep := h.tbl (e := (_, body_adaCoinStep)) (by simp [w4Table])
  coin := h.tbl (e := (_, body_adaCoin)) (by simp [w4Table])
  rnStep := h.dep (e := (_, body_readNatStep)) (by simp [w4LibDeps])
  rn := h.dep (e := (_, body_readNat)) (by simp [w4LibDeps])

theorem W4Lib.list (h : W4Lib prog) : ListLib prog where
  get := h.dep (e := (_, body_get)) (by simp [w4LibDeps])
  getStep := h.dep (e := (_, body_getStep)) (by simp [w4LibDeps])
  set := h.dep (e := (_, body_set)) (by simp [w4LibDeps])
  setStep := h.dep (e := (_, body_setStep)) (by simp [w4LibDeps])
  revAppendStep := h.dep (e := (_, body_revAppendStep)) (by simp [w4LibDeps])
  reverse := h.dep (e := (_, body_reverse)) (by simp [w4LibDeps])
  length := h.dep (e := (_, body_length)) (by simp [w4LibDeps])
  lengthStep := h.dep (e := (_, body_lengthStep)) (by simp [w4LibDeps])
  replicate := h.dep (e := (_, body_replicate)) (by simp [w4LibDeps])
  replicateStep := h.dep (e := (_, body_replicateStep)) (by simp [w4LibDeps])
  take := h.dep (e := (_, body_take)) (by simp [w4LibDeps])

theorem W4Lib.init (h : W4Lib prog) : InitLib prog where
  thrMap := h.tbl (e := (_, body_mapB Cost.Idx.adaThrMapStep)) (by simp [w4Table])
  thrMapStep := h.tbl (e := (_, body_mapBStep Cost.Idx.adaThrEl)) (by simp [w4Table])
  thrEl := h.tbl (e := (_, body_adaThrEl)) (by simp [w4Table])
  repMap := h.tbl (e := (_, body_mapB Cost.Idx.adaRepMapStep)) (by simp [w4Table])
  repMapStep := h.tbl (e := (_, body_mapBStep Cost.Idx.adaRepEl)) (by simp [w4Table])
  repEl := h.tbl (e := (_, body_adaRepEl)) (by simp [w4Table])

theorem W4Lib.mus (h : W4Lib prog) : MusLib prog :=
  ⟨h.tbl (e := (_, body_adaMusR)) (by simp [w4Table]),
    { list := h.list
      range := h.dep (e := (_, body_range)) (by simp [w4LibDeps])
      rangeStep := h.dep (e := (_, body_rangeStep)) (by simp [w4LibDeps])
      sum := h.dep (e := (_, body_sum)) (by simp [w4LibDeps])
      sumStep := h.dep (e := (_, body_sumStep)) (by simp [w4LibDeps])
      folds :=
        { fkFold := h.tbl (e := (_, body_foldB Cost.Idx.wlFKStep)) (by simp [w4Table])
          fkStep := h.tbl (e := (_, body_foldBStep Cost.Idx.wlFKEl)) (by simp [w4Table])
          fkEl := h.tbl (e := (_, body_wlFKEl)) (by simp [w4Table])
          massFold := h.tbl (e := (_, body_foldB Cost.Idx.wlMassStep)) (by simp [w4Table])
          massStep := h.tbl (e := (_, body_foldBStep Cost.Idx.wlMassEl)) (by simp [w4Table])
          massEl := h.tbl (e := (_, body_wlMassEl)) (by simp [w4Table]) }
      tryR := h.tbl (e := (_, body_wlTry)) (by simp [w4Table])
      levelFold := h.tbl (e := (_, body_foldB Cost.Idx.wlLevelStep)) (by simp [w4Table])
      levelStep := h.tbl (e := (_, body_foldBStep Cost.Idx.wlLevelEl)) (by simp [w4Table])
      levelEl := h.tbl (e := (_, body_wlLevelEl)) (by simp [w4Table])
      pnFold := h.tbl (e := (_, body_foldB Cost.Idx.pnStep)) (by simp [w4Table])
      pnStep := h.tbl (e := (_, body_foldBStep Cost.Idx.pnEl)) (by simp [w4Table])
      pnEl := h.tbl (e := (_, body_pnEl)) (by simp [w4Table])
      muJ := h.tbl (e := (_, body_muJ)) (by simp [w4Table])
      musMap := h.tbl (e := (_, body_mapB Cost.Idx.adaMusMapStep)) (by simp [w4Table])
      musMapStep := h.tbl (e := (_, body_mapBStep Cost.Idx.adaMuJ)) (by simp [w4Table]) }⟩

end Lookups

/-! ## The contract -/

/-- **The W4 contract** for `adaRep` (from W1's parameter routines and W5's `normQ`). -/
theorem w4Contract {prog : List Expr} {M : ℕ} (hlib : W4Lib prog) (hw1 : W1Contract adaRep prog M)
    (hq : NormQSpec prog M) : W4Contract adaRep prog M where
  adaPub := ⟨body_adaPub, hlib.pubTbl (Idx.adaPub, body_adaPub) (by simp [adaPubTable]),
    fun _ hP hM => adaPub_eval hlib.pubTbl hw1 hq hP hM⟩
  adaQA := ⟨body_adaQA, hlib.pubTbl (Idx.adaQA, body_adaQA) (by simp [adaPubTable]),
    fun _ hP hM => adaQA_eval hlib.pubTbl hw1 hq hP hM⟩
  adaBlockSizes := ⟨body_adaBlockSizes,
    hlib.pubTbl (Idx.adaBlockSizes, body_adaBlockSizes) (by simp [adaPubTable]),
    fun _ hP hM => adaBlockSizes_eval hlib.pubTbl hw1 hq hP hM⟩
  adaInit := ⟨body_adaInit, hlib.tbl (e := (_, body_adaInit)) (by simp [w4Table]),
    fun P _ hM => adaInit_impl hlib.samp hlib.list hlib.init (bankAda_blockSizes_length P)
      (bankAda_Tmax_length P) (Mv_adaRep_ge hM).1⟩
  adaInterval := ⟨body_adaInterval,
    hlib.entryTbl (Idx.adaInterval, body_adaInterval) (by simp [adaEntryTable]),
    fun P _ _ _ _ _ hok hv hl hu hM =>
      adaInterval_impl hlib.entryTbl hlib.prepTbl hlib.mus hlib.samp hlib.list hq
        (bankAda_blockSizes_length P) (bankAda_Tmax_length P) (bankAda_blockSizes_pos P) hok hv
        (QOK.bits hl) (QOK.bits hu) (Mv_adaRep_ge hM).1 (Mv_adaRep_q hM)⟩
  adaNumerical := ⟨body_adaNumerical,
    hlib.numTbl (Idx.adaNumerical, body_adaNumerical) (by simp [adaNumTable]),
    fun P _ _ _ hok hv hM =>
      adaNumerical_impl_of
        ⟨body_adaPrep, hlib.prepTbl (Idx.adaPrepR, body_adaPrep) (by simp [adaPrepTable]),
          fun _ f _ hok' hf hc => adaPrep_impl hlib.prepTbl hlib.mus hlib.samp hlib.list
            (bankAda_blockSizes_length P) (bankAda_Tmax_length P) (bankAda_blockSizes_pos P) hok' hv
            f hf hc (Mv_adaRep_ge hM).1⟩
        hlib.mus hlib.samp hlib.list hq (bankAda_blockSizes_length P) (bankAda_Tmax_length P)
        (bankAda_blockSizes_pos P) hok hv (Mv_adaRep_ge hM).1⟩

end F2e2e.C.Impl
