import F2e2e.C.Impl.AdaInit

/-!
# ADA module (W4), part 6: validity of the representation, `adaRep_valid`

Owner: B-NUM (b5a655d4), for W4 (cc77ceaa). Reference level only (no DSL code).

`adaRep.Valid` (`F2e2e/C/Impl/W6Contracts.lean`) asks for C-SPACE's `AdaInvariant` and five size
bounds:
* `AdaInvariant`: the invariant `AdaOK` is established by `adaInit` (W4's `adaInit_ok`) and preserved by
  `adaInterval`, `adaNumerical` on every path of fresh bits, for all states satisfying it and ALL inputs
  `vals, l, u` (`adaInterval_ok`, `adaNumerical_ok`, here);
* `enc_le`, `pub_le`, `qA_le`, `vals_le`: W4's `AdaBounds.lean`;
* `num_le`: the numerical output `clip_{[0,1]}(h_A n)` is `m/2^{qA}` with `0 ≤ m ≤ 2^{qA}`
  (`adaNumerical_num_le`, here).

Method: `DAlw B prog Q`, an every-leaf predicate of noise-draw programs in which every draw returns a
value satisfying `B`. With `B = adaKB A` (`|z| ≤ maxKs A`, true for the bounded sampler, W4's
`adaDraw_always`), `DAlw.toBits` transfers it to the fresh-bit implementation `prog.toBits (adaDraw A)`.

Preservation (B-ARCH's `F2e2e/B/ArchCore.lean`):
* `applyCorrection` (guarded by `T_j < T_j^max`, `j < p`; `applyCorrection_eq_avState` splits it into the
  threshold redraws and the pure update `avState`): every score moves by at most `4·2^{qA}`
  (`blockVals` clips to `2^{qA}`) while `∑ T` grows by `1` (`scores_le`); the weights are recomputed by
  `capWeightsQ` of the new scores (`weights`); the redrawn thresholds are draws (`thr_le`);
* `scanPass`, `prepareRoot`: by induction on the edge list and on the fuel; they leave `halted, rej,
  nInt, nNum, thrOut` untouched (`AdaSameCtr`);
* `outerReject`: `rej_halt` (`¬ halted → rej ≤ J`) gives `rej + 1 ≤ J + 1`;
* the request caps give `nInt ≤ M`, `nNum ≤ R`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## Every-leaf predicate of noise-draw programs with bounded draws -/

/-- Every leaf of the noise-draw program `prog` reached through draws whose values satisfy `B`
satisfies `Q`. -/
def DAlw {α : Type} (B : ℤ → Prop) : NoiseProg α → (α → Prop) → Prop
  | DrawProg.ret a, Q => Q a
  | DrawProg.draw _ k, Q => ∀ z, B z → DAlw B (k z) Q

namespace DAlw

variable {B : ℤ → Prop} {α γ : Type}

/-- Transfer to the fresh-bit implementation by samplers whose outputs satisfy `B`. -/
theorem toBits {s : NoiseKind → BitProg ℤ} (hs : ∀ κ, Always (s κ) B) {Q : α → Prop} :
    ∀ {prog : NoiseProg α}, DAlw B prog Q → Always (prog.toBits s) Q
  | DrawProg.ret _, h => h
  | DrawProg.draw κ _, h => Always.bind (fun z hz => toBits hs (h z hz)) (hs κ)

theorem bind {Q : α → Prop} {R : γ → Prop} {f : α → NoiseProg γ}
    (hf : ∀ a, Q a → DAlw B (f a) R) :
    ∀ {prog : NoiseProg α}, DAlw B prog Q → DAlw B (prog.bind f) R
  | DrawProg.ret a, h => hf a h
  | DrawProg.draw _ _, h => fun z hz => bind hf (h z hz)

theorem mono {Q Q' : α → Prop} (hQ : ∀ a, Q a → Q' a) :
    ∀ {prog : NoiseProg α}, DAlw B prog Q → DAlw B prog Q'
  | DrawProg.ret a, h => hQ a h
  | DrawProg.draw _ _, h => fun z hz => mono hQ (h z hz)

theorem true' : ∀ (prog : NoiseProg α), DAlw B prog (fun _ => True)
  | DrawProg.ret _ => trivial
  | DrawProg.draw _ k => fun z _ => true' (k z)

theorem bind_all {R : γ → Prop} {f : α → NoiseProg γ} (hf : ∀ a, DAlw B (f a) R)
    (prog : NoiseProg α) : DAlw B (prog.bind f) R :=
  bind (Q := fun _ => True) (fun a _ => hf a) (true' prog)

/-- One draw: its value satisfies `B`. -/
theorem ofDraw (κ : NoiseKind) : DAlw B (F2e2e.B.drawNoise κ) B := fun _ hz => hz

end DAlw

/-- The draw bound of the bounded sampler of `A` (`adaDraw_always`). -/
def adaKB (A : AdaParams) (z : ℤ) : Prop := |z| ≤ (maxKs A : ℤ)

theorem adaDraw_adaKB (A : AdaParams) (κ : NoiseKind) : Always (adaDraw A κ) (adaKB A) :=
  adaDraw_always A κ

/-- The counters that `PrepareRoot` leaves untouched. -/
def AdaSameCtr (s t : AdaState) : Prop :=
  t.halted = s.halted ∧ t.rej = s.rej ∧ t.nInt = s.nInt ∧ t.nNum = s.nNum ∧ t.thrOut = s.thrOut

theorem AdaSameCtr.refl (s : AdaState) : AdaSameCtr s s := ⟨rfl, rfl, rfl, rfl, rfl⟩

theorem AdaSameCtr.trans {s t u : AdaState} (h₁ : AdaSameCtr s t) (h₂ : AdaSameCtr t u) : AdaSameCtr s u :=
  ⟨h₂.1.trans h₁.1, h₂.2.1.trans h₁.2.1, h₂.2.2.1.trans h₁.2.2.1, h₂.2.2.2.1.trans h₁.2.2.2.1,
    h₂.2.2.2.2.trans h₁.2.2.2.2⟩

/-! ## List helpers -/

/-- `getD` of a `set` list. -/
theorem av_getD_set {β : Type} (l : List β) (n j : ℕ) (x d : β) :
    (l.set n x).getD j d = if n = j ∧ n < l.length then x else l.getD j d := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_set]
  by_cases h1 : n = j
  · subst h1
    by_cases h2 : n < l.length
    · simp [h2]
    · simp [h2]
  · simp [h1]

/-- Replacing a row by one of the same length keeps every row length. -/
theorem av_length_getD_set {l : List (List ℤ)} {n : ℕ} {x : List ℤ}
    (hx : x.length = (l.getD n []).length) (j : ℕ) :
    ((l.set n x).getD j []).length = (l.getD j []).length := by
  rw [av_getD_set]
  split_ifs with h
  · rw [hx, h.1]
  · rfl

/-- A row-wise property of a list of rows holds for the row read with default `[]`. -/
theorem av_forall_mem_getD {l : List (List ℤ)} {P : ℤ → Prop} (h : ∀ g ∈ l, ∀ z ∈ g, P z) (n : ℕ) :
    ∀ z ∈ l.getD n [], P z := by
  by_cases hn : n < l.length
  · rw [List.getD_eq_getElem _ _ hn]
    exact h _ (List.getElem_mem hn)
  · rw [List.getD_eq_default _ _ (by omega)]
    intro z hz
    simp at hz

/-- Incrementing one entry of a list of naturals increments its sum. -/
theorem av_sum_set_succ : ∀ (l : List ℕ) (j : ℕ), j < l.length →
    (l.set j (l.getD j 0 + 1)).sum = l.sum + 1
  | [], j, h => absurd h (by simp)
  | a :: l, 0, _ => by simp; omega
  | a :: l, j + 1, h => by
    simp only [List.set_cons_succ, List.getD_cons_succ, List.sum_cons]
    rw [av_sum_set_succ l j (by simpa using h)]
    omega

/-! ## `addScaled` and `blockVals` -/

theorem av_length_addScaled (g : List ℤ) (c : ℤ) (v : List ℕ) : (addScaled g c v).length = g.length := by
  simp [addScaled]

theorem av_abs_le_of_mem_addScaled {g : List ℤ} {c : ℤ} {v : List ℕ} {z Bg Bv : ℤ}
    (hz : z ∈ addScaled g c v) (hg : ∀ x ∈ g, |x| ≤ Bg) (hv : ∀ i, ((v.getD i 0 : ℕ) : ℤ) ≤ Bv) :
    |z| ≤ Bg + |c| * Bv := by
  unfold addScaled at hz
  obtain ⟨i, hi, hzi⟩ := List.mem_mapIdx.mp hz
  rw [← hzi]
  have h1 := hg _ (List.getElem_mem hi)
  have h2 := hv i
  have h3 : (0 : ℤ) ≤ ((v.getD i 0 : ℕ) : ℤ) := Int.natCast_nonneg _
  have h4 : |c * ((v.getD i 0 : ℕ) : ℤ)| = |c| * ((v.getD i 0 : ℕ) : ℤ) := by
    rw [abs_mul, abs_of_nonneg h3]
  calc |g[i] + c * ((v.getD i 0 : ℕ) : ℤ)| ≤ |g[i]| + |c * ((v.getD i 0 : ℕ) : ℤ)| := abs_add_le _ _
    _ = |g[i]| + |c| * ((v.getD i 0 : ℕ) : ℤ) := by rw [h4]
    _ ≤ Bg + |c| * Bv := add_le_add h1 (mul_le_mul_of_nonneg_left h2 (abs_nonneg c))

/-- `blockVals` clips the grid indices to `2^{qA}`. -/
theorem av_blockVals_getD_le (A : AdaParams) (vals : List (List ℕ)) (j i : ℕ) :
    (((blockVals A vals j).getD i 0 : ℕ) : ℤ) ≤ 2 ^ A.qA := by
  unfold blockVals
  rw [List.getD_eq_getElem?_getD, List.getElem?_map]
  cases (vals.getD j [])[i]? with
  | none => simp
  | some x =>
    simp only [Option.map_some, Option.getD_some]
    push_cast
    exact min_le_right _ _

/-! ## `applyCorrection`: the threshold redraws and the pure update -/

/-- The sign `q ∈ {+1, -1}` of a correction. -/
def avSign (q : Bool) : ℤ := if q then 1 else -1

theorem av_abs_sign (q : Bool) : |avSign q| = 1 := by cases q <;> simp [avSign]

/-- The corrected row `g_j + 4 q v_j`. -/
def avRow (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) : List ℤ :=
  addScaled (st.scores.getD j []) (4 * avSign q) (blockVals A vals j)

/-- The corrected row `g_{j+1} - q v_{j+1}` (read after the update of row `j`). -/
def avRow1 (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) : List ℤ :=
  addScaled ((st.scores.set j (avRow A st vals j q)).getD (j + 1) []) (-avSign q)
    (blockVals A vals (j + 1))

/-- The scores after a correction on edge `j`. -/
def avScores (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    List (List ℤ) :=
  if j + 1 < A.p then (st.scores.set j (avRow A st vals j q)).set (j + 1) (avRow1 A st vals j q)
  else st.scores.set j (avRow A st vals j q)

/-- The weights after a correction on edge `j`. -/
def avWeights (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool) :
    List (List ℚ) :=
  if j + 1 < A.p then
    (st.weights.set j (capWeightsQ (scoreScale A) (avRow A st vals j q))).set (j + 1)
      (capWeightsQ (scoreScale A) (avRow1 A st vals j q))
  else st.weights.set j (capWeightsQ (scoreScale A) (avRow A st vals j q))

/-- The state after a correction on edge `j` with the redrawn thresholds `thr`. -/
def avState (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool)
    (thr : List ℤ) : AdaState :=
  { st with
    scores := avScores A st vals j q
    weights := avWeights A st vals j q
    T := st.T.set j (st.T.getD j 0 + 1)
    thrInt := thr }

theorem applyCorrection_eq_avState (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ)
    (q : Bool) : applyCorrection A st vals j q =
      (redrawThresholds A (reopenEdges A j) st.thrInt).bind fun thr =>
        DrawProg.ret (avState A st vals j q thr) := rfl

/-- The threshold redraws keep the length and the draw bound. -/
theorem redrawThresholds_ok (A : AdaParams) : ∀ (es : List ℕ) (thr : List ℤ), (∀ z ∈ thr, adaKB A z) →
    DAlw (adaKB A) (redrawThresholds A es thr) (fun t => t.length = thr.length ∧ ∀ z ∈ t, adaKB A z)
  | [], thr, h => ⟨rfl, h⟩
  | e :: es, thr, h => by
    show DAlw (adaKB A) ((drawNoise NoiseKind.intThr).bind fun k =>
      redrawThresholds A es (thr.set e k)) _
    refine DAlw.bind (Q := adaKB A) (fun k hk => ?_) (DAlw.ofDraw _)
    refine DAlw.mono (fun t ht => ⟨by rw [ht.1, List.length_set], ht.2⟩)
      (redrawThresholds_ok A es (thr.set e k) ?_)
    intro z hz
    rcases List.mem_or_eq_of_mem_set hz with hz | rfl
    · exact h z hz
    · exact hk

/-- **The pure update of a correction preserves the invariant.** -/
theorem avState_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ))
    {j : ℕ} (q : Bool) (hj : j < A.p) (hT : st.T.getD j 0 < A.Tmax.getD j 0) {thr : List ℤ}
    (hthr : thr.length = A.p) (hthrK : ∀ z ∈ thr, adaKB A z) :
    AdaOK A (avState A st vals j q thr) := by
  have hjT : j < st.T.length := by rw [h.T_len]; exact hj
  have hrow : (avRow A st vals j q).length = (st.scores.getD j []).length :=
    av_length_addScaled _ _ _
  have hrow1 : (avRow1 A st vals j q).length =
      ((st.scores.set j (avRow A st vals j q)).getD (j + 1) []).length :=
    av_length_addScaled _ _ _
  have hqA : (0 : ℤ) ≤ 2 ^ A.qA := by positivity
  have hS0 : (0 : ℤ) ≤ (st.T.sum : ℤ) := Int.natCast_nonneg _
  have hstep : 4 * 2 ^ A.qA * (st.T.sum : ℤ) ≤ 4 * 2 ^ A.qA * ((st.T.sum : ℤ) + 1) := by
    nlinarith
  have hrowB : ∀ z ∈ avRow A st vals j q, |z| ≤ 4 * 2 ^ A.qA * ((st.T.sum : ℤ) + 1) := by
    intro z hz
    have := av_abs_le_of_mem_addScaled hz (av_forall_mem_getD h.scores_le j)
      (av_blockVals_getD_le A vals j)
    have hc : |4 * avSign q| = 4 := by rw [abs_mul, av_abs_sign]; norm_num
    rw [hc] at this
    linarith
  have hrow1B : ∀ z ∈ avRow1 A st vals j q, |z| ≤ 4 * 2 ^ A.qA * ((st.T.sum : ℤ) + 1) := by
    intro z hz
    have hbase : (st.scores.set j (avRow A st vals j q)).getD (j + 1) [] =
        st.scores.getD (j + 1) [] := by
      rw [av_getD_set, if_neg (by omega)]
    unfold avRow1 at hz
    rw [hbase] at hz
    have := av_abs_le_of_mem_addScaled hz (av_forall_mem_getD h.scores_le (j + 1))
      (av_blockVals_getD_le A vals (j + 1))
    rw [abs_neg, av_abs_sign] at this
    linarith
  have hsum : ((st.T.set j (st.T.getD j 0 + 1)).sum : ℤ) = (st.T.sum : ℤ) + 1 := by
    rw [av_sum_set_succ _ _ hjT]
    push_cast
    rfl
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · -- scores_len
    show (avScores A st vals j q).length = A.p
    unfold avScores
    split_ifs <;> simp [h.scores_len]
  · -- scores_blk
    intro j' hj'
    show ((avScores A st vals j q).getD j' []).length = A.blockSizes.getD j' 0
    rw [← h.scores_blk j' hj']
    unfold avScores
    split_ifs
    · rw [av_length_getD_set hrow1 j', av_length_getD_set hrow j']
    · rw [av_length_getD_set hrow j']
  · -- weights
    show avWeights A st vals j q = (avScores A st vals j q).map (capWeightsQ (scoreScale A))
    unfold avWeights avScores
    rw [h.weights]
    split_ifs <;> simp only [List.map_set]
  · -- T_len
    show (st.T.set j (st.T.getD j 0 + 1)).length = A.p
    rw [List.length_set, h.T_len]
  · -- T_le
    intro j' hj'
    show (st.T.set j (st.T.getD j 0 + 1)).getD j' 0 ≤ A.Tmax.getD j' 0
    rw [av_getD_set]
    split_ifs with hc
    · rw [← hc.1]
      omega
    · exact h.T_le j' hj'
  · -- thr_len
    exact hthr
  · -- thr_le
    exact hthrK
  · -- thrOut_le
    exact h.thrOut_le
  · -- scores_le
    intro g hg z hz
    show |z| ≤ 4 * 2 ^ A.qA * ((st.T.set j (st.T.getD j 0 + 1)).sum : ℤ)
    rw [hsum]
    change g ∈ avScores A st vals j q at hg
    unfold avScores at hg
    split_ifs at hg
    · rcases List.mem_or_eq_of_mem_set hg with hg | rfl
      · rcases List.mem_or_eq_of_mem_set hg with hg | rfl
        · exact (h.scores_le g hg z hz).trans hstep
        · exact hrowB z hz
      · exact hrow1B z hz
    · rcases List.mem_or_eq_of_mem_set hg with hg | rfl
      · exact (h.scores_le g hg z hz).trans hstep
      · exact hrowB z hz
  · exact h.rej_le
  · exact h.rej_halt
  · exact h.nInt_le
  · exact h.nNum_le

theorem avState_sameCtr (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (j : ℕ) (q : Bool)
    (thr : List ℤ) : AdaSameCtr st (avState A st vals j q thr) := AdaSameCtr.refl st

/-- **A correction preserves the invariant** (on every path of draws bounded by `maxKs A`). -/
theorem applyCorrection_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ))
    {j : ℕ} (q : Bool) (hj : j < A.p) (hT : st.T.getD j 0 < A.Tmax.getD j 0) :
    DAlw (adaKB A) (applyCorrection A st vals j q) (fun st' => AdaOK A st' ∧ AdaSameCtr st st') := by
  rw [applyCorrection_eq_avState]
  refine DAlw.bind (fun thr hthr => ?_) (redrawThresholds_ok A (reopenEdges A j) st.thrInt h.thr_le)
  exact ⟨avState_ok h vals q hj hT (hthr.1.trans h.thr_len) hthr.2,
    avState_sameCtr A st vals j q thr⟩

/-! ## `scanPass` and `prepareRoot` -/

/-- **A scan pass preserves the invariant and the counters.** -/
theorem scanPass_ok {A : AdaParams} (vals : List (List ℕ)) (mus : List ℚ) :
    ∀ (es : List ℕ), (∀ j ∈ es, j < A.p) → ∀ (st : AdaState) (cache : List Bool), AdaOK A st →
      DAlw (adaKB A) (scanPass A vals mus es st cache) (fun r => AdaOK A r.2.1 ∧ AdaSameCtr st r.2.1)
  | [], _, st, _, h => ⟨h, AdaSameCtr.refl st⟩
  | j :: es, hes, st, cache, h => by
    have hj : j < A.p := hes j List.mem_cons_self
    have hes' : ∀ j' ∈ es, j' < A.p := fun j' hj' => hes j' (List.mem_cons_of_mem _ hj')
    rw [scanPass]
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      exact scanPass_ok vals mus es hes' st cache h
    · rw [if_neg hc]
      refine DAlw.bind_all (fun r => ?_) _
      cases r with
      | none => exact scanPass_ok vals mus es hes' st (cache.set j true) h
      | some q =>
        dsimp only
        by_cases hcap : A.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hcap]
          exact ⟨h, AdaSameCtr.refl st⟩
        · rw [if_neg hcap]
          refine DAlw.bind (fun st' hst' => ?_) (applyCorrection_ok h vals q hj (by omega))
          exact hst'

/-- **`PrepareRoot` preserves the invariant and the counters.** -/
theorem prepareRoot_ok {A : AdaParams} (vals : List (List ℕ)) :
    ∀ (fuel : ℕ) (st : AdaState) (cache : List Bool), AdaOK A st →
      DAlw (adaKB A) (prepareRoot A vals fuel st cache)
        (fun r => ∀ st', r = some st' → AdaOK A st' ∧ AdaSameCtr st st')
  | 0, _, _, _ => fun _ h' => by cases h'
  | fuel + 1, st, cache, h => by
    rw [prepareRoot]
    refine DAlw.bind (fun r hr => ?_)
      (scanPass_ok vals (adaMus A st vals) (List.range A.p) (fun j hj => List.mem_range.mp hj) st
        cache h)
    obtain ⟨o, st1, c1⟩ := r
    obtain ⟨hok1, hs1⟩ := hr
    cases o with
    | done =>
      intro st' h'
      cases h'
      exact ⟨hok1, hs1⟩
    | corrected =>
      exact DAlw.mono (fun r hr st' h' => ⟨(hr st' h').1, hs1.trans (hr st' h').2⟩)
        (prepareRoot_ok vals fuel st1 c1 hok1)
    | abort =>
      intro st' h'
      cases h'

/-! ## The outer rejection and the two interfaces -/

/-- **An outer rejection preserves the invariant** (in a non-halted state). -/
theorem outerReject_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (hh : st.halted = false)
    (high : Bool) : DAlw (adaKB A) (outerReject A st high) (fun r => AdaOK A r.2) := by
  have hrej : st.rej ≤ A.J := h.rej_halt hh
  unfold outerReject
  by_cases hc : A.J + 1 ≤ st.rej + 1
  · rw [if_pos hc]
    exact ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le,
      h.thrOut_le, h.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
      fun h' => absurd h' (by simp), h.nInt_le, h.nNum_le⟩
  · rw [if_neg hc]
    refine DAlw.bind (Q := adaKB A) (fun k hk => ?_) (DAlw.ofDraw _)
    exact ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le,
      hk, h.scores_le, by show st.rej + 1 ≤ A.J + 1; omega,
      fun _ => by show st.rej + 1 ≤ A.J; omega, h.nInt_le, h.nNum_le⟩

/-- **The interval interface preserves the invariant** (noise-draw form). -/
theorem adaIntervalD_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ))
    (l u : ℚ) : DAlw (adaKB A) (adaIntervalD A st vals l u) (fun r => AdaOK A r.2) := by
  unfold adaIntervalD
  by_cases hc : st.halted = true ∨ A.M ≤ st.nInt
  · rw [if_pos hc]
    exact h
  · rw [if_neg hc]
    rw [not_or] at hc
    obtain ⟨hh, hM⟩ := hc
    have hh' : st.halted = false := by simpa using hh
    have h1 : AdaOK A { st with nInt := st.nInt + 1 } :=
      ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le, h.thrOut_le,
        h.scores_le, h.rej_le, h.rej_halt, by show st.nInt + 1 ≤ A.M; omega, h.nNum_le⟩
    refine DAlw.bind (fun r hr => ?_) (prepareRoot_ok vals A.fuel _ _ h1)
    cases r with
    | none =>
      exact ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le,
        h.thrOut_le, h.scores_le, h.rej_le, fun h' => absurd h' (by simp),
        by show st.nInt + 1 ≤ A.M; omega, h.nNum_le⟩
    | some st2 =>
      obtain ⟨hok2, hs2⟩ := hr st2 rfl
      have hh2 : st2.halted = false := by rw [hs2.1]; exact hh'
      dsimp only
      refine DAlw.bind_all (fun _kH => ?_) _
      refine DAlw.bind_all (fun _kL => ?_) _
      split_ifs
      · exact outerReject_ok hok2 hh2 true
      · exact outerReject_ok hok2 hh2 false
      · exact hok2

/-- **The numerical interface preserves the invariant** (noise-draw form). -/
theorem adaNumericalD_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ)) :
    DAlw (adaKB A) (adaNumericalD A st vals) (fun r => AdaOK A r.2) := by
  unfold adaNumericalD
  by_cases hc : st.halted = true ∨ A.R ≤ st.nNum
  · rw [if_pos hc]
    exact h
  · rw [if_neg hc]
    rw [not_or] at hc
    obtain ⟨_, hR⟩ := hc
    have h1 : AdaOK A { st with nNum := st.nNum + 1 } :=
      ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le, h.thrOut_le,
        h.scores_le, h.rej_le, h.rej_halt, h.nInt_le, by show st.nNum + 1 ≤ A.R; omega⟩
    refine DAlw.bind (fun r hr => ?_) (prepareRoot_ok vals A.fuel _ _ h1)
    cases r with
    | none =>
      exact ⟨h.scores_len, h.scores_blk, h.weights, h.T_len, h.T_le, h.thr_len, h.thr_le,
        h.thrOut_le, h.scores_le, h.rej_le, fun h' => absurd h' (by simp), h.nInt_le,
        by show st.nNum + 1 ≤ A.R; omega⟩
    | some st2 =>
      dsimp only
      refine DAlw.bind_all (fun _ => ?_) _
      exact (hr st2 rfl).1

/-- **`Interval` preserves the invariant on every path of fresh bits.** -/
theorem adaInterval_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ))
    (l u : ℚ) : Always (adaInterval A st vals l u) (fun r => AdaOK A r.2) :=
  DAlw.toBits (adaDraw_adaKB A) (adaIntervalD_ok h vals l u)

/-- **`Numerical` preserves the invariant on every path of fresh bits.** -/
theorem adaNumerical_ok {A : AdaParams} {st : AdaState} (h : AdaOK A st) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals) (fun r => AdaOK A r.2) :=
  DAlw.toBits (adaDraw_adaKB A) (adaNumericalD_ok h vals)

/-! ## The size of the numerical outputs -/

/-- `clip_{[0,1]}(2^{-q} n) = m/2^q` with `0 ≤ m ≤ 2^q`. -/
theorem av_clip_two_pow (q : ℕ) (n : ℤ) :
    ∃ m : ℤ, 0 ≤ m ∧ m ≤ 2 ^ q ∧ clipQ 0 1 ((1 / 2 : ℚ) ^ q * n) = m / 2 ^ q := by
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  have e : (1 / 2 : ℚ) ^ q * n = n / 2 ^ q := by rw [one_div_pow]; ring
  rw [e]
  unfold clipQ
  rcases le_total n 0 with hn | hn
  · refine ⟨0, le_rfl, by positivity, ?_⟩
    have h0 : (n : ℚ) / 2 ^ q ≤ 0 :=
      div_nonpos_of_nonpos_of_nonneg (by exact_mod_cast hn) hpos.le
    rw [min_eq_right (h0.trans zero_le_one), max_eq_left h0]
    simp
  · rcases le_total n (2 ^ q) with hn2 | hn2
    · refine ⟨n, hn, hn2, ?_⟩
      have h1 : (n : ℚ) / 2 ^ q ≤ 1 := (div_le_one hpos).mpr (by exact_mod_cast hn2)
      have h0 : 0 ≤ (n : ℚ) / 2 ^ q := div_nonneg (by exact_mod_cast hn) hpos.le
      rw [min_eq_right h1, max_eq_right h0]
    · refine ⟨2 ^ q, by positivity, le_rfl, ?_⟩
      have h1 : 1 ≤ (n : ℚ) / 2 ^ q := (one_le_div hpos).mpr (by exact_mod_cast hn2)
      rw [min_eq_left h1, max_eq_right zero_le_one]
      push_cast
      field_simp

/-- A rational `m/2^q` with `0 ≤ m ≤ 2^q` has denominator and numerator at most `2^q`. -/
theorem av_den_num_le {x : ℚ} {q : ℕ} {m : ℤ} (hm0 : 0 ≤ m) (hm : m ≤ 2 ^ q)
    (hx : x = m / 2 ^ q) : x.den ≤ 2 ^ q ∧ x.num.natAbs ≤ 2 ^ q := by
  have hd : (x.den : ℤ) ∣ 2 ^ q := by
    have h1 := Rat.den_dvd m (2 ^ q)
    rw [Rat.divInt_eq_div] at h1
    push_cast at h1
    rwa [← hx] at h1
  have hden : x.den ≤ 2 ^ q := by
    have h2 := Int.le_of_dvd (by positivity) hd
    exact_mod_cast h2
  refine ⟨hden, ?_⟩
  have hx0 : 0 ≤ x := by rw [hx]; positivity
  have hx1 : x ≤ 1 := by
    rw [hx, div_le_one (by positivity)]
    exact_mod_cast hm
  have hnum : (x.num : ℚ) = x * x.den := (Rat.mul_den_eq_num x).symm
  have h0 : 0 ≤ x.num := Rat.num_nonneg.mpr hx0
  have hdpos : (0 : ℚ) < x.den := by exact_mod_cast x.den_pos
  have h3 : (x.num : ℚ) ≤ x.den := by
    rw [hnum]
    nlinarith
  have h4 : x.num ≤ (x.den : ℤ) := by exact_mod_cast h3
  have h5 : (x.num.natAbs : ℤ) = x.num := Int.natAbs_of_nonneg h0
  have h6 : (x.num.natAbs : ℤ) ≤ 2 ^ q := by
    rw [h5]
    exact h4.trans (by exact_mod_cast hden)
  exact_mod_cast h6

/-- The size of an encoded numerical output `clip_{[0,1]}(h_A n)`. -/
theorem valSize_encNum_clip_le (A : AdaParams) (n : ℤ) :
    valSize (encNum (AdaNum.val (clipQ 0 1 (A.hA * (n : ℚ))))) ≤ 2 * A.qA + 10 := by
  obtain ⟨m, hm0, hm, hx⟩ := av_clip_two_pow A.qA n
  obtain ⟨hden, hnum⟩ := av_den_num_le hm0 hm hx
  have hs1 : Nat.size (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA * n)).den ≤ A.qA + 1 :=
    (Nat.size_le_size hden).trans (by rw [Nat.size_pow])
  have hs2 : Nat.size (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA * n)).num.natAbs ≤ A.qA + 1 :=
    (Nat.size_le_size hnum).trans (by rw [Nat.size_pow])
  show valSize (Val.list [encQ (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA * n))]) ≤ 2 * A.qA + 10
  rw [valSize_list, listSize_cons, listSize_nil, valSize_encQ]
  omega

/-- The numerical outputs are below `2 qA + 10` (noise-draw form). -/
theorem adaNumericalD_num_le (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    DAlw (adaKB A) (adaNumericalD A st vals) (fun r => valSize (encNum r.1) ≤ 2 * A.qA + 10) := by
  unfold adaNumericalD
  by_cases hc : st.halted = true ∨ A.R ≤ st.nNum
  · rw [if_pos hc]
    show valSize (encNum AdaNum.abort) ≤ 2 * A.qA + 10
    simp [encNum]
  · rw [if_neg hc]
    refine DAlw.bind_all (fun r => ?_) _
    cases r with
    | none =>
      show valSize (encNum AdaNum.abort) ≤ 2 * A.qA + 10
      simp [encNum]
    | some st2 =>
      dsimp only
      refine DAlw.bind_all (fun _k => ?_) _
      exact valSize_encNum_clip_le A _

/-- **The numerical outputs are below `adaBoundA`** on every path of fresh bits. -/
theorem adaNumerical_num_le (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals) (fun r => valSize (encNum r.1) ≤ adaBoundA A) := by
  have hq : 2 * A.qA + 10 ≤ adaBoundA A := by
    have h1 := qA_le_adaZ A
    unfold adaBoundA
    have h2 : 2 * A.qA + 10 ≤ 2 * (adaZ A + 16) := by omega
    have h3 : 2 ≤ 2 ^ 10 * (A.N + A.p + 16) := by
      have : 1 ≤ A.N + A.p + 16 := by omega
      calc 2 ≤ 2 ^ 10 * 1 := by norm_num
        _ ≤ 2 ^ 10 * (A.N + A.p + 16) := Nat.mul_le_mul_left _ this
    calc 2 * A.qA + 10 ≤ 2 * (adaZ A + 16) := h2
      _ ≤ 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := Nat.mul_le_mul_right _ h3
  exact Always.mono (fun r hr => hr.trans hq)
    (DAlw.toBits (adaDraw_adaKB A) (adaNumericalD_num_le A st vals))

/-! ## `adaRep_valid` -/

/-- **Validity of W4's ADA representation** (C-SPACE's `AdaInvariant` and the size bounds). -/
theorem adaRep_valid : adaRep.Valid where
  invariant := fun P _ =>
    { init := adaInit_ok (bankAda_blockSizes_length P)
      interval := fun _ vals l u h => adaInterval_ok h vals l u
      numerical := fun _ vals h => adaNumerical_ok h vals }
  enc_le := fun _ _ _ h => valSize_adaEnc_le h
  pub_le := fun P _ =>
    valSize_adaPubEnc_le (bankAda P) (bankAda_blockSizes_length P) (bankAda_Tmax_length P)
  qA_le := fun P _ => by
    show (bankAda P).qA ≤ adaBoundA (bankAda P)
    have h1 := qA_le_adaZ (bankAda P)
    unfold adaBoundA
    calc (bankAda P).qA ≤ adaZ (bankAda P) + 16 := by omega
      _ ≤ 2 ^ 10 * ((bankAda P).N + (bankAda P).p + 16) * (adaZ (bankAda P) + 16) :=
        Nat.le_mul_of_pos_left _ (by positivity)
  vals_le := fun P _ _ hv => valSize_encVals_le (bankAda_blockSizes_length P) hv.1 hv.2
  num_le := fun P _ st vals _ _ => adaNumerical_num_le (bankAda P) st vals

/-! ## O2b (iii) family 11: the tight scale (C-SPACE, append-only)

The tight forms of the numerical-output bound for the B space glue (`F2e2e/BSpace/DslMain.lean`, numerical request):
`adaNumerical_num_le_q` (`≤ 2 qA + 10`, N-free) and `adaNumerical_num_le_t` (`≤ tightA A`, `tightA` and `TightM` from
`AdaBounds`). `adaNumerical_num_le_of_q` checks that the statement of `adaNumerical_num_le` follows. -/

section O2bTight

open F2e2e.Cost.AdaDSL

/-! ## Scalar facts -/

/-- `tightA A ≤ adaBoundA A` (`adaBoundA = 2^9 · tightA`). -/
theorem tightA_le_adaBoundA (A : AdaParams) : tightA A ≤ adaBoundA A := by
  rw [adaBoundA_eq_tightA]
  exact Nat.le_mul_of_pos_left _ (by norm_num)

/-- `2 qA + 10 ≤ tightA A`. -/
theorem two_qA_add_ten_le_tightA (A : AdaParams) : 2 * A.qA + 10 ≤ tightA A := by
  have h1 := qA_le_adaZ A
  have h3 : 2 * (adaZ A + 16) ≤ tightA A := by
    unfold tightA
    have h4 : 2 * 1 ≤ 2 * (A.N + A.p + 16) := Nat.mul_le_mul_left 2 (Nat.le_add_left 1 _ |>.trans
      (Nat.add_le_add_left (by norm_num) _))
    calc 2 * (adaZ A + 16) = 2 * 1 * (adaZ A + 16) := by ring
      _ ≤ 2 * (A.N + A.p + 16) * (adaZ A + 16) := Nat.mul_le_mul_right _ h4
  omega

/-- `qA ≤ tightA A` (the tight form of the C field `adaRep_valid.qA_le`). -/
theorem qA_le_tightA (A : AdaParams) : A.qA ≤ tightA A := by
  have := two_qA_add_ten_le_tightA A
  omega

/-! ## The numerical outputs -/

/-- **The numerical outputs are below `2 qA + 10`** on every path of fresh bits (the tight, N-free form of
`adaNumerical_num_le`). -/
theorem adaNumerical_num_le_q (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals) (fun r => valSize (encNum r.1) ≤ 2 * A.qA + 10) :=
  DAlw.toBits (adaDraw_adaKB A) (adaNumericalD_num_le A st vals)

/-- **The numerical outputs are below `tightA A`** on every path of fresh bits. -/
theorem adaNumerical_num_le_t (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals) (fun r => valSize (encNum r.1) ≤ tightA A) :=
  Always.mono (fun _ hr => hr.trans (two_qA_add_ten_le_tightA A)) (adaNumerical_num_le_q A st vals)

/-- Integration check: the exact statement of `adaNumerical_num_le` is a corollary of `adaNumerical_num_le_t`. -/
theorem adaNumerical_num_le_of_q (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals) (fun r => valSize (encNum r.1) ≤ adaBoundA A) :=
  Always.mono (fun _ hr => hr.trans (tightA_le_adaBoundA A)) (adaNumerical_num_le_t A st vals)

end O2bTight

end F2e2e.C.Impl
