import F2e2e.C.Impl.AdaPrepCorrMain
import F2e2e.Cost.Lib.LinComb

/-!
# ADA module (W4), `PrepareRoot` in the DSL, part 3b: the two parts of a correction

OWNER: B-ARCH (dc387564). The sub-routines of `adaCorr` (Idx 702; its body `body_adaCorrMain` and the
assembly lemma `adaCorr_of_parts` are B-NUM's, `AdaPrepCorrMain.lean`; the table and the contract
`adaCorr_impl` are in `AdaPrepCorr.lean`):

* `body_adaRedraw` (Idx 706) on `redrawIn A j thr = [j, thr, pub]`: the threshold redraws of a
  correction on edge `j` (edge `j − 1` if `1 ≤ j`, edge `j`, edge `j + 1` if `j + 1 < p`), each a fresh
  lattice noise of kind `intThr` (`eDraw`) written into the list with the library `set`.
  Spec `adaRedraw_impl`: it implements `(redrawThresholds A (reopenEdges A j) thr).toBits (adaDraw A)`
  (B-NUM's unfolding `redraw_reopen_toBits` into `thrStepIf`/`thrStep`).
* `body_adaCorrDet` (Idx 705) on `corrIn A st vals j q = [j, avSign q, st, pub, vals]`: row `j` of the
  scores becomes `1·g_j + 4q·v_j`, then, if `j + 1 < p`, row `j + 1` becomes `1·g_{j+1} − q·v_{j+1}`
  (library `linComb`, Idx 21/22, on rows read with `get` and written back with `set`), and `T_j` is
  incremented. Spec `adaCorrDet_val`: the value `[encL (encL encZ) (avScores A st vals j q),
  encL encN (st.T.set j (st.T.getD j 0 + 1))]` (`avScores`, `avRow`, `avRow1`: `AdaValid.lean`;
  `blockVals A vals j = vals.getD j []` under `ValsOKA`, `addScaled` = `zipWith`).

Sizes: every intermediate value is below `4·adaBoundA A` (the state before and after the correction
are below `adaBoundA A` by `valSize_adaEnc_le` and `avState_ok`; the corrected rows are rows of the new
scores), and each library call needs at most `64·4·adaBoundA A ≤ 2^32·adaBoundA A ≤ M`.
Generic helpers are named `apc_…`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-! ## Bodies -/

/-- **`adaRedraw`** (Idx 706): `[j, thrInt, pub] ↦` the redrawn thresholds of a correction on edge
`j`: `j − 1` (if `0 < j`), `j`, `j + 1` (if `j + 1 < p`), each a fresh noise of kind `intThr`. -/
def body_adaRedraw : Expr :=
  eLet (eIte (eLt (eLit 0) (eAtN 0 (eV 0)))
      (eLet (eDraw NoiseKind.intThr (eAtN 2 (eV 0)))
        (eCall Idx.set (eList [eAtN 1 (eV 1), eSub (eAtN 0 (eV 1)) (eLit 1), eV 0])))
      (eAtN 1 (eV 0)))
  (eLet (eLet (eDraw NoiseKind.intThr (eAtN 2 (eV 1)))
      (eCall Idx.set (eList [eV 1, eAtN 0 (eV 2), eV 0])))
  (eIte (eLt (eAdd (eAtN 0 (eV 2)) (eLit 1)) (eAtN 0 (eAtN 2 (eV 2))))
    (eLet (eDraw NoiseKind.intThr (eAtN 2 (eV 2)))
      (eCall Idx.set (eList [eV 1, eAdd (eAtN 0 (eV 3)) (eLit 1), eV 0])))
    (eV 0)))

/-- **`adaCorrDet`** (Idx 705): `[j, q, st, pub, vals] ↦ [scores', T']`, the deterministic part of a
correction on edge `j` with sign `q`: row `j` becomes `1·g_j + 4q·v_j` and (if `j + 1 < p`) row `j+1`
becomes `1·g_{j+1} − q·v_{j+1}` (library `linComb`), and `T_j` is incremented. -/
def body_adaCorrDet : Expr :=
  eLet (eAtN 0 (eAtN 2 (eV 0)))
  (eLet (eCall Idx.set (eList [eV 0, eAtN 0 (eV 1),
      eCall Idx.linComb (eList [eCall Idx.get (ePair (eV 0) (eAtN 0 (eV 1))),
        eCall Idx.get (ePair (eAtN 4 (eV 1)) (eAtN 0 (eV 1))),
        eLit 1, eMul (eLit 4) (eAtN 1 (eV 1))])]))
  (eLet (eIte (eLt (eAdd (eAtN 0 (eV 2)) (eLit 1)) (eAtN 0 (eAtN 3 (eV 2))))
      (eCall Idx.set (eList [eV 0, eAdd (eAtN 0 (eV 2)) (eLit 1),
        eCall Idx.linComb (eList [eCall Idx.get (ePair (eV 0) (eAdd (eAtN 0 (eV 2)) (eLit 1))),
          eCall Idx.get (ePair (eAtN 4 (eV 2)) (eAdd (eAtN 0 (eV 2)) (eLit 1))),
          eLit 1, eSub (eLit 0) (eAtN 1 (eV 2))])]))
      (eV 0))
  (ePair (eV 0)
    (eCall Idx.set (eList [eAtN 1 (eAtN 2 (eV 3)), eAtN 0 (eV 3),
      eAdd (eCall Idx.get (ePair (eAtN 1 (eAtN 2 (eV 3))) (eAtN 0 (eV 3)))) (eLit 1)])))))

section Proof

variable {prog : List Expr} {M : ℕ}

/-! ## Generic rules -/

theorem apc_implements_ite_pos {env : List Val} {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val}
    {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : Implements prog M env t enc p) : Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  simpa using EvalsVal.ite_true hc hz (ht bits a h)

theorem apc_implements_ite_neg {env : List Val} {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val}
    {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : Implements prog M env f enc p) : Implements prog M env (Expr.ite c t f) enc p := by
  intro bits a h
  simpa using EvalsVal.ite_false hc hz (hf bits a h)

theorem apc_draw_support (A : AdaParams) (κ : NoiseKind) :
    ∀ bits k, (adaDraw A κ).run bits = some (k, []) → |k| ≤ (maxKs A : ℤ) :=
  fun _ _ h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ)

/-- Replacing one element of a list value by `x` adds at most `valSize x`. -/
theorem apc_valSize_set_le (l : List Val) (n : ℕ) (x : Val) :
    valSize (Val.list (l.set n x)) ≤ valSize (Val.list l) + valSize x := by
  induction l generalizing n with
  | nil => simp
  | cons a l ih =>
    cases n with
    | zero => simp only [List.set_cons_zero, valSize_list, listSize_cons]; omega
    | succ n =>
      have := ih n
      simp only [List.set_cons_succ, valSize_list, listSize_cons] at this ⊢
      omega

/-- Thresholds bounded by `maxKs A`. -/
def CorrThrOK (A : AdaParams) (thr : List ℤ) : Prop :=
  thr.length = A.p ∧ ∀ z ∈ thr, |z| ≤ (maxKs A : ℤ)

theorem apc_bitLen_le_of_abs_maxKs {A : AdaParams} {z : ℤ} (h : |z| ≤ (maxKs A : ℤ)) :
    bitLen z ≤ adaZ A := by
  have h1 := bitLen_le_size_of_abs_le h
  have := size_maxKs_le_adaZ A
  omega

theorem apc_valSize_thr_le {A : AdaParams} {thr : List ℤ} (h : CorrThrOK A thr) :
    valSize (encL encZ thr) ≤ 1 + A.p * (adaZ A + 2) := by
  have := valSize_encL_le encZ thr (adaZ A + 1) (fun z hz => by
    rw [valSize_encZ]; have := apc_bitLen_le_of_abs_maxKs (h.2 z hz); omega)
  rw [h.1] at this
  exact this

theorem apc_thrOK_set {A : AdaParams} {thr : List ℤ} (h : CorrThrOK A thr) (e : ℕ) {k : ℤ}
    (hk : |k| ≤ (maxKs A : ℤ)) : CorrThrOK A (thr.set e k) := by
  refine ⟨by rw [List.length_set, h.1], fun z hz => ?_⟩
  rcases List.mem_or_eq_of_mem_set hz with hz | rfl
  · exact h.2 z hz
  · exact hk

/-- The run of one redraw keeps the thresholds bounded. -/
theorem apc_thrStep_run_ok {A : AdaParams} {e : ℕ} {thr : List ℤ} (h : CorrThrOK A thr) {bits : List Bool}
    {t : List ℤ} (hr : (thrStep A e thr).run bits = some (t, [])) : CorrThrOK A t := by
  unfold thrStep at hr
  obtain ⟨b₁, b₂, k, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp hr
  obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h2
  exact apc_thrOK_set h e (apc_draw_support A _ _ _ h1)

theorem apc_thrStepIf_run_ok {A : AdaParams} {c : Bool} {e : ℕ} {thr : List ℤ} (h : CorrThrOK A thr)
    {bits : List Bool} {t : List ℤ} (hr : (thrStepIf A c e thr).run bits = some (t, [])) :
    CorrThrOK A t := by
  unfold thrStepIf at hr
  split_ifs at hr
  · exact apc_thrStep_run_ok h hr
  · obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hr
    exact h

/-- **One redraw**: `let k := draw intThr pub in set [thr, e, k]`. -/
theorem apc_thrStep_impl (hS : SampLib prog) (hL : ListLib prog) {env : List Val} {pubE thrE eE : Expr}
    {A : AdaParams} {thr : List ℤ} {e : ℕ}
    (hpub : EvalsVal prog M env [] (.inl pubE) (adaPubEnc A)) (hpubM : valSize (adaPubEnc A) ≤ M)
    (hthr : ∀ k : ℤ, EvalsVal prog M (encZ k :: env) [] (.inl thrE) (encL encZ thr))
    (he : ∀ k : ℤ, EvalsVal prog M (encZ k :: env) [] (.inl eE) (Val.int (e : ℤ)))
    (hdraw : drawM A NoiseKind.intThr ≤ M)
    (hsz : ∀ k : ℤ, |k| ≤ (maxKs A : ℤ) →
      valSize (Val.list [encL encZ thr, Val.int (e : ℤ), encZ k]) ≤ M ∧
        S_set (thr.map encZ) e (encZ k) ≤ M) :
    Implements prog M env (eLet (eDraw NoiseKind.intThr pubE) (eCall Idx.set (eList [thrE, eE, eV 0])))
      (encL encZ) (thrStep A e thr) := by
  unfold thrStep
  refine implements_letE_of (draw_impl hS hpub hpubM NoiseKind.intThr hdraw)
    (fun k => |k| ≤ (maxKs A : ℤ)) (apc_draw_support A _) ?_
  intro k hk
  apply Implements.of_det
  have hl : EvalsVal prog M (encZ k :: env) [] (.inl (eList [thrE, eE, eV 0]))
      (Val.list [Val.list (thr.map encZ), Val.int (e : ℤ), encZ k]) :=
    evalsVal_list (List.Forall₂.cons (hthr k) (List.Forall₂.cons (he k)
      (List.Forall₂.cons EvalsVal.var0 List.Forall₂.nil))) (hsz k hk).1
  have := set_val hL hl (hsz k hk).2
  rw [← List.map_set] at this
  exact this

/-! ## Size bookkeeping -/

/-- `adaBoundA A = 1024 B` with `B = (N + p + 16)(adaZ + 16)`. -/
theorem apc_adaBoundA_eq (A : AdaParams) :
    adaBoundA A = 1024 * ((A.N + A.p + 16) * (adaZ A + 16)) := by
  unfold adaBoundA; ring

theorem apc_pZ_le_B (A : AdaParams) : A.p * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
  Nat.mul_le_mul (by omega) (by omega)

theorem apc_Z_le_B (A : AdaParams) : adaZ A + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
  Nat.le_mul_of_pos_left _ (by omega)

theorem apc_p_le_B (A : AdaParams) : A.N + A.p + 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
  Nat.le_mul_of_pos_right _ (by omega)

theorem apc_redraw_sizes {A : AdaParams} (hM : 2 ^ 32 * adaBoundA A ≤ M) {t : List ℤ} (ht : CorrThrOK A t)
    {e : ℕ} (he : e ≤ A.p) {k : ℤ} (hk : |k| ≤ (maxKs A : ℤ)) :
    valSize (Val.list [encL encZ t, Val.int (e : ℤ), encZ k]) ≤ M ∧
      S_set (t.map encZ) e (encZ k) ≤ M := by
  have h1 := apc_valSize_thr_le ht
  have h2 := apc_bitLen_le_of_abs_maxKs hk
  have h3 : Nat.size e ≤ A.p := (size_le_self e).trans he
  have hB := apc_adaBoundA_eq A
  have hpB := apc_pZ_le_B A
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have hval : valSize (Val.list (t.map encZ)) = valSize (encL encZ t) := rfl
  constructor
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encZ, bitLen_natCast]
    omega
  · unfold S_set
    rw [hval, valSize_encZ]
    omega

/-- **Spec of `adaRedraw`.** -/
theorem adaRedraw_impl (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {j : ℕ} (hj : j < A.p)
    {thr : List ℤ} (hthr : CorrThrOK A thr) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [redrawIn A j thr] body_adaRedraw (encL encZ)
      ((redrawThresholds A (reopenEdges A j) thr).toBits (adaDraw A)) := by
  rw [redraw_reopen_toBits]
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hB := apc_adaBoundA_eq A
  have hpB := apc_pZ_le_B A
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : drawM A NoiseKind.intThr ≤ M := by have := drawM_le A NoiseKind.intThr; omega
  have hthrS := apc_valSize_thr_le hthr
  have hyM : valSize (redrawIn A j thr) ≤ M := by
    unfold redrawIn
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
    omega
  set y := redrawIn A j thr with hy
  rw [adaPubEnc_eq] at hpubM
  -- fields of the input, in every environment ending with `y`
  have fj : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 0 (eV pre.length)))
      (Val.int (j : ℤ)) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fthr : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 1 (eV pre.length)))
      (encL encZ thr) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fpub : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 2 (eV pre.length)))
      (adaPubEnc A) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fp : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) []
      (.inl (eAtN 0 (eAtN 2 (eV pre.length)))) (Val.int (A.p : ℤ)) := fun {pre} =>
    evalsVal_atN' (l := pubFields A) (by rw [← adaPubEnc_eq]; exact fpub) hpubM rfl
  have h2M : 2 ≤ M := by omega
  -- step 1
  refine implements_letE_of (encA := encL encZ) (Q := CorrThrOK A) ?_
    (fun bits t h => apc_thrStepIf_run_ok hthr h) ?_
  · have hc := EvalsVal.lt (EvalsVal.lit' (prog := prog) (M := M) (env := [y]) (z := 0)
      (by simp; omega)) (fj (pre := [])) h2M
    by_cases hj1 : 1 ≤ j
    · refine apc_implements_ite_pos hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
      have e1 : thrStepIf A (decide (1 ≤ j)) (j - 1) thr = thrStep A (j - 1) thr := by
        unfold thrStepIf; rw [if_pos (by simpa using hj1)]
      rw [e1]
      refine apc_thrStep_impl hS hL (fpub (pre := [])) (by rw [adaPubEnc_eq]; exact hpubM)
        (fun k => fthr (pre := [encZ k])) (fun k => ?_) hdraw
        (fun k hk => apc_redraw_sizes hM hthr (by omega) hk)
      have e : ((j - 1 : ℕ) : ℤ) = (j : ℤ) - 1 := by push_cast [Nat.cast_sub hj1]; ring
      rw [e]
      refine EvalsVal.sub (fj (pre := [encZ k])) (EvalsVal.lit' (z := 1) (by simp; omega)) ?_
      rw [← e, valSize_int, bitLen_natCast]
      have : Nat.size (j - 1) ≤ A.p := (size_le_self _).trans (by omega)
      omega
    · refine apc_implements_ite_neg hc (by rw [if_neg (by omega)]) ?_
      have e1 : thrStepIf A (decide (1 ≤ j)) (j - 1) thr = BitProg.pure thr := by
        unfold thrStepIf; rw [if_neg (by simpa using hj1)]
      rw [e1]
      exact Implements.of_det (fthr (pre := []))
  intro t1 ht1
  -- step 2
  refine implements_letE_of (encA := encL encZ) (Q := CorrThrOK A) ?_
    (fun bits t h => apc_thrStep_run_ok ht1 h) ?_
  · exact apc_thrStep_impl hS hL (fpub (pre := [encL encZ t1])) (by rw [adaPubEnc_eq]; exact hpubM)
      (fun k => EvalsVal.var1) (fun k => fj (pre := [encZ k, encL encZ t1])) hdraw
      (fun k hk => apc_redraw_sizes hM ht1 hj.le hk)
  intro t2 ht2
  -- step 3
  have hc := EvalsVal.lt (EvalsVal.add (fj (pre := [encL encZ t2, encL encZ t1]))
    (EvalsVal.lit' (z := 1) (by simp; omega)) (by
      simp only [valSize_int]
      have := bitLen_add_le (j : ℤ) 1
      simp only [bitLen_natCast] at this
      have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
      have : bitLen (1 : ℤ) = 1 := by decide
      omega)) (fp (pre := [encL encZ t2, encL encZ t1])) h2M
  by_cases hj2 : j + 1 < A.p
  · refine apc_implements_ite_pos hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
    have e2 : thrStepIf A (decide (j + 1 < A.p)) (j + 1) t2 = thrStep A (j + 1) t2 := by
      unfold thrStepIf; rw [if_pos (by simpa using hj2)]
    rw [e2]
    refine apc_thrStep_impl hS hL (fpub (pre := [encL encZ t2, encL encZ t1]))
      (by rw [adaPubEnc_eq]; exact hpubM) (fun k => EvalsVal.var1) (fun k => ?_) hdraw
      (fun k hk => apc_redraw_sizes hM ht2 (by omega) hk)
    have := EvalsVal.add (fj (pre := [encZ k, encL encZ t2, encL encZ t1]))
      (EvalsVal.lit' (z := 1) (by simp; omega)) (by
        simp only [valSize_int]
        have := bitLen_add_le (j : ℤ) 1
        simp only [bitLen_natCast] at this
        have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
        have : bitLen (1 : ℤ) = 1 := by decide
        omega)
    simpa using this
  · refine apc_implements_ite_neg hc (by rw [if_neg (by omega)]) ?_
    have e2 : thrStepIf A (decide (j + 1 < A.p)) (j + 1) t2 = BitProg.pure t2 := by
      unfold thrStepIf; rw [if_neg (by simpa using hj2)]
    rw [e2]
    exact Implements.of_det EvalsVal.var0

/-! ## Reference facts for the deterministic part -/

theorem apc_getD_map_lt {α β : Type} (l : List α) (f : α → β) {n : ℕ} (hn : n < l.length) (d : β)
    (d' : α) : (l.map f).getD n d = f (l.getD n d') := by
  rw [List.getD_eq_getElem _ _ (by simpa using hn), List.getD_eq_getElem _ _ hn, List.getElem_map]

theorem apc_encL_encN_eq (v : List ℕ) : encL encN v = encInts (v.map fun n : ℕ => (n : ℤ)) := by
  unfold encL encInts encN
  rw [List.map_map]
  rfl

theorem apc_encVals_row (vals : List (List ℕ)) {j : ℕ} (hj : j < vals.length) :
    (vals.map (encL encN)).getD j (Val.int 0) =
      encInts ((vals.getD j []).map fun v : ℕ => (v : ℤ)) := by
  rw [apc_getD_map_lt _ _ hj _ [], apc_encL_encN_eq]

theorem apc_addScaled_eq_zipWith (g : List ℤ) (c : ℤ) (v : List ℕ) (h : v.length = g.length) :
    addScaled g c v = List.zipWith (fun x y => 1 * x + c * y) g (v.map fun n : ℕ => (n : ℤ)) := by
  apply List.ext_getElem
  · simp [addScaled, h]
  · intro i h1 h2
    simp only [addScaled, List.getElem_mapIdx, List.getElem_zipWith, List.getElem_map]
    have hi : i < v.length := by simp [addScaled] at h1; omega
    rw [List.getD_eq_getElem _ _ hi]
    ring

theorem apc_blockVals_eq_of_valsOK {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals)
    (j : ℕ) : blockVals A vals j = vals.getD j [] := by
  unfold blockVals
  conv_rhs => rw [← List.map_id (vals.getD j [])]
  refine List.map_congr_left fun x hx => min_eq_left ?_
  by_cases hj : j < vals.length
  · rw [List.getD_eq_getElem _ _ hj] at hx
    exact hv.2 _ (List.getElem_mem hj) x hx
  · rw [List.getD_eq_default _ _ (by omega)] at hx
    simp at hx

theorem apc_vals_len_getD {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) (j : ℕ) :
    (vals.getD j []).length = A.blockSizes.getD j 0 := by
  have h := hv.1
  by_cases hj : j < vals.length
  · rw [List.getD_eq_getElem _ _ hj]
    have hj' : j < A.blockSizes.length := by rw [← h]; simpa using hj
    rw [List.getD_eq_getElem _ _ hj']
    simp only [← h, List.getElem_map]
  · rw [List.getD_eq_default _ _ (by omega)]
    have hj' : ¬ j < A.blockSizes.length := by rw [← h]; simpa using hj
    rw [List.getD_eq_default _ _ (by omega)]
    rfl

theorem apc_vals_length {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    vals.length = A.blockSizes.length := by
  rw [← hv.1, List.length_map]

theorem apc_avRow_eq_lc {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (q : Bool) :
    avRow A st vals j q = List.zipWith (fun x y => 1 * x + (4 * avSign q) * y)
      (st.scores.getD j []) ((vals.getD j []).map fun n : ℕ => (n : ℤ)) := by
  unfold avRow
  rw [apc_blockVals_eq_of_valsOK hv, apc_addScaled_eq_zipWith]
  rw [apc_vals_len_getD hv, hok.scores_blk j hj]

theorem apc_avRow1_eq_lc {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j + 1 < A.p) (q : Bool) :
    avRow1 A st vals j q = List.zipWith (fun x y => 1 * x + (-avSign q) * y)
      ((st.scores.set j (avRow A st vals j q)).getD (j + 1) [])
      ((vals.getD (j + 1) []).map fun n : ℕ => (n : ℤ)) := by
  unfold avRow1
  rw [apc_blockVals_eq_of_valsOK hv, apc_addScaled_eq_zipWith]
  rw [apc_vals_len_getD hv, av_getD_set, if_neg (by omega), hok.scores_blk (j + 1) hj]

theorem apc_T_sum_lt_fuel {A : AdaParams} {st : AdaState} (hok : AdaOK A st) : st.T.sum < A.fuel := by
  have := sum_le_of_getD_le st.T A.Tmax (fun j => by
    by_cases hj : j < A.p
    · exact hok.T_le j hj
    · rw [List.getD_eq_default _ _ (by rw [hok.T_len]; omega)]
      exact Nat.zero_le _)
  unfold AdaParams.fuel
  omega

/-- Scores have at most `adaZ A + 2` bits. -/
theorem apc_score_bitLen_le {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {g : List ℤ}
    (hg : g ∈ st.scores) {z : ℤ} (hz : z ∈ g) : bitLen z ≤ adaZ A + 2 := by
  have h1 := hok.scores_le g hg z hz
  have hTs := apc_T_sum_lt_fuel hok
  have hf : A.fuel < 2 ^ Nat.size A.fuel := Nat.lt_size_self _
  have h3 : (st.T.sum : ℤ) < 2 ^ Nat.size A.fuel := by exact_mod_cast hTs.trans hf
  have h4 : (4 : ℤ) * 2 ^ A.qA * (st.T.sum : ℤ) < 2 ^ (A.qA + 2 + Nat.size A.fuel) := by
    have hpos : (0 : ℤ) < 4 * 2 ^ A.qA := by positivity
    calc (4 : ℤ) * 2 ^ A.qA * (st.T.sum : ℤ) < 4 * 2 ^ A.qA * 2 ^ Nat.size A.fuel :=
          mul_lt_mul_of_pos_left h3 hpos
      _ = 2 ^ (A.qA + 2 + Nat.size A.fuel) := by rw [pow_add, pow_add]; ring
  have := bitLen_le_of_abs_lt (lt_of_le_of_lt h1 h4)
  have := qA_add_size_fuel_le_adaZ A
  omega

theorem apc_scores_getD_bitLen {A : AdaParams} {st : AdaState} (hok : AdaOK A st) (j : ℕ) :
    ∀ z ∈ st.scores.getD j [], bitLen z ≤ adaZ A + 2 := by
  intro z hz
  by_cases hj : j < st.scores.length
  · rw [List.getD_eq_getElem _ _ hj] at hz
    exact apc_score_bitLen_le hok (List.getElem_mem hj) hz
  · rw [List.getD_eq_default _ _ (by omega)] at hz
    simp at hz

theorem apc_vals_getD_bitLen {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) (j : ℕ) :
    ∀ y ∈ (vals.getD j []).map (fun n : ℕ => (n : ℤ)), bitLen y ≤ adaZ A + 1 := by
  intro y hy
  obtain ⟨n, hn, rfl⟩ := List.mem_map.mp hy
  have hle : n ≤ 2 ^ A.qA := by
    by_cases hj : j < vals.length
    · rw [List.getD_eq_getElem _ _ hj] at hn
      exact hv.2 _ (List.getElem_mem hj) n hn
    · rw [List.getD_eq_default _ _ (by omega)] at hn
      simp at hn
  rw [bitLen_natCast]
  have : Nat.size n ≤ A.qA + 1 := by
    have := Nat.size_le_size hle
    rwa [Nat.size_pow] at this
  have := qA_le_adaZ A
  omega

/-! ## `adaCorrDet` -/

/-- The fields of an encoded state. -/
def apc_stFields (st : AdaState) : List Val :=
  [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt, encZ st.thrOut,
    encN st.rej, encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted]

theorem apc_adaEnc_eq_fields (st : AdaState) : adaEnc st = Val.list (apc_stFields st) := rfl

theorem apc_bitLen_avSign_le (q : Bool) : bitLen (avSign q) ≤ 1 := by
  cases q <;> decide

theorem apc_bitLen_four_avSign_le (q : Bool) : bitLen (4 * avSign q) ≤ 3 := by
  cases q <;> decide

theorem apc_bitLen_neg_avSign_le (q : Bool) : bitLen (-avSign q) ≤ 1 := by
  cases q <;> decide

/-- The linear-combination call of a correction row: `linComb [get [sc, i], get [vals, i], 1, c]`. -/
theorem corrRow_val (hL : ListLib prog) (hlc : prog[Idx.linComb]? = some body_linComb)
    (hlcs : prog[Idx.linCombStep]? = some body_linCombStep) {env : List Val}
    {scE iE valsE cE : Expr} {Lr : List (List ℤ)} {vals : List (List ℕ)} {i : ℕ} {c : ℤ} {K Bd : ℕ}
    (hsc : EvalsVal prog M env [] (.inl scE) (encL (encL encZ) Lr))
    (hi : EvalsVal prog M env [] (.inl iE) (Val.int (i : ℤ)))
    (hvals : EvalsVal prog M env [] (.inl valsE) (encVals vals))
    (hc : EvalsVal prog M env [] (.inl cE) (Val.int c))
    (hiL : i < Lr.length) (hiv : i < vals.length)
    (hKg : ∀ z ∈ Lr.getD i [], bitLen z ≤ K)
    (hKv : ∀ y ∈ (vals.getD i []).map (fun n : ℕ => (n : ℤ)), bitLen y ≤ K)
    (hKc : bitLen c ≤ K) (hK1 : 1 ≤ K)
    (hscB : valSize (encL (encL encZ) Lr) ≤ Bd) (hvalsB : valSize (encVals vals) ≤ Bd)
    (hlenB : (Lr.getD i []).length * (2 * K + 3) + 2 * K + Nat.size i + 100 ≤ Bd)
    (hBd : 64 * Bd ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.linComb (eList [eCall Idx.get (ePair scE iE),
        eCall Idx.get (ePair valsE iE), eLit 1, cE])))
      (encInts (List.zipWith (fun x y => 1 * x + c * y) (Lr.getD i [])
        ((vals.getD i []).map fun n : ℕ => (n : ℤ)))) := by
  set a := Lr.getD i [] with ha
  set b := (vals.getD i []).map fun n : ℕ => (n : ℤ) with hb
  -- sizes of the pieces
  have haS : valSize (encInts a) ≤ Bd := by
    have : encInts a ∈ Lr.map (encL encZ) := by
      rw [encInts_eq_encL, ha, List.getD_eq_getElem _ _ hiL]
      exact List.mem_map_of_mem (List.getElem_mem hiL)
    exact (valSize_lt_of_mem this).le.trans hscB
  rw [encVals_eq_encL] at hvals hvalsB
  have hbS : valSize (encInts b) ≤ Bd := by
    have : encInts b ∈ vals.map (encL encN) := by
      rw [← apc_encVals_row vals hiv, List.getD_eq_getElem _ _ (by simpa using hiv)]
      exact List.getElem_mem _
    exact (valSize_lt_of_mem this).le.trans hvalsB
  have hiS : valSize (Val.int (i : ℤ)) ≤ Nat.size i + 1 := by simp [bitLen_natCast]
  have hcS : valSize (Val.int c) ≤ K + 1 := by simp; omega
  -- the two `get`s
  have hp1 := EvalsVal.pair hsc hi (by
    simp only [valSize_list, listSize_cons, listSize_nil] at hscB ⊢
    unfold encL at hscB ⊢
    simp only [valSize_list] at hscB ⊢
    omega)
  have hg1 := get_val hL (l := Lr.map (encL encZ)) (n := i) (by simpa [encL] using hp1) (by
    unfold S_get
    have : valSize (Val.list (Lr.map (encL encZ))) = valSize (encL (encL encZ) Lr) := rfl
    omega)
  rw [apc_getD_map_lt _ _ hiL _ [], ← encInts_eq_encL] at hg1
  have hp2 := EvalsVal.pair hvals hi (by
    simp only [valSize_list, listSize_cons, listSize_nil] at hvalsB ⊢
    unfold encL at hvalsB ⊢
    simp only [valSize_list] at hvalsB ⊢
    omega)
  have hg2 := get_val hL (l := vals.map (encL encN))
    (n := i) (by simpa [encL] using hp2) (by
      unfold S_get
      have : valSize (Val.list (vals.map (encL encN))) = valSize (encL (encL encN) vals) := rfl
      omega)
  rw [apc_encVals_row vals hiv] at hg2
  -- the argument list
  have hargs : EvalsVal prog M env [] (.inl (eList [eCall Idx.get (ePair scE iE),
      eCall Idx.get (ePair valsE iE), eLit 1, cE]))
      (Val.list [encInts a, encInts b, Val.int 1, Val.int c]) :=
    evalsVal_list (List.Forall₂.cons hg1 (List.Forall₂.cons hg2
      (List.Forall₂.cons (EvalsVal.lit' (by simp; omega)) (List.Forall₂.cons hc List.Forall₂.nil))))
      (by simp only [valSize_list, listSize_cons, listSize_nil] at haS hbS hcS ⊢
          have : bitLen (1 : ℤ) = 1 := by decide
          simp only [valSize_int, this]
          omega)
  -- the call
  have hK1' : bitLen (1 : ℤ) ≤ K := by
    have : bitLen (1 : ℤ) = 1 := by decide
    omega
  refine evalsVal_call_det hlc hargs
    ((linComb_spec hlcs hL.revAppendStep a b 1 c K hKg hKv hK1' hKc 0).toVal.mono_M ?_)
  unfold S_linComb V_lc
  omega

/-! ## Deterministic rules with no fresh bits -/

theorem apc_letE {env : List Val} {a b : Expr} {va vb : Val}
    (ha : EvalsVal prog M env [] (.inl a) va) (hb : EvalsVal prog M (va :: env) [] (.inl b) vb) :
    EvalsVal prog M env [] (.inl (Expr.letE a b)) vb :=
  EvalsVal.letE ha hb

theorem apc_ite_true {env : List Val} {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsVal prog M env [] (.inl t) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_true hc hz ht

theorem apc_ite_false {env : List Val} {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsVal prog M env [] (.inl f) v) : EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_false hc hz hf

/-- `e + 1` on a natural number. -/
theorem apc_succ_val {env : List Val} {e : Expr} {n : ℕ}
    (he : EvalsVal prog M env [] (.inl e) (Val.int (n : ℤ))) (hM : Nat.size (n + 1) + 1 ≤ M)
    (h2 : 2 ≤ M) : EvalsVal prog M env [] (.inl (eAdd e (eLit 1))) (Val.int ((n + 1 : ℕ) : ℤ)) := by
  have h1 : bitLen (1 : ℤ) = 1 := by decide
  have hc : ((n + 1 : ℕ) : ℤ) = (n : ℤ) + 1 := by push_cast; ring
  have h := EvalsVal.add he (EvalsVal.lit' (z := 1) (by rw [valSize_int, h1]; omega))
    (by rw [valSize_int, ← hc, bitLen_natCast]; exact hM)
  rw [hc]
  exact h

/-! ## The corrected rows are rows of the corrected scores -/

theorem apc_mem_of_getD {β : Type} {l : List β} {n : ℕ} {d x : β} (hn : n < l.length)
    (h : l.getD n d = x) : x ∈ l := by
  rw [← h, List.getD_eq_getElem _ _ hn]
  exact List.getElem_mem hn

theorem apc_avRow_mem {A : AdaParams} {st : AdaState} (hok : AdaOK A st) (vals : List (List ℕ))
    {j : ℕ} (hj : j < A.p) (q : Bool) : avRow A st vals j q ∈ avScores A st vals j q := by
  have hsl := hok.scores_len
  have hlen : j < st.scores.length := by omega
  unfold avScores
  split_ifs with h
  · refine apc_mem_of_getD (n := j) (d := []) (by simp; omega) ?_
    rw [av_getD_set, if_neg (by omega), av_getD_set, if_pos ⟨rfl, hlen⟩]
  · refine apc_mem_of_getD (n := j) (d := []) (by simp; omega) ?_
    rw [av_getD_set, if_pos ⟨rfl, hlen⟩]

theorem apc_avRow1_mem {A : AdaParams} {st : AdaState} (hok : AdaOK A st) (vals : List (List ℕ))
    {j : ℕ} (hj : j + 1 < A.p) (q : Bool) : avRow1 A st vals j q ∈ avScores A st vals j q := by
  have hsl := hok.scores_len
  have hlen : j + 1 < (st.scores.set j (avRow A st vals j q)).length := by
    rw [List.length_set]; omega
  unfold avScores
  rw [if_pos hj]
  refine apc_mem_of_getD (n := j + 1) (d := []) (by simp; omega) ?_
  rw [av_getD_set, if_pos ⟨rfl, hlen⟩]

/-! ## One corrected row -/

/-- **One corrected row**: `set [sc, i, linComb [get [sc, i], get [vals, i], 1, c]]`. -/
theorem corrSet_val (hL : ListLib prog) (hlc : prog[Idx.linComb]? = some body_linComb)
    (hlcs : prog[Idx.linCombStep]? = some body_linCombStep) {env : List Val}
    {scE iE valsE cE : Expr} {Lr : List (List ℤ)} {vals : List (List ℕ)} {i : ℕ} {c : ℤ} {K Bd : ℕ}
    {row : List ℤ}
    (hsc : EvalsVal prog M env [] (.inl scE) (encL (encL encZ) Lr))
    (hi : EvalsVal prog M env [] (.inl iE) (Val.int (i : ℤ)))
    (hvals : EvalsVal prog M env [] (.inl valsE) (encVals vals))
    (hc : EvalsVal prog M env [] (.inl cE) (Val.int c))
    (hiL : i < Lr.length) (hiv : i < vals.length)
    (hKg : ∀ z ∈ Lr.getD i [], bitLen z ≤ K)
    (hKv : ∀ y ∈ (vals.getD i []).map (fun n : ℕ => (n : ℤ)), bitLen y ≤ K)
    (hKc : bitLen c ≤ K) (hK1 : 1 ≤ K)
    (hscB : valSize (encL (encL encZ) Lr) ≤ Bd) (hvalsB : valSize (encVals vals) ≤ Bd)
    (hlenB : (Lr.getD i []).length * (2 * K + 3) + 2 * K + Nat.size i + 100 ≤ Bd)
    (hrow : List.zipWith (fun x y => 1 * x + c * y) (Lr.getD i [])
        ((vals.getD i []).map fun n : ℕ => (n : ℤ)) = row)
    (hrowB : valSize (encInts row) ≤ Bd) (hBd : 64 * Bd ≤ M) :
    EvalsVal prog M env [] (.inl (eCall Idx.set (eList [scE, iE,
        eCall Idx.linComb (eList [eCall Idx.get (ePair scE iE), eCall Idx.get (ePair valsE iE),
          eLit 1, cE])])))
      (encL (encL encZ) (Lr.set i row)) := by
  have hr := corrRow_val hL hlc hlcs hsc hi hvals hc hiL hiv hKg hKv hKc hK1 hscB hvalsB hlenB hBd
  rw [hrow] at hr
  have hiS : valSize (Val.int (i : ℤ)) ≤ Nat.size i + 1 := by simp [bitLen_natCast]
  have hLr : valSize (Val.list (Lr.map (encL encZ))) = valSize (encL (encL encZ) Lr) := rfl
  have hl : EvalsVal prog M env [] (.inl (eList [scE, iE, eCall Idx.linComb (eList
      [eCall Idx.get (ePair scE iE), eCall Idx.get (ePair valsE iE), eLit 1, cE])]))
      (Val.list [Val.list (Lr.map (encL encZ)), Val.int (i : ℤ), encInts row]) :=
    evalsVal_list (List.Forall₂.cons hsc (List.Forall₂.cons hi
      (List.Forall₂.cons hr List.Forall₂.nil))) (by
        simp only [valSize_list, listSize_cons, listSize_nil] at hLr ⊢
        omega)
  have hs := set_val hL hl (by unfold S_set; omega)
  rw [encInts_eq_encL, ← List.map_set] at hs
  exact hs

/-! ## `adaCorrDet` -/

/-- **Spec of `adaCorrDet`** (Idx 705): on `[j, q, st, pub, vals]` it returns the corrected scores
and the incremented correction counters. -/
theorem adaCorrDet_val (hL : ListLib prog) (hlc : prog[Idx.linComb]? = some body_linComb)
    (hlcs : prog[Idx.linCombStep]? = some body_linCombStep) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [corrIn A st vals j q] [] (.inl body_adaCorrDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) := by
  have hok' : AdaOK A (avState A st vals j q st.thrInt) :=
    avState_ok hok vals q hj hTj hok.thr_len hok.thr_le
  -- sizes
  have hB := apc_adaBoundA_eq A
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have hstB := valSize_adaEnc_le hok
  have hst'B := valSize_adaEnc_le hok'
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hvalsB := valSize_encVals_le hbs hv.1 hv.2
  have hscS : valSize (encL (encL encZ) st.scores) < valSize (adaEnc st) :=
    valSize_lt_of_mem (l := apc_stFields st) List.mem_cons_self
  have hTS : valSize (encL encN st.T) < valSize (adaEnc st) :=
    valSize_lt_of_mem (l := apc_stFields st) (List.mem_cons_of_mem _ List.mem_cons_self)
  have hS'S : valSize (encL (encL encZ) (avScores A st vals j q)) <
      valSize (adaEnc (avState A st vals j q st.thrInt)) :=
    valSize_lt_of_mem (l := apc_stFields (avState A st vals j q st.thrInt)) List.mem_cons_self
  have hT'S : valSize (encL encN (st.T.set j (st.T.getD j 0 + 1))) <
      valSize (adaEnc (avState A st vals j q st.thrInt)) :=
    valSize_lt_of_mem (l := apc_stFields (avState A st vals j q st.thrInt))
      (List.mem_cons_of_mem _ List.mem_cons_self)
  have hrowS : valSize (encInts (avRow A st vals j q)) <
      valSize (encL (encL encZ) (avScores A st vals j q)) :=
    valSize_lt_of_mem (List.mem_map_of_mem (f := encL encZ) (apc_avRow_mem hok vals hj q))
  have hsc1S : valSize (encL (encL encZ) (st.scores.set j (avRow A st vals j q))) ≤
      valSize (encL (encL encZ) st.scores) + valSize (encInts (avRow A st vals j q)) := by
    have := apc_valSize_set_le (st.scores.map (encL encZ)) j (encInts (avRow A st vals j q))
    rw [encInts_eq_encL, ← List.map_set] at this
    exact this
  have hsl := hok.scores_len
  have hTl := hok.T_len
  have hvl : vals.length = A.p + 1 := by rw [apc_vals_length hv, hbs]
  have hjT : j < st.T.length := by omega
  have hN : ∀ i, A.blockSizes.getD i 0 ≤ A.N := fun i => getD_le_sum A.blockSizes i
  have hNK : A.N * (2 * (adaZ A + 4) + 3) ≤ 2 * ((A.N + A.p + 16) * (adaZ A + 16)) := by
    calc A.N * (2 * (adaZ A + 4) + 3) ≤ (A.N + A.p + 16) * (2 * (adaZ A + 16)) :=
          Nat.mul_le_mul (by omega) (by omega)
      _ = 2 * ((A.N + A.p + 16) * (adaZ A + 16)) := by ring
  have hfuel : st.T.getD j 0 + 1 ≤ A.fuel := by
    have := getD_le_sum A.Tmax j
    unfold AdaParams.fuel
    omega
  have hTj1 : Nat.size (st.T.getD j 0 + 1) ≤ adaZ A :=
    (Nat.size_le_size hfuel).trans (size_fuel_le_adaZ A)
  have hsj : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have h2M : 2 ≤ M := by omega
  -- fields of the input
  have hxM : valSize (Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals])
      ≤ M := by
    have h2 := apc_bitLen_avSign_le q
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
    omega
  have fx : ∀ {pre : List Val} {k : ℕ} {v : Val},
      [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals][k]? = some v →
      EvalsVal prog M (pre ++ [corrIn A st vals j q]) [] (.inl (eAtN k (eV pre.length))) v :=
    fun {pre k v} h => evalsVal_atN' (EvalsVal.var (by simp [corrIn])) hxM h
  have hstM : valSize (Val.list (apc_stFields st)) ≤ M := by
    have : valSize (Val.list (apc_stFields st)) = valSize (adaEnc st) := rfl
    omega
  have fst : ∀ {pre : List Val} {k : ℕ} {v : Val}, (apc_stFields st)[k]? = some v →
      EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
        (.inl (eAtN k (eAtN 2 (eV pre.length)))) v :=
    fun {pre k v} h =>
      evalsVal_atN' (fx (pre := pre) (k := 2) (v := Val.list (apc_stFields st)) rfl) hstM h
  have hpubM : valSize (Val.list (pubFields A)) ≤ M := by
    have : valSize (Val.list (pubFields A)) = valSize (adaPubEnc A) := rfl
    omega
  have ej : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eV pre.length))) (Val.int (j : ℤ)) :=
    fun {pre} => fx (pre := pre) (k := 0) (v := Val.int (j : ℤ)) rfl
  have eq_ : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 1 (eV pre.length))) (Val.int (avSign q)) :=
    fun {pre} => fx (pre := pre) (k := 1) (v := Val.int (avSign q)) rfl
  have evals : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 4 (eV pre.length))) (encVals vals) :=
    fun {pre} => fx (pre := pre) (k := 4) (v := encVals vals) rfl
  have ep : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eAtN 3 (eV pre.length)))) (Val.int (A.p : ℤ)) :=
    fun {pre} => evalsVal_atN' (fx (pre := pre) (k := 3) (v := Val.list (pubFields A)) rfl) hpubM rfl
  have esc : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eAtN 2 (eV pre.length)))) (encL (encL encZ) st.scores) :=
    fun {pre} => fst (pre := pre) (k := 0) rfl
  have eT : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 1 (eAtN 2 (eV pre.length)))) (encL encN st.T) :=
    fun {pre} => fst (pre := pre) (k := 1) rfl
  unfold body_adaCorrDet
  -- `sc := st.scores`
  refine apc_letE (esc (pre := [])) ?_
  -- row `j`
  have hlen1 : (st.scores.getD j []).length ≤ A.N := by
    rw [hok.scores_blk j hj]; exact hN j
  refine apc_letE (corrSet_val hL hlc hlcs (K := adaZ A + 4) (Bd := 4 * adaBoundA A)
      (row := avRow A st vals j q) EvalsVal.var0
      (ej (pre := [encL (encL encZ) st.scores]))
      (evals (pre := [encL (encL encZ) st.scores]))
      (EvalsVal.mul (EvalsVal.lit' (z := 4) (by
          rw [valSize_int]; have : bitLen (4 : ℤ) = 3 := by decide
          omega)) (eq_ (pre := [encL (encL encZ) st.scores])) (by
          rw [valSize_int]; have := apc_bitLen_four_avSign_le q; omega))
      (by omega) (by omega)
      (fun z hz => (apc_scores_getD_bitLen hok j z hz).trans (by omega))
      (fun y hy => (apc_vals_getD_bitLen hv j y hy).trans (by omega))
      ((apc_bitLen_four_avSign_le q).trans (by omega)) (by omega)
      (by omega) (by omega)
      (by have := Nat.mul_le_mul hlen1 (le_refl (2 * (adaZ A + 4) + 3))
          omega)
      (apc_avRow_eq_lc hok hv hj q).symm
      (by omega) (by omega)) ?_
  -- row `j + 1` (if any)
  refine apc_letE (va := encL (encL encZ) (avScores A st vals j q)) ?_ ?_
  · have hj1E : EvalsVal prog M ([encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores] ++ [corrIn A st vals j q]) []
        (.inl (eAdd (eAtN 0 (eV 2)) (eLit 1))) (Val.int ((j + 1 : ℕ) : ℤ)) :=
      apc_succ_val (ej (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores])) (by have := size_le_self (j + 1); omega) h2M
    have hc := EvalsVal.lt hj1E (ep (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores])) h2M
    by_cases hj1 : j + 1 < A.p
    · refine apc_ite_true hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
      have e : avScores A st vals j q =
          (st.scores.set j (avRow A st vals j q)).set (j + 1) (avRow1 A st vals j q) := by
        unfold avScores; rw [if_pos hj1]
      have hrow1S : valSize (encInts (avRow1 A st vals j q)) <
          valSize (encL (encL encZ) (avScores A st vals j q)) :=
        valSize_lt_of_mem (List.mem_map_of_mem (f := encL encZ) (apc_avRow1_mem hok vals hj1 q))
      have hlen2 : ((st.scores.set j (avRow A st vals j q)).getD (j + 1) []).length ≤ A.N := by
        rw [av_getD_set, if_neg (by omega), hok.scores_blk (j + 1) hj1]; exact hN (j + 1)
      rw [e]
      exact corrSet_val hL hlc hlcs (K := adaZ A + 4) (Bd := 4 * adaBoundA A)
        EvalsVal.var0 hj1E
        (evals (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
          encL (encL encZ) st.scores]))
        (EvalsVal.sub (EvalsVal.lit' (z := 0) (by simp; omega))
          (eq_ (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
            encL (encL encZ) st.scores])) (by
          rw [zero_sub, valSize_int]; have := apc_bitLen_neg_avSign_le q; omega))
        (by rw [List.length_set]; omega) (by omega)
        (fun z hz => by
          rw [av_getD_set, if_neg (by omega)] at hz
          exact (apc_scores_getD_bitLen hok (j + 1) z hz).trans (by omega))
        (fun y hy => (apc_vals_getD_bitLen hv (j + 1) y hy).trans (by omega))
        (by rw [zero_sub]; exact (apc_bitLen_neg_avSign_le q).trans (by omega)) (by omega)
        (by omega) (by omega)
        (by have := Nat.mul_le_mul hlen2 (le_refl (2 * (adaZ A + 4) + 3))
            have := size_le_self (j + 1)
            omega)
        (by rw [zero_sub]; exact (apc_avRow1_eq_lc hok hv hj1 q).symm)
        (by omega) (by omega)
    · refine apc_ite_false hc (by rw [if_neg (by omega)]) ?_
      have e : avScores A st vals j q = st.scores.set j (avRow A st vals j q) := by
        unfold avScores; rw [if_neg hj1]
      rw [e]
      exact EvalsVal.var0
  -- the counters and the output pair
  · have hTv : valSize (Val.list (st.T.map encN)) = valSize (encL encN st.T) := rfl
    have hp := EvalsVal.pair
      (eT (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
      (ej (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
          omega)
    have hg := get_val hL (l := st.T.map encN) (n := j) hp (by unfold S_get; omega)
    rw [apc_getD_map_lt _ _ hjT _ 0] at hg
    have hs1 := apc_succ_val hg (by omega) h2M
    have hl : EvalsVal prog M ([encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores] ++
          [corrIn A st vals j q]) []
        (.inl (eList [eAtN 1 (eAtN 2 (eV 3)), eAtN 0 (eV 3),
          eAdd (eCall Idx.get (ePair (eAtN 1 (eAtN 2 (eV 3))) (eAtN 0 (eV 3)))) (eLit 1)]))
        (Val.list [Val.list (st.T.map encN), Val.int (j : ℤ),
          Val.int ((st.T.getD j 0 + 1 : ℕ) : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons (eT (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
        (List.Forall₂.cons (ej (pre := [encL (encL encZ) (avScores A st vals j q),
          encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
          (List.Forall₂.cons hs1 List.Forall₂.nil))) (by
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hTv ⊢
        omega)
    have hset := set_val hL hl (by
      unfold S_set
      simp only [valSize_int, bitLen_natCast]
      omega)
    have e : Val.list ((st.T.map encN).set j (Val.int ((st.T.getD j 0 + 1 : ℕ) : ℤ))) =
        encL encN (st.T.set j (st.T.getD j 0 + 1)) := by
      unfold encL
      rw [List.map_set]
      rfl
    rw [e] at hset
    exact EvalsVal.pair EvalsVal.var0 hset (by
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega)

end Proof

end F2e2e.C.Impl
