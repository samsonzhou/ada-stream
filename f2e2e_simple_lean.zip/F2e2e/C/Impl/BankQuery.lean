import F2e2e.C.Impl.BankRows

/-!
# W5: regularized counters and query values (778–783, 789, 792)

Shared by `validate` (756) and `release` (757):

* `zxVal P mode = [mode, 2^{eSigma}, 2^{eHb}, w, irrW P, D*]` (`bkZExtra_val`, 789);
* `zNOf P mode r = cnt·2^{eSigma} + b_{D*}·2^{eHb}`, so `regZ P mode r = zN / 2^{eHb+eSigma}`
  (`regZ_eq`; `bkZN_val`, 778);
* `qxVal P mode cN cD = [zx, cD, 2^{2(eHb+eSigma)} L cN, 2^{qA}]` (`bkQExtra_val`, 792);
* the query table `encVals (adaVals P mode (cN/cD) B)` (`bkValsQ_val`, 783 = `mapB` of 781 = `mapB`
  of `bkRowQ` 779), its well-formedness `valsOK_adaVals`.
-/

namespace F2e2e.C.Impl.BankDSL

open F2e2e.Cost F2e2e.Cost.HashDSL F2e2e.C.Alg F2e2e.C.Space F2e2e.B F2e2e.C.Top F2e2e.Discrete

/-! ## Values and references -/

/-- `zx = [mode, 2^{eSigma}, 2^{eHb}, w, irrW P, D*]`. -/
def zxVal (P : StreamParams) (mode : Mode) : Val :=
  Val.list [encMode mode, Val.int ((2 : ℤ) ^ P.eSigma), Val.int ((2 : ℤ) ^ P.eHb), Val.int (P.w : ℤ),
    Val.int (irrW P : ℤ), Val.int (P.Dstar : ℤ)]

/-- The counter of a row in a mode: `X` (`PRIMARY`) or `X − Y` (`DIFF`). -/
def cntOf (mode : Mode) (r : Row) : ℤ :=
  match mode with
  | Mode.primary => r.X
  | Mode.diff => r.X - r.Y

/-- `zN = cnt·2^{eSigma} + b_{D*}·2^{eHb}`. -/
def zNOf (P : StreamParams) (mode : Mode) (r : Row) : ℤ :=
  cntOf mode r * 2 ^ P.eSigma + rowSign P r P.Dstar * 2 ^ P.eHb

/-- `qx = [zx, cD, 2^{2(eHb+eSigma)} L cN, 2^{qA}]` (the scale `c = cN / cD`). -/
def qxVal (P : StreamParams) (mode : Mode) (cN cD : ℤ) : Val :=
  Val.list [zxVal P mode, Val.int cD, Val.int (2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN),
    Val.int ((2 : ℤ) ^ (bankAda P).qA)]

theorem regZ_eq (P : StreamParams) (mode : Mode) (r : Row) :
    regZ P mode r = (zNOf P mode r : ℚ) / 2 ^ (P.eHb + P.eSigma) := by
  have h1 : (2 : ℚ) ^ P.eHb ≠ 0 := by positivity
  have h2 : (2 : ℚ) ^ P.eSigma ≠ 0 := by positivity
  cases mode <;>
  · simp only [regZ, zNOf, cntOf, gridVal, StreamParams.sigma]
    push_cast
    rw [pow_add, one_div, inv_pow]
    field_simp

theorem bitLen_cntOf_le {P : StreamParams} {r : Row} (hr : RowOK P r) (mode : Mode) :
    bitLen (cntOf mode r) ≤ 22 * P.calL ^ 3 + 3 := by
  have hZ := bitLen_zSat_le P
  have hX : bitLen r.X ≤ bitLen (zSat P) :=
    bitLen_le_bitLen_of_natAbs_le (by
      obtain ⟨h1, h2⟩ := abs_le.mp hr.abs_X_le; have := zSat_nonneg P; omega)
  have hY : bitLen r.Y ≤ bitLen (zSat P) :=
    bitLen_le_bitLen_of_natAbs_le (by
      obtain ⟨h1, h2⟩ := abs_le.mp hr.abs_Y_le; have := zSat_nonneg P; omega)
  cases mode
  · simp only [cntOf]; omega
  · simp only [cntOf]
    have h1 := bitLen_add_le r.X (-r.Y)
    rw [bitLen_neg] at h1
    rw [sub_eq_add_neg]
    have : max (bitLen r.X) (bitLen r.Y) ≤ bitLen (zSat P) := max_le hX hY
    omega

theorem bitLen_zNOf_le {P : StreamParams} {r : Row} (hr : RowOK P r) (mode : Mode) :
    bitLen (zNOf P mode r) ≤ 31 * P.calL ^ 3 := by
  have hc := bitLen_cntOf_le hr mode
  have hs := bitLen_rowSign_le P r P.Dstar
  have hS := eSigma_le P
  have hH := eHb_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have h1 := bitLen_mul_le' (cntOf mode r) ((2 : ℤ) ^ P.eSigma)
  have h2 := bitLen_mul_le' (rowSign P r P.Dstar) ((2 : ℤ) ^ P.eHb)
  rw [bitLen_two_pow] at h1 h2
  have h3 := bitLen_add_le (cntOf mode r * 2 ^ P.eSigma) (rowSign P r P.Dstar * 2 ^ P.eHb)
  have h4 : max (bitLen (cntOf mode r * 2 ^ P.eSigma)) (bitLen (rowSign P r P.Dstar * 2 ^ P.eHb))
      ≤ 29 * P.calL ^ 3 + 4 := max_le (by omega) (by omega)
  unfold zNOf
  omega

theorem queryIdx_le (qA L : ℕ) (c z : ℚ) : queryIdx qA L c z ≤ 2 ^ qA := by
  simp only [queryIdx]
  split_ifs with h
  · exact le_refl _
  · have h := not_le.mp h
    have h2 : roundMant qA (z ^ 2 / ((L : ℚ) * c)) ≤ 2 ^ qA := by
      unfold roundMant
      rw [Int.floor_le_iff]
      push_cast
      have : (0 : ℚ) < 2 ^ qA := by positivity
      nlinarith
    have h3 := Int.toNat_le.mpr (show roundMant qA (z ^ 2 / ((L : ℚ) * c)) ≤ ((2 ^ qA : ℕ) : ℤ) by
      push_cast; exact h2)
    exact h3

theorem valsOK_adaVals {P : StreamParams} {ok : AdaState → Prop} {B : Bank} (hB : BankOK P ok B)
    (mode : Mode) (c : ℚ) : ValsOK P (adaVals P mode c B) := by
  refine ⟨?_, ?_⟩
  · rw [← hB.ada_sizes]
    simp [adaVals, List.map_map, Function.comp_def]
  · intro blk hblk v hv
    simp only [adaVals, List.mem_map] at hblk
    obtain ⟨b, -, rfl⟩ := hblk
    simp only [List.mem_map] at hv
    obtain ⟨r, -, rfl⟩ := hv
    exact queryIdx_le _ _ _ _

theorem queryIdx_eq (qA L : ℕ) (hL : 0 < L) (cN cD zN : ℤ) (hcN : 0 < cN) (hcD : 0 < cD)
    (E : ℕ) :
    ((queryIdx qA L ((cN : ℚ) / (cD : ℚ)) ((zN : ℚ) / 2 ^ E) : ℕ) : ℤ) =
      if zN * zN * cD < 2 ^ (2 * E) * (L : ℤ) * cN then
        rdivZ (zN * zN * cD * 2 ^ qA) (2 ^ (2 * E) * (L : ℤ) * cN)
      else 2 ^ qA := by
  simp only [queryIdx]
  have hden : (0 : ℤ) < 2 ^ (2 * E) * (L : ℤ) * cN := by positivity
  have hdenQ : (0 : ℚ) < ((2 ^ (2 * E) * (L : ℤ) * cN : ℤ) : ℚ) := by exact_mod_cast hden
  have hratio : ((zN : ℚ) / 2 ^ E) ^ 2 / ((L : ℚ) * ((cN : ℚ) / (cD : ℚ))) =
      ((zN * zN * cD : ℤ) : ℚ) / ((2 ^ (2 * E) * (L : ℤ) * cN : ℤ) : ℚ) := by
    have hL' : (L : ℚ) ≠ 0 := by positivity
    have hcN' : (cN : ℚ) ≠ 0 := by positivity
    have hcD' : (cD : ℚ) ≠ 0 := by positivity
    push_cast
    rw [pow_mul']
    field_simp
  rw [hratio]
  by_cases h : zN * zN * cD < 2 ^ (2 * E) * (L : ℤ) * cN
  · rw [if_pos h]
    have h1 : ¬ (1 ≤ ((zN * zN * cD : ℤ) : ℚ) / ((2 ^ (2 * E) * (L : ℤ) * cN : ℤ) : ℚ)) := by
      rw [not_le, div_lt_one hdenQ]
      exact_mod_cast h
    rw [if_neg h1]
    have h2 : roundMant qA (((zN * zN * cD : ℤ) : ℚ) / ((2 ^ (2 * E) * (L : ℤ) * cN : ℤ) : ℚ)) =
        rdivZ (zN * zN * cD * 2 ^ qA) (2 ^ (2 * E) * (L : ℤ) * cN) := by
      rw [rdivZ_eq _ _ hden]
      unfold roundMant
      congr 1
      push_cast
      ring
    rw [h2]
    have hz := mul_self_nonneg zN
    have h3 : 0 ≤ zN * zN * cD * 2 ^ qA :=
      mul_nonneg (mul_nonneg hz hcD.le) (by positivity)
    have h4 : 0 ≤ rdivZ (zN * zN * cD * 2 ^ qA) (2 ^ (2 * E) * (L : ℤ) * cN) := by
      unfold rdivZ
      exact Int.ediv_nonneg (by omega) (by omega)
    exact Int.toNat_of_nonneg h4
  · rw [if_neg h]
    have h1 : 1 ≤ ((zN * zN * cD : ℤ) : ℚ) / ((2 ^ (2 * E) * (L : ℤ) * cN : ℤ) : ℚ) := by
      rw [le_div_iff₀ hdenQ, one_mul]
      exact_mod_cast not_lt.mp h
    rw [if_pos h1]
    push_cast
    ring

/-- C-TOP's `encVals` (elaborated with a list-monad coercion) as nested `encL`s. -/
theorem encVals_eq_map (vals : List (List ℕ)) :
    encVals vals = encL (fun blk : List ℕ => encL (fun v : ℕ => Val.int (v : ℤ)) blk) vals := by
  unfold encVals encL
  congr 1
  apply List.map_congr_left
  intro blk hblk
  clear hblk
  congr 1
  induction blk with
  | nil => rfl
  | cons a l ih => simp_all

section rules

variable {prog : List Expr} {M : ℕ}

/-! ## The routines -/

theorem valSize_encMode_le (mode : Mode) : valSize (encMode mode) ≤ 2 := by
  cases mode <;> simp [encMode]

theorem bitLen_Dstar_le (P : StreamParams) : bitLen (P.Dstar : ℤ) ≤ 3 * P.calL + 1 := by
  have h1 := Dstar_le P
  have h2 : P.Dstar < 2 ^ (3 * P.calL + 1) := by
    calc P.Dstar ≤ 2 ^ (3 * P.calL) := h1
      _ < 2 ^ (3 * P.calL + 1) := Nat.pow_lt_pow_right (by norm_num) (by omega)
  exact bitLen_nat_le_of_lt h2

theorem bitLen_irrW_le (P : StreamParams) : bitLen (irrW P : ℤ) ≤ 3 * P.calL + 2 := by
  obtain ⟨-, hirr, -⟩ := isIrrPoly_irrW P (W2.one_le_Dstar P)
  have hw := w_le P
  exact (bitLen_nat_le_of_lt hirr).trans (by omega)

theorem valSize_zxVal_le (P : StreamParams) (mode : Mode) :
    valSize (zxVal P mode) ≤ 26 * P.calL ^ 3 := by
  have hm := valSize_encMode_le mode
  have hS := eSigma_le P
  have hH := eHb_le P
  have hw : bitLen (P.w : ℤ) ≤ 3 * P.calL + 1 := bitLen_natCast_le_of_le (w_le P)
  have hi := bitLen_irrW_le P
  have hD := bitLen_Dstar_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  simp only [zxVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_pow]
  omega

/-- 789: `[encP, mode] ↦ zx`. -/
theorem bkZExtra_val (R : AdaRep) (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) :
    EvalsVal prog M [Val.list [encStreamParams P, encMode mode]] [] (.inl body_bkZExtra)
      (zxVal P mode) := by
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hz := valSize_zxVal_le P mode
  have hm := valSize_encMode_le mode
  have hS := eSigma_le P
  have hH := eHb_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hI : valSize (Val.list [encStreamParams P, encMode mode]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hpS : Cost.S_pow2 P.eSigma ≤ M := by
    have := size_le_self P.eSigma; simp only [Cost.S_pow2]; omega
  have hpH : Cost.S_pow2 P.eHb ≤ M := by
    have := size_le_self P.eHb; simp only [Cost.S_pow2]; omega
  unfold body_bkZExtra
  refine ev_let (ev_hd (ev_var rfl) hI) ?_
  exact ev_list (.cons (ev_at1 (ev_var rfl) hI)
    (.cons (ev_pow2 hlib (ev_param hw1.peSigma P hP hM (ev_var rfl)) hpS)
    (.cons (ev_pow2 hlib (ev_param hw1.peHb P hP hM (ev_var rfl)) hpH)
    (.cons (ev_param hw1.pw P hP hM (ev_var rfl))
    (.cons (ev_param hw1.pIrrW P hP hM (ev_var rfl))
    (.cons (ev_param hw1.pDstar P hP hM (ev_var rfl)) .nil)))))) (by unfold zxVal at hz; omega)

/-- 778: `[encRow r, zx] ↦ zN`. -/
theorem bkZN_val (R : AdaRep) (hlib : BankLib prog) (hw2 : HornerLib prog) (P : StreamParams)
    (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (r : Row) (hr : RowOK P r) :
    EvalsVal prog M [Val.list [encRow r, zxVal P mode]] [] (.inl body_bkZN)
      (Val.int (zNOf P mode r)) := by
  have hMv := Mv_ge R P
  have hz := valSize_zxVal_le P mode
  have hrow := hr.valSize_encRow_le
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hS := eSigma_le P
  have hH := eHb_le P
  have hcnt := bitLen_cntOf_le hr mode
  have hzN := bitLen_zNOf_le hr mode
  have hs := bitLen_rowSign_le P r P.Dstar
  have hm := valSize_encMode_le mode
  have hw : bitLen (P.w : ℤ) ≤ 3 * P.calL + 1 := bitLen_natCast_le_of_le (w_le P)
  have hi := bitLen_irrW_le P
  have hD := bitLen_Dstar_le P
  have h1 := bitLen_mul_le' (cntOf mode r) ((2 : ℤ) ^ P.eSigma)
  have h2 := bitLen_mul_le' (rowSign P r P.Dstar) ((2 : ℤ) ^ P.eHb)
  rw [bitLen_two_pow] at h1 h2
  have hr' := hrow
  simp only [encRow, valSize_list, valSize_int, listSize_cons, listSize_nil] at hr'
  have hI : valSize (Val.list [encRow r, zxVal P mode]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hrowM : valSize (Val.list [encInts (r.seed.map fun z : ℕ => (z : ℤ)), Val.int r.X,
      Val.int r.Y]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hzx : valSize (Val.list [encMode mode, Val.int ((2 : ℤ) ^ P.eSigma),
      Val.int ((2 : ℤ) ^ P.eHb), Val.int (P.w : ℤ), Val.int (irrW P : ℤ),
      Val.int (P.Dstar : ℤ)]) ≤ M := by unfold zxVal at hz; omega
  have h2M : 2 ≤ M := by omega
  have h20 : 2 ^ 20 * P.calL ^ 3 ≤ M := by omega
  have hsd : encInts (r.seed.map fun z : ℕ => (z : ℤ)) = encL encN r.seed := encInts_seed r
  unfold body_bkZN
  refine ev_let (ev_hd (ev_var rfl) hI) (ev_let (ev_at1 (ev_var rfl) hI) ?_)
  -- the counter
  have hcntE : EvalsVal prog M [zxVal P mode, encRow r, Val.list [encRow r, zxVal P mode]] []
      (.inl (eIte (eEq (eHd (eV 0)) (eLit 0)) (eAt1 (eV 1)) (eSub (eAt1 (eV 1)) (eAt2 (eV 1)))))
      (Val.int (cntOf mode r)) := by
    cases mode
    · exact ev_ite_t (ev_eq (ev_hd (ev_var rfl) hzx) (ev_lit (by simp; omega)) h2M)
        (by simp [encMode]) (ev_at1 (ev_var rfl) hrowM)
    · refine ev_ite_f (ev_eq (ev_hd (ev_var rfl) hzx) (ev_lit (by simp; omega)) h2M)
        (by simp [encMode]) ?_
      exact ev_sub (ev_at1 (ev_var rfl) hrowM) (ev_at2 (ev_var rfl) hrowM)
        (by simp only [valSize_int]; simp only [cntOf] at hcnt; omega)
  refine ev_let hcntE ?_
  refine ev_let (rowSign_call_val hw2 P hP r hr P.Dstar (W2.one_le_Dstar P) le_rfl h20 ?_) ?_
  · rw [← hsd]
    exact ev_list (.cons (ev_at3 (ev_var rfl) hzx) (.cons (ev_at4 (ev_var rfl) hzx)
      (.cons (ev_hd (ev_var rfl) hrowM) (.cons (ev_at5 (ev_var rfl) hzx) .nil))))
      (by simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  unfold zNOf
  exact ev_add (ev_mul (ev_var rfl) (ev_at1 (ev_var rfl) hzx) (by simp only [valSize_int]; omega))
    (ev_mul (ev_var rfl) (ev_at2 (ev_var rfl) hzx) (by simp only [encZ, valSize_int]; omega))
    (by simp only [valSize_int]; unfold zNOf at hzN; omega)

theorem bitLen_L_le (P : StreamParams) : bitLen (P.L : ℤ) ≤ 48 * P.calL := by
  have h1 := s_le P
  have h2 : P.L ≤ 48 * P.calL := by unfold StreamParams.L; omega
  exact bitLen_natCast_le_of_le h2

theorem L_pos (P : StreamParams) : 0 < P.L := by
  unfold StreamParams.L StreamParams.s; omega

theorem bound_le_bankSizeBound (P : StreamParams) (b : ℕ) : b ≤ bankSizeBound P b := by
  unfold bankSizeBound; omega

theorem valSize_qxVal_le (R : AdaRep) (hR : R.Valid) {P : StreamParams} (hP : ParamsOK P)
    (mode : Mode) {cN cD : ℤ} (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3)
    (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3) :
    valSize (qxVal P mode cN cD) ≤ 2 ^ 12 * P.calL ^ 3 + R.bound P := by
  have hz := valSize_zxVal_le P mode
  have hqA := hR.qA_le P hP
  have hS := eSigma_le P
  have hH := eHb_le P
  have hL := bitLen_L_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have h1 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma))) (P.L : ℤ)
  have h2 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ)) cN
  rw [bitLen_two_pow] at h1
  simp only [qxVal, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_pow]
  omega

/-- 792: `[encP, zx, cN, cD] ↦ qx`. -/
theorem bkQExtra_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw1 : W1Contract R prog M)
    (hw4 : W4Contract R prog M) (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M)
    (mode : Mode) (cN cD : ℤ) (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3)
    (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3) :
    EvalsVal prog M [Val.list [encStreamParams P, zxVal P mode, Val.int cN, Val.int cD]] []
      (.inl body_bkQExtra) (qxVal P mode cN cD) := by
  have hMv := Mv_ge R P
  have hPs := valSize_encStreamParams_le' P
  have hz := valSize_zxVal_le P mode
  have hq := valSize_qxVal_le R hR hP mode hbN hbD
  have hqA := hR.qA_le P hP
  have hRb := bound_le_bankSizeBound P (R.bound P)
  have hS := eSigma_le P
  have hH := eHb_le P
  have hL := bitLen_L_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hI : valSize (Val.list [encStreamParams P, zxVal P mode, Val.int cN, Val.int cD]) ≤ M := by
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hp2E : Cost.S_pow2 (2 * (P.eHb + P.eSigma)) ≤ M := by
    have := size_le_self (2 * (P.eHb + P.eSigma)); simp only [Cost.S_pow2]; omega
  have hpq : Cost.S_pow2 (bankAda P).qA ≤ M := by
    have := size_le_self (bankAda P).qA; simp only [Cost.S_pow2]; omega
  have h1 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma))) (P.L : ℤ)
  have h2 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ)) cN
  rw [bitLen_two_pow] at h1
  obtain ⟨bq, hbq, hqspec⟩ := hw4.adaQA
  unfold body_bkQExtra
  refine ev_let (ev_hd (ev_var rfl) hI) ?_
  refine ev_list (.cons (ev_at1 (ev_var rfl) hI) (.cons (ev_at3 (ev_var rfl) hI)
    (.cons ?_ (.cons (ev_pow2 hlib (ev_call hbq (ev_var rfl) (hqspec P hP hM)) hpq) .nil))))
    (by unfold qxVal at hq; omega)
  refine ev_mul (ev_mul (ev_pow2 hlib ?_ hp2E) (ev_param hw1.pL P hP hM (ev_var rfl))
    (by simp only [valSize_int]; omega)) (ev_at2 (ev_var rfl) hI) (by simp only [valSize_int]; omega)
  rw [show (((2 * (P.eHb + P.eSigma) : ℕ) : ℤ)) = 2 * ((P.eHb : ℤ) + (P.eSigma : ℤ)) by
    push_cast; ring]
  exact ev_mul (ev_lit (by simp [bitLen_two_eq]; omega))
    (ev_add (ev_param hw1.peHb P hP hM (ev_var rfl)) (ev_param hw1.peSigma P hP hM (ev_var rfl))
      (by
        simp only [valSize_int]
        have := bitLen_natCast_le_of_le (le_refl (P.eHb + P.eSigma))
        push_cast at this
        omega))
    (by
      simp only [valSize_int]
      have := bitLen_natCast_le_of_le (le_refl (2 * (P.eHb + P.eSigma)))
      push_cast at this
      omega)

/-- 779: `[encRow r, qx] ↦ queryIdx qA L (cN/cD) (regZ P mode r)`. -/
theorem bkRowQ_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw2 : HornerLib prog)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (r : Row)
    (hr : RowOK P r) (cN cD : ℤ) (hcN : 0 < cN) (hcD : 0 < cD)
    (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3) (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3) :
    EvalsVal prog M [Val.list [encRow r, qxVal P mode cN cD]] [] (.inl body_bkRowQ)
      (Val.int (queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r) : ℤ)) := by
  rw [regZ_eq, queryIdx_eq _ _ (L_pos P) _ _ _ hcN hcD]
  have hMv := Mv_ge R P
  have hq := valSize_qxVal_le R hR hP mode hbN hbD
  have hrow := hr.valSize_encRow_le
  have hzN := bitLen_zNOf_le hr mode
  have hqA := hR.qA_le P hP
  have hRb := bound_le_bankSizeBound P (R.bound P)
  have hS := eSigma_le P
  have hH := eHb_le P
  have hL := bitLen_L_le P
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hLz : (0 : ℤ) < (P.L : ℤ) := by exact_mod_cast L_pos P
  have hden : (0 : ℤ) < 2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN :=
    mul_pos (mul_pos (pow_pos (by norm_num) _) hLz) hcN
  have h1 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma))) (P.L : ℤ)
  have h2 := bitLen_mul_le' ((2 : ℤ) ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ)) cN
  rw [bitLen_two_pow] at h1
  have h3 := bitLen_mul_le' (zNOf P mode r) (zNOf P mode r)
  have h4 := bitLen_mul_le' (zNOf P mode r * zNOf P mode r) cD
  have h5 := bitLen_mul_le' (zNOf P mode r * zNOf P mode r * cD) ((2 : ℤ) ^ (bankAda P).qA)
  rw [bitLen_two_pow] at h5
  have hI : valSize (Val.list [encRow r, qxVal P mode cN cD]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega
  have hqx : valSize (Val.list [zxVal P mode, Val.int cD,
      Val.int (2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN), Val.int ((2 : ℤ) ^ (bankAda P).qA)]) ≤ M := by
    unfold qxVal at hq; omega
  have hzx := valSize_zxVal_le P mode
  have h2M : 2 ≤ M := by omega
  have hite : (if zNOf P mode r * zNOf P mode r * cD < 2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN then
        Val.int (rdivZ (zNOf P mode r * zNOf P mode r * cD * 2 ^ (bankAda P).qA)
          (2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN))
      else Val.int (2 ^ (bankAda P).qA)) =
      Val.int (if zNOf P mode r * zNOf P mode r * cD < 2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN then
        rdivZ (zNOf P mode r * zNOf P mode r * cD * 2 ^ (bankAda P).qA)
          (2 ^ (2 * (P.eHb + P.eSigma)) * (P.L : ℤ) * cN)
      else 2 ^ (bankAda P).qA) := by
    split_ifs <;> rfl
  rw [← hite]
  unfold body_bkRowQ
  refine ev_let (ev_at1 (ev_var rfl) hI) ?_
  refine ev_let (ev_call hlib.bkZN (ev_pair (ev_hd (ev_var rfl) hI) (ev_hd (ev_var rfl) hqx)
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
    (bkZN_val R hlib hw2 P hP hM mode r hr)) ?_
  refine ev_let (ev_mul (ev_mul (ev_var rfl) (ev_var rfl) (by simp only [valSize_int]; omega))
    (ev_at1 (ev_var rfl) hqx) (by simp only [valSize_int]; omega)) ?_
  refine ev_let (ev_at2 (ev_var rfl) hqx) ?_
  exact ev_ite_dec (ev_lt (ev_var rfl) (ev_var rfl) h2M)
    (fun _ => ev_call hlib.bkRDiv (ev_pair (ev_mul (ev_var rfl) (ev_at3 (ev_var rfl) hqx)
      (by simp only [valSize_int]; omega)) (ev_var rfl)
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
      (bkRDiv_val _ _ hden (by omega)))
    (fun _ => ev_at3 (ev_var rfl) hqx)

/-- 783 (`body_mapB bkBlockQStep`): `[encL (encL encRow) B.ada, qx] ↦ encVals (adaVals P mode c B)`
for `c = cN / cD > 0`. -/
theorem bkValsQ_val (R : AdaRep) (hR : R.Valid) (hlib : BankLib prog) (hw2 : HornerLib prog)
    (P : StreamParams) (hP : ParamsOK P) (hM : Mv R P ≤ M) (mode : Mode) (B : Bank)
    (hB : BankOK P (R.ok P) B) (cN cD : ℤ) (hcN : 0 < cN) (hcD : 0 < cD)
    (hbN : bitLen cN ≤ 2 ^ 10 * P.calL ^ 3) (hbD : bitLen cD ≤ 2 ^ 10 * P.calL ^ 3) :
    EvalsVal prog M [Val.list [encL (encL encRow) B.ada, qxVal P mode cN cD]] []
      (.inl (body_mapB Idx.bkBlockQStep)) (encVals (adaVals P mode ((cN : ℚ) / (cD : ℚ)) B)) := by
  have hMv := Mv_ge R P
  have hq := valSize_qxVal_le R hR hP mode hbN hbD
  have hRb := bound_le_bankSizeBound P (R.bound P)
  have hc3 := (W2.calL_pow_bounds P).1
  have hc100 := hundred_le_calL P
  have hvals := hR.vals_le P hP _ (valsOK_adaVals hB mode ((cN : ℚ) / (cD : ℚ)))
  have hs1 := bank_size_le R hR hP hB
  have hada : valSize (encL (encL encRow) B.ada) ≤ bankSizeBound P (R.bound P) := by
    have : valSize (encL (encL encRow) B.ada) < valSize (encBank R.enc B) :=
      valSize_lt_of_mem (l := [encL (encL encRow) B.ada, encL (encL (encL encRow)) B.coarse,
        R.enc B.adaSt]) (by simp)
    omega
  rw [encVals_eq_map] at hvals ⊢
  unfold adaVals at hvals ⊢
  refine mapD_val hlib.bkBlockQStep hlib.bkBlockQ hlib.reverse hlib.revAppendStep (encL encRow)
    (fun blk : List ℕ => encL (fun v : ℕ => Val.int (v : ℤ)) blk) (qxVal P mode cN cD)
    (fun blk => blk.map (fun r =>
      queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r))) B.ada
    (fun blk hblk => ?_) (by omega)
  have h1 := valSize_lt_encL (encL encRow) hblk
  have h2 : valSize (encL (fun v : ℕ => Val.int (v : ℤ)) (blk.map (fun r =>
      queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r)))) <
      valSize (encL (fun blk : List ℕ => encL (fun v : ℕ => Val.int (v : ℤ)) blk)
      (B.ada.map (fun blk => blk.map (fun r =>
        queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r))))) :=
    valSize_lt_encL (fun blk : List ℕ => encL (fun v : ℕ => Val.int (v : ℤ)) blk)
    (List.mem_map.mpr ⟨blk, hblk, rfl⟩ : blk.map (fun r =>
      queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r)) ∈
      B.ada.map (fun blk => blk.map (fun r =>
        queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r))))
  exact mapD_val hlib.bkRowQStep hlib.bkRowQ hlib.reverse hlib.revAppendStep encRow
    (fun v : ℕ => Val.int (v : ℤ)) (qxVal P mode cN cD) (fun r =>
      queryIdx (bankAda P).qA P.L ((cN : ℚ) / (cD : ℚ)) (regZ P mode r)) blk
    (fun r hr => bkRowQ_val R hR hlib hw2 P hP hM mode r (hB.ada_rows blk hblk r hr) cN cD hcN hcD
      hbN hbD) (by omega)

end rules

end F2e2e.C.Impl.BankDSL
