import F2e2e.C.Impl.Tree3Maps
import F2e2e.C.Impl.Tree2

/-!
# W6, Tree3 (proofs, part 2): the guard update `body_step3Apply` (Idx 266)

`step3Apply_val`: on `[p, encState s, d, encLearner L_d, g, δ]` the body evaluates to
`encState (step3ApplyRef P s d L_d g δ)` (the bank updates by `addGuardYBank` / `addGuardXYBank`, the
roundings of the cache and of the terminal accumulator, the two range checks).
-/

namespace F2e2e.C.Impl.W6

open F2e2e.Cost F2e2e.C.Alg F2e2e.C.Space F2e2e.Discrete F2e2e.C.Top

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate parameters such as
`P.Amax` symbolically (C-SPACE's tip). -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Register bounds of stored values -/

theorem LearnerOK.cache_le_regBits {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) :
    L.cache ≤ 2 ^ regBits P := by
  have h := hL.cache_le
  have h1 := eAmax_le P
  have h2 := eHP_le P
  have hc1 := hundred_le_calL P
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hk : 2 + P.eAmax + P.eHP ≤ regBits P := by unfold regBits; omega
  have hA : ((P.Amax : ℕ) : ℤ) = 2 ^ P.eAmax := by simp [StreamParams.Amax]
  calc L.cache ≤ ((4 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) := h
    _ = 2 ^ (2 + P.eAmax + P.eHP) := by rw [hA]; push_cast; ring
    _ ≤ 2 ^ regBits P := pow_le_pow_right₀ (by norm_num) hk

theorem StateOK.leaf_le_regBits {P : StreamParams} {adaOK : F2e2e.B.AdaState → Prop} {s : State}
    (hs : StateOK P adaOK 4 s) : s.leaf ≤ 2 ^ regBits P := by
  have h := hs.leaf_le
  have h1 := eAmax_le P
  have h2 := eHleaf_le P
  have hc1 := hundred_le_calL P
  have hc2 := hundred_mul_calL_le_sq P
  have hc3 := hundred_mul_sq_le_cube P
  have hk : 2 + P.eAmax + P.eHleaf ≤ regBits P := by unfold regBits; omega
  have hA : ((P.Amax : ℕ) : ℤ) = 2 ^ P.eAmax := by simp [StreamParams.Amax]
  calc s.leaf ≤ ((4 : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHleaf) := h
    _ = 2 ^ (2 + P.eAmax + P.eHleaf) := by rw [hA]; push_cast; ring
    _ ≤ 2 ^ regBits P := pow_le_pow_right₀ (by norm_num) hk

/-- The cache/accumulator update `m 2^{-q} + (δ 2^{-q_g})²` as one quotient. -/
theorem sum_frac_eq (a δ : ℤ) (eP eG : ℕ) :
    (((a * ((2 ^ (eG + eG) : ℕ) : ℤ) + δ * δ * ((2 ^ eP : ℕ) : ℤ) : ℤ) : ℚ) /
      ((((2 ^ eP : ℕ) : ℤ) * ((2 ^ (eG + eG) : ℕ) : ℤ) : ℤ) : ℚ)) =
    gridVal eP a + gridVal eG δ ^ 2 := by
  unfold gridVal
  push_cast
  field_simp
  ring

theorem gridVal_eq_div (m : ℤ) (q : ℕ) :
    ((m : ℚ) / ((((2 ^ q : ℕ)) : ℤ) : ℚ)) = gridVal q m := by
  unfold gridVal
  push_cast
  rfl

/-- Bounds for the numerator of the cache/accumulator update. -/
theorem sum_num_bound {a δ : ℤ} {eP eG R : ℕ} (ha : |a| ≤ 2 ^ R) (hδ : |δ| ≤ 2 ^ R) :
    |a * ((2 ^ (eG + eG) : ℕ) : ℤ) + δ * δ * ((2 ^ eP : ℕ) : ℤ)| ≤ 2 ^ (2 * R + 10 * eG + eP + 1) := by
  have hA := abs_mul_le_pow ha (abs_natCast_two_pow (eG + eG))
  have hD := abs_mul_le_pow (abs_mul_le_pow hδ hδ) (abs_natCast_two_pow eP)
  apply abs_add_le_pow
  · exact abs_le_pow_mono hA (by omega)
  · exact abs_le_pow_mono hD (by omega)

/-- `encState_step3ApplyRef` with the updated learner written as a record update. -/
theorem encState_step3ApplyRef' (adaEnc : F2e2e.B.AdaState → Val) (P : StreamParams) (s : State)
    (d : ℕ) (Ld : Learner) (g : ℕ) (δ : ℤ) :
    encState adaEnc (step3ApplyRef P s d Ld g δ) =
      if inRangeA P (gridVal P.eHP (cache3 P Ld δ)) && inRangeA P (gridVal P.eHleaf (leaf3 P s δ)) then
        Val.list [Val.int (s.t : ℤ), Val.int (if s.failed then 1 else 0), Val.int (s.fpSeed : ℤ),
          Val.int (s.fpVal : ℤ), encL encLearner (setAt { Ld with cache := cache3 P Ld δ } d s.learners),
          encL (encBank adaEnc) (banks3 P s d g δ), Val.int (leaf3 P s δ)]
      else
        Val.list [Val.int (s.t : ℤ), Val.int 1, Val.int (s.fpSeed : ℤ), Val.int (s.fpVal : ℤ),
          encL encLearner s.learners, encL (encBank adaEnc) (banks3 P s d g δ), Val.int s.leaf] :=
  encState_step3ApplyRef adaEnc P s d Ld g δ

/-! ## The guard update -/

set_option maxHeartbeats 1000000 in
theorem step3Apply_val {R : AdaRep} (hR : R.Valid) {prog : List Expr} {M : ℕ}
    (hC : Contracts R prog M) (hT : Tree3Lib prog) {P : StreamParams} (hP : ParamsOK P)
    (hM : Mv R P ≤ M) {s : State} (hs : StateOK P (R.ok P) 4 s) (ht : s.t ≤ P.m) {d : ℕ}
    (hd : d < P.H) {Ld : Learner} (hLd : s.learners[d]? = some Ld) {g : ℕ} (hg1 : 1 ≤ g)
    (hg2 : g ≤ P.Dstar) {δ : ℤ} (hδ : |δ| ≤ 2 ^ regBits P)
    (hout : StateOK P (R.ok P) 4 (step3ApplyRef P s d Ld g δ)) :
    EvalsVal prog M [Val.list [encStreamParams P, encState R.enc s, encN d, encLearner Ld, encN g,
        encZ δ]] [] (.inl body_step3Apply) (encState R.enc (step3ApplyRef P s d Ld g δ)) := by
  obtain ⟨beP, hbeP, heP⟩ := hC.w1.peHP
  obtain ⟨beL, hbeL, heL⟩ := hC.w1.peHleaf
  obtain ⟨beG, hbeG, heG⟩ := hC.w1.peHg
  obtain ⟨brm, hbrm, hrm⟩ := hC.w5.roundMantQ
  obtain ⟨bnq, hbnq, hnq⟩ := hC.normQ
  obtain ⟨bir, hbir, hir⟩ := hC.w5.inRangeA
  have hada := hR.enc_le P hP
  obtain ⟨hS1, hMv, hSSB, hH1, hHc, hc1, hc2, hc3, hreg⟩ := size_facts R P
  have hSM : stateSizeBound P (R.bound P) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have hLd4 : LearnerOK P 4 Ld := hs.learners_ok Ld (List.mem_of_getElem? hLd)
  -- the input
  have hst : valSize (encState R.enc s) ≤ stateSizeBound P (R.bound P) :=
    StateOK.valSize_encState_le hada hs ht
  have hstM : valSize (encState R.enc s) ≤ M := hst.trans hSM
  have hLsz : valSize (encLearner Ld) ≤ 2 ^ 6 * P.calL ^ 3 := LearnerOK.valSize_encLearner_le hLd4
  have hLM : valSize (encLearner Ld) ≤ M := by omega
  have hpsz := valSize_encStreamParams_le P
  have hdsz : valSize (encN d) ≤ P.H + 1 := by rw [valSize_encN]; have := size_le_self d; omega
  have hd1sz : valSize (encN (d + 1)) ≤ P.H + 2 := by
    rw [valSize_encN]; have := size_le_self (d + 1); omega
  have hDs := Dstar_le P
  have hgsz : valSize (encN g) ≤ 3 * P.calL + 2 := by
    apply valSize_encN_le_of_lt
    have : 0 < 2 ^ (3 * P.calL) := by positivity
    rw [pow_succ]; omega
  have hδsz : valSize (encZ δ) ≤ regBits P + 2 := valSize_int_le_of_abs_le hδ
  have hXsz : valSize (Val.list [encStreamParams P, encState R.enc s, encN d, encLearner Ld, encN g,
      encZ δ]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  -- the banks
  have hB0 := hs.banks_ok
  have hlen0 := hs.banks_length_le
  have hB1 : ∀ B ∈ modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d s.banks, BankOK P (R.ok P) B :=
    Aux.forall_mem_modifyAt _ (fun B hB => bankOK_addGuardY' hB g δ) d s.banks hB0
  have hlen1 : (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d s.banks).length ≤ P.H := by
    rw [length_modifyAt]; exact hlen0
  have hext1 : valSize (Val.list [encStreamParams P, encN d, encN g, encZ δ]) ≤ 2 * regBits P := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hext2 : valSize (Val.list [encStreamParams P, encN (d + 1), encN g, encZ δ]) ≤
      2 * regBits P := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hbsz := valSize_banks_le_encState R.enc s
  have hb1sz : valSize (encL (encBank R.enc) (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d
      s.banks)) ≤ stateSizeBound P (R.bound P) := by
    have h1 := valSize_encL_le (encBank R.enc) _ (bankSizeBound P (R.bound P))
      (fun B hB => BankOK.valSize_encBank_le hada (hB1 B hB))
    have h2 : (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d s.banks).length *
        (bankSizeBound P (R.bound P) + 1) ≤ P.H * (bankSizeBound P (R.bound P) + 1) :=
      Nat.mul_le_mul_right _ hlen1
    omega
  -- the output
  have hout_sz : valSize (encState R.enc (step3ApplyRef P s d Ld g δ)) ≤
      stateSizeBound P (R.bound P) := StateOK.valSize_encState_le hada hout (by
        unfold step3ApplyRef; split <;> exact ht)
  -- parameters and powers
  have hePle := eHP_le P
  have heLle := eHleaf_le P
  have heGle := eHg_le P
  have hePsz : valSize (encN P.eHP) ≤ 7 * P.calL ^ 2 + 1 := by
    rw [valSize_encN]; have := size_le_self P.eHP; omega
  have heLsz : valSize (encN P.eHleaf) ≤ 20 * P.calL ^ 2 + 1 := by
    rw [valSize_encN]; have := size_le_self P.eHleaf; omega
  have heGGsz : valSize (encN (P.eHg + P.eHg)) ≤ 10 * P.calL ^ 2 + 1 := by
    rw [valSize_encN]; have := size_le_self (P.eHg + P.eHg); omega
  have hpowP := ((pow2_spec hT.pow2Step P.eHP 0).toVal).mono_M (M' := M) (by
    unfold S_pow2; have := size_le_self P.eHP; omega)
  have hpowL := ((pow2_spec hT.pow2Step P.eHleaf 0).toVal).mono_M (M' := M) (by
    unfold S_pow2; have := size_le_self P.eHleaf; omega)
  have hpowG := ((pow2_spec hT.pow2Step (P.eHg + P.eHg) 0).toVal).mono_M (M' := M) (by
    unfold S_pow2; have := size_le_self (P.eHg + P.eHg); omega)
  -- the numerators and denominators
  have hcache := LearnerOK.cache_le_regBits hLd4
  have hcache0 := hLd4.cache_nonneg
  have hleaf := StateOK.leaf_le_regBits hs
  have hleaf0 := hs.leaf_nonneg
  have hcabs : |Ld.cache| ≤ 2 ^ regBits P := by rw [abs_of_nonneg hcache0]; exact hcache
  have hlabs : |s.leaf| ≤ 2 ^ regBits P := by rw [abs_of_nonneg hleaf0]; exact hleaf
  have hnumC := sum_num_bound (eP := P.eHP) (eG := P.eHg) hcabs hδ
  have hnumL := sum_num_bound (eP := P.eHleaf) (eG := P.eHg) hlabs hδ
  have hdenC : ((2 ^ P.eHP : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) ≤
      2 ^ (P.eHP + (P.eHg + P.eHg)) := by push_cast; rw [← pow_add]
  have hdenL : ((2 ^ P.eHleaf : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) ≤
      2 ^ (P.eHleaf + (P.eHg + P.eHg)) := by push_cast; rw [← pow_add]
  have hdenC0 : (0 : ℤ) < ((2 ^ P.eHP : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) := by positivity
  have hdenL0 : (0 : ℤ) < ((2 ^ P.eHleaf : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) := by
    positivity
  have hregK : 2 * regBits P + 10 * P.eHg + P.eHleaf + 1 + P.eHleaf + 3 ≤ 4 * regBits P := by
    rw [hreg]; omega
  have hregKC : 2 * regBits P + 10 * P.eHg + P.eHP + 1 + P.eHP + 3 ≤ 4 * regBits P := by
    rw [hreg]; omega
  have hQC : QOK P (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2) := by
    rw [← sum_frac_eq]
    exact qok_div hnumC hdenC0 hdenC (by omega) (by omega)
  have hQL : QOK P (gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2) := by
    rw [← sum_frac_eq]
    exact qok_div hnumL hdenL0 hdenL (by omega) (by omega)
  have hzC : |gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2| ≤
      2 ^ (2 * regBits P + 10 * P.eHg + P.eHP + 1) := by
    rw [← sum_frac_eq]
    exact abs_div_le_of_one_le hnumC (by omega)
  have hzL : |gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2| ≤
      2 ^ (2 * regBits P + 10 * P.eHg + P.eHleaf + 1) := by
    rw [← sum_frac_eq]
    exact abs_div_le_of_one_le hnumL (by omega)
  have hc1abs : |cache3 P Ld δ| ≤ 2 ^ (2 * regBits P + 10 * P.eHg + P.eHP + 1 + P.eHP + 1) :=
    abs_roundMant_le hzC
  have hl1abs : |leaf3 P s δ| ≤ 2 ^ (2 * regBits P + 10 * P.eHg + P.eHleaf + 1 + P.eHleaf + 1) :=
    abs_roundMant_le hzL
  have hQc1 : QOK P (gridVal P.eHP (cache3 P Ld δ)) :=
    qok_gridVal (lt_of_le_of_lt hc1abs (pow_lt_pow_right₀ (by norm_num) (by omega))) hregKC
      (by omega)
  have hQl1 : QOK P (gridVal P.eHleaf (leaf3 P s δ)) :=
    qok_gridVal (lt_of_le_of_lt hl1abs (pow_lt_pow_right₀ (by norm_num) (by omega))) hregK
      (by omega)
  -- bit lengths
  have hbl : ∀ {z : ℤ} {k : ℕ}, |z| ≤ 2 ^ k → bitLen z ≤ k + 1 := fun {z k} h => by
    have hpos : (0 : ℤ) < 2 ^ k := by positivity
    exact bitLen_le_of_abs_lt (lt_of_le_of_lt h (by rw [pow_succ]; linarith))
  have hδδ := abs_mul_le_pow hδ hδ
  have hcpg := abs_mul_le_pow hcabs (abs_natCast_two_pow (P.eHg + P.eHg))
  have hlpg := abs_mul_le_pow hlabs (abs_natCast_two_pow (P.eHg + P.eHg))
  have hdpP := abs_mul_le_pow hδδ (abs_natCast_two_pow P.eHP)
  have hdpL := abs_mul_le_pow hδδ (abs_natCast_two_pow P.eHleaf)
  have hdC' := abs_mul_le_pow (abs_natCast_two_pow P.eHP) (abs_natCast_two_pow (P.eHg + P.eHg))
  have hdL' := abs_mul_le_pow (abs_natCast_two_pow P.eHleaf) (abs_natCast_two_pow (P.eHg + P.eHg))
  have hsz : ∀ {z : ℤ} {k : ℕ}, |z| ≤ 2 ^ k → k + 2 ≤ M → valSize (Val.int z) ≤ M :=
    fun h hk => (valSize_int_le_of_abs_le h).trans hk
  have hK : 4 * regBits P + 64 ≤ M := by omega
  have hQCsz := valSize_encQ_le_of_QOK hQC
  have hQLsz := valSize_encQ_le_of_QOK hQL
  have hQc1sz := valSize_encQ_le_of_QOK hQc1
  have hQl1sz := valSize_encQ_le_of_QOK hQl1
  -- generalize the closed semantic objects: no `whnf` may ever evaluate `step3ApplyRef …`
  have hOe := encState_step3ApplyRef' R.enc P s d Ld g δ
  clear hout
  generalize hO : step3ApplyRef P s d Ld g δ = O at hOe hout_sz ⊢
  rw [hOe] at hout_sz
  have hcv : roundMant P.eHP (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2) = cache3 P Ld δ := rfl
  have hlv : roundMant P.eHleaf (gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2) = leaf3 P s δ := rfl
  generalize hc1 : cache3 P Ld δ = c1 at hOe hout_sz hc1abs hQc1 hQc1sz hcv
  generalize hl1 : leaf3 P s δ = l1 at hOe hout_sz hl1abs hQl1 hQl1sz hlv
  generalize hr1 : inRangeA P (gridVal P.eHP c1) = r1 at hOe hout_sz
  generalize hr2 : inRangeA P (gridVal P.eHleaf l1) = r2 at hOe hout_sz
  unfold body_step3Apply
  refine ev_letE (ev_get 0 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 2 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 3 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 4 (EvalsVal.var rfl) hXsz rfl) ?_
  refine ev_letE (ev_get 5 (EvalsVal.var rfl) hXsz rfl) ?_
  -- b1: `modifyAt` of the banks
  refine ev_letE (evalsVal_call_det hT.modY
    (ev_list (.cons (ev_get 5 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) .nil))))
        (show valSize (Val.list [encStreamParams P, encN d, encN g, encZ δ]) ≤ M by omega)) .nil))
      (show valSize (Val.list [encL (encBank R.enc) s.banks,
          Val.list [encStreamParams P, encN d, encN g, encZ δ]]) ≤ M by
        rw [valSize_pair]; omega))
    (step3ModY_val hR hC hT hP hM hB0 hlen0 hg1 hg2 hδ hext1)) ?_
  -- b2: `mapFrom` of the banks
  refine ev_letE (evalsVal_call_det hT.mapXY
    (ev_list (.cons (EvalsVal.var rfl)
      (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons ?hd1 (.cons (EvalsVal.var rfl)
        (.cons (EvalsVal.var rfl) .nil))))
        (show valSize (Val.list [encStreamParams P, encN (d + 1), encN g, encZ δ]) ≤ M by omega))
        .nil))
      (show valSize (Val.list [encL (encBank R.enc) (modifyAt (Bank.mapRows (Row.addGuardY P g δ)) d
          s.banks), Val.list [encStreamParams P, encN (d + 1), encN g, encZ δ]]) ≤ M by
        rw [valSize_pair]; omega))
    (step3MapXY_val hR hC hT hP hM hB1 hlen1 hg1 hg2 hδ hext2)) ?_
  case hd1 =>
    have he : encN (d + 1) = Val.int ((d : ℤ) + 1) := by simp [encN]
    have hs1 : valSize (Val.int ((d : ℤ) + 1)) ≤ M := by rw [← he]; omega
    rw [he]
    exact ev_add (EvalsVal.var rfl) (EvalsVal.lit' (by simp; omega)) hs1
  -- the grid exponents
  refine ev_letE (evalsVal_call_det hbeP (EvalsVal.var rfl) (heP P hP hM)) ?_
  refine ev_letE (evalsVal_call_det hbeL (EvalsVal.var rfl) (heL P hP hM)) ?_
  refine ev_letE (evalsVal_call_det hbeG (EvalsVal.var rfl) (heG P hP hM)) ?_
  -- δ²
  refine ev_letE (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (hsz hδδ (by omega))) ?_
  -- the powers of two
  refine ev_letE (evalsVal_call_det hT.pow2 ?hgg hpowG) ?_
  case hgg =>
    have he : encN (P.eHg + P.eHg) = Val.int ((P.eHg : ℤ) + P.eHg) := by simp [encN]
    have hs1 : valSize (Val.int ((P.eHg : ℤ) + P.eHg)) ≤ M := by rw [← he]; omega
    rw [he]
    exact ev_add (EvalsVal.var rfl) (EvalsVal.var rfl) hs1
  refine ev_letE (evalsVal_call_det hT.pow2 (EvalsVal.var rfl) hpowP) ?_
  refine ev_letE (evalsVal_call_det hT.pow2 (EvalsVal.var rfl) hpowL) ?_
  -- the cache update `cache / 2^{q_P} + (δ / 2^{q_g})²`
  refine ev_letE (va := encQ (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2)) ?_ ?_
  · have hc := hnq (Ld.cache * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) + δ * δ * ((2 ^ P.eHP : ℕ) : ℤ))
      (((2 ^ P.eHP : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ)) hdenC0
      (by have := hbl hnumC; have := hbl hdC'; omega)
    rw [sum_frac_eq] at hc
    exact evalsVal_call_det hbnq (ev_list (.cons (ev_add (ev_mul (ev_get 1 (EvalsVal.var rfl) hLM rfl)
        (EvalsVal.var rfl) (hsz hcpg (by omega))) (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl)
        (hsz hdpP (by omega))) (hsz hnumC (by omega)))
      (.cons (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (hsz hdC' (by omega))) .nil))
      (show valSize (Val.list [Val.int (Ld.cache * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) +
          δ * δ * ((2 ^ P.eHP : ℕ) : ℤ)), Val.int (((2 ^ P.eHP : ℕ) : ℤ) *
          ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ))]) ≤ M by
        rw [valSize_pair]
        have := valSize_int_le_of_abs_le hnumC
        have := valSize_int_le_of_abs_le hdC'
        omega)) hc
  refine ev_letE (va := Val.int c1) (hcv ▸ evalsVal_call_det hbrm
    (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
      (show valSize (Val.list [encN P.eHP, encQ (gridVal P.eHP Ld.cache + gridVal P.eHg δ ^ 2)]) ≤ M by
        rw [valSize_pair]; omega))
    (hrm P P.eHP _ hP (by omega) hQC hM)) ?_
  -- the accumulator update
  refine ev_letE (va := encQ (gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2)) ?_ ?_
  · have hc := hnq (s.leaf * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) + δ * δ * ((2 ^ P.eHleaf : ℕ) : ℤ))
      (((2 ^ P.eHleaf : ℕ) : ℤ) * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ)) hdenL0
      (by have := hbl hnumL; have := hbl hdL'; omega)
    rw [sum_frac_eq] at hc
    exact evalsVal_call_det hbnq (ev_list (.cons (ev_add (ev_mul (ev_get 6 (EvalsVal.var rfl) hstM rfl)
        (EvalsVal.var rfl) (hsz hlpg (by omega))) (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl)
        (hsz hdpL (by omega))) (hsz hnumL (by omega)))
      (.cons (ev_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (hsz hdL' (by omega))) .nil))
      (show valSize (Val.list [Val.int (s.leaf * ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ) +
          δ * δ * ((2 ^ P.eHleaf : ℕ) : ℤ)), Val.int (((2 ^ P.eHleaf : ℕ) : ℤ) *
          ((2 ^ (P.eHg + P.eHg) : ℕ) : ℤ))]) ≤ M by
        rw [valSize_pair]
        have := valSize_int_le_of_abs_le hnumL
        have := valSize_int_le_of_abs_le hdL'
        omega)) hc
  refine ev_letE (va := Val.int l1) (hlv ▸ evalsVal_call_det hbrm
    (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
      (show valSize (Val.list [encN P.eHleaf, encQ (gridVal P.eHleaf s.leaf + gridVal P.eHg δ ^ 2)])
          ≤ M by rw [valSize_pair]; omega))
    (hrm P P.eHleaf _ hP (by omega) hQL hM)) ?_
  -- the range checks
  refine ev_letE (va := encB r1) ?_ ?_
  · rw [← hr1]
    have hc := hnq c1 ((2 ^ P.eHP : ℕ) : ℤ) (by positivity)
      (by have := hbl hc1abs; have := hbl (abs_natCast_two_pow P.eHP); omega)
    rw [gridVal_eq_div] at hc
    exact evalsVal_call_det hbir (ev_list (.cons (EvalsVal.var rfl)
      (.cons (evalsVal_call_det hbnq (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
        (show valSize (Val.list [Val.int c1, encN (2 ^ P.eHP)]) ≤ M by
          rw [valSize_pair]
          have := valSize_int_le_of_abs_le hc1abs
          have := valSize_int_le_of_abs_le (abs_natCast_two_pow P.eHP)
          simp only [encN] at *
          omega)) hc) .nil))
      (show valSize (Val.list [encStreamParams P, encQ (gridVal P.eHP c1)]) ≤ M by
        rw [valSize_pair]; omega))
      (hir P _ hP hQc1 hM)
  refine ev_letE (va := encB r2) ?_ ?_
  · rw [← hr2]
    have hc := hnq l1 ((2 ^ P.eHleaf : ℕ) : ℤ) (by positivity)
      (by have := hbl hl1abs; have := hbl (abs_natCast_two_pow P.eHleaf); omega)
    rw [gridVal_eq_div] at hc
    exact evalsVal_call_det hbir (ev_list (.cons (EvalsVal.var rfl)
      (.cons (evalsVal_call_det hbnq (ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil))
        (show valSize (Val.list [Val.int l1, encN (2 ^ P.eHleaf)]) ≤ M by
          rw [valSize_pair]
          have := valSize_int_le_of_abs_le hl1abs
          have := valSize_int_le_of_abs_le (abs_natCast_two_pow P.eHleaf)
          simp only [encN] at *
          omega)) hc) .nil))
      (show valSize (Val.list [encStreamParams P, encQ (gridVal P.eHleaf l1)]) ≤ M by
        rw [valSize_pair]; omega))
      (hir P _ hP hQl1 hM)
  -- the outcome
  rw [hOe]
  cases r1 <;> cases r2
  · simp only [Bool.false_and, Bool.false_eq_true, if_false] at hout_sz ⊢
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [Bool.false_eq_true, if_false]
    exact ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.lit' (by simp; omega))
      (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl) .nil))))))) (hout_sz.trans hSM)
  · simp only [Bool.false_and, Bool.false_eq_true, if_false] at hout_sz ⊢
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [Bool.false_eq_true, if_false]
    exact ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.lit' (by simp; omega))
      (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl) .nil))))))) (hout_sz.trans hSM)
  · simp only [Bool.true_and, Bool.false_eq_true, if_false] at hout_sz ⊢
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [if_true]
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [Bool.false_eq_true, if_false]
    exact ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.lit' (by simp; omega))
      (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl) hstM rfl)
        (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl) (.cons (EvalsVal.var rfl)
          (.cons (ev_get 6 (EvalsVal.var rfl) hstM rfl) .nil))))))) (hout_sz.trans hSM)
  · simp only [Bool.true_and, if_true] at hout_sz ⊢
    have hnew : LearnerOK P 4 { Ld with cache := c1 } := LearnerOK.with_cache hLd4 (by norm_num) hr1
    have hnsz : valSize (encLearner { Ld with cache := c1 }) ≤ 2 ^ 6 * P.calL ^ 3 :=
      LearnerOK.valSize_encLearner_le hnew
    have hlsz : valSize (encL encLearner s.learners) ≤ valSize (encState R.enc s) := by
      simp only [encState, encL, valSize_list, listSize_cons, listSize_nil]
      omega
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [if_true]
    refine ev_ite_encB (EvalsVal.var rfl) ?_
    simp only [if_true]
    refine ev_list (.cons (ev_get 0 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 1 (EvalsVal.var rfl)
      hstM rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hstM rfl) (.cons (ev_get 3 (EvalsVal.var rfl)
        hstM rfl) (.cons ?_ (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)))))))
      (hout_sz.trans hSM)
    exact evalsVal_call_det hT.setL (ev_list (.cons (ev_get 4 (EvalsVal.var rfl) hstM rfl)
      (.cons (ev_list (.cons (EvalsVal.var rfl) (.cons (ev_list (.cons (ev_get 0 (EvalsVal.var rfl)
        hLM rfl) (.cons (EvalsVal.var rfl) (.cons (ev_get 2 (EvalsVal.var rfl) hLM rfl)
          (.cons (ev_get 3 (EvalsVal.var rfl) hLM rfl) (.cons (ev_get 4 (EvalsVal.var rfl) hLM rfl)
            .nil))))) (show valSize (encLearner { Ld with cache := c1 }) ≤ M by omega)) .nil))
        (show valSize (Val.list [encN d, encLearner { Ld with cache := c1 }]) ≤ M by
          rw [valSize_pair]; omega)) .nil))
      (show valSize (Val.list [encL encLearner s.learners,
          Val.list [encN d, encLearner { Ld with cache := c1 }]]) ≤ M by
        rw [valSize_pair, valSize_pair]; omega))
      (step3SetL_val hT hM hs.learners_ok hs.learners_length_le hd hnew)

end F2e2e.C.Impl.W6
