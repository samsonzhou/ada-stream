import F2e2e.Cost.Lib.MapB
import F2e2e.Cost.ValRules

/-!
# W3 (Theorem (C) samplers): generic helpers and the replicate combinator `repB`

Owner: W3 (4a7299ed). Generic pieces used by the fingerprint-seed sampler (`SamplerFp.lean`), the
row-seed / row / coarse-group samplers (`SamplerRows.lean`) and bank creation (`NewBank.lean`);
design: `notes/C_IMPL_DESIGN.md` §2, `notes/DSL_CONVENTION.md`.

* `implements_letE_of_run`, `implements_letE_det`: `letE` rules for `Implements` (the continuation
  is needed only on outputs of the first program; deterministic bound expression).
* `replicateB_succ_run_exact`, `replicateB_run_forall`, `mapB_run_forall₂`: exact runs of DSL-CALC's
  reference functions `replicateB` (= C-ALG's `sampleList`) and `mapB`.
* The DSL routine `repB` (generic in the element function index `iF`; its loop body
  `body_repBStep iF` is stored at an index `iStep` chosen by the user): input `[k, extra]` ↦ the
  `k` results of the element routine (which runs in the environment `[extra]`), in draw order
  (accumulated in reverse, then reversed by the library routine `reverse`). Spec `repB_impl`
  (`Implements` form, uniform element bound `VB`).
* `mapB_impl_tot`: DSL-CALC's `mapB` routine (`body_mapB`, `body_mapBStep`, `F2e2e/Cost/Lib/MapB.lean`)
  with a value bound in terms of the total size `VT` of the actual output (DSL-CALC's `mapB_impl`
  asks for `length · (uniform element bound)`, too coarse for blocks of very different sizes).
-/

namespace F2e2e.C.Impl.W3

open F2e2e F2e2e.Cost F2e2e.Discrete

/-! ## `Implements` helpers -/

section Helpers

variable {prog : List Expr} {M : ℕ} {env : List Val} {α β : Type}

/-- `letE` whose continuation only needs to implement `f a` for the outputs `a` of `p`. -/
theorem implements_letE_of_run {ea eb : Expr} {encA : α → Val} {encC : β → Val} {p : BitProg α}
    {f : α → BitProg β} (hp : Implements prog M env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → Implements prog M (encA a :: env) eb encC (f a)) :
    Implements prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsVal.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

/-- `letE` with a deterministic bound expression. -/
theorem implements_letE_det {ea eb : Expr} {va : Val} {enc : β → Val} {p : BitProg β}
    (ha : EvalsVal prog M env [] (.inl ea) va) (hb : Implements prog M (va :: env) eb enc p) :
    Implements prog M env (Expr.letE ea eb) enc p := by
  intro bits c h
  simpa using EvalsVal.letE ha (hb bits c h)

end Helpers

/-! ## Exact runs of `replicateB` and `mapB` -/

section Runs

variable {α β : Type}

/-- Exact runs of `replicateB p (k + 1)`. -/
theorem replicateB_succ_run_exact {p : BitProg β} {k : ℕ} {bits : List Bool} {bs : List β}
    (h : (replicateB p (k + 1)).run bits = some (bs, [])) :
    ∃ b₁ b₂ b bs', bits = b₁ ++ b₂ ∧ p.run b₁ = some (b, []) ∧
      (replicateB p k).run b₂ = some (bs', []) ∧ bs = b :: bs' := by
  simp only [replicateB] at h
  obtain ⟨b₁, b₂, b, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  obtain ⟨b₂₁, b₂₂, bs', rfl, h21, h22⟩ := bitProg_run_bind_exact.mp h2
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h22
  exact ⟨b₁, b₂₁, b, bs', by simp, h1, h21, rfl⟩

/-- Exact runs of `replicateB p k` have `k` results, each the output of an exact run of `p`. -/
theorem replicateB_run_forall {p : BitProg β} :
    ∀ (k : ℕ) (bits : List Bool) (bs : List β), (replicateB p k).run bits = some (bs, []) →
      bs.length = k ∧ ∀ b ∈ bs, ∃ bits', p.run bits' = some (b, [])
  | 0, bits, bs, h => by
    simp only [replicateB] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    exact ⟨rfl, by simp⟩
  | k + 1, bits, bs, h => by
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := replicateB_succ_run_exact h
    obtain ⟨hlen, hall⟩ := replicateB_run_forall k b₂ bs' h2
    refine ⟨by simp [hlen], fun c hc => ?_⟩
    rcases List.mem_cons.mp hc with rfl | hc
    · exact ⟨b₁, h1⟩
    · exact hall c hc

/-- Exact runs of `mapB f l`: the `i`-th result is the output of an exact run of `f l[i]`. -/
theorem mapB_run_forall₂ {f : α → BitProg β} :
    ∀ (l : List α) (bits : List Bool) (bs : List β), (mapB f l).run bits = some (bs, []) →
      List.Forall₂ (fun x b => ∃ bits', (f x).run bits' = some (b, [])) l bs
  | [], bits, bs, h => by
    simp only [mapB] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    exact List.Forall₂.nil
  | x :: xs, bits, bs, h => by
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapB_cons_run_exact h
    exact List.Forall₂.cons ⟨b₁, h1⟩ (mapB_run_forall₂ xs b₂ bs' h2)

end Runs

/-! ## The DSL routine `repB` -/

/-- Loop body of `repB` with element function `iF`. Environment `[acc]`, `acc = [k, accRev, extra]`:
`[0, a, e] ↦ [0, a]`, `[k, a, e] ↦ [1, [k - 1, iF e :: a, e]]` (`k ≠ 0`; the element function runs
in the environment `[e]`). -/
def body_repBStep (iF : ℕ) : Expr :=
  Expr.letE (Expr.un UnOp.head (Expr.var 0))                                    -- k; env [k, acc]
    (Expr.ite (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))
      (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))     -- [0, accRev]
      (ePair (Expr.lit 1)
        (Arith.eTriple (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))
          (Expr.bin BinOp.cons
            (Expr.call iF
              (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))
            (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1))))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))))

/-- `repB` with the loop body stored at `iStep`: input `[k, extra]` ↦ the `k` results in draw
order (loop from `[k, [], extra]`, then the library `reverse`). -/
def body_repB (iStep : ℕ) : Expr :=
  Expr.call F2e2e.Cost.Idx.reverse
    (Expr.loop iStep (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
      (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))

section RepBody

variable {prog : List Expr} {M : ℕ}

theorem repBStep_zero_val (iF : ℕ) (av extra : Val)
    (hM : valSize (Val.list [Val.int 0, av, extra]) + 6 ≤ M) :
    EvalsVal prog M [Val.list [Val.int 0, av, extra]] [] (.inl (body_repBStep iF))
      (Val.list [Val.int 0, av]) := by
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero] at hM
  have h1 : EvalsVal prog M [Val.list [Val.int 0, av, extra]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (Val.int 0) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_int, bitLen_zero]; omega)
  have hc : EvalsVal prog M [Val.int 0, Val.list [Val.int 0, av, extra]] []
      (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 1) := by
    have := EvalsVal.eq (prog := prog) (M := M)
      (env := [Val.int 0, Val.list [Val.int 0, av, extra]]) (x := 0) (y := 0) EvalsVal.var0
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega)) (by omega)
    simpa using this
  have ht : EvalsVal prog M [Val.int 0, Val.list [Val.int 0, av, extra]] []
      (.inl (ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))))
      (Val.list [Val.int 0, av]) := by
    have := EvalsVal.pair (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.int 0, Val.list [Val.int 0, av, extra]]) (z := 0)
      (by simp only [valSize_int, bitLen_zero]; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var1
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  exact (EvalsVal.letE h1 (EvalsVal.ite_true hc one_ne_zero ht)).cast_bits (by simp)

theorem repBStep_succ_val {iF : ℕ} {bodyF : Expr} (hF : prog[iF]? = some bodyF)
    {extra bv : Val} {k : ℕ} {A : List Val} {b1 : List Bool}
    (hcall : EvalsVal prog M [extra] b1 (.inl bodyF) bv)
    (hM : valSize (Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]) + valSize bv + 10 ≤ M) :
    EvalsVal prog M [Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] b1
      (.inl (body_repBStep iF))
      (Val.list [Val.int 1, Val.list [Val.int (k : ℤ), Val.list (bv :: A), extra]]) := by
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at hM
  have hk0 : ((k + 1 : ℕ) : ℤ) ≠ 0 := by positivity
  have hk0' : (k : ℤ) + 1 ≠ 0 := by omega
  have hkb : bitLen (k : ℤ) ≤ bitLen ((k + 1 : ℕ) : ℤ) := bitLen_mono_nat (by omega)
  have hsub1 : ((k + 1 : ℕ) : ℤ) - 1 = (k : ℤ) := by push_cast; ring
  have h1 : EvalsVal prog M [Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (Val.int ((k + 1 : ℕ) : ℤ)) :=
    EvalsVal.head EvalsVal.var0 (by simp only [valSize_int]; omega)
  have hc : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ),
      Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] []
      (.inl (Expr.bin BinOp.eq (Expr.var 0) (Expr.lit 0))) (Val.int 0) := by
    have := EvalsVal.eq (prog := prog) (M := M) (y := 0) (EvalsVal.var0 (v := Val.int ((k + 1 : ℕ) : ℤ))
      (rest := [Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]]))
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_zero]; omega)) (by omega)
    simpa [hk0, hk0'] using this
  have hex : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ),
      Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) extra :=
    EvalsVal.head (EvalsVal.tail (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hA : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ),
      Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))) (Val.list A) :=
    EvalsVal.head (EvalsVal.tail EvalsVal.var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list]; omega)
  have hsub : EvalsVal prog M [Val.int ((k + 1 : ℕ) : ℤ),
      Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]] []
      (.inl (Expr.bin BinOp.sub (Expr.var 0) (Expr.lit 1))) (Val.int (k : ℤ)) := by
    have := EvalsVal.sub (prog := prog) (M := M) (y := 1)
      (EvalsVal.var0 (v := Val.int ((k + 1 : ℕ) : ℤ))
        (rest := [Val.list [Val.int ((k + 1 : ℕ) : ℤ), Val.list A, extra]]))
      (EvalsVal.lit' (by simp only [valSize_int, bitLen_one]; omega))
      (by rw [hsub1]; simp only [valSize_int]; omega)
    rw [hsub1] at this
    simpa using this
  have hcall' := EvalsVal.call hex hF hcall
  have hcons := EvalsVal.cons hcall' hA
    (by simp only [valSize_list, listSize_cons]; omega)
  have htr := EvalsVal.triple hsub hcons hex
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)
  have hf := EvalsVal.pair (EvalsVal.lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega)) htr
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
  exact (EvalsVal.letE h1 (EvalsVal.ite_false hc rfl hf)).cast_bits (by simp)

end RepBody

/-! ## The `repB` loop and its spec -/

section RepSpec

variable {prog : List Expr} {M : ℕ} {β : Type}

/-- The value bound required by `repB_impl` (`k` draws, each of size `≤ VB`). -/
def repB_M (k : ℕ) (extra : Val) (VB : ℕ) : ℕ :=
  Nat.size k + 5 * (1 + k * (VB + 1)) + VB + valSize extra + 60

theorem repB_loop {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_repBStep iF))
    (hF : prog[iF]? = some bodyF) (encB : β → Val) (extra : Val) (p : BitProg β) (k VB : ℕ)
    (hFi : Implements prog M [extra] bodyF encB p)
    (hVb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : repB_M k extra VB ≤ M) :
    ∀ j, j ≤ k → ∀ done : List β, done.length + j = k → (∀ b ∈ done, valSize (encB b) ≤ VB) →
      ∀ bits bs, (replicateB p j).run bits = some (bs, []) →
      EvalsVal prog M [] bits
        (.inr (iStep, Val.list [Val.int (j : ℤ), Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro j
  induction j with
  | zero =>
    intro _ done hlen hdone bits bs h
    simp only [replicateB] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hA := valSize_rev_map_le encB done VB hdone
    have hdl : done.length * (VB + 1) ≤ k * (VB + 1) := Nat.mul_le_mul_right _ (by omega)
    refine EvalsVal.stop hstep ?_
    simp only [List.append_nil, Nat.cast_zero]
    refine repBStep_zero_val iF _ extra ?_
    simp only [repB_M, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]
      at hM hA ⊢
    omega
  | succ j ih =>
    intro hjk done hlen hdone bits bs h
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := replicateB_succ_run_exact h
    have hb := hVb b₁ b h1
    have hcall := hFi b₁ b h1
    have hdone' : ∀ c ∈ done ++ [b], valSize (encB c) ≤ VB := by
      intro c hc
      rcases List.mem_append.mp hc with hc | hc
      · exact hdone c hc
      · rw [List.mem_singleton.mp hc]; exact hb
    have hlen' : (done ++ [b]).length + j = k := by
      simp only [List.length_append, List.length_singleton]; omega
    have hrest := ih (by omega) (done ++ [b]) hlen' hdone' b₂ bs' h2
    have hA := valSize_rev_map_le encB done VB hdone
    have hdl : done.length * (VB + 1) ≤ k * (VB + 1) := Nat.mul_le_mul_right _ (by omega)
    have hkb : bitLen ((j + 1 : ℕ) : ℤ) ≤ Nat.size k := bitLen_le_size_of_le (by omega)
    have hbody := repBStep_succ_val (k := j) (A := (done.map encB).reverse) hF hcall (by
      simp only [repB_M, valSize_list, listSize_cons, listSize_nil, valSize_int] at hM hA ⊢
      omega)
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    rw [hacc] at hbody
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    rw [hval]
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- **Spec of `repB`** (`Implements` form): `k` draws of the element routine, in draw order. -/
theorem repB_impl {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_repBStep iF))
    (hF : prog[iF]? = some bodyF) (hrev : prog[F2e2e.Cost.Idx.reverse]? = some body_reverse)
    (hra : prog[F2e2e.Cost.Idx.revAppendStep]? = some body_revAppendStep) (encB : β → Val)
    (extra : Val) (p : BitProg β) (k VB : ℕ)
    (hFi : Implements prog M [extra] bodyF encB p)
    (hVb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : repB_M k extra VB ≤ M) :
    Implements prog M [Val.list [encN k, extra]] (body_repB iStep) (encL encB)
      (replicateB p k) := by
  intro bits bs h
  have hloop := repB_loop hstep hF encB extra p k VB hFi hVb hM k le_rfl [] (by simp) (by simp)
    bits bs h
  simp only [List.map_nil, List.reverse_nil, List.nil_append] at hloop
  have hsk : valSize (encN k) = Nat.size k + 1 := valSize_encN k
  have hinit : EvalsVal prog M [Val.list [encN k, extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [encN k, Val.list [], extra]) := by
    simp only [repB_M] at hM
    have := EvalsVal.triple (EvalsVal.head (prog := prog) (M := M)
      (env := [Val.list [encN k, extra]]) EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp only [valSize_list, listSize_nil]; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hl := EvalsVal.loop hinit hloop
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  obtain ⟨hlen, hBs⟩ := replicateB_run_forall k bits bs h
  have hsz : valSize (Val.list (bs.map encB).reverse) ≤ 1 + k * (VB + 1) := by
    have := valSize_rev_map_le encB bs VB (fun b hb => by
      obtain ⟨b', hb'⟩ := hBs b hb
      exact hVb b' b hb')
    rwa [hlen] at this
  have hcall := EvalsVal.call hl hrev (hrs.mono_M (by
    simp only [S_reverse, repB_M] at hM ⊢
    omega))
  simpa [encL, body_repB] using hcall

end RepSpec

/-! ## `mapB` with a total-size value bound -/

section MapTot

variable {prog : List Expr} {M : ℕ} {α β : Type}

theorem valSize_list_reverse (l : List Val) : valSize (Val.list l.reverse) = valSize (Val.list l) := by
  simp only [valSize_list, listSize_reverse]

theorem mapB_loop_tot {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) (encA : α → Val) (encB : β → Val) (extra : Val)
    (f : α → BitProg β) (l : List α) (VT : ℕ)
    (hFi : ∀ x, x ∈ l → Implements prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hM : valSize (encL encA l) + 2 * VT + valSize extra + 20 ≤ M) :
    ∀ r : List α, r <:+ l → ∀ (done : List β) (bits : List Bool) (bs : List β),
      (mapB f r).run bits = some (bs, []) → valSize (encL encB (done ++ bs)) ≤ VT →
      EvalsVal prog M [] bits
        (.inr (iStep, Val.list [encL encA r, Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro _ done bits bs h hVT
    simp only [mapB] at h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hL := valSize_encL_ge encA l
    refine EvalsVal.stop hstep ?_
    simp only [encL_nil, List.append_nil]
    refine mapBStep_nil_val iF _ extra ?_
    have hrev := valSize_list_reverse (done.map encB)
    simp only [encL, List.append_nil] at hVT
    simp only [valSize_list, listSize_cons, listSize_nil] at hrev hVT ⊢
    omega
  | cons x r ih =>
    intro hsuf done bits bs h hVT
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapB_cons_run_exact h
    have hcall := hFi x hx b₁ b h1
    have hVT' : valSize (encL encB ((done ++ [b]) ++ bs')) ≤ VT := by simpa using hVT
    have hrest := ih hsuf' (done ++ [b]) b₂ bs' h2 hVT'
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hrev := valSize_list_reverse (done.map encB)
    have hsplit : listSize ((done ++ b :: bs').map encB) =
        listSize (done.map encB) + (valSize (encB b) + 1) + listSize (bs'.map encB) := by
      rw [List.map_append, listSize_append, List.map_cons, listSize_cons]; omega
    have hbody := mapBStep_cons_val (R := r.map encA) (A := (done.map encB).reverse) hF hcall
      (by
        simp only [encL, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hR hM hVT hrev ⊢
        omega)
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    rw [hacc] at hbody
    rw [hval]
    exact EvalsVal.cont hstep hbody one_ne_zero hrest

/-- **Spec of `mapB` with a total-size bound** (`Implements` form): if the element routine
implements every `f x` (`x ∈ l`) and every output of `mapB f l` has encoded size `≤ VT`, then
`body_mapB iStep` implements `mapB f l`. -/
theorem mapB_impl_tot {iF iStep : ℕ} {bodyF : Expr} (hstep : prog[iStep]? = some (body_mapBStep iF))
    (hF : prog[iF]? = some bodyF) (hrev : prog[F2e2e.Cost.Idx.reverse]? = some body_reverse)
    (hra : prog[F2e2e.Cost.Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val)
    (encB : β → Val) (extra : Val) (f : α → BitProg β) (l : List α) (VT : ℕ)
    (hFi : ∀ x, x ∈ l → Implements prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hVT : ∀ bits bs, (mapB f l).run bits = some (bs, []) → valSize (encL encB bs) ≤ VT)
    (hM : valSize (encL encA l) + 5 * VT + valSize extra + 60 ≤ M) :
    Implements prog M [Val.list [encL encA l, extra]] (body_mapB iStep) (encL encB) (mapB f l) := by
  intro bits bs h
  have hVTb := hVT bits bs h
  have hloop := mapB_loop_tot hstep hF encA encB extra f l VT hFi (by omega) l
    (List.suffix_refl l) [] bits bs h (by simpa using hVTb)
  simp only [List.map_nil, List.reverse_nil, List.nil_append] at hloop
  have hL := valSize_encL_ge encA l
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [encL encA l, Val.list [], extra]) := by
    have := EvalsVal.triple (EvalsVal.head (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp only [valSize_list, listSize_nil]; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (by omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hl := EvalsVal.loop hinit hloop
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  have hsz := valSize_list_reverse (bs.map encB)
  have hcall := EvalsVal.call hl hrev (hrs.mono_M (by
    simp only [S_reverse]
    simp only [encL] at hVTb
    omega))
  simpa [encL, body_mapB] using hcall

end MapTot

end F2e2e.C.Impl.W3
