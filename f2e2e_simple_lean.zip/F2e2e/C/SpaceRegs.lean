import F2e2e.C.SpaceState
import F2e2e.C.Impl.W6Contracts

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`): register facts for the DSL implementation

The transient values of a round that the DSL implementation (W6, `F2e2e/C/Impl/Tree*.lean`) computes
and passes across routine boundaries are bounded by C-TOP's register scale
`regBits P = 2^7 ℒ³` (`F2e2e.C.Impl.regBits`, `F2e2e/C/Impl/W6Contracts.lean`; partIII.tex L1180:
"every register has `O(ℒ³)` bits"):

* `release_grid`, `release_qok`: the value `N = max(0, L c μ̂ − ω)` of `ReleaseNumerical`
  (partIII.tex L215–219) lies on the grid `2^{-regBits} ℤ`, in `[0, 2^{regBits}]`; it is a canonical
  rational of `≤ 4 regBits`-bit numerator and denominator (`QOK`), and its `h_P`-mantissa has
  `< 2 regBits` bits. (The regularized counters `Ẑ(b)` lie on `2^{-(q_b+q_σ)} ℤ`, the subgroup means
  and their lower median on `2^{-(2q_b+2q_σ+5)} ℤ`, `ω/2` too, and the ADA's protected value
  `μ̂ = clip_{[0,1]} round_{h_A}(·)` on `h_A ℤ`, `h_A = 2^{-q_A}`, `q_A ≤ 14ℒ` (`qA_le`).)
* `guardMant_abs_le`: the Step-3 guard mantissas (partIII.tex L488–489) have `≤ regBits` bits.
* `roundMant_leaf_sq`: the Step-2 accumulator mantissa `round_{h_leaf}(Δ²)` (partIII.tex L483) has
  `≤ regBits` bits for `|Δ| ≤ 2U`.

Helpers (the dyadic calculus `DyOK`, every-leaf predicate `AlwaysD` of draw programs, the ADA output
fact `adaNumerical_val`) are in the namespace `F2e2e.C.Space.RegAux`.
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (QOK regBits)

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate the parameters
symbolically and elaboration explodes. -/
attribute [local irreducible] Nat.clog Nat.log

namespace RegAux

/-! ## Dyadic rationals with bounded numerators -/

/-- `x = z / 2^E` for an integer `z` with `|z| ≤ M`. -/
def DyOK (E M : ℕ) (x : ℚ) : Prop := ∃ z : ℤ, |z| ≤ (M : ℤ) ∧ x = (z : ℚ) / 2 ^ E

theorem DyOK.mono {E M M' : ℕ} {x : ℚ} (h : DyOK E M x) (hM : M ≤ M') : DyOK E M' x := by
  obtain ⟨z, hz, rfl⟩ := h
  exact ⟨z, hz.trans (by exact_mod_cast hM), rfl⟩

theorem DyOK.congr_E {E E' M : ℕ} {x : ℚ} (h : DyOK E M x) (hE : E = E') : DyOK E' M x :=
  hE ▸ h

theorem DyOK.lift {E M : ℕ} {x : ℚ} (h : DyOK E M x) (k : ℕ) : DyOK (E + k) (M * 2 ^ k) x := by
  obtain ⟨z, hz, rfl⟩ := h
  refine ⟨z * 2 ^ k, ?_, ?_⟩
  · rw [abs_mul, abs_of_pos (by positivity : (0 : ℤ) < 2 ^ k)]
    push_cast
    exact mul_le_mul_of_nonneg_right hz (by positivity)
  · rw [pow_add]
    push_cast
    rw [mul_div_mul_right _ _ (by positivity : (2 : ℚ) ^ k ≠ 0)]

theorem DyOK.zero (E M : ℕ) : DyOK E M 0 := ⟨0, by simp, by simp⟩

theorem DyOK.add {E M1 M2 : ℕ} {x y : ℚ} (h1 : DyOK E M1 x) (h2 : DyOK E M2 y) :
    DyOK E (M1 + M2) (x + y) := by
  obtain ⟨z1, hz1, rfl⟩ := h1
  obtain ⟨z2, hz2, rfl⟩ := h2
  refine ⟨z1 + z2, ?_, ?_⟩
  · push_cast
    exact (abs_add_le z1 z2).trans (add_le_add hz1 hz2)
  · push_cast
    ring

theorem DyOK.neg {E M : ℕ} {x : ℚ} (h : DyOK E M x) : DyOK E M (-x) := by
  obtain ⟨z, hz, rfl⟩ := h
  exact ⟨-z, by rw [abs_neg]; exact hz, by push_cast; ring⟩

theorem DyOK.sub {E M1 M2 : ℕ} {x y : ℚ} (h1 : DyOK E M1 x) (h2 : DyOK E M2 y) :
    DyOK E (M1 + M2) (x - y) := by
  rw [sub_eq_add_neg]
  exact h1.add h2.neg

theorem DyOK.mul {E1 E2 M1 M2 : ℕ} {x y : ℚ} (h1 : DyOK E1 M1 x) (h2 : DyOK E2 M2 y) :
    DyOK (E1 + E2) (M1 * M2) (x * y) := by
  obtain ⟨z1, hz1, rfl⟩ := h1
  obtain ⟨z2, hz2, rfl⟩ := h2
  refine ⟨z1 * z2, ?_, ?_⟩
  · rw [abs_mul]
    push_cast
    exact mul_le_mul hz1 hz2 (abs_nonneg _) (by positivity)
  · rw [pow_add]
    push_cast
    rw [div_mul_div_comm]

theorem DyOK.max {E M : ℕ} {x y : ℚ} (h1 : DyOK E M x) (h2 : DyOK E M y) :
    DyOK E M (max x y) := by
  rcases le_total x y with h | h
  · rw [max_eq_right h]; exact h2
  · rw [max_eq_left h]; exact h1

theorem DyOK.div_two_pow {E M : ℕ} {x : ℚ} (h : DyOK E M x) (k : ℕ) :
    DyOK (E + k) M (x / 2 ^ k) := by
  obtain ⟨z, hz, rfl⟩ := h
  exact ⟨z, hz, by rw [pow_add, div_div]⟩

theorem DyOK.natCast (n : ℕ) : DyOK 0 n (n : ℚ) := ⟨n, by simp, by simp⟩

theorem DyOK.sum {E M : ℕ} : ∀ {l : List ℚ}, (∀ x ∈ l, DyOK E M x) → DyOK E (l.length * M) l.sum
  | [], _ => by simpa using DyOK.zero E 0
  | x :: l, h => by
    have h1 := h x List.mem_cons_self
    have h2 := DyOK.sum (fun y hy => h y (List.mem_cons_of_mem _ hy))
    rw [List.sum_cons, List.length_cons]
    exact (h1.add h2).mono (le_of_eq (by ring))

theorem DyOK.abs_le {E M : ℕ} {x : ℚ} (h : DyOK E M x) : |x| ≤ M := by
  obtain ⟨z, hz, rfl⟩ := h
  have hpos : (0 : ℚ) < 2 ^ E := by positivity
  rw [abs_div, abs_of_pos hpos]
  calc |(z : ℚ)| / 2 ^ E ≤ |(z : ℚ)| := div_le_self (abs_nonneg _) (one_le_pow₀ (by norm_num))
    _ ≤ M := by exact_mod_cast hz

theorem DyOK.grid {E M : ℕ} {x : ℚ} (h : DyOK E M x) {R : ℕ} (hE : E ≤ R) :
    ∃ m : ℤ, x = (m : ℚ) / 2 ^ R := by
  obtain ⟨z, -, hz⟩ := h.lift (R - E)
  exact ⟨z, by rw [hz, Nat.add_sub_cancel' hE]⟩

theorem DyOK.num_den {E M : ℕ} {x : ℚ} (h : DyOK E M x) : |x.num| ≤ M ∧ (x.den : ℤ) ≤ 2 ^ E := by
  obtain ⟨z, hz, rfl⟩ := h
  have h2 : (0 : ℤ) < 2 ^ E := by positivity
  have e : (z : ℚ) / 2 ^ E = Rat.divInt z (2 ^ E) := by
    rw [Rat.divInt_eq_div]; push_cast; rfl
  rw [e]
  constructor
  · rcases eq_or_ne z 0 with rfl | hz0
    · simp
    · have hd := Int.natAbs_dvd_natAbs.mpr (Rat.num_dvd z (ne_of_gt h2))
      have hle := Nat.le_of_dvd (Int.natAbs_pos.mpr hz0) hd
      calc |(Rat.divInt z (2 ^ E)).num| = ((Rat.divInt z (2 ^ E)).num.natAbs : ℤ) :=
            (Int.natCast_natAbs _).symm
        _ ≤ (z.natAbs : ℤ) := by exact_mod_cast hle
        _ = |z| := Int.natCast_natAbs z
        _ ≤ M := hz
  · exact Int.le_of_dvd h2 (Rat.den_dvd z (2 ^ E))

theorem DyOK.qok {P : StreamParams} {E M : ℕ} {x : ℚ} (h : DyOK E M x) (hE : E ≤ 4 * Impl.regBits P)
    (hM : M ≤ 2 ^ (4 * Impl.regBits P)) : QOK P x := by
  obtain ⟨h1, h2⟩ := h.num_den
  exact ⟨h1.trans (by exact_mod_cast hM), h2.trans (pow_le_pow_right₀ (by norm_num) hE)⟩

theorem DyOK.lowerMedian_of {E M : ℕ} {l : List ℚ} (hl : ∀ x ∈ l, DyOK E M x) :
    DyOK E M (lowerMedian l) := by
  unfold F2e2e.C.Alg.lowerMedian
  rw [List.getD_eq_getElem?_getD]
  cases h : (l.insertionSort (· ≤ ·))[(l.length - 1) / 2]? with
  | none => exact DyOK.zero E M
  | some x =>
    have hx : x ∈ l.insertionSort (· ≤ ·) := List.mem_of_getElem? h
    exact hl x ((List.perm_insertionSort _ _).mem_iff.mp hx)

/-! ## Every-leaf predicate of draw programs and the ADA's protected value -/

/-- Every leaf of a draw program satisfies `Q`. -/
def AlwaysD {P β α : Type} : DrawProg P β α → (α → Prop) → Prop
  | DrawProg.ret a, Q => Q a
  | DrawProg.draw _ k, Q => ∀ b, AlwaysD (k b) Q

theorem AlwaysD.toBits {P β α : Type} (s : P → BitProg β) {Q : α → Prop} :
    ∀ {prog : DrawProg P β α}, AlwaysD prog Q → Always (DrawProg.toBits s prog) Q
  | DrawProg.ret _, h => h
  | DrawProg.draw p _, h => Always.bind_all (fun b => AlwaysD.toBits s (h b)) (s p)

theorem AlwaysD.bind {P β α γ : Type} {Q : α → Prop} {R : γ → Prop} {f : α → DrawProg P β γ}
    (hf : ∀ a, Q a → AlwaysD (f a) R) :
    ∀ {prog : DrawProg P β α}, AlwaysD prog Q → AlwaysD (prog.bind f) R
  | DrawProg.ret a, h => hf a h
  | DrawProg.draw _ _, h => fun b => AlwaysD.bind hf (h b)

theorem AlwaysD.true' {P β α : Type} : ∀ (prog : DrawProg P β α), AlwaysD prog (fun _ => True)
  | DrawProg.ret _ => trivial
  | DrawProg.draw _ k => fun b => AlwaysD.true' (k b)

theorem AlwaysD.bind_all {P β α γ : Type} {R : γ → Prop} {f : α → DrawProg P β γ}
    (hf : ∀ a, AlwaysD (f a) R) (prog : DrawProg P β α) : AlwaysD (prog.bind f) R :=
  AlwaysD.bind (Q := fun _ => True) (fun a _ => hf a) (AlwaysD.true' prog)

/-- `clip_{[0,1]}(h_A n) ∈ h_A ℤ ∩ [0, 1]`. -/
theorem clip_dy (q : ℕ) (n : ℤ) :
    DyOK q (2 ^ q) (clipQ 0 1 ((1 / 2 : ℚ) ^ q * n)) ∧ 0 ≤ clipQ 0 1 ((1 / 2 : ℚ) ^ q * n) := by
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  have e : (1 / 2 : ℚ) ^ q * n = n / 2 ^ q := by rw [one_div_pow]; ring
  rw [e]
  unfold clipQ
  refine ⟨?_, le_max_left _ _⟩
  rcases le_total (n : ℚ) 0 with hn | hn
  · have h0 : (n : ℚ) / 2 ^ q ≤ 0 := div_nonpos_of_nonpos_of_nonneg hn hpos.le
    rw [min_eq_right (h0.trans zero_le_one), max_eq_left h0]
    exact DyOK.zero q _
  · rcases le_total (n : ℚ) (2 ^ q) with hn2 | hn2
    · have h1 : (n : ℚ) / 2 ^ q ≤ 1 := (div_le_one hpos).mpr hn2
      have h0 : 0 ≤ (n : ℚ) / 2 ^ q := div_nonneg hn hpos.le
      rw [min_eq_right h1, max_eq_right h0]
      refine ⟨n, ?_, rfl⟩
      have hn' : (0 : ℤ) ≤ n := by exact_mod_cast hn
      rw [abs_of_nonneg hn']
      exact_mod_cast hn2
    · have h1 : 1 ≤ (n : ℚ) / 2 ^ q := (one_le_div hpos).mpr hn2
      rw [min_eq_left h1, max_eq_right zero_le_one]
      refine ⟨2 ^ q, ?_, ?_⟩
      · rw [abs_of_pos (by positivity)]
        push_cast
        exact le_rfl
      · push_cast
        rw [div_self (ne_of_gt hpos)]

/-- The ADA's protected numerical value lies in `h_A ℤ ∩ [0, 1]` (B's `Numerical`, line [18]:
`clip_{[0,1]} round_{h_A}(μ_0 + Z)`), on every leaf of the draw program. -/
theorem adaNumericalD_val (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    AlwaysD (adaNumericalD A st vals)
      (fun r => ∀ μ, r.1 = AdaNum.val μ → DyOK A.qA (2 ^ A.qA) μ ∧ 0 ≤ μ) := by
  unfold adaNumericalD
  split_ifs
  · intro μ hμ
    simp at hμ
  · refine AlwaysD.bind_all (fun r => ?_) _
    split
    · intro μ hμ
      simp at hμ
    · dsimp only
      refine AlwaysD.bind_all (fun k => ?_) _
      intro μ hμ
      simp only [AdaNum.val.injEq] at hμ
      subst hμ
      exact clip_dy A.qA _

/-- The ADA's protected numerical value, on every path of fresh bits. -/
theorem adaNumerical_val (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals)
      (fun r => ∀ μ, r.1 = AdaNum.val μ → DyOK A.qA (2 ^ A.qA) μ ∧ 0 ≤ μ) :=
  AlwaysD.toBits (adaDraw A) (adaNumericalD_val A st vals)

/-! ## `q_A ≤ 14ℒ` -/

theorem foldl_max_le_sum : ∀ (l : List ℕ) (a : ℕ), l.foldl max a ≤ a + l.sum
  | [], a => by simp
  | x :: l, a => by
    rw [List.foldl_cons, List.sum_cons]
    have h1 := foldl_max_le_sum l (max a x)
    have h2 : max a x ≤ a + x := max_le (Nat.le_add_right _ _) (Nat.le_add_left _ _)
    omega

end RegAux

open RegAux

/-- The lattice exponent of the bank ADA instance: `h_A = 2^{-q_A}` with `q_A ≤ 14ℒ` (from
`q_A = max(29 + e_A + ⌈log₂(p(p+1)χ)⌉, 20 + ⌈log₂ max_j n_j⌉)`, B's `adaQA`). -/
theorem qA_le (P : StreamParams) : (bankAda P).qA ≤ 14 * P.calL := by
  have hL := hundred_le_calL P
  have hA4 : 4 ≤ P.eBankA := by unfold StreamParams.eBankA; omega
  have hAle := eBankA_le P
  have hXle := eBankXi_le P
  have hcl := clog_bank_caps_le P
  have hp := B.adaP_le_of_four_le hA4
  have hchi := B.adaChi_le_of_four_le P.m P.Jmax P.Rmax P.eBankXi hA4
  have hsum := (adaRows_le P).1
  have hEta := eEta_le P
  have h4 := pow_four_le_two_pow (k := P.calL) (by omega)
  have hq : (bankAda P).qA = B.adaQA P.m P.Jmax P.Rmax P.eBankA P.eBankXi := rfl
  have hbs : (bankAda P).blockSizes = B.adaBlockSizes P.m P.Jmax P.Rmax P.eBankA P.eBankXi := rfl
  rw [hq]
  unfold B.adaQA
  apply max_le
  · have hL3 : P.calL ^ 3 ≤ 2 ^ P.calL :=
      le_trans (Nat.pow_le_pow_right (by omega) (by norm_num)) h4
    have hprod : B.adaP P.eBankA * (B.adaP P.eBankA + 1) *
        B.adaChi P.m P.Jmax P.Rmax P.eBankA P.eBankXi ≤ 2 ^ (2 * P.calL) := by
      have hp' : B.adaP P.eBankA ≤ 13 * P.calL := by omega
      have hp1 : B.adaP P.eBankA + 1 ≤ 13 * P.calL := by omega
      have hc' : B.adaChi P.m P.Jmax P.Rmax P.eBankA P.eBankXi ≤ 57 * P.calL := by omega
      calc _ ≤ (13 * P.calL) * (13 * P.calL) * (57 * P.calL) :=
            Nat.mul_le_mul (Nat.mul_le_mul hp' hp1) hc'
        _ = 9633 * P.calL ^ 3 := by ring
        _ ≤ 2 ^ 14 * 2 ^ P.calL := Nat.mul_le_mul (by norm_num) hL3
        _ = 2 ^ (14 + P.calL) := by rw [← pow_add]
        _ ≤ 2 ^ (2 * P.calL) := Nat.pow_le_pow_right (by norm_num) (by omega)
    have := clog_two_le_of_le_two_pow hprod
    omega
  · have hmax : B.adaMaxN P.m P.Jmax P.Rmax P.eBankA P.eBankXi ≤ (bankAda P).blockSizes.sum := by
      unfold B.adaMaxN
      rw [hbs]
      have := foldl_max_le_sum (B.adaBlockSizes P.m P.Jmax P.Rmax P.eBankA P.eBankXi) 0
      omega
    have hL7 : P.calL ^ 7 ≤ 2 ^ (2 * P.calL) := by
      calc P.calL ^ 7 ≤ P.calL ^ 8 := Nat.pow_le_pow_right (by omega) (by norm_num)
        _ = (P.calL ^ 4) ^ 2 := by ring
        _ ≤ (2 ^ P.calL) ^ 2 := Nat.pow_le_pow_left h4 2
        _ = 2 ^ (2 * P.calL) := by rw [← pow_mul, mul_comm]
    have hS : (bankAda P).blockSizes.sum ≤ 2 ^ (199 + 2 * P.eEta + 2 * P.calL) := by
      calc _ ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * P.calL ^ 7 := hsum
        _ ≤ 2 ^ 199 * 2 ^ (2 * P.eEta) * 2 ^ (2 * P.calL) := Nat.mul_le_mul_left _ hL7
        _ = 2 ^ (199 + 2 * P.eEta + 2 * P.calL) := by rw [← pow_add, ← pow_add]
    have := clog_two_le_of_le_two_pow (hmax.trans hS)
    omega


/-! ## The value of `ReleaseNumerical` -/

namespace RegAux

theorem zSat_eq (P : StreamParams) : zSat P = 2 ^ (P.eZmax + P.eHb) := by
  unfold zSat StreamParams.Zmax
  push_cast
  rw [pow_add]

theorem rowSign_abs_le (P : StreamParams) (r : Row) (i : ℕ) : |rowSign P r i| ≤ 1 := by
  unfold rowSign
  split <;> simp

/-- A regularized counter `X ± σ` (partIII.tex L208) with `|X| ≤ 2 Z_max/h_b`. -/
theorem regZ_dy_aux {P : StreamParams} {cnt sgn : ℤ} (hcnt : |cnt| ≤ 2 * zSat P)
    (hs : |sgn| ≤ 1) :
    DyOK (P.eHb + P.eSigma) (2 ^ (P.eZmax + P.eHb + P.eSigma + 2))
      (gridVal P.eHb cnt + (sgn : ℚ) * P.sigma) := by
  have h1 : DyOK P.eHb (2 ^ (P.eZmax + P.eHb + 1)) (gridVal P.eHb cnt) := by
    refine ⟨cnt, ?_, rfl⟩
    rw [zSat_eq] at hcnt
    push_cast
    calc |cnt| ≤ 2 * 2 ^ (P.eZmax + P.eHb) := hcnt
      _ = 2 ^ (P.eZmax + P.eHb + 1) := by ring
  have h2 : DyOK P.eSigma 1 ((sgn : ℚ) * P.sigma) := by
    refine ⟨sgn, by exact_mod_cast hs, ?_⟩
    unfold StreamParams.sigma
    rw [one_div_pow]
    ring
  have h1' := h1.lift P.eSigma
  have h2' := (h2.lift P.eHb).congr_E (Nat.add_comm P.eSigma P.eHb)
  refine (h1'.add h2').mono ?_
  have e1 : 2 ^ (P.eZmax + P.eHb + 1) * 2 ^ P.eSigma = 2 ^ (P.eZmax + P.eHb + P.eSigma + 1) := by
    rw [← pow_add]; congr 1; ring
  have e2 : 2 ^ (P.eZmax + P.eHb + P.eSigma + 2) = 2 * 2 ^ (P.eZmax + P.eHb + P.eSigma + 1) := by
    rw [pow_succ]; ring
  have h3 : 1 * 2 ^ P.eHb ≤ 2 ^ (P.eZmax + P.eHb + P.eSigma + 1) := by
    rw [one_mul]; exact Nat.pow_le_pow_right (by norm_num) (by omega)
  rw [e1, e2]
  omega

/-- The regularized counter of a stored row (partIII.tex L208, eqs. `R:eq:unscaled-regularizer-counter`,
`R:eq:difference-counter-def`). -/
theorem regZ_dy {P : StreamParams} (mode : Mode) {r : Row} (hr : RowOK P r) :
    DyOK (P.eHb + P.eSigma) (2 ^ (P.eZmax + P.eHb + P.eSigma + 2)) (regZ P mode r) := by
  have hz := Aux.zSat_nonneg P
  have hX := hr.abs_X_le
  have hY := hr.abs_Y_le
  cases mode
  · show DyOK _ _ (gridVal P.eHb r.X + (rowSign P r P.Dstar : ℚ) * P.sigma)
    exact regZ_dy_aux (by linarith) (rowSign_abs_le P r P.Dstar)
  · show DyOK _ _ (gridVal P.eHb (r.X - r.Y) + (rowSign P r P.Dstar : ℚ) * P.sigma)
    refine regZ_dy_aux ?_ (rowSign_abs_le P r P.Dstar)
    rw [abs_sub_le_iff]
    constructor <;> linarith [le_abs_self r.X, neg_abs_le r.X, le_abs_self r.Y, neg_abs_le r.Y]

/-- A subgroup mean of `32` squared regularized counters (partIII.tex L217). -/
theorem subgroupMean_dy {P : StreamParams} (mode : Mode) {sub : List Row} (hlen : sub.length = 32)
    (hrows : ∀ r ∈ sub, RowOK P r) :
    DyOK (2 * (P.eHb + P.eSigma) + 5) (2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5))
      (subgroupMean P mode sub) := by
  have hsq : ∀ x ∈ sub.map (fun r => regZ P mode r ^ 2),
      DyOK (2 * (P.eHb + P.eSigma)) (2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2))) x := by
    intro x hx
    rw [List.mem_map] at hx
    obtain ⟨r, hr, rfl⟩ := hx
    have h := (regZ_dy mode (hrows r hr)).mul (regZ_dy mode (hrows r hr))
    rw [sq]
    exact (h.congr_E (by ring)).mono (le_of_eq (by rw [← pow_add]; congr 1; ring))
  have hs := DyOK.sum hsq
  rw [List.length_map, hlen] at hs
  unfold subgroupMean
  rw [show (32 : ℚ) = 2 ^ 5 by norm_num]
  exact (hs.div_two_pow 5).mono (le_of_eq (by rw [pow_add]; ring))

theorem omega_dy (P : StreamParams) : DyOK (2 * P.eSigma) 1 P.omega := by
  refine ⟨1, by norm_num, ?_⟩
  unfold StreamParams.omega StreamParams.sigma
  rw [← pow_mul, one_div_pow]
  push_cast
  ring_nf

theorem omega_half_dy (P : StreamParams) :
    DyOK (2 * (P.eHb + P.eSigma) + 5) (2 ^ (2 * P.eHb + 4)) (P.omega / 2) := by
  have h : DyOK (2 * P.eSigma + 1) 1 (P.omega / 2) := by
    have := (omega_dy P).div_two_pow 1
    rwa [pow_one] at this
  exact ((h.lift (2 * P.eHb + 4)).congr_E (by ring)).mono (le_of_eq (one_mul _))

/-- `N = max(0, L c μ̂ − ω)` (partIII.tex L219) for `c` and `μ̂` on their grids. -/
theorem release_N_dy {P : StreamParams} {c μ : ℚ}
    (hc : DyOK (2 * (P.eHb + P.eSigma) + 5) (2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5)) c)
    (hμ : DyOK (bankAda P).qA (2 ^ (bankAda P).qA) μ) :
    DyOK (2 * (P.eHb + P.eSigma) + 5 + (bankAda P).qA)
      (P.L * 2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5) * 2 ^ (bankAda P).qA +
        2 ^ (2 * P.eHb + 5 + (bankAda P).qA))
      (max 0 ((P.L : ℚ) * c * μ - P.omega)) := by
  have h1 := ((DyOK.natCast P.L).mul hc).mul hμ
  have h1' := h1.congr_E (by ring : 0 + (2 * (P.eHb + P.eSigma) + 5) + (bankAda P).qA =
    2 * (P.eHb + P.eSigma) + 5 + (bankAda P).qA)
  have h2 := ((omega_dy P).lift (2 * P.eHb + 5 + (bankAda P).qA)).congr_E
    (by ring : 2 * P.eSigma + (2 * P.eHb + 5 + (bankAda P).qA) =
      2 * (P.eHb + P.eSigma) + 5 + (bankAda P).qA)
  exact (DyOK.zero _ _).max ((h1'.sub h2).mono (le_of_eq (by ring)))

theorem cube_facts (P : StreamParams) :
    100 ≤ P.calL ∧ P.calL ≤ P.calL ^ 3 ∧ P.calL ^ 2 ≤ P.calL ^ 3 ∧ 100 ≤ P.calL ^ 3 := by
  have hL := hundred_le_calL P
  have h1 : P.calL ≤ P.calL ^ 3 := Nat.le_self_pow (by norm_num) _
  exact ⟨hL, h1, Nat.pow_le_pow_right (by omega) (by norm_num), le_trans hL h1⟩

theorem regBits_eq (P : StreamParams) : Impl.regBits P = 128 * P.calL ^ 3 := by
  show 2 ^ 7 * P.calL ^ 3 = 128 * P.calL ^ 3
  norm_num

theorem EN_le (P : StreamParams) : 2 * (P.eHb + P.eSigma) + 5 + (bankAda P).qA ≤ Impl.regBits P := by
  have h1 := eHb_le P
  have h2 := eSigma_le P
  have h3 := qA_le P
  obtain ⟨_, hc1, _, hc3⟩ := cube_facts P
  rw [regBits_eq]
  omega

theorem Mn_le (P : StreamParams) :
    P.L * 2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5) * 2 ^ (bankAda P).qA +
      2 ^ (2 * P.eHb + 5 + (bankAda P).qA) ≤ 2 ^ Impl.regBits P := by
  have h1 := eHb_le P
  have h2 := eSigma_le P
  have h3 := qA_le P
  have h4 := eZmax_le P
  have h5 := s_le P
  obtain ⟨_, hc1, _, hc3⟩ := cube_facts P
  have hLs : P.L ≤ 2 ^ (48 * P.calL) := by
    have hLdef : P.L = 16 * P.s := rfl
    calc P.L ≤ 2 ^ P.L := (Nat.lt_two_pow_self (n := P.L)).le
      _ ≤ 2 ^ (48 * P.calL) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hA : P.L * 2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5) * 2 ^ (bankAda P).qA ≤
      2 ^ (127 * P.calL ^ 3) := by
    calc _ ≤ 2 ^ (48 * P.calL) * 2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5) *
          2 ^ (bankAda P).qA := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hLs)
      _ = 2 ^ (48 * P.calL + (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5) + (bankAda P).qA) := by
          rw [← pow_add, ← pow_add]
      _ ≤ 2 ^ (127 * P.calL ^ 3) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hB : 2 ^ (2 * P.eHb + 5 + (bankAda P).qA) ≤ 2 ^ (127 * P.calL ^ 3) :=
    Nat.pow_le_pow_right (by norm_num) (by omega)
  calc _ ≤ 2 ^ (127 * P.calL ^ 3) + 2 ^ (127 * P.calL ^ 3) := Nat.add_le_add hA hB
    _ = 2 ^ (127 * P.calL ^ 3 + 1) := by rw [pow_succ]; ring
    _ ≤ 2 ^ Impl.regBits P := Nat.pow_le_pow_right (by norm_num) (by rw [regBits_eq]; omega)

end RegAux

/-- **The value of `ReleaseNumerical`** (partIII.tex L215–219), on every path of fresh bits: `N` lies on
the grid `2^{-regBits} ℤ`, in `[0, 2^{regBits}]`. (No hypothesis on the ADA state is needed: its
protected value always lies in `h_A ℤ ∩ [0, 1]`.) -/
theorem release_grid {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (hB : BankOK P adaOK B) (mode : Mode) :
    Always (B.release P mode) (fun r => ∀ N, r.1 = some N →
      0 ≤ N ∧ N ≤ 2 ^ Impl.regBits P ∧ ∃ m : ℤ, N = (m : ℚ) / 2 ^ Impl.regBits P) := by
  unfold Bank.release
  split
  · intro N hN
    simp at hN
  · rename_i grp rest hco
    have hg : grp ∈ B.coarse := by rw [hco]; exact List.mem_cons_self
    have hmeans : ∀ x ∈ grp.map (subgroupMean P mode),
        DyOK (2 * (P.eHb + P.eSigma) + 5) (2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5)) x := by
      intro x hx
      rw [List.mem_map] at hx
      obtain ⟨sub, hsub, rfl⟩ := hx
      exact subgroupMean_dy mode ((hB.coarse_shape grp hg).2 sub hsub)
        (fun r hr => hB.coarse_rows grp hg sub hsub r hr)
    have hom : DyOK (2 * (P.eHb + P.eSigma) + 5)
        (2 ^ (2 * (P.eZmax + P.eHb + P.eSigma + 2) + 5)) (P.omega / 2) :=
      (omega_half_dy P).mono (Nat.pow_le_pow_right (by norm_num) (by omega))
    have hc := (DyOK.lowerMedian_of hmeans).max hom
    simp only [bp_bind_eq, bp_pure_eq]
    refine Always.bind (fun res hres => ?_) (adaNumerical_val (bankAda P) B.adaSt _)
    split
    · rename_i μ hμ
      intro N hN
      simp only [Option.some.injEq] at hN
      subst hN
      have hN := release_N_dy hc (hres μ hμ).1
      refine ⟨le_max_left _ _, ?_, hN.grid (EN_le P)⟩
      exact (le_abs_self _).trans (hN.abs_le.trans (by exact_mod_cast Mn_le P))
    · intro N hN
      simp at hN

/-- The value of `ReleaseNumerical` is a canonical rational of `≤ 4 regBits` bits (`QOK`, the
precondition of the W5 routines), nonnegative, and its `h_P`-mantissa has `< 2 regBits` bits. -/
theorem release_qok {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (hB : BankOK P adaOK B) (mode : Mode) :
    Always (B.release P mode) (fun r => ∀ N, r.1 = some N →
      QOK P N ∧ 0 ≤ N ∧ |roundMant P.eHP N| < 2 ^ (2 * Impl.regBits P)) := by
  refine Always.mono (fun r h N hN => ?_) (release_grid hB mode)
  obtain ⟨h0, h1, m, hm⟩ := h N hN
  have hR := RegAux.regBits_eq P
  obtain ⟨_, hc1, hc2, hc3⟩ := RegAux.cube_facts P
  have heHP := eHP_le P
  have hpos : (0 : ℚ) < 2 ^ Impl.regBits P := by positivity
  have hmq : (m : ℚ) = N * 2 ^ Impl.regBits P := by rw [hm]; field_simp
  have hm0 : (0 : ℤ) ≤ m := by
    have : (0 : ℚ) ≤ m := by rw [hmq]; positivity
    exact_mod_cast this
  have hm1 : (m : ℚ) ≤ 2 ^ (2 * Impl.regBits P) := by
    rw [hmq, two_mul, pow_add]
    exact mul_le_mul_of_nonneg_right h1 hpos.le
  have hdy : DyOK (Impl.regBits P) (2 ^ (2 * Impl.regBits P)) N :=
    ⟨m, by rw [abs_of_nonneg hm0]; exact_mod_cast hm1, hm⟩
  refine ⟨hdy.qok (by omega) (Nat.pow_le_pow_right (by norm_num) (by omega)), h0, ?_⟩
  unfold roundMant
  have hr0 : (0 : ℤ) ≤ ⌊N * 2 ^ P.eHP + 1 / 2⌋ := Int.floor_nonneg.mpr (by positivity)
  have hr1 : ((⌊N * 2 ^ P.eHP + 1 / 2⌋ : ℤ) : ℚ) ≤ N * 2 ^ P.eHP + 1 / 2 := Int.floor_le _
  rw [abs_of_nonneg hr0]
  have hlt : ((⌊N * 2 ^ P.eHP + 1 / 2⌋ : ℤ) : ℚ) < 2 ^ (2 * Impl.regBits P) := by
    have hE : Impl.regBits P + P.eHP ≤ 2 * Impl.regBits P - 1 := by omega
    have e : (2 : ℚ) ^ (2 * Impl.regBits P) = 2 * 2 ^ (2 * Impl.regBits P - 1) := by
      rw [← pow_succ']; congr 1; omega
    have h2 : N * 2 ^ P.eHP ≤ 2 ^ (2 * Impl.regBits P - 1) := by
      calc N * 2 ^ P.eHP ≤ 2 ^ Impl.regBits P * 2 ^ P.eHP :=
            mul_le_mul_of_nonneg_right h1 (by positivity)
        _ = 2 ^ (Impl.regBits P + P.eHP) := by rw [pow_add]
        _ ≤ 2 ^ (2 * Impl.regBits P - 1) := pow_le_pow_right₀ (by norm_num) hE
    have h3 : (1 : ℚ) ≤ 2 ^ (2 * Impl.regBits P - 1) := one_le_pow₀ (by norm_num)
    rw [e]
    linarith
  exact_mod_cast hlt

/-! ## The Step-3 guard mantissas -/

namespace RegAux

theorem guardMant_le (Cint α e : ℤ) :
    0 ≤ guardMant Cint α e ∧
      (guardMant Cint α e : ℚ) ≤ 4 * ((Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e)) + 1 := by
  have hy0 : (0 : ℚ) ≤ (Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e) := by positivity
  unfold guardMant
  dsimp only
  split_ifs with h
  · exact ⟨le_rfl, by push_cast; linarith⟩
  · refine ⟨by positivity, ?_⟩
    set y2 : ℚ := (Cint : ℚ) ^ 2 * (2 : ℚ) ^ (2 * α + e) with hy2
    have hfl : (0 : ℤ) ≤ ⌊4 * y2⌋ := Int.floor_nonneg.mpr (by linarith)
    have h3 : ((⌊4 * y2⌋.toNat : ℕ) : ℚ) ≤ 4 * y2 := by
      have e1 : ((⌊4 * y2⌋.toNat : ℕ) : ℚ) = ((⌊4 * y2⌋ : ℤ) : ℚ) := by
        rw [← Int.cast_natCast, Int.toNat_of_nonneg hfl]
      rw [e1]
      exact Int.floor_le _
    have h2 : (floorSqrtQ (4 * y2) : ℚ) ≤ 4 * y2 := by
      unfold floorSqrtQ
      exact le_trans (by exact_mod_cast Nat.sqrt_le_self _) h3
    have h1 : (((floorSqrtQ (4 * y2) + 1) / 2 : ℕ) : ℚ) ≤ floorSqrtQ (4 * y2) + 1 := by
      exact_mod_cast Nat.div_le_self _ _
    rw [Int.cast_natCast]
    linarith

theorem eU_le (P : StreamParams) {d : ℕ} (hd : d < P.H) : P.eU d ≤ 4 * P.calL ^ 3 + 1 := by
  have hV := Vd_le_calL P hd.le
  unfold StreamParams.eU
  apply clog_two_le_of_le_two_pow
  calc 2 * P.Vd d ^ 2 ≤ 2 * (2 ^ (2 * P.calL ^ 3)) ^ 2 :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hV 2)
    _ = 2 ^ (4 * P.calL ^ 3 + 1) := by rw [← pow_mul, ← pow_succ']; congr 1; ring

end RegAux

/-- **The Step-3 guard mantissas** (partIII.tex L488–489) have at most `regBits` bits. -/
theorem guardMant_abs_le {P : StreamParams} {L : Learner} (hL : LearnerOK P 4 L) {d : ℕ}
    (hd : d < P.H) :
    |guardMant L.tag (guardAlpha P) ((P.eU d : ℤ) - (L.epoch : ℤ))| ≤ 2 ^ Impl.regBits P := by
  obtain ⟨h0, h1⟩ :=
    RegAux.guardMant_le L.tag (guardAlpha P) ((P.eU d : ℤ) - (L.epoch : ℤ))
  rw [abs_of_nonneg h0]
  have htag : (L.tag : ℚ) ≤ 2 ^ (P.eCmax + P.eHC + 2) := by
    have h := hL.tag_le
    have e : ((4 : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) = 2 ^ (P.eCmax + P.eHC + 2) := by
      unfold StreamParams.Cmax
      push_cast
      ring
    rw [e] at h
    exact_mod_cast h
  have hexp : 2 * guardAlpha P + ((P.eU d : ℤ) - (L.epoch : ℤ)) ≤
      ((2 * P.eHg + P.eU d : ℕ) : ℤ) := by
    unfold guardAlpha
    push_cast
    omega
  have hz : (2 : ℚ) ^ (2 * guardAlpha P + ((P.eU d : ℤ) - (L.epoch : ℤ))) ≤
      2 ^ (2 * P.eHg + P.eU d) := by
    calc _ ≤ (2 : ℚ) ^ (((2 * P.eHg + P.eU d : ℕ) : ℤ)) := zpow_le_zpow_right₀ (by norm_num) hexp
      _ = 2 ^ (2 * P.eHg + P.eU d) := zpow_natCast _ _
  have htag0 : (0 : ℚ) ≤ L.tag := by exact_mod_cast hL.tag_nonneg
  have hy : (L.tag : ℚ) ^ 2 * 2 ^ (2 * guardAlpha P + ((P.eU d : ℤ) - (L.epoch : ℤ))) ≤
      (2 ^ (P.eCmax + P.eHC + 2)) ^ 2 * 2 ^ (2 * P.eHg + P.eU d) :=
    mul_le_mul (pow_le_pow_left₀ htag0 htag 2) hz (by positivity) (by positivity)
  have hK : 2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d) + 3 ≤ Impl.regBits P := by
    have h1 := eCmax_le P
    have h2 := eHC_le P
    have h3 := eHg_le P
    have h4 := RegAux.eU_le P hd
    obtain ⟨_, _, hc2, hc3⟩ := RegAux.cube_facts P
    rw [RegAux.regBits_eq]
    omega
  have hq : (guardMant L.tag (guardAlpha P) ((P.eU d : ℤ) - (L.epoch : ℤ)) : ℚ) ≤
      2 ^ Impl.regBits P := by
    have e3a : ((2 : ℚ) ^ (P.eCmax + P.eHC + 2)) ^ 2 * 2 ^ (2 * P.eHg + P.eU d) =
        2 ^ (2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d)) := by
      rw [← pow_mul, ← pow_add, mul_comm (P.eCmax + P.eHC + 2) 2]
    have e3b : (2 : ℚ) ^ (2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d) + 3) =
        8 * 2 ^ (2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d)) := by
      rw [pow_add]; ring
    have h4 : (1 : ℚ) ≤ 2 ^ (2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d)) :=
      one_le_pow₀ (by norm_num)
    calc _ ≤ 4 * ((L.tag : ℚ) ^ 2 * 2 ^ (2 * guardAlpha P + ((P.eU d : ℤ) - (L.epoch : ℤ)))) + 1 :=
          h1
      _ ≤ 4 * ((2 ^ (P.eCmax + P.eHC + 2)) ^ 2 * 2 ^ (2 * P.eHg + P.eU d)) + 1 := by linarith
      _ ≤ 2 ^ (2 * (P.eCmax + P.eHC + 2) + (2 * P.eHg + P.eU d) + 3) := by
          rw [e3a, e3b]; linarith
      _ ≤ 2 ^ Impl.regBits P := pow_le_pow_right₀ (by norm_num) hK
  exact_mod_cast hq

/-! ## The Step-2 accumulator -/

/-- The Step-2 accumulator mantissa `round_{h_leaf}(Δ²) = Δ² / h_leaf` (partIII.tex L483) has at most
`regBits` bits for `|Δ| ≤ 2U`. -/
theorem roundMant_leaf_sq {P : StreamParams} {Δ : ℤ} (hΔ : |Δ| ≤ 2 * (P.U : ℤ)) :
    |roundMant P.eHleaf ((Δ : ℚ) ^ 2)| ≤ 2 ^ Impl.regBits P := by
  have e : roundMant P.eHleaf ((Δ : ℚ) ^ 2) = Δ ^ 2 * 2 ^ P.eHleaf := by
    unfold roundMant
    rw [show (Δ : ℚ) ^ 2 * 2 ^ P.eHleaf + 1 / 2 = ((Δ ^ 2 * 2 ^ P.eHleaf : ℤ) : ℚ) + 1 / 2 by
      push_cast; ring]
    rw [Int.floor_intCast_add]
    have : ⌊(1 / 2 : ℚ)⌋ = 0 := Int.floor_eq_iff.mpr ⟨by norm_num, by norm_num⟩
    rw [this, add_zero]
  rw [e, abs_mul, abs_pow, abs_of_pos (by positivity : (0 : ℤ) < 2 ^ P.eHleaf)]
  have hU : (P.U : ℤ) + 2 ≤ 2 ^ P.calL := by
    have h1 := prod_le_two_pow_cP P
    have h2 := cP_add_hundred_le P
    have h3 : P.U + 2 ≤ 2 ^ cP P :=
      le_trans (Nat.le_mul_of_pos_left _ (by positivity)) h1
    have h4 : 2 ^ cP P ≤ 2 ^ P.calL := Nat.pow_le_pow_right (by norm_num) (by omega)
    exact_mod_cast h3.trans h4
  have hΔ' : |Δ| ≤ 2 ^ (P.calL + 1) := by rw [pow_succ]; linarith
  have hleaf := eHleaf_le P
  obtain ⟨_, hc1, hc2, hc3⟩ := RegAux.cube_facts P
  have hK : 2 * (P.calL + 1) + P.eHleaf ≤ Impl.regBits P := by
    rw [RegAux.regBits_eq]; omega
  calc |Δ| ^ 2 * 2 ^ P.eHleaf ≤ (2 ^ (P.calL + 1)) ^ 2 * 2 ^ P.eHleaf := by
        gcongr
    _ = 2 ^ (2 * (P.calL + 1) + P.eHleaf) := by ring
    _ ≤ 2 ^ Impl.regBits P := pow_le_pow_right₀ (by norm_num) hK

end F2e2e.C.Space
