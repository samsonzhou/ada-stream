import Mathlib
import F2e2e.C.ClosureInv
import F2e2e.C.ClosureOrcStepAux

/-!
# Theorem 6.4, oracle counting: labels, call counts and coverage (proofs: C-ORC; statements: C-CLOSE)

Source: `parts/partIII.tex` Theorem 5.11 (2c) (L942–949: "a Regularized Norm Bank `𝓑_d` serving at most two
sequential depth-`(d+1)` child lifetimes experiences at most `J ≤ 2J_* = J_max` rejections and at most
`R ≤ 2(2J_*+1) = 4J_*+2 = R_max` numerical requests, never exhausting its caps"), Definition
`R:def:binary-tree-architecture` (1) (dyadic lifetimes, `F2e2e.C.Alg.bornAt`), the coverage clause of Theorem 3.6
(B's `coreCovered`: at most `M = m` interval requests, at most `J` earlier rejections, at most `R` numerical
requests), and the operation count of Lemma 6.1 (iv) (`< T` operations).

`CountPart P ph c g` (with the tree shadow `S = shadowOf P g`):
* labels: bank `0` is the root bank `(0,0)`, bank `idx ≥ 1` the outgoing bank of depth `idx − 1` born with it,
  label `(t_birth(idx−1), idx−1)`; every logged call is on a live label or on a label of an earlier round
  (freshness of new labels);
* per-label counts on the call log (`nInt`, `nRej`, `nNum`, `F2e2e/C/ClosureBank.lean`): interval requests at most
  one per round; rejections and numerical requests bounded by the learner's lifetime counter `J_used` plus the
  budget of an earlier child lifetime of the same bank (at most one, by the dyadic schedule);
* the birth rounds `S.tb d` are the last scheduled births;
* the number of analysis events: at most `3H + 2` per round.

Each block lemma is pure: the ghost / controller data after the block are given by field equations (only
`labels`, `calls`, `events` of the ghost and the learners' `jUsed` matter).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Definitions (fixed by C-CLOSE) -/

/-- Depth `idx` has been evaluated in the current round (Step 4 done for it). -/
def evaluated : Tree.Phase → ℕ → Bool
  | .evals D, idx => decide (D ≤ idx)
  | .idle, _ => true
  | _, _ => false

/-- The analysis events still to come in the current round, by moment: births of the depths `D, …, H−1`, the
physical update, the `H` guards, the `H` evaluations. -/
def remEv (H : ℕ) : Tree.Phase → ℕ
  | .births D => (H - D) + 1 + 2 * H
  | .guards D => (H - D) + H
  | .evals D => D
  | .idle => 0

/-- Bank `idx` serves its first (or only) child lifetime: the root bank, or the client `idx` was born with the
bank (`t_birth(idx) = t_birth(idx − 1)`). -/
def firstLife (S : Tree.TreeSt P) (idx : ℕ) : Bool := idx == 0 || S.tb idx == S.tb (idx - 1)

/-- **The counting part of the chronological invariant** at the moment `ph`. -/
structure CountPart (P : StreamParams) (ph : Tree.Phase) (c : CState) (g : Ghost) : Prop where
  /-- the live banks `0, …, min(live, H−1)` -/
  nLab : g.labels.length = min (ph.live P.H) (P.H - 1) + 1
  /-- the root bank -/
  label0 : g.labelAt 0 = (0, 0)
  /-- the outgoing bank of depth `idx − 1`, born with it -/
  labelSucc : ∀ idx, 1 ≤ idx → idx < g.labels.length →
    g.labelAt idx = ((shadowOf P g).tb (idx - 1), idx - 1)
  /-- every logged call is on a live label or on a label of an earlier round -/
  fresh : ∀ rec ∈ g.calls, rec.lab ∈ g.labels ∨ rec.lab.1 < (shadowOf P g).t
  /-- at most one interval request per bank and round (Step 4 validates bank `d` once, at depth `d`) -/
  cntInt : ∀ idx < g.labels.length,
    nInt (g.labelAt idx) g.calls + (if evaluated ph idx then 0 else 1) ≤ (shadowOf P g).t
  /-- the bank of a live client: Theorem 5.11 (2c) -/
  cntLive : ∀ idx < g.labels.length, idx < ph.live P.H →
    nRej (g.labelAt idx) g.calls ≤
        (c.learners.getD idx dfltLearner).jUsed + (if firstLife (shadowOf P g) idx then 0 else P.Jstar) ∧
      nNum (g.labelAt idx) g.calls ≤
        2 * (c.learners.getD idx dfltLearner).jUsed +
          (if firstLife (shadowOf P g) idx then 0 else 2 * P.Jstar + 1)
  /-- the bank of a client not (yet) born in this round: at most one finished child lifetime; nothing if the bank
  was born in this round (or is the root bank) -/
  cntNew : ∀ idx < g.labels.length, ph.live P.H ≤ idx →
    nRej (g.labelAt idx) g.calls ≤ P.Jstar ∧ nNum (g.labelAt idx) g.calls ≤ 2 * P.Jstar ∧
      (idx = 0 ∨ (shadowOf P g).tb (idx - 1) = (shadowOf P g).t →
        nRej (g.labelAt idx) g.calls = 0 ∧ nNum (g.labelAt idx) g.calls = 0)
  /-- the birth rounds are the last scheduled births (rounds are `≥ 1`) -/
  tbLast : ∀ d < ph.live P.H, 1 ≤ (shadowOf P g).tb d ∧ bornAt P.H d ((shadowOf P g).tb d) = true ∧
    ∀ r, (shadowOf P g).tb d < r → r ≤ (shadowOf P g).t → bornAt P.H d r = false
  /-- at most `3H + 2` analysis events per round -/
  nev : g.events.length + remEv P.H ph ≤ (3 * P.H + 2) * (shadowOf P g).t

/-! ## Elementary facts (C-ORC) -/

theorem evaluated_births (D idx : ℕ) : evaluated (.births D) idx = false := rfl

theorem evaluated_guards (D idx : ℕ) : evaluated (.guards D) idx = false := rfl

theorem evaluated_evals (D idx : ℕ) : evaluated (.evals D) idx = decide (D ≤ idx) := rfl

theorem evaluated_idle (idx : ℕ) : evaluated .idle idx = true := rfl

theorem firstLife_iff (S : Tree.TreeSt P) (idx : ℕ) :
    firstLife S idx = true ↔ idx = 0 ∨ S.tb idx = S.tb (idx - 1) := by
  unfold firstLife
  simp

theorem bankAda_M : (bankAda P).M = P.m := rfl

theorem bankAda_J : (bankAda P).J = 2 * P.Jstar := rfl

theorem bankAda_R : (bankAda P).R = 4 * P.Jstar + 2 := rfl

/-- Appending a learner with `J_used = 0` (a new learner) changes no lifetime counter `getD`. -/
theorem getD_append_jUsed (l : List Learner) (x : Learner) (hx : x.jUsed = 0) (idx : ℕ) :
    ((l ++ [x]).getD idx dfltLearner).jUsed = (l.getD idx dfltLearner).jUsed := by
  rcases Nat.lt_or_ge idx l.length with hlt | hge
  · rw [List.getD_append _ _ _ _ hlt]
  · rw [List.getD_append_right _ _ _ _ hge, List.getD_eq_default _ _ hge]
    rcases Nat.eq_or_lt_of_le hge with heq | hlt
    · rw [← heq, Nat.sub_self]
      simp [hx, dfltLearner]
    · rw [List.getD_eq_default _ _ (by simp; omega)]

/-- Truncating the learners keeps the lifetime counters of the remaining depths. -/
theorem getD_take_jUsed (l : List Learner) (n idx : ℕ) (h : idx < n) :
    ((l.take n).getD idx dfltLearner).jUsed = (l.getD idx dfltLearner).jUsed := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take, if_pos h]

/-! ## Consequences of the invariant (C-ORC) -/

namespace CountPart

variable {ph : Tree.Phase} {c : CState} {g : Ghost}

theorem len_births {D : ℕ} (h : CountPart P (.births D) c g) (hD : D < P.H) : g.labels.length = D + 1 := by
  have := h.nLab
  simp only [Tree.Phase.live] at this
  omega

theorem len_full (h : CountPart P ph c g) (hph : ph.live P.H = P.H) : g.labels.length = P.H := by
  have := h.nLab
  have := P.one_le_H
  rw [hph] at *
  omega

theorem labelAt_eq (h : CountPart P ph c g) {idx : ℕ} (hidx : idx < g.labels.length) :
    g.labelAt idx = if idx = 0 then (0, 0) else ((shadowOf P g).tb (idx - 1), idx - 1) := by
  split_ifs with h0
  · rw [h0]
    exact h.label0
  · exact h.labelSucc idx (by omega) hidx

theorem pred_lt_live (h : CountPart P ph c g) {idx : ℕ} (h1 : 1 ≤ idx) (hidx : idx < g.labels.length) :
    idx - 1 < ph.live P.H := by
  have := h.nLab
  omega

theorem labelAt_mem {idx : ℕ} (hidx : idx < g.labels.length) : g.labelAt idx ∈ g.labels := by
  unfold Ghost.labelAt
  rw [List.getD_eq_getElem _ _ hidx]
  exact List.getElem_mem hidx

theorem labelAt_of_mem {lab : BankLabel} (hmem : lab ∈ g.labels) :
    ∃ j, j < g.labels.length ∧ g.labelAt j = lab := by
  obtain ⟨j, hj, hjeq⟩ := List.mem_iff_getElem.mp hmem
  refine ⟨j, hj, ?_⟩
  unfold Ghost.labelAt
  rw [List.getD_eq_getElem _ _ hj]
  exact hjeq

/-- Distinct live banks have distinct labels. -/
theorem inj (h : CountPart P ph c g) {i j : ℕ} (hi : i < g.labels.length) (hj : j < g.labels.length)
    (hij : g.labelAt i = g.labelAt j) : i = j := by
  rw [h.labelAt_eq hi, h.labelAt_eq hj] at hij
  by_cases hi0 : i = 0 <;> by_cases hj0 : j = 0
  · omega
  · rw [if_pos hi0, if_neg hj0] at hij
    have h1 := (h.tbLast (j - 1) (h.pred_lt_live (by omega) hj)).1
    have h2 := congrArg Prod.fst hij
    simp only at h2
    omega
  · rw [if_neg hi0, if_pos hj0] at hij
    have h1 := (h.tbLast (i - 1) (h.pred_lt_live (by omega) hi)).1
    have h2 := congrArg Prod.fst hij
    simp only at h2
    omega
  · rw [if_neg hi0, if_neg hj0] at hij
    have h2 := congrArg Prod.snd hij
    simp only at h2
    omega

/-- Live labels were born by the current round. -/
theorem lab_fst_le (h : CountPart P ph c g) : ∀ lab ∈ g.labels, lab.1 ≤ (shadowOf P g).t := by
  intro lab hmem
  obtain ⟨j, hj, e⟩ := labelAt_of_mem hmem
  rw [← e, h.labelAt_eq hj]
  split_ifs
  · exact Nat.zero_le _
  · exact OrcAux.shadow_tb_le g (j - 1)

/-- Rounds are `≥ 1` (while a bank is still to be evaluated). -/
theorem t_pos (h : CountPart P ph c g) (hev : evaluated ph 0 = false) : 1 ≤ (shadowOf P g).t := by
  have hlen : 0 < g.labels.length := by rw [h.nLab]; omega
  have := h.cntInt 0 hlen
  rw [hev] at this
  simp only [Bool.false_eq_true, if_false] at this
  omega

/-- At births `d`, the label `(t, d)` of the bank about to be born carries no call. -/
theorem fresh_new {d : ℕ} (h : CountPart P (.births d) c g) (hd : d < P.H) :
    ∀ rec ∈ g.calls, rec.lab ≠ ((shadowOf P g).t, d) := by
  intro rec hr heq
  have ht1 := h.t_pos rfl
  rcases h.fresh rec hr with hmem | hlt
  · obtain ⟨j, hj, e⟩ := labelAt_of_mem hmem
    rw [heq, h.labelAt_eq hj] at e
    have hlen := h.len_births hd
    split_ifs at e with hj0
    · have := congrArg Prod.fst e
      simp only at this
      omega
    · have := congrArg Prod.snd e
      simp only at this
      omega
  · rw [heq] at hlt
    exact lt_irrefl _ hlt

/-- Moments with the same live depths, labels, calls, round and birth rounds (and no more pending evaluations nor
more events to come). -/
theorem transport {ph ph' : Tree.Phase} {c c' : CState} {g g' : Ghost} (h : CountPart P ph c g)
    (hlive : ph'.live P.H = ph.live P.H)
    (hev : ∀ idx, evaluated ph idx = true → evaluated ph' idx = true)
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls)
    (ht : (shadowOf P g').t = (shadowOf P g).t) (htb : (shadowOf P g').tb = (shadowOf P g).tb)
    (hjU : ∀ j, (c'.learners.getD j dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed)
    (hnev : g'.events.length + remEv P.H ph' ≤ g.events.length + remEv P.H ph) :
    CountPart P ph' c' g' := by
  have hlab : g'.labelAt = g.labelAt := by
    funext idx
    unfold Ghost.labelAt
    rw [hl]
  have hfl : firstLife (shadowOf P g') = firstLife (shadowOf P g) := by
    funext idx
    unfold firstLife
    rw [htb]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hl, hlive]
    exact h.nLab
  · rw [hlab]
    exact h.label0
  · intro idx h1 h2
    rw [hl] at h2
    rw [hlab, htb]
    exact h.labelSucc idx h1 h2
  · intro rec hr
    rw [hcalls] at hr
    rw [hl, ht]
    exact h.fresh rec hr
  · intro idx hidx
    rw [hl] at hidx
    rw [hlab, hcalls, ht]
    have h1 := h.cntInt idx hidx
    have key : (if evaluated ph' idx = true then 0 else 1) ≤ (if evaluated ph idx = true then 0 else 1) := by
      by_cases he : evaluated ph idx = true
      · rw [if_pos he, if_pos (hev idx he)]
      · rw [if_neg he]
        split_ifs <;> omega
    exact le_trans (Nat.add_le_add_left key _) h1
  · intro idx hidx hlv
    rw [hl] at hidx
    rw [hlive] at hlv
    rw [hlab, hcalls, hjU, hfl]
    exact h.cntLive idx hidx hlv
  · intro idx hidx hlv
    rw [hl] at hidx
    rw [hlive] at hlv
    rw [hlab, hcalls, htb, ht]
    exact h.cntNew idx hidx hlv
  · intro d hd
    rw [hlive] at hd
    rw [htb, ht]
    exact h.tbLast d hd
  · rw [ht]
    exact le_trans hnev h.nev

/-- The birth of depth `d` (with or without a birth release), in terms of the call log after it. -/
theorem birth_gen {c c' : CState} {g g' : Ghost} {d : ℕ}
    (h : CountPart P (.births d) c g) (hd : d < P.H)
    (hbornd : bornAt P.H d (shadowOf P g).t = true)
    (hl : g'.labels = g.labels ++ (if d + 2 ≤ P.H then [((shadowOf P g).t, d)] else []))
    (he : g'.events = g.events ++ [TreeEvent.birth d])
    (hjU : ∀ idx < d, (c'.learners.getD idx dfltLearner).jUsed = (c.learners.getD idx dfltLearner).jUsed)
    (hfresh : ∀ rec ∈ g'.calls, rec.lab ∈ g.labels ∨ rec.lab.1 < (shadowOf P g).t)
    (hcntI : ∀ idx < d + 1, nInt (g.labelAt idx) g'.calls = nInt (g.labelAt idx) g.calls)
    (hold : ∀ idx < d, nRej (g.labelAt idx) g'.calls = nRej (g.labelAt idx) g.calls ∧
      nNum (g.labelAt idx) g'.calls = nNum (g.labelAt idx) g.calls)
    (hnew : d + 2 ≤ P.H → nInt ((shadowOf P g).t, d) g'.calls = 0 ∧
      nRej ((shadowOf P g).t, d) g'.calls = 0 ∧ nNum ((shadowOf P g).t, d) g'.calls = 0)
    (hlived : nRej (g.labelAt d) g'.calls ≤ (if firstLife (shadowOf P g') d then 0 else P.Jstar) ∧
      nNum (g.labelAt d) g'.calls ≤ (if firstLife (shadowOf P g') d then 0 else 2 * P.Jstar + 1)) :
    CountPart P (.births (d + 1)) c' g' := by
  obtain ⟨hS't, hS'tb⟩ := OrcAux.shadow_birth (P := P) he
  have hlen := h.len_births hd
  have ht1 : 1 ≤ (shadowOf P g).t := h.t_pos rfl
  have hlabL : ∀ idx < d + 1, g'.labelAt idx = g.labelAt idx := by
    intro idx hidx
    unfold Ghost.labelAt
    rw [hl, List.getD_append _ _ _ _ (by omega)]
  have hlabN : d + 2 ≤ P.H → g'.labelAt (d + 1) = ((shadowOf P g).t, d) := by
    intro hd2
    unfold Ghost.labelAt
    rw [hl, if_pos hd2, List.getD_append_right _ _ _ _ (by omega), hlen, Nat.sub_self]
    rfl
  have hlen' : g'.labels.length = d + 1 + (if d + 2 ≤ P.H then 1 else 0) := by
    rw [hl, List.length_append, hlen]
    split_ifs <;> simp
  have htbne : ∀ j, j ≠ d → (shadowOf P g').tb j = (shadowOf P g).tb j := by
    intro j hj
    rw [hS'tb, Function.update_of_ne hj]
  have htbd : (shadowOf P g').tb d = (shadowOf P g).t := by
    rw [hS'tb]
    simp
  have hfl : ∀ idx < d, firstLife (shadowOf P g') idx = firstLife (shadowOf P g) idx := by
    intro idx hidx
    unfold firstLife
    rw [htbne idx (by omega), htbne (idx - 1) (by omega)]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hlen']
    show _ = min (d + 1) (P.H - 1) + 1
    split_ifs <;> omega
  · rw [hlabL 0 (by omega)]
    exact h.label0
  · intro idx h1 h2
    rw [hlen'] at h2
    rcases Nat.lt_or_ge idx (d + 1) with hlt | hge
    · rw [hlabL idx hlt, htbne (idx - 1) (by omega)]
      exact h.labelSucc idx h1 (by omega)
    · have hd2 : d + 2 ≤ P.H := by
        by_contra hcon
        rw [if_neg hcon] at h2
        omega
      have hid : idx = d + 1 := by
        rw [if_pos hd2] at h2
        omega
      rw [hid, hlabN hd2, Nat.add_sub_cancel, htbd]
  · intro rec hr
    rw [hS't]
    rcases hfresh rec hr with hm | hlt
    · left
      rw [hl]
      exact List.mem_append_left _ hm
    · right
      exact hlt
  · intro idx hidx
    rw [hlen'] at hidx
    rw [hS't, evaluated_births]
    rcases Nat.lt_or_ge idx (d + 1) with hlt | hge
    · rw [hlabL idx hlt, hcntI idx hlt]
      have := h.cntInt idx (by omega)
      rw [evaluated_births] at this
      exact this
    · have hd2 : d + 2 ≤ P.H := by
        by_contra hcon
        rw [if_neg hcon] at hidx
        omega
      have hid : idx = d + 1 := by
        rw [if_pos hd2] at hidx
        omega
      rw [hid, hlabN hd2, (hnew hd2).1]
      simp only [Bool.false_eq_true, if_false]
      omega
  · intro idx hidx hlv
    change idx < d + 1 at hlv
    rcases Nat.lt_or_ge idx d with hlt | hge
    · rw [hlabL idx (by omega), (hold idx hlt).1, (hold idx hlt).2, hjU idx hlt, hfl idx hlt]
      exact h.cntLive idx (by omega) hlt
    · have hid : idx = d := by omega
      rw [hid, hlabL d (by omega)]
      obtain ⟨h1, h2⟩ := hlived
      exact ⟨le_trans h1 (Nat.le_add_left _ _), le_trans h2 (Nat.le_add_left _ _)⟩
  · intro idx hidx hlv
    change d + 1 ≤ idx at hlv
    rw [hlen'] at hidx
    have hd2 : d + 2 ≤ P.H := by
      by_contra hcon
      rw [if_neg hcon] at hidx
      omega
    have hid : idx = d + 1 := by
      rw [if_pos hd2] at hidx
      omega
    rw [hid, hlabN hd2]
    obtain ⟨-, h2, h3⟩ := hnew hd2
    rw [h2, h3]
    exact ⟨Nat.zero_le _, Nat.zero_le _, fun _ => ⟨rfl, rfl⟩⟩
  · intro d' hd'
    change d' < d + 1 at hd'
    rw [hS't]
    rcases Nat.lt_or_ge d' d with hlt | hge
    · rw [htbne d' (by omega)]
      exact h.tbLast d' hlt
    · have hid : d' = d := by omega
      rw [hid, htbd]
      exact ⟨ht1, hbornd, fun r h1 h2 => absurd (lt_of_lt_of_le h1 h2) (lt_irrefl _)⟩
  · rw [he, hS't, List.length_append, List.length_singleton]
    have := h.nev
    simp only [remEv] at this ⊢
    omega

/-- Step 4 at depth `d` (accept or reject), in terms of the call log after it. -/
theorem eval_gen {c c' : CState} {g g' : Ghost} {d : ℕ} {ev : TreeEvent}
    (h : CountPart P (.evals (d + 1)) c g)
    (hl : g'.labels = g.labels) (he : g'.events = g.events ++ [ev])
    (hev1 : ev ≠ TreeEvent.newRound) (hev2 : ∀ d', ev ≠ TreeEvent.birth d')
    (hjU : ∀ j, j ≠ d → (c'.learners.getD j dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed)
    (hfresh : ∀ rec ∈ g'.calls, rec.lab ∈ g.labels ∨ rec.lab.1 < (shadowOf P g).t)
    (hcntId : nInt (g.labelAt d) g'.calls = nInt (g.labelAt d) g.calls + 1)
    (hother : ∀ idx < P.H, idx ≠ d → nInt (g.labelAt idx) g'.calls = nInt (g.labelAt idx) g.calls ∧
      nRej (g.labelAt idx) g'.calls = nRej (g.labelAt idx) g.calls ∧
      nNum (g.labelAt idx) g'.calls = nNum (g.labelAt idx) g.calls)
    (hlived : nRej (g.labelAt d) g'.calls ≤
        (c'.learners.getD d dfltLearner).jUsed + (if firstLife (shadowOf P g) d then 0 else P.Jstar) ∧
      nNum (g.labelAt d) g'.calls ≤
        2 * (c'.learners.getD d dfltLearner).jUsed +
          (if firstLife (shadowOf P g) d then 0 else 2 * P.Jstar + 1)) :
    CountPart P (.evals d) c' g' := by
  obtain ⟨hS't, hS'tb⟩ := OrcAux.shadow_other (P := P) he hev1 hev2
  have hlen : g.labels.length = P.H := h.len_full rfl
  have hlab : g'.labelAt = g.labelAt := by
    funext idx
    unfold Ghost.labelAt
    rw [hl]
  have hfl : firstLife (shadowOf P g') = firstLife (shadowOf P g) := by
    funext idx
    unfold firstLife
    rw [hS'tb]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hl]
    exact h.nLab
  · rw [hlab]
    exact h.label0
  · intro idx h1 h2
    rw [hl] at h2
    rw [hlab, hS'tb]
    exact h.labelSucc idx h1 h2
  · intro rec hr
    rw [hl, hS't]
    exact hfresh rec hr
  · intro idx hidx
    rw [hl, hlen] at hidx
    rw [hlab, hS't]
    by_cases hid : idx = d
    · rw [hid, hcntId, evaluated_evals, decide_eq_true (le_refl d)]
      have := h.cntInt d (by omega)
      rw [evaluated_evals, decide_eq_false (by omega)] at this
      simp only [Bool.false_eq_true, if_false, if_true] at this ⊢
      omega
    · rw [(hother idx hidx hid).1]
      have e : evaluated (.evals d) idx = evaluated (.evals (d + 1)) idx := by
        rw [evaluated_evals, evaluated_evals, decide_eq_decide]
        omega
      rw [e]
      exact h.cntInt idx (by omega)
  · intro idx hidx hlv
    rw [hl, hlen] at hidx
    rw [hlab, hfl]
    by_cases hid : idx = d
    · rw [hid]
      exact hlived
    · rw [(hother idx hidx hid).2.1, (hother idx hidx hid).2.2, hjU idx hid]
      exact h.cntLive idx (by omega) hidx
  · intro idx hidx hlv
    rw [hl, hlen] at hidx
    change P.H ≤ idx at hlv
    omega
  · intro d' hd'
    rw [hS'tb, hS't]
    exact h.tbLast d' hd'
  · rw [he, hS't, List.length_append, List.length_singleton]
    have := h.nev
    simp only [remEv] at this ⊢
    omega

end CountPart

/-! ## The block lemmas -/

/-- Round `1`: after the initialization (`bankNew 0 0`) and the first `newRound`. -/
theorem countPart_init (hP : ParamsOK P) (c : CState) (hc : c.learners = []) (g : Ghost)
    (hl : g.labels = [(0, 0)]) (hcalls : g.calls = []) (he : g.events = [TreeEvent.newRound]) :
    CountPart P (.births 0) c g := by
  obtain ⟨ht1, -⟩ := OrcAux.shadow_newRound (P := P) (g := { g with events := [] }) (g' := g)
    (by rw [he]; rfl)
  have ht : (shadowOf P g).t = 1 := by
    rw [ht1]
    rfl
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hl]
    simp [Tree.Phase.live]
  · unfold Ghost.labelAt
    rw [hl]
    rfl
  · intro idx h1 h2
    rw [hl] at h2
    simp at h2
    omega
  · intro rec hr
    rw [hcalls] at hr
    simp at hr
  · intro idx hidx
    rw [hcalls, ht, evaluated_births]
    simp [nInt]
  · intro idx _ hlv
    change idx < 0 at hlv
    omega
  · intro idx _ _
    rw [hcalls]
    simp [nRej, nNum]
  · intro d hd
    change d < 0 at hd
    omega
  · rw [he, ht]
    simp only [remEv, List.length_singleton]
    omega

/-- A new round `t + 1 ≤ m` (`noteM newRound`, `bankRetainM (d₀+1)`, retirement of the learners `≥ d₀`). -/
theorem countPart_newRound (hP : ParamsOK P) {c c' : CState} {g g' : Ghost}
    (h : CountPart P .idle c g) (htree : Tree.TreeInv P .idle (regsOf P c) (shadowOf P g))
    (hjU : ∀ d < P.H, (c.learners.getD d dfltLearner).jUsed < P.Jstar)
    (ht : (shadowOf P g).t < P.m)
    (hl : g'.labels = g.labels.take (firstBorn P.H ((shadowOf P g).t + 1) + 1)) (hcalls : g'.calls = g.calls)
    (he : g'.events = g.events ++ [TreeEvent.newRound])
    (hc : c'.learners = c.learners.take (firstBorn P.H ((shadowOf P g).t + 1))) :
    CountPart P (.births (firstBorn P.H ((shadowOf P g).t + 1))) c' g' := by
  obtain ⟨hS't, hS'tb⟩ := OrcAux.shadow_newRound (P := P) he
  have hH := P.one_le_H
  have ht1 : 1 ≤ (shadowOf P g).t := htree.round_pos
  have hd0H : firstBorn P.H ((shadowOf P g).t + 1) < P.H := OrcAux.firstBorn_lt P.H _ hH
  have hd01 : 1 ≤ firstBorn P.H ((shadowOf P g).t + 1) := OrcAux.firstBorn_pos P ht1 ht
  obtain ⟨d0, hd0e⟩ : ∃ d0, firstBorn P.H ((shadowOf P g).t + 1) = d0 := ⟨_, rfl⟩
  rw [hd0e] at hl hc hd0H hd01 ⊢
  have hlen : g.labels.length = P.H := h.len_full rfl
  have hlen' : g'.labels.length = d0 + 1 := by
    rw [hl, List.length_take, hlen]
    omega
  have hlab : ∀ idx, idx < d0 + 1 → g'.labelAt idx = g.labelAt idx := by
    intro idx hidx
    unfold Ghost.labelAt
    rw [hl, List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take, if_pos hidx]
  have hfl : firstLife (shadowOf P g') = firstLife (shadowOf P g) := by
    funext idx
    unfold firstLife
    rw [hS'tb]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hlen']
    show d0 + 1 = min d0 (P.H - 1) + 1
    omega
  · rw [hlab 0 (by omega)]
    exact h.label0
  · intro idx h1 h2
    rw [hlen'] at h2
    rw [hlab idx h2, hS'tb]
    exact h.labelSucc idx h1 (by omega)
  · intro rec hr
    rw [hcalls] at hr
    right
    rw [hS't]
    rcases h.fresh rec hr with hm | hlt
    · have := h.lab_fst_le rec.lab hm
      omega
    · omega
  · intro idx hidx
    rw [hlen'] at hidx
    rw [hlab idx hidx, hcalls, hS't, evaluated_births]
    have := h.cntInt idx (by omega)
    rw [evaluated_idle] at this
    simp only [Bool.false_eq_true, if_false, if_true] at this ⊢
    omega
  · intro idx hidx hlv
    change idx < d0 at hlv
    rw [hlab idx (by omega), hcalls, hc, getD_take_jUsed _ _ _ hlv, hfl]
    exact h.cntLive idx (by omega) (by show idx < P.H; omega)
  · intro idx hidx hlv
    rw [hlen'] at hidx
    change d0 ≤ idx at hlv
    have hid : idx = d0 := by omega
    rw [hid, hlab d0 (by omega), hcalls, hS'tb, hS't]
    refine ⟨?_, ?_, ?_⟩
    rotate_right
    · rintro (h0 | h0)
      · omega
      · have := OrcAux.shadow_tb_le (P := P) g (d0 - 1)
        omega
    all_goals
      obtain ⟨hr, hn⟩ := h.cntLive d0 (by omega) (by show d0 < P.H; exact hd0H)
      have hj := hjU d0 hd0H
      cases hfirst : firstLife (shadowOf P g) d0 with
      | true =>
        rw [hfirst] at hr hn
        simp only [if_true] at hr hn
        omega
      | false =>
        exfalso
        have hne : ¬ (d0 = 0 ∨ (shadowOf P g).tb d0 = (shadowOf P g).tb (d0 - 1)) := by
          rw [← firstLife_iff, hfirst]
          simp
        obtain ⟨ha1, ha, haN⟩ := h.tbLast (d0 - 1) (by show d0 - 1 < P.H; omega)
        obtain ⟨-, hb, hbN⟩ := h.tbLast d0 (by show d0 < P.H; exact hd0H)
        exact OrcAux.no_third_life hH hd01 hd0H hd0e ha1 ha haN hb hbN (OrcAux.shadow_tb_le g _)
          (OrcAux.shadow_tb_le g _) (fun e => hne (Or.inr e))
  · intro d hd
    change d < d0 at hd
    rw [hS'tb, hS't]
    obtain ⟨h1, h2, h3⟩ := h.tbLast d (by show d < P.H; omega)
    refine ⟨h1, h2, fun r hr1 hr2 => ?_⟩
    rcases Nat.lt_or_ge r ((shadowOf P g).t + 1) with hlt | hge
    · exact h3 r hr1 (by omega)
    · have hr : r = (shadowOf P g).t + 1 := by omega
      rw [hr]
      cases hb : bornAt P.H d ((shadowOf P g).t + 1) with
      | false => rfl
      | true =>
        have := (OrcAux.bornAt_iff_firstBorn_le P.H _ d hH).mp hb
        omega
  · rw [he, hS't, List.length_append, List.length_singleton]
    have := h.nev
    simp only [remEv] at this ⊢
    rw [Nat.mul_succ]
    omega

/-- The birth of depth `d` without a birth release (`d = 0` or `d > d₀`): the outgoing bank `(t, d)` (if
`d + 2 ≤ H`), the analysis event `birth d`, the new learner with `J_used = 0`. -/
theorem countPart_birth (hP : ParamsOK P) {c c' : CState} {g g' : Ghost} {d : ℕ}
    (h : CountPart P (.births d) c g) (htree : Tree.TreeInv P (.births d) (regsOf P c) (shadowOf P g))
    (hd : d < P.H) (hd0 : d = 0 ∨ firstBorn P.H (shadowOf P g).t < d)
    (hb : firstBorn P.H (shadowOf P g).t ≤ d)
    (hl : g'.labels = g.labels ++ (if d + 2 ≤ P.H then [((shadowOf P g).t, d)] else []))
    (hcalls : g'.calls = g.calls) (he : g'.events = g.events ++ [TreeEvent.birth d])
    (hc : c'.learners = c.learners ++ [newLearner P 0]) :
    CountPart P (.births (d + 1)) c' g' := by
  obtain ⟨-, hS'tb⟩ := OrcAux.shadow_birth (P := P) he
  have hlen := h.len_births hd
  refine h.birth_gen hd ((OrcAux.bornAt_iff_firstBorn_le _ _ _ P.one_le_H).mpr hb) hl he ?_ ?_ ?_ ?_ ?_ ?_
  · intro idx _
    rw [hc]
    exact getD_append_jUsed _ _ rfl idx
  · intro rec hr
    rw [hcalls] at hr
    exact h.fresh rec hr
  · intro idx _
    rw [hcalls]
  · intro idx _
    rw [hcalls]
    exact ⟨rfl, rfl⟩
  · intro _
    rw [hcalls]
    exact OrcAux.counts_zero (h.fresh_new hd)
  · rw [hcalls]
    obtain ⟨h1, h2, h3⟩ := h.cntNew d (by omega) (le_refl _)
    by_cases hf : firstLife (shadowOf P g') d = true
    · rw [if_pos hf, if_pos hf]
      have key : d = 0 ∨ (shadowOf P g).tb (d - 1) = (shadowOf P g).t := by
        rw [firstLife_iff] at hf
        rcases hf with hf | hf
        · exact Or.inl hf
        · by_cases hd0' : d = 0
          · exact Or.inl hd0'
          · right
            rw [hS'tb, Function.update_self, Function.update_of_ne (show d - 1 ≠ d by omega)] at hf
            exact hf.symm
      obtain ⟨e1, e2⟩ := h3 key
      rw [e1, e2]
      exact ⟨le_refl 0, le_refl 0⟩
    · rw [if_neg hf, if_neg hf]
      exact ⟨h1, by omega⟩

/-- The birth of depth `d = d₀ ≥ 1` with the birth release on bank `d` (a numerical request `rec` of the label
of bank `d`, answered by the ADA module), the analysis event `birth d`, the new learner with `J_used = 0`. -/
theorem countPart_birth_release (hP : ParamsOK P) {c c' : CState} {g g' : Ghost} {d : ℕ}
    (h : CountPart P (.births d) c g) (htree : Tree.TreeInv P (.births d) (regsOf P c) (shadowOf P g))
    (hd : d < P.H) (hd1 : 1 ≤ d) (hd0 : firstBorn P.H (shadowOf P g).t = d)
    (rec : CallRec) (hrlab : rec.lab = g.labelAt d) (hrkind : rec.kind = CallKind.release Mode.primary)
    {a : AdaNum} (hrout : rec.out = some (Sum.inr a)) (cache : ℤ)
    (hl : g'.labels = g.labels ++ (if d + 2 ≤ P.H then [((shadowOf P g).t, d)] else []))
    (hcalls : g'.calls = g.calls ++ [rec]) (he : g'.events = g.events ++ [TreeEvent.birth d])
    (hc : c'.learners = c.learners ++ [newLearner P cache]) :
    CountPart P (.births (d + 1)) c' g' := by
  obtain ⟨-, hS'tb⟩ := OrcAux.shadow_birth (P := P) he
  have hlen := h.len_births hd
  obtain ⟨hrI, hrN, hrR⟩ := OrcAux.rec_release hrkind hrout
  have hlabd : g.labelAt d = ((shadowOf P g).tb (d - 1), d - 1) := h.labelSucc d hd1 (by omega)
  -- the client `d` is in the second lifetime of bank `d` (depth `d − 1` is not born this round)
  have hnotfirst : firstLife (shadowOf P g') d = false := by
    cases hf : firstLife (shadowOf P g') d with
    | false => rfl
    | true =>
      exfalso
      rw [firstLife_iff] at hf
      rcases hf with hf | hf
      · omega
      · rw [hS'tb, Function.update_self, Function.update_of_ne (show d - 1 ≠ d by omega)] at hf
        obtain ⟨-, ha, -⟩ := h.tbLast (d - 1) (by show d - 1 < d; omega)
        rw [← hf] at ha
        have := (OrcAux.bornAt_iff_firstBorn_le P.H _ _ P.one_le_H).mp ha
        omega
  refine h.birth_gen hd ((OrcAux.bornAt_iff_firstBorn_le _ _ _ P.one_le_H).mpr (le_of_eq hd0)) hl he ?_ ?_ ?_ ?_ ?_ ?_
  · intro idx _
    rw [hc]
    exact getD_append_jUsed _ _ rfl idx
  · intro r hr
    rw [hcalls] at hr
    rcases List.mem_append.mp hr with hr | hr
    · exact h.fresh r hr
    · rw [List.mem_singleton] at hr
      rw [hr, hrlab]
      exact Or.inl (CountPart.labelAt_mem (by omega))
  · intro idx _
    rw [hcalls, OrcAux.nInt_append, hrI]
    simp
  · intro idx hidx
    have hne : rec.lab ≠ g.labelAt idx := by
      rw [hrlab]
      intro e
      have := h.inj (by omega) (by omega) e
      omega
    obtain ⟨-, e2, e3⟩ := OrcAux.counts_append_ne g.calls hne
    rw [hcalls]
    exact ⟨e2, e3⟩
  · intro _
    rw [hcalls]
    refine OrcAux.counts_zero fun r hr => ?_
    rcases List.mem_append.mp hr with hr | hr
    · exact h.fresh_new hd r hr
    · rw [List.mem_singleton] at hr
      rw [hr, hrlab, hlabd]
      intro e
      have := congrArg Prod.snd e
      simp only at this
      omega
  · rw [hcalls, hnotfirst, OrcAux.nRej_append, OrcAux.nNum_append, hrR, hrN, hrlab]
    obtain ⟨h1, h2, -⟩ := h.cntNew d (by omega) (le_refl _)
    simp only [Bool.false_eq_true, if_false, and_false, and_true, if_true]
    omega

/-- An analysis event that changes no count and no label: Step 2 (`phys`, births `H` → guards `0`) and Step 3
(`guard`, guards `d` → guards `d + 1`); the learners' counters are unchanged. -/
theorem countPart_phys (hP : ParamsOK P) {c c' : CState} {g g' : Ghost} (i : ℕ) (Δ : ℤ)
    (h : CountPart P (.births P.H) c g) (hi : i - 1 < P.n)
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls)
    (he : g'.events = g.events ++ [TreeEvent.phys i Δ])
    (hc : c'.learners.length = c.learners.length)
    (hjU : ∀ j, (c'.learners.getD j dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed) :
    CountPart P (.guards 0) c' g' := by
  obtain ⟨ht, htb⟩ := OrcAux.shadow_other (P := P) he (by simp) (fun _ => by simp)
  refine h.transport rfl (fun idx he' => ?_) hl hcalls ht htb hjU ?_
  · rw [evaluated_births] at he'
    exact absurd he' (by simp)
  · rw [he, List.length_append, List.length_singleton]
    simp only [remEv]
    omega

theorem countPart_guard (hP : ParamsOK P) {c c' : CState} {g g' : Ghost} {d : ℕ} (gc : ℕ) (δ : ℤ)
    (h : CountPart P (.guards d) c g) (hd : d < P.H) (hg : gc - 1 < P.Dstar)
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls)
    (he : g'.events = g.events ++ [TreeEvent.guard d gc δ])
    (hc : c'.learners.length = c.learners.length)
    (hjU : ∀ j, (c'.learners.getD j dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed) :
    CountPart P (.guards (d + 1)) c' g' := by
  obtain ⟨ht, htb⟩ := OrcAux.shadow_other (P := P) he (by simp) (fun _ => by simp)
  refine h.transport rfl (fun idx he' => ?_) hl hcalls ht htb hjU ?_
  · rw [evaluated_guards] at he'
    exact absurd he' (by simp)
  · rw [he, List.length_append, List.length_singleton]
    simp only [remEv]
    omega

theorem countPart_bypass {c : CState} {g : Ghost} (h : CountPart P (.guards 0) c g) :
    CountPart P .idle c g :=
  h.transport rfl (fun idx _ => evaluated_idle idx) rfl rfl rfl rfl (fun _ => rfl)
    (by simp only [remEv]; omega)

theorem countPart_startStep4 {c : CState} {g : Ghost} (h : CountPart P (.guards P.H) c g) :
    CountPart P (.evals P.H) c g :=
  h.transport rfl (fun idx he' => absurd he' (by rw [evaluated_guards]; simp)) rfl rfl rfl rfl (fun _ => rfl)
    (by simp only [remEv]; omega)

/-- Step 4 at depth `d`, `ACCEPT`: the interval request `rec` of bank `d`, the analysis event `accept d`. -/
theorem countPart_accept (hP : ParamsOK P) {c : CState} {g g' : Ghost} {d : ℕ}
    (h : CountPart P (.evals (d + 1)) c g) (hd : d < P.H)
    (rec : CallRec) (hrlab : rec.lab = g.labelAt d) {S θ : ℚ} (hrkind : rec.kind = CallKind.validate S θ)
    (hrout : rec.out = some (Sum.inl AdaCert.accept))
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls ++ [rec])
    (he : g'.events = g.events ++ [TreeEvent.accept d]) :
    CountPart P (.evals d) c g' := by
  have hlen : g.labels.length = P.H := h.len_full rfl
  obtain ⟨hrI, hrN, hrR⟩ := OrcAux.rec_validate hrkind hrout
  have hrR' : OrcAux.recRej rec = false := by
    rw [hrR]
    rfl
  refine h.eval_gen hl he (by simp) (fun _ => by simp) (fun _ _ => rfl) ?_ ?_ ?_ ?_
  · intro r hr
    rw [hcalls] at hr
    rcases List.mem_append.mp hr with hr | hr
    · exact h.fresh r hr
    · rw [List.mem_singleton] at hr
      rw [hr, hrlab]
      exact Or.inl (CountPart.labelAt_mem (by omega))
  · rw [hcalls, OrcAux.nInt_append, hrI, hrlab]
    simp
  · intro idx hidx hid
    have hne : rec.lab ≠ g.labelAt idx := by
      rw [hrlab]
      intro e
      exact hid (h.inj (by omega) (by omega) e).symm
    rw [hcalls]
    exact OrcAux.counts_append_ne g.calls hne
  · rw [hcalls, OrcAux.nRej_append, OrcAux.nNum_append, hrR', hrN]
    simp only [Bool.false_eq_true, and_false, if_false, add_zero]
    exact h.cntLive d (by omega) (by show d < P.H; exact hd)

/-- Step 4 at depth `d`, rejection: the interval request `r₀` (`HIGH`/`LOW`), the release `r₁` (`N₁`), the analysis
event `correct d c`, the release `r₂` (`N₂`), all on bank `d`; the client's `J_used` increases by one, the other
counters are unchanged. -/
theorem countPart_reject (hP : ParamsOK P) {c c' : CState} {g g' : Ghost} {d : ℕ}
    (h : CountPart P (.evals (d + 1)) c g) (hd : d < P.H)
    (r0 r1 r2 : CallRec) (h0lab : r0.lab = g.labelAt d) {S θ : ℚ} (h0kind : r0.kind = CallKind.validate S θ)
    {cert : AdaCert} (hcert : cert = AdaCert.high ∨ cert = AdaCert.low) (h0out : r0.out = some (Sum.inl cert))
    (h1lab : r1.lab = g.labelAt d) (h1kind : r1.kind = CallKind.release Mode.primary) {a1 : AdaNum}
    (h1out : r1.out = some (Sum.inr a1))
    (h2lab : r2.lab = g.labelAt d) (h2kind : r2.kind = CallKind.release Mode.diff) {a2 : AdaNum}
    (h2out : r2.out = some (Sum.inr a2)) (cInt : ℤ)
    (hl : g'.labels = g.labels) (hcalls : g'.calls = g.calls ++ [r0, r1, r2])
    (he : g'.events = g.events ++ [TreeEvent.correct d cInt])
    (hc : c'.learners.length = c.learners.length)
    (hjU : ∀ j, (c'.learners.getD j dfltLearner).jUsed =
      (c.learners.getD j dfltLearner).jUsed + (if j = d then 1 else 0)) :
    CountPart P (.evals d) c' g' := by
  have hlen : g.labels.length = P.H := h.len_full rfl
  obtain ⟨h0I, h0N, h0R⟩ := OrcAux.rec_validate h0kind h0out
  have h0R' : OrcAux.recRej r0 = true := by
    rw [h0R]
    rcases hcert with rfl | rfl <;> rfl
  obtain ⟨h1I, h1N, h1R⟩ := OrcAux.rec_release h1kind h1out
  obtain ⟨h2I, h2N, h2R⟩ := OrcAux.rec_release h2kind h2out
  have hcalls' : g'.calls = ((g.calls ++ [r0]) ++ [r1]) ++ [r2] := by
    rw [hcalls]
    simp
  have hjd : (c'.learners.getD d dfltLearner).jUsed = (c.learners.getD d dfltLearner).jUsed + 1 := by
    rw [hjU d, if_pos rfl]
  refine h.eval_gen hl he (by simp) (fun _ => by simp) (fun j hj => by rw [hjU j, if_neg hj, add_zero])
    ?_ ?_ ?_ ?_
  · intro r hr
    rw [hcalls] at hr
    rcases List.mem_append.mp hr with hr | hr
    · exact h.fresh r hr
    · left
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hr
      rcases hr with hr | hr | hr
      · rw [hr, h0lab]
        exact CountPart.labelAt_mem (by omega)
      · rw [hr, h1lab]
        exact CountPart.labelAt_mem (by omega)
      · rw [hr, h2lab]
        exact CountPart.labelAt_mem (by omega)
  · rw [hcalls', OrcAux.nInt_append, OrcAux.nInt_append, OrcAux.nInt_append, h0I, h1I, h2I, h0lab, h1lab,
      h2lab]
    simp
  · intro idx hidx hid
    have hne : ∀ r : CallRec, r.lab = g.labelAt d → r.lab ≠ g.labelAt idx := by
      intro r hr e
      rw [hr] at e
      exact hid (h.inj (by omega) (by omega) e).symm
    obtain ⟨a0, b0, c0⟩ := OrcAux.counts_append_ne g.calls (hne r0 h0lab)
    obtain ⟨a1, b1, c1⟩ := OrcAux.counts_append_ne (g.calls ++ [r0]) (hne r1 h1lab)
    obtain ⟨a2, b2, c2⟩ := OrcAux.counts_append_ne (g.calls ++ [r0] ++ [r1]) (hne r2 h2lab)
    rw [hcalls']
    exact ⟨by rw [a2, a1, a0], by rw [b2, b1, b0], by rw [c2, c1, c0]⟩
  · rw [hcalls', OrcAux.nRej_append, OrcAux.nRej_append, OrcAux.nRej_append, OrcAux.nNum_append,
      OrcAux.nNum_append, OrcAux.nNum_append, h0R', h1R, h2R, h0N, h1N, h2N, h0lab, h1lab, h2lab, hjd]
    obtain ⟨hr, hn⟩ := h.cntLive d (by omega) (by show d < P.H; exact hd)
    simp only [and_self, if_true, Bool.false_eq_true, and_false, if_false, add_zero]
    split_ifs at hr hn ⊢ <;> constructor <;> omega

theorem countPart_endRound {c c' : CState} {g : Ghost} (h : CountPart P (.evals 0) c g)
    (hc : c'.learners = c.learners) : CountPart P .idle c' g :=
  h.transport rfl (fun idx _ => evaluated_idle idx) rfl rfl rfl rfl (fun j => by rw [hc])
    (by simp only [remEv]; omega)

/-! ## Coverage of the bank calls (B's `coreCovered`) and the caps of the bank's ADA module -/

/-- The validation of depth `d` in round `t ≤ m`: at most `m − 1` earlier interval requests of the bank, and fewer
than `J_max` earlier rejections (so the ADA module does not return a terminal rejection). -/
theorem countPart_cov_validate (hP : ParamsOK P) {c : CState} {g : Ghost} {d : ℕ}
    (h : CountPart P (.evals (d + 1)) c g) (hd : d < P.H) (ht : (shadowOf P g).t ≤ P.m)
    (hjU : (c.learners.getD d dfltLearner).jUsed < P.Jstar) :
    nInt (g.labelAt d) g.calls + 1 ≤ (bankAda P).M ∧ nRej (g.labelAt d) g.calls < (bankAda P).J := by
  have hlen : g.labels.length = P.H := h.len_full rfl
  have h1 := h.cntInt d (by omega)
  rw [evaluated_evals, decide_eq_false (by omega)] at h1
  simp only [Bool.false_eq_true, if_false] at h1
  obtain ⟨h2, -⟩ := h.cntLive d (by omega) (by show d < P.H; exact hd)
  rw [bankAda_M, bankAda_J]
  constructor
  · omega
  · split_ifs at h2 <;> omega

/-- The birth release of depth `d = d₀ ≥ 1` on bank `d`: fewer than `R_max` earlier numerical requests and at most
`J_max` earlier rejections. -/
theorem countPart_cov_birth (hP : ParamsOK P) {c : CState} {g : Ghost} {d : ℕ}
    (h : CountPart P (.births d) c g) (hd : d < P.H) (hd1 : 1 ≤ d) :
    nNum (g.labelAt d) g.calls + 1 ≤ (bankAda P).R ∧ nRej (g.labelAt d) g.calls ≤ (bankAda P).J := by
  have hlen := h.len_births hd
  obtain ⟨h1, h2, -⟩ := h.cntNew d (by omega) (by show d ≤ d; exact le_refl d)
  rw [bankAda_R, bankAda_J]
  constructor <;> omega

/-- The releases of a rejection at depth `d` (`J_used < J_*` before it): after the rejected validation `r₀` (and
after the release `r₁`), fewer than `R_max` earlier numerical requests and at most `J_max` earlier rejections. -/
theorem countPart_cov_reject (hP : ParamsOK P) {c : CState} {g : Ghost} {d : ℕ}
    (h : CountPart P (.evals (d + 1)) c g) (hd : d < P.H)
    (hjU : (c.learners.getD d dfltLearner).jUsed < P.Jstar)
    (r0 r1 : CallRec) (h0lab : r0.lab = g.labelAt d) {S θ : ℚ} (h0kind : r0.kind = CallKind.validate S θ)
    {cert : AdaCert} (h0out : r0.out = some (Sum.inl cert))
    (h1lab : r1.lab = g.labelAt d) (h1kind : r1.kind = CallKind.release Mode.primary) {a1 : AdaNum}
    (h1out : r1.out = some (Sum.inr a1)) :
    (nNum (g.labelAt d) (g.calls ++ [r0]) + 1 ≤ (bankAda P).R ∧
        nRej (g.labelAt d) (g.calls ++ [r0]) ≤ (bankAda P).J) ∧
      (nNum (g.labelAt d) (g.calls ++ [r0, r1]) + 1 ≤ (bankAda P).R ∧
        nRej (g.labelAt d) (g.calls ++ [r0, r1]) ≤ (bankAda P).J) := by
  have hlen : g.labels.length = P.H := h.len_full rfl
  obtain ⟨hr, hn⟩ := h.cntLive d (by omega) (by show d < P.H; exact hd)
  obtain ⟨-, h0N, -⟩ := OrcAux.rec_validate h0kind h0out
  obtain ⟨-, h1N, h1R⟩ := OrcAux.rec_release h1kind h1out
  have e0N : nNum (g.labelAt d) (g.calls ++ [r0]) = nNum (g.labelAt d) g.calls := by
    rw [OrcAux.nNum_append, h0N]
    simp
  have e0R : nRej (g.labelAt d) (g.calls ++ [r0]) ≤ nRej (g.labelAt d) g.calls + 1 := by
    rw [OrcAux.nRej_append]
    split_ifs <;> omega
  have e01 : g.calls ++ [r0, r1] = (g.calls ++ [r0]) ++ [r1] := by simp
  have e1N : nNum (g.labelAt d) (g.calls ++ [r0, r1]) = nNum (g.labelAt d) g.calls + 1 := by
    rw [e01, OrcAux.nNum_append, e0N, h1N, h1lab]
    simp
  have e1R : nRej (g.labelAt d) (g.calls ++ [r0, r1]) = nRej (g.labelAt d) (g.calls ++ [r0]) := by
    rw [e01, OrcAux.nRej_append, h1R]
    simp
  rw [bankAda_R, bankAda_J, e0N, e1N, e1R]
  split_ifs at hr hn <;> refine ⟨⟨?_, ?_⟩, ⟨?_, ?_⟩⟩ <;> omega

/-- Distinct live banks have distinct labels. -/
theorem countPart_label_inj {ph : Tree.Phase} {c : CState} {g : Ghost} (h : CountPart P ph c g)
    {i j : ℕ} (hi : i < g.labels.length)
    (hj : j < g.labels.length) (hij : g.labelAt i = g.labelAt j) : i = j :=
  h.inj hi hj hij

/-- The number of analysis events is at most `T` (so `nev + 1 ≤ T` at every step of round `t ≤ m`). -/
theorem countPart_nev_le {ph : Tree.Phase} {c : CState} {g : Ghost} (h : CountPart P ph c g)
    (ht : (shadowOf P g).t ≤ P.m) : g.events.length + remEv P.H ph ≤ P.T := by
  have h1 : 3 * P.H + 2 ≤ 2 ^ 12 * (P.H + 1) ^ 3 := by
    have h3 : P.H + 1 ≤ (P.H + 1) ^ 3 := Nat.le_self_pow (by norm_num) _
    calc 3 * P.H + 2 ≤ 4096 * (P.H + 1) := by omega
      _ ≤ 4096 * (P.H + 1) ^ 3 := Nat.mul_le_mul_left _ h3
      _ = 2 ^ 12 * (P.H + 1) ^ 3 := by norm_num
  calc g.events.length + remEv P.H ph ≤ (3 * P.H + 2) * (shadowOf P g).t := h.nev
    _ ≤ (3 * P.H + 2) * P.m := Nat.mul_le_mul_left _ ht
    _ ≤ (2 ^ 12 * (P.H + 1) ^ 3) * (P.m + 1) := Nat.mul_le_mul h1 (Nat.le_succ _)
    _ = P.T := by unfold StreamParams.T; ring

end F2e2e.C.Closure
