import F2e2e.C.ClosureProbOracle

/-!
# Theorem 6.4, probability layer (C-PROB): the simulation of the selected bank by its oracle (auxiliary lemmas)

TBitProg algebra, the retagging of fresh banks, the erasure of the selected bank, transcripts, and the
identification of the query values handed to the selected bank's ADA module with B's core values on the sample seeds
(`adaVals_eq_coreVals`, from C-CLOSE's row invariant `RowOK`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-! ## TBitProg algebra -/

theorem map_bind' {ι α β γ : Type} (p : TBitProg ι α) (f : α → TBitProg ι β) (h : β → γ) :
    (p.bind f).map h = p.bind fun a => (f a).map h := by
  unfold TBitProg.map
  rw [TBitProg.bind_assoc]

theorem map_pure' {ι α β : Type} (a : α) (h : α → β) :
    (TBitProg.pure a : TBitProg ι α).map h = TBitProg.pure (h a) := rfl

theorem retag_pure' {ι ι' α : Type} (f : ι → ι') (a : α) :
    (TBitProg.pure a : TBitProg ι α).retag f = TBitProg.pure a := rfl

/-- Binding after a tagged bit program only depends on the continuation at its possible outputs. -/
theorem bind_congr_always {ι α β : Type} (i : ι) {q : BitProg α} {Q : α → Prop} (hq : BitAlways Q q)
    {k1 k2 : α → TBitProg ι β} (h : ∀ x, Q x → k1 x = k2 x) : (tag i q).bind k1 = (tag i q).bind k2 := by
  induction hq with
  | pure a ha => exact h a ha
  | bit k _ ih =>
    simp only [tag_bit, bind_bit]
    congr 1
    funext b
    exact ih b

/-! ## Retagging the fresh banks -/

theorem adaSel_coarse (lab l : BankLabel) (j : ℕ) : adaSel lab (Tag.coarse l j) = false := by
  simp [adaSel]

theorem adaSel_fp (lab : BankLabel) : adaSel lab Tag.fp = false := by
  simp [adaSel]

theorem adaSel_seeds_self (lab : BankLabel) : adaSel lab (Tag.seeds lab) = true := by
  simp [adaSel]

theorem adaSel_coins_self (lab : BankLabel) : adaSel lab (Tag.coins lab) = true := by
  simp [adaSel]

theorem adaSel_seeds_ne {lab l : BankLabel} (h : l ≠ lab) : adaSel lab (Tag.seeds l) = false := by
  simp only [adaSel, Tag.seeds.injEq, reduceCtorEq, or_false, decide_eq_false_iff_not]
  exact h

theorem adaSel_coins_ne {lab l : BankLabel} (h : l ≠ lab) : adaSel lab (Tag.coins l) = false := by
  simp only [adaSel, Tag.coins.injEq, reduceCtorEq, false_or, decide_eq_false_iff_not]
  exact h

theorem retag_coarseT (P : StreamParams) (l lab : BankLabel) :
    ∀ j k, (coarseT P l j k).retag (adaSel lab) =
      tag false (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) k)
  | _, 0 => rfl
  | j, k + 1 => by
    rw [coarseT, retag_bind, retag_tag, adaSel_coarse,
      sampleList_succ (sampleList (sampleList (newRow P) 32) P.gCoarse) k, tag_bind]
    congr 1
    funext a
    rw [retag_bind, retag_coarseT P l lab (j + 1) k, tag_bind]
    rfl

theorem newBank_eq (P : StreamParams) : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind fun ada =>
    (coarseProg P).bind fun coarse => (adaInit (bankAda P)).bind fun st => BitProg.pure ⟨ada, coarse, st⟩ := rfl

theorem sim_retag_newBankT_ne (P : StreamParams) {l lab : BankLabel} (h : l ≠ lab) :
    (newBankT P l).retag (adaSel lab) = tag false (newBank P) := by
  rw [newBank_eq, newBankT, retag_bind, retag_tag, adaSel_seeds_ne h, tag_bind]
  congr 1
  funext ada
  rw [retag_bind, retag_coarseT, tag_bind]
  congr 1
  funext coarse
  rw [retag_bind, retag_tag, adaSel_coins_ne h, tag_bind]
  rfl

theorem retag_newBankT_self (P : StreamParams) (lab : BankLabel) {β : Type}
    (k : Bank → TBitProg Tag β) :
    ((newBankT P lab).bind k).retag (adaSel lab) =
      (tag true (sampleBlocks P (bankAda P).blockSizes)).bind fun ada =>
        (tag false (coarseProg P)).bind fun coarse =>
          (tag true (adaInit (bankAda P))).bind fun st => (k ⟨ada, coarse, st⟩).retag (adaSel lab) := by
  rw [newBankT, TBitProg.bind_assoc, retag_bind, retag_tag, adaSel_seeds_self]
  congr 1
  funext ada
  rw [TBitProg.bind_assoc, retag_bind, retag_coarseT]
  congr 1
  funext coarse
  rw [TBitProg.bind_assoc, retag_bind, retag_tag, adaSel_coins_self]
  rfl

/-! ## Erasure -/

theorem eraseBank_mapRows (f : Row → Row) (B : Bank) :
    eraseBank (Bank.mapRows f B) = Bank.mapRows f (eraseBank B) := by
  cases B; rfl

theorem length_eraseBanks (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) : (eraseBanks lab labels banks).length = banks.length := by
  simp [eraseBanks, h]

theorem getElem?_eraseBanks (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (i : ℕ) :
    (eraseBanks lab labels banks)[i]? =
      banks[i]?.map (fun B => if labels[i]? = some lab then eraseBank B else B) := by
  unfold eraseBanks
  rw [List.getElem?_zipWith]
  rcases Nat.lt_or_ge i banks.length with hi | hi
  · have hl : i < labels.length := by rw [h]; exact hi
    rw [List.getElem?_eq_getElem hl, List.getElem?_eq_getElem hi]
    simp
  · have hl : labels.length ≤ i := by rw [h]; exact hi
    rw [List.getElem?_eq_none hl, List.getElem?_eq_none hi]
    rfl

theorem eraseBanks_append (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (l : BankLabel) (B : Bank) :
    eraseBanks lab (labels ++ [l]) (banks ++ [B]) =
      eraseBanks lab labels banks ++ [if l = lab then eraseBank B else B] := by
  unfold eraseBanks
  rw [List.zipWith_append h]
  rfl

theorem eraseBanks_take (lab : BankLabel) (labels : List BankLabel) (banks : List Bank) (n : ℕ) :
    eraseBanks lab (labels.take n) (banks.take n) = (eraseBanks lab labels banks).take n := by
  unfold eraseBanks
  rw [List.take_zipWith]

theorem eraseBanks_modifyAt (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (F : Bank → Bank) (hF : ∀ B, eraseBank (F B) = F (eraseBank B))
    (idx : ℕ) : eraseBanks lab labels (modifyAt F idx banks) = modifyAt F idx (eraseBanks lab labels banks) := by
  apply List.ext_getElem?
  intro i
  rw [getElem?_eraseBanks lab (by rw [length_modifyAt]; exact h), getElem?_modifyAt, getElem?_modifyAt,
    getElem?_eraseBanks lab h]
  by_cases h1 : i = idx
  · subst h1
    rw [if_pos rfl, if_pos rfl]
    by_cases h2 : labels[i]? = some lab <;> cases banks[i]? <;> simp [h2, hF]
  · rw [if_neg h1, if_neg h1]

theorem eraseBanks_mapFrom (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (F : Bank → Bank) (hF : ∀ B, eraseBank (F B) = F (eraseBank B))
    (idx : ℕ) : eraseBanks lab labels (mapFrom F idx banks) = mapFrom F idx (eraseBanks lab labels banks) := by
  apply List.ext_getElem?
  intro i
  rw [getElem?_eraseBanks lab (by rw [length_mapFrom]; exact h), getElem?_mapFrom, getElem?_mapFrom,
    getElem?_eraseBanks lab h]
  by_cases h1 : idx ≤ i
  · rw [if_pos h1, if_pos h1]
    by_cases h2 : labels[i]? = some lab <;> cases banks[i]? <;> simp [h2, hF]
  · rw [if_neg h1, if_neg h1]

theorem eraseBanks_setAt_ne (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (idx : ℕ) (hl : labels[idx]? ≠ some lab) (B : Bank) :
    eraseBanks lab labels (setAt B idx banks) = setAt B idx (eraseBanks lab labels banks) := by
  apply List.ext_getElem?
  intro i
  rw [getElem?_eraseBanks lab (by rw [length_setAt]; exact h), getElem?_setAt, getElem?_setAt,
    getElem?_eraseBanks lab h, length_eraseBanks lab h]
  by_cases h1 : i = idx ∧ i < banks.length
  · rw [if_pos h1, if_pos h1]
    obtain ⟨rfl, -⟩ := h1
    simp [hl]
  · rw [if_neg h1, if_neg h1]

theorem eraseBanks_setAt_eq (lab : BankLabel) {labels : List BankLabel} {banks : List Bank}
    (h : labels.length = banks.length) (idx : ℕ) (hl : labels[idx]? = some lab) (B : Bank) :
    eraseBanks lab labels (setAt B idx banks) = setAt (eraseBank B) idx (eraseBanks lab labels banks) := by
  apply List.ext_getElem?
  intro i
  rw [getElem?_eraseBanks lab (by rw [length_setAt]; exact h), getElem?_setAt, getElem?_setAt,
    getElem?_eraseBanks lab h, length_eraseBanks lab h]
  by_cases h1 : i = idx ∧ i < banks.length
  · rw [if_pos h1, if_pos h1]
    obtain ⟨rfl, -⟩ := h1
    simp [hl]
  · rw [if_neg h1, if_neg h1]

theorem setAt_self {α : Type} : ∀ (idx : ℕ) (l : List α) (x : α), l[idx]? = some x → setAt x idx l = l
  | _, [], _, h => by simp at h
  | 0, a :: l, x, h => by simp at h; subst h; rfl
  | k + 1, a :: l, x, h => by
    simp only [List.getElem?_cons_succ] at h
    simp only [setAt, setAt_self k l x h]

/-! ## Transcripts -/

theorem adaTranscript_append (P : StreamParams) (lab : BankLabel) (g : Ghost) (rec : CallRec) :
    adaTranscript P lab { g with calls := g.calls ++ [rec] } =
      adaTranscript P lab g ++
        (if rec.lab = lab then (rec.out.map fun o => (callReq P rec, o)).toList else []) := by
  unfold adaTranscript
  rw [List.filterMap_append]
  congr 1
  simp only [List.filterMap_cons, List.filterMap_nil]
  by_cases h : rec.lab = lab
  · rw [if_pos h, if_pos h]
    cases rec.out <;> rfl
  · rw [if_neg h, if_neg h]

theorem adaTranscript_eraseG (P : StreamParams) (lab : BankLabel) (g : Ghost) :
    adaTranscript P lab (eraseG g) = adaTranscript P lab g := by
  unfold adaTranscript eraseG
  rw [List.filterMap_map]
  rfl

/-! ## Query values -/

theorem splitBlocks_flatten_map (F : Row → ℕ) :
    ∀ blks : List (List Row),
      splitBlocks (blks.map List.length) (blks.flatten.map F) = blks.map (fun blk => blk.map F)
  | [] => rfl
  | blk :: rest => by
    simp only [List.map_cons, List.flatten_cons, List.map_append, splitBlocks]
    rw [List.take_left' (by simp), List.drop_left' (by simp), splitBlocks_flatten_map F rest]

/-- **The query values handed to the bank's ADA module are B's core values of the request on the sample seeds**
(the rows are hypothetical rows of their seeds under the bank's history). -/
theorem adaVals_eq_coreVals (P : StreamParams) (mode : Mode) (c : ℚ) (B : Bank) (hist : List RowOp)
    (hrows : ∀ blk ∈ B.ada, ∀ r ∈ blk, RowOK P hist r)
    (hshape : B.ada.map List.length = (bankAda P).blockSizes) (isI : Bool) (l u : ℚ) :
    adaVals P mode c B = coreVals (bankAda P) (sOf P B.ada)
      ⟨fun ζ => queryIdx (bankAda P).qA P.L c (regZ P mode (rowFun P hist ζ)), isI, l, u⟩ := by
  unfold coreVals adaVals
  have hN : (bankAda P).N = B.ada.flatten.length := by
    rw [AdaParams.N, ← hshape, List.length_flatten]
  have hofFn : List.ofFn (fun ℓ : Fin (bankAda P).N =>
      queryIdx (bankAda P).qA P.L c (regZ P mode (rowFun P hist (sOf P B.ada ℓ)))) =
      B.ada.flatten.map (fun r => queryIdx (bankAda P).qA P.L c (regZ P mode r)) := by
    apply List.ext_getElem
    · simp [hN, List.length_flatten, Function.comp_def]
    · intro i h1 h2
      have hi : i < B.ada.flatten.length := by
        simpa [List.length_flatten, Function.comp_def] using h2
      obtain ⟨blk, hblk, hrb⟩ := List.mem_flatten.mp (List.getElem_mem hi)
      have hok := hrows blk hblk _ hrb
      simp only [List.getElem_ofFn, List.getElem_map, sOf, List.getD_eq_getElem _ _ hi]
      rw [← hok.2]
  rw [hofFn, ← hshape, splitBlocks_flatten_map]

end F2e2e.C.Closure
