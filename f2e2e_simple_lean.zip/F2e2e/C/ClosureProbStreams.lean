import F2e2e.C.ClosureEvents

/-!
# Theorem 6.4, probability layer (C-PROB): tapes, laws and per-component blocks of fresh bits

Paper: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof`, information flow and failure budget
(L1271–1285). The probability model of Theorem C (C-TOP): `m + 1` uniform tapes of `tapeBits P` bits; C-TOP's
`sum_tapes_run_eq` turns tape counts of the canonical run into the law of the sequential interaction.

This file:
* `roundT`, `interactT`: the tagged instrumented interaction (C-CLOSE's `algInitL`, `algStepL`), whose merge is the
  sequential interaction of the instrumented algorithm `theAlgL` (`merge_interactT`);
* `ncard_run_eq_law`: the number of tape tuples on which the final configuration of the instrumented canonical run
  satisfies an event is `2^N` times the law of the event under the merged tagged interaction;
* `readsLE_of_depth`, `depth_interactT_le`: every tag is read at most `N = (m+1)·tapeBits P` times;
* `pairStreams`, `law_le_of_blocks`: the two-block form of the multi-stream lemma (`TBitProg.sum_streams_eq`): after
  retagging the bits of one component `Λ` as `true` and all others as `false`, a bound `ξ·2^{nΛ}` on the number of
  bad `Λ`-streams for every fixed `O`-stream bounds the law of the event by `ξ`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top
open TBitProg
open scoped ENNReal

/-! ## The tagged instrumented interaction -/

/-- One tagged round of the instrumented interaction from the configuration `o` (as C-TOP's `roundProg`). -/
def roundT (P : StreamParams) (adv : StreamAdversary P.n) :
    Option ((State × Ghost) × List ℚ) → TBitProg Tag (Option ((State × Ghost) × List ℚ))
  | none => TBitProg.pure none
  | some c => (algStepL P c.1 (adv c.2)).map fun r => some (r.1, c.2 ++ [r.2])

/-- The tagged instrumented interaction up to round `t` (initialization, then the rounds `0, …, t-1`). -/
def interactT (P : StreamParams) (adv : StreamAdversary P.n) :
    ℕ → TBitProg Tag (Option ((State × Ghost) × List ℚ))
  | 0 => (algInitL P).map fun s => some (s, [])
  | t + 1 => (interactT P adv t).bind (roundT P adv)

/-- Forgetting the tags of the tagged interaction gives the sequential interaction of `theAlgL`. -/
theorem merge_interactT (P : StreamParams) (adv : StreamAdversary P.n) (t : ℕ) :
    (interactT P adv t).merge =
      interact (algInitL P).merge (fun sg u => (algStepL P sg u).merge) adv t := by
  induction t with
  | zero => exact merge_map _ _
  | succ t ih =>
    show ((interactT P adv t).bind (roundT P adv)).merge =
      (interact (algInitL P).merge (fun sg u => (algStepL P sg u).merge) adv t).bind
        (roundProg (fun sg u => (algStepL P sg u).merge) adv)
    rw [merge_bind, ih]
    congr 1
    funext o
    cases o with
    | none => rfl
    | some c => exact merge_map _ _

/-- Generic form of the tape count: a sum of indicators along a map `R` equal to `2^N` times an expectation under
`ν` turns into a set cardinality equal to `2^N` times the outer measure of the event. -/
theorem ncard_eq_of_sum_indicator {T γ : Type} [Fintype T] (R : T → Option γ) (E : γ → Prop)
    (μ ν : PMF (Option γ)) (hμν : μ = ν) (N : ℕ)
    (h : ∑ t, ({o | ∃ c, o = some c ∧ E c} : Set (Option γ)).indicator 1 (R t) =
      (2 : ℝ≥0∞) ^ N * ∑' o, ν o * ({o | ∃ c, o = some c ∧ E c} : Set (Option γ)).indicator 1 o) :
    (({t | ∃ c, R t = some c ∧ E c} : Set T).ncard : ℝ≥0∞) =
      2 ^ N * μ.toOuterMeasure {o | ∃ c, o = some c ∧ E c} := by
  classical
  subst hμν
  set S : Set (Option γ) := {o | ∃ c, o = some c ∧ E c} with hS
  have hset : ({t | ∃ c, R t = some c ∧ E c} : Set T) = ↑(Finset.univ.filter fun t => R t ∈ S) := by
    ext t; simp [hS]
  rw [hset, Set.ncard_coe_finset, PMF.toOuterMeasure_apply]
  have hl : ((Finset.univ.filter fun t => R t ∈ S).card : ℝ≥0∞) = ∑ t, S.indicator 1 (R t) := by
    rw [Finset.card_eq_sum_ones, Nat.cast_sum, Finset.sum_filter]
    refine Finset.sum_congr rfl fun t _ => ?_
    by_cases ht : R t ∈ S
    · rw [if_pos ht, Set.indicator_of_mem ht]; simp
    · rw [if_neg ht, Set.indicator_of_notMem ht]
  rw [hl, h]
  congr 1
  refine tsum_congr fun o => ?_
  by_cases ho : o ∈ S
  · rw [Set.indicator_of_mem ho, Set.indicator_of_mem ho]; simp
  · rw [Set.indicator_of_notMem ho, Set.indicator_of_notMem ho, mul_zero]

/-- **Tape count = law**, for any event of the final configuration of the instrumented canonical run. -/
theorem ncard_run_eq_law (P : StreamParams) (adv : StreamAdversary P.n)
    (E : (State × Ghost) × List ℚ → Prop) :
    ((({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ E c} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ≥0∞)) =
      2 ^ ((P.m + 1) * tapeBits P) *
        (interactT P adv P.m).merge.law.toOuterMeasure {o | ∃ c, o = some c ∧ E c} := by
  classical
  exact ncard_eq_of_sum_indicator (T := Fin (P.m + 1) → Fin (tapeBits P) → Bool)
    (γ := (State × Ghost) × List ℚ) (fun tapes => theAlgL.run P adv tapes P.m) E _ _
    (congrArg BitProg.law (merge_interactT P adv P.m)) _
    (sum_tapes_run_eq (A := theAlgL) adv (algInitL P).merge
      (fun sg u => (algStepL P sg u).merge) (fun _ => rfl) (fun _ _ _ => rfl)
      (theAlgL_init_depth P) (fun sg u => theAlgL_step_depth P sg u) P.m le_rfl _)

/-! ## Read bounds -/

/-- A program reads every tag at most as often as its merge reads bits. -/
theorem readsLE_of_depth {ι α : Type} [DecidableEq ι] :
    ∀ (p : TBitProg ι α) (d : ℕ), p.merge.depth ≤ d → ReadsLE p (fun _ => d)
  | TBitProg.pure _, _, _ => trivial
  | TBitProg.bit i k, d, h => by
    rw [merge_bit] at h
    have hk : ∀ b, (k b).merge.depth + 1 ≤ d := fun b =>
      le_trans (BitProg.depth_le_bit (fun b => (k b).merge) b) h
    refine ⟨by have := hk true; show 0 < d; omega, fun b => ?_⟩
    refine ReadsLE.mono (readsLE_of_depth (k b) (d - 1) (by have := hk b; omega)) (fun j => ?_)
    by_cases hj : j = i
    · subst hj; simp
    · simp [Function.update_of_ne hj]

/-- The tagged interaction up to round `m` reads at most `N = (m+1)·tapeBits P` bits. -/
theorem depth_interact_le (P : StreamParams) (adv : StreamAdversary P.n) (t : ℕ) :
    (interact (algInitL P).merge (fun sg u => (algStepL P sg u).merge) adv t).depth ≤
      (t + 1) * tapeBits P := by
  induction t with
  | zero =>
    show ((algInitL P).merge.map _).depth ≤ (0 + 1) * tapeBits P
    rw [BitProg.depth_map]
    simpa using theAlgL_init_depth P
  | succ t ih =>
    show ((interact (algInitL P).merge (fun sg u => (algStepL P sg u).merge) adv t).bind
      (roundProg (fun sg u => (algStepL P sg u).merge) adv)).depth ≤ (t + 1 + 1) * tapeBits P
    refine le_trans (BitProg.depth_bind_le _ _ (n := tapeBits P) fun o => ?_) ?_
    · cases o with
      | none => exact Nat.zero_le _
      | some c =>
        show ((algStepL P c.1 (adv c.2)).merge.map _).depth ≤ tapeBits P
        rw [BitProg.depth_map]
        exact theAlgL_step_depth P c.1 (adv c.2)
    · rw [add_mul (t + 1) 1, one_mul]
      exact Nat.add_le_add_right ih _

/-- The tagged interaction up to round `m` reads at most `N = (m+1)·tapeBits P` bits. -/
theorem depth_interactT_le (P : StreamParams) (adv : StreamAdversary P.n) :
    (interactT P adv P.m).merge.depth ≤ (P.m + 1) * tapeBits P := by
  rw [merge_interactT]
  exact depth_interact_le P adv P.m

/-! ## Two blocks of streams -/

/-- The per-tag tapes of a two-tag program: `l` for the tag `true` (the selected component), `a` for `false`. -/
def pairStreams (a l : List Bool) : Bool → List Bool := fun b => if b then l else a

open Classical in
/-- **Two-block form of the multi-stream lemma**: if on every path the selected component (`true`) is read at most
`nΛ` times and the rest at most `nO` times, and for every `O`-stream `a` of length `nO` at most `ξ·2^{nΛ}` of the
`Λ`-streams of length `nΛ` produce an outcome in `E`, then the law of the merged program gives `E` probability at
most `ξ`. -/
theorem law_le_of_blocks {α : Type} (p : TBitProg Bool α) (nΛ nO : ℕ)
    (hp : ReadsLE p (fun b => if b then nΛ else nO)) (E : Set α) (ξ : ℝ≥0∞)
    (h : ∀ a ∈ lenFinset nO,
      ∑ l ∈ lenFinset nΛ,
          (if ∃ x, (p.runS (pairStreams a l)).map Prod.fst = some x ∧ x ∈ E then (1 : ℝ≥0∞) else 0) ≤
        ξ * 2 ^ nΛ) :
    p.merge.law.toOuterMeasure E ≤ ξ := by
  classical
  set n : Bool → ℕ := fun b => if b then nΛ else nO with hn
  have hsum := sum_streams_eq p n hp (E.indicator 1)
  have hN : ∑ b, n b = nΛ + nO := by
    rw [Fintype.sum_bool, hn]
    simp
  have hval : ∀ σ : Bool → List Bool, ((p.runS σ).map Prod.fst).elim 0 (E.indicator 1) =
      if ∃ x, (p.runS σ).map Prod.fst = some x ∧ x ∈ E then (1 : ℝ≥0∞) else 0 := by
    intro σ
    cases hr : (p.runS σ).map Prod.fst with
    | none => simp
    | some x =>
      by_cases hx : x ∈ E
      · rw [if_pos ⟨x, rfl, hx⟩]; simp [Set.indicator_of_mem hx]
      · rw [if_neg (by rintro ⟨y, hy, hyE⟩; cases hy; exact hx hyE)]
        simp [Set.indicator_of_notMem hx]
  have hLHS : ∑ σ ∈ streams n, ((p.runS σ).map Prod.fst).elim 0 (E.indicator 1) =
      ∑ al ∈ lenFinset nO ×ˢ lenFinset nΛ,
        (if ∃ x, (p.runS (pairStreams al.1 al.2)).map Prod.fst = some x ∧ x ∈ E
          then (1 : ℝ≥0∞) else 0) := by
    simp_rw [hval]
    refine Finset.sum_nbij' (fun σ => (σ false, σ true)) (fun al => pairStreams al.1 al.2)
      ?_ ?_ ?_ ?_ ?_
    · intro σ hσ
      rw [mem_streams] at hσ
      simp only [Finset.mem_product, mem_lenFinset]
      exact ⟨hσ false, hσ true⟩
    · intro al hal
      simp only [Finset.mem_product, mem_lenFinset] at hal
      rw [mem_streams]
      intro b
      cases b
      · exact hal.1
      · exact hal.2
    · intro σ _
      funext b
      cases b <;> rfl
    · intro al _
      rfl
    · intro σ _
      have : pairStreams (σ false) (σ true) = σ := by
        funext b
        cases b <;> rfl
      rw [this]
  rw [hLHS, Finset.sum_product, hN] at hsum
  have hbound : ∑ a ∈ lenFinset nO, ∑ l ∈ lenFinset nΛ,
      (if ∃ x, (p.runS (pairStreams a l)).map Prod.fst = some x ∧ x ∈ E
        then (1 : ℝ≥0∞) else 0) ≤ 2 ^ nO * (ξ * 2 ^ nΛ) := by
    calc _ ≤ ∑ _a ∈ lenFinset nO, ξ * 2 ^ nΛ := Finset.sum_le_sum fun a ha => h a ha
      _ = 2 ^ nO * (ξ * 2 ^ nΛ) := by rw [Finset.sum_const, card_lenFinset, nsmul_eq_mul]; norm_cast
  rw [hsum] at hbound
  have hmeas : p.merge.law.toOuterMeasure E = ∑' x, p.merge.law x * E.indicator 1 x := by
    rw [PMF.toOuterMeasure_apply]
    refine tsum_congr fun x => ?_
    by_cases hx : x ∈ E
    · simp [Set.indicator_of_mem hx]
    · simp [Set.indicator_of_notMem hx]
  rw [hmeas]
  have h2 : (2 : ℝ≥0∞) ^ (nΛ + nO) ≠ 0 := by positivity
  have h2' : (2 : ℝ≥0∞) ^ (nΛ + nO) ≠ ⊤ := ENNReal.pow_ne_top ENNReal.ofNat_ne_top
  have : 2 ^ nO * (ξ * 2 ^ nΛ) = 2 ^ (nΛ + nO) * ξ := by rw [pow_add]; ring
  rw [this] at hbound
  exact (ENNReal.mul_le_mul_iff_right h2 h2').1 hbound

/-! ## From block counts to tape counts -/

/-- The cardinality of a decidable subset of a finite type as a filter. -/
theorem ncard_setOf_eq_card_filter {T : Type} [Fintype T] (p : T → Prop) [DecidablePred p] :
    ({t | p t} : Set T).ncard = (Finset.univ.filter p).card := by
  rw [← Set.ncard_coe_finset]
  congr 1
  ext t
  simp

/-- From a bound on the law of the tagged interaction to the tape count. -/
theorem card_le_of_law_le (P : StreamParams) (adv : StreamAdversary P.n)
    (E : (State × Ghost) × List ℚ → Prop) (x : ℝ) (hx : 0 ≤ x)
    (h : (interactT P adv P.m).merge.law.toOuterMeasure {o | ∃ c, o = some c ∧ E c} ≤
      ENNReal.ofReal x) :
    (({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ E c} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      x * 2 ^ ((P.m + 1) * tapeBits P) := by
  have h2 : ((({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ E c} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ≥0∞)) ≤
      ENNReal.ofReal (x * 2 ^ ((P.m + 1) * tapeBits P)) := by
    calc _ = 2 ^ ((P.m + 1) * tapeBits P) *
          (interactT P adv P.m).merge.law.toOuterMeasure {o | ∃ c, o = some c ∧ E c} :=
          ncard_run_eq_law P adv E
      _ ≤ 2 ^ ((P.m + 1) * tapeBits P) * ENNReal.ofReal x := by gcongr
      _ = ENNReal.ofReal (x * 2 ^ ((P.m + 1) * tapeBits P)) := by
          rw [ENNReal.ofReal_mul hx, ENNReal.ofReal_pow (by norm_num), ENNReal.ofReal_ofNat, mul_comm]
  have h3 := ENNReal.toReal_le_of_le_ofReal (by positivity) h2
  simpa using h3

open Classical in
/-- `law_le_of_blocks` with a single read bound `N` on the merged program. -/
theorem law_le_of_blocks_depth {α : Type} (q : TBitProg Bool α) (N : ℕ) (hq : q.merge.depth ≤ N)
    (E : Set α) (ξ : ℝ≥0∞)
    (h : ∀ nΛ nO : ℕ, ReadsLE q (fun b => if b then nΛ else nO) →
      ∀ a ∈ lenFinset nO,
        ∑ l ∈ lenFinset nΛ,
            (if ∃ y, (q.runS (pairStreams a l)).map Prod.fst = some y ∧ y ∈ E then (1 : ℝ≥0∞) else 0) ≤
          ξ * 2 ^ nΛ) :
    q.merge.law.toOuterMeasure E ≤ ξ := by
  have h1 : ReadsLE q (fun _ => N) := readsLE_of_depth q N hq
  have e : (fun _ : Bool => N) = fun b : Bool => if b then N else N := by
    funext b; exact (ite_self _).symm
  rw [e] at h1
  exact law_le_of_blocks q N N h1 E ξ (h N N h1)

open Classical in
/-- **From per-block counts to the tape count**: if, after retagging the bits by `sel`, for all read bounds and
every fixed `false`-stream at most an `x` fraction of the `true`-streams gives an outcome in the event, then the
event occurs on at most an `x` fraction of the tapes of the instrumented canonical run. -/
theorem card_le_of_blocks (P : StreamParams) (adv : StreamAdversary P.n) (sel : Tag → Bool)
    (E : (State × Ghost) × List ℚ → Prop) (S : Set (Option ((State × Ghost) × List ℚ)))
    (hS : S = {o | ∃ c, o = some c ∧ E c}) (x : ℝ) (hx : 0 ≤ x)
    (h : ∀ nΛ nO : ℕ, ReadsLE ((interactT P adv P.m).retag sel) (fun b => if b then nΛ else nO) →
      ∀ a ∈ lenFinset nO,
        ∑ l ∈ lenFinset nΛ,
            (if ∃ y, (((interactT P adv P.m).retag sel).runS (pairStreams a l)).map Prod.fst = some y ∧
                y ∈ S then (1 : ℝ≥0∞) else 0) ≤
          ENNReal.ofReal x * 2 ^ nΛ) :
    (({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ E c} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      x * 2 ^ ((P.m + 1) * tapeBits P) := by
  refine card_le_of_law_le P adv E x hx ?_
  have hd : ((interactT P adv P.m).retag sel).merge.depth ≤ (P.m + 1) * tapeBits P := by
    rw [merge_retag]; exact depth_interactT_le P adv
  have hle := law_le_of_blocks_depth ((interactT P adv P.m).retag sel) _ hd S (ENNReal.ofReal x) h
  rw [merge_retag, hS] at hle
  exact hle

end F2e2e.C.Closure
