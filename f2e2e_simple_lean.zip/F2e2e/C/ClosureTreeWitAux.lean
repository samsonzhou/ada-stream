import Mathlib
import F2e2e.C.ClosureInv
import F2e2e.C.Alg.Facts

/-!
# Theorem 6.4, witness side (helpers): exact error witnesses, precisions, range bounds

Source: `parts/partIII.tex` Lemma `R:lem:sec6-precision` (ii) (scale tags; the recurrence `e⁺ = c e + ζ`, eq.
`R:eq:pathwise-expansion-identity`, L1047–1066), Lemma `R:lem:sec6-covariant-cache` (caches: exponent `2`, the fresh
measurement at a birth or refresh, the guard increment `δ²`, the covariance inequality
`R:eq:covariance-inequality`), Lemma `R:lem:terminal-accumulator` (the terminal accumulator, with the post-use `c²`
updates of Algorithm `R:alg:within-round-tree` L507), and the range checks of the algorithm (partIII.tex L452:
tags in `[0, C_max]`, caches and accumulator in `[0, A_max]`).

Generic in the event: each transport lemma takes the witness at the tree shadow `S` and the facts about the event
(the new shadow and the new stored value), and returns the witness at the next moment with one more event
(`nev + 1`) when a rounding error is added. The event-specific facts are C-TREE's shadow lemmas (`Tree.TreeState.*`)
and the window algebra of `F2e2e/C/ClosurePws.lean` (`pws_*`, `winProd_correct_lt`).

* `TagW` (Lemma 6.1 (ii)): `tagW_of_eq` (a birth: `Ĉ_d = C_d = 1`), `tagW_congr` (events that change neither
  `C_d` nor the windows of the ancestors), `tagW_correct_lt` (an ancestor correction with multiplier `c` and the
  new rounded tag `Ĉ⁺`, `|Ĉ⁺ − cĈ| ≤ h_C`).
* `CacheW` (Lemma 6.2): `cacheW_fresh` (a birth or refresh: `|P − E| ≤ 2^{-13}ηE + ω + h_P`), `cacheW_congr`,
  `cacheW_add` (an own guard: `E⁺ = E + δ²`, `|P⁺ − (P + δ²)| ≤ h_P`), `cacheW_correct_lt` (an ancestor correction:
  `E⁺ = c²E`, `|P⁺ − c²P| ≤ h_P`).
* `LeafW` (Lemma 5.3 with the post-use updates): `leafW_of_eq`, `leafW_congr`, `leafW_correct_lt`
  (`‖x_H⁺‖² = c²‖x_H‖²`, `|lf⁺ − c² lf| ≤ h_leaf`).
* `WitSide`: the fields of `TreePart` maintained by the witness side; `TreePart.mk_wit`, `TreePart.toWit`.
* The precisions at a moment, from any tree invariant: `tagPrec_of` (`|Ĉ_d − C_d| ≤ e_C`), `cachePrec_of`
  (hypothesis (H2) of Theorem 5.9), `leafPrec_of` (`|lf − ‖x_H‖²| ≤ TG²h_leaf ≤ 1/64`, `wit_T_G_sq_hleaf_le`);
  `TreePart.tagPrec`, `TreePart.cachePrec`.
* Range helpers: `wit_inRangeA_of_le` (`0 ≤ x ≤ 16(V+1)² ≤ A_max`), `wit_inRangeC_of_le` (`0 ≤ x ≤ 8(B^H+1) ≤ C_max`),
  `wit_vec_sq` (the squared vector bounds `≤ V²` of C-TREE's `vector_bounds_inv`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Window helpers -/

/-- The empty window (start round `t + 1`) has product `1`. -/
theorem wit_winProd_fresh (S : Tree.TreeSt P) (D : ℕ) : winProd S D (fun _ => S.t + 1) = 1 := by
  unfold winProd
  apply Finset.prod_eq_one
  intro j _
  show Tree.intervalProd (S.log j) (S.t + 1) S.t = 1
  exact Tree.intervalProd_eq_one _ _ _ (fun e _ he => by omega)

/-- Equal weighted sums (exponent `1`) give equal window products. -/
theorem wit_winProd_eq_of_pws {S S' : Tree.TreeSt P} {D : ℕ} (h : ∀ L, pws S' D 1 L = pws S D 1 L)
    (a : ℕ → ℕ) : winProd S' D a = winProd S D a := by
  have h1 := h [(a, 1)]
  simpa [pws] using h1

/-- The weights of a shifted list are those of the original list. -/
theorem wit_mem_winShift {d t : ℕ} {L : List ((ℕ → ℕ) × ℝ)} {x : (ℕ → ℕ) × ℝ} (hx : x ∈ winShift d t L) :
    ∃ y ∈ L, x.2 = y.2 := by
  unfold winShift at hx
  obtain ⟨y, hy, rfl⟩ := List.mem_map.1 hx
  exact ⟨y, hy, rfl⟩

/-- A shifted list with one new term: its weights are bounded by `h` if the old ones and the new one are. -/
theorem wit_weights_winShift_snoc {d t : ℕ} {L : List ((ℕ → ℕ) × ℝ)} {a : ℕ → ℕ} {w h : ℝ}
    (hL : ∀ x ∈ L, |x.2| ≤ h) (hw : |w| ≤ h) : ∀ x ∈ winShift d t L ++ [(a, w)], |x.2| ≤ h := by
  intro x hx
  rcases List.mem_append.1 hx with hx | hx
  · obtain ⟨y, hy, hxy⟩ := wit_mem_winShift hx
    rw [hxy]
    exact hL y hy
  · rw [List.mem_singleton] at hx
    rw [hx]
    exact hw

/-- A list with one new term: its weights are bounded by `h` if the old ones and the new one are. -/
theorem wit_weights_snoc {L : List ((ℕ → ℕ) × ℝ)} {a : ℕ → ℕ} {w h : ℝ}
    (hL : ∀ x ∈ L, |x.2| ≤ h) (hw : |w| ≤ h) : ∀ x ∈ L ++ [(a, w)], |x.2| ≤ h := by
  intro x hx
  rcases List.mem_append.1 hx with hx | hx
  · exact hL x hx
  · rw [List.mem_singleton] at hx
    rw [hx]
    exact hw

theorem wit_length_winShift_snoc (d t : ℕ) (L : List ((ℕ → ℕ) × ℝ)) (x : (ℕ → ℕ) × ℝ) {nev : ℕ}
    (h : L.length ≤ nev) : (winShift d t L ++ [x]).length ≤ nev + 1 := by
  rw [List.length_append, length_winShift, List.length_singleton]
  omega

theorem wit_length_snoc_le (L : List ((ℕ → ℕ) × ℝ)) (x : (ℕ → ℕ) × ℝ) {nev : ℕ} (h : L.length ≤ nev) :
    (L ++ [x]).length ≤ nev + 1 := by
  rw [List.length_append, List.length_singleton]
  omega

/-- The energy of a strict descendant after a correction of depth `d` by `c`: `E_{d'}⁺ = c² E_{d'}`. -/
theorem wit_E_correct_lt (S : Tree.TreeSt P) {d d' : ℕ} (c : ℝ) (h : d < d') :
    (S.step P (.correct d c)).E d' = c ^ 2 * S.E d' := by
  unfold Tree.TreeState.E
  rw [Tree.TreeState.step_correct_r, if_neg (by omega), if_pos h, norm_smul, Real.norm_eq_abs, mul_pow,
    sq_abs]

/-! ## Lemma 6.1 (ii): tags -/

/-- An exact tag (at a birth: `Ĉ_d = C_d = 1`) has the empty witness. -/
theorem tagW_of_eq {S : Tree.TreeSt P} {d nev : ℕ} {Ch : ℝ} (h : Ch = S.C d) : TagW P S d nev Ch :=
  ⟨[], by rw [h, sub_self, pws_nil], by simp, by simp⟩

/-- Events that change neither `C_d` nor the windows of the ancestors of `d` keep the witness. -/
theorem tagW_congr {S S' : Tree.TreeSt P} {d nev : ℕ} {Ch : ℝ} (h : TagW P S d nev Ch)
    (hC : S'.C d = S.C d) (hw : ∀ a, winProd S' d a = winProd S d a) : TagW P S' d nev Ch := by
  obtain ⟨L, h1, h2, h3⟩ := h
  exact ⟨L, by rw [hC, pws_congr hw]; exact h1, h2, h3⟩

/-- **An ancestor correction** (depth `d < d'`, multiplier `c`, the current record of depth `d` pending): the
rescaled tag `Ĉ⁺` with `|Ĉ⁺ − cĈ| ≤ h_C` keeps the witness, with one more rounding error. -/
theorem tagW_correct_lt {S : Tree.TreeSt P} {d d' nev : ℕ} {Ch Ch' c : ℝ} (h : TagW P S d' nev Ch)
    (hdd : d < d') {e : Tree.LogEntry} {l : List Tree.LogEntry} (hlog : S.log d = e :: l)
    (het : e.t = S.t) (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < S.t)
    (hround : |Ch' - c * Ch| ≤ (P.hC : ℝ)) :
    TagW P (S.step P (.correct d c)) d' (nev + 1) Ch' := by
  obtain ⟨L, h1, h2, h3⟩ := h
  refine ⟨winShift d S.t L ++ [(fun _ => (S.step P (.correct d c)).t + 1, Ch' - c * Ch)], ?_,
    wit_length_winShift_snoc d S.t L _ h2, wit_weights_winShift_snoc h3 hround⟩
  rw [pws_snoc, pws_correct_lt S d' 1 L hdd c hlog het hpend hl, ← h1, Tree.TreeState.step_correct_C,
    if_pos hdd]
  ring

/-! ## Lemma 6.2: caches -/

/-- **A fresh measurement** (the birth cache, or the `DIFF` refresh after a correction): if
`|P − E| ≤ 2^{-13}ηE + ω + h_P` then the witness holds with the empty window and no further errors. -/
theorem cacheW_fresh {S : Tree.TreeSt P} {d nev : ℕ} {Pc : ℝ}
    (h : |Pc - S.E d| ≤ (1 / 2) ^ 13 * (P.eta : ℝ) * S.E d + (P.omega : ℝ) + (P.hP : ℝ)) :
    CacheW P S d nev Pc := by
  refine ⟨fun _ => S.t + 1, Pc - S.E d, S.E d, [], ?_, ?_, h, ?_, by simp, by simp⟩
  · rw [wit_winProd_fresh, pws_nil]
    ring
  · unfold Tree.TreeState.E
    positivity
  · rw [wit_winProd_fresh, one_pow, mul_one]

/-- Events that change neither `E_d` nor the windows of the ancestors of `d` keep the witness. -/
theorem cacheW_congr {S S' : Tree.TreeSt P} {d nev : ℕ} {Pc : ℝ} (h : CacheW P S d nev Pc)
    (hE : S'.E d = S.E d) (hw : ∀ a, winProd S' d a = winProd S d a) : CacheW P S' d nev Pc := by
  obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := h
  refine ⟨a0, b, E0, L, ?_, h2, h3, ?_, h5, h6⟩
  · rw [hE, hw, pws_congr hw]
    exact h1
  · rw [hw, hE]
    exact h4

/-- **An own guard** (Step 3 at depth `d`): `E_d⁺ = E_d + δ²` (fresh guard coordinate) and the cache update
`P⁺ = round_{h_P}(P + δ²)`, `|P⁺ − (P + δ²)| ≤ h_P`, keep the witness with one more rounding error. -/
theorem cacheW_add {S S' : Tree.TreeSt P} {d nev : ℕ} {Pc Pc' δ2 : ℝ} (h : CacheW P S d nev Pc)
    (hδ : 0 ≤ δ2) (hE : S'.E d = S.E d + δ2) (hw : ∀ a, winProd S' d a = winProd S d a)
    (hround : |Pc' - (Pc + δ2)| ≤ (P.hP : ℝ)) : CacheW P S' d (nev + 1) Pc' := by
  obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := h
  refine ⟨a0, b, E0, L ++ [(fun _ => S'.t + 1, Pc' - (Pc + δ2))], ?_, h2, h3, ?_,
    wit_length_snoc_le L _ h5, wit_weights_snoc h6 hround⟩
  · rw [pws_snoc, hw, pws_congr hw, hE]
    linarith
  · rw [hw, hE]
    linarith

/-- **An ancestor correction** (depth `d < d'`, multiplier `c`): `E_{d'}⁺ = c²E_{d'}` and the rescaled cache
`P⁺ = round_{h_P}(c²P)`, `|P⁺ − c²P| ≤ h_P`, keep the witness (window shifted, covariance inequality multiplied
by `c²`) with one more rounding error. -/
theorem cacheW_correct_lt {S : Tree.TreeSt P} {d d' nev : ℕ} {Pc Pc' c : ℝ} (h : CacheW P S d' nev Pc)
    (hdd : d < d') {e : Tree.LogEntry} {l : List Tree.LogEntry} (hlog : S.log d = e :: l)
    (het : e.t = S.t) (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < S.t)
    (hround : |Pc' - c ^ 2 * Pc| ≤ (P.hP : ℝ)) :
    CacheW P (S.step P (.correct d c)) d' (nev + 1) Pc' := by
  obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := h
  have hW := winProd_correct_lt S hdd c hlog het hpend hl a0
  have hE := wit_E_correct_lt S c hdd
  refine ⟨Function.update a0 d (min (a0 d) S.t), b, E0,
    winShift d S.t L ++ [(fun _ => (S.step P (.correct d c)).t + 1, Pc' - c ^ 2 * Pc)], ?_, h2, h3, ?_,
    wit_length_winShift_snoc d S.t L _ h5, wit_weights_winShift_snoc h6 hround⟩
  · rw [pws_snoc, pws_correct_lt S d' 2 L hdd c hlog het hpend hl, hW, hE]
    have e1 : pws S d' 2 L = Pc - S.E d' - b * winProd S d' a0 ^ 2 := by linarith
    rw [e1]
    ring
  · rw [hW, hE]
    calc E0 * (c * winProd S d' a0) ^ 2 = c ^ 2 * (E0 * winProd S d' a0 ^ 2) := by ring
      _ ≤ c ^ 2 * S.E d' := mul_le_mul_of_nonneg_left h4 (sq_nonneg c)

/-! ## Lemma 5.3: the terminal accumulator -/

/-- An exact accumulator (during Steps 2–3) has the empty witness. -/
theorem leafW_of_eq {S : Tree.TreeSt P} {nev : ℕ} {lf : ℝ} (h : lf = ‖S.x P.H‖ ^ 2) : LeafW P S nev lf :=
  ⟨[], by rw [h, sub_self, pws_nil], by simp, by simp⟩

/-- Events that change neither `x_H` nor the windows keep the witness. -/
theorem leafW_congr {S S' : Tree.TreeSt P} {nev : ℕ} {lf : ℝ} (h : LeafW P S nev lf)
    (hx : S'.x P.H = S.x P.H) (hw : ∀ a, winProd S' P.H a = winProd S P.H a) : LeafW P S' nev lf := by
  obtain ⟨L, h1, h2, h3⟩ := h
  exact ⟨L, by rw [hx, pws_congr hw]; exact h1, h2, h3⟩

/-- **A correction of depth `d < H`** with multiplier `c`: `x_H⁺ = c x_H` (Lemma 5.4 (i)) and the post-use
update `lf⁺ = round_{h_leaf}(c² lf)`, `|lf⁺ − c² lf| ≤ h_leaf`, keep the witness with one more rounding error. -/
theorem leafW_correct_lt {S : Tree.TreeSt P} {d nev : ℕ} {lf lf' c : ℝ} (h : LeafW P S nev lf)
    (hd : d < P.H) {e : Tree.LogEntry} {l : List Tree.LogEntry} (hlog : S.log d = e :: l)
    (het : e.t = S.t) (hpend : e.out = .pending) (hl : ∀ e' ∈ l, e'.t < S.t)
    (hround : |lf' - c ^ 2 * lf| ≤ (P.hleaf : ℝ)) :
    LeafW P (S.step P (.correct d c)) (nev + 1) lf' := by
  obtain ⟨L, h1, h2, h3⟩ := h
  have hx : (S.step P (.correct d c)).x P.H = c • S.x P.H :=
    (Tree.TreeState.correct_rescale P S d c).2.2 P.H hd
  refine ⟨winShift d S.t L ++ [(fun _ => (S.step P (.correct d c)).t + 1, lf' - c ^ 2 * lf)], ?_,
    wit_length_winShift_snoc d S.t L _ h2, wit_weights_winShift_snoc h3 hround⟩
  rw [pws_snoc, pws_correct_lt S P.H 2 L hd c hlog het hpend hl, ← h1, hx, norm_smul, Real.norm_eq_abs,
    mul_pow, sq_abs]
  ring

/-! ## Monotonicity in the event count -/

theorem TagW.mono {S : Tree.TreeSt P} {d nev nev' : ℕ} {Ch : ℝ} (h : TagW P S d nev Ch) (hn : nev ≤ nev') :
    TagW P S d nev' Ch := by
  obtain ⟨L, h1, h2, h3⟩ := h
  exact ⟨L, h1, h2.trans hn, h3⟩

theorem CacheW.mono {S : Tree.TreeSt P} {d nev nev' : ℕ} {Pc : ℝ} (h : CacheW P S d nev Pc)
    (hn : nev ≤ nev') : CacheW P S d nev' Pc := by
  obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := h
  exact ⟨a0, b, E0, L, h1, h2, h3, h4, h5.trans hn, h6⟩

theorem LeafW.mono {S : Tree.TreeSt P} {nev nev' : ℕ} {lf : ℝ} (h : LeafW P S nev lf) (hn : nev ≤ nev') :
    LeafW P S nev' lf := by
  obtain ⟨L, h1, h2, h3⟩ := h
  exact ⟨L, h1, h2.trans hn, h3⟩

/-! ## The witness side of the tree part -/

/-- The fields of `TreePart` maintained by the witness side (all but `tree`, `nLearners`, `bornZero`). -/
structure WitSide (P : StreamParams) (ph : Tree.Phase) (c : CState) (S : Tree.TreeSt P) (nev : ℕ) : Prop where
  root : 0 < ph.live P.H → (c.learners.getD 0 dfltLearner).tag = 2 ^ P.eHC
  tagW : ∀ d < ph.live P.H, TagW P S d nev (tagVal P c d)
  cacheW : ∀ d < ph.live P.H, CacheW P S d nev (cacheVal P c d)
  cacheNonneg : ∀ d < ph.live P.H, 0 ≤ (c.learners.getD d dfltLearner).cache
  tagNonneg : ∀ d < ph.live P.H, 0 ≤ (c.learners.getD d dfltLearner).tag
  leafExact : ∀ D, ph = .guards D → leafVal P c = ‖S.x P.H‖ ^ 2
  leafW : ∀ D, ph = .evals D → LeafW P S nev (leafVal P c)
  leafNonneg : leafPhase ph = true → 0 ≤ c.leaf

/-- Assemble the tree part from the tree side's fields and the witness side. -/
theorem TreePart.mk_wit {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (htree : Tree.TreeInv P ph (regsOf P c) S) (hnL : c.learners.length = ph.live P.H)
    (hbz : ∀ D, ph = .births D → firstBorn P.H S.t < D → S.x D = 0) (hw : WitSide P ph c S nev) :
    TreePart P ph c S nev :=
  ⟨htree, hnL, hw.root, hw.tagW, hw.cacheW, hw.cacheNonneg, hw.tagNonneg, hw.leafExact, hw.leafW,
    hw.leafNonneg, hbz⟩

/-- The witness side of a tree part. -/
theorem TreePart.toWit {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P ph c S nev) : WitSide P ph c S nev :=
  ⟨h.root, h.tagW, h.cacheW, h.cacheNonneg, h.tagNonneg, h.leafExact, h.leafW, h.leafNonneg⟩

/-! ## Parameter facts -/

/-- `1 ≤ G` (as a real). -/
theorem wit_one_le_G (P : StreamParams) : (1 : ℝ) ≤ (P.G : ℝ) := by
  have h := Tree.Bbar_pow_le_G P (D := 0) (Nat.zero_le _)
  rwa [pow_zero] at h

/-- `1 ≤ T` (as a real). -/
theorem wit_one_le_T (P : StreamParams) : (1 : ℝ) ≤ (P.T : ℝ) := by
  exact_mod_cast P.T_pos

/-- `T G h_C ≤ e_C` (eq. `R:eq:grid-eC-hC`). -/
theorem wit_T_hC_G_le_eC (P : StreamParams) :
    (P.T : ℝ) * (P.hC : ℝ) * (P.G : ℝ) ≤ (P.eC : ℝ) := by
  have h := (Rat.cast_le (K := ℝ)).mpr (StreamParams.hC_le P)
  push_cast at h
  have hT := wit_one_le_T P
  have hG := wit_one_le_G P
  have hTG : (0 : ℝ) < (P.T : ℝ) * (P.G : ℝ) := by nlinarith
  rw [le_div_iff₀ hTG] at h
  linarith

/-- The cache drift `2ωG² + TG²D_*h_P ≤ η³ν²/2^39 ≤ 1` (Theorem 5.9 (P2)). -/
theorem wit_cacheDrift_le_one (P : StreamParams) : Tree.cacheDrift P ≤ 1 := by
  have h2 := (Tree.step4Params_committed P).P2
  have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hν0 : (0 : ℝ) ≤ (P.nu : ℝ) := by exact_mod_cast P.nu_pos.le
  have hν1 : (P.nu : ℝ) ≤ 1 := by exact_mod_cast P.nu_lt_one.le
  have h3 : (P.eta : ℝ) ^ 3 * (P.nu : ℝ) ^ 2 ≤ 1 :=
    mul_le_one₀ (pow_le_one₀ hη0 hη1) (pow_nonneg hν0 2) (pow_le_one₀ hν0 hν1)
  have h4 : (P.eta : ℝ) ^ 3 * (P.nu : ℝ) ^ 2 / 2 ^ 39 ≤ 1 := by
    rw [div_le_one (by norm_num)]
    linarith
  linarith

/-- `8(H − d)η ≤ 1` (from (P1) of Theorem 5.9: `64(H+1)²η ≤ 2^{-14}`). -/
theorem wit_eight_Hd_eta_le (P : StreamParams) (d : ℕ) : 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) ≤ 1 := by
  have hP1 := (Tree.step4Params_committed P).P1
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hHd : ((P.H - d : ℕ) : ℝ) ≤ (P.H : ℝ) := Nat.cast_le.mpr (Nat.sub_le _ _)
  have hH0 : (0 : ℝ) ≤ (P.H : ℝ) := Nat.cast_nonneg _
  have h1 : 8 * ((P.H - d : ℕ) : ℝ) ≤ 64 * ((P.H : ℝ) + 1) ^ 2 := by nlinarith
  have h2 : 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) ≤ 64 * ((P.H : ℝ) + 1) ^ 2 * (P.eta : ℝ) :=
    mul_le_mul_of_nonneg_right h1 hη0.le
  have h3 : (1 : ℝ) / 2 ^ 14 ≤ 1 := by norm_num
  linarith

/-- **The accumulator's rounding budget** (Lemma 5.3): `T G² h_leaf ≤ 1/64`. Indeed `h_leaf ≤ h_g²`,
`G h_g = B^{H+2} h_g ≤ B · B^{2H} h_g = B γην/2^{20} = 16ην/2^{20} ≤ ν ≤ γ` (`B = 16/γ`, `H ≥ 1`,
`γη = 2^{H+20}ν`), and `Tγ² ≤ 1/64`. -/
theorem wit_T_G_sq_hleaf_le (P : StreamParams) : (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hleaf : ℝ) ≤ 1 / 64 := by
  have hγ0 : (0 : ℝ) < (P.gamma : ℝ) := by exact_mod_cast P.gamma_pos
  have hη0 : (0 : ℝ) < (P.eta : ℝ) := by exact_mod_cast P.eta_pos
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hν0 : (0 : ℝ) < (P.nu : ℝ) := by exact_mod_cast P.nu_pos
  have hB := Tree.B_eq_and_gt P
  have hg0 : (0 : ℝ) ≤ (P.hg : ℝ) := by
    have : (0 : ℚ) ≤ P.hg := by unfold StreamParams.hg; positivity
    exact_mod_cast this
  have hst0 : (0 : ℝ) ≤ (P.hstep : ℝ) := by
    have : (0 : ℚ) ≤ P.hstep := by unfold StreamParams.hstep; positivity
    exact_mod_cast this
  have hst1 : (P.hstep : ℝ) ≤ 1 := by exact_mod_cast P.hstep_le_one
  have hleaf : (P.hleaf : ℝ) ≤ (P.hg : ℝ) ^ 2 := by
    have e : (P.hleaf : ℝ) = (P.hg : ℝ) ^ 2 * (P.hstep : ℝ) ^ (2 * P.H) := by exact_mod_cast P.hleaf_eq
    rw [e]
    have : (P.hstep : ℝ) ^ (2 * P.H) ≤ 1 := pow_le_one₀ hst0 hst1
    have h2 : (0 : ℝ) ≤ (P.hg : ℝ) ^ 2 := sq_nonneg _
    nlinarith
  have hH := H_pos P
  have hG : (P.G : ℝ) = (P.B : ℝ) ^ (P.H + 2) := by
    have : P.G = P.B ^ (P.H + 2) := rfl
    rw [this]
    push_cast
    ring
  have hGhg : (P.G : ℝ) * (P.hg : ℝ) ≤ 16 * (P.eta : ℝ) * (P.nu : ℝ) / 2 ^ 20 := by
    have h1 : (P.B : ℝ) ^ (P.H + 2) ≤ (P.B : ℝ) ^ (2 * P.H + 1) := pow_le_pow_right₀ hB.2.le (by omega)
    have h2 := Tree.hgUnref_eq P
    calc (P.G : ℝ) * (P.hg : ℝ) ≤ (P.B : ℝ) ^ (2 * P.H + 1) * (P.hg : ℝ) := by
          rw [hG]
          exact mul_le_mul_of_nonneg_right h1 hg0
      _ = (P.B : ℝ) * ((P.B : ℝ) ^ (2 * P.H) * (P.hg : ℝ)) := by ring
      _ = (P.B : ℝ) * ((P.gamma : ℝ) * (P.eta : ℝ) * (P.nu : ℝ) / 2 ^ 20) := by rw [← h2]
      _ = 16 * (P.eta : ℝ) * (P.nu : ℝ) / 2 ^ 20 := by
          rw [hB.1]
          field_simp
  have hνγ : (P.nu : ℝ) ≤ (P.gamma : ℝ) := by
    have h := Tree.gamma_mul_eta P
    have h2 : (1 : ℝ) ≤ 2 ^ (P.H + 20) := one_le_pow₀ (by norm_num)
    have h3 : (P.nu : ℝ) ≤ 2 ^ (P.H + 20) * (P.nu : ℝ) := by nlinarith
    have h4 : (P.gamma : ℝ) * (P.eta : ℝ) ≤ (P.gamma : ℝ) := by nlinarith
    linarith
  have hx : (P.G : ℝ) * (P.hg : ℝ) ≤ (P.gamma : ℝ) := by
    have h1 : 16 * (P.eta : ℝ) * (P.nu : ℝ) ≤ 2 ^ 20 * (P.nu : ℝ) := by nlinarith
    have h2 : 16 * (P.eta : ℝ) * (P.nu : ℝ) / 2 ^ 20 ≤ (P.nu : ℝ) := by
      rw [div_le_iff₀ (by norm_num)]
      linarith
    linarith
  have hG1 := wit_one_le_G P
  have hx0 : 0 ≤ (P.G : ℝ) * (P.hg : ℝ) := mul_nonneg (by linarith) hg0
  have hT0 : (0 : ℝ) ≤ (P.T : ℝ) := Nat.cast_nonneg _
  have hTγ := (Tree.T_gamma_sq_le P).1
  calc (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hleaf : ℝ) ≤ (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hg : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left hleaf (mul_nonneg hT0 (sq_nonneg _))
    _ = (P.T : ℝ) * ((P.G : ℝ) * (P.hg : ℝ)) ^ 2 := by ring
    _ ≤ (P.T : ℝ) * (P.gamma : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hx0 hx 2) hT0
    _ ≤ 1 / 64 := hTγ

/-! ## The precisions at a moment (from any tree invariant) -/

/-- **Lemma 6.1 (ii)**: `|Ĉ_d − C_d| ≤ e_C` for a live depth, from the tree invariant and the tag witness. -/
theorem tagPrec_of {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (hT : Tree.TreeInv P ph R S)
    {d nev : ℕ} {Ch : ℝ} (hW : TagW P S d nev Ch) (hnev : nev ≤ P.T) (hd : d < ph.live P.H) :
    |Ch - S.C d| ≤ (P.eC : ℝ) := by
  obtain ⟨L, h1, h2, h3⟩ := hW
  have hlive := hT.live_le
  have hhC0 : (0 : ℝ) ≤ (P.hC : ℝ) := by
    have : (0 : ℚ) ≤ P.hC := by unfold StreamParams.hC; positivity
    exact_mod_cast this
  have hb := abs_pws_le_G hT hd.le (by omega) 1 L hhC0 h2 h3
  have hTn : (nev : ℝ) ≤ (P.T : ℝ) := by exact_mod_cast hnev
  have hG := wit_one_le_G P
  have hkey := wit_T_hC_G_le_eC P
  rw [h1]
  calc |pws S d 1 L| ≤ (nev : ℝ) * (P.hC : ℝ) * (P.G : ℝ) ^ 1 := hb
    _ ≤ (P.T : ℝ) * (P.hC : ℝ) * (P.G : ℝ) := by
        rw [pow_one]
        have : (0 : ℝ) ≤ (P.hC : ℝ) * (P.G : ℝ) := mul_nonneg hhC0 (by linarith)
        nlinarith
    _ ≤ (P.eC : ℝ) := hkey

/-- **Lemma 6.2 (ii)** (hypothesis (H2) of Theorem 5.9): `|P_d − E_d| ≤ (η/2^12)E_d + 2ωG² + TG²D_*h_P` for a
live depth, from the tree invariant and the cache witness. -/
theorem cachePrec_of {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (hT : Tree.TreeInv P ph R S)
    {d nev : ℕ} {Pc : ℝ} (hW : CacheW P S d nev Pc) (hnev : nev ≤ P.T) (hd : d < ph.live P.H) :
    |Pc - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P := by
  obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := hW
  have hlive := hT.live_le
  have hW := winProd_pos_le hT hd.le a0
  have hWG : winProd S d a0 ≤ (P.G : ℝ) := hW.2.trans (Tree.Bbar_pow_le_G P (by omega))
  have hhP0 : (0 : ℝ) ≤ (P.hP : ℝ) := by exact_mod_cast P.hP_pos.le
  have hom0 : (0 : ℝ) ≤ (P.omega : ℝ) := by exact_mod_cast P.omega_pos.le
  have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  have hE0 : 0 ≤ S.E d := by unfold Tree.TreeState.E; positivity
  have hpws := abs_pws_le_G hT hd.le (by omega) 2 L hhP0 h5 h6
  have hW2 : winProd S d a0 ^ 2 ≤ (P.G : ℝ) ^ 2 := pow_le_pow_left₀ hW.1.le hWG 2
  have hTn : (nev : ℝ) ≤ (P.T : ℝ) := by exact_mod_cast hnev
  have hT1 := wit_one_le_T P
  have hG1 := wit_one_le_G P
  have hG2 : (0 : ℝ) ≤ (P.G : ℝ) ^ 2 := sq_nonneg _
  have hbW : |b * winProd S d a0 ^ 2| ≤
      (1 / 2) ^ 13 * (P.eta : ℝ) * S.E d + ((P.omega : ℝ) + (P.hP : ℝ)) * (P.G : ℝ) ^ 2 := by
    rw [abs_mul, abs_of_nonneg (sq_nonneg (winProd S d a0))]
    calc |b| * winProd S d a0 ^ 2
        ≤ ((1 / 2) ^ 13 * (P.eta : ℝ) * E0 + (P.omega : ℝ) + (P.hP : ℝ)) * winProd S d a0 ^ 2 :=
          mul_le_mul_of_nonneg_right h3 (sq_nonneg _)
      _ = (1 / 2) ^ 13 * (P.eta : ℝ) * (E0 * winProd S d a0 ^ 2) +
            ((P.omega : ℝ) + (P.hP : ℝ)) * winProd S d a0 ^ 2 := by ring
      _ ≤ (1 / 2) ^ 13 * (P.eta : ℝ) * S.E d + ((P.omega : ℝ) + (P.hP : ℝ)) * (P.G : ℝ) ^ 2 := by
          have hA : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) * (E0 * winProd S d a0 ^ 2) ≤
              (1 / 2) ^ 13 * (P.eta : ℝ) * S.E d :=
            mul_le_mul_of_nonneg_left h4 (by positivity)
          have hB : ((P.omega : ℝ) + (P.hP : ℝ)) * winProd S d a0 ^ 2 ≤
              ((P.omega : ℝ) + (P.hP : ℝ)) * (P.G : ℝ) ^ 2 :=
            mul_le_mul_of_nonneg_left hW2 (by positivity)
          linarith
  have hDstar : (P.T : ℝ) + 1 ≤ (P.Dstar : ℝ) := by
    have : P.T + 1 ≤ P.Dstar := by unfold StreamParams.Dstar; omega
    exact_mod_cast this
  have hdrift : ((P.omega : ℝ) + (P.hP : ℝ)) * (P.G : ℝ) ^ 2 + (nev : ℝ) * (P.hP : ℝ) * (P.G : ℝ) ^ 2 ≤
      Tree.cacheDrift P := by
    unfold Tree.cacheDrift
    have hc1 : (1 + (nev : ℝ)) * ((P.hP : ℝ) * (P.G : ℝ) ^ 2) ≤
        (P.T : ℝ) * (P.Dstar : ℝ) * ((P.hP : ℝ) * (P.G : ℝ) ^ 2) := by
      apply mul_le_mul_of_nonneg_right _ (mul_nonneg hhP0 hG2)
      nlinarith
    have hc2 : 0 ≤ (P.omega : ℝ) * (P.G : ℝ) ^ 2 := mul_nonneg hom0 hG2
    nlinarith
  have hηE : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) * S.E d ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d := by
    have : 0 ≤ (P.eta : ℝ) * S.E d := by positivity
    nlinarith
  rw [h1]
  calc |b * winProd S d a0 ^ 2 + pws S d 2 L| ≤ |b * winProd S d a0 ^ 2| + |pws S d 2 L| := abs_add_le _ _
    _ ≤ (1 / 2) ^ 13 * (P.eta : ℝ) * S.E d + ((P.omega : ℝ) + (P.hP : ℝ)) * (P.G : ℝ) ^ 2 +
          (nev : ℝ) * (P.hP : ℝ) * (P.G : ℝ) ^ 2 := add_le_add hbW hpws
    _ ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P := by linarith

/-- **Lemma 5.3 with the post-use updates**: `|lf − ‖x_H‖²| ≤ TG²h_leaf` when all depths are live, from the
tree invariant and the accumulator witness. -/
theorem leafPrec_of {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (hT : Tree.TreeInv P ph R S)
    (hlive : ph.live P.H = P.H) {nev : ℕ} {lf : ℝ} (hW : LeafW P S nev lf) (hnev : nev ≤ P.T) :
    |lf - ‖S.x P.H‖ ^ 2| ≤ (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hleaf : ℝ) := by
  obtain ⟨L, h1, h2, h3⟩ := hW
  have hl0 : (0 : ℝ) ≤ (P.hleaf : ℝ) := by
    have : (0 : ℚ) ≤ P.hleaf := by unfold StreamParams.hleaf; positivity
    exact_mod_cast this
  have hb := abs_pws_le_G hT (le_of_eq hlive.symm) (by omega) 2 L hl0 h2 h3
  have hTn : (nev : ℝ) ≤ (P.T : ℝ) := by exact_mod_cast hnev
  rw [h1]
  calc |pws S P.H 2 L| ≤ (nev : ℝ) * (P.hleaf : ℝ) * (P.G : ℝ) ^ 2 := hb
    _ ≤ (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hleaf : ℝ) := by
        have : 0 ≤ (P.hleaf : ℝ) * (P.G : ℝ) ^ 2 := mul_nonneg hl0 (sq_nonneg _)
        nlinarith

/-- **Lemma 6.1 (ii) at the current moment**: `|Ĉ_d − C_d| ≤ e_C` for every live depth. -/
theorem TreePart.tagPrec {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P ph c S nev) (hnev : nev ≤ P.T) {d : ℕ} (hd : d < ph.live P.H) :
    |tagVal P c d - S.C d| ≤ (P.eC : ℝ) :=
  tagPrec_of h.tree (h.tagW d hd) hnev hd

/-- **Lemma 6.2 (ii) at the current moment** (hypothesis (H2) of Theorem 5.9):
`|P_d − E_d| ≤ (η/2^12)E_d + 2ωG² + TG²D_*h_P` for every live depth. -/
theorem TreePart.cachePrec {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P ph c S nev) (hnev : nev ≤ P.T) {d : ℕ} (hd : d < ph.live P.H) :
    |cacheVal P c d - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P :=
  cachePrec_of h.tree (h.cacheW d hd) hnev hd

/-! ## Rounding on the dyadic grids -/

theorem wit_roundMant_nonneg (q : ℕ) {z : ℚ} (hz : 0 ≤ z) : 0 ≤ roundMant q z := by
  unfold roundMant
  apply Int.floor_nonneg.mpr
  have : (0 : ℚ) ≤ z * 2 ^ q := mul_nonneg hz (by positivity)
  linarith

theorem wit_gridVal_nonneg (q : ℕ) {m : ℤ} (hm : 0 ≤ m) : 0 ≤ gridVal q m := by
  unfold gridVal
  have : (0 : ℚ) ≤ (m : ℚ) := by exact_mod_cast hm
  positivity

theorem wit_scaleMant_nonneg (qs : ℕ) {a m : ℤ} (ha : 0 ≤ a) (hm : 0 ≤ m) : 0 ≤ scaleMant qs a m := by
  unfold scaleMant
  apply wit_roundMant_nonneg
  have ha' : (0 : ℚ) ≤ (a : ℚ) := by exact_mod_cast ha
  have hm' : (0 : ℚ) ≤ (m : ℚ) := by exact_mod_cast hm
  exact div_nonneg (mul_nonneg ha' hm') (by positivity)

/-- Rescaling on a grid is rounding the product of the values: `scaleMant qs cInt m = round_q(c · m 2^{-q})`. -/
theorem wit_scaleMant_eq_roundMant (q qs : ℕ) (cInt m : ℤ) :
    scaleMant qs cInt m = roundMant q (gridVal qs cInt * gridVal q m) := by
  unfold scaleMant roundMant gridVal
  have h2 : (2 : ℚ) ^ q ≠ 0 := pow_ne_zero _ two_ne_zero
  have e : (cInt : ℚ) / 2 ^ qs * ((m : ℚ) / 2 ^ q) * 2 ^ q = (cInt : ℚ) * m / 2 ^ qs * 2 ^ 0 := by
    rw [mul_assoc, div_mul_cancel₀ _ h2]
    ring
  rw [e]

theorem wit_gridVal_sq (qs : ℕ) (m : ℤ) : gridVal (2 * qs) (m ^ 2) = gridVal qs m ^ 2 := by
  unfold gridVal
  rw [div_pow, ← pow_mul, mul_comm qs 2, Int.cast_pow]

theorem wit_gridVal_two_pow (q : ℕ) : gridVal q (2 ^ q) = 1 := by
  unfold gridVal
  rw [Int.cast_pow, Int.cast_ofNat, div_self (pow_ne_zero _ two_ne_zero)]

/-- The rounding error on the grid `2^{-q}`, as a real number: `≤ 2^{-q}`. -/
theorem wit_round_err (q : ℕ) (z : ℚ) :
    |((gridVal q (roundMant q z) : ℚ) : ℝ) - (z : ℝ)| ≤ (((1 / 2 : ℚ) ^ q : ℚ) : ℝ) := by
  have h := abs_gridVal_roundMant_sub_le q z
  have h' : |gridVal q (roundMant q z) - z| ≤ (1 / 2 : ℚ) ^ q := by
    have : (0 : ℚ) ≤ (1 / 2 : ℚ) ^ q := by positivity
    linarith
  have h'' := (Rat.cast_le (K := ℝ)).mpr h'
  rw [Rat.cast_abs, Rat.cast_sub] at h''
  exact h''

theorem wit_round_err_hP (z : ℚ) :
    |((gridVal P.eHP (roundMant P.eHP z) : ℚ) : ℝ) - (z : ℝ)| ≤ (P.hP : ℝ) :=
  wit_round_err P.eHP z

theorem wit_round_err_hC (z : ℚ) :
    |((gridVal P.eHC (roundMant P.eHC z) : ℚ) : ℝ) - (z : ℝ)| ≤ (P.hC : ℝ) :=
  wit_round_err P.eHC z

theorem wit_round_err_hleaf (z : ℚ) :
    |((gridVal P.eHleaf (roundMant P.eHleaf z) : ℚ) : ℝ) - (z : ℝ)| ≤ (P.hleaf : ℝ) :=
  wit_round_err P.eHleaf z

/-! ## Range checks -/

/-- The cache/accumulator range `[0, A_max]` from `0 ≤ x ≤ 16(V+1)² ≤ A_max`. -/
theorem wit_inRangeA_of_le {x : ℚ} (h0 : 0 ≤ x) (hx : (x : ℝ) ≤ 16 * ((P.V : ℝ) + 1) ^ 2) :
    inRangeA P x = true := by
  have hA : 16 * ((P.V : ℝ) + 1) ^ 2 ≤ (P.Amax : ℝ) := by exact_mod_cast P.le_Amax
  have hx' : x ≤ (P.Amax : ℚ) := by
    have : (x : ℝ) ≤ ((P.Amax : ℚ) : ℝ) := by
      rw [Rat.cast_natCast]
      linarith
    exact_mod_cast this
  unfold inRangeA
  exact decide_eq_true ⟨h0, hx'⟩

/-- The tag range `[0, C_max]` from `0 ≤ x ≤ 8(B^H + 1) ≤ C_max`. -/
theorem wit_inRangeC_of_le {x : ℚ} (h0 : 0 ≤ x) (hx : (x : ℝ) ≤ 8 * ((P.B : ℝ) ^ P.H + 1)) :
    inRangeC P x = true := by
  have hC : 8 * ((P.B : ℝ) ^ P.H + 1) ≤ (P.Cmax : ℝ) := by exact_mod_cast P.le_Cmax
  have hx' : x ≤ (P.Cmax : ℚ) := by
    have : (x : ℝ) ≤ ((P.Cmax : ℚ) : ℝ) := by
      rw [Rat.cast_natCast]
      linarith
    exact_mod_cast this
  unfold inRangeC
  exact decide_eq_true ⟨h0, hx'⟩

/-- From `√(a + ω) ≤ V` (the premise of Theorem 4.9): `a ≤ V²`. -/
theorem wit_le_V_sq_of_sqrt {a : ℝ} (h : √(a + (P.omega : ℝ)) ≤ (P.V : ℝ)) : a ≤ (P.V : ℝ) ^ 2 := by
  have hω : (0 : ℝ) ≤ (P.omega : ℝ) := by exact_mod_cast P.omega_pos.le
  have h2 := (Real.sqrt_le_iff.mp h).2
  linarith

/-- The squared vector bounds (C-TREE's `vector_bounds_inv`, Theorem 5.11 (2b) and Lemma 6.1 (iii)): with
`‖x_0‖ ≤ W`, `‖x_d‖² ≤ V²` (`d ≤ live`), `E_d ≤ V²` and `‖x_d − c y_d‖² ≤ V²` (`d < live`, `|c| ≤ 3/2`), and
`‖x_H‖² ≤ V²` when all depths are live. -/
theorem wit_vec_sq {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} (hT : Tree.TreeInv P ph R S)
    (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) :
    (∀ d ≤ ph.live P.H, ‖S.x d‖ ^ 2 ≤ (P.V : ℝ) ^ 2) ∧
      (∀ d < ph.live P.H, S.E d ≤ (P.V : ℝ) ^ 2) ∧
      (∀ d < ph.live P.H, ∀ c : ℝ, |c| ≤ 3 / 2 → ‖S.x d - c • S.y d‖ ^ 2 ≤ (P.V : ℝ) ^ 2) ∧
      (ph.live P.H = P.H → ‖S.x P.H‖ ^ 2 ≤ (P.V : ℝ) ^ 2) := by
  obtain ⟨h1, -, h3, h4⟩ := Tree.vector_bounds_inv hT hbox
  have hlive := hT.live_le
  refine ⟨fun d hd => ?_, fun d hd => ?_, fun d hd c hc => ?_, fun hl => wit_le_V_sq_of_sqrt (h4 hl)⟩
  · have hVd := h1 d hd
    have h2V : 2 * P.Vd d < P.V := P.two_mul_Vd_lt_V (by omega)
    have h2V' : 2 * (P.Vd d : ℝ) < (P.V : ℝ) := by exact_mod_cast h2V
    have hn := norm_nonneg (S.x d)
    have hVd0 : (0 : ℝ) ≤ (P.Vd d : ℝ) := Nat.cast_nonneg _
    have hxV : ‖S.x d‖ ≤ (P.V : ℝ) := by linarith
    exact pow_le_pow_left₀ hn hxV 2
  · show ‖S.r d‖ ^ 2 ≤ (P.V : ℝ) ^ 2
    exact wit_le_V_sq_of_sqrt (h3 d hd 0 (by norm_num) (S.r d)
      (Set.mem_insert_of_mem _ (Set.mem_insert_of_mem _ (Set.mem_insert _ _))))
  · exact wit_le_V_sq_of_sqrt (h3 d hd c hc (S.x d - c • S.y d)
      (Set.mem_insert_of_mem _ (Set.mem_insert_of_mem _ (Set.mem_insert_of_mem _
        (Set.mem_insert_of_mem _ (Set.mem_singleton _))))))

/-! ## List lookups and learner registers -/

theorem wit_getD_take (l : List Learner) {n d : ℕ} (h : d < n) :
    (l.take n).getD d dfltLearner = l.getD d dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take, if_pos h]

theorem wit_getD_append_lt (l : List Learner) (a : Learner) {d : ℕ} (h : d < l.length) :
    (l ++ [a]).getD d dfltLearner = l.getD d dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_append_left h]

theorem wit_getD_append_length (l : List Learner) (a : Learner) :
    (l ++ [a]).getD l.length dfltLearner = a := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_append_right (le_refl _), Nat.sub_self]
  rfl

theorem wit_getD_setAt_ne (b : Learner) (k : ℕ) (l : List Learner) {j : ℕ} (h : j ≠ k) :
    (setAt b k l).getD j dfltLearner = l.getD j dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_setAt_ne b k l j h]

theorem wit_getD_setAt_self (b : Learner) (k : ℕ) (l : List Learner) (h : k < l.length) :
    (setAt b k l).getD k dfltLearner = b := by
  rw [List.getD_eq_getElem?_getD, getElem?_setAt_self b k l h]
  rfl

theorem wit_getD_mapFrom_lt (f : Learner → Learner) (k : ℕ) (l : List Learner) {j : ℕ} (h : j < k) :
    (mapFrom f k l).getD j dfltLearner = l.getD j dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_mapFrom, if_neg (by omega)]

theorem wit_getD_mapFrom_ge (f : Learner → Learner) (k : ℕ) (l : List Learner) {j : ℕ} (h : k ≤ j)
    (hj : j < l.length) : (mapFrom f k l).getD j dfltLearner = f (l.getD j dfltLearner) := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_mapFrom, if_pos h,
    List.getElem?_eq_getElem hj]
  rfl

theorem wit_getD_of_getElem? {l : List Learner} {d : ℕ} {L : Learner} (h : l[d]? = some L) :
    l.getD d dfltLearner = L := by
  rw [List.getD_eq_getElem?_getD, h]
  rfl

/-- The elements of `(mapFrom f k l).drop k` are the images `f lⱼ`, `k ≤ j < |l|`. -/
theorem wit_mem_drop_mapFrom (f : Learner → Learner) (k : ℕ) (l : List Learner) {x : Learner}
    (hx : x ∈ (mapFrom f k l).drop k) :
    ∃ j, k ≤ j ∧ j < l.length ∧ x = f (l.getD j dfltLearner) := by
  obtain ⟨i, hi, hxi⟩ := List.getElem_of_mem hx
  have hlenM : (mapFrom f k l).length = l.length := length_mapFrom f k l
  rw [List.length_drop, hlenM] at hi
  have hki : k + i < l.length := by omega
  have hkiM : k + i < (mapFrom f k l).length := by rw [hlenM]; exact hki
  refine ⟨k + i, Nat.le_add_right k i, hki, ?_⟩
  have h1 : (mapFrom f k l)[k + i]? = some (f (l.getD (k + i) dfltLearner)) := by
    rw [wit_getD_mapFrom_ge f k l (Nat.le_add_right k i) hki |>.symm, List.getD_eq_getElem?_getD,
      List.getElem?_eq_getElem hkiM]
    rfl
  rw [List.getElem?_eq_getElem hkiM] at h1
  rw [← hxi, List.getElem_drop]
  exact Option.some.inj h1

/-- Counting a correction changes only the counters. -/
theorem wit_countCorrection_tag_cache {L L' : Learner} (h : Learner.countCorrection P L = some L') :
    L'.tag = L.tag ∧ L'.cache = L.cache := by
  unfold Learner.countCorrection at h
  split_ifs at h
  all_goals (try simp only [Option.some.injEq] at h)
  all_goals (try (subst h; exact ⟨rfl, rfl⟩))

/-! ## Euclidean helpers -/

/-- Adding `δ e_g` on a coordinate where `x` vanishes adds `δ²` to the squared norm. -/
theorem wit_norm_add_single_sq {ι : Type*} [Fintype ι] [DecidableEq ι] (x : EuclideanSpace ℝ ι) (g : ι)
    (δ : ℝ) (hg : x g = 0) : ‖x + EuclideanSpace.single g δ‖ ^ 2 = ‖x‖ ^ 2 + δ ^ 2 := by
  have hsq : ∀ y : EuclideanSpace ℝ ι, ‖y‖ ^ 2 = ∑ i, y i ^ 2 := by
    intro y
    rw [EuclideanSpace.norm_eq, Real.sq_sqrt (Finset.sum_nonneg fun i _ => by positivity)]
    simp [Real.norm_eq_abs, sq_abs]
  have hpt : ∀ i, (x + EuclideanSpace.single g δ) i ^ 2 = x i ^ 2 + (if i = g then δ ^ 2 else 0) := by
    intro i
    by_cases hi : i = g
    · subst hi
      simp [hg]
    · simp [hi]
  rw [hsq, hsq, Finset.sum_congr rfl (fun i _ => hpt i), Finset.sum_add_distrib,
    Finset.sum_ite_eq' Finset.univ g, if_pos (Finset.mem_univ g)]

end F2e2e.C.Closure
