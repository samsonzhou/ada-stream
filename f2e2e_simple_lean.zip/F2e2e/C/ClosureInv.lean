import Mathlib
import F2e2e.C.ClosureBank
import F2e2e.C.ClosurePws

/-!
# Theorem 6.4: the chronological invariant (definitions)

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof`, the chronological induction
(L1287–1317). The paper never writes the invariant down; ours (map III.6.4, "Suggested explicit invariant")
packages, at every moment of the within-round schedule (`Tree.Phase`: births / guards / evals / idle):

* the **tree part** `TreePart` (C-TREE's `Tree.TreeInv` for the tree shadow `S` and the stored learner registers,
  plus the stored tags, caches and terminal accumulator against their exact values): Lemma 6.1 (ii) (tags), Lemma
  6.2 (caches, hypothesis (H2) of Theorem 5.9), Lemma 5.3 (accumulator); errors kept in the exact
  product-weighted form of `F2e2e/C/ClosurePws.lean`;
* the **bank part** `BankPart`: every bank's exact shadow equals the tree shadow it tracks (primary array of bank
  `idx` ↔ `x_idx`, secondary ↔ `y_idx`; Definition 5.1 (3)), and the counter errors of every hypothetical row
  are in the exact product-weighted form (Lemma 6.1 (iv));
* the **oracle part** (`F2e2e/C/ClosureRound*.lean`): stored rows are hypothetical rows (`RowsOK`), the ADA
  counters, the labels and call counts (coverage, Theorem 5.11 (2c)).

`nev` is a bound on the number of analysis events so far: every event adds at most one rounding error to every
witness, and `nev ≤ (3H+2)m ≤ T` gives the paper's operation count (`< T`, Lemma 6.1 (iv)).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## Stored learner values and registers -/

/-- A default learner record (for out-of-range lookups). -/
def dfltLearner : Learner := ⟨0, 0, 0, 0, 0⟩

/-- The real value `Ĉ_d` of the stored tag of depth `d`. -/
noncomputable def tagVal (P : StreamParams) (c : CState) (d : ℕ) : ℝ :=
  ((gridVal P.eHC (c.learners.getD d dfltLearner).tag : ℚ) : ℝ)

/-- The real value `P_d` of the stored cache of depth `d`. -/
noncomputable def cacheVal (P : StreamParams) (c : CState) (d : ℕ) : ℝ :=
  ((gridVal P.eHP (c.learners.getD d dfltLearner).cache : ℚ) : ℝ)

/-- The real value of the terminal accumulator. -/
noncomputable def leafVal (P : StreamParams) (c : CState) : ℝ := ((gridVal P.eHleaf c.leaf : ℚ) : ℝ)

/-- The algorithm's learner registers, as C-TREE's `Regs`: the stored tag, the epoch, the intra-epoch counter and
the lifetime counter of every depth. -/
noncomputable def regsOf (P : StreamParams) (c : CState) : Tree.Regs where
  Chat d := tagVal P c d
  k d := (c.learners.getD d dfltLearner).epoch
  jE d := (c.learners.getD d dfltLearner).jEpoch
  jU d := (c.learners.getD d dfltLearner).jUsed

/-! ## Analysis events and the tree shadow -/

/-- C-ALG's analysis events (mantissas, 1-based coordinates) as C-TREE's real-valued events. -/
noncomputable def toTreeEv (P : StreamParams) : TreeEvent → Option (Tree.TreeEv P)
  | TreeEvent.newRound => some Tree.TreeEvent.newRound
  | TreeEvent.birth d => some (Tree.TreeEvent.birth d)
  | TreeEvent.phys i Δ =>
      if h : i - 1 < P.n then some (Tree.TreeEvent.phys ⟨i - 1, h⟩ Δ) else none
  | TreeEvent.guard d g δ =>
      if h : g - 1 < P.Dstar then some (Tree.TreeEvent.guard d ⟨g - 1, h⟩ ((gridVal P.eHg δ : ℚ) : ℝ))
      else none
  | TreeEvent.accept d => some (Tree.TreeEvent.accept d)
  | TreeEvent.correct d c => some (Tree.TreeEvent.correct d ((gridVal P.eHstep c : ℚ) : ℝ))

/-- The tree shadow of the instrumented state: C-TREE's shadow run on the analysis events so far. -/
noncomputable def shadowOf (P : StreamParams) (g : Ghost) : Tree.TreeSt P :=
  Tree.TreeState.run P (Tree.TreeState.init P.Dstar) (g.events.filterMap (toTreeEv P))

/-- The tree shadow depends only on the analysis events; appending an event steps the shadow. -/
theorem shadowOf_snoc (P : StreamParams) {g g' : Ghost} {ev : TreeEvent} {e : Tree.TreeEv P}
    (hg : g'.events = g.events ++ [ev]) (hev : toTreeEv P ev = some e) :
    shadowOf P g' = (shadowOf P g).step P e := by
  unfold shadowOf Tree.TreeState.run
  rw [hg, List.filterMap_append, List.foldl_append]
  simp [hev]

/-- Ghost updates that keep the event log keep the tree shadow. -/
theorem shadowOf_congr (P : StreamParams) {g g' : Ghost} (hg : g'.events = g.events) :
    shadowOf P g' = shadowOf P g := by
  unfold shadowOf
  rw [hg]

/-- The physical stream vector embedded in the shadow space `ℝ^{D_*}` (Lean index `i` ↔ coordinate `i+1`). -/
noncomputable def embedPhys (P : StreamParams) (x : Fin P.n → ℤ) : Tree.Vec P :=
  ∑ i : Fin P.n, (x i : ℝ) • Tree.unitVec (Tree.physIdx P i)

/-! ## Exact error witnesses -/

/-- **Lemma 6.1 (ii), exact form**: the stored tag of depth `d` minus the exact tag `C_d` is a product-weighted
sum (exponent `1`, the ancestors `j < d`) of at most `nev` rounding errors, each `≤ h_C`. -/
def TagW (P : StreamParams) (S : Tree.TreeSt P) (d nev : ℕ) (Ch : ℝ) : Prop :=
  ∃ L : List ((ℕ → ℕ) × ℝ), Ch - S.C d = pws S d 1 L ∧ L.length ≤ nev ∧ ∀ x ∈ L, |x.2| ≤ (P.hC : ℝ)

/-- **Lemma 6.2 (i), exact form** (eq. `R:eq:global-cache-invariant`): the stored cache of depth `d` minus the
exact energy `E_d = ‖r_d‖²` is `b W(a₀)² + Σ_k W(a_k)² ζ_k` (exponent `2`, the ancestors `j < d`), where `b` is the
error of the last refresh (or of the birth), at which the energy was `E₀` and `|b| ≤ 2^{-13}ηE₀ + ω + h_P`; the
covariance inequality `W(a₀)² E₀ ≤ E_d` (`R:eq:covariance-inequality`); at most `nev` rounding errors `≤ h_P`. -/
def CacheW (P : StreamParams) (S : Tree.TreeSt P) (d nev : ℕ) (Pc : ℝ) : Prop :=
  ∃ (a0 : ℕ → ℕ) (b E0 : ℝ) (L : List ((ℕ → ℕ) × ℝ)),
    Pc - S.E d = b * winProd S d a0 ^ 2 + pws S d 2 L ∧ 0 ≤ E0 ∧
      |b| ≤ (1 / 2) ^ 13 * (P.eta : ℝ) * E0 + (P.omega : ℝ) + (P.hP : ℝ) ∧
      E0 * winProd S d a0 ^ 2 ≤ S.E d ∧ L.length ≤ nev ∧ ∀ x ∈ L, |x.2| ≤ (P.hP : ℝ)

/-- **Lemma 5.3, with the post-use updates**: the terminal accumulator minus `‖x_H‖²` is a product-weighted sum
(exponent `2`, all depths) of at most `nev` rounding errors `≤ h_leaf` (exact, i.e. empty, during Steps 2–3). -/
def LeafW (P : StreamParams) (S : Tree.TreeSt P) (nev : ℕ) (lf : ℝ) : Prop :=
  ∃ L : List ((ℕ → ℕ) × ℝ), lf - ‖S.x P.H‖ ^ 2 = pws S P.H 2 L ∧ L.length ≤ nev ∧
    ∀ x ∈ L, |x.2| ≤ (P.hleaf : ℝ)

/-- The moments at which the terminal accumulator is meaningful (after Step 2, before the end of the round). -/
def leafPhase : Tree.Phase → Bool
  | .guards _ => true
  | .evals _ => true
  | _ => false

/-! ## The tree part -/

/-- **The tree part of the chronological invariant** at the moment `ph`, for the controller state `c` and the tree
shadow `S`, with at most `nev` analysis events so far. -/
structure TreePart (P : StreamParams) (ph : Tree.Phase) (c : CState) (S : Tree.TreeSt P) (nev : ℕ) : Prop where
  /-- C-TREE's invariant for the stored registers -/
  tree : Tree.TreeInv P ph (regsOf P c) S
  /-- the live learners -/
  nLearners : c.learners.length = ph.live P.H
  /-- the root tag is exactly `1` (no ancestor ever rescales it) -/
  root : 0 < ph.live P.H → (c.learners.getD 0 dfltLearner).tag = 2 ^ P.eHC
  /-- Lemma 6.1 (ii), exact form -/
  tagW : ∀ d < ph.live P.H, TagW P S d nev (tagVal P c d)
  /-- Lemma 6.2, exact form -/
  cacheW : ∀ d < ph.live P.H, CacheW P S d nev (cacheVal P c d)
  /-- caches are nonnegative -/
  cacheNonneg : ∀ d < ph.live P.H, 0 ≤ (c.learners.getD d dfltLearner).cache
  /-- stored tags are nonnegative (births set `2^{e_{h_C}}`; rescalings are range-checked) -/
  tagNonneg : ∀ d < ph.live P.H, 0 ≤ (c.learners.getD d dfltLearner).tag
  /-- Lemma 5.3: during Steps 2–3 the accumulator is exactly `‖x_H‖²` -/
  leafExact : ∀ D, ph = .guards D → leafVal P c = ‖S.x P.H‖ ^ 2
  /-- Lemma 5.3 with the post-use updates, during Step 4 -/
  leafW : ∀ D, ph = .evals D → LeafW P S nev (leafVal P c)
  /-- the accumulator is nonnegative -/
  leafNonneg : leafPhase ph = true → 0 ≤ c.leaf
  /-- during Step 1, the input of a depth below a depth born in this round vanishes (`r_{D-1} := x_{D-1}`) -/
  bornZero : ∀ D, ph = .births D → firstBorn P.H S.t < D → S.x D = 0

theorem TreePart.mono_nev {P : StreamParams} {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev nev' : ℕ}
    (h : TreePart P ph c S nev) (hn : nev ≤ nev') : TreePart P ph c S nev' where
  tree := h.tree
  nLearners := h.nLearners
  root := h.root
  tagW d hd := by
    obtain ⟨L, h1, h2, h3⟩ := h.tagW d hd
    exact ⟨L, h1, h2.trans hn, h3⟩
  cacheW d hd := by
    obtain ⟨a0, b, E0, L, h1, h2, h3, h4, h5, h6⟩ := h.cacheW d hd
    exact ⟨a0, b, E0, L, h1, h2, h3, h4, h5.trans hn, h6⟩
  cacheNonneg := h.cacheNonneg
  tagNonneg := h.tagNonneg
  leafExact := h.leafExact
  leafW D hD := by
    obtain ⟨L, h1, h2, h3⟩ := h.leafW D hD
    exact ⟨L, h1, h2.trans hn, h3⟩
  leafNonneg := h.leafNonneg
  bornZero := h.bornZero

/-! ## The bank part -/

/-- The counter-error witness of one counter: the error is a product-weighted sum (exponent `1`, the depths
`j < D` whose corrections multiply the counter) of at most `nev` rounding errors `≤ h_b`. -/
def CtrW (P : StreamParams) (S : Tree.TreeSt P) (D nev : ℕ) (e : ℝ) : Prop :=
  ∃ L : List ((ℕ → ℕ) × ℝ), e = pws S D 1 L ∧ L.length ≤ nev ∧ ∀ x ∈ L, |x.2| ≤ (P.hb : ℝ)

/-- **The bank part of the chronological invariant** at the moment `ph`, for the tree shadow `S` and the
row-operation histories `hists` of the live banks (bank `idx` is the incoming bank of depth `idx`): the exact
shadows track the tree (Definition 5.1 (3); the secondary array only for a live client), and the counter errors of
every hypothetical row have exact witnesses (the primary counter of bank `idx` is multiplied by the corrections of
the depths `< idx`, the secondary one also by those of depth `idx`). -/
structure BankPart (P : StreamParams) (ph : Tree.Phase) (S : Tree.TreeSt P) (hists : List (List RowOp))
    (nev : ℕ) : Prop where
  shadowX : ∀ idx < hists.length, (bankShadowXY P (hists.getD idx [])).1 = S.x idx
  shadowY : ∀ idx < hists.length, idx < ph.live P.H → (bankShadowXY P (hists.getD idx [])).2 = S.y idx
  driftX : ∀ idx < hists.length, ∀ ζ : Seed P, CtrW P S idx nev (errX P (hists.getD idx []) ζ)
  driftY : ∀ idx < hists.length, idx < ph.live P.H → ∀ ζ : Seed P,
    CtrW P S (idx + 1) nev (errY P (hists.getD idx []) ζ)

theorem BankPart.mono_nev {P : StreamParams} {ph : Tree.Phase} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev nev' : ℕ} (h : BankPart P ph S hists nev) (hn : nev ≤ nev') : BankPart P ph S hists nev' where
  shadowX := h.shadowX
  shadowY := h.shadowY
  driftX idx hidx ζ := by
    obtain ⟨L, h1, h2, h3⟩ := h.driftX idx hidx ζ
    exact ⟨L, h1, h2.trans hn, h3⟩
  driftY idx hidx hl ζ := by
    obtain ⟨L, h1, h2, h3⟩ := h.driftY idx hidx hl ζ
    exact ⟨L, h1, h2.trans hn, h3⟩

end F2e2e.C.Closure
