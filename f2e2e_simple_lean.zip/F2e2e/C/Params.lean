import F2e2e.C.ParamsDefs
import F2e2e.C.ParamsAux
import F2e2e.C.ParamsFacts
import F2e2e.C.ParamsGrids
import F2e2e.C.ParamsPublic
import F2e2e.C.ParamsTree

/-!
# Theorem (C): public parameters (umbrella module)

Import this module to get every public parameter of the streaming algorithm of Theorem (C) as a computable
function of the Spec's `StreamParams` (definitions in `F2e2e.C.ParamsDefs`, namespace `F2e2e.StreamParams`,
dot notation `P.eta`, `P.H`, …) together with their facts:

* `F2e2e.C.ParamsAux`: `Nat.clog 2`/bit-length helpers (`clog_two_eq_size_pred`, `clog_two_pow_mul`), the real
  `⌈log₂ ·⌉` characterization, the Spec's `dyadicExp`/`dyadicDown` facts, `(1/2)^e` manipulations;
* `F2e2e.C.ParamsFacts`: standing assumptions `StreamParams.Valid`, Definitions 1.5–1.6 (link lemmas to the real
  `ε`, `β` and the Spec's `masterLambda`, faithfulness `*_eq_ceil_logb`, intervals of `η, γ, B, 𝒰_d`, eq.
  `R:eq:param-s-bound`, budgets, guard coordinates);
* `F2e2e.C.ParamsGrids`: Definition 1.7 grids (`h_g, e_C, h_C, σ, ω, h_P, h_b, h_step`: bounds, "largest power of
  two" property, faithfulness), Remark 1.8 (`h_g B^{2H} = h_{g,unrefined}`, scale cancellation), Definition 5.2
  ranges and `h_leaf`, grid divisibility (`h_b ≤ h_g`, `h_b ≤ σ`), cache-grid numerics (`2ωG^2 + TG^2D_*h_P <
  η^3ν^2/2^39`, `ξ = G(T+1)h_b ≤ ηω/(2^40 D_*(V+1))`);
* `F2e2e.C.ParamsPublic`: zero fingerprint (`q` least prime `≥ M_q`, `q ≤ 2M_q`, `q > U`, seed trials, failure
  budget `< β₀/8`), row field degree `w` (`D_* < 2^w`), coarse groups (`g = 32⌈log₂(4R_max/β_B)⌉`,
  `e^{-g/18} ≤ β_B/(4R_max)`), the dyadic inputs of the banks' ADA modules (`eBankA = dyadicExp a_num`,
  `eBankXi = dyadicExp (β_B/2)`).

* `F2e2e.C.ParamsTree`: the parameter numerics of Part III §5 (`(8H+5)η < 2^{-16}`, `64(H+1)²η ≤ 2^{-14}`,
  `𝒰_d < V²`, `𝒰_* < 16V²`, root-guard magnitudes, first-correction margin, `3B^H V_H + σ < V`, `√n U < W`,
  `B^H + e_C < C_max`, `√D_* V + 1 < Z_max`, the epoch cap `k + 12 < K_epoch`).

The Theorem-B instance of the banks (`P.bankAda = B.adaParams P.eBankA P.eBankXi m J_max R_max`, `P.Nbank`) is in
`F2e2e.C.ParamsBank`, which is not re-exported here (it imports Part II's `F2e2e.B.ArchParams`).
-/
