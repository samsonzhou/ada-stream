import F2e2e.C.ClosureProbCore
import F2e2e.C.NormBank.Coarse

/-!
# Theorem 6.4, probability layer (C-PROB): the uniform coarse group and its count

Paper: `parts/partIII.tex` L1275–1277 (the reserved coarse group `k` of a bank influences no decision before its
first use; its seeds are uniform), Lemma `R:lem:coarse-ams` and L387 (each group fails with probability at most
`β_B/(2R_max)`).

`group_count`: for every fixed target vector `w`, at most a `β_B/(2R_max)` fraction of the bit strings of any length
`n ≥ depth` make the group sampler (`g` subgroups of `32` fresh rows) produce a group whose seeds (`groupSeeds`) fail
the exact coarse moment event for `w`.

Proof: the tape sum is `2^n` times the law (`BitProg.sum_tapes_eq`); the group seeds are uniform on
`Fin g → Fin 32 → Seed P` (`law_groupSeeds`, two nested `law_sampleList_map` with `law_seed`); C-BANK's
`coarse_bad_count` counts the bad seed families.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.NormBank F2e2e.C.Top F2e2e.FinProb
open scoped ENNReal

namespace GroupCount

/-- The seeds of a subgroup of `32` rows. -/
def subSeeds (P : StreamParams) (L : List Row) : Fin 32 → Seed P :=
  fun l => seedOfRow P (L.getD l ⟨[], 0, 0⟩)

/-- The seeds of the `32` rows of a fresh subgroup are uniform. -/
theorem law_subSeeds (P : StreamParams) (y : Fin 32 → Seed P) :
    ((sampleList (newRow P) 32).law.map (subSeeds P)) y =
      ((Fintype.card (Seed P) : ℝ≥0∞))⁻¹ ^ 32 := by
  rw [show subSeeds P = fun L => fun l : Fin 32 => seedOfRow P (L.getD l ⟨[], 0, 0⟩) from rfl,
    CoreQCount.law_sampleList_map]
  simp only [CoreQCount.law_seed]
  rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin]

/-- The seeds of a fresh coarse group are uniform. -/
theorem law_groupSeeds (P : StreamParams) (z : Fin P.gCoarse → Fin 32 → Seed P) :
    ((sampleList (sampleList (newRow P) 32) P.gCoarse).law.map (groupSeeds P)) z =
      ((Fintype.card (Seed P) : ℝ≥0∞))⁻¹ ^ (32 * P.gCoarse) := by
  rw [show groupSeeds P = fun G => fun j : Fin P.gCoarse => subSeeds P (G.getD j []) from rfl,
    CoreQCount.law_sampleList_map]
  simp only [law_subSeeds]
  rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin, ← pow_mul]

/-! ## Programs reading a fixed number of bits -/

/-- `p` reads exactly `d` bits on every path. -/
inductive Exact {α : Type} : BitProg α → ℕ → Prop
  | pure (a : α) : Exact (BitProg.pure a) 0
  | bit (k : Bool → BitProg α) (d : ℕ) : (∀ b, Exact (k b) d) → Exact (BitProg.bit k) (d + 1)

theorem Exact.run_length {α : Type} {p : BitProg α} {d : ℕ} (h : Exact p d) :
    ∀ {t : List Bool} {a : α} {r : List Bool}, p.run t = some (a, r) → t.length = d + r.length := by
  induction h with
  | pure a =>
    intro t a' r hrun
    simp only [BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at hrun
    rw [← hrun.2]
    simp
  | bit k d _ ih =>
    intro t a r hrun
    cases t with
    | nil => simp at hrun
    | cons b t =>
      rw [BitProg.run_bit_cons] at hrun
      have := ih b hrun
      simp only [List.length_cons]
      omega

theorem Exact.run_none {α : Type} {p : BitProg α} {d : ℕ} (h : Exact p d) {t : List Bool}
    (ht : t.length < d) : p.run t = none := by
  cases hr : p.run t with
  | none => rfl
  | some x =>
    obtain ⟨a, r⟩ := x
    have := h.run_length hr
    omega

theorem Exact.depth_le {α : Type} {p : BitProg α} {d : ℕ} (h : Exact p d) : p.depth ≤ d := by
  induction h with
  | pure a => exact le_refl _
  | bit k d _ ih =>
    show max (k true).depth (k false).depth + 1 ≤ d + 1
    have := ih true
    have := ih false
    omega

theorem Exact.bind {α β : Type} {p : BitProg α} {d₁ : ℕ} (hp : Exact p d₁) {f : α → BitProg β} {d₂ : ℕ}
    (hf : ∀ a, Exact (f a) d₂) : Exact (p.bind f) (d₁ + d₂) := by
  induction hp with
  | pure a =>
    rw [Nat.zero_add]
    exact hf a
  | bit k d _ ih =>
    rw [show d + 1 + d₂ = (d + d₂) + 1 by omega]
    exact Exact.bit _ _ fun b => ih b

theorem exact_bitsNat : ∀ (k acc : ℕ), Exact (Discrete.bitsNat acc k) k
  | 0, acc => Exact.pure acc
  | k + 1, _ => Exact.bit _ _ fun _ => exact_bitsNat k _

theorem exact_sampleList {α : Type} {p : BitProg α} {d : ℕ} (hp : Exact p d) :
    ∀ N : ℕ, Exact (sampleList p N) (N * d)
  | 0 => by
    rw [Nat.zero_mul]
    exact Exact.pure _
  | N + 1 => by
    rw [sampleList_succ, show (N + 1) * d = d + (N * d + 0) by ring]
    exact hp.bind fun a => (exact_sampleList hp N).bind fun l => Exact.pure _

theorem exact_newRow (P : StreamParams) : Exact (newRow P) (2 * P.s * P.w + 0) := by
  rw [show newRow P = (sampleSeed P).bind fun z => BitProg.pure ⟨z, 0, 0⟩ from rfl]
  exact (exact_sampleList (exact_bitsNat P.w 0) (2 * P.s)).bind fun z => Exact.pure _

theorem exact_group (P : StreamParams) :
    Exact (sampleList (sampleList (newRow P) 32) P.gCoarse) (P.gCoarse * (32 * (2 * P.s * P.w + 0))) :=
  exact_sampleList (exact_sampleList (exact_newRow P) 32) P.gCoarse

end GroupCount

open Classical in
/-- `group_count` for tapes at least as long as the sampler's depth. -/
theorem GroupCount.group_count_of_depth (P : StreamParams) (hP : ParamsOK P)
    (w : EuclideanSpace ℝ (Fin P.Dstar)) (n : ℕ)
    (hn : (sampleList (sampleList (newRow P) 32) P.gCoarse).depth ≤ n) :
    ∑ l ∈ TBitProg.lenFinset n,
      (if ∃ grp rest, (sampleList (sampleList (newRow P) 32) P.gCoarse).run l = some (grp, rest) ∧
          ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w (groupSeeds P grp)) ∧
             coarseEst (rowVals (sgn P) w (groupSeeds P grp)) ≤ 23 / 16 * ‖w‖ ^ 2)
        then (1 : ℝ≥0∞) else 0) ≤ ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * 2 ^ n := by
  set q := sampleList (sampleList (newRow P) 32) P.gCoarse with hq
  set Bad : (Fin P.gCoarse → Fin 32 → Seed P) → Prop := fun z =>
    ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w z) ∧
      coarseEst (rowVals (sgn P) w z) ≤ 23 / 16 * ‖w‖ ^ 2) with hBad
  have hsum := BitProg.sum_tapes_eq q hn (fun grp => if Bad (groupSeeds P grp) then 1 else 0)
  rw [CoreQCount.sum_lenFinset]
  have hterm : ∀ ω : Fin n → Bool,
      (if ∃ grp rest, q.run (List.ofFn ω) = some (grp, rest) ∧ Bad (groupSeeds P grp)
        then (1 : ℝ≥0∞) else 0) =
        (q.run (List.ofFn ω)).elim 0 (fun r => if Bad (groupSeeds P r.1) then 1 else 0) := by
    intro ω
    cases h : q.run (List.ofFn ω) with
    | none => simp
    | some r =>
      obtain ⟨grp, rest⟩ := r
      simp only [Option.elim]
      by_cases hB : Bad (groupSeeds P grp)
      · rw [if_pos ⟨grp, rest, rfl, hB⟩, if_pos hB]
      · rw [if_neg (by rintro ⟨g', r', h', hB'⟩; cases h'; exact hB hB'), if_neg hB]
  rw [Finset.sum_congr rfl fun ω _ => hterm ω, hsum, mul_comm]
  refine mul_le_mul_of_nonneg_right ?_ zero_le
  -- the law of the group seeds
  have h1 : ∑' grp, q.law grp * (if Bad (groupSeeds P grp) then (1 : ℝ≥0∞) else 0) =
      q.law.toOuterMeasure (groupSeeds P ⁻¹' {z | Bad z}) := by
    rw [PMF.toOuterMeasure_apply]
    refine tsum_congr fun grp => ?_
    by_cases h : Bad (groupSeeds P grp)
    · rw [if_pos h, mul_one, Set.indicator_of_mem (show grp ∈ groupSeeds P ⁻¹' {z | Bad z} from h)]
    · rw [if_neg h, mul_zero,
        Set.indicator_of_notMem (show grp ∉ groupSeeds P ⁻¹' {z | Bad z} from h)]
  have h2 : ∑' z, (q.law.map (groupSeeds P)) z * (if Bad z then (1 : ℝ≥0∞) else 0) =
      (q.law.map (groupSeeds P)).toOuterMeasure {z | Bad z} := by
    rw [PMF.toOuterMeasure_apply]
    refine tsum_congr fun z => ?_
    by_cases h : Bad z
    · rw [if_pos h, mul_one, Set.indicator_of_mem (show z ∈ {z | Bad z} from h)]
    · rw [if_neg h, mul_zero, Set.indicator_of_notMem (show z ∉ {z | Bad z} from h)]
  rw [h1, ← PMF.toOuterMeasure_map_apply, ← h2, tsum_fintype, hq]
  simp only [GroupCount.law_groupSeeds]
  rw [← Finset.mul_sum, Finset.sum_boole]
  -- C-BANK's count of the bad seed families
  have hcb := coarse_bad_count P hP w
  set c : ℝ≥0∞ := (Fintype.card (Seed P) : ℝ≥0∞) with hc
  have hc0 : c ≠ 0 := by
    rw [hc]
    exact_mod_cast (CoreQCount.card_seed_pos P).ne'
  have hcT : c ≠ ⊤ := by
    rw [hc]
    exact ENNReal.natCast_ne_top _
  have hcard : (((Finset.univ.filter fun z => Bad z).card : ℕ) : ℝ≥0∞) ≤
      ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * c ^ (32 * P.gCoarse) := by
    have hβ : (0 : ℝ) ≤ (P.betaB : ℝ) / (2 * P.Rmax) := by
      have : (0 : ℝ) < (P.betaB : ℝ) := by exact_mod_cast StreamParams.betaB_pos hP.one_le_m
      positivity
    have hcb' : (((Finset.univ.filter fun z => Bad z).card : ℕ) : ℝ) ≤
        (P.betaB : ℝ) / (2 * P.Rmax) * (Fintype.card (Seed P) : ℝ) ^ (32 * P.gCoarse) := by
      convert hcb using 3
    calc (((Finset.univ.filter fun z => Bad z).card : ℕ) : ℝ≥0∞)
        = ENNReal.ofReal (((Finset.univ.filter fun z => Bad z).card : ℕ) : ℝ) :=
          (ENNReal.ofReal_natCast _).symm
      _ ≤ ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax) * (Fintype.card (Seed P) : ℝ) ^ (32 * P.gCoarse)) :=
          ENNReal.ofReal_le_ofReal hcb'
      _ = ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * c ^ (32 * P.gCoarse) := by
          rw [ENNReal.ofReal_mul hβ, ENNReal.ofReal_pow (Nat.cast_nonneg _), ENNReal.ofReal_natCast]
  calc c⁻¹ ^ (32 * P.gCoarse) * (((Finset.univ.filter fun z => Bad z).card : ℕ) : ℝ≥0∞)
      ≤ c⁻¹ ^ (32 * P.gCoarse) * (ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * c ^ (32 * P.gCoarse)) :=
        mul_le_mul_of_nonneg_left hcard zero_le
    _ = ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * (c⁻¹ ^ (32 * P.gCoarse) * c ^ (32 * P.gCoarse)) := by
        ring
    _ = ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) := by
        rw [← mul_pow, ENNReal.inv_mul_cancel hc0 hcT, one_pow, mul_one]

open Classical in
/-- **The coarse group count**: for every fixed target `w`, at most a `β_B/(2R_max)` fraction of the bit strings
(of any length) make the fresh coarse group fail the exact coarse moment event for `w`. -/
theorem group_count (P : StreamParams) (hP : ParamsOK P) (w : EuclideanSpace ℝ (Fin P.Dstar)) (n : ℕ) :
    ∑ l ∈ TBitProg.lenFinset n,
      (if ∃ grp rest, (sampleList (sampleList (newRow P) 32) P.gCoarse).run l = some (grp, rest) ∧
          ¬ (9 / 16 * ‖w‖ ^ 2 ≤ coarseEst (rowVals (sgn P) w (groupSeeds P grp)) ∧
             coarseEst (rowVals (sgn P) w (groupSeeds P grp)) ≤ 23 / 16 * ‖w‖ ^ 2)
        then (1 : ℝ≥0∞) else 0) ≤ ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * 2 ^ n := by
  by_cases hn : (sampleList (sampleList (newRow P) 32) P.gCoarse).depth ≤ n
  · exact GroupCount.group_count_of_depth P hP w n hn
  · have hD := GroupCount.exact_group P
    have hlt : n < P.gCoarse * (32 * (2 * P.s * P.w + 0)) :=
      lt_of_lt_of_le (not_le.1 hn) hD.depth_le
    rw [Finset.sum_eq_zero fun l hl => ?_]
    · exact zero_le
    · rw [if_neg]
      rintro ⟨grp, rest, hrun, -⟩
      rw [hD.run_none (by rw [TBitProg.mem_lenFinset.1 hl]; exact hlt)] at hrun
      simp at hrun

end F2e2e.C.Closure
