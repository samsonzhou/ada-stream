import F2e2e.C.SpaceAdaBound
import F2e2e.Cost.MachineBridge
import F2e2e.Cost.MachineWork

/-!
# The end-to-end space chain of Theorem (C) (Spec v2: bits on the small-step machine)

The space claim of Theorem (C) is measured in bits on the small-step machine (Spec v2's
`RunsWithinBits`: the footprint of every step, i.e. the bits of the configuration before plus after;
Spec v2.1 adds the arithmetic workspace of each primitive step). The chain from the algorithm's memory
to the bound `spaceBoundC = 2^512 ε^{-2} Λ^15`:

1. **Memory** (Lemma 6.3, `F2e2e/C/SpaceState.lean`, `F2e2e/C/SpaceAdaBound.lean`): every encoded
   state, and (C-TOP's uniform value bound) every value produced in a round, has at most
   `Mv adaRep P = 2^32 · stateSizeBound P (adaRep.bound P)` tree units.
2. **Big-step peak** (C-TOP's generic space theorem, `F2e2e/Cost/Generic.lean`): a run of the assembled
   program has peak `S₀ ≤ base + D · Mv` (at the entry point `D = (r₀ + 1)(K + 3) + 1`, `base = 0`).
3. **Machine bits** (17fc0802's bridge, `F2e2e/Cost/MachineBridge.lean`): footprint
   `≤ 2 (bitsFactor prog · S₀ + bitsConst prog)`; with Spec v2.1's per-step workspace
   (`opWork ≤ c · (operand bits) + c′`), `≤ (c + 2)(bitsFactor prog · S₀ + bitsConst prog) + c′`.
4. **The arithmetic** (this file): all of it is at most `spaceBoundC n m U ε β`, through
   `const_mul_stateSizeBound_adaRep_le_spaceBoundC` (every multiple `≤ 2^167` of the encoded-memory bound
   fits).

Statements (parametric in the program's size and depth and in the workspace constants, so they plug in
once the assembled program and Spec v2.1 land):

* `le_spaceBoundC_of_le_Mv`: `T ≤ α · Mv + γ` with `α · 2^32 + γ ≤ 2^167` gives `T ≤ spaceBoundC`;
* `spaceChain`: for `S₀ ≤ base + D · Mv`, `base ≤ Mv`,
  `(c + 2)(K S₀ + K′) + c′ ≤ spaceBoundC` whenever `K (D + 1)(c + 2) 2^32 + K′ (c + 2) + c′ ≤ 2^167`;
* `spaceChain_prog`: the same for `K = bitsFactor prog`, `K′ = bitsConst prog` under
  `progDepth prog ≤ 2^10`, `|prog| + 1 ≤ 2^{2^{10}}`, `D ≤ 2^40`, `c ≤ 2^10`, `c′ ≤ 2^100` (C-TOP's
  programs: `|prog| ≤ 901`, `progDepth ≤ 2^8`, `D ≤ 2^20`; 17fc0802's `c ≤ 8`, `c′ ≤ 64`);
* `runsWithinBitsFP_spaceBoundC` (and `'` without `base`): a big-step run within `S₀ ≤ base + D · Mv`
  is a machine run whose every step has footprint at most `spaceBoundC` bits (the Spec v2 obligation,
  through `F2e2e.Machine.runsWithinBitsFP_of_runsOn`);
* `runsWithinBitsW_spaceBoundC` (and `'`): the same for Spec v2.1's `RunsWithinBitsW` (footprint plus
  per-step arithmetic workspace plus finite-control temporaries), through 17fc0802's
  `F2e2e.Machine.runsWithinBitsW_of_runsOn` (constants `bridgeWC ≤ 2^10`, `bridgeWC' ≤ 2^100`).
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (adaRep Mv)

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate the parameters
symbolically and elaboration explodes. -/
attribute [local irreducible] Nat.clog Nat.log

/-- The encoded-memory bound is at least `1`. -/
theorem one_le_stateSizeBound (P : StreamParams) (b : ℕ) : 1 ≤ stateSizeBound P b := by
  have hL := hundred_le_calL P
  have h : 0 < 2 ^ 5 * P.calL ^ 3 := Nat.mul_pos (by norm_num) (pow_pos (by omega) 3)
  unfold stateSizeBound
  omega

/-- **The final arithmetic** (Lemma 6.3, partIII.tex L1252–1260): a quantity bounded by an affine
function `α · Mv + γ` of C-TOP's value bound `Mv adaRep P = 2^32 · stateSizeBound P (adaRep.bound P)`
with `α · 2^32 + γ ≤ 2^167` is at most `spaceBoundC n m U ε β = 2^512 ε^{-2} Λ^15`. -/
theorem le_spaceBoundC_of_le_Mv {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {α γ T : ℝ} (hα : 0 ≤ α)
    (hγ : 0 ≤ γ) (hαγ : α * 2 ^ 32 + γ ≤ 2 ^ 167)
    (hT : T ≤ α * (Mv adaRep (mkStreamParams n m U ε β) : ℝ) + γ) :
    T ≤ spaceBoundC n m U ε β := by
  set P := mkStreamParams n m U ε β with hPdef
  set X : ℝ := (stateSizeBound P (adaRep.bound P) : ℝ) with hX
  have hX1 : 1 ≤ X := by
    rw [hX]; exact_mod_cast one_le_stateSizeBound P (adaRep.bound P)
  have hMv : (Mv adaRep P : ℝ) = 2 ^ 32 * X := by
    rw [hX]; unfold F2e2e.C.Impl.Mv; push_cast; ring
  have h := const_mul_stateSizeBound_adaRep_le_spaceBoundC hn hm hU hε0 hε1 hβ0 hβ1 hP
    (c := α * 2 ^ 32 + γ) (by positivity) hαγ
  have hγX : γ ≤ γ * X := le_mul_of_one_le_right hγ hX1
  calc T ≤ α * (2 ^ 32 * X) + γ := by rw [← hMv]; exact hT
    _ ≤ (α * 2 ^ 32 + γ) * X := by nlinarith
    _ ≤ spaceBoundC n m U ε β := h

/-- **The space chain** (abstract form): if a run has big-step peak `S₀ ≤ base + D · Mv` with
`base ≤ Mv`, then every bound of the form `(c + 2)(K S₀ + K′) + c′` (the machine-bit bound of
17fc0802's bridge, `K = bitsFactor prog`, `K′ = bitsConst prog`, Spec v2.1's workspace constants
`c, c′`; Spec v2: `c = c′ = 0`) is at most `spaceBoundC`, provided
`K (D + 1)(c + 2) 2^32 + K′ (c + 2) + c′ ≤ 2^167`. -/
theorem spaceChain {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {K K' D base c c' S0 : ℝ}
    (hK : 0 ≤ K) (hK' : 0 ≤ K') (hD : 0 ≤ D) (hc : 0 ≤ c) (hc' : 0 ≤ c')
    (hconst : K * (D + 1) * (c + 2) * 2 ^ 32 + K' * (c + 2) + c' ≤ 2 ^ 167)
    (hbase : base ≤ (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (hS0 : S0 ≤ base + D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ)) :
    (c + 2) * (K * S0 + K') + c' ≤ spaceBoundC n m U ε β := by
  set M : ℝ := (Mv adaRep (mkStreamParams n m U ε β) : ℝ) with hM
  refine le_spaceBoundC_of_le_Mv hn hm hU hε0 hε1 hβ0 hβ1 hP (α := K * (D + 1) * (c + 2))
    (γ := K' * (c + 2) + c') (by positivity) (by positivity) (by linarith) ?_
  have h1 : S0 ≤ (D + 1) * M := by linarith
  have h2 : K * S0 ≤ K * ((D + 1) * M) := mul_le_mul_of_nonneg_left h1 hK
  have h3 : (c + 2) * (K * S0 + K') ≤ (c + 2) * (K * ((D + 1) * M) + K') :=
    mul_le_mul_of_nonneg_left (by linarith) (by linarith)
  calc (c + 2) * (K * S0 + K') + c' ≤ (c + 2) * (K * ((D + 1) * M) + K') + c' := by linarith
    _ = K * (D + 1) * (c + 2) * M + (K' * (c + 2) + c') := by ring

/-- The machine constants of a program of depth `≤ 2^10` with `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`. -/
theorem bitsFactor_bitsConst_le {prog : List Expr} {Dp w : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) :
    F2e2e.Machine.bitsFactor prog ≤ 2 ^ 24 ∧ F2e2e.Machine.bitsConst prog ≤ 2 ^ 25 := by
  have h1 := F2e2e.Machine.bitsFactor_le hDp hw
  have h2 := F2e2e.Machine.bitsConst_le hDp hw
  have hDp' : Dp ≤ 1024 := by simpa using hDp10
  have hw' : w ≤ 1024 := by simpa using hw10
  have a1 : Dp + 1 ≤ 2048 := by omega
  have a2 : w + 3 * Dp + 11 ≤ 8192 := by omega
  have a3 : w + 3 * Dp + 8 ≤ 8192 := by omega
  constructor
  · calc _ ≤ (Dp + 1) * (w + 3 * Dp + 11) := h1
      _ ≤ 2048 * 8192 := Nat.mul_le_mul a1 a2
      _ = 2 ^ 24 := by norm_num
  · have h4 := Nat.mul_le_mul a1 a3
    calc _ ≤ (Dp + 1) * (w + 3 * Dp + 8) + 1 := h2
      _ ≤ 2048 * 8192 + 1 := by omega
      _ ≤ 2 ^ 25 := by norm_num

/-- **The space chain for a program** (`K = bitsFactor prog`, `K′ = bitsConst prog`): for a program of
depth `≤ 2^10` and size `< 2^{2^{10}}`, a big-step peak `S₀ ≤ base + D · Mv` with `D ≤ 2^40`,
`base ≤ Mv`, and workspace constants `c ≤ 2^10`, `c′ ≤ 2^100`:
`(c + 2)(bitsFactor prog · S₀ + bitsConst prog) + c′ ≤ spaceBoundC`. -/
theorem spaceChain_prog {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {prog : List Expr} {Dp w D c c' : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : D ≤ 2 ^ 40) (hc : c ≤ 2 ^ 10) (hc' : c' ≤ 2 ^ 100) {base S0 : ℝ}
    (hbase : base ≤ (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (hS0 : S0 ≤ base + D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ)) :
    ((c : ℝ) + 2) * ((F2e2e.Machine.bitsFactor prog : ℝ) * S0 + (F2e2e.Machine.bitsConst prog : ℝ)) +
      (c' : ℝ) ≤ spaceBoundC n m U ε β := by
  obtain ⟨hK, hK'⟩ := bitsFactor_bitsConst_le hDp hw hDp10 hw10
  refine spaceChain hn hm hU hε0 hε1 hβ0 hβ1 hP (Nat.cast_nonneg _) (Nat.cast_nonneg _)
    (Nat.cast_nonneg _) (Nat.cast_nonneg _) (Nat.cast_nonneg _) ?_ hbase hS0
  have hnat : F2e2e.Machine.bitsFactor prog * (D + 1) * (c + 2) * 2 ^ 32 +
      F2e2e.Machine.bitsConst prog * (c + 2) + c' ≤ 2 ^ 167 := by
    have e1 : D + 1 ≤ 2 ^ 41 := by
      have : (2 : ℕ) ^ 41 = 2 * 2 ^ 40 := by norm_num
      have : 1 ≤ 2 ^ 40 := Nat.one_le_two_pow
      omega
    have e2 : c + 2 ≤ 2 ^ 11 := by
      have : (2 : ℕ) ^ 11 = 2 * 2 ^ 10 := by norm_num
      have : 2 ≤ 2 ^ 10 := by norm_num
      omega
    have t1 : F2e2e.Machine.bitsFactor prog * (D + 1) * (c + 2) * 2 ^ 32 ≤
        2 ^ 24 * 2 ^ 41 * 2 ^ 11 * 2 ^ 32 :=
      Nat.mul_le_mul_right _ (Nat.mul_le_mul (Nat.mul_le_mul hK e1) e2)
    have t2 : F2e2e.Machine.bitsConst prog * (c + 2) ≤ 2 ^ 25 * 2 ^ 11 := Nat.mul_le_mul hK' e2
    calc F2e2e.Machine.bitsFactor prog * (D + 1) * (c + 2) * 2 ^ 32 +
          F2e2e.Machine.bitsConst prog * (c + 2) + c'
        ≤ 2 ^ 24 * 2 ^ 41 * 2 ^ 11 * 2 ^ 32 + 2 ^ 25 * 2 ^ 11 + 2 ^ 100 :=
          Nat.add_le_add (Nat.add_le_add t1 t2) hc'
      _ ≤ 2 ^ 167 := by norm_num
  exact_mod_cast hnat

/-- **The Spec v2 space obligation for one run**: a big-step run of `prog` within peak
`S₀ ≤ base + D · Mv` (`base ≤ Mv`, `D ≤ 2^40`; program depth `≤ 2^10`, `|prog| + 1 ≤ 2^w`,
`w ≤ 2^10`) is a run of the small-step machine with the same output and unread tape in which every step
has footprint (bits of the configuration before plus after) at most `spaceBoundC n m U ε β`. -/
theorem runsWithinBitsFP_spaceBoundC {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {prog : List Expr} {Dp w D : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : D ≤ 2 ^ 40) {input : Val} {tape : List Bool} {out : Val}
    {base S0 : ℝ} (hbase : base ≤ (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (hS0 : S0 ≤ base + D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (h : RunsOn prog input tape out S0) :
    F2e2e.Machine.RunsWithinBitsFP prog input tape out (spaceBoundC n m U ε β) := by
  refine (F2e2e.Machine.runsWithinBitsFP_of_runsOn h).mono ?_
  have h0 := spaceChain_prog hn hm hU hε0 hε1 hβ0 hβ1 hP hDp hw hDp10 hw10 hD (c := 0) (c' := 0)
    (by norm_num) (by norm_num) hbase hS0
  norm_num at h0
  exact h0

/-- `runsWithinBitsFP_spaceBoundC` without the base term (C-TOP's GST at the entry point:
`S₀ ≤ ((r₀ + 1)(K + 3) + 1) · Mv`). -/
theorem runsWithinBitsFP_spaceBoundC' {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m)
    (hU : 1 ≤ U) (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {prog : List Expr} {Dp w D : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : D ≤ 2 ^ 40) {input : Val} {tape : List Bool} {out : Val} {S0 : ℝ}
    (hS0 : S0 ≤ D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (h : RunsOn prog input tape out S0) :
    F2e2e.Machine.RunsWithinBitsFP prog input tape out (spaceBoundC n m U ε β) :=
  runsWithinBitsFP_spaceBoundC hn hm hU hε0 hε1 hβ0 hβ1 hP hDp hw hDp10 hw10 hD (base := 0)
    (Nat.cast_nonneg _) (by linarith) h

/-- **The Spec v2.1 space obligation for one run** (`RunsWithinBitsW`: footprint plus arithmetic
workspace plus finite-control temporaries, 17fc0802's `runsWithinBitsW_of_runsOn` with the constants
`bridgeWC = 12`, `bridgeWC' = 132`): a big-step run of `prog` within peak `S₀ ≤ base + D · Mv`
(`base ≤ Mv`, `D ≤ 2^40`; program depth `≤ 2^10`, `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`) is a machine run within
`spaceBoundC n m U ε β`. -/
theorem runsWithinBitsW_spaceBoundC {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m) (hU : 1 ≤ U)
    (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {prog : List Expr} {Dp w D : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : D ≤ 2 ^ 40) {input : Val} {tape : List Bool} {out : Val}
    {base S0 : ℝ} (hbase : base ≤ (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (hS0 : S0 ≤ base + D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (h : RunsOn prog input tape out S0) :
    F2e2e.Machine.RunsWithinBitsW prog input tape out (spaceBoundC n m U ε β) :=
  (F2e2e.Machine.runsWithinBitsW_of_runsOn h).mono
    (spaceChain_prog hn hm hU hε0 hε1 hβ0 hβ1 hP hDp hw hDp10 hw10 hD
      (by rw [F2e2e.Machine.bridgeWC_eq]; norm_num) (by rw [F2e2e.Machine.bridgeWC'_eq]; norm_num)
      hbase hS0)

/-- `runsWithinBitsW_spaceBoundC` without the base term (`S₀ ≤ D · Mv`). -/
theorem runsWithinBitsW_spaceBoundC' {n m U : ℕ} {ε β : ℝ} (hn : 1 ≤ n) (hm : 1 ≤ m)
    (hU : 1 ≤ U) (hε0 : 0 < ε) (hε1 : ε < 1 / 10) (hβ0 : 0 < β) (hβ1 : β < 1 / 10)
    (hP : F2e2e.C.Top.ParamsOK (mkStreamParams n m U ε β)) {prog : List Expr} {Dp w D : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : D ≤ 2 ^ 40) {input : Val} {tape : List Bool} {out : Val} {S0 : ℝ}
    (hS0 : S0 ≤ D * (Mv adaRep (mkStreamParams n m U ε β) : ℝ))
    (h : RunsOn prog input tape out S0) :
    F2e2e.Machine.RunsWithinBitsW prog input tape out (spaceBoundC n m U ε β) :=
  runsWithinBitsW_spaceBoundC hn hm hU hε0 hε1 hβ0 hβ1 hP hDp hw hDp10 hw10 hD (base := 0)
    (Nat.cast_nonneg _) (by linarith) h

end F2e2e.C.Space
