import Mathlib
import F2e2e.C.ClosureInv
import F2e2e.C.NormBank.StepAux

/-!
# Theorem 6.4, bank side: the bank part of the invariant through every block of a round
(proofs: C-BANK; statements: C-CLOSE)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree` (L466–517, coded in `F2e2e/C/Alg/AlgMCode.lean`),
Definition `R:def:binary-tree-architecture` (3) (bank `idx` = incoming bank of depth `idx`: primary array `x_idx`,
client-secondary array `y_idx`), Lemma `R:lem:sec6-precision` (iv) (counter drift `≤ ξ`, no saturation), Theorem
5.11 (2a) (forward products, via the window products of `F2e2e/C/ClosurePws.lean`).

Every lemma is **pure**: for one block of the controller code it maps the bank part `BankPart P ph S hists nev`
(`F2e2e/C/ClosureInv.lean`) to the bank part at the next moment, for the row-operation histories after the
block's bank operations (exactly as `runL` records them: `bankOp idx op` appends `op` to history `idx`
(`modifyAt`), `bankOpFrom idx op` to all histories `≥ idx` (`mapFrom`), `bankRetain n` keeps the first `n`,
`bankNew` appends an empty history) and the tree shadow after the block's analysis event, with `nev + 1` events.
The tree invariants at the two moments (C-TREE's `TreeInv`, available from the tree part) and the box promise give
the vector bounds `√(‖v‖² + ω) ≤ V` (`Tree.vector_bounds_inv`) that exclude saturation.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Initialization and Step 1 -/

/-- Round `1`: the root bank `𝓑_{-1}` (empty history) after the first `newRound`. -/
theorem bankPart_init (hP : ParamsOK P) :
    BankPart P (.births 0) ((Tree.TreeState.init P.Dstar).step P .newRound) [[]] 1 := by
  have hx0 : ((Tree.TreeState.init P.Dstar).step P .newRound).x 0 = 0 := by
    simp [Tree.TreeState.x, Tree.TreeState.init, Tree.TreeState.step]
  refine ⟨fun idx hidx => ?_, fun idx _ hl => absurd hl (Nat.not_lt_zero _), fun idx hidx ζ => ?_,
    fun idx _ hl => absurd hl (Nat.not_lt_zero _)⟩
  · have h0 : idx = 0 := by simpa using hidx
    rw [h0, hx0]
    rfl
  · have h0 : idx = 0 := by simpa using hidx
    rw [h0]
    show CtrW P _ 0 1 (errX P [] ζ)
    rw [errX_nil]
    exact ctrW_zero _ _ _

/-- A new round (`noteM newRound`), then Step 1's `bankRetainM (d₀ + 1)`. -/
theorem bankPart_newRound (hP : ParamsOK P) {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev : ℕ} (htree : Tree.TreeInv P .idle R S) (h : BankPart P .idle S hists nev) (hlen : hists.length ≤ P.H)
    {d0 : ℕ} (hd0 : d0 < P.H) :
    BankPart P (.births d0) (S.step P .newRound) (hists.take (d0 + 1)) (nev + 1) := by
  have hx : ∀ j, (S.step P .newRound).x j = S.x j := fun j => rfl
  have hlenT : ∀ idx, idx < (hists.take (d0 + 1)).length → idx < hists.length ∧ idx < d0 + 1 := by
    intro idx hidx
    rw [List.length_take] at hidx
    omega
  have hget : ∀ idx, idx < d0 + 1 → (hists.take (d0 + 1)).getD idx [] = hists.getD idx [] :=
    fun idx hi => getD_take_of_lt _ _ _ hi
  have hpws : ∀ D, D ≤ P.H → ∀ L, pws (S.step P .newRound) D 1 L = pws S D 1 L := by
    intro D hD L
    apply pws_newRound
    intro j hj e he
    exact Tree.log_t_le htree (show j < P.H by omega) e he
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · obtain ⟨h1, h2⟩ := hlenT idx hidx
    rw [hget idx h2, hx]
    exact h.shadowX idx h1
  · obtain ⟨h1, h2⟩ := hlenT idx hidx
    have hl' : idx < d0 := hl
    have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) :=
      h.shadowY idx h1 (show idx < P.H by omega)
    rw [hget idx h2, hY]
    rfl
  · obtain ⟨h1, h2⟩ := hlenT idx hidx
    rw [hget idx h2]
    exact ctrW_congr (h.driftX idx h1 ζ) (hpws idx (by omega)) (Nat.le_succ nev)
  · obtain ⟨h1, h2⟩ := hlenT idx hidx
    have hl' : idx < d0 := hl
    rw [hget idx h2]
    exact ctrW_congr (h.driftY idx h1 (show idx < P.H by omega) ζ) (hpws (idx + 1) (by omega))
      (Nat.le_succ nev)

/-- The birth of depth `d` (`birthCode`): `bankOp d resetY`, then (if `d + 2 ≤ H`) the new outgoing bank with an
empty history, then the analysis event `birth d` (the release of a birth cache does not change any history). -/
theorem bankPart_birth (hP : ParamsOK P) {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev d : ℕ} (htree : Tree.TreeInv P (.births d) R S) (h : BankPart P (.births d) S hists nev)
    (hd : d < P.H) (hlen : hists.length = d + 1) :
    BankPart P (.births (d + 1)) (S.step P (.birth d))
      (modifyAt (fun l => l ++ [RowOp.resetY]) d hists ++ (if d + 2 ≤ P.H then [[]] else [])) (nev + 1) := by
  have hxle : ∀ j, j ≤ d → (S.step P (.birth d)).x j = S.x j := fun j hj => Tree.x_birth_le S hj
  have hx1 : (S.step P (.birth d)).x (d + 1) = 0 := by
    rw [Tree.TreeState.x_succ, hxle d le_rfl, Tree.step_birth_r, Function.update_self, sub_self]
  have hpws : ∀ D, D ≤ d → ∀ L, pws (S.step P (.birth d)) D 1 L = pws S D 1 L :=
    fun D hD L => pws_birth S D 1 L hD
  have hlenM : (modifyAt (fun l => l ++ [RowOp.resetY]) d hists).length = d + 1 := by
    rw [length_modifyAt, hlen]
  have hgetlt : ∀ idx, idx < d →
      (modifyAt (fun l => l ++ [RowOp.resetY]) d hists ++ (if d + 2 ≤ P.H then [[]] else [])).getD idx [] =
        hists.getD idx [] := by
    intro idx hi
    rw [List.getD_append _ _ _ _ (by rw [hlenM]; omega),
      getD_modifyAt_of_lt _ _ _ _ (by rw [hlen]; omega), if_neg (by omega)]
  have hgetd : (modifyAt (fun l => l ++ [RowOp.resetY]) d hists ++
      (if d + 2 ≤ P.H then [[]] else [])).getD d [] = hists.getD d [] ++ [RowOp.resetY] := by
    rw [List.getD_append _ _ _ _ (by rw [hlenM]; omega),
      getD_modifyAt_of_lt _ _ _ _ (by rw [hlen]; omega), if_pos rfl]
  have hgetnew : (modifyAt (fun l => l ++ [RowOp.resetY]) d hists ++
      (if d + 2 ≤ P.H then [[]] else [])).getD (d + 1) [] = [] := by
    rw [List.getD_append_right _ _ _ _ (by rw [hlenM]), hlenM, Nat.sub_self]
    split_ifs <;> rfl
  have hlen' : (modifyAt (fun l => l ++ [RowOp.resetY]) d hists ++
      (if d + 2 ≤ P.H then [[]] else [])).length ≤ d + 2 := by
    rw [List.length_append, hlenM]
    split_ifs <;> simp
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · -- shadowX
    by_cases hi : idx < d
    · rw [hgetlt idx hi, hxle idx hi.le]
      exact h.shadowX idx (by omega)
    · by_cases hi' : idx = d
      · rw [hi', hgetd, bankShadowXY_resetY, hxle d le_rfl]
        exact h.shadowX d (by omega)
      · have hi1 : idx = d + 1 := by omega
        rw [hi1, hgetnew, hx1]
        rfl
  · -- shadowY
    have hl' : idx < d + 1 := hl
    by_cases hi : idx < d
    · have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) :=
        h.shadowY idx (by omega) (show idx < d from hi)
      rw [hgetlt idx hi, hY]
      show S.x (idx + 1) = (S.step P (.birth d)).x (idx + 1)
      rw [hxle (idx + 1) (by omega)]
    · have hi' : idx = d := by omega
      rw [hi', hgetd, bankShadowXY_resetY]
      show (0 : Tree.Vec P) = (S.step P (.birth d)).x (d + 1)
      rw [hx1]
  · -- driftX
    by_cases hi : idx < d
    · rw [hgetlt idx hi]
      exact ctrW_congr (h.driftX idx (by omega) ζ) (hpws idx hi.le) (Nat.le_succ nev)
    · by_cases hi' : idx = d
      · rw [hi', hgetd, errX_resetY]
        exact ctrW_congr (h.driftX d (by omega) ζ) (hpws d le_rfl) (Nat.le_succ nev)
      · have hi1 : idx = d + 1 := by omega
        rw [hi1, hgetnew, errX_nil]
        exact ctrW_zero _ _ _
  · -- driftY
    have hl' : idx < d + 1 := hl
    by_cases hi : idx < d
    · rw [hgetlt idx hi]
      exact ctrW_congr (h.driftY idx (by omega) (show idx < d from hi) ζ) (hpws (idx + 1) (by omega))
        (Nat.le_succ nev)
    · have hi' : idx = d := by omega
      rw [hi', hgetd, errY_resetY]
      exact ctrW_zero _ _ _

/-! ## Step 2 -/

/-- Step 2 (`step2Code`): `bankOpFrom 0 (phys (i+1) Δ)`, then the analysis event `phys i Δ`. -/
theorem bankPart_phys (hP : ParamsOK P) {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev : ℕ} (i : Fin P.n) (Δ : ℤ) (htree : Tree.TreeInv P (.births P.H) R S)
    (htree' : Tree.TreeInv P (.guards 0) R (S.step P (.phys i Δ)))
    (hbox : ‖(S.step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ)) (h : BankPart P (.births P.H) S hists nev)
    (hlen : hists.length = P.H) (hnev : nev + 1 ≤ P.T) :
    BankPart P (.guards 0) (S.step P (.phys i Δ))
      (mapFrom (fun l => l ++ [RowOp.phys (i.val + 1) Δ]) 0 hists) (nev + 1) := by
  have hvb := Tree.vector_bounds_inv htree' hbox
  have hu : Tree.unitAt P.Dstar (i.val + 1 - 1) = Tree.unitVec (Tree.physIdx P i) := by
    rw [Tree.unitVec_eq_unitAt, Nat.add_sub_cancel]
    rfl
  have hlenM : (mapFrom (fun l => l ++ [RowOp.phys (i.val + 1) Δ]) 0 hists).length = P.H := by
    rw [length_mapFrom, hlen]
  have hget : ∀ idx, idx < P.H → (mapFrom (fun l => l ++ [RowOp.phys (i.val + 1) Δ]) 0 hists).getD idx [] =
      hists.getD idx [] ++ [RowOp.phys (i.val + 1) Δ] := by
    intro idx hi
    rw [getD_mapFrom_of_lt _ _ _ _ (by rw [hlen]; exact hi), if_pos (Nat.zero_le _)]
  have hop : opOK P (RowOp.phys (i.val + 1) Δ) := by
    have := i.isLt
    exact ⟨by omega, by unfold StreamParams.Dstar; omega⟩
  have hxS : ∀ j, (S.step P (.phys i Δ)).x j = S.x j + (Δ : ℝ) • Tree.unitVec (Tree.physIdx P i) :=
    fun j => (Tree.TreeState.x_phys P S i Δ j).1
  have hdX : ∀ idx, idx < P.H → ∀ ζ, |errX P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx ≤ P.H by omega) (by omega) (by omega) (h.driftX idx (by omega) ζ)
  have hdY : ∀ idx, idx < P.H → ∀ ζ, |errY P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx + 1 ≤ P.H by omega) (by omega) (by omega)
      (h.driftY idx (by omega) (show idx < P.H from hi) ζ)
  have hshX : ∀ idx, idx < P.H →
      (bankShadowXY P (hists.getD idx [] ++ [RowOp.phys (i.val + 1) Δ])).1 = (S.step P (.phys i Δ)).x idx := by
    intro idx hi
    rw [bankShadowXY_phys]
    show (bankShadowXY P (hists.getD idx [])).1 + (Δ : ℝ) • Tree.unitAt P.Dstar (i.val + 1 - 1) = _
    rw [hu, hxS, h.shadowX idx (by omega)]
  have hshY : ∀ idx, idx < P.H →
      (bankShadowXY P (hists.getD idx [] ++ [RowOp.phys (i.val + 1) Δ])).2 = (S.step P (.phys i Δ)).y idx := by
    intro idx hi
    have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) :=
      h.shadowY idx (by omega) (show idx < P.H from hi)
    rw [bankShadowXY_phys]
    show (bankShadowXY P (hists.getD idx [])).2 + (Δ : ℝ) • Tree.unitAt P.Dstar (i.val + 1 - 1) =
      (S.step P (.phys i Δ)).x (idx + 1)
    rw [hu, hxS, hY]
  have hstep : ∀ idx, idx < P.H → ∀ ζ : Seed P,
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errX P (hists.getD idx [] ++ [RowOp.phys (i.val + 1) Δ]) ζ =
        opMultX P (RowOp.phys (i.val + 1) Δ) * errX P (hists.getD idx []) ζ + z) ∧
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errY P (hists.getD idx [] ++ [RowOp.phys (i.val + 1) Δ]) ζ =
        opMultY P (RowOp.phys (i.val + 1) Δ) * errY P (hists.getD idx []) ζ + z) := by
    intro idx hi ζ
    have hl : idx < Tree.Phase.live P.H (.guards 0) := hi
    refine err_step P _ _ hop ζ ?_ ?_
    · rw [hshX idx hi]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdX idx hi ζ)
    · rw [hshY idx hi]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdY idx hi ζ)
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · rw [hlenM] at hidx
    rw [hget idx hidx]
    exact hshX idx hidx
  · rw [hlenM] at hidx
    rw [hget idx hidx]
    exact hshY idx hidx
  · rw [hlenM] at hidx
    rw [hget idx hidx]
    obtain ⟨⟨z, hz, he⟩, -⟩ := hstep idx hidx ζ
    exact ctrW_step_same (h.driftX idx (by omega) ζ) (fun L => pws_phys S idx 1 L i Δ) he hz
  · rw [hlenM] at hidx
    rw [hget idx hidx]
    obtain ⟨-, ⟨z, hz, he⟩⟩ := hstep idx hidx ζ
    exact ctrW_step_same (h.driftY idx (by omega) (show idx < P.H from hidx) ζ)
      (fun L => pws_phys S (idx + 1) 1 L i Δ) he hz

/-- The zero-round bypass. -/
theorem bankPart_bypass {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev : ℕ}
    (h : BankPart P (.guards 0) S hists nev) : BankPart P .idle S hists nev :=
  ⟨h.shadowX, h.shadowY, h.driftX, h.driftY⟩

/-! ## Step 3 -/

/-- Step 3 at depth `d`, omitted guard: no bank operation, the analysis event `guard d g 0`. -/
theorem bankPart_guard_zero {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev d : ℕ}
    (htree : Tree.TreeInv P (.guards d) R S) (h : BankPart P (.guards d) S hists nev) (hd : d < P.H)
    (g : Fin P.Dstar) :
    BankPart P (.guards (d + 1)) (S.step P (.guard d g ((gridVal P.eHg 0 : ℚ) : ℝ))) hists (nev + 1) := by
  have h0 : ((gridVal P.eHg 0 : ℚ) : ℝ) = 0 := by simp [gridVal]
  have hx : ∀ j, (S.step P (.guard d g ((gridVal P.eHg 0 : ℚ) : ℝ))).x j = S.x j := by
    intro j
    rw [Tree.TreeState.x_guard, h0, zero_smul, add_zero, ite_self]
  have hpws : ∀ D L, pws (S.step P (.guard d g ((gridVal P.eHg 0 : ℚ) : ℝ))) D 1 L = pws S D 1 L :=
    fun D L => pws_guard S D 1 L d g _
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · rw [hx]
    exact h.shadowX idx hidx
  · have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) := h.shadowY idx hidx hl
    rw [hY]
    show S.x (idx + 1) = (S.step P (.guard d g ((gridVal P.eHg 0 : ℚ) : ℝ))).x (idx + 1)
    rw [hx]
  · exact ctrW_congr (h.driftX idx hidx ζ) (hpws idx) (Nat.le_succ nev)
  · exact ctrW_congr (h.driftY idx hidx hl ζ) (hpws (idx + 1)) (Nat.le_succ nev)

/-- Step 3 at depth `d`, injected guard `δ` (mantissa) on the (1-based) coordinate `gc`:
`bankOp d (guardY gc δ)`, `bankOpFrom (d+1) (guardXY gc δ)`, then the analysis event `guard d (gc − 1) δ`. -/
theorem bankPart_guard (hP : ParamsOK P) {R R' : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev d : ℕ} (gc : ℕ) (hgc : 1 ≤ gc) (hg : gc - 1 < P.Dstar) (δ : ℤ)
    (htree : Tree.TreeInv P (.guards d) R S)
    (htree' : Tree.TreeInv P (.guards (d + 1)) R' (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))))
    (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (h : BankPart P (.guards d) S hists nev) (hd : d < P.H)
    (hlen : hists.length = P.H) (hnev : nev + 1 ≤ P.T) :
    BankPart P (.guards (d + 1)) (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ)))
      (mapFrom (fun l => l ++ [RowOp.guardXY gc δ]) (d + 1)
        (modifyAt (fun l => l ++ [RowOp.guardY gc δ]) d hists)) (nev + 1) := by
  have hu : Tree.unitAt P.Dstar (gc - 1) = Tree.unitVec (⟨gc - 1, hg⟩ : Fin P.Dstar) := by
    rw [Tree.unitVec_eq_unitAt]
  have hxS : ∀ j, (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).x j =
      if d < j then S.x j + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitVec (⟨gc - 1, hg⟩ : Fin P.Dstar)
      else S.x j :=
    fun j => Tree.TreeState.x_guard P S d _ _ j
  have hlenM : (modifyAt (fun l => l ++ [RowOp.guardY gc δ]) d hists).length = P.H := by
    rw [length_modifyAt, hlen]
  have hlen' : (mapFrom (fun l => l ++ [RowOp.guardXY gc δ]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.guardY gc δ]) d hists)).length = P.H := by
    rw [length_mapFrom, hlenM]
  have hget : ∀ idx, idx < P.H → (mapFrom (fun l => l ++ [RowOp.guardXY gc δ]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.guardY gc δ]) d hists)).getD idx [] =
      if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.guardY gc δ]
      else hists.getD idx [] ++ [RowOp.guardXY gc δ] := by
    intro idx hi
    rw [getD_mapFrom_of_lt _ _ _ _ (by rw [hlenM]; exact hi),
      getD_modifyAt_of_lt _ _ _ _ (by rw [hlen]; exact hi)]
    by_cases h1 : idx < d
    · rw [if_neg (by omega), if_neg (by omega), if_pos h1]
    · by_cases h2 : idx = d
      · rw [if_neg (by omega), if_pos h2, if_neg h1, if_pos h2]
      · rw [if_pos (by omega), if_neg h2, if_neg h1, if_neg h2]
  have hvb := Tree.vector_bounds_inv htree' (by rw [Tree.TreeState.step_guard_x0]; exact hbox)
  have hdX : ∀ idx, idx < P.H → ∀ ζ, |errX P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx ≤ P.H by omega) (by omega) (by omega) (h.driftX idx (by omega) ζ)
  have hdY : ∀ idx, idx < P.H → ∀ ζ, |errY P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx + 1 ≤ P.H by omega) (by omega) (by omega)
      (h.driftY idx (by omega) (show idx < P.H from hi) ζ)
  have hpws : ∀ D L, pws (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))) D 1 L = pws S D 1 L :=
    fun D L => pws_guard S D 1 L d _ _
  have hopY : opOK P (RowOp.guardY gc δ) := ⟨hgc, by omega⟩
  have hopXY : opOK P (RowOp.guardXY gc δ) := ⟨hgc, by omega⟩
  -- the new shadows
  have hshX : ∀ idx, idx < P.H → (bankShadowXY P (if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.guardY gc δ]
      else hists.getD idx [] ++ [RowOp.guardXY gc δ])).1 =
        (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).x idx := by
    intro idx hi
    have hX := h.shadowX idx (by omega)
    by_cases h1 : idx < d
    · rw [if_pos h1, hxS, if_neg (by omega), hX]
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2, bankShadowXY_guardY]
        show (bankShadowXY P (hists.getD idx [])).1 = _
        rw [hxS, if_neg (by omega), hX]
      · rw [if_neg h1, if_neg h2, bankShadowXY_guardXY]
        show (bankShadowXY P (hists.getD idx [])).1 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (gc - 1) = _
        rw [hxS, if_pos (by omega), hX, hu]
  have hshY : ∀ idx, idx < P.H → (bankShadowXY P (if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.guardY gc δ]
      else hists.getD idx [] ++ [RowOp.guardXY gc δ])).2 =
        (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).y idx := by
    intro idx hi
    have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) :=
      h.shadowY idx (by omega) (show idx < P.H from hi)
    show _ = (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).x (idx + 1)
    by_cases h1 : idx < d
    · rw [if_pos h1, hxS, if_neg (by omega), hY]
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2, bankShadowXY_guardY]
        show (bankShadowXY P (hists.getD idx [])).2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (gc - 1) = _
        rw [hxS, if_pos (by omega), hY, hu]
      · rw [if_neg h1, if_neg h2, bankShadowXY_guardXY]
        show (bankShadowXY P (hists.getD idx [])).2 + ((gridVal P.eHg δ : ℚ) : ℝ) • Tree.unitAt P.Dstar (gc - 1) = _
        rw [hxS, if_pos (by omega), hY, hu]
  -- the error steps of the banks with a new operation
  have hstep : ∀ idx, idx < P.H → ∀ (op : RowOp), opOK P op →
      (bankShadowXY P (hists.getD idx [] ++ [op])).1 =
        (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).x idx →
      (bankShadowXY P (hists.getD idx [] ++ [op])).2 =
        (S.step P (.guard d ⟨gc - 1, hg⟩ ((gridVal P.eHg δ : ℚ) : ℝ))).y idx →
      ∀ ζ : Seed P,
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errX P (hists.getD idx [] ++ [op]) ζ =
        opMultX P op * errX P (hists.getD idx []) ζ + z) ∧
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errY P (hists.getD idx [] ++ [op]) ζ =
        opMultY P op * errY P (hists.getD idx []) ζ + z) := by
    intro idx hi op hop hsX hsY ζ
    have hl : idx < Tree.Phase.live P.H (.guards (d + 1)) := hi
    refine err_step P _ _ hop ζ ?_ ?_
    · rw [hsX]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdX idx hi ζ)
    · rw [hsY]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdY idx hi ζ)
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    exact hshX idx hidx
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    exact hshY idx hidx
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    have hsX := hshX idx hidx
    have hsY := hshY idx hidx
    by_cases h1 : idx < d
    · rw [if_pos h1]
      exact ctrW_congr (h.driftX idx (by omega) ζ) (hpws idx) (Nat.le_succ nev)
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2] at hsX hsY ⊢
        obtain ⟨⟨z, hz, he⟩, -⟩ := hstep idx hidx _ hopY hsX hsY ζ
        exact ctrW_step_same (h.driftX idx (by omega) ζ) (hpws idx) he hz
      · rw [if_neg h1, if_neg h2] at hsX hsY ⊢
        obtain ⟨⟨z, hz, he⟩, -⟩ := hstep idx hidx _ hopXY hsX hsY ζ
        exact ctrW_step_same (h.driftX idx (by omega) ζ) (hpws idx) he hz
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    have hsX := hshX idx hidx
    have hsY := hshY idx hidx
    have hY0 := h.driftY idx (by omega) (show idx < P.H from hidx) ζ
    by_cases h1 : idx < d
    · rw [if_pos h1]
      exact ctrW_congr hY0 (hpws (idx + 1)) (Nat.le_succ nev)
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2] at hsX hsY ⊢
        obtain ⟨-, ⟨z, hz, he⟩⟩ := hstep idx hidx _ hopY hsX hsY ζ
        exact ctrW_step_same hY0 (hpws (idx + 1)) he hz
      · rw [if_neg h1, if_neg h2] at hsX hsY ⊢
        obtain ⟨-, ⟨z, hz, he⟩⟩ := hstep idx hidx _ hopXY hsX hsY ζ
        exact ctrW_step_same hY0 (hpws (idx + 1)) he hz

/-! ## Step 4 -/

theorem bankPart_startStep4 {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev : ℕ}
    (h : BankPart P (.guards P.H) S hists nev) : BankPart P (.evals P.H) S hists nev :=
  ⟨h.shadowX, h.shadowY, h.driftX, h.driftY⟩

/-- Step 4 at depth `d`, `ACCEPT`: no bank operation (the validation call changes no history), the analysis event
`accept d`. -/
theorem bankPart_accept {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev d : ℕ}
    (htree : Tree.TreeInv P (.evals (d + 1)) R S) (h : BankPart P (.evals (d + 1)) S hists nev) (hd : d < P.H)
    (hlen : hists.length ≤ P.H) :
    BankPart P (.evals d) (S.step P (.accept d)) hists (nev + 1) := by
  have hx : ∀ j, (S.step P (.accept d)).x j = S.x j := fun j => rfl
  obtain ⟨e, l', hl, het, hiff, hrest⟩ := htree.log_phase d hd
  have hhead : ∀ e' ∈ (S.log d).head?, e'.out = .pending := by
    intro e' he'
    rw [hl] at he'
    simp only [List.head?_cons, Option.mem_def, Option.some.injEq] at he'
    rw [← he']
    exact hiff.1 (Nat.lt_succ_self d)
  have hpws : ∀ D L, pws (S.step P (.accept d)) D 1 L = pws S D 1 L := fun D L => pws_accept S D 1 L d hhead
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · rw [hx]
    exact h.shadowX idx hidx
  · exact h.shadowY idx hidx hl
  · exact ctrW_congr (h.driftX idx hidx ζ) (hpws idx) (Nat.le_succ nev)
  · exact ctrW_congr (h.driftY idx hidx hl ζ) (hpws (idx + 1)) (Nat.le_succ nev)

/-- Step 4 at depth `d`, the correction with multiplier `c = cInt h_step ∈ [1/2, 3/2]`: `bankOp d (scaleY cInt)`,
`bankOpFrom (d+1) (scaleXY cInt)`, then the analysis event `correct d c` (the releases change no history). -/
theorem bankPart_correct (hP : ParamsOK P) {R R' : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)}
    {nev d : ℕ} (cInt : ℤ) (hc1 : (1 / 2 : ℝ) ≤ ((gridVal P.eHstep cInt : ℚ) : ℝ))
    (hc2 : ((gridVal P.eHstep cInt : ℚ) : ℝ) ≤ 3 / 2)
    (htree : Tree.TreeInv P (.evals (d + 1)) R S)
    (htree' : Tree.TreeInv P (.evals d) R' (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))))
    (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (h : BankPart P (.evals (d + 1)) S hists nev) (hd : d < P.H)
    (hlen : hists.length = P.H) (hnev : nev + 1 ≤ P.T) :
    BankPart P (.evals d) (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ)))
      (mapFrom (fun l => l ++ [RowOp.scaleXY cInt]) (d + 1)
        (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d hists)) (nev + 1) := by
  have hcr := Tree.TreeState.correct_rescale P S d ((gridVal P.eHstep cInt : ℚ) : ℝ)
  have hxle : ∀ j, j ≤ d → (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).x j = S.x j :=
    fun j hj => Tree.TreeState.x_correct_of_le P S _ hj
  obtain ⟨e, l', hl, het, hiff, hrest⟩ := htree.log_phase d hd
  have hpend : e.out = .pending := hiff.1 (Nat.lt_succ_self d)
  have hl'' : ∀ e' ∈ l', e'.t < S.t := fun e' he' => (hrest e' he').1
  have hpws_lt : ∀ D, d < D → ∀ L,
      pws (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) D 1 (winShift d S.t L) =
        ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 1 * pws S D 1 L :=
    fun D hD L => pws_correct_lt S D 1 L hD _ hl het hpend hl''
  have hpws_ge : ∀ D, D ≤ d → ∀ L,
      pws (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) D 1 L = pws S D 1 L :=
    fun D hD L => pws_correct_ge S D 1 L hD _
  have hlenM : (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d hists).length = P.H := by
    rw [length_modifyAt, hlen]
  have hlen' : (mapFrom (fun l => l ++ [RowOp.scaleXY cInt]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d hists)).length = P.H := by
    rw [length_mapFrom, hlenM]
  have hget : ∀ idx, idx < P.H → (mapFrom (fun l => l ++ [RowOp.scaleXY cInt]) (d + 1)
      (modifyAt (fun l => l ++ [RowOp.scaleY cInt]) d hists)).getD idx [] =
      if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.scaleY cInt]
      else hists.getD idx [] ++ [RowOp.scaleXY cInt] := by
    intro idx hi
    rw [getD_mapFrom_of_lt _ _ _ _ (by rw [hlenM]; exact hi),
      getD_modifyAt_of_lt _ _ _ _ (by rw [hlen]; exact hi)]
    by_cases h1 : idx < d
    · rw [if_neg (by omega), if_neg (by omega), if_pos h1]
    · by_cases h2 : idx = d
      · rw [if_neg (by omega), if_pos h2, if_neg h1, if_pos h2]
      · rw [if_pos (by omega), if_neg h2, if_neg h1, if_neg h2]
  have hvb := Tree.vector_bounds_inv htree' (by rw [Tree.TreeState.step_correct_x0]; exact hbox)
  have hdX : ∀ idx, idx < P.H → ∀ ζ, |errX P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx ≤ P.H by omega) (by omega) (by omega) (h.driftX idx (by omega) ζ)
  have hdY : ∀ idx, idx < P.H → ∀ ζ, |errY P (hists.getD idx []) ζ| ≤ Precision.xi P := fun idx hi ζ =>
    ctrW_abs_le htree (show idx + 1 ≤ P.H by omega) (by omega) (by omega)
      (h.driftY idx (by omega) (show idx < P.H from hi) ζ)
  have hc : |((gridVal P.eHstep cInt : ℚ) : ℝ)| ≤ 2 := abs_le.mpr ⟨by linarith, by linarith⟩
  have hopY : opOK P (RowOp.scaleY cInt) := hc
  have hopXY : opOK P (RowOp.scaleXY cInt) := hc
  -- the new shadows
  have hshX : ∀ idx, idx < P.H → (bankShadowXY P (if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.scaleY cInt]
      else hists.getD idx [] ++ [RowOp.scaleXY cInt])).1 =
        (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).x idx := by
    intro idx hi
    have hX := h.shadowX idx (by omega)
    by_cases h1 : idx < d
    · rw [if_pos h1, hxle idx h1.le, hX]
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2, bankShadowXY_scaleY]
        show (bankShadowXY P (hists.getD idx [])).1 = _
        rw [hxle idx (by omega), hX]
      · rw [if_neg h1, if_neg h2, bankShadowXY_scaleXY]
        show ((gridVal P.eHstep cInt : ℚ) : ℝ) • (bankShadowXY P (hists.getD idx [])).1 = _
        rw [hcr.2.2 idx (by omega), hX]
  have hshY : ∀ idx, idx < P.H → (bankShadowXY P (if idx < d then hists.getD idx []
      else if idx = d then hists.getD idx [] ++ [RowOp.scaleY cInt]
      else hists.getD idx [] ++ [RowOp.scaleXY cInt])).2 =
        (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).y idx := by
    intro idx hi
    have hY : (bankShadowXY P (hists.getD idx [])).2 = S.x (idx + 1) :=
      h.shadowY idx (by omega) (show idx < P.H from hi)
    by_cases h1 : idx < d
    · rw [if_pos h1, hY]
      show S.x (idx + 1) = (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).x (idx + 1)
      rw [hxle (idx + 1) (by omega)]
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2, bankShadowXY_scaleY]
        show ((gridVal P.eHstep cInt : ℚ) : ℝ) • (bankShadowXY P (hists.getD idx [])).2 = _
        rw [hY, h2, hcr.2.1]
        rfl
      · rw [if_neg h1, if_neg h2, bankShadowXY_scaleXY]
        show ((gridVal P.eHstep cInt : ℚ) : ℝ) • (bankShadowXY P (hists.getD idx [])).2 =
          (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).x (idx + 1)
        rw [hcr.2.2 (idx + 1) (by omega), hY]
  -- the error steps of the banks with a new operation
  have hstep : ∀ idx, idx < P.H → ∀ (op : RowOp), opOK P op →
      (bankShadowXY P (hists.getD idx [] ++ [op])).1 =
        (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).x idx →
      (bankShadowXY P (hists.getD idx [] ++ [op])).2 =
        (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).y idx →
      ∀ ζ : Seed P,
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errX P (hists.getD idx [] ++ [op]) ζ =
        opMultX P op * errX P (hists.getD idx []) ζ + z) ∧
      (∃ z : ℝ, |z| ≤ (P.hb : ℝ) ∧ errY P (hists.getD idx [] ++ [op]) ζ =
        opMultY P op * errY P (hists.getD idx []) ζ + z) := by
    intro idx hi op hop hsX hsY ζ
    have hl : idx < Tree.Phase.live P.H (.evals d) := hi
    refine err_step P _ _ hop ζ ?_ ?_
    · rw [hsX]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdX idx hi ζ)
    · rw [hsY]
      exact nosat_of ζ (hvb.2.2.1 idx hl 0 (by norm_num) _ (by simp)) (hdY idx hi ζ)
  refine ⟨fun idx hidx => ?_, fun idx hidx hl => ?_, fun idx hidx ζ => ?_, fun idx hidx hl ζ => ?_⟩
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    exact hshX idx hidx
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    exact hshY idx hidx
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    have hsX := hshX idx hidx
    have hsY := hshY idx hidx
    have hX0 := h.driftX idx (by omega) ζ
    by_cases h1 : idx < d
    · rw [if_pos h1]
      exact ctrW_congr hX0 (hpws_ge idx h1.le) (Nat.le_succ nev)
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2] at hsX hsY ⊢
        obtain ⟨⟨z, hz, he⟩, -⟩ := hstep idx hidx _ hopY hsX hsY ζ
        exact ctrW_step_same hX0 (hpws_ge idx (by omega)) he hz
      · rw [if_neg h1, if_neg h2] at hsX hsY ⊢
        obtain ⟨⟨z, hz, he⟩, -⟩ := hstep idx hidx _ hopXY hsX hsY ζ
        exact ctrW_step_scale hX0 (hpws_lt idx (by omega)) he hz
  · rw [hlen'] at hidx
    rw [hget idx hidx]
    have hsX := hshX idx hidx
    have hsY := hshY idx hidx
    have hY0 := h.driftY idx (by omega) (show idx < P.H from hidx) ζ
    by_cases h1 : idx < d
    · rw [if_pos h1]
      exact ctrW_congr hY0 (hpws_ge (idx + 1) (by omega)) (Nat.le_succ nev)
    · by_cases h2 : idx = d
      · rw [if_neg h1, if_pos h2] at hsX hsY ⊢
        obtain ⟨-, ⟨z, hz, he⟩⟩ := hstep idx hidx _ hopY hsX hsY ζ
        exact ctrW_step_scale hY0 (hpws_lt (idx + 1) (by omega)) he hz
      · rw [if_neg h1, if_neg h2] at hsX hsY ⊢
        obtain ⟨-, ⟨z, hz, he⟩⟩ := hstep idx hidx _ hopXY hsX hsY ζ
        exact ctrW_step_scale hY0 (hpws_lt (idx + 1) (by omega)) he hz

theorem bankPart_endRound {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev : ℕ}
    (h : BankPart P (.evals 0) S hists nev) : BankPart P .idle S hists nev :=
  ⟨h.shadowX, h.shadowY, h.driftX, h.driftY⟩

/-! ## Counter precision (Lemma 6.1 (iv)) -/

/-- The primary counters of a bank `idx ≤ live` have drift `≤ ξ` on every seed (`nev ≤ T` rounding errors, each
amplified by at most `G`). -/
theorem BankPart.precX {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev : ℕ}
    (htree : Tree.TreeInv P ph R S) (h : BankPart P ph S hists nev) (hnev : nev ≤ P.T) {idx : ℕ}
    (hidx : idx < hists.length) (hlive : idx ≤ ph.live P.H) (hH : idx ≤ P.H) (ζ : Seed P) :
    |errX P (hists.getD idx []) ζ| ≤ Precision.xi P :=
  ctrW_abs_le htree hlive (by omega) hnev (h.driftX idx hidx ζ)

/-- The secondary counters of the bank of a live client have drift `≤ ξ` on every seed. -/
theorem BankPart.precY {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} {hists : List (List RowOp)} {nev : ℕ}
    (htree : Tree.TreeInv P ph R S) (h : BankPart P ph S hists nev) (hnev : nev ≤ P.T) {idx : ℕ}
    (hidx : idx < hists.length) (hlive : idx < ph.live P.H) (ζ : Seed P) :
    |errY P (hists.getD idx []) ζ| ≤ Precision.xi P :=
  ctrW_abs_le htree hlive (by have := htree.live_le; omega) hnev (h.driftY idx hidx hlive ζ)

end F2e2e.C.Closure
