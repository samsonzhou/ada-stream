import F2e2e.C.ParamsFacts

/-!
# Theorem (C) parameters: fingerprint, row field, coarse groups, the banks' dyadic ADA inputs

* Zero fingerprint (Algorithm `R:alg:zero-fingerprint`, partII.tex L219; Lemma `R:lem:zero-fingerprint`,
  L237–260; partIII.tex L1279): `q` is the least prime `≥ M_q = ⌈10nm(U+1)/β₀⌉^3` (`q_prime`, `Mq_le_q`,
  `q_le_of_prime`, `Mq_eq_ceil`), `q ≤ 2M_q` (Bertrand, `q_le_two_mul_Mq`), `q > U`, the seed sampler
  makes `⌈log₂(1000/β₀)⌉ = betaExp + 10` trials (`seedTrials_eq_ceil_logb`), and the failure budget
  `mn/q + 2^{-trials} ≤ β₀/1000 + β₀/1000 < β₀/8` (`fingerprint_budget`);
* row field `F_{2^w}`, `w = ⌈log₂(D_*+1)⌉` (partIII.tex L207): `D_* < 2^w`;
* coarse groups (partIII.tex L206): `g = 32⌈log₂(4R_max/β_B)⌉` (`gCoarse_eq_ceil_logb`) and the per-group
  failure bound `e^{-g/18} ≤ β_B/(4R_max)` (N30, partIII.tex L387);
* the dyadic inputs of each bank's ADA module (partIII.tex L205; partII.tex eq. `R:eq:sec3_dyadic_inputs`):
  `eBankA = ⌈log₂(1/a_num)⌉`, `eBankXi = ⌈log₂(1/(β_B/2))⌉` in the Spec's `dyadicExp` form.
-/

namespace F2e2e

namespace StreamParams

open ParamsAux

/-! ## The zero fingerprint -/

theorem q_prime (P : StreamParams) : P.q.Prime := (Nat.find_spec (exists_prime_ge P.Mq)).2

theorem Mq_le_q (P : StreamParams) : P.Mq ≤ P.q := (Nat.find_spec (exists_prime_ge P.Mq)).1

/-- `q` is the least prime `≥ M_q`. -/
theorem q_le_of_prime (P : StreamParams) {p : ℕ} (h : P.Mq ≤ p) (hp : p.Prime) : P.q ≤ p :=
  Nat.find_min' _ ⟨h, hp⟩

theorem one_le_Mq {P : StreamParams} (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) : 1 ≤ P.Mq := by
  unfold Mq
  apply Nat.one_le_pow
  have : 0 < 2 ^ P.betaExp := pow_pos (by norm_num) _
  have h1 : 0 < 10 * P.n := by omega
  have h2 : 0 < 10 * P.n * P.m := Nat.mul_pos h1 hm
  have h3 : 0 < 10 * P.n * P.m * (P.U + 1) := Nat.mul_pos h2 (Nat.succ_pos _)
  exact Nat.mul_pos h3 this

/-- Bertrand's postulate: `q ≤ 2 M_q` (partIII.tex L1249, Lemma 1.9(1)). -/
theorem q_le_two_mul_Mq {P : StreamParams} (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) : P.q ≤ 2 * P.Mq := by
  obtain ⟨p, hp, h1, h2⟩ := Nat.exists_prime_lt_and_le_two_mul P.Mq (by have := one_le_Mq hn hm; omega)
  exact (P.q_le_of_prime h1.le hp).trans h2

/-- Faithfulness of `Mq` to eq. `R:eq:prime-q-bound`: `M_q = ⌈10 n m (U+1)/β₀⌉^3`. -/
theorem Mq_eq_ceil (P : StreamParams) :
    P.Mq = ⌈(10 * P.n * P.m * (P.U + 1) : ℚ) / P.beta0⌉₊ ^ 3 := by
  have e : (10 * P.n * P.m * (P.U + 1) : ℚ) / P.beta0 =
      ((10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp : ℕ) : ℚ) := by
    unfold beta0
    push_cast
    rw [half_pow_eq_inv, div_inv_eq_mul]
  rw [e, Nat.ceil_natCast]
  rfl

/-- `q > U` (partIII.tex L1279: the fingerprint polynomial of a nonzero vector is nonzero mod `q`). -/
theorem U_lt_q {P : StreamParams} (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) : P.U < P.q := by
  have h1 : P.U + 1 ≤ 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp := by
    have h2 : 1 ≤ 10 * P.n * P.m * 2 ^ P.betaExp :=
      Nat.mul_pos (Nat.mul_pos (by omega) hm) (pow_pos (by norm_num) _)
    calc P.U + 1 = 1 * (P.U + 1) := (one_mul _).symm
      _ ≤ (10 * P.n * P.m * 2 ^ P.betaExp) * (P.U + 1) := Nat.mul_le_mul_right _ h2
      _ = 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp := by ring
  have h3 : 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp ≤ P.Mq := by
    unfold Mq
    exact Nat.le_self_pow (by norm_num) _
  have := P.Mq_le_q
  omega

/-- Faithfulness of `seedTrials` (Algorithm `R:alg:zero-fingerprint`, L219): `⌈log₂(1000/β₀)⌉ = betaExp + 10`. -/
theorem seedTrials_eq_ceil_logb (P : StreamParams) :
    (P.seedTrials : ℤ) = ⌈Real.logb 2 (1000 / (P.beta0 : ℝ))⌉ := by
  apply (ceil_logb_two_eq _ _).symm
  · unfold seedTrials beta0
    push_cast
    rw [half_pow_eq_inv, div_inv_eq_mul,
      show ((P.betaExp : ℤ) + 10 - 1) = ((P.betaExp + 9 : ℕ) : ℤ) by push_cast; ring, zpow_natCast,
      pow_add]
    have : (0 : ℝ) < 2 ^ P.betaExp := by positivity
    nlinarith
  · unfold seedTrials beta0
    push_cast
    rw [half_pow_eq_inv, div_inv_eq_mul,
      show ((P.betaExp : ℤ) + 10) = ((P.betaExp + 10 : ℕ) : ℤ) by push_cast; ring, zpow_natCast,
      pow_add]
    have : (0 : ℝ) < 2 ^ P.betaExp := by positivity
    nlinarith

/-- The seed sampler fails with probability `2^{-trials} ≤ β₀/1000` (Lemma 1.9(3)). -/
theorem half_pow_seedTrials_le (P : StreamParams) : (1 / 2 : ℚ) ^ P.seedTrials ≤ P.beta0 / 1000 := by
  unfold seedTrials beta0
  rw [pow_add]
  have : (0 : ℚ) ≤ (1 / 2) ^ P.betaExp := (half_pow_pos _).le
  have h10 : (1 / 2 : ℚ) ^ 10 ≤ 1 / 1000 := by norm_num
  calc (1 / 2 : ℚ) ^ P.betaExp * (1 / 2) ^ 10 ≤ (1 / 2) ^ P.betaExp * (1 / 1000) :=
        mul_le_mul_of_nonneg_left h10 this
    _ = (1 / 2) ^ P.betaExp / 1000 := by ring

/-- The polynomial-collision bound `mn/q ≤ β₀/1000` (Lemma 1.9(3)). -/
theorem mn_div_q_le {P : StreamParams} (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) :
    ((P.m * P.n : ℕ) : ℚ) / P.q ≤ P.beta0 / 1000 := by
  have hX : 1000 * (P.m * P.n) * 2 ^ P.betaExp ≤ P.q := by
    set X := 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp with hXdef
    have h2b : 1 ≤ 2 ^ P.betaExp := Nat.one_le_two_pow
    have hX1 : 10 * (P.m * P.n * 2 ^ P.betaExp) ≤ X := by
      rw [hXdef]
      calc 10 * (P.m * P.n * 2 ^ P.betaExp) = 10 * P.n * P.m * 1 * 2 ^ P.betaExp := by ring
        _ ≤ 10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp := by gcongr; omega
    have hX10 : 10 ≤ X := by
      have : 1 ≤ P.m * P.n * 2 ^ P.betaExp := Nat.mul_pos (Nat.mul_pos hm hn) h2b
      omega
    have hMq : X ^ 3 ≤ P.q := P.Mq_le_q
    calc 1000 * (P.m * P.n) * 2 ^ P.betaExp = 10 * (P.m * P.n * 2 ^ P.betaExp) * (10 * 10) := by ring
      _ ≤ X * (X * X) := Nat.mul_le_mul hX1 (Nat.mul_le_mul hX10 hX10)
      _ = X ^ 3 := by ring
      _ ≤ P.q := hMq
  have hq : (0 : ℚ) < P.q := by exact_mod_cast P.q_prime.pos
  rw [div_le_div_iff₀ hq (by norm_num)]
  push_cast
  have hX' : ((1000 * (P.m * P.n) * 2 ^ P.betaExp : ℕ) : ℚ) ≤ (P.q : ℚ) := by exact_mod_cast hX
  push_cast at hX'
  unfold beta0
  have hb : (1 / 2 : ℚ) ^ P.betaExp * 2 ^ P.betaExp = 1 := half_pow_mul_two_pow _
  have hb0 : (0 : ℚ) ≤ (1 / 2) ^ P.betaExp := (half_pow_pos _).le
  calc ((P.m : ℚ) * P.n) * 1000 = ((P.m : ℚ) * P.n) * 1000 * ((1 / 2) ^ P.betaExp * 2 ^ P.betaExp) := by
        rw [hb, mul_one]
    _ = (1 / 2) ^ P.betaExp * (1000 * ((P.m : ℚ) * P.n) * 2 ^ P.betaExp) := by ring
    _ ≤ (1 / 2) ^ P.betaExp * P.q := mul_le_mul_of_nonneg_left hX' hb0
    _ = (1 / 2) ^ P.betaExp * P.q := rfl

/-- The fingerprint failure budget (Lemma 1.9(3), partIII.tex L1279):
`mn/q + 2^{-trials} ≤ β₀/1000 + β₀/1000 < β₀/8`. -/
theorem fingerprint_budget {P : StreamParams} (hn : 1 ≤ P.n) (hm : 1 ≤ P.m) :
    ((P.m * P.n : ℕ) : ℚ) / P.q + (1 / 2 : ℚ) ^ P.seedTrials < P.beta0 / 8 := by
  have h1 := mn_div_q_le hn hm
  have h2 := P.half_pow_seedTrials_le
  have h3 := P.beta0_pos
  linarith

/-! ## The row field `F_{2^w}` (partIII.tex L207) -/

/-- `D_* < 2^w` (the field has at least `D_*` nonzero elements). -/
theorem Dstar_lt_two_pow_w (P : StreamParams) : P.Dstar < 2 ^ P.w := by
  have := le_pow_clog_two (P.Dstar + 1)
  unfold w
  omega

/-- Faithfulness of `w`: `w = ⌈log₂(D_* + 1)⌉`. -/
theorem w_eq_ceil_logb (P : StreamParams) : (P.w : ℤ) = ⌈Real.logb 2 ((P.Dstar : ℝ) + 1)⌉ := by
  have e : (P.Dstar : ℝ) + 1 = ((P.Dstar + 1 : ℕ) : ℝ) := by push_cast; ring
  rw [e, ceil_logb_two_natCast (by omega)]
  rfl

/-! ## Coarse groups (partIII.tex L206, L387) -/

/-- `4 R_max/β_B = 2^{betaExp + 8} R_max m (H+1)`. -/
theorem four_Rmax_div_betaB {P : StreamParams} (hm : 1 ≤ P.m) :
    4 * (P.Rmax : ℚ) / P.betaB = 2 ^ (P.betaExp + 8) * ((P.Rmax * P.m * (P.H + 1) : ℕ) : ℚ) := by
  have hm0 : (P.m : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hH0 : (P.H : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.H
  unfold betaB beta0
  push_cast
  rw [half_pow_eq_inv, div_div_eq_mul_div, div_inv_eq_mul, pow_add]
  ring

/-- Faithfulness of `gCoarse` (partIII.tex L206): `g = 32 ⌈log₂(4 R_max/β_B)⌉`. -/
theorem gCoarse_eq_ceil_logb {P : StreamParams} (hm : 1 ≤ P.m) :
    (P.gCoarse : ℤ) = 32 * ⌈Real.logb 2 (4 * (P.Rmax : ℝ) / (P.betaB : ℝ))⌉ := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) (four_Rmax_div_betaB hm)
  push_cast at h
  have hN : 1 ≤ P.Rmax * P.m * (P.H + 1) :=
    Nat.mul_pos (Nat.mul_pos (by unfold Rmax; omega) hm) (Nat.succ_pos _)
  have e : 4 * (P.Rmax : ℝ) / (P.betaB : ℝ) =
      (2 : ℝ) ^ (P.betaExp + 8) * ((P.Rmax * P.m * (P.H + 1) : ℕ) : ℝ) := by
    rw [h]; push_cast; ring
  rw [e, ceil_logb_two_pow_mul_natCast _ hN]
  unfold gCoarse
  push_cast
  ring

/-- The coarse-group failure bound (N30, partIII.tex L387): `e^{-g/18} ≤ β_B/(4 R_max) ≤ β_B/(2 R_max)`. -/
theorem exp_neg_gCoarse_le {P : StreamParams} (hm : 1 ≤ P.m) :
    Real.exp (-(P.gCoarse : ℝ) / 18) ≤ (P.betaB : ℝ) / (4 * P.Rmax) := by
  have h := congrArg (fun q : ℚ => (q : ℝ)) (four_Rmax_div_betaB hm)
  push_cast at h
  have hN : 1 ≤ P.Rmax * P.m * (P.H + 1) :=
    Nat.mul_pos (Nat.mul_pos (by unfold Rmax; omega) hm) (Nat.succ_pos _)
  set N := P.Rmax * P.m * (P.H + 1) with hNdef
  set c := P.betaExp + 8 + Nat.clog 2 N with hcdef
  have hX : 4 * (P.Rmax : ℝ) / (P.betaB : ℝ) = (2 : ℝ) ^ (P.betaExp + 8) * (N : ℝ) := by
    rw [h, hNdef]; push_cast; ring
  have hNpos : (0 : ℝ) < N := by exact_mod_cast hN
  have hXpos : 0 < 4 * (P.Rmax : ℝ) / (P.betaB : ℝ) := by
    rw [hX]; exact mul_pos (pow_pos (by norm_num) _) hNpos
  have hXc : 4 * (P.Rmax : ℝ) / (P.betaB : ℝ) ≤ 2 ^ c := by
    rw [hX, hcdef, pow_add (2 : ℝ) (P.betaExp + 8) (Nat.clog 2 N)]
    have : (N : ℝ) ≤ (2 : ℝ) ^ Nat.clog 2 N := by exact_mod_cast le_pow_clog_two N
    exact mul_le_mul_of_nonneg_left this (pow_nonneg (by norm_num) _)
  have hlog : Real.log (4 * (P.Rmax : ℝ) / (P.betaB : ℝ)) ≤ c * Real.log 2 := by
    calc Real.log (4 * (P.Rmax : ℝ) / (P.betaB : ℝ)) ≤ Real.log ((2 : ℝ) ^ c) :=
          Real.log_le_log hXpos hXc
      _ = c * Real.log 2 := by rw [Real.log_pow]
  have hl2 := Real.log_two_lt_d9
  have hc0 : (0 : ℝ) ≤ c := Nat.cast_nonneg _
  have hg' : P.gCoarse = 32 * c := rfl
  have hg : (P.gCoarse : ℝ) = 32 * c := by rw [hg']; push_cast; ring
  have key : Real.log (4 * (P.Rmax : ℝ) / (P.betaB : ℝ)) ≤ (P.gCoarse : ℝ) / 18 := by
    rw [hg]
    have := mul_le_mul_of_nonneg_left hl2.le hc0
    nlinarith
  calc Real.exp (-(P.gCoarse : ℝ) / 18) ≤ Real.exp (-Real.log (4 * (P.Rmax : ℝ) / (P.betaB : ℝ))) :=
        Real.exp_le_exp.mpr (by linarith)
    _ = (4 * (P.Rmax : ℝ) / (P.betaB : ℝ))⁻¹ := by rw [Real.exp_neg, Real.exp_log hXpos]
    _ = (P.betaB : ℝ) / (4 * P.Rmax) := by rw [inv_div]

/-! ## The dyadic inputs of each bank's ADA module (partIII.tex L205; eq. `R:eq:sec3_dyadic_inputs`) -/

/-- `1/a_num = 2^{18 + log₂(1/η)} s`. -/
theorem inv_aNum (P : StreamParams) : P.aNum⁻¹ = ((2 ^ (18 + P.eEta) * P.s : ℕ) : ℚ) := by
  unfold aNum L eta
  push_cast
  rw [inv_div, half_pow_eq_inv, div_inv_eq_mul, pow_add]
  ring

/-- The bank ADA's dyadic accuracy exponent is the Spec's `dyadicExp a_num = ⌈log₂(1/a_num)⌉`. -/
theorem eBankA_eq_dyadicExp (P : StreamParams) : P.eBankA = dyadicExp (P.aNum : ℝ) := by
  unfold dyadicExp
  rw [← Rat.cast_inv, inv_aNum, Rat.cast_natCast, Nat.ceil_natCast,
    clog_two_pow_mul _ (by unfold s; omega)]
  rfl

/-- `a = 2^{-⌈log₂(1/a_num)⌉} = dyadicDown a_num`. -/
theorem bankA_cast (P : StreamParams) : (P.bankA : ℝ) = dyadicDown (P.aNum : ℝ) := by
  unfold bankA dyadicDown
  rw [← eBankA_eq_dyadicExp]
  push_cast
  rfl

/-- `1/(β_B/2) = 2^{betaExp + 7} m (H+1)`. -/
theorem inv_bankXiReq {P : StreamParams} (hm : 1 ≤ P.m) :
    P.bankXiReq⁻¹ = ((2 ^ (P.betaExp + 7) * (P.m * (P.H + 1)) : ℕ) : ℚ) := by
  have hm0 : (P.m : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hH0 : (P.H : ℚ) + 1 ≠ 0 := Nat.cast_add_one_ne_zero P.H
  unfold bankXiReq betaB beta0
  push_cast
  rw [half_pow_eq_inv]
  field_simp
  rw [pow_add]
  ring

/-- The bank ADA's dyadic failure-probability exponent is `dyadicExp (β_B/2) = ⌈log₂(2/β_B)⌉`. -/
theorem eBankXi_eq_dyadicExp {P : StreamParams} (hm : 1 ≤ P.m) :
    P.eBankXi = dyadicExp (P.bankXiReq : ℝ) := by
  unfold dyadicExp
  rw [← Rat.cast_inv, inv_bankXiReq hm, Rat.cast_natCast, Nat.ceil_natCast,
    clog_two_pow_mul _ (Nat.mul_pos hm (Nat.succ_pos _))]
  rfl

/-- `ξ_A = 2^{-⌈log₂(1/(β_B/2))⌉} = dyadicDown (β_B/2)`. -/
theorem bankXiA_cast {P : StreamParams} (hm : 1 ≤ P.m) :
    (P.bankXiA : ℝ) = dyadicDown (P.bankXiReq : ℝ) := by
  unfold bankXiA dyadicDown
  rw [← eBankXi_eq_dyadicExp hm]
  push_cast
  rfl

end StreamParams

end F2e2e
