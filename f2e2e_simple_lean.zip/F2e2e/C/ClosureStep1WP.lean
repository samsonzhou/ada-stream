import Mathlib
import F2e2e.C.ClosureCalls

/-!
# Theorem 6.4: the invariant through Step 1 (proofs: C-ORC, from C-ALG's draft; statements: C-CLOSE)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree`, the start of a round and Step 1 (L472–478), as
coded in `F2e2e/C/Alg/AlgMCode.lean` (`roundCode`'s `noteM newRound`, `step1Code`, `birthLoopCode`,
`birthCode`), and the initialization (`initCode`).

The lemmas thread `JointInv` (`F2e2e/C/ClosureJoint.lean`) through the code with the WP calculus
(`F2e2e/C/ClosureWP.lean`, `F2e2e/C/ClosureWPRules.lean`), from the pure block lemmas `treePart_*`, `bankPart_*`,
`countPart_*`, `statePart_*` and the release glue `rel_glue` (`F2e2e/C/ClosureCalls.lean`). `GoodLog P gF`: the
bank events of the final log (`F2e2e/C/ClosureEvents.lean`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-- The statistical bank events on the final ghost data `gF` (all labels, all coarse groups). -/
def GoodLog (P : StreamParams) (gF : Ghost) : Prop := ∀ lab, AdaGood P lab gF ∧ ∀ k, CoarseGood P lab k gF

/-- The data after the initialization (`initCode`): round `0`, no learner, the root bank `(0,0)` (fresh), no call,
no event. -/
structure InitState (P : StreamParams) (c : CState) (o : OState) (g : Ghost) : Prop where
  ctrl : c = ⟨0, false, [], 0⟩
  bank : ∃ B, o.banks = [B] ∧ ((∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧
    (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) ∧
    B.adaSt.rej = 0 ∧ CoarseShape P B ∧ B.coarse.length = P.Rmax
  labels : g.labels = [(0, 0)]
  hists : g.hists = [[]]
  calls : g.calls = []
  events : g.events = []

/-! ## Helpers (C-ORC; adapted from C-ALG's draft `F2e2e/Scratch/CAlg/S1.lean`) -/

/-- The every-path facts of a fresh bank (`bitAlways_newBank_all`). -/
def St1BankFresh (P : StreamParams) (B : Bank) : Prop :=
  ((∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧ (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) ∧
    B.adaSt.rej = 0 ∧ CoarseShape P B ∧ B.coarse.length = P.Rmax

/-- The optional bank allocation of `birthCode` (`if d + 2 ≤ H then bankNewM tr d`), with the continuation
abstracted. -/
theorem st1_wp_ite_bankNew {F : List CallRec} {β : Type} {c : Prop} [Decidable c] {tr d : ℕ}
    {REST : AlgM β} {Q : β → OState → Ghost → Prop} {o : OState} {g : Ghost}
    (hrest : ∀ (o' : OState) (g' : Ghost) (Bo : List Bank),
      (c → ∃ B, Bo = [B] ∧ St1BankFresh P B) → (¬ c → Bo = []) →
      o'.banks = o.banks ++ Bo → o'.fpSeed = o.fpSeed → o'.fpVal = o.fpVal →
      g'.labels = g.labels ++ (if c then [(tr, d)] else []) →
      g'.hists = g.hists ++ (if c then [[]] else []) →
      g'.calls = g.calls → g'.events = g.events →
      WP P F REST Q o' g') :
    WP P F (if c then (bankNewM tr d).bind (fun _ => REST) else REST) Q o g := by
  by_cases hc : c
  · rw [if_pos hc]
    refine wp_bankNewM (bitAlways_newBank_all P) (fun B hB => ?_)
    exact hrest { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } [B]
      (fun _ => ⟨B, rfl, hB⟩) (fun h => absurd hc h) rfl rfl rfl
      (by simp [hc]) (by simp [hc]) rfl rfl
  · rw [if_neg hc]
    exact hrest o g [] (fun h => absurd h hc) (fun _ => rfl) (by simp) rfl rfl
      (by simp [hc]) (by simp [hc]) rfl rfl

theorem st1_time_births {d : ℕ} {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.births d) c o g) :
    (shadowOf P g).t = c.t + 1 := by
  have := h.time
  simpa [phIdle] using this

theorem st1_time_idle {c : CState} {o : OState} {g : Ghost} (h : JointInv P .idle c o g) :
    (shadowOf P g).t = c.t := by
  have := h.time
  simpa [phIdle] using this

theorem st1_hists_len {d : ℕ} {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.births d) c o g)
    (hd : d < P.H) : g.hists.length = d + 1 := by
  have := h.hists_len
  simp only [Tree.Phase.live] at this
  rw [this]
  omega

theorem st1_labels_len {d : ℕ} {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.births d) c o g)
    (hd : d < P.H) : g.labels.length = d + 1 := by
  have := h.cp.nLab
  simp only [Tree.Phase.live] at this
  rw [this]
  omega

theorem st1_labelAt_append (e : List BankLabel) (g g' : Ghost) (hl : g'.labels = g.labels ++ e)
    {j : ℕ} (hj : j < g.labels.length) : g'.labelAt j = g.labelAt j := by
  unfold Ghost.labelAt
  rw [hl, List.getD_append _ _ _ _ hj]

/-- The label of a newly allocated outgoing bank is fresh. -/
theorem st1_fresh_label {d : ℕ} {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.births d) c o g)
    (hd : d < P.H) : ∀ rec ∈ g.calls, rec.lab ≠ (c.t + 1, d) := by
  rw [← st1_time_births h]
  exact h.cp.fresh_new hd

/-- Distinct labels at the release of a birth cache. -/
theorem st1_label_inj {d : ℕ} {c : CState} {o : OState} {g g' : Ghost} (h : JointInv P (.births d) c o g)
    (hd : d < P.H) (hd1 : 1 ≤ d) {e : List BankLabel} (hl : g'.labels = g.labels ++ e)
    (he : ∀ lab ∈ e, lab.2 = d) :
    ∀ j < g'.labels.length, g'.labelAt j = g'.labelAt d → j = d := by
  intro j hj hjd
  have hlen := st1_labels_len h hd
  have hdl : g'.labelAt d = g.labelAt d := st1_labelAt_append e g g' hl (by omega)
  have hsd := h.cp.labelSucc d hd1 (by omega)
  by_cases hjl : j < g.labels.length
  · rw [st1_labelAt_append e g g' hl hjl, hdl] at hjd
    exact countPart_label_inj h.cp hjl (by omega) hjd
  · exfalso
    have hje : g'.labelAt j ∈ e := by
      unfold Ghost.labelAt
      rw [hl, List.getD_append_right _ _ _ _ (by omega)]
      have hj' : j - g.labels.length < e.length := by
        rw [hl, List.length_append] at hj
        omega
      rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hj', Option.getD_some]
      exact List.getElem_mem hj'
    have h2 := he _ hje
    rw [hjd, hdl, hsd] at h2
    simp only at h2
    omega

theorem st1_x_zero (S : Tree.TreeSt P) : S.x 0 = S.x0 := by
  unfold Tree.TreeState.x
  simp

theorem st1_x_step_birth (S : Tree.TreeSt P) (d : ℕ) : (S.step P (.birth d)).x d = S.x d := by
  unfold Tree.TreeState.x
  rw [Tree.step_birth_x0]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [Tree.step_birth_r, Function.update_of_ne (by simp at hj; omega)]

/-- The joint invariant after a birth (pure; the code's data enter through field equations). -/
theorem st1_jointInv_birth (hP : ParamsOK P) {c c' : CState} {o o' : OState} {g g' : Ghost} {d : ℕ}
    (h : JointInv P (.births d) c o g) (hd : d < P.H)
    (htp : TreePart P (.births (d + 1)) c' ((shadowOf P g).step P (.birth d)) (g.events.length + 1))
    (hct : c'.t = c.t) (hcf : c'.failed = c.failed)
    (hcp : CountPart P (.births (d + 1)) c' g') (hsp : StatePart P o' g')
    (he : g'.events = g.events ++ [TreeEvent.birth d])
    (hh : g'.hists = modifyAt (fun l => l ++ [RowOp.resetY]) d g.hists ++
      (if d + 2 ≤ P.H then [[]] else [])) :
    JointInv P (.births (d + 1)) c' o' g' := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.birth d) := shadowOf_snoc P he (toTreeEv_birth d)
  have hlen : g'.events.length = g.events.length + 1 := by rw [he]; simp
  have hlenH := st1_hists_len h hd
  refine ⟨?_, ?_, hcp, hsp, ?_, ?_⟩
  · rw [hS, hlen]; exact htp
  · rw [hS, hlen, hh]; exact bankPart_birth hP h.tp.tree h.bp hd hlenH
  · rw [hcf]; exact h.notFailed
  · rw [hS]
    simp [phIdle, st1_time_births h, hct]

theorem st1_frame_birth {c c' : CState} {o o' : OState} {g g' : Ghost} {d : ℕ}
    (he : g'.events = g.events ++ [TreeEvent.birth d]) (hct : c'.t = c.t)
    (hs : o'.fpSeed = o.fpSeed) (hv : o'.fpVal = o.fpVal) : Frame (P := P) c o g c' o' g' := by
  have hS : shadowOf P g' = (shadowOf P g).step P (.birth d) := shadowOf_snoc P he (toTreeEv_birth d)
  refine ⟨hct, ?_, ?_, hs, hv⟩
  · rw [hS]; rfl
  · rw [hS]; rfl

/-- The registers of the learners after appending a new learner of depth `d = |learners|`. -/
theorem st1_regs_birth (c : CState) (d : ℕ) (hc0 : c.learners.length = d) (cache : ℤ) :
    (∀ j < d, (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).Chat j = (regsOf P c).Chat j ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).k j = (regsOf P c).k j ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).jE j = (regsOf P c).jE j ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).jU j = (regsOf P c).jU j) ∧
    ((regsOf P { c with learners := c.learners ++ [newLearner P cache] }).Chat d = 1 ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).k d = 0 ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).jE d = 0 ∧
      (regsOf P { c with learners := c.learners ++ [newLearner P cache] }).jU d = 0) := by
  refine ⟨fun j hj => ?_, ?_⟩
  · have e : (c.learners ++ [newLearner P cache]).getD j dfltLearner = c.learners.getD j dfltLearner :=
      List.getD_append _ _ _ _ (by omega)
    simp only [regsOf, tagVal, e, and_self]
  · have e : (c.learners ++ [newLearner P cache]).getD d dfltLearner = newLearner P cache := by
      rw [List.getD_append_right _ _ _ _ (by omega), hc0, Nat.sub_self]
      rfl
    have hg1 : gridVal P.eHC (2 ^ P.eHC) = 1 := by
      unfold gridVal
      push_cast
      exact div_self (pow_ne_zero _ (by norm_num))
    refine ⟨?_, ?_, ?_, ?_⟩
    · show ((gridVal P.eHC ((c.learners ++ [newLearner P cache]).getD d dfltLearner).tag : ℚ) : ℝ) = 1
      rw [e]
      show ((gridVal P.eHC (2 ^ P.eHC) : ℚ) : ℝ) = 1
      rw [hg1]
      norm_num
    · show ((c.learners ++ [newLearner P cache]).getD d dfltLearner).epoch = 0
      rw [e]
      rfl
    · show ((c.learners ++ [newLearner P cache]).getD d dfltLearner).jEpoch = 0
      rw [e]
      rfl
    · show ((c.learners ++ [newLearner P cache]).getD d dfltLearner).jUsed = 0
      rw [e]
      rfl

/-! ## The birth of one depth -/

/-- **The birth of depth `d`** (`birthCode`, round `t = c.t + 1`, shallowest born depth `d₀ = firstBorn H t ≤ d`):
from the moment `births d` to `births (d + 1)`. At round `1` the root input vanishes (`d₀ = 0`). -/
theorem wp_birthCode (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {c : CState} {o : OState} {g : Ghost} {d : ℕ}
    (h : JointInv P (.births d) c o g) (hd : d < P.H) (hd0 : firstBorn P.H (c.t + 1) ≤ d)
    (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t ≤ P.m)
    (hx0 : firstBorn P.H (c.t + 1) = 0 → (shadowOf P g).x0 = 0) :
    WP P F (birthCode P (c.t + 1) (firstBorn P.H (c.t + 1)) d c)
      (fun c' o' g' => JointInv P (.births (d + 1)) c' o' g' ∧ Frame (P := P) c o g c' o' g') o g := by
  have htime := st1_time_births h
  have hlenH := st1_hists_len h hd
  have hlenB : o.banks.length = d + 1 := by rw [← h.sp.rows.len_hists]; exact hlenH
  have hlenL := st1_labels_len h hd
  have hnev : g.events.length + 1 ≤ P.T := h.nev_succ ht (by simp only [remEv]; omega)
  have hc0len : c.learners.length = d := by
    have := h.tp.nLearners
    simpa [Tree.Phase.live] using this
  obtain ⟨B0, hB0⟩ : ∃ B0, o.banks[d]? = some B0 := ⟨o.banks[d]'(by omega), List.getElem?_eq_getElem _⟩
  have hsp0 := statePart_bankOp h.sp d RowOp.resetY
  unfold birthCode
  simp only [AlgM.bind_eq, AlgM.pure_eq]
  apply wp_bankOpM
  apply st1_wp_ite_bankNew
  intro o1 g1 Bo hBo1 hBo2 hob hos hov hgl hgh hgc hge
  dsimp only at hob hos hov hgl hgh hgc hge
  -- the bank-state part after the bank operations of the birth
  have hsp1 : StatePart P o1 g1 := by
    by_cases h1 : d + 2 ≤ P.H
    · obtain ⟨B, rfl, hB⟩ := hBo1 h1
      have := statePart_bankNew hsp0 B (c.t + 1, d) hB (fun rec hrec => st1_fresh_label h hd rec hrec)
      exact this.congr hob (by rw [hgl, if_pos h1]) (by rw [hgh, if_pos h1]) hgc
    · have hBo := hBo2 h1
      subst hBo
      exact hsp0.congr (by rw [hob, List.append_nil]) (by rw [hgl, if_neg h1, List.append_nil])
        (by rw [hgh, if_neg h1, List.append_nil]) hgc
  have hhists1 : g1.hists = modifyAt (fun l => l ++ [RowOp.resetY]) d g.hists ++
      (if d + 2 ≤ P.H then [[]] else []) := hgh
  have hlabels1 : g1.labels = g.labels ++ (if d + 2 ≤ P.H then [((shadowOf P g).t, d)] else []) := by
    rw [hgl, htime]
  refine wp_ite (fun h2 => ?_) (fun h2 => ?_)
  · -- no birth release: the birth cache is `0`
    apply wp_noteM
    apply wp_pure
    have hxd : (shadowOf P g).x d = 0 := by
      rcases h2 with rfl | hlt
      · rw [st1_x_zero]; exact hx0 (by omega)
      · exact h.tp.bornZero d rfl (by rw [htime]; exact hlt)
    obtain ⟨-, htp⟩ := treePart_birth hP h.tp hd hbox (cache := 0) (Or.inl ⟨rfl, hxd⟩)
    have hcp := countPart_birth hP h.cp h.tp.tree hd (by rw [htime]; exact h2) (by rw [htime]; exact hd0)
      (g' := { g1 with events := g1.events ++ [TreeEvent.birth d] })
      (c' := { c with learners := c.learners ++ [newLearner P 0] })
      hlabels1 hgc (by simp only [hge]) rfl
    exact ⟨st1_jointInv_birth hP h hd htp rfl rfl hcp (statePart_events hsp1 _)
      (by simp only [hge]) hhists1, st1_frame_birth (d := d) (by simp only [hge]) rfl hos hov⟩
  · -- the birth release of `d = d₀ ≥ 1`
    have hd1 : 1 ≤ d := by omega
    have hdd0 : firstBorn P.H (c.t + 1) = d := by omega
    have hB1 : o1.banks[d]? = some (Bank.mapRows (RowOp.apply P RowOp.resetY) B0) := by
      rw [hob, List.getElem?_append_left (by rw [length_modifyAt]; omega), getElem?_modifyAt,
        if_pos rfl, hB0]
      rfl
    obtain ⟨hR, hRd⟩ := st1_regs_birth (P := P) c d hc0len 0
    have htree' : Tree.TreeInv P (.births (d + 1))
        (regsOf P { c with learners := c.learners ++ [newLearner P 0] })
        ((shadowOf P g).step P (.birth d)) :=
      Tree.treeInv_birth h.tp.tree hd hP.one_le_n hP.one_le_U hbox hR hRd
    have hbp' : BankPart P (.births (d + 1)) ((shadowOf P g).step P (.birth d)) g1.hists
        (g.events.length + 1) := by
      rw [hhists1]; exact bankPart_birth hP h.tp.tree h.bp hd hlenH
    have hidx : d < g1.hists.length := by
      rw [hhists1, List.length_append, length_modifyAt]; omega
    have hinj := st1_label_inj h hd hd1 hlabels1 (by
      intro lab hlab
      split_ifs at hlab with hc
      · simp only [List.mem_singleton] at hlab; rw [hlab]
      · simp at hlab)
    have hlab1 : g1.labelAt d = g.labelAt d := st1_labelAt_append _ g g1 hlabels1 (by omega)
    have hcov := countPart_cov_birth hP h.cp hd hd1
    rw [← hlab1, ← hgc] at hcov
    refine wp_releaseM hB1 ((bitAlways_releaseLog_shape P _ Mode.primary).and
      (bitAlways_releaseLog_rej P _ Mode.primary)) (fun r hr hpre => ?_)
    rw [← hF] at hpre
    obtain ⟨N, hN, hN0, hcert, ⟨a, hout⟩, hsp2⟩ := rel_glue hP htree' (by simpa using hbox) hbp' hnev
      hsp1 hinj hidx hd (by simp [Tree.Phase.live]) (by intro hm; cases hm) (fun D hD => by cases hD) gF
      (hgood _).1 (hgood _).2 hB1 hcov r hr hpre
    have hcert' : NumCert (P.eta : ℝ) (P.omega : ℝ) (‖(shadowOf P g).x d‖ ^ 2) (N : ℝ) := by
      have hx := hbp'.shadowX d hidx
      rw [st1_x_step_birth] at hx
      have hsh : bankShadow P Mode.primary (g1.histAt d) = (shadowOf P g).x d := by
        rw [← hx]; rfl
      rw [hsh] at hcert
      exact hcert
    obtain ⟨hrange, htp⟩ := treePart_birth hP h.tp hd hbox (cache := roundMant P.eHP N)
      (Or.inr ⟨N, hN0, rfl, hcert'⟩)
    rw [hN]
    apply wp_noteM
    apply wp_pure
    rw [if_pos hrange]
    have hcp := countPart_birth_release hP h.cp h.tp.tree hd hd1 (by rw [htime]; exact hdd0)
      (relRec g1 d (Bank.mapRows (RowOp.apply P RowOp.resetY) B0) Mode.primary r) hlab1 rfl hout
      (roundMant P.eHP N)
      (g' := { g1 with calls := g1.calls ++ [relRec g1 d (Bank.mapRows (RowOp.apply P RowOp.resetY) B0) Mode.primary r], events := g1.events ++ [TreeEvent.birth d] })
      (c' := { c with learners := c.learners ++ [newLearner P (roundMant P.eHP N)] })
      hlabels1 (by simp only [hgc]) (by simp only [hge]) rfl
    exact ⟨st1_jointInv_birth hP h hd htp rfl rfl hcp (statePart_events hsp2 _)
      (by simp only [hge]) hhists1, st1_frame_birth (d := d) (by simp only [hge]) rfl hos hov⟩

/-! ## The births of Step 1 -/

/-- **Step 1's births** for the depths `D, …, H − 1` (`birthLoopCode`). -/
theorem wp_birthLoopCode (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) :
    ∀ (k D : ℕ) (c : CState) (o : OState) (g : Ghost), D + k = P.H → firstBorn P.H (c.t + 1) ≤ D →
      JointInv P (.births D) c o g → ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ) → (shadowOf P g).t ≤ P.m →
      (firstBorn P.H (c.t + 1) = 0 → (shadowOf P g).x0 = 0) →
      WP P F (birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1)) (List.range' D k) c)
        (fun c' o' g' => JointInv P (.births P.H) c' o' g' ∧ Frame (P := P) c o g c' o' g') o g := by
  intro k
  induction k with
  | zero =>
    intro D c o g hk _ h _ _ _
    have hD : P.H = D := by omega
    rw [List.range'_zero]
    apply wp_pure
    rw [hD]
    exact ⟨h, frame_refl c o g⟩
  | succ k ih =>
    intro D c o g hk hD h hbox ht hx0
    rw [List.range'_succ]
    show WP P F (if c.failed = true then AlgM.pure c else
      (birthCode P (c.t + 1) (firstBorn P.H (c.t + 1)) D c).bind fun c' =>
        birthLoopCode P (c.t + 1) (firstBorn P.H (c.t + 1)) (List.range' (D + 1) k) c') _ o g
    rw [h.notFailed]
    simp only [Bool.false_eq_true, if_false]
    apply wp_bind
    refine wp_mono (wp_birthCode hP gF hF hgood h (by omega) hD hbox ht hx0) ?_
    rintro c' o' g' ⟨h', hfr⟩
    have hc't : c'.t + 1 = c.t + 1 := by rw [hfr.1]
    rw [← hc't]
    refine wp_mono (ih (D + 1) c' o' g' (by omega) (by rw [hc't]; omega) h' (by rw [hfr.2.1]; exact hbox)
      (by rw [hfr.2.2.1]; exact ht) (fun h0 => by rw [hfr.2.1]; exact hx0 (by rw [← hc't]; exact h0))) ?_
    rintro c'' o'' g'' ⟨h'', hfr'⟩
    exact ⟨h'', frame_trans hfr hfr'⟩

/-! ## The start of a round -/

/-- At the moment `births D` the terminal accumulator is not part of the tree invariant. -/
theorem st1_treePart_setLeaf {D : ℕ} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P (.births D) c S nev) (v : ℤ) : TreePart P (.births D) { c with leaf := v } S nev where
  tree := h.tree
  nLearners := h.nLearners
  root := h.root
  tagW := h.tagW
  cacheW := h.cacheW
  cacheNonneg := h.cacheNonneg
  tagNonneg := h.tagNonneg
  leafExact D' hD' := by cases hD'
  leafW D' hD' := by cases hD'
  leafNonneg hl := by simp [leafPhase] at hl
  bornZero := h.bornZero

theorem st1_jointInv_setLeaf {c : CState} {o : OState} {g : Ghost} (h : JointInv P (.births P.H) c o g)
    (v : ℤ) : JointInv P (.births P.H) { c with leaf := v } o g :=
  ⟨st1_treePart_setLeaf h.tp v, h.bp, h.cp.congr rfl rfl rfl rfl, h.sp, h.notFailed, h.time⟩

/-- `firstBorn H (t + 1) = 0` happens only at round `1` (for `t < m ≤ 2^{H−1}`). -/
theorem st1_firstBorn_eq_zero {t : ℕ} (htm : t < P.m) (h0 : firstBorn P.H (t + 1) = 0) : t = 0 := by
  have hb : bornAt P.H 0 (t + 1) = true :=
    (OrcAux.bornAt_iff_firstBorn_le P.H (t + 1) 0 P.one_le_H).mpr (by omega)
  simp only [bornAt, beq_iff_eq, Nat.add_sub_cancel, Nat.sub_zero] at hb
  have hlt : t < 2 ^ (P.H - 1) := lt_of_lt_of_le htm (StreamParams.m_le_two_pow_H_sub_one P)
  rwa [Nat.mod_eq_of_lt hlt] at hb

/-- The joint invariant after `noteM newRound` and Step 1's retirement (pure). -/
theorem st1_jointInv_newRound (hP : ParamsOK P) {c c' : CState} {o o' : OState} {g g' : Ghost}
    (h : JointInv P .idle c o g) (ht : (shadowOf P g).t < P.m)
    (hc : c' = { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) })
    (hob : o'.banks = o.banks.take (firstBorn P.H (c.t + 1) + 1))
    (hl : g'.labels = g.labels.take (firstBorn P.H (c.t + 1) + 1))
    (hh : g'.hists = g.hists.take (firstBorn P.H (c.t + 1) + 1))
    (hcalls : g'.calls = g.calls) (he : g'.events = g.events ++ [TreeEvent.newRound]) :
    JointInv P (.births (firstBorn P.H (c.t + 1))) c' o' g' := by
  have htime := st1_time_idle h
  have hS : shadowOf P g' = (shadowOf P g).step P .newRound :=
    shadowOf_snoc P he toTreeEv_newRound
  have hlen : g'.events.length = g.events.length + 1 := by rw [he]; simp
  have hlenH : g.hists.length ≤ P.H := by
    have := h.hists_len
    simp only [Tree.Phase.live] at this
    rw [this]
    have := P.one_le_H
    omega
  have hd0 : firstBorn P.H (c.t + 1) < P.H := OrcAux.firstBorn_lt _ _ P.one_le_H
  subst hc
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hS, hlen]
    have := treePart_newRound hP h.tp ht
    rw [htime] at this
    exact this
  · rw [hS, hlen, hh]
    exact bankPart_newRound hP h.tp.tree h.bp hlenH hd0
  · have hcp := countPart_newRound hP h.cp h.tp.tree
      (fun d hd => h.tp.jUsed_lt (by simpa [Tree.Phase.live] using hd)) ht
      (c' := { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }) (g' := g')
      (by rw [hl, htime]) hcalls he (by rw [htime])
    rw [htime] at hcp
    exact hcp
  · exact (statePart_retain (statePart_events h.sp (g.events ++ [TreeEvent.newRound]))
      (firstBorn P.H (c.t + 1) + 1)).congr hob hl hh hcalls
  · exact h.notFailed
  · rw [hS]
    simp [phIdle, htime]

/-- **The start of a round `t + 1 ≤ m` and Step 1** (`noteM newRound`, then `step1Code`): from the end of round
`t` to the end of Step 1 of round `t + 1`. -/
theorem wp_step1 (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F) (hgood : GoodLog P gF)
    {c : CState} {o : OState} {g : Ghost} (h : JointInv P .idle c o g)
    (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ)) (ht : (shadowOf P g).t < P.m) :
    WP P F ((noteM TreeEvent.newRound).bind fun _ => step1Code P c)
      (fun c1 o' g' => JointInv P (.births P.H) c1 o' g' ∧ c1.t = c.t ∧
        (shadowOf P g').x0 = (shadowOf P g).x0 ∧ (shadowOf P g').t = (shadowOf P g).t + 1 ∧
        o'.fpSeed = o.fpSeed ∧ o'.fpVal = o.fpVal) o g := by
  have htime := st1_time_idle h
  apply wp_noteM
  unfold step1Code
  simp only [AlgM.bind_eq, AlgM.pure_eq]
  apply wp_bankRetainM
  apply wp_bind
  have hJ := st1_jointInv_newRound hP h ht
    (c' := { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) })
    (o' := { o with banks := o.banks.take (firstBorn P.H (c.t + 1) + 1) })
    (g' := { g with
      events := g.events ++ [TreeEvent.newRound]
      labels := g.labels.take (firstBorn P.H (c.t + 1) + 1)
      hists := g.hists.take (firstBorn P.H (c.t + 1) + 1) }) rfl rfl rfl rfl rfl rfl
  have hS : shadowOf P { g with
      events := g.events ++ [TreeEvent.newRound]
      labels := g.labels.take (firstBorn P.H (c.t + 1) + 1)
      hists := g.hists.take (firstBorn P.H (c.t + 1) + 1) } = (shadowOf P g).step P .newRound :=
    shadowOf_snoc P rfl toTreeEv_newRound
  have hd0H : firstBorn P.H (c.t + 1) < P.H := OrcAux.firstBorn_lt _ _ P.one_le_H
  refine wp_mono (wp_birthLoopCode hP gF hF hgood (P.H - firstBorn P.H (c.t + 1)) (firstBorn P.H (c.t + 1))
    { c with learners := c.learners.take (firstBorn P.H (c.t + 1)) }
    { o with banks := o.banks.take (firstBorn P.H (c.t + 1) + 1) }
    { g with
      events := g.events ++ [TreeEvent.newRound]
      labels := g.labels.take (firstBorn P.H (c.t + 1) + 1)
      hists := g.hists.take (firstBorn P.H (c.t + 1) + 1) }
    (by omega) le_rfl hJ (by rw [hS]; exact hbox) (by rw [hS, Tree.step_newRound_t]; omega) ?_) ?_
  · intro h0
    rw [hS]
    have ht0 : c.t = 0 := st1_firstBorn_eq_zero (by rw [← htime]; exact ht) h0
    have hnev := h.cp.nev
    rw [htime, ht0] at hnev
    simp only [remEv, Nat.mul_zero, Nat.add_zero, Nat.le_zero, List.length_eq_zero_iff] at hnev
    have hg0 : shadowOf P g = Tree.TreeState.init P.Dstar := by
      unfold shadowOf
      rw [hnev]
      rfl
    rw [hg0]
    rfl
  · rintro c2 o3 g3 ⟨h3, hfr⟩
    apply wp_pure
    refine ⟨st1_jointInv_setLeaf h3 0, hfr.1, ?_, ?_, ?_, ?_⟩
    · rw [hfr.2.1, hS]; rfl
    · rw [hfr.2.2.1, hS]; rfl
    · exact hfr.2.2.2.1
    · exact hfr.2.2.2.2

/-- The bank-state part of the initialization data (the root bank `(0,0)`, fresh). -/
theorem st1_statePart_init {o : OState} {g : Ghost} (B : Bank) (hB : St1BankFresh P B)
    (hob : o.banks = [B]) (hl : g.labels = [(0, 0)]) (hh : g.hists = [[]]) (hcalls : g.calls = []) :
    StatePart P o g := by
  have h0 : StatePart P { o with banks := [] } { g with labels := [], hists := [], calls := [] } :=
    ⟨⟨rfl, rfl, fun idx B hB => by simp at hB⟩, fun B hB => by simp at hB, fun idx B hB => by simp at hB,
      fun idx B hB => by simp at hB⟩
  have h1 := statePart_bankNew h0 B (0, 0) hB (fun rec hrec => by simp at hrec)
  exact h1.congr (by rw [hob]; rfl) (by rw [hl]; rfl) (by rw [hh]; rfl) (by rw [hcalls])

/-- `firstBorn H 1 = 0`: every depth is born at round `1`. -/
theorem st1_firstBorn_one : firstBorn P.H 1 = 0 := by
  have hb : bornAt P.H 0 1 = true := by simp [bornAt]
  have := (OrcAux.bornAt_iff_firstBorn_le P.H 1 0 P.one_le_H).mp hb
  omega

/-- The joint invariant at the start of round `1` (after `initCode`, `noteM newRound` and `bankRetainM 1`; pure). -/
theorem st1_jointInv_init (hP : ParamsOK P) {c : CState} {o : OState} {g : Ghost} (B : Bank)
    (hB : St1BankFresh P B) (hc : c.learners = []) (hct : c.t = 0) (hcf : c.failed = false)
    (hob : o.banks = [B]) (hl : g.labels = [(0, 0)]) (hh : g.hists = [[]]) (hcalls : g.calls = [])
    (he : g.events = [TreeEvent.newRound]) :
    JointInv P (.births 0) c o g := by
  have hS : shadowOf P g = (Tree.TreeState.init P.Dstar).step P .newRound := by
    unfold shadowOf
    rw [he]
    rfl
  have hlen : g.events.length = 1 := by rw [he]; rfl
  refine ⟨?_, ?_, countPart_init hP c hc g hl hcalls he, st1_statePart_init B hB hob hl hh hcalls, hcf, ?_⟩
  · rw [hS, hlen]
    exact treePart_init hP c hc
  · rw [hS, hlen, hh]
    exact bankPart_init hP
  · rw [hS, hct]
    rfl

/-- **Round `1`'s start and Step 1** from the initialization data. -/
theorem wp_step1_init (hP : ParamsOK P) {F : List CallRec} (gF : Ghost) (hF : gF.calls = F)
    (hgood : GoodLog P gF) {c : CState} {o : OState} {g : Ghost} (h : InitState P c o g) :
    WP P F ((noteM TreeEvent.newRound).bind fun _ => step1Code P c)
      (fun c1 o' g' => JointInv P (.births P.H) c1 o' g' ∧ c1.t = 0 ∧ (shadowOf P g').x0 = 0 ∧
        (shadowOf P g').t = 1 ∧ o'.fpSeed = o.fpSeed ∧ o'.fpVal = o.fpVal) o g := by
  obtain ⟨hc, ⟨B, hob, hB⟩, hl, hh, hcalls, he⟩ := h
  subst hc
  have hfb : firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) = 0 := st1_firstBorn_one
  have hg0 : shadowOf P g = Tree.TreeState.init P.Dstar := by
    unfold shadowOf
    rw [he]
    rfl
  apply wp_noteM
  unfold step1Code
  simp only [AlgM.bind_eq, AlgM.pure_eq]
  apply wp_bankRetainM
  apply wp_bind
  have hJ : JointInv P (.births (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1)))
      { (⟨0, false, [], 0⟩ : CState) with
        learners := ([] : List Learner).take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1)) }
      { o with banks := o.banks.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1) }
      { g with
        events := g.events ++ [TreeEvent.newRound]
        labels := g.labels.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1)
        hists := g.hists.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1) } := by
    rw [hfb]
    exact st1_jointInv_init hP B hB rfl rfl rfl (by rw [hob]; rfl) (by rw [hl]; rfl) (by rw [hh]; rfl)
      hcalls (by rw [he]; rfl)
  have hS1 : shadowOf P { g with
        events := g.events ++ [TreeEvent.newRound]
        labels := g.labels.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1)
        hists := g.hists.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1) } =
      (Tree.TreeState.init P.Dstar).step P .newRound := by
    rw [shadowOf_snoc P (g := g) rfl toTreeEv_newRound, hg0]
  refine wp_mono (wp_birthLoopCode hP gF hF hgood (P.H - firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1))
    (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1))
    { (⟨0, false, [], 0⟩ : CState) with
      learners := ([] : List Learner).take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1)) }
    { o with banks := o.banks.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1) }
    { g with
      events := g.events ++ [TreeEvent.newRound]
      labels := g.labels.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1)
      hists := g.hists.take (firstBorn P.H ((⟨0, false, [], 0⟩ : CState).t + 1) + 1) }
    (by omega) le_rfl hJ ?_ ?_ ?_) ?_
  · rw [hS1]
    show ‖(0 : Tree.Vec P)‖ ≤ (P.W : ℝ)
    rw [norm_zero]
    exact Nat.cast_nonneg _
  · rw [hS1]
    exact hP.one_le_m
  · intro _
    rw [hS1]
    rfl
  · rintro c2 o3 g3 ⟨h3, hfr⟩
    apply wp_pure
    refine ⟨st1_jointInv_setLeaf h3 0, hfr.1, ?_, ?_, hfr.2.2.2.1, hfr.2.2.2.2⟩
    · rw [hfr.2.1, hS1]
      rfl
    · rw [hfr.2.2.1, hS1]
      rfl

end F2e2e.C.Closure
