import F2e2e.Spec

/-!
# Helper lemmas for the Theorem (C) parameters

General facts used by `F2e2e.C.ParamsFacts` and `F2e2e.C.ParamsGrids`:

* `Nat.clog 2` (the exact `⌈log₂ ·⌉` of natural numbers): `clog_two_eq_size_pred` (`⌈log₂ x⌉` is the bit
  length of `x - 1`, as computed by a DSL program via `bitLen`), `clog_two_pow_mul`
  (`⌈log₂(2^k N)⌉ = k + ⌈log₂ N⌉`), the two-sided bounds `le_pow_clog_two`, `pow_clog_two_pred_lt`;
* the real `⌈log₂ ·⌉` of the paper: `ceil_logb_two_eq` (characterization by `2^{k-1} < x ≤ 2^k`),
  `ceil_logb_two_pow_mul_natCast`;
* the Spec's `dyadicExp`/`dyadicDown` (`⌈log₂ x⁻¹⌉` and `2^{-⌈log₂ x⁻¹⌉} ∈ (x/2, x]`).
-/

namespace F2e2e

namespace ParamsAux

/-! ## `Nat.clog 2` -/

/-- `N ≤ 2^{⌈log₂ N⌉}`. -/
theorem le_pow_clog_two (N : ℕ) : N ≤ 2 ^ Nat.clog 2 N :=
  Nat.le_pow_clog (by norm_num) N

/-- `⌈log₂ N⌉ ≥ 1` for `N ≥ 2`. -/
theorem one_le_clog_two {N : ℕ} (hN : 2 ≤ N) : 1 ≤ Nat.clog 2 N :=
  Nat.clog_pos (by norm_num) hN

/-- `2^{⌈log₂ N⌉ - 1} < N` for `N ≥ 2`. -/
theorem pow_clog_two_pred_lt {N : ℕ} (hN : 2 ≤ N) : 2 ^ (Nat.clog 2 N - 1) < N := by
  have := Nat.pow_pred_clog_lt_self (b := 2) (by norm_num) (x := N) (by omega)
  simpa [Nat.pred_eq_sub_one] using this

/-- `⌈log₂ x⌉ = bitlength(x - 1)` (`Nat.size`) for every natural number `x`; this is how a program computes
`Nat.clog 2` with bit lengths. -/
theorem clog_two_eq_size_pred (x : ℕ) : Nat.clog 2 x = Nat.size (x - 1) := by
  apply le_antisymm
  · rw [Nat.clog_le_iff_le_pow (by norm_num)]
    have := Nat.lt_size_self (x - 1)
    omega
  · rw [Nat.size_le]
    have h1 := le_pow_clog_two x
    have h2 : 0 < 2 ^ Nat.clog 2 x := by positivity
    omega

/-- `⌈log₂(2^k N)⌉ = k + ⌈log₂ N⌉` for `N ≥ 1`. -/
theorem clog_two_pow_mul (k : ℕ) {N : ℕ} (hN : 1 ≤ N) :
    Nat.clog 2 (2 ^ k * N) = k + Nat.clog 2 N := by
  apply le_antisymm
  · rw [Nat.clog_le_iff_le_pow (by norm_num), pow_add]
    exact Nat.mul_le_mul_left _ (le_pow_clog_two N)
  · rcases Nat.lt_or_ge N 2 with hN2 | hN2
    · have h0 : Nat.clog 2 N = 0 := Nat.clog_of_right_le_one (by omega) 2
      rw [h0, add_zero]
      calc k = Nat.clog 2 (2 ^ k) := (Nat.clog_pow 2 k (by norm_num)).symm
        _ ≤ Nat.clog 2 (2 ^ k * N) := Nat.clog_mono_right 2 (Nat.le_mul_of_pos_right _ hN)
    · have hc := one_le_clog_two hN2
      have h1 := pow_clog_two_pred_lt hN2
      have : k + Nat.clog 2 N - 1 < Nat.clog 2 (2 ^ k * N) := by
        rw [Nat.lt_clog_iff_pow_lt (by norm_num)]
        calc 2 ^ (k + Nat.clog 2 N - 1) = 2 ^ k * 2 ^ (Nat.clog 2 N - 1) := by
              rw [← pow_add]; congr 1; omega
          _ < 2 ^ k * N := (Nat.mul_lt_mul_left (by positivity)).2 h1
      omega

/-- `⌈log₂ x⌉ ≤ y ↔ x ≤ 2^y` (`Nat.clog_le_iff_le_pow` for base 2). -/
theorem clog_two_le_iff {x y : ℕ} : Nat.clog 2 x ≤ y ↔ x ≤ 2 ^ y :=
  Nat.clog_le_iff_le_pow (by norm_num)

/-! ## The real `⌈log₂ ·⌉` -/

/-- Characterization of the paper's `⌈log₂ x⌉`: if `2^{k-1} < x ≤ 2^k` then `⌈log₂ x⌉ = k`. -/
theorem ceil_logb_two_eq {x : ℝ} {k : ℤ} (h1 : (2 : ℝ) ^ (k - 1) < x) (h2 : x ≤ (2 : ℝ) ^ k) :
    ⌈Real.logb 2 x⌉ = k := by
  have hx : 0 < x := lt_of_le_of_lt (by positivity) h1
  rw [Int.ceil_eq_iff]
  constructor
  · rw [Real.lt_logb_iff_rpow_lt (by norm_num) hx]
    have e : ((k - 1 : ℤ) : ℝ) = (k : ℝ) - 1 := by push_cast; ring
    rw [← e, Real.rpow_intCast]
    exact h1
  · rw [Real.logb_le_iff_le_rpow (by norm_num) hx, Real.rpow_intCast]
    exact h2

/-- `⌈log₂(2^k N)⌉ = k + ⌈log₂ N⌉` for a natural number `N ≥ 1` (real logarithm). -/
theorem ceil_logb_two_pow_mul_natCast (k : ℕ) {N : ℕ} (hN : 1 ≤ N) :
    ⌈Real.logb 2 ((2 : ℝ) ^ k * N)⌉ = ((k + Nat.clog 2 N : ℕ) : ℤ) := by
  apply ceil_logb_two_eq
  · rcases Nat.lt_or_ge N 2 with hN2 | hN2
    · have hN1 : N = 1 := by omega
      subst hN1
      rw [Nat.clog_one_right, add_zero, Nat.cast_one, mul_one,
        show ((k : ℕ) : ℤ) - 1 = (k : ℤ) + (-1) by ring, zpow_add₀ (by norm_num), zpow_natCast]
      have : (0 : ℝ) < 2 ^ k := by positivity
      have h2 : (2 : ℝ) ^ (-1 : ℤ) = 1 / 2 := by norm_num
      rw [h2]
      linarith
    · have hc := one_le_clog_two hN2
      have h1 := pow_clog_two_pred_lt hN2
      have e : (((k + Nat.clog 2 N : ℕ) : ℤ) - 1) = ((k + (Nat.clog 2 N - 1) : ℕ) : ℤ) := by
        push_cast; omega
      rw [e, zpow_natCast, pow_add]
      have h1' : ((2 : ℝ) ^ (Nat.clog 2 N - 1)) < (N : ℝ) := by exact_mod_cast h1
      exact mul_lt_mul_of_pos_left h1' (by positivity)
  · rw [zpow_natCast, pow_add]
    have h2 : (N : ℝ) ≤ (2 : ℝ) ^ Nat.clog 2 N := by exact_mod_cast le_pow_clog_two N
    exact mul_le_mul_of_nonneg_left h2 (by positivity)

/-- `⌈log₂ N⌉ = Nat.clog 2 N` for a natural number `N ≥ 1` (real logarithm). -/
theorem ceil_logb_two_natCast {N : ℕ} (hN : 1 ≤ N) :
    ⌈Real.logb 2 (N : ℝ)⌉ = (Nat.clog 2 N : ℤ) := by
  have := ceil_logb_two_pow_mul_natCast 0 hN
  simpa using this

/-! ## The Spec's `dyadicExp` and `dyadicDown` -/

/-- `x⁻¹ ≤ 2^{dyadicExp x}`. -/
theorem inv_le_two_pow_dyadicExp (x : ℝ) : x⁻¹ ≤ (2 : ℝ) ^ dyadicExp x := by
  unfold dyadicExp
  calc x⁻¹ ≤ (⌈x⁻¹⌉₊ : ℝ) := Nat.le_ceil _
    _ ≤ ((2 ^ Nat.clog 2 ⌈x⁻¹⌉₊ : ℕ) : ℝ) := by exact_mod_cast le_pow_clog_two _
    _ = (2 : ℝ) ^ Nat.clog 2 ⌈x⁻¹⌉₊ := by push_cast; rfl

/-- `dyadicExp x ≥ 1` for `0 < x < 1`. -/
theorem one_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) : 1 ≤ dyadicExp x := by
  unfold dyadicExp
  apply one_le_clog_two
  have : (1 : ℝ) < x⁻¹ := by rw [lt_inv_comm₀ one_pos hx0]; simpa using hx1
  have h := Nat.lt_ceil.2 (show ((1 : ℕ) : ℝ) < x⁻¹ by exact_mod_cast this)
  omega

/-- `2^{dyadicExp x - 1} < x⁻¹` for `0 < x < 1`. -/
theorem two_pow_dyadicExp_pred_lt {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    (2 : ℝ) ^ (dyadicExp x - 1) < x⁻¹ := by
  have hpos := one_le_dyadicExp hx0 hx1
  unfold dyadicExp at hpos ⊢
  have h2 : 2 ≤ ⌈x⁻¹⌉₊ := by
    by_contra hc
    have : ⌈x⁻¹⌉₊ ≤ 1 := by omega
    have : Nat.clog 2 ⌈x⁻¹⌉₊ = 0 := Nat.clog_of_right_le_one this 2
    omega
  have h := pow_clog_two_pred_lt h2
  have : ((2 ^ (Nat.clog 2 ⌈x⁻¹⌉₊ - 1) : ℕ) : ℝ) < x⁻¹ := Nat.lt_ceil.1 h
  exact_mod_cast this

/-- `dyadicDown x = 2^{-dyadicExp x} ≤ x` for `x > 0`. -/
theorem dyadicDown_le {x : ℝ} (hx0 : 0 < x) : dyadicDown x ≤ x := by
  unfold dyadicDown
  rw [one_div, inv_pow, inv_le_comm₀ (by positivity) hx0]
  exact inv_le_two_pow_dyadicExp x

/-- `x/2 < dyadicDown x` for `0 < x < 1`. -/
theorem half_lt_dyadicDown {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) : x / 2 < dyadicDown x := by
  have h1 := one_le_dyadicExp hx0 hx1
  have h2 := two_pow_dyadicExp_pred_lt hx0 hx1
  unfold dyadicDown
  have e : (2 : ℝ) ^ dyadicExp x = 2 * 2 ^ (dyadicExp x - 1) := by
    rw [← pow_succ']; congr 1; omega
  rw [one_div, inv_pow, e]
  have h3 : x < (2 ^ (dyadicExp x - 1) : ℝ)⁻¹ := by
    rw [lt_inv_comm₀ hx0 (by positivity)]; exact h2
  rw [mul_inv]
  linarith

/-- The Spec's `dyadicExp` is the paper's `⌈log₂(1/x)⌉` for `0 < x ≤ 1`. -/
theorem dyadicExp_eq_ceil_logb {x : ℝ} (hx0 : 0 < x) (hx1 : x ≤ 1) :
    (dyadicExp x : ℤ) = ⌈Real.logb 2 x⁻¹⌉ := by
  symm
  apply ceil_logb_two_eq
  · rcases hx1.lt_or_eq with hlt | heq
    · have h1 := one_le_dyadicExp hx0 hlt
      have h2 := two_pow_dyadicExp_pred_lt hx0 hlt
      have e : ((dyadicExp x : ℤ) - 1) = ((dyadicExp x - 1 : ℕ) : ℤ) := by omega
      rw [e, zpow_natCast]; exact h2
    · subst heq
      have : dyadicExp 1 = 0 := by simp [dyadicExp]
      rw [this]; norm_num
  · rw [zpow_natCast]; exact inv_le_two_pow_dyadicExp x

/-- `dyadicExp x ≥ 4` for `0 < x < 1/10` (so `dyadicDown x ≤ 1/16`). -/
theorem four_le_dyadicExp {x : ℝ} (hx0 : 0 < x) (hx : x < 1 / 10) : 4 ≤ dyadicExp x := by
  unfold dyadicExp
  have h10 : (10 : ℝ) < x⁻¹ := by
    rw [lt_inv_comm₀ (by norm_num) hx0]; simpa using hx
  have h8 : ((8 : ℕ) : ℝ) < x⁻¹ := by push_cast; linarith
  have h := Nat.lt_ceil.2 h8
  have : 3 < Nat.clog 2 ⌈x⁻¹⌉₊ := by
    rw [Nat.lt_clog_iff_pow_lt (by norm_num)]; simpa using h
  omega

/-! ## Powers of `1/2` in an ordered field -/

section HalfPow

variable {K : Type*} [Field K]

theorem half_pow_eq_inv (e : ℕ) : (1 / 2 : K) ^ e = ((2 : K) ^ e)⁻¹ := by
  rw [one_div, inv_pow]

theorem half_pow_eq_one_div (e : ℕ) : (1 / 2 : K) ^ e = 1 / (2 : K) ^ e := by
  rw [div_pow, one_pow]

theorem half_pow_add (a b : ℕ) : (1 / 2 : K) ^ (a + b) = (1 / 2 : K) ^ a * (1 / 2 : K) ^ b :=
  pow_add _ _ _

variable [LinearOrder K] [IsStrictOrderedRing K]

theorem half_pow_pos (e : ℕ) : (0 : K) < (1 / 2 : K) ^ e := by positivity

theorem half_pow_le_one (e : ℕ) : (1 / 2 : K) ^ e ≤ 1 :=
  pow_le_one₀ (by norm_num) (by norm_num)

theorem half_pow_mul_two_pow (e : ℕ) : (1 / 2 : K) ^ e * 2 ^ e = 1 := by
  rw [← mul_pow]; norm_num

/-- `(1/2)^e ≤ x ↔ 1 ≤ x 2^e`. -/
theorem half_pow_le_iff (e : ℕ) (x : K) : (1 / 2 : K) ^ e ≤ x ↔ 1 ≤ x * 2 ^ e := by
  rw [half_pow_eq_one_div, div_le_iff₀ (by positivity)]

/-- `x ≤ (1/2)^e ↔ x 2^e ≤ 1`. -/
theorem le_half_pow_iff (e : ℕ) (x : K) : x ≤ (1 / 2 : K) ^ e ↔ x * 2 ^ e ≤ 1 := by
  rw [half_pow_eq_one_div, le_div_iff₀ (by positivity)]

/-- `x < (1/2)^e ↔ x 2^e < 1`. -/
theorem lt_half_pow_iff (e : ℕ) (x : K) : x < (1 / 2 : K) ^ e ↔ x * 2 ^ e < 1 := by
  rw [half_pow_eq_one_div, lt_div_iff₀ (by positivity)]

/-- `(1/2)^e < x ↔ 1 < x 2^e`. -/
theorem half_pow_lt_iff (e : ℕ) (x : K) : (1 / 2 : K) ^ e < x ↔ 1 < x * 2 ^ e := by
  rw [half_pow_eq_one_div, div_lt_iff₀ (by positivity)]

theorem half_pow_antitone {a b : ℕ} (h : a ≤ b) : (1 / 2 : K) ^ b ≤ (1 / 2 : K) ^ a :=
  pow_le_pow_of_le_one (by norm_num) (by norm_num) h

/-- `(1/2)^e x ≤ 1 ↔ x ≤ 2^e`. -/
theorem half_pow_mul_le_one_iff (e : ℕ) (x : K) : (1 / 2 : K) ^ e * x ≤ 1 ↔ x ≤ 2 ^ e := by
  rw [half_pow_eq_one_div, one_div_mul_eq_div, div_le_one₀ (by positivity)]

/-- `1 < (1/2)^e x ↔ 2^e < x`. -/
theorem one_lt_half_pow_mul_iff (e : ℕ) (x : K) : 1 < (1 / 2 : K) ^ e * x ↔ 2 ^ e < x := by
  rw [half_pow_eq_one_div, one_div_mul_eq_div, one_lt_div₀ (by positivity)]

/-- `2^{⌈log₂ N⌉} < 2N` for `N ≥ 1`. -/
theorem two_pow_clog_two_lt {N : ℕ} (hN : 1 ≤ N) : 2 ^ Nat.clog 2 N < 2 * N := by
  rcases Nat.lt_or_ge N 2 with h | h
  · have : N = 1 := by omega
    subst this; simp
  · have h1 := one_le_clog_two h
    have h2 := pow_clog_two_pred_lt h
    calc 2 ^ Nat.clog 2 N = 2 * 2 ^ (Nat.clog 2 N - 1) := by
          rw [← pow_succ']; congr 1; omega
      _ < 2 * N := by omega

/-- The largest power of two `≤ (1/2)^a / N` is `(1/2)^{a + ⌈log₂ N⌉}`: upper bound. -/
theorem half_pow_add_clog_le (a : ℕ) {N : ℕ} (hN : 1 ≤ N) :
    (1 / 2 : K) ^ (a + Nat.clog 2 N) ≤ (1 / 2 : K) ^ a / N := by
  have hN' : (0 : K) < N := by exact_mod_cast hN
  rw [le_div_iff₀ hN', pow_add, mul_assoc]
  calc (1 / 2 : K) ^ a * ((1 / 2) ^ Nat.clog 2 N * N) ≤ (1 / 2) ^ a * 1 := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        rw [half_pow_mul_le_one_iff]
        exact_mod_cast le_pow_clog_two N
    _ = (1 / 2) ^ a := mul_one _

/-- The largest power of two `≤ (1/2)^a / N` is `(1/2)^{a + ⌈log₂ N⌉}`: it exceeds half of `(1/2)^a / N`. -/
theorem half_pow_div_two_mul_lt (a : ℕ) {N : ℕ} (hN : 1 ≤ N) :
    (1 / 2 : K) ^ a / (2 * N) < (1 / 2 : K) ^ (a + Nat.clog 2 N) := by
  have hN' : (0 : K) < 2 * N := by positivity
  rw [div_lt_iff₀ hN', pow_add, mul_assoc]
  have key : (2 : K) ^ Nat.clog 2 N < 2 * N := by exact_mod_cast two_pow_clog_two_lt hN
  calc (1 / 2 : K) ^ a = (1 / 2) ^ a * 1 := (mul_one _).symm
    _ < (1 / 2) ^ a * ((1 / 2) ^ Nat.clog 2 N * (2 * N)) := by
        apply mul_lt_mul_of_pos_left _ (by positivity)
        rw [one_lt_half_pow_mul_iff]; exact key

/-- `(1/2)^a / N < 2 (1/2)^{a + ⌈log₂ N⌉}`. -/
theorem half_pow_div_lt_two_mul (a : ℕ) {N : ℕ} (hN : 1 ≤ N) :
    (1 / 2 : K) ^ a / N < 2 * (1 / 2 : K) ^ (a + Nat.clog 2 N) := by
  have h := half_pow_div_two_mul_lt (K := K) a hN
  have hN' : (0 : K) < N := by exact_mod_cast hN
  have hN0 : (N : K) ≠ 0 := hN'.ne'
  have e : (1 / 2 : K) ^ a / N = 2 * ((1 / 2 : K) ^ a / (2 * N)) := by
    field_simp
  rw [e]
  linarith

end HalfPow

end ParamsAux

end F2e2e
