import Mathlib
import F2e2e.C.ClosureInv

/-!
# Helpers for the oracle counting of Theorem 6.4 (`F2e2e/C/ClosureOrcStep.lean`)

* the call counts `nInt`, `nRej`, `nNum` (`F2e2e/C/ClosureBank.lean`) of an appended call log;
* the round counter and the birth rounds of the tree shadow `shadowOf P g` (`F2e2e/C/ClosureInv.lean`) after one
  analysis event, and `tb d ≤ t`;
* the dyadic schedule (Definition `R:def:binary-tree-architecture` (1), partIII.tex L431: depth `d` lives on the
  fixed dyadic intervals of length `2^{H−1−d}`; `F2e2e.C.Alg.bornAt`): depth `0` is born only at round `1`
  (`firstBorn_pos`, since `m ≤ 2^{H−1}`), and a lifetime of depth `k` contains at most two births of depth `k + 1`
  (`exists_parent_birth`; partIII.tex L949: "a Regularized Norm Bank `𝓑_d` serving at most two sequential
  depth-`(d+1)` child lifetimes").
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

namespace OrcAux

/-! ## Counts of appended call logs -/

/-- Whether a call record is a rejection returned by the ADA module. -/
def recRej (rec : CallRec) : Bool :=
  match rec.out with
  | some o => coreIsReject o
  | none => false

/-- Whether a call record is an interval request that reached the ADA module. -/
def recInt (rec : CallRec) : Bool :=
  rec.out.isSome && (match rec.kind with
    | CallKind.validate _ _ => true
    | CallKind.release _ => false)

/-- Whether a call record is a numerical request that reached the ADA module. -/
def recNum (rec : CallRec) : Bool :=
  rec.out.isSome && (match rec.kind with
    | CallKind.validate _ _ => false
    | CallKind.release _ => true)

theorem len_filter_snoc {α : Type} (p : α → Bool) (l : List α) (a : α) :
    ((l ++ [a]).filter p).length = (l.filter p).length + (if p a = true then 1 else 0) := by
  rw [List.filter_append, List.length_append]
  congr 1
  by_cases h : p a = true <;> simp [h]

theorem nRej_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nRej lab (calls ++ [rec]) = nRej lab calls + (if rec.lab = lab ∧ recRej rec = true then 1 else 0) := by
  unfold nRej
  rw [len_filter_snoc]
  congr 1
  unfold recRej
  by_cases h : rec.lab = lab <;> cases ho : rec.out <;> simp [h]

theorem nInt_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nInt lab (calls ++ [rec]) = nInt lab calls + (if rec.lab = lab ∧ recInt rec = true then 1 else 0) := by
  unfold nInt
  rw [len_filter_snoc]
  congr 1
  unfold recInt
  by_cases h : rec.lab = lab <;> cases hk : rec.kind <;> simp [h]

theorem nNum_append (lab : BankLabel) (calls : List CallRec) (rec : CallRec) :
    nNum lab (calls ++ [rec]) = nNum lab calls + (if rec.lab = lab ∧ recNum rec = true then 1 else 0) := by
  unfold nNum
  rw [len_filter_snoc]
  congr 1
  unfold recNum
  by_cases h : rec.lab = lab <;> cases hk : rec.kind <;> simp [h]

/-- A label that no call carries has no call counts. -/
theorem counts_zero {lab : BankLabel} {calls : List CallRec} (h : ∀ rec ∈ calls, rec.lab ≠ lab) :
    nInt lab calls = 0 ∧ nRej lab calls = 0 ∧ nNum lab calls = 0 := by
  refine ⟨?_, ?_, ?_⟩
  · unfold nInt
    rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
    intro rec hr
    simp [h rec hr]
  · unfold nRej
    rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
    intro rec hr
    simp [h rec hr]
  · unfold nNum
    rw [List.length_eq_zero_iff, List.filter_eq_nil_iff]
    intro rec hr
    simp [h rec hr]

/-- Appending a call of another label changes no count. -/
theorem counts_append_ne {lab : BankLabel} (calls : List CallRec) {rec : CallRec} (h : rec.lab ≠ lab) :
    nInt lab (calls ++ [rec]) = nInt lab calls ∧ nRej lab (calls ++ [rec]) = nRej lab calls ∧
      nNum lab (calls ++ [rec]) = nNum lab calls := by
  rw [nInt_append, nRej_append, nNum_append]
  simp [h]

/-- Appending a call: the counts of its own label. -/
theorem counts_append_self (calls : List CallRec) (rec : CallRec) :
    nInt rec.lab (calls ++ [rec]) = nInt rec.lab calls + (if recInt rec = true then 1 else 0) ∧
      nRej rec.lab (calls ++ [rec]) = nRej rec.lab calls + (if recRej rec = true then 1 else 0) ∧
      nNum rec.lab (calls ++ [rec]) = nNum rec.lab calls + (if recNum rec = true then 1 else 0) := by
  rw [nInt_append, nRej_append, nNum_append]
  simp

/-- The kinds of the records of `ValidateInterval` (with a certificate) and `ReleaseNumerical` (that reached the
ADA module). -/
theorem rec_validate {rec : CallRec} {S θ : ℚ} (hk : rec.kind = CallKind.validate S θ) {cert : AdaCert}
    (ho : rec.out = some (Sum.inl cert)) :
    recInt rec = true ∧ recNum rec = false ∧ recRej rec = coreIsReject (Sum.inl cert) := by
  unfold recInt recNum recRej
  rw [hk, ho]
  simp

theorem rec_release {rec : CallRec} {mode : Mode} (hk : rec.kind = CallKind.release mode) {a : AdaNum}
    (ho : rec.out = some (Sum.inr a)) :
    recInt rec = false ∧ recNum rec = true ∧ recRej rec = false := by
  unfold recInt recNum recRej
  rw [hk, ho]
  simp [coreIsReject]

/-! ## The tree shadow after one analysis event -/

variable {P : StreamParams}

theorem shadow_snoc_none {g g' : Ghost} {ev : TreeEvent} (hg : g'.events = g.events ++ [ev])
    (hev : toTreeEv P ev = none) : shadowOf P g' = shadowOf P g := by
  unfold shadowOf Tree.TreeState.run
  rw [hg, List.filterMap_append, List.foldl_append]
  simp [hev]

theorem shadow_newRound {g g' : Ghost} (hg : g'.events = g.events ++ [TreeEvent.newRound]) :
    (shadowOf P g').t = (shadowOf P g).t + 1 ∧ (shadowOf P g').tb = (shadowOf P g).tb := by
  rw [shadowOf_snoc P hg rfl]
  exact ⟨rfl, rfl⟩

theorem shadow_birth {g g' : Ghost} {d : ℕ} (hg : g'.events = g.events ++ [TreeEvent.birth d]) :
    (shadowOf P g').t = (shadowOf P g).t ∧
      (shadowOf P g').tb = Function.update (shadowOf P g).tb d (shadowOf P g).t := by
  rw [shadowOf_snoc P hg rfl]
  exact ⟨rfl, rfl⟩

/-- Analysis events other than `newRound` and `birth` keep the round counter and the birth rounds. -/
theorem shadow_other {g g' : Ghost} {ev : TreeEvent} (hg : g'.events = g.events ++ [ev])
    (h1 : ev ≠ TreeEvent.newRound) (h2 : ∀ d, ev ≠ TreeEvent.birth d) :
    (shadowOf P g').t = (shadowOf P g).t ∧ (shadowOf P g').tb = (shadowOf P g).tb := by
  cases ev with
  | newRound => exact absurd rfl h1
  | birth d => exact absurd rfl (h2 d)
  | phys i Δ =>
    by_cases hi : i - 1 < P.n
    · have hev : toTreeEv P (TreeEvent.phys i Δ) = some (Tree.TreeEvent.phys ⟨i - 1, hi⟩ Δ) := by
        simp only [toTreeEv]
        rw [dif_pos hi]
      rw [shadowOf_snoc P hg hev]
      exact ⟨rfl, rfl⟩
    · have hev : toTreeEv P (TreeEvent.phys i Δ) = none := by
        simp only [toTreeEv]
        rw [dif_neg hi]
      rw [shadow_snoc_none hg hev]
      exact ⟨rfl, rfl⟩
  | guard d gc δ =>
    by_cases hgc : gc - 1 < P.Dstar
    · have hev : toTreeEv P (TreeEvent.guard d gc δ) =
          some (Tree.TreeEvent.guard d ⟨gc - 1, hgc⟩ ((gridVal P.eHg δ : ℚ) : ℝ)) := by
        simp only [toTreeEv]
        rw [dif_pos hgc]
      rw [shadowOf_snoc P hg hev]
      exact ⟨rfl, rfl⟩
    · have hev : toTreeEv P (TreeEvent.guard d gc δ) = none := by
        simp only [toTreeEv]
        rw [dif_neg hgc]
      rw [shadow_snoc_none hg hev]
      exact ⟨rfl, rfl⟩
  | accept d =>
    rw [shadowOf_snoc P hg (e := Tree.TreeEvent.accept d) rfl]
    exact ⟨rfl, rfl⟩
  | correct d c =>
    rw [shadowOf_snoc P hg (e := Tree.TreeEvent.correct d ((gridVal P.eHstep c : ℚ) : ℝ)) rfl]
    exact ⟨rfl, rfl⟩

theorem step_tb_le (S : Tree.TreeSt P) (hS : ∀ d, S.tb d ≤ S.t) (e : Tree.TreeEv P) :
    ∀ d, (S.step P e).tb d ≤ (S.step P e).t := by
  intro d
  cases e with
  | newRound => exact Nat.le_succ_of_le (hS d)
  | birth d' =>
    show Function.update S.tb d' S.t d ≤ S.t
    rcases eq_or_ne d d' with rfl | hne
    · simp
    · rw [Function.update_of_ne hne]
      exact hS d
  | phys i Δ => exact hS d
  | guard d' gc δ => exact hS d
  | accept d' => exact hS d
  | correct d' c => exact hS d

theorem foldl_tb_le : ∀ (evs : List (Tree.TreeEv P)) (S : Tree.TreeSt P), (∀ d, S.tb d ≤ S.t) →
    ∀ d, (evs.foldl (Tree.TreeState.step P) S).tb d ≤ (evs.foldl (Tree.TreeState.step P) S).t
  | [], _, hS => hS
  | e :: evs, S, hS => foldl_tb_le evs (S.step P e) (step_tb_le S hS e)

/-- Birth rounds are at most the current round. -/
theorem shadow_tb_le (g : Ghost) (d : ℕ) : (shadowOf P g).tb d ≤ (shadowOf P g).t :=
  foldl_tb_le _ _ (fun _ => le_refl 0) d

/-! ## The dyadic schedule

(Local copies of C-ALG's `bornAt_last`, `firstBorn_lt`, `bornAt_mono`, `bornAt_iff_firstBorn_le` from
`F2e2e/C/Alg/FactsAux.lean` / `Facts.lean`, so that this file does not import `F2e2e.C.Alg.Facts`: its names, e.g.
`H_pos`, would become ambiguous downstream.) -/

theorem bornAt_last (H tr : ℕ) : bornAt H (H - 1) tr = true := by
  simp [bornAt, Nat.mod_one]

theorem firstBorn_lt (H tr : ℕ) (hH : 1 ≤ H) : firstBorn H tr < H := by
  unfold firstBorn
  have h : (List.range H).findIdx (fun d => bornAt H d tr) < (List.range H).length := by
    apply List.findIdx_lt_length_of_exists
    exact ⟨H - 1, List.mem_range.mpr (by omega), bornAt_last H tr⟩
  simpa using h

theorem bornAt_mono {H d d' tr : ℕ} (hdd : d ≤ d') (h : bornAt H d tr = true) :
    bornAt H d' tr = true := by
  simp only [bornAt, beq_iff_eq] at h ⊢
  rw [← Nat.dvd_iff_mod_eq_zero] at h ⊢
  exact Nat.dvd_trans (Nat.pow_dvd_pow 2 (by omega)) h

/-- The depths born at round `tr` are exactly `firstBorn H tr, …, H − 1` (nested dyadic lifetimes). -/
theorem bornAt_iff_firstBorn_le (H tr d : ℕ) (hH : 1 ≤ H) :
    bornAt H d tr = true ↔ firstBorn H tr ≤ d := by
  have hlt := firstBorn_lt H tr hH
  constructor
  · intro h
    by_contra hcon
    replace hcon := lt_of_not_ge hcon
    have := List.not_of_lt_findIdx (p := fun d => bornAt H d tr) (xs := List.range H)
      (i := d) (by simpa [firstBorn] using hcon)
    simp [h] at this
  · intro h
    refine bornAt_mono h ?_
    have := List.findIdx_getElem (p := fun d => bornAt H d tr) (xs := List.range H)
      (w := by simpa [firstBorn] using hlt)
    simpa [firstBorn] using this

/-- `m ≤ 2^{H−1}` (eq. `R:eq:sec5-depth-H`). -/
theorem m_le_pow (P : StreamParams) : P.m ≤ 2 ^ (P.H - 1) := by
  have h : P.H - 1 = Nat.clog 2 (max 1 P.m) := by unfold StreamParams.H; omega
  rw [h]
  exact le_trans (le_max_right 1 P.m) (Nat.le_pow_clog (by norm_num) _)

/-- Depth `0` is born only at round `1`: for `1 ≤ t < m` the shallowest depth born at round `t + 1` is `≥ 1`. -/
theorem firstBorn_pos (P : StreamParams) {t : ℕ} (h1 : 1 ≤ t) (h2 : t < P.m) :
    1 ≤ firstBorn P.H (t + 1) := by
  by_contra hcon
  have hb : bornAt P.H 0 (t + 1) = true :=
    (bornAt_iff_firstBorn_le P.H (t + 1) 0 P.one_le_H).mpr (by omega)
  simp only [bornAt, beq_iff_eq, Nat.add_sub_cancel, Nat.sub_zero] at hb
  have hm := m_le_pow P
  rw [Nat.mod_eq_of_lt (by omega)] at hb
  omega

/-- **The dyadic schedule**: if `a ≥ 1` is a birth round of depth `k` and `a < b < c` are birth rounds of depth
`k + 1`, then depth `k` is born again in `(a, c]` (a lifetime of depth `k` contains at most two births of depth
`k + 1`). -/
theorem exists_parent_birth {H k a b c : ℕ} (hk : k + 1 < H) (ha1 : 1 ≤ a) (ha : bornAt H k a = true)
    (hb : bornAt H (k + 1) b = true) (hc : bornAt H (k + 1) c = true) (hab : a < b) (hbc : b < c) :
    ∃ r, a < r ∧ r ≤ c ∧ bornAt H k r = true := by
  simp only [bornAt, beq_iff_eq] at ha hb hc
  rw [← Nat.dvd_iff_mod_eq_zero] at ha hb hc
  obtain ⟨K, hK⟩ : ∃ K, K = 2 ^ (H - 2 - k) := ⟨_, rfl⟩
  have e1 : 2 ^ (H - 1 - k) = 2 * K := by
    rw [hK, ← pow_succ']
    congr 1
    omega
  have e2 : 2 ^ (H - 1 - (k + 1)) = K := by
    rw [hK]
    congr 1
    omega
  rw [e1] at ha
  rw [e2] at hb hc
  obtain ⟨α, hα⟩ := ha
  obtain ⟨β, hβ⟩ := hb
  obtain ⟨γ, hγ⟩ := hc
  have hKpos : 0 < K := by rw [hK]; positivity
  have h1 : K * (2 * α) < K * β := by
    calc K * (2 * α) = 2 * K * α := by ring
      _ = a - 1 := hα.symm
      _ < b - 1 := by omega
      _ = K * β := hβ
  have h2 : K * β < K * γ := by
    calc K * β = b - 1 := hβ.symm
      _ < c - 1 := by omega
      _ = K * γ := hγ
  have h1' : 2 * α < β := Nat.lt_of_mul_lt_mul_left h1
  have h2' : β < γ := Nat.lt_of_mul_lt_mul_left h2
  have h3 : K * (2 * (α + 1)) ≤ K * γ := Nat.mul_le_mul_left K (by omega)
  refine ⟨a + 2 * K, by omega, ?_, ?_⟩
  · have : a + 2 * K - 1 ≤ c - 1 := by
      calc a + 2 * K - 1 = (a - 1) + 2 * K := by omega
        _ = K * (2 * (α + 1)) := by rw [hα]; ring
        _ ≤ K * γ := h3
        _ = c - 1 := hγ.symm
    omega
  · simp only [bornAt, beq_iff_eq]
    rw [← Nat.dvd_iff_mod_eq_zero, e1]
    exact ⟨α + 1, by rw [show a + 2 * K - 1 = (a - 1) + 2 * K by omega, hα]; ring⟩

/-- At the start of round `t + 1`, when the shallowest born depth is `d₀ ≥ 1`, the depth-`d₀` client of the retained
bank `d₀` cannot be in a second child lifetime: with the last births `a` of depth `d₀ − 1` and `b ≠ a` of depth `d₀`
(no births in `(a, t]`, resp. `(b, t]`), the rebirth of depth `d₀` at `t + 1` would be a third birth of depth `d₀`
in one lifetime of depth `d₀ − 1`. -/
theorem no_third_life {H d0 t a b : ℕ} (hH : 1 ≤ H) (hd0 : 1 ≤ d0) (hdH : d0 < H)
    (hfb : firstBorn H (t + 1) = d0) (ha1 : 1 ≤ a) (ha : bornAt H (d0 - 1) a = true)
    (haN : ∀ r, a < r → r ≤ t → bornAt H (d0 - 1) r = false) (hb : bornAt H d0 b = true)
    (hbN : ∀ r, b < r → r ≤ t → bornAt H d0 r = false) (hat : a ≤ t) (hbt : b ≤ t) (hne : b ≠ a) :
    False := by
  have ha' : bornAt H d0 a = true := bornAt_mono (by omega) ha
  have hab : a < b := by
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have := hbN a hlt hat
      rw [ha'] at this
      exact absurd this (by decide)
    · exact hgt
  have hc : bornAt H d0 (t + 1) = true := (bornAt_iff_firstBorn_le H (t + 1) d0 hH).mpr (le_of_eq hfb)
  have e : d0 - 1 + 1 = d0 := by omega
  obtain ⟨r, hr1, hr2, hr3⟩ := exists_parent_birth (H := H) (k := d0 - 1) (a := a) (b := b) (c := t + 1)
    (by omega) ha1 ha (by rw [e]; exact hb) (by rw [e]; exact hc) hab (by omega)
  rcases Nat.lt_or_ge r (t + 1) with hlt | hge
  · have := haN r hr1 (by omega)
    rw [hr3] at this
    exact absurd this (by decide)
  · have hr : r = t + 1 := by omega
    rw [hr] at hr3
    have := (bornAt_iff_firstBorn_le H (t + 1) (d0 - 1) hH).mp hr3
    omega

end OrcAux

end F2e2e.C.Closure
