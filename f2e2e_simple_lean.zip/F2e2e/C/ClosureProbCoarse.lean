import F2e2e.C.ClosureProbLabels
import F2e2e.C.NormBank.Coarse
import F2e2e.C.ClosureProbCoarseCouple
import F2e2e.C.ClosureProbGroup

/-!
# Theorem 6.4, probability layer (C-PROB): the coarse events of one bank

Paper: `parts/partIII.tex` L1275 ("Each unused coarse group is maintained but influences no decision. Its target
shadow vector at first use is therefore independent of that group. This holds before geometric correctness is
established"); L1277 ("the exact coarse moment events have their allocated probabilities"); Lemma `R:lem:coarse-ams`
and the proof of Theorem `R:thm:L3_Two_Regime_Norm_Bank_And_Ordered_Tree_Step` (L387): each group fails with
probability at most `β_B/(2R_max)`.

Proof structure: retag the bits `true` for the reserved coarse group `k` of bank `lab` (`coarseSel lab k`), `false`
for all others. The group's seeds are drawn at the bank's birth and read only by the bank's `k`-th consuming release
(rowwise operations act on its rows without reading them), so for a fixed `false`-stream the record of that release,
hence its target `aug σ (bankShadow mode hist)`, does not depend on the group's stream, while the group's seeds are
uniform; C-BANK's `coarse_bad_count` bounds the bad fraction (`coarse_block_count`), and `law_le_of_blocks`,
`ncard_run_eq_law` give the tape count `card_not_coarseGood_le`.

The information flow is the coupling `coarse_coupling` (`F2e2e/C/ClosureProbCoarseCouple.lean`) of the instrumented
run with the stopping placeholder interpreter `runLs`, which never reads the group's tape: for a fixed `false`-tape
`a`, its stop information `(mode, hist)` is a function of `a` alone. The uniformity of the group and C-BANK's count
are B-PRIV's `group_count` (`F2e2e/C/ClosureProbGroup.lean`). Groups `k ≥ R_max` never fail (`labInv_fullCode`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg
open scoped ENNReal

/-! ### Helpers -/

theorem tAll_of_bpAll_merge {ι α : Type} {Q : α → Prop} :
    ∀ (p : TBitProg ι α), FP.BPAll p.merge Q → TAll p Q
  | TBitProg.pure _, h => h
  | TBitProg.bit _ k, h => fun b => tAll_of_bpAll_merge (k b) (h b)

theorem runS_retag_map {α β : Type} (sel : Tag → Bool) (p : TBitProg Tag α) (f : α → β)
    (σ : Bool → List Bool) :
    ((p.map f).retag sel).runS σ = ((p.retag sel).runS σ).map (fun r => (f r.1, r.2)) := by
  rw [TBitProg.map, retag_bind, runS_bind]
  cases (p.retag sel).runS σ <;> rfl

/-- **The label invariant along the whole interaction** `fullCode` (any label set `L` containing the born labels). -/
theorem labInv_fullCode (P : StreamParams) (adv : StreamAdversary P.n) (L : BankLabel → Prop)
    (hL0 : L (0, 0)) (hL : ∀ tr d, 1 ≤ tr → tr ≤ P.m → d + 2 ≤ P.H → L (tr, d)) :
    ∀ t, t ≤ P.m → FP.BPAll (runL P (fullCode P adv t) initO Ghost.init).merge
      (fun r => LabInv P L (t + 1, 0) r.2.1 r.2.2 ∧ r.1.1.t = t)
  | 0, _ => by
    show FP.BPAll (runL P (initCode.bind fun c => AlgM.pure (c, [])) initO Ghost.init).merge _
    rw [LabAux.runL_bind, merge_bind]
    refine FP.BPAll.bind (fun r hr => ?_) (initCode_labInv P L hL0)
    exact FP.BPAll.pure ⟨hr.1, hr.2⟩
  | t + 1, ht => by
    show FP.BPAll (runL P ((fullCode P adv t).bind fun co =>
      (roundCode P co.1 (adv co.2).1.val (adv co.2).2).bind fun r =>
        AlgM.pure (r.1, co.2 ++ [r.2])) initO Ghost.init).merge _
    rw [LabAux.runL_bind, merge_bind]
    refine FP.BPAll.bind (fun r hr => ?_) (labInv_fullCode P adv L hL0 hL t (by omega))
    simp only [LabAux.runL_bind, merge_bind]
    have hct : r.1.1.t < P.m := by rw [hr.2]; omega
    have hinv : LabInv P L (r.1.1.t + 1, 0) r.2.1 r.2.2 := by rw [hr.2]; exact hr.1
    refine FP.BPAll.bind (fun r2 hr2 => ?_)
      (roundCode_labInv P L hL r.1.1 (adv r.1.2).1.val (adv r.1.2).2 r.2.1 r.2.2 hct hinv)
    refine FP.BPAll.pure ⟨?_, ?_⟩
    · have h2 := hr2.1
      rw [hr.2] at h2
      exact h2
    · show r2.1.1.t = t + 1
      rw [hr2.2, hr.2]

/-- The real outcomes of the retagged interaction, as instrumented results. -/
theorem runS_interactT (P : StreamParams) (adv : StreamAdversary P.n) (sel : Tag → Bool)
    (σ : Bool → List Bool) {x : Option ((State × Ghost) × List ℚ)} {τ : Bool → List Bool}
    (h : ((interactT P adv P.m).retag sel).runS σ = some (x, τ)) :
    ∃ r τ0, ((runL P (fullCode P adv P.m) initO Ghost.init).retag sel).runS σ = some (r, τ0) ∧
      x = packC r := by
  rw [interactT_eq, runS_retag_map] at h
  obtain ⟨q, hq, hqe⟩ := Option.map_eq_some_iff.mp h
  simp only [Prod.mk.injEq] at hqe
  exact ⟨q.1, q.2, hq, hqe.1.symm⟩

theorem coarseGood_of_length_le {P : StreamParams} {lab : BankLabel} {k : ℕ} {g : Ghost}
    (h : (coarseRecs lab g).length ≤ k) : CoarseGood P lab k g := by
  intro rec hrec
  rw [List.getElem?_eq_none_iff.mpr h] at hrec
  exact absurd hrec (by simp)

/-- The target vector of a stop information (`0` if the run did not stop). -/
noncomputable def stopTarget (P : StreamParams) {β γ : Type} : Option ((StopInfo ⊕ β) × γ) → EuclideanSpace ℝ (Fin P.Dstar)
  | some (Sum.inl info, _) => aug P P.sigma (bankShadow P info.1 info.2)
  | _ => 0

/-! ### The block count -/

open Classical in
/-- **The information-flow core of the coarse events**: for every fixed stream `a` of the other bits, at most a
`β_B/(2R_max)` fraction of the streams of group `k` of bank `lab` makes its coarse event fail. -/
theorem coarse_block_count (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (lab : BankLabel) (k : ℕ) (nΛ nO : ℕ)
    (hp : ReadsLE ((interactT P adv P.m).retag (coarseSel lab k)) (fun b => if b then nΛ else nO))
    (a : List Bool) (ha : a ∈ lenFinset nO) :
    ∑ l ∈ lenFinset nΛ,
        (if ∃ x, (((interactT P adv P.m).retag (coarseSel lab k)).runS (pairStreams a l)).map Prod.fst =
              some x ∧ x ∈ coarseBad P lab k
          then (1 : ℝ≥0∞) else 0) ≤
      ENNReal.ofReal ((P.betaB : ℝ) / (2 * P.Rmax)) * 2 ^ nΛ := by
  -- every real outcome is an instrumented result of `fullCode`
  have hreal : ∀ l x, (((interactT P adv P.m).retag (coarseSel lab k)).runS (pairStreams a l)).map
      Prod.fst = some x → x ∈ coarseBad P lab k →
      ∃ r τ0, ((runL P (fullCode P adv P.m) initO Ghost.init).retag (coarseSel lab k)).runS
        (pairStreams a l) = some (r, τ0) ∧ ¬ CoarseGood P lab k r.2.2 := by
    intro l x hx hbad
    obtain ⟨q, hq, rfl⟩ := Option.map_eq_some_iff.mp hx
    obtain ⟨r, τ0, hr, hxe⟩ := runS_interactT P adv (coarseSel lab k) (pairStreams a l) hq
    obtain ⟨c, hc, hnc⟩ := hbad
    rw [hxe] at hc
    simp only [packC, Option.some.injEq] at hc
    subst hc
    exact ⟨r, τ0, hr, hnc⟩
  by_cases hk : k < P.Rmax
  · -- the stop information of the placeholder run on the fixed `false` tape
    set w0 : EuclideanSpace ℝ (Fin P.Dstar) := stopTarget P
      (((runLs P lab k (fullCode P adv P.m) initO Ghost.init).retag (coarseSel lab k)).runS
        (pairStreams a [])) with hw0
    refine le_trans (Finset.sum_le_sum fun l _ => ?_) (group_count P hP w0 nΛ)
    by_cases hE : ∃ x, (((interactT P adv P.m).retag (coarseSel lab k)).runS (pairStreams a l)).map
        Prod.fst = some x ∧ x ∈ coarseBad P lab k
    · rw [if_pos hE]
      obtain ⟨x, hx, hbad⟩ := hE
      obtain ⟨r, τ0, hr, hnc⟩ := hreal l x hx hbad
      set s : Fin P.gCoarse → Fin 32 → Seed P :=
        ((grpProg P).run l).elim (groupSeeds P []) (fun q => groupSeeds P q.1) with hsdef
      have hs : ∀ z rest, (grpProg P).run l = some (z, rest) → groupSeeds P z = s := by
        intro z rest hz
        rw [hsdef, hz]
        rfl
      obtain ⟨y, τ', hy, hconc⟩ := coarse_coupling P lab k s l hk hs (fullCode P adv P.m) false initO
        Ghost.init initO Ghost.init (pairStreams a l) (pairStreams a []) r τ0 (CRel.init P lab k s l)
        (birthsOK_fullCode_once P adv lab P.m) (fun _ => rfl) rfl hr
      rcases hconc with ⟨born', x', -, hcr⟩ | ⟨info, rfl, ⟨rec, hrec, hkind, hhist, grp, rest, hco, hgs⟩,
        z, zr, hz⟩
      · exact absurd (coarseGood_of_length_le hcr.cnt_le) hnc
      · have hw : w0 = aug P P.sigma (bankShadow P info.1 info.2) := by
          rw [hw0, hy]
          rfl
        have hbadrec : ¬ CoarseOK P rec := fun hok => hnc fun rec' hrec' => by
          rw [hrec] at hrec'
          cases hrec'
          exact hok
        unfold CoarseOK at hbadrec
        rw [hkind, hco] at hbadrec
        simp only at hbadrec
        rw [hgs, ← hs z zr hz, hhist] at hbadrec
        have hcond : ∃ grp rest, (sampleList (sampleList (newRow P) 32) P.gCoarse).run l =
            some (grp, rest) ∧
            ¬ (9 / 16 * ‖w0‖ ^ 2 ≤ FinProb.coarseEst (FinProb.rowVals (sgn P) w0 (groupSeeds P grp)) ∧
              FinProb.coarseEst (FinProb.rowVals (sgn P) w0 (groupSeeds P grp)) ≤
                23 / 16 * ‖w0‖ ^ 2) := ⟨z, zr, hz, by rw [hw]; exact hbadrec⟩
        rw [if_pos hcond]
    · rw [if_neg hE]
      exact zero_le
  · -- groups beyond the reserve never fail
    push Not at hk
    have h0 : ∀ l ∈ lenFinset nΛ, (if ∃ x, (((interactT P adv P.m).retag (coarseSel lab k)).runS
        (pairStreams a l)).map Prod.fst = some x ∧ x ∈ coarseBad P lab k then (1 : ℝ≥0∞) else 0) = 0 := by
      intro l _
      rw [if_neg]
      rintro ⟨x, hx, hbad⟩
      obtain ⟨r, τ0, hr, hnc⟩ := hreal l x hx hbad
      have hinv := TAll.of_runS (TAll.retag (coarseSel lab k) (tAll_of_bpAll_merge _
        (labInv_fullCode P adv (fun _ => True) trivial (fun _ _ _ _ _ => trivial) P.m le_rfl))) hr
      exact hnc (coarseGood_of_length_le (le_trans (le_trans (Nat.le_add_right _ _)
        (hinv.1.count lab)) hk))
    rw [Finset.sum_eq_zero h0]
    exact zero_le

/-- **One coarse event fails on at most a `β_B/(2R_max)` fraction of the tapes** (Lemma 4.2 for one reserved group;
partIII.tex L387, L1277). -/
theorem card_not_coarseGood_le (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (lab : BankLabel) (k : ℕ) :
    (({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ ¬ CoarseGood P lab k c.1.2} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      (P.betaB : ℝ) / (2 * P.Rmax) * 2 ^ ((P.m + 1) * tapeBits P) := by
  have hβ : (0 : ℝ) ≤ (P.betaB : ℝ) / (2 * P.Rmax) := by
    have : (0 : ℝ) < (P.betaB : ℝ) := by exact_mod_cast StreamParams.betaB_pos hP.one_le_m
    positivity
  exact card_le_of_blocks P adv (coarseSel lab k) (fun c => ¬ CoarseGood P lab k c.1.2) (coarseBad P lab k) rfl _ hβ
    (fun nΛ nO hp a ha => coarse_block_count P hP adv lab k nΛ nO hp a ha)

end F2e2e.C.Closure
