import Mathlib
import F2e2e.C.ClosureTreeWitAux

/-!
# Theorem 6.4, witness side: the per-block lemmas

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree` (L466–517, as coded in
`F2e2e/C/Alg/AlgMCode.lean`), the chronological induction of Theorem `R:thm:chronological-closure-and-main-proof`
(L1287–1317), Lemma `R:lem:sec6-precision` (ii) (tags), Lemma `R:lem:sec6-covariant-cache` (caches), Lemma
`R:lem:terminal-accumulator` (the accumulator) and the range checks of the algorithm (L452: tags in `[0, C_max]`,
caches and accumulator in `[0, A_max]`).

For every block of a round, `witSide_X` gives the witness side (`WitSide`, i.e. all fields of `TreePart` except
C-TREE's `tree`, `nLearners`, `bornZero`) at the next moment, for the controller state computed by the code and the
tree shadow after the block's analysis event; `wit_X_range` gives the block's range checks. The tree part at the
next moment is then `TreePart.mk_wit (tree_X …) hnL hbz (witSide_X …)`.

* Step 1: `witSide_init`, `witSide_newRound`, `witSide_birth`, `wit_birth_range`;
* Step 2: `witSide_phys`, `wit_phys_range`; the zero bypass `witSide_bypass`;
* Step 3: `witSide_guard_zero`, `witSide_guard`, `wit_guard_range`;
* Step 4: `witSide_startStep4`, `witSide_accept`, `wit_eval_range`, `wit_N1_range`, `witSide_reject`,
  `wit_reject_range`, `witSide_endRound`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-! ## Initialization and Step 1 -/

/-- Round `1` starts from the initial tree state with no learner (`live = 0`). -/
theorem witSide_init (c : CState) :
    WitSide P (.births 0) c ((Tree.TreeState.init P.Dstar).step P .newRound) 1 where
  root h := absurd h (lt_irrefl 0)
  tagW d hd := absurd hd (Nat.not_lt_zero d)
  cacheW d hd := absurd hd (Nat.not_lt_zero d)
  cacheNonneg d hd := absurd hd (Nat.not_lt_zero d)
  tagNonneg d hd := absurd hd (Nat.not_lt_zero d)
  leafExact D hD := by cases hD
  leafW D hD := by cases hD
  leafNonneg h := by simp [leafPhase] at h

/-- A new round (`newRound`, retirement of the depths `≥ d₀`): nothing is rounded. -/
theorem witSide_newRound {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P .idle c S nev) :
    WitSide P (.births (firstBorn P.H (S.t + 1)))
      { c with learners := c.learners.take (firstBorn P.H (S.t + 1)) } (S.step P .newRound) (nev + 1) := by
  have hd0H : firstBorn P.H (S.t + 1) < P.H := firstBorn_lt P.H (S.t + 1) (H_pos P)
  have hw : ∀ D, D ≤ P.H → ∀ a, winProd (S.step P .newRound) D a = winProd S D a := by
    intro D hD a
    refine wit_winProd_eq_of_pws (fun L => pws_newRound S D 1 L fun j hj e he => ?_) a
    exact (h.tree.log_t j (show j < P.H by omega) e he).2.1
  have hE : ∀ d, (S.step P .newRound).E d = S.E d := fun d => rfl
  have hC : ∀ d, (S.step P .newRound).C d = S.C d := fun d => rfl
  have hget : ∀ d, d < firstBorn P.H (S.t + 1) →
      (c.learners.take (firstBorn P.H (S.t + 1))).getD d dfltLearner = c.learners.getD d dfltLearner :=
    fun d hd => wit_getD_take _ hd
  refine ⟨fun h0 => ?_, fun d hd => ?_, fun d hd => ?_, fun d hd => ?_, fun d hd => ?_, fun D hD => ?_,
    fun D hD => ?_, fun hl => ?_⟩
  · show ((c.learners.take (firstBorn P.H (S.t + 1))).getD 0 dfltLearner).tag = 2 ^ P.eHC
    rw [hget 0 h0]
    exact h.root (show 0 < P.H by omega)
  · have hdH : d < P.H := lt_trans hd hd0H
    show TagW P _ d (nev + 1)
      ((gridVal P.eHC ((c.learners.take (firstBorn P.H (S.t + 1))).getD d dfltLearner).tag : ℚ) : ℝ)
    rw [hget d hd]
    exact (tagW_congr (h.tagW d hdH) (hC d) (hw d hdH.le)).mono (Nat.le_succ nev)
  · have hdH : d < P.H := lt_trans hd hd0H
    show CacheW P _ d (nev + 1)
      ((gridVal P.eHP ((c.learners.take (firstBorn P.H (S.t + 1))).getD d dfltLearner).cache : ℚ) : ℝ)
    rw [hget d hd]
    exact (cacheW_congr (h.cacheW d hdH) (hE d) (hw d hdH.le)).mono (Nat.le_succ nev)
  · show 0 ≤ ((c.learners.take (firstBorn P.H (S.t + 1))).getD d dfltLearner).cache
    rw [hget d hd]
    exact h.cacheNonneg d (lt_trans hd hd0H)
  · show 0 ≤ ((c.learners.take (firstBorn P.H (S.t + 1))).getD d dfltLearner).tag
    rw [hget d hd]
    exact h.tagNonneg d (lt_trans hd hd0H)
  · cases hD
  · cases hD
  · simp [leafPhase] at hl

/-- The birth of depth `d`: the new learner `newLearner P cache` (tag `2^{e_{h_C}}`, i.e. `Ĉ_d = C_d = 1`) with the
birth cache `0` (input known to vanish) or `round_{h_P}(N)` for a release `N ≥ 0` of `x_d` with its numerical
certificate (a fresh measurement of `E_d⁺ = ‖x_d‖²`). -/
theorem witSide_birth {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.births d) c S nev)
    {cache : ℤ}
    (hcache : (cache = 0 ∧ S.x d = 0) ∨
      ∃ N : ℚ, 0 ≤ N ∧ cache = roundMant P.eHP N ∧
        NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N : ℝ)) :
    WitSide P (.births (d + 1)) { c with learners := c.learners ++ [newLearner P cache] }
      (S.step P (.birth d)) (nev + 1) := by
  have hlen : c.learners.length = d := h.nLearners
  have hw : ∀ D, D ≤ d → ∀ a, winProd (S.step P (.birth d)) D a = winProd S D a := fun D hD a =>
    wit_winProd_eq_of_pws (fun L => pws_birth S D 1 L hD) a
  have hC : ∀ j, j ≠ d → (S.step P (.birth d)).C j = S.C j := fun j hj => by
    rw [Tree.step_birth_C, Function.update_of_ne hj]
  have hE : ∀ j, j ≠ d → (S.step P (.birth d)).E j = S.E j := fun j hj => by
    unfold Tree.TreeState.E
    rw [Tree.step_birth_r, Function.update_of_ne hj]
  have hCd : (S.step P (.birth d)).C d = 1 := by
    rw [Tree.step_birth_C, Function.update_self]
  have hEd : (S.step P (.birth d)).E d = ‖S.x d‖ ^ 2 := by
    unfold Tree.TreeState.E
    rw [Tree.step_birth_r, Function.update_self]
  have hget_lt : ∀ j, j < d →
      (c.learners ++ [newLearner P cache]).getD j dfltLearner = c.learners.getD j dfltLearner :=
    fun j hj => wit_getD_append_lt _ _ (by omega)
  have hget_d : (c.learners ++ [newLearner P cache]).getD d dfltLearner = newLearner P cache := by
    have := wit_getD_append_length c.learners (newLearner P cache)
    rwa [hlen] at this
  have hcache0 : 0 ≤ cache := by
    rcases hcache with ⟨h0, -⟩ | ⟨N, hN, hc, -⟩
    · rw [h0]
    · rw [hc]
      exact wit_roundMant_nonneg _ hN
  have hfresh : |((gridVal P.eHP cache : ℚ) : ℝ) - ‖S.x d‖ ^ 2| ≤
      (1 / 2) ^ 13 * (P.eta : ℝ) * ‖S.x d‖ ^ 2 + (P.omega : ℝ) + (P.hP : ℝ) := by
    have hom0 : (0 : ℝ) ≤ (P.omega : ℝ) := by exact_mod_cast P.omega_pos.le
    have hhP0 : (0 : ℝ) ≤ (P.hP : ℝ) := by exact_mod_cast P.hP_pos.le
    rcases hcache with ⟨h0, hx0⟩ | ⟨N, -, hc, hcert⟩
    · rw [h0, hx0]
      have e : ((gridVal P.eHP 0 : ℚ) : ℝ) = 0 := by simp [gridVal]
      rw [e, norm_zero]
      have h00 : |(0 : ℝ) - 0 ^ 2| = 0 := by norm_num
      have h01 : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) * 0 ^ 2 = 0 := by ring
      rw [h00, h01]
      linarith
    · rw [hc]
      have h1 := wit_round_err_hP (P := P) N
      unfold NumCert at hcert
      calc |((gridVal P.eHP (roundMant P.eHP N) : ℚ) : ℝ) - ‖S.x d‖ ^ 2|
          ≤ |((gridVal P.eHP (roundMant P.eHP N) : ℚ) : ℝ) - (N : ℝ)| + |(N : ℝ) - ‖S.x d‖ ^ 2| :=
            abs_sub_le _ _ _
        _ ≤ (P.hP : ℝ) + ((1 / 2) ^ 13 * (P.eta : ℝ) * ‖S.x d‖ ^ 2 + (P.omega : ℝ)) := add_le_add h1 hcert
        _ = (1 / 2) ^ 13 * (P.eta : ℝ) * ‖S.x d‖ ^ 2 + (P.omega : ℝ) + (P.hP : ℝ) := by ring
  refine ⟨fun h0 => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun D hD => ?_,
    fun D hD => ?_, fun hl => ?_⟩
  · show ((c.learners ++ [newLearner P cache]).getD 0 dfltLearner).tag = 2 ^ P.eHC
    rcases Nat.eq_zero_or_pos d with hd0 | hd0
    · subst hd0
      rw [hget_d]
      rfl
    · rw [hget_lt 0 hd0]
      exact h.root hd0
  · have hj' : j < d + 1 := hj
    rcases Nat.lt_or_ge j d with hjd | hjd
    · show TagW P _ j (nev + 1) ((gridVal P.eHC ((c.learners ++ [newLearner P cache]).getD j dfltLearner).tag : ℚ) : ℝ)
      rw [hget_lt j hjd]
      exact (tagW_congr (h.tagW j hjd) (hC j (by omega)) (hw j hjd.le)).mono (Nat.le_succ nev)
    · have hjd' : j = d := by omega
      rw [hjd']
      apply tagW_of_eq
      rw [hCd]
      show ((gridVal P.eHC ((c.learners ++ [newLearner P cache]).getD d dfltLearner).tag : ℚ) : ℝ) = 1
      rw [hget_d]
      show ((gridVal P.eHC (2 ^ P.eHC) : ℚ) : ℝ) = 1
      rw [wit_gridVal_two_pow, Rat.cast_one]
  · have hj' : j < d + 1 := hj
    rcases Nat.lt_or_ge j d with hjd | hjd
    · show CacheW P _ j (nev + 1)
        ((gridVal P.eHP ((c.learners ++ [newLearner P cache]).getD j dfltLearner).cache : ℚ) : ℝ)
      rw [hget_lt j hjd]
      exact (cacheW_congr (h.cacheW j hjd) (hE j (by omega)) (hw j hjd.le)).mono (Nat.le_succ nev)
    · have hjd' : j = d := by omega
      rw [hjd']
      apply cacheW_fresh
      rw [hEd]
      show |((gridVal P.eHP ((c.learners ++ [newLearner P cache]).getD d dfltLearner).cache : ℚ) : ℝ) -
        ‖S.x d‖ ^ 2| ≤ _
      rw [hget_d]
      exact hfresh
  · have hj' : j < d + 1 := hj
    show 0 ≤ ((c.learners ++ [newLearner P cache]).getD j dfltLearner).cache
    rcases Nat.lt_or_ge j d with hjd | hjd
    · rw [hget_lt j hjd]
      exact h.cacheNonneg j hjd
    · have hjd' : j = d := by omega
      rw [hjd', hget_d]
      exact hcache0
  · have hj' : j < d + 1 := hj
    show 0 ≤ ((c.learners ++ [newLearner P cache]).getD j dfltLearner).tag
    rcases Nat.lt_or_ge j d with hjd | hjd
    · rw [hget_lt j hjd]
      exact h.tagNonneg j hjd
    · have hjd' : j = d := by omega
      rw [hjd', hget_d]
      show (0 : ℤ) ≤ 2 ^ P.eHC
      positivity
  · cases hD
  · cases hD
  · simp [leafPhase] at hl

/-- The range check of the birth cache: `0 ≤ round_{h_P}(N) ≤ N + h_P ≤ 2‖x_d‖² + 2 ≤ 2V² + 2 ≤ A_max`. -/
theorem wit_birth_range {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.births d) c S nev)
    (_hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) {cache : ℤ}
    (hcache : (cache = 0 ∧ S.x d = 0) ∨
      ∃ N : ℚ, 0 ≤ N ∧ cache = roundMant P.eHP N ∧
        NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N : ℝ)) :
    inRangeA P (gridVal P.eHP cache) = true := by
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hfin : (2 : ℝ) * (P.V : ℝ) ^ 2 + 2 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
  rcases hcache with ⟨h0, -⟩ | ⟨N, hN, hc, hcert⟩
  · rw [h0]
    apply wit_inRangeA_of_le (by simp [gridVal])
    have e : ((gridVal P.eHP 0 : ℚ) : ℝ) = 0 := by simp [gridVal]
    rw [e]
    positivity
  · have hx := (wit_vec_sq h.tree hbox).1 d (le_refl d)
    rw [hc]
    have hround := wit_round_err_hP (P := P) N
    unfold NumCert at hcert
    have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
    have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
    have hω1 : (P.omega : ℝ) ≤ 1 := by exact_mod_cast P.omega_le_one
    have hhP1 : (P.hP : ℝ) ≤ 1 := by exact_mod_cast P.hP_le_one
    have h13 : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) ≤ 1 := by
      have : (1 / 2 : ℝ) ^ 13 ≤ 1 := by norm_num
      nlinarith
    have hb : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) * ‖S.x d‖ ^ 2 ≤ ‖S.x d‖ ^ 2 :=
      mul_le_of_le_one_left (sq_nonneg _) h13
    apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _ hN))
    have a1 := (abs_le.mp hround).2
    have a2 := (abs_le.mp hcert).2
    linarith

/-! ## Step 2 and the zero bypass -/

/-- Step 2: the physical update `x_0 += Δ e_i` and the accumulator `round_{h_leaf}(Δ²) = Δ² = ‖x_H⁺‖²` (exact:
after the births `x_H = 0`). -/
theorem witSide_phys {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.births P.H) c S nev)
    (i : Fin P.n) (Δ : ℤ) :
    WitSide P (.guards 0) { c with leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2) } (S.step P (.phys i Δ))
      (nev + 1) := by
  have hw : ∀ D a, winProd (S.step P (.phys i Δ)) D a = winProd S D a := fun D a =>
    wit_winProd_eq_of_pws (fun L => pws_phys S D 1 L i Δ) a
  have hE : ∀ j, (S.step P (.phys i Δ)).E j = S.E j := fun j => rfl
  have hC : ∀ j, (S.step P (.phys i Δ)).C j = S.C j := fun j => rfl
  have hx : (S.step P (.phys i Δ)).x P.H = S.x P.H + (Δ : ℝ) • Tree.unitVec (Tree.physIdx P i) := by
    unfold Tree.TreeState.x
    rw [Tree.TreeState.step_phys_x0, Tree.TreeState.step_phys_r]
    abel
  obtain ⟨-, hxH⟩ := h.tree.leaf
  have hu : ‖Tree.unitVec (Tree.physIdx P i)‖ = 1 := by
    rw [Tree.unitVec_eq_unitAt, Tree.norm_unitAt (Fin.isLt _)]
  have hexact : leafVal P { c with leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2) } =
      ‖(S.step P (.phys i Δ)).x P.H‖ ^ 2 := by
    have e1 : leafVal P { c with leaf := roundMant P.eHleaf ((Δ : ℚ) ^ 2) } = (Δ : ℝ) ^ 2 := by
      show ((gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)) : ℚ) : ℝ) = (Δ : ℝ) ^ 2
      rw [gridVal_roundMant_exact P.eHleaf ((Δ : ℚ) ^ 2) (Δ ^ 2 * 2 ^ P.eHleaf) (by simp)]
      simp
    have e2 : ‖(S.step P (.phys i Δ)).x P.H‖ ^ 2 = (Δ : ℝ) ^ 2 := by
      rw [hx, hxH rfl, zero_add, norm_smul, hu, mul_one, Real.norm_eq_abs, sq_abs]
    rw [e1, e2]
  refine ⟨h.root, fun j hj => ?_, fun j hj => ?_, h.cacheNonneg, h.tagNonneg, fun D _ => hexact,
    fun D hD => ?_, fun _ => ?_⟩
  · exact (tagW_congr (h.tagW j hj) (hC j) (hw j)).mono (Nat.le_succ nev)
  · exact (cacheW_congr (h.cacheW j hj) (hE j) (hw j)).mono (Nat.le_succ nev)
  · cases hD
  · exact wit_roundMant_nonneg _ (sq_nonneg _)

/-- The range check of the accumulator after Step 2: `Δ² = ‖x_H⁺‖² ≤ V² ≤ A_max` (vector bound at the new moment). -/
theorem wit_phys_range {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.births P.H) c S nev)
    (i : Fin P.n) (Δ : ℤ) {R' : Tree.Regs} (hT' : Tree.TreeInv P (.guards 0) R' (S.step P (.phys i Δ)))
    (hbox : ‖(S.step P (.phys i Δ)).x0‖ ≤ (P.W : ℝ)) :
    inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2))) = true := by
  have hex : ((gridVal P.eHleaf (roundMant P.eHleaf ((Δ : ℚ) ^ 2)) : ℚ) : ℝ) =
      ‖(S.step P (.phys i Δ)).x P.H‖ ^ 2 := (witSide_phys h i Δ).leafExact 0 rfl
  have hV := (wit_vec_sq hT' hbox).2.2.2 rfl
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hfin : (P.V : ℝ) ^ 2 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
  apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _ (sq_nonneg _)))
  rw [hex]
  linarith

/-- The zero-round bypass: nothing changes (the moment becomes `idle`). -/
theorem witSide_bypass {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards 0) c S nev) :
    WitSide P .idle c S nev where
  root := h.root
  tagW := h.tagW
  cacheW := h.cacheW
  cacheNonneg := h.cacheNonneg
  tagNonneg := h.tagNonneg
  leafExact D hD := by cases hD
  leafW D hD := by cases hD
  leafNonneg hl := by simp [leafPhase] at hl

/-! ## Step 3 -/

/-- The Step-3 guard coordinate of depth `d` in round `t = c.t + 1 = S.t` is `g(d, t)`. -/
theorem wit_guard_idx {c : CState} {S : Tree.TreeSt P} {d : ℕ} (ht : c.t + 1 = S.t)
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    (⟨P.guardCoord d (c.t + 1) - 1, hg⟩ : Fin P.Dstar).val = Tree.guardIdx P d S.t := by
  show P.guardCoord d (c.t + 1) - 1 = P.guardCoord d S.t - 1
  rw [ht]

/-- Step 3 at depth `d` on the fresh coordinate `g = g(d, t)` (Lemma 5.4 (iii)(c), Lemma 5.6, Lemma 5.3):
`E_d⁺ = E_d + δ²`, the other energies are unchanged, and `‖x_H⁺‖² = ‖x_H‖² + δ²`. -/
theorem wit_guard_energy {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (hd : d < P.H) (g : Fin P.Dstar) (hgv : g.val = Tree.guardIdx P d S.t) (δ : ℝ) :
    (S.step P (.guard d g δ)).E d = S.E d + δ ^ 2 ∧
      (∀ j, j ≠ d → (S.step P (.guard d g δ)).E j = S.E j) ∧
      ‖(S.step P (.guard d g δ)).x P.H‖ ^ 2 = ‖S.x P.H‖ ^ 2 + δ ^ 2 := by
  have ht1 : 1 ≤ S.t := h.tree.round_pos
  have hrg : (S.r d) g = 0 := by
    have h0 : Tree.coordAt (S.r d) g.val = 0 := by
      apply h.tree.fresh d hd
      show P.guardCoord d S.t ≤ g.val + 1
      rw [hgv, Tree.guardIdx_add_one]
    unfold Tree.coordAt at h0
    rw [dif_pos g.isLt] at h0
    exact h0
  have hxg : (S.x P.H) g = 0 := by
    obtain ⟨hupd, hxH⟩ := h.tree.leaf
    have h0 : Tree.coordAt (S.x P.H) g.val = 0 := by
      rw [hxH, Tree.coordAt_add, Tree.coordAt_sum,
        hupd g.val (by rw [hgv]; exact Tree.guardIdx_ge P d S.t), zero_add]
      apply Finset.sum_eq_zero
      intro j hj
      have hjd : j < d := Finset.mem_range.mp hj
      rw [Tree.coordAt_smul, Tree.coordAt_unitAt_ne, mul_zero]
      rw [hgv]
      exact Tree.guardIdx_ne_of_ne P (by omega) hd ht1 (by omega)
    unfold Tree.coordAt at h0
    rw [dif_pos g.isLt] at h0
    exact h0
  refine ⟨?_, fun j hj => ?_, ?_⟩
  · unfold Tree.TreeState.E
    rw [Tree.TreeState.step_guard_r, Function.update_self, Tree.smul_unitVec_eq_single]
    have := Tree.normalized_energy_guard (S.r d) g δ 1 hrg
    simpa using this
  · unfold Tree.TreeState.E
    rw [Tree.TreeState.step_guard_r, Function.update_of_ne hj]
  · rw [Tree.TreeState.x_guard, if_pos hd, Tree.smul_unitVec_eq_single]
    exact wit_norm_add_single_sq _ g δ hxg

/-- The own-guard cache update keeps the cache witness (with one more rounding error). -/
theorem wit_guard_cacheW {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (hd : d < P.H) (g : Fin P.Dstar) (hgv : g.val = Tree.guardIdx P d S.t) (δ : ℝ) {Ld : Learner}
    (hLd : c.learners[d]? = some Ld) {Pn : ℝ}
    (hround : |Pn - (((gridVal P.eHP Ld.cache : ℚ) : ℝ) + δ ^ 2)| ≤ (P.hP : ℝ)) :
    CacheW P (S.step P (.guard d g δ)) d (nev + 1) Pn := by
  obtain ⟨hEd, -, -⟩ := wit_guard_energy h hd g hgv δ
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  have hW0 : CacheW P S d nev ((gridVal P.eHP Ld.cache : ℚ) : ℝ) := by
    have := h.cacheW d hd
    unfold cacheVal at this
    rwa [hLdg] at this
  exact cacheW_add hW0 (sq_nonneg δ) hEd
    (fun a => wit_winProd_eq_of_pws (fun L => pws_guard S d 1 L d g δ) a) hround

/-- Step 3 at depth `d` (generic form): a new record `Lnew` of depth `d` with the same tag and the cache
`P⁺ ≈ P_d + δ²` (within `h_P`), the accumulator `acc⁺ = acc + δ²` (exact). -/
theorem witSide_guard_gen {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (hd : d < P.H) (g : Fin P.Dstar) (hgv : g.val = Tree.guardIdx P d S.t) (δ : ℝ)
    {Ld Lnew : Learner} (hLd : c.learners[d]? = some Ld) (htag : Lnew.tag = Ld.tag)
    (hcache0 : 0 ≤ Lnew.cache)
    (hcache : |((gridVal P.eHP Lnew.cache : ℚ) : ℝ) - (((gridVal P.eHP Ld.cache : ℚ) : ℝ) + δ ^ 2)| ≤
      (P.hP : ℝ))
    {leaf' : ℤ} (hleaf0 : 0 ≤ leaf')
    (hleaf : ((gridVal P.eHleaf leaf' : ℚ) : ℝ) = ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) + δ ^ 2) :
    WitSide P (.guards (d + 1)) { c with learners := setAt Lnew d c.learners, leaf := leaf' }
      (S.step P (.guard d g δ)) (nev + 1) := by
  obtain ⟨-, hEj, hxH⟩ := wit_guard_energy h hd g hgv δ
  have hlen : c.learners.length = P.H := h.nLearners
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  have hw : ∀ D a, winProd (S.step P (.guard d g δ)) D a = winProd S D a :=
    fun D a => wit_winProd_eq_of_pws (fun L => pws_guard S D 1 L d g δ) a
  have hget_ne : ∀ j, j ≠ d →
      (setAt Lnew d c.learners).getD j dfltLearner = c.learners.getD j dfltLearner :=
    fun j hj => wit_getD_setAt_ne _ _ _ hj
  have hget_d : (setAt Lnew d c.learners).getD d dfltLearner = Lnew :=
    wit_getD_setAt_self _ _ _ (by rw [hlen]; exact hd)
  have htag_all : ∀ j,
      ((setAt Lnew d c.learners).getD j dfltLearner).tag = (c.learners.getD j dfltLearner).tag := by
    intro j
    by_cases hj : j = d
    · rw [hj, hget_d, hLdg, htag]
    · rw [hget_ne j hj]
  refine ⟨fun h0 => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun D hD => ?_,
    fun D hD => ?_, fun _ => hleaf0⟩
  · show ((setAt Lnew d c.learners).getD 0 dfltLearner).tag = 2 ^ P.eHC
    rw [htag_all 0]
    exact h.root h0
  · show TagW P _ j (nev + 1) ((gridVal P.eHC ((setAt Lnew d c.learners).getD j dfltLearner).tag : ℚ) : ℝ)
    rw [htag_all j]
    exact (tagW_congr (h.tagW j hj) (by rfl) (hw j)).mono (Nat.le_succ nev)
  · show CacheW P _ j (nev + 1)
      ((gridVal P.eHP ((setAt Lnew d c.learners).getD j dfltLearner).cache : ℚ) : ℝ)
    by_cases hjd : j = d
    · rw [hjd, hget_d]
      exact wit_guard_cacheW h hd g hgv δ hLd hcache
    · rw [hget_ne j hjd]
      exact (cacheW_congr (h.cacheW j hj) (hEj j hjd) (hw j)).mono (Nat.le_succ nev)
  · show 0 ≤ ((setAt Lnew d c.learners).getD j dfltLearner).cache
    by_cases hjd : j = d
    · rw [hjd, hget_d]
      exact hcache0
    · rw [hget_ne j hjd]
      exact h.cacheNonneg j hj
  · show 0 ≤ ((setAt Lnew d c.learners).getD j dfltLearner).tag
    rw [htag_all j]
    exact h.tagNonneg j hj
  · show ((gridVal P.eHleaf leaf' : ℚ) : ℝ) = ‖(S.step P (.guard d g δ)).x P.H‖ ^ 2
    rw [hleaf, hxH, ← h.leafExact d rfl]
    rfl
  · cases hD

/-- The accumulator update of Step 3 is exact: `round_{h_leaf}(acc + δ²) = acc + δ²` (`δ` on the grid `h_g`,
`h_g² = 2^{-2e_{h_g}}` divisible by `h_leaf`). -/
theorem wit_leaf_guard_exact (P : StreamParams) (lf δm : ℤ) :
    gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHleaf lf + gridVal P.eHg δm ^ 2)) =
      gridVal P.eHleaf lf + gridVal P.eHg δm ^ 2 := by
  obtain ⟨e', he'⟩ : ∃ e', P.eHleaf = 2 * P.eHg + e' :=
    ⟨P.eHleaf - 2 * P.eHg, by have := eHg_two_le_eHleaf P; omega⟩
  apply gridVal_roundMant_exact P.eHleaf _ (lf + δm ^ 2 * 2 ^ e')
  unfold gridVal
  rw [he', pow_add, pow_mul']
  push_cast
  field_simp

/-- Step 3 at depth `d`, injected guard `δ = δm h_g`: the cache `round_{h_P}(P_d + δ²)` and the accumulator
`round_{h_leaf}(acc + δ²)`. -/
theorem witSide_guard {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (hd : d < P.H) (ht : c.t + 1 = S.t) {Ld : Learner} (hLd : c.learners[d]? = some Ld) (δm : ℤ)
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    WitSide P (.guards (d + 1))
      { c with
        learners := setAt { Ld with cache := roundMant P.eHP (gridVal P.eHP Ld.cache + gridVal P.eHg δm ^ 2) }
          d c.learners,
        leaf := roundMant P.eHleaf (gridVal P.eHleaf c.leaf + gridVal P.eHg δm ^ 2) }
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg δm : ℚ) : ℝ))) (nev + 1) := by
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  have hc0 : 0 ≤ Ld.cache := by
    rw [← hLdg]
    exact h.cacheNonneg d hd
  have hl0 : 0 ≤ c.leaf := h.leafNonneg rfl
  refine witSide_guard_gen h hd _ (wit_guard_idx ht hg) _ hLd ?_ ?_ ?_ ?_ ?_
  · rfl
  · exact wit_roundMant_nonneg _ (add_nonneg (wit_gridVal_nonneg _ hc0) (sq_nonneg _))
  · have := wit_round_err_hP (P := P) (gridVal P.eHP Ld.cache + gridVal P.eHg δm ^ 2)
    rw [Rat.cast_add, Rat.cast_pow] at this
    exact this
  · exact wit_roundMant_nonneg _ (add_nonneg (wit_gridVal_nonneg _ hl0) (sq_nonneg _))
  · rw [wit_leaf_guard_exact, Rat.cast_add, Rat.cast_pow]

/-- Step 3 at depth `d`, omitted guard (`δ = 0`): the residual and the input of the leaf do not change. -/
theorem witSide_guard_zero {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (g : Fin P.Dstar) {δ : ℝ} (hδ : δ = 0) :
    WitSide P (.guards (d + 1)) c (S.step P (.guard d g δ)) (nev + 1) := by
  subst hδ
  have hr : (S.step P (.guard d g 0)).r = S.r := by
    rw [Tree.TreeState.step_guard_r, zero_smul, sub_zero, Function.update_eq_self]
  have hw : ∀ D a, winProd (S.step P (.guard d g 0)) D a = winProd S D a := fun D a =>
    wit_winProd_eq_of_pws (fun L => pws_guard S D 1 L d g 0) a
  have hx : (S.step P (.guard d g 0)).x P.H = S.x P.H := by
    unfold Tree.TreeState.x
    rw [hr]
    rfl
  have hE : ∀ d', (S.step P (.guard d g 0)).E d' = S.E d' := by
    intro d'
    unfold Tree.TreeState.E
    rw [hr]
  refine ⟨h.root, fun d' hd' => ?_, fun d' hd' => ?_, h.cacheNonneg, h.tagNonneg, fun D _ => ?_,
    fun D hD => ?_, fun _ => h.leafNonneg rfl⟩
  · exact (tagW_congr (h.tagW d' hd') (by rfl) (hw d')).mono (Nat.le_succ nev)
  · exact (cacheW_congr (h.cacheW d' hd') (hE d') (hw d')).mono (Nat.le_succ nev)
  · rw [hx]
    exact h.leafExact d rfl
  · cases hD

/-- The range checks of Step 3: the new cache `P⁺ ≤ (1 + η/2^{12})E_d⁺ + drift ≤ 2V² + 1` and the new accumulator
`acc⁺ = ‖x_H⁺‖² ≤ V²` (vector bounds at the new moment). -/
theorem wit_guard_range {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.guards d) c S nev)
    (hd : d < P.H) (ht : c.t + 1 = S.t) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (hnev : nev + 1 ≤ P.T)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (δm : ℤ) (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar)
    {R' : Tree.Regs}
    (hT' : Tree.TreeInv P (.guards (d + 1)) R'
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg δm : ℚ) : ℝ)))) :
    inRangeA P (gridVal P.eHP (roundMant P.eHP (gridVal P.eHP Ld.cache + gridVal P.eHg δm ^ 2))) = true ∧
      inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHleaf c.leaf + gridVal P.eHg δm ^ 2))) =
        true := by
  have hW := witSide_guard h hd ht hLd δm hg
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  have hc0 : 0 ≤ Ld.cache := by
    rw [← hLdg]
    exact h.cacheNonneg d hd
  have hl0 : 0 ≤ c.leaf := h.leafNonneg rfl
  obtain ⟨-, hE, -, hxH⟩ := wit_vec_sq hT' hbox
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hfin : (2 : ℝ) * (P.V : ℝ) ^ 2 + 2 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
  constructor
  · have hround := wit_round_err_hP (P := P) (gridVal P.eHP Ld.cache + gridVal P.eHg δm ^ 2)
    rw [Rat.cast_add, Rat.cast_pow] at hround
    have hCW := wit_guard_cacheW h hd ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ (wit_guard_idx ht hg)
      ((gridVal P.eHg δm : ℚ) : ℝ) hLd hround
    have hprec := cachePrec_of hT' hCW hnev hd
    have hEd := hE d hd
    have hdrift := wit_cacheDrift_le_one P
    have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
    have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
    have hη : (P.eta : ℝ) / 2 ^ 12 ≤ 1 := by
      have : (P.eta : ℝ) / 2 ^ 12 ≤ (P.eta : ℝ) := div_le_self hη0 (by norm_num)
      linarith
    have hE0 : (0 : ℝ) ≤
        (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg δm : ℚ) : ℝ))).E d := by
      unfold Tree.TreeState.E
      positivity
    have b1 := mul_le_of_le_one_left hE0 hη
    have a1 := (abs_le.mp hprec).2
    apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _
      (add_nonneg (wit_gridVal_nonneg _ hc0) (sq_nonneg _))))
    linarith
  · have hex : ((gridVal P.eHleaf (roundMant P.eHleaf (gridVal P.eHleaf c.leaf + gridVal P.eHg δm ^ 2)) : ℚ) :
        ℝ) = ‖(S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg δm : ℚ) : ℝ))).x P.H‖ ^ 2 :=
      hW.leafExact (d + 1) rfl
    have hxH' := hxH rfl
    have hV2 : (0 : ℝ) ≤ (P.V : ℝ) ^ 2 := sq_nonneg _
    apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _
      (add_nonneg (wit_gridVal_nonneg _ hl0) (sq_nonneg _))))
    rw [hex]
    linarith

/-! ## Step 4 -/

/-- The end of Step 3 is the start of Step 4: the accumulator is `‖x_H‖²` exactly. -/
theorem witSide_startStep4 {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards P.H) c S nev) :
    WitSide P (.evals P.H) c S nev ∧ leafVal P c = ‖S.x P.H‖ ^ 2 := by
  have hex := h.leafExact P.H rfl
  refine ⟨⟨h.root, h.tagW, h.cacheW, h.cacheNonneg, h.tagNonneg, fun D hD => ?_, fun D _ => leafW_of_eq hex,
    fun _ => h.leafNonneg rfl⟩, hex⟩
  cases hD

/-- The end of Step 4: nothing changes (the moment becomes `idle`). -/
theorem witSide_endRound {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.evals 0) c S nev) :
    WitSide P .idle c S nev where
  root := h.root
  tagW := h.tagW
  cacheW := h.cacheW
  cacheNonneg := h.cacheNonneg
  tagNonneg := h.tagNonneg
  leafExact D hD := by cases hD
  leafW D hD := by cases hD
  leafNonneg hl := by simp [leafPhase] at hl

/-- Step 4 at depth `d`, `ACCEPT`: no shadow change except the outcome of the pending record. -/
theorem witSide_accept {c : CState} {S : Tree.TreeSt P} {nev d : ℕ} (h : TreePart P (.evals (d + 1)) c S nev)
    (hd : d < P.H) : WitSide P (.evals d) c (S.step P (.accept d)) (nev + 1) := by
  obtain ⟨e, l', hlog, -, hpend_iff, -⟩ := h.tree.log_phase d hd
  have hhead : ∀ e' ∈ (S.log d).head?, e'.out = .pending := by
    intro e' he'
    rw [hlog] at he'
    simp only [List.head?_cons, Option.mem_def, Option.some.injEq] at he'
    rw [← he']
    exact hpend_iff.mp (Nat.lt_succ_self d)
  have hw : ∀ D a, winProd (S.step P (.accept d)) D a = winProd S D a := fun D a =>
    wit_winProd_eq_of_pws (fun L => pws_accept S D 1 L d hhead) a
  have hx : (S.step P (.accept d)).x P.H = S.x P.H := rfl
  refine ⟨h.root, fun d' hd' => ?_, fun d' hd' => ?_, h.cacheNonneg, h.tagNonneg, fun D hD => ?_,
    fun D _ => ?_, fun _ => h.leafNonneg rfl⟩
  · exact (tagW_congr (h.tagW d' hd') (by rfl) (hw d')).mono (Nat.le_succ nev)
  · exact (cacheW_congr (h.cacheW d' hd') (by rfl) (hw d')).mono (Nat.le_succ nev)
  · cases hD
  · exact (leafW_congr (h.leafW (d + 1) rfl) hx (hw P.H)).mono (Nat.le_succ nev)

/-- The range check of `S = P_d + Q̂` before the validation of Step 4: `P_d ≤ (1 + η/2^{12})E_d + drift ≤ 2V² + 1`
and `Q̂ ≤ (1 + 8(H−d)η)‖x_{d+1}‖² ≤ 2V²`. -/
theorem wit_eval_range {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (hnev : nev ≤ P.T)
    {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) :
    inRangeA P (gridVal P.eHP Ld.cache + F) = true := by
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  have hc0 : 0 ≤ Ld.cache := by
    rw [← hLdg]
    exact h.cacheNonneg d hd
  obtain ⟨hx, hE, -, -⟩ := wit_vec_sq h.tree hbox
  have hprec : |((gridVal P.eHP Ld.cache : ℚ) : ℝ) - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P := by
    have := h.cachePrec hnev (d := d) hd
    unfold cacheVal at this
    rwa [hLdg] at this
  have hEd := hE d hd
  have hxd := hx (d + 1) (show d + 1 ≤ P.H by omega)
  have h8 := wit_eight_Hd_eta_le P d
  have hdrift := wit_cacheDrift_le_one P
  have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hη : (P.eta : ℝ) / 2 ^ 12 ≤ 1 := by
    have : (P.eta : ℝ) / 2 ^ 12 ≤ (P.eta : ℝ) := div_le_self hη0 (by norm_num)
    linarith
  have hE0 : 0 ≤ S.E d := by
    unfold Tree.TreeState.E
    positivity
  have b1 := mul_le_of_le_one_left hE0 hη
  have b2 := mul_le_of_le_one_left (sq_nonneg ‖S.x (d + 1)‖) h8
  have a1 := (abs_le.mp hprec).2
  have a2 := (abs_le.mp hF).2
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hfin : (4 : ℝ) * (P.V : ℝ) ^ 2 + 1 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
  apply wit_inRangeA_of_le (add_nonneg (wit_gridVal_nonneg _ hc0) hF0)
  rw [Rat.cast_add]
  linarith

/-- The range check of the release `N₁ ≥ 0` of `x_d` (rejection branch): `N₁ ≤ (1 + 2^{-13}η)‖x_d‖² + ω ≤ 2V² + 1`. -/
theorem wit_N1_range {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ))
    (N1 : ℚ) (hN0 : 0 ≤ N1) (hN : NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N1 : ℝ)) :
    inRangeA P N1 = true := by
  obtain ⟨hx, -, -, -⟩ := wit_vec_sq h.tree hbox
  have hxd := hx d (show d ≤ P.H by omega)
  unfold NumCert at hN
  have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hω1 : (P.omega : ℝ) ≤ 1 := by exact_mod_cast P.omega_le_one
  have h13 : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) ≤ 1 := by
    have : (1 / 2 : ℝ) ^ 13 ≤ 1 := by norm_num
    nlinarith
  have hb := mul_le_of_le_one_left (sq_nonneg ‖S.x d‖) h13
  have a := (abs_le.mp hN).2
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hfin : (2 : ℝ) * (P.V : ℝ) ^ 2 + 1 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
  apply wit_inRangeA_of_le hN0
  linarith

/-- The multiplier mantissa is nonnegative when `c = cInt h_step ≥ 1/2`. -/
theorem wit_cInt_nonneg {cInt : ℤ} (hc : (1 / 2 : ℝ) ≤ ((gridVal P.eHstep cInt : ℚ) : ℝ)) : 0 ≤ cInt := by
  by_contra hneg0
  have hneg : cInt < 0 := not_le.mp hneg0
  have h1 : gridVal P.eHstep cInt < 0 := by
    unfold gridVal
    apply div_neg_of_neg_of_pos
    · exact_mod_cast hneg
    · positivity
  have h2 : ((gridVal P.eHstep cInt : ℚ) : ℝ) < 0 := by exact_mod_cast h1
  linarith

/-- The residual after a correction of depth `d` by `c`: `r_d⁺ = x_d − c y_d` (Lemma 5.4 (i)). -/
theorem wit_r_correct (S : Tree.TreeSt P) (d : ℕ) (c : ℝ) :
    (S.step P (.correct d c)).r d = S.x d - c • S.y d := by
  rw [(Tree.TreeState.correct_rescale P S d c).1, ← Tree.TreeState.r_add_y S d, sub_smul, one_smul]
  abel

/-- The rescaled tag `round_{h_C}(c Ĉ)`: rounding error `≤ h_C`. -/
theorem wit_rescale_tag_err (c : CState) (cInt : ℤ) (j : ℕ) :
    |((gridVal P.eHC (Learner.rescale P cInt (c.learners.getD j dfltLearner)).tag : ℚ) : ℝ) -
      ((gridVal P.eHstep cInt : ℚ) : ℝ) * tagVal P c j| ≤ (P.hC : ℝ) := by
  have h1 := wit_round_err_hC (P := P)
    (gridVal P.eHstep cInt * gridVal P.eHC (c.learners.getD j dfltLearner).tag)
  rw [Rat.cast_mul] at h1
  show |((gridVal P.eHC (scaleMant P.eHstep cInt (c.learners.getD j dfltLearner).tag) : ℚ) : ℝ) - _| ≤ _
  rw [wit_scaleMant_eq_roundMant P.eHC]
  exact h1

/-- The rescaled cache `round_{h_P}(c² P)`: rounding error `≤ h_P`. -/
theorem wit_rescale_cache_err (c : CState) (cInt : ℤ) (j : ℕ) :
    |((gridVal P.eHP (Learner.rescale P cInt (c.learners.getD j dfltLearner)).cache : ℚ) : ℝ) -
      ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 * cacheVal P c j| ≤ (P.hP : ℝ) := by
  have h1 := wit_round_err_hP (P := P)
    (gridVal (2 * P.eHstep) (cInt ^ 2) * gridVal P.eHP (c.learners.getD j dfltLearner).cache)
  rw [wit_gridVal_sq, Rat.cast_mul, Rat.cast_pow] at h1
  show |((gridVal P.eHP (scaleMant (2 * P.eHstep) (cInt ^ 2) (c.learners.getD j dfltLearner).cache) : ℚ) :
    ℝ) - _| ≤ _
  rw [wit_scaleMant_eq_roundMant P.eHP, wit_gridVal_sq]
  exact h1

/-- **Step 4 at depth `d`, rejection, the correction** (Theorem 5.9 (3), Lemma 5.4, Lemma 6.1 (ii), Lemma 6.2,
Lemma 5.3): the analysis event `correct d c` (`c = cInt h_step ≥ 1/2`); the strict descendants' tags and caches are
rescaled (`|Ĉ⁺ − cĈ| ≤ h_C`, `|P⁺ − c²P| ≤ h_P`), the accumulator becomes `round_{h_leaf}(c² acc)`, and the cache of
depth `d` is refreshed by the release `N₂` of `r_d⁺` (`DIFF`, a fresh measurement), with the counters of
`countCorrection`. -/
theorem witSide_reject {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    {cInt : ℤ} (hc : (1 / 2 : ℝ) ≤ ((gridVal P.eHstep cInt : ℚ) : ℝ)) {N2 : ℚ} (hN0 : 0 ≤ N2)
    (hN2 : NumCert (P.eta : ℝ) (P.omega : ℝ)
      (‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2) (N2 : ℝ))
    {Ld' : Learner} (hLd' : Learner.countCorrection P { Ld with cache := roundMant P.eHP N2 } = some Ld') :
    WitSide P (.evals d)
      { c with
        learners := setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners),
        leaf := roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf) }
      (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) (nev + 1) := by
  have hlen : c.learners.length = P.H := h.nLearners
  have hLdg : c.learners.getD d dfltLearner = Ld := wit_getD_of_getElem? hLd
  obtain ⟨htagL, hcacheL⟩ := wit_countCorrection_tag_cache hLd'
  have htagL' : Ld'.tag = Ld.tag := htagL
  have hcacheL' : Ld'.cache = roundMant P.eHP N2 := hcacheL
  have hcInt : 0 ≤ cInt := wit_cInt_nonneg hc
  obtain ⟨e, l', hlog, het, hpend_iff, hrest⟩ := h.tree.log_phase d hd
  have hpend : e.out = .pending := hpend_iff.mp (Nat.lt_succ_self d)
  have hl : ∀ e' ∈ l', e'.t < S.t := fun e' he' => (hrest e' he').1
  have hMlen : (mapFrom (Learner.rescale P cInt) (d + 1) c.learners).length = P.H := by
    rw [length_mapFrom, hlen]
  have hget_lt : ∀ j, j < d →
      (setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner =
        c.learners.getD j dfltLearner := fun j hj => by
    rw [wit_getD_setAt_ne _ _ _ (by omega), wit_getD_mapFrom_lt _ _ _ (by omega)]
  have hget_d :
      (setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD d dfltLearner = Ld' :=
    wit_getD_setAt_self _ _ _ (by rw [hMlen]; exact hd)
  have hget_gt : ∀ j, d < j → j < P.H →
      (setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner =
        Learner.rescale P cInt (c.learners.getD j dfltLearner) := fun j hj hjH => by
    rw [wit_getD_setAt_ne _ _ _ (by omega),
      wit_getD_mapFrom_ge _ _ _ (by omega) (by rw [hlen]; exact hjH)]
  have hw_le : ∀ D, D ≤ d → ∀ a,
      winProd (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))) D a = winProd S D a :=
    fun D hD a => wit_winProd_eq_of_pws (fun L => pws_correct_ge S D 1 L hD _) a
  have hC_le : ∀ j, j ≤ d → (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).C j = S.C j :=
    fun j hj => by
      rw [Tree.TreeState.step_correct_C, if_neg (by omega)]
  have hE_lt : ∀ j, j < d → (S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).E j = S.E j :=
    fun j hj => by
      unfold Tree.TreeState.E
      rw [Tree.TreeState.step_correct_r, if_neg (by omega), if_neg (by omega)]
  refine ⟨fun _ => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun j hj => ?_, fun D hD => ?_,
    fun D hD => ?_, fun _ => ?_⟩
  · -- the root tag
    show ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD 0 dfltLearner).tag =
      2 ^ P.eHC
    rcases Nat.eq_zero_or_pos d with hd0 | hd0
    · subst hd0
      rw [hget_d, htagL', ← hLdg]
      exact h.root hd
    · rw [hget_lt 0 hd0]
      exact h.root (show 0 < P.H by omega)
  · -- tags
    have hjH : j < P.H := hj
    show TagW P _ j (nev + 1) ((gridVal P.eHC
      ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner).tag : ℚ) : ℝ)
    rcases lt_trichotomy j d with hjd | hjd | hjd
    · rw [hget_lt j hjd]
      exact (tagW_congr (h.tagW j hjH) (hC_le j hjd.le) (hw_le j hjd.le)).mono (Nat.le_succ nev)
    · rw [hjd, hget_d, htagL', ← hLdg]
      exact (tagW_congr (h.tagW d hd) (hC_le d le_rfl) (hw_le d le_rfl)).mono (Nat.le_succ nev)
    · rw [hget_gt j hjd hjH]
      exact tagW_correct_lt (h.tagW j hjH) hjd hlog het hpend hl (wit_rescale_tag_err c cInt j)
  · -- caches
    have hjH : j < P.H := hj
    show CacheW P _ j (nev + 1) ((gridVal P.eHP
      ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner).cache : ℚ) : ℝ)
    rcases lt_trichotomy j d with hjd | hjd | hjd
    · rw [hget_lt j hjd]
      exact (cacheW_congr (h.cacheW j hjH) (hE_lt j hjd) (hw_le j hjd.le)).mono (Nat.le_succ nev)
    · rw [hjd, hget_d, hcacheL']
      apply cacheW_fresh
      have h1 := wit_round_err_hP (P := P) N2
      unfold NumCert at hN2
      unfold Tree.TreeState.E
      calc |((gridVal P.eHP (roundMant P.eHP N2) : ℚ) : ℝ) -
            ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2|
          ≤ |((gridVal P.eHP (roundMant P.eHP N2) : ℚ) : ℝ) - (N2 : ℝ)| +
              |(N2 : ℝ) - ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2| :=
            abs_sub_le _ _ _
        _ ≤ (P.hP : ℝ) + ((1 / 2) ^ 13 * (P.eta : ℝ) *
              ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2 + (P.omega : ℝ)) :=
            add_le_add h1 hN2
        _ = (1 / 2) ^ 13 * (P.eta : ℝ) * ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2 +
              (P.omega : ℝ) + (P.hP : ℝ) := by ring
    · rw [hget_gt j hjd hjH]
      exact cacheW_correct_lt (h.cacheW j hjH) hjd hlog het hpend hl (wit_rescale_cache_err c cInt j)
  · -- caches are nonnegative
    have hjH : j < P.H := hj
    show 0 ≤ ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner).cache
    rcases lt_trichotomy j d with hjd | hjd | hjd
    · rw [hget_lt j hjd]
      exact h.cacheNonneg j hjH
    · rw [hjd, hget_d, hcacheL']
      exact wit_roundMant_nonneg _ hN0
    · rw [hget_gt j hjd hjH]
      exact wit_scaleMant_nonneg _ (sq_nonneg cInt) (h.cacheNonneg j hjH)
  · -- tags are nonnegative
    have hjH : j < P.H := hj
    show 0 ≤ ((setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) c.learners)).getD j dfltLearner).tag
    rcases lt_trichotomy j d with hjd | hjd | hjd
    · rw [hget_lt j hjd]
      exact h.tagNonneg j hjH
    · rw [hjd, hget_d, htagL', ← hLdg]
      exact h.tagNonneg d hd
    · rw [hget_gt j hjd hjH]
      exact wit_scaleMant_nonneg _ hcInt (h.tagNonneg j hjH)
  · cases hD
  · -- the accumulator
    show LeafW P _ (nev + 1) ((gridVal P.eHleaf (roundMant P.eHleaf
      (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf)) : ℚ) : ℝ)
    have h1 := wit_round_err_hleaf (P := P) (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf)
    rw [Rat.cast_mul, Rat.cast_pow] at h1
    exact leafW_correct_lt (h.leafW (d + 1) rfl) hd hlog het hpend hl h1
  · show 0 ≤ roundMant P.eHleaf (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf)
    exact wit_roundMant_nonneg _ (mul_nonneg (sq_nonneg _) (wit_gridVal_nonneg _ (h.leafNonneg rfl)))

/-- **The range checks of the rejection branch** (all from the moment before the correction, `c ∈ [1/2, 3/2]`):
the rescaled tags `≤ (3/2)(B^{H-1}+e_C) + h_C ≤ 8(B^H+1) ≤ C_max`, the rescaled caches
`≤ (9/4)(2V²+1) + h_P ≤ A_max`, the rescaled accumulator `≤ (9/4)(V² + TG²h_leaf) + h_leaf ≤ A_max`, and the refreshed
cache `round_{h_P}(N₂) ≤ (1 + 2^{-13}η)‖x_d − c y_d‖² + ω + h_P ≤ 2V² + 2 ≤ A_max`. -/
theorem wit_reject_range {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (hnev : nev ≤ P.T)
    {cInt : ℤ} (hc1 : (1 / 2 : ℝ) ≤ ((gridVal P.eHstep cInt : ℚ) : ℝ))
    (hc2 : ((gridVal P.eHstep cInt : ℚ) : ℝ) ≤ 3 / 2) :
    ((mapFrom (Learner.rescale P cInt) (d + 1) c.learners).drop (d + 1)).all (Learner.inRange P) = true ∧
      inRangeA P (gridVal P.eHleaf (roundMant P.eHleaf
        (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf))) = true ∧
      ∀ N2 : ℚ, 0 ≤ N2 →
        NumCert (P.eta : ℝ) (P.omega : ℝ)
          (‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2) (N2 : ℝ) →
        inRangeA P (gridVal P.eHP (roundMant P.eHP N2)) = true := by
  obtain ⟨hx, hE, hxcy, hxH⟩ := wit_vec_sq h.tree hbox
  have hlen : c.learners.length = P.H := h.nLearners
  have hcInt : 0 ≤ cInt := wit_cInt_nonneg hc1
  have hV0 : (0 : ℝ) ≤ (P.V : ℝ) := Nat.cast_nonneg _
  have hη0 : (0 : ℝ) ≤ (P.eta : ℝ) := by exact_mod_cast P.eta_pos.le
  have hη1 : (P.eta : ℝ) ≤ 1 := by exact_mod_cast P.eta_le_one
  have hω1 : (P.omega : ℝ) ≤ 1 := by exact_mod_cast P.omega_le_one
  have hhP1 : (P.hP : ℝ) ≤ 1 := by exact_mod_cast P.hP_le_one
  have hhC1 : (P.hC : ℝ) ≤ 1 := by exact_mod_cast P.hC_le_one
  have hhl1 : (P.hleaf : ℝ) ≤ 1 := by exact_mod_cast P.hleaf_le_one
  have heC1 : (P.eC : ℝ) ≤ 1 := by
    have h1 : P.eC ≤ 1 := le_trans P.eC_le (by norm_num)
    exact_mod_cast h1
  have hdrift := wit_cacheDrift_le_one P
  have hη : (P.eta : ℝ) / 2 ^ 12 ≤ 1 := by
    have : (P.eta : ℝ) / 2 ^ 12 ≤ (P.eta : ℝ) := div_le_self hη0 (by norm_num)
    linarith
  have hcr0 : (0 : ℝ) ≤ ((gridVal P.eHstep cInt : ℚ) : ℝ) := by linarith
  have hcr2 : ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 ≤ 9 / 4 := by nlinarith
  refine ⟨?_, ?_, fun N2 hN0 hN2 => ?_⟩
  · -- the rescaled learners
    rw [List.all_eq_true]
    intro x hx'
    obtain ⟨j, hj1, hj2, rfl⟩ := wit_mem_drop_mapFrom _ _ _ hx'
    rw [hlen] at hj2
    unfold Learner.inRange
    rw [Bool.and_eq_true]
    constructor
    · apply wit_inRangeC_of_le (wit_gridVal_nonneg _ (wit_scaleMant_nonneg _ hcInt (h.tagNonneg j hj2)))
      show ((gridVal P.eHC (Learner.rescale P cInt (c.learners.getD j dfltLearner)).tag : ℚ) : ℝ) ≤ _
      have hprec := h.tagPrec hnev (d := j) hj2
      have hCj := (Tree.C_le_B_pow h.tree (d := j) hj2).2
      have hround := wit_rescale_tag_err (P := P) c cInt j
      have hT0 : (0 : ℝ) ≤ tagVal P c j := by
        unfold tagVal
        exact_mod_cast wit_gridVal_nonneg _ (h.tagNonneg j hj2)
      have hB1 : (1 : ℝ) ≤ (P.B : ℝ) := (Tree.B_eq_and_gt P).2.le
      have hBj : (P.B : ℝ) ^ j ≤ (P.B : ℝ) ^ P.H := pow_le_pow_right₀ hB1 hj2.le
      have hB0 : (0 : ℝ) ≤ (P.B : ℝ) ^ P.H := pow_nonneg (by linarith) _
      have hcT : ((gridVal P.eHstep cInt : ℚ) : ℝ) * tagVal P c j ≤ 3 / 2 * tagVal P c j :=
        mul_le_mul_of_nonneg_right hc2 hT0
      have a1 := (abs_le.mp hround).2
      have a2 := (abs_le.mp hprec).2
      linarith
    · apply wit_inRangeA_of_le (wit_gridVal_nonneg _
        (wit_scaleMant_nonneg _ (sq_nonneg cInt) (h.cacheNonneg j hj2)))
      show ((gridVal P.eHP (Learner.rescale P cInt (c.learners.getD j dfltLearner)).cache : ℚ) : ℝ) ≤ _
      have hprec := h.cachePrec hnev (d := j) hj2
      have hEj := hE j hj2
      have hround := wit_rescale_cache_err (P := P) c cInt j
      have hP0 : (0 : ℝ) ≤ cacheVal P c j := by
        unfold cacheVal
        exact_mod_cast wit_gridVal_nonneg _ (h.cacheNonneg j hj2)
      have hE0 : 0 ≤ S.E j := by
        unfold Tree.TreeState.E
        positivity
      have b1 := mul_le_of_le_one_left hE0 hη
      have a1 := (abs_le.mp hround).2
      have a2 := (abs_le.mp hprec).2
      have hPle : cacheVal P c j ≤ 2 * (P.V : ℝ) ^ 2 + 1 := by linarith
      have hcP : ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 * cacheVal P c j ≤ 9 / 4 * (2 * (P.V : ℝ) ^ 2 + 1) :=
        calc ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 * cacheVal P c j ≤ 9 / 4 * cacheVal P c j :=
              mul_le_mul_of_nonneg_right hcr2 hP0
          _ ≤ 9 / 4 * (2 * (P.V : ℝ) ^ 2 + 1) := by linarith
      have hfin : 9 / 4 * (2 * (P.V : ℝ) ^ 2 + 1) + 1 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
      linarith
  · -- the rescaled accumulator
    have hl0 : 0 ≤ c.leaf := h.leafNonneg rfl
    apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _
      (mul_nonneg (sq_nonneg _) (wit_gridVal_nonneg _ hl0))))
    have hround := wit_round_err_hleaf (P := P) (gridVal P.eHstep cInt ^ 2 * gridVal P.eHleaf c.leaf)
    rw [Rat.cast_mul, Rat.cast_pow] at hround
    have hprec : |((gridVal P.eHleaf c.leaf : ℚ) : ℝ) - ‖S.x P.H‖ ^ 2| ≤
        (P.T : ℝ) * (P.G : ℝ) ^ 2 * (P.hleaf : ℝ) :=
      leafPrec_of h.tree rfl (h.leafW (d + 1) rfl) hnev
    have hbud := wit_T_G_sq_hleaf_le P
    have hxH' := hxH rfl
    have hlf0 : (0 : ℝ) ≤ ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) := by
      exact_mod_cast wit_gridVal_nonneg _ hl0
    have a1 := (abs_le.mp hround).2
    have a2 := (abs_le.mp hprec).2
    have hlf : ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) ≤ (P.V : ℝ) ^ 2 + 1 := by linarith
    have hcl : ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 * ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) ≤
        9 / 4 * ((P.V : ℝ) ^ 2 + 1) :=
      calc ((gridVal P.eHstep cInt : ℚ) : ℝ) ^ 2 * ((gridVal P.eHleaf c.leaf : ℚ) : ℝ)
          ≤ 9 / 4 * ((gridVal P.eHleaf c.leaf : ℚ) : ℝ) := mul_le_mul_of_nonneg_right hcr2 hlf0
        _ ≤ 9 / 4 * ((P.V : ℝ) ^ 2 + 1) := by linarith
    have hfin : 9 / 4 * ((P.V : ℝ) ^ 2 + 1) + 1 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
    linarith
  · -- the refreshed cache of depth `d`
    apply wit_inRangeA_of_le (wit_gridVal_nonneg _ (wit_roundMant_nonneg _ hN0))
    have hround := wit_round_err_hP (P := P) N2
    unfold NumCert at hN2
    have hr' : ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖ ^ 2 ≤ (P.V : ℝ) ^ 2 := by
      rw [wit_r_correct]
      exact hxcy d hd _ (abs_le.mpr ⟨by linarith, hc2⟩)
    have h13 : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) ≤ 1 := by
      have : (1 / 2 : ℝ) ^ 13 ≤ 1 := by norm_num
      nlinarith
    have hb := mul_le_of_le_one_left
      (sq_nonneg ‖(S.step P (.correct d ((gridVal P.eHstep cInt : ℚ) : ℝ))).r d‖) h13
    have a1 := (abs_le.mp hround).2
    have a2 := (abs_le.mp hN2).2
    have hfin : (2 : ℝ) * (P.V : ℝ) ^ 2 + 2 ≤ 16 * ((P.V : ℝ) + 1) ^ 2 := by nlinarith
    linarith

end F2e2e.C.Closure
