import F2e2e.C.ClosureProbStreams
import F2e2e.C.ClosureProbLabelsAux

/-!
# Theorem 6.4, probability layer (C-PROB): bank labels

Paper: `parts/partIII.tex` L1281–1285 ("At most `2m(H+1)` bank labels can ever be born, and their birth schedule is
independent of corrections"); Definition `R:def:binary-tree-architecture` (2), L432 (the outgoing bank of a depth-`d`
learner born at round `tr`); Algorithm `R:alg:regularized-norm-bank` L206 (`R_max` reserved coarse groups).

From the controller code (C-ALG's `initCode`, `roundCode`, `F2e2e/C/Alg/AlgMCode.lean`): `bankNew 0 0` at
initialization and `bankNew (t+1) d` with `d + 2 ≤ H` in round `t` (distinct `d`), so every born label lies in
`labelSet P = {(0,0)} ∪ [1, m] × [0, H-2]` and is born at most once. Consequently, on the instrumented canonical run:
* `call_lab_mem`: every bank call is on a label of `labelSet P`;
* `adaGood_of_not_mem`, `coarseGood_of_not_mem`: the events of labels outside `labelSet P` hold trivially;
* `length_coarseRecs_le`, `coarseGood_of_le`: at most `R_max` releases of a bank consume a coarse group, so the coarse
  events with `k ≥ R_max` hold trivially;
* `card_labelSet_le`: `|labelSet P| ≤ 2m(H+1)`.

The invariant behind these (labels parallel to the banks, every label in `labelSet P` and lexicographically below
the next label to be born, and the coarse-group count per label) is `LabInv`
(`F2e2e/C/ClosureProbLabelsAux.lean`, `run_labInv`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top

/-- The bank labels that can be born: the root `(0, 0)` and `(tr, d)` with `1 ≤ tr ≤ m`, `d + 2 ≤ H`. -/
def labelSet (P : StreamParams) : Finset BankLabel :=
  insert (0, 0) (Finset.Icc 1 P.m ×ˢ Finset.range (P.H - 1))

/-- `|labelSet P| ≤ 1 + m(H-1) ≤ 2m(H+1)` (partIII.tex L1281). -/
theorem card_labelSet_le (P : StreamParams) (hm : 1 ≤ P.m) :
    (labelSet P).card ≤ 2 * P.m * (P.H + 1) := by
  unfold labelSet
  calc (insert (0, 0) (Finset.Icc 1 P.m ×ˢ Finset.range (P.H - 1))).card
      ≤ (Finset.Icc 1 P.m ×ˢ Finset.range (P.H - 1)).card + 1 := Finset.card_insert_le _ _
    _ = P.m * (P.H - 1) + 1 := by
      rw [Finset.card_product, Nat.card_Icc, Finset.card_range, Nat.add_sub_cancel]
    _ ≤ 2 * P.m * (P.H + 1) := by
      have h1 : P.m * (P.H - 1) ≤ P.m * (P.H + 1) := Nat.mul_le_mul_left _ (by omega)
      have h2 : 1 ≤ P.m * (P.H + 1) := Nat.one_le_iff_ne_zero.mpr (by positivity)
      nlinarith

theorem mem_labelSet_of (P : StreamParams) {tr d : ℕ} (h1 : 1 ≤ tr) (h2 : tr ≤ P.m) (h3 : d + 2 ≤ P.H) :
    (tr, d) ∈ labelSet P := by
  unfold labelSet
  refine Finset.mem_insert_of_mem (Finset.mem_product.mpr ⟨?_, ?_⟩)
  · exact Finset.mem_Icc.mpr ⟨h1, h2⟩
  · exact Finset.mem_range.mpr (by simp only; omega)

theorem zero_mem_labelSet (P : StreamParams) : ((0, 0) : BankLabel) ∈ labelSet P :=
  Finset.mem_insert_self _ _

/-- The label invariant on the final configuration of the instrumented canonical run. -/
theorem labInv_final (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) :
    LabInv P (· ∈ labelSet P) (P.m + 1, 0) c.1.1.orc c.1.2 :=
  (run_labInv P (· ∈ labelSet P) (zero_mem_labelSet P)
    (fun _ _ h1 h2 h3 => mem_labelSet_of P h1 h2 h3) adv tapes P.m c hc le_rfl).1

/-- Every bank call of the instrumented canonical run is on a label of `labelSet P`. -/
theorem call_lab_mem (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) : ∀ rec ∈ c.1.2.calls, rec.lab ∈ labelSet P :=
  fun rec hr => ((labInv_final P adv tapes c hc).calls_mem rec hr).1

/-- At most `R_max` releases of a bank consume a reserved coarse group. -/
theorem length_coarseRecs_le (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) (lab : BankLabel) :
    (coarseRecs lab c.1.2).length ≤ P.Rmax :=
  le_trans (Nat.le_add_right _ _) ((labInv_final P adv tapes c hc).count lab)

/-- The calls of a label outside `labelSet P`: none. -/
theorem coarseRecs_eq_nil_of_not_mem (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) (lab : BankLabel) (hlab : lab ∉ labelSet P) :
    coarseRecs lab c.1.2 = [] := by
  unfold coarseRecs
  rw [List.filter_eq_nil_iff]
  intro rec hr
  have hne : rec.lab ≠ lab := fun h => hlab (h ▸ call_lab_mem P adv tapes c hc rec hr)
  simp [hne]

/-- The ADA event of a label that is never born holds trivially (empty transcript). -/
theorem adaGood_of_not_mem (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) (lab : BankLabel) (hlab : lab ∉ labelSet P) :
    AdaGood P lab c.1.2 := by
  have hnil : adaTranscript P lab c.1.2 = [] := by
    unfold adaTranscript
    rw [List.filterMap_eq_nil_iff]
    intro rec hr
    have hne : rec.lab ≠ lab := fun h => hlab (h ▸ call_lab_mem P adv tapes c hc rec hr)
    simp [hne]
  unfold AdaGood coreFails
  rw [hnil]
  simp

/-- The coarse events of a label that is never born, and of group indices `k ≥ R_max`, hold trivially. -/
theorem coarseGood_of_not_mem (P : StreamParams) (adv : StreamAdversary P.n)
    (tapes : Fin (P.m + 1) → Fin (tapeBits P) → Bool) (c : (State × Ghost) × List ℚ)
    (hc : theAlgL.run P adv tapes P.m = some c) (lab : BankLabel) (k : ℕ)
    (h : lab ∉ labelSet P ∨ P.Rmax ≤ k) : CoarseGood P lab k c.1.2 := by
  have hnone : (coarseRecs lab c.1.2)[k]? = none := by
    rcases h with h | h
    · rw [coarseRecs_eq_nil_of_not_mem P adv tapes c hc lab h]
      rfl
    · exact List.getElem?_eq_none_iff.mpr (le_trans (length_coarseRecs_le P adv tapes c hc lab) h)
  intro rec hrec
  rw [hnone] at hrec
  exact absurd hrec (by simp)

end F2e2e.C.Closure
