import F2e2e.C.SpaceDefs

/-!
# Lemma 6.3 (`R:lem:bit-length-accounting`): the invariant through every sub-step of a round

`parts/partIII.tex` L1259–1261 ("this is a worst-case bound: samplers have finite loop caps, scores
have deterministic correction caps, rows are silently saturated, protected scalars have explicit
ranges, and all failures enter an absorbing state"), for C-ALG's algorithm
(`F2e2e/C/Alg/Round.lean`) and the bounds of `F2e2e/C/SpaceDefs.lean`:

* component lemmas: rows stay `RowOK` under every row operation (saturation, partIII.tex L451);
  banks stay `BankOK` under `mapRows` (`BankOK.addPhys`, `resetY`, `addGuardY`, `addGuardXY`,
  `scaleY`, `scaleXY`), `validate` and `release` (given `AdaInvariant`); fresh banks are `BankOK`
  (`always_newBank`); learners: `LearnerOK.mono`, `LearnerOK.rescale` (ranges grow by at most `4`),
  `LearnerOK.countCorrection`, `newLearner_ok`;
* every sub-step of a round preserves `StateOK P adaOK c` for every `c ≥ 1` (`step2_ok`,
  `step3Depth_ok`, `step3Loop_ok`, `step3_ok`, `birthDepth_ok`, `birthLoop_ok`, `step1_ok`,
  `rejectTail_ok`, `rejectDepth_ok`, `step4Depth_ok`, `step4Loop_ok`, `step4_ok`, `roundStep_ok`;
  `algInit_ok` for the initialization) and the invariant `StateInv` (`step2_inv`, …,
  `finishRound_inv`), on every path of fresh bits and for every update (no box promise is needed).
  With C-ALG's `Round.lean` every reachable state even satisfies the exact ranges (`StateOK 1`):
  rescaled learners and accumulators are range-checked before they are stored;
* the every-path calculus `always_and`.

Generic helpers (lists, samplers, numerical facts) are in the namespace `F2e2e.C.Space.Aux`.
-/

namespace F2e2e.C.Space

open F2e2e StreamParams F2e2e.C.Alg F2e2e.B F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; without this, `whnf` tries to evaluate the parameters
(`P.w`, `P.s`, `P.Amax`, …) symbolically and elaboration explodes. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Every-path calculus -/

/-- Two every-path properties hold jointly. -/
theorem always_and {α : Type} {Q R : α → Prop} :
    ∀ {p : BitProg α}, Always p Q → Always p R → Always p (fun a => Q a ∧ R a)
  | BitProg.pure _, hQ, hR => ⟨hQ, hR⟩
  | BitProg.bit _, hQ, hR => fun b => always_and (hQ b) (hR b)

namespace Aux

/-! ## List helpers -/

theorem forall_mem_modifyAt {α : Type} {Q : α → Prop} (f : α → α) (hf : ∀ a, Q a → Q (f a)) :
    ∀ (k : ℕ) (l : List α), (∀ a ∈ l, Q a) → ∀ a ∈ modifyAt f k l, Q a
  | _, [], _ => by simp [modifyAt]
  | 0, b :: l, h => by
    intro a ha
    simp only [modifyAt, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact hf _ (h b List.mem_cons_self)
    · exact h a (List.mem_cons_of_mem _ ha)
  | k + 1, b :: l, h => by
    intro a ha
    simp only [modifyAt, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact h _ List.mem_cons_self
    · exact forall_mem_modifyAt f hf k l (fun x hx => h x (List.mem_cons_of_mem _ hx)) a ha

theorem forall_mem_setAt {α : Type} {Q : α → Prop} (b : α) (hb : Q b) :
    ∀ (k : ℕ) (l : List α), (∀ a ∈ l, Q a) → ∀ a ∈ setAt b k l, Q a
  | _, [], _ => by simp [setAt]
  | 0, c :: l, h => by
    intro a ha
    simp only [setAt, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact hb
    · exact h a (List.mem_cons_of_mem _ ha)
  | k + 1, c :: l, h => by
    intro a ha
    simp only [setAt, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact h _ List.mem_cons_self
    · exact forall_mem_setAt b hb k l (fun x hx => h x (List.mem_cons_of_mem _ hx)) a ha

theorem forall_mem_mapFrom {α : Type} {Q : α → Prop} (f : α → α) (hf : ∀ a, Q a → Q (f a)) :
    ∀ (k : ℕ) (l : List α), (∀ a ∈ l, Q a) → ∀ a ∈ mapFrom f k l, Q a
  | _, [], _ => by simp [mapFrom]
  | 0, c :: l, h => by
    intro a ha
    simp only [mapFrom, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact hf _ (h c List.mem_cons_self)
    · exact forall_mem_mapFrom f hf 0 l (fun x hx => h x (List.mem_cons_of_mem _ hx)) a ha
  | k + 1, c :: l, h => by
    intro a ha
    simp only [mapFrom, List.mem_cons] at ha
    rcases ha with rfl | ha
    · exact h _ List.mem_cons_self
    · exact forall_mem_mapFrom f hf k l (fun x hx => h x (List.mem_cons_of_mem _ hx)) a ha

theorem take_mapFrom {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (mapFrom f k l).take k = l.take k
  | _, [] => by simp [mapFrom]
  | 0, _ :: _ => by simp
  | k + 1, c :: l => by simp [mapFrom, take_mapFrom f k l]

theorem mapFrom_zero {α : Type} (f : α → α) : ∀ l : List α, mapFrom f 0 l = l.map f
  | [] => rfl
  | c :: l => by simp [mapFrom, mapFrom_zero f l]

theorem drop_mapFrom {α : Type} (f : α → α) :
    ∀ (k : ℕ) (l : List α), (mapFrom f k l).drop k = (l.drop k).map f
  | _, [] => by simp [mapFrom]
  | 0, c :: l => by simp [mapFrom_zero]
  | k + 1, c :: l => by simp [mapFrom, drop_mapFrom f k l]

/-- The entries of `mapFrom f k l` are entries of `l` or images under `f` of the entries of
`l.drop k`. -/
theorem forall_mem_mapFrom_of_drop {α : Type} {Q : α → Prop} (f : α → α) (k : ℕ) (l : List α)
    (hl : ∀ a ∈ l, Q a) (hd : ∀ a ∈ (l.drop k).map f, Q a) : ∀ a ∈ mapFrom f k l, Q a := by
  intro a ha
  rw [← List.take_append_drop k (mapFrom f k l), List.mem_append, take_mapFrom,
    drop_mapFrom] at ha
  rcases ha with ha | ha
  · exact hl a (List.mem_of_mem_take ha)
  · exact hd a ha

/-! ## Numerical facts -/

theorem zSat_nonneg (P : StreamParams) : 0 ≤ zSat P := by unfold zSat; positivity

theorem abs_sat_le {Z : ℤ} (hZ : 0 ≤ Z) (z : ℤ) : |sat Z z| ≤ Z := by
  unfold sat
  rw [abs_le]
  constructor
  · exact le_max_left _ _
  · exact max_le (by linarith) (min_le_left _ _)

theorem q_pos (P : StreamParams) : 0 < P.q := (Nat.find_spec (exists_prime_ge P.Mq)).2.pos

theorem one_le_Cmax (P : StreamParams) : 1 ≤ P.Cmax := Nat.one_le_two_pow

theorem one_le_Amax (P : StreamParams) : 1 ≤ P.Amax := Nat.one_le_two_pow

theorem K0_pos (P : StreamParams) : 0 < P.K0 := by unfold K0; positivity

theorem inRangeA_gridVal {P : StreamParams} {q : ℕ} {m : ℤ} (h : inRangeA P (gridVal q m) = true) :
    0 ≤ m ∧ m ≤ (P.Amax : ℤ) * 2 ^ q := by
  unfold inRangeA at h
  obtain ⟨h1, h2⟩ := of_decide_eq_true h
  unfold gridVal at h1 h2
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  rw [le_div_iff₀ hpos, zero_mul] at h1
  rw [div_le_iff₀ hpos] at h2
  exact ⟨by exact_mod_cast h1, by exact_mod_cast h2⟩

theorem inRangeC_gridVal {P : StreamParams} {q : ℕ} {m : ℤ} (h : inRangeC P (gridVal q m) = true) :
    0 ≤ m ∧ m ≤ (P.Cmax : ℤ) * 2 ^ q := by
  unfold inRangeC at h
  obtain ⟨h1, h2⟩ := of_decide_eq_true h
  unfold gridVal at h1 h2
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  rw [le_div_iff₀ hpos, zero_mul] at h1
  rw [div_le_iff₀ hpos] at h2
  exact ⟨by exact_mod_cast h1, by exact_mod_cast h2⟩

theorem natCast_mul_two_pow_nonneg (n q : ℕ) : (0 : ℤ) ≤ (n : ℤ) * 2 ^ q :=
  mul_nonneg (Int.natCast_nonneg n) (pow_nonneg (by norm_num) q)

theorem cmul_nonneg (c : ℕ) {X : ℤ} (hX : 0 ≤ X) : (0 : ℤ) ≤ (c : ℤ) * X :=
  mul_nonneg (Int.natCast_nonneg c) hX

/-- `x ≤ X` implies `x ≤ c X` for `c ≥ 1`, `X ≥ 0`. -/
theorem le_cmul {x X : ℤ} {c : ℕ} (hc : 1 ≤ c) (hX : 0 ≤ X) (h : x ≤ X) : x ≤ (c : ℤ) * X :=
  le_trans h (le_mul_of_one_le_left hX (by exact_mod_cast hc))

/-! ## Samplers -/

theorem always_bitsNat (acc k : ℕ) : Always (Discrete.bitsNat acc k) (fun x => x < (acc + 1) * 2 ^ k) := by
  induction k generalizing acc with
  | zero => show acc < (acc + 1) * 2 ^ 0; simp
  | succ k ih =>
    show Always (BitProg.bit fun b => Discrete.bitsNat (2 * acc + if b then 1 else 0) k) _
    intro b
    refine Always.mono (fun x hx => ?_) (ih _)
    have h1 : 2 * acc + (if b then 1 else 0) + 1 ≤ 2 * (acc + 1) := by split <;> omega
    calc x < (2 * acc + (if b then 1 else 0) + 1) * 2 ^ k := hx
      _ ≤ 2 * (acc + 1) * 2 ^ k := Nat.mul_le_mul_right _ h1
      _ = (acc + 1) * 2 ^ (k + 1) := by ring

theorem always_uniformBits (k : ℕ) : Always (uniformBits k) (fun x => x < 2 ^ k) := by
  have := always_bitsNat 0 k
  simpa [uniformBits] using this

theorem always_sampleList {α : Type} {p : BitProg α} {Q : α → Prop} (hp : Always p Q) :
    ∀ k : ℕ, Always (sampleList p k) (fun l => l.length = k ∧ ∀ a ∈ l, Q a)
  | 0 => ⟨rfl, by simp⟩
  | k + 1 => by
    have e : sampleList p (k + 1) =
        p.bind (fun a => (sampleList p k).bind (fun l => BitProg.pure (a :: l))) := rfl
    rw [e]
    refine Always.bind (fun a ha => ?_) hp
    refine Always.bind (fun l hl => ?_) (always_sampleList hp k)
    refine ⟨by simp [hl.1], fun x hx => ?_⟩
    rcases List.mem_cons.1 hx with rfl | hx
    · exact ha
    · exact hl.2 x hx

theorem always_rejectUniform (D k : ℕ) :
    ∀ r : ℕ, Always (rejectUniform D k r) (fun o => ∀ x, o = some x → x < D)
  | 0 => fun x hx => by cases hx
  | r + 1 => by
    have e : rejectUniform D k (r + 1) = (uniformBits k).bind (fun x =>
        if x < D then BitProg.pure (some x) else rejectUniform D k r) := rfl
    rw [e]
    refine Always.bind_all (fun x => ?_) _
    split_ifs with hx
    · intro y hy
      cases hy
      exact hx
    · exact always_rejectUniform D k r

end Aux

open Aux

/-! ## Rows -/

theorem RowOK.of_counters {P : StreamParams} {r r' : Row} (h : RowOK P r) (hs : r'.seed = r.seed)
    (hX : |r'.X| ≤ zSat P) (hY : |r'.Y| ≤ zSat P) : RowOK P r' :=
  ⟨hs ▸ h.seed_length, by rw [hs]; exact h.seed_lt, hX, hY⟩

theorem RowOK.addPhys {P : StreamParams} {r : Row} (h : RowOK P r) (i : ℕ) (Δ : ℤ) :
    RowOK P (r.addPhys P i Δ) :=
  h.of_counters rfl (abs_sat_le (zSat_nonneg P) _) (abs_sat_le (zSat_nonneg P) _)

theorem RowOK.addGuardY {P : StreamParams} {r : Row} (h : RowOK P r) (g : ℕ) (δ : ℤ) :
    RowOK P (r.addGuardY P g δ) :=
  h.of_counters rfl h.abs_X_le (abs_sat_le (zSat_nonneg P) _)

theorem RowOK.addGuardXY {P : StreamParams} {r : Row} (h : RowOK P r) (g : ℕ) (δ : ℤ) :
    RowOK P (r.addGuardXY P g δ) :=
  h.of_counters rfl (abs_sat_le (zSat_nonneg P) _) (abs_sat_le (zSat_nonneg P) _)

theorem RowOK.scaleY {P : StreamParams} {r : Row} (h : RowOK P r) (c : ℤ) :
    RowOK P (r.scaleY P c) :=
  h.of_counters rfl h.abs_X_le (abs_sat_le (zSat_nonneg P) _)

theorem RowOK.scaleXY {P : StreamParams} {r : Row} (h : RowOK P r) (c : ℤ) :
    RowOK P (r.scaleXY P c) :=
  h.of_counters rfl (abs_sat_le (zSat_nonneg P) _) (abs_sat_le (zSat_nonneg P) _)

theorem RowOK.resetY {P : StreamParams} {r : Row} (h : RowOK P r) : RowOK P r.resetY :=
  h.of_counters rfl h.abs_X_le (by show |(0 : ℤ)| ≤ zSat P; rw [abs_zero]; exact zSat_nonneg P)

theorem always_sampleSeed (P : StreamParams) :
    Always (sampleSeed P) (fun l => l.length = 2 * P.s ∧ ∀ a ∈ l, a < 2 ^ P.w) := by
  unfold sampleSeed
  generalize 2 * P.s = k
  generalize P.w = w
  exact always_sampleList (always_uniformBits w) k

theorem always_newRow (P : StreamParams) : Always (newRow P) (RowOK P) := by
  have h1 := always_sampleSeed P
  have e : newRow P = (sampleSeed P).bind (fun z => BitProg.pure (⟨z, 0, 0⟩ : Row)) := rfl
  rw [e]
  refine Always.bind (fun z hz => ?_) h1
  have h0 : |(0 : ℤ)| ≤ zSat P := by rw [abs_zero]; exact zSat_nonneg P
  exact ⟨hz.1, hz.2, h0, h0⟩

/-! ## Banks -/

theorem BankOK.mapRows {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) {f : Row → Row} (hf : ∀ r, RowOK P r → RowOK P (f r)) :
    BankOK P adaOK (B.mapRows f) where
  ada_sizes := by
    rw [← h.ada_sizes]; simp [Bank.mapRows, Function.comp_def]
  coarse_length_le := by simpa [Bank.mapRows] using h.coarse_length_le
  coarse_shape := by
    intro grp hgrp
    simp only [Bank.mapRows, List.mem_map] at hgrp
    obtain ⟨g0, hg0, rfl⟩ := hgrp
    refine ⟨by simp [(h.coarse_shape g0 hg0).1], fun sub hsub => ?_⟩
    simp only [List.mem_map] at hsub
    obtain ⟨s0, hs0, rfl⟩ := hsub
    simp [(h.coarse_shape g0 hg0).2 s0 hs0]
  ada_rows := by
    intro blk hblk r hr
    simp only [Bank.mapRows, List.mem_map] at hblk
    obtain ⟨b0, hb0, rfl⟩ := hblk
    simp only [List.mem_map] at hr
    obtain ⟨r0, hr0, rfl⟩ := hr
    exact hf r0 (h.ada_rows b0 hb0 r0 hr0)
  coarse_rows := by
    intro grp hgrp sub hsub r hr
    simp only [Bank.mapRows, List.mem_map] at hgrp
    obtain ⟨g0, hg0, rfl⟩ := hgrp
    simp only [List.mem_map] at hsub
    obtain ⟨s0, hs0, rfl⟩ := hsub
    simp only [List.mem_map] at hr
    obtain ⟨r0, hr0, rfl⟩ := hr
    exact hf r0 (h.coarse_rows g0 hg0 s0 hs0 r0 hr0)
  ada_ok := h.ada_ok

theorem BankOK.addPhys {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (i : ℕ) (Δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addPhys P i Δ)) :=
  h.mapRows fun _ hr => hr.addPhys i Δ

theorem BankOK.resetY {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) : BankOK P adaOK (B.mapRows Row.resetY) :=
  h.mapRows fun _ hr => hr.resetY

theorem BankOK.addGuardY {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (g : ℕ) (δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addGuardY P g δ)) :=
  h.mapRows fun _ hr => hr.addGuardY g δ

theorem BankOK.addGuardXY {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (g : ℕ) (δ : ℤ) : BankOK P adaOK (B.mapRows (Row.addGuardXY P g δ)) :=
  h.mapRows fun _ hr => hr.addGuardXY g δ

theorem BankOK.scaleY {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (cInt : ℤ) : BankOK P adaOK (B.mapRows (Row.scaleY P cInt)) :=
  h.mapRows fun _ hr => hr.scaleY cInt

theorem BankOK.scaleXY {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) (cInt : ℤ) : BankOK P adaOK (B.mapRows (Row.scaleXY P cInt)) :=
  h.mapRows fun _ hr => hr.scaleXY cInt

theorem BankOK.with_adaSt {P : StreamParams} {adaOK : AdaState → Prop} {B : Bank}
    (h : BankOK P adaOK B) {st : AdaState} (hst : adaOK st) :
    BankOK P adaOK { B with adaSt := st } :=
  ⟨h.ada_sizes, h.coarse_length_le, h.coarse_shape, h.ada_rows, h.coarse_rows, hst⟩

theorem BankOK.validate {P : StreamParams} {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {B : Bank} (h : BankOK P adaOK B) (S θ : ℚ) :
    Always (B.validate P S θ) (fun r => BankOK P adaOK r.2) := by
  unfold Bank.validate
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (fun res hres => ?_) (hA.interval _ _ _ _ h.ada_ok)
  exact h.with_adaSt hres

theorem BankOK.release {P : StreamParams} {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK)
    {B : Bank} (h : BankOK P adaOK B) (mode : Mode) :
    Always (B.release P mode) (fun r => BankOK P adaOK r.2) := by
  unfold Bank.release
  split
  · exact h
  · rename_i grp rest hco
    simp only [bp_bind_eq, bp_pure_eq]
    refine Always.bind (fun res hres => ?_) (hA.numerical _ _ h.ada_ok)
    have hB' : BankOK P adaOK { B with coarse := rest, adaSt := res.2 } := by
      refine ⟨h.ada_sizes, ?_, ?_, h.ada_rows, ?_, hres⟩
      · have := h.coarse_length_le; rw [hco] at this; simp at this ⊢; omega
      · intro g hg; exact h.coarse_shape g (by rw [hco]; exact List.mem_cons_of_mem _ hg)
      · intro g hg; exact h.coarse_rows g (by rw [hco]; exact List.mem_cons_of_mem _ hg)
    split <;> exact hB'

theorem always_sampleBlocks (P : StreamParams) : ∀ ns : List ℕ, Always (sampleBlocks P ns)
    (fun blks => blks.map List.length = ns ∧ ∀ blk ∈ blks, ∀ r ∈ blk, RowOK P r)
  | [] => ⟨rfl, by simp⟩
  | nj :: rest => by
    have e : sampleBlocks P (nj :: rest) = (sampleList (newRow P) nj).bind (fun blk =>
        (sampleBlocks P rest).bind (fun l => BitProg.pure (blk :: l))) := rfl
    rw [e]
    refine Always.bind (fun blk hblk => ?_) (always_sampleList (always_newRow P) nj)
    refine Always.bind (fun l hl => ?_) (always_sampleBlocks P rest)
    refine ⟨by simp [hblk.1, hl.1], fun b hb r hr => ?_⟩
    rcases List.mem_cons.1 hb with rfl | hb
    · exact hblk.2 r hr
    · exact hl.2 b hb r hr

theorem always_newBank (P : StreamParams) {adaOK : AdaState → Prop} (hA : AdaInvariant P adaOK) :
    Always (newBank P) (BankOK P adaOK) := by
  have e : newBank P = (sampleBlocks P (bankAda P).blockSizes).bind (fun ada =>
      (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax).bind (fun coarse =>
        (adaInit (bankAda P)).bind (fun st => BitProg.pure (⟨ada, coarse, st⟩ : Bank)))) := rfl
  have hco : Always (sampleList (sampleList (sampleList (newRow P) 32) P.gCoarse) P.Rmax)
      (fun l => l.length = P.Rmax ∧ ∀ grp ∈ l, grp.length = P.gCoarse ∧
        ∀ sub ∈ grp, sub.length = 32 ∧ ∀ r ∈ sub, RowOK P r) :=
    always_sampleList (always_sampleList (always_sampleList (always_newRow P) 32) P.gCoarse) P.Rmax
  rw [e]
  refine Always.bind (fun ada hada => ?_) (always_sampleBlocks P _)
  refine Always.bind (fun coarse hc => ?_) hco
  refine Always.bind (fun st hst => ?_) hA.init
  exact ⟨hada.1, le_of_eq hc.1,
    fun grp hg => ⟨(hc.2 grp hg).1, fun sub hs => ((hc.2 grp hg).2 sub hs).1⟩,
    hada.2, fun grp hg sub hs r hr => ((hc.2 grp hg).2 sub hs).2 r hr, hst⟩

/-! ## Learners -/

theorem LearnerOK.mono {P : StreamParams} {c c' : ℕ} {L : Learner} (h : LearnerOK P c L)
    (hc : c ≤ c') : LearnerOK P c' L := by
  have hc' : (c : ℤ) ≤ c' := by exact_mod_cast hc
  exact ⟨h.tag_nonneg, h.tag_le.trans (mul_le_mul_of_nonneg_right hc' (natCast_mul_two_pow_nonneg _ _)),
    h.cache_nonneg, h.cache_le.trans (mul_le_mul_of_nonneg_right hc' (natCast_mul_two_pow_nonneg _ _)),
    h.epoch_le, h.jEpoch_lt, h.jUsed_le⟩

/-- A learner whose tag and cache passed the range checks and whose counters are those of a
`LearnerOK` learner. -/
theorem LearnerOK.of_inRange {P : StreamParams} {c : ℕ} {L L' : Learner} (h : LearnerOK P c L)
    (hr : L'.inRange P = true) (he : L'.epoch = L.epoch) (hj : L'.jEpoch = L.jEpoch)
    (hu : L'.jUsed = L.jUsed) : LearnerOK P 1 L' := by
  unfold Learner.inRange at hr
  rw [Bool.and_eq_true] at hr
  obtain ⟨h1, h2⟩ := inRangeC_gridVal hr.1
  obtain ⟨h3, h4⟩ := inRangeA_gridVal hr.2
  refine ⟨h1, ?_, h3, ?_, he ▸ h.epoch_le, hj ▸ h.jEpoch_lt, hu ▸ h.jUsed_le⟩
  · rw [Nat.cast_one, one_mul]; exact h2
  · rw [Nat.cast_one, one_mul]; exact h4

theorem LearnerOK.with_cache {P : StreamParams} {c : ℕ} {L : Learner} (h : LearnerOK P c L)
    (hc : 1 ≤ c) {cache : ℤ} (hcache : inRangeA P (gridVal P.eHP cache) = true) :
    LearnerOK P c { L with cache := cache } := by
  obtain ⟨h0, h1⟩ := inRangeA_gridVal hcache
  exact ⟨h.tag_nonneg, h.tag_le, h0, le_cmul hc (natCast_mul_two_pow_nonneg _ _) h1, h.epoch_le,
    h.jEpoch_lt, h.jUsed_le⟩

theorem LearnerOK.countCorrection {P : StreamParams} {c : ℕ} {L L' : Learner}
    (h : LearnerOK P c L) (hj : L.jUsed < P.Jstar) (hc : L.countCorrection P = some L') :
    LearnerOK P c L' := by
  unfold Learner.countCorrection at hc
  split_ifs at hc with h1 h2
  · cases hc
    exact ⟨h.tag_nonneg, h.tag_le, h.cache_nonneg, h.cache_le, h2, K0_pos P, by simp; omega⟩
  · cases hc
    exact ⟨h.tag_nonneg, h.tag_le, h.cache_nonneg, h.cache_le, h.epoch_le,
      by have := h.jEpoch_lt; simp; omega, by simp; omega⟩

theorem newLearner_ok (P : StreamParams) {c : ℕ} (hc : 1 ≤ c) {cache : ℤ} (h0 : 0 ≤ cache)
    (h1 : cache ≤ (P.Amax : ℤ) * 2 ^ P.eHP) : LearnerOK P c (newLearner P cache) where
  tag_nonneg := show (0 : ℤ) ≤ 2 ^ P.eHC from pow_nonneg (by norm_num) _
  tag_le := by
    show (2 : ℤ) ^ P.eHC ≤ (c : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC)
    have hC : (1 : ℤ) ≤ P.Cmax := by exact_mod_cast one_le_Cmax P
    have h2 : (0 : ℤ) ≤ 2 ^ P.eHC := pow_nonneg (by norm_num) _
    have h3 : (2 : ℤ) ^ P.eHC ≤ (P.Cmax : ℤ) * 2 ^ P.eHC := le_mul_of_one_le_left h2 hC
    exact le_cmul hc (natCast_mul_two_pow_nonneg _ _) h3
  cache_nonneg := h0
  cache_le := le_cmul hc (natCast_mul_two_pow_nonneg _ _) h1
  epoch_le := Nat.zero_le _
  jEpoch_lt := K0_pos P
  jUsed_le := Nat.zero_le _

/-- The rescaling of a learner in the rejection branch (partIII.tex L506) multiplies its tag by
`c ≤ 3/2` and its cache by `c² ≤ 9/4` (then rounds): the ranges grow by at most `2` and `3`. -/
theorem scaleMant_bounds {q : ℕ} {c m k M : ℤ} (hc0 : 0 ≤ c) (hck : c ≤ k * 2 ^ q) (hm0 : 0 ≤ m)
    (hmM : m ≤ M) (hk : 0 ≤ k) : 0 ≤ scaleMant q c m ∧ scaleMant q c m ≤ k * M := by
  unfold scaleMant roundMant
  simp only [pow_zero, mul_one]
  have hpos : (0 : ℚ) < 2 ^ q := by positivity
  have hc0' : (0 : ℚ) ≤ c := by exact_mod_cast hc0
  have hm0' : (0 : ℚ) ≤ m := by exact_mod_cast hm0
  have hx0 : (0 : ℚ) ≤ (c : ℚ) * m / 2 ^ q := div_nonneg (mul_nonneg hc0' hm0') hpos.le
  constructor
  · apply Int.floor_nonneg.2
    linarith
  · have h1 : (c : ℚ) * m / 2 ^ q ≤ k * M := by
      rw [div_le_iff₀ hpos]
      have hc' : (c : ℚ) ≤ k * 2 ^ q := by exact_mod_cast hck
      have hM' : (m : ℚ) ≤ M := by exact_mod_cast hmM
      have hk' : (0 : ℚ) ≤ k := by exact_mod_cast hk
      nlinarith
    have : (⌊(c : ℚ) * m / 2 ^ q + 1 / 2⌋ : ℤ) < k * M + 1 := by
      rw [Int.floor_lt]; push_cast; linarith
    omega

theorem LearnerOK.rescale {P : StreamParams} {c : ℕ} {L : Learner} (h : LearnerOK P c L)
    {cInt : ℤ} (hc0 : 2 ^ (P.eHstep - 1) ≤ cInt) (hc1 : cInt ≤ 3 * 2 ^ (P.eHstep - 1)) :
    LearnerOK P (4 * c) (L.rescale P cInt) := by
  have hq : 1 ≤ P.eHstep := by unfold eHstep; omega
  set u : ℤ := 2 ^ (P.eHstep - 1) with hu_def
  have hu : (2 : ℤ) ^ P.eHstep = 2 * u := by
    rw [hu_def, ← pow_succ']; congr 1; omega
  have hu0 : 0 < u := pow_pos (by norm_num) _
  have hcpos : 0 ≤ cInt := le_trans hu0.le hc0
  have hck : cInt ≤ 2 * 2 ^ P.eHstep := by rw [hu]; linarith
  have ht := scaleMant_bounds (q := P.eHstep) (k := 2) (M := (c : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC))
    hcpos hck h.tag_nonneg h.tag_le (by norm_num)
  have hc2 : cInt ^ 2 ≤ 3 * 2 ^ (2 * P.eHstep) := by
    have e : (2 : ℤ) ^ (2 * P.eHstep) = 4 * u ^ 2 := by
      rw [pow_mul', hu]; ring
    rw [e]
    nlinarith
  have hcache := scaleMant_bounds (q := 2 * P.eHstep) (k := 3)
    (M := (c : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP)) (sq_nonneg cInt) hc2 h.cache_nonneg h.cache_le
    (by norm_num)
  have hT : (0 : ℤ) ≤ (c : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) :=
    cmul_nonneg c (natCast_mul_two_pow_nonneg _ _)
  have hA : (0 : ℤ) ≤ (c : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) :=
    cmul_nonneg c (natCast_mul_two_pow_nonneg _ _)
  refine ⟨ht.1, ?_, hcache.1, ?_, h.epoch_le, h.jEpoch_lt, h.jUsed_le⟩
  · show scaleMant P.eHstep cInt L.tag ≤ ((4 * c : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC)
    have e : ((4 * c : ℕ) : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC) =
        4 * ((c : ℤ) * ((P.Cmax : ℤ) * 2 ^ P.eHC)) := by push_cast; ring
    rw [e]; linarith [ht.2]
  · show scaleMant (2 * P.eHstep) (cInt ^ 2) L.cache ≤ ((4 * c : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP)
    have e : ((4 * c : ℕ) : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP) =
        4 * ((c : ℤ) * ((P.Amax : ℤ) * 2 ^ P.eHP)) := by push_cast; ring
    rw [e]; linarith [hcache.2]

/-! ## States -/

section States

variable {P : StreamParams} {adaOK : AdaState → Prop} {c : ℕ}

theorem StateOK.mono {s : State} (h : StateOK P adaOK c s) {c' : ℕ} (hc : c ≤ c') :
    StateOK P adaOK c' s where
  fpSeed_lt := h.fpSeed_lt
  fpVal_lt := h.fpVal_lt
  learners_length_le := h.learners_length_le
  banks_length_le := h.banks_length_le
  learners_ok := fun L hL => (h.learners_ok L hL).mono hc
  banks_ok := h.banks_ok
  leaf_nonneg := h.leaf_nonneg
  leaf_le := h.leaf_le.trans (mul_le_mul_of_nonneg_right (by exact_mod_cast hc)
    (natCast_mul_two_pow_nonneg _ _))

theorem StateOK.fail {s : State} (h : StateOK P adaOK c s) : StateOK P adaOK c s.fail :=
  ⟨h.fpSeed_lt, h.fpVal_lt, h.learners_length_le, h.banks_length_le, h.learners_ok, h.banks_ok,
    h.leaf_nonneg, h.leaf_le⟩

theorem StateOK.finish {s : State} (h : StateOK P adaOK c s) (F : ℚ) :
    StateOK P adaOK c (finishRound s F).1 :=
  ⟨h.fpSeed_lt, h.fpVal_lt, h.learners_length_le, h.banks_length_le, h.learners_ok, h.banks_ok,
    h.leaf_nonneg, h.leaf_le⟩

theorem StateOK.withBanks {s : State} (h : StateOK P adaOK c s) {bs : List Bank}
    (hlen : bs.length ≤ P.H) (hb : ∀ B ∈ bs, BankOK P adaOK B) :
    StateOK P adaOK c { s with banks := bs } :=
  ⟨h.fpSeed_lt, h.fpVal_lt, h.learners_length_le, hlen, h.learners_ok, hb, h.leaf_nonneg,
    h.leaf_le⟩

theorem StateOK.setBank {s : State} (h : StateOK P adaOK c s) {B : Bank} (hB : BankOK P adaOK B)
    (d : ℕ) : StateOK P adaOK c { s with banks := setAt B d s.banks } :=
  h.withBanks (by rw [length_setAt]; exact h.banks_length_le) (forall_mem_setAt _ hB _ _ h.banks_ok)

theorem StateOK.update {s : State} (h : StateOK P adaOK c s) {ls : List Learner} {bs : List Bank}
    {lf : ℤ} (hls : ls.length ≤ P.H) (hbs : bs.length ≤ P.H) (hl : ∀ L ∈ ls, LearnerOK P c L)
    (hb : ∀ B ∈ bs, BankOK P adaOK B) (hlf0 : 0 ≤ lf) (hlf1 : lf ≤ c * (P.Amax * 2 ^ P.eHleaf)) :
    StateOK P adaOK c { s with learners := ls, banks := bs, leaf := lf } :=
  ⟨h.fpSeed_lt, h.fpVal_lt, hls, hbs, hl, hb, hlf0, hlf1⟩

theorem StateOK.take {s : State} (h : StateOK P adaOK c s) (a b : ℕ) :
    StateOK P adaOK c { s with learners := s.learners.take a, banks := s.banks.take b } :=
  ⟨h.fpSeed_lt, h.fpVal_lt, le_trans (List.length_take_le' _ _) h.learners_length_le,
    le_trans (List.length_take_le' _ _) h.banks_length_le,
    fun L hL => h.learners_ok L (List.mem_of_mem_take hL),
    fun B hB => h.banks_ok B (List.mem_of_mem_take hB), h.leaf_nonneg, h.leaf_le⟩


/-! ## Step 2 -/

theorem step2_ok (hc : 1 ≤ c) {s : State} (h : StateOK P adaOK c s) (i : ℕ) (Δ : ℤ) :
    StateOK P adaOK c (step2 P i Δ s).1 := by
  have hb : ∀ B ∈ s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ)), BankOK P adaOK B := by
    intro B hB
    rw [List.mem_map] at hB
    obtain ⟨B0, hB0, rfl⟩ := hB
    exact (h.banks_ok B0 hB0).addPhys _ _
  have hblen : (s.banks.map (Bank.mapRows (Row.addPhys P (i + 1) Δ))).length ≤ P.H := by
    rw [List.length_map]; exact h.banks_length_le
  have hfp := fpUpdate_lt P (q_pos P) s.fpSeed s.fpVal (i + 1) Δ
  unfold step2
  dsimp only
  split_ifs with hr
  · obtain ⟨h0, h1⟩ := inRangeA_gridVal hr
    exact ⟨h.fpSeed_lt, hfp, h.learners_length_le, hblen, h.learners_ok, hb, h0,
      le_cmul hc (by positivity) h1⟩
  · exact ⟨h.fpSeed_lt, hfp, h.learners_length_le, hblen, h.learners_ok, hb, h.leaf_nonneg,
      h.leaf_le⟩

/-! ## Step 3 -/

theorem step3Depth_ok (hc : 1 ≤ c) {s : State} (h : StateOK P adaOK c s) (tr d : ℕ) :
    StateOK P adaOK c (step3Depth P tr s d) := by
  unfold step3Depth
  split
  · exact h.fail
  · rename_i Ld hLd
    have hLd' : LearnerOK P c Ld := h.learners_ok Ld (List.mem_of_getElem? hLd)
    dsimp only
    split_ifs with hδ hr
    · exact h
    · rw [Bool.and_eq_true] at hr
      obtain ⟨hl0, hl1⟩ := inRangeA_gridVal hr.2
      refine h.update ?_ ?_ ?_ ?_ hl0 (le_cmul hc (by positivity) hl1)
      · rw [length_setAt]; exact h.learners_length_le
      · rw [length_mapFrom, length_modifyAt]; exact h.banks_length_le
      · exact forall_mem_setAt _ (hLd'.with_cache hc hr.1) _ _ h.learners_ok
      · exact forall_mem_mapFrom _ (fun B hB => hB.addGuardXY _ _) _ _
          (forall_mem_modifyAt _ (fun B hB => hB.addGuardY _ _) _ _ h.banks_ok)
    · refine StateOK.fail (h.withBanks ?_ ?_)
      · rw [length_mapFrom, length_modifyAt]; exact h.banks_length_le
      · exact forall_mem_mapFrom _ (fun B hB => hB.addGuardXY _ _) _ _
          (forall_mem_modifyAt _ (fun B hB => hB.addGuardY _ _) _ _ h.banks_ok)

theorem step3Loop_ok (hc : 1 ≤ c) (tr : ℕ) :
    ∀ (ds : List ℕ) (s : State), StateOK P adaOK c s → StateOK P adaOK c (step3Loop P tr ds s)
  | [], _, h => h
  | d :: ds, s, h => by
    simp only [step3Loop]
    split_ifs
    · exact h
    · exact step3Loop_ok hc tr ds _ (step3Depth_ok hc h tr d)

theorem step3_ok (hc : 1 ≤ c) {s : State} (h : StateOK P adaOK c s) :
    StateOK P adaOK c (step3 P s) :=
  step3Loop_ok hc _ _ _ h

/-! ## Step 1 -/

theorem birthDepth_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State}
    (h : StateOK P adaOK c s) {d : ℕ} (hl : s.learners.length ≤ d) (hb : s.banks.length ≤ d + 1)
    (hd : d < P.H) (d0 : ℕ) :
    Always (birthDepth P d0 d s) (fun s' => StateOK P adaOK c s' ∧ s'.learners.length ≤ d + 1 ∧
      s'.banks.length ≤ d + 2) := by
  have hb1 : ∀ B ∈ modifyAt (Bank.mapRows Row.resetY) d s.banks, BankOK P adaOK B :=
    forall_mem_modifyAt _ (fun B hB => hB.resetY) _ _ h.banks_ok
  unfold birthDepth
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (Q := fun s2 => StateOK P adaOK c s2 ∧ s2.learners = s.learners ∧
    s2.banks.length ≤ d + 2) (fun s2 hs2 => ?_) ?_
  · obtain ⟨h2, hl2, hb2⟩ := hs2
    split_ifs with hd0
    · refine ⟨⟨h2.fpSeed_lt, h2.fpVal_lt, ?_, h2.banks_length_le, ?_, h2.banks_ok, h2.leaf_nonneg,
        h2.leaf_le⟩, ?_, hb2⟩
      · rw [List.length_append, hl2]; simp; omega
      · intro L hL
        rw [List.mem_append] at hL
        rcases hL with hL | hL
        · exact h2.learners_ok L hL
        · rw [List.mem_singleton] at hL
          subst hL
          exact newLearner_ok P hc le_rfl (by positivity)
      · rw [List.length_append, hl2]; simp; omega
    · split
      · exact ⟨h2.fail, by rw [show s2.fail.learners = s2.learners from rfl, hl2]; omega,
          show s2.banks.length ≤ d + 2 from hb2⟩
      · rename_i B hB
        refine Always.bind (fun res hres => ?_)
          (BankOK.release hA (h2.banks_ok B (List.mem_of_getElem? hB)) Mode.primary)
        have h3 := h2.setBank hres d
        have hl3 : s2.learners.length ≤ d + 1 := by rw [hl2]; omega
        have hb3 : (setAt res.2 d s2.banks).length ≤ d + 2 := by rw [length_setAt]; exact hb2
        split
        · exact ⟨h3.fail, hl3, hb3⟩
        · rename_i N hN
          split_ifs with hr
          · obtain ⟨hc0, hc1⟩ := inRangeA_gridVal hr
            refine ⟨⟨h3.fpSeed_lt, h3.fpVal_lt, ?_, h3.banks_length_le, ?_, h3.banks_ok,
              h3.leaf_nonneg, h3.leaf_le⟩, ?_, hb3⟩
            · show (s2.learners ++ [newLearner P (roundMant P.eHP N)]).length ≤ P.H
              rw [List.length_append, hl2]; simp; omega
            · intro L hL
              rw [List.mem_append] at hL
              rcases hL with hL | hL
              · exact h2.learners_ok L hL
              · rw [List.mem_singleton] at hL
                subst hL
                exact newLearner_ok P hc hc0 hc1
            · show (s2.learners ++ [newLearner P (roundMant P.eHP N)]).length ≤ d + 1
              rw [List.length_append, hl2]; simp; omega
          · exact ⟨h3.fail, hl3, hb3⟩
  · split_ifs with hd2
    · refine Always.bind (fun B hB => ?_) (always_newBank P hA)
      have hlen : (modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B]).length ≤ d + 2 := by
        rw [List.length_append, length_modifyAt]; simp; omega
      have hlenH : (modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B]).length ≤ P.H := by
        rw [List.length_append, length_modifyAt]; simp; omega
      have hbB : ∀ B' ∈ modifyAt (Bank.mapRows Row.resetY) d s.banks ++ [B], BankOK P adaOK B' := by
        intro B' hB'
        rw [List.mem_append] at hB'
        rcases hB' with hB' | hB'
        · exact hb1 B' hB'
        · rw [List.mem_singleton] at hB'
          subst hB'
          exact hB
      exact ⟨h.withBanks hlenH hbB, rfl, hlen⟩
    · have hlen : (modifyAt (Bank.mapRows Row.resetY) d s.banks).length ≤ d + 1 := by
        rw [length_modifyAt]; exact hb
      exact ⟨h.withBanks (by rw [length_modifyAt]; exact h.banks_length_le) hb1, rfl,
        Nat.le_succ_of_le hlen⟩

theorem birthLoop_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) (d0 : ℕ) :
    ∀ (k d : ℕ) (s : State), d + k ≤ P.H → StateOK P adaOK c s → s.learners.length ≤ d →
      s.banks.length ≤ d + 1 → Always (birthLoop P d0 (List.range' d k) s) (StateOK P adaOK c)
  | 0, _, _, _, h, _, _ => by
    simp only [List.range'_zero, birthLoop]
    exact h
  | k + 1, d, s, hdk, h, hl, hb => by
    simp only [List.range'_succ, birthLoop, bp_bind_eq]
    split_ifs
    · exact h
    · refine Always.bind (fun s' hs' => ?_) (birthDepth_ok hA hc h hl hb (by omega) d0)
      exact birthLoop_ok hA hc d0 k (d + 1) s' (by omega) hs'.1 hs'.2.1 hs'.2.2

theorem step1_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State} (h : StateOK P adaOK c s) :
    Always (step1 P s) (StateOK P adaOK c) := by
  have hd0 := firstBorn_lt P.H (s.t + 1) (F2e2e.C.Alg.H_pos P)
  unfold step1
  simp only [bp_bind_eq, bp_pure_eq]
  refine Always.bind (fun s2 hs2 => ?_) (birthLoop_ok hA hc _ (P.H - firstBorn P.H (s.t + 1))
    (firstBorn P.H (s.t + 1)) _ (by omega) (h.take _ _) ?_ ?_)
  · exact ⟨hs2.fpSeed_lt, hs2.fpVal_lt, hs2.learners_length_le, hs2.banks_length_le,
      hs2.learners_ok, hs2.banks_ok, le_rfl, by positivity⟩
  · show (s.learners.take (firstBorn P.H (s.t + 1))).length ≤ firstBorn P.H (s.t + 1)
    exact List.length_take_le _ _
  · show (s.banks.take (firstBorn P.H (s.t + 1) + 1)).length ≤ firstBorn P.H (s.t + 1) + 1
    exact List.length_take_le _ _

/-! ## Step 4 -/

theorem rejectTail_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State}
    (h : StateOK P adaOK c s) {d : ℕ} {Ld : Learner} (hLd : LearnerOK P c Ld)
    (hj : Ld.jUsed < P.Jstar) (cInt : ℤ) (N1 : ℚ) :
    Always (rejectTail P d Ld cInt N1 s) (fun r => StateOK P adaOK c r.1) := by
  have hbanks : ∀ B ∈ mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks,
      BankOK P adaOK B :=
    forall_mem_mapFrom _ (fun B hB => hB.scaleXY _) _ _ h.banks_ok
  have hblen : (mapFrom (Bank.mapRows (Row.scaleXY P cInt)) (d + 1) s.banks).length ≤ P.H := by
    rw [length_mapFrom]; exact h.banks_length_le
  unfold rejectTail
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hchk
  · rw [Bool.and_eq_true] at hchk
    obtain ⟨hall, hleaf⟩ := hchk
    obtain ⟨hl0, hl1⟩ := inRangeA_gridVal hleaf
    have hlearn : ∀ L ∈ mapFrom (Learner.rescale P cInt) (d + 1) s.learners, LearnerOK P c L := by
      refine forall_mem_mapFrom_of_drop _ _ _ h.learners_ok ?_
      intro L hL
      have hr : L.inRange P = true := by
        rw [← drop_mapFrom] at hL
        exact List.all_eq_true.mp hall L hL
      rw [List.mem_map] at hL
      obtain ⟨L0, hL0, rfl⟩ := hL
      exact (LearnerOK.of_inRange (h.learners_ok L0 (List.mem_of_mem_drop hL0)) hr rfl rfl
        rfl).mono hc
    have h1 := h.update (by rw [length_mapFrom]; exact h.learners_length_le) hblen hlearn hbanks
      hl0 (le_cmul hc (by positivity) hl1)
    split
    · exact h1.fail
    · rename_i Bd hBd
      refine Always.bind (fun r2 hr2 => ?_)
        (BankOK.release hA (h1.banks_ok Bd (List.mem_of_getElem? hBd)) Mode.diff)
      have h2 := h1.setBank hr2 d
      split
      · exact h2.fail
      · rename_i N2 hN2
        split
        · exact h2.fail
        · rename_i Ld' hLd'
          split_ifs with hcache
          · have hL' : LearnerOK P c Ld' := (hLd.with_cache hc hcache).countCorrection hj hLd'
            refine ⟨h2.fpSeed_lt, h2.fpVal_lt, ?_, h2.banks_length_le, ?_, h2.banks_ok,
              h2.leaf_nonneg, h2.leaf_le⟩
            · show (setAt Ld' d (mapFrom (Learner.rescale P cInt) (d + 1) s.learners)).length ≤ P.H
              rw [length_setAt, length_mapFrom]; exact h.learners_length_le
            · exact forall_mem_setAt _ hL' _ _ hlearn
          · exact h2.fail
  · exact (h.withBanks hblen hbanks).fail

theorem rejectDepth_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State}
    (h : StateOK P adaOK c s) (d : ℕ) (pos : Bool) (Qhat : ℚ) :
    Always (rejectDepth P d pos Qhat s) (fun r => StateOK P adaOK c r.1) := by
  unfold rejectDepth
  split
  · rename_i Ld Bd hLd hBd
    simp only [bp_bind_eq, bp_pure_eq]
    split_ifs with hchk
    · exact h.fail
    · refine Always.bind (fun r1 hr1 => ?_)
        (BankOK.release hA (h.banks_ok Bd (List.mem_of_getElem? hBd)) Mode.primary)
      have h1 := h.setBank hr1 d
      split
      · exact h1.fail
      · rename_i N1 hN1
        split_ifs with hN
        · have hj : Ld.jUsed < P.Jstar := not_le.mp (fun h' => hchk (Or.inl h'))
          refine rejectTail_ok hA hc ?_ (h.learners_ok Ld (List.mem_of_getElem? hLd)) hj _ _
          exact h1.withBanks (by rw [length_modifyAt]; exact h1.banks_length_le)
            (forall_mem_modifyAt _ (fun B hB => hB.scaleY _) _ _ h1.banks_ok)
        · exact h1.fail
  · exact h.fail

theorem step4Depth_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State}
    (h : StateOK P adaOK c s) (d : ℕ) (F : ℚ) :
    Always (step4Depth P d s F) (fun r => StateOK P adaOK c r.1) := by
  unfold step4Depth
  split
  · rename_i Ld Bd hLd hBd
    simp only [bp_bind_eq, bp_pure_eq]
    split_ifs with hS
    · refine Always.bind (fun res hres => ?_)
        (BankOK.validate hA (h.banks_ok Bd (List.mem_of_getElem? hBd)) _ _)
      have h1 := h.setBank hres d
      split
      · exact h1
      · exact rejectDepth_ok hA hc h1 _ _ _
      · exact rejectDepth_ok hA hc h1 _ _ _
      · exact h1.fail
    · exact h.fail
  · exact h.fail

theorem step4Loop_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), StateOK P adaOK c s →
      Always (step4Loop P ds s F) (fun r => StateOK P adaOK c r.1)
  | [], _, _, h => h
  | d :: ds, s, F, h => by
    simp only [step4Loop, bp_bind_eq]
    split_ifs
    · exact h
    · refine Always.bind (fun r hr => ?_) (step4Depth_ok hA hc h d F)
      exact step4Loop_ok hA hc ds r.1 r.2 hr

theorem step4_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State} (h : StateOK P adaOK c s) :
    Always (step4 P s) (fun r => StateOK P adaOK c r.1) :=
  step4Loop_ok hA hc _ _ _ h

/-! ## One round and the initialization -/

theorem roundStep_ok (hA : AdaInvariant P adaOK) (hc : 1 ≤ c) {s : State}
    (h : StateOK P adaOK c s) (i : ℕ) (Δ : ℤ) :
    Always (roundStep P s i Δ) (fun r => StateOK P adaOK c r.1) := by
  unfold roundStep
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs with hf
  · exact h.finish 0
  · refine Always.bind (fun s1 hs1 => ?_) (step1_ok hA hc h)
    split_ifs with h1 h2 h3
    · exact hs1.finish 0
    · exact (step2_ok hc hs1 i Δ).finish 0
    · exact (step3_ok hc (step2_ok hc hs1 i Δ)).finish 0
    · refine Always.bind (fun r4 hr4 => ?_) (step4_ok hA hc (step3_ok hc (step2_ok hc hs1 i Δ)))
      exact hr4.finish _

theorem always_fpSeedProg (P : StreamParams) : Always (fpSeedProg P) (fun r => r < P.q) := by
  have e : fpSeedProg P = (rejectUniform P.q (Nat.clog 2 P.q) P.seedTrials).bind
      (fun o => BitProg.pure (o.getD 0)) := rfl
  rw [e]
  refine Always.bind (fun o ho => ?_) (always_rejectUniform _ _ _)
  show o.getD 0 < P.q
  cases o with
  | none => exact q_pos P
  | some x => exact ho x rfl

theorem algInit_ok (hA : AdaInvariant P adaOK) : Always (algInit P) (StateOK P adaOK 1) := by
  have e : algInit P = (fpSeedProg P).bind (fun r => (newBank P).bind
      (fun B => BitProg.pure (⟨0, false, r, 0, [], [B], 0⟩ : State))) := rfl
  rw [e]
  refine Always.bind (fun r hr => ?_) (always_fpSeedProg P)
  refine Always.bind (fun B hB => ?_) (always_newBank P hA)
  refine ⟨hr, q_pos P, Nat.zero_le _, F2e2e.C.Alg.H_pos P, fun L hL => by simp at hL, fun B' hB' => ?_, le_rfl,
    by positivity⟩
  rw [List.mem_singleton] at hB'
  subst hB'
  exact hB

/-! ## The invariant `StateInv` through the sub-steps -/

theorem StateInv.of_ok {s s' : State} (hs : StateInv P adaOK s)
    (h4 : StateOK P adaOK 4 s → StateOK P adaOK 4 s')
    (h1 : StateOK P adaOK 1 s → StateOK P adaOK 1 s')
    (hf : s.failed = true → s'.failed = true) : StateInv P adaOK s' := by
  refine ⟨h4 hs.1, fun h' => h1 (hs.2 ?_)⟩
  cases hc : s.failed
  · rfl
  · exact absurd ((hf hc).symm.trans h') (by decide)

/-- `StateInv` after a bit program producing states, from the preservation of `StateOK 4` and
`StateOK 1` and the monotonicity of the failure flag. -/
theorem StateInv.always_state {p : BitProg State} {s : State} (hs : StateInv P adaOK s)
    (h4 : StateOK P adaOK 4 s → Always p (StateOK P adaOK 4))
    (h1 : StateOK P adaOK 1 s → Always p (StateOK P adaOK 1))
    (hf : Always p (fun s' => s.failed = true → s'.failed = true)) :
    Always p (StateInv P adaOK) := by
  cases hc : s.failed
  · exact Always.mono (fun _ ha => ⟨ha.1, fun _ => ha.2⟩) (always_and (h4 hs.1) (h1 (hs.2 hc)))
  · exact Always.mono (fun _ ha => ⟨ha.1, fun h' => absurd ((ha.2 hc).symm.trans h') (by decide)⟩)
      (always_and (h4 hs.1) hf)

/-- `StateInv` after a bit program producing a state and a value. -/
theorem StateInv.always_fst {β : Type} {p : BitProg (State × β)} {s : State}
    (hs : StateInv P adaOK s)
    (h4 : StateOK P adaOK 4 s → Always p (fun r => StateOK P adaOK 4 r.1))
    (h1 : StateOK P adaOK 1 s → Always p (fun r => StateOK P adaOK 1 r.1))
    (hf : Always p (fun r => s.failed = true → r.1.failed = true)) :
    Always p (fun r => StateInv P adaOK r.1) := by
  cases hc : s.failed
  · exact Always.mono (fun _ ha => ⟨ha.1, fun _ => ha.2⟩) (always_and (h4 hs.1) (h1 (hs.2 hc)))
  · exact Always.mono (fun _ ha => ⟨ha.1, fun h' => absurd ((ha.2 hc).symm.trans h') (by decide)⟩)
      (always_and (h4 hs.1) hf)

/-- Step 2 (partIII.tex L480–484): no hypothesis on the update is needed (saturation). -/
theorem step2_inv {s : State} (hs : StateInv P adaOK s) (i : ℕ) (Δ : ℤ) :
    StateInv P adaOK (step2 P i Δ s).1 :=
  hs.of_ok (fun h => step2_ok (by norm_num) h i Δ) (fun h => step2_ok le_rfl h i Δ)
    (step2_failed P i Δ s)

theorem step3Depth_inv {s : State} (hs : StateInv P adaOK s) (tr d : ℕ) :
    StateInv P adaOK (step3Depth P tr s d) :=
  hs.of_ok (fun h => step3Depth_ok (by norm_num) h tr d) (fun h => step3Depth_ok le_rfl h tr d)
    (step3Depth_pres P tr s d).2.2.2.1

theorem step3Loop_inv {s : State} (hs : StateInv P adaOK s) (tr : ℕ) (ds : List ℕ) :
    StateInv P adaOK (step3Loop P tr ds s) :=
  hs.of_ok (fun h => step3Loop_ok (by norm_num) tr ds s h) (fun h => step3Loop_ok le_rfl tr ds s h)
    (step3Loop_pres P tr ds s).2.2.2.1

theorem step3_inv {s : State} (hs : StateInv P adaOK s) : StateInv P adaOK (step3 P s) :=
  step3Loop_inv hs _ _

/-- One birth of Step 1 (partIII.tex L475–477), with the length bookkeeping of the loop. -/
theorem birthDepth_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s) {d : ℕ}
    (hl : s.learners.length ≤ d) (hb : s.banks.length ≤ d + 1) (hd : d < P.H) (d0 : ℕ) :
    Always (birthDepth P d0 d s) (fun s' => StateInv P adaOK s' ∧ s'.learners.length ≤ d + 1 ∧
      s'.banks.length ≤ d + 2) := by
  have hinv : Always (birthDepth P d0 d s) (StateInv P adaOK) :=
    hs.always_state
      (fun h => Always.mono (fun _ h' => h'.1) (birthDepth_ok hA (by norm_num) h hl hb hd d0))
      (fun h => Always.mono (fun _ h' => h'.1) (birthDepth_ok hA le_rfl h hl hb hd d0))
      (Always.mono (fun _ h' => h'.1.2.2.2) (birthDepth_birth P d0 d s))
  exact Always.mono (fun _ h' => ⟨h'.1, h'.2.2.1, h'.2.2.2⟩)
    (always_and hinv (birthDepth_ok hA (by norm_num) hs.1 hl hb hd d0))

theorem birthLoop_inv (hA : AdaInvariant P adaOK) (d0 : ℕ) :
    ∀ (k d : ℕ) (s : State), d + k ≤ P.H → StateInv P adaOK s → s.learners.length ≤ d →
      s.banks.length ≤ d + 1 → Always (birthLoop P d0 (List.range' d k) s) (StateInv P adaOK)
  | 0, _, _, _, hs, _, _ => by
    simp only [List.range'_zero, birthLoop]
    exact hs
  | k + 1, d, s, hdk, hs, hl, hb => by
    simp only [List.range'_succ, birthLoop, bp_bind_eq]
    split_ifs
    · exact hs
    · refine Always.bind (fun s' hs' => ?_) (birthDepth_inv hA hs hl hb (by omega) d0)
      exact birthLoop_inv hA d0 k (d + 1) s' (by omega) hs'.1 hs'.2.1 hs'.2.2

/-- The retirement at the start of Step 1 (partIII.tex L472–473). -/
theorem step1_take_inv {s : State} (hs : StateInv P adaOK s) (a b : ℕ) :
    StateInv P adaOK { s with learners := s.learners.take a, banks := s.banks.take b } :=
  hs.of_ok (fun h => h.take a b) (fun h => h.take a b) id

theorem step1_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s) :
    Always (step1 P s) (StateInv P adaOK) :=
  hs.always_state (fun h => step1_ok hA (by norm_num) h) (fun h => step1_ok hA le_rfl h)
    (Always.mono (fun _ h => h.2.2.2) (step1_frame P s))

/-- `rejectTail` never clears the failure flag. -/
theorem rejectTail_failed (d : ℕ) (Ld : Learner) (cInt : ℤ) (N1 : ℚ) (s : State) :
    Always (rejectTail P d Ld cInt N1 s) (fun r => s.failed = true → r.1.failed = true) := by
  unfold rejectTail
  simp only [bp_bind_eq, bp_pure_eq]
  split_ifs
  · split
    · exact always_pure (fun _ => rfl)
    · refine Always.bind_all (fun r2 => ?_) _
      split
      · exact always_pure (fun _ => rfl)
      · split
        · exact always_pure (fun _ => rfl)
        · split_ifs
          · exact always_pure id
          · exact always_pure (fun _ => rfl)
  · exact always_pure (fun _ => rfl)

/-- The tail of the rejection branch (partIII.tex L506–510), for the learner `Ld` at depth `d` with
`J_used < J_*` (as checked by `rejectDepth`); no hypothesis on `cInt` (the rescaled values are
range-checked before they are stored). -/
theorem rejectTail_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s) {d : ℕ}
    {Ld : Learner} (hLd : s.learners[d]? = some Ld) (hj : Ld.jUsed < P.Jstar) (cInt : ℤ)
    (N1 : ℚ) : Always (rejectTail P d Ld cInt N1 s) (fun r => StateInv P adaOK r.1) :=
  hs.always_fst
    (fun h => rejectTail_ok hA (by norm_num) h (h.learners_ok Ld (List.mem_of_getElem? hLd)) hj
      cInt N1)
    (fun h => rejectTail_ok hA le_rfl h (h.learners_ok Ld (List.mem_of_getElem? hLd)) hj cInt N1)
    (rejectTail_failed d Ld cInt N1 s)

theorem rejectDepth_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s)
    (d : ℕ) (pos : Bool) (Qhat : ℚ) :
    Always (rejectDepth P d pos Qhat s) (fun r => StateInv P adaOK r.1) :=
  hs.always_fst (fun h => rejectDepth_ok hA (by norm_num) h d pos Qhat)
    (fun h => rejectDepth_ok hA le_rfl h d pos Qhat)
    (Always.mono (fun _ h => h.1.2.2.2.1) (rejectDepth_out P d pos Qhat s))

theorem step4Depth_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s)
    (d : ℕ) (F : ℚ) : Always (step4Depth P d s F) (fun r => StateInv P adaOK r.1) :=
  hs.always_fst (fun h => step4Depth_ok hA (by norm_num) h d F)
    (fun h => step4Depth_ok hA le_rfl h d F)
    (Always.mono (fun _ h => h.1.2.2.2.1) (step4Depth_out P d s F))

theorem step4Loop_inv (hA : AdaInvariant P adaOK) :
    ∀ (ds : List ℕ) (s : State) (F : ℚ), StateInv P adaOK s →
      Always (step4Loop P ds s F) (fun r => StateInv P adaOK r.1)
  | [], _, _, hs => hs
  | d :: ds, s, F, hs => by
    simp only [step4Loop, bp_bind_eq]
    split_ifs
    · exact hs
    · refine Always.bind (fun r hr => ?_) (step4Depth_inv hA hs d F)
      exact step4Loop_inv hA ds r.1 r.2 hr

theorem step4_inv (hA : AdaInvariant P adaOK) {s : State} (hs : StateInv P adaOK s) :
    Always (step4 P s) (fun r => StateInv P adaOK r.1) :=
  step4Loop_inv hA _ _ _ hs

theorem finishRound_inv {s : State} (hs : StateInv P adaOK s) (F : ℚ) :
    StateInv P adaOK (finishRound s F).1 :=
  hs.of_ok (fun h => h.finish F) (fun h => h.finish F) id

end States

end F2e2e.C.Space
