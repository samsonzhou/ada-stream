import Mathlib
import F2e2e.C.ClosureJoint
import F2e2e.C.NormBank.GlueAux

/-!
# Theorem 6.4: the bank calls of a round (proofs: C-BANK; statements: C-CLOSE)

Source: `parts/partIII.tex` Theorem `R:thm:chronological-closure-and-main-proof` (L1287–1317): at every bank call
of the round, the statistical event of the bank (its ADA event, Theorem 3.6 / B's `coreFails`, and the coarse
event of the consumed group, Lemma 4.2) gives the certificate of the call (Theorem 4.9), provided the call is
covered (Theorem 5.11 (2c), `CountPart`) and the bank's counters have drift `≤ ξ` (Lemma 6.1 (iv), `BankPart`).

* `val_glue`: a `ValidateInterval(S, θ)` call of depth `d` returns `ACCEPT`, `HIGH` or `LOW` with the certificate
  for `r = (‖x_d‖² + ω)/(S + ω)`;
* `rel_glue`: a `ReleaseNumerical(mode)` call returns a value `N ≥ 0` with its numerical certificate for the bank's
  exact mode shadow;
* the bank-state part after each call and after a bank allocation (`statePart_bankNew`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

variable {P : StreamParams}

/-- Two every-path properties of a bit program hold together. -/
theorem BitAlways.and {α : Type} {Q R : α → Prop} :
    ∀ {p : BitProg α}, BitAlways Q p → BitAlways R p → BitAlways (fun a => Q a ∧ R a) p
  | _, BitAlways.pure a h1, BitAlways.pure _ h2 => BitAlways.pure a ⟨h1, h2⟩
  | _, BitAlways.bit k h1, BitAlways.bit _ h2 => BitAlways.bit k fun b => BitAlways.and (h1 b) (h2 b)

/-! ## The output shape of `ReleaseNumerical` -/

/-- The scale `c = max(lowerMedian(subgroup means), ω/2)` of a release consuming the group `grp`. -/
def relScale (P : StreamParams) (mode : Mode) (grp : List (List Row)) : ℚ :=
  max (lowerMedian (grp.map (subgroupMean P mode))) (P.omega / 2)

/-- The output shape of the logged release: with a coarse group `grp :: rest`, the ADA module answers `a`, the
logged scale is `relScale`, the bank keeps its ADA rows and drops the group; the release is `some N` exactly for a
value answer `μ̂`, `N = max(0, Lcμ̂ − ω)`. -/
def RelShape (P : StreamParams) (B : Bank) (mode : Mode) (r : (Option ℚ × Bank) × Option (ℚ × AdaNum)) : Prop :=
  ∀ grp rest, B.coarse = grp :: rest →
    ∃ a : AdaNum, r.2 = some (relScale P mode grp, a) ∧ r.1.2.ada = B.ada ∧ r.1.2.coarse = rest ∧
      (∀ μ, a = AdaNum.val μ → r.1.1 = some (max 0 ((P.L : ℚ) * relScale P mode grp * μ - P.omega))) ∧
      (a = AdaNum.abort → r.1.1 = none)

theorem bitAlways_releaseLog_shape (P : StreamParams) (B : Bank) (mode : Mode) :
    BitAlways (RelShape P B mode) (releaseLog P B mode) := by
  cases h : B.coarse with
  | nil =>
    rw [releaseLog_nil P B mode h]
    exact BitAlways.pure _ (fun grp rest hc => by rw [h] at hc; cases hc)
  | cons grp rest =>
    rw [releaseLog_cons P B mode h]
    refine BitAlways.bind' (fun res _ => ?_) (bitAlways_true _)
    rcases res with ⟨out, st⟩
    cases out with
    | val μ =>
      refine BitAlways.pure _ (fun grp' rest' hc => ?_)
      rw [h] at hc
      obtain ⟨h1, h2⟩ := List.cons.inj hc
      subst h1
      subst h2
      exact ⟨AdaNum.val μ, rfl, rfl, rfl, (fun μ' hμ => by cases hμ; rfl), (fun ha => by cases ha)⟩
    | abort =>
      refine BitAlways.pure _ (fun grp' rest' hc => ?_)
      rw [h] at hc
      obtain ⟨h1, h2⟩ := List.cons.inj hc
      subst h1
      subst h2
      exact ⟨AdaNum.abort, rfl, rfl, rfl, (fun μ' hμ => by cases hμ), (fun _ => rfl)⟩

/-! ## The bank-state part after a bank allocation -/

/-- A fresh bank with a fresh label: its rows are fresh, its coarse groups have their shape, its ADA module has
returned nothing, and no logged call carries its label. -/
theorem statePart_bankNew {o : OState} {g : Ghost} (h : StatePart P o g) (B : Bank) (lab : BankLabel)
    (hB : ((∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧ (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) ∧
      B.adaSt.rej = 0 ∧ CoarseShape P B ∧ B.coarse.length = P.Rmax)
    (hfresh : ∀ rec ∈ g.calls, rec.lab ≠ lab) :
    StatePart P { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [lab], hists := g.hists ++ [[]] } := by
  have hll : g.labels.length = o.banks.length := h.rows.len_labels
  refine ⟨rowsOK_bankNew h.rows B hB.1 lab, ?_, ?_, ?_⟩
  · intro B' hB'
    rcases List.mem_append.mp hB' with hB' | hB'
    · exact h.shape B' hB'
    · rw [List.mem_singleton] at hB'
      rw [hB']
      exact hB.2.2.1
  · intro idx B' hB'
    simp only at hB'
    rcases Nat.lt_or_ge idx o.banks.length with hlt | hge
    · rw [List.getElem?_append_left hlt] at hB'
      rw [labelAt_snoc g lab _ (by rw [hll]; exact hlt)]
      exact h.rej idx B' hB'
    · rw [List.getElem?_append_right hge] at hB'
      have hidx : idx = o.banks.length := by
        by_contra hne
        have : [B][idx - o.banks.length]? = none := by
          rw [List.getElem?_eq_none_iff]; simp; omega
        rw [this] at hB'; simp at hB'
      subst hidx
      rw [Nat.sub_self] at hB'
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hB'
      subst hB'
      rw [← hll, labelAt_snoc_last]
      show B.adaSt.rej = nRej lab g.calls
      rw [nRej_eq_zero_of_fresh hfresh]
      exact hB.2.1
  · intro idx B' hB'
    simp only at hB'
    rcases Nat.lt_or_ge idx o.banks.length with hlt | hge
    · rw [List.getElem?_append_left hlt] at hB'
      rw [labelAt_snoc g lab _ (by rw [hll]; exact hlt)]
      exact h.coarseLen idx B' hB'
    · rw [List.getElem?_append_right hge] at hB'
      have hidx : idx = o.banks.length := by
        by_contra hne
        have : [B][idx - o.banks.length]? = none := by
          rw [List.getElem?_eq_none_iff]; simp; omega
        rw [this] at hB'; simp at hB'
      subst hidx
      rw [Nat.sub_self] at hB'
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hB'
      subst hB'
      rw [← hll, labelAt_snoc_last]
      show B.coarse.length + nNum lab g.calls = P.Rmax
      rw [nNum_eq_zero_of_fresh hfresh, add_zero]
      exact hB.2.2.2

/-- The every-path facts of a fresh bank used by `statePart_bankNew`. -/
theorem bitAlways_newBank_all (P : StreamParams) :
    BitAlways (fun B : Bank => ((∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧
      (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) ∧
      B.adaSt.rej = 0 ∧ CoarseShape P B ∧ B.coarse.length = P.Rmax) (newBank P) := by
  have hlen : BitAlways (fun B : Bank => B.coarse.length = P.Rmax) (newBank P) := by
    rw [newBank_eq_bind]
    have h2 := bitAlways_sampleList _ (bitAlways_true (sampleList (sampleList (newRow P) 32) P.gCoarse)) P.Rmax
    refine BitAlways.bind' (fun ada _ => ?_) (bitAlways_true _)
    refine BitAlways.bind' (fun coarse hco => ?_) h2
    refine BitAlways.bind' (fun st _ => ?_) (bitAlways_true _)
    exact BitAlways.pure _ hco.1
  exact (bitAlways_newBank P).and ((bitAlways_newBank_rej' P).and ((bitAlways_newBank_shape P).and hlen))

/-! ## The bank calls -/

/-- **A validation call** (depth `d`, bank `d`, in Step 4 before depth `d` is evaluated): on the ADA event of the
bank, the certificate is `ACCEPT`, `HIGH` or `LOW` (no abort: the call is covered; no terminal rejection: fewer
than `J_max` earlier rejections), with Theorem 4.9's certificate for `r = (‖x_d‖² + ω)/(S + ω)`; the bank-state
part holds after the call. -/
theorem val_glue (hP : ParamsOK P) {c : CState} {o : OState} {g : Ghost} {d : ℕ}
    (h : JointInv P (.evals (d + 1)) c o g) (hd : d < P.H) (ht : (shadowOf P g).t ≤ P.m)
    (hbox : ‖(shadowOf P g).x0‖ ≤ (P.W : ℝ)) (gF : Ghost) (hgood : AdaGood P (g.labelAt d) gF)
    {B : Bank} (hB : o.banks[d]? = some B) {S0 θ : ℚ} (hS0 : 0 ≤ S0) (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ (1 / 2) ^ 16)
    (r : AdaCert × Bank)
    (hr : (r.2.ada = B.ada ∧ r.2.coarse = B.coarse) ∧
      (r.2.adaSt.rej = B.adaSt.rej + (if coreIsReject (Sum.inl r.1) = true then 1 else 0) ∧
        (r.1 = AdaCert.termHigh ∨ r.1 = AdaCert.termLow → (bankAda P).J ≤ B.adaSt.rej)))
    (hpre : g.calls ++ [valRec P g d B S0 θ r.1] <+: gF.calls) :
    (r.1 = AdaCert.accept ∨ r.1 = AdaCert.high ∨ r.1 = AdaCert.low) ∧
      ValCertCore (P.eta : ℝ) (θ : ℝ)
        ((‖(shadowOf P g).x d‖ ^ 2 + (P.omega : ℝ)) / ((S0 : ℝ) + (P.omega : ℝ))) (Sum.inl r.1) ∧
      StatePart P { o with banks := setAt r.2 d o.banks }
        { g with calls := g.calls ++ [valRec P g d B S0 θ r.1] } := by
  have hdlive : d < Tree.Phase.live P.H (.evals (d + 1)) := hd
  have htree := h.tp.tree
  have hlenB : d < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hdh : d < g.hists.length := by rw [h.sp.rows.len_hists]; exact hlenB
  have hdl : d < g.labels.length := by rw [h.sp.rows.len_labels]; exact hlenB
  have hnev : g.events.length ≤ P.T := by
    have := countPart_nev_le h.cp ht
    omega
  -- coverage (Theorem 5.11 (2c))
  have hjU := TreePart.jUsed_lt h.tp hdlive
  obtain ⟨hint, hrejlt⟩ := countPart_cov_validate hP h.cp hd ht hjU
  have hInt : (callReq P (valRec P g d B S0 θ r.1)).isInterval = true := rfl
  -- the ADA event at this call
  have hcorr : coreCorrect (unifD P) (bankAda P).hA (P.aNum : ℝ) (callReq P (valRec P g d B S0 θ r.1))
      (Sum.inl r.1) :=
    coreCorrect_of_adaGood P (g.labelAt d) gF hgood g.calls _ hpre rfl rfl hrejlt.le (fun _ => hint)
      (fun hI => by rw [hInt] at hI; cases hI)
  -- no abort, no terminal rejection
  have hcert : r.1 = AdaCert.accept ∨ r.1 = AdaCert.high ∨ r.1 = AdaCert.low := by
    have hrej_eq := h.sp.rej d B hB
    rcases hc : r.1 with _ | _ | _ | _ | _ | _
    · exact Or.inl rfl
    · exact Or.inr (Or.inl rfl)
    · exact Or.inr (Or.inr rfl)
    · exfalso
      have := hr.2.2 (Or.inl hc)
      omega
    · exfalso
      have := hr.2.2 (Or.inr hc)
      omega
    · exfalso
      rw [hc] at hcorr
      exact not_coreCorrect_abort_int hInt hcorr
  -- the certificate (Theorem 4.9)
  have hX : (bankShadowXY P (g.histAt d)).1 = (shadowOf P g).x d := h.bp.shadowX d hdh
  have hcertV := validate_cert P hP (valRec P g d B S0 θ r.1) rfl rfl
    (by
      show (bankShadowXY P (g.histAt d)).1 (regIdx P) = 0
      rw [hX]
      exact x_reg_zero htree (fun D hD => by cases hD) hdlive.le)
    (by
      show √(‖(bankShadowXY P (g.histAt d)).1‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ)
      rw [hX]
      exact sqrt_x_le_V htree hbox hdlive.le)
    (fun ζ => BankPart.precX htree h.bp hnev hdh hdlive.le hd.le ζ)
    hS0 hθ0 hθ1 (Sum.inl r.1) hcorr
  refine ⟨hcert, ?_, ?_⟩
  · have e : (valRec P g d B S0 θ r.1).hist = g.histAt d := rfl
    rw [e, hX] at hcertV
    exact hcertV
  · -- the bank-state part after the call
    have hrej1 : nRej (g.labelAt d) (g.calls ++ [valRec P g d B S0 θ r.1]) =
        nRej (g.labelAt d) g.calls + (if coreIsReject (Sum.inl r.1) = true then 1 else 0) := by
      rw [nRej_append]
      simp [valRec]
    have hnum1 : nNum (g.labelAt d) (g.calls ++ [valRec P g d B S0 θ r.1]) = nNum (g.labelAt d) g.calls := by
      rw [nNum_append]
      simp [valRec]
    refine ⟨rowsOK_setAt h.sp.rows d hB hr.1.1 (fun grp hg => hr.1.2 ▸ hg) rfl rfl, ?_, ?_, ?_⟩
    · intro B' hB'
      rcases mem_setAt hB' with hB' | hB'
      · exact h.sp.shape B' hB'
      · rw [hB']
        intro grp hgrp
        rw [hr.1.2] at hgrp
        exact h.sp.shape B (List.mem_of_getElem? hB) grp hgrp
    · intro j B' hB'
      simp only [getElem?_setAt] at hB'
      split_ifs at hB' with hj
      · obtain ⟨hjd, -⟩ := hj
        simp only [Option.some.injEq] at hB'
        rw [← hB', hjd]
        show r.2.adaSt.rej = nRej (g.labelAt d) (g.calls ++ [valRec P g d B S0 θ r.1])
        rw [hr.2.1, h.sp.rej d B hB, hrej1]
      · have hjl : j < g.labels.length := by
          rw [h.sp.rows.len_labels]; exact (List.getElem?_eq_some_iff.mp hB').1
        have hne : (valRec P g d B S0 θ r.1).lab ≠ g.labelAt j := by
          intro heq
          have hdj := countPart_label_inj h.cp hdl hjl heq
          exact hj ⟨hdj.symm, by rw [← hdj]; exact hlenB⟩
        show B'.adaSt.rej = nRej (g.labelAt j) (g.calls ++ [valRec P g d B S0 θ r.1])
        rw [(counts_append_other g.calls _ hne).2.2]
        exact h.sp.rej j B' hB'
    · intro j B' hB'
      simp only [getElem?_setAt] at hB'
      split_ifs at hB' with hj
      · obtain ⟨hjd, -⟩ := hj
        simp only [Option.some.injEq] at hB'
        rw [← hB', hjd]
        show r.2.coarse.length + nNum (g.labelAt d) (g.calls ++ [valRec P g d B S0 θ r.1]) = P.Rmax
        rw [hr.1.2, hnum1]
        exact h.sp.coarseLen d B hB
      · have hjl : j < g.labels.length := by
          rw [h.sp.rows.len_labels]; exact (List.getElem?_eq_some_iff.mp hB').1
        have hne : (valRec P g d B S0 θ r.1).lab ≠ g.labelAt j := by
          intro heq
          have hdj := countPart_label_inj h.cp hdl hjl heq
          exact hj ⟨hdj.symm, by rw [← hdj]; exact hlenB⟩
        show B'.coarse.length + nNum (g.labelAt j) (g.calls ++ [valRec P g d B S0 θ r.1]) = P.Rmax
        rw [(counts_append_other g.calls _ hne).2.1]
        exact h.sp.coarseLen j B' hB'

/-- **A release call** on bank `idx` in mode `mode` (`PRIMARY` with `idx ≤ live`, `DIFF` with a live client), at a
moment where the tree invariant, the bank part and the bank-state part hold: on the ADA event and the coarse events
of the bank, if the call is covered, the release returns a value `N ≥ 0` with Theorem 4.9's numerical certificate
for the bank's exact mode shadow, the logged ADA answer is a value, and the bank-state part holds after the call. -/
theorem rel_glue (hP : ParamsOK P) {ph : Tree.Phase} {R : Tree.Regs} {S : Tree.TreeSt P} {o : OState}
    {g : Ghost} {nev idx : ℕ} {mode : Mode}
    (htree : Tree.TreeInv P ph R S) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (hbp : BankPart P ph S g.hists nev)
    (hnev : nev ≤ P.T) (hsp : StatePart P o g)
    (hinj : ∀ j < g.labels.length, g.labelAt j = g.labelAt idx → j = idx)
    (hidx : idx < g.hists.length) (hH : idx < P.H) (hlive : idx ≤ ph.live P.H)
    (hliveY : mode = Mode.diff → idx < ph.live P.H)
    (hph : ∀ D, ph = Tree.Phase.guards D → D ≤ P.H)
    (gF : Ghost) (hgood : AdaGood P (g.labelAt idx) gF) (hcgood : ∀ k, CoarseGood P (g.labelAt idx) k gF)
    {B : Bank} (hB : o.banks[idx]? = some B)
    (hcov : nNum (g.labelAt idx) g.calls + 1 ≤ (bankAda P).R ∧ nRej (g.labelAt idx) g.calls ≤ (bankAda P).J)
    (r : (Option ℚ × Bank) × Option (ℚ × AdaNum))
    (hr : RelShape P B mode r ∧ r.1.2.adaSt.rej = B.adaSt.rej)
    (hpre : g.calls ++ [relRec g idx B mode r] <+: gF.calls) :
    ∃ N : ℚ, r.1.1 = some N ∧ 0 ≤ N ∧
      NumCert (P.eta : ℝ) (P.omega : ℝ) (‖bankShadow P mode (g.histAt idx)‖ ^ 2) (N : ℝ) ∧
      (∃ a : AdaNum, (relRec g idx B mode r).out = some (Sum.inr a)) ∧
      StatePart P { o with banks := setAt r.1.2 idx o.banks }
        { g with calls := g.calls ++ [relRec g idx B mode r] } := by
  have hlenB : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hidl : idx < g.labels.length := by rw [hsp.rows.len_labels]; exact hlenB
  have hR : (bankAda P).R = P.Rmax := by simp only [bankAda, adaParams, StreamParams.bankR]
  -- the consumed coarse group (the cap leaves at least one)
  have hcl := hsp.coarseLen idx B hB
  obtain ⟨grp, rest, hco⟩ : ∃ grp rest, B.coarse = grp :: rest := by
    cases hc : B.coarse with
    | nil =>
      rw [hc] at hcl
      have h1 := hcov.1
      rw [hR] at h1
      simp only [List.length_nil, zero_add] at hcl
      omega
    | cons grp rest => exact ⟨grp, rest, rfl⟩
  obtain ⟨a, hr2, hrada, hrco, hval, habort⟩ := hr.1 grp rest hco
  have hrec_out : (relRec g idx B mode r).out = some (Sum.inr a) := by
    show r.2.map (fun x => Sum.inr x.2) = some (Sum.inr a)
    rw [hr2]
    rfl
  have hrec_scale : (relRec g idx B mode r).scale = relScale P mode grp := by
    show (r.2.map Prod.fst).getD 0 = relScale P mode grp
    rw [hr2, Option.map_some, Option.getD_some]
  have hNumReq : (callReq P (relRec g idx B mode r)).isInterval = false := rfl
  -- the ADA event at this call
  have hcorr := coreCorrect_of_adaGood P (g.labelAt idx) gF hgood g.calls (relRec g idx B mode r) hpre rfl
    hrec_out hcov.2 (fun hI => by rw [hNumReq] at hI; cases hI) (fun _ => hcov.1)
  -- the answer is a value
  obtain ⟨μ, rfl⟩ : ∃ μ, a = AdaNum.val μ := by
    cases a with
    | val μ => exact ⟨μ, rfl⟩
    | abort => exact absurd hcorr (not_coreCorrect_abort_num hNumReq)
  refine ⟨max 0 ((P.L : ℚ) * relScale P mode grp * μ - P.omega), hval μ rfl, le_max_left _ _, ?_,
    ⟨AdaNum.val μ, hrec_out⟩, ?_⟩
  · -- the numerical certificate (Theorem 4.9)
    have hgrp : grp ∈ B.coarse := by rw [hco]; exact List.mem_cons_self
    have hshape := hsp.shape B (List.mem_of_getElem? hB) grp hgrp
    have hrows : ∀ sub ∈ grp, ∀ x ∈ sub, RowOK P (g.histAt idx) x :=
      fun sub hsub x hx => (hsp.rows.rows idx B hB).2 grp hgrp sub hsub x hx
    have hX : (bankShadowXY P (g.hists.getD idx [])).1 = S.x idx := hbp.shadowX idx hidx
    have hreg : bankShadow P mode (g.histAt idx) (regIdx P) = 0 := by
      cases mode with
      | primary =>
        show (bankShadowXY P (g.hists.getD idx [])).1 (regIdx P) = 0
        rw [hX]
        exact x_reg_zero htree hph hlive
      | diff =>
        have hY : (bankShadowXY P (g.hists.getD idx [])).2 = S.y idx := hbp.shadowY idx hidx (hliveY rfl)
        show ((bankShadowXY P (g.hists.getD idx [])).1 - (bankShadowXY P (g.hists.getD idx [])).2) (regIdx P) = 0
        rw [hX, hY, PiLp.sub_apply, x_reg_zero htree hph hlive, y_reg_zero htree hph (hliveY rfl), sub_zero]
    have hV : √(‖bankShadow P mode (g.histAt idx)‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ) := by
      cases mode with
      | primary =>
        show √(‖(bankShadowXY P (g.hists.getD idx [])).1‖ ^ 2 + (P.omega : ℝ)) ≤ (P.V : ℝ)
        rw [hX]
        exact sqrt_x_le_V htree hbox hlive
      | diff =>
        have hY : (bankShadowXY P (g.hists.getD idx [])).2 = S.y idx := hbp.shadowY idx hidx (hliveY rfl)
        have hxy : S.x idx - S.y idx = S.r idx := by
          rw [← Tree.TreeState.r_add_y S idx]
          abel
        show √(‖(bankShadowXY P (g.hists.getD idx [])).1 - (bankShadowXY P (g.hists.getD idx [])).2‖ ^ 2 +
          (P.omega : ℝ)) ≤ (P.V : ℝ)
        rw [hX, hY, hxy]
        exact (Tree.vector_bounds_inv htree hbox).2.2.1 idx (hliveY rfl) 0 (by norm_num) _ (by simp)
    have hcOK : CoarseOK P (relRec g idx B mode r) :=
      coarseOK_of_good hcgood (hpre.subset (List.mem_append_right _ (List.mem_singleton_self _))) rfl rfl
        (by show B.coarse ≠ []; rw [hco]; exact List.cons_ne_nil _ _)
    have hcert := release_cert P hP (relRec g idx B mode r) rfl hco hshape hrows (by rw [hrec_scale, relScale])
      hreg hV (fun ζ => BankPart.precX htree hbp hnev hidx hlive hH.le ζ)
      (fun hm ζ => BankPart.precY htree hbp hnev hidx (hliveY hm) ζ) hcOK μ hcorr
    rw [hrec_scale] at hcert
    exact hcert
  · -- the bank-state part after the call
    have hrej1 : nRej (g.labelAt idx) (g.calls ++ [relRec g idx B mode r]) = nRej (g.labelAt idx) g.calls := by
      rw [nRej_append, hrec_out]
      have h0 : coreIsReject (Sum.inr (AdaNum.val μ)) = false := rfl
      simp only [h0, Bool.and_false, Bool.false_eq_true, if_false, add_zero]
    have hnum1 : nNum (g.labelAt idx) (g.calls ++ [relRec g idx B mode r]) =
        nNum (g.labelAt idx) g.calls + 1 := by
      rw [nNum_append, hrec_out]
      have hl : (relRec g idx B mode r).lab = g.labelAt idx := rfl
      have hk : (relRec g idx B mode r).kind = CallKind.release mode := rfl
      rw [hl, hk]
      simp only [decide_true, Option.isSome_some, Bool.and_self, if_true]
    refine ⟨rowsOK_setAt hsp.rows idx hB hrada (fun grp' hg => by
      rw [hrco] at hg; rw [hco]; exact List.mem_cons_of_mem _ hg) rfl rfl, ?_, ?_, ?_⟩
    · intro B' hB'
      rcases mem_setAt hB' with hB' | hB'
      · exact hsp.shape B' hB'
      · rw [hB']
        intro grp' hg
        rw [hrco] at hg
        exact hsp.shape B (List.mem_of_getElem? hB) grp' (by rw [hco]; exact List.mem_cons_of_mem _ hg)
    · intro j B' hB'
      simp only [getElem?_setAt] at hB'
      split_ifs at hB' with hj
      · obtain ⟨hjd, -⟩ := hj
        simp only [Option.some.injEq] at hB'
        rw [← hB', hjd]
        show r.1.2.adaSt.rej = nRej (g.labelAt idx) (g.calls ++ [relRec g idx B mode r])
        rw [hr.2, hsp.rej idx B hB, hrej1]
      · have hjl : j < g.labels.length := by
          rw [hsp.rows.len_labels]; exact (List.getElem?_eq_some_iff.mp hB').1
        have hne : (relRec g idx B mode r).lab ≠ g.labelAt j := by
          intro heq
          have hji := hinj j hjl heq.symm
          exact hj ⟨hji, by rw [hji]; exact hlenB⟩
        show B'.adaSt.rej = nRej (g.labelAt j) (g.calls ++ [relRec g idx B mode r])
        rw [(counts_append_other g.calls _ hne).2.2]
        exact hsp.rej j B' hB'
    · intro j B' hB'
      simp only [getElem?_setAt] at hB'
      split_ifs at hB' with hj
      · obtain ⟨hjd, -⟩ := hj
        simp only [Option.some.injEq] at hB'
        rw [← hB', hjd]
        show r.1.2.coarse.length + nNum (g.labelAt idx) (g.calls ++ [relRec g idx B mode r]) = P.Rmax
        rw [hrco, hnum1]
        rw [hco, List.length_cons] at hcl
        omega
      · have hjl : j < g.labels.length := by
          rw [hsp.rows.len_labels]; exact (List.getElem?_eq_some_iff.mp hB').1
        have hne : (relRec g idx B mode r).lab ≠ g.labelAt j := by
          intro heq
          have hji := hinj j hjl heq.symm
          exact hj ⟨hji, by rw [hji]; exact hlenB⟩
        show B'.coarse.length + nNum (g.labelAt j) (g.calls ++ [relRec g idx B mode r]) = P.Rmax
        rw [(counts_append_other g.calls _ hne).2.1]
        exact hsp.coarseLen j B' hB'

end F2e2e.C.Closure
