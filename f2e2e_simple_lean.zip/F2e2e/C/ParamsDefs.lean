import F2e2e.Spec

/-!
# Theorem (C): the public parameters (definitions)

Part II §1.4, Definitions `R:def:dyadic-normalization` (partII.tex L154–164), `R:def:global-parameters`
(L166–194) and `R:def:dyadic-grids` (L196–207); Part III Definition `R:def:total-behavior` (partIII.tex
L445–463: ranges and `h_leaf`), Algorithm `R:alg:zero-fingerprint` (partII.tex L219: fingerprint prime and
seed trials), Algorithm `R:alg:regularized-norm-bank` (partIII.tex L205–207: the bank's ADA instance, coarse
groups, row field), and the guard coordinates `g(d,t)` (partII.tex L189).

Every public parameter is a **computable** function of the Spec's `P : StreamParams`
(`P = (n, m, U, epsExp, betaExp)` with `epsExp = ⌈log₂ ε⁻¹⌉`, `betaExp = ⌈log₂ β⁻¹⌉`), in exact `ℕ`/`ℚ`
arithmetic, exactly as Def 1.5 prescribes ("All prescribed arithmetic and comparisons are exact rational or
integer operations", L155):

* once `ε₀ = 2^{-epsExp}` and `β₀ = 2^{-betaExp}` are substituted, the argument of every `⌈log₂ ·⌉` of the
  paper is a natural number times a power of two, so `⌈log₂(2^k · N)⌉ = k + Nat.clog 2 N`; the definitions
  below use the right-hand side (the link lemmas to the paper's literal `⌈log₂ ·⌉` forms are in
  `F2e2e.C.ParamsFacts` / `F2e2e.C.ParamsReal`);
* the only square root, `⌈log₂(8√T)⌉` in `γ`, equals `Nat.clog 4 (64 T)`;
* every power-of-two parameter `x = 2^{-e}` is given by its exponent `e : ℕ` (`eEta`, `eGamma`, `eNu`,
  `eHg`, …) and by its value `(1/2)^e : ℚ` (`eta`, `gamma`, `nu`, `hg`, …); powers of two `≥ 1` are
  natural numbers (`B = 2^logB`, `G = B^{H+2}`, `Ud d = 2^{eU d}`, `K0`, `Zmax`, …).

All declarations live in the namespace `F2e2e.StreamParams` (dot notation `P.eta`, `P.H`, …).
Notation clash: `P.L = 16 s` is the clipping cutoff `L` of Sections 1.4/4; the bit scale `ℒ` of
eq. `R:eq:calL-def` is `P.calL`.
-/

namespace F2e2e

namespace StreamParams

/-! ## Definition 1.5 (`R:def:dyadic-normalization`, partII.tex L154–164) -/

/-- `ε₀ = 2^{-⌈log₂(1/ε)⌉}` (eq. `R:eq:dyadic-eps-beta`, L157). -/
def eps0 (P : StreamParams) : ℚ := (1 / 2) ^ P.epsExp

/-- `β₀ = 2^{-⌈log₂(1/β)⌉}` (eq. `R:eq:dyadic-eps-beta`, L157). -/
def beta0 (P : StreamParams) : ℚ := (1 / 2) ^ P.betaExp

/-- The integer bit scale `ℒ = ⌈log₂(2^100 (n+2)(m+2)(U+2)/(ε₀β₀))⌉` (eq. `R:eq:calL-def`, L161), computed
exactly as `100 + epsExp + betaExp + ⌈log₂((n+2)(m+2)(U+2))⌉`. -/
def calL (P : StreamParams) : ℕ :=
  100 + P.epsExp + P.betaExp + Nat.clog 2 ((P.n + 2) * (P.m + 2) * (P.U + 2))

/-! ## Definition 1.6 (`R:def:global-parameters`, partII.tex L166–194) -/

/-- Tree depth `H = 1 + ⌈log₂ max{1, m}⌉` (eq. `R:eq:param-H`, L169; partIII.tex L425). -/
def H (P : StreamParams) : ℕ := 1 + Nat.clog 2 (max 1 P.m)

/-- `T = 2^12 (m+1)(H+1)^3` (eq. `R:eq:param-T`, L170). -/
def T (P : StreamParams) : ℕ := 2 ^ 12 * (P.m + 1) * (P.H + 1) ^ 3

/-- Augmented dimension `D_* = n + T + 1` (eq. `R:eq:param-Dstar-W`, L171). -/
def Dstar (P : StreamParams) : ℕ := P.n + P.T + 1

/-- `W = nU + 1` (eq. `R:eq:param-Dstar-W`, L171). -/
def W (P : StreamParams) : ℕ := P.n * P.U + 1

/-- Exponent of `η`: `⌈log₂(2^20 (H+1)^2/ε₀)⌉ = 20 + epsExp + ⌈log₂((H+1)^2)⌉` (eq. `R:eq:param-eta`, L172). -/
def eEta (P : StreamParams) : ℕ := 20 + P.epsExp + Nat.clog 2 ((P.H + 1) ^ 2)

/-- Local accuracy `η = 2^{-⌈log₂(2^20 (H+1)^2/ε₀)⌉}` (eq. `R:eq:param-eta`, L172). -/
def eta (P : StreamParams) : ℚ := (1 / 2) ^ P.eEta

/-- Exponent of `γ`: `⌈log₂(8√T)⌉ = ⌈log₄(64 T)⌉ = Nat.clog 4 (64 T)` (eq. `R:eq:param-gamma`, L173). -/
def eGamma (P : StreamParams) : ℕ := Nat.clog 4 (64 * P.T)

/-- Guard scale `γ = 2^{-⌈log₂(8√T)⌉}` (eq. `R:eq:param-gamma`, L173). -/
def gamma (P : StreamParams) : ℚ := (1 / 2) ^ P.eGamma

/-- `log₂ B = 4 + ⌈log₂(8√T)⌉` (eq. `R:eq:param-B`, L174). -/
def logB (P : StreamParams) : ℕ := 4 + P.eGamma

/-- `B = 16/γ = 2^{4 + ⌈log₂(8√T)⌉}` (eq. `R:eq:param-B`, L174). -/
def B (P : StreamParams) : ℕ := 2 ^ P.logB

/-- `V_0 = W`, `V_{d+1} = (1 + 2B^d) V_d` (eq. `R:eq:param-Vd`, L175; the paper uses `d ≤ H`). -/
def Vd (P : StreamParams) : ℕ → ℕ
  | 0 => P.W
  | d + 1 => (1 + 2 * P.B ^ d) * Vd P d

/-- Exponent of `𝒰_d`: `⌈log₂(2V_d^2)⌉` (eq. `R:eq:param-Ud`, L176). -/
def eU (P : StreamParams) (d : ℕ) : ℕ := Nat.clog 2 (2 * P.Vd d ^ 2)

/-- Envelope ceiling `𝒰_d = 𝒰_{d,0} = 2^{⌈log₂(2V_d^2)⌉}` (eq. `R:eq:param-Ud`, L176). -/
def Ud (P : StreamParams) (d : ℕ) : ℕ := 2 ^ P.eU d

/-- Exponent of `𝒰_*`: `log₂ 𝒰_{H-1}`. -/
def eUstar (P : StreamParams) : ℕ := P.eU (P.H - 1)

/-- `𝒰_* = max_{0 ≤ d < H} 𝒰_d = 𝒰_{H-1}` (eq. `R:eq:param-Ustar`, L176; the maximum property is
`Ud_le_Ustar`). -/
def Ustar (P : StreamParams) : ℕ := 2 ^ P.eUstar

/-- `V = 8 B^{H+1} V_H + 2` (eq. `R:eq:param-V-G`, L177). -/
def V (P : StreamParams) : ℕ := 8 * P.B ^ (P.H + 1) * P.Vd P.H + 2

/-- `log₂ G = (H+2) log₂ B`. -/
def logG (P : StreamParams) : ℕ := (P.H + 2) * P.logB

/-- `G = B^{H+2}` (eq. `R:eq:param-V-G`, L177). -/
def G (P : StreamParams) : ℕ := P.B ^ (P.H + 2)

/-- Exponent of `ν`: `log₂(1/ν) = log₂(1/γ) + log₂(1/η) + H + 20`. -/
def eNu (P : StreamParams) : ℕ := P.eGamma + P.eEta + P.H + 20

/-- Norm floor `ν = γ η 2^{-H-20}` (eq. `R:eq:param-nu-Emin`, L178). -/
def nu (P : StreamParams) : ℚ := (1 / 2) ^ P.eNu

/-- `E_min = (η^2/256) ν^2` (eq. `R:eq:param-nu-Emin`, L178). -/
def Emin (P : StreamParams) : ℚ := P.eta ^ 2 / 256 * P.nu ^ 2

/-- `K_epoch = ⌈log₂(2^20 𝒰_* B^{2H}/(η^2ν^2))⌉` (eq. `R:eq:param-Kepoch-Jstar`, L179); the argument is a power
of two, so this is `20 + log₂ 𝒰_* + 2H log₂ B + 2 log₂(1/η) + 2 log₂(1/ν)` exactly. -/
def Kepoch (P : StreamParams) : ℕ :=
  20 + P.eUstar + 2 * P.H * P.logB + 2 * P.eEta + 2 * P.eNu

/-- `K_0 = ⌈128/η^2⌉ = 2^{7 + 2 log₂(1/η)}` (L188). -/
def K0 (P : StreamParams) : ℕ := 2 ^ (7 + 2 * P.eEta)

/-- Lifetime correction cap `J_* = ⌈128/η^2⌉ (K_epoch + 1)` (eq. `R:eq:param-Kepoch-Jstar`, L179). -/
def Jstar (P : StreamParams) : ℕ := P.K0 * (P.Kepoch + 1)

/-- Per-bank rejection cap `J_max = 2J_*` (eq. `R:eq:param-Jmax-Rmax`, L180). -/
def Jmax (P : StreamParams) : ℕ := 2 * P.Jstar

/-- Per-bank numerical-release cap `R_max = 4J_* + 2` (eq. `R:eq:param-Jmax-Rmax`, L180). -/
def Rmax (P : StreamParams) : ℕ := 4 * P.Jstar + 2

/-- Moment order `s = log₂(1/η) + 22` (eq. `R:eq:param-s-L-a-betaB`, L182). -/
def s (P : StreamParams) : ℕ := P.eEta + 22

/-- Clipping cutoff `L = 16 s` (eq. `R:eq:param-s-L-a-betaB`, L182). Not the bit scale `ℒ` (`calL`). -/
def L (P : StreamParams) : ℕ := 16 * P.s

/-- Norm-bank ADA accuracy `a_num = η/(2^14 L)` (eq. `R:eq:param-s-L-a-betaB`, L182; partIII.tex L168). -/
def aNum (P : StreamParams) : ℚ := P.eta / (2 ^ 14 * P.L)

/-- Validation accuracy `a_val = η/(16 L)` (eq. `R:eq:param-s-L-a-betaB`, L182; partIII.tex L168). -/
def aVal (P : StreamParams) : ℚ := P.eta / (16 * P.L)

/-- Per-bank failure budget `β_B = β₀/(64 m (H+1))` (eq. `R:eq:param-s-L-a-betaB`, L182). -/
def betaB (P : StreamParams) : ℚ := P.beta0 / (64 * P.m * (P.H + 1))

/-- Guard coordinate `g(d,t) = n + H(t-1) + d + 1` of depth `d` at (paper, 1-based) round `t` (L189). -/
def guardCoord (P : StreamParams) (d t : ℕ) : ℕ := P.n + P.H * (t - 1) + d + 1

/-! ## Definition 1.7 (`R:def:dyadic-grids`, partII.tex L196–207) and Remark 1.8 (L209–211) -/

/-- Exponent of `h_{g,unrefined} = γην/2^20` (L197). -/
def eHgUnref (P : StreamParams) : ℕ := P.eGamma + P.eEta + P.eNu + 20

/-- Unrefined guard grid `h_{g,unrefined} = γην/2^20` (L197). -/
def hgUnref (P : StreamParams) : ℚ := (1 / 2) ^ P.eHgUnref

/-- Exponent of `h_g`: `log₂(1/h_{g,unrefined}) + 2H log₂ B` (Remark 1.8). -/
def eHg (P : StreamParams) : ℕ := P.eHgUnref + 2 * P.H * P.logB

/-- Guard grid `h_g = γην B^{-2H}/2^20 = h_{g,unrefined} B^{-2H}` (eq. `R:eq:grid-hg`, L199). -/
def hg (P : StreamParams) : ℚ := (1 / 2) ^ P.eHg

/-- Tag error budget `e_C = h_g/(2^10 γ V)` (eq. `R:eq:grid-eC-hC`, L200; not a power of two). -/
def eC (P : StreamParams) : ℚ := P.hg / (2 ^ 10 * P.gamma * P.V)

/-- Exponent of `h_C`: `⌈log₂(TG/e_C)⌉`, where `TG/e_C = TV · 2^{(H+1) log₂ B + 14 + log₂(1/h_g)}`. -/
def eHC (P : StreamParams) : ℕ := (P.H + 1) * P.logB + 14 + P.eHg + Nat.clog 2 (P.T * P.V)

/-- Tag grid `h_C = 2^{-⌈log₂(TG/e_C)⌉}` (eq. `R:eq:grid-eC-hC`, L200). -/
def hC (P : StreamParams) : ℚ := (1 / 2) ^ P.eHC

/-- Exponent of `σ`: `⌈log₂(2^40 T G^2 (V+1)^2 D_*/(η^4 ν^2))⌉`. -/
def eSigma (P : StreamParams) : ℕ :=
  40 + 2 * P.logG + 4 * P.eEta + 2 * P.eNu + Nat.clog 2 (P.T * (P.V + 1) ^ 2 * P.Dstar)

/-- Regularizer coordinate `σ = 2^{-⌈log₂(2^40 T G^2 (V+1)^2 D_*/(η^4ν^2))⌉}` (eq. `R:eq:grid-sigma-omega`,
L201). -/
def sigma (P : StreamParams) : ℚ := (1 / 2) ^ P.eSigma

/-- Exponent of `ω = σ^2`. -/
def eOmega (P : StreamParams) : ℕ := 2 * P.eSigma

/-- Regularizer `ω = σ^2` (eq. `R:eq:grid-sigma-omega`, L201). -/
def omega (P : StreamParams) : ℚ := P.sigma ^ 2

/-- Exponent of `h_P`: `⌈log₂(2^40 T G^2 D_*/(η^3 ν^2))⌉`. -/
def eHP (P : StreamParams) : ℕ :=
  40 + 2 * P.logG + 3 * P.eEta + 2 * P.eNu + Nat.clog 2 (P.T * P.Dstar)

/-- Cache grid `h_P = 2^{-⌈log₂(2^40 T G^2 D_*/(η^3ν^2))⌉}` (eq. `R:eq:grid-hP`, L202). -/
def hP (P : StreamParams) : ℚ := (1 / 2) ^ P.eHP

/-- Exponent of `h_b`: `⌈log₂(2^40 (T+1) G D_* (V+1)/(ηω))⌉`. -/
def eHb (P : StreamParams) : ℕ :=
  40 + P.logG + P.eEta + P.eOmega + Nat.clog 2 ((P.T + 1) * P.Dstar * (P.V + 1))

/-- Counter grid `h_b = 2^{-⌈log₂(2^40 (T+1) G D_* (V+1)/(ηω))⌉}` (eq. `R:eq:grid-hb`, L203). -/
def hb (P : StreamParams) : ℚ := (1 / 2) ^ P.eHb

/-- Exponent of `h_step`: `⌈log₂(2^20/η^2)⌉ = 20 + 2 log₂(1/η)`. -/
def eHstep (P : StreamParams) : ℕ := 20 + 2 * P.eEta

/-- Step grid `h_step = 2^{-⌈log₂(2^20/η^2)⌉}` (eq. `R:eq:grid-hstep-hADA`, L204). -/
def hstep (P : StreamParams) : ℚ := (1 / 2) ^ P.eHstep

/-- Exponent of `h_leaf = h_g^2 h_step^{2H}`. -/
def eHleaf (P : StreamParams) : ℕ := 2 * P.eHg + 2 * P.H * P.eHstep

/-- Terminal-accumulator grid `h_leaf = h_g^2 h_step^{2H}` (eq. `R:eq:h-leaf`, partIII.tex L461). -/
def hleaf (P : StreamParams) : ℚ := (1 / 2) ^ P.eHleaf

/-! ## Definition 5.2 ranges (`R:def:total-behavior`, eq. `R:eq:totality-ranges`, partIII.tex L446–449) -/

/-- `log₂ Z_max`, `Z_max` the smallest power of two `≥ 8 D_* (V+1)`. -/
def eZmax (P : StreamParams) : ℕ := Nat.clog 2 (8 * P.Dstar * (P.V + 1))

/-- Counter saturation range `Z_max` (smallest power of two `≥ 8 D_* (V+1)`). -/
def Zmax (P : StreamParams) : ℕ := 2 ^ P.eZmax

/-- `log₂ C_max`, `C_max` the smallest power of two `≥ 8 (B^H + 1)`. -/
def eCmax (P : StreamParams) : ℕ := Nat.clog 2 (8 * (P.B ^ P.H + 1))

/-- Tag range `C_max` (smallest power of two `≥ 8 (B^H + 1)`). -/
def Cmax (P : StreamParams) : ℕ := 2 ^ P.eCmax

/-- `log₂ A_max`, `A_max` the smallest power of two `≥ 16 (V+1)^2`. -/
def eAmax (P : StreamParams) : ℕ := Nat.clog 2 (16 * (P.V + 1) ^ 2)

/-- Cache/candidate/estimate range `A_max` (smallest power of two `≥ 16 (V+1)^2`). -/
def Amax (P : StreamParams) : ℕ := 2 ^ P.eAmax

/-! ## Zero fingerprint (Algorithm `R:alg:zero-fingerprint`, partII.tex L219; Lemma `R:lem:zero-fingerprint`) -/

/-- `M_q = ⌈10 n m (U+1)/β₀⌉^3 = (10 n m (U+1) 2^{betaExp})^3` (eq. `R:eq:prime-q-bound`). -/
def Mq (P : StreamParams) : ℕ := (10 * P.n * P.m * (P.U + 1) * 2 ^ P.betaExp) ^ 3

/-- There is a prime `≥ k` (Euclid). -/
theorem exists_prime_ge (k : ℕ) : ∃ p, k ≤ p ∧ p.Prime := Nat.exists_infinite_primes k

/-- The fingerprint modulus `q`: the least prime `≥ M_q` (Algorithm `R:alg:zero-fingerprint`, L219). -/
def q (P : StreamParams) : ℕ := Nat.find (exists_prime_ge P.Mq)

/-- Number of seed trials `⌈log₂(1000/β₀)⌉ = betaExp + 10` (L219). -/
def seedTrials (P : StreamParams) : ℕ := P.betaExp + 10

/-! ## Norm banks (Algorithm `R:alg:regularized-norm-bank`, partIII.tex L204–207) -/

/-- Row field degree `w = ⌈log₂(D_* + 1)⌉` (partIII.tex L207). -/
def w (P : StreamParams) : ℕ := Nat.clog 2 (P.Dstar + 1)

/-- Requested accuracy of each bank's ADA module: `a_num` (partIII.tex L205). -/
def bankAReq (P : StreamParams) : ℚ := P.aNum

/-- Requested failure probability of each bank's ADA module: `β_B/2` (partIII.tex L205). -/
def bankXiReq (P : StreamParams) : ℚ := P.betaB / 2

/-- Interval-request cap of each bank's ADA module: `M = m` (partIII.tex L205). -/
def bankM (P : StreamParams) : ℕ := P.m

/-- Rejection cap of each bank's ADA module: `J = J_max` (partIII.tex L205). -/
def bankJ (P : StreamParams) : ℕ := P.Jmax

/-- Numerical-request cap of each bank's ADA module: `R = R_max` (partIII.tex L205). -/
def bankR (P : StreamParams) : ℕ := P.Rmax

/-- Exponent of the bank ADA's dyadic accuracy `a = 2^{-⌈log₂(1/a_num)⌉}` (eq. `R:eq:sec3_dyadic_inputs`):
`⌈log₂(2^18 s/η)⌉ = 18 + log₂(1/η) + ⌈log₂ s⌉`. -/
def eBankA (P : StreamParams) : ℕ := 18 + P.eEta + Nat.clog 2 P.s

/-- The bank ADA's dyadic accuracy `a = 2^{-⌈log₂(1/a_num)⌉}`. -/
def bankA (P : StreamParams) : ℚ := (1 / 2) ^ P.eBankA

/-- Exponent of the bank ADA's dyadic failure probability `ξ_A = 2^{-⌈log₂(2/β_B)⌉}`:
`⌈log₂(128 m (H+1)/β₀)⌉ = betaExp + 7 + ⌈log₂(m (H+1))⌉`. -/
def eBankXi (P : StreamParams) : ℕ := P.betaExp + 7 + Nat.clog 2 (P.m * (P.H + 1))

/-- The bank ADA's dyadic failure probability `ξ_A = 2^{-⌈log₂(1/(β_B/2))⌉}`. -/
def bankXiA (P : StreamParams) : ℚ := (1 / 2) ^ P.eBankXi

/-- Coarse group parameter `g = 32 ⌈log₂(4 R_max/β_B)⌉`, where
`⌈log₂(4R_max/β_B)⌉ = betaExp + 8 + ⌈log₂(R_max m (H+1))⌉` (partIII.tex L206). -/
def gCoarse (P : StreamParams) : ℕ := 32 * (P.betaExp + 8 + Nat.clog 2 (P.Rmax * P.m * (P.H + 1)))

/-- Rows per coarse group: `32 g` (partIII.tex L206). -/
def coarseGroupRows (P : StreamParams) : ℕ := 32 * P.gCoarse

/-- Coarse rows of a bank: `R_max` groups of `32 g` rows (partIII.tex L206). -/
def Ncoarse (P : StreamParams) : ℕ := P.Rmax * P.coarseGroupRows

end StreamParams

end F2e2e
