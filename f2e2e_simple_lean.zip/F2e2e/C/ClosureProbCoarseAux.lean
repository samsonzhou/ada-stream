import F2e2e.C.ClosureProbBirth
import F2e2e.C.ClosureProbLabels

/-!
# Theorem 6.4, probability layer: the information flow of one coarse group

Helpers for `coarse_block_count` (`F2e2e/C/ClosureProbCoarse.lean`; paper: `parts/partIII.tex` L1275 "Each unused
coarse group is maintained but influences no decision. Its target shadow vector at first use is therefore independent
of that group").

The bits of the reserved coarse group `kc` of bank `lab` are tagged `true` by `coarseSel lab kc`, all others `false`.
They are read once, at the birth of `lab` (by `grpProg P`), and the group's rows are read again only by the
`kc`-th consuming release of `lab`. We compare the instrumented interpreter `runL` (two tapes: `a` for the `false`
bits, `l₀` for the group) with the **stopping placeholder interpreter** `runLs`: group `kc` of `lab` is the
placeholder `[]` (no bits read), and `runLs` stops (returning the release mode and the bank's history) at the release
whose head group is the placeholder. `runLs` reads no `true` bit, so its result depends on `a` alone.

* `CRel`: the relation between a real and a placeholder configuration (banks equal except that group `kc` of `lab`
  is the placeholder against a real group with the seeds `s` of the group sampled from `l₀`; the placeholder sits at
  position `kc − #(consuming releases of lab)`);
* `coarse_coupling`: along every successful real run, either `runLs` ends with a related configuration (then the
  `kc`-th consuming release of `lab` never happened), or `runLs` stops with `(mode, hist)` and the real final ghost has
  the `kc`-th consuming record of `lab` with this mode and history and with head group of seeds `s` (`KthRec`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-- The retagging selecting the reserved coarse group `k` of bank `lab`. -/
def coarseSel (lab : BankLabel) (k : ℕ) (τ : Tag) : Bool := decide (τ = Tag.coarse lab k)

/-- The final configurations on which the coarse event of group `k` of bank `lab` fails. -/
def coarseBad (P : StreamParams) (lab : BankLabel) (k : ℕ) : Set (Option ((State × Ghost) × List ℚ)) :=
  {o | ∃ c, o = some c ∧ ¬ CoarseGood P lab k c.1.2}

/-! ### Every-leaf predicate on tagged programs -/

/-- `TAll p Q`: every result of `p`, on every path, satisfies `Q`. -/
def TAll {ι α : Type} : TBitProg ι α → (α → Prop) → Prop
  | TBitProg.pure a, Q => Q a
  | TBitProg.bit _ k, Q => ∀ b, TAll (k b) Q

theorem TAll.of_runS {ι α : Type} [DecidableEq ι] {Q : α → Prop} :
    ∀ {p : TBitProg ι α}, TAll p Q → ∀ {σ : ι → List Bool} {x : α} {τ : ι → List Bool},
      p.runS σ = some (x, τ) → Q x
  | TBitProg.pure a, h, σ, x, τ, hr => by
    simp only [runS_pure, Option.some.injEq, Prod.mk.injEq] at hr
    exact hr.1 ▸ h
  | TBitProg.bit i k, h, σ, x, τ, hr => by
    simp only [runS] at hr
    split at hr
    · exact absurd hr (by simp)
    · exact TAll.of_runS (h _) hr

theorem TAll.mono {ι α : Type} {Q R : α → Prop} (hQ : ∀ a, Q a → R a) :
    ∀ {p : TBitProg ι α}, TAll p Q → TAll p R
  | TBitProg.pure a, h => hQ a h
  | TBitProg.bit _ _, h => fun b => TAll.mono hQ (h b)

theorem TAll.bind {ι α β : Type} {R : α → Prop} {Q : β → Prop} {f : α → TBitProg ι β}
    (hf : ∀ a, R a → TAll (f a) Q) : ∀ {p : TBitProg ι α}, TAll p R → TAll (p.bind f) Q
  | TBitProg.pure a, h => hf a h
  | TBitProg.bit _ _, h => fun b => TAll.bind hf (h b)

theorem TAll.true {ι α : Type} : ∀ p : TBitProg ι α, TAll p (fun _ => True)
  | TBitProg.pure _ => trivial
  | TBitProg.bit _ k => fun b => TAll.true (k b)

theorem TAll.retag {ι ι' α : Type} (f : ι → ι') {Q : α → Prop} :
    ∀ {p : TBitProg ι α}, TAll p Q → TAll (p.retag f) Q
  | TBitProg.pure _, h => h
  | TBitProg.bit _ _, h => fun b => TAll.retag f (h b)

/-- **Call logs only grow** along every path of the instrumented interpreter. -/
theorem tAll_runL_calls (P : StreamParams) {α : Type} :
    ∀ (p : AlgM α) (o : OState) (g : Ghost), TAll (runL P p o g) (fun r => g.calls <+: r.2.2.calls)
  | AlgM.pure _, _, _ => List.prefix_refl _
  | AlgM.fpInit k, o, g => by
    simp only [runL]
    exact TAll.bind (fun r _ => tAll_runL_calls P k _ g) (TAll.true _)
  | AlgM.fpStep _ _ k, o, g => by
    simp only [runL]
    exact tAll_runL_calls P _ _ _
  | AlgM.bankNew tr d k, o, g => by
    simp only [runL]
    exact TAll.bind (fun B _ => tAll_runL_calls P k _ _) (TAll.true _)
  | AlgM.bankRetain _ k, o, g => by
    simp only [runL]
    exact tAll_runL_calls P k _ _
  | AlgM.bankOp _ _ k, o, g => by
    simp only [runL]
    exact tAll_runL_calls P k _ _
  | AlgM.bankOpFrom _ _ k, o, g => by
    simp only [runL]
    exact tAll_runL_calls P k _ _
  | AlgM.bankValidate idx S θ k, o, g => by
    simp only [runL]
    cases o.banks[idx]? with
    | none => exact tAll_runL_calls P _ _ _
    | some B =>
      refine TAll.bind (fun r _ => ?_) (TAll.true _)
      exact TAll.mono (fun x hx => (List.prefix_append _ _).trans hx) (tAll_runL_calls P _ _ _)
  | AlgM.bankRelease idx mode k, o, g => by
    simp only [runL]
    cases o.banks[idx]? with
    | none => exact tAll_runL_calls P _ _ _
    | some B =>
      refine TAll.bind (fun r _ => ?_) (TAll.true _)
      exact TAll.mono (fun x hx => (List.prefix_append _ _).trans hx) (tAll_runL_calls P _ _ _)
  | AlgM.note _ k, o, g => by
    simp only [runL]
    exact tAll_runL_calls P k _ _

/-! ### Runs with two tapes -/

theorem runS_tag {γ : Type} (b : Bool) :
    ∀ (q : BitProg γ) (σ : Bool → List Bool),
      (tag b q).runS σ = (q.run (σ b)).map fun r => (r.1, Function.update σ b r.2)
  | BitProg.pure a, σ => by
    simp only [tag_pure, runS_pure, BitProg.run_pure, Option.map_some, Function.update_eq_self]
  | BitProg.bit k, σ => by
    simp only [tag_bit, runS]
    cases h : σ b with
    | nil => simp
    | cons c rest =>
      simp only [BitProg.run_bit_cons]
      rw [runS_tag b (k c) (Function.update σ b rest)]
      simp only [Function.update_self, Function.update_idem]

/-- Running a retagged `tag i q`, then a continuation. -/
theorem runS_retag_tag_bind {β γ : Type} (sel : Tag → Bool) (i : Tag) (q : BitProg β)
    (F : β → TBitProg Tag γ) (σ : Bool → List Bool) :
    (((tag i q).bind F).retag sel).runS σ =
      (q.run (σ (sel i))).bind fun r => ((F r.1).retag sel).runS (Function.update σ (sel i) r.2) := by
  rw [retag_bind, retag_tag, runS_bind, runS_tag]
  cases q.run (σ (sel i)) <;> rfl

theorem runS_retag_pure {α : Type} (sel : Tag → Bool) (a : α) (σ : Bool → List Bool) :
    ((TBitProg.pure a : TBitProg Tag α).retag sel).runS σ = some (a, σ) := rfl

theorem update_false_true (σ : Bool → List Bool) (l : List Bool) :
    Function.update σ false l true = σ true :=
  Function.update_of_ne (by decide) _ _

theorem update_true_false (σ : Bool → List Bool) (l : List Bool) :
    Function.update σ true l false = σ false :=
  Function.update_of_ne (by decide) _ _

/-! ### The stopping placeholder interpreter -/

/-- The sampler of one reserved coarse group (`g` subgroups of `32` fresh rows). -/
abbrev grpProg (P : StreamParams) : BitProg (List (List Row)) :=
  sampleList (sampleList (newRow P) 32) P.gCoarse

/-- The reserved coarse groups `j, …, j+n-1` of bank `lab`, group `kc` replaced by `[]` (no bits read). -/
def coarseTp (P : StreamParams) (lab : BankLabel) (kc : ℕ) :
    ℕ → ℕ → TBitProg Tag (List (List (List Row)))
  | _, 0 => TBitProg.pure []
  | j, n + 1 =>
    (if j = kc then TBitProg.pure [] else tag (Tag.coarse lab j) (grpProg P)).bind fun a =>
      (coarseTp P lab kc (j + 1) n).bind fun l => TBitProg.pure (a :: l)

/-- A fresh bank `lab` with its group `kc` replaced by the placeholder `[]`. -/
def newBankTp (P : StreamParams) (lab : BankLabel) (kc : ℕ) : TBitProg Tag Bank :=
  (tag (Tag.seeds lab) (sampleBlocks P (bankAda P).blockSizes)).bind fun ada =>
    (coarseTp P lab kc 0 P.Rmax).bind fun coarse =>
      (tag (Tag.coins lab) (adaInit (bankAda P))).bind fun st => TBitProg.pure ⟨ada, coarse, st⟩

/-- The head coarse group of the bank is the placeholder `[]`. -/
def phHead (B : Bank) : Bool :=
  match B.coarse with
  | [] :: _ => true
  | _ => false

/-- What the stopping interpreter reports: the release mode and the bank's history. -/
abbrev StopInfo := Mode × List RowOp

/-- **The stopping placeholder interpreter**: as `runL`, except that group `kc` of bank `lab` is the placeholder
`[]` and that the release of `lab` whose head group is the placeholder stops the run. -/
def runLs (P : StreamParams) (lab : BankLabel) (kc : ℕ) {α : Type} :
    AlgM α → OState → Ghost → TBitProg Tag (StopInfo ⊕ (α × OState × Ghost))
  | AlgM.pure a, o, g => TBitProg.pure (Sum.inr (a, o, g))
  | AlgM.fpInit k, o, g =>
    (tag Tag.fp (fpSeedProg P)).bind fun r => runLs P lab kc k { o with fpSeed := r, fpVal := 0 } g
  | AlgM.fpStep i Δ k, o, g =>
    runLs P lab kc (k (fpUpdate P o.fpSeed o.fpVal i Δ == 0))
      { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
      { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] }
  | AlgM.bankNew tr d k, o, g =>
    (if (tr, d) = lab then newBankTp P lab kc else newBankT P (tr, d)).bind fun B =>
      runLs P lab kc k { o with banks := o.banks ++ [B] }
        { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] }
  | AlgM.bankRetain n k, o, g =>
    runLs P lab kc k { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }
  | AlgM.bankOp idx op k, o, g =>
    runLs P lab kc k { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists }
  | AlgM.bankOpFrom idx op k, o, g =>
    runLs P lab kc k { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists }
  | AlgM.bankValidate idx S θ k, o, g =>
    match o.banks[idx]? with
    | none => runLs P lab kc (k AdaCert.abort) o g
    | some B =>
      (tag (Tag.coins (g.labelAt idx)) (B.validate P S θ)).bind fun r =>
        runLs P lab kc (k r.1) { o with banks := setAt r.2 idx o.banks }
          { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl r.1)⟩] }
  | AlgM.bankRelease idx mode k, o, g =>
    match o.banks[idx]? with
    | none => runLs P lab kc (k none) o g
    | some B =>
      if g.labelAt idx = lab ∧ phHead B = true then TBitProg.pure (Sum.inl (mode, g.histAt idx))
      else
        (tag (Tag.coins (g.labelAt idx)) (releaseLog P B mode)).bind fun r =>
          runLs P lab kc (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
              (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] }
  | AlgM.note ev k, o, g => runLs P lab kc k o { g with events := g.events ++ [ev] }

/-! ### Real versus placeholder configurations -/

/-- Real group `x` against placeholder group `y`: equal (and nonempty), or the placeholder against a real group
with the seeds `s`. -/
def GrpRel (P : StreamParams) (s : Fin P.gCoarse → Fin 32 → Seed P) (x y : List (List Row)) : Prop :=
  (y = x ∧ x ≠ []) ∨ (y = [] ∧ groupSeeds P x = s)

/-- Real versus placeholder bank. -/
def BankRel (P : StreamParams) (s : Fin P.gCoarse → Fin 32 → Seed P) (B B' : Bank) : Prop :=
  B'.ada = B.ada ∧ B'.adaSt = B.adaSt ∧ List.Forall₂ (GrpRel P s) B.coarse B'.coarse

/-- Real versus placeholder call record. -/
def RecRel (P : StreamParams) (s : Fin P.gCoarse → Fin 32 → Seed P) (r r' : CallRec) : Prop :=
  r'.lab = r.lab ∧ r'.idx = r.idx ∧ r'.hist = r.hist ∧ BankRel P s r.bank r'.bank ∧ r'.kind = r.kind ∧
    r'.scale = r.scale ∧ r'.out = r.out

/-- **Real versus placeholder configuration** (see the module docstring). -/
structure CRel (P : StreamParams) (lab : BankLabel) (kc : ℕ) (s : Fin P.gCoarse → Fin 32 → Seed P)
    (l₀ : List Bool) (born : Bool) (o : OState) (g : Ghost) (o' : OState) (g' : Ghost) : Prop where
  fpSeed : o'.fpSeed = o.fpSeed
  fpVal : o'.fpVal = o.fpVal
  banks : List.Forall₂ (BankRel P s) o.banks o'.banks
  labels : g'.labels = g.labels
  hists : g'.hists = g.hists
  calls : List.Forall₂ (RecRel P s) g.calls g'.calls
  events : g'.events = g.events
  fps : g'.fps = g.fps
  len : g.labels.length = o.banks.length
  uniq : ∀ i j, i < g.labels.length → j < g.labels.length → g.labelAt i = lab → g.labelAt j = lab → i = j
  other : ∀ idx B B', o.banks[idx]? = some B → o'.banks[idx]? = some B' → g.labelAt idx ≠ lab → B' = B
  cnt_le : (coarseRecs lab g).length ≤ kc
  pos : ∀ idx B', o'.banks[idx]? = some B' → g.labelAt idx = lab →
    ∀ j, B'.coarse[j]? = some [] ↔ j = kc - (coarseRecs lab g).length
  unborn : born = false → (∀ l ∈ g.labels, l ≠ lab) ∧ ∀ r ∈ g.calls, r.lab ≠ lab
  bornOK : born = true → ∃ z rest, (grpProg P).run l₀ = some (z, rest)

/-- The `kc`-th consuming record of `lab` has the given mode and history and a head group of seeds `s`. -/
def KthRec (P : StreamParams) (lab : BankLabel) (kc : ℕ) (s : Fin P.gCoarse → Fin 32 → Seed P)
    (info : StopInfo) (g : Ghost) : Prop :=
  ∃ rec, (coarseRecs lab g)[kc]? = some rec ∧ rec.kind = CallKind.release info.1 ∧ rec.hist = info.2 ∧
    ∃ grp rest, rec.bank.coarse = grp :: rest ∧ groupSeeds P grp = s

/-! ### List lemmas -/

theorem forall₂_getElem? {α β : Type} {R : α → β → Prop} :
    ∀ {l : List α} {l' : List β}, List.Forall₂ R l l' → ∀ idx : ℕ,
      (l[idx]? = none ∧ l'[idx]? = none) ∨ ∃ a b, l[idx]? = some a ∧ l'[idx]? = some b ∧ R a b
  | [], [], _, _ => Or.inl ⟨rfl, rfl⟩
  | a :: _, b :: _, List.Forall₂.cons h _, 0 => Or.inr ⟨a, b, rfl, rfl, h⟩
  | _ :: _, _ :: _, List.Forall₂.cons _ h, idx + 1 => by
    simpa only [List.getElem?_cons_succ] using forall₂_getElem? h idx

theorem forall₂_tail {α β : Type} {R : α → β → Prop} :
    ∀ {l : List α} {l' : List β}, List.Forall₂ R l l' → List.Forall₂ R l.tail l'.tail
  | [], [], _ => List.Forall₂.nil
  | _ :: _, _ :: _, List.Forall₂.cons _ h => h

theorem forall₂_modifyAt {α β : Type} {R : α → β → Prop} (f : α → α) (f' : β → β)
    (hf : ∀ a b, R a b → R (f a) (f' b)) :
    ∀ (idx : ℕ) {l : List α} {l' : List β}, List.Forall₂ R l l' →
      List.Forall₂ R (modifyAt f idx l) (modifyAt f' idx l')
  | _, [], [], _ => by cases ‹ℕ› <;> exact List.Forall₂.nil
  | 0, _ :: _, _ :: _, List.Forall₂.cons h h' => List.Forall₂.cons (hf _ _ h) h'
  | idx + 1, _ :: _, _ :: _, List.Forall₂.cons h h' =>
    List.Forall₂.cons h (forall₂_modifyAt f f' hf idx h')

theorem forall₂_mapFrom {α β : Type} {R : α → β → Prop} (f : α → α) (f' : β → β)
    (hf : ∀ a b, R a b → R (f a) (f' b)) :
    ∀ (idx : ℕ) {l : List α} {l' : List β}, List.Forall₂ R l l' →
      List.Forall₂ R (mapFrom f idx l) (mapFrom f' idx l')
  | _, [], [], _ => by cases ‹ℕ› <;> exact List.Forall₂.nil
  | 0, _ :: _, _ :: _, List.Forall₂.cons h h' =>
    List.Forall₂.cons (hf _ _ h) (forall₂_mapFrom f f' hf 0 h')
  | idx + 1, _ :: _, _ :: _, List.Forall₂.cons h h' =>
    List.Forall₂.cons h (forall₂_mapFrom f f' hf idx h')

theorem forall₂_setAt {α β : Type} {R : α → β → Prop} (a : α) (b : β) (hab : R a b) :
    ∀ (idx : ℕ) {l : List α} {l' : List β}, List.Forall₂ R l l' →
      List.Forall₂ R (setAt a idx l) (setAt b idx l')
  | _, [], [], _ => by cases ‹ℕ› <;> exact List.Forall₂.nil
  | 0, _ :: _, _ :: _, List.Forall₂.cons _ h' => List.Forall₂.cons hab h'
  | idx + 1, _ :: _, _ :: _, List.Forall₂.cons h h' =>
    List.Forall₂.cons h (forall₂_setAt a b hab idx h')

/-! ### Row operations keep the seeds -/

theorem rowOp_apply_seed' (P : StreamParams) (op : RowOp) (r : Row) : (op.apply P r).seed = r.seed := by
  cases op <;> rfl

theorem seedOfRow_getD_map (P : StreamParams) (f : Row → Row) (hf : ∀ r, (f r).seed = r.seed)
    (sub : List Row) (l : ℕ) (d : Row) :
    seedOfRow P ((sub.map f).getD l d) = seedOfRow P (sub.getD l d) := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_map]
  cases sub[l]? with
  | none => rfl
  | some r =>
    funext k
    simp only [Option.map_some, Option.getD_some, seedOfRow, hf]

theorem groupSeeds_map (P : StreamParams) (f : Row → Row) (hf : ∀ r, (f r).seed = r.seed)
    (grp : List (List Row)) : groupSeeds P (grp.map fun sub => sub.map f) = groupSeeds P grp := by
  funext j l
  unfold groupSeeds
  have h : (grp.map fun sub => sub.map f).getD j.val [] = (grp.getD j.val []).map f := by
    rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_map]
    cases grp[j.val]? <;> rfl
  rw [h, seedOfRow_getD_map P f hf]

theorem grpRel_map (P : StreamParams) (s : Fin P.gCoarse → Fin 32 → Seed P) (f : Row → Row)
    (hf : ∀ r, (f r).seed = r.seed) {x y : List (List Row)} (h : GrpRel P s x y) :
    GrpRel P s (x.map fun sub => sub.map f) (y.map fun sub => sub.map f) := by
  rcases h with ⟨rfl, hx⟩ | ⟨rfl, hs⟩
  · exact Or.inl ⟨rfl, by simpa using hx⟩
  · exact Or.inr ⟨rfl, by rw [groupSeeds_map P f hf, hs]⟩

theorem bankRel_mapRows (P : StreamParams) (s : Fin P.gCoarse → Fin 32 → Seed P) (op : RowOp)
    {B B' : Bank} (h : BankRel P s B B') :
    BankRel P s (Bank.mapRows (op.apply P) B) (Bank.mapRows (op.apply P) B') := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨by simp only [Bank.mapRows, h1], h2, ?_⟩
  simp only [Bank.mapRows]
  exact List.forall₂_map_left_iff.mpr (List.forall₂_map_right_iff.mpr
    (h3.imp fun x y hxy => grpRel_map P s _ (rowOp_apply_seed' P op) hxy))

theorem mapRows_coarse_getElem?_nil (P : StreamParams) (op : RowOp) (B : Bank) (j : ℕ) :
    (Bank.mapRows (op.apply P) B).coarse[j]? = some [] ↔ B.coarse[j]? = some [] := by
  simp only [Bank.mapRows, List.getElem?_map]
  cases B.coarse[j]? with
  | none => simp
  | some x => simp

/-! ### Validations and releases on related banks read the same bits -/

theorem validate_congr (P : StreamParams) {B B' : Bank} (hada : B'.ada = B.ada) (hst : B'.adaSt = B.adaSt)
    (S θ : ℚ) :
    B'.validate P S θ = (B.validate P S θ).map fun r => (r.1, { r.2 with coarse := B'.coarse }) := by
  obtain ⟨ada, co, st⟩ := B
  obtain ⟨ada', co', st'⟩ := B'
  simp only at hada hst
  subst hada hst
  unfold Bank.validate
  simp only [bp_bind_eq, bp_pure_eq]
  rw [FP.bp_map_bind]
  rfl

theorem releaseLog_congr (P : StreamParams) {B B' : Bank} (hada : B'.ada = B.ada)
    (hst : B'.adaSt = B.adaSt) {x : List (List Row)} {rest rest' : List (List (List Row))}
    (h1 : B.coarse = x :: rest) (h2 : B'.coarse = x :: rest') (mode : Mode) :
    releaseLog P B' mode =
      (releaseLog P B mode).map fun r => ((r.1.1, { r.1.2 with coarse := rest' }), r.2) := by
  rw [LabAux.releaseLog_cons P B mode h1, LabAux.releaseLog_cons P B' mode h2]
  obtain ⟨ada, co, st⟩ := B
  obtain ⟨ada', co', st'⟩ := B'
  simp only at hada hst
  subst hada hst
  rw [FP.bp_map_bind]
  congr 1
  funext res
  rcases res with ⟨out, st2⟩
  cases out <;> rfl

/-! ### Preservation of the relation -/

section Pres

variable {P : StreamParams} {lab : BankLabel} {kc : ℕ} {s : Fin P.gCoarse → Fin 32 → Seed P}
  {l₀ : List Bool} {born : Bool} {o o' : OState} {g g' : Ghost}

theorem CRel.labelAt_eq (h : CRel P lab kc s l₀ born o g o' g') (i : ℕ) : g'.labelAt i = g.labelAt i := by
  unfold Ghost.labelAt
  rw [h.labels]

theorem CRel.histAt_eq (h : CRel P lab kc s l₀ born o g o' g') (i : ℕ) : g'.histAt i = g.histAt i := by
  unfold Ghost.histAt
  rw [h.hists]

theorem CRel.labelAt_mem (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B : Bank}
    (hB : o.banks[idx]? = some B) : g.labelAt idx ∈ g.labels :=
  Closure.labelAt_mem (by rw [h.len]; exact (List.getElem?_eq_some_iff.mp hB).1)

/-- Generic congruence: the banks, labels and calls unchanged. -/
theorem CRel.congr (h : CRel P lab kc s l₀ born o g o' g') {o1 o1' : OState} {g1 g1' : Ghost}
    (hb : o1.banks = o.banks) (hb' : o1'.banks = o'.banks) (hfs : o1'.fpSeed = o1.fpSeed)
    (hfv : o1'.fpVal = o1.fpVal) (hl : g1.labels = g.labels) (hl' : g1'.labels = g'.labels)
    (hh : g1'.hists = g1.hists) (hc : g1.calls = g.calls) (hc' : g1'.calls = g'.calls)
    (he : g1'.events = g1.events) (hf : g1'.fps = g1.fps) : CRel P lab kc s l₀ born o1 g1 o1' g1' := by
  have hla : ∀ i, g1.labelAt i = g.labelAt i := fun i => by unfold Ghost.labelAt; rw [hl]
  have hcr : coarseRecs lab g1 = coarseRecs lab g := coarseRecs_congr hc
  exact {
    fpSeed := hfs
    fpVal := hfv
    banks := by rw [hb, hb']; exact h.banks
    labels := by rw [hl, hl', h.labels]
    hists := hh
    calls := by rw [hc, hc']; exact h.calls
    events := he
    fps := hf
    len := by rw [hl, hb]; exact h.len
    uniq := fun i j hi hj h1 h2 => h.uniq i j (by rwa [← hl]) (by rwa [← hl]) (by rwa [← hla])
      (by rwa [← hla])
    other := fun idx B B' h1 h2 h3 => h.other idx B B' (by rwa [← hb]) (by rwa [← hb'])
      (by rwa [← hla])
    cnt_le := by rw [hcr]; exact h.cnt_le
    pos := fun idx B' h1 h2 => by rw [hcr]; exact h.pos idx B' (by rwa [← hb']) (by rwa [← hla])
    unborn := fun hb0 => by rw [hl, hc]; exact h.unborn hb0
    bornOK := h.bornOK }

theorem CRel.retain (h : CRel P lab kc s l₀ born o g o' g') (n : ℕ) :
    CRel P lab kc s l₀ born { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n }
      { o' with banks := o'.banks.take n }
      { g' with labels := g'.labels.take n, hists := g'.hists.take n } := by
  have hla : ∀ i, i < n →
      ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost).labelAt i = g.labelAt i := by
    intro i hi
    unfold Ghost.labelAt
    simp only [List.getD_eq_getElem?_getD, List.getElem?_take, if_pos hi]
  have hcr : coarseRecs lab ({ g with labels := g.labels.take n, hists := g.hists.take n } : Ghost) =
      coarseRecs lab g := rfl
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := List.forall₂_take n h.banks
    labels := by simp only [h.labels]
    hists := by simp only [h.hists]
    calls := h.calls
    events := h.events
    fps := h.fps
    len := by simp only [List.length_take, h.len]
    uniq := fun i j hi hj h1 h2 => by
      simp only [List.length_take] at hi hj
      exact h.uniq i j (by omega) (by omega) (by rwa [← hla i (by omega)])
        (by rwa [← hla j (by omega)])
    other := fun idx B B' h1 h2 h3 => by
      by_cases hi : idx < n
      · simp only [List.getElem?_take, hi, if_true] at h1 h2
        exact h.other idx B B' h1 h2 (by rwa [← hla idx hi])
      · simp only [List.getElem?_take, hi, if_false] at h1
        exact absurd h1 (by simp)
    cnt_le := by rw [hcr]; exact h.cnt_le
    pos := fun idx B' h1 h2 => by
      by_cases hi : idx < n
      · simp only [List.getElem?_take, hi, if_true] at h1
        rw [hcr]; exact h.pos idx B' h1 (by rwa [← hla idx hi])
      · simp only [List.getElem?_take, hi, if_false] at h1
        exact absurd h1 (by simp)
    unborn := fun hb0 => ⟨fun l hl => (h.unborn hb0).1 l (List.mem_of_mem_take hl),
      (h.unborn hb0).2⟩
    bornOK := h.bornOK }

theorem CRel.bankOp (h : CRel P lab kc s l₀ born o g o' g') (idx : ℕ) (op : RowOp) :
    CRel P lab kc s l₀ born { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists }
      { o' with banks := modifyAt (Bank.mapRows (op.apply P)) idx o'.banks }
      { g' with hists := modifyAt (fun h => h ++ [op]) idx g'.hists } := by
  have hla : ∀ i, ({ g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } : Ghost).labelAt i =
      g.labelAt i := fun i => rfl
  have hcr : coarseRecs lab ({ g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } : Ghost) =
      coarseRecs lab g := rfl
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := forall₂_modifyAt _ _ (fun _ _ hr => bankRel_mapRows P s op hr) idx h.banks
    labels := h.labels
    hists := by simp only [h.hists]
    calls := h.calls
    events := h.events
    fps := h.fps
    len := by simp only [LabAux.length_modifyAt, h.len]
    uniq := h.uniq
    other := fun j B B' h1 h2 h3 => by
      simp only [LabAux.getElem?_modifyAt] at h1 h2
      split_ifs at h1 h2 with hj
      · obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp h1
        obtain ⟨B0', hB0', rfl⟩ := Option.map_eq_some_iff.mp h2
        rw [h.other j B0 B0' hB0 hB0' h3]
      · exact h.other j B B' h1 h2 h3
    cnt_le := h.cnt_le
    pos := fun j B' h1 h2 i => by
      simp only [LabAux.getElem?_modifyAt] at h1
      split_ifs at h1 with hj
      · obtain ⟨B0', hB0', rfl⟩ := Option.map_eq_some_iff.mp h1
        rw [mapRows_coarse_getElem?_nil]
        exact h.pos j B0' hB0' h2 i
      · exact h.pos j B' h1 h2 i
    unborn := h.unborn
    bornOK := h.bornOK }

theorem CRel.bankOpFrom (h : CRel P lab kc s l₀ born o g o' g') (idx : ℕ) (op : RowOp) :
    CRel P lab kc s l₀ born { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists }
      { o' with banks := mapFrom (Bank.mapRows (op.apply P)) idx o'.banks }
      { g' with hists := mapFrom (fun h => h ++ [op]) idx g'.hists } := by
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := forall₂_mapFrom _ _ (fun _ _ hr => bankRel_mapRows P s op hr) idx h.banks
    labels := h.labels
    hists := by simp only [h.hists]
    calls := h.calls
    events := h.events
    fps := h.fps
    len := by simp only [LabAux.length_mapFrom, h.len]
    uniq := h.uniq
    other := fun j B B' h1 h2 h3 => by
      simp only [LabAux.getElem?_mapFrom] at h1 h2
      split_ifs at h1 h2 with hj
      · obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp h1
        obtain ⟨B0', hB0', rfl⟩ := Option.map_eq_some_iff.mp h2
        rw [h.other j B0 B0' hB0 hB0' h3]
      · exact h.other j B B' h1 h2 h3
    cnt_le := h.cnt_le
    pos := fun j B' h1 h2 i => by
      simp only [LabAux.getElem?_mapFrom] at h1
      split_ifs at h1 with hj
      · obtain ⟨B0', hB0', rfl⟩ := Option.map_eq_some_iff.mp h1
        rw [mapRows_coarse_getElem?_nil]
        exact h.pos j B0' hB0' h2 i
      · exact h.pos j B' h1 h2 i
    unborn := h.unborn
    bornOK := h.bornOK }

theorem CRel.bankRel_at (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hB' : o'.banks[idx]? = some B') : BankRel P s B B' := by
  rcases forall₂_getElem? h.banks idx with ⟨h1, -⟩ | ⟨a, b, h1, h2, hab⟩
  · rw [hB] at h1; exact absurd h1 (by simp)
  · rw [hB] at h1; rw [hB'] at h2
    cases h1; cases h2; exact hab

theorem CRel.some_iff (h : CRel P lab kc s l₀ born o g o' g') (idx : ℕ) :
    (o.banks[idx]? = none ∧ o'.banks[idx]? = none) ∨
      ∃ B B', o.banks[idx]? = some B ∧ o'.banks[idx]? = some B' ∧ BankRel P s B B' :=
  forall₂_getElem? h.banks idx

theorem CRel.born_of_lab (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B : Bank}
    (hB : o.banks[idx]? = some B) (hlab : g.labelAt idx = lab) : born = true := by
  cases born with
  | true => rfl
  | false => exact absurd hlab ((h.unborn rfl).1 _ (h.labelAt_mem hB))

theorem coarseRecs_append_validate (lab : BankLabel) (g : Ghost) (r : CallRec) {S θ : ℚ}
    (hk : r.kind = CallKind.validate S θ) :
    coarseRecs lab { g with calls := g.calls ++ [r] } = coarseRecs lab g := by
  unfold coarseRecs
  simp [List.filter_append, hk]

theorem coarseRecs_append_release (lab : BankLabel) (g : Ghost) (r : CallRec) {mode : Mode}
    (hk : r.kind = CallKind.release mode) :
    coarseRecs lab { g with calls := g.calls ++ [r] } =
      coarseRecs lab g ++ (if r.lab = lab ∧ r.bank.coarse ≠ [] then [r] else []) := by
  unfold coarseRecs
  rw [List.filter_append]
  congr 1
  by_cases h1 : r.lab = lab <;> by_cases h2 : r.bank.coarse = [] <;> simp [h1, h2, hk]

theorem CRel.validate (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hB' : o'.banks[idx]? = some B') (S θ : ℚ) (c : AdaCert) (B1 : Bank)
    (hB1 : B1.coarse = B.coarse) :
    CRel P lab kc s l₀ born { o with banks := setAt B1 idx o.banks }
      { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
        S + P.omega, some (Sum.inl c)⟩] }
      { o' with banks := setAt { B1 with coarse := B'.coarse } idx o'.banks }
      { g' with calls := g'.calls ++ [⟨g'.labelAt idx, idx, g'.histAt idx, B', CallKind.validate S θ,
        S + P.omega, some (Sum.inl c)⟩] } := by
  have hBB := h.bankRel_at hB hB'
  have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hlt' : idx < o'.banks.length := (List.getElem?_eq_some_iff.mp hB').1
  have hcr := coarseRecs_append_validate lab g ⟨g.labelAt idx, idx, g.histAt idx, B,
    CallKind.validate S θ, S + P.omega, some (Sum.inl c)⟩ rfl
  have hrel1 : BankRel P s B1 { B1 with coarse := B'.coarse } :=
    ⟨rfl, rfl, by rw [hB1]; exact hBB.2.2⟩
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := forall₂_setAt _ _ hrel1 idx h.banks
    labels := h.labels
    hists := h.hists
    calls := List.rel_append h.calls (List.Forall₂.cons
      ⟨h.labelAt_eq idx, rfl, h.histAt_eq idx, hBB, rfl, rfl, rfl⟩ List.Forall₂.nil)
    events := h.events
    fps := h.fps
    len := by simp only [LabAux.length_setAt, h.len]
    uniq := h.uniq
    other := fun j C C' h1 h2 h3 => by
      simp only [LabAux.getElem?_setAt] at h1 h2
      by_cases hj : j = idx
      · subst hj
        rw [if_pos ⟨rfl, hlt⟩] at h1
        rw [if_pos ⟨rfl, hlt'⟩] at h2
        cases h1; cases h2
        have := h.other j B B' hB hB' h3
        subst this
        rw [← hB1]
      · rw [if_neg (fun h' => hj h'.1)] at h1 h2
        exact h.other j C C' h1 h2 h3
    cnt_le := by rw [hcr]; exact h.cnt_le
    pos := fun j C' h1 h2 i => by
      rw [hcr]
      simp only [LabAux.getElem?_setAt] at h1
      by_cases hj : j = idx
      · subst hj
        rw [if_pos ⟨rfl, hlt'⟩] at h1
        cases h1
        exact h.pos j B' hB' h2 i
      · rw [if_neg (fun h' => hj h'.1)] at h1
        exact h.pos j C' h1 h2 i
    unborn := fun hb0 => ⟨(h.unborn hb0).1, fun r hr => by
      rcases List.mem_append.mp hr with hr | hr
      · exact (h.unborn hb0).2 r hr
      · rw [List.mem_singleton] at hr
        subst hr
        exact (h.unborn hb0).1 _ (h.labelAt_mem hB)⟩
    bornOK := h.bornOK }

theorem CRel.releaseOther (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hB' : o'.banks[idx]? = some B') (hne : g.labelAt idx ≠ lab)
    (mode : Mode) (r : (Option ℚ × Bank) × Option (ℚ × AdaNum)) (hr : r.1.2.coarse = B.coarse.tail) :
    CRel P lab kc s l₀ born { o with banks := setAt r.1.2 idx o.banks }
      { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
        (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] }
      { o' with banks := setAt r.1.2 idx o'.banks }
      { g' with calls := g'.calls ++ [⟨g'.labelAt idx, idx, g'.histAt idx, B', CallKind.release mode,
        (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
  have hBB := h.bankRel_at hB hB'
  have hBeq : B' = B := h.other idx B B' hB hB' hne
  subst hBeq
  have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hlt' : idx < o'.banks.length := (List.getElem?_eq_some_iff.mp hB').1
  have hcr : coarseRecs lab { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B',
      CallKind.release mode, (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } =
      coarseRecs lab g := by
    rw [coarseRecs_append_release lab g _ rfl, if_neg (fun h' => hne h'.1), List.append_nil]
  have hrel1 : BankRel P s r.1.2 r.1.2 := by
    refine ⟨rfl, rfl, ?_⟩
    rw [hr]
    exact forall₂_tail hBB.2.2
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := forall₂_setAt _ _ hrel1 idx h.banks
    labels := h.labels
    hists := h.hists
    calls := List.rel_append h.calls (List.Forall₂.cons
      ⟨h.labelAt_eq idx, rfl, h.histAt_eq idx, hBB, rfl, rfl, rfl⟩ List.Forall₂.nil)
    events := h.events
    fps := h.fps
    len := by simp only [LabAux.length_setAt, h.len]
    uniq := h.uniq
    other := fun j C C' h1 h2 h3 => by
      simp only [LabAux.getElem?_setAt] at h1 h2
      by_cases hj : j = idx
      · subst hj
        rw [if_pos ⟨rfl, hlt⟩] at h1
        rw [if_pos ⟨rfl, hlt'⟩] at h2
        cases h1; cases h2; rfl
      · rw [if_neg (fun h' => hj h'.1)] at h1 h2
        exact h.other j C C' h1 h2 h3
    cnt_le := by rw [hcr]; exact h.cnt_le
    pos := fun j C' h1 h2 i => by
      rw [hcr]
      simp only [LabAux.getElem?_setAt] at h1
      by_cases hj : j = idx
      · subst hj; exact absurd h2 hne
      · rw [if_neg (fun h' => hj h'.1)] at h1
        exact h.pos j C' h1 h2 i
    unborn := fun hb0 => ⟨(h.unborn hb0).1, fun r' hr' => by
      rcases List.mem_append.mp hr' with hr' | hr'
      · exact (h.unborn hb0).2 r' hr'
      · rw [List.mem_singleton] at hr'
        subst hr'
        exact hne⟩
    bornOK := h.bornOK }

theorem CRel.releaseLab (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hB' : o'.banks[idx]? = some B') (hlab : g.labelAt idx = lab)
    {x : List (List Row)} {rest rest' : List (List (List Row))} (h1 : B.coarse = x :: rest)
    (h2 : B'.coarse = x :: rest') (hx : x ≠ [])
    (mode : Mode) (r : (Option ℚ × Bank) × Option (ℚ × AdaNum)) (hr : r.1.2.coarse = rest) :
    CRel P lab kc s l₀ born { o with banks := setAt r.1.2 idx o.banks }
      { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
        (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] }
      { o' with banks := setAt { r.1.2 with coarse := rest' } idx o'.banks }
      { g' with calls := g'.calls ++ [⟨g'.labelAt idx, idx, g'.histAt idx, B', CallKind.release mode,
        (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
  have hBB := h.bankRel_at hB hB'
  have hlt : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hlt' : idx < o'.banks.length := (List.getElem?_eq_some_iff.mp hB').1
  have hcr : coarseRecs lab { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B,
      CallKind.release mode, (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } =
      coarseRecs lab g ++ [⟨g.labelAt idx, idx, g.histAt idx, B,
      CallKind.release mode, (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] := by
    rw [coarseRecs_append_release lab g _ rfl, if_pos ⟨hlab, by simp [h1]⟩]
  have hpos := h.pos idx B' hB' hlab
  -- the placeholder is not the head
  have hne0 : kc - (coarseRecs lab g).length ≠ 0 := by
    intro h0
    have := (hpos 0).mpr h0.symm
    rw [h2] at this
    simp only [List.getElem?_cons_zero, Option.some.injEq] at this
    exact hx this
  have hrest : List.Forall₂ (GrpRel P s) rest rest' := by
    have h3 := hBB.2.2
    rw [h1, h2] at h3
    cases h3 with
    | cons _ h4 => exact h4
  have hrel1 : BankRel P s r.1.2 { r.1.2 with coarse := rest' } :=
    ⟨rfl, rfl, by rw [hr]; exact hrest⟩
  exact {
    fpSeed := h.fpSeed
    fpVal := h.fpVal
    banks := forall₂_setAt _ _ hrel1 idx h.banks
    labels := h.labels
    hists := h.hists
    calls := List.rel_append h.calls (List.Forall₂.cons
      ⟨h.labelAt_eq idx, rfl, h.histAt_eq idx, hBB, rfl, rfl, rfl⟩ List.Forall₂.nil)
    events := h.events
    fps := h.fps
    len := by simp only [LabAux.length_setAt, h.len]
    uniq := h.uniq
    other := fun j C C' h1' h2' h3' => by
      simp only [LabAux.getElem?_setAt] at h1' h2'
      by_cases hj : j = idx
      · subst hj; exact absurd hlab h3'
      · rw [if_neg (fun h' => hj h'.1)] at h1' h2'
        exact h.other j C C' h1' h2' h3'
    cnt_le := by
      rw [hcr, List.length_append, List.length_singleton]
      have := h.cnt_le
      omega
    pos := fun j C' h1' h2' i => by
      rw [hcr, List.length_append, List.length_singleton]
      simp only [LabAux.getElem?_setAt] at h1'
      by_cases hj : j = idx
      · subst hj
        rw [if_pos ⟨rfl, hlt'⟩] at h1'
        cases h1'
        show rest'[i]? = some [] ↔ _
        have := hpos (i + 1)
        rw [h2, List.getElem?_cons_succ] at this
        rw [this]
        omega
      · exfalso
        have hjl : j < g.labels.length := by
          rw [h.len, List.Forall₂.length_eq h.banks]
          rw [if_neg (fun h' => hj h'.1)] at h1'
          exact (List.getElem?_eq_some_iff.mp h1').1
        exact hj (h.uniq j idx hjl (by rw [h.len]; exact hlt) h2' hlab)
    unborn := fun hb0 => absurd (h.born_of_lab hB hlab) (by rw [hb0]; decide)
    bornOK := h.bornOK }

/-- **At the stopping release**: the real run records the `kc`-th consuming release of `lab`, whose head
group has the seeds `s`; it stays the `kc`-th consuming record along the rest of the real run. -/
theorem CRel.stop (h : CRel P lab kc s l₀ born o g o' g') {idx : ℕ} {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hB' : o'.banks[idx]? = some B') (hlab : g.labelAt idx = lab)
    (hph : phHead B' = true) (mode : Mode) (sc : ℚ) (out : Option CoreOut) (g2 : Ghost)
    (hg2 : g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode, sc, out⟩] <+:
      g2.calls) :
    KthRec P lab kc s (mode, g.histAt idx) g2 ∧ ∃ z rest, (grpProg P).run l₀ = some (z, rest) := by
  have hBB := h.bankRel_at hB hB'
  obtain ⟨rest', hco'⟩ : ∃ rest', B'.coarse = [] :: rest' := by
    unfold phHead at hph
    split at hph
    · rename_i rest' heq
      exact ⟨rest', heq⟩
    · exact absurd hph (by decide)
  have h3 := hBB.2.2
  rw [hco'] at h3
  obtain ⟨x, rest, hco, hxs⟩ : ∃ x rest, B.coarse = x :: rest ∧ groupSeeds P x = s := by
    cases hc : B.coarse with
    | nil => rw [hc] at h3; cases h3
    | cons x rest =>
      rw [hc] at h3
      cases h3 with
      | cons hg _ =>
        rcases hg with ⟨hx0, hx1⟩ | ⟨-, hx⟩
        · exact absurd hx0.symm hx1
        · exact ⟨x, rest, rfl, hx⟩
  have hpos := h.pos idx B' hB' hlab
  have hcnt : (coarseRecs lab g).length = kc := by
    have h0 := (hpos 0).mp (by rw [hco']; rfl)
    have := h.cnt_le
    omega
  set rec : CallRec := ⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode, sc, out⟩ with hrec
  have hcr : coarseRecs lab { g with calls := g.calls ++ [rec] } = coarseRecs lab g ++ [rec] := by
    rw [coarseRecs_append_release lab g rec rfl, if_pos ⟨hlab, by simp [hrec, hco]⟩]
  have hpre : coarseRecs lab { g with calls := g.calls ++ [rec] } <+: coarseRecs lab g2 := by
    unfold coarseRecs at *
    exact hg2.filter _
  have hk : (coarseRecs lab g2)[kc]? = some rec := by
    obtain ⟨t, ht⟩ := hpre
    rw [← ht, hcr, List.append_assoc, List.getElem?_append_right (by omega), hcnt, Nat.sub_self]
    rfl
  refine ⟨⟨rec, hk, rfl, rfl, x, rest, hco, hxs⟩, ?_⟩
  exact h.bornOK (h.born_of_lab hB hlab)

end Pres

end F2e2e.C.Closure
