import Mathlib
import F2e2e.C.ClosureInv
import F2e2e.C.Alg.Facts

/-!
# Theorem 6.4, tree side: C-TREE's invariant through every block of a round (the `tree` component)

Source: `parts/partIII.tex` Algorithm `R:alg:within-round-tree` (L466–517, as coded in
`F2e2e/C/Alg/AlgMCode.lean`) and C-TREE's step lemmas `Tree.treeInv_*` (`F2e2e/C/Tree/Inv.lean`).

For every block of the controller code, the lemma `tree_X` gives the field `tree : Tree.TreeInv …` of
`TreePart` (`F2e2e/C/ClosureInv.lean`) at the next moment, for the controller state computed by the code, from the
tree part at the current moment and the block's hypotheses (bank certificates in the tree-shadow form, the tag
precision of Lemma 6.1 (ii) and the cache invariant (H2) of Lemma 6.2 at the current moment). The bridges between
the integer formulas of the code and the real-valued quantities of Section 5 are `guard_bridge` (the Step-3 guard,
via `Alg.guardMant_eq`) and `step_bridge` (the Step-4 multiplier, via `Alg.stepCoeffMant_eq`). The register
updates of the code (`take`, `++ [newLearner]`, `setAt`, `mapFrom Learner.rescale`, `Learner.countCorrection`)
are translated into the register hypotheses of the step lemmas.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank

/-! ## List and register lemmas -/

theorem tr_getD_of_getElem? {l : List Learner} {d : ℕ} {L : Learner} (h : l[d]? = some L) :
    l.getD d dfltLearner = L := by
  rw [List.getD_eq_getElem?_getD, h]; rfl

theorem tr_getD_take_of_lt (l : List Learner) {k d : ℕ} (hd : d < k) :
    (l.take k).getD d dfltLearner = l.getD d dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_take, if_pos hd]

theorem tr_getD_setAt_self (b : Learner) (l : List Learner) {d : ℕ} (hd : d < l.length) :
    (setAt b d l).getD d dfltLearner = b := by
  rw [List.getD_eq_getElem?_getD, getElem?_setAt_self b d l hd]; rfl

theorem tr_getD_setAt_ne (b : Learner) (l : List Learner) {d j : ℕ} (hj : j ≠ d) :
    (setAt b d l).getD j dfltLearner = l.getD j dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_setAt_ne b d l j hj]

theorem tr_getD_mapFrom_lt (f : Learner → Learner) (l : List Learner) {k j : ℕ} (hj : j < k) :
    (mapFrom f k l).getD j dfltLearner = l.getD j dfltLearner := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_mapFrom, if_neg (by omega)]

/-- The registers `k, j_epoch, J_used` of a rescaled learner list (`Learner.rescale` changes only the tag and the
cache). -/
theorem tr_getD_mapFrom_rescale (P : StreamParams) (cInt : ℤ) (l : List Learner) (k j : ℕ) :
    ((mapFrom (Learner.rescale P cInt) k l).getD j dfltLearner).epoch = (l.getD j dfltLearner).epoch ∧
      ((mapFrom (Learner.rescale P cInt) k l).getD j dfltLearner).jEpoch = (l.getD j dfltLearner).jEpoch ∧
      ((mapFrom (Learner.rescale P cInt) k l).getD j dfltLearner).jUsed = (l.getD j dfltLearner).jUsed := by
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, getElem?_mapFrom]
  split_ifs
  · cases l[j]? <;> exact ⟨rfl, rfl, rfl⟩
  · exact ⟨rfl, rfl, rfl⟩

theorem regsOf_eq_of_getD {P : StreamParams} {c c' : CState} {d : ℕ}
    (h : c'.learners.getD d dfltLearner = c.learners.getD d dfltLearner) :
    (regsOf P c').Chat d = (regsOf P c).Chat d ∧ (regsOf P c').k d = (regsOf P c).k d ∧
      (regsOf P c').jE d = (regsOf P c).jE d ∧ (regsOf P c').jU d = (regsOf P c).jU d := by
  show tagVal P c' d = tagVal P c d ∧ (c'.learners.getD d dfltLearner).epoch = (c.learners.getD d dfltLearner).epoch ∧
    (c'.learners.getD d dfltLearner).jEpoch = (c.learners.getD d dfltLearner).jEpoch ∧
    (c'.learners.getD d dfltLearner).jUsed = (c.learners.getD d dfltLearner).jUsed
  unfold tagVal
  rw [h]
  exact ⟨rfl, rfl, rfl, rfl⟩

theorem regsOf_of_getD {P : StreamParams} {c : CState} {d : ℕ} {L : Learner}
    (h : c.learners.getD d dfltLearner = L) :
    (regsOf P c).Chat d = ((gridVal P.eHC L.tag : ℚ) : ℝ) ∧ (regsOf P c).k d = L.epoch ∧
      (regsOf P c).jE d = L.jEpoch ∧ (regsOf P c).jU d = L.jUsed := by
  show tagVal P c d = _ ∧ (c.learners.getD d dfltLearner).epoch = _ ∧
    (c.learners.getD d dfltLearner).jEpoch = _ ∧ (c.learners.getD d dfltLearner).jUsed = _
  unfold tagVal
  rw [h]
  exact ⟨rfl, rfl, rfl, rfl⟩

theorem gridVal_two_pow (q : ℕ) : gridVal q (2 ^ q) = 1 := by
  unfold gridVal
  push_cast
  exact div_self (pow_ne_zero _ two_ne_zero)

/-- The root tag `2^{eHC}` is `Ĉ_0 = 1`. -/
theorem tagVal_root {P : StreamParams} {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P ph c S nev) (hlive : 0 < ph.live P.H) : (regsOf P c).Chat 0 = 1 := by
  show tagVal P c 0 = 1
  unfold tagVal
  rw [h.root hlive, gridVal_two_pow]
  norm_num

/-! ## The integer formulas of the code as the real quantities of Section 5 -/

/-- `Ĉ δ̃ = h_g y` with `y = Cint 2^α √(2^e)` (`α = guardAlpha`, `e = u_d − k`), the quantity of
`Alg.guardMant_eq`. -/
theorem guard_key (P : StreamParams) (d k : ℕ) (Cint : ℤ) :
    ((gridVal P.eHC Cint : ℚ) : ℝ) * Tree.nomGuard P d k =
      (P.hg : ℝ) * ((Cint : ℝ) * (2 : ℝ) ^ (guardAlpha P) *
        Real.sqrt ((2 : ℝ) ^ ((P.eU d : ℤ) - (k : ℤ)))) := by
  have h2 : (2 : ℝ) ≠ 0 := two_ne_zero
  have hhg : (P.hg : ℝ) = (2 : ℝ) ^ (-(P.eHg : ℤ)) := by
    simp only [StreamParams.hg]; push_cast; rw [zpow_neg, zpow_natCast, one_div, inv_pow]
  have hγ : (P.gamma : ℝ) = (2 : ℝ) ^ (-(P.eGamma : ℤ)) := by
    simp only [StreamParams.gamma]; push_cast; rw [zpow_neg, zpow_natCast, one_div, inv_pow]
  have hU : ((P.Ud d : ℕ) : ℝ) / 2 ^ k = (2 : ℝ) ^ ((P.eU d : ℤ) - (k : ℤ)) := by
    rw [zpow_sub₀ h2, zpow_natCast, zpow_natCast]; simp [StreamParams.Ud]
  have hC : ((gridVal P.eHC Cint : ℚ) : ℝ) = (Cint : ℝ) * (2 : ℝ) ^ (-(P.eHC : ℤ)) := by
    simp only [gridVal]; push_cast; rw [zpow_neg, zpow_natCast, div_eq_mul_inv]
  have hα : (2 : ℝ) ^ (-(P.eHg : ℤ)) * (2 : ℝ) ^ (guardAlpha P) =
      (2 : ℝ) ^ (-(P.eHC : ℤ)) * ((2 : ℝ) ^ (-(P.eGamma : ℤ)) / 4) := by
    have e1 : -(P.eHg : ℤ) + guardAlpha P = -(P.eHC : ℤ) + (-(P.eGamma : ℤ) + (-2)) := by
      unfold guardAlpha; ring
    rw [← zpow_add₀ h2, e1, zpow_add₀ h2, zpow_add₀ h2]
    have e2 : (2 : ℝ) ^ (-2 : ℤ) = 1 / 4 := by norm_num
    rw [e2]
    ring
  unfold Tree.nomGuard Tree.env
  rw [hC, hγ, hU, hhg]
  calc (Cint : ℝ) * 2 ^ (-(P.eHC : ℤ)) * (2 ^ (-(P.eGamma : ℤ)) / 4 * √(2 ^ ((P.eU d : ℤ) - (k : ℤ))))
      = (Cint : ℝ) * (2 ^ (-(P.eHC : ℤ)) * (2 ^ (-(P.eGamma : ℤ)) / 4)) *
          √(2 ^ ((P.eU d : ℤ) - (k : ℤ))) := by ring
    _ = (Cint : ℝ) * (2 ^ (-(P.eHg : ℤ)) * 2 ^ (guardAlpha P)) * √(2 ^ ((P.eU d : ℤ) - (k : ℤ))) := by
        rw [hα]
    _ = 2 ^ (-(P.eHg : ℤ)) * ((Cint : ℝ) * 2 ^ (guardAlpha P) * √(2 ^ ((P.eU d : ℤ) - (k : ℤ)))) := by
        ring

/-- **The Step-3 guard of the code is the guard of Section 5** (Algorithm L488–489, eq.
`R:eq:committed-guard-amplitude`): for a tag mantissa `Cint ≥ 0` and epoch `k`,
`gridVal_{h_g}(guardMant Cint α (u_d − k)) = guardAmp(h_g, Ĉ, δ̃_{d,k})`. -/
theorem guard_bridge (P : StreamParams) (d k : ℕ) (Cint : ℤ) (hC : 0 ≤ Cint) :
    ((gridVal P.eHg (guardMant Cint (guardAlpha P) ((P.eU d : ℤ) - (k : ℤ))) : ℚ) : ℝ) =
      Tree.guardAmp (P.hg : ℝ) ((gridVal P.eHC Cint : ℚ) : ℝ) (Tree.nomGuard P d k) := by
  have hh : (0 : ℝ) < (P.hg : ℝ) := by exact_mod_cast P.hg_pos
  have hhg : (P.hg : ℝ) = 1 / 2 ^ P.eHg := by
    simp only [StreamParams.hg]; push_cast; rw [one_div_pow]
  rw [guardMant_eq Cint (guardAlpha P) ((P.eU d : ℤ) - (k : ℤ)) hC]
  unfold Tree.guardAmp Tree.roundGrid
  rw [guard_key]
  set y : ℝ := (Cint : ℝ) * (2 : ℝ) ^ (guardAlpha P) * Real.sqrt ((2 : ℝ) ^ ((P.eU d : ℤ) - (k : ℤ)))
    with hy
  by_cases hy2 : y < 2
  · have : (P.hg : ℝ) * y < 2 * P.hg := by nlinarith
    rw [if_pos hy2, if_pos this]
    simp [gridVal]
  · have : ¬ ((P.hg : ℝ) * y < 2 * P.hg) := fun h' => hy2 (by nlinarith)
    rw [if_neg hy2, if_neg this]
    have hdiv : (P.hg : ℝ) * y / P.hg = y := by field_simp
    rw [hdiv, hhg]
    simp only [gridVal]
    push_cast
    ring

/-- **The Step-4 multiplier of the code is the multiplier of Section 5** (Algorithm L504): for `P, Q̂ > 0`,
`gridVal_{h_step}(stepCoeffMant) = 1 + clamp_{[-1/2,1/2]} round_{h_step}(s (η/16) √(P/Q̂))`. -/
theorem step_bridge (P : StreamParams) (pos : Bool) (Pval Qhat : ℚ) (hP : 0 < Pval) (hQ : 0 < Qhat) :
    ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep Pval Qhat) : ℚ) : ℝ) =
      1 + max (-1 / 2) (min (1 / 2) (Tree.roundGrid (P.hstep : ℝ)
        ((if pos then (1 : ℝ) else -1) * ((P.eta : ℝ) / 16 * √((Pval : ℝ) / (Qhat : ℝ)))))) := by
  have hqs : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
  rw [stepCoeffMant_eq pos P.eEta P.eHstep Pval Qhat hP hQ hqs]
  have h2pos : (0 : ℝ) < 2 ^ P.eHstep := by positivity
  have hhs : (P.hstep : ℝ) = 1 / 2 ^ P.eHstep := by
    simp only [StreamParams.hstep]; push_cast; rw [one_div_pow]
  have hη : (P.eta : ℝ) = (1 / 2 : ℝ) ^ P.eEta := by
    simp only [StreamParams.eta]; push_cast; rfl
  set w : ℝ := (if pos then (1 : ℝ) else -1) * ((1 / 2 : ℝ) ^ P.eEta / 16 * Real.sqrt ((Pval : ℝ) / Qhat))
    with hw
  have hround : Tree.roundGrid (P.hstep : ℝ)
      ((if pos then (1 : ℝ) else -1) * ((P.eta : ℝ) / 16 * √((Pval : ℝ) / (Qhat : ℝ)))) =
      (⌊w * (2 : ℝ) ^ P.eHstep + 1 / 2⌋ : ℝ) / 2 ^ P.eHstep := by
    unfold Tree.roundGrid
    rw [hhs, hη, ← hw]
    have : w / (1 / 2 ^ P.eHstep) = w * 2 ^ P.eHstep := by field_simp
    rw [this]
    field_simp
  have hpow : (2 : ℝ) ^ P.eHstep = 2 * 2 ^ (P.eHstep - 1) := by
    rw [← pow_succ']; congr 1; omega
  simp only [gridVal, clampZ]
  push_cast
  rw [hround]
  set z : ℝ := (⌊w * (2 : ℝ) ^ P.eHstep + 1 / 2⌋ : ℝ)
  have hk : (0 : ℝ) < 2 ^ (P.eHstep - 1) := by positivity
  rw [add_div, div_self h2pos.ne']
  congr 1
  rw [← max_div_div_right h2pos.le, ← min_div_div_right h2pos.le, hpow]
  congr 1
  · field_simp
  · congr 1
    field_simp

/-! ## The tree component, block by block -/

variable {P : StreamParams}

/-- Round `1` starts from the initial tree state with no learner. -/
theorem tree_init (hP : ParamsOK P) (c : CState) :
    Tree.TreeInv P (.births 0) (regsOf P c) ((Tree.TreeState.init P.Dstar).step P .newRound) :=
  Tree.treeInv_init hP.one_le_m (regsOf P c)

/-- A new round: retirement of the learners `≥ d₀ = firstBorn H (t+1)`. -/
theorem tree_newRound {c : CState} {S : Tree.TreeSt P} {nev : ℕ}
    (h : TreePart P .idle c S nev) (ht : S.t < P.m) :
    Tree.TreeInv P (.births (firstBorn P.H (S.t + 1)))
      (regsOf P { c with learners := c.learners.take (firstBorn P.H (S.t + 1)) }) (S.step P .newRound) :=
  Tree.treeInv_newRound h.tree ht (firstBorn_lt P.H (S.t + 1) P.one_le_H)
    (fun _ hd => regsOf_eq_of_getD (tr_getD_take_of_lt c.learners hd))

/-- The birth of depth `d` (`newLearner P cache`: `Ĉ = 1`, `k = j_epoch = J_used = 0`). -/
theorem tree_birth (hP : ParamsOK P) {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.births d) c S nev) (hd : d < P.H) (hbox : ‖S.x0‖ ≤ (P.W : ℝ)) (cache : ℤ) :
    Tree.TreeInv P (.births (d + 1)) (regsOf P { c with learners := c.learners ++ [newLearner P cache] })
      (S.step P (.birth d)) := by
  have hlen : c.learners.length = d := h.nLearners
  have hget : (c.learners ++ [newLearner P cache]).getD d dfltLearner = newLearner P cache := by
    rw [List.getD_append_right _ _ _ _ (by omega), hlen, Nat.sub_self]; rfl
  refine Tree.treeInv_birth h.tree hd hP.one_le_n hP.one_le_U hbox
    (fun j hj => regsOf_eq_of_getD (List.getD_append _ _ _ _ (by omega))) ?_
  obtain ⟨h1, h2, h3, h4⟩ := regsOf_of_getD (P := P)
    (c := { c with learners := c.learners ++ [newLearner P cache] }) hget
  rw [h1, h2, h3, h4]
  refine ⟨?_, rfl, rfl, rfl⟩
  show ((gridVal P.eHC (2 ^ P.eHC) : ℚ) : ℝ) = 1
  rw [gridVal_two_pow]
  norm_num

/-- Step 2: the physical update (the accumulator is not a register). -/
theorem tree_phys {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.births P.H) c S nev)
    (i : Fin P.n) (Δ : ℤ) (leaf : ℤ) :
    Tree.TreeInv P (.guards 0) (regsOf P { c with leaf := leaf }) (S.step P (.phys i Δ)) :=
  Tree.treeInv_phys h.tree i Δ

/-- The zero-round bypass. -/
theorem tree_bypass {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards 0) c S nev) :
    Tree.TreeInv P .idle (regsOf P c) S :=
  Tree.treeInv_bypass h.tree

/-- Step 3 at depth `d`, any guard: the analysis event `guard d g δ` with the code's guard
`δ = gridVal_{h_g}(guardMant …)`, under the tag precision and `Ĉ_d ≥ 0`. -/
theorem tree_guard_gen {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (hd : d < P.H) (ht : c.t + 1 = S.t)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (htag : |tagVal P c d - S.C d| ≤ (P.eC : ℝ))
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    Tree.TreeInv P (.guards (d + 1)) (regsOf P c)
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩
        ((gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) : ℚ) : ℝ))) := by
  have hget := tr_getD_of_getElem? hLd
  have htag0 : 0 ≤ Ld.tag := by have := h.tagNonneg d hd; rwa [hget] at this
  have hgi : (⟨P.guardCoord d (c.t + 1) - 1, hg⟩ : Fin P.Dstar).val = Tree.guardIdx P d S.t := by
    show P.guardCoord d (c.t + 1) - 1 = P.guardCoord d S.t - 1
    rw [ht]
  have hδ : ((gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) : ℚ) : ℝ) =
      Tree.guardAmp P.hg ((regsOf P c).Chat d) (Tree.nomGuard P d ((regsOf P c).k d)) := by
    rw [guard_bridge P d Ld.epoch Ld.tag htag0]
    show _ = Tree.guardAmp P.hg (tagVal P c d) (Tree.nomGuard P d (c.learners.getD d dfltLearner).epoch)
    unfold tagVal
    rw [hget]
  exact (Tree.treeInv_guard h.tree hd _ hgi _ hδ htag).1

/-- Step 3 at depth `d`, omitted guard (`δ = 0`). -/
theorem tree_guard_zero {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (hd : d < P.H) (ht : c.t + 1 = S.t)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (htag : |tagVal P c d - S.C d| ≤ (P.eC : ℝ))
    (hδ : guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ)) = 0)
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) :
    Tree.TreeInv P (.guards (d + 1)) (regsOf P c)
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩ ((gridVal P.eHg 0 : ℚ) : ℝ))) := by
  have := tree_guard_gen h hd ht hLd htag hg
  rw [hδ] at this
  exact this

/-- Step 3 at depth `d`, injected guard: the cache and accumulator updates are not registers. -/
theorem tree_guard {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (hd : d < P.H) (ht : c.t + 1 = S.t)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (htag : |tagVal P c d - S.C d| ≤ (P.eC : ℝ))
    (hg : P.guardCoord d (c.t + 1) - 1 < P.Dstar) (cache leaf : ℤ) :
    Tree.TreeInv P (.guards (d + 1))
      (regsOf P { c with learners := setAt { Ld with cache := cache } d c.learners, leaf := leaf })
      (S.step P (.guard d ⟨P.guardCoord d (c.t + 1) - 1, hg⟩
        ((gridVal P.eHg (guardMant Ld.tag (guardAlpha P) ((P.eU d : ℤ) - (Ld.epoch : ℤ))) : ℚ) : ℝ))) := by
  have hT := tree_guard_gen h hd ht hLd htag hg
  have hget := tr_getD_of_getElem? hLd
  have hR : regsOf P { c with learners := setAt { Ld with cache := cache } d c.learners, leaf := leaf } =
      regsOf P c := by
    have hlen : d < c.learners.length := by rw [h.nLearners]; exact hd
    have hj : ∀ j, (setAt { Ld with cache := cache } d c.learners).getD j dfltLearner =
        { (c.learners.getD j dfltLearner) with cache := if j = d then cache else
          (c.learners.getD j dfltLearner).cache } := by
      intro j
      by_cases hjd : j = d
      · rw [hjd, tr_getD_setAt_self _ _ hlen, hget, if_pos rfl]
      · rw [tr_getD_setAt_ne _ _ hjd, if_neg hjd]
    unfold regsOf tagVal
    congr 1 <;> funext j <;> simp only [hj]
  rw [hR]
  exact hT

/-- The end of Step 3 is the start of Step 4. -/
theorem tree_startStep4 {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.guards P.H) c S nev) :
    Tree.TreeInv P (.evals P.H) (regsOf P c) S :=
  Tree.treeInv_startStep4 h.tree

/-- Step 4 at depth `d`, `ACCEPT`. -/
theorem tree_accept {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) :
    Tree.TreeInv P (.evals d) (regsOf P c) (S.step P (.accept d)) :=
  Tree.treeInv_accept h.tree hd

/-! ## Step 4, rejection -/

/-- The multiplier of the code lies in `[1/2, 3/2]` (on every execution, `Alg.stepCoeffMant_mem`). -/
theorem stepCoeff_mem (P : StreamParams) (pos : Bool) (Pval Qhat : ℚ) :
    (1 / 2 : ℝ) ≤ ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep Pval Qhat) : ℚ) : ℝ) ∧
      ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep Pval Qhat) : ℚ) : ℝ) ≤ 3 / 2 := by
  have hqs : 1 ≤ P.eHstep := by unfold StreamParams.eHstep; omega
  obtain ⟨h1, h2⟩ := stepCoeffMant_mem pos P.eEta P.eHstep Pval Qhat hqs
  have h1' : ((2 : ℝ) ^ (P.eHstep - 1)) ≤ (stepCoeffMant pos P.eEta P.eHstep Pval Qhat : ℝ) := by
    exact_mod_cast h1
  have h2' : (stepCoeffMant pos P.eEta P.eHstep Pval Qhat : ℝ) ≤ 3 * (2 : ℝ) ^ (P.eHstep - 1) := by
    exact_mod_cast h2
  have hpow : (2 : ℝ) ^ P.eHstep = 2 * 2 ^ (P.eHstep - 1) := by
    rw [← pow_succ']; congr 1; omega
  have hk : (0 : ℝ) < 2 ^ (P.eHstep - 1) := by positivity
  simp only [gridVal]
  push_cast
  rw [hpow]
  constructor
  · rw [le_div_iff₀ (by positivity)]; linarith
  · rw [div_le_iff₀ (by positivity)]; linarith

/-- `countCorrection` succeeds when the epoch cap holds. -/
theorem countCorrection_isSome (P : StreamParams) (L : Learner) (h : L.epoch + 1 ≤ P.Kepoch) :
    ∃ L', Learner.countCorrection P L = some L' := by
  unfold Learner.countCorrection
  split_ifs
  · exact ⟨_, rfl⟩
  · exact ⟨_, rfl⟩

/-- The registers after `countCorrection` (Algorithm L509). -/
theorem countCorrection_regs {P : StreamParams} {L L' : Learner} (h : Learner.countCorrection P L = some L') :
    L'.tag = L.tag ∧ L'.jUsed = L.jUsed + 1 ∧
      ((L.jEpoch + 1 = P.K0 ∧ L'.epoch = L.epoch + 1 ∧ L'.jEpoch = 0) ∨
        (L.jEpoch + 1 ≠ P.K0 ∧ L'.epoch = L.epoch ∧ L'.jEpoch = L.jEpoch + 1)) := by
  unfold Learner.countCorrection at h
  by_cases h1 : L.jEpoch + 1 = P.K0
  · rw [if_pos h1] at h
    by_cases h2 : L.epoch + 1 ≤ P.Kepoch
    · rw [if_pos h2] at h; cases h; exact ⟨rfl, rfl, Or.inl ⟨h1, rfl, rfl⟩⟩
    · rw [if_neg h2] at h; cases h
  · rw [if_neg h1] at h; cases h; exact ⟨rfl, rfl, Or.inr ⟨h1, rfl, rfl⟩⟩

/-- The hypotheses of `Tree.treeInv_correct` at a rejection of depth `d`, in the code's quantities. -/
theorem reject_hyps {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) {F : ℚ} (hF0 : 0 ≤ F)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1))
    (hcacheP : |cacheVal P c d - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P) :
    (regsOf P c).Chat 0 = 1 ∧ (0 : ℝ) ≤ ((gridVal P.eHP Ld.cache : ℚ) : ℝ) ∧ (0 : ℝ) ≤ (F : ℝ) ∧
      |((gridVal P.eHP Ld.cache : ℚ) : ℝ) - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P ∧
      ((if pos then (1 : ℝ) else -1) = 1 ∨ (if pos then (1 : ℝ) else -1) = -1) ∧
      (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
        (if pos then (1 : ℝ) else -1) * ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) /
          (((gridVal P.eHP Ld.cache : ℚ) : ℝ) + (F : ℝ) + (P.omega : ℝ)) - 1) := by
  have hget := tr_getD_of_getElem? hLd
  have hlive0 : 0 < Tree.Phase.live P.H (.evals (d + 1)) := by show 0 < P.H; omega
  have hPc : cacheVal P c d = ((gridVal P.eHP Ld.cache : ℚ) : ℝ) := by unfold cacheVal; rw [hget]
  have hc0 : 0 ≤ Ld.cache := by have := h.cacheNonneg d hd; rwa [hget] at this
  refine ⟨tagVal_root h hlive0, ?_, by exact_mod_cast hF0, by rw [← hPc]; exact hcacheP,
    by cases pos <;> simp, ?_⟩
  · simp only [gridVal]; push_cast
    have : (0 : ℝ) ≤ (Ld.cache : ℝ) := by exact_mod_cast hc0
    positivity
  · have e : (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ)) = ((gridVal P.eHP Ld.cache : ℚ) : ℝ) + (F : ℝ) := by
      push_cast; ring
    rw [e] at hcert
    exact hcert

/-- Theorem 5.9 at a Step-4 rejection of depth `d` in the code's quantities: the positive-denominator rule
is inactive (`P_d > 0`, `Q̂ > 0`), the epoch margin `k_d + 13 ≤ K_epoch` (Theorem 5.11 (2c)), and the code's
multiplier is the multiplier of Section 5. -/
theorem reject_facts {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1))
    (hcacheP : |cacheVal P c d - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P) :
    0 < gridVal P.eHP Ld.cache ∧ 0 < F ∧ Ld.epoch + 13 ≤ P.Kepoch ∧
      ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ) =
        1 + max (-1 / 2) (min (1 / 2) (Tree.roundGrid (P.hstep : ℝ)
          ((if pos then (1 : ℝ) else -1) * ((P.eta : ℝ) / 16 *
            √(((gridVal P.eHP Ld.cache : ℚ) : ℝ) / (F : ℝ)))))) := by
  obtain ⟨hroot, hP0, hQ0, hcache, hs, hcert'⟩ := reject_hyps h hd hF0 hLd pos hcert hcacheP
  have hget := tr_getD_of_getElem? hLd
  obtain ⟨hPpos, hQpos, -, -, -, hEmin, -, -⟩ :=
    Tree.correct_step4 h.tree hd hx0 hroot hP0 hQ0 hcache hF hs hcert' rfl
  have hmargin := Tree.correct_epoch_margin h.tree hd hEmin
  have hk : (regsOf P c).k d = Ld.epoch := (regsOf_of_getD (P := P) hget).2.1
  have hPq : 0 < gridVal P.eHP Ld.cache := by exact_mod_cast hPpos
  have hFq : 0 < F := by exact_mod_cast hQpos
  refine ⟨hPq, hFq, by rw [← hk]; exact hmargin, ?_⟩
  rw [step_bridge P pos _ F hPq hFq]

/-- Step 4 at depth `d`, rejection, the correction: C-TREE's invariant after the analysis event `correct d c`
(`c = cInt h_step`) for the registers computed by the code (strict descendants rescaled, `countCorrection` of
depth `d` with the refreshed cache `cache'`). -/
theorem tree_reject {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1))
    (htag : |tagVal P c d - S.C d| ≤ (P.eC : ℝ))
    (hcacheP : |cacheVal P c d - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P)
    (cache' : ℤ) {Ld' : Learner} (hLd' : Learner.countCorrection P { Ld with cache := cache' } = some Ld')
    (leaf' : ℤ) :
    Tree.TreeInv P (.evals d)
      (regsOf P { c with
        learners := setAt Ld' d (mapFrom (Learner.rescale P
          (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1) c.learners),
        leaf := leaf' })
      (S.step P (.correct d ((gridVal P.eHstep
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ))) := by
  obtain ⟨hroot, hP0, hQ0, hcache, hs, hcert'⟩ := reject_hyps h hd hF0 hLd pos hcert hcacheP
  obtain ⟨-, -, -, hc⟩ := reject_facts h hd hx0 hF0 hF hLd pos hcert hcacheP
  have hget := tr_getD_of_getElem? hLd
  have hlen : d < (mapFrom (Learner.rescale P
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1) c.learners).length := by
    rw [length_mapFrom, h.nLearners]; exact hd
  have hgetd := tr_getD_setAt_self Ld' _ hlen
  obtain ⟨h1', h2', h3', h4'⟩ := regsOf_of_getD (P := P) (c := { c with
    learners := setAt Ld' d (mapFrom (Learner.rescale P
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1) c.learners),
    leaf := leaf' }) hgetd
  obtain ⟨g1, g2, g3, g4⟩ := regsOf_of_getD (P := P) (c := c) hget
  obtain ⟨ctag, cjU, ccase⟩ := countCorrection_regs hLd'
  refine (Tree.treeInv_correct h.tree hd hx0 hroot hP0 hQ0 hcache hF hs hcert' htag hc ?_ ?_ ?_).1
  · intro j hj
    apply regsOf_eq_of_getD
    show (setAt Ld' d _).getD j dfltLearner = c.learners.getD j dfltLearner
    rw [tr_getD_setAt_ne _ _ (by omega), tr_getD_mapFrom_lt _ _ (by omega)]
  · rw [h1', g1, h2', g2, h3', g3, h4', g4, ctag, cjU]
    refine ⟨rfl, rfl, ?_⟩
    rcases ccase with ⟨e1, e2, e3⟩ | ⟨e1, e2, e3⟩
    · exact Or.inl ⟨e1, e2, e3⟩
    · exact Or.inr ⟨e1, e2, e3⟩
  · intro j hj
    have e : (setAt Ld' d (mapFrom (Learner.rescale P
        (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1) c.learners)).getD j dfltLearner =
        (mapFrom (Learner.rescale P
          (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F)) (d + 1) c.learners).getD j dfltLearner :=
      tr_getD_setAt_ne _ _ (by omega)
    obtain ⟨r1, r2, r3⟩ := tr_getD_mapFrom_rescale P
      (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) c.learners (d + 1) j
    show (_ : ℕ) = _ ∧ (_ : ℕ) = _ ∧ (_ : ℕ) = _
    refine ⟨?_, ?_, ?_⟩
    · show ((setAt Ld' d _).getD j dfltLearner).epoch = (c.learners.getD j dfltLearner).epoch
      rw [e, r1]
    · show ((setAt Ld' d _).getD j dfltLearner).jEpoch = (c.learners.getD j dfltLearner).jEpoch
      rw [e, r2]
    · show ((setAt Ld' d _).getD j dfltLearner).jUsed = (c.learners.getD j dfltLearner).jUsed
      rw [e, r3]

/-! ## The checks that follow from the tree invariant -/

/-- The live learners are stored. -/
theorem tree_learner_some {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P ph c S nev) (hd : d < ph.live P.H) :
    c.learners[d]? = some (c.learners.getD d dfltLearner) := by
  have hlen : d < c.learners.length := by rw [h.nLearners]; exact hd
  rw [List.getElem?_eq_getElem hlen, List.getD_eq_getElem _ _ hlen]

/-- The lifetime correction counter stays below the client cap `J_*` (Theorem 5.11 (2c)). -/
theorem tree_jUsed_lt {ph : Tree.Phase} {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P ph c S nev) (hd : d < ph.live P.H) :
    (c.learners.getD d dfltLearner).jUsed < P.Jstar := by
  obtain ⟨hJ, hjE, hk⟩ := h.tree.counters d hd
  have hJ' : (c.learners.getD d dfltLearner).jUsed =
      P.K0 * (c.learners.getD d dfltLearner).epoch + (c.learners.getD d dfltLearner).jEpoch := hJ
  have hjE' : (c.learners.getD d dfltLearner).jEpoch < P.K0 := hjE
  have hk' : (c.learners.getD d dfltLearner).epoch + 12 ≤ P.Kepoch := hk
  have h1 : P.K0 * ((c.learners.getD d dfltLearner).epoch + 1) ≤ P.K0 * (P.Kepoch + 1) :=
    Nat.mul_le_mul_left _ (by omega)
  have h2 : P.K0 * ((c.learners.getD d dfltLearner).epoch + 1) =
      P.K0 * (c.learners.getD d dfltLearner).epoch + P.K0 := Nat.mul_succ _ _
  have hJs : P.Jstar = P.K0 * (P.Kepoch + 1) := rfl
  omega

/-- Step 4, `ACCEPT` (Theorem 5.9 (2)): the returned `S = P_d + Q̂` has accuracy `8(ℓ+1)η` for `‖x_d‖²`. -/
theorem accept_acc {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld)
    (hcert : |(‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1| ≤
      (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) + (P.eta : ℝ) / 4) :
    |((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) - ‖S.x d‖ ^ 2| ≤
      8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 := by
  have hget := tr_getD_of_getElem? hLd
  have hlive0 : 0 < Tree.Phase.live P.H (.evals (d + 1)) := by show 0 < P.H; omega
  have hc0 : 0 ≤ Ld.cache := by have := h.cacheNonneg d hd; rwa [hget] at this
  have hP0 : (0 : ℝ) ≤ ((gridVal P.eHP Ld.cache : ℚ) : ℝ) := by
    simp only [gridVal]; push_cast
    have : (0 : ℝ) ≤ (Ld.cache : ℝ) := by exact_mod_cast hc0
    positivity
  have e : (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ)) = ((gridVal P.eHP Ld.cache : ℚ) : ℝ) + (F : ℝ) := by
    push_cast; ring
  rw [e] at hcert ⊢
  exact Tree.accept_accuracy h.tree hd hx0 (tagVal_root h hlive0) hP0 (by exact_mod_cast hF0) hcert

/-- Step 4, rejection, before the correction (`rejectDepthCode`): the client cap and the positive-denominator
rule pass, the multiplier lies in `[1/2, 3/2]`, the epoch cap of `countCorrection` holds, and the release `N₁`
of `x_d` with its numerical certificate has accuracy `8(ℓ+1)η` (eq. `R:eq:post-rejection-N1-handoff`). -/
theorem reject_pre_tree {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (hd : d < P.H) (hx0 : 1 ≤ ‖S.x0‖) {F : ℚ} (hF0 : 0 ≤ F)
    (hF : |(F : ℝ) - ‖S.x (d + 1)‖ ^ 2| ≤ 8 * ((P.H - d : ℕ) : ℝ) * (P.eta : ℝ) * ‖S.x (d + 1)‖ ^ 2)
    {Ld : Learner} (hLd : c.learners[d]? = some Ld) (pos : Bool)
    (hcert : (8 * ((P.H - d : ℕ) : ℝ) + 4) * (P.eta : ℝ) - (P.eta : ℝ) / 4 ≤
      (if pos then 1 else -1) *
        ((‖S.x d‖ ^ 2 + (P.omega : ℝ)) / (((gridVal P.eHP Ld.cache + F : ℚ) : ℝ) + (P.omega : ℝ)) - 1))
    (hcacheP : |cacheVal P c d - S.E d| ≤ (P.eta : ℝ) / 2 ^ 12 * S.E d + Tree.cacheDrift P) :
    ¬ (P.Jstar ≤ Ld.jUsed ∨ Ld.cache ≤ 0 ∨ F ≤ 0) ∧
      (1 / 2 : ℝ) ≤ ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ) ∧
      ((gridVal P.eHstep (stepCoeffMant pos P.eEta P.eHstep (gridVal P.eHP Ld.cache) F) : ℚ) : ℝ) ≤ 3 / 2 ∧
      Ld.epoch + 1 ≤ P.Kepoch ∧
      ∀ N1 : ℚ, NumCert (P.eta : ℝ) (P.omega : ℝ) (‖S.x d‖ ^ 2) (N1 : ℝ) →
        |(N1 : ℝ) - ‖S.x d‖ ^ 2| ≤ 8 * (((P.H - d : ℕ) : ℝ) + 1) * (P.eta : ℝ) * ‖S.x d‖ ^ 2 := by
  obtain ⟨hPq, hFq, hmargin, -⟩ := reject_facts h hd hx0 hF0 hF hLd pos hcert hcacheP
  have hget := tr_getD_of_getElem? hLd
  have hlive : d < Tree.Phase.live P.H (.evals (d + 1)) := hd
  have hJ := tree_jUsed_lt h hlive
  rw [hget] at hJ
  have hc0 : 0 < Ld.cache := by
    unfold gridVal at hPq
    have h2 : (0 : ℚ) < 2 ^ P.eHP := by positivity
    have : (0 : ℚ) < (Ld.cache : ℚ) := by
      have := (div_pos_iff_of_pos_right h2).1 hPq
      exact this
    exact_mod_cast this
  obtain ⟨m1, m2⟩ := stepCoeff_mem P pos (gridVal P.eHP Ld.cache) F
  refine ⟨?_, m1, m2, by omega, ?_⟩
  · rintro (h1 | h1 | h1)
    · omega
    · omega
    · linarith
  · intro N1 hN
    have hlive0 : 0 < Tree.Phase.live P.H (.evals (d + 1)) := by show 0 < P.H; omega
    apply Tree.reject_accuracy h.tree hd hx0 (tagVal_root h hlive0)
    unfold NumCert at hN
    have e : (1 / 2 : ℝ) ^ 13 * (P.eta : ℝ) * ‖S.x d‖ ^ 2 = (P.eta : ℝ) * ‖S.x d‖ ^ 2 / 2 ^ 13 := by ring
    rw [e] at hN
    exact hN

/-! ## `nLearners` and `bornZero` at the next moment -/

/-- After the birth of depth `d`, its outgoing vector vanishes: `x_{d+1} = x_d − r_d = 0`. -/
theorem tree_bornZero_birth (S : Tree.TreeSt P) (d : ℕ) :
    ∀ D, Tree.Phase.births (d + 1) = Tree.Phase.births D → firstBorn P.H (S.step P (.birth d)).t < D →
      (S.step P (.birth d)).x D = 0 := by
  intro D hD _
  cases hD
  rw [Tree.TreeState.x_succ, Tree.x_birth_le S le_rfl, Tree.step_birth_r, Function.update_self, sub_self]

/-- `bornZero` holds vacuously outside Step 1. -/
theorem tree_bornZero_of_ne {ph : Tree.Phase} (hph : ∀ D, ph ≠ Tree.Phase.births D) (S : Tree.TreeSt P) :
    ∀ D, ph = Tree.Phase.births D → firstBorn P.H S.t < D → S.x D = 0 :=
  fun D hD => absurd hD (hph D)

theorem tree_nLearners_birth {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.births d) c S nev) (cache : ℤ) :
    (c.learners ++ [newLearner P cache]).length = Tree.Phase.live P.H (.births (d + 1)) := by
  rw [List.length_append, h.nLearners]; rfl

theorem tree_nLearners_guard {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.guards d) c S nev) (L : Learner) :
    (setAt L d c.learners).length = Tree.Phase.live P.H (.guards (d + 1)) := by
  rw [length_setAt]; exact h.nLearners

theorem tree_nLearners_reject {c : CState} {S : Tree.TreeSt P} {nev d : ℕ}
    (h : TreePart P (.evals (d + 1)) c S nev) (L : Learner) (f : Learner → Learner) :
    (setAt L d (mapFrom f (d + 1) c.learners)).length = Tree.Phase.live P.H (.evals d) := by
  rw [length_setAt, length_mapFrom]; exact h.nLearners

/-- The end of Step 4. -/
theorem tree_endRound {c : CState} {S : Tree.TreeSt P} {nev : ℕ} (h : TreePart P (.evals 0) c S nev) :
    Tree.TreeInv P .idle (regsOf P c) S :=
  Tree.treeInv_endRound h.tree

end F2e2e.C.Closure
