import F2e2e.C.ClosureProbLabels
import F2e2e.C.ClosureProbSim
import F2e2e.C.ClosureProbHandle
import F2e2e.C.ClosureProbShape

/-!
# Theorem 6.4, probability layer (C-PROB): the ADA event of one bank

Paper: `parts/partIII.tex` L1271–1277 ("Fix one bank. Its updates, candidate scales, coefficients, guards, and stopping
decisions are functions of protected outputs and auxiliary randomness initially independent of its ADA sample. Other
banks' outputs are not assumed independent after interaction: after fixing their complete initial tapes, they can be
simulated from the selected bank's permitted history. … Theorem `R:thm:validation_ada` consequently supplies each
bank's unconditional capped ADA event"); the ADA module of every bank is B-ARCH's core with the parameters
`bankAda P = adaAlg2Params m J_max R_max a_num (β_B/2)` (partIII.tex L205; `bankAdaParams_eq_dyadicExp`).

Proof structure (design "controller code over oracles"):
* retag the bits of the tagged interaction: `true` for the ADA sample seeds and coins of bank `lab` (`adaSel lab`),
  `false` for all other bits (including the bank's coarse groups);
* the whole interaction is the controller program `fullCode` (`interactT_eq`); its instrumented run is the oracle-split
  run `handle P (runX …)` with bank `lab`'s ADA module run by B's online core, and bank `lab`'s transcript is the
  oracle's transcript (`sim`, `ClosureProbSim.lean`; bank `lab` is born at most once, C-FP's `birthsOK_fullCode_once`);
* for a fixed `false`-stream `a`, the oracle program is B's online core against the composite controller obtained by
  walking the oracle program with the bits `a` (B-PRIV's `handle_count`, `ClosureProbHandle.lean`, from B's core-level
  guarantee `core_guarantee_det` and the uniform seed sample) — `ada_block_count`;
* `card_le_of_blocks` turns this into the tape count `card_not_adaGood_le`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg
open scoped ENNReal

/-! ## From the instrumented run to the oracle program -/

theorem retag_map' {ι ι' α β : Type} (f : ι → ι') (p : TBitProg ι α) (h : α → β) :
    (p.map h).retag f = (p.retag f).map h := by
  unfold TBitProg.map
  rw [retag_bind]
  rfl

theorem runS_map' {ι α β : Type} [DecidableEq ι] (p : TBitProg ι α) (h : α → β) (σ : ι → List Bool) :
    (p.map h).runS σ = (p.runS σ).map fun r => (h r.1, r.2) := by
  unfold TBitProg.map
  rw [runS_bind]
  cases p.runS σ with
  | none => rfl
  | some r => rfl

/-- **A bad run gives a bad run of the oracle program**: if bank `lab`'s ADA event fails on the run with the streams
`(a, l)`, then the oracle-split run with B's online core on the same streams fails at the core level. -/
theorem handle_bad_of_real (P : StreamParams) (adv : StreamAdversary P.n) (lab : BankLabel)
    (hB : BirthOnce lab false (fullCode P adv P.m)) (a l : List Bool)
    (h : ∃ x, (((interactT P adv P.m).retag (adaSel lab)).runS (pairStreams a l)).map Prod.fst = some x ∧
      x ∈ adaBad P lab) :
    ∃ x ost σ', (handle P (runX P lab false (fullCode P adv P.m) initO Ghost.init) none).runS
        (pairStreams a l) = some ((x, ost), σ') ∧
      coreFails (bankAda P) (unifD P) (P.aNum : ℝ) (ctrlOf (trvOf ost)) ((trvOf ost).map Prod.snd) := by
  obtain ⟨x, hx, hbad⟩ := h
  rw [interactT_eq, retag_map', runS_map'] at hx
  cases hR : ((runL P (fullCode P adv P.m) initO Ghost.init).retag (adaSel lab)).runS (pairStreams a l) with
  | none => rw [hR] at hx; simp at hx
  | some rσ =>
    obtain ⟨r, σ'⟩ := rσ
    rw [hR] at hx
    simp only [Option.map_some, Option.some.injEq] at hx
    subst hx
    obtain ⟨c, hc, hgood⟩ := hbad
    simp only [packC, Option.some.injEq] at hc
    subst hc
    have hsim := congrArg (fun q => q.runS (pairStreams a l)) (sim P lab _ hB)
    simp only [runS_map', hR, Option.map_some] at hsim
    cases hH : (handle P (runX P lab false (fullCode P adv P.m) initO Ghost.init) none).runS
        (pairStreams a l) with
    | none => rw [hH] at hsim; simp at hsim
    | some yσ =>
      obtain ⟨y, σ''⟩ := yσ
      rw [hH] at hsim
      have h1 : (simOut P lab r, σ') = ((y.1, trvOf y.2), σ'') := Option.some.inj hsim
      have htr' : trvOf y.2 = adaTranscript P lab r.2.2 := (congrArg (fun z => z.1.2) h1).symm
      refine ⟨y.1, y.2, σ'', rfl, ?_⟩
      rw [htr']
      unfold AdaGood at hgood
      exact not_not.mp hgood

open Classical in
/-- **The information-flow core of the ADA event**: for every fixed stream `a` of the other bits, at most a `β_B/2`
fraction of the streams of bank `lab`'s ADA sample seeds and coins makes bank `lab`'s ADA event fail. -/
theorem ada_block_count (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n) (lab : BankLabel)
    (nΛ : ℕ) (a : List Bool) :
    ∑ l ∈ lenFinset nΛ,
        (if ∃ x, (((interactT P adv P.m).retag (adaSel lab)).runS (pairStreams a l)).map Prod.fst =
              some x ∧ x ∈ adaBad P lab
          then (1 : ℝ≥0∞) else 0) ≤
      ENNReal.ofReal ((P.betaB : ℝ) / 2) * 2 ^ nΛ := by
  have hB : BirthOnce lab false (fullCode P adv P.m) :=
    birthOnce_of_birthsOK lab (fullCode P adv P.m) false _ (birthsOK_fullCode_once P adv lab P.m)
  have hcount := handle_count P hP (runX P lab false (fullCode P adv P.m) initO Ghost.init)
    (phase1_runX P lab _ _ _) (validCalls_runX P lab _ false _ _ (thetaOK_fullCode P adv P.m)) nΛ a
  refine le_trans (Finset.sum_le_sum fun l _ => ?_) hcount
  by_cases hbad : ∃ x, (((interactT P adv P.m).retag (adaSel lab)).runS (pairStreams a l)).map Prod.fst =
      some x ∧ x ∈ adaBad P lab
  · rw [if_pos hbad, if_pos (handle_bad_of_real P adv lab hB a l hbad)]
  · rw [if_neg hbad]
    simp

/-- **The ADA event of one bank fails on at most a `β_B/2` fraction of the tapes** (Theorem 3.6 for the bank;
partIII.tex L1277, budget of eq. `R:eq:global-failure-budget`). -/
theorem card_not_adaGood_le (P : StreamParams) (hP : ParamsOK P) (adv : StreamAdversary P.n)
    (lab : BankLabel) :
    (({tapes | ∃ c, theAlgL.run P adv tapes P.m = some c ∧ ¬ AdaGood P lab c.1.2} :
        Set (Fin (P.m + 1) → Fin (tapeBits P) → Bool)).ncard : ℝ) ≤
      (P.betaB : ℝ) / 2 * 2 ^ ((P.m + 1) * tapeBits P) := by
  have hβ : (0 : ℝ) ≤ (P.betaB : ℝ) / 2 := by
    have : (0 : ℝ) < (P.betaB : ℝ) := by exact_mod_cast StreamParams.betaB_pos hP.one_le_m
    positivity
  exact card_le_of_blocks P adv (adaSel lab) (fun c => ¬ AdaGood P lab c.1.2) (adaBad P lab) rfl _ hβ
    (fun nΛ _ _ a _ => ada_block_count P hP adv lab nΛ a)

end F2e2e.C.Closure
