import F2e2e.C.ClosureProbSimAux

/-!
# Theorem 6.4, probability layer (C-PROB): the simulation of the selected bank by its oracle

Paper: `parts/partIII.tex` L1271–1277. For a selected label `lab`, the instrumented run of any controller program,
with the bits of bank `lab`'s ADA sample and ADA coins retagged `true` and all other bits `false`, is the run of the
oracle-split program `runX` with bank `lab`'s ADA module implemented by B's online core (`handle`), up to the erasure
of bank `lab`'s ADA rows and state; bank `lab`'s ADA transcript is the oracle's transcript (`sim`).

The proof is one induction over the controller program (`SimClaim`), under the hypotheses that bank `lab` is born
at most once (`BirthOnce`) and the simulation relation `SimRel` (C-CLOSE's row invariant `RowsOK`, the oracle state
mirrors bank `lab`'s ADA state, its seeds and its transcript). The query values of every call of bank `lab` are B's
core values of the request `callReq` on the sample seeds (`adaVals_eq_coreVals`).
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg

/-! ## Fresh rows -/

theorem bitAlways_sampleBlocks_shape (P : StreamParams) :
    ∀ l : List ℕ, BitAlways (fun blks : List (List Row) => (∀ blk ∈ blks, ∀ r ∈ blk, FreshRow P r) ∧
      blks.map List.length = l) (sampleBlocks P l)
  | [] => BitAlways.pure [] ⟨fun blk hblk => absurd hblk List.not_mem_nil, rfl⟩
  | nj :: rest => by
    rw [sampleBlocks_cons]
    have hb := bitAlways_sampleList (newRow P) (bitAlways_newRow P) nj
    have hr := bitAlways_sampleBlocks_shape P rest
    refine BitAlways.bind' (fun blk hblk => BitAlways.bind' (fun l hl => BitAlways.pure _ ?_) hr) hb
    refine ⟨fun b hb r hr => ?_, ?_⟩
    · rcases List.mem_cons.mp hb with rfl | hb
      · exact hblk.2 r hr
      · exact hl.1 b hb r hr
    · simp [hblk.1, hl.2]

theorem bitAlways_coarseProg (P : StreamParams) :
    BitAlways (fun coarse : List (List (List Row)) => ∀ grp ∈ coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)
      (coarseProg P) :=
  BitAlways.mono' (fun _ hco grp hgrp sub hsub r hr => ((hco.2 grp hgrp).2 sub hsub).2 r hr)
    (bitAlways_sampleList _ (bitAlways_sampleList _ (bitAlways_sampleList _
      (bitAlways_newRow P) 32) P.gCoarse) P.Rmax)

/-! ## Seeds -/

theorem seedOfRow_congr (P : StreamParams) {r r' : Row} (h : r.seed = r'.seed) :
    seedOfRow P r = seedOfRow P r' := by
  obtain ⟨s, x, y⟩ := r
  obtain ⟨s', x', y'⟩ := r'
  simp only at h
  subst h
  rfl

theorem sOf_mapRows (P : StreamParams) (op : RowOp) (ada : List (List Row)) :
    sOf P (ada.map fun blk => blk.map (op.apply P)) = sOf P ada := by
  funext ℓ
  unfold sOf
  apply seedOfRow_congr
  rw [← List.map_flatten, List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_map]
  cases ada.flatten[(ℓ : ℕ)]? with
  | none => rfl
  | some r => exact rowOp_apply_seed P op r

/-! ## The simulation relation -/

theorem adaTranscript_of_calls {P : StreamParams} {lab : BankLabel} {g g' : Ghost} (h : g'.calls = g.calls) :
    adaTranscript P lab g' = adaTranscript P lab g := by
  unfold adaTranscript; rw [h]

theorem SimRel.of_eq {P : StreamParams} {lab : BankLabel} {o o' : OState} {g g' : Ghost}
    {ost : Option (OrSt P)} {f : Bool} (h : SimRel P lab o g ost f)
    (hb : o'.banks = o.banks) (hl : g'.labels = g.labels) (hh : g'.hists = g.hists)
    (hc : g'.calls = g.calls) : SimRel P lab o' g' ost f where
  rows := rowsOK_of_eq h.rows hb hh hl
  flag := h.flag
  uniq := by rw [hl]; exact h.uniq
  none_lab := fun hn => by rw [hl, adaTranscript_of_calls hc]; exact h.none_lab hn
  some_trv := fun os hos => by rw [adaTranscript_of_calls hc]; exact h.some_trv os hos
  some_bank := fun os hos idx B hB hlab => by
    rw [hb] at hB; rw [hl] at hlab; exact h.some_bank os hos idx B hB hlab

theorem getElem?_labels {g : Ghost} {o : OState} (hlen : g.labels.length = o.banks.length) {idx : ℕ}
    {B : Bank} (hB : o.banks[idx]? = some B) : g.labels[idx]? = some (g.labelAt idx) := by
  have hi : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hB).1
  have hi' : idx < g.labels.length := by rw [hlen]; exact hi
  rw [List.getElem?_eq_getElem hi']
  unfold Ghost.labelAt
  rw [List.getD_eq_getElem _ _ hi']

/-- The labels of `labels ++ [l]` equal to `lab ∉ labels`: only the last one. -/
theorem idx_eq_of_append {labels : List BankLabel} {lab : BankLabel} (hnotin : lab ∉ labels) {l : BankLabel}
    {i : ℕ} (hi : (labels ++ [l])[i]? = some lab) : i = labels.length ∧ l = lab := by
  rcases Nat.lt_or_ge i labels.length with h | h
  · rw [List.getElem?_append_left h] at hi
    exact absurd (List.mem_of_getElem? hi) hnotin
  · rw [List.getElem?_append_right h] at hi
    have h0 : i - labels.length = 0 := by
      by_contra hne
      rw [List.getElem?_eq_none (by simp; omega)] at hi
      exact absurd hi (by simp)
    rw [h0] at hi
    simp only [List.getElem?_cons_zero, Option.some.injEq] at hi
    exact ⟨by omega, hi⟩

theorem simRel_birth {P : StreamParams} {lab : BankLabel} {o : OState} {g : Ghost}
    (hR : SimRel P lab o g none false) (ada : List (List Row)) (coarse : List (List (List Row)))
    (st : AdaState)
    (hada : (∀ blk ∈ ada, ∀ r ∈ blk, FreshRow P r) ∧ ada.map List.length = (bankAda P).blockSizes)
    (hco : ∀ grp ∈ coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r) :
    SimRel P lab { o with banks := o.banks ++ [⟨ada, coarse, st⟩] }
      { g with labels := g.labels ++ [lab], hists := g.hists ++ [[]] } (some ⟨ada, st, []⟩) true where
  rows := rowsOK_bankNew hR.rows ⟨ada, coarse, st⟩ ⟨hada.1, hco⟩ lab
  flag := by simp
  uniq := by
    intro i j hi hj
    have hnotin := (hR.none_lab rfl).1
    rw [(idx_eq_of_append hnotin hi).1, (idx_eq_of_append hnotin hj).1]
  none_lab := by simp
  some_trv := by
    intro os hos
    simp only [Option.some.injEq] at hos
    subst hos
    exact (hR.none_lab rfl).2
  some_bank := by
    intro os hos idx B hB hlab
    simp only [Option.some.injEq] at hos
    subst hos
    have hnotin := (hR.none_lab rfl).1
    have hidx := (idx_eq_of_append hnotin hlab).1
    have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
    rw [hidx, hlen] at hB
    simp only [List.getElem?_append_right (le_refl _), Nat.sub_self, List.getElem?_cons_zero,
      Option.some.injEq] at hB
    subst hB
    exact ⟨rfl, rfl, hada.2⟩

theorem simRel_newOther {P : StreamParams} {lab : BankLabel} {o : OState} {g : Ghost}
    {ost : Option (OrSt P)} {f : Bool} (hR : SimRel P lab o g ost f) {l : BankLabel} (hl : l ≠ lab)
    (B : Bank)
    (hB : (∀ blk ∈ B.ada, ∀ r ∈ blk, FreshRow P r) ∧ (∀ grp ∈ B.coarse, ∀ sub ∈ grp, ∀ r ∈ sub, FreshRow P r)) :
    SimRel P lab { o with banks := o.banks ++ [B] }
      { g with labels := g.labels ++ [l], hists := g.hists ++ [[]] } ost f where
  rows := rowsOK_bankNew hR.rows B hB l
  flag := hR.flag
  uniq := by
    intro i j hi hj
    have key : ∀ i : ℕ, (g.labels ++ [l])[i]? = some lab → g.labels[i]? = some lab := by
      intro i hi
      rcases Nat.lt_or_ge i g.labels.length with h | h
      · rwa [List.getElem?_append_left h] at hi
      · rw [List.getElem?_append_right h] at hi
        have h0 : i - g.labels.length = 0 := by
          by_contra hne
          rw [List.getElem?_eq_none (by simp; omega)] at hi
          exact absurd hi (by simp)
        rw [h0] at hi
        simp only [List.getElem?_cons_zero, Option.some.injEq] at hi
        exact absurd hi hl
    exact hR.uniq i j (key i hi) (key j hj)
  none_lab := by
    intro hn
    obtain ⟨h1, h2⟩ := hR.none_lab hn
    refine ⟨?_, h2⟩
    simp only [List.mem_append, List.mem_singleton, not_or]
    exact ⟨h1, fun h => hl h.symm⟩
  some_trv := hR.some_trv
  some_bank := by
    intro os hos idx B' hB' hlab
    have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
    rcases Nat.lt_or_ge idx g.labels.length with h | h
    · rw [List.getElem?_append_left h] at hlab
      rw [List.getElem?_append_left (by rw [← hlen]; exact h)] at hB'
      exact hR.some_bank os hos idx B' hB' hlab
    · rw [List.getElem?_append_right h] at hlab
      have h0 : idx - g.labels.length = 0 := by
        by_contra hne
        rw [List.getElem?_eq_none (by simp; omega)] at hlab
        exact absurd hlab (by simp)
      rw [h0] at hlab
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hlab
      exact absurd hlab hl

theorem SimRel.of_eq' {P : StreamParams} {lab : BankLabel} {o o' : OState} {g g' : Ghost}
    {ost : Option (OrSt P)} {f : Bool} (h : SimRel P lab o g ost f)
    (hb : o'.banks = o.banks) (hl : g'.labels = g.labels) (hh : g'.hists = g.hists)
    (ht : adaTranscript P lab g' = adaTranscript P lab g) : SimRel P lab o' g' ost f where
  rows := rowsOK_of_eq h.rows hb hh hl
  flag := h.flag
  uniq := by rw [hl]; exact h.uniq
  none_lab := fun hn => by rw [hl, ht]; exact h.none_lab hn
  some_trv := fun os hos => by rw [ht]; exact h.some_trv os hos
  some_bank := fun os hos idx B hB hlab => by
    rw [hb] at hB; rw [hl] at hlab; exact h.some_bank os hos idx B hB hlab

/-- A bank of another label is replaced (after one of its calls), with no new entry in bank `lab`'s transcript. -/
theorem SimRel.setAt_other {P : StreamParams} {lab : BankLabel} {o : OState} {g g' : Ghost}
    {ost : Option (OrSt P)} {f : Bool} (h : SimRel P lab o g ost f) (idx : ℕ) {B B' : Bank}
    (hB : o.banks[idx]? = some B) (hl : g.labels[idx]? ≠ some lab) (hada : B'.ada = B.ada)
    (hco : ∀ grp ∈ B'.coarse, grp ∈ B.coarse) (hlab : g'.labels = g.labels) (hh : g'.hists = g.hists)
    (ht : adaTranscript P lab g' = adaTranscript P lab g) :
    SimRel P lab { o with banks := setAt B' idx o.banks } g' ost f where
  rows := rowsOK_setAt h.rows idx hB hada hco hh hlab
  flag := h.flag
  uniq := by rw [hlab]; exact h.uniq
  none_lab := fun hn => by rw [hlab, ht]; exact h.none_lab hn
  some_trv := fun os hos => by rw [ht]; exact h.some_trv os hos
  some_bank := fun os hos j B2 hB2 hlab2 => by
    rw [hlab] at hlab2
    have hj : j ≠ idx := by
      rintro rfl
      exact hl hlab2
    simp only [getElem?_setAt] at hB2
    rw [if_neg (fun hc => hj hc.1)] at hB2
    exact h.some_bank os hos j B2 hB2 hlab2

/-! ## The simulation claim -/

/-- The simulation claim for one controller program. -/
def SimClaim (P : StreamParams) (lab : BankLabel) {α : Type} (p : AlgM α) : Prop :=
  ∀ (o : OState) (g : Ghost) (ost : Option (OrSt P)) (f : Bool),
    BirthOnce lab f p → SimRel P lab o g ost f →
    ((runL P p o g).retag (adaSel lab)).map (simOut P lab) =
      (handle P (runX P lab f p (eraseO lab g.labels o) (eraseG g)) ost).map fun r => (r.1, trvOf r.2)

theorem simClaim_pure (P : StreamParams) (lab : BankLabel) {α : Type} (a : α) :
    SimClaim P lab (AlgM.pure a) := by
  intro o g ost f _ hR
  have htr : adaTranscript P lab g = trvOf ost := by
    cases ost with
    | none => exact (hR.none_lab rfl).2
    | some os => exact hR.some_trv os rfl
  show TBitProg.pure (simOut P lab (a, o, g)) =
    TBitProg.pure ((a, eraseO lab g.labels o, eraseG g), trvOf ost)
  rw [← htr]
  rfl

theorem simClaim_fpInit (P : StreamParams) (lab : BankLabel) {α : Type} (k : AlgM α)
    (ih : SimClaim P lab k) : SimClaim P lab (AlgM.fpInit k) := by
  intro o g ost f hB hR
  have hBk : BirthOnce lab f k := hB
  show (((tag Tag.fp (fpSeedProg P)).bind fun r => runL P k { o with fpSeed := r, fpVal := 0 } g).retag
      (adaSel lab)).map (simOut P lab) =
    (handle P (OProg.lift (fpSeedProg P) fun r =>
      runX P lab f k { eraseO lab g.labels o with fpSeed := r, fpVal := 0 } (eraseG g)) ost).map
        fun r => (r.1, trvOf r.2)
  rw [retag_bind, retag_tag, adaSel_fp, map_bind', handle_lift, map_bind']
  congr 1
  funext r
  exact ih _ g ost f hBk (hR.of_eq rfl rfl rfl rfl)

theorem simClaim_fpStep (P : StreamParams) (lab : BankLabel) {α : Type} (i : ℕ) (Δ : ℤ)
    (k : Bool → AlgM α) (ih : ∀ z, SimClaim P lab (k z)) : SimClaim P lab (AlgM.fpStep i Δ k) := by
  intro o g ost f hB hR
  exact ih _ { o with fpVal := fpUpdate P o.fpSeed o.fpVal i Δ }
    { g with fps := g.fps ++ [(i, Δ, fpUpdate P o.fpSeed o.fpVal i Δ == 0)] } ost f (hB _)
    (hR.of_eq rfl rfl rfl rfl)

theorem simClaim_note (P : StreamParams) (lab : BankLabel) {α : Type} (ev : TreeEvent) (k : AlgM α)
    (ih : SimClaim P lab k) : SimClaim P lab (AlgM.note ev k) := by
  intro o g ost f hB hR
  exact ih o { g with events := g.events ++ [ev] } ost f hB (hR.of_eq rfl rfl rfl rfl)

theorem simClaim_bankRetain (P : StreamParams) (lab : BankLabel) {α : Type} (n : ℕ) (k : AlgM α)
    (ih : SimClaim P lab k) : SimClaim P lab (AlgM.bankRetain n k) := by
  intro o g ost f hB hR
  have hR' : SimRel P lab { o with banks := o.banks.take n }
      { g with labels := g.labels.take n, hists := g.hists.take n } ost f :=
    { rows := rowsOK_retain hR.rows n
      flag := hR.flag
      uniq := fun i j hi hj => by
        simp only [List.getElem?_take] at hi hj
        split_ifs at hi hj
        exact hR.uniq i j hi hj
      none_lab := fun hn => by
        obtain ⟨h1, h2⟩ := hR.none_lab hn
        exact ⟨fun h => h1 (List.mem_of_mem_take h), h2⟩
      some_trv := hR.some_trv
      some_bank := fun os hos idx B hB hlab => by
        simp only [List.getElem?_take] at hB hlab
        split_ifs at hB hlab
        exact hR.some_bank os hos idx B hB hlab }
  have ho : ({ eraseO lab g.labels o with banks := (eraseO lab g.labels o).banks.take n } : OState) =
      eraseO lab (g.labels.take n) { o with banks := o.banks.take n } := by
    simp only [eraseO, eraseBanks_take]
  show _ = (handle P (runX P lab f k { eraseO lab g.labels o with banks := (eraseO lab g.labels o).banks.take n }
      { eraseG g with labels := (eraseG g).labels.take n, hists := (eraseG g).hists.take n }) ost).map _
  rw [ho]
  exact ih _ _ ost f hB hR'

theorem simClaim_bankOp (P : StreamParams) (lab : BankLabel) {α : Type} (idx : ℕ) (op : RowOp)
    (k : AlgM α) (ih : SimClaim P lab k) : SimClaim P lab (AlgM.bankOp idx op k) := by
  intro o g ost f hB hR
  have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
  have hR' : SimRel P lab { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := modifyAt (fun h => h ++ [op]) idx g.hists } ost f :=
    { rows := rowsOK_bankOp hR.rows idx op
      flag := hR.flag
      uniq := hR.uniq
      none_lab := hR.none_lab
      some_trv := hR.some_trv
      some_bank := fun os hos j B hB hlab => by
        simp only [getElem?_modifyAt] at hB
        split_ifs at hB with hj
        · obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp hB
          obtain ⟨h1, h2, h3⟩ := hR.some_bank os hos j B0 hB0 hlab
          refine ⟨h1, ?_, ?_⟩
          · rw [← h2]; exact sOf_mapRows P op B0.ada
          · simp only [Bank.mapRows, List.map_map]
            rw [← h3]
            congr 1
            funext blk
            simp
        · exact hR.some_bank os hos j B hB hlab }
  have ho : ({ eraseO lab g.labels o with
      banks := modifyAt (Bank.mapRows (op.apply P)) idx (eraseO lab g.labels o).banks } : OState) =
      eraseO lab g.labels { o with banks := modifyAt (Bank.mapRows (op.apply P)) idx o.banks } := by
    simp only [eraseO, eraseBanks_modifyAt lab hlen _ (eraseBank_mapRows (op.apply P)) idx]
  show _ = (handle P (runX P lab f k { eraseO lab g.labels o with
      banks := modifyAt (Bank.mapRows (op.apply P)) idx (eraseO lab g.labels o).banks }
      { eraseG g with hists := modifyAt (fun h => h ++ [op]) idx (eraseG g).hists }) ost).map _
  rw [ho]
  exact ih _ _ ost f hB hR'

theorem simClaim_bankOpFrom (P : StreamParams) (lab : BankLabel) {α : Type} (idx : ℕ) (op : RowOp)
    (k : AlgM α) (ih : SimClaim P lab k) : SimClaim P lab (AlgM.bankOpFrom idx op k) := by
  intro o g ost f hB hR
  have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
  have hR' : SimRel P lab { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks }
      { g with hists := mapFrom (fun h => h ++ [op]) idx g.hists } ost f :=
    { rows := rowsOK_bankOpFrom hR.rows idx op
      flag := hR.flag
      uniq := hR.uniq
      none_lab := hR.none_lab
      some_trv := hR.some_trv
      some_bank := fun os hos j B hB hlab => by
        simp only [getElem?_mapFrom] at hB
        split_ifs at hB with hj
        · obtain ⟨B0, hB0, rfl⟩ := Option.map_eq_some_iff.mp hB
          obtain ⟨h1, h2, h3⟩ := hR.some_bank os hos j B0 hB0 hlab
          refine ⟨h1, ?_, ?_⟩
          · rw [← h2]; exact sOf_mapRows P op B0.ada
          · simp only [Bank.mapRows, List.map_map]
            rw [← h3]
            congr 1
            funext blk
            simp
        · exact hR.some_bank os hos j B hB hlab }
  have ho : ({ eraseO lab g.labels o with
      banks := mapFrom (Bank.mapRows (op.apply P)) idx (eraseO lab g.labels o).banks } : OState) =
      eraseO lab g.labels { o with banks := mapFrom (Bank.mapRows (op.apply P)) idx o.banks } := by
    simp only [eraseO, eraseBanks_mapFrom lab hlen _ (eraseBank_mapRows (op.apply P)) idx]
  show _ = (handle P (runX P lab f k { eraseO lab g.labels o with
      banks := mapFrom (Bank.mapRows (op.apply P)) idx (eraseO lab g.labels o).banks }
      { eraseG g with hists := mapFrom (fun h => h ++ [op]) idx (eraseG g).hists }) ost).map _
  rw [ho]
  exact ih _ _ ost f hB hR'

theorem simClaim_bankNew (P : StreamParams) (lab : BankLabel) {α : Type} (tr d : ℕ) (k : AlgM α)
    (ih : SimClaim P lab k) : SimClaim P lab (AlgM.bankNew tr d k) := by
  intro o g ost f hB hR
  have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
  by_cases hl : (tr, d) = lab
  · -- the selected bank is born
    have hB' : f = false ∧ BirthOnce lab true k := by
      have h := hB
      simp only [BirthOnce, if_pos hl] at h
      exact h
    obtain ⟨hf, hBk⟩ := hB'
    subst hf
    have hnone : ost = none := hR.flag.2 rfl
    subst hnone
    subst hl
    have hrunX : runX P (tr, d) false (AlgM.bankNew tr d k) (eraseO (tr, d) g.labels o) (eraseG g) =
        OProg.sample (OProg.lift (coarseProg P) fun coarse =>
          OProg.init (runX P (tr, d) true k { eraseO (tr, d) g.labels o with
              banks := (eraseO (tr, d) g.labels o).banks ++ [⟨[], coarse, dfltSt⟩] }
            { eraseG g with labels := (eraseG g).labels ++ [(tr, d)], hists := (eraseG g).hists ++ [[]] })) := by
      rw [runX, if_pos ⟨rfl, rfl⟩]
    have hrunL : runL P (AlgM.bankNew tr d k) o g = (newBankT P (tr, d)).bind fun B =>
        runL P k { o with banks := o.banks ++ [B] }
          { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } := rfl
    rw [hrunL, retag_newBankT_self, hrunX]
    simp only [handle, handle_lift, Option.map_some, map_bind']
    refine bind_congr_always true (bitAlways_sampleBlocks_shape P _) fun ada hada => ?_
    refine bind_congr_always false (bitAlways_coarseProg P) fun coarse hco => ?_
    congr 1
    funext st
    have ho : ({ eraseO (tr, d) g.labels o with
        banks := (eraseO (tr, d) g.labels o).banks ++ [⟨[], coarse, dfltSt⟩] } : OState) =
        eraseO (tr, d) (g.labels ++ [(tr, d)]) { o with banks := o.banks ++ [⟨ada, coarse, st⟩] } := by
      simp only [eraseO, eraseBanks_append (tr, d) hlen]
      rfl
    rw [ho]
    exact ih _ _ _ true hBk (simRel_birth hR ada coarse st hada hco)
  · -- another bank is born
    have hBk : BirthOnce lab f k := by
      have h := hB
      simp only [BirthOnce, if_neg hl] at h
      exact h
    have hrunX : runX P lab f (AlgM.bankNew tr d k) (eraseO lab g.labels o) (eraseG g) =
        OProg.lift (newBank P) fun B => runX P lab f k
          { eraseO lab g.labels o with banks := (eraseO lab g.labels o).banks ++ [B] }
          { eraseG g with labels := (eraseG g).labels ++ [(tr, d)], hists := (eraseG g).hists ++ [[]] } := by
      rw [runX, if_neg (fun h => hl h.1)]
    have hrunL : runL P (AlgM.bankNew tr d k) o g = (newBankT P (tr, d)).bind fun B =>
        runL P k { o with banks := o.banks ++ [B] }
          { g with labels := g.labels ++ [(tr, d)], hists := g.hists ++ [[]] } := rfl
    rw [hrunL, retag_bind, sim_retag_newBankT_ne P hl, hrunX, handle_lift, map_bind', map_bind']
    refine bind_congr_always false (bitAlways_newBank P) fun B hBf => ?_
    have ho : ({ eraseO lab g.labels o with banks := (eraseO lab g.labels o).banks ++ [B] } : OState) =
        eraseO lab (g.labels ++ [(tr, d)]) { o with banks := o.banks ++ [B] } := by
      simp only [eraseO, eraseBanks_append lab hlen, if_neg hl]
    rw [ho]
    exact ih _ _ ost f hBk (simRel_newOther hR hl B hBf)

/-! ## Calls -/

theorem validate_eq (P : StreamParams) (B : Bank) (S θ : ℚ) :
    B.validate P S θ = (adaInterval (bankAda P) B.adaSt (adaVals P Mode.primary (S + P.omega) B)
      ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ))).bind fun res =>
        BitProg.pure (res.1, { B with adaSt := res.2 }) := rfl

theorem coreStep_interval (P : StreamParams) (s : Fin (bankAda P).N → Seed P) (req : CoreReq (Seed P))
    (st : AdaState) (h : req.isInterval = true) :
    coreStep (bankAda P) s req st =
      (adaInterval (bankAda P) st (coreVals (bankAda P) s req) req.l req.u).bind fun r =>
        BitProg.pure (Sum.inl r.1, r.2) := by
  unfold coreStep
  rw [if_pos h]
  rfl

theorem coreStep_numerical (P : StreamParams) (s : Fin (bankAda P).N → Seed P) (req : CoreReq (Seed P))
    (st : AdaState) (h : req.isInterval = false) :
    coreStep (bankAda P) s req st =
      (adaNumerical (bankAda P) st (coreVals (bankAda P) s req)).bind fun r =>
        BitProg.pure (Sum.inr r.1, r.2) := by
  unfold coreStep
  rw [if_neg (by rw [h]; exact Bool.false_ne_true)]
  rfl

theorem tag_bind_pure {ι α β : Type} (i : ι) (q : BitProg α) (h : α → β) :
    tag i (q.bind fun a => BitProg.pure (h a)) = (tag i q).bind fun a => TBitProg.pure (h a) := by
  rw [tag_bind]
  rfl

theorem simClaim_bankValidate (P : StreamParams) (lab : BankLabel) {α : Type} (idx : ℕ) (S θ : ℚ)
    (k : AdaCert → AlgM α) (ih : ∀ c, SimClaim P lab (k c)) :
    SimClaim P lab (AlgM.bankValidate idx S θ k) := by
  intro o g ost f hB hR
  have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
  have hBk : ∀ c, BirthOnce lab f (k c) := hB
  cases hBo : o.banks[idx]? with
  | none =>
    have hBo' : (eraseO lab g.labels o).banks[idx]? = none := by
      show (eraseBanks lab g.labels o.banks)[idx]? = none
      rw [getElem?_eraseBanks lab hlen, hBo]
      rfl
    have hrunL : runL P (AlgM.bankValidate idx S θ k) o g = runL P (k AdaCert.abort) o g := by
      simp only [runL, hBo]
    have hrunX : runX P lab f (AlgM.bankValidate idx S θ k) (eraseO lab g.labels o) (eraseG g) =
        runX P lab f (k AdaCert.abort) (eraseO lab g.labels o) (eraseG g) := by
      simp only [runX, hBo']
    rw [hrunL, hrunX]
    exact ih _ o g ost f (hBk _) hR
  | some B =>
    have hlabs : g.labels[idx]? = some (g.labelAt idx) := getElem?_labels hlen hBo
    have hidx : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hBo).1
    have hrunL : runL P (AlgM.bankValidate idx S θ k) o g =
        (tag (Tag.coins (g.labelAt idx)) (B.validate P S θ)).bind fun r =>
          runL P (k r.1) { o with banks := setAt r.2 idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
              S + P.omega, some (Sum.inl r.1)⟩] } := by
      simp only [runL, hBo]
    by_cases hl : g.labelAt idx = lab
    · -- a call of the selected bank's ADA module
      have hlab : g.labels[idx]? = some lab := by rw [hlabs, hl]
      have hin : lab ∈ g.labels := List.mem_of_getElem? hlab
      cases ost with
      | none => exact absurd hin (hR.none_lab rfl).1
      | some os =>
      have hf : f = true := by
        cases f with
        | true => rfl
        | false => exact absurd (hR.flag.2 rfl) (by simp)
      subst hf
      obtain ⟨hst, hs, hshape⟩ := hR.some_bank os rfl idx B hBo hlab
      have hrows := (hR.rows.rows idx B hBo).1
      have hBo' : (eraseO lab g.labels o).banks[idx]? = some (eraseBank B) := by
        show (eraseBanks lab g.labels o.banks)[idx]? = some (eraseBank B)
        rw [getElem?_eraseBanks lab hlen, hBo]
        simp [hlab]
      have hl' : (eraseG g).labelAt idx = lab := hl
      have hrunX : runX P lab true (AlgM.bankValidate idx S θ k) (eraseO lab g.labels o) (eraseG g) =
          OProg.call (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.validate S θ,
              S + P.omega, none⟩) fun out =>
            runX P lab true (k (certOf out)) (eraseO lab g.labels o)
              { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, g.histAt idx, eraseBank (eraseBank B),
                CallKind.validate S θ, S + P.omega, some out⟩] } := by
        simp only [runX, hBo', hl', and_self, if_true]
        rfl
      rw [hrunL, hrunX, retag_bind, retag_tag, hl, adaSel_coins_self, validate_eq, tag_bind_pure,
        TBitProg.bind_assoc]
      simp only [handle]
      rw [coreStep_interval P _ _ _ rfl, tag_bind_pure, TBitProg.bind_assoc, map_bind', map_bind']
      have hq : adaInterval (bankAda P) os.st (coreVals (bankAda P) (sOf P os.rows)
          (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.validate S θ, S + P.omega,
            none⟩)) ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ)) =
          adaInterval (bankAda P) B.adaSt (adaVals P Mode.primary (S + P.omega) B)
            ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ)) := by
        rw [← hst, ← hs, adaVals_eq_coreVals P Mode.primary (S + P.omega) B (g.histAt idx) hrows hshape true
          ((1 - θ) / (P.L : ℚ)) ((1 + θ) / (P.L : ℚ))]
        rfl
      erw [hq]
      congr 1
      funext res
      have hR1 : SimRel P lab { o with banks := setAt { B with adaSt := res.2 } idx o.banks }
          { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.validate S θ, S + P.omega,
            some (Sum.inl res.1)⟩] }
          (some { os with st := res.2, trv := os.trv ++ [(callReq P ⟨lab, idx, g.histAt idx,
            eraseBank (eraseBank B), CallKind.validate S θ, S + P.omega, none⟩, Sum.inl res.1)] }) true :=
        { rows := rowsOK_setAt hR.rows idx hBo rfl (fun grp hg => hg) rfl rfl
          flag := by simp
          uniq := hR.uniq
          none_lab := by simp
          some_trv := by
            intro os' hos'
            simp only [Option.some.injEq] at hos'
            subst hos'
            rw [adaTranscript_append, hR.some_trv os rfl, if_pos rfl]
            rfl
          some_bank := by
            intro os' hos' j B' hB' hlab'
            simp only [Option.some.injEq] at hos'
            subst hos'
            have hj : j = idx := hR.uniq j idx hlab' hlab
            subst hj
            rw [getElem?_setAt, if_pos ⟨rfl, hidx⟩] at hB'
            simp only [Option.some.injEq] at hB'
            subst hB'
            exact ⟨rfl, hs, hshape⟩ }
      have key := ih res.1 _ _ _ true (hBk _) hR1
      have e1 : eraseO lab g.labels { o with banks := setAt { B with adaSt := res.2 } idx o.banks } =
          eraseO lab g.labels o := by
        show ({ o with banks := eraseBanks lab g.labels (setAt { B with adaSt := res.2 } idx o.banks) } : OState) =
          { o with banks := eraseBanks lab g.labels o.banks }
        rw [eraseBanks_setAt_eq lab hlen idx hlab]
        have : (eraseBanks lab g.labels o.banks)[idx]? = some (eraseBank { B with adaSt := res.2 }) := by
          rw [getElem?_eraseBanks lab hlen, hBo]
          simp [hlab]
          rfl
        rw [setAt_self idx _ _ this]
      have e2 : eraseG { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl res.1)⟩] } =
          { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, g.histAt idx, eraseBank (eraseBank B),
            CallKind.validate S θ, S + P.omega, some (Sum.inl res.1)⟩] } := by
        simp only [eraseG, List.map_append, List.map_cons, List.map_nil]
        rfl
      refine Eq.trans ?_ (key.trans ?_)
      · rfl
      · rw [show eraseO lab ({ g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl res.1)⟩] } : Ghost).labels
            { o with banks := setAt { B with adaSt := res.2 } idx o.banks } = eraseO lab g.labels o from e1, e2]
        rfl
    · -- a call of another bank
      have hlab : g.labels[idx]? ≠ some lab := by
        rw [hlabs]
        exact fun h => hl (Option.some.inj h)
      have hBo' : (eraseO lab g.labels o).banks[idx]? = some B := by
        show (eraseBanks lab g.labels o.banks)[idx]? = some B
        rw [getElem?_eraseBanks lab hlen, hBo]
        simp [hlab]
      have hl' : ¬ ((eraseG g).labelAt idx = lab ∧ f = true) := fun h => hl h.1
      have hrunX : runX P lab f (AlgM.bankValidate idx S θ k) (eraseO lab g.labels o) (eraseG g) =
          OProg.lift (B.validate P S θ) fun r =>
            runX P lab f (k r.1) { eraseO lab g.labels o with banks := setAt r.2 idx (eraseO lab g.labels o).banks }
              { eraseG g with calls := (eraseG g).calls ++ [⟨(eraseG g).labelAt idx, idx, (eraseG g).histAt idx,
                eraseBank B, CallKind.validate S θ, S + P.omega, some (Sum.inl r.1)⟩] } := by
        simp only [runX, hBo', if_neg hl']
      rw [hrunL, hrunX, retag_bind, retag_tag, adaSel_coins_ne hl, handle_lift, map_bind', map_bind']
      refine bind_congr_always false (bitAlways_validate P B S θ) fun r hr => ?_
      have hR1 : SimRel P lab { o with banks := setAt r.2 idx o.banks }
          { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl r.1)⟩] } ost f :=
        hR.setAt_other idx hBo hlab hr.1 (fun grp hg => hr.2 ▸ hg) rfl rfl (by
          rw [adaTranscript_append, if_neg hl, List.append_nil])
      have e1 : ({ eraseO lab g.labels o with banks := setAt r.2 idx (eraseO lab g.labels o).banks } : OState) =
          eraseO lab g.labels { o with banks := setAt r.2 idx o.banks } := by
        show ({ o with banks := setAt r.2 idx (eraseBanks lab g.labels o.banks) } : OState) =
          { o with banks := eraseBanks lab g.labels (setAt r.2 idx o.banks) }
        rw [eraseBanks_setAt_ne lab hlen idx hlab]
      have e2 : eraseG { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.validate S θ,
            S + P.omega, some (Sum.inl r.1)⟩] } =
          { eraseG g with calls := (eraseG g).calls ++ [⟨(eraseG g).labelAt idx, idx, (eraseG g).histAt idx,
            eraseBank B, CallKind.validate S θ, S + P.omega, some (Sum.inl r.1)⟩] } := by
        simp only [eraseG, List.map_append, List.map_cons, List.map_nil]
        rfl
      rw [e1]
      refine (ih r.1 _ _ ost f (hBk _) hR1).trans ?_
      rw [e2]

/-- The selected bank's release with a coarse group left, for an abstract scale `c` (so that the kernel never
unfolds the scale's definition while checking the continuation step). -/
theorem simRelease_lab_cons (P : StreamParams) (lab : BankLabel) {α : Type} (idx : ℕ) (mode : Mode)
    (k : Option ℚ → AlgM α) (ih : ∀ r, SimClaim P lab (k r)) (o : OState) (g : Ghost) (os : OrSt P)
    (B : Bank) (rest : List (List (List Row))) (c : ℚ)
    (hBk : ∀ r, BirthOnce lab true (k r)) (hR : SimRel P lab o g (some os) true)
    (hlen : g.labels.length = o.banks.length) (hBo : o.banks[idx]? = some B)
    (hlab : g.labels[idx]? = some lab) (hidx : idx < o.banks.length)
    (hs : sOf P B.ada = sOf P os.rows)
    (hshape : B.ada.map List.length = (bankAda P).blockSizes)
    (hcorest : ∀ grp' ∈ rest, grp' ∈ B.coarse)
    (hrunL : runL P (AlgM.bankRelease idx mode k) o g =
        (tag (Tag.coins lab) (releaseLog P B mode)).bind fun r =>
          runL P (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
            { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.release mode,
              (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] })
    (hrunX : runX P lab true (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g) =
        OProg.call (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.release mode,
            c, none⟩) fun out =>
          runX P lab true (k (relOut P c (numOf out)))
            { eraseO lab g.labels o with
              banks := setAt { eraseBank B with coarse := rest } idx (eraseO lab g.labels o).banks }
            { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, g.histAt idx, eraseBank (eraseBank B),
              CallKind.release mode, c, some out⟩] })
    (hrel : releaseLog P B mode =
        (adaNumerical (bankAda P) B.adaSt (adaVals P mode c B)).bind fun res =>
          BitProg.pure ((relOut P c (numOf (Sum.inr res.1)),
            { B with coarse := rest, adaSt := res.2 }), some (c, res.1)))
    (hq : adaNumerical (bankAda P) os.st (coreVals (bankAda P) (sOf P os.rows)
        (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.release mode, c, none⟩)) =
        adaNumerical (bankAda P) B.adaSt (adaVals P mode c B)) :
    ((runL P (AlgM.bankRelease idx mode k) o g).retag (adaSel lab)).map (simOut P lab) =
      (handle P (runX P lab true (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g))
        (some os)).map fun r => (r.1, trvOf r.2) := by
  rw [hrunL, hrunX, retag_bind, retag_tag, adaSel_coins_self, hrel, tag_bind_pure, TBitProg.bind_assoc]
  simp only [handle]
  rw [coreStep_numerical P _ _ _ rfl, tag_bind_pure, TBitProg.bind_assoc, map_bind', map_bind', hq]
  congr 1
  funext res
  have hR1 : SimRel P lab { o with banks := setAt { B with coarse := rest, adaSt := res.2 } idx o.banks }
      { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.release mode,
        (Option.map Prod.fst (some (c, res.1))).getD 0,
        Option.map (fun x => Sum.inr x.2) (some (c, res.1))⟩] }
      (some { os with st := res.2, trv := os.trv ++ [(callReq P ⟨lab, idx, g.histAt idx,
        eraseBank (eraseBank B), CallKind.release mode, c, none⟩, Sum.inr res.1)] }) true :=
    { rows := rowsOK_setAt hR.rows idx hBo rfl hcorest rfl rfl
      flag := by simp
      uniq := hR.uniq
      none_lab := by simp
      some_trv := by
        intro os' hos'
        simp only [Option.some.injEq] at hos'
        subst hos'
        rw [adaTranscript_append, hR.some_trv os rfl, if_pos rfl]
        rfl
      some_bank := by
        intro os' hos' j B' hB' hlab'
        simp only [Option.some.injEq] at hos'
        subst hos'
        have hj : j = idx := hR.uniq j idx hlab' hlab
        subst hj
        rw [getElem?_setAt, if_pos ⟨rfl, hidx⟩] at hB'
        simp only [Option.some.injEq] at hB'
        subst hB'
        exact ⟨rfl, hs, hshape⟩ }
  have e1 : eraseO lab g.labels
      { o with banks := setAt { B with coarse := rest, adaSt := res.2 } idx o.banks } =
      { eraseO lab g.labels o with
        banks := setAt { eraseBank B with coarse := rest } idx (eraseO lab g.labels o).banks } := by
    show ({ o with
        banks := eraseBanks lab g.labels (setAt { B with coarse := rest, adaSt := res.2 } idx o.banks) } :
        OState) =
      { o with banks := setAt { eraseBank B with coarse := rest } idx (eraseBanks lab g.labels o.banks) }
    rw [eraseBanks_setAt_eq lab hlen idx hlab]
    rfl
  have e2 : eraseG { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.release mode,
        (Option.map Prod.fst (some (c, res.1))).getD 0,
        Option.map (fun x => Sum.inr x.2) (some (c, res.1))⟩] } =
      { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, g.histAt idx, eraseBank (eraseBank B),
        CallKind.release mode, c, some (Sum.inr res.1)⟩] } := by
    simp only [eraseG, List.map_append, List.map_cons, List.map_nil]
    rfl
  have key := ih (relOut P c (numOf (Sum.inr res.1))) _ _ _ true (hBk _) hR1
  refine Eq.trans ?_ (key.trans ?_)
  · rfl
  · rw [show eraseO lab ({ g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.release mode,
        (Option.map Prod.fst (some (c, res.1))).getD 0,
        Option.map (fun x => Sum.inr x.2) (some (c, res.1))⟩] } : Ghost).labels
        { o with banks := setAt { B with coarse := rest, adaSt := res.2 } idx o.banks } =
        { eraseO lab g.labels o with
          banks := setAt { eraseBank B with coarse := rest } idx (eraseO lab g.labels o).banks } from e1, e2]
    rfl

theorem simClaim_bankRelease (P : StreamParams) (lab : BankLabel) {α : Type} (idx : ℕ) (mode : Mode)
    (k : Option ℚ → AlgM α) (ih : ∀ r, SimClaim P lab (k r)) :
    SimClaim P lab (AlgM.bankRelease idx mode k) := by
  intro o g ost f hB hR
  have hlen : g.labels.length = o.banks.length := hR.rows.len_labels
  have hBk : ∀ r, BirthOnce lab f (k r) := hB
  cases hBo : o.banks[idx]? with
  | none =>
    have hBo' : (eraseO lab g.labels o).banks[idx]? = none := by
      show (eraseBanks lab g.labels o.banks)[idx]? = none
      rw [getElem?_eraseBanks lab hlen, hBo]
      rfl
    have hrunL : runL P (AlgM.bankRelease idx mode k) o g = runL P (k none) o g := by
      simp only [runL, hBo]
    have hrunX : runX P lab f (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g) =
        runX P lab f (k none) (eraseO lab g.labels o) (eraseG g) := by
      simp only [runX, hBo']
    rw [hrunL, hrunX]
    exact ih _ o g ost f (hBk _) hR
  | some B =>
    have hlabs : g.labels[idx]? = some (g.labelAt idx) := getElem?_labels hlen hBo
    have hidx : idx < o.banks.length := (List.getElem?_eq_some_iff.mp hBo).1
    have hrunL : runL P (AlgM.bankRelease idx mode k) o g =
        (tag (Tag.coins (g.labelAt idx)) (releaseLog P B mode)).bind fun r =>
          runL P (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
              (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
      simp only [runL, hBo]
    by_cases hl : g.labelAt idx = lab
    · -- a release of the selected bank
      have hlab : g.labels[idx]? = some lab := by rw [hlabs, hl]
      have hin : lab ∈ g.labels := List.mem_of_getElem? hlab
      cases ost with
      | none => exact absurd hin (hR.none_lab rfl).1
      | some os =>
      have hf : f = true := by
        cases f with
        | true => rfl
        | false => exact absurd (hR.flag.2 rfl) (by simp)
      subst hf
      obtain ⟨hst, hs, hshape⟩ := hR.some_bank os rfl idx B hBo hlab
      have hrows := (hR.rows.rows idx B hBo).1
      have hBo' : (eraseO lab g.labels o).banks[idx]? = some (eraseBank B) := by
        show (eraseBanks lab g.labels o.banks)[idx]? = some (eraseBank B)
        rw [getElem?_eraseBanks lab hlen, hBo]
        simp [hlab]
      have hl' : (eraseG g).labelAt idx = lab := hl
      cases hco : B.coarse with
      | nil =>
        -- no coarse group left: no ADA call
        have hco' : (eraseBank B).coarse = [] := hco
        have hrunX : runX P lab true (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g) =
            runX P lab true (k none) (eraseO lab g.labels o)
              { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, (eraseG g).histAt idx,
                eraseBank (eraseBank B), CallKind.release mode, 0, none⟩] } := by
          simp only [runX, hBo', hl', and_self, if_true, hco']
        rw [hrunL, hrunX, releaseLog_nil P B mode hco]
        have hR1 : SimRel P lab { o with banks := setAt B idx o.banks }
            { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
              ((none : Option (ℚ × AdaNum)).map Prod.fst).getD 0,
              (none : Option (ℚ × AdaNum)).map (fun x => Sum.inr x.2)⟩] } (some os) true :=
          hR.of_eq' (by rw [setAt_self idx o.banks B hBo]) rfl rfl (by
            rw [adaTranscript_append, if_pos hl]
            simp)
        have key := ih none _ _ _ true (hBk _) hR1
        refine Eq.trans ?_ (key.trans ?_)
        · rfl
        · have e1 : eraseO lab g.labels { o with banks := setAt B idx o.banks } = eraseO lab g.labels o := by
            rw [setAt_self idx o.banks B hBo]
          have e2 : eraseG { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B,
                CallKind.release mode, ((none : Option (ℚ × AdaNum)).map Prod.fst).getD 0,
                (none : Option (ℚ × AdaNum)).map (fun x => Sum.inr x.2)⟩] } =
              { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, (eraseG g).histAt idx,
                eraseBank (eraseBank B), CallKind.release mode, 0, none⟩] } := by
            simp only [eraseG, List.map_append, List.map_cons, List.map_nil, hl]
            rfl
          rw [show eraseO lab ({ g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B,
                CallKind.release mode, ((none : Option (ℚ × AdaNum)).map Prod.fst).getD 0,
                (none : Option (ℚ × AdaNum)).map (fun x => Sum.inr x.2)⟩] } : Ghost).labels
                { o with banks := setAt B idx o.banks } = eraseO lab g.labels o from e1, e2]
      | cons grp rest =>
        have hco' : (eraseBank B).coarse = grp :: rest := hco
        have hrunX : runX P lab true (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g) =
            OProg.call (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.release mode,
                oRelScale P mode grp, none⟩) fun out =>
              runX P lab true (k (relOut P (oRelScale P mode grp) (numOf out)))
                { eraseO lab g.labels o with
                  banks := setAt { eraseBank B with coarse := rest } idx (eraseO lab g.labels o).banks }
                { eraseG g with calls := (eraseG g).calls ++ [⟨lab, idx, g.histAt idx, eraseBank (eraseBank B),
                  CallKind.release mode, oRelScale P mode grp, some out⟩] } := by
          simp only [runX, hBo', hl', and_self, if_true, hco']
          rfl
        have hrel : releaseLog P B mode =
            (adaNumerical (bankAda P) B.adaSt (adaVals P mode (oRelScale P mode grp) B)).bind fun res =>
              BitProg.pure ((relOut P (oRelScale P mode grp) (numOf (Sum.inr res.1)),
                { B with coarse := rest, adaSt := res.2 }), some (oRelScale P mode grp, res.1)) := by
          rw [releaseLog_cons P B mode hco]
          congr 1
          funext res
          cases res.1 <;> rfl
        have hq : adaNumerical (bankAda P) os.st (coreVals (bankAda P) (sOf P os.rows)
            (callReq P ⟨lab, idx, g.histAt idx, eraseBank (eraseBank B), CallKind.release mode,
              oRelScale P mode grp, none⟩)) =
            adaNumerical (bankAda P) B.adaSt (adaVals P mode (oRelScale P mode grp) B) := by
          rw [← hst, ← hs, adaVals_eq_coreVals P mode (oRelScale P mode grp) B (g.histAt idx) hrows hshape
            false 0 0]
          rfl
        have hrunL' : runL P (AlgM.bankRelease idx mode k) o g =
            (tag (Tag.coins lab) (releaseLog P B mode)).bind fun r =>
              runL P (k r.1.1) { o with banks := setAt r.1.2 idx o.banks }
                { g with calls := g.calls ++ [⟨lab, idx, g.histAt idx, B, CallKind.release mode,
                  (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
          rw [hrunL, hl]
        exact simRelease_lab_cons P lab idx mode k ih o g os B rest (oRelScale P mode grp) hBk hR hlen hBo hlab
          hidx hs hshape (fun grp' hg => by rw [hco]; exact List.mem_cons_of_mem _ hg) hrunL' hrunX hrel hq
    · -- a release of another bank
      have hlab : g.labels[idx]? ≠ some lab := by
        rw [hlabs]
        exact fun h => hl (Option.some.inj h)
      have hBo' : (eraseO lab g.labels o).banks[idx]? = some B := by
        show (eraseBanks lab g.labels o.banks)[idx]? = some B
        rw [getElem?_eraseBanks lab hlen, hBo]
        simp [hlab]
      have hl' : ¬ ((eraseG g).labelAt idx = lab ∧ f = true) := fun h => hl h.1
      have hrunX : runX P lab f (AlgM.bankRelease idx mode k) (eraseO lab g.labels o) (eraseG g) =
          OProg.lift (releaseLog P B mode) fun r =>
            runX P lab f (k r.1.1) { eraseO lab g.labels o with banks := setAt r.1.2 idx (eraseO lab g.labels o).banks }
              { eraseG g with calls := (eraseG g).calls ++ [⟨(eraseG g).labelAt idx, idx, (eraseG g).histAt idx,
                eraseBank B, CallKind.release mode, (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
        simp only [runX, hBo', if_neg hl']
      rw [hrunL, hrunX, retag_bind, retag_tag, adaSel_coins_ne hl, handle_lift, map_bind', map_bind']
      refine bind_congr_always false (bitAlways_releaseLog P B mode) fun r hr => ?_
      have hR1 : SimRel P lab { o with banks := setAt r.1.2 idx o.banks }
          { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
            (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } ost f :=
        hR.setAt_other idx hBo hlab hr.1 (fun grp hg => by
          rw [hr.2] at hg; exact List.mem_of_mem_tail hg) rfl rfl (by
          rw [adaTranscript_append, if_neg hl, List.append_nil])
      have e1 : ({ eraseO lab g.labels o with banks := setAt r.1.2 idx (eraseO lab g.labels o).banks } : OState) =
          eraseO lab g.labels { o with banks := setAt r.1.2 idx o.banks } := by
        show ({ o with banks := setAt r.1.2 idx (eraseBanks lab g.labels o.banks) } : OState) =
          { o with banks := eraseBanks lab g.labels (setAt r.1.2 idx o.banks) }
        rw [eraseBanks_setAt_ne lab hlen idx hlab]
      have e2 : eraseG { g with calls := g.calls ++ [⟨g.labelAt idx, idx, g.histAt idx, B, CallKind.release mode,
            (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } =
          { eraseG g with calls := (eraseG g).calls ++ [⟨(eraseG g).labelAt idx, idx, (eraseG g).histAt idx,
            eraseBank B, CallKind.release mode, (r.2.map Prod.fst).getD 0, r.2.map (fun x => Sum.inr x.2)⟩] } := by
        simp only [eraseG, List.map_append, List.map_cons, List.map_nil]
        rfl
      rw [e1]
      refine (ih r.1.1 _ _ ost f (hBk _) hR1).trans ?_
      rw [e2]

/-! ## The simulation theorem -/

theorem simClaim_all (P : StreamParams) (lab : BankLabel) {α : Type} : ∀ p : AlgM α, SimClaim P lab p
  | AlgM.pure a => simClaim_pure P lab a
  | AlgM.fpInit k => simClaim_fpInit P lab k (simClaim_all P lab k)
  | AlgM.fpStep i Δ k => simClaim_fpStep P lab i Δ k fun z => simClaim_all P lab (k z)
  | AlgM.bankNew tr d k => simClaim_bankNew P lab tr d k (simClaim_all P lab k)
  | AlgM.bankRetain n k => simClaim_bankRetain P lab n k (simClaim_all P lab k)
  | AlgM.bankOp idx op k => simClaim_bankOp P lab idx op k (simClaim_all P lab k)
  | AlgM.bankOpFrom idx op k => simClaim_bankOpFrom P lab idx op k (simClaim_all P lab k)
  | AlgM.bankValidate idx S θ k => simClaim_bankValidate P lab idx S θ k fun c => simClaim_all P lab (k c)
  | AlgM.bankRelease idx mode k => simClaim_bankRelease P lab idx mode k fun r => simClaim_all P lab (k r)
  | AlgM.note ev k => simClaim_note P lab ev k (simClaim_all P lab k)

/-- The initial simulation relation. -/
theorem simRel_init (P : StreamParams) (lab : BankLabel) : SimRel P lab initO Ghost.init none false where
  rows := ⟨rfl, rfl, fun idx B h => by simp [initO] at h⟩
  flag := by simp
  uniq := fun i j hi _ => by simp [Ghost.init] at hi
  none_lab := fun _ => ⟨by simp [Ghost.init], rfl⟩
  some_trv := fun os h => by simp at h
  some_bank := fun os h => by simp at h

/-- **The simulation of the selected bank by its oracle** (partIII.tex L1271–1277): for a controller program in
which bank `lab` is born at most once, the instrumented run from the initial state, with bank `lab`'s ADA sample
and coins retagged `true`, is the oracle-split run with bank `lab`'s ADA module run by B's online core, up to the
erasure of bank `lab`'s ADA part; in particular bank `lab`'s ADA transcript is the oracle's transcript. -/
theorem sim (P : StreamParams) (lab : BankLabel) {α : Type} (p : AlgM α) (hp : BirthOnce lab false p) :
    ((runL P p initO Ghost.init).retag (adaSel lab)).map (simOut P lab) =
      (handle P (runX P lab false p initO Ghost.init) none).map fun r => (r.1, trvOf r.2) :=
  simClaim_all P lab p initO Ghost.init none false hp (simRel_init P lab)

end F2e2e.C.Closure
