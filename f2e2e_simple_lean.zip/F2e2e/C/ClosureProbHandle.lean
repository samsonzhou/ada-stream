import F2e2e.C.ClosureProbOracle
import F2e2e.C.ClosureProbCore

/-!
# Theorem 6.4, probability layer (C-PROB): counting the oracle runs of the selected bank

Paper: `parts/partIII.tex` L1271–1277 ("after fixing their complete initial tapes, [the other components] can be
simulated from the selected bank's permitted history … Theorem `R:thm:validation_ada` consequently supplies each
bank's unconditional capped ADA event").

`handle_count`: for an oracle program `I` of the shape produced by C-PROB's interpreter (`Phase1`: other bits, at
most one birth `sample`, then other bits and the initialization `init`, then other bits and calls; `ValidCalls`),
and every fixed stream `a` of the other bits, at most a `β_B/2` fraction of the streams `l` of the selected bits make
the oracle run `handle P I none` end with a transcript on which B's core-level failure event occurs.

Proof:
* `walk I a`: the composite deterministic controller (walk the program with the other bits `a`, answering the calls
  from the response history); valid by `ValidCalls` (`walk_valid`);
* coupling (`couple3`, `couple2`, `couple1`): along a successful run, every recorded request is the controller's
  request after the previous responses, and the sample-then-core program `coreQ P (walk I a) T` run on `l ++ e`
  (`T` at least the number of calls) reproduces the transcript's responses as a prefix of its outputs;
* `coreFails_transfer`: the failure event only reads the requests and outputs up to the failing round;
* counting (`count_transfer`): padding by `D = depth` bits and B's count `coreQ_count`.
-/

namespace F2e2e.C.Closure

open F2e2e.C.Alg F2e2e.B F2e2e.Discrete F2e2e.C.Top F2e2e.C.NormBank
open TBitProg
open scoped ENNReal

namespace HandleCount

/-! ## The composite controller -/

/-- Walk the oracle program with the other bits `a`, answering the calls from the response history `h`: the request
of the next call (`defaultReq` if the program ends, or the other bits run out, before it). -/
def walk {U α : Type} : OProg (CoreReq U) α → List Bool → List CoreOut → CoreReq U
  | OProg.pure _, _, _ => defaultReq U
  | OProg.bit _, [], _ => defaultReq U
  | OProg.bit k, b :: a, h => walk (k b) a h
  | OProg.sample k, a, h => walk k a h
  | OProg.init k, a, h => walk k a h
  | OProg.call q _, _, [] => q
  | OProg.call _ k, a, out :: h => walk (k out) a h

theorem defaultReq_valid {U : Type} (A : AdaParams) :
    (∀ x, (defaultReq U).f x ≤ 2 ^ A.qA) ∧
      ((defaultReq U).isInterval = true → (defaultReq U).l ≤ (defaultReq U).u) :=
  ⟨fun _ => Nat.zero_le _, fun h => absurd h (by simp [defaultReq])⟩

theorem walk_valid {U α : Type} (A : AdaParams) :
    ∀ (I : OProg (CoreReq U) α), ValidCalls A I → ∀ (a : List Bool) (h : List CoreOut),
      (∀ x, (walk I a h).f x ≤ 2 ^ A.qA) ∧
        ((walk I a h).isInterval = true → (walk I a h).l ≤ (walk I a h).u) := by
  intro I hI
  induction hI with
  | pure x => intro a h; exact defaultReq_valid A
  | bit k _ ih =>
    intro a h
    cases a with
    | nil => exact defaultReq_valid A
    | cons b a' => exact ih b a' h
  | sample k _ ih => intro a h; exact ih a h
  | init k _ ih => intro a h; exact ih a h
  | call q k hq _ ih =>
    intro a h
    cases h with
    | nil => exact hq
    | cons out h' => exact ih out a h'

/-! ## Runs with the two streams -/

theorem update_pairStreams_false (a l a' : List Bool) :
    Function.update (pairStreams a l) false a' = pairStreams a' l := by
  funext b
  cases b
  · rw [Function.update_self]; rfl
  · rw [Function.update_of_ne (by decide)]; rfl

theorem update_pairStreams_true (a l l' : List Bool) :
    Function.update (pairStreams a l) true l' = pairStreams a l' := by
  funext b
  cases b
  · rw [Function.update_of_ne (by decide)]; rfl
  · rw [Function.update_self]; rfl

theorem runS_bit_false_nil {β : Type} (k : Bool → TBitProg Bool β) (l : List Bool) :
    (TBitProg.bit false k).runS (pairStreams [] l) = none := rfl

theorem runS_bit_false_cons {β : Type} (k : Bool → TBitProg Bool β) (b : Bool) (a l : List Bool) :
    (TBitProg.bit false k).runS (pairStreams (b :: a) l) = (k b).runS (pairStreams a l) := by
  rw [TBitProg.runS_bit_cons false k _ b a rfl, update_pairStreams_false]

theorem runS_tag_true {β : Type} (a : List Bool) :
    ∀ (p : BitProg β) (l : List Bool),
      (TBitProg.tag true p).runS (pairStreams a l) = (p.run l).map fun r => (r.1, pairStreams a r.2)
  | BitProg.pure x, l => rfl
  | BitProg.bit k, [] => rfl
  | BitProg.bit k, b :: l => by
    rw [TBitProg.tag_bit, TBitProg.runS_bit_cons true _ _ b l rfl, update_pairStreams_true,
      runS_tag_true a (k b) l]
    rfl

/-! ## The core's loop extends its history -/

theorem coreLoop_hist_prefix {U : Type} (A : AdaParams) (ctrl : CoreCtrl U) (s : Fin A.N → U) :
    ∀ (T : ℕ) (st : AdaState) (hist : List CoreOut) (t : List Bool) (o : List CoreOut) (rest : List Bool),
      (coreLoop A ctrl s T st hist).run t = some (o, rest) → hist <+: o
  | 0, st, hist, t, o, rest, h => by
    simp only [coreLoop, BitProg.run_pure, Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨rfl, -⟩ := h
    exact List.prefix_refl _
  | T + 1, st, hist, t, o, rest, h => by
    simp only [coreLoop] at h
    rw [BitProg.run_bind] at h
    cases hs : (coreStep A s (ctrl hist) st).run t with
    | none => simp [hs] at h
    | some r =>
      simp only [hs, Option.bind_some] at h
      exact (List.prefix_append hist [r.1.1]).trans
        (coreLoop_hist_prefix A ctrl s T r.1.2 (hist ++ [r.1.1]) r.2 o rest h)

/-! ## The failure event only reads the past -/

theorem coreFails_transfer {U : Type} [Fintype U] (A : AdaParams) (D : U → ℝ) (α : ℝ)
    {c1 c2 : CoreCtrl U} {o1 o2 : List CoreOut} (hpre : o1 <+: o2)
    (hc : ∀ j < o1.length, c1 (o1.take j) = c2 (o1.take j)) (h : coreFails A D α c1 o1) :
    coreFails A D α c2 o2 := by
  obtain ⟨t, ht, hcov, hinc⟩ := h
  obtain ⟨r, rfl⟩ := hpre
  have htake : ∀ j ≤ t, (o1 ++ r).take j = o1.take j := fun j hj =>
    List.take_append_of_le_length (by omega)
  have hreq : ∀ j ≤ t, coreReqAt c2 (o1 ++ r) j = coreReqAt c1 o1 j := by
    intro j hj
    unfold coreReqAt
    rw [htake j hj]
    exact (hc j (by omega)).symm
  have hout : ∀ j ≤ t, coreOutAt (o1 ++ r) j = coreOutAt o1 j := by
    intro j hj
    unfold coreOutAt
    exact List.getD_append _ _ _ _ (by omega)
  have hI : ∀ j ≤ t, ((Finset.range (j + 1)).filter fun i => (coreReqAt c2 (o1 ++ r) i).isInterval = true) =
      ((Finset.range (j + 1)).filter fun i => (coreReqAt c1 o1 i).isInterval = true) := by
    intro j hj
    refine Finset.filter_congr fun i hi => ?_
    rw [hreq i (by rw [Finset.mem_range] at hi; omega)]
  have hN : ((Finset.range (t + 1)).filter fun i => (coreReqAt c2 (o1 ++ r) i).isInterval = false) =
      ((Finset.range (t + 1)).filter fun i => (coreReqAt c1 o1 i).isInterval = false) := by
    refine Finset.filter_congr fun i hi => ?_
    rw [hreq i (by rw [Finset.mem_range] at hi; omega)]
  have hrej : ((Finset.range t).filter fun j =>
        (coreReqAt c2 (o1 ++ r) j).isInterval = true ∧
          ((Finset.range (j + 1)).filter fun i => (coreReqAt c2 (o1 ++ r) i).isInterval = true).card ≤
            A.M ∧
          coreIsReject (coreOutAt (o1 ++ r) j) = true) =
      ((Finset.range t).filter fun j =>
        (coreReqAt c1 o1 j).isInterval = true ∧
          ((Finset.range (j + 1)).filter fun i => (coreReqAt c1 o1 i).isInterval = true).card ≤ A.M ∧
          coreIsReject (coreOutAt o1 j) = true) := by
    refine Finset.filter_congr fun j hj => ?_
    have hjt : j ≤ t := by rw [Finset.mem_range] at hj; omega
    rw [hreq j hjt, hI j hjt, hout j hjt]
  refine ⟨t, by rw [List.length_append]; omega, ?_, ?_⟩
  · obtain ⟨h1, h2, h3⟩ := hcov
    refine ⟨?_, ?_, ?_⟩
    · rw [hrej]; exact h1
    · rw [hreq t le_rfl, hI t le_rfl]; exact h2
    · rw [hreq t le_rfl, hN]; exact h3
  · rw [hreq t le_rfl, hout t le_rfl]; exact hinc

/-! ## Coupling with the sample-then-core program -/

theorem couple3 (P : StreamParams) {α : Type} (ctrl : CoreCtrl (Seed P)) :
    ∀ (J : OProg (CoreReq (Seed P)) α), Phase3 J →
      ∀ (a l : List Bool) (os : OrSt P) (hist : List CoreOut) (x : α) (ost : Option (OrSt P))
        (σ' : Bool → List Bool),
        (∀ h', ctrl (hist ++ h') = walk J a h') →
        (handle P J (some os)).runS (pairStreams a l) = some ((x, ost), σ') →
        ∃ os' tr, ost = some os' ∧ os'.trv = os.trv ++ tr ∧
          (∀ j < tr.length,
            (tr.getD j (defaultReq (Seed P), Sum.inl AdaCert.abort)).1 =
              ctrl (hist ++ (tr.map Prod.snd).take j)) ∧
          ∀ T, tr.length ≤ T → ∀ (e : List Bool) (o : List CoreOut) (rest : List Bool),
            (coreLoop (bankAda P) ctrl (sOf P os.rows) T os.st hist).run (l ++ e) = some (o, rest) →
            hist ++ tr.map Prod.snd <+: o := by
  intro J hJ
  induction hJ with
  | pure x0 =>
    intro a l os hist x ost σ' _ h
    simp only [handle, TBitProg.runS_pure, Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨⟨-, rfl⟩, -⟩ := h
    refine ⟨os, [], rfl, by simp, fun j hj => absurd hj (by simp), ?_⟩
    intro T _ e o rest hrun
    simpa using coreLoop_hist_prefix (bankAda P) ctrl (sOf P os.rows) T os.st hist (l ++ e) o rest hrun
  | bit k _ ih =>
    intro a l os hist x ost σ' hctrl h
    cases a with
    | nil =>
      simp only [handle] at h
      rw [runS_bit_false_nil] at h
      exact absurd h (by simp)
    | cons b a' =>
      simp only [handle] at h
      rw [runS_bit_false_cons] at h
      exact ih b a' l os hist x ost σ' (fun h' => hctrl h') h
  | call q k _ ih =>
    intro a l os hist x ost σ' hctrl h
    simp only [handle] at h
    rw [TBitProg.runS_bind, runS_tag_true] at h
    cases hs : (coreStep (bankAda P) (sOf P os.rows) q os.st).run l with
    | none => simp [hs] at h
    | some r =>
      obtain ⟨⟨out, st'⟩, l'⟩ := r
      simp only [hs, Option.map_some, Option.bind_some] at h
      have hq : ctrl hist = q := by
        have h0 := hctrl []
        rw [List.append_nil] at h0
        exact h0
      obtain ⟨os', tr', host, htrv, hget, hloop⟩ := ih out a l'
        { os with st := st', trv := os.trv ++ [(q, out)] } (hist ++ [out]) x ost σ'
        (fun h' => by rw [List.append_assoc, List.singleton_append]; exact hctrl (out :: h')) h
      refine ⟨os', (q, out) :: tr', host, by rw [htrv]; simp, ?_, ?_⟩
      · intro j hj
        cases j with
        | zero => simpa using hq.symm
        | succ j =>
          rw [List.getD_cons_succ, hget j (by simp at hj; omega)]
          simp [List.append_assoc]
      · intro T hT e o rest hrun
        obtain ⟨T', rfl⟩ : ∃ T', T = T' + 1 := ⟨T - 1, by simp at hT; omega⟩
        simp only [coreLoop] at hrun
        rw [BitProg.run_bind, hq, BitProg.run_append hs e] at hrun
        simp only [Option.bind_some] at hrun
        have := hloop T' (by simp at hT; omega) e o rest hrun
        simpa [List.append_assoc] using this

theorem couple2 (P : StreamParams) {α : Type} (ctrl : CoreCtrl (Seed P)) :
    ∀ (K : OProg (CoreReq (Seed P)) α), Phase2 K →
      ∀ (a l : List Bool) (os : OrSt P) (x : α) (ost : Option (OrSt P)) (σ' : Bool → List Bool),
        os.trv = [] →
        (∀ h', ctrl h' = walk K a h') →
        (handle P K (some os)).runS (pairStreams a l) = some ((x, ost), σ') →
        (∀ j < (trvOf ost).length,
          ((trvOf ost).getD j (defaultReq (Seed P), Sum.inl AdaCert.abort)).1 =
            ctrl (((trvOf ost).map Prod.snd).take j)) ∧
        ∀ T, (trvOf ost).length ≤ T → ∀ (e : List Bool) (o : List CoreOut) (rest : List Bool),
          (coreRun (bankAda P) ctrl (sOf P os.rows) T).run (l ++ e) = some (o, rest) →
          (trvOf ost).map Prod.snd <+: o := by
  intro K hK
  induction hK with
  | pure x0 =>
    intro a l os x ost σ' hos _ h
    simp only [handle, TBitProg.runS_pure, Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨⟨-, rfl⟩, -⟩ := h
    simp only [trvOf, hos]
    exact ⟨fun j hj => absurd hj (by simp), fun T _ e o rest _ => List.nil_prefix⟩
  | bit k _ ih =>
    intro a l os x ost σ' hos hctrl h
    cases a with
    | nil =>
      simp only [handle] at h
      rw [runS_bit_false_nil] at h
      exact absurd h (by simp)
    | cons b a' =>
      simp only [handle] at h
      rw [runS_bit_false_cons] at h
      exact ih b a' l os x ost σ' hos (fun h' => hctrl h') h
  | init k hk =>
    intro a l os x ost σ' hos hctrl h
    simp only [handle] at h
    rw [TBitProg.runS_bind, runS_tag_true] at h
    cases hs : (adaInit (bankAda P)).run l with
    | none => simp [hs] at h
    | some r =>
      obtain ⟨st, l'⟩ := r
      simp only [hs, Option.map_some, Option.bind_some] at h
      obtain ⟨os', tr, host, htrv, hget, hloop⟩ := couple3 P ctrl k hk a l' { os with st := st } [] x ost σ'
        (fun h' => by rw [List.nil_append]; exact hctrl h') h
      subst host
      have htr : os'.trv = tr := by rw [htrv]; simp [hos]
      simp only [trvOf, htr]
      refine ⟨fun j hj => by simpa using hget j hj, ?_⟩
      intro T hT e o rest hrun
      rw [coreRun, BitProg.run_bind, BitProg.run_append hs e] at hrun
      simp only [Option.bind_some] at hrun
      simpa using hloop T hT e o rest hrun

theorem couple1 (P : StreamParams) {α : Type} :
    ∀ (I : OProg (CoreReq (Seed P)) α), Phase1 I →
      ∀ (a l : List Bool) (x : α) (ost : Option (OrSt P)) (σ' : Bool → List Bool),
        (handle P I none).runS (pairStreams a l) = some ((x, ost), σ') →
        (∀ j < (trvOf ost).length,
          ((trvOf ost).getD j (defaultReq (Seed P), Sum.inl AdaCert.abort)).1 =
            walk I a (((trvOf ost).map Prod.snd).take j)) ∧
        ∀ T, (trvOf ost).length ≤ T → ∀ (e : List Bool) (o : List CoreOut) (rest : List Bool),
          (coreQ P (walk I a) T).run (l ++ e) = some (o, rest) →
          (trvOf ost).map Prod.snd <+: o := by
  intro I hI
  induction hI with
  | pure x0 =>
    intro a l x ost σ' h
    simp only [handle, TBitProg.runS_pure, Option.some.injEq, Prod.mk.injEq] at h
    obtain ⟨⟨-, rfl⟩, -⟩ := h
    simp only [trvOf]
    exact ⟨fun j hj => absurd hj (by simp), fun T _ e o rest _ => List.nil_prefix⟩
  | bit k _ ih =>
    intro a l x ost σ' h
    cases a with
    | nil =>
      simp only [handle] at h
      rw [runS_bit_false_nil] at h
      exact absurd h (by simp)
    | cons b a' =>
      simp only [handle] at h
      rw [runS_bit_false_cons] at h
      have hw : walk (OProg.bit k) (b :: a') = walk (k b) a' := funext fun _ => rfl
      rw [hw]
      exact ih b a' l x ost σ' h
  | sample k hk =>
    intro a l x ost σ' h
    simp only [handle] at h
    rw [TBitProg.runS_bind, runS_tag_true] at h
    cases hs : (sampleBlocks P (bankAda P).blockSizes).run l with
    | none => simp [hs] at h
    | some r =>
      obtain ⟨rows, l'⟩ := r
      simp only [hs, Option.map_some, Option.bind_some] at h
      have hw : walk (OProg.sample k) a = walk k a := funext fun _ => rfl
      obtain ⟨hget, hloop⟩ := couple2 P (walk (OProg.sample k) a) k hk a l' ⟨rows, dfltSt, []⟩ x ost σ'
        rfl (fun h' => by rw [hw]) h
      refine ⟨hget, fun T hT e o rest hrun => ?_⟩
      unfold coreQ at hrun
      rw [BitProg.run_bind, BitProg.run_append hs e] at hrun
      simp only [Option.bind_some] at hrun
      exact hloop T hT e o rest hrun

/-! ## Counting -/

theorem sum_lenFinset_add (a b : ℕ) (G : List Bool → ℝ≥0∞) :
    ∑ l ∈ TBitProg.lenFinset a, ∑ e ∈ TBitProg.lenFinset b, G (l ++ e) =
      ∑ l' ∈ TBitProg.lenFinset (a + b), G l' := by
  rw [← Finset.sum_product' (f := fun l e => G (l ++ e))]
  refine Finset.sum_nbij' (fun p => p.1 ++ p.2) (fun l' => (l'.take a, l'.drop a)) ?_ ?_ ?_ ?_ ?_
  · rintro ⟨l, e⟩ h
    simp only [Finset.mem_product, TBitProg.mem_lenFinset] at h
    simp only [TBitProg.mem_lenFinset, List.length_append]
    omega
  · intro l' h
    simp only [TBitProg.mem_lenFinset] at h
    simp only [Finset.mem_product, TBitProg.mem_lenFinset, List.length_take, List.length_drop]
    omega
  · rintro ⟨l, e⟩ h
    simp only [Finset.mem_product, TBitProg.mem_lenFinset] at h
    simp only [Prod.mk.injEq]
    constructor
    · rw [List.take_append_of_le_length (by omega), List.take_of_length_le (by omega)]
    · rw [List.drop_append_of_le_length (by omega), List.drop_of_length_le (by omega), List.nil_append]
  · intro l' _
    simp only [List.take_append_drop]
  · intro p _
    rfl

open Classical in
theorem count_transfer {nΛ D : ℕ} (Bf Qf : List Bool → Prop)
    (hBQ : ∀ l ∈ TBitProg.lenFinset nΛ, ∀ e ∈ TBitProg.lenFinset D, Bf l → Qf (l ++ e)) (ξ : ℝ≥0∞)
    (hQ : ∑ l' ∈ TBitProg.lenFinset (nΛ + D), (if Qf l' then (1 : ℝ≥0∞) else 0) ≤ ξ * 2 ^ (nΛ + D)) :
    ∑ l ∈ TBitProg.lenFinset nΛ, (if Bf l then (1 : ℝ≥0∞) else 0) ≤ ξ * 2 ^ nΛ := by
  have h2D : (2 : ℝ≥0∞) ^ D * ∑ l ∈ TBitProg.lenFinset nΛ, (if Bf l then (1 : ℝ≥0∞) else 0) =
      ∑ l ∈ TBitProg.lenFinset nΛ, ∑ _e ∈ TBitProg.lenFinset D, (if Bf l then (1 : ℝ≥0∞) else 0) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun l _ => ?_
    rw [Finset.sum_const, TBitProg.card_lenFinset, nsmul_eq_mul]
    push_cast
    ring
  have hle : ∑ l ∈ TBitProg.lenFinset nΛ, ∑ _e ∈ TBitProg.lenFinset D, (if Bf l then (1 : ℝ≥0∞) else 0) ≤
      ∑ l ∈ TBitProg.lenFinset nΛ, ∑ e ∈ TBitProg.lenFinset D, (if Qf (l ++ e) then (1 : ℝ≥0∞) else 0) := by
    refine Finset.sum_le_sum fun l hl => Finset.sum_le_sum fun e he => ?_
    by_cases hb : Bf l
    · rw [if_pos hb, if_pos (hBQ l hl e he hb)]
    · rw [if_neg hb]
      exact zero_le
  have hle' := hle.trans_eq (sum_lenFinset_add nΛ D (fun l' => if Qf l' then (1 : ℝ≥0∞) else 0))
  have hfin : (2 : ℝ≥0∞) ^ D * ∑ l ∈ TBitProg.lenFinset nΛ, (if Bf l then (1 : ℝ≥0∞) else 0) ≤
      (2 : ℝ≥0∞) ^ D * (ξ * 2 ^ nΛ) := by
    rw [h2D]
    refine hle'.trans (hQ.trans (le_of_eq ?_))
    rw [pow_add]
    ring
  exact (ENNReal.mul_le_mul_iff_right (pow_ne_zero _ two_ne_zero)
    (ENNReal.pow_ne_top ENNReal.ofNat_ne_top)).1 hfin

end HandleCount

open HandleCount in
open Classical in
/-- **The selected bank's ADA event, per fixed stream of the other bits** (Theorem 3.6 applied to the composite
controller of the oracle program). -/
theorem handle_count (P : StreamParams) (hP : ParamsOK P) {α : Type} (I : OProg (CoreReq (Seed P)) α)
    (hI : Phase1 I) (hval : ValidCalls (bankAda P) I) (nΛ : ℕ) (a : List Bool) :
    ∑ l ∈ TBitProg.lenFinset nΛ,
      (if ∃ x ost σ', (handle P I none).runS (pairStreams a l) = some ((x, ost), σ') ∧
          coreFails (bankAda P) (unifD P) (P.aNum : ℝ) (ctrlOf (trvOf ost)) ((trvOf ost).map Prod.snd)
        then (1 : ℝ≥0∞) else 0) ≤ ENNReal.ofReal ((P.betaB : ℝ) / 2) * 2 ^ nΛ := by
  have hvalid : CoreCtrl.Valid (bankAda P) (walk I a) := fun h => walk_valid (bankAda P) I hval a h
  set T := ∑ l ∈ TBitProg.lenFinset nΛ,
    ((handle P I none).runS (pairStreams a l)).elim 0 (fun r => (trvOf r.1.2).length) with hT
  refine count_transfer (D := (coreQ P (walk I a) T).depth) _
    (fun l' => ∃ o rest, (coreQ P (walk I a) T).run l' = some (o, rest) ∧
      coreFails (bankAda P) (unifD P) (P.aNum : ℝ) (walk I a) o) ?_ _
    (coreQ_count P hP (walk I a) hvalid T _ (by omega))
  intro l hl e he hbad
  obtain ⟨x, ost, σ', hrun, hfail⟩ := hbad
  have hlenT : (trvOf ost).length ≤ T := by
    have h1 : ((handle P I none).runS (pairStreams a l)).elim 0 (fun r => (trvOf r.1.2).length) =
        (trvOf ost).length := by
      rw [hrun]
      rfl
    rw [← h1, hT]
    exact Finset.single_le_sum
      (f := fun l => ((handle P I none).runS (pairStreams a l)).elim 0 (fun r => (trvOf r.1.2).length))
      (fun _ _ => Nat.zero_le _) hl
  have hlen_le : (coreQ P (walk I a) T).depth ≤ (l ++ e).length := by
    rw [List.length_append, TBitProg.mem_lenFinset.1 hl, TBitProg.mem_lenFinset.1 he]
    omega
  obtain ⟨⟨o, rest⟩, hq⟩ := Option.isSome_iff_exists.1 (BitProg.run_isSome _ _ hlen_le)
  obtain ⟨hget, hpre⟩ := couple1 P I hI a l x ost σ' hrun
  refine ⟨o, rest, hq, coreFails_transfer _ _ _ (hpre T hlenT e o rest hq) ?_ hfail⟩
  intro j hj
  rw [List.length_map] at hj
  show ((trvOf ost).getD (((trvOf ost).map Prod.snd).take j).length
    (defaultReq (Seed P), Sum.inl AdaCert.abort)).1 = walk I a (((trvOf ost).map Prod.snd).take j)
  rw [List.length_take, List.length_map, min_eq_left hj.le]
  exact hget j hj

end F2e2e.C.Closure
