import F2e2e.A.Sim

/-!
# [SIM_r], one episode: the episode is a post-processing of an AboveThreshold run and one Laplace release

Paper: Part I, Prop. `I:prop:svt_episode_pure_dp` (`parts/partI.tex` L887-957). Fix a validator stage `2 ≤ r ≤ L`,
an episode index `e` and a history `y` of earlier episodes (with `e ≤ epCover y < k`). Run the mechanism from the
start state of episode `e` with stage `r` **forced**: `contRunF … m v` forces stage `r` to pass at the round offsets
`t ≠ m`, to fire at offset `m`, and uses `v` as its release value. Then
* the forced run does not read stage `r`'s noise (`contRunF_noise_congr`);
* the forced episode `epOutF … m v` is a function of the public data only;
* the actual episode `epMap … e y ω` is `epOutF … (m ω) (v ω)` where `m ω` is the output of an AboveThreshold run
  (threshold `ρ^{(r)}_e`, query noises `ν^{(r)}_{s+j}`) on the test values of the all-pass run, and `v ω` is the
  Laplace release `θ + ζ^{(r)}` at the episode's last test (`epMap_eq_epOutF`).

This file: the refined chain congruences and the forced continued run.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

namespace ChainData

/-- `orig` congruence where the release of a stage only matters when that stage fires. -/
theorem orig_congr_sim' {d₁ d₂ : ChainData} (hL : d₁.L = d₂.L) (hc1 : d₁.c1 = d₂.c1) {s : ℕ}
    (h : ∀ t < s, (d₁.Fires t (d₁.orig t).1 (d₁.orig t).2 ↔ d₂.Fires t (d₁.orig t).1 (d₁.orig t).2) ∧
      (2 ≤ t ∧ t ≤ d₁.L ∧ d₁.Fires t (d₁.orig t).1 (d₁.orig t).2 → d₁.relC t = d₂.relC t)) :
    d₁.orig s = d₂.orig s := by
  induction s with
  | zero =>
    show (1, d₁.c1) = (1, d₂.c1)
    rw [hc1]
  | succ s ih =>
    have ih' := ih (fun t ht => h t (by omega))
    obtain ⟨hF, hR⟩ := h s (by omega)
    show (if 2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2 then (s, d₁.relC s)
        else d₁.orig s) =
      (if 2 ≤ s ∧ s ≤ d₂.L ∧ d₂.Fires s (d₂.orig s).1 (d₂.orig s).2 then (s, d₂.relC s)
        else d₂.orig s)
    have hcond : (2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2) ↔
        (2 ≤ s ∧ s ≤ d₂.L ∧ d₂.Fires s (d₂.orig s).1 (d₂.orig s).2) := by
      rw [hL, hF, ← ih']
    by_cases hc : 2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2
    · rw [if_pos hc, if_pos (hcond.1 hc), hR hc]
    · rw [if_neg hc, if_neg (fun h' => hc (hcond.2 h')), ih']

/-- The record of a round only depends on `L`, `c₁`, the origins, the trigger pattern and the releases of the
released stages. -/
theorem toRec_congr_sim' {d₁ d₂ : ChainData} (hL : d₁.L = d₂.L) (hc1 : d₁.c1 = d₂.c1)
    (horig : ∀ s, d₁.orig s = d₂.orig s) (htrig : ∀ s, d₁.Trig s ↔ d₂.Trig s)
    (hrel : ∀ s, d₁.Released s → d₁.relV s = d₂.relV s) (e1 e : ℝ) (eT : ℕ → ℝ) :
    d₁.toRec e1 e eT = d₂.toRec e1 e eT := by
  have huf : d₁.ufinal = d₂.ufinal := by
    unfold ufinal
    rw [horig, hL]
  have hans : d₁.answer = d₂.answer := by
    unfold answer
    rw [horig, hL]
  have hrelsd : ∀ s, d₁.Released s ↔ d₂.Released s := fun s => by
    unfold Released
    rw [htrig, huf]
  have hcprev : ∀ s, d₁.cprev s = d₂.cprev s := fun s => by
    unfold cprev
    rw [horig]
  have hsgn : d₁.sgn = d₂.sgn := by
    unfold sgn
    rw [huf, hcprev, hans]
  have hdelta : ∀ m, d₁.delta e1 e eT m = d₂.delta e1 e eT m := fun m => by
    unfold delta
    rw [huf, hsgn]
  unfold toRec
  congr 1
  · funext s
    exact decide_eq_decide.mpr (htrig s)
  · funext s
    unfold uprev
    rw [horig]
  · funext s
    exact decide_eq_decide.mpr (hrelsd s)
  · funext s
    by_cases h : d₁.Released s
    · rw [if_pos h, if_pos ((hrelsd s).1 h), hrel s h]
    · rw [if_neg h, if_neg (fun h' => h ((hrelsd s).2 h'))]
  · funext s
    by_cases h1 : s = 1
    · rw [if_pos h1, if_pos h1, hc1]
    · rw [if_neg h1, if_neg h1]
      by_cases h : d₁.Released s
      · rw [if_pos h, if_pos ((hrelsd s).1 h)]
        unfold relC
        rw [hrel s h]
      · rw [if_neg h, if_neg (fun h' => h ((hrelsd s).2 h'))]
  · funext m
    exact hdelta m

/-- With stage `r` forced to pass, the origins do not depend on the release value. -/
theorem force_false_orig (d : ChainData) (r : ℕ) (v₁ v₂ : ℝ) (s : ℕ) :
    (d.force r false v₁).orig s = (d.force r false v₂).orig s := by
  refine orig_congr_sim' (d₁ := d.force r false v₁) (d₂ := d.force r false v₂) (s := s) rfl rfl
    fun t _ => ?_
  by_cases htr : t = r
  · rw [htr, force_orig_of_le d r false v₁ le_rfl]
    refine ⟨by rw [force_fires, force_fires], fun h => ?_⟩
    rw [force_fires] at h
    exact absurd h.2.2 (by decide)
  · refine ⟨?_, fun _ => ?_⟩
    · rw [force_fires_of_ne d false v₁ htr, force_fires_of_ne d false v₂ htr]
    · unfold relC
      rw [force_relV_of_ne d false v₁ htr, force_relV_of_ne d false v₂ htr]

theorem force_false_ufinal (d : ChainData) (r : ℕ) (v₁ v₂ : ℝ) :
    (d.force r false v₁).ufinal = (d.force r false v₂).ufinal := by
  unfold ufinal
  rw [force_false_orig d r v₁ v₂]
  rfl

/-- **Release-value irrelevance.** With stage `r` forced to pass, the release value only matters if stage `r` is
released retroactively (`u_final = r + 1`). -/
theorem force_false_toRec_congr (d : ChainData) (r : ℕ) (v₁ v₂ : ℝ) (e1 e : ℝ) (eT : ℕ → ℝ)
    (hu : (d.force r false v₁).ufinal ≠ r + 1) :
    (d.force r false v₁).toRec e1 e eT = (d.force r false v₂).toRec e1 e eT := by
  refine toRec_congr_sim' (d₁ := d.force r false v₁) (d₂ := d.force r false v₂) rfl rfl
    (force_false_orig d r v₁ v₂) (fun s => ?_) (fun s hs => ?_) e1 e eT
  · by_cases hsr : s = r
    · rw [hsr, force_trig, force_trig]
    · unfold Trig
      refine and_congr Iff.rfl (and_congr Iff.rfl ?_)
      rw [force_false_orig d r v₁ v₂, force_fires_of_ne d false v₁ hsr, force_fires_of_ne d false v₂ hsr]
  · by_cases hsr : s = r
    · exfalso
      rw [hsr] at hs
      rcases hs with hT | ⟨-, h2⟩
      · rw [force_trig] at hT
        exact absurd hT.2.2 (by decide)
      · exact hu h2.symm
    · rw [force_relV_of_ne d false v₁ hsr, force_relV_of_ne d false v₂ hsr]

end ChainData

/-! ## Forced rounds: halted rounds, release irrelevance, noise irrelevance -/

section ForcedRounds

variable {k : ℕ} {α β : ℝ}

theorem stepF_of_halt (r : ℕ) {st : MState k α β} (h : st.halt = true) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) (b : Bool) (v : ℝ) :
    stepF r st i q ω b v = (st, RoundRec.halted) := by
  unfold stepF
  rw [if_pos h]

theorem stepF_of_not_halt (r : ℕ) {st : MState k α β} (h : st.halt = false) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) (b : Bool) (v : ℝ) :
    stepF r st i q ω b v =
      (st.next q (((roundChain st i q ω).force r b v).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)),
        ((roundChain st i q ω).force r b v).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)) := by
  unfold stepF
  rw [if_neg (by simp [h])]

/-- With stage `r` forced to pass and no retroactive release, the release value is irrelevant. -/
theorem stepF_false_congr (r : ℕ) (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (v₁ v₂ : ℝ) (hu : ((roundChain st i q ω).force r false v₁).ufinal ≠ r + 1) :
    stepF r st i q ω false v₁ = stepF r st i q ω false v₂ := by
  cases hh : st.halt
  · rw [stepF_of_not_halt r hh, stepF_of_not_halt r hh,
      ChainData.force_false_toRec_congr _ r v₁ v₂ _ _ _ hu]
  · rw [stepF_of_halt r hh, stepF_of_halt r hh]

/-- The forced round does not read stage `r`'s noise. -/
theorem stepF_noise_congr {r : ℕ} (hr : 2 ≤ r) (st : MState k α β) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) {ω₁ ω₂ : AdaOmega k α}
    (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ r → ω₁ j = ω₂ j) (b : Bool) (v : ℝ) :
    stepF r st i q ω₁ b v = stepF r st i q ω₂ b v := by
  have hrec : (stepF r st i q ω₁ b v).2 = (stepF r st i q ω₂ b v).2 := by
    refine stepF_rec_congr r i b v rfl ?_ (fun t _ => rfl) (fun t ht => ?_) (fun t ht => ?_)
      (fun t ht => ?_)
    · show clip01 (stage1Release st i q ω₁) = clip01 (stage1Release st i q ω₂)
      unfold stage1Release noiseBeta
      split_ifs with h1
      · rw [hω _ (by simp [NoiseIdx.stage]; omega)]
      · rfl
    · show noiseRho ω₁ t (st.M t - 1) = noiseRho ω₂ t (st.M t - 1)
      unfold noiseRho
      split_ifs with h1
      · exact hω _ (by simpa [NoiseIdx.stage] using ht)
      · rfl
    · show noiseNu ω₁ i t = noiseNu ω₂ i t
      unfold noiseNu
      split_ifs with h1
      · exact hω _ (by simpa [NoiseIdx.stage] using ht)
      · rfl
    · show noiseZeta ω₁ i t = noiseZeta ω₂ i t
      unfold noiseZeta
      split_ifs with h1
      · exact hω _ (by simpa [NoiseIdx.stage] using ht)
      · rfl
  cases hh : st.halt
  · have h1 := stepF_of_not_halt r hh i q ω₁ b v
    have h2 := stepF_of_not_halt r hh i q ω₂ b v
    rw [h1, h2] at hrec ⊢
    simp only at hrec
    rw [hrec]
  · rw [stepF_of_halt r hh, stepF_of_halt r hh]

end ForcedRounds

/-! ## The forced continued run -/

section ForcedRun

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- One more round `i` with stage `r` forced to `(b, v)`. -/
noncomputable def contStepF (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r i : ℕ) (b : Bool) (v : ℝ) (p : MState k α β × (Fin k → RoundRec)) :
    MState k α β × (Fin k → RoundRec) :=
  ((stepF r p.1 i (qOf A S p.2 i) ω b v).1, setRec p.2 i (stepF r p.1 i (qOf A S p.2 i) ω b v).2)

/-- The run continued from round `s` with stage `r` forced to fire exactly at the round offset `m` (and to pass at
the other offsets), with release value `v`. -/
noncomputable def contRunF (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) :
    ℕ → MState k α β × (Fin k → RoundRec)
  | 0 => (st₀, h₀)
  | t + 1 => contStepF A S ω r (s + t) (decide (t = m)) v (contRunF A S ω r s st₀ h₀ m v t)

theorem contRunF_zero (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) :
    contRunF A S ω r s st₀ h₀ m v 0 = (st₀, h₀) := rfl

theorem contRunF_succ (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) (t : ℕ) :
    contRunF A S ω r s st₀ h₀ m v (t + 1) =
      contStepF A S ω r (s + t) (decide (t = m)) v (contRunF A S ω r s st₀ h₀ m v t) := rfl

/-- The forced run does not read stage `r`'s noise. -/
theorem contRunF_noise_congr (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr : 2 ≤ r)
    {ω₁ ω₂ : AdaOmega k α} (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ r → ω₁ j = ω₂ j) (s : ℕ)
    (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) (t : ℕ) :
    contRunF A S ω₁ r s st₀ h₀ m v t = contRunF A S ω₂ r s st₀ h₀ m v t := by
  induction t with
  | zero => rfl
  | succ t ih =>
    rw [contRunF_succ, contRunF_succ, ih]
    unfold contStepF
    rw [stepF_noise_congr hr _ _ _ hω]

/-- Records of rounds before `s + t` are not changed by later rounds. -/
theorem setRec_of_lt {h : Fin k → RoundRec} {i : ℕ} (rec : RoundRec) {j : Fin k} (hj : j.val ≠ i) :
    setRec h i rec j = h j := by
  unfold setRec
  rw [if_neg hj]

theorem contRunF_rec_stable (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) {t t' : ℕ} (htt : t ≤ t')
    (j : Fin k) (hj : j.val < s + t) :
    (contRunF A S ω r s st₀ h₀ m v t').2 j = (contRunF A S ω r s st₀ h₀ m v t).2 j := by
  induction t', htt using Nat.le_induction with
  | base => rfl
  | succ n hn ih =>
    rw [contRunF_succ]
    unfold contStepF
    dsimp only
    rw [setRec_of_lt _ (by omega), ih]

theorem contRun_rec_stable (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) {t t' : ℕ} (htt : t ≤ t')
    (j : Fin k) (hj : j.val < s + t) :
    (contRun A S ω s st₀ h₀ t').2 j = (contRun A S ω s st₀ h₀ t).2 j := by
  induction t', htt using Nat.le_induction with
  | base => rfl
  | succ n hn ih =>
    rw [contRun_succ]
    unfold contStep
    dsimp only
    rw [setRec_of_lt _ (by omega), ih]

end ForcedRun

/-! ## Masks only see the rounds of the episode -/

section MaskCongr

variable {k : ℕ}

theorem inEp_iff_of_agree {r s : ℕ} {h h' : Fin k → RoundRec} (hh : ∀ i, InEp r s h i → h i = h' i)
    (i : Fin k) : InEp r s h i ↔ InEp r s h' i := by
  constructor
  · rintro ⟨hsi, hno⟩
    refine ⟨hsi, fun j hsj hji hj => hno j hsj hji ?_⟩
    have hin : InEp r s h j := ⟨hsj, fun l hsl hlj => hno l hsl (lt_trans hlj hji)⟩
    rwa [hh j hin]
  · rintro ⟨hsi, hno⟩
    refine ⟨hsi, fun j hsj hji hj => ?_⟩
    -- the least reset of `h` in `[s, i)`
    classical
    have hex : ∃ l : Fin k, s ≤ l.val ∧ l < i ∧ r ≤ (h l).ufinal := ⟨j, hsj, hji, hj⟩
    let l₀ := Nat.find (p := fun n => ∃ l : Fin k, l.val = n ∧ s ≤ l.val ∧ l < i ∧ r ≤ (h l).ufinal)
      ⟨j.val, j, rfl, hsj, hji, hj⟩
    obtain ⟨l, hl, hsl, hli, hlr⟩ := Nat.find_spec (p := fun n => ∃ l : Fin k, l.val = n ∧ s ≤ l.val ∧
      l < i ∧ r ≤ (h l).ufinal) ⟨j.val, j, rfl, hsj, hji, hj⟩
    have hmin : ∀ l' : Fin k, s ≤ l'.val → l' < l → ¬ r ≤ (h l').ufinal := fun l' hsl' hl'l hr' =>
      Nat.find_min (p := fun n => ∃ l : Fin k, l.val = n ∧ s ≤ l.val ∧ l < i ∧ r ≤ (h l).ufinal)
        ⟨j.val, j, rfl, hsj, hji, hj⟩ (show l'.val < Nat.find _ by
          rw [← hl]; exact hl'l) ⟨l', rfl, hsl', lt_trans hl'l hli, hr'⟩
    have hin : InEp r s h l := ⟨hsl, hmin⟩
    exact hno l hsl hli (by rw [← hh l hin]; exact hlr)

/-- The episode starting at round `s` only depends on the records of its own rounds. -/
theorem epMask_congr {r s : ℕ} {h h' : Fin k → RoundRec} (hh : ∀ i, InEp r s h i → h i = h' i) :
    epMask r s h = epMask r s h' := by
  unfold epMask
  refine Prod.ext (funext fun i => ?_) (funext fun i => ?_)
  · exact decide_eq_decide.mpr (inEp_iff_of_agree hh i)
  · by_cases hi : InEp r s h i
    · simp only [hi, if_true, (inEp_iff_of_agree hh i).1 hi]
      exact hh i hi
    · simp only [hi, if_false, show ¬ InEp r s h' i from fun h'' => hi ((inEp_iff_of_agree hh i).2 h'')]

end MaskCongr

end A

end F2e2e
