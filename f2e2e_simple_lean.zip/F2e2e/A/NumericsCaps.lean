import F2e2e.A.NumericsBasic

/-!
# Part I numerics: trigger caps and episode caps

Proposition `I:prop:validator_sample_complexity`(1) (`parts/partI.tex` L2106-2114, proof L2136-2150):
for `0 < α < 1/16`,
* `N_{r*,max} = ⌈8192 L³ ε_{r*-1}²/α²⌉ ≤ 8193 L³ ε_{r*-1}²/α²` (`3 ≤ r* ≤ L`, `I:eq:sec6_Nr_Mr_scaling`);
* `M_{r,max} ≤ 12000 L³ ε_{r-1}²/α²` and `√M_{r,max} ≤ 110 L^{3/2} ε_{r-1}/α` (`2 ≤ r ≤ L`,
  `I:eq:sec6_Mr_bound`);
* `M_{L,max} = 1 + N_{L,max} ≤ 8194 L³ ε_{L-1}²/α² ≤ 152 L³`, `√M_{L,max} ≤ 90.53 L^{3/2} ε_{L-1}/α`;
* `M_{2,max} ≤ 30 L³/α²` (`L:2153`).

Proof route (equivalent to the paper's): `ε_{s-1}² = (θ²)^{s-2}/400` with `θ = α^{1/(L-1)} = ρ⁻¹`,
`θ² < 0.31` (from `ρ > e^{3/5}`), the geometric series `∑_{s=r}^{L} (θ²)^{s-2} ≤ (θ²)^{r-2}/(1-θ²)`,
and the ceilings are absorbed using `L³ ε_{r-1}²/α² ≥ L³/400 ≥ L/16`.
-/

namespace F2e2e

namespace A

section Caps

variable {α : ℝ}

/-- `128 L ε²/γ² = 8192 L³ ε²/α²` (`γ = α/(8L)`). -/
lemma nmax_arg_eq (α : ℝ) (r : ℕ) :
    128 * (adaL α : ℝ) * adaEps α (r - 1) ^ 2 / adaGamma α ^ 2 =
      8192 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by
  unfold adaGamma
  rw [div_pow, div_div_eq_mul_div, mul_pow]
  ring

/-- `N_{r,max} < 8192 L³ ε_{r-1}²/α² + 1`. -/
lemma adaNmax_lt (α : ℝ) (r : ℕ) :
    (adaNmax α r : ℝ) < 8192 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 + 1 := by
  unfold adaNmax
  rw [nmax_arg_eq]
  apply Nat.ceil_lt_add_one
  positivity

/-- `T_{1,max} < 600/α² + 1`. -/
lemma adaT1max_lt (α : ℝ) : (adaT1max α : ℝ) < 600 / α ^ 2 + 1 := by
  unfold adaT1max
  apply Nat.ceil_lt_add_one
  positivity

/-- `ε_{s-1}² = (θ²)^{s-2}/400` for `s ≥ 2`. -/
lemma adaEps_pred_sq (hα : 0 < α) {s : ℕ} (hs : 2 ≤ s) :
    adaEps α (s - 1) ^ 2 = 1 / 400 * ((α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) ^ (s - 2) := by
  rw [adaEps_eq_pow hα (by omega : 1 ≤ s - 1), show s - 1 - 1 = s - 2 by omega]
  ring

/-- Geometric series: `∑_{s=r}^{n} q^{s-2} ≤ q^{r-2}/(1-q)` for `0 ≤ q < 1`, `r ≥ 2`. -/
lemma sum_Icc_pow_sub_two_le {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) {r n : ℕ} (hr : 2 ≤ r) :
    ∑ s ∈ Finset.Icc r n, q ^ (s - 2) ≤ q ^ (r - 2) / (1 - q) := by
  rw [← Finset.Ico_add_one_right_eq_Icc, Finset.sum_Ico_eq_sum_range]
  have h : ∀ k ∈ Finset.range (n + 1 - r), q ^ (r + k - 2) = q ^ (r - 2) * q ^ k := by
    intro k _
    rw [← pow_add]
    congr 1
    omega
  rw [Finset.sum_congr rfl h, ← Finset.mul_sum]
  have hg : ∑ k ∈ Finset.range (n + 1 - r), q ^ k ≤ 1 / (1 - q) := by
    have := geom_sum_Ico_le_of_lt_one (m := 0) (n := n + 1 - r) hq0 hq1
    rw [pow_zero] at this
    rwa [Finset.range_eq_Ico]
  calc q ^ (r - 2) * ∑ k ∈ Finset.range (n + 1 - r), q ^ k ≤ q ^ (r - 2) * (1 / (1 - q)) := by
        gcongr
    _ = q ^ (r - 2) / (1 - q) := by ring

/-- `∑_{s=r}^{L} ε_{s-1}² ≤ ε_{r-1}²/(1 - θ²)` for `r ≥ 2`. -/
lemma sum_adaEps_sq_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : 2 ≤ r) :
    ∑ s ∈ Finset.Icc r (adaL α), adaEps α (s - 1) ^ 2 ≤
      adaEps α (r - 1) ^ 2 / (1 - (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) := by
  have hq1 : (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 < 1 := by
    have := theta_sq_lt hα hα'
    linarith
  have hsum : ∑ s ∈ Finset.Icc r (adaL α), adaEps α (s - 1) ^ 2 =
      1 / 400 * ∑ s ∈ Finset.Icc r (adaL α), ((α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) ^ (s - 2) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro s hs
    exact adaEps_pred_sq hα (by have := (Finset.mem_Icc.mp hs).1; omega)
  rw [hsum, adaEps_pred_sq hα hr]
  have hg := sum_Icc_pow_sub_two_le (sq_nonneg (α ^ (1 / ((adaL α : ℝ) - 1)))) hq1 (n := adaL α) hr
  calc 1 / 400 * ∑ s ∈ Finset.Icc r (adaL α), ((α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) ^ (s - 2)
      ≤ 1 / 400 * (((α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) ^ (r - 2) /
          (1 - (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2)) := by gcongr
    _ = 1 / 400 * ((α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) ^ (r - 2) /
          (1 - (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2) := by ring

/-- `M_{r,max} = 1 + ∑_{s=r}^{L} N_{s,max}` (as reals) for `r ≠ 2`. -/
lemma adaMmax_cast_of_ne (α : ℝ) {r : ℕ} (hr : r ≠ 2) :
    (adaMmax α r : ℝ) = 1 + ∑ s ∈ Finset.Icc r (adaL α), (adaNmax α s : ℝ) := by
  unfold adaMmax
  rw [if_neg hr]
  push_cast
  ring

/-- `M_{2,max} = 1 + T_{1,max} + ∑_{s=3}^{L} N_{s,max}` (as reals). -/
lemma adaMmax_cast_two (α : ℝ) :
    (adaMmax α 2 : ℝ) =
      1 + (adaT1max α : ℝ) + ∑ s ∈ Finset.Icc 3 (adaL α), (adaNmax α s : ℝ) := by
  unfold adaMmax
  rw [if_pos rfl]
  push_cast
  ring

/-- `M_{L,max} = 1 + N_{L,max}`. -/
lemma adaMmax_L (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaMmax α (adaL α) : ℝ) = 1 + (adaNmax α (adaL α) : ℝ) := by
  have h5 := five_le_adaL hα hα'
  rw [adaMmax_cast_of_ne α (by omega), Finset.Icc_self, Finset.sum_singleton]

/-- `∑_{s=r}^{L} N_{s,max} ≤ (L + 1 - r) + (8192 L³/α²) ε_{r-1}²/(1-θ²)` for `r ≥ 2`. -/
lemma sum_adaNmax_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : 2 ≤ r) :
    ∑ s ∈ Finset.Icc r (adaL α), (adaNmax α s : ℝ) ≤
      ((adaL α + 1 - r : ℕ) : ℝ) + 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 *
        (adaEps α (r - 1) ^ 2 / (1 - (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2)) := by
  have hpt : ∀ s ∈ Finset.Icc r (adaL α), (adaNmax α s : ℝ) ≤
      1 + 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * adaEps α (s - 1) ^ 2 := by
    intro s _
    have h1 := adaNmax_lt α s
    have h2 : 8192 * (adaL α : ℝ) ^ 3 * adaEps α (s - 1) ^ 2 / α ^ 2 =
        8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * adaEps α (s - 1) ^ 2 := by ring
    linarith
  have hA : 0 ≤ 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 := by positivity
  calc ∑ s ∈ Finset.Icc r (adaL α), (adaNmax α s : ℝ)
      ≤ ∑ s ∈ Finset.Icc r (adaL α), (1 + 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * adaEps α (s - 1) ^ 2) :=
        Finset.sum_le_sum hpt
    _ = ((adaL α + 1 - r : ℕ) : ℝ) + 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 *
          ∑ s ∈ Finset.Icc r (adaL α), adaEps α (s - 1) ^ 2 := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const, Nat.card_Icc]
        simp
    _ ≤ ((adaL α + 1 - r : ℕ) : ℝ) + 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 *
          (adaEps α (r - 1) ^ 2 / (1 - (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2)) := by
        gcongr
        exact sum_adaEps_sq_le hα hα' hr

/-- `M_{r,max} ≤ 12000 L³ ε_{r-1}²/α²` for `2 ≤ r ≤ L` (`I:eq:sec6_Mr_bound`, `I:eq:sec6_Mr_geometric_sum`,
`I:eq:sec6_M2_geometric_bound`). -/
lemma adaMmax_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) :
    (adaMmax α r : ℝ) ≤ 12000 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by
  have hL5 := five_le_adaL_real hα hα'
  have hL5n := five_le_adaL hα hα'
  have hLpos := adaL_pos_real hα hα'
  have hq := theta_sq_lt hα hα'
  have hα2 : 0 < α ^ 2 := by positivity
  have hα2' : α ^ 2 < 1 / 256 := by
    have : α ^ 2 < (1 / 16) ^ 2 := by gcongr
    linarith
  rcases Nat.lt_or_ge r 3 with h | h
  · -- `r = 2`: `M_{2,max} = 1 + T_{1,max} + ∑_{s=3}^{L} N_{s,max}`
    have hr : r = 2 := by omega
    subst hr
    rw [adaMmax_cast_two, show (2 : ℕ) - 1 = 1 from rfl, adaEps_at_one]
    have hT := adaT1max_lt α
    have hS := sum_adaNmax_le hα hα' (r := 3) (by norm_num)
    rw [adaEps_pred_sq hα (s := 3) (by norm_num)] at hS
    have hc : ((adaL α + 1 - 3 : ℕ) : ℝ) = (adaL α : ℝ) - 2 := by
      rw [show adaL α + 1 - 3 = adaL α - 2 by omega, Nat.cast_sub (by omega)]
      push_cast
      ring
    rw [hc] at hS
    set q := (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 with hqdef
    have hq0 : 0 ≤ q := sq_nonneg _
    have hqq : 1 / 400 * q ^ (3 - 2) / (1 - q) ≤ 31 / 27600 := by
      rw [show (3 : ℕ) - 2 = 1 from rfl, pow_one, div_le_iff₀ (by linarith)]
      linarith
    set Y := (adaL α : ℝ) ^ 3 / α ^ 2 with hYdef
    have hY0 : 0 ≤ Y := by positivity
    have hS' : 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * (1 / 400 * q ^ (3 - 2) / (1 - q)) ≤
        8192 * (31 / 27600) * Y := by
      rw [hYdef, show 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * (1 / 400 * q ^ (3 - 2) / (1 - q)) =
        8192 * (1 / 400 * q ^ (3 - 2) / (1 - q)) * ((adaL α : ℝ) ^ 3 / α ^ 2) by ring]
      gcongr
    have hL3 : (125 : ℝ) ≤ (adaL α : ℝ) ^ 3 := by
      have := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 5) hL5 3
      norm_num at this
      linarith
    have hYL : 6400 * (adaL α : ℝ) ≤ Y := by
      rw [hYdef, le_div_iff₀ hα2]
      have hL2 : (25 : ℝ) ≤ (adaL α : ℝ) ^ 2 := by nlinarith
      have h1 : 25 * (adaL α : ℝ) ≤ (adaL α : ℝ) ^ 3 := by
        nlinarith [mul_le_mul_of_nonneg_left hL2 hLpos.le]
      have h2 : 6400 * (adaL α : ℝ) * α ^ 2 ≤ 6400 * (adaL α : ℝ) * (1 / 256) :=
        mul_le_mul_of_nonneg_left hα2'.le (by positivity)
      linarith
    have hY600 : 600 / α ^ 2 ≤ 4.8 * Y := by
      rw [hYdef, div_le_iff₀ hα2]
      have : 4.8 * ((adaL α : ℝ) ^ 3 / α ^ 2) * α ^ 2 = 4.8 * (adaL α : ℝ) ^ 3 := by
        field_simp
      rw [this]
      linarith
    have hgoal : 12000 * (adaL α : ℝ) ^ 3 * (1 / 20) ^ 2 / α ^ 2 = 30 * Y := by
      rw [hYdef]
      ring
    rw [hgoal]
    linarith
  · -- `3 ≤ r ≤ L`: geometric series from level `r`
    rw [adaMmax_cast_of_ne α (by omega)]
    have hS := sum_adaNmax_le hα hα' hr2
    have hc : ((adaL α + 1 - r : ℕ) : ℝ) ≤ (adaL α : ℝ) - 2 := by
      have h1 : adaL α + 1 - r ≤ adaL α - 2 := by omega
      have h2 : ((adaL α + 1 - r : ℕ) : ℝ) ≤ ((adaL α - 2 : ℕ) : ℝ) := by exact_mod_cast h1
      have h3 : ((adaL α - 2 : ℕ) : ℝ) = (adaL α : ℝ) - 2 := by
        rw [Nat.cast_sub (by omega)]
        push_cast
        ring
      rw [h3] at h2
      exact h2
    have hε := adaEps_gt_of_le hα hα' (r := r - 1) (by omega)
    have hE2 : α ^ 2 / 400 < adaEps α (r - 1) ^ 2 := by
      have h0 : 0 ≤ 1 / 20 * α := by positivity
      have := pow_lt_pow_left₀ hε h0 two_ne_zero
      nlinarith
    set E := adaEps α (r - 1) with hEdef
    set q := (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 with hqdef
    have hfrac : 1 / (1 - q) ≤ 100 / 69 := by
      rw [div_le_div_iff₀ (by linarith) (by norm_num)]
      linarith
    set Y := (adaL α : ℝ) ^ 3 * E ^ 2 / α ^ 2 with hYdef
    have hY : (adaL α : ℝ) ^ 3 / 400 ≤ Y := by
      rw [hYdef, div_le_div_iff₀ (by norm_num) hα2]
      have h3 : (0 : ℝ) < (adaL α : ℝ) ^ 3 := by positivity
      nlinarith
    have hLY : (adaL α : ℝ) ≤ 16 * Y := by
      have hL2 : (25 : ℝ) ≤ (adaL α : ℝ) ^ 2 := by nlinarith
      have h25 := mul_le_mul_of_nonneg_left hL2 hLpos.le
      have : (adaL α : ℝ) ≤ 16 * ((adaL α : ℝ) ^ 3 / 400) := by nlinarith
      linarith
    have hmain : 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * (E ^ 2 / (1 - q)) ≤ 8192 * (100 / 69) * Y := by
      rw [hYdef, show 8192 * (adaL α : ℝ) ^ 3 / α ^ 2 * (E ^ 2 / (1 - q)) =
        8192 * (1 / (1 - q)) * ((adaL α : ℝ) ^ 3 * E ^ 2 / α ^ 2) by ring]
      gcongr
    have hgoal : 12000 * (adaL α : ℝ) ^ 3 * E ^ 2 / α ^ 2 = 12000 * Y := by
      rw [hYdef]
      ring
    rw [hgoal]
    linarith

/-- `M_{2,max} ≤ 30 L³/α²` (`L:2153`). -/
lemma adaMmax_two_le (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaMmax α 2 : ℝ) ≤ 30 * (adaL α : ℝ) ^ 3 / α ^ 2 := by
  have h5 := five_le_adaL hα hα'
  have h := adaMmax_le hα hα' (r := 2) le_rfl (by omega)
  rw [show (2 : ℕ) - 1 = 1 from rfl, adaEps_at_one] at h
  calc (adaMmax α 2 : ℝ) ≤ 12000 * (adaL α : ℝ) ^ 3 * (1 / 20) ^ 2 / α ^ 2 := h
    _ = 30 * (adaL α : ℝ) ^ 3 / α ^ 2 := by ring

/-- `√M_{r,max} ≤ 110 L^{3/2} ε_{r-1}/α` for `2 ≤ r ≤ L` (`I:eq:sec6_Mr_bound`; `L^{3/2} = L √L`). -/
lemma sqrt_adaMmax_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) :
    Real.sqrt (adaMmax α r : ℝ) ≤
      110 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (r - 1) / α := by
  have hM := adaMmax_le hα hα' hr2 hrL
  have hE := adaEps_pos hα (r - 1)
  have hL := adaL_pos_real hα hα'
  rw [Real.sqrt_le_left (by positivity)]
  have hs : Real.sqrt (adaL α : ℝ) ^ 2 = (adaL α : ℝ) := Real.sq_sqrt hL.le
  calc (adaMmax α r : ℝ) ≤ 12000 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := hM
    _ ≤ 12100 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by gcongr; norm_num
    _ = (110 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (r - 1) / α) ^ 2 := by
        have : (110 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (r - 1) / α) ^ 2 =
            12100 * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) ^ 2 * adaEps α (r - 1) ^ 2 / α ^ 2 := by
          ring
        rw [this, hs]
        ring

/-- `L³ ε_{L-1}²/α² = L³ ρ²/400`. -/
lemma y_L_eq (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 =
      (adaL α : ℝ) ^ 3 * (α ^ (-(1 / ((adaL α : ℝ) - 1)))) ^ 2 / 400 := by
  rw [adaEps_L_sub_one hα hα']
  field_simp
  ring

/-- `ρ² > 3.2` (from `θ² < 0.31`). -/
lemma rho_sq_gt (hα : 0 < α) (hα' : α < 1 / 16) :
    (32 / 10 : ℝ) < (α ^ (-(1 / ((adaL α : ℝ) - 1)))) ^ 2 := by
  rw [rho_eq_inv_theta hα, inv_pow]
  have h1 := theta_sq_lt hα hα'
  have h0 : 0 < (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 := by
    have := theta_pos (α := α) hα
    positivity
  rw [lt_inv_comm₀ (by norm_num) h0]
  linarith

/-- `ρ² < 7.3890561` (from `ρ < e < 2.7182818286`). -/
lemma rho_sq_lt (hα : 0 < α) (hα' : α < 1 / 16) :
    (α ^ (-(1 / ((adaL α : ℝ) - 1)))) ^ 2 < 7.3890561 := by
  have h1 := rho_lt_e_d9 hα hα'
  have h0 := rho_pos (α := α) hα
  have : (α ^ (-(1 / ((adaL α : ℝ) - 1)))) ^ 2 < 2.7182818286 ^ 2 := by gcongr
  have h2 : (2.7182818286 : ℝ) ^ 2 < 7.3890561 := by norm_num
  linarith

/-- `L³ ε_{r-1}²/α² > 1` for `2 ≤ r ≤ L` (`L:2136`). -/
lemma one_lt_y (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) :
    1 < (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by
  have hL5 := five_le_adaL_real hα hα'
  have hL5n := five_le_adaL hα hα'
  have hα2 : 0 < α ^ 2 := by positivity
  have hyL : 1 < (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 := by
    rw [y_L_eq hα hα']
    have h1 := rho_sq_gt hα hα'
    have hL3 : (125 : ℝ) ≤ (adaL α : ℝ) ^ 3 := by
      have := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 5) hL5 3
      norm_num at this
      linarith
    nlinarith
  have hE : adaEps α (adaL α - 1) ≤ adaEps α (r - 1) := adaEps_le_of_le hα hα' (by omega)
  have hE0 := adaEps_pos hα (adaL α - 1)
  have hE2 : adaEps α (adaL α - 1) ^ 2 ≤ adaEps α (r - 1) ^ 2 := by gcongr
  calc (1 : ℝ) < (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 := hyL
    _ ≤ (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by gcongr

/-- `N_{r*,max} ≤ 8193 L³ ε_{r*-1}²/α²` for `3 ≤ r* ≤ L` (`I:eq:sec6_Nr_Mr_scaling`). -/
lemma adaNmax_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr3 : 3 ≤ r) (hrL : r ≤ adaL α) :
    (adaNmax α r : ℝ) ≤ 8193 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 := by
  have h1 := adaNmax_lt α r
  have h2 := one_lt_y hα hα' (r := r) (by omega) hrL
  have e1 : 8192 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 =
      8192 * ((adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2) := by ring
  have e2 : 8193 * (adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2 =
      8193 * ((adaL α : ℝ) ^ 3 * adaEps α (r - 1) ^ 2 / α ^ 2) := by ring
  rw [e1] at h1
  rw [e2]
  linarith

/-- `M_{L,max} = 1 + N_{L,max} ≤ 8194 L³ ε_{L-1}²/α²` (`L:2146`). -/
lemma adaMmax_L_le (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaMmax α (adaL α) : ℝ) ≤ 8194 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 := by
  have h5 := five_le_adaL hα hα'
  rw [adaMmax_L hα hα']
  have h1 := adaNmax_le hα hα' (r := adaL α) (by omega) le_rfl
  have h2 := one_lt_y hα hα' (r := adaL α) (by omega) le_rfl
  have e1 : 8193 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 =
      8193 * ((adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2) := by ring
  have e2 : 8194 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 =
      8194 * ((adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2) := by ring
  rw [e1] at h1
  rw [e2]
  linarith

/-- `M_{L,max} ≤ 152 L³` (`L:2114`). -/
lemma adaMmax_L_le_cube (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaMmax α (adaL α) : ℝ) ≤ 152 * (adaL α : ℝ) ^ 3 := by
  have h1 := adaMmax_L_le hα hα'
  have e : 8194 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 =
      8194 * ((adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2) := by ring
  rw [e, y_L_eq hα hα'] at h1
  have h2 := rho_sq_lt hα hα'
  have hL3 : (0 : ℝ) ≤ (adaL α : ℝ) ^ 3 := by positivity
  nlinarith

/-- `√M_{L,max} ≤ 90.53 L^{3/2} ε_{L-1}/α` (`L:2146`). -/
lemma sqrt_adaMmax_L_le (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.sqrt (adaMmax α (adaL α) : ℝ) ≤
      90.53 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (adaL α - 1) / α := by
  have hM := adaMmax_L_le hα hα'
  have hE := adaEps_pos hα (adaL α - 1)
  have hL := adaL_pos_real hα hα'
  rw [Real.sqrt_le_left (by positivity)]
  have hs : Real.sqrt (adaL α : ℝ) ^ 2 = (adaL α : ℝ) := Real.sq_sqrt hL.le
  calc (adaMmax α (adaL α) : ℝ) ≤ 8194 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 := hM
    _ ≤ 90.53 ^ 2 * (adaL α : ℝ) ^ 3 * adaEps α (adaL α - 1) ^ 2 / α ^ 2 := by gcongr; norm_num
    _ = (90.53 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (adaL α - 1) / α) ^ 2 := by
        have : (90.53 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * adaEps α (adaL α - 1) / α) ^ 2 =
            90.53 ^ 2 * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) ^ 2 *
              adaEps α (adaL α - 1) ^ 2 / α ^ 2 := by
          ring
        rw [this, hs]
        ring

end Caps

end A

end F2e2e
