import F2e2e.A.SimEpisode2
import F2e2e.A.ArchTheta

/-!
# Public data of a validator episode (Prop. `I:prop:svt_episode_pure_dp`, the post-processing part)

Paper: `parts/partI.tex` L887-957 (Prop. `I:prop:svt_episode_pure_dp`, "conditioned on the public transcript prior to
episode `e`"): along the forced continuation of an episode of stage `r` (stage `r` forced to fire at a given test
with a given release value), everything is public, i.e. the same for two samples whose block `r` are neighbours,
except the stage-`r` weighted means `θ^{(r)}` (`passTheta`) and the AboveThreshold query values built from them
(`passF`), which move by at most `Δ_r` (`I:eq:theta_r_sensitivity`).

Statements `measurable_epOutF` and `episode_public` fixed by A-VAL (914e80f8) for `svt_episode_pure_dp`
(F2e2e/A/Validators.lean).

## Proof
* `PubEq r st₁ st₂`: HALT, `t₁`, `N`, `M` and the payoffs of the levels `t ≠ r` agree. `PayForm`: the payoff of
  level `r` is `ℓ ↦ g(X_{r,ℓ})` for one public `g` (Lemma `I:lem:kkt_sensitivity`'s coordinate payoffs).
* Replaying the same records gives `PubEq` states (`replay_pub`) with `PayForm` (`replay_pay_eq`); a forced step
  from `PubEq` states with the same records gives the same record (`stepF_rec_congr`: the forced record only reads
  the stages `t ≠ r`) and `PubEq`/`PayForm` successors (`stepF_pub`); by induction along `contRunF`
  (`contRunF_pub`) the records agree, hence `epOutF`, the number of tests `passT` and the origins of stage `r`
  agree, and `θ^{(r)}` moves by at most `Δ_r` (`theta_sens_of_payForm`, via `Opt.waterFill_neighbor_query` and
  `Opt.anchor_sensitivity`).
* Measurability: forcing preserves measurable families of chain data (`measFamily_force`), so a forced step is
  measurable (`measurable_stepF`), hence the forced run in the release value (`measurable_contRunF`); the episode
  output index is countable (`measurable_from_prod_countable_right`).
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

section Pub

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- Entries of block `t ≠ r` are not changed by `replaceBlock r`. -/
theorem replaceBlock_blockIdx_ne {r t : ℕ} (htr : t ≠ r) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (ℓ : Fin (adaBlock k α β t)) :
    replaceBlock k α β r Sr S (adaBlockIdx k α β t ℓ) = S (adaBlockIdx k α β t ℓ) := by
  apply replaceBlock_of_not_mem
  rintro ⟨h1, h2⟩
  have hidx : adaBlockIdx k α β r ⟨(adaBlockIdx k α β t ℓ).val - adaOffset k α β r, by omega⟩ =
      adaBlockIdx k α β t ℓ := by
    ext
    simp only [adaBlockIdx_val] at h1 h2 ⊢
    omega
  exact htr (adaBlockIdx_inj k α β _ _ hidx).1.symm

theorem qOf_blockIdx_ne (A : DetAnalyst X) {r t : ℕ} (htr : t ≠ r) (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (h : Fin k → RoundRec) (i : ℕ) (ℓ : Fin (adaBlock k α β t)) :
    qOf A (replaceBlock k α β r Sr S) h i (adaBlockIdx k α β t ℓ) =
      qOf A (replaceBlock k α β r Sr' S) h i (adaBlockIdx k α β t ℓ) := by
  simp only [qOf, replaceBlock_blockIdx_ne htr]

theorem qOf_blockIdx_self (A : DetAnalyst X) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (h : Fin k → RoundRec) (i : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    qOf A (replaceBlock k α β r Sr S) h i (adaBlockIdx k α β r ℓ) = A i (histAns h i) (Sr ℓ) := by
  simp only [qOf, replaceBlock_blockIdx]

/-- Two states agree on everything public for stage `r`: HALT, the counters, the episode counters and the payoffs
of the levels `t ≠ r`. -/
structure PubEq (r : ℕ) (st₁ st₂ : MState k α β) : Prop where
  halt : st₁.halt = st₂.halt
  t1 : st₁.t1 = st₂.t1
  N : st₁.N = st₂.N
  M : st₁.M = st₂.M
  pay : ∀ t, t ≠ r → st₁.pay t = st₂.pay t

/-- The payoffs of level `r` of two states are the coordinate payoffs `ℓ ↦ g(X_{r,ℓ})` of the two blocks, for one
public `g`. -/
def PayForm (r : ℕ) (Sr Sr' : Fin (adaBlock k α β r) → X) (st₁ st₂ : MState k α β) : Prop :=
  ∃ g : X → ℝ, st₁.pay r = (fun ℓ => g (Sr ℓ)) ∧ st₂.pay r = fun ℓ => g (Sr' ℓ)

theorem theta_pub (A : DetAnalyst X) {r t : ℕ} (htr : t ≠ r) {st₁ st₂ : MState k α β} (hp : PubEq r st₁ st₂)
    (Sr Sr' : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X) (h : Fin k → RoundRec) (i : ℕ) :
    st₁.theta (qOf A (replaceBlock k α β r Sr S) h i) t =
      st₂.theta (qOf A (replaceBlock k α β r Sr' S) h i) t := by
  unfold MState.theta MState.weight
  rw [hp.pay t htr]
  refine Finset.sum_congr rfl fun ℓ _ => ?_
  rw [qOf_blockIdx_ne A htr Sr Sr' S h i ℓ]

theorem next_pub (A : DetAnalyst X) {r : ℕ} {st₁ st₂ : MState k α β} (hp : PubEq r st₁ st₂)
    (Sr Sr' : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X) (h : Fin k → RoundRec) (i : ℕ)
    (rec : RoundRec) :
    PubEq r (st₁.next (qOf A (replaceBlock k α β r Sr S) h i) rec)
      (st₂.next (qOf A (replaceBlock k α β r Sr' S) h i) rec) where
  halt := by simp only [MState.next, hp.t1, hp.N]
  t1 := by simp only [MState.next, hp.t1]
  N := by simp only [MState.next, hp.N]
  M := by simp only [MState.next, hp.M]
  pay t ht := by
    funext ℓ
    simp only [MState.next, hp.pay t ht, qOf_blockIdx_ne A ht Sr Sr' S h i ℓ]

theorem next_payForm (A : DetAnalyst X) {r : ℕ} (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) {st₁ st₂ : MState k α β} (hf : PayForm r Sr Sr' st₁ st₂)
    (h : Fin k → RoundRec) (i : ℕ) (rec : RoundRec) :
    PayForm r Sr Sr' (st₁.next (qOf A (replaceBlock k α β r Sr S) h i) rec)
      (st₂.next (qOf A (replaceBlock k α β r Sr' S) h i) rec) := by
  obtain ⟨g, h1, h2⟩ := hf
  refine ⟨fun x => g x + rec.delta r * A i (histAns h i) x, ?_, ?_⟩
  · funext ℓ
    show st₁.pay r ℓ + rec.delta r * qOf A (replaceBlock k α β r Sr S) h i (adaBlockIdx k α β r ℓ) = _
    rw [h1, qOf_blockIdx_self]
  · funext ℓ
    show st₂.pay r ℓ + rec.delta r * qOf A (replaceBlock k α β r Sr' S) h i (adaBlockIdx k α β r ℓ) = _
    rw [h2, qOf_blockIdx_self]

/-- A forced step from `PubEq` states with the same records gives the same record and `PubEq`, `PayForm`
successors. -/
theorem stepF_pub (A : DetAnalyst X) {r : ℕ} (hr2 : 2 ≤ r) (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) {st₁ st₂ : MState k α β} (hp : PubEq r st₁ st₂)
    (hf : PayForm r Sr Sr' st₁ st₂) (h : Fin k → RoundRec) (i : ℕ) (ω' : AdaOmega k α) (b : Bool) (v : ℝ) :
    (stepF r st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω' b v).2 =
        (stepF r st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω' b v).2 ∧
      PubEq r (stepF r st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω' b v).1
        (stepF r st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω' b v).1 ∧
      PayForm r Sr Sr' (stepF r st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω' b v).1
        (stepF r st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω' b v).1 := by
  have h1r : (1 : ℕ) ≠ r := by omega
  have hrec : (stepF r st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω' b v).2 =
      (stepF r st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω' b v).2 := by
    refine stepF_rec_congr r i b v hp.halt ?_ (fun t ht => theta_pub A ht hp Sr Sr' S h i)
      (fun t _ => ?_) (fun t _ => rfl) (fun t _ => rfl)
    · show clip01 (stage1Release st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω') =
        clip01 (stage1Release st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω')
      unfold stage1Release
      rw [theta_pub A h1r hp Sr Sr' S h i]
    · show noiseRho ω' t (st₁.M t - 1) = noiseRho ω' t (st₂.M t - 1)
      rw [hp.M]
  refine ⟨hrec, ?_⟩
  cases hh : st₁.halt
  · have hh2 : st₂.halt = false := hp.halt ▸ hh
    rw [stepF_of_not_halt r hh, stepF_of_not_halt r hh2] at hrec ⊢
    simp only at hrec ⊢
    rw [hrec]
    exact ⟨next_pub A hp Sr Sr' S h i _, next_payForm A Sr Sr' S hf h i _⟩
  · have hh2 : st₂.halt = true := hp.halt ▸ hh
    rw [stepF_of_halt r hh, stepF_of_halt r hh2]
    exact ⟨hp, hf⟩

/-- **Along the forced run** from `PubEq`, `PayForm` states with the same records, the records agree and the states
stay `PubEq`, `PayForm`. -/
theorem contRunF_pub (A : DetAnalyst X) {r : ℕ} (hr2 : 2 ≤ r) (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) (s : ℕ) {st₁ st₂ : MState k α β}
    (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) (hp : PubEq r st₁ st₂) (hf : PayForm r Sr Sr' st₁ st₂) (t : ℕ) :
    (contRunF A (replaceBlock k α β r Sr S) ω' r s st₁ h₀ m v t).2 =
        (contRunF A (replaceBlock k α β r Sr' S) ω' r s st₂ h₀ m v t).2 ∧
      PubEq r (contRunF A (replaceBlock k α β r Sr S) ω' r s st₁ h₀ m v t).1
        (contRunF A (replaceBlock k α β r Sr' S) ω' r s st₂ h₀ m v t).1 ∧
      PayForm r Sr Sr' (contRunF A (replaceBlock k α β r Sr S) ω' r s st₁ h₀ m v t).1
        (contRunF A (replaceBlock k α β r Sr' S) ω' r s st₂ h₀ m v t).1 := by
  induction t with
  | zero => exact ⟨rfl, hp, hf⟩
  | succ t ih =>
    obtain ⟨h1, h2, h3⟩ := ih
    rw [contRunF_succ, contRunF_succ]
    unfold contStepF
    dsimp only
    rw [← h1]
    obtain ⟨hrec, hpub, hpf⟩ := stepF_pub A hr2 Sr Sr' S h2 h3
      (contRunF A (replaceBlock k α β r Sr S) ω' r s st₁ h₀ m v t).2 (s + t) ω' (decide (t = m)) v
    exact ⟨by rw [hrec], hpub, hpf⟩

theorem replay_pub (A : DetAnalyst X) {r : ℕ} (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (h₀ : Fin k → RoundRec) (n : ℕ) :
    PubEq r (replay A (replaceBlock k α β r Sr S) h₀ n) (replay A (replaceBlock k α β r Sr' S) h₀ n) := by
  induction n with
  | zero => exact ⟨rfl, rfl, rfl, rfl, fun _ _ => rfl⟩
  | succ n ih =>
    rw [replay_succ, replay_succ]
    split_ifs
    · exact next_pub A ih Sr Sr' S h₀ n (recAt h₀ n)
    · exact ih

theorem epStart_pub (A : DetAnalyst X) {r : ℕ} (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (e : ℕ) (h₀ : Fin k → RoundRec) (s : ℕ) :
    PubEq r (epStart A (replaceBlock k α β r Sr S) r e h₀ s)
      (epStart A (replaceBlock k α β r Sr' S) r e h₀ s) := by
  have hp := replay_pub A Sr Sr' S h₀ s
  refine ⟨hp.halt, hp.t1, hp.N, ?_, hp.pay⟩
  show Function.update (replay A (replaceBlock k α β r Sr S) h₀ s).M r (e + 1) =
    Function.update (replay A (replaceBlock k α β r Sr' S) h₀ s).M r (e + 1)
  rw [hp.M]

theorem epStart_payForm (A : DetAnalyst X) (r : ℕ) (Sr Sr' : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (e : ℕ) (h₀ : Fin k → RoundRec) (s : ℕ) :
    PayForm r Sr Sr' (epStart A (replaceBlock k α β r Sr S) r e h₀ s)
      (epStart A (replaceBlock k α β r Sr' S) r e h₀ s) :=
  ⟨fun x => ∑ u ∈ Finset.range s, replayCoef h₀ r u * A u (histAns h₀ u) x,
    replay_pay_eq A r Sr S h₀ s, replay_pay_eq A r Sr' S h₀ s⟩

/-- **Sensitivity of `θ^{(r)}`** for states whose level-`r` payoffs are coordinate payoffs of neighbouring blocks. -/
theorem theta_sens_of_payForm (A : DetAnalyst X) (hA : A.Valid) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α)
    (Sr Sr' : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X) (hN : DP.Neighbor Sr Sr')
    {st₁ st₂ : MState k α β} (hf : PayForm r Sr Sr' st₁ st₂) (h : Fin k → RoundRec) (i : ℕ) :
    |st₁.theta (qOf A (replaceBlock k α β r Sr S) h i) r -
      st₂.theta (qOf A (replaceBlock k α β r Sr' S) h i) r| ≤ adaSens k α β r := by
  obtain ⟨g, h1, h2⟩ := hf
  have hq : ∀ x, A i (histAns h i) x ∈ Set.Icc (0 : ℝ) 1 := fun x => ⟨(hA _ _ _).1, (hA _ _ _).2⟩
  have hth : ∀ (st : MState k α β) (T : Fin (adaBlock k α β r) → X),
      st.theta (qOf A (replaceBlock k α β r T S) h i) r =
        ∑ ℓ, st.weight r ℓ * A i (histAns h i) (T ℓ) := by
    intro st T
    unfold MState.theta
    refine Finset.sum_congr rfl fun ℓ _ => ?_
    rw [qOf_blockIdx_self]
  rw [hth, hth]
  rcases lt_or_eq_of_le hrL with hlt | heq
  · have hne : r ≠ adaL α := hlt.ne
    unfold MState.weight
    rw [if_neg hne, if_neg hne, h1, h2]
    have hb := Opt.waterFill_neighbor_query (n := adaBlock k α β r) 1 g (A i (histAns h i)) hq hN
    have e : (adaBlock k α β r : ℝ) = (adaNr k α β r : ℝ) := by rw [adaBlock_mid k α β hr2 hlt]
    have hs : adaSens k α β r = 4 / (adaNr k α β r : ℝ) := by
      unfold adaSens
      rw [if_neg hne]
    rw [hs, ← e]
    exact hb
  · subst heq
    have hw : ∀ (st : MState k α β) (T : Fin (adaBlock k α β (adaL α)) → X),
        ∑ ℓ, st.weight (adaL α) ℓ * A i (histAns h i) (T ℓ) =
          (∑ ℓ, A i (histAns h i) (T ℓ)) / (adaBlock k α β (adaL α) : ℝ) := by
      intro st T
      unfold MState.weight
      rw [if_pos rfl, Finset.sum_div]
      refine Finset.sum_congr rfl fun ℓ _ => ?_
      ring
    rw [hw, hw]
    have hb := Opt.anchor_sensitivity (A i (histAns h i)) hq hN
    have e : (adaBlock k α β (adaL α) : ℝ) = (adaNL k α β : ℝ) := by rw [adaBlock_L]
    have hs : adaSens k α β (adaL α) = 1 / (adaNL k α β : ℝ) := by
      unfold adaSens
      rw [if_pos rfl]
    rw [hs, ← e]
    exact hb

/-- The chain data of two `PubEq` states (same records) agree at stage `r`'s origin. -/
theorem roundChain_orig_pub (A : DetAnalyst X) {r : ℕ} (hr2 : 2 ≤ r) {st₁ st₂ : MState k α β}
    (hp : PubEq r st₁ st₂) (Sr Sr' : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X)
    (h : Fin k → RoundRec) (i : ℕ) (ω' : AdaOmega k α) :
    (roundChain st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω').orig r =
      (roundChain st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω').orig r := by
  have h1r : (1 : ℕ) ≠ r := by omega
  have hc1 : (roundChain st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω').c1 =
      (roundChain st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω').c1 := by
    show clip01 (stage1Release st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω') =
      clip01 (stage1Release st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω')
    unfold stage1Release
    rw [theta_pub A h1r hp Sr Sr' S h i]
  refine ChainData.orig_congr_sim (d₁ := roundChain st₁ i (qOf A (replaceBlock k α β r Sr S) h i) ω')
    (d₂ := roundChain st₂ i (qOf A (replaceBlock k α β r Sr' S) h i) ω') rfl hc1 fun t ht => ?_
  have htr : t ≠ r := by omega
  have hth := theta_pub A htr hp Sr Sr' S h i
  have hrho : noiseRho ω' t (st₁.M t - 1) = noiseRho ω' t (st₂.M t - 1) := by rw [hp.M]
  constructor
  · show adaTau α _ t + noiseRho ω' t (st₁.M t - 1) ≤
        |_ - st₁.theta (qOf A (replaceBlock k α β r Sr S) h i) t| + noiseNu ω' i t ↔
      adaTau α _ t + noiseRho ω' t (st₂.M t - 1) ≤
        |_ - st₂.theta (qOf A (replaceBlock k α β r Sr' S) h i) t| + noiseNu ω' i t
    rw [hth, hrho]
  · show clip01 (st₁.theta (qOf A (replaceBlock k α β r Sr S) h i) t + noiseZeta ω' i t) =
      clip01 (st₂.theta (qOf A (replaceBlock k α β r Sr' S) h i) t + noiseZeta ω' i t)
    rw [hth]

end Pub

theorem episode_public {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ} (A : DetAnalyst X) (hA : A.Valid)
    (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) (ω' : AdaOmega k α) (e : ℕ)
    (y : Fin e → EpRec k) {Sr Sr' : Fin (adaBlock k α β r) → X} (hN : DP.Neighbor Sr Sr') :
    passT A (replaceBlock k α β r Sr S) r ω' e y = passT A (replaceBlock k α β r Sr' S) r ω' e y ∧
    (∀ j, |passF A (replaceBlock k α β r Sr S) r ω' e y j - passF A (replaceBlock k α β r Sr' S) r ω' e y j| ≤
      adaSens k α β r) ∧
    (∀ t, |passTheta A (replaceBlock k α β r Sr S) r ω' e y t -
      passTheta A (replaceBlock k α β r Sr' S) r ω' e y t| ≤ adaSens k α β r) ∧
    (∀ m v, epOutF A (replaceBlock k α β r Sr S) r ω' e y m v =
      epOutF A (replaceBlock k α β r Sr' S) r ω' e y m v) := by
  -- the forced runs from the two episode starts
  have hrun : ∀ (m : ℕ) (v : ℝ) (t : ℕ),
      (contRunF A (replaceBlock k α β r Sr S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr S) r e (epPick e y) (epCover y)) (epPick e y) m v t).2 =
        (contRunF A (replaceBlock k α β r Sr' S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr' S) r e (epPick e y) (epCover y)) (epPick e y) m v t).2 ∧
      PubEq r (contRunF A (replaceBlock k α β r Sr S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr S) r e (epPick e y) (epCover y)) (epPick e y) m v t).1
        (contRunF A (replaceBlock k α β r Sr' S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr' S) r e (epPick e y) (epCover y)) (epPick e y) m v t).1 ∧
      PayForm r Sr Sr' (contRunF A (replaceBlock k α β r Sr S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr S) r e (epPick e y) (epCover y)) (epPick e y) m v t).1
        (contRunF A (replaceBlock k α β r Sr' S) ω' r (epCover y)
          (epStart A (replaceBlock k α β r Sr' S) r e (epPick e y) (epCover y)) (epPick e y) m v t).1 :=
    fun m v t => contRunF_pub A hr2 Sr Sr' S ω' (epCover y) (epPick e y) m v
      (epStart_pub A Sr Sr' S e (epPick e y) (epCover y))
      (epStart_payForm A r Sr Sr' S e (epPick e y) (epCover y)) t
  -- the all-pass run
  have hpass : ∀ t, (passRun A (replaceBlock k α β r Sr S) r ω' e y t).2 =
        (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).2 ∧
      PubEq r (passRun A (replaceBlock k α β r Sr S) r ω' e y t).1
        (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).1 ∧
      PayForm r Sr Sr' (passRun A (replaceBlock k α β r Sr S) r ω' e y t).1
        (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).1 :=
    fun t => hrun k 0 t
  -- θ along the all-pass run
  have htheta : ∀ t, |passTheta A (replaceBlock k α β r Sr S) r ω' e y t -
      passTheta A (replaceBlock k α β r Sr' S) r ω' e y t| ≤ adaSens k α β r := by
    intro t
    obtain ⟨h1, _, h3⟩ := hpass t
    show |(passRun A (replaceBlock k α β r Sr S) r ω' e y t).1.theta
        (qOf A (replaceBlock k α β r Sr S) (passRun A (replaceBlock k α β r Sr S) r ω' e y t).2
          (epCover y + t)) r -
      (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).1.theta
        (qOf A (replaceBlock k α β r Sr' S) (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).2
          (epCover y + t)) r| ≤ adaSens k α β r
    rw [← h1]
    exact theta_sens_of_payForm A hA hr2 hrL Sr Sr' S hN h3 _ _
  refine ⟨?_, fun j => ?_, htheta, fun m v => ?_⟩
  · -- the number of tests only depends on HALT and the episode counters
    have hh : ∀ t, (passRun A (replaceBlock k α β r Sr S) r ω' e y t).1.halt =
        (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).1.halt := fun t => (hpass t).2.1.halt
    have hM : ∀ t, (passRun A (replaceBlock k α β r Sr S) r ω' e y t).1.M =
        (passRun A (replaceBlock k α β r Sr' S) r ω' e y t).1.M := fun t => (hpass t).2.1.M
    unfold passT PassActive
    simp only [hh, hM]
    congr
  · -- the query values: same origin, `θ` moves by at most `Δ_r`
    obtain ⟨h1, h2, _⟩ := hpass j
    have hor : (passChain A (replaceBlock k α β r Sr S) r ω' e y j).orig r =
        (passChain A (replaceBlock k α β r Sr' S) r ω' e y j).orig r := by
      unfold passChain
      rw [← h1]
      exact roundChain_orig_pub A hr2 h2 Sr Sr' S _ _ ω'
    unfold passF
    rw [hor]
    have ht := htheta j
    have hab := abs_abs_sub_abs_le_abs_sub
      (((passChain A (replaceBlock k α β r Sr' S) r ω' e y j).orig r).2 -
        passTheta A (replaceBlock k α β r Sr S) r ω' e y j)
      (((passChain A (replaceBlock k α β r Sr' S) r ω' e y j).orig r).2 -
        passTheta A (replaceBlock k α β r Sr' S) r ω' e y j)
    have e2 : (((passChain A (replaceBlock k α β r Sr' S) r ω' e y j).orig r).2 -
          passTheta A (replaceBlock k α β r Sr S) r ω' e y j) -
        (((passChain A (replaceBlock k α β r Sr' S) r ω' e y j).orig r).2 -
          passTheta A (replaceBlock k α β r Sr' S) r ω' e y j) =
        -(passTheta A (replaceBlock k α β r Sr S) r ω' e y j -
          passTheta A (replaceBlock k α β r Sr' S) r ω' e y j) := by ring
    rw [e2, abs_neg] at hab
    refine le_trans (le_of_eq ?_) (hab.trans ht)
    congr 1
    ring
  · -- the forced episode: same records
    unfold epOutF
    rw [(hrun m v (k - epCover y)).1]

/-! ## Measurability of the forced episode -/

section Meas

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

theorem measFamily_comp {P Q : Type*} [MeasurableSpace P] [MeasurableSpace Q] {d : P → ChainData} {L : ℕ}
    {tau : ℕ → ℕ → ℝ} (hd : ChainData.MeasFamily d L tau) {f : Q → P} (hf : Measurable f) :
    ChainData.MeasFamily (fun q => d (f q)) L tau where
  hL q := hd.hL (f q)
  htau q := hd.htau (f q)
  hc1 := hd.hc1.comp hf
  htheta s := (hd.htheta s).comp hf
  hrho s := (hd.hrho s).comp hf
  hnu s := (hd.hnu s).comp hf
  hzeta s := (hd.hzeta s).comp hf

/-- Forcing stage `r` (outcome `b`, measurable release value `v`) preserves measurable families. -/
theorem measFamily_force {P : Type*} [MeasurableSpace P] {d : P → ChainData} {L : ℕ} {tau : ℕ → ℕ → ℝ}
    (hd : ChainData.MeasFamily d L tau) (r : ℕ) (b : Bool) {v : P → ℝ} (hv : Measurable v) :
    ChainData.MeasFamily (fun p => (d p).force r b (v p)) L tau where
  hL p := hd.hL p
  htau p := hd.htau p
  hc1 := hd.hc1
  htheta s := hd.htheta s
  hrho s := by
    show Measurable fun p => Function.update (d p).rho r 0 s
    by_cases hs : s = r
    · subst hs
      simp only [Function.update_self]
      exact measurable_const
    · simp only [Function.update_of_ne hs]
      exact hd.hrho s
  hnu s := by
    show Measurable fun p => Function.update (d p).nu r
      ((d p).tau ((d p).orig r).1 r - |((d p).orig r).2 - (d p).theta r| - (if b then 0 else 1)) s
    by_cases hs : s = r
    · subst hs
      simp only [Function.update_self, hd.htau]
      have h1 : Measurable fun p => tau ((d p).orig s).1 s :=
        (measurable_from_nat (f := fun n => tau n s)).comp (measurable_fst.comp (hd.measurable_orig s))
      exact (h1.sub (continuous_abs.measurable.comp
        ((measurable_snd.comp (hd.measurable_orig s)).sub (hd.htheta s)))).sub measurable_const
    · simp only [Function.update_of_ne hs]
      exact hd.hnu s
  hzeta s := by
    show Measurable fun p => Function.update (d p).zeta r (v p - (d p).theta r) s
    by_cases hs : s = r
    · subst hs
      simp only [Function.update_self]
      exact hv.sub (hd.htheta s)
    · simp only [Function.update_of_ne hs]
      exact hd.hzeta s

theorem measurable_stepF (r i : ℕ) (ω' : AdaOmega k α) (b : Bool) :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ =>
      stepF r p.1 i p.2.1 ω' b p.2.2 := by
  have hfam : ChainData.MeasFamily
      (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ =>
        (roundChain p.1 i p.2.1 ω').force r b p.2.2) (adaL α) (adaTau α) :=
    measFamily_force (measFamily_comp (measFamily_roundChain i)
      (f := fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ => (p.1, p.2.1, ω'))
      (measurable_fst.prodMk ((measurable_fst.comp measurable_snd).prodMk measurable_const))) r b
      (measurable_snd.comp measurable_snd)
  have hrec := hfam.measurable_toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)
  unfold stepF
  refine Measurable.ite ?_ (measurable_fst.prodMk measurable_const) ?_
  · exact (MState.measurable_halt.comp measurable_fst) (measurableSet_singleton true)
  · exact (measurable_next.comp (measurable_fst.prodMk ((measurable_fst.comp measurable_snd).prodMk
      hrec))).prodMk hrec

theorem measurable_contRunF (A : DetAnalyst X) (hAm : A.JointlyMeasurable) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m t : ℕ) :
    Measurable fun v : ℝ => contRunF A S ω' r s st₀ h₀ m v t := by
  induction t with
  | zero => exact measurable_const
  | succ t ih =>
    have hst := measurable_stepF (k := k) (α := α) (β := β) r (s + t) ω' (decide (t = m))
    have hq := measurable_qOf hAm S (s + t)
    have hin : Measurable fun v : ℝ => ((contRunF A S ω' r s st₀ h₀ m v t).1,
        qOf A S (contRunF A S ω' r s st₀ h₀ m v t).2 (s + t), v) :=
      (measurable_fst.comp ih).prodMk ((hq.comp (measurable_snd.comp ih)).prodMk measurable_id)
    have hstep := hst.comp hin
    have key : (fun v : ℝ => contRunF A S ω' r s st₀ h₀ m v (t + 1)) = fun v =>
        ((stepF r (contRunF A S ω' r s st₀ h₀ m v t).1 (s + t)
            (qOf A S (contRunF A S ω' r s st₀ h₀ m v t).2 (s + t)) ω' (decide (t = m)) v).1,
          setRec (contRunF A S ω' r s st₀ h₀ m v t).2 (s + t)
            (stepF r (contRunF A S ω' r s st₀ h₀ m v t).1 (s + t)
              (qOf A S (contRunF A S ω' r s st₀ h₀ m v t).2 (s + t)) ω' (decide (t = m)) v).2) := rfl
    rw [key]
    exact (measurable_fst.comp hstep).prodMk
      ((measurable_setRec (s + t)).comp ((measurable_snd.comp ih).prodMk (measurable_snd.comp hstep)))

end Meas

theorem measurable_epOutF {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ} (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) (S : Fin (adaSampleSize k α β) → X) (r : ℕ) (ω' : AdaOmega k α) (e : ℕ)
    (y : Fin e → EpRec k) :
    Measurable (fun p : ℕ × ℝ => epOutF A S r ω' e y p.1 p.2) := by
  refine measurable_from_prod_countable_right (fun m => ?_)
  show Measurable fun v => epMask r (epCover y)
    (contRunF A S ω' r (epCover y) (epStart A S r e (epPick e y) (epCover y)) (epPick e y) m v
      (k - epCover y)).2
  exact (measurable_epMask r (epCover y)).comp
    (measurable_snd.comp (measurable_contRunF A hAm S ω' r (epCover y) _ _ m _))

end A

end F2e2e
