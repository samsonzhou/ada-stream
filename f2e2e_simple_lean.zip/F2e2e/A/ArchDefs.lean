import F2e2e.A.Mechanism

/-!
# Part I: shared analysis definitions (transcript functionals, events, stage laws)

Owner: A-ARCH. Every Part I analysis file uses these definitions; they are kept stable.

Paper: `parts/partI.tex` Lemma `I:lem:tonelli_fubini`(ii) (L82-86: `q_i = A_i(h_{<i})`,
`μ_i(h_{<i}) = ∫ A_i(h_{<i}) dD`), Remark `I:rem:halt_round_completion` (`I:eq:ehalt_def`, L412-414),
Proposition `I:prop:clean_event_bound` (L1109-1130: `E_anc`, `E_lap`, `E_clean`), Definition `I:def:prog_m`
(L1335-1350), and the conditioning convention of §3 (L803: "conditionally on all other subsamples and their
internal randomness").

Throughout, `D` is a probability distribution on `X` and `A` a deterministic analyst (Lemma
`I:lem:tonelli_fubini` reduces the theorem to this case), `S : Fin n → X` the sample (`n = adaSampleSize`),
`ω : AdaOmega k α` the mechanism's noise, `h = transcript k α β A S ω : Fin k → RoundRec`.

## Definitions
* `adaProb k α β D = D^n ⊗ P_M`: the probability space of the analysis.
* `histAns h i`, `qry A h i = A_i(a_0, …, a_{i-1})`, `popMu D A h i = μ_i(h) = ∫ q_i dD`.
* `onlineQ`, `onlineState`, `onlineChain`: the query values, start-of-round state and chain data of round `i`
  of the interaction.
* `finalT1 h = t₁`, `finalN h r = N_r` (final counters, read off the records), `EHalt α h = E_halt(h)`.
* `blockOf r S = S_r`, `anchorMean S q = θ^{(L)}(S_L) = (1/n_L) ∑_ℓ q(X_{L,ℓ})`.
* `EAnc`, `lapOK`, `ELap`, `EClean`: the clean event `E_clean = E_anc ∩ E_lap` (with `E_lap` = every Laplace
  entry of the noise table is small: `|ρ|, |ζ| ≤ u₀`, `|ν| ≤ 2u₀`; a superset of the paper's "every drawn
  noise", same union-bound budget).
* `progM α D A h m = Prog_m(h)` (`I:eq:sec4_prog_m_def`).
* `replaceBlock r Sr S`, `mixNoise r ω ω'`, `stageLaw A r S ω' Sr`: the law of the transcript as a function
  of the block `S_r`, with all other blocks and all noise not owned by stage `r` fixed (stage `r` owns the
  Beta draws if `r = 1`, and `ν^{(r)}, ζ^{(r)}, ρ^{(r)}` if `r ≥ 2`). "`S_r ↦ h` is `(ε, δ)`-DP" (Lemma
  `I:lem:working_sample_privacy`(3), Proposition `I:prop:homog_adv_comp`) is
  `∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A r S ω') ε δ`.
* `adaProb_resample` (in `F2e2e/A/ArchResample.lean`): resampling block `r` and the stage-`r` noise preserves
  `adaProb` (the Fubini step that turns "DP for every fixed `S₋ᵣ, ω₋ᵣ`" into statements about `adaProb`).
-/

namespace F2e2e

namespace A

open MeasureTheory

noncomputable section

variable {X : Type} [MeasurableSpace X]

/-! ## The probability space of the analysis -/

/-- The probability space of the analysis: the sample `S ∼ D^n` and the mechanism's noise `ω ∼ P_M`. -/
def adaProb (k : ℕ) (α β : ℝ) (D : Measure X) :
    Measure ((Fin (adaSampleSize k α β) → X) × AdaOmega k α) :=
  (Measure.pi fun _ : Fin (adaSampleSize k α β) => D).prod (adaNoiseMeasure k α β)

instance isProbabilityMeasure_adaProb (k : ℕ) (α β : ℝ) (D : Measure X) [IsProbabilityMeasure D] :
    IsProbabilityMeasure (adaProb k α β D) := by
  unfold adaProb
  infer_instance

/-! ## Transcript functionals -/

variable {k : ℕ}

/-- The record history `h_0, …, h_{i-1}` read off a transcript (`RoundRec.halted` for rounds `≥ k`): what the
analyst sees before round `i`. (It returns the `RoundRec` history, not only the answers; the name is historical.) -/
def histAns (h : Fin k → RoundRec) (i : ℕ) : Fin i → RoundRec :=
  fun j => if hj : j.val < k then h ⟨j.val, hj⟩ else RoundRec.halted

/-- The record of round `j` of a transcript (`RoundRec.halted` for `j ≥ k`). -/
def recAt (h : Fin k → RoundRec) (j : ℕ) : RoundRec :=
  if hj : j < k then h ⟨j, hj⟩ else RoundRec.halted

/-- The query of round `i`: `q_i = A_i(a_0, …, a_{i-1})`. -/
def qry (A : DetAnalyst X) (h : Fin k → RoundRec) (i : ℕ) : X → ℝ := A i (histAns h i)

/-- The population mean of the query of round `i`: `μ_i(h) = ∫ q_i dD` (eq. `I:eq:mu_i_sigma_h_measurable`). -/
def popMu (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (i : ℕ) : ℝ :=
  ∫ x, qry A h i x ∂D

/-- The final Stage-1 trigger counter `t₁` (the number of Case-A rounds). -/
def finalT1 (h : Fin k → RoundRec) : ℕ := (Finset.univ.filter fun i => (h i).ufinal = 2).card

/-- The final Case-B counter `N_r` (`3 ≤ r ≤ L`): the number of rounds with `u_final = r`. -/
def finalN (h : Fin k → RoundRec) (r : ℕ) : ℕ := (Finset.univ.filter fun i => (h i).ufinal = r).card

/-- The validator halting event `E_halt(h) = ⋃_{r*=3}^{L} {N_{r*} = N_{r*,max}}` (`I:eq:ehalt_def`). -/
def EHalt (α : ℝ) (h : Fin k → RoundRec) : Prop :=
  ∃ r, 3 ≤ r ∧ r ≤ adaL α ∧ finalN h r = adaNmax α r

/-- The dimensionless progress functional of validator level `m` (`2 ≤ m ≤ L-1`, Definition `I:def:prog_m`):
`Prog_m(h) = 8 w_m ∑_i [(-δ_{m,i})(c_i^{(m)} - μ_i) - δ_{m,i}²/8 - |δ_{m,i}| u₀]`. -/
def progM (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (m : ℕ) : ℝ :=
  8 * adaW α m * ∑ i : Fin k,
    ((-(h i).delta m) * ((h i).c m - popMu D A h i) - (h i).delta m ^ 2 / 8 -
      |(h i).delta m| * adaU0 α)

/-! ## The interaction, round by round -/

variable {α β : ℝ}

/-- The values on the sample of the query of round `i` in the interaction with `A`. -/
def onlineQ (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : Fin (adaSampleSize k α β) → ℝ :=
  fun ℓ => A i (answersOf (onlineRun k α β A S ω i).2) (S ℓ)

/-- The state at the start of round `i` of the interaction with `A`. -/
def onlineState (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : MState k α β :=
  (onlineRun k α β A S ω i).1

/-- The chain data of round `i` of the interaction with `A` (meaningful when the round is active). -/
def onlineChain (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : ChainData :=
  roundChain (onlineState k α β A S ω i) i (onlineQ k α β A S ω i) ω

/-! ## Blocks, the anchor, the clean event -/

/-- The block `S_r = (X_{r,1}, …, X_{r,n_r})` of the sample. -/
def blockOf (k : ℕ) (α β : ℝ) (r : ℕ) (S : Fin (adaSampleSize k α β) → X) :
    Fin (adaBlock k α β r) → X :=
  fun ℓ => S (adaBlockIdx k α β r ℓ)

/-- The anchor mean `θ^{(L)}(S_L) = (1/n_L) ∑_ℓ q(X_{L,ℓ})` of a query `q`. -/
def anchorMean (k : ℕ) (α β : ℝ) (S : Fin (adaSampleSize k α β) → X) (q : X → ℝ) : ℝ :=
  (∑ ℓ, q (blockOf k α β (adaL α) S ℓ)) / (adaBlock k α β (adaL α) : ℝ)

/-- The anchor event `E_anc`: `max_{i<k} |θ_i^{(L)}(S_L) - μ_i| ≤ r_anc` (all rounds, halted ones included). -/
def EAnc (k : ℕ) (α β : ℝ) (D : Measure X) (A : DetAnalyst X)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) : Prop :=
  ∀ i : Fin k, |anchorMean k α β z.1 (qry A (transcript k α β A z.1 z.2) i) -
    popMu D A (transcript k α β A z.1 z.2) i| ≤ adaRanc α

/-- The Laplace envelope of one noise-table entry: `|ν| ≤ 2u₀`, `|ζ| ≤ u₀`, `|ρ| ≤ u₀` (no condition on the
Beta draws). -/
def lapOK (k : ℕ) (α : ℝ) : NoiseIdx k (adaL α) → ℝ → Prop
  | .beta _, _ => True
  | .nu _ _, x => |x| ≤ 2 * adaU0 α
  | .zeta _ _, x => |x| ≤ adaU0 α
  | .rho _ _, x => |x| ≤ adaU0 α

/-- The Laplace event `E_lap`: every Laplace entry of the noise table is within its envelope. -/
def ELap (k : ℕ) (α : ℝ) (ω : AdaOmega k α) : Prop := ∀ j, lapOK k α j (ω j)

/-- The clean event `E_clean = E_anc ∩ E_lap` (Proposition `I:prop:clean_event_bound`). -/
def EClean (k : ℕ) (α β : ℝ) (D : Measure X) (A : DetAnalyst X)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) : Prop :=
  EAnc k α β D A z ∧ ELap k α z.2

/-! ## Stage laws: `S_r ↦ h` with everything else fixed -/

/-- Replace the block `r` of the sample `S` by `Sr`. -/
def replaceBlock (k : ℕ) (α β : ℝ) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) : Fin (adaSampleSize k α β) → X :=
  fun p =>
    if hp : adaOffset k α β r ≤ p.val ∧ p.val < adaOffset k α β r + adaBlock k α β r then
      Sr ⟨p.val - adaOffset k α β r, by omega⟩
    else S p

/-- The noise table with the entries owned by stage `r` taken from `ω` and all others from `ω'`. -/
def mixNoise (r : ℕ) (ω ω' : AdaOmega k α) : AdaOmega k α :=
  fun j => if j.stage = r then ω j else ω' j

/-- The law of the transcript as a function of the block `S_r`, the other blocks (those of `S`) and the noise
not owned by stage `r` (that of `ω'`) being fixed, stage `r`'s own noise being drawn from `P_M`. -/
def stageLaw (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (r : ℕ) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (Sr : Fin (adaBlock k α β r) → X) : Measure (Fin k → RoundRec) :=
  (adaNoiseMeasure k α β).map
    (fun ω => transcript k α β A (replaceBlock k α β r Sr S) (mixNoise r ω ω'))

end

/-! ## Basic facts -/

variable {X : Type}

theorem blockOf_replaceBlock (k : ℕ) (α β : ℝ) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) : blockOf k α β r (replaceBlock k α β r Sr S) = Sr := by
  funext ℓ
  have h1 : adaOffset k α β r ≤ (adaBlockIdx k α β r ℓ).val ∧
      (adaBlockIdx k α β r ℓ).val < adaOffset k α β r + adaBlock k α β r := by
    rw [adaBlockIdx_val]
    exact ⟨Nat.le_add_right _ _, by have := ℓ.isLt; omega⟩
  simp only [blockOf, replaceBlock]
  rw [dif_pos h1]
  congr 1
  ext
  simp [adaBlockIdx_val]

theorem replaceBlock_of_not_mem (k : ℕ) (α β : ℝ) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (p : Fin (adaSampleSize k α β))
    (hp : ¬ (adaOffset k α β r ≤ p.val ∧ p.val < adaOffset k α β r + adaBlock k α β r)) :
    replaceBlock k α β r Sr S p = S p := by
  simp only [replaceBlock, dif_neg hp]

theorem mixNoise_of_stage {k : ℕ} {α : ℝ} (r : ℕ) (ω ω' : AdaOmega k α) (j : NoiseIdx k (adaL α))
    (hj : j.stage = r) : mixNoise r ω ω' j = ω j := by
  simp [mixNoise, hj]

theorem mixNoise_of_not_stage {k : ℕ} {α : ℝ} (r : ℕ) (ω ω' : AdaOmega k α) (j : NoiseIdx k (adaL α))
    (hj : j.stage ≠ r) : mixNoise r ω ω' j = ω' j := by
  simp [mixNoise, hj]

theorem histAns_apply {k : ℕ} (h : Fin k → RoundRec) (i : ℕ) (j : Fin i) :
    histAns h i j = recAt h j := rfl

theorem recAt_fin {k : ℕ} (h : Fin k → RoundRec) (j : Fin k) : recAt h j = h j := by
  simp [recAt]

end A

end F2e2e
