import F2e2e.A.Validators
import F2e2e.A.ArchResample

/-!
# Lemma `I:lem:anchor_ghost_monitor` for the mechanism

Paper: `parts/partI.tex` L1033-1107 (Lemma `I:lem:anchor_ghost_monitor`, `I:eq:anchor_ghost_bound`) and L1109-1146
(Prop. `I:prop:clean_event_bound`): `Pr[E_anc^c] ≤ 100 δ_val/ε_L`.

The generic ghost monitor (any `(ε/2, δ/2)`-DP Markov kernel `S_L ↦ h`, `[0,1]`-valued jointly measurable queries,
`n ≥ 16 ln(6k/δ)/(r_anc ε)`, `r_anc = 4ε`, `ε < 10⁻⁴`, `δ ≤ 1`) is A-ACC's `ghost_monitor` (F2e2e/A/Anchor.lean);
it enters here as the hypothesis `hghost`, specialised to the anchor block (`n = n_L`) and the transcript space
`H = Fin k → RoundRec`, with the same binders in the same order (so `hghost := fun hn hk κ _ => ghost_monitor D hn hk κ`).

Proof of `anchor_ghost_monitor_of_ghost`: condition on everything but the anchor block and the anchor stage's noise
(`integral_adaProb_block`, `r = L`); for fixed `(S_{-L}, ω_{-L})` the transcript is drawn from the Markov kernel
`stageKernel … L`, which is `(ε_L/2, δ_val/2)`-DP by Prop. `I:prop:homog_adv_comp`(ii) (`homog_adv_comp_anchor`);
the ghost monitor bounds the conditional failure probability by `100 δ_val/ε_L`; average.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

private theorem measurable_histAns_anc (i : ℕ) : Measurable (fun h : Fin k → RoundRec => histAns h i) := by
  rw [measurable_pi_iff]
  intro j
  by_cases hj : j.val < k
  · simp only [histAns, dif_pos hj]
    exact measurable_pi_apply _
  · simp only [histAns, dif_neg hj]
    exact measurable_const

private theorem measurable_qry_anc (A : DetAnalyst X) (hA : A.JointlyMeasurable) (i : ℕ) :
    Measurable (fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2) :=
  (hA i).comp (((measurable_histAns_anc i).comp measurable_fst).prodMk measurable_snd)

private theorem measurable_popMu_anc (D : Measure X) [SFinite D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (i : ℕ) : Measurable (fun h : Fin k → RoundRec => popMu D A h i) := by
  unfold popMu
  exact (StronglyMeasurable.integral_prod_right'
    (f := fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2)
    (measurable_qry_anc A hA i).stronglyMeasurable).measurable

/-- The anchor failure set in (anchor block, transcript) space:
`∃ i, 4 ε_L < |(1/n_L) ∑_ℓ q_i(X_{L,ℓ}) - μ_i(h)|` (`r_anc = 4 ε_L`). -/
def ancBad (k : ℕ) (α β : ℝ) (D : Measure X) (A : DetAnalyst X) :
    Set ((Fin (adaBlock k α β (adaL α)) → X) × (Fin k → RoundRec)) :=
  {p | ∃ i : Fin k, 4 * adaEpsL α <
    |(∑ ℓ, qry A p.2 i (p.1 ℓ)) / (adaBlock k α β (adaL α) : ℝ) - ∫ x, qry A p.2 i x ∂D|}

theorem measurableSet_ancBad (D : Measure X) [SFinite D] (A : DetAnalyst X) (hA : A.JointlyMeasurable) :
    MeasurableSet (ancBad k α β D A) := by
  have h : ancBad k α β D A = ⋃ i : Fin k, {p : (Fin (adaBlock k α β (adaL α)) → X) × (Fin k → RoundRec) |
      4 * adaEpsL α < |(∑ ℓ, qry A p.2 i (p.1 ℓ)) / (adaBlock k α β (adaL α) : ℝ) - popMu D A p.2 i|} := by
    ext p
    simp only [ancBad, popMu, Set.mem_ofPred_eq, Set.mem_iUnion]
  rw [h]
  refine MeasurableSet.iUnion fun i => measurableSet_lt measurable_const ?_
  refine continuous_abs.measurable.comp (Measurable.sub ?_ ((measurable_popMu_anc D A hA i).comp measurable_snd))
  refine Measurable.div_const (Finset.measurable_sum _ fun ℓ _ => ?_) _
  exact (measurable_qry_anc A hA i).comp (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))

/-- `E_anc` fails iff (anchor block, transcript) lies in `ancBad`. -/
theorem not_EAnc_iff (D : Measure X) (A : DetAnalyst X) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) :
    ¬ EAnc k α β D A z ↔
      (blockOf k α β (adaL α) z.1, transcript k α β A z.1 z.2) ∈ ancBad k α β D A := by
  simp only [EAnc, ancBad, anchorMean, popMu, adaRanc, Set.mem_ofPred_eq, not_forall, not_le]

/-- **Lemma `I:lem:anchor_ghost_monitor` for the mechanism**, from the generic ghost monitor `hghost` (A-ACC's
`ghost_monitor` specialised to `n = n_L`, `H = Fin k → RoundRec`): `Pr[E_anc^c] ≤ 100 δ_val/ε_L`. -/
theorem anchor_ghost_monitor_of_ghost (D : Measure X) [IsProbabilityMeasure D]
    (hghost : ∀ (_hn : 0 < adaBlock k α β (adaL α)) (_hk : 1 ≤ k)
      (κ : Kernel (Fin (adaBlock k α β (adaL α)) → X) (Fin k → RoundRec)) [IsMarkovKernel κ] {ε δ : ℝ}
      (_hε : 0 < ε) (_hε4 : ε < 1 / 10 ^ 4) (_hδ : 0 < δ) (_hδ1 : δ ≤ 1)
      (_hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) (q : (Fin k → RoundRec) → Fin k → X → ℝ)
      (_hqm : ∀ i, Measurable (fun p : (Fin k → RoundRec) × X => q p.1 i p.2))
      (_hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
      (_hn16 : 16 * Real.log (6 * k / δ) / (4 * ε * ε) ≤ (adaBlock k α β (adaL α) : ℝ)),
      ((Measure.pi fun _ : Fin (adaBlock k α β (adaL α)) => D) ⊗ₘ κ)
          {p | ∃ i : Fin k, 4 * ε <
            |(∑ ℓ, q p.2 i (p.1 ℓ)) / (adaBlock k α β (adaL α) : ℝ) - ∫ x, q p.2 i x ∂D|} ≤
        ENNReal.ofReal (100 * δ / ε))
    (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable) :
    adaProb k α β D {z | ¬ EAnc k α β D A z} ≤ ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α) := by
  -- parameters
  have hε : 0 < adaEpsL α := adaEpsL_pos hα
  have hε4 : adaEpsL α < 1 / 10 ^ 4 := by
    have := adaU0_lt hα hα'
    unfold adaEpsL
    linarith
  have hδ : 0 < adaDeltaVal α β := adaDeltaVal_pos hα hβ
  have hδ1 : adaDeltaVal α β ≤ 1 := (adaDeltaVal_lt_one hα hα' hβ hβ').le
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hlog : 0 < Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
    have := log_six_k_gt hα hα' hβ hβ' hk
    linarith
  have hnL : 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) / (adaBsvt k α β * adaEpsL α) +
      16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) ≤ (adaNL k α β : ℝ) :=
    Nat.le_ceil _
  have hn16 : 16 * Real.log (6 * k / adaDeltaVal α β) / (4 * adaEpsL α * adaEpsL α) ≤
      (adaBlock k α β (adaL α) : ℝ) := by
    rw [adaBlock_L]
    have h0 : 0 ≤ 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) / (adaBsvt k α β * adaEpsL α) := by
      positivity
    have e : adaRanc α * adaEpsL α = 4 * adaEpsL α * adaEpsL α := by
      unfold adaRanc
      ring
    rw [e] at hnL
    linarith
  have hn : 0 < adaBlock k α β (adaL α) := by
    have h16 : (0 : ℝ) < 16 * Real.log (6 * k / adaDeltaVal α β) / (4 * adaEpsL α * adaEpsL α) :=
      div_pos (mul_pos (by norm_num) hlog) (by positivity)
    exact_mod_cast lt_of_lt_of_le h16 hn16
  -- the queries
  set q : (Fin k → RoundRec) → Fin k → X → ℝ := fun h i x => qry A h i x with hq_def
  have hqm : ∀ i, Measurable (fun p : (Fin k → RoundRec) × X => q p.1 i p.2) :=
    fun i => measurable_qry_anc A hAm i
  have hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1 := fun h i x => ⟨(hA _ _ _).1, (hA _ _ _).2⟩
  -- the conditional bound
  set c : ℝ := 100 * adaDeltaVal α β / adaEpsL α with hc_def
  have hc : 0 ≤ c := by positivity
  set μL := Measure.pi fun _ : Fin (adaBlock k α β (adaL α)) => D with hμL
  have hMk : ∀ w : (Fin (adaSampleSize k α β) → X) × AdaOmega k α,
      IsMarkovKernel (stageKernel k α β A (adaL α) w.1 w.2) :=
    fun w => isMarkovKernel_stageKernel A hAm (adaL α) w.1 w.2
  have hw : ∀ w : (Fin (adaSampleSize k α β) → X) × AdaOmega k α,
      (μL ⊗ₘ stageKernel k α β A (adaL α) w.1 w.2) (ancBad k α β D A) ≤ ENNReal.ofReal c := by
    intro w
    have := hMk w
    have hDP : DP.IsDP DP.Neighbor (fun S => stageKernel k α β A (adaL α) w.1 w.2 S)
        (adaEpsL α / 2) (adaDeltaVal α β / 2) := by
      intro S S' hSS'
      show DP.Indist (stageKernel k α β A (adaL α) w.1 w.2 S) (stageKernel k α β A (adaL α) w.1 w.2 S')
        (adaEpsL α / 2) (adaDeltaVal α β / 2)
      rw [stageKernel_apply A hAm, stageKernel_apply A hAm]
      exact homog_adv_comp_anchor hk hα hα' hβ hβ' A hA hAm w.1 w.2 S S' hSS'
    exact hghost hn hk (stageKernel k α β A (adaL α) w.1 w.2) hε hε4 hδ hδ1 hDP q hqm hq01 hn16
  -- the indicator of the failure set
  have hBm := measurableSet_ancBad (k := k) (α := α) (β := β) D A hAm
  set G : (Fin (adaBlock k α β (adaL α)) → X) → (Fin k → RoundRec) → ℝ :=
    fun Sr y => (ancBad k α β D A).indicator (fun _ => (1 : ℝ)) (Sr, y) with hG
  have hGu : Function.uncurry G = (ancBad k α β D A).indicator (fun _ => (1 : ℝ)) := by
    funext p
    rfl
  have hGm : Measurable (Function.uncurry G) := by
    rw [hGu]
    exact measurable_const.indicator hBm
  have hGb : ∃ C, ∀ s y, |G s y| ≤ C := ⟨1, fun s y => by
    simp only [hG, Set.indicator]
    split_ifs <;> norm_num⟩
  have hint := integral_adaProb_block (k := k) (α := α) (β := β) D A hAm (adaL α) G hGm hGb
  -- left side: the probability of `E_anc^c`
  have hEm : MeasurableSet {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | ¬ EAnc k α β D A z} :=
    (measurableSet_EAnc D A hAm).compl
  have hlhs : ∫ z, G (blockOf k α β (adaL α) z.1) (transcript k α β A z.1 z.2) ∂adaProb k α β D =
      (adaProb k α β D).real {z | ¬ EAnc k α β D A z} := by
    rw [← integral_indicator_one hEm]
    refine integral_congr_ae (Filter.Eventually.of_forall fun z => ?_)
    by_cases hz : ¬ EAnc k α β D A z
    · have hz' := (not_EAnc_iff D A z).1 hz
      simp only [hG, Set.indicator_of_mem hz', Set.indicator_of_mem (show z ∈ {z | ¬ EAnc k α β D A z} from hz),
        Pi.one_apply]
    · have hz' : (blockOf k α β (adaL α) z.1, transcript k α β A z.1 z.2) ∉ ancBad k α β D A :=
        fun h => hz ((not_EAnc_iff D A z).2 h)
      simp only [hG, Set.indicator_of_notMem hz',
        Set.indicator_of_notMem (show z ∉ {z | ¬ EAnc k α β D A z} from hz)]
  -- right side: average of the conditional failure probabilities
  have hinner : ∀ w : (Fin (adaSampleSize k α β) → X) × AdaOmega k α,
      ∫ Sr, ∫ y, G Sr y ∂(stageKernel k α β A (adaL α) w.1 w.2 Sr) ∂μL =
        (μL ⊗ₘ stageKernel k α β A (adaL α) w.1 w.2).real (ancBad k α β D A) := by
    intro w
    have := hMk w
    rw [← integral_indicator_one hBm, Measure.integral_compProd]
    · rfl
    · exact (integrable_const (1 : ℝ)).indicator hBm
  have hrhs : ∫ w, ∫ Sr, ∫ y, G Sr y ∂(stageKernel k α β A (adaL α) w.1 w.2 Sr) ∂μL ∂adaProb k α β D ≤ c := by
    simp_rw [hinner]
    calc ∫ w, (μL ⊗ₘ stageKernel k α β A (adaL α) w.1 w.2).real (ancBad k α β D A) ∂adaProb k α β D
        ≤ ∫ _w, c ∂adaProb k α β D := by
          refine integral_mono_of_nonneg (Filter.Eventually.of_forall fun w => measureReal_nonneg)
            (integrable_const c) (Filter.Eventually.of_forall fun w => ?_)
          exact ENNReal.toReal_le_of_le_ofReal hc (hw w)
      _ = c := by simp
  have hreal : (adaProb k α β D).real {z | ¬ EAnc k α β D A z} ≤ c := by
    rw [← hlhs, hint]
    exact hrhs
  exact (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) hc).2 hreal

end A

end F2e2e
