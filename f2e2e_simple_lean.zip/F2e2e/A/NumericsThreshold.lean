import F2e2e.A.Params
import F2e2e.A.NumericsBasic

/-!
# Part I numerics: Lemma `I:lem:threshold_properties` (structural properties of the locked parameters)

`parts/partI.tex` L263-291. For `0 < α < 1/16` (and any `k`, `β`), with `L = adaL α`, `γ = adaGamma α`,
`u₀ = adaU0 α`, `ρ = adaRho α`, `τ = adaTau α`, `w = adaW α`, `η = adaEta α`, `η̃ = adaEtaTilde α`
(the definitions of `F2e2e/A/Params.lean`):
* (a) `L ≥ 5`, `L - 1 > ln(1/α) > 0`, `1 < ρ = exp(ln(1/α)/(L-1)) < e`, `ρ⁻² ∈ (e⁻², 1)`,
  `ε_L < ε_{L-1} < ⋯ < ε_1 = 0.05`;
* (b) `τ_{(1,2)} = α/2`, `τ_{(2,L)} = 2(L-2)γ < α/4`, `τ_{(1,L)} = α/2 + 2(L-2)γ < 3α/4`, and for all
  `1 ≤ u ≤ L`: `τ_{(u,L)} + 4u₀ + r_anc ≤ τ_{(1,L)} + 6u₀ < 3α/4 + 6α/(256L) < α`;
* (c) `τ_{(u,r*)} - τ_{(u,r*-1)} = 2γ` for `3 ≤ r*` and `1 ≤ u ≤ r* - 1`;
* (d) `8 w_{r*-1} η_{r*-1} = 8 w_{r*} η̃_{r*} = w_{r*-1} γ` for `3 ≤ r* ≤ L - 1`.
Also: `w_m > 0`, `w_{r-1} = ρ⁻² w_r`, `η̃_r = ρ⁻² η` and `w_r η̃_r² < w_{r-1} η²` for `2 ≤ r ≠ L`.
-/

namespace F2e2e

namespace A

section Threshold

variable {α : ℝ}

/-! ### (a) Bounded privacy ratio -/

/-- `ρ = exp(ln(1/α)/(L-1))`. -/
lemma adaRho_eq_exp (hα : 0 < α) :
    adaRho α = Real.exp (Real.log (1 / α) / ((adaL α : ℝ) - 1)) :=
  rho_eq_exp hα

lemma adaRho_pos (hα : 0 < α) : 0 < adaRho α := rho_pos hα

/-- `1 < ρ`. -/
lemma one_lt_adaRho (hα : 0 < α) (hα' : α < 1 / 16) : 1 < adaRho α := one_lt_rho hα hα'

/-- `ρ < e`. -/
lemma adaRho_lt_exp_one (hα : 0 < α) (hα' : α < 1 / 16) : adaRho α < Real.exp 1 :=
  rho_lt_exp_one hα hα'

/-- `e^{3/5} < ρ` (`I:eq:sec6_rho_bounds`). -/
lemma exp_three_fifths_lt_adaRho (hα : 0 < α) (hα' : α < 1 / 16) : Real.exp (3 / 5) < adaRho α :=
  exp_three_fifths_lt_rho hα hα'

/-- `ρ⁻¹ = θ = α^{1/(L-1)}`. -/
lemma adaRho_inv (hα : 0 < α) : (adaRho α)⁻¹ = α ^ (1 / ((adaL α : ℝ) - 1)) := by
  unfold adaRho
  rw [rho_eq_inv_theta hα, inv_inv]

/-- `e⁻² < ρ⁻²`. -/
lemma exp_neg_two_lt_adaRho_inv_sq (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.exp (-2) < (adaRho α)⁻¹ ^ 2 := by
  rw [adaRho_inv hα]
  exact exp_neg_two_lt_theta_sq hα hα'

/-- `ρ⁻² < 1`. -/
lemma adaRho_inv_sq_lt_one (hα : 0 < α) (hα' : α < 1 / 16) : (adaRho α)⁻¹ ^ 2 < 1 := by
  rw [adaRho_inv hα]
  have := theta_sq_lt hα hα'
  linarith

/-- `ε_r = ρ ε_{r+1}` for `r ≥ 1` (`I:eq:eps_r_schedule`). -/
lemma adaEps_eq_adaRho_mul (hα : 0 < α) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α r = adaRho α * adaEps α (r + 1) :=
  adaEps_eq_rho_mul_succ hα hr

/-- Lemma `I:lem:threshold_properties`(a), bundled. -/
theorem threshold_properties_a (hα : 0 < α) (hα' : α < 1 / 16) :
    5 ≤ adaL α ∧ Real.log (1 / α) < (adaL α : ℝ) - 1 ∧ 0 < Real.log (1 / α) ∧
      adaRho α = Real.exp (Real.log (1 / α) / ((adaL α : ℝ) - 1)) ∧
      1 < adaRho α ∧ adaRho α < Real.exp 1 ∧
      Real.exp (-2) < (adaRho α)⁻¹ ^ 2 ∧ (adaRho α)⁻¹ ^ 2 < 1 ∧
      adaEpsL α < adaEps α (adaL α - 1) ∧
      (∀ r s : ℕ, r < s → adaEps α s < adaEps α r) ∧ adaEps α 1 = 1 / 20 :=
  ⟨five_le_adaL hα hα', log_inv_lt_adaL_sub_one hα hα', log_inv_pos hα hα', adaRho_eq_exp hα,
    one_lt_adaRho hα hα', adaRho_lt_exp_one hα hα', exp_neg_two_lt_adaRho_inv_sq hα hα',
    adaRho_inv_sq_lt_one hα hα', adaEpsL_lt_adaEps hα hα', fun _ _ h => adaEps_lt_of_lt hα hα' h,
    adaEps_at_one α⟩

/-! ### (b) Threshold span bounds -/

/-- `τ_{(1,2)} = α/2`. -/
lemma adaTau_one_two (α : ℝ) : adaTau α 1 2 = α / 2 := by
  unfold adaTau
  norm_num

/-- `τ_{(1,r)} = α/2 + 2(r-2)γ` for `r ≠ 1`. -/
lemma adaTau_one (α : ℝ) {r : ℕ} (hr : r ≠ 1) :
    adaTau α 1 r = α / 2 + 2 * ((r : ℝ) - 2) * adaGamma α := by
  unfold adaTau
  rw [if_neg (Ne.symm hr), if_pos rfl]

/-- `τ_{(u,r)} = 2(r-u)γ` for `u ≠ 1`, `u ≠ r`. -/
lemma adaTau_of_ne (α : ℝ) {u r : ℕ} (hu : u ≠ 1) (hur : u ≠ r) :
    adaTau α u r = 2 * ((r : ℝ) - (u : ℝ)) * adaGamma α := by
  unfold adaTau
  rw [if_neg hur, if_neg hu]

/-- `τ_{(r,r)} = 0`. -/
lemma adaTau_self (α : ℝ) (r : ℕ) : adaTau α r r = 0 := by
  unfold adaTau
  rw [if_pos rfl]

/-- `τ_{(2,L)} = 2(L-2)γ`. -/
lemma adaTau_two_L (α : ℝ) : adaTau α 2 (adaL α) = 2 * ((adaL α : ℝ) - 2) * adaGamma α := by
  have h4 := four_le_adaL α
  rw [adaTau_of_ne α (by norm_num) (by omega)]
  norm_num

/-- `2(L-2)γ = (L-2)α/(4L) < α/4`. -/
lemma two_mul_adaL_sub_two_mul_adaGamma_lt (hα : 0 < α) :
    2 * ((adaL α : ℝ) - 2) * adaGamma α < α / 4 := by
  unfold adaGamma
  have hL := adaL_cast_pos α
  rw [show 2 * ((adaL α : ℝ) - 2) * (α / (8 * (adaL α : ℝ))) =
    α / 4 - α / (2 * (adaL α : ℝ)) by field_simp; ring]
  have : 0 < α / (2 * (adaL α : ℝ)) := by positivity
  linarith

lemma two_mul_adaL_sub_two_mul_adaGamma_nonneg (hα : 0 < α) :
    0 ≤ 2 * ((adaL α : ℝ) - 2) * adaGamma α := by
  have h4 : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  have := adaGamma_pos hα
  have : 0 ≤ (adaL α : ℝ) - 2 := by linarith
  positivity

/-- `τ_{(2,L)} < α/4` (`I:eq:tau_2L_bound`). -/
lemma adaTau_two_L_lt (hα : 0 < α) : adaTau α 2 (adaL α) < α / 4 := by
  rw [adaTau_two_L]
  exact two_mul_adaL_sub_two_mul_adaGamma_lt hα

/-- `τ_{(1,L)} = α/2 + 2(L-2)γ`. -/
lemma adaTau_one_L (α : ℝ) : adaTau α 1 (adaL α) = α / 2 + 2 * ((adaL α : ℝ) - 2) * adaGamma α := by
  have h4 := four_le_adaL α
  exact adaTau_one α (by omega)

/-- `τ_{(1,L)} < 3α/4` (`I:eq:tau_1L_bound`). -/
lemma adaTau_one_L_lt (hα : 0 < α) : adaTau α 1 (adaL α) < 3 * α / 4 := by
  rw [adaTau_one_L]
  have := two_mul_adaL_sub_two_mul_adaGamma_lt hα
  linarith

/-- `τ_{(u,r)} ≥ 0` for `1 ≤ u ≤ r`. -/
lemma adaTau_nonneg (hα : 0 < α) {u r : ℕ} (_hu : 1 ≤ u) (hur : u ≤ r) : 0 ≤ adaTau α u r := by
  have hγ := adaGamma_pos hα
  rcases eq_or_ne u r with h | h
  · rw [h, adaTau_self]
  rcases eq_or_ne u 1 with h1 | h1
  · rw [h1, adaTau_one α (by omega)]
    have : (2 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 2 ≤ r by omega)
    have : 0 ≤ (r : ℝ) - 2 := by linarith
    positivity
  · rw [adaTau_of_ne α h1 h]
    have : (u : ℝ) ≤ (r : ℝ) := by exact_mod_cast hur
    have : 0 ≤ (r : ℝ) - (u : ℝ) := by linarith
    positivity

/-- `τ_{(u,L)} ≤ τ_{(1,L)}` for `1 ≤ u ≤ L`. -/
lemma adaTau_le_adaTau_one_L (hα : 0 < α) {u : ℕ} (hu : 1 ≤ u) (_huL : u ≤ adaL α) :
    adaTau α u (adaL α) ≤ adaTau α 1 (adaL α) := by
  have hγ := adaGamma_pos hα
  have h4 := four_le_adaL α
  have hspan := two_mul_adaL_sub_two_mul_adaGamma_nonneg hα
  rw [adaTau_one_L]
  rcases eq_or_ne u (adaL α) with h | h
  · rw [h, adaTau_self]
    linarith
  rcases eq_or_ne u 1 with h1 | h1
  · rw [h1, adaTau_one_L]
  · rw [adaTau_of_ne α h1 h]
    have hu2 : (2 : ℝ) ≤ (u : ℝ) := by exact_mod_cast (show 2 ≤ u by omega)
    have : 2 * ((adaL α : ℝ) - (u : ℝ)) * adaGamma α ≤ 2 * ((adaL α : ℝ) - 2) * adaGamma α := by
      gcongr
    linarith

/-- `6 u₀ < α/4` (indeed `6u₀ = 6α/(256L)`). -/
lemma six_adaU0_lt (hα : 0 < α) : 6 * adaU0 α < α / 4 := by
  rw [adaU0_eq]
  have h4 : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  rw [show 6 * (α / (256 * (adaL α : ℝ))) = 6 * α / (256 * (adaL α : ℝ)) by ring,
    div_lt_div_iff₀ (by positivity) (by norm_num)]
  nlinarith

/-- `τ_{(u,L)} + 4u₀ + r_anc ≤ τ_{(1,L)} + 6u₀` for `1 ≤ u ≤ L` (`r_anc = 2u₀`). -/
lemma adaTau_add_le (hα : 0 < α) {u : ℕ} (hu : 1 ≤ u) (huL : u ≤ adaL α) :
    adaTau α u (adaL α) + 4 * adaU0 α + adaRanc α ≤ adaTau α 1 (adaL α) + 6 * adaU0 α := by
  rw [adaRanc_eq_two_u0]
  have := adaTau_le_adaTau_one_L hα hu huL
  linarith

/-- `τ_{(1,L)} + 6u₀ < 3α/4 + 6α/(256L)`. -/
lemma adaTau_one_L_add_lt' (hα : 0 < α) :
    adaTau α 1 (adaL α) + 6 * adaU0 α < 3 * α / 4 + 6 * α / (256 * (adaL α : ℝ)) := by
  have h1 := adaTau_one_L_lt hα
  rw [adaU0_eq]
  have : 6 * (α / (256 * (adaL α : ℝ))) = 6 * α / (256 * (adaL α : ℝ)) := by ring
  linarith

/-- `τ_{(1,L)} + 6u₀ < α`. -/
lemma adaTau_one_L_add_lt (hα : 0 < α) : adaTau α 1 (adaL α) + 6 * adaU0 α < α := by
  have h1 := adaTau_one_L_lt hα
  have h2 := six_adaU0_lt hα
  linarith

/-- Lemma `I:lem:threshold_properties`(b), bundled. -/
theorem threshold_properties_b (hα : 0 < α) :
    adaTau α 1 2 = α / 2 ∧
      adaTau α 2 (adaL α) = 2 * ((adaL α : ℝ) - 2) * adaGamma α ∧ adaTau α 2 (adaL α) < α / 4 ∧
      adaTau α 1 (adaL α) = α / 2 + 2 * ((adaL α : ℝ) - 2) * adaGamma α ∧
      adaTau α 1 (adaL α) < 3 * α / 4 ∧
      (∀ u : ℕ, 1 ≤ u → u ≤ adaL α →
        adaTau α u (adaL α) + 4 * adaU0 α + adaRanc α ≤ adaTau α 1 (adaL α) + 6 * adaU0 α) ∧
      adaTau α 1 (adaL α) + 6 * adaU0 α < 3 * α / 4 + 6 * α / (256 * (adaL α : ℝ)) ∧
      3 * α / 4 + 6 * α / (256 * (adaL α : ℝ)) < α := by
  refine ⟨adaTau_one_two α, adaTau_two_L α, adaTau_two_L_lt hα, adaTau_one_L α, adaTau_one_L_lt hα,
    fun u hu huL => adaTau_add_le hα hu huL, adaTau_one_L_add_lt' hα, ?_⟩
  have := six_adaU0_lt hα
  rw [adaU0_eq] at this
  have e : 6 * (α / (256 * (adaL α : ℝ))) = 6 * α / (256 * (adaL α : ℝ)) := by ring
  linarith

/-! ### (c) Uniform adjacent threshold increment -/

/-- `τ_{(u,r)} - τ_{(u,r-1)} = 2γ` for `r ≥ 3` and `1 ≤ u ≤ r - 1` (`I:eq:uniform_adj_increment`). -/
lemma adaTau_sub_pred (α : ℝ) {u r : ℕ} (hr : 3 ≤ r) (_hu : 1 ≤ u) (hur : u ≤ r - 1) :
    adaTau α u r - adaTau α u (r - 1) = 2 * adaGamma α := by
  have hcast : ((r - 1 : ℕ) : ℝ) = (r : ℝ) - 1 := by
    rw [Nat.cast_sub (by omega)]
    push_cast
    ring
  rcases eq_or_ne u 1 with h1 | h1
  · rw [h1, adaTau_one α (by omega), adaTau_one α (by omega), hcast]
    ring
  rcases eq_or_ne u (r - 1) with h2 | h2
  · rw [h2, adaTau_self, adaTau_of_ne α (by omega) (by omega), hcast]
    ring
  · rw [adaTau_of_ne α h1 (by omega), adaTau_of_ne α h1 h2, hcast]
    ring

/-! ### (d) Equal capacity-weighted impulse -/

/-- `w_m > 0`. -/
lemma adaW_pos (hα : 0 < α) (m : ℕ) : 0 < adaW α m := by
  unfold adaW
  have := adaEps_pos hα m
  positivity

/-- `8 w_m η_m = w_m γ`. -/
lemma eight_adaW_adaEta (α : ℝ) (m : ℕ) : 8 * adaW α m * adaEta α = adaW α m * adaGamma α := by
  unfold adaEta
  ring

/-- `8 w_{r} η̃_{r} = w_{r-1} γ` for `r ≠ L`. -/
lemma eight_adaW_adaEtaTilde (hα : 0 < α) {r : ℕ} (hr : r ≠ adaL α) :
    8 * adaW α r * adaEtaTilde α r = adaW α (r - 1) * adaGamma α := by
  unfold adaEtaTilde
  rw [if_neg hr]
  have := (adaW_pos hα r).ne'
  unfold adaEta
  field_simp

/-- Lemma `I:lem:threshold_properties`(d): `8 w_{r*-1} η_{r*-1} = 8 w_{r*} η̃_{r*} = w_{r*-1} γ`
for `3 ≤ r* ≤ L - 1` (`I:eq:equal_impulse_identity`). -/
theorem equal_impulse (hα : 0 < α) {r : ℕ} (_hr3 : 3 ≤ r) (hrL : r ≤ adaL α - 1) :
    8 * adaW α (r - 1) * adaEta α = adaW α (r - 1) * adaGamma α ∧
      8 * adaW α r * adaEtaTilde α r = adaW α (r - 1) * adaGamma α := by
  have h4 := four_le_adaL α
  exact ⟨eight_adaW_adaEta α (r - 1), eight_adaW_adaEtaTilde hα (by omega)⟩

/-- `w_{r-1} = ρ⁻² w_r` for `r ≥ 2`. -/
lemma adaW_pred_eq (hα : 0 < α) {r : ℕ} (hr : 2 ≤ r) :
    adaW α (r - 1) = (adaRho α)⁻¹ ^ 2 * adaW α r := by
  have h := adaEps_eq_adaRho_mul hα (r := r - 1) (by omega)
  rw [show r - 1 + 1 = r by omega] at h
  unfold adaW
  rw [h]
  have := (adaRho_pos hα).ne'
  have := (adaEps_pos hα r).ne'
  field_simp

/-- `η̃_r = ρ⁻² η` for `2 ≤ r ≠ L`. -/
lemma adaEtaTilde_eq (hα : 0 < α) {r : ℕ} (hr : 2 ≤ r) (hrL : r ≠ adaL α) :
    adaEtaTilde α r = (adaRho α)⁻¹ ^ 2 * adaEta α := by
  unfold adaEtaTilde
  rw [if_neg hrL, adaW_pred_eq hα hr]
  have := (adaW_pos hα r).ne'
  field_simp

/-- `w_r η̃_r² < w_{r-1} η²` for `2 ≤ r ≠ L`. -/
lemma adaW_mul_adaEtaTilde_sq_lt (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : 2 ≤ r)
    (hrL : r ≠ adaL α) : adaW α r * adaEtaTilde α r ^ 2 < adaW α (r - 1) * adaEta α ^ 2 := by
  rw [adaEtaTilde_eq hα hr hrL, adaW_pred_eq hα hr]
  have hq := adaRho_inv_sq_lt_one hα hα'
  have hq0 : 0 < (adaRho α)⁻¹ ^ 2 := by
    have := adaRho_pos hα
    positivity
  have hw := adaW_pos hα r
  have hη : 0 < adaEta α := by
    unfold adaEta
    have := adaGamma_pos hα
    positivity
  have h1 : adaW α r * ((adaRho α)⁻¹ ^ 2 * adaEta α) ^ 2 =
      ((adaRho α)⁻¹ ^ 2 * adaW α r * adaEta α ^ 2) * (adaRho α)⁻¹ ^ 2 := by ring
  rw [h1]
  have h2 : 0 < (adaRho α)⁻¹ ^ 2 * adaW α r * adaEta α ^ 2 := by positivity
  calc ((adaRho α)⁻¹ ^ 2 * adaW α r * adaEta α ^ 2) * (adaRho α)⁻¹ ^ 2
      < ((adaRho α)⁻¹ ^ 2 * adaW α r * adaEta α ^ 2) * 1 := by gcongr
    _ = (adaRho α)⁻¹ ^ 2 * adaW α r * adaEta α ^ 2 := by ring

end Threshold

end A

end F2e2e
