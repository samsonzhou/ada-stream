import Mathlib

/-!
# Triangular (adaptive) shifts on `ℝ^k` and densities of adaptive release laws

Infrastructure for Part I, Lemma `I:lem:working_sample_privacy` (`parts/partI.tex` L582–797), Step 1 and the
conclusion (L787–795): the unclipped Stage-1 releases are generated adaptively,
`ã_i = θ_i(ã_{<i}) + ξ_i` (`ξ_i` i.i.d. noise), and the paper compares the densities of the laws of `ã` under two
adjacent datasets with respect to a common dominating measure ("the joint density of the adaptively generated
sequence is the product of the per-round conditional densities", an implicit step of the paper, see
`notes/PAPER_MAP_I_a.md` §I.2.2, "Implicit step").

We prove it through the following facts, for coordinates `Fin k → ℝ` with Lebesgue measure `volume`:
* `measurePreserving_shear`: shifting one coordinate `j` by a measurable function of the other coordinates
  preserves Lebesgue measure (Tonelli in coordinate `j` plus translation invariance);
* `measurePreserving_triangular`: the triangular shift `a ↦ (a_i + g_i(a_{<i}))_i` preserves Lebesgue measure
  (a composition of `k` shears);
* `IsTriangularSol θ Φ`: `Φ` solves the release recursion `Φ v i = θ i (Φ v) + v i` (with `θ i` depending only
  on the coordinates `< i`); a canonical solution `triangularSol θ`, uniqueness, measurability, and the explicit
  inverse `a ↦ (a_i - θ_i(a))_i`;
* `pi_withDensity`: the product of `k` copies of `volume.withDensity ρ` is `volume.withDensity (∏ ρ(x_i))`;
* `map_triangularSol_pi_withDensity`: the law of `Φ(ξ)` for `ξ ∼ (volume.withDensity ρ)^{⊗k}` has the density
  `a ↦ ∏_i ρ(a_i - θ_i(a))` with respect to Lebesgue measure.
-/

namespace F2e2e.A

open MeasureTheory
open scoped ENNReal

variable {k : ℕ}

/-! ### Shears and triangular shifts preserve Lebesgue measure -/

lemma measurable_update_add (j : Fin k) {c : (Fin k → ℝ) → ℝ} (hc : Measurable c) :
    Measurable (fun b : Fin k → ℝ => Function.update b j (b j + c b)) := by
  refine measurable_pi_iff.2 fun i => ?_
  by_cases hi : i = j
  · subst hi
    simp only [Function.update_self]
    exact (measurable_pi_apply i).add hc
  · simp only [Function.update_of_ne hi]
    exact measurable_pi_apply i

/-- Shifting coordinate `j` by a measurable function of the other coordinates preserves Lebesgue measure. -/
theorem measurePreserving_shear (j : Fin k) {c : (Fin k → ℝ) → ℝ} (hc : Measurable c)
    (hdep : DependsOn c {j}ᶜ) :
    MeasurePreserving (fun b => Function.update b j (b j + c b)) volume volume := by
  classical
  have hSm := measurable_update_add j hc
  refine ⟨hSm, ?_⟩
  ext E hE
  rw [Measure.map_apply hSm hE]
  have h1 : volume ((fun b : Fin k → ℝ => Function.update b j (b j + c b)) ⁻¹' E) =
      ∫⁻ x, E.indicator 1 (Function.update x j (x j + c x)) ∂(volume : Measure (Fin k → ℝ)) := by
    rw [← lintegral_indicator_one (hSm hE)]
    rfl
  rw [h1, ← lintegral_indicator_one hE, volume_pi]
  refine lintegral_eq_of_lmarginal_eq {j}
    ((measurable_one.indicator hE).comp hSm) (measurable_one.indicator hE) ?_
  rw [lmarginal_singleton, lmarginal_singleton]
  funext x
  have key : ∀ y, Function.update (Function.update x j y) j (Function.update x j y j +
      c (Function.update x j y)) = Function.update x j (y + c x) := by
    intro y
    rw [Function.update_self, Function.update_idem]
    congr 2
    exact hdep (fun i hi => Function.update_of_ne (by simpa using hi) _ _)
  simp_rw [key]
  exact lintegral_add_right_eq_self (fun y => E.indicator 1 (Function.update x j y)) (c x)

/-- Partial triangular shift: shift the coordinates `i` with `j ≤ i`. -/
def triPartial (g : Fin k → (Fin k → ℝ) → ℝ) (j : ℕ) (a : Fin k → ℝ) : Fin k → ℝ :=
  fun i => if j ≤ (i : ℕ) then a i + g i a else a i

lemma triPartial_apply (g : Fin k → (Fin k → ℝ) → ℝ) (j : ℕ) (a : Fin k → ℝ) (i : Fin k) :
    triPartial g j a i = if j ≤ (i : ℕ) then a i + g i a else a i := rfl

lemma triPartial_eq_comp {g : Fin k → (Fin k → ℝ) → ℝ} (hdep : ∀ i, DependsOn (g i) (Set.Iio i))
    {j : ℕ} (hj : j < k) :
    triPartial g j = (fun b => Function.update b ⟨j, hj⟩ (b ⟨j, hj⟩ + g ⟨j, hj⟩ b)) ∘
      triPartial g (j + 1) := by
  funext a i
  simp only [Function.comp_apply]
  by_cases hi : i = ⟨j, hj⟩
  · subst hi
    rw [Function.update_self]
    simp only [triPartial_apply, le_refl, if_true, show ¬ (j + 1 ≤ j) by omega, if_false]
    congr 1
    refine hdep _ (fun i' hi' => ?_)
    have hlt : (i' : ℕ) < j := hi'
    simp only [triPartial_apply, show ¬ (j + 1 ≤ (i' : ℕ)) by omega, if_false]
  · rw [Function.update_of_ne hi]
    have hne : (i : ℕ) ≠ j := fun h => hi (Fin.ext h)
    by_cases hji : j ≤ (i : ℕ)
    · simp only [triPartial_apply, hji, show j + 1 ≤ (i : ℕ) by omega, if_true]
    · simp only [triPartial_apply, hji, show ¬ (j + 1 ≤ (i : ℕ)) by omega, if_false]

/-- The triangular shift `a ↦ (a_i + g_i(a))_i`, with `g_i` measurable and depending only on the coordinates
`< i`, preserves Lebesgue measure on `Fin k → ℝ`. -/
theorem measurePreserving_triangular {g : Fin k → (Fin k → ℝ) → ℝ} (hg : ∀ i, Measurable (g i))
    (hdep : ∀ i, DependsOn (g i) (Set.Iio i)) :
    MeasurePreserving (fun a i => a i + g i a) volume volume := by
  have key : ∀ n, n ≤ k → MeasurePreserving (triPartial g (k - n)) volume volume := by
    intro n
    induction n with
    | zero =>
      intro _
      have : triPartial g (k - 0) = id := by
        funext a i
        have : ¬ (k - 0 ≤ (i : ℕ)) := by have := i.isLt; omega
        simp only [triPartial_apply, this, if_false, id]
      rw [this]
      exact MeasurePreserving.id _
    | succ n ih =>
      intro hn
      have hj : k - (n + 1) < k := by omega
      have hj1 : k - (n + 1) + 1 = k - n := by omega
      rw [triPartial_eq_comp hdep hj, hj1]
      exact (measurePreserving_shear _ (hg _) ((hdep _).mono (fun i hi => by
        simp only [Set.mem_compl_iff, Set.mem_singleton_iff]
        exact ne_of_lt hi))).comp (ih (by omega))
  have h0 := key k le_rfl
  have : triPartial g (k - k) = fun a i => a i + g i a := by
    funext a i
    simp [triPartial]
  rwa [this] at h0

/-! ### The release recursion `Φ v i = θ i (Φ v) + v i` -/

/-- `Φ` solves the adaptive release recursion driven by `θ`: `Φ v i = θ i (Φ v) + v i` for all `v, i`
(`θ i` is meant to depend only on the coordinates `< i`, i.e. on the previous releases). -/
def IsTriangularSol (θ : Fin k → (Fin k → ℝ) → ℝ) (Φ : (Fin k → ℝ) → (Fin k → ℝ)) : Prop :=
  ∀ v i, Φ v i = θ i (Φ v) + v i

/-- One step of the fixed-point iteration for the release recursion. -/
def triangularStep (θ : Fin k → (Fin k → ℝ) → ℝ) (v a : Fin k → ℝ) : Fin k → ℝ :=
  fun i => θ i a + v i

/-- The canonical solution of the release recursion: `k` steps of the fixed-point iteration started at `v`
(coordinate `i` is final after `i + 1` steps). -/
def triangularSol (θ : Fin k → (Fin k → ℝ) → ℝ) (v : Fin k → ℝ) : Fin k → ℝ :=
  (triangularStep θ v)^[k] v

/-- Uniqueness of fixed points of the release recursion (strong induction on the coordinate). -/
theorem triangular_fixed_unique {θ : Fin k → (Fin k → ℝ) → ℝ} (hdep : ∀ i, DependsOn (θ i) (Set.Iio i))
    {v x y : Fin k → ℝ} (hx : ∀ i, x i = θ i x + v i) (hy : ∀ i, y i = θ i y + v i) : x = y := by
  have key : ∀ n, ∀ i : Fin k, (i : ℕ) < n → x i = y i := by
    intro n
    induction n with
    | zero => intro i hi; omega
    | succ n ih =>
      intro i hi
      rw [hx i, hy i]
      congr 1
      exact hdep i (fun j hj => ih j (by have : (j : ℕ) < i := hj; omega))
  funext i
  exact key (i + 1) i (Nat.lt_succ_self _)

theorem isTriangularSol_triangularSol {θ : Fin k → (Fin k → ℝ) → ℝ}
    (hdep : ∀ i, DependsOn (θ i) (Set.Iio i)) : IsTriangularSol θ (triangularSol θ) := by
  intro v
  set F := triangularStep θ v with hF
  -- coordinates `< n` are stable after `n` steps
  have stab : ∀ n, ∀ i : Fin k, (i : ℕ) < n → F^[n + 1] v i = F^[n] v i := by
    intro n
    induction n with
    | zero => intro i hi; omega
    | succ n ih =>
      intro i hi
      have e1 : F^[n + 1 + 1] v = F (F^[n + 1] v) := Function.iterate_succ_apply' F (n + 1) v
      have e2 : F^[n + 1] v = F (F^[n] v) := Function.iterate_succ_apply' F n v
      rw [e1]
      conv_rhs => rw [e2]
      show θ i (F^[n + 1] v) + v i = θ i (F^[n] v) + v i
      congr 1
      exact hdep i (fun j hj => ih j (by have : (j : ℕ) < i := hj; omega))
  have hfix : F (F^[k] v) = F^[k] v := by
    rw [← Function.iterate_succ_apply' F k]
    funext i
    exact stab k i i.isLt
  intro i
  have := congrFun hfix i
  simp only [hF, triangularStep] at this
  exact this.symm

/-- Uniqueness of solutions of the release recursion. -/
theorem IsTriangularSol.eq {θ : Fin k → (Fin k → ℝ) → ℝ} (hdep : ∀ i, DependsOn (θ i) (Set.Iio i))
    {Φ Ψ : (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : IsTriangularSol θ Φ) (hΨ : IsTriangularSol θ Ψ) : Φ = Ψ := by
  funext v
  exact triangular_fixed_unique hdep (hΦ v) (hΨ v)

/-- The explicit inverse of a solution: `Φ (a - θ(a)) = a`. -/
theorem IsTriangularSol.apply_sub {θ : Fin k → (Fin k → ℝ) → ℝ} (hdep : ∀ i, DependsOn (θ i) (Set.Iio i))
    {Φ : (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : IsTriangularSol θ Φ) (a : Fin k → ℝ) :
    Φ (fun i => a i - θ i a) = a :=
  triangular_fixed_unique hdep (hΦ _) (fun i => by ring)

/-- The other composition: `Φ v - θ(Φ v) = v`. -/
theorem IsTriangularSol.sub_apply {θ : Fin k → (Fin k → ℝ) → ℝ} {Φ : (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : IsTriangularSol θ Φ) (v : Fin k → ℝ) : (fun i => Φ v i - θ i (Φ v)) = v := by
  funext i
  rw [hΦ v i]
  ring

/-- The `i`-th release depends only on the noise coordinates `≤ i`. -/
theorem IsTriangularSol.dependsOn {θ : Fin k → (Fin k → ℝ) → ℝ} (hdep : ∀ i, DependsOn (θ i) (Set.Iio i))
    {Φ : (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : IsTriangularSol θ Φ) (i : Fin k) :
    DependsOn (fun v => Φ v i) (Set.Iic i) := by
  intro v w hvw
  have key : ∀ n, ∀ j : Fin k, (j : ℕ) < n → j ≤ i → Φ v j = Φ w j := by
    intro n
    induction n with
    | zero => intro j hj; omega
    | succ n ih =>
      intro j hj hji
      rw [hΦ v j, hΦ w j, hvw j hji]
      congr 1
      exact hdep j (fun l hl => ih l (by have : (l : ℕ) < j := hl; omega)
        (le_of_lt (lt_of_lt_of_le hl hji)))
  exact key (i + 1) i (Nat.lt_succ_self _) le_rfl

theorem measurable_triangularSol {θ : Fin k → (Fin k → ℝ) → ℝ} (hθ : ∀ i, Measurable (θ i)) :
    Measurable (triangularSol θ) := by
  have key : ∀ n, Measurable (fun v : Fin k → ℝ => (triangularStep θ v)^[n] v) := by
    intro n
    induction n with
    | zero => exact measurable_id'
    | succ n ih =>
      have : (fun v : Fin k → ℝ => (triangularStep θ v)^[n + 1] v) =
          fun v i => θ i ((triangularStep θ v)^[n] v) + v i := by
        funext v i
        rw [Function.iterate_succ_apply']
        rfl
      rw [this]
      exact measurable_pi_lambda _ fun i => ((hθ i).comp ih).add (measurable_pi_apply i)
  exact key k

theorem IsTriangularSol.measurable {θ : Fin k → (Fin k → ℝ) → ℝ} (hθ : ∀ i, Measurable (θ i))
    (hdep : ∀ i, DependsOn (θ i) (Set.Iio i)) {Φ : (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : IsTriangularSol θ Φ) : Measurable Φ := by
  rw [hΦ.eq hdep (isTriangularSol_triangularSol hdep)]
  exact measurable_triangularSol hθ

/-! ### Densities -/

/-- `∫⋯∫` of a product of one-variable functions over a set `s` of coordinates. -/
lemma lmarginal_prod_eq {f : Fin k → ℝ → ℝ≥0∞} (hf : ∀ i, Measurable (f i)) (s : Finset (Fin k))
    (x : Fin k → ℝ) :
    (∫⋯∫⁻_s, (fun y => ∏ i, f i (y i)) ∂(fun _ => volume)) x =
      (∏ i ∈ s, ∫⁻ t, f i t) * ∏ i ∈ Finset.univ \ s, f i (x i) := by
  classical
  induction s using Finset.induction generalizing x with
  | empty => simp
  | insert i s hi ih =>
    have hF : Measurable (fun y : Fin k → ℝ => ∏ i, f i (y i)) :=
      Finset.measurable_prod _ fun i _ => (hf i).comp (measurable_pi_apply i)
    rw [lmarginal_insert _ hF hi]
    simp_rw [ih]
    have hsplit : ∀ t : ℝ, ∏ l ∈ Finset.univ \ s, f l (Function.update x i t l) =
        f i t * ∏ l ∈ Finset.univ \ insert i s, f l (x l) := by
      intro t
      have hmem : i ∈ Finset.univ \ s := by simp [hi]
      rw [← Finset.mul_prod_erase _ _ hmem, Function.update_self]
      congr 1
      have : (Finset.univ \ s).erase i = Finset.univ \ insert i s := by
        ext l; simp only [Finset.mem_erase, Finset.mem_sdiff, Finset.mem_univ, true_and,
          Finset.mem_insert, not_or]; try tauto
      rw [this]
      refine Finset.prod_congr rfl fun l hl => ?_
      have hli : l ≠ i := by
        intro h; subst h; simp at hl
      rw [Function.update_of_ne hli]
    simp_rw [hsplit]
    rw [lintegral_const_mul _ (f := fun t => f i t * ∏ l ∈ Finset.univ \ insert i s, f l (x l))
      ((hf i).mul_const _), lintegral_mul_const _ (hf i), Finset.prod_insert hi]
    ring

/-- The indicator of a box times a product function is the product of the indicators. -/
lemma indicator_univ_pi_prod (s : Fin k → Set ℝ) (ρ : ℝ → ℝ≥0∞) (x : Fin k → ℝ) :
    (Set.univ.pi s).indicator (fun x => ∏ i, ρ (x i)) x = ∏ i, (s i).indicator ρ (x i) := by
  classical
  by_cases hx : x ∈ Set.univ.pi s
  · rw [Set.indicator_of_mem hx]
    refine Finset.prod_congr rfl fun i _ => ?_
    rw [Set.indicator_of_mem (hx i (Set.mem_univ i))]
  · rw [Set.indicator_of_notMem hx]
    simp only [Set.mem_univ_pi, not_forall] at hx
    obtain ⟨i, hi⟩ := hx
    exact (Finset.prod_eq_zero (Finset.mem_univ i) (Set.indicator_of_notMem hi _)).symm

/-- The product of `k` copies of an absolutely continuous law on `ℝ` (with a finite density) has the product
density. -/
theorem pi_withDensity {ρ : ℝ → ℝ≥0∞} (hρ : Measurable ρ) (hρ' : ∀ x, ρ x ≠ ∞) :
    Measure.pi (fun _ : Fin k => volume.withDensity ρ) = volume.withDensity (fun x => ∏ i, ρ (x i)) := by
  classical
  have : SigmaFinite (volume.withDensity ρ) := SigmaFinite.withDensity_of_ne_top' hρ'
  refine Measure.pi_eq fun s hs => ?_
  have hbox : MeasurableSet (Set.univ.pi s) := MeasurableSet.univ_pi hs
  rw [withDensity_apply _ hbox, ← lintegral_indicator hbox]
  simp_rw [indicator_univ_pi_prod s ρ]
  rw [volume_pi, lintegral_eq_lmarginal_univ (0 : Fin k → ℝ),
    lmarginal_prod_eq (fun i => hρ.indicator (hs i)) Finset.univ]
  simp only [Finset.sdiff_self, Finset.prod_empty, mul_one]
  refine Finset.prod_congr rfl fun i _ => ?_
  rw [withDensity_apply _ (hs i), lintegral_indicator (hs i)]

/-- Density of an adaptive release law: if `ξ` has i.i.d. coordinates with (finite) density `ρ` and `Φ`
solves the release recursion `Φ ξ i = θ i (Φ ξ) + ξ i`, then the law of `Φ ξ` has density
`a ↦ ∏_i ρ(a_i - θ_i(a))` with respect to Lebesgue measure. -/
theorem map_triangularSol_pi_withDensity {ρ : ℝ → ℝ≥0∞} (hρ : Measurable ρ) (hρ' : ∀ x, ρ x ≠ ∞)
    {θ : Fin k → (Fin k → ℝ) → ℝ} (hθ : ∀ i, Measurable (θ i)) (hdep : ∀ i, DependsOn (θ i) (Set.Iio i))
    {Φ : (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : IsTriangularSol θ Φ) :
    (Measure.pi (fun _ : Fin k => volume.withDensity ρ)).map Φ =
      volume.withDensity (fun a => ∏ i, ρ (a i - θ i a)) := by
  classical
  have hΦm := hΦ.measurable hθ hdep
  rw [pi_withDensity hρ hρ']
  have hPm : Measurable (fun x : Fin k → ℝ => ∏ i, ρ (x i)) :=
    Finset.measurable_prod _ fun i _ => hρ.comp (measurable_pi_apply i)
  have hΨ : MeasurePreserving (fun a : Fin k → ℝ => fun i => a i - θ i a) volume volume := by
    have h := measurePreserving_triangular (g := fun i a => -θ i a) (fun i => (hθ i).neg)
      (fun i => fun x y hxy => by simp only; rw [hdep i hxy])
    simpa [sub_eq_add_neg] using h
  ext E hE
  rw [Measure.map_apply hΦm hE, withDensity_apply _ (hΦm hE), withDensity_apply _ hE,
    ← lintegral_indicator (hΦm hE), ← lintegral_indicator hE,
    ← hΨ.lintegral_comp (hPm.indicator (hΦm hE))]
  refine lintegral_congr fun a => ?_
  have h1 : Φ (fun i => a i - θ i a) = a := hΦ.apply_sub hdep a
  by_cases ha : a ∈ E
  · have ha' : (fun i => a i - θ i a) ∈ Φ ⁻¹' E := by simp only [Set.mem_preimage, h1]; exact ha
    rw [Set.indicator_of_mem ha', Set.indicator_of_mem ha]
  · have ha' : (fun i => a i - θ i a) ∉ Φ ⁻¹' E := by simp only [Set.mem_preimage, h1]; exact ha
    rw [Set.indicator_of_notMem ha', Set.indicator_of_notMem ha]

end F2e2e.A
