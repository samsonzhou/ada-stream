import F2e2e.Lib.Opt.EntropicBasic
import F2e2e.Lib.DP.Transfer

/-!
# Part I §5.2: the two-level tilted comparator and the DP expectation transfer (abstract form)

Paper: `parts/partI.tex` Lemma `I:lem:tilted_comparator` (L1668–1748); `notes/PAPER_MAP_I_c.md` I.5.2.

For a vector `f : Fin n → ℝ` (in the applications `f ℓ = F(h, X_{m,ℓ})`) and `ε ∈ ℝ` define (eq.
`I:eq:tilted_comparator_def`) the two-level tilt weights `w_ℓ = e^{-ε}` if `f ℓ ≥ 0`, `w_ℓ = e^{+ε}` if `f ℓ < 0`,
the partition function `Z = (1/n) ∑ w_ℓ` and the comparator `Q*(ℓ) = w_ℓ/(n Z)`.

* (1) `tiltZ_mem_Icc`, `tiltQ_mem_cappedSimplex`: `Z ∈ [e^{-ε}, e^{ε}]` and `Q* ∈ K₂` (for `0 ≤ ε ≤ ½ ln 2`; the paper
  assumes `0 < ε ≤ 0.05 < ½ ln 2`, see `one_twentieth_le_half_log_two`).
* (2) `klUnif_tiltQ_le`: `KL(Q* ‖ Unif) ≤ ε²/2`, for every real `ε`. Proof (different from the paper's calculus
  argument, same statement): with `g_ℓ = ∓1` (so `w_ℓ = e^{ε g_ℓ}`), `KL(Q*‖U) = ε E_{Q*}[g] - ln Z`, and Hoeffding's
  lemma under `Q*` for the `[0,1]`-valued `(1+g)/2` at parameter `-2ε` gives `e^{ε E_{Q*}g}/Z ≤ e^{ε²/2}`.
* the pointwise identity `tilt_identity` (eq. `I:eq:Zm_Qstar_separable`):
  `Z ⟨Q*, f⟩ = (1/n) ∑_ℓ [e^{-ε} f₊(ℓ) - e^{ε} f₋(ℓ)]` with `f₊ = max(f, 0)`, `f₋ = max(-f, 0)`.
* (3) `tilted_transfer`: if `S ↦ h` is an `(ε, δ)`-DP Markov kernel `κ` (single-coordinate replacement, `δ ≥ 0`) and
  `F : Y × X → [-1, 1]` is jointly measurable with `∫ F(h, x) dD(x) = 0` for every `h` (the paper's conditional
  zero-mean property `I:eq:F_zero_cond_mean`, in the pointwise form true in both applications), then
  `E_{S,h}[Z(S) ⟨Q*(S), F(h, S)⟩] ≤ (1 + e^{-ε}) δ` (eq. `I:eq:dp_transfer_bound`; `< 2δ` for `δ > 0`, `ε > 0`).
  `tilted_transfer_width`: if moreover `F(h, x) - F(h, x') ≤ 1` (range width one; true for
  `F = ∑ c_i(h)(q_i - μ_i)` with `∑|c_i| ≤ 1`, `width_le_one_of_linComb`) and `ε ≥ 0`, the bound is `δ`
  (the paired-test refinement, via `DP.dpTransfer`).
-/

namespace F2e2e.A

open Finset MeasureTheory ProbabilityTheory

section TiltDefs

variable {n : ℕ}

/-- The two-level tilt weight `w_ℓ = e^{-ε}` if `f ℓ ≥ 0`, `e^{+ε}` if `f ℓ < 0` (eq. `I:eq:tilted_comparator_def`). -/
noncomputable def tiltW (ε : ℝ) (f : Fin n → ℝ) (ℓ : Fin n) : ℝ :=
  if 0 ≤ f ℓ then Real.exp (-ε) else Real.exp ε

/-- The empirical partition function `Z = (1/n) ∑_ℓ w_ℓ`. -/
noncomputable def tiltZ (ε : ℝ) (f : Fin n → ℝ) : ℝ := (1 / (n : ℝ)) * ∑ ℓ, tiltW ε f ℓ

/-- The two-level tilted comparator `Q*(ℓ) = w_ℓ / (n Z)`. -/
noncomputable def tiltQ (ε : ℝ) (f : Fin n → ℝ) : Fin n → ℝ := fun ℓ => tiltW ε f ℓ / ((n : ℝ) * tiltZ ε f)

lemma tiltW_pos (ε : ℝ) (f : Fin n → ℝ) (ℓ : Fin n) : 0 < tiltW ε f ℓ := by
  unfold tiltW
  split_ifs <;> exact Real.exp_pos _

lemma tiltW_mem_Icc {ε : ℝ} (hε : 0 ≤ ε) (f : Fin n → ℝ) (ℓ : Fin n) :
    tiltW ε f ℓ ∈ Set.Icc (Real.exp (-ε)) (Real.exp ε) := by
  have h : Real.exp (-ε) ≤ Real.exp ε := Real.exp_le_exp.mpr (by linarith)
  unfold tiltW
  split_ifs
  · exact ⟨le_rfl, h⟩
  · exact ⟨h, le_rfl⟩

/-- `w_ℓ = e^{ε g_ℓ}` with `g_ℓ = -1` if `f ℓ ≥ 0` and `g_ℓ = +1` otherwise. -/
lemma tiltW_eq_exp (ε : ℝ) (f : Fin n → ℝ) (ℓ : Fin n) :
    tiltW ε f ℓ = Real.exp (ε * (2 * (if 0 ≤ f ℓ then (0 : ℝ) else 1) - 1)) := by
  unfold tiltW
  split_ifs <;> ring_nf

lemma sum_tiltW_pos (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) : 0 < ∑ ℓ, tiltW ε f ℓ :=
  Finset.sum_pos (fun ℓ _ => tiltW_pos ε f ℓ) (Finset.univ_nonempty_iff.mpr ⟨⟨0, hn⟩⟩)

lemma tiltZ_pos (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) : 0 < tiltZ ε f := by
  have : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  unfold tiltZ
  have := sum_tiltW_pos hn ε f
  positivity

lemma n_mul_tiltZ (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) : (n : ℝ) * tiltZ ε f = ∑ ℓ, tiltW ε f ℓ := by
  have : (n : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hn.ne'
  unfold tiltZ
  field_simp

/-- **Lemma `I:lem:tilted_comparator`(1), first half:** `Z ∈ [e^{-ε}, e^{ε}]` (for `ε ≥ 0`, `n ≥ 1`). -/
theorem tiltZ_mem_Icc (hn : 0 < n) {ε : ℝ} (hε : 0 ≤ ε) (f : Fin n → ℝ) :
    tiltZ ε f ∈ Set.Icc (Real.exp (-ε)) (Real.exp ε) := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have hlo : (n : ℝ) * Real.exp (-ε) ≤ ∑ ℓ, tiltW ε f ℓ := by
    calc (n : ℝ) * Real.exp (-ε) = ∑ _ℓ : Fin n, Real.exp (-ε) := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      _ ≤ ∑ ℓ, tiltW ε f ℓ := Finset.sum_le_sum fun ℓ _ => (tiltW_mem_Icc hε f ℓ).1
  have hhi : ∑ ℓ, tiltW ε f ℓ ≤ (n : ℝ) * Real.exp ε := by
    calc ∑ ℓ, tiltW ε f ℓ ≤ ∑ _ℓ : Fin n, Real.exp ε :=
          Finset.sum_le_sum fun ℓ _ => (tiltW_mem_Icc hε f ℓ).2
      _ = (n : ℝ) * Real.exp ε := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  unfold tiltZ
  constructor
  · rw [one_div, ← div_eq_inv_mul, le_div_iff₀ hn']
    linarith
  · rw [one_div, ← div_eq_inv_mul, div_le_iff₀ hn']
    linarith

lemma tiltQ_pos (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) (ℓ : Fin n) : 0 < tiltQ ε f ℓ := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have := tiltZ_pos hn ε f
  have := tiltW_pos ε f ℓ
  unfold tiltQ
  positivity

lemma sum_tiltQ (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) : ∑ ℓ, tiltQ ε f ℓ = 1 := by
  unfold tiltQ
  rw [← Finset.sum_div, n_mul_tiltZ hn, div_self (sum_tiltW_pos hn ε f).ne']

lemma tiltQ_mem_stdSimplex (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) :
    tiltQ ε f ∈ stdSimplex ℝ (Fin n) :=
  ⟨fun ℓ => (tiltQ_pos hn ε f ℓ).le, sum_tiltQ hn ε f⟩

/-- `0.05 ≤ ½ ln 2` (the paper's `ε_m ≤ 0.05 < ½ ln 2 ≈ 0.34657`). -/
lemma one_twentieth_le_half_log_two : (1 / 20 : ℝ) ≤ Real.log 2 / 2 := by
  have := Real.log_two_gt_d9
  linarith

/-- **Lemma `I:lem:tilted_comparator`(1), second half:** `Q* ∈ K₂` (for `0 ≤ ε ≤ ½ ln 2`): each coordinate is at most
`e^{ε}/(n e^{-ε}) = e^{2ε}/n ≤ 2/n`. -/
theorem tiltQ_mem_cappedSimplex (hn : 0 < n) {ε : ℝ} (hε : 0 ≤ ε) (hε2 : ε ≤ Real.log 2 / 2)
    (f : Fin n → ℝ) : tiltQ ε f ∈ Opt.cappedSimplex n := by
  refine ⟨tiltQ_mem_stdSimplex hn ε f, fun ℓ => ?_⟩
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have hZ := tiltZ_mem_Icc hn hε f
  have hW := tiltW_mem_Icc hε f ℓ
  have hZpos := tiltZ_pos hn ε f
  have h2 : Real.exp ε ≤ 2 * Real.exp (-ε) := by
    have h3 : Real.exp (2 * ε) ≤ 2 := by
      calc Real.exp (2 * ε) ≤ Real.exp (Real.log 2) := Real.exp_le_exp.mpr (by linarith)
        _ = 2 := Real.exp_log (by norm_num)
    have h4 : Real.exp (2 * ε) = Real.exp ε * Real.exp ε := by rw [← Real.exp_add]; ring_nf
    have h5 : Real.exp ε * Real.exp (-ε) = 1 := by rw [← Real.exp_add]; simp
    have h6 : 0 < Real.exp ε := Real.exp_pos ε
    nlinarith
  unfold tiltQ
  rw [div_le_div_iff₀ (by positivity) hn']
  calc tiltW ε f ℓ * (n : ℝ) ≤ Real.exp ε * n := by gcongr; exact hW.2
    _ ≤ 2 * Real.exp (-ε) * n := by gcongr
    _ ≤ 2 * ((n : ℝ) * tiltZ ε f) := by nlinarith [hZ.1]

/-- **Lemma `I:lem:tilted_comparator`(2):** `KL(Q* ‖ Unif) ≤ ε²/2`, deterministically and for every `ε ∈ ℝ`. -/
theorem klUnif_tiltQ_le (hn : 0 < n) (ε : ℝ) (f : Fin n → ℝ) :
    Opt.klUnif n (tiltQ ε f) ≤ ε ^ 2 / 2 := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  set Q := tiltQ ε f with hQdef
  set Z := tiltZ ε f with hZdef
  have hZpos : 0 < Z := tiltZ_pos hn ε f
  set v : Fin n → ℝ := fun ℓ => if 0 ≤ f ℓ then (0 : ℝ) else 1 with hvdef
  have hv01 : ∀ ℓ, v ℓ ∈ Set.Icc (0 : ℝ) 1 := fun ℓ => by
    simp only [hvdef]
    split_ifs <;> norm_num
  have hQs : Q ∈ stdSimplex ℝ (Fin n) := tiltQ_mem_stdSimplex hn ε f
  obtain ⟨vbar, hvbar⟩ : ∃ vbar : ℝ, vbar = ∑ ℓ, Q ℓ * v ℓ := ⟨_, rfl⟩
  -- `n Q ℓ = e^{ε g_ℓ}/Z` with `g_ℓ = 2 v_ℓ - 1`
  have hZne : tiltZ ε f ≠ 0 := (tiltZ_pos hn ε f).ne'
  have hnne : (n : ℝ) ≠ 0 := hn'.ne'
  have hnQ : ∀ ℓ, (n : ℝ) * Q ℓ = Real.exp (ε * (2 * v ℓ - 1)) / Z := by
    intro ℓ
    simp only [hQdef, tiltQ, hvdef, hZdef]
    rw [← tiltW_eq_exp]
    field_simp
  -- the KL divergence: `KL = ε (2 v̄ - 1) - ln Z`
  have hKL : Opt.klUnif n Q = ε * (2 * vbar - 1) - Real.log Z := by
    unfold Opt.klUnif
    have hterm : ∀ ℓ, Q ℓ * Real.log ((n : ℝ) * Q ℓ) = Q ℓ * (ε * (2 * v ℓ - 1)) - Q ℓ * Real.log Z := by
      intro ℓ
      rw [hnQ ℓ, Real.log_div (Real.exp_pos _).ne' hZpos.ne', Real.log_exp]
      ring
    rw [Finset.sum_congr rfl fun ℓ _ => hterm ℓ, Finset.sum_sub_distrib, ← Finset.sum_mul, hQs.2,
      one_mul]
    have : ∑ ℓ, Q ℓ * (ε * (2 * v ℓ - 1)) = ε * (2 * vbar - 1) := by
      have e1 : ∑ ℓ, Q ℓ * (ε * (2 * v ℓ - 1)) = (2 * ε) * ∑ ℓ, Q ℓ * v ℓ - ε * ∑ ℓ, Q ℓ := by
        rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
        exact Finset.sum_congr rfl fun ℓ _ => by ring
      rw [e1, hQs.2, ← hvbar]
      ring
    rw [this]
  -- Hoeffding under `Q` at parameter `-2ε`
  have hH := Opt.hoeffding_fin Q v hQs hv01 (-2 * ε)
  have hLHS : ∑ ℓ, Q ℓ * Real.exp (-2 * ε * (v ℓ - vbar)) = Real.exp (ε * (2 * vbar - 1)) / Z := by
    have hterm : ∀ ℓ, Q ℓ * Real.exp (-2 * ε * (v ℓ - vbar)) =
        Real.exp (ε * (2 * vbar - 1)) / Z * (1 / n) := by
      intro ℓ
      have hQ' : Q ℓ = Real.exp (ε * (2 * v ℓ - 1)) / Z / n := by
        rw [← hnQ ℓ]
        field_simp
      have : Real.exp (ε * (2 * v ℓ - 1)) * Real.exp (-2 * ε * (v ℓ - vbar)) =
          Real.exp (ε * (2 * vbar - 1)) := by
        rw [← Real.exp_add]
        ring_nf
      rw [hQ', div_div, div_mul_eq_mul_div, this]
      ring
    rw [Finset.sum_congr rfl fun ℓ _ => hterm ℓ, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    field_simp
  rw [← hvbar] at hH
  rw [hLHS] at hH
  have hexp : (-2 * ε) ^ 2 / 8 = ε ^ 2 / 2 := by ring
  rw [hexp] at hH
  rw [hKL]
  have h1 : Real.log (Real.exp (ε * (2 * vbar - 1)) / Z) ≤ ε ^ 2 / 2 := by
    calc Real.log (Real.exp (ε * (2 * vbar - 1)) / Z) ≤ Real.log (Real.exp (ε ^ 2 / 2)) :=
          Real.log_le_log (by positivity) hH
      _ = ε ^ 2 / 2 := Real.log_exp _
  rw [Real.log_div (Real.exp_pos _).ne' hZpos.ne', Real.log_exp] at h1
  exact h1

/-- **The pointwise tilt identity** (eqs. `I:eq:pointwise_tilt_identity`, `I:eq:Zm_Qstar_separable`):
`Z ⟨Q*, f⟩ = (1/n) ∑_ℓ [e^{-ε} max(f ℓ, 0) - e^{ε} max(-f ℓ, 0)]`. -/
theorem tilt_identity (ε : ℝ) (f : Fin n → ℝ) :
    tiltZ ε f * ∑ ℓ, tiltQ ε f ℓ * f ℓ =
      (1 / (n : ℝ)) * ∑ ℓ, (Real.exp (-ε) * max (f ℓ) 0 - Real.exp ε * max (-f ℓ) 0) := by
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    simp
  · have hZpos := tiltZ_pos hn ε f
    have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
    have hw : ∀ ℓ, tiltW ε f ℓ * f ℓ = Real.exp (-ε) * max (f ℓ) 0 - Real.exp ε * max (-f ℓ) 0 := by
      intro ℓ
      unfold tiltW
      split_ifs with h
      · rw [max_eq_left h, max_eq_right (by linarith)]
        ring
      · push Not at h
        rw [max_eq_right h.le, max_eq_left (by linarith)]
        ring
    rw [← Finset.sum_congr rfl fun ℓ _ => hw ℓ, Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun ℓ _ => ?_
    unfold tiltQ
    field_simp

end TiltDefs

/-! ### The DP expectation transfer -/

section Transfer

variable {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y] {n : ℕ}

/-- A measurable function bounded by `C` in absolute value is integrable for a finite measure. -/
lemma integrable_of_abs_le {α : Type*} [MeasurableSpace α] (μ : Measure α) [IsFiniteMeasure μ]
    {g : α → ℝ} (hg : AEStronglyMeasurable g μ) (C : ℝ) (hC : ∀ a, |g a| ≤ C) : Integrable g μ :=
  (integrable_const C).mono' hg (Filter.Eventually.of_forall fun a => by
    rw [Real.norm_eq_abs]; exact hC a)

/-- The integral of a function bounded by `C` against a probability measure is bounded by `C`. -/
lemma abs_integral_le_of_abs_le {α : Type*} [MeasurableSpace α] (μ : Measure α) [IsProbabilityMeasure μ]
    {g : α → ℝ} (C : ℝ) (hC : ∀ a, |g a| ≤ C) : |∫ a, g a ∂μ| ≤ C := by
  have h := norm_integral_le_of_norm_le_const (μ := μ) (f := g) (C := C)
    (Filter.Eventually.of_forall fun a => by rw [Real.norm_eq_abs]; exact hC a)
  rw [Real.norm_eq_abs] at h
  simpa using h

variable (D : Measure X) [IsProbabilityMeasure D] (κ : Kernel (Fin n → X) Y) [IsMarkovKernel κ]

/-- Integrability of the inner integrand `y ↦ ψ (a, y)` for a jointly measurable bounded `ψ`. -/
lemma integrable_inner {A : Type*} [MeasurableSpace A] (ν : Kernel A Y) [IsMarkovKernel ν]
    (ψ : A × Y → ℝ) (hψ : Measurable ψ) (hψ1 : ∀ q, |ψ q| ≤ 1) (a : A) :
    Integrable (fun y => ψ (a, y)) (ν a) :=
  integrable_of_abs_le _ (hψ.comp (measurable_prodMk_left)).aestronglyMeasurable 1 fun _ => hψ1 _

/-- Integrability of the outer integrand `a ↦ ∫ ψ (a, y) dν(a)` for a jointly measurable bounded `ψ`. -/
lemma integrable_outer {A : Type*} [MeasurableSpace A] (ν : Kernel A Y) [IsMarkovKernel ν]
    (μ : Measure A) [IsProbabilityMeasure μ] (ψ : A × Y → ℝ) (hψ : Measurable ψ)
    (hψ1 : ∀ q, |ψ q| ≤ 1) : Integrable (fun a => ∫ y, ψ (a, y) ∂(ν a)) μ :=
  integrable_of_abs_le _ (hψ.stronglyMeasurable.integral_kernel_prod_right').aestronglyMeasurable 1
    fun _ => abs_integral_le_of_abs_le _ 1 fun _ => hψ1 _

/-- The fresh-coordinate expectation of a centered functional vanishes:
`E_{S, X', h ∼ κ(S)}[F(h, X')] = 0` when `∫ F(h, x) dD(x) = 0` for every `h`. -/
lemma integral_fresh_eq_zero (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F))
    (hF1 : ∀ y x, |F y x| ≤ 1) (hF0 : ∀ y, ∫ x, F y x ∂D = 0) :
    ∫ p, ∫ y, F y p.2 ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D) = 0 := by
  set κ' : Kernel ((Fin n → X) × X) Y := κ.comap Prod.fst measurable_fst with hκ'
  have hψ : Measurable fun q : ((Fin n → X) × X) × Y => F q.2 q.1.2 :=
    hF.comp (measurable_snd.prodMk (measurable_snd.comp measurable_fst))
  have hint : Integrable (fun p : (Fin n → X) × X => ∫ y, F y p.2 ∂(κ p.1))
      ((Measure.pi fun _ : Fin n => D).prod D) := by
    have h := integrable_outer κ' ((Measure.pi fun _ : Fin n => D).prod D)
      (fun q => F q.2 q.1.2) hψ (fun q => hF1 _ _)
    simpa [hκ', Kernel.comap_apply] using h
  rw [integral_prod _ hint]
  refine integral_eq_zero_of_ae (Filter.Eventually.of_forall fun S => ?_)
  simp only [Pi.zero_apply]
  have hswap : Integrable (Function.uncurry fun (x : X) (y : Y) => F y x) (D.prod (κ S)) := by
    refine integrable_of_abs_le _ ?_ 1 fun q => hF1 _ _
    exact (hF.comp measurable_swap).aestronglyMeasurable
  rw [integral_integral_swap hswap]
  simp [hF0]

omit [IsMarkovKernel κ] in
/-- The expectation of a coordinate functional, viewed on the pair space `(S, X')`, is the expectation on `S`. -/
lemma integral_pair_fst (φ : Y → X → ℝ) (ℓ : Fin n) :
    ∫ p, ∫ y, φ y (p.1 ℓ) ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D) =
      ∫ S, ∫ y, φ y (S ℓ) ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) := by
  rw [integral_fun_fst (f := fun S : Fin n → X => ∫ y, φ y (S ℓ) ∂(κ S))]
  simp

/-- Zero mean on the fresh coordinate: `E f₊(h, X') = E f₋(h, X')` (`f₊ = max(F, 0)`, `f₋ = max(-F, 0)`). -/
lemma fresh_pos_eq_neg (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F))
    (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1) (hF0 : ∀ y, ∫ x, F y x ∂D = 0) :
    ∫ p, ∫ y, max (F y p.2) 0 ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D) =
      ∫ p, ∫ y, max (-F y p.2) 0 ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D) := by
  set μ := (Measure.pi fun _ : Fin n => D).prod D with hμ
  have hFabs : ∀ y x, |F y x| ≤ 1 := fun y x => abs_le.mpr (hF1 y x)
  have hfp : Measurable fun q : Y × X => max (F q.1 q.2) 0 := hF.max measurable_const
  have hfm : Measurable fun q : Y × X => max (-F q.1 q.2) 0 := hF.neg.max measurable_const
  set κ' : Kernel ((Fin n → X) × X) Y := κ.comap Prod.fst measurable_fst with hκ'
  have hint : ∀ g : Y → X → ℝ, Measurable (Function.uncurry g) → (∀ y x, |g y x| ≤ 1) →
      Integrable (fun p : (Fin n → X) × X => ∫ y, g y p.2 ∂(κ p.1)) μ := by
    intro g hg hg1
    have h := integrable_outer κ' μ (fun q => g q.2 q.1.2)
      (hg.comp (measurable_snd.prodMk (measurable_snd.comp measurable_fst))) (fun q => hg1 _ _)
    simpa [hκ', Kernel.comap_apply] using h
  have hinner : ∀ (g : Y → X → ℝ), Measurable (Function.uncurry g) → (∀ y x, |g y x| ≤ 1) →
      ∀ p : (Fin n → X) × X, Integrable (fun y => g y p.2) (κ p.1) := by
    intro g hg hg1 p
    exact integrable_of_abs_le _ (hg.comp (measurable_id.prodMk measurable_const)).aestronglyMeasurable 1
      fun _ => hg1 _ _
  have hfp1 : ∀ y x, |max (F y x) 0| ≤ 1 := fun y x => abs_le.mpr
    ⟨by linarith [le_max_right (F y x) 0], max_le (hF1 y x).2 zero_le_one⟩
  have hfm1 : ∀ y x, |max (-F y x) 0| ≤ 1 := fun y x => abs_le.mpr
    ⟨by linarith [le_max_right (-F y x) 0], max_le (by linarith [(hF1 y x).1]) zero_le_one⟩
  rw [← sub_eq_zero, ← integral_sub (hint (fun y x => max (F y x) 0) hfp hfp1)
    (hint (fun y x => max (-F y x) 0) hfm hfm1)]
  have heq : ∀ p : (Fin n → X) × X, ∫ y, max (F y p.2) 0 ∂(κ p.1) - ∫ y, max (-F y p.2) 0 ∂(κ p.1) =
      ∫ y, F y p.2 ∂(κ p.1) := by
    intro p
    rw [← integral_sub (hinner (fun y x => max (F y x) 0) hfp hfp1 p)
      (hinner (fun y x => max (-F y x) 0) hfm hfm1 p)]
    congr 1
    funext y
    exact max_zero_sub_eq_self (F y p.2)
  simp_rw [heq]
  exact integral_fresh_eq_zero D κ F hF hFabs hF0

/-- One-coordinate transfer: `e^{-ε} E f₊(h, X_ℓ) - e^{ε} E f₋(h, X_ℓ) ≤ (1 + e^{-ε}) δ`. -/
lemma tilted_transfer_coord {ε δ : ℝ} (hδ : 0 ≤ δ) (hDP : DP.IsDP DP.Neighbor (fun S => κ S) ε δ)
    (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F)) (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1)
    (hF0 : ∀ y, ∫ x, F y x ∂D = 0) (ℓ : Fin n) :
    Real.exp (-ε) * ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) -
        Real.exp ε * ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) ≤
      (1 + Real.exp (-ε)) * δ := by
  have hfp : Measurable fun q : Y × X => max (F q.1 q.2) 0 := hF.max measurable_const
  have hfm : Measurable fun q : Y × X => max (-F q.1 q.2) 0 := hF.neg.max measurable_const
  have hfp01 : ∀ y a, max (F y a) 0 ∈ Set.Icc (0 : ℝ) 1 := fun y a =>
    ⟨le_max_right _ _, max_le (hF1 y a).2 zero_le_one⟩
  have hfm01 : ∀ y a, max (-F y a) 0 ∈ Set.Icc (0 : ℝ) 1 := fun y a =>
    ⟨le_max_right _ _, max_le (by linarith [(hF1 y a).1]) zero_le_one⟩
  have hfwd := DP.dpTransfer_fwd D κ hδ hDP ℓ (fun y a => max (F y a) 0) hfp hfp01
  have hbwd := DP.dpTransfer_bwd D κ hδ hDP ℓ (fun y a => max (-F y a) 0) hfm hfm01
  rw [integral_pair_fst D κ (fun y a => max (F y a) 0) ℓ] at hfwd
  rw [integral_pair_fst D κ (fun y a => max (-F y a) 0) ℓ] at hbwd
  have hzero := fresh_pos_eq_neg D κ F hF hF1 hF0
  have he : Real.exp (-ε) * Real.exp ε = 1 := by rw [← Real.exp_add]; simp
  have hepos : 0 < Real.exp (-ε) := Real.exp_pos _
  set A := ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D)
  set B := ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D)
  set Cp := ∫ p, ∫ y, max (F y p.2) 0 ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D)
  set Cm := ∫ p, ∫ y, max (-F y p.2) 0 ∂(κ p.1) ∂((Measure.pi fun _ : Fin n => D).prod D)
  have h1 : Real.exp (-ε) * A ≤ Cp + Real.exp (-ε) * δ := by
    have := mul_le_mul_of_nonneg_left hfwd hepos.le
    calc Real.exp (-ε) * A ≤ Real.exp (-ε) * (Real.exp ε * Cp + δ) := this
      _ = (Real.exp (-ε) * Real.exp ε) * Cp + Real.exp (-ε) * δ := by ring
      _ = Cp + Real.exp (-ε) * δ := by rw [he, one_mul]
  have h2 : Cm ≤ Real.exp ε * B + δ := hbwd
  linarith

/-- One-coordinate transfer with the paired test (width-one refinement):
`e^{-ε} E f₊(h, X_ℓ) - e^{ε} E f₋(h, X_ℓ) ≤ δ`. -/
lemma tilted_transfer_coord_width {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 ≤ δ)
    (hDP : DP.IsDP DP.Neighbor (fun S => κ S) ε δ)
    (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F)) (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1)
    (hF0 : ∀ y, ∫ x, F y x ∂D = 0) (hwidth : ∀ y x x', F y x - F y x' ≤ 1) (ℓ : Fin n) :
    Real.exp (-ε) * ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) -
        Real.exp ε * ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) ≤ δ := by
  set μ := (Measure.pi fun _ : Fin n => D).prod D with hμ
  have hepos : 0 < Real.exp (-ε) := Real.exp_pos _
  have hele : Real.exp (-ε) ≤ 1 := by
    rw [Real.exp_le_one_iff]
    linarith
  have he : Real.exp ε * Real.exp (-ε) = 1 := by rw [← Real.exp_add]; simp
  -- the paired test `g(y, a, a') = e^{-ε} f₊(y, a) + f₋(y, a') ∈ [0, 1]`
  set g : Y → X → X → ℝ := fun y a a' => Real.exp (-ε) * max (F y a) 0 + max (-F y a') 0 with hg
  have hgm : Measurable fun q : Y × X × X => g q.1 q.2.1 q.2.2 := by
    have h1 : Measurable fun q : Y × X × X => F q.1 q.2.1 :=
      hF.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    have h2 : Measurable fun q : Y × X × X => F q.1 q.2.2 :=
      hF.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
    exact ((h1.max measurable_const).const_mul _).add (h2.neg.max measurable_const)
  have hg01 : ∀ y a a', g y a a' ∈ Set.Icc (0 : ℝ) 1 := by
    intro y a a'
    have hp0 : 0 ≤ max (F y a) 0 := le_max_right _ _
    have hm0 : 0 ≤ max (-F y a') 0 := le_max_right _ _
    refine ⟨by positivity, ?_⟩
    have hw := hwidth y a a'
    have ha := hF1 y a
    have ha' := hF1 y a'
    calc g y a a' ≤ max (F y a) 0 + max (-F y a') 0 := by
          simp only [hg]
          nlinarith
      _ ≤ 1 := by
          rcases le_total 0 (F y a) with h1 | h1 <;> rcases le_total 0 (F y a') with h2 | h2
          · rw [max_eq_left h1, max_eq_right (by linarith)]; linarith [ha.2]
          · rw [max_eq_left h1, max_eq_left (by linarith)]; linarith
          · rw [max_eq_right h1, max_eq_right (by linarith)]; linarith
          · rw [max_eq_right h1, max_eq_left (by linarith)]; linarith [ha'.1]
  have hpair := DP.dpTransfer D κ hδ hDP ℓ g hgm hg01
  -- linearity on the pair space
  set κ' : Kernel ((Fin n → X) × X) Y := κ.comap Prod.fst measurable_fst with hκ'
  have hFabs : ∀ y x, |F y x| ≤ 1 := fun y x => abs_le.mpr (hF1 y x)
  have hbdp : ∀ y x, |max (F y x) 0| ≤ 1 := fun y x => abs_le.mpr
    ⟨by linarith [le_max_right (F y x) 0], max_le (hF1 y x).2 zero_le_one⟩
  have hbdm : ∀ y x, |max (-F y x) 0| ≤ 1 := fun y x => abs_le.mpr
    ⟨by linarith [le_max_right (-F y x) 0], max_le (by linarith [(hF1 y x).1]) zero_le_one⟩
  have hfpm : Measurable fun q : Y × X => max (F q.1 q.2) 0 := hF.max measurable_const
  have hfmm : Measurable fun q : Y × X => max (-F q.1 q.2) 0 := hF.neg.max measurable_const
  -- generic integrability on the pair space for `q ↦ φ (q.2, c(q.1))`
  have hint_out : ∀ (φ : Y × X → ℝ) (c : (Fin n → X) × X → X), Measurable φ → Measurable c →
      (∀ q, |φ q| ≤ 1) → Integrable (fun p : (Fin n → X) × X => ∫ y, φ (y, c p) ∂(κ p.1)) μ := by
    intro φ c hφ hc hφ1
    have h := integrable_outer κ' μ (fun q => φ (q.2, c q.1))
      (hφ.comp (measurable_snd.prodMk (hc.comp measurable_fst))) (fun q => hφ1 _)
    simpa [hκ', Kernel.comap_apply] using h
  have hint_in : ∀ (φ : Y × X → ℝ) (c : (Fin n → X) × X → X), Measurable φ → (∀ q, |φ q| ≤ 1) →
      ∀ p, Integrable (fun y => φ (y, c p)) (κ p.1) := by
    intro φ c hφ hφ1 p
    exact integrable_of_abs_le _ (hφ.comp (measurable_id.prodMk measurable_const)).aestronglyMeasurable 1
      fun _ => hφ1 _
  have hc1 : Measurable fun p : (Fin n → X) × X => p.1 ℓ := (measurable_pi_apply ℓ).comp measurable_fst
  have hc2 : Measurable fun p : (Fin n → X) × X => p.2 := measurable_snd
  -- `∫∫ (a φ₁(y, c₁ p) + φ₂(y, c₂ p)) = a ∫∫ φ₁ + ∫∫ φ₂`
  have hlin : ∀ (a : ℝ) (φ₁ φ₂ : Y × X → ℝ) (c₁ c₂ : (Fin n → X) × X → X), Measurable φ₁ → Measurable φ₂ →
      Measurable c₁ → Measurable c₂ → (∀ q, |φ₁ q| ≤ 1) → (∀ q, |φ₂ q| ≤ 1) →
      ∫ p, ∫ y, (a * φ₁ (y, c₁ p) + φ₂ (y, c₂ p)) ∂(κ p.1) ∂μ =
        a * ∫ p, ∫ y, φ₁ (y, c₁ p) ∂(κ p.1) ∂μ + ∫ p, ∫ y, φ₂ (y, c₂ p) ∂(κ p.1) ∂μ := by
    intro a φ₁ φ₂ c₁ c₂ h₁ h₂ hc₁ hc₂ b₁ b₂
    have hin : ∀ p, ∫ y, (a * φ₁ (y, c₁ p) + φ₂ (y, c₂ p)) ∂(κ p.1) =
        a * ∫ y, φ₁ (y, c₁ p) ∂(κ p.1) + ∫ y, φ₂ (y, c₂ p) ∂(κ p.1) := by
      intro p
      rw [integral_add ((hint_in φ₁ c₁ h₁ b₁ p).const_mul a) (hint_in φ₂ c₂ h₂ b₂ p), integral_const_mul]
    simp_rw [hin]
    rw [integral_add ((hint_out φ₁ c₁ h₁ hc₁ b₁).const_mul a) (hint_out φ₂ c₂ h₂ hc₂ b₂),
      integral_const_mul]
  have hL : ∫ p, ∫ y, g y (p.1 ℓ) p.2 ∂(κ p.1) ∂μ =
      Real.exp (-ε) * ∫ p, ∫ y, max (F y (p.1 ℓ)) 0 ∂(κ p.1) ∂μ +
        ∫ p, ∫ y, max (-F y p.2) 0 ∂(κ p.1) ∂μ :=
    hlin (Real.exp (-ε)) (fun q => max (F q.1 q.2) 0) (fun q => max (-F q.1 q.2) 0)
      (fun p => p.1 ℓ) (fun p => p.2) hfpm hfmm hc1 hc2 (fun q => hbdp _ _) (fun q => hbdm _ _)
  have hR : ∫ p, ∫ y, g y p.2 (p.1 ℓ) ∂(κ p.1) ∂μ =
      Real.exp (-ε) * ∫ p, ∫ y, max (F y p.2) 0 ∂(κ p.1) ∂μ +
        ∫ p, ∫ y, max (-F y (p.1 ℓ)) 0 ∂(κ p.1) ∂μ :=
    hlin (Real.exp (-ε)) (fun q => max (F q.1 q.2) 0) (fun q => max (-F q.1 q.2) 0)
      (fun p => p.2) (fun p => p.1 ℓ) hfpm hfmm hc2 hc1 (fun q => hbdp _ _) (fun q => hbdm _ _)
  rw [hL, hR, integral_pair_fst D κ (fun y a => max (F y a) 0) ℓ,
    integral_pair_fst D κ (fun y a => max (-F y a) 0) ℓ] at hpair
  have hzero := fresh_pos_eq_neg D κ F hF hF1 hF0
  set A := ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D)
  set B := ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D)
  set Cp := ∫ p, ∫ y, max (F y p.2) 0 ∂(κ p.1) ∂μ
  set Cm := ∫ p, ∫ y, max (-F y p.2) 0 ∂(κ p.1) ∂μ
  -- `e^{-ε} A + Cm ≤ e^{ε} (e^{-ε} Cp + B) + δ = Cp + e^{ε} B + δ`
  have h3 : Real.exp ε * (Real.exp (-ε) * Cp + B) = Cp + Real.exp ε * B := by
    rw [mul_add, ← mul_assoc, he, one_mul]
  rw [h3] at hpair
  linarith

/-- The tilted integral is the average of the coordinate pieces, hence bounded by any common bound of the
coordinate pieces. -/
lemma tilted_le_of_coord {ε C : ℝ} (hC : 0 ≤ C) (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F))
    (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1)
    (hcoord : ∀ ℓ : Fin n, Real.exp (-ε) * ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) -
        Real.exp ε * ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂(Measure.pi fun _ : Fin n => D) ≤ C) :
    ∫ S, ∫ y, tiltZ ε (fun ℓ => F y (S ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (S ℓ)) ℓ * F y (S ℓ) ∂(κ S)
        ∂(Measure.pi fun _ : Fin n => D) ≤ C := by
  set μS := Measure.pi fun _ : Fin n => D with hμS
  have hFabs : ∀ y x, |F y x| ≤ 1 := fun y x => abs_le.mpr (hF1 y x)
  -- the integrand, rewritten by the tilt identity
  set g : (Fin n → X) → Y → ℝ := fun S y =>
    (1 / (n : ℝ)) * ∑ ℓ, (Real.exp (-ε) * max (F y (S ℓ)) 0 - Real.exp ε * max (-F y (S ℓ)) 0) with hg
  have hid : ∀ S y, tiltZ ε (fun ℓ => F y (S ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (S ℓ)) ℓ * F y (S ℓ) = g S y :=
    fun S y => tilt_identity ε (fun ℓ => F y (S ℓ))
  simp_rw [hid]
  -- measurability / boundedness of the coordinate pieces
  have hplus : ∀ ℓ : Fin n, Measurable fun q : (Fin n → X) × Y => max (F q.2 (q.1 ℓ)) 0 := fun ℓ =>
    (hF.comp (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))).max measurable_const
  have hminus : ∀ ℓ : Fin n, Measurable fun q : (Fin n → X) × Y => max (-F q.2 (q.1 ℓ)) 0 := fun ℓ =>
    (hF.comp (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))).neg.max
      measurable_const
  have hbp : ∀ (q : (Fin n → X) × Y) (ℓ : Fin n), |max (F q.2 (q.1 ℓ)) 0| ≤ 1 := fun q ℓ =>
    abs_le.mpr ⟨by linarith [le_max_right (F q.2 (q.1 ℓ)) 0], max_le (hF1 _ _).2 zero_le_one⟩
  have hbm : ∀ (q : (Fin n → X) × Y) (ℓ : Fin n), |max (-F q.2 (q.1 ℓ)) 0| ≤ 1 := fun q ℓ =>
    abs_le.mpr ⟨by linarith [le_max_right (-F q.2 (q.1 ℓ)) 0],
      max_le (by linarith [(hF1 q.2 (q.1 ℓ)).1]) zero_le_one⟩
  -- inner integral
  have hinner : ∀ S, ∫ y, g S y ∂(κ S) = (1 / (n : ℝ)) * ∑ ℓ,
      (Real.exp (-ε) * ∫ y, max (F y (S ℓ)) 0 ∂(κ S) - Real.exp ε * ∫ y, max (-F y (S ℓ)) 0 ∂(κ S)) := by
    intro S
    simp only [hg]
    rw [integral_const_mul, integral_finsetSum]
    · congr 1
      refine Finset.sum_congr rfl fun ℓ _ => ?_
      rw [integral_sub, integral_const_mul, integral_const_mul]
      · exact (integrable_inner κ _ (hplus ℓ) (fun q => hbp q ℓ) S).const_mul _
      · exact (integrable_inner κ _ (hminus ℓ) (fun q => hbm q ℓ) S).const_mul _
    · intro ℓ _
      exact ((integrable_inner κ _ (hplus ℓ) (fun q => hbp q ℓ) S).const_mul _).sub
        ((integrable_inner κ _ (hminus ℓ) (fun q => hbm q ℓ) S).const_mul _)
  simp_rw [hinner]
  -- outer integral
  have houter : ∫ S, (1 / (n : ℝ)) * ∑ ℓ, (Real.exp (-ε) * ∫ y, max (F y (S ℓ)) 0 ∂(κ S) -
      Real.exp ε * ∫ y, max (-F y (S ℓ)) 0 ∂(κ S)) ∂μS =
      (1 / (n : ℝ)) * ∑ ℓ, (Real.exp (-ε) * ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂μS -
        Real.exp ε * ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂μS) := by
    rw [integral_const_mul, integral_finsetSum]
    · congr 1
      refine Finset.sum_congr rfl fun ℓ _ => ?_
      rw [integral_sub, integral_const_mul, integral_const_mul]
      · exact (integrable_outer κ μS _ (hplus ℓ) (fun q => hbp q ℓ)).const_mul _
      · exact (integrable_outer κ μS _ (hminus ℓ) (fun q => hbm q ℓ)).const_mul _
    · intro ℓ _
      exact ((integrable_outer κ μS _ (hplus ℓ) (fun q => hbp q ℓ)).const_mul _).sub
        ((integrable_outer κ μS _ (hminus ℓ) (fun q => hbm q ℓ)).const_mul _)
  rw [houter]
  -- average the one-coordinate bounds
  have hsum : ∑ ℓ : Fin n, (Real.exp (-ε) * ∫ S, ∫ y, max (F y (S ℓ)) 0 ∂(κ S) ∂μS -
      Real.exp ε * ∫ S, ∫ y, max (-F y (S ℓ)) 0 ∂(κ S) ∂μS) ≤ (n : ℝ) * C := by
    calc _ ≤ ∑ _ℓ : Fin n, C := Finset.sum_le_sum fun ℓ _ => hcoord ℓ
      _ = (n : ℝ) * C := by
        rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    simp only [Finset.univ_eq_empty, Finset.sum_empty, mul_zero]
    exact hC
  · have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
    calc (1 / (n : ℝ)) * _ ≤ (1 / (n : ℝ)) * ((n : ℝ) * C) :=
          mul_le_mul_of_nonneg_left hsum (by positivity)
      _ = C := by field_simp

/-- **Lemma `I:lem:tilted_comparator`(3)** (two-sided single-coordinate DP expectation transfer, eq.
`I:eq:dp_transfer_bound`): for an `(ε, δ)`-DP Markov kernel `κ` from samples `S ∼ D^n` to transcripts and a jointly
measurable `F : Y → X → [-1, 1]` with `∫ F(h, x) dD(x) = 0` for every `h`,
`E_{S, h ∼ κ(S)}[Z(S) ⟨Q*(S), F(h, S)⟩] ≤ (1 + e^{-ε}) δ`, where `Z`, `Q*` are built from `ℓ ↦ F(h, S ℓ)`. -/
theorem tilted_transfer {ε δ : ℝ} (hδ : 0 ≤ δ) (hDP : DP.IsDP DP.Neighbor (fun S => κ S) ε δ)
    (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F)) (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1)
    (hF0 : ∀ y, ∫ x, F y x ∂D = 0) :
    ∫ S, ∫ y, tiltZ ε (fun ℓ => F y (S ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (S ℓ)) ℓ * F y (S ℓ) ∂(κ S)
        ∂(Measure.pi fun _ : Fin n => D) ≤ (1 + Real.exp (-ε)) * δ :=
  tilted_le_of_coord D κ (mul_nonneg (by positivity) hδ) F hF hF1
    (fun ℓ => tilted_transfer_coord D κ hδ hDP F hF hF1 hF0 ℓ)

/-- `(1 + e^{-ε}) δ < 2 δ` for `ε, δ > 0` (the paper's "`< 2δ_m`"). -/
lemma one_add_exp_neg_mul_lt {ε δ : ℝ} (hε : 0 < ε) (hδ : 0 < δ) : (1 + Real.exp (-ε)) * δ < 2 * δ := by
  have : Real.exp (-ε) < 1 := by
    rw [Real.exp_lt_one_iff]
    linarith
  nlinarith

omit [MeasurableSpace X] in
/-- Functionals `F = ∑ c_i (q_i - μ_i)` with `q_i ∈ [0,1]` and `∑ |c_i| ≤ 1` have range width at most one:
`F(x) - F(x') ≤ 1` (the hypothesis of the width-one refinement of Lemma `I:lem:tilted_comparator`(3)). -/
lemma width_le_one_of_linComb {ι : Type*} (s : Finset ι) (c μ : ι → ℝ) (q : ι → X → ℝ)
    (hq : ∀ i x, q i x ∈ Set.Icc (0 : ℝ) 1) (hc : ∑ i ∈ s, |c i| ≤ 1) (x x' : X) :
    ∑ i ∈ s, c i * (q i x - μ i) - ∑ i ∈ s, c i * (q i x' - μ i) ≤ 1 := by
  rw [← Finset.sum_sub_distrib]
  calc ∑ i ∈ s, (c i * (q i x - μ i) - c i * (q i x' - μ i)) ≤ ∑ i ∈ s, |c i| := by
        refine Finset.sum_le_sum fun i _ => ?_
        have h1 : c i * (q i x - μ i) - c i * (q i x' - μ i) = c i * (q i x - q i x') := by ring
        rw [h1]
        have h2 : |q i x - q i x'| ≤ 1 := by
          rw [abs_le]
          constructor <;> linarith [(hq i x).1, (hq i x).2, (hq i x').1, (hq i x').2]
        calc c i * (q i x - q i x') ≤ |c i * (q i x - q i x')| := le_abs_self _
          _ = |c i| * |q i x - q i x'| := abs_mul _ _
          _ ≤ |c i| * 1 := by gcongr
          _ = |c i| := mul_one _
    _ ≤ 1 := hc

/-- **Lemma `I:lem:tilted_comparator`(3), width-one refinement** (paired test `g_{x,y} = e^{-ε} f₊(h, x) + f₋(h, y)`):
if moreover `ε ≥ 0` and `F(h, x) - F(h, x') ≤ 1` for all `h, x, x'` (e.g. `F = ∑ c_i(h)(q_i - μ_i)` with
`∑ |c_i(h)| ≤ 1`, `width_le_one_of_linComb`), then `E_{S, h ∼ κ(S)}[Z(S) ⟨Q*(S), F(h, S)⟩] ≤ δ`. -/
theorem tilted_transfer_width {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 ≤ δ)
    (hDP : DP.IsDP DP.Neighbor (fun S => κ S) ε δ)
    (F : Y → X → ℝ) (hF : Measurable (Function.uncurry F)) (hF1 : ∀ y x, F y x ∈ Set.Icc (-1 : ℝ) 1)
    (hF0 : ∀ y, ∫ x, F y x ∂D = 0) (hwidth : ∀ y x x', F y x - F y x' ≤ 1) :
    ∫ S, ∫ y, tiltZ ε (fun ℓ => F y (S ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (S ℓ)) ℓ * F y (S ℓ) ∂(κ S)
        ∂(Measure.pi fun _ : Fin n => D) ≤ δ :=
  tilted_le_of_coord D κ hδ F hF hF1
    (fun ℓ => tilted_transfer_coord_width D κ hε hδ hDP F hF hF1 hF0 hwidth ℓ)

end Transfer

end F2e2e.A
