import F2e2e.A.Chain

/-!
# Part I §4, deterministic core: one round of the first-trigger chain on the clean event

Owner: A-ACC. Paper: `parts/partI.tex` L1148-1531 (Section 4); the mechanism is Definition
`I:def:mechanism` (L293-393, `F2e2e/A/Mechanism.lean`).

Section 4 is purely deterministic: every statement is a sample-path inequality on `E_clean`. This file
proves the round-level statements for an arbitrary `ChainData` (the inputs of the first-trigger chain of
one active round) under
* the clean-round envelopes `|ρ^{(r)}| ≤ u₀`, `|ν_i^{(r)}| ≤ 2u₀`, `|ζ_i^{(r)}| ≤ u₀` for the stages
  `2 ≤ r ≤ L` (`I:eq:sec4_clean_envelopes`, L1166-1171): `ChainData.Clean`;
* `θ_i^{(r)}(S_r) ∈ [0,1]` for `1 ≤ r ≤ L` (`I:eq:theta_def`): `ChainData.ThetaMem`;
with the thresholds `d.tau` left abstract. The specialization to the locked threshold matrix
(`adaTau`, Lemma `I:lem:threshold_properties`) is in `F2e2e/A/AccuracyRound.lean`; the run-level
statements are in `F2e2e/A/Accuracy.lean` and `F2e2e/A/Progress.lean`.

## Main results
* I.4.1(i): `ChainData.abs_relC_sub_theta_le`, `ChainData.relC_fidelity` (`I:eq:sec4_cm_fidelity`).
* Pass/trigger atoms: `ChainData.pass_bound(_abs)`, `ChainData.trigger_gap(_abs)`, `ChainData.pass_gap(_abs)`.
* I.4.1(ii): `ChainData.answer_pass_bound(_abs)` (`I:eq:sec4_upper_pass_bound`),
  `ChainData.abs_answer_sub_thetaL_le` (`I:eq:sec4_ai_minus_thetaL`), `ChainData.abs_answer_sub_mu_le`
  (`I:eq:sec4_ai_accuracy`, first inequality).
* I.4.2 (Case A): `ChainData.caseA_gap(_abs)` (`I:eq:sec4_caseA_c1_c2_gap`), `ChainData.caseA_drift_ge`
  (the decomposition of L1313-1316), `ChainData.sgn_of_caseA`.
* I.4.5(2)-(4) (Case B): `ChainData.caseB_trigger_gap` (`I:eq:sec4_4u0_trigger_lb`),
  `ChainData.caseB_pass_gap` (`I:eq:sec4_4u0_pass_ub`), `ChainData.caseB_cprev_of_eq` (reuse case),
  `ChainData.caseB_adj_gap` (`I:eq:sec4_interior_adj_gap` before the threshold identity),
  `ChainData.caseB_terminal_gap` (`I:eq:sec4_terminal_adj_gap` before the threshold identity).
* Progress algebra: `progSummand` (the round summand of `I:eq:sec4_prog_mi_def`),
  `ChainData.progSum_of_ufinal_le_two` (I.4.5(1)), `ChainData.progSum_caseB_interior`
  (`I:eq:sec4_linear_mu_cancel` + the deductions), `ChainData.progSum_caseB_terminal`.

The [CHAIN] facts (first-trigger chain semantics) are those of `F2e2e/A/Chain.lean` (owner A-ARCH).
-/

namespace F2e2e

namespace A

/-! ## The paper's sign (L297): helpers -/

theorem neg_abs_le_sgn1_mul (x y : ℝ) : -|y| ≤ sgn1 x * y := by
  unfold sgn1
  split_ifs
  · rw [one_mul]
    exact neg_abs_le y
  · have := le_abs_self y
    linarith

theorem sgn1_mul_le_abs (x y : ℝ) : sgn1 x * y ≤ |y| := by
  unfold sgn1
  split_ifs
  · rw [one_mul]
    exact le_abs_self y
  · have := neg_abs_le y
    linarith

/-- If `sign(x) · y > 0` then `sign(y) = sign(x)`. -/
theorem sgn1_eq_of_pos_mul {x y : ℝ} (h : 0 < sgn1 x * y) : sgn1 y = sgn1 x := by
  by_cases hx : 0 ≤ x
  · have h1 : sgn1 x = 1 := if_pos hx
    rw [h1, one_mul] at h
    rw [h1]
    exact if_pos h.le
  · have h1 : sgn1 x = -1 := if_neg hx
    rw [h1] at h
    rw [h1]
    exact if_neg (not_le.mpr (by linarith))

/-! ## Clean rounds -/

namespace ChainData

variable (d : ChainData)

/-- The clean-round envelopes (`I:eq:sec4_clean_envelopes`, L1166-1171) for the Laplace noises used in
the round by the validator stages `2 ≤ r ≤ L`: `|ρ^{(r)}| ≤ u₀`, `|ν_i^{(r)}| ≤ 2u₀`, `|ζ_i^{(r)}| ≤ u₀`. -/
def Clean (u0 : ℝ) : Prop :=
  ∀ r, 2 ≤ r → r ≤ d.L → |d.rho r| ≤ u0 ∧ |d.nu r| ≤ 2 * u0 ∧ |d.zeta r| ≤ u0

/-- The start-of-round means lie in `[0,1]` (`I:eq:theta_def`; Lemma `I:lem:output_accuracy`(i)). -/
def ThetaMem : Prop := ∀ r, 1 ≤ r → r ≤ d.L → 0 ≤ d.theta r ∧ d.theta r ≤ 1

variable {d}

theorem Clean.u0_nonneg {u0 : ℝ} (hc : d.Clean u0) (hL : 2 ≤ d.L) : 0 ≤ u0 :=
  (abs_nonneg _).trans (hc 2 le_rfl hL).1

/-! ## I.4.1(i): clipping fidelity -/

/-- Clipping a validator release is non-expansive toward its mean:
`|c^{(r)} - θ_r| ≤ |v^{(r)} - θ_r| = |ζ_r|` (L1228-1232). -/
theorem abs_relC_sub_theta_le {r : ℕ} (h0 : 0 ≤ d.theta r) (h1 : d.theta r ≤ 1) :
    |d.relC r - d.theta r| ≤ |d.zeta r| := by
  have h := abs_clip01_sub_le (d.relV r) ⟨h0, h1⟩
  have e : d.relV r - d.theta r = d.zeta r := by
    unfold relV
    ring
  rw [e] at h
  exact h

/-- Lemma `I:lem:output_accuracy`(i), `I:eq:sec4_cm_fidelity`: on a clean round every validator release
satisfies `|c^{(r)} - θ_r| ≤ u₀`. -/
theorem relC_fidelity {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) {r : ℕ} (h2 : 2 ≤ r)
    (hrL : r ≤ d.L) : |d.relC r - d.theta r| ≤ u0 := by
  obtain ⟨h0, h1⟩ := hθ r (by omega) hrL
  exact (abs_relC_sub_theta_le h0 h1).trans (hc r h2 hrL).2.2

/-! ## The AboveThreshold test: pass and trigger atoms -/

theorem fires_iff {r u : ℕ} {cu : ℝ} :
    d.Fires r u cu ↔ d.tau u r + d.rho r ≤ |cu - d.theta r| + d.nu r := Iff.rfl

/-- A PASS (`I:eq:svt_test` fails): `|c^{(u)} - θ_s| < τ_{(u,s)} + ρ_s - ν_s`. -/
theorem abs_sub_theta_lt_of_not_fires {s u : ℕ} {cu : ℝ} (h : ¬ d.Fires s u cu) :
    |cu - d.theta s| < d.tau u s + d.rho s - d.nu s := by
  rw [fires_iff, not_le] at h
  linarith

/-- A PASS: `|c^{(u)} - θ_s| ≤ τ_{(u,s)} + |ρ_s| + |ν_s|`. -/
theorem pass_bound_abs {s u : ℕ} {cu : ℝ} (h : ¬ d.Fires s u cu) :
    |cu - d.theta s| ≤ d.tau u s + |d.rho s| + |d.nu s| := by
  have h1 := abs_sub_theta_lt_of_not_fires h
  have h2 := le_abs_self (d.rho s)
  have h3 := neg_abs_le (d.nu s)
  linarith

/-- A PASS on a clean round: `|c^{(u)} - θ_s| ≤ τ_{(u,s)} + 3u₀`. -/
theorem pass_bound {u0 : ℝ} (hc : d.Clean u0) {s u : ℕ} {cu : ℝ} (h2 : 2 ≤ s) (hsL : s ≤ d.L)
    (h : ¬ d.Fires s u cu) : |cu - d.theta s| ≤ d.tau u s + 3 * u0 := by
  have h1 := pass_bound_abs h
  obtain ⟨hr, hn, -⟩ := hc s h2 hsL
  linarith

/-- A TRIGGER followed by the clipped release of the same stage:
`|c^{(u)} - c^{(r)}| ≥ τ_{(u,r)} - |ρ_r| - |ν_r| - |c^{(r)} - θ_r|`. -/
theorem trigger_gap_abs {r u : ℕ} {cu : ℝ} (h : d.Fires r u cu) :
    d.tau u r - |d.rho r| - |d.nu r| - |d.relC r - d.theta r| ≤ |cu - d.relC r| := by
  rw [fires_iff] at h
  have h1 := abs_sub_le cu (d.relC r) (d.theta r)
  have h2 := neg_abs_le (d.rho r)
  have h3 := le_abs_self (d.nu r)
  linarith

/-- A TRIGGER on a clean round: `|c^{(u)} - c^{(r)}| ≥ τ_{(u,r)} - 4u₀`. -/
theorem trigger_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) {r u : ℕ} {cu : ℝ} (h2 : 2 ≤ r)
    (hrL : r ≤ d.L) (h : d.Fires r u cu) : d.tau u r - 4 * u0 ≤ |cu - d.relC r| := by
  have h1 := trigger_gap_abs h
  obtain ⟨hr, hn, -⟩ := hc r h2 hrL
  have hf := relC_fidelity hc hθ h2 hrL
  linarith

/-- A PASS followed by a (retroactive) release of the same stage:
`|c^{(u)} - c^{(r)}| ≤ τ_{(u,r)} + |ρ_r| + |ν_r| + |c^{(r)} - θ_r|`. -/
theorem pass_gap_abs {r u : ℕ} {cu : ℝ} (h : ¬ d.Fires r u cu) :
    |cu - d.relC r| ≤ d.tau u r + |d.rho r| + |d.nu r| + |d.relC r - d.theta r| := by
  have h1 := pass_bound_abs h
  have h2 := abs_sub_le cu (d.theta r) (d.relC r)
  rw [abs_sub_comm (d.theta r) (d.relC r)] at h2
  linarith

/-- A PASS followed by a release on a clean round: `|c^{(u)} - c^{(r)}| ≤ τ_{(u,r)} + 4u₀`. -/
theorem pass_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) {r u : ℕ} {cu : ℝ} (h2 : 2 ≤ r)
    (hrL : r ≤ d.L) (h : ¬ d.Fires r u cu) : |cu - d.relC r| ≤ d.tau u r + 4 * u0 := by
  have h1 := pass_gap_abs h
  obtain ⟨hr, hn, -⟩ := hc r h2 hrL
  have hf := relC_fidelity hc hθ h2 hrL
  linarith

/-! ## I.4.1(ii): the answer -/

/-- `I:eq:sec4_upper_pass_bound` (first inequality): every stage `s > u_final` passed on the answer. -/
theorem answer_pass_bound_abs {s : ℕ} (h1 : d.ufinal < s) (h2 : s ≤ d.L) :
    |d.answer - d.theta s| ≤ d.tau d.ufinal s + |d.rho s| + |d.nu s| :=
  pass_bound_abs (d.not_fires_above_ufinal h1 h2)

/-- `I:eq:sec4_upper_pass_bound`: `|a - θ_s| ≤ τ_{(u_final,s)} + 3u₀` for `u_final < s ≤ L`. -/
theorem answer_pass_bound {u0 : ℝ} (hc : d.Clean u0) {s : ℕ} (h1 : d.ufinal < s) (h2 : s ≤ d.L) :
    |d.answer - d.theta s| ≤ d.tau d.ufinal s + 3 * u0 := by
  have h0 := d.one_le_ufinal
  exact pass_bound hc (by omega) h2 (d.not_fires_above_ufinal h1 h2)

/-- `I:eq:sec4_ai_minus_thetaL` (both subcases): `|a - θ_L| ≤ τ_{(u_final,L)} + 4u₀`. -/
theorem abs_answer_sub_thetaL_le {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hL : 2 ≤ d.L)
    (hτ : d.tau d.L d.L = 0) : |d.answer - d.theta d.L| ≤ d.tau d.ufinal d.L + 4 * u0 := by
  have hu0 := hc.u0_nonneg hL
  rcases lt_or_eq_of_le (d.ufinal_le_L (by omega)) with h | h
  · have := answer_pass_bound hc h le_rfl
    linarith
  · have hans := d.answer_of_two_le_ufinal (by omega)
    rw [hans, h, hτ]
    have := relC_fidelity hc hθ hL le_rfl
    linarith

/-- `I:eq:sec4_ai_accuracy` (first inequality): `|a - μ| ≤ τ_{(u_final,L)} + 4u₀ + r_anc` given the anchor
envelope `|θ_L - μ| ≤ r_anc`. -/
theorem abs_answer_sub_mu_le {u0 ranc μ : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hL : 2 ≤ d.L)
    (hτ : d.tau d.L d.L = 0) (hanc : |d.theta d.L - μ| ≤ ranc) :
    |d.answer - μ| ≤ d.tau d.ufinal d.L + 4 * u0 + ranc := by
  have h1 := abs_answer_sub_thetaL_le hc hθ hL hτ
  have h2 := abs_sub_le d.answer (d.theta d.L) μ
  linarith

/-! ## The public sign -/

theorem sgn_eq_sgn1 (h : 2 ≤ d.ufinal) : d.sgn = sgn1 (d.cprev d.ufinal - d.answer) := if_pos h

theorem abs_sgn (h : 2 ≤ d.ufinal) : |d.sgn| = 1 := d.abs_sgn_of_two_le h

theorem neg_abs_le_sgn_mul (h : 2 ≤ d.ufinal) (y : ℝ) : -|y| ≤ d.sgn * y := by
  rw [sgn_eq_sgn1 h]
  exact neg_abs_le_sgn1_mul _ _

theorem sgn_mul_le_abs (h : 2 ≤ d.ufinal) (y : ℝ) : d.sgn * y ≤ |y| := by
  rw [sgn_eq_sgn1 h]
  exact sgn1_mul_le_abs _ _

/-! ## I.4.2: Case A (`u_final = 2`) -/

theorem uprev_two_eq_one (d : ChainData) : d.uprev 2 = 1 := by
  unfold ChainData.uprev
  rw [d.orig_of_le_two le_rfl]

theorem cprev_two_eq_c1 (d : ChainData) : d.cprev 2 = d.c1 := by
  unfold ChainData.cprev
  rw [d.orig_of_le_two le_rfl]

/-- In Case A the public sign is `s^{(1)} = sign(c^{(1)} - a)` (`I:eq:stage1_sign`). -/
theorem sgn_of_caseA (hA : d.ufinal = 2) : d.sgn = sgn1 (d.c1 - d.answer) := by
  rw [sgn_eq_sgn1 (by omega), hA, cprev_two_eq_c1]

theorem answer_of_caseA (hA : d.ufinal = 2) : d.answer = d.relC 2 := by
  rw [d.answer_of_two_le_ufinal (by omega), hA]

/-- `I:eq:sec4_caseA_c1_c2_gap` (first inequality): stage 2 triggered on `c^{(1)}`. -/
theorem caseA_gap_abs (hA : d.ufinal = 2) :
    d.tau 1 2 - |d.rho 2| - |d.nu 2| - |d.relC 2 - d.theta 2| ≤ |d.c1 - d.relC 2| := by
  have hF := d.fires_ufinal (by omega)
  rw [hA, uprev_two_eq_one, cprev_two_eq_c1] at hF
  exact trigger_gap_abs hF

/-- `I:eq:sec4_caseA_c1_c2_gap`: `|c^{(1)} - c^{(2)}| ≥ τ_{(1,2)} - 4u₀`. -/
theorem caseA_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hA : d.ufinal = 2) (hL : 2 ≤ d.L) :
    d.tau 1 2 - 4 * u0 ≤ |d.c1 - d.relC 2| := by
  have hF := d.fires_ufinal (by omega)
  rw [hA, uprev_two_eq_one, cprev_two_eq_c1] at hF
  exact trigger_gap hc hθ le_rfl hL hF

/-- The decomposition of L1313-1316: `s^{(1)}(θ₁ - μ) ≥ |c^{(1)} - c^{(2)}| - |c^{(1)} - θ₁| - |a - μ|`. -/
theorem caseA_drift_ge (hA : d.ufinal = 2) (μ : ℝ) :
    |d.c1 - d.relC 2| - |d.c1 - d.theta 1| - |d.answer - μ| ≤ d.sgn * (d.theta 1 - μ) := by
  have hans := answer_of_caseA hA
  rw [sgn_of_caseA hA]
  have e : d.theta 1 - μ = (d.c1 - d.answer) + (d.theta 1 - d.c1) + (d.answer - μ) := by ring
  have h1 := neg_abs_le_sgn1_mul (d.c1 - d.answer) (d.theta 1 - d.c1)
  have h2 := neg_abs_le_sgn1_mul (d.c1 - d.answer) (d.answer - μ)
  rw [abs_sub_comm (d.theta 1) d.c1] at h1
  rw [e, mul_add, mul_add, sgn1_mul_self, ← hans]
  linarith

/-! ## I.4.5(2)-(4): Case B (`u_final = r' ≥ 3`) -/

/-- In Case B the public sign is `s_{i,r'} = sign(c^{(u_prev)} - c^{(r')})` (`I:eq:trigger_sign_def`). -/
theorem sgn_of_caseB (hB : 3 ≤ d.ufinal) :
    d.sgn = sgn1 (d.cprev d.ufinal - d.relC d.ufinal) := by
  rw [sgn_eq_sgn1 (by omega), d.answer_of_two_le_ufinal (by omega)]

/-- `I:eq:sec4_4u0_trigger_lb`: `|c^{(u_prev)} - c^{(r')}| ≥ τ_{(u_prev,r')} - 4u₀`. -/
theorem caseB_trigger_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hB : 3 ≤ d.ufinal)
    (hL : 1 ≤ d.L) :
    d.tau (d.uprev d.ufinal) d.ufinal - 4 * u0 ≤ |d.cprev d.ufinal - d.relC d.ufinal| :=
  trigger_gap hc hθ (by omega) (d.ufinal_le_L hL) (d.fires_ufinal (by omega))

/-- `I:eq:sec4_4u0_pass_ub`: if `u_prev < r' - 1`, stage `r' - 1` passed on `c^{(u_prev)}` and released
retroactively, so `|c^{(u_prev)} - c^{(r'-1)}| ≤ τ_{(u_prev,r'-1)} + 4u₀`. -/
theorem caseB_pass_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hB : 3 ≤ d.ufinal)
    (hL : 1 ≤ d.L) (hu : d.uprev d.ufinal < d.ufinal - 1) :
    |d.cprev d.ufinal - d.relC (d.ufinal - 1)| ≤ d.tau (d.uprev d.ufinal) (d.ufinal - 1) + 4 * u0 := by
  have hufL := d.ufinal_le_L hL
  obtain ⟨-, -, hnf⟩ := d.pred_pass hB (by omega) hu
  exact pass_gap hc hθ (by omega) (by omega) hnf

/-- The reuse case `u_prev = r' - 1` (B1): `c^{(u_prev)} = c^{(r'-1)}`. -/
theorem caseB_cprev_of_eq (hB : 3 ≤ d.ufinal) (hu : d.uprev d.ufinal = d.ufinal - 1) :
    d.cprev d.ufinal = d.relC (d.ufinal - 1) := by
  rw [(d.cprev_of_two_le_uprev (by omega)).1, hu]

/-- `I:eq:sec4_interior_adj_gap` before the threshold identity (L1466-1471):
`s_{i,r'}(c^{(r'-1)} - c^{(r')}) ≥ τ_{(u_prev,r')} - τ_{(u_prev,r'-1)} - 8u₀`. -/
theorem caseB_adj_gap {u0 : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hB : 3 ≤ d.ufinal)
    (hL : 1 ≤ d.L) (hτ : d.tau (d.ufinal - 1) (d.ufinal - 1) = 0) :
    d.tau (d.uprev d.ufinal) d.ufinal - d.tau (d.uprev d.ufinal) (d.ufinal - 1) - 8 * u0 ≤
      d.sgn * (d.relC (d.ufinal - 1) - d.relC d.ufinal) := by
  have hufL := d.ufinal_le_L hL
  have hu0 := hc.u0_nonneg (by omega)
  have htrig := caseB_trigger_gap hc hθ hB hL
  rw [sgn_of_caseB hB]
  have e : d.relC (d.ufinal - 1) - d.relC d.ufinal =
      (d.cprev d.ufinal - d.relC d.ufinal) - (d.cprev d.ufinal - d.relC (d.ufinal - 1)) := by ring
  rw [e, mul_sub, sgn1_mul_self]
  have hlt := d.uprev_lt (r := d.ufinal) (by omega)
  have hcases : d.uprev d.ufinal < d.ufinal - 1 ∨ d.uprev d.ufinal = d.ufinal - 1 := by omega
  rcases hcases with hu | hu
  · have hp := caseB_pass_gap hc hθ hB hL hu
    have h1 := sgn1_mul_le_abs (d.cprev d.ufinal - d.relC d.ufinal)
      (d.cprev d.ufinal - d.relC (d.ufinal - 1))
    linarith
  · have hcp := caseB_cprev_of_eq hB hu
    have hτ' : d.tau (d.uprev d.ufinal) (d.ufinal - 1) = 0 := by rw [hu]; exact hτ
    have h0 : sgn1 (d.cprev d.ufinal - d.relC d.ufinal) *
        (d.cprev d.ufinal - d.relC (d.ufinal - 1)) = 0 := by
      rw [hcp, sub_self, mul_zero]
    linarith

/-- `I:eq:sec4_terminal_adj_gap` before the threshold identity (L1501-1513), `r' = L`:
`s_{i,L}(c^{(L-1)} - μ) ≥ τ_{(u_prev,L)} - τ_{(u_prev,L-1)} - 9u₀ - r_anc`. -/
theorem caseB_terminal_gap {u0 ranc μ : ℝ} (hc : d.Clean u0) (hθ : d.ThetaMem) (hBL : d.ufinal = d.L)
    (h3 : 3 ≤ d.L) (hτ : d.tau (d.L - 1) (d.L - 1) = 0) (hanc : |d.theta d.L - μ| ≤ ranc) :
    d.tau (d.uprev d.L) d.L - d.tau (d.uprev d.L) (d.L - 1) - 9 * u0 - ranc ≤
      d.sgn * (d.relC (d.L - 1) - μ) := by
  have hB : 3 ≤ d.ufinal := by omega
  have hadj := caseB_adj_gap hc hθ hB (by omega) (by rw [hBL]; exact hτ)
  rw [hBL] at hadj
  have e : d.relC (d.L - 1) - μ =
      (d.relC (d.L - 1) - d.relC d.L) + (d.relC d.L - d.theta d.L) + (d.theta d.L - μ) := by ring
  have h1 := neg_abs_le_sgn_mul (d := d) (by omega) (d.relC d.L - d.theta d.L)
  have h2 := neg_abs_le_sgn_mul (d := d) (by omega) (d.theta d.L - μ)
  have hf := relC_fidelity hc hθ (r := d.L) (by omega) le_rfl
  rw [e, mul_add, mul_add]
  linarith

end ChainData

/-! ## The progress summand and its per-round sums -/

/-- The round summand of `Prog_m(h)` (`I:eq:sec4_prog_mi_def`, L1347-1348):
`8 w [(-δ)(c - μ) - δ²/8 - |δ| u₀]` for the capacity weight `w = w_m`, the impulse `δ = δ_{m,i}`, the
clipped release `c = c_i^{(m)}`, the population mean `μ = μ_i` and the unit `u₀`. -/
noncomputable def progSummand (w u0 δ c μ : ℝ) : ℝ := 8 * w * ((-δ) * (c - μ) - δ ^ 2 / 8 - |δ| * u0)

theorem progSummand_zero (w u0 c μ : ℝ) : progSummand w u0 0 c μ = 0 := by
  simp [progSummand]

/-- The summand for the impulse `δ = -η σ` with a sign `|σ| = 1` (level `r' - 1` in Case B). -/
theorem progSummand_neg_mul (w u0 η σ c μ : ℝ) (hη : 0 ≤ η) (hσ : |σ| = 1) :
    progSummand w u0 (-η * σ) c μ = 8 * w * η * σ * (c - μ) - w * η ^ 2 - 8 * w * η * u0 := by
  unfold progSummand
  have hσ2 : σ ^ 2 = 1 := by rw [← sq_abs, hσ, one_pow]
  have habs : |-η * σ| = η := by rw [abs_mul, abs_neg, abs_of_nonneg hη, hσ, mul_one]
  rw [habs]
  linear_combination (-w * η ^ 2) * hσ2

/-- The summand for the impulse `δ = η σ` with a sign `|σ| = 1` (level `r'` in Case B). -/
theorem progSummand_mul (w u0 η σ c μ : ℝ) (hη : 0 ≤ η) (hσ : |σ| = 1) :
    progSummand w u0 (η * σ) c μ = -(8 * w * η * σ * (c - μ)) - w * η ^ 2 - 8 * w * η * u0 := by
  unfold progSummand
  have hσ2 : σ ^ 2 = 1 := by rw [← sq_abs, hσ, one_pow]
  have habs : |η * σ| = η := by rw [abs_mul, abs_of_nonneg hη, hσ, mul_one]
  rw [habs]
  linear_combination (-w * η ^ 2) * hσ2

namespace ChainData

variable {d : ChainData}

theorem toRec_c (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (r : ℕ) :
    (d.toRec eta1 eta etaT).c r = if r = 1 then d.c1 else if d.Released r then d.relC r else 0 :=
  rfl

theorem toRec_delta (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (m : ℕ) :
    (d.toRec eta1 eta etaT).delta m = d.delta eta1 eta etaT m :=
  rfl

theorem toRec_answer (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) :
    (d.toRec eta1 eta etaT).answer = d.answer :=
  rfl

theorem toRec_ufinal (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) :
    (d.toRec eta1 eta etaT).ufinal = d.ufinal :=
  rfl

theorem toRec_sgn (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) :
    (d.toRec eta1 eta etaT).sgn = d.sgn :=
  rfl

theorem toRec_rel (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (r : ℕ) :
    (d.toRec eta1 eta etaT).rel r = decide (d.Released r) :=
  rfl

/-- The impulses of a validator level `m ≥ 2` vanish outside Case B (`u_final ≤ 2`). -/
theorem delta_eq_zero_of_ufinal_le_two (hu : d.ufinal ≤ 2) {m : ℕ} (hm : 2 ≤ m) (eta1 eta : ℝ)
    (etaT : ℕ → ℝ) : d.delta eta1 eta etaT m = 0 := by
  unfold ChainData.delta
  split_ifs <;> first | rfl | (exfalso; omega)

/-- The impulses in Case B (`I:eq:delta_mi_def`). -/
theorem delta_caseB (hB : 3 ≤ d.ufinal) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (m : ℕ) :
    d.delta eta1 eta etaT m =
      if m + 1 = d.ufinal then -eta * d.sgn else if m = d.ufinal then etaT m * d.sgn else 0 := by
  have h1 : ¬ d.ufinal = 2 := by omega
  unfold ChainData.delta
  rw [if_neg h1, if_pos hB]

theorem released_pred (hB : 3 ≤ d.ufinal) : d.Released (d.ufinal - 1) :=
  Or.inr ⟨hB, by omega⟩

theorem released_ufinal (h : 2 ≤ d.ufinal) : d.Released d.ufinal :=
  Or.inl (d.trig_ufinal h)

/-- I.4.5(1), `I:eq:sec4_non_caseB_zero`: rounds of Case 0 and Case A contribute `0`. -/
theorem progSum_of_ufinal_le_two (hu : d.ufinal ≤ 2) (W : ℕ → ℝ) (u0 μ eta1 eta : ℝ)
    (etaT : ℕ → ℝ) (Lm1 : ℕ) :
    ∑ m ∈ Finset.Icc 2 Lm1,
        progSummand (W m) u0 ((d.toRec eta1 eta etaT).delta m) ((d.toRec eta1 eta etaT).c m) μ = 0 := by
  refine Finset.sum_eq_zero fun m hm => ?_
  rw [toRec_delta, delta_eq_zero_of_ufinal_le_two hu (Finset.mem_Icc.1 hm).1, progSummand_zero]

/-- I.4.5(3), interior Case B (`3 ≤ r' ≤ L - 1`), the equal-impulse `μ`-cancellation
(`I:eq:sec4_linear_mu_cancel`) together with the deductions: with `K = 8 w_{r'-1} η = 8 w_{r'} η̃_{r'}`,
`∑_{m=2}^{L-1} Prog_{m,i} = K s_{i,r'}(c^{(r'-1)} - c^{(r')}) - w_{r'-1} η² - w_{r'} η̃_{r'}² - 2 K u₀`. -/
theorem progSum_caseB_interior (hB : 3 ≤ d.ufinal) (hBL : d.ufinal + 1 ≤ d.L) (W : ℕ → ℝ)
    (u0 μ eta1 eta K : ℝ) (etaT : ℕ → ℝ) (heta : 0 ≤ eta) (hetaT : 0 ≤ etaT d.ufinal)
    (hK1 : 8 * W (d.ufinal - 1) * eta = K) (hK2 : 8 * W d.ufinal * etaT d.ufinal = K) :
    ∑ m ∈ Finset.Icc 2 (d.L - 1),
        progSummand (W m) u0 ((d.toRec eta1 eta etaT).delta m) ((d.toRec eta1 eta etaT).c m) μ =
      K * d.sgn * (d.relC (d.ufinal - 1) - d.relC d.ufinal) - W (d.ufinal - 1) * eta ^ 2 -
        W d.ufinal * etaT d.ufinal ^ 2 - 2 * K * u0 := by
  have hs1 : |d.sgn| = 1 := abs_sgn (by omega)
  have hδa : (d.toRec eta1 eta etaT).delta (d.ufinal - 1) = -eta * d.sgn := by
    rw [toRec_delta, delta_caseB hB, if_pos (show d.ufinal - 1 + 1 = d.ufinal by omega)]
  have hδb : (d.toRec eta1 eta etaT).delta d.ufinal = etaT d.ufinal * d.sgn := by
    rw [toRec_delta, delta_caseB hB, if_neg (show ¬ (d.ufinal + 1 = d.ufinal) by omega),
      if_pos rfl]
  have hca : (d.toRec eta1 eta etaT).c (d.ufinal - 1) = d.relC (d.ufinal - 1) := by
    rw [toRec_c, if_neg (show ¬ (d.ufinal - 1 = 1) by omega), if_pos (released_pred hB)]
  have hcb : (d.toRec eta1 eta etaT).c d.ufinal = d.relC d.ufinal := by
    rw [toRec_c, if_neg (show ¬ (d.ufinal = 1) by omega), if_pos (released_ufinal (by omega))]
  have hmem_a : d.ufinal - 1 ∈ Finset.Icc 2 (d.L - 1) := Finset.mem_Icc.2 ⟨by omega, by omega⟩
  have hmem_b : d.ufinal ∈ Finset.Icc 2 (d.L - 1) := Finset.mem_Icc.2 ⟨by omega, by omega⟩
  have h0 : ∀ m ∈ Finset.Icc 2 (d.L - 1), m ≠ d.ufinal - 1 ∧ m ≠ d.ufinal →
      progSummand (W m) u0 ((d.toRec eta1 eta etaT).delta m) ((d.toRec eta1 eta etaT).c m) μ = 0 := by
    intro m _ hm
    rw [toRec_delta, delta_caseB hB, if_neg (show ¬ (m + 1 = d.ufinal) by omega),
      if_neg (show ¬ (m = d.ufinal) by omega), progSummand_zero]
  rw [Finset.sum_eq_add_of_mem (d.ufinal - 1) d.ufinal hmem_a hmem_b (by omega) h0, hδa, hδb, hca, hcb,
    progSummand_neg_mul _ _ _ _ _ _ heta hs1, progSummand_mul _ _ _ _ _ _ hetaT hs1, ← hK1]
  rw [← hK1] at hK2
  linear_combination (-(d.sgn * (d.relC d.ufinal - μ)) - u0) * hK2

/-- I.4.5(4), terminal Case B (`r' = L`): only level `L - 1` updates, and with `K = 8 w_{L-1} η`,
`∑_{m=2}^{L-1} Prog_{m,i} = K s_{i,L}(c^{(L-1)} - μ) - w_{L-1} η² - K u₀`. -/
theorem progSum_caseB_terminal (hBL : d.ufinal = d.L) (h3 : 3 ≤ d.L) (W : ℕ → ℝ)
    (u0 μ eta1 eta : ℝ) (etaT : ℕ → ℝ) (heta : 0 ≤ eta) :
    ∑ m ∈ Finset.Icc 2 (d.L - 1),
        progSummand (W m) u0 ((d.toRec eta1 eta etaT).delta m) ((d.toRec eta1 eta etaT).c m) μ =
      8 * W (d.L - 1) * eta * d.sgn * (d.relC (d.L - 1) - μ) - W (d.L - 1) * eta ^ 2 -
        8 * W (d.L - 1) * eta * u0 := by
  have hB : 3 ≤ d.ufinal := by omega
  have hs1 : |d.sgn| = 1 := abs_sgn (by omega)
  have hδa : (d.toRec eta1 eta etaT).delta (d.L - 1) = -eta * d.sgn := by
    rw [toRec_delta, delta_caseB hB, if_pos (show d.L - 1 + 1 = d.ufinal by omega)]
  have hca : (d.toRec eta1 eta etaT).c (d.L - 1) = d.relC (d.L - 1) := by
    have hr := released_pred hB
    rw [hBL] at hr
    rw [toRec_c, if_neg (show ¬ (d.L - 1 = 1) by omega), if_pos hr]
  have hmem : d.L - 1 ∈ Finset.Icc 2 (d.L - 1) := Finset.mem_Icc.2 ⟨by omega, le_rfl⟩
  have h0 : ∀ m ∈ Finset.Icc 2 (d.L - 1), m ≠ d.L - 1 →
      progSummand (W m) u0 ((d.toRec eta1 eta etaT).delta m) ((d.toRec eta1 eta etaT).c m) μ = 0 := by
    intro m hm hne
    have hm' := (Finset.mem_Icc.1 hm).2
    rw [toRec_delta, delta_caseB hB, if_neg (show ¬ (m + 1 = d.ufinal) by omega),
      if_neg (show ¬ (m = d.ufinal) by omega), progSummand_zero]
  rw [Finset.sum_eq_single_of_mem (d.L - 1) hmem h0, hδa, hca,
    progSummand_neg_mul _ _ _ _ _ _ heta hs1]

end ChainData

end A

end F2e2e
