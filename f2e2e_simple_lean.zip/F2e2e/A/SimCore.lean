import F2e2e.Lib.DP.AdvancedDefs

/-!
# [SIM_r], generic part: adaptive disjoint reads of a product space give an adaptive composition

Paper: Part I §3 (`parts/partI.tex` L803, L898, L1001): "conditioning on all other subsamples and their internal
randomness, … the rest of the cascade is an adaptive post-processing environment interacting with `S_r` strictly
through its episodes". `notes/PAPER_MAP_I_b.md` §6.A item 2 and §6.B rows C1, C2, C6: with the external randomness
`ω_{-r}` fixed, the law of the sequence of episode outputs is the adaptive composition of the per-episode kernels.

This file is mechanism independent. The randomness is a finite product `ω ∈ ∀ i, Z i` with law `Measure.pi ν`.
A sequence of outputs `F ω : Fin M → Y` is generated adaptively: `F ω e = g e (F ω |_{<e}) ω`, where
* the history `F ω |_{<e}` only reads the coordinates in a set `J e (history)` (`hhist`, a "stopping set": which
  coordinates were read is itself determined by the history), and
* the next step `g e y ·` only reads the coordinates outside `J e y` (`hread`).
Then the law of `F` is the adaptive composition `DP.advComp` of the kernels `y ↦ law of g e y ·`
(`map_eq_advComp_of_reads`).

The proof splits on the (finitely many) values `I` of `J e (history)`: on `{J = I}` the history is a function of
`ω|_I` and the next output a function of `ω|_{Iᶜ}`, and splicing two independent copies on `I` preserves the
product law (`map_splice`), so the next output may be computed from an independent copy (`lintegral_decouple`).

## Main definitions and results
* `splice I x y`, `map_splice`: `(μ ⊗ μ).map (splice I) = μ` for `μ = Measure.pi ν`.
* `lawKernel μ g hg : Kernel H Y`, `y ↦ μ.map (g y)` (Markov if `μ` is a probability measure).
* `pre e he z`: the prefix of length `e ≤ M` of `z : Fin M → Y`.
* `lintegral_decouple`, `map_eq_advComp_of_reads`.
-/

namespace F2e2e.A.SimCore

open MeasureTheory ProbabilityTheory

/-! ## Splicing two independent copies of a product sample -/

section Splice

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Z : ι → Type*} [∀ i, MeasurableSpace (Z i)]

/-- The coordinates in `I` from `x`, the others from `y`. -/
def splice (I : Finset ι) (x y : ∀ i, Z i) : ∀ i, Z i := fun i => if i ∈ I then x i else y i

omit [Fintype ι] [∀ i, MeasurableSpace (Z i)] in
lemma splice_of_mem {I : Finset ι} {i : ι} (hi : i ∈ I) (x y : ∀ i, Z i) : splice I x y i = x i := by
  simp [splice, hi]

omit [Fintype ι] [∀ i, MeasurableSpace (Z i)] in
lemma splice_of_not_mem {I : Finset ι} {i : ι} (hi : i ∉ I) (x y : ∀ i, Z i) : splice I x y i = y i := by
  simp [splice, hi]

omit [Fintype ι] in
lemma measurable_splice (I : Finset ι) :
    Measurable (fun p : (∀ i, Z i) × (∀ i, Z i) => splice I p.1 p.2) := by
  refine measurable_pi_lambda _ (fun i => ?_)
  by_cases hi : i ∈ I
  · simp only [splice, hi, if_true]
    exact (measurable_pi_apply i).comp measurable_fst
  · simp only [splice, hi, if_false]
    exact (measurable_pi_apply i).comp measurable_snd

/-- Splicing two independent copies of a product sample on a fixed coordinate set preserves its law. -/
theorem map_splice (ν : ∀ i, Measure (Z i)) [∀ i, IsProbabilityMeasure (ν i)] (I : Finset ι) :
    ((Measure.pi ν).prod (Measure.pi ν)).map (fun p => splice I p.1 p.2) = Measure.pi ν := by
  refine (Measure.pi_eq fun s hs => ?_).symm
  rw [Measure.map_apply (measurable_splice I) (MeasurableSet.univ_pi hs)]
  have hpre : (fun p : (∀ i, Z i) × (∀ i, Z i) => splice I p.1 p.2) ⁻¹' Set.univ.pi s =
      (Set.univ.pi fun i => if i ∈ I then s i else Set.univ) ×ˢ
        (Set.univ.pi fun i => if i ∈ I then Set.univ else s i) := by
    ext p
    simp only [Set.mem_preimage, Set.mem_univ_pi, Set.mem_prod]
    constructor
    · intro h
      refine ⟨fun i => ?_, fun i => ?_⟩
      · by_cases hi : i ∈ I
        · have := h i
          rw [splice_of_mem hi] at this
          simpa [hi] using this
        · simp [hi]
      · by_cases hi : i ∈ I
        · simp [hi]
        · have := h i
          rw [splice_of_not_mem hi] at this
          simpa [hi] using this
    · rintro ⟨h1, h2⟩ i
      by_cases hi : i ∈ I
      · rw [splice_of_mem hi]
        simpa [hi] using h1 i
      · rw [splice_of_not_mem hi]
        simpa [hi] using h2 i
  rw [hpre, Measure.prod_prod, Measure.pi_pi, Measure.pi_pi, ← Finset.prod_mul_distrib]
  refine Finset.prod_congr rfl fun i _ => ?_
  by_cases hi : i ∈ I <;> simp [hi]

end Splice

/-! ## The law kernel of a jointly measurable family -/

section LawKernel

variable {Ω H Y : Type*} [MeasurableSpace Ω] [MeasurableSpace H] [MeasurableSpace Y]

lemma measurable_map_of_uncurry (μ : Measure Ω) [SFinite μ] (g : H → Ω → Y)
    (hg : Measurable (Function.uncurry g)) : Measurable (fun h => μ.map (g h)) := by
  refine Measure.measurable_of_measurable_coe _ fun s hs => ?_
  have hgh : ∀ h, Measurable (g h) := fun h => hg.comp measurable_prodMk_left
  have : (fun h => μ.map (g h) s) = fun h => μ (Prod.mk h ⁻¹' (Function.uncurry g ⁻¹' s)) := by
    funext h
    rw [Measure.map_apply (hgh h) hs]
    rfl
  rw [this]
  exact measurable_measure_prodMk_left (hg hs)

/-- The kernel `h ↦ μ.map (g h)` of a jointly measurable family `g`. -/
noncomputable def lawKernel (μ : Measure Ω) [SFinite μ] (g : H → Ω → Y)
    (hg : Measurable (Function.uncurry g)) : Kernel H Y where
  toFun h := μ.map (g h)
  measurable' := measurable_map_of_uncurry μ g hg

lemma lawKernel_apply (μ : Measure Ω) [SFinite μ] (g : H → Ω → Y)
    (hg : Measurable (Function.uncurry g)) (h : H) : lawKernel μ g hg h = μ.map (g h) := rfl

instance isMarkovKernel_lawKernel (μ : Measure Ω) [IsProbabilityMeasure μ] (g : H → Ω → Y)
    (hg : Measurable (Function.uncurry g)) : IsMarkovKernel (lawKernel μ g hg) :=
  ⟨fun h => by
    rw [lawKernel_apply]
    exact Measure.isProbabilityMeasure_map (hg.comp measurable_prodMk_left).aemeasurable⟩

end LawKernel

/-! ## Prefixes -/

section Pre

variable {Y : Type*}

/-- The prefix of length `e ≤ M` of a sequence `z : Fin M → Y`. -/
def pre {M : ℕ} (e : ℕ) (he : e ≤ M) (z : Fin M → Y) : Fin e → Y := fun j => z (Fin.castLE he j)

lemma measurable_pre [MeasurableSpace Y] {M e : ℕ} (he : e ≤ M) :
    Measurable (pre (Y := Y) e he) :=
  measurable_pi_lambda _ fun _ => measurable_pi_apply _

lemma pre_self {M : ℕ} (z : Fin M → Y) : pre M le_rfl z = z := by
  funext j
  rfl

lemma pre_succ {M e : ℕ} (he : e + 1 ≤ M) (z : Fin M → Y) :
    pre (e + 1) he z = Fin.snoc (α := fun _ => Y) (pre e (by omega) z) (z ⟨e, by omega⟩) := by
  funext j
  refine Fin.lastCases ?_ (fun j' => ?_) j
  · rw [Fin.snoc_last]
    rfl
  · rw [Fin.snoc_castSucc]
    rfl

end Pre

/-! ## Decoupling and the adaptive composition -/

section Reads

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Z : ι → Type*} [∀ i, MeasurableSpace (Z i)]
  (ν : ∀ i, Measure (Z i)) [∀ i, IsProbabilityMeasure (ν i)]

/-- **Decoupling.** Let `Hf ω` be a "history" that only reads the coordinates in `J (Hf ω)`, and `G h ω` a next
step that only reads the coordinates outside `J h`. Then the next step may be computed from an independent copy
of the randomness: `P[(Hf ω, G (Hf ω) ω) ∈ E] = ∫ P_{ω'}[(Hf ω, G (Hf ω) ω') ∈ E] dP(ω)`. -/
theorem lintegral_decouple {Hs W : Type*} [MeasurableSpace Hs] [MeasurableSpace W]
    {Hf : (∀ i, Z i) → Hs} (hHf : Measurable Hf) (J : Hs → Finset ι)
    (hJ : ∀ I, MeasurableSet {h | J h = I})
    (hhist : ∀ ω ω' : ∀ i, Z i, (∀ i ∈ J (Hf ω), ω i = ω' i) → Hf ω' = Hf ω)
    (G : Hs → (∀ i, Z i) → W) (hG : Measurable (Function.uncurry G))
    (hread : ∀ (h : Hs) (ω ω' : ∀ i, Z i), (∀ i, i ∉ J h → ω i = ω' i) → G h ω = G h ω')
    {E : Set (Hs × W)} (hE : MeasurableSet E) :
    Measure.pi ν {ω | (Hf ω, G (Hf ω) ω) ∈ E} =
      ∫⁻ ω, Measure.pi ν {ω' | (Hf ω, G (Hf ω) ω') ∈ E} ∂(Measure.pi ν) := by
  set μ := Measure.pi ν with hμ
  -- measurability of the relevant maps
  have hpair : Measurable (fun p : (∀ i, Z i) × (∀ i, Z i) => (Hf p.1, G (Hf p.1) p.2)) := by
    refine (hHf.comp measurable_fst).prodMk ?_
    exact hG.comp ((hHf.comp measurable_fst).prodMk measurable_snd)
  have hdiag : Measurable (fun ω : ∀ i, Z i => (Hf ω, G (Hf ω) ω)) :=
    hpair.comp (measurable_id.prodMk measurable_id)
  have hA : ∀ I, MeasurableSet {ω : ∀ i, Z i | J (Hf ω) = I} := fun I => hHf (hJ I)
  set S : Set (∀ i, Z i) := {ω | (Hf ω, G (Hf ω) ω) ∈ E} with hS
  have hSm : MeasurableSet S := hdiag hE
  set f : (∀ i, Z i) → ENNReal := fun ω => μ {ω' | (Hf ω, G (Hf ω) ω') ∈ E} with hf
  have hfm : Measurable f := by
    have : f = fun ω => μ (Prod.mk ω ⁻¹' ((fun p : (∀ i, Z i) × (∀ i, Z i) =>
        (Hf p.1, G (Hf p.1) p.2)) ⁻¹' E)) := rfl
    rw [this]
    exact measurable_measure_prodMk_left (hpair hE)
  -- step 1: split according to the value of `J (Hf ω)`
  have hsplit : μ S = ∑ I : Finset ι, μ ({ω | J (Hf ω) = I} ∩ S) := by
    have h1 := sum_measure_preimage_singleton (μ := μ.restrict S) (Finset.univ : Finset (Finset ι))
      (f := fun ω => J (Hf ω)) (fun I _ => hA I)
    simp only [Finset.coe_univ, Set.preimage_univ, Measure.restrict_apply_univ] at h1
    rw [← h1]
    refine Finset.sum_congr rfl fun I _ => ?_
    change (μ.restrict S) {ω | J (Hf ω) = I} = _
    rw [Measure.restrict_apply (hA I)]
  -- step 2: on `{J (Hf ω) = I}`, splice an independent copy on `I`
  have hI : ∀ I : Finset ι, μ ({ω | J (Hf ω) = I} ∩ S) =
      (μ.prod μ) {p | J (Hf p.1) = I ∧ (Hf p.1, G (Hf p.1) p.2) ∈ E} := by
    intro I
    have hmeas : MeasurableSet ({ω | J (Hf ω) = I} ∩ S) := (hA I).inter hSm
    conv_lhs => rw [hμ, ← map_splice ν I]
    rw [Measure.map_apply (measurable_splice I) hmeas]
    congr 1
    ext p
    simp only [Set.mem_preimage, Set.mem_inter_iff, Set.mem_ofPred_eq, hS]
    set z := splice I p.1 p.2 with hz
    have hz1 : ∀ i ∈ I, p.1 i = z i := fun i hi => (splice_of_mem hi p.1 p.2).symm
    have hz2 : ∀ i, i ∉ I → z i = p.2 i := fun i hi => splice_of_not_mem hi p.1 p.2
    constructor
    · rintro ⟨hJz, hEz⟩
      have hH : Hf p.1 = Hf z := hhist z p.1 (fun i hi => (hz1 i (hJz ▸ hi)).symm)
      have hJ1 : J (Hf p.1) = I := by rw [hH]; exact hJz
      refine ⟨hJ1, ?_⟩
      have hG' : G (Hf p.1) z = G (Hf p.1) p.2 := hread _ _ _ (fun i hi => hz2 i (hJ1 ▸ hi))
      rw [← hH] at hEz
      rwa [hG'] at hEz
    · rintro ⟨hJ1, hE1⟩
      have hH : Hf z = Hf p.1 := hhist p.1 z (fun i hi => hz1 i (hJ1 ▸ hi))
      refine ⟨by rw [hH]; exact hJ1, ?_⟩
      have hG' : G (Hf p.1) z = G (Hf p.1) p.2 := hread _ _ _ (fun i hi => hz2 i (hJ1 ▸ hi))
      rw [hH, hG']
      exact hE1
  -- step 3: Fubini on each piece
  have hF : ∀ I : Finset ι, (μ.prod μ) {p | J (Hf p.1) = I ∧ (Hf p.1, G (Hf p.1) p.2) ∈ E} =
      ∫⁻ ω, {ω | J (Hf ω) = I}.indicator f ω ∂μ := by
    intro I
    have hmeas : MeasurableSet {p : (∀ i, Z i) × (∀ i, Z i) |
        J (Hf p.1) = I ∧ (Hf p.1, G (Hf p.1) p.2) ∈ E} :=
      ((hA I).preimage measurable_fst).inter (hpair hE)
    rw [Measure.prod_apply hmeas]
    refine lintegral_congr fun ω => ?_
    by_cases hω : J (Hf ω) = I
    · rw [Set.indicator_of_mem (show ω ∈ {ω | J (Hf ω) = I} from hω)]
      congr 1
      ext ω'
      simp [hω]
    · rw [Set.indicator_of_notMem (show ω ∉ {ω | J (Hf ω) = I} from hω)]
      have : Prod.mk ω ⁻¹' {p : (∀ i, Z i) × (∀ i, Z i) |
          J (Hf p.1) = I ∧ (Hf p.1, G (Hf p.1) p.2) ∈ E} = ∅ := by
        ext ω'
        simp [hω]
      rw [this, measure_empty]
  -- step 4: reassemble
  rw [hsplit]
  simp_rw [hI, hF]
  rw [← lintegral_finsetSum _ (fun I _ => hfm.indicator (hA I))]
  refine lintegral_congr fun ω => ?_
  rw [Finset.sum_eq_single (J (Hf ω))]
  · rw [Set.indicator_of_mem (show ω ∈ {ω' | J (Hf ω') = J (Hf ω)} from rfl)]
  · intro I _ hI'
    rw [Set.indicator_of_notMem]
    exact fun h => hI' h.symm
  · intro h
    exact absurd (Finset.mem_univ _) h

/-- **Adaptive disjoint reads give an adaptive composition.** If the outputs `F ω : Fin M → Y` are generated by
`F ω e = g e (F ω |_{<e}) ω`, the history `F ω |_{<e}` only reads the coordinates in `J e (F ω |_{<e})` and the step
`g e y` only reads the coordinates outside `J e y`, then the law of `F` is the adaptive composition of the kernels
`y ↦ law of g e y`. -/
theorem map_eq_advComp_of_reads {Y : Type*} [MeasurableSpace Y] (M : ℕ)
    (F : (∀ i, Z i) → Fin M → Y) (hF : Measurable F)
    (g : (e : ℕ) → (Fin e → Y) → (∀ i, Z i) → Y) (hg : ∀ e, Measurable (Function.uncurry (g e)))
    (hFg : ∀ (ω : ∀ i, Z i) (e : ℕ) (he : e < M), F ω ⟨e, he⟩ = g e (pre e he.le (F ω)) ω)
    (J : (e : ℕ) → (Fin e → Y) → Finset ι) (hJ : ∀ (e : ℕ) (I : Finset ι), MeasurableSet {y | J e y = I})
    (hhist : ∀ (e : ℕ) (he : e < M) (ω ω' : ∀ i, Z i),
      (∀ i ∈ J e (pre e he.le (F ω)), ω i = ω' i) → pre e he.le (F ω') = pre e he.le (F ω))
    (hread : ∀ (e : ℕ), e < M → ∀ (y : Fin e → Y) (ω ω' : ∀ i, Z i),
      (∀ i, i ∉ J e y → ω i = ω' i) → g e y ω = g e y ω') :
    (Measure.pi ν).map F = DP.advComp (fun e => lawKernel (Measure.pi ν) (g e) (hg e)) M := by
  set μ := Measure.pi ν with hμ
  set κ : (e : ℕ) → Kernel (Fin e → Y) Y := fun e => lawKernel μ (g e) (hg e) with hκ
  suffices h : ∀ (e : ℕ) (he : e ≤ M), μ.map (fun ω => pre e he (F ω)) = DP.advComp κ e by
    have := h M le_rfl
    simp only [pre_self] at this
    exact this
  intro e
  induction e with
  | zero =>
    intro he
    have hc : (fun ω => pre 0 he (F ω)) = fun _ => (DP.histNil : Fin 0 → Y) := by
      funext ω j
      exact j.elim0
    rw [hc, Measure.map_const, measure_univ, one_smul, DP.advComp_zero]
  | succ e ih =>
    intro he
    have he' : e < M := by omega
    have hpre_meas : Measurable (fun ω => pre e he'.le (F ω)) := (measurable_pre he'.le).comp hF
    ext E hE
    have hpre1 : Measurable (fun ω => pre (e + 1) he (F ω)) := (measurable_pre he).comp hF
    rw [DP.advComp_succ_apply κ e hE, ← ih he'.le, Measure.map_apply hpre1 hE]
    -- the set `{(h, y) | snoc h y ∈ E}`
    set E' : Set ((Fin e → Y) × Y) := {p | Fin.snoc (α := fun _ => Y) p.1 p.2 ∈ E} with hE'
    have hE'm : MeasurableSet E' := DP.measurable_histSnoc hE
    have hlhs : (fun ω => pre (e + 1) he (F ω)) ⁻¹' E =
        {ω | (pre e he'.le (F ω), g e (pre e he'.le (F ω)) ω) ∈ E'} := by
      ext ω
      simp only [Set.mem_preimage, Set.mem_ofPred_eq, hE']
      rw [pre_succ he (F ω), hFg ω e he']
    rw [hlhs, lintegral_decouple ν hpre_meas (J e) (hJ e) (hhist e he') (g e) (hg e)
      (hread e he') hE'm]
    rw [lintegral_map _ hpre_meas]
    · refine lintegral_congr fun ω => ?_
      have hgm : Measurable (g e (pre e he'.le (F ω))) := (hg e).comp measurable_prodMk_left
      have hset : MeasurableSet {y | Fin.snoc (α := fun _ => Y) (pre e he'.le (F ω)) y ∈ E} :=
        measurable_prodMk_left hE'm
      rw [hκ]
      simp only
      rw [lawKernel_apply, Measure.map_apply hgm hset]
      rfl
    · exact Kernel.measurable_kernel_prodMk_left (κ := κ e) hE'm

end Reads

end F2e2e.A.SimCore
