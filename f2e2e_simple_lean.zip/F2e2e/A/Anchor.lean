import F2e2e.A.Validators
import F2e2e.Lib.DP.Exponential
import F2e2e.Lib.DP.Transfer
import F2e2e.A.NumericsBudget
import F2e2e.A.AnchorGhost
import F2e2e.A.ArchAnchor

/-!
# Part I §3: the self-bounding anchor ghost monitor and the clean event

Paper: `parts/partI.tex` Section 3, L1030-1146:
* Lemma `I:lem:anchor_ghost_monitor` (L1033-1107): `ghost_monitor` (generic form: any `(ε/2, δ/2)`-DP transcript
  kernel `S ↦ h`, any `[0,1]`-valued queries `q_i(h)`, anchor size `n ≥ 16 ln(6k/δ)/(r_anc ε)` with
  `r_anc = 4ε`, `ε < 10⁻⁴`) and its instance `anchor_ghost_monitor` (`Pr[E_anc^c] ≤ 100 δ_val/ε_L`);
* Proposition `I:prop:clean_event_bound` (L1109-1146): `lap_event_bound` (`Pr[E_lap^c] ≤ δ_val/2`, union bound over
  the `(L+1)(3k+1) ≤ 32 L k M_{2,max}` Laplace entries of the noise table), `clean_event_bound`
  (`Pr[E_clean^c] ≤ 100 δ_val/ε_L + δ_val`) and `clean_event_numeric` (`… < β/10⁵`).

The ghost monitor (an analysis-only exponential mechanism over `([k] × {±1}) ∪ {m₀}` with scores
`σ(θ_i^{(L)}(S_L) - μ_i)` and the null score `r_anc - t_L`) is composed with the `(ε_L/2, δ_val/2)`-DP map
`S_L ↦ h` (`DP.IsDP.compProd_of_pure`, no `e^{ε₂}δ₁` term), and the self-bounding argument uses the one-coordinate DP
transfer `DP.dpTransfer` in both directions.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

/-! ## Lemma `I:lem:anchor_ghost_monitor`, generic form -/

/-- **Lemma `I:lem:anchor_ghost_monitor`** (self-bounding exponential-mechanism ghost monitor), generic form. Let
`S ∼ D^n` and `h ∼ κ S` for an `(ε/2, δ/2)`-DP Markov kernel `κ`, let `q h i : X → [0,1]` (`i < k`) be jointly
measurable queries and `μ_i(h) = ∫ q h i dD`. If `n ≥ 16 ln(6k/δ)/(r_anc ε)` with `r_anc = 4ε`, `0 < ε < 10⁻⁴` and
`0 < δ ≤ 1`, then `Pr[∃ i, |θ_i(S) - μ_i(h)| > r_anc] ≤ 100 δ/ε`, `θ_i(S) = (1/n) ∑_ℓ q h i (S ℓ)`
(`I:eq:anchor_ghost_bound`). -/
theorem ghost_monitor {X H : Type*} [MeasurableSpace X] [MeasurableSpace H] (D : Measure X)
    [IsProbabilityMeasure D] {n k : ℕ} (hn : 0 < n) (hk : 1 ≤ k) (κ : Kernel (Fin n → X) H)
    [IsMarkovKernel κ] {ε δ : ℝ} (hε : 0 < ε) (hε4 : ε < 1 / 10 ^ 4) (hδ : 0 < δ) (hδ1 : δ ≤ 1)
    (hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) (q : H → Fin k → X → ℝ)
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (hn16 : 16 * Real.log (6 * k / δ) / (4 * ε * ε) ≤ n) :
    ((Measure.pi fun _ : Fin n => D) ⊗ₘ κ)
        {p | ∃ i : Fin k, 4 * ε < |(∑ ℓ, q p.2 i (p.1 ℓ)) / n - ∫ x, q p.2 i x ∂D|} ≤
      ENNReal.ofReal (100 * δ / ε) :=
  Ghost.ghost_monitor_aux D hn hk κ hε hε4 hδ hδ1 hDP q hqm hq01 hn16

/-! ## The anchor event and the clean event for the mechanism -/

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

/-- **Lemma `I:lem:anchor_ghost_monitor`** for the mechanism: `Pr[E_anc^c] ≤ 100 δ_val/ε_L` under `adaProb`. -/
theorem anchor_ghost_monitor (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable) :
    adaProb k α β D {z | ¬ EAnc k α β D A z} ≤ ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α) :=
  anchor_ghost_monitor_of_ghost D (fun hn hk κ _ => ghost_monitor D hn hk κ) hk hα hα' hβ hβ' A hA hAm

theorem measurableSet_lapOK (j : NoiseIdx k (adaL α)) : MeasurableSet {x : ℝ | lapOK k α j x} := by
  cases j with
  | beta _ => exact MeasurableSet.univ
  | nu _ _ => exact measurableSet_le continuous_abs.measurable measurable_const
  | zeta _ _ => exact measurableSet_le continuous_abs.measurable measurable_const
  | rho _ _ => exact measurableSet_le continuous_abs.measurable measurable_const

theorem measurableSet_ELap : MeasurableSet {ω : AdaOmega k α | ELap k α ω} := by
  have e : {ω : AdaOmega k α | ELap k α ω} = ⋂ j, Function.eval j ⁻¹' {x | lapOK k α j x} := by
    ext ω
    simp [ELap]
  rw [e]
  exact MeasurableSet.iInter fun j => measurable_pi_apply j (measurableSet_lapOK j)

theorem measurableSet_not_ELap : MeasurableSet {ω : AdaOmega k α | ¬ ELap k α ω} :=
  measurableSet_ELap.compl

/-- **The Laplace part of Prop. `I:prop:clean_event_bound`**: every Laplace entry of the noise table is within its
envelope (`|ρ|, |ζ| ≤ u₀`, `|ν| ≤ 2u₀`) except with probability at most `δ_val/2` (union bound over
`(L+1)(3k+1) ≤ 32 L k M_{2,max}` entries, each failing with probability `δ_val/(64 L k M_{2,max})`). -/
theorem lap_event_bound (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaNoiseMeasure k α β {ω | ¬ ELap k α ω} ≤ ENNReal.ofReal (adaDeltaVal α β / 2) := by
  have hu0 := adaU0_pos hα
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hδ := adaDeltaVal_pos hα hβ
  have hL4 : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hM := one_le_adaMmax_real α 2
  set K : ℝ := 64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) with hKdef
  have hK : 0 < K := by positivity
  -- each Laplace entry fails with probability `exp(-u₀/b_SVT) = δ_val/K`
  have hexp : Real.exp (-adaU0 α / adaBsvt k α β) = adaDeltaVal α β / K := by
    have hΛ := log_svt_pos hα hα' hβ hβ' hk
    have e : adaU0 α / adaBsvt k α β = Real.log (K / adaDeltaVal α β) := by
      unfold adaBsvt
      rw [hKdef]
      field_simp
    rw [neg_div, e, Real.exp_neg, Real.exp_log (by positivity), inv_div]
  have hentry : ∀ j : NoiseIdx k (adaL α),
      adaNoiseMeasure k α β {ω | ¬ lapOK k α j (ω j)} ≤ ENNReal.ofReal (adaDeltaVal α β / K) := by
    intro j
    have hpre : {ω : AdaOmega k α | ¬ lapOK k α j (ω j)} =
        Function.eval j ⁻¹' {x | ¬ lapOK k α j x} := rfl
    rw [hpre, adaNoiseMeasure,
      (measurePreserving_eval (μ := noiseLaw k α β) j).measure_preimage
        (show MeasurableSet {x : ℝ | ¬ lapOK k α j x} from (measurableSet_lapOK j).compl).nullMeasurableSet]
    cases j with
    | beta i =>
      have e : {x : ℝ | ¬ lapOK k α (.beta i) x} = ∅ := by
        ext x
        simp [lapOK]
      rw [e, measure_empty]
      simp
    | nu i r =>
      show laplace (2 * adaBsvt k α β) {x | ¬ |x| ≤ 2 * adaU0 α} ≤ _
      simp_rw [not_le]
      have e2 : -(2 * adaU0 α) / (2 * adaBsvt k α β) = -adaU0 α / adaBsvt k α β := by
        rw [neg_div, neg_div, mul_div_mul_left _ _ (two_ne_zero : (2 : ℝ) ≠ 0)]
      rw [laplace_abs_gt (by positivity) (by positivity), e2, hexp]
    | zeta i r =>
      show laplace (adaBsvt k α β) {x | ¬ |x| ≤ adaU0 α} ≤ _
      simp_rw [not_le]
      rw [laplace_abs_gt hb hu0.le, hexp]
    | rho r e =>
      show laplace (adaBsvt k α β) {x | ¬ |x| ≤ adaU0 α} ≤ _
      simp_rw [not_le]
      rw [laplace_abs_gt hb hu0.le, hexp]
  have hcard : (Fintype.card (NoiseIdx k (adaL α)) : ℝ) ≤ 32 * (adaL α : ℝ) * k * adaMmax α 2 := by
    rw [Fintype.card_congr (NoiseIdx.equivSum k (adaL α))]
    simp only [Fintype.card_sum, Fintype.card_prod, Fintype.card_fin]
    push_cast
    have h1 : (k : ℝ) * (adaL α : ℝ) ≤ (k : ℝ) * (adaL α : ℝ) * (adaMmax α 2 : ℝ) :=
      le_mul_of_one_le_right (by positivity) hM
    nlinarith [mul_le_mul_of_nonneg_left hk' (by positivity : (0 : ℝ) ≤ (adaL α : ℝ)),
      mul_le_mul_of_nonneg_right hL4 (by positivity : (0 : ℝ) ≤ (k : ℝ))]
  have hset : {ω : AdaOmega k α | ¬ ELap k α ω} = ⋃ j, {ω | ¬ lapOK k α j (ω j)} := by
    ext ω
    simp [ELap]
  calc adaNoiseMeasure k α β {ω | ¬ ELap k α ω}
      ≤ ∑ j, adaNoiseMeasure k α β {ω | ¬ lapOK k α j (ω j)} := by
        rw [hset]
        exact measure_iUnion_fintype_le _ _
    _ ≤ ∑ _j : NoiseIdx k (adaL α), ENNReal.ofReal (adaDeltaVal α β / K) :=
        Finset.sum_le_sum fun j _ => hentry j
    _ = ENNReal.ofReal ((Fintype.card (NoiseIdx k (adaL α)) : ℝ) * (adaDeltaVal α β / K)) := by
        rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ENNReal.ofReal_mul (by positivity),
          ENNReal.ofReal_natCast]
    _ ≤ ENNReal.ofReal (adaDeltaVal α β / 2) := by
        apply ENNReal.ofReal_le_ofReal
        have h32 : (Fintype.card (NoiseIdx k (adaL α)) : ℝ) * (adaDeltaVal α β / K) ≤
            32 * (adaL α : ℝ) * k * adaMmax α 2 * (adaDeltaVal α β / K) :=
          mul_le_mul_of_nonneg_right hcard (by positivity)
        have e : 32 * (adaL α : ℝ) * k * adaMmax α 2 * (adaDeltaVal α β / K) = adaDeltaVal α β / 2 := by
          rw [hKdef]
          field_simp
          ring
        linarith

/-- **Proposition `I:prop:clean_event_bound`** (consumer contract): `Pr[E_clean^c] ≤ 100 δ_val/ε_L + δ_val`
(`I:eq:Eclean_failure_bound`). -/
theorem clean_event_bound (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable) :
    adaProb k α β D {z | ¬ EClean k α β D A z} ≤
      ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β) := by
  have h1 := anchor_ghost_monitor hk hα hα' hβ hβ' D A hA hAm
  have h2 := lap_event_bound hk hα hα' hβ hβ'
  have hδ := adaDeltaVal_pos hα hβ
  have hεL := adaEpsL_pos hα
  have hsub : {z | ¬ EClean k α β D A z} ⊆
      {z | ¬ EAnc k α β D A z} ∪ (Prod.snd ⁻¹' {ω | ¬ ELap k α ω}) := by
    intro z hz
    have hz' : ¬ (EAnc k α β D A z ∧ ELap k α z.2) := hz
    rcases not_and_or.mp hz' with h | h
    · exact Or.inl h
    · exact Or.inr h
  have hmarg : adaProb k α β D (Prod.snd ⁻¹' {ω | ¬ ELap k α ω}) =
      adaNoiseMeasure k α β {ω | ¬ ELap k α ω} :=
    (measurePreserving_snd (μ := Measure.pi fun _ : Fin (adaSampleSize k α β) => D)
      (ν := adaNoiseMeasure k α β)).measure_preimage measurableSet_not_ELap.nullMeasurableSet
  calc adaProb k α β D {z | ¬ EClean k α β D A z}
      ≤ adaProb k α β D ({z | ¬ EAnc k α β D A z} ∪ (Prod.snd ⁻¹' {ω | ¬ ELap k α ω})) :=
        measure_mono hsub
    _ ≤ adaProb k α β D {z | ¬ EAnc k α β D A z} +
          adaProb k α β D (Prod.snd ⁻¹' {ω | ¬ ELap k α ω}) := measure_union_le _ _
    _ ≤ ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α) + ENNReal.ofReal (adaDeltaVal α β / 2) := by
        rw [hmarg]
        exact add_le_add h1 h2
    _ ≤ ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β) := by
        rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
        apply ENNReal.ofReal_le_ofReal
        linarith

/-- **Proposition `I:prop:clean_event_bound`, numerics** (consumer contract): `100 δ_val/ε_L + δ_val < β/10⁵`. -/
theorem clean_event_numeric (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β < β / 10 ^ 5 := by
  have h := clean_budget_lt hα hα' hβ hβ'
  rw [show β / 10 ^ 5 = 1 / 10 ^ 5 * β by ring]
  exact h

end A

end F2e2e
