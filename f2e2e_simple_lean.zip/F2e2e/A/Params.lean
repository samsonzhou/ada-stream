import F2e2e.Spec

/-!
# Part I: the locked parameters beyond the Spec (Definition `I:def:locked_parameters`)

Paper: `parts/partI.tex` L194-261 (Definition `I:def:locked_parameters`, (P1)-(P5)), L876-885
(sensitivities `Δ_r`, `I:eq:Delta_r_def`), L903 (`ε_{ep,r} ≤ 4Δ_r/b_SVT`, `I:eq:eps_ep_r_bound`),
L116 and L303 (the partition of the sample into the blocks `S_1, …, S_L`).

The Spec (`F2e2e/Spec.lean` §1.1) already defines `L = adaL α`, `γ = adaGamma α`, `u₀ = adaU0 α`,
`L₁ = adaL1 α β`, `χ₁ = adaChi1 α β`, `n₁ = adaN1 k α β`, `ε_r = adaEps α r`, `ε_L = adaEpsL α`,
`r_anc = adaRanc α`, `δ_val = adaDeltaVal α β`, `L_val = adaLval α β`, `T_{1,max} = adaT1max α`,
`N_{r*,max} = adaNmax α r*`, `M_{r,max} = adaMmax α r`, `b_SVT = adaBsvt k α β`, `n_r = adaNr k α β r`,
`n_L = adaNL k α β` and `n = adaSampleSize k α β`; they are reused verbatim here (never redefined).

This file adds the remaining quantities of Definition `I:def:locked_parameters`:
* (P2) `ε₁ = 0.05` (`adaEps1`, equal to `adaEps α 1`), `δ₁ = αβ/10240` (`adaDelta1`), `R₁ = α/32` (`adaR1`),
  `η₁ = α/16` (`adaEta1`), `γ₁ = α/8` (`adaGamma1`), the Beta shape `p₁` (`adaP1`: `8` in Branch 1A,
  `⌈L₁⌉ + 1` in Branch 1B) and the density exponent `m = p₁ - 1` of `V = 2B - 1` (`adaBetaM`);
* (P3) the privacy ratio `ρ = α^{-1/(L-1)}` (`adaRho`);
* (P4) the threshold matrix `τ_{(u,r)}` (`adaTau`);
* (P5) the capacity weights `w_m = ε_m^{-2}` (`adaW`), the validator step size `η_m = γ/8` (`adaEta`, the
  same for every level `m`), the coupled reaction steps `η̃_{r*} = (w_{r*-1}/w_{r*}) η_{r*-1}` with
  `η̃_L = 0` (`adaEtaTilde`);
* the sensitivities `Δ_r = 4/n_r` (`2 ≤ r ≤ L-1`), `Δ_L = 1/n_L` (`adaSens`) and the per-episode privacy
  `ε_{ep,r} = 4Δ_r/b_SVT` (`adaEpsEp`);
* the block sizes `n_1, …, n_L` as one function of the stage `r` (`adaBlock`, `0` outside `1 ≤ r ≤ L`;
  `adaBlockFin` on `Fin L`), the block offsets (`adaOffset`) and the global index of the `ℓ`-th point of
  block `r` (`adaBlockIdx`), with `∑_{r=1}^{L} n_r = adaSampleSize` (`adaOffset_top`,
  `sum_adaBlockFin`).

Conventions: stages are numbered `1, …, L` as in the paper (`r : ℕ`), real subtraction is used in every
formula with `r - 2`, `r - u`, `L - 1` (casts to `ℝ` first); the only `ℕ` subtractions are `r - 1` in
`adaEtaTilde` (used for `3 ≤ r ≤ L - 1`) and `p₁ - 1` in `adaBetaM` (`p₁ ≥ 8`).
-/

namespace F2e2e

namespace A

open MeasureTheory

noncomputable section

/-! ## (P2) Working sample `S₁` -/

/-- (P2) Stage-1 privacy `ε₁ = 0.05` (equal to `adaEps α 1`, see `adaEps_one`). -/
def adaEps1 : ℝ := 1 / 20

/-- (P2) `δ₁ = αβ/10240`. -/
def adaDelta1 (α β : ℝ) : ℝ := α * β / 10240

/-- (P2) The Beta noise radius `R₁ = α/32`. -/
def adaR1 (α : ℝ) : ℝ := α / 32

/-- (P2) The Stage-1 FTRL step size `η₁ = α/16`. -/
def adaEta1 (α : ℝ) : ℝ := α / 16

/-- (P2) The Stage-1 drift margin `γ₁ = α/8` (used only in §§4-5). -/
def adaGamma1 (α : ℝ) : ℝ := α / 8

/-- (P2, `I:eq:beta_shape_m1`) The symmetric Beta shape `p₁`: `8` in Branch 1A (`β ≥ min(10⁻⁶, α⁵) = α⁵`)
and `⌈L₁⌉ + 1` in Branch 1B. (As in `adaChi1`, the branch test is `α⁵ ≤ β`.) -/
def adaP1 (α β : ℝ) : ℕ := if α ^ 5 ≤ β then 8 else ⌈adaL1 α β⌉₊ + 1

/-- The density exponent `m = p₁ - 1` of the Stage-1 noise `V = 2B - 1`, `B ∼ Beta(p₁, p₁)`: `V` has density
`∝ (1 - v²)^m` on `(-1, 1)` (`I:lem:working_sample_privacy`, L595-599; `m = 7` in Branch 1A, `m = ⌈L₁⌉` in
Branch 1B). -/
def adaBetaM (α β : ℝ) : ℕ := adaP1 α β - 1

/-! ## (P3) Privacy ratio -/

/-- (P3, `I:eq:eps_r_schedule`) The adjacent privacy ratio `ρ = ε_{r-1}/ε_r = α^{-1/(L-1)}` (not to be
confused with the episode threshold noises `ρ^{(r)}` of the mechanism). -/
def adaRho (α : ℝ) : ℝ := α ^ (-(1 / ((adaL α : ℝ) - 1)))

/-! ## (P4) Threshold matrix -/

/-- (P4, `I:eq:threshold_matrix`) The two-piece linear threshold matrix, for `1 ≤ u ≤ r ≤ L`:
`τ_{(r,r)} = 0`, `τ_{(1,r)} = α/2 + 2(r-2)γ` (`2 ≤ r ≤ L`), `τ_{(u,r)} = 2(r-u)γ` (`2 ≤ u < r ≤ L`). -/
def adaTau (α : ℝ) (u r : ℕ) : ℝ :=
  if u = r then 0
  else if u = 1 then α / 2 + 2 * ((r : ℝ) - 2) * adaGamma α
  else 2 * ((r : ℝ) - (u : ℝ)) * adaGamma α

/-! ## (P5) Capacity weights and coupled step sizes -/

/-- (P5, `I:eq:coupled_steps_and_caps`) The capacity weight `w_m = ε_m^{-2}` (`2 ≤ m ≤ L-1`). -/
def adaW (α : ℝ) (m : ℕ) : ℝ := 1 / adaEps α m ^ 2

/-- (P5) The validator FTRL step size `η_m = γ/8` (the same for every level `2 ≤ m ≤ L-1`). -/
def adaEta (α : ℝ) : ℝ := adaGamma α / 8

/-- (P5) The coupled reaction step `η̃_{r*} = (w_{r*-1}/w_{r*}) η_{r*-1}` (`3 ≤ r* ≤ L-1`), and `η̃_L = 0`. -/
def adaEtaTilde (α : ℝ) (r : ℕ) : ℝ :=
  if r = adaL α then 0 else adaW α (r - 1) / adaW α r * adaEta α

/-! ## Sensitivities (`I:eq:Delta_r_def`) -/

/-- (`I:eq:Delta_r_def`, L876-885) The sensitivities `Δ_r = 4/n_r` (`2 ≤ r ≤ L-1`) and `Δ_L = 1/n_L`. -/
def adaSens (k : ℕ) (α β : ℝ) (r : ℕ) : ℝ :=
  if r = adaL α then 1 / (adaNL k α β : ℝ) else 4 / (adaNr k α β r : ℝ)

/-- The per-episode privacy parameter `ε_{ep,r} = 4Δ_r/b_SVT` (`I:eq:eps_ep_r_bound`, L903;
`16/(n_r b_SVT)` for `2 ≤ r ≤ L-1` and `4/(n_L b_SVT)` for `r = L`). -/
def adaEpsEp (k : ℕ) (α β : ℝ) (r : ℕ) : ℝ := 4 * adaSens k α β r / adaBsvt k α β

/-! ## Blocks of the sample (L116, L303) -/

/-- The block sizes `n_1, …, n_L` as a function of the stage `r` (`1 ≤ r ≤ L`): `n_1 = adaN1`,
`n_r = adaNr r` (`2 ≤ r ≤ L-1`), `n_L = adaNL`; `0` for `r = 0` and `r > L`. -/
def adaBlock (k : ℕ) (α β : ℝ) (r : ℕ) : ℕ :=
  if r = 1 then adaN1 k α β
  else if r = adaL α then adaNL k α β
  else if 2 ≤ r ∧ r < adaL α then adaNr k α β r
  else 0

/-- The block sizes indexed by `Fin L` (index `j` is stage `j + 1`). -/
def adaBlockFin (k : ℕ) (α β : ℝ) (j : Fin (adaL α)) : ℕ := adaBlock k α β (j.val + 1)

/-- The offset of block `r`: the number of sample points in the blocks `1, …, r-1`. -/
def adaOffset (k : ℕ) (α β : ℝ) (r : ℕ) : ℕ := ∑ s ∈ Finset.range r, adaBlock k α β s

end

/-! ## Basic facts -/

theorem adaL_ge_four (α : ℝ) : 4 ≤ adaL α := le_max_left _ _

theorem adaEps_one (α : ℝ) : adaEps α 1 = adaEps1 := by
  simp [adaEps, adaEps1]

theorem adaBlock_zero (k : ℕ) (α β : ℝ) : adaBlock k α β 0 = 0 := by
  have h4 := adaL_ge_four α
  unfold adaBlock
  rw [if_neg (by norm_num), if_neg (by omega), if_neg (by omega)]

theorem adaBlock_one (k : ℕ) (α β : ℝ) : adaBlock k α β 1 = adaN1 k α β := by
  simp [adaBlock]

theorem adaBlock_L (k : ℕ) (α β : ℝ) : adaBlock k α β (adaL α) = adaNL k α β := by
  have h4 := adaL_ge_four α
  unfold adaBlock
  rw [if_neg (by omega), if_pos rfl]

theorem adaBlock_mid (k : ℕ) (α β : ℝ) {r : ℕ} (h2 : 2 ≤ r) (hL : r < adaL α) :
    adaBlock k α β r = adaNr k α β r := by
  unfold adaBlock
  rw [if_neg (by omega), if_neg (by omega), if_pos ⟨h2, hL⟩]

theorem adaBlock_eq_zero_of_gt (k : ℕ) (α β : ℝ) {r : ℕ} (hr : adaL α < r) : adaBlock k α β r = 0 := by
  have h4 := adaL_ge_four α
  unfold adaBlock
  rw [if_neg (by omega), if_neg (by omega), if_neg (by omega)]

theorem adaOffset_zero (k : ℕ) (α β : ℝ) : adaOffset k α β 0 = 0 := by
  simp [adaOffset]

theorem adaOffset_succ (k : ℕ) (α β : ℝ) (r : ℕ) :
    adaOffset k α β (r + 1) = adaOffset k α β r + adaBlock k α β r :=
  Finset.sum_range_succ _ _

theorem adaOffset_mono (k : ℕ) (α β : ℝ) {r s : ℕ} (h : r ≤ s) :
    adaOffset k α β r ≤ adaOffset k α β s :=
  Finset.sum_le_sum_of_subset (Finset.range_mono h)

/-- The blocks exhaust the sample: `n_1 + ∑_{r=2}^{L-1} n_r + n_L = adaSampleSize`
(`I:eq:main_thm_explicit_n`). -/
theorem adaOffset_top (k : ℕ) (α β : ℝ) :
    adaOffset k α β (adaL α + 1) = adaSampleSize k α β := by
  have h4 := adaL_ge_four α
  unfold adaOffset adaSampleSize
  rw [Finset.range_eq_Ico, ← Finset.sum_Ico_consecutive _ (show 0 ≤ 2 by omega)
      (show 2 ≤ adaL α + 1 by omega),
    ← Finset.sum_Ico_consecutive _ (show 2 ≤ adaL α by omega) (show adaL α ≤ adaL α + 1 by omega)]
  have e1 : ∑ s ∈ Finset.Ico 0 2, adaBlock k α β s = adaN1 k α β := by
    rw [Finset.sum_Ico_eq_sum_range]
    simp [Finset.sum_range_succ, adaBlock_zero, adaBlock_one]
  have e2 : ∑ s ∈ Finset.Ico 2 (adaL α), adaBlock k α β s =
      ∑ r ∈ Finset.Icc 2 (adaL α - 1), adaNr k α β r := by
    have hI : Finset.Icc 2 (adaL α - 1) = Finset.Ico 2 (adaL α) := by
      rw [← Finset.Ico_add_one_right_eq_Icc, Nat.sub_add_cancel (by omega)]
    rw [hI]
    refine Finset.sum_congr rfl fun s hs => ?_
    rw [Finset.mem_Ico] at hs
    exact adaBlock_mid k α β hs.1 hs.2
  have e3 : ∑ s ∈ Finset.Ico (adaL α) (adaL α + 1), adaBlock k α β s = adaNL k α β := by
    rw [Finset.sum_Ico_eq_sum_range]
    simp [adaBlock_L]
  rw [e1, e2, e3, add_assoc]

theorem adaOffset_add_block_le (k : ℕ) (α β : ℝ) {r : ℕ} (hr : r ≤ adaL α) :
    adaOffset k α β r + adaBlock k α β r ≤ adaSampleSize k α β := by
  rw [← adaOffset_succ, ← adaOffset_top k α β]
  exact adaOffset_mono k α β (by omega)

theorem adaOffset_add_lt (k : ℕ) (α β : ℝ) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    adaOffset k α β r + ℓ.val < adaSampleSize k α β := by
  have hpos : 0 < adaBlock k α β r := lt_of_le_of_lt (Nat.zero_le _) ℓ.isLt
  have hr : r ≤ adaL α := by
    by_contra h
    rw [adaBlock_eq_zero_of_gt k α β (by omega)] at hpos
    exact lt_irrefl 0 hpos
  have := adaOffset_add_block_le k α β hr
  have := ℓ.isLt
  omega

/-- The global index (in `Fin n`, `n = adaSampleSize k α β`) of the `ℓ`-th point `X_{r,ℓ}` of block `r`:
`adaOffset r + ℓ`. -/
noncomputable def adaBlockIdx (k : ℕ) (α β : ℝ) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) : Fin (adaSampleSize k α β) :=
  ⟨adaOffset k α β r + ℓ.val, adaOffset_add_lt k α β r ℓ⟩

theorem adaBlockIdx_val (k : ℕ) (α β : ℝ) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (adaBlockIdx k α β r ℓ).val = adaOffset k α β r + ℓ.val := rfl

/-- Distinct (block, position) pairs have distinct global indices. -/
theorem adaBlockIdx_inj (k : ℕ) (α β : ℝ) {r r' : ℕ} (ℓ : Fin (adaBlock k α β r))
    (ℓ' : Fin (adaBlock k α β r')) (h : adaBlockIdx k α β r ℓ = adaBlockIdx k α β r' ℓ') :
    r = r' ∧ ℓ.val = ℓ'.val := by
  have hv : adaOffset k α β r + ℓ.val = adaOffset k α β r' + ℓ'.val := congrArg Fin.val h
  have key : ∀ {a b : ℕ} (la : Fin (adaBlock k α β a)) (lb : Fin (adaBlock k α β b)), a < b →
      adaOffset k α β a + la.val < adaOffset k α β b + lb.val := by
    intro a b la lb hab
    have h1 : adaOffset k α β a + adaBlock k α β a ≤ adaOffset k α β b := by
      rw [← adaOffset_succ]; exact adaOffset_mono k α β hab
    have := la.isLt
    omega
  rcases lt_trichotomy r r' with hlt | heq | hgt
  · exact absurd hv (ne_of_lt (key ℓ ℓ' hlt))
  · subst heq; exact ⟨rfl, by omega⟩
  · exact absurd hv.symm (ne_of_lt (key ℓ' ℓ hgt))

theorem sum_adaBlockFin (k : ℕ) (α β : ℝ) :
    ∑ j : Fin (adaL α), adaBlockFin k α β j = adaSampleSize k α β := by
  rw [← adaOffset_top k α β]
  unfold adaBlockFin adaOffset
  rw [Fin.sum_univ_eq_sum_range (fun j => adaBlock k α β (j + 1)) (adaL α),
    Finset.sum_range_succ' (fun s => adaBlock k α β s), adaBlock_zero, add_zero]

end A

end F2e2e
