import F2e2e.A.Accuracy

/-!
# Part I §4: the progress functional `Prog_m` and the coupled-progress lemma

Owner: A-ACC. Paper: `parts/partI.tex` L1335-1530: Definition `I:def:prog_m` (I.4.3, L1335-1350), Remark
`I:rem:prog_m_measurability` (I.4.4, L1352-1363), Lemma `I:lem:rl2_coupled_progress` (I.4.5, L1367-1530).

`Prog_m(h)` itself is `progM α D A h m` (A-ARCH's `F2e2e/A/ArchDefs.lean`, checked against L1343-1348:
`8 w_m ∑_i [(-δ_{m,i})(c_i^{(m)} - μ_i) - δ_{m,i}²/8 - |δ_{m,i}| u₀]`, where `γ w_m/η_m = 8 w_m`,
`progM_eq_paper`). Its round summand `Prog_{m,i}(h)` is `progRound` (`I:eq:sec4_prog_mi_def`).

## Main results
* `progM_eq_sum_progRound` (`Prog_m = ∑_i Prog_{m,i}`), `progM_eq_paper` (the first form of
  `I:eq:sec4_prog_m_def` with the prefactor `γ w_m/η_m`).
* I.4.4: `measurable_histAns`, `measurable_popMu`, `measurable_progRound`, `measurable_progM`
  (`h ↦ Prog_m(h)` is measurable for a jointly measurable analyst).
* I.4.5(1): `coupled_progress_non_caseB` (`I:eq:sec4_non_caseB_zero`).
* I.4.5(2)-(4) on `E_clean`: `coupled_progress_caseB` (`> 1.5 w_{r'-1} γ²` per Case-B round),
  `coupled_progress_interior` (`106/64`), `coupled_progress_terminal` (`103/64`); the separations
  themselves are `ChainData.caseB_trigger_gap`/`caseB_pass_gap`/`round_caseB_adj_gap`/
  `round_caseB_terminal_gap`.
* I.4.5(5): `coupled_progress_branches` (`I:eq:sec4_branch_sum_decomp`) and `coupled_progress_halt`
  (`I:eq:sec4_global_halt_prog`: `∑_{m=2}^{L-1} Prog_m(h) ≥ 192 L > 128(L-2)` on `E_halt(h) ∩ E_clean`).
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## Two counting lemmas -/

/-- Grouping a sum over rounds by branch (the abstract form of `I:eq:sec4_branch_sum_decomp`): if every
round contributes `F i ≥ 0`, and at least `c (u i)` when `3 ≤ u i` (then `u i ≤ L`), then
`∑_{r=3}^{L} c r · #{i : u i = r} ≤ ∑_i F i`. -/
theorem sum_branch_le {ι : Type*} (s : Finset ι) (F : ι → ℝ) (u : ι → ℕ) (c : ℕ → ℝ) (L : ℕ)
    (hF0 : ∀ i ∈ s, 0 ≤ F i) (hF : ∀ i ∈ s, 3 ≤ u i → u i ≤ L ∧ c (u i) ≤ F i) :
    ∑ r ∈ Finset.Icc 3 L, c r * ((s.filter fun i => u i = r).card : ℝ) ≤ ∑ i ∈ s, F i := by
  classical
  set s' := s.filter (fun i => u i ∈ Finset.Icc 3 L) with hs'
  have hmaps : ∀ i ∈ s', u i ∈ Finset.Icc 3 L := fun i hi => (Finset.mem_filter.1 hi).2
  have hfib : ∀ r ∈ Finset.Icc 3 L,
      s'.filter (fun i => u i = r) = s.filter (fun i => u i = r) := by
    intro r hr
    rw [hs', Finset.filter_filter]
    refine Finset.filter_congr fun i _ => ?_
    constructor
    · exact fun h => h.2
    · intro h
      exact ⟨by rw [h]; exact hr, h⟩
  have h1 : ∀ r ∈ Finset.Icc 3 L, ∑ i ∈ s'.filter (fun i => u i = r), c r =
      c r * ((s.filter fun i => u i = r).card : ℝ) := by
    intro r hr
    rw [Finset.sum_const, nsmul_eq_mul, mul_comm, hfib r hr]
  rw [← Finset.sum_congr rfl h1, Finset.sum_fiberwise_of_maps_to' hmaps c]
  calc ∑ i ∈ s', c (u i) ≤ ∑ i ∈ s', F i := by
        refine Finset.sum_le_sum fun i hi => ?_
        have hi' := Finset.mem_filter.1 hi
        exact (hF i hi'.1 (Finset.mem_Icc.1 hi'.2).1).2
    _ ≤ ∑ i ∈ s, F i :=
        Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) fun i hi _ => hF0 i hi

/-- Dropping all but one branch: `b · #{i : u i = r} ≤ ∑_i F i` if `F ≥ 0` and `F i ≥ b` on the branch. -/
theorem mul_card_le_sum {ι : Type*} (s : Finset ι) (F : ι → ℝ) (u : ι → ℕ) (r : ℕ) (b : ℝ)
    (hF0 : ∀ i ∈ s, 0 ≤ F i) (hF : ∀ i ∈ s, u i = r → b ≤ F i) :
    b * ((s.filter fun i => u i = r).card : ℝ) ≤ ∑ i ∈ s, F i := by
  classical
  calc b * ((s.filter fun i => u i = r).card : ℝ) = ∑ i ∈ s.filter (fun i => u i = r), b := by
        rw [Finset.sum_const, nsmul_eq_mul, mul_comm]
    _ ≤ ∑ i ∈ s.filter (fun i => u i = r), F i := by
        refine Finset.sum_le_sum fun i hi => ?_
        have hi' := Finset.mem_filter.1 hi
        exact hF i hi'.1 hi'.2
    _ ≤ ∑ i ∈ s, F i :=
        Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) fun i hi _ => hF0 i hi

section Prog

variable {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ}

/-! ## Definition `I:def:prog_m` -/

/-- Definition `I:def:prog_m`, the round summand `Prog_{m,i}(h)` (`I:eq:sec4_prog_mi_def`, L1347-1348):
`8 w_m [(-δ_{m,i})(c_i^{(m)} - μ_i) - δ_{m,i}²/8 - |δ_{m,i}| u₀]`. -/
noncomputable def progRound (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (m : ℕ)
    (i : Fin k) : ℝ :=
  progSummand (adaW α m) (adaU0 α) ((h i).delta m) ((h i).c m) (popMu D A h i)

/-- `Prog_m(h) = ∑_i Prog_{m,i}(h)` (`I:eq:sec4_prog_mi_def`). -/
theorem progM_eq_sum_progRound (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec)
    (m : ℕ) : progM α D A h m = ∑ i, progRound α D A h m i := by
  unfold progM progRound progSummand
  rw [Finset.mul_sum]

/-- The prefactor of `I:eq:sec4_prog_m_def`: `γ w_m / η_m = 8 w_m` (`η_m = γ/8`). -/
theorem adaGamma_mul_adaW_div_adaEta (hα : 0 < α) (m : ℕ) :
    adaGamma α * adaW α m / adaEta α = 8 * adaW α m := by
  have hγ := adaGamma_pos hα
  have hη : adaEta α ≠ 0 := by
    unfold adaEta
    positivity
  rw [div_eq_iff hη]
  unfold adaEta
  ring

/-- `I:eq:sec4_prog_m_def` in the paper's first form:
`Prog_m(h) = (γ w_m/η_m) ∑_i [(-δ_{m,i})(c_i^{(m)} - μ_i) - δ_{m,i}²/8 - |δ_{m,i}| u₀]`. -/
theorem progM_eq_paper (hα : 0 < α) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec)
    (m : ℕ) :
    progM α D A h m = adaGamma α * adaW α m / adaEta α * ∑ i : Fin k,
      ((-(h i).delta m) * ((h i).c m - popMu D A h i) - (h i).delta m ^ 2 / 8 -
        |(h i).delta m| * adaU0 α) := by
  rw [adaGamma_mul_adaW_div_adaEta hα]
  rfl

/-! ## Remark `I:rem:prog_m_measurability` -/

theorem measurable_histAns (i : ℕ) : Measurable (fun h : Fin k → RoundRec => histAns h i) := by
  rw [measurable_pi_iff]
  intro j
  by_cases hj : j.val < k
  · simp only [histAns, dif_pos hj]
    exact measurable_pi_apply _
  · simp only [histAns, dif_neg hj]
    exact measurable_const

theorem measurable_qry (A : DetAnalyst X) (hA : A.JointlyMeasurable) (i : ℕ) :
    Measurable (fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2) :=
  (hA i).comp (((measurable_histAns i).comp measurable_fst).prodMk measurable_snd)

/-- `μ_i(h) = ∫ A_i(h_{<i}) dD` is a measurable function of the transcript (Lemma `I:lem:tonelli_fubini`(ii),
Remark `I:rem:measurability_mu_i`). -/
theorem measurable_popMu (D : Measure X) [SFinite D] (A : DetAnalyst X) (hA : A.JointlyMeasurable)
    (i : ℕ) : Measurable (fun h : Fin k → RoundRec => popMu D A h i) := by
  unfold popMu
  exact (StronglyMeasurable.integral_prod_right'
    (f := fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2)
    (measurable_qry A hA i).stronglyMeasurable).measurable

theorem measurable_delta_apply (i : Fin k) (m : ℕ) :
    Measurable (fun h : Fin k → RoundRec => (h i).delta m) :=
  (measurable_pi_apply m).comp (RoundRec.measurable_delta.comp (measurable_pi_apply i))

theorem measurable_c_apply (i : Fin k) (m : ℕ) :
    Measurable (fun h : Fin k → RoundRec => (h i).c m) :=
  (measurable_pi_apply m).comp (RoundRec.measurable_c.comp (measurable_pi_apply i))

theorem measurable_progRound (α : ℝ) (D : Measure X) [SFinite D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (m : ℕ) (i : Fin k) :
    Measurable (fun h : Fin k → RoundRec => progRound α D A h m i) := by
  have hδ := measurable_delta_apply i m
  have hc := measurable_c_apply i m
  have hμ := measurable_popMu (k := k) D A hA i
  unfold progRound progSummand
  exact measurable_const.mul (((hδ.neg.mul (hc.sub hμ)).sub ((hδ.pow_const 2).div_const 8)).sub
    ((continuous_abs.measurable.comp hδ).mul_const _))

/-- Remark `I:rem:prog_m_measurability` (I.4.4): for a jointly measurable analyst, `h ↦ Prog_m(h)` is a
measurable function of the public transcript alone. -/
theorem measurable_progM (α : ℝ) (D : Measure X) [SFinite D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (m : ℕ) :
    Measurable (fun h : Fin k → RoundRec => progM α D A h m) := by
  simp_rw [progM_eq_sum_progRound]
  exact Finset.measurable_sum _ fun i _ => measurable_progRound α D A hA m i

/-! ## Lemma `I:lem:rl2_coupled_progress` -/

/-- A round of the transcript, as chain data: `∑_{m=2}^{L-1} Prog_{m,i}(h)` is the per-round sum of
`AccuracyRound` for the round's chain data (active rounds). -/
theorem sum_progRound_of_active (D : Measure X) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) (hi : (transcript k α β A S ω i).active = true) :
    ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A S ω) m i =
      ∑ m ∈ Finset.Icc 2 (adaL α - 1),
        progSummand (adaW α m) (adaU0 α)
          (((onlineChain k α β A S ω i).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).delta m)
          (((onlineChain k α β A S ω i).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c m)
          (popMu D A (transcript k α β A S ω) i) := by
  unfold progRound
  rw [transcript_of_active A S ω i hi]

/-- Lemma `I:lem:rl2_coupled_progress`(1), `I:eq:sec4_non_caseB_zero`: halted, Case-0 and Case-A rounds
(`u_final ≤ 2`; a halted round has `u_final = 0`) contribute `∑_{m=2}^{L-1} Prog_{m,i}(h) = 0`. -/
theorem coupled_progress_non_caseB (D : Measure X) (A : DetAnalyst X)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : Fin k)
    (hu : (transcript k α β A S ω i).ufinal ≤ 2) :
    ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A S ω) m i = 0 := by
  cases h : (transcript k α β A S ω i).active
  · refine Finset.sum_eq_zero fun m _ => ?_
    unfold progRound
    rw [transcript_of_halted A S ω i h, RoundRec.halted_delta, progSummand_zero]
  · rw [sum_progRound_of_active D A S ω i h]
    rw [transcript_of_active A S ω i h] at hu
    exact ChainData.round_progSum_of_ufinal_le_two hu _

/-- Lemma `I:lem:rl2_coupled_progress`(3), `I:eq:sec4_interior_net_prog`: on `E_clean`, an interior Case-B
round (`u_final = r' ∈ {3, …, L-1}`) contributes `∑_{m=2}^{L-1} Prog_{m,i}(h) ≥ (106/64) w_{r'-1} γ²`. -/
theorem coupled_progress_interior (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (i : Fin k) (hB : 3 ≤ (transcript k α β A z.1 z.2 i).ufinal)
    (hBL : (transcript k α β A z.1 z.2 i).ufinal + 1 ≤ adaL α) :
    106 / 64 * adaW α ((transcript k α β A z.1 z.2 i).ufinal - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i := by
  obtain ⟨hlk, hc, hθ, -, -⟩ := clean_envelopes hα D A hA z hz i
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [sum_progRound_of_active D A z.1 z.2 i hact]
  rw [transcript_of_active A z.1 z.2 i hact] at hB hBL ⊢
  exact ChainData.round_progSum_interior_ge hα hα' hlk hc hθ hB hBL _

/-- Lemma `I:lem:rl2_coupled_progress`(4), `I:eq:sec4_terminal_net_prog`: on `E_clean`, a terminal Case-B
round (`u_final = L`) contributes `∑_{m=2}^{L-1} Prog_{m,i}(h) = Prog_{L-1,i}(h) ≥ (103/64) w_{L-1} γ²`. -/
theorem coupled_progress_terminal (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (i : Fin k) (hBL : (transcript k α β A z.1 z.2 i).ufinal = adaL α) :
    103 / 64 * adaW α (adaL α - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i := by
  obtain ⟨hlk, hc, hθ, -, hanc⟩ := clean_envelopes hα D A hA z hz i
  have hL5 := five_le_adaL hα hα'
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [sum_progRound_of_active D A z.1 z.2 i hact]
  rw [transcript_of_active A z.1 z.2 i hact] at hBL
  exact ChainData.round_progSum_terminal_ge hα hα' hlk hc hθ hanc hBL

/-- Lemma `I:lem:rl2_coupled_progress`(3)-(4): on `E_clean`, every Case-B round (`u_final = r' ≥ 3`)
contributes `∑_{m=2}^{L-1} Prog_{m,i}(h) > 1.5 w_{r'-1} γ² > 0`. -/
theorem coupled_progress_caseB (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (i : Fin k) (hB : 3 ≤ (transcript k α β A z.1 z.2 i).ufinal) :
    3 / 2 * adaW α ((transcript k α β A z.1 z.2 i).ufinal - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i := by
  obtain ⟨hlk, hc, hθ, -, hanc⟩ := clean_envelopes hα D A hA z hz i
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [sum_progRound_of_active D A z.1 z.2 i hact]
  rw [transcript_of_active A z.1 z.2 i hact] at hB ⊢
  exact ChainData.round_progSum_caseB_ge hα hα' hlk hc hθ hanc hB

/-- On `E_clean`, every round contributes `∑_{m=2}^{L-1} Prog_{m,i}(h) ≥ 0`, and at least
`1.5 w_{r'-1} γ²` if it is a Case-B round with `u_final = r' ≥ 3` (then `r' ≤ L`). -/
theorem coupled_progress_round (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (i : Fin k) :
    0 ≤ ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i ∧
      (3 ≤ (transcript k α β A z.1 z.2 i).ufinal →
        (transcript k α β A z.1 z.2 i).ufinal ≤ adaL α ∧
        3 / 2 * adaW α ((transcript k α β A z.1 z.2 i).ufinal - 1) * adaGamma α ^ 2 ≤
          ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i) := by
  have hle : (transcript k α β A z.1 z.2 i).ufinal ≤ adaL α := by
    rw [transcript_eq_roundRec]
    exact roundRec_ufinal_le _ _ _
  by_cases hB : 3 ≤ (transcript k α β A z.1 z.2 i).ufinal
  · have h := coupled_progress_caseB hα hα' D A hA z hz i hB
    have hW := adaW_pos hα ((transcript k α β A z.1 z.2 i).ufinal - 1)
    have hγ := adaGamma_pos hα
    have h0 : 0 ≤ 3 / 2 * adaW α ((transcript k α β A z.1 z.2 i).ufinal - 1) * adaGamma α ^ 2 := by
      positivity
    exact ⟨h0.trans h, fun _ => ⟨hle, h⟩⟩
  · rw [coupled_progress_non_caseB D A z.1 z.2 i (by omega)]
    exact ⟨le_rfl, fun h => absurd h hB⟩

/-- `∑_{m=2}^{L-1} Prog_m(h) = ∑_i ∑_{m=2}^{L-1} Prog_{m,i}(h)` (first equality of
`I:eq:sec4_branch_sum_decomp`). -/
theorem sum_progM_eq (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) :
    ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A h m =
      ∑ i, ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A h m i := by
  simp_rw [progM_eq_sum_progRound]
  exact Finset.sum_comm

/-- Lemma `I:lem:rl2_coupled_progress`(5), `I:eq:sec4_branch_sum_decomp`: on `E_clean`,
`∑_{m=2}^{L-1} Prog_m(h) ≥ ∑_{r'=3}^{L} 1.5 w_{r'-1} γ² N_{r'}`. -/
theorem coupled_progress_branches (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z) :
    ∑ r ∈ Finset.Icc 3 (adaL α),
        3 / 2 * adaW α (r - 1) * adaGamma α ^ 2 * (finalN (transcript k α β A z.1 z.2) r : ℝ) ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A (transcript k α β A z.1 z.2) m := by
  rw [sum_progM_eq]
  have hround := coupled_progress_round hα hα' D A hA z hz
  exact sum_branch_le Finset.univ _ (fun i => (transcript k α β A z.1 z.2 i).ufinal)
    (fun r => 3 / 2 * adaW α (r - 1) * adaGamma α ^ 2) (adaL α) (fun i _ => (hround i).1)
    (fun i _ => (hround i).2)

/-- Lemma `I:lem:rl2_coupled_progress`(5), `I:eq:sec4_global_halt_prog`: on `E_halt(h) ∩ E_clean`,
`∑_{m=2}^{L-1} Prog_m(h) ≥ 1.5 w_{r*-1} γ² N_{r*,max} ≥ 192 L` (and `192 L > 128(L-2)`,
`halt_progress_margin`). -/
theorem coupled_progress_halt (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (hH : EHalt α (transcript k α β A z.1 z.2)) :
    192 * (adaL α : ℝ) ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A (transcript k α β A z.1 z.2) m := by
  obtain ⟨r, hr3, hrL, hN⟩ := hH
  rw [sum_progM_eq]
  have hround := coupled_progress_round hα hα' D A hA z hz
  have h1 := mul_card_le_sum Finset.univ
    (fun i => ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A z.1 z.2) m i)
    (fun i => (transcript k α β A z.1 z.2 i).ufinal) r (3 / 2 * adaW α (r - 1) * adaGamma α ^ 2)
    (fun i _ => (hround i).1) (fun i _ hu => by
      have := ((hround i).2 (by omega)).2
      rwa [hu] at this)
  have h2 := halt_progress_bound hα (r := r) (N := finalN (transcript k α β A z.1 z.2) r) hN.ge
  unfold finalN at h2
  linarith

end Prog

end A

end F2e2e
