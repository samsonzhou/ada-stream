import F2e2e.A.AccuracyCore
import F2e2e.A.NumericsThreshold

/-!
# Part I §4 for one round with the locked parameters

Owner: A-ACC. Paper: `parts/partI.tex` L1148-1531 (Section 4), with the locked parameters of Definition
`I:def:locked_parameters` and Lemma `I:lem:threshold_properties` (`F2e2e/A/NumericsThreshold.lean`).

This file specializes the deterministic core `F2e2e/A/AccuracyCore.lean` to chain data carrying the locked
depth `L = adaL α` and threshold matrix `τ = adaTau α` (`ChainData.Locked`, true for every `roundChain`),
with `u₀ = adaU0 α`, `r_anc = adaRanc α`, `R₁ = adaR1 α`, `γ = adaGamma α`, `w_m = adaW α m`,
`η = adaEta α`, `η̃ = adaEtaTilde α`. Everything is per round and deterministic.

## Main results
* `ChainData.round_output_accuracy`: Lemma `I:lem:output_accuracy`(ii), `I:eq:sec4_ai_accuracy`:
  `|a - μ| ≤ τ_{(u_final,L)} + 4u₀ + r_anc < 3α/4 + 6u₀ < α`.
* `ChainData.round_caseA_gap`, `ChainData.round_caseA_answer_err`, `ChainData.round_stage1_drift_ge`,
  `ChainData.round_stage1_drift_gt`, `ChainData.round_stage1_sgn_eq`: Lemma `I:lem:stage1_decoupling`
  (`I:eq:sec4_caseA_c1_c2_gap`, `I:eq:sec4_caseA_ai_mui_bound`, `I:eq:sec4_stage1_drift_lb`).
* `ChainData.round_caseB_adj_gap`, `ChainData.round_caseB_terminal_gap`: `I:eq:sec4_interior_adj_gap`
  (`2γ - 8u₀ = 28γ/16`) and `I:eq:sec4_terminal_adj_gap` (`2γ - 11u₀ = 53γ/32`).
* `ChainData.round_progSum_interior_ge` (`106/64`), `ChainData.round_progSum_terminal_ge` (`103/64`),
  `ChainData.round_progSum_caseB_ge` (`> 1.5 w_{r'-1} γ²`), `ChainData.round_progSum_of_ufinal_le_two`
  (`= 0`): Lemma `I:lem:rl2_coupled_progress`(1),(3),(4) (`I:eq:sec4_interior_net_prog`,
  `I:eq:sec4_terminal_net_prog`, `I:eq:sec4_non_caseB_zero`).
* `halt_progress_bound`: `1.5 w_{r*-1} γ² N ≥ 192 L` for `N ≥ N_{r*,max}` (`I:eq:sec4_global_halt_prog`).
-/

namespace F2e2e

namespace A

namespace ChainData

/-- The chain data carries the locked depth `L = adaL α` and the locked threshold matrix `τ = adaTau α`
(Definition `I:def:locked_parameters` (P1), (P4)); true for every `roundChain` (`roundChain_locked`). -/
def Locked (d : ChainData) (α : ℝ) : Prop := d.L = adaL α ∧ d.tau = adaTau α

variable {d : ChainData} {α : ℝ}

theorem Locked.L_eq (hlk : d.Locked α) : d.L = adaL α := hlk.1

theorem Locked.tau_eq (hlk : d.Locked α) : d.tau = adaTau α := hlk.2

theorem Locked.tau_self (hlk : d.Locked α) (r : ℕ) : d.tau r r = 0 := by
  rw [hlk.2]
  exact adaTau_self α r

/-! ## Lemma `I:lem:output_accuracy`(ii) -/

/-- Lemma `I:lem:output_accuracy`(ii) for one clean round, `I:eq:sec4_ai_accuracy`:
`|a_i - μ_i| ≤ τ_{(u_final,L)} + 4u₀ + r_anc < 3α/4 + 6u₀ < α`, given the anchor envelope
`|θ_i^{(L)}(S_L) - μ_i| ≤ r_anc`. -/
theorem round_output_accuracy (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α) :
    |d.answer - μ| ≤ adaTau α d.ufinal (adaL α) + 4 * adaU0 α + adaRanc α ∧
      adaTau α d.ufinal (adaL α) + 4 * adaU0 α + adaRanc α < 3 / 4 * α + 6 * adaU0 α ∧
      3 / 4 * α + 6 * adaU0 α < α := by
  have hL5 := five_le_adaL hα hα'
  have hL2 : 2 ≤ d.L := by rw [hlk.L_eq]; omega
  have h1 := abs_answer_sub_mu_le hc hθ hL2 (hlk.tau_self d.L) hanc
  rw [hlk.tau_eq, hlk.L_eq] at h1
  have hu1 := d.one_le_ufinal
  have hu2 := d.ufinal_le_L (by omega)
  rw [hlk.L_eq] at hu2
  have h2 := adaTau_add_le hα hu1 hu2
  have h3 := adaTau_one_L_lt hα
  have h4 := six_adaU0_lt hα
  exact ⟨h1, by linarith, by linarith⟩

theorem round_abs_answer_sub_mu_lt (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α) :
    |d.answer - μ| < α := by
  obtain ⟨h1, h2, h3⟩ := round_output_accuracy hα hα' hlk hc hθ hanc
  linarith

/-! ## Lemma `I:lem:stage1_decoupling` -/

/-- `I:eq:sec4_caseA_c1_c2_gap`: in Case A, `|c^{(1)} - c^{(2)}| ≥ τ_{(1,2)} - 4u₀ = α/2 - 4u₀`. -/
theorem round_caseA_gap (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hA : d.ufinal = 2) :
    α / 2 - 4 * adaU0 α ≤ |d.c1 - d.relC 2| := by
  have hL5 := five_le_adaL hα hα'
  have h := caseA_gap hc hθ hA (by rw [hlk.L_eq]; omega)
  rwa [hlk.tau_eq, adaTau_one_two] at h

/-- `I:eq:sec4_caseA_ai_mui_bound`: in Case A, `|a - μ| ≤ τ_{(2,L)} + 4u₀ + r_anc = 2(L-2)γ + 6u₀`. -/
theorem round_caseA_answer_err (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α)
    (hA : d.ufinal = 2) :
    |d.answer - μ| ≤ 2 * ((adaL α : ℝ) - 2) * adaGamma α + 6 * adaU0 α := by
  have hL5 := five_le_adaL hα hα'
  have h1 := abs_answer_sub_mu_le hc hθ (by rw [hlk.L_eq]; omega) (hlk.tau_self d.L) hanc
  rw [hA, hlk.tau_eq, hlk.L_eq, adaTau_two_L, adaRanc_eq_two_u0] at h1
  linarith

/-- `I:eq:sec4_stage1_drift_lb` (first inequality): in Case A,
`s^{(1)}(θ_i^{(1)}(S₁) - μ_i) ≥ (α/2 - 4u₀) - R₁ - (α/4 + 6u₀) = 7α/32 - 10u₀`. -/
theorem round_stage1_drift_ge (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hc1 : |d.c1 - d.theta 1| < adaR1 α) {μ : ℝ}
    (hanc : |d.theta d.L - μ| ≤ adaRanc α) (hA : d.ufinal = 2) :
    7 / 32 * α - 10 * adaU0 α ≤ d.sgn * (d.theta 1 - μ) := by
  have hg := round_caseA_gap hα hα' hlk hc hθ hA
  have he := round_caseA_answer_err hα hα' hlk hc hθ hanc hA
  have hlt := two_mul_adaL_sub_two_mul_adaGamma_lt hα
  have hdr := caseA_drift_ge hA μ
  have hR : adaR1 α = α / 32 := rfl
  rw [hR] at hc1
  linarith

/-- `I:eq:sec4_stage1_drift_lb`: in Case A, `s^{(1)}(θ_i^{(1)}(S₁) - μ_i) > 3α/16`, independently of `L`
(`10u₀ ≤ 10α/1280 < α/32`). -/
theorem round_stage1_drift_gt (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hc1 : |d.c1 - d.theta 1| < adaR1 α) {μ : ℝ}
    (hanc : |d.theta d.L - μ| ≤ adaRanc α) (hA : d.ufinal = 2) :
    3 / 16 * α < d.sgn * (d.theta 1 - μ) := by
  have h := round_stage1_drift_ge hα hα' hlk hc hθ hc1 hanc hA
  have hu := adaU0_le hα hα'
  linarith

/-- `3α/16 > α/8 = γ₁` (the last inequality of `I:eq:sec4_stage1_drift_lb`). -/
theorem adaGamma1_lt (hα : 0 < α) : adaGamma1 α < 3 / 16 * α := by
  unfold adaGamma1
  linarith

/-- Lemma `I:lem:stage1_decoupling`: in Case A the public sign is `s^{(1)} = sign(c^{(1)} - a) =
sign(θ_i^{(1)}(S₁) - μ_i)`. -/
theorem round_stage1_sgn_eq (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hc1 : |d.c1 - d.theta 1| < adaR1 α) {μ : ℝ}
    (hanc : |d.theta d.L - μ| ≤ adaRanc α) (hA : d.ufinal = 2) :
    d.sgn = sgn1 (d.theta 1 - μ) := by
  have h := round_stage1_drift_gt hα hα' hlk hc hθ hc1 hanc hA
  rw [sgn_of_caseA hA] at h ⊢
  exact (sgn1_eq_of_pos_mul (by linarith)).symm

/-! ## Lemma `I:lem:rl2_coupled_progress`(2)-(4) -/

/-- `I:eq:sec4_interior_adj_gap` (also valid at `r' = L`): in Case B,
`s_{i,r'}(c^{(r'-1)} - c^{(r')}) ≥ (τ_{(u_prev,r')} - τ_{(u_prev,r'-1)}) - 8u₀ = 2γ - 8u₀ = 28γ/16`. -/
theorem round_caseB_adj_gap (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hB : 3 ≤ d.ufinal) :
    28 / 16 * adaGamma α ≤ d.sgn * (d.relC (d.ufinal - 1) - d.relC d.ufinal) := by
  have hL5 := five_le_adaL hα hα'
  have h := caseB_adj_gap hc hθ hB (by rw [hlk.L_eq]; omega) (hlk.tau_self _)
  have hlt := d.uprev_lt (r := d.ufinal) (by omega)
  have hu1 := d.one_le_uprev d.ufinal
  rw [hlk.tau_eq, adaTau_sub_pred α hB hu1 (by omega)] at h
  have hu0 : adaU0 α = adaGamma α / 32 := rfl
  rw [hu0] at h
  linarith

/-- `I:eq:sec4_terminal_adj_gap`: in a terminal Case-B round (`u_final = L`),
`s_{i,L}(c^{(L-1)} - μ_i) ≥ 2γ - 9u₀ - r_anc = 2γ - 11u₀ = 53γ/32`. -/
theorem round_caseB_terminal_gap (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α)
    (hBL : d.ufinal = adaL α) :
    53 / 32 * adaGamma α ≤ d.sgn * (d.relC (adaL α - 1) - μ) := by
  have hL5 := five_le_adaL hα hα'
  have hdL := hlk.L_eq
  have h := caseB_terminal_gap hc hθ (by rw [hdL]; exact hBL) (by rw [hdL]; omega)
    (hlk.tau_self _) hanc
  rw [hdL, hlk.tau_eq] at h
  have hlt := d.uprev_lt (r := adaL α) (by omega)
  have hu1 := d.one_le_uprev (adaL α)
  rw [adaTau_sub_pred α (by omega) hu1 (by omega), adaRanc_eq_two_u0] at h
  have hu0 : adaU0 α = adaGamma α / 32 := rfl
  rw [hu0] at h
  linarith

theorem adaEta_nonneg (hα : 0 < α) : 0 ≤ adaEta α := by
  unfold adaEta
  have := adaGamma_pos hα
  positivity

theorem adaEtaTilde_nonneg (hα : 0 < α) (r : ℕ) : 0 ≤ adaEtaTilde α r := by
  unfold adaEtaTilde
  split_ifs
  · exact le_rfl
  · have h1 := adaW_pos hα (r - 1)
    have h2 := adaW_pos hα r
    have h3 := adaEta_nonneg hα
    positivity

/-- I.4.5(3), `I:eq:sec4_interior_net_prog`: an interior Case-B round (`3 ≤ r' ≤ L - 1`) contributes
`∑_{m=2}^{L-1} Prog_{m,i} ≥ (28/16 - 6/64) w_{r'-1} γ² = (106/64) w_{r'-1} γ²`. -/
theorem round_progSum_interior_ge (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) (hB : 3 ≤ d.ufinal) (hBL : d.ufinal + 1 ≤ adaL α)
    (μ : ℝ) :
    106 / 64 * adaW α (d.ufinal - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1),
        progSummand (adaW α m) (adaU0 α) ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).delta m)
          ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c m) μ := by
  have hgap := round_caseB_adj_gap hα hα' hlk hc hθ hB
  have hγ := adaGamma_pos hα
  have hW := adaW_pos hα (d.ufinal - 1)
  have hne : d.ufinal ≠ adaL α := by omega
  have hK1 := eight_adaW_adaEta α (d.ufinal - 1)
  have hK2 := eight_adaW_adaEtaTilde hα hne
  have hsq := adaW_mul_adaEtaTilde_sq_lt hα hα' (by omega : 2 ≤ d.ufinal) hne
  have hs := progSum_caseB_interior hB (by rw [hlk.L_eq]; exact hBL) (adaW α) (adaU0 α) μ
    (adaEta1 α) (adaEta α) _ (adaEtaTilde α) (adaEta_nonneg hα) (adaEtaTilde_nonneg hα _) hK1 hK2
  rw [hlk.L_eq] at hs
  rw [hs]
  have h1 : adaW α (d.ufinal - 1) * adaGamma α * (28 / 16 * adaGamma α) ≤
      adaW α (d.ufinal - 1) * adaGamma α * (d.sgn * (d.relC (d.ufinal - 1) - d.relC d.ufinal)) :=
    mul_le_mul_of_nonneg_left hgap (by positivity)
  have hη : adaEta α = adaGamma α / 8 := rfl
  have hu0 : adaU0 α = adaGamma α / 32 := rfl
  rw [hη] at hsq ⊢
  rw [hu0]
  nlinarith

/-- I.4.5(4), `I:eq:sec4_terminal_net_prog`: a terminal Case-B round (`u_final = L`) contributes
`∑_{m=2}^{L-1} Prog_{m,i} = Prog_{L-1,i} ≥ (53/32 - 3/64) w_{L-1} γ² = (103/64) w_{L-1} γ²`. -/
theorem round_progSum_terminal_ge (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α)
    (hBL : d.ufinal = adaL α) :
    103 / 64 * adaW α (adaL α - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1),
        progSummand (adaW α m) (adaU0 α) ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).delta m)
          ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c m) μ := by
  have hgap := round_caseB_terminal_gap hα hα' hlk hc hθ hanc hBL
  have hL5 := five_le_adaL hα hα'
  have hγ := adaGamma_pos hα
  have hW := adaW_pos hα (adaL α - 1)
  have hs := progSum_caseB_terminal (by rw [hlk.L_eq]; exact hBL) (by rw [hlk.L_eq]; omega)
    (adaW α) (adaU0 α) μ (adaEta1 α) (adaEta α) (adaEtaTilde α) (adaEta_nonneg hα)
  rw [hlk.L_eq] at hs
  rw [hs]
  have h1 : adaW α (adaL α - 1) * adaGamma α * (53 / 32 * adaGamma α) ≤
      adaW α (adaL α - 1) * adaGamma α * (d.sgn * (d.relC (adaL α - 1) - μ)) :=
    mul_le_mul_of_nonneg_left hgap (by positivity)
  have hη : adaEta α = adaGamma α / 8 := rfl
  have hu0 : adaU0 α = adaGamma α / 32 := rfl
  rw [hη, hu0]
  nlinarith

/-- I.4.5(3)-(4): every Case-B round (`u_final = r' ≥ 3`) contributes
`∑_{m=2}^{L-1} Prog_{m,i} > 1.5 w_{r'-1} γ² > 0`. -/
theorem round_progSum_caseB_ge (hα : 0 < α) (hα' : α < 1 / 16) (hlk : d.Locked α)
    (hc : d.Clean (adaU0 α)) (hθ : d.ThetaMem) {μ : ℝ} (hanc : |d.theta d.L - μ| ≤ adaRanc α)
    (hB : 3 ≤ d.ufinal) :
    3 / 2 * adaW α (d.ufinal - 1) * adaGamma α ^ 2 ≤
      ∑ m ∈ Finset.Icc 2 (adaL α - 1),
        progSummand (adaW α m) (adaU0 α) ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).delta m)
          ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c m) μ := by
  have hL5 := five_le_adaL hα hα'
  have hγ := adaGamma_pos hα
  have hu := d.ufinal_le_L (by rw [hlk.L_eq]; omega)
  rw [hlk.L_eq] at hu
  rcases lt_or_eq_of_le hu with h | h
  · have h1 := round_progSum_interior_ge hα hα' hlk hc hθ hB (by omega) μ
    have hW := adaW_pos hα (d.ufinal - 1)
    have h2 : 3 / 2 * adaW α (d.ufinal - 1) * adaGamma α ^ 2 ≤
        106 / 64 * adaW α (d.ufinal - 1) * adaGamma α ^ 2 := by
      have : 0 ≤ adaW α (d.ufinal - 1) * adaGamma α ^ 2 := by positivity
      nlinarith
    linarith
  · have h1 := round_progSum_terminal_ge hα hα' hlk hc hθ hanc h
    have hW := adaW_pos hα (adaL α - 1)
    rw [h]
    have h2 : 3 / 2 * adaW α (adaL α - 1) * adaGamma α ^ 2 ≤
        103 / 64 * adaW α (adaL α - 1) * adaGamma α ^ 2 := by
      have : 0 ≤ adaW α (adaL α - 1) * adaGamma α ^ 2 := by positivity
      nlinarith
    linarith

/-- I.4.5(1), `I:eq:sec4_non_caseB_zero`: Case-0 and Case-A rounds contribute `0`. -/
theorem round_progSum_of_ufinal_le_two (hu : d.ufinal ≤ 2) (μ : ℝ) :
    ∑ m ∈ Finset.Icc 2 (adaL α - 1),
        progSummand (adaW α m) (adaU0 α) ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).delta m)
          ((d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c m) μ = 0 :=
  progSum_of_ufinal_le_two hu _ _ _ _ _ _ _

end ChainData

/-- `roundChain` carries the locked depth and threshold matrix. -/
theorem roundChain_locked {k : ℕ} {α β : ℝ} (st : MState k α β) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) : (roundChain st i q ω).Locked α :=
  ⟨rfl, rfl⟩

/-- I.4.5(5), the last step of `I:eq:sec4_global_halt_prog`: for `N ≥ N_{r*,max} = ⌈128 L ε_{r*-1}²/γ²⌉`,
`1.5 w_{r*-1} γ² N ≥ 1.5 ε_{r*-1}^{-2} γ² · 128 L ε_{r*-1}²/γ² = 192 L`. -/
theorem halt_progress_bound {α : ℝ} (hα : 0 < α) {r N : ℕ} (hN : adaNmax α r ≤ N) :
    192 * (adaL α : ℝ) ≤ 3 / 2 * adaW α (r - 1) * adaGamma α ^ 2 * N := by
  have hε := adaEps_pos hα (r - 1)
  have hγ := adaGamma_pos hα
  have hN' : ((adaNmax α r : ℕ) : ℝ) ≤ (N : ℝ) := Nat.cast_le.mpr hN
  have hc : 128 * (adaL α : ℝ) * adaEps α (r - 1) ^ 2 / adaGamma α ^ 2 ≤ (N : ℝ) :=
    (Nat.le_ceil _).trans hN'
  rw [div_le_iff₀ (by positivity)] at hc
  unfold adaW
  have e : 3 / 2 * (1 / adaEps α (r - 1) ^ 2) * adaGamma α ^ 2 * (N : ℝ) =
      3 / 2 * ((N : ℝ) * adaGamma α ^ 2) / adaEps α (r - 1) ^ 2 := by ring
  rw [e, le_div_iff₀ (by positivity)]
  linarith

/-- `192 L > 128 (L - 2)` (the pigeonhole margin of `I:eq:sec4_global_halt_prog`). -/
theorem halt_progress_margin (α : ℝ) : 128 * ((adaL α : ℝ) - 2) < 192 * (adaL α : ℝ) := by
  have := adaL_cast_pos α
  linarith

end A

end F2e2e
