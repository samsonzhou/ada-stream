import F2e2e.A.S1PrivacyTriangular
import F2e2e.Lib.Dist.BetaSymLoss
import F2e2e.Lib.Prob.Freedman
import F2e2e.Lib.DP.Loss

/-!
# Stage-1 privacy, Steps 2–4: the privacy-loss tail of adaptive symmetric-Beta releases

Part I, Lemma `I:lem:working_sample_privacy` (3) (`parts/partI.tex` L670–797), in a parametric form.

Setting (Step 1, L670–696): i.i.d. noises `V_i ∼ f_m` (`Dist.betaSym m`), releases `ã = Φ(V)` generated
adaptively, `ã_i = θ_i(ã_{<i}) + R V_i`, under two adjacent datasets (`θ`, `θ'`) whose per-round means differ by
at most `R h` (`|η_i| ≤ h` for the normalized shift `η_i = d_i/R`, eq. `I:eq:stage1_normalized_shift_bound`).

* Steps 2–4 (L699–786) on the noise space: with `κ = 64 m L h` (eq. `I:eq:kappa_interior_def`), the safe
  interior `G_k = ⋂ {1 - V_i² ≥ κ}`, the truncated losses `Y_i = truncLLR m κ η_i V_i`, drifts
  `μ_i = E[Y_i | F_{i-1}]` and martingale differences `D_i = Y_i - μ_i ≤ b = 1/(31L)`, Freedman's inequality
  (`F2e2e.Prob.freedman_pi`) and the boundary tail (`Dist.betaSym_tail_le`) give
  `P[∏ f(V_i) > e^ε ∏ f(V_i - η_i)] ≤ δ` (`betaSym_pi_ratio_tail`).
* Conclusion (L787–795): the laws of `ã` under the two datasets have the densities
  `∏_i ρ(a_i - θ_i(a))`, `∏_i ρ(a_i - θ'_i(a))` with respect to Lebesgue measure on `ℝ^k`
  (`map_triangularSol_pi_withDensity`), whose ratio at `a = Φ(V)` is `∏ f(V_i)/∏ f(V_i - η_i)`; the two-density
  comparison (`DP.indist_of_two_densities`) gives `(ε, δ)`-indistinguishability (`releases_indist_of_params`).

The numeric hypotheses are bundled in `S1NoiseParams` (verified for the locked parameters in
`F2e2e.A.S1PrivacyNumerics`).
-/

namespace F2e2e.A

open MeasureTheory ProbabilityTheory F2e2e.Dist
open scoped ENNReal

/-- Numeric hypotheses of Steps 2–4 of `I:lem:working_sample_privacy`, for `k` rounds, noise exponent `m`
(`V ∼ f_m`), normalized sensitivity `h`, the log-parameter `L` (the paper's `L₁`), target `(ε, δ)` and Freedman
threshold `z`. Here `κ = 64 m L h` (eq. `I:eq:kappa_interior_def`), `b = 1/(31 L)` (eq.
`I:eq:stage1_step_range_b`), the drift per round is at most `0.67 𝓘_m h²` (eq. `I:eq:stage1_drift_bound`), the
conditional variance per round at most `1.03 𝓘_m h²` (eq. `I:eq:stage1_cond_var_bound`), and the failure
probability is the union bound over the `k` boundary tails (eq. `I:eq:beta_boundary_tail`) plus Freedman's bound
(eq. `I:eq:Mk_freedman_tail`). -/
structure S1NoiseParams (k m : ℕ) (h L ε δ z : ℝ) : Prop where
  two_le_m : 2 ≤ m
  L_pos : 0 < L
  h_pos : 0 < h
  h_le : h ≤ 1 / 1000
  mL_ge : 5990 ≤ 64 * (m : ℝ) * L
  kappa_lt_one : 64 * (m : ℝ) * L * h < 1
  hmh : 12.8 * h ^ 2 * (2 * (m : ℝ) - 1) ≤ 0.0089
  z_pos : 0 < z
  drift_le : (k : ℝ) * (0.67 * betaSymFisher m * h ^ 2) + z ≤ ε
  tail_le : (k : ℝ) * ((64 * (m : ℝ) * L * h) ^ (m + 1) /
        (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - 64 * (m : ℝ) * L * h))) +
      Real.exp (-(z ^ 2 / (2 * ((k : ℝ) * (1.03 * betaSymFisher m * h ^ 2) + 1 / (31 * L) * z / 3)))) ≤ δ

/-- The conditional drift `g(η) = E_{V ∼ f_m}[Y(η, V)]` of the truncated per-round loss. -/
noncomputable def s1Drift (m : ℕ) (κ η : ℝ) : ℝ := ∫ x, truncLLR m κ η x ∂(betaSym m)

lemma measurable_s1Drift (m : ℕ) (κ : ℝ) : Measurable (s1Drift m κ) :=
  (StronglyMeasurable.integral_prod_right' (ν := betaSym m)
    (f := fun p : ℝ × ℝ => truncLLR m κ p.1 p.2)
    (measurable_truncLLR_uncurry m κ).stronglyMeasurable).measurable

/-- **Steps 2–4 (noise space).** For adapted shifts `η_i(V_{<i})` with `|η_i| ≤ h`, the probability under
i.i.d. `f_m` noise that the likelihood ratio `∏ f_m(V_i) / ∏ f_m(V_i - η_i)` exceeds `e^ε` is at most `δ`. -/
theorem betaSym_pi_ratio_tail {k m : ℕ} {h L ε δ z : ℝ} (hp : S1NoiseParams k m h L ε δ z)
    {η : Fin k → (Fin k → ℝ) → ℝ} (hηm : ∀ i, Measurable (η i))
    (hηdep : ∀ i, DependsOn (η i) (Set.Iio i)) (hηh : ∀ i v, |η i v| ≤ h) :
    Measure.pi (fun _ : Fin k => betaSym m)
        {v | ENNReal.ofReal (Real.exp ε) * ∏ i, betaSymPDF m (v i - η i v) < ∏ i, betaSymPDF m (v i)} ≤
      ENNReal.ofReal δ := by
  classical
  obtain ⟨hm2, hL, hh0, hh, hmL, hκ1, hmh, hz, hdrift, htail⟩ := hp
  set κ : ℝ := 64 * (m : ℝ) * L * h with hκdef
  set b : ℝ := 1 / (31 * L) with hbdef
  set I : ℝ := betaSymFisher m with hIdef
  have hκ0 : 0 < κ := by
    have : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
    positivity
  have hhκ : 5990 * h ≤ κ := by
    rw [hκdef]; nlinarith
  have h2hκ : 2 * h < κ := two_mul_lt_of_paper hκ0 hh0.le hhκ
  have hb0 : 0 < b := by positivity
  -- the per-round quantities
  set Y : Fin k → (Fin k → ℝ) → ℝ := fun i v => truncLLR m κ (η i v) (v i) with hYdef
  set D : Fin k → (Fin k → ℝ) → ℝ := fun i v => Y i v - s1Drift m κ (η i v) with hDdef
  -- one-dimensional facts
  have hYb : ∀ e x, |e| ≤ h → |truncLLR m κ e x| ≤ b := fun e x he =>
    abs_truncLLR_le_inv_L1 m (by omega) hL hh0 rfl he hh hhκ x
  have hIntY : ∀ e, |e| ≤ h → Integrable (truncLLR m κ e) (betaSym m) := fun e he =>
    integrable_truncLLR m hκ0 he hh hhκ m
  have hg0 : ∀ e, |e| ≤ h → 0 ≤ s1Drift m κ e := fun e he =>
    integral_truncLLR_nonneg m hκ0 he hh hhκ
  have hgdrift : ∀ e, |e| ≤ h → s1Drift m κ e ≤ 0.67 * I * h ^ 2 := fun e he =>
    (integral_truncLLR_le_fisher m hm2 hκ0 he hh hhκ hmh).2
  have hgb : ∀ e, |e| ≤ h → s1Drift m κ e ≤ b := by
    intro e he
    calc s1Drift m κ e ≤ ∫ _x, b ∂(betaSym m) :=
          integral_mono (hIntY e he) (integrable_const b) fun x => (le_abs_self _).trans (hYb e x he)
      _ = b := by simp
  have hsq : ∀ e, |e| ≤ h → ∫ x, truncLLR m κ e x ^ 2 ∂(betaSym m) ≤ 1.03 * I * h ^ 2 := fun e he =>
    integral_truncLLR_sq_le_fisher m hm2 hκ0 he hh hhκ hmh
  -- Freedman's inequality for the martingale differences `D_i`
  have hDmeas : ∀ i, Measurable (D i) := fun i =>
    ((measurable_truncLLR_uncurry m κ).comp ((hηm i).prodMk (measurable_pi_apply i))).sub
      ((measurable_s1Drift m κ).comp (hηm i))
  have hDdep : ∀ i, DependsOn (D i) (Set.Iic i) := by
    intro i v w hvw
    have h1 : η i v = η i w := hηdep i (fun j hj => hvw j (Set.mem_Iic.2 (le_of_lt hj)))
    have h2 : v i = w i := hvw i (Set.mem_Iic.2 le_rfl)
    simp only [hDdef, hYdef, h1, h2]
  have hDup : ∀ i v, D i v ≤ b := fun i v => by
    have := hg0 _ (hηh i v)
    have := (le_abs_self _).trans (hYb (η i v) (v i) (hηh i v))
    simp only [hDdef, hYdef]
    linarith
  have hDbdd : ∀ i v, |D i v| ≤ 2 * b := fun i v => by
    have h1 := hg0 _ (hηh i v)
    have h2 := hgb _ (hηh i v)
    have h3 := abs_le.1 (hYb (η i v) (v i) (hηh i v))
    simp only [hDdef, hYdef]
    rw [abs_le]
    constructor <;> linarith [h3.1, h3.2]
  have hupd : ∀ i v x, η i (Function.update v i x) = η i v := fun i v x =>
    hηdep i (fun j hj => Function.update_of_ne (ne_of_lt hj) _ _)
  have hDmean : ∀ i v, ∫ x, D i (Function.update v i x) ∂(betaSym m) = 0 := by
    intro i v
    simp only [hDdef, hYdef, hupd, Function.update_self]
    rw [integral_sub (hIntY _ (hηh i v)) (integrable_const _), integral_const]
    simp [s1Drift]
  have hDvar : ∀ i v, ∫ x, (D i (Function.update v i x)) ^ 2 ∂(betaSym m) ≤ 1.03 * I * h ^ 2 := by
    intro i v
    simp only [hDdef, hYdef, hupd, Function.update_self]
    set e := η i v
    have he := hηh i v
    set c := s1Drift m κ e with hc
    have hY2 : Integrable (fun x => truncLLR m κ e x ^ 2) (betaSym m) := by
      refine Integrable.mono' (integrable_const (b ^ 2)) ?_ (Filter.Eventually.of_forall fun x => ?_)
      · exact ((measurable_truncLLR m κ e).pow_const 2).aestronglyMeasurable
      · rw [Real.norm_eq_abs, abs_pow]
        exact pow_le_pow_left₀ (abs_nonneg _) (hYb e x he) 2
    have hexp : ∀ x, (truncLLR m κ e x - c) ^ 2 = truncLLR m κ e x ^ 2 - 2 * c * truncLLR m κ e x + c ^ 2 :=
      fun x => by ring
    simp_rw [hexp]
    have hA : Integrable (fun x => truncLLR m κ e x ^ 2 - 2 * c * truncLLR m κ e x) (betaSym m) :=
      hY2.sub ((hIntY e he).const_mul (2 * c))
    rw [integral_add hA (integrable_const _),
      integral_sub hY2 ((hIntY e he).const_mul (2 * c)), integral_const_mul, integral_const]
    have : ∫ x, truncLLR m κ e x ∂(betaSym m) = c := rfl
    rw [this]
    simp only [probReal_univ, smul_eq_mul, one_mul]
    nlinarith [hsq e he, sq_nonneg c]
  have hfreed := F2e2e.Prob.freedman_pi (fun _ : Fin k => betaSym m) D hDmeas hDdep hb0 hDup hDbdd
    (fun _ => 1.03 * I * h ^ 2) hDmean hDvar hz
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hfreed
  -- the boundary event
  have htail1 : ∀ i : Fin k, Measure.pi (fun _ : Fin k => betaSym m) {v | 1 - (v i) ^ 2 < κ} ≤
      ENNReal.ofReal (κ ^ (m + 1) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ))) := by
    intro i
    have hmeas : MeasurableSet {x : ℝ | 1 - x ^ 2 < κ} :=
      measurableSet_lt (by fun_prop) measurable_const
    have : {v : Fin k → ℝ | 1 - (v i) ^ 2 < κ} = Function.eval i ⁻¹' {x : ℝ | 1 - x ^ 2 < κ} := rfl
    rw [this, (measurePreserving_eval (fun _ : Fin k => betaSym m) i).measure_preimage
      hmeas.nullMeasurableSet]
    exact betaSym_tail_le m hκ0 hκ1
  have hA : Measure.pi (fun _ : Fin k => betaSym m) (⋃ i, {v : Fin k → ℝ | 1 - (v i) ^ 2 < κ}) ≤
      ENNReal.ofReal ((k : ℝ) * (κ ^ (m + 1) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ)))) := by
    refine (measure_iUnion_fintype_le _ _).trans ?_
    refine (Finset.sum_le_sum fun i _ => htail1 i).trans ?_
    rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
      ENNReal.ofReal_mul (Nat.cast_nonneg k), ENNReal.ofReal_natCast]
  -- on the good event the likelihood ratio is at most `e^ε`
  have hsub : {v : Fin k → ℝ | ENNReal.ofReal (Real.exp ε) * ∏ i, betaSymPDF m (v i - η i v) <
      ∏ i, betaSymPDF m (v i)} ⊆
      (⋃ i, {v : Fin k → ℝ | 1 - (v i) ^ 2 < κ}) ∪ {v | z ≤ ∑ i, D i v} := by
    intro v hv
    by_contra hcon
    simp only [Set.mem_union, Set.mem_iUnion, Set.mem_ofPred_eq, not_or, not_exists, not_lt] at hcon
    obtain ⟨hsafe, hM⟩ := hcon
    have hloc : ∀ i, truncLLR m κ (η i v) (v i) =
        Real.log (betaSymPDFReal m (v i) / betaSymPDFReal m (v i - η i v)) ∧
        0 < betaSymPDFReal m (v i) ∧ 0 < betaSymPDFReal m (v i - η i v) := fun i =>
      truncLLR_eq_log m hκ0 (hsafe i) (hηh i v) h2hκ
    have hfac : ∀ i, betaSymPDFReal m (v i) =
        Real.exp (Y i v) * betaSymPDFReal m (v i - η i v) := by
      intro i
      obtain ⟨h1, h2, h3⟩ := hloc i
      simp only [hYdef, h1]
      rw [Real.exp_log (div_pos h2 h3), div_mul_cancel₀ _ h3.ne']
    have hsumY : ∑ i, Y i v ≤ ε := by
      have e1 : ∑ i, Y i v = ∑ i, D i v + ∑ i, s1Drift m κ (η i v) := by
        rw [← Finset.sum_add_distrib]
        refine Finset.sum_congr rfl fun i _ => ?_
        simp only [hDdef]; ring
      have e2 : ∑ i, s1Drift m κ (η i v) ≤ (k : ℝ) * (0.67 * I * h ^ 2) := by
        calc ∑ i, s1Drift m κ (η i v) ≤ ∑ _i : Fin k, 0.67 * I * h ^ 2 :=
              Finset.sum_le_sum fun i _ => hgdrift _ (hηh i v)
          _ = (k : ℝ) * (0.67 * I * h ^ 2) := by simp
      have hdrift' : (k : ℝ) * (0.67 * I * h ^ 2) + z ≤ ε := by simpa [hIdef, mul_assoc] using hdrift
      linarith
    have hprod : ∏ i, betaSymPDFReal m (v i) =
        Real.exp (∑ i, Y i v) * ∏ i, betaSymPDFReal m (v i - η i v) := by
      rw [Real.exp_sum, ← Finset.prod_mul_distrib]
      exact Finset.prod_congr rfl fun i _ => hfac i
    have hle : ∏ i, betaSymPDF m (v i) ≤
        ENNReal.ofReal (Real.exp ε) * ∏ i, betaSymPDF m (v i - η i v) := by
      simp only [betaSymPDF]
      rw [← ENNReal.ofReal_prod_of_nonneg (fun i _ => betaSymPDFReal_nonneg m _),
        ← ENNReal.ofReal_prod_of_nonneg (fun i _ => betaSymPDFReal_nonneg m _),
        ← ENNReal.ofReal_mul (Real.exp_pos _).le, hprod]
      refine ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right (Real.exp_le_exp.2 hsumY)
        (Finset.prod_nonneg fun i _ => betaSymPDFReal_nonneg m _))
    exact absurd hv (not_lt.2 hle)
  calc Measure.pi (fun _ : Fin k => betaSym m)
        {v | ENNReal.ofReal (Real.exp ε) * ∏ i, betaSymPDF m (v i - η i v) < ∏ i, betaSymPDF m (v i)}
      ≤ Measure.pi (fun _ : Fin k => betaSym m)
          ((⋃ i, {v : Fin k → ℝ | 1 - (v i) ^ 2 < κ}) ∪ {v | z ≤ ∑ i, D i v}) := measure_mono hsub
    _ ≤ Measure.pi (fun _ : Fin k => betaSym m) (⋃ i, {v : Fin k → ℝ | 1 - (v i) ^ 2 < κ}) +
        Measure.pi (fun _ : Fin k => betaSym m) {v | z ≤ ∑ i, D i v} := measure_union_le _ _
    _ ≤ ENNReal.ofReal ((k : ℝ) * (κ ^ (m + 1) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ)))) +
        ENNReal.ofReal (Real.exp (-(z ^ 2 / (2 * ((k : ℝ) * (1.03 * I * h ^ 2) + b * z / 3))))) :=
        add_le_add hA hfreed
    _ = ENNReal.ofReal ((k : ℝ) * (κ ^ (m + 1) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ))) +
        Real.exp (-(z ^ 2 / (2 * ((k : ℝ) * (1.03 * I * h ^ 2) + b * z / 3))))) := by
        rw [ENNReal.ofReal_add (mul_nonneg (Nat.cast_nonneg _) (div_nonneg (pow_nonneg hκ0.le _)
          (mul_nonneg (mul_nonneg (by positivity) (betaSymZ_pos m).le) (Real.sqrt_nonneg _))))
          (Real.exp_pos _).le]
    _ ≤ ENNReal.ofReal δ := ENNReal.ofReal_le_ofReal htail

/-- **Stage-1 privacy, parametric form** (`I:lem:working_sample_privacy` (3), conclusion L787–795): the laws
of the adaptive releases `ã_i = θ_i(ã_{<i}) + R V_i` and `ã'_i = θ'_i(ã'_{<i}) + R V_i` (`V_i` i.i.d. `f_m`) are
`(ε, δ)`-indistinguishable when `|θ_i - θ'_i| ≤ R h` and the numeric hypotheses `S1NoiseParams` hold. -/
theorem releases_indist_of_params {k m : ℕ} {R h L ε δ z : ℝ} (hR : 0 < R)
    (hp : S1NoiseParams k m h L ε δ z) {θ θ' : Fin k → (Fin k → ℝ) → ℝ}
    (hθ : ∀ i, Measurable (θ i)) (hθ' : ∀ i, Measurable (θ' i))
    (hdep : ∀ i, DependsOn (θ i) (Set.Iio i)) (hdep' : ∀ i, DependsOn (θ' i) (Set.Iio i))
    (hsens : ∀ i a, |θ i a - θ' i a| ≤ R * h) {Φ Φ' : (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : ∀ v i, Φ v i = θ i (Φ v) + R * v i) (hΦ' : ∀ v i, Φ' v i = θ' i (Φ' v) + R * v i) :
    DP.Indist ((Measure.pi fun _ : Fin k => betaSym m).map Φ)
      ((Measure.pi fun _ : Fin k => betaSym m).map Φ') ε δ := by
  classical
  have hh0 : 0 < h := hp.h_pos
  -- the scaled noise `ξ = R V` and its law
  set sc : (Fin k → ℝ) → (Fin k → ℝ) := fun v i => R * v i with hsc
  have hscm : Measurable sc := by
    rw [hsc]; fun_prop
  set ρ : ℝ → ℝ≥0∞ := fun x => ENNReal.ofReal (betaSymScaledPDFReal R m x) with hρdef
  have hρm : Measurable ρ := (measurable_betaSymScaledPDFReal R m).ennreal_ofReal
  have hρfin : ∀ x, ρ x ≠ ∞ := fun x => ENNReal.ofReal_ne_top
  have hsf : ∀ _i : Fin k, SigmaFinite ((betaSym m).map fun v => R * v) := fun _ =>
    (inferInstance : SigmaFinite (betaSymScaled R m))
  have hPξ : (Measure.pi fun _ : Fin k => betaSym m).map sc =
      Measure.pi fun _ : Fin k => volume.withDensity ρ := by
    rw [hsc, Measure.pi_map_pi (fun _ => (measurable_const_mul R).aemeasurable)]
    congr 1
    funext i
    exact betaSymScaled_eq_withDensity hR m
  -- the releases as functions of the scaled noise
  have hdiv : ∀ ξ : Fin k → ℝ, sc (fun i => ξ i / R) = ξ := fun ξ => by
    funext i; simp only [hsc]; field_simp
  have hsol : ∀ {θ₀ : Fin k → (Fin k → ℝ) → ℝ} {Φ₀ : (Fin k → ℝ) → (Fin k → ℝ)},
      (∀ v i, Φ₀ v i = θ₀ i (Φ₀ v) + R * v i) →
      IsTriangularSol θ₀ (fun ξ => Φ₀ (fun i => ξ i / R)) := by
    intro θ₀ Φ₀ h ξ i
    show Φ₀ (fun i => ξ i / R) i = θ₀ i (Φ₀ (fun i => ξ i / R)) + ξ i
    rw [h]
    congr 1
    field_simp
  have hcomp : ∀ Φ₀ : (Fin k → ℝ) → (Fin k → ℝ), Φ₀ = (fun ξ => Φ₀ (fun i => ξ i / R)) ∘ sc := by
    intro Φ₀; funext v
    simp only [Function.comp_apply, hsc]
    congr 1; funext i; field_simp
  have hΦs := hsol hΦ
  have hΦs' := hsol hΦ'
  have hΦsm := hΦs.measurable hθ hdep
  have hΦsm' := hΦs'.measurable hθ' hdep'
  have hΦm : Measurable Φ := by rw [hcomp Φ]; exact hΦsm.comp hscm
  -- the densities of the two release laws
  set p : (Fin k → ℝ) → ℝ≥0∞ := fun a => ∏ i, ρ (a i - θ i a) with hpdef
  set q : (Fin k → ℝ) → ℝ≥0∞ := fun a => ∏ i, ρ (a i - θ' i a) with hqdef
  have hpm : Measurable p := Finset.measurable_prod _ fun i _ =>
    hρm.comp ((measurable_pi_apply i).sub (hθ i))
  have hqm : Measurable q := Finset.measurable_prod _ fun i _ =>
    hρm.comp ((measurable_pi_apply i).sub (hθ' i))
  have hlaw : (Measure.pi fun _ : Fin k => betaSym m).map Φ = volume.withDensity p := by
    rw [hcomp Φ, ← Measure.map_map hΦsm hscm, hPξ,
      map_triangularSol_pi_withDensity hρm hρfin hθ hdep hΦs]
  have hlaw' : (Measure.pi fun _ : Fin k => betaSym m).map Φ' = volume.withDensity q := by
    rw [hcomp Φ', ← Measure.map_map hΦsm' hscm, hPξ,
      map_triangularSol_pi_withDensity hρm hρfin hθ' hdep' hΦs']
  rw [hlaw, hlaw']
  refine DP.indist_of_two_densities hpm hqm ?_
  -- the privacy-loss tail, pulled back to the noise space
  have hA : MeasurableSet {a : Fin k → ℝ | ENNReal.ofReal (Real.exp ε) * q a < p a} :=
    measurableSet_lt (measurable_const.mul hqm) hpm
  rw [← hlaw, Measure.map_apply hΦm hA]
  -- the normalized shifts
  set η : Fin k → (Fin k → ℝ) → ℝ := fun i v => (θ' i (Φ v) - θ i (Φ v)) / R with hηdef
  have hηm : ∀ i, Measurable (η i) := fun i =>
    (((hθ' i).comp hΦm).sub ((hθ i).comp hΦm)).div_const R
  have hΦdep : ∀ j : Fin k, DependsOn (fun v => Φ v j) (Set.Iic j) := by
    intro j v w hvw
    have h1 := hΦs.dependsOn hdep j (x := sc v) (y := sc w) (fun l hl => by
      simp only [hsc, hvw l hl])
    have e1 : Φ v = (fun ξ => Φ (fun i => ξ i / R)) (sc v) := congrFun (hcomp Φ) v
    have e2 : Φ w = (fun ξ => Φ (fun i => ξ i / R)) (sc w) := congrFun (hcomp Φ) w
    simp only at h1 ⊢
    rw [e1, e2]
    exact h1
  have hηdep : ∀ i, DependsOn (η i) (Set.Iio i) := by
    intro i v w hvw
    have hpre : ∀ j ∈ Set.Iio i, Φ v j = Φ w j := fun j hj =>
      hΦdep j (fun l hl => hvw l (Set.mem_Iio.2 (lt_of_le_of_lt hl hj)))
    simp only [hηdef, hdep' i hpre, hdep i hpre]
  have hηh : ∀ i v, |η i v| ≤ h := by
    intro i v
    simp only [hηdef]
    rw [abs_div, abs_of_pos hR, div_le_iff₀ hR, abs_sub_comm, mul_comm]
    exact hsens i (Φ v)
  -- the pulled-back set is the noise-space bad set
  have hρR : ∀ x, ρ (R * x) = ENNReal.ofReal R⁻¹ * betaSymPDF m x := by
    intro x
    simp only [hρdef, betaSymScaledPDFReal, betaSymPDF]
    rw [ENNReal.ofReal_mul (inv_nonneg.2 hR.le)]
    congr 2
    field_simp
  have hcR : (ENNReal.ofReal R⁻¹) ^ k ≠ 0 := pow_ne_zero _ (ENNReal.ofReal_pos.2 (inv_pos.2 hR)).ne'
  have hcR' : (ENNReal.ofReal R⁻¹) ^ k ≠ ∞ := ENNReal.pow_ne_top ENNReal.ofReal_ne_top
  have hsub : Φ ⁻¹' {a | ENNReal.ofReal (Real.exp ε) * q a < p a} ⊆
      {v | ENNReal.ofReal (Real.exp ε) * ∏ i, betaSymPDF m (v i - η i v) < ∏ i, betaSymPDF m (v i)} := by
    intro v hv
    simp only [Set.mem_preimage, Set.mem_ofPred_eq] at hv ⊢
    have hpow : ∀ F : Fin k → ℝ≥0∞, (ENNReal.ofReal R⁻¹) ^ k * ∏ i, F i =
        ∏ i, (ENNReal.ofReal R⁻¹ * F i) := fun F => by
      rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    have hp' : p (Φ v) = (ENNReal.ofReal R⁻¹) ^ k * ∏ i, betaSymPDF m (v i) := by
      simp only [hpdef]
      rw [hpow]
      refine Finset.prod_congr rfl fun i _ => ?_
      rw [← hρR]
      congr 1
      rw [hΦ v i]; ring
    have hq' : q (Φ v) = (ENNReal.ofReal R⁻¹) ^ k * ∏ i, betaSymPDF m (v i - η i v) := by
      simp only [hqdef]
      rw [hpow]
      refine Finset.prod_congr rfl fun i _ => ?_
      rw [← hρR]
      congr 1
      simp only [hηdef]
      rw [hΦ v i]; field_simp; ring
    rw [hp', hq', mul_left_comm] at hv
    exact (ENNReal.mul_lt_mul_iff_right hcR hcR').1 hv
  exact (measure_mono hsub).trans (betaSym_pi_ratio_tail hp hηm hηdep hηh)

end F2e2e.A
