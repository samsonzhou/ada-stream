import F2e2e.A.Chain

/-!
# [SIM_r], mechanism part 1: stage `r` enters a round only through its test outcome and release value

Paper: Part I §3 (`parts/partI.tex` L803, L898: the cascade interacts with `S_r` "strictly through its public
AboveThreshold episodes and episode-ending scalar releases"); Prop. `I:prop:svt_episode_pure_dp` (L892-907).

For one round's `ChainData` and a validator stage `r`, `d.force r b v` overwrites the noises of stage `r` so that its
AboveThreshold test has outcome `b` and its release value `relV r` is `v`:
* (`force_toRec_self`) with the actual outcome `b = stageFires d r` and the actual release `v = d.relV r` the record
  is unchanged;
* (`force_toRec_congr`) the forced record does not depend on stage `r`'s fields (`θ_r`, `ρ_r`, `ν_r`, `ζ_r`) at all.
At the level of a round of the mechanism: `step = stepF r … (actual outcome) (actual release)`
(`step_eq_stepF`), and the record of `stepF` only depends on the other stages' data (`stepF_rec_congr`). The round
reads the noise table only at the round's coordinates (`roundChain_congr_noise`, `step_congr_mix`).
-/

namespace F2e2e

namespace A

open MeasureTheory

namespace ChainData

/-! ## Forcing stage `r` -/

/-- Force stage `r`'s AboveThreshold outcome to `b` and its release value `relV r` to `v` (the threshold noise of
stage `r` is set to `0`, its query noise to `τ_{(u,r)} - |c^{(u)} - θ_r| - [b = false]` at the actual origin
`(u, c^{(u)}) = orig r`, and its release noise to `v - θ_r`). -/
noncomputable def force (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) : ChainData where
  L := d.L
  tau := d.tau
  theta := d.theta
  c1 := d.c1
  rho := Function.update d.rho r 0
  nu := Function.update d.nu r
    (d.tau (d.orig r).1 r - |(d.orig r).2 - d.theta r| - (if b then 0 else 1))
  zeta := Function.update d.zeta r (v - d.theta r)

/-- Stage `r`'s AboveThreshold outcome at its actual origin. -/
noncomputable def stageFires (d : ChainData) (r : ℕ) : Bool := decide (d.Fires r (d.orig r).1 (d.orig r).2)

/-- `orig s` only depends on the stages `< s`, through their decisions at the actual origins and their releases. -/
theorem orig_congr_sim {d₁ d₂ : ChainData} (hL : d₁.L = d₂.L) (hc1 : d₁.c1 = d₂.c1) {s : ℕ}
    (h : ∀ t < s, (d₁.Fires t (d₁.orig t).1 (d₁.orig t).2 ↔ d₂.Fires t (d₁.orig t).1 (d₁.orig t).2) ∧
      d₁.relC t = d₂.relC t) : d₁.orig s = d₂.orig s := by
  induction s with
  | zero =>
    show (1, d₁.c1) = (1, d₂.c1)
    rw [hc1]
  | succ s ih =>
    have ih' := ih (fun t ht => h t (by omega))
    obtain ⟨hF, hR⟩ := h s (by omega)
    show (if 2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2 then (s, d₁.relC s)
        else d₁.orig s) =
      (if 2 ≤ s ∧ s ≤ d₂.L ∧ d₂.Fires s (d₂.orig s).1 (d₂.orig s).2 then (s, d₂.relC s)
        else d₂.orig s)
    have hcond : (2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2) ↔
        (2 ≤ s ∧ s ≤ d₂.L ∧ d₂.Fires s (d₂.orig s).1 (d₂.orig s).2) := by
      rw [hL, hF, ← ih']
    by_cases hc : 2 ≤ s ∧ s ≤ d₁.L ∧ d₁.Fires s (d₁.orig s).1 (d₁.orig s).2
    · rw [if_pos hc, if_pos (hcond.1 hc), hR]
    · rw [if_neg hc, if_neg (fun h' => hc (hcond.2 h')), ih']

theorem force_fires_of_ne (d : ChainData) {r t : ℕ} (b : Bool) (v : ℝ) (ht : t ≠ r) (u : ℕ) (c : ℝ) :
    (d.force r b v).Fires t u c ↔ d.Fires t u c := by
  simp only [Fires, force, Function.update_of_ne ht]

theorem force_relV_of_ne (d : ChainData) {r t : ℕ} (b : Bool) (v : ℝ) (ht : t ≠ r) :
    (d.force r b v).relV t = d.relV t := by
  simp only [relV, force, Function.update_of_ne ht]

theorem force_relV (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) : (d.force r b v).relV r = v := by
  simp only [relV, force, Function.update_self]
  ring

theorem force_relC (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) : (d.force r b v).relC r = clip01 v := by
  unfold relC
  rw [force_relV]

/-- Forcing stage `r` does not change the origins up to stage `r`. -/
theorem force_orig_of_le (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) {s : ℕ} (hs : s ≤ r) :
    (d.force r b v).orig s = d.orig s :=
  orig_congr_sim (d₁ := d.force r b v) (d₂ := d) (s := s) rfl rfl fun t ht =>
    ⟨force_fires_of_ne d b v (by omega) _ _, by
      unfold relC
      rw [force_relV_of_ne d b v (by omega)]⟩

/-- The forced outcome of stage `r`'s test (at its actual origin) is `b`. -/
theorem force_fires (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) :
    (d.force r b v).Fires r (d.orig r).1 (d.orig r).2 ↔ b = true := by
  show d.tau (d.orig r).1 r + Function.update d.rho r 0 r ≤
      |(d.orig r).2 - d.theta r| + Function.update d.nu r
        (d.tau (d.orig r).1 r - |(d.orig r).2 - d.theta r| - (if b then 0 else 1)) r ↔ b = true
  rw [Function.update_self, Function.update_self]
  cases b
  · have h1 : (if false = true then (0 : ℝ) else 1) = 1 := rfl
    rw [h1]
    constructor
    · intro h
      linarith
    · intro h
      exact absurd h (by decide)
  · have h0 : (if true = true then (0 : ℝ) else 1) = 0 := rfl
    rw [h0]
    constructor
    · intro _
      rfl
    · intro _
      linarith

theorem force_stageFires (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) :
    (d.force r b v).stageFires r = b := by
  unfold stageFires
  rw [force_orig_of_le d r b v le_rfl]
  cases b
  · exact decide_eq_false (by rw [force_fires]; simp)
  · exact decide_eq_true (by rw [force_fires])

theorem force_trig (d : ChainData) (r : ℕ) (b : Bool) (v : ℝ) :
    (d.force r b v).Trig r ↔ 2 ≤ r ∧ r ≤ d.L ∧ b = true := by
  unfold Trig
  rw [force_orig_of_le d r b v le_rfl]
  exact and_congr Iff.rfl (and_congr Iff.rfl (force_fires d r b v))

/-- The record of a round only depends on the `L`, `c₁`, the origins, the trigger pattern and the releases. -/
theorem toRec_congr_sim {d₁ d₂ : ChainData} (hL : d₁.L = d₂.L) (hc1 : d₁.c1 = d₂.c1)
    (horig : ∀ s, d₁.orig s = d₂.orig s) (htrig : ∀ s, d₁.Trig s ↔ d₂.Trig s)
    (hrel : ∀ s, d₁.relV s = d₂.relV s) (e1 e : ℝ) (eT : ℕ → ℝ) :
    d₁.toRec e1 e eT = d₂.toRec e1 e eT := by
  have huf : d₁.ufinal = d₂.ufinal := by
    unfold ufinal
    rw [horig, hL]
  have hans : d₁.answer = d₂.answer := by
    unfold answer
    rw [horig, hL]
  have hrelC : ∀ s, d₁.relC s = d₂.relC s := fun s => by
    unfold relC
    rw [hrel]
  have hrelsd : ∀ s, d₁.Released s ↔ d₂.Released s := fun s => by
    unfold Released
    rw [htrig, huf]
  have hcprev : ∀ s, d₁.cprev s = d₂.cprev s := fun s => by
    unfold cprev
    rw [horig]
  have hsgn : d₁.sgn = d₂.sgn := by
    unfold sgn
    rw [huf, hcprev, hans]
  have hdelta : ∀ m, d₁.delta e1 e eT m = d₂.delta e1 e eT m := fun m => by
    unfold delta
    rw [huf, hsgn]
  unfold toRec
  congr 1
  · funext s
    exact decide_eq_decide.mpr (htrig s)
  · funext s
    unfold uprev
    rw [horig]
  · funext s
    exact decide_eq_decide.mpr (hrelsd s)
  · funext s
    by_cases h : d₁.Released s
    · rw [if_pos h, if_pos ((hrelsd s).1 h), hrel]
    · rw [if_neg h, if_neg (fun h' => h ((hrelsd s).2 h'))]
  · funext s
    by_cases h1 : s = 1
    · rw [if_pos h1, if_pos h1, hc1]
    · rw [if_neg h1, if_neg h1]
      by_cases h : d₁.Released s
      · rw [if_pos h, if_pos ((hrelsd s).1 h), hrelC]
      · rw [if_neg h, if_neg (fun h' => h ((hrelsd s).2 h'))]
  · funext m
    exact hdelta m

/-- With the actual outcome and the actual release, forcing does not change the origins. -/
theorem force_orig_self (d : ChainData) (r : ℕ) (s : ℕ) :
    (d.force r (d.stageFires r) (d.relV r)).orig s = d.orig s := by
  refine orig_congr_sim (d₁ := d.force r (d.stageFires r) (d.relV r)) (d₂ := d) (s := s) rfl rfl
    fun t _ => ?_
  by_cases htr : t = r
  · rw [htr, force_orig_of_le d r _ _ le_rfl, force_fires, force_relC]
    exact ⟨decide_eq_true_iff, rfl⟩
  · exact ⟨force_fires_of_ne d _ _ htr _ _, by
      unfold relC
      rw [force_relV_of_ne d _ _ htr]⟩

/-- **Consistency.** With the actual outcome and the actual release value, the forced record is the record. -/
theorem force_toRec_self (d : ChainData) (r : ℕ) (e1 e : ℝ) (eT : ℕ → ℝ) :
    (d.force r (d.stageFires r) (d.relV r)).toRec e1 e eT = d.toRec e1 e eT := by
  refine toRec_congr_sim (d₁ := d.force r (d.stageFires r) (d.relV r)) (d₂ := d) rfl rfl
    (force_orig_self d r) (fun s => ?_) (fun s => ?_) e1 e eT
  · by_cases hs : s = r
    · rw [hs, force_trig]
      unfold Trig
      exact and_congr Iff.rfl (and_congr Iff.rfl decide_eq_true_iff)
    · unfold Trig
      refine and_congr Iff.rfl (and_congr Iff.rfl ?_)
      rw [force_orig_self]
      exact force_fires_of_ne d _ _ hs _ _
  · by_cases hs : s = r
    · rw [hs, force_relV]
    · rw [force_relV_of_ne d _ _ hs]

/-- **Independence.** The forced record does not depend on stage `r`'s fields: if `d₁, d₂` agree on `L`, `τ`, `c₁`
and on the fields of every stage `t ≠ r`, the forced records agree. -/
theorem force_toRec_congr {d₁ d₂ : ChainData} (r : ℕ) (b : Bool) (v : ℝ) (hL : d₁.L = d₂.L)
    (htau : d₁.tau = d₂.tau) (hc1 : d₁.c1 = d₂.c1)
    (htheta : ∀ t, t ≠ r → d₁.theta t = d₂.theta t) (hrho : ∀ t, t ≠ r → d₁.rho t = d₂.rho t)
    (hnu : ∀ t, t ≠ r → d₁.nu t = d₂.nu t) (hzeta : ∀ t, t ≠ r → d₁.zeta t = d₂.zeta t)
    (e1 e : ℝ) (eT : ℕ → ℝ) :
    (d₁.force r b v).toRec e1 e eT = (d₂.force r b v).toRec e1 e eT := by
  -- the fields of the two chains agree away from `r`
  have hF : ∀ t, t ≠ r → ∀ u c, d₁.Fires t u c ↔ d₂.Fires t u c := fun t ht u c => by
    unfold Fires
    rw [htau, htheta t ht, hrho t ht, hnu t ht]
  have hRv : ∀ t, t ≠ r → d₁.relV t = d₂.relV t := fun t ht => by
    unfold relV
    rw [htheta t ht, hzeta t ht]
  -- the origins of the two chains agree up to `r`
  have hor : d₁.orig r = d₂.orig r := orig_congr_sim (s := r) hL hc1 fun t ht =>
    ⟨hF t (by omega) _ _, by unfold relC; rw [hRv t (by omega)]⟩
  -- the origins of the two forced chains agree everywhere
  have horig : ∀ s, (d₁.force r b v).orig s = (d₂.force r b v).orig s := fun s => by
    refine orig_congr_sim (d₁ := d₁.force r b v) (d₂ := d₂.force r b v) (s := s) hL hc1 fun t _ => ?_
    by_cases htr : t = r
    · rw [htr, force_orig_of_le d₁ r b v le_rfl, force_fires, hor, force_fires, force_relC,
        force_relC]
      exact ⟨Iff.rfl, rfl⟩
    · refine ⟨?_, ?_⟩
      · rw [force_fires_of_ne d₁ b v htr, force_fires_of_ne d₂ b v htr]
        exact hF t htr _ _
      · unfold relC
        rw [force_relV_of_ne d₁ b v htr, force_relV_of_ne d₂ b v htr, hRv t htr]
  refine toRec_congr_sim (d₁ := d₁.force r b v) (d₂ := d₂.force r b v) hL hc1 horig (fun s => ?_)
    (fun s => ?_) e1 e eT
  · by_cases hs : s = r
    · rw [hs, force_trig, force_trig, hL]
    · unfold Trig
      refine and_congr Iff.rfl (and_congr (show s ≤ d₁.L ↔ s ≤ d₂.L by rw [hL]) ?_)
      rw [horig, force_fires_of_ne d₁ b v hs, force_fires_of_ne d₂ b v hs]
      exact hF s hs _ _
  · by_cases hs : s = r
    · rw [hs, force_relV, force_relV]
    · rw [force_relV_of_ne d₁ b v hs, force_relV_of_ne d₂ b v hs, hRv s hs]

end ChainData

/-! ## Rounds with stage `r` forced -/

variable {k : ℕ} {α β : ℝ}

/-- One round of the mechanism with stage `r`'s AboveThreshold outcome forced to `b` and its release value to
`v` (a halted round is unchanged). -/
noncomputable def stepF (r : ℕ) (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (b : Bool) (v : ℝ) : MState k α β × RoundRec :=
  if st.halt then (st, RoundRec.halted)
  else (st.next q (((roundChain st i q ω).force r b v).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)),
    ((roundChain st i q ω).force r b v).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α))

/-- **Consistency** of the forced round with the actual outcome and release. -/
theorem step_eq_stepF (r : ℕ) (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) :
    step st i q ω = stepF r st i q ω ((roundChain st i q ω).stageFires r)
      ((roundChain st i q ω).relV r) := by
  unfold step stepF activeRec
  rw [ChainData.force_toRec_self]

/-- **Independence** of the forced round record from stage `r`'s data: it only depends on HALT and on the chain
data of the stages `t ≠ r` (and on `c₁`). -/
theorem stepF_rec_congr (r : ℕ) {st₁ st₂ : MState k α β} (i : ℕ) {q₁ q₂ : Fin (adaSampleSize k α β) → ℝ}
    {ω₁ ω₂ : AdaOmega k α} (b : Bool) (v : ℝ) (hhalt : st₁.halt = st₂.halt)
    (hc1 : (roundChain st₁ i q₁ ω₁).c1 = (roundChain st₂ i q₂ ω₂).c1)
    (htheta : ∀ t, t ≠ r → (roundChain st₁ i q₁ ω₁).theta t = (roundChain st₂ i q₂ ω₂).theta t)
    (hrho : ∀ t, t ≠ r → (roundChain st₁ i q₁ ω₁).rho t = (roundChain st₂ i q₂ ω₂).rho t)
    (hnu : ∀ t, t ≠ r → (roundChain st₁ i q₁ ω₁).nu t = (roundChain st₂ i q₂ ω₂).nu t)
    (hzeta : ∀ t, t ≠ r → (roundChain st₁ i q₁ ω₁).zeta t = (roundChain st₂ i q₂ ω₂).zeta t) :
    (stepF r st₁ i q₁ ω₁ b v).2 = (stepF r st₂ i q₂ ω₂ b v).2 := by
  unfold stepF
  rw [hhalt]
  split_ifs
  · rfl
  · exact ChainData.force_toRec_congr (d₁ := roundChain st₁ i q₁ ω₁) (d₂ := roundChain st₂ i q₂ ω₂)
      r b v rfl rfl hc1 htheta hrho hnu hzeta _ _ _

/-! ## Which noise coordinates a round reads -/

/-- A round reads the noise table only at the Beta draw of the round, the `ν, ζ` of the round and the current
`ρ` of every stage. -/
theorem roundChain_congr_noise (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    {ω₁ ω₂ : AdaOmega k α} (hb : noiseBeta ω₁ i = noiseBeta ω₂ i)
    (hnu : ∀ s, noiseNu ω₁ i s = noiseNu ω₂ i s) (hzeta : ∀ s, noiseZeta ω₁ i s = noiseZeta ω₂ i s)
    (hrho : ∀ s, noiseRho ω₁ s (st.M s - 1) = noiseRho ω₂ s (st.M s - 1)) :
    roundChain st i q ω₁ = roundChain st i q ω₂ := by
  unfold roundChain stage1Release
  rw [hb]
  congr 1
  · funext s
    exact hrho s
  · funext s
    exact hnu s
  · funext s
    exact hzeta s

theorem noiseNu_mixNoise (r : ℕ) (ω ω' : AdaOmega k α) (i s : ℕ) :
    noiseNu (mixNoise r ω ω') i s = if s = r then noiseNu ω i s else noiseNu ω' i s := by
  unfold noiseNu
  split_ifs with h1 h2 <;> simp_all [mixNoise, NoiseIdx.stage]

theorem noiseZeta_mixNoise (r : ℕ) (ω ω' : AdaOmega k α) (i s : ℕ) :
    noiseZeta (mixNoise r ω ω') i s = if s = r then noiseZeta ω i s else noiseZeta ω' i s := by
  unfold noiseZeta
  split_ifs with h1 h2 <;> simp_all [mixNoise, NoiseIdx.stage]

theorem noiseRho_mixNoise (r : ℕ) (ω ω' : AdaOmega k α) (s e : ℕ) :
    noiseRho (mixNoise r ω ω') s e = if s = r then noiseRho ω s e else noiseRho ω' s e := by
  unfold noiseRho
  split_ifs with h1 h2 <;> simp_all [mixNoise, NoiseIdx.stage]

theorem noiseBeta_mixNoise {r : ℕ} (hr : r ≠ 1) (ω ω' : AdaOmega k α) (i : ℕ) :
    noiseBeta (mixNoise r ω ω') i = noiseBeta ω' i := by
  unfold noiseBeta
  split_ifs with h1
  · simp [mixNoise, NoiseIdx.stage, Ne.symm hr]
  · rfl

/-- With the noise not owned by stage `r ≥ 2` fixed, a round reads stage `r`'s noise only at `ν_i^{(r)}`,
`ζ_i^{(r)}` and the current `ρ^{(r)}`. -/
theorem roundChain_congr_mix {r : ℕ} (hr : 2 ≤ r) (st : MState k α β) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω' : AdaOmega k α) {ω₁ ω₂ : AdaOmega k α}
    (hnu : noiseNu ω₁ i r = noiseNu ω₂ i r) (hzeta : noiseZeta ω₁ i r = noiseZeta ω₂ i r)
    (hrho : noiseRho ω₁ r (st.M r - 1) = noiseRho ω₂ r (st.M r - 1)) :
    roundChain st i q (mixNoise r ω₁ ω') = roundChain st i q (mixNoise r ω₂ ω') := by
  refine roundChain_congr_noise st i q ?_ (fun s => ?_) (fun s => ?_) (fun s => ?_)
  · rw [noiseBeta_mixNoise (by omega), noiseBeta_mixNoise (by omega)]
  · rw [noiseNu_mixNoise, noiseNu_mixNoise]
    split_ifs with h
    · rw [h]; exact hnu
    · rfl
  · rw [noiseZeta_mixNoise, noiseZeta_mixNoise]
    split_ifs with h
    · rw [h]; exact hzeta
    · rfl
  · rw [noiseRho_mixNoise, noiseRho_mixNoise]
    split_ifs with h
    · rw [h]; exact hrho
    · rfl

theorem step_congr_mix {r : ℕ} (hr : 2 ≤ r) (st : MState k α β) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω' : AdaOmega k α) {ω₁ ω₂ : AdaOmega k α}
    (hnu : noiseNu ω₁ i r = noiseNu ω₂ i r) (hzeta : noiseZeta ω₁ i r = noiseZeta ω₂ i r)
    (hrho : noiseRho ω₁ r (st.M r - 1) = noiseRho ω₂ r (st.M r - 1)) :
    step st i q (mixNoise r ω₁ ω') = step st i q (mixNoise r ω₂ ω') := by
  unfold step activeRec
  rw [roundChain_congr_mix hr st i q ω' hnu hzeta hrho]

end A

end F2e2e
