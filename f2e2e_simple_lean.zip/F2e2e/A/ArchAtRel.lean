import F2e2e.A.ArchMeasurable
import F2e2e.Lib.DP.AboveThreshold
import F2e2e.Lib.DP.Laplace
import F2e2e.Lib.DP.Compose
import F2e2e.A.NumericsBasic

/-!
# The AboveThreshold + Laplace core of a validator episode (Prop. `I:prop:svt_episode_pure_dp`, Step 1-2)

Paper: `parts/partI.tex` L887-957 (Prop. `I:prop:svt_episode_pure_dp`): one episode of stage `r` is an
AboveThreshold run (threshold noise `ρ^{(r)}_e ∼ Lap(b_SVT)`, query noises `ν_i^{(r)} ∼ Lap(2 b_SVT)`) followed by
one Laplace release `θ + ζ_i^{(r)}` (`ζ ∼ Lap(b_SVT)`) at the end round; for `Δ`-sensitive inputs this is
`(2Δ/b + Δ/b, 0) = (3Δ/b, 0)`-indistinguishable (AboveThreshold T3 + Laplace mechanism + pure composition T4).

`atRel k α r e s K f T θ ω` is the episode core on the mechanism's noise table `ω`: the AboveThreshold output
`m = DP.atOutput f T (ρ^{(r)}_e, (ν_{s+j}^{(r)})_{j<K})` (index of the first trigger among the tests `j < T`, or `T`)
and the release `θ(end) + ζ_{s+end}^{(r)}` at the end index `end = atEnd T m` (`m` if `m < T`, else `T - 1`).

Statements fixed by A-VAL (914e80f8) for `svt_episode_pure_dp` (F2e2e/A/Validators.lean, via
F2e2e/A/SimEpisode.lean).

## Proof of `atRel_indist`
The coordinates `ρ^{(r)}_e`, `ν_{s+j}^{(r)}`, `ζ_{s+j}^{(r)}` (`j < K`) of the noise table are distinct
(`epCoord_injective`), so the law of `ω ↦ ((ρ, ν), ζ)` under `adaNoiseMeasure` is `DP.atNoise b K ⊗ Lap(b)^K`
(`map_epNoise`, via `map_pi_comp_injective`); hence the law of `atRel` is
`DP.atLaw b f T ⊗ₘ (m ↦ DP.lapMech b (θ (atEnd T m)))` (`map_atRel`), and `DP.Indist.compProd_pure` with
`DP.atLaw_indist` (`2Δ/b`) and `DP.lapMech_indist` (`Δ/b`) gives `3Δ/b`.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

noncomputable section

/-- The AboveThreshold noise of episode `e` of stage `r` whose tests start at round `s` (horizon `K`): the threshold
noise `ρ^{(r)}_e` and the query noises `ν_{s+j}^{(r)}`, `j < K`. -/
def atNoiseOf (k : ℕ) (α : ℝ) (r e s K : ℕ) (ω : AdaOmega k α) : DP.ATNoise K :=
  (noiseRho ω r e, fun j : Fin K => noiseNu ω (s + j) r)

/-- The end index of an episode with AboveThreshold output `m` and horizon `T`: the trigger index `m` if `m < T`,
else the last test `T - 1`. -/
def atEnd (T m : ℕ) : ℕ := if m < T then m else T - 1

/-- **The episode core**: the AboveThreshold output and the Laplace release at the end index. -/
def atRel (k : ℕ) (α : ℝ) (r e s K : ℕ) (f : Fin K → ℝ) (T : ℕ) (θ : ℕ → ℝ)
    (ω : AdaOmega k α) : ℕ × ℝ :=
  (DP.atOutput f T (atNoiseOf k α r e s K ω),
   θ (atEnd T (DP.atOutput f T (atNoiseOf k α r e s K ω))) +
     noiseZeta ω (s + atEnd T (DP.atOutput f T (atNoiseOf k α r e s K ω))) r)

end

theorem atEnd_lt {T K : ℕ} (hK : 0 < K) (hT : T ≤ K) (m : ℕ) : atEnd T m < K := by
  unfold atEnd
  split_ifs <;> omega

theorem measurable_atNoiseOf (k : ℕ) (α : ℝ) (r e s K : ℕ) : Measurable (atNoiseOf k α r e s K) :=
  (measurable_noiseRho r e).prodMk (measurable_pi_lambda _ fun j => measurable_noiseNu (s + j) r)

theorem measurable_atRel (k : ℕ) (α : ℝ) (r e s K : ℕ) (f : Fin K → ℝ) (T : ℕ) (θ : ℕ → ℝ) :
    Measurable (atRel k α r e s K f T θ) := by
  have hm : Measurable fun ω : AdaOmega k α => DP.atOutput f T (atNoiseOf k α r e s K ω) :=
    (DP.measurable_atOutput f T).comp (measurable_atNoiseOf k α r e s K)
  refine hm.prodMk ?_
  exact measurable_nat_index (g := fun n (ω : AdaOmega k α) => θ (atEnd T n) + noiseZeta ω (s + atEnd T n) r)
    (fun n => measurable_const.add (measurable_noiseZeta _ _)) hm

/-! ## Selecting coordinates of a product measure -/

/-- Precomposition with an injective index map pushes a finite product of probability measures to the product of
the selected factors. -/
theorem map_pi_comp_injective {ι κ : Type*} [Fintype ι] [Fintype κ] {E : Type*} [MeasurableSpace E]
    (μ : ι → Measure E) [∀ i, IsProbabilityMeasure (μ i)] (g : κ → ι) (hg : Function.Injective g) :
    (Measure.pi μ).map (fun ω : ι → E => fun j => ω (g j)) = Measure.pi (fun j => μ (g j)) := by
  classical
  have hmeas : Measurable (fun ω : ι → E => fun j => ω (g j)) :=
    measurable_pi_lambda _ fun j => measurable_pi_apply (g j)
  symm
  apply Measure.pi_eq
  intro s hs
  rw [Measure.map_apply hmeas (MeasurableSet.univ_pi hs)]
  set t : ι → Set E := fun i => if h : ∃ j, g j = i then s h.choose else Set.univ with ht
  have htg : ∀ j, t (g j) = s j := by
    intro j
    have hex : ∃ j', g j' = g j := ⟨j, rfl⟩
    have hc : hex.choose = j := hg hex.choose_spec
    simp only [ht]
    rw [dif_pos hex, hc]
  have htn : ∀ i, (¬ ∃ j, g j = i) → t i = Set.univ := by
    intro i hi
    simp only [ht]
    rw [dif_neg hi]
  have hset : (fun ω : ι → E => fun j => ω (g j)) ⁻¹' Set.univ.pi s = Set.univ.pi t := by
    ext ω
    simp only [Set.mem_preimage, Set.mem_univ_pi]
    constructor
    · intro h i
      by_cases hi : ∃ j, g j = i
      · obtain ⟨j, rfl⟩ := hi
        rw [htg]
        exact h j
      · rw [htn i hi]
        exact Set.mem_univ _
    · intro h j
      have := h (g j)
      rwa [htg] at this
  rw [hset, Measure.pi_pi]
  have hsub := Finset.prod_subset (Finset.subset_univ (Finset.univ.image g))
    (f := fun i => μ i (t i)) (fun i _ hi => by
      have hi' : ¬ ∃ j, g j = i := by
        rintro ⟨j, rfl⟩
        exact hi (Finset.mem_image_of_mem g (Finset.mem_univ j))
      simp only [htn i hi', measure_univ])
  rw [← hsub, Finset.prod_image (fun x _ y _ hxy => hg hxy)]
  exact Finset.prod_congr rfl fun j _ => by rw [htg]

/-! ## The noise coordinates of one episode -/

/-- The noise coordinates of one episode: `inl (inl ())` ↦ `ρ^{(r)}_e`, `inl (inr j)` ↦ `ν_{s+j}^{(r)}`,
`inr j` ↦ `ζ_{s+j}^{(r)}` (`j < K`). -/
def epCoord (k L r e s K : ℕ) (hr : r < L + 1) (he : e < k + 1) (hsK : s + K ≤ k) :
    (Unit ⊕ Fin K) ⊕ Fin K → NoiseIdx k L
  | .inl (.inl _) => .rho ⟨r, hr⟩ ⟨e, he⟩
  | .inl (.inr j) => .nu ⟨s + j, by have := j.isLt; omega⟩ ⟨r, hr⟩
  | .inr j => .zeta ⟨s + j, by have := j.isLt; omega⟩ ⟨r, hr⟩

theorem epCoord_injective (k L r e s K : ℕ) (hr : r < L + 1) (he : e < k + 1) (hsK : s + K ≤ k) :
    Function.Injective (epCoord k L r e s K hr he hsK) := by
  intro a b h
  rcases a with (u | j) | j <;> rcases b with (u' | j') | j' <;>
    simp [epCoord, Fin.ext_iff] at h ⊢ <;> omega

/-- **The law of the episode noise** `ω ↦ ((ρ^{(r)}_e, (ν_{s+j}^{(r)})_j), (ζ_{s+j}^{(r)})_j)`: the AboveThreshold
noise law times i.i.d. `Lap(b_SVT)` release noises. -/
theorem map_epNoise {k : ℕ} {α β : ℝ} {r e s K : ℕ} (hr : r ≤ adaL α) (he : e ≤ k) (hsK : s + K ≤ k) :
    (adaNoiseMeasure k α β).map (fun ω : AdaOmega k α =>
        (atNoiseOf k α r e s K ω, fun j : Fin K => noiseZeta ω (s + j) r)) =
      (DP.atNoise (adaBsvt k α β) K).prod (Measure.pi fun _ : Fin K => laplace (adaBsvt k α β)) := by
  have hr' : r < adaL α + 1 := by omega
  have he' : e < k + 1 := by omega
  set g := epCoord k (adaL α) r e s K hr' he' hsK with hg
  have hginj : Function.Injective g := epCoord_injective k (adaL α) r e s K hr' he' hsK
  have hR : MeasurePreserving (fun ω : AdaOmega k α => fun j => ω (g j)) (adaNoiseMeasure k α β)
      (Measure.pi fun j => noiseLaw k α β (g j)) :=
    ⟨measurable_pi_lambda _ fun j => measurable_pi_apply (g j), map_pi_comp_injective _ g hginj⟩
  have h1 := measurePreserving_sumPiEquivProdPi (fun j => noiseLaw k α β (g j))
  have h2 := measurePreserving_sumPiEquivProdPi (fun i : Unit ⊕ Fin K => noiseLaw k α β (g (.inl i)))
  have h3 : MeasurePreserving (MeasurableEquiv.funUnique Unit ℝ)
      (Measure.pi fun u : Unit => noiseLaw k α β (g (.inl (.inl u)))) (laplace (adaBsvt k α β)) :=
    measurePreserving_funUnique (laplace (adaBsvt k α β)) Unit
  have h4 := (h3.prod (MeasurePreserving.id
    (Measure.pi fun j : Fin K => noiseLaw k α β (g (.inl (.inr j)))))).comp h2
  have h5 := (h4.prod (MeasurePreserving.id
    (Measure.pi fun j : Fin K => noiseLaw k α β (g (.inr j))))).comp h1
  have h6 := h5.comp hR
  have hρ : ∀ ω : AdaOmega k α, noiseRho ω r e = ω (g (.inl (.inl ()))) := by
    intro ω
    simp only [noiseRho, dif_pos (show r < adaL α + 1 ∧ e < k + 1 from ⟨hr', he'⟩), hg, epCoord]
  have hν : ∀ (ω : AdaOmega k α) (j : Fin K), noiseNu ω (s + j) r = ω (g (.inl (.inr j))) := by
    intro ω j
    have hj : s + (j : ℕ) < k ∧ r < adaL α + 1 := ⟨by have := j.isLt; omega, hr'⟩
    simp only [noiseNu, dif_pos hj, hg, epCoord]
  have hζ : ∀ (ω : AdaOmega k α) (j : Fin K), noiseZeta ω (s + j) r = ω (g (.inr j)) := by
    intro ω j
    have hj : s + (j : ℕ) < k ∧ r < adaL α + 1 := ⟨by have := j.isLt; omega, hr'⟩
    simp only [noiseZeta, dif_pos hj, hg, epCoord]
  have hfun : (fun ω : AdaOmega k α => (atNoiseOf k α r e s K ω, fun j : Fin K => noiseZeta ω (s + j) r)) =
      ((Prod.map (Prod.map (MeasurableEquiv.funUnique Unit ℝ) id ∘
          (MeasurableEquiv.sumPiEquivProdPi fun _ : Unit ⊕ Fin K => ℝ)) id) ∘
        (MeasurableEquiv.sumPiEquivProdPi fun _ : (Unit ⊕ Fin K) ⊕ Fin K => ℝ)) ∘
        (fun ω : AdaOmega k α => fun j => ω (g j)) := by
    funext ω
    simp only [atNoiseOf, hρ, hν, hζ]
    rfl
  rw [hfun, h6.map_eq]
  rfl

/-! ## The law of the episode core -/

/-- The release kernel: `m ↦ law(θ(atEnd T m) + Lap(b))`. -/
noncomputable def relKernel (b : ℝ) (T : ℕ) (θ : ℕ → ℝ) : Kernel ℕ ℝ :=
  (DP.lapKernel b).comap (fun m => θ (atEnd T m)) measurable_from_nat

theorem relKernel_apply (b : ℝ) (T : ℕ) (θ : ℕ → ℝ) (m : ℕ) :
    relKernel b T θ m = DP.lapMech b (θ (atEnd T m)) := rfl

instance isMarkovKernel_relKernel (b : ℝ) (T : ℕ) (θ : ℕ → ℝ) : IsMarkovKernel (relKernel b T θ) := by
  unfold relKernel
  infer_instance

/-- The episode core as a function of the episode noise `((ρ, ν), ζ)`. -/
noncomputable def atRelG (K : ℕ) (f : Fin K → ℝ) (T : ℕ) (θ : ℕ → ℝ) (p : DP.ATNoise K × (Fin K → ℝ)) :
    ℕ × ℝ :=
  (DP.atOutput f T p.1, θ (atEnd T (DP.atOutput f T p.1)) +
    if h : atEnd T (DP.atOutput f T p.1) < K then p.2 ⟨atEnd T (DP.atOutput f T p.1), h⟩ else 0)

theorem measurable_atRelG (K : ℕ) (f : Fin K → ℝ) (T : ℕ) (θ : ℕ → ℝ) : Measurable (atRelG K f T θ) := by
  have hm : Measurable fun p : DP.ATNoise K × (Fin K → ℝ) => DP.atOutput f T p.1 :=
    (DP.measurable_atOutput f T).comp measurable_fst
  refine hm.prodMk ?_
  refine measurable_nat_index (g := fun n (p : DP.ATNoise K × (Fin K → ℝ)) => θ (atEnd T n) +
    if h : atEnd T n < K then p.2 ⟨atEnd T n, h⟩ else 0) (fun n => ?_) hm
  refine measurable_const.add ?_
  by_cases h : atEnd T n < K
  · simp only [dif_pos h]
    exact (measurable_pi_apply _).comp measurable_snd
  · simp only [dif_neg h]
    exact measurable_const

theorem map_atRelG {b : ℝ} {K T : ℕ} (hK : 0 < K) (hT : T ≤ K) (f : Fin K → ℝ) (θ : ℕ → ℝ) :
    ((DP.atNoise b K).prod (Measure.pi fun _ : Fin K => laplace b)).map (atRelG K f T θ) =
      DP.atLaw b f T ⊗ₘ relKernel b T θ := by
  ext E hE
  rw [Measure.map_apply (measurable_atRelG K f T θ) hE,
    Measure.prod_apply (measurable_atRelG K f T θ hE), Measure.compProd_apply hE, DP.atLaw,
    lintegral_map (Kernel.measurable_kernel_prodMk_left hE) (DP.measurable_atOutput f T)]
  refine lintegral_congr fun a => ?_
  have hend := atEnd_lt hK hT (DP.atOutput f T a)
  rw [relKernel_apply, DP.lapMech,
    Measure.map_apply (measurable_const_add _) (measurable_prodMk_left hE)]
  have hpre : Prod.mk a ⁻¹' (atRelG K f T θ ⁻¹' E) =
      Function.eval (⟨atEnd T (DP.atOutput f T a), hend⟩ : Fin K) ⁻¹'
        ((fun z => θ (atEnd T (DP.atOutput f T a)) + z) ⁻¹' (Prod.mk (DP.atOutput f T a) ⁻¹' E)) := by
    ext z
    simp only [Set.mem_preimage, atRelG, dif_pos hend, Function.eval]
  rw [hpre, (measurePreserving_eval (μ := fun _ : Fin K => laplace b)
    (⟨atEnd T (DP.atOutput f T a), hend⟩ : Fin K)).measure_preimage
    ((measurable_const_add _) (measurable_prodMk_left hE)).nullMeasurableSet]

/-- **The law of the episode core**: `DP.atLaw b f T ⊗ₘ (m ↦ θ(atEnd T m) + Lap(b))`. -/
theorem map_atRel {k : ℕ} {α β : ℝ} {r e s K T : ℕ} (hr : r ≤ adaL α) (he : e ≤ k) (hsK : s + K ≤ k)
    (hK : 0 < K) (hT : T ≤ K) (f : Fin K → ℝ) (θ : ℕ → ℝ) :
    (adaNoiseMeasure k α β).map (atRel k α r e s K f T θ) =
      DP.atLaw (adaBsvt k α β) f T ⊗ₘ relKernel (adaBsvt k α β) T θ := by
  have hfun : atRel k α r e s K f T θ = atRelG K f T θ ∘
      (fun ω : AdaOmega k α => (atNoiseOf k α r e s K ω, fun j : Fin K => noiseZeta ω (s + j) r)) := by
    funext ω
    have hend := atEnd_lt hK hT (DP.atOutput f T (atNoiseOf k α r e s K ω))
    simp only [atRel, atRelG, Function.comp, dif_pos hend]
  have hΦ : Measurable (fun ω : AdaOmega k α =>
      (atNoiseOf k α r e s K ω, fun j : Fin K => noiseZeta ω (s + j) r)) :=
    (measurable_atNoiseOf k α r e s K).prodMk
      (measurable_pi_lambda _ fun j => measurable_noiseZeta (s + j) r)
  rw [hfun, ← Measure.map_map (measurable_atRelG K f T θ) hΦ, map_epNoise hr he hsK,
    map_atRelG hK hT f θ]

/-- **Pure DP of the episode core** (AboveThreshold `2Δ/b` + Laplace release `Δ/b`, pure composition). -/
theorem atRel_indist {k : ℕ} {α β : ℝ} (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) {r e s K T : ℕ} (hr : r ≤ adaL α) (he : e ≤ k) (hsK : s + K ≤ k) (hK : 0 < K)
    (hT : T ≤ K) {f f' : Fin K → ℝ} {θ θ' : ℕ → ℝ} {Δ : ℝ} (hΔ : 0 ≤ Δ) (hf : ∀ j, |f j - f' j| ≤ Δ)
    (hθ : ∀ j, |θ j - θ' j| ≤ Δ) :
    DP.Indist ((adaNoiseMeasure k α β).map (atRel k α r e s K f T θ))
      ((adaNoiseMeasure k α β).map (atRel k α r e s K f' T θ')) (3 * Δ / adaBsvt k α β) 0 := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  rw [map_atRel hr he hsK hK hT f θ, map_atRel hr he hsK hK hT f' θ']
  have : IsProbabilityMeasure (DP.atLaw (adaBsvt k α β) f T) :=
    Measure.isProbabilityMeasure_map (DP.measurable_atOutput f T).aemeasurable
  have : IsProbabilityMeasure (DP.atLaw (adaBsvt k α β) f' T) :=
    Measure.isProbabilityMeasure_map (DP.measurable_atOutput f' T).aemeasurable
  have h := DP.Indist.compProd_pure (κ := relKernel (adaBsvt k α β) T θ)
    (κ' := relKernel (adaBsvt k α β) T θ') (DP.atLaw_indist hb hΔ f f' hf T)
    (fun m => by
      rw [relKernel_apply, relKernel_apply]
      exact DP.lapMech_indist hb (hθ (atEnd T m)))
  rwa [show 2 * Δ / adaBsvt k α β + Δ / adaBsvt k α β = 3 * Δ / adaBsvt k α β by ring] at h

end A

end F2e2e
