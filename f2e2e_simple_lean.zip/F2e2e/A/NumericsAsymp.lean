import F2e2e.A.NumericsCaps

/-!
# Part I numerics: the explicit bound is `O(adaAsymp)`

Theorem I.1.1, `I:eq:main_explicit_bound` ⟹ `I:eq:main_sample_complexity` (`parts/partI.tex` L21-34 and the
substitutions of L2127-2131, L2153-2156): for `k ≥ 1`, `0 < α < 1/16`, `0 < β < 1/2`,
`adaExplicitBound k α β ≤ 10¹² · adaAsymp k α β`.

Notation: `ℓ = ln(1/α)`, `Λ₀ = ln(1/(αβ))`, `K = ln(k ℓ/(αβ))`, `V = ln(ℓ/(αβ))`.
Certificates (all elementary):
* `L ≤ 3ℓ` (`L < ℓ + 3`, `ℓ > 2.77`), so `L^{7/2} = L³√L ≤ 54 ℓ³√ℓ`;
* `L₁ = ln(20480/(αβ)) ≤ 4Λ₀` (`20480 < 32³`), so `χ₁ ≤ 4χ` in both branches and `L₁³ ≤ 64Λ₀³`;
* `Λ_SVT = ln(64 L k M_{2,max}/δ_val) ≤ 20 K`: with `M_{2,max} ≤ 30L³/α²` and
  `δ_val = α³β/(256³·10⁸L⁶)`, `64LkM_{2,max}/δ_val ≤ 1920·256³·10⁸·(3ℓ)¹⁰ k/(α⁵β) ≤ (kℓ/(αβ))²⁰`
  (as `1920·256³·10⁸·3¹⁰ ≤ 16¹⁵·2¹⁹`);
* `L_val = ln(4/δ_val) ≤ 16 V` (`4·256³·10⁸·3⁶ ≤ 16¹³·2¹⁵`);
* hence `adaExplicitBound ≤ 128000·√k χ/α + 1024001·Λ₀³/α² + 4.32·10¹¹·ℓ³√ℓ K √V/α²`.
-/

namespace F2e2e

namespace A

section Asymp

variable {α β : ℝ}

/-- `ln(1/α) ≥ 1`. -/
lemma one_le_log_inv (hα : 0 < α) (hα' : α < 1 / 16) : 1 ≤ Real.log (1 / α) := by
  have := log_inv_gt hα hα'
  linarith

/-- `ln(1/(αβ)) ≥ 1`. -/
lemma one_le_log_inv_mul (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    1 ≤ Real.log (1 / (α * β)) := by
  have := log_inv_mul_gt hα hα' hβ hβ'
  linarith

/-- `ℓ/(αβ) ≥ 1`. -/
lemma one_le_V_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    1 ≤ Real.log (1 / α) / (α * β) := by
  have h1 := one_le_log_inv hα hα'
  have h2 := inv_mul_gt hα hα' hβ hβ'
  rw [le_div_iff₀ (by positivity)]
  have h3 : α * β < 1 := by
    rw [lt_div_iff₀ (by positivity)] at h2
    linarith
  nlinarith

/-- `kℓ/(αβ) ≥ 1`. -/
lemma one_le_K_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : 1 ≤ (k : ℝ) * Real.log (1 / α) / (α * β) := by
  have h1 := one_le_V_arg hα hα' hβ hβ'
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have : (k : ℝ) * Real.log (1 / α) / (α * β) = (k : ℝ) * (Real.log (1 / α) / (α * β)) := by ring
  rw [this]
  nlinarith

/-- Polynomial certificate for `Λ_SVT ≤ 20K`. -/
lemma svt_poly_le {k ℓ : ℝ} (hk : 1 ≤ k) (hℓ : 1 ≤ ℓ) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) :
    1920 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 10 * k / (α ^ 5 * β) ≤ (k * ℓ / (α * β)) ^ 20 := by
  have hk0 : 0 < k := by linarith
  have hℓ0 : 0 < ℓ := by linarith
  rw [div_pow, div_le_div_iff₀ (by positivity) (by positivity)]
  have hα15 : α ^ 15 ≤ (1 / 16) ^ 15 := pow_le_pow_left₀ hα.le hα'.le 15
  have hβ19 : β ^ 19 ≤ (1 / 2) ^ 19 := pow_le_pow_left₀ hβ.le hβ'.le 19
  have hc : 1920 * 256 ^ 3 * 10 ^ 8 * 3 ^ 10 * α ^ 15 * β ^ 19 ≤ 1 := by
    calc 1920 * 256 ^ 3 * 10 ^ 8 * 3 ^ 10 * α ^ 15 * β ^ 19
        ≤ 1920 * 256 ^ 3 * 10 ^ 8 * 3 ^ 10 * (1 / 16) ^ 15 * (1 / 2) ^ 19 := by gcongr
      _ ≤ 1 := by norm_num
  have hkℓ : ℓ ^ 10 * k ≤ (k * ℓ) ^ 20 := by
    have h1 : k ≤ k ^ 20 := le_self_pow₀ hk (by norm_num)
    have h2 : ℓ ^ 10 ≤ ℓ ^ 20 := pow_le_pow_right₀ hℓ (by norm_num)
    calc ℓ ^ 10 * k ≤ ℓ ^ 20 * k ^ 20 := mul_le_mul h2 h1 (by positivity) (by positivity)
      _ = (k * ℓ) ^ 20 := by ring
  have hc0 : 0 ≤ 1920 * 256 ^ 3 * 10 ^ 8 * 3 ^ 10 * α ^ 15 * β ^ 19 := by positivity
  calc 1920 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 10 * k * (α * β) ^ 20
      = (1920 * 256 ^ 3 * 10 ^ 8 * 3 ^ 10 * α ^ 15 * β ^ 19) * (ℓ ^ 10 * k) * (α ^ 5 * β) := by ring
    _ ≤ 1 * (k * ℓ) ^ 20 * (α ^ 5 * β) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        exact mul_le_mul hc hkℓ (by positivity) (by norm_num)
    _ = (k * ℓ) ^ 20 * (α ^ 5 * β) := by ring

/-- Polynomial certificate for `L_val ≤ 16V`. -/
lemma lval_poly_le {ℓ : ℝ} (hℓ : 1 ≤ ℓ) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) :
    4 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 6 / (α ^ 3 * β) ≤ (ℓ / (α * β)) ^ 16 := by
  have hℓ0 : 0 < ℓ := by linarith
  rw [div_pow, div_le_div_iff₀ (by positivity) (by positivity)]
  have hα13 : α ^ 13 ≤ (1 / 16) ^ 13 := pow_le_pow_left₀ hα.le hα'.le 13
  have hβ15 : β ^ 15 ≤ (1 / 2) ^ 15 := pow_le_pow_left₀ hβ.le hβ'.le 15
  have hc : 4 * 256 ^ 3 * 10 ^ 8 * 3 ^ 6 * α ^ 13 * β ^ 15 ≤ 1 := by
    calc 4 * 256 ^ 3 * 10 ^ 8 * 3 ^ 6 * α ^ 13 * β ^ 15
        ≤ 4 * 256 ^ 3 * 10 ^ 8 * 3 ^ 6 * (1 / 16) ^ 13 * (1 / 2) ^ 15 := by gcongr
      _ ≤ 1 := by norm_num
  have hℓ' : ℓ ^ 6 ≤ ℓ ^ 16 := pow_le_pow_right₀ hℓ (by norm_num)
  calc 4 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 6 * (α * β) ^ 16
      = (4 * 256 ^ 3 * 10 ^ 8 * 3 ^ 6 * α ^ 13 * β ^ 15) * ℓ ^ 6 * (α ^ 3 * β) := by ring
    _ ≤ 1 * ℓ ^ 16 * (α ^ 3 * β) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        exact mul_le_mul hc hℓ' (by positivity) (by norm_num)
    _ = ℓ ^ 16 * (α ^ 3 * β) := by ring

/-- `Λ_SVT ≤ 20 ln(k ln(1/α)/(αβ))`. -/
lemma log_svt_le_K (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) ≤
      20 * Real.log ((k : ℝ) * Real.log (1 / α) / (α * β)) := by
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hℓ := one_le_log_inv hα hα'
  have hL := adaL_pos_real hα hα'
  have hL3 := adaL_le_three_mul_log_inv hα hα'
  have hM := adaMmax_two_le hα hα'
  have hM0 : (0 : ℝ) ≤ (adaMmax α 2 : ℝ) := Nat.cast_nonneg _
  have hδ := adaDeltaVal_pos hα hβ
  have hk0 : (0 : ℝ) < (k : ℝ) := by linarith
  have hM1 : (0 : ℝ) < (adaMmax α 2 : ℝ) := by
    have := one_le_adaMmax_real α 2
    linarith
  rw [show (20 : ℝ) * Real.log ((k : ℝ) * Real.log (1 / α) / (α * β)) =
    Real.log (((k : ℝ) * Real.log (1 / α) / (α * β)) ^ 20) by rw [Real.log_pow]; norm_num]
  apply Real.log_le_log (by positivity)
  set ℓ := Real.log (1 / α) with hℓdef
  set L := (adaL α : ℝ) with hLdef
  calc 64 * L * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β
      = 64 * L * (k : ℝ) * (adaMmax α 2 : ℝ) * (256 ^ 3 * 10 ^ 8 * L ^ 6) / (α ^ 3 * β) := by
        rw [adaDeltaVal_eq, div_div_eq_mul_div]
    _ ≤ 64 * L * (k : ℝ) * (30 * L ^ 3 / α ^ 2) * (256 ^ 3 * 10 ^ 8 * L ^ 6) / (α ^ 3 * β) := by
        gcongr
    _ = 1920 * 256 ^ 3 * 10 ^ 8 * L ^ 10 * (k : ℝ) / (α ^ 5 * β) := by
        field_simp
        ring
    _ ≤ 1920 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 10 * (k : ℝ) / (α ^ 5 * β) := by
        gcongr
    _ ≤ ((k : ℝ) * ℓ / (α * β)) ^ 20 := svt_poly_le hk' hℓ hα hα' hβ hβ'

/-- `L_val ≤ 16 ln(ln(1/α)/(αβ))`. -/
lemma adaLval_le_V (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaLval α β ≤ 16 * Real.log (Real.log (1 / α) / (α * β)) := by
  have hℓ := one_le_log_inv hα hα'
  have hL := adaL_pos_real hα hα'
  have hL3 := adaL_le_three_mul_log_inv hα hα'
  have hδ := adaDeltaVal_pos hα hβ
  unfold adaLval
  rw [show (16 : ℝ) * Real.log (Real.log (1 / α) / (α * β)) =
    Real.log ((Real.log (1 / α) / (α * β)) ^ 16) by rw [Real.log_pow]; norm_num]
  apply Real.log_le_log (by positivity)
  set ℓ := Real.log (1 / α) with hℓdef
  set L := (adaL α : ℝ) with hLdef
  calc 4 / adaDeltaVal α β = 4 * (256 ^ 3 * 10 ^ 8 * L ^ 6) / (α ^ 3 * β) := by
        rw [adaDeltaVal_eq, div_div_eq_mul_div]
    _ = 4 * 256 ^ 3 * 10 ^ 8 * L ^ 6 / (α ^ 3 * β) := by ring
    _ ≤ 4 * 256 ^ 3 * 10 ^ 8 * (3 * ℓ) ^ 6 / (α ^ 3 * β) := by gcongr
    _ ≤ (ℓ / (α * β)) ^ 16 := lval_poly_le hℓ hα hα' hβ hβ'

/-- `L^{7/2} = L³ √L ≤ 54 ℓ³ √ℓ`. -/
lemma adaL_pow_le (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) ≤
      54 * (Real.log (1 / α) ^ 3 * Real.sqrt (Real.log (1 / α))) := by
  have hL := adaL_pos_real hα hα'
  have hL3 := adaL_le_three_mul_log_inv hα hα'
  have hℓ := log_inv_pos hα hα'
  have h1 : (adaL α : ℝ) ^ 3 ≤ (3 * Real.log (1 / α)) ^ 3 := pow_le_pow_left₀ hL.le hL3 3
  have h2 : Real.sqrt (adaL α : ℝ) ≤ 2 * Real.sqrt (Real.log (1 / α)) := by
    have : Real.sqrt (adaL α : ℝ) ≤ Real.sqrt (4 * Real.log (1 / α)) :=
      Real.sqrt_le_sqrt (by linarith)
    rw [Real.sqrt_mul (by norm_num), show Real.sqrt 4 = 2 by
      rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]] at this
    exact this
  calc (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)
      ≤ (3 * Real.log (1 / α)) ^ 3 * (2 * Real.sqrt (Real.log (1 / α))) :=
        mul_le_mul h1 h2 (Real.sqrt_nonneg _) (by positivity)
    _ = 54 * (Real.log (1 / α) ^ 3 * Real.sqrt (Real.log (1 / α))) := by ring

/-- `adaExplicitBound k α β ≤ 10¹² · adaAsymp k α β`. -/
theorem adaExplicitBound_le_asymp (k : ℕ) (α β : ℝ) (hk : 1 ≤ k) (hα : 0 < α)
    (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaExplicitBound k α β ≤ 10 ^ 12 * adaAsymp k α β := by
  have hℓ := one_le_log_inv hα hα'
  have hΛ0 := one_le_log_inv_mul hα hα' hβ hβ'
  have hL1 := adaL1_le_four_mul hα hα' hβ hβ'
  have hL1pos := adaL1_pos hα hα' hβ hβ'
  have hsvt := log_svt_le_K hα hα' hβ hβ' hk
  have hsvt0 := log_svt_pos hα hα' hβ hβ' hk
  have hval := adaLval_le_V hα hα' hβ hβ'
  have hval0 := adaLval_pos hα hα' hβ hβ'
  have hpow := adaL_pow_le hα hα'
  have hK0 : 0 ≤ Real.log ((k : ℝ) * Real.log (1 / α) / (α * β)) :=
    Real.log_nonneg (one_le_K_arg hα hα' hβ hβ' hk)
  have hV0 : 0 ≤ Real.log (Real.log (1 / α) / (α * β)) :=
    Real.log_nonneg (one_le_V_arg hα hα' hβ hβ')
  have hα2 : 0 < α ^ 2 := by positivity
  have hα21 : α ^ 2 ≤ 1 := by
    have : α ^ 2 < (1 / 16) ^ 2 := by gcongr
    linarith
  set ℓ := Real.log (1 / α) with hℓdef
  set Λ₀ := Real.log (1 / (α * β)) with hΛ0def
  set K := Real.log ((k : ℝ) * ℓ / (α * β)) with hKdef
  set V := Real.log (ℓ / (α * β)) with hVdef
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β)
    with hΛdef
  -- the first term
  set χ := (if α ^ 5 ≤ β then Real.sqrt Λ₀ else Λ₀) with hχdef
  have hχ0 : 0 ≤ χ := by
    rw [hχdef]
    split_ifs
    · exact Real.sqrt_nonneg _
    · linarith
  have hχ1 : adaChi1 α β ≤ 4 * χ := by
    unfold adaChi1
    rw [hχdef]
    split_ifs with h
    · have h1 : Real.sqrt (adaL1 α β) ≤ Real.sqrt (4 * Λ₀) := Real.sqrt_le_sqrt hL1
      rw [Real.sqrt_mul (by norm_num), show Real.sqrt 4 = 2 by
        rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]] at h1
      have h2 := Real.sqrt_nonneg Λ₀
      linarith
    · exact hL1
  have hT1 : 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α ≤
      128000 * (Real.sqrt (k : ℝ) * χ / α) := by
    have : 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α ≤ 32000 * Real.sqrt (k : ℝ) * (4 * χ) / α := by
      gcongr
    calc 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α ≤ 32000 * Real.sqrt (k : ℝ) * (4 * χ) / α := this
      _ = 128000 * (Real.sqrt (k : ℝ) * χ / α) := by ring
  -- the `L₁³` term
  have hT2 : 16000 * adaL1 α β ^ 3 / α ^ 2 ≤ 1024000 * (Λ₀ ^ 3 / α ^ 2) := by
    have h1 : adaL1 α β ^ 3 ≤ (4 * Λ₀) ^ 3 := pow_le_pow_left₀ hL1pos.le hL1 3
    calc 16000 * adaL1 α β ^ 3 / α ^ 2 ≤ 16000 * (4 * Λ₀) ^ 3 / α ^ 2 := by gcongr
      _ = 1024000 * (Λ₀ ^ 3 / α ^ 2) := by ring
  have hT0 : 1 ≤ Λ₀ ^ 3 / α ^ 2 := by
    rw [le_div_iff₀ hα2]
    have : 1 ≤ Λ₀ ^ 3 := one_le_pow₀ hΛ0
    linarith
  -- the validator term
  have hsqval : Real.sqrt (adaLval α β) ≤ 4 * Real.sqrt V := by
    have h1 : Real.sqrt (adaLval α β) ≤ Real.sqrt (16 * V) := Real.sqrt_le_sqrt hval
    rw [Real.sqrt_mul (by norm_num), show Real.sqrt 16 = 4 by
      rw [show (16 : ℝ) = 4 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]] at h1
    exact h1
  have hT3 : 10 ^ 8 / α ^ 2 * ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) * Λ *
      Real.sqrt (adaLval α β) ≤
      432000000000 * (ℓ ^ 3 * Real.sqrt ℓ * K * Real.sqrt V / α ^ 2) := by
    have hA0 : 0 ≤ (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) := by positivity
    have h1 : ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) * Λ ≤
        (54 * (ℓ ^ 3 * Real.sqrt ℓ)) * (20 * K) := mul_le_mul hpow hsvt hsvt0.le (by positivity)
    have h2 : ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) * Λ * Real.sqrt (adaLval α β) ≤
        (54 * (ℓ ^ 3 * Real.sqrt ℓ)) * (20 * K) * (4 * Real.sqrt V) :=
      mul_le_mul h1 hsqval (Real.sqrt_nonneg _) (by positivity)
    calc 10 ^ 8 / α ^ 2 * ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) * Λ * Real.sqrt (adaLval α β)
        = 10 ^ 8 / α ^ 2 *
            (((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) * Λ * Real.sqrt (adaLval α β)) := by ring
      _ ≤ 10 ^ 8 / α ^ 2 * ((54 * (ℓ ^ 3 * Real.sqrt ℓ)) * (20 * K) * (4 * Real.sqrt V)) := by
          gcongr
      _ = 432000000000 * (ℓ ^ 3 * Real.sqrt ℓ * K * Real.sqrt V / α ^ 2) := by ring
  -- assemble
  have hA : 0 ≤ Real.sqrt (k : ℝ) * χ / α := by positivity
  have hB : 0 ≤ ℓ ^ 3 * Real.sqrt ℓ * K * Real.sqrt V / α ^ 2 := by positivity
  have hC : 0 ≤ Λ₀ ^ 3 / α ^ 2 := by positivity
  have hasymp : adaAsymp k α β =
      Real.sqrt (k : ℝ) * χ / α + Λ₀ ^ 3 / α ^ 2 + ℓ ^ 3 * Real.sqrt ℓ * K * Real.sqrt V / α ^ 2 := by
    unfold adaAsymp
    rw [hχdef]
    ring
  unfold adaExplicitBound
  rw [hasymp]
  linarith

end Asymp

end A

end F2e2e
