import F2e2e.Spec
import F2e2e.A.Chain
import F2e2e.Lib.Opt.EntropicWaterFill

/-!
# Spec v2 (A) bridge, part 1: one round of `F2e2e.adaCascade` vs A-ARCH's `step` (A-ACC draft)

Scratch draft against the namespaced Spec v2 candidate `F2e2e.Scratch.AV2.SpecV2NS` (namespace `F2e2eV2`).
After the lock this becomes part of `F2e2e/A/SpecV2Bridge.lean` (with `F2e2e.` ↦ `F2e2e.`).

## Contents
* Parameters: the v2 locked parameters are definitionally A-ARCH's (`adaL_eq`, `adaBlock_eq`, …).
* `coinMap`: the coin map `φ : Ω_v2 → Ω_A`, identity on the Laplace coordinates and `ξ_i ↦ ξ_i / R₁` on
  the Stage-1 coordinates; `Good ω` (`|ξ_i| < R₁` for all `i`, almost sure under `adaCoinLaw`);
  `R₁ · clampUnit (V_i(φ ω)) = ξ_i(ω)` on `Good`.
* `adaQAt_eq`: v2's block lookup is A-ARCH's `adaBlockIdx`.
* `entropicArgmin_eq_waterFill`: v2's literal argmin over `K₂` is `Opt.waterFill` (`n ≥ 1`, `η > 0`).
* `adaChain_corr`: v2's chain `adaChain` is A-ARCH's `ChainData.orig`.
-/

namespace F2e2e.A.V2Bridge

open MeasureTheory

noncomputable section

/-! ## The locked parameters agree definitionally -/

section Params

variable (k : ℕ) (α β : ℝ)

theorem adaL_eq : F2e2e.adaL α = adaL α := rfl

theorem adaSampleSize_eq : F2e2e.adaSampleSize k α β = adaSampleSize k α β := rfl

theorem adaBlock_eq (r : ℕ) : F2e2e.adaBlock k α β r = adaBlock k α β r := rfl

theorem adaOffset_eq (r : ℕ) : F2e2e.adaOffset k α β r = adaOffset k α β r := rfl

theorem adaTau_eq : F2e2e.adaTau α = adaTau α := rfl

theorem adaR1_eq : F2e2e.adaR1 α = adaR1 α := rfl

theorem adaEta1_eq : F2e2e.adaEta1 α = adaEta1 α := rfl

theorem adaEta_eq : F2e2e.adaEta α = adaEta α := rfl

theorem adaEtaTilde_eq : F2e2e.adaEtaTilde α = adaEtaTilde α := rfl

theorem adaP1_eq : F2e2e.adaP1 α β = adaP1 α β := rfl

theorem adaT1max_eq : F2e2e.adaT1max α = adaT1max α := rfl

theorem adaNmax_eq : F2e2e.adaNmax α = adaNmax α := rfl

theorem adaBsvt_eq : F2e2e.adaBsvt k α β = adaBsvt k α β := rfl

end Params

/-! ## The coin map -/

/-- The coin map `φ : Ω_v2 → Ω_A`: v2 stores the Stage-1 noise `ξ_i = R₁(2B_i - 1)` itself, A-ARCH stores
`V_i = 2B_i - 1` (and uses `ξ_i = R₁ · clampUnit V_i`); the Laplace coordinates are the same. -/
def coinMap (k : ℕ) (α : ℝ) (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) : AdaOmega k α :=
  fun j => match j with
  | .beta i => ω (Sum.inl i) / adaR1 α
  | .nu i r => ω (Sum.inr (Sum.inl (i, r)))
  | .zeta i r => ω (Sum.inr (Sum.inr (Sum.inl (i, r))))
  | .rho r e => ω (Sum.inr (Sum.inr (Sum.inr (r, e))))

/-- The almost-sure event `|ξ_i| < R₁` for every round `i < k` (the support of `R₁(2B - 1)`). -/
def Good {k : ℕ} {α : ℝ} (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) : Prop :=
  ∀ i : Fin k, |ω (Sum.inl i)| < adaR1 α

section Coins

variable {k : ℕ} {α : ℝ} (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ)

theorem noiseNu_coinMap (i r : ℕ) : noiseNu (coinMap k α ω) i r = F2e2e.noiseNu ω i r := rfl

theorem noiseZeta_coinMap (i r : ℕ) : noiseZeta (coinMap k α ω) i r = F2e2e.noiseZeta ω i r := rfl

theorem noiseRho_coinMap (r e : ℕ) : noiseRho (coinMap k α ω) r e = F2e2e.noiseRho ω r e := rfl

/-- On `Good`, A-ARCH's Stage-1 noise `R₁ · clampUnit(V_i(φ ω))` is v2's `ξ_i(ω)`. -/
theorem stage1Noise_coinMap (hω : Good ω) (i : ℕ) :
    adaR1 α * Dist.clampUnit (noiseBeta (coinMap k α ω) i) = F2e2e.noiseXi ω i := by
  unfold noiseBeta F2e2e.noiseXi
  by_cases hi : i < k
  · rw [dif_pos hi, dif_pos hi]
    have hR := hω ⟨i, hi⟩
    have hR0 : 0 < adaR1 α := lt_of_le_of_lt (abs_nonneg _) hR
    show adaR1 α * Dist.clampUnit (ω (Sum.inl ⟨i, hi⟩) / adaR1 α) = ω (Sum.inl ⟨i, hi⟩)
    have hmem : ω (Sum.inl ⟨i, hi⟩) / adaR1 α ∈ Set.Ioo (-1 : ℝ) 1 := by
      rw [abs_lt] at hR
      constructor
      · rw [lt_div_iff₀ hR0]
        linarith
      · rw [div_lt_iff₀ hR0]
        linarith
    rw [Dist.clampUnit_of_mem hmem]
    field_simp
  · rw [dif_neg hi, dif_neg hi, Dist.clampUnit_of_mem (by norm_num), mul_zero]

end Coins

/-! ## Block lookups -/

theorem adaQAt_eq {k : ℕ} {α β : ℝ} (q : Fin (F2e2e.adaSampleSize k α β) → ℝ) (r : ℕ)
    (ℓ : Fin (F2e2e.adaBlock k α β r)) : F2e2e.adaQAt q r ℓ = q (adaBlockIdx k α β r ℓ) := by
  unfold F2e2e.adaQAt
  exact dif_pos (adaOffset_add_lt k α β r ℓ)

/-- `adaQAt_eq` for an index typed with A-ARCH's `adaBlock` (definitionally the same type; stated
separately so that `rw` finds it syntactically). -/
theorem adaQAt_eq' {k : ℕ} {α β : ℝ} (q : Fin (F2e2e.adaSampleSize k α β) → ℝ) (r : ℕ)
    (ℓ : Fin (adaBlock k α β r)) : F2e2e.adaQAt q r ℓ = q (adaBlockIdx k α β r ℓ) :=
  adaQAt_eq q r ℓ

/-! ## The entropic projection -/

theorem capSimplex2_eq (n : ℕ) : F2e2e.capSimplex2 n = Opt.cappedSimplex n := by
  ext P
  rw [Opt.mem_cappedSimplex]
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨fun ℓ => (h1 ℓ).1, fun ℓ => (h1 ℓ).2, h2⟩
  · rintro ⟨h0, h1, h2⟩
    exact ⟨fun ℓ => ⟨h0 ℓ, h1 ℓ⟩, h2⟩

theorem entropicObjective_eq (n : ℕ) (η : ℝ) (G P : Fin n → ℝ) :
    F2e2e.entropicObjective n η G P = Opt.ftrlObj n η G P := rfl

/-- v2's literal argmin over the 2-capped simplex is the water-filling solution (`n ≥ 1`, `η > 0`). -/
theorem entropicArgmin_eq_waterFill {n : ℕ} (hn : 0 < n) {η : ℝ} (hη : 0 < η) (G : Fin n → ℝ) :
    F2e2e.entropicArgmin n η G = Opt.waterFill n η G := by
  have hex : ∃ P : Fin n → ℝ, P ∈ F2e2e.capSimplex2 n ∧
      ∀ Q ∈ F2e2e.capSimplex2 n, F2e2e.entropicObjective n η G P ≤
        F2e2e.entropicObjective n η G Q := by
    refine ⟨Opt.waterFill n η G, ?_, fun Q hQ => ?_⟩
    · exact (Set.ext_iff.mp (capSimplex2_eq n) _).mpr (Opt.waterFill_mem hn η G)
    · exact isMinOn_iff.mp (Opt.waterFill_isMinOn hn hη G) Q
        ((Set.ext_iff.mp (capSimplex2_eq n) Q).mp hQ)
  have hspec := Classical.epsilon_spec hex
  obtain ⟨hmem, hmin⟩ := hspec
  refine Opt.eq_waterFill_of_isMinOn hn hη G ((Set.ext_iff.mp (capSimplex2_eq n) _).mp hmem)
    (isMinOn_iff.mpr fun Q hQ => ?_)
  exact hmin Q ((Set.ext_iff.mp (capSimplex2_eq n) Q).mpr hQ)

/-! ## The first-trigger chain -/

/-- v2's chain `adaChain` on the inputs of a `ChainData` is its `orig` (origins equal, proposals equal as
reals; v2's proposals are `[0,1]`-valued). -/
theorem adaChain_corr (d : ChainData) (c1 : Set.Icc (0 : ℝ) 1) (hc1 : (c1 : ℝ) = d.c1) (r : ℕ) :
    (F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1 = (d.orig r).1 ∧
      ((F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) = (d.orig r).2 := by
  induction r with
  | zero => exact ⟨rfl, hc1⟩
  | succ r ih =>
    obtain ⟨h1, h2⟩ := ih
    have hf : F2e2e.adaFires d.L d.tau d.theta d.rho d.nu
        (F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1
        ((F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) r = true ↔
        (2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2) := by
      rw [h1, h2]
      unfold F2e2e.adaFires ChainData.Fires
      exact decide_eq_true_iff
    show (if F2e2e.adaFires d.L d.tau d.theta d.rho d.nu
          (F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1
          ((F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) r = true
        then (r, F2e2e.clip01 (d.theta r + d.zeta r))
        else F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1 =
          (if 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2 then (r, d.relC r)
            else d.orig r).1 ∧
        ((if F2e2e.adaFires d.L d.tau d.theta d.rho d.nu
          (F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1
          ((F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) r = true
        then (r, F2e2e.clip01 (d.theta r + d.zeta r))
        else F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) =
          (if 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2 then (r, d.relC r)
            else d.orig r).2
    by_cases ht : 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2
    · rw [if_pos (hf.mpr ht), if_pos ht]
      exact ⟨rfl, rfl⟩
    · rw [if_neg (mt hf.mp ht), if_neg ht]
      exact ⟨h1, h2⟩

/-- The v2 trigger bit of stage `r` is `decide (Trig r)`. -/
theorem adaFires_corr (d : ChainData) (c1 : Set.Icc (0 : ℝ) 1) (hc1 : (c1 : ℝ) = d.c1) (r : ℕ) :
    F2e2e.adaFires d.L d.tau d.theta d.rho d.nu
        (F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).1
        ((F2e2e.adaChain d.L d.tau d.theta d.rho d.nu d.zeta c1 r).2 : ℝ) r = decide (d.Trig r) := by
  obtain ⟨h1, h2⟩ := adaChain_corr d c1 hc1 r
  rw [h1, h2]
  rfl

/-- `entropicArgmin = waterFill` for every block size (`n = 0` is trivial). -/
theorem entropicArgmin_eq_waterFill' {n : ℕ} {η : ℝ} (hη : 0 < η) (G : Fin n → ℝ) :
    F2e2e.entropicArgmin n η G = Opt.waterFill n η G := by
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    funext ℓ
    exact ℓ.elim0
  · exact entropicArgmin_eq_waterFill hn hη G

/-! ## One round -/

section Round

variable {k : ℕ} {α β : ℝ}

/-- The v2 public record `τ_aux,i` of the A-ARCH record `rec` of a round started in state `st`. The fields
are A-ARCH's, except: `c1` is A-ARCH's `c 1` (v2 keeps `c 1 = 0` and has the separate field `c1`); the
Case-A impulse (A-ARCH records `δ_{1,i} = -η₁ s`, v2 only the validator levels `m ≥ 2`); `haltAfter` is the
next state's `HALT`, computed from `t₁`, `N_r` and the record. -/
def toField (st : MState k α β) (rec : RoundRec) : F2e2e.ADAField → ℝ
  | .active => if rec.active then 1 else 0
  | .c1 => rec.c 1
  | .b r => if rec.trig r then 1 else 0
  | .uPrev r => if rec.trig r then (rec.uprev r : ℝ) else 0
  | .released r => if rec.rel r then 1 else 0
  | .v r => rec.v r
  | .c r => if r = 1 then 0 else rec.c r
  | .s => rec.sgn
  | .delta m => if m = 1 then 0 else rec.delta m
  | .haltAfter => if (rec.ufinal = 2 ∧ st.t1 + 1 = adaT1max α) ∨
      (3 ≤ rec.ufinal ∧ st.N rec.ufinal + 1 = adaNmax α rec.ufinal) then 1 else 0

/-- The v2 public output `(a_i, τ_aux,i)` of an A-ARCH round. -/
def toPublic (st : MState k α β) (rec : RoundRec) : Set.Icc (0 : ℝ) 1 × (F2e2e.ADAField → ℝ) :=
  (F2e2e.clip01 rec.answer, toField st rec)

/-- The state correspondence: v2 stores `G^{(1)}` and the weights `P^{(r)}`, A-ARCH stores `η₁ G^{(1)}` and
recomputes the weights by water-filling. -/
structure Corr (st2 : F2e2e.ADAState k α β) (st : MState k α β) : Prop where
  halt : st2.halt = st.halt
  t1 : st2.t1 = st.t1
  N : st2.N = st.N
  M : st2.M = st.M
  pay1 : ∀ ℓ, st.pay 1 ℓ = adaEta1 α * st2.pay 1 ℓ
  pay : ∀ r, r ≠ 1 → ∀ ℓ, st.pay r ℓ = st2.pay r ℓ
  P : ∀ r, st2.P r = st.weight r

/-! ### v2's active round, unfolded -/

section V2

variable (st2 : F2e2e.ADAState k α β) (i : ℕ) (q : Fin (F2e2e.adaSampleSize k α β) → ℝ)
  (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ)

def vθ : ℕ → ℝ := fun r => ∑ ℓ, st2.P r ℓ * F2e2e.adaQAt q r ℓ

def vρ : ℕ → ℝ := fun r => F2e2e.noiseRho ω r (st2.M r - 1)

def vν : ℕ → ℝ := fun r => F2e2e.noiseNu ω i r

def vζ : ℕ → ℝ := fun r => F2e2e.noiseZeta ω i r

def vc1 : Set.Icc (0 : ℝ) 1 := F2e2e.clip01 (vθ st2 q 1 + F2e2e.noiseXi ω i)

def vchain : ℕ → ℕ × Set.Icc (0 : ℝ) 1 :=
  F2e2e.adaChain (F2e2e.adaL α) (F2e2e.adaTau α) (vθ st2 q) (vρ st2 ω) (vν i ω) (vζ i ω)
    (vc1 st2 i q ω)

def vtrig (r : ℕ) : Bool :=
  F2e2e.adaFires (F2e2e.adaL α) (F2e2e.adaTau α) (vθ st2 q) (vρ st2 ω) (vν i ω)
    (vchain st2 i q ω r).1 ((vchain st2 i q ω r).2 : ℝ) r

def vuF : ℕ := (vchain st2 i q ω (F2e2e.adaL α + 1)).1

def vans : Set.Icc (0 : ℝ) 1 := (vchain st2 i q ω (F2e2e.adaL α + 1)).2

def vcaseA : Bool := decide (vuF st2 i q ω = 2)

def vcaseB : Bool := decide (3 ≤ vuF st2 i q ω)

def vrel (r : ℕ) : Bool := vtrig st2 i q ω r || (vcaseB st2 i q ω && decide (r + 1 = vuF st2 i q ω))

def vs : ℝ :=
  if 2 ≤ vuF st2 i q ω then
    F2e2e.sign1 (((vchain st2 i q ω (vuF st2 i q ω)).2 : ℝ) - (vans st2 i q ω : ℝ))
  else 0

def vδ (m : ℕ) : ℝ :=
  if vcaseB st2 i q ω = true then
    (if m + 1 = vuF st2 i q ω then -(F2e2e.adaEta α * vs st2 i q ω)
     else if m = vuF st2 i q ω ∧ vuF st2 i q ω ≤ F2e2e.adaL α - 1 then
       F2e2e.adaEtaTilde α m * vs st2 i q ω
     else 0)
  else 0

def vhaltAfter : Bool := (vcaseA st2 i q ω && decide (st2.t1 + 1 = F2e2e.adaT1max α)) ||
  (vcaseB st2 i q ω && decide (st2.N (vuF st2 i q ω) + 1 = F2e2e.adaNmax α (vuF st2 i q ω)))

def vpay : (r : ℕ) → Fin (F2e2e.adaBlock k α β r) → ℝ := fun r ℓ =>
  if vcaseA st2 i q ω = true ∧ r = 1 then st2.pay r ℓ - vs st2 i q ω * F2e2e.adaQAt q r ℓ
  else if 2 ≤ r ∧ r ≤ F2e2e.adaL α - 1 then
    st2.pay r ℓ + vδ st2 i q ω r * F2e2e.adaQAt q r ℓ
  else st2.pay r ℓ

def vupd (r : ℕ) : Bool := (vcaseA st2 i q ω && decide (r = 1)) ||
  (vcaseB st2 i q ω && decide (2 ≤ r ∧ r ≤ F2e2e.adaL α - 1 ∧
    (r + 1 = vuF st2 i q ω ∨ r = vuF st2 i q ω)))

def vP : (r : ℕ) → Fin (F2e2e.adaBlock k α β r) → ℝ := fun r =>
  if vupd st2 i q ω r = true then
    (if r = 1 then F2e2e.entropicArgmin (F2e2e.adaBlock k α β r) (F2e2e.adaEta1 α) (vpay st2 i q ω r)
     else F2e2e.entropicArgmin (F2e2e.adaBlock k α β r) 1 (vpay st2 i q ω r))
  else st2.P r

theorem active_answer : (F2e2e.adaActiveRound st2 i q ω).2.1 = vans st2 i q ω := rfl

theorem active_f_active : (F2e2e.adaActiveRound st2 i q ω).2.2 .active = 1 := rfl

theorem active_f_c1 : (F2e2e.adaActiveRound st2 i q ω).2.2 .c1 = (vc1 st2 i q ω : ℝ) := rfl

theorem active_f_b (r : ℕ) :
    (F2e2e.adaActiveRound st2 i q ω).2.2 (.b r) = if vtrig st2 i q ω r = true then 1 else 0 := rfl

theorem active_f_uPrev (r : ℕ) : (F2e2e.adaActiveRound st2 i q ω).2.2 (.uPrev r) =
    if vtrig st2 i q ω r = true then ((vchain st2 i q ω r).1 : ℝ) else 0 := rfl

theorem active_f_released (r : ℕ) : (F2e2e.adaActiveRound st2 i q ω).2.2 (.released r) =
    if vrel st2 i q ω r = true then 1 else 0 := rfl

theorem active_f_v (r : ℕ) : (F2e2e.adaActiveRound st2 i q ω).2.2 (.v r) =
    if vrel st2 i q ω r = true then vθ st2 q r + vζ i ω r else 0 := rfl

theorem active_f_c (r : ℕ) : (F2e2e.adaActiveRound st2 i q ω).2.2 (.c r) =
    if vrel st2 i q ω r = true then
      ((F2e2e.clip01 (vθ st2 q r + vζ i ω r) : Set.Icc (0 : ℝ) 1) : ℝ) else 0 := rfl

theorem active_f_s : (F2e2e.adaActiveRound st2 i q ω).2.2 .s = vs st2 i q ω := rfl

theorem active_f_delta (m : ℕ) :
    (F2e2e.adaActiveRound st2 i q ω).2.2 (.delta m) = vδ st2 i q ω m := rfl

theorem active_f_haltAfter : (F2e2e.adaActiveRound st2 i q ω).2.2 .haltAfter =
    if vhaltAfter st2 i q ω = true then 1 else 0 := rfl

theorem active_halt : (F2e2e.adaActiveRound st2 i q ω).1.halt = vhaltAfter st2 i q ω := rfl

theorem active_t1 : (F2e2e.adaActiveRound st2 i q ω).1.t1 =
    st2.t1 + (if vcaseA st2 i q ω = true then 1 else 0) := rfl

theorem active_N : (F2e2e.adaActiveRound st2 i q ω).1.N =
    fun r => st2.N r + (if vcaseB st2 i q ω = true ∧ r = vuF st2 i q ω then 1 else 0) := rfl

theorem active_M : (F2e2e.adaActiveRound st2 i q ω).1.M = fun r => st2.M r +
    (if (vcaseA st2 i q ω = true ∧ r = 2) ∨
        (vcaseB st2 i q ω = true ∧ 2 ≤ r ∧ r ≤ vuF st2 i q ω) then 1 else 0) := rfl

theorem active_pay : (F2e2e.adaActiveRound st2 i q ω).1.pay = vpay st2 i q ω := rfl

theorem active_P : (F2e2e.adaActiveRound st2 i q ω).1.P = vP st2 i q ω := rfl

end V2

/-! ### The correspondence for one round -/

/-- A-ARCH's chain data of round `i` on the coins `φ ω`. -/
def dC (st : MState k α β) (i : ℕ) (q : Fin (F2e2e.adaSampleSize k α β) → ℝ)
    (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) : ChainData :=
  roundChain st i q (coinMap k α ω)

/-- `η̃_L = 0`. -/
theorem adaEtaTilde_L (α : ℝ) : adaEtaTilde α (adaL α) = 0 := by
  simp [adaEtaTilde]

theorem dC_ufinal_le (st : MState k α β) (i : ℕ) (q : Fin (F2e2e.adaSampleSize k α β) → ℝ)
    (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) : (dC st i q ω).ufinal ≤ adaL α :=
  (dC st i q ω).ufinal_le_L (by show 1 ≤ adaL α; have := adaL_ge_four α; omega)

theorem delta_one (d : ChainData) (e1 e : ℝ) (eT : ℕ → ℝ) :
    d.delta e1 e eT 1 = if d.ufinal = 2 then -e1 * d.sgn else 0 := by
  unfold ChainData.delta
  split_ifs <;> first | rfl | (exfalso; omega)

theorem delta_eq_zero_of_not_mid (st : MState k α β) (i : ℕ)
    (q : Fin (F2e2e.adaSampleSize k α β) → ℝ) (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ)
    {r : ℕ} (hr1 : r ≠ 1) (hmid : ¬ (2 ≤ r ∧ r ≤ adaL α - 1)) :
    (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) r = 0 := by
  have hL := dC_ufinal_le st i q ω
  unfold ChainData.delta
  split_ifs with h1 h2 h3 h4 <;> first | rfl | (exfalso; omega) | skip
  have hrL : r = adaL α := by omega
  rw [hrL, adaEtaTilde_L, zero_mul]

theorem delta_eq_zero_of_not_upd (st : MState k α β) (i : ℕ)
    (q : Fin (F2e2e.adaSampleSize k α β) → ℝ) (ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ)
    {r : ℕ} (hrL : r ≠ adaL α)
    (h : ¬ (((dC st i q ω).ufinal = 2 ∧ r = 1) ∨ (3 ≤ (dC st i q ω).ufinal ∧ 2 ≤ r ∧
      r ≤ adaL α - 1 ∧ (r + 1 = (dC st i q ω).ufinal ∨ r = (dC st i q ω).ufinal)))) :
    (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) r = 0 := by
  have hL := dC_ufinal_le st i q ω
  unfold ChainData.delta
  split_ifs <;> first | rfl | (exfalso; omega)

section CorrRound

variable {st2 : F2e2e.ADAState k α β} {st : MState k α β} (hc : Corr st2 st) (i : ℕ)
  (q : Fin (F2e2e.adaSampleSize k α β) → ℝ) {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ}
  (hω : Good ω)

include hc in
theorem vθ_eq : vθ st2 q = st.theta q := by
  funext r
  unfold vθ MState.theta
  refine Finset.sum_congr rfl fun ℓ _ => ?_
  rw [hc.P r, adaQAt_eq]

include hc in
theorem vρ_eq : vρ st2 ω = (dC st i q ω).rho := by
  funext r
  show F2e2e.noiseRho ω r (st2.M r - 1) = F2e2e.noiseRho ω r (st.M r - 1)
  rw [hc.M]

include hc hω in
theorem vc1_eq : (vc1 st2 i q ω : ℝ) = (dC st i q ω).c1 := by
  show min 1 (max 0 (vθ st2 q 1 + F2e2e.noiseXi ω i)) =
    clip01 (st.theta q 1 + adaR1 α * Dist.clampUnit (noiseBeta (coinMap k α ω) i))
  rw [vθ_eq hc q, stage1Noise_coinMap ω hω i]
  rfl

include hc in
theorem vchain_eq : vchain st2 i q ω = F2e2e.adaChain (dC st i q ω).L (dC st i q ω).tau
    (dC st i q ω).theta (dC st i q ω).rho (dC st i q ω).nu (dC st i q ω).zeta (vc1 st2 i q ω) := by
  unfold vchain
  rw [vθ_eq hc q, vρ_eq hc i q]
  rfl

include hc hω in
theorem vchain_corr (r : ℕ) : (vchain st2 i q ω r).1 = ((dC st i q ω).orig r).1 ∧
    ((vchain st2 i q ω r).2 : ℝ) = ((dC st i q ω).orig r).2 := by
  rw [vchain_eq hc i q]
  exact adaChain_corr _ _ (vc1_eq hc i q hω) r

include hc hω in
theorem vtrig_eq (r : ℕ) : vtrig st2 i q ω r = decide ((dC st i q ω).Trig r) := by
  have h := adaFires_corr (dC st i q ω) (vc1 st2 i q ω) (vc1_eq hc i q hω) r
  rw [← vchain_eq hc i q] at h
  unfold vtrig
  rw [vθ_eq hc q, vρ_eq hc i q]
  exact h

include hc hω in
theorem vuF_eq : vuF st2 i q ω = (dC st i q ω).ufinal :=
  (vchain_corr hc i q hω (F2e2e.adaL α + 1)).1

include hc hω in
theorem vans_eq : (vans st2 i q ω : ℝ) = (dC st i q ω).answer :=
  (vchain_corr hc i q hω (F2e2e.adaL α + 1)).2

include hc hω in
theorem vcaseA_eq : vcaseA st2 i q ω = decide ((dC st i q ω).ufinal = 2) := by
  unfold vcaseA
  rw [vuF_eq hc i q hω]

include hc hω in
theorem vcaseB_eq : vcaseB st2 i q ω = decide (3 ≤ (dC st i q ω).ufinal) := by
  unfold vcaseB
  rw [vuF_eq hc i q hω]

include hc hω in
theorem vrel_eq (r : ℕ) : vrel st2 i q ω r = decide ((dC st i q ω).Released r) := by
  unfold vrel
  rw [vtrig_eq hc i q hω, vcaseB_eq hc i q hω, vuF_eq hc i q hω, Bool.eq_iff_iff]
  simp only [Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_iff]
  exact Iff.rfl

include hc hω in
theorem vs_eq : vs st2 i q ω = (dC st i q ω).sgn := by
  unfold vs
  rw [vuF_eq hc i q hω, (vchain_corr hc i q hω _).2, vans_eq hc i q hω]
  rfl

include hc hω in
theorem vδ_eq (m : ℕ) : vδ st2 i q ω m =
    if m = 1 then 0 else (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) m := by
  have hL := dC_ufinal_le st i q ω
  unfold vδ ChainData.delta
  rw [vcaseB_eq hc i q hω, vuF_eq hc i q hω, vs_eq hc i q hω, adaL_eq, adaEta_eq, adaEtaTilde_eq]
  simp only [decide_eq_true_iff]
  split_ifs <;> first | rfl | (exfalso; omega) | (rw [neg_mul]) |
    (rw [show m = adaL α by omega, adaEtaTilde_L, zero_mul])

include hc hω in
theorem vhaltAfter_eq : vhaltAfter st2 i q ω =
    decide (((dC st i q ω).ufinal = 2 ∧ st.t1 + 1 = adaT1max α) ∨
      (3 ≤ (dC st i q ω).ufinal ∧ st.N (dC st i q ω).ufinal + 1 = adaNmax α (dC st i q ω).ufinal)) := by
  unfold vhaltAfter
  rw [vcaseA_eq hc i q hω, vcaseB_eq hc i q hω, vuF_eq hc i q hω, hc.t1, hc.N, Bool.eq_iff_iff]
  simp only [Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_iff]

include hc hω in
theorem vupd_iff (r : ℕ) : vupd st2 i q ω r = true ↔
    (((dC st i q ω).ufinal = 2 ∧ r = 1) ∨ (3 ≤ (dC st i q ω).ufinal ∧ 2 ≤ r ∧
      r ≤ adaL α - 1 ∧ (r + 1 = (dC st i q ω).ufinal ∨ r = (dC st i q ω).ufinal))) := by
  unfold vupd
  rw [vcaseA_eq hc i q hω, vcaseB_eq hc i q hω, vuF_eq hc i q hω, adaL_eq]
  simp only [Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_iff]

/-! #### The next state -/

include hc hω in
theorem next_pay1 (ℓ : Fin (adaBlock k α β 1)) :
    (st.next q (activeRec st i q (coinMap k α ω))).pay 1 ℓ = adaEta1 α * vpay st2 i q ω 1 ℓ := by
  show st.pay 1 ℓ + (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) 1 *
      q (adaBlockIdx k α β 1 ℓ) = adaEta1 α * vpay st2 i q ω 1 ℓ
  rw [delta_one, hc.pay1 ℓ]
  unfold vpay
  rw [vcaseA_eq hc i q hω, adaQAt_eq', vs_eq hc i q hω]
  by_cases h2 : (dC st i q ω).ufinal = 2
  · rw [if_pos h2, if_pos ⟨decide_eq_true h2, rfl⟩]
    ring
  · rw [if_neg h2, if_neg (fun h => h2 (of_decide_eq_true h.1)),
      if_neg (show ¬ (2 ≤ 1 ∧ 1 ≤ F2e2e.adaL α - 1) by omega)]
    ring

include hc hω in
theorem next_pay {r : ℕ} (hr1 : r ≠ 1) (ℓ : Fin (adaBlock k α β r)) :
    (st.next q (activeRec st i q (coinMap k α ω))).pay r ℓ = vpay st2 i q ω r ℓ := by
  show st.pay r ℓ + (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) r *
      q (adaBlockIdx k α β r ℓ) = vpay st2 i q ω r ℓ
  unfold vpay
  rw [if_neg (fun h => hr1 h.2), hc.pay r hr1 ℓ]
  by_cases hmid : 2 ≤ r ∧ r ≤ F2e2e.adaL α - 1
  · rw [if_pos hmid, vδ_eq hc i q hω, if_neg hr1, adaQAt_eq']
  · rw [if_neg hmid, delta_eq_zero_of_not_mid st i q ω hr1 hmid, zero_mul, add_zero]

include hc hω in
theorem active_corr (hα : 0 < α) :
    Corr (F2e2e.adaActiveRound st2 i q ω).1 (st.next q (activeRec st i q (coinMap k α ω))) := by
  have h1 := (dC st i q ω).one_le_ufinal
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [active_halt, vhaltAfter_eq hc i q hω]
    rfl
  · rw [active_t1, vcaseA_eq hc i q hω, hc.t1]
    show st.t1 + _ = st.t1 + if (dC st i q ω).ufinal = 2 then 1 else 0
    congr 1
    exact if_congr decide_eq_true_iff rfl rfl
  · rw [active_N, vcaseB_eq hc i q hω, vuF_eq hc i q hω, hc.N]
    funext r
    show st.N r + _ = st.N r + if 3 ≤ (dC st i q ω).ufinal ∧ r = (dC st i q ω).ufinal then 1 else 0
    congr 1
    exact if_congr (by simp only [decide_eq_true_iff]) rfl rfl
  · rw [active_M, vcaseA_eq hc i q hω, vcaseB_eq hc i q hω, vuF_eq hc i q hω, hc.M]
    funext r
    show st.M r + _ = st.M r + if 2 ≤ r ∧ r ≤ (dC st i q ω).ufinal then 1 else 0
    congr 1
    refine if_congr ?_ rfl rfl
    simp only [decide_eq_true_iff]
    constructor
    · intro h
      omega
    · intro h
      omega
  · intro ℓ
    rw [active_pay]
    exact next_pay1 hc i q hω ℓ
  · intro r hr1 ℓ
    rw [active_pay]
    exact next_pay hc i q hω hr1 ℓ
  · intro r
    rw [active_P]
    unfold vP
    by_cases hu : vupd st2 i q ω r = true
    · rw [if_pos hu]
      have hu' := (vupd_iff hc i q hω r).mp hu
      have hrL : r ≠ adaL α := by
        have := adaL_ge_four α
        omega
      unfold MState.weight
      rw [if_neg hrL]
      by_cases hr1 : r = 1
      · subst hr1
        rw [if_pos rfl, entropicArgmin_eq_waterFill' (show 0 < F2e2e.adaEta1 α by
          unfold F2e2e.adaEta1; linarith)]
        apply Opt.waterFill_congr
        intro ℓ
        rw [one_mul, next_pay1 hc i q hω ℓ]
        rfl
      · rw [if_neg hr1, entropicArgmin_eq_waterFill' one_pos]
        apply Opt.waterFill_congr
        intro ℓ
        rw [next_pay hc i q hω hr1 ℓ]
    · rw [if_neg hu, hc.P r]
      have hu' : ¬ (((dC st i q ω).ufinal = 2 ∧ r = 1) ∨ (3 ≤ (dC st i q ω).ufinal ∧ 2 ≤ r ∧
          r ≤ adaL α - 1 ∧ (r + 1 = (dC st i q ω).ufinal ∨ r = (dC st i q ω).ufinal))) :=
        fun h => hu ((vupd_iff hc i q hω r).mpr h)
      unfold MState.weight
      by_cases hrL : r = adaL α
      · rw [if_pos hrL, if_pos hrL]
      · rw [if_neg hrL, if_neg hrL]
        congr 1
        funext ℓ
        show st.pay r ℓ = st.pay r ℓ + (dC st i q ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) r *
          q (adaBlockIdx k α β r ℓ)
        rw [delta_eq_zero_of_not_upd st i q ω hrL hu', zero_mul, add_zero]

/-! #### The public output -/

include hc hω in
theorem active_out :
    (F2e2e.adaActiveRound st2 i q ω).2 = toPublic st (activeRec st i q (coinMap k α ω)) := by
  refine Prod.ext ?_ (funext fun f => ?_)
  · rw [active_answer]
    apply Subtype.ext
    show (vans st2 i q ω : ℝ) = min 1 (max 0 (dC st i q ω).answer)
    rw [vans_eq hc i q hω]
    have hmem := (dC st i q ω).answer_mem (clip01_mem _)
    rw [max_eq_right hmem.1, min_eq_right hmem.2]
  · cases f with
    | active => rfl
    | c1 =>
      rw [active_f_c1, vc1_eq hc i q hω]
      rfl
    | b r =>
      rw [active_f_b, vtrig_eq hc i q hω]
      rfl
    | uPrev r =>
      rw [active_f_uPrev, vtrig_eq hc i q hω, (vchain_corr hc i q hω r).1]
      rfl
    | released r =>
      rw [active_f_released, vrel_eq hc i q hω]
      rfl
    | v r =>
      rw [active_f_v, vrel_eq hc i q hω, vθ_eq hc q]
      show _ = if (dC st i q ω).Released r then (dC st i q ω).relV r else 0
      exact if_congr decide_eq_true_iff rfl rfl
    | c r =>
      rw [active_f_c, vrel_eq hc i q hω, vθ_eq hc q]
      show _ = if r = 1 then 0 else (if r = 1 then (dC st i q ω).c1 else
        if (dC st i q ω).Released r then (dC st i q ω).relC r else 0)
      by_cases hr : r = 1
      · subst hr
        have hR : ¬ (dC st i q ω).Released 1 := by
          rintro (h | ⟨h3, h2⟩)
          · exact absurd h.1 (by norm_num)
          · omega
        rw [if_pos rfl, if_neg (by simpa using hR)]
      · rw [if_neg hr, if_neg hr]
        exact if_congr decide_eq_true_iff rfl rfl
    | s =>
      rw [active_f_s, vs_eq hc i q hω]
      rfl
    | delta m =>
      rw [active_f_delta, vδ_eq hc i q hω]
      rfl
    | haltAfter =>
      rw [active_f_haltAfter, vhaltAfter_eq hc i q hω]
      exact if_congr decide_eq_true_iff rfl rfl

end CorrRound

/-- **One round.** From corresponding states, v2's round and A-ARCH's `step` (on the coins `φ ω`) produce
corresponding states, and v2's public output is the `toPublic` image of A-ARCH's record (on `Good`). -/
theorem round_corr (hα : 0 < α) {st2 : F2e2e.ADAState k α β} {st : MState k α β} (hc : Corr st2 st)
    (i : ℕ) (q : Fin (F2e2e.adaSampleSize k α β) → ℝ)
    {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ} (hω : Good ω) :
    Corr (F2e2e.adaRound st2 i q ω).1 (step st i q (coinMap k α ω)).1 ∧
      (F2e2e.adaRound st2 i q ω).2 = toPublic st (step st i q (coinMap k α ω)).2 := by
  cases hh : st.halt with
  | true =>
    have hh2 : st2.halt = true := hc.halt.trans hh
    have e1 : F2e2e.adaRound st2 i q ω = (st2, (F2e2e.clip01 0, fun _ => 0)) := by
      unfold F2e2e.adaRound
      rw [if_pos hh2]
    have e2 : step st i q (coinMap k α ω) = (st, RoundRec.halted) := step_of_halt hh i q _
    rw [e1, e2]
    refine ⟨hc, Prod.ext rfl (funext fun f => ?_)⟩
    cases f <;> simp [toPublic, toField, RoundRec.halted]
  | false =>
    have hh2 : st2.halt = false := hc.halt.trans hh
    have e1 : F2e2e.adaRound st2 i q ω = F2e2e.adaActiveRound st2 i q ω := by
      unfold F2e2e.adaRound
      rw [if_neg (by simp [hh2])]
    have e2 : step st i q (coinMap k α ω) = (st.next q (activeRec st i q (coinMap k α ω)),
        activeRec st i q (coinMap k α ω)) := step_of_not_halt hh i q _
    rw [e1, e2]
    exact ⟨active_corr hc i q hω hα, active_out hc i q hω⟩

/-- The initial states correspond. -/
theorem init_corr : Corr (F2e2e.ADAState.init : F2e2e.ADAState k α β) (MState.init : MState k α β) where
  halt := rfl
  t1 := rfl
  N := rfl
  M := rfl
  pay1 := fun ℓ => by simp [MState.init, F2e2e.ADAState.init]
  pay := fun _ _ _ => rfl
  P := fun r => by
    funext ℓ
    show 1 / (F2e2e.adaBlock k α β r : ℝ) = (MState.init : MState k α β).weight r ℓ
    unfold MState.weight
    split_ifs
    · rfl
    · have hn : 0 < adaBlock k α β r := lt_of_le_of_lt (Nat.zero_le _) ℓ.isLt
      rw [show (MState.init : MState k α β).pay r = fun _ => 0 from rfl, Opt.waterFill_zero hn]
      rfl

/-- **The run.** Along any query-value sequence, v2's states before each round correspond to A-ARCH's run
on the coins `φ ω` (on `Good`). -/
theorem run_corr (hα : 0 < α) {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ} (hω : Good ω)
    (qv : ℕ → Fin (F2e2e.adaSampleSize k α β) → ℝ) :
    ∀ i, Corr (F2e2e.adaStateBefore k α β qv ω i) (run k α β qv (coinMap k α ω) i)
  | 0 => init_corr
  | i + 1 => (round_corr hα (run_corr hα hω qv i) i (qv i) hω).1

/-- **The cascade.** On `Good`, the output of round `i` of v2's `adaCascade` is the `toPublic` image of
A-ARCH's record of round `i` (on the coins `φ ω`, the same query values). -/
theorem cascade_eq (hα : 0 < α) {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ} (hω : Good ω)
    (i : ℕ) (vals : Fin (i + 1) → Fin (F2e2e.adaSampleSize k α β) → ℝ) :
    F2e2e.adaCascade k α β i vals ω =
      toPublic (run k α β (extendVals vals) (coinMap k α ω) i)
        (roundRec k α β (extendVals vals) (coinMap k α ω) i) := by
  have h := (round_corr hα (run_corr hα hω (extendVals vals) i) i (vals (Fin.last i)) hω).2
  have hq : extendVals vals i = vals (Fin.last i) := by
    unfold extendVals
    rw [dif_pos (Nat.lt_succ_self i)]
    rfl
  have h2 : roundRec k α β (extendVals vals) (coinMap k α ω) i =
      (step (run k α β (extendVals vals) (coinMap k α ω) i) i (vals (Fin.last i)) (coinMap k α ω)).2 :=
    congrArg (fun q' => (step (run k α β (extendVals vals) (coinMap k α ω) i) i q' (coinMap k α ω)).2) hq
  exact h.trans (congrArg (toPublic (run k α β (extendVals vals) (coinMap k α ω) i)) h2.symm)

end Round

end

end F2e2e.A.V2Bridge
