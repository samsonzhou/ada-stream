import F2e2e.A.SimEpisode
import F2e2e.Lib.DP.AboveThreshold

/-!
# [SIM_r], one episode (continued): the actual episode is the forced episode at the AboveThreshold output

Paper: Part I, Prop. `I:prop:svt_episode_pure_dp` (`parts/partI.tex` L887-957), Step 1 ("condition on all randomness
external to `S_r`'s AboveThreshold noises so that `f_1, …, f_m` are fixed along the passing prefix") and Step 2 (the
episode-end scalar release).

Fix a validator stage `r ≥ 2`, the public noise `ω'`, an episode index `e` and a history `y` with
`e ≤ s := epCover y < k`. Along the **all-pass run** `passRun` (stage `r` forced to pass) we read off, for every
test `t` (round `s + t`): the origin and proposal `(u_t, c_t)` and the weighted mean `θ_t` of stage `r`, hence the
AboveThreshold query values `f_t = |c_t - θ_t| - τ_{(u_t, r)}` (`passF`), and the number `T` of tests of the episode
(`passT`). With `m = atOutput f T (ρ^{(r)}_e, ν^{(r)}_{s+·})` (`epAtOut`) and
`v = θ_end + ζ^{(r)}_{s+end}` (`epRelVal`, `end` the last test), the actual episode is the forced episode
`epOutF … m v` (`epMap_eq_epOutF`).
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

/-! ## Monotonicity of HALT and of the episode counter along the runs -/

section RunMono

variable {k : ℕ} {α β : ℝ} {X : Type}

theorem recAt_setRec_self {h : Fin k → RoundRec} {i : ℕ} (hi : i < k) (rec : RoundRec) :
    recAt (setRec h i rec) i = rec := by
  unfold recAt setRec
  rw [dif_pos hi, if_pos rfl]

theorem recAt_setRec_of_ne {h : Fin k → RoundRec} {i j : ℕ} (hij : j ≠ i) (rec : RoundRec) :
    recAt (setRec h i rec) j = recAt h j := by
  unfold recAt
  split_ifs with hj
  · exact setRec_of_lt rec (show (⟨j, hj⟩ : Fin k).val ≠ i from hij)
  · rfl

theorem step_M (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α)
    {r : ℕ} (hr : 2 ≤ r) :
    (step st i q ω).1.M r = st.M r + if r ≤ (step st i q ω).2.ufinal then 1 else 0 := by
  cases hh : st.halt
  · rw [step_of_not_halt hh]
    show st.M r + (if 2 ≤ r ∧ r ≤ (activeRec st i q ω).ufinal then 1 else 0) = _
    simp only [hr, true_and]
  · rw [step_of_halt hh]
    have h0 : ¬ r ≤ RoundRec.halted.ufinal := by rw [RoundRec.halted_ufinal]; omega
    dsimp only
    rw [if_neg h0, add_zero]

theorem stepF_M (r : ℕ) (hr : 2 ≤ r) (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (b : Bool) (v : ℝ) :
    (stepF r st i q ω b v).1.M r = st.M r + if r ≤ (stepF r st i q ω b v).2.ufinal then 1 else 0 := by
  cases hh : st.halt
  · rw [stepF_of_not_halt r hh]
    show st.M r + (if 2 ≤ r ∧ r ≤ _ then 1 else 0) = _
    simp only [hr, true_and]
  · rw [stepF_of_halt r hh]
    have h0 : ¬ r ≤ RoundRec.halted.ufinal := by rw [RoundRec.halted_ufinal]; omega
    dsimp only
    rw [if_neg h0, add_zero]

theorem contRun_M_succ (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (t : ℕ) {r : ℕ} (hr : 2 ≤ r) (hst : s + t < k) :
    (contRun A S ω s st₀ h₀ (t + 1)).1.M r = (contRun A S ω s st₀ h₀ t).1.M r +
      if r ≤ (recAt (contRun A S ω s st₀ h₀ (t + 1)).2 (s + t)).ufinal then 1 else 0 := by
  rw [contRun_succ]
  unfold contStep
  dsimp only
  rw [recAt_setRec_self hst, step_M _ _ _ _ hr]

theorem contRunF_M_succ (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (hr : 2 ≤ r) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) (t : ℕ)
    (hst : s + t < k) :
    (contRunF A S ω r s st₀ h₀ m v (t + 1)).1.M r = (contRunF A S ω r s st₀ h₀ m v t).1.M r +
      if r ≤ (recAt (contRunF A S ω r s st₀ h₀ m v (t + 1)).2 (s + t)).ufinal then 1 else 0 := by
  rw [contRunF_succ]
  unfold contStepF
  dsimp only
  rw [recAt_setRec_self hst, stepF_M r hr]

theorem contRun_halt_mono (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) {t t' : ℕ} (htt : t ≤ t')
    (h : (contRun A S ω s st₀ h₀ t).1.halt = true) : (contRun A S ω s st₀ h₀ t').1.halt = true := by
  induction t', htt using Nat.le_induction with
  | base => exact h
  | succ n hn ih =>
    rw [contRun_succ]
    unfold contStep
    dsimp only
    rw [step_of_halt ih]
    exact ih

theorem contRunF_halt_mono (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) {t t' : ℕ} (htt : t ≤ t')
    (h : (contRunF A S ω r s st₀ h₀ m v t).1.halt = true) :
    (contRunF A S ω r s st₀ h₀ m v t').1.halt = true := by
  induction t', htt using Nat.le_induction with
  | base => exact h
  | succ n hn ih =>
    rw [contRunF_succ]
    unfold contStepF
    dsimp only
    rw [stepF_of_halt r ih]
    exact ih

theorem contRunF_M_mono (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (r s : ℕ) (hr : 2 ≤ r) (st₀ : MState k α β) (h₀ : Fin k → RoundRec) (m : ℕ) (v : ℝ) {t t' : ℕ}
    (htt : t ≤ t') : (contRunF A S ω r s st₀ h₀ m v t).1.M r ≤ (contRunF A S ω r s st₀ h₀ m v t').1.M r := by
  induction t', htt using Nat.le_induction with
  | base => exact le_rfl
  | succ n hn ih =>
    refine le_trans ih ?_
    rw [contRunF_succ]
    unfold contStepF
    dsimp only
    rw [stepF_M r hr]
    exact Nat.le_add_right _ _

end RunMono

/-! ## The all-pass run of an episode and its AboveThreshold data -/

section Pass

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- The all-pass run of episode `e` (stage `r` forced to pass, release value `0`), with the public noise `ω'`. -/
noncomputable def passRun (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (t : ℕ) : MState k α β × (Fin k → RoundRec) :=
  contRunF A S ω' r (epCover y) (epStart A S r e (epPick e y) (epCover y)) (epPick e y) k 0 t

/-- The chain data of round `epCover y + t` of the all-pass run. -/
noncomputable def passChain (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (t : ℕ) : ChainData :=
  roundChain (passRun A S r ω' e y t).1 (epCover y + t)
    (qOf A S (passRun A S r ω' e y t).2 (epCover y + t)) ω'

/-- The weighted mean `θ^{(r)}` of stage `r` at test `t` of the episode. -/
noncomputable def passTheta (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (t : ℕ) : ℝ :=
  (passChain A S r ω' e y t).theta r

/-- The AboveThreshold query value of test `t`: `f_t = |c^{(u_t)} - θ_t| - τ_{(u_t, r)}`. -/
noncomputable def passF (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (j : Fin (k - epCover y)) : ℝ :=
  |((passChain A S r ω' e y j).orig r).2 - passTheta A S r ω' e y j| -
    adaTau α ((passChain A S r ω' e y j).orig r).1 r

/-- Test `t` of the episode takes place: round `s + t` exists, is active, and stage `r` has not reset yet. -/
def PassActive (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (t : ℕ) : Prop :=
  epCover y + t < k ∧ (passRun A S r ω' e y t).1.halt = false ∧ (passRun A S r ω' e y t).1.M r = e + 1

open Classical in
/-- The number of tests of the episode along the all-pass prefix. -/
noncomputable def passT (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) : ℕ :=
  ((Finset.range (k - epCover y)).filter (PassActive A S r ω' e y)).card

/-- The AboveThreshold output of the episode. -/
noncomputable def epAtOut (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (ω : AdaOmega k α) : ℕ :=
  DP.atOutput (passF A S r ω' e y) (passT A S r ω' e y)
    (noiseRho ω r e, fun j : Fin (k - epCover y) => noiseNu ω (epCover y + j) r)

/-- The last test of the episode. -/
noncomputable def epAtEnd (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (ω : AdaOmega k α) : ℕ :=
  if epAtOut A S r ω' e y ω < passT A S r ω' e y then epAtOut A S r ω' e y ω else passT A S r ω' e y - 1

/-- The release value of the episode: `θ_end + ζ^{(r)}_{s + end}`. -/
noncomputable def epRelVal (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (ω : AdaOmega k α) : ℝ :=
  passTheta A S r ω' e y (epAtEnd A S r ω' e y ω) + noiseZeta ω (epCover y + epAtEnd A S r ω' e y ω) r

/-- The forced episode: stage `r` fires at the round offset `m` with release value `v`. -/
noncomputable def epOutF (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (m : ℕ) (v : ℝ) : EpRec k :=
  epMask r (epCover y)
    (contRunF A S ω' r (epCover y) (epStart A S r e (epPick e y) (epCover y)) (epPick e y) m v
      (k - epCover y)).2

theorem passActive_mono (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr : 2 ≤ r)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) {t t' : ℕ} (htt : t' ≤ t)
    (ht : PassActive A S r ω' e y t) : PassActive A S r ω' e y t' := by
  obtain ⟨h1, h2, h3⟩ := ht
  refine ⟨by omega, ?_, ?_⟩
  · cases hh : (passRun A S r ω' e y t').1.halt
    · rfl
    · have := contRunF_halt_mono A S ω' r _ _ _ k 0 htt hh
      unfold passRun at h2
      rw [h2] at this
      exact absurd this (by decide)
  · have hle := contRunF_M_mono A S ω' r (epCover y) hr (epStart A S r e (epPick e y) (epCover y))
      (epPick e y) k 0 htt
    have hge := contRunF_M_mono A S ω' r (epCover y) hr (epStart A S r e (epPick e y) (epCover y))
      (epPick e y) k 0 (Nat.zero_le t')
    have h0 : (epStart A S r e (epPick e y) (epCover y)).M r = e + 1 := by
      unfold epStart
      simp
    unfold passRun at h3 ⊢
    rw [contRunF_zero] at hge
    simp only at hge
    omega

theorem lt_passT_iff (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr : 2 ≤ r)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) {t : ℕ} (htK : t < k - epCover y) :
    t < passT A S r ω' e y ↔ PassActive A S r ω' e y t := by
  classical
  unfold passT
  constructor
  · intro ht
    by_contra hP
    have hsub : ((Finset.range (k - epCover y)).filter (PassActive A S r ω' e y)) ⊆ Finset.range t := by
      intro j hj
      rw [Finset.mem_filter] at hj
      rw [Finset.mem_range]
      by_contra hjt
      exact hP (passActive_mono A S hr ω' e y (not_lt.1 hjt) hj.2)
    have := Finset.card_le_card hsub
    rw [Finset.card_range] at this
    convert absurd ht (not_lt.2 this) using 0
  · intro hP
    have hsub : Finset.range (t + 1) ⊆ ((Finset.range (k - epCover y)).filter (PassActive A S r ω' e y)) := by
      intro j hj
      rw [Finset.mem_range] at hj
      rw [Finset.mem_filter, Finset.mem_range]
      exact ⟨by omega, passActive_mono A S hr ω' e y (by omega) hP⟩
    have := Finset.card_le_card hsub
    rw [Finset.card_range] at this
    convert this using 0
    exact Iff.intro (fun h => by omega) (fun h => by omega)

theorem passT_le (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (r : ℕ)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) : passT A S r ω' e y ≤ k - epCover y := by
  classical
  unfold passT
  exact (Finset.card_filter_le _ _).trans (by rw [Finset.card_range])

end Pass

/-! ## Identification of the actual test with the AboveThreshold test -/

section Ident

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- At a round of the episode where the actual state and records are those of the all-pass run, stage `r`'s
actual test is the AboveThreshold test of `passF` with threshold `ρ^{(r)}_e` and query noise `ν^{(r)}_{s+t}`, and its
release value is `θ_t + ζ^{(r)}_{s+t}`. -/
theorem stage_fires_iff_at (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr2 : 2 ≤ r)
    (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (ω : AdaOmega k α) (t : ℕ)
    (htK : t < k - epCover y) (p : MState k α β × (Fin k → RoundRec))
    (hp : p = passRun A S r ω' e y t) (hM : p.1.M r = e + 1) :
    ((roundChain p.1 (epCover y + t) (qOf A S p.2 (epCover y + t)) (mixNoise r ω ω')).stageFires r = true ↔
      DP.ATTriggers (passF A S r ω' e y)
        (noiseRho ω r e, fun j : Fin (k - epCover y) => noiseNu ω (epCover y + j) r) t) ∧
    (roundChain p.1 (epCover y + t) (qOf A S p.2 (epCover y + t)) (mixNoise r ω ω')).relV r =
      passTheta A S r ω' e y t + noiseZeta ω (epCover y + t) r := by
  set d := roundChain p.1 (epCover y + t) (qOf A S p.2 (epCover y + t)) (mixNoise r ω ω') with hd
  set dp := passChain A S r ω' e y t with hdp
  have hdp' : dp = roundChain p.1 (epCover y + t) (qOf A S p.2 (epCover y + t)) ω' := by
    rw [hdp, hp]
    rfl
  -- the fields of `d` and `dp` agree away from stage `r`
  have hrho : ∀ t', t' ≠ r → d.rho t' = dp.rho t' := fun t' ht' => by
    rw [hdp']
    show noiseRho (mixNoise r ω ω') t' (p.1.M t' - 1) = noiseRho ω' t' (p.1.M t' - 1)
    rw [noiseRho_mixNoise, if_neg ht']
  have hnu : ∀ t', t' ≠ r → d.nu t' = dp.nu t' := fun t' ht' => by
    rw [hdp']
    show noiseNu (mixNoise r ω ω') (epCover y + t) t' = noiseNu ω' (epCover y + t) t'
    rw [noiseNu_mixNoise, if_neg ht']
  have hzeta : ∀ t', t' ≠ r → d.zeta t' = dp.zeta t' := fun t' ht' => by
    rw [hdp']
    show noiseZeta (mixNoise r ω ω') (epCover y + t) t' = noiseZeta ω' (epCover y + t) t'
    rw [noiseZeta_mixNoise, if_neg ht']
  have htheta : ∀ t', d.theta t' = dp.theta t' := fun t' => by rw [hdp']; rfl
  have hc1 : d.c1 = dp.c1 := by
    rw [hdp']
    show clip01 (stage1Release p.1 (epCover y + t) _ (mixNoise r ω ω')) =
      clip01 (stage1Release p.1 (epCover y + t) _ ω')
    unfold stage1Release
    rw [noiseBeta_mixNoise (by omega)]
  have hL : d.L = dp.L := by rw [hdp']; rfl
  have htau : d.tau = dp.tau := by rw [hdp']; rfl
  have horig : d.orig r = dp.orig r := by
    refine ChainData.orig_congr_sim (s := r) hL hc1 fun t' ht' => ⟨?_, ?_⟩
    · unfold ChainData.Fires
      rw [htau, htheta, hrho t' (by omega), hnu t' (by omega)]
    · unfold ChainData.relC ChainData.relV
      rw [htheta, hzeta t' (by omega)]
  have hdrho : d.rho r = noiseRho ω r e := by
    show noiseRho (mixNoise r ω ω') r (p.1.M r - 1) = _
    rw [noiseRho_mixNoise, if_pos rfl, hM]
    rfl
  have hdnu : d.nu r = noiseNu ω (epCover y + t) r := by
    show noiseNu (mixNoise r ω ω') (epCover y + t) r = _
    rw [noiseNu_mixNoise, if_pos rfl]
  have hdzeta : d.zeta r = noiseZeta ω (epCover y + t) r := by
    show noiseZeta (mixNoise r ω ω') (epCover y + t) r = _
    rw [noiseZeta_mixNoise, if_pos rfl]
  have hdtau : d.tau = adaTau α := rfl
  refine ⟨?_, ?_⟩
  · unfold ChainData.stageFires
    rw [decide_eq_true_iff]
    unfold ChainData.Fires DP.ATTriggers
    rw [horig, hdrho, hdnu, hdtau, htheta r]
    constructor
    · intro h
      refine ⟨⟨t, htK⟩, rfl, ?_⟩
      change noiseRho ω r e ≤ |(dp.orig r).2 - dp.theta r| - adaTau α (dp.orig r).1 r +
        noiseNu ω (epCover y + t) r
      linarith
    · rintro ⟨j, hj, hle⟩
      have hj' : j = ⟨t, htK⟩ := Fin.ext hj
      subst hj'
      change noiseRho ω r e ≤ |(dp.orig r).2 - dp.theta r| - adaTau α (dp.orig r).1 r +
        noiseNu ω (epCover y + t) r at hle
      linarith
  · unfold ChainData.relV passTheta
    rw [hdzeta, htheta r]

end Ident


/-! ## The decomposition of the episode -/

section Decomp

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- **The episode is the forced episode at the AboveThreshold output** (Prop. `I:prop:svt_episode_pure_dp`, the
reduction behind Steps 1-2): for a history with `e ≤ s = epCover y < k`, the `e`-th episode of stage `r` equals
`epOutF … m v` with `m` the AboveThreshold output on the all-pass test values and `v` the release at the last
test. -/
theorem epMap_eq_epOutF (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) {r : ℕ} (hr2 : 2 ≤ r)
    (hrL : r ≤ adaL α) (ω' : AdaOmega k α) (e : ℕ) (y : Fin e → EpRec k) (hes : e ≤ epCover y)
    (hsk : epCover y < k) (ω : AdaOmega k α) :
    epMap A S r ω' e y ω = epOutF A S r ω' e y (epAtOut A S r ω' e y ω) (epRelVal A S r ω' e y ω) := by
  set s := epCover y with hs
  set h₀ := epPick e y with hh₀
  set st₀ := epStart A S r e h₀ s with hst₀
  set m := epAtOut A S r ω' e y ω with hm
  set v := epRelVal A S r ω' e y ω with hv
  set T := passT A S r ω' e y with hT
  set ρν : DP.ATNoise (k - s) := (noiseRho ω r e, fun j : Fin (k - s) => noiseNu ω (s + j) r) with hρν
  set ω₁ := mixNoise r ω ω' with hω₁
  have hmix : ∀ j : NoiseIdx k (adaL α), j.stage ≠ r → ω₁ j = ω' j :=
    fun j hj => mixNoise_of_not_stage r ω ω' j hj
  have hM0 : st₀.M r = e + 1 := by
    rw [hst₀]
    unfold epStart
    simp
  set R : ℕ → MState k α β × (Fin k → RoundRec) := fun t => contRun A S ω₁ s st₀ h₀ t with hR
  set F : ℕ → MState k α β × (Fin k → RoundRec) := fun t => contRunF A S ω₁ r s st₀ h₀ m v t with hF
  set P : ℕ → MState k α β × (Fin k → RoundRec) := fun t => contRunF A S ω₁ r s st₀ h₀ k 0 t with hP
  have hPp : ∀ t, P t = passRun A S r ω' e y t := fun t =>
    contRunF_noise_congr A S hr2 hmix s st₀ h₀ k 0 t
  -- the AboveThreshold output
  have hmT : m ≤ T := DP.atOutput_le _ _ _
  have hbefore : ∀ t < m, ¬ DP.ATTriggers (passF A S r ω' e y) ρν t := by
    intro t htm
    by_cases hmT' : m < T
    · exact ((DP.atOutput_eq_of_lt (passF A S r ω' e y) hmT' ρν).1 rfl).2 t htm
    · have hmeq : m = T := le_antisymm hmT (not_lt.1 hmT')
      exact (DP.atOutput_eq_self (passF A S r ω' e y) T ρν).1 hmeq t (by omega)
  have hat : m < T → DP.ATTriggers (passF A S r ω' e y) ρν m := fun h =>
    ((DP.atOutput_eq_of_lt (passF A S r ω' e y) h ρν).1 rfl).1
  -- one step of each run
  have hRstep : ∀ t, R (t + 1) = contStepF A S ω₁ r (s + t)
      ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r)
      ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r) (R t) := by
    intro t
    show contStep A S ω₁ (s + t) (R t) = _
    unfold contStep contStepF
    rw [step_eq_stepF r]
  have hFstep : ∀ t, F (t + 1) = contStepF A S ω₁ r (s + t) (decide (t = m)) v (F t) := fun t => rfl
  have hPstep : ∀ t, P (t + 1) = contStepF A S ω₁ r (s + t) (decide (t = k)) 0 (P t) := fun t => rfl
  have hcongr : ∀ (i : ℕ) (p : MState k α β × (Fin k → RoundRec)) (b₁ b₂ : Bool) (v₁ v₂ : ℝ),
      stepF r p.1 i (qOf A S p.2 i) ω₁ b₁ v₁ = stepF r p.1 i (qOf A S p.2 i) ω₁ b₂ v₂ →
      contStepF A S ω₁ r i b₁ v₁ p = contStepF A S ω₁ r i b₂ v₂ p := by
    intro i p b₁ b₂ v₁ v₂ h
    unfold contStepF
    rw [h]
  -- the reset predicate on the actual run
  set NoRes : ℕ → Prop := fun t => ∀ t' < t, ¬ r ≤ (recAt (R (t' + 1)).2 (s + t')).ufinal with hNoRes
  -- the episode counter of the actual run before a reset
  have hMR : ∀ t, s + t ≤ k → NoRes t → (R t).1.M r = e + 1 := by
    intro t
    induction t with
    | zero => intro _ _; exact hM0
    | succ t ih =>
      intro hst hno
      have h1 := contRun_M_succ A S ω₁ s st₀ h₀ t hr2 (by omega : s + t < k)
      have h2 : ¬ r ≤ (recAt (R (t + 1)).2 (s + t)).ufinal := hno t (by omega)
      show (contRun A S ω₁ s st₀ h₀ (t + 1)).1.M r = e + 1
      rw [h1, if_neg h2, add_zero]
      exact ih (by omega) (fun t' ht' => hno t' (by omega))
  -- the halting flag is monotone along the actual run
  have hRhalt : ∀ t t', t ≤ t' → (R t).1.halt = true → (R t').1.halt = true := fun t t' htt h =>
    contRun_halt_mono A S ω₁ s st₀ h₀ htt h
  -- identification of the actual test when the actual run is the all-pass run
  have hident : ∀ t, t < k - s → R t = P t → (R t).1.M r = e + 1 →
      ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r = true ↔
        DP.ATTriggers (passF A S r ω' e y) ρν t) ∧
      (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r =
        passTheta A S r ω' e y t + noiseZeta ω (s + t) r := fun t htK hRP hMt =>
    stage_fires_iff_at A S hr2 ω' e y ω t htK (R t) (by rw [hRP, hPp]) hMt
  -- an active test of the actual run (identical to the pass run) is a test of the episode
  have hactive : ∀ t, t < k - s → R t = P t → (R t).1.halt = false → (R t).1.M r = e + 1 → t < T := by
    intro t htK hRP hh hMt
    refine (lt_passT_iff A S hr2 ω' e y htK).2 ⟨by omega, ?_, ?_⟩
    · rw [← hPp, ← hRP]
      exact hh
    · rw [← hPp, ← hRP]
      exact hMt
  -- (1) the actual run is the all-pass run up to the trigger
  have hRP : ∀ t, t ≤ m → t ≤ k - s → NoRes t → R t = P t := by
    intro t
    induction t with
    | zero => intro _ _ _; rfl
    | succ t ih =>
      intro htm htK hno
      have hno' : NoRes t := fun t' ht' => hno t' (by omega)
      have hRPt := ih (by omega) (by omega) hno'
      rw [hRstep t, hPstep t, ← hRPt]
      apply hcongr
      cases hh : (R t).1.halt
      · have hMt := hMR t (by omega) hno'
        obtain ⟨hf, -⟩ := hident t (by omega) hRPt hMt
        have hfalse : (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r = false := by
          cases hb : (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r
          · rfl
          · exact absurd (hf.1 hb) (hbefore t (by omega))
        rw [hfalse, decide_eq_false (show ¬ t = k by omega)]
        apply stepF_false_congr
        -- no reset at round `s + t`
        have hnr := hno t (by omega)
        intro hu
        apply hnr
        show r ≤ (recAt (contRun A S ω₁ s st₀ h₀ (t + 1)).2 (s + t)).ufinal
        rw [contRun_succ]
        unfold contStep
        dsimp only
        rw [recAt_setRec_self (by omega), step_eq_stepF r, hfalse, stepF_of_not_halt r hh]
        dsimp only
        show r ≤ ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).force r false _).ufinal
        rw [hu]
        omega
      · rw [stepF_of_halt r hh, stepF_of_halt r hh]
  -- (2) every test before a non-halted round lies before the trigger
  have hmle : ∀ t, t ≤ k - s → NoRes t → (R t).1.halt = false → t ≤ m := by
    intro t htK hno hh
    by_contra hlt
    rw [not_le] at hlt
    have hnom : NoRes m := fun t' ht' => hno t' (by omega)
    have hRPm := hRP m le_rfl (by omega) hnom
    have hhm : (R m).1.halt = false := by
      cases hhm : (R m).1.halt
      · rfl
      · have := hRhalt m t hlt.le hhm
        rw [hh] at this
        exact absurd this (by decide)
    have hMm := hMR m (by omega) hnom
    have hmT' : m < T := hactive m (by omega) hRPm hhm hMm
    obtain ⟨hf, -⟩ := hident m (by omega) hRPm hMm
    have htrue := hf.2 (hat hmT')
    -- the actual round `s + m` resets stage `r`
    apply hno m hlt
    show r ≤ (recAt (contRun A S ω₁ s st₀ h₀ (m + 1)).2 (s + m)).ufinal
    rw [contRun_succ]
    unfold contStep
    dsimp only
    rw [recAt_setRec_self (by omega), step_eq_stepF r, htrue, stepF_of_not_halt r hhm]
    dsimp only
    show r ≤ ((roundChain (R m).1 (s + m) (qOf A S (R m).2 (s + m)) ω₁).force r true _).ufinal
    apply ChainData.le_ufinal_of_trig
    rw [ChainData.force_trig]
    exact ⟨hr2, hrL, rfl⟩
  -- (3) one more step of the actual run and of the forced run agree
  have hE : ∀ t, t < k - s → NoRes t → R t = F t → R (t + 1) = F (t + 1) := by
    intro t htK hno hRF
    rw [hRstep t, hFstep t, ← hRF]
    apply hcongr
    cases hh : (R t).1.halt
    · have htm := hmle t htK.le hno hh
      have hRPt := hRP t htm htK.le hno
      have hMt := hMR t (by omega) hno
      have htT := hactive t htK hRPt hh hMt
      obtain ⟨hf, hrel⟩ := hident t htK hRPt hMt
      rcases Nat.lt_or_ge t m with htm' | htm'
      · -- before the trigger: stage `r` passes
        have hfalse : (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r = false := by
          cases hb : (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).stageFires r
          · rfl
          · exact absurd (hf.1 hb) (hbefore t htm')
        rw [hfalse, decide_eq_false (show ¬ t = m by omega)]
        by_cases hres : r ≤ ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).force r false
            ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r)).ufinal
        · -- an external reset: this is the last test, and `v` is its release
          have hPres : r ≤ (recAt (P (t + 1)).2 (s + t)).ufinal := by
            show r ≤ (recAt (contRunF A S ω₁ r s st₀ h₀ k 0 (t + 1)).2 (s + t)).ufinal
            rw [contRunF_succ]
            unfold contStepF
            dsimp only
            rw [recAt_setRec_self (by omega),
              show contRunF A S ω₁ r s st₀ h₀ k 0 t = R t from hRPt.symm,
              decide_eq_false (show ¬ t = k by omega), stepF_of_not_halt r hh]
            dsimp only
            show r ≤ ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).force r false 0).ufinal
            rw [ChainData.force_false_ufinal _ r 0
              ((roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r)]
            exact hres
          have hMP : (P (t + 1)).1.M r = e + 2 := by
            have h1 := contRunF_M_succ A S ω₁ r s hr2 st₀ h₀ k 0 t (by omega)
            have h2 : (P t).1.M r = e + 1 := by rw [← hRPt]; exact hMt
            show (contRunF A S ω₁ r s st₀ h₀ k 0 (t + 1)).1.M r = e + 2
            rw [h1, if_pos hPres]
            show (P t).1.M r + 1 = e + 2
            rw [h2]
          have hTle : T ≤ t + 1 := by
            by_contra hTlt
            rw [not_le] at hTlt
            have := (lt_passT_iff A S hr2 ω' e y (show t + 1 < k - s by
              have := passT_le A S r ω' e y
              omega)).1 hTlt
            have h3 := this.2.2
            rw [← hPp] at h3
            omega
          have hmeq : m = T := by omega
          have hend : epAtEnd A S r ω' e y ω = t := by
            unfold epAtEnd
            rw [← hm, ← hT, if_neg (by omega)]
            omega
          have hvt : v = (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r := by
            rw [hv, hrel]
            unfold epRelVal
            rw [hend]
          rw [hvt]
        · exact stepF_false_congr r _ _ _ _ _ _ (fun hu => hres (by rw [hu]; omega))
      · -- the trigger
        have htm'' : t = m := le_antisymm htm htm'
        have htrue := hf.2 (by rw [htm'']; exact hat (by omega))
        rw [htrue, decide_eq_true htm'']
        have hend : epAtEnd A S r ω' e y ω = t := by
          unfold epAtEnd
          rw [← hm, ← hT, if_pos (by omega)]
          exact htm''.symm
        have hvt : v = (roundChain (R t).1 (s + t) (qOf A S (R t).2 (s + t)) ω₁).relV r := by
          rw [hv, hrel]
          unfold epRelVal
          rw [hend]
        rw [hvt]
    · rw [stepF_of_halt r hh, stepF_of_halt r hh]
  -- (4) hence the actual and forced runs agree on the episode
  have hD : ∀ t, t ≤ k - s → NoRes t → R t = F t := by
    intro t
    induction t with
    | zero => intro _ _; rfl
    | succ t ih =>
      intro htK hno
      have hno' : NoRes t := fun t' ht' => hno t' (by omega)
      exact hE t (by omega) hno' (ih (by omega) hno')
  -- (5) the masks agree
  have hepMap : epMap A S r ω' e y ω = epMask r s (R (k - s)).2 := by
    unfold epMap
    rw [if_pos hes]
  have hepOut : epOutF A S r ω' e y m v = epMask r s (F (k - s)).2 := by
    show epMask r s (contRunF A S ω' r s st₀ h₀ m v (k - s)).2 = _
    rw [← contRunF_noise_congr A S hr2 hmix s st₀ h₀ m v (k - s)]
  rw [hepMap, hepOut]
  refine epMask_congr fun i hi => ?_
  obtain ⟨hsi, hno⟩ := hi
  set t := i.val - s with ht
  have hit : i.val = s + t := by omega
  have htK : t < k - s := by have := i.isLt; omega
  have hNoRes : NoRes t := by
    intro t' ht'
    have hlt : s + t' < k := by omega
    have := hno ⟨s + t', hlt⟩ (by simp) (by rw [Fin.lt_def]; simp; omega)
    rwa [show (R (k - s)).2 ⟨s + t', hlt⟩ = (R (t' + 1)).2 ⟨s + t', hlt⟩ from
      contRun_rec_stable A S ω₁ s st₀ h₀ (show t' + 1 ≤ k - s by omega) _ (by simp),
      ← show recAt (R (t' + 1)).2 (s + t') = (R (t' + 1)).2 ⟨s + t', hlt⟩ by
        unfold recAt
        rw [dif_pos hlt]] at this
  have hstep := hE t htK hNoRes (hD t htK.le hNoRes)
  have h1 : (R (k - s)).2 i = (R (t + 1)).2 i :=
    contRun_rec_stable A S ω₁ s st₀ h₀ (show t + 1 ≤ k - s by omega) i (by omega)
  have h2 : (F (k - s)).2 i = (F (t + 1)).2 i :=
    contRunF_rec_stable A S ω₁ r s st₀ h₀ m v (show t + 1 ≤ k - s by omega) i (by omega)
  rw [h1, h2, hstep]

end Decomp

end A

end F2e2e
