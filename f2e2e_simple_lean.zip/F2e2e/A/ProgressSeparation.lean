import F2e2e.A.Progress

/-!
# Part I §4: the separations of Lemma `I:lem:rl2_coupled_progress` on the transcript

Owner: A-ACC. Paper: `parts/partI.tex` Remark `I:rem:prog_m_measurability` (L1352-1363, first claim) and
Lemma `I:lem:rl2_coupled_progress`(2)-(4) (L1392-1422), stated on the public records of the transcript
`h = transcript k α β A z.1 z.2` (the chain-level forms are in `F2e2e/A/AccuracyCore.lean` and
`F2e2e/A/AccuracyRound.lean`; the progress bounds themselves are in `F2e2e/A/Progress.lean`).

## Main results
* `caseB_of_delta_ne_zero`: `δ_{m,i} ≠ 0` (`m ≥ 2`) only in an active Case-B round with `m ∈ {r' - 1, r'}`.
* `coupled_progress_separation` (I.4.5(2)): `|c_i^{(u_prev)} - c_i^{(r')}| ≥ τ_{(u_prev,r')} - 4u₀`
  (`I:eq:sec4_4u0_trigger_lb`), `|c_i^{(u_prev)} - c_i^{(r'-1)}| ≤ τ_{(u_prev,r'-1)} + 4u₀` if
  `u_prev < r' - 1` (`I:eq:sec4_4u0_pass_ub`), and `c_i^{(u_prev)} = c_i^{(r'-1)}` if `u_prev = r' - 1`.
* `coupled_progress_adj_gap` (I.4.5(3), `I:eq:sec4_interior_adj_gap`):
  `s_{i,r'}(c_i^{(r'-1)} - c_i^{(r')}) ≥ 2γ - 8u₀ = 28γ/16`.
* `coupled_progress_terminal_gap` (I.4.5(4), `I:eq:sec4_terminal_adj_gap`):
  `s_{i,L}(c_i^{(L-1)} - μ_i) ≥ 2γ - 11u₀ = 53γ/32`.
* `coupled_progress_mu_cancel` (I.4.5(3), `I:eq:sec4_linear_mu_cancel` with the deductions): for an
  interior Case-B round, `∑_{m=2}^{L-1} Prog_{m,i}(h) = w_{r'-1}γ s_{i,r'}(c_i^{(r'-1)} - c_i^{(r')})
  - w_{r'-1}η² - w_{r'}η̃_{r'}² - 2 w_{r'-1}γ u₀` (no `μ_i` on the right).
* `deduction_primary` (`I:eq:sec4_deduction_primary`), `deduction_reaction`
  (`I:eq:sec4_deduction_reaction`): the quadratic-stability and noise-conversion deductions.
* Also (I.4.A, I.4.1(ii) on the transcript): `sec4_u0_gamma_relations` (`I:eq:sec4_u0_gamma_relations`),
  `output_pass_bound` (`I:eq:sec4_upper_pass_bound`), `output_thetaL_bound` (`I:eq:sec4_ai_minus_thetaL`).
-/

namespace F2e2e

namespace A

open MeasureTheory

namespace ChainData

theorem toRec_uprev (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (r : ℕ) :
    (d.toRec eta1 eta etaT).uprev r = d.uprev r :=
  rfl

theorem two_le_of_released {d : ChainData} {r : ℕ} (h : d.Released r) : 2 ≤ r := by
  rcases h with hT | ⟨_, hr⟩
  · exact d.two_le_of_trig hT
  · omega

theorem toRec_c_of_released (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) {r : ℕ}
    (h : d.Released r) : (d.toRec eta1 eta etaT).c r = d.relC r := by
  have := two_le_of_released h
  rw [toRec_c, if_neg (show ¬ (r = 1) by omega), if_pos h]

/-- The recorded proposal of the origin `u_prev(r)` is the proposal `c^{(u_prev(r))}` tested by stage `r`:
`c₁` if `u_prev(r) = 1`, the release of the triggered stage `u_prev(r) ≥ 2` otherwise. -/
theorem toRec_c_uprev (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) (r : ℕ) :
    (d.toRec eta1 eta etaT).c (d.uprev r) = d.cprev r := by
  rcases Nat.lt_or_ge (d.uprev r) 2 with h | h
  · have h1 : d.uprev r = 1 := by
      have := d.one_le_uprev r
      omega
    rw [h1, toRec_c, if_pos rfl, d.cprev_of_uprev_eq_one h1]
  · obtain ⟨hc, hT⟩ := d.cprev_of_two_le_uprev h
    rw [toRec_c, if_neg (show ¬ (d.uprev r = 1) by omega),
      if_pos (show d.Released (d.uprev r) from Or.inl hT), hc]

end ChainData

section Sep

variable {X : Type} {k : ℕ} {α β : ℝ}

/-- Remark `I:rem:prog_m_measurability` (first claim): if `δ_{m,i} ≠ 0` for a validator level `m ≥ 2`,
then round `i` is an active Case-B round with `u_final = r' ≥ 3` and `m ∈ {r' - 1, r'}` (and then
`c_i^{(m)}` is recorded, `rel_of_delta_ne_zero`). -/
theorem caseB_of_delta_ne_zero (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) {m : ℕ} (hm : 2 ≤ m)
    (hδ : (transcript k α β A S ω i).delta m ≠ 0) :
    (transcript k α β A S ω i).active = true ∧ 3 ≤ (transcript k α β A S ω i).ufinal ∧
      (m + 1 = (transcript k α β A S ω i).ufinal ∨ m = (transcript k α β A S ω i).ufinal) := by
  cases h : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i h] at hδ
    exact absurd rfl hδ
  · refine ⟨rfl, ?_⟩
    rw [transcript_of_active A S ω i h] at hδ ⊢
    rw [ChainData.toRec_ufinal]
    rw [ChainData.toRec_delta] at hδ
    by_cases hu : (onlineChain k α β A S ω i).ufinal ≤ 2
    · exact absurd (ChainData.delta_eq_zero_of_ufinal_le_two hu hm _ _ _) hδ
    · have hB : 3 ≤ (onlineChain k α β A S ω i).ufinal := by omega
      refine ⟨hB, ?_⟩
      rw [ChainData.delta_caseB hB] at hδ
      split_ifs at hδ with h1 h2
      · exact Or.inl h1
      · exact Or.inr h2
      · exact absurd rfl hδ

/-- Lemma `I:lem:rl2_coupled_progress`(2), the exact `4u₀` trigger/pass separation, on `E_lap` (a fortiori on
`E_clean`): in a Case-B round with `u_final = r' ≥ 3` and `u_prev = u_prev(r')`,
`|c_i^{(u_prev)} - c_i^{(r')}| ≥ τ_{(u_prev,r')} - 4u₀` (`I:eq:sec4_4u0_trigger_lb`); if `u_prev < r' - 1`,
`|c_i^{(u_prev)} - c_i^{(r'-1)}| ≤ τ_{(u_prev,r'-1)} + 4u₀` (`I:eq:sec4_4u0_pass_ub`); if `u_prev = r' - 1`,
`c_i^{(u_prev)} = c_i^{(r'-1)}` (the reused release of (B1)). -/
theorem coupled_progress_separation (hα : 0 < α) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k)
    (hB : 3 ≤ (transcript k α β A z.1 z.2 i).ufinal) :
    adaTau α ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal)
        (transcript k α β A z.1 z.2 i).ufinal - 4 * adaU0 α ≤
      |(transcript k α β A z.1 z.2 i).c
          ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal) -
        (transcript k α β A z.1 z.2 i).c (transcript k α β A z.1 z.2 i).ufinal| ∧
    ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal <
        (transcript k α β A z.1 z.2 i).ufinal - 1 →
      |(transcript k α β A z.1 z.2 i).c
          ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal) -
        (transcript k α β A z.1 z.2 i).c ((transcript k α β A z.1 z.2 i).ufinal - 1)| ≤
        adaTau α ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal)
          ((transcript k α β A z.1 z.2 i).ufinal - 1) + 4 * adaU0 α) ∧
    ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal =
        (transcript k α β A z.1 z.2 i).ufinal - 1 →
      (transcript k α β A z.1 z.2 i).c
          ((transcript k α β A z.1 z.2 i).uprev (transcript k α β A z.1 z.2 i).ufinal) =
        (transcript k α β A z.1 z.2 i).c ((transcript k α β A z.1 z.2 i).ufinal - 1)) := by
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [transcript_of_active A z.1 z.2 i hact] at hB ⊢
  rw [ChainData.toRec_ufinal] at hB ⊢
  rw [ChainData.toRec_uprev]
  have hc := onlineChain_clean hα A z.1 hz i
  have hθ := onlineChain_thetaMem A hA z.1 z.2 i
  have hlk := onlineChain_locked A z.1 z.2 i
  have hL1 : 1 ≤ (onlineChain k α β A z.1 z.2 i).L := by
    rw [hlk.L_eq]
    have := adaL_ge_four α
    omega
  rw [ChainData.toRec_c_uprev,
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_ufinal (by omega)),
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_pred hB)]
  refine ⟨?_, fun hu => ?_, fun hu => ChainData.caseB_cprev_of_eq hB hu⟩
  · have h := ChainData.caseB_trigger_gap hc hθ hB hL1
    rwa [hlk.tau_eq] at h
  · have h := ChainData.caseB_pass_gap hc hθ hB hL1 hu
    rwa [hlk.tau_eq] at h

/-- Lemma `I:lem:rl2_coupled_progress`(3), `I:eq:sec4_interior_adj_gap` (valid for every Case-B round), on
`E_lap`: `s_{i,r'}(c_i^{(r'-1)} - c_i^{(r')}) ≥ (τ_{(u_prev,r')} - τ_{(u_prev,r'-1)}) - 8u₀ = 2γ - 8u₀ =
28γ/16`. -/
theorem coupled_progress_adj_gap (hα : 0 < α) (hα' : α < 1 / 16) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k)
    (hB : 3 ≤ (transcript k α β A z.1 z.2 i).ufinal) :
    28 / 16 * adaGamma α ≤ (transcript k α β A z.1 z.2 i).sgn *
      ((transcript k α β A z.1 z.2 i).c ((transcript k α β A z.1 z.2 i).ufinal - 1) -
        (transcript k α β A z.1 z.2 i).c (transcript k α β A z.1 z.2 i).ufinal) := by
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [transcript_of_active A z.1 z.2 i hact] at hB ⊢
  rw [ChainData.toRec_ufinal] at hB ⊢
  rw [ChainData.toRec_sgn,
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_ufinal (by omega)),
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_pred hB)]
  exact ChainData.round_caseB_adj_gap hα hα' (onlineChain_locked A z.1 z.2 i)
    (onlineChain_clean hα A z.1 hz i) (onlineChain_thetaMem A hA z.1 z.2 i) hB

/-- Lemma `I:lem:rl2_coupled_progress`(4), `I:eq:sec4_terminal_adj_gap`, on `E_clean`: in a terminal Case-B
round (`u_final = L`), `s_{i,L}(c_i^{(L-1)} - μ_i) ≥ 2γ - 9u₀ - r_anc = 2γ - 11u₀ = 53γ/32`. -/
theorem coupled_progress_terminal_gap [MeasurableSpace X] (hα : 0 < α) (hα' : α < 1 / 16)
    (D : Measure X) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z) (i : Fin k)
    (hBL : (transcript k α β A z.1 z.2 i).ufinal = adaL α) :
    53 / 32 * adaGamma α ≤ (transcript k α β A z.1 z.2 i).sgn *
      ((transcript k α β A z.1 z.2 i).c (adaL α - 1) - popMu D A (transcript k α β A z.1 z.2) i) := by
  obtain ⟨hlk, hc, hθ, -, hanc⟩ := clean_envelopes hα D A hA z hz i
  have hL5 := five_le_adaL hα hα'
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [transcript_of_active A z.1 z.2 i hact] at hBL ⊢
  rw [ChainData.toRec_ufinal] at hBL
  have hB : 3 ≤ (onlineChain k α β A z.1 z.2 i).ufinal := by omega
  have hrel := ChainData.released_pred hB
  rw [hBL] at hrel
  rw [ChainData.toRec_sgn, ChainData.toRec_c_of_released _ _ _ _ hrel]
  exact ChainData.round_caseB_terminal_gap hα hα' hlk hc hθ hanc hBL

/-- Lemma `I:lem:rl2_coupled_progress`(3), the equal-impulse `μ`-cancellation (`I:eq:sec4_linear_mu_cancel`)
with the deductions: for an interior Case-B round (`3 ≤ r' ≤ L - 1`, `r' = u_final`),
`∑_{m=2}^{L-1} Prog_{m,i}(h) = w_{r'-1}γ s_{i,r'}(c_i^{(r'-1)} - c_i^{(r')}) - w_{r'-1}η² - w_{r'}η̃_{r'}²
- 2w_{r'-1}γu₀`; the population mean `μ_i` cancels exactly (deterministic, no clean event needed). -/
theorem coupled_progress_mu_cancel [MeasurableSpace X] (hα : 0 < α) (D : Measure X)
    (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : Fin k)
    (hB : 3 ≤ (transcript k α β A S ω i).ufinal)
    (hBL : (transcript k α β A S ω i).ufinal + 1 ≤ adaL α) :
    ∑ m ∈ Finset.Icc 2 (adaL α - 1), progRound α D A (transcript k α β A S ω) m i =
      adaW α ((transcript k α β A S ω i).ufinal - 1) * adaGamma α * (transcript k α β A S ω i).sgn *
          ((transcript k α β A S ω i).c ((transcript k α β A S ω i).ufinal - 1) -
            (transcript k α β A S ω i).c (transcript k α β A S ω i).ufinal) -
        adaW α ((transcript k α β A S ω i).ufinal - 1) * adaEta α ^ 2 -
        adaW α (transcript k α β A S ω i).ufinal *
          adaEtaTilde α (transcript k α β A S ω i).ufinal ^ 2 -
        2 * (adaW α ((transcript k α β A S ω i).ufinal - 1) * adaGamma α) * adaU0 α := by
  have hact := transcript_active_of_two_le_ufinal A S ω i (by omega)
  rw [sum_progRound_of_active D A S ω i hact]
  rw [transcript_of_active A S ω i hact] at hB hBL ⊢
  rw [ChainData.toRec_ufinal] at hB hBL ⊢
  rw [ChainData.toRec_sgn,
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_ufinal (by omega)),
    ChainData.toRec_c_of_released _ _ _ _ (ChainData.released_pred hB)]
  have hne : (onlineChain k α β A S ω i).ufinal ≠ adaL α := by omega
  have hs := ChainData.progSum_caseB_interior hB (by show _ ≤ adaL α; exact hBL) (adaW α) (adaU0 α)
    (popMu D A (transcript k α β A S ω) i) (adaEta1 α) (adaEta α) _ (adaEtaTilde α)
    (ChainData.adaEta_nonneg hα) (ChainData.adaEtaTilde_nonneg hα _)
    (eight_adaW_adaEta α _) (eight_adaW_adaEtaTilde hα hne)
  rw [show (onlineChain k α β A S ω i).L = adaL α from rfl] at hs
  rw [hs]

/-! ## The deductions `I:eq:sec4_deduction_primary`, `I:eq:sec4_deduction_reaction` -/

/-- `I:eq:sec4_deduction_primary`: `8 w_{r'-1}(η²/8 + η u₀) = w_{r'-1}(γ²/64 + γ²/32) = (3/64) w_{r'-1} γ²`
(`η = γ/8`, `u₀ = γ/32`). -/
theorem deduction_primary (α : ℝ) (m : ℕ) :
    8 * adaW α m * (adaEta α ^ 2 / 8 + adaEta α * adaU0 α) = 3 / 64 * adaW α m * adaGamma α ^ 2 := by
  unfold adaEta adaU0
  ring

/-- `I:eq:sec4_deduction_reaction`: for a level `2 ≤ r' ≠ L` (used for `3 ≤ r' ≤ L - 1`),
`8 w_{r'}(η̃_{r'}²/8 + η̃_{r'} u₀) = w_{r'-1} γ² (ρ^{-2}/64 + 1/32) < (3/64) w_{r'-1} γ²`. -/
theorem deduction_reaction (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : 2 ≤ r) (hrL : r ≠ adaL α) :
    8 * adaW α r * (adaEtaTilde α r ^ 2 / 8 + adaEtaTilde α r * adaU0 α) =
        adaW α (r - 1) * adaGamma α ^ 2 * ((adaRho α)⁻¹ ^ 2 / 64 + 1 / 32) ∧
      8 * adaW α r * (adaEtaTilde α r ^ 2 / 8 + adaEtaTilde α r * adaU0 α) <
        3 / 64 * adaW α (r - 1) * adaGamma α ^ 2 := by
  have hid : 8 * adaW α r * (adaEtaTilde α r ^ 2 / 8 + adaEtaTilde α r * adaU0 α) =
      adaW α (r - 1) * adaGamma α ^ 2 * ((adaRho α)⁻¹ ^ 2 / 64 + 1 / 32) := by
    rw [adaW_pred_eq hα hr, adaEtaTilde_eq hα hr hrL]
    unfold adaEta adaU0
    ring
  refine ⟨hid, ?_⟩
  rw [hid]
  have hq := adaRho_inv_sq_lt_one hα hα'
  have hW := adaW_pos hα (r - 1)
  have hγ := adaGamma_pos hα
  have hP : 0 < adaW α (r - 1) * adaGamma α ^ 2 := by positivity
  nlinarith

/-! ## I.4.A and I.4.1(ii) on the transcript -/

/-- `I:eq:sec4_u0_gamma_relations` (L1173-1175): `L ≥ 5`, `γ = α/(8L)`, `u₀ = γ/32 = α/(256L)`,
`r_anc = 2u₀ = γ/16`, `R₁ = α/32`. -/
theorem sec4_u0_gamma_relations (hα : 0 < α) (hα' : α < 1 / 16) :
    5 ≤ adaL α ∧ adaGamma α = α / (8 * (adaL α : ℝ)) ∧ adaU0 α = adaGamma α / 32 ∧
      adaU0 α = α / (256 * (adaL α : ℝ)) ∧ adaRanc α = 2 * adaU0 α ∧
      adaRanc α = adaGamma α / 16 ∧ adaR1 α = α / 32 := by
  refine ⟨five_le_adaL hα hα', rfl, rfl, adaU0_eq α, adaRanc_eq_two_u0 α, ?_, rfl⟩
  rw [adaRanc_eq_two_u0]
  unfold adaU0
  ring

/-- `I:eq:sec4_upper_pass_bound` on the transcript, on `E_lap`: in an active round, every stage
`s ∈ {u_final + 1, …, L}` passed on the answer, so `|a_i - θ_i^{(s)}(S_s)| ≤ τ_{(u_final,s)} + 3u₀`. -/
theorem output_pass_bound (hα : 0 < α) (A : DetAnalyst X)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k)
    (hi : (transcript k α β A z.1 z.2 i).active = true) {s : ℕ}
    (hs1 : (transcript k α β A z.1 z.2 i).ufinal < s) (hs2 : s ≤ adaL α) :
    |(transcript k α β A z.1 z.2 i).answer - (onlineChain k α β A z.1 z.2 i).theta s| ≤
      adaTau α (transcript k α β A z.1 z.2 i).ufinal s + 3 * adaU0 α := by
  rw [transcript_of_active A z.1 z.2 i hi] at hs1 ⊢
  rw [ChainData.toRec_ufinal] at hs1 ⊢
  rw [ChainData.toRec_answer]
  have h := ChainData.answer_pass_bound (onlineChain_clean hα A z.1 hz i) hs1 hs2
  rwa [(onlineChain_locked A z.1 z.2 i).tau_eq] at h

/-- `I:eq:sec4_ai_minus_thetaL` on the transcript, on `E_lap`: in an active round,
`|a_i - θ_i^{(L)}(S_L)| ≤ τ_{(u_final,L)} + 4u₀` (both subcases `u_final < L` and `u_final = L`). -/
theorem output_thetaL_bound (hα : 0 < α) (hα' : α < 1 / 16) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k)
    (hi : (transcript k α β A z.1 z.2 i).active = true) :
    |(transcript k α β A z.1 z.2 i).answer - (onlineChain k α β A z.1 z.2 i).theta (adaL α)| ≤
      adaTau α (transcript k α β A z.1 z.2 i).ufinal (adaL α) + 4 * adaU0 α := by
  rw [transcript_of_active A z.1 z.2 i hi, ChainData.toRec_answer, ChainData.toRec_ufinal]
  have hlk := onlineChain_locked A z.1 z.2 i
  have hL5 := five_le_adaL hα hα'
  have h := ChainData.abs_answer_sub_thetaL_le (onlineChain_clean hα A z.1 hz i)
    (onlineChain_thetaMem A hA z.1 z.2 i) (by rw [hlk.L_eq]; omega) (hlk.tau_self _)
  rwa [hlk.tau_eq, hlk.L_eq] at h

end Sep

end A

end F2e2e
