import F2e2e.A.NumericsCaps

/-!
# Part I numerics: the failure-budget certificates of Sections 3, 5 and 6

Statements requested by the §5 owner (295bf129) for `F2e2e/A/Closure.lean` (exact forms).
`parts/partI.tex`:
* (B1) `e^{0.05} < 1.0513` (L1812, L1977);
* (B2), (B2') the Stage-1 comparator floor `γ₁ - η₁/8 - ε₁²/(2η₁T) ≥ (15/128 - 1/30000)α > (1121/9600)α > α/10`
  for `T ≥ 600/α²` (`I:eq:stage1_unweighted_comp_lb`, L1807);
* (B3), (B3') the clean-event budget `100δ_val/ε_L + δ_val ≤ 201u₀²β/(10⁸L³) < 10⁻¹³α²β < 10⁻⁵β`
  (`I:eq:Eclean_failure_bound` L1128, L1143, L1812);
* (B4) the Stage-1 Markov budget `(2δ₁ + e^{ε₁}P[E_clean^c])/(e^{-ε₁}(1121/9600)α) < 0.00176β`
  (`I:eq:stage1_markov_derivation`, L1813-1818);
* (B5) the ceiling bound `128L/γ ≤ W̃_{max,m} < 257L/γ` (`I:eq:W_tilde_ceiling_bound`, L1860-1893);
* (B6) the per-level Markov budget `(δ_val + e^{ε_m}P[E_clean^c])/(124e^{-ε_m}/W̃_{max,m}) < 15u₀β/(10⁸L²)`
  (`I:eq:Am_numerical_bound`, L1977-1980);
* (B7) `(L-2)·15u₀β/(10⁸L²) < 10⁻¹¹β` (L1983);
* (B8) `10⁻⁵β + 0.00176β + 10⁻¹¹β < β` (`I:eq:sec6_total_failure_prob`, L2040).
-/

namespace F2e2e

namespace A

section Budget

variable {α β : ℝ}

/-- (B1) `e^{1/20} < 1.0513`. -/
lemma exp_one_twentieth_lt : Real.exp (1 / 20 : ℝ) < 10513 / 10000 := by
  have h := Real.exp_bound' (x := (1 / 20 : ℝ)) (by norm_num) (by norm_num) (n := 3) (by norm_num)
  generalize Real.exp (1 / 20 : ℝ) = E at h ⊢
  norm_num [Finset.sum_range_succ, Nat.factorial] at h
  linarith

/-- (B2) The Stage-1 comparator floor (`I:eq:stage1_unweighted_comp_lb`):
`(15/128 - 1/30000) α ≤ γ₁ - η₁/8 - ε₁²/(2 η₁ T)` with `γ₁ = α/8`, `η₁ = α/16`, `ε₁ = 1/20`,
`T ≥ 600/α²`. -/
lemma stage1_floor_num {α T : ℝ} (hα : 0 < α) (hT : 600 / α ^ 2 ≤ T) :
    (15 / 128 - 1 / 30000) * α ≤ α / 8 - α / 16 / 8 - (1 / 20 : ℝ) ^ 2 / (2 * (α / 16) * T) := by
  have hα2 : 0 < α ^ 2 := by positivity
  have hT0 : 0 < T := lt_of_lt_of_le (by positivity) hT
  have hT' : 600 ≤ α ^ 2 * T := by
    rw [div_le_iff₀ hα2] at hT
    linarith
  have key : (1 / 20 : ℝ) ^ 2 / (2 * (α / 16) * T) ≤ α / 30000 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    nlinarith
  linarith

/-- (B2') `1/10 < 1121/9600 < 15/128 - 1/30000`. -/
lemma floor_consts : (1 / 10 : ℝ) < 1121 / 9600 ∧ (1121 / 9600 : ℝ) < 15 / 128 - 1 / 30000 := by
  constructor <;> norm_num

/-- (B3) `100 δ_val/ε_L + δ_val < 10⁻¹³ α² β`. -/
lemma clean_budget_lt_sq (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (_hβ' : β < 1 / 2) :
    100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β < 1 / 10 ^ 13 * α ^ 2 * β := by
  have hL5 := five_le_adaL_real hα hα'
  rw [adaDeltaVal_eq, adaEpsL_eq]
  set L := (adaL α : ℝ) with hLdef
  have hL0 : 0 < L := by linarith
  have e : 100 * (α ^ 3 * β / (256 ^ 3 * 10 ^ 8 * L ^ 6)) / (α / (512 * L)) +
      α ^ 3 * β / (256 ^ 3 * 10 ^ 8 * L ^ 6) =
      α ^ 2 * β * (51200 * L + α) / (256 ^ 3 * 10 ^ 8 * L ^ 6) := by
    field_simp
    ring
  rw [e, div_lt_iff₀ (by positivity)]
  have hab : 0 < α ^ 2 * β := by positivity
  have hL6 : 3125 * L ≤ L ^ 6 := by
    have h5 : (5 : ℝ) ^ 5 ≤ L ^ 5 := pow_le_pow_left₀ (by norm_num) hL5 5
    have h6 := mul_le_mul_of_nonneg_left h5 hL0.le
    nlinarith
  have hin : 51200 * L + α < 1 / 10 ^ 13 * (256 ^ 3 * 10 ^ 8 * L ^ 6) := by nlinarith
  calc α ^ 2 * β * (51200 * L + α) < α ^ 2 * β * (1 / 10 ^ 13 * (256 ^ 3 * 10 ^ 8 * L ^ 6)) :=
        mul_lt_mul_of_pos_left hin hab
    _ = 1 / 10 ^ 13 * α ^ 2 * β * (256 ^ 3 * 10 ^ 8 * L ^ 6) := by ring

/-- (B3') `100 δ_val/ε_L + δ_val < 10⁻⁵ β` (`I:eq:Eclean_failure_bound`). -/
lemma clean_budget_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β < 1 / 10 ^ 5 * β := by
  have h := clean_budget_lt_sq hα hα' hβ hβ'
  have hα2 : α ^ 2 ≤ 1 := by nlinarith
  have : 1 / 10 ^ 13 * α ^ 2 * β ≤ 1 / 10 ^ 5 * β := by nlinarith
  linarith

/-- (B4) The Stage-1 Markov budget (`I:eq:stage1_markov_derivation`). -/
lemma stage1_budget_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {p : ℝ}
    (hp0 : 0 ≤ p) (hp : p ≤ 100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β) :
    (2 * (α * β / 10240) + Real.exp (1 / 20) * p) / (Real.exp (-(1 / 20)) * (1121 / 9600) * α) <
      176 / 100000 * β := by
  have hE := exp_one_twentieth_lt
  have hE0 : 0 < Real.exp (1 / 20 : ℝ) := Real.exp_pos _
  have hpc := clean_budget_lt_sq hα hα' hβ hβ'
  have hp' : p ≤ 1 / 10 ^ 13 * α ^ 2 * β := hp.trans hpc.le
  rw [Real.exp_neg]
  set E := Real.exp (1 / 20 : ℝ) with hEdef
  have hαβ : 0 < α * β := by positivity
  have h1 : E * (2 * (α * β / 10240)) ≤ 10513 / 10000 * (2 * (α * β / 10240)) := by
    gcongr
  have hEE : E * E ≤ (10513 / 10000) ^ 2 := by nlinarith
  have h2 : E * (E * p) ≤ (10513 / 10000) ^ 2 * (1 / 10 ^ 13) * (α * β / 16) := by
    have h4 : α ^ 2 * β ≤ α * β / 16 := by nlinarith
    calc E * (E * p) = (E * E) * p := by ring
      _ ≤ (10513 / 10000) ^ 2 * p := mul_le_mul_of_nonneg_right hEE hp0
      _ ≤ (10513 / 10000) ^ 2 * (1 / 10 ^ 13 * α ^ 2 * β) := by gcongr
      _ ≤ (10513 / 10000) ^ 2 * (1 / 10 ^ 13) * (α * β / 16) := by nlinarith
  have key : (2 * (α * β / 10240) + E * p) * E < 176 / 100000 * (1121 / 9600) * (α * β) := by
    have e : (2 * (α * β / 10240) + E * p) * E = E * (2 * (α * β / 10240)) + E * (E * p) := by
      ring
    rw [e]
    linarith
  have e2 : 176 / 100000 * β * (E⁻¹ * (1121 / 9600) * α) =
      176 / 100000 * (1121 / 9600) * (α * β) / E := by
    field_simp
  rw [div_lt_iff₀ (by positivity), e2, lt_div_iff₀ hE0]
  exact key

/-- The step-capacity normalizer `W̃_{max,m} = γ (w_m N_{m+1,max} + 1_{m ≥ 3} w_{m-1} N_{m,max})` of
`I:eq:W_tilde_max_def` (L1839), written with `w_m = ε_m^{-2}`. -/
noncomputable def adaWmaxSpec (α : ℝ) (m : ℕ) : ℝ :=
  adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2 +
    if 3 ≤ m then (adaNmax α m : ℝ) / adaEps α (m - 1) ^ 2 else 0)

/-- `γ/ε_j² < L/(2γ)` for `j ≤ L - 1` (as `ε_j > α/20`; the paper's `γ²(w_m + w_{m-1}) < 0.5 < L`). -/
lemma gamma_div_eps_sq_lt (hα : 0 < α) (hα' : α < 1 / 16) {j : ℕ} (hj : j ≤ adaL α - 1) :
    adaGamma α / adaEps α j ^ 2 < (adaL α : ℝ) / (2 * adaGamma α) := by
  have hL5 := five_le_adaL_real hα hα'
  have hε := adaEps_gt_of_le hα hα' hj
  have hε0 := adaEps_pos hα j
  have hε2 : α ^ 2 / 400 < adaEps α j ^ 2 := by
    have h0 : 0 ≤ 1 / 20 * α := by positivity
    have := pow_lt_pow_left₀ hε h0 two_ne_zero
    nlinarith
  have hγ := adaGamma_pos hα
  rw [div_lt_div_iff₀ (by positivity) (by positivity)]
  unfold adaGamma
  set L := (adaL α : ℝ) with hLdef
  have hL0 : 0 < L := by linarith
  have e : α / (8 * L) * (2 * (α / (8 * L))) = α ^ 2 / (32 * L ^ 2) := by
    field_simp
    ring
  rw [e, div_lt_iff₀ (by positivity)]
  have hL3 : 125 ≤ L ^ 3 := by
    have := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 5) hL5 3
    norm_num at this
    linarith
  have h1 : 32 * L ^ 3 * (α ^ 2 / 400) ≤ 32 * L ^ 3 * adaEps α j ^ 2 := by gcongr
  have h2 : α ^ 2 ≤ 32 * L ^ 3 * (α ^ 2 / 400) := by nlinarith
  nlinarith

/-- (B5) `128 L/γ ≤ W̃_{max,m}` for `2 ≤ m ≤ L - 1` (`I:eq:W_tilde_ceiling_bound`). -/
lemma wmax_ge (hα : 0 < α) (_hα' : α < 1 / 16) {m : ℕ} (_hm2 : 2 ≤ m) (_hmL : m ≤ adaL α - 1) :
    128 * (adaL α : ℝ) / adaGamma α ≤ adaWmaxSpec α m := by
  unfold adaWmaxSpec
  have hγ := adaGamma_pos hα
  have hε := adaEps_pos hα m
  have hN : 128 * (adaL α : ℝ) * adaEps α m ^ 2 / adaGamma α ^ 2 ≤ (adaNmax α (m + 1) : ℝ) := by
    unfold adaNmax
    rw [Nat.add_sub_cancel]
    exact Nat.le_ceil _
  have hextra : 0 ≤ (if 3 ≤ m then (adaNmax α m : ℝ) / adaEps α (m - 1) ^ 2 else 0) := by
    split_ifs
    · positivity
    · exact le_rfl
  have h1 : 128 * (adaL α : ℝ) / adaGamma α ≤
      adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2) := by
    have e : adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2) =
        adaGamma α ^ 2 / adaEps α m ^ 2 * (adaNmax α (m + 1) : ℝ) / adaGamma α := by
      field_simp
    rw [e]
    apply div_le_div_of_nonneg_right _ hγ.le
    have e2 : 128 * (adaL α : ℝ) = adaGamma α ^ 2 / adaEps α m ^ 2 *
        (128 * (adaL α : ℝ) * adaEps α m ^ 2 / adaGamma α ^ 2) := by
      field_simp
    rw [e2]
    gcongr
  calc 128 * (adaL α : ℝ) / adaGamma α ≤ adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2) :=
        h1
    _ ≤ adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2 +
          if 3 ≤ m then (adaNmax α m : ℝ) / adaEps α (m - 1) ^ 2 else 0) := by
        gcongr
        linarith

/-- (B5) `W̃_{max,m} < 257 L/γ` for `2 ≤ m ≤ L - 1` (`I:eq:W_tilde_ceiling_bound`). -/
lemma wmax_lt (hα : 0 < α) (hα' : α < 1 / 16) {m : ℕ} (_hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1) :
    adaWmaxSpec α m < 257 * (adaL α : ℝ) / adaGamma α := by
  unfold adaWmaxSpec
  have hγ := adaGamma_pos hα
  have hL5 := five_le_adaL_real hα hα'
  -- one trigger-cap term: `γ N_{j+1}/ε_j² < 128L/γ + γ/ε_j²`
  have hterm : ∀ j : ℕ, j ≤ adaL α - 1 → adaGamma α * ((adaNmax α (j + 1) : ℝ) / adaEps α j ^ 2) <
      128 * (adaL α : ℝ) / adaGamma α + (adaL α : ℝ) / (2 * adaGamma α) := by
    intro j hj
    have hε := adaEps_pos hα j
    have hN : (adaNmax α (j + 1) : ℝ) < 128 * (adaL α : ℝ) * adaEps α j ^ 2 / adaGamma α ^ 2 + 1 := by
      unfold adaNmax
      rw [Nat.add_sub_cancel]
      exact Nat.ceil_lt_add_one (by positivity)
    have hg := gamma_div_eps_sq_lt hα hα' hj
    have e : adaGamma α * ((128 * (adaL α : ℝ) * adaEps α j ^ 2 / adaGamma α ^ 2 + 1) /
        adaEps α j ^ 2) = 128 * (adaL α : ℝ) / adaGamma α + adaGamma α / adaEps α j ^ 2 := by
      field_simp
    calc adaGamma α * ((adaNmax α (j + 1) : ℝ) / adaEps α j ^ 2)
        < adaGamma α * ((128 * (adaL α : ℝ) * adaEps α j ^ 2 / adaGamma α ^ 2 + 1) /
            adaEps α j ^ 2) := by gcongr
      _ = 128 * (adaL α : ℝ) / adaGamma α + adaGamma α / adaEps α j ^ 2 := e
      _ < 128 * (adaL α : ℝ) / adaGamma α + (adaL α : ℝ) / (2 * adaGamma α) := by linarith
  have hA := hterm m hmL
  have e257 : 128 * (adaL α : ℝ) / adaGamma α + (adaL α : ℝ) / (2 * adaGamma α) +
      (128 * (adaL α : ℝ) / adaGamma α + (adaL α : ℝ) / (2 * adaGamma α)) =
      257 * (adaL α : ℝ) / adaGamma α := by
    field_simp
    ring
  have hpos : 0 < 128 * (adaL α : ℝ) / adaGamma α + (adaL α : ℝ) / (2 * adaGamma α) := by
    have : (0 : ℝ) < (adaL α : ℝ) := by linarith
    positivity
  split_ifs with h3
  · have hB := hterm (m - 1) (by omega)
    rw [show m - 1 + 1 = m by omega] at hB
    calc adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2 +
          (adaNmax α m : ℝ) / adaEps α (m - 1) ^ 2)
        = adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2) +
          adaGamma α * ((adaNmax α m : ℝ) / adaEps α (m - 1) ^ 2) := by ring
      _ < 257 * (adaL α : ℝ) / adaGamma α := by linarith
  · calc adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2 + 0)
        = adaGamma α * ((adaNmax α (m + 1) : ℝ) / adaEps α m ^ 2) := by ring
      _ < 257 * (adaL α : ℝ) / adaGamma α := by linarith

/-- (B6) The per-level Markov budget (`I:eq:Am_numerical_bound`). -/
lemma val_budget_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (_hβ' : β < 1 / 2) {p ε W : ℝ}
    (hp0 : 0 ≤ p) (hp : p ≤ 100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β) (hε0 : 0 ≤ ε)
    (hε : ε ≤ 1 / 20) (hW0 : 0 < W) (hW : W < 257 * (adaL α : ℝ) / adaGamma α) :
    (adaDeltaVal α β + Real.exp ε * p) / (124 * Real.exp (-ε) / W) <
      15 * adaU0 α * β / (10 ^ 8 * (adaL α : ℝ) ^ 2) := by
  have hu := adaU0_pos hα
  have hu' := adaU0_lt hα hα'
  have hL5 := five_le_adaL_real hα hα'
  have hγ : adaGamma α = 32 * adaU0 α := by
    rw [adaU0_eq_gamma]
    ring
  have hεL : adaEpsL α = adaU0 α / 2 := rfl
  have hδ : adaDeltaVal α β = adaU0 α ^ 3 * β / (10 ^ 8 * (adaL α : ℝ) ^ 3) := rfl
  have hE1 : 1 ≤ Real.exp ε := Real.one_le_exp hε0
  have hE2 : Real.exp ε ≤ 10513 / 10000 :=
    (Real.exp_le_exp.mpr hε).trans exp_one_twentieth_lt.le
  rw [hγ] at hW
  rw [hεL] at hp
  rw [Real.exp_neg]
  set E := Real.exp ε with hEdef
  set u := adaU0 α with hudef
  set L := (adaL α : ℝ) with hLdef
  have hL0 : 0 < L := by linarith
  set K := β / (10 ^ 8 * L ^ 3) with hKdef
  have hK0 : 0 < K := by positivity
  have hδK : adaDeltaVal α β = u ^ 3 * K := by
    rw [hδ, hKdef]
    ring
  rw [hδK] at hp ⊢
  have hp2 : p ≤ 200 * u ^ 2 * K + u ^ 3 * K := by
    calc p ≤ 100 * (u ^ 3 * K) / (u / 2) + u ^ 3 * K := hp
      _ = 200 * u ^ 2 * K + u ^ 3 * K := by
        field_simp
        ring
  have hRHS : 15 * u * β / (10 ^ 8 * L ^ 2) = 15 * u * K * L := by
    rw [hKdef]
    field_simp
  rw [hRHS]
  have hE0 : 0 < E := by linarith
  have eL : (u ^ 3 * K + E * p) / (124 * E⁻¹ / W) = (u ^ 3 * K + E * p) * E * W / 124 := by
    field_simp
  rw [eL]
  -- `δ + E p ≤ u²K (2.0513 u + 210.26)`
  have hS : u ^ 3 * K + E * p ≤ u ^ 3 * K + 10513 / 10000 * (200 * u ^ 2 * K + u ^ 3 * K) := by
    have : E * p ≤ 10513 / 10000 * p := mul_le_mul_of_nonneg_right hE2 hp0
    have : 10513 / 10000 * p ≤ 10513 / 10000 * (200 * u ^ 2 * K + u ^ 3 * K) := by gcongr
    linarith
  have hS0 : 0 ≤ u ^ 3 * K + E * p := by positivity
  have hEW : E * W < 10513 / 10000 * (257 * L / (32 * u)) := by
    calc E * W ≤ 10513 / 10000 * W := mul_le_mul_of_nonneg_right hE2 hW0.le
      _ < 10513 / 10000 * (257 * L / (32 * u)) := by gcongr
  have hT0 : 0 < u ^ 3 * K + 10513 / 10000 * (200 * u ^ 2 * K + u ^ 3 * K) := by positivity
  calc (u ^ 3 * K + E * p) * E * W / 124 = (u ^ 3 * K + E * p) * (E * W) / 124 := by ring
    _ ≤ (u ^ 3 * K + 10513 / 10000 * (200 * u ^ 2 * K + u ^ 3 * K)) * (E * W) / 124 := by
        gcongr
    _ < (u ^ 3 * K + 10513 / 10000 * (200 * u ^ 2 * K + u ^ 3 * K)) *
          (10513 / 10000 * (257 * L / (32 * u))) / 124 := by gcongr
    _ = u * K * L * ((20513 / 10000 * u + 21026 / 100) * (10513 / 10000) * 257 / (32 * 124)) := by
        field_simp
        ring
    _ < 15 * u * K * L := by
        have hf : (20513 / 10000 * u + 21026 / 100) * (10513 / 10000) * 257 / (32 * 124) < 15 := by
          nlinarith
        have hukl : 0 < u * K * L := by positivity
        calc u * K * L * ((20513 / 10000 * u + 21026 / 100) * (10513 / 10000) * 257 / (32 * 124))
            < u * K * L * 15 := mul_lt_mul_of_pos_left hf hukl
          _ = 15 * u * K * L := by ring

/-- (B7) `(L - 2) · 15 u₀ β/(10⁸ L²) < 10⁻¹¹ β`. -/
lemma val_sum_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) :
    ((adaL α : ℝ) - 2) * (15 * adaU0 α * β / (10 ^ 8 * (adaL α : ℝ) ^ 2)) < 1 / 10 ^ 11 * β := by
  have hu := adaU0_pos hα
  have hu' := adaU0_lt hα hα'
  have hL5 := five_le_adaL_real hα hα'
  set u := adaU0 α with hudef
  set L := (adaL α : ℝ) with hLdef
  have hL0 : 0 < L := by linarith
  have e : (L - 2) * (15 * u * β / (10 ^ 8 * L ^ 2)) = (L - 2) / L * (15 * u * β / (10 ^ 8 * L)) := by
    field_simp
  rw [e]
  have h1 : (L - 2) / L ≤ 1 := by
    rw [div_le_one hL0]
    linarith
  have h0 : 0 ≤ (L - 2) / L := div_nonneg (by linarith) hL0.le
  have hX0 : 0 ≤ 15 * u * β / (10 ^ 8 * L) := by positivity
  have h2 : 15 * u * β / (10 ^ 8 * L) ≤ 15 * u * β / (10 ^ 8 * 5) := by
    apply div_le_div_of_nonneg_left (by positivity) (by norm_num)
    linarith
  have h3 : 15 * u * β / (10 ^ 8 * 5) < 1 / 10 ^ 11 * β := by
    rw [div_lt_iff₀ (by norm_num)]
    nlinarith
  calc (L - 2) / L * (15 * u * β / (10 ^ 8 * L)) ≤ 1 * (15 * u * β / (10 ^ 8 * L)) :=
        mul_le_mul_of_nonneg_right h1 hX0
    _ = 15 * u * β / (10 ^ 8 * L) := by ring
    _ ≤ 15 * u * β / (10 ^ 8 * 5) := h2
    _ < 1 / 10 ^ 11 * β := h3

/-- (B8) `10⁻⁵ β + 0.00176 β + 10⁻¹¹ β < β` (`I:eq:sec6_total_failure_prob`). -/
lemma total_budget_lt (hβ : 0 < β) : 1 / 10 ^ 5 * β + 176 / 100000 * β + 1 / 10 ^ 11 * β < β := by
  linarith

end Budget

end A

end F2e2e
