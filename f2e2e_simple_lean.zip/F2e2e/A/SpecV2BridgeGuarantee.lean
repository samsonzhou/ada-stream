import F2e2e.A.SpecV2BridgeCoins
import F2e2e.A.ArchSpecV2Meas
import F2e2e.A.Model
import F2e2e.A.Closure

/-!
# Spec v2 (A) bridge, part 3: `ADAPublicGuarantee` for v2's cascade (A-ACC draft)

* `adaPublicOutputs_eq_recRun`, `adaPublicFails_iff`: v2's analyst-sees-public-records interaction is A-NUM's
  generic `recRun` (`F2e2e/A/Model.lean`) for the record type `PubRec = [0,1] × (ADAField → ℝ)` and the answer
  map `r ↦ r.1`.
* `toPublicHist α h`: the public history of a record history `h` (the `toPublic` image of each record, with
  `t₁`, `N_r` before each round counted from the earlier records); `Bd α B`: the record analyst induced by a
  deterministic public analyst `B`; `toPublicHist_run`, `measurable_toPublicHist`.
-/

namespace F2e2e.A.V2Bridge

open MeasureTheory ProbabilityTheory

noncomputable section

/-- The public record space `[0,1] × (ADAField → ℝ)` of v2. -/
abbrev PubRec : Type := Set.Icc (0 : ℝ) 1 × (F2e2e.ADAField → ℝ)

/-! ## v2's interaction is the generic `recRun` -/

theorem adaPublicOutputs_eq_recRun {X ΩM ΩA : Type} {n : ℕ} (mech : F2e2e.ADAPublicMechanism n ΩM)
    (A : F2e2e.ADAPublicAnalyst X ΩA) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) (i : ℕ) :
    F2e2e.adaPublicOutputs mech A S ωM ωA i = recRun (R := PubRec) mech A S ωM ωA i := by
  induction i with
  | zero =>
    funext j
    exact j.elim0
  | succ i ih =>
    simp only [F2e2e.adaPublicOutputs, recRun, ih]

theorem adaPublicFails_iff {X ΩM ΩA : Type} [MeasurableSpace X] {n : ℕ}
    (mech : F2e2e.ADAPublicMechanism n ΩM) (A : F2e2e.ADAPublicAnalyst X ΩA) (D : Measure X) (k : ℕ)
    (α : ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) :
    F2e2e.adaPublicFails mech A D k α S ωM ωA ↔
      recFails (R := PubRec) (fun r => (r.1 : ℝ)) mech A D k α S ωM ωA := by
  simp only [F2e2e.adaPublicFails, recFails, adaPublicOutputs_eq_recRun]

/-! ## Public histories of record histories -/

/-- `toField` with the counters `t₁`, `N` given directly. -/
def toFieldTN (α : ℝ) (t1 : ℕ) (N : ℕ → ℕ) (rec : RoundRec) : F2e2e.ADAField → ℝ
  | .active => if rec.active then 1 else 0
  | .c1 => rec.c 1
  | .b r => if rec.trig r then 1 else 0
  | .uPrev r => if rec.trig r then (rec.uprev r : ℝ) else 0
  | .released r => if rec.rel r then 1 else 0
  | .v r => rec.v r
  | .c r => if r = 1 then 0 else rec.c r
  | .s => rec.sgn
  | .delta m => if m = 1 then 0 else rec.delta m
  | .haltAfter => if (rec.ufinal = 2 ∧ t1 + 1 = adaT1max α) ∨
      (3 ≤ rec.ufinal ∧ N rec.ufinal + 1 = adaNmax α rec.ufinal) then 1 else 0

theorem toField_eq {k : ℕ} {α β : ℝ} (st : MState k α β) (rec : RoundRec) :
    toField st rec = toFieldTN α st.t1 st.N rec := by
  funext f
  cases f <;> rfl

/-- The record of round `j` of a record prefix (`RoundRec.halted` beyond it). -/
def recAtP {i : ℕ} (h : Fin i → RoundRec) (j : ℕ) : RoundRec :=
  if hj : j < i then h ⟨j, hj⟩ else RoundRec.halted

/-- `t₁` before round `j`: the number of Case-A rounds among the rounds `< j`. -/
def preT1 {i : ℕ} (h : Fin i → RoundRec) (j : ℕ) : ℕ :=
  ∑ l ∈ Finset.range j, if (recAtP h l).ufinal = 2 then 1 else 0

/-- `N_r` before round `j`: the number of Case-B rounds `< j` with `u_final = r`. -/
def preN {i : ℕ} (h : Fin i → RoundRec) (j r : ℕ) : ℕ :=
  ∑ l ∈ Finset.range j, if 3 ≤ (recAtP h l).ufinal ∧ r = (recAtP h l).ufinal then 1 else 0

/-- The public history (v2 outputs) of a record history. -/
def toPublicHist (α : ℝ) {i : ℕ} (h : Fin i → RoundRec) : Fin i → PubRec :=
  fun j => (F2e2e.clip01 (h j).answer, toFieldTN α (preT1 h j) (preN h j) (h j))

/-- The record analyst induced by a deterministic public analyst. -/
def Bd {X : Type} (α : ℝ) (B : (i : ℕ) → (Fin i → PubRec) → X → ℝ) : DetAnalyst X :=
  fun i hr x => B i (toPublicHist α hr) x

section Run

variable {k : ℕ} {α β : ℝ} (qv : ℕ → Fin (adaSampleSize k α β) → ℝ) (ω' : AdaOmega k α)

theorem preT1_run {i : ℕ} (j : Fin i) :
    preT1 (fun l : Fin i => roundRec k α β qv ω' l) j = (run k α β qv ω' j).t1 := by
  rw [run_t1]
  unfold preT1
  refine Finset.sum_congr rfl fun l hl => ?_
  have hl' : l < i := lt_trans (Finset.mem_range.mp hl) j.isLt
  unfold recAtP
  rw [dif_pos hl']

theorem preN_run {i : ℕ} (j : Fin i) :
    preN (fun l : Fin i => roundRec k α β qv ω' l) j = (run k α β qv ω' j).N := by
  funext r
  rw [run_N]
  unfold preN
  refine Finset.sum_congr rfl fun l hl => ?_
  have hl' : l < i := lt_trans (Finset.mem_range.mp hl) j.isLt
  unfold recAtP
  rw [dif_pos hl']

/-- The public history of the run's records is the sequence of the rounds' `toPublic` outputs. -/
theorem toPublicHist_run (i : ℕ) :
    toPublicHist α (fun l : Fin i => roundRec k α β qv ω' l) =
      fun j : Fin i => toPublic (run k α β qv ω' j) (roundRec k α β qv ω' j) := by
  funext j
  unfold toPublicHist toPublic
  rw [toField_eq, preT1_run, preN_run]

end Run

/-! ## Measurability of `toPublicHist` -/

theorem measurable_recField {i : ℕ} (j : Fin i) :
    Measurable fun h : Fin i → RoundRec => h j := measurable_pi_apply j

theorem measurableSet_active {i : ℕ} (j : Fin i) :
    MeasurableSet {h : Fin i → RoundRec | (h j).active = true} :=
  (RoundRec.measurable_active.comp (measurable_pi_apply j)) (measurableSet_singleton true)

theorem measurableSet_trig {i : ℕ} (j : Fin i) (r : ℕ) :
    MeasurableSet {h : Fin i → RoundRec | (h j).trig r = true} :=
  (((measurable_pi_apply r).comp RoundRec.measurable_trig).comp (measurable_pi_apply j))
    (measurableSet_singleton true)

theorem measurableSet_rel {i : ℕ} (j : Fin i) (r : ℕ) :
    MeasurableSet {h : Fin i → RoundRec | (h j).rel r = true} :=
  (((measurable_pi_apply r).comp RoundRec.measurable_rel).comp (measurable_pi_apply j))
    (measurableSet_singleton true)

theorem measurable_ufinalP {i : ℕ} (l : ℕ) :
    Measurable fun h : Fin i → RoundRec => (recAtP h l).ufinal := by
  unfold recAtP
  by_cases hl : l < i
  · simp only [dif_pos hl]
    exact RoundRec.measurable_ufinal.comp (measurable_pi_apply _)
  · simp only [dif_neg hl]
    exact measurable_const

theorem measurable_preT1 {i : ℕ} (j : ℕ) : Measurable fun h : Fin i → RoundRec => preT1 h j := by
  unfold preT1
  refine Finset.measurable_sum _ fun l _ => ?_
  exact Measurable.ite ((measurable_ufinalP l) (measurableSet_singleton 2)) measurable_const
    measurable_const

theorem measurable_preN {i : ℕ} (j r : ℕ) : Measurable fun h : Fin i → RoundRec => preN h j r := by
  unfold preN
  refine Finset.measurable_sum _ fun l _ => ?_
  refine Measurable.ite ?_ measurable_const measurable_const
  have hu := measurable_ufinalP (i := i) l
  exact measurableSet_setOfPred.mpr
    ((measurableSet_setOfPred.mp (hu (MeasurableSet.of_discrete (s := {n : ℕ | 3 ≤ n})))).and
      (measurable_const.eq hu))

theorem measurable_toFieldTN_haltAfter (α : ℝ) {i : ℕ} (j : Fin i) :
    Measurable fun h : Fin i → RoundRec =>
      toFieldTN α (preT1 h j) (preN h j) (h j) .haltAfter := by
  have hu : Measurable fun h : Fin i → RoundRec => (h j).ufinal :=
    RoundRec.measurable_ufinal.comp (measurable_pi_apply j)
  have hN : Measurable fun h : Fin i → RoundRec => preN h j (h j).ufinal :=
    measurable_nat_index (g := fun r h => preN h j r) (fun r => measurable_preN j r) hu
  have hT : Measurable fun h : Fin i → RoundRec => preT1 h j := measurable_preT1 j
  have h3 : Measurable fun h : Fin i → RoundRec => 3 ≤ (h j).ufinal :=
    measurableSet_setOfPred.mp (hu (MeasurableSet.of_discrete (s := {n : ℕ | 3 ≤ n})))
  have hT1 : Measurable fun h : Fin i → RoundRec => preT1 h j + 1 :=
    (Measurable.of_discrete (f := fun n : ℕ => n + 1)).comp hT
  have hN1 : Measurable fun h : Fin i → RoundRec => preN h j (h j).ufinal + 1 :=
    (Measurable.of_discrete (f := fun n : ℕ => n + 1)).comp hN
  have hNm : Measurable fun h : Fin i → RoundRec => adaNmax α (h j).ufinal :=
    (Measurable.of_discrete (f := fun n : ℕ => adaNmax α n)).comp hu
  have hp : Measurable fun h : Fin i → RoundRec => ((h j).ufinal = 2 ∧ preT1 h j + 1 = adaT1max α) ∨
      (3 ≤ (h j).ufinal ∧ preN h j (h j).ufinal + 1 = adaNmax α (h j).ufinal) :=
    ((hu.eq measurable_const).and (hT1.eq measurable_const)).or (h3.and (hN1.eq hNm))
  exact Measurable.ite (measurableSet_setOfPred.mpr hp) measurable_const measurable_const

theorem measurable_toFieldTN (α : ℝ) {i : ℕ} (j : Fin i) :
    Measurable fun h : Fin i → RoundRec => toFieldTN α (preT1 h j) (preN h j) (h j) := by
  refine measurable_pi_lambda _ fun f => ?_
  have hrec : Measurable fun h : Fin i → RoundRec => h j := measurable_pi_apply j
  cases f with
  | active => exact Measurable.ite (measurableSet_active j) measurable_const measurable_const
  | c1 => exact (measurable_pi_apply 1).comp (RoundRec.measurable_c.comp hrec)
  | b r => exact Measurable.ite (measurableSet_trig j r) measurable_const measurable_const
  | uPrev r =>
    refine Measurable.ite (measurableSet_trig j r) ?_ measurable_const
    exact (Measurable.of_discrete (f := fun n : ℕ => (n : ℝ))).comp
      ((measurable_pi_apply r).comp (RoundRec.measurable_uprev.comp hrec))
  | released r => exact Measurable.ite (measurableSet_rel j r) measurable_const measurable_const
  | v r => exact (measurable_pi_apply r).comp (RoundRec.measurable_v.comp hrec)
  | c r =>
    by_cases hr : r = 1
    · simp only [toFieldTN, hr, if_true]
      exact measurable_const
    · simp only [toFieldTN, hr, if_false]
      exact (measurable_pi_apply r).comp (RoundRec.measurable_c.comp hrec)
  | s => exact RoundRec.measurable_sgn.comp hrec
  | delta m =>
    by_cases hm : m = 1
    · simp only [toFieldTN, hm, if_true]
      exact measurable_const
    · simp only [toFieldTN, hm, if_false]
      exact (measurable_pi_apply m).comp (RoundRec.measurable_delta.comp hrec)
  | haltAfter => exact measurable_toFieldTN_haltAfter α j

theorem measurable_toPublicHist (α : ℝ) (i : ℕ) :
    Measurable (toPublicHist α : (Fin i → RoundRec) → Fin i → PubRec) := by
  refine measurable_pi_lambda _ fun j => ?_
  refine Measurable.prodMk ?_ (measurable_toFieldTN α j)
  exact V2Meas.measurable_clip01V2.comp (RoundRec.measurable_answer.comp (measurable_pi_apply j))

/-! ## Generic `recRun` unfolding -/

/-- The query values fed to round `i` of the generic interaction. -/
def recVals {X ΩM ΩA R : Type} {n : ℕ} (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) (i : ℕ) :
    Fin (i + 1) → Fin n → ℝ :=
  fun j ℓ => A j.val (fun l : Fin j.val =>
    recRun mech A S ωM ωA i (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) ωA (S ℓ)

theorem recRun_succ_last {X ΩM ΩA R : Type} {n : ℕ} (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) (i : ℕ) :
    recRun mech A S ωM ωA (i + 1) (Fin.last i) = mech i (recVals mech A S ωM ωA i) ωM := by
  simp only [recRun, Fin.snoc_last]
  rfl

theorem recRun_succ_castSucc {X ΩM ΩA R : Type} {n : ℕ}
    (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) (i : ℕ) (j : Fin i) :
    recRun mech A S ωM ωA (i + 1) (Fin.castSucc j) = recRun mech A S ωM ωA i j := by
  simp only [recRun, Fin.snoc_castSucc]

/-! ## The interaction -/

section Interaction

variable {k : ℕ} {α β : ℝ}

theorem roundRec_answer_mem (qv : ℕ → Fin (adaSampleSize k α β) → ℝ) (ω' : AdaOmega k α) (i : ℕ) :
    (roundRec k α β qv ω' i).answer ∈ Set.Icc (0 : ℝ) 1 := by
  cases hh : (run k α β qv ω' i).halt with
  | true =>
    rw [roundRec_of_halt hh]
    exact ⟨le_refl 0, zero_le_one⟩
  | false =>
    rw [roundRec_of_not_halt hh]
    exact (roundChain (run k α β qv ω' i) i (qv i) ω').answer_mem (clip01_mem _)

/-- **The interaction.** If `qv` are the query values of the record analyst `Bd α B` on the run, then v2's
public outputs (deterministic public analyst `B`, coins `ω`) are the `toPublic` images of A-ARCH's records
on the coins `φ ω` (on `Good`). -/
theorem recRun_cascade_aux (hα : 0 < α) {X : Type} (B : (i : ℕ) → (Fin i → PubRec) → X → ℝ)
    (S : Fin (F2e2e.adaSampleSize k α β) → X) {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ}
    (hω : Good ω) (qv : ℕ → Fin (adaSampleSize k α β) → ℝ)
    (hqv : ∀ j, qv j = fun ℓ =>
      B j (toPublicHist α (fun l : Fin j => roundRec k α β qv (coinMap k α ω) l)) (S ℓ))
    (i : ℕ) :
    recRun (R := PubRec) (F2e2e.adaCascade k α β) (toRand B) S ω () i =
      fun j : Fin i => toPublic (run k α β qv (coinMap k α ω) j) (roundRec k α β qv (coinMap k α ω) j) := by
  induction i with
  | zero =>
    funext j
    exact j.elim0
  | succ i ih =>
    have hvals : recVals (R := PubRec) (F2e2e.adaCascade k α β) (toRand B) S ω () i =
        fun j => qv j.val := by
      funext j ℓ
      rw [hqv j.val]
      show B j.val (fun l : Fin j.val =>
          recRun (R := PubRec) (F2e2e.adaCascade k α β) (toRand B) S ω () i
            (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) (S ℓ) =
        B j.val (toPublicHist α (fun l : Fin j.val => roundRec k α β qv (coinMap k α ω) l)) (S ℓ)
      rw [ih, toPublicHist_run]
      rfl
    have hext : ∀ j ≤ i, extendVals (fun j : Fin (i + 1) => qv j.val) j = qv j := by
      intro j hj
      unfold extendVals
      rw [dif_pos (by omega)]
    have hrun : run k α β (extendVals (fun j : Fin (i + 1) => qv j.val)) (coinMap k α ω) i =
        run k α β qv (coinMap k α ω) i :=
      run_congr (coinMap k α ω) (fun j hj => hext j hj.le)
    have hrec : roundRec k α β (extendVals (fun j : Fin (i + 1) => qv j.val)) (coinMap k α ω) i =
        roundRec k α β qv (coinMap k α ω) i :=
      roundRec_congr (coinMap k α ω) hext
    have hcas := cascade_eq (β := β) hα hω i (fun j => qv j.val)
    funext j
    induction j using Fin.lastCases with
    | last =>
      rw [recRun_succ_last (R := PubRec) (F2e2e.adaCascade k α β) (toRand B) S ω () i, hvals, hcas, hrun,
        hrec]
      rfl
    | cast j =>
      rw [recRun_succ_castSucc (R := PubRec) (F2e2e.adaCascade k α β) (toRand B) S ω () i j, ih]
      rfl

theorem onlineQ_Bd {X : Type} (B : (i : ℕ) → (Fin i → PubRec) → X → ℝ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) (j : ℕ) :
    onlineQ k α β (Bd α B) S ω' j = fun ℓ =>
      B j (toPublicHist α (fun l : Fin j => roundRec k α β (onlineQ k α β (Bd α B) S ω') ω' l)) (S ℓ) := by
  funext ℓ
  show B j (toPublicHist α (answersOf (onlineRun k α β (Bd α B) S ω' j).2)) (S ℓ) = _
  have e : answersOf (onlineRun k α β (Bd α B) S ω' j).2 =
      fun l : Fin j => roundRec k α β (onlineQ k α β (Bd α B) S ω') ω' l :=
    funext fun l => (onlineRun_eq (Bd α B) S ω' j).2 l
  rw [e]

/-- **The failure events agree** (on `Good`): v2's failure event for a deterministic public analyst `B` is
A-ARCH's transcript failure event for the induced record analyst `Bd α B` on the coins `φ ω`. -/
theorem fails_iff (hα : 0 < α) {X : Type} [MeasurableSpace X] (D : Measure X)
    (B : (i : ℕ) → (Fin i → PubRec) → X → ℝ) (S : Fin (F2e2e.adaSampleSize k α β) → X)
    {ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ} (hω : Good ω) :
    recFails (R := PubRec) (fun r => (r.1 : ℝ)) (F2e2e.adaCascade k α β) (toRand B) D k α S ω () ↔
      ∃ i : Fin k, α < |(transcript k α β (Bd α B) S (coinMap k α ω) i).answer -
        popMu D (Bd α B) (transcript k α β (Bd α B) S (coinMap k α ω)) i| := by
  have hrun := recRun_cascade_aux hα B S hω (onlineQ k α β (Bd α B) S (coinMap k α ω))
    (onlineQ_Bd B S (coinMap k α ω)) k
  unfold recFails
  rw [hrun]
  refine exists_congr fun i => ?_
  have hmem := roundRec_answer_mem (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω) i
  have htr := transcript_eq_roundRec (Bd α B) S (coinMap k α ω) i
  have e1 : ((toPublic (run k α β (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω) i)
      (roundRec k α β (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω) i)).1 : ℝ) =
      (transcript k α β (Bd α B) S (coinMap k α ω) i).answer := by
    rw [htr]
    show min 1 (max 0 _) = _
    rw [max_eq_right hmem.1, min_eq_right hmem.2]
  have eh : histAns (transcript k α β (Bd α B) S (coinMap k α ω)) i =
      fun l : Fin i.val => roundRec k α β (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω) l := by
    funext l
    unfold histAns
    rw [dif_pos (lt_trans l.isLt i.isLt)]
    exact transcript_eq_roundRec (Bd α B) S (coinMap k α ω) _
  have e2 : (fun l : Fin i.val =>
      toPublic (run k α β (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω)
        (Fin.castLE (le_of_lt i.isLt) l))
        (roundRec k α β (onlineQ k α β (Bd α B) S (coinMap k α ω)) (coinMap k α ω)
          (Fin.castLE (le_of_lt i.isLt) l))) =
      toPublicHist α (histAns (transcript k α β (Bd α B) S (coinMap k α ω)) i) := by
    rw [eh, toPublicHist_run]
    rfl
  simp only [toRand]
  rw [e1, e2]
  rfl

/-! ## The guarantee -/

/-- The deterministic-analyst bound for v2's cascade, from A-ARCH's `adaMech_accurate_det`. -/
theorem det_bound (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    {Y : Type} [MeasurableSpace Y] (D : Measure Y) [IsProbabilityMeasure D]
    (B : (i : ℕ) → (Fin i → PubRec) → Y → ℝ) (hBv : ∀ i h x, 0 ≤ B i h x ∧ B i h x ≤ 1)
    (hBm : ∀ i, Measurable (fun p : (Fin i → PubRec) × Y => B i p.1 p.2)) :
    ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod (F2e2e.adaCoinLaw k α β))
      {z | recFails (R := PubRec) (fun r => (r.1 : ℝ)) (F2e2e.adaCascade k α β) (toRand B) D k α
        z.1 z.2 ()} ≤ ENNReal.ofReal β := by
  have hb : 0 < F2e2e.adaBsvt k α β := adaBsvt_pos hα hα' hβ hβ' hk
  have hP := V2Meas.isProbabilityMeasure_adaCoinLaw hb
  have hA : (Bd α B).Valid := fun i h x => hBv i (toPublicHist α h) x
  have hAm : (Bd α B).JointlyMeasurable := fun i =>
    (hBm i).comp (((measurable_toPublicHist α i).comp measurable_fst).prodMk measurable_snd)
  have hacc := adaMech_accurate_det k α β hk hα hα' hβ hβ' D (Bd α B) hA hAm
  have hsub : {z : (Fin (F2e2e.adaSampleSize k α β) → Y) × (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) |
      recFails (R := PubRec) (fun r => (r.1 : ℝ)) (F2e2e.adaCascade k α β) (toRand B) D k α z.1 z.2 ()} ⊆
      (Prod.map id (coinMap k α)) ⁻¹'
        {z : (Fin (adaSampleSize k α β) → Y) × AdaOmega k α | ∃ i : Fin k,
          α < |(transcript k α β (Bd α B) z.1 z.2 i).answer -
            popMu D (Bd α B) (transcript k α β (Bd α B) z.1 z.2) i|} ∪ {z | ¬ Good z.2} := by
    intro z hz
    by_cases hg : Good z.2
    · left
      exact (fails_iff hα D B z.1 hg).mp hz
    · right
      exact hg
  have hmap : ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod
      (F2e2e.adaCoinLaw k α β)).map (Prod.map id (coinMap k α)) = adaProb k α β D := by
    rw [← Measure.map_prod_map (Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D)
      (F2e2e.adaCoinLaw k α β) measurable_id measurable_coinMap, Measure.map_id,
      map_coinMap hk hα hα' hβ hβ']
    rfl
  have hnull : ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod
      (F2e2e.adaCoinLaw k α β)) {z | ¬ Good z.2} = 0 := by
    have e : {z : (Fin (F2e2e.adaSampleSize k α β) → Y) × (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) |
        ¬ Good z.2} = Set.univ ×ˢ {ω | ¬ Good ω} := by
      ext z
      simp
    rw [e, Measure.prod_prod, measure_not_good hk hα hα' hβ hβ', mul_zero]
  calc _ ≤ ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod (F2e2e.adaCoinLaw k α β))
        ((Prod.map id (coinMap k α)) ⁻¹'
          {z : (Fin (adaSampleSize k α β) → Y) × AdaOmega k α | ∃ i : Fin k,
            α < |(transcript k α β (Bd α B) z.1 z.2 i).answer -
              popMu D (Bd α B) (transcript k α β (Bd α B) z.1 z.2) i|} ∪ {z | ¬ Good z.2}) :=
        measure_mono hsub
    _ ≤ ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod (F2e2e.adaCoinLaw k α β))
          ((Prod.map id (coinMap k α)) ⁻¹'
            {z : (Fin (adaSampleSize k α β) → Y) × AdaOmega k α | ∃ i : Fin k,
              α < |(transcript k α β (Bd α B) z.1 z.2 i).answer -
                popMu D (Bd α B) (transcript k α β (Bd α B) z.1 z.2) i|}) +
        ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod (F2e2e.adaCoinLaw k α β))
          {z | ¬ Good z.2} := measure_union_le _ _
    _ ≤ (((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D).prod
          (F2e2e.adaCoinLaw k α β)).map (Prod.map id (coinMap k α)))
          {z : (Fin (adaSampleSize k α β) → Y) × AdaOmega k α | ∃ i : Fin k,
            α < |(transcript k α β (Bd α B) z.1 z.2 i).answer -
              popMu D (Bd α B) (transcript k α β (Bd α B) z.1 z.2) i|} := by
        rw [hnull, add_zero]
        exact Measure.le_map_apply (measurable_id.prodMap measurable_coinMap).aemeasurable _
    _ = adaProb k α β D {z | ∃ i : Fin k, α < |(transcript k α β (Bd α B) z.1 z.2 i).answer -
          popMu D (Bd α B) (transcript k α β (Bd α B) z.1 z.2) i|} := by
        rw [hmap]
    _ ≤ ENNReal.ofReal β := hacc

/-- **Conjunct 4 of `Theorem_A_statistical` (v2 candidate)**: v2's cascade with its coin law is
simultaneously `(α, β)`-accurate against every randomized analyst that sees the public records. -/
theorem adaPublicGuarantee_adaCascade (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) :
    F2e2e.ADAPublicGuarantee (F2e2e.adaSampleSize k α β) k α β (F2e2e.adaCoinLaw k α β)
      (F2e2e.adaCascade k α β) := by
  have hb : 0 < F2e2e.adaBsvt k α β := adaBsvt_pos hα hα' hβ hβ' hk
  have hP := V2Meas.isProbabilityMeasure_adaCoinLaw hb
  have hmech := V2Meas.jointlyMeasurable_adaCascade (k := k) (β := β) hα
  have hdet : ∀ (Y : Type) [MeasurableSpace Y] (D' : Measure Y) [IsProbabilityMeasure D']
      (B : (i : ℕ) → (Fin i → PubRec) → Y → ℝ), (∀ i h x, 0 ≤ B i h x ∧ B i h x ≤ 1) →
      (∀ i, Measurable (fun p : (Fin i → PubRec) × Y => B i p.1 p.2)) →
        ((Measure.pi fun _ : Fin (F2e2e.adaSampleSize k α β) => D').prod (F2e2e.adaCoinLaw k α β))
          {z | recFails (R := PubRec) (fun r => (r.1 : ℝ)) (F2e2e.adaCascade k α β) (toRand B) D' k α
            z.1 z.2 ()} ≤ ENNReal.ofReal β :=
    fun Y _ D' _ B hBv hBm => det_bound hk hα hα' hβ hβ' D' B hBv hBm
  intro X _ D _ ΩA _ PA _ A hAv hAm
  have key := recGuarantee_of_det (ΩM := F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) (R := PubRec)
    (n := F2e2e.adaSampleSize k α β) (ans := fun r => (r.1 : ℝ)) (k := k) (α := α) (β := β)
    (measurable_subtype_coe.comp measurable_fst) (F2e2e.adaCoinLaw k α β)
    (mech := F2e2e.adaCascade k α β) hmech hdet X D ΩA PA A hAv hAm
  refine le_trans (measure_mono fun z hz => ?_) key
  simp only [Set.mem_ofPred_eq] at hz ⊢
  exact (adaPublicFails_iff (F2e2e.adaCascade k α β) A D k α z.1 z.2.1 z.2.2).mp hz

end Interaction

end

end F2e2e.A.V2Bridge
