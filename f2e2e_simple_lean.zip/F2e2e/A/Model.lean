import F2e2e.A.Mechanism

/-!
# Part I: the Tonelli–Fubini deterministic-analyst reduction (Lemma `I:lem:tonelli_fubini`)

Owner: worker A-NUM (taken over from A-ARCH). `parts/partI.tex` L71-99.

Paper statement (part (i)): if a randomized mechanism has failure probability at most `β` against every
*deterministic* adaptive analyst (in `D^n ⊗ P_M`), then it has failure probability at most `β` against
every *randomized* analyst (in `D^n ⊗ P_M ⊗ P_A`). Proof: for each fixed analyst seed `ω`, the conditioned
analyst `A_ω` is deterministic; by Tonelli the failure probability is `∫ P[fail | r_A = ω] dP_A(ω) ≤ β`.
Part (ii) (`μ_i` is a deterministic function of the transcript prefix) is built into the formal model: the
failure event `adaFails` integrates the query of round `i`, which is the analyst applied to the answers of
rounds `< i`.

This file proves the reduction **generically** (Section `Generic`) for any per-round public record type
`R` (with a measurable answer map `ans : R → ℝ`), any mechanism
`mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R` that is measurable in (query values, coins), and any
randomized analyst seeing the record history `Fin i → R`; the Spec v1 interface (`F2e2e.ADAMechanism`,
`F2e2e.adaAnswers`, `F2e2e.adaFails`) is the instance `R = ℝ`, `ans = id` (`adaAnswers_eq_recRun`,
`adaFails_iff_recFails`). A public-transcript interface (answer in `[0,1]` plus an auxiliary record, the
analyst seeing the records) is the instance `R = (answer × record)`, `ans = answer`.

Main results:
* `prod_prod_le_of_slices`: the Tonelli step (`(μ ⊗ (P_M ⊗ P_A)) F ≤ c` if every `ω_A`-slice has
  `(μ ⊗ P_M)`-measure `≤ c`, for measurable `F`);
* `measurable_recRun`, `measurable_recMean`, `measurableSet_recFails`: measurability of the answers, of the
  population means `μ_i = ∫ q_i dD`, and of the failure event;
* `recRun_fixCoins`, `recFails_fixCoins`: fixing the analyst's coins gives a deterministic analyst with the
  same run;
* `recGuarantee_of_slices`, `recGuarantee_of_det`: the generic reduction;
* `adaGuarantee_of_det`: the Spec v1 contract consumed by `Final.lean`.
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## The Tonelli step -/

/-- **Tonelli step.** For a measurable `F ⊆ S × (Ω_M × Ω_A)`: if for every `ω_A` the slice
`{(s, ω_M) | (s, (ω_M, ω_A)) ∈ F}` has `(μ ⊗ P_M)`-measure at most `c`, then `(μ ⊗ (P_M ⊗ P_A)) F ≤ c`
(`P_A` a probability measure). -/
theorem prod_prod_le_of_slices {S ΩM ΩA : Type} [MeasurableSpace S] [MeasurableSpace ΩM]
    [MeasurableSpace ΩA] (μ : Measure S) [SFinite μ] (PM : Measure ΩM) [SFinite PM]
    (PA : Measure ΩA) [IsProbabilityMeasure PA] {F : Set (S × (ΩM × ΩA))} (hF : MeasurableSet F)
    {c : ENNReal} (h : ∀ ωA : ΩA, (μ.prod PM) {z | (z.1, (z.2, ωA)) ∈ F} ≤ c) :
    (μ.prod (PM.prod PA)) F ≤ c := by
  rw [← (measurePreserving_prodAssoc μ PM PA).measure_preimage_equiv F,
    Measure.prod_apply_symm (MeasurableEquiv.prodAssoc.measurable hF)]
  calc ∫⁻ ωA, (μ.prod PM) ((fun x => (x, ωA)) ⁻¹' (MeasurableEquiv.prodAssoc ⁻¹' F)) ∂PA
      ≤ ∫⁻ _ : ΩA, c ∂PA := lintegral_mono (fun ωA => h ωA)
    _ = c := by rw [lintegral_const, measure_univ, mul_one]

/-! ## Generic adaptive interaction with public records -/

section Generic

variable {X ΩM ΩA R : Type} {n : ℕ}

/-- The records of the first `i` rounds of the interaction between a mechanism `mech` (outputting a
public record in `R` per round, from the values of the queries of rounds `0, …, i` on the sample and its
coins `ωM`) and a randomized analyst `A` (choosing the query of round `i` from the records of rounds
`< i` and its coins `ωA`) on the sample `S`. For `R = ℝ` this is `F2e2e.adaAnswers`. -/
def recRun (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) :
    (i : ℕ) → Fin i → R
  | 0 => Fin.elim0
  | i + 1 =>
      Fin.snoc (α := fun _ => R) (recRun mech A S ωM ωA i)
        (mech i
          (fun (j : Fin (i + 1)) (ℓ : Fin n) =>
            A j.val (fun l : Fin j.val =>
              recRun mech A S ωM ωA i (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) ωA (S ℓ))
          ωM)

/-- Failure event: the answer `ans r_i` of some round `i < k` is more than `α` away from the population
mean `∫ q_i dD` of the query of that round. For `R = ℝ`, `ans = id` this is `F2e2e.adaFails`. -/
def recFails [MeasurableSpace X] (ans : R → ℝ) (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (D : Measure X) (k : ℕ) (α : ℝ) (S : Fin n → X)
    (ωM : ΩM) (ωA : ΩA) : Prop :=
  ∃ i : Fin k, α < |ans (recRun mech A S ωM ωA k i) -
    ∫ x, A i.val (fun l : Fin i.val =>
      recRun mech A S ωM ωA k (Fin.castLE (le_of_lt i.isLt) l)) ωA x ∂D|

/-- A deterministic analyst (no coins) seen as a randomized analyst with coin space `Unit`. -/
def toRand (B : (i : ℕ) → (Fin i → R) → X → ℝ) : (i : ℕ) → (Fin i → R) → Unit → X → ℝ :=
  fun i h _ x => B i h x

/-- The deterministic analyst obtained by fixing the coins `ωA` of a randomized analyst. -/
def detFix (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (ωA : ΩA) : (i : ℕ) → (Fin i → R) → X → ℝ :=
  fun i h x => A i h ωA x

/-- Fixing the coins does not change the run. -/
theorem recRun_detFix (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) (i : ℕ) :
    recRun mech (toRand (detFix A ωA)) S ωM () i = recRun mech A S ωM ωA i := by
  induction i with
  | zero =>
    funext j
    exact j.elim0
  | succ i ih =>
    simp only [recRun, toRand, detFix, ih]

/-- Fixing the coins does not change the failure event. -/
theorem recFails_detFix [MeasurableSpace X] (ans : R → ℝ)
    (mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R)
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (D : Measure X) (k : ℕ) (α : ℝ) (S : Fin n → X)
    (ωM : ΩM) (ωA : ΩA) :
    recFails ans mech (toRand (detFix A ωA)) D k α S ωM () ↔ recFails ans mech A D k α S ωM ωA := by
  simp only [recFails, recRun_detFix]
  rfl

section Measurability

variable [MeasurableSpace X] [MeasurableSpace ΩM] [MeasurableSpace ΩA] [MeasurableSpace R]

/-- The records are measurable in (sample, mechanism coins, analyst coins). -/
theorem measurable_recRun {mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R}
    {A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ}
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    (hA : ∀ i, Measurable (fun p : ((Fin i → R) × ΩA) × X => A i p.1.1 p.1.2 p.2)) (i : ℕ) :
    Measurable (fun z : (Fin n → X) × (ΩM × ΩA) => recRun mech A z.1 z.2.1 z.2.2 i) := by
  induction i with
  | zero =>
    have e : (fun z : (Fin n → X) × (ΩM × ΩA) => recRun mech A z.1 z.2.1 z.2.2 0) =
        fun _ => Fin.elim0 := by
      funext z j
      exact j.elim0
    rw [e]
    exact measurable_const
  | succ i ih =>
    have hvals : Measurable (fun z : (Fin n → X) × (ΩM × ΩA) =>
        fun (j : Fin (i + 1)) (ℓ : Fin n) =>
          A j.val (fun l : Fin j.val =>
            recRun mech A z.1 z.2.1 z.2.2 i (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) z.2.2
            (z.1 ℓ)) := by
      apply measurable_pi_lambda
      intro j
      apply measurable_pi_lambda
      intro ℓ
      have h1 : Measurable (fun z : (Fin n → X) × (ΩM × ΩA) =>
          (((fun l : Fin j.val =>
            recRun mech A z.1 z.2.1 z.2.2 i (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)), z.2.2),
            z.1 ℓ)) := by
        refine Measurable.prodMk (Measurable.prodMk ?_ measurable_snd.snd)
          ((measurable_pi_apply ℓ).comp measurable_fst)
        apply measurable_pi_lambda
        intro l
        exact (measurable_pi_apply _).comp ih
      exact (hA j.val).comp h1
    have hlast : Measurable (fun z : (Fin n → X) × (ΩM × ΩA) =>
        mech i (fun (j : Fin (i + 1)) (ℓ : Fin n) =>
          A j.val (fun l : Fin j.val =>
            recRun mech A z.1 z.2.1 z.2.2 i (Fin.castLE (Nat.lt_succ_iff.mp j.isLt) l)) z.2.2
            (z.1 ℓ)) z.2.1) :=
      (hmech i).comp (hvals.prodMk measurable_snd.fst)
    apply measurable_pi_lambda
    intro j
    induction j using Fin.lastCases with
    | last =>
      simp only [recRun, Fin.snoc_last]
      exact hlast
    | cast j =>
      simp only [recRun, Fin.snoc_castSucc]
      exact (measurable_pi_apply j).comp ih

/-- The population means `μ_i = ∫ q_i dD` of the queries are measurable in (sample, coins). -/
theorem measurable_recMean {mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R}
    {A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ}
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    (hA : ∀ i, Measurable (fun p : ((Fin i → R) × ΩA) × X => A i p.1.1 p.1.2 p.2))
    (D : Measure X) [SFinite D] (k : ℕ) (i : Fin k) :
    Measurable (fun z : (Fin n → X) × (ΩM × ΩA) =>
      ∫ x, A i.val (fun l : Fin i.val =>
        recRun mech A z.1 z.2.1 z.2.2 k (Fin.castLE (le_of_lt i.isLt) l)) z.2.2 x ∂D) := by
  have hf : Measurable (fun p : ((Fin n → X) × (ΩM × ΩA)) × X =>
      A i.val (fun l : Fin i.val =>
        recRun mech A p.1.1 p.1.2.1 p.1.2.2 k (Fin.castLE (le_of_lt i.isLt) l)) p.1.2.2 p.2) := by
    refine (hA i.val).comp (Measurable.prodMk (Measurable.prodMk ?_ measurable_fst.snd.snd)
      measurable_snd)
    apply measurable_pi_lambda
    intro l
    exact (measurable_pi_apply _).comp ((measurable_recRun hmech hA k).comp measurable_fst)
  exact (hf.stronglyMeasurable.integral_prod_right' (ν := D)).measurable

/-- The failure event is measurable. -/
theorem measurableSet_recFails {ans : R → ℝ} (hans : Measurable ans)
    {mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R}
    {A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ}
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    (hA : ∀ i, Measurable (fun p : ((Fin i → R) × ΩA) × X => A i p.1.1 p.1.2 p.2))
    (D : Measure X) [SFinite D] (k : ℕ) (α : ℝ) :
    MeasurableSet {z : (Fin n → X) × (ΩM × ΩA) | recFails ans mech A D k α z.1 z.2.1 z.2.2} := by
  have e : {z : (Fin n → X) × (ΩM × ΩA) | recFails ans mech A D k α z.1 z.2.1 z.2.2} =
      ⋃ i : Fin k, {z : (Fin n → X) × (ΩM × ΩA) | α < |ans (recRun mech A z.1 z.2.1 z.2.2 k i) -
        ∫ x, A i.val (fun l : Fin i.val =>
          recRun mech A z.1 z.2.1 z.2.2 k (Fin.castLE (le_of_lt i.isLt) l)) z.2.2 x ∂D|} := by
    ext z
    simp only [recFails, Set.mem_ofPred_eq, Set.mem_iUnion]
  rw [e]
  refine MeasurableSet.iUnion (fun i => measurableSet_lt measurable_const ?_)
  exact continuous_abs.measurable.comp
    ((hans.comp ((measurable_pi_apply i).comp (measurable_recRun hmech hA k))).sub
      (measurable_recMean hmech hA D k i))

end Measurability

/-- **Generic reduction, slice form.** If, for every seed `ωA` of a randomized analyst `A`, the
conditioned (deterministic) analyst fails with `(D^n ⊗ P_M)`-probability at most `β`, then `A` fails
with `(D^n ⊗ (P_M ⊗ P_A))`-probability at most `β`. -/
theorem recGuarantee_of_slices [MeasurableSpace ΩM] [MeasurableSpace R] {ans : R → ℝ}
    (hans : Measurable ans) {k : ℕ} {α β : ℝ} (PM : Measure ΩM) [IsProbabilityMeasure PM]
    {mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R}
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D]
    [MeasurableSpace ΩA] (PA : Measure ΩA) [IsProbabilityMeasure PA]
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ)
    (hA : ∀ i, Measurable (fun p : ((Fin i → R) × ΩA) × X => A i p.1.1 p.1.2 p.2))
    (hdet : ∀ ωA : ΩA, ((Measure.pi fun _ : Fin n => D).prod PM)
      {z | recFails ans mech (toRand (detFix A ωA)) D k α z.1 z.2 ()} ≤ ENNReal.ofReal β) :
    ((Measure.pi fun _ : Fin n => D).prod (PM.prod PA))
      {z | recFails ans mech A D k α z.1 z.2.1 z.2.2} ≤ ENNReal.ofReal β := by
  apply prod_prod_le_of_slices _ PM PA (measurableSet_recFails hans hmech hA D k α)
  intro ωA
  have h := hdet ωA
  simp only [recFails_detFix] at h
  exact h

/-- **Generic reduction (Lemma `I:lem:tonelli_fubini`(i)).** A mechanism (measurable in (query values,
coins)) whose failure probability is at most `β` against every valid jointly measurable deterministic
analyst has failure probability at most `β` against every valid jointly measurable randomized analyst,
for any record type `R` and measurable answer map `ans`. -/
theorem recGuarantee_of_det [MeasurableSpace ΩM] [MeasurableSpace R] {ans : R → ℝ}
    (hans : Measurable ans) {k : ℕ} {α β : ℝ} (PM : Measure ΩM) [IsProbabilityMeasure PM]
    {mech : (i : ℕ) → (Fin (i + 1) → Fin n → ℝ) → ΩM → R}
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    (hdet : ∀ (X : Type) [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D]
      (B : (i : ℕ) → (Fin i → R) → X → ℝ), (∀ i h x, 0 ≤ B i h x ∧ B i h x ≤ 1) →
      (∀ i, Measurable (fun p : (Fin i → R) × X => B i p.1 p.2)) →
        ((Measure.pi fun _ : Fin n => D).prod PM) {z | recFails ans mech (toRand B) D k α z.1 z.2 ()} ≤
          ENNReal.ofReal β)
    (X : Type) [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D]
    (ΩA : Type) [MeasurableSpace ΩA] (PA : Measure ΩA) [IsProbabilityMeasure PA]
    (A : (i : ℕ) → (Fin i → R) → ΩA → X → ℝ) (hAv : ∀ i h ω x, 0 ≤ A i h ω x ∧ A i h ω x ≤ 1)
    (hA : ∀ i, Measurable (fun p : ((Fin i → R) × ΩA) × X => A i p.1.1 p.1.2 p.2)) :
    ((Measure.pi fun _ : Fin n => D).prod (PM.prod PA))
      {z | recFails ans mech A D k α z.1 z.2.1 z.2.2} ≤ ENNReal.ofReal β := by
  refine recGuarantee_of_slices hans PM hmech D PA A hA (fun ωA => ?_)
  refine hdet X D (detFix A ωA) (fun i h x => hAv i h ωA x) (fun i => ?_)
  exact (hA i).comp ((measurable_fst.prodMk measurable_const).prodMk measurable_snd)

end Generic

/-! ## The Spec v1 instance -/

section SpecV1

variable {X ΩM ΩA : Type} {n : ℕ}

/-- The Spec's answers are the generic records for `R = ℝ`. -/
theorem adaAnswers_eq_recRun (mech : ADAMechanism n ΩM) (A : ADAAnalyst X ΩA) (S : Fin n → X)
    (ωM : ΩM) (ωA : ΩA) (i : ℕ) : adaAnswers mech A S ωM ωA i = recRun mech A S ωM ωA i := by
  induction i with
  | zero =>
    funext j
    exact j.elim0
  | succ i ih =>
    simp only [adaAnswers, recRun, ih]

/-- The Spec's failure event is the generic one for `R = ℝ`, `ans = id`. -/
theorem adaFails_iff_recFails [MeasurableSpace X] (mech : ADAMechanism n ΩM) (A : ADAAnalyst X ΩA)
    (D : Measure X) (k : ℕ) (α : ℝ) (S : Fin n → X) (ωM : ΩM) (ωA : ΩA) :
    adaFails mech A D k α S ωM ωA ↔ recFails id mech A D k α S ωM ωA := by
  simp only [adaFails, recFails, adaAnswers_eq_recRun, id]

/-- **Lemma `I:lem:tonelli_fubini`(i), Spec v1 form** (the contract consumed by `Final.lean`): a mechanism
measurable in (query values, coins) whose failure probability against every valid jointly measurable
deterministic analyst is at most `β` satisfies `ADAGuarantee` (randomized analysts on any coin probability
space). -/
theorem adaGuarantee_of_det {n k : ℕ} {α β : ℝ} {ΩM : Type} [MeasurableSpace ΩM] (PM : Measure ΩM)
    [IsProbabilityMeasure PM] (mech : ADAMechanism n ΩM)
    (hmech : ∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2))
    (hdet : ∀ (X : Type) [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D]
      (A : AnsAnalyst X), A.Valid → A.JointlyMeasurable →
        ((Measure.pi fun _ : Fin n => D).prod PM) {z | adaFails mech A.toADA D k α z.1 z.2 ()} ≤
          ENNReal.ofReal β) :
    ADAGuarantee n k α β PM mech := by
  intro X _ D _ ΩA _ PA _ A hAv hAm
  have hset : {z : (Fin n → X) × (ΩM × ΩA) | adaFails mech A D k α z.1 z.2.1 z.2.2} =
      {z | recFails id mech A D k α z.1 z.2.1 z.2.2} := by
    ext z
    exact adaFails_iff_recFails mech A D k α z.1 z.2.1 z.2.2
  rw [hset]
  refine recGuarantee_of_det measurable_id PM hmech (fun Y _ D' _ B hBv hBm => ?_) X D ΩA PA A hAv hAm
  have h := hdet Y D' B hBv hBm
  have hset' : {z : (Fin n → Y) × ΩM | adaFails mech (AnsAnalyst.toADA B) D' k α z.1 z.2 ()} =
      {z | recFails id mech (toRand B) D' k α z.1 z.2 ()} := by
    ext z
    exact adaFails_iff_recFails mech (AnsAnalyst.toADA B) D' k α z.1 z.2 ()
  rw [hset'] at h
  exact h

end SpecV1

end A

end F2e2e
