import F2e2e.A.NumericsCaps

/-!
# Part I numerics: validator sample sizes and the explicit bound

Proposition `I:prop:validator_sample_complexity`(2),(3) (`parts/partI.tex` L2116-2131, proof L2153-2178):
with `Λ_SVT = ln(64 L k M_{2,max}/δ_val)` (so `1/b_SVT = 256 L Λ_SVT/α`) and `ρ = α^{-1/(L-1)} < e`,
* `√M_{r,max}/(b_SVT ε_r) ≤ 28160 ρ L^{5/2} Λ_SVT/α²` (`2 ≤ r ≤ L-1`, `I:eq:sec6_interior_nr_scaling`);
* `√M_{L,max}/(b_SVT ε_L) ≤ 593300 ρ L^{7/2} Λ_SVT/α²` (`I:eq:sec6_terminal_nL_scaling`);
* the Ghost-Monitor term `16 ln(6k/δ_val)/(r_anc ε_L) = 1048576 L² ln(6k/δ_val)/α²`;
* `∑_{r=2}^{L} n_r ≤ 10⁸ L^{7/2} Λ_SVT √L_val/α²` (`I:eq:sec6_validator_sum_explicit`, ceilings included).

`L^{7/2}` is written `L³ √L` and `L^{5/2}` is written `L² √L`, as in `F2e2e.adaExplicitBound`.
-/

namespace F2e2e

namespace A

section Sample

variable {α β : ℝ}

/-- `√5 > 2.2`. -/
lemma sqrt_five_gt : (2.2 : ℝ) < Real.sqrt 5 := by
  rw [Real.lt_sqrt (by norm_num)]
  norm_num

/-- `√L ≥ 2.2`. -/
lemma sqrt_adaL_ge (hα : 0 < α) (hα' : α < 1 / 16) : (2.2 : ℝ) ≤ Real.sqrt (adaL α : ℝ) :=
  sqrt_five_gt.le.trans (Real.sqrt_le_sqrt (five_le_adaL_real hα hα'))

/-- `√L_val > 7`. -/
lemma sqrt_adaLval_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (7 : ℝ) < Real.sqrt (adaLval α β) := by
  rw [Real.lt_sqrt (by norm_num)]
  have := adaLval_gt hα hα' hβ hβ'
  linarith

/-- Interior per-level ratio (`I:eq:sec6_nr_bound_explicit`):
`√M_{r,max}/(b_SVT ε_r) ≤ 28160 ρ L^{5/2} Λ_SVT/α²` for `2 ≤ r ≤ L - 1`. -/
lemma interior_ratio_le (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α - 1) :
    Real.sqrt (adaMmax α r : ℝ) / (adaBsvt k α β * adaEps α r) ≤
      28160 * α ^ (-(1 / ((adaL α : ℝ) - 1))) * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) *
        Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) / α ^ 2 := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hEr := adaEps_pos hα r
  have hρε : adaEps α (r - 1) = α ^ (-(1 / ((adaL α : ℝ) - 1))) * adaEps α r := by
    have := adaEps_eq_rho_mul_succ hα (r := r - 1) (by omega)
    rwa [show r - 1 + 1 = r by omega] at this
  have hsq := sqrt_adaMmax_le hα hα' hr2 (by omega : r ≤ adaL α)
  rw [hρε] at hsq
  have hΛ := log_svt_pos hα hα' hβ hβ' hk
  have hL := adaL_pos_real hα hα'
  rw [div_le_iff₀ (mul_pos hb hEr), adaBsvt_eq]
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  have hα0 : α ≠ 0 := hα.ne'
  have hL0 : (adaL α : ℝ) ≠ 0 := hL.ne'
  have hΛ0 : Λ ≠ 0 := hΛ.ne'
  calc Real.sqrt (adaMmax α r : ℝ)
      ≤ 110 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) *
          (α ^ (-(1 / ((adaL α : ℝ) - 1))) * adaEps α r) / α := hsq
    _ = 28160 * α ^ (-(1 / ((adaL α : ℝ) - 1))) * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) * Λ /
          α ^ 2 * (α / (256 * (adaL α : ℝ) * Λ) * adaEps α r) := by
        field_simp
        ring

/-- Anchor ratio (`I:eq:sec6_anchor_ratio_explicit`):
`√M_{L,max}/(b_SVT ε_L) ≤ 593300 ρ L^{7/2} Λ_SVT/α²`. -/
lemma anchor_ratio_le (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    Real.sqrt (adaMmax α (adaL α) : ℝ) / (adaBsvt k α β * adaEpsL α) ≤
      593300 * α ^ (-(1 / ((adaL α : ℝ) - 1))) * (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) *
        Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) / α ^ 2 := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hεL := adaEpsL_pos hα
  have hsq := sqrt_adaMmax_L_le hα hα'
  rw [adaEps_L_sub_one hα hα'] at hsq
  have hΛ := log_svt_pos hα hα' hβ hβ' hk
  have hL := adaL_pos_real hα hα'
  have hρ := rho_pos (α := α) hα
  rw [div_le_iff₀ (mul_pos hb hεL), adaBsvt_eq, adaEpsL_eq]
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  set ρ := α ^ (-(1 / ((adaL α : ℝ) - 1))) with hρdef
  have hα0 : α ≠ 0 := hα.ne'
  have hL0 : (adaL α : ℝ) ≠ 0 := hL.ne'
  have hΛ0 : Λ ≠ 0 := hΛ.ne'
  have e1 : 90.53 * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) * (1 / 20 * α * ρ) / α =
      90.53 / 20 * (ρ * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ)) := by
    field_simp
  have e2 : 593300 * ρ * (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) * Λ / α ^ 2 *
      (α / (256 * (adaL α : ℝ) * Λ) * (α / (512 * (adaL α : ℝ)))) =
      593300 / 131072 * (ρ * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ)) := by
    field_simp
    ring
  rw [e2]
  rw [e1] at hsq
  have h0 : 0 ≤ ρ * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ) := by positivity
  calc Real.sqrt (adaMmax α (adaL α) : ℝ) ≤ 90.53 / 20 * (ρ * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ)) :=
        hsq
    _ ≤ 593300 / 131072 * (ρ * (adaL α : ℝ) * Real.sqrt (adaL α : ℝ)) :=
        mul_le_mul_of_nonneg_right (by norm_num) h0

/-- Ghost-Monitor term (`I:eq:sec6_nL_term2_explicit`):
`16 ln(6k/δ_val)/(r_anc ε_L) = 1048576 L² ln(6k/δ_val)/α²`. -/
lemma ghost_eq (k : ℕ) (α β : ℝ) :
    16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) =
      1048576 * (adaL α : ℝ) ^ 2 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / α ^ 2 := by
  rw [adaRanc_eq, adaEpsL_eq]
  rw [div_mul_div_comm, div_div_eq_mul_div]
  ring

/-- Interior validator sample size: `n_r < 110·28160 ρ L^{5/2} Λ_SVT √L_val/α² + 1`, `2 ≤ r ≤ L - 1`. -/
lemma adaNr_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α - 1) :
    (adaNr k α β r : ℝ) <
      110 * 28160 * α ^ (-(1 / ((adaL α : ℝ) - 1))) * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) *
        Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) *
        Real.sqrt (adaLval α β) / α ^ 2 + 1 := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hEr := adaEps_pos hα r
  have hratio := interior_ratio_le hα hα' hβ hβ' hk hr2 hrL
  have hM0 : (0 : ℝ) ≤ (adaMmax α r : ℝ) := Nat.cast_nonneg _
  unfold adaNr
  have harg0 : 0 ≤ 110 * Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) / (adaBsvt k α β * adaEps α r) :=
    div_nonneg (by positivity) (mul_pos hb hEr).le
  have h1 := Nat.ceil_lt_add_one harg0
  have h2 : 110 * Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) / (adaBsvt k α β * adaEps α r) =
      110 * Real.sqrt (adaLval α β) *
        (Real.sqrt (adaMmax α r : ℝ) / (adaBsvt k α β * adaEps α r)) := by
    rw [Real.sqrt_mul hM0]
    ring
  have h3 := mul_le_mul_of_nonneg_left hratio
    (by positivity : (0 : ℝ) ≤ 110 * Real.sqrt (adaLval α β))
  set ρ := α ^ (-(1 / ((adaL α : ℝ) - 1))) with hρdef
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  have e : 110 * Real.sqrt (adaLval α β) *
      (28160 * ρ * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) * Λ / α ^ 2) =
      110 * 28160 * ρ * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) * Λ * Real.sqrt (adaLval α β) /
        α ^ 2 := by ring
  linarith

/-- Interior sum (`I:eq:sec6_sum_interior_nr`):
`∑_{r=2}^{L-1} n_r ≤ 8420150 L^{7/2} Λ_SVT √L_val/α² + L` (`110·28160·e < 8420150`). -/
lemma sum_adaNr_le (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    ∑ r ∈ Finset.Icc 2 (adaL α - 1), (adaNr k α β r : ℝ) ≤
      8420150 * ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) *
        Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) *
        Real.sqrt (adaLval α β) / α ^ 2) + (adaL α : ℝ) := by
  have hL5 := five_le_adaL_real hα hα'
  have hL5n := five_le_adaL hα hα'
  have hρe := rho_lt_e_d9 hα hα'
  have hρ0 := rho_pos (α := α) hα
  have hΛ := log_svt_pos hα hα' hβ hβ' hk
  have hpt := fun r (hr : r ∈ Finset.Icc 2 (adaL α - 1)) =>
    (adaNr_lt hα hα' hβ hβ' hk (Finset.mem_Icc.mp hr).1 (Finset.mem_Icc.mp hr).2).le
  set ρ := α ^ (-(1 / ((adaL α : ℝ) - 1))) with hρdef
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  set T := (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) * Λ * Real.sqrt (adaLval α β) / α ^ 2 with hTdef
  have hT0 : 0 ≤ T := by positivity
  have hpt' : ∀ r ∈ Finset.Icc 2 (adaL α - 1), (adaNr k α β r : ℝ) ≤ 3097600 * ρ * T + 1 := by
    intro r hr
    have h := hpt r hr
    have e : 110 * 28160 * ρ * (adaL α : ℝ) ^ 2 * Real.sqrt (adaL α : ℝ) * Λ *
        Real.sqrt (adaLval α β) / α ^ 2 = 3097600 * ρ * T := by
      rw [hTdef]
      ring
    linarith
  have hcard : ((Finset.Icc 2 (adaL α - 1)).card : ℝ) = (adaL α : ℝ) - 2 := by
    rw [Nat.card_Icc, show adaL α - 1 + 1 - 2 = adaL α - 2 by omega, Nat.cast_sub (by omega)]
    push_cast
    ring
  have hsum : ∑ r ∈ Finset.Icc 2 (adaL α - 1), (adaNr k α β r : ℝ) ≤
      ((adaL α : ℝ) - 2) * (3097600 * ρ * T + 1) := by
    calc ∑ r ∈ Finset.Icc 2 (adaL α - 1), (adaNr k α β r : ℝ)
        ≤ ∑ _r ∈ Finset.Icc 2 (adaL α - 1), (3097600 * ρ * T + 1) := Finset.sum_le_sum hpt'
      _ = ((adaL α : ℝ) - 2) * (3097600 * ρ * T + 1) := by
        rw [Finset.sum_const, nsmul_eq_mul, hcard]
  have h3 : 3097600 * ρ * T ≤ 3097600 * 2.7182818286 * T := by gcongr
  have h4 : ((adaL α : ℝ) - 2) * (3097600 * ρ * T) ≤ (adaL α : ℝ) * (3097600 * 2.7182818286 * T) :=
    mul_le_mul (by linarith) h3 (by positivity) (by linarith)
  have h5 : (adaL α : ℝ) * (3097600 * 2.7182818286 * T) ≤ 8420150 * ((adaL α : ℝ) * T) := by
    have : (0 : ℝ) ≤ (adaL α : ℝ) * T := by positivity
    nlinarith
  have e2 : (adaL α : ℝ) * T = (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) * Λ *
      Real.sqrt (adaLval α β) / α ^ 2 := by
    rw [hTdef]
    ring
  rw [← e2]
  nlinarith

/-- Anchor sample size:
`n_L < 55·593300 ρ L^{7/2} Λ_SVT √L_val/α² + 1048576 L² ln(6k/δ_val)/α² + 1`. -/
lemma adaNL_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    (adaNL k α β : ℝ) <
      55 * 593300 * α ^ (-(1 / ((adaL α : ℝ) - 1))) * (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) *
          Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) *
          Real.sqrt (adaLval α β) / α ^ 2 +
        1048576 * (adaL α : ℝ) ^ 2 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / α ^ 2 + 1 := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hεL := adaEpsL_pos hα
  have hranc := adaRanc_pos hα
  have hlog6 : 0 < Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
    have := log_six_k_gt hα hα' hβ hβ' hk
    linarith
  have hratio := anchor_ratio_le hα hα' hβ hβ' hk
  have hM0 : (0 : ℝ) ≤ (adaMmax α (adaL α) : ℝ) := Nat.cast_nonneg _
  unfold adaNL
  have harg0 : 0 ≤ 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) /
        (adaBsvt k α β * adaEpsL α) +
      16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) :=
    add_nonneg (div_nonneg (by positivity) (mul_pos hb hεL).le)
      (div_nonneg (by positivity) (mul_pos hranc hεL).le)
  have h1 := Nat.ceil_lt_add_one harg0
  have h2 : 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) / (adaBsvt k α β * adaEpsL α) =
      55 * Real.sqrt (adaLval α β) *
        (Real.sqrt (adaMmax α (adaL α) : ℝ) / (adaBsvt k α β * adaEpsL α)) := by
    rw [Real.sqrt_mul hM0]
    ring
  have h3 := mul_le_mul_of_nonneg_left hratio
    (by positivity : (0 : ℝ) ≤ 55 * Real.sqrt (adaLval α β))
  have hg := ghost_eq k α β
  set ρ := α ^ (-(1 / ((adaL α : ℝ) - 1))) with hρdef
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  have e : 55 * Real.sqrt (adaLval α β) *
      (593300 * ρ * (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) * Λ / α ^ 2) =
      55 * 593300 * ρ * (adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ) * Λ * Real.sqrt (adaLval α β) /
        α ^ 2 := by ring
  linarith

/-- Proposition `I:prop:validator_sample_complexity`(3), `I:eq:sec6_validator_sum_explicit`:
`∑_{r=2}^{L-1} n_r + n_L ≤ (10⁸/α²) L^{7/2} ln(64 L k M_{2,max}/δ_val) √L_val` (ceilings included; the
paper's prefactor is `(0.843 + 8.871 + 0.002)·10⁷ + 1 < 9.72·10⁷`). -/
theorem validator_sum_le (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    ∑ r ∈ Finset.Icc 2 (adaL α - 1), (adaNr k α β r : ℝ) + (adaNL k α β : ℝ) ≤
      10 ^ 8 / α ^ 2 * ((adaL α : ℝ) ^ 3 * Real.sqrt (adaL α : ℝ)) *
        Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) *
        Real.sqrt (adaLval α β) := by
  have hI := sum_adaNr_le hα hα' hβ hβ' hk
  have hA := adaNL_lt hα hα' hβ hβ' hk
  have hL5 := five_le_adaL_real hα hα'
  have hρe := rho_lt_e_d9 hα hα'
  have hρ0 := rho_pos (α := α) hα
  have hΛ49 := log_svt_gt hα hα' hβ hβ' hk
  have hG := log_six_k_le_log_svt hα hβ hk
  have hs := sqrt_adaL_ge hα hα'
  have hv := sqrt_adaLval_gt hα hα' hβ hβ'
  have hα2 : 0 < α ^ 2 := by positivity
  have hα21 : α ^ 2 ≤ 1 := by
    have : α ^ 2 < (1 / 16) ^ 2 := by gcongr
    linarith
  set ρ := α ^ (-(1 / ((adaL α : ℝ) - 1))) with hρdef
  set Λ := Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) with hΛdef
  set G := Real.log (6 * (k : ℝ) / adaDeltaVal α β) with hGdef
  set L := (adaL α : ℝ) with hLdef
  set s := Real.sqrt (adaL α : ℝ) with hsdef
  set v := Real.sqrt (adaLval α β) with hvdef
  set P := L ^ 3 * s * Λ * v / α ^ 2 with hPdef
  have hP0 : 0 ≤ P := by positivity
  -- anchor: `55·593300·ρ < 88710000`
  have hP1 : 55 * 593300 * ρ * L ^ 3 * s * Λ * v / α ^ 2 ≤ 88710000 * P := by
    have e : 55 * 593300 * ρ * L ^ 3 * s * Λ * v / α ^ 2 = (55 * 593300 * ρ) * P := by
      rw [hPdef]
      ring
    rw [e]
    have : 55 * 593300 * ρ ≤ 88710000 := by nlinarith
    exact mul_le_mul_of_nonneg_right this hP0
  -- Ghost-Monitor term: `1048576 L² ln(6k/δ_val)/α² ≤ 20000 P` as `L √L √L_val ≥ 77`
  have hP2 : 1048576 * L ^ 2 * G / α ^ 2 ≤ 20000 * P := by
    have hLsv : 77 ≤ L * s * v := by
      have h1 : 5 * 2.2 ≤ L * s := mul_le_mul hL5 hs (by norm_num) (by positivity)
      have h2 : 5 * 2.2 * 7 ≤ L * s * v := mul_le_mul h1 hv.le (by norm_num) (by positivity)
      linarith
    have hfac : 0 ≤ L ^ 2 * Λ / α ^ 2 := by positivity
    have h1 : 1048576 * L ^ 2 * G / α ^ 2 ≤ 1048576 * L ^ 2 * Λ / α ^ 2 := by gcongr
    have e : 20000 * P - 1048576 * L ^ 2 * Λ / α ^ 2 =
        (L ^ 2 * Λ / α ^ 2) * (20000 * (L * s * v) - 1048576) := by
      rw [hPdef]
      ring
    have h2 : 0 ≤ (L ^ 2 * Λ / α ^ 2) * (20000 * (L * s * v) - 1048576) :=
      mul_nonneg hfac (by linarith)
    linarith
  -- the remaining ceilings: `L + 1 ≤ P`
  have hP3 : L + 1 ≤ P := by
    have h1 : 1 ≤ s * Λ * v := by
      have : 0 ≤ s * Λ := by positivity
      nlinarith
    have h2 : L ^ 3 ≤ P := by
      rw [hPdef, le_div_iff₀ hα2]
      calc L ^ 3 * α ^ 2 ≤ L ^ 3 * 1 := by gcongr
        _ ≤ L ^ 3 * (s * Λ * v) := by gcongr
        _ = L ^ 3 * s * Λ * v := by ring
    have h3 : L + 1 ≤ L ^ 3 := by nlinarith
    linarith
  have e : 10 ^ 8 / α ^ 2 * (L ^ 3 * s) * Λ * v = 10 ^ 8 * P := by
    rw [hPdef]
    ring
  rw [e]
  linarith

/-- Theorem I.1.1: `n ≤ 32000 √k χ₁/α + 16000 L₁³/α² + 1 + (10⁸/α²) L^{7/2} Λ_SVT √L_val`
(`I:eq:main_explicit_bound`). -/
theorem adaSampleSize_le_explicitBound (k : ℕ) (α β : ℝ) (hk : 1 ≤ k) (hα : 0 < α)
    (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (adaSampleSize k α β : ℝ) ≤ adaExplicitBound k α β := by
  have hsum := validator_sum_le hα hα' hβ hβ' hk
  have hχ := adaChi1_nonneg hα hα' hβ hβ'
  have hL1 := adaL1_pos hα hα' hβ hβ'
  have harg : 0 ≤ 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α + 16000 * adaL1 α β ^ 3 / α ^ 2 :=
    add_nonneg (div_nonneg (mul_nonneg (by positivity) hχ) hα.le) (by positivity)
  have hn1 : (adaN1 k α β : ℝ) <
      32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α + 16000 * adaL1 α β ^ 3 / α ^ 2 + 1 :=
    Nat.ceil_lt_add_one harg
  unfold adaSampleSize adaExplicitBound
  push_cast
  linarith

end Sample

end A

end F2e2e
