import F2e2e.A.AccuracyRound

/-!
# Part I §4: clean-event output accuracy and Stage-1 decoupling (run level)

Owner: A-ACC. Paper: `parts/partI.tex` L1165-1323: the clean envelopes I.4.A (`I:eq:sec4_clean_envelopes`,
L1165-1176), Lemma `I:lem:output_accuracy` (I.4.1, L1187-1251) and Lemma `I:lem:stage1_decoupling` (I.4.2,
L1263-1323).

Setting (A-ARCH's `F2e2e/A/ArchDefs.lean`): a deterministic analyst `A : DetAnalyst X` with `[0,1]`-valued
queries (`A.Valid`), a distribution `D`, a point `z = (S, ω)` of the analysis space, the transcript
`h = transcript k α β A z.1 z.2 : Fin k → RoundRec`, the population means `μ_i = popMu D A h i`, the chain
data `onlineChain k α β A z.1 z.2 i` of round `i` (so `θ_i^{(r)}(S_r) = (onlineChain … i).theta r`), and the
clean event `EClean k α β D A z = EAnc ∧ ELap`.

## Main results
* I.4.A: `onlineChain_clean` (`ELap` gives the round envelopes `ChainData.Clean`), `onlineChain_anchor`
  (`EAnc` gives `|θ_i^{(L)}(S_L) - μ_i| ≤ r_anc`), `onlineChain_thetaMem`, `onlineChain_c1_fidelity`
  (`|c_i^{(1)} - θ_i^{(1)}(S₁)| < R₁`, Lemma `I:lem:working_sample_privacy`(1)), bundled as
  `clean_envelopes`.
* I.4.1(i): `MState.theta_mem` (`θ_i^{(m)}(S_m) ∈ [0,1]`), `clip_fidelity` (`I:eq:sec4_cm_fidelity`: every
  released validator scalar is within `u₀` of its mean), `c1_fidelity` (`I:eq:sec4_c1_fidelity`),
  `rel_of_delta_ne_zero`, `theta_to_c_conversion` (the conversion `I:eq:theta_to_c_conversion_sec5` used in
  §5).
* I.4.1(ii): `output_accuracy` (`I:eq:sec4_ai_accuracy`: `|a_i - μ_i| ≤ τ_{(u_final,L)} + 4u₀ + r_anc < α`
  on every active round).
* I.4.2: `stage1_decoupling` (`I:eq:sec4_caseA_c1_c2_gap`, `I:eq:sec4_caseA_ai_mui_bound`,
  `I:eq:sec4_stage1_drift_lb`; the public sign equals `sign(θ_i^{(1)}(S₁) - μ_i)`).
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## `θ ∈ [0,1]` (Lemma `I:lem:output_accuracy`(i), first claim) -/

section Theta

variable {k : ℕ} {α β : ℝ}

theorem MState.weight_nonneg (st : MState k α β) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    0 ≤ st.weight r ℓ := by
  unfold MState.weight
  split_ifs
  · positivity
  · exact (Opt.waterFill_pos (Fin.pos ℓ) ℓ).le

theorem MState.sum_weight_le_one (st : MState k α β) (r : ℕ) : ∑ ℓ, st.weight r ℓ ≤ 1 := by
  rcases Nat.eq_zero_or_pos (adaBlock k α β r) with h0 | hpos
  · rw [Finset.sum_eq_zero fun ℓ _ => absurd ℓ.isLt (by omega)]
    exact zero_le_one
  · unfold MState.weight
    split_ifs
    · rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      have : (0 : ℝ) < adaBlock k α β r := by exact_mod_cast hpos
      rw [mul_one_div_cancel this.ne']
    · rw [Opt.sum_waterFill hpos]

/-- Lemma `I:lem:output_accuracy`(i), first claim: `θ_i^{(m)}(S_m) = ⟨P^{(m)}, q_i(S_m)⟩ ∈ [0,1]` for
`[0,1]`-valued queries (a sub-convex combination of values in `[0,1]`). -/
theorem MState.theta_mem (st : MState k α β) (q : Fin (adaSampleSize k α β) → ℝ)
    (hq : ∀ ℓ, 0 ≤ q ℓ ∧ q ℓ ≤ 1) (r : ℕ) : 0 ≤ st.theta q r ∧ st.theta q r ≤ 1 := by
  unfold MState.theta
  constructor
  · exact Finset.sum_nonneg fun ℓ _ =>
      mul_nonneg (st.weight_nonneg r ℓ) (hq _).1
  · calc ∑ ℓ, st.weight r ℓ * q (adaBlockIdx k α β r ℓ) ≤ ∑ ℓ, st.weight r ℓ * 1 :=
          Finset.sum_le_sum fun ℓ _ => mul_le_mul_of_nonneg_left (hq _).2 (st.weight_nonneg r ℓ)
      _ = ∑ ℓ, st.weight r ℓ := by simp
      _ ≤ 1 := st.sum_weight_le_one r

end Theta

/-! ## I.4.A: the clean envelopes, round by round -/

section Envelopes

variable {X : Type} {k : ℕ} {α β : ℝ}

theorem abs_noiseNu_le (hα : 0 < α) {ω : AdaOmega k α} (hω : ELap k α ω) (i r : ℕ) :
    |noiseNu ω i r| ≤ 2 * adaU0 α := by
  unfold noiseNu
  split_ifs with h
  · exact hω (.nu ⟨i, h.1⟩ ⟨r, h.2⟩)
  · rw [abs_zero]
    have := adaU0_pos hα
    linarith

theorem abs_noiseZeta_le (hα : 0 < α) {ω : AdaOmega k α} (hω : ELap k α ω) (i r : ℕ) :
    |noiseZeta ω i r| ≤ adaU0 α := by
  unfold noiseZeta
  split_ifs with h
  · exact hω (.zeta ⟨i, h.1⟩ ⟨r, h.2⟩)
  · rw [abs_zero]
    exact (adaU0_pos hα).le

theorem abs_noiseRho_le (hα : 0 < α) {ω : AdaOmega k α} (hω : ELap k α ω) (r e : ℕ) :
    |noiseRho ω r e| ≤ adaU0 α := by
  unfold noiseRho
  split_ifs with h
  · exact hω (.rho ⟨r, h.1⟩ ⟨e, h.2⟩)
  · rw [abs_zero]
    exact (adaU0_pos hα).le

/-- On `E_lap` every round's chain data satisfies the clean-round envelopes
(`I:eq:sec4_clean_envelopes`: `|ρ^{(r)}| ≤ u₀`, `|ν_i^{(r)}| ≤ 2u₀`, `|ζ_i^{(r)}| ≤ u₀`). -/
theorem roundChain_clean (hα : 0 < α) (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    {ω : AdaOmega k α} (hω : ELap k α ω) : (roundChain st i q ω).Clean (adaU0 α) :=
  fun r _ _ => ⟨abs_noiseRho_le hα hω r _, abs_noiseNu_le hα hω i r, abs_noiseZeta_le hα hω i r⟩

theorem roundChain_thetaMem (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (hq : ∀ ℓ, 0 ≤ q ℓ ∧ q ℓ ≤ 1) : (roundChain st i q ω).ThetaMem :=
  fun r _ _ => st.theta_mem q hq r

/-- Lemma `I:lem:working_sample_privacy`(1) / `I:eq:sec4_c1_fidelity`: the clipped Stage-1 proposal satisfies
`|c_i^{(1)} - θ_i^{(1)}(S₁)| ≤ |ξ_i| < R₁` deterministically (`ξ_i = R₁ · clampUnit(V_i)`). -/
theorem roundChain_c1_fidelity (hα : 0 < α) (st : MState k α β) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) (hq : ∀ ℓ, 0 ≤ q ℓ ∧ q ℓ ≤ 1) :
    |(roundChain st i q ω).c1 - (roundChain st i q ω).theta 1| < adaR1 α := by
  have hθ := st.theta_mem q hq 1
  have hR : 0 < adaR1 α := by
    unfold adaR1
    linarith
  have h1 := abs_clip01_sub_le (stage1Release st i q ω) (y := st.theta q 1) ⟨hθ.1, hθ.2⟩
  have e : stage1Release st i q ω - st.theta q 1 = adaR1 α * Dist.clampUnit (noiseBeta ω i) := by
    unfold stage1Release
    ring
  rw [e] at h1
  exact lt_of_le_of_lt h1 (Dist.abs_mul_clampUnit_lt hR _)

theorem onlineQ_mem (A : DetAnalyst X) (hA : A.Valid) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) (ℓ : Fin (adaSampleSize k α β)) :
    0 ≤ onlineQ k α β A S ω i ℓ ∧ onlineQ k α β A S ω i ℓ ≤ 1 :=
  hA _ _ _

theorem onlineChain_locked (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : (onlineChain k α β A S ω i).Locked α :=
  roundChain_locked _ _ _ _

theorem onlineChain_clean (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    {ω : AdaOmega k α} (hω : ELap k α ω) (i : ℕ) : (onlineChain k α β A S ω i).Clean (adaU0 α) :=
  roundChain_clean hα _ _ _ hω

theorem onlineChain_thetaMem (A : DetAnalyst X) (hA : A.Valid) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : (onlineChain k α β A S ω i).ThetaMem :=
  roundChain_thetaMem _ _ _ _ (onlineQ_mem A hA S ω i)

theorem onlineChain_c1_fidelity (hα : 0 < α) (A : DetAnalyst X) (hA : A.Valid)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : ℕ) :
    |(onlineChain k α β A S ω i).c1 - (onlineChain k α β A S ω i).theta 1| < adaR1 α :=
  roundChain_c1_fidelity hα _ _ _ _ (onlineQ_mem A hA S ω i)

/-- The anchor level of the chain data is the plain average over `S_L` of the round's query:
`θ_i^{(L)}(S_L) = (1/n_L) ∑_ℓ q_i(X_{L,ℓ}) = anchorMean S q_i` (Definition `I:def:mechanism` (iii)). -/
theorem onlineChain_theta_L (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {i : ℕ} (hi : i ≤ k) :
    (onlineChain k α β A S ω i).theta (adaL α) =
      anchorMean k α β S (qry A (transcript k α β A S ω) i) := by
  show (onlineState k α β A S ω i).theta (onlineQ k α β A S ω i) (adaL α) = _
  rw [onlineQ_eq_qry A S ω hi]
  unfold MState.theta MState.weight anchorMean blockOf
  rw [if_pos rfl, Finset.sum_div]
  refine Finset.sum_congr rfl fun ℓ _ => ?_
  rw [one_div_mul_eq_div]

/-- On `E_anc`: `|θ_i^{(L)}(S_L) - μ_i| ≤ r_anc` for every round `i < k` (`I:eq:sec4_clean_envelopes`). -/
theorem onlineChain_anchor [MeasurableSpace X] (D : Measure X) (A : DetAnalyst X)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EAnc k α β D A z) (i : Fin k) :
    |(onlineChain k α β A z.1 z.2 i).theta (onlineChain k α β A z.1 z.2 i).L -
        popMu D A (transcript k α β A z.1 z.2) i| ≤ adaRanc α := by
  show |(onlineChain k α β A z.1 z.2 i).theta (adaL α) - _| ≤ _
  rw [onlineChain_theta_L A z.1 z.2 i.isLt.le]
  exact hz i

/-- I.4.A (`I:eq:sec4_clean_envelopes`, L1165-1176) bundled: on `E_clean`, the chain data of every round
`i < k` carries the locked parameters, the Laplace envelopes, `θ ∈ [0,1]`, the Stage-1 envelope and the
anchor envelope. -/
theorem clean_envelopes [MeasurableSpace X] (hα : 0 < α) (D : Measure X) (A : DetAnalyst X)
    (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z)
    (i : Fin k) :
    (onlineChain k α β A z.1 z.2 i).Locked α ∧ (onlineChain k α β A z.1 z.2 i).Clean (adaU0 α) ∧
      (onlineChain k α β A z.1 z.2 i).ThetaMem ∧
      |(onlineChain k α β A z.1 z.2 i).c1 - (onlineChain k α β A z.1 z.2 i).theta 1| < adaR1 α ∧
      |(onlineChain k α β A z.1 z.2 i).theta (onlineChain k α β A z.1 z.2 i).L -
        popMu D A (transcript k α β A z.1 z.2) i| ≤ adaRanc α :=
  ⟨onlineChain_locked A z.1 z.2 i, onlineChain_clean hα A z.1 hz.2 i,
    onlineChain_thetaMem A hA z.1 z.2 i, onlineChain_c1_fidelity hα A hA z.1 z.2 i,
    onlineChain_anchor D A z hz.1 i⟩

end Envelopes

/-! ## Lemma `I:lem:output_accuracy` -/

section Accuracy

variable {X : Type} {k : ℕ} {α β : ℝ}

theorem ChainData.released_bounds {d : ChainData} (hL : 1 ≤ d.L) {r : ℕ} (h : d.Released r) :
    2 ≤ r ∧ r ≤ d.L := by
  rcases h with hT | ⟨h3, hr⟩
  · exact ⟨d.two_le_of_trig hT, d.le_L_of_trig hT⟩
  · have := d.ufinal_le_L hL
    omega

theorem transcript_active_of_rel (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) {r : ℕ} (hr : (transcript k α β A S ω i).rel r = true) :
    (transcript k α β A S ω i).active = true := by
  cases h : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i h] at hr
    exact absurd hr (by rw [show RoundRec.halted.rel r = false from rfl]; decide)
  · rfl

theorem transcript_active_of_two_le_ufinal (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) (hu : 2 ≤ (transcript k α β A S ω i).ufinal) :
    (transcript k α β A S ω i).active = true := by
  cases h : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i h, RoundRec.halted_ufinal] at hu
    omega
  · rfl

/-- A released scalar of an active round is the clipped release of the chain data (`I:eq:trigger_release`,
`I:eq:retroactive_release`), and its stage is a validator stage `2 ≤ r ≤ L`. -/
theorem transcript_c_of_rel (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) {r : ℕ} (hr : (transcript k α β A S ω i).rel r = true) :
    (transcript k α β A S ω i).c r = (onlineChain k α β A S ω i).relC r ∧ 2 ≤ r ∧ r ≤ adaL α := by
  have hact := transcript_active_of_rel A S ω i hr
  rw [transcript_of_active A S ω i hact] at hr ⊢
  have hrel : (onlineChain k α β A S ω i).Released r := of_decide_eq_true hr
  have hb := ChainData.released_bounds (d := onlineChain k α β A S ω i)
    (by show 1 ≤ adaL α; have := adaL_ge_four α; omega) hrel
  refine ⟨?_, hb.1, hb.2⟩
  rw [ChainData.toRec_c, if_neg (show ¬ (r = 1) by omega), if_pos hrel]

/-- Lemma `I:lem:output_accuracy`(i), `I:eq:sec4_cm_fidelity`: on `E_lap` (in particular on `E_clean`),
every validator scalar `c_i^{(r)}` released in round `i` (direct trigger, Step 2(c), or retroactive, (B1))
satisfies `|c_i^{(r)} - θ_i^{(r)}(S_r)| ≤ |ζ_i^{(r)}| ≤ u₀`. -/
theorem clip_fidelity (hα : 0 < α) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k) {r : ℕ}
    (hr : (transcript k α β A z.1 z.2 i).rel r = true) :
    |(transcript k α β A z.1 z.2 i).c r - (onlineChain k α β A z.1 z.2 i).theta r| ≤ adaU0 α := by
  obtain ⟨hc, h2, hL⟩ := transcript_c_of_rel A z.1 z.2 i hr
  rw [hc]
  exact ChainData.relC_fidelity (onlineChain_clean hα A z.1 hz i) (onlineChain_thetaMem A hA z.1 z.2 i)
    h2 hL

/-- Lemma `I:lem:output_accuracy`(i), `I:eq:sec4_c1_fidelity`: on every active round,
`|c_i^{(1)} - θ_i^{(1)}(S₁)| < R₁ = α/32` (deterministically). -/
theorem c1_fidelity (hα : 0 < α) (A : DetAnalyst X) (hA : A.Valid) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) (hi : (transcript k α β A S ω i).active = true) :
    |(transcript k α β A S ω i).c 1 - (onlineChain k α β A S ω i).theta 1| < adaR1 α := by
  rw [transcript_of_active A S ω i hi, ChainData.toRec_c, if_pos rfl]
  exact onlineChain_c1_fidelity hα A hA S ω i

/-- A non-zero validator impulse `δ_{m,i}` (`m ≥ 2`) is only applied to a released level (Remark
`I:rem:prog_m_measurability`: `c_i^{(m)}` is recorded whenever `δ_{m,i} ≠ 0`). -/
theorem rel_of_delta_ne_zero (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) {m : ℕ} (hm : 2 ≤ m)
    (hδ : (transcript k α β A S ω i).delta m ≠ 0) : (transcript k α β A S ω i).rel m = true := by
  cases h : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i h] at hδ
    exact absurd rfl hδ
  · rw [transcript_of_active A S ω i h] at hδ ⊢
    set d := onlineChain k α β A S ω i
    rw [ChainData.toRec_delta] at hδ
    by_cases hu : d.ufinal ≤ 2
    · exact absurd (ChainData.delta_eq_zero_of_ufinal_le_two hu hm _ _ _) hδ
    · have hB : 3 ≤ d.ufinal := by omega
      rw [ChainData.delta_caseB hB] at hδ
      show decide (d.Released m) = true
      apply decide_eq_true
      split_ifs at hδ with h1 h2
      · exact Or.inr ⟨hB, h1⟩
      · rw [h2]
        exact ChainData.released_ufinal (by omega)
      · exact absurd rfl hδ

/-- The conversion `I:eq:theta_to_c_conversion_sec5` used in the §5 closure: on `E_lap`, for every round
`i` and validator level `m ≥ 2`,
`(-δ_{m,i})(θ_i^{(m)}(S_m) - μ) ≥ (-δ_{m,i})(c_i^{(m)} - μ) - |δ_{m,i}| u₀`. -/
theorem theta_to_c_conversion (hα : 0 < α) (A : DetAnalyst X) (hA : A.Valid)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : ELap k α z.2) (i : Fin k) {m : ℕ}
    (hm : 2 ≤ m) (μ : ℝ) :
    (-(transcript k α β A z.1 z.2 i).delta m) * ((transcript k α β A z.1 z.2 i).c m - μ) -
        |(transcript k α β A z.1 z.2 i).delta m| * adaU0 α ≤
      (-(transcript k α β A z.1 z.2 i).delta m) * ((onlineChain k α β A z.1 z.2 i).theta m - μ) := by
  by_cases hδ : (transcript k α β A z.1 z.2 i).delta m = 0
  · rw [hδ]
    simp
  · have hf := clip_fidelity hα A hA z hz i (rel_of_delta_ne_zero A z.1 z.2 i hm hδ)
    set δ := (transcript k α β A z.1 z.2 i).delta m
    set c := (transcript k α β A z.1 z.2 i).c m
    set θ := (onlineChain k α β A z.1 z.2 i).theta m
    have e : (-δ) * (θ - μ) = (-δ) * (c - μ) + (-δ) * (θ - c) := by ring
    have h1 : |(-δ) * (θ - c)| ≤ |δ| * adaU0 α := by
      rw [abs_mul, abs_neg, abs_sub_comm]
      exact mul_le_mul_of_nonneg_left hf (abs_nonneg _)
    have h2 := neg_abs_le ((-δ) * (θ - c))
    linarith

/-- Lemma `I:lem:output_accuracy`(ii), `I:eq:sec4_ai_accuracy`: on `E_clean`, every active round outputs
`a_i = c_i^{(u_final)}` with `|a_i - μ_i| ≤ τ_{(u_final,L)} + 4u₀ + r_anc < 3α/4 + 6u₀ < α`. -/
theorem output_accuracy [MeasurableSpace X] (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X)
    (A : DetAnalyst X) (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hz : EClean k α β D A z) (i : Fin k) (hi : (transcript k α β A z.1 z.2 i).active = true) :
    |(transcript k α β A z.1 z.2 i).answer - popMu D A (transcript k α β A z.1 z.2) i| ≤
        adaTau α (transcript k α β A z.1 z.2 i).ufinal (adaL α) + 4 * adaU0 α + adaRanc α ∧
      adaTau α (transcript k α β A z.1 z.2 i).ufinal (adaL α) + 4 * adaU0 α + adaRanc α <
        3 / 4 * α + 6 * adaU0 α ∧
      |(transcript k α β A z.1 z.2 i).answer - popMu D A (transcript k α β A z.1 z.2) i| < α := by
  obtain ⟨hlk, hc, hθ, -, hanc⟩ := clean_envelopes hα D A hA z hz i
  have h := ChainData.round_output_accuracy hα hα' hlk hc hθ hanc
  rw [transcript_of_active A z.1 z.2 i hi, ChainData.toRec_answer, ChainData.toRec_ufinal]
  exact ⟨h.1, h.2.1, by linarith [h.1, h.2.1, h.2.2]⟩

/-- Lemma `I:lem:stage1_decoupling` (I.4.2): on `E_clean`, in every Case-A round (`u_final = 2`, so stage 2
triggered on `c_i^{(1)}` and the Stage-1 public sign is `s^{(1)} = (h_i).sgn = sign(c_i^{(1)} - a_i)`):
`|c_i^{(1)} - c_i^{(2)}| ≥ α/2 - 4u₀` (`I:eq:sec4_caseA_c1_c2_gap`),
`|a_i - μ_i| ≤ 2(L-2)γ + 6u₀ < α/4 + 6u₀` (`I:eq:sec4_caseA_ai_mui_bound`),
`s^{(1)}(θ_i^{(1)}(S₁) - μ_i) ≥ 7α/32 - 10u₀ > 3α/16 > α/8 = γ₁` (`I:eq:sec4_stage1_drift_lb`), and
`s^{(1)} = sign(θ_i^{(1)}(S₁) - μ_i)`. -/
theorem stage1_decoupling [MeasurableSpace X] (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X)
    (A : DetAnalyst X) (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hz : EClean k α β D A z) (i : Fin k) (hA2 : (transcript k α β A z.1 z.2 i).ufinal = 2) :
    α / 2 - 4 * adaU0 α ≤ |(transcript k α β A z.1 z.2 i).c 1 - (transcript k α β A z.1 z.2 i).c 2| ∧
      |(transcript k α β A z.1 z.2 i).answer - popMu D A (transcript k α β A z.1 z.2) i| ≤
        2 * ((adaL α : ℝ) - 2) * adaGamma α + 6 * adaU0 α ∧
      2 * ((adaL α : ℝ) - 2) * adaGamma α + 6 * adaU0 α < α / 4 + 6 * adaU0 α ∧
      7 / 32 * α - 10 * adaU0 α ≤ (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i) ∧
      3 / 16 * α < 7 / 32 * α - 10 * adaU0 α ∧
      adaGamma1 α < 3 / 16 * α ∧
      (transcript k α β A z.1 z.2 i).sgn =
        sgn1 ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i) := by
  obtain ⟨hlk, hc, hθ, hc1, hanc⟩ := clean_envelopes hα D A hA z hz i
  have hact := transcript_active_of_two_le_ufinal A z.1 z.2 i (by omega)
  rw [transcript_of_active A z.1 z.2 i hact] at hA2 ⊢
  set d := onlineChain k α β A z.1 z.2 i
  have hA2' : d.ufinal = 2 := hA2
  have hrel2 : d.Released 2 := by
    have := ChainData.released_ufinal (d := d) (by omega)
    rwa [hA2'] at this
  have hc2 : (d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c 2 = d.relC 2 := by
    rw [ChainData.toRec_c, if_neg (by norm_num), if_pos hrel2]
  have hc1' : (d.toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)).c 1 = d.c1 := by
    rw [ChainData.toRec_c, if_pos rfl]
  rw [hc1', hc2]
  have hu := adaU0_le hα hα'
  refine ⟨ChainData.round_caseA_gap hα hα' hlk hc hθ hA2',
    ChainData.round_caseA_answer_err hα hα' hlk hc hθ hanc hA2', ?_,
    ChainData.round_stage1_drift_ge hα hα' hlk hc hθ hc1 hanc hA2', by linarith,
    ChainData.adaGamma1_lt hα, ChainData.round_stage1_sgn_eq hα hα' hlk hc hθ hc1 hanc hA2'⟩
  have := two_mul_adaL_sub_two_mul_adaGamma_lt hα
  linarith

/-- I.4.2 in the form used by the §5 Stage-1 closure (L1805): on `E_clean`, every Case-A round has
`s^{(1)}(θ_i^{(1)}(S₁) - μ_i) > 3α/16`. -/
theorem stage1_drift_gt [MeasurableSpace X] (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X)
    (A : DetAnalyst X) (hA : A.Valid) (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hz : EClean k α β D A z) (i : Fin k) (hA2 : (transcript k α β A z.1 z.2 i).ufinal = 2) :
    3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
      ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i) := by
  obtain ⟨-, -, -, h1, h2, -, -⟩ := stage1_decoupling hα hα' D A hA z hz i hA2
  linarith

end Accuracy

end A

end F2e2e
