import F2e2e.Spec

/-!
# Part I numerics: basic range facts on the locked parameters (Definition I.1.6)

Owner: worker A-NUM. Imports only `F2e2e.Spec`.

Facts on the Spec's definitions `adaL`, `adaGamma`, `adaU0`, `adaEps`, `adaEpsL`, `adaRanc`,
`adaDeltaVal`, `adaLval`, `adaL1`, `adaT1max`, `adaNmax`, `adaMmax`, `adaBsvt`, for
`0 < α < 1/16`, `0 < β < 1/2`, `k ≥ 1` (`parts/partI.tex` L194-261, Lemma `I:lem:threshold_properties`(a)
L263-291, Proposition `I:prop:validator_sample_complexity` L2090-2179).

Notation in the comments: `x = ln(1/α)`, `L = adaL α`, `θ = α^{1/(L-1)}` and
`ρ = α^{-1/(L-1)} = θ⁻¹` (the adjacent privacy ratio `ε_{r-1}/ε_r`, `I:eq:eps_r_schedule`).
-/

namespace F2e2e

namespace A

section Basic

variable {α β : ℝ}

/-! ### `x = ln(1/α)` and the depth `L` -/

/-- `ln 16 = 4 ln 2`. -/
lemma log_sixteen : Real.log 16 = 4 * Real.log 2 := by
  rw [show (16 : ℝ) = 2 ^ 4 by norm_num, Real.log_pow]
  norm_num

/-- `1/α > 16` for `0 < α < 1/16`. -/
lemma sixteen_lt_inv (hα : 0 < α) (hα' : α < 1 / 16) : (16 : ℝ) < 1 / α := by
  rw [lt_div_iff₀ hα]
  linarith

/-- `4 ln 2 < ln(1/α)` for `0 < α < 1/16`. -/
lemma four_log_two_lt_log_inv (hα : 0 < α) (hα' : α < 1 / 16) :
    4 * Real.log 2 < Real.log (1 / α) := by
  rw [← log_sixteen]
  exact Real.log_lt_log (by norm_num) (sixteen_lt_inv hα hα')

/-- `ln(1/α) > 2.77` (since `4 ln 2 > 2.7725`). -/
lemma log_inv_gt (hα : 0 < α) (hα' : α < 1 / 16) : (277 / 100 : ℝ) < Real.log (1 / α) := by
  have h1 := four_log_two_lt_log_inv hα hα'
  have h2 := Real.log_two_gt_d9
  norm_num at h2
  linarith

lemma log_inv_pos (hα : 0 < α) (hα' : α < 1 / 16) : 0 < Real.log (1 / α) := by
  have := log_inv_gt hα hα'
  linarith

/-- `⌈ln(1/α)⌉₊ ≥ 3`. -/
lemma three_le_ceil_log_inv (hα : 0 < α) (hα' : α < 1 / 16) : 3 ≤ ⌈Real.log (1 / α)⌉₊ := by
  have h := log_inv_gt hα hα'
  have h2 : (2 : ℕ) < ⌈Real.log (1 / α)⌉₊ :=
    Nat.lt_ceil.mpr (by exact_mod_cast (by linarith : (2 : ℝ) < Real.log (1 / α)))
  omega

/-- For `α < 1/16` the maximum in `L = max(4, ⌈ln(1/α)⌉ + 2)` is attained by the second entry. -/
lemma adaL_eq (hα : 0 < α) (hα' : α < 1 / 16) : adaL α = ⌈Real.log (1 / α)⌉₊ + 2 := by
  have h := three_le_ceil_log_inv hα hα'
  unfold adaL
  exact max_eq_right (by omega)

/-- `L ≥ 5` (`I:lem:threshold_properties`(a)). -/
lemma five_le_adaL (hα : 0 < α) (hα' : α < 1 / 16) : 5 ≤ adaL α := by
  rw [adaL_eq hα hα']
  have := three_le_ceil_log_inv hα hα'
  omega

lemma adaL_cast_eq (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) = (⌈Real.log (1 / α)⌉₊ : ℝ) + 2 := by
  rw [adaL_eq hα hα']
  push_cast
  ring

lemma five_le_adaL_real (hα : 0 < α) (hα' : α < 1 / 16) : (5 : ℝ) ≤ (adaL α : ℝ) := by
  exact_mod_cast five_le_adaL hα hα'

lemma adaL_pos_real (hα : 0 < α) (hα' : α < 1 / 16) : (0 : ℝ) < (adaL α : ℝ) := by
  have := five_le_adaL_real hα hα'
  linarith

/-- `L - 1 ≥ 4 > 0` as a real number. -/
lemma adaL_sub_one_pos (hα : 0 < α) (hα' : α < 1 / 16) : (0 : ℝ) < (adaL α : ℝ) - 1 := by
  have := five_le_adaL_real hα hα'
  linarith

/-- `ln(1/α) + 1 ≤ L - 1`, in particular `L - 1 > ln(1/α)` (`I:lem:threshold_properties`(a)). -/
lemma log_inv_add_one_le (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.log (1 / α) + 1 ≤ (adaL α : ℝ) - 1 := by
  rw [adaL_cast_eq hα hα']
  have := Nat.le_ceil (Real.log (1 / α))
  linarith

lemma log_inv_lt_adaL_sub_one (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.log (1 / α) < (adaL α : ℝ) - 1 := by
  have := log_inv_add_one_le hα hα'
  linarith

/-- `L - 1 < ln(1/α) + 2`. -/
lemma adaL_sub_one_lt (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) - 1 < Real.log (1 / α) + 2 := by
  rw [adaL_cast_eq hα hα']
  have h0 : 0 ≤ Real.log (1 / α) := (log_inv_pos hα hα').le
  have := Nat.ceil_lt_add_one h0
  linarith

/-- `L < ln(1/α) + 3`. -/
lemma adaL_lt_log_inv_add_three (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) < Real.log (1 / α) + 3 := by
  have := adaL_sub_one_lt hα hα'
  linarith

/-- `L ≤ 2.1 ln(1/α)` (as `ln(1/α) > 30/11`). -/
lemma adaL_le_mul_log_inv (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) ≤ 21 / 10 * Real.log (1 / α) := by
  have h1 := adaL_lt_log_inv_add_three hα hα'
  have h2 := log_inv_gt hα hα'
  linarith

/-- `L ≤ 3 ln(1/α)`. -/
lemma adaL_le_three_mul_log_inv (hα : 0 < α) (hα' : α < 1 / 16) :
    (adaL α : ℝ) ≤ 3 * Real.log (1 / α) := by
  have h1 := adaL_le_mul_log_inv hα hα'
  have h2 := log_inv_pos hα hα'
  linarith

/-- `ln(1/α)/(L-1) < 1`. -/
lemma log_inv_div_lt_one (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.log (1 / α) / ((adaL α : ℝ) - 1) < 1 := by
  rw [div_lt_one (adaL_sub_one_pos hα hα')]
  exact log_inv_lt_adaL_sub_one hα hα'

/-- `ln(1/α)/(L-1) > 3/5` (`I:eq:sec6_rho_bounds`; case analysis on `⌈ln(1/α)⌉ = 3` or `≥ 4`). -/
lemma three_fifths_lt_log_inv_div (hα : 0 < α) (hα' : α < 1 / 16) :
    (3 / 5 : ℝ) < Real.log (1 / α) / ((adaL α : ℝ) - 1) := by
  rw [lt_div_iff₀ (adaL_sub_one_pos hα hα'), adaL_cast_eq hα hα']
  have hm3 := three_le_ceil_log_inv hα hα'
  have h0 : 0 ≤ Real.log (1 / α) := (log_inv_pos hα hα').le
  have hmx := Nat.ceil_lt_add_one h0
  have h4 := four_log_two_lt_log_inv hα hα'
  have hl2 := Real.log_two_gt_d9
  norm_num at hl2
  rcases Nat.lt_or_ge ⌈Real.log (1 / α)⌉₊ 4 with h | h
  · have h3 : ⌈Real.log (1 / α)⌉₊ = 3 := by omega
    rw [h3]
    push_cast
    linarith
  · have h4' : (4 : ℝ) ≤ (⌈Real.log (1 / α)⌉₊ : ℝ) := by exact_mod_cast h
    linarith

/-- `ln(1/α)/(L-1) > 0`. -/
lemma log_inv_div_pos (hα : 0 < α) (hα' : α < 1 / 16) :
    0 < Real.log (1 / α) / ((adaL α : ℝ) - 1) :=
  div_pos (log_inv_pos hα hα') (adaL_sub_one_pos hα hα')

/-! ### `θ = α^{1/(L-1)}` and `ρ = α^{-1/(L-1)}` -/

/-- `α^y = exp(-ln(1/α) y)`. -/
lemma rpow_eq_exp_neg (hα : 0 < α) (y : ℝ) : α ^ y = Real.exp (-(Real.log (1 / α) * y)) := by
  rw [Real.rpow_def_of_pos hα, one_div, Real.log_inv]
  congr 1
  ring

/-- `θ = exp(-ln(1/α)/(L-1))`. -/
lemma theta_eq_exp (hα : 0 < α) :
    α ^ (1 / ((adaL α : ℝ) - 1)) = Real.exp (-(Real.log (1 / α) / ((adaL α : ℝ) - 1))) := by
  rw [rpow_eq_exp_neg hα]
  congr 1
  ring

/-- `ρ = exp(ln(1/α)/(L-1))`. -/
lemma rho_eq_exp (hα : 0 < α) :
    α ^ (-(1 / ((adaL α : ℝ) - 1))) = Real.exp (Real.log (1 / α) / ((adaL α : ℝ) - 1)) := by
  rw [rpow_eq_exp_neg hα]
  congr 1
  ring

/-- `ρ = θ⁻¹`. -/
lemma rho_eq_inv_theta (hα : 0 < α) :
    α ^ (-(1 / ((adaL α : ℝ) - 1))) = (α ^ (1 / ((adaL α : ℝ) - 1)))⁻¹ :=
  Real.rpow_neg hα.le _

lemma theta_pos (hα : 0 < α) : 0 < α ^ (1 / ((adaL α : ℝ) - 1)) :=
  Real.rpow_pos_of_pos hα _

lemma rho_pos (hα : 0 < α) : 0 < α ^ (-(1 / ((adaL α : ℝ) - 1))) :=
  Real.rpow_pos_of_pos hα _

/-- `1 < ρ` (`I:lem:threshold_properties`(a)). -/
lemma one_lt_rho (hα : 0 < α) (hα' : α < 1 / 16) : 1 < α ^ (-(1 / ((adaL α : ℝ) - 1))) := by
  rw [rho_eq_exp hα]
  exact Real.one_lt_exp_iff.mpr (log_inv_div_pos hα hα')

/-- `ρ < e` (`I:lem:threshold_properties`(a)). -/
lemma rho_lt_exp_one (hα : 0 < α) (hα' : α < 1 / 16) :
    α ^ (-(1 / ((adaL α : ℝ) - 1))) < Real.exp 1 := by
  rw [rho_eq_exp hα]
  exact Real.exp_lt_exp.mpr (log_inv_div_lt_one hα hα')

/-- `e^{3/5} < ρ` (`I:eq:sec6_rho_bounds`). -/
lemma exp_three_fifths_lt_rho (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.exp (3 / 5) < α ^ (-(1 / ((adaL α : ℝ) - 1))) := by
  rw [rho_eq_exp hα]
  exact Real.exp_lt_exp.mpr (three_fifths_lt_log_inv_div hα hα')

/-- `ρ < 2.7182818286`. -/
lemma rho_lt_e_d9 (hα : 0 < α) (hα' : α < 1 / 16) :
    α ^ (-(1 / ((adaL α : ℝ) - 1))) < 2.7182818286 :=
  (rho_lt_exp_one hα hα').trans Real.exp_one_lt_d9

/-- `θ < 1`. -/
lemma theta_lt_one (hα : 0 < α) (hα' : α < 1 / 16) : α ^ (1 / ((adaL α : ℝ) - 1)) < 1 :=
  Real.rpow_lt_one hα.le (by linarith) (one_div_pos.mpr (adaL_sub_one_pos hα hα'))

/-- `e⁻¹ < θ`. -/
lemma exp_neg_one_lt_theta (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.exp (-1) < α ^ (1 / ((adaL α : ℝ) - 1)) := by
  rw [theta_eq_exp hα]
  apply Real.exp_lt_exp.mpr
  have := log_inv_div_lt_one hα hα'
  linarith

/-- `θ < e^{-3/5}`. -/
lemma theta_lt_exp_neg (hα : 0 < α) (hα' : α < 1 / 16) :
    α ^ (1 / ((adaL α : ℝ) - 1)) < Real.exp (-(3 / 5)) := by
  rw [theta_eq_exp hα]
  apply Real.exp_lt_exp.mpr
  have := three_fifths_lt_log_inv_div hα hα'
  linarith

/-- `e^{6/5} > 3.26` (`e > 2.718`, `e^{1/5} ≥ 1.2`). -/
lemma exp_six_fifths_gt : (326 / 100 : ℝ) < Real.exp (6 / 5) := by
  have h1 := Real.exp_one_gt_d9
  have h2 := Real.add_one_le_exp (1 / 5 : ℝ)
  have h3 : Real.exp (6 / 5) = Real.exp 1 * Real.exp (1 / 5) := by
    rw [← Real.exp_add]; norm_num
  rw [h3]
  norm_num at h1 h2
  nlinarith

/-- `θ² = ρ^{-2} < e^{-6/5} < 0.31`. -/
lemma theta_sq_lt (hα : 0 < α) (hα' : α < 1 / 16) :
    (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 < 31 / 100 := by
  have h1 := theta_lt_exp_neg hα hα'
  have h0 := theta_pos hα
  have h2 : Real.exp (-(3 / 5)) ^ 2 = (Real.exp (6 / 5))⁻¹ := by
    rw [← Real.exp_nat_mul, ← Real.exp_neg]; norm_num
  have h3 := exp_six_fifths_gt
  have h4 : (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 < Real.exp (-(3 / 5)) ^ 2 := by gcongr
  rw [h2] at h4
  have h5 : (Real.exp (6 / 5))⁻¹ < 100 / 326 := by
    rw [inv_lt_comm₀ (Real.exp_pos _) (by norm_num)]
    norm_num
    linarith
  linarith

/-- `e^{-2} < θ² = ρ^{-2}` (`I:lem:threshold_properties`(a)). -/
lemma exp_neg_two_lt_theta_sq (hα : 0 < α) (hα' : α < 1 / 16) :
    Real.exp (-2) < (α ^ (1 / ((adaL α : ℝ) - 1))) ^ 2 := by
  have h1 := exp_neg_one_lt_theta hα hα'
  have h2 : Real.exp (-1) ^ 2 = Real.exp (-2) := by
    rw [← Real.exp_nat_mul]; norm_num
  rw [← h2]
  gcongr

/-- `θ^{L-1} = α`. -/
lemma theta_pow_adaL_sub_one (hα : 0 < α) (hα' : α < 1 / 16) :
    (α ^ (1 / ((adaL α : ℝ) - 1))) ^ (adaL α - 1) = α := by
  have h5 := five_le_adaL hα hα'
  rw [← Real.rpow_natCast, ← Real.rpow_mul hα.le, Nat.cast_sub (by omega)]
  push_cast
  rw [one_div_mul_cancel (adaL_sub_one_pos hα hα').ne', Real.rpow_one]

/-! ### Unconditional facts on `L` -/

/-- `L ≥ 4` for every `α` (first entry of the maximum). -/
lemma four_le_adaL (α : ℝ) : 4 ≤ adaL α := le_max_left _ _

lemma adaL_cast_pos (α : ℝ) : (0 : ℝ) < (adaL α : ℝ) := by
  have : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  linarith

/-! ### The validator privacy schedule `ε_r = 0.05 α^{(r-1)/(L-1)}` -/

/-- `ε_1 = 1/20`. -/
lemma adaEps_at_one (α : ℝ) : adaEps α 1 = 1 / 20 := by
  simp [adaEps]

lemma adaEps_pos (hα : 0 < α) (r : ℕ) : 0 < adaEps α r := by
  unfold adaEps
  have := Real.rpow_pos_of_pos hα (((r : ℝ) - 1) / ((adaL α : ℝ) - 1))
  positivity

/-- `ε_r = θ^{r-1}/20` with `θ = α^{1/(L-1)}`, for `r ≥ 1`. -/
lemma adaEps_eq_pow (hα : 0 < α) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α r = 1 / 20 * (α ^ (1 / ((adaL α : ℝ) - 1))) ^ (r - 1) := by
  unfold adaEps
  rw [← Real.rpow_natCast, ← Real.rpow_mul hα.le, Nat.cast_sub hr]
  congr 2
  push_cast
  ring

/-- `ε_{r+1} = θ ε_r` for `r ≥ 1`. -/
lemma adaEps_succ (hα : 0 < α) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α (r + 1) = adaEps α r * α ^ (1 / ((adaL α : ℝ) - 1)) := by
  rw [adaEps_eq_pow hα hr, adaEps_eq_pow hα (by omega : 1 ≤ r + 1)]
  have : r + 1 - 1 = (r - 1) + 1 := by omega
  rw [this, pow_succ]
  ring

/-- `ε_r / ε_{r+1} = ρ` for `r ≥ 1` (`I:eq:eps_r_schedule`). -/
lemma adaEps_div_succ (hα : 0 < α) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α r / adaEps α (r + 1) = α ^ (-(1 / ((adaL α : ℝ) - 1))) := by
  rw [adaEps_succ hα hr, rho_eq_inv_theta hα]
  have h1 := adaEps_pos hα r
  have h2 := theta_pos (α := α) hα
  field_simp

/-- `ε_r = ρ ε_{r+1}` for `r ≥ 1`. -/
lemma adaEps_eq_rho_mul_succ (hα : 0 < α) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α r = α ^ (-(1 / ((adaL α : ℝ) - 1))) * adaEps α (r + 1) := by
  rw [← adaEps_div_succ hα hr]
  have := adaEps_pos hα (r + 1)
  field_simp

/-- `ε_r` is strictly decreasing in `r` (`I:lem:threshold_properties`(a)). -/
lemma adaEps_lt_of_lt (hα : 0 < α) (hα' : α < 1 / 16) {r s : ℕ} (hrs : r < s) :
    adaEps α s < adaEps α r := by
  unfold adaEps
  have hD := adaL_sub_one_pos hα hα'
  have hrs' : ((r : ℝ) - 1) / ((adaL α : ℝ) - 1) < ((s : ℝ) - 1) / ((adaL α : ℝ) - 1) := by
    apply div_lt_div_of_pos_right _ hD
    have : (r : ℝ) < (s : ℝ) := by exact_mod_cast hrs
    linarith
  have := Real.rpow_lt_rpow_of_exponent_gt hα (by linarith) hrs'
  linarith

lemma adaEps_le_of_le (hα : 0 < α) (hα' : α < 1 / 16) {r s : ℕ} (hrs : r ≤ s) :
    adaEps α s ≤ adaEps α r := by
  rcases hrs.lt_or_eq with h | h
  · exact (adaEps_lt_of_lt hα hα' h).le
  · rw [h]

/-- `ε_r ≤ 1/20` for `r ≥ 1`. -/
lemma adaEps_le_one_twentieth (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : 1 ≤ r) :
    adaEps α r ≤ 1 / 20 := by
  rw [← adaEps_at_one α]
  exact adaEps_le_of_le hα hα' hr

/-- `ε_{L-1} = 0.05 α ρ` (`I:eq:sec6_terminal_eps_ratio`). -/
lemma adaEps_L_sub_one (hα : 0 < α) (hα' : α < 1 / 16) :
    adaEps α (adaL α - 1) = 1 / 20 * α * α ^ (-(1 / ((adaL α : ℝ) - 1))) := by
  have h5 := five_le_adaL hα hα'
  have h := theta_pow_adaL_sub_one hα hα'
  rw [adaEps_eq_pow hα (by omega : 1 ≤ adaL α - 1), rho_eq_inv_theta hα]
  have hθ := theta_pos (α := α) hα
  set θ := α ^ (1 / ((adaL α : ℝ) - 1)) with hθdef
  have hθne : θ ≠ 0 := hθ.ne'
  have hsplit : adaL α - 1 = (adaL α - 1 - 1) + 1 := by omega
  rw [hsplit, pow_succ] at h
  calc 1 / 20 * θ ^ (adaL α - 1 - 1) = 1 / 20 * (θ ^ (adaL α - 1 - 1) * θ) * θ⁻¹ := by
        field_simp
    _ = 1 / 20 * α * θ⁻¹ := by rw [h]

/-- `ε_{L-1} > 0.05 α`. -/
lemma adaEps_L_sub_one_gt (hα : 0 < α) (hα' : α < 1 / 16) :
    1 / 20 * α < adaEps α (adaL α - 1) := by
  rw [adaEps_L_sub_one hα hα']
  have := one_lt_rho hα hα'
  nlinarith

/-- For `1 ≤ r ≤ L - 1`: `ε_r ≥ ε_{L-1} > 0.05 α`. -/
lemma adaEps_gt_of_le (hα : 0 < α) (hα' : α < 1 / 16) {r : ℕ} (hr : r ≤ adaL α - 1) :
    1 / 20 * α < adaEps α r :=
  (adaEps_L_sub_one_gt hα hα').trans_le (adaEps_le_of_le hα hα' hr)

/-! ### Margin `γ`, Laplace unit `u₀`, anchor privacy `ε_L`, anchor radius `r_anc` -/

lemma adaGamma_pos (hα : 0 < α) : 0 < adaGamma α := by
  unfold adaGamma
  have := adaL_cast_pos α
  positivity

/-- `u₀ = α/(256 L)`. -/
lemma adaU0_eq (α : ℝ) : adaU0 α = α / (256 * (adaL α : ℝ)) := by
  unfold adaU0 adaGamma
  ring

lemma adaU0_pos (hα : 0 < α) : 0 < adaU0 α := by
  rw [adaU0_eq]
  have := adaL_cast_pos α
  positivity

/-- `u₀ = γ/32`. -/
lemma adaU0_eq_gamma (α : ℝ) : adaU0 α = adaGamma α / 32 := rfl

/-- `ε_L = u₀/2 = α/(512 L)`. -/
lemma adaEpsL_eq (α : ℝ) : adaEpsL α = α / (512 * (adaL α : ℝ)) := by
  unfold adaEpsL
  rw [adaU0_eq]
  ring

lemma adaEpsL_pos (hα : 0 < α) : 0 < adaEpsL α := by
  rw [adaEpsL_eq]
  have := adaL_cast_pos α
  positivity

/-- `r_anc = 4 ε_L = 2 u₀`. -/
lemma adaRanc_eq_two_u0 (α : ℝ) : adaRanc α = 2 * adaU0 α := by
  unfold adaRanc adaEpsL
  ring

/-- `r_anc = α/(128 L) = γ/16`. -/
lemma adaRanc_eq (α : ℝ) : adaRanc α = α / (128 * (adaL α : ℝ)) := by
  rw [adaRanc_eq_two_u0, adaU0_eq]
  ring

lemma adaRanc_pos (hα : 0 < α) : 0 < adaRanc α := by
  rw [adaRanc_eq_two_u0]
  have := adaU0_pos hα
  positivity

/-- `γ ≤ α/40`. -/
lemma adaGamma_le (hα : 0 < α) (hα' : α < 1 / 16) : adaGamma α ≤ α / 40 := by
  unfold adaGamma
  have hL := five_le_adaL_real hα hα'
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith

/-- `u₀ ≤ α/1280`. -/
lemma adaU0_le (hα : 0 < α) (hα' : α < 1 / 16) : adaU0 α ≤ α / 1280 := by
  rw [adaU0_eq]
  have hL := five_le_adaL_real hα hα'
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith

/-- `u₀ < 1/20480 < 10⁻⁴`. -/
lemma adaU0_lt (hα : 0 < α) (hα' : α < 1 / 16) : adaU0 α < 1 / 20480 := by
  have := adaU0_le hα hα'
  linarith

/-- `ε_L < ε_{L-1}` (`I:lem:threshold_properties`(a)). -/
lemma adaEpsL_lt_adaEps (hα : 0 < α) (hα' : α < 1 / 16) :
    adaEpsL α < adaEps α (adaL α - 1) := by
  have h1 := adaEps_L_sub_one_gt hα hα'
  have h2 : adaEpsL α ≤ α / 2560 := by
    rw [adaEpsL_eq]
    have hL := five_le_adaL_real hα hα'
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    nlinarith
  linarith

/-! ### Validator failure budget `δ_val = u₀³β/(10⁸L³)` and `L_val = ln(4/δ_val)` -/

/-- `δ_val = α³β/(256³·10⁸·L⁶)` (`I:eq:sec6_Lval_asymptotic`). -/
lemma adaDeltaVal_eq (α β : ℝ) :
    adaDeltaVal α β = α ^ 3 * β / (256 ^ 3 * 10 ^ 8 * (adaL α : ℝ) ^ 6) := by
  unfold adaDeltaVal
  rw [adaU0_eq]
  ring

lemma adaDeltaVal_pos (hα : 0 < α) (hβ : 0 < β) : 0 < adaDeltaVal α β := by
  rw [adaDeltaVal_eq]
  have := adaL_cast_pos α
  positivity

/-- `δ_val < 5·10⁻²⁴`. -/
lemma adaDeltaVal_lt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaDeltaVal α β < 5 / 10 ^ 24 := by
  rw [adaDeltaVal_eq]
  have hL := five_le_adaL_real hα hα'
  have hL6 : (5 : ℝ) ^ 6 ≤ (adaL α : ℝ) ^ 6 := by gcongr
  have h1 : α ^ 3 * β < (1 / 16) ^ 3 * (1 / 2) := by
    have : α ^ 3 < (1 / 16) ^ 3 := by gcongr
    exact mul_lt_mul'' this hβ' (by positivity) hβ.le
  rw [div_lt_iff₀ (by positivity)]
  calc α ^ 3 * β < (1 / 16) ^ 3 * (1 / 2) := h1
    _ ≤ 5 / 10 ^ 24 * (256 ^ 3 * 10 ^ 8 * 5 ^ 6) := by norm_num
    _ ≤ 5 / 10 ^ 24 * (256 ^ 3 * 10 ^ 8 * (adaL α : ℝ) ^ 6) := by gcongr

lemma adaDeltaVal_lt_one (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaDeltaVal α β < 1 := by
  have := adaDeltaVal_lt hα hα' hβ hβ'
  have h : (5 : ℝ) / 10 ^ 24 < 1 := by norm_num
  linarith

/-- `4/δ_val > 8·10²³`. -/
lemma four_div_adaDeltaVal_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (8 * 10 ^ 23 : ℝ) < 4 / adaDeltaVal α β := by
  have h1 := adaDeltaVal_lt hα hα' hβ hβ'
  have h0 := adaDeltaVal_pos hα hβ
  rw [lt_div_iff₀ h0]
  calc (8 * 10 ^ 23 : ℝ) * adaDeltaVal α β < 8 * 10 ^ 23 * (5 / 10 ^ 24) := by gcongr
    _ = 4 := by norm_num

/-- `exp 49 < 8·10²³` (from `e < 3`). -/
lemma exp_forty_nine_lt : Real.exp 49 < 8 * 10 ^ 23 := by
  have h1 := Real.exp_one_lt_d9
  have h3 : Real.exp 1 < 3 := by norm_num at h1; linarith
  have h4 : Real.exp 1 ^ 49 < 3 ^ 49 := by gcongr
  rw [Real.exp_one_pow] at h4
  have h5 : (3 : ℝ) ^ 49 < 8 * 10 ^ 23 := by norm_num
  push_cast at h4
  linarith

/-- `L_val > 49` (the paper uses `L_val > 25`). -/
lemma adaLval_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (49 : ℝ) < adaLval α β := by
  unfold adaLval
  have h0 := adaDeltaVal_pos hα hβ
  rw [Real.lt_log_iff_exp_lt (by positivity)]
  exact exp_forty_nine_lt.trans (four_div_adaDeltaVal_gt hα hα' hβ hβ')

lemma adaLval_pos (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    0 < adaLval α β := by
  have := adaLval_gt hα hα' hβ hβ'
  linarith

/-! ### Working-sample logarithm `L₁ = ln(20480/(αβ))` -/

/-- `1/(αβ) > 32`. -/
lemma inv_mul_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (32 : ℝ) < 1 / (α * β) := by
  rw [lt_div_iff₀ (by positivity)]
  have : α * β < 1 / 16 * (1 / 2) := mul_lt_mul'' hα' hβ' hα.le hβ.le
  linarith

/-- `ln(1/(αβ)) > ln 32 > 3.46`. -/
lemma log_inv_mul_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (346 / 100 : ℝ) < Real.log (1 / (α * β)) := by
  have h1 : Real.log 32 < Real.log (1 / (α * β)) :=
    Real.log_lt_log (by norm_num) (inv_mul_gt hα hα' hβ hβ')
  have h2 : Real.log 32 = 5 * Real.log 2 := by
    rw [show (32 : ℝ) = 2 ^ 5 by norm_num, Real.log_pow]
    norm_num
  have h3 := Real.log_two_gt_d9
  norm_num at h3
  linarith

/-- `20480/(αβ) > 1`, so `L₁ > 0`; in fact `L₁ > ln(655360) > 13`. -/
lemma adaL1_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (13 : ℝ) < adaL1 α β := by
  unfold adaL1
  have h1 := inv_mul_gt hα hα' hβ hβ'
  have h2 : (20480 : ℝ) / (α * β) = 20480 * (1 / (α * β)) := by ring
  rw [h2, Real.lt_log_iff_exp_lt (by positivity)]
  have h3 := Real.exp_one_lt_d9
  have h4 : Real.exp 1 < 68 / 25 := by norm_num at h3; linarith
  have h5 : Real.exp 1 ^ 13 < (68 / 25) ^ 13 := by gcongr
  rw [Real.exp_one_pow] at h5
  push_cast at h5
  have h6 : ((68 : ℝ) / 25) ^ 13 < 20480 * 32 := by norm_num
  linarith

lemma adaL1_pos (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    0 < adaL1 α β := by
  have := adaL1_gt hα hα' hβ hβ'
  linarith

/-- `L₁ ≤ 4 ln(1/(αβ))` (as `20480 < 32³ < (1/(αβ))³`). -/
lemma adaL1_le_four_mul (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    adaL1 α β ≤ 4 * Real.log (1 / (α * β)) := by
  unfold adaL1
  have h1 := inv_mul_gt hα hα' hβ hβ'
  set w := 1 / (α * β) with hw
  have h2 : (20480 : ℝ) / (α * β) = 20480 * w := by rw [hw]; ring
  rw [h2, show (4 : ℝ) * Real.log w = Real.log (w ^ 4) by rw [Real.log_pow]; norm_num]
  apply Real.log_le_log (by positivity)
  have h3 : (32 : ℝ) ^ 3 ≤ w ^ 3 := by gcongr
  have h4 : (20480 : ℝ) ≤ w ^ 3 := by nlinarith
  calc 20480 * w ≤ w ^ 3 * w := by gcongr
    _ = w ^ 4 := by ring

/-- `χ₁ ≥ 0`. -/
lemma adaChi1_nonneg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    0 ≤ adaChi1 α β := by
  unfold adaChi1
  split_ifs
  · exact Real.sqrt_nonneg _
  · exact (adaL1_pos hα hα' hβ hβ').le

/-! ### Episode caps are `≥ 1`; the `AboveThreshold` scale `b_SVT` -/

lemma one_le_adaMmax (α : ℝ) (r : ℕ) : 1 ≤ adaMmax α r := by
  unfold adaMmax
  split_ifs <;> omega

lemma one_le_adaMmax_real (α : ℝ) (r : ℕ) : (1 : ℝ) ≤ (adaMmax α r : ℝ) := by
  exact_mod_cast one_le_adaMmax α r

/-- The argument of `Λ_SVT = ln(64 L k M_{2,max}/δ_val)` dominates `4/δ_val`. -/
lemma four_div_le_svt_arg (hα : 0 < α) (hβ : 0 < β) {k : ℕ} (hk : 1 ≤ k) :
    4 / adaDeltaVal α β ≤
      64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β := by
  have h0 := adaDeltaVal_pos hα hβ
  have hL : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hM := one_le_adaMmax_real α 2
  apply div_le_div_of_nonneg_right _ h0.le
  have : (1 : ℝ) ≤ (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) := by
    have h1 : (1 : ℝ) ≤ (adaL α : ℝ) * (k : ℝ) := by nlinarith
    nlinarith
  nlinarith

/-- `L_val ≤ Λ_SVT`. -/
lemma adaLval_le_log_svt (hα : 0 < α) (hβ : 0 < β) {k : ℕ} (hk : 1 ≤ k) :
    adaLval α β ≤
      Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) := by
  unfold adaLval
  have h0 := adaDeltaVal_pos hα hβ
  exact Real.log_le_log (by positivity) (four_div_le_svt_arg hα hβ hk)

/-- `Λ_SVT > 49`. -/
lemma log_svt_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    (49 : ℝ) <
      Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) :=
  (adaLval_gt hα hα' hβ hβ').trans_le (adaLval_le_log_svt hα hβ hk)

lemma log_svt_pos (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    0 < Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) := by
  have := log_svt_gt hα hα' hβ hβ' hk
  linarith

/-- `b_SVT = u₀/Λ_SVT > 0`. -/
lemma adaBsvt_pos (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : 0 < adaBsvt k α β := by
  unfold adaBsvt
  exact div_pos (adaU0_pos hα) (log_svt_pos hα hα' hβ hβ' hk)

/-- `b_SVT = α/(256 L Λ_SVT)` (`I:prop:validator_sample_complexity`(2): `1/b_SVT = 256 L Λ_SVT/α`). -/
lemma adaBsvt_eq (k : ℕ) (α β : ℝ) :
    adaBsvt k α β = α / (256 * (adaL α : ℝ) *
      Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β)) := by
  unfold adaBsvt
  rw [adaU0_eq]
  ring

/-- `b_SVT < u₀`, in particular `b_SVT < 1/20480`. -/
lemma adaBsvt_lt_u0 (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : adaBsvt k α β < adaU0 α := by
  unfold adaBsvt
  have h1 := log_svt_gt hα hα' hβ hβ' hk
  have h2 := adaU0_pos hα
  rw [div_lt_iff₀ (by linarith)]
  nlinarith

/-- `ln(6k/δ_val) ≤ Λ_SVT` (as `6 < 64 L M_{2,max}`). -/
lemma log_six_k_le_log_svt (hα : 0 < α) (hβ : 0 < β) {k : ℕ} (hk : 1 ≤ k) :
    Real.log (6 * (k : ℝ) / adaDeltaVal α β) ≤
      Real.log (64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β) := by
  have h0 := adaDeltaVal_pos hα hβ
  have hL : (4 : ℝ) ≤ (adaL α : ℝ) := by exact_mod_cast four_le_adaL α
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hM := one_le_adaMmax_real α 2
  apply Real.log_le_log (by positivity)
  apply div_le_div_of_nonneg_right _ h0.le
  have h1 : (6 : ℝ) ≤ 64 * (adaL α : ℝ) * (adaMmax α 2 : ℝ) := by nlinarith
  nlinarith

/-- `ln(6k/δ_val) > 49`, in particular the Ghost-Monitor logarithm is positive. -/
lemma log_six_k_gt (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : (49 : ℝ) < Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
  have h0 := adaDeltaVal_pos hα hβ
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have h1 : adaLval α β ≤ Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
    unfold adaLval
    apply Real.log_le_log (by positivity)
    apply div_le_div_of_nonneg_right _ h0.le
    linarith
  exact (adaLval_gt hα hα' hβ hβ').trans_le h1

/-! ### All logarithm arguments exceed `1` -/

lemma one_lt_inv_alpha (hα : 0 < α) (hα' : α < 1 / 16) : (1 : ℝ) < 1 / α := by
  have := sixteen_lt_inv hα hα'
  linarith

lemma one_lt_adaL1_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (1 : ℝ) < 20480 / (α * β) := by
  have h := inv_mul_gt hα hα' hβ hβ'
  have : (20480 : ℝ) / (α * β) = 20480 * (1 / (α * β)) := by ring
  rw [this]
  linarith

lemma one_lt_adaLval_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (1 : ℝ) < 4 / adaDeltaVal α β := by
  have := four_div_adaDeltaVal_gt hα hα' hβ hβ'
  linarith

lemma one_lt_svt_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) :
    (1 : ℝ) < 64 * (adaL α : ℝ) * (k : ℝ) * (adaMmax α 2 : ℝ) / adaDeltaVal α β :=
  (one_lt_adaLval_arg hα hα' hβ hβ').trans_le (four_div_le_svt_arg hα hβ hk)

lemma one_lt_six_k_arg (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : (1 : ℝ) < 6 * (k : ℝ) / adaDeltaVal α β := by
  have h0 := adaDeltaVal_pos hα hβ
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have h1 := one_lt_adaLval_arg hα hα' hβ hβ'
  have h2 : 4 / adaDeltaVal α β ≤ 6 * (k : ℝ) / adaDeltaVal α β := by
    apply div_le_div_of_nonneg_right _ h0.le
    linarith
  linarith

lemma one_lt_inv_mul (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (1 : ℝ) < 1 / (α * β) := by
  have := inv_mul_gt hα hα' hβ hβ'
  linarith

end Basic

end A

end F2e2e
