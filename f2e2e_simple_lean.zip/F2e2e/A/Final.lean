import F2e2e.A.ArchMeasurable
import F2e2e.A.NumericsContracts
import F2e2e.A.Closure
import F2e2e.A.Model
import F2e2e.A.SpecV2BridgeTheoremA

/-!
# Part I: Main Theorem (A) (`F2e2e.Theorem_A_statistical`)

Paper: `parts/partI.tex` Theorem `I:thm:main` (L8-35), proof (L2258-2260): (acc) from Proposition
`I:prop:end_to_end_accuracy` via Lemma `I:lem:tonelli_fubini`; the explicit bound (`I:eq:main_explicit_bound`)
and the asymptotic form from Proposition `I:prop:validator_sample_complexity`.

## The headline: `theorem_A_statistical_proof : Theorem_A_statistical`

The Spec states (A) for the paper's own mechanism: the cascade `adaCascade k α β` of Definition `I:def:mechanism`
(locked parameters and allocation, coin law `adaCoinLaw k α β`, full public records) with
`n = adaSampleSize k α β` samples. The five conjuncts are assembled in `F2e2e/A/SpecV2BridgeTheoremA.lean`
(`V2Bridge.theorem_A_statistical_bridge`, A-ACC):
1. `IsProbabilityMeasure (adaCoinLaw k α β)`: `V2Meas.isProbabilityMeasure_adaCoinLaw`
   (`F2e2e/A/ArchSpecV2Meas.lean`, with `adaBsvt_pos`);
2. `(adaCascade k α β).JointlyMeasurable`: `V2Meas.jointlyMeasurable_adaCascade` (`F2e2e/A/ArchSpecV2Meas.lean`);
3. and 4. the explicit and the asymptotic bound on `adaSampleSize`: `adaSampleSize_le_explicit`,
   `adaSampleSize_le_asymp` (`F2e2e/A/NumericsContracts.lean`, A-NUM);
5. `ADAPublicGuarantee`: `adaPublicGuarantee_adaCascade` (`F2e2e/A/SpecV2BridgeGuarantee.lean`). The analyst's
   view of the public records is A-NUM's record interaction `recRun` (`F2e2e/A/Model.lean`), whose Tonelli–Fubini
   reduction leaves deterministic analysts; these induce record-seeing analysts `Bd α B` of the transcript
   (`F2e2e/A/SpecV2BridgeRound.lean`: the cascade's rounds are `adaMech`'s), so Proposition
   `I:prop:end_to_end_accuracy` for deterministic analysts (`adaMech_accurate_det`, `F2e2e/A/Closure.lean`)
   gives the bound.

## The v1 statement (`F2e2e.Theorem_A`, compatibility layer `F2e2e/SpecV1Compat.lean`)

The mechanism is `adaMech k α β` (`F2e2e/A/Mechanism.lean`) with `n = adaSampleSize k α β` samples, coin space
`AdaOmega k α` and coin law `adaNoiseMeasure k α β`. Inputs:
* `TonelliReduction`: Lemma `I:lem:tonelli_fubini`(i) for mechanisms with jointly measurable answers
  (`adaGuarantee_of_det`, `F2e2e/A/Model.lean`, owner A-NUM);
* `DetAccuracy`: Proposition `I:prop:end_to_end_accuracy` for deterministic analysts
  (`adaMech_accurate_det`, Part I §5-6 files, owner 295bf129);
* `measurable_adaMech` (`F2e2e/A/ArchMeasurable.lean`);
* the numeric contracts `adaSampleSize_le_explicit`, `adaSampleSize_le_asymp`
  (`F2e2e/A/NumericsContracts.lean`, owner A-NUM).

`theorem_A_of_parts` is the assembly (no `sorry`). `theorem_A_proof` instantiates it with
`adaGuarantee_of_det` (`F2e2e/A/Model.lean`) and `adaMech_accurate_det` (`F2e2e/A/Closure.lean`).
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## The headline (Spec v2/v2.1) -/

/-- **Main Theorem (A)** (Theorem `I:thm:main`), statistical content, for the paper's own mechanism
`adaCascade k α β` (the Spec's headline `F2e2e.Theorem_A_statistical`). -/
theorem theorem_A_statistical_proof : Theorem_A_statistical :=
  V2Bridge.theorem_A_statistical_bridge

/-! ## The v1 statement -/

/-- The Tonelli–Fubini reduction (Lemma `I:lem:tonelli_fubini`(i)) for a mechanism with jointly measurable
answers: the failure bound against every deterministic analyst implies the Spec's guarantee against every
randomized analyst. (The statement of `adaGuarantee_of_det`.) -/
def TonelliReduction : Prop :=
  ∀ {n k : ℕ} {α β : ℝ} {ΩM : Type} [MeasurableSpace ΩM] (PM : Measure ΩM) [IsProbabilityMeasure PM]
    (mech : ADAMechanism n ΩM),
    (∀ i, Measurable (fun p : (Fin (i + 1) → Fin n → ℝ) × ΩM => mech i p.1 p.2)) →
    (∀ (X : Type) [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D] (A : AnsAnalyst X),
      A.Valid → A.JointlyMeasurable →
        ((Measure.pi fun _ : Fin n => D).prod PM) {z | adaFails mech A.toADA D k α z.1 z.2 ()} ≤
          ENNReal.ofReal β) →
    ADAGuarantee n k α β PM mech

/-- The deterministic-analyst accuracy of the cascade (Proposition `I:prop:end_to_end_accuracy`): for every
deterministic analyst (seeing the public records of the previous rounds), the probability over `S ∼ D^n` and the
mechanism's noise that some answer is more than `α` away from the population mean of its query is at most `β`.
(The statement of `adaMech_accurate_det`.) -/
def DetAccuracy : Prop :=
  ∀ (k : ℕ) (α β : ℝ), 1 ≤ k → 0 < α → α < 1 / 16 → 0 < β → β < 1 / 2 →
    ∀ {X : Type} [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X),
      A.Valid → A.JointlyMeasurable →
        adaProb k α β D {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
          popMu D A (transcript k α β A z.1 z.2) i|} ≤ ENNReal.ofReal β

/-- **Main Theorem (A)** from its parts (v1 statement): the mechanism `adaMech k α β` with
`n = adaSampleSize k α β` samples witnesses `Theorem_A`, with the universal constant of
`adaSampleSize_le_asymp`. -/
theorem theorem_A_of_parts (hT : TonelliReduction) (hD : DetAccuracy) : Theorem_A := by
  obtain ⟨C, hC, hasymp⟩ := adaSampleSize_le_asymp
  refine ⟨C, hC, fun k α β hk hα hα' hβ hβ' => ?_⟩
  refine ⟨adaSampleSize k α β, AdaOmega k α, inferInstance, adaNoiseMeasure k α β, inferInstance,
    adaMech k α β, le_rfl, adaSampleSize_le_explicit k α β hk hα hα' hβ hβ',
    hasymp k α β hk hα hα' hβ hβ', ?_⟩
  refine hT (adaNoiseMeasure k α β) (adaMech k α β) (measurable_adaMech k α β) (fun X _ D _ A hA hAm => ?_)
  -- an answer-only analyst is the record-seeing analyst `A.toDet`
  have h := hD k α β hk hα hα' hβ hβ' (X := X) D A.toDet (AnsAnalyst.valid_toDet hA)
    (AnsAnalyst.jointlyMeasurable_toDet hAm)
  have hset : {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α |
      adaFails (adaMech k α β) A.toADA D k α z.1 z.2 ()} =
      {z | ∃ i : Fin k, α < |(transcript k α β A.toDet z.1 z.2 i).answer -
        popMu D A.toDet (transcript k α β A.toDet z.1 z.2) i|} := by
    ext z
    exact adaFails_adaMech_iff D A z.1 z.2 α
  rw [hset]
  exact h

/-- **Main Theorem (A)** (Theorem `I:thm:main`), v1 statement (`F2e2e/SpecV1Compat.lean`). -/
theorem theorem_A_proof : Theorem_A :=
  theorem_A_of_parts (fun PM _ mech hmech hdet => adaGuarantee_of_det PM mech hmech hdet)
    (fun k α β hk hα hα' hβ hβ' => adaMech_accurate_det k α β hk hα hα' hβ hβ')

end A

end F2e2e
