import F2e2e.A.ArchMeasurable
import F2e2e.A.S1PrivacyTriangular

/-!
# Part I: the Stage-1 factorization of the transcript

Owner: A-ARCH. Interface for Lemma `I:lem:working_sample_privacy`(3) (`F2e2e/A/S1Privacy*.lean`, owner c186bcb5).

Paper: `parts/partI.tex` L616-681 (Step 1 of the proof of Lemma `I:lem:working_sample_privacy`): with the other
blocks, the validator noise and the analyst fixed, the transcript is a post-processing of the unclipped Stage-1
releases `ã_i = θ_i^{(1)}(S₁; ã_{<i}) + R₁ V_i`, and `θ_i^{(1)}` is a weighted mean with public coefficients.

## Release-driven run
`relRun k α β A S ω a` is the interaction where the clipped Stage-1 proposal of round `i` is `clip(a i)` for a
given release sequence `a` (instead of `clip(θ_i^{(1)} + ξ_i)`). It never reads the Stage-1 noise, and its records
do not depend on block 1 of the sample (`relRun_congr`).

## The factorization (fixed `S`, `ω'`, `A`; `S₁` the block, `ω` the Stage-1 noise)
* `s1Theta k α β A S ω' S₁ i a`: `θ_i^{(1)}` at the start of round `i` of the release-driven run with the sample
  `replaceBlock 1 S₁ S` and the releases `a` (it depends only on `a_{<i}`: `s1Theta_dependsOn`);
* `s1Psi k α β A S ω' a`: the records of the release-driven run (`S₁`-free);
* `s1Phi k α β A S ω' S₁ v = triangularSol (s1Theta … S₁) (R₁ • v)`: the release sequence;
* `transcript_eq_s1Psi`: `transcript k α β A (replaceBlock 1 S₁ S) (mixNoise 1 ω ω') =
  s1Psi … (s1Phi … S₁ (fun i => clampUnit (ω (.beta i))))`;
* `s1Theta_eq`: `s1Theta … S₁ i a = ∑ ℓ, waterFill n₁ 1 (∑_{j<i} c_j Q_j(S₁ ℓ)) ℓ * Q_i(S₁ ℓ)` with `S₁`-free
  coefficients `c_j = δ_{1,j}` and queries `Q_j` read off `s1Psi … a` (so `Opt.kkt_query_sensitivity` applies);
* measurability: `measurable_s1Theta`, `measurable_s1Psi`.
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## Congruence of the chain -/

namespace ChainData

theorem fires_congr {d d' : ChainData} (htau : d.tau = d'.tau)
    (h : ∀ r, 2 ≤ r → d.theta r = d'.theta r ∧ d.rho r = d'.rho r ∧ d.nu r = d'.nu r ∧
      d.zeta r = d'.zeta r) {r : ℕ} (hr : 2 ≤ r) (u : ℕ) (c : ℝ) : d.Fires r u c ↔ d'.Fires r u c := by
  obtain ⟨ht, hrho, hn, -⟩ := h r hr
  unfold Fires
  rw [htau, ht, hrho, hn]

theorem relV_congr {d d' : ChainData}
    (h : ∀ r, 2 ≤ r → d.theta r = d'.theta r ∧ d.rho r = d'.rho r ∧ d.nu r = d'.nu r ∧
      d.zeta r = d'.zeta r) {r : ℕ} (hr : 2 ≤ r) : d.relV r = d'.relV r := by
  obtain ⟨ht, -, -, hz⟩ := h r hr
  unfold relV
  rw [ht, hz]

theorem relC_congr {d d' : ChainData}
    (h : ∀ r, 2 ≤ r → d.theta r = d'.theta r ∧ d.rho r = d'.rho r ∧ d.nu r = d'.nu r ∧
      d.zeta r = d'.zeta r) {r : ℕ} (hr : 2 ≤ r) : d.relC r = d'.relC r := by
  unfold relC
  rw [relV_congr h hr]

section Congr

variable {d d' : ChainData} (hL : d.L = d'.L) (htau : d.tau = d'.tau) (hc1 : d.c1 = d'.c1)
  (h : ∀ r, 2 ≤ r → d.theta r = d'.theta r ∧ d.rho r = d'.rho r ∧ d.nu r = d'.nu r ∧
    d.zeta r = d'.zeta r)
include hL htau hc1 h

/-- Two chain data agreeing on everything the chain reads (`L`, `τ`, `c₁`, and stages `r ≥ 2`) have the same
origins. -/
theorem orig_congr (r : ℕ) : d.orig r = d'.orig r := by
  induction r with
  | zero => rw [orig_zero, orig_zero, hc1]
  | succ r ih =>
    have hT : d.Trig r ↔ d'.Trig r := by
      constructor
      · rintro ⟨h2, hLr, hF⟩
        refine ⟨h2, hL ▸ hLr, ?_⟩
        rw [← ih]
        exact (fires_congr htau h h2 _ _).mp hF
      · rintro ⟨h2, hLr, hF⟩
        refine ⟨h2, hL ▸ hLr, ?_⟩
        rw [ih]
        exact (fires_congr htau h h2 _ _).mpr hF
    by_cases hTr : d.Trig r
    · rw [d.orig_succ_of_trig hTr, d'.orig_succ_of_trig (hT.mp hTr),
        relC_congr h hTr.1]
    · rw [d.orig_succ_of_not_trig hTr, d'.orig_succ_of_not_trig (fun h' => hTr (hT.mpr h')), ih]

theorem trig_congr (r : ℕ) : d.Trig r ↔ d'.Trig r := by
  unfold Trig
  rw [orig_congr hL htau hc1 h r, hL]
  constructor
  · rintro ⟨h2, hLr, hF⟩
    exact ⟨h2, hLr, (fires_congr htau h h2 _ _).mp hF⟩
  · rintro ⟨h2, hLr, hF⟩
    exact ⟨h2, hLr, (fires_congr htau h h2 _ _).mpr hF⟩

theorem ufinal_congr : d.ufinal = d'.ufinal := by
  unfold ufinal
  rw [orig_congr hL htau hc1 h, hL]

theorem answer_congr : d.answer = d'.answer := by
  unfold answer
  rw [orig_congr hL htau hc1 h, hL]

theorem released_congr (r : ℕ) : d.Released r ↔ d'.Released r := by
  unfold Released
  rw [trig_congr hL htau hc1 h r, ufinal_congr hL htau hc1 h]

theorem sgn_congr : d.sgn = d'.sgn := by
  unfold sgn cprev
  rw [ufinal_congr hL htau hc1 h, answer_congr hL htau hc1 h, orig_congr hL htau hc1 h]

/-- **Chain congruence**: the record of a round only depends on `L`, `τ`, `c₁` and the stage-`r ≥ 2` data. -/
theorem toRec_congr (e1 e : ℝ) (eT : ℕ → ℝ) : d.toRec e1 e eT = d'.toRec e1 e eT := by
  have two_le : ∀ {r : ℕ}, d.Released r → 2 ≤ r := fun {r} hr => by
    rcases hr with hT | ⟨h3, h1⟩
    · exact hT.1
    · omega
  have hu := ufinal_congr hL htau hc1 h
  have hs := sgn_congr hL htau hc1 h
  unfold toRec
  congr 1
  · funext r
    exact decide_eq_decide.mpr (trig_congr hL htau hc1 h r)
  · funext r
    unfold uprev
    rw [orig_congr hL htau hc1 h]
  · funext r
    exact decide_eq_decide.mpr (released_congr hL htau hc1 h r)
  · funext r
    by_cases hr : d.Released r
    · rw [if_pos hr, if_pos ((released_congr hL htau hc1 h r).mp hr), relV_congr h (two_le hr)]
    · rw [if_neg hr, if_neg (fun h' => hr ((released_congr hL htau hc1 h r).mpr h'))]
  · funext r
    by_cases h1 : r = 1
    · rw [if_pos h1, if_pos h1, hc1]
    · rw [if_neg h1, if_neg h1]
      by_cases hr : d.Released r
      · rw [if_pos hr, if_pos ((released_congr hL htau hc1 h r).mp hr),
          relC_congr h (two_le hr)]
      · rw [if_neg hr, if_neg (fun h' => hr ((released_congr hL htau hc1 h r).mpr h'))]
  · exact answer_congr hL htau hc1 h
  · funext m
    unfold delta
    rw [hu, hs]

end Congr

end ChainData

/-! ## The release-driven run -/

section RelRun

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- The chain data of round `i` with the clipped Stage-1 proposal replaced by `c1`. -/
noncomputable def roundChainRel (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (c1 : ℝ) : ChainData :=
  { roundChain st i q ω with c1 := c1 }

theorem roundChain_eq_rel (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) :
    roundChain st i q ω = roundChainRel st i q ω (clip01 (stage1Release st i q ω)) := rfl

/-- One round with the clipped Stage-1 proposal `c1`. -/
noncomputable def stepRel (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) (c1 : ℝ) : MState k α β × RoundRec :=
  if st.halt then (st, RoundRec.halted)
  else (st.next q ((roundChainRel st i q ω c1).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)),
    (roundChainRel st i q ω c1).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α))

theorem step_eq_stepRel (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : step st i q ω = stepRel st i q ω (clip01 (stage1Release st i q ω)) := rfl

/-- The release-driven interaction with the deterministic analyst `A`: round `i` uses the clipped Stage-1
proposal `clip(a i)`. -/
noncomputable def relRun (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (a : ℕ → ℝ) : (i : ℕ) → MState k α β × (Fin i → RoundRec)
  | 0 => (MState.init, Fin.elim0)
  | i + 1 =>
      ((stepRel (relRun k α β A S ω a i).1 i
          (fun ℓ => A i (answersOf (relRun k α β A S ω a i).2) (S ℓ)) ω (clip01 (a i))).1,
        Fin.snoc (α := fun _ => RoundRec) (relRun k α β A S ω a i).2
          (stepRel (relRun k α β A S ω a i).1 i
            (fun ℓ => A i (answersOf (relRun k α β A S ω a i).2) (S ℓ)) ω (clip01 (a i))).2)

/-- The query values of round `i` of the release-driven interaction. -/
noncomputable def relQ (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (a : ℕ → ℝ) (i : ℕ) : Fin (adaSampleSize k α β) → ℝ :=
  fun ℓ => A i (answersOf (relRun k α β A S ω a i).2) (S ℓ)

/-- The Stage-1 releases of the true interaction: `ã_i = θ_i^{(1)} + R₁ clampUnit(V_i)`. -/
noncomputable def trueReleases (k : ℕ) (α β : ℝ) (A : DetAnalyst X)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : ℕ) : ℝ :=
  stage1Release (onlineState k α β A S ω i) i (onlineQ k α β A S ω i) ω

/-- The true interaction is the release-driven one on its own releases. -/
theorem onlineRun_eq_relRun (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) :
    onlineRun k α β A S ω i = relRun k α β A S ω (trueReleases k α β A S ω) i := by
  induction i with
  | zero => rfl
  | succ i ih =>
    have e1 : (onlineRun k α β A S ω (i + 1)) =
        ((step (onlineRun k α β A S ω i).1 i (onlineQ k α β A S ω i) ω).1,
          Fin.snoc (α := fun _ => RoundRec) (onlineRun k α β A S ω i).2
            (step (onlineRun k α β A S ω i).1 i (onlineQ k α β A S ω i) ω).2) := rfl
    have e2 : trueReleases k α β A S ω i =
        stage1Release (onlineRun k α β A S ω i).1 i (onlineQ k α β A S ω i) ω := rfl
    have e3 : onlineQ k α β A S ω i =
        fun ℓ => A i (answersOf (relRun k α β A S ω (trueReleases k α β A S ω) i).2) (S ℓ) := by
      funext ℓ
      show A i (answersOf (onlineRun k α β A S ω i).2) (S ℓ) = _
      rw [ih]
    rw [e1, step_eq_stepRel, ← e2, e3, ih]
    rfl

/-- `relRun` only reads the releases of the rounds before `i`. -/
theorem relRun_congr_a (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {a a' : ℕ → ℝ} {i : ℕ} (h : ∀ j < i, a j = a' j) :
    relRun k α β A S ω a i = relRun k α β A S ω a' i := by
  induction i with
  | zero => rfl
  | succ i ih =>
    have := ih fun j hj => h j (by omega)
    show ((stepRel (relRun k α β A S ω a i).1 i _ ω (clip01 (a i))).1, _) =
      ((stepRel (relRun k α β A S ω a' i).1 i _ ω (clip01 (a' i))).1, _)
    rw [this, h i (Nat.lt_succ_self i)]

/-- Agreement of two states except possibly on the payoffs of the levels in `B`. -/
def StateAgree (B : Set ℕ) (st st' : MState k α β) : Prop :=
  st.halt = st'.halt ∧ st.t1 = st'.t1 ∧ st.N = st'.N ∧ st.M = st'.M ∧ ∀ r ∉ B, st.pay r = st'.pay r

theorem noiseRho_congr {ω ω' : AdaOmega k α} (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ 1 → ω j = ω' j)
    {r : ℕ} (hr : r ≠ 1) (e : ℕ) : noiseRho ω r e = noiseRho ω' r e := by
  unfold noiseRho
  split_ifs with hh
  · exact hω _ hr
  · rfl

theorem noiseNu_congr {ω ω' : AdaOmega k α} (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ 1 → ω j = ω' j)
    (i : ℕ) {r : ℕ} (hr : r ≠ 1) : noiseNu ω i r = noiseNu ω' i r := by
  unfold noiseNu
  split_ifs with hh
  · exact hω _ hr
  · rfl

theorem noiseZeta_congr {ω ω' : AdaOmega k α}
    (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ 1 → ω j = ω' j) (i : ℕ) {r : ℕ} (hr : r ≠ 1) :
    noiseZeta ω i r = noiseZeta ω' i r := by
  unfold noiseZeta
  split_ifs with hh
  · exact hω _ hr
  · rfl

/-- **Release-driven congruence**: two release-driven runs whose samples agree on the blocks `r ∉ B`
(`1 ∈ B` allowed) and whose noise tables agree on all entries not owned by Stage 1 have the same records, and
their states agree except possibly on the payoffs of the levels in `B`. -/
theorem relRun_congr (A : DetAnalyst X) {S S' : Fin (adaSampleSize k α β) → X} {ω ω' : AdaOmega k α}
    (a : ℕ → ℝ) {B : Set ℕ} (hB : ∀ r ∉ B, ∀ ℓ, S (adaBlockIdx k α β r ℓ) = S' (adaBlockIdx k α β r ℓ))
    (hB1 : ∀ r ∈ B, r = 1)
    (hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ 1 → ω j = ω' j) (i : ℕ) :
    (relRun k α β A S ω a i).2 = (relRun k α β A S' ω' a i).2 ∧
      StateAgree B (relRun k α β A S ω a i).1 (relRun k α β A S' ω' a i).1 := by
  induction i with
  | zero => exact ⟨rfl, rfl, rfl, rfl, rfl, fun _ _ => rfl⟩
  | succ i ih =>
    obtain ⟨hrec, hhalt, ht1, hN, hM, hpay⟩ := ih
    set st := (relRun k α β A S ω a i).1
    set st' := (relRun k α β A S' ω' a i).1
    set q : Fin (adaSampleSize k α β) → ℝ :=
      fun ℓ => A i (answersOf (relRun k α β A S ω a i).2) (S ℓ) with hq
    set q' : Fin (adaSampleSize k α β) → ℝ :=
      fun ℓ => A i (answersOf (relRun k α β A S' ω' a i).2) (S' ℓ) with hq'
    have hqB : ∀ r ∉ B, ∀ ℓ, q (adaBlockIdx k α β r ℓ) = q' (adaBlockIdx k α β r ℓ) := by
      intro r hr ℓ
      simp only [hq, hq', hrec, hB r hr ℓ]
    have htheta : ∀ r, 2 ≤ r → st.theta q r = st'.theta q' r := by
      intro r hr
      have hrB : r ∉ B := fun h => by have := hB1 r h; omega
      unfold MState.theta MState.weight
      rw [hpay r hrB]
      refine Finset.sum_congr rfl fun ℓ _ => ?_
      rw [hqB r hrB ℓ]
    have hrecEq : (roundChainRel st i q ω (clip01 (a i))).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α) =
        (roundChainRel st' i q' ω' (clip01 (a i))).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α) := by
      refine ChainData.toRec_congr (d := roundChainRel st i q ω (clip01 (a i)))
        (d' := roundChainRel st' i q' ω' (clip01 (a i))) rfl rfl rfl (fun r hr => ?_) _ _ _
      have hr1 : r ≠ 1 := by omega
      refine ⟨htheta r hr, ?_, noiseNu_congr hω i hr1, noiseZeta_congr hω i hr1⟩
      show noiseRho ω r (st.M r - 1) = noiseRho ω' r (st'.M r - 1)
      rw [hM, noiseRho_congr hω hr1]
    have hstep : stepRel st i q ω (clip01 (a i)) = (if st.halt then (st, RoundRec.halted) else
        (st.next q ((roundChainRel st i q ω (clip01 (a i))).toRec (adaEta1 α) (adaEta α)
          (adaEtaTilde α)), (roundChainRel st i q ω (clip01 (a i))).toRec (adaEta1 α) (adaEta α)
            (adaEtaTilde α))) := rfl
    have hstep' : stepRel st' i q' ω' (clip01 (a i)) = (if st'.halt then (st', RoundRec.halted) else
        (st'.next q' ((roundChainRel st' i q' ω' (clip01 (a i))).toRec (adaEta1 α) (adaEta α)
          (adaEtaTilde α)), (roundChainRel st' i q' ω' (clip01 (a i))).toRec (adaEta1 α) (adaEta α)
            (adaEtaTilde α))) := rfl
    show (Fin.snoc (α := fun _ => RoundRec) (relRun k α β A S ω a i).2
        (stepRel st i q ω (clip01 (a i))).2 =
      Fin.snoc (α := fun _ => RoundRec) (relRun k α β A S' ω' a i).2
        (stepRel st' i q' ω' (clip01 (a i))).2) ∧
      StateAgree B (stepRel st i q ω (clip01 (a i))).1 (stepRel st' i q' ω' (clip01 (a i))).1
    rw [hstep, hstep', ← hhalt, hrec]
    cases hh : st.halt
    · simp only [Bool.false_eq_true, if_false]
      rw [hrecEq]
      refine ⟨rfl, ?_, ?_, ?_, ?_, ?_⟩
      · simp only [MState.next, ht1, hN]
      · show st.t1 + _ = st'.t1 + _
        rw [ht1]
      · show (fun r => st.N r + _) = (fun r => st'.N r + _)
        rw [hN]
      · show (fun r => st.M r + _) = (fun r => st'.M r + _)
        rw [hM]
      · intro r hr
        funext ℓ
        show st.pay r ℓ + _ * q (adaBlockIdx k α β r ℓ) = st'.pay r ℓ + _ * q' (adaBlockIdx k α β r ℓ)
        rw [hpay r hr, hqB r hr ℓ]
    · rw [if_pos rfl, if_pos rfl]
      exact ⟨rfl, hhalt, ht1, hN, hM, hpay⟩

/-- The record of round `j` of the release-driven interaction. -/
noncomputable def relRec (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (a : ℕ → ℝ) (j : ℕ) : RoundRec :=
  (stepRel (relRun k α β A S ω a j).1 j (relQ k α β A S ω a j) ω (clip01 (a j))).2

theorem relRun_succ (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (a : ℕ → ℝ) (j : ℕ) :
    relRun k α β A S ω a (j + 1) =
      ((stepRel (relRun k α β A S ω a j).1 j (relQ k α β A S ω a j) ω (clip01 (a j))).1,
        Fin.snoc (α := fun _ => RoundRec) (relRun k α β A S ω a j).2 (relRec k α β A S ω a j)) := rfl

/-- The records list of the release-driven interaction is prefix-consistent. -/
theorem relRun_rec (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (a : ℕ → ℝ) (i : ℕ) (j : Fin i) : (relRun k α β A S ω a i).2 j = relRec k α β A S ω a j := by
  induction i with
  | zero => exact j.elim0
  | succ i ih =>
    rw [relRun_succ]
    refine Fin.lastCases ?_ (fun j' => ?_) j
    · show Fin.snoc (α := fun _ => RoundRec) _ _ (Fin.last i) = _
      rw [Fin.snoc_last]
      rfl
    · show Fin.snoc (α := fun _ => RoundRec) _ _ (Fin.castSucc j') = _
      rw [Fin.snoc_castSucc, ih]
      rfl

theorem relRun_succ_pay (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (a : ℕ → ℝ) (j r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (relRun k α β A S ω a (j + 1)).1.pay r ℓ = (relRun k α β A S ω a j).1.pay r ℓ +
      (relRec k α β A S ω a j).delta r * relQ k α β A S ω a j (adaBlockIdx k α β r ℓ) := by
  rw [relRun_succ]
  unfold relRec stepRel
  cases h : (relRun k α β A S ω a j).1.halt
  · simp only [Bool.false_eq_true, if_false]
    rfl
  · simp only [if_true]
    simp

/-- The Stage-1 (and every) payoff of the release-driven interaction: public impulses times queries. -/
theorem relRun_pay (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (a : ℕ → ℝ) (i r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (relRun k α β A S ω a i).1.pay r ℓ = ∑ j ∈ Finset.range i,
      (relRec k α β A S ω a j).delta r * relQ k α β A S ω a j (adaBlockIdx k α β r ℓ) := by
  induction i with
  | zero => rfl
  | succ i ih => rw [relRun_succ_pay, ih, Finset.sum_range_succ]

theorem replaceBlock_blockIdx_of_ne (r : ℕ) (hr : r ≠ 1) (S₁ : Fin (adaBlock k α β 1) → X)
    (S : Fin (adaSampleSize k α β) → X) (ℓ : Fin (adaBlock k α β r)) :
    replaceBlock k α β 1 S₁ S (adaBlockIdx k α β r ℓ) = S (adaBlockIdx k α β r ℓ) := by
  apply replaceBlock_of_not_mem
  rintro ⟨h1, h2⟩
  rw [adaBlockIdx_val] at h1 h2
  have hl := ℓ.isLt
  rcases Nat.lt_or_gt_of_ne hr with hlt | hgt
  · -- r = 0: the block is empty
    have : r = 0 := by omega
    subst this
    have h0 := adaBlock_zero k α β
    omega
  · have hmono : adaOffset k α β 1 + adaBlock k α β 1 ≤ adaOffset k α β r := by
      rw [← adaOffset_succ]
      exact adaOffset_mono k α β (by omega)
    omega

end RelRun

/-! ## The Stage-1 factorization -/

section Factor

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- Extend a release vector `Fin k → ℝ` to a sequence (junk `0` after round `k - 1`). -/
def extRel (a : Fin k → ℝ) : ℕ → ℝ := fun i => if h : i < k then a ⟨i, h⟩ else 0

/-- `θ_i^{(1)}` at the start of round `i` of the release-driven interaction with the sample
`replaceBlock 1 S₁ S`, the noise `ω'` and the releases `a`. -/
noncomputable def s1Theta (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X) (i : Fin k) (a : Fin k → ℝ) : ℝ :=
  (relRun k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel a) i).1.theta
    (relQ k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel a) i) 1

/-- The records of the release-driven interaction (they do not depend on block 1 of the sample). -/
noncomputable def s1Psi (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (a : Fin k → ℝ) : Fin k → RoundRec :=
  (relRun k α β A S ω' (extRel a) k).2

/-- The Stage-1 release sequence driven by the noise `v`: the solution of `a_i = θ_i^{(1)}(a_{<i}) + R₁ v_i`. -/
noncomputable def s1Phi (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X) (v : Fin k → ℝ) : Fin k → ℝ :=
  triangularSol (s1Theta k α β A S ω' S₁) (fun i => adaR1 α * v i)

theorem s1Theta_dependsOn (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X) (i : Fin k) :
    DependsOn (s1Theta k α β A S ω' S₁ i) (Set.Iio i) := by
  intro x y hxy
  have hext : ∀ j < (i : ℕ), extRel x j = extRel y j := by
    intro j hj
    have hjk : j < k := lt_trans hj i.isLt
    simp only [extRel, dif_pos hjk]
    exact hxy ⟨j, hjk⟩ (show (⟨j, hjk⟩ : Fin k) < i from hj)
  unfold s1Theta relQ
  rw [relRun_congr_a A _ ω' hext]

theorem isTriangularSol_s1Phi (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X) (v : Fin k → ℝ) (i : Fin k) :
    s1Phi k α β A S ω' S₁ v i = s1Theta k α β A S ω' S₁ i (s1Phi k α β A S ω' S₁ v) + adaR1 α * v i :=
  isTriangularSol_triangularSol (s1Theta_dependsOn A S ω' S₁) (fun i => adaR1 α * v i) i

/-- **The Stage-1 factorization** (Step 1 of the proof of Lemma `I:lem:working_sample_privacy`): with the other
blocks (those of `S`), the non-Stage-1 noise (that of `ω'`) and the analyst fixed, the transcript is the
`S₁`-free post-processing `s1Psi` of the release sequence `s1Phi … S₁ V`, `V_i = clampUnit(ω (beta i))`. -/
theorem transcript_eq_s1Psi (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X) (ω : AdaOmega k α) :
    transcript k α β A (replaceBlock k α β 1 S₁ S) (mixNoise 1 ω ω') =
      s1Psi k α β A S ω' (s1Phi k α β A S ω' S₁ (fun i => Dist.clampUnit (ω (.beta i)))) := by
  set S'' := replaceBlock k α β 1 S₁ S with hS''
  set ω'' := mixNoise 1 ω ω' with hω''
  set tr := trueReleases k α β A S'' ω'' with htr
  set Φ := s1Phi k α β A S ω' S₁ (fun i => Dist.clampUnit (ω (.beta i))) with hΦ
  have hω : ∀ j : NoiseIdx k (adaL α), j.stage ≠ 1 → ω'' j = ω' j :=
    fun j hj => mixNoise_of_not_stage 1 ω ω' j hj
  have hS : ∀ r ∉ ({1} : Set ℕ), ∀ ℓ, S'' (adaBlockIdx k α β r ℓ) = S (adaBlockIdx k α β r ℓ) :=
    fun r hr ℓ => replaceBlock_blockIdx_of_ne r hr S₁ S ℓ
  -- the true releases solve the release recursion
  have hsol : ∀ i : Fin k, tr i = s1Theta k α β A S ω' S₁ i (fun j => tr j) +
      adaR1 α * Dist.clampUnit (ω (.beta i)) := by
    intro i
    have hbeta : noiseBeta ω'' i = ω (.beta i) := by
      simp only [noiseBeta, dif_pos i.isLt]
      exact mixNoise_of_stage 1 ω ω' _ rfl
    have h1 := onlineRun_eq_relRun A S'' ω'' i
    have hagree := relRun_congr (B := ∅) A tr (S := S'') (S' := S'')
      (fun _ _ _ => rfl) (fun r hr => absurd hr (Set.notMem_empty r)) hω i
    have hext : ∀ j < (i : ℕ), tr j = extRel (fun j : Fin k => tr j) j := by
      intro j hj
      simp only [extRel, dif_pos (lt_trans hj i.isLt)]
    have h2 := relRun_congr_a A S'' ω' hext
    show stage1Release (onlineState k α β A S'' ω'' i) i (onlineQ k α β A S'' ω'' i) ω'' = _
    unfold stage1Release
    rw [hbeta]
    congr 1
    unfold s1Theta
    rw [← h2]
    have hst : onlineState k α β A S'' ω'' i = (relRun k α β A S'' ω'' tr i).1 := by
      unfold onlineState
      rw [h1]
    have hq : onlineQ k α β A S'' ω'' i = relQ k α β A S'' ω' tr i := by
      funext ℓ
      show A i (answersOf (onlineRun k α β A S'' ω'' i).2) (S'' ℓ) =
        A i (answersOf (relRun k α β A S'' ω' tr i).2) (S'' ℓ)
      rw [h1, hagree.1]
    rw [hst, hq]
    have hq' : relQ k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel fun j : Fin k => tr j) i =
        relQ k α β A S'' ω' tr i := by
      unfold relQ
      rw [← h2]
    rw [hq']
    unfold MState.theta MState.weight
    rw [hagree.2.2.2.2.2 1 (Set.notMem_empty 1)]
  have hfix : (fun j : Fin k => tr j) = Φ :=
    triangular_fixed_unique (s1Theta_dependsOn A S ω' S₁) hsol
      (isTriangularSol_s1Phi A S ω' S₁ _)
  have hextΦ : ∀ j < k, tr j = extRel Φ j := by
    intro j hj
    simp only [extRel, dif_pos hj, ← hfix]
  show (onlineRun k α β A S'' ω'' k).2 = (relRun k α β A S ω' (extRel Φ) k).2
  rw [onlineRun_eq_relRun, (relRun_congr A tr hS (fun r hr => hr) hω k).1,
    relRun_congr_a A S ω' hextΦ]

/-- `θ_i^{(1)}` in the form of Lemma `I:lem:kkt_sensitivity`(2): a water-filling weighted mean of `Q_i(S₁)` with
the public coefficients `c_j = δ_{1,j}` and the public queries `Q_j`, all read off the `S₁`-free records
`s1Psi … a`. -/
theorem s1Theta_eq (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α)
    (S₁ : Fin (adaBlock k α β 1) → X) (i : Fin k) (a : Fin k → ℝ) :
    s1Theta k α β A S ω' S₁ i a = ∑ ℓ, Opt.waterFill (adaBlock k α β 1) 1
        (fun ℓ => ∑ j ∈ Finset.range i, (recAt (s1Psi k α β A S ω' a) j).delta 1 *
          qry A (s1Psi k α β A S ω' a) j (S₁ ℓ)) ℓ *
      qry A (s1Psi k α β A S ω' a) i (S₁ ℓ) := by
  set S'' := replaceBlock k α β 1 S₁ S with hS''
  have hS : ∀ r ∉ ({1} : Set ℕ), ∀ ℓ, S'' (adaBlockIdx k α β r ℓ) = S (adaBlockIdx k α β r ℓ) :=
    fun r hr ℓ => replaceBlock_blockIdx_of_ne r hr S₁ S ℓ
  have hcong := fun m => relRun_congr (ω := ω') (ω' := ω') A (extRel a) hS (fun r hr => hr)
    (fun _ _ => rfl) m
  -- records of the run with `S''` are those of `s1Psi`
  have hrec : ∀ j < k, relRec k α β A S'' ω' (extRel a) j = recAt (s1Psi k α β A S ω' a) j := by
    intro j hj
    rw [recAt, dif_pos hj]
    unfold s1Psi
    rw [relRun_rec A S ω' (extRel a) k ⟨j, hj⟩]
    have e1 : relRec k α β A S'' ω' (extRel a) j =
        (relRun k α β A S'' ω' (extRel a) (j + 1)).2 (Fin.last j) :=
      (relRun_rec A S'' ω' (extRel a) (j + 1) (Fin.last j)).symm
    have e2 : relRec k α β A S ω' (extRel a) j =
        (relRun k α β A S ω' (extRel a) (j + 1)).2 (Fin.last j) :=
      (relRun_rec A S ω' (extRel a) (j + 1) (Fin.last j)).symm
    show relRec k α β A S'' ω' (extRel a) j = relRec k α β A S ω' (extRel a) j
    rw [e1, e2, (hcong (j + 1)).1]
  have hans : ∀ j ≤ k, answersOf (relRun k α β A S'' ω' (extRel a) j).2 = histAns (s1Psi k α β A S ω' a) j := by
    intro j hj
    funext l
    rw [histAns_apply, ← hrec l (by omega), ← relRun_rec A S'' ω' (extRel a) j l]
    rfl
  have hq : ∀ j ≤ k, ∀ ℓ : Fin (adaBlock k α β 1),
      relQ k α β A S'' ω' (extRel a) j (adaBlockIdx k α β 1 ℓ) = qry A (s1Psi k α β A S ω' a) j (S₁ ℓ) := by
    intro j hj ℓ
    have hb : S'' (adaBlockIdx k α β 1 ℓ) = S₁ ℓ := by
      have := congrFun (blockOf_replaceBlock k α β 1 S₁ S) ℓ
      exact this
    show A j (answersOf (relRun k α β A S'' ω' (extRel a) j).2) (S'' (adaBlockIdx k α β 1 ℓ)) = _
    rw [hans j hj, hb]
    rfl
  unfold s1Theta
  unfold MState.theta MState.weight
  have h1L : (1 : ℕ) ≠ adaL α := by have := adaL_ge_four α; omega
  simp only [if_neg h1L]
  refine Finset.sum_congr rfl fun ℓ _ => ?_
  rw [hq i i.isLt.le ℓ]
  congr 2
  funext ℓ'
  rw [relRun_pay]
  refine Finset.sum_congr rfl fun j hj => ?_
  rw [Finset.mem_range] at hj
  rw [hrec j (lt_trans hj i.isLt), hq j (le_of_lt (lt_trans hj i.isLt)) ℓ']

end Factor

/-! ## Measurability of the factorization -/

section Meas

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

theorem measFamily_roundChainRel (i : ℕ) (ω : AdaOmega k α) :
    ChainData.MeasFamily
      (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ => roundChainRel p.1 i p.2.1 ω p.2.2)
      (adaL α) (adaTau α) where
  hL _ := rfl
  htau _ := rfl
  hc1 := measurable_snd.comp measurable_snd
  htheta s := (measurable_theta s).comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
  hrho s := by
    show Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ =>
      noiseRho ω s (p.1.M s - 1)
    have hM : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ => p.1.M s - 1 :=
      (measurable_from_nat (f := fun n : ℕ => n - 1)).comp
        ((measurable_pi_apply s).comp (MState.measurable_M.comp measurable_fst))
    exact (measurable_from_nat (f := fun e => noiseRho ω s e)).comp hM
  hnu _ := measurable_const
  hzeta _ := measurable_const

theorem measurable_stepRel (i : ℕ) (ω : AdaOmega k α) :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × ℝ =>
      stepRel p.1 i p.2.1 ω p.2.2 := by
  unfold stepRel
  have hrec := (measFamily_roundChainRel (β := β) i ω).measurable_toRec (adaEta1 α) (adaEta α)
    (adaEtaTilde α)
  refine Measurable.ite ?_ (measurable_fst.prodMk measurable_const) ?_
  · exact (MState.measurable_halt.comp measurable_fst) (measurableSet_singleton true)
  · exact (measurable_next.comp (measurable_fst.prodMk ((measurable_fst.comp measurable_snd).prodMk
      hrec))).prodMk hrec

theorem measurable_relRun (A : DetAnalyst X) (hA : A.JointlyMeasurable)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : ℕ) :
    Measurable fun a : Fin k → ℝ => relRun k α β A S ω (extRel a) i := by
  induction i with
  | zero => exact measurable_const
  | succ i ih =>
    have hhist : Measurable fun a : Fin k → ℝ => answersOf (relRun k α β A S ω (extRel a) i).2 :=
      measurable_snd.comp ih
    have hq : Measurable fun a : Fin k → ℝ => relQ k α β A S ω (extRel a) i := by
      rw [measurable_pi_iff]
      intro ℓ
      exact (hA i).comp (hhist.prodMk measurable_const)
    have hext : Measurable fun a : Fin k → ℝ => clip01 (extRel a i) := by
      by_cases h : i < k
      · simp only [extRel, dif_pos h]
        exact measurable_clip01.comp (measurable_pi_apply _)
      · simp only [extRel, dif_neg h]
        exact measurable_const
    have hstep := (measurable_stepRel (β := β) i ω).comp ((measurable_fst.comp ih).prodMk (hq.prodMk hext))
    show Measurable fun a : Fin k → ℝ =>
      ((stepRel (relRun k α β A S ω (extRel a) i).1 i (relQ k α β A S ω (extRel a) i) ω
          (clip01 (extRel a i))).1,
        Fin.snoc (α := fun _ => RoundRec) (relRun k α β A S ω (extRel a) i).2
          (relRec k α β A S ω (extRel a) i))
    exact (measurable_fst.comp hstep).prodMk
      (measurable_fin_snoc (measurable_snd.comp ih) (measurable_snd.comp hstep))

theorem measurable_relQ (A : DetAnalyst X) (hA : A.JointlyMeasurable)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (i : ℕ) :
    Measurable fun a : Fin k → ℝ => relQ k α β A S ω (extRel a) i := by
  have hhist : Measurable fun a : Fin k → ℝ => answersOf (relRun k α β A S ω (extRel a) i).2 :=
    measurable_snd.comp (measurable_relRun A hA S ω i)
  rw [measurable_pi_iff]
  intro ℓ
  exact (hA i).comp (hhist.prodMk measurable_const)

/-- The records of the release-driven interaction are a measurable function of the releases. -/
theorem measurable_s1Psi (A : DetAnalyst X) (hA : A.JointlyMeasurable)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) : Measurable (s1Psi k α β A S ω') :=
  measurable_snd.comp (measurable_relRun A hA S ω' k)

theorem measurable_theta_comp {P : Type*} [MeasurableSpace P] (st : P → MState k α β)
    (q : P → Fin (adaSampleSize k α β) → ℝ) (hst : Measurable st) (hq : Measurable q) (r : ℕ) :
    Measurable fun p => (st p).theta (q p) r := by
  have h := (measurable_theta (k := k) (α := α) (β := β) r).comp (hst.prodMk hq)
  exact h

/-- `θ_i^{(1)}` is a measurable function of the releases. -/
theorem measurable_s1Theta (A : DetAnalyst X) (hA : A.JointlyMeasurable)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) (S₁ : Fin (adaBlock k α β 1) → X)
    (i : Fin k) : Measurable (s1Theta k α β A S ω' S₁ i) := by
  have hst : Measurable fun a : Fin k → ℝ =>
      (relRun k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel a) i).1 :=
    measurable_fst.comp (measurable_relRun A hA (replaceBlock k α β 1 S₁ S) ω' i)
  unfold s1Theta
  exact measurable_theta_comp (fun a : Fin k → ℝ =>
      (relRun k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel a) i).1)
    (fun a : Fin k → ℝ => relQ k α β A (replaceBlock k α β 1 S₁ S) ω' (extRel a) i) hst
    (measurable_relQ A hA (replaceBlock k α β 1 S₁ S) ω' i) 1

end Meas

end A

end F2e2e
