import F2e2e.A.Sim
import F2e2e.Lib.DP.Advanced
import F2e2e.Lib.DP.AboveThreshold
import F2e2e.Lib.DP.Laplace
import F2e2e.Lib.DP.Compose
import F2e2e.Lib.Opt.EntropicSensitivity
import F2e2e.A.NumericsBasic
import F2e2e.A.ArchTheta
import F2e2e.A.ArchAtRel
import F2e2e.A.ArchEpisode

/-!
# Part I §3: validator episodes, per-episode pure DP, homogeneous advanced composition

Paper: `parts/partI.tex` Section 3, L799-1028:
* Lemma `I:lem:validator_episode_conservation` (L825-874): `validator_episode_conservation`
  (unit increments, zero overshoot, intra-episode weight invariance, episode conservation);
* the sensitivities `Δ_r` (`I:eq:Delta_r_def`, L876-885; `adaSens` in `F2e2e.A.Params`) and the query-evaluation
  sensitivity `I:eq:theta_r_sensitivity` (L911-918): `theta_sensitivity`;
* Proposition `I:prop:svt_episode_pure_dp` (L887-957): `svt_episode_pure_dp` — every episode kernel of stage `r` is
  `(4Δ_r/b_SVT, 0)`-DP at every history (the paper's "conditioned on the public transcript prior to episode `e`",
  formalized as a kernel bound for every history, `notes/PAPER_MAP_I_b.md` §6.B row C2);
* Proposition `I:prop:homog_adv_comp` (L962-1028): the composition formula `homog_adv_comp_formula`
  (`ε_comp,r = √(2 M_{r,max} L_val) ε_ep,r + M_{r,max} ε_ep,r (e^{ε_ep,r} - 1)`, `δ_val/2`), the three-line
  substitutions `adaEpsComp_lt_mid` (`< 0.21 ε_r`, prefactor 110) and `adaEpsComp_lt_anchor` (`< 0.21 ε_L/2`,
  prefactor 55), and the consumer contracts `homog_adv_comp_mid`, `homog_adv_comp_anchor`.

"`S_r ↦ h` is `(ε, δ)`-DP" is `∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A r S ω') ε δ` (ArchDefs convention: the
other blocks and all noise not owned by stage `r` fixed). The proof of Prop. 3.3 goes through [SIM_r]
(`stageLaw_eq_advComp`, F2e2e/A/Sim.lean), the per-episode bound (Prop. 3.2) and the advanced-composition library
(`DP.isDP_advComp`, KOV route).
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

variable {k : ℕ} {α β : ℝ} {X : Type}

/-! ## Lemma `I:lem:validator_episode_conservation` -/

/-- **Lemma `I:lem:validator_episode_conservation`** (strict intra-episode weight invariance and zero-overshoot episode
conservation), for the run on any query-value sequence `qv` and noise `ω`:
* (i) unit increments: at the end of round `i`, `t₁` increases by `1` exactly in Case A (`u_final = 2`) and `N_{r*}`
  by `1` exactly in Case B with `u_final = r*`; and the counters never exceed their caps
  (`I:eq:zero_overshoot_caps`);
* (ii) intra-episode weight invariance: if stage `r ≥ 2` does not reset in round `i` (`M_r` unchanged), its
  cumulative payoff (hence its FTRL weights) is unchanged;
* (iii) episode conservation (`I:eq:M2_conservation`, `I:eq:Mr_conservation`):
  `M_2 ≤ 1 + t₁ + ∑_{r*=3}^{L} N_{r*} ≤ M_{2,max}` and `M_r ≤ 1 + ∑_{r*=r}^{L} N_{r*} ≤ M_{r,max}` (`3 ≤ r ≤ L`). -/
theorem validator_episode_conservation (hα : 0 < α) (qv : ℕ → Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) :
    (∀ i, (run k α β qv ω (i + 1)).t1 =
        (run k α β qv ω i).t1 + (if (roundRec k α β qv ω i).ufinal = 2 then 1 else 0) ∧
      ∀ r, (run k α β qv ω (i + 1)).N r = (run k α β qv ω i).N r +
        (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧ r = (roundRec k α β qv ω i).ufinal then 1 else 0)) ∧
    (∀ i, (run k α β qv ω i).t1 ≤ adaT1max α ∧ ∀ r, (run k α β qv ω i).N r ≤ adaNmax α r) ∧
    (∀ i r, 2 ≤ r → (run k α β qv ω (i + 1)).M r = (run k α β qv ω i).M r →
      (run k α β qv ω (i + 1)).pay r = (run k α β qv ω i).pay r) ∧
    (∀ i, (run k α β qv ω i).M 2 ≤
        1 + (run k α β qv ω i).t1 + ∑ s ∈ Finset.Icc 3 (adaL α), (run k α β qv ω i).N s ∧
      1 + (run k α β qv ω i).t1 + ∑ s ∈ Finset.Icc 3 (adaL α), (run k α β qv ω i).N s ≤ adaMmax α 2) ∧
    (∀ i r, 3 ≤ r → r ≤ adaL α →
      (run k α β qv ω i).M r ≤ 1 + ∑ s ∈ Finset.Icc r (adaL α), (run k α β qv ω i).N s ∧
      1 + ∑ s ∈ Finset.Icc r (adaL α), (run k α β qv ω i).N s ≤ adaMmax α r) := by
  refine ⟨fun i => ⟨run_succ_t1 qv ω i, fun r => run_succ_N qv ω i r⟩,
    fun i => ⟨run_t1_le qv ω hα i, fun r => run_N_le qv ω hα i r⟩,
    fun i r hr hM => run_pay_eq_of_M_eq qv ω hr hM,
    fun i => ⟨(run_M_two qv ω i).le, ?_⟩,
    fun i r h3 hL => ⟨(run_M_ge_three qv ω h3 i).le, ?_⟩⟩
  · have ht := run_t1_le qv ω hα i
    have hN : ∑ s ∈ Finset.Icc 3 (adaL α), (run k α β qv ω i).N s ≤
        ∑ s ∈ Finset.Icc 3 (adaL α), adaNmax α s :=
      Finset.sum_le_sum fun s _ => run_N_le qv ω hα i s
    unfold adaMmax
    rw [if_pos rfl]
    omega
  · have hN : ∑ s ∈ Finset.Icc r (adaL α), (run k α β qv ω i).N s ≤
        ∑ s ∈ Finset.Icc r (adaL α), adaNmax α s :=
      Finset.sum_le_sum fun s _ => run_N_le qv ω hα i s
    unfold adaMmax
    rw [if_neg (by omega)]
    omega

/-! ## Sensitivities (`I:eq:Delta_r_def`, `I:eq:theta_r_sensitivity`) -/

/-- **Query-evaluation sensitivity of a validator stage** (`I:eq:theta_r_sensitivity`; Lemma `I:lem:kkt_sensitivity`(2)
and `I:eq:anchor_sens`): after replaying the same public records `h₀` on two samples whose block `r` are neighbours,
the weighted means `θ^{(r)} = ⟨P^{(r)}, q(S_r)⟩` of any `[0,1]`-valued query differ by at most `Δ_r`. -/
theorem theta_sensitivity [MeasurableSpace X] (A : DetAnalyst X) (hA : A.Valid) {r : ℕ} (hr2 : 2 ≤ r)
    (hrL : r ≤ adaL α) (S : Fin (adaSampleSize k α β) → X) (h₀ : Fin k → RoundRec) (s : ℕ) (q : X → ℝ)
    (hq : ∀ x, q x ∈ Set.Icc (0 : ℝ) 1) {Sr Sr' : Fin (adaBlock k α β r) → X} (hN : DP.Neighbor Sr Sr') :
    |(replay A (replaceBlock k α β r Sr S) h₀ s).theta (fun ℓ => q (replaceBlock k α β r Sr S ℓ)) r -
      (replay A (replaceBlock k α β r Sr' S) h₀ s).theta (fun ℓ => q (replaceBlock k α β r Sr' S ℓ)) r| ≤
      adaSens k α β r :=
  theta_sensitivity' A hA hr2 hrL S h₀ s q hq hN

/-! ## Proposition `I:prop:svt_episode_pure_dp` -/

/-- **Proposition `I:prop:svt_episode_pure_dp`** (per-episode `(4Δ_r/b_SVT, 0)`-pure DP): for every validator stage
`2 ≤ r ≤ L`, every episode index `e` and every history `y` of earlier episodes, the law of the `e`-th episode of
stage `r` (AboveThreshold indicator stream + its scalar release) is `(ε_ep,r, 0)`-DP in the block `S_r`,
`ε_ep,r = 4Δ_r/b_SVT` (`I:eq:eps_ep_r_bound`). -/
theorem svt_episode_pure_dp [MeasurableSpace X] (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable) {r : ℕ}
    (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) (e : ℕ) :
    DP.IsDPKernel DP.Neighbor
      (fun Sr : Fin (adaBlock k α β r) → X => epKernel k α β A (replaceBlock k α β r Sr S) r ω' e)
      (adaEpsEp k α β r) 0 := by
  -- Plan (L887-957): on a possible history (`e ≤ s = epCover y < k`) the episode is the post-processing
  -- `epOutF` (public, `episode_public`) of the episode core `atRel` = AboveThreshold on the all-pass test values
  -- `passF` (horizon `passT`, public) + the Laplace release of `passTheta` at the last test; the core is
  -- `3Δ_r/b_SVT ≤ 4Δ_r/b_SVT`-pure DP (`atRel_indist`, sensitivities from `episode_public`). On impossible
  -- histories the episode map is constant.
  intro y Sr Sr' hN
  show DP.Indist (epKernel k α β A (replaceBlock k α β r Sr S) r ω' e y)
    (epKernel k α β A (replaceBlock k α β r Sr' S) r ω' e y) (adaEpsEp k α β r) 0
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hΔ : 0 ≤ adaSens k α β r := by
    unfold adaSens
    split_ifs <;> positivity
  have hε0 : 0 ≤ adaEpsEp k α β r := by
    unfold adaEpsEp
    exact div_nonneg (by linarith) hb.le
  rw [epKernel_apply (measurable_epMap hAm _ r ω' e), epKernel_apply (measurable_epMap hAm _ r ω' e)]
  by_cases hcase : e ≤ epCover y ∧ epCover y < k
  · obtain ⟨hes, hsk⟩ := hcase
    obtain ⟨hT, hF, hθ, hout⟩ := episode_public A hA S hr2 hrL ω' e y hN
    have hdec : ∀ S' : Fin (adaSampleSize k α β) → X,
        (adaNoiseMeasure k α β).map (epMap A S' r ω' e y) =
          ((adaNoiseMeasure k α β).map (atRel k α r e (epCover y) (k - epCover y) (passF A S' r ω' e y)
            (passT A S' r ω' e y) (passTheta A S' r ω' e y))).map
            (fun p : ℕ × ℝ => epOutF A S' r ω' e y p.1 p.2) := by
      intro S'
      rw [Measure.map_map (measurable_epOutF A hAm S' r ω' e y) (measurable_atRel _ _ _ _ _ _ _ _ _)]
      congr 1
      funext ω
      exact epMap_eq_epOutF A S' hr2 hrL ω' e y hes hsk ω
    rw [hdec, hdec]
    simp only [← hout]
    rw [← hT]
    have hind := atRel_indist (β := β) hk hα hα' hβ hβ' hrL (show e ≤ k by omega)
      (show epCover y + (k - epCover y) ≤ k by omega) (show 0 < k - epCover y by omega)
      (passT_le A (replaceBlock k α β r Sr S) r ω' e y) hΔ hF hθ
    refine (hind.map (measurable_epOutF A hAm _ r ω' e y)).mono ?_ le_rfl
    unfold adaEpsEp
    exact div_le_div_of_nonneg_right (by linarith) hb.le
  · have hc : ∀ S' : Fin (adaSampleSize k α β) → X,
        epMap A S' r ω' e y = fun _ => ((fun _ => false, fun _ => RoundRec.halted) : EpRec k) := by
      intro S'
      funext ω
      unfold epMap
      split_ifs with hes
      · have hsk : k ≤ epCover y := by
          by_contra h
          exact hcase ⟨hes, lt_of_not_ge h⟩
        have hno : ∀ (h : Fin k → RoundRec) (i : Fin k), ¬ InEp r (epCover y) h i :=
          fun h i hi => by
            have := hi.1
            have := i.isLt
            omega
        unfold epMask
        simp [hno]
      · rfl
    rw [hc, hc]
    exact DP.indist_self _ hε0 0

/-! ## Proposition `I:prop:homog_adv_comp` -/

/-- The composed privacy parameter of stage `r` (eq. `I:eq:eps_comp_formula` with `M = M_{r,max}`,
`δ'_val = δ_val/2`, `ln(2/δ'_val) = L_val`): `√(2 M_{r,max} L_val) ε_ep,r + M_{r,max} ε_ep,r (e^{ε_ep,r} - 1)`. -/
noncomputable def adaEpsComp (k : ℕ) (α β : ℝ) (r : ℕ) : ℝ :=
  Real.sqrt (2 * (adaMmax α r : ℝ) * adaLval α β) * adaEpsEp k α β r +
    (adaMmax α r : ℝ) * adaEpsEp k α β r * (Real.exp (adaEpsEp k α β r) - 1)

/-- **Homogeneous advanced composition** (Prop. `I:prop:homog_adv_comp`, eq. `I:eq:eps_comp_formula`): `S_r ↦ h` is
`(ε_comp,r, δ_val/2)`-DP for every validator stage `2 ≤ r ≤ L`. -/
theorem homog_adv_comp_formula [MeasurableSpace X] (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16)
    (hβ : 0 < β) (hβ' : β < 1 / 2) (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α) :
    ∀ (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α),
      DP.IsDP DP.Neighbor (stageLaw k α β A r S ω') (adaEpsComp k α β r) (adaDeltaVal α β / 2) := by
  intro S ω'
  have hδ := adaDeltaVal_pos hα hβ
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hε : 0 ≤ adaEpsEp k α β r := by
    unfold adaEpsEp adaSens
    split_ifs <;> positivity
  have hcomp := DP.isDP_advComp (Adj := DP.Neighbor) (fun _ _ h => DP.neighbor_symm h)
    (fun Sr : Fin (adaBlock k α β r) → X => fun e => epKernel k α β A (replaceBlock k α β r Sr S) r ω' e)
    hε (adaMmax α r) (fun j _ => svt_episode_pure_dp hk hα hα' hβ hβ' A hA hAm hr2 hrL S ω' j)
    (δ' := adaDeltaVal α β / 2) (by positivity)
  have hmap := hcomp.map (measurable_epRecon (k := k) (M := adaMmax α r))
  intro Sr Sr' hN
  rw [stageLaw_eq_advComp hα A hAm hr2 hrL S ω' Sr, stageLaw_eq_advComp hα A hAm hr2 hrL S ω' Sr']
  refine (hmap Sr Sr' hN).mono (le_of_eq ?_) (by linarith)
  have h4 : 2 / (adaDeltaVal α β / 2) = 4 / adaDeltaVal α β := by
    field_simp
    ring
  unfold adaEpsComp adaLval
  rw [h4]

/-- **The three-line substitution, generic form** (eqs. `I:eq:3line_sub_1`-`I:eq:3line_sub_3`): if `M ≥ 1`,
`L_val > 49`, `0 < c ≤ 0.05` and `0 ≤ x ≤ (16/110) c/√(M L_val)`, then
`√(2 M L_val) x + M x (e^x - 1) < 0.21 c` (via `e^x - 1 ≤ x + x² ≤ 1.002 x` for `x ≤ 0.002` and
`16√2/110 < 0.205705`). -/
theorem epsComp_lt_of_le {M Lv x c : ℝ} (hM : 1 ≤ M) (hLv : 49 < Lv) (hc : 0 < c) (hc1 : c ≤ 1 / 20)
    (hx0 : 0 ≤ x) (hx : x ≤ 16 / 110 * c / Real.sqrt (M * Lv)) :
    Real.sqrt (2 * M * Lv) * x + M * x * (Real.exp x - 1) < 21 / 100 * c := by
  have hML : 49 < M * Lv := by nlinarith
  have hMLpos : 0 < M * Lv := by linarith
  have hLvpos : 0 < Lv := by linarith
  set R := Real.sqrt (M * Lv) with hR
  have hR2 : R ^ 2 = M * Lv := Real.sq_sqrt hMLpos.le
  have hR7 : 7 < R := by
    have h49 : Real.sqrt 49 = 7 := by
      rw [show (49 : ℝ) = 7 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    rw [← h49, hR]
    exact Real.sqrt_lt_sqrt (by norm_num) hML
  have hRpos : 0 < R := by linarith
  have hsq2 : Real.sqrt (2 * M * Lv) = Real.sqrt 2 * R := by
    rw [hR, ← Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 2), mul_assoc]
  have hs2 : Real.sqrt 2 < 141422 / 100000 := by
    rw [Real.sqrt_lt' (by norm_num)]
    norm_num
  have hxR : x * R ≤ 16 / 110 * c := by
    have h := hx
    rw [le_div_iff₀ hRpos] at h
    exact h
  have hxR0 : 0 ≤ x * R := mul_nonneg hx0 hRpos.le
  have hx1 : x ≤ 1 / 500 := by
    have h1 : x * 7 ≤ x * R := mul_le_mul_of_nonneg_left hR7.le hx0
    nlinarith
  have hexp : Real.exp x - 1 ≤ x + x ^ 2 := by
    have h := Real.abs_exp_sub_one_sub_id_le (show |x| ≤ 1 by rw [abs_of_nonneg hx0]; linarith)
    have := (abs_le.1 h).2
    linarith
  have h1 : Real.sqrt (2 * M * Lv) * x ≤ 141422 / 100000 * (16 / 110 * c) := by
    rw [hsq2]
    calc Real.sqrt 2 * R * x = Real.sqrt 2 * (x * R) := by ring
      _ ≤ 141422 / 100000 * (16 / 110 * c) :=
        mul_le_mul hs2.le hxR hxR0 (by norm_num)
  have hMx2 : M * x ^ 2 = (x * R) ^ 2 / Lv := by
    rw [mul_pow, hR2]
    field_simp
  have h2 : M * x * (Real.exp x - 1) ≤ 1002 / 1000 * ((16 / 110 * c) ^ 2 / Lv) := by
    have hMx : 0 ≤ M * x := by positivity
    calc M * x * (Real.exp x - 1) ≤ M * x * (x + x ^ 2) := mul_le_mul_of_nonneg_left hexp hMx
      _ = M * x ^ 2 * (1 + x) := by ring
      _ ≤ M * x ^ 2 * (1002 / 1000) := by
          apply mul_le_mul_of_nonneg_left (by linarith) (by positivity)
      _ = 1002 / 1000 * ((x * R) ^ 2 / Lv) := by rw [hMx2]; ring
      _ ≤ 1002 / 1000 * ((16 / 110 * c) ^ 2 / Lv) := by
          have : (x * R) ^ 2 ≤ (16 / 110 * c) ^ 2 := pow_le_pow_left₀ hxR0 hxR 2
          gcongr
  have h3 : (16 / 110 * c) ^ 2 / Lv ≤ (16 / 110) ^ 2 * (1 / 20) / 49 * c := by
    rw [div_le_iff₀ hLvpos]
    have hcc : c * c ≤ c * (1 / 20) := mul_le_mul_of_nonneg_left hc1 hc.le
    have : (16 / 110 * c) ^ 2 = (16 / 110) ^ 2 * (c * c) := by ring
    rw [this]
    nlinarith
  nlinarith

/-- **Three-line substitution with prefactor 110** (eqs. `I:eq:3line_sub_1`-`I:eq:3line_sub_3`):
`ε_comp,r < 0.21 ε_r` for `2 ≤ r ≤ L - 1`. -/
theorem adaEpsComp_lt_mid (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    {r : ℕ} (hr2 : 2 ≤ r) (hrL : r ≤ adaL α - 1) :
    adaEpsComp k α β r < 21 / 100 * adaEps α r := by
  have hL5 := five_le_adaL hα hα'
  have hrne : r ≠ adaL α := by omega
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hε := adaEps_pos hα r
  have hε1 := adaEps_le_one_twentieth hα hα' (by omega : 1 ≤ r)
  have hLv := adaLval_gt hα hα' hβ hβ'
  have hM := one_le_adaMmax_real α r
  have hMLpos : 0 < Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) :=
    Real.sqrt_pos.2 (by nlinarith)
  have hn : 110 * Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) / (adaBsvt k α β * adaEps α r) ≤
      (adaNr k α β r : ℝ) := Nat.le_ceil _
  have hnpos : 0 < (adaNr k α β r : ℝ) := lt_of_lt_of_le (by positivity) hn
  have hx : adaEpsEp k α β r = 16 / ((adaNr k α β r : ℝ) * adaBsvt k α β) := by
    unfold adaEpsEp adaSens
    rw [if_neg hrne]
    field_simp
    ring
  have hx0 : 0 ≤ adaEpsEp k α β r := by rw [hx]; positivity
  have hxle : adaEpsEp k α β r ≤
      16 / 110 * adaEps α r / Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) := by
    rw [hx, div_le_div_iff₀ (by positivity) hMLpos]
    have h := hn
    rw [div_le_iff₀ (by positivity)] at h
    nlinarith
  unfold adaEpsComp
  exact epsComp_lt_of_le hM hLv hε hε1 hx0 hxle

/-- **Substitution with prefactor 55 at the anchor** (eqs. `I:eq:55_sub_1`, `I:eq:55_sub_2`):
`ε_comp,L < 0.21 (ε_L/2)`. -/
theorem adaEpsComp_lt_anchor (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) : adaEpsComp k α β (adaL α) < 21 / 100 * (adaEpsL α / 2) := by
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hεL := adaEpsL_pos hα
  have hεL1 : adaEpsL α / 2 ≤ 1 / 20 := by
    have := adaU0_lt hα hα'
    unfold adaEpsL
    linarith
  have hLv := adaLval_gt hα hα' hβ hβ'
  have hM := one_le_adaMmax_real α (adaL α)
  have hMLpos : 0 < Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) :=
    Real.sqrt_pos.2 (by nlinarith)
  have hlog : 0 < Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
    have := log_six_k_gt hα hα' hβ hβ' hk
    linarith
  have hranc := adaRanc_pos hα
  have hn : 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) / (adaBsvt k α β * adaEpsL α) +
      16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) ≤
      (adaNL k α β : ℝ) := Nat.le_ceil _
  have hn' : 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) / (adaBsvt k α β * adaEpsL α) ≤
      (adaNL k α β : ℝ) := by
    have : 0 ≤ 16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) := by
      positivity
    linarith
  have hnpos : 0 < (adaNL k α β : ℝ) := lt_of_lt_of_le (by positivity) hn'
  have hx : adaEpsEp k α β (adaL α) = 4 / ((adaNL k α β : ℝ) * adaBsvt k α β) := by
    unfold adaEpsEp adaSens
    rw [if_pos rfl]
    field_simp
  have hx0 : 0 ≤ adaEpsEp k α β (adaL α) := by rw [hx]; positivity
  have hxle : adaEpsEp k α β (adaL α) ≤
      16 / 110 * (adaEpsL α / 2) / Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) := by
    rw [hx, div_le_div_iff₀ (by positivity) hMLpos]
    have h := hn'
    rw [div_le_iff₀ (by positivity)] at h
    nlinarith
  unfold adaEpsComp
  exact epsComp_lt_of_le hM hLv (by positivity) hεL1 hx0 hxle

/-- **Prop. `I:prop:homog_adv_comp`(i)** (consumer contract): for `2 ≤ r ≤ L - 1`, `S_r ↦ h` is
`(ε_r, δ_val/2)`-DP. -/
theorem homog_adv_comp_mid [MeasurableSpace X] (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable) {r : ℕ}
    (hr2 : 2 ≤ r) (hrL : r ≤ adaL α - 1) :
    ∀ (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α),
      DP.IsDP DP.Neighbor (stageLaw k α β A r S ω') (adaEps α r) (adaDeltaVal α β / 2) := by
  have hL5 := five_le_adaL hα hα'
  intro S ω'
  have h := homog_adv_comp_formula hk hα hα' hβ hβ' A hA hAm hr2 (by omega : r ≤ adaL α) S ω'
  have hlt := adaEpsComp_lt_mid hk hα hα' hβ hβ' hr2 hrL
  have hε := adaEps_pos hα r
  exact h.mono (by linarith) le_rfl

/-- **Prop. `I:prop:homog_adv_comp`(ii)** (consumer contract): `S_L ↦ h` is `(ε_L/2, δ_val/2)`-DP. -/
theorem homog_adv_comp_anchor [MeasurableSpace X] (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16)
    (hβ : 0 < β) (hβ' : β < 1 / 2) (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable) :
    ∀ (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α),
      DP.IsDP DP.Neighbor (stageLaw k α β A (adaL α) S ω') (adaEpsL α / 2) (adaDeltaVal α β / 2) := by
  have hL5 := five_le_adaL hα hα'
  intro S ω'
  have h := homog_adv_comp_formula hk hα hα' hβ hβ' A hA hAm (by omega : 2 ≤ adaL α) le_rfl S ω'
  have hlt := adaEpsComp_lt_anchor hk hα hα' hβ hβ'
  have hε := adaEpsL_pos hα
  exact h.mono (by linarith) le_rfl

end A

end F2e2e
