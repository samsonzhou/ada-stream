import F2e2e.A.S1Privacy
import F2e2e.A.Mechanism
import F2e2e.A.ArchStage1
import F2e2e.Lib.Opt.EntropicSensitivity

/-!
# Stage-1 privacy: interface with the mechanism

Instantiation helpers for Part I, Lemma `I:lem:working_sample_privacy` (3) (`parts/partI.tex` L616–797) for the
mechanism of `F2e2e.A.Mechanism` (owner A-ARCH): the mechanism's coin law `adaNoiseMeasure` is a product over the
noise indices `NoiseIdx`, and the Stage-1 noise vector `V = (clampUnit (ω (.beta i)))_i` has law `f_m^{⊗k}`
(`adaNoise_map_beta`), which is the hypothesis `hVlaw` of `s1_isDP_of_generative`.

## Main statements
* `pi_map_comp_injective`: the image of a product of probability measures under the restriction to an
  injectively indexed family of coordinates is the product of the corresponding factors.
* `adaNoise_map_beta`: the law of the Stage-1 noise vector under the mechanism's coin law.
* `stage1_isDP`: **Lemma `I:lem:working_sample_privacy` (3) for the mechanism**: for every analyst, every
  sample and every realization of the noise not owned by Stage 1, the law of the full transcript as a function
  of the working block `S₁` is `(0.05, αβ/10240)`-DP with respect to single-coordinate replacement
  (`stageLaw k α β A 1 S ω'`, the target statement of A-ARCH/Closure). Ingredients: A-ARCH's factorization
  `transcript_eq_s1Psi` (Step 1), `s1Theta_eq` + `Opt.kkt_query_sensitivity` (the sensitivity `4/n₁`,
  eq. `I:eq:di_centered_bound`), `adaNoise_map_beta`, and `s1_isDP_of_generative`.
-/

namespace F2e2e.A

open MeasureTheory ProbabilityTheory

/-- Restricting a product of probability measures to an injectively indexed family of coordinates. -/
theorem pi_map_comp_injective {ι κ : Type*} [Fintype ι] [Fintype κ] {X : Type*} [MeasurableSpace X]
    (μ : ι → Measure X) [∀ i, IsProbabilityMeasure (μ i)] {e : κ → ι} (he : Function.Injective e) :
    (Measure.pi μ).map (fun ω j => ω (e j)) = Measure.pi (fun j => μ (e j)) := by
  classical
  have hm : Measurable (fun (ω : ι → X) (j : κ) => ω (e j)) :=
    measurable_pi_lambda _ fun j => measurable_pi_apply (e j)
  refine (Measure.pi_eq fun s hs => ?_).symm
  set s' : ι → Set X := fun i => {x | ∀ j, e j = i → x ∈ s j} with hs'
  have hs'm : ∀ i, MeasurableSet (s' i) := by
    intro i
    have : s' i = ⋂ j, ⋂ (_ : e j = i), s j := by
      ext x; simp [hs']
    rw [this]
    exact MeasurableSet.iInter fun j => MeasurableSet.iInter fun _ => hs j
  have hpre : (fun (ω : ι → X) (j : κ) => ω (e j)) ⁻¹' Set.univ.pi s = Set.univ.pi s' := by
    ext ω
    simp only [Set.mem_preimage, Set.mem_univ_pi, hs', Set.mem_ofPred_eq]
    constructor
    · intro h i j hj
      rw [← hj]
      exact h j
    · intro h j
      exact h (e j) j rfl
  rw [Measure.map_apply hm (MeasurableSet.univ_pi hs), hpre, Measure.pi_pi]
  have hout : ∀ i ∉ Finset.univ.image e, μ i (s' i) = 1 := by
    intro i hi
    have : s' i = Set.univ := by
      ext x
      simp only [hs', Set.mem_ofPred_eq, Set.mem_univ, iff_true]
      intro j hj
      exact absurd (Finset.mem_image.2 ⟨j, Finset.mem_univ j, hj⟩) hi
    rw [this, measure_univ]
  have hin : ∀ j, s' (e j) = s j := by
    intro j
    ext x
    simp only [hs', Set.mem_ofPred_eq]
    constructor
    · intro h; exact h j rfl
    · intro h j' hj'
      rw [he hj'] at *
      exact h
  rw [← Finset.prod_subset (Finset.subset_univ (Finset.univ.image e)) (fun i _ hi => hout i hi),
    Finset.prod_image (fun j _ j' _ h => he h)]
  exact Finset.prod_congr rfl fun j _ => by rw [hin j]

/-- **The Stage-1 noise vector** (`hVlaw` of `s1_isDP_of_generative`): under the mechanism's coin law
`adaNoiseMeasure`, the vector `V = (clampUnit (ω (.beta i)))_{i < k}` has law `f_m^{⊗k}`,
`m = adaBetaM α β`. -/
theorem adaNoise_map_beta (k : ℕ) (α β : ℝ) :
    (adaNoiseMeasure k α β).map (fun ω (i : Fin k) => Dist.clampUnit (ω (.beta i))) =
      Measure.pi fun _ : Fin k => Dist.betaSym (adaBetaM α β) := by
  have hproj : Measurable (fun (ω : AdaOmega k α) (i : Fin k) => ω (.beta i)) :=
    measurable_pi_lambda _ fun i => measurable_pi_apply _
  have hcl : Measurable (fun (v : Fin k → ℝ) (i : Fin k) => Dist.clampUnit (v i)) :=
    measurable_pi_lambda _ fun i => Dist.measurable_clampUnit.comp (measurable_pi_apply i)
  have h1 : (fun (ω : AdaOmega k α) (i : Fin k) => Dist.clampUnit (ω (.beta i))) =
      (fun (v : Fin k → ℝ) (i : Fin k) => Dist.clampUnit (v i)) ∘
        (fun (ω : AdaOmega k α) (i : Fin k) => ω (.beta i)) := rfl
  rw [h1, ← Measure.map_map hcl hproj, adaNoiseMeasure,
    pi_map_comp_injective (noiseLaw k α β) (fun i j h => NoiseIdx.beta.inj h)]
  have hsf : ∀ i : Fin k, SigmaFinite ((noiseLaw k α β (.beta i)).map Dist.clampUnit) := fun i => by
    rw [show noiseLaw k α β (.beta i) = Dist.betaSym (adaBetaM α β) from rfl,
      Dist.map_clampUnit_betaSym]
    infer_instance
  rw [Measure.pi_map_pi (fun i => Dist.measurable_clampUnit.aemeasurable)]
  congr 1
  funext i
  exact Dist.map_clampUnit_betaSym _

/-- **Lemma `I:lem:working_sample_privacy` (3) for the mechanism of Definition I.1.8** (`parts/partI.tex`
L616–619, eq. `I:eq:s1_dp_claim`): fix the analyst `A` (valid, jointly measurable), the sample `S` (whose blocks
other than `S₁` are used) and the noise `ω'` not owned by Stage 1; then the law of the full `k`-round transcript,
as a function of the working block `S₁` (with the Stage-1 noise drawn from the mechanism's coin law), is
`(ε₁, δ₁) = (0.05, αβ/10240)`-DP with respect to single-coordinate replacement. -/
theorem stage1_isDP (k : ℕ) {α β : ℝ} (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {X : Type} [MeasurableSpace X] (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) :
    DP.IsDP DP.Neighbor (stageLaw k α β A 1 S ω') adaEps1 (adaDelta1 α β) := by
  have hV : Measurable (fun (ω : AdaOmega k α) (i : Fin k) => Dist.clampUnit (ω (.beta i))) :=
    measurable_pi_lambda _ fun i => Dist.measurable_clampUnit.comp (measurable_pi_apply _)
  have h4 : (4 : ℝ) / (adaBlock k α β 1 : ℝ) = 4 / (adaN1 k α β : ℝ) := by rw [adaBlock_one]
  have hsens : ∀ S₁ S₁' : Fin (adaBlock k α β 1) → X, DP.Neighbor S₁ S₁' →
      ∀ (i : Fin k) (a : Fin k → ℝ),
        |s1Theta k α β A S ω' S₁ i a - s1Theta k α β A S ω' S₁' i a| ≤ 4 / (adaN1 k α β : ℝ) := by
    intro S₁ S₁' hS i a
    rw [s1Theta_eq, s1Theta_eq, ← h4]
    exact Opt.kkt_query_sensitivity 1 (i : ℕ) (fun j => (recAt (s1Psi k α β A S ω' a) j).delta 1)
      (qry A (s1Psi k α β A S ω' a)) (qry A (s1Psi k α β A S ω' a) i) (fun x => hA _ _ x) hS
  exact s1_isDP_of_generative hα hα16 hβ hβ2 (P := adaNoiseMeasure k α β)
    (V := fun ω i => Dist.clampUnit (ω (.beta i))) hV (adaNoise_map_beta k α β) DP.Neighbor
    (θ := s1Theta k α β A S ω') (fun S₁ i => measurable_s1Theta A hAm S ω' S₁ i)
    (fun S₁ i => s1Theta_dependsOn A S ω' S₁ i) hsens
    (Φ := s1Phi k α β A S ω') (fun S₁ v i => isTriangularSol_s1Phi A S ω' S₁ v i)
    (Ψ := s1Psi k α β A S ω') (measurable_s1Psi A hAm S ω')
    (out := fun S₁ ω => transcript k α β A (replaceBlock k α β 1 S₁ S) (mixNoise 1 ω ω'))
    (fun S₁ ω => transcript_eq_s1Psi A S ω' S₁ ω)

end F2e2e.A
