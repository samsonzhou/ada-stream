import F2e2e.A.NumericsSample
import F2e2e.A.NumericsAsymp

/-!
# Part I numerics: the headline numeric conjuncts of `Theorem_A` (contracts)

Owner: worker A-NUM.

* `adaSampleSize_le_explicit`: the explicit sample size of Theorem I.1.1
  (`I:eq:main_thm_explicit_n`) is at most its explicit intermediate bound (`I:eq:main_explicit_bound`);
  `parts/partI.tex` L16-22 and Proposition `I:prop:validator_sample_complexity` (L2090-2179). Proof:
  `n₁ = ⌈…⌉ < … + 1` and `∑_{r=2}^{L} n_r ≤ 10⁸ L^{7/2} Λ_SVT √L_val/α²` (`validator_sum_le`,
  `F2e2e/A/NumericsSample.lean`).
* `adaSampleSize_le_asymp`: the explicit sample size is at most a universal constant (`C = 10¹²`) times the
  asymptotic expression `adaAsymp` (`I:eq:main_sample_complexity`, with the improved leading term
  for `β ≥ α⁵`), uniformly in `k ≥ 1`, `α ∈ (0, 1/16)`, `β ∈ (0, 1/2)` (`adaExplicitBound_le_asymp`,
  `F2e2e/A/NumericsAsymp.lean`).
-/

namespace F2e2e

namespace A

/-- Theorem I.1.1, `I:eq:main_thm_explicit_n` ≤ `I:eq:main_explicit_bound`. -/
theorem adaSampleSize_le_explicit (k : ℕ) (a b : ℝ) (hk : 1 ≤ k) (ha : 0 < a) (ha' : a < 1 / 16)
    (hb : 0 < b) (hb' : b < 1 / 2) : (adaSampleSize k a b : ℝ) ≤ adaExplicitBound k a b :=
  adaSampleSize_le_explicitBound k a b hk ha ha' hb hb'

/-- Theorem I.1.1, `I:eq:main_sample_complexity`: the explicit sample size is `O(adaAsymp)` with a
universal constant. -/
theorem adaSampleSize_le_asymp :
    ∃ C : ℝ, 0 < C ∧ ∀ (k : ℕ) (a b : ℝ), 1 ≤ k → 0 < a → a < 1 / 16 → 0 < b → b < 1 / 2 →
      (adaSampleSize k a b : ℝ) ≤ C * adaAsymp k a b :=
  ⟨10 ^ 12, by norm_num, fun k a b hk ha ha' hb hb' =>
    (adaSampleSize_le_explicit k a b hk ha ha' hb hb').trans
      (adaExplicitBound_le_asymp k a b hk ha ha' hb hb')⟩

end A

end F2e2e
