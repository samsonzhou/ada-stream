import F2e2e.A.ClosureDefs
import F2e2e.A.NumericsBasic
import F2e2e.A.NumericsBudget
import F2e2e.A.ArchMeasurable

/-!
# Part I §5: the deterministic comparator floors on the mechanism's transcript

Paper: `parts/partI.tex` Lemma `I:lem:stage1_trigger_cap_closure`(ii) (L1781–1809), Lemma
`I:lem:obl1_measurability_ceiling` (L1846–1903), Theorem `I:thm:pigeonhole_comparator_closure`(1) (L1929–1970).

The bridge from the mechanism (`F2e2e/A/{Mechanism,Chain}.lean`) to the abstract regret lemmas of
`F2e2e/A/ClosureCore.lean`: the start-of-round weights of level `r` are the entropic-FTRL iterates
`P*(G_(i))` of the transcript's impulses `δ_{r,j}` on the block values `q_j(X_{r,ℓ})` (`onlineState_weight_eq`), and the
start-of-round means `θ_i^{(r)}` are `⟨P_(i), q_i(S_r)⟩` (`onlineChain_theta`).
-/

namespace F2e2e.A

open MeasureTheory Finset

noncomputable section

variable {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ}

/-! ### Block sizes -/

theorem adaBlock_one_pos (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    0 < adaBlock k α β 1 := by
  rw [adaBlock_one]
  unfold adaN1
  apply Nat.ceil_pos.mpr
  have hL1 := adaL1_pos hα hα' hβ hβ'
  have hchi := adaChi1_nonneg hα hα' hβ hβ'
  have h1 : 0 ≤ 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α := by positivity
  have h2 : 0 < 16000 * adaL1 α β ^ 3 / α ^ 2 := by positivity
  linarith

theorem adaBlock_mid_pos (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    {m : ℕ} (hm2 : 2 ≤ m) (hmL : m < adaL α) : 0 < adaBlock k α β m := by
  rw [adaBlock_mid k α β hm2 hmL]
  unfold adaNr
  apply Nat.ceil_pos.mpr
  have h1 := adaLval_pos hα hα' hβ hβ'
  have h2 := adaBsvt_pos hα hα' hβ hβ' hk
  have h3 := adaEps_pos hα m
  have hM : (0 : ℝ) < adaMmax α m := by linarith [one_le_adaMmax_real α m]
  have hs : 0 < Real.sqrt ((adaMmax α m : ℝ) * adaLval α β) := Real.sqrt_pos.mpr (mul_pos hM h1)
  exact div_pos (mul_pos (by norm_num) hs) (mul_pos h2 h3)

/-! ### The transcript records -/

theorem recAt_eq (h : Fin k → RoundRec) {i : ℕ} (hi : i < k) : recAt h i = h ⟨i, hi⟩ := by
  simp [recAt, hi]

omit [MeasurableSpace X] in
/-- Case-A (and Case-B) records carry a sign of absolute value one. -/
theorem transcript_abs_sgn (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (i : Fin k) (h2 : 2 ≤ (transcript k α β A S ω i).ufinal) : |(transcript k α β A S ω i).sgn| = 1 := by
  cases hact : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i hact, RoundRec.halted_ufinal] at h2
    omega
  · rw [transcript_of_active A S ω i hact] at h2 ⊢
    exact ChainData.abs_sgn_of_two_le _ h2

/-- `∑_{i<k} f(recAt h i, i)` as a sum over `Fin k`. -/
theorem sum_range_recAt {M : Type*} [AddCommMonoid M] (h : Fin k → RoundRec) (f : RoundRec → ℕ → M) :
    ∑ j ∈ Finset.range k, f (recAt h j) j = ∑ i : Fin k, f (h i) i := by
  rw [← Fin.sum_univ_eq_sum_range (fun j => f (recAt h j) j) k]
  exact Finset.sum_congr rfl fun i _ => by rw [recAt_fin]

/-! ### The FTRL structure of the mechanism -/

omit [MeasurableSpace X] in
/-- The start-of-round weights of level `r ≠ L` are the entropic-FTRL iterates `P*(G_(i))` at any rate `η ≠ 0`,
`G_(i) = ∑_{j<i} (δ_{r,j}/η) q_j(S_r)` (paper eq. `I:eq:round_payoff_recursion`, `I:eq:validator_ftrl_minimizer`). -/
theorem onlineState_weight_eq (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {i : ℕ} (hi : i ≤ k) {r : ℕ} (hr : r ≠ adaL α) {η : ℝ} (hη : η ≠ 0) :
    (onlineState k α β A S ω i).weight r = Opt.waterFill (adaBlock k α β r) η (fun ℓ =>
      ∑ j ∈ Finset.range i, (recAt (transcript k α β A S ω) j).delta r / η *
        qry A (transcript k α β A S ω) j (blockOf k α β r S ℓ)) := by
  unfold MState.weight
  rw [if_neg hr]
  apply Opt.waterFill_congr
  intro ℓ
  rw [onlineState_pay A S ω hi r ℓ, one_mul, Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  simp only [blockOf]
  field_simp

omit [MeasurableSpace X] in
/-- The start-of-round means `θ_i^{(r)} = ⟨P_(i), q_i(S_r)⟩` (`I:eq:theta_def`). -/
theorem onlineChain_theta (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {i : ℕ} (hi : i ≤ k) (r : ℕ) :
    (onlineChain k α β A S ω i).theta r =
      ∑ ℓ, (onlineState k α β A S ω i).weight r ℓ * qry A (transcript k α β A S ω) i (blockOf k α β r S ℓ) := by
  show (onlineState k α β A S ω i).theta (onlineQ k α β A S ω i) r = _
  unfold MState.theta
  rw [onlineQ_eq_qry A S ω hi]
  rfl

omit [MeasurableSpace X] in
/-- The Stage-1 impulse of round `i < k`: `-η₁ s` on Case-A rounds and `0` otherwise. -/
theorem recAt_delta_one (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {i : ℕ} (hi : i < k) :
    (recAt (transcript k α β A S ω) i).delta 1 =
      if (transcript k α β A S ω ⟨i, hi⟩).ufinal = 2 then -adaEta1 α * (transcript k α β A S ω ⟨i, hi⟩).sgn
      else 0 := by
  rw [recAt_eq _ hi]
  exact transcript_delta_one A S ω ⟨i, hi⟩

omit [MeasurableSpace X] in
/-- Non-zero Stage-1 impulses are exactly the Case-A rounds. -/
theorem recAt_delta_one_ne_zero_iff (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) {i : ℕ} (hi : i < k) :
    (recAt (transcript k α β A S ω) i).delta 1 ≠ 0 ↔ (transcript k α β A S ω ⟨i, hi⟩).ufinal = 2 := by
  rw [recAt_delta_one A S ω hi]
  have hη : 0 < adaEta1 α := by unfold adaEta1; positivity
  constructor
  · intro h
    by_contra h2
    rw [if_neg h2] at h
    exact h rfl
  · intro h2
    rw [if_pos h2]
    have hs := transcript_abs_sgn A S ω ⟨i, hi⟩ (by omega)
    intro h0
    have : |(-adaEta1 α * (transcript k α β A S ω ⟨i, hi⟩).sgn)| = 0 := by rw [h0, abs_zero]
    rw [abs_mul, abs_neg, abs_of_pos hη, hs, mul_one] at this
    linarith

omit [MeasurableSpace X] in
/-- The number of non-zero Stage-1 impulses is `t₁`. -/
theorem card_delta_one_ne_zero (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) :
    ((Finset.range k).filter fun j => (recAt (transcript k α β A S ω) j).delta 1 ≠ 0).card =
      finalT1 (transcript k α β A S ω) := by
  unfold finalT1
  rw [Finset.card_filter, Finset.card_filter]
  rw [← sum_range_recAt (transcript k α β A S ω) (fun r _ => if r.ufinal = 2 then 1 else 0)]
  refine Finset.sum_congr rfl fun j hj => ?_
  rw [Finset.mem_range] at hj
  have h := recAt_delta_one_ne_zero_iff hα A S ω hj
  rw [recAt_eq _ hj]
  rw [recAt_eq _ hj] at h
  by_cases h2 : (transcript k α β A S ω ⟨j, hj⟩).ufinal = 2
  · rw [if_pos (h.mpr h2), if_pos h2]
  · rw [if_neg (fun h' => h2 (h.mp h')), if_neg h2]

omit [MeasurableSpace X] in
/-- `∑_i |δ_{1,i}| = η₁ t₁`. -/
theorem sum_abs_delta_one (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) :
    ∑ i : Fin k, |(transcript k α β A S ω i).delta 1| = adaEta1 α * finalT1 (transcript k α β A S ω) := by
  have hη : 0 < adaEta1 α := by unfold adaEta1; positivity
  unfold finalT1
  rw [Finset.card_filter, Nat.cast_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [transcript_delta_one A S ω i]
  by_cases h2 : (transcript k α β A S ω i).ufinal = 2
  · rw [if_pos h2, if_pos h2, abs_mul, abs_neg, abs_of_pos hη, transcript_abs_sgn A S ω i (by omega)]
    simp
  · rw [if_neg h2, if_neg h2]
    simp

omit [MeasurableSpace X] in
/-- Weighted sums of a gated linear functional: if the gate is open and `∑ Q = 1`,
`∑_ℓ Q(ℓ) F(x_ℓ) = c ∑_i a_i (∑_ℓ Q(ℓ) q_i(x_ℓ) - μ_i)`. -/
theorem sum_mul_linTest {n : ℕ} (Q : Fin n → ℝ) (hQ1 : ∑ ℓ, Q ℓ = 1) (xs : Fin n → X) (c : ℝ)
    (a μ : Fin k → ℝ) (q : Fin k → X → ℝ) (hgate : c * ∑ i, |a i| ≤ 1) :
    ∑ ℓ, Q ℓ * linTest Finset.univ c a μ q (xs ℓ) = c * ∑ i, a i * (∑ ℓ, Q ℓ * q i (xs ℓ) - μ i) := by
  simp_rw [linTest_eq hgate]
  have h1 : ∀ ℓ, Q ℓ * (c * ∑ i, a i * (q i (xs ℓ) - μ i)) =
      ∑ i, c * (a i * (Q ℓ * q i (xs ℓ)) - a i * μ i * Q ℓ) := by
    intro ℓ
    rw [Finset.mul_sum, Finset.mul_sum]
    exact Finset.sum_congr rfl fun i _ => by ring
  rw [Finset.sum_congr rfl fun ℓ _ => h1 ℓ, Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [← Finset.mul_sum, Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum, hQ1, mul_one]
  ring

/-! ### Lemma `I:lem:stage1_trigger_cap_closure`(ii) -/

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(ii)**, the comparator floor (eq. `I:eq:stage1_comparator_clean_lb`):
on `{t₁ = T_{1,max}}`, if every Case-A round has the decoupling margin `s (θ^{(1)} - μ) > 3α/16` (which §4 proves
on `E_clean`), then `Z₁(S₁) ⟨Q*^{(1)}, F⁽¹⁾(h, S₁)⟩ ≥ e^{-ε₁} (15/128 - 1/30000) α`. -/
theorem stage1_comparator_floor (_hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid) (_hAm : A.JointlyMeasurable)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hT : finalT1 (transcript k α β A z.1 z.2) = adaT1max α)
    (hdec : ∀ i : Fin k, (transcript k α β A z.1 z.2 i).ufinal = 2 →
      3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i)) :
    Real.exp (-adaEps1) * ((15 / 128 - 1 / 30000) * α) ≤
      tiltG k α β A 1 adaEps1 (fun h => stage1F α D A h) z := by
  set h := transcript k α β A z.1 z.2 with hh
  set n := adaBlock k α β 1 with hn_def
  have hn : 0 < n := adaBlock_one_pos hα hα' hβ hβ'
  have hη : 0 < adaEta1 α := by unfold adaEta1; positivity
  have hT1 : 0 < adaT1max α := one_le_adaT1max hα
  have hTr : (600 : ℝ) / α ^ 2 ≤ (adaT1max α : ℝ) := Nat.le_ceil _
  have hr1 : (1 : ℕ) ≠ adaL α := by have := adaL_ge_four α; omega
  -- the regret data on block 1
  set δ : ℕ → ℝ := fun j => (recAt h j).delta 1 with hδdef
  set zv : ℕ → Fin n → ℝ := fun j ℓ => qry A h j (blockOf k α β 1 z.1 ℓ) with hzv
  set μv : ℕ → ℝ := fun j => popMu D A h j with hμv
  set P : ℕ → Fin n → ℝ := fun i => (onlineState k α β A z.1 z.2 i).weight 1 with hPdef
  have hP : ∀ i ≤ k, P i = Opt.waterFill n (adaEta1 α) (fun ℓ => ∑ j ∈ range i, δ j / adaEta1 α * zv j ℓ) :=
    fun i hi => onlineState_weight_eq A z.1 z.2 hi hr1 hη.ne'
  have hz : ∀ i < k, ∀ ℓ, zv i ℓ ∈ Set.Icc (0 : ℝ) 1 := fun i _ ℓ => qry_mem_Icc A hA h i _
  have hδη : ∀ i < k, δ i ≠ 0 → |δ i| = adaEta1 α := by
    intro i hi h0
    have h2 := (recAt_delta_one_ne_zero_iff hα A z.1 z.2 hi).mp h0
    simp only [hδdef]
    rw [recAt_delta_one A z.1 z.2 hi, if_pos h2, abs_mul, abs_neg, abs_of_pos hη,
      transcript_abs_sgn A z.1 z.2 ⟨i, hi⟩ (by omega), mul_one]
  have hcard : ((range k).filter fun i => δ i ≠ 0).card = adaT1max α := by
    rw [← hT]
    exact card_delta_one_ne_zero hα A z.1 z.2
  have hdec' : ∀ i < k, δ i ≠ 0 → α / 8 ≤ (-δ i / adaEta1 α) * (∑ ℓ, P i ℓ * zv i ℓ - μv i) := by
    intro i hi h0
    have h2 := (recAt_delta_one_ne_zero_iff hα A z.1 z.2 hi).mp h0
    have hd : 3 / 16 * α < (transcript k α β A z.1 z.2 ⟨i, hi⟩).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A h i) := hdec ⟨i, hi⟩ h2
    have hδi : δ i = -adaEta1 α * (transcript k α β A z.1 z.2 ⟨i, hi⟩).sgn := by
      simp only [hδdef]
      rw [recAt_delta_one A z.1 z.2 hi, if_pos h2]
    have hθ : ∑ ℓ, P i ℓ * zv i ℓ = (onlineChain k α β A z.1 z.2 i).theta 1 := by
      rw [onlineChain_theta A z.1 z.2 hi.le]
    rw [hδi, hθ]
    have e : -(-adaEta1 α * (transcript k α β A z.1 z.2 ⟨i, hi⟩).sgn) / adaEta1 α =
        (transcript k α β A z.1 z.2 ⟨i, hi⟩).sgn := by
      field_simp
    rw [e]
    have : μv i = popMu D A h i := rfl
    rw [this]
    linarith
  -- the comparator
  set f := blockVals k α β A 1 (fun h => stage1F α D A h) z with hf
  set Q := tiltQ adaEps1 f with hQdef
  have hε0 : (0 : ℝ) ≤ adaEps1 := by unfold adaEps1; norm_num
  have hε2 : adaEps1 ≤ Real.log 2 / 2 := by
    unfold adaEps1
    exact one_twentieth_le_half_log_two
  have hQ : Q ∈ Opt.cappedSimplex n := tiltQ_mem_cappedSimplex hn hε0 hε2 f
  have hKL : Opt.klUnif n Q ≤ adaEps1 ^ 2 / 2 := klUnif_tiltQ_le hn adaEps1 f
  have hfloor := stage1_floor_of_regret hn hη δ zv μv k (adaT1max α) hT1 hz P hP hδη hcard hdec' Q hQ hKL
  have hnum := stage1_floor_num hα hTr
  -- `⟨Q, f⟩ = (1/(η₁ T)) ∑_i (-δ_i)(⟨Q, z_i⟩ - μ_i)`
  have hgate : 1 / (adaEta1 α * adaT1max α) * ∑ i : Fin k, |-(h i).delta 1| ≤ 1 := by
    simp_rw [abs_neg]
    rw [sum_abs_delta_one hα A z.1 z.2, hT]
    rw [div_mul_eq_mul_div, one_mul, div_self (by positivity)]
  have hQf : ∑ ℓ, Q ℓ * f ℓ =
      1 / (adaEta1 α * adaT1max α) * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * zv i ℓ - μv i) := by
    have hfl : ∀ ℓ, f ℓ = linTest Finset.univ (1 / (adaEta1 α * adaT1max α)) (fun i => -(h i).delta 1)
        (fun i => popMu D A h i) (fun i => qry A h i) (blockOf k α β 1 z.1 ℓ) := by
      intro ℓ
      simp only [hf, blockVals, stage1F]
      rw [if_pos hT]
    simp_rw [hfl]
    rw [sum_mul_linTest Q (sum_tiltQ hn adaEps1 f) (blockOf k α β 1 z.1) _ _ _ _ hgate]
    congr 1
    rw [← sum_range_recAt h (fun r j => (-r.delta 1) * (∑ ℓ, Q ℓ * qry A h j (blockOf k α β 1 z.1 ℓ) -
      popMu D A h j))]
  have hZ := (tiltZ_mem_Icc hn hε0 f).1
  have hpos : 0 < (15 / 128 - 1 / 30000) * α := by nlinarith
  have hgoal : (15 / 128 - 1 / 30000) * α ≤ ∑ ℓ, Q ℓ * f ℓ := by
    rw [hQf]
    have : α / 8 - adaEta1 α / 8 - adaEps1 ^ 2 / (2 * adaEta1 α * (adaT1max α : ℝ)) =
        α / 8 - α / 16 / 8 - (1 / 20 : ℝ) ^ 2 / (2 * (α / 16) * (adaT1max α : ℝ)) := by
      unfold adaEta1 adaEps1
      ring
    linarith
  show Real.exp (-adaEps1) * ((15 / 128 - 1 / 30000) * α) ≤ tiltZ adaEps1 f * ∑ ℓ, Q ℓ * f ℓ
  exact mul_le_mul hZ hgoal hpos.le (le_trans (Real.exp_pos _).le hZ)

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(ii)**, pointwise non-negativity: `Ĝ₁ 1_{E_clean} ≥ 0` everywhere. -/
theorem tiltG_stage1_nonneg (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    (hdec : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).ufinal = 2 →
      3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i))
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) (hz : EClean k α β D A z) :
    0 ≤ tiltG k α β A 1 adaEps1 (fun h => stage1F α D A h) z := by
  by_cases hT : finalT1 (transcript k α β A z.1 z.2) = adaT1max α
  · have h1 := stage1_comparator_floor hk hα hα' hβ hβ' D A hA hAm z hT (hdec z hz)
    have h2 : 0 ≤ Real.exp (-adaEps1) * ((15 / 128 - 1 / 30000) * α) := by positivity
    linarith
  · rw [tiltG_stage1_eq_zero D A adaEps1 z hT]

/-! ### Lemma `I:lem:obl1_measurability_ceiling` -/

/-- The final counters are measurable functions of the transcript. -/
theorem measurable_finalN (r : ℕ) : Measurable fun h : Fin k → RoundRec => finalN h r := by
  have : (fun h : Fin k → RoundRec => finalN h r) =
      fun h => ∑ i : Fin k, if (h i).ufinal = r then 1 else 0 := by
    funext h
    unfold finalN
    rw [Finset.card_filter]
  rw [this]
  refine Finset.measurable_sum _ fun i _ => ?_
  refine Measurable.ite ?_ measurable_const measurable_const
  exact (RoundRec.measurable_ufinal.comp (measurable_pi_apply i)) (measurableSet_singleton r)

theorem measurable_finalT1 : Measurable fun h : Fin k → RoundRec => finalT1 h := by
  have : (fun h : Fin k → RoundRec => finalT1 h) = fun h => finalN h 2 := by
    funext h
    rfl
  rw [this]
  exact measurable_finalN 2

/-- `E_halt(h)` is a measurable event of the transcript. -/
theorem measurableSet_EHalt (α : ℝ) : MeasurableSet {h : Fin k → RoundRec | EHalt α h} := by
  have : {h : Fin k → RoundRec | EHalt α h} =
      ⋃ r ∈ Finset.Icc 3 (adaL α), {h | finalN h r = adaNmax α r} := by
    ext h
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Finset.mem_Icc, EHalt, exists_prop]
    constructor
    · rintro ⟨r, h3, hL, hN⟩
      exact ⟨r, ⟨h3, hL⟩, hN⟩
    · rintro ⟨r, ⟨h3, hL⟩, hN⟩
      exact ⟨r, h3, hL, hN⟩
  rw [this]
  exact Finset.measurableSet_biUnion _ fun r _ => (measurable_finalN r) (measurableSet_singleton _)

theorem histAns_measurable (i : ℕ) : Measurable (fun h : Fin k → RoundRec => histAns h i) := by
  rw [measurable_pi_iff]
  intro j
  by_cases hj : j.val < k
  · simp only [histAns, dif_pos hj]
    exact measurable_pi_apply _
  · simp only [histAns, dif_neg hj]
    exact measurable_const

/-- The query `(h, x) ↦ q_i(h)(x)` is jointly measurable for a jointly measurable analyst. -/
theorem qry_measurable (A : DetAnalyst X) (hA : A.JointlyMeasurable) (i : ℕ) :
    Measurable (fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2) :=
  (hA i).comp (((histAns_measurable i).comp measurable_fst).prodMk measurable_snd)

/-- `μ_i(h)` is a measurable function of the transcript (Remark `I:rem:measurability_mu_i`). -/
theorem popMu_measurable (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (i : ℕ) : Measurable (fun h : Fin k → RoundRec => popMu D A h i) := by
  unfold popMu
  exact (StronglyMeasurable.integral_prod_right'
    (f := fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2)
    (qry_measurable A hA i).stronglyMeasurable).measurable

theorem delta_measurable (i : Fin k) (m : ℕ) : Measurable (fun h : Fin k → RoundRec => (h i).delta m) :=
  (measurable_pi_apply m).comp (RoundRec.measurable_delta.comp (measurable_pi_apply i))

theorem c_measurable (i : Fin k) (m : ℕ) : Measurable (fun h : Fin k → RoundRec => (h i).c m) :=
  (measurable_pi_apply m).comp (RoundRec.measurable_c.comp (measurable_pi_apply i))

/-- **Lemma `I:lem:obl1_measurability_ceiling`(1)** (Remark `I:rem:prog_m_measurability`): `Prog_m(h)` is a
measurable function of the transcript. -/
theorem progM_measurable (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) (m : ℕ) : Measurable fun h : Fin k → RoundRec => progM α D A h m := by
  unfold progM
  refine measurable_const.mul (Finset.measurable_sum _ fun i _ => ?_)
  have hδ := delta_measurable (k := k) i m
  have hc := c_measurable (k := k) i m
  have hμ := popMu_measurable (k := k) D A hAm i
  exact ((hδ.neg.mul (hc.sub hμ)).sub ((hδ.pow_const 2).div_const 8)).sub
    ((continuous_abs.measurable.comp hδ).mul_const _)

/-- **Lemma `I:lem:obl1_measurability_ceiling`(1)**, measurability of `A_m(h)` in the transcript. -/
theorem measurableSet_AmEvent (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) (m : ℕ) : MeasurableSet {h : Fin k → RoundRec | AmEvent α D A h m} := by
  have : {h : Fin k → RoundRec | AmEvent α D A h m} =
      {h | EHalt α h} ∩ {h | 128 ≤ progM α D A h m} := rfl
  rw [this]
  exact (measurableSet_EHalt α).inter (measurableSet_le measurable_const (progM_measurable D A hAm m))

/-- `W̃_{max,m}` in Spec terms (A-NUM's `adaWmaxSpec`). -/
theorem adaWmax_eq_spec (α : ℝ) (m : ℕ) : adaWmax α m = adaWmaxSpec α m := by
  unfold adaWmax adaWmaxSpec adaW
  split_ifs <;> ring

/-- **Lemma `I:lem:obl1_measurability_ceiling`(2)**, ceiling remainder bound (eq. `I:eq:W_tilde_ceiling_bound`),
lower half: `W̃_{max,m} ≥ 128 L/γ`. -/
theorem adaWmax_ge (hα : 0 < α) (hα' : α < 1 / 16) {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1) :
    128 * (adaL α : ℝ) / adaGamma α ≤ adaWmax α m := by
  rw [adaWmax_eq_spec]
  exact wmax_ge hα hα' hm2 hmL

/-- **Lemma `I:lem:obl1_measurability_ceiling`(2)**, ceiling remainder bound (eq. `I:eq:W_tilde_ceiling_bound`),
upper half: `W̃_{max,m} < 257 L/γ`. -/
theorem adaWmax_lt (hα : 0 < α) (hα' : α < 1 / 16) {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1) :
    adaWmax α m < 257 * (adaL α : ℝ) / adaGamma α := by
  rw [adaWmax_eq_spec]
  exact wmax_lt hα hα' hm2 hmL

theorem adaWmax_pos (hα : 0 < α) (hα' : α < 1 / 16) {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1) :
    0 < adaWmax α m := by
  have h1 := adaWmax_ge hα hα' hm2 hmL
  have h2 : 0 < 128 * (adaL α : ℝ) / adaGamma α := by
    have := adaGamma_pos hα
    have := adaL_cast_pos α
    positivity
  linarith

omit [MeasurableSpace X] in
/-- **Lemma `I:lem:obl1_measurability_ceiling`(2)**, the deterministic `ℓ₁` step budget
(eq. `I:eq:l1_step_budget_bound`): `8 w_m ∑_i |δ_{m,i}| ≤ W̃_{max,m}` on every transcript. -/
theorem l1_step_budget (hα : 0 < α) (_hα' : α < 1 / 16) (A : DetAnalyst X)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1) :
    8 * adaW α m * ∑ i : Fin k, |(transcript k α β A S ω i).delta m| ≤ adaWmax α m := by
  have hL4 := adaL_ge_four α
  have hw : 0 < adaW α m := by
    unfold adaW
    have := adaEps_pos hα m
    positivity
  have hw' : 0 < adaW α (m - 1) := by
    unfold adaW
    have := adaEps_pos hα (m - 1)
    positivity
  have hγ := adaGamma_pos hα
  have hN1 : (finalN (transcript k α β A S ω) (m + 1) : ℝ) ≤ adaNmax α (m + 1) := by
    exact_mod_cast finalN_le hα A S ω (by omega : 3 ≤ m + 1)
  rw [sum_abs_delta hα A S ω hm2]
  unfold adaWmax
  have hmL' : m ≠ adaL α := by omega
  split_ifs with h3
  · have hN2 : (finalN (transcript k α β A S ω) m : ℝ) ≤ adaNmax α m := by
      exact_mod_cast finalN_le hα A S ω h3
    have hηT : |adaEtaTilde α m| = adaW α (m - 1) / adaW α m * adaEta α := by
      unfold adaEtaTilde
      rw [if_neg hmL', abs_of_nonneg]
      unfold adaEta
      positivity
    rw [hηT]
    have e1 : 8 * adaW α m * (adaEta α * (finalN (transcript k α β A S ω) (m + 1) : ℝ) +
        adaW α (m - 1) / adaW α m * adaEta α * (finalN (transcript k α β A S ω) m : ℝ)) =
        adaGamma α * (adaW α m * (finalN (transcript k α β A S ω) (m + 1) : ℝ) +
          adaW α (m - 1) * (finalN (transcript k α β A S ω) m : ℝ)) := by
      unfold adaEta
      field_simp
    rw [e1]
    gcongr
  · have e1 : 8 * adaW α m * (adaEta α * (finalN (transcript k α β A S ω) (m + 1) : ℝ) + 0) =
        adaGamma α * (adaW α m * (finalN (transcript k α β A S ω) (m + 1) : ℝ)) := by
      unfold adaEta
      ring
    rw [e1, add_zero]
    gcongr

/-- **Lemma `I:lem:obl1_measurability_ceiling`(2)**: `F^{(m)}(h, x) ∈ [-1, 1]` for all `(h, x)`. -/
theorem valF_mem_Icc (hα : 0 < α) (hα' : α < 1 / 16) (D : Measure X) [IsProbabilityMeasure D]
    (A : DetAnalyst X) (hA : A.Valid) (h : Fin k → RoundRec) {m : ℕ} (hm2 : 2 ≤ m)
    (hmL : m ≤ adaL α - 1) (x : X) : valF α D A h m x ∈ Set.Icc (-1 : ℝ) 1 := by
  classical
  unfold valF
  split_ifs
  · have hc : (0 : ℝ) ≤ 8 * adaW α m / adaWmax α m := by
      have := adaWmax_pos hα hα' hm2 hmL
      unfold adaW
      positivity
    exact linTest_mem_Icc Finset.univ hc (fun i => -(h i).delta m) (fun i => popMu D A h i)
      (fun i => qry A h i) (fun i x => qry_mem_Icc A hA h i x) (fun i => popMu_mem_Icc D A hA h i) x
  · exact ⟨by norm_num, by norm_num⟩

/-! ### Theorem `I:thm:pigeonhole_comparator_closure`(1) -/

/-- **Theorem `I:thm:pigeonhole_comparator_closure`(1)**, the comparator floor on `A_m(h) ∩ E_clean`
(eqs. `I:eq:validator_comparator_124`, `I:eq:pointwise_nonnegativity_Ghat`): if `A_m(h)` holds and the released
validator values are `u₀`-close to `θ^{(m)}` on every round with `δ_{m,i} ≠ 0` (§4, on `E_clean`; a non-zero
impulse is only applied to a released level), then `Ĝ_m ≥ 124 e^{-ε_m}/W̃_{max,m}`. -/
theorem validator_comparator_floor (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (_hAm : A.JointlyMeasurable) {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hAmz : AmEvent α D A (transcript k α β A z.1 z.2) m)
    (hclip : ∀ i : Fin k, (transcript k α β A z.1 z.2 i).delta m ≠ 0 →
      |(transcript k α β A z.1 z.2 i).c m - (onlineChain k α β A z.1 z.2 i).theta m| ≤ adaU0 α) :
    124 * Real.exp (-adaEps α m) / adaWmax α m ≤
      tiltG k α β A m (adaEps α m) (fun h => valF α D A h m) z := by
  set h := transcript k α β A z.1 z.2 with hh
  have hL4 := adaL_ge_four α
  have hmL' : m < adaL α := by omega
  set n := adaBlock k α β m with hn_def
  have hn : 0 < n := adaBlock_mid_pos hk hα hα' hβ hβ' hm2 hmL'
  have hη : 0 < adaEta α := by
    unfold adaEta
    have := adaGamma_pos hα
    positivity
  have hrm : m ≠ adaL α := by omega
  set δ : ℕ → ℝ := fun j => (recAt h j).delta m with hδdef
  set zv : ℕ → Fin n → ℝ := fun j ℓ => qry A h j (blockOf k α β m z.1 ℓ) with hzv
  set μv : ℕ → ℝ := fun j => popMu D A h j with hμv
  set cv : ℕ → ℝ := fun j => (recAt h j).c m with hcv
  set P : ℕ → Fin n → ℝ := fun i => (onlineState k α β A z.1 z.2 i).weight m with hPdef
  have hP : ∀ i ≤ k, P i = Opt.waterFill n (adaEta α) (fun ℓ => ∑ j ∈ range i, δ j / adaEta α * zv j ℓ) :=
    fun i hi => onlineState_weight_eq A z.1 z.2 hi hrm hη.ne'
  have hz : ∀ i < k, ∀ ℓ, zv i ℓ ∈ Set.Icc (0 : ℝ) 1 := fun i _ ℓ => qry_mem_Icc A hA h i _
  have hclip' : ∀ i < k, δ i ≠ 0 → |cv i - ∑ ℓ, P i ℓ * zv i ℓ| ≤ adaU0 α := by
    intro i hi h0
    have h0' : (transcript k α β A z.1 z.2 ⟨i, hi⟩).delta m ≠ 0 := by
      have e : δ i = (transcript k α β A z.1 z.2 ⟨i, hi⟩).delta m := by
        simp only [hδdef]
        rw [recAt_eq _ hi]
      rwa [← e]
    have hc : |(transcript k α β A z.1 z.2 ⟨i, hi⟩).c m - (onlineChain k α β A z.1 z.2 i).theta m| ≤
        adaU0 α := hclip ⟨i, hi⟩ h0'
    have hθ : ∑ ℓ, P i ℓ * zv i ℓ = (onlineChain k α β A z.1 z.2 i).theta m := by
      rw [onlineChain_theta A z.1 z.2 hi.le]
    have ec : cv i = (transcript k α β A z.1 z.2 ⟨i, hi⟩).c m := by
      simp only [hcv]
      rw [recAt_eq _ hi]
    rw [hθ, ec]
    exact hc
  -- the comparator
  set ε := adaEps α m with hεdef
  set f := blockVals k α β A m (fun h => valF α D A h m) z with hf
  set Q := tiltQ ε f with hQdef
  have hεpos : 0 < ε := adaEps_pos hα m
  have hε2 : ε ≤ Real.log 2 / 2 :=
    (adaEps_le_one_twentieth hα hα' (by omega)).trans one_twentieth_le_half_log_two
  have hQ : Q ∈ Opt.cappedSimplex n := tiltQ_mem_cappedSimplex hn hεpos.le hε2 f
  have hKL : Opt.klUnif n Q ≤ ε ^ 2 / 2 := klUnif_tiltQ_le hn ε f
  have hw0 : 0 ≤ adaW α m := by
    unfold adaW
    positivity
  have hwε : adaW α m * ε ^ 2 = 1 := by
    have hne : adaEps α m ≠ 0 := (adaEps_pos hα m).ne'
    rw [hεdef]
    unfold adaW
    field_simp
  have hfloor := validator_floor_of_regret hn hη hw0 hwε δ zv μv cv k hz P hP hclip' Q hQ hKL
  -- the progress functional
  have hprog : 8 * adaW α m * ∑ i ∈ range k, ((-δ i) * (cv i - μv i) - δ i ^ 2 / 8 - |δ i| * adaU0 α) =
      progM α D A h m := by
    unfold progM
    congr 1
    exact sum_range_recAt h (fun r j => (-r.delta m) * (r.c m - popMu D A h j) - r.delta m ^ 2 / 8 -
      |r.delta m| * adaU0 α)
  rw [hprog] at hfloor
  -- `⟨Q, f⟩ = (8 w_m/W̃) ∑_i (-δ_i)(⟨Q, z_i⟩ - μ_i)`
  have hW := adaWmax_pos hα hα' hm2 hmL
  have hgate : 8 * adaW α m / adaWmax α m * ∑ i : Fin k, |-(h i).delta m| ≤ 1 := by
    simp_rw [abs_neg]
    rw [div_mul_eq_mul_div, div_le_one hW]
    exact l1_step_budget hα hα' A z.1 z.2 hm2 hmL
  have hQf : ∑ ℓ, Q ℓ * f ℓ =
      8 * adaW α m / adaWmax α m * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * zv i ℓ - μv i) := by
    have hfl : ∀ ℓ, f ℓ = linTest Finset.univ (8 * adaW α m / adaWmax α m) (fun i => -(h i).delta m)
        (fun i => popMu D A h i) (fun i => qry A h i) (blockOf k α β m z.1 ℓ) := by
      intro ℓ
      simp only [hf, blockVals, valF]
      rw [if_pos hAmz]
    simp_rw [hfl]
    rw [sum_mul_linTest Q (sum_tiltQ hn ε f) (blockOf k α β m z.1) _ _ _ _ hgate]
    congr 1
    rw [← sum_range_recAt h (fun r j => (-r.delta m) * (∑ ℓ, Q ℓ * qry A h j (blockOf k α β m z.1 ℓ) -
      popMu D A h j))]
  have h124 : 124 / adaWmax α m ≤ ∑ ℓ, Q ℓ * f ℓ := by
    rw [hQf, div_le_iff₀ hW]
    have e : 8 * adaW α m / adaWmax α m * (∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * zv i ℓ - μv i)) *
        adaWmax α m = 8 * adaW α m * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * zv i ℓ - μv i) := by
      field_simp
    rw [e]
    linarith [hAmz.2]
  have hZ := (tiltZ_mem_Icc hn hεpos.le f).1
  show 124 * Real.exp (-ε) / adaWmax α m ≤ tiltZ ε f * ∑ ℓ, Q ℓ * f ℓ
  calc 124 * Real.exp (-ε) / adaWmax α m = Real.exp (-ε) * (124 / adaWmax α m) := by ring
    _ ≤ tiltZ ε f * ∑ ℓ, Q ℓ * f ℓ :=
        mul_le_mul hZ h124 (by positivity) (le_trans (Real.exp_pos _).le hZ)


/-! ### Measurability and boundedness of the test functionals and of `Ĝ` -/

omit [MeasurableSpace X] in
/-- `|Z ⟨Q*, f⟩| ≤ e^{ε}` for `f ∈ [-1,1]ⁿ`, `ε ≥ 0`. -/
theorem abs_tilt_le {n : ℕ} {ε : ℝ} (hε : 0 ≤ ε) (f : Fin n → ℝ) (hf : ∀ ℓ, f ℓ ∈ Set.Icc (-1 : ℝ) 1) :
    |tiltZ ε f * ∑ ℓ, tiltQ ε f ℓ * f ℓ| ≤ Real.exp ε := by
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    simp only [Finset.univ_eq_empty, Finset.sum_empty, mul_zero, abs_zero]
    exact (Real.exp_pos ε).le
  · have hZ := tiltZ_mem_Icc hn hε f
    have hZ0 : 0 ≤ tiltZ ε f := (tiltZ_pos hn ε f).le
    have hS : |∑ ℓ, tiltQ ε f ℓ * f ℓ| ≤ 1 := by
      calc |∑ ℓ, tiltQ ε f ℓ * f ℓ| ≤ ∑ ℓ, |tiltQ ε f ℓ * f ℓ| := Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ ℓ, tiltQ ε f ℓ := Finset.sum_le_sum fun ℓ _ => by
            rw [abs_mul, abs_of_pos (tiltQ_pos hn ε f ℓ)]
            exact mul_le_of_le_one_right (tiltQ_pos hn ε f ℓ).le (abs_le.mpr (hf ℓ))
        _ = 1 := sum_tiltQ hn ε f
    rw [abs_mul, abs_of_nonneg hZ0]
    calc tiltZ ε f * |∑ ℓ, tiltQ ε f ℓ * f ℓ| ≤ Real.exp ε * 1 := mul_le_mul hZ.2 hS (abs_nonneg _)
          (Real.exp_pos ε).le
      _ = Real.exp ε := mul_one _

theorem measurable_linTest {Y : Type*} [MeasurableSpace Y] (c : ℝ) (a μ : Y → Fin k → ℝ)
    (q : Fin k → Y → X → ℝ) (ha : ∀ i, Measurable fun y => a y i) (hμ : ∀ i, Measurable fun y => μ y i)
    (hq : ∀ i, Measurable fun p : Y × X => q i p.1 p.2) :
    Measurable fun p : Y × X => linTest Finset.univ c (a p.1) (μ p.1) (fun i => q i p.1) p.2 := by
  unfold linTest
  refine Measurable.ite ?_ ?_ measurable_const
  · exact measurableSet_le (measurable_const.mul (Finset.measurable_sum _ fun i _ =>
      continuous_abs.measurable.comp ((ha i).comp measurable_fst))) measurable_const
  · exact measurable_const.mul (Finset.measurable_sum _ fun i _ =>
      ((ha i).comp measurable_fst).mul ((hq i).sub ((hμ i).comp measurable_fst)))

/-- `F⁽¹⁾` is jointly measurable in `(h, x)`. -/
theorem measurable_stage1F (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) :
    Measurable (Function.uncurry fun (h : Fin k → RoundRec) (x : X) => stage1F α D A h x) := by
  have hlin := measurable_linTest (Y := Fin k → RoundRec) (1 / (adaEta1 α * adaT1max α))
    (fun h i => -(h i).delta 1) (fun h i => popMu D A h i) (fun i h x => qry A h i x)
    (fun i => (delta_measurable i 1).neg) (fun i => popMu_measurable D A hAm i)
    (fun i => qry_measurable A hAm i)
  have hset : MeasurableSet {p : (Fin k → RoundRec) × X | finalT1 p.1 = adaT1max α} :=
    (measurable_finalT1.comp measurable_fst) (measurableSet_singleton _)
  unfold stage1F
  exact Measurable.ite hset hlin measurable_const

/-- `F^{(m)}` is jointly measurable in `(h, x)`. -/
theorem measurable_valF (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) (m : ℕ) :
    Measurable (Function.uncurry fun (h : Fin k → RoundRec) (x : X) => valF α D A h m x) := by
  classical
  have hlin := measurable_linTest (Y := Fin k → RoundRec) (8 * adaW α m / adaWmax α m)
    (fun h i => -(h i).delta m) (fun h i => popMu D A h i) (fun i h x => qry A h i x)
    (fun i => (delta_measurable i m).neg) (fun i => popMu_measurable D A hAm i)
    (fun i => qry_measurable A hAm i)
  have hset : MeasurableSet {p : (Fin k → RoundRec) × X | AmEvent α D A p.1 m} :=
    measurable_fst (measurableSet_AmEvent D A hAm m)
  unfold valF
  exact Measurable.ite hset hlin measurable_const

theorem measurable_blockVals (A : DetAnalyst X) (hAm : A.JointlyMeasurable) {F : (Fin k → RoundRec) → X → ℝ}
    (hF : Measurable (Function.uncurry F)) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    Measurable fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α => blockVals k α β A r F z ℓ :=
  hF.comp ((measurable_transcript A hAm).prodMk
    ((measurable_pi_apply (adaBlockIdx k α β r ℓ)).comp measurable_fst))

/-- `Ĝ_r` is a measurable function of `(S, ω)`. -/
theorem measurable_tiltG (A : DetAnalyst X) (hAm : A.JointlyMeasurable) {F : (Fin k → RoundRec) → X → ℝ}
    (hF : Measurable (Function.uncurry F)) (r : ℕ) (ε : ℝ) :
    Measurable (tiltG k α β A r ε F) := by
  have hb := measurable_blockVals (α := α) (β := β) A hAm hF r
  have hW : ∀ ℓ, Measurable fun z => tiltW ε (blockVals k α β A r F z) ℓ := fun ℓ => by
    unfold tiltW
    exact Measurable.ite (measurableSet_le measurable_const (hb ℓ)) measurable_const measurable_const
  have hZ : Measurable fun z => tiltZ ε (blockVals k α β A r F z) := by
    unfold tiltZ
    exact measurable_const.mul (Finset.measurable_sum _ fun ℓ _ => hW ℓ)
  unfold tiltG tiltQ
  exact hZ.mul (Finset.measurable_sum _ fun ℓ _ => ((hW ℓ).div (measurable_const.mul hZ)).mul (hb ℓ))

end

end F2e2e.A
