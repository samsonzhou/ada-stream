import F2e2e.A.SpecV2BridgeRound
import F2e2e.Lib.Dist.BetaBridge
import F2e2e.A.NumericsBasic

/-!
# Spec v2 (A) bridge, part 2: the coin laws (A-ACC draft)

* `measurable_coinMap`;
* `laplaceLaw_eq`: v2's `laplaceLaw b` is the library's `laplace b` (`b > 0`);
* `stage1Law_map`: `ξ ↦ ξ / R₁` pushes v2's Stage-1 law `R₁(2·Beta(p₁,p₁) - 1)` to `betaSym (p₁ - 1)`;
* `map_coinMap`: **`φ_* adaCoinLaw = adaNoiseMeasure`**;
* `ae_good`: `Good` (`|ξ_i| < R₁` for all `i`) holds `adaCoinLaw`-almost surely.
-/

namespace F2e2e.A.V2Bridge

open MeasureTheory ProbabilityTheory

noncomputable section

variable {k : ℕ} {α β : ℝ}

theorem measurable_coinMap : Measurable (coinMap k α) := by
  apply measurable_pi_lambda
  intro j
  cases j with
  | beta i => exact (measurable_pi_apply _).div_const _
  | nu i r => exact measurable_pi_apply _
  | zeta i r => exact measurable_pi_apply _
  | rho r e => exact measurable_pi_apply _

theorem laplaceLaw_eq {b : ℝ} (hb : 0 < b) : F2e2e.laplaceLaw b = laplace b := by
  unfold F2e2e.laplaceLaw laplace
  rw [if_pos hb]
  rfl

theorem one_le_adaP1 (α β : ℝ) : 1 ≤ adaP1 α β := by
  unfold adaP1
  split_ifs <;> omega

theorem adaR1_pos (hα : 0 < α) : 0 < adaR1 α := by
  unfold adaR1
  positivity

/-- `ξ ↦ ξ / R₁` maps the v2 Stage-1 law `R₁(2B - 1)`, `B ∼ Beta(p₁, p₁)`, to A-ARCH's `betaSym (p₁ - 1)`. -/
theorem stage1Law_map (hα : 0 < α) :
    (F2e2e.adaStage1Law α β).map (fun x => x / adaR1 α) = Dist.betaSym (adaBetaM α β) := by
  have hR : adaR1 α ≠ 0 := (adaR1_pos hα).ne'
  have hm1 : Measurable (fun x : ℝ => x / adaR1 α) := by fun_prop
  have hm2 : Measurable (fun v : ℝ => F2e2e.adaR1 α * (2 * v - 1)) := by fun_prop
  unfold F2e2e.adaStage1Law
  rw [Measure.map_map hm1 hm2]
  have e : (fun x => x / adaR1 α) ∘ (fun v => F2e2e.adaR1 α * (2 * v - 1)) = fun v => 2 * v - 1 := by
    funext v
    show adaR1 α * (2 * v - 1) / adaR1 α = 2 * v - 1
    field_simp
  rw [e]
  exact Dist.map_two_mul_sub_one_betaMeasure (one_le_adaP1 α β)

theorem isProbabilityMeasure_stage1Law (α β : ℝ) : IsProbabilityMeasure (F2e2e.adaStage1Law α β) := by
  unfold F2e2e.adaStage1Law
  have : IsProbabilityMeasure (betaMeasure (F2e2e.adaP1 α β : ℝ) (F2e2e.adaP1 α β : ℝ)) :=
    Dist.isProbabilityMeasure_betaMeasure_nat (one_le_adaP1 α β)
  exact Measure.isProbabilityMeasure_map (Measurable.aemeasurable (by fun_prop))

/-- Every factor of v2's coin law is a probability measure (under the standing hypotheses, which make
`b_SVT > 0`). -/
theorem isProbabilityMeasure_adaNoiseLaw' (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (j : Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
      (Fin (F2e2e.adaL α + 1) × Fin (k + 1))) :
    IsProbabilityMeasure (F2e2e.adaNoiseLaw k α β j) := by
  have hb : 0 < F2e2e.adaBsvt k α β := adaBsvt_pos hα hα' hβ hβ' hk
  rcases j with i | p | p | p
  · exact isProbabilityMeasure_stage1Law α β
  · show IsProbabilityMeasure (F2e2e.laplaceLaw (2 * F2e2e.adaBsvt k α β))
    rw [laplaceLaw_eq (show 0 < 2 * F2e2e.adaBsvt k α β by linarith)]
    infer_instance
  · show IsProbabilityMeasure (F2e2e.laplaceLaw (F2e2e.adaBsvt k α β))
    rw [laplaceLaw_eq hb]
    infer_instance
  · show IsProbabilityMeasure (F2e2e.laplaceLaw (F2e2e.adaBsvt k α β))
    rw [laplaceLaw_eq hb]
    infer_instance

/-- The box preimage under the coin map. -/
def sPre (s : NoiseIdx k (adaL α) → Set ℝ) : Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
    (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin (F2e2e.adaL α + 1) × Fin (k + 1)) → Set ℝ
  | Sum.inl i => (fun x => x / adaR1 α) ⁻¹' s (.beta i)
  | Sum.inr (Sum.inl p) => s (.nu p.1 p.2)
  | Sum.inr (Sum.inr (Sum.inl p)) => s (.zeta p.1 p.2)
  | Sum.inr (Sum.inr (Sum.inr p)) => s (.rho p.1 p.2)

theorem coinMap_preimage_pi (s : NoiseIdx k (adaL α) → Set ℝ) :
    coinMap k α ⁻¹' Set.univ.pi s = Set.univ.pi (sPre s) := by
  ext ω
  constructor
  · intro h j _
    rcases j with i | p | p | p
    · exact h (.beta i) (Set.mem_univ _)
    · exact h (.nu p.1 p.2) (Set.mem_univ _)
    · exact h (.zeta p.1 p.2) (Set.mem_univ _)
    · exact h (.rho p.1 p.2) (Set.mem_univ _)
  · intro h j _
    cases j with
    | beta i => exact h (Sum.inl i) (Set.mem_univ _)
    | nu i r => exact h (Sum.inr (Sum.inl (i, r))) (Set.mem_univ _)
    | zeta i r => exact h (Sum.inr (Sum.inr (Sum.inl (i, r)))) (Set.mem_univ _)
    | rho r e => exact h (Sum.inr (Sum.inr (Sum.inr (r, e)))) (Set.mem_univ _)

/-- **The coin laws.** The coin map pushes v2's `adaCoinLaw` to A-ARCH's `adaNoiseMeasure`. -/
theorem map_coinMap (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    (F2e2e.adaCoinLaw k α β).map (coinMap k α) = adaNoiseMeasure k α β := by
  have hb : 0 < adaBsvt k α β := adaBsvt_pos hα hα' hβ hβ' hk
  have hP := isProbabilityMeasure_adaNoiseLaw' hk hα hα' hβ hβ'
  have hσ : ∀ j : Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
      (Fin (F2e2e.adaL α + 1) × Fin (k + 1)), SigmaFinite (F2e2e.adaNoiseLaw k α β j) := fun j => by
    have := hP j
    infer_instance
  symm
  refine Measure.pi_eq fun s hs => ?_
  rw [Measure.map_apply measurable_coinMap (MeasurableSet.univ_pi hs), coinMap_preimage_pi]
  unfold F2e2e.adaCoinLaw
  refine (Measure.pi_pi (ι := Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
    (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin (F2e2e.adaL α + 1) × Fin (k + 1)))
    (F2e2e.adaNoiseLaw k α β) (sPre s)).trans ?_
  refine (Fintype.prod_equiv (NoiseIdx.equivSum k (adaL α)) _ _ fun j => ?_).symm
  cases j with
  | beta i =>
    show Dist.betaSym (adaBetaM α β) (s (.beta i)) =
      F2e2e.adaStage1Law α β ((fun x => x / adaR1 α) ⁻¹' s (.beta i))
    rw [← Measure.map_apply (show Measurable (fun x : ℝ => x / adaR1 α) by fun_prop) (hs _),
      stage1Law_map hα]
  | nu i r =>
    show laplace (2 * adaBsvt k α β) (s (.nu i r)) =
      F2e2e.laplaceLaw (2 * F2e2e.adaBsvt k α β) (s (.nu i r))
    rw [laplaceLaw_eq (show 0 < 2 * F2e2e.adaBsvt k α β by rw [adaBsvt_eq]; linarith)]
  | zeta i r =>
    show laplace (adaBsvt k α β) (s (.zeta i r)) = F2e2e.laplaceLaw (F2e2e.adaBsvt k α β) (s (.zeta i r))
    rw [laplaceLaw_eq (show 0 < F2e2e.adaBsvt k α β from hb)]
  | rho r e =>
    show laplace (adaBsvt k α β) (s (.rho r e)) = F2e2e.laplaceLaw (F2e2e.adaBsvt k α β) (s (.rho r e))
    rw [laplaceLaw_eq (show 0 < F2e2e.adaBsvt k α β from hb)]

/-- `Good` holds almost surely under v2's coin law. -/
theorem ae_good (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    ∀ᵐ ω ∂(F2e2e.adaCoinLaw k α β), Good ω := by
  have := isProbabilityMeasure_adaNoiseLaw' hk hα hα' hβ hβ'
  unfold Good
  rw [ae_all_iff]
  intro i
  have hmp := measurePreserving_eval (ι := Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
    (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin (F2e2e.adaL α + 1) × Fin (k + 1)))
    (F2e2e.adaNoiseLaw k α β) (Sum.inl i)
  exact hmp.quasiMeasurePreserving.ae (Dist.ae_abs_lt_map_scaled_betaMeasure (adaR1_pos hα) _ _)

theorem measure_not_good (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) :
    F2e2e.adaCoinLaw k α β {ω | ¬ Good ω} = 0 :=
  ae_iff.mp (ae_good hk hα hα' hβ hβ')

end

end F2e2e.A.V2Bridge
