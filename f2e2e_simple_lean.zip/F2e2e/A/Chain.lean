import F2e2e.A.ArchDefs

/-!
# Part I: the first-trigger chain semantics ([CHAIN]) and the run invariants (Remark I.1.9)

Paper: `parts/partI.tex` Definition `I:def:mechanism` Step 2-3 (L328-392), Remark
`I:rem:halt_round_completion` (L395-417), Lemma `I:lem:validator_episode_conservation` (i)-(iii)
(L825-874, the deterministic bookkeeping), and the reduction of the interaction to the run on the analyst's
query values (Lemma `I:lem:tonelli_fubini`(ii)).

## [CHAIN] (about one round's `ChainData`)
* the origin before stage `r` is `1` or a triggered stage `< r` (`orig_spec`, `uprev_lt`), with the
  proposal `c₁` resp. `relC u` (`cprev_of_uprev_eq_one`, `cprev_of_two_le_uprev`);
* every triggered stage is `≤ u_final` (`le_ufinal_of_trig`), `1 ≤ u_final ≤ L`;
* Case 0 / A / B characterizations: `ufinal_eq_one_iff`, `answer_of_ufinal_eq_one`, `trig_ufinal`,
  `answer_of_two_le_ufinal`, `fires_ufinal`;
* all stages above `u_final` were tested on `(u_final, a_i)` and passed (`orig_above_ufinal`,
  `not_fires_above_ufinal`);
* the predecessor `r - 1` of a trigger `r` with `u_prev(r) < r - 1` was tested on the same proposal and
  passed (`pred_pass`);
* conventions: `clip01_mem`, `clip01_of_mem`, `abs_clip01_sub_le`, `sgn1_mul_self`, `abs_sgn1`.
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## `clip` and `sign` -/

theorem clip01_mem (x : ℝ) : clip01 x ∈ Set.Icc (0 : ℝ) 1 := by
  unfold clip01
  constructor
  · exact le_min zero_le_one (le_max_left _ _)
  · exact min_le_left _ _

theorem clip01_of_mem {x : ℝ} (hx : x ∈ Set.Icc (0 : ℝ) 1) : clip01 x = x := by
  unfold clip01
  rw [max_eq_right hx.1, min_eq_right hx.2]

/-- `clip(·, [0,1])` is `1`-Lipschitz and fixes `[0,1]`: `|clip(x) - y| ≤ |x - y|` for `y ∈ [0,1]`. -/
theorem abs_clip01_sub_le (x : ℝ) {y : ℝ} (hy : y ∈ Set.Icc (0 : ℝ) 1) :
    |clip01 x - y| ≤ |x - y| := by
  unfold clip01
  obtain ⟨hy0, hy1⟩ := hy
  rcases le_total x 0 with h0 | h0
  · rw [max_eq_left h0, min_eq_right zero_le_one, abs_of_nonpos (by linarith),
      abs_of_nonpos (by linarith)]
    linarith
  · rw [max_eq_right h0]
    rcases le_total x 1 with h1 | h1
    · rw [min_eq_right h1]
    · rw [min_eq_left h1, abs_of_nonneg (by linarith), abs_of_nonneg (by linarith)]
      linarith

theorem sgn1_mul_self (x : ℝ) : sgn1 x * x = |x| := by
  unfold sgn1
  split_ifs with h
  · rw [one_mul, abs_of_nonneg h]
  · rw [abs_of_neg (lt_of_not_ge h)]
    ring

theorem abs_sgn1 (x : ℝ) : |sgn1 x| = 1 := by
  unfold sgn1
  split_ifs <;> simp

theorem sgn1_sq (x : ℝ) : sgn1 x ^ 2 = 1 := by
  unfold sgn1
  split_ifs <;> norm_num

/-! ## The chain of one round -/

namespace ChainData

variable (d : ChainData)

theorem orig_zero : d.orig 0 = (1, d.c1) := rfl

theorem orig_succ_of_trig {r : ℕ} (h : d.Trig r) : d.orig (r + 1) = (r, d.relC r) := by
  show (if 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2 then (r, d.relC r)
    else d.orig r) = _
  exact if_pos h

theorem orig_succ_of_not_trig {r : ℕ} (h : ¬ d.Trig r) : d.orig (r + 1) = d.orig r := by
  show (if 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2 then (r, d.relC r)
    else d.orig r) = _
  exact if_neg h

theorem not_trig_of_lt_two {r : ℕ} (hr : r < 2) : ¬ d.Trig r := fun h => by
  have := h.1
  omega

theorem not_trig_of_gt_L {r : ℕ} (hr : d.L < r) : ¬ d.Trig r := fun h => by
  have := h.2.1
  omega

theorem two_le_of_trig {r : ℕ} (h : d.Trig r) : 2 ≤ r := h.1

theorem le_L_of_trig {r : ℕ} (h : d.Trig r) : r ≤ d.L := h.2.1

theorem fires_of_trig {r : ℕ} (h : d.Trig r) : d.Fires r (d.uprev r) (d.cprev r) := h.2.2

/-- A stage `2 ≤ r ≤ L` that does not trigger was tested on `(u_prev(r), c^{(u_prev(r))})` and passed. -/
theorem not_fires_of_not_trig {r : ℕ} (h2 : 2 ≤ r) (hL : r ≤ d.L) (h : ¬ d.Trig r) :
    ¬ d.Fires r (d.uprev r) (d.cprev r) := fun hf => h ⟨h2, hL, hf⟩

theorem orig_of_le_two {r : ℕ} (hr : r ≤ 2) : d.orig r = (1, d.c1) := by
  induction r with
  | zero => rfl
  | succ r ih =>
    rw [d.orig_succ_of_not_trig (d.not_trig_of_lt_two (by omega))]
    exact ih (by omega)

/-- The origin before stage `r` is `1` (proposal `c₁`) or a stage `u < r` that triggered (proposal
`c^{(u)} = relC u`). -/
theorem orig_spec (r : ℕ) :
    ((d.orig r).1 = 1 ∧ (d.orig r).2 = d.c1) ∨
      (d.Trig (d.orig r).1 ∧ (d.orig r).1 < r ∧ (d.orig r).2 = d.relC (d.orig r).1) := by
  induction r with
  | zero => exact Or.inl ⟨rfl, rfl⟩
  | succ r ih =>
    by_cases h : d.Trig r
    · rw [d.orig_succ_of_trig h]
      exact Or.inr ⟨h, Nat.lt_succ_self r, rfl⟩
    · rw [d.orig_succ_of_not_trig h]
      rcases ih with h1 | ⟨h1, h2, h3⟩
      · exact Or.inl h1
      · exact Or.inr ⟨h1, by omega, h3⟩

theorem one_le_orig_fst (r : ℕ) : 1 ≤ (d.orig r).1 := by
  rcases d.orig_spec r with ⟨h1, -⟩ | ⟨h1, -, -⟩
  · rw [h1]
  · exact le_trans (by norm_num) h1.1

theorem one_le_uprev (r : ℕ) : 1 ≤ d.uprev r := d.one_le_orig_fst r

theorem uprev_lt {r : ℕ} (hr : 2 ≤ r) : d.uprev r < r := by
  unfold uprev
  rcases d.orig_spec r with ⟨h1, -⟩ | ⟨-, h2, -⟩
  · rw [h1]
    omega
  · exact h2

theorem cprev_of_uprev_eq_one {r : ℕ} (h : d.uprev r = 1) : d.cprev r = d.c1 := by
  unfold uprev at h
  unfold cprev
  rcases d.orig_spec r with ⟨-, h2⟩ | ⟨h1, -, -⟩
  · exact h2
  · rw [h] at h1
    exact absurd h1.1 (by norm_num)

theorem cprev_of_two_le_uprev {r : ℕ} (h : 2 ≤ d.uprev r) :
    d.cprev r = d.relC (d.uprev r) ∧ d.Trig (d.uprev r) := by
  unfold uprev at h ⊢
  unfold cprev
  rcases d.orig_spec r with ⟨h1, -⟩ | ⟨h1, -, h3⟩
  · rw [h1] at h
    omega
  · exact ⟨h3, h1⟩

theorem orig_fst_le_succ (r : ℕ) : (d.orig r).1 ≤ (d.orig (r + 1)).1 := by
  by_cases h : d.Trig r
  · rw [d.orig_succ_of_trig h]
    rcases d.orig_spec r with ⟨h1, -⟩ | ⟨-, h2, -⟩
    · rw [h1]
      exact le_trans (by norm_num) h.1
    · exact h2.le
  · rw [d.orig_succ_of_not_trig h]

theorem orig_fst_mono {r s : ℕ} (h : r ≤ s) : (d.orig r).1 ≤ (d.orig s).1 := by
  induction h with
  | refl => exact le_rfl
  | step _ ih => exact le_trans ih (d.orig_fst_le_succ _)

/-- If no stage in `[r, s)` triggers, the origin does not move between `r` and `s`. -/
theorem orig_eq_of_no_trig {r s : ℕ} (hrs : r ≤ s) (h : ∀ t, r ≤ t → t < s → ¬ d.Trig t) :
    d.orig s = d.orig r := by
  induction hrs with
  | refl => rfl
  | step hle ih =>
    rw [d.orig_succ_of_not_trig (h _ hle (Nat.lt_succ_self _))]
    exact ih fun t ht1 ht2 => h t ht1 (by omega)

/-- Every stage that triggers is at most `u_final` (the origin never decreases). -/
theorem le_ufinal_of_trig {s : ℕ} (h : d.Trig s) : s ≤ d.ufinal := by
  have hmono := d.orig_fst_mono (show s + 1 ≤ d.L + 1 by have := h.2.1; omega)
  rw [d.orig_succ_of_trig h] at hmono
  exact hmono

theorem one_le_ufinal : 1 ≤ d.ufinal := d.one_le_orig_fst _

theorem ufinal_le_L (hL : 1 ≤ d.L) : d.ufinal ≤ d.L := by
  unfold ufinal
  rcases d.orig_spec (d.L + 1) with ⟨h1, -⟩ | ⟨-, h2, -⟩
  · rw [h1]
    exact hL
  · omega

/-- **Case 0**: `u_final = 1` iff no stage triggers. -/
theorem ufinal_eq_one_iff : d.ufinal = 1 ↔ ∀ r, ¬ d.Trig r := by
  constructor
  · intro h r hr
    have := d.le_ufinal_of_trig hr
    have := hr.1
    omega
  · intro h
    unfold ufinal
    rw [d.orig_eq_of_no_trig (Nat.zero_le _) fun t _ _ => h t]
    rfl

theorem answer_of_ufinal_eq_one (h : d.ufinal = 1) : d.answer = d.c1 := by
  unfold ufinal at h
  unfold answer
  rcases d.orig_spec (d.L + 1) with ⟨-, h2⟩ | ⟨h1, -, -⟩
  · exact h2
  · rw [h] at h1
    exact absurd h1.1 (by norm_num)

/-- **Cases A/B**: if `u_final ≥ 2`, stage `u_final` triggered and the answer is its release. -/
theorem trig_ufinal (h : 2 ≤ d.ufinal) : d.Trig d.ufinal := by
  unfold ufinal at h ⊢
  rcases d.orig_spec (d.L + 1) with ⟨h1, -⟩ | ⟨h1, -, -⟩
  · rw [h1] at h
    omega
  · exact h1

theorem answer_of_two_le_ufinal (h : 2 ≤ d.ufinal) : d.answer = d.relC d.ufinal := by
  unfold ufinal at h ⊢
  unfold answer
  rcases d.orig_spec (d.L + 1) with ⟨h1, -⟩ | ⟨-, -, h3⟩
  · rw [h1] at h
    omega
  · exact h3

theorem fires_ufinal (h : 2 ≤ d.ufinal) :
    d.Fires d.ufinal (d.uprev d.ufinal) (d.cprev d.ufinal) :=
  d.fires_of_trig (d.trig_ufinal h)

/-- Above `u_final` nothing triggers, so the origin stays `(u_final, a_i)`. -/
theorem orig_above_ufinal {s : ℕ} (h1 : d.ufinal < s) (h2 : s ≤ d.L + 1) :
    d.orig s = (d.ufinal, d.answer) := by
  have : d.orig (d.L + 1) = d.orig s := by
    apply d.orig_eq_of_no_trig h2
    intro t hst _ hT
    have := d.le_ufinal_of_trig hT
    omega
  rw [← this]
  rfl

/-- Every stage `u_final < s ≤ L` was tested on the final proposal `a_i = c^{(u_final)}` and passed. -/
theorem not_fires_above_ufinal {s : ℕ} (h1 : d.ufinal < s) (h2 : s ≤ d.L) :
    ¬ d.Fires s d.ufinal d.answer := by
  intro hF
  have ho := d.orig_above_ufinal h1 (by omega)
  have h1' := d.one_le_ufinal
  have hT : d.Trig s := ⟨by omega, h2, by rw [ho]; exact hF⟩
  have := d.le_ufinal_of_trig hT
  omega

/-- **Predecessor pass** (used for the retroactive release): if stage `r ≥ 3` was tested on a proposal from
an origin `u_prev(r) < r - 1`, then stage `r - 1` did not trigger, was tested on the same proposal, and
passed. -/
theorem pred_pass {r : ℕ} (hr : 3 ≤ r) (hrL : r ≤ d.L + 1) (h : d.uprev r < r - 1) :
    d.orig (r - 1) = d.orig r ∧ ¬ d.Trig (r - 1) ∧ ¬ d.Fires (r - 1) (d.uprev r) (d.cprev r) := by
  have hr' : r = (r - 1) + 1 := by omega
  have hnt : ¬ d.Trig (r - 1) := by
    intro hT
    have := d.orig_succ_of_trig hT
    rw [← hr'] at this
    unfold uprev at h
    rw [this] at h
    simp at h
  have heq : d.orig (r - 1) = d.orig r := by
    have := d.orig_succ_of_not_trig hnt
    rw [← hr'] at this
    exact this.symm
  refine ⟨heq, hnt, ?_⟩
  have hnf := d.not_fires_of_not_trig (by omega) (by omega) hnt
  unfold uprev cprev at hnf ⊢
  rw [heq] at hnf
  exact hnf

theorem relC_mem (r : ℕ) : d.relC r ∈ Set.Icc (0 : ℝ) 1 := clip01_mem _

theorem cprev_mem (hc1 : d.c1 ∈ Set.Icc (0 : ℝ) 1) (r : ℕ) : d.cprev r ∈ Set.Icc (0 : ℝ) 1 := by
  unfold cprev
  rcases d.orig_spec r with ⟨-, h2⟩ | ⟨-, -, h3⟩
  · rw [h2]
    exact hc1
  · rw [h3]
    exact d.relC_mem _

theorem answer_mem (hc1 : d.c1 ∈ Set.Icc (0 : ℝ) 1) : d.answer ∈ Set.Icc (0 : ℝ) 1 :=
  d.cprev_mem hc1 (d.L + 1)

end ChainData

/-! ## The run: one round at a time -/

section Run

variable {k : ℕ} {α β : ℝ}

@[simp] theorem RoundRec.halted_ufinal : RoundRec.halted.ufinal = 0 := rfl

@[simp] theorem RoundRec.halted_delta (m : ℕ) : RoundRec.halted.delta m = 0 := rfl

@[simp] theorem RoundRec.halted_active : RoundRec.halted.active = false := rfl

@[simp] theorem RoundRec.halted_answer : RoundRec.halted.answer = 0 := rfl

@[simp] theorem activeRec_active (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : (activeRec st i q ω).active = true := rfl

theorem activeRec_ufinal (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : (activeRec st i q ω).ufinal = (roundChain st i q ω).ufinal := rfl

theorem roundChain_L (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : (roundChain st i q ω).L = adaL α := rfl

theorem activeRec_ufinal_le (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : (activeRec st i q ω).ufinal ≤ adaL α := by
  rw [activeRec_ufinal]
  have h4 := adaL_ge_four α
  have := (roundChain st i q ω).ufinal_le_L (by rw [roundChain_L]; omega)
  rwa [roundChain_L] at this

theorem step_of_halt {st : MState k α β} (h : st.halt = true) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) :
    step st i q ω = (st, RoundRec.halted) := by
  unfold step
  rw [if_pos h]

theorem step_of_not_halt {st : MState k α β} (h : st.halt = false) (i : ℕ)
    (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) :
    step st i q ω = (st.next q (activeRec st i q ω), activeRec st i q ω) := by
  unfold step
  rw [if_neg (by simp [h])]

variable (qv : ℕ → Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α)

theorem run_zero : run k α β qv ω 0 = MState.init := rfl

theorem run_succ (i : ℕ) : run k α β qv ω (i + 1) = (step (run k α β qv ω i) i (qv i) ω).1 := rfl

theorem roundRec_eq (i : ℕ) : roundRec k α β qv ω i = (step (run k α β qv ω i) i (qv i) ω).2 := rfl

variable {qv ω}

theorem roundRec_of_halt {i : ℕ} (h : (run k α β qv ω i).halt = true) :
    roundRec k α β qv ω i = RoundRec.halted := by
  rw [roundRec_eq, step_of_halt h]

theorem roundRec_of_not_halt {i : ℕ} (h : (run k α β qv ω i).halt = false) :
    roundRec k α β qv ω i = activeRec (run k α β qv ω i) i (qv i) ω := by
  rw [roundRec_eq, step_of_not_halt h]

theorem run_succ_of_halt {i : ℕ} (h : (run k α β qv ω i).halt = true) :
    run k α β qv ω (i + 1) = run k α β qv ω i := by
  rw [run_succ, step_of_halt h]

theorem run_succ_of_not_halt {i : ℕ} (h : (run k α β qv ω i).halt = false) :
    run k α β qv ω (i + 1) = (run k α β qv ω i).next (qv i) (roundRec k α β qv ω i) := by
  rw [run_succ, step_of_not_halt h, roundRec_of_not_halt h]

variable (qv ω)

/-- A round is active iff HALT was not set before it. -/
theorem roundRec_active (i : ℕ) :
    (roundRec k α β qv ω i).active = !(run k α β qv ω i).halt := by
  cases h : (run k α β qv ω i).halt
  · rw [roundRec_of_not_halt h]
    rfl
  · rw [roundRec_of_halt h]
    rfl

theorem roundRec_ufinal_le (i : ℕ) : (roundRec k α β qv ω i).ufinal ≤ adaL α := by
  cases h : (run k α β qv ω i).halt
  · rw [roundRec_of_not_halt h]
    exact activeRec_ufinal_le _ _ _ _
  · rw [roundRec_of_halt h]
    exact Nat.zero_le _

/-! ### One-round updates -/

theorem run_succ_t1 (i : ℕ) : (run k α β qv ω (i + 1)).t1 =
    (run k α β qv ω i).t1 + if (roundRec k α β qv ω i).ufinal = 2 then 1 else 0 := by
  cases h : (run k α β qv ω i).halt
  · rw [run_succ_of_not_halt h]
    rfl
  · rw [run_succ_of_halt h, roundRec_of_halt h]
    simp

theorem run_succ_N (i r : ℕ) : (run k α β qv ω (i + 1)).N r = (run k α β qv ω i).N r +
    if 3 ≤ (roundRec k α β qv ω i).ufinal ∧ r = (roundRec k α β qv ω i).ufinal then 1 else 0 := by
  cases h : (run k α β qv ω i).halt
  · rw [run_succ_of_not_halt h]
    rfl
  · rw [run_succ_of_halt h, roundRec_of_halt h]
    simp

theorem run_succ_M (i r : ℕ) : (run k α β qv ω (i + 1)).M r = (run k α β qv ω i).M r +
    if 2 ≤ r ∧ r ≤ (roundRec k α β qv ω i).ufinal then 1 else 0 := by
  cases h : (run k α β qv ω i).halt
  · rw [run_succ_of_not_halt h]
    rfl
  · rw [run_succ_of_halt h, roundRec_of_halt h, RoundRec.halted_ufinal, if_neg (by omega)]
    exact (add_zero _).symm

theorem run_succ_pay (i r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (run k α β qv ω (i + 1)).pay r ℓ =
      (run k α β qv ω i).pay r ℓ + (roundRec k α β qv ω i).delta r * qv i (adaBlockIdx k α β r ℓ) := by
  cases h : (run k α β qv ω i).halt
  · rw [run_succ_of_not_halt h]
    rfl
  · rw [run_succ_of_halt h, roundRec_of_halt h]
    simp

theorem run_halt_succ {i : ℕ} (h : (run k α β qv ω i).halt = true) :
    (run k α β qv ω (i + 1)).halt = true := by
  rw [run_succ_of_halt h]
  exact h

/-! ### The state as a function of the public records -/

/-- The cumulative payoff of level `r` is `∑_{j<i} δ_{r,j} q_j(S_r)` (public coefficients times queries). -/
theorem run_pay (i r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (run k α β qv ω i).pay r ℓ =
      ∑ j ∈ Finset.range i, (roundRec k α β qv ω j).delta r * qv j (adaBlockIdx k α β r ℓ) := by
  induction i with
  | zero => rfl
  | succ i ih => rw [run_succ_pay, ih, Finset.sum_range_succ]

/-- `t₁` counts the Case-A rounds. -/
theorem run_t1 (i : ℕ) : (run k α β qv ω i).t1 =
    ∑ j ∈ Finset.range i, if (roundRec k α β qv ω j).ufinal = 2 then 1 else 0 := by
  induction i with
  | zero => rfl
  | succ i ih => rw [run_succ_t1, ih, Finset.sum_range_succ]

/-- `N_r` counts the Case-B rounds with `u_final = r`. -/
theorem run_N (i r : ℕ) : (run k α β qv ω i).N r = ∑ j ∈ Finset.range i,
    if 3 ≤ (roundRec k α β qv ω j).ufinal ∧ r = (roundRec k α β qv ω j).ufinal then 1 else 0 := by
  induction i with
  | zero => rfl
  | succ i ih => rw [run_succ_N, ih, Finset.sum_range_succ]

/-- `M_r = 1 + ` the number of rounds at whose end stage `r` reset its episode. -/
theorem run_M (i r : ℕ) : (run k α β qv ω i).M r = 1 + ∑ j ∈ Finset.range i,
    if 2 ≤ r ∧ r ≤ (roundRec k α β qv ω j).ufinal then 1 else 0 := by
  induction i with
  | zero => rfl
  | succ i ih => rw [run_succ_M, ih, Finset.sum_range_succ, add_assoc]

theorem run_t1_mono {i j : ℕ} (h : i ≤ j) : (run k α β qv ω i).t1 ≤ (run k α β qv ω j).t1 := by
  induction h with
  | refl => exact le_rfl
  | step _ ih => exact le_trans ih (by rw [run_succ_t1]; exact Nat.le_add_right _ _)

theorem run_N_mono {i j : ℕ} (h : i ≤ j) (r : ℕ) : (run k α β qv ω i).N r ≤ (run k α β qv ω j).N r := by
  induction h with
  | refl => exact le_rfl
  | step _ ih => exact le_trans ih (by rw [run_succ_N]; exact Nat.le_add_right _ _)

/-! ### Remark `I:rem:halt_round_completion` (3): zero overshoot; episode conservation -/

theorem one_le_adaT1max {α : ℝ} (hα : 0 < α) : 1 ≤ adaT1max α := by
  unfold adaT1max
  exact Nat.ceil_pos.mpr (by positivity)

theorem one_le_adaNmax {α : ℝ} (hα : 0 < α) (r : ℕ) : 1 ≤ adaNmax α r := by
  unfold adaNmax
  apply Nat.ceil_pos.mpr
  have hL : (0 : ℝ) < adaL α := by
    have := adaL_ge_four α
    exact_mod_cast (show 0 < adaL α by omega)
  have he : 0 < adaEps α (r - 1) := by
    unfold adaEps
    exact mul_pos (by norm_num) (Real.rpow_pos_of_pos hα _)
  have hg : 0 < adaGamma α := by
    unfold adaGamma
    positivity
  exact div_pos (mul_pos (mul_pos (by norm_num) hL) (pow_pos he 2)) (pow_pos hg 2)

/-- The counters never exceed their caps, and HALT is set as soon as one reaches its cap (Remark
`I:rem:halt_round_completion`(3), eq. `I:eq:det_counter_caps`; Lemma `I:lem:validator_episode_conservation`(i)). -/
theorem run_caps (hα : 0 < α) (i : ℕ) :
    ((run k α β qv ω i).t1 ≤ adaT1max α ∧
      ((run k α β qv ω i).t1 = adaT1max α → (run k α β qv ω i).halt = true)) ∧
    ∀ r, (3 ≤ r ∧ r ≤ adaL α → (run k α β qv ω i).N r ≤ adaNmax α r ∧
        ((run k α β qv ω i).N r = adaNmax α r → (run k α β qv ω i).halt = true)) ∧
      (¬ (3 ≤ r ∧ r ≤ adaL α) → (run k α β qv ω i).N r = 0) := by
  have hT := one_le_adaT1max hα
  have hN := one_le_adaNmax hα
  induction i with
  | zero =>
    refine ⟨⟨Nat.zero_le _, fun h => ?_⟩, fun r => ⟨fun _ => ⟨Nat.zero_le _, fun h => ?_⟩, fun _ => rfl⟩⟩
    · change 0 = adaT1max α at h
      omega
    · change 0 = adaNmax α r at h
      have := hN r
      omega
  | succ i ih =>
    obtain ⟨⟨ht1, ht1h⟩, hNr⟩ := ih
    cases hh : (run k α β qv ω i).halt with
    | true =>
      rw [run_succ_of_halt hh]
      exact ⟨⟨ht1, ht1h⟩, hNr⟩
    | false =>
      have hlt : (run k α β qv ω i).t1 < adaT1max α := by
        refine lt_of_le_of_ne ht1 fun h => ?_
        have := ht1h h
        rw [hh] at this
        exact absurd this (by decide)
      have hNlt : ∀ r, 3 ≤ r → r ≤ adaL α → (run k α β qv ω i).N r < adaNmax α r := by
        intro r h3 hL
        obtain ⟨hle, hcap⟩ := (hNr r).1 ⟨h3, hL⟩
        refine lt_of_le_of_ne hle fun h => ?_
        have := hcap h
        rw [hh] at this
        exact absurd this (by decide)
      have hu := roundRec_ufinal_le qv ω i
      rw [run_succ_of_not_halt hh]
      refine ⟨⟨?_, ?_⟩, fun r => ⟨fun hr => ⟨?_, ?_⟩, fun hr => ?_⟩⟩
      · show (run k α β qv ω i).t1 + (if (roundRec k α β qv ω i).ufinal = 2 then 1 else 0) ≤ _
        split_ifs <;> omega
      · intro h
        change (run k α β qv ω i).t1 + (if (roundRec k α β qv ω i).ufinal = 2 then 1 else 0) =
          adaT1max α at h
        show decide _ = true
        split_ifs at h with hu2
        · exact decide_eq_true (Or.inl ⟨hu2, h⟩)
        · omega
      · show (run k α β qv ω i).N r + (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧
          r = (roundRec k α β qv ω i).ufinal then 1 else 0) ≤ _
        have := hNlt r hr.1 hr.2
        split_ifs <;> omega
      · intro h
        change (run k α β qv ω i).N r + (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧
          r = (roundRec k α β qv ω i).ufinal then 1 else 0) = adaNmax α r at h
        show decide _ = true
        have := hNlt r hr.1 hr.2
        split_ifs at h with hur
        · obtain ⟨hu3, rfl⟩ := hur
          exact decide_eq_true (Or.inr ⟨hu3, h⟩)
        · omega
      · show (run k α β qv ω i).N r + (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧
          r = (roundRec k α β qv ω i).ufinal then 1 else 0) = 0
        rw [(hNr r).2 hr]
        split_ifs with hur
        · exact absurd ⟨hur.2 ▸ hur.1, hur.2 ▸ hu⟩ hr
        · rfl

theorem run_t1_le (hα : 0 < α) (i : ℕ) : (run k α β qv ω i).t1 ≤ adaT1max α :=
  (run_caps qv ω hα i).1.1

theorem run_N_le (hα : 0 < α) (i r : ℕ) : (run k α β qv ω i).N r ≤ adaNmax α r := by
  by_cases hr : 3 ≤ r ∧ r ≤ adaL α
  · exact ((run_caps qv ω hα i).2 r).1 hr |>.1
  · rw [((run_caps qv ω hα i).2 r).2 hr]
    exact Nat.zero_le _

/-- HALT is only set when a counter reaches its cap. -/
theorem run_halt_cap (i : ℕ) (h : (run k α β qv ω i).halt = true) :
    (run k α β qv ω i).t1 = adaT1max α ∨
      ∃ r, 3 ≤ r ∧ r ≤ adaL α ∧ (run k α β qv ω i).N r = adaNmax α r := by
  induction i with
  | zero =>
    change false = true at h
    exact absurd h (by decide)
  | succ i ih =>
    cases hh : (run k α β qv ω i).halt with
    | true =>
      rw [run_succ_of_halt hh] at h ⊢
      exact ih h
    | false =>
      have hu := roundRec_ufinal_le qv ω i
      rw [run_succ_of_not_halt hh] at h ⊢
      change decide _ = true at h
      rcases of_decide_eq_true h with ⟨hu2, ht⟩ | ⟨hu3, hNc⟩
      · left
        show (run k α β qv ω i).t1 + (if (roundRec k α β qv ω i).ufinal = 2 then 1 else 0) = _
        rw [if_pos hu2, ht]
      · right
        refine ⟨(roundRec k α β qv ω i).ufinal, hu3, hu, ?_⟩
        show (run k α β qv ω i).N _ + (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧
          (roundRec k α β qv ω i).ufinal = (roundRec k α β qv ω i).ufinal then 1 else 0) = _
        rw [if_pos ⟨hu3, rfl⟩, hNc]

/-- If at round `n` no counter has reached its cap, no round `i ≤ n` is halted. -/
theorem run_not_halt_of_caps {n i : ℕ} (hi : i ≤ n) (ht : (run k α β qv ω n).t1 < adaT1max α)
    (hN : ∀ r, 3 ≤ r → r ≤ adaL α → (run k α β qv ω n).N r < adaNmax α r) :
    (run k α β qv ω i).halt = false := by
  cases hh : (run k α β qv ω i).halt with
  | false => rfl
  | true =>
    exfalso
    rcases run_halt_cap qv ω i hh with h1 | ⟨r, h3, hL, hNr⟩
    · have := run_t1_mono qv ω hi
      omega
    · have := run_N_mono qv ω hi r
      have := hN r h3 hL
      omega

/-- **Episode conservation** (Lemma `I:lem:validator_episode_conservation`(iii), eq. `I:eq:M2_conservation`,
as an identity): `M_2 = 1 + t₁ + ∑_{r*=3}^{L} N_{r*}`. -/
theorem run_M_two (i : ℕ) : (run k α β qv ω i).M 2 =
    1 + (run k α β qv ω i).t1 + ∑ s ∈ Finset.Icc 3 (adaL α), (run k α β qv ω i).N s := by
  induction i with
  | zero =>
    simp only [run_zero, MState.init, Finset.sum_const_zero, add_zero]
  | succ i ih =>
    have hu := roundRec_ufinal_le qv ω i
    rw [run_succ_M, run_succ_t1, ih]
    simp only [run_succ_N, Finset.sum_add_distrib]
    have hsum : ∑ s ∈ Finset.Icc 3 (adaL α),
        (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧ s = (roundRec k α β qv ω i).ufinal then 1 else 0) =
        if 3 ≤ (roundRec k α β qv ω i).ufinal then 1 else 0 := by
      by_cases h3 : 3 ≤ (roundRec k α β qv ω i).ufinal
      · simp only [h3, true_and, if_true]
        rw [Finset.sum_ite_eq' (Finset.Icc 3 (adaL α)) ((roundRec k α β qv ω i).ufinal) (fun _ => 1),
          if_pos (Finset.mem_Icc.mpr ⟨h3, hu⟩)]
      · simp [h3]
    rw [hsum]
    split_ifs <;> omega

/-- **Episode conservation** (eq. `I:eq:Mr_conservation`, as an identity): `M_r = 1 + ∑_{r*=r}^{L} N_{r*}`
for `3 ≤ r ≤ L`. -/
theorem run_M_ge_three {r : ℕ} (h3 : 3 ≤ r) (i : ℕ) : (run k α β qv ω i).M r =
    1 + ∑ s ∈ Finset.Icc r (adaL α), (run k α β qv ω i).N s := by
  induction i with
  | zero =>
    simp only [run_zero, MState.init, Finset.sum_const_zero, add_zero]
  | succ i ih =>
    have hu := roundRec_ufinal_le qv ω i
    rw [run_succ_M, ih]
    simp only [run_succ_N, Finset.sum_add_distrib]
    have hsum : ∑ s ∈ Finset.Icc r (adaL α),
        (if 3 ≤ (roundRec k α β qv ω i).ufinal ∧ s = (roundRec k α β qv ω i).ufinal then 1 else 0) =
        if r ≤ (roundRec k α β qv ω i).ufinal then 1 else 0 := by
      by_cases hr : r ≤ (roundRec k α β qv ω i).ufinal
      · have h3' : 3 ≤ (roundRec k α β qv ω i).ufinal := le_trans h3 hr
        simp only [h3', true_and, if_true, hr]
        rw [Finset.sum_ite_eq' (Finset.Icc r (adaL α)) ((roundRec k α β qv ω i).ufinal) (fun _ => 1),
          if_pos (Finset.mem_Icc.mpr ⟨hr, hu⟩)]
      · rw [if_neg hr]
        refine Finset.sum_eq_zero fun s hs => ?_
        rw [Finset.mem_Icc] at hs
        rw [if_neg]
        rintro ⟨-, rfl⟩
        exact hr hs.1
    rw [hsum]
    split_ifs <;> omega

/-- **Intra-episode weight invariance** (Remark `I:rem:halt_round_completion`(2), Lemma
`I:lem:validator_episode_conservation`(ii)): for a validator stage `2 ≤ r`, if the episode counter `M_r`
does not move in round `i`, neither does the payoff (hence the weights) of level `r`. -/
theorem run_pay_eq_of_M_eq {i r : ℕ} (hr : 2 ≤ r)
    (hM : (run k α β qv ω (i + 1)).M r = (run k α β qv ω i).M r) :
    (run k α β qv ω (i + 1)).pay r = (run k α β qv ω i).pay r := by
  funext ℓ
  rw [run_succ_pay]
  rw [run_succ_M] at hM
  have hnot : ¬ r ≤ (roundRec k α β qv ω i).ufinal := by
    intro h
    rw [if_pos ⟨hr, h⟩] at hM
    omega
  suffices (roundRec k α β qv ω i).delta r = 0 by rw [this, zero_mul, add_zero]
  cases hh : (run k α β qv ω i).halt
  · rw [roundRec_of_not_halt hh] at hnot ⊢
    show (roundChain _ i (qv i) ω).delta (adaEta1 α) (adaEta α) (adaEtaTilde α) r = 0
    rw [activeRec_ufinal] at hnot
    unfold ChainData.delta
    split_ifs <;> first | rfl | (exfalso; omega)
  · rw [roundRec_of_halt hh]
    rfl

end Run

/-! ## The interaction with a deterministic analyst -/

section Online

variable {k : ℕ} {α β : ℝ} {X : Type}

theorem run_congr {qv qv' : ℕ → Fin (adaSampleSize k α β) → ℝ} (ω : AdaOmega k α) {i : ℕ}
    (h : ∀ j < i, qv j = qv' j) : run k α β qv ω i = run k α β qv' ω i := by
  induction i with
  | zero => rfl
  | succ i ih =>
    rw [run_succ, run_succ, ih (fun j hj => h j (by omega)), h i (by omega)]

theorem roundRec_congr {qv qv' : ℕ → Fin (adaSampleSize k α β) → ℝ} (ω : AdaOmega k α) {i : ℕ}
    (h : ∀ j ≤ i, qv j = qv' j) : roundRec k α β qv ω i = roundRec k α β qv' ω i := by
  rw [roundRec_eq, roundRec_eq, run_congr ω (fun j hj => h j hj.le), h i le_rfl]

/-- The interaction is the run on the analyst's query values. -/
theorem onlineRun_eq (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (i : ℕ) :
    (onlineRun k α β A S ω i).1 = run k α β (onlineQ k α β A S ω) ω i ∧
      ∀ j : Fin i, (onlineRun k α β A S ω i).2 j = roundRec k α β (onlineQ k α β A S ω) ω j := by
  induction i with
  | zero => exact ⟨rfl, fun j => j.elim0⟩
  | succ i ih =>
    obtain ⟨h1, h2⟩ := ih
    have hq : (fun ℓ => A i (onlineRun k α β A S ω i).2 (S ℓ)) =
        onlineQ k α β A S ω i := rfl
    refine ⟨?_, fun j => ?_⟩
    · show (step (onlineRun k α β A S ω i).1 i
          (fun ℓ => A i (onlineRun k α β A S ω i).2 (S ℓ)) ω).1 = _
      rw [hq, h1]
      rfl
    · show Fin.snoc (α := fun _ => RoundRec) (onlineRun k α β A S ω i).2
          (step (onlineRun k α β A S ω i).1 i
            (fun ℓ => A i (onlineRun k α β A S ω i).2 (S ℓ)) ω).2 j = _
      rw [hq, h1]
      refine Fin.lastCases ?_ (fun j' => ?_) j
      · rw [Fin.snoc_last]
        rfl
      · rw [Fin.snoc_castSucc, h2]
        rfl

theorem onlineState_eq_run (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) : onlineState k α β A S ω i = run k α β (onlineQ k α β A S ω) ω i :=
  (onlineRun_eq A S ω i).1

theorem transcript_eq_roundRec (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) :
    transcript k α β A S ω i = roundRec k α β (onlineQ k α β A S ω) ω i :=
  (onlineRun_eq A S ω k).2 i

theorem recAt_transcript (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {j : ℕ} (hj : j < k) :
    recAt (transcript k α β A S ω) j = roundRec k α β (onlineQ k α β A S ω) ω j := by
  rw [recAt, dif_pos hj, transcript_eq_roundRec]

/-- The query values of round `j ≤ k` are those of `q_j = qry A h j`. -/
theorem onlineQ_eq_qry (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {j : ℕ} (hj : j ≤ k) :
    onlineQ k α β A S ω j = fun ℓ => qry A (transcript k α β A S ω) j (S ℓ) := by
  funext ℓ
  show A j (answersOf (onlineRun k α β A S ω j).2) (S ℓ) = A j (histAns _ j) (S ℓ)
  congr 1
  funext l
  rw [histAns_apply, recAt_transcript A S ω (by omega)]
  show (onlineRun k α β A S ω j).2 l = _
  rw [(onlineRun_eq A S ω j).2 l]

theorem transcript_active (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) :
    (transcript k α β A S ω i).active = !(onlineState k α β A S ω i).halt := by
  rw [transcript_eq_roundRec, roundRec_active, onlineState_eq_run]

/-- The record of an active round is built from the chain data of that round. -/
theorem transcript_of_active (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) (h : (transcript k α β A S ω i).active = true) :
    transcript k α β A S ω i =
      (onlineChain k α β A S ω i).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α) := by
  rw [transcript_active] at h
  have hh : (onlineState k α β A S ω i).halt = false := by simpa using h
  rw [transcript_eq_roundRec, roundRec_of_not_halt (by rw [← onlineState_eq_run]; exact hh)]
  rw [← onlineState_eq_run]
  rfl

theorem transcript_of_halted (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) (h : (transcript k α β A S ω i).active = false) :
    transcript k α β A S ω i = RoundRec.halted := by
  rw [transcript_active] at h
  have hh : (onlineState k α β A S ω i).halt = true := by simpa using h
  rw [transcript_eq_roundRec, roundRec_of_halt (by rw [← onlineState_eq_run]; exact hh)]

/-- **FTRL bookkeeping**: the payoff of level `r` at the start of round `i ≤ k` is
`∑_{j<i} δ_{r,j} q_j(X_{r,ℓ})`, with the impulses read off the transcript. -/
theorem onlineState_pay (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {i : ℕ} (hi : i ≤ k) (r : ℕ) (ℓ : Fin (adaBlock k α β r)) :
    (onlineState k α β A S ω i).pay r ℓ = ∑ j ∈ Finset.range i,
      (recAt (transcript k α β A S ω) j).delta r *
        qry A (transcript k α β A S ω) j (S (adaBlockIdx k α β r ℓ)) := by
  rw [onlineState_eq_run, run_pay]
  refine Finset.sum_congr rfl fun j hj => ?_
  rw [Finset.mem_range] at hj
  rw [recAt_transcript A S ω (by omega), onlineQ_eq_qry A S ω (by omega)]

/-- Sums over the rounds of a transcript are sums over the run's records. -/
theorem sum_transcript {M : Type*} [AddCommMonoid M] (A : DetAnalyst X)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (f : RoundRec → M) :
    ∑ i : Fin k, f (transcript k α β A S ω i) =
      ∑ j ∈ Finset.range k, f (roundRec k α β (onlineQ k α β A S ω) ω j) := by
  rw [← Fin.sum_univ_eq_sum_range (fun j => f (roundRec k α β (onlineQ k α β A S ω) ω j)) k]
  exact Finset.sum_congr rfl fun i _ => by rw [transcript_eq_roundRec]

/-- The final `t₁` read off the transcript is the run's counter after round `k - 1`. -/
theorem finalT1_eq (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) :
    finalT1 (transcript k α β A S ω) = (onlineState k α β A S ω k).t1 := by
  unfold finalT1
  rw [Finset.card_filter, sum_transcript A S ω (fun h => if h.ufinal = 2 then 1 else 0),
    onlineState_eq_run, run_t1]

/-- The final `N_r` (`r ≥ 3`) read off the transcript is the run's counter after round `k - 1`. -/
theorem finalN_eq (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    {r : ℕ} (hr : 3 ≤ r) : finalN (transcript k α β A S ω) r = (onlineState k α β A S ω k).N r := by
  unfold finalN
  rw [Finset.card_filter, sum_transcript A S ω (fun h => if h.ufinal = r then 1 else 0),
    onlineState_eq_run, run_N]
  refine Finset.sum_congr rfl fun j _ => ?_
  by_cases h : (roundRec k α β (onlineQ k α β A S ω) ω j).ufinal = r
  · rw [if_pos h, if_pos ⟨h ▸ hr, h.symm⟩]
  · rw [if_neg h, if_neg fun h' => h h'.2.symm]

theorem finalT1_le (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) : finalT1 (transcript k α β A S ω) ≤ adaT1max α := by
  rw [finalT1_eq, onlineState_eq_run]
  exact run_t1_le _ ω hα k

/-- Zero overshoot on the transcript: `N_r ≤ N_{r,max}` for `r ≥ 3` (eq. `I:eq:det_counter_caps`). -/
theorem finalN_le (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) {r : ℕ} (hr : 3 ≤ r) : finalN (transcript k α β A S ω) r ≤ adaNmax α r := by
  rw [finalN_eq A S ω hr, onlineState_eq_run]
  exact run_N_le _ ω hα k r

/-- If no counter reaches its cap, every round is active (the HALT branch is never taken). -/
theorem active_of_caps (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α)
    (ht : finalT1 (transcript k α β A S ω) < adaT1max α)
    (hN : ∀ r, 3 ≤ r → r ≤ adaL α → finalN (transcript k α β A S ω) r < adaNmax α r) (i : Fin k) :
    (transcript k α β A S ω i).active = true := by
  rw [transcript_active, onlineState_eq_run]
  rw [finalT1_eq, onlineState_eq_run] at ht
  have hN' : ∀ r, 3 ≤ r → r ≤ adaL α →
      (run k α β (onlineQ k α β A S ω) ω k).N r < adaNmax α r := fun r h3 hL => by
    have := hN r h3 hL
    rwa [finalN_eq A S ω h3, onlineState_eq_run] at this
  rw [run_not_halt_of_caps _ ω i.isLt.le ht hN']
  rfl

/-! ### The impulses -/

theorem ChainData.delta_one (d : ChainData) (e1 e : ℝ) (eT : ℕ → ℝ) :
    d.delta e1 e eT 1 = if d.ufinal = 2 then -e1 * d.sgn else 0 := by
  unfold ChainData.delta
  split_ifs <;> first | rfl | omega

/-- The unified Stage-1 impulse: `δ_{1,i} = -η₁ s^{(1)}` on Case-A rounds and `0` otherwise. -/
theorem transcript_delta_one (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : Fin k) :
    (transcript k α β A S ω i).delta 1 =
      if (transcript k α β A S ω i).ufinal = 2 then -adaEta1 α * (transcript k α β A S ω i).sgn
      else 0 := by
  cases h : (transcript k α β A S ω i).active
  · rw [transcript_of_halted A S ω i h]
    simp
  · rw [transcript_of_active A S ω i h]
    exact ChainData.delta_one _ _ _ _

theorem ChainData.abs_sgn_of_two_le (d : ChainData) (h : 2 ≤ d.ufinal) : |d.sgn| = 1 := by
  unfold ChainData.sgn
  rw [if_pos h, abs_sgn1]

/-- Remark `I:rem:halt_round_completion`(1) (single-pair updates), in absolute values: for a validator level
`m ≥ 2`, `|δ_{m,i}| = η` if `u_final = m + 1 ≥ 3`, `|η̃_m|` if `u_final = m ≥ 3`, and `0` otherwise. -/
theorem ChainData.abs_delta (d : ChainData) (e1 e : ℝ) (eT : ℕ → ℝ) {m : ℕ} (hm : 2 ≤ m)
    (he : 0 ≤ e) :
    |d.delta e1 e eT m| = (if d.ufinal = m + 1 then e else 0) +
      (if d.ufinal = m ∧ 3 ≤ m then |eT m| else 0) := by
  unfold ChainData.delta
  by_cases h2 : d.ufinal = 2
  · have e1' : ¬ (d.ufinal = m + 1) := by omega
    have e2' : ¬ (d.ufinal = m ∧ 3 ≤ m) := by omega
    have e3 : ¬ (m = 1) := by omega
    rw [if_pos h2, if_neg e3, if_neg e1', if_neg e2']
    simp
  · rw [if_neg h2]
    by_cases h3 : 3 ≤ d.ufinal
    · rw [if_pos h3]
      have hs := d.abs_sgn_of_two_le (by omega)
      by_cases hm1 : m + 1 = d.ufinal
      · have e1' : d.ufinal = m + 1 := hm1.symm
        have e2' : ¬ (d.ufinal = m ∧ 3 ≤ m) := by omega
        rw [if_pos hm1, if_pos e1', if_neg e2', abs_mul, abs_neg, hs, mul_one, abs_of_nonneg he,
          add_zero]
      · have e1' : ¬ (d.ufinal = m + 1) := fun h => hm1 h.symm
        rw [if_neg hm1, if_neg e1']
        by_cases hmu : m = d.ufinal
        · have e2' : d.ufinal = m ∧ 3 ≤ m := ⟨hmu.symm, by omega⟩
          rw [if_pos hmu, if_pos e2', abs_mul, hs, mul_one, zero_add]
        · have e2' : ¬ (d.ufinal = m ∧ 3 ≤ m) := fun h => hmu h.1.symm
          rw [if_neg hmu, if_neg e2']
          simp
    · have e1' : ¬ (d.ufinal = m + 1) := by omega
      have e2' : ¬ (d.ufinal = m ∧ 3 ≤ m) := by omega
      rw [if_neg h3, if_neg e1', if_neg e2']
      simp

/-- Impulse counting (used for the `ℓ₁` budget `W̃_{max,m}` of §5): for a validator level `m ≥ 2`,
`∑_i |δ_{m,i}| = η N_{m+1} + |η̃_m| N_m 1{m ≥ 3}`. -/
theorem sum_abs_delta (hα : 0 < α) (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) {m : ℕ} (hm : 2 ≤ m) :
    ∑ i : Fin k, |(transcript k α β A S ω i).delta m| =
      adaEta α * finalN (transcript k α β A S ω) (m + 1) +
        (if 3 ≤ m then |adaEtaTilde α m| * finalN (transcript k α β A S ω) m else 0) := by
  have he : 0 ≤ adaEta α := by
    unfold adaEta adaGamma
    have := adaL_ge_four α
    have : (0 : ℝ) < adaL α := by exact_mod_cast (show 0 < adaL α by omega)
    positivity
  have key : ∀ i : Fin k, |(transcript k α β A S ω i).delta m| =
      (if (transcript k α β A S ω i).ufinal = m + 1 then adaEta α else 0) +
        (if (transcript k α β A S ω i).ufinal = m ∧ 3 ≤ m then |adaEtaTilde α m| else 0) := by
    intro i
    cases h : (transcript k α β A S ω i).active
    · rw [transcript_of_halted A S ω i h]
      have e1 : ¬ (RoundRec.halted.ufinal = m + 1) := by
        rw [RoundRec.halted_ufinal]
        omega
      have e2 : ¬ (RoundRec.halted.ufinal = m ∧ 3 ≤ m) := by
        rw [RoundRec.halted_ufinal]
        omega
      rw [RoundRec.halted_delta, abs_zero, if_neg e1, if_neg e2, add_zero]
    · rw [transcript_of_active A S ω i h]
      exact ChainData.abs_delta _ _ _ _ hm he
  rw [Finset.sum_congr rfl fun i _ => key i, Finset.sum_add_distrib]
  unfold finalN
  congr 1
  · rw [Finset.card_filter, Nat.cast_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    split_ifs <;> simp
  · split_ifs with h3
    · rw [Finset.card_filter, Nat.cast_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      by_cases hu : (transcript k α β A S ω i).ufinal = m
      · rw [if_pos ⟨hu, h3⟩, if_pos hu]
        simp
      · rw [if_neg (fun h => hu h.1), if_neg hu]
        simp
    · refine Finset.sum_eq_zero fun i _ => ?_
      rw [if_neg (fun h => h3 h.2)]

/-! ### The interaction is the Spec's `adaAnswers` (Spec v1 interface: answer-only analysts) -/

/-- The Spec v1 interaction transcript `adaAnswers` of `adaMech` with an answer-only deterministic analyst is
the sequence of answers of the run on the query values of the record-seeing analyst `A.toDet`. -/
theorem adaAnswers_adaMech (A : AnsAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (i : ℕ) (j : Fin i) :
    adaAnswers (adaMech k α β) A.toADA S ω () i j =
      (roundRec k α β (onlineQ k α β A.toDet S ω) ω j).answer := by
  induction i with
  | zero => exact j.elim0
  | succ i ih =>
    refine Fin.lastCases ?_ (fun j' => ?_) j
    · show Fin.snoc (α := fun _ => ℝ) (adaAnswers (adaMech k α β) A.toADA S ω () i) _ (Fin.last i) = _
      rw [Fin.snoc_last]
      show (roundRec k α β (extendVals _) ω i).answer = _
      congr 1
      apply roundRec_congr
      intro j hj
      funext ℓ
      simp only [extendVals, dif_pos (Nat.lt_succ_of_le hj)]
      show A j _ (S ℓ) = A j (fun l => ((onlineRun k α β A.toDet S ω j).2 l).answer) (S ℓ)
      congr 1
      funext l
      rw [ih]
      show _ = ((onlineRun k α β A.toDet S ω j).2 l).answer
      rw [(onlineRun_eq A.toDet S ω j).2 l]
      rfl
    · show Fin.snoc (α := fun _ => ℝ) (adaAnswers (adaMech k α β) A.toADA S ω () i) _ (Fin.castSucc j') = _
      rw [Fin.snoc_castSucc]
      exact ih j'

theorem adaAnswers_adaMech_eq_transcript (A : AnsAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) (j : Fin k) :
    adaAnswers (adaMech k α β) A.toADA S ω () k j = (transcript k α β A.toDet S ω j).answer := by
  rw [adaAnswers_adaMech, transcript_eq_roundRec]

/-- The Spec v1 failure event for `adaMech` and an answer-only deterministic analyst, in terms of the
transcript of `A.toDet`: some answer is more than `α` away from the population mean `μ_i(h)` of its query. -/
theorem adaFails_adaMech_iff [MeasurableSpace X] (D : Measure X) (A : AnsAnalyst X)
    (S : Fin (adaSampleSize k α β) → X) (ω : AdaOmega k α) (a : ℝ) :
    adaFails (adaMech k α β) A.toADA D k a S ω () ↔
      ∃ i : Fin k, a < |(transcript k α β A.toDet S ω i).answer -
        popMu D A.toDet (transcript k α β A.toDet S ω) i| := by
  unfold adaFails
  refine exists_congr fun i => ?_
  rw [adaAnswers_adaMech_eq_transcript]
  have hh : (fun l : Fin i.val =>
      adaAnswers (adaMech k α β) A.toADA S ω () k (Fin.castLE (le_of_lt i.isLt) l)) =
      fun l => (histAns (transcript k α β A.toDet S ω) i l).answer := by
    funext l
    rw [adaAnswers_adaMech_eq_transcript, histAns_apply, recAt, dif_pos (by omega)]
    rfl
  rw [hh]
  rfl

end Online

end A

end F2e2e
