import F2e2e.Lib.Opt.EntropicRegret

/-!
# Part I §5: abstract closure lemmas

Paper: `parts/partI.tex` §5 (L1750–1986): Lemma `I:lem:stage1_trigger_cap_closure` (L1759–1820), Lemma
`I:lem:obl1_measurability_ceiling` (L1846–1903), Theorem `I:thm:pigeonhole_comparator_closure` (L1905–1986);
`notes/PAPER_MAP_I_c.md` I.5.3–I.5.5.

These are the mechanism-independent steps of the three closure arguments, stated for real sequences, finite
distributions and an abstract probability space, so that the transcript-level statements (`F2e2e/A/Closure.lean`)
only have to instantiate them.

* `markov_closure`: if `G` is bounded by `M`, `G ≥ 0` on the clean event `E` and `G ≥ c > 0` on `B ∩ E`, then
  `μ(B ∩ E) ≤ (E[G] + M μ(Eᶜ))/c` (the Markov steps `I:eq:stage1_markov_derivation`, `I:eq:sec5_markov_step`).
* `exists_ge_of_sum_ge`: the pigeonhole step of `I:eq:pigeonhole_inclusion`
  (`∑_{m=2}^{L-1} Prog_m ≥ 192 L` forces some `Prog_m ≥ 128`).
* `linTest`: the gated linear test functional `c ∑_i a_i (q_i - μ_i)` (zero if `c ∑ |a_i| > 1`), with its range,
  zero-mean and width-one properties (Lemma `I:lem:stage1_trigger_cap_closure`(i), Lemma
  `I:lem:obl1_measurability_ceiling`(2)).
* `stage1_floor_of_regret`: Proposition `I:prop:ftrl_regret` at a comparator `Q` plus the decoupling margin `γ₁`
  give `(1/(ηT)) ∑_i (-δ_i)(⟨Q, z_i⟩ - μ_i) ≥ γ₁ - η/8 - ε²/(2ηT)` (eq. `I:eq:stage1_unweighted_comp_lb`).
* `validator_floor_of_regret`: the scaled regret plus clipping fidelity give
  `8w ∑_i (-δ_i)(⟨Q, z_i⟩ - μ_i) ≥ Prog - 4` (eqs. `I:eq:scaled_ftrl_regret_m`–`I:eq:scaled_comp_vs_Progm`).
-/

namespace F2e2e.A

open Finset MeasureTheory

/-! ### Markov closure -/

/-- **Markov closure.** Let `G` be measurable with `|G| ≤ M`, `G ≥ 0` on `E` and `G ≥ c > 0` on `B ∩ E`. Then
`μ(B ∩ E) ≤ (A + M μ(Eᶜ))/c` whenever `E[G] ≤ A` (the paper's `E[G 1_E] ≤ E[G] + M P[Eᶜ]` and Markov's
inequality for the pointwise non-negative `G 1_E`). -/
theorem markov_closure {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {G : Ω → ℝ} (hG : Measurable G) {E B : Set Ω} (hE : MeasurableSet E) (hB : MeasurableSet B)
    {c M A : ℝ} (hc : 0 < c) (hM : ∀ ω, |G ω| ≤ M)
    (hnonneg : ∀ ω ∈ E, 0 ≤ G ω) (hbad : ∀ ω ∈ E, ω ∈ B → c ≤ G ω) (hint : ∫ ω, G ω ∂μ ≤ A) :
    μ.real (B ∩ E) ≤ (A + M * μ.real Eᶜ) / c := by
  have hGi : Integrable G μ := (integrable_const M).mono' hG.aestronglyMeasurable
    (Filter.Eventually.of_forall fun ω => by rw [Real.norm_eq_abs]; exact hM ω)
  have h1 : c * μ.real (B ∩ E) ≤ ∫ ω in E, G ω ∂μ := by
    calc c * μ.real (B ∩ E) = ∫ _ω in B ∩ E, c ∂μ := by
          rw [setIntegral_const, smul_eq_mul, mul_comm]
      _ ≤ ∫ ω in B ∩ E, G ω ∂μ :=
          setIntegral_mono_on (integrable_const c).integrableOn hGi.integrableOn (hB.inter hE)
            fun ω hω => hbad ω hω.2 hω.1
      _ ≤ ∫ ω in E, G ω ∂μ := by
          apply setIntegral_mono_set hGi.integrableOn
          · exact (ae_restrict_iff' hE).mpr (Filter.Eventually.of_forall fun ω hω => hnonneg ω hω)
          · exact Filter.Eventually.of_forall fun ω hω => hω.2
  have h2 : ∫ ω in E, G ω ∂μ ≤ A + M * μ.real Eᶜ := by
    have hsplit := integral_add_compl hE hGi
    have h3 : -(M * μ.real Eᶜ) ≤ ∫ ω in Eᶜ, G ω ∂μ := by
      calc -(M * μ.real Eᶜ) = ∫ _ω in Eᶜ, (-M) ∂μ := by
            rw [setIntegral_const, smul_eq_mul]
            ring
        _ ≤ ∫ ω in Eᶜ, G ω ∂μ :=
            setIntegral_mono_on (integrable_const (-M)).integrableOn hGi.integrableOn hE.compl
              fun ω _ => by linarith [(abs_le.mp (hM ω)).1]
    linarith
  rw [le_div_iff₀ hc]
  linarith [mul_comm c (μ.real (B ∩ E))]

/-! ### Pigeonhole -/

/-- **Pigeonhole** (proof of Lemma `I:lem:obl1_measurability_ceiling`(1)): if `∑_{m=2}^{L-1} P_m ≥ 192 L` with
`L > 0`, some level `m ∈ [2, L-1]` has `P_m ≥ 128` (as `192 L > 128 (L - 2)`). -/
theorem exists_ge_of_sum_ge {L : ℕ} (hL : 0 < L) (P : ℕ → ℝ)
    (hsum : 192 * (L : ℝ) ≤ ∑ m ∈ Finset.Icc 2 (L - 1), P m) :
    ∃ m ∈ Finset.Icc 2 (L - 1), 128 ≤ P m := by
  have hL' : (0 : ℝ) < L := Nat.cast_pos.mpr hL
  have hne : (Finset.Icc 2 (L - 1)).Nonempty := by
    by_contra h
    rw [Finset.not_nonempty_iff_eq_empty] at h
    rw [h, Finset.sum_empty] at hsum
    linarith
  have hcard : ((Finset.Icc 2 (L - 1)).card : ℝ) ≤ L := by
    rw [Nat.card_Icc]
    exact_mod_cast (by omega : L - 1 + 1 - 2 ≤ L)
  apply Finset.exists_le_of_sum_le hne
  calc ∑ _m ∈ Finset.Icc 2 (L - 1), (128 : ℝ) = 128 * ((Finset.Icc 2 (L - 1)).card : ℝ) := by
        rw [Finset.sum_const, nsmul_eq_mul, mul_comm]
    _ ≤ 128 * L := by gcongr
    _ ≤ 192 * L := by linarith
    _ ≤ ∑ m ∈ Finset.Icc 2 (L - 1), P m := hsum

/-! ### The gated linear test functional -/

section LinTest

variable {ι X : Type*}

/-- The gated linear test functional `c ∑_{i ∈ s} a_i (q_i(x) - μ_i)`, set to `0` when `c ∑_{i ∈ s} |a_i| > 1`.
The gate never closes on the mechanism's transcripts (it encodes the step budget `8 w_m ∑_i |δ_{m,i}| ≤ W̃_{max,m}`,
resp. `∑_u |s_u| = T_{1,max}` on `{t₁ = T_{1,max}}`); it makes the functional bounded for every argument, as the
transfer lemma requires. -/
noncomputable def linTest (s : Finset ι) (c : ℝ) (a μ : ι → ℝ) (q : ι → X → ℝ) (x : X) : ℝ :=
  if c * ∑ i ∈ s, |a i| ≤ 1 then c * ∑ i ∈ s, a i * (q i x - μ i) else 0

lemma linTest_eq {s : Finset ι} {c : ℝ} {a μ : ι → ℝ} {q : ι → X → ℝ} (h : c * ∑ i ∈ s, |a i| ≤ 1)
    (x : X) : linTest s c a μ q x = c * ∑ i ∈ s, a i * (q i x - μ i) := by
  simp [linTest, h]

lemma abs_linComb_le (s : Finset ι) (a μ : ι → ℝ) (q : ι → X → ℝ) (hq : ∀ i x, q i x ∈ Set.Icc (0 : ℝ) 1)
    (hμ : ∀ i, μ i ∈ Set.Icc (0 : ℝ) 1) (x : X) :
    |∑ i ∈ s, a i * (q i x - μ i)| ≤ ∑ i ∈ s, |a i| := by
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
  rw [abs_mul]
  have h : |q i x - μ i| ≤ 1 := by
    rw [abs_le]
    constructor <;> linarith [(hq i x).1, (hq i x).2, (hμ i).1, (hμ i).2]
  calc |a i| * |q i x - μ i| ≤ |a i| * 1 := by gcongr
    _ = |a i| := mul_one _

/-- The gated test functional takes values in `[-1, 1]` (Lemma `I:lem:stage1_trigger_cap_closure`(i), Lemma
`I:lem:obl1_measurability_ceiling`(2)). -/
lemma linTest_mem_Icc (s : Finset ι) {c : ℝ} (hc : 0 ≤ c) (a μ : ι → ℝ) (q : ι → X → ℝ)
    (hq : ∀ i x, q i x ∈ Set.Icc (0 : ℝ) 1) (hμ : ∀ i, μ i ∈ Set.Icc (0 : ℝ) 1) (x : X) :
    linTest s c a μ q x ∈ Set.Icc (-1 : ℝ) 1 := by
  unfold linTest
  split_ifs with h
  · have h1 := abs_linComb_le s a μ q hq hμ x
    have h2 : |c * ∑ i ∈ s, a i * (q i x - μ i)| ≤ 1 := by
      rw [abs_mul, abs_of_nonneg hc]
      calc c * |∑ i ∈ s, a i * (q i x - μ i)| ≤ c * ∑ i ∈ s, |a i| := by gcongr
        _ ≤ 1 := h
    exact abs_le.mp h2
  · exact ⟨by norm_num, by norm_num⟩

/-- The gated test functional has range width at most one. -/
lemma linTest_width (s : Finset ι) {c : ℝ} (hc : 0 ≤ c) (a μ : ι → ℝ) (q : ι → X → ℝ)
    (hq : ∀ i x, q i x ∈ Set.Icc (0 : ℝ) 1) (x x' : X) :
    linTest s c a μ q x - linTest s c a μ q x' ≤ 1 := by
  unfold linTest
  split_ifs with h
  · rw [← mul_sub, ← Finset.sum_sub_distrib]
    have h1 : ∑ i ∈ s, (a i * (q i x - μ i) - a i * (q i x' - μ i)) ≤ ∑ i ∈ s, |a i| := by
      refine Finset.sum_le_sum fun i _ => ?_
      have e : a i * (q i x - μ i) - a i * (q i x' - μ i) = a i * (q i x - q i x') := by ring
      rw [e]
      have h2 : |q i x - q i x'| ≤ 1 := by
        rw [abs_le]
        constructor <;> linarith [(hq i x).1, (hq i x).2, (hq i x').1, (hq i x').2]
      calc a i * (q i x - q i x') ≤ |a i * (q i x - q i x')| := le_abs_self _
        _ = |a i| * |q i x - q i x'| := abs_mul _ _
        _ ≤ |a i| * 1 := by gcongr
        _ = |a i| := mul_one _
    calc c * ∑ i ∈ s, (a i * (q i x - μ i) - a i * (q i x' - μ i)) ≤ c * ∑ i ∈ s, |a i| := by gcongr
      _ ≤ 1 := h
  · norm_num

/-- The gated test functional is centered when `μ_i = ∫ q_i dD`
(`E_{X' ∼ D}[F(h, X') | h] = 0`, Lemma `I:lem:stage1_trigger_cap_closure`(i), Lemma
`I:lem:obl1_measurability_ceiling`(2)). -/
lemma integral_linTest [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D] (s : Finset ι) (c : ℝ)
    (a μ : ι → ℝ) (q : ι → X → ℝ) (hqi : ∀ i, Integrable (q i) D) (hμ : ∀ i, μ i = ∫ x, q i x ∂D) :
    ∫ x, linTest s c a μ q x ∂D = 0 := by
  unfold linTest
  split_ifs with h
  · rw [integral_const_mul, integral_finsetSum]
    · have : ∀ i ∈ s, ∫ x, a i * (q i x - μ i) ∂D = 0 := by
        intro i _
        rw [integral_const_mul, integral_sub (hqi i) (integrable_const _), integral_const, ← hμ i]
        simp
      rw [Finset.sum_eq_zero this, mul_zero]
    · intro i _
      exact ((hqi i).sub (integrable_const _)).const_mul _
  · simp

end LinTest

/-! ### From the FTRL regret to the comparator floors -/

section Floors

variable {n : ℕ}

/-- `∑_{i<k, δ_i ≠ 0} c = T c` and `∑ |δ_i| = η T` when every non-zero step has size `η`. -/
lemma sum_ite_ne_zero (δ : ℕ → ℝ) (k : ℕ) (c : ℝ) :
    ∑ i ∈ range k, (if δ i ≠ 0 then c else 0) = (((range k).filter fun i => δ i ≠ 0).card : ℝ) * c := by
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]

/-- **Stage-1 comparator floor** (deterministic part of Lemma `I:lem:stage1_trigger_cap_closure`(ii),
eqs. `I:eq:stage1_ftrl_divided`, `I:eq:stage1_unweighted_comp_lb`). Let `P_(i) = P*(G_(i))` be the entropic-FTRL
iterates of the steps `δ_i` (each non-zero step has size `η`, and exactly `T > 0` of the first `k` steps are
non-zero), and suppose every update round has margin `γ₁ ≤ s_i (θ_i - μ_i)` with `s_i = -δ_i/η` (the decoupling
bound of §4). Then every comparator `Q ∈ K₂` with `KL(Q ‖ Unif) ≤ ε²/2` satisfies
`(1/(ηT)) ∑_{i<k} (-δ_i)(⟨Q, z_i⟩ - μ_i) ≥ γ₁ - η/8 - ε²/(2ηT)`. -/
theorem stage1_floor_of_regret (hn : 0 < n) {η γ₁ ε : ℝ} (hη : 0 < η) (δ : ℕ → ℝ) (z : ℕ → Fin n → ℝ)
    (μ : ℕ → ℝ) (k T : ℕ) (hT : 0 < T) (hz : ∀ i < k, ∀ ℓ, z i ℓ ∈ Set.Icc (0 : ℝ) 1)
    (P : ℕ → Fin n → ℝ) (hP : ∀ i ≤ k, P i = Opt.waterFill n η (fun ℓ => ∑ j ∈ range i, δ j / η * z j ℓ))
    (hδ : ∀ i < k, δ i ≠ 0 → |δ i| = η) (hcard : ((range k).filter fun i => δ i ≠ 0).card = T)
    (hdec : ∀ i < k, δ i ≠ 0 → γ₁ ≤ (-δ i / η) * (∑ ℓ, P i ℓ * z i ℓ - μ i))
    (Q : Fin n → ℝ) (hQ : Q ∈ Opt.cappedSimplex n) (hKL : Opt.klUnif n Q ≤ ε ^ 2 / 2) :
    γ₁ - η / 8 - ε ^ 2 / (2 * η * T) ≤
      (1 / (η * T)) * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) := by
  have hreg := Opt.ftrl_regret hn hη δ z μ k hz P hP Q hQ
  have hT' : (0 : ℝ) < T := Nat.cast_pos.mpr hT
  -- per-round lower bound: `(-δ_i)(θ_i - μ_i) - δ_i²/8 ≥ 1{δ_i ≠ 0} (γ₁ η - η²/8)`
  have hterm : ∀ i ∈ range k, (if δ i ≠ 0 then γ₁ * η - η ^ 2 / 8 else 0) ≤
      (-δ i) * (∑ ℓ, P i ℓ * z i ℓ - μ i) - δ i ^ 2 / 8 := by
    intro i hi
    rw [Finset.mem_range] at hi
    split_ifs with h0
    · have h1 := hdec i hi h0
      have h2 : δ i ^ 2 = η ^ 2 := by rw [← sq_abs, hδ i hi h0]
      have h3 : (-δ i) * (∑ ℓ, P i ℓ * z i ℓ - μ i) = η * ((-δ i / η) * (∑ ℓ, P i ℓ * z i ℓ - μ i)) := by
        field_simp
      rw [h3, h2]
      nlinarith
    · push Not at h0
      rw [h0]
      simp
  have hsum : (T : ℝ) * (γ₁ * η - η ^ 2 / 8) ≤
      ∑ i ∈ range k, ((-δ i) * (∑ ℓ, P i ℓ * z i ℓ - μ i) - δ i ^ 2 / 8) := by
    calc (T : ℝ) * (γ₁ * η - η ^ 2 / 8) = ∑ i ∈ range k, (if δ i ≠ 0 then γ₁ * η - η ^ 2 / 8 else 0) := by
          rw [sum_ite_ne_zero, hcard]
      _ ≤ _ := Finset.sum_le_sum hterm
  -- drop the `μ_i`, which cancel in the regret bound
  have hmain : (T : ℝ) * (γ₁ * η - η ^ 2 / 8) - ε ^ 2 / 2 ≤
      ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) := by
    linarith
  have hηT : 0 < η * T := mul_pos hη hT'
  rw [← sub_nonneg]
  have key : (1 / (η * T)) * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) -
      (γ₁ - η / 8 - ε ^ 2 / (2 * η * T)) =
      (1 / (η * T)) * (∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) -
        ((T : ℝ) * (γ₁ * η - η ^ 2 / 8) - ε ^ 2 / 2)) := by
    field_simp
  rw [key]
  exact mul_nonneg (by positivity) (by linarith)

/-- **Validator comparator floor** (deterministic part of Theorem `I:thm:pigeonhole_comparator_closure`(1),
eqs. `I:eq:scaled_ftrl_regret_m`, `I:eq:theta_to_c_conversion_sec5`, `I:eq:scaled_comp_vs_Progm`). Let `P_(i)` be the
entropic-FTRL iterates of the steps `δ_i` at rate `η`, suppose the released values satisfy the clipping fidelity
`|c_i - θ_i| ≤ u₀` on every round with `δ_i ≠ 0`, and let `w ε² = 1`, `w ≥ 0`. Then every comparator `Q ∈ K₂` with
`KL(Q ‖ Unif) ≤ ε²/2` satisfies
`8w ∑_i (-δ_i)(⟨Q, z_i⟩ - μ_i) ≥ 8w ∑_i [(-δ_i)(c_i - μ_i) - δ_i²/8 - |δ_i| u₀] - 4` (`= Prog_m(h) - 4`). -/
theorem validator_floor_of_regret (hn : 0 < n) {η u₀ w ε : ℝ} (hη : 0 < η) (hw : 0 ≤ w)
    (hwε : w * ε ^ 2 = 1) (δ : ℕ → ℝ) (z : ℕ → Fin n → ℝ) (μ c : ℕ → ℝ) (k : ℕ)
    (hz : ∀ i < k, ∀ ℓ, z i ℓ ∈ Set.Icc (0 : ℝ) 1) (P : ℕ → Fin n → ℝ)
    (hP : ∀ i ≤ k, P i = Opt.waterFill n η (fun ℓ => ∑ j ∈ range i, δ j / η * z j ℓ))
    (hclip : ∀ i < k, δ i ≠ 0 → |c i - ∑ ℓ, P i ℓ * z i ℓ| ≤ u₀)
    (Q : Fin n → ℝ) (hQ : Q ∈ Opt.cappedSimplex n) (hKL : Opt.klUnif n Q ≤ ε ^ 2 / 2) :
    8 * w * ∑ i ∈ range k, ((-δ i) * (c i - μ i) - δ i ^ 2 / 8 - |δ i| * u₀) - 4 ≤
      8 * w * ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) := by
  have hreg := Opt.ftrl_regret hn hη δ z μ k hz P hP Q hQ
  have hterm : ∀ i ∈ range k, (-δ i) * (c i - μ i) - δ i ^ 2 / 8 - |δ i| * u₀ ≤
      (-δ i) * (∑ ℓ, P i ℓ * z i ℓ - μ i) - δ i ^ 2 / 8 := by
    intro i hi
    rw [Finset.mem_range] at hi
    by_cases h0 : δ i = 0
    · rw [h0]
      simp
    · have h1 := hclip i hi h0
      have h2 : (-δ i) * (c i - ∑ ℓ, P i ℓ * z i ℓ) ≤ |δ i| * u₀ := by
        calc (-δ i) * (c i - ∑ ℓ, P i ℓ * z i ℓ) ≤ |(-δ i) * (c i - ∑ ℓ, P i ℓ * z i ℓ)| :=
              le_abs_self _
          _ = |δ i| * |c i - ∑ ℓ, P i ℓ * z i ℓ| := by rw [abs_mul, abs_neg]
          _ ≤ |δ i| * u₀ := by gcongr
      nlinarith
  have hsum := Finset.sum_le_sum hterm
  have h4 : 8 * w * (ε ^ 2 / 2) = 4 := by nlinarith
  have h5 : 8 * w * Opt.klUnif n Q ≤ 4 := by
    calc 8 * w * Opt.klUnif n Q ≤ 8 * w * (ε ^ 2 / 2) := by gcongr
      _ = 4 := h4
  have h6 : ∑ i ∈ range k, ((-δ i) * (c i - μ i) - δ i ^ 2 / 8 - |δ i| * u₀) - Opt.klUnif n Q ≤
      ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) := by
    have e1 : ∑ i ∈ range k, ((-δ i) * (∑ ℓ, P i ℓ * z i ℓ - μ i) - δ i ^ 2 / 8) - Opt.klUnif n Q ≤
        ∑ i ∈ range k, (-δ i) * (∑ ℓ, Q ℓ * z i ℓ - μ i) := hreg
    linarith
  have h7 := mul_le_mul_of_nonneg_left h6 (by positivity : (0 : ℝ) ≤ 8 * w)
  rw [mul_sub] at h7
  linarith

end Floors

end F2e2e.A
