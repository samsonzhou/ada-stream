import F2e2e.A.S1PrivacyNumerics

/-!
# Part I, Lemma `I:lem:working_sample_privacy`: Stage-1 working-sample privacy (abstract form)

`parts/partI.tex` L582–797 (statement L589–641, proof L643–797); `notes/PAPER_MAP_I_a.md` §I.2.2.

The lemma is formalized for an ABSTRACT adaptive release process, to be instantiated by the mechanism
(`F2e2e.A.Mechanism`, owner A-ARCH) after fixing all randomness and data other than `S₁` (L616, L671):
* noise: `V = (V_1, …, V_k)` i.i.d. with law `Dist.betaSym m` (`V_i = 2B_i - 1`, `B_i ∼ Beta(m+1, m+1)`),
  `m = adaBetaM α β`;
* unclipped Stage-1 releases `ã_i = θ_i(ã_{<i}) + R₁ V_i` (L605, L671), where `θ_i : (Fin k → ℝ) → ℝ` is the
  round-`i` weighted empirical mean of `S₁` as a function of the previous releases (it may depend on anything
  fixed: the other blocks, validator coins, analyst coins); we require `θ_i` measurable and depending only on the
  coordinates `< i` (`DependsOn (θ i) (Set.Iio i)`). On halted rounds `θ_i` may be any value not depending on
  `S₁` (e.g. `1/2`): the transcript simply ignores those coordinates;
* adjacency: `|θ_i(S₁, a) - θ_i(S₁', a)| ≤ Δ₁ = 4/n₁` for all `i`, `a` (eq. `I:eq:di_centered_bound`, from the
  KKT sensitivity lemma `I:lem:kkt_sensitivity`; to be supplied by the instantiation);
* the transcript is a measurable post-processing of `ã` (L696).

## Main statements
* (1) `s1_envelope` (eq. `I:eq:stage1_deterministic_error`).
* (2) the Beta facts are `F2e2e.Dist.betaSymZ_rec`, `betaSymZ_seven`, `one_le_succ_mul_betaSymZ`,
  `integral_betaSym_one_div`, `integral_betaSym_one_div_sq`, `betaSymFisher_eq`, `betaSymFisher_seven`,
  `betaSym_tail_le` (file `F2e2e.Lib.Dist.BetaSym`, owner LIB-BETA).
* (3) `s1_releases_indist` (eq. `I:eq:s1_dp_claim` for the law of `ã`), `s1_releases_isDP`,
  `s1_transcript_isDP` (post-processing), `s1_isDP_of_fixed` (fix the external randomness `ω₁`, then average,
  "and hence also unconditionally after averaging", L616), `s1_isDP_of_generative` (the interface for the
  mechanism: output = dataset-free measurable function of the releases driven by a noise vector `V`).
-/

namespace F2e2e.A

open MeasureTheory ProbabilityTheory F2e2e.Dist

/-- **(1) Deterministic working-noise envelope** (eq. `I:eq:stage1_deterministic_error`, L644–648): for
`θ ∈ [0, 1]` and `|v| < 1`, the clipped proposal `clip(θ + R v, [0, 1]) = min 1 (max 0 (θ + R v))` satisfies
`|clip(θ + R v) - θ| ≤ |(θ + R v) - θ| = |R v| < R`. -/
theorem s1_envelope {θ R v : ℝ} (hθ : θ ∈ Set.Icc (0 : ℝ) 1) (hR : 0 < R) (hv : |v| < 1) :
    |min 1 (max 0 (θ + R * v)) - θ| ≤ |(θ + R * v) - θ| ∧ |(θ + R * v) - θ| < R := by
  refine ⟨?_, ?_⟩
  · rw [add_sub_cancel_left]
    exact abs_clip_add_sub_le hθ.1 hθ.2 (R * v)
  · rw [add_sub_cancel_left, abs_mul, abs_of_pos hR]
    calc R * |v| < R * 1 := mul_lt_mul_of_pos_left hv hR
      _ = R := mul_one R

/-- A solution of the release recursion `Φ v i = θ i (Φ v) + R v i` (`R ≠ 0`, `θ i` measurable and depending
only on the coordinates `< i`) is measurable. -/
theorem measurable_of_release_recursion {k : ℕ} {R : ℝ} (hR : R ≠ 0)
    {θ : Fin k → (Fin k → ℝ) → ℝ} (hθ : ∀ i, Measurable (θ i))
    (hdep : ∀ i, DependsOn (θ i) (Set.Iio i)) {Φ : (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : ∀ v i, Φ v i = θ i (Φ v) + R * v i) : Measurable Φ := by
  have hsol : IsTriangularSol θ (fun ξ => Φ (fun i => ξ i / R)) := by
    intro ξ i
    show Φ (fun i => ξ i / R) i = θ i (Φ (fun i => ξ i / R)) + ξ i
    rw [hΦ]
    congr 1
    field_simp
  have hcomp : Φ = (fun ξ => Φ (fun i => ξ i / R)) ∘ (fun v i => R * v i) := by
    funext v
    simp only [Function.comp_apply]
    congr 1
    funext i
    field_simp
  rw [hcomp]
  exact (hsol.measurable hθ hdep).comp (by fun_prop)

section DP

variable {k : ℕ} {α β : ℝ}

/-- **(3) Stage-1 privacy of the unclipped releases** (eq. `I:eq:s1_dp_claim` for the law of `ã`, both
branches, every `k`, independently of `L`, `η₁`, `T_{1,max}`): the laws of the adaptive releases
`ã_i = θ_i(ã_{<i}) + R₁ V_i` and `ã'_i = θ'_i(ã'_{<i}) + R₁ V_i` under i.i.d. `V_i ∼ f_m` are
`(ε₁, δ₁) = (0.05, αβ/10240)`-indistinguishable when `|θ_i - θ'_i| ≤ 4/n₁`. -/
theorem s1_releases_indist (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {θ θ' : Fin k → (Fin k → ℝ) → ℝ} (hθ : ∀ i, Measurable (θ i)) (hθ' : ∀ i, Measurable (θ' i))
    (hdep : ∀ i, DependsOn (θ i) (Set.Iio i)) (hdep' : ∀ i, DependsOn (θ' i) (Set.Iio i))
    (hsens : ∀ i a, |θ i a - θ' i a| ≤ 4 / (adaN1 k α β : ℝ)) {Φ Φ' : (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : ∀ v i, Φ v i = θ i (Φ v) + adaR1 α * v i)
    (hΦ' : ∀ v i, Φ' v i = θ' i (Φ' v) + adaR1 α * v i) :
    DP.Indist ((Measure.pi fun _ : Fin k => betaSym (adaBetaM α β)).map Φ)
      ((Measure.pi fun _ : Fin k => betaSym (adaBetaM α β)).map Φ') adaEps1 (adaDelta1 α β) := by
  refine releases_indist_of_params (R := adaR1 α) (h := s1H k α β)
    (by unfold adaR1; positivity) (s1NoiseParams_locked k hα hα16 hβ hβ2) hθ hθ' hdep hdep' ?_ hΦ hΦ'
  intro i a
  rw [adaR1_mul_s1H k hα]
  exact hsens i a

/-- **(3), DP form**: a dataset-indexed family of adaptive Stage-1 release processes with sensitivity `4/n₁`
across adjacent datasets is `(0.05, αβ/10240)`-DP. -/
theorem s1_releases_isDP (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {D : Type*} (Adj : D → D → Prop) {θ : D → Fin k → (Fin k → ℝ) → ℝ}
    (hθ : ∀ S i, Measurable (θ S i)) (hdep : ∀ S i, DependsOn (θ S i) (Set.Iio i))
    (hsens : ∀ S S', Adj S S' → ∀ i a, |θ S i a - θ S' i a| ≤ 4 / (adaN1 k α β : ℝ))
    {Φ : D → (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : ∀ S v i, Φ S v i = θ S i (Φ S v) + adaR1 α * v i) :
    DP.IsDP Adj (fun S => (Measure.pi fun _ : Fin k => betaSym (adaBetaM α β)).map (Φ S)) adaEps1
      (adaDelta1 α β) :=
  fun S S' hS => s1_releases_indist hα hα16 hβ hβ2 (hθ S) (hθ S') (hdep S) (hdep S') (hsens S S' hS)
    (hΦ S) (hΦ S')

/-- **(3), transcript form** (post-processing, L696): every measurable function of the release sequence (e.g.
the full `k`-round transcript `h`) is `(0.05, αβ/10240)`-DP. -/
theorem s1_transcript_isDP (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {D : Type*} (Adj : D → D → Prop) {θ : D → Fin k → (Fin k → ℝ) → ℝ}
    (hθ : ∀ S i, Measurable (θ S i)) (hdep : ∀ S i, DependsOn (θ S i) (Set.Iio i))
    (hsens : ∀ S S', Adj S S' → ∀ i a, |θ S i a - θ S' i a| ≤ 4 / (adaN1 k α β : ℝ))
    {Φ : D → (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : ∀ S v i, Φ S v i = θ S i (Φ S v) + adaR1 α * v i)
    {H : Type*} [MeasurableSpace H] {post : (Fin k → ℝ) → H} (hpost : Measurable post) :
    DP.IsDP Adj (fun S => ((Measure.pi fun _ : Fin k => betaSym (adaBetaM α β)).map (Φ S)).map post)
      adaEps1 (adaDelta1 α β) :=
  (s1_releases_isDP hα hα16 hβ hβ2 Adj hθ hdep hsens hΦ).map hpost

/-- **(3), averaged form** ("conditioned on any fixed realization of `(S₂, …, S_L)`, `r_val`, `r_A` … and hence
also unconditionally after averaging", L616): the external randomness `ω₁ ∼ ρ₁` (independent of the Stage-1
noise) is fixed first; for every `ω₁` the releases follow the Stage-1 recursion with means `θ S ω₁` and the
output is `post ω₁ (ã)`. Then the output law under `ρ₁ ⊗ f_m^{⊗k}` is `(0.05, αβ/10240)`-DP. -/
theorem s1_isDP_of_fixed (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {D : Type*} (Adj : D → D → Prop) {Ω₁ : Type*} [MeasurableSpace Ω₁] {ρ₁ : Measure Ω₁}
    (hρ₁ : ρ₁ Set.univ ≤ 1) {θ : D → Ω₁ → Fin k → (Fin k → ℝ) → ℝ}
    (hθ : ∀ S ω₁ i, Measurable (θ S ω₁ i)) (hdep : ∀ S ω₁ i, DependsOn (θ S ω₁ i) (Set.Iio i))
    (hsens : ∀ S S', Adj S S' → ∀ ω₁ i a, |θ S ω₁ i a - θ S' ω₁ i a| ≤ 4 / (adaN1 k α β : ℝ))
    {Φ : D → Ω₁ → (Fin k → ℝ) → (Fin k → ℝ)}
    (hΦ : ∀ S ω₁ v i, Φ S ω₁ v i = θ S ω₁ i (Φ S ω₁ v) + adaR1 α * v i)
    {H : Type*} [MeasurableSpace H] {post : Ω₁ → (Fin k → ℝ) → H} (hpost : ∀ ω₁, Measurable (post ω₁))
    {run : D → Ω₁ × (Fin k → ℝ) → H} (hrun : ∀ S, Measurable (run S))
    (hfac : ∀ S ω₁ v, run S (ω₁, v) = post ω₁ (Φ S ω₁ v)) :
    DP.IsDP Adj (fun S => (ρ₁.prod (Measure.pi fun _ : Fin k => betaSym (adaBetaM α β))).map (run S))
      adaEps1 (adaDelta1 α β) := by
  intro S S' hS
  refine DP.Indist.map_prod hρ₁ (hrun S) (hrun S') (fun ω₁ => ?_)
  have hR : adaR1 α ≠ 0 := by unfold adaR1; positivity
  have hΦm : ∀ T, Measurable (Φ T ω₁) := fun T =>
    measurable_of_release_recursion hR (hθ T ω₁) (hdep T ω₁) (hΦ T ω₁)
  have e : ∀ T, (fun v => run T (ω₁, v)) = post ω₁ ∘ Φ T ω₁ := fun T => funext fun v => hfac T ω₁ v
  rw [e S, e S', ← Measure.map_map (hpost ω₁) (hΦm S), ← Measure.map_map (hpost ω₁) (hΦm S')]
  exact (s1_releases_indist hα hα16 hβ hβ2 (hθ S ω₁) (hθ S' ω₁) (hdep S ω₁) (hdep S' ω₁)
    (hsens S S' hS ω₁) (hΦ S ω₁) (hΦ S' ω₁)).map (hpost ω₁)

/-- **(3), generative-process form** (the interface for the mechanism, `F2e2e.A.Mechanism`): the output
`out S ω` of a randomized procedure is a fixed (dataset-free) measurable function `Ψ` of the Stage-1 releases
`Φ S (V ω)`, where `V ω` is the Stage-1 noise vector, with law `f_m^{⊗k}` under `P`, and the releases follow the
recursion `ã_i = θ_i(S, ã_{<i}) + R₁ V_i`. Then `S ↦ law(out S)` is `(0.05, αβ/10240)`-DP. -/
theorem s1_isDP_of_generative (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2)
    {Ω : Type*} [MeasurableSpace Ω] {P : Measure Ω} {V : Ω → Fin k → ℝ} (hV : Measurable V)
    (hVlaw : P.map V = Measure.pi fun _ : Fin k => betaSym (adaBetaM α β))
    {D : Type*} (Adj : D → D → Prop) {θ : D → Fin k → (Fin k → ℝ) → ℝ}
    (hθ : ∀ S i, Measurable (θ S i)) (hdep : ∀ S i, DependsOn (θ S i) (Set.Iio i))
    (hsens : ∀ S S', Adj S S' → ∀ i a, |θ S i a - θ S' i a| ≤ 4 / (adaN1 k α β : ℝ))
    {Φ : D → (Fin k → ℝ) → (Fin k → ℝ)} (hΦ : ∀ S v i, Φ S v i = θ S i (Φ S v) + adaR1 α * v i)
    {H : Type*} [MeasurableSpace H] {Ψ : (Fin k → ℝ) → H} (hΨ : Measurable Ψ)
    {out : D → Ω → H} (hout : ∀ S ω, out S ω = Ψ (Φ S (V ω))) :
    DP.IsDP Adj (fun S => P.map (out S)) adaEps1 (adaDelta1 α β) := by
  intro S S' hS
  have hR : adaR1 α ≠ 0 := by unfold adaR1; positivity
  have hΦm : ∀ T, Measurable (Φ T) := fun T =>
    measurable_of_release_recursion hR (hθ T) (hdep T) (hΦ T)
  have e : ∀ T, P.map (out T) =
      ((Measure.pi fun _ : Fin k => betaSym (adaBetaM α β)).map (Φ T)).map Ψ := by
    intro T
    have : out T = Ψ ∘ Φ T ∘ V := funext fun ω => hout T ω
    rw [this, ← hVlaw, Measure.map_map (hΦm T) hV, Measure.map_map hΨ ((hΦm T).comp hV)]
  show DP.Indist (P.map (out S)) (P.map (out S')) adaEps1 (adaDelta1 α β)
  rw [e S, e S']
  exact s1_transcript_isDP hα hα16 hβ hβ2 Adj hθ hdep hsens hΦ hΨ S S' hS

end DP

end F2e2e.A
