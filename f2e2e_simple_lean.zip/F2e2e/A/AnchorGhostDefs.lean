import F2e2e.Lib.DP.Exponential
import F2e2e.Lib.DP.Transfer
import F2e2e.Lib.DP.Compose

/-!
# The ghost monitor of Lemma `I:lem:anchor_ghost_monitor`: candidates, scores, kernels

Owner: A-ACC. Paper: `parts/partI.tex` L1054-1107 (proof of Lemma `I:lem:anchor_ghost_monitor`).

Setting (generic): `S ∼ D^n`, an `(ε/2, δ/2)`-DP Markov kernel `κ : S ↦ h`, `[0,1]`-valued jointly measurable
queries `q h i` (`i < k`), `θ_i(S, h) = (1/n) ∑_ℓ q h i (S ℓ)`, `μ_i(h) = ∫ q h i dD`.

The analysis-only ghost monitor is an exponential mechanism over the candidates `([k] × {±1}) ∪ {m₀}`, encoded
as `Fin (2k + 1)` (`c < k`: `(c, +1)`; `k ≤ c < 2k`: `(c - k, -1)`; `c = 2k`: the null candidate `m₀`), with scores
`u_{(i,σ)} = σ(θ_i - μ_i)` and `u_{m₀} = ν` (`ν = r_anc - t_L` in the paper), privacy `ε/2` and sensitivity `1/n`.

## Main definitions
* `nullC`, `candS` (the sign `σ`, `0` for `m₀`), `candI` (the query index).
* `thetaQ`, `muQ`, `score`, `psi` (the test function `ψ(h, J, x) = σ(q_i(h)(x) - μ_i(h))`, `0` for `m₀`).
* `emK` (the exponential-mechanism kernel `(S, h) ↦ J`) and `ghostK = κ ⊗ₖ emK` (`S ↦ (h, J)`).

## Main results
* `score_sens`: scores have sensitivity `1/n`; `ghostK_isDP`: `S ↦ (h, J)` is `(ε, δ/2)`-DP (`(ε/2, δ/2)` then
  the pure `(ε/2, 0)` exponential mechanism, `DP.IsDP.compProd_of_pure`).
* `avg_psi`: `(1/n) ∑_ℓ ψ(h, J, X_ℓ) = u_J` for `J ≠ m₀` (and `0` for `m₀`); `integral_psi`: `E_{X'∼D} ψ(h, J, X') = 0`;
  `abs_psi_le`: `|ψ| ≤ 1_{J ≠ m₀}`.
-/

namespace F2e2e.A.Ghost

open MeasureTheory ProbabilityTheory

/-! ## Candidates -/

/-- The null candidate `m₀ = 2k`. -/
def nullC (k : ℕ) : Fin (2 * k + 1) := ⟨2 * k, by omega⟩

/-- The sign of a candidate: `+1` for `c < k`, `-1` for `k ≤ c < 2k`, `0` for `m₀`. -/
noncomputable def candS (k : ℕ) (c : Fin (2 * k + 1)) : ℝ :=
  if c.val < k then 1 else if c.val < 2 * k then -1 else 0

/-- The query index of a candidate (`c mod k`; irrelevant for `m₀`). -/
def candI {k : ℕ} (hk : 0 < k) (c : Fin (2 * k + 1)) : Fin k := ⟨c.val % k, Nat.mod_lt _ hk⟩

theorem candS_nullC (k : ℕ) : candS k (nullC k) = 0 := by
  show (if 2 * k < k then (1 : ℝ) else if 2 * k < 2 * k then -1 else 0) = 0
  rw [if_neg (show ¬ (2 * k < k) by omega), if_neg (lt_irrefl _)]

theorem abs_candS_le (k : ℕ) (c : Fin (2 * k + 1)) : |candS k c| ≤ 1 := by
  unfold candS
  split_ifs <;> norm_num

theorem abs_candS_of_ne {k : ℕ} {c : Fin (2 * k + 1)} (hc : c ≠ nullC k) : |candS k c| = 1 := by
  have hlt := c.isLt
  unfold candS
  split_ifs with h1 h2
  · norm_num
  · norm_num
  · exfalso
    apply hc
    ext
    show c.val = 2 * k
    omega

theorem candS_eq_zero_iff {k : ℕ} (c : Fin (2 * k + 1)) : candS k c = 0 ↔ c = nullC k := by
  constructor
  · intro h
    by_contra hc
    have := abs_candS_of_ne hc
    rw [h, abs_zero] at this
    exact zero_ne_one this
  · rintro rfl
    exact candS_nullC k

/-- Every `|x|` is the signed value `σ x` of some non-null candidate with query index `i`. -/
theorem exists_cand {k : ℕ} (hk : 0 < k) (i : Fin k) (x : ℝ) :
    ∃ c : Fin (2 * k + 1), c ≠ nullC k ∧ candI hk c = i ∧ candS k c * x = |x| := by
  have hi := i.isLt
  by_cases hx : 0 ≤ x
  · refine ⟨⟨i.val, by omega⟩, ?_, ?_, ?_⟩
    · intro h
      have := congrArg Fin.val h
      simp only [nullC] at this
      omega
    · ext
      show i.val % k = i.val
      exact Nat.mod_eq_of_lt hi
    · have : candS k ⟨i.val, by omega⟩ = 1 := by
        show (if i.val < k then (1 : ℝ) else if i.val < 2 * k then -1 else 0) = 1
        rw [if_pos hi]
      rw [this, one_mul, abs_of_nonneg hx]
  · refine ⟨⟨k + i.val, by omega⟩, ?_, ?_, ?_⟩
    · intro h
      have := congrArg Fin.val h
      simp only [nullC] at this
      omega
    · ext
      show (k + i.val) % k = i.val
      rw [Nat.add_mod_left]
      exact Nat.mod_eq_of_lt hi
    · have : candS k ⟨k + i.val, by omega⟩ = -1 := by
        show (if k + i.val < k then (1 : ℝ) else if k + i.val < 2 * k then -1 else 0) = -1
        rw [if_neg (show ¬ (k + i.val < k) by omega), if_pos (show k + i.val < 2 * k by omega)]
      rw [this, abs_of_neg (lt_of_not_ge hx)]
      ring

/-! ## Scores and the test function -/

section Scores

variable {X H : Type*} [MeasurableSpace X] [MeasurableSpace H]

/-- `θ_i(S, h) = (1/n) ∑_ℓ q h i (S ℓ)`. -/
noncomputable def thetaQ {n k : ℕ} (q : H → Fin k → X → ℝ) (S : Fin n → X) (h : H) (i : Fin k) : ℝ :=
  (∑ ℓ, q h i (S ℓ)) / n

/-- `μ_i(h) = ∫ q h i dD`. -/
noncomputable def muQ {k : ℕ} (D : Measure X) (q : H → Fin k → X → ℝ) (h : H) (i : Fin k) : ℝ :=
  ∫ x, q h i x ∂D

/-- The ghost scores: `u_{(i,σ)}(S, h) = σ(θ_i(S, h) - μ_i(h))`, `u_{m₀} = ν`. -/
noncomputable def score {n k : ℕ} (hk : 0 < k) (D : Measure X) (q : H → Fin k → X → ℝ) (ν : ℝ)
    (S : Fin n → X) (h : H) (c : Fin (2 * k + 1)) : ℝ :=
  if c = nullC k then ν else candS k c * (thetaQ q S h (candI hk c) - muQ D q h (candI hk c))

/-- The test function `ψ(h, J, x) = σ(q_i(h)(x) - μ_i(h))` for `J = (i, σ)`, and `0` for `J = m₀`. -/
noncomputable def psi {k : ℕ} (hk : 0 < k) (D : Measure X) (q : H → Fin k → X → ℝ)
    (y : H × Fin (2 * k + 1)) (x : X) : ℝ :=
  candS k y.2 * (q y.1 (candI hk y.2) x - muQ D q y.1 (candI hk y.2))

variable {n k : ℕ} (hk : 0 < k) (D : Measure X) (q : H → Fin k → X → ℝ)

omit [MeasurableSpace H] in
theorem muQ_mem [IsProbabilityMeasure D] (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (h : H)
    (i : Fin k) : muQ D q h i ∈ Set.Icc (0 : ℝ) 1 := by
  unfold muQ
  constructor
  · exact integral_nonneg fun x => (hq01 h i x).1
  · calc ∫ x, q h i x ∂D ≤ ∫ _x, (1 : ℝ) ∂D :=
          integral_mono_of_nonneg (Filter.Eventually.of_forall fun x => (hq01 h i x).1)
            (integrable_const 1) (Filter.Eventually.of_forall fun x => (hq01 h i x).2)
      _ = 1 := by simp

omit [MeasurableSpace X] [MeasurableSpace H] in
theorem thetaQ_mem (hn : 0 < n) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (S : Fin n → X)
    (h : H) (i : Fin k) : thetaQ q S h i ∈ Set.Icc (0 : ℝ) 1 := by
  unfold thetaQ
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  constructor
  · exact div_nonneg (Finset.sum_nonneg fun ℓ _ => (hq01 h i (S ℓ)).1) hn'.le
  · rw [div_le_one hn']
    calc ∑ ℓ, q h i (S ℓ) ≤ ∑ _ℓ : Fin n, (1 : ℝ) := Finset.sum_le_sum fun ℓ _ => (hq01 h i (S ℓ)).2
      _ = n := by simp

omit [MeasurableSpace H] in
theorem psi_nullC (h : H) (x : X) : psi hk D q (h, nullC k) x = 0 := by
  simp [psi, candS_nullC]

omit [MeasurableSpace H] in
theorem abs_psi_le [IsProbabilityMeasure D] (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (y : H × Fin (2 * k + 1)) (x : X) : |psi hk D q y x| ≤ 1 := by
  unfold psi
  rw [abs_mul]
  have h1 := abs_candS_le k y.2
  have h2 := hq01 y.1 (candI hk y.2) x
  have h3 := muQ_mem D q hq01 y.1 (candI hk y.2)
  have h4 : |q y.1 (candI hk y.2) x - muQ D q y.1 (candI hk y.2)| ≤ 1 := by
    rw [abs_le]
    constructor <;> linarith [h2.1, h2.2, h3.1, h3.2]
  calc |candS k y.2| * |q y.1 (candI hk y.2) x - muQ D q y.1 (candI hk y.2)| ≤ 1 * 1 :=
        mul_le_mul h1 h4 (abs_nonneg _) zero_le_one
    _ = 1 := one_mul 1

omit [MeasurableSpace H] in
/-- `|ψ(h, J, x)| ≤ 1_{J ≠ m₀}`. -/
theorem abs_psi_le_indicator [IsProbabilityMeasure D] (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (y : H × Fin (2 * k + 1)) (x : X) :
    |psi hk D q y x| ≤ if y.2 = nullC k then 0 else 1 := by
  split_ifs with hy
  · obtain ⟨h, c⟩ := y
    simp only at hy
    subst hy
    rw [psi_nullC, abs_zero]
  · exact abs_psi_le hk D q hq01 y x

/-- Centering: `E_{X' ∼ D} ψ(h, J, X') = 0`. -/
theorem integral_psi [IsProbabilityMeasure D] (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (y : H × Fin (2 * k + 1)) :
    ∫ x, psi hk D q y x ∂D = 0 := by
  unfold psi
  have hmeas : Measurable fun x => q y.1 (candI hk y.2) x :=
    (hqm (candI hk y.2)).comp (measurable_const.prodMk measurable_id)
  have hint : Integrable (fun x => q y.1 (candI hk y.2) x) D :=
    Integrable.mono' (integrable_const (1 : ℝ)) hmeas.aestronglyMeasurable
      (Filter.Eventually.of_forall fun x => by
        rw [Real.norm_eq_abs, abs_of_nonneg (hq01 _ _ x).1]
        exact (hq01 _ _ x).2)
  rw [integral_const_mul, integral_sub hint (integrable_const _), integral_const]
  simp [muQ]

omit [MeasurableSpace H] in
/-- `(1/n) ∑_ℓ ψ(h, J, X_ℓ) = u_J(S, h)` for `J ≠ m₀`. -/
theorem avg_psi (hn : 0 < n) (ν : ℝ) (S : Fin n → X) (h : H) {c : Fin (2 * k + 1)}
    (hc : c ≠ nullC k) :
    (∑ ℓ, psi hk D q (h, c) (S ℓ)) / n = score hk D q ν S h c := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
  unfold psi score thetaQ
  rw [if_neg hc]
  simp only
  rw [← Finset.mul_sum, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    nsmul_eq_mul]
  field_simp

omit [MeasurableSpace H] in
theorem avg_psi_nullC (S : Fin n → X) (h : H) :
    (∑ ℓ, psi hk D q (h, nullC k) (S ℓ)) / n = 0 := by
  simp [psi_nullC]

omit [MeasurableSpace H] in
/-- The scores have sensitivity `1/n` in the sample (for every fixed `h`). -/
theorem score_sens (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (ν : ℝ) {S S' : Fin n → X}
    (hSS' : DP.Neighbor S S') (h : H) (c : Fin (2 * k + 1)) :
    |score hk D q ν S h c - score hk D q ν S' h c| ≤ 1 / n := by
  unfold score
  split_ifs with hc
  · rw [sub_self, abs_zero]
    positivity
  · obtain ⟨i0, hi0⟩ := hSS'
    set i := candI hk c
    have hsum : ∑ ℓ, q h i (S ℓ) - ∑ ℓ, q h i (S' ℓ) = q h i (S i0) - q h i (S' i0) := by
      rw [← Finset.sum_sub_distrib]
      refine Finset.sum_eq_single i0 (fun ℓ _ hℓ => ?_) (fun h0 => absurd (Finset.mem_univ i0) h0)
      rw [hi0 ℓ hℓ, sub_self]
    have e : candS k c * (thetaQ q S h i - muQ D q h i) - candS k c * (thetaQ q S' h i - muQ D q h i) =
        candS k c * ((q h i (S i0) - q h i (S' i0)) / n) := by
      unfold thetaQ
      rw [← hsum]
      ring
    rw [e, abs_mul]
    have h1 := abs_candS_le k c
    have h2 : |(q h i (S i0) - q h i (S' i0)) / n| ≤ 1 / n := by
      rw [abs_div, Nat.abs_cast]
      apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg n)
      have a := hq01 h i (S i0)
      have b := hq01 h i (S' i0)
      rw [abs_le]
      constructor <;> linarith [a.1, a.2, b.1, b.2]
    calc |candS k c| * |(q h i (S i0) - q h i (S' i0)) / n| ≤ 1 * (1 / n) :=
          mul_le_mul h1 h2 (abs_nonneg _) zero_le_one
      _ = 1 / n := one_mul _

/-! ### Measurability -/

theorem measurable_thetaQ (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (i : Fin k) :
    Measurable (fun p : (Fin n → X) × H => thetaQ q p.1 p.2 i) := by
  unfold thetaQ
  refine Measurable.div_const (Finset.measurable_sum _ fun ℓ _ => ?_) _
  exact (hqm i).comp (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))

theorem measurable_muQ [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2))
    (i : Fin k) : Measurable (fun h => muQ D q h i) :=
  (StronglyMeasurable.integral_prod_right' (f := fun p : H × X => q p.1 i p.2)
    (hqm i).stronglyMeasurable).measurable

theorem measurable_score [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ν : ℝ)
    (c : Fin (2 * k + 1)) : Measurable (fun p : (Fin n → X) × H => score hk D q ν p.1 p.2 c) := by
  by_cases hc : c = nullC k
  · simp only [score, if_pos hc]
    exact measurable_const
  · simp only [score, if_neg hc]
    exact measurable_const.mul ((measurable_thetaQ q hqm _).sub
      ((measurable_muQ D q hqm _).comp measurable_snd))

theorem measurable_psi [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) :
    Measurable (fun p : (H × Fin (2 * k + 1)) × X => psi hk D q p.1 p.2) := by
  have hg : Measurable (fun r : (H × X) × Fin (2 * k + 1) => psi hk D q (r.1.1, r.2) r.1.2) := by
    refine measurable_from_prod_countable_left fun c => ?_
    show Measurable fun r : H × X =>
      candS k c * (q r.1 (candI hk c) r.2 - muQ D q r.1 (candI hk c))
    exact measurable_const.mul ((hqm _).sub ((measurable_muQ D q hqm _).comp measurable_fst))
  exact hg.comp ((measurable_fst.comp measurable_fst).prodMk measurable_snd |>.prodMk
    (measurable_snd.comp measurable_fst))

/-! ### The exponential-mechanism kernel and the composed kernel -/

/-- The ghost exponential mechanism `(S, h) ↦ J`: privacy `ε/2`, sensitivity `1/n`
(`Pr[J = c] ∝ exp(n ε u_c/4)`). -/
noncomputable def emK [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ε ν : ℝ) :
    Kernel ((Fin n → X) × H) (Fin (2 * k + 1)) :=
  DP.expMechKernel (ε / 2) (1 / n) (fun p => score hk D q ν p.1 p.2)
    (fun c => measurable_score hk D q hqm ν c)

instance [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ε ν : ℝ) :
    IsMarkovKernel (emK (n := n) hk D q hqm ε ν) := by
  unfold emK
  infer_instance

theorem emK_apply [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ε ν : ℝ)
    (p : (Fin n → X) × H) :
    emK hk D q hqm ε ν p = DP.expMech (ε / 2) (1 / n) (score hk D q ν p.1 p.2) := rfl

/-- The composed ghost kernel `S ↦ (h, J)`. -/
noncomputable def ghostK [SFinite D] (κ : Kernel (Fin n → X) H) (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2))
    (ε ν : ℝ) : Kernel (Fin n → X) (H × Fin (2 * k + 1)) :=
  κ ⊗ₖ emK hk D q hqm ε ν

instance [SFinite D] (κ : Kernel (Fin n → X) H) [IsMarkovKernel κ]
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ε ν : ℝ) :
    IsMarkovKernel (ghostK hk D q κ hqm ε ν) := by
  unfold ghostK
  infer_instance

/-- `S ↦ (h, J)` is `(ε, δ/2)`-DP: the `(ε/2, δ/2)`-DP map `S ↦ h` followed by the `(ε/2, 0)`-DP exponential
mechanism (no `e^{ε/2} δ/2` term, `DP.IsDP.compProd_of_pure`). -/
theorem ghostK_isDP [SFinite D] (hn : 0 < n) (κ : Kernel (Fin n → X) H) [IsMarkovKernel κ]
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2))
    (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) {ε δ : ℝ} (hε : 0 < ε) (ν : ℝ)
    (hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) :
    DP.IsDP DP.Neighbor (fun S => ghostK hk D q κ hqm ε ν S) ε (δ / 2) := by
  have hn' : (0 : ℝ) < 1 / n := by
    have : (0 : ℝ) < n := by exact_mod_cast hn
    positivity
  have hη : DP.IsDPKernel DP.Neighbor (fun S : Fin n → X => Kernel.sectR (emK hk D q hqm ε ν) S)
      (ε / 2) 0 := by
    intro h S S' hSS'
    simp only [Kernel.sectR_apply, emK_apply]
    exact DP.expMech_isDP DP.Neighbor (by positivity) hn' (fun S => score hk D q ν S h)
      (fun S S' hSS' c => score_sens hk D q hq01 ν hSS' h c) S S' hSS'
  have hcomp := DP.IsDP.compProd_of_pure (P := fun S : Fin n → X => κ S)
    (κ := fun S : Fin n → X => Kernel.sectR (emK hk D q hqm ε ν) S) hDP hη
  intro S S' hSS'
  have h2 := hcomp S S' hSS'
  simp only at h2
  rw [show ε / 2 + ε / 2 = ε by ring] at h2
  show DP.Indist ((κ ⊗ₖ emK hk D q hqm ε ν) S) ((κ ⊗ₖ emK hk D q hqm ε ν) S') ε (δ / 2)
  rw [Kernel.compProd_apply_eq_compProd_sectR, Kernel.compProd_apply_eq_compProd_sectR]
  exact h2

end Scores

end F2e2e.A.Ghost
