import F2e2e.A.Params
import F2e2e.SpecV1Compat
import F2e2e.Lib.Dist.Laplace
import F2e2e.Lib.Dist.BetaSym
import F2e2e.Lib.Opt.EntropicWaterFill

/-!
# Part I: the mechanism of Definition `I:def:mechanism` as a Lean function

Paper: `parts/partI.tex` L293-393 (conventions `Lap`, `clip`, `sign` at L297; Definition `I:def:mechanism`),
with the parameters of Definition `I:def:locked_parameters` (`F2e2e/Spec.lean` §1.1 and
`F2e2e/A/Params.lean`).

## Randomness: an explicit finite product of independent noises
The mechanism's coin space is `AdaOmega k α = NoiseIdx k L → ℝ` (`L = adaL α`) with the product law
`adaNoiseMeasure k α β = Measure.pi (noiseLaw k α β)` of the following independent noise variables:
* `beta i` (`i < k`): the Stage-1 Beta draw of round `i`, recorded as `V_i = 2B_i - 1 ∼ betaSym m`
  (`m = p₁ - 1 = adaBetaM α β`, density `∝ (1 - v²)^m` on `(-1, 1)`); the mechanism uses
  `ξ_i = R₁ · clampUnit(V_i)`, which has the law of `R₁(2B_i - 1)` and satisfies `|ξ_i| < R₁` for every
  realization (`Dist.clampUnit`, `Dist.map_clampUnit_betaSym`);
* `nu i r` (`i < k`, stage `r ≤ L`): the per-query AboveThreshold noise `ν_i^{(r)} ∼ Lap(2 b_SVT)`;
* `zeta i r`: the release noise `ζ_i^{(r)} ∼ Lap(b_SVT)`, used by the trigger release of stage `r` in round
  `i` (Step 2(c)) or by its retroactive predecessor release (B1); at most one of the two happens in a round;
* `rho r e` (stage `r ≤ L`, episode `e ≤ k`): the threshold noise `ρ^{(r)} ∼ Lap(b_SVT)` of the `e`-th
  AboveThreshold episode of stage `r` (episodes are numbered from `0`; the current episode of stage `r` is
  `M_r - 1`, and `M_r ≤ 1 + i ≤ k` at the start of round `i < k`).
Indices of stages `0, 1` for `ν, ζ, ρ` exist but are never used. Drawing the noise of the paper "when it is
needed" or reading it from this table gives the same joint law; the mechanism is *defined* on the table.

## The deterministic mechanism
* `ChainData`: the inputs of the first-trigger chain of one active round (Step 2): the means `θ_r`, the
  Stage-1 proposal `c₁`, the current noises; `ChainData.orig r` is the active (origin, proposal) pair
  before stage `r` is tested, `ufinal`, `answer`, `Trig r` (`b_i^{(r)} = 1`), `Released r`.
* `RoundRec`: the public record `h_i` of a round (pass/trigger bits, origins, releases `v`/`c`, `u_final`,
  answer `a_i`, the public sign `s` (Case A: `s^{(1)}_{t₁}`; Case B: `s_{i,r*}`), impulses `δ_{m,i}`; with the
  unified Stage-1 impulse `δ_{1,i} = -η₁ s^{(1)}_{t₁}` of L1560).
* `MState`: the state at the start of a round (HALT, `t₁`, `N_{r*}`, `M_r`, and per level `r` the cumulative
  payoff `x^{(r)} = ∑_{j<i} δ_{r,j} q_j(S_r)`: Stage 1 stores `x^{(1)} = η₁ G^{(1)}`, validators store
  `L^{(m)}`). The FTRL weights are `P^{(r)} = Opt.waterFill n_r 1 x^{(r)}` (`= P*(G^{(1)})` at rate `η₁` for
  Stage 1 by `Opt.waterFill_eq_unit`; `= argmin ⟨P, -L^{(m)}⟩ + KL(P ‖ Unif)` for validators, eq.
  `I:eq:validator_ftrl_minimizer`), and `P^{(L)} = Unif(S_L)`.
* `step`: one round (halted round, or Steps 1-3); `run k α β qv ω i`: the state after rounds `0, …, i-1`
  on the query-value sequence `qv`; `roundRec`: the record of round `i`.
* `adaMech k α β : ADAMechanism (adaSampleSize k α β) (AdaOmega k α)`: round `i` recomputes rounds
  `0, …, i` from the values of queries `0, …, i` on the sample and outputs `a_i`.
* `DetAnalyst X`, `onlineRun`, `transcript`: the interaction with a deterministic analyst (used by the
  analysis, Lemma `I:lem:tonelli_fubini`(ii)).

Rounds are numbered `0, …, k-1` (paper: `1, …, k`); stages are `1, …, L` as in the paper.
-/

namespace F2e2e

namespace A

open MeasureTheory

/-! ## The noise index type and the coin space -/

/-- The independent noise variables of the mechanism (see the module docstring). -/
inductive NoiseIdx (k L : ℕ) : Type
  | beta : Fin k → NoiseIdx k L
  | nu : Fin k → Fin (L + 1) → NoiseIdx k L
  | zeta : Fin k → Fin (L + 1) → NoiseIdx k L
  | rho : Fin (L + 1) → Fin (k + 1) → NoiseIdx k L

namespace NoiseIdx

/-- `NoiseIdx k L` as a sum of finite types. -/
def equivSum (k L : ℕ) :
    NoiseIdx k L ≃
      Fin k ⊕ (Fin k × Fin (L + 1)) ⊕ (Fin k × Fin (L + 1)) ⊕ (Fin (L + 1) × Fin (k + 1)) where
  toFun
    | beta i => Sum.inl i
    | nu i r => Sum.inr (Sum.inl (i, r))
    | zeta i r => Sum.inr (Sum.inr (Sum.inl (i, r)))
    | rho r e => Sum.inr (Sum.inr (Sum.inr (r, e)))
  invFun
    | Sum.inl i => beta i
    | Sum.inr (Sum.inl p) => nu p.1 p.2
    | Sum.inr (Sum.inr (Sum.inl p)) => zeta p.1 p.2
    | Sum.inr (Sum.inr (Sum.inr p)) => rho p.1 p.2
  left_inv x := by cases x <;> rfl
  right_inv x := by rcases x with i | p | p | p <;> rfl

instance (k L : ℕ) : DecidableEq (NoiseIdx k L) := (equivSum k L).decidableEq

instance (k L : ℕ) : Fintype (NoiseIdx k L) := Fintype.ofEquiv _ (equivSum k L).symm

/-- The stage owning a noise variable: `1` for the Beta draws (Stage 1), `r` for `ν_i^{(r)}`, `ζ_i^{(r)}`,
`ρ^{(r)}_e`. -/
def stage {k L : ℕ} : NoiseIdx k L → ℕ
  | beta _ => 1
  | nu _ r => r.val
  | zeta _ r => r.val
  | rho r _ => r.val

end NoiseIdx

/-- The law of each noise variable: `betaSym (p₁ - 1)` for the Beta draws (the law of `2B - 1`,
`B ∼ Beta(p₁, p₁)`), `Lap(2 b_SVT)` for `ν`, `Lap(b_SVT)` for `ζ` and `ρ`. -/
noncomputable def noiseLaw (k : ℕ) (α β : ℝ) : NoiseIdx k (adaL α) → Measure ℝ
  | .beta _ => Dist.betaSym (adaBetaM α β)
  | .nu _ _ => laplace (2 * adaBsvt k α β)
  | .zeta _ _ => laplace (adaBsvt k α β)
  | .rho _ _ => laplace (adaBsvt k α β)

instance isProbabilityMeasure_noiseLaw (k : ℕ) (α β : ℝ) (j : NoiseIdx k (adaL α)) :
    IsProbabilityMeasure (noiseLaw k α β j) := by
  cases j with
  | beta _ => exact Dist.isProbabilityMeasure_betaSym _
  | nu _ _ => exact isProbabilityMeasure_laplace _
  | zeta _ _ => exact isProbabilityMeasure_laplace _
  | rho _ _ => exact isProbabilityMeasure_laplace _

/-- The mechanism's coin space `Ω_M = (NoiseIdx k L → ℝ)` (`L = adaL α`). -/
abbrev AdaOmega (k : ℕ) (α : ℝ) : Type := NoiseIdx k (adaL α) → ℝ

/-- The mechanism's coin law `P_M`: the product of the per-index noise laws. -/
noncomputable def adaNoiseMeasure (k : ℕ) (α β : ℝ) : Measure (AdaOmega k α) :=
  Measure.pi (noiseLaw k α β)

instance isProbabilityMeasure_adaNoiseMeasure (k : ℕ) (α β : ℝ) :
    IsProbabilityMeasure (adaNoiseMeasure k α β) := by
  unfold adaNoiseMeasure
  infer_instance

section Lookup

variable {k : ℕ} {α : ℝ}

/-- `V_i` (the Stage-1 Beta draw of round `i`, as `2B_i - 1`); `0` for `i ≥ k`. -/
noncomputable def noiseBeta (ω : AdaOmega k α) (i : ℕ) : ℝ :=
  if h : i < k then ω (.beta ⟨i, h⟩) else 0

/-- `ν_i^{(r)} ∼ Lap(2 b_SVT)`; `0` out of range. -/
noncomputable def noiseNu (ω : AdaOmega k α) (i r : ℕ) : ℝ :=
  if h : i < k ∧ r < adaL α + 1 then ω (.nu ⟨i, h.1⟩ ⟨r, h.2⟩) else 0

/-- `ζ_i^{(r)} ∼ Lap(b_SVT)`; `0` out of range. -/
noncomputable def noiseZeta (ω : AdaOmega k α) (i r : ℕ) : ℝ :=
  if h : i < k ∧ r < adaL α + 1 then ω (.zeta ⟨i, h.1⟩ ⟨r, h.2⟩) else 0

/-- `ρ^{(r)}_e ∼ Lap(b_SVT)`, the threshold noise of episode `e` of stage `r`; `0` out of range. -/
noncomputable def noiseRho (ω : AdaOmega k α) (r e : ℕ) : ℝ :=
  if h : r < adaL α + 1 ∧ e < k + 1 then ω (.rho ⟨r, h.1⟩ ⟨e, h.2⟩) else 0

end Lookup

noncomputable section

/-! ## Conventions (L297) -/

/-- `clip(x, [0,1]) = min(1, max(0, x))`. -/
def clip01 (x : ℝ) : ℝ := min 1 (max 0 x)

/-- The paper's sign: `sign(x) = +1` if `x ≥ 0` and `-1` if `x < 0` (`sign 0 = +1`, unlike `Real.sign`). -/
def sgn1 (x : ℝ) : ℝ := if 0 ≤ x then 1 else -1

/-! ## The first-trigger interception chain of one active round (Step 2) -/

/-- The inputs of the first-trigger chain of one active round: the depth `L`, the thresholds `τ_{(u,r)}`,
the start-of-round empirical means `θ_r` (`1 ≤ r ≤ L`), the clipped Stage-1 proposal `c₁ = c_i^{(1)}`, and,
for the stages `2 ≤ r ≤ L`, the current episode threshold noise `ρ_r`, the per-query noise `ν_r` and the
release noise `ζ_r` of this round. -/
structure ChainData : Type where
  L : ℕ
  tau : ℕ → ℕ → ℝ
  theta : ℕ → ℝ
  c1 : ℝ
  rho : ℕ → ℝ
  nu : ℕ → ℝ
  zeta : ℕ → ℝ

namespace ChainData

variable (d : ChainData)

/-- The unclipped release of stage `r`: `v_i^{(r)} = θ_r + ζ_r` (`I:eq:trigger_release`,
`I:eq:retroactive_release`). -/
def relV (r : ℕ) : ℝ := d.theta r + d.zeta r

/-- The clipped release of stage `r`: `c_i^{(r)} = clip(v_i^{(r)}, [0,1])`. -/
def relC (r : ℕ) : ℝ := clip01 (d.relV r)

/-- The AboveThreshold test of stage `r` on the proposal `cu` from origin `u` (`I:eq:svt_test`):
`|c^{(u)} - θ_r| + ν_r ≥ τ_{(u,r)} + ρ_r` (TRIGGER). -/
def Fires (r u : ℕ) (cu : ℝ) : Prop := d.tau u r + d.rho r ≤ |cu - d.theta r| + d.nu r

instance (r u : ℕ) (cu : ℝ) : Decidable (d.Fires r u cu) := by
  unfold Fires
  infer_instance

/-- The active (origin `u`, proposal `c^{(u)}`) pair just before stage `r` is tested: `(1, c₁)` for `r ≤ 2`;
after a TRIGGER at stage `r` (`2 ≤ r ≤ L`) the origin becomes `r` with proposal `c^{(r)}`. -/
def orig : ℕ → ℕ × ℝ
  | 0 => (1, d.c1)
  | r + 1 =>
      if 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (orig r).1 (orig r).2 then (r, d.relC r) else orig r

/-- Stage `r` triggers in this round (`b_i^{(r)} = 1`; `2 ≤ r ≤ L`). -/
def Trig (r : ℕ) : Prop := 2 ≤ r ∧ r ≤ d.L ∧ d.Fires r (d.orig r).1 (d.orig r).2

instance (r : ℕ) : Decidable (d.Trig r) := by
  unfold Trig
  infer_instance

/-- The predecessor origin `u_prev(r)` of stage `r` (the origin whose proposal stage `r` tests). -/
def uprev (r : ℕ) : ℕ := (d.orig r).1

/-- The proposal `c^{(u_prev(r))}` tested by stage `r`. -/
def cprev (r : ℕ) : ℝ := (d.orig r).2

/-- The final origin `u_final ∈ {1, …, L}` (`1` iff all stages passed, else the highest trigger). -/
def ufinal : ℕ := (d.orig (d.L + 1)).1

/-- The answer `a_i = c_i^{(u_final)}` (`I:eq:final_answer_ai`). -/
def answer : ℝ := (d.orig (d.L + 1)).2

/-- Stage `r ≥ 2` publishes a scalar release in this round: its trigger release (Step 2(c)) or the
retroactive predecessor release of Case B (B1, stage `r* - 1` with `r* = u_final ≥ 3`). -/
def Released (r : ℕ) : Prop := d.Trig r ∨ (3 ≤ d.ufinal ∧ r + 1 = d.ufinal)

instance (r : ℕ) : Decidable (d.Released r) := by
  unfold Released
  infer_instance

/-- The public sign of Step 3: Case A (`u_final = 2`): `s^{(1)}_{t₁} = sign(c_i^{(1)} - a_i)`
(`I:eq:stage1_sign`); Case B (`u_final = r* ≥ 3`): `s_{i,r*} = sign(c_i^{(u_prev(r*))} - c_i^{(r*)})`
(`I:eq:trigger_sign_def`); `0` in Case 0. (In Case A, `u_prev(2) = 1` and `c^{(1)} = c₁`.) -/
def sgn : ℝ := if 2 ≤ d.ufinal then sgn1 (d.cprev d.ufinal - d.answer) else 0

/-- The end-of-round impulses: Case A: `δ_{1,i} = -η₁ s` (L1560), Case B (`u_final = r*`):
`δ_{r*-1,i} = -η_{r*-1} s`, `δ_{r*,i} = +η̃_{r*} s` (`I:eq:delta_mi_def`; `η̃_L = 0`), all others `0`. -/
def delta (eta1 eta : ℝ) (etaT : ℕ → ℝ) (m : ℕ) : ℝ :=
  if d.ufinal = 2 then (if m = 1 then -eta1 * d.sgn else 0)
  else if 3 ≤ d.ufinal then
    (if m + 1 = d.ufinal then -eta * d.sgn else if m = d.ufinal then etaT m * d.sgn else 0)
  else 0

end ChainData

/-! ## The public record of a round -/

/-- The public record of a round (`h_i` without the query): `active = false` for a halted round (then
everything else is `0`/`false`); `trig r = b_i^{(r)}`, `uprev r = u_prev(r)` (meaningful when `trig r`),
`rel r` (stage `r ≥ 2` released a scalar), `v r`, `c r` (the released unclipped / clipped values `v_i^{(r)}`,
`c_i^{(r)}`, `0` if not released; `c 1 = c_i^{(1)}`), `ufinal = u_final`, `answer = a_i`, `sgn` (the public
sign of Step 3, `0` in Case 0), `delta m = δ_{m,i}` (`m = 1`: the Stage-1 impulse `-η₁ s^{(1)}`). -/
structure RoundRec : Type where
  active : Bool
  trig : ℕ → Bool
  uprev : ℕ → ℕ
  rel : ℕ → Bool
  v : ℕ → ℝ
  c : ℕ → ℝ
  ufinal : ℕ
  answer : ℝ
  sgn : ℝ
  delta : ℕ → ℝ

/-- The record as a tuple (defines its measurable structure). -/
def RoundRec.toTuple (h : RoundRec) :
    Bool × (ℕ → Bool) × (ℕ → ℕ) × (ℕ → Bool) × (ℕ → ℝ) × (ℕ → ℝ) × ℕ × ℝ × ℝ × (ℕ → ℝ) :=
  (h.active, h.trig, h.uprev, h.rel, h.v, h.c, h.ufinal, h.answer, h.sgn, h.delta)

theorem RoundRec.toTuple_injective : Function.Injective RoundRec.toTuple := by
  intro a b h
  cases a
  cases b
  simp only [RoundRec.toTuple, Prod.mk.injEq] at h
  obtain ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10⟩ := h
  subst h1 h2 h3 h4 h5 h6 h7 h8 h9 h10
  rfl

/-- The measurable structure of records: the one induced by `RoundRec.toTuple` (products of the discrete
`Bool`, `ℕ`, the Borel `ℝ` and countable products of these). -/
instance : MeasurableSpace RoundRec := MeasurableSpace.comap RoundRec.toTuple inferInstance

theorem RoundRec.measurable_toTuple : Measurable RoundRec.toTuple := comap_measurable _

theorem RoundRec.measurable_active : Measurable RoundRec.active :=
  measurable_fst.comp RoundRec.measurable_toTuple

theorem RoundRec.measurable_trig : Measurable RoundRec.trig :=
  measurable_fst.comp (measurable_snd.comp RoundRec.measurable_toTuple)

theorem RoundRec.measurable_uprev : Measurable RoundRec.uprev :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp RoundRec.measurable_toTuple))

theorem RoundRec.measurable_rel : Measurable RoundRec.rel :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    RoundRec.measurable_toTuple)))

theorem RoundRec.measurable_v : Measurable RoundRec.v :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp RoundRec.measurable_toTuple))))

theorem RoundRec.measurable_c : Measurable RoundRec.c :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp (measurable_snd.comp RoundRec.measurable_toTuple)))))

theorem RoundRec.measurable_ufinal : Measurable RoundRec.ufinal :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp RoundRec.measurable_toTuple))))))

theorem RoundRec.measurable_answer : Measurable RoundRec.answer :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
      RoundRec.measurable_toTuple)))))))

theorem RoundRec.measurable_sgn : Measurable RoundRec.sgn :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
      (measurable_snd.comp RoundRec.measurable_toTuple))))))))

theorem RoundRec.measurable_delta : Measurable RoundRec.delta :=
  measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
      (measurable_snd.comp RoundRec.measurable_toTuple))))))))

/-- A map into `RoundRec` is measurable iff its tuple is. -/
theorem RoundRec.measurable_iff {Ω : Type*} [MeasurableSpace Ω] {f : Ω → RoundRec} :
    Measurable f ↔ Measurable (fun ω => (f ω).toTuple) := by
  refine ⟨fun h => RoundRec.measurable_toTuple.comp h, fun h => ?_⟩
  rw [measurable_iff_comap_le]
  have : MeasurableSpace.comap f (MeasurableSpace.comap RoundRec.toTuple inferInstance) =
      MeasurableSpace.comap (fun ω => (f ω).toTuple) inferInstance := by
    rw [MeasurableSpace.comap_comp]
    rfl
  change MeasurableSpace.comap f (MeasurableSpace.comap RoundRec.toTuple inferInstance) ≤ _
  rw [this]
  exact h.comap_le

/-- The record of a halted round: `a_i = 0`, `δ_{m,i} = 0`. -/
def RoundRec.halted : RoundRec :=
  ⟨false, fun _ => false, fun _ => 0, fun _ => false, fun _ => 0, fun _ => 0, 0, 0, 0, fun _ => 0⟩

/-- The record of an active round with chain data `d` (step sizes `η₁`, `η = γ/8`, `η̃`). -/
def ChainData.toRec (d : ChainData) (eta1 eta : ℝ) (etaT : ℕ → ℝ) : RoundRec where
  active := true
  trig r := decide (d.Trig r)
  uprev r := d.uprev r
  rel r := decide (d.Released r)
  v r := if d.Released r then d.relV r else 0
  c r := if r = 1 then d.c1 else if d.Released r then d.relC r else 0
  ufinal := d.ufinal
  answer := d.answer
  sgn := d.sgn
  delta m := d.delta eta1 eta etaT m

/-! ## The mechanism state -/

variable {k : ℕ} {α β : ℝ}

/-- The state at the start of a round: `halt` (HALT), `t1` (`t₁`), `N r` (`N_r`, `3 ≤ r ≤ L`), `M r` (the
episode counter `M_r`, `2 ≤ r ≤ L`, initially `1`), and `pay r` (the cumulative payoff `x^{(r)}` of level
`1 ≤ r ≤ L-1` on its block: `η₁ G^{(1)}` for `r = 1`, `L^{(m)}` for `2 ≤ m ≤ L-1`; unused for `r = L`). -/
structure MState (k : ℕ) (α β : ℝ) : Type where
  halt : Bool
  t1 : ℕ
  N : ℕ → ℕ
  M : ℕ → ℕ
  pay : (r : ℕ) → Fin (adaBlock k α β r) → ℝ

/-- The initial state (State Initialization (i)-(vi)). -/
def MState.init : MState k α β := ⟨false, 0, fun _ => 0, fun _ => 1, fun _ _ => 0⟩

/-- The start-of-round FTRL weights `P^{(r)}` of level `r`: `Opt.waterFill n_r 1 x^{(r)}` for `r ≠ L`, and the
uniform weights `Unif(S_L)` on the anchor. -/
def MState.weight (st : MState k α β) (r : ℕ) : Fin (adaBlock k α β r) → ℝ :=
  if r = adaL α then fun _ => 1 / (adaBlock k α β r : ℝ)
  else Opt.waterFill (adaBlock k α β r) 1 (st.pay r)

/-- The start-of-round weighted empirical mean `θ_i^{(r)}(S_r) = ⟨P^{(r)}, q_i(S_r)⟩` (`I:eq:theta_def`), for
the values `q : Fin n → ℝ` of the round's query on the sample. -/
def MState.theta (st : MState k α β) (q : Fin (adaSampleSize k α β) → ℝ) (r : ℕ) : ℝ :=
  ∑ ℓ, st.weight r ℓ * q (adaBlockIdx k α β r ℓ)

/-- The unclipped Stage-1 proposal `v_i^{(1)} = θ_i^{(1)}(S_1) + ξ_i`, `ξ_i = R₁ · clampUnit(V_i)`
(`I:eq:c1_proposal`). -/
def stage1Release (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : ℝ :=
  st.theta q 1 + adaR1 α * Dist.clampUnit (noiseBeta ω i)

/-- The chain data of the (active) round `i` from the state, the query values and the noise. The current
episode of stage `r` is `M_r - 1`. -/
def roundChain (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : ChainData where
  L := adaL α
  tau := adaTau α
  theta := st.theta q
  c1 := clip01 (stage1Release st i q ω)
  rho r := noiseRho ω r (st.M r - 1)
  nu r := noiseNu ω i r
  zeta r := noiseZeta ω i r

/-- The record of the active round `i`. -/
def activeRec (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ)
    (ω : AdaOmega k α) : RoundRec :=
  (roundChain st i q ω).toRec (adaEta1 α) (adaEta α) (adaEtaTilde α)

/-- The end-of-round state update (Step 3) from the record `rec` of an active round: Case A
(`u_final = 2`): `t₁ ← t₁ + 1`, Stage-1 payoff update, reset of stage 2, HALT iff `t₁ = T_{1,max}`;
Case B (`u_final = r* ≥ 3`): payoff updates of levels `r* - 1, r*`, `N_{r*} ← N_{r*} + 1`, resets of stages
`2, …, r*`, HALT iff `N_{r*} = N_{r*,max}`; Case 0: nothing. -/
def MState.next (st : MState k α β) (q : Fin (adaSampleSize k α β) → ℝ) (rec : RoundRec) :
    MState k α β where
  halt := decide ((rec.ufinal = 2 ∧ st.t1 + 1 = adaT1max α) ∨
    (3 ≤ rec.ufinal ∧ st.N rec.ufinal + 1 = adaNmax α rec.ufinal))
  t1 := st.t1 + if rec.ufinal = 2 then 1 else 0
  N r := st.N r + if 3 ≤ rec.ufinal ∧ r = rec.ufinal then 1 else 0
  M r := st.M r + if 2 ≤ r ∧ r ≤ rec.ufinal then 1 else 0
  pay r ℓ := st.pay r ℓ + rec.delta r * q (adaBlockIdx k α β r ℓ)

/-- One round: a halted round outputs `0` and changes nothing; an active round runs Steps 1-3. -/
def step (st : MState k α β) (i : ℕ) (q : Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) :
    MState k α β × RoundRec :=
  if st.halt then (st, RoundRec.halted)
  else (st.next q (activeRec st i q ω), activeRec st i q ω)

/-- The state at the start of round `i` when the queries of rounds `j < i` take the values `qv j` on the
sample. -/
def run (k : ℕ) (α β : ℝ) (qv : ℕ → Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α) :
    ℕ → MState k α β
  | 0 => MState.init
  | i + 1 => (step (run k α β qv ω i) i (qv i) ω).1

/-- The record of round `i`. -/
def roundRec (k : ℕ) (α β : ℝ) (qv : ℕ → Fin (adaSampleSize k α β) → ℝ) (ω : AdaOmega k α)
    (i : ℕ) : RoundRec :=
  (step (run k α β qv ω i) i (qv i) ω).2

/-- Extend the values of the queries of rounds `0, …, i` to a sequence (junk `0` afterwards). -/
def extendVals {i n : ℕ} (vals : Fin (i + 1) → Fin n → ℝ) : ℕ → Fin n → ℝ :=
  fun j => if h : j < i + 1 then vals ⟨j, h⟩ else fun _ => 0

/-- **The mechanism `𝓜` of Definition `I:def:mechanism`** with the locked parameters, as an `ADAMechanism`:
in round `i` it recomputes rounds `0, …, i` from the values of the queries `0, …, i` on the sample and its
noise table, and outputs `a_i`. -/
def adaMech (k : ℕ) (α β : ℝ) : ADAMechanism (adaSampleSize k α β) (AdaOmega k α) :=
  fun i vals ω => (roundRec k α β (extendVals vals) ω i).answer

/-! ## Deterministic analysts and the transcript -/

/-- A deterministic adaptive analyst: in round `i` it picks the query `X → ℝ` from the public records
`h_0, …, h_{i-1}` of the `i` previous rounds (Lemma `I:lem:tonelli_fubini`; the analyst observes the public
transcript prefix `h_{<i}`, L45). A record contains the round's answer `a_j` and its public auxiliary record
`τ_aux,j` (Definition `I:def:mechanism`). -/
def DetAnalyst (X : Type) : Type := (i : ℕ) → (Fin i → RoundRec) → X → ℝ

/-- Every query takes values in `[0, 1]`. -/
def DetAnalyst.Valid {X : Type} (A : DetAnalyst X) : Prop :=
  ∀ (i : ℕ) (h : Fin i → RoundRec) (x : X), 0 ≤ A i h x ∧ A i h x ≤ 1

/-- Joint measurability of `(h, x) ↦ A_i(h)(x)` for every round `i`. -/
def DetAnalyst.JointlyMeasurable {X : Type} [MeasurableSpace X] (A : DetAnalyst X) : Prop :=
  ∀ i : ℕ, Measurable (fun p : (Fin i → RoundRec) × X => A i p.1 p.2)

/-- A deterministic analyst that only sees the previous answers `a_0, …, a_{i-1}` (the deterministic analysts of
the Spec v1 interface `ADAGuarantee`). -/
def AnsAnalyst (X : Type) : Type := (i : ℕ) → (Fin i → ℝ) → X → ℝ

/-- Every query of an answer-only analyst takes values in `[0, 1]`. -/
def AnsAnalyst.Valid {X : Type} (A : AnsAnalyst X) : Prop :=
  ∀ (i : ℕ) (h : Fin i → ℝ) (x : X), 0 ≤ A i h x ∧ A i h x ≤ 1

/-- Joint measurability of `(h, x) ↦ A_i(h)(x)` for an answer-only analyst. -/
def AnsAnalyst.JointlyMeasurable {X : Type} [MeasurableSpace X] (A : AnsAnalyst X) : Prop :=
  ∀ i : ℕ, Measurable (fun p : (Fin i → ℝ) × X => A i p.1 p.2)

/-- An answer-only analyst as a Spec v1 analyst with the trivial coin space `Unit`. -/
def AnsAnalyst.toADA {X : Type} (A : AnsAnalyst X) : ADAAnalyst X Unit := fun i h _ x => A i h x

/-- An answer-only analyst as a record-seeing analyst: it reads the answers off the records. -/
def AnsAnalyst.toDet {X : Type} (A : AnsAnalyst X) : DetAnalyst X :=
  fun i h x => A i (fun j => (h j).answer) x

theorem AnsAnalyst.valid_toDet {X : Type} {A : AnsAnalyst X} (hA : A.Valid) : A.toDet.Valid :=
  fun i h x => hA i (fun j => (h j).answer) x

theorem AnsAnalyst.jointlyMeasurable_toDet {X : Type} [MeasurableSpace X] {A : AnsAnalyst X}
    (hA : A.JointlyMeasurable) : A.toDet.JointlyMeasurable := fun i =>
  (hA i).comp ((measurable_pi_lambda _ fun j => RoundRec.measurable_answer.comp
    ((measurable_pi_apply j).comp measurable_fst)).prodMk measurable_snd)

/-- The interaction of `𝓜` with the deterministic analyst `A` on the sample `S` with noise `ω`: the state
after `i` rounds and the records of rounds `0, …, i-1`; the query of round `i` is
`q_i = A_i(h_0, …, h_{i-1})` (the analyst sees the records of the previous rounds). -/
def onlineRun (k : ℕ) (α β : ℝ) {X : Type} (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) : (i : ℕ) → MState k α β × (Fin i → RoundRec)
  | 0 => (MState.init, Fin.elim0)
  | i + 1 =>
      ((step (onlineRun k α β A S ω i).1 i
          (fun ℓ => A i (onlineRun k α β A S ω i).2 (S ℓ)) ω).1,
        Fin.snoc (α := fun _ => RoundRec) (onlineRun k α β A S ω i).2
          (step (onlineRun k α β A S ω i).1 i
            (fun ℓ => A i (onlineRun k α β A S ω i).2 (S ℓ)) ω).2)

/-- The full public transcript `h = (h_0, …, h_{k-1})` of the interaction (records only; the queries are
`q_i = A_i(answers before i)`). -/
def transcript (k : ℕ) (α β : ℝ) {X : Type} (A : DetAnalyst X) (S : Fin (adaSampleSize k α β) → X)
    (ω : AdaOmega k α) : Fin k → RoundRec :=
  (onlineRun k α β A S ω k).2

/-- What the analyst sees of a record sequence `h_0, …, h_{i-1}`: the records themselves. (This is the identity
on `RoundRec` histories; the name is historical, from when the analyst only saw the answers.) -/
def answersOf {i : ℕ} (h : Fin i → RoundRec) : Fin i → RoundRec := h

end

end A

end F2e2e
