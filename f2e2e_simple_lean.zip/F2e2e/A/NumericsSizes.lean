import F2e2e.A.NumericsBasic

/-!
# Part I numerics: every block of the sample has at least two points

The KKT water-filling lemma (`I:lem:kkt_sensitivity`, `parts/partI.tex` L130-186) is stated for subsample
sizes `n_r ≥ 2`. For `k ≥ 1`, `0 < α < 1/16`, `0 < β < 1/2`:
* `n₁ = ⌈32000 √k χ₁/α + 16000 L₁³/α²⌉ ≥ 2` (the second term alone exceeds `16000·13³·256`);
* `n_r = ⌈110 √(M_{r,max} L_val)/(b_SVT ε_r)⌉ ≥ 2` for every `r ≥ 1` (`b_SVT < u₀ < 1/20480`,
  `ε_r ≤ 1/20`, `M_{r,max} ≥ 1`, `L_val > 49`);
* `n_L ≥ 2` (same estimate for its first term, the Ghost-Monitor term is positive).
-/

namespace F2e2e

namespace A

section Sizes

variable {α β : ℝ}

/-- `2 ≤ ⌈x⌉₊` as soon as `1 < x`. -/
lemma two_le_ceil_of_one_lt {x : ℝ} (hx : 1 < x) : 2 ≤ ⌈x⌉₊ := by
  have : (1 : ℕ) < ⌈x⌉₊ := Nat.lt_ceil.mpr (by exact_mod_cast hx)
  omega

/-- `n₁ ≥ 2`. -/
lemma two_le_adaN1 (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) (k : ℕ) :
    2 ≤ adaN1 k α β := by
  unfold adaN1
  apply two_le_ceil_of_one_lt
  have hχ := adaChi1_nonneg hα hα' hβ hβ'
  have hL1 := adaL1_gt hα hα' hβ hβ'
  have h1 : 0 ≤ 32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α :=
    div_nonneg (mul_nonneg (by positivity) hχ) hα.le
  have hα2 : 0 < α ^ 2 := by positivity
  have hα21 : α ^ 2 < 1 := by
    have : α ^ 2 < (1 / 16) ^ 2 := by gcongr
    linarith
  have h2 : 1 < 16000 * adaL1 α β ^ 3 / α ^ 2 := by
    rw [lt_div_iff₀ hα2]
    have h3 : (13 : ℝ) ^ 3 ≤ adaL1 α β ^ 3 := by gcongr
    nlinarith
  linarith

/-- `n_r ≥ 2` for every stage `r ≥ 1` (in particular `2 ≤ r ≤ L - 1`). -/
lemma two_le_adaNr (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) {r : ℕ} (hr : 1 ≤ r) : 2 ≤ adaNr k α β r := by
  unfold adaNr
  apply two_le_ceil_of_one_lt
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hb' := adaBsvt_lt_u0 hα hα' hβ hβ' hk
  have hu := adaU0_lt hα hα'
  have hE := adaEps_pos hα r
  have hE' := adaEps_le_one_twentieth hα hα' hr
  have hM := one_le_adaMmax_real α r
  have hLv := adaLval_gt hα hα' hβ hβ'
  have hsq : 7 ≤ Real.sqrt ((adaMmax α r : ℝ) * adaLval α β) := by
    rw [Real.le_sqrt (by norm_num) (by positivity)]
    nlinarith
  rw [lt_div_iff₀ (mul_pos hb hE)]
  have hbE : adaBsvt k α β * adaEps α r ≤ 1 / 20480 * (1 / 20) :=
    mul_le_mul (by linarith) hE' hE.le (by norm_num)
  nlinarith

/-- `n_L ≥ 2`. -/
lemma two_le_adaNL (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2) {k : ℕ}
    (hk : 1 ≤ k) : 2 ≤ adaNL k α β := by
  unfold adaNL
  apply two_le_ceil_of_one_lt
  have hb := adaBsvt_pos hα hα' hβ hβ' hk
  have hb' := adaBsvt_lt_u0 hα hα' hβ hβ' hk
  have hu := adaU0_lt hα hα'
  have hεL := adaEpsL_pos hα
  have hεL' : adaEpsL α ≤ 1 / 20 := by
    have h1 := adaEpsL_lt_adaEps hα hα'
    have h5 := five_le_adaL hα hα'
    have h2 := adaEps_le_one_twentieth hα hα' (r := adaL α - 1) (by omega)
    linarith
  have hranc := adaRanc_pos hα
  have hlog6 : 0 < Real.log (6 * (k : ℝ) / adaDeltaVal α β) := by
    have := log_six_k_gt hα hα' hβ hβ' hk
    linarith
  have hM := one_le_adaMmax_real α (adaL α)
  have hLv := adaLval_gt hα hα' hβ hβ'
  have hsq : 7 ≤ Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) := by
    rw [Real.le_sqrt (by norm_num) (by positivity)]
    nlinarith
  have h2 : 0 ≤ 16 * Real.log (6 * (k : ℝ) / adaDeltaVal α β) / (adaRanc α * adaEpsL α) :=
    div_nonneg (by positivity) (mul_pos hranc hεL).le
  have h1 : 1 < 55 * Real.sqrt ((adaMmax α (adaL α) : ℝ) * adaLval α β) /
      (adaBsvt k α β * adaEpsL α) := by
    rw [lt_div_iff₀ (mul_pos hb hεL)]
    have hbE : adaBsvt k α β * adaEpsL α ≤ 1 / 20480 * (1 / 20) :=
      mul_le_mul (by linarith) hεL' hεL.le (by norm_num)
    nlinarith
  linarith

end Sizes

end A

end F2e2e
