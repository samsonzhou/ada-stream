import F2e2e.A.Sim
import F2e2e.Lib.Opt.EntropicSensitivity

/-!
# Query-evaluation sensitivity of a validator stage (`I:eq:theta_r_sensitivity`)

Paper: `parts/partI.tex` L876-885 (`Δ_r`, `I:eq:Delta_r_def`) and L911-918 (`I:eq:theta_r_sensitivity`): after
replaying the same public records on two samples whose block `r` are neighbours, the weighted means
`θ^{(r)} = ⟨P^{(r)}, q(S_r)⟩` of a `[0,1]`-valued query differ by at most `Δ_r` (`4/n_r` for `2 ≤ r ≤ L-1` by
Lemma `I:lem:kkt_sensitivity`(2), `1/n_L` at the anchor by `I:eq:anchor_sens`).

Proof: the replayed cumulative payoff of level `r` is a *coordinate payoff* (`Opt.coordPayoff`): its `ℓ`-th entry is
`∑_{u<s} c_u q_u(X_{r,ℓ})` with public weights `c_u = δ_r` of round `u` (`0` for halted rounds) and public queries
`q_u = A_u(a_0, …, a_{u-1})`, all read off the records `h₀` (`replay_pay_eq`). Then `Opt.kkt_query_sensitivity`
(levels `r ≠ L`, weights `Opt.waterFill n_r 1`) and `Opt.anchor_sensitivity` (anchor, uniform weights) apply.

`theta_sensitivity'` has exactly the statement of A-VAL's `theta_sensitivity` (F2e2e/A/Validators.lean); the
validity hypothesis is not needed (the query `q` comes with its own range hypothesis).
-/

namespace F2e2e

namespace A

open MeasureTheory

variable {k : ℕ} {α β : ℝ} {X : Type}

/-- The public weights of the replayed payoff of level `r`: `δ_r` of round `u` if it is active, else `0`. -/
noncomputable def replayCoef (h₀ : Fin k → RoundRec) (r : ℕ) : ℕ → ℝ :=
  fun u => if (recAt h₀ u).active = true then (recAt h₀ u).delta r else 0

/-- Entry `ℓ` of block `r` of `replaceBlock r Sr S` is `Sr ℓ`. -/
theorem replaceBlock_blockIdx (r : ℕ) (Sr : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X)
    (ℓ : Fin (adaBlock k α β r)) : replaceBlock k α β r Sr S (adaBlockIdx k α β r ℓ) = Sr ℓ :=
  congrFun (blockOf_replaceBlock k α β r Sr S) ℓ

/-- **The replayed payoff of level `r` is a coordinate payoff** of the block `S_r`, with public weights
`replayCoef h₀ r` and public queries `u ↦ A_u(histAns h₀ u)`. -/
theorem replay_pay_eq (A : DetAnalyst X) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (h₀ : Fin k → RoundRec) (s : ℕ) :
    (replay A (replaceBlock k α β r Sr S) h₀ s).pay r =
      Opt.coordPayoff s (replayCoef h₀ r) (fun u => A u (histAns h₀ u)) Sr := by
  induction s with
  | zero =>
    funext ℓ
    simp [replay, MState.init, Opt.coordPayoff]
  | succ s ih =>
    funext ℓ
    rw [replay_succ]
    by_cases ha : (recAt h₀ s).active = true
    · rw [if_pos ha]
      show (replay A (replaceBlock k α β r Sr S) h₀ s).pay r ℓ +
          (recAt h₀ s).delta r * qOf A (replaceBlock k α β r Sr S) h₀ s (adaBlockIdx k α β r ℓ) = _
      rw [ih]
      simp only [Opt.coordPayoff, Finset.sum_range_succ, replayCoef, if_pos ha, qOf,
        replaceBlock_blockIdx]
    · rw [if_neg ha, ih]
      simp only [Opt.coordPayoff, Finset.sum_range_succ, replayCoef, if_neg ha, zero_mul, add_zero]

/-- The replayed `θ^{(r)}` of a query `q` on the sample `replaceBlock r Sr S` only sees `S_r`. -/
theorem replay_theta_eq (A : DetAnalyst X) (r : ℕ) (Sr : Fin (adaBlock k α β r) → X)
    (S : Fin (adaSampleSize k α β) → X) (h₀ : Fin k → RoundRec) (s : ℕ) (q : X → ℝ) :
    (replay A (replaceBlock k α β r Sr S) h₀ s).theta (fun ℓ => q (replaceBlock k α β r Sr S ℓ)) r =
      ∑ ℓ, (replay A (replaceBlock k α β r Sr S) h₀ s).weight r ℓ * q (Sr ℓ) := by
  unfold MState.theta
  refine Finset.sum_congr rfl fun ℓ _ => ?_
  simp only [replaceBlock_blockIdx]

/-- **Query-evaluation sensitivity of a validator stage** (`I:eq:theta_r_sensitivity`; Lemma
`I:lem:kkt_sensitivity`(2) and `I:eq:anchor_sens`); same statement as `theta_sensitivity` in
F2e2e/A/Validators.lean. -/
theorem theta_sensitivity' [MeasurableSpace X] (A : DetAnalyst X) (_hA : A.Valid) {r : ℕ} (hr2 : 2 ≤ r)
    (hrL : r ≤ adaL α) (S : Fin (adaSampleSize k α β) → X) (h₀ : Fin k → RoundRec) (s : ℕ) (q : X → ℝ)
    (hq : ∀ x, q x ∈ Set.Icc (0 : ℝ) 1) {Sr Sr' : Fin (adaBlock k α β r) → X} (hN : DP.Neighbor Sr Sr') :
    |(replay A (replaceBlock k α β r Sr S) h₀ s).theta (fun ℓ => q (replaceBlock k α β r Sr S ℓ)) r -
      (replay A (replaceBlock k α β r Sr' S) h₀ s).theta (fun ℓ => q (replaceBlock k α β r Sr' S ℓ)) r| ≤
      adaSens k α β r := by
  rw [replay_theta_eq, replay_theta_eq]
  rcases lt_or_eq_of_le hrL with hlt | heq
  · -- a level `2 ≤ r ≤ L-1`: entropic weights, `Δ_r = 4/n_r`
    have hne : r ≠ adaL α := hlt.ne
    have hw : ∀ (T : Fin (adaBlock k α β r) → X),
        (replay A (replaceBlock k α β r T S) h₀ s).weight r =
          Opt.waterFill (adaBlock k α β r) 1
            (Opt.coordPayoff s (replayCoef h₀ r) (fun u => A u (histAns h₀ u)) T) := by
      intro T
      unfold MState.weight
      rw [if_neg hne, replay_pay_eq]
    rw [hw Sr, hw Sr']
    have h := Opt.kkt_query_sensitivity (n := adaBlock k α β r) 1 s (replayCoef h₀ r)
      (fun u => A u (histAns h₀ u)) q hq hN
    have e : (adaBlock k α β r : ℝ) = (adaNr k α β r : ℝ) := by rw [adaBlock_mid k α β hr2 hlt]
    have hs : adaSens k α β r = 4 / (adaNr k α β r : ℝ) := by
      unfold adaSens
      rw [if_neg hne]
    rw [hs, ← e]
    exact h
  · -- the anchor `r = L`: uniform weights, `Δ_L = 1/n_L`
    subst heq
    have hw : ∀ (T : Fin (adaBlock k α β (adaL α)) → X),
        ∑ ℓ, (replay A (replaceBlock k α β (adaL α) T S) h₀ s).weight (adaL α) ℓ * q (T ℓ) =
          (∑ ℓ, q (T ℓ)) / (adaBlock k α β (adaL α) : ℝ) := by
      intro T
      unfold MState.weight
      rw [if_pos rfl, Finset.sum_div]
      refine Finset.sum_congr rfl fun ℓ _ => ?_
      ring
    rw [hw Sr, hw Sr']
    have h := Opt.anchor_sensitivity q hq hN
    have e : (adaBlock k α β (adaL α) : ℝ) = (adaNL k α β : ℝ) := by rw [adaBlock_L]
    have hs : adaSens k α β (adaL α) = 1 / (adaNL k α β : ℝ) := by
      unfold adaSens
      rw [if_pos rfl]
    rw [hs, ← e]
    exact h

end A

end F2e2e
