import F2e2e.A.ArchMeasurable

/-!
# Part I: resampling a block and a stage's noise; the clean event is measurable

Owner: A-ARCH.

* `map_piMix`: mixing two independent samples of a product measure coordinatewise (by a fixed predicate)
  gives the product measure again.
* `map_replaceBlock`: replacing block `r` of `S ∼ D^n` by an independent `S_r ∼ D^{n_r}` gives `D^n`.
* `adaProb_resample`: resampling block `r` and the stage-`r` noise preserves `adaProb` (the Fubini step that
  turns "DP for every fixed `S₋ᵣ, ω₋ᵣ`" into statements about `adaProb`).
* `integral_adaProb_block`: the integral form used by the DP-to-expectation transfer of §5.
* `measurableSet_EClean`: the clean event `E_clean` is measurable.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

/-! ## Coordinatewise mixing of product measures -/

theorem measurable_piMix {ι : Type*} {E : ι → Type*} [∀ i, MeasurableSpace (E i)] (P : ι → Prop)
    [DecidablePred P] :
    Measurable (fun xy : ((i : ι) → E i) × ((i : ι) → E i) => fun i => if P i then xy.1 i else xy.2 i) := by
  rw [measurable_pi_iff]
  intro i
  by_cases h : P i
  · simp only [if_pos h]
    exact (measurable_pi_apply i).comp measurable_fst
  · simp only [if_neg h]
    exact (measurable_pi_apply i).comp measurable_snd

/-- Mixing two independent samples of `∏ μ_i` coordinatewise (coordinates in `P` from the first, the others
from the second) gives `∏ μ_i`. -/
theorem map_piMix {ι : Type*} [Fintype ι] {E : ι → Type*} [∀ i, MeasurableSpace (E i)]
    (μ : (i : ι) → Measure (E i)) [∀ i, IsProbabilityMeasure (μ i)] (P : ι → Prop) [DecidablePred P] :
    ((Measure.pi μ).prod (Measure.pi μ)).map
      (fun xy : ((i : ι) → E i) × ((i : ι) → E i) => fun i => if P i then xy.1 i else xy.2 i) =
      Measure.pi μ := by
  symm
  apply Measure.pi_eq
  intro s hs
  rw [Measure.map_apply (measurable_piMix P) (MeasurableSet.univ_pi hs)]
  have hset : (fun xy : ((i : ι) → E i) × ((i : ι) → E i) => fun i => if P i then xy.1 i else xy.2 i) ⁻¹'
      Set.univ.pi s =
      (Set.univ.pi fun i => if P i then s i else Set.univ) ×ˢ
        (Set.univ.pi fun i => if P i then Set.univ else s i) := by
    ext xy
    simp only [Set.mem_preimage, Set.mem_univ_pi, Set.mem_prod]
    constructor
    · intro h
      constructor
      · intro i
        by_cases hi : P i
        · have := h i
          rw [if_pos hi] at this ⊢
          exact this
        · rw [if_neg hi]
          exact Set.mem_univ _
      · intro i
        by_cases hi : P i
        · rw [if_pos hi]
          exact Set.mem_univ _
        · have := h i
          rw [if_neg hi] at this ⊢
          exact this
    · rintro ⟨h1, h2⟩ i
      by_cases hi : P i
      · have := h1 i
        rw [if_pos hi] at this ⊢
        exact this
      · have := h2 i
        rw [if_neg hi] at this ⊢
        exact this
  rw [hset, Measure.prod_prod, Measure.pi_pi, Measure.pi_pi, ← Finset.prod_mul_distrib]
  refine Finset.prod_congr rfl fun i _ => ?_
  by_cases hi : P i
  · simp [hi]
  · simp [hi]

/-! ## Replacing a block of the sample -/

section Block

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

/-- Replacing block `r` of `S ∼ D^n` by an independent `S_r ∼ D^{n_r}` gives `D^n`. -/
theorem map_replaceBlock (D : Measure X) [IsProbabilityMeasure D] (r : ℕ) :
    ((Measure.pi fun _ : Fin (adaBlock k α β r) => D).prod
        (Measure.pi fun _ : Fin (adaSampleSize k α β) => D)).map
      (fun p => replaceBlock k α β r p.1 p.2) = Measure.pi fun _ : Fin (adaSampleSize k α β) => D := by
  symm
  apply Measure.pi_eq
  intro s hs
  rw [Measure.map_apply (measurable_replaceBlock k α β r) (MeasurableSet.univ_pi hs)]
  set inB : Fin (adaSampleSize k α β) → Prop := fun p =>
    adaOffset k α β r ≤ p.val ∧ p.val < adaOffset k α β r + adaBlock k α β r with hinB
  have hidx : ∀ ℓ : Fin (adaBlock k α β r), inB (adaBlockIdx k α β r ℓ) := fun ℓ => by
    simp only [hinB, adaBlockIdx_val]
    exact ⟨Nat.le_add_right _ _, by have := ℓ.isLt; omega⟩
  have hrep_idx : ∀ (Sr : Fin (adaBlock k α β r) → X) (S : Fin (adaSampleSize k α β) → X)
      (ℓ : Fin (adaBlock k α β r)), replaceBlock k α β r Sr S (adaBlockIdx k α β r ℓ) = Sr ℓ := by
    intro Sr S ℓ
    exact congrFun (blockOf_replaceBlock k α β r Sr S) ℓ
  have hidx_of : ∀ p, inB p → ∃ ℓ : Fin (adaBlock k α β r), adaBlockIdx k α β r ℓ = p := by
    intro p hp
    refine ⟨⟨p.val - adaOffset k α β r, by have := hp.2; have := hp.1; omega⟩, ?_⟩
    ext
    rw [adaBlockIdx_val]
    have := hp.1
    simp only
    omega
  have hset : (fun p : (Fin (adaBlock k α β r) → X) × (Fin (adaSampleSize k α β) → X) =>
      replaceBlock k α β r p.1 p.2) ⁻¹' Set.univ.pi s =
      (Set.univ.pi fun ℓ => s (adaBlockIdx k α β r ℓ)) ×ˢ
        (Set.univ.pi fun p => if inB p then Set.univ else s p) := by
    ext ⟨Sr, S⟩
    simp only [Set.mem_preimage, Set.mem_univ_pi, Set.mem_prod]
    constructor
    · intro h
      constructor
      · intro ℓ
        have := h (adaBlockIdx k α β r ℓ)
        rwa [hrep_idx] at this
      · intro p
        by_cases hp : inB p
        · rw [if_pos hp]
          exact Set.mem_univ _
        · rw [if_neg hp]
          have := h p
          rwa [replaceBlock_of_not_mem k α β r Sr S p hp] at this
    · rintro ⟨h1, h2⟩ p
      by_cases hp : inB p
      · obtain ⟨ℓ, rfl⟩ := hidx_of p hp
        rw [hrep_idx]
        exact h1 ℓ
      · rw [replaceBlock_of_not_mem k α β r Sr S p hp]
        have := h2 p
        rwa [if_neg hp] at this
  rw [hset, Measure.prod_prod, Measure.pi_pi, Measure.pi_pi]
  -- `∏_ℓ D(s(idx ℓ)) * ∏_p D(if inB p then univ else s p) = ∏_p D(s p)`
  have hblock : ∏ ℓ : Fin (adaBlock k α β r), D (s (adaBlockIdx k α β r ℓ)) =
      ∏ p ∈ Finset.univ.filter inB, D (s p) := by
    apply Finset.prod_nbij (adaBlockIdx k α β r)
    · intro ℓ _
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      exact hidx ℓ
    · intro ℓ _ ℓ' _ h
      exact Fin.ext (adaBlockIdx_inj k α β ℓ ℓ' h).2
    · intro p hp
      simp only [Finset.coe_filter, Finset.mem_univ, true_and, Set.mem_ofPred_eq] at hp
      obtain ⟨ℓ, hℓ⟩ := hidx_of p hp
      exact ⟨ℓ, Finset.mem_coe.mpr (Finset.mem_univ _), hℓ⟩
    · intro ℓ _
      rfl
  have hrest : ∏ p, D (if inB p then Set.univ else s p) = ∏ p ∈ Finset.univ.filter (fun p => ¬ inB p),
      D (s p) := by
    rw [← Finset.prod_filter_mul_prod_filter_not Finset.univ inB]
    have h1 : ∏ p ∈ Finset.univ.filter inB, D (if inB p then Set.univ else s p) = 1 := by
      refine Finset.prod_eq_one fun p hp => ?_
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hp
      rw [if_pos hp, measure_univ]
    have h2 : ∏ p ∈ Finset.univ.filter (fun p => ¬ inB p), D (if inB p then Set.univ else s p) =
        ∏ p ∈ Finset.univ.filter (fun p => ¬ inB p), D (s p) := by
      refine Finset.prod_congr rfl fun p hp => ?_
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hp
      rw [if_neg hp]
    rw [h1, h2, one_mul]
  rw [hblock, hrest, Finset.prod_filter_mul_prod_filter_not]

end Block

/-! ## Resampling for the probability space of the analysis -/

section Resample

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

theorem map_mixNoise (k : ℕ) (α β : ℝ) (r : ℕ) :
    ((adaNoiseMeasure k α β).prod (adaNoiseMeasure k α β)).map (fun p => mixNoise r p.1 p.2) =
      adaNoiseMeasure k α β := by
  unfold adaNoiseMeasure
  exact map_piMix (noiseLaw k α β) (fun j => j.stage = r)

/-- **Resampling.** Drawing a fresh block `S_r ∼ D^{n_r}` and fresh stage-`r` noise `ω ∼ P_M` and plugging
them into `(S, ω') ∼ D^n ⊗ P_M` gives `D^n ⊗ P_M` again. -/
theorem adaProb_resample (k : ℕ) (α β : ℝ) (D : Measure X) [IsProbabilityMeasure D] (r : ℕ) :
    ((Measure.pi fun _ : Fin (adaBlock k α β r) => D).prod
        ((adaNoiseMeasure k α β).prod (adaProb k α β D))).map
      (fun w => (replaceBlock k α β r w.1 w.2.2.1, mixNoise r w.2.1 w.2.2.2)) =
      adaProb k α β D := by
  set μA := Measure.pi fun _ : Fin (adaBlock k α β r) => D
  set μB := adaNoiseMeasure k α β
  set μC := Measure.pi fun _ : Fin (adaSampleSize k α β) => D
  -- the rearrangement `A × (B × (C × D)) → (A × C) × (B × D)` is measure preserving
  have e1 := (measurePreserving_prodAssoc μB μC μB).symm
  have es := (Measure.measurePreserving_swap (μ := μB) (ν := μC)).prod (MeasurePreserving.id μB)
  have ea := measurePreserving_prodAssoc μC μB μB
  have e2 := (MeasurePreserving.id μA).prod (ea.comp (es.comp e1))
  have e4 := (measurePreserving_prodAssoc μA μC (μB.prod μB)).symm
  have he := e4.comp e2
  have hF : Measurable (fun p : (Fin (adaBlock k α β r) → X) × (Fin (adaSampleSize k α β) → X) =>
      replaceBlock k α β r p.1 p.2) := measurable_replaceBlock k α β r
  have hG : Measurable (fun p : AdaOmega k α × AdaOmega k α => mixNoise r p.1 p.2) :=
    measurable_mixNoise k α r
  have hcomp : (fun w : (Fin (adaBlock k α β r) → X) × (AdaOmega k α ×
      ((Fin (adaSampleSize k α β) → X) × AdaOmega k α)) =>
        (replaceBlock k α β r w.1 w.2.2.1, mixNoise r w.2.1 w.2.2.2)) =
      Prod.map (fun p => replaceBlock k α β r p.1 p.2) (fun p => mixNoise r p.1 p.2) ∘
        (MeasurableEquiv.prodAssoc.symm ∘ Prod.map id (MeasurableEquiv.prodAssoc ∘
          (Prod.map Prod.swap id ∘ MeasurableEquiv.prodAssoc.symm))) := by
    funext w
    rfl
  unfold adaProb
  rw [hcomp, ← Measure.map_map (hF.prodMap hG) he.measurable, he.map_eq,
    ← Measure.map_prod_map _ _ hF hG, map_replaceBlock, map_mixNoise]

/-- The transcript as a jointly measurable function of `((S, ω'), (S_r, ω))` after resampling block `r` and
the stage-`r` noise. -/
theorem measurable_resampled_transcript (A : DetAnalyst X) (hA : A.JointlyMeasurable) (r : ℕ) :
    Measurable fun v : ((Fin (adaSampleSize k α β) → X) × AdaOmega k α) ×
        ((Fin (adaBlock k α β r) → X) × AdaOmega k α) =>
      transcript k α β A (replaceBlock k α β r v.2.1 v.1.1) (mixNoise r v.2.2 v.1.2) := by
  have h1 : Measurable fun v : ((Fin (adaSampleSize k α β) → X) × AdaOmega k α) ×
      ((Fin (adaBlock k α β r) → X) × AdaOmega k α) => replaceBlock k α β r v.2.1 v.1.1 :=
    (measurable_replaceBlock k α β r).comp
      ((measurable_fst.comp measurable_snd).prodMk (measurable_fst.comp measurable_fst))
  have h2 : Measurable fun v : ((Fin (adaSampleSize k α β) → X) × AdaOmega k α) ×
      ((Fin (adaBlock k α β r) → X) × AdaOmega k α) => mixNoise r v.2.2 v.1.2 :=
    (measurable_mixNoise k α r).comp
      ((measurable_snd.comp measurable_snd).prodMk (measurable_snd.comp measurable_fst))
  exact (measurable_transcript A hA).comp (h1.prodMk h2)

theorem measurable_blockOf (r : ℕ) :
    Measurable fun S : Fin (adaSampleSize k α β) → X => blockOf k α β r S := by
  rw [measurable_pi_iff]
  intro ℓ
  exact measurable_pi_apply _

/-- **Integral form of the resampling** (for the DP-to-expectation transfer of §5): for a bounded jointly
measurable `G`, `E[G(S_r, h)] = E_{(S, ω')}[E_{S_r ∼ D^{n_r}}[E_{h ∼ stageKernel(S_r)} G(S_r, h)]]`. -/
theorem integral_adaProb_block (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (r : ℕ)
    (G : (Fin (adaBlock k α β r) → X) → (Fin k → RoundRec) → ℝ) (hG : Measurable (Function.uncurry G))
    (hGb : ∃ C, ∀ s y, |G s y| ≤ C) :
    ∫ z, G (blockOf k α β r z.1) (transcript k α β A z.1 z.2) ∂adaProb k α β D =
      ∫ w, ∫ Sr, ∫ y, G Sr y ∂(stageKernel k α β A r w.1 w.2 Sr)
        ∂(Measure.pi fun _ : Fin (adaBlock k α β r) => D) ∂adaProb k α β D := by
  obtain ⟨C, hC⟩ := hGb
  set μA := Measure.pi fun _ : Fin (adaBlock k α β r) => D
  set μB := adaNoiseMeasure k α β
  -- the function on the original space and on the rearranged space
  set g' : ((Fin (adaSampleSize k α β) → X) × AdaOmega k α) ×
      ((Fin (adaBlock k α β r) → X) × AdaOmega k α) → ℝ :=
    fun v => G v.2.1 (transcript k α β A (replaceBlock k α β r v.2.1 v.1.1) (mixNoise r v.2.2 v.1.2))
    with hg'
  have hg'm : Measurable g' :=
    hG.comp ((measurable_fst.comp measurable_snd).prodMk (measurable_resampled_transcript A hA r))
  have hg'b : ∀ v, ‖g' v‖ ≤ C := fun v => by
    rw [Real.norm_eq_abs]
    exact hC _ _
  have hint : ∀ (μ : Measure (((Fin (adaSampleSize k α β) → X) × AdaOmega k α) ×
      ((Fin (adaBlock k α β r) → X) × AdaOmega k α))) [IsFiniteMeasure μ], Integrable g' μ :=
    fun μ _ => (integrable_const C).mono' hg'm.aestronglyMeasurable (ae_of_all _ hg'b)
  -- Step 1: resampling
  have hΦ : Measurable (fun w : (Fin (adaBlock k α β r) → X) × (AdaOmega k α ×
      ((Fin (adaSampleSize k α β) → X) × AdaOmega k α)) =>
        (replaceBlock k α β r w.1 w.2.2.1, mixNoise r w.2.1 w.2.2.2)) :=
    ((measurable_replaceBlock k α β r).comp (measurable_fst.prodMk
      (measurable_fst.comp (measurable_snd.comp measurable_snd)))).prodMk
    ((measurable_mixNoise k α r).comp ((measurable_fst.comp measurable_snd).prodMk
      (measurable_snd.comp (measurable_snd.comp measurable_snd))))
  have hfm : Measurable fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
      G (blockOf k α β r z.1) (transcript k α β A z.1 z.2) :=
    hG.comp (((measurable_blockOf r).comp measurable_fst).prodMk (measurable_transcript A hA))
  have step1 : ∫ z, G (blockOf k α β r z.1) (transcript k α β A z.1 z.2) ∂adaProb k α β D =
      ∫ w, g' (MeasurableEquiv.prodComm (MeasurableEquiv.prodAssoc.symm w))
        ∂(μA.prod (μB.prod (adaProb k α β D))) := by
    conv_lhs => rw [← adaProb_resample k α β D r]
    rw [integral_map hΦ.aemeasurable hfm.aestronglyMeasurable]
    refine integral_congr_ae (ae_of_all _ fun w => ?_)
    simp only [hg']
    rw [blockOf_replaceBlock]
    rfl
  -- Step 2: rearrange `A × (B × W) → W × (A × B)`
  have hψ : MeasurePreserving (fun w => MeasurableEquiv.prodComm (MeasurableEquiv.prodAssoc.symm w))
      (μA.prod (μB.prod (adaProb k α β D))) ((adaProb k α β D).prod (μA.prod μB)) :=
    (Measure.measurePreserving_swap (μ := μA.prod μB) (ν := adaProb k α β D)).comp
      (measurePreserving_prodAssoc μA μB (adaProb k α β D)).symm
  have hemb : MeasurableEmbedding (fun w : (Fin (adaBlock k α β r) → X) × (AdaOmega k α ×
      ((Fin (adaSampleSize k α β) → X) × AdaOmega k α)) =>
        MeasurableEquiv.prodComm (MeasurableEquiv.prodAssoc.symm w)) :=
    (MeasurableEquiv.prodAssoc.symm.trans MeasurableEquiv.prodComm).measurableEmbedding
  have step2 := hψ.integral_comp hemb g'
  rw [step1, step2, integral_prod g' (hint _)]
  refine integral_congr_ae (ae_of_all _ fun w => ?_)
  -- Step 3: the inner integral over `(S_r, ω)`
  have hin : Integrable (fun p : (Fin (adaBlock k α β r) → X) × AdaOmega k α => g' (w, p))
      (μA.prod μB) :=
    (integrable_const C).mono' (hg'm.comp (measurable_const.prodMk measurable_id)).aestronglyMeasurable
      (ae_of_all _ fun p => hg'b (w, p))
  show ∫ p, g' (w, p) ∂(μA.prod μB) = _
  rw [integral_prod _ hin]
  refine integral_congr_ae (ae_of_all _ fun Sr => ?_)
  beta_reduce
  rw [stageKernel_apply A hA r w.1 w.2 Sr]
  unfold stageLaw
  have hsm : Measurable fun ω : AdaOmega k α =>
      transcript k α β A (replaceBlock k α β r Sr w.1) (mixNoise r ω w.2) :=
    (measurable_stageMap A hA r w.1 w.2).comp (measurable_const.prodMk measurable_id)
  have hGs : Measurable (G Sr) := by
    have h := hG.comp (measurable_const.prodMk measurable_id :
      Measurable fun y : Fin k → RoundRec => (Sr, y))
    exact h
  rw [integral_map hsm.aemeasurable hGs.aestronglyMeasurable]

/-! ## The clean event is measurable -/

private theorem measurable_histAns' (i : ℕ) :
    Measurable (fun h : Fin k → RoundRec => histAns h i) := by
  rw [measurable_pi_iff]
  intro j
  by_cases hj : j.val < k
  · simp only [histAns, dif_pos hj]
    exact measurable_pi_apply _
  · simp only [histAns, dif_neg hj]
    exact measurable_const

private theorem measurable_qry' (A : DetAnalyst X) (hA : A.JointlyMeasurable) (i : ℕ) :
    Measurable (fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2) :=
  (hA i).comp (((measurable_histAns' i).comp measurable_fst).prodMk measurable_snd)

private theorem measurable_popMu' (D : Measure X) [SFinite D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) (i : ℕ) : Measurable (fun h : Fin k → RoundRec => popMu D A h i) := by
  unfold popMu
  exact (StronglyMeasurable.integral_prod_right'
    (f := fun p : (Fin k → RoundRec) × X => qry A p.1 i p.2)
    (measurable_qry' A hA i).stronglyMeasurable).measurable

private theorem measurableSet_ELap (k : ℕ) (α : ℝ) : MeasurableSet {ω : AdaOmega k α | ELap k α ω} := by
  have h : {ω : AdaOmega k α | ELap k α ω} = ⋂ j, (fun ω : AdaOmega k α => ω j) ⁻¹' {x | lapOK k α j x} := by
    ext ω
    simp [ELap]
  rw [h]
  refine MeasurableSet.iInter fun j => (measurable_pi_apply j) ?_
  cases j with
  | beta _ =>
    show MeasurableSet {x : ℝ | True}
    exact MeasurableSet.univ
  | nu _ _ =>
    show MeasurableSet {x : ℝ | |x| ≤ 2 * adaU0 α}
    exact measurableSet_le continuous_abs.measurable measurable_const
  | zeta _ _ =>
    show MeasurableSet {x : ℝ | |x| ≤ adaU0 α}
    exact measurableSet_le continuous_abs.measurable measurable_const
  | rho _ _ =>
    show MeasurableSet {x : ℝ | |x| ≤ adaU0 α}
    exact measurableSet_le continuous_abs.measurable measurable_const

theorem measurableSet_EAnc (D : Measure X) [SFinite D] (A : DetAnalyst X) (hA : A.JointlyMeasurable) :
    MeasurableSet {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | EAnc k α β D A z} := by
  have htr := measurable_transcript (k := k) (α := α) (β := β) A hA
  have h : {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | EAnc k α β D A z} =
      ⋂ i : Fin k, {z | |anchorMean k α β z.1 (qry A (transcript k α β A z.1 z.2) i) -
        popMu D A (transcript k α β A z.1 z.2) i| ≤ adaRanc α} := by
    ext z
    simp [EAnc]
  rw [h]
  refine MeasurableSet.iInter fun i => measurableSet_le ?_ measurable_const
  refine continuous_abs.measurable.comp (Measurable.sub ?_ ((measurable_popMu' D A hA i).comp htr))
  unfold anchorMean
  refine Measurable.div_const (Finset.measurable_sum _ fun ℓ _ => ?_) _
  exact (measurable_qry' A hA i).comp (htr.prodMk ((measurable_pi_apply _).comp measurable_fst))

/-- The clean event `E_clean` is measurable. -/
theorem measurableSet_EClean (D : Measure X) [SFinite D] (A : DetAnalyst X)
    (hA : A.JointlyMeasurable) :
    MeasurableSet {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | EClean k α β D A z} :=
  (measurableSet_EAnc D A hA).inter (measurable_snd (measurableSet_ELap k α))

end Resample

end A

end F2e2e
