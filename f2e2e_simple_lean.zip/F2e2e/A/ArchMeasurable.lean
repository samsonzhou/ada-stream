import F2e2e.A.Chain

/-!
# Part I: measurability of the mechanism and of the transcript

Owner: A-ARCH.

* `measurable_adaMech`: the answers of `adaMech` are jointly measurable in (query values, noise) — the
  hypothesis of the Tonelli–Fubini reduction (Lemma `I:lem:tonelli_fubini`, `F2e2e/A/Model.lean`).
* `measurable_transcript`: for a jointly measurable deterministic analyst, the transcript is jointly
  measurable in (sample, noise).
* Building blocks: `ChainData.MeasFamily` (a measurable family of chain data with fixed depth and
  thresholds) and its lemmas `measurable_orig`, `measurableSet_trig`, `measurable_ufinal`, `measurable_answer`,
  `measurable_sgn`, `measurable_delta`, `measurable_toRec`; the measurable structure of `MState`
  (`MState.toTuple`, `MState.measurable_iff`, projections), `MState.measurable_weight`,
  `measurable_theta`, `measurable_roundChain`, `measurable_activeRec`, `measurable_next`, `measurable_step`,
  `measurable_onlineRun`.
* `measurable_replaceBlock`, `measurable_mixNoise`, `stageMap`, `measurable_stageMap`.
* `stageKernel`: the Markov-kernel form of `stageLaw` (the law of the transcript as a function of the block
  `S_r`, all other blocks and all noise not owned by stage `r` fixed), with `stageKernel_apply` and
  `isMarkovKernel_stageKernel`.

The measurability of the water-filling projection is `Opt.measurable_waterFill`.
-/

namespace F2e2e

namespace A

open MeasureTheory ProbabilityTheory

/-! ## Helpers -/

section Helpers

variable {P γ : Type*} [MeasurableSpace P] [MeasurableSpace γ]

/-- A measurable family indexed by `ℕ`, evaluated at a measurable `ℕ`-valued index, is measurable. -/
theorem measurable_nat_index {g : ℕ → P → γ} (hg : ∀ n, Measurable (g n)) {N : P → ℕ}
    (hN : Measurable N) : Measurable fun p => g (N p) p :=
  (measurable_from_prod_countable_left (f := fun q : P × ℕ => g q.2 q.1) hg).comp
    (measurable_id.prodMk hN)

theorem measurable_fin_snoc {i : ℕ} {f : P → Fin i → γ} {g : P → γ} (hf : Measurable f)
    (hg : Measurable g) : Measurable fun p => Fin.snoc (α := fun _ => γ) (f p) (g p) := by
  rw [measurable_pi_iff]
  intro j
  refine Fin.lastCases ?_ (fun j' => ?_) j
  · simp only [Fin.snoc_last]
    exact hg
  · simp only [Fin.snoc_castSucc]
    exact (measurable_pi_apply j').comp hf

end Helpers

theorem measurable_clip01 : Measurable clip01 := by
  unfold clip01
  exact measurable_const.min (measurable_const.max measurable_id)

theorem measurable_sgn1 : Measurable sgn1 := by
  unfold sgn1
  exact Measurable.ite measurableSet_Ici measurable_const measurable_const

/-! ## Measurable families of chain data -/

/-- A family `d : P → ChainData` with fixed depth `L` and thresholds `tau`, whose other fields are measurable
in the parameter. -/
structure ChainData.MeasFamily {P : Type*} [MeasurableSpace P] (d : P → ChainData) (L : ℕ)
    (tau : ℕ → ℕ → ℝ) : Prop where
  hL : ∀ p, (d p).L = L
  htau : ∀ p, (d p).tau = tau
  hc1 : Measurable fun p => (d p).c1
  htheta : ∀ s, Measurable fun p => (d p).theta s
  hrho : ∀ s, Measurable fun p => (d p).rho s
  hnu : ∀ s, Measurable fun p => (d p).nu s
  hzeta : ∀ s, Measurable fun p => (d p).zeta s

namespace ChainData.MeasFamily

variable {P : Type*} [MeasurableSpace P] {d : P → ChainData} {L : ℕ} {tau : ℕ → ℕ → ℝ}
  (hd : ChainData.MeasFamily d L tau)
include hd

theorem measurable_relV (s : ℕ) : Measurable fun p => (d p).relV s :=
  (hd.htheta s).add (hd.hzeta s)

theorem measurable_relC (s : ℕ) : Measurable fun p => (d p).relC s :=
  measurable_clip01.comp (hd.measurable_relV s)

theorem measurableSet_fires (s : ℕ) {u : P → ℕ} (hu : Measurable u) {c : P → ℝ}
    (hc : Measurable c) : MeasurableSet {p | (d p).Fires s (u p) (c p)} := by
  have h : {p | (d p).Fires s (u p) (c p)} =
      {p | tau (u p) s + (d p).rho s ≤ |c p - (d p).theta s| + (d p).nu s} := by
    ext p
    simp only [Set.mem_ofPred_eq, ChainData.Fires, hd.htau p]
  rw [h]
  have h1 : Measurable fun p => tau (u p) s := (measurable_from_nat (f := fun n => tau n s)).comp hu
  have h2 : Measurable fun p => |c p - (d p).theta s| :=
    continuous_abs.measurable.comp (hc.sub (hd.htheta s))
  exact measurableSet_le (h1.add (hd.hrho s)) (h2.add (hd.hnu s))

theorem measurable_orig (s : ℕ) : Measurable fun p => (d p).orig s := by
  induction s with
  | zero => exact measurable_const.prodMk hd.hc1
  | succ s ih =>
    have h1 : Measurable fun p => ((d p).orig s).1 := measurable_fst.comp ih
    have h2 : Measurable fun p => ((d p).orig s).2 := measurable_snd.comp ih
    have hset : MeasurableSet
        {p | 2 ≤ s ∧ s ≤ (d p).L ∧ (d p).Fires s ((d p).orig s).1 ((d p).orig s).2} := by
      have h : {p | 2 ≤ s ∧ s ≤ (d p).L ∧ (d p).Fires s ((d p).orig s).1 ((d p).orig s).2} =
          {_p | 2 ≤ s ∧ s ≤ L} ∩ {p | (d p).Fires s ((d p).orig s).1 ((d p).orig s).2} := by
        ext p
        simp only [Set.mem_ofPred_eq, Set.mem_inter_iff, hd.hL p, and_assoc]
      rw [h]
      exact (MeasurableSet.const _).inter (hd.measurableSet_fires s h1 h2)
    show Measurable fun p => if 2 ≤ s ∧ s ≤ (d p).L ∧ (d p).Fires s ((d p).orig s).1 ((d p).orig s).2
      then (s, (d p).relC s) else (d p).orig s
    exact Measurable.ite hset (measurable_const.prodMk (hd.measurable_relC s)) ih

theorem measurableSet_trig (s : ℕ) : MeasurableSet {p | (d p).Trig s} := by
  have h : {p | (d p).Trig s} =
      {_p | 2 ≤ s ∧ s ≤ L} ∩ {p | (d p).Fires s ((d p).orig s).1 ((d p).orig s).2} := by
    ext p
    simp only [Set.mem_ofPred_eq, Set.mem_inter_iff, ChainData.Trig, hd.hL p, and_assoc]
  rw [h]
  exact (MeasurableSet.const _).inter (hd.measurableSet_fires s
    (measurable_fst.comp (hd.measurable_orig s)) (measurable_snd.comp (hd.measurable_orig s)))

theorem measurable_ufinal : Measurable fun p => (d p).ufinal := by
  have h : (fun p => (d p).ufinal) = fun p => ((d p).orig (L + 1)).1 := by
    funext p
    simp only [ChainData.ufinal, hd.hL p]
  rw [h]
  exact measurable_fst.comp (hd.measurable_orig _)

theorem measurable_answer : Measurable fun p => (d p).answer := by
  have h : (fun p => (d p).answer) = fun p => ((d p).orig (L + 1)).2 := by
    funext p
    simp only [ChainData.answer, hd.hL p]
  rw [h]
  exact measurable_snd.comp (hd.measurable_orig _)

theorem measurable_uprev (s : ℕ) : Measurable fun p => (d p).uprev s :=
  measurable_fst.comp (hd.measurable_orig s)

theorem measurable_cprev (s : ℕ) : Measurable fun p => (d p).cprev s :=
  measurable_snd.comp (hd.measurable_orig s)

theorem measurableSet_ufinal (S : Set ℕ) : MeasurableSet {p | (d p).ufinal ∈ S} :=
  hd.measurable_ufinal MeasurableSet.of_discrete

theorem measurableSet_released (s : ℕ) : MeasurableSet {p | (d p).Released s} := by
  have h : {p | (d p).Released s} = {p | (d p).Trig s} ∪ {p | (d p).ufinal ∈ {u | 3 ≤ u ∧ s + 1 = u}} := by
    ext p
    rfl
  rw [h]
  exact (hd.measurableSet_trig s).union (hd.measurableSet_ufinal _)

theorem measurable_sgn : Measurable fun p => (d p).sgn := by
  have hcp : Measurable fun p => (d p).cprev (d p).ufinal :=
    measurable_nat_index (g := fun n p => (d p).cprev n) (fun n => hd.measurable_cprev n)
      hd.measurable_ufinal
  show Measurable fun p => if 2 ≤ (d p).ufinal then sgn1 ((d p).cprev (d p).ufinal - (d p).answer)
    else 0
  exact Measurable.ite (hd.measurableSet_ufinal {u | 2 ≤ u})
    (measurable_sgn1.comp (hcp.sub hd.measurable_answer)) measurable_const

theorem measurable_delta (e1 e : ℝ) (eT : ℕ → ℝ) (m : ℕ) :
    Measurable fun p => (d p).delta e1 e eT m := by
  show Measurable fun p => if (d p).ufinal = 2 then (if m = 1 then -e1 * (d p).sgn else 0)
    else if 3 ≤ (d p).ufinal then
      (if m + 1 = (d p).ufinal then -e * (d p).sgn else if m = (d p).ufinal then eT m * (d p).sgn else 0)
    else 0
  refine Measurable.ite (hd.measurableSet_ufinal {u | u = 2})
    (Measurable.ite (MeasurableSet.const _) (measurable_const.mul hd.measurable_sgn) measurable_const)
    (Measurable.ite (hd.measurableSet_ufinal {u | 3 ≤ u})
      (Measurable.ite (hd.measurableSet_ufinal {u | m + 1 = u})
        (measurable_const.mul hd.measurable_sgn)
        (Measurable.ite (hd.measurableSet_ufinal {u | m = u})
          (measurable_const.mul hd.measurable_sgn) measurable_const))
      measurable_const)

theorem measurable_toRec (e1 e : ℝ) (eT : ℕ → ℝ) :
    Measurable fun p => (d p).toRec e1 e eT := by
  rw [RoundRec.measurable_iff]
  have htrig : Measurable fun p => fun r => decide ((d p).Trig r) := by
    rw [measurable_pi_iff]
    intro r
    apply measurable_to_bool
    have h : (fun p => decide ((d p).Trig r)) ⁻¹' {true} = {p | (d p).Trig r} := by
      ext p
      simp
    rw [h]
    exact hd.measurableSet_trig r
  have hrel : Measurable fun p => fun r => decide ((d p).Released r) := by
    rw [measurable_pi_iff]
    intro r
    apply measurable_to_bool
    have h : (fun p => decide ((d p).Released r)) ⁻¹' {true} = {p | (d p).Released r} := by
      ext p
      simp
    rw [h]
    exact hd.measurableSet_released r
  have hup : Measurable fun p => fun r => (d p).uprev r := by
    rw [measurable_pi_iff]
    exact hd.measurable_uprev
  have hv : Measurable fun p => fun r => if (d p).Released r then (d p).relV r else 0 := by
    rw [measurable_pi_iff]
    intro r
    exact Measurable.ite (hd.measurableSet_released r) (hd.measurable_relV r) measurable_const
  have hc : Measurable fun p => fun r =>
      if r = 1 then (d p).c1 else if (d p).Released r then (d p).relC r else 0 := by
    rw [measurable_pi_iff]
    intro r
    exact Measurable.ite (MeasurableSet.const _) hd.hc1
      (Measurable.ite (hd.measurableSet_released r) (hd.measurable_relC r) measurable_const)
  have hdel : Measurable fun p => fun m => (d p).delta e1 e eT m := by
    rw [measurable_pi_iff]
    exact hd.measurable_delta e1 e eT
  exact measurable_const.prodMk (htrig.prodMk (hup.prodMk (hrel.prodMk (hv.prodMk (hc.prodMk
    (hd.measurable_ufinal.prodMk (hd.measurable_answer.prodMk (hd.measurable_sgn.prodMk hdel))))))))

end ChainData.MeasFamily

/-! ## The measurable structure of the mechanism state -/

section State

variable {k : ℕ} {α β : ℝ}

/-- The state as a tuple (defines its measurable structure). -/
def MState.toTuple (st : MState k α β) :
    Bool × ℕ × (ℕ → ℕ) × (ℕ → ℕ) × ((r : ℕ) → Fin (adaBlock k α β r) → ℝ) :=
  (st.halt, st.t1, st.N, st.M, st.pay)

/-- The measurable structure of states: the one induced by `MState.toTuple`. -/
instance : MeasurableSpace (MState k α β) := MeasurableSpace.comap MState.toTuple inferInstance

theorem MState.measurable_toTuple : Measurable (MState.toTuple (k := k) (α := α) (β := β)) :=
  comap_measurable _

theorem MState.measurable_halt : Measurable (MState.halt (k := k) (α := α) (β := β)) :=
  measurable_fst.comp MState.measurable_toTuple

theorem MState.measurable_t1 : Measurable (MState.t1 (k := k) (α := α) (β := β)) :=
  measurable_fst.comp (measurable_snd.comp MState.measurable_toTuple)

theorem MState.measurable_N : Measurable (MState.N (k := k) (α := α) (β := β)) :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp MState.measurable_toTuple))

theorem MState.measurable_M : Measurable (MState.M (k := k) (α := α) (β := β)) :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    MState.measurable_toTuple)))

theorem MState.measurable_pay : Measurable (MState.pay (k := k) (α := α) (β := β)) :=
  measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    MState.measurable_toTuple)))

/-- A map into `MState` is measurable iff its tuple is. -/
theorem MState.measurable_iff {Ω : Type*} [MeasurableSpace Ω] {f : Ω → MState k α β} :
    Measurable f ↔ Measurable (fun ω => (f ω).toTuple) := by
  refine ⟨fun h => MState.measurable_toTuple.comp h, fun h => ?_⟩
  rw [measurable_iff_comap_le]
  have : MeasurableSpace.comap f (MeasurableSpace.comap MState.toTuple inferInstance) =
      MeasurableSpace.comap (fun ω => (f ω).toTuple) inferInstance := by
    rw [MeasurableSpace.comap_comp]
    rfl
  change MeasurableSpace.comap f (MeasurableSpace.comap MState.toTuple inferInstance) ≤ _
  rw [this]
  exact h.comap_le

theorem MState.measurable_weight (r : ℕ) :
    Measurable fun st : MState k α β => st.weight r := by
  unfold MState.weight
  by_cases hr : r = adaL α
  · simp only [if_pos hr]
    exact measurable_const
  · simp only [if_neg hr]
    rcases Nat.eq_zero_or_pos (adaBlock k α β r) with h0 | hpos
    · have : IsEmpty (Fin (adaBlock k α β r)) := by
        rw [h0]
        infer_instance
      exact measurable_of_subsingleton_codomain _
    · exact (Opt.measurable_waterFill hpos 1).comp ((measurable_pi_apply r).comp MState.measurable_pay)

theorem measurable_theta (r : ℕ) :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) => p.1.theta p.2 r := by
  unfold MState.theta
  refine Finset.measurable_sum _ fun ℓ _ => ?_
  exact ((measurable_pi_apply ℓ).comp ((MState.measurable_weight r).comp measurable_fst)).mul
    ((measurable_pi_apply _).comp measurable_snd)

theorem measurable_noiseBeta (i : ℕ) : Measurable fun ω : AdaOmega k α => noiseBeta ω i := by
  unfold noiseBeta
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseNu (i r : ℕ) : Measurable fun ω : AdaOmega k α => noiseNu ω i r := by
  unfold noiseNu
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseZeta (i r : ℕ) : Measurable fun ω : AdaOmega k α => noiseZeta ω i r := by
  unfold noiseZeta
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseRho (r e : ℕ) : Measurable fun ω : AdaOmega k α => noiseRho ω r e := by
  unfold noiseRho
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

/-- The chain data of a round form a measurable family in (state, query values, noise). -/
theorem measFamily_roundChain (i : ℕ) :
    ChainData.MeasFamily
      (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
        roundChain p.1 i p.2.1 p.2.2) (adaL α) (adaTau α) where
  hL _ := rfl
  htau _ := rfl
  hc1 := by
    show Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      clip01 (p.1.theta p.2.1 1 + adaR1 α * Dist.clampUnit (noiseBeta p.2.2 i))
    exact measurable_clip01.comp (((measurable_theta 1).comp (measurable_fst.prodMk
      (measurable_fst.comp measurable_snd))).add (measurable_const.mul
        (Dist.measurable_clampUnit.comp ((measurable_noiseBeta i).comp
          (measurable_snd.comp measurable_snd)))))
  htheta s := (measurable_theta s).comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
  hrho s := by
    show Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      noiseRho p.2.2 s (p.1.M s - 1)
    have hM : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
        p.1.M s - 1 :=
      (measurable_from_nat (f := fun n : ℕ => n - 1)).comp
        ((measurable_pi_apply s).comp (MState.measurable_M.comp measurable_fst))
    exact measurable_nat_index
      (g := fun e (p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α) =>
        noiseRho p.2.2 s e)
      (fun e => (measurable_noiseRho s e).comp (measurable_snd.comp measurable_snd)) hM
  hnu s := (measurable_noiseNu i s).comp (measurable_snd.comp measurable_snd)
  hzeta s := (measurable_noiseZeta i s).comp (measurable_snd.comp measurable_snd)

theorem measurable_activeRec (i : ℕ) :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      activeRec p.1 i p.2.1 p.2.2 :=
  (measFamily_roundChain i).measurable_toRec _ _ _

theorem measurable_next :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      p.1.next p.2.1 p.2.2 := by
  rw [MState.measurable_iff]
  have hu : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      p.2.2.ufinal := RoundRec.measurable_ufinal.comp (measurable_snd.comp measurable_snd)
  have ht1 : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      p.1.t1 := MState.measurable_t1.comp measurable_fst
  have hNu : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      p.1.N p.2.2.ufinal :=
    measurable_nat_index (g := fun n p => p.1.N n)
      (fun n => (measurable_pi_apply n).comp (MState.measurable_N.comp measurable_fst)) hu
  have hhalt : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      (p.1.next p.2.1 p.2.2).halt := by
    have h : (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
        (p.1.next p.2.1 p.2.2).halt) =
        (fun t : ℕ × ℕ × ℕ => decide ((t.1 = 2 ∧ t.2.1 + 1 = adaT1max α) ∨
          (3 ≤ t.1 ∧ t.2.2 + 1 = adaNmax α t.1))) ∘
        (fun p => (p.2.2.ufinal, p.1.t1, p.1.N p.2.2.ufinal)) := rfl
    rw [h]
    exact (measurable_of_countable _).comp (hu.prodMk (ht1.prodMk hNu))
  have hT : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      (p.1.next p.2.1 p.2.2).t1 := by
    have h : (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
        (p.1.next p.2.1 p.2.2).t1) =
        (fun t : ℕ × ℕ => t.1 + if t.2 = 2 then 1 else 0) ∘ (fun p => (p.1.t1, p.2.2.ufinal)) := rfl
    rw [h]
    exact (measurable_of_countable _).comp (ht1.prodMk hu)
  have hN : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      (p.1.next p.2.1 p.2.2).N := by
    rw [measurable_pi_iff]
    intro r
    have h : (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
        (p.1.next p.2.1 p.2.2).N r) =
        (fun t : ℕ × ℕ => t.1 + if 3 ≤ t.2 ∧ r = t.2 then 1 else 0) ∘ (fun p => (p.1.N r, p.2.2.ufinal)) :=
      rfl
    rw [h]
    exact (measurable_of_countable _).comp
      (((measurable_pi_apply r).comp (MState.measurable_N.comp measurable_fst)).prodMk hu)
  have hM : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      (p.1.next p.2.1 p.2.2).M := by
    rw [measurable_pi_iff]
    intro r
    have h : (fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
        (p.1.next p.2.1 p.2.2).M r) =
        (fun t : ℕ × ℕ => t.1 + if 2 ≤ r ∧ r ≤ t.2 then 1 else 0) ∘ (fun p => (p.1.M r, p.2.2.ufinal)) :=
      rfl
    rw [h]
    exact (measurable_of_countable _).comp
      (((measurable_pi_apply r).comp (MState.measurable_M.comp measurable_fst)).prodMk hu)
  have hpay : Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      (p.1.next p.2.1 p.2.2).pay := by
    rw [measurable_pi_iff]
    intro r
    rw [measurable_pi_iff]
    intro ℓ
    show Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × RoundRec =>
      p.1.pay r ℓ + p.2.2.delta r * p.2.1 (adaBlockIdx k α β r ℓ)
    exact ((measurable_pi_apply ℓ).comp ((measurable_pi_apply r).comp
      (MState.measurable_pay.comp measurable_fst))).add
      (((measurable_pi_apply r).comp (RoundRec.measurable_delta.comp
        (measurable_snd.comp measurable_snd))).mul
        ((measurable_pi_apply _).comp (measurable_fst.comp measurable_snd)))
  exact hhalt.prodMk (hT.prodMk (hN.prodMk (hM.prodMk hpay)))

theorem measurable_step (i : ℕ) :
    Measurable fun p : MState k α β × (Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      step p.1 i p.2.1 p.2.2 := by
  unfold step
  refine Measurable.ite ?_ (measurable_fst.prodMk measurable_const) ?_
  · exact (MState.measurable_halt.comp measurable_fst) (measurableSet_singleton true)
  · exact (measurable_next.comp (measurable_fst.prodMk ((measurable_fst.comp measurable_snd).prodMk
      (measurable_activeRec i)))).prodMk (measurable_activeRec i)

end State

/-! ## The mechanism and the transcript -/

section Main

variable {k : ℕ} {α β : ℝ} {X : Type} [MeasurableSpace X]

theorem measurable_extendVals {i : ℕ} (j : ℕ) :
    Measurable fun vals : Fin (i + 1) → Fin (adaSampleSize k α β) → ℝ => extendVals vals j := by
  unfold extendVals
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_run_extendVals (i j : ℕ) :
    Measurable fun p : (Fin (i + 1) → Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      run k α β (extendVals p.1) p.2 j := by
  induction j with
  | zero => exact measurable_const
  | succ j ih =>
    exact measurable_fst.comp ((measurable_step j).comp
      (ih.prodMk (((measurable_extendVals j).comp measurable_fst).prodMk measurable_snd)))

/-- **Measurability of the mechanism**: each answer of `adaMech` is a jointly measurable function of the
query values and the noise table. -/
theorem measurable_adaMech (k : ℕ) (α β : ℝ) (i : ℕ) :
    Measurable (fun p : (Fin (i + 1) → Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
      adaMech k α β i p.1 p.2) := by
  show Measurable fun p : (Fin (i + 1) → Fin (adaSampleSize k α β) → ℝ) × AdaOmega k α =>
    (step (run k α β (extendVals p.1) p.2 i) i (extendVals p.1 i) p.2).2.answer
  exact RoundRec.measurable_answer.comp (measurable_snd.comp ((measurable_step i).comp
    ((measurable_run_extendVals i i).prodMk (((measurable_extendVals i).comp measurable_fst).prodMk
      measurable_snd))))

theorem measurable_onlineRun (A : DetAnalyst X) (hA : A.JointlyMeasurable) (i : ℕ) :
    Measurable fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
      onlineRun k α β A z.1 z.2 i := by
  induction i with
  | zero => exact measurable_const
  | succ i ih =>
    have hhist : Measurable fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
        (onlineRun k α β A z.1 z.2 i).2 := measurable_snd.comp ih
    have hq : Measurable fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
        (fun ℓ => A i (onlineRun k α β A z.1 z.2 i).2 (z.1 ℓ)) := by
      rw [measurable_pi_iff]
      intro ℓ
      exact (hA i).comp (hhist.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))
    have hstep := (measurable_step i).comp ((measurable_fst.comp ih).prodMk (hq.prodMk measurable_snd))
    exact (measurable_fst.comp hstep).prodMk
      (measurable_fin_snoc (measurable_snd.comp ih) (measurable_snd.comp hstep))

/-- **Measurability of the transcript**: for a jointly measurable deterministic analyst, the transcript
`(S, ω) ↦ h` is measurable. -/
theorem measurable_transcript (A : DetAnalyst X) (hA : A.JointlyMeasurable) :
    Measurable (fun z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
      transcript k α β A z.1 z.2) :=
  measurable_snd.comp (measurable_onlineRun A hA k)

/-! ## Stage laws as kernels -/

theorem measurable_replaceBlock (k : ℕ) (α β : ℝ) (r : ℕ) :
    Measurable (fun p : (Fin (adaBlock k α β r) → X) × (Fin (adaSampleSize k α β) → X) =>
      replaceBlock k α β r p.1 p.2) := by
  rw [measurable_pi_iff]
  intro q
  by_cases hq : adaOffset k α β r ≤ q.val ∧ q.val < adaOffset k α β r + adaBlock k α β r
  · simp only [replaceBlock, dif_pos hq]
    exact (measurable_pi_apply _).comp measurable_fst
  · simp only [replaceBlock, dif_neg hq]
    exact (measurable_pi_apply _).comp measurable_snd

theorem measurable_mixNoise (k : ℕ) (α : ℝ) (r : ℕ) :
    Measurable (fun p : AdaOmega k α × AdaOmega k α => mixNoise r p.1 p.2) := by
  rw [measurable_pi_iff]
  intro j
  by_cases hj : j.stage = r
  · simp only [mixNoise, if_pos hj]
    exact (measurable_pi_apply _).comp measurable_fst
  · simp only [mixNoise, if_neg hj]
    exact (measurable_pi_apply _).comp measurable_snd

/-- The transcript as a function of (block `S_r`, noise), with the other blocks taken from `S` and the noise
not owned by stage `r` taken from `ω'`. -/
noncomputable def stageMap (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (r : ℕ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) :
    (Fin (adaBlock k α β r) → X) × AdaOmega k α → (Fin k → RoundRec) :=
  fun p => transcript k α β A (replaceBlock k α β r p.1 S) (mixNoise r p.2 ω')

theorem measurable_stageMap (A : DetAnalyst X) (hA : A.JointlyMeasurable) (r : ℕ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) :
    Measurable (stageMap k α β A r S ω') := by
  have h1 : Measurable (fun p : (Fin (adaBlock k α β r) → X) × AdaOmega k α =>
      replaceBlock k α β r p.1 S) :=
    (measurable_replaceBlock k α β r).comp (measurable_fst.prodMk measurable_const)
  have h2 : Measurable (fun p : (Fin (adaBlock k α β r) → X) × AdaOmega k α => mixNoise r p.2 ω') :=
    (measurable_mixNoise k α r).comp (measurable_snd.prodMk measurable_const)
  exact (measurable_transcript A hA).comp (h1.prodMk h2)

/-- The Markov-kernel form of `stageLaw`: `S_r ↦` the law of the transcript when the stage-`r` noise is drawn
from `P_M`, the other blocks are those of `S` and the other noise is that of `ω'`. -/
noncomputable def stageKernel (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (r : ℕ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) :
    Kernel (Fin (adaBlock k α β r) → X) (Fin k → RoundRec) :=
  Kernel.map (Kernel.prod (Kernel.deterministic id measurable_id)
    (Kernel.const _ (adaNoiseMeasure k α β))) (stageMap k α β A r S ω')

theorem stageKernel_apply (A : DetAnalyst X) (hA : A.JointlyMeasurable) (r : ℕ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) (Sr : Fin (adaBlock k α β r) → X) :
    stageKernel k α β A r S ω' Sr = stageLaw k α β A r S ω' Sr := by
  unfold stageKernel stageLaw
  rw [Kernel.map_apply _ (measurable_stageMap A hA r S ω'), Kernel.prod_apply,
    Kernel.deterministic_apply, Kernel.const_apply, Measure.dirac_prod,
    Measure.map_map (measurable_stageMap A hA r S ω') measurable_prodMk_left]
  rfl

theorem isMarkovKernel_stageKernel (A : DetAnalyst X) (hA : A.JointlyMeasurable) (r : ℕ)
    (S : Fin (adaSampleSize k α β) → X) (ω' : AdaOmega k α) :
    IsMarkovKernel (stageKernel k α β A r S ω') :=
  Kernel.IsMarkovKernel.map _ (measurable_stageMap A hA r S ω')

end Main

end A

end F2e2e
