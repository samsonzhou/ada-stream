import F2e2e.A.SpecV2BridgeGuarantee
import F2e2e.A.NumericsContracts

/-!
# Spec v2 (A) bridge, part 4: `Theorem_A_statistical` for the v2 candidate (A-ACC draft)

Assembly of the five conjuncts of `F2e2e.Theorem_A_statistical`:
1. `IsProbabilityMeasure (adaCoinLaw k α β)`: A-ARCH, `V2Meas.isProbabilityMeasure_adaCoinLaw`;
2. `(adaCascade k α β).JointlyMeasurable`: A-ARCH, `V2Meas.jointlyMeasurable_adaCascade`;
3. the explicit bound and 4. the asymptotic bound: A-NUM, `adaSampleSize_le_explicit`, `adaSampleSize_le_asymp`
   (the v2 sample-size definitions are definitionally v1's);
5. `ADAPublicGuarantee`: `adaPublicGuarantee_adaCascade` (this bridge, from A-ARCH's `adaMech_accurate_det`).
-/

namespace F2e2e.A.V2Bridge

/-- **Main Theorem (A), statistical content (Spec v2 candidate).** -/
theorem theorem_A_statistical_bridge : F2e2e.Theorem_A_statistical := by
  obtain ⟨C, hC, hasymp⟩ := adaSampleSize_le_asymp
  refine ⟨C, hC, fun k α β hk hα hα' hβ hβ' => ⟨?_, ?_, ?_, ?_, ?_⟩⟩
  · exact V2Meas.isProbabilityMeasure_adaCoinLaw (adaBsvt_pos hα hα' hβ hβ' hk)
  · exact V2Meas.jointlyMeasurable_adaCascade hα
  · exact adaSampleSize_le_explicit k α β hk hα hα' hβ hβ'
  · exact hasymp k α β hk hα hα' hβ hβ'
  · exact adaPublicGuarantee_adaCascade hk hα hα' hβ hβ'

end F2e2e.A.V2Bridge
