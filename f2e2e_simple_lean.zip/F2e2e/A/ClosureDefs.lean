import F2e2e.A.Chain
import F2e2e.A.ClosureTilted
import F2e2e.A.ClosureCore

/-!
# Part I §5: the transcript functionals of the closure arguments

Paper: `parts/partI.tex` §5 (L1750–1986); `notes/PAPER_MAP_I_c.md` I.5.3–I.5.D.

* `stage1F α D A h x` : the Stage-1 stopped drift functional `F⁽¹⁾(h, x)` (eq. `I:eq:F1_stopped_drift_def`);
* `AmEvent α D A h m` : `A_m(h) = E_halt(h) ∩ {Prog_m(h) ≥ 128}`; `adaWmax α m` : `W̃_{max,m}`;
  `valF α D A h m x` : `F^{(m)}(h, x)` (eqs. `I:eq:Am_event_def`, `I:eq:Fm_validator_def`);
* `blockVals`, `tiltG k α β A r ε F z` : `Ĝ_r = Z_r(S_r) ⟨Q*^{(r)}, F(h, S_r)⟩` for the two-level tilted comparator
  (Lemma `I:lem:tilted_comparator`, `F2e2e/A/ClosureTilted.lean`) of `F` on block `r` at privacy `ε`.

Both test functionals are written with the gated `linTest` (`F2e2e/A/ClosureCore.lean`): the gate is the step budget
(`∑_i |δ_{1,i}| = η₁ T_{1,max}` on `{t₁ = T_{1,max}}`, resp. `8 w_m ∑_i |δ_{m,i}| ≤ W̃_{max,m}`), which holds on every
transcript of the mechanism; it makes the functionals bounded for *every* argument `h`, as the transfer lemma
requires. Also: the range/centering facts (Lemma `I:lem:stage1_trigger_cap_closure`(i), Lemma
`I:lem:obl1_measurability_ceiling`(2)), the pigeonhole covering (Lemma `I:lem:obl1_measurability_ceiling`(1)) and the
equalized KL penalty (Theorem `I:thm:pigeonhole_comparator_closure`(1)).
-/

namespace F2e2e.A

open MeasureTheory Finset

noncomputable section

variable {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ}

/-- The Stage-1 stopped drift functional `F⁽¹⁾(h, x)` (eq. `I:eq:F1_stopped_drift_def`). On `{t₁ = T_{1,max}}`
it is `(1/T_{1,max}) ∑_{u=1}^{T_{1,max}} s_u (q_{i_u}(x) - μ_{i_u}) = (1/(η₁ T_{1,max})) ∑_{i<k} (-δ_{1,i})(q_i(x) - μ_i)`
(`δ_{1,i} = -η₁ s` on the Case-A rounds and `0` otherwise, `transcript_delta_one`); it is `0` on `{t₁ < T_{1,max}}`. -/
def stage1F (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (x : X) : ℝ :=
  if finalT1 h = adaT1max α then
    linTest Finset.univ (1 / (adaEta1 α * adaT1max α)) (fun i => -(h i).delta 1) (fun i => popMu D A h i)
      (fun i => qry A h i) x
  else 0

/-- The Pigeonhole winner event `A_m(h) = E_halt(h) ∩ {Prog_m(h) ≥ 128}` (eq. `I:eq:Am_event_def`). -/
def AmEvent (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (m : ℕ) : Prop :=
  EHalt α h ∧ 128 ≤ progM α D A h m

/-- The deterministic `ℓ₁` step-capacity normalizer `W̃_{max,m} = γ (w_m N_{m+1,max} + w_{m-1} N_{m,max} 1{m ≥ 3})`
(eq. `I:eq:Am_event_def`; at `m = 2` the second summand is absent). -/
def adaWmax (α : ℝ) (m : ℕ) : ℝ :=
  adaGamma α * (adaW α m * adaNmax α (m + 1) + if 3 ≤ m then adaW α (m - 1) * adaNmax α m else 0)

/-- The `A_m(h)`-gated comparator test functional
`F^{(m)}(h, x) = 1_{A_m(h)} (8 w_m/W̃_{max,m}) ∑_i (-δ_{m,i})(q_i(x) - μ_i)` (eq. `I:eq:Fm_validator_def`). -/
def valF (α : ℝ) (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (m : ℕ) (x : X) : ℝ := by
  classical
  exact if AmEvent α D A h m then
    linTest Finset.univ (8 * adaW α m / adaWmax α m) (fun i => -(h i).delta m) (fun i => popMu D A h i)
      (fun i => qry A h i) x
  else 0

/-- The values `ℓ ↦ F(h, X_{r,ℓ})` of a test functional on block `r` (`h` the transcript). -/
def blockVals (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (r : ℕ) (F : (Fin k → RoundRec) → X → ℝ)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) : Fin (adaBlock k α β r) → ℝ :=
  fun ℓ => F (transcript k α β A z.1 z.2) (blockOf k α β r z.1 ℓ)

/-- `Ĝ_r = Z_r(S_r) ⟨Q*^{(r)}, F(h, S_r)⟩` (Lemma `I:lem:tilted_comparator`, eq. `I:eq:dp_transfer_bound`). -/
def tiltG (k : ℕ) (α β : ℝ) (A : DetAnalyst X) (r : ℕ) (ε : ℝ) (F : (Fin k → RoundRec) → X → ℝ)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α) : ℝ :=
  tiltZ ε (blockVals k α β A r F z) *
    ∑ ℓ, tiltQ ε (blockVals k α β A r F z) ℓ * blockVals k α β A r F z ℓ

/-- Population means of `[0,1]`-valued queries lie in `[0,1]`. -/
theorem popMu_mem_Icc (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (h : Fin k → RoundRec) (i : ℕ) : popMu D A h i ∈ Set.Icc (0 : ℝ) 1 := by
  unfold popMu
  constructor
  · exact integral_nonneg fun x => (hA i _ x).1
  · by_cases hi : Integrable (qry A h i) D
    · calc ∫ x, qry A h i x ∂D ≤ ∫ _x, (1 : ℝ) ∂D :=
            integral_mono hi (integrable_const 1) fun x => (hA i _ x).2
        _ = 1 := by simp
    · rw [integral_undef hi]
      norm_num

omit [MeasurableSpace X] in
theorem qry_mem_Icc (A : DetAnalyst X) (hA : A.Valid) (h : Fin k → RoundRec) (i : ℕ) (x : X) :
    qry A h i x ∈ Set.Icc (0 : ℝ) 1 := hA i _ x

theorem integrable_qry (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable) (h : Fin k → RoundRec) (i : ℕ) : Integrable (qry A h i) D := by
  have hm : Measurable (qry A h i) := by
    have := hAm i
    exact this.comp (measurable_const.prodMk measurable_id)
  refine (integrable_const (1 : ℝ)).mono' hm.aestronglyMeasurable (Filter.Eventually.of_forall fun x => ?_)
  rw [Real.norm_eq_abs, abs_of_nonneg (qry_mem_Icc A hA h i x).1]
  exact (qry_mem_Icc A hA h i x).2

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(i)**, range: `F⁽¹⁾(h, x) ∈ [-1, 1]` for all `(h, x)`. -/
theorem stage1F_mem_Icc (hα : 0 < α) (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hA : A.Valid) (h : Fin k → RoundRec) (x : X) : stage1F α D A h x ∈ Set.Icc (-1 : ℝ) 1 := by
  unfold stage1F
  split_ifs
  · have hc : (0 : ℝ) ≤ 1 / (adaEta1 α * adaT1max α) := by
      unfold adaEta1
      positivity
    exact linTest_mem_Icc Finset.univ hc (fun i => -(h i).delta 1) (fun i => popMu D A h i)
      (fun i => qry A h i) (fun i x => qry_mem_Icc A hA h i x) (fun i => popMu_mem_Icc D A hA h i) x
  · exact ⟨by norm_num, by norm_num⟩

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(i)**, centering: `E_{X' ∼ D}[F⁽¹⁾(h, X') | h] = 0`. -/
theorem integral_stage1F (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable) (h : Fin k → RoundRec) : ∫ x, stage1F α D A h x ∂D = 0 := by
  unfold stage1F
  split_ifs
  · exact integral_linTest D _ _ _ _ _ (fun i => integrable_qry D A hA hAm h i) (fun i => rfl)
  · simp

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(ii)**, off the cap event: `F⁽¹⁾(h, ·) ≡ 0` on `{t₁ < T_{1,max}}`, so
`Ĝ₁ = 0` there. -/
theorem tiltG_stage1_eq_zero (D : Measure X) (A : DetAnalyst X) (ε : ℝ)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hT : finalT1 (transcript k α β A z.1 z.2) ≠ adaT1max α) :
    tiltG k α β A 1 ε (fun h => stage1F α D A h) z = 0 := by
  unfold tiltG blockVals stage1F
  simp [hT]

/-- **Lemma `I:lem:obl1_measurability_ceiling`(1)**, pigeonhole covering (eq. `I:eq:pigeonhole_inclusion`): if
`∑_{m=2}^{L-1} Prog_m(h) ≥ 192 L` (§4, on `E_halt ∩ E_clean`) and `E_halt(h)` holds, some level `2 ≤ m ≤ L-1` has
`A_m(h)`. -/
theorem pigeonhole_inclusion (D : Measure X) (A : DetAnalyst X) (h : Fin k → RoundRec) (hhalt : EHalt α h)
    (h192 : 192 * (adaL α : ℝ) ≤ ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A h m) :
    ∃ m ∈ Finset.Icc 2 (adaL α - 1), AmEvent α D A h m := by
  obtain ⟨m, hm, h128⟩ := exists_ge_of_sum_ge (by have := adaL_ge_four α; omega) _ h192
  exact ⟨m, hm, hhalt, h128⟩

/-- **Lemma `I:lem:obl1_measurability_ceiling`(2)**: `E_{X' ∼ D}[F^{(m)}(h, X') | h] = 0`. -/
theorem integral_valF (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable) (h : Fin k → RoundRec) (m : ℕ) : ∫ x, valF α D A h m x ∂D = 0 := by
  classical
  unfold valF
  split_ifs
  · exact integral_linTest D _ _ _ _ _ (fun i => integrable_qry D A hA hAm h i) (fun i => rfl)
  · simp

/-- **Theorem `I:thm:pigeonhole_comparator_closure`(1)**, equalized dimensionless KL penalty
(eq. `I:eq:equalized_kl_penalty`): `8 w_m KL(Q*^{(m)} ‖ Unif) ≤ 4`. -/
theorem equalized_kl_penalty (hα : 0 < α) {n : ℕ} (hn : 0 < n) (m : ℕ) (f : Fin n → ℝ) :
    8 * adaW α m * Opt.klUnif n (tiltQ (adaEps α m) f) ≤ 4 := by
  have hε : 0 < adaEps α m := by
    unfold adaEps
    positivity
  have hKL := klUnif_tiltQ_le hn (adaEps α m) f
  have hw : adaW α m * adaEps α m ^ 2 = 1 := by
    unfold adaW
    field_simp
  have hw0 : 0 ≤ adaW α m := by
    unfold adaW
    positivity
  calc 8 * adaW α m * Opt.klUnif n (tiltQ (adaEps α m) f) ≤ 8 * adaW α m * (adaEps α m ^ 2 / 2) := by
        gcongr
    _ = 4 * (adaW α m * adaEps α m ^ 2) := by ring
    _ = 4 := by rw [hw, mul_one]

/-- **Theorem `I:thm:pigeonhole_comparator_closure`(1)**, off `A_m(h)`: `F^{(m)}(h, ·) ≡ 0`, so `Ĝ_m = 0`. -/
theorem tiltG_val_eq_zero (D : Measure X) (A : DetAnalyst X) (m : ℕ) (ε : ℝ)
    (z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α)
    (hAmz : ¬ AmEvent α D A (transcript k α β A z.1 z.2) m) :
    tiltG k α β A m ε (fun h => valF α D A h m) z = 0 := by
  classical
  unfold tiltG blockVals valF
  simp [hAmz]

end

end F2e2e.A
