import F2e2e.A.ClosureBridge
import F2e2e.A.Progress
import F2e2e.A.S1PrivacyMech
import F2e2e.A.ArchResample
import F2e2e.A.Anchor

/-!
# Part I §5 (closure arguments) and §6.1 (failure budget): the probability statements

Paper: `parts/partI.tex` Lemma `I:lem:tilted_comparator`(3) (L1668–1748), Lemma
`I:lem:stage1_trigger_cap_closure`(iii) (L1786–1790, L1811–1819), Theorem `I:thm:pigeonhole_comparator_closure`(2)
(L1942–1949, L1972–1985), Proposition `I:prop:end_to_end_accuracy` (L2016–2078); `notes/PAPER_MAP_I_c.md` I.5.2,
I.5.3, I.5.5, I.6.1.

The transcript functionals (`stage1F`, `AmEvent`, `adaWmax`, `valF`, `tiltG`) are in `F2e2e/A/ClosureDefs.lean`;
the deterministic comparator floors in `F2e2e/A/ClosureBridge.lean`; the abstract tilted comparator and DP transfer
in `F2e2e/A/ClosureTilted.lean`; the Markov/pigeonhole steps in `F2e2e/A/ClosureCore.lean`.

## Main statements
* `integral_tiltG_le`: the DP expectation transfer (`I:eq:dp_transfer_bound`) on the mechanism;
* `stage1_trigger_cap_prob`, `stage1_trigger_cap_prob_lt`: `P[{t₁ = T_{1,max}} ∩ E_clean] < 0.00176 β`;
* `validator_level_prob`, `validator_halt_prob_lt`: `P[E_halt ∩ E_clean] < 10⁻³ β`;
* `end_to_end_failure_of_inputs`: the failure budget `0.00301 β` from the §§2–4 inputs stated as hypotheses:
  - `hDP1` (Lemma `I:lem:working_sample_privacy`(3)): `∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A 1 S ω') adaEps1
    (adaDelta1 α β)`;
  - `hDPm` (Proposition `I:prop:homog_adv_comp`(i)): the same for `2 ≤ m ≤ L-1` with `(adaEps α m, adaDeltaVal α β / 2)`;
  - `hclean` (Proposition `I:prop:clean_event_bound`): `adaProb{¬ EClean} ≤ 100 δ_val/ε_L + δ_val`;
  - `hdec` (Lemma `I:lem:stage1_decoupling`, A-ACC's `stage1_drift_gt`): on `EClean`, every Case-A round has
    `s (θ^{(1)} - μ) > 3α/16`;
  - `hclip` (Lemma `I:lem:output_accuracy`(i), A-ACC's `clip_fidelity` with `rel_of_delta_ne_zero`): on `EClean`,
    validator values released on rounds with `δ_{m,i} ≠ 0` are `u₀`-close to `θ^{(m)}`;
  - `h192` (Lemma `I:lem:rl2_coupled_progress`(5), A-ACC's `coupled_progress_halt`): on `EHalt ∩ EClean`,
    `∑_{m=2}^{L-1} Prog_m ≥ 192 L`;
  - `hacc` (Lemma `I:lem:output_accuracy`(ii), A-ACC's `output_accuracy`): on `EClean`, every active round has
    `|a_i - μ_i| < α`;
* `adaMech_accurate_det` (consumed by A-ARCH's `Final.lean`): the hypothesis-free form, instantiating the inputs with
  `stage1_isDP` (`F2e2e/A/S1PrivacyMech.lean`), A-ACC's `F2e2e/A/Progress.lean` lemmas, and the §3 inputs
  `homog_adv_comp_mid` (Proposition `I:prop:homog_adv_comp`(i), `F2e2e/A/Validators.lean`) and
  `clean_event_bound` (Proposition `I:prop:clean_event_bound`, `F2e2e/A/Anchor.lean`).

The resampling identity `integral_adaProb_block` and `measurableSet_EClean` are A-ARCH's
(`F2e2e/A/ArchResample.lean`).
-/

namespace F2e2e.A

open MeasureTheory Finset

noncomputable section

variable {X : Type} [MeasurableSpace X] {k : ℕ} {α β : ℝ}

/-! ## The DP expectation transfer on the mechanism (Lemma `I:lem:tilted_comparator`(3)) -/

omit [MeasurableSpace X] in
/-- Measurability of `(S_r, h) ↦ Z ⟨Q*, F(h, S_r)⟩`. -/
theorem measurable_tilt_pair {n : ℕ} {Y : Type*} [MeasurableSpace Y] [MeasurableSpace X] (ε : ℝ)
    {F : Y → X → ℝ} (hF : Measurable (Function.uncurry F)) :
    Measurable (Function.uncurry fun (s : Fin n → X) (y : Y) =>
      tiltZ ε (fun ℓ => F y (s ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (s ℓ)) ℓ * F y (s ℓ)) := by
  have hb : ∀ ℓ : Fin n, Measurable fun p : (Fin n → X) × Y => F p.2 (p.1 ℓ) := fun ℓ =>
    hF.comp (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp measurable_fst))
  have hW : ∀ ℓ, Measurable fun p : (Fin n → X) × Y => tiltW ε (fun ℓ => F p.2 (p.1 ℓ)) ℓ := fun ℓ => by
    unfold tiltW
    exact Measurable.ite (measurableSet_le measurable_const (hb ℓ)) measurable_const measurable_const
  have hZ : Measurable fun p : (Fin n → X) × Y => tiltZ ε (fun ℓ => F p.2 (p.1 ℓ)) := by
    unfold tiltZ
    exact measurable_const.mul (Finset.measurable_sum _ fun ℓ _ => hW ℓ)
  show Measurable fun p : (Fin n → X) × Y =>
    tiltZ ε (fun ℓ => F p.2 (p.1 ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F p.2 (p.1 ℓ)) ℓ * F p.2 (p.1 ℓ)
  unfold tiltQ
  exact hZ.mul (Finset.measurable_sum _ fun ℓ _ => ((hW ℓ).div (measurable_const.mul hZ)).mul (hb ℓ))

/-- **Lemma `I:lem:tilted_comparator`(3) on the mechanism** (eq. `I:eq:dp_transfer_bound`): if `S_r ↦ h` is
`(ε, δ)`-DP for every fixed value of the other blocks and of the noise not owned by stage `r`, then for every jointly
measurable centered test functional `F : h, x ↦ [-1, 1]`, `E_{S, h}[Z_r(S_r) ⟨Q*^{(r)}, F(h, S_r)⟩] ≤ (1 + e^{-ε}) δ`. -/
theorem integral_tiltG_le (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X)
    (hAm : A.JointlyMeasurable) (r : ℕ) {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 ≤ δ)
    (hDP : ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A r S ω') ε δ)
    (F : (Fin k → RoundRec) → X → ℝ) (hF : Measurable (Function.uncurry F))
    (hF1 : ∀ h x, F h x ∈ Set.Icc (-1 : ℝ) 1) (hF0 : ∀ h, ∫ x, F h x ∂D = 0) :
    ∫ z, tiltG k α β A r ε F z ∂adaProb k α β D ≤ (1 + Real.exp (-ε)) * δ := by
  set G : (Fin (adaBlock k α β r) → X) → (Fin k → RoundRec) → ℝ := fun s y =>
    tiltZ ε (fun ℓ => F y (s ℓ)) * ∑ ℓ, tiltQ ε (fun ℓ => F y (s ℓ)) ℓ * F y (s ℓ) with hGdef
  have hGz : ∀ z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α,
      tiltG k α β A r ε F z = G (blockOf k α β r z.1) (transcript k α β A z.1 z.2) := fun z => rfl
  simp_rw [hGz]
  have hGm : Measurable (Function.uncurry G) := measurable_tilt_pair ε hF
  have hGb : ∃ C, ∀ s y, |G s y| ≤ C := ⟨Real.exp ε, fun s y => abs_tilt_le hε _ fun ℓ => hF1 _ _⟩
  rw [integral_adaProb_block D A hAm r G hGm hGb]
  have hC : 0 ≤ (1 + Real.exp (-ε)) * δ := mul_nonneg (by positivity) hδ
  have hin : ∀ w : (Fin (adaSampleSize k α β) → X) × AdaOmega k α,
      ∫ s, ∫ y, G s y ∂(stageKernel k α β A r w.1 w.2 s) ∂(Measure.pi fun _ => D) ≤
        (1 + Real.exp (-ε)) * δ := by
    intro w
    have := isMarkovKernel_stageKernel A hAm r w.1 w.2
    have hDPk : DP.IsDP DP.Neighbor (fun s => stageKernel k α β A r w.1 w.2 s) ε δ := by
      intro S S' hSS'
      show DP.Indist (stageKernel k α β A r w.1 w.2 S) (stageKernel k α β A r w.1 w.2 S') ε δ
      rw [stageKernel_apply A hAm, stageKernel_apply A hAm]
      exact hDP w.1 w.2 S S' hSS'
    exact tilted_transfer D (stageKernel k α β A r w.1 w.2) hδ hDPk F hF hF1 hF0
  by_cases hi : Integrable (fun w : (Fin (adaSampleSize k α β) → X) × AdaOmega k α =>
      ∫ s, ∫ y, G s y ∂(stageKernel k α β A r w.1 w.2 s) ∂(Measure.pi fun _ => D)) (adaProb k α β D)
  · calc ∫ w, ∫ s, ∫ y, G s y ∂(stageKernel k α β A r w.1 w.2 s) ∂(Measure.pi fun _ => D)
          ∂adaProb k α β D ≤ ∫ _w, (1 + Real.exp (-ε)) * δ ∂adaProb k α β D :=
          integral_mono hi (integrable_const _) hin
      _ = (1 + Real.exp (-ε)) * δ := by simp
  · rw [integral_undef hi]
    exact hC

/-! ## Lemma `I:lem:stage1_trigger_cap_closure`(iii) -/

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(iii)**, the Markov bound (first inequality of
`I:eq:stage1_trigger_cap_prob`), with the general `2δ₁` transfer bound. -/
theorem stage1_trigger_cap_prob (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    (hDP1 : ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A 1 S ω') adaEps1 (adaDelta1 α β))
    (hdec : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).ufinal = 2 →
      3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i)) :
    (adaProb k α β D).real
        {z | finalT1 (transcript k α β A z.1 z.2) = adaT1max α ∧ EClean k α β D A z} ≤
      (2 * adaDelta1 α β + Real.exp adaEps1 * (adaProb k α β D).real {z | ¬ EClean k α β D A z}) /
        (Real.exp (-adaEps1) * (1121 / 9600) * α) := by
  have hEm := measurableSet_EClean (k := k) (α := α) (β := β) D A hAm
  have hBm : MeasurableSet {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α |
      finalT1 (transcript k α β A z.1 z.2) = adaT1max α} :=
    (measurable_finalT1.comp (measurable_transcript A hAm)) (measurableSet_singleton _)
  have hG := measurable_tiltG (k := k) (α := α) (β := β) A hAm (measurable_stage1F (k := k) (α := α) D A hAm)
    1 adaEps1
  have hε0 : (0 : ℝ) ≤ adaEps1 := by unfold adaEps1; norm_num
  have hM : ∀ z, |tiltG k α β A 1 adaEps1 (fun h => stage1F α D A h) z| ≤ Real.exp adaEps1 := fun z =>
    abs_tilt_le hε0 _ fun ℓ => stage1F_mem_Icc hα D A hA _ _
  have hδ1 : 0 ≤ adaDelta1 α β := by unfold adaDelta1; positivity
  have hint : ∫ z, tiltG k α β A 1 adaEps1 (fun h => stage1F α D A h) z ∂adaProb k α β D ≤
      2 * adaDelta1 α β := by
    have h1 := integral_tiltG_le D A hAm 1 hε0 hδ1 hDP1 (fun h x => stage1F α D A h x)
      (measurable_stage1F D A hAm) (fun h x => stage1F_mem_Icc hα D A hA h x)
      (fun h => integral_stage1F D A hA hAm h)
    have h2 : Real.exp (-adaEps1) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    nlinarith
  have hc : 0 < Real.exp (-adaEps1) * (1121 / 9600) * α := by positivity
  have hconst := floor_consts
  exact markov_closure (adaProb k α β D) hG hEm hBm hc hM
    (fun z hz => tiltG_stage1_nonneg hk hα hα' hβ hβ' D A hA hAm hdec z hz)
    (fun z hz hB => by
      have h1 := stage1_comparator_floor hk hα hα' hβ hβ' D A hA hAm z hB (hdec z hz)
      have h2 : Real.exp (-adaEps1) * (1121 / 9600) * α ≤
          Real.exp (-adaEps1) * ((15 / 128 - 1 / 30000) * α) := by
        have := Real.exp_pos (-adaEps1)
        nlinarith [hconst.2]
      linarith)
    hint

/-- **Lemma `I:lem:stage1_trigger_cap_closure`(iii)**, numeric form (`I:eq:stage1_markov_derivation`):
`P[{t₁ = T_{1,max}} ∩ E_clean] < 0.00176 β`. -/
theorem stage1_trigger_cap_prob_lt (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable)
    (hDP1 : ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A 1 S ω') adaEps1 (adaDelta1 α β))
    (hdec : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).ufinal = 2 →
      3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i))
    (hclean : adaProb k α β D {z | ¬ EClean k α β D A z} ≤
      ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β)) :
    (adaProb k α β D).real
        {z | finalT1 (transcript k α β A z.1 z.2) = adaT1max α ∧ EClean k α β D A z} < 176 / 100000 * β := by
  have h := stage1_trigger_cap_prob hk hα hα' hβ hβ' D A hA hAm hDP1 hdec
  have hb : 0 ≤ 100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β := by
    have := adaDeltaVal_pos hα hβ
    have := adaEpsL_pos hα
    positivity
  have hp := ENNReal.toReal_le_of_le_ofReal hb hclean
  have hnum := stage1_budget_lt hα hα' hβ hβ' measureReal_nonneg hp
  unfold adaDelta1 adaEps1 at h
  exact lt_of_le_of_lt h hnum

/-! ## Theorem `I:thm:pigeonhole_comparator_closure`(2) -/

/-- **Theorem `I:thm:pigeonhole_comparator_closure`(2)**, per level (eq. `I:eq:Am_markov_bound`):
`P[A_m(h) ∩ E_clean] ≤ (δ_val + e^{ε_m} P[E_cleanᶜ])/(124 e^{-ε_m}/W̃_{max,m})`. -/
theorem validator_level_prob (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    {m : ℕ} (hm2 : 2 ≤ m) (hmL : m ≤ adaL α - 1)
    (hDPm : ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A m S ω') (adaEps α m) (adaDeltaVal α β / 2))
    (hclip : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).delta m ≠ 0 →
      |(transcript k α β A z.1 z.2 i).c m - (onlineChain k α β A z.1 z.2 i).theta m| ≤ adaU0 α) :
    (adaProb k α β D).real {z | AmEvent α D A (transcript k α β A z.1 z.2) m ∧ EClean k α β D A z} ≤
      (adaDeltaVal α β + Real.exp (adaEps α m) * (adaProb k α β D).real {z | ¬ EClean k α β D A z}) /
        (124 * Real.exp (-adaEps α m) / adaWmax α m) := by
  have hEm := measurableSet_EClean (k := k) (α := α) (β := β) D A hAm
  have hBm : MeasurableSet {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α |
      AmEvent α D A (transcript k α β A z.1 z.2) m} :=
    (measurable_transcript A hAm) (measurableSet_AmEvent D A hAm m)
  have hG := measurable_tiltG (k := k) (α := α) (β := β) A hAm
    (measurable_valF (k := k) (α := α) D A hAm m) m (adaEps α m)
  have hε0 : 0 ≤ adaEps α m := (adaEps_pos hα m).le
  have hM : ∀ z, |tiltG k α β A m (adaEps α m) (fun h => valF α D A h m) z| ≤ Real.exp (adaEps α m) :=
    fun z => abs_tilt_le hε0 _ fun ℓ => valF_mem_Icc hα hα' D A hA _ hm2 hmL _
  have hδv : 0 ≤ adaDeltaVal α β / 2 := by
    have := adaDeltaVal_pos hα hβ
    positivity
  have hint : ∫ z, tiltG k α β A m (adaEps α m) (fun h => valF α D A h m) z ∂adaProb k α β D ≤
      adaDeltaVal α β := by
    have h1 := integral_tiltG_le D A hAm m hε0 hδv hDPm (fun h x => valF α D A h m x)
      (measurable_valF D A hAm m) (fun h x => valF_mem_Icc hα hα' D A hA h hm2 hmL x)
      (fun h => integral_valF D A hA hAm h m)
    have h2 : Real.exp (-adaEps α m) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    nlinarith
  have hW := adaWmax_pos hα hα' hm2 hmL
  have hc : 0 < 124 * Real.exp (-adaEps α m) / adaWmax α m := by positivity
  exact markov_closure (adaProb k α β D) hG hEm hBm hc hM
    (fun z hz => by
      by_cases hAz : AmEvent α D A (transcript k α β A z.1 z.2) m
      · exact le_trans hc.le (validator_comparator_floor hk hα hα' hβ hβ' D A hA hAm hm2 hmL z hAz
          (hclip z hz))
      · rw [tiltG_val_eq_zero D A m _ z hAz])
    (fun z hz hB => validator_comparator_floor hk hα hα' hβ hβ' D A hA hAm hm2 hmL z hB (hclip z hz))
    hint

/-- **Theorem `I:thm:pigeonhole_comparator_closure`(2)**, summed over the levels with the pigeonhole covering
(eq. `I:eq:validator_halt_prob_bound`): `P[E_halt(h) ∩ E_clean] < 10⁻³ β` (the proof gives `< 10⁻¹¹ β`). -/
theorem validator_halt_prob_lt (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β) (hβ' : β < 1 / 2)
    (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable)
    (hDPm : ∀ m, 2 ≤ m → m ≤ adaL α - 1 →
      ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A m S ω') (adaEps α m) (adaDeltaVal α β / 2))
    (hclip : ∀ z, EClean k α β D A z → ∀ m, 2 ≤ m → m ≤ adaL α - 1 → ∀ i : Fin k,
      (transcript k α β A z.1 z.2 i).delta m ≠ 0 →
      |(transcript k α β A z.1 z.2 i).c m - (onlineChain k α β A z.1 z.2 i).theta m| ≤ adaU0 α)
    (h192 : ∀ z, EHalt α (transcript k α β A z.1 z.2) → EClean k α β D A z →
      192 * (adaL α : ℝ) ≤ ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A (transcript k α β A z.1 z.2) m)
    (hclean : adaProb k α β D {z | ¬ EClean k α β D A z} ≤
      ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β)) :
    (adaProb k α β D).real {z | EHalt α (transcript k α β A z.1 z.2) ∧ EClean k α β D A z} <
      1 / 10 ^ 3 * β := by
  set μ := adaProb k α β D with hμ
  set E := {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | EClean k α β D A z} with hE
  have hL4 := adaL_ge_four α
  -- the pigeonhole covering
  have hcov : {z | EHalt α (transcript k α β A z.1 z.2) ∧ EClean k α β D A z} ⊆
      ⋃ m ∈ Finset.Icc 2 (adaL α - 1), {z | AmEvent α D A (transcript k α β A z.1 z.2) m ∧ EClean k α β D A z} := by
    intro z ⟨hH, hz⟩
    obtain ⟨m, hm, hAm'⟩ := pigeonhole_inclusion D A _ hH (h192 z hH hz)
    exact Set.mem_biUnion hm ⟨hAm', hz⟩
  have hb : 0 ≤ 100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β := by
    have := adaDeltaVal_pos hα hβ
    have := adaEpsL_pos hα
    positivity
  have hp := ENNReal.toReal_le_of_le_ofReal hb hclean
  -- per-level numeric bound
  have hlevel : ∀ m ∈ Finset.Icc 2 (adaL α - 1),
      μ.real {z | AmEvent α D A (transcript k α β A z.1 z.2) m ∧ EClean k α β D A z} <
        15 * adaU0 α * β / (10 ^ 8 * (adaL α : ℝ) ^ 2) := by
    intro m hm
    rw [Finset.mem_Icc] at hm
    have h1 := validator_level_prob hk hα hα' hβ hβ' D A hA hAm hm.1 hm.2 (hDPm m hm.1 hm.2)
      (fun z hz => hclip z hz m hm.1 hm.2)
    have h2 := val_budget_lt hα hα' hβ hβ' (p := μ.real {z | ¬ EClean k α β D A z}) measureReal_nonneg hp
      (adaEps_pos hα m).le (adaEps_le_one_twentieth hα hα' (by omega)) (adaWmax_pos hα hα' hm.1 hm.2)
      (adaWmax_lt hα hα' hm.1 hm.2)
    exact lt_of_le_of_lt h1 h2
  have hne : (Finset.Icc 2 (adaL α - 1)).Nonempty := ⟨2, Finset.mem_Icc.mpr ⟨le_rfl, by omega⟩⟩
  have hcard : ((Finset.Icc 2 (adaL α - 1)).card : ℝ) = (adaL α : ℝ) - 2 := by
    rw [Nat.card_Icc, show adaL α - 1 + 1 - 2 = adaL α - 2 by omega, Nat.cast_sub (by omega)]
    norm_num
  calc μ.real {z | EHalt α (transcript k α β A z.1 z.2) ∧ EClean k α β D A z}
      ≤ μ.real (⋃ m ∈ Finset.Icc 2 (adaL α - 1),
          {z | AmEvent α D A (transcript k α β A z.1 z.2) m ∧ EClean k α β D A z}) :=
        measureReal_mono hcov (measure_ne_top _ _)
    _ ≤ ∑ m ∈ Finset.Icc 2 (adaL α - 1),
          μ.real {z | AmEvent α D A (transcript k α β A z.1 z.2) m ∧ EClean k α β D A z} :=
        measureReal_biUnion_finset_le _ _
    _ < ∑ _m ∈ Finset.Icc 2 (adaL α - 1), 15 * adaU0 α * β / (10 ^ 8 * (adaL α : ℝ) ^ 2) :=
        Finset.sum_lt_sum_of_nonempty hne hlevel
    _ = ((adaL α : ℝ) - 2) * (15 * adaU0 α * β / (10 ^ 8 * (adaL α : ℝ) ^ 2)) := by
        rw [Finset.sum_const, nsmul_eq_mul, hcard]
    _ < 1 / 10 ^ 11 * β := val_sum_lt hα hα' hβ
    _ ≤ 1 / 10 ^ 3 * β := by nlinarith

/-! ## Proposition `I:prop:end_to_end_accuracy` -/

/-- **Proposition `I:prop:end_to_end_accuracy`**, from the §§2–4 inputs (stated as hypotheses): the failure
probability is at most `(10⁻⁵ + 0.002 + 10⁻³) β = 0.00301 β` (with the sharper Stage-1 term `0.00176 β`). -/
theorem end_to_end_failure_of_inputs (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) (D : Measure X) [IsProbabilityMeasure D] (A : DetAnalyst X) (hA : A.Valid)
    (hAm : A.JointlyMeasurable)
    (hDP1 : ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A 1 S ω') adaEps1 (adaDelta1 α β))
    (hDPm : ∀ m, 2 ≤ m → m ≤ adaL α - 1 →
      ∀ S ω', DP.IsDP DP.Neighbor (stageLaw k α β A m S ω') (adaEps α m) (adaDeltaVal α β / 2))
    (hclean : adaProb k α β D {z | ¬ EClean k α β D A z} ≤
      ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β))
    (hdec : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).ufinal = 2 →
      3 / 16 * α < (transcript k α β A z.1 z.2 i).sgn *
        ((onlineChain k α β A z.1 z.2 i).theta 1 - popMu D A (transcript k α β A z.1 z.2) i))
    (hclip : ∀ z, EClean k α β D A z → ∀ m, 2 ≤ m → m ≤ adaL α - 1 → ∀ i : Fin k,
      (transcript k α β A z.1 z.2 i).delta m ≠ 0 →
      |(transcript k α β A z.1 z.2 i).c m - (onlineChain k α β A z.1 z.2 i).theta m| ≤ adaU0 α)
    (h192 : ∀ z, EHalt α (transcript k α β A z.1 z.2) → EClean k α β D A z →
      192 * (adaL α : ℝ) ≤ ∑ m ∈ Finset.Icc 2 (adaL α - 1), progM α D A (transcript k α β A z.1 z.2) m)
    (hacc : ∀ z, EClean k α β D A z → ∀ i : Fin k, (transcript k α β A z.1 z.2 i).active = true →
      |(transcript k α β A z.1 z.2 i).answer - popMu D A (transcript k α β A z.1 z.2) i| < α) :
    adaProb k α β D {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
      popMu D A (transcript k α β A z.1 z.2) i|} ≤
      ENNReal.ofReal (301 / 100000 * β) := by
  set μ := adaProb k α β D with hμ
  set E := {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α | EClean k α β D A z} with hE
  set B1 := {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α |
    finalT1 (transcript k α β A z.1 z.2) = adaT1max α ∧ EClean k α β D A z} with hB1
  set BH := {z : (Fin (adaSampleSize k α β) → X) × AdaOmega k α |
    EHalt α (transcript k α β A z.1 z.2) ∧ EClean k α β D A z} with hBH
  -- (i) on `E_good` there is no failure; hence the failure event is inside `Eᶜ ∪ B1 ∪ BH`
  have hsub : {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
      popMu D A (transcript k α β A z.1 z.2) i|} ⊆ (Eᶜ ∪ B1) ∪ BH := by
    intro z hz
    simp only [Set.mem_ofPred_eq] at hz
    obtain ⟨i, hi⟩ := hz
    by_contra hcon
    simp only [Set.mem_union, Set.mem_compl_iff, Set.mem_ofPred_eq, not_or, not_and, not_not, hE, hB1,
      hBH] at hcon
    obtain ⟨⟨hzE, hT⟩, hH⟩ := hcon
    have hT' : finalT1 (transcript k α β A z.1 z.2) < adaT1max α :=
      lt_of_le_of_ne (finalT1_le hα A z.1 z.2) (fun h => hT h hzE)
    have hN : ∀ r, 3 ≤ r → r ≤ adaL α → finalN (transcript k α β A z.1 z.2) r < adaNmax α r := by
      intro r h3 hL
      exact lt_of_le_of_ne (finalN_le hα A z.1 z.2 h3) (fun h => hH ⟨r, h3, hL, h⟩ hzE)
    have hact := active_of_caps A z.1 z.2 hT' hN i
    have := hacc z hzE i hact
    linarith
  -- (ii) the three bounds
  have hb : 0 ≤ 100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β := by
    have := adaDeltaVal_pos hα hβ
    have := adaEpsL_pos hα
    positivity
  have hcl := clean_budget_lt hα hα' hβ hβ'
  have h1 : μ B1 ≤ ENNReal.ofReal (176 / 100000 * β) := by
    rw [← ofReal_measureReal]
    exact ENNReal.ofReal_le_ofReal
      (stage1_trigger_cap_prob_lt hk hα hα' hβ hβ' D A hA hAm hDP1 hdec hclean).le
  have h2 : μ BH ≤ ENNReal.ofReal (1 / 10 ^ 3 * β) := by
    rw [← ofReal_measureReal]
    exact ENNReal.ofReal_le_ofReal
      (validator_halt_prob_lt hk hα hα' hβ hβ' D A hA hAm hDPm hclip h192 hclean).le
  calc μ {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
      popMu D A (transcript k α β A z.1 z.2) i|} ≤ μ ((Eᶜ ∪ B1) ∪ BH) := measure_mono hsub
    _ ≤ μ Eᶜ + μ B1 + μ BH := (measure_union_le _ _).trans (by gcongr; exact measure_union_le _ _)
    _ ≤ ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β) +
          ENNReal.ofReal (176 / 100000 * β) + ENNReal.ofReal (1 / 10 ^ 3 * β) :=
        add_le_add (add_le_add hclean h1) h2
    _ = ENNReal.ofReal (100 * adaDeltaVal α β / adaEpsL α + adaDeltaVal α β + 176 / 100000 * β +
          1 / 10 ^ 3 * β) := by
        have h176 : (0 : ℝ) ≤ 176 / 100000 * β := by positivity
        have h103 : (0 : ℝ) ≤ 1 / 10 ^ 3 * β := by positivity
        rw [← ENNReal.ofReal_add hb h176, ← ENNReal.ofReal_add (add_nonneg hb h176) h103]
    _ ≤ ENNReal.ofReal (301 / 100000 * β) := ENNReal.ofReal_le_ofReal (by linarith)

/-- **Proposition `I:prop:end_to_end_accuracy`** (the deterministic-analyst form of Theorem `I:thm:main`'s
accuracy, consumed by `F2e2e/A/Final.lean`): for every probability distribution `D` and every valid, jointly
measurable deterministic analyst `A`, the mechanism fails with probability at most `0.00301 β < β`. The Stage-1
privacy input is `stage1_isDP`; the §4 inputs are A-ACC's `stage1_drift_gt`, `clip_fidelity`/`rel_of_delta_ne_zero`,
`coupled_progress_halt`, `output_accuracy`. -/
theorem adaMech_accurate_det (k : ℕ) (α β : ℝ) (hk : 1 ≤ k) (hα : 0 < α) (hα' : α < 1 / 16) (hβ : 0 < β)
    (hβ' : β < 1 / 2) {X : Type} [MeasurableSpace X] (D : Measure X) [IsProbabilityMeasure D]
    (A : DetAnalyst X) (hA : A.Valid) (hAm : A.JointlyMeasurable) :
    adaProb k α β D {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
      popMu D A (transcript k α β A z.1 z.2) i|} ≤ ENNReal.ofReal β := by
  have h := end_to_end_failure_of_inputs hk hα hα' hβ hβ' D A hA hAm
    (fun S ω' => stage1_isDP k hα hα' hβ hβ' A hA hAm S ω')
    (fun m hm2 hmL => homog_adv_comp_mid hk hα hα' hβ hβ' A hA hAm hm2 hmL)
    (clean_event_bound hk hα hα' hβ hβ' D A hA hAm)
    (fun z hz i hi => stage1_drift_gt hα hα' D A hA z hz i hi)
    (fun z hz _m hm2 _ i hδ => clip_fidelity hα A hA z hz.2 i (rel_of_delta_ne_zero A z.1 z.2 i hm2 hδ))
    (fun z hH hz => coupled_progress_halt hα hα' D A hA z hz hH)
    (fun z hz i hi => (output_accuracy hα hα' D A hA z hz i hi).2.2)
  calc adaProb k α β D {z | ∃ i : Fin k, α < |(transcript k α β A z.1 z.2 i).answer -
      popMu D A (transcript k α β A z.1 z.2) i|}
      ≤ ENNReal.ofReal (301 / 100000 * β) := h
    _ ≤ ENNReal.ofReal β := ENNReal.ofReal_le_ofReal (by linarith)

end

end F2e2e.A
