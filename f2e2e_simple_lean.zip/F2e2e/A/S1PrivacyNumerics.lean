import F2e2e.A.S1PrivacyCore
import F2e2e.A.Params

/-!
# Stage-1 privacy: the numeric certificates for the locked parameters

Part I, Lemma `I:lem:working_sample_privacy` (`parts/partI.tex` L589–797), numeric facts of Steps 2–4 (see
`notes/PAPER_MAP_I_a.md` §I.2.2, "Numeric facts"): for `0 < α < 1/16`, `0 < β < 1/2`, every `k`, the locked
parameters `m = adaBetaM α β` (`7` in Branch 1A, `⌈L₁⌉` in Branch 1B), `L₁ = adaL1 α β`,
`n₁ = adaN1 k α β`, the normalized sensitivity `h = 128/(n₁ α)` (eq. `I:eq:stage1_normalized_shift_bound`),
`ε₁ = 0.05`, `δ₁ = αβ/10240` and the Freedman threshold `z = 0.045` satisfy all hypotheses of
`S1NoiseParams`:
* `L₁ > ln 655360 > 13.39` (L700), `κ = 64 m L₁ h < 1`, `h ≤ 1/1000`, `5990 h ≤ κ`, `12.8 h²(2m-1) ≤ 0.0089`;
* drift: `k · 0.67 𝓘_m h² < 0.005` (L776–777);
* failure: `k · κ^{m+1}/((m+1) Z_m √(1-κ)) ≤ δ₁/2` (Branch 1A: `κ² · κ⁶` split against the two terms of `n₁`,
  L712–721; Branch 1B: `κ ≤ 1/500`, L734–742) and Freedman's bound `≤ e^{-L₁} = δ₁/2` (L779–786).

The certificates use the two lower bounds `n₁ α ≥ 32000 √k χ₁` and `n₁ α ≥ 16000 L₁³/α` (eq. `I:eq:sec2_n1_def`),
i.e. `k χ₁² h² ≤ (128/32000)²` and `h L₁³ ≤ 0.008 α`.
-/

namespace F2e2e.A

open F2e2e.Dist

/-- The normalized Stage-1 sensitivity `h = 128/(n₁ α)` (eq. `I:eq:stage1_normalized_shift_bound`). -/
noncomputable def s1H (k : ℕ) (α β : ℝ) : ℝ := 128 / ((adaN1 k α β : ℝ) * α)

/-- `R₁ h = 4/n₁` (the sensitivity `Δ₁ = 4/n₁` of L680–684). -/
theorem adaR1_mul_s1H (k : ℕ) {α β : ℝ} (hα : 0 < α) :
    adaR1 α * s1H k α β = 4 / (adaN1 k α β : ℝ) := by
  unfold adaR1 s1H
  by_cases hn : (adaN1 k α β : ℝ) = 0
  · rw [hn]; simp
  · field_simp
    ring

/-! ### Elementary numeric facts -/

/-- `e^{13.39} < 655360`. -/
lemma exp_1339_lt : Real.exp 13.39 < 655360 := by
  have h1 : Real.exp 13.39 = Real.exp 1 ^ 13 * Real.exp 0.39 := by
    rw [Real.exp_one_pow, ← Real.exp_add]
    congr 1
    norm_num
  have h2 : Real.exp 1 ^ 13 < 2.7182818286 ^ 13 := by
    gcongr
    exact Real.exp_one_lt_d9
  have h3 : Real.exp 0.39 ≤ 1.4769814 := by
    have := Real.exp_bound' (x := 0.39) (by norm_num) (by norm_num) (n := 6) (by norm_num)
    norm_num [Finset.sum_range_succ, Nat.factorial] at this
    linarith
  rw [h1]
  calc Real.exp 1 ^ 13 * Real.exp 0.39 ≤ Real.exp 1 ^ 13 * 1.4769814 := by gcongr
    _ < 2.7182818286 ^ 13 * 1.4769814 := by gcongr
    _ < 655360 := by norm_num

/-- `L₁ > 13.39` (L700, from `αβ < 1/32`). -/
lemma adaL1_gt_1339 {α β : ℝ} (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hβ2 : β < 1 / 2) :
    13.39 < adaL1 α β := by
  unfold adaL1
  have hαβ : α * β < 1 / 32 := by nlinarith
  have hpos : 0 < α * β := mul_pos hα hβ
  rw [Real.lt_log_iff_exp_lt (by positivity)]
  have : (655360 : ℝ) < 20480 / (α * β) := by
    rw [lt_div_iff₀ hpos]; nlinarith
  linarith [exp_1339_lt]

/-- `L₁ > 26` in Branch 1B (`β < α⁵`, so `αβ < 16⁻⁶`). -/
lemma adaL1_gt_26 {α β : ℝ} (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β) (hb : β < α ^ 5) :
    26 < adaL1 α β := by
  unfold adaL1
  have hpos : 0 < α * β := mul_pos hα hβ
  have hα6 : α * β < (1 / 16) ^ 6 := by
    have h1 : α * β < α * α ^ 5 := mul_lt_mul_of_pos_left hb hα
    have h2 : α * α ^ 5 = α ^ 6 := by ring
    have h3 : α ^ 6 < (1 / 16) ^ 6 := by gcongr
    linarith
  rw [Real.lt_log_iff_exp_lt (by positivity)]
  have h4 : Real.exp 1 < 68 / 25 := by have := Real.exp_one_lt_d9; norm_num at this ⊢; linarith
  have h5 : Real.exp 26 < (68 / 25) ^ 26 := by
    have e : Real.exp 26 = Real.exp 1 ^ 26 := by rw [Real.exp_one_pow]; norm_num
    rw [e]
    gcongr
  have h6 : (20480 : ℝ) * 16 ^ 6 < 20480 / (α * β) := by
    rw [lt_div_iff₀ hpos]
    have : (20480 : ℝ) * 16 ^ 6 * (α * β) < 20480 * 16 ^ 6 * (1 / 16) ^ 6 := by gcongr
    norm_num at this ⊢
    linarith
  have h7 : ((68 : ℝ) / 25) ^ 26 < 20480 * 16 ^ 6 := by norm_num
  linarith

/-- For `t ≥ 1`: `0.131072 (t+2)² 3^{t+1} ≤ 500^t` (used for the Branch-1B boundary tail). -/
lemma aux_pow_le (t : ℕ) (ht : 1 ≤ t) :
    0.131072 * ((t : ℝ) + 2) ^ 2 * 3 ^ (t + 1) ≤ 500 ^ t := by
  induction t with
  | zero => omega
  | succ t ih =>
    rcases Nat.lt_or_ge t 1 with h0 | h1
    · have : t = 0 := by omega
      subst this
      norm_num
    · have ih' := ih h1
      have hstep : ((t : ℝ) + 1 + 2) ^ 2 * 3 ≤ 500 * ((t : ℝ) + 2) ^ 2 := by
        have : (0 : ℝ) ≤ t := Nat.cast_nonneg t
        nlinarith
      push_cast
      calc 0.131072 * ((t : ℝ) + 1 + 2) ^ 2 * 3 ^ (t + 1 + 1)
          = 0.131072 * 3 ^ (t + 1) * (((t : ℝ) + 1 + 2) ^ 2 * 3) := by ring
        _ ≤ 0.131072 * 3 ^ (t + 1) * (500 * ((t : ℝ) + 2) ^ 2) := by gcongr
        _ = 500 * (0.131072 * ((t : ℝ) + 2) ^ 2 * 3 ^ (t + 1)) := by ring
        _ ≤ 500 * 500 ^ t := by gcongr
        _ = 500 ^ (t + 1) := by ring

lemma half_le_sqrt_one_sub {κ : ℝ} (hκ : κ ≤ 3 / 4) : (1 : ℝ) / 2 ≤ Real.sqrt (1 - κ) := by
  rw [show (1 : ℝ) / 2 = Real.sqrt (1 / 4) by
    rw [show (1 : ℝ) / 4 = (1 / 2) ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
  exact Real.sqrt_le_sqrt (by linarith)

/-! ### Branch 1A (`m = 7`) -/

section BranchA

variable (k : ℕ) {α β h L : ℝ}

lemma tailA_boundary (hα : 0 < α) (hα16 : α < 1 / 16) (hb : α ^ 5 ≤ β) (hL : 13.39 < L)
    (hh0 : 0 < h) (hh3 : h * L ^ 3 ≤ 0.008 * α) (hkh : (k : ℝ) * L * h ^ 2 ≤ (128 / 32000) ^ 2) :
    (k : ℝ) * ((64 * ((7 : ℕ) : ℝ) * L * h) ^ (7 + 1) /
      ((((7 : ℕ) : ℝ) + 1) * betaSymZ 7 * Real.sqrt (1 - 64 * ((7 : ℕ) : ℝ) * L * h))) ≤
      α * β / 20480 := by
  have hL0 : 0 < L := by linarith
  have hκ : 64 * ((7 : ℕ) : ℝ) * L * h = 448 * (L * h) := by push_cast; ring
  rw [hκ, betaSymZ_seven]
  set κ := 448 * (L * h) with hκdef
  have hκ0 : 0 < κ := by have := mul_pos hL0 hh0; rw [hκdef]; linarith
  have hκ_le : κ ≤ 3.584 * α / L ^ 2 := by
    rw [le_div_iff₀ (pow_pos hL0 2)]
    have : κ * L ^ 2 = 448 * (h * L ^ 3) := by rw [hκdef]; ring
    rw [this]; linarith
  have hL2 : (169 : ℝ) ≤ L ^ 2 := by nlinarith
  have hκ_small : κ ≤ 1 / 100 := by
    have h1 : κ * L ^ 2 ≤ 3.584 * α := by
      have := (le_div_iff₀ (pow_pos hL0 2)).1 hκ_le; linarith
    have h2 : κ * 169 ≤ κ * L ^ 2 := mul_le_mul_of_nonneg_left hL2 hκ0.le
    linarith
  have hden : (1 : ℝ) / 2 ≤ (((7 : ℕ) : ℝ) + 1) * (4096 / 6435) * Real.sqrt (1 - κ) := by
    have := half_le_sqrt_one_sub (κ := κ) (by linarith)
    push_cast
    linarith
  have hkκ2 : (k : ℝ) * κ ^ 2 ≤ 448 ^ 2 * (128 / 32000) ^ 2 * L := by
    have e : (k : ℝ) * κ ^ 2 = 448 ^ 2 * L * ((k : ℝ) * L * h ^ 2) := by rw [hκdef]; ring
    rw [e]
    have h0 : (0 : ℝ) ≤ 448 ^ 2 * L := mul_nonneg (by norm_num) hL0.le
    calc 448 ^ 2 * L * ((k : ℝ) * L * h ^ 2) ≤ 448 ^ 2 * L * (128 / 32000) ^ 2 :=
          mul_le_mul_of_nonneg_left hkh h0
      _ = 448 ^ 2 * (128 / 32000) ^ 2 * L := by ring
  have hκ6 : κ ^ 6 ≤ (3.584 * α / L ^ 2) ^ 6 := pow_le_pow_left₀ hκ0.le hκ_le 6
  have hpow8 : (k : ℝ) * κ ^ (7 + 1) ≤ 448 ^ 2 * (128 / 32000) ^ 2 * L * (3.584 * α / L ^ 2) ^ 6 := by
    have e : (k : ℝ) * κ ^ (7 + 1) = ((k : ℝ) * κ ^ 2) * κ ^ 6 := by ring
    rw [e]
    exact mul_le_mul hkκ2 hκ6 (by positivity)
      (mul_nonneg (by norm_num) hL0.le)
  have hα6 : α ^ 6 ≤ α * β := by
    have e : α ^ 6 = α * α ^ 5 := by ring
    rw [e]; exact mul_le_mul_of_nonneg_left hb hα.le
  have hL11 : (13 : ℝ) ^ 11 ≤ L ^ 11 := by gcongr; linarith
  have hfinal : 2 * (448 ^ 2 * (128 / 32000) ^ 2 * L * (3.584 * α / L ^ 2) ^ 6) ≤ α * β / 20480 := by
    have hLne : L ≠ 0 := hL0.ne'
    have e : 2 * (448 ^ 2 * (128 / 32000) ^ 2 * L * (3.584 * α / L ^ 2) ^ 6) =
        (2 * 448 ^ 2 * (128 / 32000) ^ 2 * 3.584 ^ 6) * α ^ 6 / L ^ 11 := by
      field_simp
    rw [e, div_le_div_iff₀ (pow_pos hL0 11) (by norm_num)]
    have hc : (2 * 448 ^ 2 * (128 / 32000) ^ 2 * 3.584 ^ 6 : ℝ) * 20480 ≤ 13 ^ 11 := by norm_num
    have hα6' : 0 ≤ α ^ 6 := by positivity
    calc (2 * 448 ^ 2 * (128 / 32000) ^ 2 * 3.584 ^ 6 : ℝ) * α ^ 6 * 20480
        = ((2 * 448 ^ 2 * (128 / 32000) ^ 2 * 3.584 ^ 6 : ℝ) * 20480) * α ^ 6 := by ring
      _ ≤ 13 ^ 11 * α ^ 6 := mul_le_mul_of_nonneg_right hc hα6'
      _ ≤ L ^ 11 * (α * β) := mul_le_mul hL11 hα6 hα6' (pow_pos hL0 11).le
      _ = α * β * L ^ 11 := by ring
  have hnum0 : 0 ≤ (k : ℝ) * κ ^ (7 + 1) := by positivity
  calc (k : ℝ) * (κ ^ (7 + 1) / ((((7 : ℕ) : ℝ) + 1) * (4096 / 6435) * Real.sqrt (1 - κ)))
      = ((k : ℝ) * κ ^ (7 + 1)) / ((((7 : ℕ) : ℝ) + 1) * (4096 / 6435) * Real.sqrt (1 - κ)) := by
        ring
    _ ≤ ((k : ℝ) * κ ^ (7 + 1)) / (1 / 2) := div_le_div_of_nonneg_left hnum0 (by norm_num) hden
    _ = 2 * ((k : ℝ) * κ ^ (7 + 1)) := by ring
    _ ≤ 2 * (448 ^ 2 * (128 / 32000) ^ 2 * L * (3.584 * α / L ^ 2) ^ 6) := by linarith
    _ ≤ α * β / 20480 := hfinal

lemma tailA_freedman (hL : 13.39 < L) (hkh : (k : ℝ) * L * h ^ 2 ≤ (128 / 32000) ^ 2)
    (hexpL : Real.exp (-L) = α * β / 20480) :
    Real.exp (-((9 / 200 : ℝ) ^ 2 / (2 * ((k : ℝ) * (1.03 * betaSymFisher 7 * h ^ 2) +
      1 / (31 * L) * (9 / 200) / 3)))) ≤ α * β / 20480 := by
  have hL0 : 0 < L := by linarith
  rw [betaSymFisher_seven, ← hexpL]
  apply Real.exp_le_exp.2
  have hb' : 0 < 1 / (31 * L) * (9 / 200) / 3 :=
    div_pos (mul_pos (one_div_pos.2 (by linarith)) (by norm_num)) (by norm_num)
  have hS : 0 < 2 * ((k : ℝ) * (1.03 * (35 / 2) * h ^ 2) + 1 / (31 * L) * (9 / 200) / 3) := by
    have : (0 : ℝ) ≤ (k : ℝ) * (1.03 * (35 / 2) * h ^ 2) := by positivity
    linarith
  rw [neg_le_neg_iff, le_div_iff₀ hS]
  have hLne : L ≠ 0 := hL0.ne'
  have e : L * (2 * ((k : ℝ) * (1.03 * (35 / 2) * h ^ 2) + 1 / (31 * L) * (9 / 200) / 3)) =
      2 * 1.03 * (35 / 2) * ((k : ℝ) * L * h ^ 2) + 2 * (9 / 200) / 93 := by
    field_simp
    ring
  rw [e]
  linarith

lemma s1NoiseParams_A (hα : 0 < α) (hα16 : α < 1 / 16) (hb : α ^ 5 ≤ β) (hL : 13.39 < L)
    (hh0 : 0 < h) (hh3 : h * L ^ 3 ≤ 0.008 * α) (hkh : (k : ℝ) * L * h ^ 2 ≤ (128 / 32000) ^ 2)
    (hexpL : Real.exp (-L) = α * β / 20480) :
    S1NoiseParams k 7 h L (1 / 20) (α * β / 20480 + α * β / 20480) (9 / 200) := by
  have hL0 : 0 < L := by linarith
  have hL3 : (13 : ℝ) ^ 3 ≤ L ^ 3 := by gcongr; linarith
  have hhsmall : h ≤ 1 / 1000000 := by
    have h1 : h * 13 ^ 3 ≤ h * L ^ 3 := mul_le_mul_of_nonneg_left hL3 hh0.le
    have h2 : 0.008 * α ≤ 0.008 * (1 / 16) := by linarith
    norm_num at h1 h2 ⊢
    linarith
  have hκ : 64 * ((7 : ℕ) : ℝ) * L * h = 448 * (L * h) := by push_cast; ring
  have hκ_small : 448 * (L * h) ≤ 1 / 100 := by
    have hL2 : (169 : ℝ) ≤ L ^ 2 := by nlinarith
    have h1 : 448 * (L * h) * L ^ 2 = 448 * (h * L ^ 3) := by ring
    have h2 : 448 * (L * h) * 169 ≤ 448 * (L * h) * L ^ 2 :=
      mul_le_mul_of_nonneg_left hL2 (by have := mul_pos hL0 hh0; linarith)
    linarith
  refine ⟨by norm_num, hL0, hh0, by linarith, ?_, ?_, ?_, by norm_num, ?_, ?_⟩
  · push_cast; linarith
  · rw [hκ]; linarith
  · have : h ^ 2 ≤ (1 / 1000000) ^ 2 := pow_le_pow_left₀ hh0.le hhsmall 2
    push_cast
    norm_num at this ⊢
    linarith
  · rw [betaSymFisher_seven]
    have h1 : (k : ℝ) * h ^ 2 * 13 ≤ (k : ℝ) * h ^ 2 * L :=
      mul_le_mul_of_nonneg_left (by linarith) (by positivity)
    have h2 : (k : ℝ) * h ^ 2 * L = (k : ℝ) * L * h ^ 2 := by ring
    have h3 : (k : ℝ) * (0.67 * (35 / 2) * h ^ 2) = 0.67 * (35 / 2) * ((k : ℝ) * h ^ 2) := by ring
    rw [h3]
    norm_num at hkh h1 ⊢
    linarith
  · exact add_le_add (tailA_boundary k hα hα16 hb hL hh0 hh3 hkh) (tailA_freedman k hL hkh hexpL)

end BranchA

/-! ### Branch 1B (`m = ⌈L₁⌉`) -/

section BranchB

variable (k m : ℕ) {α β h L : ℝ}

lemma tailB_boundary (hL26 : 26 < L) (hmL : L ≤ m) (hh0 : 0 < h)
    (hκ_le : 64 * (m : ℝ) * L * h ≤ 1 / 500) (hkh : (k : ℝ) * L ^ 2 * h ^ 2 ≤ (128 / 32000) ^ 2)
    (hexpL : Real.exp (-L) = α * β / 20480) :
    (k : ℝ) * ((64 * (m : ℝ) * L * h) ^ (m + 1) /
      (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - 64 * (m : ℝ) * L * h))) ≤ α * β / 20480 := by
  have hL0 : 0 < L := by linarith
  have hm27 : 27 ≤ m := by
    have h1 : (26 : ℝ) < m := lt_of_lt_of_le hL26 hmL
    have h2 : (26 : ℕ) < m := by exact_mod_cast h1
    omega
  set κ := 64 * (m : ℝ) * L * h with hκdef
  have hκ0 : 0 < κ := by
    have : (0 : ℝ) < m := by linarith
    have := mul_pos (mul_pos this hL0) hh0
    rw [hκdef]; linarith
  have hden : (1 : ℝ) / 2 ≤ ((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ) := by
    have h1 := half_le_sqrt_one_sub (κ := κ) (by linarith)
    have h2 := one_le_succ_mul_betaSymZ m
    have := mul_le_mul h2 h1 (by norm_num) (by linarith)
    linarith
  have hkκ2 : (k : ℝ) * κ ^ 2 ≤ 0.065536 * ((m : ℝ) + 1) ^ 2 := by
    have e : (k : ℝ) * κ ^ 2 = 64 ^ 2 * (m : ℝ) ^ 2 * ((k : ℝ) * L ^ 2 * h ^ 2) := by
      rw [hκdef]; ring
    rw [e]
    have hm2 : (m : ℝ) ^ 2 ≤ ((m : ℝ) + 1) ^ 2 := by
      have : (0 : ℝ) ≤ m := Nat.cast_nonneg m
      nlinarith
    have h0 : (0 : ℝ) ≤ (k : ℝ) * L ^ 2 * h ^ 2 := by positivity
    calc 64 ^ 2 * (m : ℝ) ^ 2 * ((k : ℝ) * L ^ 2 * h ^ 2)
        ≤ 64 ^ 2 * ((m : ℝ) + 1) ^ 2 * (128 / 32000) ^ 2 :=
          mul_le_mul (mul_le_mul_of_nonneg_left hm2 (by norm_num)) hkh h0 (by positivity)
      _ = 0.065536 * ((m : ℝ) + 1) ^ 2 := by ring
  have hκm : κ ^ (m - 1) ≤ (1 / 500) ^ (m - 1) := pow_le_pow_left₀ hκ0.le hκ_le (m - 1)
  have hsplit : κ ^ (m + 1) = κ ^ 2 * κ ^ (m - 1) := by
    rw [← pow_add]; congr 1; omega
  have hexp_m : (1 / 3 : ℝ) ^ m ≤ Real.exp (-L) := by
    have h1 : Real.exp (-(m : ℝ)) ≤ Real.exp (-L) := Real.exp_le_exp.2 (by linarith)
    have h2 : Real.exp (-(m : ℝ)) = (Real.exp 1)⁻¹ ^ m := by
      rw [Real.exp_neg, ← Real.exp_one_pow, inv_pow]
    have h3 : (1 / 3 : ℝ) ^ m ≤ (Real.exp 1)⁻¹ ^ m := by
      have he : Real.exp 1 < 3 := by have := Real.exp_one_lt_d9; linarith
      apply pow_le_pow_left₀ (by norm_num)
      rw [one_div]
      exact inv_anti₀ (Real.exp_pos 1) he.le
    linarith
  have haux := aux_pow_le (m - 1) (by omega)
  have hm1 : ((m - 1 : ℕ) : ℝ) = (m : ℝ) - 1 := by
    rw [Nat.cast_sub (by omega)]; norm_num
  rw [hm1] at haux
  have hm2 : m - 1 + 1 = m := by omega
  rw [hm2] at haux
  rw [← hexpL]
  have hnum0 : 0 ≤ (k : ℝ) * κ ^ (m + 1) := by positivity
  calc (k : ℝ) * (κ ^ (m + 1) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ)))
      = ((k : ℝ) * κ ^ (m + 1)) / (((m : ℝ) + 1) * betaSymZ m * Real.sqrt (1 - κ)) := by ring
    _ ≤ ((k : ℝ) * κ ^ (m + 1)) / (1 / 2) := div_le_div_of_nonneg_left hnum0 (by norm_num) hden
    _ = 2 * (((k : ℝ) * κ ^ 2) * κ ^ (m - 1)) := by rw [hsplit]; ring
    _ ≤ 2 * ((0.065536 * ((m : ℝ) + 1) ^ 2) * (1 / 500) ^ (m - 1)) :=
        mul_le_mul_of_nonneg_left (mul_le_mul hkκ2 hκm (pow_nonneg hκ0.le _) (by positivity))
          (by norm_num)
    _ ≤ (1 / 3 : ℝ) ^ m := by
        rw [one_div_pow, one_div_pow]
        have h5 : (0 : ℝ) < 500 ^ (m - 1) := by positivity
        have h3 : (0 : ℝ) < 3 ^ m := by positivity
        rw [show 2 * ((0.065536 * ((m : ℝ) + 1) ^ 2) * (1 / 500 ^ (m - 1))) =
          (0.131072 * ((m : ℝ) + 1) ^ 2) / 500 ^ (m - 1) by ring]
        rw [div_le_div_iff₀ h5 h3, one_mul]
        have e : ((m : ℝ) - 1 + 2) = (m : ℝ) + 1 := by ring
        rw [e] at haux
        linarith [haux]
    _ ≤ Real.exp (-L) := hexp_m

lemma tailB_freedman (hL26 : 26 < L) (hIle : betaSymFisher m ≤ 2.4 * L) (hI0 : 0 ≤ betaSymFisher m)
    (hkh : (k : ℝ) * L ^ 2 * h ^ 2 ≤ (128 / 32000) ^ 2) (hexpL : Real.exp (-L) = α * β / 20480) :
    Real.exp (-((9 / 200 : ℝ) ^ 2 / (2 * ((k : ℝ) * (1.03 * betaSymFisher m * h ^ 2) +
      1 / (31 * L) * (9 / 200) / 3)))) ≤ α * β / 20480 := by
  have hL0 : 0 < L := by linarith
  rw [← hexpL]
  apply Real.exp_le_exp.2
  have hb' : 0 < 1 / (31 * L) * (9 / 200) / 3 :=
    div_pos (mul_pos (one_div_pos.2 (by linarith)) (by norm_num)) (by norm_num)
  have hS : 0 < 2 * ((k : ℝ) * (1.03 * betaSymFisher m * h ^ 2) + 1 / (31 * L) * (9 / 200) / 3) := by
    have : (0 : ℝ) ≤ (k : ℝ) * (1.03 * betaSymFisher m * h ^ 2) :=
      mul_nonneg (Nat.cast_nonneg k) (mul_nonneg (mul_nonneg (by norm_num) hI0) (sq_nonneg h))
    linarith
  rw [neg_le_neg_iff, le_div_iff₀ hS]
  have hLne : L ≠ 0 := hL0.ne'
  have e : L * (2 * ((k : ℝ) * (1.03 * betaSymFisher m * h ^ 2) + 1 / (31 * L) * (9 / 200) / 3)) =
      2 * 1.03 * (betaSymFisher m * ((k : ℝ) * L * h ^ 2)) + 2 * (9 / 200) / 93 := by
    field_simp
    ring
  rw [e]
  have h0 : (0 : ℝ) ≤ (k : ℝ) * L * h ^ 2 :=
    mul_nonneg (mul_nonneg (Nat.cast_nonneg k) hL0.le) (sq_nonneg h)
  have hkLh : (k : ℝ) * L * h ^ 2 * L ≤ (128 / 32000) ^ 2 := by
    have e2 : (k : ℝ) * L * h ^ 2 * L = (k : ℝ) * L ^ 2 * h ^ 2 := by ring
    rw [e2]; exact hkh
  have h1 : betaSymFisher m * ((k : ℝ) * L * h ^ 2) ≤ 2.4 * ((128 / 32000) ^ 2) :=
    calc betaSymFisher m * ((k : ℝ) * L * h ^ 2) ≤ 2.4 * L * ((k : ℝ) * L * h ^ 2) :=
          mul_le_mul_of_nonneg_right hIle h0
      _ = 2.4 * ((k : ℝ) * L * h ^ 2 * L) := by ring
      _ ≤ 2.4 * ((128 / 32000) ^ 2) := by linarith
  norm_num at h1 ⊢
  linarith

lemma s1NoiseParams_B (hα : 0 < α) (hα16 : α < 1 / 16) (hL26 : 26 < L) (hmL : L ≤ m)
    (hmL1 : (m : ℝ) < L + 1) (hh0 : 0 < h) (hh3 : h * L ^ 3 ≤ 0.008 * α)
    (hkh : (k : ℝ) * L ^ 2 * h ^ 2 ≤ (128 / 32000) ^ 2) (hexpL : Real.exp (-L) = α * β / 20480) :
    S1NoiseParams k m h L (1 / 20) (α * β / 20480 + α * β / 20480) (9 / 200) := by
  have hL0 : 0 < L := by linarith
  have hm27 : 27 ≤ m := by
    have h1 : (26 : ℝ) < m := lt_of_lt_of_le hL26 hmL
    have h2 : (26 : ℕ) < m := by exact_mod_cast h1
    omega
  have hm27r : (27 : ℝ) ≤ m := by exact_mod_cast hm27
  have hI : betaSymFisher m = (m : ℝ) * (2 * m + 1) / (m - 1) := betaSymFisher_eq m (by omega)
  have hIle : betaSymFisher m ≤ 2.4 * L := by
    rw [hI, div_le_iff₀ (by linarith)]
    nlinarith [mul_pos (by linarith : (0 : ℝ) < L - ((m : ℝ) - 1)) (by linarith : (0 : ℝ) < (m : ℝ) - 1)]
  have hI0 : 0 ≤ betaSymFisher m := by
    rw [hI]; apply div_nonneg <;> nlinarith
  have hLh : L ^ 3 * h ≤ 0.0005 := by nlinarith
  have hL2 : (676 : ℝ) ≤ L ^ 2 := by nlinarith
  have hκ_le : 64 * (m : ℝ) * L * h ≤ 1 / 500 := by
    have hLh0 : 0 ≤ L * h := (mul_pos hL0 hh0).le
    have h1 : 64 * (m : ℝ) * L * h ≤ 64 * (L + 1) * L * h := by
      have : 64 * (m : ℝ) * (L * h) ≤ 64 * (L + 1) * (L * h) := by
        apply mul_le_mul_of_nonneg_right _ hLh0; linarith
      linarith [this]
    have h2 : 64 * (L + 1) * L * h * L ^ 2 = 64 * (L + 1) * (L ^ 3 * h) := by ring
    have h2' : 64 * (L + 1) * (L ^ 3 * h) ≤ 64 * (L + 1) * 0.0005 := by
      apply mul_le_mul_of_nonneg_left hLh; linarith
    have h3 : 64 * (L + 1) * 0.0005 ≤ 1 / 500 * L ^ 2 := by nlinarith
    have h4 : 64 * (L + 1) * L * h * L ^ 2 ≤ 1 / 500 * L ^ 2 := by linarith
    have h5 : 64 * (L + 1) * L * h ≤ 1 / 500 := le_of_mul_le_mul_right h4 (pow_pos hL0 2)
    linarith
  refine ⟨by omega, hL0, hh0, ?_, ?_, by linarith, ?_, by norm_num, ?_, ?_⟩
  · -- `h ≤ 1/1000`
    have h1 : h * 676 ≤ h * L ^ 2 := mul_le_mul_of_nonneg_left hL2 hh0.le
    have h2 : h * L ^ 2 * 26 ≤ h * L ^ 2 * L :=
      mul_le_mul_of_nonneg_left hL26.le (by positivity)
    have h3 : h * L ^ 2 * L = L ^ 3 * h := by ring
    linarith
  · have := mul_le_mul hm27r hL26.le (by norm_num) (by linarith)
    linarith
  · -- `12.8 h² (2m - 1) ≤ 0.0089`
    have h1 : h * (2 * (m : ℝ) - 1) ≤ h * (2 * L + 1) := by
      apply mul_le_mul_of_nonneg_left _ hh0.le; linarith
    have hh2 : h * (2 * L + 1) ≤ 1 := by
      have e : h * (2 * L + 1) * L ^ 2 ≤ 3 * (L ^ 3 * h) := by
        have e0 : h * (2 * L + 1) * L ^ 2 = 3 * (L ^ 3 * h) - h * L ^ 2 * (L - 1) := by ring
        have e1 : 0 ≤ h * L ^ 2 * (L - 1) :=
          mul_nonneg (mul_nonneg hh0.le (sq_nonneg L)) (by linarith)
        linarith
      have : h * (2 * L + 1) * L ^ 2 ≤ 1 * L ^ 2 := by nlinarith
      exact le_of_mul_le_mul_right this (pow_pos hL0 2)
    have hh1 : h ≤ 1 / 1000 := by
      have h1 : h * 676 ≤ h * L ^ 2 := mul_le_mul_of_nonneg_left hL2 hh0.le
      have h2 : h * L ^ 2 * 26 ≤ h * L ^ 2 * L :=
        mul_le_mul_of_nonneg_left hL26.le (by positivity)
      have h3 : h * L ^ 2 * L = L ^ 3 * h := by ring
      linarith
    have e : h ^ 2 * (2 * (m : ℝ) - 1) = h * (h * (2 * (m : ℝ) - 1)) := by ring
    have : h * (h * (2 * (m : ℝ) - 1)) ≤ h * 1 :=
      mul_le_mul_of_nonneg_left (h1.trans hh2) hh0.le
    nlinarith
  · -- drift
    have hkI : (k : ℝ) * (0.67 * betaSymFisher m * h ^ 2) ≤ 0.67 * 2.4 * ((k : ℝ) * L * h ^ 2) := by
      have h0 : (0 : ℝ) ≤ k * h ^ 2 := by positivity
      have : (k : ℝ) * (0.67 * betaSymFisher m * h ^ 2) = 0.67 * (betaSymFisher m * (k * h ^ 2)) := by
        ring
      rw [this]
      have : betaSymFisher m * (k * h ^ 2) ≤ 2.4 * L * (k * h ^ 2) := mul_le_mul_of_nonneg_right hIle h0
      have e : 2.4 * L * ((k : ℝ) * h ^ 2) = 2.4 * ((k : ℝ) * L * h ^ 2) := by ring
      linarith
    have hkh' : (k : ℝ) * L * h ^ 2 * 26 ≤ (128 / 32000) ^ 2 := by
      have h1 : (k : ℝ) * L * h ^ 2 * 26 ≤ (k : ℝ) * L * h ^ 2 * L :=
        mul_le_mul_of_nonneg_left hL26.le
          (mul_nonneg (mul_nonneg (Nat.cast_nonneg k) hL0.le) (sq_nonneg h))
      have h2 : (k : ℝ) * L * h ^ 2 * L = (k : ℝ) * L ^ 2 * h ^ 2 := by ring
      linarith
    norm_num at hkI hkh' ⊢
    linarith
  · have h1 := tailB_boundary k m hL26 hmL hh0 hκ_le hkh hexpL
    have h2 := tailB_freedman k m hL26 hIle hI0 hkh hexpL
    exact add_le_add h1 h2

end BranchB

/-! ### The locked parameters -/

/-- **The numeric certificates of `I:lem:working_sample_privacy`** for the locked parameters (both
branches, every `k`). -/
theorem s1NoiseParams_locked (k : ℕ) {α β : ℝ} (hα : 0 < α) (hα16 : α < 1 / 16) (hβ : 0 < β)
    (hβ2 : β < 1 / 2) :
    S1NoiseParams k (adaBetaM α β) (s1H k α β) (adaL1 α β) adaEps1 (adaDelta1 α β) (9 / 200) := by
  have hL1339 := adaL1_gt_1339 hα hα16 hβ hβ2
  have hL0 : 0 < adaL1 α β := by linarith
  -- the sample-size lower bounds
  have hX := Nat.le_ceil
    (32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α + 16000 * adaL1 α β ^ 3 / α ^ 2)
  have hnα : 32000 * Real.sqrt k * adaChi1 α β + 16000 * adaL1 α β ^ 3 / α ≤
      (adaN1 k α β : ℝ) * α := by
    have e : (32000 * Real.sqrt (k : ℝ) * adaChi1 α β / α + 16000 * adaL1 α β ^ 3 / α ^ 2) * α =
        32000 * Real.sqrt k * adaChi1 α β + 16000 * adaL1 α β ^ 3 / α := by
      field_simp
    rw [← e]
    exact mul_le_mul_of_nonneg_right hX hα.le
  have hχ0 : 0 ≤ adaChi1 α β := by
    unfold adaChi1; split_ifs
    · exact Real.sqrt_nonneg _
    · exact hL0.le
  have hA0 : 0 ≤ 32000 * Real.sqrt k * adaChi1 α β := by positivity
  have hB : 0 < 16000 * adaL1 α β ^ 3 / α := div_pos (by have := pow_pos hL0 3; linarith) hα
  have hnαpos : 0 < (adaN1 k α β : ℝ) * α := by linarith
  have hh_eq : s1H k α β = 128 / ((adaN1 k α β : ℝ) * α) := rfl
  have hh0 : 0 < s1H k α β := by rw [hh_eq]; exact div_pos (by norm_num) hnαpos
  have hh3 : s1H k α β * adaL1 α β ^ 3 ≤ 0.008 * α := by
    rw [hh_eq, div_mul_eq_mul_div, div_le_iff₀ hnαpos]
    have h1 : 16000 * adaL1 α β ^ 3 / α ≤ (adaN1 k α β : ℝ) * α := by linarith
    have h2 : 16000 * adaL1 α β ^ 3 ≤ (adaN1 k α β : ℝ) * α * α := by
      rwa [div_le_iff₀ hα] at h1
    nlinarith
  have hkh : (k : ℝ) * adaChi1 α β ^ 2 * s1H k α β ^ 2 ≤ (128 / 32000) ^ 2 := by
    have h1 : 32000 * Real.sqrt k * adaChi1 α β ≤ (adaN1 k α β : ℝ) * α := by linarith
    have h2 : (32000 * Real.sqrt k * adaChi1 α β) ^ 2 ≤ ((adaN1 k α β : ℝ) * α) ^ 2 :=
      pow_le_pow_left₀ hA0 h1 2
    have h3 : (32000 * Real.sqrt k * adaChi1 α β) ^ 2 = 32000 ^ 2 * ((k : ℝ) * adaChi1 α β ^ 2) := by
      rw [mul_pow, mul_pow, Real.sq_sqrt (Nat.cast_nonneg k)]; ring
    rw [h3] at h2
    rw [hh_eq, div_pow]
    rw [show (k : ℝ) * adaChi1 α β ^ 2 * (128 ^ 2 / ((adaN1 k α β : ℝ) * α) ^ 2) =
      128 ^ 2 * ((k : ℝ) * adaChi1 α β ^ 2) / ((adaN1 k α β : ℝ) * α) ^ 2 by ring]
    rw [div_le_iff₀ (pow_pos hnαpos 2)]
    nlinarith
  have hexpL : Real.exp (-adaL1 α β) = α * β / 20480 := by
    rw [adaL1, Real.exp_neg, Real.exp_log (by positivity)]
    field_simp
  have heps : adaEps1 = 1 / 20 := rfl
  have hδ : adaDelta1 α β = α * β / 20480 + α * β / 20480 := by
    unfold adaDelta1; ring
  rw [heps, hδ]
  by_cases hb : α ^ 5 ≤ β
  · have hm : adaBetaM α β = 7 := by simp [adaBetaM, adaP1, hb]
    have hχL : adaChi1 α β ^ 2 = adaL1 α β := by
      unfold adaChi1; rw [if_pos hb, Real.sq_sqrt hL0.le]
    rw [hχL] at hkh
    rw [hm]
    exact s1NoiseParams_A k hα hα16 hb hL1339 hh0 hh3 hkh hexpL
  · have hb' : β < α ^ 5 := lt_of_not_ge hb
    have hL26 := adaL1_gt_26 hα hα16 hβ hb'
    have hm : adaBetaM α β = ⌈adaL1 α β⌉₊ := by simp [adaBetaM, adaP1, hb]
    have hχL : adaChi1 α β = adaL1 α β := by
      unfold adaChi1; rw [if_neg hb]
    rw [hχL] at hkh
    rw [hm]
    exact s1NoiseParams_B k ⌈adaL1 α β⌉₊ hα hα16 hL26 (Nat.le_ceil _) (Nat.ceil_lt_add_one hL0.le)
      hh0 hh3 hkh hexpL

end F2e2e.A
