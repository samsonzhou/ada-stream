import F2e2e.A.AnchorGhostDefs

/-!
# The ghost monitor of Lemma `I:lem:anchor_ghost_monitor`: the self-bounding argument

Owner: A-ACC. Paper: `parts/partI.tex` L1054-1107.

`ghost_monitor_aux` is the generic Lemma `I:lem:anchor_ghost_monitor` (statement identical to `ghost_monitor` in
`F2e2e/A/Anchor.lean`). The proof follows the paper on the probability space of `(S, X', h, J)`:
`S ∼ D^n`, `X' ∼ D` fresh, `(h, J) ∼ ghostK S` (`S ↦ h` then the ghost exponential mechanism), i.e. the measure
`P = (D^n ⊗ D) ⊗ₘ ghostK` (`ghostP`), with `t = t_L = 4 ln(6k/δ)/(nε) ≤ ε` and null score `ν = r_anc - t`
(`r_anc = 4ε`):
* (utility, `prob_gc_le`) `G^c = {u_J ≤ max_c u_c - t}` has probability `≤ |C| e^{-nεt/4} ≤ δ/2`;
* (`bad_subset`) `{∃ i, |θ_i - μ_i| > r_anc} ⊆ {J ≠ m₀} ∪ G^c`;
* (`lower_bound_pt`) `(1/n) ∑_ℓ ψ(h, J, X_ℓ) ≥ 2ε·1_{J ≠ m₀} - (1+2ε)·1_{G^c}` (on `G ∩ {J ≠ m₀}`, `u_J > r_anc - 2t ≥ 2ε`);
* (transfer, `DP.dpTransfer_fwd/_bwd` for `ψ_±`, the `(ε, δ/2)`-DP kernel `ghostK`) and centering
  `E ψ(h, J, X') = 0` with `|ψ| ≤ 1_{J ≠ m₀}`: `E[(1/n) ∑_ℓ ψ(h, J, X_ℓ)] ≤ sinh(ε) Pr[J ≠ m₀] + δ`;
* combining, `(2ε - sinh ε) Pr[J ≠ m₀] ≤ δ + (1+2ε)δ/2`, hence `Pr[bad] ≤ Pr[J ≠ m₀] + δ/2 < 3δ/ε ≤ 100δ/ε`.
-/

namespace F2e2e.A.Ghost

open MeasureTheory ProbabilityTheory

/-- A bounded measurable real function is integrable for a finite measure. -/
theorem integrable_of_abs_le {Ω : Type*} [MeasurableSpace Ω] {P : Measure Ω} [IsFiniteMeasure P]
    {F : Ω → ℝ} (hF : Measurable F) {B : ℝ} (hB : ∀ z, |F z| ≤ B) : Integrable F P :=
  Integrable.mono' (integrable_const B) hF.aestronglyMeasurable
    (Filter.Eventually.of_forall fun z => by rw [Real.norm_eq_abs]; exact hB z)

/-- `e^ε - e^{-ε} ≤ 2ε + ε²` for `0 ≤ ε ≤ 1`. -/
theorem exp_sub_exp_neg_le {ε : ℝ} (h0 : 0 ≤ ε) (h1 : ε ≤ 1) :
    Real.exp ε - Real.exp (-ε) ≤ 2 * ε + ε ^ 2 := by
  have ha := Real.abs_exp_sub_one_sub_id_le (x := ε) (by rw [abs_of_nonneg h0]; exact h1)
  have hb := Real.add_one_le_exp (-ε)
  have hc := (abs_le.mp ha).2
  linarith

/-- `a = a⁺ - a⁻` with `a⁺ = max a 0`, `a⁻ = max (-a) 0`. -/
theorem eq_max_sub_max (a : ℝ) : a = max a 0 - max (-a) 0 := by
  rcases le_total 0 a with h | h
  · rw [max_eq_left h, max_eq_right (by linarith)]
    ring
  · rw [max_eq_right h, max_eq_left (by linarith)]
    ring

/-- `a⁺ + a⁻ = |a|`. -/
theorem max_add_max_neg (a : ℝ) : max a 0 + max (-a) 0 = |a| := by
  rcases le_total 0 a with h | h
  · rw [max_eq_left h, max_eq_right (by linarith), abs_of_nonneg h]
    ring
  · rw [max_eq_right h, max_eq_left (by linarith), abs_of_nonpos h]
    ring

section Main

variable {X H : Type*} [MeasurableSpace X] [MeasurableSpace H]

/-- The probability space of the ghost argument: `(S, X') ∼ D^n ⊗ D`, `(h, J) ∼ ghostK S`. -/
noncomputable def ghostP (D : Measure X) {n k : ℕ} (hk : 0 < k) (q : H → Fin k → X → ℝ)
    (κ : Kernel (Fin n → X) H) [SFinite D] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2))
    (ε ν : ℝ) : Measure (((Fin n → X) × X) × (H × Fin (2 * k + 1))) :=
  ((Measure.pi fun _ : Fin n => D).prod D) ⊗ₘ
    ((ghostK hk D q κ hqm ε ν).comap Prod.fst measurable_fst)

instance (D : Measure X) [IsProbabilityMeasure D] {n k : ℕ} (hk : 0 < k) (q : H → Fin k → X → ℝ)
    (κ : Kernel (Fin n → X) H) [IsMarkovKernel κ]
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (ε ν : ℝ) :
    IsProbabilityMeasure (ghostP D hk q κ hqm ε ν) := by
  unfold ghostP
  infer_instance

variable (D : Measure X) [IsProbabilityMeasure D] {n k : ℕ} (hk : 0 < k) (q : H → Fin k → X → ℝ)
  (κ : Kernel (Fin n → X) H) [IsMarkovKernel κ] (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2))
  (ε ν : ℝ)

/-- Integrals against `ghostP` as iterated integrals (`S`, `X'` outside, `(h, J) ∼ ghostK S` inside). -/
theorem integral_ghostP {F : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) → ℝ} (hF : Measurable F) {B : ℝ}
    (hB : ∀ z, |F z| ≤ B) :
    ∫ z, F z ∂(ghostP D hk q κ hqm ε ν) =
      ∫ p, ∫ y, F (p, y) ∂(ghostK hk D q κ hqm ε ν p.1) ∂((Measure.pi fun _ : Fin n => D).prod D) := by
  unfold ghostP
  rw [Measure.integral_compProd (integrable_of_abs_le hF hB)]
  rfl

/-- The maximal score `M(S, h) = max_c u_c(S, h)`. -/
noncomputable def maxScore (S : Fin n → X) (h : H) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (score hk D q ν S h)

include hqm in
theorem measurable_score_pair :
    Measurable (fun r : ((Fin n → X) × H) × Fin (2 * k + 1) => score hk D q ν r.1.1 r.1.2 r.2) :=
  measurable_from_prod_countable_left fun c => measurable_score hk D q hqm ν c

include hqm in
theorem measurable_maxScore :
    Measurable (fun p : (Fin n → X) × H => maxScore D hk q ν p.1 p.2) := by
  have h := Finset.measurable_sup' (Finset.univ_nonempty (α := Fin (2 * k + 1)))
    (f := fun c (p : (Fin n → X) × H) => score hk D q ν p.1 p.2 c)
    (fun c _ => measurable_score hk D q hqm ν c)
  convert h using 1
  funext p
  rw [Finset.sup'_apply]
  rfl

/-- The event `{J ≠ m₀}`. -/
def actSet : Set (((Fin n → X) × X) × (H × Fin (2 * k + 1))) := {z | z.2.2 ≠ nullC k}

/-- The event `G^c = {u_J ≤ max_c u_c - t}`. -/
def gcSet (t : ℝ) : Set (((Fin n → X) × X) × (H × Fin (2 * k + 1))) :=
  {z | score hk D q ν z.1.1 z.2.1 z.2.2 ≤ maxScore D hk q ν z.1.1 z.2.1 - t}

omit [IsProbabilityMeasure D] in
/-- The bad event `{∃ i, |θ_i(S, h) - μ_i(h)| > r}`. -/
def badSet (r : ℝ) : Set ((Fin n → X) × H) :=
  {p | ∃ i : Fin k, r < |thetaQ q p.1 p.2 i - muQ D q p.2 i|}

theorem measurableSet_actSet : MeasurableSet (actSet (X := X) (H := H) (n := n) (k := k)) :=
  (measurable_snd.comp measurable_snd) (measurableSet_singleton (nullC k)).compl

include hqm in
theorem measurableSet_gcSet (t : ℝ) : MeasurableSet (gcSet D hk q ν t (n := n)) := by
  have h1 : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      score hk D q ν z.1.1 z.2.1 z.2.2) :=
    (measurable_score_pair D hk q hqm ν).comp
      (((measurable_fst.comp measurable_fst).prodMk (measurable_fst.comp measurable_snd)).prodMk
        (measurable_snd.comp measurable_snd))
  have h2 : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      maxScore D hk q ν z.1.1 z.2.1 - t) :=
    ((measurable_maxScore D hk q hqm ν).comp
      ((measurable_fst.comp measurable_fst).prodMk (measurable_fst.comp measurable_snd))).sub_const t
  exact measurableSet_le h1 h2

include hqm in
theorem measurableSet_badSet (r : ℝ) : MeasurableSet (badSet D q r (n := n)) := by
  have e : badSet D q r (n := n) =
      ⋃ i : Fin k, {p | r < |thetaQ q p.1 p.2 i - muQ D q p.2 i|} := by
    ext p
    simp [badSet]
  rw [e]
  refine MeasurableSet.iUnion fun i => measurableSet_lt measurable_const ?_
  exact ((measurable_thetaQ q hqm i).sub ((measurable_muQ D q hqm i).comp measurable_snd)).abs

/-! ### The utility of the ghost exponential mechanism -/

include hqm in
/-- `Pr[G^c] ≤ |C| exp(-(ε/2) t/(2/n))` (`DP.expMech_utility_max`, for every `(S, h)`). -/
theorem prob_gc_le (hn : 0 < n) (hε : 0 < ε) (t : ℝ) :
    ghostP D hk q κ hqm ε ν (gcSet D hk q ν t) ≤
      ENNReal.ofReal (Fintype.card (Fin (2 * k + 1)) *
        Real.exp (-(ε / 2 * t) / (2 * (1 / (n : ℝ))))) := by
  have hn' : (0 : ℝ) < 1 / n := by
    have : (0 : ℝ) < n := by exact_mod_cast hn
    positivity
  have hmeas := measurableSet_gcSet D hk q hqm ν t (n := n)
  unfold ghostP
  rw [Measure.compProd_apply hmeas]
  calc ∫⁻ p, ((ghostK hk D q κ hqm ε ν).comap Prod.fst measurable_fst) p (Prod.mk p ⁻¹' gcSet D hk q ν t)
        ∂((Measure.pi fun _ : Fin n => D).prod D)
      ≤ ∫⁻ _p, ENNReal.ofReal (Fintype.card (Fin (2 * k + 1)) *
          Real.exp (-(ε / 2 * t) / (2 * (1 / (n : ℝ))))) ∂((Measure.pi fun _ : Fin n => D).prod D) := by
        refine lintegral_mono fun p => ?_
        have hs : MeasurableSet (Prod.mk p ⁻¹' gcSet D hk q ν t) := measurable_prodMk_left hmeas
        show (κ ⊗ₖ emK hk D q hqm ε ν) p.1 (Prod.mk p ⁻¹' gcSet D hk q ν t) ≤ _
        rw [Kernel.compProd_apply hs]
        calc ∫⁻ h, emK hk D q hqm ε ν (p.1, h) {c | (h, c) ∈ Prod.mk p ⁻¹' gcSet D hk q ν t} ∂κ p.1
            ≤ ∫⁻ _h, ENNReal.ofReal (Fintype.card (Fin (2 * k + 1)) *
                Real.exp (-(ε / 2 * t) / (2 * (1 / (n : ℝ))))) ∂κ p.1 := by
              refine lintegral_mono fun h => ?_
              rw [emK_apply]
              exact DP.expMech_utility_max (by positivity) hn' (score hk D q ν p.1 h) t
          _ = _ := by rw [lintegral_const, measure_univ, mul_one]
    _ = _ := by rw [lintegral_const, measure_univ, mul_one]

/-! ### Deterministic consequences on `G` -/

omit [MeasurableSpace H] [IsProbabilityMeasure D] in
/-- On `E_bad`, a null selection must lie in `G^c`: `E_bad ⊆ {J ≠ m₀} ∪ G^c`. -/
theorem bad_subset {t : ℝ} (hν : ν = 4 * ε - t) :
    {z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) | (z.1.1, z.2.1) ∈ badSet D q (4 * ε)} ⊆
      actSet ∪ gcSet D hk q ν t := by
  intro z hz
  obtain ⟨i, hi⟩ := hz
  have hi' : 4 * ε < |thetaQ q z.1.1 z.2.1 i - muQ D q z.2.1 i| := hi
  by_cases hnull : z.2.2 = nullC k
  · right
    show score hk D q ν z.1.1 z.2.1 z.2.2 ≤ maxScore D hk q ν z.1.1 z.2.1 - t
    obtain ⟨c, hc, hci, hcs⟩ := exists_cand hk i (thetaQ q z.1.1 z.2.1 i - muQ D q z.2.1 i)
    have h1 : score hk D q ν z.1.1 z.2.1 c = |thetaQ q z.1.1 z.2.1 i - muQ D q z.2.1 i| := by
      unfold score
      rw [if_neg hc, hci, hcs]
    have h2 : score hk D q ν z.1.1 z.2.1 c ≤ maxScore D hk q ν z.1.1 z.2.1 :=
      Finset.le_sup' (score hk D q ν z.1.1 z.2.1) (Finset.mem_univ c)
    have h3 : score hk D q ν z.1.1 z.2.1 z.2.2 = ν := by
      unfold score
      rw [if_pos hnull]
    rw [h3]
    linarith
  · left
    exact hnull

omit [MeasurableSpace H] in
/-- The self-bounding lower bound, pointwise:
`(1/n) ∑_ℓ ψ(h, J, X_ℓ) ≥ 2ε·1_{J ≠ m₀} - (1+2ε)·1_{G^c}` (`I:eq:ghost_selfbound_lb`). -/
theorem lower_bound_pt (hn : 0 < n) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) {t : ℝ}
    (htε : t ≤ ε) (hν : ν = 4 * ε - t) (hε : 0 < ε) (z : ((Fin n → X) × X) × (H × Fin (2 * k + 1))) :
    2 * ε * (actSet (X := X) (H := H) (n := n) (k := k)).indicator 1 z -
        (1 + 2 * ε) * (gcSet D hk q ν t).indicator 1 z ≤
      (∑ ℓ, psi hk D q z.2 (z.1.1 ℓ)) / n := by
  obtain ⟨⟨S, x'⟩, ⟨h, c⟩⟩ := z
  have hgc0 : (0 : ℝ) ≤ (gcSet D hk q ν t).indicator 1 ((S, x'), (h, c)) :=
    Set.indicator_nonneg (fun _ _ => zero_le_one) _
  by_cases hc : c = nullC k
  · subst hc
    have hna : ((S, x'), (h, nullC k)) ∉ (actSet (X := X) (H := H) (n := n) (k := k)) :=
      fun hm => hm rfl
    rw [Set.indicator_of_notMem hna]
    show 2 * ε * 0 - (1 + 2 * ε) * (gcSet D hk q ν t).indicator 1 ((S, x'), (h, nullC k)) ≤
      (∑ ℓ, psi hk D q (h, nullC k) (S ℓ)) / n
    rw [avg_psi_nullC]
    have : 0 ≤ (1 + 2 * ε) * (gcSet D hk q ν t).indicator 1 ((S, x'), (h, nullC k)) :=
      mul_nonneg (by linarith) hgc0
    linarith
  · have ha : ((S, x'), (h, c)) ∈ (actSet (X := X) (H := H) (n := n) (k := k)) := hc
    rw [Set.indicator_of_mem ha, Pi.one_apply, mul_one]
    show 2 * ε - (1 + 2 * ε) * (gcSet D hk q ν t).indicator 1 ((S, x'), (h, c)) ≤
      (∑ ℓ, psi hk D q (h, c) (S ℓ)) / n
    rw [avg_psi hk D q hn ν S h hc]
    by_cases hg : ((S, x'), (h, c)) ∈ gcSet D hk q ν t
    · rw [Set.indicator_of_mem hg, Pi.one_apply, mul_one]
      have hlow : -1 ≤ score hk D q ν S h c := by
        unfold score
        rw [if_neg hc]
        have h1 := abs_candS_le k c
        have h2 := thetaQ_mem q hn hq01 S h (candI hk c)
        have h3 := muQ_mem D q hq01 h (candI hk c)
        have h4 : |thetaQ q S h (candI hk c) - muQ D q h (candI hk c)| ≤ 1 := by
          rw [abs_le]
          constructor <;> linarith [h2.1, h2.2, h3.1, h3.2]
        have h5 : |candS k c * (thetaQ q S h (candI hk c) - muQ D q h (candI hk c))| ≤ 1 := by
          rw [abs_mul]
          calc |candS k c| * |thetaQ q S h (candI hk c) - muQ D q h (candI hk c)| ≤ 1 * 1 :=
                mul_le_mul h1 h4 (abs_nonneg _) zero_le_one
            _ = 1 := one_mul 1
        have := neg_abs_le (candS k c * (thetaQ q S h (candI hk c) - muQ D q h (candI hk c)))
        linarith
      linarith
    · rw [Set.indicator_of_notMem hg, mul_zero, sub_zero]
      have hg' : maxScore D hk q ν S h - t < score hk D q ν S h c := lt_of_not_ge hg
      have hM : score hk D q ν S h (nullC k) ≤ maxScore D hk q ν S h :=
        Finset.le_sup' (score hk D q ν S h) (Finset.mem_univ (nullC k))
      have hnu : score hk D q ν S h (nullC k) = ν := by
        unfold score
        rw [if_pos rfl]
      rw [hnu] at hM
      linarith

/-! ### Transfer and centering -/

include hqm in
theorem measurable_psi_sample (ℓ : Fin n) :
    Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) => psi hk D q z.2 (z.1.1 ℓ)) :=
  (measurable_psi hk D q hqm).comp
    (measurable_snd.prodMk ((measurable_pi_apply ℓ).comp (measurable_fst.comp measurable_fst)))

include hqm in
theorem measurable_psi_fresh :
    Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) => psi hk D q z.2 z.1.2) :=
  (measurable_psi hk D q hqm).comp (measurable_snd.prodMk (measurable_snd.comp measurable_fst))

omit [MeasurableSpace H] in
theorem abs_max_psi_le (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (y : H × Fin (2 * k + 1)) (x : X) :
    |max (psi hk D q y x) 0| ≤ 1 := by
  rw [abs_of_nonneg (le_max_right _ _)]
  exact max_le ((le_abs_self _).trans (abs_psi_le hk D q hq01 y x)) zero_le_one

omit [MeasurableSpace H] in
theorem abs_max_neg_psi_le (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (y : H × Fin (2 * k + 1))
    (x : X) : |max (-psi hk D q y x) 0| ≤ 1 := by
  rw [abs_of_nonneg (le_max_right _ _)]
  exact max_le ((neg_le_abs _).trans (abs_psi_le hk D q hq01 y x)) zero_le_one

/-! Integrability on `ghostP` (stated with typed binders: an untyped `(F := fun z => …)` here makes the
elaborator time out). -/

theorem integrable_pos_fresh (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) :
    Integrable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (psi hk D q z.2 z.1.2) 0) (ghostP D hk q κ hqm ε ν) := by
  have hm : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (psi hk D q z.2 z.1.2) 0) :=
    (measurable_psi_fresh D hk q hqm).max measurable_const
  exact integrable_of_abs_le hm (fun z => abs_max_psi_le D hk q hq01 z.2 z.1.2)

theorem integrable_neg_fresh (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) :
    Integrable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (-psi hk D q z.2 z.1.2) 0) (ghostP D hk q κ hqm ε ν) := by
  have hm : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (-psi hk D q z.2 z.1.2) 0) :=
    (measurable_psi_fresh D hk q hqm).neg.max measurable_const
  exact integrable_of_abs_le hm (fun z => abs_max_neg_psi_le D hk q hq01 z.2 z.1.2)

theorem integrable_psi_sample (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (ℓ : Fin n) :
    Integrable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      psi hk D q z.2 (z.1.1 ℓ)) (ghostP D hk q κ hqm ε ν) := by
  have hm : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      psi hk D q z.2 (z.1.1 ℓ)) :=
    measurable_psi_sample D hk q hqm ℓ
  exact integrable_of_abs_le hm (fun z => abs_psi_le hk D q hq01 z.2 (z.1.1 ℓ))

theorem integrable_pos_sample (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (ℓ : Fin n) :
    Integrable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (psi hk D q z.2 (z.1.1 ℓ)) 0) (ghostP D hk q κ hqm ε ν) := by
  have hm : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (psi hk D q z.2 (z.1.1 ℓ)) 0) :=
    (measurable_psi_sample D hk q hqm ℓ).max measurable_const
  exact integrable_of_abs_le hm (fun z => abs_max_psi_le D hk q hq01 z.2 (z.1.1 ℓ))

theorem integrable_neg_sample (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (ℓ : Fin n) :
    Integrable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (-psi hk D q z.2 (z.1.1 ℓ)) 0) (ghostP D hk q κ hqm ε ν) := by
  have hm : Measurable (fun z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) =>
      max (-psi hk D q z.2 (z.1.1 ℓ)) 0) :=
    (measurable_psi_sample D hk q hqm ℓ).neg.max measurable_const
  exact integrable_of_abs_le hm (fun z => abs_max_neg_psi_le D hk q hq01 z.2 (z.1.1 ℓ))

/-- Transfer for `ψ_+`, forward (T9): `E ψ_+(h, J, X_ℓ) ≤ e^ε E ψ_+(h, J, X') + δ/2`. -/
theorem transfer_pos (hn : 0 < n) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (hε : 0 < ε)
    {δ : ℝ} (hδ : 0 ≤ δ) (hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) (ℓ : Fin n) :
    ∫ z, max (psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν) ≤
      Real.exp ε * ∫ z, max (psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) + δ / 2 := by
  have hb : ∀ y x, max (psi hk D q y x) 0 ∈ Set.Icc (0 : ℝ) 1 := fun y x =>
    ⟨le_max_right _ _, max_le ((le_abs_self _).trans (abs_psi_le hk D q hq01 y x)) zero_le_one⟩
  have hfm : Measurable fun r : (H × Fin (2 * k + 1)) × X => max (psi hk D q r.1 r.2) 0 :=
    (measurable_psi hk D q hqm).max measurable_const
  have hT := DP.dpTransfer_fwd D (ghostK hk D q κ hqm ε ν) (by linarith)
    (ghostK_isDP hk D q hn κ hqm hq01 hε ν hDP) ℓ (fun y x => max (psi hk D q y x) 0) hfm hb
  rw [integral_ghostP D hk q κ hqm ε ν ((measurable_psi_sample D hk q hqm ℓ).max measurable_const)
      (fun z => abs_max_psi_le D hk q hq01 _ _),
    integral_ghostP D hk q κ hqm ε ν ((measurable_psi_fresh D hk q hqm).max measurable_const)
      (fun z => abs_max_psi_le D hk q hq01 _ _)]
  exact hT

/-- Transfer for `ψ_-`, backward (T9): `E ψ_-(h, J, X') ≤ e^ε E ψ_-(h, J, X_ℓ) + δ/2`. -/
theorem transfer_neg (hn : 0 < n) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) (hε : 0 < ε)
    {δ : ℝ} (hδ : 0 ≤ δ) (hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) (ℓ : Fin n) :
    ∫ z, max (-psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) ≤
      Real.exp ε * ∫ z, max (-psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν) + δ / 2 := by
  have hb : ∀ y x, max (-psi hk D q y x) 0 ∈ Set.Icc (0 : ℝ) 1 := fun y x =>
    ⟨le_max_right _ _, max_le ((neg_le_abs _).trans (abs_psi_le hk D q hq01 y x)) zero_le_one⟩
  have hfm : Measurable fun r : (H × Fin (2 * k + 1)) × X => max (-psi hk D q r.1 r.2) 0 :=
    (measurable_psi hk D q hqm).neg.max measurable_const
  have hT := DP.dpTransfer_bwd D (ghostK hk D q κ hqm ε ν) (by linarith)
    (ghostK_isDP hk D q hn κ hqm hq01 hε ν hDP) ℓ (fun y x => max (-psi hk D q y x) 0) hfm hb
  rw [integral_ghostP D hk q κ hqm ε ν (F := fun z => max (-psi hk D q z.2 z.1.2) 0)
      ((measurable_psi_fresh D hk q hqm).neg.max measurable_const)
      (fun z => abs_max_neg_psi_le D hk q hq01 _ _),
    integral_ghostP D hk q κ hqm ε ν (F := fun z => max (-psi hk D q z.2 (z.1.1 ℓ)) 0)
      ((measurable_psi_sample D hk q hqm ℓ).neg.max measurable_const)
      (fun z => abs_max_neg_psi_le D hk q hq01 _ _)]
  exact hT

/-- Centering (L1084-1086): `E ψ(h, J, X') = 0` for the fresh draw `X' ∼ D`. -/
theorem integral_psi_fresh (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) :
    ∫ z, psi hk D q z.2 z.1.2 ∂(ghostP D hk q κ hqm ε ν) = 0 := by
  rw [integral_ghostP D hk q κ hqm ε ν (measurable_psi_fresh D hk q hqm)
    (fun z => abs_psi_le hk D q hq01 _ _)]
  have hG : Measurable fun p : (Fin n → X) × X =>
      ∫ y, psi hk D q y p.2 ∂(ghostK hk D q κ hqm ε ν p.1) :=
    (StronglyMeasurable.integral_kernel_prod_right'
      (κ := (ghostK hk D q κ hqm ε ν).comap Prod.fst measurable_fst)
      (f := fun r : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) => psi hk D q r.2 r.1.2)
      (measurable_psi_fresh D hk q hqm).stronglyMeasurable).measurable
  have hGb : ∀ p : (Fin n → X) × X, |∫ y, psi hk D q y p.2 ∂(ghostK hk D q κ hqm ε ν p.1)| ≤ 1 := by
    intro p
    rw [← Real.norm_eq_abs]
    calc ‖∫ y, psi hk D q y p.2 ∂(ghostK hk D q κ hqm ε ν p.1)‖
        ≤ 1 * ((ghostK hk D q κ hqm ε ν p.1) Set.univ).toReal :=
          norm_integral_le_of_norm_le_const (Filter.Eventually.of_forall fun y => by
            rw [Real.norm_eq_abs]
            exact abs_psi_le hk D q hq01 y p.2)
      _ = 1 := by rw [measure_univ, ENNReal.toReal_one, mul_one]
  rw [integral_prod _ (integrable_of_abs_le hG hGb)]
  refine integral_eq_zero_of_ae (Filter.Eventually.of_forall fun S => ?_)
  show ∫ x', ∫ y, psi hk D q y x' ∂(ghostK hk D q κ hqm ε ν S) ∂D = 0
  have hsw : Measurable (Function.uncurry fun (x' : X) (y : H × Fin (2 * k + 1)) => psi hk D q y x') :=
    (measurable_psi hk D q hqm).comp (measurable_snd.prodMk measurable_fst)
  rw [integral_integral_swap (integrable_of_abs_le hsw (fun r => abs_psi_le hk D q hq01 _ _))]
  simp only [integral_psi hk D q hq01 hqm, integral_zero]

/-- The marginal of `ghostP` on `(S, h)` is `D^n ⊗ₘ κ`. -/
theorem compProd_eq_ghostP {B : Set ((Fin n → X) × H)} (hB : MeasurableSet B) :
    ((Measure.pi fun _ : Fin n => D) ⊗ₘ κ) B =
      ghostP D hk q κ hqm ε ν {z | (z.1.1, z.2.1) ∈ B} := by
  have hmeasZ : MeasurableSet
      {z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) | (z.1.1, z.2.1) ∈ B} :=
    ((measurable_fst.comp measurable_fst).prodMk (measurable_fst.comp measurable_snd)) hB
  have hslice : ∀ p : (Fin n → X) × X,
      ((ghostK hk D q κ hqm ε ν).comap Prod.fst measurable_fst :
          Kernel ((Fin n → X) × X) (H × Fin (2 * k + 1))) p
          (Prod.mk p ⁻¹' {z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) | (z.1.1, z.2.1) ∈ B}) =
        κ p.1 (Prod.mk p.1 ⁻¹' B) := by
    intro p
    have hs : MeasurableSet (Prod.mk p.1 ⁻¹' B) := measurable_prodMk_left hB
    have e : Prod.mk p ⁻¹' {z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) | (z.1.1, z.2.1) ∈ B} =
        (Prod.mk p.1 ⁻¹' B) ×ˢ (Set.univ : Set (Fin (2 * k + 1))) := by
      ext y
      simp
    rw [e]
    show (κ ⊗ₖ emK hk D q hqm ε ν) p.1 ((Prod.mk p.1 ⁻¹' B) ×ˢ Set.univ) = _
    rw [Kernel.compProd_apply_prod hs MeasurableSet.univ]
    simp only [measure_univ, setLIntegral_const, one_mul]
  have hc : ∫⁻ p, ((ghostK hk D q κ hqm ε ν).comap Prod.fst measurable_fst :
          Kernel ((Fin n → X) × X) (H × Fin (2 * k + 1))) p
          (Prod.mk p ⁻¹' {z : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) | (z.1.1, z.2.1) ∈ B})
          ∂((Measure.pi fun _ : Fin n => D).prod D) =
        ∫⁻ p, κ p.1 (Prod.mk p.1 ⁻¹' B) ∂((Measure.pi fun _ : Fin n => D).prod D) :=
    lintegral_congr hslice
  unfold ghostP
  have hmeas : Measurable fun p : (Fin n → X) × X => κ p.1 (Prod.mk p.1 ⁻¹' B) :=
    (Kernel.measurable_kernel_prodMk_left hB).comp measurable_fst
  rw [Measure.compProd_apply hB, Measure.compProd_apply hmeasZ, hc, lintegral_prod _ hmeas.aemeasurable]
  simp only [lintegral_const, measure_univ, mul_one]

/-! ### The four estimates on `ghostP` -/

/-- Centering in the form `E ψ_+(h, J, X') = E ψ_-(h, J, X')`. -/
theorem ghost_center (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) :
    ∫ z, max (psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) =
      ∫ z, max (-psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) := by
  have hIp := integrable_pos_fresh D hk q κ hqm ε ν hq01
  have hIm := integrable_neg_fresh D hk q κ hqm ε ν hq01
  have h := integral_psi_fresh D hk q κ hqm ε ν hq01
  have e : ∫ z, psi hk D q z.2 z.1.2 ∂(ghostP D hk q κ hqm ε ν) =
      ∫ z, max (psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) -
        ∫ z, max (-psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) := by
    rw [← integral_sub hIp hIm]
    refine integral_congr_ae (Filter.Eventually.of_forall fun z => ?_)
    exact eq_max_sub_max _
  rw [e] at h
  exact sub_eq_zero.mp h

omit [MeasurableSpace H] in
/-- Pointwise: `ψ_+ + ψ_- = |ψ| ≤ 1_{J ≠ m₀}`. -/
theorem max_add_max_neg_psi_le (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (z : ((Fin n → X) × X) × (H × Fin (2 * k + 1))) :
    max (psi hk D q z.2 z.1.2) 0 + max (-psi hk D q z.2 z.1.2) 0 ≤
      (actSet (X := X) (H := H) (n := n) (k := k)).indicator 1 z := by
  rw [max_add_max_neg]
  have hz := abs_psi_le_indicator hk D q hq01 z.2 z.1.2
  by_cases hc : z.2.2 = nullC k
  · rw [if_pos hc] at hz
    have h0 : |psi hk D q z.2 z.1.2| = 0 := le_antisymm hz (abs_nonneg _)
    rw [h0]
    exact Set.indicator_nonneg (fun _ _ => zero_le_one) _
  · rw [if_neg hc] at hz
    rw [Set.indicator_of_mem (show z ∈ actSet (X := X) (H := H) from hc), Pi.one_apply]
    exact hz

/-- `E ψ_+(h, J, X') + E ψ_-(h, J, X') = E|ψ(h, J, X')| ≤ Pr[J ≠ m₀]`. -/
theorem ghost_abs (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) :
    ∫ z, max (psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) +
        ∫ z, max (-psi hk D q z.2 z.1.2) 0 ∂(ghostP D hk q κ hqm ε ν) ≤
      (ghostP D hk q κ hqm ε ν).real (actSet (X := X) (H := H) (n := n) (k := k)) := by
  have hIp := integrable_pos_fresh D hk q κ hqm ε ν hq01
  have hIm := integrable_neg_fresh D hk q κ hqm ε ν hq01
  have hI1 : Integrable ((actSet (X := X) (H := H) (n := n) (k := k)).indicator
      (1 : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) → ℝ)) (ghostP D hk q κ hqm ε ν) :=
    (integrable_const (1 : ℝ)).indicator (measurableSet_actSet (X := X) (H := H))
  rw [← integral_add hIp hIm, ← integral_indicator_one (measurableSet_actSet (X := X) (H := H))]
  exact integral_mono (hIp.add hIm) hI1 (fun z => max_add_max_neg_psi_le D hk q hq01 z)

/-- The integrated self-bounding lower bound (`I:eq:ghost_selfbound_lb`):
`2ε Pr[J ≠ m₀] - (1+2ε) Pr[G^c] ≤ (1/n) ∑_ℓ (E ψ_+(h, J, X_ℓ) - E ψ_-(h, J, X_ℓ))`. -/
theorem ghost_lower (hn : 0 < n) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1) {t : ℝ} (htε : t ≤ ε)
    (hν : ν = 4 * ε - t) (hε : 0 < ε) :
    2 * ε * (ghostP D hk q κ hqm ε ν).real (actSet (X := X) (H := H) (n := n) (k := k)) -
        (1 + 2 * ε) * (ghostP D hk q κ hqm ε ν).real (gcSet D hk q ν t) ≤
      (∑ ℓ, (∫ z, max (psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν) -
        ∫ z, max (-psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν))) / n := by
  have hlow := lower_bound_pt D hk q ε ν hn hq01 htε hν hε
  have hIact : Integrable ((actSet (X := X) (H := H) (n := n) (k := k)).indicator
      (1 : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) → ℝ)) (ghostP D hk q κ hqm ε ν) :=
    (integrable_const (1 : ℝ)).indicator (measurableSet_actSet (X := X) (H := H))
  have hIgc : Integrable ((gcSet D hk q ν t).indicator
      (1 : ((Fin n → X) × X) × (H × Fin (2 * k + 1)) → ℝ)) (ghostP D hk q κ hqm ε ν) :=
    (integrable_const (1 : ℝ)).indicator (measurableSet_gcSet D hk q hqm ν t)
  have hIs := integrable_psi_sample D hk q κ hqm ε ν hq01
  have hIsp := integrable_pos_sample D hk q κ hqm ε ν hq01
  have hIsm := integrable_neg_sample D hk q κ hqm ε ν hq01
  have e1 : ∫ z, (2 * ε * (actSet (X := X) (H := H) (n := n) (k := k)).indicator 1 z -
      (1 + 2 * ε) * (gcSet D hk q ν t).indicator 1 z) ∂(ghostP D hk q κ hqm ε ν) =
      2 * ε * (ghostP D hk q κ hqm ε ν).real (actSet (X := X) (H := H) (n := n) (k := k)) -
        (1 + 2 * ε) * (ghostP D hk q κ hqm ε ν).real (gcSet D hk q ν t) := by
    rw [integral_sub (hIact.const_mul _) (hIgc.const_mul _), integral_const_mul, integral_const_mul,
      integral_indicator_one (measurableSet_actSet (X := X) (H := H)),
      integral_indicator_one (measurableSet_gcSet D hk q hqm ν t)]
  have e2 : ∫ z, (∑ ℓ, psi hk D q z.2 (z.1.1 ℓ)) / n ∂(ghostP D hk q κ hqm ε ν) =
      (∑ ℓ, (∫ z, max (psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν) -
        ∫ z, max (-psi hk D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk q κ hqm ε ν))) / n := by
    rw [integral_div, integral_finsetSum _ (fun ℓ _ => hIs ℓ)]
    congr 1
    refine Finset.sum_congr rfl fun ℓ _ => ?_
    rw [← integral_sub (hIsp ℓ) (hIsm ℓ)]
    refine integral_congr_ae (Filter.Eventually.of_forall fun z => ?_)
    exact eq_max_sub_max _
  rw [← e1, ← e2]
  exact integral_mono ((hIact.const_mul _).sub (hIgc.const_mul _))
    ((integrable_finsetSum _ fun ℓ _ => hIs ℓ).div_const _) hlow

/-- `Pr[E_bad] ≤ Pr[J ≠ m₀] + Pr[G^c]`. -/
theorem ghost_bad {t : ℝ} (hν : ν = 4 * ε - t) :
    ((Measure.pi fun _ : Fin n => D) ⊗ₘ κ) (badSet D q (4 * ε)) ≤
      ENNReal.ofReal ((ghostP D hk q κ hqm ε ν).real (actSet (X := X) (H := H) (n := n) (k := k)) +
        (ghostP D hk q κ hqm ε ν).real (gcSet D hk q ν t)) := by
  rw [compProd_eq_ghostP D hk q κ hqm ε ν (measurableSet_badSet D q hqm (4 * ε)),
    ENNReal.ofReal_add measureReal_nonneg measureReal_nonneg, ofReal_measureReal, ofReal_measureReal]
  calc ghostP D hk q κ hqm ε ν {z | (z.1.1, z.2.1) ∈ badSet D q (4 * ε)}
      ≤ ghostP D hk q κ hqm ε ν (actSet ∪ gcSet D hk q ν t) :=
        measure_mono (bad_subset D hk q ε ν hν)
    _ ≤ _ := measure_union_le _ _

/-- The utility estimate with the paper's parameters: `Pr[G^c] ≤ (2k+1) δ/(6k) ≤ δ/2` for
`t = t_L = 4 ln(6k/δ)/(nε)`. -/
theorem ghost_gc_le (hn : 0 < n) (hε : 0 < ε) {δ : ℝ} (hδ : 0 < δ) (hk1 : 1 ≤ k) :
    (ghostP D hk q κ hqm ε ν).real (gcSet D hk q ν (4 * Real.log (6 * k / δ) / (n * ε))) ≤ δ / 2 := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk1
  have h1 := prob_gc_le D hk q κ hqm ε ν hn hε (4 * Real.log (6 * k / δ) / (n * ε))
  have e1 : -(ε / 2 * (4 * Real.log (6 * k / δ) / (n * ε))) / (2 * (1 / (n : ℝ))) =
      -Real.log (6 * k / δ) := by
    field_simp
    ring
  have e2 : Real.exp (-Real.log (6 * k / δ)) = δ / (6 * k) := by
    rw [Real.exp_neg, Real.exp_log (by positivity), inv_div]
  rw [e1, e2, Fintype.card_fin] at h1
  have h2 : ((2 * k + 1 : ℕ) : ℝ) * (δ / (6 * k)) ≤ δ / 2 := by
    push_cast
    rw [show (2 * (k : ℝ) + 1) * (δ / (6 * k)) = δ * (2 * k + 1) / (6 * k) by ring,
      div_le_div_iff₀ (by positivity) (by norm_num)]
    nlinarith
  exact (ENNReal.toReal_le_of_le_ofReal (by positivity) h1).trans h2

end Main

/-! ## The generic ghost monitor -/

/-- The real-arithmetic core of the self-bounding argument (L1100-1105). -/
theorem ghost_real_bound {n : ℕ} (hn : 0 < n) {ε δ A G ap am : ℝ} (bp bm : Fin n → ℝ)
    (hε : 0 < ε) (hε4 : ε < 1 / 10 ^ 4) (hδ : 0 < δ) (hA0 : 0 ≤ A) (hG0 : 0 ≤ G) (hG : G ≤ δ / 2)
    (hF1 : ∀ ℓ, bp ℓ ≤ Real.exp ε * ap + δ / 2) (hF2 : ∀ ℓ, am ≤ Real.exp ε * bm ℓ + δ / 2)
    (hF3 : ap = am) (hF4 : ap + am ≤ A)
    (hF5 : 2 * ε * A - (1 + 2 * ε) * G ≤ (∑ ℓ, (bp ℓ - bm ℓ)) / n) :
    A + G ≤ 100 * δ / ε := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hexpn : 0 < Real.exp (-ε) := Real.exp_pos _
  have hexpn1 : Real.exp (-ε) ≤ 1 := by
    rw [Real.exp_le_one_iff]
    linarith
  have hee : Real.exp (-ε) * Real.exp ε = 1 := by
    rw [← Real.exp_add, neg_add_cancel, Real.exp_zero]
  have hsinh := exp_sub_exp_neg_le hε.le (by linarith)
  have hsinh0 : 0 ≤ Real.exp ε - Real.exp (-ε) := by
    have := Real.exp_le_exp.mpr (show -ε ≤ ε by linarith)
    linarith
  have hR : ∀ ℓ, bp ℓ - bm ℓ ≤ (Real.exp ε - Real.exp (-ε)) * (A / 2) + δ := by
    intro ℓ
    have h1 := hF1 ℓ
    have h2 : Real.exp (-ε) * am ≤ bm ℓ + Real.exp (-ε) * (δ / 2) := by
      have := mul_le_mul_of_nonneg_left (hF2 ℓ) hexpn.le
      rw [mul_add, ← mul_assoc, hee, one_mul] at this
      exact this
    have h3 : (Real.exp ε - Real.exp (-ε)) * ap ≤ (Real.exp ε - Real.exp (-ε)) * (A / 2) := by
      apply mul_le_mul_of_nonneg_left _ hsinh0
      linarith
    have h4 : Real.exp (-ε) * (δ / 2) ≤ δ / 2 := by
      have := mul_le_mul_of_nonneg_right hexpn1 (show 0 ≤ δ / 2 by linarith)
      linarith
    have e : Real.exp ε * ap - Real.exp (-ε) * am = (Real.exp ε - Real.exp (-ε)) * ap := by
      rw [hF3]
      ring
    linarith
  have hsum : (∑ ℓ, (bp ℓ - bm ℓ)) / n ≤ (Real.exp ε - Real.exp (-ε)) * (A / 2) + δ := by
    rw [div_le_iff₀ hn']
    calc ∑ ℓ, (bp ℓ - bm ℓ) ≤ ∑ _ℓ : Fin n, ((Real.exp ε - Real.exp (-ε)) * (A / 2) + δ) :=
          Finset.sum_le_sum fun ℓ _ => hR ℓ
      _ = ((Real.exp ε - Real.exp (-ε)) * (A / 2) + δ) * n := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
          ring
  have h5 : (Real.exp ε - Real.exp (-ε)) * (A / 2) ≤ (2 * ε + ε ^ 2) * (A / 2) :=
    mul_le_mul_of_nonneg_right hsinh (by linarith)
  have hmain : 2 * ε * A - (1 + 2 * ε) * G ≤ (2 * ε + ε ^ 2) * (A / 2) + δ := by
    linarith
  have hεA : ε * (ε * A) ≤ 1 / 10 ^ 4 * (ε * A) :=
    mul_le_mul_of_nonneg_right hε4.le (by positivity)
  have hεG : ε * G ≤ 1 / 10 ^ 4 * (δ / 2) :=
    mul_le_mul hε4.le hG hG0 (by norm_num)
  have hfin : ε * (A + G) ≤ 100 * δ := by
    have e1 : (2 * ε + ε ^ 2) * (A / 2) = ε * A + ε * (ε * A) / 2 := by ring
    have e2 : (1 + 2 * ε) * G = G + 2 * (ε * G) := by ring
    have e3 : ε * (A + G) = ε * A + ε * G := by ring
    have e4 : 2 * ε * A = 2 * (ε * A) := by ring
    rw [e1, e2, e4] at hmain
    rw [e3]
    linarith
  rw [le_div_iff₀ hε]
  linarith

/-- **Lemma `I:lem:anchor_ghost_monitor`** (generic form; statement identical to `F2e2e.A.ghost_monitor`). -/
theorem ghost_monitor_aux {X H : Type*} [MeasurableSpace X] [MeasurableSpace H] (D : Measure X)
    [IsProbabilityMeasure D] {n k : ℕ} (hn : 0 < n) (hk : 1 ≤ k) (κ : Kernel (Fin n → X) H)
    [IsMarkovKernel κ] {ε δ : ℝ} (hε : 0 < ε) (hε4 : ε < 1 / 10 ^ 4) (hδ : 0 < δ) (hδ1 : δ ≤ 1)
    (hDP : DP.IsDP DP.Neighbor (fun S => κ S) (ε / 2) (δ / 2)) (q : H → Fin k → X → ℝ)
    (hqm : ∀ i, Measurable (fun p : H × X => q p.1 i p.2)) (hq01 : ∀ h i x, q h i x ∈ Set.Icc (0 : ℝ) 1)
    (hn16 : 16 * Real.log (6 * k / δ) / (4 * ε * ε) ≤ n) :
    ((Measure.pi fun _ : Fin n => D) ⊗ₘ κ)
        {p | ∃ i : Fin k, 4 * ε < |(∑ ℓ, q p.2 i (p.1 ℓ)) / n - ∫ x, q p.2 i x ∂D|} ≤
      ENNReal.ofReal (100 * δ / ε) := by
  have hk0 : 0 < k := hk
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have h6 : 1 < 6 * (k : ℝ) / δ := by
    rw [one_lt_div hδ]
    linarith
  have hΛ : 0 < Real.log (6 * k / δ) := Real.log_pos h6
  have htε : 4 * Real.log (6 * k / δ) / (n * ε) ≤ ε := by
    have hn' : (0 : ℝ) < n := by exact_mod_cast hn
    rw [div_le_iff₀ (by positivity)]
    rw [div_le_iff₀ (by positivity)] at hn16
    linarith
  obtain ⟨ν, hν⟩ : ∃ ν : ℝ, ν = 4 * ε - 4 * Real.log (6 * k / δ) / (n * ε) := ⟨_, rfl⟩
  have hbad := ghost_bad D hk0 q κ hqm ε ν hν
  have hG := ghost_gc_le D hk0 q κ hqm ε ν hn hε hδ hk
  have hlow := ghost_lower D hk0 q κ hqm ε ν hn hq01 htε hν hε
  have hAG := ghost_real_bound hn
    (A := (ghostP D hk0 q κ hqm ε ν).real (actSet (X := X) (H := H) (n := n) (k := k)))
    (G := (ghostP D hk0 q κ hqm ε ν).real (gcSet D hk0 q ν (4 * Real.log (6 * k / δ) / (n * ε))))
    (fun ℓ => ∫ z, max (psi hk0 D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk0 q κ hqm ε ν))
    (fun ℓ => ∫ z, max (-psi hk0 D q z.2 (z.1.1 ℓ)) 0 ∂(ghostP D hk0 q κ hqm ε ν))
    hε hε4 hδ measureReal_nonneg measureReal_nonneg hG
    (fun ℓ => transfer_pos D hk0 q κ hqm ε ν hn hq01 hε hδ.le hDP ℓ)
    (fun ℓ => transfer_neg D hk0 q κ hqm ε ν hn hq01 hε hδ.le hDP ℓ)
    (ghost_center D hk0 q κ hqm ε ν hq01) (ghost_abs D hk0 q κ hqm ε ν hq01) hlow
  exact hbad.trans (ENNReal.ofReal_le_ofReal hAG)

end F2e2e.A.Ghost
