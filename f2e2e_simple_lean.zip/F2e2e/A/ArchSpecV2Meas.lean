import F2e2e.A.SpecV2BridgeRound
import F2e2e.A.ArchMeasurable
import F2e2e.Lib.Dist.Laplace
import F2e2e.Lib.Dist.BetaBridge

/-!
# Spec v2 (A): the cascade is jointly measurable and its coin law is a probability measure

Owner: A-ARCH (a99d156c). Moved at the Spec lock from the scratch draft `F2e2e/Scratch/AV2/ArchV2Meas.lean`
(written against the namespaced candidate `F2e2eV2`; the only change is `F2e2eV2.` ↦ `F2e2e.`). It proves two
conjuncts of `Theorem_A_statistical`, for every coin (not almost everywhere), directly on the Spec's
definitions:
* `isProbabilityMeasure_adaCoinLaw`: `IsProbabilityMeasure (adaCoinLaw k α β)` (for `b_SVT > 0`);
* `jointlyMeasurable_adaCascade`: `(adaCascade k α β).JointlyMeasurable` (for `α > 0`, so that `η₁ > 0`).

It uses A-ACC's unfolding of v2's active round (`F2e2e.A.V2Bridge.vθ`, …, `active_*`) and
`entropicArgmin_eq_waterFill'` (`F2e2e/A/SpecV2BridgeRound.lean`): the stored weights are water-filling
solutions, hence measurable in the payoffs (`Opt.measurable_waterFill`). The state space `ADAState` carries the
σ-algebra induced by its fields (`stTuple`).
-/

namespace F2e2e.A.V2Meas

open MeasureTheory ProbabilityTheory F2e2e.A.V2Bridge

noncomputable section

/-! ## The coin law -/

theorem laplaceLaw_eq {b : ℝ} (hb : 0 < b) : F2e2e.laplaceLaw b = laplace b := by
  rw [laplace_of_pos hb]
  rfl

theorem isProbabilityMeasure_laplaceLaw {b : ℝ} (hb : 0 < b) :
    IsProbabilityMeasure (F2e2e.laplaceLaw b) := by
  rw [laplaceLaw_eq hb]
  infer_instance

theorem one_le_adaP1 (α β : ℝ) : 1 ≤ F2e2e.adaP1 α β := by
  unfold F2e2e.adaP1
  split_ifs <;> omega

theorem isProbabilityMeasure_adaStage1Law (α β : ℝ) : IsProbabilityMeasure (F2e2e.adaStage1Law α β) := by
  have := Dist.isProbabilityMeasure_betaMeasure_nat (one_le_adaP1 α β)
  unfold F2e2e.adaStage1Law
  exact Measure.isProbabilityMeasure_map
    ((measurable_const.mul ((measurable_const.mul measurable_id).sub measurable_const))).aemeasurable

theorem isProbabilityMeasure_adaNoiseLaw {k : ℕ} {α β : ℝ} (hb : 0 < F2e2e.adaBsvt k α β)
    (j : F2e2e.ADANoiseIndex k (F2e2e.adaL α)) : IsProbabilityMeasure (F2e2e.adaNoiseLaw k α β j) := by
  rcases j with i | x | x | x
  · exact isProbabilityMeasure_adaStage1Law α β
  · exact isProbabilityMeasure_laplaceLaw (by positivity)
  · exact isProbabilityMeasure_laplaceLaw hb
  · exact isProbabilityMeasure_laplaceLaw hb

/-- **Conjunct 1 of `Theorem_A_statistical`**: the coin law is a probability measure. -/
theorem isProbabilityMeasure_adaCoinLaw {k : ℕ} {α β : ℝ} (hb : 0 < F2e2e.adaBsvt k α β) :
    IsProbabilityMeasure (F2e2e.adaCoinLaw k α β) := by
  have : ∀ j : Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
      (Fin (F2e2e.adaL α + 1) × Fin (k + 1)), IsProbabilityMeasure (F2e2e.adaNoiseLaw k α β j) :=
    fun j => isProbabilityMeasure_adaNoiseLaw hb j
  exact @Measure.pi.instIsProbabilityMeasure (Fin k ⊕ (Fin k × Fin (F2e2e.adaL α + 1)) ⊕
    (Fin k × Fin (F2e2e.adaL α + 1)) ⊕ (Fin (F2e2e.adaL α + 1) × Fin (k + 1))) _ _ _
    (F2e2e.adaNoiseLaw k α β) this

/-! ## Generic measurability helpers -/

section Helpers

variable {P : Type*} [MeasurableSpace P]

theorem measurable_bool_of_set {f : P → Bool} (h : MeasurableSet {p | f p = true}) : Measurable f := by
  refine measurable_to_countable' fun b => ?_
  cases b
  · have e : f ⁻¹' {false} = {p | f p = true}ᶜ := by
      ext p
      simp
    rw [e]
    exact h.compl
  · exact h

theorem measurableSet_bool_eq_true {f : P → Bool} (hf : Measurable f) : MeasurableSet {p | f p = true} :=
  hf (measurableSet_singleton true)

theorem measurable_bor {f g : P → Bool} (hf : Measurable f) (hg : Measurable g) :
    Measurable fun p => f p || g p :=
  (measurable_of_countable (fun b : Bool × Bool => b.1 || b.2)).comp (hf.prodMk hg)

theorem measurable_band {f g : P → Bool} (hf : Measurable f) (hg : Measurable g) :
    Measurable fun p => f p && g p :=
  (measurable_of_countable (fun b : Bool × Bool => b.1 && b.2)).comp (hf.prodMk hg)

theorem measurable_nat_comp {u : P → ℕ} (hu : Measurable u) {γ : Type*} [MeasurableSpace γ] (g : ℕ → γ) :
    Measurable fun p => g (u p) :=
  (measurable_from_nat (f := g)).comp hu

theorem measurable_clip01V2 : Measurable F2e2e.clip01 :=
  (measurable_const.min (measurable_const.max measurable_id)).subtype_mk

theorem measurable_sign1V2 : Measurable F2e2e.sign1 := by
  unfold F2e2e.sign1
  exact Measurable.ite measurableSet_Ici measurable_const measurable_const

end Helpers

/-- The entropic projection is measurable in the payoff vector (`η > 0`). -/
theorem measurable_entropicArgmin {n : ℕ} {η : ℝ} (hη : 0 < η) : Measurable (F2e2e.entropicArgmin n η) := by
  have e : F2e2e.entropicArgmin n η = Opt.waterFill n η :=
    funext fun G => entropicArgmin_eq_waterFill' hη G
  rw [e]
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    exact measurable_of_subsingleton_codomain _
  · exact Opt.measurable_waterFill hn η

/-! ## The chain -/

section Chain

variable {P : Type*} [MeasurableSpace P]

theorem measurableSet_adaFires (L : ℕ) (tau : ℕ → ℕ → ℝ) {θ ρ ν : P → ℕ → ℝ}
    (hθ : ∀ r, Measurable fun p => θ p r) (hρ : ∀ r, Measurable fun p => ρ p r)
    (hν : ∀ r, Measurable fun p => ν p r) {u : P → ℕ} (hu : Measurable u) {c : P → ℝ} (hc : Measurable c)
    (r : ℕ) : MeasurableSet {p | F2e2e.adaFires L tau (θ p) (ρ p) (ν p) (u p) (c p) r = true} := by
  have e : {p | F2e2e.adaFires L tau (θ p) (ρ p) (ν p) (u p) (c p) r = true} =
      {_p | 2 ≤ r ∧ r ≤ L} ∩ {p | tau (u p) r + ρ p r ≤ |c p - θ p r| + ν p r} := by
    ext p
    simp only [F2e2e.adaFires, decide_eq_true_eq, Set.mem_ofPred_eq, Set.mem_inter_iff, and_assoc]
  rw [e]
  refine (MeasurableSet.const _).inter (measurableSet_le ?_ ?_)
  · exact (measurable_nat_comp hu (fun n => tau n r)).add (hρ r)
  · exact (continuous_abs.measurable.comp (hc.sub (hθ r))).add (hν r)

theorem measurable_adaChain (L : ℕ) (tau : ℕ → ℕ → ℝ) {θ ρ ν ζ : P → ℕ → ℝ}
    (hθ : ∀ r, Measurable fun p => θ p r) (hρ : ∀ r, Measurable fun p => ρ p r)
    (hν : ∀ r, Measurable fun p => ν p r) (hζ : ∀ r, Measurable fun p => ζ p r)
    {c1 : P → Set.Icc (0 : ℝ) 1} (hc1 : Measurable c1) (r : ℕ) :
    Measurable fun p => F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r := by
  induction r with
  | zero => exact measurable_const.prodMk hc1
  | succ r ih =>
    have h1 : Measurable fun p => (F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r).1 :=
      measurable_fst.comp ih
    have h2 : Measurable fun p => ((F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r).2 : ℝ) :=
      measurable_subtype_coe.comp (measurable_snd.comp ih)
    have hset := measurableSet_adaFires L tau hθ hρ hν h1 h2 r
    show Measurable fun p =>
      if F2e2e.adaFires L tau (θ p) (ρ p) (ν p) (F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r).1
          ((F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r).2 : ℝ) r = true
      then (r, F2e2e.clip01 (θ p r + ζ p r))
      else F2e2e.adaChain L tau (θ p) (ρ p) (ν p) (ζ p) (c1 p) r
    exact Measurable.ite hset (measurable_const.prodMk (measurable_clip01V2.comp ((hθ r).add (hζ r)))) ih

end Chain

/-! ## The σ-algebra on the cascade's state -/

section State

variable {k : ℕ} {α β : ℝ}

/-- The fields of a v2 state as a tuple. -/
def stTuple (st : F2e2e.ADAState k α β) :
    Bool × ℕ × (ℕ → ℕ) × (ℕ → ℕ) × ((r : ℕ) → Fin (F2e2e.adaBlock k α β r) → ℝ) ×
      ((r : ℕ) → Fin (F2e2e.adaBlock k α β r) → ℝ) :=
  (st.halt, st.t1, st.N, st.M, st.pay, st.P)

/-- The σ-algebra on `ADAState` induced by its fields. -/
instance instMeasurableSpaceADAState : MeasurableSpace (F2e2e.ADAState k α β) :=
  MeasurableSpace.comap stTuple inferInstance

theorem measurable_stTuple : Measurable (stTuple (k := k) (α := α) (β := β)) :=
  comap_measurable _

theorem measurable_st_iff {Ω : Type*} [MeasurableSpace Ω] {f : Ω → F2e2e.ADAState k α β} :
    Measurable f ↔ Measurable (fun ω => stTuple (f ω)) := by
  refine ⟨fun h => measurable_stTuple.comp h, fun h => ?_⟩
  rw [measurable_iff_comap_le]
  have e : MeasurableSpace.comap f (MeasurableSpace.comap stTuple inferInstance) =
      MeasurableSpace.comap (fun ω => stTuple (f ω)) inferInstance := by
    rw [MeasurableSpace.comap_comp]
    rfl
  change MeasurableSpace.comap f (MeasurableSpace.comap stTuple inferInstance) ≤ _
  rw [e]
  exact h.comap_le

theorem measurable_st_halt : Measurable fun st : F2e2e.ADAState k α β => st.halt :=
  measurable_fst.comp measurable_stTuple

theorem measurable_st_t1 : Measurable fun st : F2e2e.ADAState k α β => st.t1 :=
  measurable_fst.comp (measurable_snd.comp measurable_stTuple)

theorem measurable_st_N : Measurable fun st : F2e2e.ADAState k α β => st.N :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp measurable_stTuple))

theorem measurable_st_M : Measurable fun st : F2e2e.ADAState k α β => st.M :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp measurable_stTuple)))

theorem measurable_st_pay : Measurable fun st : F2e2e.ADAState k α β => st.pay :=
  measurable_fst.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp measurable_stTuple))))

theorem measurable_st_P : Measurable fun st : F2e2e.ADAState k α β => st.P :=
  measurable_snd.comp (measurable_snd.comp (measurable_snd.comp (measurable_snd.comp
    (measurable_snd.comp measurable_stTuple))))

end State

/-! ## One active round -/

section Round

variable {k : ℕ} {α β : ℝ}

/-- The parameter space of one round: the state, the query values on the sample, the coins. -/
abbrev RPar (k : ℕ) (α β : ℝ) : Type :=
  F2e2e.ADAState k α β × (Fin (F2e2e.adaSampleSize k α β) → ℝ) ×
    (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ)

theorem measurable_noiseXiV2 (i : ℕ) :
    Measurable fun ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ => F2e2e.noiseXi ω i := by
  unfold F2e2e.noiseXi
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseNuV2 (i r : ℕ) :
    Measurable fun ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ => F2e2e.noiseNu ω i r := by
  unfold F2e2e.noiseNu
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseZetaV2 (i r : ℕ) :
    Measurable fun ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ => F2e2e.noiseZeta ω i r := by
  unfold F2e2e.noiseZeta
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_noiseRhoV2 (r e : ℕ) :
    Measurable fun ω : F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ => F2e2e.noiseRho ω r e := by
  unfold F2e2e.noiseRho
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_adaQAt (r : ℕ) (ℓ : Fin (F2e2e.adaBlock k α β r)) :
    Measurable fun q : Fin (F2e2e.adaSampleSize k α β) → ℝ => F2e2e.adaQAt q r ℓ := by
  unfold F2e2e.adaQAt
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

variable (i : ℕ)

theorem measurable_vθ (r : ℕ) : Measurable fun p : RPar k α β => vθ p.1 p.2.1 r := by
  unfold vθ
  refine Finset.measurable_sum _ fun ℓ _ => ?_
  exact ((measurable_pi_apply ℓ).comp ((measurable_pi_apply r).comp (measurable_st_P.comp measurable_fst))).mul
    ((measurable_adaQAt r ℓ).comp (measurable_fst.comp measurable_snd))

theorem measurable_vρ (r : ℕ) : Measurable fun p : RPar k α β => vρ p.1 p.2.2 r := by
  unfold vρ
  have hM : Measurable fun p : RPar k α β => p.1.M r - 1 :=
    measurable_nat_comp ((measurable_pi_apply r).comp (measurable_st_M.comp measurable_fst)) (fun n => n - 1)
  exact measurable_nat_index (g := fun e (p : RPar k α β) => F2e2e.noiseRho p.2.2 r e)
    (fun e => (measurable_noiseRhoV2 r e).comp (measurable_snd.comp measurable_snd)) hM

theorem measurable_vν (r : ℕ) : Measurable fun p : RPar k α β => vν i p.2.2 r :=
  (measurable_noiseNuV2 i r).comp (measurable_snd.comp measurable_snd)

theorem measurable_vζ (r : ℕ) : Measurable fun p : RPar k α β => vζ i p.2.2 r :=
  (measurable_noiseZetaV2 i r).comp (measurable_snd.comp measurable_snd)

theorem measurable_vc1 : Measurable fun p : RPar k α β => vc1 p.1 i p.2.1 p.2.2 :=
  measurable_clip01V2.comp ((measurable_vθ 1).add ((measurable_noiseXiV2 i).comp
    (measurable_snd.comp measurable_snd)))

theorem measurable_vchain (r : ℕ) : Measurable fun p : RPar k α β => vchain p.1 i p.2.1 p.2.2 r :=
  measurable_adaChain (F2e2e.adaL α) (F2e2e.adaTau α) (θ := fun p : RPar k α β => vθ p.1 p.2.1)
    (ρ := fun p : RPar k α β => vρ p.1 p.2.2) (ν := fun p : RPar k α β => vν i p.2.2)
    (ζ := fun p : RPar k α β => vζ i p.2.2) measurable_vθ measurable_vρ (measurable_vν i)
    (measurable_vζ i) (measurable_vc1 i) r

theorem measurable_vtrig (r : ℕ) : Measurable fun p : RPar k α β => vtrig p.1 i p.2.1 p.2.2 r :=
  measurable_bool_of_set (measurableSet_adaFires (F2e2e.adaL α) (F2e2e.adaTau α)
    (θ := fun p : RPar k α β => vθ p.1 p.2.1) (ρ := fun p : RPar k α β => vρ p.1 p.2.2)
    (ν := fun p : RPar k α β => vν i p.2.2) measurable_vθ measurable_vρ (measurable_vν i)
    (measurable_fst.comp (measurable_vchain i r))
    (measurable_subtype_coe.comp (measurable_snd.comp (measurable_vchain i r))) r)

theorem measurable_vuF : Measurable fun p : RPar k α β => vuF p.1 i p.2.1 p.2.2 :=
  measurable_fst.comp (measurable_vchain i _)

theorem measurable_vans : Measurable fun p : RPar k α β => vans p.1 i p.2.1 p.2.2 :=
  measurable_snd.comp (measurable_vchain i _)

theorem measurable_vcaseA : Measurable fun p : RPar k α β => vcaseA p.1 i p.2.1 p.2.2 :=
  measurable_nat_comp (measurable_vuF i) (fun n => decide (n = 2))

theorem measurable_vcaseB : Measurable fun p : RPar k α β => vcaseB p.1 i p.2.1 p.2.2 :=
  measurable_nat_comp (measurable_vuF i) (fun n => decide (3 ≤ n))

theorem measurable_vrel (r : ℕ) : Measurable fun p : RPar k α β => vrel p.1 i p.2.1 p.2.2 r :=
  measurable_bor (measurable_vtrig i r) (measurable_band (measurable_vcaseB i)
    (measurable_nat_comp (measurable_vuF i) (fun n => decide (r + 1 = n))))

theorem measurable_vs : Measurable fun p : RPar k α β => vs p.1 i p.2.1 p.2.2 := by
  unfold vs
  have hset : MeasurableSet {p : RPar k α β | 2 ≤ vuF p.1 i p.2.1 p.2.2} :=
    (measurable_vuF i) (MeasurableSet.of_discrete (s := {n : ℕ | 2 ≤ n}))
  have hc : Measurable fun p : RPar k α β =>
      ((vchain p.1 i p.2.1 p.2.2 (vuF p.1 i p.2.1 p.2.2)).2 : ℝ) :=
    measurable_nat_index (g := fun r (p : RPar k α β) => ((vchain p.1 i p.2.1 p.2.2 r).2 : ℝ))
      (fun r => measurable_subtype_coe.comp (measurable_snd.comp (measurable_vchain i r))) (measurable_vuF i)
  exact Measurable.ite hset (measurable_sign1V2.comp (hc.sub (measurable_subtype_coe.comp (measurable_vans i))))
    measurable_const

theorem measurable_vδ (m : ℕ) : Measurable fun p : RPar k α β => vδ p.1 i p.2.1 p.2.2 m := by
  unfold vδ
  refine Measurable.ite (measurableSet_bool_eq_true (measurable_vcaseB i)) ?_ measurable_const
  refine Measurable.ite ((measurable_vuF i) (MeasurableSet.of_discrete (s := {n : ℕ | m + 1 = n})))
    (measurable_const.mul (measurable_vs i)).neg ?_
  refine Measurable.ite ((measurable_vuF i)
    (MeasurableSet.of_discrete (s := {n : ℕ | m = n ∧ n ≤ F2e2e.adaL α - 1}))) ?_ measurable_const
  exact measurable_const.mul (measurable_vs i)

theorem measurable_vhaltAfter : Measurable fun p : RPar k α β => vhaltAfter p.1 i p.2.1 p.2.2 := by
  unfold vhaltAfter
  refine measurable_bor (measurable_band (measurable_vcaseA i) ?_) (measurable_band (measurable_vcaseB i) ?_)
  · exact measurable_nat_comp (measurable_st_t1.comp measurable_fst)
      (fun n => decide (n + 1 = F2e2e.adaT1max α))
  · have hN : Measurable fun p : RPar k α β => p.1.N (vuF p.1 i p.2.1 p.2.2) :=
      measurable_nat_index (g := fun r (p : RPar k α β) => p.1.N r)
        (fun r => (measurable_pi_apply r).comp (measurable_st_N.comp measurable_fst)) (measurable_vuF i)
    have h2 : Measurable fun p : RPar k α β =>
        (p.1.N (vuF p.1 i p.2.1 p.2.2), vuF p.1 i p.2.1 p.2.2) := hN.prodMk (measurable_vuF i)
    exact (measurable_of_countable
      (fun x : ℕ × ℕ => decide (x.1 + 1 = F2e2e.adaNmax α x.2))).comp h2

theorem measurable_vpay : Measurable fun p : RPar k α β => vpay p.1 i p.2.1 p.2.2 := by
  rw [measurable_pi_iff]
  intro r
  rw [measurable_pi_iff]
  intro ℓ
  unfold vpay
  have hpay : Measurable fun p : RPar k α β => p.1.pay r ℓ :=
    (measurable_pi_apply ℓ).comp ((measurable_pi_apply r).comp (measurable_st_pay.comp measurable_fst))
  have hq : Measurable fun p : RPar k α β => F2e2e.adaQAt p.2.1 r ℓ :=
    (measurable_adaQAt r ℓ).comp (measurable_fst.comp measurable_snd)
  refine Measurable.ite ?_ (hpay.sub ((measurable_vs i).mul hq)) ?_
  · exact (measurableSet_bool_eq_true (measurable_vcaseA i)).inter (MeasurableSet.const _)
  · exact Measurable.ite (MeasurableSet.const _) (hpay.add ((measurable_vδ i r).mul hq)) hpay

theorem measurable_vupd (r : ℕ) : Measurable fun p : RPar k α β => vupd p.1 i p.2.1 p.2.2 r := by
  unfold vupd
  exact measurable_bor (measurable_band (measurable_vcaseA i) measurable_const)
    (measurable_band (measurable_vcaseB i) (measurable_nat_comp (measurable_vuF i)
      (fun n => decide (2 ≤ r ∧ r ≤ F2e2e.adaL α - 1 ∧ (r + 1 = n ∨ r = n)))))

theorem measurable_vP (hα : 0 < α) : Measurable fun p : RPar k α β => vP p.1 i p.2.1 p.2.2 := by
  rw [measurable_pi_iff]
  intro r
  unfold vP
  have hpr : Measurable fun p : RPar k α β => vpay p.1 i p.2.1 p.2.2 r :=
    (measurable_pi_apply r).comp (measurable_vpay i)
  have he1 : 0 < F2e2e.adaEta1 α := by
    unfold F2e2e.adaEta1
    positivity
  refine Measurable.ite (measurableSet_bool_eq_true (measurable_vupd i r)) ?_
    ((measurable_pi_apply r).comp (measurable_st_P.comp measurable_fst))
  refine Measurable.ite (MeasurableSet.const _) ((measurable_entropicArgmin he1).comp hpr)
    ((measurable_entropicArgmin one_pos).comp hpr)

/-- **One active round is measurable** in (state, query values, coins). -/
theorem measurable_adaActiveRound (hα : 0 < α) :
    Measurable fun p : RPar k α β => F2e2e.adaActiveRound p.1 i p.2.1 p.2.2 := by
  refine Measurable.prodMk ?_ (Measurable.prodMk ?_ ?_)
  · rw [measurable_st_iff]
    simp only [stTuple]
    have hA1 : Measurable fun p : RPar k α β => (if vcaseA p.1 i p.2.1 p.2.2 = true then 1 else 0 : ℕ) :=
      (measurable_of_countable (fun b : Bool => if b = true then (1 : ℕ) else 0)).comp (measurable_vcaseA i)
    have hN : Measurable fun p : RPar k α β => fun r =>
        p.1.N r + (if vcaseB p.1 i p.2.1 p.2.2 = true ∧ r = vuF p.1 i p.2.1 p.2.2 then 1 else 0) := by
      rw [measurable_pi_iff]
      intro r
      have h2 : Measurable fun p : RPar k α β => (vcaseB p.1 i p.2.1 p.2.2, vuF p.1 i p.2.1 p.2.2) :=
        (measurable_vcaseB i).prodMk (measurable_vuF i)
      have hb : Measurable fun p : RPar k α β =>
          (if vcaseB p.1 i p.2.1 p.2.2 = true ∧ r = vuF p.1 i p.2.1 p.2.2 then 1 else 0 : ℕ) :=
        (measurable_of_countable (fun x : Bool × ℕ => if x.1 = true ∧ r = x.2 then (1 : ℕ) else 0)).comp h2
      exact ((measurable_pi_apply r).comp (measurable_st_N.comp measurable_fst)).add hb
    have hM : Measurable fun p : RPar k α β => fun r => p.1.M r +
        (if (vcaseA p.1 i p.2.1 p.2.2 = true ∧ r = 2) ∨
          (vcaseB p.1 i p.2.1 p.2.2 = true ∧ 2 ≤ r ∧ r ≤ vuF p.1 i p.2.1 p.2.2) then 1 else 0) := by
      rw [measurable_pi_iff]
      intro r
      have h3 : Measurable fun p : RPar k α β =>
          (vcaseA p.1 i p.2.1 p.2.2, vcaseB p.1 i p.2.1 p.2.2, vuF p.1 i p.2.1 p.2.2) :=
        (measurable_vcaseA i).prodMk ((measurable_vcaseB i).prodMk (measurable_vuF i))
      have hb : Measurable fun p : RPar k α β =>
          (if (vcaseA p.1 i p.2.1 p.2.2 = true ∧ r = 2) ∨
            (vcaseB p.1 i p.2.1 p.2.2 = true ∧ 2 ≤ r ∧ r ≤ vuF p.1 i p.2.1 p.2.2) then 1 else 0 : ℕ) :=
        (measurable_of_countable (fun x : Bool × Bool × ℕ =>
          if (x.1 = true ∧ r = 2) ∨ (x.2.1 = true ∧ 2 ≤ r ∧ r ≤ x.2.2) then (1 : ℕ) else 0)).comp h3
      exact ((measurable_pi_apply r).comp (measurable_st_M.comp measurable_fst)).add hb
    exact (measurable_vhaltAfter i).prodMk (((measurable_st_t1.comp measurable_fst).add hA1).prodMk
      (hN.prodMk (hM.prodMk ((measurable_vpay i).prodMk (measurable_vP i hα)))))
  · exact measurable_vans i
  · rw [measurable_pi_iff]
    intro f
    cases f with
    | active =>
      simp only
      exact measurable_const
    | c1 =>
      simp only
      exact measurable_subtype_coe.comp (measurable_vc1 i)
    | b r =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vtrig i r)) measurable_const measurable_const
    | uPrev r =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vtrig i r))
        (measurable_nat_comp (measurable_fst.comp (measurable_vchain i r)) (fun n => (n : ℝ))) measurable_const
    | released r =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vrel i r)) measurable_const measurable_const
    | v r =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vrel i r))
        ((measurable_vθ r).add (measurable_vζ i r)) measurable_const
    | c r =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vrel i r))
        (measurable_subtype_coe.comp (measurable_clip01V2.comp ((measurable_vθ r).add (measurable_vζ i r))))
        measurable_const
    | s =>
      simp only
      exact measurable_vs i
    | delta m =>
      simp only
      exact measurable_vδ i m
    | haltAfter =>
      simp only
      exact Measurable.ite (measurableSet_bool_eq_true (measurable_vhaltAfter i)) measurable_const
        measurable_const

/-- **One round is measurable** (halted rounds output `(0, 0)` and keep the state). -/
theorem measurable_adaRound (hα : 0 < α) :
    Measurable fun p : RPar k α β => F2e2e.adaRound p.1 i p.2.1 p.2.2 := by
  unfold F2e2e.adaRound
  exact Measurable.ite (measurableSet_bool_eq_true (measurable_st_halt.comp measurable_fst))
    (measurable_fst.prodMk measurable_const) (measurable_adaActiveRound i hα)

end Round

/-! ## The cascade -/

section Cascade

variable {k : ℕ} {α β : ℝ}

/-- The extension of the query values of rounds `0, …, i` used by `adaCascade`. -/
theorem measurable_extendV2 {i : ℕ} (j : ℕ) :
    Measurable fun vals : Fin (i + 1) → Fin (F2e2e.adaSampleSize k α β) → ℝ =>
      (if h : j < i + 1 then vals ⟨j, h⟩ else fun _ => 0) := by
  split_ifs
  · exact measurable_pi_apply _
  · exact measurable_const

theorem measurable_adaStateBefore (hα : 0 < α) (i t : ℕ) :
    Measurable fun p : (Fin (i + 1) → Fin (F2e2e.adaSampleSize k α β) → ℝ) ×
        (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) =>
      F2e2e.adaStateBefore k α β (fun j => if h : j < i + 1 then p.1 ⟨j, h⟩ else fun _ => 0) p.2 t := by
  induction t with
  | zero => exact measurable_const
  | succ t ih =>
    show Measurable fun p : (Fin (i + 1) → Fin (F2e2e.adaSampleSize k α β) → ℝ) ×
        (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) =>
      (F2e2e.adaRound (F2e2e.adaStateBefore k α β
        (fun j => if h : j < i + 1 then p.1 ⟨j, h⟩ else fun _ => 0) p.2 t) t
        (if h : t < i + 1 then p.1 ⟨t, h⟩ else fun _ => 0) p.2).1
    exact measurable_fst.comp ((measurable_adaRound t hα).comp
      (ih.prodMk (((measurable_extendV2 t).comp measurable_fst).prodMk measurable_snd)))

/-- **Conjunct 2 of `Theorem_A_statistical`**: the cascade's public output is jointly measurable in the
query values and the coins, for every coin. -/
theorem jointlyMeasurable_adaCascade (hα : 0 < α) : (F2e2e.adaCascade k α β).JointlyMeasurable := by
  intro i
  show Measurable fun p : (Fin (i + 1) → Fin (F2e2e.adaSampleSize k α β) → ℝ) ×
      (F2e2e.ADANoiseIndex k (F2e2e.adaL α) → ℝ) =>
    (F2e2e.adaRound (F2e2e.adaStateBefore k α β
      (fun j => if h : j < i + 1 then p.1 ⟨j, h⟩ else fun _ => 0) p.2 i) i (p.1 (Fin.last i)) p.2).2
  exact measurable_snd.comp ((measurable_adaRound i hα).comp
    ((measurable_adaStateBefore hα i i).prodMk (((measurable_pi_apply (Fin.last i)).comp
      measurable_fst).prodMk measurable_snd)))

end Cascade

end

end F2e2e.A.V2Meas
