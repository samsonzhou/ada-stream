import F2e2e.BSpace.PubCore

/-!
# B_space, layer P (W2): the parameter record for general parameters, structural facts

Owner: W2 (a2ff64c3), for W4 (cc77ceaa), plan `F2e2e/BSpace/BSPACE_PLAN.md` §P.

The B programs receive `encVParams M J R aReq ξReq = encInts [M, J, R, eA, eXi]`, which is
`encStreamParams ⟨M, J, R, eA, eXi⟩`. Hence W2's routine `adaPub` (Idx 600, `body_adaPub`) computes the
parameter record `adaPubEnc (adaParams eA eXi M J R)` of a general instance when the five parameter keys
`Idx.peBankA, peBankXi, pbankM, pbankJ, pbankR` hold the field getters `eGet 3/4/0/1/2 (var 0)`.

* **P1** `bsPubTable` (the five getters `++ adaPubTable`), the explicit value bound
  `bsPubBound Mc J R eA eXi = 2^20 · bsPubL²` with `bsPubL = eA + eXi + ⌈log₂(Mc+J+R+2)⌉ + 100`, and
  `bsPub_eval`: for all `eA ≥ 4`, `eXi ≥ 2` (no `StreamParams`, no `ParamsOK`), `body_adaPub` evaluates
  on `encInts [Mc, J, R, eA, eXi]` to `adaPubEnc (adaParams eA eXi Mc J R)`, of size `≤ M`. Proof: W2's
  `bsP_core` (W3's copy of `adaPub_core` needing only `2^20 L² ≤ M`, `F2e2e/BSpace/PubCore.lean`) at
  the scale `L = bsPubL`; its side conditions are
  checked here (the block-size sum by B-NUM's `adaN_le_of_bounds` with `E = 2^{eA + ⌈log₂(Mc+J+R+2)⌉}`).
* **P2** `bsP_blockSizes_length`, `bsP_Tmax_length`, `bsP_blockSizes_pos`: the shape hypotheses `hbs`,
  `hT`, `hpos` of W4's routine specs, for every instance `adaParams eA eXi M J R` (no hypothesis on
  `eA, eXi` is needed: `n_j ≥ 2^12 χ h⁻² > 0`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.C.Impl F2e2e.C.Impl.W6 F2e2e.C.Impl.AP

/-! ## P2: structural facts of a general instance -/

/-- `[n_0, …, n_p]` has `p + 1` entries. -/
theorem bsP_blockSizes_length (eA eXi M J R : ℕ) :
    (adaParams eA eXi M J R).blockSizes.length = (adaParams eA eXi M J R).p + 1 :=
  adaBlockSizes_length M J R eA eXi

/-- `[T_0^max, …, T_{p-1}^max]` has `p` entries. -/
theorem bsP_Tmax_length (eA eXi M J R : ℕ) :
    (adaParams eA eXi M J R).Tmax.length = (adaParams eA eXi M J R).p := by
  show (adaTmaxList eA).length = adaP eA
  unfold adaTmaxList
  rw [List.length_map, List.length_range]

/-- The block sizes are positive: `n_j ≥ 2^12 χ h⁻² > 0` (`χ ≥ 49`, `h⁻¹ = 512 p 2^{eA}`, `p ≥ 2`). -/
theorem bsP_blockSizes_pos (eA eXi M J R : ℕ) :
    ∀ j, j ≤ (adaParams eA eXi M J R).p → 0 < (adaParams eA eXi M J R).blockSizes.getD j 0 := by
  intro j hj
  have hj' : j < adaP eA + 1 := Nat.lt_succ_of_le hj
  have hbs : (adaParams eA eXi M J R).blockSizes =
      (List.range (adaP eA + 1)).map (adaNBlock M J R eA eXi) := rfl
  rw [hbs, List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hj']
  show 0 < adaNBlock M J R eA eXi j
  have hp2 : 2 ≤ adaP eA := (Nat.find_spec (exists_adaP eA)).1
  have hchi : 0 < adaChi M J R eA eXi := by
    unfold adaChi
    omega
  have hh : 0 < adaHInv eA := by
    unfold adaHInv
    exact Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (pow_pos (by norm_num) _)
  unfold adaNBlock
  exact lt_of_lt_of_le (Nat.mul_pos (Nat.mul_pos (by norm_num) hchi) (pow_pos hh 2))
    (Nat.le_add_left _ _)

/-! ## P1: the parameter record -/

/-- The B parameter table: the five parameter keys hold the field getters of
`encInts [M, J, R, eA, eXi]`, followed by W2's `adaPubTable` (600, 604, 605, 650–657 and the library
routines `pow2`, `clog2`, `natSqrt`). W5's `normQ` (766) is supplied by `NormQSpec`. -/
def bsPubTable : List (ℕ × Expr) :=
  [(Idx.peBankA, eGet 3 (Expr.var 0)), (Idx.peBankXi, eGet 4 (Expr.var 0)),
    (Idx.pbankM, eGet 0 (Expr.var 0)), (Idx.pbankJ, eGet 1 (Expr.var 0)),
    (Idx.pbankR, eGet 2 (Expr.var 0))] ++ adaPubTable

/-- The scale of the parameter record: `eA + eXi + ⌈log₂(Mc + J + R + 2)⌉ + 100`. -/
def bsPubL (Mc J R eA eXi : ℕ) : ℕ := eA + eXi + Nat.clog 2 (Mc + J + R + 2) + 100

/-- **The value bound of the parameter record**: `2^20 · bsPubL²` (W3's `bsPubBound_le`:
`≤ 2^32 · adaBoundA (adaParams eA eXi Mc J R)`, `F2e2e/BSpace/PubBound.lean`). -/
def bsPubBound (Mc J R eA eXi : ℕ) : ℕ := 2 ^ 20 * bsPubL Mc J R eA eXi ^ 2

/-- `L < 2^L` gives `L^7 < 2^{7L}`. -/
private theorem bsP_pow7_lt (L : ℕ) : L ^ 7 < 2 ^ (7 * L) := by
  have h := Nat.pow_lt_pow_left (Nat.lt_two_pow_self (n := L)) (show (7 : ℕ) ≠ 0 by norm_num)
  rwa [← pow_mul, mul_comm] at h

/-- The block-size sum of a general instance at the scale `L = bsPubL`. -/
theorem bsP_blockSizes_sum_lt {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) :
    (adaBlockSizes Mc J R eA eXi).sum < 2 ^ (11 * bsPubL Mc J R eA eXi + 199) := by
  set c := Nat.clog 2 (Mc + J + R + 2) with hc
  set L := bsPubL Mc J R eA eXi with hLd
  have hLe : L = eA + eXi + c + 100 := rfl
  have hp := adaP_le_of_four_le h4
  have hchi := adaChi_le_of_four_le Mc J R eXi h4
  have hcap : Mc + J + R + 2 ≤ 2 ^ c := Nat.le_pow_clog (by norm_num) _
  have hL1 : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast (show 1 ≤ L by omega)
  have hE1 : (1 : ℝ) ≤ (2 : ℝ) ^ (eA + c) := one_le_pow₀ (by norm_num)
  have hP' : (adaP eA : ℝ) ≤ 2 ^ 12 * (L : ℝ) := by
    have : adaP eA ≤ 2 ^ 12 * L := by omega
    exact_mod_cast this
  have hX' : (adaChi Mc J R eA eXi : ℝ) ≤ 2 ^ 12 * (L : ℝ) := by
    have : adaChi Mc J R eA eXi ≤ 2 ^ 12 * L := by omega
    exact_mod_cast this
  have h0 : (0 : ℝ) ≤ (2 : ℝ) ^ (eA + c) := by positivity
  have hAb' : (2 : ℝ) ^ eA ≤ 2 ^ 21 * (2 : ℝ) ^ (eA + c) * (L : ℝ) := by
    have h1 : (2 : ℝ) ^ eA ≤ (2 : ℝ) ^ (eA + c) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h21 : (1 : ℝ) ≤ 2 ^ 21 * (L : ℝ) := by linarith
    have h2' : (2 : ℝ) ^ (eA + c) ≤ 2 ^ 21 * (2 : ℝ) ^ (eA + c) * (L : ℝ) :=
      calc (2 : ℝ) ^ (eA + c) ≤ (2 : ℝ) ^ (eA + c) * (2 ^ 21 * (L : ℝ)) :=
            le_mul_of_one_le_right h0 h21
        _ = 2 ^ 21 * (2 : ℝ) ^ (eA + c) * (L : ℝ) := by ring
    linarith
  have hK' : (J : ℝ) + R + 1 ≤ 2 ^ 13 * ((2 : ℝ) ^ (eA + c)) ^ 2 * (L : ℝ) ^ 3 := by
    have hJR : (J : ℝ) + R + 1 ≤ (2 : ℝ) ^ c := by
      have : J + R + 1 ≤ 2 ^ c := by omega
      exact_mod_cast this
    have h1 : (2 : ℝ) ^ c ≤ (2 : ℝ) ^ (eA + c) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h2' : (2 : ℝ) ^ (eA + c) ≤ ((2 : ℝ) ^ (eA + c)) ^ 2 :=
      calc (2 : ℝ) ^ (eA + c) ≤ (2 : ℝ) ^ (eA + c) * (2 : ℝ) ^ (eA + c) :=
            le_mul_of_one_le_right h0 hE1
        _ = ((2 : ℝ) ^ (eA + c)) ^ 2 := by ring
    have hL3 : (1 : ℝ) ≤ (L : ℝ) ^ 3 := one_le_pow₀ hL1
    have h00 : (0 : ℝ) ≤ ((2 : ℝ) ^ (eA + c)) ^ 2 := by positivity
    have h13 : (1 : ℝ) ≤ 2 ^ 13 * (L : ℝ) ^ 3 := by linarith
    have h3 : ((2 : ℝ) ^ (eA + c)) ^ 2 ≤ 2 ^ 13 * ((2 : ℝ) ^ (eA + c)) ^ 2 * (L : ℝ) ^ 3 :=
      calc ((2 : ℝ) ^ (eA + c)) ^ 2 ≤ ((2 : ℝ) ^ (eA + c)) ^ 2 * (2 ^ 13 * (L : ℝ) ^ 3) :=
            le_mul_of_one_le_right h00 h13
        _ = 2 ^ 13 * ((2 : ℝ) ^ (eA + c)) ^ 2 * (L : ℝ) ^ 3 := by ring
    linarith
  have h := adaN_le_of_bounds Mc J R h4 h2 hL1 hE1 hP' hX' hAb' hK'
  have e : ((2 : ℝ) ^ (eA + c)) ^ 2 = 2 ^ (2 * (eA + c)) := by rw [← pow_mul, mul_comm]
  rw [e] at h
  have hN : (adaBlockSizes Mc J R eA eXi).sum ≤ 2 ^ 199 * 2 ^ (2 * (eA + c)) * L ^ 7 := by
    exact_mod_cast h
  have h7 := bsP_pow7_lt L
  have hlt : 2 ^ (2 * (eA + c)) * L ^ 7 < 2 ^ (11 * L) := by
    calc 2 ^ (2 * (eA + c)) * L ^ 7 < 2 ^ (2 * (eA + c)) * 2 ^ (7 * L) :=
          Nat.mul_lt_mul_of_pos_left h7 (by positivity)
      _ = 2 ^ (2 * (eA + c) + 7 * L) := by rw [← pow_add]
      _ ≤ 2 ^ (11 * L) := Nat.pow_le_pow_right (by norm_num) (by omega)
  calc (adaBlockSizes Mc J R eA eXi).sum ≤ 2 ^ 199 * 2 ^ (2 * (eA + c)) * L ^ 7 := hN
    _ = 2 ^ 199 * (2 ^ (2 * (eA + c)) * L ^ 7) := by ring
    _ < 2 ^ 199 * 2 ^ (11 * L) := Nat.mul_lt_mul_of_pos_left hlt (by positivity)
    _ = 2 ^ (11 * L + 199) := by rw [← pow_add, add_comm]

/-- **P1: the B parameter record.** For all `eA ≥ 4`, `eXi ≥ 2` and every program containing
`bsPubTable` (and W5's `normQ`), `body_adaPub` evaluates on the encoded parameters
`encInts [Mc, J, R, eA, eXi]` to the parameter record `adaPubEnc (adaParams eA eXi Mc J R)`, whose
size is `≤ M`, for every value bound `M ≥ bsPubBound Mc J R eA eXi`. -/
theorem bsPub_eval {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2)
    (hq : NormQSpec prog M) {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi)
    (hM : bsPubBound Mc J R eA eXi ≤ M) :
    EvalsVal prog M [encInts [Mc, J, R, eA, eXi]] [] (.inl body_adaPub)
      (adaPubEnc (adaParams eA eXi Mc J R)) ∧ valSize (adaPubEnc (adaParams eA eXi Mc J R)) ≤ M := by
  have hpub : ∀ e ∈ adaPubTable, prog[e.1]? = some e.2 :=
    fun e he => hlib e (List.mem_append_right _ he)
  have get : ∀ (k : ℕ) (hk : k < adaPubTable.length),
      prog[(adaPubTable[k]).1]? = some (adaPubTable[k]).2 :=
    fun k hk => hpub _ (List.getElem_mem hk)
  have hlen : adaPubTable.length = 17 := rfl
  have hBL : BlkLib prog := ⟨get 5 (by omega), get 6 (by omega), get 8 (by omega),
    get 9 (by omega), get 15 (by omega), get 16 (by omega)⟩
  have hbA : prog[Idx.peBankA]? = some (eGet 3 (Expr.var 0)) :=
    hlib _ (List.mem_append_left _ List.mem_cons_self)
  have hbX : prog[Idx.peBankXi]? = some (eGet 4 (Expr.var 0)) :=
    hlib _ (List.mem_append_left _ (List.mem_cons_of_mem _ List.mem_cons_self))
  have hbM : prog[Idx.pbankM]? = some (eGet 0 (Expr.var 0)) :=
    hlib _ (List.mem_append_left _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _
      List.mem_cons_self)))
  have hbJ : prog[Idx.pbankJ]? = some (eGet 1 (Expr.var 0)) :=
    hlib _ (List.mem_append_left _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _
      (List.mem_cons_of_mem _ List.mem_cons_self))))
  have hbR : prog[Idx.pbankR]? = some (eGet 2 (Expr.var 0)) :=
    hlib _ (List.mem_append_left _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _
      (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)))))
  /- ### The side conditions of `bsP_core` at `L = bsPubL` -/
  set c := Nat.clog 2 (Mc + J + R + 2) with hc
  set L := bsPubL Mc J R eA eXi with hLd
  have hLe : L = eA + eXi + c + 100 := rfl
  have hM2 : 1048576 * (L * L) ≤ M := by
    have e : bsPubBound Mc J R eA eXi = 1048576 * (L * L) := by
      show 2 ^ 20 * L ^ 2 = _
      ring
    omega
  have hL100 : 100 ≤ L := by omega
  have hcap : Mc + J + R + 2 ≤ 2 ^ c := Nat.le_pow_clog (by norm_num) _
  have hcaps : Mc + J + R + 2 ≤ 2 ^ (5 * L + 14) :=
    hcap.trans (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hχ : adaChi Mc J R eA eXi ≤ 56 * L + 82 := by
    have := adaChi_le_of_four_le Mc J R eXi h4
    omega
  have hN := bsP_blockSizes_sum_lt (Mc := Mc) (J := J) (R := R) h4 h2
  /- ### The five parameters -/
  have hL2 : L ≤ L * L := Nat.le_mul_self L
  have hinM : valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) ≤ M := by
    have sM : Nat.size Mc ≤ c := Nat.size_le.2 (by omega)
    have sJ : Nat.size J ≤ c := Nat.size_le.2 (by omega)
    have sR : Nat.size R ≤ c := Nat.size_le.2 (by omega)
    have sA := size_le_self eA
    have sX := size_le_self eXi
    simp only [encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons, listSize_nil,
      valSize_int, bitLen_natCast]
    omega
  have ev : ∀ (k : ℕ) (n : ℕ),
      [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)][k]? = some (n : ℤ) →
      EvalsVal prog M [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]] []
        (.inl (eGet k (Expr.var 0))) (encN n) := by
    intro k n hk
    refine ev_get k (EvalsVal.var rfl) hinM ?_
    rw [List.getElem?_map, hk]
    rfl
  exact bsP_core (P := ⟨Mc, J, R, eA, eXi⟩) hBL (get 3 (by omega)) (get 4 (by omega))
    (get 7 (by omega)) (get 10 (by omega)) (get 11 (by omega)) (get 12 (by omega))
    (get 13 (by omega)) (get 14 (by omega)) hq hbA hbX hbM hbJ hbR (ev 3 eA rfl) (ev 4 eXi rfl)
    (ev 0 Mc rfl) (ev 1 J rfl) (ev 2 R rfl) hL100 hM2 (by omega) h4 (by omega) hcaps hχ hN

end F2e2e.BSpace
