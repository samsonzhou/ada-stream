import F2e2e.Spec

/-!
# B_space, layer M: the oracle big-step semantics (shared base of M1–M3)

Owner: C-SPACE (B_space layer M; area lead W4). Spec v3 §7 (draft `notes/spec_v3/parts/S7_BSpace.lean`)
runs the programs of `Theorem_B_space` on the locked machine of §3.1 with one change: under `stepO orc`,
`Expr.call oracleIdx a` evaluates `a` to `[sel, r, q]` (three integers) and returns the integer
`orc sel r q` in one step (the oracle's own working space is in no configuration). The proof chain is

`EvalsValO` (M1, the value judgment) —(M2, generic space theorem)→ a run of `evalO` (this file) —(M3,
17fc0802's machine bridge)→ a run of `stepO` within the bit bound (`RunsWithinBitsO`).

This file fixes the common base:
* `bsOracleIdx = 1000 = oracleIdx` (§7's `BSpace.oracleIdx`, `F2e2e/Spec.lean`; above every function
  index of the project's DSL programs, `0`–`999`), `bsOracleIdx_eq_oracleIdx`;
* `evalO orc` / `loopRunO orc`: verbatim copies of the Spec's big-step `eval` / `loopRun` (§3), with the one
  change of §7's `stepO`: `call bsOracleIdx a` does not look up a body: after `a ↦ va`, it answers
  `Val.int (orc sel r q)` when `va = [sel, r, q]` (and is stuck otherwise), with the argument and the answer
  live together (peak `base + valSize va + valSize answer`, as for a primitive operation);
* `RunsOnO`: the Spec's `RunsOn` for `evalO`, with the unread tape `rest` exposed (to thread the tape from
  run to run).
-/

namespace F2e2e.BSpace

/-- The reserved function index of the evaluation oracle (the value `1000` of Spec v3 §7's
`BSpace.oracleIdx`, `bsOracleIdx_eq_oracleIdx`; kept as a reducible literal so that `omega`/`decide` see it). -/
abbrev bsOracleIdx : ℕ := 1000

theorem bsOracleIdx_eq_oracleIdx : bsOracleIdx = oracleIdx := rfl

mutual
/-- The Spec's big-step `eval` (§3) with the evaluation oracle `orc`: verbatim, except that
`call bsOracleIdx a` evaluates `a` and answers `Val.int (orc sel r q)` on `[sel, r, q]` (stuck on any other
argument), with the argument and the answer live together. -/
def evalO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) : ℕ → ℕ → List Val → List Bool → Expr →
    Option (Val × ℕ × ℕ × List Bool)
  | 0, _, _, _, _ => none
  | fuel + 1, base, env, tape, e =>
    match e with
    | Expr.var i =>
        match env[i]? with
        | some v => some (v, 1, base + valSize v, tape)
        | none => none
    | Expr.lit z => some (Val.int z, 1 + bitLen z, base + valSize (Val.int z), tape)
    | Expr.nil => some (Val.list [], 1, base + valSize (Val.list []), tape)
    | Expr.coin =>
        match tape with
        | b :: rest =>
            some (Val.int (if b = true then 1 else 0), 1,
              base + valSize (Val.int (if b = true then 1 else 0)), rest)
        | [] => none
    | Expr.bin op a b =>
        match evalO orc prog fuel base env tape a with
        | none => none
        | some (va, ca, pa, ta) =>
          match evalO orc prog fuel (base + valSize va) env ta b with
          | none => none
          | some (vb, cb, pb, tb) =>
            match evalBin op va vb with
            | none => none
            | some (v, c) =>
              some (v, 1 + ca + cb + c,
                max (max pa pb) (base + valSize va + valSize vb + valSize v), tb)
    | Expr.un op a =>
        match evalO orc prog fuel base env tape a with
        | none => none
        | some (va, ca, pa, ta) =>
          match evalUn op va with
          | none => none
          | some (v, c) => some (v, 1 + ca + c, max pa (base + valSize va + valSize v), ta)
    | Expr.ite c t f =>
        match evalO orc prog fuel base env tape c with
        | some (Val.int z, cc, pc, tc) =>
          match evalO orc prog fuel base env tc (if z ≠ 0 then t else f) with
          | none => none
          | some (v, cv, pv, tv) => some (v, 1 + cc + cv, max pc pv, tv)
        | _ => none
    | Expr.letE a b =>
        match evalO orc prog fuel base env tape a with
        | none => none
        | some (va, ca, pa, ta) =>
          match evalO orc prog fuel (base + valSize va) (va :: env) ta b with
          | none => none
          | some (vb, cb, pb, tb) => some (vb, 1 + ca + cb, max pa pb, tb)
    | Expr.call i a =>
        match evalO orc prog fuel base env tape a with
        | none => none
        | some (va, ca, pa, ta) =>
          if i = bsOracleIdx then
            match va with
            | Val.list [Val.int sel, Val.int r, Val.int q] =>
                some (Val.int (orc sel r q), 2 + ca,
                  max pa (base + valSize va + valSize (Val.int (orc sel r q))), ta)
            | _ => none
          else
            match prog[i]? with
            | none => none
            | some body =>
              match evalO orc prog fuel (base + valSize va) [va] ta body with
              | none => none
              | some (vb, cb, pb, tb) => some (vb, 1 + ca + cb, max pa pb, tb)
    | Expr.loop i a =>
        match evalO orc prog fuel base env tape a with
        | none => none
        | some (va, ca, pa, ta) =>
          match loopRunO orc prog fuel base i va ta with
          | none => none
          | some (w, cw, pw, tw) => some (w, 1 + ca + cw, max pa pw, tw)

/-- The Spec's `loopRun` (§3) with the evaluation oracle `orc` (verbatim, with `evalO`). -/
def loopRunO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) :
    ℕ → ℕ → ℕ → Val → List Bool → Option (Val × ℕ × ℕ × List Bool)
  | 0, _, _, _, _ => none
  | fuel + 1, base, i, v, tape =>
    match prog[i]? with
    | none => none
    | some body =>
      match evalO orc prog fuel (base + valSize v) [v] tape body with
      | some (Val.list [Val.int flag, v'], cb, pb, tb) =>
        if flag = 0 then some (v', 1 + cb, pb, tb)
        else
          match loopRunO orc prog fuel base i v' tb with
          | none => none
          | some (w, cw, pw, tw) => some (w, 1 + cb + cw, max pb pw, tw)
      | _ => none
end

/-- The Spec's `RunsOn` (§3) for `evalO`, with the unread tape `rest` exposed: the program `prog` (entry
point: function `0`) with the oracle `orc` runs on `input` with the tape `tape`, halts with output `out`,
leaves exactly `rest` unread, with peak live space at most `S`. -/
def RunsOnO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (input : Val) (tape : List Bool) (out : Val)
    (rest : List Bool) (S : ℝ) : Prop :=
  ∃ (body : Expr) (fuel cost peak : ℕ), prog[0]? = some body ∧
    evalO orc prog fuel (valSize input) [input] tape body = some (out, cost, peak, rest) ∧
    (peak : ℝ) ≤ S

/-- `RunsOnO` is monotone in the bound. -/
theorem RunsOnO.mono {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {input : Val} {tape : List Bool}
    {out : Val} {rest : List Bool} {S S' : ℝ} (h : RunsOnO orc prog input tape out rest S)
    (hS : S ≤ S') : RunsOnO orc prog input tape out rest S' := by
  obtain ⟨body, fuel, cost, peak, h0, he, hp⟩ := h
  exact ⟨body, fuel, cost, peak, h0, he, hp.trans hS⟩

end F2e2e.BSpace
