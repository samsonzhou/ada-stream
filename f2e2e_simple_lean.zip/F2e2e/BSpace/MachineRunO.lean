import F2e2e.Cost.MachineSim
import F2e2e.Spec

/-!
# Runs of the oracle machine `stepO` (B_space layer M3; 17fc0802)

Oracle copies of `Cost/MachineRun.lean` and of the `RunAll` lemmas of `Cost/MachineSim.lean`:

* `stepNO_add`: `m + n` steps are `m` steps then `n` steps; `stepNO_one`.
* `RunAllO orc prog P c c'`: the oracle machine goes from `c` to `c'` and every configuration of the run (both
  ends included) satisfies `P`; composition (`trans`, `cons_step`, `snoc_step`), `single`, `mono`, `first`,
  `last`, and the frame bookkeeping `push`/`weaken` for the invariant `Machine.Within`.
-/

namespace F2e2e.BSpace.MachineO

open F2e2e.Machine

variable {orc : VOracle} {prog : List Expr}

theorem stepNO_zero (c : Conf) : stepNO orc prog 0 c = some c := rfl

theorem stepNO_add (m n : ℕ) (c : Conf) :
    stepNO orc prog (m + n) c = (stepNO orc prog m c).bind (stepNO orc prog n) := by
  induction m generalizing c with
  | zero => simp [stepNO]
  | succ m ih =>
    rw [show m + 1 + n = (m + n) + 1 by omega]
    simp only [stepNO]
    cases stepO orc prog c with
    | none => rfl
    | some c' => exact ih c'

theorem stepNO_one {c c' : Conf} (h : stepO orc prog c = some c') : stepNO orc prog 1 c = some c' := by
  simp [stepNO, h]

/-- The oracle machine goes from `c` to `c'`, and every configuration of the run (both ends included)
satisfies `P`. -/
def RunAllO (orc : VOracle) (prog : List Expr) (P : Conf → Prop) (c c' : Conf) : Prop :=
  ∃ n, stepNO orc prog n c = some c' ∧ ∀ k ≤ n, ∀ d, stepNO orc prog k c = some d → P d

namespace RunAllO

variable {P Q : Conf → Prop} {c c' c'' : Conf}

theorem refl (h : P c) : RunAllO orc prog P c c :=
  ⟨0, rfl, fun k hk d hd => by
    obtain rfl : k = 0 := by omega
    simp only [stepNO, Option.some.injEq] at hd
    exact hd ▸ h⟩

theorem first (h : RunAllO orc prog P c c') : P c := by
  obtain ⟨n, _, hall⟩ := h
  exact hall 0 (Nat.zero_le _) c rfl

theorem last (h : RunAllO orc prog P c c') : P c' := by
  obtain ⟨n, hn, hall⟩ := h
  exact hall n le_rfl c' hn

theorem steps (h : RunAllO orc prog P c c') : ∃ n, stepNO orc prog n c = some c' := by
  obtain ⟨n, hn, _⟩ := h
  exact ⟨n, hn⟩

theorem trans (h₁ : RunAllO orc prog P c c') (h₂ : RunAllO orc prog P c' c'') :
    RunAllO orc prog P c c'' := by
  obtain ⟨n₁, hn₁, hall₁⟩ := h₁
  obtain ⟨n₂, hn₂, hall₂⟩ := h₂
  refine ⟨n₁ + n₂, by rw [stepNO_add, hn₁]; exact hn₂, fun k hk d hd => ?_⟩
  by_cases hk1 : k ≤ n₁
  · exact hall₁ k hk1 d hd
  · obtain ⟨j, rfl⟩ : ∃ j, k = n₁ + j := ⟨k - n₁, by omega⟩
    rw [stepNO_add, hn₁] at hd
    exact hall₂ j (by omega) d hd

theorem single (hs : stepO orc prog c = some c') (hc : P c) (hc' : P c') : RunAllO orc prog P c c' :=
  ⟨1, stepNO_one hs, fun k hk d hd => by
    interval_cases k
    · simp only [stepNO, Option.some.injEq] at hd
      exact hd ▸ hc
    · rw [stepNO_one hs, Option.some.injEq] at hd
      exact hd ▸ hc'⟩

theorem cons_step (hs : stepO orc prog c = some c') (hc : P c) (h : RunAllO orc prog P c' c'') :
    RunAllO orc prog P c c'' :=
  (single hs hc h.first).trans h

theorem snoc_step (h : RunAllO orc prog P c c') (hs : stepO orc prog c' = some c'') (hc'' : P c'') :
    RunAllO orc prog P c c'' :=
  h.trans (single hs h.last hc'')

theorem mono (h : RunAllO orc prog P c c') (hPQ : ∀ d, P d → Q d) : RunAllO orc prog Q c c' := by
  obtain ⟨n, hn, hall⟩ := h
  exact ⟨n, hn, fun k hk d hd => hPQ d (hall k hk d hd)⟩

theorem push {K : List Frame} {f : Frame} {B B' : ℕ}
    (h : RunAllO orc prog (Within prog (f :: K) B) c c') (hB : B + frameBits prog f ≤ B') :
    RunAllO orc prog (Within prog K B') c c' :=
  h.mono fun _ hd => hd.push.mono hB

theorem weaken {K : List Frame} {B B' : ℕ}
    (h : RunAllO orc prog (Within prog K B) c c') (hB : B ≤ B') :
    RunAllO orc prog (Within prog K B') c c' :=
  h.mono fun _ hd => hd.mono hB

end RunAllO

end F2e2e.BSpace.MachineO
