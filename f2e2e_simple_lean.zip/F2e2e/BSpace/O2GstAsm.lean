import F2e2e.BSpace.O2GstLiftCalc
import F2e2e.BSpace.O2BridgeMain
import F2e2e.BSpace.MachineBridgeO

/-!
# B_space, route O2b: per-call GST + additive bridge (composition for the B programs)

Owner: O2B-GST (8cf19cc0), for the O2b technical lead 17fc0802. Composition of
* C-SPACE's per-call generic space theorem at the entry point (`runsOnO_of_evalsValF`, `ImplementsF.runsOnO`,
  `F2e2e/BSpace/O2GstF.lean`): an `EvalsValF` evaluation of the entry body at `(m, τ)` on an input `≤ m` runs
  under `evalO` within the peak `(exprDepth body + 3) · m + τ`, and
* 17fc0802's additive bridge (`O2B.runsWithinBitsO_add_of_runsOnO`, `F2e2e/BSpace/O2BridgeMain.lean`): a run
  within the peak `S` (and a rank certificate of the program, for the activation nesting) is a run of §7's oracle
  machine with every step charged at most `bridgeAdd prog (r 0) S` bits.

Main results (per run of a program with a rank certificate `RankOK prog r Kd`):
* `runsWithinBitsO_of_evalsValF`: an `EvalsValF` evaluation of the entry body at `(m, τ)`, input `≤ m`,
  consuming exactly `bits`, is a `RunsWithinBitsO` run on every tape `bits ++ rest`, leaving `rest`, within
  `bridgeAdd prog (r 0) ((exprDepth body + 3) · m + τ)` bits;
* `ImplementsF.runsWithinBitsO`: the bit-program form (every run `p.run tape = some (a, rest)`);
* `_le` versions into any real bound `Sb ≥ bridgeAdd …`, and the monotonicity `O2B.bridgeAdd_mono` of the
  bridge bound in the peak;
* for uniform-`M` evaluations (`EvalsValO`): `runsWithinBitsO_add_of_evalsValO_wt` (weight certificate: peak
  `w 0 · M`), `runsWithinBitsO_add_of_evalsValO` (ranks: peak `(r 0 + 1)(K + 3) · M`),
  `ImplementsO.runsWithinBitsO_add_wt`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

/-- The additive bridge bound is monotone in the peak. -/
theorem O2B.bridgeAdd_mono (prog : List Expr) (ρ : ℕ) {S S' : ℕ} (hS : S ≤ S') :
    O2B.bridgeAdd prog ρ S ≤ O2B.bridgeAdd prog ρ S' := by
  have hT : O2B.addTop prog ρ S ≤ O2B.addTop prog ρ S' := by
    unfold O2B.addTop
    have := Nat.mul_le_mul_left (2 * (F2e2e.Machine.progDepth prog + 1)) hS
    omega
  have hc := Nat.clog_mono_right 2
    (show 2 * O2B.addTop prog ρ S + 16 * (S + 1) + 66 ≤ 2 * O2B.addTop prog ρ S' + 16 * (S' + 1) + 66 by
      omega)
  unfold O2B.bridgeAdd
  omega

/-- **Per-call GST + additive bridge.** An `EvalsValF` evaluation of the entry body at `(m, τ)` on an input of
size `≤ m`, consuming exactly `bits`, is a run of the oracle machine on every tape `bits ++ rest`, leaving
`rest`, with every step charged at most `bridgeAdd prog (r 0) ((exprDepth body + 3) · m + τ)` bits. -/
theorem runsWithinBitsO_of_evalsValF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {Kd : ℕ}
    (hR : RankOK prog r Kd) {body : Expr} (h0 : prog[0]? = some body) {input out : Val}
    {bits : List Bool} {m τ : ℕ} (h : EvalsValF orc prog m τ [input] bits (.inl body) out)
    (hin : valSize input ≤ m) (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest
      ((O2B.bridgeAdd prog (r 0) ((exprDepth body + 3) * m + τ) : ℕ) : ℝ) :=
  O2B.runsWithinBitsO_add_of_runsOnO hR (runsOnO_of_evalsValF h0 h hin rest)

/-- **Per-call GST + additive bridge**, into any real bound `Sb ≥ bridgeAdd …`. -/
theorem runsWithinBitsO_of_evalsValF_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {Kd : ℕ}
    (hR : RankOK prog r Kd) {body : Expr} (h0 : prog[0]? = some body) {input out : Val}
    {bits : List Bool} {m τ : ℕ} (h : EvalsValF orc prog m τ [input] bits (.inl body) out)
    (hin : valSize input ≤ m) {Sb : ℝ}
    (hS : ((O2B.bridgeAdd prog (r 0) ((exprDepth body + 3) * m + τ) : ℕ) : ℝ) ≤ Sb) (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest Sb :=
  (runsWithinBitsO_of_evalsValF hR h0 h hin rest).mono hS

/-- **Per-call GST + additive bridge, bit-program form.** If the entry body implements `p` at `(m, τ)` on an
input of size `≤ m`, every run `p.run tape = some (a, rest)` is a run of the oracle machine on `tape` with output
`enc a`, leaving exactly `rest`, within `bridgeAdd prog (r 0) ((exprDepth body + 3) · m + τ)` bits. -/
theorem ImplementsF.runsWithinBitsO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {Kd : ℕ}
    (hR : RankOK prog r Kd) {body : Expr} (h0 : prog[0]? = some body) {input : Val} {α : Type}
    {enc : α → Val} {p : BitProg α} {m τ : ℕ} (h : ImplementsF orc prog m τ [input] body enc p)
    (hin : valSize input ≤ m) {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc prog input tape (enc a) rest
      ((O2B.bridgeAdd prog (r 0) ((exprDepth body + 3) * m + τ) : ℕ) : ℝ) :=
  O2B.runsWithinBitsO_add_of_runsOnO hR (ImplementsF.runsOnO h0 h hin hrun)

/-- **Per-call GST + additive bridge, bit-program form**, into any real bound `Sb ≥ bridgeAdd …`. -/
theorem ImplementsF.runsWithinBitsO_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {Kd : ℕ}
    (hR : RankOK prog r Kd) {body : Expr} (h0 : prog[0]? = some body) {input : Val} {α : Type}
    {enc : α → Val} {p : BitProg α} {m τ : ℕ} (h : ImplementsF orc prog m τ [input] body enc p)
    (hin : valSize input ≤ m) {Sb : ℝ}
    (hS : ((O2B.bridgeAdd prog (r 0) ((exprDepth body + 3) * m + τ) : ℕ) : ℝ) ≤ Sb)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc prog input tape (enc a) rest Sb :=
  (ImplementsF.runsWithinBitsO hR h0 h hin hrun).mono hS

/-! ## Uniform-`M` evaluations with the additive bridge -/

/-- **Uniform-`M` GST (weights) + additive bridge.** An `EvalsValO` evaluation of the entry body at the uniform
bound `M` (input `≤ M`, consuming exactly `bits`) with a weight certificate is a run of the oracle machine on every
tape `bits ++ rest`, leaving `rest`, within `bridgeAdd prog (r 0) (w 0 · M)` bits: the peak is the weight of the
entry point (the weighted length `Σ (exprDepth + 3)` of its deepest call chain) times `M`. -/
theorem runsWithinBitsO_add_of_evalsValO_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {Kd : ℕ} (hR : RankOK prog r Kd) {w : ℕ → ℕ} (hW : WeightOK prog w) {body : Expr}
    (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool} {M : ℕ}
    (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest ((O2B.bridgeAdd prog (r 0) (w 0 * M) : ℕ) : ℝ) := by
  obtain ⟨hw0, hc0⟩ := hW 0 body h0
  have hF := h.toF_wt hW (by simpa using hin) hc0
  have hS : (exprDepth body + 3) * M + (w 0 - (exprDepth body + 3)) * M = w 0 * M := by
    rw [← Nat.add_mul, Nat.add_sub_cancel' hw0]
  have := runsWithinBitsO_of_evalsValF hR h0 hF hin rest
  rwa [hS] at this

/-- **Uniform-`M` GST (ranks) + additive bridge**: the peak is `(r 0 + 1)(K + 3) · M` (the bound of the generic
space theorem of layer M2), with the additive bridge in place of the coarse one. -/
theorem runsWithinBitsO_add_of_evalsValO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K : ℕ}
    (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool}
    {M : ℕ} (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M)
    (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest
      ((O2B.bridgeAdd prog (r 0) ((r 0 + 1) * (K + 3) * M) : ℕ) : ℝ) :=
  runsWithinBitsO_add_of_evalsValO_wt hR (weightOK_of_rankOK hR) h0 h hin rest

/-- **Uniform-`M` GST (weights) + additive bridge, bit-program form.** -/
theorem ImplementsO.runsWithinBitsO_add_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {Kd : ℕ} (hR : RankOK prog r Kd) {w : ℕ → ℕ} (hW : WeightOK prog w) {body : Expr}
    (h0 : prog[0]? = some body) {input : Val} {α : Type} {enc : α → Val} {p : BitProg α} {M : ℕ}
    (h : ImplementsO orc prog M [input] body enc p) (hin : valSize input ≤ M) {tape rest : List Bool}
    {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc prog input tape (enc a) rest ((O2B.bridgeAdd prog (r 0) (w 0 * M) : ℕ) : ℝ) := by
  obtain ⟨bits, rfl, hb⟩ := bitProg_run_split hrun
  exact runsWithinBitsO_add_of_evalsValO_wt hR hW h0 (h bits a hb) hin rest

end F2e2e.BSpace
