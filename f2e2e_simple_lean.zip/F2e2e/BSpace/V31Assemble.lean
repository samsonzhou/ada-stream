import F2e2e.BSpace.Assemble

/-!
# B_space v3.1 (C-TOP): history-freeness for the B state encoding

The v3.1 assembly (`F-B1`, `F-B2`) is in `Assemble.lean` / `AssembleFinal.lean`. This file keeps the corollary of
`v31_states_histFree` for W2's state encoding `bsStateEnc` with B-ARCH's `v31h_enc` (`V31HistFree.lean`).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2

/-- **History-freeness for the B state encoding** (with B-ARCH's functional `StCorr`, `V31HistFree.lean`): the
implementation's state before round `t` is `v31h_enc A blocks (Algorithm 2's state after t requests)`. -/
theorem v31_states_enc {U : Type} {P2 : Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid)
    (τ0 : List Bool) (blocks : List (List ℕ)) (t : ℕ)
    (htot : (threadRun (adaInit A) (asmRound A (castSample hN s) reqs) τ0 t).isSome) :
    threadStates (bsStateEnc blocks) (adaInit A) (asmRound A (castSample hN s) reqs) τ0 t =
      V31.v31h_enc A blocks (asmSpecState P2 s reqs τ0 t) :=
  v31_states_histFree hP hN s reqs hvalid τ0 (V31.v31h_archOf A) (fun _ _ h => V31.v31h_archOf_eq h)
    (bsStateEnc blocks) t htot

end F2e2e.BSpace
