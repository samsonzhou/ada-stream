import F2e2e.BSpace.DslEvalsInner

/-!
# B_space, D2: `bsEvals` (key 910), the query table of a request through the evaluation oracle

Owner: 1beb339b (D2; area lead W4). Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §D (D2).

* `bsE_outer_run`: the outer loop (key 911) over the blocks, each block by the inner loop (key 912,
  `bsE_inner_run`, `F2e2e/BSpace/DslEvalsInner.lean`);
* **`bsEvals_eval`**: on `[q, blocks]` (the blocks of record codes, as stored in the B state), `bsEvals`
  returns `encVals (evalsOf orc q blocks)`, the grid indices `(orc 0 r (q+1) + 1) div 2` of all records,
  block by block (`F2e2e/BSpace/DslEvalsMath.lean`), deterministically, with every value at most
  `|blocks| + |result| + 2q + 64`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-- **The outer loop of `bsEvals`** (key 911): from `[restB, accB, q + 1]` the iterations return the blocks
of indices computed so far (`accB` reversed) followed by the blocks of indices of the blocks of `restB`;
every value is at most `|restB| + |result| + q + 24`. -/
theorem bsE_outer_run {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} (hlib : BsEvalsLib prog)
    (q : ℕ) : ∀ restB accB : List (List ℕ),
      (∀ blk ∈ restB, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) →
      valSize (Val.list (restB.map (encL encN))) +
          valSize (Val.list ((accB.reverse ++ restB.map (List.map (bsE_g orc q))).map (encL encN))) +
          q + 24 ≤ M →
      EvalsValO orc prog M [] [] (.inr (bsE_outerKey, bsE_encOuter q restB accB))
        (Val.list ((accB.reverse ++ restB.map (List.map (bsE_g orc q))).map (encL encN)))
  | [], accB, _, hM => by
    have hQ := bsE_vsQ q
    simp only [valSize_int] at hQ
    have hT : (accB.reverse ++ ([] : List (List ℕ)).map (List.map (bsE_g orc q))).map (encL encN) =
        (accB.map (encL encN)).reverse := by simp
    rw [hT]
    rw [hT] at hM
    simp only [valSize_list, listSize_nil, listSize_reverse, List.map_nil] at hM
    refine EvalsValO.stop hlib.outer ?_
    unfold body_bsEvalsOuter bsE_encOuter
    simp only [List.map_nil]
    refine bsC.ite_true (bsC.isNil_nil (EvalsValO.head (EvalsValO.var rfl)
      (by simp only [valSize_list, listSize_nil]; omega)) (by omega)) one_ne_zero ?_
    refine EvalsValO.pair (EvalsValO.lit (by simp only [valSize_int, bitLen_zero]; omega))
      (bsE_rev hlib.rev (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (by simp only [valSize_list]; omega)) (by simp only [valSize_list]; omega)) ?_
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, listSize_reverse, bitLen_zero]
    omega
  | blk :: restB, accB, hO, hM => by
    have hQ := bsE_vsQ q
    simp only [valSize_int] at hQ
    have hid : (List.map (bsE_g orc q) blk :: accB).reverse ++ restB.map (List.map (bsE_g orc q)) =
        accB.reverse ++ (blk :: restB).map (List.map (bsE_g orc q)) := by simp
    have hM' := hM
    simp only [encL, valSize_list, listSize_cons, listSize_append, listSize_reverse, List.map_cons,
      List.map_append, List.map_reverse] at hM'
    -- the inner loop on the first block
    have hin := bsE_inner_run (M := M) hlib q blk [] (hO blk List.mem_cons_self) (by
      simp only [encL, valSize_list, List.reverse_nil, List.nil_append]
      omega)
    simp only [List.reverse_nil, List.nil_append] at hin
    -- the remaining blocks
    have ih := bsE_outer_run (M := M) hlib q restB (List.map (bsE_g orc q) blk :: accB)
      (fun b hb => hO b (List.mem_cons_of_mem _ hb)) (by
        rw [hid]
        simp only [encL, valSize_list, listSize_cons, listSize_append, listSize_reverse,
          List.map_cons, List.map_append, List.map_reverse]
        omega)
    rw [hid] at ih
    -- one iteration
    have hb : EvalsValO orc prog M [bsE_encOuter q (blk :: restB) accB] [] (.inl body_bsEvalsOuter)
        (Val.list [Val.int 1, bsE_encOuter q restB (List.map (bsE_g orc q) blk :: accB)]) := by
      unfold body_bsEvalsOuter bsE_encOuter
      simp only [List.map_cons]
      have h1 : valSize (Val.list (encL encN blk :: List.map (encL encN) restB)) ≤ M := by
        simp only [encL, valSize_list, listSize_cons]; omega
      have h2 : valSize (Val.list [Val.list (List.map (encL encN) accB), Val.int ((q : ℤ) + 1)]) ≤ M := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h3 : valSize (Val.list [Val.int ((q : ℤ) + 1)]) ≤ M := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h4 : valSize (Val.int ((q : ℤ) + 1)) ≤ M := by simp only [valSize_int]; omega
      refine bsC.ite_false (bsC.isNil_cons (EvalsValO.head (EvalsValO.var rfl) h1) (by omega)) rfl ?_
      refine EvalsValO.letE (EvalsValO.loop (bsC.triple
        (EvalsValO.head (EvalsValO.head (EvalsValO.var rfl) h1) (by simp only [encL, valSize_list]; omega))
        (EvalsValO.nil (by simp only [valSize_list, listSize_nil]; omega))
        (EvalsValO.head (EvalsValO.tail (EvalsValO.tail (EvalsValO.var rfl) h2) h3) h4)
        (by simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)) hin) ?_
      refine EvalsValO.pair (EvalsValO.lit (by simp only [valSize_int, bitLen_one]; omega))
        (bsC.triple (EvalsValO.tail (EvalsValO.head (EvalsValO.var rfl) h1)
            (by simp only [valSize_list]; omega))
          (EvalsValO.cons (EvalsValO.var rfl) (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl) h2)
              (by simp only [valSize_list]; omega))
            (by simp only [encL, valSize_list, listSize_cons]; omega))
          (EvalsValO.head (EvalsValO.tail (EvalsValO.tail (EvalsValO.var rfl) h2) h3) h4)
          (by simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)) ?_
      simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]
      omega
    exact EvalsValO.cast_bits (EvalsValO.cont hlib.outer hb one_ne_zero ih) (by simp)

/-- **D2: the query table of a request through the evaluation oracle.** On `[q, blocks]` (the blocks of
record codes, as stored in the B state), `bsEvals` returns `encVals (evalsOf orc q blocks)`: for every code
`r` of every block the grid index `(orc 0 r (q+1) + 1) div 2`, one oracle call per code, reading no fair
bits; every value is at most `|blocks| + |result| + 2q + 64`. -/
theorem bsEvals_eval {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) {q : ℕ} {blocks : List (List ℕ)}
    (hO : ∀ blk ∈ blocks, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1))
    (hM : valSize (Val.list (blocks.map (encL encN))) + valSize (C.Impl.encVals (evalsOf orc q blocks)) +
      2 * q + 64 ≤ M) :
    EvalsValO orc prog M [Val.list [encN q, Val.list (blocks.map (encL encN))]] []
      (.inl body_bsEvals) (C.Impl.encVals (evalsOf orc q blocks)) := by
  have hL := BsEvalsLib.of_table hlib
  have hQ := bsE_vsQ q
  have hN := bsE_vsN q
  simp only [valSize_int] at hQ
  simp only [encN, valSize_int] at hN
  rw [bsE_encVals_eq, evalsOf_eq_map] at hM ⊢
  have hout := bsE_outer_run (M := M) hL q blocks [] hO (by
    simp only [List.reverse_nil, List.nil_append]
    omega)
  simp only [List.reverse_nil, List.nil_append] at hout
  unfold body_bsEvals
  have hI : valSize (Val.list [Val.list (blocks.map (encL encN))]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  refine EvalsValO.cast_bits (EvalsValO.loop (bsC.triple
    (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl) hI) (by omega))
    (EvalsValO.nil (by simp only [valSize_list, listSize_nil]; omega))
    (bsC.add (EvalsValO.head (EvalsValO.var rfl) (by simp only [valSize_int]; omega))
      (EvalsValO.lit (by simp only [valSize_int, bitLen_one]; omega)) (by simp only [valSize_int]; omega))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil] at hM ⊢; omega)) hout) (by simp)

end F2e2e.BSpace
