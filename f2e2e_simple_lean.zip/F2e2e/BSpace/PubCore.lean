import F2e2e.C.Impl.AdaPub

/-!
# B_space, layer P: the parameter record with a quadratic value bound (`bsP_core`)

Owner: W3 (4a7299ed), for W2 (a2ff64c3) / B-ARCH (S3 (iii)). `bsP_core` is a verbatim copy of W2's
`adaPub_core` (`F2e2e/C/Impl/AdaPubCore.lean`, which stays untouched on the C side) with ONE change: the
hypothesis `hML : 2 ^ 37 * L ^ 3 ≤ M` is replaced by `hM2 : 1048576 * (L * L) ≤ M` (= `2^20 · L²`), which
is all the proof uses (the original derived exactly this `hM2` from `hML`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Space F2e2e.C.Top F2e2e.C.Impl
  F2e2e.C.Impl.W6 F2e2e.C.Impl.AP

set_option linter.unusedSimpArgs false

set_option maxHeartbeats 1000000 in
/-- **Correctness of `body_adaPub`** (copy of W2's `adaPub_core`, `F2e2e/C/Impl/AdaPubCore.lean`) with
the value-bound hypothesis `2^20 · L² ≤ M` instead of `2^37 · L³ ≤ M`. -/
theorem bsP_core {prog : List Expr} {M : ℕ} {P : StreamParams} {eA eXi mM J R L : ℕ}
    (hBL : BlkLib prog) (h650 : prog[Cost.Idx.apPStep]? = some body_apPStep)
    (h651 : prog[Cost.Idx.apTStep]? = some body_apTStep)
    (h654 : prog[Cost.Idx.apBStep]? = some body_apBStep)
    (h657 : prog[Cost.Idx.apSamp]? = some body_apSamp)
    (hpw : prog[Cost.Idx.pow2]? = some body_pow2)
    (hpwS : prog[Cost.Idx.pow2Step]? = some body_pow2Step)
    (hcl : prog[Cost.Idx.clog2]? = some body_clog2)
    (hclS : prog[Cost.Idx.clog2Step]? = some body_clog2Step)
    (hq : NormQSpec prog M) {bA bX bM bJ bR : Expr}
    (hbA : prog[Idx.peBankA]? = some bA) (hbX : prog[Idx.peBankXi]? = some bX)
    (hbM : prog[Idx.pbankM]? = some bM) (hbJ : prog[Idx.pbankJ]? = some bJ)
    (hbR : prog[Idx.pbankR]? = some bR)
    (eA_ev : EvalsVal prog M [encStreamParams P] [] (.inl bA) (encN eA))
    (eX_ev : EvalsVal prog M [encStreamParams P] [] (.inl bX) (encN eXi))
    (eM_ev : EvalsVal prog M [encStreamParams P] [] (.inl bM) (encN mM))
    (eJ_ev : EvalsVal prog M [encStreamParams P] [] (.inl bJ) (encN J))
    (eR_ev : EvalsVal prog M [encStreamParams P] [] (.inl bR) (encN R))
    (hL100 : 100 ≤ L) (hM2 : 1048576 * (L * L) ≤ M) (heA6 : eA ≤ 6 * L) (heA4 : 4 ≤ eA)
    (heX : eXi ≤ 3 * L) (hcaps : mM + J + R + 2 ≤ 2 ^ (5 * L + 14))
    (hχ : adaChi mM J R eA eXi ≤ 56 * L + 82)
    (hN : (adaBlockSizes mM J R eA eXi).sum < 2 ^ (11 * L + 199)) :
    EvalsVal prog M [encStreamParams P] [] (.inl body_adaPub)
      (adaPubEnc (adaParams eA eXi mM J R)) ∧
    valSize (adaPubEnc (adaParams eA eXi mM J R)) ≤ M := by
  /- ### Numerical facts -/
  have hp2 : 2 ≤ adaP eA := two_le_adaP eA
  have hp : adaP eA ≤ 2 * eA + 4 := adaP_le_of_four_le heA4
  have hLL : 100 * L ≤ L * L := Nat.mul_le_mul_right L hL100
  have hW : ∀ x : ℕ, Nat.size x ≤ 128 * L + 300 → x < 2 ^ (1024 * L) :=
    fun x hx => Nat.size_le.1 (by omega)
  have hvs : ∀ x : ℕ, Nat.size x ≤ 128 * L + 300 → Nat.size x + 1 ≤ M := by
    intro x hx; omega
  have hSp : ∀ k : ℕ, k ≤ 128 * L + 300 → S_pow2 k ≤ M := by
    intro k hk; have := size_le_self' k; unfold S_pow2; omega
  have hSc : ∀ m : ℕ, Nat.size m ≤ 128 * L + 300 → S_clog2 m ≤ M := by
    intro m hm; unfold S_clog2; omega
  have hlit : ∀ (env : List Val) (n : ℕ), n < 2 ^ 30 →
      EvalsVal prog M env [] (.inl (Expr.lit (n : ℤ))) (encN n) :=
    fun env n hn => evN_lit n (by have := size_le_of_lt_pow hn; omega)
  /- ### Sizes -/
  have sEA : Nat.size eA ≤ 6 * L := (size_le_self' eA).trans heA6
  have sP : Nat.size (adaP eA) ≤ 12 * L + 4 := (size_le_self' _).trans (by omega)
  have sP1 : Nat.size (adaP eA + 1) ≤ 12 * L + 5 := (size_succ_le _).trans (by omega)
  have se2 : Nat.size (2 ^ eA) = eA + 1 := size_two_pow eA
  have se2x : Nat.size (2 ^ eXi) = eXi + 1 := size_two_pow eXi
  have hcapsS : Nat.size (mM + R + J + 2) ≤ 5 * L + 15 := Nat.size_le.2 (by rw [pow_succ]; omega)
  have sM : Nat.size mM ≤ 5 * L + 15 := (size_le_of_le (show mM ≤ mM + R + J + 2 by omega)).trans hcapsS
  have sJ : Nat.size J ≤ 5 * L + 15 := (size_le_of_le (show J ≤ mM + R + J + 2 by omega)).trans hcapsS
  have sR : Nat.size R ≤ 5 * L + 15 := (size_le_of_le (show R ≤ mM + R + J + 2 by omega)).trans hcapsS
  have h384 : Nat.size 384 ≤ 9 := Nat.size_le.2 (by norm_num)
  have hA1 : 1 ≤ tmA eA := tmA_pos eA
  have sA : Nat.size (tmA eA) ≤ 36 * L + 30 := by
    have e : tmA eA = 384 * adaP eA * adaP eA * (2 ^ eA * 2 ^ eA) := rfl
    rw [e]
    have h1 := size_mul_le 384 (adaP eA)
    have h2 := size_mul_le (384 * adaP eA) (adaP eA)
    have h3 := size_mul_le (2 ^ eA) (2 ^ eA)
    have h4 := size_mul_le (384 * adaP eA * adaP eA) (2 ^ eA * 2 ^ eA)
    omega
  have hsT := adaTmaxList_sum_le eA
  have ssT : Nat.size (adaTmaxList eA).sum ≤ 48 * L + 34 :=
    (size_le_of_le hsT).trans ((size_mul_le _ _).trans (by omega))
  have sQ : Nat.size (adaQ mM J R eA) ≤ 66 * L + 70 := by
    have e : adaQ mM J R eA = 100 * (adaP eA + 1) * (mM + R + J + 2 + (adaTmaxList eA).sum) := rfl
    rw [e]
    have h100 : Nat.size 100 ≤ 7 := Nat.size_le.2 (by norm_num)
    have h1 := size_mul_le 100 (adaP eA + 1)
    have h3 := size_add_le2 (mM + R + J + 2) (adaTmaxList eA).sum
    have h4 := size_mul_le (100 * (adaP eA + 1)) (mM + R + J + 2 + (adaTmaxList eA).sum)
    omega
  have hQ1 : 1 ≤ adaQ mM J R eA := adaQ_pos mM J R eA
  have hχ1 : 1 ≤ adaChi mM J R eA eXi := adaChi_pos mM J R eA eXi
  have sχ : Nat.size (adaChi mM J R eA eXi) ≤ 56 * L + 82 := (size_le_self' _).trans hχ
  have shI : Nat.size (adaHInv eA) ≤ 18 * L + 15 := by
    have e : adaHInv eA = 512 * adaP eA * 2 ^ eA := rfl
    rw [e]
    have h512 : Nat.size 512 ≤ 10 := Nat.size_le.2 (by norm_num)
    have h1 := size_mul_le 512 (adaP eA)
    have h2 := size_mul_le (512 * adaP eA) (2 ^ eA)
    omega
  have h2e20 : Nat.size 1048576 ≤ 21 := Nat.size_le.2 (by norm_num)
  have h4096 : Nat.size 4096 ≤ 13 := Nat.size_le.2 (by norm_num)
  have sK1 : Nat.size (1048576 * adaChi mM J R eA eXi * adaHInv eA) ≤ 74 * L + 118 := by
    have h1 := size_mul_le 1048576 (adaChi mM J R eA eXi)
    have h2 := size_mul_le (1048576 * adaChi mM J R eA eXi) (adaHInv eA)
    omega
  have sK2 : Nat.size (4096 * adaChi mM J R eA eXi * (adaHInv eA * adaHInv eA)) ≤ 92 * L + 125 := by
    have h1 := size_mul_le 4096 (adaChi mM J R eA eXi)
    have h2 := size_mul_le (adaHInv eA) (adaHInv eA)
    have h3 := size_mul_le (4096 * adaChi mM J R eA eXi) (adaHInv eA * adaHInv eA)
    omega
  have sdp : Nat.size (2 ^ (eA + 11) * adaP eA) ≤ 18 * L + 16 := by
    have h1 := size_mul_le (2 ^ (eA + 11)) (adaP eA)
    have h2 := size_two_pow (eA + 11)
    omega
  have sZd : Nat.size (zdQ mM J R eA eXi) ≤ 100 * L + 120 := by
    have e : zdQ mM J R eA eXi =
        98304000 * adaP eA * (adaP eA + 1) * adaQ mM J R eA * (2 ^ eA * 2 ^ eXi) := rfl
    rw [e]
    have hc : Nat.size 98304000 ≤ 27 := Nat.size_le.2 (by norm_num)
    have h1 := size_mul_le 98304000 (adaP eA)
    have h2 := size_mul_le (98304000 * adaP eA) (adaP eA + 1)
    have h3 := size_mul_le (98304000 * adaP eA * (adaP eA + 1)) (adaQ mM J R eA)
    have h4 := size_mul_le (2 ^ eA) (2 ^ eXi)
    have h5 := size_mul_le (98304000 * adaP eA * (adaP eA + 1) * adaQ mM J R eA) (2 ^ eA * 2 ^ eXi)
    omega
  have hZd1 : 1 ≤ zdQ mM J R eA eXi := zdQ_pos mM J R eA eXi
  have h16 : Nat.size 16 ≤ 5 := Nat.size_le.2 (by norm_num)
  have hB0 : adaB0 mM J R eA eXi ≤ 100 * L + 125 := by
    rw [adaB0_eq]
    have h1 := clog2_le_size (16 * zdQ mM J R eA eXi)
    have h2 := size_mul_le 16 (zdQ mM J R eA eXi)
    omega
  have sB0 : Nat.size (adaB0 mM J R eA eXi) ≤ 100 * L + 125 := (size_le_self' _).trans hB0
  -- the blocks
  set nb : ℕ → ℕ := fun j => nbV j (tmA eA) (adaP eA) J R (adaChi mM J R eA eXi)
    (1048576 * adaChi mM J R eA eXi * adaHInv eA)
    (4096 * adaChi mM J R eA eXi * (adaHInv eA * adaHInv eA)) (2 ^ (eA + 11) * adaP eA)
    with hnbd
  have hBl : (List.range (adaP eA + 1)).map nb = adaBlockSizes mM J R eA eXi := by
    unfold adaBlockSizes
    apply List.map_congr_left
    intro j hj
    rw [List.mem_range] at hj
    exact nbV_ada mM J R eA eXi j (by omega)
  have hnbN : ∀ j, j ≤ adaP eA → nb j < 2 ^ (11 * L + 199) := by
    intro j hj
    have hmem : nb j ∈ adaBlockSizes mM J R eA eXi := by
      rw [← hBl]; exact List.mem_map.2 ⟨j, List.mem_range.2 (by omega), rfl⟩
    exact lt_of_le_of_lt (le_sum_of_mem' hmem) hN
  have hmaxN : adaMaxN mM J R eA eXi < 2 ^ (11 * L + 199) := by
    unfold adaMaxN
    rw [foldl_max_zero]
    exact foldr_max_lt (Nat.two_pow_pos _) (fun x hx => lt_of_le_of_lt (le_sum_of_mem' hx) hN)
  have smaxN : Nat.size (adaMaxN mM J R eA eXi) ≤ 11 * L + 199 := size_le_of_lt_pow hmaxN
  have spp1χ : Nat.size (adaP eA * (adaP eA + 1) * adaChi mM J R eA eXi) ≤ 80 * L + 91 := by
    have h1 := size_mul_le (adaP eA) (adaP eA + 1)
    have h2 := size_mul_le (adaP eA * (adaP eA + 1)) (adaChi mM J R eA eXi)
    omega
  have hqA : adaQA mM J R eA eXi ≤ 86 * L + 230 := by
    unfold adaQA
    have h1 := clog2_le_size (adaP eA * (adaP eA + 1) * adaChi mM J R eA eXi)
    have h3 := clog2_le_size (adaMaxN mM J R eA eXi)
    exact max_le (by omega) (by omega)
  have sqA : Nat.size (adaQA mM J R eA eXi) ≤ 86 * L + 230 := (size_le_self' _).trans hqA
  have sq2 : Nat.size (2 ^ adaQA mM J R eA eXi) ≤ 86 * L + 231 := by
    rw [size_two_pow]; omega
  have smK : ∀ κ, Nat.size (mK mM J R eA eXi κ) ≤ 74 * L + 103 := by
    have h32768 : Nat.size 32768 ≤ 16 := Nat.size_le.2 (by norm_num)
    have h16384 : Nat.size 16384 ≤ 15 := Nat.size_le.2 (by norm_num)
    have h256 : Nat.size 256 ≤ 9 := Nat.size_le.2 (by norm_num)
    have h128 : Nat.size 128 ≤ 8 := Nat.size_le.2 (by norm_num)
    have h64 : Nat.size 64 ≤ 7 := Nat.size_le.2 (by norm_num)
    intro κ
    cases κ <;> simp only [mK]
    · have h1 := size_mul_le 32768 (adaP eA)
      have h2 := size_mul_le (32768 * adaP eA) (2 ^ eA)
      have h3 := size_mul_le (32768 * adaP eA * 2 ^ eA) (adaChi mM J R eA eXi)
      omega
    · have h1 := size_mul_le 16384 (adaP eA)
      have h2 := size_mul_le (16384 * adaP eA) (2 ^ eA)
      have h3 := size_mul_le (16384 * adaP eA * 2 ^ eA) (adaChi mM J R eA eXi)
      omega
    · have h1 := size_mul_le 256 (adaChi mM J R eA eXi)
      have h2 := size_mul_le (256 * adaChi mM J R eA eXi) (2 ^ eA)
      omega
    · have h1 := size_mul_le 128 (adaChi mM J R eA eXi)
      have h2 := size_mul_le (128 * adaChi mM J R eA eXi) (2 ^ eA)
      omega
    · have h1 := size_mul_le 64 (adaChi mM J R eA eXi)
      have h2 := size_mul_le (64 * adaChi mM J R eA eXi) (2 ^ eA)
      omega
  have hsamp : ∀ κ, valSize (encL encN (sampV (2 ^ adaQA mM J R eA eXi) (mK mM J R eA eXi κ)
      (adaB0 mM J R eA eXi) (zdQ mM J R eA eXi))) ≤ 20 * (1024 * L) + 80 := fun κ =>
    valSize_sampV_le (mK_pos mM J R eA eXi κ) (hW _ (by omega)) (hW _ (by have := smK κ; omega))
      (hW _ (by omega)) (hW _ (by omega))
  /- ### The size of the record -/
  have hrec : valSize (adaPubEnc (adaParams eA eXi mM J R)) ≤ M := by
    rw [adaPubEnc_adaParams]
    have hBs : valSize (encL encN (adaBlockSizes mM J R eA eXi)) ≤
        1 + (adaP eA + 1) * (11 * L + 201) := by
      have h := valSize_encL_le encN (adaBlockSizes mM J R eA eXi) (11 * L + 200) (fun x hx => by
        rw [valSize_encN]
        have := size_le_of_lt_pow (lt_of_le_of_lt (le_sum_of_mem' hx) hN)
        omega)
      rwa [adaBlockSizes_length] at h
    have hTs : valSize (encL encN (adaTmaxList eA)) ≤ 1 + adaP eA * (36 * L + 32) := by
      have h := valSize_encL_le encN (adaTmaxList eA) (36 * L + 31) (fun x hx => by
        rw [valSize_encN]
        have := (size_le_of_le (mem_adaTmaxList_le hx)).trans sA
        omega)
      rwa [adaTmaxList_length] at h
    have hpos1 : 0 < 8 * adaP eA * 2 ^ eA := Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega))
      (Nat.two_pow_pos _)
    have hpos2 : 0 < 2 * 2 ^ eA := Nat.mul_pos (by norm_num) (Nat.two_pow_pos _)
    have hpos3 : 0 < 128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi :=
      Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (Nat.two_pow_pos _))
        (Nat.two_pow_pos _)
    have h8 : Nat.size 8 ≤ 4 := Nat.size_le.2 (by norm_num)
    have h128 : Nat.size 128 ≤ 8 := Nat.size_le.2 (by norm_num)
    have sb1 : Nat.size (8 * adaP eA * 2 ^ eA) ≤ 18 * L + 9 := by
      have h1 := size_mul_le 8 (adaP eA)
      have h2 := size_mul_le (8 * adaP eA) (2 ^ eA)
      omega
    have sb2 : Nat.size (2 * 2 ^ eA) ≤ 6 * L + 3 := by
      have h1 := size_mul_le 2 (2 ^ eA)
      have : Nat.size 2 ≤ 2 := Nat.size_le.2 (by norm_num)
      omega
    have sb3 : Nat.size (128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi) ≤ 104 * L + 245 := by
      have h1 := size_mul_le 128 (adaP eA)
      have h2 := size_mul_le (128 * adaP eA) (2 ^ eA)
      have h3 := size_mul_le (128 * adaP eA * 2 ^ eA) (2 ^ adaQA mM J R eA eXi)
      omega
    have b1 : bitLen (1 : ℤ) = 1 := bitLen_one
    have q1 : valSize (encQ (((1 : ℤ) : ℚ) / (((8 * adaP eA * 2 ^ eA : ℕ) : ℤ) : ℚ))) ≤
        18 * L + 15 :=
      (valSize_encQ_le (a := 1) (b := 8 * adaP eA * 2 ^ eA) (by norm_num) hpos1).trans
        (by rw [b1]; omega)
    have q2 : valSize (encQ (((1 : ℤ) : ℚ) / (((2 * 2 ^ eA : ℕ) : ℤ) : ℚ))) ≤ 6 * L + 9 :=
      (valSize_encQ_le (a := 1) (b := 2 * 2 ^ eA) (by norm_num) hpos2).trans (by rw [b1]; omega)
    have q3 : valSize (encQ (((1 : ℤ) : ℚ) /
        (((128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi : ℕ) : ℤ) : ℚ))) ≤ 104 * L + 251 :=
      (valSize_encQ_le (a := 1) (b := 128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi)
        (by norm_num) hpos3).trans (by rw [b1]; omega)
    have s1T : Nat.size (1 + (adaTmaxList eA).sum) ≤ 48 * L + 36 :=
      (size_add_le2 _ _).trans (by simp; omega)
    exact rec_size_le hL100 hM2 (by omega : adaP eA ≤ 12 * L + 4)
      (by rw [valSize_encN]; omega) hBs hTs (by rw [valSize_encN]; omega)
      (by rw [valSize_encN]; omega) (by rw [valSize_encN]; omega) (by rw [valSize_encN]; omega)
      (by rw [valSize_encN]; omega) (by rw [valSize_encN]; omega) q1 q2 q3
      (valSize_list5_le (hsamp _) (hsamp _) (hsamp _) (hsamp _) (hsamp _))
  refine ⟨?_, hrec⟩
  /- ### The evaluation -/
  unfold body_adaPub
  -- W1's parameters
  refine ev_letE (ev_call hbA (EvalsVal.var rfl) eA_ev) ?_
  refine ev_letE (ev_call hbX (EvalsVal.var rfl) eX_ev) ?_
  refine ev_letE (ev_call hbM (EvalsVal.var rfl) eM_ev) ?_
  refine ev_letE (ev_call hbJ (EvalsVal.var rfl) eJ_ev) ?_
  refine ev_letE (ev_call hbR (EvalsVal.var rfl) eR_ev) ?_
  -- 2^eA, 2^(eA+3)
  refine ev_letE (pow2_ev hpw hpwS (EvalsVal.var rfl) (hSp _ (by omega))) ?_
  refine ev_letE (pow2_ev hpw hpwS (evN_add (EvalsVal.var rfl) (hlit _ 3 (by norm_num))
    (hvs _ ((size_add_le2 _ _).trans (by have := size_le_of_lt_pow (show 3 < 2 ^ 2 by norm_num); omega))))
    (hSp _ (by omega))) ?_
  -- p
  obtain ⟨outP, houtP, hloopP⟩ := apP_loop (prog := prog) (M := M) h650 eA (by omega) 2
    ⟨le_rfl, hp2⟩
  subst houtP
  refine ev_letE (ev_loop_ap ?_ hloopP) ?_
  · refine ev_list (.cons (hlit _ 2 (by norm_num)) (.cons (ev_cast (hlit _ 2 (by norm_num))
      (by norm_num)) (.cons (EvalsVal.var rfl) .nil))) ?_
    have := size_le_of_lt_pow (show 2 < 2 ^ 2 by norm_num)
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, size_two_pow]
    omega
  -- A = tmA eA
  have hAe : 384 * adaP eA * adaP eA * 2 ^ eA * 2 ^ eA = tmA eA := by unfold tmA; ring
  refine ev_letE (ev_cast (evN_mul (evN_mul (evN_mul (evN_mul (hlit _ 384 (by norm_num))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans
      (by have := size_mul_le 384 (adaP eA); omega))))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans
      (by have := size_mul_le 384 (adaP eA); have := size_mul_le (384 * adaP eA) (adaP eA); omega))))
    (EvalsVal.var rfl) (by rw [hAe]; exact hvs _ (by omega))) (by rw [hAe])) ?_
  -- f0 = 2^(p + p - 2)
  refine ev_letE (pow2_ev hpw hpwS (evN_sub (evN_add (EvalsVal.var rfl) (EvalsVal.var rfl)
    (hvs _ ((size_add_le2 _ _).trans (by omega)))) (hlit _ 2 (by norm_num)) (by omega)
    (hvs _ ((size_add_le2 _ _).trans (by omega)))) (hSp _ (by omega))) ?_
  -- the caps
  obtain ⟨outT, houtT, hloopT⟩ := apT_loop (prog := prog) (M := M) h651 eA (by
    have : adaP eA * (Nat.size (tmA eA) + 2) ≤ (13 * L) * (37 * L) :=
      Nat.mul_le_mul (by omega) (by omega)
    have e2 : (13 * L) * (37 * L) = 481 * (L * L) := by ring
    omega) (adaP eA) le_rfl
  subst houtT
  have hdropT : (adaTmaxList eA).drop (adaP eA) = [] :=
    List.drop_eq_nil_of_le (by rw [adaTmaxList_length])
  refine ev_letE (ev_loop_ap ?_ hloopT) ?_
  · have e : encTS (tmA eA) (adaP eA) ((adaTmaxList eA).drop (adaP eA)) =
        Val.list [encN (adaP eA), Val.list [], encN 0, encN (tmA eA),
          encN (2 ^ (adaP eA + adaP eA - 2))] := by
      rw [hdropT]
      unfold encTS
      rw [four_pow_div_four' (by omega)]
      rfl
    rw [e]
    refine ev_list (.cons (EvalsVal.var rfl) (.cons (EvalsVal.nil (by simp; omega))
      (.cons (hlit _ 0 (by norm_num)) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) .nil)))))
      ?_
    have hf := size_two_pow (adaP eA + adaP eA - 2)
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, Nat.size_zero]
    omega
  -- the sum of the caps
  have hTTs : valSize (Val.list [encL encN (adaTmaxList eA), encN (adaTmaxList eA).sum]) ≤ M := by
    have h : valSize (encL encN (adaTmaxList eA)) ≤ 1 + adaP eA * (36 * L + 32) := by
      have h0 := valSize_encL_le encN (adaTmaxList eA) (36 * L + 31) (fun x hx => by
        rw [valSize_encN]
        have := (size_le_of_le (mem_adaTmaxList_le hx)).trans sA
        omega)
      rwa [adaTmaxList_length] at h0
    have hpr2 : adaP eA * (36 * L + 32) ≤ (13 * L) * (37 * L) := Nat.mul_le_mul (by omega) (by omega)
    have e2 : (13 * L) * (37 * L) = 481 * (L * L) := by ring
    have h2 : valSize (encN (adaTmaxList eA).sum) ≤ 48 * L + 35 := by rw [valSize_encN]; omega
    have := valSize_list2_le h h2
    omega
  refine ev_letE (ev_get 1 (EvalsVal.var rfl) hTTs rfl) ?_
  -- Q
  have h100 : Nat.size 100 ≤ 7 := Nat.size_le.2 (by norm_num)
  refine ev_letE (ev_cast (evN_mul (evN_mul (hlit _ 100 (by norm_num)) (evN_add (EvalsVal.var rfl)
    (hlit _ 1 (by norm_num)) (hvs _ (by omega))) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (evN_add (evN_add (evN_add (evN_add (EvalsVal.var rfl) (EvalsVal.var rfl)
      (hvs _ (le_trans (size_le_of_le (show mM + R ≤ mM + R + J + 2 by omega)) (by omega))))
      (EvalsVal.var rfl) (hvs _ (le_trans (size_le_of_le (show mM + R + J ≤ mM + R + J + 2 by omega))
        (by omega)))) (hlit _ 2 (by norm_num)) (hvs _ (by omega)))
      (EvalsVal.var rfl) (hvs _ ((size_add_le2 _ _).trans (by omega))))
    (hvs _ (by
      have e : 100 * (adaP eA + 1) * (mM + R + J + 2 + (adaTmaxList eA).sum) = adaQ mM J R eA := rfl
      rw [e]; omega)))
    (show encN (100 * (adaP eA + 1) * (mM + R + J + 2 + (adaTmaxList eA).sum)) =
      encN (adaQ mM J R eA) from rfl)) ?_
  -- χ
  have h49 : Nat.size 49 ≤ 6 := Nat.size_le.2 (by norm_num)
  refine ev_letE (ev_cast (evN_add (evN_add (evN_add (hlit _ 49 (by norm_num)) (EvalsVal.var rfl)
    (hvs _ ((size_add_le2 _ _).trans (by omega)))) (EvalsVal.var rfl)
    (hvs _ ((size_add_le2 _ _).trans (by have := size_add_le2 49 eA; have := size_le_self' eXi; omega))))
    (clog2_ev hcl hclS (evN_mul (evN_mul (EvalsVal.var rfl) (evN_add (EvalsVal.var rfl)
      (hlit _ 1 (by norm_num)) (hvs _ (by omega))) (hvs _ ((size_mul_le _ _).trans (by omega))))
      (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans
        (by have := size_mul_le (adaP eA) (adaP eA + 1); omega))))
      (hSc _ ((size_mul_le _ _).trans (by have := size_mul_le (adaP eA) (adaP eA + 1); omega))))
    (hvs _ (by
      have e : 49 + eA + eXi + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaQ mM J R eA) =
        adaChi mM J R eA eXi := rfl
      rw [e]; omega)))
    (show encN (49 + eA + eXi + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaQ mM J R eA)) =
      encN (adaChi mM J R eA eXi) from rfl)) ?_
  -- h⁻¹
  have h512 : Nat.size 512 ≤ 10 := Nat.size_le.2 (by norm_num)
  refine ev_letE (ev_cast (evN_mul (evN_mul (hlit _ 512 (by norm_num)) (EvalsVal.var rfl)
    (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
    (hvs _ (by
      have e : 512 * adaP eA * 2 ^ eA = adaHInv eA := rfl
      rw [e]; omega)))
    (show encN (512 * adaP eA * 2 ^ eA) = encN (adaHInv eA) from rfl)) ?_
  -- 2^(eA+11)
  refine ev_letE (pow2_ev hpw hpwS (evN_add (EvalsVal.var rfl) (hlit _ 11 (by norm_num))
    (hvs _ ((size_add_le2 _ _).trans (by
      have := size_le_of_lt_pow (show 11 < 2 ^ 4 by norm_num); omega)))) (hSp _ (by omega))) ?_
  -- the blocks
  have hnbev : ∀ j, j ≤ adaP eA → EvalsVal prog M [Val.list [encN j, encN (2 ^ (2 * j)),
      encN (tmA eA), encN (adaP eA), encN J, encN R, encN (adaChi mM J R eA eXi),
      encN (1048576 * adaChi mM J R eA eXi * adaHInv eA),
      encN (4096 * adaChi mM J R eA eXi * (adaHInv eA * adaHInv eA)),
      encN (2 ^ (eA + 11) * adaP eA)]] [] (.inl body_apNB) (encN (nb j)) := by
    intro j hj
    exact apNB_ev (W := 1024 * L) hBL hA1 (hW _ (by have := size_le_self' j; omega))
      (hW _ (by rw [size_two_pow]; omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega))
      (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega))
      (by omega)
  obtain ⟨outB, houtB, hloopB⟩ := apB_loop (prog := prog) (M := M) (W := 1024 * L) h654
    hBL.apNB nb hnbev (fun j hj => lt_of_lt_of_le (hnbN j hj)
      (Nat.pow_le_pow_right (by norm_num) (by omega)))
    (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega))
    (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by rw [size_two_pow]; omega))
    (by
      have : (adaP eA + 2) * (1024 * L + 2) ≤ (13 * L) * (1025 * L) :=
        Nat.mul_le_mul (by omega) (by omega)
      have e : (13 * L) * (1025 * L) = 13325 * (L * L) := by ring
      omega) (adaP eA + 1) le_rfl
  subst houtB
  have hdropB : ((List.range (adaP eA + 1)).map nb).drop (adaP eA + 1) = [] :=
    List.drop_eq_nil_of_le (by simp)
  have hBBv : Val.list [encL encN ((List.range (adaP eA + 1)).map nb),
      encN (((List.range (adaP eA + 1)).map nb).foldr max 0)] =
      Val.list [encL encN (adaBlockSizes mM J R eA eXi), encN (adaMaxN mM J R eA eXi)] := by
    rw [hBl]
    unfold adaMaxN
    rw [foldl_max_zero]
  refine ev_letE (ev_cast (ev_loop_ap ?_ hloopB) hBBv) ?_
  · have hf4 : 2 ^ (2 * (adaP eA + 1)) / 4 = 4 * 2 ^ (adaP eA + adaP eA - 2) := by
      rw [four_pow_div_four, show 2 * adaP eA = (adaP eA + adaP eA - 2) + 2 by omega, pow_add]
      ring
    have e : encBS (tmA eA) (adaP eA) J R (adaChi mM J R eA eXi)
        (1048576 * adaChi mM J R eA eXi * adaHInv eA)
        (4096 * adaChi mM J R eA eXi * (adaHInv eA * adaHInv eA)) (2 ^ (eA + 11) * adaP eA)
        (adaP eA + 1) (((List.range (adaP eA + 1)).map nb).drop (adaP eA + 1)) =
        Val.list [encN (adaP eA + 1), Val.list [], encN 0, encN (4 * 2 ^ (adaP eA + adaP eA - 2)),
          encN (tmA eA), encN (adaP eA), encN J, encN R, encN (adaChi mM J R eA eXi),
          encN (1048576 * adaChi mM J R eA eXi * adaHInv eA),
          encN (4096 * adaChi mM J R eA eXi * (adaHInv eA * adaHInv eA)),
          encN (2 ^ (eA + 11) * adaP eA)] := by
      rw [hdropB]
      unfold encBS
      rw [hf4]
      rfl
    rw [e]
    have s4f : Nat.size (4 * 2 ^ (adaP eA + adaP eA - 2)) ≤ 24 * L + 12 := by
      have h1 := size_mul_le 4 (2 ^ (adaP eA + adaP eA - 2))
      have h2 := size_two_pow (adaP eA + adaP eA - 2)
      have : Nat.size 4 ≤ 3 := Nat.size_le.2 (by norm_num)
      omega
    refine ev_list (.cons (evN_add (EvalsVal.var rfl) (hlit _ 1 (by norm_num)) (hvs _ (by omega)))
      (.cons (EvalsVal.nil (by simp; omega)) (.cons (hlit _ 0 (by norm_num))
      (.cons (evN_mul (hlit _ 4 (by norm_num)) (EvalsVal.var rfl) (hvs _ (by omega)))
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
      (.cons (evN_mul (evN_mul (hlit _ 1048576 (by norm_num)) (EvalsVal.var rfl)
          (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl) (hvs _ (by omega)))
      (.cons (evN_mul (evN_mul (hlit _ 4096 (by norm_num)) (EvalsVal.var rfl)
          (hvs _ ((size_mul_le _ _).trans (by omega)))) (evN_mul (EvalsVal.var rfl)
          (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega)))) (hvs _ (by omega)))
      (.cons (evN_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (hvs _ (by omega))) .nil)))))))))))) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, Nat.size_zero]
    omega
  -- a₁, a₂, q_A
  have h29 : Nat.size 29 ≤ 5 := Nat.size_le.2 (by norm_num)
  have h20 : Nat.size 20 ≤ 5 := Nat.size_le.2 (by norm_num)
  have hBBs : valSize (Val.list [encL encN (adaBlockSizes mM J R eA eXi),
      encN (adaMaxN mM J R eA eXi)]) ≤ M := by
    have h : valSize (encL encN (adaBlockSizes mM J R eA eXi)) ≤
        1 + (adaP eA + 1) * (11 * L + 201) := by
      have h0 := valSize_encL_le encN (adaBlockSizes mM J R eA eXi) (11 * L + 200) (fun x hx => by
        rw [valSize_encN]
        have := size_le_of_lt_pow (lt_of_le_of_lt (le_sum_of_mem' hx) hN)
        omega)
      rwa [adaBlockSizes_length] at h0
    have hpr1 : (adaP eA + 1) * (11 * L + 201) ≤ (13 * L) * (14 * L) :=
      Nat.mul_le_mul (by omega) (by omega)
    have e1 : (13 * L) * (14 * L) = 182 * (L * L) := by ring
    have h2 : valSize (encN (adaMaxN mM J R eA eXi)) ≤ 11 * L + 200 := by rw [valSize_encN]; omega
    have := valSize_list2_le h h2
    omega
  have hcl1 := clog2_le_size (adaP eA * (adaP eA + 1) * adaChi mM J R eA eXi)
  have hcl2 := clog2_le_size (adaMaxN mM J R eA eXi)
  refine ev_letE (evN_add (evN_add (hlit _ 29 (by norm_num)) (EvalsVal.var rfl)
    (hvs _ ((size_add_le2 _ _).trans (by omega))))
    (clog2_ev hcl hclS (evN_mul (evN_mul (EvalsVal.var rfl) (evN_add (EvalsVal.var rfl)
      (hlit _ 1 (by norm_num)) (hvs _ (by omega))) (hvs _ ((size_mul_le _ _).trans (by omega))))
      (EvalsVal.var rfl) (hvs _ (by omega))) (hSc _ (by omega)))
    (hvs _ ((size_le_self' _).trans (by omega)))) ?_
  refine ev_letE (evN_add (hlit _ 20 (by norm_num)) (clog2_ev hcl hclS
    (ev_get 1 (EvalsVal.var rfl) hBBs rfl) (hSc _ (by omega)))
    (hvs _ ((size_le_self' _).trans (by omega)))) ?_
  have hqAv : (if 29 + eA + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaChi mM J R eA eXi) <
      20 + Nat.clog 2 (adaMaxN mM J R eA eXi) then 20 + Nat.clog 2 (adaMaxN mM J R eA eXi)
      else 29 + eA + Nat.clog 2 (adaP eA * (adaP eA + 1) * adaChi mM J R eA eXi)) =
      adaQA mM J R eA eXi := by
    unfold adaQA
    split_ifs with h
    · exact (max_eq_right h.le).symm
    · exact (max_eq_left (not_lt.mp h)).symm
  refine ev_letE (ev_cast (?_ : EvalsVal prog M _ [] (.inl (Expr.ite (Expr.bin BinOp.lt (Expr.var 1)
    (Expr.var 0)) (Expr.var 0) (Expr.var 1))) (encN (if 29 + eA + Nat.clog 2 (adaP eA *
      (adaP eA + 1) * adaChi mM J R eA eXi) < 20 + Nat.clog 2 (adaMaxN mM J R eA eXi) then
      20 + Nat.clog 2 (adaMaxN mM J R eA eXi) else 29 + eA + Nat.clog 2 (adaP eA * (adaP eA + 1) *
        adaChi mM J R eA eXi)))) (by rw [hqAv])) ?_
  · split_ifs with h
    · exact ev_ite_true (evN_lt_true (EvalsVal.var rfl) (EvalsVal.var rfl) h (by omega))
        (EvalsVal.var rfl)
    · exact ev_ite_false (evN_lt_false (EvalsVal.var rfl) (EvalsVal.var rfl) h (by omega))
        (EvalsVal.var rfl)
  -- 2^qA, 2^eXi
  refine ev_letE (pow2_ev hpw hpwS (EvalsVal.var rfl) (hSp _ (by omega))) ?_
  refine ev_letE (pow2_ev hpw hpwS (EvalsVal.var rfl) (hSp _ (by omega))) ?_
  -- Z_d
  have hc98 : Nat.size 98304000 ≤ 27 := Nat.size_le.2 (by norm_num)
  refine ev_letE (ev_cast (evN_mul (evN_mul (evN_mul (evN_mul (hlit _ 98304000 (by norm_num))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (evN_add (EvalsVal.var rfl) (hlit _ 1 (by norm_num)) (hvs _ (by omega)))
    (hvs _ ((size_mul_le _ _).trans (by have := size_mul_le 98304000 (adaP eA); omega))))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans
      (by have := size_mul_le 98304000 (adaP eA)
          have := size_mul_le (98304000 * adaP eA) (adaP eA + 1); omega))))
    (evN_mul (EvalsVal.var rfl) (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (hvs _ (by
      have e : 98304000 * adaP eA * (adaP eA + 1) * adaQ mM J R eA * (2 ^ eA * 2 ^ eXi) =
        zdQ mM J R eA eXi := rfl
      rw [e]; omega)))
    (show encN (98304000 * adaP eA * (adaP eA + 1) * adaQ mM J R eA * (2 ^ eA * 2 ^ eXi)) =
      encN (zdQ mM J R eA eXi) from rfl)) ?_
  -- B₀
  refine ev_letE (ev_cast (clog2_ev hcl hclS (evN_mul (hlit _ 16 (by norm_num)) (EvalsVal.var rfl)
    (hvs _ ((size_mul_le _ _).trans (by omega)))) (hSc _ ((size_mul_le _ _).trans (by omega))))
    (by rw [← adaB0_eq])) ?_
  -- τ, a/2, κ h_A/4
  have hpos1 : (0 : ℤ) < ((8 * adaP eA * 2 ^ eA : ℕ) : ℤ) := by
    have : 0 < 8 * adaP eA * 2 ^ eA :=
      Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (Nat.two_pow_pos _)
    exact_mod_cast this
  have hpos2 : (0 : ℤ) < ((2 * 2 ^ eA : ℕ) : ℤ) := by
    have : 0 < 2 * 2 ^ eA := Nat.mul_pos (by norm_num) (Nat.two_pow_pos _)
    exact_mod_cast this
  have hpos3 : (0 : ℤ) < ((128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi : ℕ) : ℤ) := by
    have : 0 < 128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi :=
      Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (Nat.two_pow_pos _))
        (Nat.two_pow_pos _)
    exact_mod_cast this
  have h8 : Nat.size 8 ≤ 4 := Nat.size_le.2 (by norm_num)
  have h128 : Nat.size 128 ≤ 8 := Nat.size_le.2 (by norm_num)
  have h2 : Nat.size 2 ≤ 2 := Nat.size_le.2 (by norm_num)
  have sb1 : Nat.size (8 * adaP eA * 2 ^ eA) ≤ 18 * L + 9 := by
    have h1 := size_mul_le 8 (adaP eA)
    have h2 := size_mul_le (8 * adaP eA) (2 ^ eA)
    omega
  have sb2 : Nat.size (2 * 2 ^ eA) ≤ 6 * L + 3 := by
    have h1 := size_mul_le 2 (2 ^ eA)
    omega
  have sb3 : Nat.size (128 * adaP eA * 2 ^ eA * 2 ^ adaQA mM J R eA eXi) ≤ 104 * L + 245 := by
    have h1 := size_mul_le 128 (adaP eA)
    have h2 := size_mul_le (128 * adaP eA) (2 ^ eA)
    have h3 := size_mul_le (128 * adaP eA * 2 ^ eA) (2 ^ adaQA mM J R eA eXi)
    omega
  have hl1 : ∀ (env : List Val), EvalsVal prog M env [] (.inl (Expr.lit 1)) (Val.int 1) :=
    fun env => EvalsVal.lit (by simp; omega)
  refine ev_letE (normQ_ev hq (ev_list (.cons (hl1 _) (.cons (evN_mul (evN_mul (hlit _ 8
    (by norm_num)) (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (EvalsVal.var rfl) (hvs _ (by omega))) .nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen_one,
        bitLen_natCast]
      omega)) hpos1 (by rw [bitLen_one, bitLen_natCast]; omega)) ?_
  refine ev_letE (normQ_ev hq (ev_list (.cons (hl1 _) (.cons (evN_mul (hlit _ 2 (by norm_num))
    (EvalsVal.var rfl) (hvs _ (by omega))) .nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen_one,
        bitLen_natCast]
      omega)) hpos2 (by rw [bitLen_one, bitLen_natCast]; omega)) ?_
  refine ev_letE (normQ_ev hq (ev_list (.cons (hl1 _) (.cons (evN_mul (evN_mul (evN_mul
    (hlit _ 128 (by norm_num)) (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans (by omega))))
    (EvalsVal.var rfl) (hvs _ ((size_mul_le _ _).trans
      (by have := size_mul_le 128 (adaP eA); omega))))
    (EvalsVal.var rfl) (hvs _ (by omega))) .nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen_one,
        bitLen_natCast]
      omega)) hpos3 (by rw [bitLen_one, bitLen_natCast]; omega)) ?_
  -- the record
  rw [adaPubEnc_adaParams] at hrec ⊢
  have hsampEv : ∀ κ, ∀ (env : List Val) (m : Expr),
      env[6]? = some (encN (2 ^ adaQA mM J R eA eXi)) →
      env[3]? = some (encN (adaB0 mM J R eA eXi)) → env[4]? = some (encN (zdQ mM J R eA eXi)) →
      EvalsVal prog M env [] (.inl m) (encN (mK mM J R eA eXi κ)) →
      EvalsVal prog M env [] (.inl (apSampCall m))
        (encL encN (sampV (2 ^ adaQA mM J R eA eXi) (mK mM J R eA eXi κ) (adaB0 mM J R eA eXi)
          (zdQ mM J R eA eXi))) := by
    intro κ env m h6 h3 h4 hm
    have smk := smK κ
    refine ev_call h657 (ev_list (.cons (EvalsVal.var h6) (.cons hm (.cons (EvalsVal.var h3)
      (.cons (EvalsVal.var h4) .nil)))) ?_) (apSamp_ev hq hcl hclS (W := 1024 * L)
        (mK_pos mM J R eA eXi κ) (hW _ (by omega)) (hW _ (by omega)) (hW _ (by omega))
        (hW _ (by omega)) (by omega))
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have h32768 : Nat.size 32768 ≤ 16 := Nat.size_le.2 (by norm_num)
  have h16384 : Nat.size 16384 ≤ 15 := Nat.size_le.2 (by norm_num)
  have h256 : Nat.size 256 ≤ 9 := Nat.size_le.2 (by norm_num)
  have h64 : Nat.size 64 ≤ 7 := Nat.size_le.2 (by norm_num)
  have s1T : Nat.size (1 + (adaTmaxList eA).sum) ≤ 48 * L + 36 :=
    (size_add_le2 _ _).trans (by simp; omega)
  refine ev_list (.cons (EvalsVal.var rfl) (.cons (ev_get 0 (EvalsVal.var rfl) hBBs rfl)
    (.cons (ev_get 0 (EvalsVal.var rfl) hTTs rfl)
    (.cons (evN_add (hlit _ 1 (by norm_num)) (EvalsVal.var rfl) (hvs _ (s1T.trans (by omega))))
    (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl)
    (.cons (EvalsVal.var rfl) (.cons (EvalsVal.var rfl) (.cons ?_ .nil))))))))))))) hrec
  refine ev_list (.cons (hsampEv NoiseKind.intThr _ _ rfl rfl rfl
    (evN_mul (evN_mul (evN_mul (hlit _ 32768 (by norm_num)) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by have := size_mul_le 32768 (adaP eA); omega))))
      (EvalsVal.var rfl) (hvs _ (by have := smK NoiseKind.intThr; simp only [mK] at this; omega))))
    (.cons (hsampEv NoiseKind.intTest _ _ rfl rfl rfl
    (evN_mul (evN_mul (evN_mul (hlit _ 16384 (by norm_num)) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by have := size_mul_le 16384 (adaP eA); omega))))
      (EvalsVal.var rfl) (hvs _ (by have := smK NoiseKind.intTest; simp only [mK] at this; omega))))
    (.cons (hsampEv NoiseKind.outThr _ _ rfl rfl rfl
    (evN_mul (evN_mul (hlit _ 256 (by norm_num)) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
      (hvs _ (by have := smK NoiseKind.outThr; simp only [mK] at this; omega))))
    (.cons (hsampEv NoiseKind.outTest _ _ rfl rfl rfl
    (evN_mul (evN_mul (hlit _ 128 (by norm_num)) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
      (hvs _ (by have := smK NoiseKind.outTest; simp only [mK] at this; omega))))
    (.cons (hsampEv NoiseKind.num _ _ rfl rfl rfl
    (evN_mul (evN_mul (hlit _ 64 (by norm_num)) (EvalsVal.var rfl)
      (hvs _ ((size_mul_le _ _).trans (by omega)))) (EvalsVal.var rfl)
      (hvs _ (by have := smK NoiseKind.num; simp only [mK] at this; omega)))) .nil))))) ?_
  have := valSize_list5_le (hsamp NoiseKind.intThr) (hsamp NoiseKind.intTest)
    (hsamp NoiseKind.outThr) (hsamp NoiseKind.outTest) (hsamp NoiseKind.num)
  omega

end F2e2e.BSpace
