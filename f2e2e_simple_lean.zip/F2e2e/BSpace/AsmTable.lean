import F2e2e.BSpace.DslBodies
import F2e2e.BSpace.Pub
import F2e2e.C.Impl.AdaContract
import F2e2e.BSpace.DslBlocks
import F2e2e.BSpace.DslEnds
import F2e2e.BSpace.DslEvalsDefs
import F2e2e.Cost.MachineBits
import F2e2e.C.Impl.AsmTable

/-!
# B_space, layer D5: the routine table and the two programs of `Theorem_B_space`

Owner: NEW-B (96916dcd), for the B_space area lead W4 (cc77ceaa); plan `F2e2e/BSpace/BSPACE_PLAN.md` §D (D5).
Modelled on C-SPACE's assembly of Theorem (C) (`F2e2e/C/Impl/AsmTable.lean`, `AsmRank.lean`).

* `bsTable`: the concatenation of the B areas' routine tables, each referenced BY NAME (so that it follows
  their changes): W4's `w4AllTable` (the whole ADA module, `F2e2e/C/Impl/AdaContract.lean`), W2's `bsPubTable`
  (the five parameter getters `++ adaPubTable`, `F2e2e/BSpace/Pub.lean`), W5's `bsNormQTable` (`normQ`),
  W3's `bsBlocksTable` (D1, keys 900–902), 1beb339b's `bsEvalsTable` (D2, keys 910–912 and `revAppendStep`),
  W5's `bsEndsTable` (D3, key 920 and `pow2`) and W2's `bsMainTable` (D4's helpers, keys 930–939; empty so
  far). Keys occurring several times carry the same body (checked: `BsAsmCons`), so `List.lookup` (the first
  entry) finds every entry.
* `bsInitProg = mkProg body_bsInit bsTable`, `bsRoundProg = mkProg body_bsRound bsTable` (`F2e2e/Cost/Assembly.lean`;
  entry bodies: D4, W2's `F2e2e/BSpace/DslBodies.lean`).
* `BsLib prog`: every entry of `bsTable` is the body of `prog` at its key. `bsLib_mkProg`: every program assembled
  from `bsTable` satisfies it. Projections to the areas' library hypotheses: `BsLib.w4Lib` (W4's `W4Lib`),
  `BsLib.pub` (W2's `bsPub_eval`), `BsLib.normQTbl` / `BsLib.normQ` (C-TOP's `NormQSpec`), `BsLib.blocks` (D1),
  `BsLib.evals` (D2), `BsLib.ends` (D3), `BsLib.main` (D4).
* The oracle: `bsInitProg_oracle`, `bsRoundProg_oracle` (`prog[bsOracleIdx]? = none`, `bsOracleIdx = 1000`: all keys
  are `≤ 999`), as needed by `EvalsValO.of_evalsVal` / `Implements.toO`.
* Generic facts about `mkProg` (copies of C-SPACE's, named `bsAsm_*`): `bsAsm_mkProg_get_cases`,
  `bsAsm_rankOK_mkProg` (a rank certificate from the entry body and the table entries),
  `bsAsm_progDepth_mkProg_le`, `bsAsm_height_add_one`.

All finite facts about the table are ONE kernel evaluation (`bsAsmTableCheck_ok`, `decide +kernel`: kernel reduction
only, nothing added to the trusted base; about 0.6 s). It walks the table once, compares the keys (numerals `≤ 1000`,
by `Nat.beq`) and compares bodies only for repeated keys (`bsAsmConsB`: the 17 entries of `adaPubTable`, which
`bsPubTable` repeats, `pow2` and `revAppendStep`); no big numerals and no powers of two are reduced. The rank
certificate is in `F2e2e/BSpace/AsmRank.lean`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl

/-! The structural decidable equality of programs (`DecidableEq` for `BinOp`, `UnOp`, `Expr`, used by the kernel
check of repeated keys) comes from C-SPACE's `F2e2e/C/Impl/AsmTable.lean`; deriving it a second time here would
duplicate its auxiliary declarations (e.g. `F2e2e.UnOp.ofNat`) in every module importing both. -/

/-! ## The table -/

/-- **The routine table of the B programs**: the B areas' tables, each by name. -/
def bsTable : List (ℕ × Expr) :=
  w4AllTable ++ bsPubTable ++ bsNormQTable ++ bsBlocksTable ++ bsEvalsTable ++ bsEndsTable ++
    bsMainTable

/-! ## Generic facts about `mkProg` (copies of C-SPACE's `F2e2e/C/Impl/AsmTable.lean`) -/

/-- An entry found by `List.lookup` is an entry of the table. -/
theorem bsAsm_mem_of_lookup {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr} (h : tbl.lookup i = some b) :
    (i, b) ∈ tbl := by
  obtain ⟨l₁, l₂, htbl, -⟩ := List.lookup_eq_some_iff.mp h
  rw [htbl]
  simp

/-- Every body of `mkProg main tbl` is the entry body (index `0`), a body of the table at its own
key, or the filler `Expr.nil`. -/
theorem bsAsm_mkProg_get_cases {main : Expr} {tbl : List (ℕ × Expr)} {j : ℕ} {b : Expr}
    (h : (mkProg main tbl)[j]? = some b) : (j = 0 ∧ b = main) ∨ (j, b) ∈ tbl ∨ b = Expr.nil := by
  cases j with
  | zero =>
    left
    simp only [mkProg, List.getElem?_cons_zero, Option.some.injEq] at h
    exact ⟨rfl, h.symm⟩
  | succ j =>
    right
    simp only [mkProg, List.getElem?_cons_succ, List.getElem?_map] at h
    by_cases hj : j < tblMax tbl
    · rw [List.getElem?_range hj] at h
      simp only [Option.map_some, Option.some.injEq] at h
      cases hl : tbl.lookup (j + 1) with
      | none =>
        right
        rw [hl] at h
        exact h.symm
      | some b' =>
        left
        rw [hl] at h
        simp only [Option.getD_some] at h
        subst h
        exact bsAsm_mem_of_lookup hl
    · rw [List.getElem?_eq_none (by simpa using hj)] at h
      simp at h

/-- **Rank certificate of an assembled program** from its entry body and its table entries (the
filler `Expr.nil` has depth `1` and no callees). -/
theorem bsAsm_rankOK_mkProg {main : Expr} {tbl : List (ℕ × Expr)} {r : ℕ → ℕ} {K : ℕ} (hK : 1 ≤ K)
    (hmain : exprDepth main ≤ K ∧ CalleesLt r (r 0) main)
    (htbl : ∀ e ∈ tbl, exprDepth e.2 ≤ K ∧ CalleesLt r (r e.1) e.2) :
    RankOK (mkProg main tbl) r K := by
  intro j b hj
  rcases bsAsm_mkProg_get_cases hj with ⟨rfl, rfl⟩ | hmem | rfl
  · exact hmain
  · exact htbl _ hmem
  · exact ⟨by simpa [exprDepth] using hK, trivial⟩

theorem bsAsm_foldr_max_le {l : List ℕ} {D : ℕ} (h : ∀ x ∈ l, x ≤ D) : l.foldr max 0 ≤ D := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.foldr_cons]
    exact max_le (h a (by simp)) (ih fun x hx => h x (by simp [hx]))

/-- The machine depth of an assembled program from its entry body and its table entries. -/
theorem bsAsm_progDepth_mkProg_le {main : Expr} {tbl : List (ℕ × Expr)} {D : ℕ}
    (hmain : F2e2e.Machine.height main ≤ D)
    (htbl : ∀ e ∈ tbl, F2e2e.Machine.height e.2 ≤ D) :
    F2e2e.Machine.progDepth (mkProg main tbl) ≤ D := by
  unfold F2e2e.Machine.progDepth
  refine bsAsm_foldr_max_le fun x hx => ?_
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hx
  obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hb
  rcases bsAsm_mkProg_get_cases hj with ⟨-, rfl⟩ | hmem | rfl
  · exact hmain
  · exact htbl _ hmem
  · simp [F2e2e.Machine.height]

/-- The machine's height of an expression is its depth minus one (leaves: height `0`, depth `1`). -/
theorem bsAsm_height_add_one : ∀ e : Expr, F2e2e.Machine.height e + 1 = exprDepth e
  | Expr.var _ => rfl
  | Expr.lit _ => rfl
  | Expr.nil => rfl
  | Expr.coin => rfl
  | Expr.bin _ a b => by
    have ha := bsAsm_height_add_one a
    have hb := bsAsm_height_add_one b
    simp only [F2e2e.Machine.height, exprDepth]
    omega
  | Expr.un _ a => by
    have ha := bsAsm_height_add_one a
    simp only [F2e2e.Machine.height, exprDepth]
    omega
  | Expr.ite c t f => by
    have hc := bsAsm_height_add_one c
    have ht := bsAsm_height_add_one t
    have hf := bsAsm_height_add_one f
    simp only [F2e2e.Machine.height, exprDepth]
    omega
  | Expr.letE a b => by
    have ha := bsAsm_height_add_one a
    have hb := bsAsm_height_add_one b
    simp only [F2e2e.Machine.height, exprDepth]
    omega
  | Expr.call _ a => by
    have ha := bsAsm_height_add_one a
    simp only [F2e2e.Machine.height, exprDepth]
    omega
  | Expr.loop _ a => by
    have ha := bsAsm_height_add_one a
    simp only [F2e2e.Machine.height, exprDepth]
    omega

/-! ## Lookup by `Nat.beq` (light in the kernel) -/

/-- The value of the first entry of key `j` (`Nat.beq` comparisons: one kernel step per entry). -/
def bsAsmFindO {α : Type} : List (ℕ × α) → ℕ → Option α
  | [], _ => none
  | (k, v) :: rest, j => bif Nat.beq j k then some v else bsAsmFindO rest j

theorem bsAsmFindO_some {α : Type} : ∀ {l : List (ℕ × α)} {j : ℕ} {v : α},
    bsAsmFindO l j = some v → (j, v) ∈ l
  | [], _, _, h => by simp [bsAsmFindO] at h
  | (k, w) :: rest, j, v, h => by
    simp only [bsAsmFindO] at h
    cases hb : Nat.beq j k with
    | true =>
      rw [hb] at h
      simp only [cond_true, Option.some.injEq] at h
      have hjk := Nat.eq_of_beq_eq_true hb
      subst hjk
      subst h
      exact List.mem_cons_self
    | false =>
      rw [hb] at h
      simp only [cond_false] at h
      exact List.mem_cons_of_mem _ (bsAsmFindO_some h)

theorem bsAsmFindO_none {α : Type} : ∀ {l : List (ℕ × α)} {j : ℕ},
    bsAsmFindO l j = none → ∀ p ∈ l, p.1 ≠ j
  | [], _, _, p, hp => by simp at hp
  | (k, w) :: rest, j, h, p, hp => by
    simp only [bsAsmFindO] at h
    cases hb : Nat.beq j k with
    | true =>
      rw [hb] at h
      simp at h
    | false =>
      rw [hb] at h
      simp only [cond_false] at h
      rcases List.mem_cons.mp hp with hpk | hp'
      · rw [hpk]
        exact fun e => Nat.ne_of_beq_eq_false hb e.symm
      · exact bsAsmFindO_none h p hp'

/-! ## Consistency of a table with repeated keys -/

/-- A table is **consistent** if entries with equal keys have equal bodies. -/
def BsAsmCons (l : List (ℕ × Expr)) : Prop := ∀ x ∈ l, ∀ y ∈ l, x.1 = y.1 → x.2 = y.2

/-- Boolean check of consistency, comparing bodies only for repeated keys: `seen` holds the entries
already processed (most recent first); a new entry is compared with an earlier entry of its key, if any. -/
def bsAsmConsB : List (ℕ × Expr) → List (ℕ × Expr) → Bool
  | _, [] => true
  | seen, e :: rest =>
    (match bsAsmFindO seen e.1 with
      | none => true
      | some b => decide (b = e.2)) && bsAsmConsB (e :: seen) rest

theorem bsAsmConsB_sound : ∀ (rest seen : List (ℕ × Expr)), BsAsmCons seen →
    bsAsmConsB seen rest = true → BsAsmCons (seen ++ rest)
  | [], seen, hs, _ => by simpa using hs
  | e :: rest, seen, hs, hc => by
    simp only [bsAsmConsB, Bool.and_eq_true] at hc
    obtain ⟨h1, h2⟩ := hc
    have key : ∀ y ∈ seen, y.1 = e.1 → e.2 = y.2 := by
      intro y hy hye
      cases hl : bsAsmFindO seen e.1 with
      | none =>
        exact absurd hye (bsAsmFindO_none hl y hy)
      | some b =>
        rw [hl] at h1
        have hbe : b = e.2 := by simpa using h1
        have hb : (e.1, b) ∈ seen := bsAsmFindO_some hl
        rw [← hbe]
        exact hs (e.1, b) hb y hy hye.symm
    have hs' : BsAsmCons (e :: seen) := by
      intro x hx y hy hxy
      rcases List.mem_cons.mp hx with hxe | hxs <;> rcases List.mem_cons.mp hy with hye | hys
      · rw [hxe, hye]
      · rw [hxe] at hxy ⊢
        exact key y hys hxy.symm
      · rw [hye] at hxy ⊢
        exact (key x hxs hxy).symm
      · exact hs x hxs y hys hxy
    have h3 := bsAsmConsB_sound rest (e :: seen) hs' h2
    intro x hx y hy hxy
    refine h3 x ?_ y ?_ hxy
    · simp only [List.mem_append, List.mem_cons] at hx ⊢
      tauto
    · simp only [List.mem_append, List.mem_cons] at hy ⊢
      tauto

/-- In a consistent table, `List.lookup` finds every entry. -/
theorem bsAsm_lookup_of_cons {l : List (ℕ × Expr)} (h : BsAsmCons l) :
    ∀ e ∈ l, l.lookup e.1 = some e.2 := by
  intro e he
  cases hl : l.lookup e.1 with
  | none =>
    have := (List.lookup_eq_none_iff.mp hl) e he
    simp at this
  | some b =>
    exact congrArg some (h (e.1, b) (bsAsm_mem_of_lookup hl) e he rfl)

/-! ## The finite facts about `bsTable` (one kernel evaluation) -/

/-- All finite facts about `bsTable` in one Boolean: consistency (bodies compared only for repeated
keys), positive keys (index `0` is the entry point), and keys `≤ 999` (below the oracle index `1000`). -/
def bsAsmTableCheckB : Bool :=
  bsAsmConsB [] bsTable && bsTable.all (fun e => decide (0 < e.1)) && decide (tblMax bsTable ≤ 999)

theorem bsAsmTableCheck_ok : bsAsmTableCheckB = true := by
  decide +kernel

theorem bsTable_facts : BsAsmCons bsTable ∧ (∀ e ∈ bsTable, 0 < e.1) ∧ tblMax bsTable ≤ 999 := by
  have h := bsAsmTableCheck_ok
  simp only [bsAsmTableCheckB, Bool.and_eq_true, decide_eq_true_eq, List.all_eq_true] at h
  obtain ⟨⟨h1, h2⟩, h3⟩ := h
  have hnil : BsAsmCons [] := by
    intro x hx
    simp at hx
  have h4 := bsAsmConsB_sound bsTable [] hnil h1
  rw [List.nil_append] at h4
  exact ⟨h4, h2, h3⟩

/-- **Every entry of `bsTable` is found by `List.lookup`.** -/
theorem bsTable_lookup : ∀ e ∈ bsTable, bsTable.lookup e.1 = some e.2 :=
  bsAsm_lookup_of_cons bsTable_facts.1

/-- All keys of `bsTable` are positive (index `0` is the entry point). -/
theorem bsTable_pos : ∀ e ∈ bsTable, 0 < e.1 := bsTable_facts.2.1

/-- All keys of `bsTable` are `≤ 999` (below the oracle index `bsOracleIdx = 1000`). -/
theorem bsTable_max : tblMax bsTable ≤ 999 := bsTable_facts.2.2

/-! ## The library predicate -/

/-- **The B library predicate**: every entry of `bsTable` is the body of `prog` at its key. -/
def BsLib (prog : List Expr) : Prop := ∀ e ∈ bsTable, prog[e.1]? = some e.2

/-- **Every program assembled from `bsTable` contains it.** -/
theorem bsLib_mkProg (main : Expr) : BsLib (mkProg main bsTable) :=
  fun e he => mkProg_get_of_lookup (bsTable_lookup e he) (bsTable_pos e he)

section Projections

variable {prog : List Expr}

/-- The entries of a sub-table of `bsTable`. -/
theorem BsLib.sub (h : BsLib prog) {L : List (ℕ × Expr)} (hL : ∀ e ∈ L, e ∈ bsTable) :
    ∀ e ∈ L, prog[e.1]? = some e.2 :=
  fun e he => h e (hL e he)

/-- W4's library predicate (the whole ADA module). -/
theorem BsLib.w4Lib (h : BsLib prog) : W4Lib prog :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- The hypothesis `hlib` of W2's `bsPub_eval` (the five getters and `adaPubTable`). -/
theorem BsLib.pub (h : BsLib prog) : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- W5's `normQ` and its Euclid loop. -/
theorem BsLib.normQTbl (h : BsLib prog) : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- C-TOP's `NormQSpec` (W5's `normQSpec_of_table`). -/
theorem BsLib.normQ (h : BsLib prog) (M : ℕ) : NormQSpec prog M :=
  normQSpec_of_table h.normQTbl

/-- The hypothesis `hlib` of D1's `bsBlocks_eval`. -/
theorem BsLib.blocks (h : BsLib prog) : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- The hypothesis `hlib` of D3's `bsEnds_eval`. -/
theorem BsLib.ends (h : BsLib prog) : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- The hypothesis of D2's `BsEvalsLib.of_table` (`bsEvals`, keys 910–912, and `revAppendStep`). -/
theorem BsLib.evals (h : BsLib prog) : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

/-- D4's helper routines (W2's `bsMainTable`, `F2e2e/BSpace/DslBodies.lean`; empty so far). -/
theorem BsLib.main (h : BsLib prog) : ∀ e ∈ bsMainTable, prog[e.1]? = some e.2 :=
  h.sub fun e he => by unfold bsTable; simp [he]

end Projections

/-! ## The two programs -/

/-- **The initialization program** of `Theorem_B_space` (`VImpl.initProg`). -/
def bsInitProg : List Expr := mkProg body_bsInit bsTable

/-- **The round program** of `Theorem_B_space` (`VImpl.roundProg`). -/
def bsRoundProg : List Expr := mkProg body_bsRound bsTable

theorem bsInitProg_zero : bsInitProg[0]? = some body_bsInit := mkProg_zero _ _

theorem bsRoundProg_zero : bsRoundProg[0]? = some body_bsRound := mkProg_zero _ _

theorem bsLib_init : BsLib bsInitProg := bsLib_mkProg _

theorem bsLib_round : BsLib bsRoundProg := bsLib_mkProg _

theorem bsInitProg_length : bsInitProg.length = tblMax bsTable + 1 := length_mkProg _ _

theorem bsRoundProg_length : bsRoundProg.length = tblMax bsTable + 1 := length_mkProg _ _

theorem bsInitProg_length_le : bsInitProg.length ≤ 1000 := by
  have := bsTable_max
  rw [bsInitProg_length]
  omega

theorem bsRoundProg_length_le : bsRoundProg.length ≤ 1000 := by
  have := bsTable_max
  rw [bsRoundProg_length]
  omega

/-- **The oracle index is not a function of the initialization program.** -/
theorem bsInitProg_oracle : bsInitProg[bsOracleIdx]? = none :=
  List.getElem?_eq_none bsInitProg_length_le

/-- **The oracle index is not a function of the round program.** -/
theorem bsRoundProg_oracle : bsRoundProg[bsOracleIdx]? = none :=
  List.getElem?_eq_none bsRoundProg_length_le

end F2e2e.BSpace
