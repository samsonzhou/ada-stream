import F2e2e.BSpace.MachineEvalsO

/-!
# B_space: forward rules for `EvalsValO` (DSL-CALC, namespace `F2e2e.BSpace.bsC`)

Complements C-SPACE's M1 (`F2e2e/BSpace/MachineEvalsO.lean`: `EvalsValO`, `of_evalsVal`, `ImplementsO`,
`mono_M`, `cast_bits`, `oracle_det`, `head`, `tail`, `cons`, `pair`, `loop_of_measure`, the `ImplementsO`
calculus and call rules) with the remaining rules of `F2e2e/Cost/ValRules.lean`, in oracle form:

* `bsC.var0`–`var3`, `ite_true`, `ite_false`, `isNil_nil`, `isNil_cons`, `lit'`, `add`, `sub`, `mul`,
  `div`, `mod`, `lt`, `eq`, `triple` (`Arith.eTriple`);
* `bsC.ne_oracle_of_some` (a key with a body is not the oracle index when `prog[bsOracleIdx]? = none`),
  `bsC.call` (call rule taking `hO : prog[bsOracleIdx]? = none` instead of `i ≠ bsOracleIdx`),
  `bsC.implementsO_call_det` (the same for `ImplementsO`);
* `bsC.oracle_triple`: `call bsOracleIdx (eTriple a b c)` from the three argument evaluations;
* `bsC.of_eval` / `bsC.of_evalT`: symbolic evaluation of oracle-free straight-line code (compute `eval`
  with the `eval_succ_*` simp lemmas and bound only the peak), lifted by `EvalsValO.of_evalsVal`;
* `bsC.lift`: any `EvalsVal` spec (e.g. `(X_spec … 0).toVal` of a library routine) lifts.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

namespace bsC

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}

/-! ### Variables, conditionals, primitives -/

theorem var0 {v : Val} {rest : List Val} :
    EvalsValO orc prog M (v :: rest) [] (.inl (Expr.var 0)) v :=
  EvalsValO.var rfl

theorem var1 {v w : Val} {rest : List Val} :
    EvalsValO orc prog M (w :: v :: rest) [] (.inl (Expr.var 1)) v :=
  EvalsValO.var rfl

theorem var2 {v w u : Val} {rest : List Val} :
    EvalsValO orc prog M (u :: w :: v :: rest) [] (.inl (Expr.var 2)) v :=
  EvalsValO.var rfl

theorem var3 {v w u t : Val} {rest : List Val} :
    EvalsValO orc prog M (t :: u :: w :: v :: rest) [] (.inl (Expr.var 3)) v :=
  EvalsValO.var rfl

theorem ite_true {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
    (hc : EvalsValO orc prog M env bc (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsValO orc prog M env bv (.inl t) v) :
    EvalsValO orc prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v :=
  EvalsValO.ite hc (by rw [if_pos hz]; exact ht)

theorem ite_false {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
    (hc : EvalsValO orc prog M env bc (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsValO orc prog M env bv (.inl f) v) :
    EvalsValO orc prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v :=
  EvalsValO.ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem isNil_nil {a : Expr} {ba : List Bool}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [])) (hM : 2 ≤ M) :
    EvalsValO orc prog M env ba (.inl (Expr.un UnOp.isNil a)) (Val.int 1) :=
  EvalsValO.un (c := 1) ha rfl (by simpa using hM)

theorem isNil_cons {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list (x :: l))) (hM : 1 ≤ M) :
    EvalsValO orc prog M env ba (.inl (Expr.un UnOp.isNil a)) (Val.int 0) :=
  EvalsValO.un (c := 1) ha rfl (by simpa using hM)

theorem lit' {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
    EvalsValO orc prog M env [] (.inl (Expr.lit z)) (Val.int z) :=
  EvalsValO.lit hM

theorem add {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.add a b)) (Val.int (x + y)) :=
  EvalsValO.bin ha hb rfl hM

theorem sub {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x - y)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.sub a b)) (Val.int (x - y)) :=
  EvalsValO.bin ha hb rfl hM

theorem mul {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hM : valSize (Val.int (x * y)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.mul a b)) (Val.int (x * y)) :=
  EvalsValO.bin ha hb rfl hM

theorem div {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.div a b)) (Val.int (x / y)) :=
  EvalsValO.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem mod {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x % y)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.mod a b)) (Val.int (x % y)) :=
  EvalsValO.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem lt {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.lt a b))
      (Val.int (if x < y then 1 else 0)) :=
  EvalsValO.bin ha hb rfl (by split_ifs <;> simp <;> omega)

theorem eq {a b : Expr} {ba bb : List Bool} {x y : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int y)) (hM : 2 ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.eq a b))
      (Val.int (if x = y then 1 else 0)) :=
  EvalsValO.bin ha hb rfl (by split_ifs <;> simp <;> omega)

/-- `Arith.eTriple a b c` builds `[x, y, z]`. -/
theorem triple {a b c : Expr} {ba bb bc : List Bool} {x y z : Val}
    (ha : EvalsValO orc prog M env ba (.inl a) x) (hb : EvalsValO orc prog M env bb (.inl b) y)
    (hc : EvalsValO orc prog M env bc (.inl c) z) (hM : valSize (Val.list [x, y, z]) ≤ M) :
    EvalsValO orc prog M env (ba ++ (bb ++ bc)) (.inl (Arith.eTriple a b c))
      (Val.list [x, y, z]) := by
  have h0 : valSize (Val.list []) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h1 : valSize (Val.list [z]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h2 : valSize (Val.list [y, z]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hz := EvalsValO.cons hc (EvalsValO.nil h0) h1
  rw [List.append_nil] at hz
  exact EvalsValO.cons ha (EvalsValO.cons hb hz h2) hM

/-! ### Calls and the oracle -/

/-- A key with a body is not the oracle index (when the program has no body there). -/
theorem ne_oracle_of_some {i : ℕ} {body : Expr} (hO : prog[bsOracleIdx]? = none)
    (hbody : prog[i]? = some body) : i ≠ bsOracleIdx := by
  rintro rfl
  rw [hO] at hbody
  cases hbody

/-- The call rule with `hO : prog[bsOracleIdx]? = none` in place of `i ≠ bsOracleIdx`. -/
theorem call {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
    (hO : prog[bsOracleIdx]? = none) (ha : EvalsValO orc prog M env ba (.inl a) va)
    (hbody : prog[i]? = some body) (hb : EvalsValO orc prog M [va] bb (.inl body) vb) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.call i a)) vb :=
  EvalsValO.call (ne_oracle_of_some hO hbody) ha hbody hb

/-- The `ImplementsO` call rule with a deterministic argument, taking `hO`. -/
theorem implementsO_call_det {α : Type} {argE : Expr} {x : Val} {enc : α → Val} {p : BitProg α}
    {i : ℕ} {body : Expr} (hO : prog[bsOracleIdx]? = none) (hbody : prog[i]? = some body)
    (hA : EvalsValO orc prog M env [] (.inl argE) x) (hf : ImplementsO orc prog M [x] body enc p) :
    ImplementsO orc prog M env (Expr.call i argE) enc p :=
  F2e2e.BSpace.implementsO_call_det (ne_oracle_of_some hO hbody) hbody hA hf

/-- The oracle on an argument built by `Arith.eTriple`. -/
theorem oracle_triple {a b c : Expr} {ba bb bc : List Bool} {sel r q : ℤ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.int sel))
    (hb : EvalsValO orc prog M env bb (.inl b) (Val.int r))
    (hc : EvalsValO orc prog M env bc (.inl c) (Val.int q))
    (hM : valSize (Val.list [Val.int sel, Val.int r, Val.int q]) ≤ M)
    (hMo : valSize (Val.int (orc sel r q)) ≤ M) :
    EvalsValO orc prog M env (ba ++ (bb ++ bc)) (.inl (Expr.call bsOracleIdx (Arith.eTriple a b c)))
      (Val.int (orc sel r q)) :=
  EvalsValO.oracle (triple ha hb hc hM) hMo

/-! ### Lifting and symbolic evaluation -/

/-- Any `EvalsVal` evaluation lifts (program without a body at the oracle index). -/
theorem lift (hO : prog[bsOracleIdx]? = none) {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsVal prog M env bits t v) : EvalsValO orc prog M env bits t v :=
  EvalsValO.of_evalsVal hO h

/-- **Symbolic evaluation** of oracle-free code on the tape `bits`: compute `eval` with an explicit
fuel (e.g. by `simp` with the `eval_succ_*` lemmas) and bound the peak by `base + M`. -/
theorem of_evalT (hO : prog[bsOracleIdx]? = none) {base : ℕ} {bits : List Bool} {e : Expr}
    {v : Val} (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env bits e = some (v, c, p, []) ∧ p ≤ base + M) :
    EvalsValO orc prog M env bits (.inl e) v :=
  EvalsValO.of_evalsVal hO (EvalsVal.of_evalT fuel h)

/-- **Symbolic evaluation** of deterministic oracle-free code (see `of_evalT`). -/
theorem of_eval (hO : prog[bsOracleIdx]? = none) {base : ℕ} {e : Expr} {v : Val} (fuel : ℕ)
    (h : ∃ c p, eval prog fuel base env [] e = some (v, c, p, []) ∧ p ≤ base + M) :
    EvalsValO orc prog M env [] (.inl e) v :=
  of_evalT hO fuel h

end bsC

end F2e2e.BSpace
