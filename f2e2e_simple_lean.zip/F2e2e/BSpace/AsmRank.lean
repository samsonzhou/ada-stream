import F2e2e.BSpace.AsmTable

/-!
# B_space, layer D5: the rank certificate and the machine constants of the B programs

Owner: NEW-B (96916dcd), for the B_space area lead W4 (cc77ceaa); plan `F2e2e/BSpace/BSPACE_PLAN.md` §D (D5).
Modelled on C-SPACE's `F2e2e/C/Impl/AsmRank.lean` (Theorem (C)).

* The **rank certificate** of the generic space theorem with the oracle (`RankOK`, `F2e2e/Cost/Generic.lean`;
  consumed by C-SPACE's M\* `runsWithinBitsO_of_evalsValO`, `F2e2e/BSpace/MachineStarO.lean`): the ranks `bsRank`
  are computed by the kernel from the call graph of `bsTable` itself (a depth-first search, "rank = `1 +` the
  largest rank of a callee", `0` without callees; the oracle index `bsOracleIdx = 1000` has no body, hence rank
  `0`, below every routine that calls it). The entry point `0` gets `bsR0 = 15`, above every routine. They are
  checked in ONE kernel evaluation, one walk per body (`bsRankCheck_ok`, `bsAsmOkB_sound`,
  `bsAsm_rankOK_mkProg`), with the depth bound `bsK = 60` (`bsRankOK_init`, `bsRankOK_round`).
* The peak factor at the entry point: `(r₀ + 1)(K + 3) + 1 = 16 · 63 + 1 = 1009 ≤ 2^10` (`bsAsm_D_eq`,
  `bsAsm_D_le`).
* The constants of the machine bridge (`bitsFactor` / `bitsConst`, `F2e2e/Cost/MachineBits.lean`): `progDepth ≤ 59`
  (heights are depths minus one; `bsInitProg_progDepth_le`, `bsRoundProg_progDepth_le`), `|prog| + 1 ≤ 2^10` (keys
  `≤ 999`; `bsInitProg_length_succ_le`, `bsRoundProg_length_succ_le`), hence `bitsFactor ≤ 60 · 198 = 11880` and
  `bitsConst ≤ 60 · 195 + 1 = 11701` (`bsInitProg_bits_le`, `bsRoundProg_bits_le`). These meet the hypotheses of
  C-SPACE's `bsMachineBound_le` (`F2e2e/BSpace/BoundSpace.lean`) with `Dp = 59`, `w = 10`.

Measured on the current tables (13:50Z): 112 entries, largest key 920, largest body depth 51 (`body_adaPub`), entry
bodies of depth 8 (`body_bsInit`) and 15 (`body_bsRound`), largest rank 13 (`adaInterval`, `adaNumerical`). The tight
values would be `r₀ = 14`, `K = 51`; `bsR0` and `bsK` leave headroom. If a table outgrows them, `bsRankCheck_ok` fails
(raise the literal).

**Kernel cost.** All finite checks are `decide +kernel` (kernel reduction only; nothing added to the trusted base),
about 1 s in total. Only numerals `≤ 1000` are reduced (no big numerals, no powers of two). The memo of the search and
the callee lists are binary tries over the bits of the keys (`BsAsmTrie`, depth 10): a lookup takes 10 `Nat.beq`
steps, not a walk through the table. Only the result of the search matters, not how it was found: the check walks
the actual bodies (`bsAsmOkB`, checking depth and callee ranks in one pass).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Binary tries over the keys (a light memo for the kernel) -/

/-- A binary trie of values indexed by natural numbers: bit `i` of the key chooses the branch at depth `i`, and a
leaf holds the value of all keys below it. Keys `< 2^10` are told apart at depth `10`. -/
inductive BsAsmTrie (α : Type) : Type where
  | leaf : α → BsAsmTrie α
  | node : BsAsmTrie α → BsAsmTrie α → BsAsmTrie α

namespace BsAsmTrie

/-- The value at the key `j`. -/
def get {α : Type} : BsAsmTrie α → ℕ → α
  | leaf v, _ => v
  | node l r, j => bif Nat.beq (j % 2) 0 then get l (j / 2) else get r (j / 2)

/-- Set the value at the key `j` (the path of `j` is split down to depth `d`). -/
def set {α : Type} : ℕ → BsAsmTrie α → ℕ → α → BsAsmTrie α
  | 0, _, _, v => leaf v
  | d + 1, leaf w, j, v =>
      bif Nat.beq (j % 2) 0 then node (set d (leaf w) (j / 2) v) (leaf w)
      else node (leaf w) (set d (leaf w) (j / 2) v)
  | d + 1, node l r, j, v =>
      bif Nat.beq (j % 2) 0 then node (set d l (j / 2) v) r else node l (set d r (j / 2) v)

end BsAsmTrie

/-! ## The ranks, computed from the call graph of `bsTable` -/

/-- The routines called or looped by an expression (with repetitions). -/
def bsAsmCallees : Expr → List ℕ
  | Expr.bin _ a b => bsAsmCallees a ++ bsAsmCallees b
  | Expr.un _ a => bsAsmCallees a
  | Expr.ite c t f => bsAsmCallees c ++ bsAsmCallees t ++ bsAsmCallees f
  | Expr.letE a b => bsAsmCallees a ++ bsAsmCallees b
  | Expr.call j a => j :: bsAsmCallees a
  | Expr.loop j a => j :: bsAsmCallees a
  | _ => []

/-- The callees of every routine of `bsTable` (the first entry of a key wins; `[]` for keys without a body, e.g.
the oracle index). -/
def bsAsmCalleeTrie : BsAsmTrie (List ℕ) :=
  bsTable.foldr (fun e t => t.set 10 e.1 (bsAsmCallees e.2)) (BsAsmTrie.leaf [])

/-- Depth-first computation of the ranks of the routine `j` and of every routine it calls, with fuel `f` (a bound
on the call depth). The memo holds `rank i + 1` at every finished routine `i` (`0`: not yet computed); the rank of
a routine is `1 +` the largest rank of its callees (`0` without callees). -/
def bsAsmDfs : ℕ → ℕ → BsAsmTrie ℕ → BsAsmTrie ℕ
  | 0, _, memo => memo
  | f + 1, j, memo =>
    bif Nat.beq (memo.get j) 0 then
      let res := (bsAsmCalleeTrie.get j).foldl
        (fun (acc : BsAsmTrie ℕ × ℕ) c =>
          let m := bsAsmDfs f c acc.1
          (m, max acc.2 (m.get c))) (memo, 0)
      res.1.set 10 j (res.2 + 1)
    else memo

/-- The ranks (plus one) of all routines of `bsTable` (memo of `bsAsmDfs` with fuel `32` from every key). -/
def bsRankMemo : BsAsmTrie ℕ := bsTable.foldl (fun m e => bsAsmDfs 32 e.1 m) (BsAsmTrie.leaf 0)

/-- The rank of the entry point `0` (above every routine: the largest rank is currently `13`). -/
def bsR0 : ℕ := 15

/-- **The ranks of the routines**: the longest call chain from each routine of `bsTable` (computed by the kernel
from the table itself, so it follows the areas' tables); the entry point `0` gets `bsR0`. Checked by
`bsRankCheck_ok`. -/
def bsRank (j : ℕ) : ℕ := if j = 0 then bsR0 else bsRankMemo.get j - 1

theorem bsRank_zero : bsRank 0 = 15 := rfl

/-- The depth bound of all bodies (the deepest body, W2's `body_adaPub`, has depth `51`). -/
def bsK : ℕ := 60

/-! ## The check: depth and callee ranks in one walk -/

/-- `bsAsmOkB r ρ d e`: `e` has depth `≤ d` and calls or loops only routines of rank `< ρ` (one walk). -/
def bsAsmOkB (r : ℕ → ℕ) (ρ : ℕ) : ℕ → Expr → Bool
  | 0, _ => false
  | d + 1, Expr.bin _ a b => bsAsmOkB r ρ d a && bsAsmOkB r ρ d b
  | d + 1, Expr.un _ a => bsAsmOkB r ρ d a
  | d + 1, Expr.ite c t f => bsAsmOkB r ρ d c && (bsAsmOkB r ρ d t && bsAsmOkB r ρ d f)
  | d + 1, Expr.letE a b => bsAsmOkB r ρ d a && bsAsmOkB r ρ d b
  | d + 1, Expr.call j a => decide (r j < ρ) && bsAsmOkB r ρ d a
  | d + 1, Expr.loop j a => decide (r j < ρ) && bsAsmOkB r ρ d a
  | _ + 1, _ => true

theorem bsAsmOkB_sound {r : ℕ → ℕ} {ρ : ℕ} :
    ∀ (e : Expr) (d : ℕ), bsAsmOkB r ρ d e = true → exprDepth e ≤ d ∧ CalleesLt r ρ e := by
  intro e
  induction e with
  | var i =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d => exact ⟨by simp only [exprDepth]; omega, trivial⟩
  | lit z =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d => exact ⟨by simp only [exprDepth]; omega, trivial⟩
  | nil =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d => exact ⟨by simp only [exprDepth]; omega, trivial⟩
  | coin =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d => exact ⟨by simp only [exprDepth]; omega, trivial⟩
  | bin op a b iha ihb =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB, Bool.and_eq_true] at h
      obtain ⟨ha1, ha2⟩ := iha d h.1
      obtain ⟨hb1, hb2⟩ := ihb d h.2
      exact ⟨by simp only [exprDepth]; omega, ha2, hb2⟩
  | un op a iha =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB] at h
      obtain ⟨ha1, ha2⟩ := iha d h
      exact ⟨by simp only [exprDepth]; omega, ha2⟩
  | ite c t f ihc iht ihf =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB, Bool.and_eq_true] at h
      obtain ⟨hc1, hc2⟩ := ihc d h.1
      obtain ⟨ht1, ht2⟩ := iht d h.2.1
      obtain ⟨hf1, hf2⟩ := ihf d h.2.2
      exact ⟨by simp only [exprDepth]; omega, hc2, ht2, hf2⟩
  | letE a b iha ihb =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB, Bool.and_eq_true] at h
      obtain ⟨ha1, ha2⟩ := iha d h.1
      obtain ⟨hb1, hb2⟩ := ihb d h.2
      exact ⟨by simp only [exprDepth]; omega, ha2, hb2⟩
  | call j a iha =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB, Bool.and_eq_true, decide_eq_true_eq] at h
      obtain ⟨ha1, ha2⟩ := iha d h.2
      exact ⟨by simp only [exprDepth]; omega, h.1, ha2⟩
  | loop j a iha =>
    intro d h
    cases d with
    | zero => simp [bsAsmOkB] at h
    | succ d =>
      simp only [bsAsmOkB, Bool.and_eq_true, decide_eq_true_eq] at h
      obtain ⟨ha1, ha2⟩ := iha d h.2
      exact ⟨by simp only [exprDepth]; omega, h.1, ha2⟩

/-- All conditions of the rank certificate in one Boolean (one kernel evaluation of the ranks): every table
entry and both entry bodies have depth `≤ bsK` and call only routines of smaller rank. -/
def bsRankCheckB : Bool :=
  bsTable.all (fun e => bsAsmOkB bsRank (bsRank e.1) bsK e.2) &&
    bsAsmOkB bsRank (bsRank 0) bsK body_bsInit && bsAsmOkB bsRank (bsRank 0) bsK body_bsRound

theorem bsRankCheck_ok : bsRankCheckB = true := by
  decide +kernel

theorem bsRank_facts : (∀ e ∈ bsTable, exprDepth e.2 ≤ bsK ∧ CalleesLt bsRank (bsRank e.1) e.2) ∧
    (exprDepth body_bsInit ≤ bsK ∧ CalleesLt bsRank (bsRank 0) body_bsInit) ∧
    (exprDepth body_bsRound ≤ bsK ∧ CalleesLt bsRank (bsRank 0) body_bsRound) := by
  have h := bsRankCheck_ok
  simp only [bsRankCheckB, Bool.and_eq_true, List.all_eq_true] at h
  obtain ⟨⟨h1, h2⟩, h3⟩ := h
  exact ⟨fun e he => bsAsmOkB_sound e.2 bsK (h1 e he), bsAsmOkB_sound _ _ h2, bsAsmOkB_sound _ _ h3⟩

/-! ## The rank certificates of the two programs -/

/-- **Rank certificate of the initialization program.** -/
theorem bsRankOK_init : RankOK bsInitProg bsRank bsK :=
  bsAsm_rankOK_mkProg (by decide) bsRank_facts.2.1 bsRank_facts.1

/-- **Rank certificate of the round program.** -/
theorem bsRankOK_round : RankOK bsRoundProg bsRank bsK :=
  bsAsm_rankOK_mkProg (by decide) bsRank_facts.2.2 bsRank_facts.1

/-- The peak factor of the generic space theorem at the entry point: `(r₀ + 1)(K + 3) + 1 = 1009`. -/
theorem bsAsm_D_eq : (bsRank 0 + 1) * (bsK + 3) + 1 = 1009 := rfl

/-- The peak factor at the entry point is at most `2^10` (C-SPACE's `bsMachineBound_le` asks for `2^20`). -/
theorem bsAsm_D_le : (bsRank 0 + 1) * (bsK + 3) + 1 ≤ 2 ^ 10 := by
  rw [bsAsm_D_eq]
  norm_num

/-! ## The constants of the machine bridge -/

/-- Every table body has machine height `≤ 59` (its depth minus one). -/
theorem bsTable_height_le : ∀ e ∈ bsTable, F2e2e.Machine.height e.2 ≤ 59 := fun e he => by
  have h1 := (bsRank_facts.1 e he).1
  have h2 := bsAsm_height_add_one e.2
  simp only [bsK] at h1
  omega

theorem bsInit_height_le : F2e2e.Machine.height body_bsInit ≤ 59 := by
  have h1 := bsRank_facts.2.1.1
  have h2 := bsAsm_height_add_one body_bsInit
  simp only [bsK] at h1
  omega

theorem bsRound_height_le : F2e2e.Machine.height body_bsRound ≤ 59 := by
  have h1 := bsRank_facts.2.2.1
  have h2 := bsAsm_height_add_one body_bsRound
  simp only [bsK] at h1
  omega

/-- **The machine depth of the initialization program**: `progDepth ≤ 59`. -/
theorem bsInitProg_progDepth_le : F2e2e.Machine.progDepth bsInitProg ≤ 59 :=
  bsAsm_progDepth_mkProg_le bsInit_height_le bsTable_height_le

/-- **The machine depth of the round program**: `progDepth ≤ 59`. -/
theorem bsRoundProg_progDepth_le : F2e2e.Machine.progDepth bsRoundProg ≤ 59 :=
  bsAsm_progDepth_mkProg_le bsRound_height_le bsTable_height_le

theorem bsInitProg_length_succ_le : bsInitProg.length + 1 ≤ 2 ^ 10 := by
  have h := bsInitProg_length_le
  norm_num
  omega

theorem bsRoundProg_length_succ_le : bsRoundProg.length + 1 ≤ 2 ^ 10 := by
  have h := bsRoundProg_length_le
  norm_num
  omega

/-- The bridge constants of a program of depth `≤ 59` with `|prog| + 1 ≤ 2^10`:
`bitsFactor = (D + 1)(⌈log₂(|prog| + 1)⌉ + 3D + 11) ≤ 60 · 198` and
`bitsConst = (D + 1)(⌈log₂(|prog| + 1)⌉ + 3D + 8) + 1 ≤ 60 · 195 + 1`. -/
theorem bsAsm_bits_le {prog : List Expr} (hD : F2e2e.Machine.progDepth prog ≤ 59)
    (hw : prog.length + 1 ≤ 2 ^ 10) :
    F2e2e.Machine.bitsFactor prog ≤ 11880 ∧ F2e2e.Machine.bitsConst prog ≤ 11701 := by
  have hc : Nat.clog 2 (prog.length + 1) ≤ 10 := Nat.clog_le_of_le_pow hw
  have h1 : F2e2e.Machine.progDepth prog + 1 ≤ 60 := by omega
  have h2 : Nat.clog 2 (prog.length + 1) + 3 * F2e2e.Machine.progDepth prog + 11 ≤ 198 := by omega
  have h3 : Nat.clog 2 (prog.length + 1) + 3 * F2e2e.Machine.progDepth prog + 8 ≤ 195 := by omega
  have e1 : F2e2e.Machine.bitsFactor prog = (F2e2e.Machine.progDepth prog + 1) *
      (Nat.clog 2 (prog.length + 1) + 3 * F2e2e.Machine.progDepth prog + 11) := by
    simp only [F2e2e.Machine.bitsFactor, F2e2e.Machine.frameC, F2e2e.Machine.posBits, fnWidth]
  have e2 : F2e2e.Machine.bitsConst prog = (F2e2e.Machine.progDepth prog + 1) *
      (Nat.clog 2 (prog.length + 1) + 3 * F2e2e.Machine.progDepth prog + 8) + 1 := by
    simp only [F2e2e.Machine.bitsConst, F2e2e.Machine.frameC, F2e2e.Machine.posBits, fnWidth]
  constructor
  · rw [e1]
    exact (Nat.mul_le_mul h1 h2).trans (by norm_num)
  · rw [e2]
    have := Nat.mul_le_mul h1 h3
    omega

/-- **The bridge constants of the initialization program.** -/
theorem bsInitProg_bits_le : F2e2e.Machine.bitsFactor bsInitProg ≤ 11880 ∧
    F2e2e.Machine.bitsConst bsInitProg ≤ 11701 :=
  bsAsm_bits_le bsInitProg_progDepth_le bsInitProg_length_succ_le

/-- **The bridge constants of the round program.** -/
theorem bsRoundProg_bits_le : F2e2e.Machine.bitsFactor bsRoundProg ≤ 11880 ∧
    F2e2e.Machine.bitsConst bsRoundProg ≤ 11701 :=
  bsAsm_bits_le bsRoundProg_progDepth_le bsRoundProg_length_succ_le

end F2e2e.BSpace
