import F2e2e.BSpace.O2GstLift
import F2e2e.Cost.Assembly

/-!
# B_space, route O2b, layer (i): weight certificates of assembled programs

Owner: O2B-GST (8cf19cc0). The weighted lifting (`EvalsValO.toF_wt`, `F2e2e/BSpace/O2GstLift.lean`) needs a
weight certificate `WeightOK prog w`: every routine `j` has `w j ≥ exprDepth body_j + 3 + w k` for each of its
callees `k`. This file gives
* `tblWeightB`, `tblWeightB_sound`, `weightOK_mkProg`: the certificate of an assembled program
  `mkProg main tbl` from a per-entry Boolean check (fillers `Expr.nil` need `w j ≥ 4`);
* `wCheckWB`, `weightOK_of_wCheckWB`: ONE Boolean for a given weight function;
* the weights computed by the kernel from the table itself: `o2wInfo` (depth and callees of every routine),
  `o2wDfs` / `o2wMemo` (a depth-first search; the weight of a routine is `exprDepth body + 3` plus the largest
  weight of a callee, i.e. the weighted length of its deepest call chain), `wProgOf memo main` (the weights of
  `mkProg main tbl`), and `weightOK_of_check`: `wCheckWB (wProgOf memo main) main tbl = true` (by
  `decide +kernel`) gives `WeightOK (mkProg main tbl) (wProgOf memo main)`. The search is not proved correct:
  the Boolean check verifies its output.

Kernel cost (as NEW-B's rank computation `F2e2e/BSpace/AsmRank.lean`): the memo and the routine information
are binary tries over the bits of the keys (`O2wTrie`, depth 10: keys `< 2^10`; a lookup takes 10 `Nat.beq`
steps), and only small numerals are reduced (weights, depths, keys).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Facts about `mkProg` (copies of C-SPACE's `F2e2e/C/Impl/AsmTable.lean`, prefix `o2w`) -/

/-- An entry found by `List.lookup` is an entry of the table. -/
theorem o2w_mem_of_lookup {tbl : List (ℕ × Expr)} {i : ℕ} {b : Expr} (h : tbl.lookup i = some b) :
    (i, b) ∈ tbl := by
  obtain ⟨l₁, l₂, htbl, -⟩ := List.lookup_eq_some_iff.mp h
  rw [htbl]
  simp

/-- Every body of `mkProg main tbl` is the entry body (index `0`), a body of the table at its own key, or the
filler `Expr.nil`. -/
theorem o2w_mkProg_get_cases {main : Expr} {tbl : List (ℕ × Expr)} {j : ℕ} {b : Expr}
    (h : (mkProg main tbl)[j]? = some b) : (j = 0 ∧ b = main) ∨ (j, b) ∈ tbl ∨ b = Expr.nil := by
  cases j with
  | zero =>
    left
    simp only [mkProg, List.getElem?_cons_zero, Option.some.injEq] at h
    exact ⟨rfl, h.symm⟩
  | succ j =>
    right
    simp only [mkProg, List.getElem?_cons_succ, List.getElem?_map] at h
    by_cases hj : j < tblMax tbl
    · rw [List.getElem?_range hj] at h
      simp only [Option.map_some, Option.some.injEq] at h
      cases hl : tbl.lookup (j + 1) with
      | none =>
        right
        rw [hl] at h
        exact h.symm
      | some b' =>
        left
        rw [hl] at h
        simp only [Option.getD_some] at h
        subst h
        exact o2w_mem_of_lookup hl
    · rw [List.getElem?_eq_none (by simpa using hj)] at h
      simp at h

/-! ## The certificate of an assembled program -/

/-- Boolean check of the weight certificate on the entries of a table. -/
def tblWeightB (w : ℕ → ℕ) (tbl : List (ℕ × Expr)) : Bool :=
  tbl.all fun e => decide (exprDepth e.2 + 3 ≤ w e.1) && calleesLeB w (w e.1 - (exprDepth e.2 + 3)) e.2

theorem tblWeightB_sound {w : ℕ → ℕ} {tbl : List (ℕ × Expr)} (h : tblWeightB w tbl = true) :
    ∀ e ∈ tbl, exprDepth e.2 + 3 ≤ w e.1 ∧ CalleesLe w (w e.1 - (exprDepth e.2 + 3)) e.2 := by
  intro e he
  have := List.all_eq_true.mp h e he
  simp only [Bool.and_eq_true, decide_eq_true_eq] at this
  exact ⟨this.1, (calleesLeB_iff w _ e.2).mp this.2⟩

/-- **Weight certificate of an assembled program** from its entry body and its table entries (the filler
`Expr.nil` has depth `1` and no callees). -/
theorem weightOK_mkProg {main : Expr} {tbl : List (ℕ × Expr)} {w : ℕ → ℕ} (hfill : ∀ j, 4 ≤ w j)
    (hmain : exprDepth main + 3 ≤ w 0 ∧ CalleesLe w (w 0 - (exprDepth main + 3)) main)
    (htbl : ∀ e ∈ tbl, exprDepth e.2 + 3 ≤ w e.1 ∧ CalleesLe w (w e.1 - (exprDepth e.2 + 3)) e.2) :
    WeightOK (mkProg main tbl) w := by
  intro j b hj
  rcases o2w_mkProg_get_cases hj with ⟨rfl, rfl⟩ | hmem | rfl
  · exact hmain
  · exact htbl _ hmem
  · exact ⟨by simpa [exprDepth] using hfill j, trivial⟩

/-- All conditions of the weight certificate of `mkProg main tbl` for the weights `w`, in one Boolean. -/
def wCheckWB (w : ℕ → ℕ) (main : Expr) (tbl : List (ℕ × Expr)) : Bool :=
  tblWeightB w tbl && (decide (exprDepth main + 3 ≤ w 0) && calleesLeB w (w 0 - (exprDepth main + 3)) main)

/-- **Weight certificate from one Boolean check.** -/
theorem weightOK_of_wCheckWB {w : ℕ → ℕ} {main : Expr} {tbl : List (ℕ × Expr)} (hfill : ∀ j, 4 ≤ w j)
    (h : wCheckWB w main tbl = true) : WeightOK (mkProg main tbl) w := by
  simp only [wCheckWB, Bool.and_eq_true, decide_eq_true_eq] at h
  exact weightOK_mkProg hfill ⟨h.2.1, (calleesLeB_iff _ _ _).mp h.2.2⟩ (tblWeightB_sound h.1)

/-! ## Binary tries over the keys (a light memo for the kernel; a copy of NEW-B's `BsAsmTrie`) -/

/-- A binary trie of values indexed by natural numbers: bit `i` of the key chooses the branch at depth `i`, and a
leaf holds the value of all keys below it. Keys `< 2^10` are told apart at depth `10`. -/
inductive O2wTrie (α : Type) : Type where
  | leaf : α → O2wTrie α
  | node : O2wTrie α → O2wTrie α → O2wTrie α

namespace O2wTrie

/-- The value at the key `j`. -/
def get {α : Type} : O2wTrie α → ℕ → α
  | leaf v, _ => v
  | node l r, j => bif Nat.beq (j % 2) 0 then get l (j / 2) else get r (j / 2)

/-- Set the value at the key `j` (the path of `j` is split down to depth `d`). -/
def set {α : Type} : ℕ → O2wTrie α → ℕ → α → O2wTrie α
  | 0, _, _, v => leaf v
  | d + 1, leaf w, j, v =>
      bif Nat.beq (j % 2) 0 then node (set d (leaf w) (j / 2) v) (leaf w)
      else node (leaf w) (set d (leaf w) (j / 2) v)
  | d + 1, node l r, j, v =>
      bif Nat.beq (j % 2) 0 then node (set d l (j / 2) v) r else node l (set d r (j / 2) v)

end O2wTrie

/-! ## Weights computed by the kernel -/

/-- The routines called or looped by an expression (with repetitions). -/
def wCallees : Expr → List ℕ
  | Expr.bin _ a b => wCallees a ++ wCallees b
  | Expr.un _ a => wCallees a
  | Expr.ite c t f => wCallees c ++ wCallees t ++ wCallees f
  | Expr.letE a b => wCallees a ++ wCallees b
  | Expr.call j a => j :: wCallees a
  | Expr.loop j a => j :: wCallees a
  | _ => []

/-- The depth and the callees of every routine of `tbl` (the first entry of a key wins; `(1, [])`, the filler
`Expr.nil`, for keys without a body, e.g. the oracle index). -/
def o2wInfo (tbl : List (ℕ × Expr)) : O2wTrie (ℕ × List ℕ) :=
  tbl.foldr (fun e t => t.set 10 e.1 (exprDepth e.2, wCallees e.2)) (O2wTrie.leaf (1, []))

/-- Depth-first computation of the weights of the routine `j` and of every routine it calls, with fuel `f` (a
bound on the call depth). The memo holds the weight of every finished routine (`0`: not yet computed; weights are
`≥ 4`). The weight of a routine is `exprDepth body + 3` plus the largest weight of its callees. -/
def o2wDfs (info : O2wTrie (ℕ × List ℕ)) : ℕ → ℕ → O2wTrie ℕ → O2wTrie ℕ
  | 0, _, memo => memo
  | f + 1, j, memo =>
    bif Nat.beq (memo.get j) 0 then
      let res := (info.get j).2.foldl
        (fun (acc : O2wTrie ℕ × ℕ) c =>
          let m := o2wDfs info f c acc.1
          (m, max acc.2 (m.get c))) (memo, 0)
      res.1.set 10 j ((info.get j).1 + 3 + res.2)
    else memo

/-- The weights of all routines of `tbl` (memo of `o2wDfs` with fuel `32` from every key). -/
def o2wMemo (tbl : List (ℕ × Expr)) : O2wTrie ℕ :=
  tbl.foldl (fun m e => o2wDfs (o2wInfo tbl) 32 e.1 m) (O2wTrie.leaf 0)

/-- The weight of the routine `j` read from a memo (at least `4`, the weight of the filler `Expr.nil`). -/
def wTblOf (memo : O2wTrie ℕ) (j : ℕ) : ℕ := max 4 (memo.get j)

/-- The weight of an entry body `main` over a memo of routine weights. -/
def wMainOf (memo : O2wTrie ℕ) (main : Expr) : ℕ :=
  exprDepth main + 3 + ((wCallees main).map (wTblOf memo)).foldr max 0

/-- **The weights of the program `mkProg main tbl`** from a memo (typically `o2wMemo tbl`): `wMainOf memo main`
at the entry point, `wTblOf memo j` elsewhere. -/
def wProgOf (memo : O2wTrie ℕ) (main : Expr) (j : ℕ) : ℕ :=
  if j = 0 then wMainOf memo main else wTblOf memo j

theorem four_le_wProgOf (memo : O2wTrie ℕ) (main : Expr) (j : ℕ) : 4 ≤ wProgOf memo main j := by
  unfold wProgOf wMainOf wTblOf
  split_ifs
  · have := one_le_exprDepth main
    omega
  · exact le_max_left _ _

/-- **Weight certificate from one Boolean check** for the weights read from a memo (prove the Boolean by
`decide +kernel`; define the memo as a top-level constant, e.g. `def myMemo := o2wMemo myTable`). -/
theorem weightOK_of_check (memo : O2wTrie ℕ) {main : Expr} {tbl : List (ℕ × Expr)}
    (h : wCheckWB (wProgOf memo main) main tbl = true) : WeightOK (mkProg main tbl) (wProgOf memo main) :=
  weightOK_of_wCheckWB (four_le_wProgOf memo main) h

/-! ## Sanity check: a three-routine program -/

/-- `main = call 1 (var 0)`, routine `1 = call 2 (var 0) + 1`, routine `2 = var 0`. -/
def o2wExampleTbl : List (ℕ × Expr) :=
  [(1, Expr.bin BinOp.add (Expr.call 2 (Expr.var 0)) (Expr.lit 1)), (2, Expr.var 0)]

/-- The memo of the example. -/
def o2wExampleMemo : O2wTrie ℕ := o2wMemo o2wExampleTbl

/-- The computed weights: `w 2 = 1 + 3`, `w 1 = 3 + 3 + w 2 = 10`, `w 0 = 2 + 3 + w 1 = 15`. -/
example : (wProgOf o2wExampleMemo (Expr.call 1 (Expr.var 0)) 0, wProgOf o2wExampleMemo (Expr.call 1 (Expr.var 0)) 1,
    wProgOf o2wExampleMemo (Expr.call 1 (Expr.var 0)) 2) = (15, 10, 4) := by decide +kernel

example : WeightOK (mkProg (Expr.call 1 (Expr.var 0)) o2wExampleTbl)
    (wProgOf o2wExampleMemo (Expr.call 1 (Expr.var 0))) :=
  weightOK_of_check o2wExampleMemo (by decide +kernel)

end F2e2e.BSpace
