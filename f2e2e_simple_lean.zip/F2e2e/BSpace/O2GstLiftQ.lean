import F2e2e.BSpace.O2GstLiftW
import F2e2e.BSpace.O2GstAsm

/-!
# B_space, route O2b, layer (i): the PRECISE generic space theorem for uniform value bounds

Owner: O2B-GST (8cf19cc0). The generic space theorem (`gst_auxO`, C-SPACE's per-call `gst_auxF`) charges each
frame `(exprDepth body + 2) · M` PLUS the budget of its callees: a SUM along the call chain. The big-step peak
itself is a MAX recursion: with every value `≤ M`, the peak above the base of evaluating `e` is at most
`qCoef Q e · M`, where

* `qCoef Q (var/lit/nil/coin) = 1`, `qCoef Q (un a) = max (qCoef Q a) 2`,
  `qCoef Q (bin a b) = max (qCoef Q a) (1 + qCoef Q b) 3`, `qCoef Q (letE a b) = max (qCoef Q a) (1 + qCoef Q b)`,
  `qCoef Q (ite c t f) = max (qCoef Q c) (qCoef Q t) (qCoef Q f)`,
* `qCoef Q (call j a) = qCoef Q (loop j a) = max (qCoef Q a) (1 + Q j)`,

for a **peak certificate** `QOK prog Q`: `Q j ≥ 1` and `qCoef Q body_j ≤ Q j` for every routine `j` (the
argument / accumulator is one value `≤ M` live under the callee's frame). A heavy call at a shallow position of
its caller costs `1 + Q j`, not `exprDepth caller + 2 + w j`. On the B tables (`F2e2e/BSpace/O2GstAsmB.lean`):
`Q(602) = 33`, `Q(603) = 32` (weights `231`, `240`), and both entry bodies `64` (weights `148`, `258`; ranks
`1008`).

* `gst_auxQ`, `EvalsValO.toSpTO_q`, `EvalsValO.loop_toSpTO_q`: the precise GST (EvalsSpTO / LoopSpTO forms).
* `EvalsValO.eval_entry_q`, `runsOnO_of_evalsValO_q`: at the entry point, peak `|input| + qCoef Q body · M`.
* `runsWithinBitsO_add_of_evalsValO_q`, `ImplementsO.runsWithinBitsO_add_q`: with the additive bridge.
* Calls / loops of routines proved at a uniform bound `M` from a NATIVE per-call frame at `(m, τ)`, at their
  precise peak (C-SPACE's constructors `EvalsValF.callSp` / `loopSp`): `EvalsValF.call_q`,
  `evalsValF_call_det_q`, `implementsF_call_q`, `implementsF_call_det_q` (cost `Q i · M ≤ τ`) and
  `EvalsValF.loop_q` (cost `(1 + Q i) · M ≤ τ`).
* The certificate: `qCheckB`, `qOK_mkProg_of_check` (one Boolean, `decide +kernel`), and the coefficients
  computed by the kernel from the table (`o2qMemo`, `qProgOf`; tries and small numerals only, as the weights).

**Switching a native frame from weights to precise callee peaks** (insurance lever of route O2b). At the call
of a routine `i` proved at a uniform bound `M` (spec `hb : EvalsValO orc prog M [va] bb (.inl body_i) vb`, e.g.
`EvalsValO.of_evalsVal hO h`, or `Implements.toO hO h` for `ImplementsO`), replace
`EvalsValF.call_wt hW hi ha hbody hb hva hvb (hτ : w i * M ≤ τ)` by
`EvalsValF.call_q hQ hi ha hbody hb hva hvam hvb (hτ : Q i * M ≤ τ)`, and likewise `evalsValF_call_det_wt` ↦
`evalsValF_call_det_q`, `implementsF_call_wt` ↦ `implementsF_call_q`, `implementsF_call_det_wt` ↦
`implementsF_call_det_q`; `hQ : QOK prog Q` (`bsQOK_round`, `bsQOK_init`), and the one extra hypothesis
`hvam : valSize va ≤ m` (the argument also fits the caller's frame). The call then costs `Q i · M` (`bsQ_vals`:
`Q 602 = 33`, `Q 603 = 32`) instead of `w i · M` (`231`, `240`). Only the `τ` derivation of that frame changes;
the frame's other rules stay as they are.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

/-! ## Precise peak coefficients and the certificate -/

/-- **Precise peak coefficient** of an expression (in units of the uniform value bound), given the
coefficients `Q` of the routines' bodies. -/
def qCoef (Q : ℕ → ℕ) : Expr → ℕ
  | Expr.var _ => 1
  | Expr.lit _ => 1
  | Expr.nil => 1
  | Expr.coin => 1
  | Expr.bin _ a b => max (max (qCoef Q a) (1 + qCoef Q b)) 3
  | Expr.un _ a => max (qCoef Q a) 2
  | Expr.ite c t f => max (qCoef Q c) (max (qCoef Q t) (qCoef Q f))
  | Expr.letE a b => max (qCoef Q a) (1 + qCoef Q b)
  | Expr.call j a => max (qCoef Q a) (1 + Q j)
  | Expr.loop j a => max (qCoef Q a) (1 + Q j)

/-- **Peak certificate**: every coefficient is `≥ 1` and every routine's coefficient bounds the precise peak
coefficient of its body. (It exists iff the call graph is acyclic.) -/
def QOK (prog : List Expr) (Q : ℕ → ℕ) : Prop :=
  (∀ j, 1 ≤ Q j) ∧ ∀ j body, prog[j]? = some body → qCoef Q body ≤ Q j

/-! ## The precise generic space theorem -/

/-- The statement proved by induction on `EvalsValO` (precise GST). -/
def GPropQ (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (Q : ℕ → ℕ) (M : ℕ) (env : List Val)
    (bits : List Bool) : Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ w ∈ env, valSize w ≤ M) → valSize v ≤ M ∧
      ∀ base, EvalsSpTO orc prog base env bits e v (base + qCoef Q e * M)
  | .inr (i, acc), w => valSize acc ≤ M → valSize w ≤ M ∧
      ∀ base, LoopSpTO orc prog base i acc bits w (base + (1 + Q i) * M)

theorem gst_auxQ {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {M : ℕ} (hQ : QOK prog Q)
    {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValO orc prog M env bits t v) : GPropQ orc prog Q M env bits t v := by
  induction h with
  | @var env i v hv =>
    simp only [GPropQ]
    intro henv
    have hv' : valSize v ≤ M := henv v (List.mem_of_getElem? hv)
    refine ⟨hv', fun base => (EvalsSpTO.var hv).mono ?_⟩
    simp only [qCoef]
    omega
  | @lit env z hM =>
    simp only [GPropQ]
    intro _
    refine ⟨hM, fun base => (EvalsSpTO.lit z).mono ?_⟩
    simp only [qCoef]
    omega
  | @nil env hM =>
    simp only [GPropQ]
    intro _
    refine ⟨hM, fun base => EvalsSpTO.nil.mono ?_⟩
    simp only [qCoef]
    omega
  | @coin env b hM =>
    simp only [GPropQ]
    intro _
    refine ⟨hM, fun base => (EvalsSpTO.coin b).mono ?_⟩
    simp only [qCoef]
    omega
  | @bin env op a b ba bb va vb v c ha hb hop hM iha ihb =>
    simp only [GPropQ] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb henv
    refine ⟨hM, fun base => (EvalsSpTO.bin (ha' base) (hb' (base + valSize va)) hop).mono ?_⟩
    simp only [qCoef]
    have e1 : qCoef Q a * M ≤ max (max (qCoef Q a) (1 + qCoef Q b)) 3 * M :=
      Nat.mul_le_mul_right _ ((le_max_left _ _).trans (le_max_left _ _))
    have e2 : (1 + qCoef Q b) * M ≤ max (max (qCoef Q a) (1 + qCoef Q b)) 3 * M :=
      Nat.mul_le_mul_right _ ((le_max_right _ _).trans (le_max_left _ _))
    have e3 : 3 * M ≤ max (max (qCoef Q a) (1 + qCoef Q b)) 3 * M :=
      Nat.mul_le_mul_right _ (le_max_right _ _)
    have e2' : (1 + qCoef Q b) * M = M + qCoef Q b * M := by ring
    exact max_le (max_le (by omega) (by omega)) (by omega)
  | @un env op a ba va v c ha hop hM iha =>
    simp only [GPropQ] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base => (EvalsSpTO.un (ha' base) hop).mono ?_⟩
    simp only [qCoef]
    have e1 : qCoef Q a * M ≤ max (qCoef Q a) 2 * M := Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : 2 * M ≤ max (qCoef Q a) 2 * M := Nat.mul_le_mul_right _ (le_max_right _ _)
    exact max_le (by omega) (by omega)
  | @ite env c t f bc bv z v hc hv ihc ihv =>
    simp only [GPropQ] at ihc ihv ⊢
    intro henv
    obtain ⟨-, hc'⟩ := ihc henv
    obtain ⟨hvv, hv'⟩ := ihv henv
    refine ⟨hvv, fun base => (EvalsSpTO.ite (hc' base) (hv' base)).mono ?_⟩
    have hbr : qCoef Q (if z ≠ 0 then t else f) ≤ max (qCoef Q t) (qCoef Q f) := by
      split_ifs
      · exact le_max_left _ _
      · exact le_max_right _ _
    simp only [qCoef]
    have e1 : qCoef Q c * M ≤ max (qCoef Q c) (max (qCoef Q t) (qCoef Q f)) * M :=
      Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : qCoef Q (if z ≠ 0 then t else f) * M ≤ max (qCoef Q c) (max (qCoef Q t) (qCoef Q f)) * M :=
      Nat.mul_le_mul_right _ (hbr.trans (le_max_right _ _))
    exact max_le (by omega) (by omega)
  | @letE env a b ba bb va vb ha hb iha ihb =>
    simp only [GPropQ] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    have henv' : ∀ w ∈ va :: env, valSize w ≤ M := by
      intro w hw
      rcases List.mem_cons.mp hw with rfl | hw
      · exact hva
      · exact henv w hw
    obtain ⟨hvb, hb'⟩ := ihb henv'
    refine ⟨hvb, fun base => (EvalsSpTO.letE (ha' base) (hb' (base + valSize va))).mono ?_⟩
    simp only [qCoef]
    have e1 : qCoef Q a * M ≤ max (qCoef Q a) (1 + qCoef Q b) * M := Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : (1 + qCoef Q b) * M ≤ max (qCoef Q a) (1 + qCoef Q b) * M :=
      Nat.mul_le_mul_right _ (le_max_right _ _)
    have e2' : (1 + qCoef Q b) * M = M + qCoef Q b * M := by ring
    exact max_le (by omega) (by omega)
  | @call env i a body ba bb va vb hi ha hbody hb iha ihb =>
    simp only [GPropQ] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb (by simpa using hva)
    refine ⟨hvb, fun base => (EvalsSpTO.call hi (ha' base) hbody (hb' (base + valSize va))).mono ?_⟩
    simp only [qCoef]
    have hqb : qCoef Q body * M ≤ Q i * M := Nat.mul_le_mul_right _ (hQ.2 i body hbody)
    have e1 : qCoef Q a * M ≤ max (qCoef Q a) (1 + Q i) * M := Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : (1 + Q i) * M ≤ max (qCoef Q a) (1 + Q i) * M := Nat.mul_le_mul_right _ (le_max_right _ _)
    have e2' : (1 + Q i) * M = M + Q i * M := by ring
    exact max_le (by omega) (by omega)
  | @oracle env a ba sel rr q ha hM iha =>
    simp only [GPropQ] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base => (EvalsSpTO.oracle (ha' base)).mono ?_⟩
    simp only [qCoef]
    have h1 := hQ.1 bsOracleIdx
    have e1 : qCoef Q a * M ≤ max (qCoef Q a) (1 + Q bsOracleIdx) * M :=
      Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : 2 * M ≤ max (qCoef Q a) (1 + Q bsOracleIdx) * M :=
      Nat.mul_le_mul_right _ ((show 2 ≤ 1 + Q bsOracleIdx by omega).trans (le_max_right _ _))
    exact max_le (by omega) (by omega)
  | @loop env i a ba bl va w ha hl iha ihl =>
    simp only [GPropQ] at iha ihl ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hw, hl'⟩ := ihl hva
    refine ⟨hw, fun base => (EvalsSpTO.loop (ha' base) (hl' base)).mono ?_⟩
    simp only [qCoef]
    have e1 : qCoef Q a * M ≤ max (qCoef Q a) (1 + Q i) * M := Nat.mul_le_mul_right _ (le_max_left _ _)
    have e2 : (1 + Q i) * M ≤ max (qCoef Q a) (1 + Q i) * M := Nat.mul_le_mul_right _ (le_max_right _ _)
    exact max_le (by omega) (by omega)
  | @stop i v body bb v' hbody hb ihb =>
    simp only [GPropQ] at ihb ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    refine ⟨?_, fun base => (LoopSpTO.stop hbody (hb' (base + valSize v))).mono ?_⟩
    · rw [valSize_flag_pair] at hpair
      omega
    · have hqb : qCoef Q body * M ≤ Q i * M := Nat.mul_le_mul_right _ (hQ.2 i body hbody)
      have e1 : (1 + Q i) * M = M + Q i * M := by ring
      omega
  | @cont i v body bb bw flag v' w hbody hb hflag hrest ihb ihr =>
    simp only [GPropQ] at ihb ihr ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    have hv' : valSize v' ≤ M := by
      rw [valSize_flag_pair] at hpair
      omega
    obtain ⟨hw, hr'⟩ := ihr hv'
    refine ⟨hw, fun base => (LoopSpTO.cont hbody (hb' (base + valSize v)) hflag (hr' base)).mono ?_⟩
    have hqb : qCoef Q body * M ≤ Q i * M := Nat.mul_le_mul_right _ (hQ.2 i body hbody)
    have e1 : (1 + Q i) * M = M + Q i * M := by ring
    exact max_le (by omega) le_rfl

/-- **Precise generic space theorem** (uniform value bound `M`, peak certificate `Q`): an `EvalsValO`
evaluation of `e` in an environment of values `≤ M` runs within peak `base + qCoef Q e · M`. -/
theorem EvalsValO.toSpTO_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {M : ℕ}
    (hQ : QOK prog Q) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) (base : ℕ) :
    EvalsSpTO orc prog base env bits e v (base + qCoef Q e * M) :=
  (gst_auxQ hQ h henv).2 base

/-- **Precise generic space theorem**, loop targets: peak `base + (1 + Q i) · M`. -/
theorem EvalsValO.loop_toSpTO_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {M : ℕ}
    (hQ : QOK prog Q) {i : ℕ} {acc w : Val} {bits : List Bool}
    (h : EvalsValO orc prog M [] bits (.inr (i, acc)) w) (hacc : valSize acc ≤ M) (base : ℕ) :
    LoopSpTO orc prog base i acc bits w (base + (1 + Q i) * M) :=
  (gst_auxQ hQ h hacc).2 base

/-- **Precise GST at the entry point**: the entry body evaluated on an input of size `≤ M`, consuming exactly
`bits`, runs on every tape `bits ++ rest`, leaving `rest`, with peak `≤ |input| + qCoef Q body · M`. -/
theorem EvalsValO.eval_entry_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {M : ℕ}
    (hQ : QOK prog Q) {body : Expr} {input out : Val} {bits : List Bool}
    (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) :
    ∃ fuel c p, p ≤ valSize input + qCoef Q body * M ∧
      ∀ rest, evalO orc prog fuel (valSize input) [input] (bits ++ rest) body = some (out, c, p, rest) :=
  h.toSpTO_q hQ (by simpa using hin) (valSize input)

/-- **Precise GST at the entry point, `RunsOnO` form.** -/
theorem runsOnO_of_evalsValO_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {M : ℕ}
    (hQ : QOK prog Q) {body : Expr} (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool}
    (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) (rest : List Bool) :
    RunsOnO orc prog input (bits ++ rest) out rest ((valSize input + qCoef Q body * M : ℕ) : ℝ) := by
  obtain ⟨fuel, c, p, hp, hf⟩ := h.eval_entry_q hQ hin
  exact ⟨body, fuel, c, p, h0, hf rest, by exact_mod_cast hp⟩

/-- **Precise GST + additive bridge.** -/
theorem runsWithinBitsO_add_of_evalsValO_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {Kd : ℕ} (hR : RankOK prog r Kd) {Q : ℕ → ℕ} (hQ : QOK prog Q) {body : Expr}
    (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool} {M : ℕ}
    (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest
      ((O2B.bridgeAdd prog (r 0) (valSize input + qCoef Q body * M) : ℕ) : ℝ) :=
  O2B.runsWithinBitsO_add_of_runsOnO hR (runsOnO_of_evalsValO_q hQ h0 h hin rest)

/-- **Precise GST + additive bridge, bit-program form.** -/
theorem ImplementsO.runsWithinBitsO_add_q {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {Kd : ℕ} (hR : RankOK prog r Kd) {Q : ℕ → ℕ} (hQ : QOK prog Q) {body : Expr}
    (h0 : prog[0]? = some body) {input : Val} {α : Type} {enc : α → Val} {p : BitProg α} {M : ℕ}
    (h : ImplementsO orc prog M [input] body enc p) (hin : valSize input ≤ M) {tape rest : List Bool}
    {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc prog input tape (enc a) rest
      ((O2B.bridgeAdd prog (r 0) (valSize input + qCoef Q body * M) : ℕ) : ℝ) := by
  obtain ⟨bits, rfl, hb⟩ := bitProg_run_split hrun
  exact runsWithinBitsO_add_of_evalsValO_q hR hQ h0 (h bits a hb) hin rest

/-! ## Precise calls from native per-call frames (C-SPACE's `callSp` / `loopSp`) -/

section CallPrecise

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Q : ℕ → ℕ} {m τ M : ℕ}

/-- **Call of a routine proved at a uniform bound `M`, at its precise peak**, from a native frame at `(m, τ)`:
the callee's `EvalsValO` evaluation (argument `≤ M`) runs within `qCoef Q body · M ≤ Q i · M` above its frame
base; the call costs `Q i · M ≤ τ`. -/
theorem EvalsValF.call_q (hQ : QOK prog Q) {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool}
    {va vb : Val} (hi : i ≠ bsOracleIdx) (ha : EvalsValF orc prog m τ env ba (.inl a) va)
    (hbody : prog[i]? = some body) (hb : EvalsValO orc prog M [va] bb (.inl body) vb)
    (hva : valSize va ≤ M) (hvam : valSize va ≤ m) (hvb : valSize vb ≤ m) (hτ : Q i * M ≤ τ) :
    EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.call i a)) vb :=
  EvalsValF.callSp hi ha hbody (fun base => hb.toSpTO_q hQ (by simpa using hva) base) hvam hvb
    ((Nat.mul_le_mul_right _ (hQ.2 i body hbody)).trans hτ)

/-- **Call of a deterministic routine proved at a uniform bound `M`, at its precise peak**, deterministic
argument. -/
theorem evalsValF_call_det_q (hQ : QOK prog Q) {env : List Val} {argE : Expr} {x v : Val} {i : ℕ}
    {body : Expr} (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : EvalsValF orc prog m τ env [] (.inl argE) x) (hf : EvalsValO orc prog M [x] [] (.inl body) v)
    (hva : valSize x ≤ M) (hvam : valSize x ≤ m) (hvb : valSize v ≤ m) (hτ : Q i * M ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (Expr.call i argE)) v := by
  simpa using EvalsValF.call_q hQ hi hA hbody hf hva hvam hvb hτ

/-- **Call of a routine implementing `f a` at a uniform bound `M`, at its precise peak** (`ImplementsO`), from
a native frame at `(m, τ)`: support predicate `S` on the argument, argument encodings `≤ M` and `≤ m`, outputs
`≤ m`; the call costs `Q i · M ≤ τ`. -/
theorem implementsF_call_q (hQ : QOK prog Q) {α β : Type} {env : List Val} {argE : Expr}
    {encA : α → Val} {encB : β → Val} {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr}
    (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body) (hA : ImplementsF orc prog m τ env argE encA pA)
    (S : α → Prop) (hS : ∀ bits a, pA.run bits = some (a, []) → S a)
    (hf : ∀ a, S a → ImplementsO orc prog M [encA a] body encB (f a))
    (hva : ∀ a, S a → valSize (encA a) ≤ M) (hvam : ∀ a, S a → valSize (encA a) ≤ m)
    (hvb : ∀ a, S a → ∀ bits b, (f a).run bits = some (b, []) → valSize (encB b) ≤ m)
    (hτ : Q i * M ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB (pA.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  have hs := hS b₁ a h1
  exact EvalsValF.call_q hQ hi (hA b₁ a h1) hbody (hf a hs b₂ c h2) (hva a hs) (hvam a hs)
    (hvb a hs b₂ c h2) hτ

/-- **Call of a routine implementing `p` at a uniform bound `M`, at its precise peak** (`ImplementsO`),
deterministic argument. -/
theorem implementsF_call_det_q (hQ : QOK prog Q) {β : Type} {env : List Val} {argE : Expr} {x : Val}
    {encB : β → Val} {p : BitProg β} {i : ℕ} {body : Expr} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : EvalsValF orc prog m τ env [] (.inl argE) x)
    (hf : ImplementsO orc prog M [x] body encB p) (hva : valSize x ≤ M) (hvam : valSize x ≤ m)
    (hvb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ m) (hτ : Q i * M ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB p := by
  intro bits c h
  simpa using EvalsValF.call_q hQ hi hA hbody (hf bits c h) hva hvam (hvb bits c h) hτ

/-- **Loop of a routine proved at a uniform bound `M`, at its precise peak**, from a native frame at `(m, τ)`:
the iterations (accumulator `≤ M`) run within `(1 + Q i) · M` above the caller's base; the loop costs
`(1 + Q i) · M ≤ τ`. -/
theorem EvalsValF.loop_q (hQ : QOK prog Q) {env : List Val} {i : ℕ} {a : Expr} {ba bl : List Bool}
    {va w : Val} (ha : EvalsValF orc prog m τ env ba (.inl a) va)
    (hl : EvalsValO orc prog M [] bl (.inr (i, va)) w) (hva : valSize va ≤ M) (hw : valSize w ≤ m)
    (hτ : (1 + Q i) * M ≤ τ) :
    EvalsValF orc prog m τ env (ba ++ bl) (.inl (Expr.loop i a)) w :=
  EvalsValF.loopSp ha (fun base => hl.loop_toSpTO_q hQ hva base) hw hτ

end CallPrecise

/-! ## The certificate of an assembled program -/

/-- Boolean check of the peak certificate of `mkProg main tbl` for the coefficients `Q` (besides `Q ≥ 1`). -/
def qCheckB (Q : ℕ → ℕ) (main : Expr) (tbl : List (ℕ × Expr)) : Bool :=
  tbl.all (fun e => decide (qCoef Q e.2 ≤ Q e.1)) && decide (qCoef Q main ≤ Q 0)

/-- **Peak certificate of an assembled program** from one Boolean check (fillers `Expr.nil` have coefficient
`1 ≤ Q j`). -/
theorem qOK_mkProg_of_check {Q : ℕ → ℕ} {main : Expr} {tbl : List (ℕ × Expr)} (hfill : ∀ j, 1 ≤ Q j)
    (h : qCheckB Q main tbl = true) : QOK (mkProg main tbl) Q := by
  simp only [qCheckB, Bool.and_eq_true, List.all_eq_true, decide_eq_true_eq] at h
  refine ⟨hfill, fun j b hj => ?_⟩
  rcases o2w_mkProg_get_cases hj with ⟨rfl, rfl⟩ | hmem | rfl
  · exact h.2
  · exact h.1 _ hmem
  · simpa [qCoef] using hfill j

/-! ## Coefficients computed by the kernel -/

/-- The body of every routine of `tbl` (the first entry of a key wins; `Expr.nil` for keys without a body). -/
def o2qBodies (tbl : List (ℕ × Expr)) : O2wTrie Expr :=
  tbl.foldr (fun e t => t.set 10 e.1 e.2) (O2wTrie.leaf Expr.nil)

/-- Depth-first computation of the coefficients of the routine `j` and of every routine it calls, with fuel `f`.
The memo holds the coefficient (`≥ 1`) of every finished routine (`0`: not yet computed). -/
def o2qDfs (bodies : O2wTrie Expr) : ℕ → ℕ → O2wTrie ℕ → O2wTrie ℕ
  | 0, _, memo => memo
  | f + 1, j, memo =>
    bif Nat.beq (memo.get j) 0 then
      let m := (wCallees (bodies.get j)).foldl (fun acc c => o2qDfs bodies f c acc) memo
      m.set 10 j (max 1 (qCoef (fun k => max 1 (m.get k)) (bodies.get j)))
    else memo

/-- The coefficients of all routines of `tbl` (memo of `o2qDfs` with fuel `32` from every key). -/
def o2qMemo (tbl : List (ℕ × Expr)) : O2wTrie ℕ :=
  tbl.foldl (fun m e => o2qDfs (o2qBodies tbl) 32 e.1 m) (O2wTrie.leaf 0)

/-- **The coefficients of the program `mkProg main tbl`** from a memo (typically `o2qMemo tbl`). -/
def qProgOf (memo : O2wTrie ℕ) (main : Expr) (j : ℕ) : ℕ :=
  if j = 0 then max 1 (qCoef (fun k => max 1 (memo.get k)) main) else max 1 (memo.get j)

theorem one_le_qProgOf (memo : O2wTrie ℕ) (main : Expr) (j : ℕ) : 1 ≤ qProgOf memo main j := by
  unfold qProgOf
  split_ifs <;> exact le_max_left _ _

/-- **Peak certificate from one Boolean check** for the coefficients read from a memo (prove the Boolean by
`decide +kernel`; define the memo as a top-level constant). -/
theorem qOK_of_check (memo : O2wTrie ℕ) {main : Expr} {tbl : List (ℕ × Expr)}
    (h : qCheckB (qProgOf memo main) main tbl = true) : QOK (mkProg main tbl) (qProgOf memo main) :=
  qOK_mkProg_of_check (one_le_qProgOf memo main) h

/-! ## Sanity check: a three-routine program -/

/-- The memo of the example of `F2e2e/BSpace/O2GstLiftW.lean` (`main = call 1 (var 0)`,
`1 = call 2 (var 0) + 1`, `2 = var 0`). -/
def o2qExampleMemo : O2wTrie ℕ := o2qMemo o2wExampleTbl

/-- `Q 2 = 1`, `Q 1 = max (1 + Q 2) (1 + 1) 3 = 3`, `Q 0 = max 1 (1 + Q 1) = 4` (weights: `4, 10, 15`). -/
example : (qProgOf o2qExampleMemo (Expr.call 1 (Expr.var 0)) 0, qProgOf o2qExampleMemo (Expr.call 1 (Expr.var 0)) 1,
    qProgOf o2qExampleMemo (Expr.call 1 (Expr.var 0)) 2) = (4, 3, 1) := by decide +kernel

example : QOK (mkProg (Expr.call 1 (Expr.var 0)) o2wExampleTbl)
    (qProgOf o2qExampleMemo (Expr.call 1 (Expr.var 0))) :=
  qOK_of_check o2qExampleMemo (by decide +kernel)

end F2e2e.BSpace
