import F2e2e.BSpace.DslEvalsMath
import F2e2e.BSpace.CalcORules
import F2e2e.C.Impl.W6Contracts
import F2e2e.Cost.Lib.RevAppend
import F2e2e.Cost.Arith.Helpers

/-!
# B_space, D2: the routine `bsEvals` (keys 910–912): bodies, table, sizes, reversal

Owner: 1beb339b (D2; area lead W4). Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §D (D2).

`bsEvals` computes the query table `evalsOf orc q blocks` (`F2e2e/BSpace/DslEvalsMath.lean`) of the stored
blocks of record codes, with one oracle call per record, by two flat loops. The results are accumulated in
reverse order and reversed by the library loop `revAppendStep` (key `4`):
* `body_bsEvals` (key 910): `[q, blocks] ↦ loop 911 [blocks, [], q + 1]`;
* `body_bsEvalsOuter` (key 911), accumulator `[blocks, accRev, q + 1]`: when no block is left, stop with
  `accRev` reversed; otherwise run the inner loop from `[block, [], q + 1]` and push its result;
* `body_bsEvalsInner` (key 912), accumulator `[codes, accRev, q + 1]`: when no code is left, stop with
  `accRev` reversed; otherwise ask the oracle `[0, r, q + 1]` about the first code `r` and push
  `(answer + 1) div 2`.
Call ranks: `revAppendStep` 0, 912: 1 (the oracle index is not a function of the program), 911: 2,
910: 3. The value bound is additive: input + output + `O(q)`.

This file: keys, bodies, `bsEvalsTable`, the entry function `bsE_g`, the loop accumulators, size lemmas,
and the reversal (`bsE_rev`). The loops and the specification: `F2e2e/BSpace/DslEvalsInner.lean` (912),
`F2e2e/BSpace/DslEvals.lean` (911, 910, `bsEvals_eval`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Keys, bodies, table -/

/-- Key of `bsEvals`: `[q, blocks] ↦ encVals (evalsOf orc q blocks)`. -/
abbrev bsE_evalsKey : ℕ := 910

/-- Key of the outer loop body of `bsEvals` (one block per iteration). -/
abbrev bsE_outerKey : ℕ := 911

/-- Key of the inner loop body of `bsEvals` (one record per iteration, one oracle call). -/
abbrev bsE_innerKey : ℕ := 912

/-- The first component of a list. -/
abbrev bsE1 (e : Expr) : Expr := Expr.un UnOp.head e

/-- The second component of a list. -/
abbrev bsE2 (e : Expr) : Expr := Expr.un UnOp.head (Expr.un UnOp.tail e)

/-- The third component of a list. -/
abbrev bsE3 (e : Expr) : Expr := Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail e))

/-- `l ↦ l.reverse`, by the library loop `revAppendStep` from the accumulator `[l, []]`. -/
abbrev bsERev (e : Expr) : Expr := Expr.loop Cost.Idx.revAppendStep (ePair e Expr.nil)

/-- **Inner loop body** (key 912), accumulator `[codes, accRev, q + 1]`: stop with `accRev` reversed when no
code is left; otherwise ask the oracle `[0, r, q + 1]` about the first code `r` (environment `[o, acc]`)
and continue with `[codes.tail, ((o + 1) div 2) :: accRev, q + 1]`. -/
def body_bsEvalsInner : Expr :=
  Expr.ite (Expr.un UnOp.isNil (bsE1 (Expr.var 0)))
    (ePair (Expr.lit 0) (bsERev (bsE2 (Expr.var 0))))
    (Expr.letE
      (Expr.call bsOracleIdx (Arith.eTriple (Expr.lit 0) (bsE1 (bsE1 (Expr.var 0))) (bsE3 (Expr.var 0))))
      (ePair (Expr.lit 1)
        (Arith.eTriple (Expr.un UnOp.tail (bsE1 (Expr.var 1)))
          (Expr.bin BinOp.cons
            (Expr.bin BinOp.div (Expr.bin BinOp.add (Expr.var 0) (Expr.lit 1)) (Expr.lit 2))
            (bsE2 (Expr.var 1)))
          (bsE3 (Expr.var 1)))))

/-- **Outer loop body** (key 911), accumulator `[blocks, accRev, q + 1]`: stop with `accRev` reversed when
no block is left; otherwise run the inner loop from `[block, [], q + 1]` (environment `[vs, acc]`) and
continue with `[blocks.tail, vs :: accRev, q + 1]`. -/
def body_bsEvalsOuter : Expr :=
  Expr.ite (Expr.un UnOp.isNil (bsE1 (Expr.var 0)))
    (ePair (Expr.lit 0) (bsERev (bsE2 (Expr.var 0))))
    (Expr.letE
      (Expr.loop bsE_innerKey (Arith.eTriple (bsE1 (bsE1 (Expr.var 0))) Expr.nil (bsE3 (Expr.var 0))))
      (ePair (Expr.lit 1)
        (Arith.eTriple (Expr.un UnOp.tail (bsE1 (Expr.var 1)))
          (Expr.bin BinOp.cons (Expr.var 0) (bsE2 (Expr.var 1)))
          (bsE3 (Expr.var 1)))))

/-- **`bsEvals`** (key 910): `[q, blocks] ↦` the outer loop from `[blocks, [], q + 1]`. -/
def body_bsEvals : Expr :=
  Expr.loop bsE_outerKey
    (Arith.eTriple (bsE2 (Expr.var 0)) Expr.nil (Expr.bin BinOp.add (bsE1 (Expr.var 0)) (Expr.lit 1)))

/-- The routines of `bsEvals` (with the library loop body `revAppendStep`). -/
def bsEvalsTable : List (ℕ × Expr) :=
  [(bsE_evalsKey, body_bsEvals), (bsE_outerKey, body_bsEvalsOuter), (bsE_innerKey, body_bsEvalsInner),
    (Cost.Idx.revAppendStep, Cost.body_revAppendStep)]

/-- The lookups of `bsEvals`'s routines. -/
structure BsEvalsLib (prog : List Expr) : Prop where
  evals : prog[bsE_evalsKey]? = some body_bsEvals
  outer : prog[bsE_outerKey]? = some body_bsEvalsOuter
  inner : prog[bsE_innerKey]? = some body_bsEvalsInner
  rev : prog[Cost.Idx.revAppendStep]? = some Cost.body_revAppendStep

theorem BsEvalsLib.of_table {prog : List Expr} (h : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) :
    BsEvalsLib prog :=
  ⟨h _ List.mem_cons_self, h _ (List.mem_cons_of_mem _ List.mem_cons_self),
    h _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)),
    h _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)))⟩

/-! ## The entries and the accumulators -/

/-- The grid index of the record code `r` (one entry of `evalsOf orc q`). -/
def bsE_g (orc : ℤ → ℤ → ℤ → ℤ) (q r : ℕ) : ℕ := ((orc 0 (r : ℤ) (q + 1) + 1) / 2).toNat

theorem evalsOf_eq_map (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (bs : List (List ℕ)) :
    evalsOf orc q bs = bs.map (List.map (bsE_g orc q)) := rfl

/-- The entry as the integer computed by the program. -/
theorem bsE_encN_g {orc : ℤ → ℤ → ℤ → ℤ} {q r : ℕ} (h0 : 0 ≤ orc 0 (r : ℤ) (q + 1)) :
    encN (bsE_g orc q r) = Val.int ((orc 0 (r : ℤ) (q + 1) + 1) / 2) := by
  unfold bsE_g encN
  rw [Int.toNat_of_nonneg (by omega)]

/-- The inner loop accumulator `[codes, accRev, q + 1]`. -/
def bsE_encInner (q : ℕ) (rest acc : List ℕ) : Val :=
  Val.list [encL encN rest, encL encN acc, Val.int ((q : ℤ) + 1)]

/-- The outer loop accumulator `[blocks, accRev, q + 1]`. -/
def bsE_encOuter (q : ℕ) (restB accB : List (List ℕ)) : Val :=
  Val.list [Val.list (restB.map (encL encN)), Val.list (accB.map (encL encN)), Val.int ((q : ℤ) + 1)]

theorem bsE_map_bind_cast (l : List ℕ) :
    (List.map (fun v : ℤ => Val.int v) do let a ← l; pure (a : ℤ)) =
      l.map fun n : ℕ => Val.int (n : ℤ) := by
  induction l with
  | nil => rfl
  | cons a l ih => simp_all

/-- `encVals` (W6) in `encL` form. -/
theorem bsE_encVals_eq (vals : List (List ℕ)) :
    C.Impl.encVals vals = Val.list (vals.map (encL encN)) := by
  unfold C.Impl.encVals encL encN
  congr 1
  apply List.map_congr_left
  intro blk _
  rw [bsE_map_bind_cast]

/-! ## Sizes -/

theorem bsE_vs_nil : valSize (Val.list []) = 1 := rfl

theorem bsE_vs_int0 : valSize (Val.int 0) = 1 := rfl

theorem bsE_vs_int1 : valSize (Val.int 1) = 2 := rfl

theorem bsE_vs_int2 : valSize (Val.int 2) = 3 := rfl

theorem bsE_vs_one (v : Val) : valSize (Val.list [v]) = valSize v + 2 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem bsE_vs_two (u v : Val) : valSize (Val.list [u, v]) = valSize u + valSize v + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem bsE_vs_three (u v w : Val) :
    valSize (Val.list [u, v, w]) = valSize u + valSize v + valSize w + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem bsE_vs_cons (x : Val) (l : List Val) :
    valSize (Val.list (x :: l)) = valSize x + 1 + valSize (Val.list l) := by
  simp only [valSize_list, listSize_cons]
  omega

theorem bsE_vs_append (l₁ l₂ : List Val) :
    valSize (Val.list (l₁ ++ l₂)) + 1 = valSize (Val.list l₁) + valSize (Val.list l₂) := by
  simp only [valSize_list, listSize_append]
  omega

theorem bsE_vs_reverse (l : List Val) : valSize (Val.list l.reverse) = valSize (Val.list l) := by
  simp only [valSize_list, listSize_reverse]

theorem bsE_vs_pos (l : List Val) : 1 ≤ valSize (Val.list l) := by
  simp only [valSize_list]
  omega

theorem bsE_vsL_cons {α : Type} (f : α → Val) (a : α) (l : List α) :
    valSize (Val.list ((a :: l).map f)) = valSize (f a) + 1 + valSize (Val.list (l.map f)) := by
  rw [List.map_cons, bsE_vs_cons]

theorem bsE_vsL_append {α : Type} (f : α → Val) (l₁ l₂ : List α) :
    valSize (Val.list ((l₁ ++ l₂).map f)) + 1 =
      valSize (Val.list (l₁.map f)) + valSize (Val.list (l₂.map f)) := by
  rw [List.map_append, bsE_vs_append]

theorem bsE_vsL_reverse {α : Type} (f : α → Val) (l : List α) :
    valSize (Val.list (l.reverse.map f)) = valSize (Val.list (l.map f)) := by
  rw [List.map_reverse, bsE_vs_reverse]

/-- The size of the oracle's precision `q + 1`. -/
theorem bsE_vsQ (q : ℕ) : valSize (Val.int ((q : ℤ) + 1)) ≤ q + 2 := by
  have h := bitLen_natCast_le (q + 1)
  push_cast at h
  simp only [valSize_int]
  omega

theorem bsE_vsN (n : ℕ) : valSize (encN n) ≤ n + 1 := by
  have h := bitLen_natCast_le n
  simp only [encN, valSize_int]
  omega

/-- The sizes around one oracle answer `o ∈ [0, 2^{q+1}]`: `o`, `o + 1` and `(o + 1) div 2`. -/
theorem bsE_vs_answer {q : ℕ} {o : ℤ} (h0 : 0 ≤ o) (h1 : o ≤ 2 ^ (q + 1)) :
    valSize (Val.int o) ≤ q + 3 ∧ valSize (Val.int (o + 1)) ≤ q + 3 ∧
      valSize (Val.int ((o + 1) / 2)) ≤ q + 3 := by
  have h2 : (2 : ℤ) ^ (q + 2) = 2 * 2 ^ (q + 1) := by ring
  have h5 : (1 : ℤ) ≤ 2 ^ q := one_le_pow₀ (by norm_num)
  have h4 : (2 : ℤ) ≤ 2 ^ (q + 1) := by rw [pow_succ]; linarith
  have e1 : bitLen o ≤ q + 2 := bitLen_le_of_abs_lt (by rw [abs_of_nonneg h0]; linarith)
  have e2 : bitLen (o + 1) ≤ q + 2 := bitLen_le_of_abs_lt (by rw [abs_of_nonneg (by linarith)]; linarith)
  have e3 : bitLen ((o + 1) / 2) ≤ q + 2 := (bitLen_ediv_le _ _).trans e2
  simp only [valSize_int]
  omega

/-- An entry `≤ 2^q` costs at most `q + 2`. -/
theorem bsE_vsN_le {q v : ℕ} (hv : v ≤ 2 ^ q) : valSize (encN v) ≤ q + 2 := by
  have h3 : (2 : ℤ) ^ q < 2 ^ (q + 1) := pow_lt_pow_right₀ (by norm_num) (by omega)
  have h2 : ((v : ℕ) : ℤ) ≤ 2 ^ q := by exact_mod_cast hv
  have : bitLen (v : ℤ) ≤ q + 1 :=
    bitLen_le_of_abs_lt (by rw [abs_of_nonneg (by positivity)]; linarith)
  simp only [encN, valSize_int]
  omega

/-- A block of entries `≤ 2^q`. -/
theorem bsE_vsE_le {q : ℕ} : ∀ (l : List ℕ), (∀ v ∈ l, v ≤ 2 ^ q) →
    valSize (encL encN l) ≤ (q + 3) * l.length + 1
  | [], _ => by simp [encL]
  | v :: l, h => by
    have hv := bsE_vsN_le (h v List.mem_cons_self)
    have ih := bsE_vsE_le l fun w hw => h w (List.mem_cons_of_mem _ hw)
    have e : valSize (encL encN (v :: l)) = valSize (encN v) + 1 + valSize (encL encN l) :=
      bsE_vsL_cons encN v l
    rw [e, List.length_cons, Nat.mul_succ]
    omega

/-- **An orc-free bound on the output of `bsEvals`** (answers in `[0, 2^{q+1}]`). -/
theorem valSize_encVals_evalsOf_le {orc : ℤ → ℤ → ℤ → ℤ} {q : ℕ} {blocks : List (List ℕ)}
    (hO : ∀ blk ∈ blocks, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) :
    valSize (C.Impl.encVals (evalsOf orc q blocks)) ≤
      (q + 3) * (blocks.map List.length).sum + 2 * blocks.length + 1 := by
  have hle := evalsOf_le hO
  rw [bsE_encVals_eq]
  have key : ∀ (vals : List (List ℕ)), (∀ blk ∈ vals, ∀ v ∈ blk, v ≤ 2 ^ q) →
      valSize (Val.list (vals.map (encL encN))) ≤
        (q + 3) * (vals.map List.length).sum + 2 * vals.length + 1 := by
    intro vals
    induction vals with
    | nil => intro _; simp
    | cons b vals ih =>
      intro h
      have hb := bsE_vsE_le b (h b List.mem_cons_self)
      have ih' := ih fun blk hblk => h blk (List.mem_cons_of_mem _ hblk)
      rw [bsE_vsL_cons, List.map_cons, List.sum_cons, List.length_cons, Nat.mul_add]
      omega
  have hlen : ((evalsOf orc q blocks).map List.length).sum = (blocks.map List.length).sum := by
    rw [evalsOf_map_length]
  have := key _ hle
  rw [hlen, evalsOf_length] at this
  exact this

/-! ## Reversal by the library loop `revAppendStep` -/

section rev

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

/-- The iterations of `revAppendStep` from `[A, B]` return `A.reverse ++ B`; every value is at most
`|A| + |B| + 8`. -/
theorem bsE_revStep_run (hR : prog[Cost.Idx.revAppendStep]? = some Cost.body_revAppendStep) :
    ∀ (A B : List Val), valSize (Val.list A) + valSize (Val.list B) + 8 ≤ M →
      EvalsValO orc prog M [] [] (.inr (Cost.Idx.revAppendStep, Val.list [Val.list A, Val.list B]))
        (Val.list (A.reverse ++ B))
  | [], B, hM => by
    rw [bsE_vs_nil] at hM
    show EvalsValO orc prog M [] [] (.inr (_, _)) (Val.list B)
    refine EvalsValO.stop hR ?_
    unfold Cost.body_revAppendStep
    refine EvalsValO.letE (EvalsValO.head (EvalsValO.var rfl) (by rw [bsE_vs_nil]; omega)) ?_
    refine bsC.ite_true (bsC.isNil_nil (EvalsValO.var rfl) (by omega)) one_ne_zero ?_
    refine EvalsValO.pair (EvalsValO.lit (by rw [bsE_vs_int0]; omega))
      (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl) (by rw [bsE_vs_one]; omega)) (by omega)) ?_
    rw [bsE_vs_two, bsE_vs_int0]
    omega
  | x :: A, B, hM => by
    rw [bsE_vs_cons] at hM
    have ih := bsE_revStep_run hR A (x :: B) (by rw [bsE_vs_cons]; omega)
    have hb : EvalsValO orc prog M [Val.list [Val.list (x :: A), Val.list B]] []
        (.inl Cost.body_revAppendStep)
        (Val.list [Val.int 1, Val.list [Val.list A, Val.list (x :: B)]]) := by
      unfold Cost.body_revAppendStep
      refine EvalsValO.letE (EvalsValO.head (EvalsValO.var rfl) (by rw [bsE_vs_cons]; omega)) ?_
      refine bsC.ite_false (bsC.isNil_cons (EvalsValO.var rfl) (by omega)) rfl ?_
      refine EvalsValO.pair (EvalsValO.lit (by rw [bsE_vs_int1]; omega))
        (EvalsValO.pair (EvalsValO.tail (EvalsValO.var rfl) (by omega))
          (EvalsValO.cons (EvalsValO.head (EvalsValO.var rfl) (by omega))
            (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl) (by rw [bsE_vs_one]; omega))
              (by omega))
            (by rw [bsE_vs_cons]; omega)) ?_) ?_
      · rw [bsE_vs_two, bsE_vs_cons]
        omega
      · rw [bsE_vs_two, bsE_vs_two, bsE_vs_cons, bsE_vs_int1]
        omega
    rw [show (x :: A).reverse ++ B = A.reverse ++ (x :: B) by simp]
    exact EvalsValO.cast_bits (EvalsValO.cont hR hb one_ne_zero ih) (by simp)

/-- **`bsERev e`** reverses the list computed by `e` (every value at most `|l| + 9`). -/
theorem bsE_rev (hR : prog[Cost.Idx.revAppendStep]? = some Cost.body_revAppendStep) {env : List Val}
    {e : Expr} {l : List Val} (he : EvalsValO orc prog M env [] (.inl e) (Val.list l))
    (hM : valSize (Val.list l) + 9 ≤ M) :
    EvalsValO orc prog M env [] (.inl (bsERev e)) (Val.list l.reverse) := by
  have h1 := bsE_revStep_run (orc := orc) (M := M) hR l [] (by rw [bsE_vs_nil]; omega)
  rw [List.append_nil] at h1
  have hp : EvalsValO orc prog M env [] (.inl (ePair e Expr.nil)) (Val.list [Val.list l, Val.list []]) :=
    EvalsValO.cast_bits (EvalsValO.pair he (EvalsValO.nil (by rw [bsE_vs_nil]; omega))
      (by rw [bsE_vs_two, bsE_vs_nil]; omega)) (by simp)
  exact EvalsValO.cast_bits (EvalsValO.loop hp h1) (by simp)

end rev

end F2e2e.BSpace
