import F2e2e.BSpace.O2BridgeSim

/-!
# O2b additive bridge, part 3: the headline (17fc0802)

`runsWithinBitsO_add_of_runsOnO`. Assume a rank certificate `RankOK prog r Kd` and a run of the oracle big-step
semantics within `S` tree units, `RunsOnO orc prog input tape out rest S`. Then the oracle machine of Spec v3 §7
halts with the same output and unread tape, and every step's charge (its footprint, its arithmetic workspace and
its finite-control temporaries) is at most `bridgeAdd prog (r 0) S`, where (`D = progDepth prog`,
`fc = frameC prog = fnWidth prog + 3D + 6`):

* `addTop prog ρ S = 2(D+1)·S + 3(D+1) + (ρ+1)(D+1)(fc+4) + 1` bounds every configuration (`top_bounds`);
* `bridgeAdd prog ρ S = 2·addTop prog ρ S + 16(S+1) + 128 + 4⌈log₂(2·addTop prog ρ S + 16(S+1) + 66)⌉`.

So the charge is `(4(D+1) + 16)·S + 2(ρ+1)(D+1)(fc+4) + O(D + log S)`: linear in the peak with the env-copy factor
`4(D+1)`, and an additive frame term per activation level. The coarse bridge
(`runsWithinBitsO_of_runsOnO`, `(bridgeWC+2)·bitsFactor ≈ 50·(D+1)(fc+5)`) had the frame overhead `fc` in front
of `S`.
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine F2e2e.Cost F2e2e.BSpace.MachineO

/-- The additive bound on every configuration of a top-level run at level `ρ` with peak `S`. -/
def addTop (prog : List Expr) (ρ S : ℕ) : ℕ :=
  2 * (progDepth prog + 1) * S + 3 * (progDepth prog + 1) +
    (ρ + 1) * (progDepth prog + 1) * (frameC prog + 4) + 1

/-- The additive bridge bound on the charge of every step of a top-level run at level `ρ` with peak `S`. -/
def bridgeAdd (prog : List Expr) (ρ S : ℕ) : ℕ :=
  2 * addTop prog ρ S + 16 * (S + 1) + 128 + 4 * Nat.clog 2 (2 * addTop prog ρ S + 16 * (S + 1) + 66)

/-- The top-level simulation bound `addB` is within `addTop` (minus the stack terminator). -/
theorem addB_top_le {prog : List Expr} {body : Expr} {input : Val} {peak S ρ : ℕ}
    (hD : height body ≤ progDepth prog) (hin : valSize input ≤ peak) (hS : peak ≤ S) :
    addB prog (height body) [input] (peak - valSize input) ρ + 1 ≤ addTop prog ρ S := by
  unfold addB addTop
  rw [bitEncodeVals_singleton_length]
  have hv := bitEncodeVal_length_le2 input
  set E := progDepth prog + 1
  set fc := frameC prog
  have h1 : (height body + 1) * ((bitEncodeVal input).length + 2 + fc + 4) ≤
      E * (2 * valSize input + 3 + (fc + 4)) := Nat.mul_le_mul (by omega) (by omega)
  have h2 : E * (2 * valSize input + 3 + (fc + 4)) =
      2 * E * valSize input + 3 * E + E * (fc + 4) := by ring
  have h3 : 2 * E * valSize input + 2 * E * (peak - valSize input) ≤ 2 * E * S := by
    rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ (by omega)
  have h4 : ρ * E * (fc + 4) + E * (fc + 4) = (ρ + 1) * E * (fc + 4) := by ring
  omega

/-- The operand clause at the top level bounds the arithmetic operands: `opBits ≤ 2(δ + 1)`. -/
theorem opBits_le_of_opsOK {d : Conf} {δ : ℕ} (h : OpsOK [] δ d) : opBits d ≤ 2 * (δ + 1) := by
  obtain ⟨ctrl, stack, t⟩ := d
  cases ctrl with
  | eval p env => simp [opBits]
  | ret w =>
    cases stack with
    | nil => simp [opBits]
    | cons f K =>
      cases f with
      | binR p va =>
        have hs := h w p va K rfl rfl (Nat.zero_le _)
        have h1 := bitEncodeVal_length_le2 va
        have h2 := bitEncodeVal_length_le2 w
        cases w with
        | int b =>
          cases va with
          | int a =>
            simp only [opBits]
            omega
          | list l => simp [opBits]
        | list l => cases va <;> simp [opBits]
      | binL p env => simp [opBits]
      | un p => simp [opBits]
      | ite p env => simp [opBits]
      | letE p env => simp [opBits]
      | callArg p => simp [opBits]
      | loopInit p => simp [opBits]
      | loopIter p => simp [opBits]

/-- Every configuration of the oracle-machine run of a `RunsOnO` run has at most `addTop prog (r 0) S` bits, and
its arithmetic operands have `opBits ≤ 2(S + 1)`. -/
theorem top_bounds {orc : VOracle} {prog : List Expr} {input : Val} {tape : List Bool} {out : Val}
    {rest : List Bool} {S : ℕ} {r : ℕ → ℕ} {Kd : ℕ} (hR : RankOK prog r Kd)
    (h : RunsOnO orc prog input tape out rest (S : ℝ)) :
    ∃ n : ℕ, stepNO orc prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩ ∧
      ∀ k ≤ n, ∀ c : Conf, stepNO orc prog k (initConf input tape) = some c →
        confBits prog c ≤ addTop prog (r 0) S ∧ opBits c ≤ 2 * (S + 1) := by
  obtain ⟨body, fuel, cost, peak, hbody, heval, hpeak⟩ := h
  have hpS : peak ≤ S := by exact_mod_cast hpeak
  have hroot : exprAt prog ⟨0, []⟩ = some body := exprAt_root hbody
  have hcb : CalleesLt r (r 0) body := (hR 0 body hbody).2
  have hpk : valSize input + valSize out ≤ peak := evalO_peak_ge orc prog fuel _ _ _ _ _ heval
  obtain ⟨n, hn, hall⟩ := (simA orc prog hR fuel).1 (valSize input) [input] tape body out cost peak rest
    ⟨0, []⟩ [] (r 0) heval hroot hcb
  refine ⟨n, hn, fun k hk d hd => ?_⟩
  obtain ⟨⟨F, hs, hb⟩, hops, -⟩ := hall k hk d hd
  have htop := addB_top_le (ρ := r 0) (height_le_progDepth hbody) (show valSize input ≤ peak by omega) hpS
  refine ⟨?_, ?_⟩
  · have hconf : confBits prog d = (encodeCtrl prog d.ctrl).length + framesBits prog F + 1 := by
      rw [confBits_eq, hs, encodeStack_append_length, encodeStack_nil_length]
      omega
    omega
  · have := opBits_le_of_opsOK hops
    omega

/-- **The O2b additive bridge.** Assume a rank certificate and a run of the oracle big-step semantics within `S`
tree units. Then there is a run of §7's oracle machine with the same output and unread tape, in which every
step's footprint plus arithmetic workspace plus finite-control temporaries is at most `bridgeAdd prog (r 0) S`
bits. -/
theorem runsWithinBitsO_add_of_runsOnO {orc : VOracle} {prog : List Expr} {input : Val} {tape : List Bool}
    {out : Val} {rest : List Bool} {S : ℕ} {r : ℕ → ℕ} {Kd : ℕ} (hR : RankOK prog r Kd)
    (h : RunsOnO orc prog input tape out rest (S : ℝ)) :
    RunsWithinBitsO orc prog input tape out rest ((bridgeAdd prog (r 0) S : ℕ) : ℝ) := by
  obtain ⟨n, hn, hb⟩ := top_bounds hR h
  exact runsWithinBitsO_of_bounds (Bc := addTop prog (r 0) S) (Bi := S + 1) hn hb

end F2e2e.BSpace.O2B
