import F2e2e.BSpace.BoundSpace
import F2e2e.BSpace.BoundValue
import F2e2e.BSpace.BoundParams
import F2e2e.BSpace.PubBound

/-!
# B_space, S2 (B-ARCH): the final inequality

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §S2 (area lead W4; the generic machine estimate is C-SPACE's,
`F2e2e/BSpace/BoundSpace.lean`). Notation: `A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R`,
`χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq)`, `N = (alg2Params M J R aReq ξReq).N`, for
`0 < aReq < 1/10` and `0 < ξReq < 1/2`.

* `bsMB_le_final`: S1's value bound (B-ACC, `F2e2e/BSpace/BoundValue.lean`)
  `bsMB = 2^33 adaBoundA A + bsPubBound + 2^4 (N + 4)(b_𝒰 + 4)` is at most `2^56 · N · (b_𝒰 + χ²)`.
  It uses S3 (`adaBoundA A ≤ 2^22 N χ`, `60 < χ`, `p + 16 ≤ N`; `F2e2e/BSpace/BoundParams.lean`) and
  the parameter record's bound `bsPubBound ≤ 2^32 adaBoundA A` (W3's `bsPubBound_le`), which is taken as
  a hypothesis here until W2's switch `bsPubBound := 2^20 bsPubL²` lands.
* `bs_machineBound_le_final`: for every program of depth `≤ 2^10` with `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`,
  and peak factor `(r 0 + 1)(K + 3) + 1 ≤ 2^20`, the oracle machine bound at the value bound `bsMB` is
  `bsMachineBound prog r K bsMB ≤ 2^51 · bsMB ≤ 2^107 · N · (b_𝒰 + χ²)`. Here `2^51` is C-SPACE's
  `bsMachineBound_le` and `2^56` comes from `bsMB_le_final`.
* `bs_machineBound_le_of_const`: the same against any final constant `C ≥ 2^107`;
* **`bs_machineBound_le_bSpaceBound`**: against Spec v3's `bSpaceBound e N b_𝒰 χ = 2^e N (b_𝒰 + χ²)` for
  every exponent `e ≥ bsChainExp = 107` (the parameter record's bound discharged by W3's
  `bsPubBound_le`). The program constants of D5 (NEW-B's `AsmRank.lean`: depth `≤ 59`, `|prog| + 1 ≤ 2^10`,
  `(r 0 + 1)(K + 3) + 1 = 1009`) satisfy the hypotheses.
-/

namespace F2e2e.BSpace

open F2e2e.B F2e2e.C.Impl

/-- **S1's value bound in the final shape**: `bsMB ≤ 2^56 · N · (b_𝒰 + χ²)`, given the parameter
record's bound `bsPubBound ≤ 2^32 · adaBoundA A` (W3's `bsPubBound_le`). -/
theorem bsMB_le_final (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ)
    (hpub : bsPubBound M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      2 ^ 32 * adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)) :
    bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU ≤
      2 ^ 56 * (F2e2e.alg2Params M J R aReq ξReq).N *
        (bU + F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) ^ 2) := by
  have hA := bs_adaBoundA_le' M J R ha0 ha1 hξ0 hξ1
  have hN := V2.v2par_N M J R ha0 ha1 hξ0 hξ1
  have hpN := BoundAux.p_add_le_N M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq)
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  rw [bsMB_eq]
  set N := (F2e2e.alg2Params M J R aReq ξReq).N with hNdef
  set χ := F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) with hχdef
  set B := adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) with hB
  set NA := (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N with hNA
  set P := bsPubBound M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) with hP
  set Y := bU + χ ^ 2 with hY
  have hχ2 : χ ≤ χ ^ 2 := Nat.le_self_pow (by norm_num) χ
  have hNY : N * χ ≤ N * Y := Nat.mul_le_mul_left _ (by omega)
  have t1 : 2 ^ 33 * B + P ≤ 3 * 2 ^ 32 * B := by omega
  have t2 : 3 * 2 ^ 32 * B ≤ 3 * 2 ^ 54 * (N * Y) := by
    calc 3 * 2 ^ 32 * B ≤ 3 * 2 ^ 32 * (2 ^ 22 * N * χ) := Nat.mul_le_mul_left _ hA
      _ = 3 * 2 ^ 54 * (N * χ) := by ring
      _ ≤ 3 * 2 ^ 54 * (N * Y) := Nat.mul_le_mul_left _ hNY
  have t3 : 2 ^ 4 * (NA + 4) * (bU + 4) ≤ 2 ^ 5 * (N * Y) := by
    have e1 : NA + 4 ≤ 2 * N := by omega
    have e2 : bU + 4 ≤ Y := by omega
    calc 2 ^ 4 * (NA + 4) * (bU + 4) ≤ 2 ^ 4 * (2 * N) * Y :=
          Nat.mul_le_mul (Nat.mul_le_mul_left _ e1) e2
      _ = 2 ^ 5 * (N * Y) := by ring
  have t4 : 3 * 2 ^ 54 * (N * Y) + 2 ^ 5 * (N * Y) ≤ 2 ^ 56 * (N * Y) := by
    have : 3 * 2 ^ 54 + 2 ^ 5 ≤ 2 ^ 56 := by norm_num
    calc 3 * 2 ^ 54 * (N * Y) + 2 ^ 5 * (N * Y) = (3 * 2 ^ 54 + 2 ^ 5) * (N * Y) := by ring
      _ ≤ 2 ^ 56 * (N * Y) := Nat.mul_le_mul_right _ this
  calc 2 ^ 33 * B + P + 2 ^ 4 * (NA + 4) * (bU + 4) ≤ 2 ^ 56 * (N * Y) := by omega
    _ = 2 ^ 56 * N * Y := by ring

/-- `1 ≤ bsMB` (the records' summand). -/
theorem one_le_bsMB (M J R eA eXi bU : ℕ) : 1 ≤ bsMB M J R eA eXi bU :=
  le_trans (Nat.one_le_iff_ne_zero.mpr (by positivity)) (bsMB_rec M J R eA eXi bU)

/-- **S2 (final inequality, parametric)**: the bit bound of the oracle machine at S1's value bound,
for every program of depth `≤ 2^10` with `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`, and peak factor
`(r 0 + 1)(K + 3) + 1 ≤ 2^20`, is at most `2^107 · N · (b_𝒰 + χ²)`. -/
theorem bs_machineBound_le_final (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ)
    (hpub : bsPubBound M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      2 ^ 32 * adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R))
    {prog : List Expr} {r : ℕ → ℕ} {K Dp w : ℕ} (hDp : F2e2e.Machine.progDepth prog ≤ Dp)
    (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10) (hw10 : w ≤ 2 ^ 10)
    (hD : (r 0 + 1) * (K + 3) + 1 ≤ 2 ^ 20) :
    bsMachineBound prog r K (bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU) ≤
      2 ^ 107 * ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2) := by
  have hMB := bsMB_le_final M J R ha0 ha1 hξ0 hξ1 bU hpub
  have h := bsMachineBound_le hDp hw hDp10 hw10 hD
    (one_le_bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU)
  refine h.trans ?_
  have hc : (bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU : ℝ) ≤
      2 ^ 56 * ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2) := by
    exact_mod_cast hMB
  calc 2 ^ 51 * (bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU : ℝ)
      ≤ 2 ^ 51 * (2 ^ 56 * ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2)) :=
        mul_le_mul_of_nonneg_left hc (by positivity)
    _ = _ := by ring

/-- **S2 against a final constant** `C ≥ 2^107`. -/
theorem bs_machineBound_le_of_const (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq)
    (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ)
    (hpub : bsPubBound M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      2 ^ 32 * adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R))
    {prog : List Expr} {r : ℕ → ℕ} {K Dp w : ℕ} (hDp : F2e2e.Machine.progDepth prog ≤ Dp)
    (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10) (hw10 : w ≤ 2 ^ 10)
    (hD : (r 0 + 1) * (K + 3) + 1 ≤ 2 ^ 20) {C : ℝ} (hC : 2 ^ 107 ≤ C) :
    bsMachineBound prog r K (bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU) ≤
      C * ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2) := by
  refine (bs_machineBound_le_final M J R ha0 ha1 hξ0 hξ1 bU hpub hDp hw hDp10 hw10 hD).trans ?_
  have hX : (0 : ℝ) ≤ ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
      ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2) := by
    positivity
  calc 2 ^ 107 * ((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2)
      = 2 ^ 107 * (((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2)) :=
        by ring
    _ ≤ C * (((F2e2e.alg2Params M J R aReq ξReq).N : ℝ) *
        ((bU : ℝ) + (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) : ℝ) ^ 2)) :=
        mul_le_mul_of_nonneg_right hC hX
    _ = _ := by ring

/-! ## Against `bSpaceBound e` -/

/-- The exponent of the B_space chain: the machine bound is at most `2^bsChainExp · N · (b_𝒰 + χ²)`
(C-SPACE's `2^51` times `bsMB ≤ 2^56 · N · (b_𝒰 + χ²)`). -/
abbrev bsChainExp : ℕ := 107

/-- The parameter record's bound for the actual parameters (W3's `bsPubBound_le`). -/
theorem bs_pub_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    bsPubBound M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      2 ^ 32 * adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) :=
  bsPubBound_le (four_le_dyadicExp ha0 (by linarith)) (two_le_dyadicExp hξ0 hξ1)

/-- **S2 (final inequality)**: for every program of depth `≤ 2^10` with `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`,
and peak factor `(r 0 + 1)(K + 3) + 1 ≤ 2^20`, the bit bound of the oracle machine at S1's value bound is at
most `bSpaceBound e N b_𝒰 χ` for every exponent `e ≥ bsChainExp = 107`. -/
theorem bs_machineBound_le_bSpaceBound (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq)
    (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ)
    {prog : List Expr} {r : ℕ → ℕ} {K Dp w : ℕ} (hDp : F2e2e.Machine.progDepth prog ≤ Dp)
    (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10) (hw10 : w ≤ 2 ^ 10)
    (hD : (r 0 + 1) * (K + 3) + 1 ≤ 2 ^ 20) {e : ℕ} (he : bsChainExp ≤ e) :
    bsMachineBound prog r K (bsMB M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) bU) ≤
      bSpaceBound e (F2e2e.alg2Params M J R aReq ξReq).N bU
        (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  have hC : (2 : ℝ) ^ 107 ≤ (2 : ℝ) ^ e := pow_le_pow_right₀ (by norm_num) he
  exact bs_machineBound_le_of_const M J R ha0 ha1 hξ0 hξ1 bU (bs_pub_le M J R ha0 ha1 hξ0 hξ1)
    hDp hw hDp10 hw10 hD hC

end F2e2e.BSpace
