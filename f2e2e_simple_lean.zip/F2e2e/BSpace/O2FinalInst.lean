import F2e2e.BSpace.O2FinalB
import F2e2e.BSpace.O2SizeCoef

/-!
# O2b: the final inequalities at the glue owners' bounds (B-ACC)

`o2fi_finR` is exactly the field `O2Inputs.finR` (`F2e2e/BSpace/O2Assemble.lean`) at C-BANK's round-frame bounds
`mR := o2m_mR`, `τR := o2m_τR` (`F2e2e/BSpace/O2GlueMainBounds.lean`). Ingredients:
* O2B-SIZE's Plan-A coefficients (`F2e2e/BSpace/O2SizeCoef.lean`): `o2s_coef_mR : o2m_mR ≤ 1·(N b_𝒰) + 9·(N χ)` and
  `o2s_coef_τR : o2m_τR ≤ 50·(N b_𝒰) + 17387760·(N χ)`;
* `o2f_finR_pure` (`F2e2e/BSpace/O2FinalB.lean`), whose conditions are `258 (18 + 50) = 17544 ≤ 2^30` and
  `258 (18·9 + 17387760) + 380266 = 4486464142 ≤ 61·2^30`.

The initialization's field is C-PROB's `o2is_finI` (`F2e2e/BSpace/O2InitFin.lean`, from `o2f_finI_pure`).
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine F2e2e.Cost F2e2e.BSpace.MachineO

/-- **`O2Inputs.finR` at `mR := o2m_mR`, `τR := o2m_τR`**: a request's charge is below
`asmBound 30 = 2^30 · N · (b_𝒰 + χ²)`. -/
theorem o2fi_finR : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ bU : ℕ,
    ((O2B.bridgeAdd bsRoundProg (bsRank 0)
        ((exprDepth body_bsRound + 3) * o2m_mR M J R aReq ξReq bU + o2m_τR M J R aReq ξReq bU) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU
  exact o2f_finR_pure (cmU := 1) (cmX := 9) (cτU := 50) (cτX := 17387760) ha0 ha1 hξ0 hξ1 rfl rfl
    (o2s_coef_mR M J R ha0 ha1 hξ0 hξ1 bU) (o2s_coef_τR M J R ha0 ha1 hξ0 hξ1 bU) (by norm_num) (by norm_num)

end F2e2e.BSpace.O2B
