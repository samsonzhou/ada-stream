import F2e2e.BSpace.MachineDefsO

/-!
# Facts about the oracle big-step semantics `evalO` / `loopRunO` (B_space layer M; 17fc0802)

Oracle copies of `F2e2e/Cost/Facts.lean` (DSL-CALC) for C-SPACE's `evalO`/`loopRunO`
(`F2e2e/BSpace/MachineDefsO.lean`): the inversion lemmas `evalO_*_iff` / `evalO_*_eq` and `loopRunO_succ_iff`
(`evalO_call_iff` has two branches: the oracle `i = bsOracleIdx` and an ordinary call), fuel monotonicity and
determinism, base shift, the peak and cost bounds, and the tape frame lemmas. The proofs are those of
`Cost/Facts.lean` with the extra oracle branch in every `call` case. Helpers are prefixed `bsO_`.
-/

namespace F2e2e.BSpace

/-! ### One-step inversion lemmas -/

section Inversion
variable (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr)

theorem evalO_zero_eq (base : ℕ) (env : List Val) (tape : List Bool) (e : Expr) :
    evalO orc prog 0 base env tape e = none := by
  simp [evalO]

theorem loopRunO_zero_eq (base i : ℕ) (v : Val) (tape : List Bool) :
    loopRunO orc prog 0 base i v tape = none := by
  simp [loopRunO]

theorem evalO_var_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.var i) = some r ↔
      ∃ v, env[i]? = some v ∧ r = (v, 1, base + valSize v, tape) := by
  simp only [evalO]
  cases env[i]? <;> simp [eq_comm]

theorem evalO_lit_eq (n base : ℕ) (env : List Val) (tape : List Bool) (z : ℤ) :
    evalO orc prog (n+1) base env tape (Expr.lit z) =
      some (Val.int z, 1 + bitLen z, base + valSize (Val.int z), tape) := by
  simp only [evalO]

theorem evalO_nil_eq (n base : ℕ) (env : List Val) (tape : List Bool) :
    evalO orc prog (n+1) base env tape Expr.nil =
      some (Val.list [], 1, base + valSize (Val.list []), tape) := by
  simp only [evalO]

theorem evalO_coin_cons (n base : ℕ) (env : List Val) (b : Bool) (rest : List Bool) :
    evalO orc prog (n+1) base env (b :: rest) Expr.coin =
      some (Val.int (if b = true then 1 else 0), 1,
        base + valSize (Val.int (if b = true then 1 else 0)), rest) := by
  simp only [evalO]

theorem evalO_coin_nil (n base : ℕ) (env : List Val) :
    evalO orc prog (n+1) base env [] Expr.coin = none := by
  simp only [evalO]

theorem evalO_coin_iff {n base : ℕ} {env : List Val} {tape : List Bool}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape Expr.coin = some r ↔
      ∃ b rest, tape = b :: rest ∧
        r = (Val.int (if b = true then 1 else 0), 1,
          base + valSize (Val.int (if b = true then 1 else 0)), rest) := by
  cases tape with
  | nil => simp [evalO_coin_nil]
  | cons b rest =>
    rw [evalO_coin_cons]
    constructor
    · intro h
      exact ⟨b, rest, rfl, (Option.some.inj h).symm⟩
    · rintro ⟨b', rest', h, rfl⟩
      cases h
      rfl

theorem evalO_bin_iff {n base : ℕ} {env : List Val} {tape : List Bool} {op : BinOp} {a b : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.bin op a b) = some r ↔
      ∃ va ca pa ta vb cb pb tb v c, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        evalO orc prog n (base + valSize va) env ta b = some (vb, cb, pb, tb) ∧
        evalBin op va vb = some (v, c) ∧
        r = (v, 1 + ca + cb + c, max (max pa pb) (base + valSize va + valSize vb + valSize v),
          tb) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i vb cb pb tb hb
        split at h
        · simp at h
        · rename_i v c hv
          exact ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩
    simp only [ha, hb, hv]

theorem evalO_un_iff {n base : ℕ} {env : List Val} {tape : List Bool} {op : UnOp} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.un op a) = some r ↔
      ∃ va ca pa ta v c, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        evalUn op va = some (v, c) ∧
        r = (v, 1 + ca + c, max pa (base + valSize va + valSize v), ta) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i v c hv
        exact ⟨va, ca, pa, ta, v, c, ha, hv, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩
    simp only [ha, hv]

theorem evalO_ite_iff {n base : ℕ} {env : List Val} {tape : List Bool} {c t f : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.ite c t f) = some r ↔
      ∃ z cc pc tc v cv pv tv, evalO orc prog n base env tape c = some (Val.int z, cc, pc, tc) ∧
        evalO orc prog n base env tc (if z ≠ 0 then t else f) = some (v, cv, pv, tv) ∧
        r = (v, 1 + cc + cv, max pc pv, tv) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · rename_i z cc pc tc hc
      split at h
      · simp at h
      · rename_i v cv pv tv hv
        exact ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, (Option.some.inj h).symm⟩
    · simp at h
  · rintro ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩
    simp only [hc, hv]

theorem evalO_letE_iff {n base : ℕ} {env : List Val} {tape : List Bool} {a b : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.letE a b) = some r ↔
      ∃ va ca pa ta vb cb pb tb, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        evalO orc prog n (base + valSize va) (va :: env) ta b = some (vb, cb, pb, tb) ∧
        r = (vb, 1 + ca + cb, max pa pb, tb) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i vb cb pb tb hb
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩
    simp only [ha, hb]

theorem evalO_call_cases_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.call i a) = some r ↔
      ∃ va ca pa ta, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        ((i = bsOracleIdx ∧ ∃ sel w q, va = Val.list [Val.int sel, Val.int w, Val.int q] ∧
            r = (Val.int (orc sel w q), 2 + ca,
              max pa (base + valSize va + valSize (Val.int (orc sel w q))), ta)) ∨
          (i ≠ bsOracleIdx ∧ ∃ body vb cb pb tb, prog[i]? = some body ∧
            evalO orc prog n (base + valSize va) [va] ta body = some (vb, cb, pb, tb) ∧
            r = (vb, 1 + ca + cb, max pa pb, tb))) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · rename_i hi
        split at h
        · rename_i sel w q
          exact ⟨_, ca, pa, ta, ha, Or.inl ⟨hi, sel, w, q, rfl, (Option.some.inj h).symm⟩⟩
        · simp at h
      · rename_i hi
        split at h
        · simp at h
        · rename_i body hbody
          split at h
          · simp at h
          · rename_i vb cb pb tb hb
            exact ⟨va, ca, pa, ta, ha,
              Or.inr ⟨hi, body, vb, cb, pb, tb, hbody, hb, (Option.some.inj h).symm⟩⟩
  · rintro ⟨va, ca, pa, ta, ha, ⟨hi, sel, w, q, rfl, rfl⟩ | ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩⟩
    · simp only [ha, hi, if_true]
    · simp only [ha, hi, if_false, hbody, hb]

/-- An ordinary call (`i ≠ bsOracleIdx`): exactly the Spec's `eval_call_iff`. -/
theorem evalO_call_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} (hi : i ≠ bsOracleIdx) :
    evalO orc prog (n+1) base env tape (Expr.call i a) = some r ↔
      ∃ va ca pa ta body vb cb pb tb, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        prog[i]? = some body ∧
        evalO orc prog n (base + valSize va) [va] ta body = some (vb, cb, pb, tb) ∧
        r = (vb, 1 + ca + cb, max pa pb, tb) := by
  rw [evalO_call_cases_iff]
  constructor
  · rintro ⟨va, ca, pa, ta, ha, ⟨hi', -⟩ | ⟨-, body, vb, cb, pb, tb, hbody, hb, rfl⟩⟩
    · exact absurd hi' hi
    · exact ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩
  · rintro ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, rfl⟩
    exact ⟨va, ca, pa, ta, ha, Or.inr ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩⟩

/-- The oracle call: the argument evaluates to `[sel, rr, q]` and the answer is `orc sel rr q`, with the
argument and the answer live together. -/
theorem evalO_oracle_iff {n base : ℕ} {env : List Val} {tape : List Bool} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.call bsOracleIdx a) = some r ↔
      ∃ va ca pa ta sel rr q, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        va = Val.list [Val.int sel, Val.int rr, Val.int q] ∧
        r = (Val.int (orc sel rr q), 2 + ca,
          max pa (base + valSize va + valSize (Val.int (orc sel rr q))), ta) := by
  rw [evalO_call_cases_iff]
  constructor
  · rintro ⟨va, ca, pa, ta, ha, ⟨-, sel, rr, q, hva, rfl⟩ | ⟨hi, -⟩⟩
    · exact ⟨va, ca, pa, ta, sel, rr, q, ha, hva, rfl⟩
    · exact absurd rfl hi
  · rintro ⟨va, ca, pa, ta, sel, rr, q, ha, hva, rfl⟩
    exact ⟨va, ca, pa, ta, ha, Or.inl ⟨rfl, sel, rr, q, hva, rfl⟩⟩

theorem evalO_loop_iff {n base : ℕ} {env : List Val} {tape : List Bool} {i : ℕ} {a : Expr}
    {r : Val × ℕ × ℕ × List Bool} :
    evalO orc prog (n+1) base env tape (Expr.loop i a) = some r ↔
      ∃ va ca pa ta w cw pw tw, evalO orc prog n base env tape a = some (va, ca, pa, ta) ∧
        loopRunO orc prog n base i va ta = some (w, cw, pw, tw) ∧
        r = (w, 1 + ca + cw, max pa pw, tw) := by
  simp only [evalO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i va ca pa ta ha
      split at h
      · simp at h
      · rename_i w cw pw tw hw
        exact ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hw, (Option.some.inj h).symm⟩
  · rintro ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hw, rfl⟩
    simp only [ha, hw]

theorem loopRunO_succ_iff {n base i : ℕ} {v : Val} {tape : List Bool}
    {r : Val × ℕ × ℕ × List Bool} :
    loopRunO orc prog (n+1) base i v tape = some r ↔
      ∃ body flag v' cb pb tb, prog[i]? = some body ∧
        evalO orc prog n (base + valSize v) [v] tape body =
          some (Val.list [Val.int flag, v'], cb, pb, tb) ∧
        ((flag = 0 ∧ r = (v', 1 + cb, pb, tb)) ∨
          (flag ≠ 0 ∧ ∃ w cw pw tw, loopRunO orc prog n base i v' tb = some (w, cw, pw, tw) ∧
            r = (w, 1 + cb + cw, max pb pw, tw))) := by
  simp only [loopRunO]
  constructor
  · intro h
    split at h
    · simp at h
    · rename_i body hbody
      split at h
      · rename_i flag v' cb pb tb hb
        by_cases hflag : flag = 0
        · rw [if_pos hflag] at h
          exact ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inl ⟨hflag, (Option.some.inj h).symm⟩⟩
        · rw [if_neg hflag] at h
          split at h
          · simp at h
          · rename_i w cw pw tw hw
            exact ⟨body, flag, v', cb, pb, tb, hbody, hb,
              Or.inr ⟨hflag, w, cw, pw, tw, hw, (Option.some.inj h).symm⟩⟩
      · simp at h
  · rintro ⟨body, flag, v', cb, pb, tb, hbody, hb, ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩⟩
    · simp only [hbody, hb]
      rw [if_pos hflag]
    · simp only [hbody, hb]
      rw [if_neg hflag]
      simp only [hw]

end Inversion

/-! ### Fuel monotonicity and determinism (simultaneously for `eval` and `loopRun`) -/

theorem bsO_fuel_mono_aux (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (n : ℕ) :
    (∀ m, n ≤ m → ∀ base env tape e r, evalO orc prog n base env tape e = some r →
      evalO orc prog m base env tape e = some r) ∧
    (∀ m, n ≤ m → ∀ base i v tape r, loopRunO orc prog n base i v tape = some r →
      loopRunO orc prog m base i v tape = some r) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ _ _ h => by simp [evalO] at h,
      fun _ _ _ _ _ _ _ h => by simp [loopRunO] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro m' hm base env tape e r hr
      obtain ⟨m, rfl⟩ : ∃ m, m' = m + 1 := ⟨m' - 1, by omega⟩
      have hnm : n ≤ m := by omega
      cases e with
      | var i => rw [evalO_var_iff] at hr ⊢; exact hr
      | lit z => rw [evalO_lit_eq] at hr ⊢; exact hr
      | nil => rw [evalO_nil_eq] at hr ⊢; exact hr
      | coin => rw [evalO_coin_iff] at hr ⊢; exact hr
      | bin op a b =>
        rw [evalO_bin_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ihe m hnm _ _ _ _ _ ha,
          ihe m hnm _ _ _ _ _ hb, hv, rfl⟩
      | un op a =>
        rw [evalO_un_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, v, c, ihe m hnm _ _ _ _ _ ha, hv, rfl⟩
      | ite c t f =>
        rw [evalO_ite_iff] at hr ⊢
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := hr
        exact ⟨z, cc, pc, tc, v, cv, pv, tv, ihe m hnm _ _ _ _ _ hc, ihe m hnm _ _ _ _ _ hv, rfl⟩
      | letE a b =>
        rw [evalO_letE_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, vb, cb, pb, tb, ihe m hnm _ _ _ _ _ ha, ihe m hnm _ _ _ _ _ hb, rfl⟩
      | call i a =>
        rw [evalO_call_cases_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, ha, hrest⟩ := hr
        refine ⟨va, ca, pa, ta, ihe m hnm _ _ _ _ _ ha, ?_⟩
        rcases hrest with ⟨hi, sel, w, q, rfl, rfl⟩ | ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩
        · exact Or.inl ⟨hi, sel, w, q, rfl, rfl⟩
        · exact Or.inr ⟨hi, body, vb, cb, pb, tb, hbody, ihe m hnm _ _ _ _ _ hb, rfl⟩
      | loop i a =>
        rw [evalO_loop_iff] at hr ⊢
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := hr
        exact ⟨va, ca, pa, ta, w, cw, pw, tw, ihe m hnm _ _ _ _ _ ha, ihl m hnm _ _ _ _ _ hl, rfl⟩
    · intro m' hm base i v tape r hr
      obtain ⟨m, rfl⟩ : ∃ m, m' = m + 1 := ⟨m' - 1, by omega⟩
      have hnm : n ≤ m := by omega
      rw [loopRunO_succ_iff] at hr ⊢
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := hr
      refine ⟨body, flag, v', cb, pb, tb, hbody, ihe m hnm _ _ _ _ _ hb, ?_⟩
      rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
      · exact Or.inl ⟨hflag, rfl⟩
      · exact Or.inr ⟨hflag, w, cw, pw, tw, ihl m hnm _ _ _ _ _ hw, rfl⟩

/-- **Fuel monotonicity.** More fuel never changes a successful result. -/
theorem evalO_fuel_mono (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel fuel' : ℕ} (h : fuel ≤ fuel') (base : ℕ)
    (env : List Val) (tape : List Bool) (e : Expr) (r : Val × ℕ × ℕ × List Bool)
    (hr : evalO orc prog fuel base env tape e = some r) :
    evalO orc prog fuel' base env tape e = some r :=
  (bsO_fuel_mono_aux orc prog fuel).1 fuel' h base env tape e r hr

/-- Fuel monotonicity of loop iterations. -/
theorem loopRunO_fuel_mono (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel fuel' : ℕ} (h : fuel ≤ fuel') (base i : ℕ)
    (v : Val) (tape : List Bool) (r : Val × ℕ × ℕ × List Bool)
    (hr : loopRunO orc prog fuel base i v tape = some r) :
    loopRunO orc prog fuel' base i v tape = some r :=
  (bsO_fuel_mono_aux orc prog fuel).2 fuel' h base i v tape r hr

/-- **Determinism.** Two successful runs on the same tape (with any fuels) agree: same value,
cost, peak and leftover tape. -/
theorem evalO_det (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {f₁ f₂ : ℕ} (base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) {r₁ r₂ : Val × ℕ × ℕ × List Bool} (h₁ : evalO orc prog f₁ base env tape e = some r₁)
    (h₂ : evalO orc prog f₂ base env tape e = some r₂) : r₁ = r₂ := by
  have e₁ := evalO_fuel_mono orc prog (le_max_left f₁ f₂) base env tape e r₁ h₁
  have e₂ := evalO_fuel_mono orc prog (le_max_right f₁ f₂) base env tape e r₂ h₂
  rw [e₁] at e₂
  exact Option.some.inj e₂

/-- Determinism of loop iterations. -/
theorem loopRunO_det (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {f₁ f₂ : ℕ} (base i : ℕ) (v : Val) (tape : List Bool)
    {r₁ r₂ : Val × ℕ × ℕ × List Bool} (h₁ : loopRunO orc prog f₁ base i v tape = some r₁)
    (h₂ : loopRunO orc prog f₂ base i v tape = some r₂) : r₁ = r₂ := by
  have e₁ := loopRunO_fuel_mono orc prog (le_max_left f₁ f₂) base i v tape r₁ h₁
  have e₂ := loopRunO_fuel_mono orc prog (le_max_right f₁ f₂) base i v tape r₂ h₂
  rw [e₁] at e₂
  exact Option.some.inj e₂

/-! ### Base shift (simultaneously for `eval` and `loopRun`) -/

/-- Helper: an equation `x = y.map f` of options from the two "success" implications. -/
theorem bsO_option_eq_map_of {α β : Type} {x : Option α} {y : Option β} {f : β → α}
    (h1 : ∀ r, y = some r → x = some (f r)) (h2 : ∀ r', x = some r' → ∃ r, y = some r) :
    x = y.map f := by
  cases hy : y with
  | none =>
    cases hx : x with
    | none => rfl
    | some r' =>
      obtain ⟨r, hr⟩ := h2 r' hx
      rw [hy] at hr
      exact absurd hr (by simp)
  | some r => simp [h1 r hy]

/-- Helper: the shift of a successful result. -/
theorem bsO_shift_some {o o' : Option (Val × ℕ × ℕ × List Bool)} {d : ℕ}
    (h : o' = o.map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) {v : Val} {c p : ℕ}
    {t : List Bool} (ho : o = some (v, c, p, t)) : o' = some (v, c, p + d, t) := by
  rw [h, ho]
  rfl

/-- Helper: un-shifting a successful result. -/
theorem bsO_shift_some_inv {o o' : Option (Val × ℕ × ℕ × List Bool)} {d : ℕ}
    (h : o' = o.map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) {v : Val} {c p' : ℕ}
    {t : List Bool} (ho' : o' = some (v, c, p', t)) : ∃ p, o = some (v, c, p, t) := by
  rw [h] at ho'
  obtain ⟨⟨v₀, c₀, p₀, t₀⟩, h₀, h₁⟩ := Option.map_eq_some_iff.mp ho'
  simp only [Prod.mk.injEq] at h₁
  obtain ⟨rfl, rfl, -, rfl⟩ := h₁
  exact ⟨p₀, h₀⟩

theorem bsO_base_shift_aux (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (d n : ℕ) :
    (∀ base env tape e, evalO orc prog n (base + d) env tape e =
      (evalO orc prog n base env tape e).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) ∧
    (∀ base i v tape, loopRunO orc prog n (base + d) i v tape =
      (loopRunO orc prog n base i v tape).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2))) := by
  induction n with
  | zero => exact ⟨fun _ _ _ _ => by simp [evalO], fun _ _ _ _ => by simp [loopRunO]⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e
      apply bsO_option_eq_map_of
      · intro r hr
        cases e with
        | var i =>
          obtain ⟨v, hv, rfl⟩ := (evalO_var_iff orc prog).mp hr
          exact (evalO_var_iff orc prog).mpr ⟨v, hv, by
            simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
        | lit z =>
          rw [evalO_lit_eq] at hr ⊢
          rw [← Option.some.inj hr]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | nil =>
          rw [evalO_nil_eq] at hr ⊢
          rw [← Option.some.inj hr]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | coin =>
          obtain ⟨b, rest, rfl, rfl⟩ := (evalO_coin_iff orc prog).mp hr
          rw [evalO_coin_cons]
          simp only [Option.some.injEq, Prod.mk.injEq, true_and, and_true]; omega
        | bin op a b =>
          obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ :=
            (evalO_bin_iff orc prog).mp hr
          refine (evalO_bin_iff orc prog).mpr ⟨va, ca, pa + d, ta, vb, cb, pb + d, tb, v, c,
            bsO_shift_some (ihe _ _ _ _) ha, ?_, hv, ?_⟩
          · rw [Nat.add_right_comm]; exact bsO_shift_some (ihe _ _ _ _) hb
          · simp only [Prod.mk.injEq, true_and, and_true]; omega
        | un op a =>
          obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := (evalO_un_iff orc prog).mp hr
          refine (evalO_un_iff orc prog).mpr ⟨va, ca, pa + d, ta, v, c,
            bsO_shift_some (ihe _ _ _ _) ha, hv, ?_⟩
          simp only [Prod.mk.injEq, true_and, and_true]; omega
        | ite c t f =>
          obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := (evalO_ite_iff orc prog).mp hr
          exact (evalO_ite_iff orc prog).mpr ⟨z, cc, pc + d, tc, v, cv, pv + d, tv,
            bsO_shift_some (ihe _ _ _ _) hc, bsO_shift_some (ihe _ _ _ _) hv,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
        | letE a b =>
          obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := (evalO_letE_iff orc prog).mp hr
          refine (evalO_letE_iff orc prog).mpr ⟨va, ca, pa + d, ta, vb, cb, pb + d, tb,
            bsO_shift_some (ihe _ _ _ _) ha, ?_,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
          rw [Nat.add_right_comm]; exact bsO_shift_some (ihe _ _ _ _) hb
        | call i a =>
          obtain ⟨va, ca, pa, ta, ha, hrest⟩ := (evalO_call_cases_iff orc prog).mp hr
          rcases hrest with ⟨hi, sel, w, q, rfl, rfl⟩ | ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩
          · exact (evalO_call_cases_iff orc prog).mpr ⟨_, ca, pa + d, ta, bsO_shift_some (ihe _ _ _ _) ha,
              Or.inl ⟨hi, sel, w, q, rfl, by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩⟩
          · refine (evalO_call_cases_iff orc prog).mpr ⟨va, ca, pa + d, ta, bsO_shift_some (ihe _ _ _ _) ha,
              Or.inr ⟨hi, body, vb, cb, pb + d, tb, hbody, ?_,
                by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩⟩
            rw [Nat.add_right_comm]; exact bsO_shift_some (ihe _ _ _ _) hb
        | loop i a =>
          obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := (evalO_loop_iff orc prog).mp hr
          exact (evalO_loop_iff orc prog).mpr ⟨va, ca, pa + d, ta, w, cw, pw + d, tw,
            bsO_shift_some (ihe _ _ _ _) ha, bsO_shift_some (ihl _ _ _ _) hl,
            by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩
      · intro r' hr'
        cases e with
        | var i =>
          obtain ⟨v, hv, rfl⟩ := (evalO_var_iff orc prog).mp hr'
          exact ⟨_, (evalO_var_iff orc prog).mpr ⟨v, hv, rfl⟩⟩
        | lit z => exact ⟨_, evalO_lit_eq orc prog n base env tape z⟩
        | nil => exact ⟨_, evalO_nil_eq orc prog n base env tape⟩
        | coin =>
          obtain ⟨b, rest, rfl, rfl⟩ := (evalO_coin_iff orc prog).mp hr'
          exact ⟨_, evalO_coin_cons orc prog n base env b rest⟩
        | bin op a b =>
          obtain ⟨va, ca, pa', ta, vb, cb, pb', tb, v, c, ha, hb, hv, rfl⟩ :=
            (evalO_bin_iff orc prog).mp hr'
          obtain ⟨pa, ha⟩ := bsO_shift_some_inv (ihe _ _ _ _) ha
          rw [Nat.add_right_comm] at hb
          obtain ⟨pb, hb⟩ := bsO_shift_some_inv (ihe _ _ _ _) hb
          exact ⟨_, (evalO_bin_iff orc prog).mpr ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩⟩
        | un op a =>
          obtain ⟨va, ca, pa', ta, v, c, ha, hv, rfl⟩ := (evalO_un_iff orc prog).mp hr'
          obtain ⟨pa, ha⟩ := bsO_shift_some_inv (ihe _ _ _ _) ha
          exact ⟨_, (evalO_un_iff orc prog).mpr ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩⟩
        | ite c t f =>
          obtain ⟨z, cc, pc', tc, v, cv, pv', tv, hc, hv, rfl⟩ := (evalO_ite_iff orc prog).mp hr'
          obtain ⟨pc, hc⟩ := bsO_shift_some_inv (ihe _ _ _ _) hc
          obtain ⟨pv, hv⟩ := bsO_shift_some_inv (ihe _ _ _ _) hv
          exact ⟨_, (evalO_ite_iff orc prog).mpr ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩⟩
        | letE a b =>
          obtain ⟨va, ca, pa', ta, vb, cb, pb', tb, ha, hb, rfl⟩ := (evalO_letE_iff orc prog).mp hr'
          obtain ⟨pa, ha⟩ := bsO_shift_some_inv (ihe _ _ _ _) ha
          rw [Nat.add_right_comm] at hb
          obtain ⟨pb, hb⟩ := bsO_shift_some_inv (ihe _ _ _ _) hb
          exact ⟨_, (evalO_letE_iff orc prog).mpr ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩⟩
        | call i a =>
          obtain ⟨va, ca, pa', ta, ha, hrest⟩ := (evalO_call_cases_iff orc prog).mp hr'
          obtain ⟨pa, ha⟩ := bsO_shift_some_inv (ihe _ _ _ _) ha
          rcases hrest with ⟨hi, sel, w, q, rfl, rfl⟩ | ⟨hi, body, vb, cb, pb', tb, hbody, hb, rfl⟩
          · exact ⟨_, (evalO_call_cases_iff orc prog).mpr ⟨_, ca, pa, ta, ha, Or.inl ⟨hi, sel, w, q, rfl, rfl⟩⟩⟩
          · rw [Nat.add_right_comm] at hb
            obtain ⟨pb, hb⟩ := bsO_shift_some_inv (ihe _ _ _ _) hb
            exact ⟨_, (evalO_call_cases_iff orc prog).mpr
              ⟨va, ca, pa, ta, ha, Or.inr ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩⟩⟩
        | loop i a =>
          obtain ⟨va, ca, pa', ta, w, cw, pw', tw, ha, hl, rfl⟩ := (evalO_loop_iff orc prog).mp hr'
          obtain ⟨pa, ha⟩ := bsO_shift_some_inv (ihe _ _ _ _) ha
          obtain ⟨pw, hl⟩ := bsO_shift_some_inv (ihl _ _ _ _) hl
          exact ⟨_, (evalO_loop_iff orc prog).mpr ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩⟩
    · intro base i v tape
      apply bsO_option_eq_map_of
      · intro r hr
        obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := (loopRunO_succ_iff orc prog).mp hr
        have hb' : evalO orc prog n (base + d + valSize v) [v] tape body =
            some (Val.list [Val.int flag, v'], cb, pb + d, tb) := by
          rw [Nat.add_right_comm]; exact bsO_shift_some (ihe _ _ _ _) hb
        rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
        · exact (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb + d, tb, hbody, hb',
            Or.inl ⟨hflag, rfl⟩⟩
        · exact (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb + d, tb, hbody, hb',
            Or.inr ⟨hflag, w, cw, pw + d, tw, bsO_shift_some (ihl _ _ _ _) hw,
              by simp only [Prod.mk.injEq, true_and, and_true]; omega⟩⟩
      · intro r' hr'
        obtain ⟨body, flag, v', cb, pb', tb, hbody, hb, hrest⟩ := (loopRunO_succ_iff orc prog).mp hr'
        rw [Nat.add_right_comm] at hb
        obtain ⟨pb, hb⟩ := bsO_shift_some_inv (ihe _ _ _ _) hb
        rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw', tw, hw, rfl⟩
        · exact ⟨_, (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inl ⟨hflag, rfl⟩⟩⟩
        · obtain ⟨pw, hw⟩ := bsO_shift_some_inv (ihl _ _ _ _) hw
          exact ⟨_, (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb, tb, hbody, hb,
            Or.inr ⟨hflag, w, cw, pw, tw, hw, rfl⟩⟩⟩

/-- **Base shift.** Peaks shift with the base; values, costs and leftover tapes do not depend on
it. -/
theorem evalO_base_shift (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base d : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) :
    evalO orc prog fuel (base + d) env tape e =
      (evalO orc prog fuel base env tape e).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2)) :=
  (bsO_base_shift_aux orc prog d fuel).1 base env tape e

/-- Base shift for loop iterations. -/
theorem loopRunO_base_shift (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base d i : ℕ) (v : Val) (tape : List Bool) :
    loopRunO orc prog fuel (base + d) i v tape =
      (loopRunO orc prog fuel base i v tape).map (fun r => (r.1, r.2.1, r.2.2.1 + d, r.2.2.2)) :=
  (bsO_base_shift_aux orc prog d fuel).2 base i v tape

/-! ### Peak and cost bounds -/

/-- Helper: size of a loop-body result `[flag, v']`. -/
theorem bsO_valSize_flag_pair (flag : ℤ) (v' : Val) :
    valSize (Val.list [Val.int flag, v']) = bitLen flag + valSize v' + 4 := by
  simp only [valSize, listSize]
  omega

theorem bsO_peak_ge_aux (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (n : ℕ) :
    (∀ base env tape e r, evalO orc prog n base env tape e = some r →
      base + valSize r.1 ≤ r.2.2.1) ∧
    (∀ base i v tape r, loopRunO orc prog n base i v tape = some r →
      base + valSize v ≤ r.2.2.1 ∧ base + valSize r.1 ≤ r.2.2.1) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ h => by simp [evalO] at h, fun _ _ _ _ _ h => by simp [loopRunO] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e r hr
      cases e with
      | var i =>
        obtain ⟨v, -, rfl⟩ := (evalO_var_iff orc prog).mp hr
        exact le_refl _
      | lit z =>
        rw [evalO_lit_eq] at hr
        rw [← Option.some.inj hr]
      | nil =>
        rw [evalO_nil_eq] at hr
        rw [← Option.some.inj hr]
      | coin =>
        obtain ⟨b, rest, -, rfl⟩ := (evalO_coin_iff orc prog).mp hr
        exact le_refl _
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, -, -, -, rfl⟩ := (evalO_bin_iff orc prog).mp hr
        exact le_max_of_le_right (by dsimp only; omega)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v, c, -, -, rfl⟩ := (evalO_un_iff orc prog).mp hr
        exact le_max_of_le_right (by dsimp only; omega)
      | ite c t f =>
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, -, hv, rfl⟩ := (evalO_ite_iff orc prog).mp hr
        exact le_max_of_le_right (ihe _ _ _ _ _ hv)
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, -, hb, rfl⟩ := (evalO_letE_iff orc prog).mp hr
        have := ihe _ _ _ _ _ hb
        exact le_max_of_le_right (by simp only at this ⊢; omega)
      | call i a =>
        obtain ⟨va, ca, pa, ta, -, hrest⟩ := (evalO_call_cases_iff orc prog).mp hr
        rcases hrest with ⟨-, sel, w, q, rfl, rfl⟩ | ⟨-, body, vb, cb, pb, tb, -, hb, rfl⟩
        · exact le_max_of_le_right (by dsimp only; omega)
        · have := ihe _ _ _ _ _ hb
          exact le_max_of_le_right (by simp only at this ⊢; omega)
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, -, hl, rfl⟩ := (evalO_loop_iff orc prog).mp hr
        exact le_max_of_le_right (ihl _ _ _ _ _ hl).2
    · intro base i v tape r hr
      obtain ⟨body, flag, v', cb, pb, tb, -, hb, hrest⟩ := (loopRunO_succ_iff orc prog).mp hr
      have hpb := ihe _ _ _ _ _ hb
      simp only [bsO_valSize_flag_pair] at hpb
      rcases hrest with ⟨-, rfl⟩ | ⟨-, w, cw, pw, tw, hw, rfl⟩
      · constructor <;> (dsimp only; omega)
      · have := (ihl _ _ _ _ _ hw).2
        constructor
        · exact le_max_of_le_left (by omega)
        · exact le_max_of_le_right this

/-- The peak is at least the base plus the size of the produced value. -/
theorem evalO_peak_ge (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) (r : Val × ℕ × ℕ × List Bool) (hr : evalO orc prog fuel base env tape e = some r) :
    base + valSize r.1 ≤ r.2.2.1 :=
  (bsO_peak_ge_aux orc prog fuel).1 base env tape e r hr

/-- The initial accumulator and the result of loop iterations are both live at some point. -/
theorem loopRunO_peak_ge (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base i : ℕ) (v : Val) (tape : List Bool)
    (r : Val × ℕ × ℕ × List Bool) (hr : loopRunO orc prog fuel base i v tape = some r) :
    base + valSize v ≤ r.2.2.1 ∧ base + valSize r.1 ≤ r.2.2.1 :=
  (bsO_peak_ge_aux orc prog fuel).2 base i v tape r hr

/-- Every evaluation step costs at least one unit. -/
theorem evalO_cost_pos (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base : ℕ) (env : List Val) (tape : List Bool)
    (e : Expr) (r : Val × ℕ × ℕ × List Bool) (hr : evalO orc prog fuel base env tape e = some r) :
    1 ≤ r.2.1 := by
  cases fuel with
  | zero => simp [evalO] at hr
  | succ n =>
    cases e with
    | var i =>
      obtain ⟨v, -, rfl⟩ := (evalO_var_iff orc prog).mp hr
      exact le_refl _
    | lit z =>
      rw [evalO_lit_eq] at hr
      rw [← Option.some.inj hr]
      dsimp only; omega
    | nil =>
      rw [evalO_nil_eq] at hr
      rw [← Option.some.inj hr]
    | coin =>
      obtain ⟨b, rest, -, rfl⟩ := (evalO_coin_iff orc prog).mp hr
      exact le_refl _
    | bin op a b =>
      obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, -, -, -, rfl⟩ := (evalO_bin_iff orc prog).mp hr
      dsimp only; omega
    | un op a =>
      obtain ⟨va, ca, pa, ta, v, c, -, -, rfl⟩ := (evalO_un_iff orc prog).mp hr
      dsimp only; omega
    | ite c t f =>
      obtain ⟨z, cc, pc, tc, v, cv, pv, tv, -, -, rfl⟩ := (evalO_ite_iff orc prog).mp hr
      dsimp only; omega
    | letE a b =>
      obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, -, -, rfl⟩ := (evalO_letE_iff orc prog).mp hr
      dsimp only; omega
    | call i a =>
      obtain ⟨va, ca, pa, ta, -, hrest⟩ := (evalO_call_cases_iff orc prog).mp hr
      rcases hrest with ⟨-, sel, w, q, rfl, rfl⟩ | ⟨-, body, vb, cb, pb, tb, -, -, rfl⟩
      · dsimp only; omega
      · dsimp only; omega
    | loop i a =>
      obtain ⟨va, ca, pa, ta, w, cw, pw, tw, -, -, rfl⟩ := (evalO_loop_iff orc prog).mp hr
      dsimp only; omega

/-- Every loop iteration costs at least one unit. -/
theorem loopRunO_cost_pos (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (fuel base i : ℕ) (v : Val) (tape : List Bool)
    (r : Val × ℕ × ℕ × List Bool) (hr : loopRunO orc prog fuel base i v tape = some r) :
    1 ≤ r.2.1 := by
  cases fuel with
  | zero => simp [loopRunO] at hr
  | succ n =>
    obtain ⟨body, flag, v', cb, pb, tb, -, -, ⟨-, rfl⟩ | ⟨-, w, cw, pw, tw, -, rfl⟩⟩ :=
      (loopRunO_succ_iff orc prog).mp hr
    · dsimp only; omega
    · dsimp only; omega

/-! ### Tape frame lemmas (simultaneously for `eval` and `loopRun`) -/

theorem bsO_tape_aux (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (n : ℕ) :
    (∀ base env tape e r, evalO orc prog n base env tape e = some r →
      ∃ pre, tape = pre ++ r.2.2.2 ∧
        ∀ s, evalO orc prog n base env (pre ++ s) e = some (r.1, r.2.1, r.2.2.1, s)) ∧
    (∀ base i v tape r, loopRunO orc prog n base i v tape = some r →
      ∃ pre, tape = pre ++ r.2.2.2 ∧
        ∀ s, loopRunO orc prog n base i v (pre ++ s) = some (r.1, r.2.1, r.2.2.1, s)) := by
  induction n with
  | zero =>
    exact ⟨fun _ _ _ _ _ h => by simp [evalO] at h, fun _ _ _ _ _ h => by simp [loopRunO] at h⟩
  | succ n ih =>
    obtain ⟨ihe, ihl⟩ := ih
    constructor
    · intro base env tape e r hr
      cases e with
      | var i =>
        obtain ⟨v, hv, rfl⟩ := (evalO_var_iff orc prog).mp hr
        exact ⟨[], rfl, fun s => (evalO_var_iff orc prog).mpr ⟨v, hv, rfl⟩⟩
      | lit z =>
        rw [evalO_lit_eq] at hr
        cases hr
        exact ⟨[], rfl, fun s => evalO_lit_eq orc prog n base env s z⟩
      | nil =>
        rw [evalO_nil_eq] at hr
        cases hr
        exact ⟨[], rfl, fun s => evalO_nil_eq orc prog n base env s⟩
      | coin =>
        obtain ⟨b, rest, rfl, rfl⟩ := (evalO_coin_iff orc prog).mp hr
        exact ⟨[b], rfl, fun s => evalO_coin_cons orc prog n base env b s⟩
      | bin op a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v, c, ha, hb, hv, rfl⟩ :=
          (evalO_bin_iff orc prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hqa hqb hfa hfb ⊢
        refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
          (evalO_bin_iff orc prog).mpr ⟨va, ca, pa, qb ++ s, vb, cb, pb, s, v, c, ?_, hfb s, hv, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (qb ++ s)
      | un op a =>
        obtain ⟨va, ca, pa, ta, v, c, ha, hv, rfl⟩ := (evalO_un_iff orc prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        dsimp only at hqa hfa ⊢
        exact ⟨qa, hqa, fun s => (evalO_un_iff orc prog).mpr ⟨va, ca, pa, s, v, c, hfa s, hv, rfl⟩⟩
      | ite c t f =>
        obtain ⟨z, cc, pc, tc, v, cv, pv, tv, hc, hv, rfl⟩ := (evalO_ite_iff orc prog).mp hr
        obtain ⟨qc, hqc, hfc⟩ := ihe _ _ _ _ _ hc
        obtain ⟨qv, hqv, hfv⟩ := ihe _ _ _ _ _ hv
        dsimp only at hqc hqv hfc hfv ⊢
        refine ⟨qc ++ qv, by rw [hqc, hqv, List.append_assoc], fun s =>
          (evalO_ite_iff orc prog).mpr ⟨z, cc, pc, qv ++ s, v, cv, pv, s, ?_, hfv s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfc (qv ++ s)
      | letE a b =>
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, rfl⟩ := (evalO_letE_iff orc prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
        dsimp only at hqa hqb hfa hfb ⊢
        refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
          (evalO_letE_iff orc prog).mpr ⟨va, ca, pa, qb ++ s, vb, cb, pb, s, ?_, hfb s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (qb ++ s)
      | call i a =>
        obtain ⟨va, ca, pa, ta, ha, hrest⟩ := (evalO_call_cases_iff orc prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        dsimp only at hqa hfa
        rcases hrest with ⟨hi, sel, w, q, rfl, rfl⟩ | ⟨hi, body, vb, cb, pb, tb, hbody, hb, rfl⟩
        · exact ⟨qa, hqa, fun s => (evalO_call_cases_iff orc prog).mpr
            ⟨_, ca, pa, s, hfa s, Or.inl ⟨hi, sel, w, q, rfl, rfl⟩⟩⟩
        · obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
          dsimp only at hqb hfb ⊢
          refine ⟨qa ++ qb, by rw [hqa, hqb, List.append_assoc], fun s =>
            (evalO_call_cases_iff orc prog).mpr ⟨va, ca, pa, qb ++ s, ?_,
              Or.inr ⟨hi, body, vb, cb, pb, s, hbody, hfb s, rfl⟩⟩⟩
          rw [List.append_assoc]
          exact hfa (qb ++ s)
      | loop i a =>
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, rfl⟩ := (evalO_loop_iff orc prog).mp hr
        obtain ⟨qa, hqa, hfa⟩ := ihe _ _ _ _ _ ha
        obtain ⟨ql, hql, hfl⟩ := ihl _ _ _ _ _ hl
        dsimp only at hqa hql hfa hfl ⊢
        refine ⟨qa ++ ql, by rw [hqa, hql, List.append_assoc], fun s =>
          (evalO_loop_iff orc prog).mpr ⟨va, ca, pa, ql ++ s, w, cw, pw, s, ?_, hfl s, rfl⟩⟩
        rw [List.append_assoc]
        exact hfa (ql ++ s)
    · intro base i v tape r hr
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hrest⟩ := (loopRunO_succ_iff orc prog).mp hr
      obtain ⟨qb, hqb, hfb⟩ := ihe _ _ _ _ _ hb
      dsimp only at hqb hfb
      rcases hrest with ⟨hflag, rfl⟩ | ⟨hflag, w, cw, pw, tw, hw, rfl⟩
      · exact ⟨qb, hqb, fun s => (loopRunO_succ_iff orc prog).mpr
          ⟨body, flag, v', cb, pb, s, hbody, hfb s, Or.inl ⟨hflag, rfl⟩⟩⟩
      · obtain ⟨qw, hqw, hfw⟩ := ihl _ _ _ _ _ hw
        dsimp only at hqw hfw ⊢
        refine ⟨qb ++ qw, by rw [hqb, hqw, List.append_assoc], fun s =>
          (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb, qw ++ s, hbody, ?_,
            Or.inr ⟨hflag, w, cw, pw, s, hfw s, rfl⟩⟩⟩
        rw [List.append_assoc]
        exact hfb (qw ++ s)

section TapeFrame
variable (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel base : ℕ} {env : List Val} {e : Expr} {v : Val} {c p : ℕ}

/-- **Tape frame.** A run on `tape` leaving `t'` consumed a prefix `pre` (`tape = pre ++ t'`), and
for every `r` the run on `pre ++ r` is identical and leaves `r`. -/
theorem evalO_tape_frame {tape t' : List Bool}
    (h : evalO orc prog fuel base env tape e = some (v, c, p, t')) :
    ∃ pre, tape = pre ++ t' ∧ ∀ r, evalO orc prog fuel base env (pre ++ r) e = some (v, c, p, r) :=
  (bsO_tape_aux orc prog fuel).1 base env tape e _ h

/-- The leftover tape is a suffix of the input tape. -/
theorem evalO_tape_suffix {tape t' : List Bool}
    (h : evalO orc prog fuel base env tape e = some (v, c, p, t')) : t' <:+ tape := by
  obtain ⟨pre, htape, -⟩ := evalO_tape_frame orc prog h
  exact ⟨pre, htape.symm⟩

/-- A run on `pre ++ t` leaving `t` gives, for every `r`, the same run on `pre ++ r`, leaving `r`. -/
theorem evalO_tape_append {pre t : List Bool}
    (h : evalO orc prog fuel base env (pre ++ t) e = some (v, c, p, t)) (r : List Bool) :
    evalO orc prog fuel base env (pre ++ r) e = some (v, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := evalO_tape_frame orc prog h
  rw [List.append_cancel_right htape]
  exact hf r

/-- A run on `pre` leaving the empty tape gives, for every `r`, the same run on `pre ++ r`,
leaving `r`. -/
theorem evalO_tape_append_nil {pre : List Bool}
    (h : evalO orc prog fuel base env pre e = some (v, c, p, [])) (r : List Bool) :
    evalO orc prog fuel base env (pre ++ r) e = some (v, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := evalO_tape_frame orc prog h
  rw [List.append_nil] at htape
  rw [htape]
  exact hf r

/-- A run that consumes nothing runs identically on every tape (leaving it untouched). -/
theorem evalO_tape_indep {t : List Bool} (h : evalO orc prog fuel base env t e = some (v, c, p, t))
    (r : List Bool) : evalO orc prog fuel base env r e = some (v, c, p, r) :=
  evalO_tape_append orc prog (pre := []) h r

/-- A run on the empty tape consumes nothing, hence runs identically on every tape. -/
theorem evalO_tape_nil {t' : List Bool} (h : evalO orc prog fuel base env [] e = some (v, c, p, t')) :
    t' = [] ∧ ∀ r, evalO orc prog fuel base env r e = some (v, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := evalO_tape_frame orc prog h
  have h1 : pre = [] ∧ t' = [] := List.append_eq_nil_iff.mp htape.symm
  obtain ⟨rfl, rfl⟩ := h1
  exact ⟨rfl, hf⟩

/-- **Bounded reading.** A run on `l ++ r` that reads at most `|l|` bits (its leftover is at least
as long as `r`) leaves `l₂ ++ r` for a suffix `l₂` of `l`, and is unchanged (leaving `l₂ ++ r'`)
when `r` is replaced by any `r'`. -/
theorem evalO_tape_prefix {l r t' : List Bool}
    (h : evalO orc prog fuel base env (l ++ r) e = some (v, c, p, t')) (hlen : r.length ≤ t'.length) :
    ∃ l₂, l₂ <:+ l ∧ t' = l₂ ++ r ∧
      ∀ r', evalO orc prog fuel base env (l ++ r') e = some (v, c, p, l₂ ++ r') := by
  obtain ⟨pre, htape, hf⟩ := evalO_tape_frame orc prog h
  rcases List.append_eq_append_iff.mp htape with ⟨a', hpre, hr⟩ | ⟨c', hl, ht'⟩
  · -- `pre = l ++ a'`, `r = a' ++ t'`: then `a' = []`
    have ha : a' = [] := by
      have := congrArg List.length hr
      simp only [List.length_append] at this
      exact List.eq_nil_of_length_eq_zero (by omega)
    subst ha
    simp only [List.append_nil, List.nil_append] at hpre hr
    subst hpre hr
    exact ⟨[], List.nil_suffix, rfl, fun r' => hf r'⟩
  · -- `l = pre ++ c'`, `t' = c' ++ r`
    refine ⟨c', ⟨pre, hl.symm⟩, ht', fun r' => ?_⟩
    rw [hl, List.append_assoc]
    exact hf (c' ++ r')

/-- The leftover tape is `tape.drop k` for the number `k = |tape| - |t'|` of consumed bits, and
the consumed bits are `tape.take k`. -/
theorem evalO_tape_drop {tape t' : List Bool}
    (h : evalO orc prog fuel base env tape e = some (v, c, p, t')) :
    t' = tape.drop (tape.length - t'.length) ∧
      ∀ r, evalO orc prog fuel base env (tape.take (tape.length - t'.length) ++ r) e =
        some (v, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := evalO_tape_frame orc prog h
  have hk : tape.length - t'.length = pre.length := by
    rw [htape, List.length_append]; omega
  rw [hk]
  refine ⟨?_, ?_⟩
  · rw [htape, List.drop_left]
  · rw [htape, List.take_left]
    exact hf

end TapeFrame

section LoopTapeFrame
variable (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel base i : ℕ} {v w : Val} {c p : ℕ}

/-- **Tape frame for loop iterations.** -/
theorem loopRunO_tape_frame {tape t' : List Bool}
    (h : loopRunO orc prog fuel base i v tape = some (w, c, p, t')) :
    ∃ pre, tape = pre ++ t' ∧ ∀ r, loopRunO orc prog fuel base i v (pre ++ r) = some (w, c, p, r) :=
  (bsO_tape_aux orc prog fuel).2 base i v tape _ h

theorem loopRunO_tape_suffix {tape t' : List Bool}
    (h : loopRunO orc prog fuel base i v tape = some (w, c, p, t')) : t' <:+ tape := by
  obtain ⟨pre, htape, -⟩ := loopRunO_tape_frame orc prog h
  exact ⟨pre, htape.symm⟩

theorem loopRunO_tape_append {pre t : List Bool}
    (h : loopRunO orc prog fuel base i v (pre ++ t) = some (w, c, p, t)) (r : List Bool) :
    loopRunO orc prog fuel base i v (pre ++ r) = some (w, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := loopRunO_tape_frame orc prog h
  rw [List.append_cancel_right htape]
  exact hf r

theorem loopRunO_tape_append_nil {pre : List Bool}
    (h : loopRunO orc prog fuel base i v pre = some (w, c, p, [])) (r : List Bool) :
    loopRunO orc prog fuel base i v (pre ++ r) = some (w, c, p, r) := by
  obtain ⟨pre', htape, hf⟩ := loopRunO_tape_frame orc prog h
  rw [List.append_nil] at htape
  rw [htape]
  exact hf r

theorem loopRunO_tape_indep {t : List Bool}
    (h : loopRunO orc prog fuel base i v t = some (w, c, p, t)) (r : List Bool) :
    loopRunO orc prog fuel base i v r = some (w, c, p, r) :=
  loopRunO_tape_append orc prog (pre := []) h r

theorem loopRunO_tape_nil {t' : List Bool}
    (h : loopRunO orc prog fuel base i v [] = some (w, c, p, t')) :
    t' = [] ∧ ∀ r, loopRunO orc prog fuel base i v r = some (w, c, p, r) := by
  obtain ⟨pre, htape, hf⟩ := loopRunO_tape_frame orc prog h
  have h1 : pre = [] ∧ t' = [] := List.append_eq_nil_iff.mp htape.symm
  obtain ⟨rfl, rfl⟩ := h1
  exact ⟨rfl, hf⟩

end LoopTapeFrame

/-- A run on `tape` also runs on `tape ++ extra`, leaving `rest ++ extra` (the tape frame with an appended
suffix). -/
theorem evalO_append (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel base : ℕ} {env : List Val} {e : Expr}
    {v : Val} {c p : ℕ} {tape t' : List Bool} (h : evalO orc prog fuel base env tape e = some (v, c, p, t'))
    (extra : List Bool) : evalO orc prog fuel base env (tape ++ extra) e = some (v, c, p, t' ++ extra) := by
  obtain ⟨pre, htape, hf⟩ := evalO_tape_frame orc prog h
  rw [htape, List.append_assoc]
  exact hf (t' ++ extra)

/-- `loopRunO` version of `evalO_append`. -/
theorem loopRunO_append (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) {fuel base i : ℕ} {v w : Val} {c p : ℕ}
    {tape t' : List Bool} (h : loopRunO orc prog fuel base i v tape = some (w, c, p, t'))
    (extra : List Bool) : loopRunO orc prog fuel base i v (tape ++ extra) = some (w, c, p, t' ++ extra) := by
  obtain ⟨pre, htape, hf⟩ := loopRunO_tape_frame orc prog h
  rw [htape, List.append_assoc]
  exact hf (t' ++ extra)

end F2e2e.BSpace
