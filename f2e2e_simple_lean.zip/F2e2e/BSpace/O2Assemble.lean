import F2e2e.BSpace.AssembleFinal
import F2e2e.BSpace.O2GstAsm

/-!
# B_space at the paper's constant (O2b): the top-level assembly of `Theorem_B_space_with 30` (W4)

The `e = 30` analog of C-TOP's O1 assembly (`AssembleFinal.lean`), for the Spec v3.1 statements (F-B1: every
oracle consistent with the sample; F-B2: history-free states). It reuses everything of O1 except the space chain:
* the execution format, conformance, no-exhaustion, the invariant, the oracle adapter (`OracleFor` →
  `v31OracleAgrees`) and the history-free states are unchanged (C-TOP's generic `theorem_B_space_with_of` /
  `theorem_B_joint_with_of`, `Assemble.lean`; R1–R4; `asm_resp_parse`);
* the run obligations `AsmInitRunsW` / `V31RoundRunsW` (the latter for every oracle agreeing with the request where
  the round program reads it) at the budget `asmBound 30 = 2^30 · N · (b_𝒰 + χ²)` come from the O2b chain instead
  of M* + S2:
  - the tight top-frame specs of the two entry programs, in C-SPACE's per-call form `ImplementsF orc prog m τ`
    (`O2GstF.lean`; the top frame at the value bound `m`, the callee chain within the budget `τ`); the request's
    spec is for every agreeing oracle `orc`;
  - O2B-GST's composition `ImplementsF.runsWithinBitsO_le` (`O2GstAsm.lean`: C-SPACE's per-call GST
    `runsOnO_of_evalsValF` + 17fc0802's additive bridge `O2B.runsWithinBitsO_add_of_runsOnO`, with D5's rank
    certificates `bsRankOK_init` / `bsRankOK_round`);
  - the final inequality `bridgeAdd prog (bsRank 0) ((exprDepth body + 3) · m + τ) ≤ 2^30 · N · (b_𝒰 + χ²)`.

**Interface.** `O2Inputs` bundles exactly these pieces (the bounds `mI τI mR τR` as functions of the public
parameters and `b_𝒰`). `theorem_B_space_with_30_of` / `theorem_B_joint_with_30_of` prove `Theorem_B_space_with 30`
and `Theorem_B_joint_with 30` from any `O2Inputs`, sorry-free. The instance is assembled in
`O2AssembleFinal.lean` from the glue owners' top-frame specs (bsInit: e26ae4ae, bsRound: C-BANK, made
oracle-generic in `V31O2Round.lean`) and B-ACC's final inequality.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.Cost F2e2e.C.Impl

/-- **The inputs of the `e = 30` assembly**: per public parameters `M, J, R, a_req, ξ_req` and record length
`b_𝒰`, the top-frame value bounds `mI`, `mR` and callee budgets `τI`, `τR` of the two entry programs, their
`ImplementsF` specs (at the same encodings and core programs as O1's `AsmInitRunsW` / `V31RoundRunsW`; the request's
for every oracle that answers like `reqOracle code req` at selector `0` on the codes of the sample and at selectors
`1, 2` on `r = 0`, at the precision `q_A + 1`), the input size facts, and the final inequalities into
`2^30 · N · (b_𝒰 + χ²)`. -/
structure O2Inputs : Type 1 where
  /-- top-frame value bound of the initialization -/
  mI : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ
  /-- callee-chain budget of the initialization -/
  τI : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ
  /-- top-frame value bound of a request -/
  mR : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ
  /-- callee-chain budget of a request -/
  τR : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ
  /-- the initialization program implements the core initialization at `(mI, τI)` -/
  implI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U),
      ImplementsF nullOracle bsInitProg (mI M J R aReq ξReq bU) (τI M J R aReq ξReq bU)
        [Val.list [encVParams M J R aReq ξReq, encRecords code s]] body_bsInit
        (bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s)) (adaInit (asmParams M J R aReq ξReq))
  /-- the initialization input fits the top frame -/
  inI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) (bU : ℕ) (code : U → ℕ), (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U),
      valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) ≤ mI M J R aReq ξReq bU
  /-- the initialization's charge is below `2^30 · N · (b_𝒰 + χ²)` -/
  finI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
    ((O2B.bridgeAdd bsInitProg (bsRank 0)
        ((exprDepth body_bsInit + 3) * mI M J R aReq ξReq bU + τI M J R aReq ξReq bU) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU
  /-- the request program implements the core round at `(mR, τR)` (valid request, state with `AdaOK`), for every
  oracle `orc` that answers like `reqOracle code req` where the round program reads it: selector `0` on the codes
  of the sample, selectors `1, 2` on `r = 0`, at the precision `q_A + 1` (Spec v3.1 F-B1) -/
  implR : ∀ (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2),
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U), req.Valid →
    ∀ (orc : ℤ → ℤ → ℤ → ℤ),
      (∀ ℓ : Fin (alg2Params M J R aReq ξReq).N,
        orc 0 (code (s ℓ) : ℤ) (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
          reqOracle code req 0 (code (s ℓ) : ℤ) (((asmParams M J R aReq ξReq).qA : ℤ) + 1)) →
      orc 1 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
        reqOracle code req 1 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) →
      orc 2 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
        reqOracle code req 2 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) →
    ∀ (st : AdaState), C.Impl.AdaOK (asmParams M J R aReq ξReq) st →
      ImplementsF orc bsRoundProg (mR M J R aReq ξReq bU) (τR M J R aReq ξReq bU)
        [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
          Val.int (if req.2.1 then 1 else 0)]] body_bsRound
        (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
        (bsCoreRound (asmParams M J R aReq ξReq) st
          (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
            (quantReq (asmParams M J R aReq ξReq) req))
          (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
          req.2.1)
  /-- the request input fits the top frame -/
  inR : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) (bU : ℕ) (code : U → ℕ), (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (k : ℤ), bitLen k ≤ 1 →
    ∀ (st : AdaState), C.Impl.AdaOK (asmParams M J R aReq ξReq) st →
      valSize (Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int k]) ≤ mR M J R aReq ξReq bU
  /-- a request's charge is below `2^30 · N · (b_𝒰 + χ²)` -/
  finR : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
    ((O2B.bridgeAdd bsRoundProg (bsRank 0)
        ((exprDepth body_bsRound + 3) * mR M J R aReq ξReq bU + τR M J R aReq ξReq bU) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU

section Assembly

/-- **The initialization runs within `2^30 · N · (b_𝒰 + χ²)`** (O2b chain). -/
theorem o2a_init_runsW (I : O2Inputs) : AsmInitRunsW bsInitProg bsStateEnc (asmBound 30) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s τ st τ' hrun
  exact ImplementsF.runsWithinBitsO_le bsRankOK_init bsInitProg_zero
    (I.implI M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s)
    (I.inI M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hcode s)
    (I.finI M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hrun

/-- **Every request runs within `2^30 · N · (b_𝒰 + χ²)`, for every agreeing oracle** (O2b chain; Spec v3.1
F-B1). -/
theorem o2a_round_runsW (I : O2Inputs) : V31RoundRunsW bsRoundProg bsStateEnc bsResp (asmBound 30) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s req hreq orc hagree st τ out st' τ' hok hrun
  have hk : bitLen (if req.2.1 then (1 : ℤ) else 0) ≤ 1 := by
    split_ifs <;> simp [bitLen]
  exact ImplementsF.runsWithinBitsO_le bsRankOK_round bsRoundProg_zero
    (I.implR M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s req hreq orc
      (fun ℓ => hagree.1 ℓ _) (hagree.2 0 _).1 (hagree.2 0 _).2 st hok)
    (I.inR M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hcode s _ hk st hok)
    (I.finR M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hrun

/-- **Main Theorem (B), bit-space clause, with the paper's constant `2^30`**, from the O2b inputs. -/
theorem theorem_B_space_with_30_of (I : O2Inputs) : Theorem_B_space_with 30 :=
  theorem_B_space_with_of asm_resp_parse (o2a_init_runsW I) (o2a_round_runsW I)
    (fun _ _ _ _ _ _ _ _ _ _ => le_rfl)

/-- **Main Theorem (B), guarantee and bit-space clause jointly, with the paper's constant `2^30`**, from the O2b
inputs. -/
theorem theorem_B_joint_with_30_of (I : O2Inputs) : Theorem_B_joint_with 30 :=
  theorem_B_joint_with_of asm_resp_parse (o2a_init_runsW I) (o2a_round_runsW I)
    (fun _ _ _ _ _ _ _ _ _ _ => le_rfl)

end Assembly

end F2e2e.BSpace
