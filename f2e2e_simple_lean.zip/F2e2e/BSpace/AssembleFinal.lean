import F2e2e.BSpace.Assemble
import F2e2e.BSpace.DslDefs
import F2e2e.BSpace.AsmRank
import F2e2e.BSpace.DslMainReq
import F2e2e.BSpace.V31DslReq
import F2e2e.BSpace.MachineStarO
import F2e2e.BSpace.MachineBridgeO
import F2e2e.BSpace.BoundFinal
import F2e2e.BSpace.PubBound
import F2e2e.B.NumericsDyadic

/-!
# B_space, top level (C-TOP): the final assembly

`theorem_B_space_2e128_proof : Theorem_B_space_with 128` and `theorem_B_joint_2e128_proof : Theorem_B_joint_with 128`
(generic: `theorem_B_space_of_le`, `theorem_B_joint_of_le` for every exponent `e ≥ bsChainExp = 107`), for
* the programs `bsInitProg`, `bsRoundProg` of D5 (NEW-B, `AsmTable.lean`, `AsmRank.lean`: rank certificate
  `(bsRank, bsK)`, entries, no body at the oracle index, depth `≤ 59`, length `< 2^10`);
* the encodings `bsStateEnc`, `bsResp` of D4 (W2, `DslDefs.lean`; `asm_resp_parse`).

The run obligations (`asm_init_runsW`, `v31_round_runsW` for every agreeing oracle, within
`asmBound bsChainExp = 2^107 · N · (b_𝒰 + χ²)`): D4's entry specs (W3's `bsInit_implO` and the oracle-generic
`bsRound_implG`, `DslMainReq.lean`, `V31DslReq.lean`, from W2's specs), M*
(C-SPACE's `ImplementsO.runsWithinBitsO`), S1 (B-ACC's value bound `bsMB` and its D4 facts; `asm_init_input_le`)
and S2 (B-ARCH's `bs_machineBound_le_bSpaceBound`: `bsMachineBound ≤ 2^e · N · (b_𝒰 + χ²)` at `M = bsMB` for
`e ≥ bsChainExp = 107`).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.Cost F2e2e.C.Impl

/-- The response encoding of D4 parses to the Spec's response of the core output. -/
theorem asm_resp_parse (r : CoreOut) : parseVResponse (bsResp r) = some (outRespV2 r) := by
  rcases r with c | x
  · cases c <;> rfl
  · cases x with
    | val μ =>
      have hd : (0 : ℤ) < (μ.den : ℤ) := by exact_mod_cast μ.den_pos
      simp only [bsResp, encInts, List.map_cons, List.map_nil, parseVResponse, hd, and_self, if_true,
        outRespV2, numRespV2, Int.cast_natCast, Rat.num_div_den]
    | abort =>
      simp [bsResp, encInts, parseVResponse, outRespV2, numRespV2]

/-- The budget is monotone in the exponent. -/
theorem asmBound_mono {e e' : ℕ} (h : e ≤ e') (M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) :
    asmBound e M J R aReq ξReq bU ≤ asmBound e' M J R aReq ξReq bU := by
  unfold asmBound bSpaceBound
  rw [mul_assoc, mul_assoc]
  exact mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by norm_num) h) (by positivity)

/-! ## The data of the sample -/

theorem asm_codes_length (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} (code : U → ℕ)
    (s : Fin (alg2Params M J R aReq ξReq).N → U) :
    (List.ofFn (code ∘ s)).length = (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).N := by
  rw [List.length_ofFn]
  exact refine_N M J R ha0 ha1 hξ0 hξ1

theorem asm_codes_lt {U : Type} {code : U → ℕ} {bU : ℕ} (hcode : ∀ x, code x < 2 ^ bU) {N : ℕ}
    (s : Fin N → U) : ∀ x ∈ List.ofFn (code ∘ s), x < 2 ^ bU := by
  intro x hx
  obtain ⟨ℓ, rfl⟩ := List.mem_ofFn.mp hx
  exact hcode (s ℓ)

/-- **S1, initialization input**: the parameters and the records fit in `bsMB`. -/
theorem asm_init_input_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} {code : U → ℕ} {bU : ℕ} (hcode : ∀ x, code x < 2 ^ bU)
    (s : Fin (alg2Params M J R aReq ξReq).N → U) :
    valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) ≤
      bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU := by
  have hlen := asm_codes_length M J R ha0 ha1 hξ0 hξ1 code s
  have h1 := bsV_params_size M J R (dyadicExp aReq) (dyadicExp ξReq)
  have h2 := valSize_codes_le (asm_codes_lt hcode s)
  rw [hlen] at h2
  have h3 := three_bsPubL_le M J R (dyadicExp aReq) (dyadicExp ξReq)
  have h4 := rec_summand_bound (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R).N bU
  have h5 := bsMB_eq M J R (dyadicExp aReq) (dyadicExp ξReq) bU
  rw [bsB_encRecords]
  show valSize (Val.list [encInts [(M : ℤ), (J : ℤ), (R : ℤ), (dyadicExp aReq : ℤ), (dyadicExp ξReq : ℤ)],
    encL encN (List.ofFn (code ∘ s))]) ≤ _
  simp only [valSize_list, listSize_cons, listSize_nil] at h1 h2 ⊢
  omega

/-! ## S2 at the programs -/

theorem asm_machineBound_le_init (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ) :
    bsMachineBound bsInitProg bsRank bsK (bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU) ≤
      asmBound bsChainExp M J R aReq ξReq bU :=
  bs_machineBound_le_bSpaceBound M J R ha0 ha1 hξ0 hξ1 bU bsInitProg_progDepth_le
    bsInitProg_length_succ_le (by norm_num) (by norm_num) (bsAsm_D_le.trans (by norm_num)) le_rfl

theorem asm_machineBound_le_round (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (bU : ℕ) :
    bsMachineBound bsRoundProg bsRank bsK (bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU) ≤
      asmBound bsChainExp M J R aReq ξReq bU :=
  bs_machineBound_le_bSpaceBound M J R ha0 ha1 hξ0 hξ1 bU bsRoundProg_progDepth_le
    bsRoundProg_length_succ_le (by norm_num) (by norm_num) (bsAsm_D_le.trans (by norm_num)) le_rfl

/-! ## The run obligations -/

/-- **The initialization runs**: D4 (W3's `bsInit_implO`, from W2's `bsInit_impl`) + D5 + M* + S1 + S2. -/
theorem asm_init_runsW : AsmInitRunsW bsInitProg bsStateEnc (asmBound bsChainExp) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s τ st τ' hrun
  have hlen := asm_codes_length M J R ha0 ha1 hξ0 hξ1 code s
  have hc := asm_codes_lt hcode s
  have hImpl : ImplementsO nullOracle bsInitProg (bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU)
      [Val.list [encVParams M J R aReq ξReq, encRecords code s]] body_bsInit
      (bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s)) (adaInit (asmParams M J R aReq ξReq)) := by
    exact bsInit_implO bsInitProg_oracle bsLib_init.w4Lib bsLib_init.pub (bsLib_init.normQ _)
      (blocksAt_of_table bsLib_init.blocks) ha0 ha1 hξ0 hξ1 code s (refine_N M J R ha0 ha1 hξ0 hξ1)
      (bsMB_pub _ _ _ _ _ _) (bsMB_D4init hlen hc)
  exact (ImplementsO.runsWithinBitsO bsRankOK_init bsInitProg_zero hImpl
    (asm_init_input_le M J R ha0 ha1 hξ0 hξ1 hcode s) hrun).mono
    (asm_machineBound_le_init M J R ha0 ha1 hξ0 hξ1 bU)

/-- **The request runs**: D4 (W3's request-oracle round spec `bsRound_implR`) + D5 + M* + S1 + S2. -/
theorem asm_round_runsW : AsmRoundRunsW bsRoundProg bsStateEnc bsResp (asmBound bsChainExp) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s req hreq st τ out st' τ' hok hrun
  have hlen := asm_codes_length M J R ha0 ha1 hξ0 hξ1 code s
  have hc := asm_codes_lt hcode s
  have hImpl : ImplementsO (reqOracle code req) bsRoundProg (bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU)
      [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams M J R aReq ξReq) st
        (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
          (quantReq (asmParams M J R aReq ξReq) req))
        (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
        req.2.1) := by
    exact bsRound_implR bsRoundProg_oracle bsLib_round.w4Lib bsLib_round.pub (bsLib_round.normQ _)
      bsLib_round.evals bsLib_round.ends ha0 ha1 hξ0 hξ1 hinj s (refine_N M J R ha0 ha1 hξ0 hξ1) hreq hok
      (bsMB_pub _ _ _ _ _ _) (bsMB_D4round hlen hc)
  have hk : bitLen (if req.2.1 then (1 : ℤ) else 0) ≤ 1 := by
    split_ifs <;> simp [bitLen]
  have hin : valSize (Val.list [encVParams M J R aReq ξReq,
      bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st, Val.int (if req.2.1 then 1 else 0)]) ≤
      bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU :=
    le_trans (Nat.le_add_left _ _) (bsMB_D4input hlen hc hok hk)
  exact (ImplementsO.runsWithinBitsO bsRankOK_round bsRoundProg_zero hImpl hin hrun).mono
    (asm_machineBound_le_round M J R ha0 ha1 hξ0 hξ1 bU)

/-- **The request runs for every agreeing oracle**: W3's oracle-generic round spec `bsRound_implG` + D5 + M* +
S1 + S2. -/
theorem v31_round_runsW : V31RoundRunsW bsRoundProg bsStateEnc bsResp (asmBound bsChainExp) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s req hreq orc hagree st τ out st' τ' hok hrun
  have hlen := asm_codes_length M J R ha0 ha1 hξ0 hξ1 code s
  have hc := asm_codes_lt hcode s
  have hImpl : ImplementsO orc bsRoundProg (bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU)
      [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams M J R aReq ξReq) st
        (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
          (quantReq (asmParams M J R aReq ξReq) req))
        (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
        req.2.1) := by
    exact bsRound_implG bsRoundProg_oracle bsLib_round.w4Lib bsLib_round.pub (bsLib_round.normQ _)
      bsLib_round.evals bsLib_round.ends ha0 ha1 hξ0 hξ1 hinj s (refine_N M J R ha0 ha1 hξ0 hξ1) hreq hok
      (bsMB_pub _ _ _ _ _ _) (bsMB_D4round hlen hc) (fun ℓ => hagree.1 ℓ _) (hagree.2 0 _).1
      (hagree.2 0 _).2
  have hk : bitLen (if req.2.1 then (1 : ℤ) else 0) ≤ 1 := by
    split_ifs <;> simp [bitLen]
  have hin : valSize (Val.list [encVParams M J R aReq ξReq,
      bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st, Val.int (if req.2.1 then 1 else 0)]) ≤
      bsMB M J R (dyadicExp aReq) (dyadicExp ξReq) bU :=
    le_trans (Nat.le_add_left _ _) (bsMB_D4input hlen hc hok hk)
  exact (ImplementsO.runsWithinBitsO bsRankOK_round bsRoundProg_zero hImpl hin hrun).mono
    (asm_machineBound_le_round M J R ha0 ha1 hξ0 hξ1 bU)

/-! ## The final theorems -/

/-- **Main Theorem (B), bit-space clause, with the constant `2^e`** for every `e ≥ bsChainExp`. -/
theorem theorem_B_space_of_le {e : ℕ} (he : bsChainExp ≤ e) : Theorem_B_space_with e :=
  theorem_B_space_with_of asm_resp_parse asm_init_runsW v31_round_runsW
    (fun M J R aReq ξReq _ _ _ _ bU => asmBound_mono he M J R aReq ξReq bU)

/-- **Main Theorem (B), guarantee and bit-space clause jointly, with the constant `2^e`** for every
`e ≥ bsChainExp`. -/
theorem theorem_B_joint_of_le {e : ℕ} (he : bsChainExp ≤ e) : Theorem_B_joint_with e :=
  theorem_B_joint_with_of asm_resp_parse asm_init_runsW v31_round_runsW
    (fun M J R aReq ξReq _ _ _ _ bU => asmBound_mono he M J R aReq ξReq bU)

/-- `Theorem_B_space_with 128`. -/
theorem theorem_B_space_2e128_proof : Theorem_B_space_with 128 :=
  theorem_B_space_of_le (by unfold bsChainExp; norm_num)

/-- `Theorem_B_joint_with 128`. -/
theorem theorem_B_joint_2e128_proof : Theorem_B_joint_with 128 :=
  theorem_B_joint_of_le (by unfold bsChainExp; norm_num)

end F2e2e.BSpace
