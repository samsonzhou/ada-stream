import F2e2e.BSpace.O2GlueInit
import F2e2e.BSpace.O2SizeFrames
import F2e2e.BSpace.O2TightChiLinks

/-!
# B_space, route O2b: the init frame's input size and budget coefficients (C-PROB)

Owner: C-PROB (51ccc2e3), for the O2b technical lead 17fc0802, e26ae4ae (the init top frame
`F2e2e/BSpace/O2GlueInit.lean`: `o2i_mI`, `o2i_τI`) and B-ACC (`finI` via `O2B.o2f_final`). Prefix `o2is`.

At the actual parameters `A = asmParams M J R a_req ξ_req`, `N = A.N`, `χ = valChi M J R (dyadicDown a_req)
(dyadicDown ξ_req)`, with Plan A's link `q_A ≤ 2χ` (B-NUM's `o2c_alg2HAExp_le_two`, O2B-SIZE's χ-links
`O2sLinks A χ 2`):
* `o2is_inI`: the field `O2Inputs.inI` at `mI = o2i_mI` (the input `[params, records]` is part of the top-frame
  bound `o2i_B`);
* `o2is_mI_le : o2i_mI ≤ 1 · (N b_𝒰) + 4 · (N χ)`;
* `o2is_τI_le : o2i_τI ≤ 31 · (N b_𝒰) + 9853064 · (N χ)` (`9853064 = 136 · 72449`, B-ARCH's
  `o2cl_tightM_le : 2^8 tightA + cAddA ≤ 72449 N χ`).
For B-ACC's closing conditions of the init frame (`S = 11 m + τ`): `11 · 1 + 31 = 42 ≤ 4161790` and
`11 · 4 + 9853064 = 9853108 ≤ 253867717`. Every `N`-free term is absorbed by `N ≥ 2^{30} (p + 1) χ` and `60 < χ`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/-! ## Plan A's χ-links at the actual parameters -/

/-- **The χ-links of the actual parameters with `q_A ≤ 2χ`** (B-NUM's Plan A). -/
theorem o2is_links (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    O2sLinks (asmParams M J R aReq ξReq)
      (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) 2 :=
  o2s_links_actual M J R ha0 ha1 hξ0 hξ1 (by
    rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
    exact o2cl_qA_le_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq)) (by norm_num)

/-! ## Generic component bounds -/

section generic

variable {A : AdaParams} {χ cq : ℕ}

/-- **B-ACC's state bound** `o2mStB A ≤ cq N χ + N χ + 6 N` (the bound behind `o2s_base_st`). -/
theorem o2is_stB_le (L : O2sLinks A χ cq) : o2mStB A ≤ cq * (A.N * χ) + A.N * χ + 6 * A.N := by
  unfold o2mStB
  have e1 : A.N * (A.qA + Nat.size A.fuel + 4) = A.N * A.qA + A.N * Nat.size A.fuel + 4 * A.N := by
    ring
  have hNF : A.N * Nat.size A.fuel ≤ A.N * χ + A.N :=
    calc A.N * Nat.size A.fuel ≤ A.N * (χ + 1) := Nat.mul_le_mul_left _ L.sF_le
      _ = A.N * χ + A.N := by ring
  have hp : A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have hF := L.sF_le; have hK := L.sK_le; have hC := L.sC_le
    have h1 := Nat.mul_le_mul_left A.p
      (show Nat.size A.fuel + Nat.size (maxKs A) + 6 ≤ A.qA + 7 * χ + 40 by omega)
    have e : (A.p + 1) * (A.qA + 7 * χ + 40) = A.p * (A.qA + 7 * χ + 40) + (A.qA + 7 * χ + 40) := by
      ring
    omega
  have hs := L.small
  have hq := L.qNX
  omega

/-- `χ ≤ N` and `p + 1 ≤ N` (from `N ≥ 2^{30} (p + 1) χ`). -/
theorem o2is_chi_p_le_N (L : O2sLinks A χ cq) : 1073741824 * χ ≤ A.N ∧ 1073741824 * (A.p + 1) ≤ A.N := by
  have h := L.pX
  have hχ := L.chi_gt
  constructor
  · have : 1073741824 * χ ≤ 1073741824 * ((A.p + 1) * χ) :=
      Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))
    omega
  · have : 1073741824 * (A.p + 1) ≤ 1073741824 * ((A.p + 1) * χ) :=
      Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_right _ (by omega))
    omega

/-- **The init frame's value bound, generic**: `|params| + |pub| + o2iRecB + 2 (p + 1) + o2mStB + 3 ≤
N b_𝒰 + (cq + 2) N χ`. -/
theorem o2is_B_le_gen (L : O2sLinks A χ cq) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) (bU : ℕ) :
    o2sParamsSize A.M A.J A.R eA eXi + valSize (adaPubEnc A) + o2iRecB A bU + 2 * (A.p + 1) +
        o2mStB A + 3 ≤ 1 * (A.N * bU) + (cq + 2) * (A.N * χ) := by
  have hS := o2is_stB_le L
  have hP := o2s_paramsSize_le L hpar
  have hPub := o2s_base_pub L
  have hNX := L.NX
  obtain ⟨hχN, hpN⟩ := o2is_chi_p_le_N L
  have e1 : o2iRecB A bU = A.N * bU + 2 * A.N + 1 := by unfold o2iRecB; ring
  have e2 : (cq + 2) * (A.N * χ) = cq * (A.N * χ) + 2 * (A.N * χ) := by ring
  rw [e1, e2]
  omega

/-- **The init frame's callee budget, generic**: from a bound `o2MA A ≤ C · N χ` (`C ≥ 1`) on the value bound of
`adaInit`, `o2iTopT ≤ 31 N b_𝒰 + 136 C N χ`. -/
theorem o2is_topT_le_gen (L : O2sLinks A χ cq) {eA eXi : ℕ} (hA : A = adaParams eA eXi A.M A.J A.R)
    (hpar : eA + eXi + 49 ≤ χ) (bU : ℕ) {C : ℕ} (hC : 1 ≤ C) (hMA : o2MA A ≤ C * (A.N * χ)) :
    o2iTopT A.M A.J A.R eA eXi bU ≤ 31 * (A.N * bU) + 136 * C * (A.N * χ) := by
  have hPub := o2s_base_pub L
  have hNX := L.NX
  obtain ⟨hχN, hpN⟩ := o2is_chi_p_le_N L
  have hBP := o2s_frame_bsPub L hpar
  have hbs : valSize (encL encN A.blockSizes) < valSize (adaPubEnc A) :=
    valSize_lt_of_mem (l := pubFields A) (by simp [pubFields])
  unfold o2iTopT
  rw [← hA]
  refine max_le ?_ (max_le ?_ ?_)
  · -- the parameter record (600)
    have h1 : 134 * bsPubBound A.M A.J A.R eA eXi ≤ 134 * (A.N * χ) := Nat.mul_le_mul_left _ hBP
    have h2 : 134 * (A.N * χ) ≤ 136 * C * (A.N * χ) :=
      Nat.mul_le_mul_right _ (by omega)
    generalize 136 * C * (A.N * χ) = X at h2 ⊢
    omega
  · -- the blocks (900)
    have e1 : o2iRecB A bU = A.N * bU + 2 * A.N + 1 := by unfold o2iRecB; ring
    rw [e1]
    have h2 : 2 * (A.N * χ) ≤ 136 * C * (A.N * χ) := Nat.mul_le_mul_right _ (by omega)
    generalize 136 * C * (A.N * χ) = X at h2 ⊢
    omega
  · -- `adaInit` (601)
    have h1 : 136 * o2MA A ≤ 136 * (C * (A.N * χ)) := Nat.mul_le_mul_left _ hMA
    have e : 136 * (C * (A.N * χ)) = 136 * C * (A.N * χ) := by ring
    rw [e] at h1
    generalize 136 * C * (A.N * χ) = X at h1 ⊢
    omega

end generic

/-! ## The actual parameters -/

section actual

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- **The field `inI` of `O2Inputs`** at `mI = o2i_mI`: the initialization input fits the top frame. -/
theorem o2is_inI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) (bU : ℕ) (code : U → ℕ), (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (F2e2e.alg2Params M J R aReq ξReq).N → U),
      valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) ≤ o2i_mI M J R aReq ξReq bU := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hcode s
  have hR := o2s_valSize_encRecords_le code s bU hcode
  unfold o2sRecordsBound at hR
  have hN := V2.v2par_N M J R ha0 ha1 hξ0 hξ1
  have hR' : valSize (encRecords code s) ≤
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N * (bU + 2) + 1 := by
    rw [← hN]
    exact hR
  rw [o2s_valSize_list2]
  unfold o2i_mI o2i_B o2iRecB encVParams
  simp only [asmParams]
  omega

/-- **The value bound of the init frame in `N b_𝒰`, `N χ`**: `o2i_mI ≤ 1 · (N b_𝒰) + 4 · (N χ)`. -/
theorem o2is_mI_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2i_mI M J R aReq ξReq bU ≤
      1 * ((asmParams M J R aReq ξReq).N * bU) +
        4 * ((asmParams M J R aReq ξReq).N *
          F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  have h := o2is_B_le_gen (o2is_links M J R ha0 ha1 hξ0 hξ1) (o2s_eAX_le_chi M J R ha0 ha1 hξ0 hξ1) bU
  unfold o2i_mI o2i_B
  rw [o2s_valSize_encInts_params]
  exact h

/-- **The callee budget of the init frame in `N b_𝒰`, `N χ`**: `o2i_τI ≤ 31 · (N b_𝒰) + 9853064 · (N χ)`. -/
theorem o2is_τI_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2i_τI M J R aReq ξReq bU ≤
      31 * ((asmParams M J R aReq ξReq).N * bU) +
        9853064 * ((asmParams M J R aReq ξReq).N *
          F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  have hMA : o2MA (asmParams M J R aReq ξReq) ≤
      72449 * ((asmParams M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
    have h := o2cl_tightM_le M J R ha0 ha1 hξ0 hξ1
    rw [← V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
    unfold o2MA
    rw [← Nat.mul_assoc]
    exact h
  have h := o2is_topT_le_gen (o2is_links M J R ha0 ha1 hξ0 hξ1) (eA := F2e2e.dyadicExp aReq)
    (eXi := F2e2e.dyadicExp ξReq) rfl (o2s_eAX_le_chi M J R ha0 ha1 hξ0 hξ1) bU (by norm_num) hMA
  exact h

end actual

end F2e2e.BSpace
