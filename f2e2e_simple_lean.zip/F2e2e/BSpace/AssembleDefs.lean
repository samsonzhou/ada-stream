import F2e2e.B.Mechanism

/-!
# B_space, top level (C-TOP): the shared definitions of the assembly

* `asmParams M J R a_req ξ_req = adaParams (dyadicExp a_req) (dyadicExp ξ_req) M J R`: the core parameters for the
  public parameters of `Theorem_B_space`;
* `asmBlocks A code s`: the stored blocks of record codes (B-ARCH's `splitBlocks` of the codes of the sample, in
  sample order).

Imported by the assembly (`Assemble.lean`) and by the request-oracle forms of the entry specs (W3's
`DslMainReq.lean`), so that both state the programs' data with the same terms.
-/

namespace F2e2e.BSpace

open F2e2e.B

/-- The core parameters for the public parameters of `Theorem_B_space`. -/
noncomputable abbrev asmParams (M J R : ℕ) (aReq ξReq : ℝ) : AdaParams :=
  adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R

/-- The stored blocks of record codes (B-ARCH's `splitBlocks` of the codes of the sample, in sample order). -/
def asmBlocks (A : AdaParams) {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) : List (List ℕ) :=
  splitBlocks A.blockSizes (List.ofFn fun ℓ => code (s ℓ))

end F2e2e.BSpace
