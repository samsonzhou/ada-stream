import F2e2e.Spec
import F2e2e.BSpace.AssembleThread
import F2e2e.BSpace.RefineDefs
import F2e2e.BSpace.RefineRound

/-!
# B_space, top level (C-TOP): conformance of the threaded core run with the Spec's Algorithm 2

The round programs of `Theorem_B_space` run W4's core on exactly the data of the quantized request of round `t`
(W4's alignment 13:13Z): `asmRound A s reqs t st = bsCoreRound A st (coreVals A s q) q.l q.u (reqs t).2.1` with
`q = quantReq A (reqs t)`, which is the core round `coreStep A s q st` (`asmRound_eq_coreStep`). Along the threaded
run (`threadRun`, `F2e2e/BSpace/AssembleThread.lean`), B-ARCH's round and init conformance (R1 `refine_round`,
R2 `refine_init`, `F2e2e/BSpace/RefineRound.lean`) give:

* `asm_fold`: the Spec's replay fold of `alg2Request` over the views of rounds `0, …, n-1` (from `alg2Init` on the
  same tape) ends on the unread tape of the threaded run after `n` rounds, in a state corresponding (`StCorr`) to
  the core's;
* **`asm_conform`** (R3): the output `r` of round `t` of the threaded run gives the Spec's response
  `outRespV2 r = (alg2Exec P2 t (viewsOf s reqs t) ω).response`, i.e. `alg2Mech M J R aReq ξReq c t (viewsOf s reqs t) ω`.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2

/-- Round `t` of the core on the quantized request `reqs t` (the data that the round program computes from the
oracle of request `t`). -/
noncomputable def asmRound (A : AdaParams) {U : Type} (s : Fin A.N → U) (reqs : ℕ → VReq U) (t : ℕ)
    (st : AdaState) : BitProg (CoreOut × AdaState) :=
  bsCoreRound A st (coreVals A s (quantReq A (reqs t))) (quantReq A (reqs t)).l (quantReq A (reqs t)).u
    (reqs t).2.1

theorem asmRound_eq_coreStep (A : AdaParams) {U : Type} (s : Fin A.N → U) (reqs : ℕ → VReq U) (t : ℕ)
    (st : AdaState) : asmRound A s reqs t st = coreStep A s (quantReq A (reqs t)) st := by
  unfold asmRound bsCoreRound coreStep
  rfl

/-- The Spec's view of request `j` (as in `viewsOf`). -/
def asmView {U : Type} {N : ℕ} (s : Fin N → U) (reqs : ℕ → VReq U) (j : ℕ) : VView N :=
  ((fun ℓ => (reqs j).1 (s ℓ)), (reqs j).2)

theorem ofFn_viewsOf {U : Type} {N : ℕ} (s : Fin N → U) (reqs : ℕ → VReq U) (t : ℕ) :
    List.ofFn (viewsOf s reqs t) = List.ofFn fun j : Fin (t + 1) => asmView s reqs j.val := rfl

/-- One step of the Spec's replay fold. -/
noncomputable def asmStep (P2 : Alg2Params) (acc : VResponse × Alg2State × List Bool) (v : VView P2.N) :
    VResponse × Alg2State × List Bool :=
  alg2Request P2 acc.2.1 v acc.2.2

theorem foldl_ofFn_succ {α β : Type} (f : β → α → β) (b : β) (g : ℕ → α) (n : ℕ) :
    (List.ofFn fun j : Fin (n + 1) => g j.val).foldl f b =
      f ((List.ofFn fun j : Fin n => g j.val).foldl f b) (g n) := by
  rw [List.ofFn_succ', List.concat_eq_append, List.foldl_append]
  simp only [Fin.val_castSucc, Fin.val_last, List.foldl_cons, List.foldl_nil]

/-- **The replay fold along the threaded run.** -/
theorem asm_fold {U : Type} {P2 : Alg2Params} {A : AdaParams} (hP : ParCorr P2 A) (hN : P2.N = A.N)
    (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid) (τ0 : List Bool) :
    ∀ (n : ℕ) (st : AdaState) (τ : List Bool),
      threadRun (adaInit A) (asmRound A (castSample hN s) reqs) τ0 n = some (st, τ) →
      ∃ (acc : VResponse) (st2 : Alg2State),
        (List.ofFn fun j : Fin n => asmView s reqs j.val).foldl (asmStep P2)
            (VResponse.accept, (alg2Init P2 τ0).1, (alg2Init P2 τ0).2) = (acc, st2, τ) ∧
          StCorr A st2 st := by
  intro n
  induction n with
  | zero =>
    intro st τ h
    obtain ⟨hst, hτ⟩ := refine_init hP (show (adaInit A).run τ0 = some (st, τ) from h)
    refine ⟨VResponse.accept, (alg2Init P2 τ0).1, ?_, hst⟩
    simp only [List.ofFn_zero, List.foldl_nil, hτ]
  | succ n ih =>
    intro st' τ' h
    obtain ⟨st, τ, r, hn, hrun⟩ := threadRun_succ_eq_some h
    obtain ⟨acc, st2, hfold, hcorr⟩ := ih st τ hn
    rw [asmRound_eq_coreStep] at hrun
    obtain ⟨st2', hreq, hcorr'⟩ := refine_round hP hN hcorr s (reqs n) (hvalid n).1 hrun
    refine ⟨outRespV2 r, st2', ?_, hcorr'⟩
    rw [foldl_ofFn_succ, hfold]
    exact hreq

/-- **R3 (conformance)**: the output of round `t` of the threaded run is the Spec's response of round `t`. -/
theorem asm_conform {U : Type} {P2 : Alg2Params} {A : AdaParams} (hP : ParCorr P2 A) (hN : P2.N = A.N)
    {c : ℕ} (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid) (ω : Fin c → Bool)
    (t : ℕ) (r : CoreOut)
    (h : threadOut (adaInit A) (asmRound A (castSample hN s) reqs) (List.ofFn ω) t = some r) :
    outRespV2 r = (alg2Exec P2 t (viewsOf s reqs t) ω).response := by
  obtain ⟨st, τ, st', τ', ht, hrun⟩ := threadOut_eq_some h
  obtain ⟨acc, st2, hfold, hcorr⟩ := asm_fold hP hN s reqs hvalid (List.ofFn ω) t st τ ht
  rw [asmRound_eq_coreStep] at hrun
  obtain ⟨st2', hreq, -⟩ := refine_round hP hN hcorr s (reqs t) (hvalid t).1 hrun
  have hlast : (List.ofFn fun j : Fin (t + 1) => asmView s reqs j.val).foldl (asmStep P2)
      (VResponse.accept, (alg2Init P2 (List.ofFn ω)).1, (alg2Init P2 (List.ofFn ω)).2) =
      (outRespV2 r, st2', τ') := by
    rw [foldl_ofFn_succ, hfold]
    exact hreq
  unfold alg2Exec
  rw [ofFn_viewsOf]
  exact (congrArg Prod.fst hlast).symm

end F2e2e.BSpace
