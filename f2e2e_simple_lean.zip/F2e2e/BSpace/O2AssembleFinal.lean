import F2e2e.BSpace.O2Assemble
import F2e2e.BSpace.O2GlueInitAsm
import F2e2e.BSpace.BoundParams
import F2e2e.BSpace.O2InitFin
import F2e2e.BSpace.O2FinalInst
import F2e2e.BSpace.O2GlueMainAsm
import F2e2e.BSpace.O2GlueMainCoef
import F2e2e.BSpace.O2RoundCalleesAt
import F2e2e.BSpace.V31O2Round

/-!
# B_space at the paper's constant (O2b): the instance of `O2Inputs` and the final theorems (W4)

Collects the O2b pieces into `O2Inputs` (`O2Assemble.lean`), from which `theorem_B_space_with_30_of` /
`theorem_B_joint_with_30_of` give `Theorem_B_space_with 30` / `Theorem_B_joint_with 30` (Spec v3.1: every oracle
consistent with the sample, history-free states).

The fields of `o2aInputs`:
* `mI := o2i_mI`, `τI := o2i_τI`, `implI := o2i_implI` (e26ae4ae, `O2GlueInit.lean`, `O2GlueInitAsm.lean`);
* `inI := o2a_inI` (here; C-PROB's `o2is_inI` is the same field);
* `finI := o2is_finI` (C-PROB, `O2InitFin.lean`, via B-ACC's `o2f_finI_pure`);
* `mR := o2m_mR`, `τR := o2m_τR` (`O2GlueMainBounds.lean`), `inR := o2m_inR` (C-FP, `O2GlueMainCoef.lean`);
* `finR := O2B.o2fi_finR` (B-ACC, `O2FinalInst.lean`);
* `implR := v31o2_implR_agree hIvT hNumT` (`V31O2Round.lean`: C-BANK's `o2m_implR_of`, `O2GlueMainAsm.lean`, for
  every agreeing oracle), from the two tight entry specs `O2mIvTightSpec bsRoundProg` / `O2mNumTightSpec bsRoundProg`.
  `theorem_B_space_with_30_of_tight` / `theorem_B_joint_with_30_of_tight` take them as hypotheses; the final
  theorems below discharge them with C-TREE's instances `o2ct_ivTightSpec_round` / `o2ct_numTightSpec_round`
  (`O2RoundCalleesAt.lean`).

Final results (sorry-free; `#print axioms` gives `[propext, Classical.choice, Quot.sound]` for both):
* `theorem_B_space_proof : F2e2e.Theorem_B_space` (the headline is `BSpace.Theorem_B_space_with 30`
  by definition);
* `theorem_B_joint_proof : F2e2e.Theorem_B_joint` (the headline is `BSpace.Theorem_B_joint_with 30`
  by definition).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.Cost F2e2e.C.Impl

/-- **`inI`**: the initialization input `[params, records]` fits the init frame `o2i_mI`
(`|params| + |records| + 3`, with `|records| ≤ N (b_𝒰 + 2) + 1`, B-ARCH's `bs_valSize_encRecords_le`). -/
theorem o2a_inI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) (bU : ℕ) (code : U → ℕ), (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U),
      valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) ≤ o2i_mI M J R aReq ξReq bU := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hcode s
  have hrec := bs_valSize_encRecords_le code s bU hcode
  have hN : (alg2Params M J R aReq ξReq).N * (bU + 2) + 1 =
      (asmParams M J R aReq ξReq).N * (bU + 2) + 1 := by
    rw [refine_N M J R ha0 ha1 hξ0 hξ1]
  unfold o2i_mI o2i_B o2iRecB
  show valSize (Val.list [encInts [(M : ℤ), (J : ℤ), (R : ℤ), (dyadicExp aReq : ℤ), (dyadicExp ξReq : ℤ)],
    encRecords code s]) ≤ _
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **The O2b inputs**, from the two tight entry specs of the request program (instantiated by C-TREE's
`o2ct_ivTightSpec_round` / `o2ct_numTightSpec_round` in the final theorems below). -/
noncomputable def o2aInputs (hIvT : O2mIvTightSpec bsRoundProg) (hNumT : O2mNumTightSpec bsRoundProg) :
    O2Inputs where
  mI := o2i_mI
  τI := o2i_τI
  mR := o2m_mR
  τR := o2m_τR
  implI := o2i_implI
  inI := o2a_inI
  finI := o2is_finI
  implR := by
    intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code hinj hcode s req hreq orc h0 h1 h2 st hok
    exact v31o2_implR_agree hIvT hNumT M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s req hreq
      h0 h1 h2 st hok
  inR := o2m_inR
  finR := O2B.o2fi_finR

/-- **Main Theorem (B), bit-space clause, with the paper's constant `2^30`**, from the two tight entry specs of
the request program. -/
theorem theorem_B_space_with_30_of_tight (hIvT : O2mIvTightSpec bsRoundProg)
    (hNumT : O2mNumTightSpec bsRoundProg) : Theorem_B_space_with 30 :=
  theorem_B_space_with_30_of (o2aInputs hIvT hNumT)

/-- **Main Theorem (B), guarantee and bit-space clause jointly, with the paper's constant `2^30`**, from the two
tight entry specs of the request program. -/
theorem theorem_B_joint_with_30_of_tight (hIvT : O2mIvTightSpec bsRoundProg)
    (hNumT : O2mNumTightSpec bsRoundProg) : Theorem_B_joint_with 30 :=
  theorem_B_joint_with_30_of (o2aInputs hIvT hNumT)

/-- **Main Theorem (B), bit-space clause, with the paper's constant `2^30`** (`F2e2e.Theorem_B_space`). -/
theorem theorem_B_space_proof : F2e2e.Theorem_B_space :=
  theorem_B_space_with_30_of_tight o2ct_ivTightSpec_round o2ct_numTightSpec_round

/-- **Main Theorem (B), guarantee and bit-space clause jointly, with the paper's constant `2^30`**
(`F2e2e.Theorem_B_joint`). -/
theorem theorem_B_joint_proof : F2e2e.Theorem_B_joint :=
  theorem_B_joint_with_30_of_tight o2ct_ivTightSpec_round o2ct_numTightSpec_round

end F2e2e.BSpace
