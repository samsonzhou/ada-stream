import F2e2e.BSpace.DslEvalsDefs

/-!
# B_space, D2: the inner loop of `bsEvals` (key 912)

Owner of the proof: W5 (c1b4f720), helper of 1beb339b (D2), who owns the statement below (fixed; do not
change it) and the rest of `F2e2e/BSpace/DslEvals*.lean`.

**Statement** `bsE_inner_run`: the iterations of `body_bsEvalsInner` (`F2e2e/BSpace/DslEvalsDefs.lean`) from
the accumulator `bsE_encInner q rest acc = [encL encN rest, encL encN acc, Val.int (q + 1)]` return
`encL encN (acc.reverse ++ rest.map (bsE_g orc q))`, one oracle call per code, with every value at most
`|rest| + |result| + q + 20`.

**Proof plan** (all helpers are in `DslEvalsDefs.lean`, `CalcORules.lean`, `MachineEvalsO.lean`; model:
`bsE_revStep_run`):
* induction on `rest`, generalizing `acc`;
* `rest = []`: `EvalsValO.stop hlib.inner`; the body is `bsC.ite_true (bsC.isNil_nil (head (var 0)) _)
  one_ne_zero (EvalsValO.pair (lit 0) (bsE_rev hlib.rev (head (tail (var 0))) _) _)`; the result
  `Val.list (acc.map encN).reverse` is `encL encN (acc.reverse ++ [].map _)` (`List.map_reverse`, `simp`);
* `rest = r :: rest'`: `EvalsValO.cast_bits (EvalsValO.cont hlib.inner hb one_ne_zero ih) (by simp)` with
  `ih` the induction hypothesis at `bsE_g orc q r :: acc` and `hb` the body:
  `bsC.ite_false (bsC.isNil_cons (head (var 0)) _) rfl (EvalsValO.letE
    (EvalsValO.oracle (bsC.triple (lit 0) (head (head (var 0))) (head (tail (tail (var 0)))) _) _)
    (EvalsValO.pair (lit 1) (bsC.triple (tail (head (var 1)))
      (EvalsValO.cons (bsC.div (bsC.add (var 0) (lit 1) _) (lit 2) two_ne_zero _) (head (tail (var 1))) _)
      (head (tail (tail (var 1)))) _) _))`;
  the pushed value is `encN (bsE_g orc q r)` by `bsE_encN_g`; the target identity
  `(g r :: acc).reverse ++ rest'.map g = acc.reverse ++ (r :: rest').map g` is `simp`;
* sizes: `bsE_vs_nil/int0/int1/int2/one/two/three/cons`, `bsE_vsQ` (`q + 1`), `bsE_vs_answer` (the answer,
  answer + 1, and their half), `bsE_vsL_append`, `bsE_vsL_reverse`, `bsE_vsL_cons`, `bsE_vs_pos`; rewrite
  sizes into `valSize` atoms of the components and close with `omega` (do not mix `valSize (Val.list l)` and
  `listSize l`).
* Pitfall: in `have h := lemma …`, pass `(M := M)` when the conclusion does not fix `M` (otherwise a size
  side goal `… ≤ ?M` is closed by `rfl` with the wrong `M`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-- The size of the inner loop accumulator. -/
theorem bsE_vs_encInner (q : ℕ) (rest acc : List ℕ) :
    valSize (bsE_encInner q rest acc) =
      valSize (encL encN rest) + valSize (encL encN acc) + valSize (Val.int ((q : ℤ) + 1)) + 4 := by
  unfold bsE_encInner
  exact bsE_vs_three _ _ _

/-- **The inner loop of `bsEvals`** (key 912): from `[rest, acc, q + 1]` the iterations return the indices
computed so far (`acc` reversed) followed by the indices `bsE_g orc q r` of the codes `r` of `rest`, one
oracle call per code; every value is at most `|rest| + |result| + q + 20`. -/
theorem bsE_inner_run {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} (hlib : BsEvalsLib prog)
    (q : ℕ) : ∀ rest acc : List ℕ,
      (∀ r ∈ rest, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) →
      valSize (encL encN rest) + valSize (encL encN (acc.reverse ++ rest.map (bsE_g orc q))) + q + 20 ≤
        M →
      EvalsValO orc prog M [] [] (.inr (bsE_innerKey, bsE_encInner q rest acc))
        (encL encN (acc.reverse ++ rest.map (bsE_g orc q))) := by
  have hQ := bsE_vsQ q
  intro rest
  induction rest with
  | nil =>
    intro acc _ hM
    have hres : encL encN (acc.reverse ++ ([] : List ℕ).map (bsE_g orc q)) =
        Val.list (acc.map encN).reverse := by
      simp [encL, List.map_reverse]
    have hA : valSize (encL encN acc) = valSize (encL encN (acc.reverse ++ ([] : List ℕ).map
        (bsE_g orc q))) := by
      rw [hres]
      show valSize (Val.list (acc.map encN)) = valSize (Val.list (acc.map encN).reverse)
      rw [bsE_vs_reverse]
    have hS := bsE_vs_encInner q [] acc
    have hN : valSize (encL encN ([] : List ℕ)) = 1 := rfl
    have hAc : valSize (Val.list (List.map encN acc)) = valSize (encL encN acc) := rfl
    have hAr : valSize (Val.list (List.map encN acc).reverse) = valSize (encL encN acc) := by
      rw [bsE_vs_reverse]; rfl
    have hacc : valSize (encL encN acc) + q + 21 ≤ M := by omega
    rw [hres]
    refine EvalsValO.stop hlib.inner ?_
    unfold body_bsEvalsInner
    have hst : valSize (bsE_encInner q [] acc) ≤ M := by omega
    unfold bsE_encInner at hst
    refine EvalsValO.cast_bits (bsC.ite_true (bsC.isNil_nil (EvalsValO.head (EvalsValO.var rfl)
      (by rw [bsE_vs_nil]; omega)) (by omega)) one_ne_zero
      (EvalsValO.pair (EvalsValO.lit (by rw [bsE_vs_int0]; omega))
        (bsE_rev hlib.rev (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl)
          (by rw [bsE_vs_two]; omega)) (by omega))
          (by omega))
        (by rw [bsE_vs_two, bsE_vs_int0]; omega))) (by simp)
  | cons r rest ih =>
    intro acc hO hM
    obtain ⟨hr0, hr1⟩ := hO r List.mem_cons_self
    have hO' : ∀ r' ∈ rest, 0 ≤ orc 0 (r' : ℤ) (q + 1) ∧ orc 0 (r' : ℤ) (q + 1) ≤ 2 ^ (q + 1) :=
      fun r' h => hO r' (List.mem_cons_of_mem _ h)
    obtain ⟨ho1, ho2, ho3⟩ := bsE_vs_answer hr0 hr1
    have hg : encN (bsE_g orc q r) = Val.int ((orc 0 (r : ℤ) (q + 1) + 1) / 2) := bsE_encN_g hr0
    have hid : (bsE_g orc q r :: acc).reverse ++ rest.map (bsE_g orc q) =
        acc.reverse ++ (r :: rest).map (bsE_g orc q) := by simp
    -- sizes of the pieces
    have e1 : valSize (encL encN (r :: rest)) = valSize (encN r) + 1 + valSize (encL encN rest) :=
      bsE_vsL_cons encN r rest
    have e2 : valSize (encL encN (acc.reverse ++ (r :: rest).map (bsE_g orc q))) + 1 =
        valSize (encL encN acc.reverse) + valSize (encL encN ((r :: rest).map (bsE_g orc q))) :=
      bsE_vsL_append encN acc.reverse ((r :: rest).map (bsE_g orc q))
    have e3 : valSize (encL encN acc.reverse) = valSize (encL encN acc) := bsE_vsL_reverse encN acc
    have e4 : valSize (encL encN ((r :: rest).map (bsE_g orc q))) =
        valSize (encN (bsE_g orc q r)) + 1 + valSize (encL encN (rest.map (bsE_g orc q))) := by
      rw [List.map_cons]
      exact bsE_vsL_cons encN _ _
    have e5 : valSize (encL encN (bsE_g orc q r :: acc)) =
        valSize (encN (bsE_g orc q r)) + 1 + valSize (encL encN acc) := bsE_vsL_cons encN _ _
    have e6 : valSize (encL encN (rest.map (bsE_g orc q))) ≥ 1 := bsE_vs_pos _
    have hgv : valSize (encN (bsE_g orc q r)) ≤ q + 3 := by rw [hg]; exact ho3
    have hrv : valSize (encN r) ≥ 1 := valSize_pos _
    have hS := bsE_vs_encInner q (r :: rest) acc
    have hS' := bsE_vs_encInner q rest (bsE_g orc q r :: acc)
    have b1 : valSize (Val.list (List.map encN acc)) = valSize (encL encN acc) := rfl
    have b2 : valSize (Val.list (List.map encN rest)) = valSize (encL encN rest) := rfl
    have b3 : valSize (Val.list (encN r :: List.map encN rest)) = valSize (encL encN (r :: rest)) :=
      rfl
    have b4 : valSize (Val.int (r : ℤ)) = valSize (encN r) := rfl
    have b5 : valSize (Val.list (Val.int ((orc 0 (r : ℤ) (q + 1) + 1) / 2) :: List.map encN acc)) =
        valSize (encL encN (bsE_g orc q r :: acc)) := by
      rw [bsE_vs_cons, e5, hg]
      rfl
    -- the induction hypothesis
    have hM' : valSize (encL encN rest) +
        valSize (encL encN ((bsE_g orc q r :: acc).reverse ++ rest.map (bsE_g orc q))) + q + 20 ≤
          M := by
      rw [hid]
      omega
    have hrest := ih (bsE_g orc q r :: acc) hO' hM'
    rw [hid] at hrest
    -- the body
    have hb : EvalsValO orc prog M [bsE_encInner q (r :: rest) acc] [] (.inl body_bsEvalsInner)
        (Val.list [Val.int 1, bsE_encInner q rest (bsE_g orc q r :: acc)]) := by
      have hst : valSize (bsE_encInner q (r :: rest) acc) ≤ M := by omega
      have hst' : valSize (bsE_encInner q rest (bsE_g orc q r :: acc)) + 3 ≤ M := by omega
      have hrow : valSize (Val.list (encN r :: rest.map encN)) ≤ M := by
        show valSize (encL encN (r :: rest)) ≤ M
        omega
      have hnew : encL encN (bsE_g orc q r :: acc) =
          Val.list (Val.int ((orc 0 (r : ℤ) (q + 1) + 1) / 2) :: acc.map encN) := by
        simp only [encL, List.map_cons, hg]
      unfold bsE_encInner at hst hst' ⊢
      rw [hnew] at hst' ⊢
      unfold body_bsEvalsInner
      refine EvalsValO.cast_bits (bsC.ite_false (bsC.isNil_cons (EvalsValO.head (EvalsValO.var rfl)
        (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by omega))
        rfl (EvalsValO.letE
          (EvalsValO.oracle (bsC.triple (EvalsValO.lit (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (EvalsValO.head (EvalsValO.head (EvalsValO.var rfl) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (EvalsValO.head (EvalsValO.tail (EvalsValO.tail (EvalsValO.var rfl) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (by omega))
          (EvalsValO.pair (EvalsValO.lit (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (bsC.triple
              (EvalsValO.tail (EvalsValO.head (EvalsValO.var rfl) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
              (EvalsValO.cons (bsC.div (bsC.add (EvalsValO.var rfl)
                  (EvalsValO.lit (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by omega))
                  (EvalsValO.lit (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) two_ne_zero (by omega))
                (EvalsValO.head (EvalsValO.tail (EvalsValO.var rfl) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
                (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
              (EvalsValO.head (EvalsValO.tail (EvalsValO.tail (EvalsValO.var rfl) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)) (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
              (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega))
            (by simp only [bsE_vs_three, bsE_vs_two, bsE_vs_one, bsE_vs_cons, bsE_vs_nil, bsE_vs_int0, bsE_vs_int1, bsE_vs_int2] at hst hst' b1 b2 b3 b5 ⊢; omega)))) (by simp)
    exact EvalsValO.cast_bits (EvalsValO.cont hlib.inner hb one_ne_zero hrest) (by simp)

end F2e2e.BSpace
