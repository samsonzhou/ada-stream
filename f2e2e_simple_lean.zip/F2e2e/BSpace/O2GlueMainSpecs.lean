import F2e2e.BSpace.O2GlueMainDefs

/-!
# B_space, route O2b: the top frame of the round program, the tight callee specs (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802. The two hypotheses of `o2m_implR_of`
(`O2GlueMainAsm.lean`): the tight specs of the ADA entries `adaInterval` (602) and `adaNumerical` (603) on a
program, i.e. the callee rule of the O2b families 5 and 7 (`adaInterval_impl` / `adaNumerical_impl_of` with
`TightM A M` in place of `2^32 · adaBoundA A ≤ M`, the table premises discharged). Proved on `bsRoundProg` by
C-TREE (`o2ct_ivTightSpec`, `o2ct_numTightSpec`, `F2e2e/BSpace/O2RoundCallees*.lean`). **Byte-stable.**
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The tight specs of the ADA entries (callee-rule stubs) -/

/-- **The tight spec of `adaInterval` (602) on `prog`**: `adaInterval_impl` with the tight value premise
`TightM A M` and the table premises discharged (O2b family 5, `adaInterval_impl_t`). -/
def O2mIvTightSpec (prog : List Expr) : Prop :=
  ∀ (M : ℕ) (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) (Bq : ℕ),
    NormQSpec prog M → A.blockSizes.length = A.p + 1 → A.Tmax.length = A.p →
    (∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) → AdaOK A st → ValsOKA A vals →
    (bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq) → (bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq) →
    TightM A M → 2 ^ 28 * Bq ≤ M →
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]] body_adaInterval
      (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u)

/-- **The tight spec of `adaNumerical` (603) on `prog`**: `adaNumerical_impl_of` with the tight value premise
`TightM A M`, the table premises and the preparation spec (family 8) discharged (O2b family 7). -/
def O2mNumTightSpec (prog : List Expr) : Prop :=
  ∀ (M : ℕ) (A : AdaParams) (st : AdaState) (vals : List (List ℕ)),
    NormQSpec prog M → A.blockSizes.length = A.p + 1 → A.Tmax.length = A.p →
    (∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) → AdaOK A st → ValsOKA A vals → TightM A M →
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals)

end F2e2e.BSpace
