import F2e2e.BSpace.O2GstLiftCalc

/-!
# B_space, route O2b (iii): lifting loop-only routines into the per-call judgment `EvalsValF`

Owner: W5 (c1b4f720), for the O2b tech lead 17fc0802 and O2B-GST (8cf19cc0). Prefix `o2g`.

Many light routines of the B glue and of the library (`bsBlocks` 900, `normQ` 766, `pow2` 100) call no
routine at all: their bodies contain only primitive operations, oracle calls and loops whose bodies are
call-free. For them the per-call budget is explicit and frame-local, without any global rank or weight
certificate:

* `o2gCFL prog D e`: `e` calls no routine except the oracle, and every loop `loop i a` of `e` has a
  call-free body (O2B-GST's `CallFree`) with `exprDepth body + 3 ≤ D`;
  `o2gCFLB L e` is a Boolean checker (no calls except the oracle, loops only at indices in `L`) and
  `o2gCFL_of_B` turns it into `o2gCFL` from the bodies at the indices of `L`.
* `EvalsValO.o2g_toF_loopCF`: the iterations of a loop with a call-free body, at the uniform bound `M`,
  are `EvalsValF` iterations at `(M, τ)` for every `τ`.
* `EvalsValO.o2g_toF_cfl`: an `EvalsValO` evaluation of such an `e` at the uniform bound `M`, in an
  environment of values `≤ M`, is an `EvalsValF` evaluation at the frame bound `M` with the callee budget
  `D · M` (every loop frame runs at `M` and costs `(exprDepth body + 3) · M ≤ D · M`).
* `EvalsVal.o2g_toF_cfl`: the same from the oracle-free `EvalsVal` (no body at the oracle index).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Loop-only expressions -/

/-- `e` calls no routine except the oracle, and each of its loops has a call-free body with
`exprDepth body + 3 ≤ D`. -/
def o2gCFL (prog : List Expr) (D : ℕ) : Expr → Prop
  | Expr.var _ => True
  | Expr.lit _ => True
  | Expr.nil => True
  | Expr.coin => True
  | Expr.bin _ a b => o2gCFL prog D a ∧ o2gCFL prog D b
  | Expr.un _ a => o2gCFL prog D a
  | Expr.ite c t f => o2gCFL prog D c ∧ o2gCFL prog D t ∧ o2gCFL prog D f
  | Expr.letE a b => o2gCFL prog D a ∧ o2gCFL prog D b
  | Expr.call j a => j = bsOracleIdx ∧ o2gCFL prog D a
  | Expr.loop j a =>
      (∀ body, prog[j]? = some body → CallFree body ∧ exprDepth body + 3 ≤ D) ∧ o2gCFL prog D a

/-- Boolean checker: no calls except the oracle, loops only at the indices in `L`. -/
def o2gCFLB (L : List ℕ) : Expr → Bool
  | Expr.var _ => true
  | Expr.lit _ => true
  | Expr.nil => true
  | Expr.coin => true
  | Expr.bin _ a b => o2gCFLB L a && o2gCFLB L b
  | Expr.un _ a => o2gCFLB L a
  | Expr.ite c t f => o2gCFLB L c && (o2gCFLB L t && o2gCFLB L f)
  | Expr.letE a b => o2gCFLB L a && o2gCFLB L b
  | Expr.call j a => decide (j = bsOracleIdx) && o2gCFLB L a
  | Expr.loop j a => decide (j ∈ L) && o2gCFLB L a

/-- The Boolean checker is sound, given call-free bodies of depth `+ 3 ≤ D` at the indices of `L`. -/
theorem o2gCFL_of_B {prog : List Expr} {D : ℕ} {L : List ℕ}
    (hL : ∀ j ∈ L, ∀ body, prog[j]? = some body → CallFree body ∧ exprDepth body + 3 ≤ D) :
    ∀ e : Expr, o2gCFLB L e = true → o2gCFL prog D e
  | Expr.var _, _ => trivial
  | Expr.lit _, _ => trivial
  | Expr.nil, _ => trivial
  | Expr.coin, _ => trivial
  | Expr.bin _ a b, h => by
    simp only [o2gCFLB, Bool.and_eq_true] at h
    exact ⟨o2gCFL_of_B hL a h.1, o2gCFL_of_B hL b h.2⟩
  | Expr.un _ a, h => by
    simp only [o2gCFLB] at h
    exact o2gCFL_of_B hL a h
  | Expr.ite c t f, h => by
    simp only [o2gCFLB, Bool.and_eq_true] at h
    exact ⟨o2gCFL_of_B hL c h.1, o2gCFL_of_B hL t h.2.1, o2gCFL_of_B hL f h.2.2⟩
  | Expr.letE a b, h => by
    simp only [o2gCFLB, Bool.and_eq_true] at h
    exact ⟨o2gCFL_of_B hL a h.1, o2gCFL_of_B hL b h.2⟩
  | Expr.call j a, h => by
    simp only [o2gCFLB, Bool.and_eq_true, decide_eq_true_eq] at h
    exact ⟨h.1, o2gCFL_of_B hL a h.2⟩
  | Expr.loop j a, h => by
    simp only [o2gCFLB, Bool.and_eq_true, decide_eq_true_eq] at h
    exact ⟨hL j h.1, o2gCFL_of_B hL a h.2⟩

/-! ## The lifting -/

/-- The statement proved by induction for the loop-only lifting. -/
def O2gCFLProp (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (D M : ℕ) (env : List Val)
    (bits : List Bool) : Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ x ∈ env, valSize x ≤ M) → o2gCFL prog D e → ∀ τ, D * M ≤ τ →
      EvalsValF orc prog M τ env bits (.inl e) v
  | .inr (i, acc), w => ∀ body, prog[i]? = some body → CallFree body → ∀ τ,
      EvalsValF orc prog M τ env bits (.inr (i, acc)) w

theorem o2g_cfl_aux {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {D M : ℕ} {env : List Val}
    {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsValO orc prog M env bits t v) :
    O2gCFLProp orc prog D M env bits t v := by
  induction h with
  | var hv => exact fun _ _ _ _ => EvalsValF.var hv
  | lit hM => exact fun _ _ _ _ => EvalsValF.lit hM
  | nil hM => exact fun _ _ _ _ => EvalsValF.nil hM
  | coin b hM => exact fun _ _ _ _ => EvalsValF.coin b hM
  | bin _ _ hop hM iha ihb =>
    intro henv hc τ hτ
    exact EvalsValF.bin (iha henv hc.1 τ hτ) (ihb henv hc.2 τ hτ) hop hM
  | un _ hop hM iha =>
    intro henv hc τ hτ
    exact EvalsValF.un (iha henv hc τ hτ) hop hM
  | @ite env c t f bc bv z v _ _ ihc ihv =>
    intro henv hcl τ hτ
    obtain ⟨hcc, hct, hcf⟩ := hcl
    have hbr : o2gCFL prog D (if z ≠ 0 then t else f) := by
      split_ifs
      · exact hct
      · exact hcf
    exact EvalsValF.ite (ihc henv hcc τ hτ) (ihv henv hbr τ hτ)
  | @letE env a b ba bb va vb ha _ iha ihb =>
    intro henv hc τ hτ
    have hva : valSize va ≤ M := EvalsValO.val_le_env ha henv
    have henv' : ∀ x ∈ va :: env, valSize x ≤ M := by
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hx
      · exact hva
      · exact henv x hx
    exact EvalsValF.letE (iha henv hc.1 τ hτ) (ihb henv' hc.2 τ hτ)
  | call hi _ _ _ _ _ => exact fun _ hc _ _ => absurd hc.1 hi
  | oracle _ hM iha =>
    intro henv hc τ hτ
    exact EvalsValF.oracle (iha henv hc.2 τ hτ) hM
  | @loop env i a ba bl va w' ha hl iha ihl =>
    intro henv hc τ hτ
    have hva : valSize va ≤ M := EvalsValO.val_le_env ha henv
    have hw' : valSize w' ≤ M := EvalsValO.loop_val_le hl hva
    obtain ⟨body, hbody⟩ := EvalsValO.loop_body_exists hl
    obtain ⟨hcf, hD⟩ := hc.1 body hbody
    refine EvalsValF.loop (τ' := 0) (iha henv hc.2 τ hτ) (ihl body hbody hcf 0) hva hw' ?_
    intro body' hbody'
    rw [hbody] at hbody'
    cases hbody'
    calc (exprDepth body + 3) * M + 0 = (exprDepth body + 3) * M := Nat.add_zero _
      _ ≤ D * M := Nat.mul_le_mul_right _ hD
      _ ≤ τ := hτ
  | @stop i v body bb v' hbody hb _ =>
    intro body' hbody' hcf τ
    rw [hbody] at hbody'
    cases hbody'
    exact EvalsValF.stop hbody (EvalsValO.toF_callFree hb hcf τ)
  | @cont i v body bb bw flag v' w' hbody hb hflag _ _ ihr =>
    intro body' hbody' hcf τ
    rw [hbody] at hbody'
    cases hbody'
    exact EvalsValF.cont hbody (EvalsValO.toF_callFree hb hcf τ) hflag (ihr body hbody hcf τ)

/-- **Loops with a call-free body**: their iterations at the uniform bound `M` are `EvalsValF` iterations
at `(M, τ)` for every budget `τ`. -/
theorem EvalsValO.o2g_toF_loopCF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {i : ℕ}
    {acc w : Val} {bits : List Bool} (h : EvalsValO orc prog M [] bits (.inr (i, acc)) w) {body : Expr}
    (hbody : prog[i]? = some body) (hcf : CallFree body) (τ : ℕ) :
    EvalsValF orc prog M τ [] bits (.inr (i, acc)) w :=
  o2g_cfl_aux (D := 0) h body hbody hcf τ

/-- **Loop-only lifting**: an `EvalsValO` evaluation at the uniform bound `M` of an expression that calls
nothing but the oracle and whose loops have call-free bodies of depth `+ 3 ≤ D` is an `EvalsValF`
evaluation at the frame bound `M` with every budget `τ ≥ D · M`. -/
theorem EvalsValO.o2g_toF_cfl {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {D M : ℕ} {env : List Val}
    {bits : List Bool} {e : Expr} {v : Val} (h : EvalsValO orc prog M env bits (.inl e) v)
    (henv : ∀ x ∈ env, valSize x ≤ M) (hc : o2gCFL prog D e) {τ : ℕ} (hτ : D * M ≤ τ) :
    EvalsValF orc prog M τ env bits (.inl e) v :=
  o2g_cfl_aux h henv hc τ hτ

/-- **Loop-only lifting** of an oracle-free `EvalsVal` evaluation (no body at the oracle index). -/
theorem EvalsVal.o2g_toF_cfl {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} (hO : prog[bsOracleIdx]? = none)
    {D M : ℕ} {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ x ∈ env, valSize x ≤ M) (hc : o2gCFL prog D e)
    {τ : ℕ} (hτ : D * M ≤ τ) : EvalsValF orc prog M τ env bits (.inl e) v :=
  (EvalsValO.of_evalsVal (orc := orc) hO h).o2g_toF_cfl henv hc hτ

end F2e2e.BSpace
