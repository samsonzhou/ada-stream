import F2e2e.BSpace.MachineDefsO
import F2e2e.Cost.BitProgBridge
import F2e2e.Cost.ValRules

/-!
# B_space, layer M1: the oracle value judgment `EvalsValO`

Owner: C-SPACE (B_space layer M; area lead W4). The programs of `Theorem_B_space` run with an evaluation
oracle `orc`: `Expr.call bsOracleIdx a` evaluates `a` to `[sel, r, q]` and answers `Val.int (orc sel r q)`
(`bsOracleIdx = 1000`, Spec v3 §7's `oracleIdx`; see `F2e2e/BSpace/MachineDefsO.lean`).

* `EvalsValO orc prog M env bits t v`: C-TOP's value judgment `EvalsVal` (`F2e2e/Cost/Generic.lean`)
  verbatim, with the rule `call` restricted to `i ≠ bsOracleIdx`, plus the rule `oracle`:
  `a ↦ [sel, r, q]` (consuming `ba`) gives `call bsOracleIdx a ↦ Val.int (orc sel r q)` (consuming `ba`)
  when the answer has size `≤ M`.
* `EvalsValO.of_evalsVal`: on a program without a body at `bsOracleIdx` (every `mkProg` program with keys
  `< 1000`), every `EvalsVal` evaluation is an `EvalsValO` evaluation, for every oracle; so all specs of the
  (C) and ADA routines lift (`Implements.toO`).
* `ImplementsO`: C-TOP's `Implements` for `EvalsValO`, with its calculus (`mono_M`, `coin`, `of_det`,
  `letE`, `congr`, the call rules `implementsO_call`, `implementsO_call_det`, `evalsValO_call_det`).
* Derived rules: `mono_M`, `cast_bits`, `pair`, `head`, `tail`, `cons`, `triple`-free list building via
  `cons`, the deterministic oracle rule `oracle_det`, and the loop rule `loop_of_measure`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

/-- **The oracle value judgment** (C-TOP's `EvalsVal` with the evaluation oracle `orc`). Targets: `.inl e`
(an expression, in the environment `env`) or `.inr (i, acc)` (the iterations of `loop i` from the
accumulator `acc`, environment `[]`); `bits` are exactly the fresh bits consumed; every value produced by a
literal, `nil`, `coin`, a primitive operation or the oracle has size `≤ M`. -/
inductive EvalsValO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (M : ℕ) :
    List Val → List Bool → Expr ⊕ (ℕ × Val) → Val → Prop
  | var {env : List Val} {i : ℕ} {v : Val} (h : env[i]? = some v) :
      EvalsValO orc prog M env [] (.inl (Expr.var i)) v
  | lit {env : List Val} {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
      EvalsValO orc prog M env [] (.inl (Expr.lit z)) (Val.int z)
  | nil {env : List Val} (hM : valSize (Val.list []) ≤ M) :
      EvalsValO orc prog M env [] (.inl Expr.nil) (Val.list [])
  | coin {env : List Val} (b : Bool) (hM : valSize (encB b) ≤ M) :
      EvalsValO orc prog M env [b] (.inl Expr.coin) (encB b)
  | bin {env : List Val} {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {c : ℕ}
      (ha : EvalsValO orc prog M env ba (.inl a) va) (hb : EvalsValO orc prog M env bb (.inl b) vb)
      (hop : evalBin op va vb = some (v, c)) (hM : valSize v ≤ M) :
      EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin op a b)) v
  | un {env : List Val} {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {c : ℕ}
      (ha : EvalsValO orc prog M env ba (.inl a) va) (hop : evalUn op va = some (v, c))
      (hM : valSize v ≤ M) :
      EvalsValO orc prog M env ba (.inl (Expr.un op a)) v
  | ite {env : List Val} {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
      (hc : EvalsValO orc prog M env bc (.inl c) (Val.int z))
      (hv : EvalsValO orc prog M env bv (.inl (if z ≠ 0 then t else f)) v) :
      EvalsValO orc prog M env (bc ++ bv) (.inl (Expr.ite c t f)) v
  | letE {env : List Val} {a b : Expr} {ba bb : List Bool} {va vb : Val}
      (ha : EvalsValO orc prog M env ba (.inl a) va)
      (hb : EvalsValO orc prog M (va :: env) bb (.inl b) vb) :
      EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.letE a b)) vb
  | call {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
      (hi : i ≠ bsOracleIdx) (ha : EvalsValO orc prog M env ba (.inl a) va)
      (hbody : prog[i]? = some body) (hb : EvalsValO orc prog M [va] bb (.inl body) vb) :
      EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.call i a)) vb
  | oracle {env : List Val} {a : Expr} {ba : List Bool} {sel r q : ℤ}
      (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [Val.int sel, Val.int r, Val.int q]))
      (hM : valSize (Val.int (orc sel r q)) ≤ M) :
      EvalsValO orc prog M env ba (.inl (Expr.call bsOracleIdx a)) (Val.int (orc sel r q))
  | loop {env : List Val} {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val}
      (ha : EvalsValO orc prog M env ba (.inl a) va)
      (hl : EvalsValO orc prog M [] bl (.inr (i, va)) w) :
      EvalsValO orc prog M env (ba ++ bl) (.inl (Expr.loop i a)) w
  | stop {i : ℕ} {v : Val} {body : Expr} {bb : List Bool} {v' : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsValO orc prog M [v] bb (.inl body) (Val.list [Val.int 0, v'])) :
      EvalsValO orc prog M [] bb (.inr (i, v)) v'
  | cont {i : ℕ} {v : Val} {body : Expr} {bb bw : List Bool} {flag : ℤ} {v' w : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsValO orc prog M [v] bb (.inl body) (Val.list [Val.int flag, v']))
      (hflag : flag ≠ 0) (hrest : EvalsValO orc prog M [] bw (.inr (i, v')) w) :
      EvalsValO orc prog M [] (bb ++ bw) (.inr (i, v)) w

namespace EvalsValO

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

/-- Monotonicity in the value bound. -/
theorem mono_M {M' : ℕ} {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValO orc prog M env bits t v) (hM : M ≤ M') : EvalsValO orc prog M' env bits t v := by
  induction h with
  | var hv => exact EvalsValO.var hv
  | lit h => exact EvalsValO.lit (h.trans hM)
  | nil h => exact EvalsValO.nil (h.trans hM)
  | coin b h => exact EvalsValO.coin b (h.trans hM)
  | bin _ _ hop h iha ihb => exact EvalsValO.bin iha ihb hop (h.trans hM)
  | un _ hop h iha => exact EvalsValO.un iha hop (h.trans hM)
  | ite _ _ ihc ihv => exact EvalsValO.ite ihc ihv
  | letE _ _ iha ihb => exact EvalsValO.letE iha ihb
  | call hi _ hbody _ iha ihb => exact EvalsValO.call hi iha hbody ihb
  | oracle _ h iha => exact EvalsValO.oracle iha (h.trans hM)
  | loop _ _ iha ihl => exact EvalsValO.loop iha ihl
  | stop hbody _ ihb => exact EvalsValO.stop hbody ihb
  | cont hbody _ hflag _ ihb ihr => exact EvalsValO.cont hbody ihb hflag ihr

theorem cast_bits {env : List Val} {bits bits' : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValO orc prog M env bits t v) (hb : bits = bits') :
    EvalsValO orc prog M env bits' t v :=
  hb ▸ h

/-- **Lifting.** On a program without a body at the oracle index, every `EvalsVal` evaluation is an
`EvalsValO` evaluation (for every oracle). -/
theorem of_evalsVal (hO : prog[bsOracleIdx]? = none) {env : List Val} {bits : List Bool}
    {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsVal prog M env bits t v) :
    EvalsValO orc prog M env bits t v := by
  induction h with
  | var hv => exact EvalsValO.var hv
  | lit h => exact EvalsValO.lit h
  | nil h => exact EvalsValO.nil h
  | coin b h => exact EvalsValO.coin b h
  | bin _ _ hop h iha ihb => exact EvalsValO.bin iha ihb hop h
  | un _ hop h iha => exact EvalsValO.un iha hop h
  | ite _ _ ihc ihv => exact EvalsValO.ite ihc ihv
  | letE _ _ iha ihb => exact EvalsValO.letE iha ihb
  | @call env i a body ba bb va vb _ hbody _ iha ihb =>
    have hi : i ≠ bsOracleIdx := by
      rintro rfl
      rw [hO] at hbody
      cases hbody
    exact EvalsValO.call hi iha hbody ihb
  | loop _ _ iha ihl => exact EvalsValO.loop iha ihl
  | stop hbody _ ihb => exact EvalsValO.stop hbody ihb
  | cont hbody _ hflag _ ihb ihr => exact EvalsValO.cont hbody ihb hflag ihr

/-- The oracle with a deterministic argument. -/
theorem oracle_det {env : List Val} {a : Expr} {sel r q : ℤ}
    (ha : EvalsValO orc prog M env [] (.inl a) (Val.list [Val.int sel, Val.int r, Val.int q]))
    (hM : valSize (Val.int (orc sel r q)) ≤ M) :
    EvalsValO orc prog M env [] (.inl (Expr.call bsOracleIdx a)) (Val.int (orc sel r q)) :=
  EvalsValO.oracle ha hM

theorem head {env : List Val} {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list (x :: l))) (hM : valSize x ≤ M) :
    EvalsValO orc prog M env ba (.inl (Expr.un UnOp.head a)) x :=
  EvalsValO.un (c := 1) ha rfl hM

theorem tail {env : List Val} {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list l) ≤ M) :
    EvalsValO orc prog M env ba (.inl (Expr.un UnOp.tail a)) (Val.list l) :=
  EvalsValO.un (c := 1) ha rfl hM

theorem cons {env : List Val} {a b : Expr} {ba bb : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) x) (hb : EvalsValO orc prog M env bb (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (Expr.bin BinOp.cons a b)) (Val.list (x :: l)) :=
  EvalsValO.bin (c := 1) ha hb (by cases x <;> rfl) hM

/-- `ePair a b` builds `[x, y]`. -/
theorem pair {env : List Val} {a b : Expr} {ba bb : List Bool} {x y : Val}
    (ha : EvalsValO orc prog M env ba (.inl a) x) (hb : EvalsValO orc prog M env bb (.inl b) y)
    (hM : valSize (Val.list [x, y]) ≤ M) :
    EvalsValO orc prog M env (ba ++ bb) (.inl (ePair a b)) (Val.list [x, y]) := by
  have h1 : valSize (Val.list [y]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h0 : valSize (Val.list []) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hin := EvalsValO.bin (op := BinOp.cons) (c := 1) hb (EvalsValO.nil h0)
    (by cases y <;> rfl) h1
  rw [List.append_nil] at hin
  exact EvalsValO.bin (c := 1) ha hin (by cases x <;> rfl) hM

/-- **Loop rule (measure, with fresh bits).** Every iteration from a state `s` satisfying `Inv` either
stops with an output satisfying `Post`, consuming `bitsOf s`, or consumes a prefix `bs` with
`bitsOf s = bs ++ bitsOf s'` and continues to a state `s'` satisfying `Inv` with a smaller measure. -/
theorem loop_of_measure {σ : Type*} {i : ℕ} {body : Expr} (hbody : prog[i]? = some body)
    (enc : σ → Val) (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsValO orc prog M [enc s] (bitsOf s) (.inl body) (Val.list [Val.int 0, out]) ∧
          Post out) ∨
      (∃ flag s' bs, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsValO orc prog M [enc s] bs (.inl body) (Val.list [Val.int flag, enc s']) ∧ Inv s' ∧
          μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ EvalsValO orc prog M [] (bitsOf s) (.inr (i, enc s)) out := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', bs, hflag, hbits, hb, hs', hlt⟩
    · exact ⟨out, hpost, EvalsValO.stop hbody hb⟩
    · obtain ⟨out, hpost, hrest⟩ := ih (μ s') (by omega) s' rfl hs'
      rw [hbits]
      exact ⟨out, hpost, EvalsValO.cont hbody hb hflag hrest⟩

end EvalsValO

/-! ## `ImplementsO` -/

/-- C-TOP's `Implements` with the oracle: whenever `p` reads exactly `bits` and returns `a`, the evaluation
of `e` with the oracle `orc` consumes exactly `bits` and returns `enc a` (all produced values `≤ M`). -/
def ImplementsO {α : Type} (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (M : ℕ) (env : List Val)
    (e : Expr) (enc : α → Val) (p : BitProg α) : Prop :=
  ∀ bits a, p.run bits = some (a, []) → EvalsValO orc prog M env bits (.inl e) (enc a)

/-- **Lifting** of `Implements` (no body at the oracle index). -/
theorem Implements.toO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val} {α : Type}
    {e : Expr} {enc : α → Val} {p : BitProg α} (hO : prog[bsOracleIdx]? = none)
    (h : Implements prog M env e enc p) : ImplementsO orc prog M env e enc p :=
  fun bits a hp => EvalsValO.of_evalsVal hO (h bits a hp)

namespace ImplementsO

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val} {α β : Type}

theorem mono_M {M' : ℕ} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsO orc prog M env e enc p) (hM : M ≤ M') : ImplementsO orc prog M' env e enc p :=
  fun bits a hp => (h bits a hp).mono_M hM

/-- `Expr.coin` implements `readBit` with the encoding `encB`. -/
theorem coin (hM : 2 ≤ M) : ImplementsO orc prog M env Expr.coin encB BitProg.readBit := by
  intro bits b hp
  rw [bitProg_run_readBit_exact.mp hp]
  exact EvalsValO.coin b ((valSize_encB_le b).trans hM)

/-- A deterministic evaluation implements `pure a`. -/
theorem of_det {e : Expr} {enc : α → Val} {a : α}
    (h : EvalsValO orc prog M env [] (.inl e) (enc a)) :
    ImplementsO orc prog M env e enc (BitProg.pure a) := by
  intro bits a' hp
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp hp
  exact h

/-- **Sequential composition.** -/
theorem letE {ea eb : Expr} {encA : α → Val} {encC : β → Val} {p : BitProg α} {f : α → BitProg β}
    (hp : ImplementsO orc prog M env ea encA p)
    (hf : ∀ a, ImplementsO orc prog M (encA a :: env) eb encC (f a)) :
    ImplementsO orc prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValO.letE (hp b₁ a h1) (hf a b₂ c h2)

/-- Rewriting the implemented program or the encoding. -/
theorem congr {e : Expr} {enc enc' : α → Val} {p p' : BitProg α}
    (h : ImplementsO orc prog M env e enc p) (hp : p = p') (henc : ∀ a, enc a = enc' a) :
    ImplementsO orc prog M env e enc' p' := by
  subst hp
  intro bits a hr
  rw [← henc a]
  exact h bits a hr

end ImplementsO

/-- **Call rule** (callee form ⇒ caller form; not the oracle index). -/
theorem implementsO_call {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {α β : Type} {argE : Expr} {encA : α → Val} {encB : β → Val} {pA : BitProg α} {f : α → BitProg β}
    {i : ℕ} {body : Expr} (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : ImplementsO orc prog M env argE encA pA)
    (hf : ∀ a, ImplementsO orc prog M [encA a] body encB (f a)) :
    ImplementsO orc prog M env (Expr.call i argE) encB (pA.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValO.call hi (hA b₁ a h1) hbody (hf a b₂ c h2)

/-- **Call rule with a deterministic argument** (not the oracle index). -/
theorem implementsO_call_det {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {β : Type} {argE : Expr} {x : Val} {encB : β → Val} {p : BitProg β} {i : ℕ} {body : Expr}
    (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : EvalsValO orc prog M env [] (.inl argE) x)
    (hf : ImplementsO orc prog M [x] body encB p) :
    ImplementsO orc prog M env (Expr.call i argE) encB p := by
  intro bits c h
  have := EvalsValO.call hi hA hbody (hf bits c h)
  simpa using this

/-- **Call rule for a deterministic routine** (not the oracle index). -/
theorem evalsValO_call_det {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {argE : Expr} {x v : Val} {i : ℕ} {body : Expr} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : EvalsValO orc prog M env [] (.inl argE) x)
    (hf : EvalsValO orc prog M [x] [] (.inl body) v) :
    EvalsValO orc prog M env [] (.inl (Expr.call i argE)) v := by
  simpa using EvalsValO.call hi hA hbody hf

end F2e2e.BSpace
