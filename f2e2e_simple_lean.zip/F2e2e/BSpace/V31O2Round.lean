import F2e2e.BSpace.O2GlueMainAsm
import F2e2e.BSpace.V31DslReq

/-!
# B_space v3.1 F-B1 on the O2b route (W4, speculative): the request frame for every agreeing oracle

Speculative, ahead of the v3.1 statement (F-B1: the evaluation oracle need only agree with Spec v3's
`reqOracle code req` where the round program reads it; its answers elsewhere are adversarial). This is the O2b
analog of W3's `bsRound_implG` (`V31DslReq.lean`), for C-BANK's per-call request frame `o2m_implR_of`
(`O2GlueMainAsm.lean`), which is stated for `orc = reqOracle code req` only.

The hypotheses on the oracle are the pointwise ones of `bsRound_implG` (every reasonable wording of F-B1 implies
them): `orc` answers like `reqOracle code req` at selector `0` on the codes of the sample and at selectors `1, 2` on
`r = 0`, all at the precision `q_A + 1`.

* `v31o2_reqData`: C-BANK/O2P-2's request data `o2m_reqData` for such an oracle (W3's `bsR_mem_asmBlocks`,
  `bsR_evalsOf_congr`);
* `v31o2_implR_agree`: `o2m_implR_of` for such an oracle (same frame bound `o2m_mR`, budget `o2m_τR`, input,
  output encoding and core round on the quantized request). The proof is `o2m_implR_of`'s, with the generic-oracle
  lemmas it already uses (`o2m_roundF`, the weighted liftings, `o2m_roundB_le_topM_gen`, `o2m_roundT_le_topT_gen`)
  instantiated at `orc`; the two tight entry specs are oracle-free.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.C.Alg F2e2e.C.Impl

/-- **The request data for an agreeing oracle**: `o2m_reqData` for every oracle `orc` that answers like
`reqOracle code req` at selector `0` on the codes of the sample and at selectors `1, 2` on `r = 0`, at the
precision `q_A + 1`. -/
theorem v31o2_reqData (A : AdaParams) {U : Type} {code : U → ℕ} (hinj : Function.Injective code) {N : ℕ}
    (s : Fin N → U) (hN : N = A.N) {req : VReq U} (hreq : req.Valid) {orc : ℤ → ℤ → ℤ → ℤ}
    (hagree0 : ∀ ℓ : Fin N, orc 0 (code (s ℓ) : ℤ) ((A.qA : ℤ) + 1) =
      reqOracle code req 0 (code (s ℓ) : ℤ) ((A.qA : ℤ) + 1))
    (hagree1 : orc 1 0 ((A.qA : ℤ) + 1) = reqOracle code req 1 0 ((A.qA : ℤ) + 1))
    (hagree2 : orc 2 0 ((A.qA : ℤ) + 1) = reqOracle code req 2 0 ((A.qA : ℤ) + 1)) :
    (∀ blk ∈ asmBlocks A code s, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ∧
        orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ≤ 2 ^ (A.qA + 1)) ∧
      (|orc 1 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2) ∧ |orc 2 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2)) ∧
      evalsOf orc A.qA (asmBlocks A code s) = coreVals A (V2.castSample hN s) (quantReq A req) ∧
      bsN_end A.qA (orc 1 0 ((A.qA : ℤ) + 1)) = (quantReq A req).l ∧
      bsN_end A.qA (orc 2 0 ((A.qA : ℤ) + 1)) = (quantReq A req).u := by
  have hag : ∀ blk ∈ asmBlocks A code s, ∀ r ∈ blk,
      orc 0 (r : ℤ) ((A.qA : ℤ) + 1) = reqOracle code req 0 (r : ℤ) ((A.qA : ℤ) + 1) := by
    intro blk hblk r hr
    obtain ⟨ℓ, rfl⟩ := bsR_mem_asmBlocks A code s blk hblk r hr
    exact hagree0 ℓ
  obtain ⟨h0, h12, hve, hel, heu⟩ := o2m_reqData A hinj s hN hreq
  refine ⟨fun blk hblk r hr => ?_, ?_, ?_, ?_, ?_⟩
  · rw [hag blk hblk r hr]
    exact h0 blk hblk r hr
  · rw [hagree1, hagree2]
    exact h12
  · rw [bsR_evalsOf_congr hag]
    exact hve
  · rw [hagree1]
    exact hel
  · rw [hagree2]
    exact heu

set_option maxHeartbeats 2000000 in
/-- **The request frame of `Theorem_B_space_with 30` for every agreeing oracle** (Spec v3.1 F-B1): C-BANK's
`o2m_implR_of` (W4's `O2Inputs.implR`, `mR := o2m_mR`, `τR := o2m_τR`) for every oracle `orc` that answers like
`reqOracle code req` at selector `0` on the codes of the sample and at selectors `1, 2` on `r = 0`, at the
precision `q_A + 1`; given the tight specs of the two ADA entries on the round program. -/
theorem v31o2_implR_agree (hIvT : O2mIvTightSpec bsRoundProg) (hNumT : O2mNumTightSpec bsRoundProg)
    (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ) (hinj : Function.Injective code)
    (hcode : ∀ x, code x < 2 ^ bU) (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U)
    (hreq : req.Valid) {orc : ℤ → ℤ → ℤ → ℤ}
    (hagree0 : ∀ ℓ : Fin (alg2Params M J R aReq ξReq).N,
      orc 0 (code (s ℓ) : ℤ) (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
        reqOracle code req 0 (code (s ℓ) : ℤ) (((asmParams M J R aReq ξReq).qA : ℤ) + 1))
    (hagree1 : orc 1 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
      reqOracle code req 1 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1))
    (hagree2 : orc 2 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1) =
      reqOracle code req 2 0 (((asmParams M J R aReq ξReq).qA : ℤ) + 1))
    (st : AdaState) (hok : C.Impl.AdaOK (asmParams M J R aReq ξReq) st) :
    ImplementsF orc bsRoundProg (o2m_mR M J R aReq ξReq bU) (o2m_τR M J R aReq ξReq bU)
      [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams M J R aReq ξReq) st
        (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
          (quantReq (asmParams M J R aReq ξReq) req))
        (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
        req.2.1) := by
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  have hN := refine_N M J R ha0 ha1 hξ0 hξ1
  obtain ⟨horc0, horc12, hve, hel, heu⟩ :=
    v31o2_reqData (asmParams M J R aReq ξReq) hinj s hN hreq hagree0 hagree1 hagree2
  have hbs := bsP_blockSizes_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hT := bsP_Tmax_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hpos := bsP_blockSizes_pos (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hblk := bsR_asmBlocks_length (asmParams M J R aReq ξReq) code s hN
  have hv : ValsOKA (asmParams M J R aReq ξReq) (evalsOf orc
      (asmParams M J R aReq ξReq).qA (asmBlocks (asmParams M J R aReq ξReq) code s)) :=
    ⟨(evalsOf_map_length _ _ _).trans hblk, evalsOf_le horc0⟩
  have hl := bsN_end_bitLen' _ _ horc12.1
  have hu := bsN_end_bitLen' _ _ horc12.2
  /- ### The program and its weights -/
  have hO := bsRoundProg_oracle
  have hL := bsLib_round
  have hW := bsWeightOK_round
  obtain ⟨w600, -, w602, w603, -, -, w920, -, -⟩ := bsW_vals
  have h600 : bsRoundProg[Idx.adaPub]? = some body_adaPub :=
    hL.pub (Idx.adaPub, body_adaPub) (List.mem_append_right _ (by simp [adaPubTable]))
  have h602 : bsRoundProg[Idx.adaInterval]? = some body_adaInterval :=
    hL.w4Lib.entryTbl (Idx.adaInterval, body_adaInterval) (by simp [adaEntryTable])
  have h603 : bsRoundProg[Idx.adaNumerical]? = some body_adaNumerical :=
    hL.w4Lib.numTbl (Idx.adaNumerical, body_adaNumerical) (by simp [adaNumTable])
  have h920 : bsRoundProg[bsEndsKey]? = some body_bsEnds :=
    hL.ends (bsEndsKey, body_bsEnds) List.mem_cons_self
  have hcP : CalleesLe bsWRound 81 body_adaPub := by
    have h := (hW _ _ h600).2
    rwa [show bsWRound Idx.adaPub = 135 from w600, o2m_depth_adaPub] at h
  have hcD : CalleesLe bsWRound 23 body_bsEnds := by
    have h := (hW _ _ h920).2
    rwa [show bsWRound bsEndsKey = 38 from w920, o2m_depth_bsEnds] at h
  have hcI : CalleesLe bsWRound 210 body_adaInterval := by
    have h := (hW _ _ h602).2
    rwa [show bsWRound Idx.adaInterval = 231 from w602, o2m_depth_adaInterval] at h
  have hcN : CalleesLe bsWRound 206 body_adaNumerical := by
    have h := (hW _ _ h603).2
    rwa [show bsWRound Idx.adaNumerical = 240 from w603, o2m_depth_adaNumerical] at h
  /- ### The callees in their own frames -/
  have hPub := o2m_pubAt_of_lift (orc := orc) (Mc := M) (J := J) (R := R) hO hW hL.pub
    (hL.normQ _) h4 h2 le_rfl hcP
  have hEv := o2m_evalsAt_of (orc := orc) hL.evals horc0
  have hEn := o2m_endsAt_of_lift hO hW hL.ends (hL.normQ _) horc12 le_rfl hcD
  have hMq : 2 ^ 28 * ((asmParams M J R aReq ξReq).qA + 4) ≤ o2mMI (asmParams M J R aReq ξReq) := by
    unfold o2mMI
    omega
  have hIv := o2m_ivAt_of_lift (orc := orc) hO hW h602
    (hIvT _ _ st _ _ _ _ (hL.normQ _) hbs hT hpos hok hv hl hu (o2mMI_tight _) hMq)
    (o2m_ivIn_le_of_tight hbs hT hok hv hl hu (o2mMI_tight _) hMq) hcI
  have hNum := o2m_numAt_of_lift (orc := orc) hO hW h603
    (hNumT _ _ st _ (hL.normQ _) hbs hT hpos hok hv (o2MA_tightM _))
    (o2m_numIn_le_of_tight hbs hT hok hv (o2MA_tightM _)) hcN
  /- ### The frame bound and the budget (the generic instances at `orc`) -/
  have hm : o2mRoundB orc M J R (dyadicExp aReq) (dyadicExp ξReq)
      (asmBlocks (asmParams M J R aReq ξReq) code s) st req.2.1 ≤ o2m_mR M J R aReq ξReq bU :=
    o2m_roundB_le_topM_gen (orc := orc) (bsR_codes_length (asmParams M J R aReq ξReq) code s hN)
      (o2m_codes_lt hcode s) horc0 hok req.2.1
  have hτ : o2mRoundT (o2mMP M J R (dyadicExp aReq) (dyadicExp ξReq))
      (81 * o2mMP M J R (dyadicExp aReq) (dyadicExp ξReq))
      (o2e_B orc (asmParams M J R aReq ξReq).qA (asmBlocks (asmParams M J R aReq ξReq) code s))
      (o2e_T orc (asmParams M J R aReq ξReq).qA (asmBlocks (asmParams M J R aReq ξReq) code s))
      (o2mMD (asmParams M J R aReq ξReq)) (23 * o2mMD (asmParams M J R aReq ξReq))
      (o2mMI (asmParams M J R aReq ξReq)) (210 * o2mMI (asmParams M J R aReq ξReq))
      (o2MA (asmParams M J R aReq ξReq)) (206 * o2MA (asmParams M J R aReq ξReq)) ≤
      o2m_τR M J R aReq ξReq bU :=
    o2m_roundT_le_topT_gen (orc := orc) (bsR_codes_length (asmParams M J R aReq ξReq) code s hN)
      (o2m_codes_lt hcode s) horc0
  have key := o2m_roundF hO hok req.2.1 horc12 hPub hEv hEn hIv hNum hm hτ
  rw [← hve, ← hel, ← heu]
  exact key

/-- `o2m_implR_of` is the case `orc = reqOracle code req` of `v31o2_implR_agree` (shape check). -/
example (hIvT : O2mIvTightSpec bsRoundProg) (hNumT : O2mNumTightSpec bsRoundProg)
    (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ) (hinj : Function.Injective code)
    (hcode : ∀ x, code x < 2 ^ bU) (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U)
    (hreq : req.Valid) (st : AdaState) (hok : C.Impl.AdaOK (asmParams M J R aReq ξReq) st) :
    ImplementsF (reqOracle code req) bsRoundProg (o2m_mR M J R aReq ξReq bU) (o2m_τR M J R aReq ξReq bU)
      [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams M J R aReq ξReq) st
        (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
          (quantReq (asmParams M J R aReq ξReq) req))
        (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
        req.2.1) :=
  v31o2_implR_agree hIvT hNumT M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s req hreq
    (fun _ => rfl) rfl rfl st hok

end F2e2e.BSpace
