import F2e2e.BSpace.DslMainReq

/-!
# B_space, Spec v3.1 F-B1 (W3, for C-TOP): the round spec for every oracle agreeing with the request where the
round program reads

Owner: W3 (4a7299ed), for C-TOP (95aff426; consumer `F2e2e/BSpace/V31Assemble.lean`). Speculative (lead, v3.1
F-B1): the evaluation oracle `orc` need only agree with Spec v3's `reqOracle code req` at the points the round
program reads, namely selector `0` at the codes of the sample and selectors `1, 2` at `r = 0`, all at the
precision `q_A + 1`. Its answers anywhere else (codes of records outside the sample, other selectors or
precisions) are arbitrary (adversarial).

* `bsR_mem_splitBlocks`: every entry of a block of `splitBlocks ns l` is an entry of `l`;
* `bsR_mem_asmBlocks`: every stored code is the code of a record of the sample;
* `bsR_evalsOf_congr`: `evalsOf` reads the oracle only at selector `0` and precision `q + 1`, on the stored
  entries;
* `bsRound_implG`: `bsRound_implR` (`F2e2e/BSpace/DslMainReq.lean`) for every such oracle (same input, output
  encoding and core round on the quantized request); `bsRound_implR` is the case `orc = reqOracle code req`
  (the `example` at the end).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The stored codes -/

/-- Every entry of a block of `splitBlocks ns l` is an entry of `l`. -/
theorem bsR_mem_splitBlocks : ∀ (ns l : List ℕ), ∀ blk ∈ splitBlocks ns l, ∀ x ∈ blk, x ∈ l
  | [], _, blk, hblk, _, _ => by simp [splitBlocks] at hblk
  | n :: ns, l, blk, hblk, x, hx => by
    simp only [splitBlocks, List.mem_cons] at hblk
    rcases hblk with rfl | hblk
    · exact List.mem_of_mem_take hx
    · exact List.mem_of_mem_drop (bsR_mem_splitBlocks ns (l.drop n) blk hblk x hx)

/-- Every stored code is the code of a record of the sample. -/
theorem bsR_mem_asmBlocks {U : Type} (A : AdaParams) (code : U → ℕ) {N : ℕ} (s : Fin N → U) :
    ∀ blk ∈ asmBlocks A code s, ∀ r ∈ blk, ∃ ℓ : Fin N, code (s ℓ) = r := by
  intro blk hblk r hr
  exact List.mem_ofFn.mp (bsR_mem_splitBlocks _ _ blk hblk r hr)

/-- `evalsOf` reads the oracle only at selector `0` and precision `q + 1`, on the stored entries. -/
theorem bsR_evalsOf_congr {orc orc' : ℤ → ℤ → ℤ → ℤ} {q : ℕ} {bs : List (List ℕ)}
    (h : ∀ blk ∈ bs, ∀ r ∈ blk, orc 0 (r : ℤ) ((q : ℤ) + 1) = orc' 0 (r : ℤ) ((q : ℤ) + 1)) :
    evalsOf orc q bs = evalsOf orc' q bs := by
  unfold evalsOf
  refine List.map_congr_left fun blk hblk => List.map_congr_left fun r hr => ?_
  exact congrArg (fun z : ℤ => ((z + 1) / 2).toNat) (h blk hblk r hr)

/-! ## The round -/

/-- **Spec of `body_bsRound` for every oracle agreeing with the request where the program reads** (Spec v3.1
F-B1): the hypotheses of `bsRound_implR`, and an oracle `orc` that answers like `reqOracle code req` at selector
`0` on the codes of the sample and at selectors `1, 2` on `r = 0`, at the precision `q_A + 1`. Then
`body_bsRound` implements the same core round on the quantized request,
`bsCoreRound A st (coreVals A (castSample hN s) (quantReq A req)) (quantReq A req).l (quantReq A req).u
req.2.1` (`A = asmParams M J R a_req ξ_req`), with the oracle `orc`. -/
theorem bsRound_implG {prog : List Expr} {M : ℕ} (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hEv : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2)
    {Mc J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {U : Type} {code : U → ℕ} (hinj : Function.Injective code) {N : ℕ}
    (s : Fin N → U) (hN : N = (asmParams Mc J R aReq ξReq).N) {req : VReq U} (hreq : req.Valid)
    {st : AdaState} (hok : AdaOK (asmParams Mc J R aReq ξReq) st)
    (hMP : bsPubBound Mc J R (dyadicExp aReq) (dyadicExp ξReq) ≤ M)
    (hM : 2 ^ 32 * adaBoundA (asmParams Mc J R aReq ξReq) +
      2 * valSize (Val.list ((asmBlocks (asmParams Mc J R aReq ξReq) code s).map (encL encN))) ≤ M)
    {orc : ℤ → ℤ → ℤ → ℤ}
    (hagree0 : ∀ ℓ : Fin N, orc 0 (code (s ℓ) : ℤ) (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1) =
      reqOracle code req 0 (code (s ℓ) : ℤ) (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1))
    (hagree1 : orc 1 0 (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1) =
      reqOracle code req 1 0 (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1))
    (hagree2 : orc 2 0 (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1) =
      reqOracle code req 2 0 (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1)) :
    ImplementsO orc prog M
      [Val.list [encVParams Mc J R aReq ξReq, bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams Mc J R aReq ξReq) st
        (coreVals (asmParams Mc J R aReq ξReq) (V2.castSample hN s)
          (quantReq (asmParams Mc J R aReq ξReq) req))
        (quantReq (asmParams Mc J R aReq ξReq) req).l (quantReq (asmParams Mc J R aReq ξReq) req).u
        req.2.1) := by
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  have hblk := bsR_asmBlocks_length (asmParams Mc J R aReq ξReq) code s hN
  -- the oracle agrees with `reqOracle` on the stored codes
  have hag : ∀ blk ∈ asmBlocks (asmParams Mc J R aReq ξReq) code s, ∀ r ∈ blk,
      orc 0 (r : ℤ) (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1) =
        reqOracle code req 0 (r : ℤ) (((asmParams Mc J R aReq ξReq).qA : ℤ) + 1) := by
    intro blk hblk' r hr
    obtain ⟨ℓ, rfl⟩ := bsR_mem_asmBlocks _ code s blk hblk' r hr
    exact hagree0 ℓ
  -- the ranges of D2 and D3
  have horc0 : ∀ blk ∈ asmBlocks (asmParams Mc J R aReq ξReq) code s, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((asmParams Mc J R aReq ξReq).qA + 1) ∧
        orc 0 (r : ℤ) ((asmParams Mc J R aReq ξReq).qA + 1) ≤
          2 ^ ((asmParams Mc J R aReq ξReq).qA + 1) := by
    intro blk hblk' r hr
    rw [hag blk hblk' r hr]
    exact bsE_reqOracle_mem code hreq (r : ℤ) _
  have horc12 : |orc 1 0 ((asmParams Mc J R aReq ξReq).qA + 1)| ≤
        2 ^ ((asmParams Mc J R aReq ξReq).qA + 2) ∧
      |orc 2 0 ((asmParams Mc J R aReq ξReq).qA + 1)| ≤
        2 ^ ((asmParams Mc J R aReq ξReq).qA + 2) := by
    rw [hagree1, hagree2, bsR_reqOracle_one, bsR_reqOracle_two]
    exact ⟨bsN_trunc_abs_le _ _, bsN_trunc_abs_le _ _⟩
  -- W2's generic round spec at `orc`
  have key := bsRound_impl_gen hO hW4 hpub hq hEv hEn h4 h2 hblk hok req.2.1 horc0 horc12 hMP hM
  -- the query table and the endpoints read through `orc` are those of the quantized request
  have hev : evalsOf orc (asmParams Mc J R aReq ξReq).qA (asmBlocks (asmParams Mc J R aReq ξReq) code s) =
      evalsOf (reqOracle code req) (asmParams Mc J R aReq ξReq).qA
        (asmBlocks (asmParams Mc J R aReq ξReq) code s) :=
    bsR_evalsOf_congr hag
  have hv := bsR_evalsOf_eq (asmParams Mc J R aReq ξReq) hinj s hN hreq
  obtain ⟨el, eu⟩ := bsR_ends_eq (asmParams Mc J R aReq ξReq) code req
  refine ImplementsO.congr key ?_ (fun _ => rfl)
  rw [hev, hv, hagree1, hagree2, el, eu]

/-- `bsRound_implR` is the case `orc = reqOracle code req` of `bsRound_implG` (shape check). -/
example {prog : List Expr} {M : ℕ} (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hEv : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2)
    {Mc J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {U : Type} {code : U → ℕ} (hinj : Function.Injective code) {N : ℕ}
    (s : Fin N → U) (hN : N = (asmParams Mc J R aReq ξReq).N) {req : VReq U} (hreq : req.Valid)
    {st : AdaState} (hok : AdaOK (asmParams Mc J R aReq ξReq) st)
    (hMP : bsPubBound Mc J R (dyadicExp aReq) (dyadicExp ξReq) ≤ M)
    (hM : 2 ^ 32 * adaBoundA (asmParams Mc J R aReq ξReq) +
      2 * valSize (Val.list ((asmBlocks (asmParams Mc J R aReq ξReq) code s).map (encL encN))) ≤ M) :
    ImplementsO (reqOracle code req) prog M
      [Val.list [encVParams Mc J R aReq ξReq, bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams Mc J R aReq ξReq) st
        (coreVals (asmParams Mc J R aReq ξReq) (V2.castSample hN s)
          (quantReq (asmParams Mc J R aReq ξReq) req))
        (quantReq (asmParams Mc J R aReq ξReq) req).l (quantReq (asmParams Mc J R aReq ξReq) req).u
        req.2.1) :=
  bsRound_implG hO hW4 hpub hq hEv hEn ha0 ha1 hξ0 hξ1 hinj s hN hreq hok hMP hM
    (fun _ => rfl) rfl rfl

end F2e2e.BSpace
