import F2e2e.BSpace.MachineGstO
import F2e2e.BSpace.MachineBridgeO
import F2e2e.BSpace.BoundSpace

/-!
# B_space, layer M*: from the oracle value judgment to the bit-bounded oracle machine

Owner: C-SPACE (B_space layer M; area lead W4). Composition of
* M2 (C-SPACE, `F2e2e/BSpace/MachineGstO.lean`): `EvalsValO` ⇒ a run of the oracle big-step semantics `evalO`
  with peak `≤ ((r 0 + 1)(K + 3) + 1) · M` (`runsOnO_of_evalsValO`, `ImplementsO.runsOnO`), and
* M3 (17fc0802, `F2e2e/BSpace/MachineBridgeO.lean`): an `evalO` run within peak `S` ⇒ a run of §7's machine
  `stepO` with the same output and unread tape, every step within
  `(bridgeWC + 2)(bitsFactor prog · S + bitsConst prog) + bridgeWC'` bits (`runsWithinBitsO_of_runsOnO`).

Main results (per run of an assembled program with a rank certificate `RankOK prog r K` and value bound `M`;
`bsMachineBound` is defined in `F2e2e/BSpace/BoundSpace.lean`):
* `runsWithinBitsO_of_evalsValO`: an `EvalsValO` evaluation of the entry body on an input of size `≤ M`,
  consuming exactly `bits`, is a `RunsWithinBitsO` run on every tape `bits ++ rest`, leaving `rest`, within
  `bsMachineBound prog r K M`;
* `ImplementsO.runsWithinBitsO`: the bit-program form (every run `p.run tape = some (a, rest)`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-- **M\*.** An `EvalsValO` evaluation of the entry body (input of size `≤ M`, consuming exactly `bits`) is
a run of the oracle machine on every tape `bits ++ rest`, leaving `rest`, within `bsMachineBound`. -/
theorem runsWithinBitsO_of_evalsValO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {K M : ℕ} (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input out : Val}
    {bits : List Bool} (h : EvalsValO orc prog M [input] bits (.inl body) out)
    (hin : valSize input ≤ M) (rest : List Bool) :
    RunsWithinBitsO orc prog input (bits ++ rest) out rest (bsMachineBound prog r K M) :=
  runsWithinBitsO_of_runsOnO (runsOnO_of_evalsValO hR h0 h hin rest)

/-- **M\*, bit-program form.** If the entry body implements `p` (with the oracle `orc`) on an input of size
`≤ M`, every run `p.run tape = some (a, rest)` is a run of the oracle machine on `tape` with output `enc a`,
leaving exactly `rest`, within `bsMachineBound`. -/
theorem ImplementsO.runsWithinBitsO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ}
    {K M : ℕ} (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input : Val}
    {α : Type} {enc : α → Val} {p : Discrete.BitProg α} (h : ImplementsO orc prog M [input] body enc p)
    (hin : valSize input ≤ M) {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc prog input tape (enc a) rest (bsMachineBound prog r K M) :=
  runsWithinBitsO_of_runsOnO (h.runsOnO hR h0 hin hrun)

end F2e2e.BSpace
