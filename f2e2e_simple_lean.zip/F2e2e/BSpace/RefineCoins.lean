import F2e2e.BSpace.RefineDefs
import F2e2e.BSpace.AssembleThread
import F2e2e.B.ArchCount

/-!
# B_space, layer R4 (B-ARCH): no tape exhaustion

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §R (R4). The Spec quantifies the tape length as `c ≥ c_B`; here
`c_B = bsCoins A = adaCoins A = adaInitBits A + (M + R) · adaCallBits A` (`RefineDefs`). On a tape of
at least `bsCoins A` bits, the threaded run (C-TOP's `threadRun`: `adaInit A`, then the rounds
`bsCoreRound A st (vals t) (ls t) (us t) (kinds t)`, each on the rest of the tape left by the
previous one) never fails, whatever the (history-independent) inputs of the rounds are:

* the core makes at most `p + 1` noise draws in the initialization and at most `callDraws A` in each
  processed request, and processes at most `M + R` requests: the request potential
  `reqPot A st = (M − nInt) + (R − nNum)` (`0` once halted) drops by one per processed request
  (`adaIntervalD_budget`, `adaNumericalD_budget`, `F2e2e/B/ArchCount.lean`), and unprocessed requests
  (over the cap, or halted) draw nothing;
* every draw reads at most `A.maxDrawBits` bits (`adaDraw_depth_le`);
* hence the invariant `maxDrawBits · callDraws · reqPot A st ≤ |rest of the tape|` holds after the
  initialization and is preserved by every round (`refine_runToBits_of_budget`, a run version of
  `DrawsBudget`).

Main statement: `refine_noExhaust` (shape fixed with B-ACC for C-TOP's `exec_of_thread`).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B

section Generic

variable {Pm β α : Type}

/-- **Runs within a draw budget.** If every path of `prog` makes at most `B` draws, counting `Φ` of
its output (`DrawsBudget prog B Φ`), every sampler reads at most `d` bits, and the tape has at least
`d · B` bits, then the bit implementation of `prog` succeeds on the tape and leaves at least `d · Φ a`
unread bits, `a` being its output. -/
theorem refine_runToBits_of_budget (s : Pm → BitProg β) {d : ℕ} (hs : ∀ p, (s p).depth ≤ d)
    {prog : DrawProg Pm β α} {B : ℕ} {Φ : α → ℕ} (h : DrawsBudget prog B Φ) {t : List Bool}
    (ht : d * B ≤ t.length) :
    ∃ a r, (DrawProg.toBits s prog).run t = some (a, r) ∧ d * Φ a ≤ r.length := by
  induction prog generalizing B t with
  | ret a => exact ⟨a, t, rfl, le_trans (Nat.mul_le_mul_left d h) ht⟩
  | draw p k ih =>
    cases B with
    | zero => exact h.elim
    | succ B =>
      have hsp := hs p
      have e : d * (B + 1) = d * B + d := by ring
      have hd : (s p).depth ≤ t.length := by omega
      obtain ⟨⟨b, t1⟩, hrun⟩ := Option.isSome_iff_exists.mp (BitProg.run_isSome (s p) t hd)
      obtain ⟨pre, hpre, hlen⟩ := BitProg.run_eq_some_suffix hrun
      have hlen' : t.length = pre.length + t1.length := by rw [hpre, List.length_append]
      have ht1 : d * B ≤ t1.length := by omega
      obtain ⟨a, r, hr, hΦ⟩ := ih b (h b) ht1
      refine ⟨a, r, ?_, hΦ⟩
      rw [DrawProg.run_toBits_draw, hrun]
      exact hr

end Generic

/-! ## The core's runs -/

/-- The tape invariant of the threaded run: enough bits for the remaining processed requests. -/
def refineTapeInv (A : AdaParams) (st : AdaState) (r : List Bool) : Prop :=
  A.maxDrawBits * (callDraws A * reqPot A st) ≤ r.length

/-- **The initialization** succeeds on a tape of at least `bsCoins A` bits and leaves enough bits for
`M + R` processed requests. -/
theorem refine_init_run (A : AdaParams) {t : List Bool} (ht : bsCoins A ≤ t.length) :
    ∃ st r, (adaInit A).run t = some (st, r) ∧ refineTapeInv A st r := by
  have hB : DrawsBudget (adaInitD A) (A.p + 1 + (A.M + A.R) * callDraws A)
      (fun st => callDraws A * reqPot A st) := by
    refine drawsBudget_of (adaInitD_drawsLE A) ((adaInitD_allOut A).mono fun st hst => ?_)
    rw [hst, Nat.mul_comm]
    omega
  have hcoins : bsCoins A = A.maxDrawBits * (A.p + 1 + (A.M + A.R) * callDraws A) := by
    rw [bsCoins_eq]
    unfold adaInitBits adaCallBits callDraws
    ring
  exact refine_runToBits_of_budget (adaDraw A) (adaDraw_depth_le A) hB (by omega)

/-- **One request** succeeds on a tape satisfying the invariant, and the invariant holds afterwards
(processed requests consume their budget, unprocessed ones read nothing). -/
theorem refine_coreRound_run (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ)
    (kind : Bool) {t : List Bool} (ht : refineTapeInv A st t) :
    ∃ o st' r, (bsCoreRound A st vals l u kind).run t = some ((o, st'), r) ∧
      refineTapeInv A st' r := by
  cases kind
  · obtain ⟨⟨x, st'⟩, r, hr, hΦ⟩ := refine_runToBits_of_budget (adaDraw A) (adaDraw_depth_le A)
      (adaNumericalD_budget A st vals) ht
    refine ⟨Sum.inr x, st', r, ?_, hΦ⟩
    rw [bsCoreRound_false, BitProg.run_map]
    unfold adaNumerical
    rw [hr]
    rfl
  · obtain ⟨⟨c, st'⟩, r, hr, hΦ⟩ := refine_runToBits_of_budget (adaDraw A) (adaDraw_depth_le A)
      (adaIntervalD_budget A st vals l u) ht
    refine ⟨Sum.inl c, st', r, ?_, hΦ⟩
    rw [bsCoreRound_true, BitProg.run_map]
    unfold adaInterval
    rw [hr]
    rfl

/-! ## R4 -/

/-- The threaded run on a tape of at least `bsCoins A` bits exists at every round and keeps the tape
invariant. -/
theorem refine_thread_inv (A : AdaParams) (vals : ℕ → List (List ℕ)) (ls us : ℕ → ℚ)
    (kinds : ℕ → Bool) (τ : List Bool) (hτ : bsCoins A ≤ τ.length) :
    ∀ t, ∃ st r, threadRun (adaInit A) (fun t st => bsCoreRound A st (vals t) (ls t) (us t) (kinds t))
      τ t = some (st, r) ∧ refineTapeInv A st r := by
  intro t
  induction t with
  | zero => exact refine_init_run A hτ
  | succ t ih =>
    obtain ⟨st, r, h, hinv⟩ := ih
    obtain ⟨o, st', r', hr, hinv'⟩ :=
      refine_coreRound_run A st (vals t) (ls t) (us t) (kinds t) hinv
    refine ⟨st', r', ?_, hinv'⟩
    rw [threadRun_succ_of h, hr]
    rfl

/-- **R4 (no tape exhaustion).** On a tape of at least `bsCoins A = adaCoins A` bits, the threaded run
of the initialization and the rounds never fails, for any inputs of the rounds. -/
theorem refine_noExhaust (A : AdaParams) (vals : ℕ → List (List ℕ)) (ls us : ℕ → ℚ)
    (kinds : ℕ → Bool) (τ : List Bool) (hτ : bsCoins A ≤ τ.length) (t : ℕ) :
    (threadRun (adaInit A) (fun t st => bsCoreRound A st (vals t) (ls t) (us t) (kinds t)) τ
      t).isSome := by
  obtain ⟨st, r, h, -⟩ := refine_thread_inv A vals ls us kinds τ hτ t
  rw [h]
  rfl

end F2e2e.BSpace
