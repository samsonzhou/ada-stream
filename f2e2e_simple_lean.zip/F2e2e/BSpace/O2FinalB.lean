import F2e2e.BSpace.O2Final
import F2e2e.BSpace.O2GstAsmB
import F2e2e.BSpace.Assemble
import F2e2e.BSpace.BoundParams
import F2e2e.BSpace.RefineRound

/-!
# O2b, the final inequalities of the two B entry programs (B-ACC)

These lemmas close the fields `O2Inputs.finI` and `O2Inputs.finR` of W4's `F2e2e/BSpace/O2Assemble.lean`.
The constants of the B programs `bsInitProg` and `bsRoundProg`:
* from NEW-B's D5: `progDepth ≤ 59`, `fnWidth = ⌈log₂(|prog| + 1)⌉ ≤ 10`, `bsRank 0 = 15`;
* from O2B-GST: `exprDepth body_bsInit = 8`, `exprDepth body_bsRound = 15`.

So the instance of `o2f_final_gen_range` has `c = 4·60 + 18 = 258`, `o2fC 59 10 15 = 380266`, and `e = 11` (init)
or `e = 18` (round). `N` and `χ` are the terms of `asmBound 30`: `N = (alg2Params M J R a_req ξ_req).N` and
`χ = valChi M J R (dyadicDown a_req) (dyadicDown ξ_req)`. The pointwise closers take `N`, `χ` as variables with these
equations, so bounds stated with `(asmParams M J R a_req ξ_req).N` (= O2B-SIZE's `A.N`) plug in with
`hN := (refine_N M J R ha0 ha1 hξ0 hξ1).symm`, and bounds stated with `(alg2Params …).N` plug in with `hN := rfl`.

Three forms of the closers:
* pointwise: `o2f_finI_pt`, `o2f_finR_pt`. General budgets with N-free parts `d_m`, `d_τ` and a free `d_X`;
  side condition `258 (e d_m + d_τ) + 380266 ≤ d_X · N χ`.
* pure forms (no N-free parts): `o2f_finI_pure`, `o2f_finR_pure`. Here the bridge constant is bounded using
  `N χ ≥ 1`. Closing conditions: `258 (e c_mU + c_τU) ≤ 2^30` and `258 (e c_mX + c_τX) + 380266 ≤ 61 · 2^30`.
* the exact field shape (bounds as functions of the public parameters, with `(alg2Params …).N`):
  `o2f_finI_of`, `o2f_finR_of`, `o2f_finI_of_pure`, `o2f_finR_of_pure`.
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine F2e2e.Cost F2e2e.BSpace.MachineO

/-- **The machine constants of the initialization program**: `progDepth ≤ 59`, `fnWidth ≤ 10`, `bsRank 0 ≤ 15`,
`exprDepth body_bsInit ≤ 8`. -/
theorem o2f_bsInit_consts : progDepth bsInitProg ≤ 59 ∧ fnWidth bsInitProg ≤ 10 ∧ bsRank 0 ≤ 15 ∧
    exprDepth body_bsInit ≤ 8 :=
  ⟨bsInitProg_progDepth_le, Nat.clog_le_of_le_pow bsInitProg_length_succ_le, le_of_eq bsRank_zero,
    le_of_eq bs_entry_depths.1⟩

/-- **The machine constants of the round program**: `progDepth ≤ 59`, `fnWidth ≤ 10`, `bsRank 0 ≤ 15`,
`exprDepth body_bsRound ≤ 15`. -/
theorem o2f_bsRound_consts : progDepth bsRoundProg ≤ 59 ∧ fnWidth bsRoundProg ≤ 10 ∧ bsRank 0 ≤ 15 ∧
    exprDepth body_bsRound ≤ 15 :=
  ⟨bsRoundProg_progDepth_le, Nat.clog_le_of_le_pow bsRoundProg_length_succ_le, le_of_eq bsRank_zero,
    le_of_eq bs_entry_depths.2⟩

/-- `N χ ≥ 1` for the actual parameters (`N ≥ p + 16`, `χ > 60`). -/
theorem o2f_one_le_Nchi (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    1 ≤ (alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq) := by
  have h1 := BoundAux.p_add_le_N M J R (dyadicExp aReq) (dyadicExp ξReq)
  have h2 := bs_sixty_lt_chi M J R aReq ξReq
  rw [refine_N M J R ha0 ha1 hξ0 hξ1]
  exact Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega) (by omega))

/-! ## The initialization (`e = 11`) -/

/-- **The initialization's final inequality, pointwise.** With `N = (alg2Params …).N`, `χ = valChi …`, for budgets
`m ≤ c_mU N b_𝒰 + c_mX N χ + d_m`, `τ ≤ c_τU N b_𝒰 + c_τX N χ + d_τ` with `258 (11 d_m + d_τ) + 380266 ≤ d_X N χ`,
`258 (11 c_mU + c_τU) ≤ 2^30` and `258 (11 c_mX + c_τX) + d_X ≤ 61 · 2^30`: the charge of `bsInitProg` is within
`asmBound 30`. -/
theorem o2f_finI_pt {M J R : ℕ} {aReq ξReq : ℝ} {N χ bU m τ cmU cmX cτU cτX dm dτ dX : ℕ}
    (hN : N = (alg2Params M J R aReq ξReq).N) (hχ : χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq))
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hd : 258 * (11 * dm + dτ) + 380266 ≤ dX * (N * χ))
    (hU : 258 * (11 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (11 * cmX + cτX) + dX ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd bsInitProg (bsRank 0) ((exprDepth body_bsInit + 3) * m + τ) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU := by
  obtain ⟨hD, hW, hr, hE⟩ := o2f_bsInit_consts
  have h60 : 60 < χ := hχ ▸ bs_sixty_lt_chi M J R aReq ξReq
  have hd' : (4 * (59 + 1) + 18) * ((8 + 3) * dm + dτ) + o2fC 59 10 15 ≤ dX * (N * χ) := by
    have e : (4 * (59 + 1) + 18) * ((8 + 3) * dm + dτ) = 258 * (11 * dm + dτ) := by norm_num
    rw [e, o2fC_59_10_15]
    exact hd
  have hU' : (4 * (59 + 1) + 18) * ((8 + 3) * cmU + cτU) ≤ 2 ^ 30 := by
    have e : (4 * (59 + 1) + 18) * ((8 + 3) * cmU + cτU) = 258 * (11 * cmU + cτU) := by norm_num
    rw [e]
    exact hU
  have hX' : (4 * (59 + 1) + 18) * ((8 + 3) * cmX + cτX) + dX ≤ 61 * 2 ^ 30 := by
    have e : (4 * (59 + 1) + 18) * ((8 + 3) * cmX + cτX) = 258 * (11 * cmX + cτX) := by norm_num
    rw [e]
    exact hX
  have hfin := o2f_final_gen_range (D0 := 59) (W0 := 10) (ρ0 := 15) (E0 := 8) (bU := bU) hD (by norm_num) hW hr
    hE hm hτ hd' h60 hU' hX'
  rw [hN, hχ] at hfin
  exact hfin

/-- **The initialization's final inequality, pure form** (no N-free parts): with `N = (alg2Params …).N`,
`χ = valChi …`, for `m ≤ c_mU N b_𝒰 + c_mX N χ`, `τ ≤ c_τU N b_𝒰 + c_τX N χ`, `258 (11 c_mU + c_τU) ≤ 2^30` and
`258 (11 c_mX + c_τX) + 380266 ≤ 61 · 2^30`. -/
theorem o2f_finI_pure {M J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {N χ bU m τ cmU cmX cτU cτX : ℕ}
    (hN : N = (alg2Params M J R aReq ξReq).N) (hχ : χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq))
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ))
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ))
    (hU : 258 * (11 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (11 * cmX + cτX) + 380266 ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd bsInitProg (bsRank 0) ((exprDepth body_bsInit + 3) * m + τ) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU := by
  have hNχ : 1 ≤ N * χ := by
    rw [hN, hχ]
    exact o2f_one_le_Nchi M J R ha0 ha1 hξ0 hξ1
  have hd : 258 * (11 * 0 + 0) + 380266 ≤ 380266 * (N * χ) :=
    calc 258 * (11 * 0 + 0) + 380266 = 380266 := by norm_num
      _ ≤ 380266 * (N * χ) := Nat.le_mul_of_pos_right _ hNχ
  exact o2f_finI_pt hN hχ (hm.trans (Nat.le_add_right _ 0)) (hτ.trans (Nat.le_add_right _ 0)) hd hU hX

/-- **`O2Inputs.finI`, field shape.** From bounds on `mI`, `τI` (with N-free parts `dm`, `dτ`) as functions of the
public parameters. -/
theorem o2f_finI_of (mI τI : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ) (dm dτ : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ)
    {cmU cmX cτU cτX dX : ℕ}
    (hm : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      mI M J R aReq ξReq bU ≤ cmU * ((alg2Params M J R aReq ξReq).N * bU) +
        cmX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)) +
          dm M J R aReq ξReq bU)
    (hτ : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      τI M J R aReq ξReq bU ≤ cτU * ((alg2Params M J R aReq ξReq).N * bU) +
        cτX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)) +
          dτ M J R aReq ξReq bU)
    (hd : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      258 * (11 * dm M J R aReq ξReq bU + dτ M J R aReq ξReq bU) + 380266 ≤
        dX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hU : 258 * (11 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (11 * cmX + cτX) + dX ≤ 61 * 2 ^ 30) :
    ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      ((O2B.bridgeAdd bsInitProg (bsRank 0)
          ((exprDepth body_bsInit + 3) * mI M J R aReq ξReq bU + τI M J R aReq ξReq bU) : ℕ) : ℝ) ≤
        asmBound 30 M J R aReq ξReq bU :=
  fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU =>
    o2f_finI_pt rfl rfl (hm M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) (hτ M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU)
      (hd M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hU hX

/-- **`O2Inputs.finI`, field shape, pure form** (bounds on `mI`, `τI` without N-free parts). -/
theorem o2f_finI_of_pure (mI τI : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ) {cmU cmX cτU cτX : ℕ}
    (hm : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      mI M J R aReq ξReq bU ≤ cmU * ((alg2Params M J R aReq ξReq).N * bU) +
        cmX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hτ : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      τI M J R aReq ξReq bU ≤ cτU * ((alg2Params M J R aReq ξReq).N * bU) +
        cτX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hU : 258 * (11 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (11 * cmX + cτX) + 380266 ≤ 61 * 2 ^ 30) :
    ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      ((O2B.bridgeAdd bsInitProg (bsRank 0)
          ((exprDepth body_bsInit + 3) * mI M J R aReq ξReq bU + τI M J R aReq ξReq bU) : ℕ) : ℝ) ≤
        asmBound 30 M J R aReq ξReq bU :=
  fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU =>
    o2f_finI_pure ha0 ha1 hξ0 hξ1 rfl rfl (hm M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU)
      (hτ M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hU hX

/-! ## The round (`e = 18`) -/

/-- **A request's final inequality, pointwise.** With `N = (alg2Params …).N`, `χ = valChi …`, for budgets
`m ≤ c_mU N b_𝒰 + c_mX N χ + d_m`, `τ ≤ c_τU N b_𝒰 + c_τX N χ + d_τ` with `258 (18 d_m + d_τ) + 380266 ≤ d_X N χ`,
`258 (18 c_mU + c_τU) ≤ 2^30` and `258 (18 c_mX + c_τX) + d_X ≤ 61 · 2^30`: the charge of `bsRoundProg` is within
`asmBound 30`. -/
theorem o2f_finR_pt {M J R : ℕ} {aReq ξReq : ℝ} {N χ bU m τ cmU cmX cτU cτX dm dτ dX : ℕ}
    (hN : N = (alg2Params M J R aReq ξReq).N) (hχ : χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq))
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hd : 258 * (18 * dm + dτ) + 380266 ≤ dX * (N * χ))
    (hU : 258 * (18 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (18 * cmX + cτX) + dX ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd bsRoundProg (bsRank 0) ((exprDepth body_bsRound + 3) * m + τ) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU := by
  obtain ⟨hD, hW, hr, hE⟩ := o2f_bsRound_consts
  have h60 : 60 < χ := hχ ▸ bs_sixty_lt_chi M J R aReq ξReq
  have hd' : (4 * (59 + 1) + 18) * ((15 + 3) * dm + dτ) + o2fC 59 10 15 ≤ dX * (N * χ) := by
    have e : (4 * (59 + 1) + 18) * ((15 + 3) * dm + dτ) = 258 * (18 * dm + dτ) := by norm_num
    rw [e, o2fC_59_10_15]
    exact hd
  have hU' : (4 * (59 + 1) + 18) * ((15 + 3) * cmU + cτU) ≤ 2 ^ 30 := by
    have e : (4 * (59 + 1) + 18) * ((15 + 3) * cmU + cτU) = 258 * (18 * cmU + cτU) := by norm_num
    rw [e]
    exact hU
  have hX' : (4 * (59 + 1) + 18) * ((15 + 3) * cmX + cτX) + dX ≤ 61 * 2 ^ 30 := by
    have e : (4 * (59 + 1) + 18) * ((15 + 3) * cmX + cτX) = 258 * (18 * cmX + cτX) := by norm_num
    rw [e]
    exact hX
  have hfin := o2f_final_gen_range (D0 := 59) (W0 := 10) (ρ0 := 15) (E0 := 15) (bU := bU) hD (by norm_num) hW hr
    hE hm hτ hd' h60 hU' hX'
  rw [hN, hχ] at hfin
  exact hfin

/-- **A request's final inequality, pure form** (no N-free parts): with `N = (alg2Params …).N`, `χ = valChi …`,
for `m ≤ c_mU N b_𝒰 + c_mX N χ`, `τ ≤ c_τU N b_𝒰 + c_τX N χ`, `258 (18 c_mU + c_τU) ≤ 2^30` and
`258 (18 c_mX + c_τX) + 380266 ≤ 61 · 2^30`. -/
theorem o2f_finR_pure {M J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {N χ bU m τ cmU cmX cτU cτX : ℕ}
    (hN : N = (alg2Params M J R aReq ξReq).N) (hχ : χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq))
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ))
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ))
    (hU : 258 * (18 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (18 * cmX + cτX) + 380266 ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd bsRoundProg (bsRank 0) ((exprDepth body_bsRound + 3) * m + τ) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU := by
  have hNχ : 1 ≤ N * χ := by
    rw [hN, hχ]
    exact o2f_one_le_Nchi M J R ha0 ha1 hξ0 hξ1
  have hd : 258 * (18 * 0 + 0) + 380266 ≤ 380266 * (N * χ) :=
    calc 258 * (18 * 0 + 0) + 380266 = 380266 := by norm_num
      _ ≤ 380266 * (N * χ) := Nat.le_mul_of_pos_right _ hNχ
  exact o2f_finR_pt hN hχ (hm.trans (Nat.le_add_right _ 0)) (hτ.trans (Nat.le_add_right _ 0)) hd hU hX

/-- **`O2Inputs.finR`, field shape.** From bounds on `mR`, `τR` (with N-free parts `dm`, `dτ`) as functions of the
public parameters. -/
theorem o2f_finR_of (mR τR : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ) (dm dτ : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ)
    {cmU cmX cτU cτX dX : ℕ}
    (hm : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      mR M J R aReq ξReq bU ≤ cmU * ((alg2Params M J R aReq ξReq).N * bU) +
        cmX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)) +
          dm M J R aReq ξReq bU)
    (hτ : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      τR M J R aReq ξReq bU ≤ cτU * ((alg2Params M J R aReq ξReq).N * bU) +
        cτX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)) +
          dτ M J R aReq ξReq bU)
    (hd : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      258 * (18 * dm M J R aReq ξReq bU + dτ M J R aReq ξReq bU) + 380266 ≤
        dX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hU : 258 * (18 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (18 * cmX + cτX) + dX ≤ 61 * 2 ^ 30) :
    ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      ((O2B.bridgeAdd bsRoundProg (bsRank 0)
          ((exprDepth body_bsRound + 3) * mR M J R aReq ξReq bU + τR M J R aReq ξReq bU) : ℕ) : ℝ) ≤
        asmBound 30 M J R aReq ξReq bU :=
  fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU =>
    o2f_finR_pt rfl rfl (hm M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) (hτ M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU)
      (hd M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hU hX

/-- **`O2Inputs.finR`, field shape, pure form** (bounds on `mR`, `τR` without N-free parts). -/
theorem o2f_finR_of_pure (mR τR : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℕ) {cmU cmX cτU cτX : ℕ}
    (hm : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      mR M J R aReq ξReq bU ≤ cmU * ((alg2Params M J R aReq ξReq).N * bU) +
        cmX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hτ : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      τR M J R aReq ξReq bU ≤ cτU * ((alg2Params M J R aReq ξReq).N * bU) +
        cτX * ((alg2Params M J R aReq ξReq).N * valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (hU : 258 * (18 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 258 * (18 * cmX + cτX) + 380266 ≤ 61 * 2 ^ 30) :
    ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 → ∀ bU : ℕ,
      ((O2B.bridgeAdd bsRoundProg (bsRank 0)
          ((exprDepth body_bsRound + 3) * mR M J R aReq ξReq bU + τR M J R aReq ξReq bU) : ℕ) : ℝ) ≤
        asmBound 30 M J R aReq ξReq bU :=
  fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU =>
    o2f_finR_pure ha0 ha1 hξ0 hξ1 rfl rfl (hm M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU)
      (hτ M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU) hU hX

end F2e2e.BSpace.O2B
