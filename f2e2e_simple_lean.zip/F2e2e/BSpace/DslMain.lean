import F2e2e.BSpace.DslBodies
import F2e2e.BSpace.Pub
import F2e2e.BSpace.MachineEvalsO
import F2e2e.BSpace.RefineDefs
import F2e2e.C.Impl.AdaContract
import F2e2e.BSpace.DslBlocks
import F2e2e.BSpace.DslEnds

/-!
# B_space, layer D4 (W2): the entry bodies of the B programs

Owner: W2 (a2ff64c3), for W4 (cc77ceaa), plan `F2e2e/BSpace/BSPACE_PLAN.md` §D (D4). Helper keys
930–939 (none used so far).

* **State** `bsStateEnc blocks st = [blocks, adaEnc st]` (the stored blocks of record codes and W4's
  ADA state).
* **Response** `bsResp : CoreOut → Val` (Spec v3 §7 `parseVResponse` format): a certificate
  `accept/abort ↦ [0]`, `high/termHigh ↦ [1]`, `low/termLow ↦ [2]`; a numerical output
  `val μ ↦ [3, μ.num, μ.den]`, `abort ↦ [3, 0, 1]`.
* **Init** `body_bsInit` (entry of `bsInitProg`, oracle-free), input `[params, records]`:
  `pub := adaPub params` (W2, `bsPub_eval`), `blocks := bsBlocks [pub.blockSizes, records]` (D1, W3,
  key 900), `st := adaInit pub` (W4, `adaInit_impl`); output `[blocks, adaEnc st]`.
* **Round** `body_bsRound` (entry of `bsRoundProg`), input `[params, state, kind]`:
  `pub := adaPub params`, `vals := bsEvals [qA, blocks]` (D2, 1beb339b, key 910, oracle); for an interval
  request `ends := bsEnds [qA]` (D3, W5, key 920, oracle) and `r := adaInterval [pub, st, vals, l', u']`
  (602), else `r := adaNumerical [pub, st, vals]` (603); output `[[blocks, r.state], bsResp r.out]`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## Sizes -/

/-- The stored blocks are the record codes plus two cells per block. -/
theorem bsM_listSize_split : ∀ (ns codes : List ℕ),
    listSize ((splitBlocks ns codes).map (encL encN)) ≤ listSize (codes.map encN) + 2 * ns.length
  | [], codes => by simp [splitBlocks]
  | n :: ns, codes => by
    have ih := bsM_listSize_split ns (codes.drop n)
    have hsplit : listSize (codes.map encN) =
        listSize ((codes.take n).map encN) + listSize ((codes.drop n).map encN) := by
      rw [← listSize_append, ← List.map_append, List.take_append_drop]
    have hv : valSize (encL encN (codes.take n)) = 1 + listSize ((codes.take n).map encN) := by
      simp [encL]
    simp only [splitBlocks, List.map_cons, listSize_cons, List.length_cons]
    rw [hv]
    omega

theorem bsM_valSize_split (ns codes : List ℕ) :
    valSize (Val.list ((splitBlocks ns codes).map (encL encN))) ≤
      valSize (encL encN codes) + 2 * ns.length := by
  have h := bsM_listSize_split ns codes
  have e : valSize (encL encN codes) = 1 + listSize (codes.map encN) := by simp [encL]
  rw [valSize_list, e]
  omega

/-- The encoded parameters are below the record's value bound. -/
theorem bsM_params_size (Mc J R eA eXi : ℕ) :
    valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) ≤
      3 * bsPubL Mc J R eA eXi := by
  have hcap : Mc + J + R + 2 ≤ 2 ^ Nat.clog 2 (Mc + J + R + 2) := Nat.le_pow_clog (by norm_num) _
  have sM : Nat.size Mc ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sJ : Nat.size J ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sR : Nat.size R ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sA := size_le_self eA
  have sX := size_le_self eXi
  simp only [encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons, listSize_nil,
    valSize_int, bitLen_natCast, bsPubL]
  omega

/-! ## D1's contract (W3) as used here -/

/-- D1's contract (W3's `bsBlocks_eval`, `F2e2e/BSpace/DslBlocks.lean`) at key 900, in the form used by
`body_bsInit`. -/
def BlocksAt (prog : List Expr) (M : ℕ) : Prop :=
  AtIdx prog bsBlocksKey fun body => ∀ ns codes : List ℕ, ns.sum ≤ codes.length →
    valSize (encL encN ns) + valSize (encL encN codes) + 32 ≤ M →
    EvalsVal prog M [Val.list [encL encN ns, encL encN codes]] [] (.inl body)
      (Val.list ((splitBlocks ns codes).map (encL encN)))

/-! ## Init -/

set_option maxHeartbeats 1000000 in
/-- **Spec of `body_bsInit`** (oracle-free): on the encoded parameters `encInts [Mc, J, R, eA, eXi]`
(`eA ≥ 4`, `eXi ≥ 2`) and the record codes (`A.N` of them), `body_bsInit` implements `adaInit A`
(`A = adaParams eA eXi Mc J R`) with the state encoding `bsStateEnc (splitBlocks A.blockSizes codes)`,
for every value bound `M ≥ bsPubBound` and `M ≥ 2^32 adaBoundA A + 2 |codes|`. -/
theorem bsInit_impl {prog : List Expr} {M : ℕ} (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M) (hB : BlocksAt prog M)
    {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) {codes : List ℕ}
    (hcodes : codes.length = (adaParams eA eXi Mc J R).N)
    (hMP : bsPubBound Mc J R eA eXi ≤ M)
    (hM : 2 ^ 32 * adaBoundA (adaParams eA eXi Mc J R) + 2 * valSize (encL encN codes) ≤ M) :
    Implements prog M [Val.list [encInts [Mc, J, R, eA, eXi], encL encN codes]] body_bsInit
      (bsStateEnc (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes))
      (adaInit (adaParams eA eXi Mc J R)) := by
  have hbs := bsP_blockSizes_length eA eXi Mc J R
  have hT := bsP_Tmax_length eA eXi Mc J R
  have h600 : prog[Idx.adaPub]? = some body_adaPub :=
    hW4.pubTbl (Idx.adaPub, body_adaPub) (by simp [adaPubTable])
  have h601 : prog[Idx.adaInit]? = some body_adaInit :=
    hW4.tbl (e := (_, body_adaInit)) (by simp [w4Table])
  obtain ⟨b900, h900, hbody⟩ := hB
  /- ### Sizes -/
  set A := adaParams eA eXi Mc J R with hA
  set L := bsPubL Mc J R eA eXi with hL
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hZ16 := sixteen_le_adaZ A
  have hpZ := p_le_adaZ A
  have hB14 : 2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    have h1 : 16 * (A.p + adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := by nlinarith
    calc 2 ^ 14 * (A.p + adaZ A + 16) = 2 ^ 10 * (16 * (A.p + adaZ A + 16)) := by ring
      _ ≤ 2 ^ 10 * ((A.N + A.p + 16) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
      _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring
  have hparS := bsM_params_size Mc J R eA eXi
  have hL2 : L ≤ L * L := Nat.le_mul_self L
  have hMP' : 1048576 * (L * L) ≤ M := by
    have e : bsPubBound Mc J R eA eXi = 1048576 * (L * L) := by
      show 2 ^ 20 * L ^ 2 = _
      ring
    omega
  have hinM : valSize (Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      encL encN codes]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  set inp := Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)], encL encN codes]
    with hinp
  have hbsS : valSize (encL encN A.blockSizes) ≤ valSize (adaPubEnc A) :=
    (valSize_lt_of_mem (l := pubFields A) (by simp [pubFields])).le
  /- ### The parameter record -/
  obtain ⟨hpubE, hpubM⟩ := bsPub_eval hpub hq h4 h2 hMP
  have hpE : EvalsVal prog M [inp] [] (.inl (eCall Idx.adaPub (eAtN 0 (eV 0)))) (adaPubEnc A) :=
    evalsVal_call_det h600 (evalsVal_atN' (EvalsVal.var rfl) hinM rfl) hpubE
  unfold body_bsInit
  refine iv_letE_det hpE ?_
  /- ### The blocks -/
  have hlen : A.blockSizes.sum ≤ codes.length := by rw [hcodes]; rfl
  have hbE : EvalsVal prog M [adaPubEnc A, inp] []
      (.inl (eCall bsBlocksKey (ePair (eAtN 1 (eV 0)) (eAtN 1 (eV 1)))))
      (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) := by
    refine evalsVal_call_det h900 (EvalsVal.pair (evalsVal_atN' (l := pubFields A)
      (EvalsVal.var rfl) hpubM rfl) (evalsVal_atN' (EvalsVal.var rfl) hinM rfl) ?_)
      (hbody A.blockSizes codes hlen (by omega))
    simp only [valSize_list, listSize_cons, listSize_nil] at hbsS ⊢
    omega
  refine iv_letE_det hbE ?_
  /- ### `adaInit` -/
  have hMA : 2 ^ 32 * adaBoundA A ≤ M := by omega
  have hinit := implements_call_det
    (env := [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaPubEnc A, inp])
    h601 (EvalsVal.var (i := 1) rfl) (adaInit_impl hW4.samp hW4.list hW4.init hbs hT hMA)
  rw [← BitProg.bind_pure_right (adaInit A)]
  refine implements_letE_of hinit (AdaOK A) (fun bits st h => Always.of_run (adaInit_ok hbs) h) ?_
  intro st hok
  apply Implements.of_det
  have hstS := valSize_adaEnc_le hok
  have hspl := bsM_valSize_split A.blockSizes codes
  rw [hbs] at hspl
  refine EvalsVal.pair (EvalsVal.var rfl) (EvalsVal.var rfl) ?_
  simp only [valSize_list, listSize_cons, listSize_nil] at hspl ⊢
  omega


/-! ## The response conversion (oracle-free, lifted to `EvalsValO`) -/

section Resp

variable {prog : List Expr} {M : ℕ}

/-- The certificate code `c ∈ [0, 5]` to the response code `if c < 3 then c else (c - 2) % 3`. -/
theorem bsM_certCode_eval {env : List Val} {e : Expr} {z : ℤ}
    (he : EvalsVal prog M env [] (.inl e) (Val.int z)) (hz0 : 0 ≤ z) (hz : z ≤ 5) (hM : 16 ≤ M) :
    EvalsVal prog M env [] (.inl (bsCertCode e)) (Val.int (if z < 3 then z else (z - 2) % 3)) := by
  have hsmall : ∀ w : ℤ, 0 ≤ w → w ≤ 7 → valSize (Val.int w) ≤ M := by
    intro w hw0 hw
    rw [valSize_int]
    have : bitLen w ≤ 3 := by
      have h' : |w| ≤ ((7 : ℕ) : ℤ) := by rw [abs_of_nonneg hw0]; exact_mod_cast hw
      have := bitLen_le_size_of_abs_le h'
      have h7 : Nat.size 7 ≤ 3 := Nat.size_le.2 (by norm_num)
      omega
    omega
  have hlit : ∀ w : ℤ, 0 ≤ w → w ≤ 7 → EvalsVal prog M env [] (.inl (eLit w)) (Val.int w) :=
    fun w hw0 hw => EvalsVal.lit (hsmall w hw0 hw)
  have hlt := EvalsVal.lt he (hlit 3 (by norm_num) (by norm_num)) (by omega)
  by_cases hz3 : z < 3
  · rw [if_pos hz3]
    exact EvalsVal.ite_true hlt (by rw [if_pos hz3]; exact one_ne_zero) he
  · rw [if_neg hz3]
    have hsub := EvalsVal.sub he (hlit 2 (by norm_num) (by norm_num)) (hsmall _ (by omega) (by omega))
    have hmod := EvalsVal.mod hsub (hlit 3 (by norm_num) (by norm_num)) (by norm_num)
      (hsmall _ (Int.emod_nonneg _ (by norm_num)) (by
        have := Int.emod_lt_of_pos (z - 2) (show (0 : ℤ) < 3 by norm_num)
        omega))
    exact EvalsVal.ite_false hlt (by rw [if_neg hz3]) hmod

/-- **The certificate response.** -/
theorem bsM_certResp {env : List Val} {e : Expr} {c : AdaCert}
    (he : EvalsVal prog M env [] (.inl e) (encCert c)) (hM : 16 ≤ M) :
    EvalsVal prog M env [] (.inl (eList [bsCertCode e])) (bsResp (Sum.inl c)) := by
  have hcode : ∃ z : ℤ, encCert c = Val.int z ∧ 0 ≤ z ∧ z ≤ 5 ∧
      bsResp (Sum.inl c) = Val.list [Val.int (if z < 3 then z else (z - 2) % 3)] := by
    cases c
    · exact ⟨0, rfl, by norm_num, by norm_num, rfl⟩
    · exact ⟨1, rfl, by norm_num, by norm_num, rfl⟩
    · exact ⟨2, rfl, by norm_num, by norm_num, rfl⟩
    · exact ⟨3, rfl, by norm_num, by norm_num, rfl⟩
    · exact ⟨4, rfl, by norm_num, by norm_num, rfl⟩
    · exact ⟨5, rfl, by norm_num, by norm_num, rfl⟩
  obtain ⟨z, hz, hz0, hz5, hr⟩ := hcode
  rw [hz] at he
  rw [hr]
  have hv := bsM_certCode_eval he hz0 hz5 hM
  refine evalsVal_list (List.Forall₂.cons hv List.Forall₂.nil) ?_
  have hk : valSize (Val.int (if z < 3 then z else (z - 2) % 3)) ≤ 4 := by
    rw [valSize_int]
    have h0 : 0 ≤ (if z < 3 then z else (z - 2) % 3) := by
      split_ifs
      · exact hz0
      · exact Int.emod_nonneg _ (by norm_num)
    have h1 : (if z < 3 then z else (z - 2) % 3) ≤ 7 := by
      split_ifs
      · omega
      · have := Int.emod_lt_of_pos (z - 2) (show (0 : ℤ) < 3 by norm_num)
        omega
    have h' : |(if z < 3 then z else (z - 2) % 3)| ≤ ((7 : ℕ) : ℤ) := by
      rw [abs_of_nonneg h0]; exact_mod_cast h1
    have := bitLen_le_size_of_abs_le h'
    have h7 : Nat.size 7 ≤ 3 := Nat.size_le.2 (by norm_num)
    omega
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **The numerical response.** -/
theorem bsM_numResp {env : List Val} {e : Expr} {x : AdaNum}
    (he : EvalsVal prog M env [] (.inl e) (encNum x)) (hx : valSize (encNum x) ≤ M)
    (hr : valSize (bsResp (Sum.inr x)) ≤ M) (hM : 16 ≤ M) :
    EvalsVal prog M env [] (.inl (bsNumResp e)) (bsResp (Sum.inr x)) := by
  have hlit : ∀ w : ℤ, 0 ≤ w → w ≤ 3 → EvalsVal prog M env [] (.inl (eLit w)) (Val.int w) := by
    intro w hw0 hw
    refine EvalsVal.lit ?_
    rw [valSize_int]
    have h' : |w| ≤ ((3 : ℕ) : ℤ) := by rw [abs_of_nonneg hw0]; exact_mod_cast hw
    have := bitLen_le_size_of_abs_le h'
    have h3 : Nat.size 3 ≤ 2 := Nat.size_le.2 (by norm_num)
    omega
  cases x with
  | abort =>
    have hnil := EvalsVal.isNil_nil (he : EvalsVal prog M env [] (.inl e) (Val.list [])) (by omega)
    refine EvalsVal.ite_true hnil one_ne_zero ?_
    exact evalsVal_list (List.Forall₂.cons (hlit 3 (by norm_num) (by norm_num))
      (List.Forall₂.cons (hlit 0 (by norm_num) (by norm_num))
      (List.Forall₂.cons (hlit 1 (by norm_num) (by norm_num)) List.Forall₂.nil))) hr
  | val μ =>
    have he' : EvalsVal prog M env [] (.inl e) (Val.list [encQ μ]) := he
    have hnil := EvalsVal.isNil_cons he' (by omega)
    refine EvalsVal.ite_false hnil rfl ?_
    have hqM : valSize (encQ μ) ≤ M :=
      le_trans (valSize_lt_of_mem (l := [encQ μ]) List.mem_cons_self).le hx
    have hhd : EvalsVal prog M env [] (.inl (eHd e)) (encQ μ) := EvalsVal.head he' hqM
    have hnum : EvalsVal prog M env [] (.inl (eAtN 0 (eHd e))) (Val.int μ.num) :=
      evalsVal_atN' (l := [Val.int μ.num, Val.int (μ.den : ℤ)]) hhd hqM rfl
    have hden : EvalsVal prog M env [] (.inl (eAtN 1 (eHd e))) (Val.int (μ.den : ℤ)) :=
      evalsVal_atN' (l := [Val.int μ.num, Val.int (μ.den : ℤ)]) hhd hqM rfl
    exact evalsVal_list (List.Forall₂.cons (hlit 3 (by norm_num) (by norm_num))
      (List.Forall₂.cons hnum (List.Forall₂.cons hden List.Forall₂.nil))) hr

end Resp


/-- D1's contract from W3's table (`bsBlocks_eval`). -/
theorem blocksAt_of_table {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2) : BlocksAt prog M :=
  ⟨body_bsBlocks, hlib _ List.mem_cons_self, fun _ _ hlen hM => bsBlocks_eval hlib hlen hM⟩

/-! ## `ImplementsO` glue -/

section GlueO

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

/-- A deterministic `letE` with the oracle. -/
theorem bsM_letE_detO {α : Type} {env : List Val} {a b : Expr} {va : Val} {enc : α → Val}
    {p : BitProg α} (ha : EvalsValO orc prog M env [] (.inl a) va)
    (hb : ImplementsO orc prog M (va :: env) b enc p) :
    ImplementsO orc prog M env (Expr.letE a b) enc p := by
  intro bits x h
  have := EvalsValO.letE ha (hb bits x h)
  simpa using this

/-- `letE` with a support condition on the first output. -/
theorem bsM_letE_ofO {α β : Type} {env : List Val} {ea eb : Expr} {encA : α → Val}
    {encC : β → Val} {p : BitProg α} {f : α → BitProg β}
    (hp : ImplementsO orc prog M env ea encA p) (Q : α → Prop)
    (hQ : ∀ bits a, p.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → ImplementsO orc prog M (encA a :: env) eb encC (f a)) :
    ImplementsO orc prog M env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValO.letE (hp b₁ a h1) (hf a (hQ b₁ a h1) b₂ c h2)

/-- `ite` on a deterministic condition. -/
theorem bsM_iteO {α : Type} {env : List Val} {c t f : Expr} {z : ℤ} {enc : α → Val}
    {p : BitProg α} (hc : EvalsValO orc prog M env [] (.inl c) (Val.int z))
    (h : ImplementsO orc prog M env (if z ≠ 0 then t else f) enc p) :
    ImplementsO orc prog M env (Expr.ite c t f) enc p := by
  intro bits x hx
  have := EvalsValO.ite hc (h bits x hx)
  simpa using this

end GlueO

/-! ## The round after the predictions: the core request -/

section Tail

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

set_option maxHeartbeats 1000000 in
/-- **The core request** (the round after the predictions `vals`): in the environment
`[encVals vals, adaPubEnc A, [params, [blocksV, adaEnc st], encB kind]]`, the branch on `kind` implements
`bsCoreRound A st vals l' u' kind` with the endpoints `l', u'` of `bsEnds` (D3) and the output
`[[blocksV, adaEnc st'], bsResp out]`. Generic in the ADA instance `A`. -/
theorem bsRound_tail (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog) (hq : NormQSpec prog M)
    (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals)
    (horc : |orc 1 0 (A.qA + 1)| ≤ 2 ^ (A.qA + 2) ∧ |orc 2 0 (A.qA + 1)| ≤ 2 ^ (A.qA + 2))
    {params blocksV : Val} (kind : Bool)
    (hinpM : valSize (Val.list [params, Val.list [blocksV, adaEnc st], encB kind]) ≤ M)
    (hM : 2 ^ 32 * adaBoundA A + 2 * valSize blocksV ≤ M) :
    ImplementsO orc prog M [encVals vals, adaPubEnc A,
        Val.list [params, Val.list [blocksV, adaEnc st], encB kind]]
      (eIte (eAtN 2 (eV 2)) bsIvBranch bsNumBranch)
      (fun r => Val.list [Val.list [blocksV, adaEnc r.2], bsResp r.1])
      (bsCoreRound A st vals (bsN_end A.qA (orc 1 0 (A.qA + 1)))
        (bsN_end A.qA (orc 2 0 (A.qA + 1))) kind) := by
  /- ### Sizes -/
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hstB := valSize_adaEnc_le hok
  have hvB := valSize_encVals_le hbs hv.1 hv.2
  have hZ16 := sixteen_le_adaZ A
  have hqZ := qA_le_adaZ A
  have hpZ := p_le_adaZ A
  have hB14 : 2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    have h1 : 16 * (A.p + adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := by nlinarith
    calc 2 ^ 14 * (A.p + adaZ A + 16) = 2 ^ 10 * (16 * (A.p + adaZ A + 16)) := by ring
      _ ≤ 2 ^ 10 * ((A.N + A.p + 16) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
      _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring
  have hMA : 2 ^ 32 * adaBoundA A ≤ M := by omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hvM : valSize (encVals vals) ≤ M := by omega
  have h16 : 16 ≤ M := by omega
  set inp := Val.list [params, Val.list [blocksV, adaEnc st], encB kind] with hinp
  have hstV : valSize (Val.list [blocksV, adaEnc st]) ≤ M :=
    le_trans (valSize_lt_of_mem (l := [params, Val.list [blocksV, adaEnc st], encB kind])
      (by simp)).le hinpM
  -- field access (oracle-free, lifted)
  have hF : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      [params, Val.list [blocksV, adaEnc st], encB kind][n]? = some v →
      EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (EvalsVal.var henv) hinpM hget
  have hS : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      [blocksV, adaEnc st][n]? = some v → EvalsVal prog M env [] (.inl (eAtN n (eAtN 1 (eV k)))) v :=
    fun henv hget => evalsVal_atN' (hF henv rfl) hstV hget
  have hP : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some (adaPubEnc A) →
      (pubFields A)[n]? = some v → EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (l := pubFields A) (EvalsVal.var henv) hpubM hget
  have hkind : EvalsValO orc prog M [encVals vals, adaPubEnc A, inp] [] (.inl (eAtN 2 (eV 2)))
      (Val.int (if kind then 1 else 0)) := EvalsValO.of_evalsVal hO (hF rfl rfl)
  refine bsM_iteO hkind ?_
  cases kind with
  | true =>
    /- ### Interval request -/
    show ImplementsO orc prog M _ bsIvBranch _ _
    have h602 : prog[Idx.adaInterval]? = some body_adaInterval :=
      hW4.entryTbl (Idx.adaInterval, body_adaInterval) (by simp [adaEntryTable])
    have h920 : prog[bsEndsKey]? = some body_bsEnds := hEn _ List.mem_cons_self
    obtain ⟨hn1, hn2⟩ := horc
    have hl := bsN_end_bitLen' A.qA _ hn1
    have hu := bsN_end_bitLen' A.qA _ hn2
    have hlS := bsN_valSize_encQ_end A.qA _ hn1
    have huS := bsN_valSize_encQ_end A.qA _ hn2
    -- the endpoints (D3)
    have hqE : EvalsVal prog M [encVals vals, adaPubEnc A, inp] [] (.inl (eList [eAtN 7 (eV 1)]))
        (Val.list [encN A.qA]) := by
      refine evalsVal_list (List.Forall₂.cons (hP rfl rfl) List.Forall₂.nil) ?_
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
      have := size_le_self A.qA
      omega
    have hendsE : EvalsValO orc prog M [encVals vals, adaPubEnc A, inp] []
        (.inl (eCall bsEndsKey (eList [eAtN 7 (eV 1)])))
        (Val.list [encQ (bsN_end A.qA (orc 1 0 (A.qA + 1))),
          encQ (bsN_end A.qA (orc 2 0 (A.qA + 1)))]) :=
      evalsValO_call_det (by decide) h920 (EvalsValO.of_evalsVal hO hqE)
        (bsEnds_eval orc A.qA hEn hq hO ⟨hn1, hn2⟩ (by omega))
    refine bsM_letE_detO hendsE ?_
    set ends := Val.list [encQ (bsN_end A.qA (orc 1 0 (A.qA + 1))),
      encQ (bsN_end A.qA (orc 2 0 (A.qA + 1)))] with hends
    have hendsM : valSize ends ≤ M := by
      rw [hends]
      simp only [valSize_list, listSize_cons, listSize_nil] at hlS huS ⊢
      omega
    -- `adaInterval`
    have hargs : EvalsVal prog M [ends, encVals vals, adaPubEnc A, inp] []
        (.inl (eList [eV 2, eAtN 1 (eAtN 1 (eV 3)), eV 1, eAtN 0 (eV 0), eAtN 1 (eV 0)]))
        (Val.list [adaPubEnc A, adaEnc st, encVals vals,
          encQ (bsN_end A.qA (orc 1 0 (A.qA + 1))), encQ (bsN_end A.qA (orc 2 0 (A.qA + 1)))]) := by
      refine evalsVal_list (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (hS rfl rfl)
        (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons
          (evalsVal_atN' (EvalsVal.var rfl) hendsM rfl) (List.Forall₂.cons
          (evalsVal_atN' (EvalsVal.var rfl) hendsM rfl) List.Forall₂.nil))))) ?_
      simp only [valSize_list, listSize_cons, listSize_nil] at hlS huS ⊢
      omega
    have hivI := implementsO_call_det (orc := orc) (by decide) h602 (EvalsValO.of_evalsVal hO hargs)
      (Implements.toO hO (adaInterval_impl hW4.entryTbl hW4.prepTbl hW4.mus hW4.samp hW4.list hq
        hbs hT hpos hok hv hl hu hMA (by omega)))
    show ImplementsO orc prog M _ _ _ ((adaInterval A st vals _ _).bind _)
    refine bsM_letE_ofO hivI (fun r => AdaOK A r.2)
      (fun bits r h => Always.of_run (adaInterval_ok hok vals _ _) h) ?_
    rintro ⟨c, st'⟩ hok'
    dsimp only at hok'
    apply ImplementsO.of_det
    have hst'B := valSize_adaEnc_le hok'
    have hrM : valSize (Val.list [encCert c, adaEnc st']) ≤ M := by
      have : valSize (encCert c) ≤ 4 := by cases c <;> decide
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    have hresp : valSize (bsResp (Sum.inl c)) ≤ 5 := by cases c <;> decide
    refine EvalsValO.of_evalsVal hO ?_
    show EvalsVal prog M _ [] _ (Val.list [Val.list [blocksV, adaEnc st'], bsResp (Sum.inl c)])
    refine EvalsVal.pair (EvalsVal.pair (hS rfl rfl) (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) ?_)
      (bsM_certResp (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) h16) ?_
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only [valSize_list, listSize_cons, listSize_nil] at hresp ⊢
      omega
  | false =>
    /- ### Numerical request -/
    show ImplementsO orc prog M _ bsNumBranch _ _
    have h603 : prog[Idx.adaNumerical]? = some body_adaNumerical :=
      hW4.numTbl (Idx.adaNumerical, body_adaNumerical) (by simp [adaNumTable])
    have hargs : EvalsVal prog M [encVals vals, adaPubEnc A, inp] []
        (.inl (eList [eV 1, eAtN 1 (eAtN 1 (eV 2)), eV 0]))
        (Val.list [adaPubEnc A, adaEnc st, encVals vals]) := by
      refine evalsVal_list (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons (hS rfl rfl)
        (List.Forall₂.cons (EvalsVal.var rfl) List.Forall₂.nil))) ?_
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    have hprep : NumPrepAt prog M A vals :=
      ⟨body_adaPrep, hW4.prepTbl (Idx.adaPrepR, body_adaPrep) (by simp [adaPrepTable]),
        fun _ f _ hok' hf hc => adaPrep_impl hW4.prepTbl hW4.mus hW4.samp hW4.list hbs hT hpos hok'
          hv f hf hc hMA⟩
    have hnumI := implementsO_call_det (orc := orc) (by decide) h603
      (EvalsValO.of_evalsVal hO hargs)
      (Implements.toO hO (adaNumerical_impl_of hprep hW4.mus hW4.samp hW4.list hq hbs hT hpos hok
        hv hMA))
    show ImplementsO orc prog M _ _ _ ((adaNumerical A st vals).bind _)
    refine bsM_letE_ofO hnumI (fun r => AdaOK A r.2 ∧ valSize (encNum r.1) ≤ adaBoundA A)
      (fun bits r h => ⟨Always.of_run (adaNumerical_ok hok vals) h,
        Always.of_run (adaNumerical_num_le A st vals) h⟩) ?_
    rintro ⟨x, st'⟩ ⟨hok', hxB⟩
    dsimp only at hok' hxB
    apply ImplementsO.of_det
    have hst'B := valSize_adaEnc_le hok'
    have hrM : valSize (Val.list [encNum x, adaEnc st']) ≤ M := by
      simp only [valSize_list, listSize_cons, listSize_nil] at hxB ⊢
      omega
    have hresp : valSize (bsResp (Sum.inr x)) ≤ valSize (encNum x) + 12 := by
      cases x with
      | val μ =>
        simp only [bsResp, encNum, encQ, encInts, List.map_cons, List.map_nil, valSize_list,
          listSize_cons, listSize_nil, valSize_int]
        have : bitLen (3 : ℤ) = 2 := by decide
        omega
      | abort => decide
    refine EvalsValO.of_evalsVal hO ?_
    show EvalsVal prog M _ [] _ (Val.list [Val.list [blocksV, adaEnc st'], bsResp (Sum.inr x)])
    refine EvalsVal.pair (EvalsVal.pair (hS rfl rfl) (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) ?_)
      (bsM_numResp (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) (by omega) (by omega) h16) ?_
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega

end Tail

end F2e2e.BSpace
