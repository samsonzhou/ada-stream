import F2e2e.BSpace.O2GlueMainDefs

/-!
# B_space, route O2b: the ADA callees of the top frame of the round program (o2m)

Owner: A-ARCH (a99d156c), for C-BANK's top-frame assembly (P5, `O2GlueMain.lean`) and the O2b technical lead
17fc0802. The callee predicates `O2mNumAt` (603) and `O2mIvAt` (602) of `F2e2e/BSpace/O2GlueMainDefs.lean`
discharged from the uniform C-side specs (the judgment `Implements` at a frame bound `M`) by O2B-GST's weighted
lifting `Implements.toF_wt` (`F2e2e/BSpace/O2GstLift.lean`): the callee runs in its own frame `(M, C · M)`, `C` a
weight bound of its callees. With a weight certificate `hW : WeightOK prog w` (on `bsRoundProg`: `bsWeightOK_round`,
`w(603) = 240`) the choice `C = w i − (exprDepth body + 3)` makes the call cost at most `w i · M` in the caller's
budget (`o2m_numAt_wt`, `o2m_ivAt_wt`; for 603: `33 M + 206 M ≤ 240 M`).

The specs enter as hypotheses (`hspec`): at the end they are the tight `_t` specs of the ADA families 7 and 5
(`adaNumerical_impl_of_t`, `adaInterval_impl_t`, scratch `F2e2e/Scratch/O2T/`, swapped into `F2e2e/C/Impl` after the
stage-1 cut), so that no O2 module imports a scratch module. Their input-size premises follow from the tight value
premise `TightM A M` (`F2e2e/C/Impl/AdaBounds.lean`): `o2m_numIn_le_of_tight`, `o2m_ivIn_le_of_tight`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## Input sizes under the tight value premise -/

/-- The tight scale: `2^8 · tightA A ≤ M` and `512 ≤ tightA A`. -/
theorem o2m_tight_scale {A : AdaParams} {M : ℕ} (hMt : TightM A M) :
    2 ^ 8 * tightA A ≤ M ∧ 512 ≤ tightA A := by
  have h32 := thirtytwo_le_tightA A
  unfold TightM at hMt
  constructor <;> omega

/-- **The input `[pub, st, vals]` of `adaNumerical` is below a tight value bound.** -/
theorem o2m_numIn_le_of_tight {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {M : ℕ} (hMt : TightM A M) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M := by
  obtain ⟨hM, h512⟩ := o2m_tight_scale hMt
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hvB := valSize_encVals_le_t hbs hv.1 hv.2
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- The size of an encoded rational whose numerator and denominator have bit lengths `≤ B`. -/
theorem o2m_valSize_encQ_le {q : ℚ} {B : ℕ} (h : bitLen q.num ≤ B ∧ bitLen (q.den : ℤ) ≤ B) :
    valSize (encQ q) ≤ 2 * B + 5 := by
  rw [valSize_encQ]
  obtain ⟨h1, h2⟩ := h
  unfold bitLen at h1 h2
  rw [Int.natAbs_natCast] at h2
  omega

/-- **The input `[pub, st, vals, l, u]` of `adaInterval` is below a tight value bound** (under the endpoint
premises of `adaInterval_impl_t`). -/
theorem o2m_ivIn_le_of_tight {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ} (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq)
    (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq) {M : ℕ} (hMt : TightM A M)
    (hMq : 2 ^ 28 * Bq ≤ M) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ M := by
  obtain ⟨hM, h512⟩ := o2m_tight_scale hMt
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hvB := valSize_encVals_le_t hbs hv.1 hv.2
  have hlB := o2m_valSize_encQ_le hl
  have huB := o2m_valSize_encQ_le hu
  have hB8 : 8 * Bq ≤ M := le_trans (Nat.mul_le_mul_right Bq (by norm_num)) hMq
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-! ## The callee predicates from the uniform specs -/

section Lift

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ}

/-- **`adaNumerical` (603) in its own frame `(M, C · M)`** from its uniform spec at the frame bound `M`
(`C` bounds the weights of the callees of `body_adaNumerical`). -/
theorem o2m_numAt_of_lift (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (h603 : prog[Idx.adaNumerical]? = some body_adaNumerical) {M : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)}
    (hspec : Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals))
    (hin : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M) {C : ℕ}
    (hc : CalleesLe w C body_adaNumerical) :
    O2mNumAt orc prog M (C * M) A st vals :=
  ⟨h603, hin, Implements.toF_wt hO hW hspec (fun x hx => by rw [List.mem_singleton.mp hx]; exact hin) hc⟩

/-- **`adaInterval` (602) in its own frame `(M, C · M)`** from its uniform spec at the frame bound `M`. -/
theorem o2m_ivAt_of_lift (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (h602 : prog[Idx.adaInterval]? = some body_adaInterval) {M : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)} {l u : ℚ}
    (hspec : Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u))
    (hin : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ M) {C : ℕ}
    (hc : CalleesLe w C body_adaInterval) :
    O2mIvAt orc prog M (C * M) A st vals l u :=
  ⟨h602, hin, Implements.toF_wt hO hW hspec (fun x hx => by rw [List.mem_singleton.mp hx]; exact hin) hc⟩

/-- **`adaNumerical` at its weight**: in the frame `(M, (w 603 − (exprDepth body + 3)) · M)` given by the weight
certificate, and the call costs at most `w 603 · M` in the caller's budget (the premise
`(exprDepth body_adaNumerical + 2) · mN + τN ≤ τ` of P2, `o2m_numF`). -/
theorem o2m_numAt_wt (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (h603 : prog[Idx.adaNumerical]? = some body_adaNumerical) {M : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)}
    (hspec : Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals))
    (hin : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M) :
    O2mNumAt orc prog M ((w Idx.adaNumerical - (exprDepth body_adaNumerical + 3)) * M) A st vals ∧
      (exprDepth body_adaNumerical + 2) * M +
        (w Idx.adaNumerical - (exprDepth body_adaNumerical + 3)) * M ≤ w Idx.adaNumerical * M := by
  obtain ⟨hd, hc⟩ := hW _ _ h603
  exact ⟨o2m_numAt_of_lift hO hW h603 hspec hin hc, callCost_wt_le hd⟩

/-- **`adaInterval` at its weight**: in the frame `(M, (w 602 − (exprDepth body + 3)) · M)`; the call costs at
most `w 602 · M` in the caller's budget. -/
theorem o2m_ivAt_wt (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (h602 : prog[Idx.adaInterval]? = some body_adaInterval) {M : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)} {l u : ℚ}
    (hspec : Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u))
    (hin : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ M) :
    O2mIvAt orc prog M ((w Idx.adaInterval - (exprDepth body_adaInterval + 3)) * M) A st vals l u ∧
      (exprDepth body_adaInterval + 2) * M +
        (w Idx.adaInterval - (exprDepth body_adaInterval + 3)) * M ≤ w Idx.adaInterval * M := by
  obtain ⟨hd, hc⟩ := hW _ _ h602
  exact ⟨o2m_ivAt_of_lift hO hW h602 hspec hin hc, callCost_wt_le hd⟩

end Lift

end F2e2e.BSpace
