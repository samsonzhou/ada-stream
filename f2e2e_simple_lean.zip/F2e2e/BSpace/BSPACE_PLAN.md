# B_space (Theorem_B_space): DAG, contracts, assignments

Area lead: W4 (cc77ceaa). Status: PLAN v1, 2026-10-25 13:40Z; status table updated 13:36Z (below).

## Status (15:34Z): BOTH MILESTONES DONE, ON SPEC v3.1 (+F1 `alg2RetainedOf`, interim sha `2c702709…`)

15:34Z: SpecDefs regenerated from the interim SpecV31 (F1: the history clause's reference state is `alg2RetainedOf`,
`G` zeroed outside `j < p, i < n_j`; plus m1/m2/m4); C-TOP's `reproducesFor_of` factors through B-ARCH's retained lemma;
all four finals rebuilt, 0 sorry, axioms clean (O2 files unchanged: same generic interface).

Spec v3.1 (plan of record; SpecV31.lean sha `2f4f3c09…`, fixes FA + B1 + B2): `SpecDefs.lean` regenerated 14:50Z (W4);
the four finals below prove the v3.1 statements (OracleFor-generic `ReproducesFor`, history-free states with `enc`),
0 sorry, axioms [propext, Classical.choice, Quot.sound] (O1: C-TOP 14:55Z; O2b: W4 14:56Z). The generic v3.1 assembly
(`theorem_B_space_with_of` / `theorem_B_joint_with_of` with `hR : V31RoundRunsW`, `oracleFor_agrees`, threaded
states, `enc := stEnc blocks ∘ archOf`) is C-TOP's `Assemble.lean`; the O2b request frame for every agreeing oracle
is `V31O2Round.lean` (`v31o2_implR_agree`). The V31* files (V31DslReq, V31HistFree, V31Thread, V31Assemble, V31O2Round)
are part of the real chain.

| milestone | theorem | file | state |
|---|---|---|---|
| O1 (2^128, staged) | `F2e2e.BSpace.theorem_B_space_2e128_proof : BSpace.Theorem_B_space_with 128`, `theorem_B_joint_2e128_proof : BSpace.Theorem_B_joint_with 128` (generic `theorem_B_space_of_le`, e ≥ 107) | AssembleFinal.lean (C-TOP) | 0 sorry, axioms [propext, Classical.choice, Quot.sound] (13:59Z) |
| O2b (paper's 2^30) | `F2e2e.BSpace.theorem_B_space_proof : F2e2e.Theorem_B_space`, `theorem_B_joint_proof : F2e2e.Theorem_B_joint` | O2Assemble.lean + O2AssembleFinal.lean (W4) | 0 sorry, axioms [propext, Classical.choice, Quot.sound] (14:38Z) |

O1 chain: SpecDefs (W4) · M1–M3/M* (C-SPACE, 17fc0802) · bsC calculus (DSL-CALC) · P (W2, W3) · D1 (W3), D2 (1beb339b, W5),
D3 (W5), D4 (W2), D4-req (W3), D5 (NEW-B) · R1–R4 (B-ARCH, B-ACC) · S1 (B-ACC), S2/S3 (B-ARCH) · T1 (C-TOP).

O2b chain (tech lead 17fc0802): spike (W4: true c₁ ≈ 2^5.6) · additive bridge (17fc0802) · per-call GST + lifting
(C-SPACE, O2B-GST) · tight families in C/Impl (B1: AdaBounds/AdaInit/AdaValid/AdaEntryReject, append-only, W4) and promoted
O2T deltas (A-VAL et al.) · tight sizes (B-ACC, O2B-SIZE) · top frames (e26ae4ae init, C-BANK round, C-TREE callees) ·
finals (C-PROB finI, B-ACC finR) · assembly `O2Inputs` (W4).


## What W4 already provides (all 0 sorry, axiom-clean; `F2e2e/C/Impl/`)

All of these are generic in `A : AdaParams`. They hold for every `A` with `hbs : A.blockSizes.length = A.p+1`,
`hT : A.Tmax.length = A.p`, `hpos : ∀ j ≤ A.p, 0 < A.blockSizes.getD j 0`, `AdaOK A st`, `ValsOKA A vals`, and
`hM : 2^32 * adaBoundA A ≤ M`.

| routine | spec | file |
|---|---|---|
| `adaInit` 601 | `Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A)` | AdaInit.lean `adaInit_impl` |
| `adaInterval` 602 | on `[adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]` ↦ `[encCert c, adaEnc st']`, implements `adaInterval A st vals l u` (needs `bitLen l.num, l.den, … ≤ Bq`, `2^28·Bq ≤ M`) | AdaEntry.lean `adaInterval_impl` |
| `adaNumerical` 603 | on `[adaPubEnc A, adaEnc st, encVals vals]` ↦ `[encNum r, adaEnc st']` | AdaEntryNum.lean `adaNumerical_impl_of` (+ `NumPrepAt` from AdaPrep.lean `adaPrep_impl`) |
| parameter record 600 | `adaPub_core`: from five `EvalsVal` facts `encStreamParams P ↦ eA, eXi, M, J, R` it gives `adaPubEnc (adaParams eA eXi M J R)` (needs `2^37·L³ ≤ M`, `eA ≤ 6L`, …) | AdaPubCore.lean (W2) |
| tables | `w4AllTable` (601, 602–608, 610–640, 650–657, 700–707, libraries), `W4Lib`, lookup lemmas | AdaContract.lean |

**Reuse facts.**
- `encVParams M J R aReq ξReq = encInts [M, J, R, eA, eXi]` has the same shape as
  `encStreamParams ⟨M, J, R, eA, eXi⟩`. So `body_adaPub` computes the B parameter record when, in the B
  program, the five keys `Idx.peBankA/peBankXi/pbankM/pbankJ/pbankR` hold the field getters
  `eGet 3/4/0/1/2 (var 0)`.
- Both ArchCore and W4 enforce the caps (`nInt ≤ M`, `nNum ≤ R`, `rej ≤ J+1`; halted/over-cap gives `abort`,
  no bits, no state change). That is exactly the saturating behaviour needed for all rounds `t ∈ ℕ`.
- B-ARCH's Spec v2 bridge (`F2e2e/B/SpecV2Bridge*.lean`) relates `alg2Mech` and ArchCore:
  `parCorr_alg2`, `step_sim`, `fold_sim`, `v2_online`, `outRespV2`.

## What `Theorem_B_space` needs beyond W4

General parameters `(M, J, R, aReq, ξReq)` with `A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R`, and on
top of that:
- storing the `N` record codes, split into blocks;
- the evaluation loop through the oracle (grid index `(⌊2^{qA+1} f(x)⌋ + 1) div 2`);
- endpoints through the oracle (`l' = ⌊2^{qA+1} clip l⌋ / 2^{qA+1}`, so that
  `round_hA(clip l') = round_hA(clip l)`);
- the init and round programs, with the response encoding;
- the oracle machine bridge;
- the bit bound;
- refinement to `alg2Mech`;
- tape threading over all rounds;
- the top-level assembly.

## DAG

```
SpecDefs (W4, at §7)
  ├─ M1 EvalsValO + lifting (C-SPACE/17fc0802) ──┬─ D2 evals via oracle (1beb339b)
  │                                              ├─ D3 endpoints via oracle (W5)
  │                                              └─ D4 init/round bodies (W4) ── D5 tables/programs/rank (W4)
  ├─ M2 GST-O, M3 machine-O (C-SPACE/17fc0802) ── M* runsWithinBitsO_of_evalsValO
  ├─ P1 B parameter record (W2) ───────────────── D4
  ├─ P2 general-param structural facts (W2) ───── D4, S
  ├─ D1 records → blocks (W3) ─────────────────── D4
  ├─ R1–R3 refinement DSL-level ArchCore ≅ alg2Mech (B-ARCH + B-ACC)
  ├─ S1–S3 value bound M_B and final inequality (C-SPACE/17fc0802; S2 waits for the constant decision)
  └─ T1 Theorem_B_space from bsImpl (C-TOP) ← D5, M*, R3, S2
```

Indices: BSpace glue routines use keys **900–999** (all (C) keys are ≤ 899). In the B program, keys
`Idx.peBankA … pbankR` are re-bound to the five getters (P1). `ORACLE_IDX` must be a key outside every table
(ask the drafters for a key ≥ 1000), so that `prog[ORACLE_IDX]? = none` for `mkProg` programs.

## Contracts (provisional names; statements fixed once §7 is copied)

### M (C-SPACE 50da43f0 + 17fc0802): `F2e2e/BSpace/Machine*.lean`

- **M1** `EvalsValO (orc : ℤ → ℤ → ℤ → ℤ) (prog) (M) : List Val → List Bool → Expr ⊕ (ℕ × Val) → Val → Prop`.
  - It is `EvalsVal` (Cost/Generic.lean) with `call` restricted to `i ≠ ORACLE_IDX`, plus the rule
    `oracle (ha : EvalsValO … env ba (.inl a) (Val.list [Val.int sel, Val.int r, Val.int q]))
    (hM : valSize (Val.int (orc sel r q)) ≤ M) : EvalsValO … env ba (.inl (Expr.call ORACLE_IDX a))
    (Val.int (orc sel r q))`.
  - Lifting lemma `EvalsValO.of_evalsVal (hO : prog[ORACLE_IDX]? = none) : EvalsVal prog M env bits t v →
    EvalsValO orc prog M env bits t v`.
  - `ImplementsO` (the same as `Implements`, with `EvalsValO`) and `Implements.toO (hO)`.
  - The basic rules: `var/lit/letE/ite/call/loop_of_measure/pair` (DSL-CALC can help).
  - **Deliver M1 first (target 14:30Z): D2, D3 and D4 depend on it.**
- **M2** GST for `EvalsValO` (oracle copy of `gst_aux` / `EvalsSpT` / `RunsOn` with the unread tape exposed).
- **M3** the machine bridge for `stepO` (oracle copy of `MachineSim*` / `MachineBridge` /
  `runsWithinBitsW_of_runsOn`).
- **M\*** `runsWithinBitsO_of_evalsValO (hR : RankOK prog r K) (h0 : prog[0]? = some body)
  (h : EvalsValO orc prog M [input] bits (.inl body) out) (hin : valSize input ≤ M) :
  RunsWithinBitsO prog orc input (bits ++ rest) out rest (bsMachineBound prog r K M (valSize input))`,
  with an explicit `bsMachineBound` (as in `SpaceChain`: `(bridgeWC+2)·(bitsFactor·(|input| +
  ((r 0+1)(K+3)+1)·M) + bitsConst) + bridgeWC'`).

### P (W2 a2ff64c3): `F2e2e/BSpace/Pub.lean`

- **P1** `bsPubTable` = the five getters at `Idx.peBankA, peBankXi, pbankM, pbankJ, pbankR` ++ `adaPubTable`
  ++ normQ's table (from W5).
  - `bsPub_eval (hlib : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) (hM : bsPubBound Mc J R eA eXi ≤ M) :
    EvalsVal prog M [encInts [Mc, J, R, eA, eXi]] [] (.inl body_adaPub)
      (adaPubEnc (adaParams eA eXi Mc J R)) ∧ valSize (adaPubEnc (adaParams eA eXi Mc J R)) ≤ M`.
  - `bsPubBound` is explicit (W2 chooses it, e.g. `2^37·L³` with an explicit `L(Mc,J,R,eA,eXi)`).
- **P2** for every `eA ≥ 4`, `eXi ≥ 1`:
  - `(adaParams eA eXi M J R).blockSizes.length = p + 1`;
  - `Tmax.length = p`;
  - `∀ j ≤ p, 0 < blockSizes.getD j 0` (generalizing A-ARCH's `bankAda_blockSizes_pos`).

### D (W4 lead; W3 4a7299ed, 1beb339b, W5 c1b4f720): `F2e2e/BSpace/Dsl*.lean`

- **D1** (W3) `bsBlocks` (key 900, + steps 901–903).
  - Input `[encL encN A.blockSizes, encInts codes]` with `codes.length = A.N`; output
    `Val.list ((blocksOf A.blockSizes codes).map encInts)`.
  - `blocksOf ns l` = consecutive sublists of lengths `ns`: `blocksOf [] l = []`,
    `blocksOf (n :: ns) l = l.take n :: blocksOf ns (l.drop n)`.
  - Deterministic `EvalsVal` spec, values `≤ M` given `valSize (encInts codes) + … ≤ M`.
- **D2** (1beb339b) `bsEvals` (keys 910–915).
  - Input `[encN qA, blocks]`; output `encVals (evalsOf orc qA blocks)` with
    `evalsOf orc q bs = bs.map (·.map fun r => ((orc 0 r (q+1) + 1) / 2).toNat)`.
  - `EvalsValO` spec, with the hypothesis `∀ r ∈ blocks, 0 ≤ orc 0 r (q+1) ≤ 2^(q+1)` (so every value is
    `≤ 2^q`).
  - Math lemma: for `orc = reqOracle code req`, a valid `req` and `h_A = 2^{-q}`,
    `((orc 0 (code x) (q+1) + 1)/2) = roundIdx`, i.e. `h_A·that = roundGridQ h_A (f x)` (cf.
    `roundGrid_index_eq_trunc`).
- **D3** (W5) `bsEnds` (keys 920–925).
  - Input `[encN qA]`; output `[encQ l', encQ u']`, `l' = (orc 1 0 (qA+1) : ℚ) / 2^(qA+1)` (canonical, via
    `normQ`).
  - Math lemma: `roundIdxQ h_A (clipQ (-1) 2 l') = ⌊clip(l)/h_A + 1/2⌋` for the real `l` (the ArchCore
    rounding of `l'` equals alg2's rounding of `l`), together with the bit bounds of `l'` needed by
    `adaInterval_impl` (`Bq = qA + 4`).
- **D4** (W4) `body_bsInit`, `body_bsRound`.
  - **State** `bsStateEnc blocks st = Val.list [Val.list (blocks.map encInts), adaEnc st]`.
  - **Init**: `[params, records] ↦ bsStateEnc (blocksOf A.blockSizes codes) st0`. It calls `adaPub`,
    `bsBlocks` and `adaInit`. `ImplementsO orc prog M [Val.list [encVParams…, encRecords code s]]
    body_bsInit (bsStateEnc blocks) (adaInit A)`.
  - **Round**: `[params, state, kind] ↦ [state', resp]`. It calls `adaPub`, `bsEvals` (oracle), then for
    interval `bsEnds` and `adaInterval`, else `adaNumerical`.
  - Response encoding `bsResp`: cert `accept/abort ↦ [0]`, `high/termHigh ↦ [1]`, `low/termLow ↦ [2]`;
    num `val μ ↦ [3, μ.num, μ.den]`, `abort ↦ [3, 0, 1]`.
  - Spec: `ImplementsO (reqOracle code req) prog M [Val.list [params, bsStateEnc blocks st, kind]]
    body_bsRound (fun r => Val.list [bsStateEnc blocks r.2, bsResp r.1])
    (bsCoreRound A st (evalsOf …) l' u' kind)`, where `bsCoreRound` = `adaInterval`/`adaNumerical` mapped
    into a sum type.
- **D5** (W4) `bsTable` (W4's `w4AllTable` ++ `bsPubTable` ++ D1–D3 entries ++ normQ), `bsInitProg`,
  `bsRoundProg` (`mkProg`), `BsLib (mkProg …)`, the rank certificate (kernel-computed, as C-SPACE's
  `AsmRank`), and `prog[ORACLE_IDX]? = none`.

### R (B-ARCH dc387564 + B-ACC 6f8aab0c): `F2e2e/BSpace/Refine*.lean`

- **R1** round conformance. If the ArchCore round
  `(bsCoreRound A st (evalsOf (reqOracle code (reqs t)) qA blocks) l' u' kind).run tape = some (out, tape')`,
  with `ParCorr (alg2Params …) A` and the state relation of `SpecV2BridgeExec`, then
  `alg2Request (alg2Params …) st2 (viewsOf s reqs t) tape = (respOf out, st2', tape')` and the relation is
  preserved. This needs D2/D3's math lemmas: the oracle grid indices equal `alg2Evals`, and the endpoints
  round alike.
- **R2** init conformance (`adaInit A` vs `alg2Init`).
- **R3** the fold over rounds: `alg2Mech M J R aReq ξReq c t (viewsOf s reqs t) ω = respOf (out t)` for the
  DSL run's outputs.
- **R4** no exhaustion (if the Spec quantifies `c ≥ cB`): every BitProg run on the threaded tape succeeds.
  - Total bits are at most `adaInitBits A + (M+R)·adaCallBits A`, since only the first `M+R` effective
    requests read bits.
  - Uses B-ARCH's `adaInit_depth_le` / `adaInterval_depth_le` / `adaNumerical_depth_le`.

### S (C-SPACE 50da43f0 + 17fc0802): `F2e2e/BSpace/Bound*.lean`

- **S1** value bound: one explicit `M_B(M,J,R,eA,eXi,b_𝒰) ≥ max(2^32·adaBoundA A, bsPubBound, valSize of the
  B state and inputs)`, valid for D4's derivations.
- **S3** relations:
  - `(alg2Params …).N = A.N` (B-ARCH `ParCorr.hn` / `hblen`);
  - `valChi` vs `adaChi`;
  - `adaZ A ≤ c·χ` (analog of `SpaceAdaBound.adaZ_le`, from B-NUM's NumericsSize);
  - `valSize (encRecords code s) ≤ N·(b_𝒰+2)+1`.
- **S2** `bsMachineBound bsProg rB KB M_B (|input|) ≤ bSpaceBound N b_𝒰 χ` (waits for the constant decision).

### T (C-TOP 95aff426): `F2e2e/BSpace/Assemble.lean`

- **T1** `theorem_B_space : Theorem_B_space` (copy in SpecDefs until the lock), with
  `impl := ⟨bsInitProg, bsRoundProg⟩`.
  - Build `states t` and `tapes t` by recursion on `t`.
  - Init: M\* + D4 init.
  - Round t: M\* + D4 round; `parseVResponse (bsResp …) = some (alg2Mech … t …)` by R3.
  - Bound: S2.
