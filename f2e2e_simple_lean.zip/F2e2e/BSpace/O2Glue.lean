import F2e2e.BSpace.O2GlueLift
import F2e2e.BSpace.DslEnds

/-!
# B_space, route O2b (iii): native per-call specs of D3 `bsEnds` and of `normQ`

Owner: W5 (c1b4f720), for the O2b tech lead 17fc0802; consumer O2B-GST (8cf19cc0) and the top-frame
authors of `bsRound`. Prefix `o2g`. Statements approved by 17fc0802 (14:05Z). The O1 versions
(`F2e2e/BSpace/DslEnds.lean`, `F2e2e/C/Impl/BankArith.lean`, `F2e2e/Cost/Arith/Basic.lean`) are unchanged;
this file only adds per-call statements in C-SPACE's judgment `EvalsValF orc prog m τ …`
(`F2e2e/BSpace/O2GstF.lean`).

Shape (O2B-GST's): `∀ m τ, B_f ≤ m → T_f ≤ τ → EvalsValF orc prog m τ [x] [] (.inl body_f) out`, where `B_f`
is the largest value live in the routine's own frame and `T_f` the budget of its callees (each callee at
its OWN `(m', τ')`: `T_f ≥ (exprDepth body' + 2) m' + τ'`; a loop frame costs `(exprDepth body' + 3) m'`).
A caller pays `(exprDepth body_f + 2) B_f + T_f` (`o2g_depth_*` give the depths).

* `normQ` (766; Euclid's loop 767, call-free body of depth 9): `B = 2 (bitLen a + bitLen b) + 64` (its
  O1 bound), `T = 12 · B` (the loop frame at `B`). Proof: the O1 `normQ_val` lifted by `o2g_toF_cfl`.
* `pow2` (ARITH 100; loop 101, call-free body of depth 9): `B = S_pow2 k`, `T = 12 · B` (the callee of
  `bsEnds`). Proof: ARITH's `pow2_spec` (reverse bridge `toVal`) lifted by `o2g_toF_cfl`.
* `bsEnds` (920, depth 12): `B = 4 qA + 32` (the largest value of its frame is the result
  `[encQ l', encQ u']`, `≤ 4 qA + 29`), `T = max (18 · S_pow2 qA) (22 · (4 qA + 74))` (the `pow2` call:
  `(4 + 2) S_pow2 qA + 12 S_pow2 qA`; the two `normQ` calls at `m' = 4 qA + 74`: `(8 + 2) m' + 12 m'`).
  Proof: a native `EvalsValF` derivation (the call rule with the callees at their own bounds).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/-! ## Budgets -/

/-- Frame bound of `normQ` on `[a, b]` (its O1 value bound). -/
def o2gB_normQ (a b : ℤ) : ℕ := 2 * (bitLen a + bitLen b) + 64

/-- Callee budget of `normQ`: Euclid's loop frame (call-free body of depth `9`) at the frame bound. -/
def o2gT_normQ (a b : ℤ) : ℕ := 12 * o2gB_normQ a b

/-- Frame bound of `pow2` on `k` (ARITH's space bound `S_pow2`). -/
def o2gB_pow2 (k : ℕ) : ℕ := Cost.S_pow2 k

/-- Callee budget of `pow2`: its loop frame (call-free body of depth `9`) at the frame bound. -/
def o2gT_pow2 (k : ℕ) : ℕ := 12 * Cost.S_pow2 k

/-- Frame bound of `bsEnds` on `[qA]`. -/
def o2gB_ends (qA : ℕ) : ℕ := 4 * qA + 32

/-- Callee budget of `bsEnds`: the `pow2` call at `(S_pow2 qA, 12 S_pow2 qA)` and the two `normQ` calls at
`(4 qA + 74, 12 (4 qA + 74))`. -/
def o2gT_ends (qA : ℕ) : ℕ := max (18 * Cost.S_pow2 qA) (22 * (4 * qA + 74))

/-! ## Depths (for the callers' `(exprDepth body + 2) m' + τ'`) -/

theorem o2g_depth_normQ : exprDepth BankDSL.body_normQ = 8 := rfl

theorem o2g_depth_gcdStep : exprDepth BankDSL.body_bkGcdStep = 9 := rfl

theorem o2g_depth_pow2 : exprDepth Cost.body_pow2 = 4 := rfl

theorem o2g_depth_pow2Step : exprDepth Cost.body_pow2Step = 9 := rfl

theorem o2g_depth_ends : exprDepth body_bsEnds = 12 := rfl

/-! ## `normQ` -/

/-- **`normQ`, per call**: `[a, b] ↦ encQ (a / b)` for `b > 0`, at its own frame bound and budget. -/
theorem o2g_normQ {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hq : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2) (hnone : prog[bsOracleIdx]? = none)
    (a b : ℤ) (hb : 0 < b) :
    ∀ m τ, o2gB_normQ a b ≤ m → o2gT_normQ a b ≤ τ →
      EvalsValF orc prog m τ [Val.list [Val.int a, Val.int b]] [] (.inl BankDSL.body_normQ)
        (encQ ((a : ℚ) / (b : ℚ))) := by
  intro m τ hm hτ
  have hstep : prog[C.Impl.Idx.bkGcdStep]? = some BankDSL.body_bkGcdStep :=
    hq _ (List.mem_cons_of_mem _ List.mem_cons_self)
  have h := BankDSL.normQ_val (M := o2gB_normQ a b) hstep a b hb le_rfl
  have henv : ∀ x ∈ [Val.list [Val.int a, Val.int b]], valSize x ≤ o2gB_normQ a b := by
    intro x hx
    rw [List.mem_singleton] at hx
    subst hx
    simp only [o2gB_normQ, valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hL : ∀ j ∈ [C.Impl.Idx.bkGcdStep], ∀ body, prog[j]? = some body →
      CallFree body ∧ exprDepth body + 3 ≤ 12 := by
    intro j hj body hbody
    rw [List.mem_singleton] at hj
    subst hj
    rw [hstep] at hbody
    cases hbody
    exact ⟨(callFreeB_iff _).mp (by decide), by decide⟩
  have hc : o2gCFL prog 12 BankDSL.body_normQ := o2gCFL_of_B hL _ (by decide)
  exact ((EvalsVal.o2g_toF_cfl (orc := orc) hnone h henv hc (τ := o2gT_normQ a b) le_rfl).mono_m
    hm).mono_τ hτ

/-! ## `pow2` -/

/-- **`pow2`, per call**: `k ↦ 2^k` at its own frame bound and budget. -/
theorem o2g_pow2 {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hpowS : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step) (hnone : prog[bsOracleIdx]? = none)
    (k : ℕ) :
    ∀ m τ, o2gB_pow2 k ≤ m → o2gT_pow2 k ≤ τ →
      EvalsValF orc prog m τ [encN k] [] (.inl Cost.body_pow2) (encN (2 ^ k)) := by
  intro m τ hm hτ
  have h : EvalsVal prog (o2gB_pow2 k) [encN k] [] (.inl Cost.body_pow2) (encN (2 ^ k)) :=
    (Cost.pow2_spec hpowS k 0).toVal
  have henv : ∀ x ∈ [encN k], valSize x ≤ o2gB_pow2 k := by
    intro x hx
    rw [List.mem_singleton] at hx
    subst hx
    have hs : Nat.size k ≤ k := size_le_self k
    rw [valSize_encN]
    simp only [o2gB_pow2, Cost.S_pow2]
    omega
  have hL : ∀ j ∈ [Cost.Idx.pow2Step], ∀ body, prog[j]? = some body →
      CallFree body ∧ exprDepth body + 3 ≤ 12 := by
    intro j hj body hbody
    rw [List.mem_singleton] at hj
    subst hj
    rw [hpowS] at hbody
    cases hbody
    exact ⟨(callFreeB_iff _).mp (by decide), by decide⟩
  have hc : o2gCFL prog 12 Cost.body_pow2 := o2gCFL_of_B hL _ (by decide)
  exact ((EvalsVal.o2g_toF_cfl (orc := orc) hnone h henv hc (τ := o2gT_pow2 k) le_rfl).mono_m
    hm).mono_τ hτ

/-! ## Deterministic `EvalsValF` rules (no fresh bits) -/

section rulesF

open F2e2e.Cost.HashDSL

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}

theorem o2gF_let {a b : Expr} {va vb : Val} (ha : EvalsValF orc prog m τ env [] (.inl a) va)
    (hb : EvalsValF orc prog m τ (va :: env) [] (.inl b) vb) :
    EvalsValF orc prog m τ env [] (.inl (eLet a b)) vb :=
  EvalsValF.letE ha hb

theorem o2gF_hd {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list (x :: l)) ≤ m) : EvalsValF orc prog m τ env [] (.inl (eHd a)) x :=
  EvalsValF.head ha ((BankDSL.valSize_head_le' x l).trans hM)

theorem o2gF_add {a b : Expr} {x y : ℤ} (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.int x))
    (hb : EvalsValF orc prog m τ env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (eAdd a b)) (Val.int (x + y)) :=
  EvalsValF.bin ha hb rfl hM

theorem o2gF_div {a b : Expr} {x y : ℤ} (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.int x))
    (hb : EvalsValF orc prog m τ env [] (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (eDiv a b)) (Val.int (x / y)) :=
  EvalsValF.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem o2gF_cons {a b : Expr} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env [] (.inl a) x)
    (hb : EvalsValF orc prog m τ env [] (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (eCons a b)) (Val.list (x :: l)) :=
  EvalsValF.cons ha hb hM

theorem o2gF_list :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsValF orc prog m τ env [] (.inl e) v) es vs →
        valSize (Val.list vs) ≤ m → EvalsValF orc prog m τ env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsValF.nil hM
  | _ :: _, v :: vs, List.Forall₂.cons he hrest, hM =>
    o2gF_cons he (o2gF_list hrest ((BankDSL.valSize_tail_le' v vs).trans hM)) hM

theorem o2gF_pair {a b : Expr} {x y : Val} (ha : EvalsValF orc prog m τ env [] (.inl a) x)
    (hb : EvalsValF orc prog m τ env [] (.inl b) y) (hM : valSize (Val.list [x, y]) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (ePair a b)) (Val.list [x, y]) :=
  EvalsValF.pair ha hb hM

end rulesF

/-! ## `bsEnds` -/

/-- **`bsEnds`, per call** (key 920) with the evaluation oracle `orc`: on `[qA]` it returns the two
endpoints `bsN_end qA (orc 1 0 (qA+1))`, `bsN_end qA (orc 2 0 (qA+1))`, in a frame of bound `4 qA + 32`,
its callees (`pow2`, `normQ`) at their own bounds. -/
theorem o2g_ends (orc : ℤ → ℤ → ℤ → ℤ) {prog : List Expr} (qA : ℕ)
    (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2)
    (hnone : prog[bsOracleIdx]? = none)
    (hO : |orc 1 0 (qA + 1)| ≤ 2 ^ (qA + 2) ∧ |orc 2 0 (qA + 1)| ≤ 2 ^ (qA + 2)) :
    ∀ m τ, o2gB_ends qA ≤ m → o2gT_ends qA ≤ τ →
      EvalsValF orc prog m τ [Val.list [encN qA]] [] (.inl body_bsEnds)
        (Val.list [encQ (bsN_end qA (orc 1 0 (qA + 1))), encQ (bsN_end qA (orc 2 0 (qA + 1)))]) := by
  intro M τ hM0 hτ0
  have hM : 4 * qA + 32 ≤ M := hM0
  have hτp : 18 * Cost.S_pow2 qA ≤ τ := (le_max_left _ _).trans hτ0
  have hτn : 22 * (4 * qA + 74) ≤ τ := (le_max_right _ _).trans hτ0
  clear hM0 hτ0
  have hpow : prog[Cost.Idx.pow2]? = some Cost.body_pow2 :=
    hlib _ (List.mem_cons_of_mem _ List.mem_cons_self)
  have hpowS : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step :=
    hlib _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))
  have hnq : prog[C.Impl.Idx.normQ]? = some BankDSL.body_normQ := hq _ List.mem_cons_self
  -- the callees at their own bounds
  have hP := o2g_pow2 (orc := orc) hpowS hnone qA (o2gB_pow2 qA) (o2gT_pow2 qA) le_rfl le_rfl
  have hTp : (exprDepth Cost.body_pow2 + 2) * o2gB_pow2 qA + o2gT_pow2 qA ≤ τ := by
    rw [o2g_depth_pow2]
    simp only [o2gB_pow2, o2gT_pow2]
    omega
  have hTn : (exprDepth BankDSL.body_normQ + 2) * (4 * qA + 74) + 12 * (4 * qA + 74) ≤ τ := by
    rw [o2g_depth_normQ, ← Nat.add_mul]
    exact hτn
  have hpb : bitLen (((2 ^ qA : ℕ) : ℤ)) = qA + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have h2pos : (0 : ℤ) < ((2 ^ qA : ℕ) : ℤ) := by positivity
  have hN : ∀ kl : ℤ, bitLen kl ≤ qA + 4 → EvalsValF orc prog (4 * qA + 74) (12 * (4 * qA + 74))
      [Val.list [Val.int kl, Val.int ((2 ^ qA : ℕ) : ℤ)]] [] (.inl BankDSL.body_normQ)
      (encQ ((kl : ℚ) / ((((2 ^ qA : ℕ) : ℤ)) : ℚ))) := by
    intro kl hkl
    have h1 : o2gB_normQ kl ((2 ^ qA : ℕ) : ℤ) ≤ 4 * qA + 74 := by
      simp only [o2gB_normQ]
      rw [hpb]
      omega
    exact o2g_normQ hq hnone kl _ h2pos _ _ h1 (Nat.mul_le_mul_left 12 h1)
  have hnqA : ∀ kl : ℤ, bitLen kl ≤ qA + 4 →
      valSize (Val.list [Val.int kl, encN (2 ^ qA)]) ≤ 4 * qA + 74 := by
    intro kl hkl
    simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]
    rw [hpb]
    omega
  have hnqM : ∀ kl : ℤ, bitLen kl ≤ qA + 4 → valSize (Val.list [Val.int kl, encN (2 ^ qA)]) ≤ M := by
    intro kl hkl
    simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]
    rw [hpb]
    omega
  clear hτp hτn hpowS hlib hq h2pos hpb
  -- the sizes in the frame
  obtain ⟨hOl, hOu⟩ := hO
  have hq1b : bitLen ((qA : ℤ) + 1) ≤ qA + 1 := by
    have := bitLen_natCast_le (qA + 1); push_cast at this; exact this
  have hsq : Nat.size qA ≤ qA := size_le_self qA
  have hnb : ∀ n : ℤ, |n| ≤ 2 ^ (qA + 2) →
      bitLen n ≤ qA + 3 ∧ bitLen (n + 1) ≤ qA + 4 ∧ bitLen ((n + 1) / 2) ≤ qA + 4 := by
    intro n hn
    have h3 : (2 : ℤ) ^ (qA + 2) < 2 ^ (qA + 3) := pow_lt_pow_right₀ (by norm_num) (by omega)
    have h4 : (2 : ℤ) ^ (qA + 3) < 2 ^ (qA + 4) := pow_lt_pow_right₀ (by norm_num) (by omega)
    have e1 : bitLen n ≤ qA + 3 := bitLen_le_of_abs_lt (by linarith)
    have e2 : bitLen (n + 1) ≤ qA + 4 := by
      apply bitLen_le_of_abs_lt
      have := abs_add_le n 1
      simp only [abs_one] at this
      linarith
    exact ⟨e1, e2, (bitLen_ediv_le _ _).trans e2⟩
  obtain ⟨hl1, hl2, hl3⟩ := hnb _ hOl
  obtain ⟨hu1, hu2, hu3⟩ := hnb _ hOu
  have hEl := bsN_valSize_encQ_end qA _ hOl
  have hEu := bsN_valSize_encQ_end qA _ hOu
  rw [bsN_end_eq] at hEl hEu
  clear hnb hOl hOu
  have hI : valSize (Val.list [encN qA]) ≤ M := by
    have := bitLen_natCast_le qA
    simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]
    omega
  have hne100 : Cost.Idx.pow2 ≠ bsOracleIdx := by decide
  have hne766 : C.Impl.Idx.normQ ≠ bsOracleIdx := by decide
  have hv0 : valSize (Val.int 0) ≤ M := by rw [valSize_int, bitLen_zero]; omega
  have hv1 : valSize (Val.int 1) ≤ M := by rw [valSize_int, bitLen_one]; omega
  have hv2 : valSize (Val.int 2) ≤ M := by rw [valSize_int, bitLen_two_eq]; omega
  rw [bsN_end_eq, bsN_end_eq]
  unfold body_bsEnds
  refine o2gF_let (o2gF_hd (EvalsValF.var rfl) hI) ?_
  refine o2gF_let (evalsValF_call_det hne100 hpow (EvalsValF.var rfl) hP ?_ ?_ hTp) ?_
  · rw [valSize_encN]
    simp only [o2gB_pow2, Cost.S_pow2]
    omega
  · rw [valSize_encN, Nat.size_pow]
    omega
  refine o2gF_let (o2gF_add (EvalsValF.var rfl) (EvalsValF.lit hv1)
    (by simp only [valSize_int]; omega)) ?_
  refine o2gF_let (o2gF_div (o2gF_add (EvalsValF.oracle_det (o2gF_list (.cons (EvalsValF.lit hv1)
    (.cons (EvalsValF.lit hv0) (.cons (EvalsValF.var rfl) .nil)))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one, bitLen_zero]
        omega)) (by simp only [valSize_int]; omega)) (EvalsValF.lit hv1)
    (by simp only [valSize_int]; omega)) (EvalsValF.lit hv2) two_ne_zero
    (by simp only [valSize_int]; omega)) ?_
  refine o2gF_let (o2gF_div (o2gF_add (EvalsValF.oracle_det (o2gF_list (.cons (EvalsValF.lit hv2)
    (.cons (EvalsValF.lit hv0) (.cons (EvalsValF.var rfl) .nil)))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_eq,
          bitLen_zero]
        omega)) (by simp only [valSize_int]; omega)) (EvalsValF.lit hv1)
    (by simp only [valSize_int]; omega)) (EvalsValF.lit hv2) two_ne_zero
    (by simp only [valSize_int]; omega)) ?_
  refine o2gF_list (.cons (evalsValF_call_det hne766 hnq (o2gF_pair (EvalsValF.var rfl)
      (EvalsValF.var rfl) (hnqM _ hl3)) (hN _ hl3) (hnqA _ hl3) (by omega) hTn)
    (.cons (evalsValF_call_det hne766 hnq (o2gF_pair (EvalsValF.var rfl) (EvalsValF.var rfl)
      (hnqM _ hu3)) (hN _ hu3) (hnqA _ hu3) (by omega) hTn) .nil)) ?_
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **`bsEnds`, per call, on a request's oracle**: if the oracle answers the clipped endpoints of `r`
truncated to `qA + 1` digits, `bsEnds` returns `quantReq`'s endpoints. -/
theorem o2g_ends_quant (orc : ℤ → ℤ → ℤ → ℤ) {prog : List Expr} (P : AdaParams) {U : Type}
    (r : (U → ℝ) × Bool × ℝ × ℝ)
    (hl : orc 1 0 (P.qA + 1) = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 r.2.2.1)⌋)
    (hu : orc 2 0 (P.qA + 1) = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 r.2.2.2)⌋)
    (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2)
    (hnone : prog[bsOracleIdx]? = none) :
    ∀ m τ, o2gB_ends P.qA ≤ m → o2gT_ends P.qA ≤ τ →
      EvalsValF orc prog m τ [Val.list [encN P.qA]] [] (.inl body_bsEnds)
        (Val.list [encQ (quantReq P r).l, encQ (quantReq P r).u]) := by
  intro m τ hm hτ
  have hb : ∀ n : ℤ, ∀ x : ℝ, n = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 x)⌋ →
      |n| ≤ 2 ^ (P.qA + 2) := by
    intro n x hn
    rw [hn]
    exact bsN_trunc_abs_le P.qA x
  have h := o2g_ends orc P.qA hlib hq hnone ⟨hb _ _ hl, hb _ _ hu⟩ m τ hm hτ
  have el : bsN_end P.qA (orc 1 0 (P.qA + 1)) = (quantReq P r).l := by
    unfold bsN_end
    exact bsN_quant_eq P r.2.2.1 _ hl
  have eu : bsN_end P.qA (orc 2 0 (P.qA + 1)) = (quantReq P r).u := by
    unfold bsN_end
    exact bsN_quant_eq P r.2.2.2 _ hu
  rw [el, eu] at h
  exact h

/-- **`bsEnds`, per call, with a request's oracle** (Spec v3 §7's `reqOracle`): it returns `quantReq`'s
endpoints for `qA = P.qA`. -/
theorem o2g_ends_req {prog : List Expr} (P : AdaParams) {U : Type} (code : U → ℕ) (req : VReq U)
    (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2)
    (hnone : prog[bsOracleIdx]? = none) :
    ∀ m τ, o2gB_ends P.qA ≤ m → o2gT_ends P.qA ≤ τ →
      EvalsValF (reqOracle code req) prog m τ [Val.list [encN P.qA]] [] (.inl body_bsEnds)
        (Val.list [encQ (quantReq P req).l, encQ (quantReq P req).u]) := by
  have ht : ((P.qA : ℤ) + 1).toNat = P.qA + 1 := by omega
  have h10 : (1 : ℤ) ≠ 0 := by norm_num
  have h20 : (2 : ℤ) ≠ 0 := by norm_num
  have h21 : (2 : ℤ) ≠ 1 := by norm_num
  refine o2g_ends_quant (reqOracle code req) P req ?_ ?_ hlib hq hnone
  · show (if (1 : ℤ) = 0 then _ else if (1 : ℤ) = 1 then truncIdx ((P.qA : ℤ) + 1).toNat
        (max (-1) (min 2 req.2.2.1)) else _) = _
    rw [if_neg h10, if_pos rfl, ht]
    rfl
  · show (if (2 : ℤ) = 0 then _ else if (2 : ℤ) = 1 then _ else if (2 : ℤ) = 2 then
        truncIdx ((P.qA : ℤ) + 1).toNat (max (-1) (min 2 req.2.2.2)) else _) = _
    rw [if_neg h20, if_neg h21, if_pos rfl, ht]
    rfl

end F2e2e.BSpace
