import F2e2e.B.ArchBridge
import F2e2e.Spec

/-!
# B_space, D2 (math): the query table of a request through the evaluation oracle

Owner: 1beb339b (D2; area lead W4). Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §D (D2).

Algorithm 2 quantizes every query value `f(x) ∈ [0, 1]` to the grid `h_A ℤ`, `h_A = 2^{-q_A}`: the grid
index is `⌊f(x)/h_A + 1/2⌋` (ties toward `+∞`; B-ARCH's `valIdx`, `F2e2e/B/Mechanism.lean`). The program sees
`f` only through the evaluation oracle of Spec v3 §7 (`reqOracle`, `F2e2e/Spec.lean`), which
answers `⌊2^q f(x)⌋` at a precision `q` chosen by the program (selector `0`, record code `r = code x`). One
answer at precision `q_A + 1` gives the grid index: `⌊f(x)/h_A + 1/2⌋ = (⌊2^{q_A+1} f(x)⌋ + 1) div 2`.

* `evalsOf orc q blocks`: the grid indices `(orc 0 r (q+1) + 1) div 2` of all record codes `r`, block by block
  (the output of the DSL routine `bsEvals`, `F2e2e/BSpace/DslEvals.lean`);
* `evalsOf_le`, `evalsOf_map_length`: every index is `≤ 2^q` when the answers lie in `[0, 2^{q+1}]`, and the
  block shape is kept;
* `bsE_roundIdx_eq`, `bsE_idx_eq_valIdx`: the grid index identity, and the per-entry identity with `valIdx`;
* `evalsOf_eq_coreVals`: for answers `orc 0 (code x) (q_A+1) = ⌊2^{q_A+1} f(x)⌋` of a query with values in
  `[0, 1]`, `evalsOf orc q_A (splitBlocks n codes)` is B-ARCH's `coreVals P s (quantReq P r)` (the query table
  of the quantized request, `F2e2e/B/ArchOnline.lean`, `F2e2e/B/ArchBridge.lean`);
* `bsE_reqOracle_code`, `bsE_reqOracle_mem`, `evalsOf_reqOracle_eq_coreVals`: the same for Spec v3's
  `reqOracle` of a valid request with an injective record encoding.
-/

namespace F2e2e.BSpace

open F2e2e.B F2e2e.Discrete

/-- **The query table read through the evaluation oracle**: for every record code `r` of every block, the
grid index `(orc 0 r (q+1) + 1) div 2`, i.e. `(⌊2^{q+1} f(x)⌋ + 1) div 2` for the oracle of a request. -/
def evalsOf (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (bs : List (List ℕ)) : List (List ℕ) :=
  bs.map (·.map fun r : ℕ => ((orc 0 (r : ℤ) (q + 1) + 1) / 2).toNat)

/-! ## Range and shape -/

/-- An answer `≤ 2^{q+1}` gives an index `≤ 2^q`. -/
theorem bsE_half_le {v : ℤ} {q : ℕ} (h1 : v ≤ 2 ^ (q + 1)) :
    ((v + 1) / 2).toNat ≤ 2 ^ q := by
  have h2 : (2 : ℤ) ^ (q + 1) = 2 * 2 ^ q := by ring
  rw [h2] at h1
  rw [Int.toNat_le]
  push_cast
  generalize (2 : ℤ) ^ q = t at h1 ⊢
  omega

/-- The index of an answer in `[0, 2^{q+1}]`, as an integer. -/
theorem bsE_half_nonneg {v : ℤ} (h0 : 0 ≤ v) : 0 ≤ (v + 1) / 2 := by omega

/-- Every index of `evalsOf` is `≤ 2^q` when the oracle's answers lie in `[0, 2^{q+1}]`. -/
theorem evalsOf_le {orc : ℤ → ℤ → ℤ → ℤ} {q : ℕ} {bs : List (List ℕ)}
    (hO : ∀ blk ∈ bs, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) :
    ∀ blk ∈ evalsOf orc q bs, ∀ v ∈ blk, v ≤ 2 ^ q := by
  intro blk hblk v hv
  simp only [evalsOf, List.mem_map] at hblk
  obtain ⟨b, hb, rfl⟩ := hblk
  simp only [List.mem_map] at hv
  obtain ⟨r, hr, rfl⟩ := hv
  exact bsE_half_le (hO b hb r hr).2

/-- `evalsOf` keeps the block shape. -/
theorem evalsOf_map_length (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (bs : List (List ℕ)) :
    (evalsOf orc q bs).map List.length = bs.map List.length := by
  simp [evalsOf]

/-- `evalsOf` keeps the number of blocks. -/
theorem evalsOf_length (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (bs : List (List ℕ)) :
    (evalsOf orc q bs).length = bs.length := by
  simp [evalsOf]

/-! ## The grid index from one truncation -/

/-- **The grid index from one truncation** (`h_A = 2^{-q}`): `⌊z/h_A + 1/2⌋ = (⌊2^{q+1} z⌋ + 1) div 2`. -/
theorem bsE_roundIdx_eq (q : ℕ) (z : ℝ) :
    roundIdx ((((1 / 2 : ℚ) ^ q : ℚ)) : ℝ) z = (⌊(2 : ℝ) ^ (q + 1) * z⌋ + 1) / 2 := by
  unfold roundIdx
  have h2 : (((1 / 2 : ℚ) ^ q : ℚ) : ℝ) = ((2 : ℝ) ^ q)⁻¹ := by
    push_cast
    rw [one_div, inv_pow]
  have h1 : z / ((2 : ℝ) ^ q)⁻¹ + 1 / 2 = ((2 : ℝ) ^ (q + 1) * z + 1) / ((2 : ℕ) : ℝ) := by
    rw [div_inv_eq_mul, pow_succ]
    push_cast
    ring
  rw [h2, h1, Int.floor_div_natCast, Int.floor_add_one]
  norm_num

/-- **Per-entry identity**: for `z ∈ [0, 1]` and the answer `v = ⌊2^{q_A+1} z⌋`, the index
`(v + 1) div 2` is B-ARCH's grid index `valIdx P z`. -/
theorem bsE_idx_eq_valIdx (P : AdaParams) {z : ℝ} (hz0 : 0 ≤ z) (hz1 : z ≤ 1) {v : ℤ}
    (hv : v = ⌊(2 : ℝ) ^ (P.qA + 1) * z⌋) : ((v + 1) / 2).toNat = valIdx P z := by
  unfold valIdx
  rw [min_eq_right hz1, max_eq_right hz0, hv]
  have hh : ((P.hA : ℚ) : ℝ) = ((((1 / 2 : ℚ) ^ P.qA : ℚ)) : ℝ) := rfl
  rw [hh, bsE_roundIdx_eq]

/-- `⌊2^q z⌋ ∈ [0, 2^q]` for `z ∈ [0, 1]`. -/
theorem bsE_floor_mem {q : ℕ} {z : ℝ} (h0 : 0 ≤ z) (h1 : z ≤ 1) :
    0 ≤ ⌊(2 : ℝ) ^ q * z⌋ ∧ ⌊(2 : ℝ) ^ q * z⌋ ≤ 2 ^ q := by
  have hp : (0 : ℝ) < 2 ^ q := by positivity
  constructor
  · exact Int.floor_nonneg.mpr (by positivity)
  · have h : (2 : ℝ) ^ q * z ≤ ((2 ^ q : ℤ) : ℝ) := by
      push_cast
      exact mul_le_of_le_one_right hp.le h1
    calc ⌊(2 : ℝ) ^ q * z⌋ ≤ ⌊((2 ^ q : ℤ) : ℝ)⌋ := Int.floor_mono h
      _ = 2 ^ q := Int.floor_intCast _

/-! ## The query table of a request -/

/-- `splitBlocks` commutes with `map`. -/
theorem bsE_splitBlocks_map (f : ℕ → ℕ) : ∀ (ns l : List ℕ),
    splitBlocks ns (l.map f) = (splitBlocks ns l).map (List.map f)
  | [], _ => rfl
  | n :: ns, l => by
    simp only [splitBlocks, List.map_cons, List.map_take]
    rw [← bsE_splitBlocks_map f ns (l.drop n), List.map_drop]

/-- `evalsOf` of the blocks of a code list is the split of the indices of the codes. -/
theorem evalsOf_splitBlocks (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (ns codes : List ℕ) :
    evalsOf orc q (splitBlocks ns codes) =
      splitBlocks ns (codes.map fun r : ℕ => ((orc 0 (r : ℤ) (q + 1) + 1) / 2).toNat) := by
  rw [bsE_splitBlocks_map]
  rfl

/-- **The query table through the oracle is the query table of the quantized request.** If the oracle
answers `⌊2^{q_A+1} f(x)⌋` on the code of every record `x` and `f` takes values in `[0, 1]`, then
`evalsOf orc q_A` of the blocks of the sample's codes is B-ARCH's `coreVals P s (quantReq P r)`. -/
theorem evalsOf_eq_coreVals {U : Type} (P : AdaParams) (code : U → ℕ) (s : Fin P.N → U)
    (r : (U → ℝ) × Bool × ℝ × ℝ) (orc : ℤ → ℤ → ℤ → ℤ) (hval : ∀ x, 0 ≤ r.1 x ∧ r.1 x ≤ 1)
    (horc : ∀ x, orc 0 (code x : ℤ) (P.qA + 1) = ⌊(2 : ℝ) ^ (P.qA + 1) * r.1 x⌋) :
    evalsOf orc P.qA (splitBlocks P.blockSizes (List.ofFn fun ℓ => code (s ℓ))) =
      coreVals P s (quantReq P r) := by
  rw [evalsOf_splitBlocks, List.map_ofFn]
  unfold coreVals
  congr 2
  funext ℓ
  exact bsE_idx_eq_valIdx P (hval (s ℓ)).1 (hval (s ℓ)).2 (horc (s ℓ))

/-! ## Spec v3's oracle of a request -/

/-- `reqOracle` on the code of a record (injective encoding), at the precision `q + 1`. -/
theorem bsE_reqOracle_code {U : Type} {code : U → ℕ} (hinj : Function.Injective code) (req : VReq U)
    (x : U) (q : ℕ) :
    reqOracle code req 0 (code x : ℤ) ((q : ℤ) + 1) = ⌊(2 : ℝ) ^ (q + 1) * req.1 x⌋ := by
  have hex : ∃ y, (code y : ℤ) = (code x : ℤ) := ⟨x, rfl⟩
  have hch : Classical.choose hex = x := hinj (by exact_mod_cast Classical.choose_spec hex)
  have hq : ((q : ℤ) + 1).toNat = q + 1 := by omega
  unfold reqOracle truncIdx
  simp only [if_true, dif_pos hex, hch, hq]

/-- **The oracle's range** (hypothesis `hO` of `bsEvals_eval`): for a valid request, every answer at
selector `0` and precision `q + 1` lies in `[0, 2^{q+1}]` (it is `0` on a non-code). -/
theorem bsE_reqOracle_mem {U : Type} (code : U → ℕ) {req : VReq U} (hval : req.Valid) (r : ℤ) (q : ℕ) :
    0 ≤ reqOracle code req 0 r ((q : ℤ) + 1) ∧ reqOracle code req 0 r ((q : ℤ) + 1) ≤ 2 ^ (q + 1) := by
  have hq : ((q : ℤ) + 1).toNat = q + 1 := by omega
  unfold reqOracle truncIdx
  simp only [if_true, hq]
  split
  · exact bsE_floor_mem (hval.1 _).1 (hval.1 _).2
  · exact ⟨le_refl 0, by positivity⟩

/-- **D2's math for R1**: with Spec v3's oracle of a valid request and an injective record encoding, the
query table read by `bsEvals` (blocks of the sample's codes) is B-ARCH's `coreVals P s (quantReq P req)`. -/
theorem evalsOf_reqOracle_eq_coreVals {U : Type} (P : AdaParams) {code : U → ℕ}
    (hinj : Function.Injective code) (s : Fin P.N → U) {req : VReq U} (hval : req.Valid) :
    evalsOf (reqOracle code req) P.qA (splitBlocks P.blockSizes (List.ofFn fun ℓ => code (s ℓ))) =
      coreVals P s (quantReq P req) :=
  evalsOf_eq_coreVals P code s req _ hval.1 fun x => bsE_reqOracle_code hinj req x P.qA

end F2e2e.BSpace
