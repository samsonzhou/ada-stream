import F2e2e.BSpace.O2SizeFrames
import F2e2e.BSpace.O2GlueMainBounds
import F2e2e.BSpace.O2TightChiLinks

/-!
# B_space, route O2b (O2B-SIZE): the round frame's `(m, τ)` in O2Final's coefficients

Owner: O2B-SIZE (ce59d4ae), for the O2b technical lead (17fc0802) and B-ACC's end inequality
(`o2f_final`: `m ≤ c_mU (N b_𝒰) + c_mX (N χ) + d_m`, `τ ≤ c_τU (N b_𝒰) + c_τX (N χ) + d_τ`).

C-BANK's round frame (`F2e2e/BSpace/O2GlueMainBounds.lean`): the value bound
`o2m_mR = o2mTopM = o2mInpB + o2mPubRecB + o2mValsB + o2mStB + 4 q_A + 64` and the callee budget
`o2m_τR = o2mTopT = max (135 · bsPubBound) (max (50 · o2mME) (max (38 · o2mMD) (max (231 · o2mMI) (240 · o2MA))))`.

* Component bounds over the χ-links `O2sLinks A χ cq` (`F2e2e/BSpace/O2SizeFrames.lean`): `o2s_coef_stB`,
  `o2s_coef_valsB`, `o2s_coef_blocksB`, `o2s_coef_pubRecB`, `o2s_coef_inpB`, `o2s_coef_ME`, `o2s_coef_MD`;
* the frame: `o2s_coef_topM : o2mTopM … ≤ 1·(N b_𝒰) + (3 cq + 3)·(N χ)`;
  `o2s_coef_topT : o2mTopT … ≤ 50·(N b_𝒰) + (240 C₁)·(N χ)` given `o2MA A ≤ C₁ · N χ`, `26 ≤ C₁`;
* the actual parameters at Plan A (`q_A ≤ 2χ`, B-NUM; `o2MA ≤ 72449 N χ`, B-ARCH's `o2cl_tightM_le`):
  `o2s_coef_mR : o2m_mR … ≤ 1·(N b_𝒰) + 9·(N χ)`, `o2s_coef_τR : o2m_τR … ≤ 50·(N b_𝒰) + 17387760·(N χ)` (pure
  form of `o2f_finR_pure`; `o2s_coef_mR_pt`, `o2s_coef_τR_pt` carry `+ 0` for `o2f_finR_pt`),
  with `N = (alg2Params M J R a_req ξ_req).N`, `χ = valChi M J R (dyadicDown a_req) (dyadicDown ξ_req)`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Components (generic) -/

section components

variable {A : AdaParams} {χ cq : ℕ}

/-- **The state bound** `o2mStB A ≤ cq N χ + N χ + 6 N`. -/
theorem o2s_coef_stB (L : O2sLinks A χ cq) : o2mStB A ≤ cq * (A.N * χ) + A.N * χ + 6 * A.N := by
  unfold o2mStB
  have e1 : A.N * (A.qA + Nat.size A.fuel + 4) = A.N * A.qA + A.N * Nat.size A.fuel + 4 * A.N := by
    ring
  have hNF : A.N * Nat.size A.fuel ≤ A.N * χ + A.N :=
    calc A.N * Nat.size A.fuel ≤ A.N * (χ + 1) := Nat.mul_le_mul_left _ L.sF_le
      _ = A.N * χ + A.N := by ring
  have hp : A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have hF := L.sF_le; have hK := L.sK_le; have hC := L.sC_le
    have h1 := Nat.mul_le_mul_left A.p
      (show Nat.size A.fuel + Nat.size (maxKs A) + 6 ≤ A.qA + 7 * χ + 40 by omega)
    have e : (A.p + 1) * (A.qA + 7 * χ + 40) = A.p * (A.qA + 7 * χ + 40) + (A.qA + 7 * χ + 40) := by
      ring
    omega
  have hs := L.small
  have hq := L.qNX
  omega

/-- **The query-table bound** `o2mValsB A ≤ cq N χ + 4 N`. -/
theorem o2s_coef_valsB (L : O2sLinks A χ cq) : o2mValsB A ≤ cq * (A.N * χ) + 4 * A.N := by
  unfold o2mValsB
  have e1 : A.N * (A.qA + 3) = A.N * A.qA + 3 * A.N := by ring
  have hs := L.small
  have hp : 2 * (A.p + 1) + 1 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have : 3 * (A.p + 1) ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
      rw [Nat.mul_comm 3]; exact Nat.mul_le_mul_left _ (by omega)
    omega
  have hq := L.qNX
  omega

/-- **The stored-blocks bound** `o2mBlocksB A bU ≤ N b_𝒰 + 3 N`. -/
theorem o2s_coef_blocksB (L : O2sLinks A χ cq) (bU : ℕ) : o2mBlocksB A bU ≤ A.N * bU + 3 * A.N := by
  unfold o2mBlocksB
  have e : A.N * (bU + 2) = A.N * bU + 2 * A.N := by ring
  have hs := L.small
  have hp : 2 * (A.p + 1) + 1 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have : 3 * (A.p + 1) ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
      rw [Nat.mul_comm 3]; exact Nat.mul_le_mul_left _ (by omega)
    omega
  omega

/-- **The parameter-record bound** `2^{14} · o2mPubRecB A ≤ N`. -/
theorem o2s_coef_pubRecB (L : O2sLinks A χ cq) : 16384 * o2mPubRecB A ≤ A.N := by
  have hc34 : 34 * (29 * cq + 83) ≤ 34374 := by have := L.cq_le; omega
  have hNz : Nat.size A.N + 2 ≤ adaZ A + 16 := by have := size_N_le_adaZ A; omega
  have hFz : Nat.size A.fuel + 2 ≤ adaZ A + 16 := by have := size_fuel_le_adaZ A; omega
  have hp1 : A.p ≤ A.p + 1 := Nat.le_succ _
  have hpos : 0 < A.p + 1 := Nat.succ_pos _
  have hZ := L.Z16
  have h4 := L.pX
  have h1 : o2mPubRecB A ≤ 34 * (A.p + 1) * (adaZ A + 16) := by
    unfold o2mPubRecB
    have e1 : (A.p + 1) * (Nat.size A.N + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
      Nat.mul_le_mul_left _ hNz
    have e2 : A.p * (Nat.size A.fuel + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
      Nat.mul_le_mul hp1 hFz
    have e3 : 32 * (adaZ A + 16) ≤ 32 * ((A.p + 1) * (adaZ A + 16)) :=
      Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ hpos)
    have e : 34 * (A.p + 1) * (adaZ A + 16) = 34 * ((A.p + 1) * (adaZ A + 16)) := by ring
    linarith
  calc 16384 * o2mPubRecB A ≤ 16384 * (34 * (A.p + 1) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
    _ ≤ 16384 * (34 * (A.p + 1) * ((29 * cq + 83) * χ)) :=
        Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hZ)
    _ = 16384 * ((34 * (29 * cq + 83)) * ((A.p + 1) * χ)) := by ring
    _ ≤ 16384 * (34374 * ((A.p + 1) * χ)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ hc34)
    _ = 563183616 * ((A.p + 1) * χ) := by ring
    _ ≤ 1073741824 * ((A.p + 1) * χ) := Nat.mul_le_mul_right _ (by norm_num)
    _ ≤ A.N := h4

/-- **The round-input bound** `o2mInpB A bU A.M A.J A.R eA eXi ≤ N b_𝒰 + cq N χ + N χ + 8 N`. -/
theorem o2s_coef_inpB (L : O2sLinks A χ cq) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) (bU : ℕ) :
    o2mInpB A bU A.M A.J A.R eA eXi ≤ A.N * bU + cq * (A.N * χ) + A.N * χ + 8 * A.N := by
  unfold o2mInpB
  have e1 : A.N * (bU + A.qA + Nat.size A.fuel + 6) =
      A.N * bU + A.N * A.qA + A.N * Nat.size A.fuel + 6 * A.N := by ring
  have hNF : A.N * Nat.size A.fuel ≤ A.N * χ + A.N :=
    calc A.N * Nat.size A.fuel ≤ A.N * (χ + 1) := Nat.mul_le_mul_left _ L.sF_le
      _ = A.N * χ + A.N := by ring
  have hC := L.sC_le
  have hcl : Nat.clog 2 (A.M + A.J + A.R + 2) ≤ Nat.size (A.M + A.J + A.R + 2) :=
    (Nat.clog_le_iff_le_pow (by norm_num)).2 (Nat.lt_size_self _).le
  have hL : bsPubL A.M A.J A.R eA eXi ≤ 3 * χ := by
    unfold bsPubL
    have := L.chi_gt
    omega
  have hp : A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 3 * bsPubL A.M A.J A.R eA eXi + 37 ≤
      (A.p + 1) * (A.qA + 7 * χ + 40) + 9 * χ + 37 := by
    have hF := L.sF_le; have hK := L.sK_le
    have h1 := Nat.mul_le_mul_left A.p
      (show Nat.size A.fuel + Nat.size (maxKs A) + 8 ≤ A.qA + 7 * χ + 40 by omega)
    have e : (A.p + 1) * (A.qA + 7 * χ + 40) = A.p * (A.qA + 7 * χ + 40) + (A.qA + 7 * χ + 40) := by
      ring
    omega
  have hs := L.small
  have hs1 := L.small1
  have hq := L.qNX
  omega

/-- **`bsEvals`' bound** `o2mME A bU ≤ N b_𝒰 + (cq + 1) N χ`. -/
theorem o2s_coef_ME (L : O2sLinks A χ cq) (bU : ℕ) :
    o2mME A bU ≤ A.N * bU + (cq + 1) * (A.N * χ) := by
  unfold o2mME
  have h1 := o2s_coef_blocksB L bU
  have h2 := o2s_coef_valsB L
  have hNX := L.NX
  have hs := L.small1
  have e : (cq + 1) * (A.N * χ) = cq * (A.N * χ) + A.N * χ := by ring
  omega

/-- **`bsEnds`' bound** `o2mMD A = 20 q_A + 200 ≤ N`. -/
theorem o2s_coef_MD (L : O2sLinks A χ cq) : o2mMD A ≤ A.N := by
  unfold o2mMD
  exact o2s_frame_D3 L

end components

/-! ## The round frame (generic) -/

theorem o2s_aux_231 {X Y : ℕ} (h : 26 * X ≤ Y) : 231 * X ≤ 9 * Y := by omega

section frame

variable {A : AdaParams} {χ cq : ℕ}

/-- **The round frame's value bound**: `o2mTopM … ≤ 1·(N b_𝒰) + (3 cq + 3)·(N χ)`. -/
theorem o2s_coef_topM (L : O2sLinks A χ cq) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) (bU : ℕ) :
    o2mTopM A bU A.M A.J A.R eA eXi ≤ 1 * (A.N * bU) + (3 * cq + 3) * (A.N * χ) := by
  unfold o2mTopM
  have h1 := o2s_coef_inpB L hpar bU
  have h2 := o2s_coef_pubRecB L
  have h3 := o2s_coef_valsB L
  have h4 := o2s_coef_stB L
  have hNX := L.NX
  have hs := L.small1
  have e : (3 * cq + 3) * (A.N * χ) = cq * (A.N * χ) + cq * (A.N * χ) + cq * (A.N * χ) +
      3 * (A.N * χ) := by ring
  omega

/-- **The round frame's callee budget**: given `o2MA A ≤ C₁ · N χ` with `26 ≤ C₁`,
`o2mTopT … ≤ 50·(N b_𝒰) + (240 C₁)·(N χ)`. -/
theorem o2s_coef_topT (L : O2sLinks A χ cq) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) (bU : ℕ)
    {C₁ : ℕ} (hC₁ : 26 ≤ C₁) (hMA : o2MA A ≤ C₁ * (A.N * χ)) :
    o2mTopT A bU A.M A.J A.R eA eXi ≤ 50 * (A.N * bU) + (240 * C₁) * (A.N * χ) := by
  have hcq1 : cq + 1 ≤ 33 := by have := L.cq_le; omega
  have hC₁pos : 0 < C₁ := by omega
  have hNX := L.NX
  have hP : o2mMP A.M A.J A.R eA eXi ≤ A.N * χ := o2s_frame_bsPub L hpar
  have hE := o2s_coef_ME L bU
  have hD := o2s_coef_MD L
  have hQ := o2s_frame_q28 L
  have hX0 : 0 ≤ A.N * χ := Nat.zero_le _
  have hCX : C₁ * (A.N * χ) ≤ (240 * C₁) * (A.N * χ) := by
    have e : (240 * C₁) * (A.N * χ) = 240 * (C₁ * (A.N * χ)) := by ring
    omega
  have hCX1 : A.N * χ ≤ C₁ * (A.N * χ) := Nat.le_mul_of_pos_left _ hC₁pos
  have h26 : 26 * (A.N * χ) ≤ C₁ * (A.N * χ) := Nat.mul_le_mul_right _ hC₁
  have hcqX : (cq + 1) * (A.N * χ) ≤ 33 * (A.N * χ) := Nat.mul_le_mul_right _ hcq1
  unfold o2mTopT
  refine max_le ?_ (max_le ?_ (max_le ?_ (max_le ?_ ?_)))
  · -- `135 · bsPubBound ≤ 135 N χ`
    have e : (240 * C₁) * (A.N * χ) = 240 * (C₁ * (A.N * χ)) := by ring
    omega
  · -- `50 · o2mME ≤ 50 N b_𝒰 + 1650 N χ`
    have e : (240 * C₁) * (A.N * χ) = 240 * (C₁ * (A.N * χ)) := by ring
    omega
  · -- `38 · (20 q_A + 200) ≤ 38 N ≤ N χ`
    have e : (240 * C₁) * (A.N * χ) = 240 * (C₁ * (A.N * χ)) := by ring
    omega
  · -- `231 · (o2MA + 2^28 (q_A + 4)) ≤ 231 (C₁ + 1) N χ ≤ 240 C₁ N χ`
    unfold o2mMI
    calc 231 * (o2MA A + 2 ^ 28 * (A.qA + 4)) ≤ 231 * (C₁ * (A.N * χ) + A.N * χ) :=
          Nat.mul_le_mul_left _ (Nat.add_le_add hMA hQ)
      _ = 231 * (C₁ * (A.N * χ)) + 231 * (A.N * χ) := by ring
      _ ≤ 231 * (C₁ * (A.N * χ)) + 9 * (C₁ * (A.N * χ)) := Nat.add_le_add_left (o2s_aux_231 h26) _
      _ = (240 * C₁) * (A.N * χ) := by ring
      _ ≤ 50 * (A.N * bU) + (240 * C₁) * (A.N * χ) := Nat.le_add_left _ _
  · -- `240 · o2MA ≤ 240 C₁ N χ`
    have e : (240 * C₁) * (A.N * χ) = 240 * (C₁ * (A.N * χ)) := by ring
    omega

end frame

/-! ## The actual parameters at Plan A -/

section actual

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- `o2MA (asmParams …) ≤ 72449 · N χ` (B-ARCH's `o2cl_tightM_le`, Plan A), with `N = A.N`. -/
theorem o2s_coef_MA_planA (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    o2MA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      72449 * ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  have h := o2cl_tightM_le M J R ha0 ha1 hξ0 hξ1
  rw [V2.v2par_N M J R ha0 ha1 hξ0 hξ1] at h
  unfold o2MA
  calc 2 ^ 8 * tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) +
        cAddA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      ≤ 72449 * (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N *
          F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := h
    _ = _ := by ring

/-- **The round frame's value bound, Plan A**: `o2m_mR … ≤ 1·(N b_𝒰) + 9·(N χ)` (the pure form of B-ACC's
`o2f_finR_pure` / `o2f_finR_of_pure`; `o2s_coef_mR_pt` is the form with `+ 0` for `o2f_finR_pt`). -/
theorem o2s_coef_mR (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2m_mR M J R aReq ξReq bU ≤ 1 * ((F2e2e.alg2Params M J R aReq ξReq).N * bU) +
      9 * ((F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  rw [V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
  exact o2s_coef_topM (o2s_links_planA M J R ha0 ha1 hξ0 hξ1) (o2s_eAX_le_chi M J R ha0 ha1 hξ0 hξ1) bU

/-- **The round frame's callee budget, Plan A**: `o2m_τR … ≤ 50·(N b_𝒰) + 17387760·(N χ)`
(`17387760 = 240 · 72449`; pure form, `o2s_coef_τR_pt` with `+ 0`). -/
theorem o2s_coef_τR (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2m_τR M J R aReq ξReq bU ≤ 50 * ((F2e2e.alg2Params M J R aReq ξReq).N * bU) +
      17387760 * ((F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) := by
  rw [V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
  have h := o2s_coef_topT (o2s_links_planA M J R ha0 ha1 hξ0 hξ1) (o2s_eAX_le_chi M J R ha0 ha1 hξ0 hξ1)
    bU (by norm_num) (o2s_coef_MA_planA M J R ha0 ha1 hξ0 hξ1)
  exact h

/-- `o2s_coef_mR` with an explicit `+ 0` (the shape of B-ACC's `o2f_finR_pt` at `d_m = 0`). -/
theorem o2s_coef_mR_pt (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2m_mR M J R aReq ξReq bU ≤ 1 * ((F2e2e.alg2Params M J R aReq ξReq).N * bU) +
      9 * ((F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) + 0 :=
  (o2s_coef_mR M J R ha0 ha1 hξ0 hξ1 bU).trans (Nat.le_add_right _ 0)

/-- `o2s_coef_τR` with an explicit `+ 0` (the shape of B-ACC's `o2f_finR_pt` at `d_τ = 0`). -/
theorem o2s_coef_τR_pt (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    (bU : ℕ) :
    o2m_τR M J R aReq ξReq bU ≤ 50 * ((F2e2e.alg2Params M J R aReq ξReq).N * bU) +
      17387760 * ((F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) + 0 :=
  (o2s_coef_τR M J R ha0 ha1 hξ0 hξ1 bU).trans (Nat.le_add_right _ 0)

end actual

end F2e2e.BSpace
