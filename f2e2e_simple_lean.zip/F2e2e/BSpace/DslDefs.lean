import F2e2e.C.Impl.AdaRep
import F2e2e.BSpace.RefineDefs

/-!
# B_space, layer D4 (W2): the stable definitions of the entry bodies

Owner: W2 (a2ff64c3). The keys of the B glue routines called by the entry bodies, the B state encoding
`bsStateEnc` and the response encoding `bsResp` (Spec v3 §7 `parseVResponse` format). Split off from
`F2e2e/BSpace/DslMain.lean` (the bodies and their specs) so that consumers (C-TOP's T1) import only these.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Impl

/-! ## Keys of the B glue routines -/

/-- D1 (W3): `bsBlocks : [encL encN ns, encL encN codes] ↦ Val.list ((splitBlocks ns codes).map (encL encN))`. -/
abbrev bsBlocksKey : ℕ := 900
/-- D2 (1beb339b): `bsEvals : [encN qA, blocks] ↦ encVals (evalsOf orc qA blocks)` (oracle). -/
abbrev bsEvalsKey : ℕ := 910
/-- D3 (W5): `bsEnds : [encN qA] ↦ [encQ l', encQ u']` (oracle). -/
abbrev bsEndsKey : ℕ := 920

/-! ## State and response -/

/-- **The B state**: the stored blocks of record codes and W4's ADA state. -/
def bsStateEnc (blocks : List (List ℕ)) (st : AdaState) : Val :=
  Val.list [Val.list (blocks.map (encL encN)), adaEnc st]

/-- **The response encoding** (Spec v3 §7 `parseVResponse`): `[0]` ACCEPT (also `abort`), `[1]` HIGH
(also the terminal HIGH), `[2]` LOW (also the terminal LOW), `[3, a, d]` the numerical answer `a/d`
(`[3, 0, 1]` for a numerical abort). -/
def bsResp : CoreOut → Val
  | Sum.inl AdaCert.accept => encInts [0]
  | Sum.inl AdaCert.high => encInts [1]
  | Sum.inl AdaCert.low => encInts [2]
  | Sum.inl AdaCert.termHigh => encInts [1]
  | Sum.inl AdaCert.termLow => encInts [2]
  | Sum.inl AdaCert.abort => encInts [0]
  | Sum.inr (AdaNum.val μ) => encInts [3, μ.num, (μ.den : ℤ)]
  | Sum.inr AdaNum.abort => encInts [3, 0, 1]

end F2e2e.BSpace
