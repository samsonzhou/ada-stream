import F2e2e.BSpace.CalcORules
import F2e2e.Cost.Lib.MapB

/-!
# B_space: folds and maps with oracle-calling steps (DSL-CALC, `bsC`)

Oracle versions of the callback combinators of `F2e2e/Cost/Lib/BitFold.lean` and
`F2e2e/Cost/Lib/MapB.lean`, with the SAME DSL bodies (`body_foldBStep iF`, `body_foldB iStep`,
`body_mapBStep iF`, `body_mapB iStep`), so the routines are shared between (C) and B:

* `bsC.foldB_implO` : if the step routine `iF` (environment `[[x, s, extra]]`) implements every
  `f x s` in `ImplementsO` form (it may call the oracle) for states satisfying an invariant `P`
  preserved by the steps, states satisfying `P` have size `≤ VS`, and
  `M ≥ 2 VS + |encL encA l| + |extra| + 20`, then `body_foldB iStep` implements `foldB f l s`;
* `bsC.foldP_valO` : the deterministic version (`EvalsValO` with no fresh bits);
* `bsC.mapB_implO` : if the element routine `iF` (environment `[[x, extra]]`) implements every
  `f x` in `ImplementsO` form, all results have size `≤ VB` and `mapB_M encA l extra VB ≤ M`,
  then `body_mapB iStep` implements `mapB f l` (results in order, encoding `encL encB`);
* `bsC.mapP_valO` : the deterministic map (`l.map g`; `bsC.mapB_pure`);
* `bsC.mapMapP_valO` : the deterministic nested map (`ls.map (List.map g)`, e.g. a query table
  block by block), the inner element routine calling the oracle;
* step and loop lemmas `bsC.foldBStep_nil_valO`, `bsC.foldBStep_cons_valO`, `bsC.foldB_loopO`,
  `bsC.mapBStep_nil_valO`, `bsC.mapBStep_cons_valO`, `bsC.mapB_loopO`.

All take `hO : prog[bsOracleIdx]? = none` (no body at the oracle index).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

namespace bsC

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

/-! ### The fold -/

theorem foldBStep_nil_valO (hO : prog[bsOracleIdx]? = none) (iF : ℕ) (sv extra : Val)
    (hM : valSize (Val.list [sv, Val.list [], extra]) + 6 ≤ M) :
    EvalsValO orc prog M [Val.list [sv, Val.list [], extra]] [] (.inl (body_foldBStep iF))
      (Val.list [Val.int 0, sv]) :=
  lift hO (foldBStep_nil_val iF sv extra hM)

theorem foldBStep_cons_valO (hO : prog[bsOracleIdx]? = none) {iF : ℕ} {bodyF : Expr}
    (hF : prog[iF]? = some bodyF) {sv x extra sv' : Val} {R : List Val} {b1 : List Bool}
    (hcall : EvalsValO orc prog M [Val.list [x, sv, extra]] b1 (.inl bodyF) sv')
    (hM : valSize (Val.list [sv, Val.list (x :: R), extra]) + valSize sv' + 10 ≤ M) :
    EvalsValO orc prog M [Val.list [sv, Val.list (x :: R), extra]] b1 (.inl (body_foldBStep iF))
      (Val.list [Val.int 1, Val.list [sv', Val.list R, extra]]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h1 : EvalsValO orc prog M [Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))) (Val.list (x :: R)) :=
    EvalsValO.head (EvalsValO.tail var0
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsValO orc prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    isNil_cons var0 (by omega)
  have hex : EvalsValO orc prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) extra :=
    EvalsValO.head (EvalsValO.tail (EvalsValO.tail var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hargs : EvalsValO orc prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]]
      [] (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) (Expr.un UnOp.head (Expr.var 1))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [x, sv, extra]) := by
    have := triple (EvalsValO.head var0 (by omega)) (EvalsValO.head var1 (by omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hcall' := call hO hargs hF hcall
  have htr : EvalsValO orc prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] b1
      (.inl (Arith.eTriple
        (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
          (Expr.un UnOp.head (Expr.var 1))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
        (Expr.un UnOp.tail (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [sv', Val.list R, extra]) := by
    have := triple hcall' (EvalsValO.tail var0
      (by simp only [valSize_list]; omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hf : EvalsValO orc prog M [Val.list (x :: R), Val.list [sv, Val.list (x :: R), extra]] b1
      (.inl (ePair (Expr.lit 1) (Arith.eTriple
        (Expr.call iF (Arith.eTriple (Expr.un UnOp.head (Expr.var 0))
          (Expr.un UnOp.head (Expr.var 1))
          (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
        (Expr.un UnOp.tail (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))))
      (Val.list [Val.int 1, Val.list [sv', Val.list R, extra]]) := by
    have := EvalsValO.pair (lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega)) htr
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
    simpa using this
  have := EvalsValO.letE h1 (ite_false
    (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.var 1))) hc rfl hf)
  simpa [body_foldBStep] using this

section SpecFold

variable {α σ : Type}

theorem foldB_loopO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (f : α → σ → BitProg σ) (P : σ → Prop)
    (l : List α) (VS : ℕ)
    (hP : ∀ x s bits s', x ∈ l → P s → (f x s).run bits = some (s', []) → P s')
    (hFi : ∀ x s, x ∈ l → P s →
      ImplementsO orc prog M [Val.list [encA x, encS s, extra]] bodyF encS (f x s))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) :
    ∀ r : List α, r <:+ l → ∀ s, P s → ∀ bits s', (foldB f r s).run bits = some (s', []) →
      EvalsValO orc prog M [] bits (.inr (iStep, Val.list [encS s, encL encA r, extra]))
        (encS s') := by
  intro r
  induction r with
  | nil =>
    intro _ s hs bits s' h
    obtain ⟨hb1, hb2⟩ := bitProg_run_pure_exact.mp h
    subst hb1
    rw [hb2]
    have hVs := hV s hs
    have hL := valSize_encL_ge encA l
    refine EvalsValO.stop hstep ?_
    simp only [encL_nil]
    exact foldBStep_nil_valO hO iF (encS s) extra
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  | cons x r ih =>
    intro hsuf s hs bits s' h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    rw [foldB_cons] at h
    obtain ⟨b₁, b₂, s'', rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
    have hs'' := hP x s b₁ s'' hx hs h1
    have hcall := hFi x s hx hs b₁ s'' h1
    have hrest := ih hsuf' s'' hs'' b₂ s' h2
    have hVs := hV s hs
    have hVs'' := hV s'' hs''
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hbody := foldBStep_cons_valO hO (R := r.map encA) hF hcall
      (by simp only [encL, valSize_list, listSize_cons, listSize_nil, List.map_cons] at hR hM ⊢
          omega)
    exact EvalsValO.cont hstep hbody one_ne_zero hrest

/-- **Spec of `foldB` with the oracle** (`ImplementsO` form). -/
theorem foldB_implO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (f : α → σ → BitProg σ) (P : σ → Prop)
    (l : List α) (VS : ℕ)
    (hP : ∀ x s bits s', x ∈ l → P s → (f x s).run bits = some (s', []) → P s')
    (hFi : ∀ x s, x ∈ l → P s →
      ImplementsO orc prog M [Val.list [encA x, encS s, extra]] bodyF encS (f x s))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : P s) :
    ImplementsO orc prog M [Val.list [encS s, encL encA l, extra]] (body_foldB iStep) encS
      (foldB f l s) := by
  intro bits s' h
  exact EvalsValO.loop var0 (foldB_loopO hO hstep hF encA encS extra f P l VS hP hFi hV hM l
    (List.suffix_refl l) s hs bits s' h)

/-- **Spec of the deterministic fold with the oracle** (`foldP`): no fresh bits. -/
theorem foldP_valO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_foldBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encS : σ → Val) (extra : Val) (g : α → σ → σ) (P : σ → Prop)
    (l : List α) (VS : ℕ)
    (hP : ∀ x s, x ∈ l → P s → P (g x s))
    (hG : ∀ x s, x ∈ l → P s →
      EvalsValO orc prog M [Val.list [encA x, encS s, extra]] [] (.inl bodyF) (encS (g x s)))
    (hV : ∀ s, P s → valSize (encS s) ≤ VS)
    (hM : 2 * VS + valSize (encL encA l) + valSize extra + 20 ≤ M) (s : σ) (hs : P s) :
    EvalsValO orc prog M [Val.list [encS s, encL encA l, extra]] [] (.inl (body_foldB iStep))
      (encS (foldP g l s)) := by
  have himpl := foldB_implO hO hstep hF encA encS extra (fun x s => BitProg.pure (g x s)) P l VS
    (fun x s bits s' hx hs h => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
      exact hP x s hx hs)
    (fun x s hx hs => ImplementsO.of_det (hG x s hx hs)) hV hM s hs
  exact himpl [] (foldP g l s) (by rw [foldB_pure]; rfl)

end SpecFold

/-! ### The map (results in draw order) -/

theorem mapBStep_nil_valO (hO : prog[bsOracleIdx]? = none) (iF : ℕ) (av extra : Val)
    (hM : valSize (Val.list [Val.list [], av, extra]) + 6 ≤ M) :
    EvalsValO orc prog M [Val.list [Val.list [], av, extra]] [] (.inl (body_mapBStep iF))
      (Val.list [Val.int 0, av]) :=
  lift hO (mapBStep_nil_val iF av extra hM)

theorem mapBStep_cons_valO (hO : prog[bsOracleIdx]? = none) {iF : ℕ} {bodyF : Expr}
    (hF : prog[iF]? = some bodyF) {x extra bv : Val} {R A : List Val} {b1 : List Bool}
    (hcall : EvalsValO orc prog M [Val.list [x, extra]] b1 (.inl bodyF) bv)
    (hM : valSize (Val.list [Val.list (x :: R), Val.list A, extra]) + valSize bv + 10 ≤ M) :
    EvalsValO orc prog M [Val.list [Val.list (x :: R), Val.list A, extra]] b1
      (.inl (body_mapBStep iF)) (Val.list [Val.int 1, Val.list [Val.list R, Val.list (bv :: A),
        extra]]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h1 : EvalsValO orc prog M [Val.list [Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.var 0))) (Val.list (x :: R)) :=
    EvalsValO.head var0 (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A,
      extra]] [] (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    isNil_cons var0 (by omega)
  have hex : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A,
      extra]] [] (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1)))))
      extra :=
    EvalsValO.head (EvalsValO.tail (EvalsValO.tail var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hA : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A,
      extra]] [] (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))) (Val.list A) :=
    EvalsValO.head (EvalsValO.tail var1
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list]; omega)
  have hargs : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.list (x :: R), Val.list A,
      extra]] [] (.inl (ePair (Expr.un UnOp.head (Expr.var 0))
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))))
      (Val.list [x, extra]) := by
    have := EvalsValO.pair (EvalsValO.head var0 (by omega)) hex
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hcall' := call hO hargs hF hcall
  have hcons := EvalsValO.cons hcall' hA
    (by simp only [valSize_list, listSize_cons]; omega)
  have htr := triple (EvalsValO.tail var0
    (by simp only [valSize_list]; omega)) hcons hex
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have hf := EvalsValO.pair (lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega)) htr
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
  have := EvalsValO.letE h1 (ite_false
    (t := ePair (Expr.lit 0) (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 1)))) hc rfl hf)
  simpa [body_mapBStep] using this

section SpecMap

variable {α β : Type}

/-- The deterministic map is the map with pure element programs. -/
theorem mapB_pure (g : α → β) :
    ∀ l : List α, mapB (fun x => BitProg.pure (g x)) l = BitProg.pure (l.map g)
  | [] => rfl
  | x :: xs => by
    rw [mapB, mapB_pure g xs]
    rfl

theorem mapB_loopO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapBStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encB : β → Val) (extra : Val) (f : α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ x, x ∈ l → ImplementsO orc prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hVb : ∀ x, x ∈ l → ∀ bits b, (f x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapB_M encA l extra VB ≤ M) :
    ∀ r : List α, r <:+ l → ∀ done : List β, done.length + r.length = l.length →
      (∀ b ∈ done, valSize (encB b) ≤ VB) → ∀ bits bs, (mapB f r).run bits = some (bs, []) →
      EvalsValO orc prog M [] bits
        (.inr (iStep, Val.list [encL encA r, Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro _ done hlen hdone bits bs h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hA := valSize_rev_map_le encB done VB hdone
    have hL := valSize_encL_ge encA l
    simp only [List.length_nil, Nat.add_zero] at hlen
    refine EvalsValO.stop hstep ?_
    simp only [encL_nil, List.append_nil]
    refine mapBStep_nil_valO hO iF _ extra ?_
    simp only [mapB_M, valSize_list, listSize_cons, listSize_nil] at hM hA ⊢
    rw [hlen] at hA
    nlinarith
  | cons x r ih =>
    intro hsuf done hlen hdone bits bs h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapB_cons_run_exact h
    have hb := hVb x hx b₁ b h1
    have hcall := hFi x hx b₁ b h1
    have hdone' : ∀ c ∈ done ++ [b], valSize (encB c) ≤ VB := by
      intro c hc
      rcases List.mem_append.mp hc with hc | hc
      · exact hdone c hc
      · rw [List.mem_singleton.mp hc]; exact hb
    have hlen' : (done ++ [b]).length + r.length = l.length := by
      simp only [List.length_append, List.length_cons, List.length_nil] at hlen ⊢
      omega
    have hrest := ih hsuf' (done ++ [b]) hlen' hdone' b₂ bs' h2
    have hA := valSize_rev_map_le encB done VB hdone
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hdl : done.length ≤ l.length := by simp only [List.length_cons] at hlen; omega
    have hbody := mapBStep_cons_valO hO (R := r.map encA) (A := (done.map encB).reverse) hF hcall
      (by
        simp only [mapB_M, encL, valSize_list, listSize_cons, listSize_nil, List.map_cons]
          at hM hR hA ⊢
        have : done.length * (VB + 1) ≤ l.length * (VB + 1) := Nat.mul_le_mul_right _ hdl
        omega)
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    rw [hval]
    rw [hacc] at hbody
    exact EvalsValO.cont hstep hbody one_ne_zero hrest

/-- **Spec of `mapB` with the oracle** (`ImplementsO` form): the results in draw order. -/
theorem mapB_implO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapBStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (f : α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ x, x ∈ l → ImplementsO orc prog M [Val.list [encA x, extra]] bodyF encB (f x))
    (hVb : ∀ x, x ∈ l → ∀ bits b, (f x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapB_M encA l extra VB ≤ M) :
    ImplementsO orc prog M [Val.list [encL encA l, extra]] (body_mapB iStep) (encL encB)
      (mapB f l) := by
  intro bits bs h
  have hloop := mapB_loopO hO hstep hF encA encB extra f l VB hFi hVb hM l (List.suffix_refl l) []
    (by simp) (by simp) bits bs h
  simp only [List.map_nil, List.reverse_nil, List.nil_append] at hloop
  have hL := valSize_encL_ge encA l
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (Arith.eTriple (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [encL encA l, Val.list [], extra]) := by
    simp only [mapB_M] at hM
    have := EvalsVal.triple (EvalsVal.head (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
        (by omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
    simpa using this
  have hl := EvalsValO.loop (lift hO hinit) hloop
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  obtain ⟨hlen, hBs⟩ := mapB_run_results encB l bits bs hVb h
  have hsz := valSize_rev_map_le encB bs VB hBs
  have hcall := call hO hl hrev (lift hO (hrs.mono_M (by
    simp only [S_reverse, mapB_M] at hM ⊢
    rw [hlen] at hsz
    omega)))
  simpa [encL, body_mapB] using hcall

/-- **Spec of the deterministic map with the oracle** (`l.map g`): no fresh bits. -/
theorem mapP_valO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapBStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (g : α → β) (l : List α) (VB : ℕ)
    (hG : ∀ x, x ∈ l →
      EvalsValO orc prog M [Val.list [encA x, extra]] [] (.inl bodyF) (encB (g x)))
    (hVg : ∀ x, x ∈ l → valSize (encB (g x)) ≤ VB)
    (hM : mapB_M encA l extra VB ≤ M) :
    EvalsValO orc prog M [Val.list [encL encA l, extra]] [] (.inl (body_mapB iStep))
      (encL encB (l.map g)) := by
  have himpl := mapB_implO hO hstep hF hrev hra encA encB extra (fun a => BitProg.pure (g a)) l VB
    (fun x hx => ImplementsO.of_det (hG x hx))
    (fun x hx bits b h => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
      exact hVg x hx) hM
  exact himpl [] (l.map g) (by rw [mapB_pure]; rfl)

/-- **Nested deterministic map with the oracle** (a map of maps; e.g. a query table block by
block): the outer step calls the inner map's entry `body_mapB iIS` (stored at `iInner`) as its element
routine (its environment `[[encL encA l, extra]]` is exactly the inner input); the inner element
routine `bodyF` (environment `[[encA x, extra]]`) may call the oracle. `VL` bounds the encoded inner
results. -/
theorem mapMapP_valO (hO : prog[bsOracleIdx]? = none) {iF iIS iInner iOS : ℕ} {bodyF : Expr}
    (hOS : prog[iOS]? = some (body_mapBStep iInner))
    (hInner : prog[iInner]? = some (body_mapB iIS))
    (hIS : prog[iIS]? = some (body_mapBStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep)
    (encA : α → Val) (encB : β → Val) (extra : Val) (g : α → β) (ls : List (List α)) (VB VL : ℕ)
    (hG : ∀ l, l ∈ ls → ∀ x, x ∈ l →
      EvalsValO orc prog M [Val.list [encA x, extra]] [] (.inl bodyF) (encB (g x)))
    (hVg : ∀ l, l ∈ ls → ∀ x, x ∈ l → valSize (encB (g x)) ≤ VB)
    (hVL : ∀ l, l ∈ ls → valSize (encL encB (l.map g)) ≤ VL)
    (hMi : ∀ l, l ∈ ls → mapB_M encA l extra VB ≤ M)
    (hMo : mapB_M (encL encA) ls extra VL ≤ M) :
    EvalsValO orc prog M [Val.list [encL (encL encA) ls, extra]] [] (.inl (body_mapB iOS))
      (encL (encL encB) (ls.map (List.map g))) :=
  mapP_valO hO hOS hInner hrev hra (encL encA) (encL encB) extra (List.map g) ls VL
    (fun l hl => mapP_valO hO hIS hF hrev hra encA encB extra g l VB (hG l hl) (hVg l hl)
      (hMi l hl))
    hVL hMo

/-- Size of the encoding of a list of results bounded by `VB` (for the bound `VL` above). -/
theorem valSize_encL_le_of_forall (encB : β → Val) (l : List β) (VB : ℕ)
    (h : ∀ b ∈ l, valSize (encB b) ≤ VB) :
    valSize (encL encB l) ≤ 1 + l.length * (VB + 1) := by
  have := valSize_rev_map_le encB l VB h
  simpa [encL, valSize_list, listSize_reverse] using this

end SpecMap

end bsC

end F2e2e.BSpace
