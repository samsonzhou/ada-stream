import F2e2e.BSpace.O2GlueInit
import F2e2e.BSpace.O2GstAsmB
import F2e2e.BSpace.AssembleFinal

/-!
# B_space, route O2b: the top frame of the initialization program at `bsInitProg` (o2i)

Owner: e26ae4ae (W1), for the O2b technical lead 17fc0802 and W4 (`O2Inputs.implI`,
`F2e2e/BSpace/O2Assemble.lean`).

`o2i_implI`: the field `implI` of W4's `O2Inputs`, verbatim, at `mI := o2i_mI`, `τI := o2i_τI`
(`F2e2e/BSpace/O2GlueInit.lean`): the generic top frame `o2i_bsInit_implF` at `prog = bsInitProg`,
`orc = nullOracle`, with
* `adaPub` (600) at `bsPubBound` (W2's `bsPub_eval`, lifted by C-BANK's `o2m_pubAt_of_lift`) with budget
  `81 · bsPubBound`;
* `bsBlocks` (900) by W3's `o2k_bsBlocks_callF`;
* `adaInit` (601) at `o2MA A = 2^8 tightA A + cAddA A` (W4's tight spec `adaInit_impl_t` under `TightM`, lifted by
  `o2i_initAt_of_lift`) with budget `114 · o2MA A`.
The budgets `C = w − (depth + 3)` come from O2B-GST's weight certificate `bsWeightOK_init` (`bsW_vals`:
`w 600 = 135`, `w 601 = 137`; depths `51`, `20`): `o2i_callees_adaPub`, `o2i_callees_adaInit`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The entries and the weights of the callees -/

theorem o2i_init_600 : bsInitProg[Idx.adaPub]? = some body_adaPub :=
  bsLib_init.pub (Idx.adaPub, body_adaPub) (List.mem_append_right _ (by simp [adaPubTable]))

theorem o2i_init_601 : bsInitProg[Idx.adaInit]? = some body_adaInit :=
  bsLib_init.w4Lib.tbl (e := (_, body_adaInit)) (by simp [w4Table])

/-- The callees of `body_adaPub` weigh `≤ 81 = w 600 − (51 + 3)` in the initialization program. -/
theorem o2i_callees_adaPub : CalleesLe bsWInit 81 body_adaPub := by
  have h := (bsWeightOK_init Idx.adaPub body_adaPub o2i_init_600).2
  have hw : bsWInit Idx.adaPub = 135 := by
    rw [bsWInit_eq_bsWRound (by decide)]
    exact bsW_vals.1
  rw [hw, o2m_depth_adaPub] at h
  exact h

/-- The callees of `body_adaInit` weigh `≤ 114 = w 601 − (20 + 3)` in the initialization program. -/
theorem o2i_callees_adaInit : CalleesLe bsWInit 114 body_adaInit := by
  have h := (bsWeightOK_init Idx.adaInit body_adaInit o2i_init_601).2
  have hw : bsWInit Idx.adaInit = 137 := by
    rw [bsWInit_eq_bsWRound (by decide)]
    exact bsW_vals.2.1
  rw [hw, o2i_depth_adaInit] at h
  exact h

/-! ## `implI` -/

set_option maxHeartbeats 1000000 in
/-- **The initialization program implements the core initialization at `(o2i_mI, o2i_τI)`** (the field
`implI` of `O2Inputs`): on `[encVParams M J R a_req ξ_req, encRecords code s]`, `body_bsInit` implements
`adaInit A` (`A = asmParams M J R a_req ξ_req`) with the state encoding `bsStateEnc (asmBlocks A code s)`. -/
theorem o2i_implI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U),
      ImplementsF nullOracle bsInitProg (o2i_mI M J R aReq ξReq bU) (o2i_τI M J R aReq ξReq bU)
        [Val.list [encVParams M J R aReq ξReq, encRecords code s]] body_bsInit
        (bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s)) (adaInit (asmParams M J R aReq ξReq)) := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U _ bU code _ hcode s
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  have hlen := asm_codes_length M J R ha0 ha1 hξ0 hξ1 code s
  have hc := asm_codes_lt hcode s
  have hbs := bsP_blockSizes_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hT := bsP_Tmax_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hvC : valSize (encL encN (List.ofFn (code ∘ s))) ≤
      o2iRecB (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R) bU := by
    have h := valSize_codes_le hc
    rw [hlen] at h
    unfold o2iRecB
    omega
  have hPub := o2m_pubAt_of_lift (orc := nullOracle) (Mc := M) (J := J) (R := R) bsInitProg_oracle
    bsWeightOK_init bsLib_init.pub (bsLib_init.normQ _) h4 h2 le_rfl o2i_callees_adaPub
  have hpubM : valSize (adaPubEnc (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R)) ≤
      o2MA (adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R) :=
    (valSize_adaPubEnc_le_t _ hbs hT).trans
      ((Nat.le_mul_of_pos_left _ (by positivity)).trans (Nat.le_add_right _ _))
  have hInit := o2i_initAt_of_lift (orc := nullOracle) bsInitProg_oracle bsWeightOK_init o2i_init_601
    (adaInit_impl_t bsLib_init.w4Lib.samp bsLib_init.w4Lib.list bsLib_init.w4Lib.init hbs hT
      (o2MA_tightM _)) hpubM o2i_callees_adaInit
  rw [bsB_encRecords]
  refine o2i_bsInit_implF bsInitProg_oracle bsLib_init.blocks hlen hvC hPub hInit le_rfl ?_ ?_ ?_
  · unfold o2i_τI o2iTopT
    rw [o2m_depth_adaPub]
    exact le_max_of_le_left (by omega)
  · unfold o2i_τI o2iTopT
    exact le_max_of_le_right (le_max_of_le_left le_rfl)
  · unfold o2i_τI o2iTopT
    rw [o2i_depth_adaInit]
    exact le_max_of_le_right (le_max_of_le_right (by omega))

end F2e2e.BSpace
