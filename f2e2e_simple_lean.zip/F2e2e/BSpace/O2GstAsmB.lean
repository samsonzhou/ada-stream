import F2e2e.BSpace.AsmRank
import F2e2e.BSpace.O2GstLiftW
import F2e2e.BSpace.O2GstAsm
import F2e2e.BSpace.O2GstLiftQ

/-!
# B_space, route O2b: weight certificates and the per-call GST + bridge for the two B programs

Owner: O2B-GST (8cf19cc0), for the O2b technical lead 17fc0802. Instantiates the generic results of
`F2e2e/BSpace/O2GstLiftW.lean` (kernel-computed weights) and `F2e2e/BSpace/O2GstAsm.lean` (per-call GST + additive
bridge) at the B programs `bsInitProg = mkProg body_bsInit bsTable`, `bsRoundProg = mkProg body_bsRound bsTable`
(NEW-B's `F2e2e/BSpace/AsmTable.lean`, rank certificates `bsRankOK_init` / `bsRankOK_round` of
`F2e2e/BSpace/AsmRank.lean`).

* **Weights** `bsWInit`, `bsWRound` (one memo `bsWMemo` of the table, computed by the kernel) and the certificates
  `bsWeightOK_init : WeightOK bsInitProg bsWInit`, `bsWeightOK_round : WeightOK bsRoundProg bsWRound`
  (`decide +kernel`, small numerals only). Values on the current tables (`bsW_vals`): the routines called by the
  entry bodies have weights `600 ↦ 135`, `601 ↦ 137`, `602 ↦ 231`, `603 ↦ 240`, `900 ↦ 32`, `910 ↦ 51`,
  `920 ↦ 38`; the entry points `bsWInit 0 = 148`, `bsWRound 0 = 258` (versus `(r₀ + 1)(K + 3) = 16 · 63 = 1008`
  of the rank certificate). A call of the routine `j` proved at a uniform bound `M` costs `w j · M` in the caller's
  budget (`EvalsValF.call_wt`, `implementsF_call_det_wt`, …, `F2e2e/BSpace/O2GstLiftCalc.lean`).
* **Runs**: `bsInit_runsWithinBitsO`, `bsRound_runsWithinBitsO` (native `ImplementsF` specs of the entry bodies at
  `(m, τ)` give `RunsWithinBitsO` within `bridgeAdd prog (bsRank 0) (c · m + τ)` with `c = exprDepth body + 3`,
  i.e. `11` for init and `18` for round), and the uniform-`M` forms `bsInit_runsWithinBitsO_unif`,
  `bsRound_runsWithinBitsO_unif` (peak `bsWInit 0 · M`, `bsWRound 0 · M`).
* **Precise peak certificates** (`F2e2e/BSpace/O2GstLiftQ.lean`): `bsQOK_init : QOK bsInitProg bsQInit`,
  `bsQOK_round : QOK bsRoundProg bsQRound`; coefficients `bsQ_vals`: `600 ↦ 63`, `601 ↦ 23`, `602 ↦ 33`,
  `603 ↦ 32`, `900 ↦ 10`, `910 ↦ 10`, `920 ↦ 18`, and both entry bodies `64` (`bsQ_entry`). Uniform runs with
  the precise GST: `bsInit_runsWithinBitsO_q`, `bsRound_runsWithinBitsO_q` (peak `|input| + 64 · M`).

If a table changes, `bsW_vals` (the numerals) may need an update; the certificates themselves follow the table.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

/-! ## The weights of the B programs -/

/-- The weights of all routines of `bsTable` (computed by the kernel). -/
def bsWMemo : O2wTrie ℕ := o2wMemo bsTable

/-- **The weights of the initialization program** (`wProgOf`: the entry body at index `0`, the table elsewhere). -/
def bsWInit : ℕ → ℕ := wProgOf bsWMemo body_bsInit

/-- **The weights of the round program.** -/
def bsWRound : ℕ → ℕ := wProgOf bsWMemo body_bsRound

/-- **Weight certificate of the initialization program.** -/
theorem bsWeightOK_init : WeightOK bsInitProg bsWInit :=
  weightOK_of_check bsWMemo (by decide +kernel)

/-- **Weight certificate of the round program.** -/
theorem bsWeightOK_round : WeightOK bsRoundProg bsWRound :=
  weightOK_of_check bsWMemo (by decide +kernel)

/-- Away from the entry point both programs have the same weights. -/
theorem bsWInit_eq_bsWRound {j : ℕ} (hj : j ≠ 0) : bsWInit j = bsWRound j := by
  simp only [bsWInit, bsWRound, wProgOf, if_neg hj]

/-- **The weights on the current tables**: the routines called by the entry bodies (`body_bsInit` calls
`600, 900, 601`; `body_bsRound` calls `600, 910, 920, 602, 603`) and the entry points. -/
theorem bsW_vals : bsWRound 600 = 135 ∧ bsWRound 601 = 137 ∧ bsWRound 602 = 231 ∧ bsWRound 603 = 240 ∧
    bsWRound 900 = 32 ∧ bsWRound 910 = 51 ∧ bsWRound 920 = 38 ∧ bsWInit 0 = 148 ∧ bsWRound 0 = 258 := by
  decide +kernel

/-- The depths of the entry bodies. -/
theorem bs_entry_depths : exprDepth body_bsInit = 8 ∧ exprDepth body_bsRound = 15 := by
  decide +kernel

/-! ## Runs of the B programs: per-call GST + additive bridge -/

/-- **Initialization run** from a native `ImplementsF` spec of `body_bsInit` at `(m, τ)` (input `≤ m`): every run
`p.run tape = some (a, rest)` is a run of the oracle machine within `bridgeAdd bsInitProg (bsRank 0) (11 · m + τ)`
bits. -/
theorem bsInit_runsWithinBitsO {orc : ℤ → ℤ → ℤ → ℤ} {m τ : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsF orc bsInitProg m τ [input] body_bsInit enc p) (hin : valSize input ≤ m)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsInitProg input tape (enc a) rest
      ((O2B.bridgeAdd bsInitProg (bsRank 0) (11 * m + τ) : ℕ) : ℝ) := by
  have := ImplementsF.runsWithinBitsO bsRankOK_init bsInitProg_zero h hin hrun
  rwa [bs_entry_depths.1] at this

/-- **Round run** from a native `ImplementsF` spec of `body_bsRound` at `(m, τ)` (input `≤ m`): every run
`p.run tape = some (a, rest)` is a run of the oracle machine within `bridgeAdd bsRoundProg (bsRank 0) (18 · m + τ)`
bits. -/
theorem bsRound_runsWithinBitsO {orc : ℤ → ℤ → ℤ → ℤ} {m τ : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsF orc bsRoundProg m τ [input] body_bsRound enc p) (hin : valSize input ≤ m)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsRoundProg input tape (enc a) rest
      ((O2B.bridgeAdd bsRoundProg (bsRank 0) (18 * m + τ) : ℕ) : ℝ) := by
  have := ImplementsF.runsWithinBitsO bsRankOK_round bsRoundProg_zero h hin hrun
  rwa [bs_entry_depths.2] at this

/-- **Initialization run, uniform bound**: from an `ImplementsO` spec of `body_bsInit` at the uniform bound `M`
(input `≤ M`), within `bridgeAdd bsInitProg (bsRank 0) (bsWInit 0 · M)` bits (`bsWInit 0 = 148`). -/
theorem bsInit_runsWithinBitsO_unif {orc : ℤ → ℤ → ℤ → ℤ} {M : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsO orc bsInitProg M [input] body_bsInit enc p) (hin : valSize input ≤ M)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsInitProg input tape (enc a) rest
      ((O2B.bridgeAdd bsInitProg (bsRank 0) (bsWInit 0 * M) : ℕ) : ℝ) :=
  ImplementsO.runsWithinBitsO_add_wt bsRankOK_init bsWeightOK_init bsInitProg_zero h hin hrun

/-- **Round run, uniform bound**: from an `ImplementsO` spec of `body_bsRound` at the uniform bound `M`
(input `≤ M`), within `bridgeAdd bsRoundProg (bsRank 0) (bsWRound 0 · M)` bits (`bsWRound 0 = 258`). -/
theorem bsRound_runsWithinBitsO_unif {orc : ℤ → ℤ → ℤ → ℤ} {M : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsO orc bsRoundProg M [input] body_bsRound enc p) (hin : valSize input ≤ M)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsRoundProg input tape (enc a) rest
      ((O2B.bridgeAdd bsRoundProg (bsRank 0) (bsWRound 0 * M) : ℕ) : ℝ) :=
  ImplementsO.runsWithinBitsO_add_wt bsRankOK_round bsWeightOK_round bsRoundProg_zero h hin hrun

/-! ## Precise peak certificates of the B programs -/

/-- The precise peak coefficients of all routines of `bsTable` (computed by the kernel). -/
def bsQMemo : O2wTrie ℕ := o2qMemo bsTable

/-- **The precise peak coefficients of the initialization program.** -/
def bsQInit : ℕ → ℕ := qProgOf bsQMemo body_bsInit

/-- **The precise peak coefficients of the round program.** -/
def bsQRound : ℕ → ℕ := qProgOf bsQMemo body_bsRound

/-- **Peak certificate of the initialization program.** -/
theorem bsQOK_init : QOK bsInitProg bsQInit :=
  qOK_of_check bsQMemo (by decide +kernel)

/-- **Peak certificate of the round program.** -/
theorem bsQOK_round : QOK bsRoundProg bsQRound :=
  qOK_of_check bsQMemo (by decide +kernel)

/-- **The precise peak coefficients on the current tables** (the routines called by the entry bodies). -/
theorem bsQ_vals : bsQRound 600 = 63 ∧ bsQRound 601 = 23 ∧ bsQRound 602 = 33 ∧ bsQRound 603 = 32 ∧
    bsQRound 900 = 10 ∧ bsQRound 910 = 10 ∧ bsQRound 920 = 18 := by
  decide +kernel

/-- The precise peak coefficients of the entry bodies. -/
theorem bsQ_entry : qCoef bsQInit body_bsInit = 64 ∧ qCoef bsQRound body_bsRound = 64 := by
  decide +kernel

/-- **Initialization run, uniform bound, precise GST**: from an `ImplementsO` spec of `body_bsInit` at the uniform
bound `M` (input `≤ M`), within `bridgeAdd bsInitProg (bsRank 0) (|input| + 64 · M)` bits. -/
theorem bsInit_runsWithinBitsO_q {orc : ℤ → ℤ → ℤ → ℤ} {M : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsO orc bsInitProg M [input] body_bsInit enc p) (hin : valSize input ≤ M)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsInitProg input tape (enc a) rest
      ((O2B.bridgeAdd bsInitProg (bsRank 0) (valSize input + 64 * M) : ℕ) : ℝ) := by
  have := ImplementsO.runsWithinBitsO_add_q bsRankOK_init bsQOK_init bsInitProg_zero h hin hrun
  rwa [bsQ_entry.1] at this

/-- **Round run, uniform bound, precise GST**: from an `ImplementsO` spec of `body_bsRound` at the uniform bound
`M` (input `≤ M`), within `bridgeAdd bsRoundProg (bsRank 0) (|input| + 64 · M)` bits. -/
theorem bsRound_runsWithinBitsO_q {orc : ℤ → ℤ → ℤ → ℤ} {M : ℕ} {input : Val} {α : Type} {enc : α → Val}
    {p : BitProg α} (h : ImplementsO orc bsRoundProg M [input] body_bsRound enc p) (hin : valSize input ≤ M)
    {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsWithinBitsO orc bsRoundProg input tape (enc a) rest
      ((O2B.bridgeAdd bsRoundProg (bsRank 0) (valSize input + 64 * M) : ℕ) : ℝ) := by
  have := ImplementsO.runsWithinBitsO_add_q bsRankOK_round bsQOK_round bsRoundProg_zero h hin hrun
  rwa [bsQ_entry.2] at this

end F2e2e.BSpace
