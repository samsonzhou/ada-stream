import F2e2e.BSpace.CalcORules
import F2e2e.Cost.Lib.MapIdx

/-!
# B_space: the indexed map with oracle-calling element routines (DSL-CALC, `bsC`)

Oracle versions of the indexed-map combinator of `F2e2e/Cost/Lib/MapIdx.lean`, with the SAME DSL bodies
(`body_mapIdxStep iF`, `body_mapIdx iStep`), so tables are shared between (C) and B:

* `bsC.mapIdxB_implO` : if the element routine `iF` (environment `[[i, x, extra]]`) implements every
  `f i x` in `ImplementsO` form (it may call the oracle), then `body_mapIdx iStep` implements
  `mapIdxB f l` (results in order, encoding `encL encB`);
* `bsC.mapIdx_valO` : the deterministic version (`EvalsValO` with no fresh bits; result
  `encL encB (mapIdxFrom g 0 l)`); with `mapIdxFrom_map`/`modifyAtL_eq`/… it covers plain maps,
  nested maps (element routine = another `mapIdx`) and list updates;
* `bsC.quad` (`eQuad`), and the step lemmas `bsC.mapIdxStep_nil_valO`, `bsC.mapIdxStep_cons_valO`.

Hypotheses as in the (C) versions plus `hO : prog[bsOracleIdx]? = none`; value bound `mapIdx_M`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

namespace bsC

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

theorem quad {env : List Val} {a b c d : Expr} {ba bb bc bd : List Bool} {x y z w : Val}
    (ha : EvalsValO orc prog M env ba (.inl a) x) (hb : EvalsValO orc prog M env bb (.inl b) y)
    (hc : EvalsValO orc prog M env bc (.inl c) z) (hd : EvalsValO orc prog M env bd (.inl d) w)
    (hM : valSize (Val.list [x, y, z, w]) ≤ M) :
    EvalsValO orc prog M env (ba ++ (bb ++ (bc ++ bd))) (.inl (eQuad a b c d))
      (Val.list [x, y, z, w]) := by
  simp only [valSize_list, listSize_cons, listSize_nil] at hM
  have h0 := EvalsValO.nil (orc := orc) (prog := prog) (M := M) (env := env)
    (by simp only [valSize_list, listSize_nil]; omega)
  have h1 := EvalsValO.cons hd h0
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  rw [List.append_nil] at h1
  have h2 := EvalsValO.cons hc h1
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  have h3 := EvalsValO.cons hb h2
    (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)
  exact EvalsValO.cons ha h3 (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)

theorem mapIdxStep_nil_valO (hO : prog[bsOracleIdx]? = none) (iF : ℕ) (i : ℤ) (av extra : Val)
    (hM : 2 * valSize (Val.list [Val.int i, Val.list [], av, extra]) + 10 ≤ M) :
    EvalsValO orc prog M [Val.list [Val.int i, Val.list [], av, extra]] []
      (.inl (body_mapIdxStep iF)) (Val.list [Val.int 0, av]) :=
  lift hO (mapIdxStep_nil_val iF i av extra hM)

theorem mapIdxStep_cons_valO (hO : prog[bsOracleIdx]? = none) {iF : ℕ} {bodyF : Expr}
    (hF : prog[iF]? = some bodyF) {i : ℤ} {x extra bv : Val} {R A : List Val} {b1 : List Bool}
    (hcall : EvalsValO orc prog M [Val.list [Val.int i, x, extra]] b1 (.inl bodyF) bv)
    (hM : valSize (Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]) + valSize bv +
      bitLen (i + 1) + 12 ≤ M) :
    EvalsValO orc prog M [Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]] b1
      (.inl (body_mapIdxStep iF))
      (Val.list [Val.int 1, Val.list [Val.int (i + 1), Val.list R, Val.list (bv :: A), extra]]) := by
  simp only [valSize_list, valSize_int, listSize_cons, listSize_nil] at hM
  have hacc : ∀ {E : List Val}, EvalsValO orc prog M (Val.list (x :: R) ::
      Val.list [Val.int i, Val.list (x :: R), Val.list A, extra] :: E) [] (.inl (Expr.var 1))
      (Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]) := var1
  have h1 : EvalsValO orc prog M [Val.list [Val.int i, Val.list (x :: R), Val.list A, extra]] []
      (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))) (Val.list (x :: R)) :=
    EvalsValO.head (EvalsValO.tail var0
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons]; omega)
  have hc : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.isNil (Expr.var 0))) (Val.int 0) :=
    isNil_cons var0 (by omega)
  have hi : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.head (Expr.var 1))) (Val.int i) :=
    EvalsValO.head hacc (by simp only [valSize_int]; omega)
  have hex : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (eFourth (Expr.var 1))) extra :=
    EvalsValO.head (EvalsValO.tail (EvalsValO.tail (EvalsValO.tail hacc
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega)
  have hA : EvalsValO orc prog M [Val.list (x :: R), Val.list [Val.int i, Val.list (x :: R),
      Val.list A, extra]] [] (.inl (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail
      (Expr.var 1))))) (Val.list A) :=
    EvalsValO.head (EvalsValO.tail (EvalsValO.tail hacc
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list, listSize_cons, listSize_nil]; omega))
      (by simp only [valSize_list]; omega)
  have hargs := triple hi (EvalsValO.head var0 (by omega)) hex
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  have hcall' := call hO hargs hF hcall
  have hcons := EvalsValO.cons hcall' hA (by simp only [valSize_list, listSize_cons]; omega)
  have hi1 := add hi (lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega))
    (by simp only [valSize_int]; omega)
  have hq := quad hi1 (EvalsValO.tail var0 (by simp only [valSize_list]; omega))
    hcons hex (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)
  have hf := EvalsValO.pair (lit' (z := 1) (by simp only [valSize_int, bitLen_one]; omega))
    hq (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]; omega)
  have := EvalsValO.letE h1 (ite_false (t := ePair (Expr.lit 0)
    (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.un UnOp.tail (Expr.var 1))))) hc rfl hf)
  simpa [body_mapIdxStep] using this

section Spec

variable {α β : Type}

theorem mapIdx_loopO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapIdxStep iF)) (hF : prog[iF]? = some bodyF)
    (encA : α → Val) (encB : β → Val) (extra : Val) (f : ℕ → α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ i x, x ∈ l → i < l.length →
      ImplementsO orc prog M [Val.list [Val.int (i : ℤ), encA x, extra]] bodyF encB (f i x))
    (hVb : ∀ i x, x ∈ l → ∀ bits b, (f i x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    ∀ r : List α, r <:+ l → ∀ done : List β, done.length + r.length = l.length →
      (∀ b ∈ done, valSize (encB b) ≤ VB) → ∀ bits bs,
      (mapIdxBFrom f done.length r).run bits = some (bs, []) →
      EvalsValO orc prog M [] bits
        (.inr (iStep, Val.list [Val.int (done.length : ℤ), encL encA r,
          Val.list (done.map encB).reverse, extra]))
        (Val.list ((done ++ bs).map encB).reverse) := by
  intro r
  induction r with
  | nil =>
    intro _ done hlen hdone bits bs h
    obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h
    have hA := valSize_rev_map_le encB done VB hdone
    simp only [List.length_nil, Nat.add_zero] at hlen
    have hi : bitLen (done.length : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le (by omega)
    refine EvalsValO.stop hstep ?_
    simp only [encL_nil, List.append_nil]
    refine mapIdxStep_nil_valO hO iF _ _ extra ?_
    simp only [mapIdx_M, valSize_list, valSize_int, listSize_cons, listSize_nil] at hM hA ⊢
    rw [hlen] at hA
    omega
  | cons x r ih =>
    intro hsuf done hlen hdone bits bs h
    have hx : x ∈ l := hsuf.subset List.mem_cons_self
    have hsuf' : r <:+ l := (List.suffix_cons x r).trans hsuf
    obtain ⟨b₁, b₂, b, bs', rfl, h1, h2, rfl⟩ := mapIdxBFrom_cons_run_exact h
    have hdl : done.length < l.length := by simp only [List.length_cons] at hlen; omega
    have hb := hVb done.length x hx b₁ b h1
    have hcall := hFi done.length x hx hdl b₁ b h1
    have hdone' : ∀ c ∈ done ++ [b], valSize (encB c) ≤ VB := by
      intro c hc
      rcases List.mem_append.mp hc with hc | hc
      · exact hdone c hc
      · rw [List.mem_singleton.mp hc]; exact hb
    have hlen' : (done ++ [b]).length + r.length = l.length := by
      simp only [List.length_append, List.length_cons, List.length_nil] at hlen ⊢
      omega
    have h2' : (mapIdxBFrom f (done ++ [b]).length r).run b₂ = some (bs', []) := by
      simpa using h2
    have hrest := ih hsuf' (done ++ [b]) hlen' hdone' b₂ bs' h2'
    have hA := valSize_rev_map_le encB done VB hdone
    have hR : listSize ((x :: r).map encA) ≤ listSize (l.map encA) :=
      listSize_le_of_suffix (hsuf.map encA)
    have hi1 : bitLen ((done.length : ℤ) + 1) ≤ Nat.size l.length := by
      have := bitLen_le_size_of_le (show done.length + 1 ≤ l.length by omega)
      push_cast at this
      exact this
    have hi0 : bitLen (done.length : ℤ) ≤ Nat.size l.length := bitLen_le_size_of_le hdl.le
    have hbody := mapIdxStep_cons_valO hO (R := r.map encA) (A := (done.map encB).reverse) hF
      hcall (by
        simp only [mapIdx_M, encL, valSize_list, valSize_int, listSize_cons, listSize_nil,
          List.map_cons] at hM hR hA ⊢
        have : done.length * (VB + 1) ≤ l.length * (VB + 1) := Nat.mul_le_mul_right _ hdl.le
        omega)
    have hval : ((done ++ b :: bs').map encB).reverse =
        (((done ++ [b]) ++ bs').map encB).reverse := by simp
    have hacc : Val.list (encB b :: (done.map encB).reverse) =
        Val.list ((done ++ [b]).map encB).reverse := by simp
    have hidx : Val.int ((done.length : ℤ) + 1) = Val.int (((done ++ [b]).length : ℕ) : ℤ) := by
      simp
    rw [hval]
    rw [hacc, hidx] at hbody
    exact EvalsValO.cont hstep hbody one_ne_zero hrest

/-- **Spec of `mapIdxB` with the oracle** (`ImplementsO` form): the results in order. -/
theorem mapIdxB_implO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapIdxStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (f : ℕ → α → BitProg β) (l : List α) (VB : ℕ)
    (hFi : ∀ i x, x ∈ l → i < l.length →
      ImplementsO orc prog M [Val.list [Val.int (i : ℤ), encA x, extra]] bodyF encB (f i x))
    (hVb : ∀ i x, x ∈ l → ∀ bits b, (f i x).run bits = some (b, []) → valSize (encB b) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    ImplementsO orc prog M [Val.list [encL encA l, extra]] (body_mapIdx iStep) (encL encB)
      (mapIdxB f l) := by
  intro bits bs h
  have hloop := mapIdx_loopO hO hstep hF encA encB extra f l VB hFi hVb hM l (List.suffix_refl l)
    [] (by simp) (by simp) bits bs (by simpa [mapIdxB] using h)
  simp only [List.map_nil, List.reverse_nil, List.nil_append, List.length_nil,
    Nat.cast_zero] at hloop
  have hL := valSize_encL_ge encA l
  have hinit : EvalsVal prog M [Val.list [encL encA l, extra]] []
      (.inl (eQuad (Expr.lit 0) (Expr.un UnOp.head (Expr.var 0)) Expr.nil
        (Expr.un UnOp.head (Expr.un UnOp.tail (Expr.var 0)))))
      (Val.list [Val.int 0, encL encA l, Val.list [], extra]) := by
    simp only [mapIdx_M] at hM
    have := EvalsVal.quad (EvalsVal.lit' (prog := prog) (M := M)
      (env := [Val.list [encL encA l, extra]]) (z := 0) (by simp; omega))
      (EvalsVal.head EvalsVal.var0 (by omega))
      (EvalsVal.nil (by simp; omega))
      (EvalsVal.head (EvalsVal.tail EvalsVal.var0
        (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) (by omega))
      (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega)
    simpa using this
  have hl := EvalsValO.loop (lift hO hinit) hloop
  have hrs := (reverse_spec hra (bs.map encB).reverse 0).toVal
  rw [List.reverse_reverse] at hrs
  obtain ⟨hlen, hBs⟩ := mapIdxBFrom_run_results encB l 0 bits bs hVb (by simpa [mapIdxB] using h)
  have hsz := valSize_rev_map_le encB bs VB hBs
  have hcall := call hO hl hrev (lift hO (hrs.mono_M (by
    simp only [S_reverse, mapIdx_M] at hM ⊢
    rw [hlen] at hsz
    omega)))
  simpa [encL, body_mapIdx] using hcall

/-- **Spec of the deterministic indexed map with the oracle** (`mapIdxFrom g 0 l`). -/
theorem mapIdx_valO (hO : prog[bsOracleIdx]? = none) {iF iStep : ℕ} {bodyF : Expr}
    (hstep : prog[iStep]? = some (body_mapIdxStep iF)) (hF : prog[iF]? = some bodyF)
    (hrev : prog[Idx.reverse]? = some body_reverse)
    (hra : prog[Idx.revAppendStep]? = some body_revAppendStep) (encA : α → Val) (encB : β → Val)
    (extra : Val) (g : ℕ → α → β) (l : List α) (VB : ℕ)
    (hG : ∀ i x, x ∈ l → i < l.length →
      EvalsValO orc prog M [Val.list [Val.int (i : ℤ), encA x, extra]] [] (.inl bodyF)
        (encB (g i x)))
    (hVg : ∀ i x, x ∈ l → valSize (encB (g i x)) ≤ VB)
    (hM : mapIdx_M encA l extra VB ≤ M) :
    EvalsValO orc prog M [Val.list [encL encA l, extra]] [] (.inl (body_mapIdx iStep))
      (encL encB (mapIdxFrom g 0 l)) := by
  have himpl := mapIdxB_implO hO hstep hF hrev hra encA encB extra
    (fun i a => BitProg.pure (g i a)) l VB
    (fun i x hx hi => ImplementsO.of_det (hG i x hx hi))
    (fun i x hx bits b h => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp h
      exact hVg i x hx) hM
  exact himpl [] (mapIdxFrom g 0 l) (by rw [mapIdxB, mapIdxB_pure]; rfl)

end Spec

end bsC

/-- A plain map is an indexed map ignoring the index. -/
theorem mapIdxFrom_map {α β : Type} (g : α → β) :
    ∀ (i : ℕ) (l : List α), mapIdxFrom (fun _ a => g a) i l = l.map g
  | _, [] => rfl
  | i, x :: xs => by simp [mapIdxFrom, mapIdxFrom_map g (i + 1) xs]

end F2e2e.BSpace
