import F2e2e.BSpace.O2GstLift

/-!
# B_space, route O2b, layer (i): the calculus of the per-call judgment `EvalsValF`

Owner: O2B-GST (8cf19cc0); the home of the `EvalsValF` / `ImplementsF` calculus (agreed with C-SPACE, owner of
the core `F2e2e/BSpace/O2GstF.lean`). Rules for NATIVE per-call proofs (the frames that hold the big B state,
route O2b layer (iii)), on top of the core and the liftings of `F2e2e/BSpace/O2GstLift.lean`. Modelled on the
uniform calculus (`F2e2e/Cost/ValRules.lean`, `F2e2e/Cost/BitProgBridge.lean`,
`F2e2e/BSpace/MachineEvalsO.lean`, C-TOP's call rules in `F2e2e/C/Impl/W6Contracts.lean`).

* Derived `EvalsValF` rules: `var0`–`var2`, `head`, `tail`, `cons`, `pair`, `oracle_det`, `call_le` (callee
  bound `m' ≤ m`: the result bound is automatic), the loop rule with an explicit body `EvalsValF.loop'`, and
  `EvalsValF.loop_of_measure` (the measure rule for native loops).
* Call rules for deterministic routines: `evalsValF_call_det` (any callee bound, explicit result bound),
  `evalsValF_call_det_le` (`m' ≤ m`).
* `ImplementsF` calculus: `mono`, `mono_m`, `mono_τ`, `coin`, `of_det`, `letE`, `congr`,
  `implementsF_letE_of` (support condition), `implementsF_letE_of_run`, `implementsF_letE_det`; call rules
  `implementsF_call` (support predicate, any callee bound, result bound on the actual outputs),
  `implementsF_call_le` (support predicate, `m' ≤ m`), `implementsF_call_det` (deterministic argument, result
  bound on the outputs), `implementsF_call_det_le` (deterministic argument, `m' ≤ m`).
* Calls of routines proved at a uniform bound `M` (the ADA routines), from a native frame: `EvalsValF.call_wt`,
  `evalsValF_call_det_wt`, `implementsF_call_wt`, `implementsF_call_det_wt` (weight certificate; the call costs
  `w i · M ≤ τ`; for oracle-free specs apply `EvalsValO.of_evalsVal hO` / `Implements.toO hO` first).
* Embedding of light sub-computations proved with the uniform calculus: `EvalsVal.toF_wt_le`,
  `Implements.toF_wt_le`, `ImplementsO.toF_wt_le` (weighted lifting at the frame bound, budget `C · m ≤ τ`).

In every call rule the callee runs at its OWN `(m', τ')`: argument `≤ m'`, result `≤ m`,
`(exprDepth body + 2) m' + τ' ≤ τ`. Dot notation: `ImplementsF`, `ImplementsO`, `Implements` are definitions
(`∀ …`), so write `ImplementsF.mono h hm hτ`, `Implements.toF_wt_le hO hW h henv hc hτ`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

section Rules

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ}

/-! ## Derived `EvalsValF` rules -/

theorem EvalsValF.var0 {v : Val} {rest : List Val} :
    EvalsValF orc prog m τ (v :: rest) [] (.inl (Expr.var 0)) v :=
  EvalsValF.var rfl

theorem EvalsValF.var1 {v w : Val} {rest : List Val} :
    EvalsValF orc prog m τ (v :: w :: rest) [] (.inl (Expr.var 1)) w :=
  EvalsValF.var rfl

theorem EvalsValF.var2 {v w u : Val} {rest : List Val} :
    EvalsValF orc prog m τ (v :: w :: u :: rest) [] (.inl (Expr.var 2)) u :=
  EvalsValF.var rfl

theorem EvalsValF.head {env : List Val} {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env ba (.inl a) (Val.list (x :: l))) (hM : valSize x ≤ m) :
    EvalsValF orc prog m τ env ba (.inl (Expr.un UnOp.head a)) x :=
  EvalsValF.un (c := 1) ha rfl hM

theorem EvalsValF.tail {env : List Val} {a : Expr} {ba : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env ba (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list l) ≤ m) :
    EvalsValF orc prog m τ env ba (.inl (Expr.un UnOp.tail a)) (Val.list l) :=
  EvalsValF.un (c := 1) ha rfl hM

theorem EvalsValF.cons {env : List Val} {a b : Expr} {ba bb : List Bool} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env ba (.inl a) x)
    (hb : EvalsValF orc prog m τ env bb (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ m) :
    EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.bin BinOp.cons a b)) (Val.list (x :: l)) :=
  EvalsValF.bin (c := 1) ha hb (by cases x <;> rfl) hM

/-- `ePair a b` builds `[x, y]`. -/
theorem EvalsValF.pair {env : List Val} {a b : Expr} {ba bb : List Bool} {x y : Val}
    (ha : EvalsValF orc prog m τ env ba (.inl a) x) (hb : EvalsValF orc prog m τ env bb (.inl b) y)
    (hM : valSize (Val.list [x, y]) ≤ m) :
    EvalsValF orc prog m τ env (ba ++ bb) (.inl (ePair a b)) (Val.list [x, y]) := by
  have h1 : valSize (Val.list [y]) ≤ m := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have h0 : valSize (Val.list []) ≤ m := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hM ⊢; omega
  have hin := EvalsValF.bin (op := BinOp.cons) (c := 1) hb (EvalsValF.nil h0)
    (by cases y <;> rfl) h1
  rw [List.append_nil] at hin
  exact EvalsValF.bin (c := 1) ha hin (by cases x <;> rfl) hM

/-- The oracle with a deterministic argument. -/
theorem EvalsValF.oracle_det {env : List Val} {a : Expr} {sel r q : ℤ}
    (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.list [Val.int sel, Val.int r, Val.int q]))
    (hM : valSize (Val.int (orc sel r q)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (Expr.call bsOracleIdx a)) (Val.int (orc sel r q)) :=
  EvalsValF.oracle ha hM

/-- A call whose callee bound `m'` is at most the caller's bound: the result bound is automatic. -/
theorem EvalsValF.call_le {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
    {m' τ' : ℕ} (hi : i ≠ bsOracleIdx) (ha : EvalsValF orc prog m τ env ba (.inl a) va)
    (hbody : prog[i]? = some body) (hb : EvalsValF orc prog m' τ' [va] bb (.inl body) vb)
    (hva : valSize va ≤ m') (hm : m' ≤ m) (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.call i a)) vb :=
  EvalsValF.call hi ha hbody hb hva ((hb.val_le (by simpa using hva)).trans hm) hτ

/-- **Call rule for a deterministic routine** (callee at its own `(m', τ')`, explicit result bound). -/
theorem evalsValF_call_det {env : List Val} {argE : Expr} {x v : Val} {i : ℕ} {body : Expr}
    {m' τ' : ℕ} (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : EvalsValF orc prog m τ env [] (.inl argE) x) (hf : EvalsValF orc prog m' τ' [x] [] (.inl body) v)
    (hva : valSize x ≤ m') (hvb : valSize v ≤ m) (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (Expr.call i argE)) v := by
  simpa using EvalsValF.call hi hA hbody hf hva hvb hτ

/-- **Call rule for a deterministic routine**, callee bound `m' ≤ m` (the result bound is automatic). -/
theorem evalsValF_call_det_le {env : List Val} {argE : Expr} {x v : Val} {i : ℕ} {body : Expr}
    {m' τ' : ℕ} (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : EvalsValF orc prog m τ env [] (.inl argE) x) (hf : EvalsValF orc prog m' τ' [x] [] (.inl body) v)
    (hva : valSize x ≤ m') (hm : m' ≤ m) (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (Expr.call i argE)) v :=
  evalsValF_call_det hi hbody hA hf hva ((hf.val_le (by simpa using hva)).trans hm) hτ

/-- The loop rule with an explicit body of the looped routine. -/
theorem EvalsValF.loop' {env : List Val} {i : ℕ} {a body : Expr} {ba bl : List Bool} {va w : Val}
    {m' τ' : ℕ} (ha : EvalsValF orc prog m τ env ba (.inl a) va) (hbody : prog[i]? = some body)
    (hl : EvalsValF orc prog m' τ' [] bl (.inr (i, va)) w) (hva : valSize va ≤ m') (hw : valSize w ≤ m)
    (hτ : (exprDepth body + 3) * m' + τ' ≤ τ) :
    EvalsValF orc prog m τ env (ba ++ bl) (.inl (Expr.loop i a)) w := by
  refine EvalsValF.loop ha hl hva hw fun body' hbody' => ?_
  rw [hbody] at hbody'
  cases hbody'
  exact hτ

/-- **Loop rule (measure, with fresh bits)** for native loops: every iteration from a state `s` satisfying
`Inv` either stops with an output satisfying `Post`, consuming `bitsOf s`, or consumes a prefix `bs` with
`bitsOf s = bs ++ bitsOf s'` and continues to a state `s'` satisfying `Inv` with a smaller measure. All
iterations run at the frame bound `m` and budget `τ` of the loop. -/
theorem EvalsValF.loop_of_measure {σ : Type*} {i : ℕ} {body : Expr} (hbody : prog[i]? = some body)
    (enc : σ → Val) (bitsOf : σ → List Bool) (Inv : σ → Prop) (Post : Val → Prop) (μ : σ → ℕ)
    (hstep : ∀ s, Inv s →
      (∃ out, EvalsValF orc prog m τ [enc s] (bitsOf s) (.inl body) (Val.list [Val.int 0, out]) ∧
          Post out) ∨
      (∃ flag s' bs, flag ≠ 0 ∧ bitsOf s = bs ++ bitsOf s' ∧
          EvalsValF orc prog m τ [enc s] bs (.inl body) (Val.list [Val.int flag, enc s']) ∧ Inv s' ∧
          μ s' < μ s)) :
    ∀ s, Inv s → ∃ out, Post out ∧ EvalsValF orc prog m τ [] (bitsOf s) (.inr (i, enc s)) out := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ n ih =>
    intro hs
    rcases hstep s hs with ⟨out, hb, hpost⟩ | ⟨flag, s', bs, hflag, hbits, hb, hs', hlt⟩
    · exact ⟨out, hpost, EvalsValF.stop hbody hb⟩
    · obtain ⟨out, hpost, hrest⟩ := ih (μ s') (by omega) s' rfl hs'
      rw [hbits]
      exact ⟨out, hpost, EvalsValF.cont hbody hb hflag hrest⟩

/-! ## `ImplementsF` calculus -/

namespace ImplementsF

variable {env : List Val} {α β : Type}

/-- Monotonicity in the budget. -/
theorem mono_τ {τ' : ℕ} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsF orc prog m τ env e enc p) (hτ : τ ≤ τ') : ImplementsF orc prog m τ' env e enc p :=
  fun bits a hp => (h bits a hp).mono_τ hτ

/-- Monotonicity in the frame bound. -/
theorem mono_m {m' : ℕ} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsF orc prog m τ env e enc p) (hm : m ≤ m') : ImplementsF orc prog m' τ env e enc p :=
  fun bits a hp => (h bits a hp).mono_m hm

/-- Monotonicity in the frame bound and the budget together. -/
theorem mono {m' τ' : ℕ} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsF orc prog m τ env e enc p) (hm : m ≤ m') (hτ : τ ≤ τ') :
    ImplementsF orc prog m' τ' env e enc p :=
  fun bits a hp => ((h bits a hp).mono_m hm).mono_τ hτ

/-- `Expr.coin` implements `readBit` with the encoding `encB`. -/
theorem coin (hM : 2 ≤ m) : ImplementsF orc prog m τ env Expr.coin encB BitProg.readBit := by
  intro bits b hp
  rw [bitProg_run_readBit_exact.mp hp]
  exact EvalsValF.coin b ((valSize_encB_le b).trans hM)

/-- A deterministic evaluation implements `pure a`. -/
theorem of_det {e : Expr} {enc : α → Val} {a : α}
    (h : EvalsValF orc prog m τ env [] (.inl e) (enc a)) :
    ImplementsF orc prog m τ env e enc (BitProg.pure a) := by
  intro bits a' hp
  obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp hp
  exact h

/-- **Sequential composition.** -/
theorem letE {ea eb : Expr} {encA : α → Val} {encC : β → Val} {p : BitProg α} {f : α → BitProg β}
    (hp : ImplementsF orc prog m τ env ea encA p)
    (hf : ∀ a, ImplementsF orc prog m τ (encA a :: env) eb encC (f a)) :
    ImplementsF orc prog m τ env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValF.letE (hp b₁ a h1) (hf a b₂ c h2)

/-- Rewriting the implemented program or the encoding. -/
theorem congr {e : Expr} {enc enc' : α → Val} {p p' : BitProg α}
    (h : ImplementsF orc prog m τ env e enc p) (hp : p = p') (henc : ∀ a, enc a = enc' a) :
    ImplementsF orc prog m τ env e enc' p' := by
  subst hp
  intro bits a hr
  rw [← henc a]
  exact h bits a hr

end ImplementsF

/-- `letE` for bit programs with a support condition on the first output. -/
theorem implementsF_letE_of {α β : Type} {env : List Val} {ea eb : Expr} {encA : α → Val}
    {encC : β → Val} {p : BitProg α} {f : α → BitProg β}
    (hp : ImplementsF orc prog m τ env ea encA p) (Q : α → Prop)
    (hQ : ∀ bits a, p.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → ImplementsF orc prog m τ (encA a :: env) eb encC (f a)) :
    ImplementsF orc prog m τ env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValF.letE (hp b₁ a h1) (hf a (hQ b₁ a h1) b₂ c h2)

/-- `letE` whose continuation only needs to implement `f a` for the outputs `a` of `p`. -/
theorem implementsF_letE_of_run {α β : Type} {env : List Val} {ea eb : Expr} {encA : α → Val}
    {encC : β → Val} {p : BitProg α} {f : α → BitProg β} (hp : ImplementsF orc prog m τ env ea encA p)
    (hf : ∀ bits a, p.run bits = some (a, []) → ImplementsF orc prog m τ (encA a :: env) eb encC (f a)) :
    ImplementsF orc prog m τ env (Expr.letE ea eb) encC (p.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  exact EvalsValF.letE (hp b₁ a h1) (hf b₁ a h1 b₂ c h2)

/-- `letE` with a deterministic bound expression. -/
theorem implementsF_letE_det {β : Type} {env : List Val} {ea eb : Expr} {va : Val} {enc : β → Val}
    {p : BitProg β} (ha : EvalsValF orc prog m τ env [] (.inl ea) va)
    (hb : ImplementsF orc prog m τ (va :: env) eb enc p) :
    ImplementsF orc prog m τ env (Expr.letE ea eb) enc p := by
  intro bits c h
  simpa using EvalsValF.letE ha (hb bits c h)

/-- **Call rule** (callee form ⇒ caller form; the callee runs at its own `(m', τ')`, which may exceed the
caller's bound): the argument encodings of the outputs of `pA` satisfying the support predicate `Q` are
`≤ m'`, and the outputs of the call are `≤ m`. -/
theorem implementsF_call {α β : Type} {env : List Val} {argE : Expr} {encA : α → Val} {encB : β → Val}
    {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr} {m' τ' : ℕ} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : ImplementsF orc prog m τ env argE encA pA) (Q : α → Prop)
    (hQ : ∀ bits a, pA.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → ImplementsF orc prog m' τ' [encA a] body encB (f a))
    (hva : ∀ a, Q a → valSize (encA a) ≤ m')
    (hvb : ∀ a, Q a → ∀ bits b, (f a).run bits = some (b, []) → valSize (encB b) ≤ m)
    (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB (pA.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  have hq := hQ b₁ a h1
  exact EvalsValF.call hi (hA b₁ a h1) hbody (hf a hq b₂ c h2) (hva a hq) (hvb a hq b₂ c h2) hτ

/-- **Call rule** with a support predicate, callee bound `m' ≤ m` (the result bound is automatic). -/
theorem implementsF_call_le {α β : Type} {env : List Val} {argE : Expr} {encA : α → Val}
    {encB : β → Val} {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr} {m' τ' : ℕ}
    (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body) (hA : ImplementsF orc prog m τ env argE encA pA)
    (Q : α → Prop) (hQ : ∀ bits a, pA.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → ImplementsF orc prog m' τ' [encA a] body encB (f a))
    (hva : ∀ a, Q a → valSize (encA a) ≤ m') (hm : m' ≤ m)
    (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB (pA.bind f) :=
  implementsF_call hi hbody hA Q hQ hf hva
    (fun a hq bits b hb => ((hf a hq bits b hb).val_le (by simpa using hva a hq)).trans hm) hτ

/-- **Call rule with a deterministic argument** (callee at its own `(m', τ')`; the outputs of the call are
`≤ m`). -/
theorem implementsF_call_det {β : Type} {env : List Val} {argE : Expr} {x : Val} {encB : β → Val}
    {p : BitProg β} {i : ℕ} {body : Expr} {m' τ' : ℕ} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : EvalsValF orc prog m τ env [] (.inl argE) x)
    (hf : ImplementsF orc prog m' τ' [x] body encB p) (hva : valSize x ≤ m')
    (hvb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ m)
    (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB p := by
  intro bits c h
  simpa using EvalsValF.call hi hA hbody (hf bits c h) hva (hvb bits c h) hτ

/-- **Call rule with a deterministic argument**, callee bound `m' ≤ m`. -/
theorem implementsF_call_det_le {β : Type} {env : List Val} {argE : Expr} {x : Val} {encB : β → Val}
    {p : BitProg β} {i : ℕ} {body : Expr} {m' τ' : ℕ} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : EvalsValF orc prog m τ env [] (.inl argE) x)
    (hf : ImplementsF orc prog m' τ' [x] body encB p) (hva : valSize x ≤ m') (hm : m' ≤ m)
    (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB p :=
  implementsF_call_det hi hbody hA hf hva
    (fun bits b hb => ((hf bits b hb).val_le (by simpa using hva)).trans hm) hτ

end Rules

/-! ## Calling a routine proved at a uniform bound (weighted lifting at the call site) -/

section CallUniform

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {m τ M : ℕ}

/-- The call-site cost of a routine lifted with its weight: `(exprDepth body + 2) M + (w i − (exprDepth body + 3)) M
≤ w i · M`. -/
theorem callCost_wt_le {d wi : ℕ} (hd : d + 3 ≤ wi) : (d + 2) * M + (wi - (d + 3)) * M ≤ wi * M := by
  rw [← Nat.add_mul]
  exact Nat.mul_le_mul_right _ (by omega)

/-- **Call of a routine proved at a uniform bound `M`** from a native frame at `(m, τ)` (weight certificate):
the callee's `EvalsValO` evaluation at `M` (argument `≤ M`) is lifted at its own frame; the call costs
`w i · M ≤ τ`. -/
theorem EvalsValF.call_wt (hW : WeightOK prog w) {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool}
    {va vb : Val} (hi : i ≠ bsOracleIdx) (ha : EvalsValF orc prog m τ env ba (.inl a) va)
    (hbody : prog[i]? = some body) (hb : EvalsValO orc prog M [va] bb (.inl body) vb)
    (hva : valSize va ≤ M) (hvb : valSize vb ≤ m) (hτ : w i * M ≤ τ) :
    EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.call i a)) vb := by
  obtain ⟨hwi, hcb⟩ := hW i body hbody
  exact EvalsValF.call hi ha hbody (hb.toF_wt hW (by simpa using hva) hcb) hva hvb
    ((callCost_wt_le hwi).trans hτ)

/-- **Call of a deterministic routine proved at a uniform bound `M`**, deterministic argument. -/
theorem evalsValF_call_det_wt (hW : WeightOK prog w) {env : List Val} {argE : Expr} {x v : Val} {i : ℕ}
    {body : Expr} (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body)
    (hA : EvalsValF orc prog m τ env [] (.inl argE) x) (hf : EvalsValO orc prog M [x] [] (.inl body) v)
    (hva : valSize x ≤ M) (hvb : valSize v ≤ m) (hτ : w i * M ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (Expr.call i argE)) v := by
  simpa using EvalsValF.call_wt hW hi hA hbody hf hva hvb hτ

/-- **Call of a routine implementing `f a` at a uniform bound `M`** (`ImplementsO`), from a native frame at
`(m, τ)`: support predicate `Q` on the argument, the argument encodings `≤ M`, the outputs `≤ m`; the call costs
`w i · M ≤ τ`. -/
theorem implementsF_call_wt (hW : WeightOK prog w) {α β : Type} {env : List Val} {argE : Expr}
    {encA : α → Val} {encB : β → Val} {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr}
    (hi : i ≠ bsOracleIdx) (hbody : prog[i]? = some body) (hA : ImplementsF orc prog m τ env argE encA pA)
    (Q : α → Prop) (hQ : ∀ bits a, pA.run bits = some (a, []) → Q a)
    (hf : ∀ a, Q a → ImplementsO orc prog M [encA a] body encB (f a))
    (hva : ∀ a, Q a → valSize (encA a) ≤ M)
    (hvb : ∀ a, Q a → ∀ bits b, (f a).run bits = some (b, []) → valSize (encB b) ≤ m)
    (hτ : w i * M ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB (pA.bind f) := by
  intro bits c h
  obtain ⟨b₁, b₂, a, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp h
  have hq := hQ b₁ a h1
  exact EvalsValF.call_wt hW hi (hA b₁ a h1) hbody (hf a hq b₂ c h2) (hva a hq) (hvb a hq b₂ c h2) hτ

/-- **Call of a routine implementing `p` at a uniform bound `M`** (`ImplementsO`), deterministic argument. -/
theorem implementsF_call_det_wt (hW : WeightOK prog w) {β : Type} {env : List Val} {argE : Expr} {x : Val}
    {encB : β → Val} {p : BitProg β} {i : ℕ} {body : Expr} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (hA : EvalsValF orc prog m τ env [] (.inl argE) x)
    (hf : ImplementsO orc prog M [x] body encB p) (hva : valSize x ≤ M)
    (hvb : ∀ bits b, p.run bits = some (b, []) → valSize (encB b) ≤ m) (hτ : w i * M ≤ τ) :
    ImplementsF orc prog m τ env (Expr.call i argE) encB p := by
  intro bits c h
  simpa using EvalsValF.call_wt hW hi hA hbody (hf bits c h) hva (hvb bits c h) hτ

end CallUniform

/-! ## Embedding light sub-computations proved with the uniform calculus -/

/-- A uniform oracle-free evaluation at the frame bound `M` whose callees have weight `≤ C` embeds into a
frame with budget `τ ≥ C · M` (no body at the oracle index). -/
theorem EvalsVal.toF_wt_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w) {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ x ∈ env, valSize x ≤ M)
    {C τ : ℕ} (hc : CalleesLe w C e) (hτ : C * M ≤ τ) : EvalsValF orc prog M τ env bits (.inl e) v :=
  (EvalsVal.toF_wt hO hW h henv hc).mono_τ hτ

/-- `ImplementsO` at the frame bound embeds into a frame with budget `τ ≥ C · M`. -/
theorem ImplementsO.toF_wt_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {env : List Val} {α : Type} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsO orc prog M env e enc p) (henv : ∀ x ∈ env, valSize x ≤ M) {C τ : ℕ}
    (hc : CalleesLe w C e) (hτ : C * M ≤ τ) : ImplementsF orc prog M τ env e enc p :=
  ImplementsF.mono_τ (ImplementsO.toF_wt hW h henv hc) hτ

/-- `Implements` at the frame bound embeds into a frame with budget `τ ≥ C · M` (no body at the oracle
index). -/
theorem Implements.toF_wt_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w) {env : List Val} {α : Type} {e : Expr}
    {enc : α → Val} {p : BitProg α} (h : Implements prog M env e enc p)
    (henv : ∀ x ∈ env, valSize x ≤ M) {C τ : ℕ} (hc : CalleesLe w C e) (hτ : C * M ≤ τ) :
    ImplementsF orc prog M τ env e enc p :=
  ImplementsF.mono_τ (Implements.toF_wt hO hW h henv hc) hτ

end F2e2e.BSpace
