import F2e2e.BSpace.O2TightSizes

/-!
# B_space, route O2b (O2B-SIZE): the tight unit of the ADA module

Owner: O2B-SIZE (ce59d4ae), for the O2b technical lead (17fc0802). W4's ADA routines assume
`hM : 2^32 · adaBoundA A ≤ M` with `adaBoundA A = 2^10 (N + p + 16)(adaZ A + 16)`, which is about `2^15`
times the real per-record size of the data (numerically `2^14.3 … 2^15.0` over the tested parameters, see
`notes/o2_prep/M_TABLE.md`). This file proposes the replacement unit

  `o2sAdaUnit A = N (2 qA + sF + 7) + 2^7 (p + 1)(adaZ A + 16)`      (`sF = Nat.size A.fuel`)

built from B-ACC's tight sizes (`F2e2e/BSpace/O2TightSizes.lean`):
* `o2s_data_le_unit`: `|adaPubEnc A| + |adaEnc st| + |encVals vals| ≤ o2sAdaUnit A` (so every one of the three,
  and the argument list `[pub, st, vals]` up to `+ 4`, is below the unit);
* `o2s_adaArgsIv_le_unit`: the argument list `[pub, st, vals, l, u]` of `adaInterval` with endpoints of at most
  `qA + 4` bits (D3's `bsN_end_bitLen'`) is below the unit;
* `o2s_drawM_le_unit`, `o2s_intScale_le_unit`: the value bound of a draw and `2^7 (adaZ A + 16)` (the integer
  intermediates) are below the unit;
* `o2s_unit_le_adaBoundA`: `2^3 · o2sAdaUnit A ≤ adaBoundA A` (generic; the numeric ratio is `≈ 2^14`);
* for the actual parameters `A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R`:
  `o2s_N_ge`: `N ≥ 2^30 (p + 1) χ'`; `o2s_unit_le_perRecord`: `o2sAdaUnit A ≤ N (2 qA + sF + 8)`;
  `o2s_unit_le_chi`: `o2sAdaUnit A ≤ N (65 χ + 10)` (with B-NUM's `qA ≤ 32 χ`; the true `qA` is `≤ χ` on every
  tested parameter, which would give `N (3 χ + 10)`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-- **The tight unit of the ADA module**: `N (2 qA + sF + 7) + 2^7 (p + 1)(adaZ A + 16)`. -/
def o2sAdaUnit (A : AdaParams) : ℕ :=
  A.N * (2 * A.qA + Nat.size A.fuel + 7) + 2 ^ 7 * (A.p + 1) * (adaZ A + 16)

section unit

variable {A : AdaParams}

theorem o2sAdaUnit_eq (A : AdaParams) : o2sAdaUnit A =
    A.N * (2 * A.qA + Nat.size A.fuel + 7) + 2 ^ 7 * (A.p + 1) * (adaZ A + 16) := rfl

/-- The `p`-part of the unit dominates `2^7 (adaZ A + 16)`. -/
theorem o2s_intScale_le_unit (A : AdaParams) : 2 ^ 7 * (adaZ A + 16) ≤ o2sAdaUnit A := by
  rw [o2sAdaUnit_eq]
  have h : 2 ^ 7 * (adaZ A + 16) ≤ 2 ^ 7 * (A.p + 1) * (adaZ A + 16) := by
    rw [Nat.mul_assoc]
    exact Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))
  omega

/-- **The value bound of a draw** is below the unit. -/
theorem o2s_drawM_le_unit (A : AdaParams) (κ : NoiseKind) : drawM A κ ≤ o2sAdaUnit A :=
  (drawM_le A κ).trans (o2s_intScale_le_unit A)

/-- **The three data of the module together are below the unit**:
`|adaPubEnc A| + |adaEnc st| + |encVals vals| ≤ o2sAdaUnit A`. -/
theorem o2s_data_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (adaPubEnc A) + valSize (adaEnc st) + valSize (encVals vals) ≤ o2sAdaUnit A := by
  have h1 := bsT_valSize_adaEnc hok
  have h2 := bsT_valSize_encVals hbs hv
  have h3 := bsT_valSize_adaPubEnc A hbs hT
  rw [o2sAdaUnit_eq]
  set Z := adaZ A with hZ
  set sF := Nat.size A.fuel with hsF
  set sK := Nat.size (maxKs A) with hsK
  set sC := Nat.size (A.M + A.J + A.R + 2) with hsC
  set sN := Nat.size A.N with hsN
  have hZ16 : 16 ≤ Z := sixteen_le_adaZ A
  have hF : sF ≤ Z := size_fuel_le_adaZ A
  have hK : sK ≤ Z := size_maxKs_le_adaZ A
  have hC : sC ≤ Z := size_MJR_le_adaZ A
  have hNz : sN ≤ Z := size_N_le_adaZ A
  -- the `p`-parts
  have e1 : A.p * (sF + sK + 6) ≤ (A.p + 1) * (2 * Z + 6) :=
    Nat.mul_le_mul (by omega) (by omega)
  have e2 : (A.p + 1) * (sN + 2) ≤ (A.p + 1) * (Z + 2) := Nat.mul_le_mul_left _ (by omega)
  have e3 : A.p * (sF + 2) ≤ (A.p + 1) * (Z + 2) := Nat.mul_le_mul (by omega) (by omega)
  have e4 : 32 * (Z + 16) ≤ 32 * ((A.p + 1) * (Z + 16)) :=
    Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))
  have e5 : (A.p + 1) * (2 * Z + 6) + (A.p + 1) * (Z + 2) + (A.p + 1) * (Z + 2) +
      2 * (A.p + 1) + 4 * Z + 28 ≤ 2 ^ 7 * (A.p + 1) * (Z + 16) - 32 * ((A.p + 1) * (Z + 16)) := by
    have h1p : 1 ≤ A.p + 1 := by omega
    have hz : 4 * Z + 28 ≤ (A.p + 1) * (4 * Z + 28) := Nat.le_mul_of_pos_left _ h1p
    have e : (A.p + 1) * (2 * Z + 6) + (A.p + 1) * (Z + 2) + (A.p + 1) * (Z + 2) + 2 * (A.p + 1) +
        (A.p + 1) * (4 * Z + 28) = (A.p + 1) * (8 * Z + 40) := by ring
    have e' : 2 ^ 7 * (A.p + 1) * (Z + 16) - 32 * ((A.p + 1) * (Z + 16)) = (A.p + 1) * (96 * Z + 1536) := by
      have : 2 ^ 7 * (A.p + 1) * (Z + 16) = 32 * ((A.p + 1) * (Z + 16)) + (A.p + 1) * (96 * Z + 1536) := by
        ring
      omega
    rw [e']
    have : (A.p + 1) * (8 * Z + 40) ≤ (A.p + 1) * (96 * Z + 1536) := Nat.mul_le_mul_left _ (by omega)
    omega
  have hmul : 32 * ((A.p + 1) * (Z + 16)) ≤ 2 ^ 7 * (A.p + 1) * (Z + 16) := by
    have : 2 ^ 7 * (A.p + 1) * (Z + 16) = 4 * (32 * ((A.p + 1) * (Z + 16))) := by ring
    omega
  have hN : A.N * (A.qA + sF + 4) + A.N * (A.qA + 3) = A.N * (2 * A.qA + sF + 7) := by ring
  omega

theorem o2s_adaEnc_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (adaEnc st) ≤ o2sAdaUnit A := by
  have := o2s_data_le_unit hbs hT hok hv
  omega

theorem o2s_encVals_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (encVals vals) ≤ o2sAdaUnit A := by
  have := o2s_data_le_unit hbs hT hok hv
  omega

/-- The parameter record alone is below the `p`-part of the unit. -/
theorem o2s_adaPubEnc_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) :
    valSize (adaPubEnc A) ≤ o2sAdaUnit A := by
  have h := bsT_valSize_adaPubEnc' A hbs hT
  have : 34 * (A.p + 1) * (adaZ A + 16) ≤ 2 ^ 7 * (A.p + 1) * (adaZ A + 16) :=
    Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num))
  rw [o2sAdaUnit_eq]
  omega

/-- **`adaNumerical`'s argument** `[pub, st, vals]` is below the unit plus `4`. -/
theorem o2s_adaArgsNum_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ o2sAdaUnit A + 4 := by
  rw [o2s_valSize_list3_u]
  have := o2s_data_le_unit hbs hT hok hv
  omega
where
  o2s_valSize_list3_u (a b c : Val) :
      valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
    simp only [valSize_list, listSize_cons, listSize_nil]; omega

/-- **`adaInterval`'s argument** `[pub, st, vals, l, u]` with endpoints of at most `B` bits
(`B ≤ 2 adaZ A`; D3 gives `B = qA + 4`) is below the unit. -/
theorem o2s_adaArgsIv_le_unit (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {B : ℕ}
    (hB : B ≤ 2 * adaZ A) (hl : bitLen l.num ≤ B ∧ bitLen (l.den : ℤ) ≤ B)
    (hu : bitLen u.num ≤ B ∧ bitLen (u.den : ℤ) ≤ B) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ o2sAdaUnit A := by
  have hdata := bsT_valSize_adaEnc hok
  have hvals := bsT_valSize_encVals hbs hv
  have hpub := bsT_valSize_adaPubEnc' A hbs hT
  have hZ16 := sixteen_le_adaZ A
  have hl' : valSize (encQ l) ≤ 2 * B + 5 := by
    rw [valSize_encQ]; unfold bitLen at hl; simp only [Int.natAbs_natCast] at hl; omega
  have hu' : valSize (encQ u) ≤ 2 * B + 5 := by
    rw [valSize_encQ]; unfold bitLen at hu; simp only [Int.natAbs_natCast] at hu; omega
  have hsum := o2s_data_le_unit hbs hT hok hv
  -- the endpoints fit in the slack of the `p`-part
  have hslack : valSize (adaPubEnc A) + valSize (adaEnc st) + valSize (encVals vals) + (8 * adaZ A + 16) ≤
      o2sAdaUnit A := by
    -- redo `o2s_data_le_unit` with the extra `8 adaZ + 16`: the `p`-part has room `(p+1)(96 adaZ + 1536)`
    have h1 := bsT_valSize_adaEnc hok
    have h2 := bsT_valSize_encVals hbs hv
    have h3 := bsT_valSize_adaPubEnc A hbs hT
    rw [o2sAdaUnit_eq]
    set Z := adaZ A with hZ
    set sF := Nat.size A.fuel with hsF
    set sK := Nat.size (maxKs A) with hsK
    set sC := Nat.size (A.M + A.J + A.R + 2) with hsC
    set sN := Nat.size A.N with hsN
    have hF : sF ≤ Z := size_fuel_le_adaZ A
    have hK : sK ≤ Z := size_maxKs_le_adaZ A
    have hC : sC ≤ Z := size_MJR_le_adaZ A
    have hNz : sN ≤ Z := size_N_le_adaZ A
    have e1 : A.p * (sF + sK + 6) ≤ (A.p + 1) * (2 * Z + 6) := Nat.mul_le_mul (by omega) (by omega)
    have e2 : (A.p + 1) * (sN + 2) ≤ (A.p + 1) * (Z + 2) := Nat.mul_le_mul_left _ (by omega)
    have e3 : A.p * (sF + 2) ≤ (A.p + 1) * (Z + 2) := Nat.mul_le_mul (by omega) (by omega)
    have h1p : 1 ≤ A.p + 1 := by omega
    have hz : 12 * Z + 44 ≤ (A.p + 1) * (12 * Z + 44) := Nat.le_mul_of_pos_left _ h1p
    have hz2 : 32 * (Z + 16) ≤ (A.p + 1) * (32 * (Z + 16)) := Nat.le_mul_of_pos_left _ h1p
    have e : (A.p + 1) * (2 * Z + 6) + (A.p + 1) * (Z + 2) + (A.p + 1) * (Z + 2) + 2 * (A.p + 1) +
        (A.p + 1) * (12 * Z + 44) + (A.p + 1) * (32 * (Z + 16)) = (A.p + 1) * (48 * Z + 568) := by ring
    have e' : 2 ^ 7 * (A.p + 1) * (Z + 16) = (A.p + 1) * (128 * Z + 2048) := by ring
    have hle : (A.p + 1) * (48 * Z + 568) ≤ (A.p + 1) * (128 * Z + 2048) :=
      Nat.mul_le_mul_left _ (by omega)
    have hN : A.N * (A.qA + sF + 4) + A.N * (A.qA + 3) = A.N * (2 * A.qA + sF + 7) := by ring
    omega
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **Generic comparison**: `2^3 · o2sAdaUnit A ≤ adaBoundA A` (numerically the ratio is `≈ 2^14`). -/
theorem o2s_unit_le_adaBoundA (A : AdaParams) : 2 ^ 3 * o2sAdaUnit A ≤ adaBoundA A := by
  have hqf := qA_add_size_fuel_le_adaZ A
  unfold adaBoundA
  rw [o2sAdaUnit_eq]
  calc 2 ^ 3 * (A.N * (2 * A.qA + Nat.size A.fuel + 7) + 2 ^ 7 * (A.p + 1) * (adaZ A + 16))
      ≤ 2 ^ 3 * (A.N * (2 * (adaZ A + 16)) + 2 ^ 7 * (A.p + 1) * (adaZ A + 16)) :=
        Nat.mul_le_mul_left _ (Nat.add_le_add_right (Nat.mul_le_mul_left _ (by omega)) _)
    _ = 2 ^ 4 * (A.N * (adaZ A + 16)) + 2 ^ 10 * ((A.p + 1) * (adaZ A + 16)) := by ring
    _ ≤ 2 ^ 10 * (A.N * (adaZ A + 16)) + 2 ^ 10 * ((A.p + 16) * (adaZ A + 16)) :=
        Nat.add_le_add (Nat.mul_le_mul_right _ (by norm_num))
          (Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (by omega)))
    _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring

end unit

/-! ## The actual parameters -/

section actual

/-- Every block has `n_j ≥ 2^{30} χ'` samples (`n_j ≥ 2^{12} χ' h⁻²`, `h⁻¹ = 512 p 2^{eA} ≥ 2^9`). -/
theorem o2s_nBlock_ge (M J R eA eXi j : ℕ) :
    2 ^ 30 * adaChi M J R eA eXi ≤ adaNBlock M J R eA eXi j := by
  have hh : 2 ^ 9 ≤ adaHInv eA := by
    have hp := F2e2e.C.Impl.AP.two_le_adaP eA
    have h1 : 1 ≤ adaP eA * 2 ^ eA := Nat.one_le_iff_ne_zero.mpr (by positivity)
    unfold adaHInv
    calc 2 ^ 9 = 512 * 1 := by norm_num
      _ ≤ 512 * (adaP eA * 2 ^ eA) := Nat.mul_le_mul_left _ h1
      _ = 512 * adaP eA * 2 ^ eA := by ring
  have hh2 : 2 ^ 18 ≤ adaHInv eA ^ 2 := by
    calc 2 ^ 18 = (2 ^ 9) ^ 2 := by norm_num
      _ ≤ adaHInv eA ^ 2 := Nat.pow_le_pow_left hh 2
  have h2 : 2 ^ 30 * adaChi M J R eA eXi ≤ 2 ^ 12 * adaChi M J R eA eXi * adaHInv eA ^ 2 := by
    calc 2 ^ 30 * adaChi M J R eA eXi = 2 ^ 12 * adaChi M J R eA eXi * 2 ^ 18 := by ring
      _ ≤ 2 ^ 12 * adaChi M J R eA eXi * adaHInv eA ^ 2 := Nat.mul_le_mul_left _ hh2
  unfold adaNBlock
  omega

/-- **`N ≥ 2^{30} (p + 1) χ'`.** -/
theorem o2s_N_ge (M J R eA eXi : ℕ) :
    2 ^ 30 * (adaP eA + 1) * adaChi M J R eA eXi ≤ (adaParams eA eXi M J R).N := by
  have hent : ∀ x ∈ adaBlockSizes M J R eA eXi, 2 ^ 30 * adaChi M J R eA eXi ≤ x := by
    intro x hx
    unfold adaBlockSizes at hx
    obtain ⟨j, -, rfl⟩ := List.mem_map.mp hx
    exact o2s_nBlock_ge M J R eA eXi j
  have hsum := List.card_nsmul_le_sum _ _ hent
  rw [adaBlockSizes_length, smul_eq_mul] at hsum
  show 2 ^ 30 * (adaP eA + 1) * adaChi M J R eA eXi ≤ (adaBlockSizes M J R eA eXi).sum
  calc 2 ^ 30 * (adaP eA + 1) * adaChi M J R eA eXi =
        (adaP eA + 1) * (2 ^ 30 * adaChi M J R eA eXi) := by ring
    _ ≤ _ := hsum

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- **The unit, per record** (actual parameters): `o2sAdaUnit A ≤ N (2 qA + sF + 8)`; the `p`-part is
`≤ N` since `N ≥ 2^{30}(p+1)χ` and `adaZ A ≤ 1024 χ`. -/
theorem o2s_unit_le_perRecord (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    o2sAdaUnit (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N *
        (2 * (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA +
          Nat.size (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).fuel + 8) := by
  have hZ := bs_adaZ_le M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  have hce := bs_chi_eq M J R ha0 ha1 hξ0 hξ1
  have hN : 2 ^ 30 * ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p + 1) *
      F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) ≤
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N := by
    rw [hce]
    exact o2s_N_ge M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq)
  rw [o2sAdaUnit_eq]
  generalize F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) = χ at hZ h60 hN
  generalize adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R = A at hZ hN ⊢
  -- `2^7 (p+1)(adaZ + 16) ≤ 2^7 (p+1) · 1025 χ ≤ 2^30 (p+1) χ ≤ N`
  have h1 : adaZ A + 16 ≤ 1025 * χ := by omega
  have h3 : 2 ^ 7 * (A.p + 1) * (adaZ A + 16) ≤ A.N :=
    calc 2 ^ 7 * (A.p + 1) * (adaZ A + 16) ≤ 2 ^ 7 * (A.p + 1) * (1025 * χ) :=
          Nat.mul_le_mul_left _ h1
      _ = (2 ^ 7 * 1025) * ((A.p + 1) * χ) := by ring
      _ ≤ 2 ^ 30 * ((A.p + 1) * χ) := Nat.mul_le_mul_right _ (by norm_num)
      _ = 2 ^ 30 * (A.p + 1) * χ := by ring
      _ ≤ A.N := hN
  have e : A.N * (2 * A.qA + Nat.size A.fuel + 8) = A.N * (2 * A.qA + Nat.size A.fuel + 7) + A.N := by
    ring
  rw [e]
  omega

/-- **The unit in terms of `χ`** (actual parameters, with B-NUM's `qA ≤ 32 χ`):
`o2sAdaUnit A ≤ N (65 χ + 10)`. -/
theorem o2s_unit_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    o2sAdaUnit (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N *
        (65 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 10) := by
  have h := o2s_unit_le_perRecord M J R ha0 ha1 hξ0 hξ1
  have hq := bsT_qA_le_chi M J R ha0 ha1 hξ0 hξ1
  have hF := bsT_sF_le_chi M J R ha0 ha1 hξ0 hξ1
  refine h.trans (Nat.mul_le_mul_left _ ?_)
  omega

end actual

end F2e2e.BSpace
