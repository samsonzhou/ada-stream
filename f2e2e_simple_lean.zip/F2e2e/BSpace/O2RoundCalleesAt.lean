import F2e2e.BSpace.O2RoundCalleesNum
import F2e2e.BSpace.O2RoundCalleesIv
import F2e2e.BSpace.O2GlueMainSpecs

/-!
# B_space, route O2b: the tight specs of the ADA entries on `bsRoundProg` (o2m)

Owner: C-TREE (51e3826d), for C-BANK's top frame (P5, `o2m_implR_of`) and the O2b technical lead 17fc0802.

C-BANK's callee-rule stubs `O2mIvTightSpec` / `O2mNumTightSpec` (`F2e2e/BSpace/O2GlueMainSpecs.lean`) on the round
program, from the instances `o2ct_iv_impl` / `o2ct_num_impl` (`F2e2e/BSpace/O2RoundCalleesIv.lean`, `F2e2e/BSpace/O2RoundCalleesNum.lean`). The stubs' premise
`NormQSpec prog M` is not needed (the round program provides it, `bsLib_round.normQ`). Exported under C-BANK's names
(`o2m_ivTight_round`, `o2m_numTight_round`) and W4's (`o2ct_ivTightSpec_round`, `o2ct_numTightSpec_round`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- **The tight spec of `adaInterval` (602) on the round program.** -/
theorem o2m_ivTight_round : O2mIvTightSpec bsRoundProg :=
  fun _ _ _ _ _ _ _ _ hbs hT hpos hok hv hl hu hMt hMq => o2ct_iv_impl hbs hT hpos hok hv hl hu hMt hMq

/-- **The tight spec of `adaNumerical` (603) on the round program.** -/
theorem o2m_numTight_round : O2mNumTightSpec bsRoundProg :=
  fun _ _ _ _ _ hbs hT hpos hok hv hMt => o2ct_num_impl hbs hT hpos hok hv hMt

/-- `o2m_ivTight_round` under the name used by W4's `O2AssembleFinal`. -/
theorem o2ct_ivTightSpec_round : O2mIvTightSpec bsRoundProg := o2m_ivTight_round

/-- `o2m_numTight_round` under the name used by W4's `O2AssembleFinal`. -/
theorem o2ct_numTightSpec_round : O2mNumTightSpec bsRoundProg := o2m_numTight_round

end F2e2e.BSpace
