import F2e2e.B.SpecV2BridgeFinal

/-!
# Theorem (B), joint form (B-ARCH): the guarantee for EVERY tape length `c ≥ c₀`

For the v3 statement `Theorem_B_joint` (one tape length serves the statistical guarantee and the
bit-space clause). The bridge `F2e2e/B/SpecV2BridgeFinal.lean` proves the guarantee of the Spec's
Algorithm 2 at the tape length `c = adaCoins (adaAlg2Params …)`. The tape length enters its proof only
through `v2_online` (any `c ≥ adaCoins P`), `BitProg.sum_tapes_eq` (any length `≥` the depth of the
online run, `coreRunS_depth_le`) and the factor `2^c`. This file copies the deterministic-controller
step with these three substitutions (the audited bridge stays untouched):

* `v2DetFailMass_le_ge`, `alg2V2_det_ge`: as `v2DetFailMass_le`, `alg2V2_det`, for any
  `c ≥ adaCoins P`;
* `alg2V2_guarantee_ge`: `∀ c ≥ adaCoins (adaAlg2Params M J R aReq ξReq), VGuaranteeWithInternalCaps
  … (alg2Mech … c) (alg2Aborted … c) (alg2PeakCorrections … c)`. Here
  `adaAlg2Params M J R aReq ξReq = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R` by definition,
  so `c₀ = adaCoins A = bsCoins A` is also B_space's tape budget (`F2e2e/BSpace/RefineDefs.lean`).
-/

namespace F2e2e.B.V2

open F2e2e.Discrete F2e2e.B.Bridge MeasureTheory

/-- **The union event of the Spec's Algorithm 2 from the core-level guarantee with internal caps**,
for every tape length `c ≥ adaCoins P` (`v2DetFailMass_le` is the case `c = adaCoins P`). -/
theorem v2DetFailMass_le_ge {U : Type} [Fintype U] {P2 : F2e2e.Alg2Params} {P : AdaParams}
    (hP : ParCorr P2 P) (hN : P2.N = P.N) {c : ℕ} (hc : adaCoins P ≤ c) {aReq : ℝ} (ha1 : aReq < 1)
    (hvp : F2e2e.valP (F2e2e.dyadicDown aReq) = P.p)
    (hvt : ∀ j < P.p, F2e2e.valTmax (F2e2e.dyadicDown aReq) j = P.Tmax.getD j 0)
    (D : U → ℝ) (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl2 : F2e2e.VController U)
    (hvalid : ctrl2.Valid) (B : ENNReal)
    (hcore : ∀ T : ℕ, ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
        (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure
          {r | coreFails P D (aReq - (P.hA : ℝ)) (specToCoreV2 P ctrl2) r.1 ∨
            internalFails P r.2} ≤ B) :
    v2DetFailMass (mech2 P2 (c))
      (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
      (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) D P.M P.J P.R aReq ctrl2 ≤
      B * 2 ^ c := by
  classical
  -- the per-round bad event of the union
  let E : (Fin P2.N → U) × (Fin (c) → Bool) → ℕ → Prop := fun p t =>
    F2e2e.VCovered (mech2 P2 (c)) ctrl2 P.M P.J P.R p.1 p.2 t ∧
      (¬ F2e2e.VCorrect D aReq (F2e2e.vRequest (mech2 P2 (c)) ctrl2 p.1 p.2 t)
          (F2e2e.vResponse (mech2 P2 (c)) ctrl2 p.1 p.2 t) ∨
        ((F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 (c)) ctrl2 p.1 p.2 t)
            p.2).aborted = true ∨
          ∃ j : Fin (F2e2e.valP (F2e2e.dyadicDown aReq)),
            F2e2e.valTmax (F2e2e.dyadicDown aReq) j.val ≤
              (F2e2e.alg2Exec P2 t (F2e2e.vRoundViews (mech2 P2 (c)) ctrl2 p.1 p.2 t)
                p.2).corrections j.val))
  obtain ⟨T, hT⟩ := exists_horizon' E
  set Ebad : Set (List CoreOut × AdaState) :=
    {r | coreFails P D (aReq - (P.hA : ℝ)) (specToCoreV2 P ctrl2) r.1 ∨ internalFails P r.2}
    with hEbad
  have hpt : ∀ (s2 : Fin P2.N → U) (ω : Fin (c) → Bool),
      (if F2e2e.VFails (mech2 P2 (c)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
          F2e2e.VInternalFails (mech2 P2 (c))
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R aReq
            s2 ω then (1 : ENNReal) else 0) ≤
        ((coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).run (List.ofFn ω)).elim 0
          (fun r => Ebad.indicator 1 r.1) := by
    intro s2 ω
    split_ifs with hf
    · have hex : ∃ t, E (s2, ω) t := by
        rcases hf with ⟨t, hcov, hinc⟩ | ⟨t, hcov, hint⟩
        · exact ⟨t, hcov, Or.inl hinc⟩
        · exact ⟨t, hcov, Or.inr hint⟩
      obtain ⟨t, htT, hcov, hbad⟩ := hT (s2, ω) hex
      obtain ⟨o, st, rest, hrun, holen, hresp, -⟩ := v2_online hP hN hc ctrl2 hvalid s2 ω T
      rw [hrun]
      have hmem : (o, st) ∈ Ebad := by
        rcases hbad with hinc | hint
        · exact Or.inl (v2Fails_imp_coreFails P2 P D hD0 hD1 ha1 _ ctrl2 hvalid s2 ω htT hcov hinc
            holen hresp)
        · right
          obtain ⟨o1, st1, rest1, hrun1, -, -, hstate⟩ :=
            v2_online hP hN hc ctrl2 hvalid s2 ω (t + 1)
          obtain ⟨hab, hcor⟩ := hstate t rfl
          have hf1 : internalFails P st1 := by
            rcases hint with ha | ⟨j, hj⟩
            · left; rw [← hab]; exact ha
            · right
              have hjp : j.val < P.p := by rw [← hvp]; exact j.isLt
              refine ⟨j.val, hjp, ?_⟩
              rw [← hvt j.val hjp, ← hcor]; exact hj
          obtain ⟨b, hb⟩ : ∃ b, T = t + 1 + b := ⟨T - (t + 1), by omega⟩
          rw [hb] at hrun
          exact coreRunS_internalFails_mono P _ _ (t + 1) b _ hrun1 hrun hf1
      simp [Set.indicator_of_mem hmem]
    · exact zero_le
  have hsum : ∀ s2 : Fin P2.N → U, ∑ ω : Fin (c) → Bool,
      (if F2e2e.VFails (mech2 P2 (c)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
          F2e2e.VInternalFails (mech2 P2 (c))
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
            (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R aReq
            s2 ω then (1 : ENNReal) else 0) ≤
        2 ^ c *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad := by
    intro s2
    refine (Finset.sum_le_sum fun ω _ => hpt s2 ω).trans (le_of_eq ?_)
    rw [BitProg.sum_tapes_eq _ ((coreRunS_depth_le P _ _ T).trans hc) (Ebad.indicator 1),
      PMF.toOuterMeasure_apply]
    congr 1
    refine tsum_congr fun r => ?_
    by_cases hr : r ∈ Ebad
    · simp [Set.indicator_of_mem hr]
    · simp [Set.indicator_of_notMem hr]
  calc v2DetFailMass (mech2 P2 (c))
        (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
        (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) D P.M P.J P.R aReq ctrl2
      = ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) * ∑ ω : Fin (c) → Bool,
          (if F2e2e.VFails (mech2 P2 (c)) D P.M P.J P.R aReq ctrl2 s2 ω ∨
            F2e2e.VInternalFails (mech2 P2 (c))
              (fun t views ω => (F2e2e.alg2Exec P2 t views ω).aborted)
              (fun t views ω => (F2e2e.alg2Exec P2 t views ω).corrections) ctrl2 P.M P.J P.R
              aReq s2 ω then (1 : ENNReal) else 0) := by
        unfold v2DetFailMass
        refine Finset.sum_congr rfl fun s _ => ?_
        rw [Finset.mul_sum]
    _ ≤ ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) * (2 ^ c *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad) :=
        Finset.sum_le_sum fun s2 _ => mul_le_mul' le_rfl (hsum s2)
    _ = 2 ^ c * ∑ s2 : Fin P2.N → U, ENNReal.ofReal (∏ ℓ, D (s2 ℓ)) *
          (coreRunS P (specToCoreV2 P ctrl2) (castSample hN s2) T).law.toOuterMeasure Ebad := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun s _ => ?_
        ring
    _ = 2 ^ c * ∑ s : Fin P.N → U, ENNReal.ofReal (∏ ℓ, D (s ℓ)) *
          (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure Ebad := by
        rw [sum_castSample hN D
          (fun s => (coreRunS P (specToCoreV2 P ctrl2) s T).law.toOuterMeasure Ebad)]
    _ ≤ 2 ^ c * B := mul_le_mul' le_rfl (hcore T)
    _ = B * 2 ^ c := mul_comm _ _

/-- **The Spec's Algorithm 2, deterministic controllers, any tape length `c ≥ c₀`**: the union
event has probability at most `ξ_req`. -/
theorem alg2V2_det_ge (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {c : ℕ}
    (hc : adaCoins (adaAlg2Params M J R aReq ξReq) ≤ c) {U : Type} [Fintype U] (D : U → ℝ)
    (hD0 : ∀ x, 0 ≤ D x) (hD1 : ∑ x, D x = 1) (ctrl2 : F2e2e.VController U)
    (hvalid : ctrl2.Valid) :
    v2DetFailMass (F2e2e.alg2Mech M J R aReq ξReq c) (F2e2e.alg2Aborted M J R aReq ξReq c)
      (F2e2e.alg2PeakCorrections M J R aReq ξReq c) D M J R aReq ctrl2 ≤
      ENNReal.ofReal ξReq * 2 ^ c :=
  v2DetFailMass_le_ge (parCorr_alg2 M J R ha0 ha1 hξ0 hξ1) (v2par_N M J R ha0 ha1 hξ0 hξ1) hc
    (by linarith) (v2par_valP M J R aReq ξReq) (fun j hj => v2par_valTmax M J R aReq ξReq j hj)
    D hD0 hD1 ctrl2 hvalid _
    (fun T => accuracy_core_guarantee_detS M J R ha0 ha1 hξ0 hξ1 U D hD0 hD1 _
      (specToCoreV2_valid _ ctrl2 hvalid) T)

/-- **Main Theorem (B), the guarantee conjunct, for every tape length `c ≥ c₀`**, with
`c₀ = adaCoins (adaAlg2Params M J R aReq ξReq)`: Algorithm 2 of the Spec with `c` fair bits satisfies
`VGuaranteeWithInternalCaps`. -/
theorem alg2V2_guarantee_ge (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ∀ c ≥ adaCoins (adaAlg2Params M J R aReq ξReq), F2e2e.VGuaranteeWithInternalCaps M J R aReq ξReq
      (F2e2e.alg2Mech M J R aReq ξReq c) (F2e2e.alg2Aborted M J R aReq ξReq c)
      (F2e2e.alg2PeakCorrections M J R aReq ξReq c) := by
  intro c hc
  exact vGuaranteeWithInternalCaps_of_det _ _ _ M J R aReq ξReq
    (fun U _ D Ω _ ctrl _ hctrl s ω' => alg2V2_meas M J R aReq ξReq _ U D Ω ctrl hctrl s ω')
    (fun _U _ D hD0 hD1 ctrl hvalid => alg2V2_det_ge M J R ha0 ha1 hξ0 hξ1 hc D hD0 hD1 ctrl hvalid)

end F2e2e.B.V2
