import F2e2e.BSpace.DslEvals
import F2e2e.BSpace.O2GstLiftCalc

/-!
# B_space, route O2b: D2 `bsEvals` in the per-call judgment `EvalsValF`

Owner: 1beb339b (O2b slice D2; technical lead 17fc0802; consumer O2B-GST 8cf19cc0). The routine is the O1
routine `bsEvals` (keys 910–912 and the library loop `revAppendStep`, `F2e2e/BSpace/DslEvalsDefs.lean`),
unchanged; this file proves it in C-SPACE's per-call judgment `EvalsValF` (`F2e2e/BSpace/O2GstF.lean`), with
one value bound per frame and an explicit callee budget:
* the entry frame (key 910) at `(m, τ)` with `o2e_B ≤ m`, `o2e_T = 41 · o2e_B ≤ τ`;
* the outer loop (911) at `(B, 27 B)`, charged `(11 + 3) B + 27 B = 41 B`;
* in each outer iteration the inner loop (912) at `(B, 13 B)`, charged `(11 + 3) B + 13 B = 27 B`, and the final
  reversal of the blocks at `(|blocks| + 9, 0)`, charged `13 (|blocks| + 9) ≤ 13 B`;
* in each inner iteration the oracle (no frame), and the final reversal of the block at `(|block| + 9, 0)`.
A call of `bsEvals` at `(o2e_B, o2e_T)` costs its caller `(7 + 2) B + 41 B = 50 B`
(`o2e_depth_evals : exprDepth body_bsEvals = 7`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Bounds and depths -/

/-- The value bound of every frame of `bsEvals` (O1's hypothesis `hM` of `bsEvals_eval`). -/
def o2e_B (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (blocks : List (List ℕ)) : ℕ :=
  valSize (Val.list (blocks.map (encL encN))) + valSize (C.Impl.encVals (evalsOf orc q blocks)) + 2 * q + 64

/-- The callee budget of the entry frame of `bsEvals`. -/
def o2e_T (orc : ℤ → ℤ → ℤ → ℤ) (q : ℕ) (blocks : List (List ℕ)) : ℕ := 41 * o2e_B orc q blocks

theorem o2e_depth_evals : exprDepth body_bsEvals = 7 := by decide

theorem o2e_depth_outer : exprDepth body_bsEvalsOuter = 11 := by decide

theorem o2e_depth_inner : exprDepth body_bsEvalsInner = 11 := by decide

theorem o2e_depth_rev : exprDepth Cost.body_revAppendStep = 10 := by decide

/-! ## Deterministic rules -/

section rules

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}

theorem o2e_ite_true {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsValF orc prog m τ env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : EvalsValF orc prog m τ env [] (.inl t) v) :
    EvalsValF orc prog m τ env [] (.inl (Expr.ite c t f)) v :=
  EvalsValF.ite hc (by rw [if_pos hz]; exact ht)

theorem o2e_ite_false {c t f : Expr} {z : ℤ} {v : Val}
    (hc : EvalsValF orc prog m τ env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : EvalsValF orc prog m τ env [] (.inl f) v) :
    EvalsValF orc prog m τ env [] (.inl (Expr.ite c t f)) v :=
  EvalsValF.ite hc (by rw [if_neg (not_not.mpr hz)]; exact hf)

theorem o2e_isNil_nil {a : Expr} (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.list []))
    (hM : 2 ≤ m) : EvalsValF orc prog m τ env [] (.inl (Expr.un UnOp.isNil a)) (Val.int 1) :=
  EvalsValF.un (c := 1) ha rfl (by simpa using hM)

theorem o2e_isNil_cons {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.list (x :: l))) (hM : 1 ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (Expr.un UnOp.isNil a)) (Val.int 0) :=
  EvalsValF.un (c := 1) ha rfl (by simpa using hM)

theorem o2e_add {a b : Expr} {x y : ℤ} (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.int x))
    (hb : EvalsValF orc prog m τ env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (Expr.bin BinOp.add a b)) (Val.int (x + y)) :=
  EvalsValF.bin ha hb rfl hM

theorem o2e_div {a b : Expr} {x y : ℤ} (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.int x))
    (hb : EvalsValF orc prog m τ env [] (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (Expr.bin BinOp.div a b)) (Val.int (x / y)) :=
  EvalsValF.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem o2e_triple {a b c : Expr} {x y z : Val} (ha : EvalsValF orc prog m τ env [] (.inl a) x)
    (hb : EvalsValF orc prog m τ env [] (.inl b) y) (hc : EvalsValF orc prog m τ env [] (.inl c) z)
    (hM : valSize (Val.list [x, y, z]) ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (Arith.eTriple a b c)) (Val.list [x, y, z]) := by
  have h3 := bsE_vs_three x y z
  have h0 : valSize (Val.list []) ≤ m := by rw [bsE_vs_nil]; omega
  have h1 : valSize (Val.list [z]) ≤ m := by rw [bsE_vs_one]; omega
  have h2 : valSize (Val.list [y, z]) ≤ m := by rw [bsE_vs_two]; omega
  exact EvalsValF.cons ha (EvalsValF.cons hb (EvalsValF.cons hc (EvalsValF.nil h0) h1) h2) hM

end rules

/-! ## Reversal by the library loop `revAppendStep` -/

section rev

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}

/-- The iterations of `revAppendStep` from `[A, B]` at any frame bound `m ≥ |A| + |B| + 8` and any budget. -/
theorem o2e_revStep_run (hR : prog[Cost.Idx.revAppendStep]? = some Cost.body_revAppendStep) (τ : ℕ) :
    ∀ (A B : List Val) (m : ℕ), valSize (Val.list A) + valSize (Val.list B) + 8 ≤ m →
      EvalsValF orc prog m τ [] [] (.inr (Cost.Idx.revAppendStep, Val.list [Val.list A, Val.list B]))
        (Val.list (A.reverse ++ B))
  | [], B, m, hM => by
    rw [bsE_vs_nil] at hM
    show EvalsValF orc prog m τ [] [] (.inr (_, _)) (Val.list B)
    refine EvalsValF.stop hR ?_
    unfold Cost.body_revAppendStep
    refine EvalsValF.letE (EvalsValF.head (EvalsValF.var rfl) (by rw [bsE_vs_nil]; omega)) ?_
    refine o2e_ite_true (o2e_isNil_nil (EvalsValF.var rfl) (by omega)) one_ne_zero ?_
    refine EvalsValF.pair (EvalsValF.lit (by rw [bsE_vs_int0]; omega))
      (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl) (by rw [bsE_vs_one]; omega)) (by omega)) ?_
    rw [bsE_vs_two, bsE_vs_int0]
    omega
  | x :: A, B, m, hM => by
    rw [bsE_vs_cons] at hM
    have ih := o2e_revStep_run hR τ A (x :: B) m (by rw [bsE_vs_cons]; omega)
    have hb : EvalsValF orc prog m τ [Val.list [Val.list (x :: A), Val.list B]] []
        (.inl Cost.body_revAppendStep)
        (Val.list [Val.int 1, Val.list [Val.list A, Val.list (x :: B)]]) := by
      unfold Cost.body_revAppendStep
      refine EvalsValF.letE (EvalsValF.head (EvalsValF.var rfl) (by rw [bsE_vs_cons]; omega)) ?_
      refine o2e_ite_false (o2e_isNil_cons (EvalsValF.var rfl) (by omega)) rfl ?_
      refine EvalsValF.pair (EvalsValF.lit (by rw [bsE_vs_int1]; omega))
        (EvalsValF.pair (EvalsValF.tail (EvalsValF.var rfl) (by omega))
          (EvalsValF.cons (EvalsValF.head (EvalsValF.var rfl) (by omega))
            (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl) (by rw [bsE_vs_one]; omega))
              (by omega))
            (by rw [bsE_vs_cons]; omega)) ?_) ?_
      · rw [bsE_vs_two, bsE_vs_cons]
        omega
      · rw [bsE_vs_two, bsE_vs_two, bsE_vs_cons, bsE_vs_int1]
        omega
    rw [show (x :: A).reverse ++ B = A.reverse ++ (x :: B) by simp]
    exact EvalsValF.cast_bits (EvalsValF.cont hR hb one_ne_zero ih) (by simp)

/-- **`bsERev e`** in a frame `(m, τ)`: the reversal loop runs in its own frame `(|l| + 9, 0)`, charged
`13 (|l| + 9) ≤ τ`. -/
theorem o2e_rev (hR : prog[Cost.Idx.revAppendStep]? = some Cost.body_revAppendStep) {m τ : ℕ}
    {env : List Val} {e : Expr} {l : List Val}
    (he : EvalsValF orc prog m τ env [] (.inl e) (Val.list l)) (hm : valSize (Val.list l) + 9 ≤ m)
    (hτ : 13 * (valSize (Val.list l) + 9) ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (bsERev e)) (Val.list l.reverse) := by
  have h1 := o2e_revStep_run (orc := orc) hR 0 l [] (valSize (Val.list l) + 9)
    (by have h0 := bsE_vs_nil; omega)
  rw [List.append_nil] at h1
  have hp : EvalsValF orc prog m τ env [] (.inl (ePair e Expr.nil))
      (Val.list [Val.list l, Val.list []]) :=
    EvalsValF.cast_bits (EvalsValF.pair he (EvalsValF.nil (by rw [bsE_vs_nil]; omega))
      (by rw [bsE_vs_two, bsE_vs_nil]; omega)) (by simp)
  exact EvalsValF.cast_bits (EvalsValF.loop' hp hR h1 (by rw [bsE_vs_two, bsE_vs_nil]; omega)
    (by rw [bsE_vs_reverse]; omega) (by rw [o2e_depth_rev]; omega)) (by simp)

end rev

/-! ## The inner loop (key 912) -/

/-- **The inner loop** in its frame `(m, τ)`: from `[rest, acc, q + 1]` the iterations return
`acc.reverse ++ rest.map g`, one oracle call per code; the final reversal is charged `13 m ≤ τ`. -/
theorem o2e_inner_run {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} (hlib : BsEvalsLib prog) (q m τ : ℕ)
    (hτ : 13 * m ≤ τ) : ∀ rest acc : List ℕ,
      (∀ r ∈ rest, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) →
      valSize (encL encN rest) + valSize (encL encN (acc.reverse ++ rest.map (bsE_g orc q))) + q + 20 ≤
        m →
      EvalsValF orc prog m τ [] [] (.inr (bsE_innerKey, bsE_encInner q rest acc))
        (encL encN (acc.reverse ++ rest.map (bsE_g orc q))) := by
  have hQ := bsE_vsQ q
  simp only [valSize_int] at hQ
  intro rest
  induction rest with
  | nil =>
    intro acc _ hM
    have hres : encL encN (acc.reverse ++ ([] : List ℕ).map (bsE_g orc q)) =
        Val.list (acc.map encN).reverse := by
      simp [encL, List.map_reverse]
    rw [hres]
    rw [hres] at hM
    simp only [encL, valSize_list, listSize_nil, listSize_reverse, List.map_nil] at hM
    refine EvalsValF.stop hlib.inner ?_
    unfold body_bsEvalsInner bsE_encInner
    simp only [encL, List.map_nil]
    refine o2e_ite_true (o2e_isNil_nil (EvalsValF.head (EvalsValF.var rfl)
      (by simp only [valSize_list, listSize_nil]; omega)) (by omega)) one_ne_zero ?_
    refine EvalsValF.pair (EvalsValF.lit (by simp only [valSize_int, bitLen_zero]; omega))
      (o2e_rev hlib.rev (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (by simp only [valSize_list]; omega)) (by simp only [valSize_list]; omega)
        (by simp only [valSize_list]; omega)) ?_
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, listSize_reverse, bitLen_zero]
    omega
  | cons r rest ih =>
    intro acc hO hM
    obtain ⟨hr0, hr1⟩ := hO r List.mem_cons_self
    have hO' : ∀ r' ∈ rest, 0 ≤ orc 0 (r' : ℤ) (q + 1) ∧ orc 0 (r' : ℤ) (q + 1) ≤ 2 ^ (q + 1) :=
      fun r' h => hO r' (List.mem_cons_of_mem _ h)
    obtain ⟨ho1, ho2, ho3⟩ := bsE_vs_answer hr0 hr1
    simp only [valSize_int] at ho1 ho2 ho3
    have hg : encN (bsE_g orc q r) = Val.int ((orc 0 (r : ℤ) (q + 1) + 1) / 2) := bsE_encN_g hr0
    have hgsz : bitLen ((orc 0 (r : ℤ) (q + 1) + 1) / 2) = bitLen ((bsE_g orc q r : ℕ) : ℤ) := by
      have h := congrArg valSize hg
      simp only [encN, valSize_int] at h
      omega
    have hid : (bsE_g orc q r :: acc).reverse ++ rest.map (bsE_g orc q) =
        acc.reverse ++ (r :: rest).map (bsE_g orc q) := by simp
    have hM' := hM
    simp only [encL, encN, valSize_list, valSize_int, listSize_cons, listSize_append, listSize_reverse,
      List.map_cons, List.map_append, List.map_reverse] at hM'
    -- the remaining codes
    have hrest := ih (bsE_g orc q r :: acc) hO' (by
      rw [hid]
      simp only [encL, encN, valSize_list, valSize_int, listSize_cons, listSize_append,
        listSize_reverse, List.map_cons, List.map_append, List.map_reverse]
      omega)
    rw [hid] at hrest
    -- one iteration
    have hb : EvalsValF orc prog m τ [bsE_encInner q (r :: rest) acc] [] (.inl body_bsEvalsInner)
        (Val.list [Val.int 1, bsE_encInner q rest (bsE_g orc q r :: acc)]) := by
      unfold body_bsEvalsInner bsE_encInner
      simp only [encL, List.map_cons]
      rw [hg]
      have h1 : valSize (Val.list (encN r :: List.map encN rest)) ≤ m := by
        simp only [encN, valSize_list, valSize_int, listSize_cons]; omega
      have h2 : valSize (Val.list [Val.list (List.map encN acc), Val.int ((q : ℤ) + 1)]) ≤ m := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h3 : valSize (Val.list [Val.int ((q : ℤ) + 1)]) ≤ m := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h4 : valSize (Val.int ((q : ℤ) + 1)) ≤ m := by simp only [valSize_int]; omega
      refine o2e_ite_false (o2e_isNil_cons (EvalsValF.head (EvalsValF.var rfl) h1) (by omega)) rfl ?_
      refine EvalsValF.letE (EvalsValF.oracle (o2e_triple
        (EvalsValF.lit (by simp only [valSize_int, bitLen_zero]; omega))
        (EvalsValF.head (EvalsValF.head (EvalsValF.var rfl) h1)
          (by simp only [valSize_int]; omega))
        (EvalsValF.head (EvalsValF.tail (EvalsValF.tail (EvalsValF.var rfl) h2) h3) h4)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_zero]; omega))
        (by simp only [valSize_int]; omega)) ?_
      refine EvalsValF.pair (EvalsValF.lit (by simp only [valSize_int, bitLen_one]; omega))
        (o2e_triple (EvalsValF.tail (EvalsValF.head (EvalsValF.var rfl) h1)
            (by simp only [valSize_list]; omega))
          (EvalsValF.cons (o2e_div (o2e_add (EvalsValF.var rfl)
                (EvalsValF.lit (by simp only [valSize_int, bitLen_one]; omega))
                (by simp only [valSize_int]; omega))
              (EvalsValF.lit (by simp only [valSize_int, bitLen_two_eq]; omega)) two_ne_zero
              (by simp only [valSize_int]; omega))
            (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl) h2)
              (by simp only [valSize_list]; omega))
            (by simp only [valSize_list, valSize_int, listSize_cons]; omega))
          (EvalsValF.head (EvalsValF.tail (EvalsValF.tail (EvalsValF.var rfl) h2) h3) h4)
          (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)) ?_
      simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]
      omega
    exact EvalsValF.cast_bits (EvalsValF.cont hlib.inner hb one_ne_zero hrest) (by simp)

/-! ## The outer loop (key 911) -/

/-- **The outer loop** in its frame `(m, τ)`: the inner loops run at `(m, 13 m)` (charged `27 m`), the final
reversal at `(|accB| + 9, 0)` (charged `≤ 13 m`). -/
theorem o2e_outer_run {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} (hlib : BsEvalsLib prog) (q m τ : ℕ)
    (hτ : 27 * m ≤ τ) : ∀ restB accB : List (List ℕ),
      (∀ blk ∈ restB, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) →
      valSize (Val.list (restB.map (encL encN))) +
          valSize (Val.list ((accB.reverse ++ restB.map (List.map (bsE_g orc q))).map (encL encN))) +
          q + 24 ≤ m →
      EvalsValF orc prog m τ [] [] (.inr (bsE_outerKey, bsE_encOuter q restB accB))
        (Val.list ((accB.reverse ++ restB.map (List.map (bsE_g orc q))).map (encL encN)))
  | [], accB, _, hM => by
    have hQ := bsE_vsQ q
    simp only [valSize_int] at hQ
    have hT : (accB.reverse ++ ([] : List (List ℕ)).map (List.map (bsE_g orc q))).map (encL encN) =
        (accB.map (encL encN)).reverse := by simp
    rw [hT]
    rw [hT] at hM
    simp only [valSize_list, listSize_nil, listSize_reverse, List.map_nil] at hM
    refine EvalsValF.stop hlib.outer ?_
    unfold body_bsEvalsOuter bsE_encOuter
    simp only [List.map_nil]
    refine o2e_ite_true (o2e_isNil_nil (EvalsValF.head (EvalsValF.var rfl)
      (by simp only [valSize_list, listSize_nil]; omega)) (by omega)) one_ne_zero ?_
    refine EvalsValF.pair (EvalsValF.lit (by simp only [valSize_int, bitLen_zero]; omega))
      (o2e_rev hlib.rev (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl)
        (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
        (by simp only [valSize_list]; omega)) (by simp only [valSize_list]; omega)
        (by simp only [valSize_list]; omega)) ?_
    simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, listSize_reverse, bitLen_zero]
    omega
  | blk :: restB, accB, hO, hM => by
    have hQ := bsE_vsQ q
    simp only [valSize_int] at hQ
    have hid : (List.map (bsE_g orc q) blk :: accB).reverse ++ restB.map (List.map (bsE_g orc q)) =
        accB.reverse ++ (blk :: restB).map (List.map (bsE_g orc q)) := by simp
    have hM' := hM
    simp only [encL, valSize_list, listSize_cons, listSize_append, listSize_reverse, List.map_cons,
      List.map_append, List.map_reverse] at hM'
    -- the inner loop on the first block, in its frame `(m, 13 m)`
    have hin := o2e_inner_run hlib q m (13 * m) le_rfl blk [] (hO blk List.mem_cons_self) (by
      simp only [encL, valSize_list, List.reverse_nil, List.nil_append]
      omega)
    simp only [List.reverse_nil, List.nil_append] at hin
    -- the remaining blocks
    have ih := o2e_outer_run hlib q m τ hτ restB (List.map (bsE_g orc q) blk :: accB)
      (fun b hb => hO b (List.mem_cons_of_mem _ hb)) (by
        rw [hid]
        simp only [encL, valSize_list, listSize_cons, listSize_append, listSize_reverse,
          List.map_cons, List.map_append, List.map_reverse]
        omega)
    rw [hid] at ih
    -- one iteration
    have hb : EvalsValF orc prog m τ [bsE_encOuter q (blk :: restB) accB] [] (.inl body_bsEvalsOuter)
        (Val.list [Val.int 1, bsE_encOuter q restB (List.map (bsE_g orc q) blk :: accB)]) := by
      unfold body_bsEvalsOuter bsE_encOuter
      simp only [List.map_cons]
      have h1 : valSize (Val.list (encL encN blk :: List.map (encL encN) restB)) ≤ m := by
        simp only [encL, valSize_list, listSize_cons]; omega
      have h2 : valSize (Val.list [Val.list (List.map (encL encN) accB), Val.int ((q : ℤ) + 1)]) ≤ m := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h3 : valSize (Val.list [Val.int ((q : ℤ) + 1)]) ≤ m := by
        simp only [valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have h4 : valSize (Val.int ((q : ℤ) + 1)) ≤ m := by simp only [valSize_int]; omega
      have hacc : valSize (Val.list [encL encN blk, Val.list [], Val.int ((q : ℤ) + 1)]) ≤ m := by
        simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
      have ht : EvalsValF orc prog m τ [Val.list [Val.list (encL encN blk :: List.map (encL encN) restB),
          Val.list (List.map (encL encN) accB), Val.int ((q : ℤ) + 1)]] []
          (.inl (Arith.eTriple (bsE1 (bsE1 (Expr.var 0))) Expr.nil (bsE3 (Expr.var 0))))
          (Val.list [encL encN blk, Val.list [], Val.int ((q : ℤ) + 1)]) :=
        o2e_triple (EvalsValF.head (EvalsValF.head (EvalsValF.var rfl) h1)
            (by simp only [encL, valSize_list]; omega))
          (EvalsValF.nil (by simp only [valSize_list, listSize_nil]; omega))
          (EvalsValF.head (EvalsValF.tail (EvalsValF.tail (EvalsValF.var rfl) h2) h3) h4) hacc
      have hτin : (exprDepth body_bsEvalsInner + 3) * m + 13 * m ≤ τ := by
        rw [o2e_depth_inner]; omega
      have hloop : EvalsValF orc prog m τ [Val.list [Val.list (encL encN blk :: List.map (encL encN) restB),
          Val.list (List.map (encL encN) accB), Val.int ((q : ℤ) + 1)]] []
          (.inl (Expr.loop bsE_innerKey (Arith.eTriple (bsE1 (bsE1 (Expr.var 0))) Expr.nil
            (bsE3 (Expr.var 0))))) (encL encN (List.map (bsE_g orc q) blk)) :=
        EvalsValF.cast_bits (EvalsValF.loop' ht hlib.inner hin hacc
          (by simp only [encL, valSize_list]; omega) hτin) (by simp)
      refine o2e_ite_false (o2e_isNil_cons (EvalsValF.head (EvalsValF.var rfl) h1) (by omega)) rfl ?_
      refine EvalsValF.letE hloop ?_
      refine EvalsValF.pair (EvalsValF.lit (by simp only [valSize_int, bitLen_one]; omega))
        (o2e_triple (EvalsValF.tail (EvalsValF.head (EvalsValF.var rfl) h1)
            (by simp only [valSize_list]; omega))
          (EvalsValF.cons (EvalsValF.var rfl) (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl) h2)
              (by simp only [valSize_list]; omega))
            (by simp only [encL, valSize_list, listSize_cons]; omega))
          (EvalsValF.head (EvalsValF.tail (EvalsValF.tail (EvalsValF.var rfl) h2) h3) h4)
          (by simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega)) ?_
      simp only [encL, valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one]
      omega
    exact EvalsValF.cast_bits (EvalsValF.cont hlib.outer hb one_ne_zero ih) (by simp)

/-! ## `bsEvals` -/

/-- **D2 in the per-call judgment**: on `[q, blocks]`, `bsEvals` returns `encVals (evalsOf orc q blocks)` in
any frame `(m, τ)` with `o2e_B ≤ m` and `o2e_T = 41 · o2e_B ≤ τ` (the outer loop runs in its own frame
`(o2e_B, 27 · o2e_B)`). -/
theorem o2e_bsEvals_evalsF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hlib : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) {q : ℕ} {blocks : List (List ℕ)}
    (hO : ∀ blk ∈ blocks, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1))
    {m τ : ℕ} (hm : o2e_B orc q blocks ≤ m) (hτ : o2e_T orc q blocks ≤ τ) :
    EvalsValF orc prog m τ [Val.list [encN q, Val.list (blocks.map (encL encN))]] []
      (.inl body_bsEvals) (C.Impl.encVals (evalsOf orc q blocks)) := by
  have hL := BsEvalsLib.of_table hlib
  have hQ := bsE_vsQ q
  have hN := bsE_vsN q
  simp only [valSize_int] at hQ
  simp only [encN, valSize_int] at hN
  unfold o2e_T at hτ
  unfold o2e_B at hm hτ
  rw [bsE_encVals_eq, evalsOf_eq_map] at hm hτ ⊢
  generalize hB : valSize (Val.list (blocks.map (encL encN))) +
    valSize (Val.list ((blocks.map (List.map (bsE_g orc q))).map (encL encN))) + 2 * q + 64 = B at hm hτ
  have hout := o2e_outer_run hL q B (27 * B) le_rfl blocks [] hO (by
    simp only [List.reverse_nil, List.nil_append]
    omega)
  simp only [List.reverse_nil, List.nil_append] at hout
  unfold body_bsEvals
  have hI : valSize (Val.list [Val.list (blocks.map (encL encN))]) ≤ m := by
    rw [bsE_vs_one]; omega
  have hacc : valSize (Val.list [Val.list (blocks.map (encL encN)), Val.list [],
      Val.int ((q : ℤ) + 1)]) ≤ B := by
    rw [bsE_vs_three, bsE_vs_nil]; simp only [valSize_int]; omega
  refine EvalsValF.cast_bits (EvalsValF.loop' (o2e_triple
    (EvalsValF.head (EvalsValF.tail (EvalsValF.var rfl) hI) (by omega))
    (EvalsValF.nil (by rw [bsE_vs_nil]; omega))
    (o2e_add (EvalsValF.head (EvalsValF.var rfl) (by simp only [valSize_int]; omega))
      (EvalsValF.lit (by simp only [valSize_int, bitLen_one]; omega)) (by simp only [valSize_int]; omega))
    (by omega)) hL.outer hout hacc (by omega) (by rw [o2e_depth_outer]; omega)) (by simp)

end F2e2e.BSpace
