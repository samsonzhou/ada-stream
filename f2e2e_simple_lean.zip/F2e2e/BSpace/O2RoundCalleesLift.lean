import F2e2e.BSpace.O2RoundCalleesNum
import F2e2e.BSpace.O2RoundCalleesIv
import F2e2e.BSpace.O2GstAsmB
import F2e2e.BSpace.O2GlueMainCallees

/-!
# B_space, route O2b: the ADA callee predicates of the top frame on `bsRoundProg` (o2ct)

Owner: C-TREE (51e3826d), for the O2b technical lead 17fc0802 and C-BANK's top frame.

C-BANK's callee predicates `O2mNumAt` (603) and `O2mIvAt` (602) (`F2e2e/BSpace/O2GlueMainDefs.lean`) on the round
program, from the instances `o2ct_num_impl` / `o2ct_iv_impl` (`F2e2e/BSpace/O2RoundCalleesNum.lean`,
`F2e2e/BSpace/O2RoundCalleesIv.lean`: the tight `_t` specs on `bsRoundProg`) by A-ARCH's weighted liftings `o2m_numAt_wt` / `o2m_ivAt_wt`
(`F2e2e/BSpace/O2GlueMainCallees.lean`) with O2B-GST's weight certificate `bsWeightOK_round`
(`F2e2e/BSpace/O2GstAsmB.lean`: `w(603) = 240`, `w(602) = 231`; depths `31`, `18`):
* `adaNumerical` in the frame `(M, 206 · M)`, call cost `33 M + 206 M ≤ 240 M`, for every `M` with `TightM A M`,
  in particular at `M_N = 2^8 · tightA A + cAddA A` (`o2ct_numAt`, `o2ct_numAt_MN`);
* `adaInterval` in the frame `(M, 210 · M)`, call cost `20 M + 210 M ≤ 231 M`, for every `M` with `TightM A M`
  and `2^28 · Bq ≤ M` (endpoints of bit length `≤ Bq`), in particular at
  `M_I = 2^8 · tightA A + cAddA A + 2^28 (q_A + 4)` for the endpoints `bsN_end q_A (orc i 0 (q_A + 1))` read in
  the round (`o2ct_ivAt`, `o2ct_ivAt_MI`, `o2ct_ivAt_ends`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- The tight frame bound of `adaNumerical`. -/
def o2ctMN (A : AdaParams) : ℕ := 2 ^ 8 * tightA A + cAddA A

/-- The tight frame bound of `adaInterval` (endpoints of bit length `≤ q_A + 4`). -/
def o2ctMI (A : AdaParams) : ℕ := 2 ^ 8 * tightA A + cAddA A + 2 ^ 28 * (A.qA + 4)

theorem o2ct_tight_MN (A : AdaParams) : TightM A (o2ctMN A) := by
  unfold TightM o2ctMN
  exact le_rfl

theorem o2ct_tight_MI (A : AdaParams) : TightM A (o2ctMI A) := by
  unfold TightM o2ctMI
  omega

theorem o2ct_endpoints_MI (A : AdaParams) : 2 ^ 28 * (A.qA + 4) ≤ o2ctMI A := by
  unfold o2ctMI
  omega

/-- `adaNumerical` is entry `603` of `bsRoundProg`. -/
theorem o2ct_h603 : bsRoundProg[Idx.adaNumerical]? = some body_adaNumerical :=
  bsLib_round.w4Lib.numTbl (Idx.adaNumerical, body_adaNumerical) (by simp [adaNumTable])

/-- `adaInterval` is entry `602` of `bsRoundProg`. -/
theorem o2ct_h602 : bsRoundProg[Idx.adaInterval]? = some body_adaInterval :=
  bsLib_round.w4Lib.entryTbl (Idx.adaInterval, body_adaInterval) (by simp [adaEntryTable])

/-- **`adaNumerical` (603) on `bsRoundProg` in its own frame `(M, 206 · M)`**, for every tight `M`; the call
costs `33 M + 206 M ≤ 240 M = w(603) · M` in the caller's budget. -/
theorem o2ct_numAt (orc : ℤ → ℤ → ℤ → ℤ) {M : ℕ} {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M) :
    O2mNumAt orc bsRoundProg M (206 * M) A st vals ∧ 33 * M + 206 * M ≤ 240 * M := by
  have h := o2m_numAt_wt (orc := orc) bsRoundProg_oracle bsWeightOK_round o2ct_h603
    (o2ct_num_impl hbs hT hpos hok hv hMt) (o2m_numIn_le_of_tight hbs hT hok hv hMt)
  have hw : bsWRound Idx.adaNumerical = 240 := bsW_vals.2.2.2.1
  rw [hw, o2m_depth_adaNumerical] at h
  exact h

/-- **`adaNumerical` at `M_N = 2^8 · tightA A + cAddA A`.** -/
theorem o2ct_numAt_MN (orc : ℤ → ℤ → ℤ → ℤ) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    O2mNumAt orc bsRoundProg (o2ctMN A) (206 * o2ctMN A) A st vals ∧
      33 * o2ctMN A + 206 * o2ctMN A ≤ 240 * o2ctMN A :=
  o2ct_numAt orc hbs hT hpos hok hv (o2ct_tight_MN A)

/-- **`adaInterval` (602) on `bsRoundProg` in its own frame `(M, 210 · M)`**, for every tight `M` covering the
endpoints; the call costs `20 M + 210 M ≤ 231 M = w(602) · M` in the caller's budget. -/
theorem o2ct_ivAt (orc : ℤ → ℤ → ℤ → ℤ) {M : ℕ} {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq) (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hMt : TightM A M) (hMq : 2 ^ 28 * Bq ≤ M) :
    O2mIvAt orc bsRoundProg M (210 * M) A st vals l u ∧ 20 * M + 210 * M ≤ 231 * M := by
  have h := o2m_ivAt_wt (orc := orc) bsRoundProg_oracle bsWeightOK_round o2ct_h602
    (o2ct_iv_impl hbs hT hpos hok hv hl hu hMt hMq) (o2m_ivIn_le_of_tight hbs hT hok hv hl hu hMt hMq)
  have hw : bsWRound Idx.adaInterval = 231 := bsW_vals.2.2.1
  rw [hw, o2m_depth_adaInterval] at h
  exact h

/-- **`adaInterval` at `M_I = 2^8 · tightA A + cAddA A + 2^28 (q_A + 4)`** (endpoints of bit length
`≤ q_A + 4`). -/
theorem o2ct_ivAt_MI (orc : ℤ → ℤ → ℤ → ℤ) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ}
    (hl : bitLen l.num ≤ A.qA + 4 ∧ bitLen (l.den : ℤ) ≤ A.qA + 4)
    (hu : bitLen u.num ≤ A.qA + 4 ∧ bitLen (u.den : ℤ) ≤ A.qA + 4) :
    O2mIvAt orc bsRoundProg (o2ctMI A) (210 * o2ctMI A) A st vals l u ∧
      20 * o2ctMI A + 210 * o2ctMI A ≤ 231 * o2ctMI A :=
  o2ct_ivAt orc hbs hT hpos hok hv hl hu (o2ct_tight_MI A) (o2ct_endpoints_MI A)

/-- **`adaInterval` at `M_I` on the endpoints read in the round** (`bsN_end q_A (orc i 0 (q_A + 1))`, `i = 1, 2`,
under the oracle bounds `|orc i 0 (q_A + 1)| ≤ 2^(q_A + 2)`). -/
theorem o2ct_ivAt_ends (orc : ℤ → ℤ → ℤ → ℤ) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals)
    (hn1 : |orc 1 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2)) (hn2 : |orc 2 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2)) :
    O2mIvAt orc bsRoundProg (o2ctMI A) (210 * o2ctMI A) A st vals
        (bsN_end A.qA (orc 1 0 ((A.qA : ℤ) + 1))) (bsN_end A.qA (orc 2 0 ((A.qA : ℤ) + 1))) ∧
      20 * o2ctMI A + 210 * o2ctMI A ≤ 231 * o2ctMI A :=
  o2ct_ivAt_MI orc hbs hT hpos hok hv (bsN_end_bitLen' A.qA _ hn1) (bsN_end_bitLen' A.qA _ hn2)

end F2e2e.BSpace
