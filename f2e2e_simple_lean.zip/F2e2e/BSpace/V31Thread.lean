import F2e2e.BSpace.AssembleThread

/-!
# B_space v3.1 (C-TOP, speculative): threaded runs with explicit states

`exec_of_thread` (`AssembleThread.lean`) produces states and tapes; here they are explicit
(`threadStates`, `threadTapes`): the state before round `t` is the encoding of the core state of the threaded run
after `t` rounds (`threadStates_of`). This is what the history-freeness clause of the v3.1 audit (F-B2: the state
after `t` requests is a function of Algorithm 2's state after `t` requests) needs from the assembly.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete

variable {σ ρ : Type}

/-- The encoded state before round `t` of the threaded run (junk once a run failed). -/
def threadStates (encS : σ → Val) (init : BitProg σ) (round : ℕ → σ → BitProg (ρ × σ)) (tape : List Bool)
    (t : ℕ) : Val :=
  ((threadRun init round tape t).map fun p => encS p.1).getD (Val.int 0)

/-- The unread tape before round `t` of the threaded run. -/
def threadTapes (init : BitProg σ) (round : ℕ → σ → BitProg (ρ × σ)) (tape : List Bool) (t : ℕ) :
    List Bool :=
  ((threadRun init round tape t).map Prod.snd).getD []

theorem threadStates_of {encS : σ → Val} {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)}
    {tape : List Bool} {t : ℕ} {st : σ} {τ : List Bool} (h : threadRun init round tape t = some (st, τ)) :
    threadStates encS init round tape t = encS st := by
  simp only [threadStates, h, Option.map_some, Option.getD_some]

theorem threadTapes_of {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)} {tape : List Bool} {t : ℕ}
    {st : σ} {τ : List Bool} (h : threadRun init round tape t = some (st, τ)) :
    threadTapes init round tape t = τ := by
  simp only [threadTapes, h, Option.map_some, Option.getD_some]

/-- **`exec_of_thread` with explicit states and tapes.** -/
theorem exec_of_thread_explicit {O : Type}
    (Runs : O → List Expr → Val → List Bool → Val → List Bool → ℝ → Prop)
    {initProg roundProg : List Expr} {orc0 : O} {orcs : ℕ → O}
    {params records : Val} {kinds : ℕ → Bool} {tape : List Bool} {S : ℝ}
    {resps : ℕ → VResponse} {parse : Val → Option VResponse}
    {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)} {encS : σ → Val} {encR : ρ → Val}
    (Inv : σ → Prop)
    (hinit : ∀ st τ, init.run tape = some (st, τ) →
      Inv st ∧ Runs orc0 initProg (Val.list [params, records]) tape (encS st) τ S)
    (hround : ∀ t st τ r st' τ', Inv st → (round t st).run τ = some ((r, st'), τ') →
      Inv st' ∧ Runs (orcs t) roundProg (Val.list [params, encS st, Val.int (if kinds t then 1 else 0)])
        τ (Val.list [encS st', encR r]) τ' S)
    (htot : ∀ t, (threadRun init round tape (t + 1)).isSome)
    (hresp : ∀ t r, threadOut init round tape t = some r → parse (encR r) = some (resps t)) :
    Runs orc0 initProg (Val.list [params, records]) tape (threadStates encS init round tape 0)
        (threadTapes init round tape 0) S ∧
      ∀ t : ℕ, ∃ respV : Val,
        Runs (orcs t) roundProg
          (Val.list [params, threadStates encS init round tape t, Val.int (if kinds t then 1 else 0)])
          (threadTapes init round tape t)
          (Val.list [threadStates encS init round tape (t + 1), respV]) (threadTapes init round tape (t + 1))
          S ∧
        parse respV = some (resps t) := by
  have hall := threadRun_inv Inv (fun st τ h => (hinit st τ h).1)
    (fun t st τ r st' τ' hI h => (hround t st τ r st' τ' hI h).1) htot
  refine ⟨?_, fun t => ?_⟩
  · obtain ⟨st, τ, h, -⟩ := hall 0
    rw [threadStates_of h, threadTapes_of h]
    exact (hinit st τ h).2
  · obtain ⟨st, τ, h, hInv⟩ := hall t
    have h1 := htot t
    rw [threadRun_succ_of h, Option.isSome_map] at h1
    obtain ⟨⟨⟨r, st'⟩, τ'⟩, hrun⟩ := Option.isSome_iff_exists.mp h1
    have h2 : threadRun init round tape (t + 1) = some (st', τ') := by
      rw [threadRun_succ_of h, hrun]
      rfl
    refine ⟨encR r, ?_, hresp t r ?_⟩
    · rw [threadStates_of h, threadTapes_of h, threadStates_of h2, threadTapes_of h2]
      exact (hround t st τ r st' τ' hInv hrun).2
    · rw [threadOut_of h, hrun]
      rfl

end F2e2e.BSpace
