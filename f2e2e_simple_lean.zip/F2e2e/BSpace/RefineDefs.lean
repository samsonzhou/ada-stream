import F2e2e.B.ArchOnline

/-!
# B_space, layer R: shared definitions (B-ACC, for W4's D4 and the layer R proofs)

* `bsCoreRound A st vals l u kind`: one request of the core (`F2e2e/B/ArchCore.lean`, B-ARCH) on the grid
  indices `vals` of the request's query on the stored blocks and on the endpoints `l, u`: W4's
  `adaInterval` for an interval request (`kind = true`), W4's `adaNumerical` for a numerical request
  (`kind = false`), as a bit program reading fresh fair bits from the tape, with its output in the sum type
  `CoreOut = AdaCert ⊕ AdaNum`. D4's `body_bsRound` implements it (with `vals`, `l`, `u` computed through the
  evaluation oracle); layer R relates it to the Spec's `alg2Request` (R1, R3).
* `bsCoins A = adaCoins A = adaInitBits A + (M + R) · adaCallBits A`: the tape budget `c_B` from which on no run
  of an execution exhausts the tape (R4): only the initialization and the first `M + R` processed requests
  read fair bits.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B

/-- One request of the core on the grid indices `vals` and the endpoints `l, u`: an interval request
(`kind = true`, W4's `adaInterval`) or a numerical request (`kind = false`, W4's `adaNumerical`). -/
def bsCoreRound (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) (kind : Bool) :
    BitProg (CoreOut × AdaState) :=
  if kind then (adaInterval A st vals l u).map fun r => (Sum.inl r.1, r.2)
  else (adaNumerical A st vals).map fun r => (Sum.inr r.1, r.2)

/-- The tape budget `c_B` of an execution: the initialization and `M + R` processed requests. -/
def bsCoins (A : AdaParams) : ℕ := adaCoins A

theorem bsCoins_eq (A : AdaParams) : bsCoins A = adaInitBits A + (A.M + A.R) * adaCallBits A := rfl

theorem bsCoreRound_true (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    bsCoreRound A st vals l u true = (adaInterval A st vals l u).map fun r => (Sum.inl r.1, r.2) :=
  rfl

theorem bsCoreRound_false (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    bsCoreRound A st vals l u false = (adaNumerical A st vals).map fun r => (Sum.inr r.1, r.2) :=
  rfl

end F2e2e.BSpace
