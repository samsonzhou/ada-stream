import F2e2e.Cost.MachineWork

/-!
# B_space, layer S2: the machine bound of an assembled oracle program

Owner: C-SPACE (B_space layer S; area lead W4). The bit bound of a run of an assembled program with the
oracle (M\*, `F2e2e/BSpace/MachineStarO.lean`) is

`bsMachineBound prog r K M = (bridgeWC + 2)(bitsFactor prog · ((r 0 + 1)(K + 3) + 1) · M + bitsConst prog) +
bridgeWC'`

(rank certificate `RankOK prog r K`, value bound `M`; `bridgeWC = 48`, `bridgeWC' = 392`, the constants of the
locked bridge). This file defines it and gives the program-independent estimate
`bsMachineBound_le : bsMachineBound prog r K M ≤ 2^51 · M` for every program of depth `≤ 2^10` with at most
`2^10 − 1` routines and peak factor `(r 0 + 1)(K + 3) + 1 ≤ 2^20` (`M ≥ 1`). The final inequality S2 against
`bSpaceBound` (Spec v3 §7) combines it with the value bound of layer S1 once the constant is decided.
-/

namespace F2e2e.BSpace

/-- The bit bound of the oracle machine for a program with rank certificate `(r, K)` and value bound `M`. -/
noncomputable def bsMachineBound (prog : List Expr) (r : ℕ → ℕ) (K M : ℕ) : ℝ :=
  (((F2e2e.Machine.bridgeWC : ℕ) : ℝ) + 2) *
      ((F2e2e.Machine.bitsFactor prog : ℝ) * ((((r 0 + 1) * (K + 3) + 1) * M : ℕ) : ℝ) +
        (F2e2e.Machine.bitsConst prog : ℝ)) +
    ((F2e2e.Machine.bridgeWC' : ℕ) : ℝ)

/-- The machine constants of a program of depth `≤ Dp ≤ 2^10` with `|prog| + 1 ≤ 2^w`, `w ≤ 2^10`. -/
theorem bsBitsFactor_bitsConst_le {prog : List Expr} {Dp w : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) :
    F2e2e.Machine.bitsFactor prog ≤ 2 ^ 24 ∧ F2e2e.Machine.bitsConst prog ≤ 2 ^ 25 := by
  have h1 := F2e2e.Machine.bitsFactor_le hDp hw
  have h2 := F2e2e.Machine.bitsConst_le hDp hw
  have hDp' : Dp ≤ 1024 := by simpa using hDp10
  have hw' : w ≤ 1024 := by simpa using hw10
  have a1 : Dp + 1 ≤ 2048 := by omega
  have a2 : w + 3 * Dp + 11 ≤ 8192 := by omega
  have a3 : w + 3 * Dp + 8 ≤ 8192 := by omega
  constructor
  · calc _ ≤ (Dp + 1) * (w + 3 * Dp + 11) := h1
      _ ≤ 2048 * 8192 := Nat.mul_le_mul a1 a2
      _ = 2 ^ 24 := by norm_num
  · have h4 := Nat.mul_le_mul a1 a3
    calc _ ≤ (Dp + 1) * (w + 3 * Dp + 8) + 1 := h2
      _ ≤ 2048 * 8192 + 1 := by omega
      _ ≤ 2 ^ 25 := by norm_num

/-- **The program-independent machine bound**: for a program of depth `≤ 2^10` with `|prog| + 1 ≤ 2^w`,
`w ≤ 2^10`, peak factor `(r 0 + 1)(K + 3) + 1 ≤ 2^20` and value bound `M ≥ 1`,
`bsMachineBound prog r K M ≤ 2^51 · M`. -/
theorem bsMachineBound_le {prog : List Expr} {r : ℕ → ℕ} {K M Dp w : ℕ}
    (hDp : F2e2e.Machine.progDepth prog ≤ Dp) (hw : prog.length + 1 ≤ 2 ^ w) (hDp10 : Dp ≤ 2 ^ 10)
    (hw10 : w ≤ 2 ^ 10) (hD : (r 0 + 1) * (K + 3) + 1 ≤ 2 ^ 20) (hM : 1 ≤ M) :
    bsMachineBound prog r K M ≤ 2 ^ 51 * (M : ℝ) := by
  obtain ⟨hK, hK'⟩ := bsBitsFactor_bitsConst_le hDp hw hDp10 hw10
  -- everything in ℕ first
  have hnat : (F2e2e.Machine.bridgeWC + 2) *
      (F2e2e.Machine.bitsFactor prog * (((r 0 + 1) * (K + 3) + 1) * M) +
        F2e2e.Machine.bitsConst prog) + F2e2e.Machine.bridgeWC' ≤ 2 ^ 51 * M := by
    rw [F2e2e.Machine.bridgeWC_eq, F2e2e.Machine.bridgeWC'_eq]
    have t1 : F2e2e.Machine.bitsFactor prog * (((r 0 + 1) * (K + 3) + 1) * M) ≤
        2 ^ 24 * (2 ^ 20 * M) :=
      Nat.mul_le_mul hK (Nat.mul_le_mul_right M hD)
    have t2 : (2 : ℕ) ^ 24 * (2 ^ 20 * M) = 2 ^ 44 * M := by ring
    have t3 : (48 + 2) * (2 ^ 44 * M + 2 ^ 25) + 392 ≤ 2 ^ 51 * M := by
      have : (2 : ℕ) ^ 51 * M = 2 ^ 50 * M + 2 ^ 50 * M := by ring
      have h50 : 2 ^ 31 ≤ 2 ^ 50 * M := by
        calc (2 : ℕ) ^ 31 ≤ 2 ^ 50 := Nat.pow_le_pow_right (by norm_num) (by norm_num)
          _ = 2 ^ 50 * 1 := by ring
          _ ≤ 2 ^ 50 * M := Nat.mul_le_mul_left _ hM
      have e1 : (48 + 2) * (2 ^ 44 * M) ≤ 2 ^ 50 * M := by
        have : (48 + 2) * (2 ^ 44 * M) = 50 * 2 ^ 44 * M := by ring
        rw [this]
        exact Nat.mul_le_mul_right M (by norm_num)
      have e2 : (48 + 2) * 2 ^ 25 + 392 ≤ 2 ^ 31 := by norm_num
      nlinarith
    calc (48 + 2) * (F2e2e.Machine.bitsFactor prog * (((r 0 + 1) * (K + 3) + 1) * M) +
          F2e2e.Machine.bitsConst prog) + 392
        ≤ (48 + 2) * (2 ^ 44 * M + 2 ^ 25) + 392 := by
          have := Nat.add_le_add (t1.trans_eq t2) hK'
          have := Nat.mul_le_mul_left (48 + 2) this
          omega
      _ ≤ 2 ^ 51 * M := t3
  unfold bsMachineBound
  have hcast : ((((F2e2e.Machine.bridgeWC + 2) *
      (F2e2e.Machine.bitsFactor prog * (((r 0 + 1) * (K + 3) + 1) * M) +
        F2e2e.Machine.bitsConst prog) + F2e2e.Machine.bridgeWC' : ℕ)) : ℝ) ≤
      ((2 ^ 51 * M : ℕ) : ℝ) := by exact_mod_cast hnat
  push_cast at hcast ⊢
  linarith

end F2e2e.BSpace
