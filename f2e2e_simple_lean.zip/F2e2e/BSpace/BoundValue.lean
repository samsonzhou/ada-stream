import F2e2e.C.Impl.AdaBounds
import F2e2e.BSpace.Pub
import F2e2e.BSpace.DslEvalsMath

/-!
# B_space, S1 (B-ACC): the value bound `bsMB` of the B programs

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §S (area lead W4). One explicit value bound

  `bsMB M J R eA eXi bU = 2^33 · adaBoundA A + bsPubBound M J R eA eXi + 2^4 · (N + 4) · (bU + 4)`

(`A = adaParams eA eXi M J R`, `N = A.N`, record codes `< 2^{bU}`) under which every value-bound hypothesis of
the B derivations holds:
* (a) W4's ADA routines: `2^32 · adaBoundA A ≤ bsMB` (`bsMB_ada`, with room `2^33`);
* (b) W2's parameter record: `bsPubBound ≤ bsMB` (`bsMB_pub`);
* (c) D1 (W3, `bsBlocks_eval`): `valSize (encL encN A.blockSizes) + valSize (encL encN codes) + 32 ≤ bsMB`
  (`bsMB_D1`);
* (d) D2 (`bsEvals`): `valSize (stored blocks) + valSize (encVals (evalsOf orc A.qA blocks)) + 2 qA + 64 ≤ bsMB`
  (`bsMB_D2`);
* (e) D3 (W5, `bsEnds_eval`): `20 qA + 200 ≤ bsMB` (`bsMB_D3`);
* (f) D4 (W2): the initialization's `2^32 · adaBoundA A + 2 · valSize (encL encN codes) ≤ bsMB`
  (`bsMB_D4init`) and the sizes of the round's input `[params, state, kind]` (`bsMB_D4round`).

The building blocks (`valSize_codes_le`, `valSize_blockSizes_le`, `bsV_valSize_split`, `valSize_evals_le`,
`bsV_params_size`) bound the record codes, the block sizes, the stored blocks, the query table and the
parameters.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/-- **The value bound of the B programs** (S1): `2^33 · adaBoundA A + bsPubBound + 2^4 (N + 4)(bU + 4)` for
`A = adaParams eA eXi M J R`, `N = A.N` and record codes of at most `bU` bits. -/
def bsMB (M J R eA eXi bU : ℕ) : ℕ :=
  2 ^ 33 * adaBoundA (adaParams eA eXi M J R) + bsPubBound M J R eA eXi +
    2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)

/-! ## The three summands -/

section summands

variable (M J R eA eXi bU : ℕ)

theorem bsMB_eq : bsMB M J R eA eXi bU =
    2 ^ 33 * adaBoundA (adaParams eA eXi M J R) + bsPubBound M J R eA eXi +
      2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4) := rfl

/-- (a) The ADA routines' value bound, with room: `2^33 · adaBoundA A ≤ bsMB`. -/
theorem bsMB_ada : 2 ^ 33 * adaBoundA (adaParams eA eXi M J R) ≤ bsMB M J R eA eXi bU := by
  rw [bsMB_eq]
  exact Nat.le_add_right_of_le (Nat.le_add_right _ _)

/-- (a) W4's ADA routines' value hypothesis `2^32 · adaBoundA A ≤ M` at `M = bsMB`. -/
theorem bsMB_ada32 : 2 ^ 32 * adaBoundA (adaParams eA eXi M J R) ≤ bsMB M J R eA eXi bU :=
  le_trans (Nat.mul_le_mul_right _ (by norm_num)) (bsMB_ada M J R eA eXi bU)

/-- (b) The parameter record's value bound: `bsPubBound ≤ bsMB`. -/
theorem bsMB_pub : bsPubBound M J R eA eXi ≤ bsMB M J R eA eXi bU := by
  rw [bsMB_eq]
  exact Nat.le_add_right_of_le (Nat.le_add_left _ _)

/-- The records' summand: `2^4 (N + 4)(bU + 4) ≤ bsMB`. -/
theorem bsMB_rec : 2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4) ≤ bsMB M J R eA eXi bU := by
  rw [bsMB_eq]
  exact Nat.le_add_left _ _

end summands

/-! ## Arithmetic of the summands -/

/-- `adaBoundA A = 2^10 (N + p + 16)(adaZ A + 16)` dominates every `O(adaZ A)` quantity. -/
theorem adaZ_le_adaBoundA (A : AdaParams) : 2 ^ 10 * (adaZ A + 16) ≤ adaBoundA A := by
  unfold adaBoundA
  rw [Nat.mul_assoc]
  exact Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))

/-- Two records' worth of codes plus a constant fit in the records' summand. -/
theorem rec_summand_bound (N bU : ℕ) :
    2 * (1 + N * (bU + 2)) + 240 ≤ 2 ^ 4 * (N + 4) * (bU + 4) := by
  nlinarith [Nat.zero_le (N * bU)]

/-! ## Building blocks -/

/-- The record codes: `valSize (encL encN codes) ≤ 1 + |codes| (bU + 2)` for codes `< 2^{bU}`. -/
theorem valSize_codes_le {codes : List ℕ} {bU : ℕ} (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (encL encN codes) ≤ 1 + codes.length * (bU + 2) := by
  have h := valSize_encL_le encN codes (bU + 1) (fun x hx => by
    rw [valSize_encN]
    have := Nat.size_le.mpr (hc x hx)
    omega)
  rw [show bU + 1 + 1 = bU + 2 by omega] at h
  exact h

/-- Block sizes (`p + 1` of them, each `≤ N`) are below `adaBoundA A`. -/
theorem valSize_blockSizes_le_of (A : AdaParams) (hbs : A.blockSizes.length = A.p + 1) :
    valSize (encL encN A.blockSizes) ≤ adaBoundA A := by
  have h1 : valSize (encL encN A.blockSizes) ≤ 1 + (A.p + 1) * (adaZ A + 2) := by
    have h := valSize_encL_le encN A.blockSizes (adaZ A + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.N := List.le_sum_of_mem hx
      have := Nat.size_le_size hx'
      have := size_N_le_adaZ A
      omega)
    rw [hbs, show adaZ A + 1 + 1 = adaZ A + 2 by omega] at h
    exact h
  have h2 : (A.p + 1) * (adaZ A + 2) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h3 : 1 ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
    Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega) (by omega))
  unfold adaBoundA
  rw [Nat.mul_assoc]
  omega

/-- The block sizes of a general instance are below `adaBoundA A`. -/
theorem valSize_blockSizes_le (eA eXi M J R : ℕ) :
    valSize (encL encN (adaParams eA eXi M J R).blockSizes) ≤ adaBoundA (adaParams eA eXi M J R) :=
  valSize_blockSizes_le_of _ (bsP_blockSizes_length eA eXi M J R)

/-- The stored blocks are the record codes plus two cells per block. -/
theorem bsV_listSize_split : ∀ (ns codes : List ℕ),
    listSize ((splitBlocks ns codes).map (encL encN)) ≤ listSize (codes.map encN) + 2 * ns.length
  | [], codes => by simp [splitBlocks]
  | n :: ns, codes => by
    have ih := bsV_listSize_split ns (codes.drop n)
    have hsplit : listSize (codes.map encN) =
        listSize ((codes.take n).map encN) + listSize ((codes.drop n).map encN) := by
      rw [← listSize_append, ← List.map_append, List.take_append_drop]
    have hv : valSize (encL encN (codes.take n)) = 1 + listSize ((codes.take n).map encN) := by
      simp [encL]
    simp only [splitBlocks, List.map_cons, listSize_cons, List.length_cons]
    rw [hv]
    omega

/-- The stored blocks: `valSize (Val.list ((splitBlocks ns codes).map (encL encN))) ≤ valSize (encL encN codes) +
2 |ns|`. -/
theorem bsV_valSize_split (ns codes : List ℕ) :
    valSize (Val.list ((splitBlocks ns codes).map (encL encN))) ≤
      valSize (encL encN codes) + 2 * ns.length := by
  have h := bsV_listSize_split ns codes
  have e : valSize (encL encN codes) = 1 + listSize (codes.map encN) := by simp [encL]
  rw [valSize_list, e]
  omega

/-- `splitBlocks` has the block sizes when there are enough entries. -/
theorem splitBlocks_map_length : ∀ (ns l : List ℕ), ns.sum ≤ l.length →
    (splitBlocks ns l).map List.length = ns
  | [], _, _ => rfl
  | n :: ns, l, h => by
    simp only [List.sum_cons] at h
    simp only [splitBlocks, List.map_cons, List.length_take]
    rw [splitBlocks_map_length ns (l.drop n) (by rw [List.length_drop]; omega)]
    congr 1
    omega

/-- The query table of a request on the stored blocks (oracle answers in `[0, 2^{qA+1}]`) is below `adaBoundA A`. -/
theorem valSize_evals_le (eA eXi M J R : ℕ) {codes : List ℕ}
    (hlen : (adaParams eA eXi M J R).N ≤ codes.length) (orc : ℤ → ℤ → ℤ → ℤ)
    (hO : ∀ blk ∈ splitBlocks (adaParams eA eXi M J R).blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((adaParams eA eXi M J R).qA + 1) ∧
        orc 0 (r : ℤ) ((adaParams eA eXi M J R).qA + 1) ≤ 2 ^ ((adaParams eA eXi M J R).qA + 1)) :
    valSize (encVals (evalsOf orc (adaParams eA eXi M J R).qA
      (splitBlocks (adaParams eA eXi M J R).blockSizes codes))) ≤ adaBoundA (adaParams eA eXi M J R) := by
  refine valSize_encVals_le (bsP_blockSizes_length eA eXi M J R) ?_ (evalsOf_le hO)
  rw [evalsOf_map_length]
  exact splitBlocks_map_length _ _ hlen

/-- The encoded parameters are below `3 · bsPubL` (W2's `bsM_params_size`). -/
theorem bsV_params_size (Mc J R eA eXi : ℕ) :
    valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) ≤
      3 * bsPubL Mc J R eA eXi := by
  have hcap : Mc + J + R + 2 ≤ 2 ^ Nat.clog 2 (Mc + J + R + 2) := Nat.le_pow_clog (by norm_num) _
  have sM : Nat.size Mc ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sJ : Nat.size J ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sR : Nat.size R ≤ Nat.clog 2 (Mc + J + R + 2) := Nat.size_le.2 (by omega)
  have sA := size_le_self eA
  have sX := size_le_self eXi
  simp only [encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons, listSize_nil,
    valSize_int, bitLen_natCast, bsPubL]
  omega

/-- `3 · bsPubL ≤ bsPubBound`. -/
theorem three_bsPubL_le (Mc J R eA eXi : ℕ) : 3 * bsPubL Mc J R eA eXi ≤ bsPubBound Mc J R eA eXi := by
  unfold bsPubBound
  exact Nat.mul_le_mul (by norm_num) (Nat.le_self_pow (by norm_num) _)

/-! ## The value hypotheses of the D layer at `M = bsMB` -/

section D

variable {M J R eA eXi bU : ℕ}

/-- (c) **D1** (`bsBlocks_eval`): the block sizes and the record codes. -/
theorem bsMB_D1 {codes : List ℕ} (hlen : codes.length = (adaParams eA eXi M J R).N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (encL encN (adaParams eA eXi M J R).blockSizes) + valSize (encL encN codes) + 32 ≤
      bsMB M J R eA eXi bU := by
  have h1 := valSize_blockSizes_le eA eXi M J R
  have h2 := valSize_codes_le hc
  rw [hlen] at h2
  have h3 := rec_summand_bound (adaParams eA eXi M J R).N bU
  have h4 := bsMB_ada M J R eA eXi bU
  have h5 := bsMB_rec M J R eA eXi bU
  have h6 : adaBoundA (adaParams eA eXi M J R) + (2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)) ≤
      bsMB M J R eA eXi bU := by rw [bsMB_eq]; omega
  omega

/-- (d) **D2** (`bsEvals`): the stored blocks, the query table (oracle answers in `[0, 2^{qA+1}]`) and the
precision. -/
theorem bsMB_D2 {codes : List ℕ} (hlen : codes.length = (adaParams eA eXi M J R).N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) (orc : ℤ → ℤ → ℤ → ℤ)
    (hO : ∀ blk ∈ splitBlocks (adaParams eA eXi M J R).blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((adaParams eA eXi M J R).qA + 1) ∧
        orc 0 (r : ℤ) ((adaParams eA eXi M J R).qA + 1) ≤ 2 ^ ((adaParams eA eXi M J R).qA + 1)) :
    valSize (Val.list ((splitBlocks (adaParams eA eXi M J R).blockSizes codes).map (encL encN))) +
        valSize (encVals (evalsOf orc (adaParams eA eXi M J R).qA
          (splitBlocks (adaParams eA eXi M J R).blockSizes codes))) +
        2 * (adaParams eA eXi M J R).qA + 64 ≤ bsMB M J R eA eXi bU := by
  have h1 := bsV_valSize_split (adaParams eA eXi M J R).blockSizes codes
  rw [bsP_blockSizes_length] at h1
  have h2 := valSize_codes_le hc
  rw [hlen] at h2
  have h3 := valSize_evals_le eA eXi M J R (le_of_eq hlen.symm) orc hO
  have h4 := adaZ_le_adaBoundA (adaParams eA eXi M J R)
  have h5 := qA_le_adaZ (adaParams eA eXi M J R)
  have h6 := p_le_adaZ (adaParams eA eXi M J R)
  have h7 := rec_summand_bound (adaParams eA eXi M J R).N bU
  have h8 : 2 * adaBoundA (adaParams eA eXi M J R) +
      (2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)) ≤ bsMB M J R eA eXi bU := by
    rw [bsMB_eq]; omega
  omega

/-- (e) **D3** (`bsEnds_eval`): `20 qA + 200 ≤ bsMB`. -/
theorem bsMB_D3 : 20 * (adaParams eA eXi M J R).qA + 200 ≤ bsMB M J R eA eXi bU := by
  have h1 := adaZ_le_adaBoundA (adaParams eA eXi M J R)
  have h2 := qA_le_adaZ (adaParams eA eXi M J R)
  have h3 := bsMB_ada M J R eA eXi bU
  omega

/-- (f) **D4, initialization** (`bsInit_impl`): `2^32 · adaBoundA A + 2 · valSize (encL encN codes) ≤ bsMB`. -/
theorem bsMB_D4init {codes : List ℕ} (hlen : codes.length = (adaParams eA eXi M J R).N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    2 ^ 32 * adaBoundA (adaParams eA eXi M J R) + 2 * valSize (encL encN codes) ≤
      bsMB M J R eA eXi bU := by
  have h2 := valSize_codes_le hc
  rw [hlen] at h2
  have h3 := rec_summand_bound (adaParams eA eXi M J R).N bU
  have h8 : 2 ^ 32 * adaBoundA (adaParams eA eXi M J R) +
      (2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)) ≤ bsMB M J R eA eXi bU := by
    rw [bsMB_eq]; omega
  omega

/-- (f) **D4, round** (`bsRound_impl`): `2^32 · adaBoundA A + 2 · valSize (stored blocks) ≤ bsMB`. -/
theorem bsMB_D4round {codes : List ℕ} (hlen : codes.length = (adaParams eA eXi M J R).N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    2 ^ 32 * adaBoundA (adaParams eA eXi M J R) +
        2 * valSize (Val.list ((splitBlocks (adaParams eA eXi M J R).blockSizes codes).map (encL encN))) ≤
      bsMB M J R eA eXi bU := by
  have h1 := bsV_valSize_split (adaParams eA eXi M J R).blockSizes codes
  rw [bsP_blockSizes_length] at h1
  have h2 := valSize_codes_le hc
  rw [hlen] at h2
  have h6 := adaZ_le_adaBoundA (adaParams eA eXi M J R)
  have h7 := p_le_adaZ (adaParams eA eXi M J R)
  have h3 := rec_summand_bound (adaParams eA eXi M J R).N bU
  have h8 : 2 ^ 33 * adaBoundA (adaParams eA eXi M J R) +
      (2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)) ≤ bsMB M J R eA eXi bU := by
    rw [bsMB_eq]; omega
  omega

/-- (f) **D4, round input**: the parameters, the state (stored blocks and an ADA state satisfying the
invariant) and the request kind fit in `bsMB` (with `2^32 · adaBoundA A` to spare). -/
theorem bsMB_D4input {codes : List ℕ} (hlen : codes.length = (adaParams eA eXi M J R).N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {st : AdaState} (hok : AdaOK (adaParams eA eXi M J R) st)
    {k : ℤ} (hk : bitLen k ≤ 1) :
    2 ^ 32 * adaBoundA (adaParams eA eXi M J R) +
        valSize (Val.list [encInts [(M : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
          Val.list [Val.list ((splitBlocks (adaParams eA eXi M J R).blockSizes codes).map (encL encN)),
            adaEnc st], Val.int k]) ≤ bsMB M J R eA eXi bU := by
  have h1 := bsV_valSize_split (adaParams eA eXi M J R).blockSizes codes
  rw [bsP_blockSizes_length] at h1
  have h2 := valSize_codes_le hc
  rw [hlen] at h2
  have h3 := valSize_adaEnc_le hok
  have h4 := bsV_params_size M J R eA eXi
  have h5 := three_bsPubL_le M J R eA eXi
  have h6 := adaZ_le_adaBoundA (adaParams eA eXi M J R)
  have h7 := p_le_adaZ (adaParams eA eXi M J R)
  have h8 := rec_summand_bound (adaParams eA eXi M J R).N bU
  have h9 : 2 ^ 33 * adaBoundA (adaParams eA eXi M J R) + bsPubBound M J R eA eXi +
      (2 ^ 4 * ((adaParams eA eXi M J R).N + 4) * (bU + 4)) ≤ bsMB M J R eA eXi bU := le_of_eq rfl
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at h1 ⊢
  omega

end D

end F2e2e.BSpace
