import F2e2e.BSpace.O2GlueMainDefs
import F2e2e.BSpace.O2GlueBlocks
import F2e2e.BSpace.AssembleDefs

/-!
# B_space, route O2b: the top frame of the initialization program (o2i)

Owner: e26ae4ae (W1), for the O2b technical lead 17fc0802; consumers W4 (`O2Inputs.implI`,
`F2e2e/BSpace/O2Assemble.lean`), C-PROB (`inI` and the coefficient lemmas), B-ACC (`finI`).

`body_bsInit` (W2's D4, `F2e2e/BSpace/DslBodies.lean`), environment `[[params, records]]`:
`pub := adaPub params` (600), `blocks := bsBlocks [pub.blockSizes, records]` (900, D1),
`st := adaInit pub` (601); output `[blocks, adaEnc st] = bsStateEnc blocks st`.

Route O2b (C-SPACE's per-call judgment `EvalsValF`, `F2e2e/BSpace/O2GstF.lean`) charges every callee at its
OWN value bound and budget `(m', τ')`: the call costs `(exprDepth body + 2) · m' + τ'`, and the calls of a frame
are sequential, so the frame's budget `τ` only needs to cover each call separately.

* `O2iInitAt`: the callee predicate of `adaInit` (601), in C-BANK's style (`O2mPubAt` for 600,
  `F2e2e/BSpace/O2GlueMainDefs.lean`); `o2i_initAt_of_lift`: from the uniform spec by the weighted lifting.
* `o2i_B`: the top-frame value bound (parameters, parameter record, records `≤ vC`, the `2 (p + 1)` block cells,
  the encoded state `o2mStB A`, and `3`).
* **`o2i_bsInit_implF`**: the generic top frame (any `orc`, `prog`, frame `(m, τ)` with `o2i_B ≤ m` and the three
  call charges `≤ τ`; 900 by W3's `o2k_bsBlocks_callF`, charge `31 · o2k_B`).
* **The explicit bounds** (the fields `mI`, `τI` of W4's `O2Inputs`): `o2i_mI = o2i_B` with the records bounded by
  `o2iRecB A bU = N (b_𝒰 + 2) + 1`; `o2i_τI = o2iTopT = max(134 · bsPubBound, 31 · (|blockSizes| + o2iRecB + 32),
  136 · o2MA)`: `adaPub` at `bsPubBound` (C-BANK's `o2mMP`) with budget `81 · bsPubBound`, `adaInit` at
  `o2MA = 2^8 tightA + cAddA` (`TightM`) with budget `114 · o2MA` (`C = w − depth − 3` from O2B-GST's
  `bsWeightOK_init`: `w 600 = 135`, `w 601 = 137`; depths `51`, `20`), so the calls cost
  `(51 + 2 + 81) · bsPubBound`, `31 · o2k_B`, `(20 + 2 + 114) · o2MA`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The callee predicate of `adaInit` (601) -/

/-- **`adaInit` (601) at its own per-call budget `(mA, τA)`**: on the parameter record `adaPubEnc A` it implements
`adaInit A` with the state encoding `adaEnc`. -/
def O2iInitAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mA τA : ℕ) (A : AdaParams) : Prop :=
  prog[Idx.adaInit]? = some body_adaInit ∧ valSize (adaPubEnc A) ≤ mA ∧
    ImplementsF orc prog mA τA [adaPubEnc A] body_adaInit adaEnc (adaInit A)

/-- **`adaInit` at `(M, C · M)`** from a uniform spec at `M` (e.g. `adaInit_impl_t` under `TightM A M`), by the
weighted lifting (weight certificate `w`, callees of `body_adaInit` of weight `≤ C`). -/
theorem o2i_initAt_of_lift {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (h601 : prog[Idx.adaInit]? = some body_adaInit) {A : AdaParams} {M : ℕ}
    (hI : Implements prog M [adaPubEnc A] body_adaInit adaEnc (adaInit A))
    (hpubM : valSize (adaPubEnc A) ≤ M) {C : ℕ} (hc : CalleesLe w C body_adaInit) :
    O2iInitAt orc prog M (C * M) A :=
  ⟨h601, hpubM, Implements.toF_wt hO hW hI
    (fun x hx => by rw [List.mem_singleton.mp hx]; exact hpubM) hc⟩

/-! ## Depths -/

theorem o2i_depth_bsInit : exprDepth body_bsInit = 8 := by decide

theorem o2i_depth_adaInit : exprDepth body_adaInit = 20 := by decide

/-! ## The top-frame value bound -/

/-- **The top-frame value bound of `body_bsInit`** for the parameters `encInts [Mc, J, R, eA, eXi]` and records of
size `≤ vC` (`A = adaParams eA eXi Mc J R`): `|params| + |adaPubEnc A| + vC + 2 (p + 1) + o2mStB A + 3`. It covers
the input `[params, records]`, the record `pub`, the argument `[pub.blockSizes, records]` of 900, the stored blocks
(`≤ |records| + 2 (p + 1)`, `bsM_valSize_split`) and the output `[blocks, adaEnc st]` (`adaEnc st ≤ o2mStB A` for
every state with `AdaOK A st`, B-ACC's `bsT_valSize_adaEnc`). -/
def o2i_B (Mc J R eA eXi vC : ℕ) : ℕ :=
  valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) +
    valSize (adaPubEnc (adaParams eA eXi Mc J R)) + vC + 2 * ((adaParams eA eXi Mc J R).p + 1) +
    o2mStB (adaParams eA eXi Mc J R) + 3

/-! ## The top frame -/

set_option maxHeartbeats 1000000 in
/-- **The top frame of `body_bsInit`** (route O2b, generic): on `[encInts [Mc, J, R, eA, eXi], encL encN codes]`
(`A.N` codes, `valSize (encL encN codes) ≤ vC`), `body_bsInit` implements `adaInit A` with the state encoding
`bsStateEnc (splitBlocks A.blockSizes codes)` (`A = adaParams eA eXi Mc J R`), in every frame `(m, τ)` with
`o2i_B ≤ m` whose budget covers the three calls: `adaPub` (600) at its own `(mP, τP)`, `bsBlocks` (900, W3's
`o2k_bsBlocks_callF`: `31 · o2k_B`) and `adaInit` (601) at its own `(mA, τA)`. -/
theorem o2i_bsInit_implF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hO : prog[bsOracleIdx]? = none) (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2)
    {Mc J R eA eXi : ℕ} {codes : List ℕ} (hcodes : codes.length = (adaParams eA eXi Mc J R).N)
    {vC : ℕ} (hvC : valSize (encL encN codes) ≤ vC) {mP τP mA τA m τ : ℕ}
    (hPub : O2mPubAt orc prog mP τP Mc J R eA eXi)
    (hInit : O2iInitAt orc prog mA τA (adaParams eA eXi Mc J R))
    (hm : o2i_B Mc J R eA eXi vC ≤ m)
    (hτP : (exprDepth body_adaPub + 2) * mP + τP ≤ τ)
    (hτK : 31 * (valSize (encL encN (adaParams eA eXi Mc J R).blockSizes) + vC + 32) ≤ τ)
    (hτA : (exprDepth body_adaInit + 2) * mA + τA ≤ τ) :
    ImplementsF orc prog m τ
      [Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)], encL encN codes]] body_bsInit
      (bsStateEnc (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes))
      (adaInit (adaParams eA eXi Mc J R)) := by
  obtain ⟨h600, hinP, hpubF⟩ := hPub
  have hbs := bsP_blockSizes_length eA eXi Mc J R
  unfold o2i_B at hm
  generalize encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)] = params at *
  generalize adaParams eA eXi Mc J R = A at *
  obtain ⟨h601, hinA, hinitF⟩ := hInit
  /- ### Sizes -/
  have hinM : valSize (Val.list [params, encL encN codes]) ≤ m := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hpubS : valSize (adaPubEnc A) ≤ m := by omega
  have hbsS : valSize (encL encN A.blockSizes) < valSize (adaPubEnc A) :=
    valSize_lt_of_mem (l := pubFields A) (by simp [pubFields])
  have hspl := bsM_valSize_split A.blockSizes codes
  rw [hbs] at hspl
  /- ### The parameter record (600) -/
  have hpE : EvalsValF orc prog m τ [Val.list [params, encL encN codes]] []
      (.inl (eCall Idx.adaPub (eAtN 0 (eV 0)))) (adaPubEnc A) := by
    refine evalsValF_call_det (by decide) h600 ?_ hpubF hinP hpubS hτP
    exact EvalsVal.toF_callFree hO (evalsVal_atN' (EvalsVal.var rfl) hinM rfl)
      ((callFreeB_iff _).mp rfl) τ
  unfold body_bsInit
  refine implementsF_letE_det hpE ?_
  /- ### The blocks (900) -/
  have hlen : A.blockSizes.sum ≤ codes.length := by rw [hcodes]; rfl
  have hblkS : valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) ≤ m := by
    omega
  have hargS : valSize (Val.list [encL encN A.blockSizes, encL encN codes]) ≤ m := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hinM ⊢
    omega
  have hbE : EvalsValF orc prog m τ [adaPubEnc A, Val.list [params, encL encN codes]] []
      (.inl (eCall bsBlocksKey (ePair (eAtN 1 (eV 0)) (eAtN 1 (eV 1)))))
      (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) := by
    refine o2k_bsBlocks_callF hO hlib hlen ?_ hblkS ?_
    · exact EvalsVal.toF_callFree hO (EvalsVal.pair
        (evalsVal_atN' (l := pubFields A) (EvalsVal.var rfl) hpubS rfl)
        (evalsVal_atN' (EvalsVal.var rfl) hinM rfl) hargS) ((callFreeB_iff _).mp rfl) τ
    · unfold o2k_B
      omega
  refine implementsF_letE_det hbE ?_
  /- ### `adaInit` (601) -/
  rw [← BitProg.bind_pure_right (adaInit A)]
  refine implementsF_letE_of (implementsF_call_det (by decide) h601 EvalsValF.var1 hinitF hinA ?_ hτA)
    (AdaOK A) (fun bits st h => Always.of_run (adaInit_ok hbs) h) ?_
  · intro bits st h
    have hstS := o2m_valSize_adaEnc_le (Always.of_run (adaInit_ok hbs) h)
    omega
  · intro st hok
    apply ImplementsF.of_det
    have hstS := o2m_valSize_adaEnc_le hok
    refine EvalsValF.pair EvalsValF.var1 EvalsValF.var0 ?_
    simp only [valSize_list, listSize_cons, listSize_nil] at hspl ⊢
    omega

/-! ## The explicit bounds (the fields `mI`, `τI` of `O2Inputs`) -/

/-- The encoded records: `N (b_𝒰 + 2) + 1` for `N = A.N` codes `< 2^{b_𝒰}` (`valSize_codes_le`). -/
def o2iRecB (A : AdaParams) (bU : ℕ) : ℕ := A.N * (bU + 2) + 1

/-- **The callee budget of the init frame** (`A = adaParams eA eXi Mc J R`): the largest call charge,
`max(134 · bsPubBound, 31 · (|A.blockSizes| + o2iRecB A bU + 32), 136 · o2MA A)`. -/
def o2iTopT (Mc J R eA eXi bU : ℕ) : ℕ :=
  max (134 * bsPubBound Mc J R eA eXi)
    (max (31 * (valSize (encL encN (adaParams eA eXi Mc J R).blockSizes) +
        o2iRecB (adaParams eA eXi Mc J R) bU + 32))
      (136 * o2MA (adaParams eA eXi Mc J R)))

/-- **`mI`**: the value bound of the init frame, at `A = asmParams M J R a_req ξ_req`. -/
noncomputable def o2i_mI (M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) : ℕ :=
  o2i_B M J R (dyadicExp aReq) (dyadicExp ξReq) (o2iRecB (asmParams M J R aReq ξReq) bU)

/-- **`τI`**: the callee budget of the init frame, at `A = asmParams M J R a_req ξ_req`. -/
noncomputable def o2i_τI (M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) : ℕ :=
  o2iTopT M J R (dyadicExp aReq) (dyadicExp ξReq) bU

end F2e2e.BSpace
