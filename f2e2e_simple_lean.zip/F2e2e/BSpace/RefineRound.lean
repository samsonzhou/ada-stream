import F2e2e.B.SpecV2BridgeFinal

/-!
# B_space, layer R (B-ARCH): round and init conformance of the core with the Spec's Algorithm 2

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §R (area lead W4). The DSL programs of `Theorem_B_space` run the
core of `F2e2e/B/ArchCore.lean` on exactly the data of the quantized request `quantReq A req`
(W4's alignment, 13:13Z): the grid indices `coreVals A s (quantReq A req)` of the records (D2) and
the grid endpoints `(quantReq A req).l = h_A · endIdx A l`, `.u` (D3); the round program implements
`adaInterval A st vals l u` / `adaNumerical A st vals`, i.e. `coreStep A s (quantReq A req) st`
(D4). This file transports one such round, and the initialization, to the Spec's `alg2Request`,
`alg2Init`, along the simulation relation `StCorr` of the bridge (`F2e2e/B/SpecV2BridgeCorr.lean`):

* `refine_parCorr`, `refine_N`: the parameter correspondence and `N = N` for the actual parameters
  `A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R` (= `adaAlg2Params M J R aReq ξReq`);
* **R2** `refine_init`: a successful run of `adaInit A` on a tape gives `alg2Init` on the same tape,
  the same rest of the tape, and corresponding states;
* **R1** `refine_round` (on `coreStep`), and its two branches `refine_interval`, `refine_numerical`
  (on `adaInterval`/`adaNumerical`, as D4 states the round): a successful core round on a tape gives
  `alg2Request` on the same tape with the response `outRespV2 out` (`certRespV2`/`numRespV2`), the
  same rest of the tape, and corresponding states.

The sample of the Spec is `s : Fin P2.N → U`; the core reads it as `castSample hN s : Fin A.N → U`
(`hN : P2.N = A.N`). Requests are raw `(f, isInterval, l, u)` with `f` valued in `[0, 1]` (§7's
`VReq U` and the first conjunct of `VReq.Valid`).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2

/-! ## The actual parameters -/

/-- The parameter correspondence for the actual parameters of `Theorem_B_space`. -/
theorem refine_parCorr (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    ParCorr (F2e2e.alg2Params M J R aReq ξReq)
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) :=
  parCorr_alg2 M J R ha0 ha1 hξ0 hξ1

/-- The sample sizes agree: `(alg2Params …).N = A.N`. -/
theorem refine_N (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (F2e2e.alg2Params M J R aReq ξReq).N =
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N :=
  v2par_N M J R ha0 ha1 hξ0 hξ1

/-! ## R2: initialization -/

/-- **R2 (init conformance).** If `adaInit A` succeeds on the tape `τ` with the state `st` and the
rest `rest`, then the Spec's initialization on `τ` leaves the same rest and a corresponding state. -/
theorem refine_init {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A) {τ : List Bool}
    {st : AdaState} {rest : List Bool} (h : (adaInit A).run τ = some (st, rest)) :
    StCorr A (F2e2e.alg2Init P2 τ).1 st ∧ (F2e2e.alg2Init P2 τ).2 = rest :=
  init_sim hP h

/-! ## R1: one request -/

/-- **R1 (round conformance).** If the core round on the quantized request succeeds on the tape `τ`
with the output `out`, the state `st'` and the rest `rest`, then the Spec's `alg2Request` on the
view of the request, from a corresponding state, on the same tape, returns `outRespV2 out`, the same
rest and a corresponding state. -/
theorem refine_round {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr A st2 st)
    (s : Fin P2.N → U) (req : (U → ℝ) × Bool × ℝ × ℝ) (hreq : ∀ x, 0 ≤ req.1 x ∧ req.1 x ≤ 1)
    {τ : List Bool} {out : CoreOut} {st' : AdaState} {rest : List Bool}
    (h : (coreStep A (castSample hN s) (quantReq A req) st).run τ = some ((out, st'), rest)) :
    ∃ st2' : F2e2e.Alg2State,
      F2e2e.alg2Request P2 st2 ((fun ℓ => req.1 (s ℓ)), req.2) τ = (outRespV2 out, st2', rest) ∧
        StCorr A st2' st' := by
  refine step_sim hP hN hst req hreq s ?_
  rw [← coreStep_eq_toBits]
  exact h

/-- **R1, interval requests** (the round as D4 states it: `adaInterval` on the grid indices and the
grid endpoints of the quantized request). -/
theorem refine_interval {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr A st2 st)
    (s : Fin P2.N → U) (req : (U → ℝ) × Bool × ℝ × ℝ) (hreq : ∀ x, 0 ≤ req.1 x ∧ req.1 x ≤ 1)
    (hI : req.2.1 = true) {τ : List Bool} {c : AdaCert} {st' : AdaState} {rest : List Bool}
    (h : (adaInterval A st (coreVals A (castSample hN s) (quantReq A req)) (quantReq A req).l
      (quantReq A req).u).run τ = some ((c, st'), rest)) :
    ∃ st2' : F2e2e.Alg2State,
      F2e2e.alg2Request P2 st2 ((fun ℓ => req.1 (s ℓ)), req.2) τ = (certRespV2 c, st2', rest) ∧
        StCorr A st2' st' := by
  refine refine_round hP hN hst s req hreq (out := Sum.inl c) ?_
  have e : coreStep A (castSample hN s) (quantReq A req) st =
      (adaInterval A st (coreVals A (castSample hN s) (quantReq A req)) (quantReq A req).l
        (quantReq A req).u).map fun r => (Sum.inl r.1, r.2) := by
    unfold coreStep
    exact if_pos hI
  simp only [e, BitProg.run_map, h, Option.map_some]

/-- **R1, numerical requests** (`adaNumerical` on the grid indices of the quantized request). -/
theorem refine_numerical {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) {st2 : F2e2e.Alg2State} {st : AdaState} (hst : StCorr A st2 st)
    (s : Fin P2.N → U) (req : (U → ℝ) × Bool × ℝ × ℝ) (hreq : ∀ x, 0 ≤ req.1 x ∧ req.1 x ≤ 1)
    (hI : req.2.1 = false) {τ : List Bool} {x : AdaNum} {st' : AdaState} {rest : List Bool}
    (h : (adaNumerical A st (coreVals A (castSample hN s) (quantReq A req))).run τ =
      some ((x, st'), rest)) :
    ∃ st2' : F2e2e.Alg2State,
      F2e2e.alg2Request P2 st2 ((fun ℓ => req.1 (s ℓ)), req.2) τ = (numRespV2 x, st2', rest) ∧
        StCorr A st2' st' := by
  refine refine_round hP hN hst s req hreq (out := Sum.inr x) ?_
  have e : coreStep A (castSample hN s) (quantReq A req) st =
      (adaNumerical A st (coreVals A (castSample hN s) (quantReq A req))).map
        fun r => (Sum.inr r.1, r.2) := by
    unfold coreStep
    exact if_neg (show ¬ req.2.1 = true by rw [hI]; decide)
  simp only [e, BitProg.run_map, h, Option.map_some]

end F2e2e.BSpace
