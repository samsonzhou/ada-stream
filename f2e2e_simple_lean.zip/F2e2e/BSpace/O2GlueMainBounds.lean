import F2e2e.BSpace.O2GlueMainDefs
import F2e2e.BSpace.AssembleDefs

/-!
# B_space, route O2b: the top frame of the round program, the explicit bounds (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802 (statement list approved 14:10Z). The value bound
`m_top` and the callee budget `τ_top` of the frame of `body_bsRound`, as explicit functions of the core parameters
`A` and the record width `b_𝒰`, and their instances `o2m_mR`, `o2m_τR` at `A = asmParams M J R a_req ξ_req`
(the fields `mR`, `τR` of W4's `O2Inputs`, `F2e2e/BSpace/O2Assemble.lean`).

* **Frame bound** `o2mTopM = o2mInpB + o2mPubRecB + o2mValsB + o2mStB + 4 q_A + 64`: B-ACC's per-record bounds
  (`F2e2e/BSpace/O2TightSizes.lean`) of the round input (`bsT_valSize_roundIn_state`), the parameter record
  (`bsT_valSize_adaPubEnc`), the query table (`bsT_valSize_encVals`) and an encoded state with `AdaOK`
  (`bsT_valSize_adaEnc`), plus the endpoints and slack; it covers every value of the frame (the bounds
  `o2mIvB`, `o2mNumB`, `o2mPreB` of the pieces, with the actual sizes replaced by these bounds).
* **Callee bounds**: `adaPub` at `o2mMP = bsPubBound`; `bsEvals` (native, 1beb339b) at
  `o2mME ≥ o2e_B`; `bsEnds` at `o2mMD = 20 q_A + 200`; `adaNumerical` at `o2MA = 2^8 tightA + cAddA`
  (`TightM`); `adaInterval` at `o2mMI = o2MA + 2^28 (q_A + 4)` (`TightM` and the endpoint premise of
  `adaInterval_impl`, `Bq = q_A + 4`).
* **Callee budget** `o2mTopT = max(135 o2mMP, 50 o2mME, 38 o2mMD, 231 o2mMI, 240 o2MA)`: a weighted call of
  routine `i` at bound `M` costs `bsWRound i · M` (O2B-GST's certificate `bsWeightOK_round`, `bsW_vals`:
  `w 600 = 135`, `w 602 = 231`, `w 603 = 240`, `w 920 = 38`); the native `bsEvals` frame costs
  `(7 + 2) o2mME + 41 o2mME`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## Value bounds of the frame -/

/-- The round input `[params, [blocks, adaEnc st], kind]` (B-ACC's `bsT_valSize_roundIn_state`). -/
def o2mInpB (A : AdaParams) (bU Mc J R eA eXi : ℕ) : ℕ :=
  A.N * (bU + A.qA + Nat.size A.fuel + 6) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) +
    Nat.size (maxKs A) + 3 * Nat.size (A.M + A.J + A.R + 2) + 3 * bsPubL Mc J R eA eXi + 37

/-- The parameter record (B-ACC's `bsT_valSize_adaPubEnc`). -/
def o2mPubRecB (A : AdaParams) : ℕ :=
  (A.p + 1) * (Nat.size A.N + 2) + A.p * (Nat.size A.fuel + 2) + 32 * (adaZ A + 16)

/-- The query table (B-ACC's `bsT_valSize_encVals`). -/
def o2mValsB (A : AdaParams) : ℕ := A.N * (A.qA + 3) + 2 * (A.p + 1) + 1

/-- The stored blocks (B-ACC's `bsT_valSize_blocks`). -/
def o2mBlocksB (A : AdaParams) (bU : ℕ) : ℕ := A.N * (bU + 2) + 2 * (A.p + 1) + 1

/-- **The value bound of the top frame of `body_bsRound`.** -/
def o2mTopM (A : AdaParams) (bU Mc J R eA eXi : ℕ) : ℕ :=
  o2mInpB A bU Mc J R eA eXi + o2mPubRecB A + o2mValsB A + o2mStB A + 4 * A.qA + 64

/-! ## Callee bounds and the budget -/

/-- `adaPub` (600) runs at `bsPubBound`. -/
def o2mMP (Mc J R eA eXi : ℕ) : ℕ := bsPubBound Mc J R eA eXi

/-- `bsEvals` (910, native) runs at `o2mME ≥ o2e_B` (stored blocks + query table + `2 q_A + 64`). -/
def o2mME (A : AdaParams) (bU : ℕ) : ℕ := o2mBlocksB A bU + o2mValsB A + 2 * A.qA + 64

/-- `bsEnds` (920) runs at `20 q_A + 200` (W5's `bsEnds_eval`). -/
def o2mMD (A : AdaParams) : ℕ := 20 * A.qA + 200

/-- `adaInterval` (602) runs at `o2MA + 2^28 (q_A + 4)` (`TightM` and `2^28 · Bq ≤ M`, `Bq = q_A + 4`); `adaNumerical`
(603) runs at `o2MA` (`O2GlueMainDefs`). -/
def o2mMI (A : AdaParams) : ℕ := o2MA A + 2 ^ 28 * (A.qA + 4)

/-- **The callee budget of the top frame of `body_bsRound`**: the largest weighted call cost. -/
def o2mTopT (A : AdaParams) (bU Mc J R eA eXi : ℕ) : ℕ :=
  max (135 * o2mMP Mc J R eA eXi)
    (max (50 * o2mME A bU) (max (38 * o2mMD A) (max (231 * o2mMI A) (240 * o2MA A))))

theorem o2mMI_tight (A : AdaParams) : TightM A (o2mMI A) := by
  unfold TightM o2mMI o2MA
  omega

/-! ## The instances of `O2Inputs` -/

/-- **`mR`**: the value bound of the request frame, at `A = asmParams M J R a_req ξ_req`. -/
noncomputable def o2m_mR (M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) : ℕ :=
  o2mTopM (asmParams M J R aReq ξReq) bU M J R (dyadicExp aReq) (dyadicExp ξReq)

/-- **`τR`**: the callee budget of the request frame, at `A = asmParams M J R a_req ξ_req`. -/
noncomputable def o2m_τR (M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) : ℕ :=
  o2mTopT (asmParams M J R aReq ξReq) bU M J R (dyadicExp aReq) (dyadicExp ξReq)

end F2e2e.BSpace
