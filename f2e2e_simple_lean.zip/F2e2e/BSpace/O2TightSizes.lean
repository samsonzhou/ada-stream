import F2e2e.C.Impl.AdaBounds
import F2e2e.C.Impl.AdaMusDefs
import F2e2e.BSpace.BoundValue
import F2e2e.BSpace.BoundParams

/-!
# B_space, O2 groundwork (B-ACC): tight value sizes, bypassing `adaBoundA`

Area lead W4 (O2a/O2b of `F2e2e/BSpace/BSPACE_PLAN.md`); shapes requested by N2 (O2b design). W4's size bounds
(`F2e2e/C/Impl/AdaBounds.lean`) go through `adaBoundA A = 2^10 (N + p + 16)(adaZ A + 16)`, about `2^16` times the
real per-record data size. Here the same values are bounded per record, with literal constants and no `adaZ`
factor on `N`, in terms of
* `q_A`, `sF = Nat.size A.fuel` (`fuel = 1 + ∑ T_j^max`, so `sF ≤ log₂(T_sum + 1) + 1`),
* `sK = Nat.size (maxKs A)` (thresholds), `sC = Nat.size (M + J + R + 2)` (counters), `b_𝒰` (record codes):

**Small values (3).** `bsT_score_bitLen`: every score has `bitLen ≤ q_A + sF + 2`; T-counters `≤ sF`, thresholds
`≤ sK`, request/rejection counters `≤ sC` (`bsT_T_size`, `bsT_thr_bitLen`, `bsT_thrOut_bitLen`, `bsT_counters_size`);
one row of scores `≤ 1 + n_j (q_A + sF + 4)` (`bsT_row_valSize`); the parameter record
`≤ (p + 1)(size N + 2) + p (sF + 2) + 32 (adaZ A + 16)` (`bsT_valSize_adaPubEnc`).

**Per-record linear forms (1).**
* `bsT_valSize_adaEnc`: `valSize (adaEnc st) ≤ N (q_A + sF + 4) + p (sF + sK + 6) + sK + 3 sC + 24`;
* `bsT_valSize_encVals`: `valSize (encVals vals) ≤ N (q_A + 3) + 2 (p + 1) + 1`;
* `bsT_valSize_blocks`: the stored blocks `≤ N (b_𝒰 + 2) + 2 (p + 1) + 1`;
* `bsT_valSize_state`: the B state `[blocks, adaEnc st]` (= D4's `bsStateEnc`)
  `≤ N (b_𝒰 + q_A + sF + 6) + p (sF + sK + 8) + sK + 3 sC + 30`.

**Round values (2).** `bsT_valSize_roundIn` (`[params, state, kind]`) and `bsT_valSize_roundOut`
(`[state', resp]`).

**In terms of `χ` (4)** for the actual parameters (B-ARCH's S3, `F2e2e/BSpace/BoundParams.lean`):
`bsT_qA_sF_le_chi : q_A + sF + 59 ≤ 34 χ`, `bsT_sK_le_chi : sK ≤ 35 χ + 3`, `bsT_sC_le_chi : sC ≤ χ + 1`, and
`bsT_valSize_adaEnc_chi : valSize (adaEnc st) ≤ N (72 χ + 17)`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Small values -/

section small

variable {A : AdaParams} {st : AdaState}

theorem bsT_T_sum_lt (hok : AdaOK A st) : st.T.sum < A.fuel := by
  have := sum_le_of_getD_le st.T A.Tmax (fun j => by
    by_cases hj : j < A.p
    · exact hok.T_le j hj
    · rw [List.getD_eq_default _ _ (by rw [hok.T_len]; omega)]
      exact Nat.zero_le _)
  unfold AdaParams.fuel
  omega

/-- **Scores** have at most `q_A + sF + 2` bits (`|z| ≤ 4 · 2^{q_A} · T_sum`, `T_sum < fuel`). -/
theorem bsT_score_bitLen (hok : AdaOK A st) :
    ∀ g ∈ st.scores, ∀ z ∈ g, bitLen z ≤ A.qA + Nat.size A.fuel + 2 := by
  intro g hg z hz
  apply bitLen_le_of_abs_lt
  have h1 := hok.scores_le g hg z hz
  have h2 : (A.fuel : ℤ) < 2 ^ Nat.size A.fuel := by exact_mod_cast Nat.lt_size_self A.fuel
  have h3 : (st.T.sum : ℤ) < A.fuel := by exact_mod_cast bsT_T_sum_lt hok
  calc |z| ≤ 4 * 2 ^ A.qA * (st.T.sum : ℤ) := h1
    _ < 4 * 2 ^ A.qA * 2 ^ Nat.size A.fuel := by
        apply mul_lt_mul_of_pos_left (h3.trans h2); positivity
    _ = 2 ^ (A.qA + Nat.size A.fuel + 2) := by rw [pow_add, pow_add]; ring

/-- **Correction counters** have at most `sF` bits. -/
theorem bsT_T_size (hok : AdaOK A st) : ∀ t ∈ st.T, Nat.size t ≤ Nat.size A.fuel := by
  intro t ht
  have h1 : t ≤ st.T.sum := List.le_sum_of_mem ht
  have h2 := bsT_T_sum_lt hok
  exact Nat.size_le_size (by omega)

/-- **Internal thresholds** have at most `sK` bits. -/
theorem bsT_thr_bitLen (hok : AdaOK A st) : ∀ z ∈ st.thrInt, bitLen z ≤ Nat.size (maxKs A) := by
  intro z hz
  unfold bitLen
  apply Nat.size_le_size
  have : (z.natAbs : ℤ) ≤ (maxKs A : ℤ) := by rw [Int.natCast_natAbs]; exact hok.thr_le z hz
  exact_mod_cast this

/-- **The outer threshold** has at most `sK` bits. -/
theorem bsT_thrOut_bitLen (hok : AdaOK A st) : bitLen st.thrOut ≤ Nat.size (maxKs A) := by
  unfold bitLen
  apply Nat.size_le_size
  have : (st.thrOut.natAbs : ℤ) ≤ (maxKs A : ℤ) := by rw [Int.natCast_natAbs]; exact hok.thrOut_le
  exact_mod_cast this

/-- **Request and rejection counters** have at most `sC = size (M + J + R + 2)` bits. -/
theorem bsT_counters_size (hok : AdaOK A st) :
    Nat.size st.rej ≤ Nat.size (A.M + A.J + A.R + 2) ∧
      Nat.size st.nInt ≤ Nat.size (A.M + A.J + A.R + 2) ∧
      Nat.size st.nNum ≤ Nat.size (A.M + A.J + A.R + 2) :=
  ⟨Nat.size_le_size (by have := hok.rej_le; omega), Nat.size_le_size (by have := hok.nInt_le; omega),
    Nat.size_le_size (by have := hok.nNum_le; omega)⟩

/-- **One row of scores**: `valSize (encL encZ g) ≤ 1 + |g| (q_A + sF + 4)`. -/
theorem bsT_row_valSize (hok : AdaOK A st) {g : List ℤ} (hg : g ∈ st.scores) :
    valSize (encL encZ g) ≤ 1 + g.length * (A.qA + Nat.size A.fuel + 4) := by
  have h := valSize_encL_le encZ g (A.qA + Nat.size A.fuel + 3) (fun z hz => by
    simp only [encZ, valSize_int]
    have := bsT_score_bitLen hok g hg z hz
    omega)
  rw [show A.qA + Nat.size A.fuel + 3 + 1 = A.qA + Nat.size A.fuel + 4 by omega] at h
  exact h

end small

/-! ## Per-record linear forms -/

section linear

variable {A : AdaParams} {st : AdaState}

/-- The scores, for any bound `S` on their total length: `≤ S (q_A + sF + 4) + 2p + 1`. -/
theorem bsT_valSize_scores_of (hok : AdaOK A st) {S : ℕ} (hS : (st.scores.map List.length).sum ≤ S) :
    valSize (encL (encL encZ) st.scores) ≤ S * (A.qA + Nat.size A.fuel + 4) + 2 * A.p + 1 := by
  rw [valSize_encL]
  have hrow : ∀ g ∈ st.scores, valSize (encL encZ g) + 1 ≤ 2 + g.length * (A.qA + Nat.size A.fuel + 4) := by
    intro g hg
    have := bsT_row_valSize hok hg
    omega
  have hsum : (st.scores.map fun g => valSize (encL encZ g) + 1).sum ≤
      (st.scores.map fun g => 2 + g.length * (A.qA + Nat.size A.fuel + 4)).sum :=
    List.sum_le_sum (fun g hg => hrow g hg)
  have hsum2 : (st.scores.map fun g => 2 + g.length * (A.qA + Nat.size A.fuel + 4)).sum =
      2 * st.scores.length + (st.scores.map List.length).sum * (A.qA + Nat.size A.fuel + 4) := by
    clear hsum hrow hS
    induction st.scores with
    | nil => simp
    | cons g gs ih => simp [ih]; ring
  rw [hok.scores_len] at hsum2
  have : (st.scores.map List.length).sum * (A.qA + Nat.size A.fuel + 4) ≤
      S * (A.qA + Nat.size A.fuel + 4) := Nat.mul_le_mul_right _ hS
  omega

/-- The total length of the scores is at most `N`. -/
theorem bsT_scores_length_le (hok : AdaOK A st) : (st.scores.map List.length).sum ≤ A.N := by
  apply sum_le_of_getD_le
  intro j
  by_cases hj : j < A.p
  · rw [List.getD_eq_getElem _ _ (by simp [hok.scores_len]; omega), List.getElem_map]
    have := hok.scores_blk j hj
    rw [List.getD_eq_getElem _ _ (by rw [hok.scores_len]; omega)] at this
    rw [this]
  · rw [List.getD_eq_default _ _ (by simp [hok.scores_len]; omega)]
    exact Nat.zero_le _

/-- Scores live on the learned blocks only: their lengths are `n_0, …, n_{p-1}`. -/
theorem bsT_scores_lengths (hbs : A.blockSizes.length = A.p + 1) (hok : AdaOK A st) :
    st.scores.map List.length = A.blockSizes.take A.p := by
  apply List.ext_getElem
  · simp only [List.length_map, List.length_take, hok.scores_len, hbs]
    omega
  · intro j h1 h2
    have hj : j < A.p := by simpa [hok.scores_len] using h1
    rw [List.getElem_map, List.getElem_take]
    have := hok.scores_blk j hj
    rw [List.getD_eq_getElem _ _ (by rw [hok.scores_len]; exact hj),
      List.getD_eq_getElem _ _ (by rw [hbs]; omega)] at this
    exact this

/-- The scores of all learned blocks: `≤ N (q_A + sF + 4) + 2p + 1`. -/
theorem bsT_valSize_scores (hok : AdaOK A st) :
    valSize (encL (encL encZ) st.scores) ≤ A.N * (A.qA + Nat.size A.fuel + 4) + 2 * A.p + 1 :=
  bsT_valSize_scores_of hok (bsT_scores_length_le hok)

/-- The scores, sharp: `≤ (n_0 + ⋯ + n_{p-1}) (q_A + sF + 4) + 2p + 1` (the anchor block `p`, the largest, carries
no scores). -/
theorem bsT_valSize_scores' (hbs : A.blockSizes.length = A.p + 1) (hok : AdaOK A st) :
    valSize (encL (encL encZ) st.scores) ≤
      (A.blockSizes.take A.p).sum * (A.qA + Nat.size A.fuel + 4) + 2 * A.p + 1 :=
  bsT_valSize_scores_of hok (le_of_eq (by rw [bsT_scores_lengths hbs hok]))

/-- The encoded ADA state, for any bound `S` on the total length of the scores:
`valSize (adaEnc st) ≤ S (q_A + sF + 4) + p (sF + sK + 6) + sK + 3 sC + 24`. -/
theorem bsT_valSize_adaEnc_of (hok : AdaOK A st) {S : ℕ} (hS : (st.scores.map List.length).sum ≤ S) :
    valSize (adaEnc st) ≤ S * (A.qA + Nat.size A.fuel + 4) +
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 := by
  have hsc := bsT_valSize_scores_of hok hS
  have hTV : valSize (encL encN st.T) ≤ 1 + A.p * (Nat.size A.fuel + 2) := by
    have := valSize_encL_le encN st.T (Nat.size A.fuel + 1) (fun t ht => by
      rw [valSize_encN]
      have := bsT_T_size hok t ht
      omega)
    rwa [hok.T_len] at this
  have hthrV : valSize (encL encZ st.thrInt) ≤ 1 + A.p * (Nat.size (maxKs A) + 2) := by
    have := valSize_encL_le encZ st.thrInt (Nat.size (maxKs A) + 1) (fun z hz => by
      simp only [encZ, valSize_int]
      have := bsT_thr_bitLen hok z hz
      omega)
    rwa [hok.thr_len] at this
  have hthrO := bsT_thrOut_bitLen hok
  obtain ⟨hrej, hnI, hnN⟩ := bsT_counters_size hok
  have hb1 := valSize_encB_le st.halted
  have hb2 := valSize_encB_le st.capAborted
  have hcomb : A.p * (Nat.size A.fuel + 2) + A.p * (Nat.size (maxKs A) + 2) + 2 * A.p =
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) := by ring
  unfold adaEnc
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, encZ, valSize_int]
  omega

/-- **The encoded ADA state, per record**:
`valSize (adaEnc st) ≤ N (q_A + sF + 4) + p (sF + sK + 6) + sK + 3 sC + 24`. -/
theorem bsT_valSize_adaEnc (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ A.N * (A.qA + Nat.size A.fuel + 4) +
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 :=
  bsT_valSize_adaEnc_of hok (bsT_scores_length_le hok)

/-- **The encoded ADA state, sharp** (scores on the learned blocks only):
`valSize (adaEnc st) ≤ (n_0 + ⋯ + n_{p-1}) (q_A + sF + 4) + p (sF + sK + 6) + sK + 3 sC + 24`. -/
theorem bsT_valSize_adaEnc' (hbs : A.blockSizes.length = A.p + 1) (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ (A.blockSizes.take A.p).sum * (A.qA + Nat.size A.fuel + 4) +
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 :=
  bsT_valSize_adaEnc_of hok (le_of_eq (by rw [bsT_scores_lengths hbs hok]))

/-- **Query tables, per record**: `valSize (encVals vals) ≤ N (q_A + 3) + 2 (p + 1) + 1`. -/
theorem bsT_valSize_encVals (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) : valSize (encVals vals) ≤ A.N * (A.qA + 3) + 2 * (A.p + 1) + 1 := by
  obtain ⟨hlen, hle⟩ := hv
  have hent : ∀ blk ∈ vals, valSize (encL encN blk) + 1 ≤ 2 + blk.length * (A.qA + 3) := by
    intro blk hblk
    have := valSize_encL_le encN blk (A.qA + 2) (fun v hv' => by
      rw [valSize_encN]
      have := Nat.size_le_size (hle blk hblk v hv')
      rw [Nat.size_pow] at this
      omega)
    rw [show A.qA + 2 + 1 = A.qA + 3 by omega] at this
    omega
  have hsum : (vals.map fun blk => valSize (encL encN blk) + 1).sum ≤
      (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum :=
    List.sum_le_sum (fun blk hblk => hent blk hblk)
  have hsum2 : (vals.map fun blk => 2 + blk.length * (A.qA + 3)).sum =
      2 * vals.length + (vals.map List.length).sum * (A.qA + 3) := by
    clear hsum hent hlen hle
    induction vals with
    | nil => simp
    | cons g gs ih => simp [ih]; ring
  have hvl : vals.length = A.p + 1 := by
    have := congrArg List.length hlen
    rw [List.length_map] at this
    rw [this, hbs]
  have hN : (vals.map List.length).sum = A.N := by rw [hlen]; rfl
  rw [encVals_eq_encL, valSize_encL]
  rw [hvl, hN] at hsum2
  omega

/-- **The stored blocks, per record**: `≤ N (b_𝒰 + 2) + 2 (p + 1) + 1` for `N` codes `< 2^{b_𝒰}`. -/
theorem bsT_valSize_blocks (hbs : A.blockSizes.length = A.p + 1) {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = A.N) (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) ≤
      A.N * (bU + 2) + 2 * (A.p + 1) + 1 := by
  have h1 := bsV_valSize_split A.blockSizes codes
  have h2 := valSize_codes_le hc
  rw [hbs] at h1
  rw [hlen] at h2
  omega

/-- **The B state, per record** (`[stored blocks, adaEnc st]`, which is D4's `bsStateEnc` by definition):
`≤ N (b_𝒰 + q_A + sF + 6) + p (sF + sK + 8) + sK + 3 sC + 30`. -/
theorem bsT_valSize_state (hbs : A.blockSizes.length = A.p + 1) {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = A.N) (hc : ∀ x ∈ codes, x < 2 ^ bU) (hok : AdaOK A st) :
    valSize (Val.list [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaEnc st]) ≤
      A.N * (bU + A.qA + Nat.size A.fuel + 6) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) +
        Nat.size (maxKs A) + 3 * Nat.size (A.M + A.J + A.R + 2) + 30 := by
  have h1 := bsT_valSize_blocks hbs hlen hc
  have h2 := bsT_valSize_adaEnc hok
  have hN : A.N * (bU + 2) + A.N * (A.qA + Nat.size A.fuel + 4) = A.N * (bU + A.qA + Nat.size A.fuel + 6) := by
    ring
  have hP : 2 * (A.p + 1) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) =
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) + 2 := by ring
  simp only [valSize_list, listSize_cons, listSize_nil] at h1 ⊢
  omega

/-- **The B state, sharp** (scores on the learned blocks only):
`≤ N (b_𝒰 + 2) + (n_0 + ⋯ + n_{p-1}) (q_A + sF + 4) + p (sF + sK + 8) + sK + 3 sC + 30`. -/
theorem bsT_valSize_state' (hbs : A.blockSizes.length = A.p + 1) {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = A.N) (hc : ∀ x ∈ codes, x < 2 ^ bU) (hok : AdaOK A st) :
    valSize (Val.list [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaEnc st]) ≤
      A.N * (bU + 2) + (A.blockSizes.take A.p).sum * (A.qA + Nat.size A.fuel + 4) +
        A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) + Nat.size (maxKs A) +
        3 * Nat.size (A.M + A.J + A.R + 2) + 30 := by
  have h1 := bsT_valSize_blocks hbs hlen hc
  have h2 := bsT_valSize_adaEnc' hbs hok
  have hP : 2 * (A.p + 1) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) =
      A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) + 2 := by ring
  simp only [valSize_list, listSize_cons, listSize_nil] at h1 ⊢
  omega

end linear

/-! ## The values live in a round -/

section round

variable {A : AdaParams} {st : AdaState}

/-- **Round input** `[params, state, kind]` (`params = encInts [M, J, R, eA, eXi]`, `kind ∈ {0, 1}`): the state
bound plus `3 · bsPubL + 7`. -/
theorem bsT_valSize_roundIn (Mc J R eA eXi : ℕ) {S : Val} {k : ℤ} (hk : bitLen k ≤ 1) :
    valSize (Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)], S, Val.int k]) ≤
      valSize S + 3 * bsPubL Mc J R eA eXi + 7 := by
  have h := bsV_params_size Mc J R eA eXi
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int] at h ⊢
  omega

/-- **Round input, per record**, for the B state of `A` (the parameters of `A = adaParams eA eXi Mc J R`). -/
theorem bsT_valSize_roundIn_state (hbs : A.blockSizes.length = A.p + 1) {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = A.N) (hc : ∀ x ∈ codes, x < 2 ^ bU) (hok : AdaOK A st)
    (Mc J R eA eXi : ℕ) {k : ℤ} (hk : bitLen k ≤ 1) :
    valSize (Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      Val.list [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaEnc st], Val.int k]) ≤
      A.N * (bU + A.qA + Nat.size A.fuel + 6) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 8) +
        Nat.size (maxKs A) + 3 * Nat.size (A.M + A.J + A.R + 2) + 3 * bsPubL Mc J R eA eXi + 37 := by
  have h1 := bsT_valSize_roundIn Mc J R eA eXi
    (S := Val.list [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaEnc st]) hk
  have h2 := bsT_valSize_state hbs hlen hc hok
  omega

/-- **Round output** `[state', resp]`: the new state bound plus the response plus `3`. -/
theorem bsT_valSize_roundOut (S resp : Val) :
    valSize (Val.list [S, resp]) = valSize S + valSize resp + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

end round

/-! ## The parameter record -/

/-- **The parameter record** (`p + 1` block sizes `≤ N`, `p` caps `≤ fuel`, and `O(adaZ A)` scalars):
`valSize (adaPubEnc A) ≤ (p + 1)(size N + 2) + p (sF + 2) + 32 (adaZ A + 16)`. -/
theorem bsT_valSize_adaPubEnc (A : AdaParams) (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) :
    valSize (adaPubEnc A) ≤ (A.p + 1) * (Nat.size A.N + 2) + A.p * (Nat.size A.fuel + 2) +
      32 * (adaZ A + 16) := by
  have hZ16 := sixteen_le_adaZ A
  have hbsV : valSize (encL encN A.blockSizes) ≤ 1 + (A.p + 1) * (Nat.size A.N + 2) := by
    have := valSize_encL_le encN A.blockSizes (Nat.size A.N + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.N := List.le_sum_of_mem hx
      have := Nat.size_le_size hx'
      omega)
    rw [hbs] at this
    exact this
  have hTV : valSize (encL encN A.Tmax) ≤ 1 + A.p * (Nat.size A.fuel + 2) := by
    have := valSize_encL_le encN A.Tmax (Nat.size A.fuel + 1) (fun x hx => by
      rw [valSize_encN]
      have hx' : x ≤ A.fuel := by
        have := List.le_sum_of_mem hx
        unfold AdaParams.fuel
        omega
      have := Nat.size_le_size hx'
      omega)
    rw [hT] at this
    exact this
  have hsampV : valSize (Val.list (noiseKinds.map fun κ => encL encN (samplerParams A κ))) ≤
      5 * (adaZ A + 20) + 1 := by
    have hκ : ∀ κ, valSize (encL encN (samplerParams A κ)) ≤ adaZ A + 16 := by
      intro κ
      have h := sampTerm_le_adaZ A κ
      unfold sampTerm at h
      have h1 := size_le_self (A.rs (A.scale κ))
      have h2 := size_le_self (Nat.clog 2 (A.rho (A.scale κ)).den)
      simp only [samplerParams, valSize_encL, List.map_cons, List.map_nil, List.sum_cons,
        List.sum_nil, valSize_encN]
      omega
    have h0 := hκ NoiseKind.intThr
    have h1 := hκ NoiseKind.intTest
    have h2 := hκ NoiseKind.outThr
    have h3 := hκ NoiseKind.outTest
    have h4 := hκ NoiseKind.num
    simp only [noiseKinds, List.map_cons, List.map_nil, valSize_list, listSize_cons,
      listSize_nil]
    omega
  have hq1 := valSize_encQ A.tau
  have hq2 := valSize_encQ (A.a / 2)
  have hq3 := valSize_encQ (scoreScale A)
  have := size_tauden_le_adaZ A
  have := size_taunum_le_adaZ A
  have := size_a2den_le_adaZ A
  have := size_a2num_le_adaZ A
  have := size_cden_le_adaZ A
  have := size_cnum_le_adaZ A
  have hp := p_le_adaZ A
  have hqA := qA_le_adaZ A
  have hfuel := size_fuel_le_adaZ A
  have hMJR := size_MJR_le_adaZ A
  have hpsz := size_le_self A.p
  have hqsz := size_le_self A.qA
  have hM' : Nat.size A.M ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hJ' : Nat.size A.J ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have hR' : Nat.size A.R ≤ adaZ A := (Nat.size_le_size (by omega)).trans hMJR
  have h2q : Nat.size (2 ^ A.qA) = A.qA + 1 := Nat.size_pow
  simp only [valSize_list] at hsampV
  rw [adaPubEnc_eq]
  simp only [pubFields, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  linarith

/-- The parameter record `≤ 34 (p + 1)(adaZ A + 16)`, independent of `N` except through the block sizes. -/
theorem bsT_valSize_adaPubEnc' (A : AdaParams) (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) :
    valSize (adaPubEnc A) ≤ 34 * (A.p + 1) * (adaZ A + 16) := by
  have h := bsT_valSize_adaPubEnc A hbs hT
  have hN := size_N_le_adaZ A
  have hF := size_fuel_le_adaZ A
  have h1 : (A.p + 1) * (Nat.size A.N + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
    Nat.mul_le_mul_left _ (by omega)
  have h2 : A.p * (Nat.size A.fuel + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h3 : 32 * (adaZ A + 16) ≤ 32 * ((A.p + 1) * (adaZ A + 16)) :=
    Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))
  have e : 34 * (A.p + 1) * (adaZ A + 16) = 34 * ((A.p + 1) * (adaZ A + 16)) := by ring
  omega

/-! ## In terms of `χ` (the actual parameters) -/

section chi

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- `q_A ≤ 32 χ` (B-NUM's `alg2HAExp_le`, via B-ARCH's `adaQA_eq`). -/
theorem bsT_qA_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA ≤
      32 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  show adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤ _
  rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1]
  exact alg2HAExp_le M J R aReq ξReq

/-- `sF = size fuel ≤ χ + 1`. -/
theorem bsT_sF_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    Nat.size (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).fuel ≤
      F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 1 := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
  exact BoundAux.size_le_of_le (BoundAux.fuel_le M J R _ _)

/-- `sC = size (M + J + R + 2) ≤ χ + 1`. -/
theorem bsT_sC_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    Nat.size ((adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).M +
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).J +
      (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).R + 2) ≤
      F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 1 := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
  exact BoundAux.size_le_of_le (BoundAux.caps_le M J R _ _)

/-- `sK = size (maxKs A) ≤ 35 χ + 3`. -/
theorem bsT_sK_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    Nat.size (maxKs (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)) ≤
      35 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 3 := by
  have h1 := BoundAux.size_le_of_le (BoundAux.maxKs_le M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq))
  have h2 := bsT_qA_le_chi M J R ha0 ha1 hξ0 hξ1
  have h3 := bs_chi_eq M J R ha0 ha1 hξ0 hξ1
  have h4 : (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA =
      adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) := rfl
  rw [← h3] at h1
  omega

/-- **The S3 link**: `q_A + sF + 59 ≤ 34 χ` (with `60 < χ`). -/
theorem bsT_qA_sF_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA +
        Nat.size (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).fuel + 59 ≤
      34 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  have h1 := bsT_qA_le_chi M J R ha0 ha1 hξ0 hξ1
  have h2 := bsT_sF_le_chi M J R ha0 ha1 hξ0 hξ1
  have h3 := bs_sixty_lt_chi M J R aReq ξReq
  omega

/-- **The encoded ADA state in terms of `χ`**: `valSize (adaEnc st) ≤ N (72 χ + 17)` for every state satisfying
the invariant (`N = A.N = (alg2Params M J R aReq ξReq).N`). -/
theorem bsT_valSize_adaEnc_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {st : AdaState}
    (hok : AdaOK (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) st) :
    valSize (adaEnc st) ≤ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N *
      (72 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 17) := by
  set A := adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R with hA
  set χ := F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) with hχ
  have h0 := bsT_valSize_adaEnc hok
  have hq := bsT_qA_le_chi M J R ha0 ha1 hξ0 hξ1
  have hF := bsT_sF_le_chi M J R ha0 ha1 hξ0 hξ1
  have hK := bsT_sK_le_chi M J R ha0 ha1 hξ0 hξ1
  have hC := bsT_sC_le_chi M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  have hpN := BoundAux.p_add_le_N M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq)
  rw [← hA, ← hχ] at hq hF hK hC
  rw [← hχ] at h60
  rw [← hA] at hpN
  -- the three summands, each `≤ N · (…)`
  have e1 : A.N * (A.qA + Nat.size A.fuel + 4) ≤ A.N * (33 * χ + 5) :=
    Nat.mul_le_mul_left _ (by omega)
  have e2 : A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) ≤ A.N * (36 * χ + 10) :=
    Nat.mul_le_mul (by omega) (by omega)
  have e3 : Nat.size (maxKs A) + 3 * Nat.size (A.M + A.J + A.R + 2) + 24 ≤ A.N * (3 * χ + 2) := by
    have : 16 * (3 * χ + 2) ≤ A.N * (3 * χ + 2) := Nat.mul_le_mul_right _ (by omega)
    omega
  have e4 : A.N * (33 * χ + 5) + A.N * (36 * χ + 10) + A.N * (3 * χ + 2) = A.N * (72 * χ + 17) := by
    ring
  omega

end chi

end F2e2e.BSpace
