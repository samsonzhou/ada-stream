import F2e2e.C.Impl.BankArith
import F2e2e.B.ArchBridge
import F2e2e.BSpace.MachineEvalsO
import F2e2e.Spec

/-!
# B_space, D3: interval endpoints through the evaluation oracle, and `normQ` for the B program

Owner: W5 (c1b4f720). Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §D (D3). Keys 920–929.

* `bsNormQTable`, `normQSpec_of_table`: W5's `normQ` (index `766`, Euclid's loop at `767`) as a table
  the B program can include, and C-TOP's `NormQSpec` for every program containing it.
* The endpoint arithmetic: for `n = ⌊2^{qA+1} clip_{[−1,2]}(l)⌋` (the oracle's answer `orc 1 0 (qA+1)`),
  the grid index `kl = (n + 1) div 2` is B-ARCH's `endIdx P l` (`bsN_endIdx_eq`), so the rational
  endpoint `kl / 2^{qA}` is `quantReq`'s `P.hA * endIdx P l` (`bsN_quant_eq`), with the bit bounds
  needed by W4's `adaInterval_impl` (`bsN_end_bitLen`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/-! ## The routine `bsEnds` (key 920) -/

/-- The key of `bsEnds`. -/
abbrev bsN_endsKey : ℕ := 920

open F2e2e.Cost.HashDSL in
/-- `bsEnds : [qA] ↦ [encQ l', encQ u']`: `kl = (orc 1 0 (qA+1) + 1) div 2`, `ku = (orc 2 0 (qA+1) + 1) div 2`,
`l' = kl / 2^{qA}`, `u' = ku / 2^{qA}` (canonical through `normQ`). -/
def body_bsEnds : Expr :=
  eLet (eHd (eV 0)) <|                                                     -- q    [q, I]
  eLet (eCall Cost.Idx.pow2 (eV 0)) <|                                     -- p    [p, q, I]
  eLet (eAdd (eV 1) (eLit 1)) <|                                           -- q1   [q1, p, q, I]
  eLet (eDiv (eAdd (eCall bsOracleIdx (eList [eLit 1, eLit 0, eV 0])) (eLit 1)) (eLit 2)) <|
                                                                           -- kl   [kl, q1, p, q, I]
  eLet (eDiv (eAdd (eCall bsOracleIdx (eList [eLit 2, eLit 0, eV 1])) (eLit 1)) (eLit 2)) <|
                                                                           -- ku   [ku, kl, q1, p, q, I]
  eList [eCall C.Impl.Idx.normQ (ePair (eV 1) (eV 3)), eCall C.Impl.Idx.normQ (ePair (eV 0) (eV 3))]

/-- `bsEnds` and the library routines it calls (besides `normQ`, see `bsNormQTable`). -/
def bsEndsTable : List (ℕ × Expr) :=
  [(bsN_endsKey, body_bsEnds), (Cost.Idx.pow2, Cost.body_pow2), (Cost.Idx.pow2Step, Cost.body_pow2Step)]

/-- The endpoint computed by `bsEnds` from the oracle's answer `n`. -/
def bsN_end (qA : ℕ) (n : ℤ) : ℚ := (((n + 1) / 2 : ℤ) : ℚ) / 2 ^ qA

/-! ## `normQ` as a table -/

/-- W5's `normQ` and its Euclid loop body. -/
def bsNormQTable : List (ℕ × Expr) :=
  [(C.Impl.Idx.normQ, BankDSL.body_normQ), (C.Impl.Idx.bkGcdStep, BankDSL.body_bkGcdStep)]

/-- C-TOP's `NormQSpec` for every program containing `bsNormQTable`. -/
theorem normQSpec_of_table {prog : List Expr} {M : ℕ}
    (h : ∀ e ∈ bsNormQTable, prog[e.1]? = some e.2) : NormQSpec prog M :=
  ⟨BankDSL.body_normQ, h _ List.mem_cons_self,
    fun a b hb hM => BankDSL.normQ_val (h _ (List.mem_cons_of_mem _ List.mem_cons_self)) a b hb hM⟩

/-! ## The endpoint arithmetic -/

theorem bsN_div_num_abs_le (a b : ℤ) (hb : 0 < b) : |((a : ℚ) / (b : ℚ)).num| ≤ |a| := by
  rw [← Rat.divInt_eq_div]
  by_cases ha : a = 0
  · subst ha
    simp
  · have hd := Rat.num_dvd a (ne_of_gt hb)
    have := Int.natAbs_le_of_dvd_ne_zero hd ha
    rw [Int.abs_eq_natAbs, Int.abs_eq_natAbs]
    exact_mod_cast this

theorem bsN_div_den_le (a b : ℤ) (hb : 0 < b) : (((a : ℚ) / (b : ℚ)).den : ℤ) ≤ b := by
  rw [← Rat.divInt_eq_div]
  exact Int.le_of_dvd hb (Rat.den_dvd a b)

/-- `⌊z/h_A + 1/2⌋ = (⌊2^{q+1} z⌋ + 1) div 2` for `h_A = 2^{-q}` (the truncation oracle at precision
`q + 1` gives Spec v2's rounding to `h_A`, ties toward `+∞`). -/
theorem bsN_roundIdx_eq_trunc (q : ℕ) (z : ℝ) :
    roundIdx (((1 / 2 : ℚ) ^ q : ℚ) : ℝ) z = (⌊(2 : ℝ) ^ (q + 1) * z⌋ + 1) / 2 := by
  unfold roundIdx
  have h2 : (((1 / 2 : ℚ) ^ q : ℚ) : ℝ) = ((2 : ℝ) ^ q)⁻¹ := by
    push_cast
    rw [one_div, inv_pow]
  have h1 : z * (2 : ℝ) ^ q + 1 / 2 = ((2 : ℝ) ^ (q + 1) * z + 1) / ((2 : ℕ) : ℝ) := by
    push_cast
    rw [pow_succ]
    ring
  rw [h2, div_inv_eq_mul, h1, Int.floor_div_natCast, Int.floor_add_one]
  norm_num

/-- **The endpoint grid index.** If `n = ⌊2^{qA+1} clip_{[−1,2]}(l)⌋` (the oracle's answer), then
`(n + 1) div 2` is B-ARCH's `endIdx P l`. -/
theorem bsN_endIdx_eq (P : AdaParams) (l : ℝ) (n : ℤ)
    (hn : n = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 l)⌋) :
    (n + 1) / 2 = endIdx P l := by
  rw [hn]
  unfold endIdx
  rw [AdaParams.hA, bsN_roundIdx_eq_trunc]

/-- **The quantized endpoint.** With `n = ⌊2^{qA+1} clip_{[−1,2]}(l)⌋`, the rational
`((n + 1) div 2) / 2^{qA}` is `quantReq`'s endpoint `P.hA * endIdx P l`. -/
theorem bsN_quant_eq (P : AdaParams) (l : ℝ) (n : ℤ)
    (hn : n = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 l)⌋) :
    ((((n + 1) / 2 : ℤ) : ℚ) / 2 ^ P.qA) = P.hA * (endIdx P l : ℚ) := by
  rw [bsN_endIdx_eq P l n hn, AdaParams.hA, div_eq_mul_inv, mul_comm, one_div, inv_pow]

/-- The oracle's endpoint answer is in `[−2^{q}, 2^{q+1}]` (the clipped endpoint is in `[−1, 2]`). -/
theorem bsN_trunc_bounds (q : ℕ) (l : ℝ) :
    -(2 : ℤ) ^ q ≤ ⌊(2 : ℝ) ^ q * max (-1) (min 2 l)⌋ ∧
      ⌊(2 : ℝ) ^ q * max (-1) (min 2 l)⌋ ≤ 2 ^ (q + 1) := by
  have hpos : (0 : ℝ) < (2 : ℝ) ^ q := by positivity
  have hc1 : (-1 : ℝ) ≤ max (-1) (min 2 l) := le_max_left _ _
  have hc2 : max (-1) (min 2 l) ≤ (2 : ℝ) := max_le (by norm_num) (min_le_left _ _)
  constructor
  · rw [Int.le_floor]
    push_cast
    nlinarith
  · rw [Int.floor_le_iff]
    push_cast
    rw [pow_succ]
    nlinarith

/-- **Bit bounds of the endpoint** (W4's `adaInterval_impl` endpoint hypothesis, `Bq = qA + 4`): for
`|n| ≤ 2^{q+2}`, the rational `((n + 1) div 2) / 2^q` has numerator and denominator of at most `q + 4`
bits. -/
theorem bsN_end_bitLen (q : ℕ) (n : ℤ) (hn : |n| ≤ 2 ^ (q + 2)) :
    bitLen ((((n + 1) / 2 : ℤ) : ℚ) / 2 ^ q).num ≤ q + 4 ∧
      bitLen (((((n + 1) / 2 : ℤ) : ℚ) / 2 ^ q).den : ℤ) ≤ q + 4 := by
  set k : ℤ := (n + 1) / 2 with hk
  have hk1 : |k| ≤ 2 ^ (q + 2) := by
    have h1 := abs_le.mp hn
    have h2 : (2 : ℤ) ^ (q + 2) = 2 * 2 ^ (q + 1) := by rw [pow_succ]; ring
    rw [abs_le]
    constructor <;> omega
  have hq : (0 : ℤ) < 2 ^ q := by positivity
  have hcast : ((k : ℚ) / 2 ^ q) = ((k : ℤ) : ℚ) / (((2 : ℤ) ^ q : ℤ) : ℚ) := by push_cast; ring
  rw [hcast]
  constructor
  · have h := bsN_div_num_abs_le k (2 ^ q) hq
    apply bitLen_le_of_abs_lt
    have : (2 : ℤ) ^ (q + 2) < 2 ^ (q + 4) := pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith
  · have h := bsN_div_den_le k (2 ^ q) hq
    have hd : (0 : ℤ) ≤ ((((k : ℤ) : ℚ) / (((2 : ℤ) ^ q : ℤ) : ℚ)).den : ℤ) := by positivity
    apply bitLen_le_of_abs_lt
    rw [abs_of_nonneg hd]
    have : (2 : ℤ) ^ q < 2 ^ (q + 4) := pow_lt_pow_right₀ (by norm_num) (by omega)
    linarith

/-! ## Deterministic rules for `EvalsValO` -/

section rulesO

open F2e2e.Cost.HashDSL

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}

theorem bsN_var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsValO orc prog M env [] (.inl (eV i)) v :=
  EvalsValO.var h

theorem bsN_lit {z : ℤ} (hM : valSize (Val.int z) ≤ M) :
    EvalsValO orc prog M env [] (.inl (eLit z)) (Val.int z) :=
  EvalsValO.lit hM

theorem bsN_let {a b : Expr} {va vb : Val} (ha : EvalsValO orc prog M env [] (.inl a) va)
    (hb : EvalsValO orc prog M (va :: env) [] (.inl b) vb) :
    EvalsValO orc prog M env [] (.inl (eLet a b)) vb :=
  EvalsValO.letE ha hb

theorem bsN_call {i : ℕ} {a body : Expr} {va vb : Val} (hi : i ≠ bsOracleIdx)
    (hbody : prog[i]? = some body) (ha : EvalsValO orc prog M env [] (.inl a) va)
    (hb : EvalsValO orc prog M [va] [] (.inl body) vb) :
    EvalsValO orc prog M env [] (.inl (eCall i a)) vb :=
  EvalsValO.call hi ha hbody hb

theorem bsN_hd {a : Expr} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env [] (.inl a) (Val.list (x :: l)))
    (hM : valSize (Val.list (x :: l)) ≤ M) : EvalsValO orc prog M env [] (.inl (eHd a)) x :=
  EvalsValO.head ha ((BankDSL.valSize_head_le' x l).trans hM)

theorem bsN_add {a b : Expr} {x y : ℤ} (ha : EvalsValO orc prog M env [] (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env [] (.inl b) (Val.int y)) (hM : valSize (Val.int (x + y)) ≤ M) :
    EvalsValO orc prog M env [] (.inl (eAdd a b)) (Val.int (x + y)) :=
  EvalsValO.bin ha hb rfl hM

theorem bsN_div {a b : Expr} {x y : ℤ} (ha : EvalsValO orc prog M env [] (.inl a) (Val.int x))
    (hb : EvalsValO orc prog M env [] (.inl b) (Val.int y)) (hy : y ≠ 0)
    (hM : valSize (Val.int (x / y)) ≤ M) :
    EvalsValO orc prog M env [] (.inl (eDiv a b)) (Val.int (x / y)) :=
  EvalsValO.bin (c := 1 + (bitLen x + 1) * (bitLen y + 1)) ha hb (by simp [evalBin, hy]) hM

theorem bsN_cons {a b : Expr} {x : Val} {l : List Val}
    (ha : EvalsValO orc prog M env [] (.inl a) x)
    (hb : EvalsValO orc prog M env [] (.inl b) (Val.list l))
    (hM : valSize (Val.list (x :: l)) ≤ M) :
    EvalsValO orc prog M env [] (.inl (eCons a b)) (Val.list (x :: l)) :=
  EvalsValO.cons ha hb hM

theorem bsN_list :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsValO orc prog M env [] (.inl e) v) es vs →
        valSize (Val.list vs) ≤ M → EvalsValO orc prog M env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsValO.nil hM
  | _ :: _, v :: vs, List.Forall₂.cons he hrest, hM =>
    bsN_cons he (bsN_list hrest ((BankDSL.valSize_tail_le' v vs).trans hM)) hM

theorem bsN_pair {a b : Expr} {x y : Val} (ha : EvalsValO orc prog M env [] (.inl a) x)
    (hb : EvalsValO orc prog M env [] (.inl b) y) (hM : valSize (Val.list [x, y]) ≤ M) :
    EvalsValO orc prog M env [] (.inl (ePair a b)) (Val.list [x, y]) :=
  EvalsValO.pair ha hb hM

end rulesO

/-! ## The specification of `bsEnds` -/

theorem bsN_end_eq (qA : ℕ) (n : ℤ) :
    bsN_end qA n = ((((n + 1) / 2 : ℤ)) : ℚ) / ((((2 ^ qA : ℕ) : ℤ)) : ℚ) := by
  simp [bsN_end]

/-- The bit bounds of `bsEnds`'s endpoint (W4's `adaInterval_impl` hypothesis with `Bq = qA + 4`). -/
theorem bsN_end_bitLen' (qA : ℕ) (n : ℤ) (hn : |n| ≤ 2 ^ (qA + 2)) :
    bitLen (bsN_end qA n).num ≤ qA + 4 ∧ bitLen ((bsN_end qA n).den : ℤ) ≤ qA + 4 :=
  bsN_end_bitLen qA n hn

/-- The oracle's endpoint answer at precision `qA + 1` satisfies `bsEnds_eval`'s range hypothesis. -/
theorem bsN_trunc_abs_le (qA : ℕ) (x : ℝ) :
    |⌊(2 : ℝ) ^ (qA + 1) * max (-1) (min 2 x)⌋| ≤ 2 ^ (qA + 2) := by
  obtain ⟨h1, h2⟩ := bsN_trunc_bounds (qA + 1) x
  have h3 : (2 : ℤ) ^ (qA + 1) ≤ 2 ^ (qA + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
  rw [abs_le]
  constructor <;> omega

theorem bsN_valSize_encQ_end (qA : ℕ) (n : ℤ) (hn : |n| ≤ 2 ^ (qA + 2)) :
    valSize (encQ (bsN_end qA n)) ≤ 2 * qA + 13 := by
  obtain ⟨h1, h2⟩ := bsN_end_bitLen qA n hn
  simp only [encQ, valSize_list, valSize_int, listSize_cons, listSize_nil]
  unfold bsN_end at *
  omega

/-- **`bsEnds`** (key 920) with the evaluation oracle `orc`: on `[qA]` it returns the two endpoints
`bsN_end qA (orc 1 0 (qA+1))`, `bsN_end qA (orc 2 0 (qA+1))` (canonical `encQ`). -/
theorem bsEnds_eval (orc : ℤ → ℤ → ℤ → ℤ) {prog : List Expr} {M : ℕ} (qA : ℕ)
    (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hnone : prog[bsOracleIdx]? = none)
    (hO : |orc 1 0 (qA + 1)| ≤ 2 ^ (qA + 2) ∧ |orc 2 0 (qA + 1)| ≤ 2 ^ (qA + 2))
    (hM : 20 * qA + 200 ≤ M) :
    EvalsValO orc prog M [Val.list [encN qA]] [] (.inl body_bsEnds)
      (Val.list [encQ (bsN_end qA (orc 1 0 (qA + 1))), encQ (bsN_end qA (orc 2 0 (qA + 1)))]) := by
  have hpow : prog[Cost.Idx.pow2]? = some Cost.body_pow2 :=
    hlib _ (List.mem_cons_of_mem _ List.mem_cons_self)
  have hpowS : prog[Cost.Idx.pow2Step]? = some Cost.body_pow2Step :=
    hlib _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))
  obtain ⟨bq, hbq, hqspec⟩ := hq
  obtain ⟨hOl, hOu⟩ := hO
  -- sizes
  have hqb : bitLen (qA : ℤ) ≤ qA := bitLen_natCast_le qA
  have hq1b : bitLen ((qA : ℤ) + 1) ≤ qA + 1 := by
    have := bitLen_natCast_le (qA + 1); push_cast at this; exact this
  have hpb : bitLen (((2 ^ qA : ℕ) : ℤ)) = qA + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hsq : Nat.size qA ≤ qA := size_le_self qA
  have hnb : ∀ n : ℤ, |n| ≤ 2 ^ (qA + 2) →
      bitLen n ≤ qA + 3 ∧ bitLen (n + 1) ≤ qA + 4 ∧ bitLen ((n + 1) / 2) ≤ qA + 4 := by
    intro n hn
    have h3 : (2 : ℤ) ^ (qA + 2) < 2 ^ (qA + 3) := pow_lt_pow_right₀ (by norm_num) (by omega)
    have h4 : (2 : ℤ) ^ (qA + 3) < 2 ^ (qA + 4) := pow_lt_pow_right₀ (by norm_num) (by omega)
    have e1 : bitLen n ≤ qA + 3 := bitLen_le_of_abs_lt (by linarith)
    have e2 : bitLen (n + 1) ≤ qA + 4 := by
      apply bitLen_le_of_abs_lt
      have := abs_add_le n 1
      simp only [abs_one] at this
      linarith
    exact ⟨e1, e2, (bitLen_ediv_le _ _).trans e2⟩
  obtain ⟨hl1, hl2, hl3⟩ := hnb _ hOl
  obtain ⟨hu1, hu2, hu3⟩ := hnb _ hOu
  have hEl := bsN_valSize_encQ_end qA _ hOl
  have hEu := bsN_valSize_encQ_end qA _ hOu
  have hI : valSize (Val.list [encN qA]) ≤ M := by
    simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega
  have hpowM : Cost.S_pow2 qA ≤ M := by simp only [Cost.S_pow2]; omega
  have hne100 : Cost.Idx.pow2 ≠ bsOracleIdx := by decide
  have hne766 : C.Impl.Idx.normQ ≠ bsOracleIdx := by decide
  have h2pos : (0 : ℤ) < ((2 ^ qA : ℕ) : ℤ) := by positivity
  rw [bsN_end_eq, bsN_end_eq]
  unfold body_bsEnds
  refine bsN_let (bsN_hd (bsN_var rfl) hI) ?_
  refine bsN_let (bsN_call hne100 hpow (bsN_var rfl)
    (EvalsValO.of_evalsVal hnone ((Cost.pow2_spec hpowS qA 0).toVal.mono_M hpowM))) ?_
  refine bsN_let (bsN_add (bsN_var rfl) (bsN_lit (by simp; omega))
    (by simp only [valSize_int]; omega)) ?_
  refine bsN_let (bsN_div (bsN_add (EvalsValO.oracle_det (bsN_list (.cons (bsN_lit (by simp; omega))
    (.cons (bsN_lit (by simp; omega)) (.cons (bsN_var rfl) .nil)))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_one, bitLen_zero]
        omega)) (by simp only [valSize_int]; omega)) (bsN_lit (by simp; omega))
    (by simp only [valSize_int]; omega)) (bsN_lit (by simp [bitLen_two_eq]; omega)) two_ne_zero
    (by simp only [valSize_int]; omega)) ?_
  refine bsN_let (bsN_div (bsN_add (EvalsValO.oracle_det (bsN_list (.cons (bsN_lit (by
      simp [bitLen_two_eq]; omega))
    (.cons (bsN_lit (by simp; omega)) (.cons (bsN_var rfl) .nil)))
    (by simp only [valSize_list, valSize_int, listSize_cons, listSize_nil, bitLen_two_eq,
          bitLen_zero]
        omega)) (by simp only [valSize_int]; omega)) (bsN_lit (by simp; omega))
    (by simp only [valSize_int]; omega)) (bsN_lit (by simp [bitLen_two_eq]; omega)) two_ne_zero
    (by simp only [valSize_int]; omega)) ?_
  refine bsN_list (.cons (bsN_call hne766 hbq (bsN_pair (bsN_var rfl) (bsN_var rfl)
      (by simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
      (EvalsValO.of_evalsVal hnone (hqspec _ _ h2pos (by omega))))
    (.cons (bsN_call hne766 hbq (bsN_pair (bsN_var rfl) (bsN_var rfl)
      (by simp only [encN, valSize_list, valSize_int, listSize_cons, listSize_nil]; omega))
      (EvalsValO.of_evalsVal hnone (hqspec _ _ h2pos (by omega)))) .nil)) ?_
  rw [← bsN_end_eq, ← bsN_end_eq]
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

/-- **`bsEnds` on a request's oracle**: if the oracle answers the clipped endpoints of `r` truncated to
`qA + 1` digits (as Spec v3's `reqOracle` does), `bsEnds` returns `quantReq`'s endpoints. -/
theorem bsEnds_eval_quant (orc : ℤ → ℤ → ℤ → ℤ) {prog : List Expr} {M : ℕ} (P : AdaParams)
    {U : Type} (r : (U → ℝ) × Bool × ℝ × ℝ)
    (hl : orc 1 0 (P.qA + 1) = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 r.2.2.1)⌋)
    (hu : orc 2 0 (P.qA + 1) = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 r.2.2.2)⌋)
    (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hnone : prog[bsOracleIdx]? = none) (hM : 20 * P.qA + 200 ≤ M) :
    EvalsValO orc prog M [Val.list [encN P.qA]] [] (.inl body_bsEnds)
      (Val.list [encQ (quantReq P r).l, encQ (quantReq P r).u]) := by
  have hb : ∀ n : ℤ, ∀ x : ℝ, n = ⌊(2 : ℝ) ^ (P.qA + 1) * max (-1) (min 2 x)⌋ →
      |n| ≤ 2 ^ (P.qA + 2) := by
    intro n x hn
    obtain ⟨h1, h2⟩ := bsN_trunc_bounds (P.qA + 1) x
    rw [← hn] at h1 h2
    have h3 : (2 : ℤ) ^ (P.qA + 1) ≤ 2 ^ (P.qA + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    rw [abs_le]
    constructor <;> omega
  have h := bsEnds_eval orc P.qA hlib hq hnone ⟨hb _ _ hl, hb _ _ hu⟩ hM
  have el : bsN_end P.qA (orc 1 0 (P.qA + 1)) = (quantReq P r).l := by
    unfold bsN_end
    exact bsN_quant_eq P r.2.2.1 _ hl
  have eu : bsN_end P.qA (orc 2 0 (P.qA + 1)) = (quantReq P r).u := by
    unfold bsN_end
    exact bsN_quant_eq P r.2.2.2 _ hu
  rw [el, eu] at h
  exact h

/-- **`bsEnds` with a request's oracle** (Spec v3 §7's `reqOracle`): it returns `quantReq`'s endpoints
`P.hA * endIdx P l`, `P.hA * endIdx P u` for `qA = P.qA`. -/
theorem bsEnds_eval_req {prog : List Expr} {M : ℕ} (P : AdaParams) {U : Type} (code : U → ℕ)
    (req : VReq U) (hlib : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hnone : prog[bsOracleIdx]? = none) (hM : 20 * P.qA + 200 ≤ M) :
    EvalsValO (reqOracle code req) prog M [Val.list [encN P.qA]] [] (.inl body_bsEnds)
      (Val.list [encQ (quantReq P req).l, encQ (quantReq P req).u]) := by
  have ht : ((P.qA : ℤ) + 1).toNat = P.qA + 1 := by omega
  have h10 : (1 : ℤ) ≠ 0 := by norm_num
  have h20 : (2 : ℤ) ≠ 0 := by norm_num
  have h21 : (2 : ℤ) ≠ 1 := by norm_num
  refine bsEnds_eval_quant (reqOracle code req) P req ?_ ?_ hlib hq hnone hM
  · show (if (1 : ℤ) = 0 then _ else if (1 : ℤ) = 1 then truncIdx ((P.qA : ℤ) + 1).toNat
        (max (-1) (min 2 req.2.2.1)) else _) = _
    rw [if_neg h10, if_pos rfl, ht]
    rfl
  · show (if (2 : ℤ) = 0 then _ else if (2 : ℤ) = 1 then _ else if (2 : ℤ) = 2 then
        truncIdx ((P.qA : ℤ) + 1).toNat (max (-1) (min 2 req.2.2.2)) else _) = _
    rw [if_neg h20, if_neg h21, if_pos rfl, ht]
    rfl

end F2e2e.BSpace
