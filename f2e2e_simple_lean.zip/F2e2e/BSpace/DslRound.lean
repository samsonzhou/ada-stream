import F2e2e.BSpace.DslMain
import F2e2e.BSpace.DslEvals

/-!
# B_space, layer D4 (W2): the round program's spec (generic oracle)

Owner: W2 (a2ff64c3). `bsRound_impl_gen`: for every oracle `orc` whose answers lie in the ranges of D2
(`0 ≤ orc 0 r (qA+1) ≤ 2^(qA+1)` on the stored codes) and D3 (`|orc i 0 (qA+1)| ≤ 2^(qA+2)`, `i = 1, 2`),
`body_bsRound` implements the core request `bsCoreRound A st (evalsOf orc A.qA blocks) l' u' kind` with the
endpoints `l' = bsN_end A.qA (orc 1 0 (A.qA+1))`, `u' = bsN_end A.qA (orc 2 0 (A.qA+1))` of D3, the state
encoding `bsStateEnc blocks` and the response encoding `bsResp`.

Proof: the parameter record (`bsPub_eval`, lifted), the predictions through the oracle (1beb339b's
`bsEvals_eval`), then `bsRound_tail` (`F2e2e/BSpace/DslMain.lean`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

set_option maxHeartbeats 1000000 in
/-- **Spec of `body_bsRound`** (generic oracle). -/
theorem bsRound_impl_gen {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hEv : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2)
    {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) {blocks : List (List ℕ)}
    (hblk : blocks.map List.length = (adaParams eA eXi Mc J R).blockSizes)
    {st : AdaState} (hok : AdaOK (adaParams eA eXi Mc J R) st) (kind : Bool)
    (horc0 : ∀ blk ∈ blocks, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((adaParams eA eXi Mc J R).qA + 1) ∧
        orc 0 (r : ℤ) ((adaParams eA eXi Mc J R).qA + 1) ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 1))
    (horc12 : |orc 1 0 ((adaParams eA eXi Mc J R).qA + 1)| ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 2) ∧
      |orc 2 0 ((adaParams eA eXi Mc J R).qA + 1)| ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 2))
    (hMP : bsPubBound Mc J R eA eXi ≤ M)
    (hM : 2 ^ 32 * adaBoundA (adaParams eA eXi Mc J R) +
      2 * valSize (Val.list (blocks.map (encL encN))) ≤ M) :
    ImplementsO orc prog M [Val.list [encInts [Mc, J, R, eA, eXi], bsStateEnc blocks st, encB kind]]
      body_bsRound (fun r => Val.list [bsStateEnc blocks r.2, bsResp r.1])
      (bsCoreRound (adaParams eA eXi Mc J R) st (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)
        (bsN_end (adaParams eA eXi Mc J R).qA (orc 1 0 ((adaParams eA eXi Mc J R).qA + 1)))
        (bsN_end (adaParams eA eXi Mc J R).qA (orc 2 0 ((adaParams eA eXi Mc J R).qA + 1))) kind) := by
  have hbs := bsP_blockSizes_length eA eXi Mc J R
  have hT := bsP_Tmax_length eA eXi Mc J R
  have hpos := bsP_blockSizes_pos eA eXi Mc J R
  set A := adaParams eA eXi Mc J R with hA
  have h600 : prog[Idx.adaPub]? = some body_adaPub :=
    hW4.pubTbl (Idx.adaPub, body_adaPub) (by simp [adaPubTable])
  have h910 : prog[bsEvalsKey]? = some body_bsEvals := hEv _ List.mem_cons_self
  /- ### The predictions -/
  set vals := evalsOf orc A.qA blocks with hvals
  have hv : ValsOKA A vals :=
    ⟨by rw [hvals, evalsOf_map_length, hblk], evalsOf_le horc0⟩
  /- ### Sizes -/
  have hpubB := valSize_adaPubEnc_le A hbs hT
  have hstB := valSize_adaEnc_le hok
  have hvB := valSize_encVals_le hbs hv.1 hv.2
  have hZ16 := sixteen_le_adaZ A
  have hqZ := qA_le_adaZ A
  have hpZ := p_le_adaZ A
  have hB14 : 2 ^ 14 * (A.p + adaZ A + 16) ≤ adaBoundA A := by
    unfold adaBoundA
    have h1 : 16 * (A.p + adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) := by nlinarith
    calc 2 ^ 14 * (A.p + adaZ A + 16) = 2 ^ 10 * (16 * (A.p + adaZ A + 16)) := by ring
      _ ≤ 2 ^ 10 * ((A.N + A.p + 16) * (adaZ A + 16)) := Nat.mul_le_mul_left _ h1
      _ = 2 ^ 10 * (A.N + A.p + 16) * (adaZ A + 16) := by ring
  have hparS := bsM_params_size Mc J R eA eXi
  set L := bsPubL Mc J R eA eXi with hL
  have hL2 : L ≤ L * L := Nat.le_mul_self L
  have hMP' : 1048576 * (L * L) ≤ M := by
    have e : bsPubBound Mc J R eA eXi = 1048576 * (L * L) := by
      show 2 ^ 20 * L ^ 2 = _
      ring
    omega
  set blocksV := Val.list (blocks.map (encL encN)) with hblocksV
  have hencB : valSize (encB kind) ≤ 2 := valSize_encB_le kind
  have hinpM : valSize (Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      Val.list [blocksV, adaEnc st], encB kind]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil] at hencB ⊢
    omega
  set inp := Val.list [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
    Val.list [blocksV, adaEnc st], encB kind] with hinp
  have hstV : valSize (Val.list [blocksV, adaEnc st]) ≤ M :=
    le_trans (valSize_lt_of_mem (l := [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      Val.list [blocksV, adaEnc st], encB kind]) (by simp)).le hinpM
  /- ### The parameter record -/
  obtain ⟨hpubE, hpubM⟩ := bsPub_eval hpub hq h4 h2 hMP
  have hpE : EvalsVal prog M [inp] [] (.inl (eCall Idx.adaPub (eAtN 0 (eV 0)))) (adaPubEnc A) :=
    evalsVal_call_det h600 (evalsVal_atN' (EvalsVal.var rfl) hinpM rfl) hpubE
  rw [body_bsRound_eq]
  refine bsM_letE_detO (EvalsValO.of_evalsVal hO hpE) ?_
  /- ### The predictions through the oracle (D2) -/
  have hargs : EvalsVal prog M [adaPubEnc A, inp] []
      (.inl (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1))))) (Val.list [encN A.qA, blocksV]) := by
    refine EvalsVal.pair (evalsVal_atN' (l := pubFields A) (EvalsVal.var rfl) hpubM rfl)
      (evalsVal_atN' (evalsVal_atN' (EvalsVal.var rfl) hinpM rfl) hstV rfl) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    have := size_le_self A.qA
    omega
  have hEvM : valSize blocksV + valSize (encVals vals) + 2 * A.qA + 64 ≤ M := by omega
  have hevE : EvalsValO orc prog M [adaPubEnc A, inp] []
      (.inl (eCall bsEvalsKey (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1)))))) (encVals vals) :=
    evalsValO_call_det (by decide) h910 (EvalsValO.of_evalsVal hO hargs)
      (bsEvals_eval hEv horc0 hEvM)
  refine bsM_letE_detO hevE ?_
  /- ### The core request -/
  exact bsRound_tail hO hW4 hq hEn hbs hT hpos hok hv horc12 kind hinpM (by omega)

end F2e2e.BSpace
