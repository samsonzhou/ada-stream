import F2e2e.BSpace.DslRound
import F2e2e.BSpace.O2GstLiftCalc
import F2e2e.BSpace.O2TightSizes

/-!
# B_space, route O2b: the top frame of the round program, shared definitions (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802; pieces: 1beb339b (P1 prefix
`O2GlueMainPre.lean`, P2 numerical branch `O2GlueMainNum.lean`), C-BANK (P3 interval branch
`O2GlueMainIv.lean`, P4 top composition and the asm-level statement `O2GlueMain.lean`).

`body_bsRound` (W2's D4, `F2e2e/BSpace/DslBodies.lean`) holds the big B state in its own frame; route O2b
(per-call judgment `EvalsValF`, `F2e2e/BSpace/O2GstF.lean`) charges every callee at its OWN value bound and
budget `(m', τ')`. The pieces are stated for any frame `(m, τ)` with explicit premises `B_piece ≤ m`,
`T_piece ≤ τ`, where `T_piece` collects `(exprDepth body + 2) · m' + τ'` for each call; the callees enter as the
predicates below (table entry, argument `≤ m'`, the callee body's judgment at `(m', τ')`), discharged at the asm
level by the weighted liftings of the uniform specs (`o2m_pubAt_of_lift`, `o2m_endsAt_of_lift`, the tight
`_t` specs of the ADA families, O2B-GST's `F2e2e/BSpace/O2GstLift.lean`).

* `o2mInp`: the input `[params, bsStateEnc blocks st, encB kind]`;
* callee predicates `O2mPubAt` (600), `O2mEvalsAt` (910, D2), `O2mEndsAt` (920, D3), `O2mIvAt` (602),
  `O2mNumAt` (603);
* depths of the bodies (`o2m_depth_*`); `o2mStB A`: B-ACC's bound on `adaEnc st` for `AdaOK A st`; `o2MA A`:
  the threshold of `TightM` (the value bound of the ADA routines);
* liftings `o2m_pubAt_of_lift` (W2/W3's `bsPub_eval`) and `o2m_endsAt_of_lift` (W5's `bsEnds_eval`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The input -/

/-- **The input of `body_bsRound`**: the encoded parameters, the B state and the request kind. -/
def o2mInp (Mc J R eA eXi : ℕ) (blocks : List (List ℕ)) (st : AdaState) (kind : Bool) : Val :=
  Val.list [encInts [Mc, J, R, eA, eXi], bsStateEnc blocks st, encB kind]

/-! ## Callee predicates -/

/-- **`adaPub` (600) at its own per-call budget `(mP, τP)`**: on the encoded parameters it returns the
parameter record `adaPubEnc A` (`A = adaParams eA eXi Mc J R`). -/
def O2mPubAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mP τP Mc J R eA eXi : ℕ) : Prop :=
  prog[Idx.adaPub]? = some body_adaPub ∧ valSize (encInts [Mc, J, R, eA, eXi]) ≤ mP ∧
    EvalsValF orc prog mP τP [encInts [Mc, J, R, eA, eXi]] [] (.inl body_adaPub)
      (adaPubEnc (adaParams eA eXi Mc J R))

/-- **`bsEvals` (910, D2) at `(mE, τE)`**: on `[q, blocks]` it returns the query table
`encVals (evalsOf orc q blocks)` (1beb339b's `o2e_bsEvals_evalsF` at `(o2e_B, o2e_T)`). -/
def O2mEvalsAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mE τE q : ℕ) (blocks : List (List ℕ)) :
    Prop :=
  prog[bsEvalsKey]? = some body_bsEvals ∧
    valSize (Val.list [encN q, Val.list (blocks.map (encL encN))]) ≤ mE ∧
    EvalsValF orc prog mE τE [Val.list [encN q, Val.list (blocks.map (encL encN))]] [] (.inl body_bsEvals)
      (encVals (evalsOf orc q blocks))

/-- **`bsEnds` (920, D3) at `(mD, τD)`**: on `[q]` it returns the two endpoints read from the oracle. -/
def O2mEndsAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mD τD q : ℕ) : Prop :=
  prog[bsEndsKey]? = some body_bsEnds ∧ valSize (Val.list [encN q]) ≤ mD ∧
    EvalsValF orc prog mD τD [Val.list [encN q]] [] (.inl body_bsEnds)
      (Val.list [encQ (bsN_end q (orc 1 0 ((q : ℤ) + 1))), encQ (bsN_end q (orc 2 0 ((q : ℤ) + 1)))])

/-- **`adaInterval` (602) at `(mI, τI)`**: the interval entry implements `adaInterval A st vals l u`. -/
def O2mIvAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mI τI : ℕ) (A : AdaParams) (st : AdaState)
    (vals : List (List ℕ)) (l u : ℚ) : Prop :=
  prog[Idx.adaInterval]? = some body_adaInterval ∧
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ mI ∧
    ImplementsF orc prog mI τI [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u)

/-- **`adaNumerical` (603) at `(mN, τN)`**: the numerical entry implements `adaNumerical A st vals`. -/
def O2mNumAt (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (mN τN : ℕ) (A : AdaParams) (st : AdaState)
    (vals : List (List ℕ)) : Prop :=
  prog[Idx.adaNumerical]? = some body_adaNumerical ∧
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ mN ∧
    ImplementsF orc prog mN τN [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals)

/-! ## Depths -/

theorem o2m_depth_round : exprDepth body_bsRound = 15 := by decide

theorem o2m_depth_iv : exprDepth bsIvBranch = 12 := by decide

theorem o2m_depth_num : exprDepth bsNumBranch = 12 := by decide

theorem o2m_depth_adaPub : exprDepth body_adaPub = 51 := by decide +kernel

theorem o2m_depth_bsEvals : exprDepth body_bsEvals = 7 := by decide

theorem o2m_depth_bsEnds : exprDepth body_bsEnds = 12 := by decide

theorem o2m_depth_adaInterval : exprDepth body_adaInterval = 18 := by decide

theorem o2m_depth_adaNumerical : exprDepth body_adaNumerical = 31 := by decide

/-! ## The bound of the encoded ADA state -/

/-- **The bound of an encoded ADA state with `AdaOK`** (B-ACC's `bsT_valSize_adaEnc`):
`N (q_A + sF + 4) + p (sF + sK + 6) + sK + 3 sC + 24`. -/
def o2mStB (A : AdaParams) : ℕ :=
  A.N * (A.qA + Nat.size A.fuel + 4) + A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) +
    Nat.size (maxKs A) + 3 * Nat.size (A.M + A.J + A.R + 2) + 24

theorem o2m_valSize_adaEnc_le {A : AdaParams} {st : AdaState} (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ o2mStB A :=
  bsT_valSize_adaEnc hok

/-! ## The tight bound of the ADA routines -/

/-- **The tight value bound of the ADA routines**: the threshold `2^8 · tightA A + cAddA A` of `TightM`
(`F2e2e/C/Impl/AdaBounds.lean`). Shared with the init frame (e26ae4ae, `O2GlueInit.lean`). -/
def o2MA (A : AdaParams) : ℕ := 2 ^ 8 * tightA A + cAddA A

theorem o2MA_tightM (A : AdaParams) : TightM A (o2MA A) := le_rfl

/-! ## Liftings of the uniform specs -/

/-- **`adaPub` at `(M, C · M)`** from the uniform spec `bsPub_eval` (W2) at any `M ≥ bsPubBound`, by the
weighted lifting (weight certificate `w`, callees of `body_adaPub` of weight `≤ C`). -/
theorem o2m_pubAt_of_lift {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) {M : ℕ} (hq : NormQSpec prog M)
    {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) (hM : bsPubBound Mc J R eA eXi ≤ M)
    {C : ℕ} (hc : CalleesLe w C body_adaPub) :
    O2mPubAt orc prog M (C * M) Mc J R eA eXi := by
  have h600 : prog[Idx.adaPub]? = some body_adaPub :=
    hpub (Idx.adaPub, body_adaPub) (List.mem_append_right _ (by simp [adaPubTable]))
  have hparS := bsM_params_size Mc J R eA eXi
  have hL : bsPubL Mc J R eA eXi ≤ bsPubL Mc J R eA eXi ^ 2 := by
    rw [pow_two]
    exact Nat.le_mul_self _
  have hin : valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) ≤ M := by
    unfold bsPubBound at hM
    omega
  refine ⟨h600, hin, ?_⟩
  exact EvalsVal.toF_wt hO hW (bsPub_eval hpub hq h4 h2 hM).1
    (fun x hx => by rw [List.mem_singleton.mp hx]; exact hin) hc

/-- **`bsEnds` at `(M, C · M)`** from the uniform spec `bsEnds_eval` (W5) at any `M ≥ 20 q + 200`, by the
weighted lifting. -/
theorem o2m_endsAt_of_lift {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w)
    (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2) {M : ℕ} (hq : NormQSpec prog M) {q : ℕ}
    (horc : |orc 1 0 ((q : ℤ) + 1)| ≤ 2 ^ (q + 2) ∧ |orc 2 0 ((q : ℤ) + 1)| ≤ 2 ^ (q + 2))
    (hM : 20 * q + 200 ≤ M) {C : ℕ} (hc : CalleesLe w C body_bsEnds) :
    O2mEndsAt orc prog M (C * M) q := by
  have h920 : prog[bsEndsKey]? = some body_bsEnds := hEn _ List.mem_cons_self
  have hin : valSize (Val.list [encN q]) ≤ M := by
    have := size_le_self q
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  refine ⟨h920, hin, ?_⟩
  exact (bsEnds_eval orc q hEn hq hO horc hM).toF_wt hW
    (fun x hx => by rw [List.mem_singleton.mp hx]; exact hin) hc

end F2e2e.BSpace
