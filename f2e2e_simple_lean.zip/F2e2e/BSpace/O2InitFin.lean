import F2e2e.BSpace.O2InitSizes
import F2e2e.BSpace.O2FinalB

/-!
# B_space, route O2b: the field `finI` of the init frame (C-PROB)

`o2is_finI`: the field `O2Inputs.finI` at `mI = o2i_mI`, `τI = o2i_τI` (e26ae4ae's `O2GlueInit.lean`), from the
coefficient lemmas `o2is_mI_le : o2i_mI ≤ 1 · (N b_𝒰) + 4 · (N χ)` and
`o2is_τI_le : o2i_τI ≤ 31 · (N b_𝒰) + 9853064 · (N χ)` (`O2InitSizes.lean`) through B-ACC's closer
`O2B.o2f_finI_pure` (`O2FinalB.lean`): `258 · (11 · 1 + 31) ≤ 2^30` and
`258 · (11 · 4 + 9853064) + 380266 ≤ 61 · 2^30`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete O2B

/-- **The field `finI` of `O2Inputs`** at `mI = o2i_mI`, `τI = o2i_τI`: the initialization's charge is below
`2^30 · N · (b_𝒰 + χ²)`. -/
theorem o2is_finI : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ bU : ℕ,
    ((O2B.bridgeAdd bsInitProg (bsRank 0)
        ((exprDepth body_bsInit + 3) * o2i_mI M J R aReq ξReq bU + o2i_τI M J R aReq ξReq bU) : ℕ) : ℝ) ≤
      asmBound 30 M J R aReq ξReq bU :=
  fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 bU =>
    o2f_finI_pure ha0 ha1 hξ0 hξ1 (refine_N M J R ha0 ha1 hξ0 hξ1).symm rfl
      (o2is_mI_le M J R ha0 ha1 hξ0 hξ1 bU) (o2is_τI_le M J R ha0 ha1 hξ0 hξ1 bU)
      (by norm_num) (by norm_num)

end F2e2e.BSpace
