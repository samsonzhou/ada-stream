import F2e2e.C.Impl.AdaBounds
import F2e2e.C.Impl.AdaPrepEdge

/-!
# SCRATCH (O2b family 8, owner C-PROB): `adaEdge` under the tight value premise `TightM`
Promoted from Scratch/O2T/AdaPrepEdgeT.lean (owner C-PROB) at 14:28Z; statements unchanged.

* `adaEdge_impl_gen`: W4/B-NUM's proof of `F2e2e.C.Impl.adaEdge_impl` with the two premises
  `hpubB : valSize (adaPubEnc A) ≤ adaBoundA A`, `hM : 2 ^ 32 * adaBoundA A ≤ M` replaced by the single
  premise `valSize (adaPubEnc A) + 4096 (adaZ A + 16) ≤ M` (the N-free scalar bound `2^14 (adaZ + 16) ≤
  adaBoundA` of the old proof, L166, is no longer needed: the test's workspace `36 · edgeW + 12` and the draws
  `drawM ≤ 2^7 (adaZ + 16)` are paid by the additive `4096 (adaZ + 16)`);
* `adaEdge_impl_t`: the tight form (`hpubB` at `tightA`, `hMt : TightM A M`);
* an `example`: the old statement, verbatim, as a corollary of `adaEdge_impl_gen` (at integration this
  becomes the proof of `adaEdge_impl`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

section EdgeT

variable {prog : List Expr} {M : ℕ}

/-- **Spec of `adaEdge`, general value premise.** -/
theorem adaEdge_impl_gen (hS : SampLib prog) {A : AdaParams} {t N0 D0 N1 D1 : ℤ}
    (hD0 : 0 < D0) (hD1 : 0 < D1) (ht : |t| ≤ (maxKs A : ℤ))
    (hN0 : bitLen N0 ≤ edgeW A) (hD0b : bitLen D0 ≤ edgeW A) (hN1 : bitLen N1 ≤ edgeW A)
    (hD1b : bitLen D1 ≤ edgeW A) (hpubM : valSize (adaPubEnc A) + 4096 * (adaZ A + 16) ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1,
        Val.int D1]] body_adaEdge encOB
      ((adaDraw A NoiseKind.intTest).bind fun kp => (adaDraw A NoiseKind.intTest).bind fun km =>
        BitProg.pure (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km)) := by
  have hZ16 := sixteen_le_adaZ A
  set x : Val := Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1, Val.int D1]
    with hx
  have htW : bitLen t ≤ edgeW A := ap_bitLen_le_edgeW_of_abs ht
  have hxM' : valSize x ≤ M := by
    simp only [hx, valSize_list, listSize_cons, listSize_nil, valSize_int]
    unfold edgeW at htW hN0 hD0b hN1 hD1b
    omega
  have hpubM' : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : drawM A NoiseKind.intTest ≤ M := by
    have := drawM_le A NoiseKind.intTest
    omega
  rw [adaPubEnc_eq] at hpubM'
  -- the first draw
  have hpub0 : EvalsVal prog M [x] [] (.inl (eAtN 0 (eV 0))) (adaPubEnc A) :=
    evalsVal_atN' EvalsVal.var0 hxM' rfl
  refine implements_letE_of (draw_impl hS hpub0 (by rw [adaPubEnc_eq]; exact hpubM')
    NoiseKind.intTest hdraw) (fun k => |k| ≤ (maxKs A : ℤ)) (ap_draw_support A _) ?_
  intro kp hkp
  have hpub1 : EvalsVal prog M [encZ kp, x] [] (.inl (eAtN 0 (eV 1))) (adaPubEnc A) :=
    evalsVal_atN' EvalsVal.var1 hxM' rfl
  refine implements_letE_of (draw_impl hS hpub1 (by rw [adaPubEnc_eq]; exact hpubM')
    NoiseKind.intTest hdraw) (fun k => |k| ≤ (maxKs A : ℤ)) (ap_draw_support A _) ?_
  intro km hkm
  apply Implements.of_det
  show EvalsVal prog M [encZ km, encZ kp, x] [] (.inl (edgeZE 0 0 0 0 0 0 0 0 0 0).toExpr)
    (encOB (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km))
  rw [← edgeZE_toExpr km kp t N0 D0 N1 D1 A.tau.num (A.tau.den : ℤ) ((2 ^ A.qA : ℕ) : ℤ)]
  unfold encOB
  rw [obZ_edgeDec A hD0 hD1]
  -- leaves
  set env : List Val := [encZ km, encZ kp, x] with henv
  have hX : EvalsVal prog M env [] (.inl (eV 2)) x := EvalsVal.var2
  have lkm : EvalsVal prog M env [] (.inl (eV 0)) (Val.int km) := EvalsVal.var0
  have lkp : EvalsVal prog M env [] (.inl (eV 1)) (Val.int kp) := EvalsVal.var1
  have lt' : EvalsVal prog M env [] (.inl (eAtN 1 (eV 2))) (Val.int t) := evalsVal_atN' hX hxM' rfl
  have lN0 : EvalsVal prog M env [] (.inl (eAtN 2 (eV 2))) (Val.int N0) := evalsVal_atN' hX hxM' rfl
  have lD0 : EvalsVal prog M env [] (.inl (eAtN 3 (eV 2))) (Val.int D0) := evalsVal_atN' hX hxM' rfl
  have lN1 : EvalsVal prog M env [] (.inl (eAtN 4 (eV 2))) (Val.int N1) := evalsVal_atN' hX hxM' rfl
  have lD1 : EvalsVal prog M env [] (.inl (eAtN 5 (eV 2))) (Val.int D1) := evalsVal_atN' hX hxM' rfl
  have lpub : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (Val.list (pubFields A)) :=
    evalsVal_atN' hX hxM' rfl
  have hτM : valSize (encQ A.tau) ≤ M :=
    le_trans (valSize_le_of_getElem? (l := pubFields A) (n := 9) rfl) hpubM'
  have lτ : EvalsVal prog M env [] (.inl (eAtN 9 (eAtN 0 (eV 2)))) (encQ A.tau) :=
    evalsVal_atN' lpub hpubM' rfl
  have lτn : EvalsVal prog M env [] (.inl (eAtN 0 (eAtN 9 (eAtN 0 (eV 2))))) (Val.int A.tau.num) :=
    evalsVal_atN' lτ hτM rfl
  have lτd : EvalsVal prog M env [] (.inl (eAtN 1 (eAtN 9 (eAtN 0 (eV 2)))))
      (Val.int (A.tau.den : ℤ)) := evalsVal_atN' lτ hτM rfl
  have lH : EvalsVal prog M env [] (.inl (eAtN 8 (eAtN 0 (eV 2)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_atN' lpub hpubM' rfl
  -- bit widths
  have bkm : bitLen km ≤ edgeW A := ap_bitLen_le_edgeW_of_abs hkm
  have bkp : bitLen kp ≤ edgeW A := ap_bitLen_le_edgeW_of_abs hkp
  have bτn : bitLen A.tau.num ≤ edgeW A := by
    have := size_taunum_le_adaZ A
    unfold bitLen edgeW
    omega
  have bτd : bitLen (A.tau.den : ℤ) ≤ edgeW A := by
    have := size_tauden_le_adaZ A
    rw [bitLen_natCast]
    unfold edgeW
    omega
  have bH : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ edgeW A := by
    have := qA_le_adaZ A
    rw [bitLen_natCast, Nat.size_pow]
    unfold edgeW
    omega
  refine ZE.spec' (W := edgeW A) ?_ ?_ ?_
  · simp only [edgeZE, ZE.OK, lkm, lkp, lt', lN0, lD0, lN1, lD1, lτn, lτd, lH, and_self]
  · simp only [edgeZE, ZE.LeafLe, bkm, bkp, htW, hN0, hD0b, hN1, hD1b, bτn, bτd, bH, and_self]
  · rw [edgeZE_cb]
    have hW : edgeW A = 64 * (adaZ A + 16) := by unfold edgeW; norm_num
    rw [hW]
    linarith

/-- **Spec of `adaEdge`, tight premise** (O2b family 8). -/
theorem adaEdge_impl_t (hS : SampLib prog) {A : AdaParams} {t N0 D0 N1 D1 : ℤ}
    (hD0 : 0 < D0) (hD1 : 0 < D1) (ht : |t| ≤ (maxKs A : ℤ))
    (hN0 : bitLen N0 ≤ edgeW A) (hD0b : bitLen D0 ≤ edgeW A) (hN1 : bitLen N1 ≤ edgeW A)
    (hD1b : bitLen D1 ≤ edgeW A) (hpubB : valSize (adaPubEnc A) ≤ tightA A)
    (hMt : TightM A M) :
    Implements prog M [Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1,
        Val.int D1]] body_adaEdge encOB
      ((adaDraw A NoiseKind.intTest).bind fun kp => (adaDraw A NoiseKind.intTest).bind fun km =>
        BitProg.pure (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km)) :=
  adaEdge_impl_gen hS hD0 hD1 ht hN0 hD0b hN1 hD1b (by
    unfold TightM cAddA at hMt
    have h1 : tightA A ≤ 2 ^ 8 * tightA A := Nat.le_mul_of_pos_left _ (by norm_num)
    have h2 : 4096 * (adaZ A + 16) ≤ 2 ^ 18 * (A.p + adaZ A + 16) :=
      calc 4096 * (adaZ A + 16) ≤ 4096 * (A.p + adaZ A + 16) := Nat.mul_le_mul_left _ (by omega)
        _ ≤ 2 ^ 18 * (A.p + adaZ A + 16) := Nat.mul_le_mul_right _ (by norm_num)
    linarith)

/-- Check: the old statement of `adaEdge_impl`, verbatim, is a corollary of `adaEdge_impl_gen` (at integration
this term becomes the proof of `adaEdge_impl`). -/
example (hS : SampLib prog) {A : AdaParams} {t N0 D0 N1 D1 : ℤ}
    (hD0 : 0 < D0) (hD1 : 0 < D1) (ht : |t| ≤ (maxKs A : ℤ))
    (hN0 : bitLen N0 ≤ edgeW A) (hD0b : bitLen D0 ≤ edgeW A) (hN1 : bitLen N1 ≤ edgeW A)
    (hD1b : bitLen D1 ≤ edgeW A) (hpubB : valSize (adaPubEnc A) ≤ adaBoundA A)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, Val.int t, Val.int N0, Val.int D0, Val.int N1,
        Val.int D1]] body_adaEdge encOB
      ((adaDraw A NoiseKind.intTest).bind fun kp => (adaDraw A NoiseKind.intTest).bind fun km =>
        BitProg.pure (edgeDec A t ((N0 : ℚ) / D0) ((N1 : ℚ) / D1) kp km)) :=
  adaEdge_impl_gen hS hD0 hD1 ht hN0 hD0b hN1 hD1b (by
    have hB : 4096 * (adaZ A + 16) ≤ adaBoundA A := by
      unfold adaBoundA
      exact Nat.mul_le_mul_right _ (calc 4096 ≤ 2 ^ 10 * 16 := by norm_num
        _ ≤ 2 ^ 10 * (A.N + A.p + 16) := Nat.mul_le_mul_left _ (by omega))
    have h2 : 2 * adaBoundA A ≤ 2 ^ 32 * adaBoundA A := Nat.mul_le_mul_right _ (by norm_num)
    linarith)

end EdgeT

end F2e2e.C.Impl
