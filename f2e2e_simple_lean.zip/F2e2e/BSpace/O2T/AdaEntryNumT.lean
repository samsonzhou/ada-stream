import F2e2e.BSpace.O2T.AdaMusT
import F2e2e.C.Impl.AdaEntryNum

/-!
# SCRATCH (O2b family 7, owner A-ARCH a99d156c): `adaNumerical` (Idx 603) under the tight premise `TightM`
Promoted from Scratch/O2T/AdaEntryNumT.lean (owner A-ARCH a99d156c) at 14:30Z; statements unchanged.

`adaNumerical_impl_of_t`: `F2e2e.C.Impl.adaNumerical_impl_of` (`F2e2e/C/Impl/AdaEntryNum.lean`) with
`(hMt : TightM A M)` for `(hM : 2 ^ 32 * adaBoundA A ≤ M)` (callee rule of the O2b tech lead 17fc0802;
`TightM`, `tightA`: B-ACC's `F2e2e/Scratch/O2T/TightDefs.lean`). A T-FILE on top of the original module (the
program text, the reference and `NumPrepAt` are unchanged and imported); the private helpers of the original are
re-proved here under fresh names (`aent_…`, so that they do not clash with the originals at the merge),
verbatim except for: the value bounds at `tightA A` (the `_t` size lemmas), `aen_le_bound_t`
(`32 (adaZ + 16) ≤ tightA`, `2^10 ≤ tightA`), `hM : 2^8 · tightA A ≤ M` from `hMt` (`tight_hM`), and the callee
`adaMusR_val_t` (`F2e2e/Scratch/O2T/AdaMusT.lean`). Every value bound of the routine is far below `2^8 · tightA`
(the largest: the integer expression of the release, `35 · 2^6 (adaZ + 16) + 18 ≤ 70 · tightA`); no N-free term.
At integration (after O1) these proofs replace the private lemmas of `AdaEntryNum.lean` and the old lemma becomes
`adaNumerical_impl_of … hM := adaNumerical_impl_of_t … (TightM.of_old hM)` (`adaNumerical_impl_of_of_t` below).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

section Proof

variable {prog : List Expr} {M : ℕ}

/-! ## Frame helpers -/

private theorem aent_letE_det {α : Type} {env : List Val} {ea eb : Expr} {va : Val}
    {enc : α → Val} {p : BitProg α} (ha : EvalsVal prog M env [] (.inl ea) va)
    (hb : Implements prog M (va :: env) eb enc p) : Implements prog M env (Expr.letE ea eb) enc p :=
  fun bits a h => by simpa using EvalsVal.letE ha (hb bits a h)

private theorem aent_ite_t {α : Type} {env : List Val} {c t f : Expr} {z : ℤ}
    {enc : α → Val} {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z ≠ 0)
    (ht : Implements prog M env t enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  fun bits a h => by simpa using EvalsVal.ite_true (f := f) hc hz (ht bits a h)

private theorem aent_ite_f {α : Type} {env : List Val} {c t f : Expr} {z : ℤ}
    {enc : α → Val} {p : BitProg α} (hc : EvalsVal prog M env [] (.inl c) (Val.int z)) (hz : z = 0)
    (hf : Implements prog M env f enc p) : Implements prog M env (Expr.ite c t f) enc p :=
  fun bits a h => by simpa using EvalsVal.ite_false (t := t) hc hz (hf bits a h)

private theorem aent_inp_top {env : List Val} {k n : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)} {v : Val}
    (henv : env[k]? = some (Val.list [adaPubEnc A, adaEnc st, encVals vals]))
    (hM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M)
    (hget : [adaPubEnc A, adaEnc st, encVals vals][n]? = some v) :
    EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
  evalsVal_atN' (EvalsVal.var henv) hM hget

private theorem aent_inp_pub {env : List Val} {k n : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)} {v : Val}
    (henv : env[k]? = some (Val.list [adaPubEnc A, adaEnc st, encVals vals]))
    (hM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M)
    (hget : (pubFields A)[n]? = some v) : EvalsVal prog M env [] (.inl (eAtN n (eAtN 0 (eV k)))) v :=
  evalsVal_atN' (l := pubFields A) (evalsVal_atN' (EvalsVal.var henv) hM rfl)
    (le_trans (valSize_lt_of_mem List.mem_cons_self).le hM) hget

private theorem aent_inp_st {env : List Val} {k n : ℕ} {A : AdaParams} {st : AdaState}
    {vals : List (List ℕ)} {v : Val}
    (henv : env[k]? = some (Val.list [adaPubEnc A, adaEnc st, encVals vals]))
    (hM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M)
    (hget : (aenStFields st)[n]? = some v) : EvalsVal prog M env [] (.inl (eAtN n (eAtN 1 (eV k)))) v :=
  evalsVal_atN' (l := aenStFields st) (evalsVal_atN' (EvalsVal.var henv) hM rfl)
    (le_trans (valSize_lt_of_mem (List.mem_cons_of_mem _ List.mem_cons_self)).le hM) hget

private theorem aent_st_fld {env : List Val} {k n : ℕ} {st : AdaState} {v : Val}
    (henv : env[k]? = some (adaEnc st)) (hM : valSize (adaEnc st) ≤ M)
    (hget : (aenStFields st)[n]? = some v) : EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
  evalsVal_atN' (l := aenStFields st) (EvalsVal.var henv) hM hget

/-- The arithmetic facts of the tight scale used by the omega calls below. -/
private theorem aen_le_bound_t (A : AdaParams) : 32 * (adaZ A + 16) ≤ tightA A ∧ 2 ^ 10 ≤ tightA A := by
  have h := thirtytwo_le_tightA A
  have hZ16 := sixteen_le_adaZ A
  constructor <;> omega

/-- The tight premise in the form used by the omega calls: `2^8 · tightA A ≤ M`. -/
private theorem tight_hM {A : AdaParams} {M : ℕ} (h : TightM A M) : 2 ^ 8 * tightA A ≤ M := by
  unfold TightM at h
  omega

/-! ## The branches -/

private theorem aent_abort_val {A : AdaParams} {st : AdaState} {vals : List (List ℕ)}
    (hinpM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M) :
    EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] [] (.inl aenAbortE)
      (Val.list [encNum AdaNum.abort, adaEnc st]) := by
  have hst : valSize (adaEnc st) < valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) :=
    valSize_lt_of_mem (List.mem_cons_of_mem _ List.mem_cons_self)
  refine evalsVal_list (List.Forall₂.cons (EvalsVal.nil ?_) (List.Forall₂.cons (aent_inp_top rfl hinpM rfl)
    List.Forall₂.nil)) ?_
  · simp only [valSize_list, listSize_cons, listSize_nil] at hinpM ⊢
    omega
  · simp only [encNum, valSize_list, listSize_cons, listSize_nil] at hinpM hst ⊢
    omega

private theorem aenHalt_val_t {A : AdaParams} {st : AdaState} {inp : Val}
    (hok3 : AdaOK A { st with nNum := st.nNum + 1, halted := true, capAborted := true })
    (hst1 : valSize (adaEnc { st with nNum := st.nNum + 1 }) ≤ M) (hMt : TightM A M) :
    EvalsVal prog M [encOptSt none, adaEnc { st with nNum := st.nNum + 1 }, inp] [] (.inl aenHaltE)
      (Val.list [encNum AdaNum.abort,
        adaEnc { st with nNum := st.nNum + 1, halted := true, capAborted := true }]) := by
  have h3 := valSize_adaEnc_le_t hok3
  obtain ⟨_, h10⟩ := aen_le_bound_t A
  have hM := tight_hM hMt
  have hl1 : ∀ {env : List Val}, EvalsVal prog M env [] (.inl (eLit 1)) (Val.int 1) :=
    EvalsVal.lit (by simp; omega)
  have hfields : EvalsVal prog M [encOptSt none, adaEnc { st with nNum := st.nNum + 1 }, inp] []
      (.inl (eList [eAtN 0 (eV 1), eAtN 1 (eV 1), eAtN 2 (eV 1), eAtN 3 (eV 1), eAtN 4 (eV 1),
        eAtN 5 (eV 1), eAtN 6 (eV 1), eLit 1, eLit 1]))
      (Val.list (aenStFields { st with nNum := st.nNum + 1, halted := true, capAborted := true })) :=
    evalsVal_list (.cons (aent_st_fld rfl hst1 rfl) (.cons (aent_st_fld rfl hst1 rfl) (.cons (aent_st_fld rfl hst1 rfl)
      (.cons (aent_st_fld rfl hst1 rfl) (.cons (aent_st_fld rfl hst1 rfl) (.cons (aent_st_fld rfl hst1 rfl)
      (.cons (aent_st_fld rfl hst1 rfl) (.cons hl1 (.cons hl1 .nil)))))))))
      (by rw [← adaEnc_eq_aenStFields]; omega)
  refine evalsVal_list (List.Forall₂.cons (EvalsVal.nil (by simp; omega))
    (List.Forall₂.cons hfields List.Forall₂.nil)) ?_
  simp only [encNum, valSize_list, listSize_cons, listSize_nil]
  omega

/-- The output of the `some` branch. -/
private theorem aenOut_val_t (hq : NormQSpec prog M) {A : AdaParams} {st2 : AdaState}
    {r st1E inp : Val} {m0 : ℤ × ℤ} {k : ℤ} (hD : 0 < m0.2)
    (hbN : bitLen m0.1 ≤ 2 ^ 6 * (adaZ A + 16)) (hbD : bitLen m0.2 ≤ 2 ^ 6 * (adaZ A + 16))
    (hk : |k| ≤ (maxKs A : ℤ))
    (hpub : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl (eAtN 0 (eV 5)))
      (adaPubEnc A)) (hpubB : valSize (adaPubEnc A) ≤ tightA A)
    (hst2 : valSize (adaEnc st2) ≤ tightA A) (hMt : TightM A M) :
    EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl aenOutE)
      (Val.list [encNum (AdaNum.val (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA *
        (roundIdxQ ((1 / 2 : ℚ) ^ A.qA) ((m0.1 : ℚ) / m0.2 + (1 / 2 : ℚ) ^ A.qA * k) : ℚ)))),
        adaEnc st2]) := by
  obtain ⟨hZB, h10⟩ := aen_le_bound_t A
  have hM := tight_hM hMt
  have hqZ := qA_le_adaZ A
  have hKZ := size_maxKs_le_adaZ A
  have hH : (0 : ℤ) < ((2 ^ A.qA : ℕ) : ℤ) := by positivity
  have hbH : bitLen ((2 ^ A.qA : ℕ) : ℤ) = A.qA + 1 := by rw [bitLen_natCast, Nat.size_pow]
  have hbk : bitLen k ≤ adaZ A := (bitLen_le_size_of_abs_le hk).trans hKZ
  -- the leaves
  have hmuM : valSize (encPZ m0) ≤ M := by
    simp only [encPZ, valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega
  have lN : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl (eAtN 0 (eV 1)))
      (Val.int m0.1) := evalsVal_atN' (l := [Val.int m0.1, Val.int m0.2]) (EvalsVal.var rfl) hmuM rfl
  have lD : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl (eAtN 1 (eV 1)))
      (Val.int m0.2) := evalsVal_atN' (l := [Val.int m0.1, Val.int m0.2]) (EvalsVal.var rfl) hmuM rfl
  have lk : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl (eV 0))
      (Val.int k) := EvalsVal.var rfl
  have lH : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] [] (.inl aenHE)
      (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_atN' (l := pubFields A) hpub (by rw [← adaPubEnc_eq]; omega) rfl
  -- the integer `R'`
  have hW1 : bitLen m0.1 ≤ 2 ^ 6 * (adaZ A + 16) := hbN
  have hW2 : bitLen m0.2 ≤ 2 ^ 6 * (adaZ A + 16) := hbD
  have hW3 : bitLen k ≤ 2 ^ 6 * (adaZ A + 16) := by omega
  have hW4 : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ 2 ^ 6 * (adaZ A + 16) := by omega
  have hzE : EvalsVal prog M [encZ k, encPZ m0, adaEnc st2, r, st1E, inp] []
      (.inl (aenZ (ZE.leaf (eAtN 0 (eV 1)) m0.1) (ZE.leaf (eAtN 1 (eV 1)) m0.2) (ZE.leaf (eV 0) k)
        (ZE.leaf aenHE ((2 ^ A.qA : ℕ) : ℤ))).toExpr)
      (Val.int (aenZ (ZE.leaf (eAtN 0 (eV 1)) m0.1) (ZE.leaf (eAtN 1 (eV 1)) m0.2) (ZE.leaf (eV 0) k)
        (ZE.leaf aenHE ((2 ^ A.qA : ℕ) : ℤ))).val) := by
    refine ZE.spec' (W := 2 ^ 6 * (adaZ A + 16)) ?_ ?_ ?_
    · simp only [aenZ, zClip0, ZE.OK, ZE.val, lN, lD, lk, lH, true_and, and_true, and_self, ne_eq]
      omega
    · simp only [aenZ, zClip0, ZE.LeafLe, hW1, hW2, hW3, hW4, and_self]
    · have hcb : ∀ W : ℕ, (aenZ (ZE.leaf (eAtN 0 (eV 1)) m0.1) (ZE.leaf (eAtN 1 (eV 1)) m0.2)
          (ZE.leaf (eV 0) k) (ZE.leaf aenHE ((2 ^ A.qA : ℕ) : ℤ))).cb W = 35 * W + 17 := by
        intro W
        simp only [aenZ, zClip0, ZE.cb, bitLen_zero]
        ring
      rw [hcb]
      omega
  set R' : ℤ := (aenZ (ZE.leaf (eAtN 0 (eV 1)) m0.1) (ZE.leaf (eAtN 1 (eV 1)) m0.2)
    (ZE.leaf (eV 0) k) (ZE.leaf aenHE ((2 ^ A.qA : ℕ) : ℤ))).val with hR'
  have hval : R' = clipZ 0 ((2 ^ A.qA : ℕ) : ℤ) ((m0.1 * ((2 ^ A.qA : ℕ) : ℤ) +
      m0.1 * ((2 ^ A.qA : ℕ) : ℤ) + (k * m0.2 + k * m0.2) + m0.2) / (m0.2 + m0.2)) :=
    zClip0_val _ _ hH.le
  have hR0 : 0 ≤ R' := by rw [hval]; exact le_max_left _ _
  have hRH : R' ≤ ((2 ^ A.qA : ℕ) : ℤ) := by rw [hval]; exact max_le hH.le (min_le_left _ _)
  have hbR : bitLen R' ≤ A.qA + 1 := (bitLen_le_of_nonneg_le hR0 hRH).trans hbH.le
  -- `normQ`
  obtain ⟨bq, hbq, hqs⟩ := hq
  have hpair := EvalsVal.pair hzE lH (by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    omega)
  have hnq := evalsVal_call_det hbq hpair (hqs R' _ hH (by omega))
  rw [hval, aenVal_eq A.qA hD k] at hnq
  have hnum := valSize_encNum_clip_le A (roundIdxQ ((1 / 2 : ℚ) ^ A.qA)
    ((m0.1 : ℚ) / m0.2 + (1 / 2 : ℚ) ^ A.qA * k))
  refine evalsVal_list (List.Forall₂.cons (evalsVal_list (List.Forall₂.cons hnq List.Forall₂.nil) ?_)
    (List.Forall₂.cons (EvalsVal.var rfl) List.Forall₂.nil)) ?_
  · exact le_trans hnum (by omega)
  · have h1 : valSize (Val.list [encNum (AdaNum.val (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA *
        (roundIdxQ ((1 / 2 : ℚ) ^ A.qA) ((m0.1 : ℚ) / m0.2 + (1 / 2 : ℚ) ^ A.qA * k) : ℚ)))),
        adaEnc st2]) ≤ M := by
      simp only [valSize_list, listSize_cons, listSize_nil]
      have : valSize (encNum (AdaNum.val (clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA *
          (roundIdxQ ((1 / 2 : ℚ) ^ A.qA) ((m0.1 : ℚ) / m0.2 + (1 / 2 : ℚ) ^ A.qA * k) : ℚ))))) ≤
          2 * A.qA + 10 := hnum
      omega
    exact h1

/-- The `some st₂` branch. -/
private theorem aenSome_impl_t (hmus : MusLib prog) (hS : SampLib prog) (hq : NormQSpec prog M)
    {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st st2 : AdaState} {vals : List (List ℕ)}
    (hok : AdaOK A st) (hok2 : AdaOK A st2) (hv : ValsOKA A vals) (hMt : TightM A M)
    (st1E : Val) :
    Implements prog M [encOptSt (some st2), st1E, Val.list [adaPubEnc A, adaEnc st, encVals vals]]
      aenSomeE (fun r => Val.list [encNum r.1, adaEnc r.2])
      ((adaDraw A NoiseKind.num).bind fun k => BitProg.pure (AdaNum.val (aenVal A st2 vals k), st2)) := by
  obtain ⟨hZB, h10⟩ := aen_le_bound_t A
  have hM := tight_hM hMt
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hst2B := valSize_adaEnc_le_t hok2
  have hvB := valSize_encVals_le_t hbs hv.1 hv.2
  have hinpM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  -- `st₂`
  have h1 : EvalsVal prog M [encOptSt (some st2), st1E, Val.list [adaPubEnc A, adaEnc st, encVals vals]]
      [] (.inl (eHd (eV 0))) (adaEnc st2) :=
    EvalsVal.head (l := []) (EvalsVal.var rfl) (by omega)
  refine aent_letE_det h1 ?_
  -- the predictions
  obtain ⟨m0, rest, hm⟩ : ∃ m0 rest, musZ A st2.scores vals = m0 :: rest :=
    List.exists_cons_of_length_pos (by rw [musZ_length]; omega)
  have hm0 : (musZ A st2.scores vals).getD 0 (0, 1) = m0 := by rw [hm]; rfl
  obtain ⟨hD, hμ⟩ := musZ_spec_proof hok2 hv hpos 0 (by omega)
  rw [hm0] at hD hμ
  obtain ⟨hbN, hbD⟩ := musZ_bits_proof hok2 hv m0 (by rw [hm]; exact List.mem_cons_self)
  have hsc : valSize (encL (encL encZ) st2.scores) < valSize (adaEnc st2) :=
    valSize_lt_of_mem List.mem_cons_self
  have hargs : EvalsVal prog M [adaEnc st2, encOptSt (some st2), st1E,
      Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eList [eAtN 0 (eV 3), eAtN 0 (eV 0), eAtN 2 (eV 3)]))
      (Val.list [adaPubEnc A, encL (encL encZ) st2.scores, encVals vals]) := by
    refine evalsVal_list (List.Forall₂.cons (aent_inp_top rfl hinpM rfl) (List.Forall₂.cons
      (aent_st_fld rfl (by omega) rfl) (List.Forall₂.cons (aent_inp_top rfl hinpM rfl) List.Forall₂.nil))) ?_
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hmusE := evalsVal_call_det hmus.1 hargs (adaMusR_val_t hmus hbs hT hpos hok2 hv hMt)
  rw [hm] at hmusE
  have hmuE : EvalsVal prog M [adaEnc st2, encOptSt (some st2), st1E,
      Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eHd (eCall Idx.adaMusR (eList [eAtN 0 (eV 3), eAtN 0 (eV 0), eAtN 2 (eV 3)]))))
      (encPZ m0) :=
    EvalsVal.head (x := encPZ m0) (l := rest.map encPZ) hmusE (by
      simp only [encPZ, valSize_list, listSize_cons, listSize_nil, valSize_int]
      omega)
  refine aent_letE_det hmuE ?_
  -- the draw
  have hpub4 : EvalsVal prog M [encPZ m0, adaEnc st2, encOptSt (some st2), st1E,
      Val.list [adaPubEnc A, adaEnc st, encVals vals]] [] (.inl (eAtN 0 (eV 4))) (adaPubEnc A) :=
    aent_inp_top rfl hinpM rfl
  refine implements_letE_of (draw_impl hS hpub4 (by omega) NoiseKind.num
    (by have := drawM_le A NoiseKind.num; omega))
    (fun k => |k| ≤ (maxKs A : ℤ))
    (fun bits k h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A _)) ?_
  intro k hk
  apply Implements.of_det
  have hval : aenVal A st2 vals k = clipQ 0 1 ((1 / 2 : ℚ) ^ A.qA *
      (roundIdxQ ((1 / 2 : ℚ) ^ A.qA) ((m0.1 : ℚ) / m0.2 + (1 / 2 : ℚ) ^ A.qA * k) : ℚ)) := by
    unfold aenVal
    rw [← hμ]
    rfl
  rw [hval]
  exact aenOut_val_t hq hD hbN hbD hk (aent_inp_top rfl hinpM rfl) hpubB hst2B hMt

/-- After the cap test: `st₁`, `PrepareRoot`, and the two branches. -/
private theorem aenMain_impl_t {A : AdaParams} {vals : List (List ℕ)} (hP : NumPrepAt prog M A vals)
    (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog) (hq : NormQSpec prog M)
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    (hR : st.nNum < A.R) (hv : ValsOKA A vals) (hMt : TightM A M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] aenMainE
      (fun r => Val.list [encNum r.1, adaEnc r.2])
      (((prepareRoot A vals A.fuel { st with nNum := st.nNum + 1 } (List.replicate A.p false)).toBits
        (adaDraw A)).bind (aenCont A st vals)) := by
  obtain ⟨hZB, h10⟩ := aen_le_bound_t A
  have hM := tight_hM hMt
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hvB := valSize_encVals_le_t hbs hv.1 hv.2
  have hpZ := p_le_adaZ A
  have hfZ := size_fuel_le_adaZ A
  have hinpM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hok1 : AdaOK A { st with nNum := st.nNum + 1 } :=
    ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
      hok.thrOut_le, hok.scores_le, hok.rej_le, hok.rej_halt, hok.nInt_le,
      by show st.nNum + 1 ≤ A.R; omega⟩
  have hst1B := valSize_adaEnc_le_t hok1
  -- `st₁` by `set`
  have hx : bitLen ((st.nNum : ℤ) + 1) ≤ adaZ A := by
    rw [show ((st.nNum : ℤ) + 1) = ((st.nNum + 1 : ℕ) : ℤ) by push_cast; ring, bitLen_natCast]
    exact (Nat.size_le_size (show st.nNum + 1 ≤ A.M + A.J + A.R + 2 by omega)).trans
      (size_MJR_le_adaZ A)
  have hnN : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eAtN 6 (eAtN 1 (eV 0)))) (Val.int (st.nNum : ℤ)) := aent_inp_st rfl hinpM rfl
  have hadd := EvalsVal.add hnN (EvalsVal.lit (z := 1) (by simp; omega)) (by
    rw [valSize_int]
    omega)
  have hsz6 : Nat.size 6 ≤ 6 := size_le_self 6
  have hargs1 : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eList [eAtN 1 (eV 0), eLit 6, eAdd (eAtN 6 (eAtN 1 (eV 0))) (eLit 1)]))
      (Val.list [Val.list (aenStFields st), encN 6, Val.int ((st.nNum : ℤ) + 1)]) := by
    refine evalsVal_list (List.Forall₂.cons (aent_inp_top rfl hinpM rfl) (List.Forall₂.cons
      (EvalsVal.lit (le_trans (Nat.succ_le_succ (bitLen_natCast_le 6)) (by omega)))
      (List.Forall₂.cons hadd List.Forall₂.nil))) ?_
    rw [← adaEnc_eq_aenStFields]
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN]
    omega
  have hset := set_val hL hargs1 (by
    unfold S_set
    rw [← adaEnc_eq_aenStFields, valSize_int]
    omega)
  have heq1 : Val.list ((aenStFields st).set 6 (Val.int ((st.nNum : ℤ) + 1))) =
      adaEnc { st with nNum := st.nNum + 1 } := by
    simp only [aenStFields, adaEnc, List.set_cons_succ, List.set_cons_zero, encN]
    push_cast
    rfl
  rw [heq1] at hset
  refine aent_letE_det hset ?_
  -- `PrepareRoot`
  obtain ⟨bodyP, hbodyP, hPs⟩ := hP
  have hcache : Val.list (List.replicate A.p (Val.int 0)) = encL encB (List.replicate A.p false) := by
    simp [encL, encB, List.map_replicate]
  have hcV : valSize (encL encB (List.replicate A.p false)) = 1 + 2 * A.p := by
    rw [← hcache, valSize_replicate_int0]
  have hpsz := size_le_self A.p
  have hrep : EvalsVal prog M [adaEnc { st with nNum := st.nNum + 1 },
      Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eCall Idx.replicate (ePair (eAtN 0 (eAtN 0 (eV 1))) (eLit 0))))
      (encL encB (List.replicate A.p false)) := by
    have hp : EvalsVal prog M [adaEnc { st with nNum := st.nNum + 1 },
        Val.list [adaPubEnc A, adaEnc st, encVals vals]] [] (.inl (eAtN 0 (eAtN 0 (eV 1))))
        (Val.int (A.p : ℤ)) := aent_inp_pub rfl hinpM rfl
    have hpair := EvalsVal.pair hp (EvalsVal.lit (z := 0) (by simp; omega)) (by
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero,
        bitLen_natCast]
      omega)
    have := replicate_val hL hpair (by
      unfold S_replicate
      simp only [valSize_int, bitLen_zero]
      omega)
    rw [hcache] at this
    exact this
  have hfV : valSize (encN A.fuel) ≤ adaZ A + 1 := by rw [valSize_encN]; omega
  have hargsP : EvalsVal prog M [adaEnc { st with nNum := st.nNum + 1 },
      Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eList [eAtN 3 (eAtN 0 (eV 1)), eV 0,
        eCall Idx.replicate (ePair (eAtN 0 (eAtN 0 (eV 1))) (eLit 0)), eAtN 0 (eV 1), eAtN 2 (eV 1)]))
      (Val.list [encN A.fuel, adaEnc { st with nNum := st.nNum + 1 },
        encL encB (List.replicate A.p false), adaPubEnc A, encVals vals]) := by
    refine evalsVal_list (List.Forall₂.cons (aent_inp_pub rfl hinpM rfl) (List.Forall₂.cons
      (EvalsVal.var rfl) (List.Forall₂.cons hrep (List.Forall₂.cons (aent_inp_top rfl hinpM rfl)
      (List.Forall₂.cons (aent_inp_top rfl hinpM rfl) List.Forall₂.nil))))) ?_
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  refine implements_letE_of (implements_call_det hbodyP hargsP
    (hPs _ A.fuel _ hok1 le_rfl (by simp)))
    (fun r => ∀ st2, r = some st2 → AdaOK A st2 ∧ AdaSameCtr { st with nNum := st.nNum + 1 } st2)
    (fun bits r h => Always.of_run (DAlw.toBits (adaDraw_adaKB A)
      (prepareRoot_ok vals A.fuel _ _ hok1)) h) ?_
  intro r hr
  cases r with
  | none =>
    apply Implements.of_det
    have hok3 : AdaOK A { st with nNum := st.nNum + 1, halted := true, capAborted := true } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hok.thrOut_le, hok.scores_le, hok.rej_le, fun h' => absurd h' (by simp), hok.nInt_le,
        by show st.nNum + 1 ≤ A.R; omega⟩
    exact EvalsVal.ite_true (EvalsVal.isNil_nil EvalsVal.var0 (by omega)) one_ne_zero
      (aenHalt_val_t hok3 (by omega) hMt)
  | some st2 =>
    obtain ⟨hok2, -⟩ := hr st2 rfl
    refine aent_ite_f (EvalsVal.isNil_cons (x := adaEnc st2) (l := []) EvalsVal.var0
      (by omega)) rfl ?_
    exact aenSome_impl_t hmus hS hq hbs hT hpos hok hok2 hv hMt _

end Proof

/-- **Spec of `adaNumerical`, tight premise** (O2b family 7; `PrepareRoot` at index `adaPrepR` in the
form `NumPrepAt`). -/
theorem adaNumerical_impl_of_t {prog : List Expr} {M : ℕ} {A : AdaParams} {vals : List (List ℕ)}
    (hP : NumPrepAt prog M A vals) (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog)
    (hq : NormQSpec prog M) (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    (hv : ValsOKA A vals) (hMt : TightM A M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals) := by
  obtain ⟨hZB, h10⟩ := aen_le_bound_t A
  have hM := tight_hM hMt
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hvB := valSize_encVals_le_t hbs hv.1 hv.2
  have hinpM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hhalt : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eAtN 7 (eAtN 1 (eV 0)))) (Val.int (if st.halted = true then 1 else 0)) :=
    aent_inp_st rfl hinpM rfl
  have hnN : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eAtN 6 (eAtN 1 (eV 0)))) (Val.int (st.nNum : ℤ)) := aent_inp_st rfl hinpM rfl
  have hRR : EvalsVal prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] []
      (.inl (eAtN 6 (eAtN 0 (eV 0)))) (Val.int (A.R : ℤ)) := aent_inp_pub rfl hinpM rfl
  have hab := aent_abort_val (prog := prog) hinpM
  rw [adaNumerical_toBits_eq]
  unfold body_adaNumerical
  by_cases hh : st.halted = true
  · rw [if_pos (Or.inl hh)]
    exact Implements.of_det (EvalsVal.ite_true hhalt (by simp [hh]) hab)
  · by_cases hRn : A.R ≤ st.nNum
    · rw [if_pos (Or.inr hRn)]
      exact Implements.of_det (EvalsVal.ite_false hhalt (by simp [hh])
        (EvalsVal.ite_false (EvalsVal.lt hnN hRR (by omega)) (by split_ifs <;> omega) hab))
    · rw [if_neg (not_or.mpr ⟨hh, hRn⟩)]
      refine aent_ite_f hhalt (by simp [hh]) (aent_ite_t (EvalsVal.lt hnN hRR (by omega))
        (by split_ifs <;> omega) ?_)
      exact aenMain_impl_t hP hmus hS hL hq hbs hT hpos hok (by omega) hv hMt


/-- The old statement is the corollary (the integration form of `adaNumerical_impl_of`). -/
theorem adaNumerical_impl_of_of_t {prog : List Expr} {M : ℕ} {A : AdaParams} {vals : List (List ℕ)}
    (hP : NumPrepAt prog M A vals) (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog)
    (hq : NormQSpec prog M) (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals) :=
  adaNumerical_impl_of_t hP hmus hS hL hq hbs hT hpos hok hv (TightM.of_old hM)

end F2e2e.C.Impl
