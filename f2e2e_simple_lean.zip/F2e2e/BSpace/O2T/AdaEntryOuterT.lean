import F2e2e.C.Impl.AdaEntryOuter
import F2e2e.BSpace.O2T.AdaMusT

/-!
# O2b family 5 (W2, a2ff64c3, for 17fc0802): the outer test `adaIvOuter` (Idx 606) under `TightM`
Promoted from Scratch/O2T/AdaEntryOuterT.lean (owner W2 a2ff64c3) at 14:30Z; statements unchanged.

Delta file: imports the ORIGINAL `F2e2e.C.Impl.AdaEntryOuter` and adds only
`adaIvOuter_impl_t`, whose statement is exactly `adaIvOuter_impl`'s with `hM : 2 ^ 32 * adaBoundA A ≤ M`
replaced by `(hMt : TightM A M)` (the extra premise `hMq : 2 ^ 28 * Bq ≤ M` is kept). The proof is the original
one with the size facts `adaBound_facts` replaced by the tight ones (`ivT_facts`):
* `|adaPubEnc A|, |adaEnc st|, |encVals vals| ≤ tightA A` (B-ACC's `_t` size lemmas);
* the `μ` list `|encL encPZ (musZ A st.scores vals)| ≤ 2^7 · tightA A` (`(p + 1)(2^7 (adaZ + 16) + 6) + 1`);
* the integer intermediates (`≤ 2^9 (adaZ A + 16)` bits) and the draws are covered by `cAddA A`.
Cross-family callees: `adaMusR_val_t` (family 7, A-ARCH's `AdaMusT.lean`) and `adaIvReject_impl_t` (family 6,
appended by W4 to the original `F2e2e/C/Impl/AdaEntryReject.lean`, imported through `AdaEntryOuter`). Bound-free
callees used as is: `adaIvRound_val`, `draw_impl`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- **Tight size facts of family 5**: the parameter record, an invariant state and a well-formed query table
are below `tightA A`, the list of the `p + 1` predictions `μ_j` below `2^7 · tightA A`. -/
theorem ivT_facts {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) :
    valSize (adaPubEnc A) ≤ tightA A ∧ valSize (adaEnc st) ≤ tightA A ∧
      valSize (encVals vals) ≤ tightA A ∧
      valSize (encL encPZ (musZ A st.scores vals)) ≤ 2 ^ 7 * tightA A := by
  refine ⟨valSize_adaPubEnc_le_t A hbs hT, valSize_adaEnc_le_t hok,
    valSize_encVals_le_t hbs hv.1 hv.2, ?_⟩
  have hZ16 := sixteen_le_adaZ A
  have hbits := musZ_bits hok hv
  have h1 := valSize_encL_le encPZ (musZ A st.scores vals) (2 ^ 7 * (adaZ A + 16) + 5) (by
    intro r hr
    obtain ⟨a, b⟩ := r
    rw [valSize_encPZ]
    have := hbits (a, b) hr
    simp only at this
    omega)
  rw [musZ_length] at h1
  have hP1 : A.p + 1 ≤ A.N + A.p + 16 := by omega
  have hW : 2 ^ 7 * (adaZ A + 16) + 5 + 1 + 1 ≤ 2 ^ 8 * (adaZ A + 16) := by omega
  have hPW : (A.p + 1) * (2 ^ 7 * (adaZ A + 16) + 5 + 1) ≤
      (A.N + A.p + 16) * (2 ^ 7 * (adaZ A + 16) + 5 + 1) := Nat.mul_le_mul_right _ hP1
  have hPW2 : (A.N + A.p + 16) * (2 ^ 7 * (adaZ A + 16) + 5 + 1 + 1) ≤
      (A.N + A.p + 16) * (2 ^ 8 * (adaZ A + 16)) := Nat.mul_le_mul_left _ hW
  have hexp : (A.N + A.p + 16) * (2 ^ 7 * (adaZ A + 16) + 5 + 1 + 1) =
      (A.N + A.p + 16) * (2 ^ 7 * (adaZ A + 16) + 5 + 1) + (A.N + A.p + 16) := by ring
  have htA : 2 ^ 7 * tightA A = (A.N + A.p + 16) * (2 ^ 8 * (adaZ A + 16)) := by
    unfold tightA
    ring
  omega

set_option maxHeartbeats 1000000 in
/-- **Spec of `adaIvOuter`** (Idx 606) under the tight premise `TightM A M` (O2b family 5): two fresh
draws of kind `outTest`, then `outerReject` (`adaIvReject`) on a rejection. -/
theorem adaIvOuter_impl_t {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaEntryTable, prog[e.1]? = some e.2) (hmus : MusLib prog)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st2 : AdaState} (hok : AdaOK A st2)
    (hh : st2.halted = false) {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq)
    (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hMt : TightM A M) (hMq : 2 ^ 28 * Bq ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u]]
      body_adaIvOuter (fun r => Val.list [encCert r.1, adaEnc r.2])
      ((ivOuterD A st2 vals l u).toBits (adaDraw A)) := by
  rw [ivOuterD_toBits]
  have h607 : prog[Idx.adaIvReject]? = some body_adaIvReject :=
    hlib (Idx.adaIvReject, body_adaIvReject)
      (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))
  have h608 : prog[Idx.adaIvRound]? = some body_adaIvRound :=
    hlib (Idx.adaIvRound, body_adaIvRound)
      (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)))
  /- ### Sizes -/
  obtain ⟨hPub, hSt, hVals, hMz⟩ := ivT_facts hbs hT hok hv
  have hM : 2 ^ 8 * tightA A + 2 ^ 18 * (A.p + adaZ A + 16) ≤ M := hMt
  have hZ16 := sixteen_le_adaZ A
  have hqZ := qA_le_adaZ A
  have hPubM : valSize (adaPubEnc A) ≤ M := by omega
  have hStM : valSize (adaEnc st2) ≤ M := by omega
  have h3 : 3 ≤ M := by omega
  have hencQ : ∀ x : ℚ, bitLen x.num ≤ Bq ∧ bitLen (x.den : ℤ) ≤ Bq → valSize (encQ x) ≤ 2 * Bq + 5 := by
    intro x hx
    rw [valSize_encQ]
    have h1 : Nat.size x.num.natAbs ≤ Bq := hx.1
    have h2 : Nat.size x.den ≤ Bq := by have := hx.2; rwa [bitLen_natCast] at this
    omega
  have hlq := hencQ l hl
  have huq := hencQ u hu
  have hinpM : valSize (Val.list [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  set inp := Val.list [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u] with hinp
  /- ### Field access -/
  have hF : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u][n]? = some v →
      EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (EvalsVal.var henv) hinpM hget
  have hP : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      (pubFields A)[n]? = some v → EvalsVal prog M env [] (.inl (eAtN n (eAtN 0 (eV k)))) v :=
    fun henv hget => evalsVal_atN' (l := pubFields A) (hF henv rfl) hPubM hget
  have hStF : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      [encL (encL encZ) st2.scores, encL encN st2.T, encL encZ st2.thrInt, encZ st2.thrOut,
        encN st2.rej, encN st2.nInt, encN st2.nNum, encB st2.halted, encB st2.capAborted][n]? =
        some v → EvalsVal prog M env [] (.inl (eAtN n (eAtN 1 (eV k)))) v :=
    fun henv hget => evalsVal_atN' (l := [encL (encL encZ) st2.scores, encL encN st2.T,
      encL encZ st2.thrInt, encZ st2.thrOut, encN st2.rej, encN st2.nInt, encN st2.nNum,
      encB st2.halted, encB st2.capAborted]) (hF henv rfl) hStM hget
  /- ### The predictions -/
  have hscS : valSize (encL (encL encZ) st2.scores) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (l := [encL (encL encZ) st2.scores, encL encN st2.T,
      encL encZ st2.thrInt, encZ st2.thrOut, encN st2.rej, encN st2.nInt, encN st2.nNum,
      encB st2.halted, encB st2.capAborted]) (by simp)).le hSt
  have hargs1 : EvalsVal prog M [inp] [] (.inl (eList [eAtN 0 (eV 0), eAtN 0 (eAtN 1 (eV 0)),
      eAtN 2 (eV 0)])) (Val.list [adaPubEnc A, encL (encL encZ) st2.scores, encVals vals]) := by
    refine evalsVal_list (List.Forall₂.cons (hF rfl rfl) (List.Forall₂.cons (hStF rfl rfl)
      (List.Forall₂.cons (hF rfl rfl) List.Forall₂.nil))) ?_
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  refine iv_letE_det (evalsVal_call_det hmus.1 hargs1 (adaMusR_val_t hmus hbs hT hpos hok hv hMt)) ?_
  obtain ⟨r, rest, hmz⟩ : ∃ r rest, musZ A st2.scores vals = r :: rest :=
    List.exists_cons_of_length_pos (by rw [musZ_length]; omega)
  have hrbits := musZ_bits hok hv r (by rw [hmz]; exact List.mem_cons_self)
  obtain ⟨hD0, hμ⟩ := musZ_spec hok hv hpos 0 (by omega)
  rw [hmz] at hD0 hμ hMz
  simp only [List.getD_cons_zero] at hD0 hμ
  rw [hmz]
  /- ### The rounded endpoints -/
  have hround : ∀ {env : List Val} {k : ℕ} (x : ℚ) (n : ℕ), env[k]? = some inp →
      [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u][n]? = some (encQ x) →
      bitLen x.num ≤ Bq ∧ bitLen (x.den : ℤ) ≤ Bq →
      EvalsVal prog M env [] (.inl (eCall Idx.adaIvRound (ePair (eAtN n (eV k))
        (eAtN 8 (eAtN 0 (eV k)))))) (Val.int (roundIdxQ A.hA (clipQ (-1) 2 x))) := by
    intro env k x n henv hget hx
    have hxq := hencQ x hx
    have h2q : Nat.size (2 ^ A.qA) = A.qA + 1 := Nat.size_pow
    refine evalsVal_call_det h608 (EvalsVal.pair (hF henv hget) (hP henv rfl) ?_)
      (adaIvRound_val x A.qA hx (by omega))
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  refine iv_letE_det (hround l 3 rfl rfl hl) ?_
  refine iv_letE_det (hround u 4 rfl rfl hu) ?_
  /- ### The two directed noises -/
  have hdraw : ∀ κ, drawM A κ ≤ M := fun κ => by have := drawM_le A κ; omega
  have hKs : ∀ κ bits (z : ℤ), (adaDraw A κ).run bits = some (z, []) → |z| ≤ (maxKs A : ℤ) :=
    fun κ bits z h => (adaDraw_run_abs_le h).trans (by exact_mod_cast Ks_le_maxKs A κ)
  refine implements_letE_of (draw_impl hS (hF (k := 3) rfl rfl) hPubM NoiseKind.outTest (hdraw _))
    (fun k => |k| ≤ (maxKs A : ℤ)) (fun bits k h => hKs _ bits k h) ?_
  intro kH hkH
  refine implements_letE_of (draw_impl hS (hF (k := 4) rfl rfl) hPubM NoiseKind.outTest (hdraw _))
    (fun k => |k| ≤ (maxKs A : ℤ)) (fun bits k h => hKs _ bits k h) ?_
  intro kL hkL
  /- ### The tests -/
  set env5 : List Val := [encZ kL, encZ kH, Val.int (roundIdxQ A.hA (clipQ (-1) 2 u)),
    Val.int (roundIdxQ A.hA (clipQ (-1) 2 l)), encL encPZ (r :: rest), inp] with henv5
  have hq2M : valSize (encQ (A.a / 2)) ≤ M :=
    le_trans (valSize_lt_of_mem (l := pubFields A) (by simp [pubFields])).le hPubM
  have hm0M : valSize (encPZ r) ≤ M := by
    have := valSize_lt_of_mem (l := (r :: rest).map encPZ) List.mem_cons_self
    have h' : valSize (encL encPZ (r :: rest)) ≤ M := by omega
    exact le_trans this.le h'
  have anE : EvalsVal prog M env5 [] (.inl (eAtN 0 (eAtN 10 (eAtN 0 (eV 5)))))
      (Val.int (A.a / 2).num) :=
    evalsVal_atN' (l := [Val.int (A.a / 2).num, Val.int ((A.a / 2).den : ℤ)])
      (hP (k := 5) rfl rfl) hq2M rfl
  have adE : EvalsVal prog M env5 [] (.inl (eAtN 1 (eAtN 10 (eAtN 0 (eV 5)))))
      (Val.int ((A.a / 2).den : ℤ)) :=
    evalsVal_atN' (l := [Val.int (A.a / 2).num, Val.int ((A.a / 2).den : ℤ)])
      (hP (k := 5) rfl rfl) hq2M rfl
  have HE : EvalsVal prog M env5 [] (.inl (eAtN 8 (eAtN 0 (eV 5))))
      (Val.int ((2 ^ A.qA : ℕ) : ℤ)) := hP (k := 5) rfl rfl
  have thE : EvalsVal prog M env5 [] (.inl (eAtN 3 (eAtN 1 (eV 5)))) (Val.int st2.thrOut) :=
    hStF (k := 5) rfl rfl
  have m0E : EvalsVal prog M env5 [] (.inl (eHd (eV 4))) (encPZ r) :=
    EvalsVal.head (x := encPZ r) (l := rest.map encPZ) (EvalsVal.var rfl) hm0M
  have NE : EvalsVal prog M env5 [] (.inl (eAtN 0 (eHd (eV 4)))) (Val.int r.1) :=
    evalsVal_atN' (l := [Val.int r.1, Val.int r.2]) m0E hm0M rfl
  have DE : EvalsVal prog M env5 [] (.inl (eAtN 1 (eHd (eV 4)))) (Val.int r.2) :=
    evalsVal_atN' (l := [Val.int r.1, Val.int r.2]) m0E hm0M rfl
  have UE : EvalsVal prog M env5 [] (.inl (eV 2)) (Val.int (roundIdxQ A.hA (clipQ (-1) 2 u))) :=
    EvalsVal.var rfl
  have LrE : EvalsVal prog M env5 [] (.inl (eV 3)) (Val.int (roundIdxQ A.hA (clipQ (-1) 2 l))) :=
    EvalsVal.var rfl
  have kHE : EvalsVal prog M env5 [] (.inl (eV 1)) (Val.int kH) := EvalsVal.var rfl
  have kLE : EvalsVal prog M env5 [] (.inl (eV 0)) (Val.int kL) := EvalsVal.var rfl
  -- bit lengths
  have bAn : bitLen (A.a / 2).num ≤ adaZ A := size_a2num_le_adaZ A
  have bAd : bitLen ((A.a / 2).den : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]; exact size_a2den_le_adaZ A
  have bH : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ adaZ A + 1 := by
    rw [bitLen_natCast, Nat.size_pow]; omega
  have bTh : bitLen st2.thrOut ≤ adaZ A :=
    (bitLen_le_size_of_abs_le hok.thrOut_le).trans (size_maxKs_le_adaZ A)
  have bKH : bitLen kH ≤ adaZ A := (bitLen_le_size_of_abs_le hkH).trans (size_maxKs_le_adaZ A)
  have bKL : bitLen kL ≤ adaZ A := (bitLen_le_size_of_abs_le hkL).trans (size_maxKs_le_adaZ A)
  have bN : bitLen r.1 ≤ 2 ^ 6 * (adaZ A + 16) := hrbits.1
  have bD : bitLen r.2 ≤ 2 ^ 6 * (adaZ A + 16) := hrbits.2
  have bU : bitLen (roundIdxQ A.hA (clipQ (-1) 2 u)) ≤ A.qA + 2 := iv_bitLen_round_le A.qA u
  have bLr : bitLen (roundIdxQ A.hA (clipQ (-1) 2 l)) ≤ A.qA + 2 := iv_bitLen_round_le A.qA l
  have p1 := iv_bitLen_mul3 (A.a / 2).num ((2 ^ A.qA : ℕ) : ℤ) r.2
  have p2 := iv_bitLen_mul3 st2.thrOut ((A.a / 2).den : ℤ) r.2
  have p3 := iv_bitLen_mul3 r.1 ((A.a / 2).den : ℤ) ((2 ^ A.qA : ℕ) : ℤ)
  have p4 := iv_bitLen_mul3 (roundIdxQ A.hA (clipQ (-1) 2 u)) ((A.a / 2).den : ℤ) r.2
  have p5 := iv_bitLen_mul3 kH ((A.a / 2).den : ℤ) r.2
  have p6 := iv_bitLen_mul3 (roundIdxQ A.hA (clipQ (-1) 2 l)) ((A.a / 2).den : ℤ) r.2
  have p7 := iv_bitLen_mul3 kL ((A.a / 2).den : ℤ) r.2
  have s1 := iv_bitLen_sub (r.1 * ((A.a / 2).den : ℤ) * ((2 ^ A.qA : ℕ) : ℤ))
    (roundIdxQ A.hA (clipQ (-1) 2 u) * ((A.a / 2).den : ℤ) * r.2)
  have s2 := iv_bitLen_sub (roundIdxQ A.hA (clipQ (-1) 2 l) * ((A.a / 2).den : ℤ) * r.2)
    (r.1 * ((A.a / 2).den : ℤ) * ((2 ^ A.qA : ℕ) : ℤ))
  have hlhsE : EvalsVal prog M env5 [] (.inl ivLhs) (Val.int ((A.a / 2).num *
      ((2 ^ A.qA : ℕ) : ℤ) * r.2 + st2.thrOut * ((A.a / 2).den : ℤ) * r.2)) :=
    iv_add (iv_mul3 anE HE DE (by omega)) (iv_mul3 thE adE DE (by omega)) (by omega)
  have hrHE : EvalsVal prog M env5 [] (.inl ivRhsH) (Val.int (r.1 * ((A.a / 2).den : ℤ) *
      ((2 ^ A.qA : ℕ) : ℤ) - roundIdxQ A.hA (clipQ (-1) 2 u) * ((A.a / 2).den : ℤ) * r.2 +
      kH * ((A.a / 2).den : ℤ) * r.2)) :=
    iv_add (iv_sub (iv_mul3 NE adE HE (by omega)) (iv_mul3 UE adE DE (by omega)) (by omega))
      (iv_mul3 kHE adE DE (by omega)) (by omega)
  have hrLE : EvalsVal prog M env5 [] (.inl ivRhsL) (Val.int (roundIdxQ A.hA (clipQ (-1) 2 l) *
      ((A.a / 2).den : ℤ) * r.2 - r.1 * ((A.a / 2).den : ℤ) * ((2 ^ A.qA : ℕ) : ℤ) +
      kL * ((A.a / 2).den : ℤ) * r.2)) :=
    iv_add (iv_sub (iv_mul3 LrE adE DE (by omega)) (iv_mul3 NE adE HE (by omega)) (by omega))
      (iv_mul3 kLE adE DE (by omega)) (by omega)
  have hcH := EvalsVal.lt hrHE hlhsE (by omega)
  have hcL := EvalsVal.lt hrLE hlhsE (by omega)
  -- the tests in integers
  have haH : A.a / 2 = ((A.a / 2).num : ℚ) / (((A.a / 2).den : ℤ) : ℚ) := by
    rw [Int.cast_natCast, Rat.num_div_den]
  have hhA : A.hA = 1 / (((2 ^ A.qA : ℕ) : ℤ) : ℚ) := by
    show (1 / 2 : ℚ) ^ A.qA = _
    push_cast
    rw [one_div_pow]
  have had0 : (0 : ℤ) < ((A.a / 2).den : ℤ) := by exact_mod_cast (A.a / 2).den_pos
  have hH0 : (0 : ℤ) < ((2 ^ A.qA : ℕ) : ℤ) := by exact_mod_cast Nat.two_pow_pos A.qA
  have hiffH := (iv_test_iff (th := st2.thrOut) (U := roundIdxQ A.hA (clipQ (-1) 2 u)) (k := kH)
    haH hhA hμ.symm had0 hH0 hD0).1
  have hiffL := (iv_test_iff (th := st2.thrOut) (U := roundIdxQ A.hA (clipQ (-1) 2 l)) (k := kL)
    haH hhA hμ.symm had0 hH0 hD0).2
  have hargsR : ∀ b : Bool, EvalsVal prog M env5 [] (.inl (eList [eAtN 0 (eV 5), eAtN 1 (eV 5),
      eLit (if b then 1 else 0)])) (Val.list [adaPubEnc A, adaEnc st2, encB b]) := by
    intro b
    refine evalsVal_list (List.Forall₂.cons (hF rfl rfl) (List.Forall₂.cons (hF rfl rfl)
      (List.Forall₂.cons (EvalsVal.lit (by
        have := valSize_encB_le b
        simp only [encB] at this
        omega) : EvalsVal prog M env5 [] (.inl (eLit (if b then 1 else 0))) (encB b))
        List.Forall₂.nil))) ?_
    have := valSize_encB_le b
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  split_ifs with hHigh hLow
  · -- HIGH
    refine ap_implements_ite_false hcH (if_neg (not_lt.mpr (hiffH.mp hHigh))) ?_
    exact implements_call_det h607 (hargsR true) (adaIvReject_impl_t hS hL hbs hT hok hh true hMt)
  · -- LOW
    refine ap_implements_ite_true hcH (by
      rw [if_pos (lt_of_not_ge (fun h => hHigh (hiffH.mpr h)))]; exact one_ne_zero) ?_
    refine ap_implements_ite_false hcL (if_neg (not_lt.mpr (hiffL.mp hLow))) ?_
    exact implements_call_det h607 (hargsR false) (adaIvReject_impl_t hS hL hbs hT hok hh false hMt)
  · -- ACCEPT
    refine ap_implements_ite_true hcH (by
      rw [if_pos (lt_of_not_ge (fun h => hHigh (hiffH.mpr h)))]; exact one_ne_zero) ?_
    refine ap_implements_ite_true hcL (by
      rw [if_pos (lt_of_not_ge (fun h => hLow (hiffL.mpr h)))]; exact one_ne_zero) ?_
    apply Implements.of_det
    show EvalsVal prog M env5 [] (.inl (ePair (eLit 0) (eAtN 1 (eV 5))))
      (Val.list [Val.int 0, adaEnc st2])
    refine EvalsVal.pair (ap_lit_small (by decide) h3) (hF rfl rfl) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : bitLen (0 : ℤ) = 0 := by decide
    omega

/-- Check: the old statement `adaIvOuter_impl` is the corollary via `TightM.of_old` (re-derived in place at
swap-in). -/
example {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaEntryTable, prog[e.1]? = some e.2) (hmus : MusLib prog)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st2 : AdaState} (hok : AdaOK A st2)
    (hh : st2.halted = false) {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq)
    (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) (hMq : 2 ^ 28 * Bq ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u]]
      body_adaIvOuter (fun r => Val.list [encCert r.1, adaEnc r.2])
      ((ivOuterD A st2 vals l u).toBits (adaDraw A)) :=
  adaIvOuter_impl_t hlib hmus hS hL hbs hT hpos hok hh hv hl hu (TightM.of_old hM) hMq

end F2e2e.C.Impl
