import F2e2e.BSpace.PubBound
import F2e2e.C.Impl.AdaBounds

/-!
# O2b family 4 (W2, a2ff64c3, for 17fc0802): the parameter record on the tight scale
Promoted from Scratch/O2T/PubTight.lean (owner W2 a2ff64c3) at 14:28Z; statements unchanged.

Family 4 (the parameter record, Idx 600/604/605) uses no `adaBoundA` premise: its value bound is its own
`bsPubBound Mc J R eA eXi = 2^20 · L²` with `L = bsPubL Mc J R eA eXi = eA + eXi + ⌈log₂(Mc+J+R+2)⌉ + 100`
(`F2e2e/BSpace/Pub.lean`). This file places that bound on B-ACC's tight scale
(`F2e2e/C/Impl/AdaBounds.lean`, O2b family 1), for `A = adaParams eA eXi Mc J R` and with no hypotheses:

* `bsPubBound_le_tightA : bsPubBound Mc J R eA eXi ≤ tightA A` (margin about `2^9`);
* `bsPubBound_le_tight : bsPubBound Mc J R eA eXi ≤ 2^8 · tightA A` (the form requested by the O2b lead);
* `bsPubBound_le_of_tightM : TightM A M → bsPubBound Mc J R eA eXi ≤ M` (so `TightM` replaces `hMP`).

Proof: `L ≤ adaZ A + 54 ≤ 4 (adaZ A + 16)` (W3's `bsB_L_le_adaZ`) and `2^30 · L ≤ N` (`bsPT_L_le_N`), since
`N ≥ n_0 ≥ 2^12 · χ · hInv² ≥ 2^32 · χ` (`hInv = 512 · p · 2^{eA} ≥ 2^10`, `p ≥ 2`) and
`L ≤ χ + 51 ≤ 3 χ` (`χ = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉ ≥ 49`, `p(p+1)Q ≥ Mc+J+R+2`). Hence
`2^20 L² ≤ 2^22 (adaZ A + 16) · L ≤ N (adaZ A + 16) ≤ tightA A`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.C.Impl F2e2e.C.Impl.AP

/-- `2^30 · L ≤ N` for the actual parameters (`N ≥ n_0 ≥ 2^32 χ` and `L ≤ χ + 51 ≤ 3 χ`). -/
theorem bsPT_L_le_N (Mc J R eA eXi : ℕ) :
    2 ^ 30 * bsPubL Mc J R eA eXi ≤ (adaParams eA eXi Mc J R).N := by
  have hp := two_le_adaP eA
  have hQ : Mc + J + R + 2 ≤ adaQ Mc J R eA := by
    unfold adaQ
    calc Mc + J + R + 2 ≤ Mc + R + J + 2 + (adaTmaxList eA).sum := by omega
      _ ≤ 100 * (adaP eA + 1) * (Mc + R + J + 2 + (adaTmaxList eA).sum) :=
        Nat.le_mul_of_pos_left _ (by omega)
  have hpQ : adaQ Mc J R eA ≤ adaP eA * (adaP eA + 1) * adaQ Mc J R eA :=
    Nat.le_mul_of_pos_left _ (Nat.mul_pos (by omega) (by omega))
  have hcl : Nat.clog 2 (Mc + J + R + 2) ≤
      Nat.clog 2 (adaP eA * (adaP eA + 1) * adaQ Mc J R eA) :=
    Nat.clog_mono_right 2 (hQ.trans hpQ)
  have hchi : bsPubL Mc J R eA eXi ≤ adaChi Mc J R eA eXi + 51 := by
    unfold bsPubL adaChi
    omega
  have hchi49 : 49 ≤ adaChi Mc J R eA eXi := by
    unfold adaChi
    omega
  have hL3 : bsPubL Mc J R eA eXi ≤ 3 * adaChi Mc J R eA eXi := by omega
  have hH : 2 ^ 10 ≤ adaHInv eA := by
    unfold adaHInv
    have h1 : 1 ≤ 2 ^ eA := Nat.one_le_two_pow
    calc 2 ^ 10 = 512 * 2 * 1 := by norm_num
      _ ≤ 512 * adaP eA * 2 ^ eA := Nat.mul_le_mul (Nat.mul_le_mul_left _ hp) h1
  have hH2 : 2 ^ 20 ≤ adaHInv eA ^ 2 := by
    calc 2 ^ 20 = (2 ^ 10) ^ 2 := by norm_num
      _ ≤ adaHInv eA ^ 2 := Nat.pow_le_pow_left hH 2
  have hn0 : 2 ^ 32 * adaChi Mc J R eA eXi ≤ adaNBlock Mc J R eA eXi 0 := by
    unfold adaNBlock
    calc 2 ^ 32 * adaChi Mc J R eA eXi = 2 ^ 12 * adaChi Mc J R eA eXi * 2 ^ 20 := by ring
      _ ≤ 2 ^ 12 * adaChi Mc J R eA eXi * adaHInv eA ^ 2 := Nat.mul_le_mul_left _ hH2
      _ ≤ _ := Nat.le_add_left _ _
  have hmem : adaNBlock Mc J R eA eXi 0 ∈ adaBlockSizes Mc J R eA eXi := by
    unfold adaBlockSizes
    exact List.mem_map.mpr ⟨0, List.mem_range.mpr (by omega), rfl⟩
  have hsum : adaNBlock Mc J R eA eXi 0 ≤ (adaBlockSizes Mc J R eA eXi).sum :=
    List.le_sum_of_mem hmem
  show 2 ^ 30 * bsPubL Mc J R eA eXi ≤ (adaBlockSizes Mc J R eA eXi).sum
  calc 2 ^ 30 * bsPubL Mc J R eA eXi ≤ 2 ^ 30 * (3 * adaChi Mc J R eA eXi) :=
        Nat.mul_le_mul_left _ hL3
    _ = (2 ^ 30 * 3) * adaChi Mc J R eA eXi := (Nat.mul_assoc _ _ _).symm
    _ ≤ 2 ^ 32 * adaChi Mc J R eA eXi := Nat.mul_le_mul_right _ (by norm_num)
    _ ≤ adaNBlock Mc J R eA eXi 0 := hn0
    _ ≤ _ := hsum

/-- **The parameter record's bound is below the tight scale**: `bsPubBound Mc J R eA eXi ≤ tightA A` for
`A = adaParams eA eXi Mc J R` (no hypotheses; margin about `2^9`). -/
theorem bsPubBound_le_tightA (Mc J R eA eXi : ℕ) :
    bsPubBound Mc J R eA eXi ≤ tightA (adaParams eA eXi Mc J R) := by
  have hZ := bsB_L_le_adaZ Mc J R eA eXi
  have hN := bsPT_L_le_N Mc J R eA eXi
  show 2 ^ 20 * bsPubL Mc J R eA eXi ^ 2 ≤ _
  unfold tightA
  generalize bsPubL Mc J R eA eXi = L at hZ hN ⊢
  generalize adaZ (adaParams eA eXi Mc J R) = Z at hZ ⊢
  generalize (adaParams eA eXi Mc J R).N = N at hN ⊢
  generalize (adaParams eA eXi Mc J R).p = p
  have h1 : L ≤ 4 * (Z + 16) := by omega
  calc 2 ^ 20 * L ^ 2 = 2 ^ 20 * L * L := by ring
    _ ≤ 2 ^ 20 * L * (4 * (Z + 16)) := Nat.mul_le_mul_left _ h1
    _ = 2 ^ 22 * L * (Z + 16) := by ring
    _ ≤ 2 ^ 30 * L * (Z + 16) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num))
    _ ≤ N * (Z + 16) := Nat.mul_le_mul_right _ hN
    _ ≤ 2 * (N + p + 16) * (Z + 16) := Nat.mul_le_mul_right _ (by omega)

/-- **O2b family 4, the tightA-scale record bound**: `bsPubBound Mc J R eA eXi ≤ 2^8 · tightA A` for
`A = adaParams eA eXi Mc J R` (no hypotheses). -/
theorem bsPubBound_le_tight (Mc J R eA eXi : ℕ) :
    bsPubBound Mc J R eA eXi ≤ 2 ^ 8 * tightA (adaParams eA eXi Mc J R) :=
  (bsPubBound_le_tightA Mc J R eA eXi).trans (Nat.le_mul_of_pos_left _ (by positivity))

/-- The tight premise covers the record: `TightM A M → bsPubBound Mc J R eA eXi ≤ M`
(`A = adaParams eA eXi Mc J R`), so `TightM` can replace the separate premise `hMP : bsPubBound … ≤ M`. -/
theorem bsPubBound_le_of_tightM {Mc J R eA eXi M : ℕ}
    (hMt : TightM (adaParams eA eXi Mc J R) M) : bsPubBound Mc J R eA eXi ≤ M :=
  (bsPubBound_le_tight Mc J R eA eXi).trans ((Nat.le_add_right _ _).trans hMt)

end F2e2e.BSpace
