import F2e2e.C.Impl.AdaPrepCorrMain
import F2e2e.C.Impl.AdaBounds

/-!
# SCRATCH (O2b family 9, owner 295bf129): `AdaPrepCorrMain` under the tight value premise `TightM`
Promoted from Scratch/O2T/AdaPrepCorrMainT.lean (owner 295bf129) at 14:28Z; statements unchanged.

Delta file for `F2e2e/C/Impl/AdaPrepCorrMain.lean` (B-NUM's assembly of a correction `adaCorr`, Idx 702).
It imports the original module and adds only the tight lemmas (17fc0802's pattern; `TightM`, `tightA`, `cAddA`
and the tight size lemmas are B-ACC's, adopted into `F2e2e/C/Impl/AdaBounds.lean` by W4):
* `cm_bound_t`: the N-free scalar bound `2^14 (p + adaZ + 16)` of `cm_bound` (L55) is covered by the additive
  term `cAddA A = 2^18 (p + adaZ + 16)` (against `c · tightA A` alone it fails for small `N` and `p`); the
  proofs below only need `thirtytwo_le_tightA`;
* `valSize_corrIn_le_t` (`≤ 4 · tightA A`), `valSize_redrawIn_le_t` (`≤ 3 · tightA A`): the input sizes;
* `adaCorr_of_parts_t`: `adaCorr_of_parts` with `(hMt : TightM A M)` for `(hM : 2 ^ 32 * adaBoundA A ≤ M)`
  (the proof needs only `4 · tightA A ≤ M`); the parts' hypotheses `hdet`/`hred` are at the same `M`.

At integration (after O1) these move into `AdaPrepCorrMain.lean` and the old lemma becomes
`adaCorr_of_parts … hM … := adaCorr_of_parts_t … (TightM.of_old hM) …` (checked by the `example` at the end).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- **The N-free scalar bound, tight form**: `2^14 (p + adaZ + 16)` is covered by the additive term
`cAddA A = 2^18 (p + adaZ + 16)` of the tight premise. -/
theorem cm_bound_t (A : AdaParams) : 2 ^ 14 * (A.p + adaZ A + 16) ≤ cAddA A := by
  unfold cAddA
  omega

/-- The size of the input of `adaCorr`, at the tight scale: `≤ 4 · tightA A`. -/
theorem valSize_corrIn_le_t {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (q : Bool) :
    valSize (corrIn A st vals j q) ≤ 4 * tightA A := by
  have hPub := valSize_adaPubEnc_le_t A hbs hT
  have hSt := valSize_adaEnc_le_t hok
  have hVals := valSize_encVals_le_t hbs hv.1 hv.2
  have hB := thirtytwo_le_tightA A
  have hjS : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have hsg := cm_bitLen_avSign_le q
  unfold corrIn
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
  omega

/-- The size of the input of `adaRedraw`, at the tight scale: `≤ 3 · tightA A`. -/
theorem valSize_redrawIn_le_t {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {j : ℕ} (hj : j < A.p) :
    valSize (redrawIn A j st.thrInt) ≤ 3 * tightA A := by
  have hPub := valSize_adaPubEnc_le_t A hbs hT
  have hSt := valSize_adaEnc_le_t hok
  have hB := thirtytwo_le_tightA A
  have hjS : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have hthrS : valSize (encL encZ st.thrInt) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (l := [encL (encL encZ) st.scores, encL encN st.T,
      encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
      encB st.halted, encB st.capAborted]) (by simp)).le hSt
  unfold redrawIn
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

section Main

variable {prog : List Expr} {M : ℕ}

/-- **`adaCorr` from its two parts, under the tight value premise** `TightM A M`. If routine 705 evaluates
(deterministically) the new scores and counters `[scores', T']` on `corrIn A st vals j q`, and routine 706
implements the threshold redraws on `redrawIn A j st.thrInt`, then `body_adaCorrMain` implements the
correction `applyCorrection A st vals j q` (in fresh bits) with the state encoding `adaEnc`. -/
theorem adaCorr_of_parts_t {A : AdaParams} {st : AdaState} {vals : List (List ℕ)} {j : ℕ} {q : Bool}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) (hok : AdaOK A st)
    (hv : ValsOKA A vals) (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0)
    (hMt : TightM A M) {bDet bRed : Expr}
    (hdetL : prog[Idx.adaCorrDet]? = some bDet) (hredL : prog[Idx.adaRedraw]? = some bRed)
    (hdet : EvalsVal prog M [corrIn A st vals j q] [] (.inl bDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]))
    (hred : Implements prog M [redrawIn A j st.thrInt] bRed (encL encZ)
      ((redrawThresholds A (reopenEdges A j) st.thrInt).toBits (adaDraw A))) :
    Implements prog M [corrIn A st vals j q] body_adaCorrMain adaEnc
      ((applyCorrection A st vals j q).toBits (adaDraw A)) := by
  rw [applyCorrection_toBits]
  have hM := hMt
  unfold TightM at hM
  have hSt := valSize_adaEnc_le_t hok
  have hxM : valSize (corrIn A st vals j q) ≤ M := by
    have := valSize_corrIn_le_t hbs hT hok hv hj q
    omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hrM : valSize (redrawIn A j st.thrInt) ≤ M := by
    have := valSize_redrawIn_le_t hbs hT hok hj
    omega
  -- the deterministic part (705)
  have hdvM : valSize (Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))]) ≤ M := by
    have hokD := avState_ok hok vals q hj hTj hok.thr_len hok.thr_le
    have hS' := valSize_adaEnc_le_t hokD
    have hle : valSize (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) ≤
        valSize (adaEnc (avState A st vals j q st.thrInt)) := by
      simp only [adaEnc, avState, valSize_list, listSize_cons, listSize_nil]
      omega
    omega
  have hd : EvalsVal prog M [corrIn A st vals j q] [] (.inl (eCall Idx.adaCorrDet (eV 0)))
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) :=
    evalsVal_call_det hdetL EvalsVal.var0 hdet
  unfold body_adaCorrMain
  refine cm_implements_letE_det hd ?_
  -- the redraws (706)
  have hargs : EvalsVal prog M [Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
      (.inl (eList [eAtN 0 (eV 1), eAtN 2 (eAtN 2 (eV 1)), eAtN 3 (eV 1)]))
      (redrawIn A j st.thrInt) := by
    have hstE : EvalsVal prog M [Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
        (.inl (eAtN 2 (eV 1))) (adaEnc st) :=
      evalsVal_atN' (n := 2) EvalsVal.var1 hxM rfl
    exact evalsVal_list (List.Forall₂.cons (evalsVal_atN' (n := 0) EvalsVal.var1 hxM rfl)
      (List.Forall₂.cons (evalsVal_atN' (n := 2) hstE hstM rfl)
      (List.Forall₂.cons (evalsVal_atN' (n := 3) EvalsVal.var1 hxM rfl) List.Forall₂.nil))) hrM
  refine implements_letE_of (implements_call_det hredL hargs hred)
    (fun t => t.length = A.p ∧ ∀ z ∈ t, adaKB A z) (fun bits t h => ?_) ?_
  · have hall := DAlw.toBits (adaDraw_adaKB A)
      (redrawThresholds_ok A (reopenEdges A j) st.thrInt hok.thr_le)
    obtain ⟨h1, h2⟩ := Always.of_run hall h
    exact ⟨h1.trans hok.thr_len, h2⟩
  rintro t ⟨htl, htK⟩
  apply Implements.of_det
  have hok' := avState_ok hok vals q hj hTj htl htK
  have hS' := valSize_adaEnc_le_t hok'
  have hstE : EvalsVal prog M [encL encZ t, Val.list [encL (encL encZ) (avScores A st vals j q),
      encL encN (st.T.set j (st.T.getD j 0 + 1))], corrIn A st vals j q] []
      (.inl (eAtN 2 (eV 2))) (adaEnc st) :=
    evalsVal_atN' (n := 2) EvalsVal.var2 hxM rfl
  refine evalsVal_list (List.Forall₂.cons (evalsVal_atN' (n := 0) EvalsVal.var1 hdvM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 1) EvalsVal.var1 hdvM rfl)
    (List.Forall₂.cons EvalsVal.var0
    (List.Forall₂.cons (evalsVal_atN' (n := 3) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 4) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 5) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 6) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 7) hstE hstM rfl)
    (List.Forall₂.cons (evalsVal_atN' (n := 8) hstE hstM rfl) List.Forall₂.nil))))))))) ?_
  exact le_trans hS' (by omega)

/-- Integration check: the old `adaCorr_of_parts` (exact statement) is a corollary via `TightM.of_old`. -/
example {A : AdaParams} {st : AdaState} {vals : List (List ℕ)} {j : ℕ} {q : Bool}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) (hok : AdaOK A st)
    (hv : ValsOKA A vals) (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) {bDet bRed : Expr}
    (hdetL : prog[Idx.adaCorrDet]? = some bDet) (hredL : prog[Idx.adaRedraw]? = some bRed)
    (hdet : EvalsVal prog M [corrIn A st vals j q] [] (.inl bDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]))
    (hred : Implements prog M [redrawIn A j st.thrInt] bRed (encL encZ)
      ((redrawThresholds A (reopenEdges A j) st.thrInt).toBits (adaDraw A))) :
    Implements prog M [corrIn A st vals j q] body_adaCorrMain adaEnc
      ((applyCorrection A st vals j q).toBits (adaDraw A)) :=
  adaCorr_of_parts_t hbs hT hok hv hj hTj (TightM.of_old hM) hdetL hredL hdet hred

end Main

end F2e2e.C.Impl
