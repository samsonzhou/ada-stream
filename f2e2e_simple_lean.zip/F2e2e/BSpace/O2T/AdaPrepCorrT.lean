import F2e2e.C.Impl.AdaPrepCorr
import F2e2e.BSpace.O2T.AdaPrepCorrMainT
import F2e2e.BSpace.O2T.AdaPrepCorrPartsT

/-!
# SCRATCH (O2b family 9, owner 295bf129): `adaCorr_impl` under the tight value premise `TightM`
Promoted from Scratch/O2T/AdaPrepCorrT.lean (owner 295bf129) at 14:30Z; statements unchanged.

Delta file for `F2e2e/C/Impl/AdaPrepCorr.lean` (the frozen contract `adaCorr_impl` of a correction, Idx 702,
called by `AdaPrepScan.lean`). It imports the original module and adds only
* `adaCorr_impl_t`: `adaCorr_impl` with `(hMt : TightM A M)` for `(hM : 2 ^ 32 * adaBoundA A ≤ M)` (same
  binders otherwise), composed from `adaCorr_of_parts_t` (`AdaPrepCorrMainT.lean`) and B-ARCH's parts
  `adaCorrDet_val_t`, `adaRedraw_impl_t` (`AdaPrepCorrPartsT.lean`).

At integration (after O1) it moves into `AdaPrepCorr.lean` and the frozen contract becomes
`adaCorr_impl … hM := adaCorr_impl_t … (TightM.of_old hM)` (checked by the `example` at the end).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- **Spec of `adaCorr`, under the tight value premise** `TightM A M`. -/
theorem adaCorr_impl_t {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaCorrTable, prog[e.1]? = some e.2)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool)
    (hMt : TightM A M) :
    Implements prog M [Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]]
      body_adaCorr adaEnc ((applyCorrection A st vals j q).toBits (adaDraw A)) := by
  have h705 : prog[Idx.adaCorrDet]? = some body_adaCorrDet :=
    hlib (Idx.adaCorrDet, body_adaCorrDet) (by simp [adaCorrTable])
  have h706 : prog[Idx.adaRedraw]? = some body_adaRedraw :=
    hlib (Idx.adaRedraw, body_adaRedraw) (by simp [adaCorrTable])
  have hlc : prog[Idx.linComb]? = some body_linComb :=
    hlib (Idx.linComb, body_linComb) (by simp [adaCorrTable])
  have hlcs : prog[Idx.linCombStep]? = some body_linCombStep :=
    hlib (Idx.linCombStep, body_linCombStep) (by simp [adaCorrTable])
  exact adaCorr_of_parts_t hbs hT hok hv hj hTj hMt h705 h706
    (adaCorrDet_val_t hL hlc hlcs hbs hT hok hv hj hTj q hMt)
    (adaRedraw_impl_t hS hL hbs hT hj ⟨hok.thr_len, hok.thr_le⟩ hMt)

/-- Integration check: the frozen contract `adaCorr_impl` (exact statement) is a corollary via
`TightM.of_old`. -/
example {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaCorrTable, prog[e.1]? = some e.2)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p) (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]]
      body_adaCorr adaEnc ((applyCorrection A st vals j q).toBits (adaDraw A)) :=
  adaCorr_impl_t hlib hS hL hbs hT hok hv hj hTj q (TightM.of_old hM)

end F2e2e.C.Impl
