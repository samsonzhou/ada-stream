import F2e2e.C.Impl.AdaPrep
import F2e2e.C.Impl.AdaBounds
import F2e2e.BSpace.O2T.AdaMusT
import F2e2e.BSpace.O2T.AdaPrepScanT

/-!
# SCRATCH (O2b family 8, `AdaPrep`; A-VAL 914e80f8, for the O2b tech lead 17fc0802): `PrepareRoot` under `TightM`
Promoted from Scratch/O2T/AdaPrepT.lean (owner A-VAL 914e80f8) at 14:30Z; statements unchanged.

A DELTA file (not a copy; `AdaPrep` is imported through the originals elsewhere): it imports
`F2e2e/C/Impl/AdaPrep.lean` and adds only the tight forms, by the callee rule (exact statement, with
`(hM : 2 ^ 32 * adaBoundA A ≤ M)` replaced by `(hMt : TightM A M)`):
* `passStep_impl_t` (`passStep_impl`, Idx 704) and `adaPrep_impl_t` (`adaPrep_impl`, Idx 700);
* the size fact `valSize_musZ_le_t` (the predictions are below `2^7 · tightA A`);
* `passStep_impl_of_t`, `adaPrep_impl_of_t`: the old statements as corollaries via `TightM.of_old` (the
  integration form of the old lemmas).

Callees (callee rule): `adaMusR_val_t` (A-ARCH's `F2e2e/Scratch/O2T/AdaMusT.lean`) and `scanLoop_impl_t`
(C-PROB's family 8, `F2e2e/Scratch/O2T/AdaPrepScanT.lean`).

Proof: W4/B-NUM's proofs of `AdaPrep.lean` with the tight sizes `valSize_adaPubEnc_le_t`, `valSize_adaEnc_le_t`,
`valSize_encVals_le_t` (`≤ tightA A`, `TightDefs`) and `valSize_musZ_le_t`; every environment value is then
below `2^7 · tightA A + 3 · tightA A + O(p)`, hence below `2^8 · tightA A ≤ M`. The scan accumulator is measured
directly (the uniform `valSize_scanEnc_le` would cost `5 · 2^7 · tightA A`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- **The predictions are below `2^7 · tightA A`** (`p + 1` pairs of bit length `≤ 2^6 (adaZ A + 16)`). -/
theorem valSize_musZ_le_t {A : AdaParams} {st : AdaState} (hok : AdaOK A st) {vals : List (List ℕ)}
    (hv : ValsOKA A vals) : valSize (encL encPZ (musZ A st.scores vals)) ≤ 2 ^ 7 * tightA A := by
  have hZ16 := sixteen_le_adaZ A
  have hbits := musZ_bits hok hv
  have h1 := valSize_encL_le encPZ (musZ A st.scores vals) (2 ^ 7 * (adaZ A + 16) + 5) (by
    intro r hr
    obtain ⟨a, b⟩ := r
    rw [valSize_encPZ]
    have := hbits (a, b) hr
    simp only at this
    omega)
  rw [musZ_length] at h1
  have h3 : (A.p + 1) * (2 ^ 7 * (adaZ A + 16) + 5 + 1) ≤ (A.p + 1) * (2 ^ 8 * (adaZ A + 16)) :=
    Nat.mul_le_mul_left _ (by omega)
  have h4 : (A.p + 2) * (2 ^ 8 * (adaZ A + 16)) ≤ (A.N + A.p + 16) * (2 ^ 8 * (adaZ A + 16)) :=
    Nat.mul_le_mul_right _ (by omega)
  have e1 : (A.p + 2) * (2 ^ 8 * (adaZ A + 16)) =
      (A.p + 1) * (2 ^ 8 * (adaZ A + 16)) + 2 ^ 8 * (adaZ A + 16) := by ring
  have e2 : 2 ^ 7 * tightA A = (A.N + A.p + 16) * (2 ^ 8 * (adaZ A + 16)) := by
    unfold tightA
    ring
  omega

section PrepT

variable {prog : List Expr} {M : ℕ}

/-- **The pass step implements one iteration of `PrepareRoot`** (tight value premise). -/
theorem passStep_impl_t (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) (hmus : MusLib prog)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M)
    (s : ℕ × AdaState × List Bool) (hs : PrepInv A s) :
    Implements prog M [prepEnc A vals s] body_adaPassStep (loopEnc (prepEnc A vals) encOptSt)
      (prepQ A vals s) := by
  obtain ⟨f, st, cache⟩ := s
  obtain ⟨hok, hcl, hf⟩ := hs
  simp only at hok hcl hf
  -- tight sizes: every value is below `tightA A` (the predictions below `2^7 · tightA A`)
  have hM : 2 ^ 8 * tightA A + 2 ^ 18 * (A.p + adaZ A + 16) ≤ M := hMt
  have hPub := valSize_adaPubEnc_le_t A hbs hT
  have hSt := valSize_adaEnc_le_t hok
  have hVals := valSize_encVals_le_t hbs hv.1 hv.2
  have hMz := valSize_musZ_le_t hok hv
  have hZ16 := sixteen_le_adaZ A
  have hT32 := thirtytwo_le_tightA A
  have hp16 : 8 * (A.p + 16) ≤ tightA A := by omega
  have h3 : 3 ≤ M := by omega
  have hsf : Nat.size f ≤ tightA A := by
    have := Nat.size_le_size hf
    have := size_fuel_le_adaZ A
    omega
  have hacc5 := valSize_prepEnc_le (vals := vals) hsf hcl hPub hSt hVals hp16
  have haccM : valSize (prepEnc A vals (f, st, cache)) ≤ M := by omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  set acc := prepEnc A vals (f, st, cache) with hacc
  have hfield : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some acc →
      [encN f, adaEnc st, encL encB cache, adaPubEnc A, encVals vals][n]? = some v →
      EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (EvalsVal.var henv) haccM hget
  have hfE : EvalsVal prog M [acc] [] (.inl (eAtN 0 (eV 0))) (encN f) := hfield rfl rfl
  unfold body_adaPassStep prepQ
  cases f with
  | zero =>
    dsimp only
    have hcz := EvalsVal.eq hfE (ap_lit_small (z := 0) (by decide) h3) (by omega)
    rw [if_pos (by rfl)] at hcz
    refine ap_implements_ite_true hcz one_ne_zero ?_
    apply Implements.of_det
    refine EvalsVal.pair (ap_lit_small (by decide) h3) (EvalsVal.nil (by simp; omega)) ?_
    show valSize (Val.list [Val.int 0, Val.list []]) ≤ M
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : bitLen (0 : ℤ) = 0 := by decide
    omega
  | succ f =>
    dsimp only
    have hcz := EvalsVal.eq hfE (ap_lit_small (z := 0) (by decide) h3) (by omega)
    rw [if_neg (by push_cast; omega)] at hcz
    refine ap_implements_ite_false hcz rfl ?_
    -- the predictions
    set mz := musZ A st.scores vals with hmz
    have hscE : EvalsVal prog M [acc] [] (.inl (eAtN 0 (eAtN 1 (eV 0)))) (encL (encL encZ) st.scores) :=
      evalsVal_atN' (hfield (n := 1) rfl rfl) hstM rfl
    have hmusArgs : EvalsVal prog M [acc] [] (.inl (eList [eAtN 3 (eV 0), eAtN 0 (eAtN 1 (eV 0)),
        eAtN 4 (eV 0)])) (Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]) := by
      have hscS : valSize (encL (encL encZ) st.scores) ≤ tightA A :=
        le_trans (valSize_lt_of_mem (l := [encL (encL encZ) st.scores, encL encN st.T,
          encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
          encB st.halted, encB st.capAborted]) (by simp)).le hSt
      refine evalsVal_list (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons hscE
        (List.Forall₂.cons (hfield rfl rfl) List.Forall₂.nil))) ?_
      rw [ap_valSize_list3]
      omega
    have hmusE : EvalsVal prog M [acc] [] (.inl (eCall Idx.adaMusR (eList [eAtN 3 (eV 0),
        eAtN 0 (eAtN 1 (eV 0)), eAtN 4 (eV 0)]))) (encL encPZ mz) :=
      evalsVal_call_det hmus.1 hmusArgs (adaMusR_val_t hmus hbs hT hpos hok hv hMt)
    refine ap_implements_letE_det hmusE ?_
    -- the scan pass
    have hmzM : valSize (encL encPZ mz) ≤ M := by omega
    have hinit : EvalsVal prog M [encL encPZ mz, acc] [] (.inl (eList [eLit 0, eAtN 1 (eV 1),
        eAtN 2 (eV 1), eAtN 3 (eV 1), eAtN 4 (eV 1), eV 0])) (scanEnc A vals mz (0, st, cache)) := by
      have hcS := ap_valSize_encL_encB cache
      rw [hcl] at hcS
      have h5 : valSize (scanEnc A vals mz (0, st, cache)) ≤ 2 ^ 7 * tightA A + 3 * tightA A +
          3 * A.p + 16 := by
        simp only [scanEnc, valSize_list, listSize_cons, listSize_nil, valSize_encN, Nat.size_zero]
        omega
      refine evalsVal_list (List.Forall₂.cons (ap_lit_small (z := 0) (by decide) h3)
        (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons (hfield rfl rfl)
        (List.Forall₂.cons (hfield rfl rfl) (List.Forall₂.cons (hfield rfl rfl)
        (List.Forall₂.cons EvalsVal.var0 List.Forall₂.nil)))))) ?_
      show valSize (scanEnc A vals mz (0, st, cache)) ≤ M
      omega
    have hscan := scanLoop_impl_t (scanLib_of_table hlib) hS hL hbs hT hpos hok hv hMt hcl hinit
    show Implements prog M [encL encPZ mz, acc] _ (loopEnc (prepEnc A vals) encOptSt)
      ((scanRef A vals (adaMus A st vals) (0, st, cache)).bind fun r =>
        BitProg.pure (passOutcome f r))
    refine implements_letE_of hscan (fun r => AdaOK A r.2.1 ∧ r.2.2.length = A.p)
      (fun bits r h => Always.of_run (scanRef_always vals _ hok hcl) h) ?_
    rintro ⟨o, st1, c1⟩ ⟨hok1, hc1⟩
    replace hok1 : AdaOK A st1 := hok1
    replace hc1 : c1.length = A.p := hc1
    apply Implements.of_det
    have hSt1 := valSize_adaEnc_le_t hok1
    have hc1S := ap_valSize_encL_encB c1
    rw [hc1] at hc1S
    have houtM : valSize (scanOut (o, st1, c1)) ≤ M := by
      simp only [scanOut, valSize_list, listSize_cons, listSize_nil]
      have : valSize (encPO o) ≤ 3 := by cases o <;> decide
      omega
    set env : List Val := [scanOut (o, st1, c1), encL encPZ mz, acc] with henv
    have hoE : EvalsVal prog M env [] (.inl (eAtN 0 (eV 0))) (encPO o) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    have hst1E : EvalsVal prog M env [] (.inl (eAtN 1 (eV 0))) (adaEnc st1) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    have hc1E : EvalsVal prog M env [] (.inl (eAtN 2 (eV 0))) (encL encB c1) :=
      evalsVal_atN' EvalsVal.var0 houtM rfl
    cases o with
    | done =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_pos rfl] at he
      refine EvalsVal.ite_true he one_ne_zero ?_
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (evalsVal_list (List.Forall₂.cons hst1E
        List.Forall₂.nil) (by simp only [valSize_list, listSize_cons, listSize_nil]; omega)) ?_
      show valSize (Val.list [Val.int 0, Val.list [adaEnc st1]]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
      have : bitLen (0 : ℤ) = 0 := by decide
      omega
    | corrected =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he
      refine EvalsVal.ite_false he rfl ?_
      have he1 := EvalsVal.eq hoE (ap_lit_small (z := 1) (by decide) h3) (by omega)
      rw [if_pos rfl] at he1
      refine EvalsVal.ite_true he1 one_ne_zero ?_
      have hfE' : EvalsVal prog M env [] (.inl (eAtN 0 (eV 2))) (encN (f + 1)) :=
        evalsVal_atN' EvalsVal.var2 haccM rfl
      have hsf' : Nat.size f ≤ tightA A := le_trans (Nat.size_le_size (Nat.le_succ f)) hsf
      have hsub := EvalsVal.sub hfE' (ap_lit_small (z := 1) (by decide) h3) (by
        rw [show ((f + 1 : ℕ) : ℤ) - 1 = (f : ℤ) by omega, valSize_int, bitLen_natCast]
        omega)
      rw [show ((f + 1 : ℕ) : ℤ) - 1 = (f : ℤ) by omega] at hsub
      have hnext := valSize_prepEnc_le (vals := vals) (f := f) (st := st1) (c := c1)
        (le_trans (Nat.size_le_size (Nat.le_succ f)) hsf) hc1 hPub hSt1 hVals hp16
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (evalsVal_list (List.Forall₂.cons hsub
        (List.Forall₂.cons hst1E (List.Forall₂.cons hc1E (List.Forall₂.cons
          (evalsVal_atN' EvalsVal.var2 haccM rfl) (List.Forall₂.cons
          (evalsVal_atN' EvalsVal.var2 haccM rfl) List.Forall₂.nil))))) (by
            show valSize (prepEnc A vals (f, st1, c1)) ≤ M
            omega)) ?_
      show valSize (Val.list [Val.int 1, prepEnc A vals (f, st1, c1)]) ≤ M
      rw [ap_valSize_list2, valSize_int]
      have : bitLen (1 : ℤ) = 1 := by decide
      omega
    | abort =>
      have he := EvalsVal.eq hoE (ap_lit_small (z := 0) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he
      refine EvalsVal.ite_false he rfl ?_
      have he1 := EvalsVal.eq hoE (ap_lit_small (z := 1) (by decide) h3) (by omega)
      rw [if_neg (by decide)] at he1
      refine EvalsVal.ite_false he1 rfl ?_
      refine EvalsVal.pair (ap_lit_small (by decide) h3) (EvalsVal.nil (by simp; omega)) ?_
      show valSize (Val.list [Val.int 0, Val.list []]) ≤ M
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
      have : bitLen (0 : ℤ) = 0 := by decide
      omega

/-- **Spec of `adaPrepR`** (W4's contract, with `hf : f ≤ A.fuel`; tight value premise). -/
theorem adaPrep_impl_t {prog : List Expr} {M : ℕ} (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2)
    (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (f : ℕ) (hf : f ≤ A.fuel) {cache : List Bool}
    (hc : cache.length = A.p) (hMt : TightM A M) :
    Implements prog M [Val.list [encN f, adaEnc st, encL encB cache, adaPubEnc A, encVals vals]]
      body_adaPrep encOptSt ((prepareRoot A vals f st cache).toBits (adaDraw A)) :=
  implements_loop (hlib (Idx.adaPassStep, body_adaPassStep) (by simp [adaPrepTable]))
    (prepEnc A vals) encOptSt (PrepInv A) (fun s => s.1) (prepRef A vals) (prepQ A vals)
    (fun s hs => passStep_impl_t hlib hmus hS hL hbs hT hpos hv hMt s hs)
    (fun s _ => prepRef_unfold A vals s)
    (fun s hs _ s' h => Always.of_run (prepQ_always A vals s hs) h s' rfl)
    (s₀ := (f, st, cache)) ⟨hok, hc, hf⟩ EvalsVal.var0

/-! ### The old statements as corollaries (the integration form of `passStep_impl`, `adaPrep_impl`) -/

theorem passStep_impl_of_t (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) (hmus : MusLib prog)
    (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    (s : ℕ × AdaState × List Bool) (hs : PrepInv A s) :
    Implements prog M [prepEnc A vals s] body_adaPassStep (loopEnc (prepEnc A vals) encOptSt)
      (prepQ A vals s) :=
  passStep_impl_t hlib hmus hS hL hbs hT hpos hv (TightM.of_old hM) s hs

theorem adaPrep_impl_of_t {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2)
    (hmus : MusLib prog) (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (f : ℕ) (hf : f ≤ A.fuel) {cache : List Bool}
    (hc : cache.length = A.p) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [Val.list [encN f, adaEnc st, encL encB cache, adaPubEnc A, encVals vals]]
      body_adaPrep encOptSt ((prepareRoot A vals f st cache).toBits (adaDraw A)) :=
  adaPrep_impl_t hlib hmus hS hL hbs hT hpos hok hv f hf hc (TightM.of_old hM)

end PrepT

end F2e2e.C.Impl
