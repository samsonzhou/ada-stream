import F2e2e.BSpace.O2T.AdaPrepEdgeT
import F2e2e.BSpace.O2T.AdaPrepCorrT
import F2e2e.C.Impl.AdaPrepScan

/-!
# SCRATCH (O2b family 8, owner C-PROB): the scan pass under the tight value premise `TightM`
Promoted from Scratch/O2T/AdaPrepScanT.lean (owner C-PROB) at 14:30Z; statements unchanged.

B-NUM's proofs of `F2e2e/C/Impl/AdaPrepScan.lean` with `(hMt : TightM A M)` for
`(hM : 2 ^ 32 * adaBoundA A ≤ M)`:
* `adaBound_facts_t`: the size facts at `tightA` (B-ACC's tight size lemmas); the predictions table is
  `≤ 32 · tightA` (its entries have `2^6 (adaZ + 16)` bits, `musZ_bits`, and `p + 1 ≤ N` since every block
  is nonempty); the N-free scalar bound
  `2^14 (p + adaZ + 16)` (old L282/284, false at `tightA` for small `N`) is now `≤ cAddA A`;
* `valSize_scanEnc_le_t`: the accumulator is `≤ 36 · tightA`;
* `scanStep_impl_t`, `scanLoop_impl_t`: the scan step and the scan loop.
Consumes `adaEdge_impl_t` (`AdaPrepEdgeT.lean`) and family 9's `adaCorr_impl_t` (`AdaPrepCorrT.lean`). At integration the old lemmas become corollaries:
`scanStep_impl … hM := scanStep_impl_t … (TightM.of_old hM)`, the same for `scanLoop_impl`
(`adaBound_facts` keeps its own proof).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

/-- The tight premise with its constants evaluated. -/
theorem tightM_num {A : AdaParams} {M : ℕ} (h : TightM A M) :
    256 * tightA A + 262144 * (A.p + adaZ A + 16) ≤ M := by
  unfold TightM cAddA at h
  norm_num at h
  linarith

/-- Every block is nonempty, so `p + 1 ≤ N`. -/
theorem p_succ_le_N {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) : A.p + 1 ≤ A.N := by
  have h := List.length_le_sum_of_one_le A.blockSizes (fun i hi => by
    obtain ⟨j, hj, rfl⟩ := List.mem_iff_getElem.mp hi
    have := hpos j (by omega)
    rw [List.getD_eq_getElem _ _ hj] at this
    exact this)
  have hN : A.blockSizes.sum = A.N := rfl
  omega

/-- **The size facts at the tight scale** (the tight form of `adaBound_facts`; with `hpos`, which gives
`p + 1 ≤ N`). -/
theorem adaBound_facts_t {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (adaPubEnc A) ≤ tightA A ∧ valSize (adaEnc st) ≤ tightA A ∧
      valSize (encVals vals) ≤ tightA A ∧
      valSize (encL encPZ (musZ A st.scores vals)) ≤ 32 * tightA A ∧
      2 ^ 14 * (A.p + adaZ A + 16) ≤ cAddA A := by
  have hZ16 := sixteen_le_adaZ A
  have hpZ := p_le_adaZ A
  have hpN := p_succ_le_N hbs hpos
  refine ⟨valSize_adaPubEnc_le_t A hbs hT, valSize_adaEnc_le_t hok,
    valSize_encVals_le_t hbs hv.1 hv.2, ?_, ?_⟩
  · have hbits := musZ_bits hok hv
    have h1 := valSize_encL_le encPZ (musZ A st.scores vals) (2 ^ 7 * (adaZ A + 16) + 5) (by
      intro r hr
      obtain ⟨a, b⟩ := r
      rw [valSize_encPZ]
      have := hbits (a, b) hr
      simp only at this
      omega)
    rw [musZ_length] at h1
    unfold tightA
    have h2 : (2 * A.p + 17) * (adaZ A + 16) ≤ (A.N + A.p + 16) * (adaZ A + 16) :=
      Nat.mul_le_mul_right _ (by omega)
    nlinarith
  · unfold cAddA
    exact Nat.mul_le_mul_right _ (by norm_num)

/-- The scan accumulator at the tight scale: `≤ 36 · Bd` when the predictions are `≤ 32 · Bd`. -/
theorem valSize_scanEnc_le_t {A : AdaParams} {vals : List (List ℕ)} {mz : List (ℤ × ℤ)} {j : ℕ}
    {st : AdaState} {c : List Bool} {Bd : ℕ} (hj : j ≤ A.p + 1) (hc : c.length = A.p)
    (h1 : valSize (adaPubEnc A) ≤ Bd) (h2 : valSize (adaEnc st) ≤ Bd)
    (h3 : valSize (encVals vals) ≤ Bd) (h4 : valSize (encL encPZ mz) ≤ 32 * Bd)
    (hp : 8 * (A.p + 16) ≤ Bd) :
    valSize (scanEnc A vals mz (j, st, c)) ≤ 36 * Bd := by
  have hcS := ap_valSize_encL_encB c
  have hjS : Nat.size j ≤ A.p + 1 := (size_le_self j).trans hj
  rw [hc] at hcS
  simp only [scanEnc, valSize_list, listSize_cons, listSize_nil, valSize_encN]
  omega

/-- **The scan step implements one iteration of a scan pass, tight premise** (O2b family 8). -/
theorem scanStep_impl_t {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st0 : AdaState}
    (hok : AdaOK A st0) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M)
    (s : ℕ × AdaState × List Bool) (hs : ScanInv A st0 s) :
    Implements prog M [scanEnc A vals (musZ A st0.scores vals) s] body_adaScanStep
      (loopEnc (scanEnc A vals (musZ A st0.scores vals)) scanOut)
      (scanQ A vals (adaMus A st0 vals) s) := by
  obtain ⟨j, st, cache⟩ := s
  obtain ⟨hst, hcl, hjp⟩ := hs
  simp only at hst hcl hjp
  subst hst
  obtain ⟨hPub, hSt, hVals, hMz, -⟩ := adaBound_facts_t hbs hT hpos hok hv
  have hZ16 := sixteen_le_adaZ A
  have h32 := thirtytwo_le_tightA A
  have hp16 : 8 * (A.p + 16) ≤ tightA A := by omega
  have hBM : 256 * tightA A + 262144 * (A.p + adaZ A + 16) ≤ M := tightM_num hMt
  have hMr : 2 ^ 6 * (A.p + 8) ≤ M := by linarith
  have hacc5 : valSize (scanEnc A vals (musZ A st.scores vals) (j, st, cache)) ≤ 36 * tightA A :=
    valSize_scanEnc_le_t (by omega) hcl hPub hSt hVals hMz hp16
  have haccM : valSize (scanEnc A vals (musZ A st.scores vals) (j, st, cache)) ≤ M := by omega
  have h3 : 3 ≤ M := by omega
  have hpubM : valSize (Val.list (pubFields A)) ≤ M := by
    rw [← adaPubEnc_eq]; omega
  have hstM : valSize (adaEnc st) ≤ M := by omega
  have hcS : valSize (encL encB cache) ≤ 1 + 3 * A.p := by
    have := ap_valSize_encL_encB cache; rw [hcl] at this; exact this
  have hsj : Nat.size j ≤ A.p := (size_le_self j).trans hjp
  have hsj1 : Nat.size (j + 1) + 1 ≤ M := by
    have := size_le_self (j + 1); omega
  set mz := musZ A st.scores vals with hmz
  set acc := scanEnc A vals mz (j, st, cache) with hacc
  -- fields of the state
  have hstL : adaEnc st = Val.list [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt,
      encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted] := rfl
  have hTS : valSize (encL encN st.T) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hSt
  have hthS : valSize (encL encZ st.thrInt) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hSt
  have hTmS : valSize (encL encN A.Tmax) ≤ tightA A := by
    rw [adaPubEnc_eq] at hPub
    exact le_trans (valSize_lt_of_mem (by simp [pubFields])).le hPub
  unfold scanQ body_adaScanStep
  dsimp only
  by_cases hj : j < A.p
  · rw [if_pos hj]
    have hcond : EvalsVal prog M [acc] [] (.inl (eLt (aF 0 0) (eAtN 0 (aF 3 0)))) (Val.int 1) := by
      have h1 : EvalsVal prog M [acc] [] (.inl (aF 0 0)) (encN j) := ap_acc_field (env := [acc]) (k := 0) rfl haccM rfl
      have h2 : EvalsVal prog M [acc] [] (.inl (eAtN 0 (aF 3 0))) (encN A.p) :=
        evalsVal_atN' (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl) hpubM rfl
      have := EvalsVal.lt h1 h2 (by omega)
      rwa [if_pos (by exact_mod_cast hj)] at this
    refine ap_implements_ite_true hcond one_ne_zero ?_
    -- the cache bit
    have hget : EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (aF 2 0) (aF 0 0))))
        (encB (cache.getD j false)) := by
      have := ap_get_call hL (l := cache.map encB) (n := j) (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl)
        (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl) (by unfold S_get; simp only [encL] at hcS; omega)
      rwa [ap_getD_map_int0 cache encB (d := false) rfl] at this
    by_cases hc : cache.getD j false = true
    · rw [if_pos hc]
      rw [hc] at hget
      refine ap_implements_ite_true hget one_ne_zero ?_
      apply Implements.of_det
      refine ap_acc_next (k := 0) rfl haccM (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl) hsj1 h3 ?_
      have := valSize_scanEnc_le_t (A := A) (vals := vals) (mz := mz) (j := j + 1) (st := st)
        (c := cache) (by omega) hcl hPub hSt hVals hMz hp16
      rw [ap_valSize_list2, valSize_int]
      have : bitLen (1 : ℤ) = 1 := by decide
      omega
    · rw [if_neg hc]
      have hc' : cache.getD j false = false := by simpa using hc
      rw [hc'] at hget
      refine ap_implements_ite_false hget rfl ?_
      rw [edgeTest_toBits]
      obtain ⟨hD0, hμ0⟩ := musZ_spec hok hv hpos j (by omega)
      obtain ⟨hD1, hμ1⟩ := musZ_spec hok hv hpos (j + 1) (by omega)
      rw [← hμ0, ← hμ1]
      obtain ⟨bN0, bD0⟩ : bitLen (mz.getD j (0, 1)).1 ≤ edgeW A ∧
          bitLen (mz.getD j (0, 1)).2 ≤ edgeW A := ap_bitLen_le_edgeW_of_mem hok hv (by omega)
      obtain ⟨bN1, bD1⟩ : bitLen (mz.getD (j + 1) (0, 1)).1 ≤ edgeW A ∧
          bitLen (mz.getD (j + 1) (0, 1)).2 ≤ edgeW A :=
        ap_bitLen_le_edgeW_of_mem hok hv (by omega)
      have ht : |st.thrInt.getD j 0| ≤ (maxKs A : ℤ) := by
        by_cases hjt : j < st.thrInt.length
        · rw [List.getD_eq_getElem _ _ hjt]
          exact hok.thr_le _ (List.getElem_mem _)
        · rw [List.getD_eq_default _ _ (by omega)]
          simp
      have hEdge := adaEdge_impl_t (prog := prog) hS hD0 hD1 ht bN0 bD0 bN1 bD1 hPub hMt
      -- the arguments of the edge test
      have hmusL : (mz.map encPZ).length = A.p + 1 := by simp [hmz, musZ_length]
      have hmusS : S_get (mz.map encPZ) (j + 1) ≤ M := by
        unfold S_get
        have : valSize (Val.list (mz.map encPZ)) ≤ 32 * tightA A := hMz
        have := size_le_self (j + 1)
        omega
      have hmusS0 : S_get (mz.map encPZ) j ≤ M := by
        unfold S_get
        have : valSize (Val.list (mz.map encPZ)) ≤ 32 * tightA A := hMz
        omega
      have hpz : ∀ i, i < A.p + 1 → valSize (encPZ (mz.getD i (0, 1))) ≤ M := by
        intro i hi
        have h1 : encPZ (mz.getD i (0, 1)) ∈ mz.map encPZ := by
          rw [← ap_getD_map_lt mz encPZ (0, 1) (Val.int 0) (by rw [hmz, musZ_length]; exact hi)]
          rw [List.getD_eq_getElem _ _ (by rw [hmusL]; exact hi)]
          exact List.getElem_mem _
        have := (valSize_lt_of_mem h1).le
        have : valSize (Val.list (mz.map encPZ)) ≤ 32 * tightA A := hMz
        omega
      have hgetMu : ∀ (ie : Expr) (i : ℕ), i < A.p + 1 → S_get (mz.map encPZ) i ≤ M →
          EvalsVal prog M [acc] [] (.inl ie) (Val.int (i : ℤ)) →
          EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (aF 5 0) ie))) (encPZ (mz.getD i (0, 1))) := by
        intro ie i hi hSg hie
        have := ap_get_call hL (l := mz.map encPZ) (n := i) (ap_acc_field (env := [acc]) (k := 0) (n := 5) rfl haccM rfl) hie hSg
        rwa [ap_getD_map_lt mz encPZ (0, 1) (Val.int 0) (by rw [hmz, musZ_length]; exact hi)] at this
      have hj1E : EvalsVal prog M [acc] [] (.inl (eAdd (aF 0 0) (eLit 1))) (Val.int ((j + 1 : ℕ) : ℤ)) :=
        ap_acc_succ (k := 0) rfl haccM hsj1 h3
      have hm0 := hgetMu (aF 0 0) j (by omega) hmusS0 (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl)
      have hm1 := hgetMu _ (j + 1) (by omega) hmusS hj1E
      have hthrE : EvalsVal prog M [acc] [] (.inl (eCall Idx.get (ePair (eAtN 2 (aF 1 0)) (aF 0 0))))
          (Val.int (st.thrInt.getD j 0)) := by
        have := ap_get_call hL (l := st.thrInt.map encZ) (n := j)
          (evalsVal_atN' (n := 2) (ap_acc_field (env := [acc]) (k := 0) (n := 1) rfl haccM rfl) hstM rfl) (ap_acc_field (env := [acc]) (k := 0) (n := 0) rfl haccM rfl)
          (by unfold S_get; simp only [encL] at hthS; omega)
        rwa [ap_getD_map_int0 st.thrInt encZ (d := 0) rfl] at this
      have hargs : EvalsVal prog M [acc] [] (.inl (eList [aF 3 0,
            eCall Idx.get (ePair (eAtN 2 (aF 1 0)) (aF 0 0)),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (aF 0 0))),
            eAtN 0 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1)))),
            eAtN 1 (eCall Idx.get (ePair (aF 5 0) (eAdd (aF 0 0) (eLit 1))))]))
          (Val.list [adaPubEnc A, Val.int (st.thrInt.getD j 0), Val.int (mz.getD j (0, 1)).1,
            Val.int (mz.getD j (0, 1)).2, Val.int (mz.getD (j + 1) (0, 1)).1,
            Val.int (mz.getD (j + 1) (0, 1)).2]) := by
        have hp0 := hpz j (by omega)
        have hp1 := hpz (j + 1) (by omega)
        refine evalsVal_list (List.Forall₂.cons (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl)
          (List.Forall₂.cons hthrE
          (List.Forall₂.cons (evalsVal_atN' hm0 hp0 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm0 hp0 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm1 hp1 rfl)
          (List.Forall₂.cons (evalsVal_atN' hm1 hp1 rfl) List.Forall₂.nil)))))) ?_
        have hbt := ap_bitLen_le_edgeW_of_abs ht
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
        unfold edgeW at hbt bN0 bD0 bN1 bD1
        omega
      refine implements_letE_of (implements_call_det hlib.edge hargs hEdge) (fun _ => True)
        (fun _ _ _ => trivial) ?_
      intro r _
      cases r with
      | none =>
        dsimp only
        have hcz : EvalsVal prog M [encOB none, acc] [] (.inl (eEq (eV 0) (eLit 0))) (Val.int 1) := by
          have := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB none) (rest := [acc])) (ap_lit_small (z := 0) (by decide) h3)
            (by omega)
          simpa [encOB, obZ] using this
        refine ap_implements_ite_true hcz one_ne_zero ?_
        apply Implements.of_det
        have hsetE : EvalsVal prog M [encOB none, acc] [] (.inl (eCall Idx.set (eList [aF 2 1, aF 0 1,
            eLit 1]))) (encL encB (cache.set j true)) := by
          have := ap_set_call hL (l := cache.map encB) (n := j) (x := Val.int 1)
            (ap_acc_field (env := [encOB none, acc]) (k := 1) (n := 2) rfl haccM rfl) (ap_acc_field (env := [encOB none, acc]) (k := 1) (n := 0) rfl haccM rfl)
            (ap_lit_small (z := 1) (by decide) h3) (by
              unfold S_set
              simp only [encL] at hcS
              simp only [valSize_int]
              have : bitLen (1 : ℤ) = 1 := by decide
              omega)
          rwa [show (Val.int 1 : Val) = encB true from rfl, ap_encL_encB_set] at this
        refine ap_acc_next (k := 1) rfl haccM hsetE hsj1 h3 ?_
        have := valSize_scanEnc_le_t (A := A) (vals := vals) (mz := mz) (j := j + 1) (st := st)
          (c := cache.set j true) (by omega) (by simp [hcl]) hPub hSt hVals hMz hp16
        rw [ap_valSize_list2, valSize_int]
        have : bitLen (1 : ℤ) = 1 := by decide
        omega
      | some q =>
        dsimp only
        have hcz : EvalsVal prog M [encOB (some q), acc] [] (.inl (eEq (eV 0) (eLit 0))) (Val.int 0) := by
          have := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB (some q)) (rest := [acc])) (ap_lit_small (z := 0) (by decide) h3)
            (by omega)
          rwa [if_neg (ap_obZ_ne_zero q)] at this
        refine ap_implements_ite_false hcz rfl ?_
        -- the cap test
        have hTE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eCall Idx.get
            (ePair (eAtN 1 (aF 1 1)) (aF 0 1)))) (encN (st.T.getD j 0)) := by
          have := ap_get_call hL (l := st.T.map encN) (n := j)
            (evalsVal_atN' (n := 1) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl) hstM rfl) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
            (by unfold S_get; simp only [encL] at hTS; omega)
          rwa [ap_getD_map_int0 st.T encN (d := 0) rfl] at this
        have hTmE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eCall Idx.get
            (ePair (eAtN 2 (aF 3 1)) (aF 0 1)))) (encN (A.Tmax.getD j 0)) := by
          have := ap_get_call hL (l := A.Tmax.map encN) (n := j)
            (evalsVal_atN' (n := 2) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 3) rfl haccM rfl) hpubM rfl) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
            (by unfold S_get; simp only [encL] at hTmS; omega)
          rwa [ap_getD_map_int0 A.Tmax encN (d := 0) rfl] at this
        have hlt := EvalsVal.lt hTE hTmE (by omega)
        by_cases hcap : A.Tmax.getD j 0 ≤ st.T.getD j 0
        · rw [if_pos hcap]
          have hlt0 : ¬ (((st.T.getD j 0 : ℕ) : ℤ) < ((A.Tmax.getD j 0 : ℕ) : ℤ)) := by
            exact_mod_cast not_lt.mpr hcap
          rw [if_neg hlt0] at hlt
          refine ap_implements_ite_false hlt rfl ?_
          apply Implements.of_det
          refine ap_acc_stop (ap_lit_small (z := 2) (by decide) h3) (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl)
            (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 2) rfl haccM rfl) h3 ?_
          simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : bitLen (2 : ℤ) = 2 := by decide
          have : bitLen (0 : ℤ) = 0 := by decide
          omega
        · rw [if_neg hcap]
          have hTj : st.T.getD j 0 < A.Tmax.getD j 0 := by omega
          have hlt1 : (((st.T.getD j 0 : ℕ) : ℤ) < ((A.Tmax.getD j 0 : ℕ) : ℤ)) := by exact_mod_cast hTj
          rw [if_pos hlt1] at hlt
          refine ap_implements_ite_true hlt one_ne_zero ?_
          -- the correction
          have hqE : EvalsVal prog M [encOB (some q), acc] [] (.inl (eIte (eEq (eV 0) (eLit 1)) (eLit 1)
              (eLit (-1)))) (Val.int (avSign q)) := by
            have he := EvalsVal.eq (EvalsVal.var0 (prog := prog) (M := M) (v := encOB (some q)) (rest := [acc])) (ap_lit_small (z := 1) (by decide) h3)
              (by omega)
            cases q
            · rw [show obZ (some false) = 2 from rfl, if_neg (by decide)] at he
              exact EvalsVal.ite_false he rfl (ap_lit_small (by decide) h3)
            · rw [show obZ (some true) = 1 from rfl, if_pos rfl] at he
              exact EvalsVal.ite_true he one_ne_zero (ap_lit_small (by decide) h3)
          have hcargs : EvalsVal prog M [encOB (some q), acc] [] (.inl (eList [aF 0 1,
              eIte (eEq (eV 0) (eLit 1)) (eLit 1) (eLit (-1)), aF 1 1, aF 3 1, aF 4 1]))
              (Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals]) := by
            refine evalsVal_list (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 0) rfl haccM rfl)
              (List.Forall₂.cons hqE (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 1) rfl haccM rfl)
              (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 3) rfl haccM rfl)
              (List.Forall₂.cons (ap_acc_field (env := [encOB (some q), acc]) (k := 1) (n := 4) rfl haccM rfl) List.Forall₂.nil))))) ?_
            have : bitLen (avSign q) ≤ 1 := by cases q <;> decide
            simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encN]
            omega
          have hcorr := adaCorr_impl_t (prog := prog) hlib.corr hS hL hbs hT hok hv hj hTj q hMt
          have hsupp : ∀ bits st', ((applyCorrection A st vals j q).toBits (adaDraw A)).run bits =
              some (st', []) → AdaOK A st' := fun bits st' h =>
            (Always.of_run (DAlw.toBits (adaDraw_adaKB A) (applyCorrection_ok hok vals q hj hTj)) h).1
          refine implements_letE_of (implements_call_det (ap_corr_lookup hlib.corr) hcargs hcorr) (AdaOK A)
            hsupp ?_
          intro st' hst'
          apply Implements.of_det
          have hst'M := valSize_adaEnc_le_t hst'
          have hrE : EvalsVal prog M [adaEnc st', encOB (some q), acc] [] (.inl (eCall Idx.adaReset
              (eList [aF 0 2, aF 2 2, eAtN 0 (aF 3 2)]))) (encL encB (resetCache A j cache)) := by
            refine evalsVal_call_det hlib.reset (evalsVal_list (List.Forall₂.cons
              (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 0) rfl haccM rfl) (List.Forall₂.cons (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 2) rfl haccM rfl)
              (List.Forall₂.cons (evalsVal_atN' (ap_acc_field (env := [adaEnc st', encOB (some q), acc]) (k := 2) (n := 3) rfl haccM rfl) hpubM rfl)
              List.Forall₂.nil))) ?_) (adaReset_val hL A (by omega) hcl hMr)
            rw [ap_valSize_list3, valSize_encN, valSize_encN]
            have := size_le_self A.p
            omega
          have hrl : (resetCache A j cache).length = A.p := by
            rw [resetCache_eq]; split_ifs <;> simp [hcl]
          refine ap_acc_stop (ap_lit_small (z := 1) (by decide) h3) EvalsVal.var0 hrE h3 ?_
          have := ap_valSize_encL_encB (resetCache A j cache)
          rw [hrl] at this
          simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : bitLen (1 : ℤ) = 1 := by decide
          have : bitLen (0 : ℤ) = 0 := by decide
          omega
  · rw [if_neg hj]
    have hcond : EvalsVal prog M [acc] [] (.inl (eLt (aF 0 0) (eAtN 0 (aF 3 0)))) (Val.int 0) := by
      have h1 : EvalsVal prog M [acc] [] (.inl (aF 0 0)) (encN j) := ap_acc_field (env := [acc]) (k := 0) rfl haccM rfl
      have h2 : EvalsVal prog M [acc] [] (.inl (eAtN 0 (aF 3 0))) (encN A.p) :=
        evalsVal_atN' (ap_acc_field (env := [acc]) (k := 0) (n := 3) rfl haccM rfl) hpubM rfl
      have := EvalsVal.lt h1 h2 (by omega)
      rwa [if_neg (by exact_mod_cast hj)] at this
    refine ap_implements_ite_false hcond rfl ?_
    apply Implements.of_det
    refine ap_acc_stop (ap_lit_small (z := 0) (by decide) h3) (ap_acc_field (env := [acc]) (k := 0) (n := 1) rfl haccM rfl)
      (ap_acc_field (env := [acc]) (k := 0) (n := 2) rfl haccM rfl) h3 ?_
    simp only [scanOut, encPO, valSize_list, listSize_cons, listSize_nil, valSize_int]
    have : bitLen (0 : ℤ) = 0 := by decide
    omega

/-- **The scan loop implements a whole scan pass, tight premise** (O2b family 8). -/
theorem scanLoop_impl_t {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M)
    {cache : List Bool} (hc : cache.length = A.p) {env : List Val} {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (scanEnc A vals (musZ A st.scores vals) (0, st, cache))) :
    Implements prog M env (eLoop Idx.adaScanStep a) scanOut
      (scanRef A vals (adaMus A st vals) (0, st, cache)) :=
  implements_loop hlib.step (scanEnc A vals (musZ A st.scores vals)) scanOut (ScanInv A st)
    (fun s => A.p - s.1) (scanRef A vals (adaMus A st vals)) (scanQ A vals (adaMus A st vals))
    (fun s hs => scanStep_impl_t hlib hS hL hbs hT hpos hok hv hMt s hs)
    (fun s _ => scanRef_unfold A vals _ s)
    (fun s hs _ s' h => Always.of_run (scanQ_always A vals _ st s hs) h s' rfl)
    ⟨rfl, hc, Nat.zero_le _⟩ ha

/-! ## Old-statement checks (the post-cut corollary rewrites; `adaBound_facts` and `valSize_scanEnc_le` keep
their own proofs: the old size facts have no `hpos`, and the old accumulator bound is `5 · Bd`) -/

/-- Check: `scanStep_impl` (old statement, verbatim) from `scanStep_impl_t` and `TightM.of_old`. -/
example {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st0 : AdaState}
    (hok : AdaOK A st0) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    (s : ℕ × AdaState × List Bool) (hs : ScanInv A st0 s) :
    Implements prog M [scanEnc A vals (musZ A st0.scores vals) s] body_adaScanStep
      (loopEnc (scanEnc A vals (musZ A st0.scores vals)) scanOut)
      (scanQ A vals (adaMus A st0 vals) s) :=
  scanStep_impl_t hlib hS hL hbs hT hpos hok hv (TightM.of_old hM) s hs

/-- Check: `scanLoop_impl` (old statement, verbatim) from `scanLoop_impl_t` and `TightM.of_old`. -/
example {prog : List Expr} {M : ℕ} (hlib : ScanLib prog) (hS : SampLib prog)
    (hL : ListLib prog) {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M)
    {cache : List Bool} (hc : cache.length = A.p) {env : List Val} {a : Expr}
    (ha : EvalsVal prog M env [] (.inl a) (scanEnc A vals (musZ A st.scores vals) (0, st, cache))) :
    Implements prog M env (eLoop Idx.adaScanStep a) scanOut
      (scanRef A vals (adaMus A st vals) (0, st, cache)) :=
  scanLoop_impl_t hlib hS hL hbs hT hpos hok hv (TightM.of_old hM) hc ha

end F2e2e.C.Impl
