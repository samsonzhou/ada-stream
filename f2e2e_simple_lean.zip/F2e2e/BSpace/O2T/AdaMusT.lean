import F2e2e.BSpace.O2T.AdaWater2T
import F2e2e.C.Impl.AdaMus

/-!
# SCRATCH (O2b family 7, owner A-ARCH a99d156c): `adaMusR` under the tight value premise `TightM`
Promoted from Scratch/O2T/AdaMusT.lean (owner A-ARCH a99d156c) at 14:30Z; statements unchanged.

`adaMusR_val_t`: `F2e2e.C.Impl.adaMusR_val` (`F2e2e/C/Impl/AdaMus.lean`) with `(hMt : TightM A M)` for
`(hM : 2 ^ 32 * adaBoundA A ≤ M)` (callee rule of the O2b tech lead 17fc0802). A T-FILE, not a copy: `AdaMus` is
imported by `AdaPrepRef` (hence by the copies of families 5/6/8/9 through the originals), so this file only adds
the new name. At integration (after O1) `adaMusR_val_t` moves into `AdaMus.lean` and the old lemma becomes
`adaMusR_val … hM := adaMusR_val_t … (TightM.of_old hM)` (`adaMusR_val_of_t` below checks this now).
The musZ lemmas (`musZ_spec`, `musZ_bits`, `AdaMusSpec.lean`, `AdaMusDefs.lean`) are bound-free: no `_t`.

Callee: the family-10 `adaMusRImpl_val_t` (C-FP, reviewed by W4: `F2e2e/Scratch/O2T/AdaWater2T.lean`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

/-- **Spec of `adaMusR`, tight premise** (O2b family 7). -/
theorem adaMusR_val_t {prog : List Expr} {M : ℕ} (hlib : MusLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusR) (encL encPZ (musZ A st.scores vals)) :=
  adaMusRImpl_val_t hlib.2 hbs hT hpos hok hv hMt

/-- The old statement is the corollary (the integration form of `adaMusR_val`). -/
theorem adaMusR_val_of_t {prog : List Expr} {M : ℕ} (hlib : MusLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusR) (encL encPZ (musZ A st.scores vals)) :=
  adaMusR_val_t hlib hbs hT hpos hok hv (TightM.of_old hM)

end F2e2e.C.Impl
