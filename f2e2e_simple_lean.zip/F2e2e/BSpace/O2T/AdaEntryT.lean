import F2e2e.C.Impl.AdaEntry
import F2e2e.BSpace.O2T.AdaEntryOuterT
import F2e2e.BSpace.O2T.AdaPrepT

/-!
# O2b family 5 (W2, a2ff64c3, for 17fc0802): the interval interface `adaInterval` (Idx 602) under `TightM`
Promoted from Scratch/O2T/AdaEntryT.lean (owner W2 a2ff64c3) at 14:30Z; statements unchanged.

Delta file: imports the ORIGINAL `F2e2e.C.Impl.AdaEntry` and adds only `adaInterval_impl_t`, whose statement is
exactly `adaInterval_impl`'s with `hM : 2 ^ 32 * adaBoundA A ≤ M` replaced by `(hMt : TightM A M)` (the extra
premise `hMq : 2 ^ 28 * Bq ≤ M` is kept). The proof is the original one with the tight size facts (`ivT_facts`,
`valSize_adaEnc_le_t`; the library `set` needs `10 · |state| + O(1) ≤ 2^8 · tightA A`, `replicate` and the
counters are covered by `cAddA A`) and the tight callees `adaPrep_impl_t` (family 8, A-VAL's `AdaPrepT.lean`)
and `adaIvOuter_impl_t` (`AdaEntryOuterT.lean`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

set_option maxHeartbeats 1000000 in
/-- **Spec of `adaInterval`** (Idx 602) under the tight premise `TightM A M` (O2b family 5): on the
parameter record, a state satisfying the invariant,
a well-formed query table and canonical endpoints of bit length `≤ Bq`, `body_adaInterval`
implements `adaInterval A st vals l u` with the output `[encCert cert, adaEnc st']`. -/
theorem adaInterval_impl_t {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaEntryTable, prog[e.1]? = some e.2)
    (hprep : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) (hmus : MusLib prog) (hS : SampLib prog)
    (hL : ListLib prog) (hq : NormQSpec prog M) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq)
    (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hMt : TightM A M) (hMq : 2 ^ 28 * Bq ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u) := by
  have _hq := hq -- W4's contract premise (`NormQSpec`); not needed by this routine
  have h606 : prog[Idx.adaIvOuter]? = some body_adaIvOuter :=
    hlib (Idx.adaIvOuter, body_adaIvOuter) (List.mem_cons_of_mem _ List.mem_cons_self)
  have h700 : prog[Idx.adaPrepR]? = some body_adaPrep :=
    hprep (Idx.adaPrepR, body_adaPrep) (List.mem_append_left _ List.mem_cons_self)
  /- ### Sizes -/
  obtain ⟨hPub, hSt, hVals, -⟩ := ivT_facts hbs hT hok hv
  have hM : 2 ^ 8 * tightA A + 2 ^ 18 * (A.p + adaZ A + 16) ≤ M := hMt
  have hZ16 := sixteen_le_adaZ A
  have hpZ := p_le_adaZ A
  have hfZ := size_fuel_le_adaZ A
  have hMJR := size_MJR_le_adaZ A
  have hPubM : valSize (adaPubEnc A) ≤ M := by omega
  have hStM : valSize (adaEnc st) ≤ M := by omega
  have h3 : 3 ≤ M := by omega
  have hencQ : ∀ x : ℚ, bitLen x.num ≤ Bq ∧ bitLen (x.den : ℤ) ≤ Bq →
      valSize (encQ x) ≤ 2 * Bq + 5 := by
    intro x hx
    rw [valSize_encQ]
    have h1 : Nat.size x.num.natAbs ≤ Bq := hx.1
    have h2 : Nat.size x.den ≤ Bq := by have := hx.2; rwa [bitLen_natCast] at this
    omega
  have hlq := hencQ l hl
  have huq := hencQ u hu
  have hinpM : valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤ M := by
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hlitN : ∀ {env : List Val} (n : ℕ), n < 16 →
      EvalsVal prog M env [] (.inl (eLit (n : ℤ))) (Val.int (n : ℤ)) := fun n hn =>
    EvalsVal.lit (by
      rw [valSize_int, bitLen_natCast]
      have := Nat.size_le.2 (show n < 2 ^ 4 by omega)
      omega)
  set inp := Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u] with hinp
  /- ### Field access -/
  have hF : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u][n]? = some v →
      EvalsVal prog M env [] (.inl (eAtN n (eV k))) v :=
    fun henv hget => evalsVal_atN' (EvalsVal.var henv) hinpM hget
  have hP : ∀ {env : List Val} {k n : ℕ} {v : Val}, env[k]? = some inp →
      (pubFields A)[n]? = some v → EvalsVal prog M env [] (.inl (eAtN n (eAtN 0 (eV k)))) v :=
    fun henv hget => evalsVal_atN' (l := pubFields A) (hF henv rfl) hPubM hget
  have hS0 : ∀ {env : List Val} {n : ℕ} {v : Val}, env[0]? = some (adaEnc st) →
      [encL (encL encZ) st.scores, encL encN st.T, encL encZ st.thrInt, encZ st.thrOut,
        encN st.rej, encN st.nInt, encN st.nNum, encB st.halted, encB st.capAborted][n]? =
        some v → EvalsVal prog M env [] (.inl (eAtN n (eV 0))) v :=
    fun henv hget => evalsVal_atN' (l := [encL (encL encZ) st.scores, encL encN st.T,
      encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
      encB st.halted, encB st.capAborted]) (EvalsVal.var henv) hStM hget
  have hstE : EvalsVal prog M [inp] [] (.inl (eAtN 1 (eV 0))) (adaEnc st) := hF rfl rfl
  unfold adaInterval
  rw [adaIntervalD_eq_iv]
  unfold body_adaInterval
  refine iv_letE_det hstE ?_
  have hlt := EvalsVal.lt (hS0 (env := [adaEnc st, inp]) (n := 5) rfl rfl)
    (hP (env := [adaEnc st, inp]) (k := 1) (n := 4) rfl rfl) (by omega)
  have hhE : EvalsVal prog M [adaEnc st, inp] [] (.inl (eAtN 7 (eV 0))) (encB st.halted) :=
    hS0 rfl rfl
  by_cases hc : st.halted = true ∨ A.M ≤ st.nInt
  · /- ### Abort: halted or the cap `M` reached -/
    rw [if_pos hc]
    apply Implements.of_det
    show EvalsVal prog M [adaEnc st, inp] [] _ (Val.list [Val.int 5, adaEnc st])
    have hout : EvalsVal prog M [adaEnc st, inp] [] (.inl (ePair (eLit 5) (eV 0)))
        (Val.list [Val.int 5, adaEnc st]) := by
      refine EvalsVal.pair (hlitN 5 (by norm_num)) EvalsVal.var0 ?_
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
      have : bitLen (5 : ℤ) ≤ 3 := by decide
      have : Nat.size 5 ≤ 3 := Nat.size_le.2 (by norm_num)
      omega
    cases hhv : st.halted with
    | false =>
      have hMc : A.M ≤ st.nInt := by
        rcases hc with h | h
        · rw [hhv] at h; cases h
        · exact h
      rw [hhv] at hhE
      refine EvalsVal.ite_false hhE (by decide) ?_
      exact EvalsVal.ite_false hlt (by rw [if_neg (by omega)]) hout
    | true =>
      rw [hhv] at hhE
      exact EvalsVal.ite_true hhE (by decide) hout
  · /- ### `PrepareRoot` and the outer test -/
    rw [if_neg hc]
    have hh : st.halted = false := by
      cases h : st.halted
      · rfl
      · exact absurd (Or.inl h) hc
    have hMc : st.nInt < A.M := by
      by_contra h'
      exact hc (Or.inr (by omega))
    rw [toBits_bind]
    rw [hh] at hhE
    refine ap_implements_ite_false hhE (by decide) ?_
    refine ap_implements_ite_true hlt (by
      rw [if_pos (by exact_mod_cast hMc)]; exact one_ne_zero) ?_
    -- the state with `nInt + 1`
    have hok1 : AdaOK A { st with nInt := st.nInt + 1 } :=
      ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len, hok.thr_le,
        hok.thrOut_le, hok.scores_le, hok.rej_le, hok.rej_halt,
        by show st.nInt + 1 ≤ A.M; omega, hok.nNum_le⟩
    have hSt1 := valSize_adaEnc_le_t hok1
    have hnS : Nat.size (st.nInt + 1) ≤ adaZ A :=
      (Nat.size_le_size (show st.nInt + 1 ≤ A.M + A.J + A.R + 2 by omega)).trans hMJR
    have hst1E : EvalsVal prog M [adaEnc st, inp] []
        (.inl (eCall Idx.set (eList [eV 0, eLit 5, eAdd (eAtN 5 (eV 0)) (eLit 1)])))
        (adaEnc { st with nInt := st.nInt + 1 }) := by
      have hcast : (st.nInt : ℤ) + 1 = ((st.nInt + 1 : ℕ) : ℤ) := by push_cast; ring
      have hadd := EvalsVal.add (hS0 (env := [adaEnc st, inp]) (n := 5) rfl rfl)
        (hlitN (env := [adaEnc st, inp]) 1 (by norm_num)) (by
          rw [show (st.nInt : ℤ) + ((1 : ℕ) : ℤ) = ((st.nInt + 1 : ℕ) : ℤ) by push_cast; ring,
            valSize_int, bitLen_natCast]
          omega)
      rw [show (st.nInt : ℤ) + ((1 : ℕ) : ℤ) = ((st.nInt + 1 : ℕ) : ℤ) by push_cast; ring] at hadd
      have := ap_set_call hL (l := [encL (encL encZ) st.scores, encL encN st.T,
          encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
          encB st.halted, encB st.capAborted]) (n := 5) (x := encN (st.nInt + 1))
        EvalsVal.var0 (hlitN 5 (by norm_num)) hadd (by
          unfold S_set
          rw [valSize_encN]
          have : Nat.size 5 ≤ 3 := Nat.size_le.2 (by norm_num)
          have hstL : valSize (Val.list [encL (encL encZ) st.scores, encL encN st.T,
              encL encZ st.thrInt, encZ st.thrOut, encN st.rej, encN st.nInt, encN st.nNum,
              encB st.halted, encB st.capAborted]) ≤ tightA A := hSt
          omega)
      exact this
    refine iv_letE_det hst1E ?_
    -- `PrepareRoot`
    set st1 : AdaState := { st with nInt := st.nInt + 1 } with hst1
    have hrepE : EvalsVal prog M [adaEnc st1, adaEnc st, inp] []
        (.inl (eCall Idx.replicate (ePair (eAtN 0 (eAtN 0 (eV 2))) (eLit 0))))
        (encL encB (List.replicate A.p false)) := by
      have hpS := size_le_self A.p
      have hpair := EvalsVal.pair (hP (env := [adaEnc st1, adaEnc st, inp]) (k := 2) (n := 0) rfl rfl)
        (hlitN (env := [adaEnc st1, adaEnc st, inp]) 0 (by norm_num)) (by
          simp only [encN, valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast,
            Nat.size_zero]
          omega)
      have := replicate_val hL (n := A.p) (x := Val.int ((0 : ℕ) : ℤ)) hpair (by
        unfold S_replicate
        simp only [valSize_int, bitLen_natCast, Nat.size_zero]
        have : A.p * (0 + 1 + 1) ≤ 2 * adaZ A := by omega
        omega)
      have he : Val.list (List.replicate A.p (Val.int ((0 : ℕ) : ℤ))) =
          encL encB (List.replicate A.p false) := by
        simp [encL, encB, List.map_replicate]
      rw [he] at this
      exact this
    have hcS := ap_valSize_encL_encB (List.replicate A.p false)
    rw [List.length_replicate] at hcS
    have hargs : EvalsVal prog M [adaEnc st1, adaEnc st, inp] []
        (.inl (eList [eAtN 3 (eAtN 0 (eV 2)), eV 0,
          eCall Idx.replicate (ePair (eAtN 0 (eAtN 0 (eV 2))) (eLit 0)), eAtN 0 (eV 2),
          eAtN 2 (eV 2)]))
        (Val.list [encN A.fuel, adaEnc st1, encL encB (List.replicate A.p false), adaPubEnc A,
          encVals vals]) := by
      refine evalsVal_list (List.Forall₂.cons (hP rfl rfl) (List.Forall₂.cons EvalsVal.var0
        (List.Forall₂.cons hrepE (List.Forall₂.cons (hF rfl rfl) (List.Forall₂.cons (hF rfl rfl)
          List.Forall₂.nil))))) ?_
      simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
      omega
    refine implements_letE_of (implements_call_det h700 hargs (adaPrep_impl_t hprep hmus hS hL hbs hT
        hpos hok1 hv A.fuel le_rfl (by simp) hMt))
      (fun r => ∀ st', r = some st' → AdaOK A st' ∧ AdaSameCtr st1 st')
      (fun bits r h => Always.of_run (DAlw.toBits (adaDraw_adaKB A)
        (prepareRoot_ok vals A.fuel st1 (List.replicate A.p false) hok1)) h) ?_
    intro r hr
    cases r with
    | none =>
      /- ### `CAP_ABORT` -/
      have hnil : EvalsVal prog M [encOptSt none, adaEnc st1, adaEnc st, inp] []
          (.inl (Expr.un UnOp.isNil (eV 0))) (Val.int 1) :=
        EvalsVal.isNil_nil (EvalsVal.var rfl : EvalsVal prog M [encOptSt none, adaEnc st1,
          adaEnc st, inp] [] (.inl (eV 0)) (Val.list [])) (by omega)
      refine ap_implements_ite_true hnil one_ne_zero ?_
      apply Implements.of_det
      have hokH : AdaOK A { st with nInt := st.nInt + 1, halted := true } :=
        ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len,
          hok.thr_le, hok.thrOut_le, hok.scores_le, hok.rej_le, fun h' => absurd h' (by simp),
          by show st.nInt + 1 ≤ A.M; omega, hok.nNum_le⟩
      have hokC : AdaOK A { st with nInt := st.nInt + 1, halted := true, capAborted := true } :=
        ⟨hok.scores_len, hok.scores_blk, hok.weights, hok.T_len, hok.T_le, hok.thr_len,
          hok.thr_le, hok.thrOut_le, hok.scores_le, hok.rej_le, fun h' => absurd h' (by simp),
          by show st.nInt + 1 ≤ A.M; omega, hok.nNum_le⟩
      have hSH := valSize_adaEnc_le_t hokH
      have hSC := valSize_adaEnc_le_t hokC
      have hlit1 : ∀ {env : List Val}, EvalsVal prog M env [] (.inl (eLit 1)) (Val.int 1) :=
        ap_lit_small (by decide) h3
      have hset1 := ap_set_call hL (env := [encOptSt none, adaEnc st1, adaEnc st, inp])
        (l := [encL (encL encZ) st1.scores, encL encN st1.T, encL encZ st1.thrInt,
          encZ st1.thrOut, encN st1.rej, encN st1.nInt, encN st1.nNum, encB st1.halted,
          encB st1.capAborted]) (n := 7) (x := Val.int 1) EvalsVal.var1 (hlitN 7 (by norm_num))
        hlit1 (by
          unfold S_set
          have : Nat.size 7 ≤ 3 := Nat.size_le.2 (by norm_num)
          have hst1L : valSize (Val.list [encL (encL encZ) st1.scores, encL encN st1.T,
              encL encZ st1.thrInt, encZ st1.thrOut, encN st1.rej, encN st1.nInt, encN st1.nNum,
              encB st1.halted, encB st1.capAborted]) ≤ tightA A := hSt1
          simp only [valSize_int]
          have : bitLen (1 : ℤ) = 1 := by decide
          omega)
      have hset2 := ap_set_call hL (n := 8) (x := Val.int 1) hset1 (hlitN 8 (by norm_num)) hlit1
        (by
          unfold S_set
          have : Nat.size 8 ≤ 4 := Nat.size_le.2 (by norm_num)
          have hstHL : valSize (Val.list ([encL (encL encZ) st1.scores, encL encN st1.T,
              encL encZ st1.thrInt, encZ st1.thrOut, encN st1.rej, encN st1.nInt, encN st1.nNum,
              encB st1.halted, encB st1.capAborted].set 7 (Val.int 1))) ≤ tightA A := hSH
          simp only [valSize_int]
          have : bitLen (1 : ℤ) = 1 := by decide
          omega)
      show EvalsVal prog M [encOptSt none, adaEnc st1, adaEnc st, inp] []
        (.inl (ePair (eLit 5) (eCall Idx.set (eList [eCall Idx.set (eList [eV 1, eLit 7, eLit 1]),
          eLit 8, eLit 1]))))
        (Val.list [Val.int 5,
          adaEnc { st with nInt := st.nInt + 1, halted := true, capAborted := true }])
      refine EvalsVal.pair (hlitN 5 (by norm_num)) hset2 ?_
      rw [ap_valSize_list2]
      have h5 : valSize (Val.int ((5 : ℕ) : ℤ)) ≤ 4 := by
        rw [valSize_int, bitLen_natCast]
        have := Nat.size_le.2 (show 5 < 2 ^ 3 by norm_num)
        omega
      have hC : valSize (Val.list (([encL (encL encZ) st1.scores, encL encN st1.T,
          encL encZ st1.thrInt, encZ st1.thrOut, encN st1.rej, encN st1.nInt, encN st1.nNum,
          encB st1.halted, encB st1.capAborted].set 7 (Val.int 1)).set 8 (Val.int 1))) ≤
          tightA A := hSC
      omega
    | some st2 =>
      /- ### The outer test -/
      obtain ⟨hok2, hs2⟩ := hr st2 rfl
      have hh2 : st2.halted = false := by rw [hs2.1]; exact hh
      have hSt2 := valSize_adaEnc_le_t hok2
      have henvS : valSize (encOptSt (some st2)) ≤ M := by
        show valSize (Val.list [adaEnc st2]) ≤ M
        simp only [valSize_list, listSize_cons, listSize_nil]
        omega
      have hnil : EvalsVal prog M [encOptSt (some st2), adaEnc st1, adaEnc st, inp] []
          (.inl (Expr.un UnOp.isNil (eV 0))) (Val.int 0) :=
        EvalsVal.isNil_cons (x := adaEnc st2) (l := []) EvalsVal.var0 (by omega)
      refine ap_implements_ite_false hnil rfl ?_
      have hargs2 : EvalsVal prog M [encOptSt (some st2), adaEnc st1, adaEnc st, inp] []
          (.inl (eList [eAtN 0 (eV 3), eHd (eV 0), eAtN 2 (eV 3), eAtN 3 (eV 3), eAtN 4 (eV 3)]))
          (Val.list [adaPubEnc A, adaEnc st2, encVals vals, encQ l, encQ u]) := by
        have hhd : EvalsVal prog M [encOptSt (some st2), adaEnc st1, adaEnc st, inp] []
            (.inl (eHd (eV 0))) (adaEnc st2) :=
          EvalsVal.head (x := adaEnc st2) (l := []) EvalsVal.var0 (by omega)
        refine evalsVal_list (List.Forall₂.cons (hF rfl rfl) (List.Forall₂.cons hhd
          (List.Forall₂.cons (hF rfl rfl) (List.Forall₂.cons (hF rfl rfl)
            (List.Forall₂.cons (hF rfl rfl) List.Forall₂.nil))))) ?_
        simp only [valSize_list, listSize_cons, listSize_nil]
        omega
      exact implements_call_det h606 hargs2
        (adaIvOuter_impl_t hlib hmus hS hL hbs hT hpos hok2 hh2 hv hl hu hMt hMq)

/-- Check: the old statement `adaInterval_impl` is the corollary via `TightM.of_old` (re-derived in place
at swap-in). -/
example {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ adaEntryTable, prog[e.1]? = some e.2)
    (hprep : ∀ e ∈ adaPrepTable, prog[e.1]? = some e.2) (hmus : MusLib prog) (hS : SampLib prog)
    (hL : ListLib prog) (hq : NormQSpec prog M) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq)
    (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) (hMq : 2 ^ 28 * Bq ≤ M) :
    Implements prog M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u) :=
  adaInterval_impl_t hlib hprep hmus hS hL hq hbs hT hpos hok hv hl hu (TightM.of_old hM) hMq

end F2e2e.C.Impl
