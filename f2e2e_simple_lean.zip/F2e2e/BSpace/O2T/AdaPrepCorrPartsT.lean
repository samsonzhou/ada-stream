import F2e2e.C.Impl.AdaPrepCorrParts
import F2e2e.C.Impl.AdaBounds

/-!
# O2b family 9 (owner B-ARCH): the parts of a correction under the tight value premise (delta file)
Promoted from Scratch/O2T/AdaPrepCorrPartsT.lean (owner B-ARCH) at 14:28Z; statements unchanged.

Delta file for `F2e2e/C/Impl/AdaPrepCorrParts.lean` (O2b (iii), `notes/o2_prep/TIGHTEN_ASSIGN.md`): it imports
the original module (bodies `body_adaRedraw` (Idx 706), `body_adaCorrDet` (Idx 705), the generic `apc_…`
helpers, `corrRow_val`, `corrSet_val`) and adds only the tight forms of its two specs,

* `adaRedraw_impl_t … (hthr : CorrThrOK A thr) (hMt : TightM A M)` (tight `adaRedraw_impl`),
* `adaCorrDet_val_t … (hTj) q (hMt : TightM A M)` (tight `adaCorrDet_val`),

with the helpers `apc_tightA_eq`, `apc_redraw_sizes_t`. Each statement is the original one with
`(hMt : TightM A M)` (B-ACC's tight premise, adopted into `F2e2e/C/Impl/AdaBounds.lean`:
`2^8 · tightA A + cAddA A ≤ M`) in place of `(hM : 2 ^ 32 * adaBoundA A ≤ M)`; the originals are corollaries via
`TightM.of_old` (checked by the `example`s at the end; done at the in-place swap after the stage-1 cut, when these
lemmas move into the original file).

Budgets: every value is below `4 · tightA A` (B-ACC's tight size lemmas `valSize_adaEnc_le_t`,
`valSize_adaPubEnc_le_t`, `valSize_encVals_le_t`; corrected rows are rows of the new scores), so each library
call (`corrSet_val` with `Bd := 4 · tightA A`) needs `64 · 4 · tightA A = 2^8 · tightA A ≤ M`; the redraw
sizes are at most `p · (adaZ + 2) + O(p + adaZ) ≤ tightA A`.
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg

section Proof

variable {prog : List Expr} {M : ℕ}

/-- `tightA A = 2 B` with `B = (N + p + 16)(adaZ + 16)`. -/
theorem apc_tightA_eq (A : AdaParams) : tightA A = 2 * ((A.N + A.p + 16) * (adaZ A + 16)) := by
  unfold tightA; ring

theorem apc_redraw_sizes_t {A : AdaParams} (hMt : TightM A M) {t : List ℤ} (ht : CorrThrOK A t)
    {e : ℕ} (he : e ≤ A.p) {k : ℤ} (hk : |k| ≤ (maxKs A : ℤ)) :
    valSize (Val.list [encL encZ t, Val.int (e : ℤ), encZ k]) ≤ M ∧
      S_set (t.map encZ) e (encZ k) ≤ M := by
  have h1 := apc_valSize_thr_le ht
  have h2 := apc_bitLen_le_of_abs_maxKs hk
  have h3 : Nat.size e ≤ A.p := (size_le_self e).trans he
  have hB := apc_tightA_eq A
  have hM : 2 ^ 8 * tightA A + cAddA A ≤ M := hMt
  have hpB := apc_pZ_le_B A
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have hval : valSize (Val.list (t.map encZ)) = valSize (encL encZ t) := rfl
  constructor
  · simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, valSize_encZ, bitLen_natCast]
    omega
  · unfold S_set
    rw [hval, valSize_encZ]
    omega

/-- **Spec of `adaRedraw`, tight premise** (O2b family 9). -/
theorem adaRedraw_impl_t (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {j : ℕ} (hj : j < A.p)
    {thr : List ℤ} (hthr : CorrThrOK A thr) (hMt : TightM A M) :
    Implements prog M [redrawIn A j thr] body_adaRedraw (encL encZ)
      ((redrawThresholds A (reopenEdges A j) thr).toBits (adaDraw A)) := by
  rw [redraw_reopen_toBits]
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hB := apc_tightA_eq A
  have hM : 2 ^ 8 * tightA A + cAddA A ≤ M := hMt
  have hpB := apc_pZ_le_B A
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  have hdraw : drawM A NoiseKind.intThr ≤ M := by have := drawM_le A NoiseKind.intThr; omega
  have hthrS := apc_valSize_thr_le hthr
  have hyM : valSize (redrawIn A j thr) ≤ M := by
    unfold redrawIn
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
    omega
  set y := redrawIn A j thr with hy
  rw [adaPubEnc_eq] at hpubM
  -- fields of the input, in every environment ending with `y`
  have fj : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 0 (eV pre.length)))
      (Val.int (j : ℤ)) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fthr : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 1 (eV pre.length)))
      (encL encZ thr) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fpub : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) [] (.inl (eAtN 2 (eV pre.length)))
      (adaPubEnc A) := fun {pre} =>
    evalsVal_atN' (l := [encN j, encL encZ thr, adaPubEnc A])
      (EvalsVal.var (by simp [hy, redrawIn])) hyM rfl
  have fp : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [y]) []
      (.inl (eAtN 0 (eAtN 2 (eV pre.length)))) (Val.int (A.p : ℤ)) := fun {pre} =>
    evalsVal_atN' (l := pubFields A) (by rw [← adaPubEnc_eq]; exact fpub) hpubM rfl
  have h2M : 2 ≤ M := by omega
  -- step 1
  refine implements_letE_of (encA := encL encZ) (Q := CorrThrOK A) ?_
    (fun bits t h => apc_thrStepIf_run_ok hthr h) ?_
  · have hc := EvalsVal.lt (EvalsVal.lit' (prog := prog) (M := M) (env := [y]) (z := 0)
      (by simp; omega)) (fj (pre := [])) h2M
    by_cases hj1 : 1 ≤ j
    · refine apc_implements_ite_pos hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
      have e1 : thrStepIf A (decide (1 ≤ j)) (j - 1) thr = thrStep A (j - 1) thr := by
        unfold thrStepIf; rw [if_pos (by simpa using hj1)]
      rw [e1]
      refine apc_thrStep_impl hS hL (fpub (pre := [])) (by rw [adaPubEnc_eq]; exact hpubM)
        (fun k => fthr (pre := [encZ k])) (fun k => ?_) hdraw
        (fun k hk => apc_redraw_sizes_t hMt hthr (by omega) hk)
      have e : ((j - 1 : ℕ) : ℤ) = (j : ℤ) - 1 := by push_cast [Nat.cast_sub hj1]; ring
      rw [e]
      refine EvalsVal.sub (fj (pre := [encZ k])) (EvalsVal.lit' (z := 1) (by simp; omega)) ?_
      rw [← e, valSize_int, bitLen_natCast]
      have : Nat.size (j - 1) ≤ A.p := (size_le_self _).trans (by omega)
      omega
    · refine apc_implements_ite_neg hc (by rw [if_neg (by omega)]) ?_
      have e1 : thrStepIf A (decide (1 ≤ j)) (j - 1) thr = BitProg.pure thr := by
        unfold thrStepIf; rw [if_neg (by simpa using hj1)]
      rw [e1]
      exact Implements.of_det (fthr (pre := []))
  intro t1 ht1
  -- step 2
  refine implements_letE_of (encA := encL encZ) (Q := CorrThrOK A) ?_
    (fun bits t h => apc_thrStep_run_ok ht1 h) ?_
  · exact apc_thrStep_impl hS hL (fpub (pre := [encL encZ t1])) (by rw [adaPubEnc_eq]; exact hpubM)
      (fun k => EvalsVal.var1) (fun k => fj (pre := [encZ k, encL encZ t1])) hdraw
      (fun k hk => apc_redraw_sizes_t hMt ht1 hj.le hk)
  intro t2 ht2
  -- step 3
  have hc := EvalsVal.lt (EvalsVal.add (fj (pre := [encL encZ t2, encL encZ t1]))
    (EvalsVal.lit' (z := 1) (by simp; omega)) (by
      simp only [valSize_int]
      have := bitLen_add_le (j : ℤ) 1
      simp only [bitLen_natCast] at this
      have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
      have : bitLen (1 : ℤ) = 1 := by decide
      omega)) (fp (pre := [encL encZ t2, encL encZ t1])) h2M
  by_cases hj2 : j + 1 < A.p
  · refine apc_implements_ite_pos hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
    have e2 : thrStepIf A (decide (j + 1 < A.p)) (j + 1) t2 = thrStep A (j + 1) t2 := by
      unfold thrStepIf; rw [if_pos (by simpa using hj2)]
    rw [e2]
    refine apc_thrStep_impl hS hL (fpub (pre := [encL encZ t2, encL encZ t1]))
      (by rw [adaPubEnc_eq]; exact hpubM) (fun k => EvalsVal.var1) (fun k => ?_) hdraw
      (fun k hk => apc_redraw_sizes_t hMt ht2 (by omega) hk)
    have := EvalsVal.add (fj (pre := [encZ k, encL encZ t2, encL encZ t1]))
      (EvalsVal.lit' (z := 1) (by simp; omega)) (by
        simp only [valSize_int]
        have := bitLen_add_le (j : ℤ) 1
        simp only [bitLen_natCast] at this
        have : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
        have : bitLen (1 : ℤ) = 1 := by decide
        omega)
    simpa using this
  · refine apc_implements_ite_neg hc (by rw [if_neg (by omega)]) ?_
    have e2 : thrStepIf A (decide (j + 1 < A.p)) (j + 1) t2 = BitProg.pure t2 := by
      unfold thrStepIf; rw [if_neg (by simpa using hj2)]
    rw [e2]
    exact Implements.of_det EvalsVal.var0

/-- **Spec of `adaCorrDet`, tight premise** (Idx 705, O2b family 9): on `[j, q, st, pub, vals]` it
returns the corrected scores and the incremented correction counters. -/
theorem adaCorrDet_val_t (hL : ListLib prog) (hlc : prog[Idx.linComb]? = some body_linComb)
    (hlcs : prog[Idx.linCombStep]? = some body_linCombStep) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool) (hMt : TightM A M) :
    EvalsVal prog M [corrIn A st vals j q] [] (.inl body_adaCorrDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) := by
  have hok' : AdaOK A (avState A st vals j q st.thrInt) :=
    avState_ok hok vals q hj hTj hok.thr_len hok.thr_le
  -- sizes
  have hB := apc_tightA_eq A
  have hM : 2 ^ 8 * tightA A + cAddA A ≤ M := hMt
  have hZB := apc_Z_le_B A
  have hPB := apc_p_le_B A
  have h256 : 16 * 16 ≤ (A.N + A.p + 16) * (adaZ A + 16) := Nat.mul_le_mul (by omega) (by omega)
  have hstB := valSize_adaEnc_le_t hok
  have hst'B := valSize_adaEnc_le_t hok'
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hvalsB := valSize_encVals_le_t hbs hv.1 hv.2
  have hscS : valSize (encL (encL encZ) st.scores) < valSize (adaEnc st) :=
    valSize_lt_of_mem (l := apc_stFields st) List.mem_cons_self
  have hTS : valSize (encL encN st.T) < valSize (adaEnc st) :=
    valSize_lt_of_mem (l := apc_stFields st) (List.mem_cons_of_mem _ List.mem_cons_self)
  have hS'S : valSize (encL (encL encZ) (avScores A st vals j q)) <
      valSize (adaEnc (avState A st vals j q st.thrInt)) :=
    valSize_lt_of_mem (l := apc_stFields (avState A st vals j q st.thrInt)) List.mem_cons_self
  have hT'S : valSize (encL encN (st.T.set j (st.T.getD j 0 + 1))) <
      valSize (adaEnc (avState A st vals j q st.thrInt)) :=
    valSize_lt_of_mem (l := apc_stFields (avState A st vals j q st.thrInt))
      (List.mem_cons_of_mem _ List.mem_cons_self)
  have hrowS : valSize (encInts (avRow A st vals j q)) <
      valSize (encL (encL encZ) (avScores A st vals j q)) :=
    valSize_lt_of_mem (List.mem_map_of_mem (f := encL encZ) (apc_avRow_mem hok vals hj q))
  have hsc1S : valSize (encL (encL encZ) (st.scores.set j (avRow A st vals j q))) ≤
      valSize (encL (encL encZ) st.scores) + valSize (encInts (avRow A st vals j q)) := by
    have := apc_valSize_set_le (st.scores.map (encL encZ)) j (encInts (avRow A st vals j q))
    rw [encInts_eq_encL, ← List.map_set] at this
    exact this
  have hsl := hok.scores_len
  have hTl := hok.T_len
  have hvl : vals.length = A.p + 1 := by rw [apc_vals_length hv, hbs]
  have hjT : j < st.T.length := by omega
  have hN : ∀ i, A.blockSizes.getD i 0 ≤ A.N := fun i => getD_le_sum A.blockSizes i
  have hNK : A.N * (2 * (adaZ A + 4) + 3) ≤ 2 * ((A.N + A.p + 16) * (adaZ A + 16)) := by
    calc A.N * (2 * (adaZ A + 4) + 3) ≤ (A.N + A.p + 16) * (2 * (adaZ A + 16)) :=
          Nat.mul_le_mul (by omega) (by omega)
      _ = 2 * ((A.N + A.p + 16) * (adaZ A + 16)) := by ring
  have hfuel : st.T.getD j 0 + 1 ≤ A.fuel := by
    have := getD_le_sum A.Tmax j
    unfold AdaParams.fuel
    omega
  have hTj1 : Nat.size (st.T.getD j 0 + 1) ≤ adaZ A :=
    (Nat.size_le_size hfuel).trans (size_fuel_le_adaZ A)
  have hsj : Nat.size j ≤ A.p := (size_le_self j).trans hj.le
  have h2M : 2 ≤ M := by omega
  -- fields of the input
  have hxM : valSize (Val.list [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals])
      ≤ M := by
    have h2 := apc_bitLen_avSign_le q
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int]
    omega
  have fx : ∀ {pre : List Val} {k : ℕ} {v : Val},
      [encN j, Val.int (avSign q), adaEnc st, adaPubEnc A, encVals vals][k]? = some v →
      EvalsVal prog M (pre ++ [corrIn A st vals j q]) [] (.inl (eAtN k (eV pre.length))) v :=
    fun {pre k v} h => evalsVal_atN' (EvalsVal.var (by simp [corrIn])) hxM h
  have hstM : valSize (Val.list (apc_stFields st)) ≤ M := by
    have : valSize (Val.list (apc_stFields st)) = valSize (adaEnc st) := rfl
    omega
  have fst : ∀ {pre : List Val} {k : ℕ} {v : Val}, (apc_stFields st)[k]? = some v →
      EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
        (.inl (eAtN k (eAtN 2 (eV pre.length)))) v :=
    fun {pre k v} h =>
      evalsVal_atN' (fx (pre := pre) (k := 2) (v := Val.list (apc_stFields st)) rfl) hstM h
  have hpubM : valSize (Val.list (pubFields A)) ≤ M := by
    have : valSize (Val.list (pubFields A)) = valSize (adaPubEnc A) := rfl
    omega
  have ej : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eV pre.length))) (Val.int (j : ℤ)) :=
    fun {pre} => fx (pre := pre) (k := 0) (v := Val.int (j : ℤ)) rfl
  have eq_ : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 1 (eV pre.length))) (Val.int (avSign q)) :=
    fun {pre} => fx (pre := pre) (k := 1) (v := Val.int (avSign q)) rfl
  have evals : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 4 (eV pre.length))) (encVals vals) :=
    fun {pre} => fx (pre := pre) (k := 4) (v := encVals vals) rfl
  have ep : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eAtN 3 (eV pre.length)))) (Val.int (A.p : ℤ)) :=
    fun {pre} => evalsVal_atN' (fx (pre := pre) (k := 3) (v := Val.list (pubFields A)) rfl) hpubM rfl
  have esc : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 0 (eAtN 2 (eV pre.length)))) (encL (encL encZ) st.scores) :=
    fun {pre} => fst (pre := pre) (k := 0) rfl
  have eT : ∀ {pre : List Val}, EvalsVal prog M (pre ++ [corrIn A st vals j q]) []
      (.inl (eAtN 1 (eAtN 2 (eV pre.length)))) (encL encN st.T) :=
    fun {pre} => fst (pre := pre) (k := 1) rfl
  unfold body_adaCorrDet
  -- `sc := st.scores`
  refine apc_letE (esc (pre := [])) ?_
  -- row `j`
  have hlen1 : (st.scores.getD j []).length ≤ A.N := by
    rw [hok.scores_blk j hj]; exact hN j
  refine apc_letE (corrSet_val hL hlc hlcs (K := adaZ A + 4) (Bd := 4 * tightA A)
      (row := avRow A st vals j q) EvalsVal.var0
      (ej (pre := [encL (encL encZ) st.scores]))
      (evals (pre := [encL (encL encZ) st.scores]))
      (EvalsVal.mul (EvalsVal.lit' (z := 4) (by
          rw [valSize_int]; have : bitLen (4 : ℤ) = 3 := by decide
          omega)) (eq_ (pre := [encL (encL encZ) st.scores])) (by
          rw [valSize_int]; have := apc_bitLen_four_avSign_le q; omega))
      (by omega) (by omega)
      (fun z hz => (apc_scores_getD_bitLen hok j z hz).trans (by omega))
      (fun y hy => (apc_vals_getD_bitLen hv j y hy).trans (by omega))
      ((apc_bitLen_four_avSign_le q).trans (by omega)) (by omega)
      (by omega) (by omega)
      (by have := Nat.mul_le_mul hlen1 (le_refl (2 * (adaZ A + 4) + 3))
          omega)
      (apc_avRow_eq_lc hok hv hj q).symm
      (by omega) (by omega)) ?_
  -- row `j + 1` (if any)
  refine apc_letE (va := encL (encL encZ) (avScores A st vals j q)) ?_ ?_
  · have hj1E : EvalsVal prog M ([encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores] ++ [corrIn A st vals j q]) []
        (.inl (eAdd (eAtN 0 (eV 2)) (eLit 1))) (Val.int ((j + 1 : ℕ) : ℤ)) :=
      apc_succ_val (ej (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores])) (by have := size_le_self (j + 1); omega) h2M
    have hc := EvalsVal.lt hj1E (ep (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
        encL (encL encZ) st.scores])) h2M
    by_cases hj1 : j + 1 < A.p
    · refine apc_ite_true hc (by rw [if_pos (by omega)]; exact one_ne_zero) ?_
      have e : avScores A st vals j q =
          (st.scores.set j (avRow A st vals j q)).set (j + 1) (avRow1 A st vals j q) := by
        unfold avScores; rw [if_pos hj1]
      have hrow1S : valSize (encInts (avRow1 A st vals j q)) <
          valSize (encL (encL encZ) (avScores A st vals j q)) :=
        valSize_lt_of_mem (List.mem_map_of_mem (f := encL encZ) (apc_avRow1_mem hok vals hj1 q))
      have hlen2 : ((st.scores.set j (avRow A st vals j q)).getD (j + 1) []).length ≤ A.N := by
        rw [av_getD_set, if_neg (by omega), hok.scores_blk (j + 1) hj1]; exact hN (j + 1)
      rw [e]
      exact corrSet_val hL hlc hlcs (K := adaZ A + 4) (Bd := 4 * tightA A)
        EvalsVal.var0 hj1E
        (evals (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
          encL (encL encZ) st.scores]))
        (EvalsVal.sub (EvalsVal.lit' (z := 0) (by simp; omega))
          (eq_ (pre := [encL (encL encZ) (st.scores.set j (avRow A st vals j q)),
            encL (encL encZ) st.scores])) (by
          rw [zero_sub, valSize_int]; have := apc_bitLen_neg_avSign_le q; omega))
        (by rw [List.length_set]; omega) (by omega)
        (fun z hz => by
          rw [av_getD_set, if_neg (by omega)] at hz
          exact (apc_scores_getD_bitLen hok (j + 1) z hz).trans (by omega))
        (fun y hy => (apc_vals_getD_bitLen hv (j + 1) y hy).trans (by omega))
        (by rw [zero_sub]; exact (apc_bitLen_neg_avSign_le q).trans (by omega)) (by omega)
        (by omega) (by omega)
        (by have := Nat.mul_le_mul hlen2 (le_refl (2 * (adaZ A + 4) + 3))
            have := size_le_self (j + 1)
            omega)
        (by rw [zero_sub]; exact (apc_avRow1_eq_lc hok hv hj1 q).symm)
        (by omega) (by omega)
    · refine apc_ite_false hc (by rw [if_neg (by omega)]) ?_
      have e : avScores A st vals j q = st.scores.set j (avRow A st vals j q) := by
        unfold avScores; rw [if_neg hj1]
      rw [e]
      exact EvalsVal.var0
  -- the counters and the output pair
  · have hTv : valSize (Val.list (st.T.map encN)) = valSize (encL encN st.T) := rfl
    have hp := EvalsVal.pair
      (eT (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
      (ej (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
      (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast]
          omega)
    have hg := get_val hL (l := st.T.map encN) (n := j) hp (by unfold S_get; omega)
    rw [apc_getD_map_lt _ _ hjT _ 0] at hg
    have hs1 := apc_succ_val hg (by omega) h2M
    have hl : EvalsVal prog M ([encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores] ++
          [corrIn A st vals j q]) []
        (.inl (eList [eAtN 1 (eAtN 2 (eV 3)), eAtN 0 (eV 3),
          eAdd (eCall Idx.get (ePair (eAtN 1 (eAtN 2 (eV 3))) (eAtN 0 (eV 3)))) (eLit 1)]))
        (Val.list [Val.list (st.T.map encN), Val.int (j : ℤ),
          Val.int ((st.T.getD j 0 + 1 : ℕ) : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons (eT (pre := [encL (encL encZ) (avScores A st vals j q),
        encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
        (List.Forall₂.cons (ej (pre := [encL (encL encZ) (avScores A st vals j q),
          encL (encL encZ) (st.scores.set j (avRow A st vals j q)), encL (encL encZ) st.scores]))
          (List.Forall₂.cons hs1 List.Forall₂.nil))) (by
        simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hTv ⊢
        omega)
    have hset := set_val hL hl (by
      unfold S_set
      simp only [valSize_int, bitLen_natCast]
      omega)
    have e : Val.list ((st.T.map encN).set j (Val.int ((st.T.getD j 0 + 1 : ℕ) : ℤ))) =
        encL encN (st.T.set j (st.T.getD j 0 + 1)) := by
      unfold encL
      rw [List.map_set]
      rfl
    rw [e] at hset
    exact EvalsVal.pair EvalsVal.var0 hset (by
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega)

/-! ## Integration check: the old statements are corollaries via `TightM.of_old` -/

-- the old `apc_redraw_sizes` (exact statement) is a corollary via `TightM.of_old`
example {A : AdaParams} (hM : 2 ^ 32 * adaBoundA A ≤ M) {t : List ℤ} (ht : CorrThrOK A t)
    {e : ℕ} (he : e ≤ A.p) {k : ℤ} (hk : |k| ≤ (maxKs A : ℤ)) :
    valSize (Val.list [encL encZ t, Val.int (e : ℤ), encZ k]) ≤ M ∧
      S_set (t.map encZ) e (encZ k) ≤ M :=
  apc_redraw_sizes_t (TightM.of_old hM) ht he hk

-- the old `adaRedraw_impl` (exact statement) is a corollary via `TightM.of_old`
example (hS : SampLib prog) (hL : ListLib prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {j : ℕ} (hj : j < A.p)
    {thr : List ℤ} (hthr : CorrThrOK A thr) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    Implements prog M [redrawIn A j thr] body_adaRedraw (encL encZ)
      ((redrawThresholds A (reopenEdges A j) thr).toBits (adaDraw A)) :=
  adaRedraw_impl_t hS hL hbs hT hj hthr (TightM.of_old hM)

-- the old `adaCorrDet_val` (exact statement) is a corollary via `TightM.of_old`
example (hL : ListLib prog) (hlc : prog[Idx.linComb]? = some body_linComb)
    (hlcs : prog[Idx.linCombStep]? = some body_linCombStep) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p) {st : AdaState}
    (hok : AdaOK A st) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hTj : st.T.getD j 0 < A.Tmax.getD j 0) (q : Bool) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [corrIn A st vals j q] [] (.inl body_adaCorrDet)
      (Val.list [encL (encL encZ) (avScores A st vals j q),
        encL encN (st.T.set j (st.T.getD j 0 + 1))]) :=
  adaCorrDet_val_t hL hlc hlcs hbs hT hok hv hj hTj q (TightM.of_old hM)

end Proof

end F2e2e.C.Impl
