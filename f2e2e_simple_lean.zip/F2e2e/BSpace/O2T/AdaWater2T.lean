import F2e2e.C.Impl.AdaWater2
import F2e2e.C.Impl.AdaBounds

/-!
# O2b (iii), family 10 (C-FP, scratch delta file): the predictions under the tight value premise
Promoted from Scratch/O2T/AdaWater2T.lean (owner C-FP) at 14:28Z; statements unchanged.

The `…_t` versions of the routine lemmas of `F2e2e/C/Impl/AdaWater2.lean` (W4's ADA module, part 8): the same
statements with `(hMt : TightM A M)` (`F2e2e/C/Impl/AdaBounds.lean`: `TightM A M := 2^8·tightA A + cAddA A ≤ M`)
for `(hM : 2 ^ 32 * adaBoundA A ≤ M)`:
* `muJL_val_t`, `muJA_val_t`, `muJ_val_t` (the pair of block `j`), `adaMusRImpl_val_t` (Idx 640);
* the tight size facts `adaZ16_le_tightA`, `valSize_musExtra_le_t`, `muJ_env_t`.
At integration (after O1) these lemmas move into `AdaWater2.lean` and every old lemma becomes the corollary
`… hM := …_t … (TightM.of_old hM)`. The private helpers of `AdaWater2.lean` that the proofs need are copied here
with the prefix `w2t_`. The other files of family 10 (`AdaWater`, `AdaWaterMath`, `AdaMusDefs`) have no
`adaBoundA` premise; `AdaMus`'s `adaMusR_val_t` is A-ARCH's (`F2e2e/Scratch/O2T/AdaMusT.lean`).
-/

namespace F2e2e.C.Impl

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete

section W2T

variable {prog : List Expr} {M : ℕ}

private theorem w2t_valSize_list3 (a b c : Val) :
    valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

private theorem w2t_valSize_ints4 (a b c d : ℤ) :
    valSize (Val.list [Val.int a, Val.int b, Val.int c, Val.int d]) =
      bitLen a + bitLen b + bitLen c + bitLen d + 9 := by
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega

private theorem w2t_getD_map_lt {α β : Type} (f : α → β) (l : List α) {j : ℕ} (hj : j < l.length)
    (d : β) (d' : α) : (l.map f).getD j d = f (l.getD j d') := by
  rw [List.getD_eq_getElem _ _ (by simpa using hj), List.getElem_map,
    List.getD_eq_getElem _ _ hj]

private theorem w2t_predNum_bounds {cn cd N D : ℤ} (hcd : 0 ≤ cd) (hD : 0 ≤ D) {V : ℤ} (hV0 : 0 ≤ V) :
    ∀ (g : List ℤ) (v : List ℕ), (∀ y ∈ v, (y : ℤ) ≤ V) →
      0 ≤ predNum cn cd N D g v ∧ predNum cn cd N D g v ≤ g.length * (8 * cd * D * V)
  | [], v, _ => by simp [predNum]
  | x :: xs, [], _ => by
    simp only [predNum, List.zipWith_nil_right, List.sum_nil, le_refl, true_and]
    exact mul_nonneg (by positivity) (mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) hcd) hD) hV0)
  | x :: xs, y :: ys, hv => by
    obtain ⟨h1, h2⟩ := w2t_predNum_bounds hcd hD hV0 xs ys (fun z hz => hv z (List.mem_cons_of_mem _ hz))
    have hy := hv y List.mem_cons_self
    have hH : 0 ≤ 8 * cd * D := by positivity
    have hc0 := clipZ_nonneg (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
    have hc1 := clipZ_le (H := 8 * cd * D) (y := wlS cn cd x * D - N * cd) hH
    have hy0 : (0 : ℤ) ≤ y := by positivity
    have e : predNum cn cd N D (x :: xs) (y :: ys) =
        clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) + predNum cn cd N D xs ys := by
      simp [predNum, List.zipWith_cons_cons]
    rw [e]
    have hm0 : 0 ≤ clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) := mul_nonneg hc0 hy0
    have hm1 : clipZ 0 (8 * cd * D) (wlS cn cd x * D - N * cd) * (y : ℤ) ≤ 8 * cd * D * V :=
      mul_le_mul hc1 hy hy0 hH
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
    constructor <;> nlinarith

private theorem w2t_vals_length_getD {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ}
    (hj : j < vals.length) : (vals.getD j []).length = A.blockSizes.getD j 0 := by
  have := w2t_getD_map_lt List.length vals hj 0 []
  rw [hv.1] at this
  exact this.symm

private theorem w2t_vals_length_eq {A : AdaParams} {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    vals.length = A.blockSizes.length := by
  have := congrArg List.length hv.1
  simpa using this

private theorem w2t_encL_encN_eq_encInts (v : List ℕ) :
    encL encN v = encInts (v.map fun x : ℕ => (x : ℤ)) := by
  simp [encL, encN, encInts, List.map_map, Function.comp_def]

private theorem w2t_encInts_range_eq (n : ℕ) :
    encInts ((List.range n).map fun i : ℕ => (i : ℤ)) = encL encN (List.range n) := by
  simp [encL, encN, encInts, List.map_map, Function.comp_def]

/-- `32 (adaZ + 16) ≤ tightA` (from `N + p + 16 ≥ 16`). -/
theorem adaZ16_le_tightA (A : AdaParams) : 32 * (adaZ A + 16) ≤ tightA A := by
  unfold tightA
  have : 32 ≤ 2 * (A.N + A.p + 16) := by omega
  exact Nat.mul_le_mul_right _ this

theorem valSize_musExtra_le_t {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (musExtra A st.scores vals) ≤ 3 * tightA A := by
  have h1 : valSize (encL (encL encZ) st.scores) ≤ valSize (adaEnc st) :=
    (valSize_lt_of_mem (by simp)).le
  have h2 := valSize_adaEnc_le_t hok
  have h3 := valSize_encVals_le_t hbs hv.1 hv.2
  have hZ16 := sixteen_le_adaZ A
  have hqA := qA_le_adaZ A
  have hpZ := p_le_adaZ A
  have hcn := size_cnum_le_adaZ A
  have hcd := size_cden_le_adaZ A
  have hB := adaZ16_le_tightA A
  unfold musExtra
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN, valSize_int, bitLen,
    Int.natAbs_natCast, Nat.size_pow]
  have := size_le_self A.p
  omega

theorem muJ_env_t {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals)
    {j : ℕ} (hj : j < A.p + 1) :
    valSize (Val.list [encN j, musExtra A st.scores vals]) ≤ 4 * tightA A := by
  have h := valSize_musExtra_le_t hok hbs hv
  have hpZ := p_le_adaZ A
  have hZ16 := sixteen_le_adaZ A
  have hB := adaZ16_le_tightA A
  simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
  have := Nat.size_le_size (show j ≤ A.p by omega)
  have := size_le_self A.p
  omega

/-- **The learned branch.** -/
theorem muJL_val_t (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hMt : TightM A M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJL)
      (encPZ (muLZ A (st.scores.getD j []) (vals.getD j []))) := by
  have hM := hMt
  unfold TightM cAddA at hM
  have hMs : 32 * tightA A ≤ M :=
    le_trans (Nat.mul_le_mul_right _ (by norm_num)) (le_trans (Nat.le_add_right _ _) hM)
  have hW : WB (scoreScale A).num ((scoreScale A).den : ℤ) (st.scores.getD j []) (adaZ A + 2) :=
    wb_block hok hpos hj
  have hcdpos := hW.cd_pos
  have hgne : st.scores.getD j [] ≠ [] := by
    intro h
    have := hpos j (by omega)
    rw [← hok.scores_blk j hj, h] at this
    simp at this
  obtain ⟨N, D, hLv, hD0, -⟩ := wlLevel_spec (cn := (scoreScale A).num) hcdpos hgne
  obtain ⟨hNW, hDW⟩ := wlLevel_ok hW N D hLv
  have hjs : j < st.scores.length := by rw [hok.scores_len]; exact hj
  have hjv : j < vals.length := by rw [w2t_vals_length_eq hv, hbs]; omega
  have hgmem : st.scores.getD j [] ∈ st.scores := by
    rw [List.getD_eq_getElem _ _ hjs]; exact List.getElem_mem hjs
  have hvmem : vals.getD j [] ∈ vals := by
    rw [List.getD_eq_getElem _ _ hjv]; exact List.getElem_mem hjv
  have hvl : (vals.getD j []).length = (st.scores.getD j []).length := by
    rw [w2t_vals_length_getD hv hjv, hok.scores_blk j hj]
  have hvW : ∀ y ∈ vals.getD j [], bitLen (y : ℤ) ≤ adaZ A + 2 := by
    intro y hy
    have h1 := hv.2 _ hvmem y hy
    rw [bitLen_natCast]
    have h2 := Nat.size_le_size h1
    rw [Nat.size_pow] at h2
    have := qA_le_adaZ A
    omega
  -- sizes
  have hstB := valSize_adaEnc_le_t hok
  have hscB : valSize (encL (encL encZ) st.scores) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hstB
  have hgB : valSize (encL encZ (st.scores.getD j [])) ≤ tightA A := by
    have : valSize (encL encZ (st.scores.getD j [])) < valSize (encL (encL encZ) st.scores) :=
      valSize_lt_of_mem (List.mem_map.mpr ⟨_, hgmem, rfl⟩)
    omega
  have hvsB := valSize_encVals_le_t hbs hv.1 hv.2
  have hvB : valSize (encL encN (vals.getD j [])) ≤ tightA A := by
    have : valSize (encL encN (vals.getD j [])) < valSize (encVals vals) := by
      rw [encVals_eq]; exact valSize_lt_of_mem (List.mem_map.mpr ⟨_, hvmem, rfl⟩)
    omega
  have hZB := adaZ16_le_tightA A
  have henvB := muJ_env_t hok hbs hv (j := j) (by omega)
  set a := Val.list [encN j, musExtra A st.scores vals] with ha
  have haM : valSize a ≤ M := by omega
  have hexM : valSize (musExtra A st.scores vals) ≤ M := by
    have := valSize_musExtra_le_t hok hbs hv; omega
  -- step 1: the scores of block `j`
  have lj : EvalsVal prog M [a] [] (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  have lsc : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 1 (eV 0))))
      (Val.list (st.scores.map (encL encZ))) := evalsVal_at2 rfl haM rfl rfl
  have hp1 := EvalsVal.pair lsc lj (by
    have : valSize (Val.list (st.scores.map (encL encZ))) = valSize (encL (encL encZ) st.scores) := rfl
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at this ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h1 := get_val hL.list (l := st.scores.map (encL encZ)) (n := j) hp1 (by
    unfold S_get
    have : valSize (Val.list (st.scores.map (encL encZ))) = valSize (encL (encL encZ) st.scores) := rfl
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [w2t_getD_map_lt (encL encZ) st.scores hjs (Val.int 0) []] at h1
  refine EvalsVal.letE h1 ?_
  -- step 2: the values of block `j`
  have lvals : EvalsVal prog M [encL encZ (st.scores.getD j []), a] [] (.inl (eAtN 1 (eAtN 1 (eV 1))))
      (Val.list (vals.map fun blk => encL encN blk)) := by
    have := evalsVal_at2 (prog := prog) (M := M) (env := [encL encZ (st.scores.getD j []), a]) (k := 1)
      (l := [encN j, musExtra A st.scores vals]) rfl haM (i := 1) (l2 := [encL (encL encZ) st.scores,
        encVals vals, encN (2 ^ A.qA), Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
        encN A.p]) rfl (j := 1) rfl
    rwa [encVals_eq] at this
  have lj1 : EvalsVal prog M [encL encZ (st.scores.getD j []), a] [] (.inl (eAtN 0 (eV 1)))
      (Val.int (j : ℤ)) := evalsVal_at1 rfl haM rfl
  have hvalsM : valSize (Val.list (vals.map fun blk => encL encN blk)) ≤ tightA A := by
    rw [← encVals_eq]; exact hvsB
  have hp2 := EvalsVal.pair lvals lj1 (by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hvalsM ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h2 := get_val hL.list (l := vals.map fun blk => encL encN blk) (n := j) hp2 (by
    unfold S_get
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [w2t_getD_map_lt (fun blk => encL encN blk) vals hjv (Val.int 0) []] at h2
  refine EvalsVal.letE h2 ?_
  -- step 3: the block size
  have hSl : S_length ((st.scores.getD j []).map encZ) ≤ M := by
    unfold S_length
    have e : valSize (Val.list ((st.scores.getD j []).map encZ)) =
        valSize (encL encZ (st.scores.getD j [])) := rfl
    have := hW.n_le
    simp only [List.length_map]
    omega
  have h3 := length_val (M := M) hL.list (l := (st.scores.getD j []).map encZ)
    (EvalsVal.var (env := [encL encN (vals.getD j []), encL encZ (st.scores.getD j []), a]) (i := 1)
      rfl) hSl
  rw [List.length_map] at h3
  refine EvalsVal.letE h3 ?_
  -- step 4: the water level
  set e3 := [encN (st.scores.getD j []).length, encL encN (vals.getD j []),
    encL encZ (st.scores.getD j []), a] with he3
  have lcn3 : EvalsVal prog M e3 [] (.inl (eAtN 3 (eAtN 1 (eV 3)))) (Val.int (scoreScale A).num) :=
    evalsVal_at2 rfl haM rfl rfl
  have lcd3 : EvalsVal prog M e3 [] (.inl (eAtN 4 (eAtN 1 (eV 3))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lg3 : EvalsVal prog M e3 [] (.inl (eV 2)) (encL encZ (st.scores.getD j [])) := EvalsVal.var rfl
  have ln3 : EvalsVal prog M e3 [] (.inl (eV 0)) (Val.int ((st.scores.getD j []).length : ℤ)) :=
    EvalsVal.var rfl
  have hnW := hW.n_cast_le
  have hcnW := hW.cn_le
  have hcdW := hW.cd_le
  have hlvlArg : EvalsVal prog M e3 [] (.inl (eList [Expr.nil, eV 2,
      eList [eV 2, eAtN 3 (eAtN 1 (eV 3)), eAtN 4 (eAtN 1 (eV 3)), eV 0]]))
      (Val.list [encOptPair none, encL encZ (st.scores.getD j []),
        Val.list [encL encZ (st.scores.getD j []), Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ), Val.int ((st.scores.getD j []).length : ℤ)]]) := by
    have hin : EvalsVal prog M e3 [] (.inl (eList [eV 2, eAtN 3 (eAtN 1 (eV 3)),
        eAtN 4 (eAtN 1 (eV 3)), eV 0])) (Val.list [encL encZ (st.scores.getD j []),
          Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
          Val.int ((st.scores.getD j []).length : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons lg3 (List.Forall₂.cons lcn3 (List.Forall₂.cons lcd3
        (List.Forall₂.cons ln3 List.Forall₂.nil))))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]
            have : valSize (encL encZ (st.scores.getD j [])) = 1 + listSize ((st.scores.getD j []).map encZ) := rfl
            omega)
    exact evalsVal_list (List.Forall₂.cons (EvalsVal.nil (by simp; omega))
      (List.Forall₂.cons lg3 (List.Forall₂.cons hin List.Forall₂.nil)))
      (by simp only [encOptPair, valSize_list, listSize_cons, listSize_nil, valSize_int]
          have : valSize (encL encZ (st.scores.getD j [])) = 1 + listSize ((st.scores.getD j []).map encZ) := rfl
          omega)
  have h4 := evalsVal_call_det hL.levelFold hlvlArg
    (wlLevelFold_val hL.folds hL.tryR hL.levelStep hL.levelEl hW (by clear hM hMt; omega))
  rw [hLv] at h4
  refine EvalsVal.letE h4 ?_
  -- step 5: the numerator
  set e4 := encOptPair (some (N, D)) :: e3 with he4
  have lN4 : EvalsVal prog M e4 [] (.inl (eAtN 0 (eV 0))) (Val.int N) :=
    evalsVal_at1 rfl (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lD4 : EvalsVal prog M e4 [] (.inl (eAtN 1 (eV 0))) (Val.int D) :=
    evalsVal_at1 rfl (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lcn4 : EvalsVal prog M e4 [] (.inl (eAtN 3 (eAtN 1 (eV 4)))) (Val.int (scoreScale A).num) :=
    evalsVal_at2 rfl haM rfl rfl
  have lcd4 : EvalsVal prog M e4 [] (.inl (eAtN 4 (eAtN 1 (eV 4))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lv4 : EvalsVal prog M e4 [] (.inl (eV 2)) (encL encN (vals.getD j [])) := EvalsVal.var rfl
  have lg4 : EvalsVal prog M e4 [] (.inl (eV 3)) (encL encZ (st.scores.getD j [])) := EvalsVal.var rfl
  have hpnArg : EvalsVal prog M e4 [] (.inl (eList [eList [eLit 0, eV 2], eV 3,
      eList [eAtN 0 (eV 0), eAtN 1 (eV 0), eAtN 3 (eAtN 1 (eV 4)), eAtN 4 (eAtN 1 (eV 4))]]))
      (Val.list [encPN (0, vals.getD j []), encL encZ (st.scores.getD j []),
        Val.list [Val.int N, Val.int D, Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ)]]) := by
    have hpn0 : EvalsVal prog M e4 [] (.inl (eList [eLit 0, eV 2])) (encPN (0, vals.getD j [])) :=
      evalsVal_list (List.Forall₂.cons (EvalsVal.lit (by simp; omega))
        (List.Forall₂.cons lv4 List.Forall₂.nil))
        (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_zero]; omega)
    have hex4 : EvalsVal prog M e4 [] (.inl (eList [eAtN 0 (eV 0), eAtN 1 (eV 0),
        eAtN 3 (eAtN 1 (eV 4)), eAtN 4 (eAtN 1 (eV 4))]))
        (Val.list [Val.int N, Val.int D, Val.int (scoreScale A).num,
          Val.int ((scoreScale A).den : ℤ)]) :=
      evalsVal_list (List.Forall₂.cons lN4 (List.Forall₂.cons lD4 (List.Forall₂.cons lcn4
        (List.Forall₂.cons lcd4 List.Forall₂.nil))))
        (by rw [w2t_valSize_ints4]; omega)
    exact evalsVal_list (List.Forall₂.cons hpn0 (List.Forall₂.cons lg4 (List.Forall₂.cons hex4
      List.Forall₂.nil)))
      (by rw [w2t_valSize_list3, valSize_encPN, w2t_valSize_ints4]; simp only [bitLen_zero]; omega)
  have h5 := evalsVal_call_det hL.pnFold hpnArg
    (pnFold_val hL.pnStep hL.pnEl hW hNW hD0 hDW hvl hvW (by clear hM hMt; omega))
  refine EvalsVal.letE h5 ?_
  -- step 6: the pair
  set e5 := encPN (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
    (vals.getD j []), []) :: e4 with he5
  have hpnB := w2t_predNum_bounds (cn := (scoreScale A).num) (N := N) hcdpos.le hD0.le
    (V := 2 ^ A.qA) (by positivity) (st.scores.getD j []) (vals.getD j [])
    (fun y hy => by exact_mod_cast hv.2 _ hvmem y hy)
  have hq : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
    unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
  have hqZ := qA_le_adaZ A
  have hPB : bitLen (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
      (vals.getD j [])) ≤ 8 * (adaZ A + 2) + 8 := by
    have e1 := bitLen_le_of_nonneg_le hpnB.1 hpnB.2
    have e2 := bitLen_mul_le ((st.scores.getD j []).length : ℤ)
      (8 * ((scoreScale A).den : ℤ) * D * 2 ^ A.qA)
    have e3 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ) * D) (2 ^ A.qA)
    have e4 := bitLen_mul_le (8 * ((scoreScale A).den : ℤ)) D
    have e5 := bitLen_mul_le 8 ((scoreScale A).den : ℤ)
    rw [bitLen_eight] at e5
    omega
  have lpr : EvalsVal prog M e5 [] (.inl (eAtN 0 (eV 0)))
      (Val.int (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
        (vals.getD j []))) :=
    evalsVal_at1 rfl (by simp only [encL_nil, valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  have lH : EvalsVal prog M e5 [] (.inl (eAtN 2 (eAtN 1 (eV 5)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_at2 rfl haM rfl rfl
  have ln5 : EvalsVal prog M e5 [] (.inl (eV 2)) (Val.int ((st.scores.getD j []).length : ℤ)) :=
    EvalsVal.var rfl
  have lcd5 : EvalsVal prog M e5 [] (.inl (eAtN 4 (eAtN 1 (eV 5))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  have lD5 : EvalsVal prog M e5 [] (.inl (eAtN 1 (eV 1))) (Val.int D) :=
    evalsVal_at1 rfl (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega) rfl
  set zden := ZE.mul (ZE.mul (ZE.mul (ZE.leaf (eAtN 2 (eAtN 1 (eV 5))) ((2 ^ A.qA : ℕ) : ℤ))
      (ZE.leaf (eV 2) ((st.scores.getD j []).length : ℤ)))
      (ZE.leaf (eAtN 4 (eAtN 1 (eV 5))) ((scoreScale A).den : ℤ))) (ZE.leaf (eAtN 1 (eV 1)) D)
    with hzden
  have hcast : ((2 ^ A.qA : ℕ) : ℤ) = (2 : ℤ) ^ A.qA := by push_cast; rfl
  have hHb : bitLen ((2 ^ A.qA : ℕ) : ℤ) ≤ 2 * (adaZ A + 2) := by rw [hcast, hq]; omega
  have hzE : EvalsVal prog M e5 [] (.inl zden.toExpr) (Val.int zden.val) :=
    ZE.spec' (W := 2 * (adaZ A + 2)) (by simp only [hzden, ZE.OK]; exact ⟨⟨⟨lH, ln5⟩, lcd5⟩, lD5⟩)
      (by simp only [hzden, ZE.LeafLe]; omega) (by simp only [hzden, ZE.cb]; omega)
  have hzB := ZE.bitLen_val_le_cb (e := zden) (W := 2 * (adaZ A + 2))
    (by simp only [hzden, ZE.LeafLe]; omega)
  have hzcb : zden.cb (2 * (adaZ A + 2)) ≤ 8 * (adaZ A + 2) := by simp only [hzden, ZE.cb]; omega
  have hres : encPZ (muLZ A (st.scores.getD j []) (vals.getD j [])) =
      Val.list [Val.int (predNum (scoreScale A).num ((scoreScale A).den : ℤ) N D (st.scores.getD j [])
        (vals.getD j [])), Val.int zden.val] := by
    unfold muLZ
    rw [hLv]
    simp only [encPZ, hzden, ZE.val, hcast]
  rw [hres]
  exact evalsVal_list (List.Forall₂.cons lpr (List.Forall₂.cons hzE List.Forall₂.nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)

/-- **The anchor branch.** -/
theorem muJA_val_t (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ}
    (hj : j < A.p + 1) (hMt : TightM A M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJA)
      (encPZ (muAZ A (vals.getD j []))) := by
  have hM := hMt
  unfold TightM cAddA at hM
  have hjv : j < vals.length := by rw [w2t_vals_length_eq hv, hbs]; exact hj
  have hvmem : vals.getD j [] ∈ vals := by
    rw [List.getD_eq_getElem _ _ hjv]; exact List.getElem_mem hjv
  have hvsB := valSize_encVals_le_t hbs hv.1 hv.2
  have hvB : valSize (encL encN (vals.getD j [])) ≤ tightA A := by
    have : valSize (encL encN (vals.getD j [])) < valSize (encVals vals) := by
      rw [encVals_eq]; exact valSize_lt_of_mem (List.mem_map.mpr ⟨_, hvmem, rfl⟩)
    omega
  have hZB := adaZ16_le_tightA A
  have henvB := muJ_env_t hok hbs hv hj
  set a := Val.list [encN j, musExtra A st.scores vals] with ha
  have haM : valSize a ≤ M := by omega
  have lvals : EvalsVal prog M [a] [] (.inl (eAtN 1 (eAtN 1 (eV 0))))
      (Val.list (vals.map fun blk => encL encN blk)) := by
    have := evalsVal_at2 (prog := prog) (M := M) (env := [a]) (k := 0)
      (l := [encN j, musExtra A st.scores vals]) rfl haM (i := 1) (l2 := [encL (encL encZ) st.scores,
        encVals vals, encN (2 ^ A.qA), Val.int (scoreScale A).num, Val.int ((scoreScale A).den : ℤ),
        encN A.p]) rfl (j := 1) rfl
    rwa [encVals_eq] at this
  have lj : EvalsVal prog M [a] [] (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) :=
    evalsVal_at1 rfl haM rfl
  have hvalsM : valSize (Val.list (vals.map fun blk => encL encN blk)) ≤ tightA A := by
    rw [← encVals_eq]; exact hvsB
  have hp := EvalsVal.pair lvals lj (by
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_int, bitLen_natCast] at hvalsM ⊢
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  have h1 := get_val hL.list (l := vals.map fun blk => encL encN blk) (n := j) hp (by
    unfold S_get
    have := Nat.size_le_size (show j ≤ A.p by omega)
    have := p_le_adaZ A
    have := size_le_self A.p
    omega)
  rw [w2t_getD_map_lt (fun blk => encL encN blk) vals hjv (Val.int 0) []] at h1
  refine EvalsVal.letE h1 ?_
  -- the sum and the length
  set v := vals.getD j [] with hvdef
  have hvlen : v.length ≤ A.N := by rw [hvdef, w2t_vals_length_getD hv hjv]; exact getD_le_sum _ _
  have hvb : ∀ z ∈ v.map (fun x : ℕ => (x : ℤ)), |z| < 2 ^ (A.qA + 1) := by
    intro z hz
    obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hz
    have h1 : x ≤ 2 ^ A.qA := hv.2 _ hvmem x hx
    have h2 : (x : ℤ) < 2 ^ (A.qA + 1) := by
      have : (x : ℤ) ≤ 2 ^ A.qA := by exact_mod_cast h1
      have : (2 : ℤ) ^ A.qA < 2 ^ (A.qA + 1) := by
        rw [pow_succ]; have : (0:ℤ) < 2 ^ A.qA := by positivity
        linarith
      linarith
    rw [abs_of_nonneg (by positivity)]
    exact h2
  have hqZ := qA_le_adaZ A
  have hNZ := size_N_le_adaZ A
  set e1 := encL encN v :: [a] with he1
  have hSs : S_sum (v.map fun x : ℕ => (x : ℤ)) (A.qA + 1) ≤ M := by
    unfold S_sum
    rw [← w2t_encL_encN_eq_encInts]
    have := Nat.size_le_size hvlen
    simp only [List.length_map]
    omega
  have hs : EvalsVal prog M e1 [] (.inl (eCall Idx.sum (eV 0)))
      (Val.int (v.map fun x : ℕ => (x : ℤ)).sum) :=
    evalsVal_call_det hL.sum (EvalsVal.var (env := e1) (i := 0)
      (v := encInts (v.map fun x : ℕ => (x : ℤ))) (by rw [he1, w2t_encL_encN_eq_encInts]; rfl))
      ((sum_spec hL.sumStep (v.map fun x : ℕ => (x : ℤ)) (A.qA + 1) hvb 0).toVal.mono_M hSs)
  have hlen := length_val (M := M) hL.list (l := v.map encN) (EvalsVal.var (env := e1) (i := 0) rfl)
    (by unfold S_length
        have := Nat.size_le_size hvlen
        have : valSize (Val.list (v.map encN)) = valSize (encL encN v) := rfl
        simp only [List.length_map]
        omega)
  rw [List.length_map] at hlen
  have lH : EvalsVal prog M e1 [] (.inl (eAtN 2 (eAtN 1 (eV 1)))) (Val.int ((2 ^ A.qA : ℕ) : ℤ)) :=
    evalsVal_at2 rfl haM rfl rfl
  set zden := ZE.mul (ZE.leaf (eAtN 2 (eAtN 1 (eV 1))) ((2 ^ A.qA : ℕ) : ℤ))
    (ZE.leaf (eCall Idx.length (eV 0)) (v.length : ℤ)) with hzden
  have hq : bitLen (((2 ^ A.qA : ℕ) : ℤ)) = A.qA + 1 := by
    rw [bitLen_natCast, Nat.size_pow]
  have hnv : bitLen (v.length : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]; exact (Nat.size_le_size hvlen).trans hNZ
  have hzE : EvalsVal prog M e1 [] (.inl zden.toExpr) (Val.int zden.val) :=
    ZE.spec' (W := adaZ A + 1) (by simp only [hzden, ZE.OK]; exact ⟨lH, hlen⟩)
      (by simp only [hzden, ZE.LeafLe]; omega) (by simp only [hzden, ZE.cb]; omega)
  have hs0 : 0 ≤ (v.map fun x : ℕ => (x : ℤ)).sum :=
    List.sum_nonneg (by intro y hy; obtain ⟨x, -, rfl⟩ := List.mem_map.mp hy; positivity)
  have hs1 : (v.map fun x : ℕ => (x : ℤ)).sum ≤ (v.length : ℤ) * 2 ^ A.qA := by
    have := List.sum_le_card_nsmul (v.map fun x : ℕ => (x : ℤ)) (2 ^ A.qA) (by
      intro y hy
      obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
      exact_mod_cast hv.2 _ hvmem x hx)
    simpa using this
  have hq' : bitLen ((2 : ℤ) ^ A.qA) = A.qA + 1 := by
    unfold bitLen; rw [Int.natAbs_pow]; simp [Nat.size_pow]
  have hsB : bitLen (v.map fun x : ℕ => (x : ℤ)).sum ≤ 2 * adaZ A + 1 := by
    have e1 := bitLen_le_of_nonneg_le hs0 hs1
    have e2 := bitLen_mul_le (v.length : ℤ) (2 ^ A.qA)
    omega
  have hres : encPZ (muAZ A v) = Val.list [Val.int (v.map fun x : ℕ => (x : ℤ)).sum,
      Val.int zden.val] := by
    simp only [encPZ, muAZ, hzden, ZE.val]
    push_cast
    rfl
  rw [hres]
  have hzB := ZE.bitLen_val_le_cb (e := zden) (W := adaZ A + 1)
    (by simp only [hzden, ZE.LeafLe]; omega)
  have hzcb : zden.cb (adaZ A + 1) ≤ 2 * adaZ A + 2 := by simp only [hzden, ZE.cb]; omega
  exact evalsVal_list (List.Forall₂.cons hs (List.Forall₂.cons hzE List.Forall₂.nil))
    (by simp only [valSize_list, listSize_cons, listSize_nil, valSize_int]; omega)

/-- **The pair of block `j`.** -/
theorem muJ_val_t (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p + 1)
    (hMt : TightM A M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl body_muJ)
      (encPZ (muJZ A st.scores vals j)) := by
  have hM := hMt
  unfold TightM cAddA at hM
  have hZB := adaZ16_le_tightA A
  have henvB := muJ_env_t hok hbs hv hj
  have haM : valSize (Val.list [encN j, musExtra A st.scores vals]) ≤ M := by omega
  have lj : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] []
      (.inl (eAtN 0 (eV 0))) (Val.int (j : ℤ)) := evalsVal_at1 rfl haM rfl
  have lp : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] []
      (.inl (eAtN 5 (eAtN 1 (eV 0)))) (Val.int (A.p : ℤ)) := evalsVal_at2 rfl haM rfl rfl
  set c := ZE.lt (ZE.leaf (eAtN 0 (eV 0)) (j : ℤ)) (ZE.leaf (eAtN 5 (eAtN 1 (eV 0))) (A.p : ℤ))
    with hc
  have hpZ := p_le_adaZ A
  have hcE : EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl c.toExpr)
      (Val.int c.val) :=
    ZE.spec' (W := adaZ A) (by simp only [hc, ZE.OK]; exact ⟨lj, lp⟩)
      (by
        simp only [hc, ZE.LeafLe, bitLen_natCast]
        have := Nat.size_le_size (show j ≤ A.p by omega)
        have := size_le_self A.p
        omega)
      (by simp only [hc, ZE.cb]; omega)
  unfold muJZ
  by_cases hjp : j < A.p
  · rw [if_pos hjp]
    have hv1 : c.val ≠ 0 := by simp [hc, ZE.val, hjp]
    exact EvalsVal.ite_true hcE hv1 (muJL_val_t hL hok hbs hpos hv hjp hMt)
  · rw [if_neg hjp]
    have hv0 : c.val = 0 := by simp [hc, ZE.val, hjp]
    exact EvalsVal.ite_false hcE hv0 (muJA_val_t hL hok hbs hv hj hMt)

/-- **Spec of `adaMusR`.** -/
theorem adaMusRImpl_val_t (hL : MusLibImpl prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hMt : TightM A M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusRImpl) (encL encPZ (musZ A st.scores vals)) := by
  have hM := hMt
  unfold TightM cAddA at hM
  have hZB := adaZ16_le_tightA A
  have hpubB := valSize_adaPubEnc_le_t A hbs hT
  have hstB := valSize_adaEnc_le_t hok
  have hscB : valSize (encL (encL encZ) st.scores) ≤ tightA A :=
    le_trans (valSize_lt_of_mem (by simp)).le hstB
  have hvsB := valSize_encVals_le_t hbs hv.1 hv.2
  have hpZ := p_le_adaZ A
  set a := Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals] with ha
  have haM : valSize a ≤ M := by
    simp only [ha, valSize_list, listSize_cons, listSize_nil]
    omega
  have hpubM : valSize (adaPubEnc A) ≤ M := by omega
  -- pub fields
  have lp : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 0 (eV 0)))) (encN A.p) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have lH : EvalsVal prog M [a] [] (.inl (eAtN 8 (eAtN 0 (eV 0)))) (encN (2 ^ A.qA)) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have lc : EvalsVal prog M [a] [] (.inl (eAtN 11 (eAtN 0 (eV 0)))) (encQ (scoreScale A)) :=
    evalsVal_atN' (evalsVal_at1 rfl haM rfl) hpubM (l := pubFields A) rfl
  have hcM : valSize (encQ (scoreScale A)) ≤ M :=
    le_trans (valSize_le_of_getElem? (l := pubFields A) (n := 11) rfl) hpubM
  have lcn : EvalsVal prog M [a] [] (.inl (eAtN 0 (eAtN 11 (eAtN 0 (eV 0)))))
      (Val.int (scoreScale A).num) := evalsVal_atN' lc hcM rfl
  have lcd : EvalsVal prog M [a] [] (.inl (eAtN 1 (eAtN 11 (eAtN 0 (eV 0)))))
      (Val.int ((scoreScale A).den : ℤ)) := evalsVal_atN' lc hcM rfl
  have lsc : EvalsVal prog M [a] [] (.inl (eAtN 1 (eV 0))) (encL (encL encZ) st.scores) :=
    evalsVal_at1 rfl haM rfl
  have lvs : EvalsVal prog M [a] [] (.inl (eAtN 2 (eV 0))) (encVals vals) :=
    evalsVal_at1 rfl haM rfl
  -- the extra record
  have hexB := valSize_musExtra_le_t hok hbs hv
  have hex : EvalsVal prog M [a] [] (.inl (eList [eAtN 1 (eV 0), eAtN 2 (eV 0),
      eAtN 8 (eAtN 0 (eV 0)), eAtN 0 (eAtN 11 (eAtN 0 (eV 0))), eAtN 1 (eAtN 11 (eAtN 0 (eV 0))),
      eAtN 0 (eAtN 0 (eV 0))])) (musExtra A st.scores vals) :=
    evalsVal_list (List.Forall₂.cons lsc (List.Forall₂.cons lvs (List.Forall₂.cons lH
      (List.Forall₂.cons lcn (List.Forall₂.cons lcd (List.Forall₂.cons lp List.Forall₂.nil))))))
      (by unfold musExtra at hexB; omega)
  -- size facts
  have hB1 : (A.N + A.p + 16) * (adaZ A + 16) ≤ tightA A := by
    unfold tightA; nlinarith
  have hsp1 : Nat.size (A.p + 1) ≤ A.p + 1 := size_le_self _
  have hPZ : (A.p + 1) * (adaZ A + 16) ≤ tightA A := le_trans (Nat.mul_le_mul_right _ (by omega)) hB1
  have hPZ2 : (A.p + 2) * (adaZ A + 16) ≤ tightA A :=
    le_trans (Nat.mul_le_mul_right _ (by omega)) hB1
  have hPZ3 : (A.p + 2) * (adaZ A + 16) = (A.p + 1) * (adaZ A + 16) + (adaZ A + 16) := by ring
  have hrangeV : valSize (encL encN (List.range (A.p + 1))) ≤ tightA A := by
    have := valSize_encL_le encN (List.range (A.p + 1)) (adaZ A + 2) (fun i hi => by
      rw [valSize_encN]
      have := Nat.size_le_size (show i ≤ A.p + 1 by have := List.mem_range.mp hi; omega)
      omega)
    simp only [List.length_range] at this
    have : (A.p + 1) * (adaZ A + 2 + 1) ≤ (A.p + 1) * (adaZ A + 16) := Nat.mul_le_mul_left _ (by omega)
    omega
  -- the index list `0..p`
  set zp := ZE.add (ZE.leaf (eAtN 0 (eAtN 0 (eV 0))) (A.p : ℤ)) (ZE.lit 1) with hzp
  have hzpOK : zp.OK prog M [a] := by simp only [hzp, ZE.OK]; exact ⟨lp, trivial⟩
  have hspZ : bitLen (A.p : ℤ) ≤ adaZ A := by
    rw [bitLen_natCast]; exact (size_le_self A.p).trans hpZ
  have hzpL : zp.LeafLe (adaZ A) := by simp only [hzp, ZE.LeafLe]; exact ⟨hspZ, trivial⟩
  have hzpC : zp.cb (adaZ A) + 1 ≤ M := by simp only [hzp, ZE.cb, bitLen_one]; omega
  have hzpE : EvalsVal prog M [a] [] (.inl zp.toExpr) (Val.int zp.val) := ZE.spec' hzpOK hzpL hzpC
  have hzpv : zp.val = ((A.p + 1 : ℕ) : ℤ) := by simp [hzp, ZE.val]
  rw [hzpv] at hzpE
  have hrange := evalsVal_call_det hL.range hzpE
    ((range_spec hL.rangeStep (A.p + 1) 0).toVal.mono_M (by
      unfold S_range
      have : (A.p + 1) * (Nat.size (A.p + 1) + 2) ≤ (A.p + 1) * (adaZ A + 16) :=
        Nat.mul_le_mul_left _ (by omega)
      omega))
  rw [w2t_encInts_range_eq] at hrange
  -- the map
  have hmap := mapB_impl hL.musMapStep hL.muJ hL.list.reverse hL.list.revAppendStep encN encPZ
    (musExtra A st.scores vals) (fun j => BitProg.pure (muJZ A st.scores vals j))
    (List.range (A.p + 1)) (16 * (adaZ A + 2) + 21)
    (fun j hj => Implements.of_det (muJ_val_t hL hok hbs hpos hv (List.mem_range.mp hj) hMt))
    (fun j hj bits b hb => by
      obtain ⟨-, rfl⟩ := bitProg_run_pure_exact.mp hb
      obtain ⟨h1, h2⟩ := muJZ_bits hok hbs hpos hv (List.mem_range.mp hj)
      rw [show muJZ A st.scores vals j = ((muJZ A st.scores vals j).1, (muJZ A st.scores vals j).2)
        from rfl, valSize_encPZ]
      omega)
    (by
      unfold mapB_M
      simp only [List.length_range]
      have : (A.p + 1) * (16 * (adaZ A + 2) + 21 + 1) ≤ 16 * ((A.p + 1) * (adaZ A + 16)) := by
        nlinarith
      omega)
  rw [mapB_pure] at hmap
  have := evalsVal_call_det hL.musMap
    (evalsVal_list (List.Forall₂.cons hrange (List.Forall₂.cons hex List.Forall₂.nil)) (by
      simp only [valSize_list, listSize_cons, listSize_nil]
      have : valSize (musExtra A st.scores vals) ≤ 3 * tightA A := hexB
      omega))
    (hmap [] _ rfl)
  rw [musZ_eq_map]
  exact this

/-! ### Checks: the old statements are corollaries of the `_t` lemmas (the post-cut rewrite) -/

example {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (musExtra A st.scores vals) ≤ 3 * adaBoundA A := by
  have h := valSize_musExtra_le_t hok hbs hv
  rw [adaBoundA_eq_tightA]
  omega

example {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals)
    {j : ℕ} (hj : j < A.p + 1) :
    valSize (Val.list [encN j, musExtra A st.scores vals]) ≤ 4 * adaBoundA A := by
  have h := muJ_env_t hok hbs hv hj
  rw [adaBoundA_eq_tightA]
  omega

example (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJL)
      (encPZ (muLZ A (st.scores.getD j []) (vals.getD j []))) :=
  muJL_val_t hL hok hbs hpos hv hj (TightM.of_old hM)

example (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ}
    (hj : j < A.p + 1) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl muJA)
      (encPZ (muAZ A (vals.getD j []))) :=
  muJA_val_t hL hok hbs hv hj (TightM.of_old hM)

example (hL : MusLibImpl prog) {A : AdaParams} {st : AdaState} (hok : AdaOK A st)
    (hbs : A.blockSizes.length = A.p + 1) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {j : ℕ} (hj : j < A.p + 1)
    (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [encN j, musExtra A st.scores vals]] [] (.inl body_muJ)
      (encPZ (muJZ A st.scores vals j)) :=
  muJ_val_t hL hok hbs hpos hv hj (TightM.of_old hM)

example (hL : MusLibImpl prog) {A : AdaParams}
    (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) (hM : 2 ^ 32 * adaBoundA A ≤ M) :
    EvalsVal prog M [Val.list [adaPubEnc A, encL (encL encZ) st.scores, encVals vals]] []
      (.inl body_adaMusRImpl) (encL encPZ (musZ A st.scores vals)) :=
  adaMusRImpl_val_t hL hbs hT hpos hok hv (TightM.of_old hM)

end W2T

end F2e2e.C.Impl
