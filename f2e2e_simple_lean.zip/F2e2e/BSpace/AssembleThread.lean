import F2e2e.Spec
import F2e2e.Lib.Discrete.BitProg

/-!
# B_space, top level (C-TOP): threaded runs of an initialization and rounds on one tape

The mechanism of `Theorem_B_space` reads ONE random tape, threaded through the initialization and all requests
(never rewound). At the level of bit programs:

* `threadRun init round tape t`: the state after the initialization and the rounds `0, …, t-1`, together with the
  unread tape, when the bit programs `init`, `round 0`, `round 1`, … run one after the other on `tape` (`none` as
  soon as one of them fails, i.e. runs out of tape);
* `threadOut init round tape t`: the output of round `t`.

`exec_of_thread` turns threaded bit-program runs into an execution of two programs in the format of the Spec's
`VImplExec` (states, unread tapes, the initialization run, every round run, parsed responses), for any run
predicate `Runs` (oracle first, as the Spec's `RunsWithinBitsO`). It suffices that every run of `init` (resp.
`round t`, from a state satisfying the invariant `Inv`) is a `Runs`-run of the initialization (resp. round)
program on the encoded data, producing a state that satisfies `Inv`, that the threaded run never fails, and that
the encoded outputs parse to the given responses.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete

variable {σ ρ : Type}

/-- The state and the unread tape after the initialization and the rounds `0, …, t-1`, the bit programs running
one after the other on `tape`. -/
def threadRun (init : BitProg σ) (round : ℕ → σ → BitProg (ρ × σ)) (tape : List Bool) :
    ℕ → Option (σ × List Bool)
  | 0 => init.run tape
  | t + 1 => (threadRun init round tape t).bind fun p =>
      ((round t p.1).run p.2).map fun r => (r.1.2, r.2)

/-- The output of round `t` of the threaded run. -/
def threadOut (init : BitProg σ) (round : ℕ → σ → BitProg (ρ × σ)) (tape : List Bool) (t : ℕ) :
    Option ρ :=
  (threadRun init round tape t).bind fun p => ((round t p.1).run p.2).map fun r => r.1.1

section

variable {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)} {tape : List Bool}

theorem threadRun_zero : threadRun init round tape 0 = init.run tape := rfl

theorem threadRun_succ_of {t : ℕ} {st : σ} {τ : List Bool}
    (h : threadRun init round tape t = some (st, τ)) :
    threadRun init round tape (t + 1) = ((round t st).run τ).map fun r => (r.1.2, r.2) := by
  rw [threadRun, h, Option.bind_some]

theorem threadOut_of {t : ℕ} {st : σ} {τ : List Bool}
    (h : threadRun init round tape t = some (st, τ)) :
    threadOut init round tape t = ((round t st).run τ).map fun r => r.1.1 := by
  rw [threadOut, h, Option.bind_some]

/-- A state of the threaded run after `t + 1` rounds comes from a state after `t` rounds and a run of
round `t`. -/
theorem threadRun_succ_eq_some {t : ℕ} {st' : σ} {τ' : List Bool}
    (h : threadRun init round tape (t + 1) = some (st', τ')) :
    ∃ st τ r, threadRun init round tape t = some (st, τ) ∧
      (round t st).run τ = some ((r, st'), τ') := by
  rw [threadRun] at h
  cases ht : threadRun init round tape t with
  | none => rw [ht] at h; simp at h
  | some p =>
    obtain ⟨st, τ⟩ := p
    rw [ht, Option.bind_some] at h
    obtain ⟨⟨⟨r, st1⟩, τ1⟩, hrun, heq⟩ := Option.map_eq_some_iff.mp h
    simp only [Prod.mk.injEq] at heq
    obtain ⟨rfl, rfl⟩ := heq
    exact ⟨st, τ, r, rfl, hrun⟩

/-- The output of round `t` comes from a state after `t` rounds and a run of round `t`. -/
theorem threadOut_eq_some {t : ℕ} {r : ρ} (h : threadOut init round tape t = some r) :
    ∃ st τ st' τ', threadRun init round tape t = some (st, τ) ∧
      (round t st).run τ = some ((r, st'), τ') := by
  rw [threadOut] at h
  cases ht : threadRun init round tape t with
  | none => rw [ht] at h; simp at h
  | some p =>
    obtain ⟨st, τ⟩ := p
    rw [ht, Option.bind_some] at h
    obtain ⟨⟨⟨r1, st1⟩, τ1⟩, hrun, heq⟩ := Option.map_eq_some_iff.mp h
    simp only at heq
    subst heq
    exact ⟨st, τ, st1, τ1, rfl, hrun⟩

theorem threadRun_isSome_of_succ {t : ℕ} (h : (threadRun init round tape (t + 1)).isSome) :
    (threadRun init round tape t).isSome := by
  rw [threadRun] at h
  cases ht : threadRun init round tape t with
  | none => rw [ht] at h; simp at h
  | some p => rfl

/-- If the threaded run never fails, every state of it exists and satisfies an invariant preserved by the
initialization and the rounds. -/
theorem threadRun_inv (Inv : σ → Prop)
    (hinit : ∀ st τ, init.run tape = some (st, τ) → Inv st)
    (hround : ∀ t st τ r st' τ', Inv st → (round t st).run τ = some ((r, st'), τ') → Inv st')
    (htot : ∀ t, (threadRun init round tape (t + 1)).isSome) :
    ∀ t, ∃ st τ, threadRun init round tape t = some (st, τ) ∧ Inv st := by
  intro t
  induction t with
  | zero =>
    have h0 := threadRun_isSome_of_succ (htot 0)
    rw [threadRun_zero] at h0
    obtain ⟨⟨st, τ⟩, hst⟩ := Option.isSome_iff_exists.mp h0
    exact ⟨st, τ, hst, hinit st τ hst⟩
  | succ t ih =>
    obtain ⟨st, τ, h, hInv⟩ := ih
    have h1 := htot t
    rw [threadRun_succ_of h, Option.isSome_map] at h1
    obtain ⟨⟨⟨r, st'⟩, τ'⟩, hrun⟩ := Option.isSome_iff_exists.mp h1
    refine ⟨st', τ', ?_, hround t st τ r st' τ' hInv hrun⟩
    rw [threadRun_succ_of h, hrun]
    rfl

end

/-- **Threaded bit-program runs give an execution of the programs** (the format of the Spec's `VImplExec`), for
any run predicate `Runs`. -/
theorem exec_of_thread {O : Type}
    (Runs : O → List Expr → Val → List Bool → Val → List Bool → ℝ → Prop)
    {initProg roundProg : List Expr} {orc0 : O} {orcs : ℕ → O}
    {params records : Val} {kinds : ℕ → Bool} {tape : List Bool} {S : ℝ}
    {resps : ℕ → VResponse} {parse : Val → Option VResponse}
    {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)} {encS : σ → Val} {encR : ρ → Val}
    (Inv : σ → Prop)
    (hinit : ∀ st τ, init.run tape = some (st, τ) →
      Inv st ∧ Runs orc0 initProg (Val.list [params, records]) tape (encS st) τ S)
    (hround : ∀ t st τ r st' τ', Inv st → (round t st).run τ = some ((r, st'), τ') →
      Inv st' ∧ Runs (orcs t) roundProg (Val.list [params, encS st, Val.int (if kinds t then 1 else 0)])
        τ (Val.list [encS st', encR r]) τ' S)
    (htot : ∀ t, (threadRun init round tape (t + 1)).isSome)
    (hresp : ∀ t r, threadOut init round tape t = some r → parse (encR r) = some (resps t)) :
    ∃ (states : ℕ → Val) (tapes : ℕ → List Bool),
      Runs orc0 initProg (Val.list [params, records]) tape (states 0) (tapes 0) S ∧
      ∀ t : ℕ, ∃ respV : Val,
        Runs (orcs t) roundProg (Val.list [params, states t, Val.int (if kinds t then 1 else 0)])
          (tapes t) (Val.list [states (t + 1), respV]) (tapes (t + 1)) S ∧
        parse respV = some (resps t) := by
  have hall := threadRun_inv Inv (fun st τ h => (hinit st τ h).1)
    (fun t st τ r st' τ' hI h => (hround t st τ r st' τ' hI h).1) htot
  refine ⟨fun t => ((threadRun init round tape t).map fun p => encS p.1).getD (Val.int 0),
    fun t => ((threadRun init round tape t).map Prod.snd).getD [], ?_, fun t => ?_⟩
  · obtain ⟨st, τ, h, -⟩ := hall 0
    have h' : init.run tape = some (st, τ) := h
    simp only [h, Option.map_some, Option.getD_some]
    exact (hinit st τ h').2
  · obtain ⟨st, τ, h, hInv⟩ := hall t
    have h1 := htot t
    rw [threadRun_succ_of h, Option.isSome_map] at h1
    obtain ⟨⟨⟨r, st'⟩, τ'⟩, hrun⟩ := Option.isSome_iff_exists.mp h1
    have h2 : threadRun init round tape (t + 1) = some (st', τ') := by
      rw [threadRun_succ_of h, hrun]
      rfl
    refine ⟨encR r, ?_, hresp t r ?_⟩
    · simp only [h, h2, Option.map_some, Option.getD_some]
      exact (hround t st τ r st' τ' hInv hrun).2
    · rw [threadOut_of h, hrun]
      rfl

end F2e2e.BSpace
