import F2e2e.Cost.MachineWork
import F2e2e.BSpace.MachineSimO

/-!
# The oracle machine bridge (B_space layer M3; 17fc0802)

`runsWithinBitsO_of_runsOnO`. Suppose a run of C-SPACE's oracle big-step semantics stays within `S` tree units:
`RunsOnO orc prog input tape out rest S` (`F2e2e/BSpace/MachineDefsO.lean`). Then the oracle machine `stepO` of
Spec v3 §7 halts with the same output and leaves the same unread tape `rest`. Every step of that run is charged
(its footprint, `stepWork` and `ctrlWork`) at most
`(bridgeWC + 2)·(bitsFactor prog · S + bitsConst prog) + bridgeWC'` bits. This is §7's `RunsWithinBitsO`, with
the constants of the locked bridge `Machine.runsWithinBitsW_of_runsOn` (`bridgeWC = 48`, `bridgeWC' = 392`).

Proof:
1. `MachineO.runsWithinBitsCfgO_of_runsOnO`: every configuration of the run has at most
   `bitsFactor prog · S + bitsConst prog` bits, by the simulation `MachineO.simO`.
2. The charge of a step from `c` to `c'`. `Machine.stepWork_le` and `Machine.ctrlWork_le` bound it by the bits
   of `c` and `c'`. They are statements about configurations, not about the step function. At the oracle step
   (a `callArg` frame) `stepWork` is `0`.
-/

namespace F2e2e.BSpace

open F2e2e.Machine F2e2e.Cost

namespace MachineO

/-- The per-configuration form of the oracle machine run: halting with `out`, leaving `rest`, with every
configuration of the run within `S` bits. -/
def RunsWithinBitsCfgO (orc : VOracle) (prog : List Expr) (input : Val) (tape : List Bool) (out : Val)
    (rest : List Bool) (S : ℝ) : Prop :=
  ∃ n : ℕ, stepNO orc prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩ ∧
    ∀ k ≤ n, ∀ c : Conf, stepNO orc prog k (initConf input tape) = some c → (confBits prog c : ℝ) ≤ S

/-- The oracle bridge, per-configuration form (the oracle copy of `Machine.runsWithinBitsCfg_of_runsOn`). -/
theorem runsWithinBitsCfgO_of_runsOnO {orc : VOracle} {prog : List Expr} {input : Val}
    {tape : List Bool} {out : Val} {rest : List Bool} {S : ℝ}
    (h : RunsOnO orc prog input tape out rest S) :
    RunsWithinBitsCfgO orc prog input tape out rest (bitsFactor prog * S + bitsConst prog) := by
  obtain ⟨body, fuel, cost, peak, hbody, heval, hpeak⟩ := h
  have hroot : exprAt prog ⟨0, []⟩ = some body := exprAt_root hbody
  obtain ⟨n, hn, hall⟩ :=
    (simO orc prog fuel).1 (valSize input) [input] tape body out cost peak rest ⟨0, []⟩ [] heval hroot
  refine ⟨n, hn, fun k hk d hd => ?_⟩
  obtain ⟨F, hs, hb⟩ := hall k hk d hd
  have hconf : confBits prog d = (encodeCtrl prog d.ctrl).length + framesBits prog F + 1 := by
    rw [confBits_eq, hs, encodeStack_append_length, encodeStack_nil_length]
    omega
  have hpk : valSize input + valSize out ≤ peak := evalO_peak_ge orc prog fuel _ _ _ _ _ heval
  have htop := simBound_top (prog := prog) (input := input) (height_le_progDepth hbody)
    (show valSize input ≤ peak by omega)
  have hnat : confBits prog d ≤ bitsFactor prog * peak + bitsConst prog := by omega
  calc (confBits prog d : ℝ) ≤ ((bitsFactor prog * peak + bitsConst prog : ℕ) : ℝ) := by
        exact_mod_cast hnat
    _ = (bitsFactor prog : ℝ) * (peak : ℝ) + bitsConst prog := by push_cast; ring
    _ ≤ bitsFactor prog * S + bitsConst prog := by
        gcongr

end MachineO

open MachineO in
/-- **M3, the oracle machine bridge.** A run of the oracle big-step semantics within `S` tree units gives a run
of §7's oracle machine with the same output and unread tape, in which every step's footprint plus arithmetic
workspace plus finite-control temporaries is at most
`(bridgeWC + 2)·(bitsFactor prog · S + bitsConst prog) + bridgeWC'` bits. -/
theorem runsWithinBitsO_of_runsOnO {orc : VOracle} {prog : List Expr} {input : Val} {tape : List Bool}
    {out : Val} {rest : List Bool} {S : ℝ} (h : RunsOnO orc prog input tape out rest S) :
    RunsWithinBitsO orc prog input tape out rest
      ((((bridgeWC : ℕ) : ℝ) + 2) * ((bitsFactor prog : ℝ) * S + (bitsConst prog : ℝ)) +
        ((bridgeWC' : ℕ) : ℝ)) := by
  obtain ⟨n, hn, hall⟩ := runsWithinBitsCfgO_of_runsOnO h
  refine ⟨n, hn, fun k hk c c' hc hc' => ?_⟩
  have hc2 : stepNO orc prog (k + 1) (initConf input tape) = some c' := by
    rw [stepNO_add, hc]
    exact stepNO_one hc'
  have h1 := hall k hk.le c hc
  have h2 := hall (k + 1) hk c' hc2
  have h3 : (stepWork prog c : ℝ) ≤ (arithC : ℝ) * (confBits prog c : ℝ) + (arithC' : ℝ) := by
    exact_mod_cast stepWork_le prog c
  have h5 : (ctrlWork prog c c' : ℝ) ≤
      4 * ((confBits prog c : ℝ) + (confBits prog c' : ℝ) + (stepWork prog c : ℝ)) + 72 := by
    exact_mod_cast ctrlWork_le prog c c'
  have hC : (0 : ℝ) ≤ (arithC : ℝ) := Nat.cast_nonneg _
  have h4 := mul_le_mul_of_nonneg_left h1 hC
  unfold bridgeWC bridgeWC'
  push_cast
  linarith

/-- Monotonicity of `RunsWithinBitsO` in the bound. -/
theorem RunsWithinBitsO.mono {orc : VOracle} {prog : List Expr} {input : Val} {tape : List Bool}
    {out : Val} {rest : List Bool} {S S' : ℝ} (h : RunsWithinBitsO orc prog input tape out rest S)
    (hS : S ≤ S') : RunsWithinBitsO orc prog input tape out rest S' := by
  obtain ⟨n, hn, hall⟩ := h
  exact ⟨n, hn, fun k hk c c' hc hc' => (hall k hk c c' hc hc').trans hS⟩

end F2e2e.BSpace
