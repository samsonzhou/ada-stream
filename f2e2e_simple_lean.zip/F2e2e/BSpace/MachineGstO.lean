import F2e2e.BSpace.MachineEvalsO
import F2e2e.BSpace.MachineFactsO

/-!
# B_space, layer M2: the generic space theorem with the evaluation oracle

Owner: C-SPACE (B_space layer M; area lead W4). Oracle copy of C-TOP's generic space theorem (GST,
`F2e2e/Cost/Generic.lean`: `gst_aux`, `EvalsVal.toSpT`, `EvalsVal.eval_entry`): for a program with a rank
certificate `RankOK prog r K`, an `EvalsValO` evaluation (M1, `F2e2e/BSpace/MachineEvalsO.lean`) of the
entry body on an input of size `≤ M`, consuming exactly `bits`, is a run of the oracle big-step semantics
`evalO` (`F2e2e/BSpace/MachineDefsO.lean`) on every tape `bits ++ rest`, leaving `rest`, with peak
`≤ ((r 0 + 1)(K + 3) + 1) · M` (`EvalsValO.eval_entryO`, `runsOnO_of_evalsValO`, and the bit-program form
`ImplementsO.runsOnO`).

* `EvalsSpTO` / `LoopSpTO`: the space-only judgments for `evalO` / `loopRunO`, with the tape frame built in
  (`∀ r, evalO … (bits ++ r) … = some (v, c, p, r)`), and one rule per construct (`var`, `lit`, `nil`, `coin`,
  `bin`, `un`, `ite`, `letE`, `call` (not the oracle index), `oracle`, `loop`; `stop`, `cont`), from the
  one-step lemmas and fuel monotonicity of `F2e2e/BSpace/MachineFactsO.lean` (17fc0802).
* `gst_auxO`: `gst_aux` verbatim, with the `oracle` case (the argument and the answer are two slots, as for
  a unary operation).
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-! ## Space-only judgments for `evalO` -/

/-- `e` evaluates under `evalO orc` to `v` within peak live space `S`, consuming exactly the fresh bits
`bits` (on every tape extending them, leaving the rest). -/
def EvalsSpTO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (base : ℕ) (env : List Val)
    (bits : List Bool) (e : Expr) (v : Val) (S : ℕ) : Prop :=
  ∃ fuel c p, p ≤ S ∧ ∀ r, evalO orc prog fuel base env (bits ++ r) e = some (v, c, p, r)

/-- Loop iterations under `loopRunO orc` within peak live space `S`, consuming exactly `bits`. -/
def LoopSpTO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (base i : ℕ) (v : Val) (bits : List Bool)
    (w : Val) (S : ℕ) : Prop :=
  ∃ fuel c p, p ≤ S ∧ ∀ r, loopRunO orc prog fuel base i v (bits ++ r) = some (w, c, p, r)

namespace EvalsSpTO

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {base : ℕ} {env : List Val}

theorem mono {bits : List Bool} {e : Expr} {v : Val} {S S' : ℕ}
    (h : EvalsSpTO orc prog base env bits e v S) (hS : S ≤ S') :
    EvalsSpTO orc prog base env bits e v S' := by
  obtain ⟨fuel, c, p, hp, h⟩ := h
  exact ⟨fuel, c, p, hp.trans hS, h⟩

theorem var {i : ℕ} {v : Val} (h : env[i]? = some v) :
    EvalsSpTO orc prog base env [] (Expr.var i) v (base + valSize v) :=
  ⟨1, 1, base + valSize v, le_rfl, fun _ => (evalO_var_iff orc prog).mpr ⟨v, h, rfl⟩⟩

theorem lit (z : ℤ) :
    EvalsSpTO orc prog base env [] (Expr.lit z) (Val.int z) (base + valSize (Val.int z)) :=
  ⟨1, _, _, le_rfl, fun r => evalO_lit_eq orc prog 0 base env r z⟩

theorem nil : EvalsSpTO orc prog base env [] Expr.nil (Val.list []) (base + valSize (Val.list [])) :=
  ⟨1, _, _, le_rfl, fun r => evalO_nil_eq orc prog 0 base env r⟩

/-- `coin` consumes one fresh bit `b` and returns `encB b`. -/
theorem coin (b : Bool) :
    EvalsSpTO orc prog base env [b] Expr.coin (encB b) (base + valSize (encB b)) := by
  refine ⟨1, 1, base + valSize (encB b), le_rfl, fun r => ?_⟩
  have h := evalO_coin_cons orc prog 0 base env b r
  cases b <;> simpa [encB] using h

theorem bin {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {Sa Sb c : ℕ}
    (ha : EvalsSpTO orc prog base env ba a va Sa)
    (hb : EvalsSpTO orc prog (base + valSize va) env bb b vb Sb)
    (hop : evalBin op va vb = some (v, c)) :
    EvalsSpTO orc prog base env (ba ++ bb) (Expr.bin op a b) v
      (max (max Sa Sb) (base + valSize va + valSize vb + valSize v)) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  obtain ⟨fb, cb, pb, hpb, hb⟩ := hb
  refine ⟨max fa fb + 1, 1 + ca + cb + c,
    max (max pa pb) (base + valSize va + valSize vb + valSize v), ?_, fun r => ?_⟩
  · exact max_le_max (max_le_max hpa hpb) le_rfl
  · rw [List.append_assoc]
    exact (evalO_bin_iff orc prog).mpr ⟨va, ca, pa, bb ++ r, vb, cb, pb, r, v, c,
      evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (ha (bb ++ r)),
      evalO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hb r), hop, rfl⟩

theorem un {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {Sa c : ℕ}
    (ha : EvalsSpTO orc prog base env ba a va Sa) (hop : evalUn op va = some (v, c)) :
    EvalsSpTO orc prog base env ba (Expr.un op a) v (max Sa (base + valSize va + valSize v)) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  refine ⟨fa + 1, 1 + ca + c, max pa (base + valSize va + valSize v), max_le_max hpa le_rfl,
    fun r => ?_⟩
  exact (evalO_un_iff orc prog).mpr ⟨va, ca, pa, r, v, c, ha r, hop, rfl⟩

theorem ite {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val} {Sc Sv : ℕ}
    (hc : EvalsSpTO orc prog base env bc c (Val.int z) Sc)
    (hv : EvalsSpTO orc prog base env bv (if z ≠ 0 then t else f) v Sv) :
    EvalsSpTO orc prog base env (bc ++ bv) (Expr.ite c t f) v (max Sc Sv) := by
  obtain ⟨fc, cc, pc, hpc, hc⟩ := hc
  obtain ⟨fv, cv, pv, hpv, hv⟩ := hv
  refine ⟨max fc fv + 1, 1 + cc + cv, max pc pv, max_le_max hpc hpv, fun r => ?_⟩
  rw [List.append_assoc]
  exact (evalO_ite_iff orc prog).mpr ⟨z, cc, pc, bv ++ r, v, cv, pv, r,
    evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (hc (bv ++ r)),
    evalO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hv r), rfl⟩

theorem letE {a b : Expr} {ba bb : List Bool} {va vb : Val} {Sa Sb : ℕ}
    (ha : EvalsSpTO orc prog base env ba a va Sa)
    (hb : EvalsSpTO orc prog (base + valSize va) (va :: env) bb b vb Sb) :
    EvalsSpTO orc prog base env (ba ++ bb) (Expr.letE a b) vb (max Sa Sb) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  obtain ⟨fb, cb, pb, hpb, hb⟩ := hb
  refine ⟨max fa fb + 1, 1 + ca + cb, max pa pb, max_le_max hpa hpb, fun r => ?_⟩
  rw [List.append_assoc]
  exact (evalO_letE_iff orc prog).mpr ⟨va, ca, pa, bb ++ r, vb, cb, pb, r,
    evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (ha (bb ++ r)),
    evalO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hb r), rfl⟩

theorem call {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val} {Sa Sb : ℕ}
    (hi : i ≠ bsOracleIdx) (ha : EvalsSpTO orc prog base env ba a va Sa)
    (hbody : prog[i]? = some body)
    (hb : EvalsSpTO orc prog (base + valSize va) [va] bb body vb Sb) :
    EvalsSpTO orc prog base env (ba ++ bb) (Expr.call i a) vb (max Sa Sb) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  obtain ⟨fb, cb, pb, hpb, hb⟩ := hb
  refine ⟨max fa fb + 1, 1 + ca + cb, max pa pb, max_le_max hpa hpb, fun r => ?_⟩
  rw [List.append_assoc]
  exact (evalO_call_iff orc prog hi).mpr ⟨va, ca, pa, bb ++ r, body, vb, cb, pb, r,
    evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (ha (bb ++ r)), hbody,
    evalO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hb r), rfl⟩

/-- The oracle call: the argument and the answer are live together. -/
theorem oracle {a : Expr} {ba : List Bool} {sel rr q : ℤ} {Sa : ℕ}
    (ha : EvalsSpTO orc prog base env ba a (Val.list [Val.int sel, Val.int rr, Val.int q]) Sa) :
    EvalsSpTO orc prog base env ba (Expr.call bsOracleIdx a) (Val.int (orc sel rr q))
      (max Sa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int q]) +
        valSize (Val.int (orc sel rr q)))) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  refine ⟨fa + 1, 2 + ca, max pa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int q]) +
    valSize (Val.int (orc sel rr q))), max_le_max hpa le_rfl, fun r => ?_⟩
  exact (evalO_oracle_iff orc prog).mpr ⟨_, ca, pa, r, sel, rr, q, ha r, rfl, rfl⟩

theorem loop {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val} {Sa Sl : ℕ}
    (ha : EvalsSpTO orc prog base env ba a va Sa) (hl : LoopSpTO orc prog base i va bl w Sl) :
    EvalsSpTO orc prog base env (ba ++ bl) (Expr.loop i a) w (max Sa Sl) := by
  obtain ⟨fa, ca, pa, hpa, ha⟩ := ha
  obtain ⟨fl, cl, pl, hpl, hl⟩ := hl
  refine ⟨max fa fl + 1, 1 + ca + cl, max pa pl, max_le_max hpa hpl, fun r => ?_⟩
  rw [List.append_assoc]
  exact (evalO_loop_iff orc prog).mpr ⟨va, ca, pa, bl ++ r, w, cl, pl, r,
    evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (ha (bl ++ r)),
    loopRunO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hl r), rfl⟩

end EvalsSpTO

namespace LoopSpTO

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {base i : ℕ}

theorem mono {v w : Val} {bits : List Bool} {S S' : ℕ} (h : LoopSpTO orc prog base i v bits w S)
    (hS : S ≤ S') : LoopSpTO orc prog base i v bits w S' := by
  obtain ⟨fuel, c, p, hp, h⟩ := h
  exact ⟨fuel, c, p, hp.trans hS, h⟩

theorem stop {body : Expr} {v v' : Val} {bits : List Bool} {Sb : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsSpTO orc prog (base + valSize v) [v] bits body (Val.list [Val.int 0, v']) Sb) :
    LoopSpTO orc prog base i v bits v' Sb := by
  obtain ⟨fb, cb, pb, hpb, hb⟩ := hb
  refine ⟨fb + 1, 1 + cb, pb, hpb, fun r => ?_⟩
  exact (loopRunO_succ_iff orc prog).mpr ⟨body, 0, v', cb, pb, r, hbody, hb r,
    Or.inl ⟨rfl, rfl⟩⟩

theorem cont {body : Expr} {flag : ℤ} {v v' w : Val} {bb bw : List Bool} {Sb Sw : ℕ}
    (hbody : prog[i]? = some body)
    (hb : EvalsSpTO orc prog (base + valSize v) [v] bb body (Val.list [Val.int flag, v']) Sb)
    (hflag : flag ≠ 0) (hrest : LoopSpTO orc prog base i v' bw w Sw) :
    LoopSpTO orc prog base i v (bb ++ bw) w (max Sb Sw) := by
  obtain ⟨fb, cb, pb, hpb, hb⟩ := hb
  obtain ⟨fw, cw, pw, hpw, hw⟩ := hrest
  refine ⟨max fb fw + 1, 1 + cb + cw, max pb pw, max_le_max hpb hpw, fun r => ?_⟩
  rw [List.append_assoc]
  exact (loopRunO_succ_iff orc prog).mpr ⟨body, flag, v', cb, pb, bw ++ r, hbody,
    evalO_fuel_mono orc prog (le_max_left _ _) _ _ _ _ _ (hb (bw ++ r)),
    Or.inr ⟨hflag, w, cw, pw, r,
      loopRunO_fuel_mono orc prog (le_max_right _ _) _ _ _ _ _ (hw r), rfl⟩⟩

end LoopSpTO

/-! ## The generic space theorem with the oracle -/

/-- The statement proved by induction on `EvalsValO` (C-TOP's `GProp` for the oracle semantics). -/
def GPropO (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (r : ℕ → ℕ) (K M : ℕ) (env : List Val)
    (bits : List Bool) : Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ w ∈ env, valSize w ≤ M) → valSize v ≤ M ∧
      ∀ base ρ, CalleesLt r ρ e →
        EvalsSpTO orc prog base env bits e v (base + (exprDepth e + 2 + ρ * (K + 3)) * M)
  | .inr (i, acc), w => valSize acc ≤ M → valSize w ≤ M ∧
      ∀ base, LoopSpTO orc prog base i acc bits w (base + (r i + 1) * (K + 3) * M)

open GST in
theorem gst_auxO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValO orc prog M env bits t v) : GPropO orc prog r K M env bits t v := by
  induction h with
  | @var env i v hv =>
    simp only [GPropO]
    intro henv
    have hv' : valSize v ≤ M := henv v (List.mem_of_getElem? hv)
    refine ⟨hv', fun base ρ _ => (EvalsSpTO.var hv).mono ?_⟩
    have := le_mul hv' (n := exprDepth (Expr.var i) + 2 + ρ * (K + 3)) (by omega)
    omega
  | @lit env z hM =>
    simp only [GPropO]
    intro _
    refine ⟨hM, fun base ρ _ => (EvalsSpTO.lit z).mono ?_⟩
    have := le_mul hM (n := exprDepth (Expr.lit z) + 2 + ρ * (K + 3)) (by omega)
    omega
  | @nil env hM =>
    simp only [GPropO]
    intro _
    refine ⟨hM, fun base ρ _ => EvalsSpTO.nil.mono ?_⟩
    have := le_mul hM (n := exprDepth Expr.nil + 2 + ρ * (K + 3)) (by omega)
    omega
  | @coin env b hM =>
    simp only [GPropO]
    intro _
    refine ⟨hM, fun base ρ _ => (EvalsSpTO.coin b).mono ?_⟩
    have := le_mul hM (n := exprDepth Expr.coin + 2 + ρ * (K + 3)) (by omega)
    omega
  | @bin env op a b ba bb va vb v c ha hb hop hM iha ihb =>
    simp only [GPropO] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb henv
    refine ⟨hM, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.1
    have h2 := hb' (base + valSize va) ρ hc.2
    refine (EvalsSpTO.bin h1 h2 hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth b + 2 + ρ * (K + 3))
      (n' := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3)) hva (by omega)
    have e3 := three_le_mul (n := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3))
      hva hvb hM (by omega)
    exact max_le (max_le (by omega) (by omega)) (by omega)
  | @un env op a ba va v c ha hop hM iha =>
    simp only [GPropO] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc
    refine (EvalsSpTO.un h1 hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := two_le_mul (n := 1 + exprDepth a + 2 + ρ * (K + 3)) hva hM (by omega)
    exact max_le (by omega) (by omega)
  | @ite env c t f bc bv z v hc hv ihc ihv =>
    simp only [GPropO] at ihc ihv ⊢
    intro henv
    obtain ⟨-, hc'⟩ := ihc henv
    obtain ⟨hvv, hv'⟩ := ihv henv
    refine ⟨hvv, fun base ρ hcl => ?_⟩
    simp only [CalleesLt] at hcl
    obtain ⟨hcc, hct, hcf⟩ := hcl
    have hbr : exprDepth (if z ≠ 0 then t else f) ≤ max (exprDepth t) (exprDepth f) ∧
        CalleesLt r ρ (if z ≠ 0 then t else f) := by
      split_ifs
      · exact ⟨le_max_left _ _, hct⟩
      · exact ⟨le_max_right _ _, hcf⟩
    have h1 := hc' base ρ hcc
    have h2 := hv' base ρ hbr.2
    refine (EvalsSpTO.ite h1 h2).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth c + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 + ρ * (K + 3) by omega)
    have e2 := Nat.mul_le_mul_right M (show exprDepth (if z ≠ 0 then t else f) + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 + ρ * (K + 3) by omega)
    exact max_le (by omega) (by omega)
  | @letE env a b ba bb va vb ha hb iha ihb =>
    simp only [GPropO] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    have henv' : ∀ w ∈ va :: env, valSize w ≤ M := by
      intro w hw
      rcases List.mem_cons.mp hw with rfl | hw
      · exact hva
      · exact henv w hw
    obtain ⟨hvb, hb'⟩ := ihb henv'
    refine ⟨hvb, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.1
    have h2 := hb' (base + valSize va) ρ hc.2
    refine (EvalsSpTO.letE h1 h2).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth b + 2 + ρ * (K + 3))
      (n' := 1 + max (exprDepth a) (exprDepth b) + 2 + ρ * (K + 3)) hva (by omega)
    exact max_le (by omega) (by omega)
  | @call env i a body ba bb va vb hi ha hbody hb iha ihb =>
    simp only [GPropO] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb (by simpa using hva)
    refine ⟨hvb, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    obtain ⟨hdep, hcb⟩ := hR i body hbody
    have h1 := ha' base ρ hc.2
    have h2 := hb' (base + valSize va) (r i) hcb
    refine (EvalsSpTO.call hi h1 hbody h2).mono ?_
    simp only [exprDepth]
    have hX : (r i + 1) * (K + 3) ≤ ρ * (K + 3) := Nat.mul_le_mul_right _ hc.1
    have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
      (n' := 1 + exprDepth a + 2 + ρ * (K + 3)) hva (by omega)
    exact max_le (by omega) (by omega)
  | @oracle env a ba sel rr q ha hM iha =>
    simp only [GPropO] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.2
    refine (EvalsSpTO.oracle h1).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := two_le_mul (n := 1 + exprDepth a + 2 + ρ * (K + 3)) hva hM (by omega)
    exact max_le (by omega) (by omega)
  | @loop env i a ba bl va w ha hl iha ihl =>
    simp only [GPropO] at iha ihl ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hw, hl'⟩ := ihl hva
    refine ⟨hw, fun base ρ hc => ?_⟩
    simp only [CalleesLt] at hc
    have h1 := ha' base ρ hc.2
    have h2 := hl' base
    refine (EvalsSpTO.loop h1 h2).mono ?_
    simp only [exprDepth]
    have hX : (r i + 1) * (K + 3) ≤ ρ * (K + 3) := Nat.mul_le_mul_right _ hc.1
    have e1 := Nat.mul_le_mul_right M (show exprDepth a + 2 + ρ * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    have e2 := Nat.mul_le_mul_right M (show (r i + 1) * (K + 3) ≤
      1 + exprDepth a + 2 + ρ * (K + 3) by omega)
    exact max_le (by omega) (by omega)
  | @stop i v body bb v' hbody hb ihb =>
    simp only [GPropO] at ihb ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    refine ⟨?_, fun base => ?_⟩
    · rw [valSize_flag_pair] at hpair
      omega
    · obtain ⟨hdep, hcb⟩ := hR i body hbody
      have h1 := hb' (base + valSize v) (r i) hcb
      refine (LoopSpTO.stop hbody h1).mono ?_
      have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
      have e1 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
        (n' := (r i + 1) * (K + 3)) hv (by omega)
      omega
  | @cont i v body bb bw flag v' w hbody hb hflag hrest ihb ihr =>
    simp only [GPropO] at ihb ihr ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    have hv' : valSize v' ≤ M := by
      rw [valSize_flag_pair] at hpair
      omega
    obtain ⟨hw, hr'⟩ := ihr hv'
    refine ⟨hw, fun base => ?_⟩
    obtain ⟨hdep, hcb⟩ := hR i body hbody
    have h1 := hb' (base + valSize v) (r i) hcb
    refine (LoopSpTO.cont hbody h1 hflag (hr' base)).mono ?_
    have hri : (r i + 1) * (K + 3) = r i * (K + 3) + (K + 3) := by ring
    have e1 := add_le_mul (n := exprDepth body + 2 + r i * (K + 3))
      (n' := (r i + 1) * (K + 3)) hv (by omega)
    exact max_le (by omega) le_rfl

/-- **Generic space theorem with the oracle.** -/
theorem EvalsValO.toSpTO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) {ρ : ℕ}
    (hc : CalleesLt r ρ e) (base : ℕ) :
    EvalsSpTO orc prog base env bits e v (base + (exprDepth e + 2 + ρ * (K + 3)) * M) :=
  (gst_auxO hR h henv).2 base ρ hc

/-- Produced values are `≤ M` (for environments of values `≤ M`). -/
theorem EvalsValO.val_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) :
    valSize v ≤ M :=
  (gst_auxO hR h henv).1

/-- **GST at the entry point, with the oracle**: the entry body evaluated on an input of size `≤ M`,
consuming exactly `bits`, runs under `evalO` on every tape `bits ++ rest`, leaving `rest`, with peak
`≤ ((r 0 + 1)(K + 3) + 1) M`. -/
theorem EvalsValO.eval_entryO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input out : Val}
    {bits : List Bool} (h : EvalsValO orc prog M [input] bits (.inl body) out)
    (hin : valSize input ≤ M) :
    ∃ fuel c p, p ≤ ((r 0 + 1) * (K + 3) + 1) * M ∧
      ∀ rest, evalO orc prog fuel (valSize input) [input] (bits ++ rest) body =
        some (out, c, p, rest) := by
  obtain ⟨hdep, hcb⟩ := hR 0 body h0
  have hS := h.toSpTO hR (by simpa using hin) hcb (valSize input)
  obtain ⟨fuel, c, p, hp, hf⟩ := hS
  refine ⟨fuel, c, p, ?_, hf⟩
  have hri : (r 0 + 1) * (K + 3) = r 0 * (K + 3) + (K + 3) := by ring
  have e1 := GST.add_le_mul (n := exprDepth body + 2 + r 0 * (K + 3))
    (n' := (r 0 + 1) * (K + 3) + 1) hin (by omega)
  omega

/-- **GST + `RunsOnO`.** -/
theorem runsOnO_of_evalsValO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input out : Val}
    {bits : List Bool} (h : EvalsValO orc prog M [input] bits (.inl body) out)
    (hin : valSize input ≤ M) (rest : List Bool) :
    RunsOnO orc prog input (bits ++ rest) out rest ((((r 0 + 1) * (K + 3) + 1) * M : ℕ) : ℝ) := by
  obtain ⟨fuel, c, p, hp, hf⟩ := h.eval_entryO hR h0 hin
  exact ⟨body, fuel, c, p, h0, hf rest, by exact_mod_cast hp⟩

/-- **GST + `RunsOnO`, bit-program form**: if the entry body implements `p` (with the oracle), every run
`p.run tape = some (a, rest)` gives an `evalO` run on `tape` leaving exactly `rest`, output `enc a`. -/
theorem ImplementsO.runsOnO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {body : Expr} (h0 : prog[0]? = some body) {input : Val} {α : Type}
    {enc : α → Val} {p : Discrete.BitProg α} (h : ImplementsO orc prog M [input] body enc p)
    (hin : valSize input ≤ M) {tape rest : List Bool} {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsOnO orc prog input tape (enc a) rest ((((r 0 + 1) * (K + 3) + 1) * M : ℕ) : ℝ) := by
  obtain ⟨bits, rfl, hb⟩ := bitProg_run_split hrun
  exact runsOnO_of_evalsValO hR h0 (h bits a hb) hin rest

end F2e2e.BSpace
