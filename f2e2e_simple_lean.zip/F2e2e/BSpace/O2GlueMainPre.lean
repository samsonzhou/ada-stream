import F2e2e.BSpace.O2GlueEvals
import F2e2e.BSpace.O2GlueMainDefs

/-!
# B_space, route O2b, top frame of `body_bsRound`: (P1) the prefix — `adaPub` and `bsEvals`

Owner: 1beb339b (O2b top frames, pieces P1 and P2; C-BANK 47a44866 owns the family `O2GlueMain*`, the
interval branch P3 and the composition P4; technical lead 17fc0802).

* generic `EvalsValF` rules of the top frame: field access `o2m_atN`, list building `o2m_list`, the numerical
  response `o2m_numResp`;
* `o2mPreB`: the value bound of the prefix (the input, the parameter record, the query table);
* **P1a** `o2m_pubF`: the call of `adaPub` (600) in the top frame;
* **P1b** `o2m_evalsF`: the call of `bsEvals` (910, D2) in the top frame;
* `o2m_evalsAt_of`: C-BANK's callee predicate `O2mEvalsAt` at `(o2e_B, o2e_T)` (1beb339b's
  `o2e_bsEvals_evalsF`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.C.Impl F2e2e.B

section rules

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}

/-- `tail^n` of a list value (every suffix is `≤ m`). -/
theorem o2m_tlN {e : Expr} {l : List Val} (he : EvalsValF orc prog m τ env [] (.inl e) (Val.list l))
    (hm : valSize (Val.list l) ≤ m) :
    ∀ n, n ≤ l.length → EvalsValF orc prog m τ env [] (.inl (eTlN n e)) (Val.list (l.drop n))
  | 0, _ => by simpa [eTlN] using he
  | n + 1, hn => by
    have ih := o2m_tlN he hm n (by omega)
    rw [List.drop_eq_getElem_cons (by omega)] at ih
    show EvalsValF orc prog m τ env [] (.inl (eTl (eTlN n e))) _
    refine EvalsValF.tail ih (le_trans ?_ hm)
    simp only [valSize_list]
    have := listSize_drop_le l (n + 1)
    omega

/-- **Field access** `eAtN n e` in a frame `(m, τ)`. -/
theorem o2m_atN {e : Expr} {l : List Val} (he : EvalsValF orc prog m τ env [] (.inl e) (Val.list l))
    (hm : valSize (Val.list l) ≤ m) {n : ℕ} {v : Val} (hget : l[n]? = some v) :
    EvalsValF orc prog m τ env [] (.inl (eAtN n e)) v := by
  obtain ⟨hn, rfl⟩ := List.getElem?_eq_some_iff.mp hget
  have h := o2m_tlN he hm n hn.le
  rw [List.drop_eq_getElem_cons hn] at h
  exact EvalsValF.head h (le_trans (valSize_getElem_lt hn).le hm)

/-- **List building** `eList es` in a frame `(m, τ)`. -/
theorem o2m_list :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsValF orc prog m τ env [] (.inl e) v) es vs →
      valSize (Val.list vs) ≤ m → EvalsValF orc prog m τ env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hm => EvalsValF.nil hm
  | _ :: _, _ :: vs, List.Forall₂.cons h hs, hm => by
    have hm' : valSize (Val.list vs) ≤ m := by
      simp only [valSize_list, listSize_cons] at hm ⊢; omega
    have := EvalsValF.cons h (o2m_list hs hm') hm
    simpa [eList] using this

/-- A small literal (`0 ≤ w ≤ 3`) costs at most `3`. -/
theorem o2m_vs_small {w : ℤ} (h0 : 0 ≤ w) (h3 : w ≤ 3) : valSize (Val.int w) ≤ 3 := by
  rw [valSize_int]
  have h' : |w| < 2 ^ 2 := by rw [abs_of_nonneg h0]; norm_num; omega
  have := bitLen_le_of_abs_lt h'
  omega

/-- **The numerical response** `bsNumResp e` in a frame `(m, τ)` (`[3, 0, 1]` on an abort, `[3, num, den]`
on a value). -/
theorem o2m_numResp {e : Expr} {x : AdaNum}
    (he : EvalsValF orc prog m τ env [] (.inl e) (encNum x)) (hx : valSize (encNum x) ≤ m)
    (hr : valSize (bsResp (Sum.inr x)) ≤ m) (hm : 16 ≤ m) :
    EvalsValF orc prog m τ env [] (.inl (bsNumResp e)) (bsResp (Sum.inr x)) := by
  have hlit : ∀ w : ℤ, 0 ≤ w → w ≤ 3 → EvalsValF orc prog m τ env [] (.inl (eLit w)) (Val.int w) :=
    fun w h0 h3 => EvalsValF.lit ((o2m_vs_small h0 h3).trans (by omega))
  cases x with
  | abort =>
    have hnil : EvalsValF orc prog m τ env [] (.inl e) (Val.list []) := he
    refine o2e_ite_true (o2e_isNil_nil hnil (by omega)) one_ne_zero ?_
    exact o2m_list (List.Forall₂.cons (hlit 3 (by norm_num) (by norm_num))
      (List.Forall₂.cons (hlit 0 (by norm_num) (by norm_num))
      (List.Forall₂.cons (hlit 1 (by norm_num) (by norm_num)) List.Forall₂.nil))) hr
  | val μ =>
    have he' : EvalsValF orc prog m τ env [] (.inl e) (Val.list [encQ μ]) := he
    refine o2e_ite_false (o2e_isNil_cons he' (by omega)) rfl ?_
    have hqM : valSize (encQ μ) ≤ m :=
      le_trans (valSize_lt_of_mem (l := [encQ μ]) List.mem_cons_self).le hx
    have hhd : EvalsValF orc prog m τ env [] (.inl (eHd e)) (encQ μ) := EvalsValF.head he' hqM
    have hnum : EvalsValF orc prog m τ env [] (.inl (eAtN 0 (eHd e))) (Val.int μ.num) :=
      o2m_atN (l := [Val.int μ.num, Val.int (μ.den : ℤ)]) hhd hqM rfl
    have hden : EvalsValF orc prog m τ env [] (.inl (eAtN 1 (eHd e))) (Val.int (μ.den : ℤ)) :=
      o2m_atN (l := [Val.int μ.num, Val.int (μ.den : ℤ)]) hhd hqM rfl
    exact o2m_list (List.Forall₂.cons (hlit 3 (by norm_num) (by norm_num))
      (List.Forall₂.cons hnum (List.Forall₂.cons hden List.Forall₂.nil))) hr

end rules

/-! ## P1: the prefix -/

/-- **The value bound of the prefix**: the input, the parameter record, the query table and the precision. -/
def o2mPreB (orc : ℤ → ℤ → ℤ → ℤ) (Mc J R eA eXi : ℕ) (blocks : List (List ℕ)) (st : AdaState)
    (kind : Bool) : ℕ :=
  valSize (o2mInp Mc J R eA eXi blocks st kind) + valSize (adaPubEnc (adaParams eA eXi Mc J R)) +
    valSize (encVals (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)) +
    (adaParams eA eXi Mc J R).qA + 8

/-- **P1a: the parameter record.** `adaPub` (600), at its own `(mP, τP)`, in the top frame `(m, τ)`. -/
theorem o2m_pubF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Mc J R eA eXi : ℕ}
    {blocks : List (List ℕ)} {st : AdaState} {kind : Bool} {mP τP : ℕ}
    (hPub : O2mPubAt orc prog mP τP Mc J R eA eXi) {m τ : ℕ}
    (hm : o2mPreB orc Mc J R eA eXi blocks st kind ≤ m)
    (hτ : (exprDepth body_adaPub + 2) * mP + τP ≤ τ) :
    EvalsValF orc prog m τ [o2mInp Mc J R eA eXi blocks st kind] []
      (.inl (eCall Idx.adaPub (eAtN 0 (eV 0)))) (adaPubEnc (adaParams eA eXi Mc J R)) := by
  obtain ⟨h600, harg, hP⟩ := hPub
  unfold o2mPreB at hm
  have hinp : valSize (o2mInp Mc J R eA eXi blocks st kind) ≤ m := by omega
  exact evalsValF_call_det (by decide) h600 (o2m_atN (EvalsValF.var rfl) hinp rfl) hP harg (by omega) hτ

/-- **P1b: the query table through the oracle.** `bsEvals` (910, D2), at its own `(mE, τE)`, in the top frame
`(m, τ)`, on `[q_A, blocks]` read from the parameter record and the B state. -/
theorem o2m_evalsF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Mc J R eA eXi : ℕ}
    {blocks : List (List ℕ)} {st : AdaState} {kind : Bool} {mE τE : ℕ}
    (hEv : O2mEvalsAt orc prog mE τE (adaParams eA eXi Mc J R).qA blocks) {m τ : ℕ}
    (hm : o2mPreB orc Mc J R eA eXi blocks st kind ≤ m)
    (hτ : (exprDepth body_bsEvals + 2) * mE + τE ≤ τ) :
    EvalsValF orc prog m τ [adaPubEnc (adaParams eA eXi Mc J R), o2mInp Mc J R eA eXi blocks st kind] []
      (.inl (eCall bsEvalsKey (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1))))))
      (encVals (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)) := by
  obtain ⟨h910, harg, hE⟩ := hEv
  set A := adaParams eA eXi Mc J R with hA
  unfold o2mPreB at hm
  rw [← hA] at hm
  have hinp : valSize (o2mInp Mc J R eA eXi blocks st kind) ≤ m := by omega
  have hpub : valSize (adaPubEnc A) ≤ m := by omega
  have hinpS : valSize (o2mInp Mc J R eA eXi blocks st kind) =
      valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) +
        valSize (bsStateEnc blocks st) + valSize (encB kind) + 4 := by
    unfold o2mInp
    rw [bsE_vs_three]
  have hstE : valSize (bsStateEnc blocks st) ≤ m := by omega
  have hqN := bsE_vsN A.qA
  have hblk : valSize (Val.list (blocks.map (encL encN))) + 3 ≤ valSize (bsStateEnc blocks st) := by
    unfold bsStateEnc
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hargs : EvalsValF orc prog m τ [adaPubEnc A, o2mInp Mc J R eA eXi blocks st kind] []
      (.inl (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1)))))
      (Val.list [encN A.qA, Val.list (blocks.map (encL encN))]) := by
    refine EvalsValF.pair (o2m_atN (l := pubFields A) (EvalsValF.var rfl) hpub rfl)
      (o2m_atN (o2m_atN (EvalsValF.var rfl) hinp rfl) hstE rfl) ?_
    rw [bsE_vs_two]
    omega
  exact evalsValF_call_det (by decide) h910 hargs hE harg (by omega) hτ

/-- **C-BANK's callee predicate for D2** at `(o2e_B, o2e_T)` (`o2e_bsEvals_evalsF`). -/
theorem o2m_evalsAt_of {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hlib : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) {q : ℕ} {blocks : List (List ℕ)}
    (hO : ∀ blk ∈ blocks, ∀ r ∈ blk, 0 ≤ orc 0 (r : ℤ) (q + 1) ∧ orc 0 (r : ℤ) (q + 1) ≤ 2 ^ (q + 1)) :
    O2mEvalsAt orc prog (o2e_B orc q blocks) (o2e_T orc q blocks) q blocks := by
  refine ⟨(BsEvalsLib.of_table hlib).evals, ?_, o2e_bsEvals_evalsF hlib hO le_rfl le_rfl⟩
  have hqN := bsE_vsN q
  unfold o2e_B
  rw [bsE_vs_two]
  omega

end F2e2e.BSpace
