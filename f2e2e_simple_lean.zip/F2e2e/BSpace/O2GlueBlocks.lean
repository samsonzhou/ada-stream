import F2e2e.BSpace.DslBlocks
import F2e2e.BSpace.DslDefs
import F2e2e.BSpace.O2GlueLift

/-!
# B_space, route O2b: D1 `bsBlocks` in the per-call judgment `EvalsValF`

Owner: W3 (4a7299ed) (O2b slice D1; technical lead 17fc0802; consumers O2B-GST 8cf19cc0 and the `bsInit` top
frame). Prefix `o2k`.

The routine is the O1 routine `bsBlocks` (keys 900–902, `F2e2e/BSpace/DslBlocks.lean`), unchanged. Its body
calls no routine and its two loops (901, 902) have call-free bodies (depths 15 and 12), so W5's loop-only
lifting (`EvalsVal.o2g_toF_cfl`, `F2e2e/BSpace/O2GlueLift.lean`) turns O1's `bsBlocks_eval` at the uniform
bound `o2k_B = |ns| + |codes| + 32` into a per-call evaluation (C-SPACE's `EvalsValF`,
`F2e2e/BSpace/O2GstF.lean`) with
* the entry frame (900) at `(m, τ)` with `o2k_B ≤ m`, `o2k_T = 18 · o2k_B ≤ τ`;
* both loops in their own frames `(o2k_B, 0)`, charged `(15 + 3) · o2k_B` resp. `(12 + 3) · o2k_B`.

A call of `bsBlocks` at `(o2k_B, o2k_T)` costs its caller `(11 + 2) · o2k_B + 18 · o2k_B = 31 · o2k_B`
(`o2k_depth_blocks : exprDepth body_bsBlocks = 11`; `o2k_bsBlocks_callF`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B

/-! ## Bounds and depths -/

/-- The value bound of every frame of `bsBlocks` (O1's hypothesis `hM` of `bsBlocks_eval`). -/
def o2k_B (ns codes : List ℕ) : ℕ := valSize (encL encN ns) + valSize (encL encN codes) + 32

/-- The callee budget of the entry frame of `bsBlocks` (both loops in their own frames `(o2k_B, 0)`;
`max (15, 12) + 3 = 18`). -/
def o2k_T (ns codes : List ℕ) : ℕ := 18 * o2k_B ns codes

theorem o2k_depth_blocks : exprDepth body_bsBlocks = 11 := by decide

theorem o2k_depth_blocks1 : exprDepth body_bsBlocks1 = 15 := by decide

theorem o2k_depth_blocks2 : exprDepth body_bsBlocks2 = 12 := by decide

/-- `bsBlocks` calls no routine; its loops (901, 902) have call-free bodies of depth `+ 3 ≤ 18`. -/
theorem o2k_cfl {prog : List Expr} (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2) :
    o2gCFL prog 18 body_bsBlocks := by
  have h1 : prog[Idx.bsBlocks1]? = some body_bsBlocks1 :=
    hlib _ (List.mem_cons_of_mem _ List.mem_cons_self)
  have h2 : prog[Idx.bsBlocks2]? = some body_bsBlocks2 :=
    hlib _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))
  refine o2gCFL_of_B (L := [Idx.bsBlocks1, Idx.bsBlocks2]) ?_ body_bsBlocks (by decide)
  intro j hj body hbody
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hj
  rcases hj with rfl | rfl
  · rw [h1] at hbody
    cases hbody
    exact ⟨(callFreeB_iff _).mp (by decide), by have := o2k_depth_blocks1; omega⟩
  · rw [h2] at hbody
    cases hbody
    exact ⟨(callFreeB_iff _).mp (by decide), by have := o2k_depth_blocks2; omega⟩

/-! ## `bsBlocks` -/

/-- **D1 in the per-call judgment**: on `[ns, codes]` (`ns.sum ≤ |codes|`), `bsBlocks` returns the blocks
`splitBlocks ns codes` in any frame `(m, τ)` with `o2k_B ≤ m` and `o2k_T = 18 · o2k_B ≤ τ` (both loops in their
own frames `(o2k_B, 0)`). -/
theorem o2k_bsBlocks_evalsF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}
    (hO : prog[bsOracleIdx]? = none) (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2)
    {ns codes : List ℕ} (hlen : ns.sum ≤ codes.length) {m τ : ℕ}
    (hm : o2k_B ns codes ≤ m) (hτ : o2k_T ns codes ≤ τ) :
    EvalsValF orc prog m τ [Val.list [encL encN ns, encL encN codes]] [] (.inl body_bsBlocks)
      (Val.list ((splitBlocks ns codes).map (encL encN))) := by
  have henv : ∀ x ∈ [Val.list [encL encN ns, encL encN codes]], valSize x ≤ o2k_B ns codes := by
    intro x hx
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    subst hx
    simp only [o2k_B, valSize_list, listSize_cons, listSize_nil]
    omega
  have h0 : EvalsVal prog (o2k_B ns codes) [Val.list [encL encN ns, encL encN codes]] []
      (.inl body_bsBlocks) (Val.list ((splitBlocks ns codes).map (encL encN))) :=
    bsBlocks_eval hlib hlen le_rfl
  have h1 : EvalsValF orc prog (o2k_B ns codes) (o2k_T ns codes)
      [Val.list [encL encN ns, encL encN codes]] [] (.inl body_bsBlocks)
      (Val.list ((splitBlocks ns codes).map (encL encN))) :=
    EvalsVal.o2g_toF_cfl hO h0 henv (o2k_cfl hlib) le_rfl
  exact (h1.mono_m hm).mono_τ hτ

/-- **The call of `bsBlocks`** from a caller frame `(m, τ)`: the callee runs in its frame
`(o2k_B, o2k_T)`, charged `(11 + 2) · o2k_B + 18 · o2k_B = 31 · o2k_B ≤ τ`. -/
theorem o2k_bsBlocks_callF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}
    {a : Expr} (hO : prog[bsOracleIdx]? = none) (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2)
    {ns codes : List ℕ} (hlen : ns.sum ≤ codes.length)
    (ha : EvalsValF orc prog m τ env [] (.inl a) (Val.list [encL encN ns, encL encN codes]))
    (hout : valSize (Val.list ((splitBlocks ns codes).map (encL encN))) ≤ m)
    (hτ : 31 * o2k_B ns codes ≤ τ) :
    EvalsValF orc prog m τ env [] (.inl (eCall bsBlocksKey a))
      (Val.list ((splitBlocks ns codes).map (encL encN))) := by
  have h900 : prog[bsBlocksKey]? = some body_bsBlocks := hlib _ List.mem_cons_self
  have hva : valSize (Val.list [encL encN ns, encL encN codes]) ≤ o2k_B ns codes := by
    simp only [o2k_B, valSize_list, listSize_cons, listSize_nil]
    omega
  have hcost : (exprDepth body_bsBlocks + 2) * o2k_B ns codes + o2k_T ns codes ≤ τ := by
    rw [o2k_depth_blocks]
    unfold o2k_T
    omega
  exact EvalsValF.cast_bits (EvalsValF.call (by decide) ha h900
    (o2k_bsBlocks_evalsF hO hlib hlen le_rfl le_rfl) hva hout hcost) (by simp)

end F2e2e.BSpace
