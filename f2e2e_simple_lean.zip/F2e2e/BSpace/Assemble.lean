import F2e2e.BSpace.AssembleDefs
import F2e2e.BSpace.AssembleConform
import F2e2e.BSpace.RefineCoins
import F2e2e.BSpace.Pub
import F2e2e.BSpace.JointGuarantee
import F2e2e.BSpace.MachineBridgeO
import F2e2e.BSpace.V31Thread
import F2e2e.BSpace.V31HistFree
import F2e2e.C.Impl.AdaValid

/-!
# B_space, top level (C-TOP): `Theorem_B_space_with e` and `Theorem_B_joint_with e` from the per-run obligations

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §T (T1). Spec v3.1 §7 (`F2e2e/Spec.lean`). The
implementation is a pair of DSL programs `(initProg, roundProg)` on the oracle machine. For the public parameters
`M, J, R, a_req, ξ_req`, the core runs with the parameters `A = asmParams M J R a_req ξ_req`
(`= adaParams (dyadicExp a_req) (dyadicExp ξ_req) M J R`); the state of the programs is `stEnc blocks st` (the
stored blocks `asmBlocks A code s` of record codes and W4's ADA state `st`); round `t` runs the core on the
quantized request `reqs t` (`asmRound`), and its output `r` is encoded as `respEnc r` (D4: `stEnc := bsStateEnc`,
`respEnc := bsResp`).

The DSL side provides a bound `Bd M J R a_req ξ_req b_𝒰` such that every run of the core initialization (resp.
of a core round, from a state with W4's invariant `AdaOK`, for every oracle agreeing with the request where the
programs read it) is a `RunsWithinBitsO`-run of `initProg` (resp. `roundProg`) on the encoded data within `Bd`
(`AsmInitRunsW`, `V31RoundRunsW`: D4 + D5 + M* + S1). Then:

* **`reproducesFor_of`**: for every tape length `c ≥ c_B = bsCoins A`, every family of oracles with `OracleFor`
  (F-B1; `oracleFor_agrees`) the programs reproduce `alg2Mech … c` within `Bd` (hence within `2^e · N · (b_𝒰 + χ²)`
  if `Bd` is below it, S2), with the history-free states `stEnc blocks (v31h_archOf A (alg2RetainedOf … t …))`
  (F-B2 with fix F1: the retained state `alg2Retained`; `v31_states_histFree`, B-ARCH's functional `StCorr` and
  `v31h_archOf_retained`, `V31HistFree.lean`; the same `enc` also works for `alg2StateOf`, `reproducesFor_of_stateOf`);
* **`theorem_B_space_with_of`**: `Theorem_B_space_with e`;
* **`theorem_B_joint_with_of`**: `Theorem_B_joint_with e` (with B-ARCH's guarantee `alg2V2_guarantee_ge` for
  `c ≥ adaCoins A = c_B`).

The other inputs are proved: no exhaustion for `c ≥ c_B` (B-ARCH's R4 `refine_noExhaust`, `RefineCoins.lean`),
conformance with `alg2Mech` (R3 `asm_conform`, `AssembleConform.lean`), the invariant (W4's `adaInit_ok`,
`adaInterval_ok`, `adaNumerical_ok`) and the execution format with explicit states (`exec_of_thread_explicit`,
`V31Thread.lean`). The final theorems for W4's programs and W2's encodings are in `AssembleFinal.lean`
(import-DAG rule R2: only `F2e2e/Headline.lean` declares the headline names).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2

/-- The budget `2^e · N · (b_𝒰 + χ²)` of `ReproducesFor e` for the public parameters and the record length `b_𝒰`. -/
noncomputable abbrev asmBound (e M J R : ℕ) (aReq ξReq : ℝ) (bU : ℕ) : ℝ :=
  bSpaceBound e (alg2Params M J R aReq ξReq).N bU (valChi M J R (dyadicDown aReq) (dyadicDown ξReq))

/-- The run part of the DSL obligation for the initialization: every run of the core initialization `adaInit A`
on a tape is a run of `initProg` (no oracle) on `[params, records]` within `Bd`, ending in the encoded state and
leaving the same unread tape. -/
def AsmInitRunsW (initProg : List Expr) (stEnc : List (List ℕ) → AdaState → Val)
    (Bd : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℝ) : Prop :=
  ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (τ : List Bool) (st : AdaState) (τ' : List Bool),
      (adaInit (asmParams M J R aReq ξReq)).run τ = some (st, τ') →
        RunsWithinBitsO nullOracle initProg (Val.list [encVParams M J R aReq ξReq, encRecords code s]) τ
          (stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st) τ' (Bd M J R aReq ξReq bU)

/-- The run part of the DSL obligation for a request: for a valid request `req` and a core state with `AdaOK`,
every run of the core round on the quantized request is a run of `roundProg` with the oracle `reqOracle code req`
on `[params, state, isInterval]` within `Bd`, ending in `[state', response]` and leaving the same unread tape. -/
def AsmRoundRunsW (roundProg : List Expr) (stEnc : List (List ℕ) → AdaState → Val)
    (respEnc : CoreOut → Val) (Bd : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℝ) : Prop :=
  ∀ (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2),
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U), req.Valid →
    ∀ (st : AdaState) (τ : List Bool) (out : CoreOut) (st' : AdaState) (τ' : List Bool),
      C.Impl.AdaOK (asmParams M J R aReq ξReq) st →
      (bsCoreRound (asmParams M J R aReq ξReq) st
          (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
            (quantReq (asmParams M J R aReq ξReq) req))
          (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
          req.2.1).run τ = some ((out, st'), τ') →
        RunsWithinBitsO (reqOracle code req) roundProg
          (Val.list [encVParams M J R aReq ξReq, stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
            Val.int (if req.2.1 then 1 else 0)]) τ
          (Val.list [stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st', respEnc out]) τ'
          (Bd M J R aReq ξReq bU)

/-- The oracle `orc` agrees with the request oracle `reqOracle code req` on the records of the sample (selector `0`)
and at the clipped endpoints (selectors `1`, `2`), at every precision (implied by the Spec's `OracleFor` for an
injective `code`: `oracleFor_agrees`). -/
def v31OracleAgrees {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) (req : VReq U) (orc : VOracle) :
    Prop :=
  (∀ ℓ : Fin N, ∀ q : ℤ, orc 0 (code (s ℓ) : ℤ) q = reqOracle code req 0 (code (s ℓ) : ℤ) q) ∧
    ∀ r q : ℤ, orc 1 r q = reqOracle code req 1 r q ∧ orc 2 r q = reqOracle code req 2 r q

/-- The request oracle agrees with itself. -/
theorem v31OracleAgrees_self {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) (req : VReq U) :
    v31OracleAgrees code s req (reqOracle code req) :=
  ⟨fun _ _ => rfl, fun _ _ => ⟨rfl, rfl⟩⟩

/-- The run part of the DSL obligation for a request, for **every agreeing oracle**. -/
def V31RoundRunsW (roundProg : List Expr) (stEnc : List (List ℕ) → AdaState → Val)
    (respEnc : CoreOut → Val) (Bd : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℝ) : Prop :=
  ∀ (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2),
    ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code → (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U), req.Valid →
    ∀ (orc : VOracle), v31OracleAgrees code s req orc →
    ∀ (st : AdaState) (τ : List Bool) (out : CoreOut) (st' : AdaState) (τ' : List Bool),
      C.Impl.AdaOK (asmParams M J R aReq ξReq) st →
      (bsCoreRound (asmParams M J R aReq ξReq) st
          (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
            (quantReq (asmParams M J R aReq ξReq) req))
          (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
          req.2.1).run τ = some ((out, st'), τ') →
        RunsWithinBitsO orc roundProg
          (Val.list [encVParams M J R aReq ξReq, stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
            Val.int (if req.2.1 then 1 else 0)]) τ
          (Val.list [stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st', respEnc out]) τ'
          (Bd M J R aReq ξReq bU)

/-! ## The invariant `AdaOK` along the core runs (W4's `adaInit_ok`, `adaInterval_ok`, `adaNumerical_ok`) -/

theorem asm_init_ok (M J R : ℕ) (aReq ξReq : ℝ) {τ : List Bool} {st : AdaState} {τ' : List Bool}
    (h : (adaInit (asmParams M J R aReq ξReq)).run τ = some (st, τ')) :
    C.Impl.AdaOK (asmParams M J R aReq ξReq) st :=
  C.Alg.Always.of_run (C.Impl.adaInit_ok (bsP_blockSizes_length _ _ _ _ _)) h

theorem asm_round_ok {A : AdaParams} {st : AdaState} (hok : C.Impl.AdaOK A st) {vals : List (List ℕ)}
    {l u : ℚ} {kind : Bool} {τ : List Bool} {out : CoreOut} {st' : AdaState} {τ' : List Bool}
    (h : (bsCoreRound A st vals l u kind).run τ = some ((out, st'), τ')) : C.Impl.AdaOK A st' := by
  cases kind
  · rw [bsCoreRound_false, BitProg.run_map] at h
    obtain ⟨⟨⟨x, st1⟩, τ1⟩, hrun, heq⟩ := Option.map_eq_some_iff.mp h
    simp only [Prod.mk.injEq] at heq
    obtain ⟨⟨-, rfl⟩, -⟩ := heq
    exact C.Alg.Always.of_run (C.Impl.adaNumerical_ok hok vals) hrun
  · rw [bsCoreRound_true, BitProg.run_map] at h
    obtain ⟨⟨⟨c, st1⟩, τ1⟩, hrun, heq⟩ := Option.map_eq_some_iff.mp h
    simp only [Prod.mk.injEq] at heq
    obtain ⟨⟨-, rfl⟩, -⟩ := heq
    exact C.Alg.Always.of_run (C.Impl.adaInterval_ok hok vals l u) hrun

/-! ## F-B1: oracles agreeing with the request where the programs read them -/

theorem reqOracle_code_eq {U : Type} {code : U → ℕ} (hinj : Function.Injective code) (req : VReq U) (x : U)
    (q : ℤ) : reqOracle code req 0 (code x : ℤ) q = truncIdx q.toNat (req.1 x) := by
  have hex : ∃ y, (code y : ℤ) = (code x : ℤ) := ⟨x, rfl⟩
  have hch : Classical.choose hex = x := hinj (by exact_mod_cast Classical.choose_spec hex)
  unfold reqOracle
  simp only [if_true, dif_pos hex, hch]

theorem reqOracle_one_eq {U : Type} (code : U → ℕ) (req : VReq U) (r q : ℤ) :
    reqOracle code req 1 r q = truncIdx q.toNat (max (-1) (min 2 req.2.2.1)) := by
  unfold reqOracle
  simp

theorem reqOracle_two_eq {U : Type} (code : U → ℕ) (req : VReq U) (r q : ℤ) :
    reqOracle code req 2 r q = truncIdx q.toNat (max (-1) (min 2 req.2.2.2)) := by
  unfold reqOracle
  simp

/-- An oracle with the Spec's `OracleFor` agrees with the request oracle on the sample's codes and on the endpoints. -/
theorem oracleFor_agrees {U : Type} {N : ℕ} {code : U → ℕ} (hinj : Function.Injective code)
    {s : Fin N → U} {req : VReq U} {orc : VOracle} (h : OracleFor code s req orc) :
    v31OracleAgrees code s req orc :=
  ⟨fun ℓ q => (h.1 ℓ q).trans (reqOracle_code_eq hinj req (s ℓ) q).symm,
    fun r q => ⟨(h.2.1 r q).trans (reqOracle_one_eq code req r q).symm,
      (h.2.2 r q).trans (reqOracle_two_eq code req r q).symm⟩⟩

/-! ## F-B2: history-free states -/

/-- Algorithm 2's state after the requests `0, …, t-1` of `reqs` (the state component of the Spec's replay fold
from `alg2Init` on the tape `τ0`). -/
noncomputable def asmSpecState {U : Type} (P2 : Alg2Params) (s : Fin P2.N → U) (reqs : ℕ → VReq U)
    (τ0 : List Bool) (t : ℕ) : Alg2State :=
  ((List.ofFn fun j : Fin t => asmView s reqs j.val).foldl (asmStep P2)
    (VResponse.accept, (alg2Init P2 τ0).1, (alg2Init P2 τ0).2)).2.1

/-- **History-freeness of the states** (F-B2): with a functional `StCorr` (`archOf`), the implementation's state
before round `t` (the explicit states of `exec_of_thread_explicit`) is `encS (archOf (Algorithm 2's state after t
requests))`. -/
theorem v31_states_histFree {U : Type} {P2 : Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid)
    (τ0 : List Bool) (archOf : Alg2State → AdaState)
    (harch : ∀ st2 st, StCorr A st2 st → archOf st2 = st) (encS : AdaState → Val) (t : ℕ)
    (htot : (threadRun (adaInit A) (asmRound A (castSample hN s) reqs) τ0 t).isSome) :
    threadStates encS (adaInit A) (asmRound A (castSample hN s) reqs) τ0 t =
      encS (archOf (asmSpecState P2 s reqs τ0 t)) := by
  obtain ⟨⟨st, τ⟩, h⟩ := Option.isSome_iff_exists.mp htot
  obtain ⟨acc, st2, hfold, hcorr⟩ := asm_fold hP hN s reqs hvalid τ0 t st τ h
  have hst2 : asmSpecState P2 s reqs τ0 t = st2 := by
    unfold asmSpecState
    rw [hfold]
  rw [threadStates_of h, hst2, harch st2 st hcorr]

/-! ## The assembly -/

section Assembly

variable {initProg roundProg : List Expr} {stEnc : List (List ℕ) → AdaState → Val} {respEnc : CoreOut → Val}
  {Bd : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ → ℝ}

/-- **Reproduction, generic in the abstract state** (Spec v3.1 `ReproducesFor` with any `stateOf`): for every
`c ≥ c_B` and every agreeing oracle family, an execution exists whose states are
`stEnc blocks (arch (stateOf … t (viewsBefore s reqs t) ω))`, as soon as `arch` recovers, from `stateOf`, the core
state corresponding (`StCorr`) to Algorithm 2's state `alg2StateOf … t views ω` (`hstate`). -/
theorem reproducesFor_of_corr (hparse : ∀ r, parseVResponse (respEnc r) = some (outRespV2 r))
    (hI : AsmInitRunsW initProg stEnc Bd) (hR : V31RoundRunsW roundProg stEnc respEnc Bd) {e : ℕ}
    {M J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hBd : ∀ bU, Bd M J R aReq ξReq bU ≤ asmBound e M J R aReq ξReq bU)
    {c : ℕ} (hc : bsCoins (asmParams M J R aReq ξReq) ≤ c) {σ : Type}
    (stateOf : (M J R : ℕ) → (aReq ξReq : ℝ) → (c : ℕ) → (t : ℕ) →
      (Fin t → VView (alg2Params M J R aReq ξReq).N) → (Fin c → Bool) → σ)
    (arch : σ → AdaState)
    (hstate : ∀ (t : ℕ) (views : Fin t → VView (alg2Params M J R aReq ξReq).N) (ω : Fin c → Bool)
      (st : AdaState), StCorr (asmParams M J R aReq ξReq) (alg2StateOf M J R aReq ξReq c t views ω) st →
        arch (stateOf M J R aReq ξReq c t views ω) = st) :
    ReproducesFor e (fun M J R aReq ξReq => (alg2Params M J R aReq ξReq).N) alg2Mech stateOf
      ⟨initProg, roundProg⟩ M J R aReq ξReq c := by
  intro U _ bU code hinj hcode s
  have hP := refine_parCorr M J R ha0 ha1 hξ0 hξ1
  have hN := refine_N M J R ha0 ha1 hξ0 hξ1
  refine ⟨fun x => stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) (arch x),
    fun ω reqs hvalid orcs hOF => ?_⟩
  have hτ : bsCoins (asmParams M J R aReq ξReq) ≤ (List.ofFn ω).length := by
    rw [List.length_ofFn]
    exact hc
  have htot : ∀ t, (threadRun (adaInit (asmParams M J R aReq ξReq))
      (asmRound (asmParams M J R aReq ξReq) (castSample hN s) reqs) (List.ofFn ω) (t + 1)).isSome :=
    fun t => refine_noExhaust (asmParams M J R aReq ξReq)
      (fun t => coreVals (asmParams M J R aReq ξReq) (castSample hN s)
        (quantReq (asmParams M J R aReq ξReq) (reqs t)))
      (fun t => (quantReq (asmParams M J R aReq ξReq) (reqs t)).l)
      (fun t => (quantReq (asmParams M J R aReq ξReq) (reqs t)).u)
      (fun t => (reqs t).2.1) (List.ofFn ω) hτ (t + 1)
  obtain ⟨hinit, hrounds⟩ := exec_of_thread_explicit RunsWithinBitsO
    (C.Impl.AdaOK (asmParams M J R aReq ξReq))
    (init := adaInit (asmParams M J R aReq ξReq))
    (round := asmRound (asmParams M J R aReq ξReq) (castSample hN s) reqs)
    (encS := stEnc (asmBlocks (asmParams M J R aReq ξReq) code s)) (encR := respEnc) (orcs := orcs)
    (orc0 := nullOracle) (initProg := initProg) (roundProg := roundProg)
    (params := encVParams M J R aReq ξReq) (records := encRecords code s) (kinds := fun t => (reqs t).2.1)
    (S := bSpaceBound e (alg2Params M J R aReq ξReq).N bU (valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
    (resps := fun t => alg2Mech M J R aReq ξReq c t (viewsOf s reqs t) ω) (parse := parseVResponse)
    (fun st τ h => ⟨asm_init_ok M J R aReq ξReq h,
      RunsWithinBitsO.mono (hI M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s _ st τ h) (hBd bU)⟩)
    (fun t st τ r st' τ' hok h => ⟨asm_round_ok hok h,
      RunsWithinBitsO.mono
        (hR M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hinj hcode s (reqs t) (hvalid t) (orcs t)
          (oracleFor_agrees hinj (hOF t)) st τ r st' τ' hok h)
        (hBd bU)⟩)
    htot
    (fun t r h => by
      rw [hparse, asm_conform hP hN s reqs hvalid ω t r h]
      rfl)
  refine ⟨threadStates (stEnc (asmBlocks (asmParams M J R aReq ξReq) code s))
      (adaInit (asmParams M J R aReq ξReq)) (asmRound (asmParams M J R aReq ξReq) (castSample hN s) reqs)
      (List.ofFn ω),
    ⟨threadTapes (adaInit (asmParams M J R aReq ξReq))
      (asmRound (asmParams M J R aReq ξReq) (castSample hN s) reqs) (List.ofFn ω), hinit, hrounds⟩,
    fun t => ?_⟩
  obtain ⟨⟨st, τ⟩, h⟩ := Option.isSome_iff_exists.mp (threadRun_isSome_of_succ (htot t))
  obtain ⟨acc, st2, hfold, hcorr⟩ := asm_fold hP hN s reqs hvalid (List.ofFn ω) t st τ h
  have hst2 : alg2StateOf M J R aReq ξReq c t (viewsBefore s reqs t) ω = st2 := by
    have e1 : alg2StateOf M J R aReq ξReq c t (viewsBefore s reqs t) ω =
        asmSpecState (alg2Params M J R aReq ξReq) s reqs (List.ofFn ω) t := rfl
    rw [e1]
    unfold asmSpecState
    rw [hfold]
  rw [threadStates_of h]
  show stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st =
    stEnc (asmBlocks (asmParams M J R aReq ξReq) code s) (arch (stateOf M J R aReq ξReq c t (viewsBefore s reqs t) ω))
  rw [hstate t (viewsBefore s reqs t) ω st (by rw [hst2]; exact hcorr)]

/-- **Reproduction against the full state** (`ReproducesFor` with `stateOf := alg2StateOf`; every agreeing oracle
family, history-free states `stEnc blocks (v31h_archOf A (alg2StateOf … t …))`), for every `c ≥ c_B`. The Spec uses
the retained state instead (`reproducesFor_of`); both hold, with the same `enc`. -/
theorem reproducesFor_of_stateOf (hparse : ∀ r, parseVResponse (respEnc r) = some (outRespV2 r))
    (hI : AsmInitRunsW initProg stEnc Bd) (hR : V31RoundRunsW roundProg stEnc respEnc Bd) {e : ℕ}
    {M J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hBd : ∀ bU, Bd M J R aReq ξReq bU ≤ asmBound e M J R aReq ξReq bU)
    {c : ℕ} (hc : bsCoins (asmParams M J R aReq ξReq) ≤ c) :
    ReproducesFor e (fun M J R aReq ξReq => (alg2Params M J R aReq ξReq).N) alg2Mech alg2StateOf
      ⟨initProg, roundProg⟩ M J R aReq ξReq c :=
  reproducesFor_of_corr hparse hI hR ha0 ha1 hξ0 hξ1 hBd hc alg2StateOf
    (V31.v31h_archOf (asmParams M J R aReq ξReq)) (fun _ _ _ _ h => V31.v31h_archOf_eq h)

/-- **Reproduction** (Spec v3.1 `ReproducesFor` with `stateOf := alg2RetainedOf`, fix F1; every agreeing oracle
family), for every `c ≥ c_B`: the history-free states are `stEnc blocks (v31h_archOf A (alg2RetainedOf … t …))`.
`v31h_archOf A` does not see the score coordinates that `alg2Retained` zeroes (`v31h_archOf_retained`), so the
core state recovered from the retained state is the one corresponding to `alg2StateOf … t …`. -/
theorem reproducesFor_of (hparse : ∀ r, parseVResponse (respEnc r) = some (outRespV2 r))
    (hI : AsmInitRunsW initProg stEnc Bd) (hR : V31RoundRunsW roundProg stEnc respEnc Bd) {e : ℕ}
    {M J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hBd : ∀ bU, Bd M J R aReq ξReq bU ≤ asmBound e M J R aReq ξReq bU)
    {c : ℕ} (hc : bsCoins (asmParams M J R aReq ξReq) ≤ c) :
    ReproducesFor e (fun M J R aReq ξReq => (alg2Params M J R aReq ξReq).N) alg2Mech alg2RetainedOf
      ⟨initProg, roundProg⟩ M J R aReq ξReq c :=
  reproducesFor_of_corr hparse hI hR ha0 ha1 hξ0 hξ1 hBd hc alg2RetainedOf
    (V31.v31h_archOf (asmParams M J R aReq ξReq))
    (fun t views ω _ h =>
      (V31.v31h_archOf_retained (refine_parCorr M J R ha0 ha1 hξ0 hξ1)
        (alg2StateOf M J R aReq ξReq c t views ω)).trans (V31.v31h_archOf_eq h))

/-- **Theorem (B), bit-space clause with the constant `2^e`**, from the DSL obligations. -/
theorem theorem_B_space_with_of (hparse : ∀ r, parseVResponse (respEnc r) = some (outRespV2 r))
    (hI : AsmInitRunsW initProg stEnc Bd) (hR : V31RoundRunsW roundProg stEnc respEnc Bd) {e : ℕ}
    (hBd : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
      ∀ bU, Bd M J R aReq ξReq bU ≤ asmBound e M J R aReq ξReq bU) :
    Theorem_B_space_with e :=
  ⟨⟨initProg, roundProg⟩, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 =>
    ⟨bsCoins (asmParams M J R aReq ξReq), fun _ hc =>
      reproducesFor_of hparse hI hR ha0 ha1 hξ0 hξ1 (hBd M J R aReq ξReq ha0 ha1 hξ0 hξ1) hc⟩⟩

/-- **Theorem (B), guarantee and bit-space clause jointly, with the constant `2^e`** (B-ARCH's guarantee
`alg2V2_guarantee_ge` for `c ≥ adaCoins A = c_B`). -/
theorem theorem_B_joint_with_of (hparse : ∀ r, parseVResponse (respEnc r) = some (outRespV2 r))
    (hI : AsmInitRunsW initProg stEnc Bd) (hR : V31RoundRunsW roundProg stEnc respEnc Bd) {e : ℕ}
    (hBd : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
      ∀ bU, Bd M J R aReq ξReq bU ≤ asmBound e M J R aReq ξReq bU) :
    Theorem_B_joint_with e :=
  ⟨⟨initProg, roundProg⟩, fun M J R aReq ξReq ha0 ha1 hξ0 hξ1 =>
    ⟨bsCoins (asmParams M J R aReq ξReq), fun c hc => ⟨alg2V2_guarantee_ge M J R ha0 ha1 hξ0 hξ1 c hc,
      reproducesFor_of hparse hI hR ha0 ha1 hξ0 hξ1 (hBd M J R aReq ξReq ha0 ha1 hξ0 hξ1) hc⟩⟩⟩

end Assembly

end F2e2e.BSpace
