import F2e2e.BSpace.O2T.AdaEntryNumT
import F2e2e.BSpace.O2T.AdaPrepT
import F2e2e.BSpace.AsmTable

/-!
# B_space, route O2b: the `adaNumerical` (603) instance on `bsRoundProg` (o2ct)

Owner: C-TREE (51e3826d), for the O2b technical lead 17fc0802 and C-BANK's top frame (P5).

The uniform tight spec of `adaNumerical` (A-ARCH's `adaNumerical_impl_of_t`, `F2e2e/BSpace/O2T/AdaEntryNumT.lean`)
instantiated on the round program `bsRoundProg` (`F2e2e/BSpace/AsmTable.lean`): the table facts `MusLib`, `SampLib`,
`ListLib` come from `bsLib_round.w4Lib`, `NormQSpec` from `bsLib_round.normQ`, and the premise `NumPrepAt` from
the tight spec of `PrepareRoot` (A-VAL's `adaPrep_impl_t`, `F2e2e/BSpace/O2T/AdaPrepT.lean`), as in
`F2e2e/BSpace/DslMain.lean` (L445–461) for the old bound. This is the premise `hspec` of A-ARCH's
`o2m_numAt_of_lift` / `o2m_numAt_wt` (`F2e2e/BSpace/O2GlueMainCallees.lean`) on `bsRoundProg`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- **`PrepareRoot` at its index in `bsRoundProg`** (tight value premise). -/
theorem o2ct_numPrepAt {M : ℕ} {A : AdaParams} {vals : List (List ℕ)} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) (hv : ValsOKA A vals)
    (hMt : TightM A M) : NumPrepAt bsRoundProg M A vals :=
  ⟨body_adaPrep, bsLib_round.w4Lib.prepTbl (Idx.adaPrepR, body_adaPrep) (by simp [adaPrepTable]),
    fun _ f _ hok' hf hc => adaPrep_impl_t bsLib_round.w4Lib.prepTbl bsLib_round.w4Lib.mus
      bsLib_round.w4Lib.samp bsLib_round.w4Lib.list hbs hT hpos hok' hv f hf hc hMt⟩

/-- **`adaNumerical` (603) on `bsRoundProg`** at any tight frame bound `M` (`TightM A M`). -/
theorem o2ct_num_impl {M : ℕ} {A : AdaParams} {vals : List (List ℕ)} (hbs : A.blockSizes.length = A.p + 1)
    (hT : A.Tmax.length = A.p) (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState}
    (hok : AdaOK A st) (hv : ValsOKA A vals) (hMt : TightM A M) :
    Implements bsRoundProg M [Val.list [adaPubEnc A, adaEnc st, encVals vals]] body_adaNumerical
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals) :=
  adaNumerical_impl_of_t (o2ct_numPrepAt hbs hT hpos hv hMt) bsLib_round.w4Lib.mus bsLib_round.w4Lib.samp
    bsLib_round.w4Lib.list (bsLib_round.normQ M) hbs hT hpos hok hv hMt

end F2e2e.BSpace
