import F2e2e.BSpace.AssembleConform
import F2e2e.BSpace.DslDefs

/-!
# Spec v3.1, F-B2 (history-freeness), B side (B-ARCH): the core state is a function of Algorithm 2's state

Owner: B-ARCH (dc387564), for the lead's v3.1 fix F-B2 (composition: C-TOP, `V31Thread.lean` /
`V31Assemble.lean`). The bridge relation `StCorr A σ st` (`F2e2e/B/SpecV2BridgeCorr.lean`) between a state `σ`
of the Spec's Algorithm 2 and a core state `st` is **functional**: every field of `st` is pinned by `σ`
(the scores by `G = (h_A/4) g` with `h_A > 0`, the lists `T`, `thrInt` by their length `p` and entries, the
weights by `w_j = capWeightsQ (scoreScale A) g_j`, the counters and flags by equality). Hence:

* `v31h_stCorr_unique : StCorr A σ st → StCorr A σ st' → st = st'`;
* `v31h_archOf A σ`: the core state of `σ` (a choice; `v31h_archOf_eq : StCorr A σ st → v31h_archOf A σ = st`);
* `v31h_enc A blocks σ := bsStateEnc blocks (v31h_archOf A σ)`: the history-free encoding (the B state stores
  only the blocks and `adaEnc st`; no cache, no pre-request copy, no tape position);
* `v31h_fold_enc`: along a successful threaded core run (`threadRun`, C-TOP's `asm_fold`), the stored state after
  `n` rounds is `v31h_enc A blocks σ_n` with `σ_n` the state component of the Spec's replay fold of `alg2Request`
  over the views of rounds `0, …, n-1` (from `alg2Init` on the same tape).

**v3.1 fix F1 (retained state).** The Spec's `alg2Correct` updates `G j i` for every `i`, so the coordinates
`i ≥ n_j` carry junk; v3.1 compares the stored state with the *retained* state `alg2Retained P σ` (`G` zeroed outside
`j < p ∧ i < n_j`; `T`, `thrInt` and the scalars unchanged). `StCorr` reads `G` only inside that range, so:
* `v31h_stCorr_retained_iff (hP : ParCorr P2 A) : StCorr A (alg2Retained P2 σ) st ↔ StCorr A σ st` (every `σ`);
* `v31h_archOf_retained`, `v31h_enc_retained : v31h_enc A blocks (alg2Retained P2 σ) = v31h_enc A blocks σ`;
* `v31h_fold_enc_retained`: the stored state after `n` rounds is `v31h_enc A blocks (alg2Retained P2 σ_n)`.
The lemmas are stated with the Spec's `alg2Retained` (`F2e2e/Spec.lean`, v3.1 F1); `v31h_retained` is a
reducible compatibility name for it.
-/

namespace F2e2e.BSpace.V31

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.C.Impl

/-! ## Uniqueness of the corresponding core state -/

/-- Two lists of the same length with the same entries (read with `getD d`) are equal. -/
theorem v31h_list_ext_getD {α : Type} {l l' : List α} (d : α) (hlen : l.length = l'.length)
    (h : ∀ i < l.length, l.getD i d = l'.getD i d) : l = l' := by
  apply List.ext_getElem hlen
  intro i h1 h2
  have e := h i h1
  rwa [List.getD_eq_getElem _ _ h1, List.getD_eq_getElem _ _ h2] at e

/-- `h_A ≠ 0` (as a real number). -/
theorem v31h_hA_ne (A : AdaParams) : (A.hA : ℝ) ≠ 0 := by
  have h : 0 < A.hA := by
    unfold AdaParams.hA
    positivity
  exact_mod_cast h.ne'

/-- **`StCorr` is functional**: a state of Algorithm 2 has at most one corresponding core state. -/
theorem v31h_stCorr_unique {A : AdaParams} {σ : F2e2e.Alg2State} {st st' : AdaState}
    (h1 : StCorr A σ st) (h2 : StCorr A σ st') : st = st' := by
  have hA4 : (A.hA : ℝ) / 4 ≠ 0 := div_ne_zero (v31h_hA_ne A) (by norm_num)
  -- the scores
  have hsc : st.scores = st'.scores := by
    refine v31h_list_ext_getD [] (by rw [h1.slen, h2.slen]) fun j hj => ?_
    have hj' : j < A.p := by rw [h1.slen] at hj; exact hj
    refine v31h_list_ext_getD 0 (by rw [h1.blen j hj', h2.blen j hj']) fun i hi => ?_
    have hi' : i < A.blockSizes.getD j 0 := by rw [h1.blen j hj'] at hi; exact hi
    have e := (h1.G j hj' i hi').symm.trans (h2.G j hj' i hi')
    exact_mod_cast mul_left_cancel₀ hA4 e
  -- the weights
  have hw : st.weights = st'.weights := by
    refine v31h_list_ext_getD [] (by rw [h1.wlen, h2.wlen]) fun j hj => ?_
    have hj' : j < A.p := by rw [h1.wlen] at hj; exact hj
    rw [h1.w j hj', h2.w j hj', hsc]
  -- the correction counters and the internal thresholds
  have hT : st.T = st'.T :=
    v31h_list_ext_getD 0 (by rw [h1.Tlen, h2.Tlen]) fun j _ => by rw [← h1.T j, ← h2.T j]
  have hthr : st.thrInt = st'.thrInt :=
    v31h_list_ext_getD 0 (by rw [h1.thrlen, h2.thrlen]) fun j _ => by rw [← h1.thr j, ← h2.thr j]
  -- the scalar fields
  have hto : st.thrOut = st'.thrOut := h1.thrOut.symm.trans h2.thrOut
  have hrej : st.rej = st'.rej := h1.rej.symm.trans h2.rej
  have hni : st.nInt = st'.nInt := h1.nInt.symm.trans h2.nInt
  have hnn : st.nNum = st'.nNum := h1.nNum.symm.trans h2.nNum
  have hhl : st.halted = st'.halted := h1.halted.symm.trans h2.halted
  have hca : st.capAborted = st'.capAborted := h1.aborted.symm.trans h2.aborted
  cases st
  cases st'
  simp only at hsc hw hT hthr hto hrej hni hnn hhl hca
  subst hsc hw hT hthr hto hrej hni hnn hhl hca
  rfl

/-! ## The core state of a state of Algorithm 2, and the history-free encoding -/

open Classical in
/-- **The core state of a state of Algorithm 2**: the (unique, `v31h_stCorr_unique`) corresponding core state if
there is one, and an arbitrary fixed state otherwise. -/
noncomputable def v31h_archOf (A : AdaParams) (σ : F2e2e.Alg2State) : AdaState :=
  if h : ∃ st, StCorr A σ st then Classical.choose h
  else ⟨[], [], [], [], 0, 0, 0, 0, false, false⟩

theorem v31h_archOf_eq {A : AdaParams} {σ : F2e2e.Alg2State} {st : AdaState} (h : StCorr A σ st) :
    v31h_archOf A σ = st := by
  have hex : ∃ st, StCorr A σ st := ⟨st, h⟩
  unfold v31h_archOf
  rw [dif_pos hex]
  exact v31h_stCorr_unique (Classical.choose_spec hex) h

/-- **The history-free encoding** of a state of Algorithm 2, for the stored blocks `blocks`: the B state
`bsStateEnc blocks st` of its core state. -/
noncomputable def v31h_enc (A : AdaParams) (blocks : List (List ℕ)) (σ : F2e2e.Alg2State) : Val :=
  bsStateEnc blocks (v31h_archOf A σ)

theorem v31h_enc_eq {A : AdaParams} {blocks : List (List ℕ)} {σ : F2e2e.Alg2State} {st : AdaState}
    (h : StCorr A σ st) : v31h_enc A blocks σ = bsStateEnc blocks st := by
  unfold v31h_enc
  rw [v31h_archOf_eq h]

/-! ## Along the threaded run -/

/-- **History-freeness along the threaded core run.** If the threaded run (`adaInit A`, then the rounds
`asmRound A (castSample hN s) reqs k`) succeeds for `n` rounds on the tape `τ0` with the state `st`, then the B state
`bsStateEnc blocks st` is the history-free encoding `v31h_enc A blocks σ_n` of the state `σ_n` of the Spec's replay
fold of `alg2Request` over the views of the rounds `0, …, n-1` (from `alg2Init P2 τ0`). -/
theorem v31h_fold_enc {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid)
    (τ0 : List Bool) (blocks : List (List ℕ)) (n : ℕ) {st : AdaState} {τ : List Bool}
    (h : threadRun (adaInit A) (asmRound A (castSample hN s) reqs) τ0 n = some (st, τ)) :
    bsStateEnc blocks st = v31h_enc A blocks
      ((List.ofFn fun j : Fin n => asmView s reqs j.val).foldl (asmStep P2)
        (F2e2e.VResponse.accept, (F2e2e.alg2Init P2 τ0).1, (F2e2e.alg2Init P2 τ0).2)).2.1 := by
  obtain ⟨acc, st2, hfold, hcorr⟩ := asm_fold hP hN s reqs hvalid τ0 n st τ h
  rw [hfold]
  exact (v31h_enc_eq hcorr).symm

/-! ## v3.1 fix F1: the retained state -/

/-- Compatibility name (reducible) for the Spec's **retained state** `alg2Retained` (v3.1 F1, `SpecDefs`): the
scores `G j i` outside the learned blocks' points (`j < p`, `i < n_j`) are zeroed; everything else is kept. -/
noncomputable abbrev v31h_retained (P : F2e2e.Alg2Params) (st : F2e2e.Alg2State) : F2e2e.Alg2State :=
  alg2Retained P st

/-- **`StCorr` does not see the coordinates outside the retained range**: for corresponding parameters,
`StCorr A (retained σ) st ↔ StCorr A σ st`, for every state `σ`. -/
theorem v31h_stCorr_retained_iff {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    {σ : F2e2e.Alg2State} {st : AdaState} :
    StCorr A (alg2Retained P2 σ) st ↔ StCorr A σ st := by
  have key : ∀ j < A.p, ∀ i < A.blockSizes.getD j 0, (alg2Retained P2 σ).G j i = σ.G j i := by
    intro j hj i hi
    show (if j < P2.p ∧ i < P2.n j then σ.G j i else 0) = σ.G j i
    rw [if_pos ⟨by rw [hP.hp]; exact hj, by rw [hP.hn j hj.le]; exact hi⟩]
  constructor
  · intro h
    exact { h with G := fun j hj i hi => (key j hj i hi).symm.trans (h.G j hj i hi) }
  · intro h
    exact { h with G := fun j hj i hi => (key j hj i hi).trans (h.G j hj i hi) }

/-- The core state of the retained state is the core state of the state. -/
theorem v31h_archOf_retained {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (σ : F2e2e.Alg2State) : v31h_archOf A (alg2Retained P2 σ) = v31h_archOf A σ := by
  by_cases hex : ∃ st, StCorr A σ st
  · obtain ⟨st, h⟩ := hex
    rw [v31h_archOf_eq h, v31h_archOf_eq ((v31h_stCorr_retained_iff hP).mpr h)]
  · have hex' : ¬ ∃ st, StCorr A (alg2Retained P2 σ) st :=
      fun ⟨st, h⟩ => hex ⟨st, (v31h_stCorr_retained_iff hP).mp h⟩
    unfold v31h_archOf
    rw [dif_neg hex, dif_neg hex']

/-- **The history-free encoding does not see the coordinates outside the retained range.** -/
theorem v31h_enc_retained {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (blocks : List (List ℕ)) (σ : F2e2e.Alg2State) :
    v31h_enc A blocks (alg2Retained P2 σ) = v31h_enc A blocks σ := by
  unfold v31h_enc
  rw [v31h_archOf_retained hP]

/-- **History-freeness along the threaded core run, retained form** (v3.1 F1): the B state after `n` rounds is the
history-free encoding of the retained state of the Spec's replay fold. -/
theorem v31h_fold_enc_retained {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) (s : Fin P2.N → U) (reqs : ℕ → VReq U) (hvalid : ∀ t, (reqs t).Valid)
    (τ0 : List Bool) (blocks : List (List ℕ)) (n : ℕ) {st : AdaState} {τ : List Bool}
    (h : threadRun (adaInit A) (asmRound A (castSample hN s) reqs) τ0 n = some (st, τ)) :
    bsStateEnc blocks st = v31h_enc A blocks (alg2Retained P2
      ((List.ofFn fun j : Fin n => asmView s reqs j.val).foldl (asmStep P2)
        (F2e2e.VResponse.accept, (F2e2e.alg2Init P2 τ0).1, (F2e2e.alg2Init P2 τ0).2)).2.1) := by
  rw [v31h_enc_retained hP]
  exact v31h_fold_enc hP hN s reqs hvalid τ0 blocks n h

end F2e2e.BSpace.V31
