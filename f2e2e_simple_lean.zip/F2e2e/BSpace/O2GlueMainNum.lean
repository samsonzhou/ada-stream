import F2e2e.BSpace.O2GlueMainPre
import F2e2e.BSpace.O2SizeData

/-!
# B_space, route O2b, top frame of `body_bsRound`: (P2) the numerical branch

Owner: 1beb339b (O2b top frames, piece P2; C-BANK 47a44866 owns the family `O2GlueMain*` and composes P4).

`bsNumBranch` (W2's D4, `F2e2e/BSpace/DslBodies.lean`), in the environment `[encVals vals, adaPubEnc A, inp]`
after the prefix: the call of `adaNumerical` (603, at its own `(mN, τN)`, C-BANK's callee predicate
`O2mNumAt`), then the new B state `[blocks, adaEnc st']` and the response `bsResp (Sum.inr x)`.

* `o2mNumB`: the value bound of the branch: the input, the parameter record, the query table, the new ADA
  state (`o2mStB A`, B-ACC's bound for `AdaOK`) and `4 q_A + 64` (the numerical output `≤ 2 q_A + 10`, the
  response `≤ 2 q_A + 12`, O2B-SIZE's `o2s_adaNumerical_resp_le`);
* **P2** `o2m_numF`: the branch implements the numerical case of `bsCoreRound` in the top frame `(m, τ)` with
  `o2mNumB ≤ m` and `(exprDepth body_adaNumerical + 2) mN + τN ≤ τ`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- **The value bound of the numerical branch.** -/
def o2mNumB (Mc J R eA eXi : ℕ) (blocks : List (List ℕ)) (st : AdaState) (vals : List (List ℕ)) : ℕ :=
  valSize (o2mInp Mc J R eA eXi blocks st false) + valSize (adaPubEnc (adaParams eA eXi Mc J R)) +
    valSize (encVals vals) + o2mStB (adaParams eA eXi Mc J R) + 4 * (adaParams eA eXi Mc J R).qA + 64

/-- **P2: the numerical branch.** In the top frame `(m, τ)`, after the prefix, `bsNumBranch` implements the
numerical case of `bsCoreRound` (the call of `adaNumerical` at its own `(mN, τN)`, then the new B state and
the response). -/
theorem o2m_numF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {Mc J R eA eXi : ℕ}
    {blocks : List (List ℕ)} {st : AdaState} (hok : AdaOK (adaParams eA eXi Mc J R) st)
    {vals : List (List ℕ)} {mN τN : ℕ} (hNum : O2mNumAt orc prog mN τN (adaParams eA eXi Mc J R) st vals)
    {m τ : ℕ} (hm : o2mNumB Mc J R eA eXi blocks st vals ≤ m)
    (hτ : (exprDepth body_adaNumerical + 2) * mN + τN ≤ τ) (l u : ℚ) :
    ImplementsF orc prog m τ [encVals vals, adaPubEnc (adaParams eA eXi Mc J R),
        o2mInp Mc J R eA eXi blocks st false] bsNumBranch
      (fun r => Val.list [bsStateEnc blocks r.2, bsResp r.1])
      (bsCoreRound (adaParams eA eXi Mc J R) st vals l u false) := by
  obtain ⟨h603, hargN, hI⟩ := hNum
  set A := adaParams eA eXi Mc J R with hA
  set inp := o2mInp Mc J R eA eXi blocks st false with hinpD
  unfold o2mNumB at hm
  rw [← hA, ← hinpD] at hm
  have hstB := o2m_valSize_adaEnc_le hok
  have hinp : valSize inp ≤ m := by omega
  have hpub : valSize (adaPubEnc A) ≤ m := by omega
  have hvalsM : valSize (encVals vals) ≤ m := by omega
  have hinpS : valSize inp = valSize (encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) +
      valSize (bsStateEnc blocks st) + valSize (encB false) + 4 := by
    rw [hinpD]
    unfold o2mInp
    rw [bsE_vs_three]
  have hstE : valSize (bsStateEnc blocks st) ≤ m := by omega
  have hstS : valSize (Val.list (blocks.map (encL encN))) + valSize (adaEnc st) + 3 ≤
      valSize (bsStateEnc blocks st) := by
    unfold bsStateEnc
    rw [bsE_vs_two]
  /- ### The argument and the call -/
  have hargs : EvalsValF orc prog m τ [encVals vals, adaPubEnc A, inp] []
      (.inl (eList [eV 1, eAtN 1 (eAtN 1 (eV 2)), eV 0]))
      (Val.list [adaPubEnc A, adaEnc st, encVals vals]) := by
    refine o2m_list (List.Forall₂.cons (EvalsValF.var rfl) (List.Forall₂.cons
      (o2m_atN (o2m_atN (EvalsValF.var rfl) hinp rfl) hstE rfl)
      (List.Forall₂.cons (EvalsValF.var rfl) List.Forall₂.nil))) ?_
    rw [bsE_vs_three]
    omega
  have hres : ∀ bits (r : AdaNum × AdaState), (adaNumerical A st vals).run bits = some (r, []) →
      AdaOK A r.2 ∧ valSize (encNum r.1) ≤ 2 * A.qA + 10 ∧
        valSize (bsResp (Sum.inr r.1)) ≤ o2sRespBound A.qA := fun bits r h =>
    ⟨Always.of_run (adaNumerical_ok hok vals) h,
      Always.of_run (DAlw.toBits (adaDraw_adaKB A) (adaNumericalD_num_le A st vals)) h,
      Always.of_run (o2s_adaNumerical_resp_le A st vals) h⟩
  have hcall : ImplementsF orc prog m τ [encVals vals, adaPubEnc A, inp]
      (eCall Idx.adaNumerical (eList [eV 1, eAtN 1 (eAtN 1 (eV 2)), eV 0]))
      (fun r => Val.list [encNum r.1, adaEnc r.2]) (adaNumerical A st vals) := by
    refine implementsF_call_det (by decide) h603 hargs hI hargN (fun bits r h => ?_) hτ
    obtain ⟨hok', hx, -⟩ := hres bits r h
    have := o2m_valSize_adaEnc_le hok'
    rw [bsE_vs_two]
    omega
  /- ### The new state and the response -/
  show ImplementsF orc prog m τ _ bsNumBranch _ ((adaNumerical A st vals).bind _)
  refine implementsF_letE_of hcall (fun r => AdaOK A r.2 ∧ valSize (encNum r.1) ≤ 2 * A.qA + 10 ∧
    valSize (bsResp (Sum.inr r.1)) ≤ o2sRespBound A.qA) hres ?_
  rintro ⟨x, st'⟩ ⟨hok', hx, hr⟩
  dsimp only at hok' hx hr
  unfold o2sRespBound at hr
  apply ImplementsF.of_det
  have hst'B := o2m_valSize_adaEnc_le hok'
  have hrM : valSize (Val.list [encNum x, adaEnc st']) ≤ m := by
    rw [bsE_vs_two]; omega
  show EvalsValF orc prog m τ _ [] _ (Val.list [Val.list [Val.list (blocks.map (encL encN)), adaEnc st'],
    bsResp (Sum.inr x)])
  refine EvalsValF.pair (EvalsValF.pair
      (o2m_atN (o2m_atN (EvalsValF.var rfl) hinp rfl) hstE rfl)
      (o2m_atN (EvalsValF.var rfl) hrM rfl) ?_)
    (o2m_numResp (o2m_atN (EvalsValF.var rfl) hrM rfl) (by omega) (by omega) (by omega)) ?_
  · rw [bsE_vs_two]
    omega
  · rw [bsE_vs_two, bsE_vs_two]
    omega

end F2e2e.BSpace
