import F2e2e.BSpace.O2T.AdaEntryT
import F2e2e.BSpace.AsmTable

/-!
# B_space, route O2b: the `adaInterval` (602) instance on `bsRoundProg` (o2ct)

Owner: C-TREE (51e3826d), for the O2b technical lead 17fc0802 and C-BANK's top frame (P5).

The uniform tight spec of `adaInterval` (W2's `adaInterval_impl_t`, `F2e2e/BSpace/O2T/AdaEntryT.lean`: `TightM`
plus the separate endpoint premise `2^28 · Bq ≤ M`) instantiated on the round program `bsRoundProg`
(`F2e2e/BSpace/AsmTable.lean`): the table facts from `bsLib_round.w4Lib` (`entryTbl`, `prepTbl`, `mus`, `samp`,
`list`) and `NormQSpec` from `bsLib_round.normQ`. This is the premise `hspec` of A-ARCH's `o2m_ivAt_of_lift` /
`o2m_ivAt_wt` (`F2e2e/BSpace/O2GlueMainCallees.lean`) on `bsRoundProg`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- **`adaInterval` (602) on `bsRoundProg`** at any tight frame bound `M` covering the endpoints
(`TightM A M`, `2^28 · Bq ≤ M`). -/
theorem o2ct_iv_impl {M : ℕ} {A : AdaParams} (hbs : A.blockSizes.length = A.p + 1) (hT : A.Tmax.length = A.p)
    (hpos : ∀ j, j ≤ A.p → 0 < A.blockSizes.getD j 0) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ} {Bq : ℕ}
    (hl : bitLen l.num ≤ Bq ∧ bitLen (l.den : ℤ) ≤ Bq) (hu : bitLen u.num ≤ Bq ∧ bitLen (u.den : ℤ) ≤ Bq)
    (hMt : TightM A M) (hMq : 2 ^ 28 * Bq ≤ M) :
    Implements bsRoundProg M [Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]]
      body_adaInterval (fun r => Val.list [encCert r.1, adaEnc r.2]) (adaInterval A st vals l u) :=
  adaInterval_impl_t bsLib_round.w4Lib.entryTbl bsLib_round.w4Lib.prepTbl bsLib_round.w4Lib.mus
    bsLib_round.w4Lib.samp bsLib_round.w4Lib.list (bsLib_round.normQ M) hbs hT hpos hok hv hl hu hMt hMq

end F2e2e.BSpace
