import F2e2e.BSpace.CalcORules
import F2e2e.C.Impl.AdaFrame

/-!
# B_space: the W4 proof frame with the oracle (DSL-CALC, `bsC`)

Oracle versions (`EvalsValO` / `ImplementsO`, `F2e2e/BSpace/MachineEvalsO.lean`) of the generic tools
of `F2e2e/C/Impl/AdaFrame.lean`, for the same DSL code:

* `bsC.loop_iterO`, `bsC.implements_loopO`, `bsC.implements_loopO_bind` : **loops with fresh bits**
  following a reference recursion `R s = (q s).bind (Sum.elim R pure)` (`loopEnc` encoding of one
  iteration: `[1, enc s']` continue, `[0, encOut t]` stop); the iterations may call the oracle;
* `bsC.tlN`, `bsC.atN`, `bsC.atN'` : field access `eTlN` / `eAtN` (the list may be computed with
  fresh bits and oracle calls); `bsC.list` : list building `eList`;
* `bsC.zeOK`, `bsC.ze_spec` : W4's integer expressions `ZE` with leaves evaluated by `EvalsValO`
  (e.g. an oracle call), same crude bound `ZE.mx e + 1 ≤ M`;
* `bsC.get_valO`, `set_valO`, `length_valO`, `replicate_valO`, `reverse_valO`, `take_valO` : the
  library list routines (`ListLib`) on an argument computed by `EvalsValO` (any bits);
* `bsC.call_det`, `bsC.implementsO_call`, `bsC.implementsO_letE_det`, `bsC.implementsO_ite_true`,
  `bsC.implementsO_ite_false` : call / let / conditional rules for `ImplementsO`.

All rules that call a routine take `hO : prog[bsOracleIdx]? = none` (no body at the oracle index).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete
open F2e2e.Cost.AdaDSL (eTl eHd eCall)
open F2e2e.C.Impl (loopEnc eTlN eAtN eList ZE ListLib listSize_drop_le valSize_getElem_lt)

namespace bsC

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}

/-! ### Calls, lets and conditionals -/

/-- The call rule for deterministic code (argument and callee consume no bits). -/
theorem call_det {env : List Val} {i : ℕ} {a body : Expr} {va vb : Val}
    (hO : prog[bsOracleIdx]? = none) (ha : EvalsValO orc prog M env [] (.inl a) va)
    (hbody : prog[i]? = some body) (hb : EvalsValO orc prog M [va] [] (.inl body) vb) :
    EvalsValO orc prog M env [] (.inl (Expr.call i a)) vb :=
  evalsValO_call_det (ne_oracle_of_some hO hbody) hbody ha hb

/-- The `ImplementsO` call rule (randomized argument), taking `hO`. -/
theorem implementsO_call {env : List Val} {α β : Type} {argE : Expr} {encA : α → Val}
    {encB : β → Val} {pA : BitProg α} {f : α → BitProg β} {i : ℕ} {body : Expr}
    (hO : prog[bsOracleIdx]? = none) (hbody : prog[i]? = some body)
    (hA : ImplementsO orc prog M env argE encA pA)
    (hf : ∀ a, ImplementsO orc prog M [encA a] body encB (f a)) :
    ImplementsO orc prog M env (Expr.call i argE) encB (pA.bind f) :=
  F2e2e.BSpace.implementsO_call (ne_oracle_of_some hO hbody) hbody hA hf

/-- A deterministic `let` followed by a randomized body. -/
theorem implementsO_letE_det {env : List Val} {β : Type} {ea eb : Expr} {va : Val}
    {enc : β → Val} {p : BitProg β} (ha : EvalsValO orc prog M env [] (.inl ea) va)
    (hb : ImplementsO orc prog M (va :: env) eb enc p) :
    ImplementsO orc prog M env (Expr.letE ea eb) enc p := by
  intro bits b h
  exact EvalsValO.letE ha (hb bits b h)

/-- A conditional with a deterministic true condition. -/
theorem implementsO_ite_true {env : List Val} {β : Type} {c t f : Expr} {z : ℤ}
    {enc : β → Val} {p : BitProg β} (hc : EvalsValO orc prog M env [] (.inl c) (Val.int z))
    (hz : z ≠ 0) (ht : ImplementsO orc prog M env t enc p) :
    ImplementsO orc prog M env (Expr.ite c t f) enc p := by
  intro bits b h
  exact ite_true hc hz (ht bits b h)

/-- A conditional with a deterministic false condition. -/
theorem implementsO_ite_false {env : List Val} {β : Type} {c t f : Expr} {z : ℤ}
    {enc : β → Val} {p : BitProg β} (hc : EvalsValO orc prog M env [] (.inl c) (Val.int z))
    (hz : z = 0) (hf : ImplementsO orc prog M env f enc p) :
    ImplementsO orc prog M env (Expr.ite c t f) enc p := by
  intro bits b h
  exact ite_false hc hz (hf bits b h)

/-! ### Loops with fresh bits -/

/-- The iterations of `loop i` follow the reference recursion `R` (oracle version of
`C.Impl.loop_iter`). -/
theorem loop_iterO {σ τ : Type} {i : ℕ} {body : Expr} (hbody : prog[i]? = some body)
    (enc : σ → Val) (encOut : τ → Val) (Inv : σ → Prop) (μ : σ → ℕ) (R : σ → BitProg τ)
    (q : σ → BitProg (σ ⊕ τ))
    (hq : ∀ s, Inv s → ImplementsO orc prog M [enc s] body (loopEnc enc encOut) (q s))
    (hR : ∀ s, Inv s → R s = (q s).bind (Sum.elim R BitProg.pure))
    (hinv : ∀ s, Inv s → ∀ bits s', (q s).run bits = some (Sum.inl s', []) →
      Inv s' ∧ μ s' < μ s) :
    ∀ s, Inv s → ∀ bits t, (R s).run bits = some (t, []) →
      EvalsValO orc prog M [] bits (.inr (i, enc s)) (encOut t) := by
  intro s
  induction hμ : μ s using Nat.strong_induction_on generalizing s with
  | _ m ih =>
    intro hs bits t hrun
    rw [hR s hs] at hrun
    obtain ⟨b₁, b₂, r, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp hrun
    have hb := hq s hs b₁ r h1
    cases r with
    | inl s' =>
      obtain ⟨hs', hlt⟩ := hinv s hs b₁ s' h1
      simp only [Sum.elim_inl] at h2
      exact EvalsValO.cont hbody hb one_ne_zero (ih (μ s') (by omega) s' rfl hs' b₂ t h2)
    | inr t' =>
      simp only [Sum.elim_inr] at h2
      obtain ⟨rfl, rfl⟩ := bitProg_run_pure_exact.mp h2
      rw [List.append_nil]
      exact EvalsValO.stop hbody hb

/-- **Loop rule with fresh bits and the oracle** (deterministic initial accumulator). -/
theorem implements_loopO {σ τ : Type} {env : List Val} {i : ℕ} {a body : Expr}
    (hbody : prog[i]? = some body) (enc : σ → Val) (encOut : τ → Val) (Inv : σ → Prop)
    (μ : σ → ℕ) (R : σ → BitProg τ) (q : σ → BitProg (σ ⊕ τ))
    (hq : ∀ s, Inv s → ImplementsO orc prog M [enc s] body (loopEnc enc encOut) (q s))
    (hR : ∀ s, Inv s → R s = (q s).bind (Sum.elim R BitProg.pure))
    (hinv : ∀ s, Inv s → ∀ bits s', (q s).run bits = some (Sum.inl s', []) →
      Inv s' ∧ μ s' < μ s)
    {s₀ : σ} (hs₀ : Inv s₀) (ha : EvalsValO orc prog M env [] (.inl a) (enc s₀)) :
    ImplementsO orc prog M env (Expr.loop i a) encOut (R s₀) := by
  intro bits t hrun
  have := EvalsValO.loop ha (loop_iterO hbody enc encOut Inv μ R q hq hR hinv s₀ hs₀ bits t hrun)
  simpa using this

/-- **Loop rule with fresh bits and the oracle**, the initial accumulator drawn by `p₀`. -/
theorem implements_loopO_bind {σ τ : Type} {env : List Val} {i : ℕ} {a body : Expr}
    (hbody : prog[i]? = some body) (enc : σ → Val) (encOut : τ → Val) (Inv : σ → Prop)
    (μ : σ → ℕ) (R : σ → BitProg τ) (q : σ → BitProg (σ ⊕ τ))
    (hq : ∀ s, Inv s → ImplementsO orc prog M [enc s] body (loopEnc enc encOut) (q s))
    (hR : ∀ s, Inv s → R s = (q s).bind (Sum.elim R BitProg.pure))
    (hinv : ∀ s, Inv s → ∀ bits s', (q s).run bits = some (Sum.inl s', []) →
      Inv s' ∧ μ s' < μ s)
    {p₀ : BitProg σ} (hp₀ : ∀ bits s, p₀.run bits = some (s, []) → Inv s)
    (ha : ImplementsO orc prog M env a enc p₀) :
    ImplementsO orc prog M env (Expr.loop i a) encOut (p₀.bind R) := by
  intro bits t hrun
  obtain ⟨b₁, b₂, s, rfl, h1, h2⟩ := bitProg_run_bind_exact.mp hrun
  exact EvalsValO.loop (ha b₁ s h1)
    (loop_iterO hbody enc encOut Inv μ R q hq hR hinv s (hp₀ b₁ s h1) b₂ t h2)

/-! ### Field access and list building -/

theorem tlN {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsValO orc prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M) :
    ∀ n, n ≤ l.length → EvalsValO orc prog M env bits (.inl (eTlN n e)) (Val.list (l.drop n))
  | 0, _ => by simpa [eTlN] using he
  | n + 1, hn => by
    have ih := tlN he hM n (by omega)
    rw [List.drop_eq_getElem_cons (by omega)] at ih
    show EvalsValO orc prog M env bits (.inl (eTl (eTlN n e))) _
    refine EvalsValO.tail ih (le_trans ?_ hM)
    simp only [valSize_list]
    have := listSize_drop_le l (n + 1)
    omega

/-- **Field access**: element `n` of a list value. -/
theorem atN {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsValO orc prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M)
    {n : ℕ} (hn : n < l.length) : EvalsValO orc prog M env bits (.inl (eAtN n e)) l[n] := by
  have h := tlN he hM n hn.le
  rw [List.drop_eq_getElem_cons hn] at h
  exact EvalsValO.head h (le_trans (valSize_getElem_lt hn).le hM)

/-- **Field access** with the element given by `getElem?`. -/
theorem atN' {env : List Val} {bits : List Bool} {e : Expr} {l : List Val}
    (he : EvalsValO orc prog M env bits (.inl e) (Val.list l)) (hM : valSize (Val.list l) ≤ M)
    {n : ℕ} {v : Val} (hget : l[n]? = some v) : EvalsValO orc prog M env bits (.inl (eAtN n e)) v := by
  obtain ⟨hn, rfl⟩ := List.getElem?_eq_some_iff.mp hget
  exact atN he hM hn

/-- **List building** (deterministic components). -/
theorem list {env : List Val} :
    ∀ {es : List Expr} {vs : List Val},
      List.Forall₂ (fun e v => EvalsValO orc prog M env [] (.inl e) v) es vs →
      valSize (Val.list vs) ≤ M → EvalsValO orc prog M env [] (.inl (eList es)) (Val.list vs)
  | [], [], List.Forall₂.nil, hM => EvalsValO.nil hM
  | _ :: _, _ :: vs, List.Forall₂.cons h hs, hM => by
    have hM' : valSize (Val.list vs) ≤ M := by
      simp only [valSize_list, listSize_cons] at hM ⊢; omega
    have := EvalsValO.cons h (list hs hM') hM
    simpa [eList] using this

/-! ### Integer expressions with oracle leaves -/

/-- Side conditions of `ZE` with the oracle: the leaves evaluate (by `EvalsValO`, no fresh bits) to
their values, the divisors are nonzero. -/
def zeOK (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (M : ℕ) (env : List Val) : ZE → Prop
  | ZE.leaf e z => EvalsValO orc prog M env [] (.inl e) (Val.int z)
  | ZE.lit _ => True
  | ZE.add a b => zeOK orc prog M env a ∧ zeOK orc prog M env b
  | ZE.sub a b => zeOK orc prog M env a ∧ zeOK orc prog M env b
  | ZE.mul a b => zeOK orc prog M env a ∧ zeOK orc prog M env b
  | ZE.div a b => zeOK orc prog M env a ∧ zeOK orc prog M env b ∧ b.val ≠ 0
  | ZE.lt a b => zeOK orc prog M env a ∧ zeOK orc prog M env b
  | ZE.eq a b => zeOK orc prog M env a ∧ zeOK orc prog M env b
  | ZE.cnd c t f => zeOK orc prog M env c ∧ zeOK orc prog M env t ∧ zeOK orc prog M env f

/-- **Compiled integer expressions with oracle leaves are correct.** -/
theorem ze_spec {env : List Val} : ∀ e : ZE, zeOK orc prog M env e → e.mx + 1 ≤ M →
    EvalsValO orc prog M env [] (.inl e.toExpr) (Val.int e.val)
  | ZE.leaf _ _, h, _ => h
  | ZE.lit z, _, hM => EvalsValO.lit (by rw [valSize_int]; simp only [ZE.mx] at hM; omega)
  | ZE.add a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact add (ze_spec a ha hma) (ze_spec b hb hmb) (ZE.valSize_le (e := ZE.add a b) hM)
  | ZE.sub a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact sub (ze_spec a ha hma) (ze_spec b hb hmb) (ZE.valSize_le (e := ZE.sub a b) hM)
  | ZE.mul a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact mul (ze_spec a ha hma) (ze_spec b hb hmb) (ZE.valSize_le (e := ZE.mul a b) hM)
  | ZE.div a b, ⟨ha, hb, hb0⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact div (ze_spec a ha hma) (ze_spec b hb hmb) hb0 (ZE.valSize_le (e := ZE.div a b) hM)
  | ZE.lt a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact lt (ze_spec a ha hma) (ze_spec b hb hmb) (by simp only [ZE.mx] at hM; omega)
  | ZE.eq a b, ⟨ha, hb⟩, hM => by
    have hma : a.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmb : b.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    exact eq (ze_spec a ha hma) (ze_spec b hb hmb) (by simp only [ZE.mx] at hM; omega)
  | ZE.cnd c t f, ⟨hc, ht, hf⟩, hM => by
    have hmc : c.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmt : t.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    have hmf : f.mx + 1 ≤ M := le_trans (by simp only [ZE.mx]; omega) hM
    by_cases hz : c.val ≠ 0
    · have h := ite_true (f := f.toExpr) (ze_spec c hc hmc) hz (ze_spec t ht hmt)
      have hv : (ZE.cnd c t f).val = t.val := if_pos hz
      rw [hv]
      exact h
    · have h := ite_false (t := t.toExpr) (ze_spec c hc hmc) (not_not.mp hz) (ze_spec f hf hmf)
      have hv : (ZE.cnd c t f).val = f.val := if_neg hz
      rw [hv]
      exact h

/-! ### Library list routines -/

theorem get_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val} {a : Expr}
    {ba : List Bool} {l : List Val} {n : ℕ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [Val.list l, Val.int (n : ℤ)]))
    (hM : S_get l n ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.get a)) (l.getD n (Val.int 0)) :=
  (call hO ha hL.get (lift hO ((get_spec hL.getStep l n 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

theorem set_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val} {a : Expr}
    {ba : List Bool} {l : List Val} {n : ℕ} {x : Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [Val.list l, Val.int (n : ℤ), x]))
    (hM : S_set l n x ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.set a)) (Val.list (l.set n x)) :=
  (call hO ha hL.set
    (lift hO ((set_spec hL.setStep hL.revAppendStep l n x 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

theorem length_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val}
    {a : Expr} {ba : List Bool} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list l)) (hM : S_length l ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.length a)) (encN l.length) :=
  (call hO ha hL.length (lift hO ((length_spec hL.lengthStep l 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

theorem replicate_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val}
    {a : Expr} {ba : List Bool} {n : ℕ} {x : Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [Val.int (n : ℤ), x]))
    (hM : S_replicate n x ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.replicate a)) (Val.list (List.replicate n x)) :=
  (call hO ha hL.replicate
    (lift hO ((replicate_spec hL.replicateStep n x 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

theorem reverse_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val}
    {a : Expr} {ba : List Bool} {l : List Val}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list l)) (hM : S_reverse l ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.reverse a)) (Val.list l.reverse) :=
  (call hO ha hL.reverse
    (lift hO ((reverse_spec hL.revAppendStep l 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

theorem take_valO (hO : prog[bsOracleIdx]? = none) (hL : ListLib prog) {env : List Val}
    {a : Expr} {ba : List Bool} {l : List Val} {n : ℕ}
    (ha : EvalsValO orc prog M env ba (.inl a) (Val.list [Val.list l, Val.int (n : ℤ)]))
    (hM : S_take l n ≤ M) :
    EvalsValO orc prog M env ba (.inl (eCall Idx.take a)) (Val.list (l.take n)) :=
  (call hO ha hL.take
    (lift hO ((take_spec hL.setStep hL.revAppendStep l n 0).toVal.mono_M hM))).cast_bits
    (List.append_nil ba)

end bsC

end F2e2e.BSpace
