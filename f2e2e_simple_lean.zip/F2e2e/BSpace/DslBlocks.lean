import F2e2e.B.Mechanism
import F2e2e.C.Impl.AdaFrame
import F2e2e.Spec

/-!
# B_space D1: the records split into blocks (`bsBlocks`, keys 900–902)

Owner: W3 (4a7299ed), for the B_space area lead W4 (cc77ceaa); plan `F2e2e/BSpace/BSPACE_PLAN.md` §D.

`bsBlocks` (key 900): `[encL encN ns, encL encN codes] ↦ Val.list ((splitBlocks ns codes).map (encL encN))`
(B-ARCH's `splitBlocks`, `F2e2e/B/Mechanism.lean`), deterministic, two FLAT loops, tight value bound:

* loop 1 (key 901), accumulator `[nsR, codesR, cur, acc, k]`: moves `k` codes onto the current block
  `cur` (reversed), then pushes `cur` onto `acc` and opens the next block (`k := head nsR`); the result
  is the list of the blocks, each reversed, last block first;
* loop 2 (key 902), accumulator `[rb, cr, co, out]`: reverses back (each block, and the block order).

Every accumulator has size `≤ |ns| + |codes| + 7` (the encoded sizes are invariant along both loops),
so `bsBlocks_eval` needs only `valSize (encL encN ns) + valSize (encL encN codes) + 32 ≤ M`.

Also: `bsB_splitBlocks_length` (the block lengths are `ns` when `ns.sum ≤ codes.length`),
`bsB_valSize_splitBlocks` (`valSize` of the output `≤ valSize (encL encN codes) + 2·|ns| + 1`), and
`bsB_ofFn_encN` (`Val.list (List.ofFn fun ℓ => Val.int (f ℓ)) = encL encN (List.ofFn f)`) and
`bsB_encRecords` (the §7 record encoding: `encRecords code s = encL encN (List.ofFn (code ∘ s))`).
-/

namespace F2e2e.BSpace

open F2e2e F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.C.Impl

namespace Idx

/-- `bsBlocks : [ns, codes] ↦ splitBlocks ns codes` (entry). -/
abbrev bsBlocks : ℕ := 900
/-- Loop 1 of `bsBlocks` (blocks reversed, last first). -/
abbrev bsBlocks1 : ℕ := 901
/-- Loop 2 of `bsBlocks` (reverse back). -/
abbrev bsBlocks2 : ℕ := 902

end Idx

/-! ## The DSL code -/

/-- Loop 1 body; accumulator `[nsR, codesR, cur, acc, k]`. If `k = 0`: push `cur` onto `acc`, then
stop (no sizes left) or open the next block; else move the head of `codesR` onto `cur`. -/
def body_bsBlocks1 : Expr :=
  eIte (eEq (eAtN 4 (eV 0)) (eLit 0))
    (eLet (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))
      (eIte (Expr.un UnOp.isNil (eAtN 0 (eV 1)))
        (ePair (eLit 0) (eV 0))
        (ePair (eLit 1) (eList [eTl (eAtN 0 (eV 1)), eAtN 1 (eV 1), Expr.nil, eV 0,
          eHd (eAtN 0 (eV 1))]))))
    (ePair (eLit 1) (eList [eAtN 0 (eV 0), eTl (eAtN 1 (eV 0)),
      eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)), eAtN 3 (eV 0), eSub (eAtN 4 (eV 0)) (eLit 1)]))

/-- Loop 2 body; accumulator `[rb, cr, co, out]`. If `cr = []`: push `co` onto `out`, then stop (no
blocks left) or take the next reversed block; else move the head of `cr` onto `co`. -/
def body_bsBlocks2 : Expr :=
  eIte (Expr.un UnOp.isNil (eAtN 1 (eV 0)))
    (eLet (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))
      (eIte (Expr.un UnOp.isNil (eAtN 0 (eV 1)))
        (ePair (eLit 0) (eV 0))
        (ePair (eLit 1) (eList [eTl (eAtN 0 (eV 1)), eHd (eAtN 0 (eV 1)), Expr.nil, eV 0]))))
    (ePair (eLit 1) (eList [eAtN 0 (eV 0), eTl (eAtN 1 (eV 0)),
      eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)), eAtN 3 (eV 0)]))

/-- **`bsBlocks`** (key 900): `[ns, codes] ↦ splitBlocks ns codes` (`[]` if `ns = []`). -/
def body_bsBlocks : Expr :=
  eIte (Expr.un UnOp.isNil (eAtN 0 (eV 0)))
    Expr.nil
    (eLet (eLoop Idx.bsBlocks1 (eList [eTl (eAtN 0 (eV 0)), eAtN 1 (eV 0), Expr.nil, Expr.nil,
        eHd (eAtN 0 (eV 0))]))
      (eLoop Idx.bsBlocks2 (eList [eTl (eV 0), eHd (eV 0), Expr.nil, Expr.nil])))

/-- The routines of `bsBlocks` (`(key, body)`). -/
def bsBlocksTable : List (ℕ × Expr) :=
  [(Idx.bsBlocks, body_bsBlocks), (Idx.bsBlocks1, body_bsBlocks1), (Idx.bsBlocks2, body_bsBlocks2)]

/-! ## Mathematical facts -/

/-- The §7 record encoding is `encL encN` of the codes (`encRecords code s = Val.list (List.ofFn fun
ℓ => Val.int (code (s ℓ)))` is this with `f = code ∘ s`). -/
theorem bsB_ofFn_encN {N : ℕ} (f : Fin N → ℕ) :
    Val.list (List.ofFn fun ℓ => Val.int (f ℓ : ℤ)) = encL encN (List.ofFn f) := by
  simp only [encL, List.map_ofFn]
  rfl

/-- **The records** (§7's `encRecords`) are `encL encN` of the codes. -/
theorem bsB_encRecords {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) :
    encRecords code s = encL encN (List.ofFn (code ∘ s)) :=
  bsB_ofFn_encN (code ∘ s)

/-- **The block lengths** are `ns` (when the codes suffice). -/
theorem bsB_splitBlocks_length :
    ∀ (ns codes : List ℕ), ns.sum ≤ codes.length → (splitBlocks ns codes).map List.length = ns
  | [], _, _ => rfl
  | n :: ns, codes, h => by
    simp only [List.sum_cons] at h
    simp only [splitBlocks, List.map_cons, List.length_take]
    rw [bsB_splitBlocks_length ns (codes.drop n) (by rw [List.length_drop]; omega)]
    congr 1
    omega

theorem bsB_encL_cons (z : ℕ) (l : List ℕ) :
    valSize (encL encN (z :: l)) = valSize (encN z) + valSize (encL encN l) + 1 := by
  simp only [encL, List.map_cons, valSize_list, listSize_cons]
  omega

theorem bsB_encL_nil : valSize (encL encN ([] : List ℕ)) = 1 := by
  simp [encL]

theorem bsB_encL_append (a b : List ℕ) :
    valSize (encL encN (a ++ b)) + 1 = valSize (encL encN a) + valSize (encL encN b) := by
  simp only [encL, List.map_append, valSize_list, listSize_append]
  omega

theorem bsB_vlist_cons (x : Val) (l : List Val) :
    valSize (Val.list (x :: l)) = valSize x + valSize (Val.list l) + 1 := by
  simp only [valSize_list, listSize_cons]
  omega

theorem bsB_vs_pair (a b : Val) : valSize (Val.list [a, b]) = valSize a + valSize b + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]
  omega

theorem bsB_listSize_reverse (l : List Val) : listSize l.reverse = listSize l := by
  induction l with
  | nil => rfl
  | cons x l ih =>
    rw [List.reverse_cons, listSize_append, ih]
    simp only [listSize_cons, listSize_nil]
    omega

theorem bsB_encL_reverse (b : List ℕ) : valSize (encL encN b.reverse) = valSize (encL encN b) := by
  simp only [encL, List.map_reverse, valSize_list, bsB_listSize_reverse]

theorem bsB_listSize_map_congr {α : Type} (f g : α → Val) (hfg : ∀ a, valSize (f a) = valSize (g a)) :
    ∀ l : List α, listSize (l.map f) = listSize (l.map g)
  | [] => rfl
  | a :: l => by
    simp only [List.map_cons, listSize_cons, hfg a, bsB_listSize_map_congr f g hfg l]

/-- The sizes do not change when the blocks are reversed and listed backwards. -/
theorem bsB_size_rev (L : List (List ℕ)) :
    valSize (Val.list (((L.map List.reverse).reverse).map (encL encN))) =
      valSize (Val.list (L.map (encL encN))) := by
  rw [valSize_list, valSize_list, List.map_reverse, bsB_listSize_reverse, List.map_map]
  congr 1
  exact bsB_listSize_map_congr _ _ (fun b => bsB_encL_reverse b) L

theorem bsB_listSize_splitBlocks :
    ∀ (ns l : List ℕ), listSize ((splitBlocks ns l).map (encL encN)) + 1 ≤
      valSize (encL encN l) + 2 * ns.length
  | [], l => by
    have := valSize_pos (encL encN l)
    simp only [splitBlocks, List.map_nil, listSize_nil, List.length_nil]
    omega
  | n :: ns, l => by
    have ih := bsB_listSize_splitBlocks ns (l.drop n)
    have happ := bsB_encL_append (l.take n) (l.drop n)
    rw [List.take_append_drop] at happ
    simp only [splitBlocks, List.map_cons, listSize_cons, List.length_cons]
    omega

/-- **The size of the blocks**: `≤ valSize (encL encN codes) + 2·|ns| + 1`. -/
theorem bsB_valSize_splitBlocks (ns codes : List ℕ) :
    valSize (Val.list ((splitBlocks ns codes).map (encL encN))) ≤
      valSize (encL encN codes) + 2 * ns.length + 1 := by
  have := bsB_listSize_splitBlocks ns codes
  rw [valSize_list]
  omega

/-! ## Loop states -/

/-- Loop 1 accumulator: remaining sizes, remaining codes, the current block reversed, the finished
blocks (each reversed, last first), the number of codes left in the current block. -/
def bsB1Enc (nsR codesR cur : List ℕ) (DR : List (List ℕ)) (k : ℕ) : Val :=
  Val.list [encL encN nsR, encL encN codesR, encL encN cur, Val.list (DR.map (encL encN)), encN k]

/-- The result of loop 1 from a state: all blocks, each reversed, last first. -/
def bsB1Fin (nsR codesR cur : List ℕ) (DR : List (List ℕ)) (k : ℕ) : List (List ℕ) :=
  ((splitBlocks nsR (codesR.drop k)).map List.reverse).reverse ++
    ((codesR.take k).reverse ++ cur) :: DR

theorem bsB1Enc_size (nsR codesR cur : List ℕ) (DR : List (List ℕ)) (k : ℕ) :
    valSize (bsB1Enc nsR codesR cur DR k) = valSize (encL encN nsR) + valSize (encL encN codesR) +
      valSize (encL encN cur) + valSize (Val.list (DR.map (encL encN))) + valSize (encN k) + 6 := by
  simp only [bsB1Enc, valSize_list, listSize_cons, listSize_nil]
  omega

/-- Loop 2 accumulator: the remaining reversed blocks (last first), the rest of the current reversed
block, the current block built so far, the finished blocks (in order). -/
def bsB2Enc (RR : List (List ℕ)) (cr co : List ℕ) (out : List (List ℕ)) : Val :=
  Val.list [Val.list (RR.map (encL encN)), encL encN cr, encL encN co, Val.list (out.map (encL encN))]

/-- The result of loop 2 from a state. -/
def bsB2Fin (RR : List (List ℕ)) (cr co : List ℕ) (out : List (List ℕ)) : List (List ℕ) :=
  (RR.map List.reverse).reverse ++ (cr.reverse ++ co) :: out

theorem bsB2Enc_size (RR : List (List ℕ)) (cr co : List ℕ) (out : List (List ℕ)) :
    valSize (bsB2Enc RR cr co out) = valSize (Val.list (RR.map (encL encN))) +
      valSize (encL encN cr) + valSize (encL encN co) + valSize (Val.list (out.map (encL encN))) + 5 := by
  simp only [bsB2Enc, valSize_list, listSize_cons, listSize_nil]
  omega

/-! ## Evaluation helpers -/

section Helpers

variable {prog : List Expr} {M : ℕ} {env : List Val}

theorem bsB_at {j n : ℕ} {l : List Val} {v : Val} (hj : env[j]? = some (Val.list l))
    (hM : valSize (Val.list l) ≤ M) (hget : l[n]? = some v) :
    EvalsVal prog M env [] (.inl (eAtN n (eV j))) v :=
  evalsVal_atN' (EvalsVal.var hj) hM hget

theorem bsB_iteT {c t f : Expr} {z : ℤ} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hz : z ≠ 0) (ht : EvalsVal prog M env [] (.inl t) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_true hc hz ht

theorem bsB_iteF {c t f : Expr} {z : ℤ} {v : Val} (hc : EvalsVal prog M env [] (.inl c) (Val.int z))
    (hz : z = 0) (hf : EvalsVal prog M env [] (.inl f) v) :
    EvalsVal prog M env [] (.inl (Expr.ite c t f)) v :=
  EvalsVal.ite_false hc hz hf

theorem bsB_letE {a b : Expr} {va vb : Val} (ha : EvalsVal prog M env [] (.inl a) va)
    (hb : EvalsVal prog M (va :: env) [] (.inl b) vb) :
    EvalsVal prog M env [] (.inl (Expr.letE a b)) vb :=
  EvalsVal.letE ha hb

theorem bsB_ite_eq {p : Prop} [Decidable p] (h : ¬ p) : (if p then (1 : ℤ) else 0) = 0 := by
  rw [if_neg h]

theorem bsB_ite_ne {p : Prop} [Decidable p] (h : p) : (if p then (1 : ℤ) else 0) ≠ 0 := by
  rw [if_pos h]; exact one_ne_zero

theorem bsB_nil (hM : 2 ≤ M) : EvalsVal prog M env [] (.inl Expr.nil) (Val.list []) :=
  EvalsVal.nil (by rw [valSize_list, listSize_nil]; omega)

theorem bsB_lit {z : ℤ} (hz : bitLen z ≤ 1) (hM : 2 ≤ M) :
    EvalsVal prog M env [] (.inl (eLit z)) (Val.int z) :=
  EvalsVal.lit (by rw [valSize_int]; omega)

end Helpers

/-! ## Loop 1: one iteration -/

section Loop1

variable {prog : List Expr} {M : ℕ}

theorem bsB1_move {nsR cs cur : List ℕ} {DR : List (List ℕ)} {z k : ℕ}
    (hsz : valSize (bsB1Enc nsR (z :: cs) cur DR (k + 1)) + 8 ≤ M) :
    EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl body_bsBlocks1)
      (Val.list [Val.int 1, bsB1Enc nsR cs (z :: cur) DR k]) := by
  have e := bsB1Enc_size nsR (z :: cs) cur DR (k + 1)
  have e' := bsB1Enc_size nsR cs (z :: cur) DR k
  have hc1 := bsB_encL_cons z cs
  have hc2 := bsB_encL_cons z cur
  have hk : valSize (encN k) ≤ valSize (encN (k + 1)) := by
    simp only [valSize_encN]; exact Nat.add_le_add_right (Nat.size_le_size (Nat.le_succ k)) 1
  have hsM : valSize (bsB1Enc nsR (z :: cs) cur DR (k + 1)) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f0 : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl (eAtN 0 (eV 0)))
      (encL encN nsR) := bsB_at rfl hsM rfl
  have f1 : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl (eAtN 1 (eV 0)))
      (encL encN (z :: cs)) := bsB_at rfl hsM rfl
  have f2 : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl (eAtN 2 (eV 0)))
      (encL encN cur) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (DR.map (encL encN))) := bsB_at rfl hsM rfl
  have f4 : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] [] (.inl (eAtN 4 (eV 0)))
      (encN (k + 1)) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.eq f4 (bsB_lit (z := 0) (by decide) h2M) h2M
  have hz : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] []
      (.inl (eHd (eAtN 1 (eV 0)))) (encN z) := EvalsVal.head f1 (by omega)
  have htl : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] []
      (.inl (eTl (eAtN 1 (eV 0)))) (encL encN cs) :=
    EvalsVal.tail f1 (show valSize (encL encN cs) ≤ M by omega)
  have hcons : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] []
      (.inl (eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)))) (encL encN (z :: cur)) :=
    EvalsVal.cons hz f2 (show valSize (encL encN (z :: cur)) ≤ M by omega)
  have ek : ((k + 1 : ℕ) : ℤ) - 1 = ((k : ℕ) : ℤ) := by push_cast; ring
  have hsub : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] []
      (.inl (eSub (eAtN 4 (eV 0)) (eLit 1))) (encN k) := by
    have h := EvalsVal.sub f4 (bsB_lit (z := 1) (by decide) h2M)
      (show valSize (Val.int (((k + 1 : ℕ) : ℤ) - 1)) ≤ M by
        rw [ek]; show valSize (encN k) ≤ M; omega)
    rw [ek] at h
    exact h
  have hstate : EvalsVal prog M [bsB1Enc nsR (z :: cs) cur DR (k + 1)] []
      (.inl (eList [eAtN 0 (eV 0), eTl (eAtN 1 (eV 0)), eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)),
        eAtN 3 (eV 0), eSub (eAtN 4 (eV 0)) (eLit 1)])) (bsB1Enc nsR cs (z :: cur) DR k) :=
    evalsVal_list (.cons f0 (.cons htl (.cons hcons (.cons f3 (.cons hsub .nil)))))
      (show valSize (bsB1Enc nsR cs (z :: cur) DR k) ≤ M by omega)
  have hpair := EvalsVal.pair (bsB_lit (z := 1) (by decide) h2M) hstate
    (by rw [bsB_vs_pair, valSize_int, bitLen_one]; omega)
  unfold body_bsBlocks1
  exact bsB_iteF hcond (bsB_ite_eq (by omega)) hpair

theorem bsB1_close_stop {codesR cur : List ℕ} {DR : List (List ℕ)}
    (hsz : valSize (bsB1Enc [] codesR cur DR 0) + 8 ≤ M) :
    EvalsVal prog M [bsB1Enc [] codesR cur DR 0] [] (.inl body_bsBlocks1)
      (Val.list [Val.int 0, Val.list ((cur :: DR).map (encL encN))]) := by
  have e := bsB1Enc_size [] codesR cur DR 0
  have hacc := bsB_vlist_cons (encL encN cur) (DR.map (encL encN))
  have hsM : valSize (bsB1Enc [] codesR cur DR 0) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f2 : EvalsVal prog M [bsB1Enc [] codesR cur DR 0] [] (.inl (eAtN 2 (eV 0)))
      (encL encN cur) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB1Enc [] codesR cur DR 0] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (DR.map (encL encN))) := bsB_at rfl hsM rfl
  have f4 : EvalsVal prog M [bsB1Enc [] codesR cur DR 0] [] (.inl (eAtN 4 (eV 0)))
      (encN 0) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.eq f4 (bsB_lit (z := 0) (by decide) h2M) h2M
  have hcons : EvalsVal prog M [bsB1Enc [] codesR cur DR 0] []
      (.inl (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))) (Val.list ((cur :: DR).map (encL encN))) :=
    EvalsVal.cons f2 f3 (show valSize (Val.list ((cur :: DR).map (encL encN))) ≤ M by
      rw [List.map_cons]; omega)
  have g0 : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)), bsB1Enc [] codesR cur DR 0] []
      (.inl (eAtN 0 (eV 1))) (encL encN []) := bsB_at rfl hsM rfl
  have hnil := EvalsVal.isNil_nil g0 h2M
  have hpair : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)), bsB1Enc [] codesR cur DR 0] []
      (.inl (ePair (eLit 0) (eV 0))) (Val.list [Val.int 0, Val.list ((cur :: DR).map (encL encN))]) :=
    EvalsVal.pair (bsB_lit (z := 0) (by decide) h2M) (EvalsVal.var rfl)
      (by rw [bsB_vs_pair, valSize_int, bitLen_zero, List.map_cons]; omega)
  unfold body_bsBlocks1
  exact bsB_iteT hcond (bsB_ite_ne (by norm_num)) (bsB_letE hcons (bsB_iteT hnil one_ne_zero hpair))

theorem bsB1_close_next {n : ℕ} {ns' codesR cur : List ℕ} {DR : List (List ℕ)}
    (hsz : valSize (bsB1Enc (n :: ns') codesR cur DR 0) + 8 ≤ M) :
    EvalsVal prog M [bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl body_bsBlocks1)
      (Val.list [Val.int 1, bsB1Enc ns' codesR [] (cur :: DR) n]) := by
  have e := bsB1Enc_size (n :: ns') codesR cur DR 0
  have e' := bsB1Enc_size ns' codesR [] (cur :: DR) n
  have hn := bsB_encL_cons n ns'
  have hnil0 := bsB_encL_nil
  have hacc := bsB_vlist_cons (encL encN cur) (DR.map (encL encN))
  have h0 : valSize (encN 0) = 1 := by simp [encN]
  have hsM : valSize (bsB1Enc (n :: ns') codesR cur DR 0) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f2 : EvalsVal prog M [bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eAtN 2 (eV 0)))
      (encL encN cur) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (DR.map (encL encN))) := bsB_at rfl hsM rfl
  have f4 : EvalsVal prog M [bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eAtN 4 (eV 0)))
      (encN 0) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.eq f4 (bsB_lit (z := 0) (by decide) h2M) h2M
  have hcons : EvalsVal prog M [bsB1Enc (n :: ns') codesR cur DR 0] []
      (.inl (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))) (Val.list ((cur :: DR).map (encL encN))) :=
    EvalsVal.cons f2 f3 (show valSize (Val.list ((cur :: DR).map (encL encN))) ≤ M by
      rw [List.map_cons]; omega)
  have g0 : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)),
      bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eAtN 0 (eV 1))) (encL encN (n :: ns')) :=
    bsB_at rfl hsM rfl
  have g1 : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)),
      bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eAtN 1 (eV 1))) (encL encN codesR) :=
    bsB_at rfl hsM rfl
  have hnil := EvalsVal.isNil_cons g0 (by omega)
  have htl : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)),
      bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eTl (eAtN 0 (eV 1)))) (encL encN ns') :=
    EvalsVal.tail g0 (show valSize (encL encN ns') ≤ M by omega)
  have hhd : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)),
      bsB1Enc (n :: ns') codesR cur DR 0] [] (.inl (eHd (eAtN 0 (eV 1)))) (encN n) :=
    EvalsVal.head g0 (by omega)
  have hst : EvalsVal prog M [Val.list ((cur :: DR).map (encL encN)),
      bsB1Enc (n :: ns') codesR cur DR 0] []
      (.inl (eList [eTl (eAtN 0 (eV 1)), eAtN 1 (eV 1), Expr.nil, eV 0, eHd (eAtN 0 (eV 1))]))
      (bsB1Enc ns' codesR [] (cur :: DR) n) :=
    evalsVal_list (.cons htl (.cons g1 (.cons (bsB_nil h2M) (.cons (EvalsVal.var rfl) (.cons hhd .nil)))))
      (show valSize (bsB1Enc ns' codesR [] (cur :: DR) n) ≤ M by rw [List.map_cons] at e'; omega)
  have hpair := EvalsVal.pair (bsB_lit (z := 1) (by decide) h2M) hst
    (by rw [bsB_vs_pair, valSize_int, bitLen_one]; rw [List.map_cons] at e'; omega)
  unfold body_bsBlocks1
  exact bsB_iteT hcond (bsB_ite_ne (by norm_num)) (bsB_letE hcons (bsB_iteF hnil rfl hpair))

end Loop1

/-! ## Loop 1: the whole loop -/

section Run1

variable {prog : List Expr} {M : ℕ}

theorem bsB1_run (h1 : prog[Idx.bsBlocks1]? = some body_bsBlocks1) {B : ℕ} (hB : B + 8 ≤ M) :
    ∀ (m : ℕ) (nsR codesR cur : List ℕ) (DR : List (List ℕ)) (k : ℕ),
      codesR.length + nsR.length = m → k + nsR.sum ≤ codesR.length →
      valSize (bsB1Enc nsR codesR cur DR k) ≤ B →
      EvalsVal prog M [] [] (.inr (Idx.bsBlocks1, bsB1Enc nsR codesR cur DR k))
        (Val.list ((bsB1Fin nsR codesR cur DR k).map (encL encN))) := by
  intro m
  induction m with
  | zero =>
    intro nsR codesR cur DR k hm hk hs
    have hc : codesR = [] := List.eq_nil_of_length_eq_zero (by omega)
    have hn : nsR = [] := List.eq_nil_of_length_eq_zero (by omega)
    subst hc hn
    have hk0 : k = 0 := by simp only [List.sum_nil, List.length_nil] at hk; omega
    subst hk0
    have e : bsB1Fin [] [] cur DR 0 = cur :: DR := by simp [bsB1Fin, splitBlocks]
    rw [e]
    exact EvalsVal.stop h1 (bsB1_close_stop (by omega))
  | succ m ih =>
    intro nsR codesR cur DR k hm hk hs
    cases k with
    | zero =>
      cases nsR with
      | nil =>
        have e : bsB1Fin [] codesR cur DR 0 = cur :: DR := by simp [bsB1Fin, splitBlocks]
        rw [e]
        exact EvalsVal.stop h1 (bsB1_close_stop (by omega))
      | cons n ns' =>
        have hstep := bsB1_close_next (prog := prog) (M := M) (n := n) (ns' := ns') (codesR := codesR)
          (cur := cur) (DR := DR) (by omega)
        have hle : valSize (bsB1Enc ns' codesR [] (cur :: DR) n) ≤
            valSize (bsB1Enc (n :: ns') codesR cur DR 0) := by
          have e := bsB1Enc_size (n :: ns') codesR cur DR 0
          have e' := bsB1Enc_size ns' codesR [] (cur :: DR) n
          have hn := bsB_encL_cons n ns'
          have hacc := bsB_vlist_cons (encL encN cur) (DR.map (encL encN))
          have h0 : valSize (encN 0) = 1 := by simp [encN]
          rw [List.map_cons] at e'
          rw [bsB_encL_nil] at e'
          omega
        have hrest := ih ns' codesR [] (cur :: DR) n
          (by simp only [List.length_cons] at hm; omega)
          (by simp only [List.sum_cons] at hk; omega) (le_trans hle hs)
        have e : bsB1Fin ns' codesR [] (cur :: DR) n = bsB1Fin (n :: ns') codesR cur DR 0 := by
          simp [bsB1Fin, splitBlocks]
        rw [e] at hrest
        exact EvalsVal.cont h1 hstep one_ne_zero hrest
    | succ k' =>
      cases codesR with
      | nil => simp only [List.length_nil] at hk; omega
      | cons z cs =>
        have hstep := bsB1_move (prog := prog) (M := M) (nsR := nsR) (cs := cs) (cur := cur) (DR := DR)
          (z := z) (k := k') (by omega)
        have hle : valSize (bsB1Enc nsR cs (z :: cur) DR k') ≤
            valSize (bsB1Enc nsR (z :: cs) cur DR (k' + 1)) := by
          have e := bsB1Enc_size nsR (z :: cs) cur DR (k' + 1)
          have e' := bsB1Enc_size nsR cs (z :: cur) DR k'
          have hc1 := bsB_encL_cons z cs
          have hc2 := bsB_encL_cons z cur
          have hk : valSize (encN k') ≤ valSize (encN (k' + 1)) := by
            simp only [valSize_encN]
            exact Nat.add_le_add_right (Nat.size_le_size (Nat.le_succ k')) 1
          omega
        have hrest := ih nsR cs (z :: cur) DR k'
          (by simp only [List.length_cons] at hm; omega)
          (by simp only [List.length_cons] at hk; omega) (le_trans hle hs)
        have e : bsB1Fin nsR cs (z :: cur) DR k' = bsB1Fin nsR (z :: cs) cur DR (k' + 1) := by
          simp [bsB1Fin, List.reverse_cons, List.append_assoc]
        rw [e] at hrest
        exact EvalsVal.cont h1 hstep one_ne_zero hrest

end Run1

/-! ## Loop 2: one iteration -/

section Loop2

variable {prog : List Expr} {M : ℕ}

theorem bsB2_move {RR : List (List ℕ)} {x : ℕ} {cr co : List ℕ} {out : List (List ℕ)}
    (hsz : valSize (bsB2Enc RR (x :: cr) co out) + 8 ≤ M) :
    EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl body_bsBlocks2)
      (Val.list [Val.int 1, bsB2Enc RR cr (x :: co) out]) := by
  have e := bsB2Enc_size RR (x :: cr) co out
  have e' := bsB2Enc_size RR cr (x :: co) out
  have hc1 := bsB_encL_cons x cr
  have hc2 := bsB_encL_cons x co
  have hsM : valSize (bsB2Enc RR (x :: cr) co out) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f0 : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eAtN 0 (eV 0)))
      (Val.list (RR.map (encL encN))) := bsB_at rfl hsM rfl
  have f1 : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eAtN 1 (eV 0)))
      (encL encN (x :: cr)) := bsB_at rfl hsM rfl
  have f2 : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eAtN 2 (eV 0)))
      (encL encN co) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (out.map (encL encN))) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.isNil_cons f1 (by omega)
  have hx : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eHd (eAtN 1 (eV 0))))
      (encN x) := EvalsVal.head f1 (by omega)
  have htl : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] [] (.inl (eTl (eAtN 1 (eV 0))))
      (encL encN cr) := EvalsVal.tail f1 (show valSize (encL encN cr) ≤ M by omega)
  have hcons : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] []
      (.inl (eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)))) (encL encN (x :: co)) :=
    EvalsVal.cons hx f2 (show valSize (encL encN (x :: co)) ≤ M by omega)
  have hstate : EvalsVal prog M [bsB2Enc RR (x :: cr) co out] []
      (.inl (eList [eAtN 0 (eV 0), eTl (eAtN 1 (eV 0)), eCons (eHd (eAtN 1 (eV 0))) (eAtN 2 (eV 0)),
        eAtN 3 (eV 0)])) (bsB2Enc RR cr (x :: co) out) :=
    evalsVal_list (.cons f0 (.cons htl (.cons hcons (.cons f3 .nil))))
      (show valSize (bsB2Enc RR cr (x :: co) out) ≤ M by omega)
  have hpair := EvalsVal.pair (bsB_lit (z := 1) (by decide) h2M) hstate
    (by rw [bsB_vs_pair, valSize_int, bitLen_one]; omega)
  unfold body_bsBlocks2
  exact bsB_iteF hcond rfl hpair

theorem bsB2_close_stop {co : List ℕ} {out : List (List ℕ)}
    (hsz : valSize (bsB2Enc [] [] co out) + 8 ≤ M) :
    EvalsVal prog M [bsB2Enc [] [] co out] [] (.inl body_bsBlocks2)
      (Val.list [Val.int 0, Val.list ((co :: out).map (encL encN))]) := by
  have e := bsB2Enc_size [] [] co out
  have hout := bsB_vlist_cons (encL encN co) (out.map (encL encN))
  have hsM : valSize (bsB2Enc [] [] co out) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f1 : EvalsVal prog M [bsB2Enc [] [] co out] [] (.inl (eAtN 1 (eV 0)))
      (encL encN []) := bsB_at rfl hsM rfl
  have f2 : EvalsVal prog M [bsB2Enc [] [] co out] [] (.inl (eAtN 2 (eV 0)))
      (encL encN co) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB2Enc [] [] co out] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (out.map (encL encN))) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.isNil_nil f1 h2M
  have hcons : EvalsVal prog M [bsB2Enc [] [] co out] []
      (.inl (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))) (Val.list ((co :: out).map (encL encN))) :=
    EvalsVal.cons f2 f3 (show valSize (Val.list ((co :: out).map (encL encN))) ≤ M by
      rw [List.map_cons]; omega)
  have g0 : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc [] [] co out] []
      (.inl (eAtN 0 (eV 1))) (Val.list (([] : List (List ℕ)).map (encL encN))) :=
    bsB_at rfl hsM rfl
  have hnil := EvalsVal.isNil_nil g0 h2M
  have hpair : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc [] [] co out] []
      (.inl (ePair (eLit 0) (eV 0))) (Val.list [Val.int 0, Val.list ((co :: out).map (encL encN))]) :=
    EvalsVal.pair (bsB_lit (z := 0) (by decide) h2M) (EvalsVal.var rfl)
      (by rw [bsB_vs_pair, valSize_int, bitLen_zero, List.map_cons]; omega)
  unfold body_bsBlocks2
  exact bsB_iteT hcond one_ne_zero (bsB_letE hcons (bsB_iteT hnil one_ne_zero hpair))

theorem bsB2_close_next {b : List ℕ} {RR : List (List ℕ)} {co : List ℕ} {out : List (List ℕ)}
    (hsz : valSize (bsB2Enc (b :: RR) [] co out) + 8 ≤ M) :
    EvalsVal prog M [bsB2Enc (b :: RR) [] co out] [] (.inl body_bsBlocks2)
      (Val.list [Val.int 1, bsB2Enc RR b [] (co :: out)]) := by
  have e := bsB2Enc_size (b :: RR) [] co out
  have e' := bsB2Enc_size RR b [] (co :: out)
  rw [List.map_cons] at e e'
  have hRR := bsB_vlist_cons (encL encN b) (RR.map (encL encN))
  have hout := bsB_vlist_cons (encL encN co) (out.map (encL encN))
  have hnil0 := bsB_encL_nil
  have hsM : valSize (bsB2Enc (b :: RR) [] co out) ≤ M := by omega
  have h2M : 2 ≤ M := by omega
  have f1 : EvalsVal prog M [bsB2Enc (b :: RR) [] co out] [] (.inl (eAtN 1 (eV 0)))
      (encL encN []) := bsB_at rfl hsM rfl
  have f2 : EvalsVal prog M [bsB2Enc (b :: RR) [] co out] [] (.inl (eAtN 2 (eV 0)))
      (encL encN co) := bsB_at rfl hsM rfl
  have f3 : EvalsVal prog M [bsB2Enc (b :: RR) [] co out] [] (.inl (eAtN 3 (eV 0)))
      (Val.list (out.map (encL encN))) := bsB_at rfl hsM rfl
  have hcond := EvalsVal.isNil_nil f1 h2M
  have hcons : EvalsVal prog M [bsB2Enc (b :: RR) [] co out] []
      (.inl (eCons (eAtN 2 (eV 0)) (eAtN 3 (eV 0)))) (Val.list ((co :: out).map (encL encN))) :=
    EvalsVal.cons f2 f3 (show valSize (Val.list ((co :: out).map (encL encN))) ≤ M by
      rw [List.map_cons]; omega)
  have g0 : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc (b :: RR) [] co out] []
      (.inl (eAtN 0 (eV 1))) (Val.list ((b :: RR).map (encL encN))) := bsB_at rfl hsM rfl
  have hnil := EvalsVal.isNil_cons g0 (by omega)
  have htl : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc (b :: RR) [] co out] []
      (.inl (eTl (eAtN 0 (eV 1)))) (Val.list (RR.map (encL encN))) :=
    EvalsVal.tail g0 (by omega)
  have hhd : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc (b :: RR) [] co out] []
      (.inl (eHd (eAtN 0 (eV 1)))) (encL encN b) :=
    EvalsVal.head g0 (by omega)
  have hst : EvalsVal prog M [Val.list ((co :: out).map (encL encN)), bsB2Enc (b :: RR) [] co out] []
      (.inl (eList [eTl (eAtN 0 (eV 1)), eHd (eAtN 0 (eV 1)), Expr.nil, eV 0]))
      (bsB2Enc RR b [] (co :: out)) :=
    evalsVal_list (.cons htl (.cons hhd (.cons (bsB_nil h2M) (.cons (EvalsVal.var rfl) .nil))))
      (show valSize (bsB2Enc RR b [] (co :: out)) ≤ M by omega)
  have hpair := EvalsVal.pair (bsB_lit (z := 1) (by decide) h2M) hst
    (by rw [bsB_vs_pair, valSize_int, bitLen_one]; omega)
  unfold body_bsBlocks2
  exact bsB_iteT hcond one_ne_zero (bsB_letE hcons (bsB_iteF hnil rfl hpair))

end Loop2

/-! ## Loop 2: the whole loop -/

section Run2

variable {prog : List Expr} {M : ℕ}

theorem bsB2_run (h2 : prog[Idx.bsBlocks2]? = some body_bsBlocks2) {B : ℕ} (hB : B + 8 ≤ M) :
    ∀ (m : ℕ) (RR : List (List ℕ)) (cr co : List ℕ) (out : List (List ℕ)),
      RR.length + (RR.map List.length).sum + cr.length = m →
      valSize (bsB2Enc RR cr co out) ≤ B →
      EvalsVal prog M [] [] (.inr (Idx.bsBlocks2, bsB2Enc RR cr co out))
        (Val.list ((bsB2Fin RR cr co out).map (encL encN))) := by
  intro m
  induction m with
  | zero =>
    intro RR cr co out hm hs
    have hR : RR = [] := List.eq_nil_of_length_eq_zero (by omega)
    have hc : cr = [] := List.eq_nil_of_length_eq_zero (by omega)
    subst hR hc
    have e : bsB2Fin [] [] co out = co :: out := by simp [bsB2Fin]
    rw [e]
    exact EvalsVal.stop h2 (bsB2_close_stop (by omega))
  | succ m ih =>
    intro RR cr co out hm hs
    cases cr with
    | cons x cr' =>
      have hstep := bsB2_move (prog := prog) (M := M) (RR := RR) (x := x) (cr := cr') (co := co)
        (out := out)
        (by omega)
      have hle : valSize (bsB2Enc RR cr' (x :: co) out) ≤ valSize (bsB2Enc RR (x :: cr') co out) := by
        have e := bsB2Enc_size RR (x :: cr') co out
        have e' := bsB2Enc_size RR cr' (x :: co) out
        have hc1 := bsB_encL_cons x cr'
        have hc2 := bsB_encL_cons x co
        omega
      have hrest := ih RR cr' (x :: co) out (by simp only [List.length_cons] at hm; omega)
        (le_trans hle hs)
      have e : bsB2Fin RR cr' (x :: co) out = bsB2Fin RR (x :: cr') co out := by
        simp [bsB2Fin, List.reverse_cons, List.append_assoc]
      rw [e] at hrest
      exact EvalsVal.cont h2 hstep one_ne_zero hrest
    | nil =>
      cases RR with
      | nil =>
        have e : bsB2Fin [] [] co out = co :: out := by simp [bsB2Fin]
        rw [e]
        exact EvalsVal.stop h2 (bsB2_close_stop (by omega))
      | cons b RR' =>
        have hstep := bsB2_close_next (prog := prog) (M := M) (b := b) (RR := RR') (co := co)
          (out := out)
          (by omega)
        have hle : valSize (bsB2Enc RR' b [] (co :: out)) ≤ valSize (bsB2Enc (b :: RR') [] co out) := by
          have e := bsB2Enc_size (b :: RR') [] co out
          have e' := bsB2Enc_size RR' b [] (co :: out)
          have hRR := bsB_vlist_cons (encL encN b) (RR'.map (encL encN))
          have hout := bsB_vlist_cons (encL encN co) (out.map (encL encN))
          have hnil0 := bsB_encL_nil
          rw [List.map_cons] at e e'
          omega
        have hrest := ih RR' b [] (co :: out)
          (by simp only [List.length_cons, List.map_cons, List.sum_cons, List.length_nil] at hm
              omega)
          (le_trans hle hs)
        have e : bsB2Fin RR' b [] (co :: out) = bsB2Fin (b :: RR') [] co out := by
          simp [bsB2Fin, List.append_assoc]
        rw [e] at hrest
        exact EvalsVal.cont h2 hstep one_ne_zero hrest

end Run2

/-! ## The routine -/

/-- **Spec of `bsBlocks`** (deterministic, value bound `|ns| + |codes| + 32`). -/
theorem bsBlocks_eval {prog : List Expr} {M : ℕ}
    (hlib : ∀ e ∈ bsBlocksTable, prog[e.1]? = some e.2) {ns codes : List ℕ}
    (hlen : ns.sum ≤ codes.length)
    (hM : valSize (encL encN ns) + valSize (encL encN codes) + 32 ≤ M) :
    EvalsVal prog M [Val.list [encL encN ns, encL encN codes]] [] (.inl body_bsBlocks)
      (Val.list ((splitBlocks ns codes).map (encL encN))) := by
  have h1 : prog[Idx.bsBlocks1]? = some body_bsBlocks1 :=
    hlib (Idx.bsBlocks1, body_bsBlocks1) (by simp [bsBlocksTable])
  have h2 : prog[Idx.bsBlocks2]? = some body_bsBlocks2 :=
    hlib (Idx.bsBlocks2, body_bsBlocks2) (by simp [bsBlocksTable])
  have hXM : valSize (Val.list [encL encN ns, encL encN codes]) ≤ M := by
    rw [bsB_vs_pair]; omega
  have h2M : 2 ≤ M := by omega
  have fns : EvalsVal prog M [Val.list [encL encN ns, encL encN codes]] [] (.inl (eAtN 0 (eV 0)))
      (encL encN ns) := bsB_at rfl hXM rfl
  have fcodes : EvalsVal prog M [Val.list [encL encN ns, encL encN codes]] []
      (.inl (eAtN 1 (eV 0))) (encL encN codes) := bsB_at rfl hXM rfl
  unfold body_bsBlocks
  cases ns with
  | nil =>
    exact bsB_iteT (EvalsVal.isNil_nil fns h2M) one_ne_zero
      (bsB_nil h2M)
  | cons n ns' =>
    refine bsB_iteF (EvalsVal.isNil_cons fns (by omega)) rfl ?_
    have hn := bsB_encL_cons n ns'
    -- loop 1 from `[ns', codes, [], [], n]`
    have hs1 : valSize (bsB1Enc ns' codes [] [] n) = valSize (encL encN (n :: ns')) +
        valSize (encL encN codes) + 7 := by
      rw [bsB1Enc_size, bsB_encL_nil]
      simp only [List.map_nil, valSize_list, listSize_nil]
      omega
    have hinit1 : EvalsVal prog M [Val.list [encL encN (n :: ns'), encL encN codes]] []
        (.inl (eList [eTl (eAtN 0 (eV 0)), eAtN 1 (eV 0), Expr.nil, Expr.nil, eHd (eAtN 0 (eV 0))]))
        (bsB1Enc ns' codes [] [] n) :=
      evalsVal_list (.cons (EvalsVal.tail fns (show valSize (encL encN ns') ≤ M by omega))
        (.cons fcodes (.cons (bsB_nil h2M)
          (.cons (bsB_nil h2M)
            (.cons (EvalsVal.head fns (by omega)) .nil)))))
        (show valSize (bsB1Enc ns' codes [] [] n) ≤ M by omega)
    have hloop1 := bsB1_run h1 (M := M) (B := valSize (bsB1Enc ns' codes [] [] n)) (by omega)
      (codes.length + ns'.length) ns' codes [] [] n rfl
      (by simp only [List.sum_cons] at hlen; omega) le_rfl
    have e1 : bsB1Fin ns' codes [] [] n =
        ((splitBlocks (n :: ns') codes).map List.reverse).reverse := by
      simp [bsB1Fin, splitBlocks]
    rw [e1] at hloop1
    refine bsB_letE (EvalsVal.loop hinit1 hloop1) ?_
    -- loop 2 from `[tail, head, [], []]`
    have hne : ((splitBlocks (n :: ns') codes).map List.reverse).reverse ≠ [] := by
      simp [splitBlocks]
    obtain ⟨b0, RR0, hDR⟩ := List.exists_cons_of_ne_nil hne
    have hsz := bsB_valSize_splitBlocks (n :: ns') codes
    have hrev := bsB_size_rev (splitBlocks (n :: ns') codes)
    rw [hDR] at hrev ⊢
    have hlen2 : 2 * (n :: ns').length + 1 ≤ valSize (encL encN (n :: ns')) := by
      have := length_le_listSize ((n :: ns').map encN)
      simp only [encL, valSize_list, List.length_map] at this ⊢
      omega
    have hRR := bsB_vlist_cons (encL encN b0) (RR0.map (encL encN))
    rw [List.map_cons] at hrev
    have hs2 : valSize (bsB2Enc RR0 b0 [] []) =
        valSize (Val.list (encL encN b0 :: RR0.map (encL encN))) + 6 := by
      rw [bsB2Enc_size, bsB_encL_nil]
      simp only [List.map_nil, valSize_list, listSize_nil]
      simp only [valSize_list] at hRR
      omega
    have hDRM : valSize (Val.list (encL encN b0 :: RR0.map (encL encN))) ≤ M := by omega
    have hv0 : EvalsVal prog M [Val.list ((b0 :: RR0).map (encL encN)),
        Val.list [encL encN (n :: ns'), encL encN codes]] [] (.inl (eV 0))
        (Val.list (encL encN b0 :: RR0.map (encL encN))) := EvalsVal.var rfl
    have hinit2 : EvalsVal prog M [Val.list ((b0 :: RR0).map (encL encN)),
        Val.list [encL encN (n :: ns'), encL encN codes]] []
        (.inl (eList [eTl (eV 0), eHd (eV 0), Expr.nil, Expr.nil])) (bsB2Enc RR0 b0 [] []) :=
      evalsVal_list (.cons (EvalsVal.tail hv0 (by omega)) (.cons (EvalsVal.head hv0 (by omega))
        (.cons (bsB_nil h2M)
          (.cons (bsB_nil h2M) .nil))))
        (show valSize (bsB2Enc RR0 b0 [] []) ≤ M by omega)
    have hloop2 := bsB2_run h2 (M := M) (B := valSize (bsB2Enc RR0 b0 [] [])) (by omega)
      (RR0.length + (RR0.map List.length).sum + b0.length) RR0 b0 [] [] rfl le_rfl
    have e2 : bsB2Fin RR0 b0 [] [] = splitBlocks (n :: ns') codes := by
      have h := congrArg (fun L => (L.map List.reverse).reverse) hDR
      simp only [List.map_reverse, List.reverse_reverse, List.map_map] at h
      have hid : (List.reverse ∘ List.reverse : List ℕ → List ℕ) = id := by
        funext l; simp
      rw [hid, List.map_id] at h
      rw [h]
      simp [bsB2Fin, List.map_cons, List.reverse_cons]
    rw [e2] at hloop2
    exact EvalsVal.loop hinit2 hloop2

end F2e2e.BSpace
