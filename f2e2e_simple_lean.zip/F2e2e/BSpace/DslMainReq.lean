import F2e2e.BSpace.DslRound
import F2e2e.BSpace.AssembleDefs
import F2e2e.B.SpecV2BridgeExec
import F2e2e.B.NumericsDyadic

/-!
# B_space, layer D4 (W3): the entry specs on the data of `Theorem_B_space` (request oracle)

Owner: W3 (4a7299ed), for W2 (D4, a2ff64c3), C-TOP (95aff426) and the B_space area lead W4 (cc77ceaa).

W2's entry specs of D4 (`bsInit_impl`, `F2e2e/BSpace/DslMain.lean`; `bsRound_impl_gen`,
`F2e2e/BSpace/DslRound.lean`) restated on the data of Spec v3 §7 (`encVParams`, `encRecords`, `reqOracle`), in
the form used by the assembly (C-TOP's `AsmInitRunsW`, `AsmRoundRunsW`, `F2e2e/BSpace/Assemble.lean`), for the
core parameters `A = asmParams M J R a_req ξ_req` (`a_req ∈ (0, 1/10)`, `ξ_req ∈ (0, 1/2)`) and a sample
`s : Fin N → U` with `N = A.N` (C-TOP takes `hN := refine_N …`):

* `bsInit_implO` (null oracle): on `[encVParams M J R a_req ξ_req, encRecords code s]`, `body_bsInit` implements
  `adaInit A` with the state encoding `bsStateEnc (asmBlocks A code s)`;
* `bsRound_implR` (the oracle `reqOracle code req` of a valid request, injective `code`, a state with W4's
  invariant `AdaOK A st`): on `[encVParams …, bsStateEnc (asmBlocks A code s) st, Val.int (if req.2.1 then 1
  else 0)]`, `body_bsRound` implements the core round on the quantized request,
  `bsCoreRound A st (coreVals A (castSample hN s) (quantReq A req)) (quantReq A req).l (quantReq A req).u
  req.2.1`, with the output `[bsStateEnc (asmBlocks A code s) st', bsResp out]`.

Proofs: W2's specs (lifted to the oracle machine by `Implements.toO`); the oracle's ranges (1beb339b's
`bsE_reqOracle_mem`, W5's `bsN_trunc_abs_le`); the query table (`evalsOf_reqOracle_eq_coreVals`) and the
endpoints (`bsN_quant_eq`) of the quantized request; `4 ≤ dyadicExp a_req`, `2 ≤ dyadicExp ξ_req` (B-NUM).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-! ## The data of the sample -/

/-- The codes of a sample of `A.N` records. -/
theorem bsR_codes_length {U : Type} (A : AdaParams) (code : U → ℕ) {N : ℕ} (s : Fin N → U)
    (hN : N = A.N) : (List.ofFn fun ℓ => code (s ℓ)).length = A.N := by
  rw [List.length_ofFn]
  exact hN

/-- The stored blocks have the block sizes of `A`. -/
theorem bsR_asmBlocks_length {U : Type} (A : AdaParams) (code : U → ℕ) {N : ℕ} (s : Fin N → U)
    (hN : N = A.N) : (asmBlocks A code s).map List.length = A.blockSizes :=
  bsB_splitBlocks_length A.blockSizes _ (le_of_eq (bsR_codes_length A code s hN).symm)

/-- **D2 for a transported sample** (1beb339b's `evalsOf_reqOracle_eq_coreVals`): the query table read
through `reqOracle` on the stored blocks is `coreVals A (castSample hN s) (quantReq A req)`. -/
theorem bsR_evalsOf_eq {U : Type} (A : AdaParams) {code : U → ℕ} (hinj : Function.Injective code)
    {N : ℕ} (s : Fin N → U) (hN : N = A.N) {req : VReq U} (hreq : req.Valid) :
    evalsOf (reqOracle code req) A.qA (asmBlocks A code s) =
      coreVals A (V2.castSample hN s) (quantReq A req) := by
  subst hN
  exact evalsOf_reqOracle_eq_coreVals A hinj s hreq

/-- `reqOracle` at selector `1` and precision `q + 1`: the clipped lower endpoint, truncated. -/
theorem bsR_reqOracle_one {U : Type} (code : U → ℕ) (req : VReq U) (q : ℕ) :
    reqOracle code req 1 0 ((q : ℤ) + 1) = ⌊(2 : ℝ) ^ (q + 1) * max (-1) (min 2 req.2.2.1)⌋ := by
  have ht : ((q : ℤ) + 1).toNat = q + 1 := by omega
  have h10 : (1 : ℤ) ≠ 0 := by norm_num
  show (if (1 : ℤ) = 0 then _ else if (1 : ℤ) = 1 then truncIdx ((q : ℤ) + 1).toNat
      (max (-1) (min 2 req.2.2.1)) else _) = _
  rw [if_neg h10, if_pos rfl, ht]
  rfl

/-- `reqOracle` at selector `2` and precision `q + 1`: the clipped upper endpoint, truncated. -/
theorem bsR_reqOracle_two {U : Type} (code : U → ℕ) (req : VReq U) (q : ℕ) :
    reqOracle code req 2 0 ((q : ℤ) + 1) = ⌊(2 : ℝ) ^ (q + 1) * max (-1) (min 2 req.2.2.2)⌋ := by
  have ht : ((q : ℤ) + 1).toNat = q + 1 := by omega
  have h20 : (2 : ℤ) ≠ 0 := by norm_num
  have h21 : (2 : ℤ) ≠ 1 := by norm_num
  show (if (2 : ℤ) = 0 then _ else if (2 : ℤ) = 1 then _ else if (2 : ℤ) = 2 then
      truncIdx ((q : ℤ) + 1).toNat (max (-1) (min 2 req.2.2.2)) else _) = _
  rw [if_neg h20, if_neg h21, if_pos rfl, ht]
  rfl

/-- **D3 for `reqOracle`** (W5's `bsN_quant_eq`): the endpoints read by `bsEnds` are `quantReq`'s. -/
theorem bsR_ends_eq {U : Type} (A : AdaParams) (code : U → ℕ) (req : VReq U) :
    bsN_end A.qA (reqOracle code req 1 0 ((A.qA : ℤ) + 1)) = (quantReq A req).l ∧
      bsN_end A.qA (reqOracle code req 2 0 ((A.qA : ℤ) + 1)) = (quantReq A req).u := by
  constructor
  · unfold bsN_end
    exact bsN_quant_eq A req.2.2.1 _ (bsR_reqOracle_one code req A.qA)
  · unfold bsN_end
    exact bsN_quant_eq A req.2.2.2 _ (bsR_reqOracle_two code req A.qA)

/-! ## Initialization -/

/-- **Spec of `body_bsInit` on the data of `Theorem_B_space`** (Spec v3 §7; null oracle): on
`[encVParams M J R a_req ξ_req, encRecords code s]` (`a_req ∈ (0, 1/10)`, `ξ_req ∈ (0, 1/2)`, a sample of
`N = A.N` records, `A = asmParams M J R a_req ξ_req`), `body_bsInit` implements `adaInit A` with the state
encoding `bsStateEnc (asmBlocks A code s)`. W2's `bsInit_impl` lifted by `Implements.toO`. -/
theorem bsInit_implO {prog : List Expr} {M : ℕ} (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M) (hB : BlocksAt prog M)
    {Mc J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {U : Type} (code : U → ℕ) {N : ℕ} (s : Fin N → U)
    (hN : N = (asmParams Mc J R aReq ξReq).N)
    (hMP : bsPubBound Mc J R (dyadicExp aReq) (dyadicExp ξReq) ≤ M)
    (hM : 2 ^ 32 * adaBoundA (asmParams Mc J R aReq ξReq) +
      2 * valSize (encL encN (List.ofFn fun ℓ => code (s ℓ))) ≤ M) :
    ImplementsO nullOracle prog M [Val.list [encVParams Mc J R aReq ξReq, encRecords code s]]
      body_bsInit (bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s))
      (adaInit (asmParams Mc J R aReq ξReq)) := by
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  rw [bsB_encRecords]
  exact Implements.toO hO (bsInit_impl hW4 hpub hq hB h4 h2
    (bsR_codes_length (asmParams Mc J R aReq ξReq) code s hN) hMP hM)

/-! ## A request -/

/-- **Spec of `body_bsRound` on the data of `Theorem_B_space`** (Spec v3 §7; the oracle of a valid
request, injective record encoding): on `[encVParams M J R a_req ξ_req, bsStateEnc (asmBlocks A code s) st,
Val.int (if req.2.1 then 1 else 0)]` (state `st` with W4's invariant `AdaOK A st`), `body_bsRound`
implements the core round on the quantized request,
`bsCoreRound A st (coreVals A (castSample hN s) (quantReq A req)) (quantReq A req).l (quantReq A req).u
req.2.1`, with the output `[bsStateEnc (asmBlocks A code s) st', bsResp out]`. W2's `bsRound_impl_gen` at the
oracle `reqOracle code req` (ranges: `bsE_reqOracle_mem`, `bsN_trunc_abs_le`), with D2's
`evalsOf_reqOracle_eq_coreVals` and D3's `bsN_quant_eq`. -/
theorem bsRound_implR {prog : List Expr} {M : ℕ} (hO : prog[bsOracleIdx]? = none) (hW4 : W4Lib prog)
    (hpub : ∀ e ∈ bsPubTable, prog[e.1]? = some e.2) (hq : NormQSpec prog M)
    (hEv : ∀ e ∈ bsEvalsTable, prog[e.1]? = some e.2) (hEn : ∀ e ∈ bsEndsTable, prog[e.1]? = some e.2)
    {Mc J R : ℕ} {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) {U : Type} {code : U → ℕ} (hinj : Function.Injective code) {N : ℕ}
    (s : Fin N → U) (hN : N = (asmParams Mc J R aReq ξReq).N) {req : VReq U} (hreq : req.Valid)
    {st : AdaState} (hok : AdaOK (asmParams Mc J R aReq ξReq) st)
    (hMP : bsPubBound Mc J R (dyadicExp aReq) (dyadicExp ξReq) ≤ M)
    (hM : 2 ^ 32 * adaBoundA (asmParams Mc J R aReq ξReq) +
      2 * valSize (Val.list ((asmBlocks (asmParams Mc J R aReq ξReq) code s).map (encL encN))) ≤ M) :
    ImplementsO (reqOracle code req) prog M
      [Val.list [encVParams Mc J R aReq ξReq, bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams Mc J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams Mc J R aReq ξReq) st
        (coreVals (asmParams Mc J R aReq ξReq) (V2.castSample hN s)
          (quantReq (asmParams Mc J R aReq ξReq) req))
        (quantReq (asmParams Mc J R aReq ξReq) req).l (quantReq (asmParams Mc J R aReq ξReq) req).u
        req.2.1) := by
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  have hblk := bsR_asmBlocks_length (asmParams Mc J R aReq ξReq) code s hN
  have horc0 : ∀ blk ∈ asmBlocks (asmParams Mc J R aReq ξReq) code s, ∀ r ∈ blk,
      0 ≤ reqOracle code req 0 (r : ℤ) ((asmParams Mc J R aReq ξReq).qA + 1) ∧
        reqOracle code req 0 (r : ℤ) ((asmParams Mc J R aReq ξReq).qA + 1) ≤
          2 ^ ((asmParams Mc J R aReq ξReq).qA + 1) :=
    fun _ _ r _ => bsE_reqOracle_mem code hreq (r : ℤ) _
  have horc12 : |reqOracle code req 1 0 ((asmParams Mc J R aReq ξReq).qA + 1)| ≤
        2 ^ ((asmParams Mc J R aReq ξReq).qA + 2) ∧
      |reqOracle code req 2 0 ((asmParams Mc J R aReq ξReq).qA + 1)| ≤
        2 ^ ((asmParams Mc J R aReq ξReq).qA + 2) := by
    rw [bsR_reqOracle_one, bsR_reqOracle_two]
    exact ⟨bsN_trunc_abs_le _ _, bsN_trunc_abs_le _ _⟩
  have key := bsRound_impl_gen hO hW4 hpub hq hEv hEn h4 h2 hblk hok req.2.1 horc0 horc12 hMP hM
  have hv := bsR_evalsOf_eq (asmParams Mc J R aReq ξReq) hinj s hN hreq
  obtain ⟨el, eu⟩ := bsR_ends_eq (asmParams Mc J R aReq ξReq) code req
  refine ImplementsO.congr key ?_ (fun _ => rfl)
  rw [hv, el, eu]

end F2e2e.BSpace
