import F2e2e.BSpace.O2BridgeStep
import F2e2e.BSpace.MachineSimO
import F2e2e.Cost.Generic

/-!
# O2b additive bridge, part 2: the additive simulation (17fc0802)

The oracle-machine simulation of `evalO` (`MachineO.simO`) with an **additive** invariant. The configuration bound
is linear in the big-step peak with the factor `2·(D+1)` (the environment-copy multiplicity of the locked machine:
every pending `binL`/`ite`/`letE` frame stores a copy of its activation's environment). The frame overhead is paid
per activation level instead of per unit of value size. Levels come from a rank certificate `RankOK prog r Kd`:
a call/loop body runs at a strictly lower level (`CalleesLt`).

Invariant `Inv prog K B δ v d` of a configuration `d` met while simulating an expression whose result is `v` and
whose peak excess is `δ`, on top of the stack `K`:
* `Within prog K B d` (the control and the frames pushed on top of `K` take at most `B` bits);
* operand clause: a return `w` to a `binR p va` frame strictly above `K` has `valSize va + valSize w ≤ δ`;
* only the final configuration returns at the base stack `K` (its value is `v`).

Bound for an expression of height `h` in `env` at level `ρ` with peak excess `δ` (`E = progDepth prog + 1`,
`fc = frameC prog`):
`addB prog h env δ ρ = (h+1)·(|bitEncodeVals env| + fc + 4) + 2E·δ + ρ·E·(fc + 4)`.

Results: `simA` (the simulation) and `confBits_le_addTop` / `opBits_le_addTop` (every configuration of a top-level
run has at most `2E·S + 3E + (r₀+1)·E·(fc+4) + 1` bits, and its arithmetic operands have `opBits ≤ 2S + 2`).
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine F2e2e.Cost F2e2e.BSpace.MachineO

/-! ## Sharper encoding lengths: `|bitEncodeVal v| ≤ 2·valSize v + 1` -/

mutual
theorem bitEncodeVal_length_le2 : ∀ v : Val, (bitEncodeVal v).length ≤ 2 * valSize v + 1
  | Val.int z => by
      rw [bitEncodeVal_int_length]
      simp only [valSize]
      omega
  | Val.list xs => by
      have := bitEncodeVals_length_le2 xs
      rw [bitEncodeVal_list_length]
      simp only [valSize]
      omega
theorem bitEncodeVals_length_le2 : ∀ l : List Val, (bitEncodeVals l).length ≤ 2 * listSize l + 1
  | [] => by simp [bitEncodeVals, listSize]
  | x :: xs => by
      have h1 := bitEncodeVal_length_le2 x
      have h2 := bitEncodeVals_length_le2 xs
      rw [bitEncodeVals_cons_length]
      simp only [listSize]
      omega
end

theorem one_le_bitEncodeVals_length (l : List Val) : 1 ≤ (bitEncodeVals l).length := by
  cases l with
  | nil => simp [bitEncodeVals]
  | cons x xs => rw [bitEncodeVals_cons_length]; omega

/-! ## The invariant -/

/-- The operand clause: a return `w` to a `binR p va` frame strictly above `K` has `valSize va + valSize w ≤ δ`. -/
def OpsOK (K : List Frame) (δ : ℕ) (d : Conf) : Prop :=
  ∀ w p va K', d.ctrl = Ctrl.ret w → d.stack = Frame.binR p va :: K' → K.length ≤ K'.length →
    valSize va + valSize w ≤ δ

/-- Only the final configuration (with value `v`) returns at the base stack `K`. -/
def FinOK (K : List Frame) (v : Val) (d : Conf) : Prop :=
  d.stack = K → ∀ w, d.ctrl = Ctrl.ret w → w = v

/-- The invariant of the additive simulation. -/
def Inv (prog : List Expr) (K : List Frame) (B δ : ℕ) (v : Val) (d : Conf) : Prop :=
  Within prog K B d ∧ OpsOK K δ d ∧ FinOK K v d

theorem Inv.weaken {prog : List Expr} {K : List Frame} {B B' δ δ' : ℕ} {v : Val} {d : Conf}
    (h : Inv prog K B δ v d) (hB : B ≤ B') (hδ : δ ≤ δ') : Inv prog K B' δ' v d :=
  ⟨h.1.mono hB, fun w p va K' h1 h2 h3 => (h.2.1 w p va K' h1 h2 h3).trans hδ, h.2.2⟩

/-- Pushing a frame `f` below a simulation (its result `v'`): the configurations stay above `f :: K`. -/
theorem Inv.push {prog : List Expr} {K : List Frame} {f : Frame} {B B' δ' δ : ℕ} {v' v : Val} {d : Conf}
    (h : Inv prog (f :: K) B δ' v' d) (hB : B + frameBits prog f ≤ B') (hδ : δ' ≤ δ)
    (hop : ∀ q va, f = Frame.binR q va → valSize va + valSize v' ≤ δ) : Inv prog K B' δ v d := by
  obtain ⟨hW, hO, hF⟩ := h
  refine ⟨hW.push.mono hB, fun w p va K' h1 h2 h3 => ?_, fun hd => ?_⟩
  · -- either the `binR` frame is strictly above `f :: K`, or it is `f` itself (then `d` is the final one)
    obtain ⟨F, hs, -⟩ := hW
    by_cases hlen : (f :: K).length ≤ K'.length
    · exact (hO w p va K' h1 h2 hlen).trans hδ
    · have hF0 : F = [] := by
        have hl := congrArg List.length (h2.symm.trans hs)
        simp only [List.length_cons, List.length_append] at hl hlen
        exact List.eq_nil_of_length_eq_zero (by omega)
      subst hF0
      simp only [List.nil_append] at hs
      rw [h2] at hs
      obtain ⟨rfl, rfl⟩ := List.cons.inj hs
      have := hF (by rw [h2]) w h1
      subst this
      exact hop p va rfl
  · -- the stack `K` is never reached inside the pushed run (it has `f` on top)
    obtain ⟨F, hs, -⟩ := hW
    have hl := congrArg List.length (hd.symm.trans hs)
    simp only [List.length_cons, List.length_append] at hl
    omega

theorem RunAllO.pushInv {orc : VOracle} {prog : List Expr} {K : List Frame} {f : Frame}
    {B B' δ' δ : ℕ} {v' v : Val} {c c' : Conf}
    (h : RunAllO orc prog (Inv prog (f :: K) B δ' v') c c') (hB : B + frameBits prog f ≤ B')
    (hδ : δ' ≤ δ) (hop : ∀ q va, f = Frame.binR q va → valSize va + valSize v' ≤ δ) :
    RunAllO orc prog (Inv prog K B' δ v) c c' :=
  h.mono fun _ hd => hd.push hB hδ hop

theorem RunAllO.weakenInv {orc : VOracle} {prog : List Expr} {K : List Frame} {B B' δ δ' : ℕ}
    {v : Val} {c c' : Conf} (h : RunAllO orc prog (Inv prog K B δ v) c c') (hB : B ≤ B')
    (hδ : δ ≤ δ') : RunAllO orc prog (Inv prog K B' δ' v) c c' :=
  h.mono fun _ hd => hd.weaken hB hδ

/-! ## The additive bound and its arithmetic -/

/-- The additive bound for simulating an expression of height `h` in `env` at activation level `ρ` whose peak
exceeds its base by `δ`. -/
def addB (prog : List Expr) (h : ℕ) (env : List Val) (δ ρ : ℕ) : ℕ :=
  (h + 1) * ((bitEncodeVals env).length + frameC prog + 4) + 2 * (progDepth prog + 1) * δ +
    ρ * (progDepth prog + 1) * (frameC prog + 4)

/-- The bound of the iterations of a loop whose node is at level `ρ` (its body runs at a lower level). -/
def loopB (prog : List Expr) (δ ρ : ℕ) : ℕ :=
  frameC prog + 2 * (progDepth prog + 1) * δ + 3 * (progDepth prog + 1) +
    ρ * (progDepth prog + 1) * (frameC prog + 4)

theorem frameC_ge (prog : List Expr) : 3 * progDepth prog + 6 ≤ frameC prog := by
  unfold frameC posBits; omega

theorem addB_mono {prog : List Expr} {h h' δ δ' ρ ρ' : ℕ} (env : List Val) (hh : h ≤ h') (hδ : δ ≤ δ')
    (hρ : ρ ≤ ρ') : addB prog h env δ ρ ≤ addB prog h' env δ' ρ' := by
  unfold addB
  have h1 := Nat.mul_le_mul_right ((bitEncodeVals env).length + frameC prog + 4)
    (show h + 1 ≤ h' + 1 by omega)
  have h2 := Nat.mul_le_mul_left (2 * (progDepth prog + 1)) hδ
  have h3 := Nat.mul_le_mul_right (frameC prog + 4) (Nat.mul_le_mul_right (progDepth prog + 1) hρ)
  omega

/-- A frame of the current activation holding at most one copy of the environment. -/
theorem addB_push_env {prog : List Expr} {h ha δ δa ρ : ℕ} (env : List Val) (hh : ha + 1 ≤ h)
    (hδ : δa ≤ δ) {fb : ℕ} (hfb : fb ≤ (bitEncodeVals env).length + frameC prog + 4) :
    addB prog ha env δa ρ + fb ≤ addB prog h env δ ρ := by
  unfold addB
  set X := (bitEncodeVals env).length + frameC prog + 4
  have h1 : (ha + 1) * X + X ≤ (h + 1) * X := by
    rw [← Nat.succ_mul]; exact Nat.mul_le_mul_right _ (by omega)
  have h2 := Nat.mul_le_mul_left (2 * (progDepth prog + 1)) hδ
  omega

/-- A frame of the current activation holding a value of size `s` charged in the base of the child. -/
theorem addB_push_val {prog : List Expr} {h hb δ δb ρ s : ℕ} (env : List Val) (hh : hb + 1 ≤ h)
    (hδ : δb + s ≤ δ) {fb : ℕ} (hfb : fb ≤ frameC prog + 1 + 2 * s) :
    addB prog hb env δb ρ + fb ≤ addB prog h env δ ρ := by
  unfold addB
  have hX := one_le_bitEncodeVals_length env
  set X := (bitEncodeVals env).length + frameC prog + 4
  have h1 : (hb + 1) * X + X ≤ (h + 1) * X := by
    rw [← Nat.succ_mul]; exact Nat.mul_le_mul_right _ (by omega)
  have h2 : 2 * (progDepth prog + 1) * δb + 2 * (progDepth prog + 1) * s ≤
      2 * (progDepth prog + 1) * δ := by
    rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ hδ
  have h3 : 2 * s ≤ 2 * (progDepth prog + 1) * s := by
    have := Nat.mul_le_mul_right s (show 2 ≤ 2 * (progDepth prog + 1) by omega)
    omega
  omega

/-- A new activation on `[v]` (call or loop body) at a lower level `ρb + 1 ≤ ρ`. -/
theorem addB_body {prog : List Expr} {hb δb ρb ρ : ℕ} {v : Val} (hD : hb ≤ progDepth prog)
    (hρ : ρb + 1 ≤ ρ) :
    addB prog hb [v] δb ρb ≤ 2 * (progDepth prog + 1) * (δb + valSize v) + 3 * (progDepth prog + 1) +
      ρ * (progDepth prog + 1) * (frameC prog + 4) := by
  unfold addB
  rw [bitEncodeVals_singleton_length]
  have hv := bitEncodeVal_length_le2 v
  set E := progDepth prog + 1
  set fc := frameC prog
  have h1 : (hb + 1) * ((bitEncodeVal v).length + 2 + fc + 4) ≤ E * (2 * valSize v + 3 + (fc + 4)) :=
    Nat.mul_le_mul (by omega) (by omega)
  have h2 : E * (2 * valSize v + 3 + (fc + 4)) = 2 * E * valSize v + 3 * E + E * (fc + 4) := by ring
  have h3 : ρb * E * (fc + 4) + E * (fc + 4) ≤ ρ * E * (fc + 4) := by
    have := Nat.mul_le_mul_right (E * (fc + 4)) hρ
    nlinarith
  have h4 : 2 * E * (δb + valSize v) = 2 * E * δb + 2 * E * valSize v := by ring
  omega

/-- A `letE` extension of the environment by `va`, charged in the base of the body. -/
theorem addB_letE {prog : List Expr} {h hb δ δb ρ : ℕ} {va : Val} (env : List Val) (hh : hb + 1 ≤ h)
    (hD : hb ≤ progDepth prog) (hδ : δb + valSize va ≤ δ) :
    addB prog hb (va :: env) δb ρ ≤ addB prog h env δ ρ := by
  unfold addB
  rw [bitEncodeVals_cons_length]
  have hv := bitEncodeVal_length_le2 va
  have hfc := frameC_ge prog
  set E := progDepth prog + 1
  set fc := frameC prog
  set X := (bitEncodeVals env).length + fc + 4
  have h1 : (hb + 1) * ((bitEncodeVal va).length + (bitEncodeVals env).length + 1 + fc + 4) ≤
      (hb + 1) * X + E * (2 * valSize va + 2) := by
    have h' : (hb + 1) * (2 * valSize va + 2) ≤ E * (2 * valSize va + 2) :=
      Nat.mul_le_mul_right _ (by omega)
    calc (hb + 1) * ((bitEncodeVal va).length + (bitEncodeVals env).length + 1 + fc + 4)
        ≤ (hb + 1) * (X + (2 * valSize va + 2)) := Nat.mul_le_mul_left _ (by omega)
      _ = (hb + 1) * X + (hb + 1) * (2 * valSize va + 2) := Nat.mul_add _ _ _
      _ ≤ (hb + 1) * X + E * (2 * valSize va + 2) := Nat.add_le_add_left h' _
  have h2 : (hb + 1) * X + X ≤ (h + 1) * X := by
    rw [← Nat.succ_mul]; exact Nat.mul_le_mul_right _ (by omega)
  have h3 : 2 * E * δb + 2 * E * valSize va ≤ 2 * E * δ := by
    rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ hδ
  have h4 : E * (2 * valSize va + 2) = 2 * E * valSize va + 2 * E := by ring
  have h5 : 2 * E ≤ X := by omega
  omega

/-- The bound of a call body, absorbed at the call node (height `h ≥ 1`). -/
theorem addB_call {prog : List Expr} {h δ δ' ρ : ℕ} (env : List Val) (hh : 1 ≤ h) (hδ : δ' ≤ δ) :
    2 * (progDepth prog + 1) * δ' + 3 * (progDepth prog + 1) +
      ρ * (progDepth prog + 1) * (frameC prog + 4) ≤ addB prog h env δ ρ := by
  unfold addB
  have hfc := frameC_ge prog
  have h1 : 2 * ((bitEncodeVals env).length + frameC prog + 4) ≤
      (h + 1) * ((bitEncodeVals env).length + frameC prog + 4) := Nat.mul_le_mul_right _ (by omega)
  have h2 := Nat.mul_le_mul_left (2 * (progDepth prog + 1)) hδ
  omega

/-- The loop bound, absorbed at the loop node (height `h ≥ 1`). -/
theorem loopB_le_addB {prog : List Expr} {h δ δ' ρ : ℕ} (env : List Val) (hh : 1 ≤ h) (hδ : δ' ≤ δ) :
    loopB prog δ' ρ ≤ addB prog h env δ ρ := by
  unfold loopB addB
  have hfc := frameC_ge prog
  have h1 : 2 * ((bitEncodeVals env).length + frameC prog + 4) ≤
      (h + 1) * ((bitEncodeVals env).length + frameC prog + 4) := Nat.mul_le_mul_right _ (by omega)
  have h2 := Nat.mul_le_mul_left (2 * (progDepth prog + 1)) hδ
  omega

theorem loopB_mono {prog : List Expr} {δ δ' ρ : ℕ} (hδ : δ ≤ δ') : loopB prog δ ρ ≤ loopB prog δ' ρ := by
  unfold loopB
  have := Nat.mul_le_mul_left (2 * (progDepth prog + 1)) hδ
  omega

/-! ## First and last configurations -/

theorem start_inv {prog : List Expr} {q : CodePos} {e : Expr} (hq : exprAt prog q = some e)
    (env : List Val) (K : List Frame) (tape : List Bool) (h δ ρ : ℕ) (v : Val) :
    Inv prog K (addB prog h env δ ρ) δ v ⟨Ctrl.eval q env, K, tape⟩ := by
  refine ⟨Within.top ?_, fun w p va K' h1 _ _ => by simp at h1, fun _ w h1 => by simp at h1⟩
  rw [encodeCtrl_eval_length]
  have hp := encodePos_le hq
  unfold addB frameC
  have h1 : (bitEncodeVals env).length + (posBits prog + 5) + 4 ≤
      (h + 1) * ((bitEncodeVals env).length + (posBits prog + 5) + 4) :=
    Nat.le_mul_of_pos_left _ (by omega)
  omega

theorem ret_inv {prog : List Expr} {v : Val} {δ : ℕ} (hv : valSize v ≤ δ) (K : List Frame)
    (tape : List Bool) (h : ℕ) (env : List Val) (ρ : ℕ) :
    Inv prog K (addB prog h env δ ρ) δ v ⟨Ctrl.ret v, K, tape⟩ := by
  refine ⟨Within.top ?_, fun w p va K' _ h2 h3 => ?_, fun _ w h1 => ?_⟩
  · rw [encodeCtrl_ret_length]
    have h1 := bitEncodeVal_length_le2 v
    have h2 : 2 * valSize v ≤ 2 * (progDepth prog + 1) * δ := by
      have := Nat.mul_le_mul (show 2 ≤ 2 * (progDepth prog + 1) by omega) hv
      omega
    unfold addB
    have h3 : 2 ≤ (h + 1) * ((bitEncodeVals env).length + frameC prog + 4) :=
      Nat.le_trans (by omega) (Nat.le_mul_of_pos_left _ (by omega))
    omega
  · simp only at h2
    have hl := congrArg List.length h2
    simp only [List.length_cons] at hl
    omega
  · simp only [Ctrl.ret.injEq] at h1
    exact h1.symm

/-! ## The simulation theorem -/

/-- The additive simulation of `evalO` (first component) and `loopRunO` (second component) at fuel `n`. -/
theorem simA (orc : VOracle) (prog : List Expr) {r : ℕ → ℕ} {Kd : ℕ} (hR : RankOK prog r Kd) :
    ∀ n : ℕ,
    (∀ (base : ℕ) (env : List Val) (tape : List Bool) (e : Expr) (v : Val) (c pk : ℕ)
        (tape' : List Bool) (q : CodePos) (K : List Frame) (ρ : ℕ),
        evalO orc prog n base env tape e = some (v, c, pk, tape') → exprAt prog q = some e →
        CalleesLt r ρ e →
        RunAllO orc prog (Inv prog K (addB prog (height e) env (pk - base) ρ) (pk - base) v)
          ⟨Ctrl.eval q env, K, tape⟩ ⟨Ctrl.ret v, K, tape'⟩) ∧
    (∀ (base i : ℕ) (v : Val) (tape : List Bool) (w : Val) (cw pw : ℕ) (tw : List Bool)
        (q : CodePos) (a : Expr) (K : List Frame) (ρ : ℕ),
        loopRunO orc prog n base i v tape = some (w, cw, pw, tw) →
        exprAt prog q = some (Expr.loop i a) → r i < ρ →
        RunAllO orc prog (Inv prog K (loopB prog (pw - base) ρ) (pw - base) w)
          ⟨Ctrl.eval ⟨i, []⟩ [v], Frame.loopIter q :: K, tape⟩ ⟨Ctrl.ret w, K, tw⟩)
  | 0 => ⟨fun base env tape e _ _ _ _ _ _ _ he _ _ => by
            have h := (evalO_zero_eq orc prog base env tape e).symm.trans he
            exact absurd h (by simp),
          fun base i v tape _ _ _ _ _ _ _ _ hl _ _ => by
            have h := (loopRunO_zero_eq orc prog base i v tape).symm.trans hl
            exact absurd h (by simp)⟩
  | n + 1 => by
    obtain ⟨ihE, ihL⟩ := simA orc prog hR n
    constructor
    · intro base env tape e v c pk tape' q K ρ he hq hc
      cases e with
      | var i =>
        obtain ⟨v', hv', hr⟩ := (evalO_var_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        exact RunAllO.single ((stepO_eval).trans (step_eval_var hq hv'))
          (start_inv hq env K tape _ _ _ _) (ret_inv (by omega) K tape _ env _)
      | lit z =>
        have he' := (evalO_lit_eq orc prog n base env tape z).symm.trans he
        simp only [Option.some.injEq, Prod.mk.injEq] at he'
        obtain ⟨rfl, -, rfl, h4⟩ := he'
        subst tape'
        exact RunAllO.single ((stepO_eval).trans (step_eval_lit hq)) (start_inv hq env K tape _ _ _ _)
          (ret_inv (by omega) K tape _ env _)
      | nil =>
        have he' := (evalO_nil_eq orc prog n base env tape).symm.trans he
        simp only [Option.some.injEq, Prod.mk.injEq] at he'
        obtain ⟨rfl, -, rfl, h4⟩ := he'
        subst tape'
        exact RunAllO.single ((stepO_eval).trans (step_eval_nil hq)) (start_inv hq env K tape _ _ _ _)
          (ret_inv (by omega) K tape _ env _)
      | coin =>
        obtain ⟨b, rest, rfl, hr⟩ := (evalO_coin_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨rfl, -, rfl, h4⟩ := hr
        subst tape'
        exact RunAllO.single ((stepO_eval).trans (step_eval_coin hq)) (start_inv hq env K _ _ _ _ _)
          (ret_inv (by omega) K rest _ env _)
      | bin op a b =>
        have hc' : CalleesLt r ρ a ∧ CalleesLt r ρ b := hc
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, v', c', ha, hb, hv, hr⟩ :=
          (evalO_bin_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hqb : exprAt prog (q.child 1) = some b := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.bin op a b) := height_child (j := 0) rfl
        have hhb : height b + 1 ≤ height (Expr.bin op a b) := height_child (j := 1) rfl
        have hpa : base + valSize va ≤ pa := evalO_peak_ge orc prog n base env tape a _ ha
        have hpb : base + valSize va + valSize vb ≤ pb :=
          evalO_peak_ge orc prog n (base + valSize va) env ta b _ hb
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max (max pa pb) (base + valSize va + valSize vb + valSize v') :=
          (le_max_left _ _).trans (le_max_left _ _)
        have hm2 : pb ≤ max (max pa pb) (base + valSize va + valSize vb + valSize v') :=
          (le_max_right _ _).trans (le_max_left _ _)
        have hm3 : base + valSize va + valSize vb + valSize v' ≤
            max (max pa pb) (base + valSize va + valSize vb + valSize v') := le_max_right _ _
        have IHa := RunAllO.pushInv (v := v') (δ := max (max pa pb) (base + valSize va + valSize vb + valSize v') - base) (ihE base env tape a va ca pa ta (q.child 0)
          (Frame.binL q env :: K) ρ ha hqa hc'.1)
          (B' := addB prog (height (Expr.bin op a b)) env
            (max (max pa pb) (base + valSize va + valSize vb + valSize v') - base) ρ) (by
            rw [frameBits_binL]
            exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
            (fun _ _ h => by simp at h)
        have IHb := RunAllO.pushInv (v := v') (δ := max (max pa pb) (base + valSize va + valSize vb + valSize v') - base) (ihE (base + valSize va) env ta b vb cb pb tb (q.child 1)
          (Frame.binR q va :: K) ρ hb hqb hc'.2)
          (B' := addB prog (height (Expr.bin op a b)) env
            (max (max pa pb) (base + valSize va + valSize vb + valSize v') - base) ρ) (by
            rw [frameBits_binR]
            have := bitEncodeVal_length_le2 va
            exact addB_push_val (s := valSize va) env hhb (by omega)
              (by unfold frameC; omega)) (by omega)
            (fun q' va' h => by
              simp only [Frame.binR.injEq] at h
              obtain ⟨rfl, rfl⟩ := h
              omega)
        exact (((RunAllO.cons_step ((stepO_eval).trans (step_eval_bin hq))
          (start_inv hq env K tape _ _ _ _) IHa).snoc_step
          stepO_ret_binL IHb.first).trans IHb).snoc_step (stepO_ret_binR hq hv)
          (ret_inv (by omega) K tb _ env _)
      | un op a =>
        have hc' : CalleesLt r ρ a := hc
        obtain ⟨va, ca, pa, ta, v', c', ha, hv, hr⟩ := (evalO_un_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.un op a) := height_child (j := 0) rfl
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa (base + valSize va + valSize v') := le_max_left _ _
        have hm2 : base + valSize va + valSize v' ≤ max pa (base + valSize va + valSize v') :=
          le_max_right _ _
        have IHa := RunAllO.pushInv (v := v') (δ := max pa (base + valSize va + valSize v') - base)
          (ihE base env tape a va ca pa ta (q.child 0) (Frame.un q :: K) ρ ha hqa hc')
          (B' := addB prog (height (Expr.un op a)) env
            (max pa (base + valSize va + valSize v') - base) ρ) (by
            rw [frameBits_un]
            exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
            (fun _ _ h => by simp at h)
        exact (RunAllO.cons_step ((stepO_eval).trans (step_eval_un hq))
          (start_inv hq env K tape _ _ _ _) IHa).snoc_step
          (stepO_ret_un hq hv) (ret_inv (by omega) K ta _ env _)
      | ite cnd tb fb =>
        have hc' : CalleesLt r ρ cnd ∧ CalleesLt r ρ tb ∧ CalleesLt r ρ fb := hc
        obtain ⟨z, cc, pc, tc, v', cv, pv, tv, hcnd, hbr, hr⟩ := (evalO_ite_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqc : exprAt prog (q.child 0) = some cnd := exprAt_child hq rfl
        have hqbr : exprAt prog (q.child (if z ≠ 0 then 1 else 2)) =
            some (if z ≠ 0 then tb else fb) := by
          split_ifs
          · exact exprAt_child hq rfl
          · exact exprAt_child hq rfl
        have hcbr : CalleesLt r ρ (if z ≠ 0 then tb else fb) := by
          split_ifs
          · exact hc'.2.1
          · exact hc'.2.2
        have hhc : height cnd + 1 ≤ height (Expr.ite cnd tb fb) := height_child (j := 0) rfl
        have hhbr : height (if z ≠ 0 then tb else fb) + 1 ≤ height (Expr.ite cnd tb fb) := by
          split_ifs
          · exact height_child (j := 1) rfl
          · exact height_child (j := 2) rfl
        have hpos := encodePos_le hq
        have IHc := RunAllO.pushInv (v := v') (δ := max pc pv - base) (ihE base env tape cnd (Val.int z) cc pc tc (q.child 0)
          (Frame.ite q env :: K) ρ hcnd hqc hc'.1)
          (B' := addB prog (height (Expr.ite cnd tb fb)) env (max pc pv - base) ρ) (by
            rw [frameBits_ite]
            exact addB_push_env env hhc (by omega) (by unfold frameC; omega)) (by omega)
            (fun _ _ h => by simp at h)
        have IHbr := RunAllO.weakenInv (δ' := max pc pv - base) (ihE base env tc _ v' cv pv tv _ K ρ hbr hqbr hcbr)
          (B' := addB prog (height (Expr.ite cnd tb fb)) env (max pc pv - base) ρ)
          (addB_mono env (by omega) (by omega) le_rfl) (by omega)
        exact ((RunAllO.cons_step ((stepO_eval).trans (step_eval_ite hq))
          (start_inv hq env K tape _ _ _ _) IHc).snoc_step
          stepO_ret_ite IHbr.first).trans IHbr
      | letE a b =>
        have hc' : CalleesLt r ρ a ∧ CalleesLt r ρ b := hc
        obtain ⟨va, ca, pa, ta, vb, cb, pb, tb, ha, hb, hr⟩ := (evalO_letE_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hqb : exprAt prog (q.child 1) = some b := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.letE a b) := height_child (j := 0) rfl
        have hhb : height b + 1 ≤ height (Expr.letE a b) := height_child (j := 1) rfl
        have hDb : height b ≤ progDepth prog := by have := exprAt_bound hqb; omega
        have hpb : base + valSize va + valSize vb ≤ pb :=
          evalO_peak_ge orc prog n (base + valSize va) (va :: env) ta b _ hb
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa pb := le_max_left _ _
        have hm2 : pb ≤ max pa pb := le_max_right _ _
        have IHa := RunAllO.pushInv (v := vb) (δ := max pa pb - base) (ihE base env tape a va ca pa ta
          (q.child 0) (Frame.letE q env :: K) ρ ha hqa hc'.1)
          (B' := addB prog (height (Expr.letE a b)) env (max pa pb - base) ρ) (by
            rw [frameBits_letE]
            exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
            (fun _ _ h => by simp at h)
        have IHb := RunAllO.weakenInv (δ' := max pa pb - base) (ihE (base + valSize va) (va :: env) ta b vb cb pb tb (q.child 1)
          K ρ hb hqb hc'.2)
          (B' := addB prog (height (Expr.letE a b)) env (max pa pb - base) ρ)
          (addB_letE env hhb hDb (by omega)) (by omega)
        exact ((RunAllO.cons_step ((stepO_eval).trans (step_eval_letE hq))
          (start_inv hq env K tape _ _ _ _) IHa).snoc_step
          stepO_ret_letE IHb.first).trans IHb
      | call i a =>
        have hc' : r i < ρ ∧ CalleesLt r ρ a := hc
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.call i a) := height_child (j := 0) rfl
        have hpos := encodePos_le hq
        by_cases hi : i = bsOracleIdx
        · -- the oracle call: the argument runs under a `callArg` frame, then one oracle step
          subst hi
          obtain ⟨va, ca, pa, ta, sel, rr, qq, ha, hva, hr⟩ := (evalO_oracle_iff orc prog).1 he
          subst hva
          simp only [Prod.mk.injEq] at hr
          obtain ⟨h1, -, rfl, h4⟩ := hr
          subst v tape'
          have hm1 : pa ≤ max pa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int qq]) +
              valSize (Val.int (orc sel rr qq))) := le_max_left _ _
          have hm2 : base + valSize (Val.list [Val.int sel, Val.int rr, Val.int qq]) +
              valSize (Val.int (orc sel rr qq)) ≤
              max pa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int qq]) +
                valSize (Val.int (orc sel rr qq))) := le_max_right _ _
          have IHa := RunAllO.pushInv (v := Val.int (orc sel rr qq))
            (δ := max pa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int qq]) +
              valSize (Val.int (orc sel rr qq))) - base) (ihE base env tape a _ ca pa ta
            (q.child 0) (Frame.callArg q :: K) ρ ha hqa hc'.2)
            (B' := addB prog (height (Expr.call bsOracleIdx a)) env
              (max pa (base + valSize (Val.list [Val.int sel, Val.int rr, Val.int qq]) +
                valSize (Val.int (orc sel rr qq))) - base) ρ) (by
              rw [frameBits_callArg]
              exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
              (fun _ _ h => by simp at h)
          exact (RunAllO.cons_step ((stepO_eval).trans (step_eval_call hq))
            (start_inv hq env K tape _ _ _ _) IHa).snoc_step
            (stepO_ret_oracle hq bsOracleIdx_eq_oracleIdx) (ret_inv (by omega) K ta _ env _)
        · -- an ordinary call: the body runs at the lower level `r i`
          obtain ⟨va, ca, pa, ta, body, vb, cb, pb, tb, ha, hbody, hb, hr⟩ :=
            (evalO_call_iff orc prog hi).1 he
          simp only [Prod.mk.injEq] at hr
          obtain ⟨h1, -, rfl, h4⟩ := hr
          subst v tape'
          have hroot : exprAt prog ⟨i, []⟩ = some body := exprAt_root hbody
          have hDbody : height body ≤ progDepth prog := height_le_progDepth hbody
          have hcb : CalleesLt r (r i) body := (hR i body hbody).2
          have hpb : base + valSize va + valSize vb ≤ pb :=
            evalO_peak_ge orc prog n (base + valSize va) [va] ta body _ hb
          have hm1 : pa ≤ max pa pb := le_max_left _ _
          have hm2 : pb ≤ max pa pb := le_max_right _ _
          have IHa := RunAllO.pushInv (v := vb) (δ := max pa pb - base) (ihE base env tape a va ca pa ta
            (q.child 0) (Frame.callArg q :: K) ρ ha hqa hc'.2)
            (B' := addB prog (height (Expr.call i a)) env (max pa pb - base) ρ) (by
              rw [frameBits_callArg]
              exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
              (fun _ _ h => by simp at h)
          have IHb := RunAllO.weakenInv (δ' := max pa pb - base)
            (ihE (base + valSize va) [va] ta body vb cb pb tb ⟨i, []⟩ K (r i) hb hroot hcb)
            (B' := addB prog (height (Expr.call i a)) env (max pa pb - base) ρ) (by
              refine (addB_body (ρ := ρ) hDbody hc'.1).trans ?_
              exact addB_call env (by omega) (by omega)) (by omega)
          exact ((RunAllO.cons_step ((stepO_eval).trans (step_eval_call hq))
            (start_inv hq env K tape _ _ _ _) IHa).snoc_step
            (stepO_ret_callArg hq (by rw [← bsOracleIdx_eq_oracleIdx]; exact hi)) IHb.first).trans IHb
      | loop i a =>
        have hc' : r i < ρ ∧ CalleesLt r ρ a := hc
        obtain ⟨va, ca, pa, ta, w, cw, pw, tw, ha, hl, hr⟩ := (evalO_loop_iff orc prog).1 he
        simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst v tape'
        have hqa : exprAt prog (q.child 0) = some a := exprAt_child hq rfl
        have hha : height a + 1 ≤ height (Expr.loop i a) := height_child (j := 0) rfl
        have hpos := encodePos_le hq
        have hm1 : pa ≤ max pa pw := le_max_left _ _
        have hm2 : pw ≤ max pa pw := le_max_right _ _
        have IHa := RunAllO.pushInv (v := w) (δ := max pa pw - base) (ihE base env tape a va ca pa ta
          (q.child 0) (Frame.loopInit q :: K) ρ ha hqa hc'.2)
          (B' := addB prog (height (Expr.loop i a)) env (max pa pw - base) ρ) (by
            rw [frameBits_loopInit]
            exact addB_push_env env hha (by omega) (by unfold frameC; omega)) (by omega)
            (fun _ _ h => by simp at h)
        have IHl := RunAllO.weakenInv (δ' := max pa pw - base) (ihL base i va ta w cw pw tw q a K ρ hl hq hc'.1)
          (B' := addB prog (height (Expr.loop i a)) env (max pa pw - base) ρ)
          (loopB_le_addB env (by omega) (by omega)) (by omega)
        exact ((RunAllO.cons_step ((stepO_eval).trans (step_eval_loop hq))
          (start_inv hq env K tape _ _ _ _) IHa).snoc_step
          (stepO_ret_loopInit hq) IHl.first).trans IHl
    · intro base i v tape w cw pw tw q a K ρ hl hq hri
      obtain ⟨body, flag, v', cb, pb, tb, hbody, hb, hcase⟩ := (loopRunO_succ_iff orc prog).1 hl
      have hroot : exprAt prog ⟨i, []⟩ = some body := exprAt_root hbody
      have hDbody : height body ≤ progDepth prog := height_le_progDepth hbody
      have hcb : CalleesLt r (r i) body := (hR i body hbody).2
      have hpb : base + valSize v + valSize (Val.list [Val.int flag, v']) ≤ pb :=
        evalO_peak_ge orc prog n (base + valSize v) [v] tape body _ hb
      have hpair : valSize v' + 3 ≤ valSize (Val.list [Val.int flag, v']) := by
        simp only [valSize, listSize]; omega
      have hpos := encodePos_le hq
      -- the body runs under the `loopIter` frame, at the lower level `r i`
      have IHb := RunAllO.pushInv (v := w) (δ := pb - base) (ihE (base + valSize v) [v] tape body _ cb pb tb ⟨i, []⟩
        (Frame.loopIter q :: K) (r i) hb hroot hcb)
        (B' := loopB prog (pb - base) ρ) (by
          refine (Nat.add_le_add_right (addB_body (ρ := ρ) hDbody hri) _).trans ?_
          rw [frameBits_loopIter]
          have h1 : 2 * (progDepth prog + 1) * (pb - (base + valSize v) + valSize v) ≤
              2 * (progDepth prog + 1) * (pb - base) := Nat.mul_le_mul_left _ (by omega)
          unfold loopB frameC
          omega) (by omega) (fun _ _ h => by simp at h)
      rcases hcase with ⟨rfl, hr⟩ | ⟨hflag, w', cw', pw', tw', hl', hr⟩
      · simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, h3, h4⟩ := hr
        subst w pw tw
        refine IHb.snoc_step (stepO_ret_loopIter_stop hq) ⟨Within.top ?_, ?_, ?_⟩
        · rw [encodeCtrl_ret_length]
          have h1 := bitEncodeVal_length_le2 v'
          have h4 : 2 * valSize v' ≤ 2 * (progDepth prog + 1) * (pb - base) :=
            Nat.mul_le_mul (by omega) (by omega)
          unfold loopB
          omega
        · intro w p va K' _ h2 _
          simp only at h2
          have hl := congrArg List.length h2
          simp only [List.length_cons] at hl
          omega
        · intro _ w h1
          simp only [Ctrl.ret.injEq] at h1
          exact h1.symm
      · simp only [Prod.mk.injEq] at hr
        obtain ⟨h1, -, rfl, h4⟩ := hr
        subst w tw
        have IHl := RunAllO.weakenInv (δ' := max pb pw' - base) (ihL base i v' tb w' cw' pw' tw' q a K ρ hl' hq hri)
          (B' := loopB prog (max pb pw' - base) ρ) (loopB_mono (by omega)) (by omega)
        have IHb' := RunAllO.weakenInv (δ' := max pb pw' - base) IHb
          (B' := loopB prog (max pb pw' - base) ρ) (loopB_mono (by omega)) (by omega)
        exact (IHb'.snoc_step (stepO_ret_loopIter_cont hq hflag) IHl.first).trans IHl

end F2e2e.BSpace.O2B
