import F2e2e.BSpace.O2GlueMainBounds
import F2e2e.BSpace.RefineRound

/-!
# B_space, route O2b: the request input fits the top frame of `body_bsRound` (o2m)

Owner: C-FP (4683dd7f), for C-BANK (47a44866) and the O2b technical lead 17fc0802.

`o2m_inR` is the field `inR` of W4's `O2Inputs` (`F2e2e/BSpace/O2Assemble.lean`) at `mR := o2m_mR`
(`F2e2e/BSpace/O2GlueMainBounds.lean`): the request input `[params, state, kind]` (valid request kind,
state with `AdaOK`) has size at most `o2m_mR`. Proof: B-ACC's `bsT_valSize_roundIn_state`
(`F2e2e/BSpace/O2TightSizes.lean`) bounds the input by `o2mInpB`, a summand of the frame bound `o2mTopM`
(`o2m_inpB_le_topM`). The coefficient lemmas of `o2m_mR` / `o2m_τR` are O2B-SIZE's (`O2SizeCoef.lean`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- The round input bound is a summand of the frame bound: `o2mInpB ≤ o2mTopM`. -/
theorem o2m_inpB_le_topM (A : AdaParams) (bU Mc J R eA eXi : ℕ) :
    o2mInpB A bU Mc J R eA eXi ≤ o2mTopM A bU Mc J R eA eXi := by
  unfold o2mTopM
  omega

/-- **The request input fits the top frame** (`O2Inputs.inR` at `mR := o2m_mR`). -/
theorem o2m_inR : ∀ (M J R : ℕ) (aReq ξReq : ℝ), 0 < aReq → aReq < 1 / 10 → 0 < ξReq → ξReq < 1 / 2 →
    ∀ (U : Type) (bU : ℕ) (code : U → ℕ), (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (alg2Params M J R aReq ξReq).N → U) (k : ℤ), bitLen k ≤ 1 →
    ∀ (st : AdaState), C.Impl.AdaOK (asmParams M J R aReq ξReq) st →
      valSize (Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int k]) ≤ o2m_mR M J R aReq ξReq bU := by
  intro M J R aReq ξReq ha0 ha1 hξ0 hξ1 U bU code hcode s k hk st hok
  have hlen : (List.ofFn fun ℓ => code (s ℓ)).length = (asmParams M J R aReq ξReq).N := by
    rw [List.length_ofFn]
    exact refine_N M J R ha0 ha1 hξ0 hξ1
  have hc : ∀ x ∈ List.ofFn (fun ℓ => code (s ℓ)), x < 2 ^ bU := by
    intro x hx
    obtain ⟨ℓ, rfl⟩ := List.mem_ofFn.mp hx
    exact hcode (s ℓ)
  have h := bsT_valSize_roundIn_state (bsP_blockSizes_length _ _ _ _ _) hlen hc hok M J R (dyadicExp aReq)
    (dyadicExp ξReq) hk
  exact le_trans h (o2m_inpB_le_topM _ bU M J R (dyadicExp aReq) (dyadicExp ξReq))

end F2e2e.BSpace
