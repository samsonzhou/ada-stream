import F2e2e.BSpace.BoundParams

/-!
# O2b: the sharper bound `q_A ≤ 2χ` and its `adaZ`/`adaBoundA` corollaries (B-NUM)

Owner: B-NUM (b5a655d4), for the O2b track (tech lead 17fc0802). Prefix `o2c`.

B-NUM's `alg2HAExp_le` (`F2e2e/B/NumericsSize.lean`) gives `q_A ≤ 32χ` through the crude bounds
`max_j n_j ≤ 2^{8χ}`. Here, with `E = 2^χ ≥ arg = 2^40 (p+1) Q/(h ξ_A)` and `u = 1/h`:
* `E ≥ 2^38 u³` (`Q ≥ 100·3·T_0^max ≥ u²/4`) and `E ≥ 2^40 (J+R+1) u` (`Q ≥ J+R+1`);
* `χ³·2^30 ≤ E` (`χ ≥ 61`);
* the raw block bound `n_j ≤ 2^21 χ d_j √(C_j χ)/h + 2^12 χ/h² + 1` with `d_j ≤ 5u²`, `C_j ≤ 190u² + (J+R+1)`;
hence `2^20 max_j n_j ≤ E²` and `2^20 (p+1) χ/h ≤ E²`, i.e. `1/(h_A bound) ≤ 2^{2χ}` and `q_A ≤ 2χ`
(`o2c_alg2HAExp_le_two`). Corollaries (with `adaZ_le_of : adaZ ≤ 29 q_A + 80χ + 128`):
`o2c_adaZ_le : adaZ A ≤ 141χ` (instead of `1024χ`), `o2c_adaBoundA_le : adaBoundA A ≤ 2^10·(2N)·(141χ+16)`,
`o2c_adaBoundA_le' : adaBoundA A ≤ 2^19·N·χ` (instead of `2^22·N·χ`).
-/

namespace F2e2e.BSpace

open F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (adaZ adaBoundA maxKs noiseKinds)
open BoundAux

/-- `n³·2^30 ≤ 2^n` for `n ≥ 61`. -/
theorem o2c_cube_le_two_pow : ∀ n : ℕ, 61 ≤ n → n ^ 3 * 2 ^ 30 ≤ 2 ^ n := by
  intro n hn
  induction n, hn using Nat.le_induction with
  | base => norm_num
  | succ n hn ih =>
    have h2 : 61 * n ^ 2 ≤ n ^ 3 := by
      calc 61 * n ^ 2 ≤ n * n ^ 2 := Nat.mul_le_mul_right _ hn
        _ = n ^ 3 := by ring
    have h3 : n ≤ n ^ 2 := by nlinarith
    have h1 : (n + 1) ^ 3 ≤ 2 * n ^ 3 := by
      have e : (n + 1) ^ 3 = n ^ 3 + 3 * n ^ 2 + 3 * n + 1 := by ring
      rw [e]
      omega
    calc (n + 1) ^ 3 * 2 ^ 30 ≤ 2 * n ^ 3 * 2 ^ 30 := Nat.mul_le_mul_right _ h1
      _ = 2 * (n ^ 3 * 2 ^ 30) := by ring
      _ ≤ 2 * 2 ^ n := Nat.mul_le_mul_left _ ih
      _ = 2 ^ (n + 1) := by ring

/-- **The algebraic core**: with `E ≥ 2^38 u³`, `E ≥ 2^40 K u`, `X³·2^30 ≤ E`, `D ≤ 5u²`, `C ≤ 190u² + K`,
the raw block bound satisfies `2^20 (2^21 X D √(C X) u + 2^12 X u² + 1) ≤ E²`. -/
theorem o2c_core {E u X K D C : ℝ} (hu1 : 1 ≤ u) (hX1 : 1 ≤ X) (hK0 : 0 ≤ K) (hD0 : 0 ≤ D) (hC0 : 0 ≤ C)
    (hE38 : 2 ^ 38 * u ^ 3 ≤ E) (hEK : 2 ^ 40 * K * u ≤ E) (hcube : X ^ 3 * 2 ^ 30 ≤ E)
    (hD : D ≤ 5 * u ^ 2) (hC : C ≤ 190 * u ^ 2 + K) :
    2 ^ 20 * (2 ^ 21 * X * D * Real.sqrt (C * X) * u + 2 ^ 12 * X * u ^ 2 + 1) ≤ E ^ 2 := by
  have hu0 : 0 ≤ u := by linarith
  have hX0 : 0 ≤ X := by linarith
  have hu3pos : 1 ≤ u ^ 3 := one_le_pow₀ hu1
  have hE0 : 0 < E := by nlinarith
  have hu3 : u ^ 3 ≤ E / 2 ^ 38 := by rw [le_div_iff₀ (by norm_num)]; linarith
  have hX3 : X ^ 3 ≤ E / 2 ^ 30 := by rw [le_div_iff₀ (by norm_num)]; linarith
  have hKu : K * u ≤ E / 2 ^ 40 := by rw [le_div_iff₀ (by norm_num)]; linarith
  have hu8 : u ^ 8 ≤ (E / 2 ^ 38) ^ 3 :=
    calc u ^ 8 ≤ u ^ 9 := pow_le_pow_right₀ hu1 (by norm_num)
      _ = (u ^ 3) ^ 3 := by ring
      _ ≤ (E / 2 ^ 38) ^ 3 := pow_le_pow_left₀ (by positivity) hu3 3
  have hu5 : u ^ 5 ≤ (E / 2 ^ 38) ^ 2 :=
    calc u ^ 5 ≤ u ^ 6 := pow_le_pow_right₀ hu1 (by norm_num)
      _ = (u ^ 3) ^ 2 := by ring
      _ ≤ (E / 2 ^ 38) ^ 2 := pow_le_pow_left₀ (by positivity) hu3 2
  have hD2 : D ^ 2 ≤ 25 * u ^ 4 :=
    calc D ^ 2 ≤ (5 * u ^ 2) ^ 2 := pow_le_pow_left₀ hD0 hD 2
      _ = 25 * u ^ 4 := by ring
  -- the main term, through its square
  have hS0 : 0 ≤ 2 ^ 21 * X * D * Real.sqrt (C * X) * u := by positivity
  have hsq : Real.sqrt (C * X) ^ 2 = C * X := Real.sq_sqrt (by positivity)
  have hS2 : (2 ^ 21 * X * D * Real.sqrt (C * X) * u) ^ 2 ≤ (E ^ 2 / 2 ^ 44) ^ 2 := by
    have e1 : (2 ^ 21 * X * D * Real.sqrt (C * X) * u) ^ 2 =
        2 ^ 42 * X ^ 2 * D ^ 2 * Real.sqrt (C * X) ^ 2 * u ^ 2 := by ring
    rw [hsq] at e1
    have hCX : C * X ≤ (190 * u ^ 2 + K) * X := mul_le_mul_of_nonneg_right hC hX0
    calc (2 ^ 21 * X * D * Real.sqrt (C * X) * u) ^ 2
        = 2 ^ 42 * X ^ 2 * D ^ 2 * (C * X) * u ^ 2 := e1
      _ ≤ 2 ^ 42 * X ^ 2 * (25 * u ^ 4) * ((190 * u ^ 2 + K) * X) * u ^ 2 := by gcongr
      _ = 2 ^ 42 * 25 * X ^ 3 * (190 * u ^ 8 + (K * u) * u ^ 5) := by ring
      _ ≤ 2 ^ 42 * 25 * (E / 2 ^ 30) * (190 * (E / 2 ^ 38) ^ 3 + (E / 2 ^ 40) * (E / 2 ^ 38) ^ 2) := by
          gcongr
      _ = E ^ 4 * (2 ^ 42 * 25 * (190 / 2 ^ 144 + 1 / 2 ^ 146)) := by ring
      _ ≤ E ^ 4 * (1 / 2 ^ 88) := by
          gcongr
          norm_num
      _ = (E ^ 2 / 2 ^ 44) ^ 2 := by ring
  have hS : 2 ^ 21 * X * D * Real.sqrt (C * X) * u ≤ E ^ 2 / 2 ^ 44 :=
    (pow_le_pow_iff_left₀ hS0 (by positivity) (by norm_num)).mp hS2
  -- the second term
  have hY : 2 ^ 12 * X * u ^ 2 ≤ E ^ 2 / 2 ^ 56 := by
    have h1 : X ≤ X ^ 3 :=
      calc X = X ^ 1 := (pow_one X).symm
        _ ≤ X ^ 3 := pow_le_pow_right₀ hX1 (by norm_num)
    have h2 : u ^ 2 ≤ u ^ 3 := pow_le_pow_right₀ hu1 (by norm_num)
    calc 2 ^ 12 * X * u ^ 2 ≤ 2 ^ 12 * X ^ 3 * u ^ 3 := by gcongr
      _ ≤ 2 ^ 12 * (E / 2 ^ 30) * (E / 2 ^ 38) := by gcongr
      _ = E ^ 2 / 2 ^ 56 := by ring
  have hE38' : (2 : ℝ) ^ 38 ≤ E := by nlinarith
  have h1E : (1 : ℝ) ≤ E ^ 2 / 2 ^ 76 := by
    rw [le_div_iff₀ (by norm_num), one_mul]
    calc (2 : ℝ) ^ 76 = (2 ^ 38) ^ 2 := by norm_num
      _ ≤ E ^ 2 := pow_le_pow_left₀ (by norm_num) hE38' 2
  have hE2 : 0 ≤ E ^ 2 := by positivity
  calc 2 ^ 20 * (2 ^ 21 * X * D * Real.sqrt (C * X) * u + 2 ^ 12 * X * u ^ 2 + 1)
      ≤ 2 ^ 20 * (E ^ 2 / 2 ^ 44 + E ^ 2 / 2 ^ 56 + E ^ 2 / 2 ^ 76) := by gcongr
    _ ≤ E ^ 2 := by
        have : 2 ^ 20 * (E ^ 2 / 2 ^ 44 + E ^ 2 / 2 ^ 56 + E ^ 2 / 2 ^ 76) =
            E ^ 2 * (2 ^ 20 * (1 / 2 ^ 44 + 1 / 2 ^ 56 + 1 / 2 ^ 76)) := by ring
        rw [this]
        calc E ^ 2 * (2 ^ 20 * (1 / 2 ^ 44 + 1 / 2 ^ 56 + 1 / 2 ^ 76)) ≤ E ^ 2 * 1 := by
              gcongr
              norm_num
          _ = E ^ 2 := by ring

/-- **`q_A ≤ 2χ`** (B-NUM's `alg2HAExp_le` gives `32χ`). -/
theorem o2c_alg2HAExp_le_two (M J R : ℕ) (aReq ξReq : ℝ) :
    alg2HAExp M J R aReq ξReq ≤ 2 * alg2Chi M J R aReq ξReq := by
  set E := (2 : ℝ) ^ alg2Chi M J R aReq ξReq with hE
  have hχ61 : 60 < alg2Chi M J R aReq ξReq :=
    sixty_lt_valChi M J R (alg2A_pos aReq) (alg2A_le_one aReq) (alg2XiA_pos ξReq)
      (alg2XiA_le_one ξReq)
  have hcube : (alg2Chi M J R aReq ξReq : ℝ) ^ 3 * 2 ^ 30 ≤ E := by
    have h := o2c_cube_le_two_pow (alg2Chi M J R aReq ξReq) hχ61
    rw [hE]
    exact_mod_cast h
  have hX1 : (1 : ℝ) ≤ alg2Chi M J R aReq ξReq := one_le_alg2Chi_real M J R aReq ξReq
  have hh := alg2H_pos aReq
  have hh0 : alg2H aReq ≠ 0 := ne_of_gt hh
  have hh1 := alg2H_le_one aReq
  have hu1 : (1 : ℝ) ≤ 1 / alg2H aReq := by rw [le_div_iff₀ hh]; linarith
  have hξ := alg2XiA_pos ξReq
  have hξ1 := alg2XiA_le_one ξReq
  have hp0 : (0 : ℝ) ≤ alg2P aReq := Nat.cast_nonneg _
  have hQ0 := alg2Q_pos_real M J R aReq
  -- `E ≥ arg ≥ 2^40 Q u`
  have harg : chiArg M J R (alg2A aReq) (alg2XiA ξReq) ≤ E :=
    chiArg_le_two_pow_valChi M J R (alg2A_pos aReq) (alg2XiA_pos ξReq)
  have hargQ : 2 ^ 40 * (alg2Q M J R aReq : ℝ) * (1 / alg2H aReq) ≤ E := by
    refine le_trans ?_ harg
    unfold chiArg
    change 2 ^ 40 * (alg2Q M J R aReq : ℝ) * (1 / alg2H aReq) ≤
      2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) / (alg2H aReq * alg2XiA ξReq)
    rw [le_div_iff₀ (by positivity)]
    have e : 2 ^ 40 * (alg2Q M J R aReq : ℝ) * (1 / alg2H aReq) * (alg2H aReq * alg2XiA ξReq) =
        2 ^ 40 * ((alg2Q M J R aReq : ℝ) * alg2XiA ξReq) := by
      field_simp
    rw [e]
    have h1 : (alg2Q M J R aReq : ℝ) * alg2XiA ξReq ≤ (alg2Q M J R aReq : ℝ) * 1 :=
      mul_le_mul_of_nonneg_left hξ1 hQ0.le
    have h2 : (alg2Q M J R aReq : ℝ) * 1 ≤ ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) := by
      nlinarith
    have h3 : (0 : ℝ) ≤ 2 ^ 40 := by positivity
    calc 2 ^ 40 * ((alg2Q M J R aReq : ℝ) * alg2XiA ξReq)
        ≤ 2 ^ 40 * (((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ)) :=
          mul_le_mul_of_nonneg_left (h1.trans h2) h3
      _ = 2 ^ 40 * ((alg2P aReq : ℝ) + 1) * (alg2Q M J R aReq : ℝ) := by ring
  -- `Q ≥ u²/4` and `Q ≥ J + R + 1`
  have hc := valQ_cast M J R (alg2A aReq)
  change (alg2Q M J R aReq : ℝ) = _ at hc
  have hsum0 : (0 : ℝ) ≤ ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ) :=
    Finset.sum_nonneg (fun _ _ => Nat.cast_nonneg _)
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  have hJ0 : (0 : ℝ) ≤ J := Nat.cast_nonneg _
  have hR0 : (0 : ℝ) ≤ R := Nat.cast_nonneg _
  have hp2r := two_le_alg2P_real aReq
  have hpp : (300 : ℝ) ≤ 100 * ((valP (alg2A aReq) : ℝ) + 1) := by
    have : (2 : ℝ) ≤ (valP (alg2A aReq) : ℝ) := hp2r
    linarith
  have hQK : (J : ℝ) + R + 1 ≤ (alg2Q M J R aReq : ℝ) := by
    rw [hc]
    nlinarith
  have hτ := alg2Tau_pos aReq
  have hut : 1 / alg2H aReq = 64 / alg2Tau aReq := by
    rw [alg2H_eq_tau]
    field_simp
  have hQu : (1 / alg2H aReq) ^ 2 / 4 ≤ (alg2Q M J R aReq : ℝ) := by
    have hT0 : (6 : ℝ) / alg2Tau aReq ^ 2 ≤ (valTmax (alg2A aReq) 0 : ℝ) := by
      have := le_valTmax (alg2A aReq) 0
      rw [pow_zero, one_mul] at this
      exact this
    have hsum : (valTmax (alg2A aReq) 0 : ℝ) ≤
        ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ) := by
      have hp2 := two_le_alg2P aReq
      exact Finset.single_le_sum (f := fun j => (valTmax (alg2A aReq) j : ℝ))
        (fun _ _ => Nat.cast_nonneg _) (Finset.mem_range.mpr (by change 0 < alg2P aReq; omega))
    have hS : (6 : ℝ) / alg2Tau aReq ^ 2 ≤ (M : ℝ) + R + J + 2 +
        ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ) := by linarith
    have hS0 : (0 : ℝ) ≤ 6 / alg2Tau aReq ^ 2 := by positivity
    rw [hc, hut]
    calc (64 / alg2Tau aReq) ^ 2 / 4 = 1024 / alg2Tau aReq ^ 2 := by ring
      _ ≤ 300 * 6 / alg2Tau aReq ^ 2 :=
          div_le_div_of_nonneg_right (by norm_num) (by positivity)
      _ = 300 * (6 / alg2Tau aReq ^ 2) := by ring
      _ ≤ 100 * ((valP (alg2A aReq) : ℝ) + 1) * ((M : ℝ) + R + J + 2 +
          ∑ j ∈ Finset.range (valP (alg2A aReq)), (valTmax (alg2A aReq) j : ℝ)) :=
          mul_le_mul hpp hS hS0 (by positivity)
  have hu0 : (0 : ℝ) ≤ 1 / alg2H aReq := by positivity
  have hE38 : 2 ^ 38 * (1 / alg2H aReq) ^ 3 ≤ E := by
    have h1 : 2 ^ 40 * ((1 / alg2H aReq) ^ 2 / 4) * (1 / alg2H aReq) ≤
        2 ^ 40 * (alg2Q M J R aReq : ℝ) * (1 / alg2H aReq) := by gcongr
    have e : 2 ^ 40 * ((1 / alg2H aReq) ^ 2 / 4) * (1 / alg2H aReq) = 2 ^ 38 * (1 / alg2H aReq) ^ 3 := by
      ring
    linarith
  have hEK : 2 ^ 40 * ((J : ℝ) + R + 1) * (1 / alg2H aReq) ≤ E := by
    have h1 : 2 ^ 40 * ((J : ℝ) + R + 1) * (1 / alg2H aReq) ≤
        2 ^ 40 * (alg2Q M J R aReq : ℝ) * (1 / alg2H aReq) := by gcongr
    linarith
  -- `1/bound ≤ 2^{2χ}`
  have hinv : (alg2HABound M J R aReq ξReq)⁻¹ ≤ (2 : ℝ) ^ (2 * alg2Chi M J R aReq ξReq) := by
    have hE2 : (2 : ℝ) ^ (2 * alg2Chi M J R aReq ξReq) = E ^ 2 := by
      rw [hE, ← pow_mul, Nat.mul_comm]
    rw [hE2]
    have hpos1 := alg2HABound_first_pos M J R aReq ξReq
    have hmax1 : (1 : ℝ) ≤ alg2MaxN M J R aReq ξReq := by
      exact_mod_cast one_le_alg2MaxN M J R aReq ξReq
    have hpos2 : 0 < 1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)) := by positivity
    unfold alg2HABound
    rcases le_total (alg2H aReq / ((2 : ℝ) ^ 20 * ((alg2P aReq : ℝ) + 1) *
        (alg2Chi M J R aReq ξReq : ℝ))) (1 / ((2 : ℝ) ^ 20 * (alg2MaxN M J R aReq ξReq : ℝ)))
      with hle | hle
    · rw [min_eq_left hle, inv_div]
      have hp : (alg2P aReq : ℝ) + 1 ≤ 2 * (1 / alg2H aReq) := by
        have hih := one_div_alg2H aReq
        have ha := alg2A_pos aReq
        have ha1 := alg2A_le_one aReq
        rw [hih, mul_div_assoc', le_div_iff₀ ha]
        nlinarith
      have hX3 : (alg2Chi M J R aReq ξReq : ℝ) ≤ (alg2Chi M J R aReq ξReq : ℝ) ^ 3 :=
        calc (alg2Chi M J R aReq ξReq : ℝ) = (alg2Chi M J R aReq ξReq : ℝ) ^ 1 := (pow_one _).symm
          _ ≤ (alg2Chi M J R aReq ξReq : ℝ) ^ 3 := pow_le_pow_right₀ hX1 (by norm_num)
      have hu23 : (1 / alg2H aReq) ^ 2 ≤ (1 / alg2H aReq) ^ 3 := pow_le_pow_right₀ hu1 (by norm_num)
      have hX0 : (0 : ℝ) ≤ alg2Chi M J R aReq ξReq := by linarith
      have hE0 : 0 < E := by positivity
      calc 2 ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq
          = 2 ^ 20 * ((alg2P aReq : ℝ) + 1) * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) := by
            ring
        _ ≤ 2 ^ 20 * (2 * (1 / alg2H aReq)) * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) := by
            gcongr
        _ = 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) ^ 2 := by ring
        _ ≤ 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) ^ 3 * (1 / alg2H aReq) ^ 3 := by gcongr
        _ = 2 ^ (-9 : ℤ) * ((alg2Chi M J R aReq ξReq : ℝ) ^ 3 * 2 ^ 30) * (2 ^ 38 * (1 / alg2H aReq) ^ 3) /
              2 ^ 38 := by
            rw [zpow_neg, zpow_ofNat]
            field_simp
        _ ≤ 2 ^ (-9 : ℤ) * E * E / 2 ^ 38 := by gcongr
        _ ≤ E ^ 2 := by
            rw [zpow_neg, zpow_ofNat]
            have : (2 : ℝ) ^ 9 * 2 ^ 38 ≥ 1 := by norm_num
            rw [div_le_iff₀ (by positivity)]
            have hEE : 0 ≤ E * E := by positivity
            calc ((2 : ℝ) ^ 9)⁻¹ * E * E = (E * E) / 2 ^ 9 := by ring
              _ ≤ E * E := div_le_self hEE (by norm_num)
              _ ≤ E ^ 2 * 2 ^ 38 := by nlinarith
    · rw [min_eq_right hle, one_div, inv_inv]
      obtain ⟨j, hjmem, hjeq⟩ := Finset.exists_mem_eq_sup (Finset.range (alg2P aReq + 1))
        ⟨0, Finset.mem_range.mpr (Nat.succ_pos _)⟩ (alg2NBlock M J R aReq ξReq)
      have hj : j ≤ alg2P aReq := Nat.lt_succ_iff.mp (Finset.mem_range.mp hjmem)
      have hmaxeq : (alg2MaxN M J R aReq ξReq : ℝ) = (alg2NBlock M J R aReq ξReq j : ℝ) := by
        unfold alg2MaxN
        rw [hjeq]
      rw [hmaxeq]
      have hraw := alg2NBlock_le_raw M J R aReq ξReq hj
      have e1 : 2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
          Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) / alg2H aReq +
          2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) / alg2H aReq ^ 2 + 1 =
          2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
          Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq) +
          2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) ^ 2 + 1 := by
        field_simp
      rw [e1] at hraw
      have hcore := o2c_core hu1 hX1 (by positivity : (0 : ℝ) ≤ (J : ℝ) + R + 1)
        (Nat.cast_nonneg (alg2D aReq j)) (Nat.cast_nonneg (alg2C J R aReq j)) hE38 hEK hcube
        (alg2D_le_inv_h_sq aReq j) (alg2C_le_inv_h_sq J R aReq hj)
      calc 2 ^ 20 * (alg2NBlock M J R aReq ξReq j : ℝ)
          ≤ 2 ^ 20 * (2 ^ 21 * (alg2Chi M J R aReq ξReq : ℝ) * (alg2D aReq j : ℝ) *
            Real.sqrt ((alg2C J R aReq j : ℝ) * (alg2Chi M J R aReq ξReq : ℝ)) * (1 / alg2H aReq) +
            2 ^ 12 * (alg2Chi M J R aReq ξReq : ℝ) * (1 / alg2H aReq) ^ 2 + 1) := by gcongr
        _ ≤ E ^ 2 := hcore
  -- `q_A = clog₂ ⌈1/bound⌉ ≤ 2χ`
  show Nat.clog 2 ⌈(alg2HABound M J R aReq ξReq)⁻¹⌉₊ ≤ 2 * alg2Chi M J R aReq ξReq
  apply Nat.clog_le_of_le_pow
  apply Nat.ceil_le.mpr
  have : ((2 ^ (2 * alg2Chi M J R aReq ξReq) : ℕ) : ℝ) = (2 : ℝ) ^ (2 * alg2Chi M J R aReq ξReq) := by
    push_cast
    rfl
  rw [this]
  exact hinv

/-- **`adaZ A ≤ 141 χ`** (instead of `bs_adaZ_le : adaZ A ≤ 1024 χ`). -/
theorem o2c_adaZ_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaZ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      141 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  have h4 : 4 ≤ F2e2e.dyadicExp aReq := four_le_dyadicExp ha0 (by linarith)
  have hZ := adaZ_le_of M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) h4
  have hq : adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      2 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
    rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1]
    exact o2c_alg2HAExp_le_two M J R aReq ξReq
  have hχ := bs_chi_eq M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  rw [← hχ] at hZ
  omega

/-- `adaBoundA A ≤ 2^10 · (2N) · (141 χ + 16)`. -/
theorem o2c_adaBoundA_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      2 ^ 10 * (2 * (F2e2e.alg2Params M J R aReq ξReq).N) *
        (141 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 16) := by
  have hZ := o2c_adaZ_le M J R ha0 ha1 hξ0 hξ1
  have hN := bs_N_add_le M J R ha0 ha1 hξ0 hξ1
  unfold adaBoundA
  exact Nat.mul_le_mul (Nat.mul_le_mul_left _ hN) (by omega)

/-- **`adaBoundA A ≤ 2^19 · N · χ`** (instead of `bs_adaBoundA_le' : ≤ 2^22 · N · χ`). -/
theorem o2c_adaBoundA_le' (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      2 ^ 19 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  have h := o2c_adaBoundA_le M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  refine h.trans ?_
  set N := (F2e2e.alg2Params M J R aReq ξReq).N
  set χ := F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)
  have h1 : 141 * χ + 16 ≤ 142 * χ := by omega
  calc 2 ^ 10 * (2 * N) * (141 * χ + 16) ≤ 2 ^ 10 * (2 * N) * (142 * χ) :=
        Nat.mul_le_mul_left _ h1
    _ = 2 ^ 11 * 142 * N * χ := by ring
    _ ≤ 2 ^ 19 * N * χ := by
        have : 2 ^ 11 * 142 ≤ 2 ^ 19 := by norm_num
        exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ this)

end F2e2e.BSpace
