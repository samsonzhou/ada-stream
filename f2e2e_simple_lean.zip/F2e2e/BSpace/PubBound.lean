import F2e2e.BSpace.Pub
import F2e2e.C.Impl.AdaBounds

/-!
# B_space, layer P: the quadratic parameter-record bound is below W4's value bound

Owner: W3 (4a7299ed), for W2 (a2ff64c3) / B-ARCH (S3 (iii)).

`bsPubBound_le`: `bsPubBound Mc J R eA eXi = 2^20 · L² ≤ 2^32 · adaBoundA A` (`bsPubBound_le_sq`) for
`A = adaParams eA eXi Mc J R` and
`L = bsPubL Mc J R eA eXi = eA + eXi + ⌈log₂(Mc+J+R+2)⌉ + 100`. Both factors of
`adaBoundA A = 2^10 (N + p + 16)(adaZ A + 16)` dominate `L` linearly:

* `bsB_L_le_adaZ`: `L ≤ adaZ A + 54`, since `adaZ A ≥ q_A + size(M+J+R+2) + size(ζ.den) + 16` with
  `q_A ≥ 29 + eA`, `size n ≥ ⌈log₂ n⌉` and `ζ.den = zdQ ≥ 2^{eXi}` (`ζ = 1/zdQ`, `adaZeta_eq`);
* `bsB_L_le_N`: `L ≤ N + 51`, since `N ≥ n_0 ≥ 2^12 χ h⁻² ≥ χ` and
  `χ = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉ ≥ L − 51` (`p(p+1)Q ≥ Q ≥ Mc+J+R+2`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.C.Impl F2e2e.C.Impl.AP

/-- `⌈log₂ n⌉ ≤ size n`. -/
theorem bsB_clog_le_size (n : ℕ) : Nat.clog 2 n ≤ Nat.size n :=
  Nat.clog_le_of_le_pow (Nat.lt_size_self n).le

/-- `2^{eXi} ≤ zdQ` (the denominator of `ζ`). -/
theorem bsB_two_pow_le_zdQ (Mc J R eA eXi : ℕ) : 2 ^ eXi ≤ zdQ Mc J R eA eXi := by
  have hp := two_le_adaP eA
  have hQ := adaQ_pos Mc J R eA
  have hc : 0 < 98304000 * adaP eA * (adaP eA + 1) * adaQ Mc J R eA :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (by omega)) hQ
  unfold zdQ
  calc 2 ^ eXi ≤ 2 ^ eA * 2 ^ eXi := Nat.le_mul_of_pos_left _ (by positivity)
    _ ≤ 98304000 * adaP eA * (adaP eA + 1) * adaQ Mc J R eA * (2 ^ eA * 2 ^ eXi) :=
      Nat.le_mul_of_pos_left _ hc

/-- **`L ≤ adaZ A + 54`.** -/
theorem bsB_L_le_adaZ (Mc J R eA eXi : ℕ) :
    bsPubL Mc J R eA eXi ≤ adaZ (adaParams eA eXi Mc J R) + 54 := by
  have hz := adaZ_eq (adaParams eA eXi Mc J R)
  have hqA : 29 + eA ≤ (adaParams eA eXi Mc J R).qA := by
    show 29 + eA ≤ adaQA Mc J R eA eXi
    unfold adaQA
    exact le_trans (Nat.le_add_right _ _) (le_max_left _ _)
  have hcl : Nat.clog 2 (Mc + J + R + 2) ≤ Nat.size ((adaParams eA eXi Mc J R).M +
      (adaParams eA eXi Mc J R).J + (adaParams eA eXi Mc J R).R + 2) :=
    bsB_clog_le_size (Mc + J + R + 2)
  have hden : (adaParams eA eXi Mc J R).zeta.den = zdQ Mc J R eA eXi := by
    show (adaZeta Mc J R eA eXi).den = zdQ Mc J R eA eXi
    rw [adaZeta_eq, one_div]
    exact Rat.inv_natCast_den_of_pos (zdQ_pos Mc J R eA eXi)
  have hsz : eXi + 1 ≤ Nat.size (adaParams eA eXi Mc J R).zeta.den := by
    rw [hden, ← Nat.size_pow]
    exact Nat.size_le_size (bsB_two_pow_le_zdQ Mc J R eA eXi)
  unfold bsPubL
  omega

/-- **`L ≤ N + 51`.** -/
theorem bsB_L_le_N (Mc J R eA eXi : ℕ) :
    bsPubL Mc J R eA eXi ≤ (adaParams eA eXi Mc J R).N + 51 := by
  have hp := two_le_adaP eA
  have hQ : Mc + J + R + 2 ≤ adaQ Mc J R eA := by
    unfold adaQ
    calc Mc + J + R + 2 ≤ Mc + R + J + 2 + (adaTmaxList eA).sum := by omega
      _ ≤ 100 * (adaP eA + 1) * (Mc + R + J + 2 + (adaTmaxList eA).sum) :=
        Nat.le_mul_of_pos_left _ (by omega)
  have hpQ : adaQ Mc J R eA ≤ adaP eA * (adaP eA + 1) * adaQ Mc J R eA :=
    Nat.le_mul_of_pos_left _ (Nat.mul_pos (by omega) (by omega))
  have hcl : Nat.clog 2 (Mc + J + R + 2) ≤
      Nat.clog 2 (adaP eA * (adaP eA + 1) * adaQ Mc J R eA) :=
    Nat.clog_mono_right 2 (hQ.trans hpQ)
  have hchi : bsPubL Mc J R eA eXi ≤ adaChi Mc J R eA eXi + 51 := by
    unfold bsPubL adaChi
    omega
  have hH : 0 < adaHInv eA := by
    unfold adaHInv
    exact Nat.mul_pos (Nat.mul_pos (by norm_num) (by omega)) (by positivity)
  have hn0 : adaChi Mc J R eA eXi ≤ adaNBlock Mc J R eA eXi 0 := by
    unfold adaNBlock
    calc adaChi Mc J R eA eXi ≤ 2 ^ 12 * adaChi Mc J R eA eXi :=
          Nat.le_mul_of_pos_left _ (by norm_num)
      _ ≤ 2 ^ 12 * adaChi Mc J R eA eXi * adaHInv eA ^ 2 :=
          Nat.le_mul_of_pos_right _ (by positivity)
      _ ≤ _ := Nat.le_add_left _ _
  have hmem : adaNBlock Mc J R eA eXi 0 ∈ adaBlockSizes Mc J R eA eXi := by
    unfold adaBlockSizes
    exact List.mem_map.mpr ⟨0, List.mem_range.mpr (by omega), rfl⟩
  have hsum : adaNBlock Mc J R eA eXi 0 ≤ (adaBlockSizes Mc J R eA eXi).sum :=
    List.le_sum_of_mem hmem
  show bsPubL Mc J R eA eXi ≤ (adaBlockSizes Mc J R eA eXi).sum + 51
  omega

/-- The quadratic record bound is below W4's value bound, explicitly:
`2^20 · bsPubL² ≤ 2^32 · adaBoundA (adaParams eA eXi Mc J R)`. -/
theorem bsPubBound_le_sq {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) :
    2 ^ 20 * bsPubL Mc J R eA eXi ^ 2 ≤ 2 ^ 32 * adaBoundA (adaParams eA eXi Mc J R) := by
  have _h4 := h4
  have _h2 := h2
  have hZ := bsB_L_le_adaZ Mc J R eA eXi
  have hN := bsB_L_le_N Mc J R eA eXi
  have hZ16 := sixteen_le_adaZ (adaParams eA eXi Mc J R)
  unfold adaBoundA
  generalize bsPubL Mc J R eA eXi = L at hZ hN ⊢
  generalize adaZ (adaParams eA eXi Mc J R) = Z at hZ hZ16 ⊢
  generalize (adaParams eA eXi Mc J R).N = N at hN ⊢
  generalize (adaParams eA eXi Mc J R).p = p
  have h1 : L ≤ 4 * (Z + 16) := by omega
  have h2' : L ≤ 4 * (N + p + 16) := by omega
  have hL2 : L ^ 2 ≤ 16 * ((N + p + 16) * (Z + 16)) := by
    calc L ^ 2 = L * L := by ring
      _ ≤ (4 * (N + p + 16)) * (4 * (Z + 16)) := Nat.mul_le_mul h2' h1
      _ = 16 * ((N + p + 16) * (Z + 16)) := by ring
  calc 2 ^ 20 * L ^ 2 ≤ 2 ^ 20 * (16 * ((N + p + 16) * (Z + 16))) := Nat.mul_le_mul_left _ hL2
    _ = 2 ^ 24 * ((N + p + 16) * (Z + 16)) := by ring
    _ ≤ 2 ^ 42 * ((N + p + 16) * (Z + 16)) := Nat.mul_le_mul_right _ (by norm_num)
    _ = 2 ^ 32 * (2 ^ 10 * (N + p + 16) * (Z + 16)) := by ring

/-- **The parameter record's value bound is below W4's value bound** (B-ARCH's S3 (iii)):
`bsPubBound Mc J R eA eXi ≤ 2^32 · adaBoundA (adaParams eA eXi Mc J R)`. -/
theorem bsPubBound_le {Mc J R eA eXi : ℕ} (h4 : 4 ≤ eA) (h2 : 2 ≤ eXi) :
    bsPubBound Mc J R eA eXi ≤ 2 ^ 32 * adaBoundA (adaParams eA eXi Mc J R) := by
  show 2 ^ 20 * bsPubL Mc J R eA eXi ^ 2 ≤ _
  exact bsPubBound_le_sq h4 h2

end F2e2e.BSpace
