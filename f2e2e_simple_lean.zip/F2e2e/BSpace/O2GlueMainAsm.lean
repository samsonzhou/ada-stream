import F2e2e.BSpace.O2GlueMain
import F2e2e.BSpace.O2GlueMainSpecs
import F2e2e.BSpace.O2GlueMainBounds
import F2e2e.BSpace.O2GlueMainCallees
import F2e2e.BSpace.O2GstAsmB
import F2e2e.BSpace.DslMainReq
import F2e2e.BSpace.RefineRound

/-!
# B_space, route O2b: the top frame of the round program, P5 the assembly-level statement (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802 (statement list approved 14:10Z).

`o2m_implR_of`: the field `implR` of W4's `O2Inputs` (`F2e2e/BSpace/O2Assemble.lean`) for `mR := o2m_mR`,
`τR := o2m_τR` (`F2e2e/BSpace/O2GlueMainBounds.lean`), given the tight specs of the two ADA entries on the round
program as hypotheses (`O2mIvTightSpec`, `O2mNumTightSpec`: the callee rule of the O2b families 5 and 7, i.e.
`adaInterval_impl` / `adaNumerical_impl_of` with `TightM A M` for `2^32 · adaBoundA A ≤ M`, table premises
discharged). Proof: P4 (`o2m_roundF`) on `bsRoundProg` with the request oracle, the five callees in their own
frames from the weighted liftings with O2B-GST's certificate `bsWeightOK_round` (weights `bsW_vals`), the request
data (O2P-2's `o2m_reqData`, from W3's `DslMainReq`), and the frame-bound / budget inequalities.
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2 F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.C.Alg F2e2e.C.Impl

/-! ## The request data (O2P-2's `o2m_reqData`) -/

/-- **The request data** of a valid request on the stored blocks of a sample (O2P-2, from W3's
`F2e2e/BSpace/DslMainReq.lean`): the oracle ranges of D2 and D3, the query table, and the endpoints. -/
theorem o2m_reqData (A : AdaParams) {U : Type} {code : U → ℕ} (hinj : Function.Injective code) {N : ℕ}
    (s : Fin N → U) (hN : N = A.N) {req : VReq U} (hreq : req.Valid) :
    (∀ blk ∈ asmBlocks A code s, ∀ r ∈ blk, 0 ≤ reqOracle code req 0 (r : ℤ) ((A.qA : ℤ) + 1) ∧
        reqOracle code req 0 (r : ℤ) ((A.qA : ℤ) + 1) ≤ 2 ^ (A.qA + 1)) ∧
      (|reqOracle code req 1 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2) ∧
        |reqOracle code req 2 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2)) ∧
      evalsOf (reqOracle code req) A.qA (asmBlocks A code s) = coreVals A (V2.castSample hN s) (quantReq A req) ∧
      bsN_end A.qA (reqOracle code req 1 0 ((A.qA : ℤ) + 1)) = (quantReq A req).l ∧
      bsN_end A.qA (reqOracle code req 2 0 ((A.qA : ℤ) + 1)) = (quantReq A req).u := by
  refine ⟨fun _ _ r _ => bsE_reqOracle_mem code hreq (r : ℤ) _, ?_, bsR_evalsOf_eq A hinj s hN hreq,
    (bsR_ends_eq A code req).1, (bsR_ends_eq A code req).2⟩
  rw [bsR_reqOracle_one, bsR_reqOracle_two]
  exact ⟨bsN_trunc_abs_le _ _, bsN_trunc_abs_le _ _⟩

/-! ## The frame bound and the budget (O2P-2, 8e515073) -/

/-! ### Shared facts -/

/-- The codes of a sample are `< 2^{b_𝒰}`. -/
theorem o2m_codes_lt {U : Type} {bU : ℕ} {code : U → ℕ} (hcode : ∀ x, code x < 2 ^ bU) {N : ℕ}
    (s : Fin N → U) : ∀ x ∈ List.ofFn (fun ℓ => code (s ℓ)), x < 2 ^ bU := by
  intro x hx
  obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hx
  exact hcode (s i)

/-- The query table of the stored blocks is well formed (D2's range of the oracle on the stored codes). -/
theorem o2m_valsOKA_split {orc : ℤ → ℤ → ℤ → ℤ} {A : AdaParams} {codes : List ℕ}
    (hlen : codes.length = A.N)
    (horc0 : ∀ blk ∈ splitBlocks A.blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ∧ orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ≤ 2 ^ (A.qA + 1)) :
    ValsOKA A (evalsOf orc A.qA (splitBlocks A.blockSizes codes)) :=
  ⟨by rw [evalsOf_map_length, bsB_splitBlocks_length A.blockSizes codes (le_of_eq hlen.symm)],
    evalsOf_le horc0⟩

/-! ### The frame bound -/

/-- **The frame bound of the round frame, general instance**: `o2mRoundB ≤ o2mTopM`. -/
theorem o2m_roundB_le_topM_gen {orc : ℤ → ℤ → ℤ → ℤ} {Mc J R eA eXi : ℕ} {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = (adaParams eA eXi Mc J R).N) (hc : ∀ x ∈ codes, x < 2 ^ bU)
    (horc0 : ∀ blk ∈ splitBlocks (adaParams eA eXi Mc J R).blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) (((adaParams eA eXi Mc J R).qA : ℤ) + 1) ∧
        orc 0 (r : ℤ) (((adaParams eA eXi Mc J R).qA : ℤ) + 1) ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 1))
    {st : AdaState} (hok : AdaOK (adaParams eA eXi Mc J R) st) (kind : Bool) :
    o2mRoundB orc Mc J R eA eXi (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes) st kind ≤
      o2mTopM (adaParams eA eXi Mc J R) bU Mc J R eA eXi := by
  have hbs := bsP_blockSizes_length eA eXi Mc J R
  have hT := bsP_Tmax_length eA eXi Mc J R
  have hv := o2m_valsOKA_split hlen horc0
  have hinp : ∀ k : Bool,
      valSize (o2mInp Mc J R eA eXi (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes) st k) ≤
        o2mInpB (adaParams eA eXi Mc J R) bU Mc J R eA eXi := fun k =>
    bsT_valSize_roundIn_state hbs hlen hc hok Mc J R eA eXi (k := if k then 1 else 0)
      (by split_ifs <;> simp [bitLen])
  have hpub : valSize (adaPubEnc (adaParams eA eXi Mc J R)) ≤ o2mPubRecB (adaParams eA eXi Mc J R) :=
    bsT_valSize_adaPubEnc _ hbs hT
  have hvals : valSize (encVals (evalsOf orc (adaParams eA eXi Mc J R).qA
      (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes))) ≤ o2mValsB (adaParams eA eXi Mc J R) :=
    bsT_valSize_encVals hbs hv
  have h1 := hinp kind
  have h2 := hinp true
  have h3 := hinp false
  unfold o2mRoundB o2mTopM o2mPreB o2mIvB o2mNumB
  refine max_le ?_ (max_le ?_ ?_) <;> omega

/-- **The frame bound of the round frame at the asm level** (C-BANK's P5): for the B state of a sample and the
oracle of a valid request, `o2mRoundB ≤ o2m_mR` (every `kind`). -/
theorem o2m_roundB_le_mR (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} {bU : ℕ} {code : U → ℕ}
    (hcode : ∀ x, code x < 2 ^ bU) (s : Fin (alg2Params M J R aReq ξReq).N → U) {req : VReq U}
    (hreq : req.Valid) {st : AdaState} (hok : AdaOK (asmParams M J R aReq ξReq) st) (kind : Bool) :
    o2mRoundB (reqOracle code req) M J R (dyadicExp aReq) (dyadicExp ξReq)
        (asmBlocks (asmParams M J R aReq ξReq) code s) st kind ≤ o2m_mR M J R aReq ξReq bU :=
  o2m_roundB_le_topM_gen (orc := reqOracle code req)
    (bsR_codes_length (asmParams M J R aReq ξReq) code s (refine_N M J R ha0 ha1 hξ0 hξ1))
    (o2m_codes_lt hcode s) (fun _ _ r _ => bsE_reqOracle_mem code hreq (r : ℤ) _) hok kind

/-! ### The callee budget -/

/-- **The frame bound of `bsEvals` (D2)**: `o2e_B ≤ o2mME`. -/
theorem o2m_evalsB_le_ME {orc : ℤ → ℤ → ℤ → ℤ} {A : AdaParams} {codes : List ℕ} {bU : ℕ}
    (hbs : A.blockSizes.length = A.p + 1) (hlen : codes.length = A.N) (hc : ∀ x ∈ codes, x < 2 ^ bU)
    (horc0 : ∀ blk ∈ splitBlocks A.blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ∧ orc 0 (r : ℤ) ((A.qA : ℤ) + 1) ≤ 2 ^ (A.qA + 1)) :
    o2e_B orc A.qA (splitBlocks A.blockSizes codes) ≤ o2mME A bU := by
  have h1 : valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) ≤ o2mBlocksB A bU :=
    bsT_valSize_blocks hbs hlen hc
  have h2 : valSize (encVals (evalsOf orc A.qA (splitBlocks A.blockSizes codes))) ≤ o2mValsB A :=
    bsT_valSize_encVals hbs (o2m_valsOKA_split hlen horc0)
  unfold o2e_B o2mME
  omega

/-- **The callee budget of the round frame, general instance**: `o2mRoundT ≤ o2mTopT` at the five callee
bounds. -/
theorem o2m_roundT_le_topT_gen {orc : ℤ → ℤ → ℤ → ℤ} {Mc J R eA eXi : ℕ} {codes : List ℕ} {bU : ℕ}
    (hlen : codes.length = (adaParams eA eXi Mc J R).N) (hc : ∀ x ∈ codes, x < 2 ^ bU)
    (horc0 : ∀ blk ∈ splitBlocks (adaParams eA eXi Mc J R).blockSizes codes, ∀ r ∈ blk,
      0 ≤ orc 0 (r : ℤ) (((adaParams eA eXi Mc J R).qA : ℤ) + 1) ∧
        orc 0 (r : ℤ) (((adaParams eA eXi Mc J R).qA : ℤ) + 1) ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 1)) :
    o2mRoundT (o2mMP Mc J R eA eXi) (81 * o2mMP Mc J R eA eXi)
        (o2e_B orc (adaParams eA eXi Mc J R).qA (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes))
        (o2e_T orc (adaParams eA eXi Mc J R).qA (splitBlocks (adaParams eA eXi Mc J R).blockSizes codes))
        (o2mMD (adaParams eA eXi Mc J R)) (23 * o2mMD (adaParams eA eXi Mc J R))
        (o2mMI (adaParams eA eXi Mc J R)) (210 * o2mMI (adaParams eA eXi Mc J R))
        (o2MA (adaParams eA eXi Mc J R)) (206 * o2MA (adaParams eA eXi Mc J R)) ≤
      o2mTopT (adaParams eA eXi Mc J R) bU Mc J R eA eXi := by
  have hE := o2m_evalsB_le_ME (bU := bU) (bsP_blockSizes_length eA eXi Mc J R) hlen hc horc0
  unfold o2mRoundT o2mTopT o2e_T
  rw [o2m_depth_adaPub, o2m_depth_bsEvals, o2m_depth_bsEnds, o2m_depth_adaInterval,
    o2m_depth_adaNumerical]
  refine max_le_max ?_ (max_le_max ?_ (max_le_max ?_ (max_le_max ?_ ?_))) <;> omega

/-- **The callee budget of the round frame at the asm level** (C-BANK's P5): `o2mRoundT ≤ o2m_τR` at the five
callee bounds, for the B state of a sample and the oracle of a valid request. -/
theorem o2m_roundT_le_τR (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) {U : Type} {bU : ℕ} {code : U → ℕ}
    (hcode : ∀ x, code x < 2 ^ bU) (s : Fin (alg2Params M J R aReq ξReq).N → U) {req : VReq U}
    (hreq : req.Valid) :
    o2mRoundT (o2mMP M J R (dyadicExp aReq) (dyadicExp ξReq))
        (81 * o2mMP M J R (dyadicExp aReq) (dyadicExp ξReq))
        (o2e_B (reqOracle code req) (asmParams M J R aReq ξReq).qA
          (asmBlocks (asmParams M J R aReq ξReq) code s))
        (o2e_T (reqOracle code req) (asmParams M J R aReq ξReq).qA
          (asmBlocks (asmParams M J R aReq ξReq) code s))
        (o2mMD (asmParams M J R aReq ξReq)) (23 * o2mMD (asmParams M J R aReq ξReq))
        (o2mMI (asmParams M J R aReq ξReq)) (210 * o2mMI (asmParams M J R aReq ξReq))
        (o2MA (asmParams M J R aReq ξReq)) (206 * o2MA (asmParams M J R aReq ξReq)) ≤
      o2m_τR M J R aReq ξReq bU :=
  o2m_roundT_le_topT_gen (orc := reqOracle code req)
    (bsR_codes_length (asmParams M J R aReq ξReq) code s (refine_N M J R ha0 ha1 hξ0 hξ1))
    (o2m_codes_lt hcode s) (fun _ _ r _ => bsE_reqOracle_mem code hreq (r : ℤ) _)

/-! ## `implR` -/

set_option maxHeartbeats 2000000 in
/-- **The request frame of `Theorem_B_space_with 30`**: W4's `O2Inputs.implR` with `mR := o2m_mR`,
`τR := o2m_τR`, given the tight specs of the two ADA entries on the round program. -/
theorem o2m_implR_of (hIvT : O2mIvTightSpec bsRoundProg) (hNumT : O2mNumTightSpec bsRoundProg)
    (M J R : ℕ) (aReq ξReq : ℝ) (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ) (hinj : Function.Injective code)
    (hcode : ∀ x, code x < 2 ^ bU) (s : Fin (alg2Params M J R aReq ξReq).N → U) (req : VReq U)
    (hreq : req.Valid) (st : AdaState) (hok : C.Impl.AdaOK (asmParams M J R aReq ξReq) st) :
    ImplementsF (reqOracle code req) bsRoundProg (o2m_mR M J R aReq ξReq bU) (o2m_τR M J R aReq ξReq bU)
      [Val.list [encVParams M J R aReq ξReq, bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) st,
        Val.int (if req.2.1 then 1 else 0)]] body_bsRound
      (fun r => Val.list [bsStateEnc (asmBlocks (asmParams M J R aReq ξReq) code s) r.2, bsResp r.1])
      (bsCoreRound (asmParams M J R aReq ξReq) st
        (coreVals (asmParams M J R aReq ξReq) (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
          (quantReq (asmParams M J R aReq ξReq) req))
        (quantReq (asmParams M J R aReq ξReq) req).l (quantReq (asmParams M J R aReq ξReq) req).u
        req.2.1) := by
  have h4 : 4 ≤ dyadicExp aReq := B.four_le_dyadicExp ha0 (by linarith)
  have h2 : 2 ≤ dyadicExp ξReq := B.two_le_dyadicExp hξ0 hξ1
  have hN := refine_N M J R ha0 ha1 hξ0 hξ1
  obtain ⟨horc0, horc12, hve, hel, heu⟩ := o2m_reqData (asmParams M J R aReq ξReq) hinj s hN hreq
  have hbs := bsP_blockSizes_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hT := bsP_Tmax_length (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hpos := bsP_blockSizes_pos (dyadicExp aReq) (dyadicExp ξReq) M J R
  have hblk := bsR_asmBlocks_length (asmParams M J R aReq ξReq) code s hN
  have hv : ValsOKA (asmParams M J R aReq ξReq) (evalsOf (reqOracle code req)
      (asmParams M J R aReq ξReq).qA (asmBlocks (asmParams M J R aReq ξReq) code s)) :=
    ⟨(evalsOf_map_length _ _ _).trans hblk, evalsOf_le horc0⟩
  have hl := bsN_end_bitLen' _ _ horc12.1
  have hu := bsN_end_bitLen' _ _ horc12.2
  /- ### The program and its weights -/
  have hO := bsRoundProg_oracle
  have hL := bsLib_round
  have hW := bsWeightOK_round
  obtain ⟨w600, -, w602, w603, -, -, w920, -, -⟩ := bsW_vals
  have h600 : bsRoundProg[Idx.adaPub]? = some body_adaPub :=
    hL.pub (Idx.adaPub, body_adaPub) (List.mem_append_right _ (by simp [adaPubTable]))
  have h602 : bsRoundProg[Idx.adaInterval]? = some body_adaInterval :=
    hL.w4Lib.entryTbl (Idx.adaInterval, body_adaInterval) (by simp [adaEntryTable])
  have h603 : bsRoundProg[Idx.adaNumerical]? = some body_adaNumerical :=
    hL.w4Lib.numTbl (Idx.adaNumerical, body_adaNumerical) (by simp [adaNumTable])
  have h920 : bsRoundProg[bsEndsKey]? = some body_bsEnds :=
    hL.ends (bsEndsKey, body_bsEnds) List.mem_cons_self
  have hcP : CalleesLe bsWRound 81 body_adaPub := by
    have h := (hW _ _ h600).2
    rwa [show bsWRound Idx.adaPub = 135 from w600, o2m_depth_adaPub] at h
  have hcD : CalleesLe bsWRound 23 body_bsEnds := by
    have h := (hW _ _ h920).2
    rwa [show bsWRound bsEndsKey = 38 from w920, o2m_depth_bsEnds] at h
  have hcI : CalleesLe bsWRound 210 body_adaInterval := by
    have h := (hW _ _ h602).2
    rwa [show bsWRound Idx.adaInterval = 231 from w602, o2m_depth_adaInterval] at h
  have hcN : CalleesLe bsWRound 206 body_adaNumerical := by
    have h := (hW _ _ h603).2
    rwa [show bsWRound Idx.adaNumerical = 240 from w603, o2m_depth_adaNumerical] at h
  /- ### The callees in their own frames -/
  have hPub := o2m_pubAt_of_lift (orc := reqOracle code req) (Mc := M) (J := J) (R := R) hO hW hL.pub
    (hL.normQ _) h4 h2 le_rfl hcP
  have hEv := o2m_evalsAt_of (orc := reqOracle code req) hL.evals horc0
  have hEn := o2m_endsAt_of_lift hO hW hL.ends (hL.normQ _) horc12 le_rfl hcD
  have hMq : 2 ^ 28 * ((asmParams M J R aReq ξReq).qA + 4) ≤ o2mMI (asmParams M J R aReq ξReq) := by
    unfold o2mMI
    omega
  have hIv := o2m_ivAt_of_lift (orc := reqOracle code req) hO hW h602
    (hIvT _ _ st _ _ _ _ (hL.normQ _) hbs hT hpos hok hv hl hu (o2mMI_tight _) hMq)
    (o2m_ivIn_le_of_tight hbs hT hok hv hl hu (o2mMI_tight _) hMq) hcI
  have hNum := o2m_numAt_of_lift (orc := reqOracle code req) hO hW h603
    (hNumT _ _ st _ (hL.normQ _) hbs hT hpos hok hv (o2MA_tightM _))
    (o2m_numIn_le_of_tight hbs hT hok hv (o2MA_tightM _)) hcN
  /- ### The frame -/
  /- ### The frame bound and the budget -/
  have hm := o2m_roundB_le_mR M J R ha0 ha1 hξ0 hξ1 hcode s hreq hok req.2.1
  have hτ := o2m_roundT_le_τR M J R ha0 ha1 hξ0 hξ1 (bU := bU) hcode s hreq
  have key := o2m_roundF hO hok req.2.1 horc12 hPub hEv hEn hIv hNum hm hτ
  rw [← hve, ← hel, ← heu]
  exact key

end F2e2e.BSpace
