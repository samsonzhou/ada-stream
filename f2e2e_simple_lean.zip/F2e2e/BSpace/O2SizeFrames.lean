import F2e2e.BSpace.O2SizeData
import F2e2e.BSpace.O2SizeUnit
import F2e2e.BSpace.O2TightChi

/-!
# B_space, route O2b (O2B-SIZE): per-frame sizes in `N·b_𝒰` and `N·χ` coefficients

Owner: O2B-SIZE (ce59d4ae), for the O2b technical lead (17fc0802), B-ACC (`O2Final`) and C-BANK / O2B-GST
(the budgets `m, τ` of the top frames). Every value that the top frames of `body_bsInit` and `body_bsRound` hold,
and every value-bound requirement of the B layer (`notes/o2_prep/M_TABLE.md` §3), is bounded in the form
`cU · (N · b_𝒰) + cX · (N · χ)` with explicit naturals `cU, cX`.

The bounds are generic in the instance through the χ-links `O2sLinks A χ cq` (with `q_A ≤ cq · χ`), so that they
serve today's link `cq = 32` (B-NUM's `alg2HAExp_le`, `o2s_links_today`) and B-NUM's Plan A `cq = 2` unchanged
(`o2s_links_actual` takes the link as a hypothesis; `o2s_links_planA` is the instance `cq = 2`). Every `N`-free term is absorbed by `N ≥ 2^{30} (p+1) χ`
(`o2s_N_ge`) and `60 < χ`.

| value (lemma) | bound |
|---|---|
| ADA state (`o2s_frame_st`) | `(cq + 2) N χ` |
| query table (`o2s_frame_vals`) | `(cq + 1) N χ` |
| parameter record (`o2s_frame_pub`, base `o2s_base_pub`) | `N` (`2^{14}·|pub| ≤ N`) |
| stored blocks / codes (`o2s_frame_blocks`, `o2s_frame_codes`) | `N b_𝒰 + N χ` |
| B state (`o2s_frame_state`) | `N b_𝒰 + (cq + 3) N χ` |
| round input (`o2s_frame_roundIn`) | `N b_𝒰 + (cq + 3) N χ` |
| ADA argument lists (`o2s_frame_argsIv`, `o2s_frame_argsNum`) | `(2 cq + 2) N χ` |
| ADA output pair (`o2s_frame_adaOut`) | `(cq + 2) N χ` |
| round output (`o2s_frame_roundOut`) | `N b_𝒰 + (cq + 3) N χ` |
| init input (`o2s_frame_initIn`) | `N b_𝒰 + N χ` |
| D1 / D2 requirements (`o2s_frame_D1`, `o2s_frame_D2`) | `N b_𝒰 + N χ`, `N b_𝒰 + (cq + 1) N χ` |
| D3 `20 q_A + 200`, `2^28 (q_A + 4)` (`o2s_frame_D3`, `o2s_frame_q28`) | `N`, `N χ` |
| P1 `bsPubBound` (`o2s_frame_bsPub`) | `N χ` |
| `TightM`'s left side `2^8 tightA + cAddA` | see B-ARCH's `O2TightChiLinks.lean` (`o2cl_tightM_le_gen`, `o2cl_tightM_le`: `72449 N χ` at `cq = 2`) |
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.C.Impl F2e2e.B F2e2e.Discrete

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## The χ-links -/

/-- **The χ-links of an ADA instance** (`q_A ≤ cq χ`, `cq ≤ 32`). -/
structure O2sLinks (A : AdaParams) (χ cq : ℕ) : Prop where
  chi_gt : 60 < χ
  N_ge : 2 ^ 30 * (A.p + 1) * χ ≤ A.N
  qA_le : A.qA ≤ cq * χ
  cq_le : cq ≤ 32
  sF_le : Nat.size A.fuel ≤ χ + 1
  sK_le : Nat.size (maxKs A) ≤ A.qA + 3 * χ + 3
  sC_le : Nat.size (A.M + A.J + A.R + 2) ≤ χ + 1
  Z_le : adaZ A ≤ 29 * A.qA + 80 * χ + 128
  hbs : A.blockSizes.length = A.p + 1
  hT : A.Tmax.length = A.p

section actual

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- **The χ-links of the actual parameters**, for any link `q_A ≤ cq χ` (`cq ≤ 32`). -/
theorem o2s_links_actual (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2)
    {cq : ℕ}
    (hq : (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA ≤
      cq * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq))
    (hcq : cq ≤ 32) :
    O2sLinks (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) cq := by
  have hce := bs_chi_eq M J R ha0 ha1 hξ0 hξ1
  have h4 : 4 ≤ F2e2e.dyadicExp aReq := four_le_dyadicExp ha0 (by linarith)
  refine ⟨bs_sixty_lt_chi M J R aReq ξReq, ?_, hq, hcq, bsT_sF_le_chi M J R ha0 ha1 hξ0 hξ1, ?_,
    bsT_sC_le_chi M J R ha0 ha1 hξ0 hξ1, ?_, bsP_blockSizes_length _ _ _ _ _,
    bsP_Tmax_length _ _ _ _ _⟩
  · rw [hce]
    exact o2s_N_ge M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq)
  · rw [hce]
    have h := BoundAux.size_le_of_le
      (BoundAux.maxKs_le M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq))
    have hq' : (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA =
        adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) := rfl
    rw [hq']
    omega
  · rw [hce]
    have h := BoundAux.adaZ_le_of M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) h4
    have hq' : (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).qA =
        adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) := rfl
    rw [hq']
    exact h

/-- **Today's χ-links** (`cq = 32`, B-NUM's `q_A ≤ 32 χ`). -/
theorem o2s_links_today (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    O2sLinks (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) 32 :=
  o2s_links_actual M J R ha0 ha1 hξ0 hξ1 (bsT_qA_le_chi M J R ha0 ha1 hξ0 hξ1) le_rfl

/-- **Plan A's χ-links** (`cq = 2`, B-NUM's `o2c_alg2HAExp_le_two : q_A ≤ 2 χ`, `O2TightChi.lean`). -/
theorem o2s_links_planA (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    O2sLinks (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) 2 := by
  refine o2s_links_actual M J R ha0 ha1 hξ0 hξ1 ?_ (by norm_num)
  show adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤ _
  rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1]
  exact o2c_alg2HAExp_le_two M J R aReq ξReq

/-- The parameters of the actual instance: `eA + eXi + 49 ≤ χ`. -/
theorem o2s_eAX_le_chi (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    F2e2e.dyadicExp aReq + F2e2e.dyadicExp ξReq + 49 ≤
      F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
  unfold adaChi
  omega

end actual

/-! ## Elementary consequences (numerals, no powers: `omega`-friendly) -/

namespace O2sLinks

variable {A : AdaParams} {χ cq : ℕ} (L : O2sLinks A χ cq)
include L

theorem NX : 60 * A.N ≤ A.N * χ := by
  have := L.chi_gt
  calc 60 * A.N ≤ χ * A.N := Nat.mul_le_mul_right _ (by omega)
    _ = A.N * χ := Nat.mul_comm _ _

/-- `2^{30} (p + 1) χ ≤ N`, with the numeral `2^{30} = 1073741824`. -/
theorem pX : 1073741824 * ((A.p + 1) * χ) ≤ A.N := by
  have h := L.N_ge
  have e : (2 : ℕ) ^ 30 * (A.p + 1) * χ = 1073741824 * ((A.p + 1) * χ) := by ring
  omega

theorem pX_pos : 1 ≤ (A.p + 1) * χ := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega)
  (by have := L.chi_gt; omega))

theorem N_big : 1073741824 ≤ A.N := by
  have h1 := L.pX
  have h2 := L.pX_pos
  have : 1073741824 * 1 ≤ 1073741824 * ((A.p + 1) * χ) := Nat.mul_le_mul_left _ h2
  omega

theorem qNX : A.N * A.qA ≤ cq * (A.N * χ) :=
  calc A.N * A.qA ≤ A.N * (cq * χ) := Nat.mul_le_mul_left _ L.qA_le
    _ = cq * (A.N * χ) := by ring

/-- `q_A + 7χ + 40 ≤ 40 χ`. -/
theorem q7 : A.qA + 7 * χ + 40 ≤ 40 * χ := by
  have := L.qA_le; have := L.chi_gt
  have : cq * χ ≤ 32 * χ := Nat.mul_le_mul_right _ L.cq_le
  omega

/-- The `N`-free terms of the state and the tables: `2^{24} (p + 1)(q_A + 7χ + 40) ≤ N`. -/
theorem small : 16777216 * ((A.p + 1) * (A.qA + 7 * χ + 40)) ≤ A.N := by
  have h2 : (A.p + 1) * (A.qA + 7 * χ + 40) ≤ 40 * ((A.p + 1) * χ) :=
    calc (A.p + 1) * (A.qA + 7 * χ + 40) ≤ (A.p + 1) * (40 * χ) := Nat.mul_le_mul_left _ L.q7
      _ = 40 * ((A.p + 1) * χ) := by ring
  have h3 := L.pX
  omega

/-- In particular `2^{24} (q_A + 7χ + 40) ≤ N`. -/
theorem small1 : 16777216 * (A.qA + 7 * χ + 40) ≤ A.N := by
  have h := L.small
  have : A.qA + 7 * χ + 40 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := Nat.le_mul_of_pos_left _ (by omega)
  omega

/-- `adaZ A + 16 ≤ (29 cq + 83) χ`. -/
theorem Z16 : adaZ A + 16 ≤ (29 * cq + 83) * χ := by
  have h1 := L.Z_le
  have h2 : 29 * A.qA ≤ 29 * (cq * χ) := Nat.mul_le_mul_left _ L.qA_le
  have e : (29 * cq + 83) * χ = 29 * (cq * χ) + 83 * χ := by ring
  have := L.chi_gt
  omega

end O2sLinks

/-! ## Base sizes (in `N`-units) -/

section base

variable {A : AdaParams} {χ cq : ℕ}

/-- **The ADA state, base form**: `≤ cq N χ + N χ + 6 N`. -/
theorem o2s_base_st (L : O2sLinks A χ cq) {st : AdaState} (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ cq * (A.N * χ) + A.N * χ + 6 * A.N := by
  have h := bsT_valSize_adaEnc hok
  have e1 : A.N * (A.qA + Nat.size A.fuel + 4) = A.N * A.qA + A.N * Nat.size A.fuel + 4 * A.N := by
    ring
  have hNF : A.N * Nat.size A.fuel ≤ A.N * χ + A.N :=
    calc A.N * Nat.size A.fuel ≤ A.N * (χ + 1) := Nat.mul_le_mul_left _ L.sF_le
      _ = A.N * χ + A.N := by ring
  have hp : A.p * (Nat.size A.fuel + Nat.size (maxKs A) + 6) + Nat.size (maxKs A) +
      3 * Nat.size (A.M + A.J + A.R + 2) + 24 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have hF := L.sF_le; have hK := L.sK_le; have hC := L.sC_le
    have h1 := Nat.mul_le_mul_left A.p
      (show Nat.size A.fuel + Nat.size (maxKs A) + 6 ≤ A.qA + 7 * χ + 40 by omega)
    have e : (A.p + 1) * (A.qA + 7 * χ + 40) = A.p * (A.qA + 7 * χ + 40) + (A.qA + 7 * χ + 40) := by
      ring
    omega
  have hs := L.small
  have hq := L.qNX
  omega

/-- **The query table, base form**: `≤ cq N χ + 4 N`. -/
theorem o2s_base_vals (L : O2sLinks A χ cq) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (encVals vals) ≤ cq * (A.N * χ) + 4 * A.N := by
  have h := bsT_valSize_encVals L.hbs hv
  have e1 : A.N * (A.qA + 3) = A.N * A.qA + 3 * A.N := by ring
  have hs := L.small
  have hp : 2 * (A.p + 1) + 1 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have : 3 * (A.p + 1) ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
      rw [Nat.mul_comm 3]; exact Nat.mul_le_mul_left _ (by omega)
    omega
  have hq := L.qNX
  omega

/-- **The parameter record, base form**: `2^{14} · valSize (adaPubEnc A) ≤ N`. -/
theorem o2s_base_pub (L : O2sLinks A χ cq) : 16384 * valSize (adaPubEnc A) ≤ A.N := by
  have hc34 : 34 * (29 * cq + 83) ≤ 34374 := by have := L.cq_le; omega
  have hZ := L.Z16
  have h4 := L.pX
  calc 16384 * valSize (adaPubEnc A) ≤ 16384 * (34 * (A.p + 1) * (adaZ A + 16)) :=
        Nat.mul_le_mul_left _ (bsT_valSize_adaPubEnc' A L.hbs L.hT)
    _ ≤ 16384 * (34 * (A.p + 1) * ((29 * cq + 83) * χ)) :=
        Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hZ)
    _ = 16384 * ((34 * (29 * cq + 83)) * ((A.p + 1) * χ)) := by ring
    _ ≤ 16384 * (34374 * ((A.p + 1) * χ)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ hc34)
    _ = 563183616 * ((A.p + 1) * χ) := by ring
    _ ≤ 1073741824 * ((A.p + 1) * χ) := Nat.mul_le_mul_right _ (by norm_num)
    _ ≤ A.N := h4

/-- **The record codes, base form**: `≤ N b_𝒰 + 3 N`. -/
theorem o2s_base_codes (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) : valSize (encL encN codes) ≤ A.N * bU + 3 * A.N := by
  have h := valSize_codes_le hc
  rw [hlen] at h
  have e : A.N * (bU + 2) = A.N * bU + 2 * A.N := by ring
  have hN := L.N_big
  omega

/-- **The stored blocks, base form**: `≤ N b_𝒰 + 3 N`. -/
theorem o2s_base_blocks (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) ≤ A.N * bU + 3 * A.N := by
  have h := bsT_valSize_blocks L.hbs hlen hc
  have e : A.N * (bU + 2) = A.N * bU + 2 * A.N := by ring
  have hs := L.small
  have hp : 2 * (A.p + 1) + 1 ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
    have : 3 * (A.p + 1) ≤ (A.p + 1) * (A.qA + 7 * χ + 40) := by
      rw [Nat.mul_comm 3]; exact Nat.mul_le_mul_left _ (by omega)
    omega
  omega

/-- The encoded parameters are small: `o2sParamsSize ≤ 5 χ + 14` when `eA + eXi + 49 ≤ χ`. -/
theorem o2s_paramsSize_le (L : O2sLinks A χ cq) {eA eXi : ℕ} (h : eA + eXi + 49 ≤ χ) :
    o2sParamsSize A.M A.J A.R eA eXi ≤ 5 * χ + 14 := by
  have hC := L.sC_le
  have hM : Nat.size A.M ≤ Nat.size (A.M + A.J + A.R + 2) := Nat.size_le_size (by omega)
  have hJ : Nat.size A.J ≤ Nat.size (A.M + A.J + A.R + 2) := Nat.size_le_size (by omega)
  have hR : Nat.size A.R ≤ Nat.size (A.M + A.J + A.R + 2) := Nat.size_le_size (by omega)
  have hA := size_le_self eA
  have hX := size_le_self eXi
  unfold o2sParamsSize
  omega

end base

/-! ## The per-frame values -/

section frames

variable {A : AdaParams} {χ cq : ℕ}

/-- **The ADA state**: `valSize (adaEnc st) ≤ (cq + 2) N χ`. -/
theorem o2s_frame_st (L : O2sLinks A χ cq) {st : AdaState} (hok : AdaOK A st) :
    valSize (adaEnc st) ≤ (cq + 2) * (A.N * χ) := by
  have h := o2s_base_st L hok
  have hNX := L.NX
  have e : (cq + 2) * (A.N * χ) = cq * (A.N * χ) + 2 * (A.N * χ) := by ring
  omega

/-- **The query table**: `valSize (encVals vals) ≤ (cq + 1) N χ`. -/
theorem o2s_frame_vals (L : O2sLinks A χ cq) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (encVals vals) ≤ (cq + 1) * (A.N * χ) := by
  have h := o2s_base_vals L hv
  have hNX := L.NX
  have e : (cq + 1) * (A.N * χ) = cq * (A.N * χ) + A.N * χ := by ring
  omega

/-- **The parameter record**: `valSize (adaPubEnc A) ≤ N`. -/
theorem o2s_frame_pub (L : O2sLinks A χ cq) : valSize (adaPubEnc A) ≤ A.N := by
  have := o2s_base_pub L
  omega

/-- **The record codes**: `valSize (encL encN codes) ≤ N b_𝒰 + N χ`. -/
theorem o2s_frame_codes (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) : valSize (encL encN codes) ≤ A.N * bU + A.N * χ := by
  have h := o2s_base_codes L hlen hc
  have hNX := L.NX
  omega

/-- **The stored blocks**: `≤ N b_𝒰 + N χ`. -/
theorem o2s_frame_blocks (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) ≤ A.N * bU + A.N * χ := by
  have h := o2s_base_blocks L hlen hc
  have hNX := L.NX
  omega

/-- **The B state** `bsStateEnc (splitBlocks A.blockSizes codes) st`: `≤ N b_𝒰 + (cq + 3) N χ`. -/
theorem o2s_frame_state (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {st : AdaState} (hok : AdaOK A st) :
    valSize (bsStateEnc (splitBlocks A.blockSizes codes) st) ≤ A.N * bU + (cq + 3) * (A.N * χ) := by
  have h1 := o2s_base_blocks L hlen hc
  have h2 := o2s_base_st L hok
  have hNX := L.NX
  have hN := L.N_big
  have e : (cq + 3) * (A.N * χ) = cq * (A.N * χ) + 3 * (A.N * χ) := by ring
  show valSize (Val.list [Val.list ((splitBlocks A.blockSizes codes).map (encL encN)), adaEnc st]) ≤ _
  rw [o2s_valSize_list2]
  omega

/-- **A round's input** `[params, state, kind]` (`bitLen kind ≤ 1`): `≤ N b_𝒰 + (cq + 3) N χ`. -/
theorem o2s_frame_roundIn (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {st : AdaState} (hok : AdaOK A st) {eA eXi : ℕ}
    (hpar : eA + eXi + 49 ≤ χ) {k : ℤ} (hk : bitLen k ≤ 1) :
    valSize (Val.list [encInts [(A.M : ℤ), (A.J : ℤ), (A.R : ℤ), (eA : ℤ), (eXi : ℤ)],
      bsStateEnc (splitBlocks A.blockSizes codes) st, Val.int k]) ≤ A.N * bU + (cq + 3) * (A.N * χ) := by
  have h1 := o2s_base_blocks L hlen hc
  have h2 := o2s_base_st L hok
  have h3 := o2s_paramsSize_le L hpar
  have hS : valSize (bsStateEnc (splitBlocks A.blockSizes codes) st) =
      valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) + valSize (adaEnc st) + 3 :=
    o2s_valSize_list2 _ _
  rw [o2s_valSize_list3, o2s_valSize_encInts_params, valSize_int, hS]
  have hNX := L.NX
  have hs := L.small1
  have e : (cq + 3) * (A.N * χ) = cq * (A.N * χ) + 3 * (A.N * χ) := by ring
  omega

/-- **`adaInterval`'s argument** `[pub, st, vals, l, u]` (endpoints of `≤ q_A + 4` bits): `≤ (2 cq + 2) N χ`. -/
theorem o2s_frame_argsIv (L : O2sLinks A χ cq) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) {l u : ℚ}
    (hl : bitLen l.num ≤ A.qA + 4 ∧ bitLen (l.den : ℤ) ≤ A.qA + 4)
    (hu : bitLen u.num ≤ A.qA + 4 ∧ bitLen (u.den : ℤ) ≤ A.qA + 4) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) ≤
      (2 * cq + 2) * (A.N * χ) := by
  rw [o2s_valSize_adaArgsIv]
  have h1 := o2s_base_pub L
  have h2 := o2s_base_st L hok
  have h3 := o2s_base_vals L hv
  unfold bitLen at hl hu
  simp only [Int.natAbs_natCast] at hl hu
  have hNX := L.NX
  have hs := L.small1
  have e : (2 * cq + 2) * (A.N * χ) = cq * (A.N * χ) + cq * (A.N * χ) + 2 * (A.N * χ) := by ring
  omega

/-- **`adaNumerical`'s argument** `[pub, st, vals]`: `≤ (2 cq + 2) N χ`. -/
theorem o2s_frame_argsNum (L : O2sLinks A χ cq) {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) ≤ (2 * cq + 2) * (A.N * χ) := by
  rw [o2s_valSize_adaArgsNum]
  have h1 := o2s_base_pub L
  have h2 := o2s_base_st L hok
  have h3 := o2s_base_vals L hv
  have hNX := L.NX
  have hN := L.N_big
  have e : (2 * cq + 2) * (A.N * χ) = cq * (A.N * χ) + cq * (A.N * χ) + 2 * (A.N * χ) := by ring
  omega

/-- **An ADA output pair** `[out, adaEnc st']` (`|out| ≤ 2 q_A + 13`): `≤ (cq + 2) N χ`. -/
theorem o2s_frame_adaOut (L : O2sLinks A χ cq) {st' : AdaState} (hok' : AdaOK A st') {out : Val}
    (hout : valSize out ≤ 2 * A.qA + 13) :
    valSize (Val.list [out, adaEnc st']) ≤ (cq + 2) * (A.N * χ) := by
  rw [o2s_valSize_adaOut]
  have h2 := o2s_base_st L hok'
  have hNX := L.NX
  have hs := L.small1
  have e : (cq + 2) * (A.N * χ) = cq * (A.N * χ) + 2 * (A.N * χ) := by ring
  omega

/-- **A round's output** `[bsStateEnc blocks st', resp]` (`|resp| ≤ 2 q_A + 12`): `≤ N b_𝒰 + (cq + 3) N χ`. -/
theorem o2s_frame_roundOut (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {st' : AdaState} (hok' : AdaOK A st') {resp : Val}
    (hresp : valSize resp ≤ 2 * A.qA + 12) :
    valSize (Val.list [bsStateEnc (splitBlocks A.blockSizes codes) st', resp]) ≤
      A.N * bU + (cq + 3) * (A.N * χ) := by
  have h1 := o2s_base_blocks L hlen hc
  have h2 := o2s_base_st L hok'
  have hS : valSize (bsStateEnc (splitBlocks A.blockSizes codes) st') =
      valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) + valSize (adaEnc st') + 3 :=
    o2s_valSize_list2 _ _
  rw [o2s_valSize_roundOut, hS]
  have hNX := L.NX
  have hs := L.small1
  have e : (cq + 3) * (A.N * χ) = cq * (A.N * χ) + 3 * (A.N * χ) := by ring
  omega

/-- **The initialization's input** `[params, codes]`: `≤ N b_𝒰 + N χ`. -/
theorem o2s_frame_initIn (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) :
    valSize (Val.list [encInts [(A.M : ℤ), (A.J : ℤ), (A.R : ℤ), (eA : ℤ), (eXi : ℤ)],
      encL encN codes]) ≤ A.N * bU + A.N * χ := by
  rw [o2s_valSize_list2, o2s_valSize_encInts_params]
  have h1 := o2s_base_codes L hlen hc
  have h2 := o2s_paramsSize_le L hpar
  have hNX := L.NX
  have hs := L.small1
  omega

/-- **D1's requirement** `|encL encN ns| + |encL encN codes| + 32` at `ns = A.blockSizes`: `≤ N b_𝒰 + N χ`. -/
theorem o2s_frame_D1 (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) :
    valSize (encL encN A.blockSizes) + valSize (encL encN codes) + 32 ≤ A.N * bU + A.N * χ := by
  have h1 := o2s_base_codes L hlen hc
  have hP : valSize (encL encN A.blockSizes) ≤ valSize (adaPubEnc A) :=
    (valSize_lt_of_mem (l := pubFields A) (by simp [pubFields])).le
  have h2 := o2s_base_pub L
  have hNX := L.NX
  have hN := L.N_big
  omega

/-- **D2's requirement** `|blocks| + |encVals vals| + 2 q_A + 64`: `≤ N b_𝒰 + (cq + 1) N χ`. -/
theorem o2s_frame_D2 (L : O2sLinks A χ cq) {codes : List ℕ} {bU : ℕ} (hlen : codes.length = A.N)
    (hc : ∀ x ∈ codes, x < 2 ^ bU) {vals : List (List ℕ)} (hv : ValsOKA A vals) :
    valSize (Val.list ((splitBlocks A.blockSizes codes).map (encL encN))) + valSize (encVals vals) +
      2 * A.qA + 64 ≤ A.N * bU + (cq + 1) * (A.N * χ) := by
  have h1 := o2s_base_blocks L hlen hc
  have h2 := o2s_base_vals L hv
  have hNX := L.NX
  have hs := L.small1
  have e : (cq + 1) * (A.N * χ) = cq * (A.N * χ) + A.N * χ := by ring
  omega

/-- **D3's requirement** `20 q_A + 200`: `≤ N` (and so `≤ N χ`). -/
theorem o2s_frame_D3 (L : O2sLinks A χ cq) : 20 * A.qA + 200 ≤ A.N := by
  have hs := L.small1
  omega

/-- **`adaInterval`'s normQ requirement** `2^{28} (q_A + 4)` (`Bq = q_A + 4`): `≤ N χ`. -/
theorem o2s_frame_q28 (L : O2sLinks A χ cq) : 2 ^ 28 * (A.qA + 4) ≤ A.N * χ := by
  have hNX := L.NX
  have hs := L.small1
  have e : (2 : ℕ) ^ 28 * (A.qA + 4) = 268435456 * (A.qA + 4) := by ring
  rw [e]
  omega

/-- **P1's requirement** `bsPubBound = 2^{20} L²`: `≤ N χ` (`L ≤ 3 χ`, `N ≥ 2^{30} χ`). -/
theorem o2s_frame_bsPub (L : O2sLinks A χ cq) {eA eXi : ℕ} (hpar : eA + eXi + 49 ≤ χ) :
    bsPubBound A.M A.J A.R eA eXi ≤ A.N * χ := by
  have hC := L.sC_le
  have hcl : Nat.clog 2 (A.M + A.J + A.R + 2) ≤ Nat.size (A.M + A.J + A.R + 2) :=
    (Nat.clog_le_iff_le_pow (by norm_num)).2 (Nat.lt_size_self _).le
  have hL : bsPubL A.M A.J A.R eA eXi ≤ 3 * χ := by
    unfold bsPubL
    have := L.chi_gt
    omega
  have hL2 : bsPubL A.M A.J A.R eA eXi ^ 2 ≤ (3 * χ) ^ 2 := Nat.pow_le_pow_left hL 2
  have h2 : 1073741824 * χ ≤ A.N := by
    have h := L.pX
    have : 1073741824 * χ ≤ 1073741824 * ((A.p + 1) * χ) :=
      Nat.mul_le_mul_left _ (Nat.le_mul_of_pos_left _ (by omega))
    omega
  have h3 : (2 : ℕ) ^ 20 * (3 * χ) ^ 2 = 9437184 * (χ * χ) := by ring
  have h4 : 9437184 * (χ * χ) ≤ (1073741824 * χ) * χ := by
    have e' : (1073741824 * χ) * χ = 1073741824 * (χ * χ) := by ring
    rw [e']
    exact Nat.mul_le_mul_right _ (by norm_num)
  have h5 : (1073741824 * χ) * χ ≤ A.N * χ := Nat.mul_le_mul_right _ h2
  unfold bsPubBound
  calc 2 ^ 20 * bsPubL A.M A.J A.R eA eXi ^ 2 ≤ 2 ^ 20 * (3 * χ) ^ 2 := Nat.mul_le_mul_left _ hL2
    _ = 9437184 * (χ * χ) := h3
    _ ≤ A.N * χ := h4.trans h5

end frames

end F2e2e.BSpace
