import F2e2e.BSpace.O2BridgeMain
import F2e2e.Spec

/-!
# O2b, the end inequality (B-ACC)

Plan: O2b (tech lead 17fc0802). The additive bridge (`F2e2e/BSpace/O2BridgeMain.lean`) charges every step of a
top-level run with peak `S` at most `bridgeAdd prog (r 0) S`; C-SPACE's GST entry gives the peak
`S = (exprDepth body0 + 3)·m + τ`. Here: for programs with `progDepth ≤ D0`, `fnWidth ≤ W0`, `r 0 ≤ ρ0`,
`exprDepth body0 ≤ E0`, and budgets `m`, `τ` linear in `N·b_𝒰` and `N·χ`,

  `bridgeAdd prog (r 0) ((exprDepth body0 + 3)·m + τ) ≤ bSpaceBound 30 N b_𝒰 χ = 2^30 · N · (b_𝒰 + χ²)`

(`o2f_final_gen`), with `c = 4 (D0 + 1) + 18` and `e = E0 + 3`, under three numeric conditions: the record part
`c (e c_mU + c_τU) ≤ 2^30`, the N-free part `c (e d_m + d_τ) + o2fC D0 W0 ρ0 ≤ d_X · N χ` (any `d_X`; e.g.
`d_X` = the left side when `N χ ≥ 1`, or a small `d_X` from `N ≥ 2^30 (p+1) χ`), and the χ threshold
`c (e c_mX + c_τX) + d_X ≤ 2^30 · χ` (`o2f_final_gen_range`: implied by `60 < χ` when the left side is
`≤ 61 · 2^30`).

* `o2f_bridgeAdd_le_gen`: `bridgeAdd prog ρ S ≤ (4 (D0 + 1) + 18) S + o2fC D0 W0 ρ0` (with
  `⌈log₂ x⌉ ≤ x / 2^{10} + 10`);
* the instance `D0 = 60`, `W0 = 10`, `ρ0 = 15`, `E0 = 60`: `o2f_bridgeAdd_le` (`≤ 262 S + 392500`) and
  `o2f_final` / `o2f_final_range` (`c = 262`, `e = 63`);
* the B entry programs (`progDepth ≤ 59`, `fnWidth ≤ 10`, `bsRank 0 = 15`, entry depths `8` / `15`):
  `c = 258`, `o2fC 59 10 15 = 380266` (`o2fC_59_10_15`); the closers in the shape of `O2Inputs.finI/finR` are in
  `F2e2e/BSpace/O2FinalB.lean`.
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine F2e2e.Cost F2e2e.BSpace.MachineO

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-- `⌈log₂ x⌉ ≤ x`. -/
theorem o2f_clog_le (x : ℕ) : Nat.clog 2 x ≤ x :=
  (Nat.clog_le_iff_le_pow (by norm_num)).2 Nat.lt_two_pow_self.le

/-- `⌈log₂ x⌉ ≤ x / 2^k + k` (from `x < 2^k (x / 2^k + 1) ≤ 2^k · 2^{x / 2^k}`). -/
theorem o2f_clog_le_div (x k : ℕ) : Nat.clog 2 x ≤ x / 2 ^ k + k := by
  rw [Nat.clog_le_iff_le_pow (by norm_num)]
  have h1 : x < 2 ^ k * (x / 2 ^ k + 1) := Nat.lt_mul_div_succ x (by positivity)
  have h2 : x / 2 ^ k + 1 ≤ 2 ^ (x / 2 ^ k) := Nat.lt_two_pow_self
  have h3 : 2 ^ k * (x / 2 ^ k + 1) ≤ 2 ^ k * 2 ^ (x / 2 ^ k) := Nat.mul_le_mul_left _ h2
  rw [pow_add, Nat.mul_comm (2 ^ (x / 2 ^ k))]
  exact le_of_lt (lt_of_lt_of_le h1 h3)

/-! ## The general form (program constants as parameters) -/

/-- The constant part of the bridge bound for `progDepth ≤ D0`, `fnWidth ≤ W0`, `ρ ≤ ρ0`:
`2 a + 185 + (2 a + 82) / 256` with `a = 3(D0+1) + (ρ0+1)(D0+1)(W0 + 3 D0 + 10) + 1` (`a` bounds the constant part of
`addTop`). -/
def o2fC (D0 W0 ρ0 : ℕ) : ℕ :=
  2 * (3 * (D0 + 1) + (ρ0 + 1) * (D0 + 1) * (W0 + 3 * D0 + 10) + 1) + 185 +
    (2 * (3 * (D0 + 1) + (ρ0 + 1) * (D0 + 1) * (W0 + 3 * D0 + 10) + 1) + 82) / 256

/-- The instance `D0 = 60`, `W0 = 10`, `ρ0 = 15` (value `392479`). -/
theorem o2fC_60_10_15 : o2fC 60 10 15 ≤ 392500 := by
  unfold o2fC
  norm_num

/-- The instance of the B entry programs: `D0 = 59`, `W0 = 10`, `ρ0 = 15`. -/
theorem o2fC_59_10_15 : o2fC 59 10 15 = 380266 := by
  unfold o2fC
  norm_num

/-- **The bridge bound, general**: `bridgeAdd prog ρ S ≤ (4 (D0 + 1) + 18) S + o2fC D0 W0 ρ0` for
`progDepth ≤ D0 ≤ 123`, `fnWidth ≤ W0`, `ρ ≤ ρ0`. -/
theorem o2f_bridgeAdd_le_gen {prog : List Expr} {ρ D0 W0 ρ0 : ℕ} (S : ℕ)
    (hD : progDepth prog ≤ D0) (hD0 : D0 ≤ 123) (hW : fnWidth prog ≤ W0) (hρ : ρ ≤ ρ0) :
    O2B.bridgeAdd prog ρ S ≤ (4 * (D0 + 1) + 18) * S + o2fC D0 W0 ρ0 := by
  have f1 : 2 * (progDepth prog + 1) * S ≤ 2 * (D0 + 1) * S :=
    Nat.mul_le_mul_right _ (by omega)
  have f2 : (ρ + 1) * (progDepth prog + 1) * (frameC prog + 4) ≤
      (ρ0 + 1) * (D0 + 1) * (W0 + 3 * D0 + 10) :=
    Nat.mul_le_mul (Nat.mul_le_mul (by omega) (by omega)) (by unfold frameC posBits; omega)
  have f3 : (4 * (D0 + 1) + 18) * S = 2 * (2 * (D0 + 1) * S) + 16 * S + 2 * S := by ring
  have f4 : (4 * (D0 + 1) + 16) * S = 2 * (2 * (D0 + 1) * S) + 16 * S := by ring
  have f5 : (4 * (D0 + 1) + 16) * S ≤ 256 * (2 * S) := by
    have : (4 * (D0 + 1) + 16) * S ≤ 512 * S := Nat.mul_le_mul_right _ (by omega)
    omega
  have f6 : (4 * (D0 + 1) + 16) * S / 256 ≤ 2 * S := Nat.div_le_of_le_mul f5
  have h2 := o2f_clog_le_div (2 * O2B.addTop prog ρ S + 16 * (S + 1) + 66) 10
  have h3 : (2 : ℕ) ^ 10 = 1024 := by norm_num
  rw [h3] at h2
  unfold O2B.bridgeAdd o2fC
  unfold O2B.addTop at h2 ⊢
  omega

/-- **The end inequality, general.** For `progDepth prog ≤ D0 ≤ 123`, `fnWidth prog ≤ W0`, `r 0 ≤ ρ0`,
`exprDepth body0 ≤ E0` and budgets `m ≤ c_mU N b_𝒰 + c_mX N χ + d_m`, `τ ≤ c_τU N b_𝒰 + c_τX N χ + d_τ`: the additive
bridge's charge of the GST peak `(exprDepth body0 + 3) m + τ` is at most `bSpaceBound 30 N b_𝒰 χ`, provided (with
`c = 4 (D0 + 1) + 18`, `e = E0 + 3`) the record part `c (e c_mU + c_τU) ≤ 2^30`, the N-free part
`c (e d_m + d_τ) + o2fC D0 W0 ρ0 ≤ d_X · N χ`, and the χ threshold `c (e c_mX + c_τX) + d_X ≤ 2^30 χ`. -/
theorem o2f_final_gen {prog : List Expr} {r : ℕ → ℕ} {body0 : Expr}
    {D0 W0 ρ0 E0 m τ N bU χ cmU cmX dm cτU cτX dτ dX : ℕ}
    (hD : progDepth prog ≤ D0) (hD0 : D0 ≤ 123) (hW : fnWidth prog ≤ W0) (hr : r 0 ≤ ρ0)
    (hE : exprDepth body0 ≤ E0)
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hd : (4 * (D0 + 1) + 18) * ((E0 + 3) * dm + dτ) + o2fC D0 W0 ρ0 ≤ dX * (N * χ))
    (hU : (4 * (D0 + 1) + 18) * ((E0 + 3) * cmU + cτU) ≤ 2 ^ 30)
    (hX : (4 * (D0 + 1) + 18) * ((E0 + 3) * cmX + cτX) + dX ≤ 2 ^ 30 * χ) :
    ((O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) : ℕ) : ℝ) ≤ bSpaceBound 30 N bU χ := by
  -- the bridge
  have hB := o2f_bridgeAdd_le_gen ((exprDepth body0 + 3) * m + τ) hD hD0 hW hr
  have hS : (exprDepth body0 + 3) * m ≤ (E0 + 3) * m := Nat.mul_le_mul_right _ (by omega)
  -- the budgets
  have hmτ : (E0 + 3) * m + τ ≤ ((E0 + 3) * cmU + cτU) * (N * bU) + ((E0 + 3) * cmX + cτX) * (N * χ) +
      ((E0 + 3) * dm + dτ) :=
    calc (E0 + 3) * m + τ ≤ (E0 + 3) * (cmU * (N * bU) + cmX * (N * χ) + dm) +
          (cτU * (N * bU) + cτX * (N * χ) + dτ) := Nat.add_le_add (Nat.mul_le_mul_left _ hm) hτ
      _ = ((E0 + 3) * cmU + cτU) * (N * bU) + ((E0 + 3) * cmX + cτX) * (N * χ) +
          ((E0 + 3) * dm + dτ) := by ring
  -- the record part
  have hUp : (4 * (D0 + 1) + 18) * (((E0 + 3) * cmU + cτU) * (N * bU)) ≤ 2 ^ 30 * (N * bU) := by
    rw [← Nat.mul_assoc]; exact Nat.mul_le_mul_right _ hU
  -- the χ part (with the N-free part)
  have hXp : (4 * (D0 + 1) + 18) * (((E0 + 3) * cmX + cτX) * (N * χ)) +
      ((4 * (D0 + 1) + 18) * ((E0 + 3) * dm + dτ) + o2fC D0 W0 ρ0) ≤ 2 ^ 30 * (N * χ ^ 2) :=
    calc (4 * (D0 + 1) + 18) * (((E0 + 3) * cmX + cτX) * (N * χ)) +
          ((4 * (D0 + 1) + 18) * ((E0 + 3) * dm + dτ) + o2fC D0 W0 ρ0)
        ≤ (4 * (D0 + 1) + 18) * (((E0 + 3) * cmX + cτX) * (N * χ)) + dX * (N * χ) :=
          Nat.add_le_add_left hd _
      _ = ((4 * (D0 + 1) + 18) * ((E0 + 3) * cmX + cτX) + dX) * (N * χ) := by ring
      _ ≤ (2 ^ 30 * χ) * (N * χ) := Nat.mul_le_mul_right _ hX
      _ = 2 ^ 30 * (N * χ ^ 2) := by ring
  -- the whole bound in ℕ
  have hS' : (exprDepth body0 + 3) * m + τ ≤ ((E0 + 3) * cmU + cτU) * (N * bU) +
      ((E0 + 3) * cmX + cτX) * (N * χ) + ((E0 + 3) * dm + dτ) :=
    le_trans (Nat.add_le_add_right hS τ) hmτ
  have hnat : O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) ≤
      2 ^ 30 * (N * bU) + 2 ^ 30 * (N * χ ^ 2) :=
    calc O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ)
        ≤ (4 * (D0 + 1) + 18) * ((exprDepth body0 + 3) * m + τ) + o2fC D0 W0 ρ0 := hB
      _ ≤ (4 * (D0 + 1) + 18) * (((E0 + 3) * cmU + cτU) * (N * bU) +
            ((E0 + 3) * cmX + cτX) * (N * χ) + ((E0 + 3) * dm + dτ)) + o2fC D0 W0 ρ0 :=
          Nat.add_le_add_right (Nat.mul_le_mul_left _ hS') _
      _ = (4 * (D0 + 1) + 18) * (((E0 + 3) * cmU + cτU) * (N * bU)) +
            ((4 * (D0 + 1) + 18) * (((E0 + 3) * cmX + cτX) * (N * χ)) +
              ((4 * (D0 + 1) + 18) * ((E0 + 3) * dm + dτ) + o2fC D0 W0 ρ0)) := by ring
      _ ≤ 2 ^ 30 * (N * bU) + 2 ^ 30 * (N * χ ^ 2) := Nat.add_le_add hUp hXp
  -- to the reals
  have hreal : ((O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) : ℕ) : ℝ) ≤
      ((2 ^ 30 * (N * bU) + 2 ^ 30 * (N * χ ^ 2) : ℕ) : ℝ) := by exact_mod_cast hnat
  refine hreal.trans (le_of_eq ?_)
  unfold bSpaceBound
  push_cast
  ring

/-- **The end inequality, general, in the parameter range** (`60 < χ`): the χ threshold holds when
`c (e c_mX + c_τX) + d_X ≤ 61 · 2^30`. -/
theorem o2f_final_gen_range {prog : List Expr} {r : ℕ → ℕ} {body0 : Expr}
    {D0 W0 ρ0 E0 m τ N bU χ cmU cmX dm cτU cτX dτ dX : ℕ}
    (hD : progDepth prog ≤ D0) (hD0 : D0 ≤ 123) (hW : fnWidth prog ≤ W0) (hr : r 0 ≤ ρ0)
    (hE : exprDepth body0 ≤ E0)
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hd : (4 * (D0 + 1) + 18) * ((E0 + 3) * dm + dτ) + o2fC D0 W0 ρ0 ≤ dX * (N * χ))
    (hχ : 60 < χ)
    (hU : (4 * (D0 + 1) + 18) * ((E0 + 3) * cmU + cτU) ≤ 2 ^ 30)
    (hX : (4 * (D0 + 1) + 18) * ((E0 + 3) * cmX + cτX) + dX ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) : ℕ) : ℝ) ≤ bSpaceBound 30 N bU χ := by
  refine o2f_final_gen hD hD0 hW hr hE hm hτ hd hU (hX.trans ?_)
  rw [Nat.mul_comm (2 ^ 30) χ]
  exact Nat.mul_le_mul_right _ (by omega)

/-! ## The instance `progDepth ≤ 60`, `fnWidth ≤ 10`, `r 0 ≤ 15`, `exprDepth body0 ≤ 60` -/

/-- `addTop prog ρ S ≤ 122 S + 195384` for `progDepth ≤ 60`, `fnWidth ≤ 10`, `ρ ≤ 15`. -/
theorem o2f_addTop_le {prog : List Expr} {ρ : ℕ} (S : ℕ) (hD : progDepth prog ≤ 60)
    (hW : fnWidth prog ≤ 10) (hρ : ρ ≤ 15) : O2B.addTop prog ρ S ≤ 122 * S + 195384 := by
  have h1 : 2 * (progDepth prog + 1) * S ≤ 122 * S := Nat.mul_le_mul_right _ (by omega)
  have h2 : (ρ + 1) * (progDepth prog + 1) * (frameC prog + 4) ≤ 16 * 61 * 200 :=
    Nat.mul_le_mul (Nat.mul_le_mul (by omega) (by omega)) (by unfold frameC posBits; omega)
  unfold O2B.addTop
  omega

/-- `bridgeAdd prog ρ S ≤ 262 S + 392500` for `progDepth ≤ 60`, `fnWidth ≤ 10`, `ρ ≤ 15` (the instance of
`o2f_bridgeAdd_le_gen`). -/
theorem o2f_bridgeAdd_le {prog : List Expr} {ρ : ℕ} (S : ℕ) (hD : progDepth prog ≤ 60)
    (hW : fnWidth prog ≤ 10) (hρ : ρ ≤ 15) : O2B.bridgeAdd prog ρ S ≤ 262 * S + 392500 := by
  refine (o2f_bridgeAdd_le_gen S hD (by norm_num) hW hρ).trans (Nat.add_le_add (le_of_eq ?_) o2fC_60_10_15)
  norm_num

/-- **The end inequality** (the instance `D0 = 60`, `W0 = 10`, `ρ0 = 15`, `E0 = 60` of `o2f_final_gen`, with the
N-free terms bounded by `N χ ≥ 1`). For budgets `m ≤ c_mU N b_𝒰 + c_mX N χ + d_m`, `τ ≤ c_τU N b_𝒰 + c_τX N χ + d_τ`:
the charge of the GST peak `(exprDepth body0 + 3) m + τ` is at most `bSpaceBound 30 N b_𝒰 χ`, provided the record
part `262 (63 c_mU + c_τU) ≤ 2^30` and the χ threshold `262 (63 c_mX + c_τX) + 262 (63 d_m + d_τ) + 392500 ≤ 2^30 χ`. -/
theorem o2f_final {prog : List Expr} {r : ℕ → ℕ} {body0 : Expr}
    {m τ N bU χ cmU cmX dm cτU cτX dτ : ℕ}
    (hD : progDepth prog ≤ 60) (hW : fnWidth prog ≤ 10) (hr : r 0 ≤ 15) (hE : exprDepth body0 ≤ 60)
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hN : 1 ≤ N)
    (hU : 262 * (63 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 262 * (63 * cmX + cτX) + 262 * (63 * dm + dτ) + 392500 ≤ 2 ^ 30 * χ) :
    ((O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) : ℕ) : ℝ) ≤ bSpaceBound 30 N bU χ := by
  have hχ1 : 1 ≤ χ := by
    rcases Nat.eq_zero_or_pos χ with h | h
    · rw [h, Nat.mul_zero] at hX
      exact absurd hX (by omega)
    · exact h
  have hNχ : 1 ≤ N * χ := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega) (by omega))
  have hd : (4 * (60 + 1) + 18) * ((60 + 3) * dm + dτ) + o2fC 60 10 15 ≤
      (262 * (63 * dm + dτ) + 392500) * (N * χ) :=
    calc (4 * (60 + 1) + 18) * ((60 + 3) * dm + dτ) + o2fC 60 10 15
        ≤ 262 * (63 * dm + dτ) + 392500 := by
          have e : (4 * (60 + 1) + 18) * ((60 + 3) * dm + dτ) = 262 * (63 * dm + dτ) := by norm_num
          rw [e]
          exact Nat.add_le_add_left o2fC_60_10_15 _
      _ ≤ (262 * (63 * dm + dτ) + 392500) * (N * χ) := Nat.le_mul_of_pos_right _ hNχ
  have hU' : (4 * (60 + 1) + 18) * ((60 + 3) * cmU + cτU) ≤ 2 ^ 30 := by
    have e : (4 * (60 + 1) + 18) * ((60 + 3) * cmU + cτU) = 262 * (63 * cmU + cτU) := by norm_num
    rw [e]
    exact hU
  have hX' : (4 * (60 + 1) + 18) * ((60 + 3) * cmX + cτX) + (262 * (63 * dm + dτ) + 392500) ≤
      2 ^ 30 * χ := by
    have e : (4 * (60 + 1) + 18) * ((60 + 3) * cmX + cτX) = 262 * (63 * cmX + cτX) := by norm_num
    rw [e, ← Nat.add_assoc]
    exact hX
  exact o2f_final_gen (D0 := 60) (W0 := 10) (ρ0 := 15) (E0 := 60) hD (by norm_num) hW hr hE hm hτ hd hU' hX'

/-- **The end inequality in the parameter range** (`60 < χ`): the χ threshold holds when
`262 (63 c_mX + c_τX) + 262 (63 d_m + d_τ) + 392500 ≤ 61 · 2^30`. -/
theorem o2f_final_range {prog : List Expr} {r : ℕ → ℕ} {body0 : Expr}
    {m τ N bU χ cmU cmX dm cτU cτX dτ : ℕ}
    (hD : progDepth prog ≤ 60) (hW : fnWidth prog ≤ 10) (hr : r 0 ≤ 15) (hE : exprDepth body0 ≤ 60)
    (hm : m ≤ cmU * (N * bU) + cmX * (N * χ) + dm)
    (hτ : τ ≤ cτU * (N * bU) + cτX * (N * χ) + dτ)
    (hN : 1 ≤ N) (hχ : 60 < χ)
    (hU : 262 * (63 * cmU + cτU) ≤ 2 ^ 30)
    (hX : 262 * (63 * cmX + cτX) + 262 * (63 * dm + dτ) + 392500 ≤ 61 * 2 ^ 30) :
    ((O2B.bridgeAdd prog (r 0) ((exprDepth body0 + 3) * m + τ) : ℕ) : ℝ) ≤ bSpaceBound 30 N bU χ := by
  refine o2f_final hD hW hr hE hm hτ hN hU (hX.trans ?_)
  rw [Nat.mul_comm (2 ^ 30) χ]
  exact Nat.mul_le_mul_right _ (by omega)

end F2e2e.BSpace.O2B
