import F2e2e.BSpace.MachineGstO

/-!
# B_space, route O2b, layer (i): the generic space theorem with per-call value bounds

Owner: C-SPACE (senior owner of O2b layer (i); technical lead of O2b: 17fc0802; implementer of the liftings:
O2B-GST 8cf19cc0, `F2e2e/BSpace/O2GstLift.lean`).

The generic space theorem of layer M (`F2e2e/BSpace/MachineGstO.lean`) charges every frame of the active call
chain `(K + 3) · M` for ONE uniform value bound `M` (the largest value of the whole run), hence a peak
`((r₀ + 1)(K + 3) + 1) · M`. Route O2b (Theorem_B_space with the paper's constant `2^30`) needs every frame to
pay only for the values it actually holds: the frames holding the big B state pay `M_big`, the inner ADA frames
their own (much smaller) bounds. Since shared library routines (`reverse`, `append`, …) are called on big and on
tiny lists, the bounds are attached to the CALLS, not to the function indices:

* `EvalsValF orc prog m τ env bits t v`: the oracle value judgment `EvalsValO` where `m` is the value bound of
  the current frame and `τ` the budget of everything the current frame's callees may add above it. A call
  `call i a` runs the body of `i` at its OWN bound and budget `(m', τ')`, with the argument `≤ m'`, the result
  `≤ m`, and `(exprDepth body + 2) · m' + τ' ≤ τ`; loops likewise (with `+ 3` for the accumulator). No rank
  certificate is needed: the budgets are part of the (finite) derivation.
* `callSp` / `loopSp` (requested by O2B-GST): a call or loop whose callee is given directly by a precise space
  derivation (`EvalsSpTO` / `LoopSpTO` within `base + P`, `P ≤ τ`), e.g. from a precise uniform GST of a heavy
  routine; the frames above it then pay the routine's exact peak instead of `(exprDepth body + 2) · m' + τ'`.
* `gst_auxF` / `EvalsValF.toSpTO`: an evaluation at `(m, τ)` in an environment of values `≤ m` produces a value
  `≤ m` and runs under `evalO` within peak `base + (exprDepth e + 2) · m + τ` (`EvalsSpTO` of layer M2).
* `EvalsValF.eval_entryF`, `runsOnO_of_evalsValF`, `ImplementsF`, `ImplementsF.runsOnO`: at the entry point the
  peak is `(exprDepth body + 3) · m + τ`, and the run is a `RunsOnO` (input of M3 / of the additive bridge).
* The `ImplementsF` calculus and further derived rules are in O2B-GST's `F2e2e/BSpace/O2GstLiftCalc.lean`.

With the lifting `EvalsValO.toF` (8cf19cc0: an `EvalsValO` evaluation at a uniform `M` with a rank certificate
`(r, K)` is an `EvalsValF` evaluation at `(M, ρ (K + 3) M)`), every routine proved at its own uniform bound plugs
in at that bound.
-/

namespace F2e2e.BSpace

open F2e2e.Cost

/-- **The per-call value judgment**: `EvalsValO` with the value bound `m` of the current frame and the budget
`τ` of its callee chain. -/
inductive EvalsValF (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) :
    ℕ → ℕ → List Val → List Bool → Expr ⊕ (ℕ × Val) → Val → Prop
  | var {m τ : ℕ} {env : List Val} {i : ℕ} {v : Val} (h : env[i]? = some v) :
      EvalsValF orc prog m τ env [] (.inl (Expr.var i)) v
  | lit {m τ : ℕ} {env : List Val} {z : ℤ} (hM : valSize (Val.int z) ≤ m) :
      EvalsValF orc prog m τ env [] (.inl (Expr.lit z)) (Val.int z)
  | nil {m τ : ℕ} {env : List Val} (hM : valSize (Val.list []) ≤ m) :
      EvalsValF orc prog m τ env [] (.inl Expr.nil) (Val.list [])
  | coin {m τ : ℕ} {env : List Val} (b : Bool) (hM : valSize (encB b) ≤ m) :
      EvalsValF orc prog m τ env [b] (.inl Expr.coin) (encB b)
  | bin {m τ : ℕ} {env : List Val} {op : BinOp} {a b : Expr} {ba bb : List Bool} {va vb v : Val} {c : ℕ}
      (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hb : EvalsValF orc prog m τ env bb (.inl b) vb)
      (hop : evalBin op va vb = some (v, c)) (hM : valSize v ≤ m) :
      EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.bin op a b)) v
  | un {m τ : ℕ} {env : List Val} {op : UnOp} {a : Expr} {ba : List Bool} {va v : Val} {c : ℕ}
      (ha : EvalsValF orc prog m τ env ba (.inl a) va) (hop : evalUn op va = some (v, c))
      (hM : valSize v ≤ m) :
      EvalsValF orc prog m τ env ba (.inl (Expr.un op a)) v
  | ite {m τ : ℕ} {env : List Val} {c t f : Expr} {bc bv : List Bool} {z : ℤ} {v : Val}
      (hc : EvalsValF orc prog m τ env bc (.inl c) (Val.int z))
      (hv : EvalsValF orc prog m τ env bv (.inl (if z ≠ 0 then t else f)) v) :
      EvalsValF orc prog m τ env (bc ++ bv) (.inl (Expr.ite c t f)) v
  | letE {m τ : ℕ} {env : List Val} {a b : Expr} {ba bb : List Bool} {va vb : Val}
      (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hb : EvalsValF orc prog m τ (va :: env) bb (.inl b) vb) :
      EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.letE a b)) vb
  | call {m τ m' τ' : ℕ} {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
      (hi : i ≠ bsOracleIdx) (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hbody : prog[i]? = some body) (hb : EvalsValF orc prog m' τ' [va] bb (.inl body) vb)
      (hva : valSize va ≤ m') (hvb : valSize vb ≤ m)
      (hτ : (exprDepth body + 2) * m' + τ' ≤ τ) :
      EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.call i a)) vb
  | oracle {m τ : ℕ} {env : List Val} {a : Expr} {ba : List Bool} {sel r q : ℤ}
      (ha : EvalsValF orc prog m τ env ba (.inl a) (Val.list [Val.int sel, Val.int r, Val.int q]))
      (hM : valSize (Val.int (orc sel r q)) ≤ m) :
      EvalsValF orc prog m τ env ba (.inl (Expr.call bsOracleIdx a)) (Val.int (orc sel r q))
  | loop {m τ m' τ' : ℕ} {env : List Val} {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val}
      (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hl : EvalsValF orc prog m' τ' [] bl (.inr (i, va)) w)
      (hva : valSize va ≤ m') (hw : valSize w ≤ m)
      (hτ : ∀ body, prog[i]? = some body → (exprDepth body + 3) * m' + τ' ≤ τ) :
      EvalsValF orc prog m τ env (ba ++ bl) (.inl (Expr.loop i a)) w
  /-- A call whose callee is given by a precise space derivation: the body of `i` runs on `[va]` within
  peak `P` above its frame base (e.g. from a precise uniform GST of the routine), `P ≤ τ`. -/
  | callSp {m τ P : ℕ} {env : List Val} {i : ℕ} {a body : Expr} {ba bb : List Bool} {va vb : Val}
      (hi : i ≠ bsOracleIdx) (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hbody : prog[i]? = some body)
      (hb : ∀ base, EvalsSpTO orc prog base [va] bb body vb (base + P))
      (hva : valSize va ≤ m) (hvb : valSize vb ≤ m) (hP : P ≤ τ) :
      EvalsValF orc prog m τ env (ba ++ bb) (.inl (Expr.call i a)) vb
  /-- A loop whose iterations are given by a precise space derivation: within peak `P` above the
  caller's base (the accumulator included), `P ≤ τ`. -/
  | loopSp {m τ P : ℕ} {env : List Val} {i : ℕ} {a : Expr} {ba bl : List Bool} {va w : Val}
      (ha : EvalsValF orc prog m τ env ba (.inl a) va)
      (hl : ∀ base, LoopSpTO orc prog base i va bl w (base + P))
      (hw : valSize w ≤ m) (hP : P ≤ τ) :
      EvalsValF orc prog m τ env (ba ++ bl) (.inl (Expr.loop i a)) w
  | stop {m τ : ℕ} {i : ℕ} {v : Val} {body : Expr} {bb : List Bool} {v' : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsValF orc prog m τ [v] bb (.inl body) (Val.list [Val.int 0, v'])) :
      EvalsValF orc prog m τ [] bb (.inr (i, v)) v'
  | cont {m τ : ℕ} {i : ℕ} {v : Val} {body : Expr} {bb bw : List Bool} {flag : ℤ} {v' w : Val}
      (hbody : prog[i]? = some body)
      (hb : EvalsValF orc prog m τ [v] bb (.inl body) (Val.list [Val.int flag, v']))
      (hflag : flag ≠ 0) (hrest : EvalsValF orc prog m τ [] bw (.inr (i, v')) w) :
      EvalsValF orc prog m τ [] (bb ++ bw) (.inr (i, v)) w

namespace EvalsValF

variable {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr}

/-- Monotonicity in the budget. -/
theorem mono_τ {m τ τ' : ℕ} {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValF orc prog m τ env bits t v) (hτ : τ ≤ τ') : EvalsValF orc prog m τ' env bits t v := by
  induction h generalizing τ' with
  | var hv => exact EvalsValF.var hv
  | lit h => exact EvalsValF.lit h
  | nil h => exact EvalsValF.nil h
  | coin b h => exact EvalsValF.coin b h
  | bin _ _ hop h iha ihb => exact EvalsValF.bin (iha hτ) (ihb hτ) hop h
  | un _ hop h iha => exact EvalsValF.un (iha hτ) hop h
  | ite _ _ ihc ihv => exact EvalsValF.ite (ihc hτ) (ihv hτ)
  | letE _ _ iha ihb => exact EvalsValF.letE (iha hτ) (ihb hτ)
  | call hi _ hbody hb hva hvb hτ' iha _ =>
    exact EvalsValF.call hi (iha hτ) hbody hb hva hvb (hτ'.trans hτ)
  | oracle _ h iha => exact EvalsValF.oracle (iha hτ) h
  | loop _ hl hva hw hτ' iha _ =>
    exact EvalsValF.loop (iha hτ) hl hva hw (fun body hbody => (hτ' body hbody).trans hτ)
  | callSp hi _ hbody hb hva hvb hP iha =>
    exact EvalsValF.callSp hi (iha hτ) hbody hb hva hvb (hP.trans hτ)
  | loopSp _ hl hw hP iha => exact EvalsValF.loopSp (iha hτ) hl hw (hP.trans hτ)
  | stop hbody _ ihb => exact EvalsValF.stop hbody (ihb hτ)
  | cont hbody _ hflag _ ihb ihr => exact EvalsValF.cont hbody (ihb hτ) hflag (ihr hτ)

/-- Monotonicity in the value bound of the current frame (and of its loop frames). -/
theorem mono_m {m m' τ : ℕ} {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValF orc prog m τ env bits t v) (hm : m ≤ m') : EvalsValF orc prog m' τ env bits t v := by
  induction h generalizing m' with
  | var hv => exact EvalsValF.var hv
  | lit h => exact EvalsValF.lit (h.trans hm)
  | nil h => exact EvalsValF.nil (h.trans hm)
  | coin b h => exact EvalsValF.coin b (h.trans hm)
  | bin _ _ hop h iha ihb => exact EvalsValF.bin (iha hm) (ihb hm) hop (h.trans hm)
  | un _ hop h iha => exact EvalsValF.un (iha hm) hop (h.trans hm)
  | ite _ _ ihc ihv => exact EvalsValF.ite (ihc hm) (ihv hm)
  | letE _ _ iha ihb => exact EvalsValF.letE (iha hm) (ihb hm)
  | call hi _ hbody hb hva hvb hτ iha _ =>
    exact EvalsValF.call hi (iha hm) hbody hb hva (hvb.trans hm) hτ
  | oracle _ h iha => exact EvalsValF.oracle (iha hm) (h.trans hm)
  | loop _ hl hva hw hτ iha _ => exact EvalsValF.loop (iha hm) hl hva (hw.trans hm) hτ
  | callSp hi _ hbody hb hva hvb hP iha =>
    exact EvalsValF.callSp hi (iha hm) hbody hb (hva.trans hm) (hvb.trans hm) hP
  | loopSp _ hl hw hP iha => exact EvalsValF.loopSp (iha hm) hl (hw.trans hm) hP
  | stop hbody _ ihb => exact EvalsValF.stop hbody (ihb hm)
  | cont hbody _ hflag _ ihb ihr => exact EvalsValF.cont hbody (ihb hm) hflag (ihr hm)

theorem cast_bits {m τ : ℕ} {env : List Val} {bits bits' : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValF orc prog m τ env bits t v) (hb : bits = bits') :
    EvalsValF orc prog m τ env bits' t v :=
  hb ▸ h

end EvalsValF

/-! ## The generic space theorem with per-call bounds -/

/-- The statement proved by induction on `EvalsValF`. -/
def GPropF (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (m τ : ℕ) (env : List Val) (bits : List Bool) :
    Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ w ∈ env, valSize w ≤ m) → valSize v ≤ m ∧
      ∀ base, EvalsSpTO orc prog base env bits e v (base + (exprDepth e + 2) * m + τ)
  | .inr (i, acc), w => valSize acc ≤ m → valSize w ≤ m ∧
      ∃ body, prog[i]? = some body ∧
        ∀ base, LoopSpTO orc prog base i acc bits w (base + (exprDepth body + 3) * m + τ)

theorem gst_auxF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}
    {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsValF orc prog m τ env bits t v) :
    GPropF orc prog m τ env bits t v := by
  induction h with
  | @var m τ env i v hv =>
    simp only [GPropF]
    intro henv
    have hv' : valSize v ≤ m := henv v (List.mem_of_getElem? hv)
    refine ⟨hv', fun base => (EvalsSpTO.var hv).mono ?_⟩
    simp only [exprDepth]
    nlinarith
  | @lit m τ env z hM =>
    simp only [GPropF]
    intro _
    refine ⟨hM, fun base => (EvalsSpTO.lit z).mono ?_⟩
    simp only [exprDepth]
    nlinarith
  | @nil m τ env hM =>
    simp only [GPropF]
    intro _
    refine ⟨hM, fun base => EvalsSpTO.nil.mono ?_⟩
    simp only [exprDepth]
    nlinarith
  | @coin m τ env b hM =>
    simp only [GPropF]
    intro _
    refine ⟨hM, fun base => (EvalsSpTO.coin b).mono ?_⟩
    simp only [exprDepth]
    nlinarith
  | @bin m τ env op a b ba bb va vb v c ha hb hop hM iha ihb =>
    simp only [GPropF] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    obtain ⟨hvb, hb'⟩ := ihb henv
    refine ⟨hM, fun base => ?_⟩
    have h1 := ha' base
    have h2 := hb' (base + valSize va)
    refine (EvalsSpTO.bin h1 h2 hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + max (exprDepth a) (exprDepth b) + 2
      by omega)
    have e2 := Nat.mul_le_mul_right m (show exprDepth b + 2 + 1 ≤ 1 + max (exprDepth a) (exprDepth b) + 2
      by omega)
    have e3 := Nat.mul_le_mul_right m (show 3 ≤ 1 + max (exprDepth a) (exprDepth b) + 2 by omega)
    have e2' : (exprDepth b + 2 + 1) * m = (exprDepth b + 2) * m + m := by ring
    exact max_le (max_le (by omega) (by omega)) (by omega)
  | @un m τ env op a ba va v c ha hop hM iha =>
    simp only [GPropF] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base => ?_⟩
    refine (EvalsSpTO.un (ha' base) hop).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    have e2 := Nat.mul_le_mul_right m (show 2 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @ite m τ env c t f bc bv z v hc hv ihc ihv =>
    simp only [GPropF] at ihc ihv ⊢
    intro henv
    obtain ⟨-, hc'⟩ := ihc henv
    obtain ⟨hvv, hv'⟩ := ihv henv
    refine ⟨hvv, fun base => ?_⟩
    have hbr : exprDepth (if z ≠ 0 then t else f) ≤ max (exprDepth t) (exprDepth f) := by
      split_ifs
      · exact le_max_left _ _
      · exact le_max_right _ _
    refine (EvalsSpTO.ite (hc' base) (hv' base)).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth c + 2 ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 by omega)
    have e2 := Nat.mul_le_mul_right m (show exprDepth (if z ≠ 0 then t else f) + 2 ≤
      1 + max (exprDepth c) (max (exprDepth t) (exprDepth f)) + 2 by omega)
    exact max_le (by omega) (by omega)
  | @letE m τ env a b ba bb va vb ha hb iha ihb =>
    simp only [GPropF] at iha ihb ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    have henv' : ∀ w ∈ va :: env, valSize w ≤ m := by
      intro w hw
      rcases List.mem_cons.mp hw with rfl | hw
      · exact hva
      · exact henv w hw
    obtain ⟨hvb, hb'⟩ := ihb henv'
    refine ⟨hvb, fun base => ?_⟩
    refine (EvalsSpTO.letE (ha' base) (hb' (base + valSize va))).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + max (exprDepth a) (exprDepth b) + 2
      by omega)
    have e2 := Nat.mul_le_mul_right m (show exprDepth b + 2 + 1 ≤ 1 + max (exprDepth a) (exprDepth b) + 2
      by omega)
    have e2' : (exprDepth b + 2 + 1) * m = (exprDepth b + 2) * m + m := by ring
    exact max_le (by omega) (by omega)
  | @call m τ m' τ' env i a body ba bb va vb hi ha hbody hb hva hvb hτ iha ihb =>
    simp only [GPropF] at iha ihb ⊢
    intro henv
    obtain ⟨hva', ha'⟩ := iha henv
    obtain ⟨-, hb'⟩ := ihb (by simpa using hva)
    refine ⟨hvb, fun base => ?_⟩
    refine (EvalsSpTO.call hi (ha' base) hbody (hb' (base + valSize va))).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    have e2 := Nat.mul_le_mul_right m (show 1 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @oracle m τ env a ba sel rr q ha hM iha =>
    simp only [GPropF] at iha ⊢
    intro henv
    obtain ⟨hva, ha'⟩ := iha henv
    refine ⟨hM, fun base => ?_⟩
    refine (EvalsSpTO.oracle (ha' base)).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    have e2 := Nat.mul_le_mul_right m (show 2 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @loop m τ m' τ' env i a ba bl va w ha hl hva hw hτ iha ihl =>
    simp only [GPropF] at iha ihl ⊢
    intro henv
    obtain ⟨hva', ha'⟩ := iha henv
    obtain ⟨-, body, hbody, hl'⟩ := ihl hva
    refine ⟨hw, fun base => ?_⟩
    refine (EvalsSpTO.loop (ha' base) (hl' base)).mono ?_
    have hτb := hτ body hbody
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @callSp m τ P env i a body ba bb va vb hi ha hbody hb hva hvb hP iha =>
    simp only [GPropF] at iha ⊢
    intro henv
    obtain ⟨-, ha'⟩ := iha henv
    refine ⟨hvb, fun base => ?_⟩
    refine (EvalsSpTO.call hi (ha' base) hbody (hb (base + valSize va))).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    have e2 := Nat.mul_le_mul_right m (show 1 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @loopSp m τ P env i a ba bl va w ha hl hw hP iha =>
    simp only [GPropF] at iha ⊢
    intro henv
    obtain ⟨-, ha'⟩ := iha henv
    refine ⟨hw, fun base => ?_⟩
    refine (EvalsSpTO.loop (ha' base) (hl base)).mono ?_
    simp only [exprDepth]
    have e1 := Nat.mul_le_mul_right m (show exprDepth a + 2 ≤ 1 + exprDepth a + 2 by omega)
    exact max_le (by omega) (by omega)
  | @stop m τ i v body bb v' hbody hb ihb =>
    simp only [GPropF] at ihb ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    refine ⟨?_, body, hbody, fun base => ?_⟩
    · rw [valSize_flag_pair] at hpair
      omega
    · refine (LoopSpTO.stop hbody (hb' (base + valSize v))).mono ?_
      have e1 : (exprDepth body + 3) * m = (exprDepth body + 2) * m + m := by ring
      omega
  | @cont m τ i v body bb bw flag v' w hbody hb hflag hrest ihb ihr =>
    simp only [GPropF] at ihb ihr ⊢
    intro hv
    obtain ⟨hpair, hb'⟩ := ihb (by simpa using hv)
    have hv' : valSize v' ≤ m := by
      rw [valSize_flag_pair] at hpair
      omega
    obtain ⟨hw, body', hbody', hr'⟩ := ihr hv'
    rw [hbody] at hbody'
    cases hbody'
    refine ⟨hw, body, hbody, fun base => ?_⟩
    refine (LoopSpTO.cont hbody (hb' (base + valSize v)) hflag (hr' base)).mono ?_
    have e1 : (exprDepth body + 3) * m = (exprDepth body + 2) * m + m := by ring
    exact max_le (by omega) le_rfl

/-- **Generic space theorem with per-call bounds.** -/
theorem EvalsValF.toSpTO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}
    {bits : List Bool} {e : Expr} {v : Val} (h : EvalsValF orc prog m τ env bits (.inl e) v)
    (henv : ∀ w ∈ env, valSize w ≤ m) (base : ℕ) :
    EvalsSpTO orc prog base env bits e v (base + (exprDepth e + 2) * m + τ) :=
  (gst_auxF h henv).2 base

/-- Produced values are `≤ m` (for environments of values `≤ m`). -/
theorem EvalsValF.val_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}
    {bits : List Bool} {e : Expr} {v : Val} (h : EvalsValF orc prog m τ env bits (.inl e) v)
    (henv : ∀ w ∈ env, valSize w ≤ m) : valSize v ≤ m :=
  (gst_auxF h henv).1

/-- **Entry point.** The entry body evaluated at `(m, τ)` on an input of size `≤ m`, consuming exactly
`bits`, runs under `evalO` on every tape `bits ++ rest`, leaving `rest`, within peak
`(exprDepth body + 3) · m + τ`. -/
theorem EvalsValF.eval_entryF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {body : Expr}
    {input out : Val} {bits : List Bool} (h : EvalsValF orc prog m τ [input] bits (.inl body) out)
    (hin : valSize input ≤ m) :
    ∃ fuel c p, p ≤ (exprDepth body + 3) * m + τ ∧
      ∀ rest, evalO orc prog fuel (valSize input) [input] (bits ++ rest) body =
        some (out, c, p, rest) := by
  have hS := h.toSpTO (by simpa using hin) (valSize input)
  obtain ⟨fuel, c, p, hp, hf⟩ := hS
  refine ⟨fuel, c, p, ?_, hf⟩
  have e1 : (exprDepth body + 3) * m = (exprDepth body + 2) * m + m := by ring
  omega

/-- **Entry point, `RunsOnO` form.** -/
theorem runsOnO_of_evalsValF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {body : Expr}
    (h0 : prog[0]? = some body) {input out : Val} {bits : List Bool}
    (h : EvalsValF orc prog m τ [input] bits (.inl body) out) (hin : valSize input ≤ m)
    (rest : List Bool) :
    RunsOnO orc prog input (bits ++ rest) out rest (((exprDepth body + 3) * m + τ : ℕ) : ℝ) := by
  obtain ⟨fuel, c, p, hp, hf⟩ := h.eval_entryF hin
  exact ⟨body, fuel, c, p, h0, hf rest, by exact_mod_cast hp⟩

/-! ## `ImplementsF` -/

/-- `ImplementsO` with per-call bounds: whenever `p` reads exactly `bits` and returns `a`, the evaluation of
`e` at `(m, τ)` consumes exactly `bits` and returns `enc a`. -/
def ImplementsF {α : Type} (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (m τ : ℕ) (env : List Val)
    (e : Expr) (enc : α → Val) (p : Discrete.BitProg α) : Prop :=
  ∀ bits a, p.run bits = some (a, []) → EvalsValF orc prog m τ env bits (.inl e) (enc a)

/-- **Entry point, bit-program form.** -/
theorem ImplementsF.runsOnO {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {body : Expr}
    (h0 : prog[0]? = some body) {input : Val} {α : Type} {enc : α → Val} {p : Discrete.BitProg α}
    (h : ImplementsF orc prog m τ [input] body enc p) (hin : valSize input ≤ m) {tape rest : List Bool}
    {a : α} (hrun : p.run tape = some (a, rest)) :
    RunsOnO orc prog input tape (enc a) rest (((exprDepth body + 3) * m + τ : ℕ) : ℝ) := by
  obtain ⟨bits, rfl, hb⟩ := bitProg_run_split hrun
  exact runsOnO_of_evalsValF h0 (h bits a hb) hin rest

end F2e2e.BSpace
