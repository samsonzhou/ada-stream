import F2e2e.Cost.MachineWork
import F2e2e.BSpace.MachineRunO

/-!
# O2b additive bridge, part 1: the step charge and the structural configuration bound (17fc0802)

Machine-level facts, independent of any simulation. They hold for the locked machine and the oracle machine
alike, because they speak only about configurations and the charge terms `stepWork` and `ctrlWork` of the locked
Spec.

**(a) Step charge by operand bits.** `opBits c` is the encoded size of the two integer operands of an arithmetic
step from `c` (a return `int b` to a `binR _ (int a)` frame), and `0` for every other configuration.
* `stepWork_le_opBits`: `stepWork prog c ≤ 8·opBits c + 64` (`Machine.opWork_le`, `arithC = 8`,
  `arithC' = 64`).
* `ctrlWork_le_opBits`: `ctrlWork prog c c' ≤ 64 + 4·⌈log₂(confBits c + confBits c' + 8·opBits c + 66)⌉`.
* `stepCharge_le`: the full charge of a step is at most
  `confBits c + confBits c' + 8·opBits c + 128 + 4·⌈log₂(confBits c + confBits c' + 8·opBits c + 66)⌉`.
* `runsWithinBitsO_of_bounds`: if every configuration of a halting oracle-machine run has at most `Bc` bits and
  `opBits ≤ 2·Bi`, the run is a `RunsWithinBitsO` run with bound
  `2·Bc + 16·Bi + 128 + 4·⌈log₂(2·Bc + 16·Bi + 66)⌉`. The coarse bridge had the factor
  `bridgeWC + 2 = 50` in front of `Bc`; here it is `2`.

**(b) Structural configuration bound.** `storedSize c` is the total `valSize` of the values stored in `c`: the
environment or value of the control, plus the environment or value saved by every frame, counted with
multiplicity. The bound uses `PosLe prog P c`: every code position in `c` encodes in at most `P` bits.
* `confBits_le_stored`: `confBits prog c ≤ 3·storedSize c + (#frames + 1)·(P + 6) + 2`, given `PosLe prog P c`.
* `posLe_of_pathLe`: positions with paths of length `≤ D` encode in `fnWidth prog + 3·D + 1` bits; for
  `D = progDepth prog` that is `posBits prog`.
-/

namespace F2e2e.BSpace.O2B

open F2e2e.Machine

/-! ## (a) The step charge by operand bits -/

/-- The encoded size of the two integer operands of an arithmetic step from `c`: at a return `int b` to a
`binR _ (int a)` frame, `|bitEncodeVal (int a)| + |bitEncodeVal (int b)|`; `0` for every other configuration. -/
def opBits (c : Conf) : ℕ :=
  match c.ctrl, c.stack with
  | Ctrl.ret (Val.int b), Frame.binR _ (Val.int a) :: _ =>
      (bitEncodeVal (Val.int a)).length + (bitEncodeVal (Val.int b)).length
  | _, _ => 0

theorem opBits_int (a b : ℤ) (p : CodePos) (K : List Frame) (t : List Bool) :
    opBits ⟨Ctrl.ret (Val.int b), Frame.binR p (Val.int a) :: K, t⟩ = 2 * bitLen a + 2 * bitLen b + 6 := by
  simp only [opBits, bitEncodeVal_int_length]
  omega

/-- The operands of an arithmetic step are stored in its configuration: `opBits c ≤ confBits prog c`. -/
theorem opBits_le_confBits (prog : List Expr) (c : Conf) : opBits c ≤ confBits prog c := by
  obtain ⟨ctrl, stack, t⟩ := c
  cases ctrl with
  | eval p env => simp [opBits]
  | ret v =>
    cases stack with
    | nil => simp [opBits]
    | cons f K =>
      cases f with
      | binR p va =>
        cases v with
        | int b =>
          cases va with
          | int a =>
            have := binR_operands_le prog (Val.int b) (Val.int a) p K t
            simp only [opBits]
            omega
          | list l => simp [opBits]
        | list l => cases va <;> simp [opBits]
      | binL p env => simp [opBits]
      | un p => simp [opBits]
      | ite p env => simp [opBits]
      | letE p env => simp [opBits]
      | callArg p => simp [opBits]
      | loopInit p => simp [opBits]
      | loopIter p => simp [opBits]

/-- **(a1)** The workspace of a step is bounded by its integer operands: `stepWork ≤ 8·opBits + 64`. -/
theorem stepWork_le_opBits (prog : List Expr) (c : Conf) : stepWork prog c ≤ 8 * opBits c + 64 := by
  obtain ⟨ctrl, stack, t⟩ := c
  cases ctrl with
  | eval p env => simp [stepWork]
  | ret v =>
    cases stack with
    | nil => simp [stepWork]
    | cons f K =>
      cases f with
      | binR p va =>
        simp only [stepWork]
        split
        · rename_i op _ _ _
          cases v with
          | int b =>
            cases va with
            | int a =>
              have h := opWork_le op (Val.int a) (Val.int b)
              simp only [arithC, arithC'] at h
              simp only [opBits]
              omega
            | list l => cases op <;> simp [opWork]
          | list l => cases op <;> cases va <;> simp [opWork]
        · omega
      | un p =>
        simp only [stepWork]
        split
        · rename_i op _ _
          cases op <;> simp [unWork]
        · omega
      | binL p env => simp [stepWork]
      | ite p env => simp [stepWork]
      | letE p env => simp [stepWork]
      | callArg p => simp [stepWork]
      | loopInit p => simp [stepWork]
      | loopIter p => simp [stepWork]

/-- **(a2)** The finite-control temporaries, with the workspace replaced by its operand bound. -/
theorem ctrlWork_le_opBits (prog : List Expr) (c c' : Conf) :
    ctrlWork prog c c' ≤
      64 + 4 * Nat.clog 2 (confBits prog c + confBits prog c' + 8 * opBits c + 66) := by
  unfold ctrlWork
  have h := stepWork_le_opBits prog c
  have hmono : Nat.clog 2 (confBits prog c + confBits prog c' + stepWork prog c + 2) ≤
      Nat.clog 2 (confBits prog c + confBits prog c' + 8 * opBits c + 66) :=
    Nat.clog_mono_right 2 (by omega)
  omega

/-- **(a3)** The full charge of a step from `c` to `c'` (footprint + workspace + control temporaries). -/
theorem stepCharge_le (prog : List Expr) (c c' : Conf) :
    confBits prog c + confBits prog c' + stepWork prog c + ctrlWork prog c c' ≤
      confBits prog c + confBits prog c' + 8 * opBits c + 128 +
        4 * Nat.clog 2 (confBits prog c + confBits prog c' + 8 * opBits c + 66) := by
  have h1 := stepWork_le_opBits prog c
  have h2 := ctrlWork_le_opBits prog c c'
  omega

/-- The step charge from uniform bounds `confBits ≤ Bc` (both ends) and `opBits ≤ 2·Bi`. -/
theorem stepCharge_le_of_bounds (prog : List Expr) {c c' : Conf} {Bc Bi : ℕ}
    (hc : confBits prog c ≤ Bc) (hc' : confBits prog c' ≤ Bc) (ho : opBits c ≤ 2 * Bi) :
    confBits prog c + confBits prog c' + stepWork prog c + ctrlWork prog c c' ≤
      2 * Bc + 16 * Bi + 128 + 4 * Nat.clog 2 (2 * Bc + 16 * Bi + 66) := by
  have h := stepCharge_le prog c c'
  have hmono : Nat.clog 2 (confBits prog c + confBits prog c' + 8 * opBits c + 66) ≤
      Nat.clog 2 (2 * Bc + 16 * Bi + 66) := Nat.clog_mono_right 2 (by omega)
  omega

open F2e2e.BSpace.MachineO in
/-- **(a4)** A halting oracle-machine run whose configurations all have at most `Bc` bits and whose arithmetic
operands have `opBits ≤ 2·Bi` is a `RunsWithinBitsO` run with bound
`2·Bc + 16·Bi + 128 + 4·⌈log₂(2·Bc + 16·Bi + 66)⌉`. -/
theorem runsWithinBitsO_of_bounds {orc : VOracle} {prog : List Expr} {input : Val} {tape : List Bool}
    {out : Val} {rest : List Bool} {n Bc Bi : ℕ}
    (hn : stepNO orc prog n (initConf input tape) = some ⟨Ctrl.ret out, [], rest⟩)
    (hb : ∀ k ≤ n, ∀ c : Conf, stepNO orc prog k (initConf input tape) = some c →
      confBits prog c ≤ Bc ∧ opBits c ≤ 2 * Bi) :
    RunsWithinBitsO orc prog input tape out rest
      ((2 * Bc + 16 * Bi + 128 + 4 * Nat.clog 2 (2 * Bc + 16 * Bi + 66) : ℕ) : ℝ) := by
  refine ⟨n, hn, fun k hk c c' hc hc' => ?_⟩
  have hc2 : stepNO orc prog (k + 1) (initConf input tape) = some c' := by
    rw [stepNO_add, hc]
    exact stepNO_one hc'
  obtain ⟨h1, h3⟩ := hb k hk.le c hc
  obtain ⟨h2, -⟩ := hb (k + 1) hk c' hc2
  exact_mod_cast stepCharge_le_of_bounds prog h1 h2 h3

/-! ## (b) The structural configuration bound -/

/-- The values stored in the control: its environment or its returned value. -/
def ctrlSize : Ctrl → ℕ
  | Ctrl.eval _ env => listSize env
  | Ctrl.ret v => valSize v

/-- The values saved by a frame: an environment (`binL`, `ite`, `letE`), a left operand (`binR`), or nothing. -/
def frameSize : Frame → ℕ
  | Frame.binL _ env => listSize env
  | Frame.binR _ v => valSize v
  | Frame.un _ => 0
  | Frame.ite _ env => listSize env
  | Frame.letE _ env => listSize env
  | Frame.callArg _ => 0
  | Frame.loopInit _ => 0
  | Frame.loopIter _ => 0

/-- The total size of the values stored in a configuration, counted with multiplicity: every saved copy of an
environment counts. -/
def storedSize (c : Conf) : ℕ := ctrlSize c.ctrl + (c.stack.map frameSize).sum

/-- The code position of a frame. -/
def framePos : Frame → CodePos
  | Frame.binL p _ => p
  | Frame.binR p _ => p
  | Frame.un p => p
  | Frame.ite p _ => p
  | Frame.letE p _ => p
  | Frame.callArg p => p
  | Frame.loopInit p => p
  | Frame.loopIter p => p

/-- Every code position of the configuration (that of an evaluating control and those of all frames) encodes
in at most `P` bits. -/
def PosLe (prog : List Expr) (P : ℕ) (c : Conf) : Prop :=
  (∀ p env, c.ctrl = Ctrl.eval p env → (encodePos prog p).length ≤ P) ∧
    ∀ f ∈ c.stack, (encodePos prog (framePos f)).length ≤ P

theorem ctrl_bits_le (prog : List Expr) {P : ℕ} {ctrl : Ctrl}
    (h : ∀ p env, ctrl = Ctrl.eval p env → (encodePos prog p).length ≤ P) :
    (encodeCtrl prog ctrl).length ≤ 3 * ctrlSize ctrl + P + 2 := by
  cases ctrl with
  | eval p env =>
    rw [encodeCtrl_eval_length]
    have h1 := h p env rfl
    have h2 := bitEncodeVals_length_le env
    simp only [ctrlSize]
    omega
  | ret v =>
    rw [encodeCtrl_ret_length]
    have h1 := bitEncodeVal_length_le v
    simp only [ctrlSize]
    omega

theorem frame_bits_le (prog : List Expr) {P : ℕ} (f : Frame)
    (h : (encodePos prog (framePos f)).length ≤ P) :
    (encodeFrame prog f).length + 1 ≤ 3 * frameSize f + P + 6 := by
  have e : (encodeFrame prog f).length + 1 = frameBits prog f := rfl
  rw [e]
  cases f with
  | binL p env =>
    rw [frameBits_binL]
    have := bitEncodeVals_length_le env
    simp only [frameSize, framePos] at h ⊢
    omega
  | binR p v =>
    rw [frameBits_binR]
    have := bitEncodeVal_length_le v
    simp only [frameSize, framePos] at h ⊢
    omega
  | un p =>
    rw [frameBits_un]
    simp only [frameSize, framePos] at h ⊢
    omega
  | ite p env =>
    rw [frameBits_ite]
    have := bitEncodeVals_length_le env
    simp only [frameSize, framePos] at h ⊢
    omega
  | letE p env =>
    rw [frameBits_letE]
    have := bitEncodeVals_length_le env
    simp only [frameSize, framePos] at h ⊢
    omega
  | callArg p =>
    rw [frameBits_callArg]
    simp only [frameSize, framePos] at h ⊢
    omega
  | loopInit p =>
    rw [frameBits_loopInit]
    simp only [frameSize, framePos] at h ⊢
    omega
  | loopIter p =>
    rw [frameBits_loopIter]
    simp only [frameSize, framePos] at h ⊢
    omega

theorem stack_bits_le (prog : List Expr) {P : ℕ} :
    ∀ K : List Frame, (∀ f ∈ K, (encodePos prog (framePos f)).length ≤ P) →
      (encodeStack prog K).length ≤ 3 * (K.map frameSize).sum + K.length * (P + 6) + 1
  | [], _ => by simp [encodeStack]
  | f :: K, h => by
    have hf := frame_bits_le prog f (h f (by simp))
    have hK := stack_bits_le prog K (fun g hg => h g (by simp [hg]))
    simp only [encodeStack, List.length_cons, List.length_append, List.map_cons, List.sum_cons]
    nlinarith

/-- **(b)** The structural bound: `confBits ≤ 3·storedSize + (#frames + 1)·(P + 6) + 2`. -/
theorem confBits_le_stored (prog : List Expr) {P : ℕ} {c : Conf} (h : PosLe prog P c) :
    confBits prog c ≤ 3 * storedSize c + (c.stack.length + 1) * (P + 6) + 2 := by
  rw [confBits_eq]
  have h1 := ctrl_bits_le prog h.1
  have h2 := stack_bits_le prog c.stack h.2
  simp only [storedSize]
  nlinarith

/-- Positions whose paths have length at most `D` encode in `fnWidth prog + 3·D + 1` bits. -/
theorem posLe_of_pathLe (prog : List Expr) {D : ℕ} {c : Conf}
    (hctrl : ∀ p env, c.ctrl = Ctrl.eval p env → p.path.length ≤ D)
    (hstack : ∀ f ∈ c.stack, (framePos f).path.length ≤ D) :
    PosLe prog (fnWidth prog + 3 * D + 1) c := by
  refine ⟨fun p env hp => ?_, fun f hf => ?_⟩
  · rw [encodePos_length]
    have := hctrl p env hp
    omega
  · rw [encodePos_length]
    have := hstack f hf
    omega

/-- For paths within the program depth the position bound is `posBits prog`. -/
theorem posLe_posBits (prog : List Expr) {c : Conf}
    (hctrl : ∀ p env, c.ctrl = Ctrl.eval p env → p.path.length ≤ progDepth prog)
    (hstack : ∀ f ∈ c.stack, (framePos f).path.length ≤ progDepth prog) :
    PosLe prog (posBits prog) c :=
  posLe_of_pathLe prog hctrl hstack

end F2e2e.BSpace.O2B
