import F2e2e.BSpace.RefineDefs
import F2e2e.BSpace.RefineRound
import F2e2e.BSpace.AssembleThread
import F2e2e.Spec

/-!
# B_space, layer R3 (B-ACC): the threaded core execution answers as the Spec's Algorithm 2

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §R (area lead W4). The mechanism of `Theorem_B_space` runs the core's
initialization `adaInit A` and then, in round `t`, the core round `bsCoreRound A st (vals t) (ls t) (us t) kind`
(`F2e2e/BSpace/RefineDefs.lean`) on the grid indices `vals t` and the endpoints `ls t`, `us t` of the request
`reqs t` (D2/D3: they are the data of the quantized request `quantReq A (reqs t)`), all on ONE random tape threaded
from run to run (C-TOP's `threadRun`/`threadOut`, `F2e2e/BSpace/AssembleThread.lean`).

* `alg2Exec_response_of_steps`: the replay fold of the Spec's `alg2Exec` along any sequence of Spec states and
  tapes that the initialization and the rounds `0, …, t` produce one after the other;
* **R3** `refine_exec`: if round `t` of the threaded core execution on `List.ofFn ω` outputs `r`, then the Spec's
  `alg2Mech M J R aReq ξReq c` answers round `t` (views of the rounds `0, …, t`, coins `ω`) with `outRespV2 r`.
  (B-ARCH's R2 `refine_init` and R1 `refine_interval`/`refine_numerical`, `F2e2e/BSpace/RefineRound.lean`, along
  the simulation relation `StCorr`.)

The views `fun j => ((fun ℓ => (reqs j).1 (s ℓ)), (reqs j).2)` are §7's `viewsOf s reqs t` (by definition).
-/

namespace F2e2e.BSpace

open F2e2e.Discrete F2e2e.B F2e2e.B.V2

/-! ## The replay fold of `alg2Exec` -/

theorem ofFn_val_eq_map_range {α : Type} (g : ℕ → α) (n : ℕ) :
    List.ofFn (fun j : Fin n => g j.val) = (List.range n).map g := by
  apply List.ext_getElem
  · simp
  · intro i h1 h2
    simp

/-- **The replay fold of `alg2Exec`.** If the Spec's initialization on `List.ofFn ω` gives `(st2 0, tapes 0)` and
every round `k ≤ t` maps `(st2 k, tapes k)` on the view `views k` to `(resp k, st2 (k + 1), tapes (k + 1))`, then
the response of `alg2Exec` in round `t` (views of the rounds `0, …, t`) is `resp t`. -/
theorem alg2Exec_response_of_steps (P2 : F2e2e.Alg2Params) {c : ℕ} (ω : Fin c → Bool)
    (views : ℕ → F2e2e.VView P2.N) (st2 : ℕ → F2e2e.Alg2State) (tapes : ℕ → List Bool)
    (resp : ℕ → F2e2e.VResponse) (t : ℕ)
    (h0 : F2e2e.alg2Init P2 (List.ofFn ω) = (st2 0, tapes 0))
    (hstep : ∀ k ≤ t, F2e2e.alg2Request P2 (st2 k) (views k) (tapes k) =
      (resp k, st2 (k + 1), tapes (k + 1))) :
    (F2e2e.alg2Exec P2 t (fun j => views j.val) ω).response = resp t := by
  have hfold : ∀ n ≤ t + 1,
      ((List.range n).map views).foldl (fun acc v => F2e2e.alg2Request P2 acc.2.1 v acc.2.2)
        (F2e2e.VResponse.accept, st2 0, tapes 0) =
      ((if n = 0 then F2e2e.VResponse.accept else resp (n - 1)), st2 n, tapes n) := by
    intro n hn
    induction n with
    | zero => rfl
    | succ n ih =>
      rw [List.range_succ, List.map_append, List.foldl_append, ih (by omega)]
      simp only [List.map_cons, List.map_nil, List.foldl_cons, List.foldl_nil]
      rw [hstep n (by omega)]
      simp
  have h1 : (F2e2e.alg2Init P2 (List.ofFn ω)).1 = st2 0 := by rw [h0]
  have h2 : (F2e2e.alg2Init P2 (List.ofFn ω)).2 = tapes 0 := by rw [h0]
  unfold F2e2e.alg2Exec
  dsimp only
  rw [h1, h2, ofFn_val_eq_map_range, hfold (t + 1) le_rfl]
  simp

/-- The Spec states along the views `views` and the tapes `tapes`, from `st0`. -/
noncomputable def specStates (P2 : F2e2e.Alg2Params) (views : ℕ → F2e2e.VView P2.N)
    (tapes : ℕ → List Bool) (st0 : F2e2e.Alg2State) : ℕ → F2e2e.Alg2State
  | 0 => st0
  | k + 1 => (F2e2e.alg2Request P2 (specStates P2 views tapes st0 k) (views k) (tapes k)).2.1

/-! ## Threaded runs: the states, tapes and outputs of the rounds -/

section thread

variable {σ ρ : Type} {init : BitProg σ} {round : ℕ → σ → BitProg (ρ × σ)} {tape : List Bool}

theorem threadRun_isSome_of_le {t : ℕ} (h : (threadRun init round tape t).isSome) :
    ∀ k ≤ t, (threadRun init round tape k).isSome := by
  induction t with
  | zero =>
    intro k hk
    obtain rfl : k = 0 := by omega
    exact h
  | succ t ih =>
    intro k hk
    rcases Nat.lt_or_ge k (t + 1) with hlt | hge
    · exact ih (threadRun_isSome_of_succ h) k (by omega)
    · obtain rfl : k = t + 1 := by omega
      exact h

theorem threadOut_step {k : ℕ} {st : σ} {τ : List Bool} {o : ρ}
    (h : threadRun init round tape k = some (st, τ)) (ho : threadOut init round tape k = some o) :
    ∃ st' τ', (round k st).run τ = some ((o, st'), τ') ∧
      threadRun init round tape (k + 1) = some (st', τ') := by
  rw [threadOut_of h] at ho
  cases hrun : (round k st).run τ with
  | none => rw [hrun] at ho; simp at ho
  | some x =>
    rw [hrun] at ho
    obtain ⟨⟨o', st'⟩, τ'⟩ := x
    simp only [Option.map_some, Option.some.injEq] at ho
    subst ho
    refine ⟨st', τ', rfl, ?_⟩
    rw [threadRun_succ_of h, hrun]
    rfl

theorem threadOut_isSome_of_succ {k : ℕ} (h : (threadRun init round tape (k + 1)).isSome) :
    (threadOut init round tape k).isSome := by
  have hk := threadRun_isSome_of_succ h
  obtain ⟨⟨st, τ⟩, hst⟩ := Option.isSome_iff_exists.mp hk
  rw [threadRun_succ_of hst, Option.isSome_map] at h
  rw [threadOut_of hst, Option.isSome_map]
  exact h

end thread

/-! ## R3 -/

/-- **R3, for corresponding parameters.** Let the parameter records `P2` (Spec) and `A` (core) correspond, and let the
round inputs be the data of the quantized requests (`vals t` the grid indices of `reqs t` on the sample, `ls t`,
`us t` its grid endpoints; D2/D3). If round `t` of the threaded core execution (`adaInit A`, then
`bsCoreRound A · (vals k) (ls k) (us k) (reqs k).2.1` for `k = 0, 1, …`) on the tape `List.ofFn ω` outputs `r`,
then the Spec's `alg2Exec P2` answers round `t` on the views of the rounds `0, …, t` and the coins `ω` with
`outRespV2 r`. -/
theorem refine_exec_of {U : Type} {P2 : F2e2e.Alg2Params} {A : AdaParams} (hP : ParCorr P2 A)
    (hN : P2.N = A.N) {c : ℕ} (ω : Fin c → Bool) (s : Fin P2.N → U)
    (reqs : ℕ → (U → ℝ) × Bool × ℝ × ℝ) (hreqs : ∀ t x, 0 ≤ (reqs t).1 x ∧ (reqs t).1 x ≤ 1)
    (vals : ℕ → List (List ℕ)) (ls us : ℕ → ℚ)
    (hvals : ∀ t, vals t = coreVals A (castSample hN s) (quantReq A (reqs t)))
    (hl : ∀ t, ls t = (quantReq A (reqs t)).l) (hu : ∀ t, us t = (quantReq A (reqs t)).u)
    (t : ℕ) (r : CoreOut)
    (hr : threadOut (adaInit A) (fun k st => bsCoreRound A st (vals k) (ls k) (us k) (reqs k).2.1)
      (List.ofFn ω) t = some r) :
    (F2e2e.alg2Exec P2 t (fun j => ((fun ℓ => (reqs j.val).1 (s ℓ)), (reqs j.val).2)) ω).response =
      outRespV2 r := by
  set rnd : ℕ → AdaState → BitProg (CoreOut × AdaState) :=
    fun k st => bsCoreRound A st (vals k) (ls k) (us k) (reqs k).2.1 with hrnd
  set τ := List.ofFn ω with hτ
  -- the threaded run exists up to round `t`
  have hsomeT : (threadRun (adaInit A) rnd τ t).isSome := by
    unfold threadOut at hr
    cases h : threadRun (adaInit A) rnd τ t with
    | none => rw [h] at hr; simp at hr
    | some p => rfl
  obtain ⟨⟨stT, τT⟩, hT⟩ := Option.isSome_iff_exists.mp hsomeT
  -- the core states, tapes and outputs
  set cst : ℕ → AdaState := fun k => ((threadRun (adaInit A) rnd τ k).map Prod.fst).getD stT
    with hcst
  set ctp : ℕ → List Bool := fun k => ((threadRun (adaInit A) rnd τ k).map Prod.snd).getD []
    with hctp
  set cout : ℕ → CoreOut := fun k => (threadOut (adaInit A) rnd τ k).getD r with hcout
  have hrunk : ∀ k ≤ t, threadRun (adaInit A) rnd τ k = some (cst k, ctp k) := by
    intro k hk
    obtain ⟨⟨a, b⟩, hab⟩ := Option.isSome_iff_exists.mp (threadRun_isSome_of_le hsomeT k hk)
    simp only [hcst, hctp, hab, Option.map_some, Option.getD_some]
  have hcoutT : cout t = r := by simp only [hcout, hr, Option.getD_some]
  -- every round `k ≤ t` of the core
  have hstepk : ∀ k ≤ t, (rnd k (cst k)).run (ctp k) = some ((cout k, cst (k + 1)), ctp (k + 1)) := by
    intro k hk
    have hout : ∃ o, threadOut (adaInit A) rnd τ k = some o := by
      rcases Nat.lt_or_ge k t with hlt | hge
      · exact Option.isSome_iff_exists.mp
          (threadOut_isSome_of_succ (threadRun_isSome_of_le hsomeT (k + 1) (by omega)))
      · obtain rfl : k = t := by omega
        exact ⟨r, hr⟩
    obtain ⟨o, ho⟩ := hout
    have hco : cout k = o := by simp only [hcout, ho, Option.getD_some]
    obtain ⟨st', τ', hrun, hnext⟩ := threadOut_step (hrunk k hk) ho
    have h1 : cst (k + 1) = st' := by simp only [hcst, hnext, Option.map_some, Option.getD_some]
    have h2 : ctp (k + 1) = τ' := by simp only [hctp, hnext, Option.map_some, Option.getD_some]
    rw [hco, h1, h2]
    exact hrun
  -- the Spec side
  set views : ℕ → F2e2e.VView P2.N := fun k => ((fun ℓ => (reqs k).1 (s ℓ)), (reqs k).2) with hviews
  have hinit : (adaInit A).run τ = some (cst 0, ctp 0) := hrunk 0 (Nat.zero_le _)
  obtain ⟨hst0, htp0⟩ := refine_init hP hinit
  set st2 : ℕ → F2e2e.Alg2State := specStates P2 views ctp (F2e2e.alg2Init P2 τ).1 with hst2
  have hst2succ : ∀ k, st2 (k + 1) = (F2e2e.alg2Request P2 (st2 k) (views k) (ctp k)).2.1 :=
    fun k => rfl
  -- one round: the core round and the Spec's request agree
  have hone : ∀ k ≤ t, StCorr A (st2 k) (cst k) →
      F2e2e.alg2Request P2 (st2 k) (views k) (ctp k) = (outRespV2 (cout k), st2 (k + 1), ctp (k + 1)) ∧
        StCorr A (st2 (k + 1)) (cst (k + 1)) := by
    intro k hk hst
    have hrun := hstepk k hk
    simp only [hrnd] at hrun
    cases hI : (reqs k).2.1 with
    | true =>
      rw [hI, bsCoreRound_true, BitProg.run_map] at hrun
      cases hx : (adaInterval A (cst k) (vals k) (ls k) (us k)).run (ctp k) with
      | none => rw [hx] at hrun; simp at hrun
      | some x =>
        rw [hx] at hrun
        obtain ⟨⟨cc, st'⟩, τ'⟩ := x
        simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hrun
        obtain ⟨⟨hc, hs⟩, ht⟩ := hrun
        rw [hvals k, hl k, hu k, hs, ht] at hx
        obtain ⟨st2', h1, h2⟩ := refine_interval hP hN hst s (reqs k) (hreqs k) hI hx
        have h3 : st2 (k + 1) = st2' := by rw [hst2succ k]; exact congrArg (fun x => x.2.1) h1
        refine ⟨?_, h3 ▸ h2⟩
        rw [h3, ← hc]
        exact h1
    | false =>
      rw [hI, bsCoreRound_false, BitProg.run_map] at hrun
      cases hx : (adaNumerical A (cst k) (vals k)).run (ctp k) with
      | none => rw [hx] at hrun; simp at hrun
      | some x =>
        rw [hx] at hrun
        obtain ⟨⟨xx, st'⟩, τ'⟩ := x
        simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hrun
        obtain ⟨⟨hc, hs⟩, ht⟩ := hrun
        rw [hvals k, hs, ht] at hx
        obtain ⟨st2', h1, h2⟩ := refine_numerical hP hN hst s (reqs k) (hreqs k) hI hx
        have h3 : st2 (k + 1) = st2' := by rw [hst2succ k]; exact congrArg (fun x => x.2.1) h1
        refine ⟨?_, h3 ▸ h2⟩
        rw [h3, ← hc]
        exact h1
  have hall : ∀ k ≤ t, StCorr A (st2 k) (cst k) := by
    intro k
    induction k with
    | zero => intro _; exact hst0
    | succ k ih => intro hk; exact (hone k (by omega) (ih (by omega))).2
  have hsteps : ∀ k ≤ t, F2e2e.alg2Request P2 (st2 k) (views k) (ctp k) =
      (outRespV2 (cout k), st2 (k + 1), ctp (k + 1)) :=
    fun k hk => (hone k hk (hall k hk)).1
  have h0 : F2e2e.alg2Init P2 τ = (st2 0, ctp 0) := by
    rw [← htp0]
    rfl
  have hres := alg2Exec_response_of_steps P2 ω views st2 ctp (fun k => outRespV2 (cout k)) t h0 hsteps
  rw [hcoutT] at hres
  exact hres

/-- **R3 (the threaded execution answers as `alg2Mech`).** For the core parameters
`A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R` of `Theorem_B_space` and the data of the quantized requests
as round inputs (D2/D3): if round `t` of the threaded core execution on the tape `List.ofFn ω` outputs `r`, then the
Spec's `alg2Mech M J R aReq ξReq c` answers round `t` on the views of the rounds `0, …, t` (§7's
`viewsOf s reqs t`) and the coins `ω` with `outRespV2 r`. -/
theorem refine_exec {U : Type} (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (c : ℕ) (ω : Fin c → Bool)
    (s : Fin (F2e2e.alg2Params M J R aReq ξReq).N → U) (reqs : ℕ → (U → ℝ) × Bool × ℝ × ℝ)
    (hreqs : ∀ t x, 0 ≤ (reqs t).1 x ∧ (reqs t).1 x ≤ 1)
    (vals : ℕ → List (List ℕ)) (ls us : ℕ → ℚ)
    (hvals : ∀ t, vals t = coreVals (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)))
    (hl : ∀ t, ls t =
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)).l)
    (hu : ∀ t, us t =
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)).u)
    (t : ℕ) (r : CoreOut)
    (hr : threadOut (adaInit (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R))
      (fun k st => bsCoreRound (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) st
        (vals k) (ls k) (us k) (reqs k).2.1) (List.ofFn ω) t = some r) :
    F2e2e.alg2Mech M J R aReq ξReq c t
      (fun j => ((fun ℓ => (reqs j.val).1 (s ℓ)), (reqs j.val).2)) ω = outRespV2 r :=
  refine_exec_of (refine_parCorr M J R ha0 ha1 hξ0 hξ1) (refine_N M J R ha0 ha1 hξ0 hξ1) ω s reqs
    hreqs vals ls us hvals hl hu t r hr

/-- **R3 in the terms of §7** (`VReq`, `VReq.Valid`, `viewsOf`): the response of round `t` of the threaded core
execution is the Spec's `alg2Mech M J R aReq ξReq c t (viewsOf s reqs t) ω`. -/
theorem refine_exec_viewsOf {U : Type} (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq)
    (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) (c : ℕ) (ω : Fin c → Bool)
    (s : Fin (F2e2e.alg2Params M J R aReq ξReq).N → U) (reqs : ℕ → VReq U) (hreqs : ∀ t, (reqs t).Valid)
    (vals : ℕ → List (List ℕ)) (ls us : ℕ → ℚ)
    (hvals : ∀ t, vals t = coreVals (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (castSample (refine_N M J R ha0 ha1 hξ0 hξ1) s)
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)))
    (hl : ∀ t, ls t =
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)).l)
    (hu : ∀ t, us t =
      (quantReq (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) (reqs t)).u)
    (t : ℕ) (r : CoreOut)
    (hr : threadOut (adaInit (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R))
      (fun k st => bsCoreRound (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) st
        (vals k) (ls k) (us k) (reqs k).2.1) (List.ofFn ω) t = some r) :
    F2e2e.alg2Mech M J R aReq ξReq c t (viewsOf s reqs t) ω = outRespV2 r :=
  refine_exec M J R ha0 ha1 hξ0 hξ1 c ω s reqs (fun t x => (hreqs t).1 x) vals ls us hvals hl hu t r hr

end F2e2e.BSpace
