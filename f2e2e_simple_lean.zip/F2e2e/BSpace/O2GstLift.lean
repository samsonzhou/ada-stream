import F2e2e.BSpace.O2GstF

/-!
# B_space, route O2b, layer (i): liftings into the per-call judgment `EvalsValF`

Owner: O2B-GST (8cf19cc0), for the O2b technical lead 17fc0802; the judgment `EvalsValF` and its generic space
theorem are C-SPACE's (`F2e2e/BSpace/O2GstF.lean`, senior owner of O2b layer (i)).

A routine proved with the uniform-`M` value judgment (`EvalsValO`, or the oracle-free `EvalsVal` /
`Implements` of `F2e2e/Cost/Generic.lean`) plugs into a per-call derivation at the frame bound `M`, with a callee
budget computed from a certificate of the program's call graph:

* `EvalsValO.toF` (rank certificate `RankOK prog r K`, the statement fixed by C-SPACE): budget `ρ (K + 3) M`
  when every callee of `e` has rank `< ρ`; `EvalsValO.toF_loop` for loop targets.
* `EvalsValO.toF_wt` (**weight certificate** `WeightOK prog w`, tighter): budget `C · M` when every callee of
  `e` has weight `≤ C`. A weight function assigns to every routine `j` a number with
  `w j ≥ exprDepth body_j + 3 + w k` for every callee `k` of `body_j`; the smallest one is the weighted length
  `Σ (exprDepth + 3)` of the deepest call chain below `j`, so a call to `j` costs `≤ w j · M` instead of
  `(r j + 1)(K + 3) · M` with the global depth bound `K` (`weightOK_of_rankOK`: every rank certificate gives a
  weight certificate).
* `EvalsValO.toF_callFree`: an expression without calls of program routines (only the oracle) lifts with
  every budget, no certificate.
* The same for `ImplementsO` (`ImplementsO.toF`, `ImplementsO.toF_wt`) and for the oracle-free `EvalsVal` /
  `Implements` on programs without a body at the oracle index (`EvalsVal.toF`, `Implements.toF`, …).
* `EvalsValO.val_le_env`, `EvalsValO.loop_val_le`: produced values are `≤ M` (no certificate needed).

Use in a native per-call proof (a frame holding the big B state at bound `m`): every sub-computation of the frame
that only calls light routines is proved with the uniform calculus at `M = m` and embedded by `toF_wt_le`
(budget `C · m ≤ τ`); only the calls of heavy routines use `EvalsValF.call` with the callee's own `(m', τ')`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Discrete

/-! ## Value bounds of `EvalsValO` without a certificate -/

/-- The statement proved by induction: produced values are `≤ M` when the environment (resp. the loop
accumulator) is. -/
def ValLeO (M : ℕ) (env : List Val) : Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl _, v => (∀ w ∈ env, valSize w ≤ M) → valSize v ≤ M
  | .inr (_, acc), w => valSize acc ≤ M → valSize w ≤ M

theorem EvalsValO.valLeO_aux {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsValO orc prog M env bits t v) :
    ValLeO M env t v := by
  induction h with
  | var hv => exact fun henv => henv _ (List.mem_of_getElem? hv)
  | lit hM => exact fun _ => hM
  | nil hM => exact fun _ => hM
  | coin b hM => exact fun _ => hM
  | bin _ _ _ hM _ _ => exact fun _ => hM
  | un _ _ hM _ => exact fun _ => hM
  | ite _ _ _ ihv => exact fun henv => ihv henv
  | @letE env a b ba bb va vb _ _ iha ihb =>
    intro henv
    have hva : valSize va ≤ M := iha henv
    refine ihb fun w hw => ?_
    rcases List.mem_cons.mp hw with rfl | hw
    · exact hva
    · exact henv w hw
  | call _ _ _ _ iha ihb => exact fun henv => ihb (by simpa using iha henv)
  | oracle _ hM _ => exact fun _ => hM
  | loop _ _ iha ihl => exact fun henv => ihl (iha henv)
  | stop _ _ ihb =>
    intro hv
    have h1 := ihb (by simpa using hv)
    rw [valSize_flag_pair] at h1
    omega
  | cont _ _ _ _ ihb ihr =>
    intro hv
    have h1 := ihb (by simpa using hv)
    rw [valSize_flag_pair] at h1
    exact ihr (by omega)

/-- Produced values are `≤ M` for environments of values `≤ M` (no certificate needed). -/
theorem EvalsValO.val_le_env {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {e : Expr} {v : Val} (h : EvalsValO orc prog M env bits (.inl e) v)
    (henv : ∀ w ∈ env, valSize w ≤ M) : valSize v ≤ M :=
  EvalsValO.valLeO_aux h henv

/-- The output of loop iterations is `≤ M` when the accumulator is. -/
theorem EvalsValO.loop_val_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {i : ℕ} {acc w : Val} (h : EvalsValO orc prog M env bits (.inr (i, acc)) w)
    (hacc : valSize acc ≤ M) : valSize w ≤ M :=
  EvalsValO.valLeO_aux h hacc

/-- Loop iterations of `i` exist only if `i` has a body. -/
theorem EvalsValO.loop_body_exists {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {i : ℕ} {acc w : Val} (h : EvalsValO orc prog M env bits (.inr (i, acc)) w) :
    ∃ body, prog[i]? = some body := by
  cases h with
  | stop hbody _ => exact ⟨_, hbody⟩
  | cont hbody _ _ _ => exact ⟨_, hbody⟩

/-! ## Weights -/

/-- Every function called or looped by `e` has weight `≤ C` (the analogue of `CalleesLt` for weights). -/
def CalleesLe (w : ℕ → ℕ) (C : ℕ) : Expr → Prop
  | Expr.var _ => True
  | Expr.lit _ => True
  | Expr.nil => True
  | Expr.coin => True
  | Expr.bin _ a b => CalleesLe w C a ∧ CalleesLe w C b
  | Expr.un _ a => CalleesLe w C a
  | Expr.ite c t f => CalleesLe w C c ∧ CalleesLe w C t ∧ CalleesLe w C f
  | Expr.letE a b => CalleesLe w C a ∧ CalleesLe w C b
  | Expr.call j a => w j ≤ C ∧ CalleesLe w C a
  | Expr.loop j a => w j ≤ C ∧ CalleesLe w C a

/-- Boolean version of `CalleesLe`. -/
def calleesLeB (w : ℕ → ℕ) (C : ℕ) : Expr → Bool
  | Expr.var _ => true
  | Expr.lit _ => true
  | Expr.nil => true
  | Expr.coin => true
  | Expr.bin _ a b => calleesLeB w C a && calleesLeB w C b
  | Expr.un _ a => calleesLeB w C a
  | Expr.ite c t f => calleesLeB w C c && (calleesLeB w C t && calleesLeB w C f)
  | Expr.letE a b => calleesLeB w C a && calleesLeB w C b
  | Expr.call j a => decide (w j ≤ C) && calleesLeB w C a
  | Expr.loop j a => decide (w j ≤ C) && calleesLeB w C a

theorem calleesLeB_iff (w : ℕ → ℕ) (C : ℕ) (e : Expr) : calleesLeB w C e = true ↔ CalleesLe w C e := by
  induction e with
  | var => simp [calleesLeB, CalleesLe]
  | lit => simp [calleesLeB, CalleesLe]
  | nil => simp [calleesLeB, CalleesLe]
  | coin => simp [calleesLeB, CalleesLe]
  | bin op a b iha ihb => simp [calleesLeB, CalleesLe, iha, ihb]
  | un op a iha => simp [calleesLeB, CalleesLe, iha]
  | ite c t f ihc iht ihf => simp [calleesLeB, CalleesLe, ihc, iht, ihf]
  | letE a b iha ihb => simp [calleesLeB, CalleesLe, iha, ihb]
  | call j a iha => simp [calleesLeB, CalleesLe, iha]
  | loop j a iha => simp [calleesLeB, CalleesLe, iha]

/-- `CalleesLe` is monotone in the bound. -/
theorem CalleesLe.mono {w : ℕ → ℕ} {C C' : ℕ} {e : Expr} (h : CalleesLe w C e) (hC : C ≤ C') :
    CalleesLe w C' e := by
  induction e with
  | var => trivial
  | lit => trivial
  | nil => trivial
  | coin => trivial
  | bin op a b iha ihb => exact ⟨iha h.1, ihb h.2⟩
  | un op a iha => exact iha h
  | ite c t f ihc iht ihf => exact ⟨ihc h.1, iht h.2.1, ihf h.2.2⟩
  | letE a b iha ihb => exact ⟨iha h.1, ihb h.2⟩
  | call j a iha => exact ⟨h.1.trans hC, iha h.2⟩
  | loop j a iha => exact ⟨h.1.trans hC, iha h.2⟩

/-- From ranks to weights: if every callee has rank `< ρ`, and every routine of rank `< ρ` has weight `≤ C`,
then every callee has weight `≤ C`. -/
theorem calleesLe_of_calleesLt {r : ℕ → ℕ} {ρ : ℕ} {w : ℕ → ℕ} {C : ℕ} {e : Expr}
    (h : CalleesLt r ρ e) (hw : ∀ j, r j < ρ → w j ≤ C) : CalleesLe w C e := by
  induction e with
  | var => trivial
  | lit => trivial
  | nil => trivial
  | coin => trivial
  | bin op a b iha ihb => exact ⟨iha h.1, ihb h.2⟩
  | un op a iha => exact iha h
  | ite c t f ihc iht ihf => exact ⟨ihc h.1, iht h.2.1, ihf h.2.2⟩
  | letE a b iha ihb => exact ⟨iha h.1, ihb h.2⟩
  | call j a iha => exact ⟨hw j h.1, iha h.2⟩
  | loop j a iha => exact ⟨hw j h.1, iha h.2⟩

/-- **Weight certificate.** Every routine `j` has weight at least `exprDepth body_j + 3` plus the weight of
each of its callees. (The smallest such `w` is the weighted length `Σ (exprDepth + 3)` of the deepest call
chain below `j`; it exists iff the call graph is acyclic.) -/
def WeightOK (prog : List Expr) (w : ℕ → ℕ) : Prop :=
  ∀ j body, prog[j]? = some body →
    exprDepth body + 3 ≤ w j ∧ CalleesLe w (w j - (exprDepth body + 3)) body

/-- **Every rank certificate is a weight certificate**, with `w j = (r j + 1)(K + 3)`. -/
theorem weightOK_of_rankOK {prog : List Expr} {r : ℕ → ℕ} {K : ℕ} (hR : RankOK prog r K) :
    WeightOK prog (fun j => (r j + 1) * (K + 3)) := by
  intro j body hj
  obtain ⟨hd, hc⟩ := hR j body hj
  have e1 : (r j + 1) * (K + 3) = r j * (K + 3) + (K + 3) := by ring
  refine ⟨?_, calleesLe_of_calleesLt hc fun k hk => ?_⟩
  · show exprDepth body + 3 ≤ (r j + 1) * (K + 3)
    omega
  · have e2 : (r k + 1) * (K + 3) ≤ r j * (K + 3) := Nat.mul_le_mul_right _ hk
    show (r k + 1) * (K + 3) ≤ (r j + 1) * (K + 3) - (exprDepth body + 3)
    omega

/-- Rank bounds give weight bounds for `w j = (r j + 1)(K + 3)`. -/
theorem calleesLe_of_calleesLt_rank {r : ℕ → ℕ} {K ρ : ℕ} {e : Expr} (h : CalleesLt r ρ e) :
    CalleesLe (fun j => (r j + 1) * (K + 3)) (ρ * (K + 3)) e :=
  calleesLe_of_calleesLt h fun _ hj => Nat.mul_le_mul_right _ hj

/-! ## The weighted lifting -/

/-- The statement proved by induction for the weighted lifting. -/
def LiftWProp (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (w : ℕ → ℕ) (M : ℕ) (env : List Val)
    (bits : List Bool) : Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => (∀ x ∈ env, valSize x ≤ M) → ∀ C, CalleesLe w C e →
      EvalsValF orc prog M (C * M) env bits (.inl e) v
  | .inr (i, acc), v => valSize acc ≤ M → ∀ body, prog[i]? = some body → ∀ C, CalleesLe w C body →
      EvalsValF orc prog M (C * M) env bits (.inr (i, acc)) v

theorem liftW_aux {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {env : List Val} {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val}
    (h : EvalsValO orc prog M env bits t v) : LiftWProp orc prog w M env bits t v := by
  induction h with
  | var hv => exact fun _ _ _ => EvalsValF.var hv
  | lit hM => exact fun _ _ _ => EvalsValF.lit hM
  | nil hM => exact fun _ _ _ => EvalsValF.nil hM
  | coin b hM => exact fun _ _ _ => EvalsValF.coin b hM
  | bin _ _ hop hM iha ihb =>
    intro henv C hc
    exact EvalsValF.bin (iha henv C hc.1) (ihb henv C hc.2) hop hM
  | un _ hop hM iha =>
    intro henv C hc
    exact EvalsValF.un (iha henv C hc) hop hM
  | @ite env c t f bc bv z v _ _ ihc ihv =>
    intro henv C hcl
    obtain ⟨hcc, hct, hcf⟩ := hcl
    have hbr : CalleesLe w C (if z ≠ 0 then t else f) := by
      split_ifs
      · exact hct
      · exact hcf
    exact EvalsValF.ite (ihc henv C hcc) (ihv henv C hbr)
  | @letE env a b ba bb va vb ha _ iha ihb =>
    intro henv C hc
    have hva : valSize va ≤ M := EvalsValO.val_le_env ha henv
    have henv' : ∀ x ∈ va :: env, valSize x ≤ M := by
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hx
      · exact hva
      · exact henv x hx
    exact EvalsValF.letE (iha henv C hc.1) (ihb henv' C hc.2)
  | @call env i a body ba bb va vb hi ha hbody hb iha ihb =>
    intro henv C hc
    obtain ⟨hwi, hcb⟩ := hW i body hbody
    have hva : valSize va ≤ M := EvalsValO.val_le_env ha henv
    have henv1 : ∀ x ∈ [va], valSize x ≤ M := by simpa using hva
    have hvb : valSize vb ≤ M := EvalsValO.val_le_env hb henv1
    refine EvalsValF.call hi (iha henv C hc.2) hbody (ihb henv1 _ hcb) hva hvb ?_
    have hle : exprDepth body + 2 + (w i - (exprDepth body + 3)) ≤ C := by have := hc.1; omega
    calc (exprDepth body + 2) * M + (w i - (exprDepth body + 3)) * M
        = (exprDepth body + 2 + (w i - (exprDepth body + 3))) * M := by ring
      _ ≤ C * M := Nat.mul_le_mul_right _ hle
  | @oracle env a ba sel rr q _ hM iha =>
    intro henv C hc
    exact EvalsValF.oracle (iha henv C hc.2) hM
  | @loop env i a ba bl va w' ha hl iha ihl =>
    intro henv C hc
    have hva : valSize va ≤ M := EvalsValO.val_le_env ha henv
    have hw' : valSize w' ≤ M := EvalsValO.loop_val_le hl hva
    obtain ⟨body, hbody⟩ := EvalsValO.loop_body_exists hl
    obtain ⟨hwi, hcb⟩ := hW i body hbody
    refine EvalsValF.loop (iha henv C hc.2) (ihl hva body hbody _ hcb) hva hw' ?_
    intro body' hbody'
    rw [hbody] at hbody'
    cases hbody'
    have hle : exprDepth body + 3 + (w i - (exprDepth body + 3)) ≤ C := by have := hc.1; omega
    calc (exprDepth body + 3) * M + (w i - (exprDepth body + 3)) * M
        = (exprDepth body + 3 + (w i - (exprDepth body + 3))) * M := by ring
      _ ≤ C * M := Nat.mul_le_mul_right _ hle
  | @stop i v body bb v' hbody hb ihb =>
    intro hv body' hbody' C hc
    rw [hbody] at hbody'
    cases hbody'
    exact EvalsValF.stop hbody (ihb (by simpa using hv) C hc)
  | @cont i v body bb bw flag v' w' hbody hb hflag hrest ihb ihr =>
    intro hv body' hbody' C hc
    rw [hbody] at hbody'
    cases hbody'
    have henv1 : ∀ x ∈ [v], valSize x ≤ M := by simpa using hv
    have hpair := EvalsValO.val_le_env hb henv1
    have hv' : valSize v' ≤ M := by
      rw [valSize_flag_pair] at hpair
      omega
    exact EvalsValF.cont hbody (ihb henv1 C hc) hflag (ihr hv' body hbody C hc)

/-- **Weighted lifting** (expression targets): an `EvalsValO` evaluation at the uniform bound `M`, in an
environment of values `≤ M`, whose callees all have weight `≤ C`, is an `EvalsValF` evaluation at the frame
bound `M` with the callee budget `C · M`. -/
theorem EvalsValO.toF_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ x ∈ env, valSize x ≤ M) {C : ℕ}
    (hc : CalleesLe w C e) : EvalsValF orc prog M (C * M) env bits (.inl e) v :=
  liftW_aux hW h henv C hc

/-- Weighted lifting into a frame with a larger budget `τ ≥ C · M`. -/
theorem EvalsValO.toF_wt_le {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ x ∈ env, valSize x ≤ M) {C τ : ℕ}
    (hc : CalleesLe w C e) (hτ : C * M ≤ τ) : EvalsValF orc prog M τ env bits (.inl e) v :=
  (h.toF_wt hW henv hc).mono_τ hτ

/-- **Weighted lifting** (loop targets): the iterations of `loop i` from an accumulator `≤ M` lift with the
budget `C · M` for every `C` bounding the weights of the callees of the body of `i`. -/
theorem EvalsValO.toF_wt_loop {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {i : ℕ} {acc w' : Val} {bits : List Bool}
    (h : EvalsValO orc prog M [] bits (.inr (i, acc)) w') (hacc : valSize acc ≤ M) {body : Expr}
    (hbody : prog[i]? = some body) {C : ℕ} (hc : CalleesLe w C body) :
    EvalsValF orc prog M (C * M) [] bits (.inr (i, acc)) w' :=
  liftW_aux hW h hacc body hbody C hc

/-! ## The rank lifting (C-SPACE's statement) -/

/-- **Lifting** (expression targets): an `EvalsValO` evaluation at the uniform bound `M` with a rank
certificate, in an environment of values `≤ M`, whose callees have rank `< ρ`, is an `EvalsValF` evaluation at
`(M, ρ (K + 3) M)`. -/
theorem EvalsValO.toF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsValO orc prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M) {ρ : ℕ}
    (hc : CalleesLt r ρ e) : EvalsValF orc prog M (ρ * (K + 3) * M) env bits (.inl e) v :=
  h.toF_wt (weightOK_of_rankOK hR) henv (calleesLe_of_calleesLt_rank hc)

/-- **Lifting** (loop targets): the iterations of `loop i` from an accumulator `≤ M` lift at
`(M, r i (K + 3) M)`. -/
theorem EvalsValO.toF_loop {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {i : ℕ} {acc w : Val} {bits : List Bool}
    (h : EvalsValO orc prog M [] bits (.inr (i, acc)) w) (hacc : valSize acc ≤ M) :
    EvalsValF orc prog M (r i * (K + 3) * M) [] bits (.inr (i, acc)) w := by
  obtain ⟨body, hbody⟩ := EvalsValO.loop_body_exists h
  exact h.toF_wt_loop (weightOK_of_rankOK hR) hacc hbody
    (calleesLe_of_calleesLt_rank (hR i body hbody).2)

/-! ## Call-free expressions -/

/-- `e` calls no routine of the program (oracle calls allowed) and contains no loop. -/
def CallFree : Expr → Prop
  | Expr.var _ => True
  | Expr.lit _ => True
  | Expr.nil => True
  | Expr.coin => True
  | Expr.bin _ a b => CallFree a ∧ CallFree b
  | Expr.un _ a => CallFree a
  | Expr.ite c t f => CallFree c ∧ CallFree t ∧ CallFree f
  | Expr.letE a b => CallFree a ∧ CallFree b
  | Expr.call j a => j = bsOracleIdx ∧ CallFree a
  | Expr.loop _ _ => False

/-- Boolean version of `CallFree`. -/
def callFreeB : Expr → Bool
  | Expr.var _ => true
  | Expr.lit _ => true
  | Expr.nil => true
  | Expr.coin => true
  | Expr.bin _ a b => callFreeB a && callFreeB b
  | Expr.un _ a => callFreeB a
  | Expr.ite c t f => callFreeB c && (callFreeB t && callFreeB f)
  | Expr.letE a b => callFreeB a && callFreeB b
  | Expr.call j a => decide (j = bsOracleIdx) && callFreeB a
  | Expr.loop _ _ => false

theorem callFreeB_iff (e : Expr) : callFreeB e = true ↔ CallFree e := by
  induction e with
  | var => simp [callFreeB, CallFree]
  | lit => simp [callFreeB, CallFree]
  | nil => simp [callFreeB, CallFree]
  | coin => simp [callFreeB, CallFree]
  | bin op a b iha ihb => simp [callFreeB, CallFree, iha, ihb]
  | un op a iha => simp [callFreeB, CallFree, iha]
  | ite c t f ihc iht ihf => simp [callFreeB, CallFree, ihc, iht, ihf]
  | letE a b iha ihb => simp [callFreeB, CallFree, iha, ihb]
  | call j a iha => simp [callFreeB, CallFree, iha]
  | loop j a => simp [callFreeB, CallFree]

/-- The statement proved by induction for the call-free lifting (loop targets do not occur). -/
def LiftCFProp (orc : ℤ → ℤ → ℤ → ℤ) (prog : List Expr) (M : ℕ) (env : List Val) (bits : List Bool) :
    Expr ⊕ (ℕ × Val) → Val → Prop
  | .inl e, v => CallFree e → ∀ τ, EvalsValF orc prog M τ env bits (.inl e) v
  | .inr _, _ => True

theorem liftCF_aux {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {t : Expr ⊕ (ℕ × Val)} {v : Val} (h : EvalsValO orc prog M env bits t v) :
    LiftCFProp orc prog M env bits t v := by
  induction h with
  | var hv => exact fun _ _ => EvalsValF.var hv
  | lit hM => exact fun _ _ => EvalsValF.lit hM
  | nil hM => exact fun _ _ => EvalsValF.nil hM
  | coin b hM => exact fun _ _ => EvalsValF.coin b hM
  | bin _ _ hop hM iha ihb => exact fun hc τ => EvalsValF.bin (iha hc.1 τ) (ihb hc.2 τ) hop hM
  | un _ hop hM iha => exact fun hc τ => EvalsValF.un (iha hc τ) hop hM
  | @ite env c t f bc bv z v _ _ ihc ihv =>
    intro hcl τ
    obtain ⟨hcc, hct, hcf⟩ := hcl
    have hbr : CallFree (if z ≠ 0 then t else f) := by
      split_ifs
      · exact hct
      · exact hcf
    exact EvalsValF.ite (ihc hcc τ) (ihv hbr τ)
  | letE _ _ iha ihb => exact fun hc τ => EvalsValF.letE (iha hc.1 τ) (ihb hc.2 τ)
  | call hi _ _ _ _ _ => exact fun hc _ => absurd hc.1 hi
  | oracle _ hM iha => exact fun hc τ => EvalsValF.oracle (iha hc.2 τ) hM
  | loop _ _ _ _ => exact fun hc _ => hc.elim
  | stop _ _ _ => trivial
  | cont _ _ _ _ _ _ => trivial

/-- **Call-free lifting**: an `EvalsValO` evaluation of a call-free expression (oracle calls allowed) is an
`EvalsValF` evaluation at the same bound with every budget. -/
theorem EvalsValO.toF_callFree {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {bits : List Bool} {e : Expr} {v : Val} (h : EvalsValO orc prog M env bits (.inl e) v)
    (hcf : CallFree e) (τ : ℕ) : EvalsValF orc prog M τ env bits (.inl e) v :=
  liftCF_aux h hcf τ

/-! ## `ImplementsO` and the oracle-free judgments -/

/-- **Weighted lifting** of `ImplementsO`. -/
theorem ImplementsO.toF_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hW : WeightOK prog w) {env : List Val} {α : Type} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsO orc prog M env e enc p) (henv : ∀ x ∈ env, valSize x ≤ M) {C : ℕ}
    (hc : CalleesLe w C e) : ImplementsF orc prog M (C * M) env e enc p :=
  fun bits a hp => (h bits a hp).toF_wt hW henv hc

/-- **Lifting** of `ImplementsO` (rank certificate). -/
theorem ImplementsO.toF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hR : RankOK prog r K) {env : List Val} {α : Type} {e : Expr} {enc : α → Val} {p : BitProg α}
    (h : ImplementsO orc prog M env e enc p) (henv : ∀ w ∈ env, valSize w ≤ M) {ρ : ℕ}
    (hc : CalleesLt r ρ e) : ImplementsF orc prog M (ρ * (K + 3) * M) env e enc p :=
  fun bits a hp => (h bits a hp).toF hR henv hc

/-- **Call-free lifting** of `ImplementsO`. -/
theorem ImplementsO.toF_callFree {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ} {env : List Val}
    {α : Type} {e : Expr} {enc : α → Val} {p : BitProg α} (h : ImplementsO orc prog M env e enc p)
    (hcf : CallFree e) (τ : ℕ) : ImplementsF orc prog M τ env e enc p :=
  fun bits a hp => (h bits a hp).toF_callFree hcf τ

/-- **Weighted lifting** of an oracle-free `EvalsVal` evaluation (no body at the oracle index). -/
theorem EvalsVal.toF_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w) {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ x ∈ env, valSize x ≤ M)
    {C : ℕ} (hc : CalleesLe w C e) : EvalsValF orc prog M (C * M) env bits (.inl e) v :=
  (EvalsValO.of_evalsVal (orc := orc) hO h).toF_wt hW henv hc

/-- **Lifting** of an oracle-free `EvalsVal` evaluation (rank certificate, no body at the oracle index). -/
theorem EvalsVal.toF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hR : RankOK prog r K) {env : List Val} {bits : List Bool}
    {e : Expr} {v : Val} (h : EvalsVal prog M env bits (.inl e) v) (henv : ∀ w ∈ env, valSize w ≤ M)
    {ρ : ℕ} (hc : CalleesLt r ρ e) : EvalsValF orc prog M (ρ * (K + 3) * M) env bits (.inl e) v :=
  (EvalsValO.of_evalsVal (orc := orc) hO h).toF hR henv hc

/-- **Call-free lifting** of an oracle-free `EvalsVal` evaluation (no body at the oracle index). -/
theorem EvalsVal.toF_callFree {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) {env : List Val} {bits : List Bool} {e : Expr} {v : Val}
    (h : EvalsVal prog M env bits (.inl e) v) (hcf : CallFree e) (τ : ℕ) :
    EvalsValF orc prog M τ env bits (.inl e) v :=
  (EvalsValO.of_evalsVal (orc := orc) hO h).toF_callFree hcf τ

/-- **Weighted lifting** of `Implements` (no body at the oracle index). -/
theorem Implements.toF_wt {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {w : ℕ → ℕ} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hW : WeightOK prog w) {env : List Val} {α : Type} {e : Expr}
    {enc : α → Val} {p : BitProg α} (h : Implements prog M env e enc p)
    (henv : ∀ x ∈ env, valSize x ≤ M) {C : ℕ} (hc : CalleesLe w C e) :
    ImplementsF orc prog M (C * M) env e enc p :=
  (Implements.toO (orc := orc) hO h).toF_wt hW henv hc

/-- **Lifting** of `Implements` (rank certificate, no body at the oracle index). -/
theorem Implements.toF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {r : ℕ → ℕ} {K M : ℕ}
    (hO : prog[bsOracleIdx]? = none) (hR : RankOK prog r K) {env : List Val} {α : Type} {e : Expr}
    {enc : α → Val} {p : BitProg α} (h : Implements prog M env e enc p)
    (henv : ∀ w ∈ env, valSize w ≤ M) {ρ : ℕ} (hc : CalleesLt r ρ e) :
    ImplementsF orc prog M (ρ * (K + 3) * M) env e enc p :=
  (Implements.toO (orc := orc) hO h).toF hR henv hc

/-- **Call-free lifting** of `Implements` (no body at the oracle index). -/
theorem Implements.toF_callFree {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {M : ℕ}
    (hO : prog[bsOracleIdx]? = none) {env : List Val} {α : Type} {e : Expr} {enc : α → Val}
    {p : BitProg α} (h : Implements prog M env e enc p) (hcf : CallFree e) (τ : ℕ) :
    ImplementsF orc prog M τ env e enc p :=
  (Implements.toO (orc := orc) hO h).toF_callFree hcf τ

end F2e2e.BSpace
