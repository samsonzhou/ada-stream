import F2e2e.BSpace.O2GlueMainPre
import F2e2e.BSpace.O2GlueMainNum
import F2e2e.BSpace.O2GlueMainIv

/-!
# B_space, route O2b: the top frame of the round program, P4 the composition (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802 (statement list approved 14:10Z). Pieces:
1beb339b's P1 (`o2m_pubF`, `o2m_evalsF`, `F2e2e/BSpace/O2GlueMainPre.lean`) and P2 (`o2m_numF`,
`O2GlueMainNum.lean`), C-BANK's P3 (`o2m_ivF`, `O2GlueMainIv.lean`).

`o2m_roundF`: in a frame `(m, τ)` with `o2mRoundB ≤ m` (the maximum of the pieces' value bounds) and
`o2mRoundT ≤ τ` (the maximum of the five call costs `(exprDepth body + 2) · m' + τ'`), `body_bsRound` implements
the core request `bsCoreRound A st (evalsOf orc q_A blocks) l' u' kind` (`l', u'` the endpoints of D3), for
every oracle and program that satisfy the five callee predicates of `O2GlueMainDefs`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl

/-- **The value bound of the round frame**: the maximum of the bounds of the prefix (P1), the interval
branch (P3) and the numerical branch (P2). -/
def o2mRoundB (orc : ℤ → ℤ → ℤ → ℤ) (Mc J R eA eXi : ℕ) (blocks : List (List ℕ)) (st : AdaState)
    (kind : Bool) : ℕ :=
  max (o2mPreB orc Mc J R eA eXi blocks st kind)
    (max (o2mIvB (adaParams eA eXi Mc J R) (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)
        (o2mInp Mc J R eA eXi blocks st true))
      (o2mNumB Mc J R eA eXi blocks st (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)))

/-- **The callee budget of the round frame**: the maximum of the five call costs. -/
def o2mRoundT (mP τP mE τE mD τD mI τI mN τN : ℕ) : ℕ :=
  max ((exprDepth body_adaPub + 2) * mP + τP)
    (max ((exprDepth body_bsEvals + 2) * mE + τE)
      (max ((exprDepth body_bsEnds + 2) * mD + τD)
        (max ((exprDepth body_adaInterval + 2) * mI + τI) ((exprDepth body_adaNumerical + 2) * mN + τN))))

/-- An `ite` on a deterministic condition in the per-call judgment. -/
theorem o2m_implementsF_ite {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} {m τ : ℕ} {env : List Val}
    {α : Type} {c t f : Expr} {z : ℤ} {enc : α → Val} {p : BitProg α}
    (hc : EvalsValF orc prog m τ env [] (.inl c) (Val.int z))
    (h : ImplementsF orc prog m τ env (if z ≠ 0 then t else f) enc p) :
    ImplementsF orc prog m τ env (Expr.ite c t f) enc p := by
  intro bits x hx
  simpa using EvalsValF.ite hc (h bits x hx)

set_option maxHeartbeats 1000000 in
/-- **P4: the round program's entry body in the per-call judgment.** -/
theorem o2m_roundF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} (hO : prog[bsOracleIdx]? = none)
    {Mc J R eA eXi : ℕ} {blocks : List (List ℕ)} {st : AdaState}
    (hok : AdaOK (adaParams eA eXi Mc J R) st) (kind : Bool)
    (horc : |orc 1 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1)| ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 2) ∧
      |orc 2 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1)| ≤ 2 ^ ((adaParams eA eXi Mc J R).qA + 2))
    {mP τP mE τE mD τD mI τI mN τN : ℕ}
    (hPub : O2mPubAt orc prog mP τP Mc J R eA eXi)
    (hEv : O2mEvalsAt orc prog mE τE (adaParams eA eXi Mc J R).qA blocks)
    (hEn : O2mEndsAt orc prog mD τD (adaParams eA eXi Mc J R).qA)
    (hIv : O2mIvAt orc prog mI τI (adaParams eA eXi Mc J R) st
      (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)
      (bsN_end (adaParams eA eXi Mc J R).qA (orc 1 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1)))
      (bsN_end (adaParams eA eXi Mc J R).qA (orc 2 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1))))
    (hNum : O2mNumAt orc prog mN τN (adaParams eA eXi Mc J R) st
      (evalsOf orc (adaParams eA eXi Mc J R).qA blocks))
    {m τ : ℕ} (hm : o2mRoundB orc Mc J R eA eXi blocks st kind ≤ m)
    (hτ : o2mRoundT mP τP mE τE mD τD mI τI mN τN ≤ τ) :
    ImplementsF orc prog m τ [o2mInp Mc J R eA eXi blocks st kind] body_bsRound
      (fun r => Val.list [bsStateEnc blocks r.2, bsResp r.1])
      (bsCoreRound (adaParams eA eXi Mc J R) st (evalsOf orc (adaParams eA eXi Mc J R).qA blocks)
        (bsN_end (adaParams eA eXi Mc J R).qA (orc 1 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1)))
        (bsN_end (adaParams eA eXi Mc J R).qA (orc 2 0 (((adaParams eA eXi Mc J R).qA : ℤ) + 1))) kind) := by
  unfold o2mRoundB at hm
  unfold o2mRoundT at hτ
  have hmP := le_trans (le_max_left _ _) hm
  have hmIv := le_trans (le_max_left _ _) (le_trans (le_max_right _ _) hm)
  have hmNum := le_trans (le_max_right _ _) (le_trans (le_max_right _ _) hm)
  have hτP := le_trans (le_max_left _ _) hτ
  have hτE := le_trans (le_max_left _ _) (le_trans (le_max_right _ _) hτ)
  have hτD := le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) hτ))
  have hτI := le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _)
    (le_trans (le_max_right _ _) hτ)))
  have hτN := le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _)
    (le_trans (le_max_right _ _) hτ)))
  have hinpM : valSize (o2mInp Mc J R eA eXi blocks st kind) ≤ m := by
    unfold o2mPreB at hmP
    omega
  rw [body_bsRound_eq]
  refine implementsF_letE_det (o2m_pubF hPub hmP hτP) ?_
  refine implementsF_letE_det (o2m_evalsF hEv hmP hτE) ?_
  have hk : EvalsValF orc prog m τ [encVals (evalsOf orc (adaParams eA eXi Mc J R).qA blocks),
      adaPubEnc (adaParams eA eXi Mc J R), o2mInp Mc J R eA eXi blocks st kind] []
      (.inl (eAtN 2 (eV 2))) (Val.int (if kind then 1 else 0)) :=
    o2m_atN (EvalsValF.var rfl) hinpM rfl
  refine o2m_implementsF_ite hk ?_
  cases kind with
  | true =>
    rw [if_pos (by decide)]
    exact o2m_ivF hO hok horc hEn hIv hmIv hτD hτI
  | false =>
    rw [if_neg (by decide)]
    exact o2m_numF hok hNum hmNum hτN _ _

end F2e2e.BSpace
