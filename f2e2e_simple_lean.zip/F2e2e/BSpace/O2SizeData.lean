import F2e2e.Cost.MachineBits
import F2e2e.C.Impl.AdaValid
import F2e2e.BSpace.DslDefs
import F2e2e.Spec

/-!
# B_space, route O2b (O2B-SIZE): exact sizes of the B data outside the ADA state

Owner: O2B-SIZE (ce59d4ae), for the O2b technical lead (17fc0802). Split with B-ACC (6f8aab0c), who owns
the tight sizes of the ADA state `adaEnc st`, the query table `encVals vals`, the parameter record
`adaPubEnc A`, the stored blocks and the B state `bsStateEnc` (`F2e2e/BSpace/O2TightSizes.lean`, prefix
`bsT`). This file (prefix `o2s`) gives EXACT `valSize` formulas (and named bounds) for the remaining data
that the B programs hold or pass:

* the records `encRecords code s` (the input of the initialization), `o2s_valSize_encRecords_eq`;
* the public parameters `encVParams M J R aReq ξReq`, `o2s_valSize_encVParams`;
* the response `bsResp r` (`o2s_valSize_bsResp_val`, `o2s_valSize_bsResp_cert`, `o2s_valSize_bsResp_abort`)
  and its bound `2 qA + 12` on every path of `adaNumerical` (`o2s_adaNumerical_resp_le`);
* the ADA outputs `encCert c`, `encNum x` and the output pairs `[out, adaEnc st']`;
* the argument lists of the ADA entry calls `[pub, st, vals, l, u]`, `[pub, st, vals]`, the input of the
  initialization `[params, records]`, the input of a round `[params, state, kind]`, the output of a round;
* the bit encoding: `|bitEncodeVal v| ≤ 2 · valSize v + 1` (`o2s_bitEncodeVal_length_le`; the machine
  bridge's `bitEncodeVal_length_le` has `3 · valSize v`); equality holds for integers.

Named bounds (for citation by the GST / final inequality): `o2sParamsSize`, `o2sRecordsBound`,
`o2sInitInBound`, `o2sRespBound`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.B F2e2e.Discrete F2e2e.C.Impl F2e2e.C.Alg

/-! ## Named bounds -/

/-- The exact size of the encoded public parameters `[M, J, R, eA, eXi]`. -/
def o2sParamsSize (M J R eA eXi : ℕ) : ℕ :=
  11 + Nat.size M + Nat.size J + Nat.size R + Nat.size eA + Nat.size eXi

/-- The size bound of `N` records of `bU` bits. -/
def o2sRecordsBound (N bU : ℕ) : ℕ := N * (bU + 2) + 1

/-- The size bound of the initialization's input `[params, records]`. -/
def o2sInitInBound (N bU M J R eA eXi : ℕ) : ℕ :=
  o2sRecordsBound N bU + o2sParamsSize M J R eA eXi + 3

/-- The size bound of a response (`q = qA`). -/
def o2sRespBound (q : ℕ) : ℕ := 2 * q + 12

/-! ## Generic list sizes -/

theorem o2s_valSize_list1 (a : Val) : valSize (Val.list [a]) = valSize a + 2 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem o2s_valSize_list2 (a b : Val) : valSize (Val.list [a, b]) = valSize a + valSize b + 3 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem o2s_valSize_list3 (a b c : Val) :
    valSize (Val.list [a, b, c]) = valSize a + valSize b + valSize c + 4 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

theorem o2s_valSize_list5 (a b c d e : Val) :
    valSize (Val.list [a, b, c, d, e]) =
      valSize a + valSize b + valSize c + valSize d + valSize e + 6 := by
  simp only [valSize_list, listSize_cons, listSize_nil]; omega

/-- The cells of a list of encoded integers given by a function on `Fin N`. -/
theorem o2s_listSize_ofFn_int : ∀ {N : ℕ} (g : Fin N → ℤ),
    listSize (List.ofFn fun ℓ => Val.int (g ℓ)) = ∑ ℓ, (bitLen (g ℓ) + 2)
  | 0, g => by simp
  | n + 1, g => by
    rw [List.ofFn_succ, listSize_cons, Fin.sum_univ_succ, o2s_listSize_ofFn_int (fun i => g i.succ),
      valSize_int]

/-! ## The records -/

/-- **The records, exactly**: `valSize (encRecords code s) = 1 + ∑_ℓ (size (code (s ℓ)) + 2)`. -/
theorem o2s_valSize_encRecords_eq {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) :
    valSize (encRecords code s) = 1 + ∑ ℓ, (Nat.size (code (s ℓ)) + 2) := by
  unfold encRecords
  rw [valSize_list, o2s_listSize_ofFn_int (fun ℓ => (code (s ℓ) : ℤ))]
  simp only [bitLen_natCast]

/-- The records are the list `encL encN` of the codes (the input shape of D1, `bsBlocks`). -/
theorem o2s_encRecords_eq_encL {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) :
    encRecords code s = encL encN (List.ofFn fun ℓ => code (s ℓ)) := by
  simp only [encRecords, encL, List.map_ofFn]
  rfl

/-- **The records, bound**: `N` codes `< 2^{bU}` have size `≤ N (bU + 2) + 1`. -/
theorem o2s_valSize_encRecords_le {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) (bU : ℕ)
    (hcode : ∀ x, code x < 2 ^ bU) : valSize (encRecords code s) ≤ o2sRecordsBound N bU := by
  rw [o2s_valSize_encRecords_eq]
  have h : ∑ ℓ, (Nat.size (code (s ℓ)) + 2) ≤ ∑ _ℓ : Fin N, (bU + 2) :=
    Finset.sum_le_sum fun ℓ _ => by
      have := Nat.size_le.mpr (hcode (s ℓ))
      omega
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul] at h
  unfold o2sRecordsBound
  omega

/-! ## The public parameters -/

/-- **The public parameters, exactly.** -/
theorem o2s_valSize_encVParams (M J R : ℕ) (aReq ξReq : ℝ) :
    valSize (encVParams M J R aReq ξReq) =
      o2sParamsSize M J R (dyadicExp aReq) (dyadicExp ξReq) := by
  simp only [encVParams, encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons,
    listSize_nil, valSize_int, bitLen_natCast, o2sParamsSize]
  omega

/-- The parameters in the `encInts` form used by D4 (`bsInit_impl`, `bsRound_tail`). -/
theorem o2s_valSize_encInts_params (M J R eA eXi : ℕ) :
    valSize (encInts [(M : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)]) =
      o2sParamsSize M J R eA eXi := by
  simp only [encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons, listSize_nil,
    valSize_int, bitLen_natCast, o2sParamsSize]
  omega

/-! ## ADA outputs -/

/-- A certificate is a small integer: `valSize (encCert c) ≤ 4`. -/
theorem o2s_valSize_encCert (c : AdaCert) : valSize (encCert c) ≤ 4 := by
  cases c <;> decide

/-- **A numerical output, exactly**: `valSize (encNum (val μ)) = size |μ.num| + size μ.den + 7`. -/
theorem o2s_valSize_encNum_val (μ : ℚ) :
    valSize (encNum (AdaNum.val μ)) = Nat.size μ.num.natAbs + Nat.size μ.den + 7 := by
  show valSize (Val.list [encQ μ]) = _
  rw [o2s_valSize_list1, valSize_encQ]

theorem o2s_valSize_encNum_abort : valSize (encNum AdaNum.abort) = 1 := by
  simp [encNum]

/-- The output pair `[out, adaEnc st']` of an ADA entry. -/
theorem o2s_valSize_adaOut (out : Val) (st' : AdaState) :
    valSize (Val.list [out, adaEnc st']) = valSize out + valSize (adaEnc st') + 3 :=
  o2s_valSize_list2 _ _

theorem o2s_valSize_adaOut_cert_le (c : AdaCert) (st' : AdaState) :
    valSize (Val.list [encCert c, adaEnc st']) ≤ valSize (adaEnc st') + 7 := by
  rw [o2s_valSize_adaOut]
  have := o2s_valSize_encCert c
  omega

/-! ## The response -/

theorem o2s_bitLen_three : bitLen (3 : ℤ) = 2 := by decide

/-- **A numerical response, exactly**: `valSize [3, μ.num, μ.den] = 9 + bitLen μ.num + size μ.den`. -/
theorem o2s_valSize_bsResp_val (μ : ℚ) :
    valSize (bsResp (Sum.inr (AdaNum.val μ))) = 9 + bitLen μ.num + Nat.size μ.den := by
  simp only [bsResp, encInts, List.map_cons, List.map_nil, valSize_list, listSize_cons,
    listSize_nil, valSize_int, bitLen_natCast, o2s_bitLen_three]
  omega

theorem o2s_valSize_bsResp_abort : valSize (bsResp (Sum.inr AdaNum.abort)) = 10 := by
  decide

/-- A certificate response is `[k]` with `k ≤ 2`: size `≤ 5`. -/
theorem o2s_valSize_bsResp_cert (c : AdaCert) : valSize (bsResp (Sum.inl c)) ≤ 5 := by
  cases c <;> decide

/-- A numerical response is at most `9` larger than the numerical output. -/
theorem o2s_valSize_bsResp_inr_le (x : AdaNum) :
    valSize (bsResp (Sum.inr x)) ≤ valSize (encNum x) + 9 := by
  cases x with
  | val μ =>
    rw [o2s_valSize_bsResp_val, o2s_valSize_encNum_val]
    unfold bitLen
    omega
  | abort =>
    rw [o2s_valSize_bsResp_abort, o2s_valSize_encNum_abort]

/-- **The numerical responses are below `2 qA + 12`** on every path of `adaNumerical`. -/
theorem o2s_adaNumerical_resp_le (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    Always (adaNumerical A st vals)
      (fun r => valSize (bsResp (Sum.inr r.1)) ≤ o2sRespBound A.qA) := by
  refine Always.mono (fun r hr => ?_)
    (DAlw.toBits (adaDraw_adaKB A) (adaNumericalD_num_le A st vals))
  unfold o2sRespBound
  cases h : r.1 with
  | val μ =>
    rw [h] at hr
    rw [o2s_valSize_bsResp_val]
    rw [o2s_valSize_encNum_val] at hr
    unfold bitLen
    omega
  | abort =>
    rw [o2s_valSize_bsResp_abort]
    omega

/-- **Every response is below `2 qA + 12`** given the numerical bound (certificates: `≤ 5`). -/
theorem o2s_valSize_bsResp_le {q : ℕ} (r : CoreOut)
    (hr : ∀ x, r = Sum.inr x → valSize (encNum x) ≤ 2 * q + 10) :
    valSize (bsResp r) ≤ o2sRespBound q := by
  unfold o2sRespBound
  cases r with
  | inl c =>
    have := o2s_valSize_bsResp_cert c
    omega
  | inr x =>
    have h1 := hr x rfl
    cases x with
    | val μ =>
      rw [o2s_valSize_bsResp_val]
      rw [o2s_valSize_encNum_val] at h1
      unfold bitLen
      omega
    | abort =>
      rw [o2s_valSize_bsResp_abort]
      omega

/-! ## Argument lists of the ADA entries -/

/-- **`adaInterval`'s argument** `[pub, st, vals, l, u]`, exactly. -/
theorem o2s_valSize_adaArgsIv (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) (l u : ℚ) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l, encQ u]) =
      valSize (adaPubEnc A) + valSize (adaEnc st) + valSize (encVals vals) +
        (Nat.size l.num.natAbs + Nat.size l.den) + (Nat.size u.num.natAbs + Nat.size u.den) + 16 := by
  rw [o2s_valSize_list5, valSize_encQ, valSize_encQ]
  omega

/-- **`adaNumerical`'s argument** `[pub, st, vals]`, exactly. -/
theorem o2s_valSize_adaArgsNum (A : AdaParams) (st : AdaState) (vals : List (List ℕ)) :
    valSize (Val.list [adaPubEnc A, adaEnc st, encVals vals]) =
      valSize (adaPubEnc A) + valSize (adaEnc st) + valSize (encVals vals) + 4 :=
  o2s_valSize_list3 _ _ _

/-! ## Inputs and outputs of the B programs -/

/-- **The initialization's input** `[params, records]`, exactly. -/
theorem o2s_valSize_initIn {U : Type} {N : ℕ} (M J R : ℕ) (aReq ξReq : ℝ) (code : U → ℕ)
    (s : Fin N → U) :
    valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) =
      o2sParamsSize M J R (dyadicExp aReq) (dyadicExp ξReq) + valSize (encRecords code s) + 3 := by
  rw [o2s_valSize_list2, o2s_valSize_encVParams]

/-- **The initialization's input, bound.** -/
theorem o2s_valSize_initIn_le {U : Type} {N : ℕ} (M J R : ℕ) (aReq ξReq : ℝ) (code : U → ℕ)
    (s : Fin N → U) (bU : ℕ) (hcode : ∀ x, code x < 2 ^ bU) :
    valSize (Val.list [encVParams M J R aReq ξReq, encRecords code s]) ≤
      o2sInitInBound N bU M J R (dyadicExp aReq) (dyadicExp ξReq) := by
  rw [o2s_valSize_initIn]
  have := o2s_valSize_encRecords_le code s bU hcode
  unfold o2sInitInBound
  omega

/-- **A round's input** `[params, state, kind]`, exactly (`kind` is `0` or `1`). -/
theorem o2s_valSize_roundIn (M J R : ℕ) (aReq ξReq : ℝ) (S : Val) (kind : Bool) :
    valSize (Val.list [encVParams M J R aReq ξReq, S, Val.int (if kind then 1 else 0)]) =
      o2sParamsSize M J R (dyadicExp aReq) (dyadicExp ξReq) + valSize S +
        (if kind then 1 else 0) + 5 := by
  rw [o2s_valSize_list3, o2s_valSize_encVParams]
  cases kind <;> simp

/-- **A round's output** `[state', resp]`, exactly. -/
theorem o2s_valSize_roundOut (S resp : Val) :
    valSize (Val.list [S, resp]) = valSize S + valSize resp + 3 :=
  o2s_valSize_list2 _ _

/-! ## Bit encodings -/

mutual
/-- **`|bitEncodeVal v| ≤ 2 valSize v + 1`** (equality for integers). -/
theorem o2s_bitEncodeVal_length_le : ∀ v : Val, (bitEncodeVal v).length ≤ 2 * valSize v + 1
  | Val.int z => by
      rw [Machine.bitEncodeVal_int_length]
      simp only [valSize]
      omega
  | Val.list xs => by
      have := o2s_bitEncodeVals_length_le xs
      rw [Machine.bitEncodeVal_list_length]
      simp only [valSize]
      omega
/-- The list version: `|bitEncodeVals l| ≤ 2 listSize l + 1`. -/
theorem o2s_bitEncodeVals_length_le : ∀ l : List Val, (bitEncodeVals l).length ≤ 2 * listSize l + 1
  | [] => by simp [bitEncodeVals, listSize]
  | x :: xs => by
      have h1 := o2s_bitEncodeVal_length_le x
      have h2 := o2s_bitEncodeVals_length_le xs
      rw [Machine.bitEncodeVals_cons_length]
      simp only [listSize]
      omega
end

/-- Integers: `|bitEncodeVal (int z)| = 2 valSize (int z) + 1`. -/
theorem o2s_bitEncodeVal_int_eq (z : ℤ) :
    (bitEncodeVal (Val.int z)).length = 2 * valSize (Val.int z) + 1 := by
  rw [Machine.bitEncodeVal_int_length, valSize_int]
  omega

end F2e2e.BSpace
