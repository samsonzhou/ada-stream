import F2e2e.BSpace.DslDefs
import F2e2e.C.Impl.AdaFrame

/-!
# B_space, layer D4 (W2): the entry bodies (definitions only)

Owner: W2 (a2ff64c3). The entry bodies `body_bsInit` (entry of `bsInitProg`) and `body_bsRound` (entry
of `bsRoundProg`), with their response helpers; specs in `F2e2e/BSpace/DslMain.lean`. Split off so that
D5 (tables, programs, rank certificate) does not depend on the proofs. D4 uses no helper routine of its
own (keys 930–939 unused): `bsMainTable = []`.
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Impl

/-! ## The bodies -/

/-- **`body_bsInit`** (entry of `bsInitProg`), environment `[[params, records]]`. -/
def body_bsInit : Expr :=
  eLet (eCall Idx.adaPub (eAtN 0 (eV 0)))
  (eLet (eCall bsBlocksKey (ePair (eAtN 1 (eV 0)) (eAtN 1 (eV 1))))
  (eLet (eCall Idx.adaInit (eV 1))
    (ePair (eV 1) (eV 0))))

/-- The response code of a certificate code `c = encCert cert` (`0…5`): `c` if `c < 3`, else
`(c - 2) mod 3` (`termHigh 3 ↦ 1`, `termLow 4 ↦ 2`, `abort 5 ↦ 0`). -/
def bsCertCode (c : Expr) : Expr := eIte (eLt c (eLit 3)) c (eMod (eSub c (eLit 2)) (eLit 3))

/-- The response of a numerical output `x = encNum r` (`[]` or `[[num, den]]`). -/
def bsNumResp (x : Expr) : Expr :=
  eIte (Expr.un UnOp.isNil x) (eList [eLit 3, eLit 0, eLit 1])
    (eList [eLit 3, eAtN 0 (eHd x), eAtN 1 (eHd x)])

/-- **`body_bsRound`** (entry of `bsRoundProg`), environment `[[params, state, kind]]`. -/
def body_bsRound : Expr :=
  eLet (eCall Idx.adaPub (eAtN 0 (eV 0)))
  (eLet (eCall bsEvalsKey (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1)))))
  (eIte (eAtN 2 (eV 2))
    (eLet (eCall bsEndsKey (eList [eAtN 7 (eV 1)]))
      (eLet (eCall Idx.adaInterval (eList [eV 2, eAtN 1 (eAtN 1 (eV 3)), eV 1, eAtN 0 (eV 0),
          eAtN 1 (eV 0)]))
        (ePair (ePair (eAtN 0 (eAtN 1 (eV 4))) (eAtN 1 (eV 0)))
          (eList [bsCertCode (eAtN 0 (eV 0))]))))
    (eLet (eCall Idx.adaNumerical (eList [eV 1, eAtN 1 (eAtN 1 (eV 2)), eV 0]))
      (ePair (ePair (eAtN 0 (eAtN 1 (eV 3))) (eAtN 1 (eV 0))) (bsNumResp (eAtN 0 (eV 0)))))))


/-! ## The branches of `body_bsRound` -/

/-- The interval branch of `body_bsRound` (environment `[vals, pub, inp]`). -/
def bsIvBranch : Expr :=
  eLet (eCall bsEndsKey (eList [eAtN 7 (eV 1)]))
    (eLet (eCall Idx.adaInterval (eList [eV 2, eAtN 1 (eAtN 1 (eV 3)), eV 1, eAtN 0 (eV 0),
        eAtN 1 (eV 0)]))
      (ePair (ePair (eAtN 0 (eAtN 1 (eV 4))) (eAtN 1 (eV 0)))
        (eList [bsCertCode (eAtN 0 (eV 0))])))

/-- The numerical branch of `body_bsRound` (environment `[vals, pub, inp]`). -/
def bsNumBranch : Expr :=
  eLet (eCall Idx.adaNumerical (eList [eV 1, eAtN 1 (eAtN 1 (eV 2)), eV 0]))
    (ePair (ePair (eAtN 0 (eAtN 1 (eV 3))) (eAtN 1 (eV 0))) (bsNumResp (eAtN 0 (eV 0))))

theorem body_bsRound_eq : body_bsRound =
    eLet (eCall Idx.adaPub (eAtN 0 (eV 0)))
      (eLet (eCall bsEvalsKey (ePair (eAtN 7 (eV 0)) (eAtN 0 (eAtN 1 (eV 1)))))
        (eIte (eAtN 2 (eV 2)) bsIvBranch bsNumBranch)) := rfl

/-- D4's own helper routines (keys 930–939): none. -/
def bsMainTable : List (ℕ × Expr) := []

end F2e2e.BSpace
