import F2e2e.BSpace.O2SizeUnit
import F2e2e.BSpace.O2TightChi

/-!
# O2b, Plan A (B-ARCH): the tight value premise `TightM` in terms of `N · χ`

Owner: B-ARCH (dc387564), for the O2b technical lead (17fc0802); prefix `o2cl`. Companion of B-NUM's
`O2TightChi.lean` (`o2c_alg2HAExp_le_two : q_A ≤ 2χ`, `o2c_adaZ_le`, `o2c_adaBoundA_le'`).

The ADA routines run under W4/B-ACC's tight premise `TightM A M := 2^8 · tightA A + cAddA A ≤ M`
(`F2e2e/C/Impl/AdaBounds.lean`: `tightA A = 2 (N + p + 16)(adaZ A + 16)`, `cAddA A = 2^18 (p + adaZ A + 16)`).
This file bounds both terms by `N · χ`.

* **Generic** (any `eA ≥ 4`, `eXi`, `χ' = adaChi M J R eA eXi ≥ 49 + eA`), from a hypothesis
  `q_A ≤ cq · χ'` with `cq ≤ 64`:
  - `o2cl_adaZ_add_le_gen : adaZ A + 16 ≤ (29 cq + 83) χ'` (from `adaZ_le_of : adaZ ≤ 29 q_A + 80 χ' + 128`
    and `144 ≤ 3 χ'`);
  - `o2cl_tightA_le_gen : tightA A ≤ (58 cq + 167) N χ'` and `o2cl_cAddA_le_gen : cAddA A ≤ N`, both from
    O2B-SIZE's `o2s_N_ge : 2^30 (p + 1) χ' ≤ N` (so `p + 16` and `p + adaZ + 16` are negligible against `N`);
  - `o2cl_tightM_le_gen : 2^8 tightA A + cAddA A ≤ (2^8 (58 cq + 167) + 1) N χ'`.
* **Actual parameters** `A = adaParams (dyadicExp a_req) (dyadicExp ξ_req) M J R` (`= asmParams M J R a_req ξ_req`),
  `N = (alg2Params M J R a_req ξ_req).N`, `χ = valChi M J R (dyadicDown a_req) (dyadicDown ξ_req)`, from
  `hq : alg2HAExp M J R a_req ξ_req ≤ cq · alg2Chi M J R a_req ξ_req`: `o2cl_adaZ_add_le_of`, `o2cl_tightA_le_of`,
  `o2cl_cAddA_le_of`, `o2cl_tightM_le_of`, `o2cl_TightM_of` (every `m ≥ (2^8 (58 cq + 167) + 1) N χ`).
* **Instance `cq = 2`** (B-NUM's `o2c_alg2HAExp_le_two`, Plan A): `o2cl_adaZ_add_le : adaZ A + 16 ≤ 141 χ`,
  `o2cl_tightA_le : tightA A ≤ 283 N χ`, `o2cl_cAddA_le : cAddA A ≤ N`,
  `o2cl_tightM_le : 2^8 tightA A + cAddA A ≤ 72449 N χ`, `o2cl_TightM : TightM A (2^17 N χ)`.
* **Instance `cq = 32`** (B-NUM's `alg2HAExp_le`, the fallback): `o2cl_tightA_le_32 : tightA A ≤ 2023 N χ`,
  `o2cl_TightM_32 : TightM A (2^19 N χ)`.
-/

namespace F2e2e.BSpace

open F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (adaZ tightA cAddA TightM)
open BoundAux

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically. -/
attribute [local irreducible] Nat.clog Nat.log

/-! ## Generic parameters -/

section generic

variable (M J R eA eXi : ℕ)

/-- `χ' = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉ ≥ 49 + eA`. -/
theorem o2cl_chi_ge : 49 + eA ≤ adaChi M J R eA eXi := by
  unfold adaChi; omega

/-- **`adaZ` from `q_A ≤ cq · χ'`**: `adaZ A + 16 ≤ (29 cq + 83) χ'` (`eA ≥ 4`). -/
theorem o2cl_adaZ_add_le_gen {cq : ℕ} (h4 : 4 ≤ eA)
    (hq : adaQA M J R eA eXi ≤ cq * adaChi M J R eA eXi) :
    adaZ (adaParams eA eXi M J R) + 16 ≤ (29 * cq + 83) * adaChi M J R eA eXi := by
  have hZ := adaZ_le_of M J R eA eXi h4
  have hχ := o2cl_chi_ge M J R eA eXi
  have e : (29 * cq + 83) * adaChi M J R eA eXi =
      29 * (cq * adaChi M J R eA eXi) + 83 * adaChi M J R eA eXi := by ring
  rw [e]
  omega

/-- `(58 cq + 166)(p + 16) ≤ N` for `cq ≤ 64` (from `o2s_N_ge : 2^30 (p + 1) χ' ≤ N`). -/
theorem o2cl_p_mul_le_N {cq : ℕ} (hcq : cq ≤ 64) :
    (58 * cq + 166) * ((adaParams eA eXi M J R).p + 16) ≤ (adaParams eA eXi M J R).N := by
  have hN := o2s_N_ge M J R eA eXi
  have hχ := o2cl_chi_ge M J R eA eXi
  have hp : (adaParams eA eXi M J R).p = adaP eA := rfl
  rw [hp]
  calc (58 * cq + 166) * (adaP eA + 16) ≤ 3878 * (16 * (adaP eA + 1)) :=
        Nat.mul_le_mul (by omega) (by omega)
    _ = 62048 * (adaP eA + 1) := by ring
    _ ≤ 2 ^ 30 * (adaP eA + 1) * 1 := by
        rw [Nat.mul_one]; exact Nat.mul_le_mul_right _ (by norm_num)
    _ ≤ 2 ^ 30 * (adaP eA + 1) * adaChi M J R eA eXi := Nat.mul_le_mul_left _ (by omega)
    _ ≤ _ := hN

/-- **`cAddA A ≤ N`** for `q_A ≤ cq χ'`, `cq ≤ 64`: `2^18 (p + adaZ + 16) ≤ 2^18 · 1940 (p + 1) χ' ≤ N`. -/
theorem o2cl_cAddA_le_gen {cq : ℕ} (h4 : 4 ≤ eA)
    (hq : adaQA M J R eA eXi ≤ cq * adaChi M J R eA eXi) (hcq : cq ≤ 64) :
    cAddA (adaParams eA eXi M J R) ≤ (adaParams eA eXi M J R).N := by
  have hZ := o2cl_adaZ_add_le_gen M J R eA eXi h4 hq
  have hN := o2s_N_ge M J R eA eXi
  have hχ := o2cl_chi_ge M J R eA eXi
  have hp : (adaParams eA eXi M J R).p = adaP eA := rfl
  unfold cAddA
  rw [hp]
  have hX1 : adaP eA + 1 ≤ (adaP eA + 1) * adaChi M J R eA eXi :=
    Nat.le_mul_of_pos_right _ (by omega)
  have hX2 : adaChi M J R eA eXi ≤ (adaP eA + 1) * adaChi M J R eA eXi :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hc : (29 * cq + 83) * adaChi M J R eA eXi ≤ 1939 * ((adaP eA + 1) * adaChi M J R eA eXi) :=
    calc (29 * cq + 83) * adaChi M J R eA eXi ≤ 1939 * adaChi M J R eA eXi :=
          Nat.mul_le_mul_right _ (by omega)
      _ ≤ 1939 * ((adaP eA + 1) * adaChi M J R eA eXi) := Nat.mul_le_mul_left _ hX2
  have e : 2 ^ 30 * (adaP eA + 1) * adaChi M J R eA eXi =
      1073741824 * ((adaP eA + 1) * adaChi M J R eA eXi) := by ring
  rw [e] at hN
  have h18 : (2 : ℕ) ^ 18 = 262144 := by norm_num
  rw [h18]
  omega

/-- **`tightA` from `q_A ≤ cq χ'`**: `tightA A ≤ (58 cq + 167) N χ'` (`cq ≤ 64`). -/
theorem o2cl_tightA_le_gen {cq : ℕ} (h4 : 4 ≤ eA)
    (hq : adaQA M J R eA eXi ≤ cq * adaChi M J R eA eXi) (hcq : cq ≤ 64) :
    tightA (adaParams eA eXi M J R) ≤
      (58 * cq + 167) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi := by
  have hZ := o2cl_adaZ_add_le_gen M J R eA eXi h4 hq
  have hP := o2cl_p_mul_le_N M J R eA eXi hcq
  unfold tightA
  calc 2 * ((adaParams eA eXi M J R).N + (adaParams eA eXi M J R).p + 16) *
        (adaZ (adaParams eA eXi M J R) + 16)
      ≤ 2 * ((adaParams eA eXi M J R).N + (adaParams eA eXi M J R).p + 16) *
          ((29 * cq + 83) * adaChi M J R eA eXi) := Nat.mul_le_mul_left _ hZ
    _ = (58 * cq + 166) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi +
          (58 * cq + 166) * ((adaParams eA eXi M J R).p + 16) * adaChi M J R eA eXi := by ring
    _ ≤ (58 * cq + 166) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi +
          (adaParams eA eXi M J R).N * adaChi M J R eA eXi :=
        Nat.add_le_add_left (Nat.mul_le_mul_right _ hP) _
    _ = (58 * cq + 167) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi := by ring

/-- **The tight premise in `N χ'`**: `2^8 tightA A + cAddA A ≤ (2^8 (58 cq + 167) + 1) N χ'`. -/
theorem o2cl_tightM_le_gen {cq : ℕ} (h4 : 4 ≤ eA)
    (hq : adaQA M J R eA eXi ≤ cq * adaChi M J R eA eXi) (hcq : cq ≤ 64) :
    2 ^ 8 * tightA (adaParams eA eXi M J R) + cAddA (adaParams eA eXi M J R) ≤
      (2 ^ 8 * (58 * cq + 167) + 1) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi := by
  have hT := o2cl_tightA_le_gen M J R eA eXi h4 hq hcq
  have hC := o2cl_cAddA_le_gen M J R eA eXi h4 hq hcq
  have hχ := o2cl_chi_ge M J R eA eXi
  have hN : (adaParams eA eXi M J R).N ≤ (adaParams eA eXi M J R).N * adaChi M J R eA eXi :=
    Nat.le_mul_of_pos_right _ (by omega)
  calc 2 ^ 8 * tightA (adaParams eA eXi M J R) + cAddA (adaParams eA eXi M J R)
      ≤ 2 ^ 8 * ((58 * cq + 167) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi) +
          (adaParams eA eXi M J R).N * adaChi M J R eA eXi :=
        Nat.add_le_add (Nat.mul_le_mul_left _ hT) (hC.trans hN)
    _ = (2 ^ 8 * (58 * cq + 167) + 1) * (adaParams eA eXi M J R).N * adaChi M J R eA eXi := by ring

end generic

/-! ## The actual parameters -/

section actual

variable (M J R : ℕ) {aReq ξReq : ℝ}

/-- The hypothesis `q_A ≤ cq χ` in B-NUM's form (`alg2HAExp ≤ cq · alg2Chi`), transported to `adaQA ≤ cq · adaChi`. -/
theorem o2cl_qA_le_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq) :
    adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      cq * adaChi M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) := by
  rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1, ← bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
  exact hq

/-- `adaZ A + 16 ≤ (29 cq + 83) χ` (actual parameters). -/
theorem o2cl_adaZ_add_le_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq) :
    adaZ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) + 16 ≤
      (29 * cq + 83) * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1]
  exact o2cl_adaZ_add_le_gen M J R _ _ (four_le_dyadicExp ha0 (by linarith))
    (o2cl_qA_le_of M J R ha0 ha1 hξ0 hξ1 hq)

/-- **`tightA A ≤ (58 cq + 167) N χ`** (actual parameters, `cq ≤ 64`). -/
theorem o2cl_tightA_le_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq)
    (hcq : cq ≤ 64) :
    tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (58 * cq + 167) * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1, V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
  exact o2cl_tightA_le_gen M J R _ _ (four_le_dyadicExp ha0 (by linarith))
    (o2cl_qA_le_of M J R ha0 ha1 hξ0 hξ1 hq) hcq

/-- **`cAddA A ≤ N`** (actual parameters, `cq ≤ 64`). -/
theorem o2cl_cAddA_le_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq)
    (hcq : cq ≤ 64) :
    cAddA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (F2e2e.alg2Params M J R aReq ξReq).N := by
  rw [V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
  exact o2cl_cAddA_le_gen M J R _ _ (four_le_dyadicExp ha0 (by linarith))
    (o2cl_qA_le_of M J R ha0 ha1 hξ0 hξ1 hq) hcq

/-- **The tight premise in `N χ`** (actual parameters, `cq ≤ 64`):
`2^8 tightA A + cAddA A ≤ (2^8 (58 cq + 167) + 1) N χ`. -/
theorem o2cl_tightM_le_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq)
    (hcq : cq ≤ 64) :
    2 ^ 8 * tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) +
        cAddA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (2 ^ 8 * (58 * cq + 167) + 1) * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  rw [bs_chi_eq M J R ha0 ha1 hξ0 hξ1, V2.v2par_N M J R ha0 ha1 hξ0 hξ1]
  exact o2cl_tightM_le_gen M J R _ _ (four_le_dyadicExp ha0 (by linarith))
    (o2cl_qA_le_of M J R ha0 ha1 hξ0 hξ1 hq) hcq

/-- **`TightM A m`** for every `m ≥ (2^8 (58 cq + 167) + 1) N χ` (actual parameters, `cq ≤ 64`). -/
theorem o2cl_TightM_of {cq : ℕ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) (hq : alg2HAExp M J R aReq ξReq ≤ cq * alg2Chi M J R aReq ξReq)
    (hcq : cq ≤ 64) {m : ℕ}
    (hm : (2 ^ 8 * (58 * cq + 167) + 1) * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) ≤ m) :
    TightM (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) m :=
  (o2cl_tightM_le_of M J R ha0 ha1 hξ0 hξ1 hq hcq).trans hm

/-! ### Instance `cq = 2` (Plan A: B-NUM's `o2c_alg2HAExp_le_two : q_A ≤ 2 χ`) -/

/-- **`adaZ A + 16 ≤ 141 χ`** (with `q_A ≤ 2 χ`). -/
theorem o2cl_adaZ_add_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    adaZ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) + 16 ≤
      141 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) :=
  o2cl_adaZ_add_le_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq)

/-- **`tightA A ≤ 283 N χ`** (with `q_A ≤ 2 χ`). -/
theorem o2cl_tightA_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      283 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) :=
  o2cl_tightA_le_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq) (by norm_num)

/-- **`cAddA A ≤ N`** (with `q_A ≤ 2 χ`). -/
theorem o2cl_cAddA_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    cAddA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      (F2e2e.alg2Params M J R aReq ξReq).N :=
  o2cl_cAddA_le_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq) (by norm_num)

/-- **`2^8 tightA A + cAddA A ≤ 72449 N χ`** (with `q_A ≤ 2 χ`; `2^8 · 283 + 1 = 72449`). -/
theorem o2cl_tightM_le (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    2 ^ 8 * tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) +
        cAddA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      72449 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) :=
  (o2cl_tightM_le_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq) (by norm_num)).trans
    (le_of_eq (by norm_num))

/-- **`TightM A (2^17 N χ)`** (with `q_A ≤ 2 χ`; `72449 ≤ 2^17 = 131072`). -/
theorem o2cl_TightM (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    TightM (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (2 ^ 17 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) :=
  o2cl_TightM_of M J R ha0 ha1 hξ0 hξ1 (o2c_alg2HAExp_le_two M J R aReq ξReq) (by norm_num)
    (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num)))

/-! ### Instance `cq = 32` (B-NUM's `alg2HAExp_le : q_A ≤ 32 χ`, the fallback) -/

/-- `tightA A ≤ 2023 N χ` (with `q_A ≤ 32 χ`). -/
theorem o2cl_tightA_le_32 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    tightA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      2023 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) :=
  o2cl_tightA_le_of M J R ha0 ha1 hξ0 hξ1 (alg2HAExp_le M J R aReq ξReq) (by norm_num)

/-- `TightM A (2^19 N χ)` (with `q_A ≤ 32 χ`; `2^8 · 2023 + 1 = 517889 ≤ 2^19`). -/
theorem o2cl_TightM_32 (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10) (hξ0 : 0 < ξReq)
    (hξ1 : ξReq < 1 / 2) :
    TightM (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R)
      (2 ^ 19 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)) :=
  o2cl_TightM_of M J R ha0 ha1 hξ0 hξ1 (alg2HAExp_le M J R aReq ξReq) (by norm_num)
    (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num)))

end actual

end F2e2e.BSpace
