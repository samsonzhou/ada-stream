import F2e2e.C.Impl.AdaPubMath
import F2e2e.B.NumericsSize
import F2e2e.B.ArchParamsBridge
import F2e2e.B.SpecV2BridgeParams
import F2e2e.Spec

/-!
# B_space, S3 (B-ARCH): parameter-size relations for the final bound

Plan: `F2e2e/BSpace/BSPACE_PLAN.md` §S3 (area lead W4). Throughout
`A = adaParams (dyadicExp aReq) (dyadicExp ξReq) M J R`,
`χ = valChi M J R (dyadicDown aReq) (dyadicDown ξReq)` and `N = (alg2Params M J R aReq ξReq).N = A.N`,
for `0 < aReq < 1/10`, `0 < ξReq < 1/2`.

* (i) `bs_adaZ_le : adaZ A ≤ 1024 · χ`. Every summand of W4's bit-length scale `adaZ` is bounded via
  W2's closed forms of the parameters (`F2e2e/C/Impl/AdaPubMath.lean`), as in C-SPACE's
  `F2e2e/C/SpaceAdaBound.lean` for the bank instance, here in terms of `χ` and `q_A`. The generic
  bound is `adaZ_le_of : adaZ ≤ 29 q_A + 80 χ' + 128` for every `eA ≥ 4`, with
  `χ' = adaChi M J R eA eXi = 49 + eA + eXi + ⌈log₂(p(p+1)Q)⌉` (so `2^{49+eA+eXi} p(p+1)Q ≤ 2^{χ'}`).
  Then B-NUM supplies `q_A ≤ 32χ` (`alg2HAExp_le`) and `χ' = χ` (`adaChi_eq`).
* (ii) `bs_adaBoundA_le : adaBoundA A ≤ 2^10 · (2N) · (1024χ + 16)`, and the clean form
  `bs_adaBoundA_le' : adaBoundA A ≤ 2^22 · N · χ`. Both use `p + 16 ≤ N`, since every block has at
  least `2^12` samples.
* (iii) `bsPubBound … ≤ 2^32 · adaBoundA A` is W2's.
* (iv) `bs_valSize_encRecords_le : valSize (encRecords code s) ≤ N (b_𝒰 + 2) + 1` and
  `bs_bitEncode_encRecords_le : |bitEncodeVal (encRecords code s)| ≤ N (2 b_𝒰 + 4) + 2`, for codes
  `< 2^{b_𝒰}`. The `+ 2` is exact for `N = 0`.
* (v) `bs_sixty_lt_chi : 60 < χ` (B-NUM's `sixty_lt_valChi`) and `bs_chi_eq : χ = adaChi M J R eA eXi`.
-/

namespace F2e2e.BSpace

open F2e2e.B F2e2e.Discrete
open F2e2e.C.Impl (adaZ adaBoundA maxKs noiseKinds)

/- `Nat.clog` is defined by fuel recursion; keep `whnf` from evaluating it symbolically (as in
`F2e2e/C/SpaceAdaBound.lean`). -/
attribute [local irreducible] Nat.clog Nat.log

namespace BoundAux

/-! ## Elementary facts -/

theorem size_le_of_le {n k : ℕ} (h : n ≤ 2 ^ k) : Nat.size n ≤ k + 1 :=
  Nat.size_le.mpr (lt_of_le_of_lt h (Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self k)))

theorem clog_le_of_le {x y : ℕ} (h : x ≤ 2 ^ y) : Nat.clog 2 x ≤ y :=
  (Nat.clog_le_iff_le_pow (by norm_num)).2 h

/-- `a / b` in lowest terms has numerator `≤ a` and denominator `≤ b`. -/
theorem num_den_div_le (a b : ℕ) (hb : 0 < b) :
    ((a : ℚ) / (b : ℚ)).num.natAbs ≤ a ∧ ((a : ℚ) / (b : ℚ)).den ≤ b := by
  have hb' : (0 : ℤ) < b := by exact_mod_cast hb
  have e : (a : ℚ) / (b : ℚ) = Rat.divInt (a : ℤ) (b : ℤ) := by
    rw [Rat.divInt_eq_div]; push_cast; rfl
  rw [e]
  constructor
  · rcases Nat.eq_zero_or_pos a with rfl | ha
    · simp
    · have ha' : (a : ℤ) ≠ 0 := by exact_mod_cast ha.ne'
      have := Nat.le_of_dvd (Int.natAbs_pos.mpr ha')
        (Int.natAbs_dvd_natAbs.mpr (Rat.num_dvd (a : ℤ) (ne_of_gt hb')))
      simpa using this
  · have := Int.le_of_dvd hb' (Rat.den_dvd (a : ℤ) (b : ℤ))
    exact_mod_cast this

theorem toNat_le_natAbs (x : ℤ) : x.toNat ≤ x.natAbs := by
  rcases le_total 0 x with h | h
  · have h1 : ((x.toNat : ℕ) : ℤ) = x := Int.toNat_of_nonneg h
    have h2 : ((x.natAbs : ℕ) : ℤ) = x := Int.natAbs_of_nonneg h
    have : ((x.toNat : ℕ) : ℤ) = ((x.natAbs : ℕ) : ℤ) := h1.trans h2.symm
    exact le_of_eq (by exact_mod_cast this)
  · rw [Int.toNat_eq_zero.mpr h]; exact Nat.zero_le _

/-- `1/n` has numerator `1` and denominator `n`. -/
theorem size_one_div (n k : ℕ) (hn : 0 < n) (hk : n ≤ 2 ^ k) :
    Nat.size ((1 : ℚ) / (n : ℚ)).den ≤ k + 1 ∧ Nat.size ((1 : ℚ) / (n : ℚ)).num.natAbs ≤ 1 := by
  have h := num_den_div_le 1 n hn
  rw [Nat.cast_one] at h
  refine ⟨size_le_of_le (h.2.trans hk), ?_⟩
  have := size_le_of_le (k := 0) (by simpa using h.1)
  simpa using this

theorem pow_two_mul (a b : ℕ) : 2 ^ a * 2 ^ b = 2 ^ (a + b) := (pow_add 2 a b).symm

theorem le_foldl_max : ∀ (l : List ℕ) (a : ℕ), a ≤ l.foldl max a
  | [], a => le_refl a
  | x :: l, a => (le_max_left a x).trans (le_foldl_max l (max a x))

theorem mem_le_foldl_max : ∀ (l : List ℕ) (a x : ℕ), x ∈ l → x ≤ l.foldl max a
  | [], _, _, h => absurd h (List.not_mem_nil)
  | y :: l, a, x, h => by
    rcases List.mem_cons.mp h with rfl | h
    · exact (le_max_right a x).trans (le_foldl_max l (max a x))
    · exact mem_le_foldl_max l (max a y) x h

/-! ## The parameters in terms of `χ' = adaChi M J R eA eXi` -/

section Facts

variable (M J R eA eXi : ℕ)

/-- `2^{49+eA+eXi} p(p+1)Q ≤ 2^{χ'}`. -/
theorem pow_mul_le : 2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1) * adaQ M J R eA) ≤
    2 ^ adaChi M J R eA eXi := by
  unfold adaChi
  rw [pow_add 2 (49 + eA + eXi)]
  exact Nat.mul_le_mul_left _ (Nat.le_pow_clog (by norm_num) _)

theorem eA_le_chi : eA ≤ adaChi M J R eA eXi := by unfold adaChi; omega

theorem chi_le_two_pow : adaChi M J R eA eXi ≤ 2 ^ adaChi M J R eA eXi := Nat.lt_two_pow_self.le

theorem Q_le : adaQ M J R eA ≤ 2 ^ adaChi M J R eA eXi := by
  have h := pow_mul_le M J R eA eXi
  have hp := F2e2e.C.Impl.AP.two_le_adaP eA
  have h1 : 1 ≤ 2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1)) :=
    Nat.one_le_iff_ne_zero.mpr (by positivity)
  calc adaQ M J R eA = 1 * adaQ M J R eA := (one_mul _).symm
    _ ≤ (2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1))) * adaQ M J R eA :=
        Nat.mul_le_mul_right _ h1
    _ = 2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1) * adaQ M J R eA) := by ring
    _ ≤ _ := h

/-- `2^49 · p · 2^{eA} ≤ 2^{χ'}`. -/
theorem p_pow_le : 2 ^ 49 * (adaP eA * 2 ^ eA) ≤ 2 ^ adaChi M J R eA eXi := by
  have h := pow_mul_le M J R eA eXi
  have hQ := F2e2e.C.Impl.AP.adaQ_pos M J R eA
  have h1 : 1 ≤ 2 ^ eXi * ((adaP eA + 1) * adaQ M J R eA) :=
    Nat.one_le_iff_ne_zero.mpr (by positivity)
  calc 2 ^ 49 * (adaP eA * 2 ^ eA) = (2 ^ 49 * 2 ^ eA * adaP eA) * 1 := by ring
    _ ≤ (2 ^ 49 * 2 ^ eA * adaP eA) * (2 ^ eXi * ((adaP eA + 1) * adaQ M J R eA)) :=
        Nat.mul_le_mul_left _ h1
    _ = 2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1) * adaQ M J R eA) := by
        rw [pow_add, pow_add]; ring
    _ ≤ _ := h

/-- `2^{22} Z_d ≤ 2^{χ'}` (`Z_d = 1/ζ = 98304000 p(p+1)Q 2^{eA} 2^{eXi}`). -/
theorem zdQ_le : 2 ^ 22 * F2e2e.C.Impl.AP.zdQ M J R eA eXi ≤ 2 ^ adaChi M J R eA eXi := by
  have h := pow_mul_le M J R eA eXi
  have hc : 2 ^ 22 * 98304000 ≤ 2 ^ 49 := by norm_num
  unfold F2e2e.C.Impl.AP.zdQ
  calc 2 ^ 22 * (98304000 * adaP eA * (adaP eA + 1) * adaQ M J R eA * (2 ^ eA * 2 ^ eXi))
      = (2 ^ 22 * 98304000) * (2 ^ eA * 2 ^ eXi * (adaP eA * (adaP eA + 1) * adaQ M J R eA)) := by
        ring
    _ ≤ 2 ^ 49 * (2 ^ eA * 2 ^ eXi * (adaP eA * (adaP eA + 1) * adaQ M J R eA)) :=
        Nat.mul_le_mul_right _ hc
    _ = 2 ^ (49 + eA + eXi) * (adaP eA * (adaP eA + 1) * adaQ M J R eA) := by
        rw [pow_add, pow_add]; ring
    _ ≤ _ := h

theorem zdQ_le' : F2e2e.C.Impl.AP.zdQ M J R eA eXi ≤ 2 ^ adaChi M J R eA eXi := by
  have := zdQ_le M J R eA eXi
  have h1 : F2e2e.C.Impl.AP.zdQ M J R eA eXi ≤ 2 ^ 22 * F2e2e.C.Impl.AP.zdQ M J R eA eXi := Nat.le_mul_of_pos_left _ (by norm_num)
  omega

/-- The denominators of the noise scales: `m_κ ≤ 2^{2χ'}`. -/
theorem mK_le (κ : NoiseKind) : F2e2e.C.Impl.AP.mK M J R eA eXi κ ≤ 2 ^ (2 * adaChi M J R eA eXi) := by
  have h1 := p_pow_le M J R eA eXi
  have h2 := chi_le_two_pow M J R eA eXi
  have hp := F2e2e.C.Impl.AP.two_le_adaP eA
  have h3 : 32768 * (adaP eA * 2 ^ eA) ≤ 2 ^ adaChi M J R eA eXi := by
    have : 32768 * (adaP eA * 2 ^ eA) ≤ 2 ^ 49 * (adaP eA * 2 ^ eA) :=
      Nat.mul_le_mul_right _ (by norm_num)
    omega
  have key : 32768 * adaP eA * 2 ^ eA * adaChi M J R eA eXi ≤ 2 ^ (2 * adaChi M J R eA eXi) := by
    calc 32768 * adaP eA * 2 ^ eA * adaChi M J R eA eXi
        = (32768 * (adaP eA * 2 ^ eA)) * adaChi M J R eA eXi := by ring
      _ ≤ 2 ^ adaChi M J R eA eXi * 2 ^ adaChi M J R eA eXi := Nat.mul_le_mul h3 h2
      _ = 2 ^ (2 * adaChi M J R eA eXi) := by rw [pow_two_mul]; congr 1; omega
  have hsmall : ∀ c : ℕ, c ≤ 256 →
      c * adaChi M J R eA eXi * 2 ^ eA ≤ 32768 * adaP eA * 2 ^ eA * adaChi M J R eA eXi := by
    intro c hc
    have : c ≤ 32768 * adaP eA := by omega
    calc c * adaChi M J R eA eXi * 2 ^ eA = c * (adaChi M J R eA eXi * 2 ^ eA) := by ring
      _ ≤ (32768 * adaP eA) * (adaChi M J R eA eXi * 2 ^ eA) := Nat.mul_le_mul_right _ this
      _ = 32768 * adaP eA * 2 ^ eA * adaChi M J R eA eXi := by ring
  cases κ
  · exact key
  · refine le_trans ?_ key
    show 16384 * adaP eA * 2 ^ eA * adaChi M J R eA eXi ≤ _
    exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num)))
  · exact (hsmall 256 le_rfl).trans key
  · exact (hsmall 128 (by norm_num)).trans key
  · exact (hsmall 64 (by norm_num)).trans key

/-- `B_0 ≤ χ'`. -/
theorem B0_le : adaB0 M J R eA eXi ≤ adaChi M J R eA eXi := by
  rw [F2e2e.C.Impl.AP.adaB0_eq]
  apply clog_le_of_le
  have h := zdQ_le M J R eA eXi
  have : 16 * F2e2e.C.Impl.AP.zdQ M J R eA eXi ≤ 2 ^ 22 * F2e2e.C.Impl.AP.zdQ M J R eA eXi :=
    Nat.mul_le_mul_right _ (by norm_num)
  omega

/-! ### The sampler parameters (any `q_A`) -/

theorem Ks_le (κ : NoiseKind) :
    (adaParams eA eXi M J R).Ks ((adaParams eA eXi M J R).scale κ) ≤
      2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 2) := by
  have hm0 := F2e2e.C.Impl.AP.mK_pos M J R eA eXi κ
  have hm := mK_le M J R eA eXi κ
  have hB0 := B0_le M J R eA eXi
  have hX := chi_le_two_pow M J R eA eXi
  rw [F2e2e.C.Impl.AP.scale_eq, F2e2e.C.Impl.AP.Ks_eq _ hm0]
  refine le_trans (Nat.div_le_self _ _) ?_
  show (2 ^ adaQA M J R eA eXi + F2e2e.C.Impl.AP.mK M J R eA eXi κ) * adaB0 M J R eA eXi +
    F2e2e.C.Impl.AP.mK M J R eA eXi κ - 1 ≤ _
  set a := 2 ^ adaQA M J R eA eXi with ha
  set b := 2 ^ (2 * adaChi M J R eA eXi) with hb
  set c := 2 ^ adaChi M J R eA eXi with hc
  set m := F2e2e.C.Impl.AP.mK M J R eA eXi κ with hmdef
  set B := adaB0 M J R eA eXi with hBdef
  have ha1 : 1 ≤ a := Nat.one_le_two_pow
  have hb1 : 1 ≤ b := Nat.one_le_two_pow
  have hc1 : 1 ≤ c := Nat.one_le_two_pow
  have hab : a + b ≤ 2 * (a * b) := by
    have h1 : a ≤ a * b := Nat.le_mul_of_pos_right _ hb1
    have h2 : b ≤ a * b := Nat.le_mul_of_pos_left _ ha1
    omega
  have hBc : B ≤ c := hB0.trans hX
  have h1 : (a + m) * B ≤ (a + b) * c := Nat.mul_le_mul (by omega) hBc
  have h2 : (a + b) * c ≤ 2 * (a * b * c) := by
    calc (a + b) * c ≤ (2 * (a * b)) * c := Nat.mul_le_mul_right _ hab
      _ = 2 * (a * b * c) := by ring
  have h3 : m ≤ a * b * c := by
    have : b ≤ a * b * c := by
      calc b = 1 * b * 1 := by ring
        _ ≤ a * b * c := Nat.mul_le_mul (Nat.mul_le_mul_right _ ha1) hc1
    omega
  have e : 2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 2) = 4 * (a * b * c) := by
    rw [ha, hb, hc, pow_two_mul, pow_two_mul,
      show adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 2 =
        2 + (adaQA M J R eA eXi + 2 * adaChi M J R eA eXi + adaChi M J R eA eXi) by ring, pow_add]
    norm_num
  rw [e]
  omega

theorem rs_le (κ : NoiseKind) :
    (adaParams eA eXi M J R).rs ((adaParams eA eXi M J R).scale κ) ≤
      adaQA M J R eA eXi + 4 * adaChi M J R eA eXi + 8 := by
  have hz : (adaParams eA eXi M J R).zeta = 1 / ((F2e2e.C.Impl.AP.zdQ M J R eA eXi : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.adaZeta_eq _ _ _ _ _
  rw [F2e2e.C.Impl.AP.rs_eq _ _ hz]
  apply clog_le_of_le
  have hK := Ks_le M J R eA eXi κ
  have hzd := zdQ_le' M J R eA eXi
  have hK1 : (adaParams eA eXi M J R).Ks ((adaParams eA eXi M J R).scale κ) + 1 ≤
      2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 3) := by
    have : 1 ≤ 2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 2) := Nat.one_le_two_pow
    rw [pow_succ]; omega
  calc 32 * ((adaParams eA eXi M J R).Ks ((adaParams eA eXi M J R).scale κ) + 1) *
        F2e2e.C.Impl.AP.zdQ M J R eA eXi
      ≤ 2 ^ 5 * 2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 3) *
          2 ^ adaChi M J R eA eXi :=
        Nat.mul_le_mul (Nat.mul_le_mul (by norm_num) hK1) hzd
    _ = 2 ^ (adaQA M J R eA eXi + 4 * adaChi M J R eA eXi + 8) := by
        rw [pow_two_mul, pow_two_mul]; congr 1; ring

theorem rho_le (κ : NoiseKind) :
    Nat.size ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).num.toNat ≤
        adaQA M J R eA eXi + 1 ∧
      Nat.size ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).den ≤
        adaQA M J R eA eXi + 2 * adaChi M J R eA eXi + 2 ∧
      Nat.clog 2 ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).den ≤
        adaQA M J R eA eXi + 2 * adaChi M J R eA eXi + 1 := by
  have hm0 := F2e2e.C.Impl.AP.mK_pos M J R eA eXi κ
  have hm := mK_le M J R eA eXi κ
  have hq : (adaParams eA eXi M J R).qA = adaQA M J R eA eXi := rfl
  rw [F2e2e.C.Impl.AP.scale_eq, F2e2e.C.Impl.AP.rho_eq _ hm0, hq]
  obtain ⟨hn, hd⟩ := num_den_div_le (2 ^ adaQA M J R eA eXi)
    (2 ^ adaQA M J R eA eXi + F2e2e.C.Impl.AP.mK M J R eA eXi κ) (by positivity)
  have hden : 2 ^ adaQA M J R eA eXi + F2e2e.C.Impl.AP.mK M J R eA eXi κ ≤
      2 ^ (adaQA M J R eA eXi + 2 * adaChi M J R eA eXi + 1) := by
    have h1 : 2 ^ adaQA M J R eA eXi ≤ 2 ^ (adaQA M J R eA eXi + 2 * adaChi M J R eA eXi) :=
      Nat.pow_le_pow_right (by norm_num) (by omega)
    have h2 : 2 ^ (2 * adaChi M J R eA eXi) ≤
        2 ^ (adaQA M J R eA eXi + 2 * adaChi M J R eA eXi) :=
      Nat.pow_le_pow_right (by norm_num) (by omega)
    rw [pow_succ]; omega
  refine ⟨size_le_of_le ((toNat_le_natAbs _).trans hn), ?_, clog_le_of_le (hd.trans hden)⟩
  have := size_le_of_le (hd.trans hden)
  omega

/-- The summand of `adaZ` for one noise kind. -/
theorem samp_le (κ : NoiseKind) :
    Nat.size ((adaParams eA eXi M J R).scale κ).den +
        Nat.size ((adaParams eA eXi M J R).scale κ).num.natAbs +
        Nat.size ((adaParams eA eXi M J R).Ks ((adaParams eA eXi M J R).scale κ)) +
        (adaParams eA eXi M J R).rs ((adaParams eA eXi M J R).scale κ) +
        Nat.size ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).num.toNat +
        Nat.size ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).den +
        Nat.clog 2 ((adaParams eA eXi M J R).rho ((adaParams eA eXi M J R).scale κ)).den ≤
      5 * adaQA M J R eA eXi + 13 * adaChi M J R eA eXi + 20 := by
  obtain ⟨hs1, hs2⟩ := size_one_div (F2e2e.C.Impl.AP.mK M J R eA eXi κ) (2 * adaChi M J R eA eXi)
    (F2e2e.C.Impl.AP.mK_pos _ _ _ _ _ κ) (mK_le M J R eA eXi κ)
  rw [← F2e2e.C.Impl.AP.scale_eq] at hs1 hs2
  have hK := size_le_of_le (Ks_le M J R eA eXi κ)
  have hr := rs_le M J R eA eXi κ
  obtain ⟨hr1, hr2, hr3⟩ := rho_le M J R eA eXi κ
  omega

/-! ### The global summands -/

theorem maxKs_le :
    maxKs (adaParams eA eXi M J R) ≤ 2 ^ (adaQA M J R eA eXi + 3 * adaChi M J R eA eXi + 2) := by
  have h1 := Ks_le M J R eA eXi NoiseKind.intThr
  have h2 := Ks_le M J R eA eXi NoiseKind.intTest
  have h3 := Ks_le M J R eA eXi NoiseKind.outThr
  have h4 := Ks_le M J R eA eXi NoiseKind.outTest
  have h5 := Ks_le M J R eA eXi NoiseKind.num
  unfold maxKs
  simp only [noiseKinds, List.map_cons, List.map_nil, List.foldr_cons, List.foldr_nil]
  omega

theorem fuel_le : (adaParams eA eXi M J R).fuel ≤ 2 ^ adaChi M J R eA eXi := by
  have hQ := Q_le M J R eA eXi
  refine le_trans ?_ hQ
  show 1 + (adaTmaxList eA).sum ≤ adaQ M J R eA
  unfold adaQ
  have : M + R + J + 2 + (adaTmaxList eA).sum ≤
      100 * (adaP eA + 1) * (M + R + J + 2 + (adaTmaxList eA).sum) :=
    Nat.le_mul_of_pos_left _ (by positivity)
  omega

theorem caps_le : M + J + R + 2 ≤ 2 ^ adaChi M J R eA eXi := by
  have hQ := Q_le M J R eA eXi
  refine le_trans ?_ hQ
  unfold adaQ
  have : M + R + J + 2 + (adaTmaxList eA).sum ≤
      100 * (adaP eA + 1) * (M + R + J + 2 + (adaTmaxList eA).sum) :=
    Nat.le_mul_of_pos_left _ (by positivity)
  omega

theorem p_succ_le : adaP eA + 1 ≤ 2 ^ adaChi M J R eA eXi := by
  have hQ := Q_le M J R eA eXi
  refine le_trans ?_ hQ
  unfold adaQ
  have h1 : 1 ≤ M + R + J + 2 + (adaTmaxList eA).sum := by omega
  calc adaP eA + 1 = 1 * (adaP eA + 1) * 1 := by ring
    _ ≤ 100 * (adaP eA + 1) * (M + R + J + 2 + (adaTmaxList eA).sum) :=
        Nat.mul_le_mul (Nat.mul_le_mul_right _ (by norm_num)) h1

theorem N_le : (adaParams eA eXi M J R).N ≤ 2 ^ (adaChi M J R eA eXi + adaQA M J R eA eXi) := by
  have hp := p_succ_le M J R eA eXi
  -- every block size is at most `max_j n_j ≤ 2^{q_A}`
  have hmax : adaMaxN M J R eA eXi ≤ 2 ^ adaQA M J R eA eXi := by
    have h1 : adaMaxN M J R eA eXi ≤ 2 ^ Nat.clog 2 (adaMaxN M J R eA eXi) :=
      Nat.le_pow_clog (by norm_num) _
    have h2 : Nat.clog 2 (adaMaxN M J R eA eXi) ≤ adaQA M J R eA eXi := by
      unfold adaQA; omega
    exact h1.trans (Nat.pow_le_pow_right (by norm_num) h2)
  have hent : ∀ x ∈ adaBlockSizes M J R eA eXi, x ≤ 2 ^ adaQA M J R eA eXi := fun x hx =>
    (mem_le_foldl_max _ 0 x hx).trans hmax
  show (adaBlockSizes M J R eA eXi).sum ≤ _
  calc (adaBlockSizes M J R eA eXi).sum ≤
        (adaBlockSizes M J R eA eXi).length * 2 ^ adaQA M J R eA eXi := by
        simpa using List.sum_le_card_nsmul _ _ hent
    _ = (adaP eA + 1) * 2 ^ adaQA M J R eA eXi := by rw [adaBlockSizes_length]
    _ ≤ 2 ^ adaChi M J R eA eXi * 2 ^ adaQA M J R eA eXi := Nat.mul_le_mul_right _ hp
    _ = _ := pow_two_mul _ _

theorem scoreScale_le :
    Nat.size (scoreScale (adaParams eA eXi M J R)).den ≤
        adaChi M J R eA eXi + adaQA M J R eA eXi + 1 ∧
      Nat.size (scoreScale (adaParams eA eXi M J R)).num.natAbs ≤ 1 := by
  have h1 := p_pow_le M J R eA eXi
  have hp := F2e2e.C.Impl.AP.two_le_adaP eA
  rw [F2e2e.C.Impl.AP.scoreScale_eq]
  apply size_one_div _ _ (by positivity)
  have h7 : 128 * (adaP eA * 2 ^ eA) ≤ 2 ^ adaChi M J R eA eXi := by
    have : 128 * (adaP eA * 2 ^ eA) ≤ 2 ^ 49 * (adaP eA * 2 ^ eA) :=
      Nat.mul_le_mul_right _ (by norm_num)
    omega
  calc 128 * adaP eA * 2 ^ eA * 2 ^ adaQA M J R eA eXi
      = (128 * (adaP eA * 2 ^ eA)) * 2 ^ adaQA M J R eA eXi := by ring
    _ ≤ 2 ^ adaChi M J R eA eXi * 2 ^ adaQA M J R eA eXi := Nat.mul_le_mul_right _ h7
    _ = _ := pow_two_mul _ _

theorem tau_le :
    Nat.size (adaParams eA eXi M J R).tau.den ≤ adaChi M J R eA eXi + 1 ∧
      Nat.size (adaParams eA eXi M J R).tau.num.natAbs ≤ 1 := by
  have h1 := p_pow_le M J R eA eXi
  have hp := F2e2e.C.Impl.AP.two_le_adaP eA
  have e : (adaParams eA eXi M J R).tau = 1 / ((8 * adaP eA * 2 ^ eA : ℕ) : ℚ) := F2e2e.C.Impl.AP.adaTau_eq eA
  rw [e]
  apply size_one_div _ _ (by positivity)
  have : 8 * (adaP eA * 2 ^ eA) ≤ 2 ^ 49 * (adaP eA * 2 ^ eA) := Nat.mul_le_mul_right _ (by norm_num)
  calc 8 * adaP eA * 2 ^ eA = 8 * (adaP eA * 2 ^ eA) := by ring
    _ ≤ _ := by omega

theorem a_half_le :
    Nat.size ((adaParams eA eXi M J R).a / 2).den ≤ adaChi M J R eA eXi + 2 ∧
      Nat.size ((adaParams eA eXi M J R).a / 2).num.natAbs ≤ 1 := by
  have hA := eA_le_chi M J R eA eXi
  rw [F2e2e.C.Impl.AP.a_half_eq]
  have h := size_one_div (2 * 2 ^ eA) (eA + 1) (by positivity) (by rw [pow_succ]; omega)
  exact ⟨by omega, h.2⟩

theorem zeta_le :
    Nat.size (adaParams eA eXi M J R).zeta.den ≤ adaChi M J R eA eXi + 1 ∧
      Nat.size (adaParams eA eXi M J R).zeta.num.natAbs ≤ 1 := by
  have e : (adaParams eA eXi M J R).zeta = 1 / ((F2e2e.C.Impl.AP.zdQ M J R eA eXi : ℕ) : ℚ) :=
    F2e2e.C.Impl.AP.adaZeta_eq _ _ _ _ _
  rw [e]
  exact size_one_div _ _ (F2e2e.C.Impl.AP.zdQ_pos _ _ _ _ _) (zdQ_le' M J R eA eXi)

/-- **The bit-length scale in terms of `q_A` and `χ'`** (any `eA ≥ 4`). -/
theorem adaZ_le_of (h4 : 4 ≤ eA) :
    adaZ (adaParams eA eXi M J R) ≤ 29 * adaQA M J R eA eXi + 80 * adaChi M J R eA eXi + 128 := by
  have hp := adaP_le_of_four_le h4
  have hA := eA_le_chi M J R eA eXi
  have hB0 := B0_le M J R eA eXi
  have hfuel := size_le_of_le (fuel_le M J R eA eXi)
  have hmax := size_le_of_le (maxKs_le M J R eA eXi)
  have hcaps := size_le_of_le (caps_le M J R eA eXi)
  have hN := size_le_of_le (N_le M J R eA eXi)
  obtain ⟨hc1, hc2⟩ := scoreScale_le M J R eA eXi
  obtain ⟨ht1, ht2⟩ := tau_le M J R eA eXi
  obtain ⟨ha1, ha2⟩ := a_half_le M J R eA eXi
  obtain ⟨hz1, hz2⟩ := zeta_le M J R eA eXi
  have k1 := samp_le M J R eA eXi NoiseKind.intThr
  have k2 := samp_le M J R eA eXi NoiseKind.intTest
  have k3 := samp_le M J R eA eXi NoiseKind.outThr
  have k4 := samp_le M J R eA eXi NoiseKind.outTest
  have k5 := samp_le M J R eA eXi NoiseKind.num
  have hq : (adaParams eA eXi M J R).qA = adaQA M J R eA eXi := rfl
  have hpp : (adaParams eA eXi M J R).p = adaP eA := rfl
  have hB : (adaParams eA eXi M J R).B0 = adaB0 M J R eA eXi := rfl
  have hcaps' : (adaParams eA eXi M J R).M + (adaParams eA eXi M J R).J +
      (adaParams eA eXi M J R).R + 2 = M + J + R + 2 := rfl
  unfold adaZ
  simp only [noiseKinds, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  rw [hq, hpp, hB, hcaps']
  omega

/-- `n_j ≥ 2^{12}`, hence `p + 16 ≤ N`. -/
theorem p_add_le_N : (adaParams eA eXi M J R).p + 16 ≤ (adaParams eA eXi M J R).N := by
  have hent : ∀ x ∈ adaBlockSizes M J R eA eXi, 4096 ≤ x := by
    intro x hx
    unfold adaBlockSizes at hx
    obtain ⟨j, -, rfl⟩ := List.mem_map.mp hx
    unfold adaNBlock
    have hc := F2e2e.C.Impl.AP.adaChi_pos M J R eA eXi
    have hh : 1 ≤ adaHInv eA := by
      have := F2e2e.C.Impl.AP.two_le_adaP eA
      unfold adaHInv; exact Nat.one_le_iff_ne_zero.mpr (by positivity)
    have : 4096 ≤ 2 ^ 12 * adaChi M J R eA eXi * adaHInv eA ^ 2 := by
      have h1 : 1 ≤ adaChi M J R eA eXi * adaHInv eA ^ 2 :=
        Nat.one_le_iff_ne_zero.mpr (by positivity)
      calc 4096 = 2 ^ 12 * 1 := by norm_num
        _ ≤ 2 ^ 12 * (adaChi M J R eA eXi * adaHInv eA ^ 2) := Nat.mul_le_mul_left _ h1
        _ = 2 ^ 12 * adaChi M J R eA eXi * adaHInv eA ^ 2 := by ring
    omega
  have hsum := List.card_nsmul_le_sum _ _ hent
  rw [adaBlockSizes_length, smul_eq_mul] at hsum
  show adaP eA + 16 ≤ (adaBlockSizes M J R eA eXi).sum
  omega

end Facts

end BoundAux

open BoundAux

/-! ## The statements for the actual parameters -/

/-- **(v)** `χ = adaChi M J R eA eXi` (B-NUM's `adaChi_eq`). -/
theorem bs_chi_eq (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) =
      adaChi M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) :=
  (adaChi_eq M J R ha0 ha1 hξ0 hξ1).symm

/-- **(v)** `60 < χ` (B-NUM's `sixty_lt_valChi`). -/
theorem bs_sixty_lt_chi (M J R : ℕ) (aReq ξReq : ℝ) :
    60 < F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) :=
  sixty_lt_valChi M J R (alg2A_pos aReq) (alg2A_le_one aReq) (alg2XiA_pos ξReq)
    (alg2XiA_le_one ξReq)

/-- **(i)** `adaZ A ≤ 1024 χ`. -/
theorem bs_adaZ_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaZ (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      1024 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  have h4 : 4 ≤ F2e2e.dyadicExp aReq := four_le_dyadicExp ha0 (by linarith)
  have hZ := adaZ_le_of M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) h4
  have hq : adaQA M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) ≤
      32 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
    rw [adaQA_eq M J R ha0 ha1 hξ0 hξ1]
    exact alg2HAExp_le M J R aReq ξReq
  have hχ := bs_chi_eq M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  rw [← hχ] at hZ
  omega

/-- `N + p + 16 ≤ 2N` and `N = A.N`. -/
theorem bs_N_add_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).N +
        (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R).p + 16 ≤
      2 * (F2e2e.alg2Params M J R aReq ξReq).N := by
  have h := p_add_le_N M J R (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq)
  have hN := V2.v2par_N M J R ha0 ha1 hξ0 hξ1
  omega

/-- **(ii)** `adaBoundA A ≤ 2^10 · (2N) · (1024 χ + 16)`. -/
theorem bs_adaBoundA_le (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      2 ^ 10 * (2 * (F2e2e.alg2Params M J R aReq ξReq).N) *
        (1024 * F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) + 16) := by
  have hZ := bs_adaZ_le M J R ha0 ha1 hξ0 hξ1
  have hN := bs_N_add_le M J R ha0 ha1 hξ0 hξ1
  unfold adaBoundA
  exact Nat.mul_le_mul (Nat.mul_le_mul_left _ hN) (by omega)

/-- **(ii), clean form** `adaBoundA A ≤ 2^22 · N · χ`. -/
theorem bs_adaBoundA_le' (M J R : ℕ) {aReq ξReq : ℝ} (ha0 : 0 < aReq) (ha1 : aReq < 1 / 10)
    (hξ0 : 0 < ξReq) (hξ1 : ξReq < 1 / 2) :
    adaBoundA (adaParams (F2e2e.dyadicExp aReq) (F2e2e.dyadicExp ξReq) M J R) ≤
      2 ^ 22 * (F2e2e.alg2Params M J R aReq ξReq).N *
        F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq) := by
  have h := bs_adaBoundA_le M J R ha0 ha1 hξ0 hξ1
  have h60 := bs_sixty_lt_chi M J R aReq ξReq
  refine h.trans ?_
  set N := (F2e2e.alg2Params M J R aReq ξReq).N
  set χ := F2e2e.valChi M J R (F2e2e.dyadicDown aReq) (F2e2e.dyadicDown ξReq)
  have h1 : 1024 * χ + 16 ≤ 2048 * χ := by omega
  calc 2 ^ 10 * (2 * N) * (1024 * χ + 16) ≤ 2 ^ 10 * (2 * N) * (2048 * χ) :=
        Nat.mul_le_mul_left _ h1
    _ = 2 ^ 22 * N * χ := by ring

/-! ## (iv) The records -/

theorem listSize_le_of {l : List Val} {b : ℕ} (h : ∀ v ∈ l, F2e2e.valSize v ≤ b + 1) :
    F2e2e.listSize l ≤ l.length * (b + 2) := by
  induction l with
  | nil => simp [F2e2e.listSize]
  | cons v l ih =>
    have hv := h v (by simp)
    have hl := ih fun w hw => h w (by simp [hw])
    simp only [F2e2e.listSize, List.length_cons]
    rw [Nat.succ_mul]
    omega

theorem bitEncodeVals_length_le_of {l : List Val} {b : ℕ}
    (h : ∀ v ∈ l, (F2e2e.bitEncodeVal v).length ≤ b + 3) :
    (F2e2e.bitEncodeVals l).length ≤ l.length * (b + 4) + 1 := by
  induction l with
  | nil => simp [F2e2e.bitEncodeVals]
  | cons v l ih =>
    have hv := h v (by simp)
    have hl := ih fun w hw => h w (by simp [hw])
    simp only [F2e2e.bitEncodeVals, List.length_cons, List.length_append]
    rw [Nat.succ_mul]
    omega

theorem bitEncodeVal_int_length (z : ℤ) :
    (F2e2e.bitEncodeVal (Val.int z)).length = 2 * F2e2e.bitLen z + 3 := by
  simp only [F2e2e.bitEncodeVal, List.length_append, List.length_cons, List.length_nil,
    List.length_replicate, Nat.size_eq_bits_len]
  unfold F2e2e.bitLen
  omega

/-- **(iv)** The size of the encoded records. -/
theorem bs_valSize_encRecords_le {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) (bU : ℕ)
    (hcode : ∀ x, code x < 2 ^ bU) : F2e2e.valSize (encRecords code s) ≤ N * (bU + 2) + 1 := by
  unfold encRecords
  have h := listSize_le_of (l := List.ofFn fun ℓ => Val.int (code (s ℓ))) (b := bU) (by
    intro v hv
    obtain ⟨ℓ, rfl⟩ := List.mem_ofFn.mp hv
    simp only [F2e2e.valSize, F2e2e.bitLen, Int.natAbs_natCast]
    have := Nat.size_le.mpr (hcode (s ℓ))
    omega)
  rw [List.length_ofFn] at h
  simp only [F2e2e.valSize]
  omega

/-- **(iv)** The length of the bit encoding of the records (`+ 2`: the list's leading `1` and final
`0`; exact for `N = 0`). -/
theorem bs_bitEncode_encRecords_le {U : Type} {N : ℕ} (code : U → ℕ) (s : Fin N → U) (bU : ℕ)
    (hcode : ∀ x, code x < 2 ^ bU) :
    (F2e2e.bitEncodeVal (encRecords code s)).length ≤ N * (2 * bU + 4) + 2 := by
  unfold encRecords
  have h := bitEncodeVals_length_le_of (l := List.ofFn fun ℓ => Val.int (code (s ℓ)))
    (b := 2 * bU) (by
    intro v hv
    obtain ⟨ℓ, rfl⟩ := List.mem_ofFn.mp hv
    rw [bitEncodeVal_int_length]
    simp only [F2e2e.bitLen, Int.natAbs_natCast]
    have := Nat.size_le.mpr (hcode (s ℓ))
    omega)
  rw [List.length_ofFn] at h
  simp only [F2e2e.bitEncodeVal, List.length_cons]
  rw [show 2 * bU + 4 = 2 * bU + 4 from rfl] at h
  omega

end F2e2e.BSpace
