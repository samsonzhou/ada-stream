import F2e2e.BSpace.O2GlueMainDefs

/-!
# B_space, route O2b: the top frame of the round program, P3 the interval branch (o2m)

Owner: C-BANK (47a44866), for the O2b technical lead 17fc0802 (statement list approved 14:10Z; shared definitions
`F2e2e/BSpace/O2GlueMainDefs.lean`).

`o2m_ivF`: in a frame `(m, τ)` with `o2mIvB ≤ m`, the interval branch `bsIvBranch` of `body_bsRound` (environment
`[encVals vals, adaPubEnc A, inp]` after the prefix) implements the interval request `bsCoreRound … true` with the
state encoding `bsStateEnc blocks` and the response `bsResp`. The two calls run in their own frames: `bsEnds` (D3)
at `(mD, τD)` and `adaInterval` (602) at `(mI, τI)`, charged `(exprDepth body + 2) · m' + τ'` each; everything else
(field access, the argument lists, the output pair and the certificate response `bsM_certResp`) is call-free and is
proved with the uniform calculus at `M = m` and embedded by `EvalsVal.toF_callFree`.

The proof follows W2's O1 proof (`bsRound_tail`, `F2e2e/BSpace/DslMain.lean`, interval case) with the per-call call
rules of O2B-GST (`evalsValF_call_det`, `implementsF_call_det`, `implementsF_letE_of`).
-/

namespace F2e2e.BSpace

open F2e2e.Cost F2e2e.Cost.AdaDSL F2e2e.B F2e2e.Discrete F2e2e.C.Alg F2e2e.C.Impl


/-- The frame bound of the interval branch. -/
def o2mIvB (A : AdaParams) (vals : List (List ℕ)) (inp : Val) : ℕ :=
  valSize (encVals vals) + valSize (adaPubEnc A) + valSize inp + o2mStB A + 4 * A.qA + 64

set_option maxHeartbeats 1000000 in
/-- **P3: the interval branch of `body_bsRound`** in the per-call judgment. -/
theorem o2m_ivF {orc : ℤ → ℤ → ℤ → ℤ} {prog : List Expr} (hO : prog[bsOracleIdx]? = none)
    {A : AdaParams} {Mc J R eA eXi : ℕ} {blocks : List (List ℕ)} {st : AdaState} (hok : AdaOK A st)
    {vals : List (List ℕ)}
    (horc : |orc 1 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2) ∧ |orc 2 0 ((A.qA : ℤ) + 1)| ≤ 2 ^ (A.qA + 2))
    {mD τD mI τI : ℕ} (hEn : O2mEndsAt orc prog mD τD A.qA)
    (hIv : O2mIvAt orc prog mI τI A st vals (bsN_end A.qA (orc 1 0 ((A.qA : ℤ) + 1)))
      (bsN_end A.qA (orc 2 0 ((A.qA : ℤ) + 1))))
    {m τ : ℕ} (hm : o2mIvB A vals (o2mInp Mc J R eA eXi blocks st true) ≤ m)
    (hτD : (exprDepth body_bsEnds + 2) * mD + τD ≤ τ)
    (hτI : (exprDepth body_adaInterval + 2) * mI + τI ≤ τ) :
    ImplementsF orc prog m τ [encVals vals, adaPubEnc A, o2mInp Mc J R eA eXi blocks st true] bsIvBranch
      (fun r => Val.list [bsStateEnc blocks r.2, bsResp r.1])
      (bsCoreRound A st vals (bsN_end A.qA (orc 1 0 ((A.qA : ℤ) + 1)))
        (bsN_end A.qA (orc 2 0 ((A.qA : ℤ) + 1))) true) := by
  /- ### Sizes -/
  set l' := bsN_end A.qA (orc 1 0 ((A.qA : ℤ) + 1)) with hl'
  set u' := bsN_end A.qA (orc 2 0 ((A.qA : ℤ) + 1)) with hu'
  set inp := o2mInp Mc J R eA eXi blocks st true with hinp
  set blocksV := Val.list (blocks.map (encL encN)) with hblocksV
  unfold o2mIvB at hm
  obtain ⟨hn1, hn2⟩ := horc
  have hlS : valSize (encQ l') ≤ 2 * A.qA + 13 := bsN_valSize_encQ_end A.qA _ hn1
  have huS : valSize (encQ u') ≤ 2 * A.qA + 13 := bsN_valSize_encQ_end A.qA _ hn2
  have hstB := o2m_valSize_adaEnc_le hok
  have hinpM : valSize inp ≤ m := by omega
  have hpubM : valSize (adaPubEnc A) ≤ m := by omega
  have h16 : 16 ≤ m := by omega
  have hstV : valSize (bsStateEnc blocks st) ≤ m :=
    le_trans (valSize_lt_of_mem (l := [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      bsStateEnc blocks st, encB true]) (by simp)).le hinpM
  have hstV' : valSize (bsStateEnc blocks st) ≤ valSize inp :=
    (valSize_lt_of_mem (l := [encInts [(Mc : ℤ), (J : ℤ), (R : ℤ), (eA : ℤ), (eXi : ℤ)],
      bsStateEnc blocks st, encB true]) (by simp)).le
  have hstE : bsStateEnc blocks st = Val.list [blocksV, adaEnc st] := rfl
  have hblkS : valSize blocksV + valSize (adaEnc st) + 3 = valSize (bsStateEnc blocks st) := by
    rw [hstE]
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  set ends := Val.list [encQ l', encQ u'] with hends
  have hendsS : valSize ends ≤ 4 * A.qA + 29 := by
    rw [hends]
    simp only [valSize_list, listSize_cons, listSize_nil] at hlS huS ⊢
    omega
  /- ### The endpoints (D3) -/
  have hqA := size_le_self A.qA
  have hqE : EvalsVal prog m [encVals vals, adaPubEnc A, inp] [] (.inl (eList [eAtN 7 (eV 1)]))
      (Val.list [encN A.qA]) := by
    refine evalsVal_list (List.Forall₂.cons (evalsVal_atN' (l := pubFields A) (EvalsVal.var rfl) hpubM rfl)
      List.Forall₂.nil) ?_
    simp only [valSize_list, listSize_cons, listSize_nil, valSize_encN]
    omega
  have hendsE : EvalsValF orc prog m τ [encVals vals, adaPubEnc A, inp] []
      (.inl (eCall bsEndsKey (eList [eAtN 7 (eV 1)]))) ends :=
    evalsValF_call_det (by decide) hEn.1 (EvalsVal.toF_callFree hO hqE ((callFreeB_iff _).mp (by decide)) τ)
      hEn.2.2 hEn.2.1 (by omega) hτD
  unfold bsIvBranch
  refine implementsF_letE_det hendsE ?_
  /- ### `adaInterval` (602) -/
  have hargs : EvalsVal prog m [ends, encVals vals, adaPubEnc A, inp] []
      (.inl (eList [eV 2, eAtN 1 (eAtN 1 (eV 3)), eV 1, eAtN 0 (eV 0), eAtN 1 (eV 0)]))
      (Val.list [adaPubEnc A, adaEnc st, encVals vals, encQ l', encQ u']) := by
    have hendsM : valSize ends ≤ m := by omega
    refine evalsVal_list (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons
      (evalsVal_atN' (l := [blocksV, adaEnc st]) (evalsVal_atN' (EvalsVal.var rfl) hinpM rfl) hstV rfl)
      (List.Forall₂.cons (EvalsVal.var rfl) (List.Forall₂.cons
        (evalsVal_atN' (EvalsVal.var rfl) hendsM rfl) (List.Forall₂.cons
        (evalsVal_atN' (EvalsVal.var rfl) hendsM rfl) List.Forall₂.nil))))) ?_
    simp only [valSize_list, listSize_cons, listSize_nil] at hlS huS ⊢
    omega
  have hivI := implementsF_call_det (orc := orc) (by decide) hIv.1
    (EvalsVal.toF_callFree hO hargs ((callFreeB_iff _).mp (by decide)) τ) hIv.2.2 hIv.2.1
    (fun bits r hr => by
      have hok' := Always.of_run (adaInterval_ok hok vals l' u') hr
      have h1 := o2m_valSize_adaEnc_le hok'
      have h2 : valSize (encCert r.1) ≤ 4 := by cases r.1 <;> decide
      simp only [valSize_list, listSize_cons, listSize_nil]
      omega) hτI
  rw [bsCoreRound_true]
  show ImplementsF orc prog m τ _ _ _ ((adaInterval A st vals l' u').bind _)
  refine implementsF_letE_of hivI (fun r => AdaOK A r.2)
    (fun bits r h => Always.of_run (adaInterval_ok hok vals l' u') h) ?_
  rintro ⟨c, st'⟩ hok'
  dsimp only at hok'
  apply ImplementsF.of_det
  have hst'B := o2m_valSize_adaEnc_le hok'
  have hrM : valSize (Val.list [encCert c, adaEnc st']) ≤ m := by
    have : valSize (encCert c) ≤ 4 := by cases c <;> decide
    simp only [valSize_list, listSize_cons, listSize_nil]
    omega
  have hresp : valSize (bsResp (Sum.inl c)) ≤ 5 := by cases c <;> decide
  have hout : EvalsVal prog m [Val.list [encCert c, adaEnc st'], ends, encVals vals, adaPubEnc A, inp] []
      (.inl (ePair (ePair (eAtN 0 (eAtN 1 (eV 4))) (eAtN 1 (eV 0))) (eList [bsCertCode (eAtN 0 (eV 0))])))
      (Val.list [Val.list [blocksV, adaEnc st'], bsResp (Sum.inl c)]) := by
    refine EvalsVal.pair (EvalsVal.pair (evalsVal_atN' (l := [blocksV, adaEnc st])
        (evalsVal_atN' (EvalsVal.var rfl) hinpM rfl) hstV rfl)
      (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) ?_)
      (bsM_certResp (evalsVal_atN' (EvalsVal.var rfl) hrM rfl) h16) ?_
    · simp only [valSize_list, listSize_cons, listSize_nil]
      omega
    · simp only [valSize_list, listSize_cons, listSize_nil] at hresp ⊢
      omega
  exact EvalsVal.toF_callFree hO hout ((callFreeB_iff _).mp (by decide)) τ

end F2e2e.BSpace
