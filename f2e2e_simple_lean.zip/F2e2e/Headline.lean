import F2e2e.A.Final
import F2e2e.B.Final
import F2e2e.C.Impl.Assemble
import F2e2e.C.Final
import F2e2e.AEff.Final
import F2e2e.BSpace.AssembleFinal
import F2e2e.BSpace.O2AssembleFinal

/-!
# The headline theorems: Main Theorems (A), (B) and (C) of the Spec

The names are those of `comparator/headlines.json` (headline module `F2e2e.Headline`).

Spec v2.2c headlines:
* (A) `theorem_A_statistical` := `F2e2e.A.theorem_A_statistical_proof` (`F2e2e/A/Final.lean`);
* (B) `theorem_B_statistical` := `F2e2e.B.theorem_B_statistical_proof` (`F2e2e/B/Final.lean`);
* (C) `theorem_C` := `F2e2e.C.Impl.Asm.theorem_C_of_lawBound` (`F2e2e/C/Impl/Assemble.lean`: the DSL implementation of
  the algorithm and its space bound on the small-step machine, via `F2e2e.C.Top.theorem_C_of_runsBound`) applied to
  `F2e2e.C.Closure.theLawBound` (`F2e2e/C/Final.lean`: Part III, the accuracy of the algorithm);
* `theorem_main` : the v2.2c conjunction (A) ∧ (B) ∧ (C) of the statistical headlines.

Spec v3.1 headlines:
* `theorem_A_eff` := `F2e2e.AEff.theorem_A_eff_proof` (`F2e2e/AEff/Final.lean`, from the fragment contracts of the
  uniform program in `F2e2e/AEffU/`): the computational clause of (A), for ONE fixed real-RAM program with rational
  literals that reads the public input image `adaInput k α β`;
* `theorem_B_space_2e128` := `F2e2e.BSpace.theorem_B_space_2e128_proof` and `theorem_B_joint_2e128` :=
  `F2e2e.BSpace.theorem_B_joint_2e128_proof` (`F2e2e/BSpace/AssembleFinal.lean`): (B)'s bit clause, and the
  single-tape-length form of (B), with the bit budget's constant `2^128` (the proof chain gives `2^107`);
* `theorem_main_full_2e128 : Theorem_main_full_2e128`: the six-fold conjunction with that constant;
* `theorem_B_space` := `F2e2e.BSpace.theorem_B_space_proof` and `theorem_B_joint` := `F2e2e.BSpace.theorem_B_joint_proof`
  (`F2e2e/BSpace/O2AssembleFinal.lean`): the same two statements with the paper's constant `2^30`;
* `theorem_main_full : Theorem_main_full`: Main Theorem (A), (B) and (C) in full, with the paper's constants.
-/

namespace F2e2e

/-- **Main Theorem (A)** (statistical content). -/
theorem theorem_A_statistical : Theorem_A_statistical := A.theorem_A_statistical_proof

/-- **Main Theorem (B)** (statistical content). -/
theorem theorem_B_statistical : Theorem_B_statistical := B.theorem_B_statistical_proof

/-- **Main Theorem (C)**. -/
theorem theorem_C : Theorem_C := C.Impl.Asm.theorem_C_of_lawBound C.Closure.theLawBound

/-- **Main Theorem**, v2.2c form: the statistical contents of (A) and (B), and (C). -/
theorem theorem_main : Theorem_A_statistical ∧ Theorem_B_statistical ∧ Theorem_C :=
  ⟨theorem_A_statistical, theorem_B_statistical, theorem_C⟩

/-- **Main Theorem (A), computational clause** (Spec v3.1 §6). -/
theorem theorem_A_eff : Theorem_A_eff := AEff.theorem_A_eff_proof

/-- **Main Theorem (B), bit clause, with the bit budget's constant `2^128`** (Spec v3.1 §7). -/
theorem theorem_B_space_2e128 : BSpace.Theorem_B_space_with 128 := BSpace.theorem_B_space_2e128_proof

/-- **Main Theorem (B) for one mechanism, with the bit budget's constant `2^128`** (Spec v3.1 §8). -/
theorem theorem_B_joint_2e128 : BSpace.Theorem_B_joint_with 128 := BSpace.theorem_B_joint_2e128_proof

/-- **The full Main Theorem with the bit budget's constant `2^128`** (Spec v3.1 §8, `Theorem_main_full_2e128`). -/
theorem theorem_main_full_2e128 : Theorem_main_full_2e128 :=
  ⟨theorem_A_statistical, theorem_A_eff, theorem_B_statistical, theorem_B_space_2e128, theorem_B_joint_2e128,
    theorem_C⟩

/-- **Main Theorem (B), bit clause, with the paper's bit budget `2^30 · N · (b_𝒰 + χ²)`** (Spec v3.1 §7). -/
theorem theorem_B_space : Theorem_B_space := BSpace.theorem_B_space_proof

/-- **Main Theorem (B) for one mechanism, with the paper's bit budget** (Spec v3.1 §8). -/
theorem theorem_B_joint : Theorem_B_joint := BSpace.theorem_B_joint_proof

/-- **The full Main Theorem, with the paper's constants** (Spec v3.1 §8, `Theorem_main_full`). -/
theorem theorem_main_full : Theorem_main_full :=
  ⟨theorem_A_statistical, theorem_A_eff, theorem_B_statistical, theorem_B_space, theorem_B_joint, theorem_C⟩

end F2e2e
