# RED-TEAM BRIEF (Spec v3.1): independent verification of the f2e2e Lean proof (Main Theorem (A)+(B)+(C) of `e2e.pdf`)

(Prepared by the f2e2e lead's team, 2026-10-25, for the Spec v3.1 candidate kit. The integrator launches the red
teams.
* The kit is built on a candidate commit. The v3.1 statement audit on `2f4f3c09…` (an independent multi-stage
  statement audit) runs in parallel; main carries this commit only after the integrator's sign-off on a FAITHFUL
  verdict.
* The kit's Spec is `7d40afe2…`, a delta from the audited `2f4f3c09…` confined to the appended v3.1 part: the code fix
  F1 (the retained state `alg2Retained`, from the v3.1 audit's check 2), plus comment and docstring minors (red-team
  phase-1 m1, m2, m4, and two §6 documentation minors from the audit).
* `7d40afe2…` is v3.1.1: the certified v3.1 `d36e360b…` with a comment/docstring-only docs patch applied after
  certification (strip-check IDENTICAL): the §7 header names `alg2RetainedOf`, and `alg2StateAt`'s docstring
  calls it the raw semantic state.
* Closing evidence: `evidence/<candidate rev>/`, produced on this exact commit; see the kit README.

Internal only: no external sharing without the user's decision. The paper is not in the kit; this brief quotes only
its Main Theorem.)

**Your mission.** You are an independent red-team verifier. Try to show that the following claim is FALSE, and report
honestly if you cannot:

> The source tree in `f2e2e_src.tar.zst` (sha256 in `SHA256SUMS`) is a Lean 4 project whose theorems (module
> `F2e2e.Headline`)
> * `F2e2e.theorem_A_statistical`, `F2e2e.theorem_B_statistical`, `F2e2e.theorem_C`, `F2e2e.theorem_main` (the v2.2c
>   headlines),
> * `F2e2e.theorem_A_eff`, `F2e2e.theorem_B_space`, `F2e2e.theorem_B_joint`, `F2e2e.theorem_main_full` (the v3.1
>   headlines, with the paper's constants), and
> * `F2e2e.theorem_B_space_2e128`, `F2e2e.theorem_B_joint_2e128`, `F2e2e.theorem_main_full_2e128` (the same with the
>   bit budget's constant `2^128`)
>
> prove, respectively, `Theorem_A_statistical`, `Theorem_B_statistical`, `Theorem_C`, `Theorem_A_statistical ∧
> Theorem_B_statistical ∧ Theorem_C`, `Theorem_A_eff`, `Theorem_B_space`, `Theorem_B_joint`, `Theorem_main_full`,
> `BSpace.Theorem_B_space_with 128`, `BSpace.Theorem_B_joint_with 128` and `Theorem_main_full_2e128` **exactly as
> stated in the trusted challenge file** `F2e2eChallenge/Challenge.lean` (in this kit), using only the axioms
> `propext`, `Quot.sound` and `Classical.choice`.

Assume the proof was written by AI agents that may have exploited Lean, deliberately or not. Possible routes:
* notation, macros, elaborators, instances, `open ... in`, coercions, metaprogramming;
* `implemented_by`/`extern`, `unsafe`, debug or `backward.*` options, kernel bypasses;
* tampering with compiled files or with the build.

**Trust nothing from the project's own documentation, scripts, gates, audit commands or verification records.** Use
only the inputs below and standard, independently obtained tools. Keep a complete input/output trace: it is the
certificate of your result.

## 1. What is claimed

Source: "Adaptive Data Analysis with α^{-2} polylog Overhead, Interval Validation, and Adversarially Robust Turnstile
F2 Estimation in ε^{-2} polylog Bits" (package `ada5_rf2_e2e_final`, 2026-10-24; `e2e.pdf` md5
`158a3f8f4d65231e9492ed2a910226b3`, LaTeX `e2e_source.tgz` md5 `3ccb54d5b9dd262f151a677810124162`). The paper is not in
the kit; ask the integrator if you need it.

The Main Theorem (`e2e.tex`), verbatim: (A) = L146–150, (B) = L151–159, (C) = L160–164 (each item's source lines
joined by single spaces, nothing else changed):

```latex
\item \textbf{Adaptive data analysis} (Theorem~\Iref{I:thm:main}). For every $k \ge 1$, $\alpha \in (0, 1/16)$, and $\beta \in (0, 1/2)$, the mechanism of Definition~\Iref{I:def:mechanism} answers $k$ adaptively chosen statistical queries $q_1, \dots, q_k : X \to [0,1]$ on any probability distribution $D$ over any measurable domain $X$, against any (possibly randomized and computationally unbounded) adaptive analyst, so that $\Prb[\max_{i \le k} |a_i - \E_{D}[q_i]| \le \alpha] \ge 1 - \beta$, using \[ n = O\bigg(\frac{\sqrt{k}\,\ln(1/(\alpha\beta))}{\alpha} + \frac{1}{\alpha^2}\bigg[\ln^3\!\Big(\frac{1}{\alpha\beta}\Big) + \ln^{7/2}(1/\alpha)\ln\!\left(\frac{k\ln(1/\alpha)}{\alpha\beta}\right)\sqrt{\ln\!\left(\frac{\ln(1/\alpha)}{\alpha\beta}\right)}\bigg]\bigg) \] i.i.d.\ samples from $D$; for $\beta \ge \alpha^5$ the leading term improves to $\sqrt{k\ln(1/(\alpha\beta))}/\alpha$. The mechanism runs in $O(kn)$ arithmetic operations and $O(n)$ working space in the real-arithmetic (oracle) model of Proposition~\Iref{I:prop:runtime}.
\item \textbf{Interval-validation ADA} (Theorem~\IIref{R:thm:validation_ada}). Let $\calU$ be a finite domain with an unknown distribution $\calD$, and fix $a_{\mathrm{req}} \in (0, 1/10)$, $\xi_{\mathrm{req}} \in (0, 1/2)$, and nonnegative integer caps $M$, $J$, $R$ on interval requests, nonterminal rejections, and numerical requests. The mechanism of Algorithm~\ref{R:alg:sec3_validation_ada} interacts with an adaptive controller that submits functions $f_t : \calU \to [0,1]$ (accessed only through their values on the samples), each paired with an interval request $[l_t, u_t]$ or a numerical request. With the dyadic accuracy $a = 2^{-\lceil \log_2(1/a_{\mathrm{req}}) \rceil}$, the parameters $p = \Theta(\log(1/a))$ and $\chi$ of Definition~\IIref{R:def:sec3_ada_params}, and $K = J + R + 1$, it uses \[ N \le 2^{64}\left[\left(\frac{p^{7/2}}{a^2} + \frac{p^{3/2}\sqrt{K}}{a}\right)\chi^{3/2} + \frac{p^3\chi}{a^2}\right] = O\!\left[\left(\frac{\sqrt{J+R+1}}{a_{\mathrm{req}}} + \frac{1}{a_{\mathrm{req}}^2}\right)\log^3\frac{1}{a_{\mathrm{req}}}\,\log^2\frac{M+J+R+2}{a_{\mathrm{req}}\,\xi_{\mathrm{req}}}\right] \] samples and, if records use $b_{\calU}$ bits, at most $2^{30}N(b_{\calU} + \chi^2)$ bits plus the working space of its evaluation oracle; its randomness consists of fresh independent fair bits drawn by bounded samplers. With probability at least $1 - \xi_{\mathrm{req}}$, it never exhausts an internal correction cap, every interval response up to and including a terminal $(J+1)$-st rejection satisfies \[ \texttt{ACCEPT} \Rightarrow \calD f_t \in [l_t - a_{\mathrm{req}},\, u_t + a_{\mathrm{req}}], \qquad \texttt{HIGH} \Rightarrow \calD f_t \ge u_t - a_{\mathrm{req}}, \qquad \texttt{LOW} \Rightarrow \calD f_t \le l_t + a_{\mathrm{req}}, \] and every numerical answer satisfies $|\hat{\mu}_t - \calD f_t| \le a_{\mathrm{req}}$.
\item \textbf{Adversarially robust turnstile $F_2$} (Theorem~\IIref{R:thm:main}, proved in Part~III). For all integers $n, m, U \ge 1$ and reals $\varepsilon, \beta \in (0, 1/10)$, let $\Lambda := \log_2[2^{100}(n+2)(m+2)(U+2)/(\varepsilon\beta)]$. There is a finite-precision single-pass streaming algorithm that, against any computationally unbounded adaptive adversary in the integer turnstile model with $\|x^{(t)}\|_\infty \le U$, outputs $\widehat{F}_t \ge 0$ after every update $t \le m$ such that \[ \Prb\left[\forall\, t \le m : \frac{F_2(x^{(t)})}{1+\varepsilon} \le \widehat{F}_t \le (1+\varepsilon)F_2(x^{(t)})\right] \ge 1 - \beta, \] using at most $2^{512}\varepsilon^{-2}\Lambda^{15} = \varepsilon^{-2}\polylog(n, m, U, 1/\varepsilon, 1/\beta)$ bits of space on every execution, counting all samples, seeds, counters, learner states, scale tags, caches, noise samplers, public parameters, and arithmetic workspace; all randomness consists of fresh independent fair bits.
```

**The v2.2c headlines** (unchanged in v3.1; each a `def … : Prop` of the Spec):
* **`Theorem_A_statistical`**: `∃ C > 0, ∀ k ≥ 1, α ∈ (0,1/16), β ∈ (0,1/2)`, five conjuncts:
  * the coin law is a probability measure;
  * the cascade is jointly measurable;
  * `adaSampleSize ≤ adaExplicitBound`;
  * `adaSampleSize ≤ C·adaAsymp`;
  * `ADAPublicGuarantee`, for every measurable `X`, every probability `D`, and every randomized analyst that sees
    the answers in `[0,1]` and the public records `τ_aux`.

  The mechanism is pinned to Def I.1.8 (`adaCascade`).
* **`Theorem_B_statistical`**: `∃ C > 0, ∀ M J R, a_req ∈ (0,1/10), ξ_req ∈ (0,1/2)`:
  * `N ≤ valNExplicit` and `N ≤ C·valNAsymp`;
  * `∃ c` (fair-bit tape length) with `VGuaranteeWithInternalCaps` for the pinned Algorithm 2 (`alg2Mech`).

  The failure event is an incorrect covered response ∪ an internal cap/abort, under one `ξ_req`.
* **`Theorem_C`**: `∃ alg` (uniform), `∀ n m U ≥ 1, ε, β ∈ (0,1/10)`:
  * (1) the space bound `2^512 ε⁻² Λ^15` holds on every execution. Every step of the small-step machine is charged
    `confBits c + confBits c' + stepWork c + ctrlWork c c'`.
  * (2) accuracy up to the first box violation with probability `≥ 1 − β`.

**The v3.1 headlines, one by one: the Lean statement, then the claim in words** (§6–§8 of the Spec; `n =
adaSampleSize k α β`, `L = adaL α`, `N = (alg2Params M J R a_req ξ_req).N`, `χ = valChi M J R (dyadicDown a_req)
(dyadicDown ξ_req)`):
1. **`F2e2e.theorem_A_eff : Theorem_A_eff`** (§6; e2e.tex L150; partI.tex L34, L499–507). The statement is
   `∃ C : ℕ, ∃ P : AEff.RamProgram, P.RatLits ∧ ∀ k ≥ 1, α ∈ (0,1/16), β ∈ (0,1/2), ∀ qv ω,
   P.RunsWithin (AEff.adaInput k α β) k (AEff.adaOracle qv ω) (ADAOutputStreamed …) (C·n) (C·n)`.
   * In words: there are a constant `C` and ONE real-RAM program `P`, fixed before all parameters and with rational
     literals only. For all `k ≥ 1`, `α ∈ (0, 1/16)`, `β ∈ (0, 1/2)`, all query values `qv` and all realizations
     `ω` of the cascade's coin table, `P` is started on the public input `adaInput k α β`, with oracle access to `qv`
     and `ω`. Then the initialization and each of the `k` rounds take at most `C·n` unit operations, the workspace
     stays at most `C·n`, and round `i` streams exactly the cascade's public output `(a_i, τ_aux,i)` (Def I.1.8,
     `adaCascade`).
   * The input image `adaInput k α β` has a header of ten cells (`k, α, β, n, L, α/2, adaGamma α, adaEta α,
     adaEta1 α, adaT1max α`) and four fields for each stage `r ≤ L+1` (`adaBlock`, `adaOffset`, `adaNmax`,
     `adaEtaTilde`). Every other cell is `0`, and the length is `16L + 96`.
2. **`F2e2e.theorem_B_space : Theorem_B_space`** (§7; e2e.tex L151, L155; partII.tex L966–970). The statement is
   `Theorem_B_space := BSpace.Theorem_B_space_with 30`, i.e. `∃ impl, ∀ M J R a_req ξ_req (ranges), ∃ c_B,
   ∀ c ≥ c_B, BSpace.ReproducesFor 30 … alg2Mech alg2RetainedOf impl M J R a_req ξ_req c`. In words:
   * There is ONE implementation, two programs of the locked DSL. For all caps `M, J, R` and all `a_req ∈ (0, 1/10)`,
     `ξ_req ∈ (0, 1/2)` there is a tape bound `c_B`, depending only on these, with the following property for every
     tape length `c ≥ c_B`.
   * Take every finite domain `𝒰` with an injective code into `b_𝒰`-bit integers and every sample `s`. Then there is
     an encoding `enc` of Algorithm 2's state such that, for every `c`-bit coin block `ω`, every sequence of valid
     requests and EVERY oracle family consistent with the sample (`OracleFor`), three things hold. First, the runs of
     the implementation on the oracle machine (the initialization, then one run per request, with the tape threaded
     through) answer every request exactly as the pinned Algorithm 2 (`alg2Mech M J R a_req ξ_req c`) does on the
     same views and coins. Second, every step of every run is charged at most `2^30 · N · (b_𝒰 + χ²)` bits. Third,
     the memory passed from each request to the next is `enc` of the part of Algorithm 2's current state that the
     paper retains: `alg2Retained` of `alg2StateAt`, i.e. the scores only at each learned block's own points, with all
     other fields unchanged.
3. **`F2e2e.theorem_B_joint : Theorem_B_joint`** (§8). The statement is `Theorem_B_joint :=
   BSpace.Theorem_B_joint_with 30`. In words: there is ONE implementation such that, for all public parameters,
   there is a `c₀` such that for every `c ≥ c₀` BOTH hold.
   * `alg2Mech … c` satisfies the statistical guarantee of `Theorem_B_statistical`
     (`VGuaranteeWithInternalCaps`): with probability `≥ 1 − ξ_req` over the coins, every covered response is
     correct and no internal correction cap is exhausted.
   * The implementation reproduces `alg2Mech … c` within `2^30 · N · (b_𝒰 + χ²)` bits, history-free, as in
     `theorem_B_space`, for this same `c`.
   So (B) is one mechanism, accurate and implementable.
4. **`F2e2e.theorem_main_full : Theorem_main_full`** (§8). The statement is `Theorem_A_statistical ∧ Theorem_A_eff ∧
   Theorem_B_statistical ∧ Theorem_B_space ∧ Theorem_B_joint ∧ Theorem_C`. In words: Main Theorem (A)+(B)+(C), with
   the paper's constants.
5. **`F2e2e.theorem_B_space_2e128 : BSpace.Theorem_B_space_with 128`.** In words: the same as `theorem_B_space`, with
   the bit budget `2^128 · N · (b_𝒰 + χ²)` instead of `2^30 · N · (b_𝒰 + χ²)`.
6. **`F2e2e.theorem_B_joint_2e128 : BSpace.Theorem_B_joint_with 128`.** In words: the same as `theorem_B_joint`, with
   the budget `2^128 · N · (b_𝒰 + χ²)`.
7. **`F2e2e.theorem_main_full_2e128 : Theorem_main_full_2e128`.** The statement is the six-fold conjunction with the
   two (B) space conjuncts at `2^128`. In words: Main Theorem (A)+(B)+(C) with the bit budget's constant `2^128`.
   * The Spec proves `Theorem_main_full → Theorem_main_full_2e128` (an `example`), so this form is implied by item 4.
   * The `2^128` forms were the targets of a staged proof plan, whose earlier proof chain gives the constant
     `2^107`; they are certified alongside the paper's form.

**Relation to the paper.** (A), (B) and (C) are claimed in full, with the paper's constants:
* (A) includes its computational clause;
* (B) includes its bit clause with `2^30`, its "accessed only through their values on the samples", and its
  "stores only current evaluations, not old queries";
* (C) is as in v2.2c.

**Remaining non-claims:**
* (A): the `k`-independent absorbed sample form (a corollary). The workspace bound of `Theorem_A_eff` does not count
  storing the sample, which lives behind the query oracle; storing it would add `n` cells.
* (C): rules 2–3 of Def R:def:streaming-model (strict-model architecture; the stronger Theorem R:thm:main mentions
  them, e2e (C) does not), and any update-time bound.
* (B): no time bound (the paper's clause has none), and the working space of the evaluation oracle (excluded by the
  paper).
* The v2.2c docstrings that say "does NOT claim" remain true of `Theorem_A_statistical` / `Theorem_B_statistical`
  themselves. The clauses are claimed by the v3.1 headlines, as the v3 header (§0 of the appended part) says.

## 2. Spec versions and shas

Every audited version was reviewed by an independent multi-stage statement audit (several checks and a consolidation
per round).

| version | sha256 | status |
|---|---|---|
| v1 | `6a5254ff6e8d0fe81bdd9bb78b404d65c331e77d4c7f4e87c74f0e39255e5bee` | round-1 statement-audit record: NOT FAITHFUL (7 MAJOR, M1–M7). Superseded |
| v2 | `cc04b02b6187428568eba6953f90e76578ae75e8edaebaea3827a896c81b5124` | round-2 record: (A), (B) FAITHFUL WITH MINOR ISSUES; (C) UNDETERMINED (U-C) |
| v2.1 | `9aeafbeb0cdb9fae8df0ab3e1c2858ee72a53e374a155de2a7bf7f29e2a4959a` | explicit arithmetic workspace (§3.2). Focused (C) check: FAITHFUL WITH MINOR ISSUES; one minor, dR |
| v2.2 / v2.2b | `ae054eb6…` / `a34af531…` | F-dR docstring; title and footer labels |
| v2.2c | `c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f` | locked 2026-10-25 (lock commit 58fed18). Certified at 7802a6a (gate, CI, kit); red teams A and B on v2.2c |
| v3 candidate | `9dd5490e90b10eb1a9b46a9267b5840f0e177115312117294f790be45a1a7caa` | v2.2c prefix + §6–§8. Statement audit (check 2): three MAJORs, F-A (§6 advice through parameter-dependent real literals), F-B1 (off-sample evaluation) and F-B2 (old queries could be stored). Superseded |
| v3.1, audited text | `2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e` | v3 + the three fixes (user decision): one fixed RAM program with rational literals and the public input `adaInput`; `OracleFor`; history-free states. v3.1 statement audit on `2f4f3c09…`; main carries this commit only after the integrator's sign-off on a FAITHFUL verdict |
| **v3.1** (this kit) | **`7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`** (`SPEC_LOCK.sha256`: one line `<sha>  F2e2e/Spec.lean`) | `2f4f3c09…` plus one code fix and documentation minors, all in the appended part. Code fix F1 (v3.1 audit, check 2): new `BSpace.alg2Retained` / `alg2RetainedOf`, now the reference state of the history-freeness clause in `Theorem_B_space_with` and `Theorem_B_joint_with`. Documentation: red-team phase-1 minors m1 (the §7 header now states that history-freeness is a conjunct), m2 (the S0 title reads v3.1) and m4 (the `Theorem_A_eff` docstring notes that storing the sample is not counted), and two §6 documentation minors |

* **Prefix.** The first 142,145 bytes of the v3.1 Spec are the locked v2.2c file. The v2.2c headlines and every v2.2c
  definition are byte-identical.
* **Check the challenge.** `Challenge.lean` above its `### The challenge` section must be a verbatim copy of the
  v3.1 `F2e2e/Spec.lean` (sha256 `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`).

## 3. Trust chain built by the project (context only: re-verify everything yourself)

1. **Spec frozen and sha-pinned.** Workers cannot edit the Spec, the gate or the build files. On this commit,
   `scripts/gate.sh` pins `PINNED_SPEC_SHA` = `LOCKED_SPEC_SHA` = `7d40afe2…` (the v3.1 sha) and verifies
   `SPEC_LOCK.sha256`.
2. **Gate G1** (`scripts/gate.sh`, adapted from cut2), run on every integration. It is as for v2.2c, extended:
   * **Static part.** `scan_forbidden.py` (comments and strings stripped) bans `sorry`, `admit`, `axiom`,
     `native_decide`, `implemented_by`, `extern`, `unsafe`, `opaque`, `partial def`, `macro`/`syntax`/`elab`,
     `run_cmd`, `initialize`, `Lean.Elab`/`Lean.Meta`, `IO.`, debug options and search tactics.
   * **Extra Spec rules:** no `instance`, `attribute`, `set_option`, `open … in`, `local`, `scoped`, notation or
     reducibility attributes.
   * **Structure checks.** Import-DAG rules: the library is independent of the headlines; only `F2e2e.Headline`
     declares the headline theorems. For v3.1, R1 covers `F2e2e/AEff/` and `F2e2e/BSpace/`, and R2/MENTION cover the
     new headline names (a name with a further suffix, e.g. `…_proof`, is not a headline name). A declaration-clash
     check also runs. The temporary proof-side Spec copies are deleted at the lock.
   * **Elaborated part.** `F2e2e/GateCheck.lean` (built with the sha-pinned `F2e2e/Gate.lean`) fails iff a checked
     dependency cone contains `sorryAx`, a non-standard axiom, or an `implemented_by`/`extern`/`unsafe` constant.
     `F2e2e/GateTest.lean` is not shipped; the kit has its own negative controls.
3. **Axioms.** `#print axioms` of every headline theorem ⊆ {`propext`, `Classical.choice`, `Quot.sound`}. Closing
   gate: `evidence/<candidate rev>/`, produced on this exact commit; see the kit README.
4. **Full CI.** `lake build`, then `leanchecker` on every module. Result: `evidence/<candidate rev>/`.
5. **Fresh replay.** `leanchecker --fresh F2e2e.Headline`. Result: `evidence/<candidate rev>/`.
6. **Comparator kit** (`comparator/mk_kit.py`, `run_kit.sh`; eleven challenges, listed in the kit's
   `comparator_config.json`).
   * **Contents.** The verbatim Spec with sorry'd `*_challenge` theorems.
   * **Kernels.** comparator checks with the Lean kernel and nanoda. con-leche master `0d2f467b`, built with official
     Lean 4.35.0, is run in `--verified` mode as a third, independent checker. On v2.2c it accepted all 78,188
     declarations of the solution export (peak 6.6 GiB, red team A).
   * **Negative controls.** `A_sorry`; `B_wrongdef` (every Prop the statements use redefined as `True`, parametrized
     Props keeping their binders); `C_axiom`; plus a con-leche mutant (a challenge theorem retyped to `False`).
   * **Results:** `evidence/<candidate rev>/`, produced on this exact commit; see the kit README.
7. **Where the proofs live** (all assembled in `F2e2e/Headline.lean`; its module docstring lists the proof
   constants):
   * `theorem_A_eff`: `F2e2e.AEff.theorem_A_eff_proof` (`F2e2e/AEff/Final.lean`). It goes through
     `theorem_A_eff_of_exports` (`F2e2e/AEffU/GlueU.lean`), from the seven fragment contracts of the uniform
     program in `F2e2e/AEffU/ContractsU.lean`.
   * `theorem_B_space`, `theorem_B_joint` (`2^30`): `F2e2e.BSpace.theorem_B_space_proof` and
     `F2e2e.BSpace.theorem_B_joint_proof` (`F2e2e/BSpace/O2AssembleFinal.lean`).
   * The `2^128` forms: `F2e2e.BSpace.theorem_B_space_2e128_proof` and `F2e2e.BSpace.theorem_B_joint_2e128_proof`
     (`F2e2e/BSpace/AssembleFinal.lean`; `theorem_B_space_of_le` / `theorem_B_joint_of_le` for every
     `e ≥ bsChainExp = 107`).
   * `theorem_main_full` and `theorem_main_full_2e128` are conjunctions.
   * The `Theorem_A_eff` cone is `F2e2e/AEff/Final.lean` → `F2e2e/AEffU/*`, plus the AEff RAM toolkit. The unused
     v3 per-`(L, n)` AEff fragments (`RTheta`, `RHalt`, `Init*`, `RUpd*`, `WaterFillRam*`, `WaterFillBridge`,
     `RCase`/`RCaseLoop`, …) are sorry-free and gated, but outside every headline cone, so red teams need not chase
     them.
8. **Non-headline lemmas** (STATEMENT_REVIEW §F) are context, not part of the claim: strict-model rules 2–3, the
   big-step → machine bridge, determinism, and the arithmetic workspace.

## 4. Inputs (use ONLY these)

| input | where | check |
|---|---|---|
| Proof sources | `f2e2e_src.tar.zst`: a Lake project (`lean-toolchain`, `lakefile.toml`, `lake-manifest.json`, `F2e2e/`) | `SHA256SUMS` |
| Documentation (context only, untrusted) | tarball root: `STATEMENT_REVIEW.md` (conventions, junk-value risks, audit history; with the "Spec v3 additions" section, in its v3.1 form), `F2E2E_SPEC_AUDIT.md` (statement-audit record), `SPEC_LOCK.sha256`, this brief. `PLAN.md` and `F2e2e/GateTest.lean` are left out by lead decision. The paper (`source/`) is never shipped | `SHA256SUMS` |
| Trusted statement | `F2e2eChallenge/Challenge.lean` (see §2) | `SHA256SUMS` |
| Solution (untrusted) | `F2e2eChallenge/Solution.lean` | `SHA256SUMS` |
| Comparator config | `comparator_config.json` (`enable_nanoda: true`; permitted axioms `propext`, `Quot.sound`, `Classical.choice`) | `SHA256SUMS` |
| Lean toolchain | official `lean-4.33.1-linux` release; record sha256 and `lean --version`; no pre-installed toolchain | record |
| Mathlib and deps | the revisions pinned in `lake-manifest.json` (Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`), official cache or built from source | record revs |
| Checkers | `leanchecker` (ships with the toolchain); comparator; lean4export built with the 4.33.1 toolchain (a 4.33.0 build rejects 4.33.1 oleans); landrun; nanoda_lib; con-leche master `0d2f467b` (`--verified`; build it with official Lean 4.35.0; the older 65e74db4 did not complete at full scale on v2.2c) | record commits and hashes |

**Independence.** Work only in your own directory. Do not read `~/lean_campaigns/f2e2e*`, any agent transcript, or
any file of the original campaign. Verify every kit file against `SHA256SUMS` before use and again at the end.

## 5. Tasks (in priority order)

1. **Statement review.**
   * Compile `Challenge.lean`. Print the eleven challenge statements and every project definition they use
     (`#print`, `pp.all` where useful). List the Mathlib definitions they depend on.
   * Check them against §1 and look for loopholes (§6, §7).
   * The Spec's 41 `example`s must pass: 18 from v2.2c, plus 23 in §6–§8 (including the F1 example on
     `alg2Retained`), covering:
     * RAM sanity, including a program on a one-cell input that satisfies `RatLits`;
     * the oracle machine;
     * the honest oracle satisfying `OracleFor`;
     * `alg2StateAt` agreeing with `alg2Exec`'s fold;
     * the `Iff.rfl` shape checks;
     * `Theorem_main_full → Theorem_main_full_2e128`.
   * So must the 23 proved `theorem`s of §6: RAM determinism, the input address map of `adaInput`, losslessness of the
     output relation, and conformance of the cascade's own outputs.
2. **Clean build.** Unpack into a fresh directory, run `lake exe cache get` and `lake build`, and log every command.
   Record the module count, failures and warnings. Add the challenge directory as a `lean_lib`; write and log that change
   yourself.
3. **Kernel checks.**
   * (a) `leanchecker` on every project module, plus `--fresh` on `F2e2e.Headline`.
   * (b) comparator with the kit's config, exactly as in its README (landrun sandbox, Challenge built before
     Solution). Record the full output.
   * (c) con-leche `--verified` on the solution export.
   * (d) Your own `#print axioms` for the eleven theorems, in a file you write.
4. **Negative controls.** Show that comparator rejects:
   * (i) a `sorry` solution;
   * (ii) a solution with a changed Spec definition. Examples: `bSpaceBound` with `2 ^ (e + 1)`; `oracleIdx := 0`;
     `OracleFor` without its first clause; `alg2StateAt` returning the initial state; `adaInput := []`;
     `RamConf.space := 0`; `opWork := 0`; `ctrlWork` dropped;
   * (iii) an added axiom.
5. **Exploit hunt (static).**
   * Search all sources, including `F2e2e/AEff/` and `F2e2e/BSpace/`, for `notation`, `syntax`, `macro`, `elab`,
     `open … in`, `instance`, coercions, `set_option` (`debug.*`, `backward.*`, `maxRecDepth`), `unsafe`,
     `implemented_by`, `extern`, `opaque`, `axiom`, `sorry`, `native_decide`, `ofReduceBool`, custom `Decidable`
     instances, reducibility attributes, `addDecl`/`modifyEnv`, and IO.
   * Assess every hit, including `F2e2e/Gate.lean` (it contains `elab`; imported only by `F2e2e/GateCheck.lean`,
     never by the headline).
6. **Report.**
   * `VERDICT.md`: `ACCEPT`, `REJECT` or `INCONCLUSIVE`; the reasons; a table of checks with results and logs; all
     deviations.
   * `TRACE_MANIFEST.tsv` (path, bytes, sha256) covering every input, command log and output.

## 6. Known modeling choices and junk-value risks (attack these first)

Full tables: `STATEMENT_REVIEW.md` §0, §A.3, §B.3, §C.3 (v2.2c) and the "Spec v3 additions" (§6.2–6.4, §7.2–7.4,
§8).

**v2.2c (unchanged; see the v2.2c brief for detail).**
* Conventions: `Real.log` (natural, `log 0 = 0`); ℕ subtraction; `x/0 = 0`; `sInf ∅`; `Type` universes; outer measures.
* (A):
  * pre-drawn noise table;
  * out-of-range reads;
  * the ε-choice `entropicArgmin`;
  * `laplaceLaw`/`Measure.map` degeneracies (excluded by the probability conjunct);
  * the exact `τ_aux` record;
  * `clip01`.
* (B):
  * refuse-and-continue dummies;
  * `CAP_ABORT` in the pre-request state (sticky abort = failure);
  * existential tape length;
  * pass budget;
  * draw order and priorities;
  * ℚ rounding/clipping;
  * the ε-choice `learnerWeights`;
  * reaching `T_j^max` counts.
* (C):
  * uniform programs that see dyadic exponents;
  * fresh tapes, stuck past the end;
  * the box promise;
  * relational `StreamExec`;
  * certified bits: `confBits`, `stepWork = opWork` of the Spec-defined `arithRun`, and `ctrlWork`.

**NEW in v3.1 (attack these first):**
* **§6 real RAM** (`AEff.RamExp/RamCond/RamStmt`, `RamExec`, `RamProgram.RunsWithin`).
  * Model: a BSS-style real RAM with exact reals, `+ − × ÷ exp log`, indirect addressing through `ramNat` (stuck off
    ℕ), and no floor, mod or bit operations.
  * Cost: sequencing is free; each executed statement costs `1` plus its evaluated expression nodes; a call costs 1.
  * Workspace: the address watermark `top` plus the call depth `peak`. The output stream and the oracles are not
    counted.
  * Phases: the control restarts every round, and only memory persists.
  * Oracles: the query oracle gives `qv i ℓ` (`0` off-range). The noise oracle gives this round's `ξ_i`, `ν_i`,
    `ζ_i`, and the threshold table `ρ^{(a)}_b` for `b ≤ i`, which can include episodes not yet started; the conformance
    relation pins every output.
  * Output: losslessly streamed (`ADAOutputStreamed`), required for every `ω` and all real query values.
* **§6 uniformity (F-A).**
  * `∃ P` comes before `(k, α, β)`: one program for all parameters. The v3 size bound `P.size ≤ C·L` is gone, since
    `P` is fixed.
  * `P.RatLits`: every literal is a rational, so a fixed real constant cannot encode advice.
  * The parameters arrive only as the input image `adaInput k α β`. It holds `O(L)` reals, all functions of
    `(k, α, β)`, laid out at fixed addresses with zero padding. The initial memory is `RamConf.ofInput`, and an input
    cell counts toward the workspace once it is read.
* **§7 oracle machine.**
  * `BSpace.stepO` is the locked `step`, except when `[sel, r, q]` returns to `call 1000 a`, which gives `orc sel r q`
    in one step.
  * **`OracleFor` (F-B1).** The oracle of a request is pinned only at the codes of sample records (`sel = 0`:
    `⌊2^q f(s ℓ)⌋`) and for the clipped endpoints (`sel = 1, 2`). Everything else is adversarial: the statement holds
    for EVERY consistent oracle family, quantified after the requests. The claim is that this is equivalent to a stuck
    semantics, because an unconstrained answer can be made larger than the budget.
  * **History-free states (F-B2).** `VImplRun` makes the between-request states explicit. `∃ enc` is chosen after the
    sample, before the coins and the requests, and requires `states t = enc (alg2StateAt (alg2Params …) t (views of
    rounds < t) ω)` for every `t`, with the retained-only reference state of fix F1: `alg2Retained` zeroes the score
    coordinates `G j i` outside `j < p ∧ i < n_j`, which `alg2Correct` updates but nothing reads. `alg2StateAt` is the
    state component of `alg2Exec`'s fold.
  * Records are handed over as codes; the initialization runs with `nullOracle`; the tape is threaded across runs.
  * The responses must parse as `alg2Mech`'s, for every round `t ∈ ℕ` and every valid request sequence.
  * The per-step charge is the same as in (C).
* **`∃ c_B, ∀ c ≥ c_B`** comes right after the public parameters. `c_B` cannot depend on the domain, codes, sample,
  coins or requests. The machine's `coin` is stuck on the empty tape (no sentinel), so a proof implies bounded
  consumption. `c` is not an input.
* **`Theorem_B_joint_with e`**: one tape length for both (B) claims, for all `c ≥ c₀`.
* **The parametrized constant**: `bSpaceBound e N b χ = 2^e·N·(b+χ²)`. `Theorem_B_space` / `Theorem_B_joint` /
  `Theorem_main_full` fix `e = 30`; the `2^128` forms fix `e = 128`.

## 7. Concrete attack suggestions

**Carried over from v2.2c:**
1. Vacuity: are the hypotheses satisfiable, and do the predicates have natural witnesses?
2. Quantifier order: `∃ C`, `∃ alg`, `∃ P` and `∃ impl` come before all parameters; can `∃ c`, `c_B` or `enc` encode
   advice?
3. Measure-theoretic tricks: outer measure, `Measure.map`/`withDensity`, coin spaces, the `∑_tapes` normalization.
4. Junk values at the range endpoints.
5. The pinned mechanisms, diffed line by line against Def I.1.8 and Algorithm 2.
6. The U-C accounting.
7. Stuck steps.
8. "Every execution".
9. Parsing, precedence and casts.
10. The Mathlib API meanings at `0df444a3`.

**Flagged risks of v3.1 (each an explicit attack item; attack these first):**

11. **Flagged risk: `Theorem_A_eff` uniformity and advice (`∃ P` before `k α β`).**
    * Is `∃ P` really before `(k, α, β)`, with `C` and `P` independent of them? (In v3, the program came after the
      parameters and could embed parameter-dependent real constants: advice.)
    * Can the program obtain parameter-dependent information other than through `adaInput`, for example through the
      oracles?
    * Is a fixed program with unbounded `n`-dependence, such as loops over `n`, charged correctly?
12. **Flagged risk: `RatLits` and the `adaInput` image.**
    * Is `RatLits` checked on every literal of every procedure and of both phases? Could a non-rational real enter
      through another route? Computing from rationals and from the input is legitimate.
    * Does `adaInput` give the program anything beyond functions of `(k, α, β)`? It must not contain query values or
      coins. Is its length `O(L)`? Could the padding conventions hide information?
    * Is `RamConf.ofInput` charged correctly: is the workspace watermark raised by reading input cells?
13. **`Theorem_A_eff`: can the RAM model be gamed?**
    * Is every executed operation charged? Check that `while` charges its condition on every iteration, that calls
      and returns are charged, and that nested expressions are charged per node; sequencing itself is free.
    * Can the program store data where it is not counted: the output stream, the oracles, or the call stack beyond
      `peak`?
    * Is `ramNat` strict (non-natural addresses are stuck, so they can only hurt)?
    * Does `RunsWithin` really reset the control and the output every round, and does it forbid reading the
      output back?
    * Is the noise-table exposure `b ≤ i` (including future episodes) harmless, given that the outputs are pinned?
    * Could a program that packs reals into one cell or extracts bits by comparisons beat `C·n`?
    * Conformance: does `ADAOutputStreamed (adaL α) out (adaCascade …)` pin `(a_i, τ_aux,i)` uniquely
      (`ADAOutputStreamed.unique`)? Is the cascade's own output streamable (`adaCascade_streamed`)?
14. **Flagged risk: `OracleFor`'s quantifier and record-code indexing.**
    * Placement: the oracle family is quantified universally per execution, after `∃ enc`, the coins and the
      requests, and before `∃ states`. Can an implementation exploit that `states` may depend on the oracle family?
    * Indexing is by record CODE, `orc 0 (code (s ℓ)) q`, not by sample index. So the implementation must keep the
      records, and this storage is what the paper's `N·b_𝒰` term pays for. Repeated records share a code and a value.
      Codes of non-sample records, and selectors other than `0, 1, 2`, are unconstrained. Injectivity of `code` is a
      hypothesis.
    * The precision `q` is program-chosen: negative `q` reads as `0`, and the answer is charged in the next
      configuration.
    * Is the claimed equivalence with a stuck semantics right? An unconstrained call fails against a consistent
      oracle whose answer exceeds the budget. Is `OracleFor` satisfiable (the honest-oracle example)?
15. **Flagged risk: the existential placement of `enc`, and history-freeness.**
    * `∃ enc` comes after the sample and before the coins, the requests and the oracles. Can `enc` carry anything
      but a function of the sample and Algorithm 2's state?
    * Is `alg2StateAt` exactly the state component of `alg2Exec`'s fold (the `rfl` examples)?
    * Is `alg2Retained` right? It should zero exactly the never-read coordinates (`G j i` outside `j < p ∧ i < n_j`).
      Are `T` and `thrInt` really `0` outside `j < p` in every reachable state, as its docstring claims?
    * Can an implementation hide history anywhere other than `states t`, for example in the tape remainder, the
      control stack or an oracle? Check that every run starts from a fresh initial configuration on
      `[params, states t, kind]`.
    * Is the post-halt convention of `Alg2State` (after `CAP_ABORT`, the pre-request state with the flags set) an
      over-constraint or a loophole?
16. **Flagged risk: `2^30` versus the staged `2^128`.**
    * The kit certifies both. Do the `2^30` theorems prove exactly `BSpace.Theorem_B_space_with 30` /
      `BSpace.Theorem_B_joint_with 30`, as the challenge statements pin?
    * Is the `2^30` chain (`O2AssembleFinal.lean`) sound on its own, independently of the `2^128` chain
      (`AssembleFinal.lean`)?
    * Is `Theorem_main_full_2e128` weaker than `Theorem_main_full` only in the budget constant of the two (B) space
      conjuncts (the proved implication example)? Does the parameter `e` of `bSpaceBound e` occur anywhere else?
17. **Flagged risk: junk values.**
    * `truncIdx q.toNat`: a negative precision reads as `0`.
    * The endpoints are clipped to `[−1, 2]` (`max (-1) (min 2 ·)`).
    * `OracleFor` constrains only the codes of sample records.
    * In the RAM, `x / 0 = 0` and `Real.log 0 = 0`; `ramNat` is stuck off `ℕ`; `RamConf.ofInput` reads `0` past the
      input.
    * The `adaInput` padding is zeros.
    * Small values: `b_𝒰 = 0` means `|𝒰| ≤ 1`. With `M = J = R = 0` every request is over-cap and gets a dummy.
    * `parseVResponse` needs `d > 0`.
    * ℕ subtraction and casts in the stage records (`adaBlock`, `adaOffset`, `adaNmax`).
    * Check each against the paper's intent.
18. **`∃ c_B` and `Theorem_B_joint`.**
    * Is `c_B` placed so that it cannot depend on the data? Is `Theorem_B_space` satisfied by an implementation that
      relies on a particular tape length?
    * Do the joint-reading monotonicity (STATEMENT_REVIEW §7.1) and `Theorem_B_joint` together close the gap between
      `∃ c` (statistical) and `∀ c ≥ c_B` (space)?
    * Are the guarantee and the reproduction in `Theorem_B_joint` about the same `alg2Mech … c`, the same `impl` and the
      same `c`, for all `c ≥ c₀`?
19. **The conjunctions.** Is each of `Theorem_main_full` and `Theorem_main_full_2e128` exactly its six-fold
    conjunction (the `Iff.rfl` examples)? Do all eleven challenges use the Spec's definitions verbatim?

## 8. Resources and conduct

* Hosts: red team A on woodruffd3, red team B on woodruffd4. Local CPU only, official toolchain and Mathlib cache.
  Do not use the campaign's build hosts (woodruffd6, woodruffd7, woodruffd14). Keep memory moderate and use `nice`.
* **Never push, upload or publish anything.** Report to the integrator (conversation
  `0ffe9639-f7fb-46b7-908e-306336e5d2bc`) with `send_message`: a status about every 45 minutes, then the verdict and the
  paths of `VERDICT.md` and `TRACE_MANIFEST.tsv`.
