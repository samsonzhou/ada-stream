# f2e2e Lean statement (Spec.lean): independent multi-stage statement audit

> [!IMPORTANT]
> Confidential, need-to-know: summary record of an independent multi-stage statement audit of `F2e2e/Spec.lean`; raw audit outputs are internal and not part of this record.

- **Authorization:** the user's request at 9:13 PM PT: "please leanify the long version in the usual way we have been leanifying papers in this chat space". The usual way includes an independent multi-stage statement audit before the spec lock.
- **Budget:** a fixed total audit budget with a hard guard; round 1 had a capped share, and round 2 (re-audit and final) the remainder.
- **Paper:** e2e.tex (144 pp; tgz md5 `3ccb54d5…`, pdf md5 `158a3f8f…`). The Main Theorem has three parts:
  - (A) Thm I.1.1: adaptive data analysis (ADA), with the explicit bound I:eq:main_explicit_bound and its O-form;
  - (B) R:thm:validation_ada: interval-validation ADA;
  - (C) R:thm:main: robust turnstile F2 in at most 2^512 ε⁻² Λ¹⁵ bits.
- **Spec under audit:** v1, sha256 `6a5254ff6e8d0fe81bdd9bb78b404d65c331e77d4c7f4e87c74f0e39255e5bee`, at campaign commit 06ddff3. Headlines: `F2e2e.Theorem_A`, `F2e2e.Theorem_B`, `F2e2e.Theorem_C`.
- **Setup:**
  - Environment: Python execution only, with no web access and no Lean.
  - Inputs:
    - Spec.lean;
    - STATEMENT_REVIEW.md;
    - PLAN.md (context only);
    - the e2e LaTeX source and PDF;
    - cut2's Spec v2.2 and CUT2_SPEC_AUDIT.md (context only);
    - the pinned Mathlib 0df444a3 (Lean 4.33.1).
  - Every stage answered Q1–Q8 and gave a required-changes list.

## Bottom line

| | Spec | verdicts |
|---|---|---|
| Round 1 | v1 `6a5254ff…` | 3 checks in rotation + consolidation: **NOT FAITHFUL** (unanimous; 7 MAJOR) |
| Round 2 (re-audit) | v2 `cc04b02b…` | 2 checks + consolidation: (A) and (B) **FAITHFUL WITH MINOR ISSUES** (docstring fixes only); (C) **UNDETERMINED** (U-C). The final names **Spec.lean, sha256 `cc04b02b6187428568eba6953f90e76578ae75e8edaebaea3827a896c81b5124`**; its verdict is UNDETERMINED on all three (see the note in Round 2). |
| v2.1, mechanical pre-check | v2.1 `9aeafbeb…` vs v2 | **PASS.** The comment-stripped code delta is exactly +101/−3: the new §3.2 arithmetic-workspace definitions, one changed conjunct in RunsWithinBits, and adjusted sanity examples. (A)/(B) code is token-identical. step, StreamExec and Theorem_C are byte-identical. The docstring fixes dA, dB, dC1, dC2 and F6 are applied in substance. |
| v2.1, single (C)-only check | v2.1 `9aeafbeb…` | **FAITHFUL WITH MINOR ISSUES**, with (A)/(B) NOT REVIEWED. "Covers: SpecV2_1.lean, sha256 `9aeafbeb0cdb9fae8df0ab3e1c2858ee72a53e374a155de2a7bf7f29e2a4959a`". **U-C is resolved.** |
| v2.2, mechanical check | v2.2 `ae054eb6…` vs v2.1 | **PASS.** Code tokens are identical to v2.1 in every section. The only Spec hunk is the `regBits` docstring (F-dR, exact match), and the §C.3.1 prose is exact. The §F.4 parenthetical is fixed. |
| v2.2b, mechanical check | v2.2b `a34af531…` vs v2.1 and v2.2 | **PASS.** Code tokens are identical to v2.1 in every section. Against v2.2 the diff is only the title (L4) and footer (L105–107) labels. F-dR is exact in the Spec and the review, and the §F.4 fix is present. |
| **v2.2c (lock file), mechanical check** | v2.2c `c28be50e…` vs v2.2b and v2.1 | **PASS.** Against v2.2b the diff is exactly one line, L105 (the tool-named round label → "audit rounds"). Code tokens are identical to v2.2b and v2.1. A scan for internal tool and model names prints nothing. |

> [!IMPORTANT]
> **State after the v2.1 check and the v2.2/v2.2b/v2.2c mechanical checks:**
> - (C) is FAITHFUL WITH MINOR ISSUES on v2.1, and its one minor (dR) is fixed exactly in v2.2 and its successors.
> - (A)/(B) code is unchanged since v2 (verified mechanically). Their round-2 assessment, FAITHFUL WITH MINOR ISSUES from both checks and the consolidation, carries over, and their docstring fixes dA and dB are applied.
> - Caveat: no single audit stage reviewed all three headlines of the final file together. The round-2 final did not independently re-check (A)/(B) because the budget guard cut it off. This was a verification limit, not a finding.

## Lock record

**Lock file:** Spec v2.2c, `notes/spec_v2_2_draft/SpecV2_2c.lean`, **sha256 `c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f`** (2,344 lines, 142,145 bytes).
- Lineage: v2 `cc04b02b…` (round 2) → v2.1 `9aeafbeb…` (code delta checked mechanically; the audit's (C) check covers this file) → v2.2 `ae054eb6…` (+ F-dR docstring) → v2.2b `a34af531…` (title and footer labels) → v2.2c (L105: tool name → "audit").
- **v2.2c differs from the audited v2.1 only in comments and docstrings.** Code tokens with comments stripped are identical (17,683), verified mechanically at each step.
- The Spec mentions no internal tool or model names (a scan for them prints nothing).
- Package from v2.2b: STATEMENT_REVIEW `864b7e77…`, V2_1_TO_V2_2 `dfa04675…`, SHA256SUMS `f790cea4…`.
- The formalizers report that it compiles: `scripts/lean1.sh` EXIT 0 for v2.2/v2.2b. The integrator pre-authorized the lead to lock v2.2c after its own diff, grep and compile checks pass.

**Final per-headline status across rounds:**

| headline | round 1 (v1) | round 2 (v2) | v2.1 check | carried to v2.2 | status at lock |
|---|---|---|---|---|---|
| (A) `Theorem_A_statistical` | NOT FAITHFUL as the full Main Theorem (A): D1, D4, M4 | Re-scoped per F4 (the O(kn)/O(n) clause is an explicit non-claim). Check 1: FWMI. Check 2: FWMI. Consolidation: FWMI. Final: UNDETERMINED, as verification status only | NOT REVIEWED | Code unchanged v2→v2.1→v2.2 (mechanical); dA applied | **FAITHFUL WITH MINOR ISSUES (minors fixed)**, as a re-scoped statistical statement |
| (B) `Theorem_B_statistical` | NOT FAITHFUL: D2, D3, D4, M5 | Re-scoped (the bit-space clause is an explicit non-claim). Check 1: FAITHFUL. Check 2: FWMI. Consolidation: FWMI. Final: UNDETERMINED, as verification status only | NOT REVIEWED | Code unchanged; dB applied | **FAITHFUL WITH MINOR ISSUES (minors fixed)**, as a re-scoped statistical statement |
| (C) `Theorem_C` | NOT FAITHFUL: M6 (valSize ≠ bits), M7 (strict rules) | UNDETERMINED in all four stages (U-C). M7 was accepted as a non-claim (V6) | **FWMI**: U-C resolved; dR | dR applied exactly (F-dR); code unchanged | **FAITHFUL WITH MINOR ISSUES (its one minor fixed)** |

**Which stage covered which part of the locked file:**

| part of SpecV2_2c.lean (lock file) | reviewed by | changed since then? |
|---|---|---|
| Header and module docstring, scope statements (L1–107) | Round 2: V2 and V4, scope honesty. v2.1 check: the (C) scope text | Docstrings only, verified mechanically: dC1, F-dR, the v2.2b title and footer labels, and the v2.2c L105 wording |
| §0–§2: (A)/(B) parameters, the Def I.1.8 cascade, Algorithm 2, protocols and headlines | Round 2: check 1, check 2 and consolidation in depth. The final only structurally | Code unchanged since v2 (mechanical v2→v2.1→v2.2). Docstrings dA, dB and F6 verified mechanically |
| §3: DSL, CEK small-step machine, `confBits` | Round 2, all stages: serialization and control encoding OK | Unchanged code. Re-read by the v2.1 check in the context of U-C |
| §3.2 (new in v2.1): `regBits` … `ctrlWork`, the arithmetic workspace | The v2.1 check only: VC1, VC2, 29,445 exact cases, and the 2^63×2^63 example charged 1034 bits | `regBits` docstring replaced by F-dR in v2.2, verified exact |
| §4: the (C) headline. `RunsWithinBits`, `StreamExec`, `spaceBoundC`, `Theorem_C` | Round 2, all stages. The changed `RunsWithinBits` condition was reviewed by the v2.1 check | Bodies of `StreamExec`, `spaceBoundC` and `Theorem_C` unchanged since v2 |
| §5: sanity examples | Round 2 (the v2 examples); the v2.1 check (the adjusted examples) | Unchanged in v2.2 |

**Caveats:**
- No audit stage compiled Lean; compilation is the formalizers' report.
- (A)/(B) were not re-reviewed by the audit after v2. Their code is unchanged and their docstring fixes were verified mechanically. The round-2 final's independent pass over (A)/(B) was cut short by my budget guard; this was a verification limit, not a finding.
- §3.2 was reviewed by a single stage: one check with 3 tool turns.
- The docstring fixes in v2.1 and v2.2 were verified mechanically (code-token identity and text presence), not re-read by the audit.

## v2.1: mechanical pre-check and the single (C)-only check

**Pre-check**: PASS.
- Hashes: SpecV2_1.lean `9aeafbeb…`, STATEMENT_REVIEW `11127cfa…`, V2_TO_V2_1 `5d330b41…`, ArithWork `256fe8e6…`, SHA256SUMS `782ed59f…`. All entries verify.
- Code delta, comments stripped: +101/−3.
  - +95 lines: regBits … ctrlWork in §3.2.
  - The RunsWithinBits conjunct is now `confBits c + confBits c′ + stepWork prog c + ctrlWork prog c c′ ≤ S`.
  - A few lines of §5 sanity examples changed or were added.
- §0–§2, i.e. (A)/(B), are token-identical to v2. step, stepN, initConf, StreamExec, Theorem_C and Theorem_A_statistical are byte-identical. spaceBoundC, confBits and Theorem_B_statistical are code-identical.
- The docstring fixes are reworded rather than F1–F4 verbatim, but they are complete in substance.

**Single (C)-only check** (one stage; 3 tool turns, then its verdict):
- Verdict lines: FAITHFUL WITH MINOR ISSUES. Per headline: (A) NOT REVIEWED; (B) NOT REVIEWED; (C) FAITHFUL WITH MINOR ISSUES. Covers `9aeafbeb…`.
- **VC1, VERIFIED:** U-C is resolved. The 2^63×2^63 multiplication step is now charged 530 (footprint) + 400 (mulTrace registers) + 104 (ctrlWork) = **1034** bits. Our run of its program reproduces this.
- **VC2, VERIFIED** (subject to dR): the bit-level algorithms are correct.
  - The adder (with complement), signed add and subtract, shift-add multiplication, restoring division with Euclidean sign fix-up, less-than and equality were checked by invariants.
  - Its program checked 29,445 exact small cases plus large signed cases.
  - No arithmetic routine reads coins, and register counts are determined by the phase.
- **VC4, OK WITH MINOR ISSUES:** no new semantic loophole and no vacuity. One documentation imprecision (dR).
- **VC5, OK WITH MINOR ISSUES:** "the revised proposition has the printed bit-space meaning". Correct dR before locking.
- **dR, MINOR, DOCSTRING-ONLY:** the `regBits` documentation implies a standalone self-delimiting register-file encoding. It is not one: `[]` encodes as `0`, which is a prefix of `[[]]` → `00`. The register count comes from the control phase, which `ctrlWork` covers. The replacement docstring and review prose are F-dR in its report. The definition body is unchanged.
- Caveat (the check's own): no Lean compilation was available.

Report: internal (not part of this record); F-dR is under its "Exact Lean fixes".

## Round 2: re-audit of Spec v2 (`cc04b02b…`, commit 7982cfd)

**Scope decision (coordinator):**
- (A) and (B) are re-scoped as statistical headlines, `Theorem_A_statistical` and `Theorem_B_statistical`. The O(kn)/O(n) clause of (A) and the bit-space clause of (B) are explicit non-claims.
- (C) is Main Theorem (C) as printed in e2e.tex. Space is in certified bits, via a small-step CEK machine with a prefix-free `confBits` encoding and a before-plus-after footprint. Rules 2–3 of Definition R:def:streaming-model are a non-claim (R4-0, per V6).

| stage | Verdict | per headline |
|---|---|---|
| check 1 | UNDETERMINED | (A) FAITHFUL WITH MINOR ISSUES; (B) FAITHFUL; (C) UNDETERMINED |
| check 2 | UNDETERMINED | (A) FWMI; (B) FWMI; (C) UNDETERMINED |
| consolidation | UNDETERMINED | (A) FWMI; (B) FWMI; (C) UNDETERMINED |
| **final** | **UNDETERMINED** | (A) UNDETERMINED; (B) UNDETERMINED; (C) UNDETERMINED. "Covers: Spec.lean, sha256 cc04b02b6187428568eba6953f90e76578ae75e8edaebaea3827a896c81b5124" |

**V-answers.** The consolidation's answers are definitive; the final's dispositions are in brackets.
- **V1:**
  - M3, M4 and M5 are FIXED. [The final calls M3 "PARTLY FIXED for verification purposes": the defect is structurally repaired, but exact identity with the Part I/II source was not re-checked.]
  - M6 is partly fixed: the serialization is repaired, and U-C remains.
  - M7 no longer applies to the printed-e2e target.
- **V2:** VERIFIED. The re-scoping is honest. Proving the Props must not be advertised as verifying every clause of printed (A)/(B).
- **V3:** PARTLY. The serialization and control overhead fit inside the bound; the arithmetic workspace does not (U-C).
- **V4:** PARTLY [final: VERIFIED]. The non-claim is clear, with no ghost logs. The remaining defect is dC1.
- **V5:** PARTLY. Documentation only (dA, dB, dC1, dC2); nothing new for (A) or (B).
- **V6:** VERIFIED. Leaving Part II's strict rules out of printed Main Theorem (C) is acceptable. In the audit's words, a citation to a stronger theorem "does not import every additional conclusion" of it.
- **V7:** VERIFIED. The existential tape length c is harmless: it is chosen before the domain and controller, and exhaustion counts as failure.
- **V8:** VERIFIED. The probability and measurability properties are conjuncts, not antecedents, so no vacuous discharge is possible.
- **V9:** VERIFIED [final: PARTLY, since exact source conformance was not re-checked]. The silent conventions are acceptable.
- **V10:** NOT VERIFIED [final: PARTLY]. This is U-C.

**U-C (UNRESOLVED; potentially MAJOR; (C)).** The missing implication, verbatim:
- "Every relevant machine transition has a uniform implementation with the same result and coin consumption, whose complete live binary storage is bounded by the charged before-plus-after footprint, or by another explicitly accounted quantity already inside spaceBoundC."
- Arithmetic is atomic. For example, a 2^63 × 2^63 step has a footprint of 271 + 259 = 530 bits.
- "Up to a constant", proof slack, and the CEK serialization bridge do not establish it.
- Fixes: prove the exact bridge for the current machine (preferred), or use a fully charged binary-transition model. The consolidation's F5 is such a model; the final does not endorse it because it did not inspect it.

**Required changes (round 2):**
1. DOCSTRING-ONLY:
   - dA: STATEMENT_REVIEW.md:73 wrongly says the sample sum was parenthesized.
   - dB: the counter-monotonicity explanation in §B.3 B14 must allow for an abort rolling back the counts.
   - dC1: the claims that the separate strict-model lemmas are "proved" (Spec.lean:59–60, 1980–1981) conflict with §F's "in progress".
   - dC2: the M6 row should state the actual adjacent-configuration footprint contract.
   - The exact texts are in the consolidation's F1–F4. F6 (the sampler example's "reads true, false" means Bernoulli outcomes) is optional.
2. CODE / model certification: resolve U-C before (C) is locked.
3. Final's verification items before lock:
   - compare the (A)/(B) mechanisms independently with the Part sources;
   - inspect the pinned Mathlib definitions listed under Q4;
   - review any replacement machine in full.

**Records:** the stage reports, the inputs (including the round-1 reports, Spec v1 and the full v1→v2 diff), the scope and the questions are internal and not part of this record.

## Round 1 (Spec v1)

**Consolidated verdict:** "Do not lock Spec.lean as a faithful statement of the Main Theorem. Restore R1–R4 and incorporate the local documentation corrections, or explicitly reduce and rename the verification target. The identified omissions are definite; they are not allegations that the paper's theorems or proofs are false."

| stage | headlines | Verdict | per headline |
|---|---|---|---|
| check 1 | (A)+(B) | NOT FAITHFUL | (A) NOT FAITHFUL; (B) NOT FAITHFUL |
| check 2 | (B)+(C) | NOT FAITHFUL | (B) NOT FAITHFUL; (C) NOT FAITHFUL |
| check 3 | (C)+(A) | NOT FAITHFUL | (A) NOT FAITHFUL; (C) NOT FAITHFUL |
| consolidation | all | **NOT FAITHFUL** | (A), (B), (C) all NOT FAITHFUL |
| final | — | not run in round 1 (SKIP_FINAL, by design) | — |

## Per-item assessment (consolidation)

| item | status | gist |
|---|---|---|
| Q1 (A) | PROBLEM | The parameter formulas and the universal O-constant are correct. But the witness is an arbitrary mechanism with a selected n, not the named cascade with its locked allocation. |
| Q1 (B) | PROBLEM | The sample bounds are correct. The subject and allocation differ from Algorithm 2 (N = Σ n_j). |
| Q1 (C) | OK | The uniform algorithm comes before the parameters. The ranges, 2^100, 2^512 and the exponent 15 are correct. (The unit is a separate problem.) |
| Q2 (A) | PROBLEM | The product probability and the population integral are correct. But the analyst does not see the paper's public auxiliary records. |
| Q2 (B) | OK | Finite i.i.d. weights, fair coins, independent controller coins and the certificate event are all correct. |
| Q2 (C) | OK | The output-adaptive adversary, the private bits and the all-time accuracy event are correct. |
| Q3 (C) | PROBLEM | Initialization, uniformity and tape threading are sound. But tree units are not certified bits with the same coefficient, and the strict operational rules are missing. |
| Q4 whole Spec | OK WITH MINOR ISSUES | No operative defect involving log, division, ceiling, ℕ subtraction, rpow, empty types or outer measure. Several documentation claims are false. |
| Q5 whole Spec | OK | No trivial witness was found. Zero-sample and zero-output shortcuts fail. |
| Q6 (A)/(B)/(C) | PROBLEM | Weaker than the paper: implementation identity and public observation (A); internal caps and bit space (B); literal bits and the strict model (C). |
| Q7 D1 / D2 / D3 / D4 | PROBLEM ×4 | **All four flagged omissions are NOT ACCEPTABLE.** |
| Q8 (B) | OK WITH MINOR ISSUES | "Refuse and continue" is an acceptable off-protocol extension. The comment's claim that the mechanism "halts" is inaccurate. |

## Issues (consolidation)

**MAJOR** (all CODE; non-local):

| # | headline | issue | raised by |
|---|---|---|---|
| M1 | A | No operational realization and no O(kn)-work / O(n)-workspace conclusion (D1). | 1, 3 |
| M2 | B | No finite-precision implementation and no explicit 2^30·N(b_U+χ²)-bit bound (D2). | 1, 2 |
| M3 | A, B | Unrestricted existential functions with selected sample counts replace the named mechanisms (Def I.1.8, Algorithm 2) and their prescribed allocations (D4). | 1, 2, 3 |
| M4 | A | The analyst sees only answers, not the paper's public auxiliary records. Robustness against answer-only analysts does not imply robustness to extra public information. Witness: a mechanism that reveals its sample after round 1 fails on the indicator of the revealed points. | 1, 3 |
| M5 | B | The joint success event omits internal-cap non-exhaustion (D3). | 1, 2 |
| M6 | C | `valSize` units are not certified bits: 266 values have size exactly 8, more than the 256 8-bit words. An unspecified serialization factor cannot be absorbed into the explicit 2^512. | 2, 3 |
| M7 | C | The Spec omits the no-full-buffer/replay and bank lifetime/reset/allocation rules of Def R:def:streaming-model, which R:thm:main expressly incorporates (partII.tex:22, 41–42). | 2, 3 |

**MINOR** (DOCSTRING-ONLY):
- m1: (A)'s answers are unrestricted reals rather than values in [0,1]. Document this, or use the clipping wrapper F3.
- m2: the `VCovered` "halts" comment.
- m3: "Real.log x = 0 for x ≤ 1".
- m4: `Fin n → X` is nonempty iff X is nonempty only when n > 0.
- m5: p ≤ 5 ln(1/a_req) is false, with counterexample a_req = 99/1000, p = 12. Use 6.
- m6: "deterministic algorithms are never accurate" is false; n = 1 is a counterexample.
- m7: "only definitions and the three headlines" is inaccurate, since the file also contains proved examples.

**NOTE:**
- N1: outer measure is conservative, not vacuous.
- N2: the parse at Spec.lean:111 is correct; parentheses are optional.
- N3: fuel, tape and prefix determinism lemmas would be useful, but they are not a faithfulness issue.

**Refuted risks (R1–R12).** The consolidation investigated and rejected these:
- double counting in `adaSampleSize`;
- zero denominators;
- `valP = sInf ∅`;
- non-measurable events silently getting probability 0;
- tape counts making the bounds vacuous;
- tapeLen or fuel acting as advice;
- executions chosen to defeat the box guard;
- refuse-and-continue invalidating (B);
- the uniform-code and bounded-init assumptions being too strong;
- the choice of log base;
- the absorbed O-form in (A);
- the fixed universes (kept as a NOTE).

## Required changes (consolidation)

Blocking CODE changes:
1. **R1, restore (A).** Define the specified cascade: its locked allocation, coin law and complete public records. Give an operational real-arithmetic/oracle implementation. State accuracy, plus O(kn) work and O(n) workspace, for that same object, with the universal constants before the parameters.
2. **R2, restore (B).** Define Algorithm 2 with its prescribed allocation and internal state. Put cap and abort failure in the same event as wrong responses, under one ξ_req. Add an oracle-aware finite-bit implementation with the exact general space bound.
3. **R3, calibrate (C) to bits.** Use either a directly specified bit-level machine, or a DSL simulation/encoding theorem whose whole overhead sits inside `spaceBoundC`. Renaming "units" to "bits" is not enough.
4. **R4, enforce (C)'s strict model.** Tie the implementation to transitions that enforce:
   - no full buffering or replay of the stream;
   - persistence across ancestor corrections;
   - permitted rescalings;
   - data-independent bank births;
   - retirement before replacement.
   These must be actual execution state, not ghost logs.

DOCSTRING-ONLY changes (exact text in the consolidation's F1/F2):
5. Fix (A)'s output range and (B)'s halting description.
6. Fix logarithms, empty products, the p coefficient (6) and the deterministic subcase.
7. Fix the "only definitions" claim, and state the current verification scope explicitly.

**Alternative (F4, CODE).** Rename and narrow the headlines to honestly scoped statistical corollaries (`StatisticalExistence_A`/`_B`, …). The consolidation calls this "not a Main-Theorem repair". The consolidation's F3 also gives optional local patches that it verified.

Checked and correct:
- numerical transcriptions;
- probability normalizations;
- adaptive recursions;
- fresh-tape threading;
- dyadic parameters;
- initialization;
- the uniform algorithm before the parameters;
- no junk-value shortcut, empty-space shortcut, tape advice or fabricated execution.

## Records

The raw audit outputs (stage reports, the read-only inputs with their `SHA256SUMS.txt` and manifest, and the audit scripts) are internal and not part of this record. Round 1's exact fixes F1–F4 are in its consolidation report, under "Exact Lean fixes".

---

## Appendix (f2e2e lead 49ae37f2): chronology, Spec versions, disposition of every finding

Appended at the lock to a8ff0e4e's audit record above, which is copied verbatim except for the v3.1 kit's name sanitization (tool and model names, costs and internal paths removed). The technical detail is in
`STATEMENT_REVIEW.md` (v2.2b), in its tables "Changes v1 → v2", "Changes v2 → v2.1" and "Changes v2.1 → v2.2".

### Spec versions

| version | sha256 | location in the repo | status |
|---|---|---|---|
| v1 | `6a5254ff6e8d0fe81bdd9bb78b404d65c331e77d4c7f4e87c74f0e39255e5bee` | `attic/Spec_v1_6a5254ff.lean` (commit 06ddff3) | round-1 audit record: NOT FAITHFUL |
| v2 | `cc04b02b6187428568eba6953f90e76578ae75e8edaebaea3827a896c81b5124` | `spec_v2/Spec.lean` (commit 7982cfd) | round-2 audit record: (A), (B) FAITHFUL WITH MINOR; (C) UNDETERMINED (U-C) |
| v2.1 | `9aeafbeb0cdb9fae8df0ab3e1c2858ee72a53e374a155de2a7bf7f29e2a4959a` | `notes/spec_v2_1_draft/SpecV2_1.lean` | record of the focused (C) check: FAITHFUL WITH MINOR (dR) |
| v2.2 | `ae054eb68e9000f6081460c0fcc5bd7d05cb8a14f55ce2db76ba4c00673988d2` | `notes/spec_v2_2_draft/SpecV2_2.lean` | v2.1 + F-dR verbatim; code tokens identical to v2.1 |
| v2.2b | `a34af531676c260b10df8b75789a61db6775707b33f43680a3b7242d49dad43c` | `notes/spec_v2_2_draft/SpecV2_2b.lean` | v2.2 with only the title and footer labels changed; passed the mechanical check |
| v2.2c | `c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f` | **`F2e2e/Spec.lean`** (also `notes/spec_v2_2_draft/SpecV2_2c.lean`) | **LOCKED** per `SPEC_LOCK.sha256`. It is v2.2b with one footer comment line changed at sign-off (a tool-named label became "audit rounds 1–2"). Code tokens are identical to v2.1, v2.2 and v2.2b |

The intermediate v2.1 drafts (`4d282e43…`, `78f61e25…`, `519a5632…`) were never audited. `519a5632…` and `9aeafbeb…` have
byte-identical code. All derived versions are produced by generators that do exact-once replacements with source-sha
asserts: `notes/spec_v2_1_draft/make_v2_1.py`, `notes/spec_v2_2_draft/make_v2_2.py` and `make_v2_2b.py`.

### Chronology (UTC, 2026-10-25)

- 04:13: the user's request.
- 06:05: lead 49ae37f2 takes over from c4453444.
- 06:29: Spec v1 is sent. Round 1 starts at 06:30.
- 07:27: round 1 is consolidated as NOT FAITHFUL (M1–M7, m1–m7).
- 07:27 and 07:31: integrator decisions.
  - Spec v2 common core: M3, M4, M5 and the docstrings.
  - (C) with R3 (certified bits).
  - R4-0: the strict-model rules 2–3 are non-headline.
  - A_eff and B_space become additive v3 drafts only.
- 07:52–08:03: internal read-only pre-review of the v2 candidate. A, B and C are all FAITHFUL; the doc fixes are applied.
- 08:08: Spec v2 `cc04b02b…` is delivered. Round 2 follows: (A) and (B) FAITHFUL WITH MINOR; (C) UNDETERMINED on U-C.
- 09:37: Spec v2.1 `9aeafbeb…` is delivered.
  - The internal read-only checker C found the delta FAITHFUL. Its doc nits are applied in `9aeafbeb…`.
  - The integrator then froze `notes/spec_v2_1_draft/`.
- The mechanical pre-check of v2.1 against v2: PASS. The focused (C) check of v2.1: FAITHFUL WITH MINOR, with one fix, dR.
- 10:02: v2.2 `ae054eb6…` (F-dR).
- 10:04: v2.2b `a34af531…` (labels only, at the integrator's request).
- ~10:07: a8ff0e4e's mechanical check of v2.2b: PASS.
- 10:07:54: integrator sign-off, conditional on one comment-line change: remove the tool name from the Spec footer.
- 10:08: v2.2c `c28be50e…` is created. The lead's mechanical checks:
  - `diff` against v2.2b shows only L105;
  - a scan for internal tool and model names prints nothing;
  - `lean1` EXIT 0.
  a8ff0e4e confirms the diff independently.
- 10:09:42: lock applied by `notes/port_dry/apply_lock.sh --apply --go` (manifest `notes/port_dry/LOCK_MANIFEST.txt`) and `notes/lock_prep/lead_lock.sh --go`, then committed as "LOCK: Spec v2.2c" (`git log --grep 'LOCK: Spec v2.2c'`).

### Disposition of every finding

| round | id | finding (short) | disposition |
|---|---|---|---|
| 1 | M1 | (A) has no O(kn)/O(n) efficiency conclusion | Explicit non-claim (scope); headline renamed `Theorem_A_statistical`; additive v3 draft `notes/spec_v3_draft/AEff.lean` |
| 1 | M2 | (B) has no finite-bit implementation and no 2^30·N(b_𝒰+χ²) bound | Explicit non-claim; headline renamed `Theorem_B_statistical`; additive v3 draft `notes/spec_v3_draft/BSpace.lean` |
| 1 | M3 | (A)/(B) are unrestricted existentials | (A) is pinned to Def I.1.8's cascade (locked allocation, coin law); (B) is pinned to Algorithm 2 (allocation, internal state) |
| 1 | M4 | (A)'s analyst sees only the answers | The analyst sees the full public record (answer + τ_aux) |
| 1 | M5 | (B)'s success event omits cap non-exhaustion | Failure event = wrong covered response ∪ internal cap/abort of the same execution, under one ξ_req |
| 1 | M6 | `valSize` tree units are not bits | Certified bits: small-step machine C1, prefix-free `confBits`, per-step `RunsWithinBits`; v2.1 adds `stepWork` and `ctrlWork` (U-C) |
| 1 | M7 | Strict-model rules 2–3 are missing | R4-0: e2e (C) does not reference them; explicit non-claim. Rules 2–3 are proved as non-headline lemmas (`F2e2e/C/Alg/StrictModel.lean`); V6 was accepted in round 2 |
| 1 | m1–m7 | answer range; VCovered comment; Real.log; empty products; p ≤ 5 ln; deterministic algorithms; "only definitions" | All fixed in v2 (STATEMENT_REVIEW "Changes v1 → v2", rows m1–m7) |
| 1 | N1–N3 | outer measure; sample-sum parse; determinism | N1 kept (conservative). N2: the parse is correct (round-1 R1 refuted). N3: determinism lemmas proved in the project |
| 2 | U-C | Atomic arithmetic workspace not covered by the footprint | v2.1 §3.2: `opWork`/`arithRun` per primitive, `stepWork`, `ctrlWork`, conjunct `footprint + stepWork + ctrlWork ≤ S`. Non-headline lemmas proved (`F2e2e/Cost/Arith*`, `MachineWork`). Resolved per the focused check |
| 2 | dA | Review said the sample sum was parenthesized | Review text corrected |
| 2 | dB | B14: "T_j never decreases" is false across an abort | Spec docstrings of `alg2Interval`/`alg2Numerical`/`Alg2Outcome`/`alg2PeakCorrections` and the B14 row corrected |
| 2 | dC1 | Spec claimed rules 2–3 are "stated and proved" | The Spec makes no completion claim; it points to STATEMENT_REVIEW §F |
| 2 | dC2 | M6 row must say "per-step footprint ≤ S" | M6 row, §C.2 and §C.3 rewritten (per-step charge) |
| 2 | N3/F6 | Lattice example: "reads true, false" means Bernoulli outcomes | Docstring: outcomes vs raw tape bits |
| 2 | V6 | Is R4-0 faithful to e2e (C)? | Accepted |
| internal | a1–d | Checker C nits on the v2.1 delta (labels, §F refs, lemma names, a pre-existing `alg2Interval` docstring inaccuracy) | Applied in `9aeafbeb…` (docstrings only) |
| v2.1 check | dR | `regBits` docstring claimed a standalone self-delimiting code | F-dR verbatim in v2.2; §C.3.1 prose qualified |
| integrator | labels | The locked bytes must not say "not audited; not locked" | v2.2b: title and footer labels only |
| integrator | names | No tool names in shareable files | v2.2c: the footer's tool name became "audit" (one comment line) |


## v3.1 record (candidate; drafted by 1c1a75fe for the lead 49ae37f2)

> [!NOTE]
> This record was written as a candidate record, worded to stay true both before and after the integrator's
> sign-off. The v3.1 statement audit, an independent multi-stage statement audit, ran on
> `2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e`. Main carries the candidate commit only after the
> integrator's sign-off on a FAITHFUL verdict. The integrator's sanitized audit record is appended verbatim in the
> last section (added in the v3.1.1 docs revision).

### Spec versions (v3 line)

| version | sha256 | location in the repo | status |
|---|---|---|---|
| v3 candidate | `9dd5490e90b10eb1a9b46a9267b5840f0e177115312117294f790be45a1a7caa` | `notes/spec_v3/SpecV3.lean` | Sent to the independent multi-stage statement audit. Check 2 raised three MAJORs (F-A, F-B1, F-B2) and minor wording issues. Superseded by v3.1 |
| v3.1, audited text | `2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e` | `notes/spec_v31/scratch/SpecV31_2f4f3c09.lean` (copy) | v3.1 statement audit on `2f4f3c09…`; main carries this commit only after the integrator's sign-off on a FAITHFUL verdict |
| v3.1 | `d36e360b80ae72627a493f9a65b159f67159ec2fd6ee441688a18db4bc27153a` | `notes/spec_v31/SpecV31.lean`; on the candidate commit also `F2e2e/Spec.lean` (byte-identical; `SPEC_LOCK.sha256`; gate pins) | code delta F1 from `2f4f3c09…` (retained state), plus comment and docstring minors; the strip-check shows only the F1 code hunks |

v3.1 = `d36e360b80ae72627a493f9a65b159f67159ec2fd6ee441688a18db4bc27153a`, with code delta F1 (the retained state `alg2Retained`; v3.1 audit, check 2) from the audited
`2f4f3c09`, plus comment minors (red-team phase-1 m1, m2, m4; v3.1 audit minors (a), (b) in §6). An intermediate
comment-only build, `d65e839b…`, was superseded before use.

v3.1.1 = `7d40afe2843132693c1558b8aa97194e012344e80077c1b988e44e56f6976523`, a comment/docstring-only docs patch of the certified v3.1 `d36e360b…` (strip-check IDENTICAL),
applied after certification. It adopts the audit's exact replacement texts S1 (the §7 module comment), S2 (the
`alg2StateAt` and `alg2StateOf` docstrings) and S3 (the `ReproducesFor` docstring), and in the review section the exact
R1 replacement (§7.1 item 5, §7.2 item 13). No declaration body changes.

**Composition of v3.1** (3795 lines; `2f4f3c09…` has 3760):
* the locked v2.2c file as a byte-identical prefix: 2344 lines, 142,145 bytes, sha256 `c28be50e…`;
* the v3 header S0;
* §6 `Theorem_A_eff` (b5a655d4; fix F-A);
* §7 `Theorem_B_space` and §8 `Theorem_B_joint`, `Theorem_main_full`, `Theorem_main_full_2e128` (1c1a75fe; fixes
  F-B1, F-B2).

**Generator.** `notes/spec_v31/make_v31.py` builds the file from the fragments in `notes/spec_v31/parts/`. Each fix is
behind a flag: FA, B1, B2.
* With all flags off, the output is byte-identical to the v3 candidate `9dd5490e…` (`--selftest-v3`). So each fix is
  exactly its flag's difference, and it can be reviewed or dropped on its own.
* The change log, fix by fix, is `notes/spec_v31/V3_TO_V31.md`.
* The plain-math review of the appended sections is `notes/spec_v31/STATEMENT_REVIEW_v3_section.md`. It is appended
  to `STATEMENT_REVIEW.md` under "Spec v3.1 additions" on the candidate commit.

### Findings on v3 and their disposition in v3.1

| id | finding on v3 (short) | disposition in v3.1 |
|---|---|---|
| F-A (MAJOR) | §6 quantifier order `∃ C, ∀ k α β, ∃ P, P.size ≤ C·L ∧ …` with real literals: `P` could embed real constants depending on `(k, α, β)`, i.e. advice (non-uniformity) | `∃ C, ∃ P, P.RatLits ∧ ∀ k α β …`. ONE program, fixed before all parameters, with rational literals only (`RamProgram.RatLits`). The parameters reach it only through the public input `AEff.adaInput k α β` (`RunsWithin` gains `input`; initialization from `RamConf.ofInput`; the address map is proved). The size bound is dropped because `P` is fixed |
| F-A (minor) | §6 docstrings: cost wording for `seq`; the claim about exposing threshold noise of episodes not yet started; "future rounds" | Docstrings corrected; no semantic change |
| F-B1 (MAJOR) | `reqOracle` answers at ANY record code, so off-sample evaluation is possible. Witness: `𝒰 = {0, 1}`, sample all `0`, `f(1) = 1`, and `call 1000 [0, 1, 0]` returns `1`. The paper: queries are "accessed only through their values on the samples" (e2e.tex L151) | `BSpace.OracleFor code s req orc` pins the oracle only at the codes of sample records (`sel = 0`) and at the clipped endpoints (`sel = 1, 2`). `BSpace.ReproducesFor` quantifies over every consistent oracle family (`∀ orcs, (∀ t, OracleFor code s (reqs t) (orcs t)) → …`). The honest oracle qualifies (a proved example). Off-sample answers are adversarial, which is equivalent to a stuck semantics, because an answer is charged |
| F-B2 (MAJOR) | "It stores only current evaluations, not old queries" (partII.tex L970) was not implied. Witness: `M = J = R = 0`, and an implementation that keeps the first query's bit forever | `BSpace.VImplRun` makes the between-request states explicit (`VImplExec := ∃ states, VImplRun …`). `BSpace.alg2StateAt` is the state component of exactly `alg2Exec`'s fold, with `BSpace.alg2StateOf` and `BSpace.viewsBefore`. `ReproducesFor` requires `∃ enc` (after the sample, before the coins and the requests) with `states t = enc (alg2StateAt … t (viewsBefore s reqs t) ω)` for every `t`. The proof side (B-ARCH) confirmed that this matches its invariant at every `t`, including after an abort |
| §7 (minor) | Wording | STATEMENT_REVIEW §7: §7.1 steps 2 and 5; §7.2 items 3 and 13; §7.3 bullets; the non-vacuity list |

**Findings on v3.1 (`2f4f3c09…`) and their disposition in this build:**

| id | finding (short) | disposition |
|---|---|---|
| F1 (MAJOR; v3.1 audit, check 2) | `alg2Correct` (locked prefix) updates `G j i` for every `i : ℕ`. The coordinates `i ≥ n_j` accumulate evaluations at other blocks' sample points and are never read, but `states t = enc (alg2StateOf …)` lets `enc` read them, so old-query information could be kept | New `BSpace.alg2Retained` (zeroes `G j i` outside `j < p ∧ i < n_j`; every other field unchanged) and `BSpace.alg2RetainedOf`. These are now the reference state in `Theorem_B_space_with` and `Theorem_B_joint_with`. `ReproducesFor` / `Theorem_B_space_for` are unchanged. `T` and `thrInt` are `0` outside `j < p` in every reachable state (docstring). The proof side confirmed provability. New example: `(alg2Retained P st).G 0 (P.n 0) = 0` |
| (a), (b) (minor; v3.1 audit, check 2) | §6 documentation: the noise-cache argument; the review's projection count and its `Θ(n)` text | Docstrings and review text corrected (§6, b5a655d4); no code change |
| m1, m2, m4 (minor; red-team phase 1) | §7 header called history-freeness descriptive; the S0 title said v3; `Theorem_A_eff` did not say that storing the sample is uncounted | Comments and docstrings corrected; no code change |

Unchanged from v3: the v2.2c prefix, and every definition not named above. The headline names and shapes are
unchanged too: `Theorem_B_space := BSpace.Theorem_B_space_with 30`, `Theorem_B_joint := BSpace.Theorem_B_joint_with 30`,
`Theorem_main_full`, `Theorem_main_full_2e128`, and the parametrized budget `bSpaceBound e`.

### Mechanical checks of the v3.1 file (lead team; separate from the statement audit)

* `python3 notes/spec_v31/make_v31.py --final --check`: IDENTICAL. `--selftest-v3`: IDENTICAL.
* `scripts/lean1.sh notes/spec_v31/SpecV31.lean`: EXIT 0, with 0 warnings and 0 errors. The variants with one fix
  dropped also compile (FA off; B1 off; B2 off).
* `python3 notes/spec_v31/strip_check.py` on `2f4f3c09…` against this build: with comments and docstrings
  stripped, the only differences are F1's code hunks. These are the two new definitions, the reference state in
  `Theorem_B_space_with` and `Theorem_B_joint_with`, and the new example.
* Spec-rule scan (`scripts/scan_forbidden.py --spec`): 0 violations.
* Tool-name grep over the Spec and its docs: empty.
* `head -c 142145 notes/spec_v31/SpecV31.lean | sha256sum` = `c28be50e…`: the v2.2c prefix is byte-identical.
* Docs: `notes/spec_v31/V3_TO_V31.md` (sha256 `eabcb93f…`) and `notes/spec_v31/STATEMENT_REVIEW_v3_section.md`
  (sha256 `5f3e1174…`).

### Candidate commit and closing evidence

* The lock runs on a candidate worktree commit, cut by `notes/lock_prep_v3/cut_candidate_v31.sh` (integrator-approved
  flow). Main fast-forwards to the identical commit at sign-off.
* On the candidate commit, `F2e2e/Spec.lean` is a byte-identical copy of `notes/spec_v31/SpecV31.lean`.
  `SPEC_LOCK.sha256` and the gate pins name `d36e360b…`.
* Closing evidence: `evidence/<candidate rev>/`, produced on this exact commit; see the kit README.
* The comparator kit is built first, and the red teams start on it: red team A on woodruffd3, red team B on
  woodruffd4.

### Chronology (UTC, 2026-10-25; system timestamps; ≈ marks an approximate time)

* 12:50 (relayed 12:54): the user requires a full end-to-end proof. The computational clause of (A) and the bit-space clause of (B)
  become proved headlines of Spec v3.
* ≈13:40: one v3 Spec, parametrized by the bit budget's constant (integrator).
* Then the v3 candidate `9dd5490e…` is sent to the independent multi-stage statement audit.
* 14:24: check 2's three MAJORs (F-A, F-B1, F-B2) are relayed. The v3.1 drafting starts (b5a655d4 §6; 1c1a75fe §7, §8
  and the assembly).
* 14:42 (chat; relayed 14:46): user decision: v3.1 with all three fixes is the plan of record.
* 14:43: B-ARCH confirms that the F-B2 definitions match the proof.
* 14:48: v3.1 `2f4f3c09…` is final (Lean file). 14:49: its docs are final, and the candidate is frozen.
* 15:19: red-team phase-1 interim on `2f4f3c09…`: no CRITICAL or MAJOR findings; minors m1, m2, m4 to fix
  (comments and docstrings).
* 15:24: the v3.1 audit's check 2 raises MAJOR F1 (retained state) and minors (a), (b). The fix F1 is confined to the
  appended part; the proof side confirms it at 15:25.
* Integrator: the close runs on a candidate worktree commit; main fast-forwards at sign-off; the kit is built first.
* v3.1 statement audit on `2f4f3c09…`. Main carries the candidate commit only after the integrator's sign-off on a
  FAITHFUL verdict.

### The v3.1 statement audit: sanitized record (verbatim)

Verbatim copy of `notes/spec_v31/audit/F2E2E_V31_STATEMENT_AUDIT_SANITIZED.md` (sha256 `2b36d87ba03426d59fc4cfce7c51db22a12dbb084216efc7c225eb18ab87b99a`).

# f2e2e Spec v3.1: outcome of the independent statement audit (sanitized record)

Scope: the appended Sections 6–8 of the v3.1 statement, i.e. `Theorem_A_eff`, `Theorem_B_space`, `Theorem_B_joint`, `Theorem_main_full`, and the staged target `Theorem_main_full_2e128`. The locked v2.2c prefix (sha256 `c28be50e3898ed9275061038904c9931f8c5accb4313e4feac5c277cfb0d420f`) is byte-identical in both files and was context only. Faithfulness of the statement only; no proofs were audited.

Process: an independent multi-stage statement audit.
- Two independent checks reviewed the candidate `SpecV31.lean` (sha256 `2f4f3c09…`).
- A consolidation and a final stage then adjudicated their findings.
- These two stages also verified the post-check delta to `SpecV31_d36e360b.lean` (sha256 `d36e360b…`), together with a targeted check of that delta. The delta comprises code fix F1 plus comment fixes.
- The verdicts below judge the post-delta file.

## Final verdict (verbatim)

```
Verdict: FAITHFUL WITH MINOR ISSUES
Per-headline: (A_eff) FAITHFUL; (B_space) FAITHFUL WITH MINOR ISSUES; (B_joint) FAITHFUL WITH MINOR ISSUES; (main_full) FAITHFUL WITH MINOR ISSUES
Staged target: main_full_2e128 HONESTLY LABELLED
Covers: SpecV31.lean, sha256 2f4f3c0991583e1d9c9959425e22ee71e3ab8db133def4adc6b62f801d8aa37e (audited); SpecV31_d36e360b.lean, sha256 d36e360b80ae72627a493f9a65b159f67159ec2fd6ee441688a18db4bc27153a (delta: code (F1) verified in-stage; comment MINORs: 3, to be fixed in docs patch v3.1.1)
```

## Delta rulings, items (i)–(v) (final stage)

- **(i) VERIFIED.** F1's projection `alg2Retained` keeps exactly the information Algorithm 2 retains between requests, and no more:
  - the scores `G j i` for `j < p`, `i < n_j`;
  - the persistent correction counts, thresholds, request/rejection counters and flags.
  Weights are recomputable from these scores. A legal score coordinate is updated only from the same legal coordinate and the current evaluations, so no discarded coordinate feeds a retained one, and the projection does not discard anything the implementation needs.
- **(ii) VERIFIED.** The junk-coordinate witness found against `2f4f3c09` is blocked. In both histories the differing out-of-block coordinate (`G 0 (offset p)`) projects to 0, while all retained fields agree. This was established by an independent algebraic reconstruction, with locked parameters p = 12, χ = 97, q_A = 88, N = 241162555576119459840.
- **(iii) VERIFIED.** `T` and `thrInt` are 0 at every index `j ≥ p` in every reachable reference state. So leaving them unmasked is sound, and no further masking is needed. A support lemma for these zero tails would be useful proof infrastructure; this is a NOTE.
- **(iv) VERIFIED.** The executable changes are exactly F1: `alg2Retained` and `alg2RetainedOf`, the two bindings in `Theorem_B_space_with` and `Theorem_B_joint_with`, and one sanity example. There are 4 code hunks and 5 comment-only hunks. The prefix is byte-identical. No new vacuity, junk value or loophole was introduced.
- **(v) NOT VERIFIED "as unqualified".** The new comments are accurate: the v3.1 heading, the relevant-table noise-cache explanation, its review cross-reference (which resolves in the merged review), the A_eff sample-storage remark, and the `alg2RetainedOf` description. But three pre-existing or partial raw-state descriptions remain (S1–S3 below).

No MAJOR issue survives in the post-delta statement, and no further CODE change is required. The final also recorded:
- do not alter the locked prefix;
- do not require injectivity of `enc`;
- do not weaken the state condition after halting;
- do not replace F1 by an unrestricted raw-state refinement.

## The three comment MINORs in the Spec file (counted in the Covers line; DOCSTRING-ONLY; for docs patch v3.1.1)

- **S1.** The Section 7 header (new file, about lines 3284–3287) names the raw `alg2StateAt` as the argument of the encoding. The actual condition factors through `alg2RetainedOf`; the code is the stronger condition.
- **S2.** The `alg2StateAt` docstring (about lines 3430–3433) still calls the raw total-function state everything Algorithm 2 retains. Its unused score coordinates are exactly what F1 excludes.
- **S3.** The closing explanation in the `ReproducesFor` docstring (about lines 3501–3502) again identifies the paper's memory with the unrestricted `Alg2State`. The code and the opening of that docstring are correct.

Exact replacement texts proposed by the final stage. They are documentation-only, and the declaration bodies are unchanged.

### S1: replacement Section 7 module comment

```lean
/-! ## 7. Main Theorem (B), bit-space clause (`Theorem_B_space`)

This section states the bit-space clause for the pinned Algorithm 2 of §2:
at most `2^30 * N * (b_𝒰 + χ^2)` bits, plus the working space of its
evaluation oracle (e2e.tex L151–155; partII.tex L966–970).

One fixed pair of integer/list programs receives the encoded public
parameters and sample record codes at initialization. Each request supplies
its kind and a record-code-indexed evaluation oracle. The oracle may be any
oracle satisfying `OracleFor` for that sample and request.

The machine is the locked machine of §3.1 with reserved-index oracle
dispatch. The oracle argument and answer are charged in the before/after
configurations; only the oracle's internal working space is excluded.
Universal quantification over consistent oracles, together with this answer
charge, excludes calls at unconstrained selector/record combinations.

Every step of initialization and every request is charged its configuration
footprint, arithmetic workspace, and control temporaries. Responses must
equal the pinned `alg2Mech` on the same views and original fair-bit block.

The space bound alone does not exclude retained old queries.
`ReproducesFor` also requires one encoding, chosen after the sample but
before coins, requests, and oracle choices, such that every actual boundary
state is the encoding of the retained reference state. For the pinned
mechanism this reference is `alg2RetainedOf`: `alg2Retained` applied to the
raw `alg2StateOf` state. It preserves the paper's in-block scores and its
persistent counters, thresholds, and flags. Unused score coordinates cannot
authorize additional historical information.

One finite fair-bit tape is threaded through initialization and all
requests. The implementation is required for every tape length beyond a
bound depending only on public parameters. Tape length is not an input,
the tape cannot be rewound, and reading an empty tape is stuck.
-/
```

### S2: raw-state declarations (docstrings only; bodies unchanged; the `alg2StateOf` wording is included for consistency)

```lean
/-- The raw semantic state component of `alg2Exec`'s fold after
initialization and the first `t` requests. For `t = 0` this is the state
of `alg2Init`.

The total-function representation includes unused score coordinates outside
the paper's finite blocks. Those coordinates are not declared to be retained
machine memory. The pinned boundary-state contract uses `alg2RetainedOf`,
which applies `alg2Retained` to this raw state. -/
noncomputable def alg2StateAt (P : Alg2Params) {c : ℕ} (t : ℕ)
    (views : Fin t → VView P.N) (ω : Fin c → Bool) : Alg2State :=
  ((List.ofFn views).foldl (fun acc v => alg2Request P acc.2.1 v acc.2.2)
      (VResponse.accept, (alg2Init P (List.ofFn ω)).1,
        (alg2Init P (List.ofFn ω)).2)).2.1

/-- The raw `alg2StateAt` at the pinned public parameters.
`alg2RetainedOf` projects this state before it is supplied to the encoding
in the paper's history-freeness contract. -/
noncomputable def alg2StateOf (M J R : ℕ) (aReq ξReq : ℝ) (c : ℕ) (t : ℕ)
    (views : Fin t → VView (alg2Params M J R aReq ξReq).N)
    (ω : Fin c → Bool) : Alg2State :=
  alg2StateAt (alg2Params M J R aReq ξReq) t views ω
```

### S3: `ReproducesFor` (docstring replaced; body unchanged)

```lean
/-- Reproduction within the bit budget for one tape length.

For every admissible finite record domain, encoding, sample, coin block,
valid request sequence, and consistent oracle sequence, the actual programs
terminate within the budget and return exactly the reference responses on
the same views and original coin block.

For each sample, one encoding `enc` is chosen before the coins, requests,
and oracle choices. Every actual between-request state must equal `enc`
of `stateOf`. The encoding is not a runtime oracle, need not be injective,
and does not exempt any actual machine value from the space charge.

For the pinned Algorithm 2, `stateOf` is `alg2RetainedOf`: the raw reference
fold projected to the paper's in-block scores and other persistent state.
The out-of-block score coordinates of `Alg2State.G` are zeroed before `enc`
is applied. The unused correction-count and internal-threshold coordinates
are already zero in every reachable reference state. The sample may also
be retained because the encoding is chosen after the sample.

Universal quantification over `OracleFor` prevents use of unconstrained
oracle calls: an arbitrarily large answer would violate the charged budget.
The oracle remains indexed by record codes, not sample positions. -/
def ReproducesFor (e : ℕ) (Nf : ℕ → ℕ → ℕ → ℝ → ℝ → ℕ)
    (mech : (M J R : ℕ) → (aReq ξReq : ℝ) → (c : ℕ) →
      VMechanism (Nf M J R aReq ξReq) c) {σ : Type}
    (stateOf : (M J R : ℕ) → (aReq ξReq : ℝ) → (c : ℕ) → (t : ℕ) →
      (Fin t → VView (Nf M J R aReq ξReq)) → (Fin c → Bool) → σ)
    (impl : VImpl) (M J R : ℕ) (aReq ξReq : ℝ) (c : ℕ) : Prop :=
  ∀ (U : Type) [Fintype U] (bU : ℕ) (code : U → ℕ), Function.Injective code →
    (∀ x, code x < 2 ^ bU) →
    ∀ (s : Fin (Nf M J R aReq ξReq) → U), ∃ enc : σ → Val,
    ∀ (ω : Fin c → Bool) (reqs : ℕ → VReq U),
      (∀ t, (reqs t).Valid) →
      ∀ orcs : ℕ → VOracle, (∀ t, OracleFor code s (reqs t) (orcs t)) →
      ∃ states : ℕ → Val,
      VImplRun impl (encVParams M J R aReq ξReq) (encRecords code s)
        (fun t => (reqs t).2.1) orcs (List.ofFn ω)
        (bSpaceBound e (Nf M J R aReq ξReq) bU
          (valChi M J R (dyadicDown aReq) (dyadicDown ξReq)))
        (fun t => mech M J R aReq ξReq c t (viewsOf s reqs t) ω)
        states ∧
      ∀ t : ℕ,
        states t = enc (stateOf M J R aReq ξReq c t (viewsBefore s reqs t) ω)
```

## The review-document MINOR (not counted in the Covers line)

- **R1.** The merged review (kit rev de676dc, sha256 `657134d95930786a5f4e85dc87cc44568f39b91da06399fe2b9ed07b230a2386`) has a problem in Sections 7.1 and 7.2 (about lines 806–810 and 898–904). A raw-state equality formula and identification come just before the F1 correction at about lines 908–916. The prose is recoverable, but the displayed contract should use the projected reference.

Replace the raw-state equality in Section 7.1 item 5, and the corresponding identification in Section 7.2 item 13, by:

> **History-freeness after F1.** For each sample there is an encoding `enc : Alg2State → Val`, chosen before coins, requests, and consistent oracles. Every actual boundary state satisfies  
> `states t = enc (alg2RetainedOf M J R aReq ξReq c t (viewsBefore s reqs t) ω)`.  
> The reference is the raw `alg2StateOf` fold projected by `alg2Retained`. It retains scores only for `j < p` and `i < n_j`, together with persistent correction counts, thresholds, request/rejection counters, and flags. Unused score coordinates are zeroed; unused `T` and `thrInt` coordinates are already zero on reachable states. The sample may be retained because `enc` is chosen after it. The encoding is not a runtime oracle, and every actual machine value remains charged.

The merged review already contains the corrected noise-cache argument (Section 6.2 item 7; Section 6.5, "O(n) cells"), the "at most two" projections in Case B, and "asserts no Θ(n) lower bound". The earlier review findings on those points are therefore resolved.

## Caveats

- No stage of this audit compiled Lean. Compilation and the headline proofs are reported by the formalizers.
- The audit supplies no headline proof, no bit-space implementation proof, and no certification of numerical resource constants.
- Supporting computations were exact finite checks: parameter values, witness states, hunk classification, and machine-cost tests.
  - All packaged state, witness, machine-cost and source checks passed when run with the delta files present.
  - The targeted delta check's documentation audit reports FAIL by design on two documentation items: S1, and the review cross-reference, which it checked against the pre-merge review section. The merged review resolves that cross-reference.

### Kit verification and sign-off

* Red team B: ACCEPT WITH FINDINGS on kit `de676dccc6db`. All 3 kernels (Lean, nanoda, con-leche) ACCEPT, with the
  negative controls REJECTED.
* Integrator sign-off for the v3.1 lock: 16:24Z.
